# SemanticVG

SemanticVG is a semantic-first retrieval framework for workloads where flat
nearest-neighbor search is not enough. It organizes vectors around semantic
keys, grouped observations, local representative vectors, and optional
contextual relations, then executes mixed semantic-vector search with HDMG
(Hierarchical Dynamic-Metric Graph) routing.

Traditional vector search treats every item as an isolated embedding.
SemanticVG is designed for cases where the query also implies a target identity,
structured context, or linked evidence span. In those settings, relevance is not
only "which vector is closest?", but also "which semantic target should search
enter, and which related observations should stay connected?"

## Why SemanticVG?

Flat vector retrieval often fails in two recurring ways:

- **Semantic mismatch**: nearest neighbors can be close in embedding space while
  still belonging to the wrong semantic target.
- **Fragmented relevance**: relevant evidence may be split across views,
  passages, chunks, or linked records that should be retrieved together.

SemanticVG addresses these cases with a `VectorGroup` abstraction. A group keeps
the semantic target, member vectors, representative local regions, and relation
metadata in one retrieval object instead of leaving those signals as post-hoc
application logic.

## What Problems Does It Help With?

SemanticVG is built for retrieval workloads where the right answer is not just
the nearest isolated vector. The examples below use the original case images
from the paper artifact, but the point is practical: these are the kinds of
failure modes developers hit when vector search is used as the whole retrieval
model.



###  Case 1. Plausible semantic mismatch

<img src="docs/figures/readme/case1.jpg"  alt="case1">

**SemanticVG pattern:** Route into the intended semantic target before ranking local observations.


###  Case 2. Unjustified semantic mismatch

<img src="docs/figures/readme/case2.jpg"  alt="case2">

**SemanticVG pattern:** Combine semantic key vectors with embedding vectors so identity affects retrieval.


###  Case 3. Implicit fragmentation

<img src="docs/figures/readme/case3.jpg"  alt="case4">

**SemanticVG pattern: **Keep multi-view observations in one `VectorGroup` and search local representatives.

###  Case 4. Explicit fragmentation

<img src="docs/figures/readme/case4.jpg"  alt="case4">

**SemanticVG pattern:** Store contextual links and expand from one hit to the evidence span. 

This is the main shift: SemanticVG asks which semantic object, 
local representative region, and linked evidence should be returned together.

## Core Ideas

- **VectorMap** stores semantic keys and their associated vector groups.
- **VectorGroup** stores a representative vector plus member vectors and
  descriptions.
- **Mixed retrieval** combines key-level semantic distance and instance-level
  embedding distance with a tunable `beta`.
- **HDMG routing** indexes semantically attached representative units for fast
  group-level search.
- **Relation-aware expansion** supports contextual or linked evidence retrieval
  when descriptions include explicit vector relations.

## Vector Group Structure

<img src="docs/figures/readme/vg-structure.jpg" width="860" alt="Vector Group structure">

A `VectorGroup` is the retrieval unit behind SemanticVG. It keeps the target
identity (`k_G` and `s_G`), member observations (`M_G`), representative local
regions (`R_G`), and relevance-bearing links (`E_G`) in one managed object. The
index can therefore route by semantic target, navigate inside the target, and
expand through context links without pushing all of that logic into downstream
application code.

## Quick Start

Install the package in editable mode:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
```

If you want the packaged core library from PyPI later, the distribution name is
`violas`.

Run the minimal example. It uses synthetic vectors and does not require any
dataset, embedding model, or external vector database:

```bash
python examples/minimal_vectormap.py
```

Minimal API usage:

```python
import numpy as np

from violas import VectorGroup, VectorMap

vectors = [np.random.rand(4) for _ in range(5)]
group = VectorGroup(
    group_name="demo",
    representative=np.mean(vectors, axis=0),
    rep_description="demo representative",
    vectors=vectors,
    descriptions=[{"text": f"item {i}"} for i in range(5)],
)

vm = VectorMap()
vm.insert("example", group)

query = np.random.rand(4)
results = vm.search(query, top_k=3)
for result in results:
    print(result)
```

## API Guide

The public API follows the same workflow as a production retrieval project:
ingest grouped data, attach semantic signals, build an index, then choose the
search mode that matches the query.

### 1. Ingest Semantic Groups

| API | Typical use | Notes |
| --- | --- | --- |
| `VectorGroup(...)` | Create a retrieval unit with a representative vector, member vectors, and descriptions. | Use one group for one semantic target, document, entity, event, or paired object. |
| `VectorMap.insert(key, group, metadata=None)` | Register a group under a semantic key. | `key` is the target-level entry point used by scoped and mixed search. |
| `VectorMap.insert_with_auto_cluster(key, group, alpha=0.5)` | Split a large group into representative local regions. | Useful when a target has many views, chunks, or modes. |
| `VectorMap.add_vector(vector, description)` | Append one item to an existing group. | The description should include `key` and `group_name`. |
| `VectorMap.add_vector_list(vectors, descriptions)` | Batch append items and create context ids. | Convenient for chunked documents or ordered evidence. |

### 2. Attach Semantic Signals

| API | Typical use | Notes |
| --- | --- | --- |
| `VectorMap.set_key_vectors(key_vectors)` | Provide semantic vectors for keys such as classes, entities, or document ids. | Enables mixed semantic-vector retrieval. |
| `VectorMap.set_key_vectors_from_predictor(predictor)` | Import key vectors from a predictor object. | The predictor is expected to expose `keys` and `text_features`. |
| `VectorMap.get_key_vector(key)` | Resolve the semantic vector for a key or clustered subkey. | Handles keys such as `rhino-0001` by mapping back to `rhino`. |

### 3. Build Search Indexes

| API | Typical use | Notes |
| --- | --- | --- |
| `VectorMap.build_index()` | Build local indexes for representative and single-vector search. | Uses FAISS when available and falls back to exact search otherwise. |
| `VectorMap.build_rep_index()` | Build only the representative-vector index. | Useful for group-level candidate generation. |
| `VectorMap.build_single_index()` | Build only the member-vector index. | Useful for flat item-level lookup. |
| `VectorMap.build_hdmg(embedding_k=16, semantic_intra_k=4, ...)` | Build HDMG over semantically attached representatives. | This is the fast path for mixed semantic-vector search. |
| `VectorMap.get_last_hdmg_search_stats()` | Inspect the previous HDMG query. | Helpful for debugging visited nodes and graph traversal behavior. |

### 4. Search Modes

| API | Query pattern | Result behavior |
| --- | --- | --- |
| `VectorMap.search(query_vector, top_k=5, key=None, mode="single")` | Standard vector search, optionally scoped to one key. | Returns `SearchResult` objects with distance, key, group, and vector index. |
| `VectorMap.search_with_rep_vec(query_vector, top_k=5)` | Search group representatives. | Good for routing to target-level candidates. |
| `VectorMap.search_with_representative_rerank(query_vector, query_key_vector=None, beta=0.5)` | Use representatives first, then rerank with semantic information. | Useful when quality matters more than raw flat search speed. |
| `VectorMap.search_with_mixed_key_rep_vec(query_vector, query_key_vector, beta=0.5)` | Combine semantic-key relevance and representative-vector relevance. | `beta` controls the semantic vs. embedding tradeoff. |
| `VectorMap.search_hdmg(query_vector, query_key_vector=None, alpha=0.5, top_k=5)` | Run graph-based semantic-vector retrieval. | Recommended for scalable mixed retrieval. |

### 5. Relations, Context, and Multimodal Retrieval

| API | Query pattern | Result behavior |
| --- | --- | --- |
| `VectorRef` | Address one vector inside a key/group/index location. | Used to build explicit links between items. |
| `VectorRelation` | Store typed relations such as context, pair, parent-child, or temporal links. | Lets retrieval expand beyond one isolated hit. |
| `VectorMap.add_pair_relation(key, group1_id, group2_id)` | Link paired groups, such as image-caption or query-answer groups. | Supports paired evidence retrieval. |
| `VectorMap.add_tree_relation(key, parent_name, child_name)` | Store hierarchical relations. | Useful for document sections, taxonomy, or structured records. |
| `VectorMap.search_with_contextual_vectors(query_vector, num=2)` | Search and include nearby context vectors. | Works well for chunked documents and dialogue histories. |
| `VectorMap.get_contextual_vectors(result, num=2)` | Expand an existing result with its neighbors. | Turns one hit into a small evidence bundle. |
| `VectorMap.search_with_relations(query_vector, relation_types=...)` | Search while following explicit stored relations. | Returns relation-aware results. |
| `VectorMap.search_multimodal(query_vectors, modality_weights=...)` | Fuse several query vectors or modalities. | Useful when one target has image, text, or other views. |
| `VectorMap.get_statistics()` / `VectorMap.analyze_relationships()` | Inspect storage and relation coverage. | Useful for dataset checks and benchmark reporting. |

Example: group-scoped retrieval for a known target:

```python
results = vm.search(query_vector, key="rhino", top_k=5)
```

Example: mixed semantic-vector retrieval with HDMG:

```python
vm.set_key_vectors(key_vectors)
vm.build_hdmg()

results = vm.search_hdmg(
    query_vector=image_embedding,
    query_key_vector=semantic_embedding,
    alpha=0.5,
    top_k=5,
)
```

Example: expand a hit into contextual evidence:

```python
base_results = vm.search(query_vector, top_k=1)
context_bundle = vm.get_contextual_vectors(base_results[0], num=2)
```

For a broader overview of supported retrieval patterns, see
[docs/api.md](docs/api.md).

## Installation Options

The full benchmark suite uses several optional backends. For quick library
experiments, install only the minimal dependencies shown above.

For the full benchmark environment:

```bash
pip install -r requirements.txt
pip install -e .
```

Alternatively, use the full benchmark requirements file:

```bash
pip install -r requirements.txt
```

The full benchmark dependencies include optional-heavy packages such as CLIP,
Sentence-Transformers, FAISS, Milvus Lite, Qdrant, and Chroma because the
benchmark suite compares SemanticVG with external vector database baselines.

## Repository Layout

```text
SemanticVG/
  semanticvg/
    storage/       # VectorMap, VectorGroup, relation helpers
    core/          # feature helpers, recall utilities, baseline indexes
  benchmarks/      # six benchmark pipelines plus diversity cases
  examples/        # small runnable examples
  scripts/         # benchmark wrapper scripts
  docs/            # API notes, data formats, benchmark results, case studies
```

## Benchmark Overview

![SemanticVG Benchmark Overview](docs/figures/benchmarks/overview_grid.png)

At the balanced mixed-retrieval setting (`beta = 0.5`), SemanticVG delivers
high retrieval quality with low latency across six vision and text datasets.

| Dataset | HDMG Recall@3 | HDMG Latency (ms) | Representative Recall@3 | Representative Latency (ms) | Milvus Recall@3 | Milvus Latency (ms) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Caltech-101 | 0.9985 | 3.06 | 1.0000 | 131.53 | 0.8972 | 15.94 |
| CUB-200-2011 | 1.0000 | 2.91 | 1.0000 | 163.91 | 0.5253 | 15.69 |
| COCO | 0.9965 | 1.49 | 1.0000 | 115.75 | 0.6625 | 4.97 |
| 20 Newsgroups | 0.9987 | 2.50 | 0.9715 | 81.89 | 0.7832 | 5.16 |
| OHSUMED | 0.9809 | 2.71 | 0.9226 | 62.44 | 0.4586 | 4.57 |
| Yahoo Answers | 1.0000 | 2.94 | 0.9507 | 58.56 | 0.6132 | 5.23 |

Key takeaways:

- HDMG reaches near-perfect retrieval quality on every benchmark at `beta = 0.5`.
- Representative reranking remains accurate but is substantially slower than HDMG.
- Pure-vector baselines are competitive at `beta = 0.0`, but degrade once
  semantic control matters.

Experiments were run on a server with an Intel Xeon Platinum 8350C CPU
(2.60 GHz), 16 CPU cores, and 64 GB RAM. Image embeddings use CLIP ViT-B/32 and
text embeddings use Sentence-Transformers all-MiniLM-L6-v2 in the benchmark
pipelines.

More details:

- [Benchmark Results](docs/results.md)
- [Benchmark Notes](docs/benchmark.md)
- [Data Format](docs/data_format.md)

## Running Benchmarks

The shell scripts assume a workspace where `SemanticVG/` and `dataset/` are
siblings. Override the dataset variables if your data lives elsewhere.

```bash
bash scripts/run_bench_all.sh
bash scripts/run_bench_vision.sh
bash scripts/run_bench_text.sh
bash scripts/run_diversity_case.sh
```

Vision dataset variables:

- `CALTECH_ROOT`
- `CUB_ROOT`
- `COCO_ROOT`
- `COCO_JSON`

Text dataset variables:

- `NEWS20_ROOT`
- `OHSUMED_ROOT`
- `YAHOO_ROOT`

Saved artifacts are written under `outputs/<benchmark>/` by default. External
vector database baselines are disabled by default for portability. To enable
them:

```bash
export SEMANTICVG_ENABLE_EXTERNAL_DBS=1
```
