from pathlib import Path

from setuptools import setup


README = Path(__file__).parent / "PYPI_README.md"


setup(
    name="violas",
    version="0.0.1",
    description="Core grouped vector retrieval primitives from the SemanticVG project.",
    long_description=README.read_text(encoding="utf-8"),
    long_description_content_type="text/markdown",
    author="SemanticVG Authors",
    url="https://github.com/DoubleNorth/SemanticVG",
    project_urls={
        "Documentation": "https://github.com/DoubleNorth/SemanticVG#readme",
        "Issues": "https://github.com/DoubleNorth/SemanticVG/issues",
    },
    python_requires=">=3.9",
    packages=["violas", "semanticvg", "semanticvg.storage"],
    install_requires=[
        "numpy",
        "scipy",
        "scikit-learn",
        "tqdm",
    ],
    extras_require={
        "faiss": ["faiss-cpu"],
    },
    keywords=[
        "vector-database",
        "vector-search",
        "retrieval",
        "semantic-search",
    ],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)
