import unittest
from unittest.mock import patch

from gradexp import auth


class TestAuthLoginHelpers(unittest.TestCase):
    def test_get_user_display_name_prefers_clerk_name_fields(self):
        user_info = {
            "first_name": "Ada",
            "last_name": "Lovelace",
            "username": "user_user_2vdDOxzOKNU2qBF6szuDEGDcW5T",
            "id": "user_2vdDOxzOKNU2qBF6szuDEGDcW5T",
        }

        self.assertEqual(auth._get_user_display_name(user_info), "Ada Lovelace")

    def test_get_user_display_name_falls_back_to_primary_email(self):
        user_info = {
            "username": "user_user_2vdDOxzOKNU2qBF6szuDEGDcW5T",
            "id": "user_2vdDOxzOKNU2qBF6szuDEGDcW5T",
            "primary_email_address_id": "id_2",
            "email_addresses": [
                {"id": "id_1", "email_address": "wrong@example.com"},
                {"id": "id_2", "email_address": "ada@example.com"},
            ],
        }

        self.assertEqual(auth._get_user_display_name(user_info), "ada@example.com")

    def test_get_user_display_name_hides_internal_identifiers(self):
        user_info = {
            "username": "user_user_2vdDOxzOKNU2qBF6szuDEGDcW5T",
            "id": "user_2vdDOxzOKNU2qBF6szuDEGDcW5T",
        }

        self.assertEqual(auth._get_user_display_name(user_info), "")

    def test_prompt_api_key_confirms_hidden_input_length(self):
        entered_chars = iter(list("secret-key\n"))
        echo_messages = []

        def fake_getchar(echo=False):
            return next(entered_chars)

        def fake_echo(message="", nl=True):
            echo_messages.append((message, nl))

        with patch("gradexp.auth.click.getchar", side_effect=fake_getchar), \
             patch("gradexp.auth.click.echo", side_effect=fake_echo):
            api_key = auth._prompt_api_key()

        self.assertEqual(api_key, "secret-key")
        rendered_messages = [message for message, _ in echo_messages]
        self.assertTrue(any("Paste your API key and press Enter (input hidden):" in message for message in rendered_messages))
        self.assertTrue(any("Received API key (10 chars)." in message for message in rendered_messages))

    def test_login_flow_uses_friendly_display_name(self):
        user_info = {
            "first_name": "Ada",
            "last_name": "Lovelace",
            "username": "user_user_2vdDOxzOKNU2qBF6szuDEGDcW5T",
        }

        with patch("gradexp.auth.get_web_base_url", return_value="https://gradient-explorer.xyz"), \
             patch("gradexp.auth.webbrowser.open", return_value=True), \
             patch("gradexp.auth._prompt_api_key", return_value="test_api_key"), \
             patch("gradexp.auth.validate_api_key", return_value=user_info), \
             patch("gradexp.auth.save_token") as mock_save_token, \
             patch("gradexp.auth.click.echo"), \
             patch("gradexp.auth.click.secho") as mock_secho:
            auth.login_flow()

        mock_save_token.assert_called_once_with("test_api_key")
        mock_secho.assert_called_once_with("Logged in as Ada Lovelace. API key saved.", fg="green")


if __name__ == "__main__":
    unittest.main()
