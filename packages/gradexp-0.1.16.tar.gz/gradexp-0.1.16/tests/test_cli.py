import unittest
from unittest.mock import patch

from click.testing import CliRunner

from gradexp.cli import main


class TestCli(unittest.TestCase):
    def test_login_command_calls_login_flow(self):
        runner = CliRunner()

        with patch("gradexp.cli.auth.login_flow") as mock_login_flow:
            result = runner.invoke(main, ["login"])

        self.assertEqual(result.exit_code, 0, result.output)
        mock_login_flow.assert_called_once_with(debug=False)


if __name__ == "__main__":
    unittest.main()
