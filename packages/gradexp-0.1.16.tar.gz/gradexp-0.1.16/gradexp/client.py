import os
import sys
import signal
import atexit
import base64
import json
import numbers
import time
import threading
import queue
from uuid import uuid4
import requests
import numpy as np

from . import auth
from ._util import (
    BATCH_JSON_ITEM_SEPARATOR_BYTES,
    BATCH_JSON_PREFIX_BYTES,
    BATCH_JSON_SUFFIX_BYTES,
    env_bool,
    env_float,
    env_int,
    estimate_batch_body_wire_bytes,
    estimate_batch_item_wire_bytes,
    human_bytes,
    next_run_name,
)
from .precision import (
    BFLOAT16_DTYPE,
    DEFAULT_PRECISION,
    FLOAT16_DTYPE,
    FLOAT32_DTYPE,
    canonicalize_precision,
    flattened_element_count,
)

GRADEXP_PREFIX = "\033[38;5;174mgradexp\033[0m: "
_GRADEXP_PREFIX_WIDTH = len("gradexp: ")
_UNDERLINE = "\033[4m"
_DIM = "\033[2m"
_BAR_COLOR = "\033[38;5;151m"
_RESET = "\033[0m"
_MAX_TENSOR_ELEMENTS = 1024 * 1024 * 64
_MAX_TENSOR_ELEMENTS_LABEL = "1024x1024x64"


class InitExit(SystemExit):
    """User-facing init failure that should exit without a traceback."""

    def __init__(self, lines, code=1):
        self.lines = [str(line) for line in lines]
        self.exit_code = int(code)
        super().__init__("\n".join(self.lines))


def _build_local_log_group(kind):
    return {
        "kind": str(kind),
        "group_id": uuid4().hex,
        "created_at_ns": time.time_ns(),
    }

def _term_log(message, end="\n"):
    """
    Prints a message with a colored 'gradexp:' prefix.
    """
    # Handle multi-line messages or messages starting with newline
    if isinstance(message, str) and message.startswith("\n"):
        print(f"\n{GRADEXP_PREFIX}{message[1:]}", end=end)
    else:
        print(f"{GRADEXP_PREFIX}{message}", end=end)

def _term_link(url):
    """Format a URL with underline and OSC 8 hyperlink escape for clickable terminal links."""
    return f"\033]8;;{url}\033\\{_UNDERLINE}{url}{_RESET}\033]8;;\033\\"


def _raise_init_exit(*lines, code=1):
    raise InitExit(lines, code=code)

def _check_first_run():
    """Show a one-time welcome message on first successful init."""
    marker = os.path.join(auth.get_config_dir(), ".welcome-shown")
    if os.path.exists(marker):
        return
    _term_log("Welcome to Gradient Explorer!")
    _term_log("  Log tensors:       gradexp.log(tensor, name='my_tensor')")
    _term_log("  Dimension labels:  gradexp.log(tensor, name='x', dimension_labels=['batch', 'height', 'width'])")
    _term_log("  Gradient stats:    gradexp.log_gradient_stats(model)")
    _term_log("  Local viewer:      gradexp local start")
    print()
    try:
        os.makedirs(os.path.dirname(marker), exist_ok=True)
        with open(marker, "w") as f:
            f.write("")
    except OSError:
        pass

def _format_shape(shape):
    if not shape:
        return "scalar"
    return "x".join(str(dim) for dim in shape)

def _describe_tensor_limit(shape, element_count):
    return (
        f"{element_count:,} flattened elements (shape {_format_shape(shape)}) exceeds the hard limit of "
        f"{_MAX_TENSOR_ELEMENTS:,} ({_MAX_TENSOR_ELEMENTS_LABEL})."
    )

def _inspect_tensor_shape_and_size(tensor):
    shape = getattr(tensor, "shape", None)
    if shape is not None:
        try:
            shape_list = [int(dim) for dim in list(shape)]
            return shape_list, flattened_element_count(shape_list)
        except (TypeError, ValueError):
            pass

    numel = getattr(tensor, "numel", None)
    if callable(numel):
        try:
            element_count = int(numel())
            if element_count >= 0:
                return None, element_count
        except (TypeError, ValueError):
            pass

    try:
        array = np.asarray(tensor)
    except Exception:
        return None, None

    return list(array.shape), int(array.size)


def _float32_to_bfloat16_uint16(tensor):
    float32_tensor = np.ascontiguousarray(np.asarray(tensor, dtype="<f4"))
    raw_bits = float32_tensor.view(np.uint32)
    rounding_bias = np.uint32(0x7FFF) + ((raw_bits >> np.uint32(16)) & np.uint32(1))
    return ((raw_bits + rounding_bias) >> np.uint32(16)).astype("<u2", copy=False)


def _serialize_tensor_bytes(tensor, storage_dtype):
    canonical_dtype = canonicalize_precision(storage_dtype)
    float32_tensor = np.ascontiguousarray(np.asarray(tensor, dtype="<f4"))

    if canonical_dtype == FLOAT32_DTYPE:
        return float32_tensor.tobytes()

    if canonical_dtype == FLOAT16_DTYPE:
        return np.ascontiguousarray(float32_tensor.astype("<f2")).tobytes()

    if canonical_dtype == BFLOAT16_DTYPE:
        return np.ascontiguousarray(_float32_to_bfloat16_uint16(float32_tensor)).tobytes()

    raise ValueError(f"Unsupported storage dtype: {storage_dtype}")

_SPINNER_FRAMES = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"

class _Spinner:
    """Inline spinner shown during blocking operations."""
    def __init__(self, message):
        self._message = message
        self._stop = threading.Event()
        self._thread = None

    def __enter__(self):
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *_):
        if self._stop.is_set():
            return
        self._stop.set()
        self._thread.join()
        sys.stdout.write(f"\r{' ' * (_GRADEXP_PREFIX_WIDTH + len(self._message) + 4)}\r")
        sys.stdout.flush()

    def _run(self):
        i = 0
        while not self._stop.wait(0.08):
            frame = _SPINNER_FRAMES[i % len(_SPINNER_FRAMES)]
            sys.stdout.write(f"\r{GRADEXP_PREFIX}{self._message} {frame} ")
            sys.stdout.flush()
            i += 1

class Client:
    def __init__(self):
        self.api_key = None
        self.run_id = None
        self.project_id = None
        self._api_base_url = None
        self._web_base_url = None
        self.tensors = {} # {name: {"id": uuid, "step": 0}}
        self._tensors_lock = threading.Lock()  # Protects self.tensors
        self.active = False
        self._session = requests.Session()
        self._upload_queue = queue.Queue()
        self._batch_queue = queue.Queue()
        self._stop_event = threading.Event()
        self._batcher_thread = None
        self._uploader_threads = []
        self._interrupted = False
        self._original_sigint_handler = None
        self._original_sigterm_handler = None
        self._local_backend_status = None
        self._local_runtime_status_emitted = False
        self._run_url = None
        self._init_time = None
        self._tensor_precision = DEFAULT_PRECISION

        # Progress tracking
        self._progress_lock = threading.Lock()
        self._bytes_uploaded = 0
        self._tensors_uploaded = 0
        self._total_tensors_queued = 0
        self._upload_start_time = None

    def _get_runtime_api_base_url(self):
        return (self._api_base_url or auth.get_api_base_url()).rstrip("/")

    def _get_runtime_web_base_url(self):
        return (self._web_base_url or auth.get_web_base_url()).rstrip("/")

    def _build_api_url(self, path):
        normalized_path = path if path.startswith("/") else f"/{path}"
        return f"{self._get_runtime_api_base_url()}{normalized_path}"

    def _get_upload_config(self):
        return {
            "batch_size": env_int("GRADEXP_BATCH_SIZE", 1000),
            "max_batch_bytes": env_int("GRADEXP_MAX_BATCH_BYTES", 5 * 1024 * 1024),
            "idle_flush_s": env_float("GRADEXP_BATCH_IDLE_FLUSH_S", 2.0),
            "max_batch_age_s": env_float("GRADEXP_BATCH_MAX_AGE_S", 15.0),
            "min_flush_steps": env_int("GRADEXP_BATCH_MIN_FLUSH_STEPS", 8),
            "min_flush_bytes": env_int("GRADEXP_BATCH_MIN_FLUSH_BYTES", 64 * 1024),
            "debug_upload": env_bool("GRADEXP_DEBUG_UPLOAD", default=False),
            "gzip_upload": env_bool("GRADEXP_GZIP_UPLOAD", default=False),
            "gzip_level": env_int("GRADEXP_GZIP_LEVEL", 1),
            "upload_workers": env_int("GRADEXP_UPLOAD_WORKERS", 1),
            "max_chunk_bytes": env_int("GRADEXP_MAX_CHUNK_BYTES", 4 * 1024 * 1024),
        }

    def _get_local_backend_status(self):
        if self._local_backend_status is not None:
            return self._local_backend_status

        api_base_url = self._get_runtime_api_base_url()
        if not (
            auth.is_loopback_url(api_base_url)
            or auth.is_loopback_url(self._get_runtime_web_base_url())
        ):
            self._local_backend_status = False
            return None

        local_backend_status = {
            "api_base_url": api_base_url,
            "data_dir": str(auth.get_local_data_dir()),
        }

        try:
            response = self._session.get(self._build_api_url("/version"), timeout=1.0)
            response.raise_for_status()
            payload = response.json()
            data_dir = payload.get("data_dir")
            if isinstance(data_dir, str) and data_dir.strip():
                local_backend_status["data_dir"] = data_dir.strip()
        except (ValueError, requests.exceptions.RequestException):
            pass

        self._local_backend_status = local_backend_status
        return self._local_backend_status

    def _maybe_log_local_backend_status(self):
        if self._local_runtime_status_emitted:
            return

        local_backend_status = self._get_local_backend_status()
        if not local_backend_status:
            return

        _term_log(
            f"Local backend detected at {local_backend_status['api_base_url']}. Logging to the local store in {local_backend_status['data_dir']}"
        )
        self._local_runtime_status_emitted = True

    def init(self, project_name=None, run_name=None, precision=None):
        """
        Initialize a new run session.
        """
        self._tensor_precision = canonicalize_precision(precision)

        # Try to pull from wandb if not provided
        if project_name is None or run_name is None:
            if "wandb" in sys.modules:
                import wandb
                if wandb.run:
                    if project_name is None:
                        project_name = wandb.run.project
                    if run_name is None:
                        run_name = wandb.run.name
                        
        # Fallback to defaults if still None
        if project_name is None:
            project_name = "default"
        if run_name is None:
            run_name = "default-run"

        self._api_base_url = auth.get_api_base_url()
        self._web_base_url = auth.get_web_base_url()
        self.api_key = auth.load_token()
        if not self.api_key:
            _raise_init_exit(
                "Authentication required before gradexp.init().",
                "  Hosted runs:       gradexp login",
                "  Local viewer:      gradexp local start",
                "  Start a local instance first and gradexp.init() will route there automatically.",
            )

        current_run_name = run_name
        spinner = _Spinner("Connecting")
        spinner.__enter__()
        try:
            while True:
                payload = {
                    "project_name": project_name,
                    "run_name": current_run_name
                }

                try:
                    url = self._build_api_url("/api/v1/runs")
                    headers = {
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json"
                    }

                    response = self._session.post(url, headers=headers, json=payload)
                    response.raise_for_status()

                    data = response.json()
                    self.run_id = data.get("run_id")
                    self.project_id = data.get("project_id")
                    self.tensors = {}
                    self.active = True
                    self._local_backend_status = None
                    self._local_runtime_status_emitted = False
                    self._bytes_uploaded = 0
                    self._tensors_uploaded = 0
                    self._total_tensors_queued = 0
                    self._upload_start_time = None

                    self._stop_event.clear()
                    cfg = self._get_upload_config()
                    workers = max(1, cfg["upload_workers"])
                    adapter = requests.adapters.HTTPAdapter(pool_connections=workers * 2, pool_maxsize=workers * 2)
                    self._session.mount("https://", adapter)
                    self._session.mount("http://", adapter)

                    self._uploader_threads = [
                        threading.Thread(target=self._uploader_worker, daemon=True)
                        for _ in range(workers)
                    ]
                    for t in self._uploader_threads:
                        t.start()
                    self._batcher_thread = threading.Thread(target=self._batcher_worker, daemon=True)
                    self._batcher_thread.start()

                    base_url = self._get_runtime_web_base_url()
                    run_url = f"{base_url}/?project={self.project_id}&run={self.run_id}"
                    self._run_url = run_url
                    self._init_time = time.time()

                    spinner.__exit__(None, None, None)
                    _check_first_run()
                    self._maybe_log_local_backend_status()
                    _term_log(f"Initialized. View run at {_term_link(run_url)}")

                    atexit.register(self.finish)

                    try:
                        self._original_sigint_handler = signal.getsignal(signal.SIGINT)
                        self._original_sigterm_handler = signal.getsignal(signal.SIGTERM)
                        signal.signal(signal.SIGINT, self._handle_interrupt)
                        signal.signal(signal.SIGTERM, self._handle_interrupt)
                    except ValueError:
                        pass

                    return  # Success

                except requests.exceptions.HTTPError as e:
                    if e.response.status_code == 409:
                        current_run_name = next_run_name(current_run_name, e.response)
                        continue

                    _term_log(f"Failed to initialize: {e}")
                    try:
                        _term_log(f"Backend error message: {e.response.text}")
                    except Exception:
                        pass

                    if e.response.status_code == 401:
                        _raise_init_exit(
                            "Authentication failed: Unauthorized.",
                            "  Hosted runs:       gradexp login",
                            "  Local viewer:      gradexp local start",
                            "  Start a local instance first and gradexp.init() will route there automatically.",
                        )
                    else:
                        raise
                except requests.exceptions.RequestException as e:
                    _term_log(f"Failed to initialize: {e}")
                    raise
        finally:
            spinner.__exit__(None, None, None)

    def _ensure_tensor_registered(self, name, dtype, shape, dimension_labels=None, tag=None):
        """
        Ensures a tensor exists on the backend. Returns its ID.
        Thread-safe - called from worker thread.
        """
        with self._tensors_lock:
            if name in self.tensors and self.tensors[name].get("id"):
                return self.tensors[name]["id"]

        try:
            url = self._build_api_url(f"/api/v1/runs/{self.run_id}/tensors")
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            payload = {
                "name": name,
                "dtype": dtype,
                "shape": shape
            }
            if dimension_labels:
                payload["dimension_labels"] = dimension_labels
            if tag:
                payload["tag"] = tag
            response = self._session.post(url, headers=headers, json=payload)
            response.raise_for_status()

            data = response.json()
            tensor_id = data.get("tensor_id")
            with self._tensors_lock:
                if name in self.tensors:
                    self.tensors[name]["id"] = tensor_id
                else:
                    self.tensors[name] = {"id": tensor_id, "step": 0}
            return tensor_id
        except Exception as e:
            _term_log(f"Failed to create tensor '{name}': {e}")
            return None

    def _validate_tensor_size(self, name, shape, element_count, context=None):
        if element_count <= _MAX_TENSOR_ELEMENTS:
            return True

        message = f"Tensor '{name}' is too large to log: {_describe_tensor_limit(shape, element_count)}"
        if context:
            message = f"{message} {context}"
        _term_log(message)
        return False

    def log(self, tensor, name="default", dimension_labels=None, step=None, tag=None, _local_step_group=None):
        """
        Upload data for the tensor. Non-blocking - queues data for background upload.

        Args:
            tensor: The tensor data (numpy array, PyTorch tensor, or array-like)
            name: Name for this tensor
            dimension_labels: Optional list of labels for each dimension (e.g., ["batch", "height", "width"])
            step: Optional explicit step index. If omitted, gradexp auto-increments per tensor name.
            tag: Optional tag label for this tensor (e.g., "gradient_stats", "weights").
        """
        if not self.active:
            _term_log("Not initialized. Please call gradexp.init() first.")
            return

        self._maybe_log_local_backend_status()

        # Convert to numpy if needed
        if not isinstance(tensor, np.ndarray):
            # Handle PyTorch tensors
            if hasattr(tensor, 'detach') and hasattr(tensor, 'cpu'):
                try:
                    tensor = tensor.detach().cpu()
                    try:
                        tensor = tensor.numpy()
                    except (TypeError, RuntimeError):
                        # Handle dtypes numpy doesn't support (bfloat16, float8, etc.)
                        tensor = tensor.float().numpy()
                except Exception as e:
                    _term_log(f"Could not convert torch tensor to numpy: {e}")
                    return
            else:
                try:
                    tensor = np.array(tensor)
                except Exception:
                    _term_log("Could not convert input to numpy array.")
                    return

        try:
            dtype_str = self._tensor_precision
            shape_list = list(tensor.shape)
            element_count = int(tensor.size)

            if not self._validate_tensor_size(name, shape_list, element_count):
                return

            tensor_bytes = _serialize_tensor_bytes(tensor, dtype_str)

            if step is not None:
                if not isinstance(step, numbers.Integral):
                    _term_log(f"Invalid step for tensor '{name}': expected an integer, got {type(step).__name__}.")
                    return
                step = int(step)

            # Get or update step cursor (thread-safe)
            with self._tensors_lock:
                if name not in self.tensors:
                    self.tensors[name] = {"id": None, "step": 0}
                tensor_state = self.tensors[name]
                if step is None:
                    step_index = tensor_state["step"]
                    tensor_state["step"] += 1
                else:
                    step_index = step
                    tensor_state["step"] = max(tensor_state["step"], step_index + 1)

            # Enqueue for background upload (in-memory, no file I/O)
            local_step_metadata = None
            if _local_step_group and self._get_local_backend_status():
                local_step_metadata = dict(_local_step_group)
                local_step_metadata["step"] = step_index

            with self._progress_lock:
                self._total_tensors_queued += 1
                # Set upload start time when first tensor is queued (not when first batch uploads)
                if self._upload_start_time is None:
                    self._upload_start_time = time.time()
            self._upload_queue.put({
                "content": tensor_bytes,
                "name": name,
                "dtype": dtype_str,
                "shape": shape_list,
                "step": step_index,
                "dimension_labels": dimension_labels,
                "tag": tag,
                "local_step_metadata": local_step_metadata,
            })

        except Exception as e:
            _term_log(f"Failed to buffer tensor data: {e}")

    def _update_status(self, status):
        """
        Updates the status of the run.
        Uses PATCH /api/v1/runs/{run_id}
        """
        if not self.run_id or not self.api_key:
            return

        try:
            url = self._build_api_url(f"/api/v1/runs/{self.run_id}")
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            payload = {"status": status}
            response = self._session.patch(url, headers=headers, json=payload)
            response.raise_for_status()
        except Exception as e:
            _term_log(f"Failed to update session status to {status}: {e}")

    def _print_progress(self):
        """
        Prints a progress bar showing upload status and throughput.
        """
        with self._progress_lock:
            uploaded = self._tensors_uploaded
            total = self._total_tensors_queued
            bytes_up = self._bytes_uploaded
            start_time = self._upload_start_time
        
        # Calculate throughput
        if start_time and bytes_up > 0:
            elapsed = time.time() - start_time
            if elapsed > 0:
                mbps = (bytes_up / (1024 * 1024)) / elapsed
            else:
                mbps = 0.0
        else:
            mbps = 0.0
        
        # Build progress bar
        bar_width = 30
        if total > 0:
            filled = int(bar_width * uploaded / total)
        else:
            filled = 0
        bar = f"{_BAR_COLOR}{'█' * filled}{_DIM}{'░' * (bar_width - filled)}{_RESET}"

        sys.stdout.write(f"\r{GRADEXP_PREFIX}[{bar}] {uploaded}/{total} tensors | {mbps:.2f} MB/s ")
        sys.stdout.flush()

    def _handle_interrupt(self, signum, frame):
        """
        Handles SIGINT (Ctrl+C) or SIGTERM.
        """
        if not self._interrupted:
            self._interrupted = True
            q_size = self._upload_queue.qsize()
            
            if q_size == 0:
                _term_log("\nInterrupt received. No pending uploads. Shutting down...")
                self.finish("stopped")
                sys.exit(0)
            else:
                _term_log(f"\nInterrupt received. Waiting for {q_size} pending uploads to complete.")
                _term_log("Press Ctrl+C again to force quit.\n")
                
                # Show progress while waiting for uploads
                try:
                    while not self._upload_queue.empty() or (self._batcher_thread and self._batcher_thread.is_alive()) or any(t.is_alive() for t in self._uploader_threads):
                        if self._tensors_uploaded >= self._total_tensors_queued:
                            break
                        self._print_progress()
                        time.sleep(0.2)
                    self._print_progress()  # Final update
                    print()  # Newline after progress bar
                    self.finish("stopped")
                    sys.exit(0)
                except KeyboardInterrupt:
                    # Second Ctrl+C during progress display - force quit
                    _term_log("\nForce quitting...")
                    self._update_status("stopped")
                    os._exit(1)
        else:
            _term_log("\nForce quitting...")
            # Attempt a quick status update if possible, but don't block
            try:
                # Direct status update attempt to backend, skipping the queue
                # This might fail if the session is already half-closed but worth a try
                self._update_status("stopped")
            except Exception:
                pass
            os._exit(1) # Immediate exit

    def _upload_step_raw(self, tensor_id, item, cfg=None):
        if cfg is None:
            cfg = self._get_upload_config()

        url = self._build_api_url(f"/api/v1/tensors/{tensor_id}/step?step={int(item['step'])}")
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/octet-stream",
        }
        body = item["content"]
        if cfg["gzip_upload"]:
            import gzip
            body = gzip.compress(body, compresslevel=max(0, min(9, cfg["gzip_level"])))
            headers["Content-Encoding"] = "gzip"
        if item.get("local_step_metadata") and self._get_local_backend_status():
            headers["X-Gradexp-Step-Metadata"] = json.dumps(
                item["local_step_metadata"],
                separators=(",", ":"),
                ensure_ascii=False,
            )

        try:
            response = self._session.post(url, headers=headers, data=body, timeout=60)
            response.raise_for_status()
        except requests.exceptions.HTTPError as e:
            if e.response is not None and e.response.status_code == 413:
                self._upload_step_chunked(tensor_id, item, cfg=cfg)
                return
            raise

        with self._progress_lock:
            self._bytes_uploaded += len(item["content"])
            self._tensors_uploaded += 1

    def _upload_step_chunked(self, tensor_id, item, cfg=None):
        if cfg is None:
            cfg = self._get_upload_config()
        chunk_size = cfg["max_chunk_bytes"]
        data = item["content"]
        step = int(item["step"])
        total_chunks = (len(data) + chunk_size - 1) // chunk_size
        _term_log(f"step {step} too large ({len(data)} bytes), uploading in {total_chunks} chunks")

        for i in range(total_chunks):
            chunk = data[i * chunk_size : (i + 1) * chunk_size]
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/octet-stream",
            }
            if cfg["gzip_upload"]:
                import gzip
                chunk = gzip.compress(chunk, compresslevel=max(0, min(9, cfg["gzip_level"])))
                headers["Content-Encoding"] = "gzip"
            url = self._build_api_url(
                f"/api/v1/tensors/{tensor_id}/step/chunked?step={step}&chunk_index={i}&total_chunks={total_chunks}"
            )
            response = self._session.post(url, headers=headers, data=chunk, timeout=60)
            response.raise_for_status()

        with self._progress_lock:
            self._bytes_uploaded += len(data)
            self._tensors_uploaded += 1

    def _upload_batch(self, tensor_id, items, retry_on_413=True):
        """
        Upload a batch of steps for a tensor using the batch endpoint.
        If the payload is too large (413), splits into smaller batches and retries.
        """
        if not items:
            return

        url = self._build_api_url(f"/api/v1/tensors/{tensor_id}/steps")
        cfg = self._get_upload_config()
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }

        total_bytes = sum(len(item["content"]) for item in items)
        estimated_wire_bytes = estimate_batch_body_wire_bytes(items, content_key="content")
        force_raw_single_step = len(items) == 1 and estimated_wire_bytes > cfg["max_batch_bytes"]
        if force_raw_single_step:
            if cfg["debug_upload"]:
                _term_log(
                    f"single step estimated at {human_bytes(estimated_wire_bytes)} as batch; using raw upload endpoint"
                )
            try:
                self._upload_step_raw(tensor_id, items[0], cfg=cfg)
            except requests.exceptions.RequestException as e:
                _term_log(f"Failed to upload raw step ({total_bytes / (1024*1024):.2f} MB): {e}")
            except Exception as e:
                _term_log(f"Unexpected error uploading raw step ({total_bytes / (1024*1024):.2f} MB): {e}")
            return

        t_build0 = time.perf_counter()
        payload = {"steps": []}
        approx_b64_chars = 0
        for item in items:
            raw_len = len(item["content"])
            approx_b64_chars += ((raw_len + 2) // 3) * 4
            payload_item = {
                "step": item["step"],
                "value": base64.b64encode(item["content"]).decode("ascii"),
            }
            if item.get("local_step_metadata") and self._get_local_backend_status():
                payload_item["local_step_metadata"] = item["local_step_metadata"]
            payload["steps"].append(payload_item)
        t_build1 = time.perf_counter()

        body = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        t_json = time.perf_counter()

        if cfg["gzip_upload"]:
            import gzip
            body = gzip.compress(body, compresslevel=max(0, min(9, cfg["gzip_level"])))
            headers["Content-Encoding"] = "gzip"
        t_build2 = time.perf_counter()

        try:
            t_send0 = time.perf_counter()
            response = self._session.post(url, headers=headers, data=body, timeout=60)
            t_send1 = time.perf_counter()
            response.raise_for_status()

            if cfg["debug_upload"]:
                build_ms = (t_build2 - t_build0) * 1000.0
                b64_ms = (t_build1 - t_build0) * 1000.0
                json_ms = (t_json - t_build1) * 1000.0
                send_ms = (t_send1 - t_send0) * 1000.0
                wire_mb = len(body) / (1024 * 1024)
                raw_mb = total_bytes / (1024 * 1024)
                _term_log(
                    f"upload_batch steps={len(items)} raw_mb={raw_mb:.2f} approx_b64_mb={approx_b64_chars/(1024*1024):.2f} "
                    f"wire_mb={wire_mb:.2f} b64_ms={b64_ms:.1f} json_ms={json_ms:.1f} build_ms={build_ms:.1f} send_ms={send_ms:.1f}"
                )

            # Success: update progress
            with self._progress_lock:
                self._bytes_uploaded += total_bytes
                self._tensors_uploaded += len(items)

        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 413 and retry_on_413 and len(items) > 1:
                # Payload too large - split into smaller batches and retry
                mid = len(items) // 2
                _term_log(f"Batch too large ({len(items)} steps, {total_bytes / (1024*1024):.2f} MB), splitting...")
                self._upload_batch(tensor_id, items[:mid], retry_on_413=True)
                self._upload_batch(tensor_id, items[mid:], retry_on_413=True)
            elif e.response.status_code == 413 and retry_on_413 and len(items) == 1:
                try:
                    self._upload_step_raw(tensor_id, items[0], cfg=cfg)
                except requests.exceptions.RequestException as raw_error:
                    _term_log(
                        f"Failed to upload raw step after 413 ({total_bytes / (1024*1024):.2f} MB): {raw_error}"
                    )
                except Exception as raw_error:
                    _term_log(
                        f"Unexpected error uploading raw step after 413 ({total_bytes / (1024*1024):.2f} MB): {raw_error}"
                    )
            else:
                _term_log(f"Failed to upload batch of {len(items)} steps ({total_bytes / (1024*1024):.2f} MB): {e}")
        except requests.exceptions.RequestException as e:
            _term_log(f"Failed to upload batch of {len(items)} steps ({total_bytes / (1024*1024):.2f} MB): {e}")
        except Exception as e:
            _term_log(f"Unexpected error uploading batch ({total_bytes / (1024*1024):.2f} MB): {e}")

    def _batcher_worker(self):
        """
        Background worker that batches data from the queue.
        Handles lazy tensor registration to avoid blocking the main thread.
        """
        cfg = self._get_upload_config()
        BATCH_SIZE = cfg["batch_size"]
        IDLE_FLUSH_S = cfg["idle_flush_s"]
        MAX_BATCH_AGE_S = cfg["max_batch_age_s"]
        MIN_FLUSH_STEPS = cfg["min_flush_steps"]
        MIN_FLUSH_BYTES = cfg["min_flush_bytes"]
        MAX_BATCH_BYTES = cfg["max_batch_bytes"]

        # {tensor_id: {"items": [...], "bytes": int, "first_ts": float, "last_ts": float}}
        pending = {}
        # Local cache of name -> tensor_id to avoid repeated lookups
        tensor_id_cache = {}

        while True:
            # Check exit condition: stop requested, queue empty, and no pending batches
            if self._stop_event.is_set() and self._upload_queue.empty() and not pending:
                break

            try:
                item = self._upload_queue.get(timeout=0.5)

                name = item["name"]
                step = item["step"]
                content = item["content"]
                dtype = item["dtype"]
                shape = item["shape"]
                dimension_labels = item.get("dimension_labels")
                tag = item.get("tag")

                # Lazy tensor registration - only happens in background thread
                if name not in tensor_id_cache:
                    tensor_id = self._ensure_tensor_registered(name, dtype, shape, dimension_labels, tag=tag)
                    if tensor_id:
                        tensor_id_cache[name] = tensor_id
                    else:
                        # Failed to register tensor, skip this item
                        self._upload_queue.task_done()
                        continue
                else:
                    tensor_id = tensor_id_cache[name]

                now = time.time()
                if tensor_id not in pending:
                    pending[tensor_id] = {
                        "items": [],
                        "bytes": 0,
                        "wire_bytes": BATCH_JSON_PREFIX_BYTES + BATCH_JSON_SUFFIX_BYTES,
                        "first_ts": now,
                        "last_ts": now,
                    }

                item_wire_bytes = estimate_batch_item_wire_bytes(step, len(content))
                if pending[tensor_id]["items"]:
                    item_wire_bytes += BATCH_JSON_ITEM_SEPARATOR_BYTES

                pending[tensor_id]["items"].append({
                    "step": step,
                    "content": content,
                    "local_step_metadata": item.get("local_step_metadata"),
                })
                pending[tensor_id]["bytes"] += len(content)
                pending[tensor_id]["wire_bytes"] += item_wire_bytes
                pending[tensor_id]["last_ts"] = now

                self._upload_queue.task_done()

            except queue.Empty:
                pass

            # Determine if we should flush batches
            current_time = time.time()
            is_flushing = self._stop_event.is_set() and self._upload_queue.empty()

            for tensor_id in list(pending.keys()):
                batch_info = pending[tensor_id]
                batch = batch_info["items"]
                batch_bytes = batch_info["bytes"]
                batch_wire_bytes = batch_info["wire_bytes"]
                batch_age = current_time - batch_info["first_ts"]
                batch_idle = current_time - batch_info["last_ts"]
                can_flush_small = (len(batch) >= MIN_FLUSH_STEPS) or (batch_bytes >= MIN_FLUSH_BYTES)
                should_upload = (
                    len(batch) >= BATCH_SIZE or
                    batch_wire_bytes >= MAX_BATCH_BYTES or
                    (batch and is_flushing) or
                    (batch and batch_age >= MAX_BATCH_AGE_S) or
                    (batch and batch_idle >= IDLE_FLUSH_S and can_flush_small)
                )
                if should_upload:
                    self._batch_queue.put((tensor_id, batch))
                    del pending[tensor_id]

        for _ in self._uploader_threads:
            self._batch_queue.put(None)

    def _uploader_worker(self):
        """
        Background worker that uploads prepared batches.
        """
        while True:
            item = self._batch_queue.get()
            if item is None:
                self._batch_queue.task_done()
                break
            tensor_id, batch = item
            self._upload_batch(tensor_id, batch)
            self._batch_queue.task_done()

    def finish(self, status="complete"):
        """
        Marks the session as finished and flushes the upload queue.
        """
        if not self.active:
            return

        # Signal the worker to stop after processing remaining items
        self._stop_event.set()
        
        any_alive = False
        if self._batcher_thread and self._batcher_thread.is_alive():
            any_alive = True
        for t in self._uploader_threads:
            if t.is_alive():
                any_alive = True
                break

        if any_alive:
            with self._progress_lock:
                pending = self._total_tensors_queued - self._tensors_uploaded

            if pending > 0:
                _term_log("finishing... Waiting for background uploads to complete.")
                while (self._batcher_thread and self._batcher_thread.is_alive()) or any(t.is_alive() for t in self._uploader_threads):
                    if self._tensors_uploaded >= self._total_tensors_queued:
                        break
                    self._print_progress()
                    time.sleep(0.2)
                self._print_progress()
                print()

            if self._batcher_thread:
                self._batcher_thread.join()
            for t in self._uploader_threads:
                t.join()

        # Update status on backend
        self._update_status(status)

        # Restore signal handlers
        try:
            if self._original_sigint_handler:
                signal.signal(signal.SIGINT, self._original_sigint_handler)
            if self._original_sigterm_handler:
                signal.signal(signal.SIGTERM, self._original_sigterm_handler)
        except ValueError:
            pass

        self._interrupted = False
        self.active = False
        self._print_session_summary(status)

    def _print_session_summary(self, status):
        _term_log(f"Session {status}.")
        with self._tensors_lock:
            tensor_names = list(self.tensors.keys())
        with self._progress_lock:
            total_steps = self._tensors_uploaded
            total_bytes = self._bytes_uploaded
        if not tensor_names:
            return
        elapsed = time.time() - self._init_time if self._init_time else 0
        names_str = ", ".join(tensor_names[:5])
        if len(tensor_names) > 5:
            names_str += f" (+{len(tensor_names) - 5} more)"
        size_label = human_bytes(total_bytes)
        elapsed_label = f"{elapsed:.0f}s" if elapsed < 120 else f"{elapsed / 60:.1f}m"
        padding = " " * 10
        _term_log(f"{padding}Logged {len(tensor_names)} tensor{'s' if len(tensor_names) != 1 else ''} ({names_str})")
        _term_log(f"{padding}{total_steps} steps \u00b7 {size_label} uploaded \u00b7 {elapsed_label}")
        if self._run_url:
            _term_log(f"{padding}View run at {_term_link(self._run_url)}")

# Singleton instance
_client = Client()
_excepthook_installed = False

def init(project_name=None, run_name=None, precision=None):
    global _excepthook_installed
    if not _excepthook_installed:
        _excepthook_installed = True
        _original_excepthook = sys.excepthook

        def _excepthook(exc_type, value, tb):
            if _client.active:
                _client.finish("stopped")
            _original_excepthook(exc_type, value, tb)

        sys.excepthook = _excepthook
        
    try:
        _client.init(project_name=project_name, run_name=run_name, precision=precision)
    except InitExit as exit_info:
        for line in exit_info.lines:
            _term_log(line)
        raise SystemExit(exit_info.exit_code)

def log(tensor, name="default", dimension_labels=None, step=None, tag=None):
    _client.log(tensor, name=name, dimension_labels=dimension_labels, step=step, tag=tag)

def finish(status="complete"):
    _client.finish(status)

def _split_layer_string(input_string):
    """Parse layer name into (layer_num, layer_type).

    Finds the first numeric component as the layer number and uses
    the remainder as the layer type. Expands LLaMA w1/w2/w3 shorthand.
    """
    parts = input_string.split('.')

    # Find first numeric part as layer number
    layer_num = 0
    layer_num_idx = -1
    for i, part in enumerate(parts):
        if part.isdigit():
            layer_num = int(part)
            layer_num_idx = i
            break

    # Build layer type from parts after the layer number
    if layer_num_idx >= 0:
        layer_type = '.'.join(parts[layer_num_idx + 1:])
    else:
        layer_type = input_string

    # Expand LLaMA shorthand (no-op for other architectures)
    layer_type = layer_type.replace("w1", "gate_proj").replace("w2", "down_proj").replace("w3", "up_proj")

    return layer_num, layer_type

_STAT_LEVELS = {
    'min': ['grad_l2', 'l2_grad_param_ratio'],
    'default': ['grad_l2', 'grad_max', 'grad_std', 'avg_abs_grad', 'param_l2', 'l2_grad_param_ratio'],
    'full': ['grad_l2', 'grad_max', 'grad_std', 'avg_abs_grad', 'param_l2',
             'l2_grad_param_ratio', 'param_std', 'avg_grad_std_ratio'],
}

def _safe_std(t):
    return t.std().item() if t.numel() > 1 else 0.0

_STAT_COMPUTERS = {
    'grad_l2':             lambda g, p: g.norm(2).item(),
    'grad_max':            lambda g, p: g.abs().max().item(),
    'grad_std':            lambda g, p: _safe_std(g),
    'avg_abs_grad':        lambda g, p: g.abs().mean().item(),
    'param_l2':            lambda g, p: p.norm(2).item(),
    'param_std':           lambda g, p: _safe_std(p),
    'l2_grad_param_ratio': lambda g, p: (g.norm(2) / p.norm(2)).item() * 100,
    'avg_grad_std_ratio':  lambda g, p: (g.abs().mean() / _safe_std(p)) * 100 if p.numel() > 1 else 0.0,
}

def log_model_tensors(model, step=None):
    """Log raw model weights and gradient updates for a PyTorch model.

    Args:
        model: PyTorch model whose parameters should be logged.
        step: Optional explicit step index. If omitted, gradexp auto-increments per tensor name.
    """
    if step is not None:
        if not isinstance(step, numbers.Integral):
            _term_log(f"Invalid step for model tensors: expected an integer, got {type(step).__name__}.")
            return
        step = int(step)

    tensor_entries = []

    for name, param in model.named_parameters():
        tensor_entries.append((f"weights/{name}", param))

        grad = getattr(param, "grad", None)
        if grad is not None:
            tensor_entries.append((f"updates/{name}", grad))

    if not tensor_entries:
        _term_log("No model parameters found to log.")
        return

    size_context = (
        "gradexp.log_model_tensors() is only for tiny models. "
        "Use gradexp.log_gradient_stats() for larger models."
    )

    for tensor_name, tensor in tensor_entries:
        shape, element_count = _inspect_tensor_shape_and_size(tensor)
        if element_count is None:
            _term_log(f"Could not determine tensor size for '{tensor_name}'.")
            return
        if not _client._validate_tensor_size(tensor_name, shape, element_count, context=size_context):
            return

    for tensor_name, tensor in tensor_entries:
        _client.log(tensor, name=tensor_name, step=step, tag="model_tensors")

def log_gradient_stats(model, step=None, level='default', stats=None):
    """Log gradient and parameter statistics for a PyTorch model.

    Args:
        model: PyTorch model with gradients computed.
        step: Optional explicit step index. If omitted, gradexp auto-increments per stat tensor.
        level: 'min', 'default', or 'full'.
        stats: List of stat names to log, overrides level.
    """
    if isinstance(step, str):
        legacy_level = step
        legacy_stats = stats if stats is not None else level
        step = None
        level = legacy_level
        if isinstance(legacy_stats, (list, tuple)):
            stats = list(legacy_stats)
        elif legacy_stats == 'default':
            stats = None
    elif isinstance(level, (list, tuple)) and stats is None:
        stats = list(level)
        level = 'default'

    stat_names = stats if stats is not None else _STAT_LEVELS[level]
    stats_by_layer_type = {}

    for name, param in model.named_parameters():
        if param.grad is None:
            continue
        layer_num, layer_type = _split_layer_string(name)
        if layer_type not in stats_by_layer_type:
            stats_by_layer_type[layer_type] = {}
        stats_by_layer_type[layer_type][layer_num] = {
            s: _STAT_COMPUTERS[s](param.grad, param) for s in stat_names
        }

    tensor_entries = []
    for layer_type, layers_dict in stats_by_layer_type.items():
        layer_nums = sorted(layers_dict.keys())
        for stat_name in stat_names:
            values = [layers_dict[ln][stat_name] for ln in layer_nums]
            tensor_entries.append((f"{layer_type}/{stat_name}", values))

    local_step_group = _build_local_log_group("gradient_stats") if tensor_entries else None
    for tensor_name, values in tensor_entries:
        _client.log(
            values,
            name=tensor_name,
            dimension_labels=["Layer", "Step"],
            step=step,
            tag="gradient_stats",
            _local_step_group=local_step_group,
        )
