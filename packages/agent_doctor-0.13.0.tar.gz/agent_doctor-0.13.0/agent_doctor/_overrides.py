import inspect
import logging
import os
import sys
from contextlib import contextmanager

import wrapt
from opentelemetry import trace

from ._context import _overrides_var

logger = logging.getLogger(__name__)


_TRACELOOP_SUFFIXES = (".task", ".workflow", ".agent", ".tool")

# Module names to skip when walking the call stack to find the user's frame.
# sys.stdlib_module_names (Python 3.10+) covers all stdlib modules by name,
# which is more reliable than path-based checks that break in virtualenvs.
_STDLIB_MODULE_NAMES = getattr(sys, "stdlib_module_names", frozenset())
_THIS_PACKAGE = os.path.dirname(os.path.abspath(__file__))


# ── Span-name helpers ─────────────────────────────────────────────────────────


def _node_name_from_span(span_name: str) -> str:
    """Strip the traceloop kind suffix (e.g. '.task', '.workflow') so that
    callers can match by the name they passed to @task/@workflow."""
    for suffix in _TRACELOOP_SUFFIXES:
        if span_name.endswith(suffix):
            return span_name[: -len(suffix)]
    return span_name


def _is_traceloop_span(span_name: str) -> bool:
    """Return True if this span was created by a Traceloop @task/@workflow decorator."""
    return any(span_name.endswith(s) for s in _TRACELOOP_SUFFIXES)


# ── Call-site inference ───────────────────────────────────────────────────────


def _infer_node_name() -> str:
    """Walk the call stack and return 'module.function_name:lineno' for the
    first user frame (skipping SDK internals, site-packages, and stdlib).

    Including the module name prevents collisions when two different files
    define functions with the same name.
    """
    for frame_info in inspect.stack():
        filename = frame_info.filename
        if not filename or filename.startswith("<"):
            continue
        if "site-packages" in filename:
            continue
        if filename.startswith(_THIS_PACKAGE):
            continue
        # Skip stdlib by module name — more reliable than path checks in venvs.
        module_name = frame_info.frame.f_globals.get("__name__", "")
        top_module = module_name.split(".")[0]
        if top_module in _STDLIB_MODULE_NAMES:
            continue
        # Use filename stem for __main__ so the name stays readable.
        if module_name == "__main__":
            short_module = os.path.splitext(os.path.basename(filename))[0]
        else:
            short_module = module_name.split(".")[-1]
        return f"{short_module}.{frame_info.function}:{frame_info.lineno}"
    return "node_unknown"


# ── Synthetic span context manager ────────────────────────────────────────────


@contextmanager
def _node_span():
    """Ensure an active, recording span exists for override matching.

    - If a recording span is already active (e.g. from @task/@workflow or
      any user-created span), yield immediately — no new span is created.
    - If no recording span is active (undecorated code), create a minimal
      span named 'function:lineno' inferred from the user's call site.
      This span is exported and stored by Django as the Node name, making
      override targeting possible without requiring @task decorators.
    """
    span = trace.get_current_span()
    if span.is_recording():
        yield
    else:
        node_name = _infer_node_name()
        with trace.get_tracer(__name__).start_as_current_span(node_name):
            yield


# ── Override lookup ───────────────────────────────────────────────────────────


def _get_node_overrides():
    """Match the current OTel span name against overrides stored in the contextvar."""
    all_overrides = _overrides_var.get(None)
    if not all_overrides:
        return None
    span = trace.get_current_span()
    if not span or not span.is_recording():
        return None
    node_name = _node_name_from_span(span.name)
    if isinstance(all_overrides, list):
        return next((o for o in all_overrides if o.get("node_name") == node_name), None)
    if isinstance(all_overrides, dict):
        return all_overrides.get(node_name)
    return None


# ── Shared span-logging helper (OpenAI / Anthropic) ──────────────────────────


def _log_span_attributes(span, kwargs, override_keys=()):
    """Stamp gen_ai.request.* attributes on the active span.

    Logs the effective value for each field — either the overridden value
    (already applied to kwargs) or the original value passed by the caller.
    """
    if not span.is_recording():
        return
    for attr, kwarg_key in (
        ("gen_ai.request.temperature", "temperature"),
        ("gen_ai.request.top_p", "top_p"),
        ("gen_ai.request.max_tokens", "max_tokens"),
    ):
        value = kwargs.get(kwarg_key)
        if value is not None:
            span.set_attribute(attr, value)
    if "model" in override_keys and kwargs.get("model"):
        span.set_attribute("gen_ai.request.model_override", kwargs["model"])
    if "user_prompt" in override_keys:
        messages = kwargs.get("messages") or []
        last_user = next((m["content"] for m in reversed(messages) if m.get("role") == "user"), None)
        if last_user:
            span.set_attribute("gen_ai.request.user_prompt_override", last_user)


# ── Google GenAI helpers ──────────────────────────────────────────────────────


def _log_baseline_google(kwargs):
    """Log baseline config values on the active span (no-override path)."""
    config = kwargs.get("config")
    if config is None:
        return
    span = trace.get_current_span()
    if not span.is_recording():
        return
    if getattr(config, "temperature", None) is not None:
        span.set_attribute("gen_ai.request.temperature", config.temperature)
    if getattr(config, "top_p", None) is not None:
        span.set_attribute("gen_ai.request.top_p", config.top_p)
    if getattr(config, "max_output_tokens", None) is not None:
        span.set_attribute("gen_ai.request.max_tokens", config.max_output_tokens)


def _prepare_google_kwargs(overrides, kwargs):
    """Apply Google-specific overrides to kwargs in-place and log on active span."""
    config = kwargs.get("config")
    if config is None:
        from google.genai import types
        config = types.GenerateContentConfig()
        kwargs["config"] = config

    if "temperature" in overrides:
        config.temperature = overrides["temperature"]
    if "prompt" in overrides:
        config.system_instruction = overrides["prompt"]
    if "top_p" in overrides:
        config.top_p = overrides["top_p"]
    if "max_tokens" in overrides:
        config.max_output_tokens = overrides["max_tokens"]
    if "user_prompt" in overrides:
        kwargs["contents"] = overrides["user_prompt"]
    if "model" in overrides:
        kwargs["model"] = overrides["model"]

    span = trace.get_current_span()
    if span.is_recording():
        if "temperature" in overrides:
            span.set_attribute("gen_ai.request.temperature", overrides["temperature"])
        if "top_p" in overrides:
            span.set_attribute("gen_ai.request.top_p", overrides["top_p"])
        if "max_tokens" in overrides:
            span.set_attribute("gen_ai.request.max_tokens", overrides["max_tokens"])
        if "model" in overrides:
            span.set_attribute("gen_ai.request.model_override", overrides["model"])
        if "user_prompt" in overrides:
            span.set_attribute("gen_ai.request.user_prompt_override", overrides["user_prompt"])


# ── OpenAI helpers ────────────────────────────────────────────────────────────


def _prepare_openai_kwargs(overrides, kwargs):
    """Apply OpenAI-specific overrides to kwargs in-place."""
    for key in ("temperature", "top_p", "max_tokens", "model"):
        if key in overrides:
            kwargs[key] = overrides[key]

    if "prompt" in overrides:
        messages = list(kwargs.get("messages") or [])
        if messages and messages[0].get("role") == "system":
            messages[0] = {**messages[0], "content": overrides["prompt"]}
        else:
            messages.insert(0, {"role": "system", "content": overrides["prompt"]})
        kwargs["messages"] = messages

    if "user_prompt" in overrides:
        messages = list(kwargs.get("messages") or [])
        for i in range(len(messages) - 1, -1, -1):
            if messages[i].get("role") == "user":
                messages[i] = {**messages[i], "content": overrides["user_prompt"]}
                break
        else:
            messages.append({"role": "user", "content": overrides["user_prompt"]})
        kwargs["messages"] = messages


# ── Anthropic helpers ─────────────────────────────────────────────────────────


def _prepare_anthropic_kwargs(overrides, kwargs):
    """Apply Anthropic-specific overrides to kwargs in-place."""
    for key in ("temperature", "top_p", "max_tokens", "model"):
        if key in overrides:
            kwargs[key] = overrides[key]

    if "prompt" in overrides:
        kwargs["system"] = overrides["prompt"]

    if "user_prompt" in overrides:
        messages = list(kwargs.get("messages") or [])
        for i in range(len(messages) - 1, -1, -1):
            if messages[i].get("role") == "user":
                messages[i] = {**messages[i], "content": overrides["user_prompt"]}
                break
        else:
            messages.append({"role": "user", "content": overrides["user_prompt"]})
        kwargs["messages"] = messages


# ── Google GenAI ──────────────────────────────────────────────────────────────


def _apply_overrides_google(wrapped, instance, args, kwargs):
    with _node_span():
        overrides = _get_node_overrides()
        if not overrides:
            _log_baseline_google(kwargs)
            return wrapped(*args, **kwargs)
        _prepare_google_kwargs(overrides, kwargs)
        return wrapped(*args, **kwargs)


async def _apply_overrides_google_async(wrapped, instance, args, kwargs):
    with _node_span():
        overrides = _get_node_overrides()
        if not overrides:
            _log_baseline_google(kwargs)
            return await wrapped(*args, **kwargs)
        _prepare_google_kwargs(overrides, kwargs)
        return await wrapped(*args, **kwargs)


# ── OpenAI ────────────────────────────────────────────────────────────────────


def _apply_overrides_openai(wrapped, instance, args, kwargs):
    with _node_span():
        overrides = _get_node_overrides()
        span = trace.get_current_span()
        if not overrides:
            _log_span_attributes(span, kwargs)
            return wrapped(*args, **kwargs)
        _prepare_openai_kwargs(overrides, kwargs)
        _log_span_attributes(span, kwargs, override_keys=overrides.keys())
        return wrapped(*args, **kwargs)


async def _apply_overrides_openai_async(wrapped, instance, args, kwargs):
    with _node_span():
        overrides = _get_node_overrides()
        span = trace.get_current_span()
        if not overrides:
            _log_span_attributes(span, kwargs)
            return await wrapped(*args, **kwargs)
        _prepare_openai_kwargs(overrides, kwargs)
        _log_span_attributes(span, kwargs, override_keys=overrides.keys())
        return await wrapped(*args, **kwargs)


# ── Anthropic ─────────────────────────────────────────────────────────────────


def _apply_overrides_anthropic(wrapped, instance, args, kwargs):
    with _node_span():
        overrides = _get_node_overrides()
        span = trace.get_current_span()
        if not overrides:
            _log_span_attributes(span, kwargs)
            return wrapped(*args, **kwargs)
        _prepare_anthropic_kwargs(overrides, kwargs)
        _log_span_attributes(span, kwargs, override_keys=overrides.keys())
        return wrapped(*args, **kwargs)


async def _apply_overrides_anthropic_async(wrapped, instance, args, kwargs):
    with _node_span():
        overrides = _get_node_overrides()
        span = trace.get_current_span()
        if not overrides:
            _log_span_attributes(span, kwargs)
            return await wrapped(*args, **kwargs)
        _prepare_anthropic_kwargs(overrides, kwargs)
        _log_span_attributes(span, kwargs, override_keys=overrides.keys())
        return await wrapped(*args, **kwargs)


# ── Install hooks ─────────────────────────────────────────────────────────────

_HOOKS = [
    # sync
    ("google.genai.models", "Models.generate_content", _apply_overrides_google),
    ("openai.resources.chat.completions", "Completions.create", _apply_overrides_openai),
    ("anthropic.resources.messages", "Messages.create", _apply_overrides_anthropic),
    # async
    ("google.genai.models", "AsyncModels.generate_content", _apply_overrides_google_async),
    ("openai.resources.chat.completions", "AsyncCompletions.create", _apply_overrides_openai_async),
    ("anthropic.resources.messages", "AsyncMessages.create", _apply_overrides_anthropic_async),
]


def install_override_hooks():
    """Wrap LLM SDK methods (after LLMetry has already wrapped them) to inject overrides."""
    for module, method, wrapper in _HOOKS:
        try:
            wrapt.wrap_function_wrapper(module, method, wrapper)
            logger.debug("Override hook installed: %s.%s", module, method)
        except (ImportError, AttributeError):
            logger.debug("Skipping override hook (not installed): %s.%s", module, method)
