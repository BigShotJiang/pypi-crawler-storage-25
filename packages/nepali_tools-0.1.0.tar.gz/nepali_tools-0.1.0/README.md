# Nepali Tools

A Python package designed to provide a collection of useful, fun, and smart tools with a focus on Nepali users, while also offering general utilities for global use.

## Features

This package aims to be simple, clean, and beginner-friendly, offering a variety of tools across different categories:

### 💰 Finance Tools
- **Interest Calculation**: Simple interest calculation.
- **EMI Calculation**: Equated Monthly Installment calculation.
- **Currency Formatting**: Format numbers into Nepali Rupees.

### 📅 Date Tools
- **AD to BS Conversion**: Basic conversion from Anno Domini (AD) to Bikram Sambat (BS) dates (simplified).
- **Date Utilities**: Basic date-related functionalities.

### ✍️ Text Tools
- **Roman to Nepali**: Convert Romanized Nepali text to Devanagari script (basic).
- **Text Cleaning**: Simple text cleaning functionalities.

### 😂 Fun Tools
- **Jokes**: Generate random Nepali jokes.
- **Meme Ideas**: Generate creative meme ideas.
- **Funny Generators**: Generate funny excuses.

### 🎮 Gamer Tools
- **Username Generator**: Create unique gamer usernames.
- **Stylish Text**: Convert text to a stylish, gamer-like format.
- **Clan Names**: Generate cool clan names.

### 🚀 Viral Tools
- **Captions**: Generate viral-style captions for social media.
- **Hashtags**: Generate relevant and trending hashtags.
- **Titles**: Create catchy, viral titles.

### 🛠️ Utility Tools
- **Password Generator**: Generate strong, random passwords.
- **OTP Generator**: Generate One-Time Passwords.
- **Random Generator**: Generate random strings.

### 🧠 Smart Features (Basic Logic)
- **Auto Reply Generator**: Generate simple auto-replies based on message content.
- **Personality Generator**: Generate random personality descriptions.
- **Motivation Generator**: Generate motivational quotes.

## Installation

```bash
pip install nepali_tools
```

## Usage

Here are some basic examples of how to use the `nepali_tools` package:

```python
import nepali_tools as nt

# Finance Tools
interest = nt.calculate_simple_interest(10000, 5, 2)
print(f"Simple Interest: {interest}")

emi = nt.calculate_emi(500000, 10, 60)
print(f"EMI: {emi:.2f}")

formatted_currency = nt.format_currency_nepali(1234567.89)
print(f"Formatted Currency: {formatted_currency}")

# Date Tools
bs_date = nt.ad_to_bs_simple(2023, 4, 5)
print(f"AD to BS (approx): {bs_date}")

current_ad = nt.get_current_ad_date()
print(f"Current AD Date: {current_ad}")

# Text Tools
nepali_script = nt.roman_to_nepali_script("namaste nepal")
print(f"Roman to Nepali: {nepali_script}")

cleaned_text = nt.clean_text("  Hello   World!  ")
print(f"Cleaned Text: {cleaned_text}")

# Fun Tools
joke = nt.get_nepali_joke()
print(f"Nepali Joke: {joke}")

# Gamer Tools
username = nt.generate_gamer_username()
print(f"Gamer Username: {username}")

# Viral Tools
caption = nt.generate_caption("travel")
print(f"Viral Caption: {caption}")

# Utility Tools
password = nt.generate_password()
print(f"Generated Password: {password}")

# Smart Features
reply = nt.generate_auto_reply("Hi, how are you?")
print(f"Auto Reply: {reply}")
```

## Developer Credit

Made by [@gunpark_xd (diwas)](https://github.com/gunpark-xd)

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details. (To be created)
