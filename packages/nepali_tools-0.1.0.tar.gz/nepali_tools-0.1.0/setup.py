from setuptools import setup, find_packages

setup(
    name='nepali_tools',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[
        # No external dependencies for now, but can be added here later
    ],
    author='@gunpark_xd (diwas)',
    author_email='your.email@example.com', # Placeholder, replace with actual email if desired
    description='A Python package with useful, fun, and smart tools focused on Nepali users and general global use.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/gunpark-xd/nepali_tools', # Placeholder, will be updated after repo creation
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: Utilities',
    ],
    python_requires='>=3.6',
)
