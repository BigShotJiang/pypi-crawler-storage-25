"""Text utilities for Nepali and general text manipulation.
"""

def roman_to_nepali_script(text):
    """
    Converts Romanized Nepali text to Devanagari (Nepali script).
    This is a very basic, rule-based conversion and will not be perfect for all cases.

    Args:
        text (str): Romanized Nepali text.

    Returns:
        str: Converted Nepali script text.
    """
    mapping = {
        'a': 'अ', 'aa': 'आ', 'i': 'इ', 'ee': 'ई', 'u': 'उ', 'oo': 'ऊ', 'ri': 'ऋ',
        'e': 'ए', 'ai': 'ऐ', 'o': 'ओ', 'au': 'औ',
        'ka': 'क', 'kha': 'ख', 'ga': 'ग', 'gha': 'घ', 'nga': 'ङ',
        'cha': 'च', 'chha': 'छ', 'ja': 'ज', 'jha': 'झ', 'nya': 'ञ',
        'ta': 'ट', 'tha': 'ठ', 'da': 'ड', 'dha': 'ढ', 'na': 'ण',
        'Ta': 'त', 'Tha': 'थ', 'Da': 'द', 'Dha': 'ध', 'Na': 'न',
        'pa': 'प', 'pha': 'फ', 'ba': 'ब', 'bha': 'भ', 'ma': 'म',
        'ya': 'य', 'ra': 'र', 'la': 'ल', 'va': 'व', 'sha': 'श', 'Sha': 'ष', 'sa': 'स', 'ha': 'ह',
        'ksha': 'क्ष', 'tra': 'त्र', 'gya': 'ज्ञ',
        '0': '०', '1': '१', '2': '२', '3': '३', '4': '४', '5': '५', '6': '६', '7': '७', '8': '८', '9': '९',
        ' ': ' ',
        # Add more complex mappings or common words for better accuracy
    }

    # Simple replacement, order matters for multi-character mappings
    # Sort keys by length in descending order to handle 'aa' before 'a'
    sorted_keys = sorted(mapping.keys(), key=len, reverse=True)

    result = text.lower()
    for roman, nepali in mapping.items():
        result = result.replace(roman, nepali)

    return result

def clean_text(text):
    """
    Performs basic text cleaning (removes extra spaces, converts to lowercase).

    Args:
        text (str): The input text.

    Returns:
        str: Cleaned text.
    """
    if not isinstance(text, str):
        raise ValueError("Input must be a string.")
    return ' '.join(text.split()).lower()

# Example Usage:
if __name__ == "__main__":
    print("--- Text Tools Examples ---")
    # Roman to Nepali
    roman_text = "mero naam diwas ho"
    nepali_text = roman_to_nepali_script(roman_text)
    print(f"Roman '{roman_text}' to Nepali: {nepali_text}")

    roman_text_complex = "namaste nepal"
    nepali_text_complex = roman_to_nepali_script(roman_text_complex)
    print(f"Roman '{roman_text_complex}' to Nepali: {nepali_text_complex}")

    # Text Cleaning
    dirty_text = "  Hello   World!   This is a TEST.  "
    cleaned = clean_text(dirty_text)
    print(f"Cleaned text '{dirty_text}': '{cleaned}'")
