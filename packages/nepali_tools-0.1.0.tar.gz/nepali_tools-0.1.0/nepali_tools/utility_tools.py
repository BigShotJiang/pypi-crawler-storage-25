"""Utility tools for password, OTP, and random generation.
"""

import random
import string

def generate_password(length=12, include_symbols=True, include_numbers=True):
    """
    Generates a random password.

    Args:
        length (int): The desired length of the password.
        include_symbols (bool): Whether to include symbols in the password.
        include_numbers (bool): Whether to include numbers in the password.

    Returns:
        str: A randomly generated password.
    """
    if length < 4:
        raise ValueError("Password length must be at least 4.")

    characters = string.ascii_letters
    if include_numbers:
        characters += string.digits
    if include_symbols:
        characters += string.punctuation

    if not characters:
        raise ValueError("No character types selected for password generation.")

    password = "".join(random.choice(characters) for _ in range(length))
    return password

def generate_otp(length=6):
    """
    Generates a One-Time Password (OTP).

    Args:
        length (int): The desired length of the OTP.

    Returns:
        str: A randomly generated OTP.
    """
    if length < 1:
        raise ValueError("OTP length must be at least 1.")
    return "".join(random.choice(string.digits) for _ in range(length))

def generate_random_string(length=10, chars=string.ascii_letters + string.digits):
    """
    Generates a random string of specified length and character set.

    Args:
        length (int): The desired length of the string.
        chars (str): The set of characters to choose from.

    Returns:
        str: A randomly generated string.
    """
    if length < 1:
        raise ValueError("String length must be at least 1.")
    if not chars:
        raise ValueError("Character set cannot be empty.")
    return "".join(random.choice(chars) for _ in range(length))

# Example Usage:
if __name__ == "__main__":
    print("--- Utility Tools Examples ---")
    print(f"Generated Password: {generate_password()}")
    print(f"Generated Password (no symbols): {generate_password(include_symbols=False)}")
    print(f"Generated OTP: {generate_otp()}")
    print(f"Generated Random String: {generate_random_string(length=15)}")
