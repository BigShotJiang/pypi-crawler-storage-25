"""Finance tools for Nepali users and general global use.
"""

def calculate_simple_interest(principal, rate, time):
    """
    Calculates simple interest.

    Args:
        principal (float): The initial amount of money.
        rate (float): The annual interest rate (as a percentage).
        time (float): The time the money is borrowed or invested for, in years.

    Returns:
        float: The calculated simple interest.
    """
    if not all(isinstance(arg, (int, float)) and arg >= 0 for arg in [principal, rate, time]):
        raise ValueError("All inputs must be non-negative numbers.")
    return (principal * rate * time) / 100

def calculate_emi(principal, annual_interest_rate, tenure_months):
    """
    Calculates Equated Monthly Installment (EMI).

    Args:
        principal (float): The total amount of the loan.
        annual_interest_rate (float): The annual interest rate (as a percentage).
        tenure_months (int): The loan tenure in months.

    Returns:
        float: The calculated EMI.
    """
    if not all(isinstance(arg, (int, float)) and arg >= 0 for arg in [principal, annual_interest_rate, tenure_months]):
        raise ValueError("All inputs must be non-negative numbers.")
    if annual_interest_rate == 0:
        return principal / tenure_months

    monthly_interest_rate = (annual_interest_rate / 12) / 100
    emi = principal * monthly_interest_rate * ((1 + monthly_interest_rate)**tenure_months) / (((1 + monthly_interest_rate)**tenure_months) - 1)
    return emi

def format_currency_nepali(amount):
    """
    Formats a number as Nepali currency (Rupees).

    Args:
        amount (float or int): The amount to format.

    Returns:
        str: The formatted currency string.
    """
    if not isinstance(amount, (int, float)):
        raise ValueError("Amount must be a number.")
    return f"Rs. {amount:,.2f}"

# Example Usage:
if __name__ == "__main__":
    print("--- Finance Tools Examples ---")
    # Simple Interest
    principal_si = 10000
    rate_si = 5
    time_si = 2
    interest = calculate_simple_interest(principal_si, rate_si, time_si)
    print(f"Simple Interest for Principal {principal_si}, Rate {rate_si}%, Time {time_si} years: {interest}")

    # EMI Calculation
    principal_emi = 500000
    annual_rate_emi = 10
    tenure_emi = 60
    emi = calculate_emi(principal_emi, annual_rate_emi, tenure_emi)
    print(f"EMI for Principal {principal_emi}, Annual Rate {annual_rate_emi}%, Tenure {tenure_emi} months: {emi:.2f}")

    # Currency Formatting
    amount_format = 1234567.89
    formatted_amount = format_currency_nepali(amount_format)
    print(f"Formatted Nepali Currency for {amount_format}: {formatted_amount}")

    amount_format_int = 50000
    formatted_amount_int = format_currency_nepali(amount_format_int)
    print(f"Formatted Nepali Currency for {amount_format_int}: {formatted_amount_int}")
