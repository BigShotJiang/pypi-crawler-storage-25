from .finance import calculate_simple_interest, calculate_emi, format_currency_nepali
from .date_utils import ad_to_bs_simple, get_current_ad_date
from .text_utils import roman_to_nepali_script, clean_text
from .fun_tools import get_nepali_joke, generate_meme_idea, generate_funny_excuse
from .gamer_tools import generate_gamer_username, to_stylish_text, generate_clan_name
from .viral_tools import generate_caption, generate_hashtags, generate_viral_title
from .utility_tools import generate_password, generate_otp, generate_random_string
from .smart_features import generate_auto_reply, generate_personality, generate_motivation

__all__ = [
    # Finance Tools
    "calculate_simple_interest",
    "calculate_emi",
    "format_currency_nepali",
    # Date Tools
    "ad_to_bs_simple",
    "get_current_ad_date",
    # Text Tools
    "roman_to_nepali_script",
    "clean_text",
    # Fun Tools
    "get_nepali_joke",
    "generate_meme_idea",
    "generate_funny_excuse",
    # Gamer Tools
    "generate_gamer_username",
    "to_stylish_text",
    "generate_clan_name",
    # Viral Tools
    "generate_caption",
    "generate_hashtags",
    "generate_viral_title",
    # Utility Tools
    "generate_password",
    "generate_otp",
    "generate_random_string",
    # Smart Features
    "generate_auto_reply",
    "generate_personality",
    "generate_motivation",
]

__version__ = "0.1.0"
__author__ = "@gunpark_xd (diwas)"
