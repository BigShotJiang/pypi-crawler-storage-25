"""Viral tools for generating captions, hashtags, and titles.
"""

import random

def generate_caption(topic="general"):
    """
    Generates a viral-style caption based on a topic.

    Args:
        topic (str): The topic for the caption (e.g., "travel", "food", "motivation").

    Returns:
        str: A viral caption.
    """
    captions = {
        "general": [
            "Vibes speak louder than words. ✨",
            "Living my best life, one moment at a time.",
            "Making memories all over the world.",
            "Good times and tan lines.",
            "Lost in the right direction."
        ],
        "travel": [
            "Wander often, wonder always. ✈️",
            "Collecting moments, not things.",
            "Adventure awaits!",
            "Passport ready, heart open.",
            "Exploring the world, one city at a time."
        ],
        "food": [
            "Food is my love language. 🍔🍟",
            "Eating my way through life.",
            "Savoring every bite.",
            "Good food, good mood.",
            "Taste the adventure."
        ],
        "motivation": [
            "Dream big, work hard, stay focused. 💪",
            "Your only limit is you.",
            "Believe you can and you\"re halfway there.",
            "Hustle until your haters ask if you\"re hiring.",
            "Success is not final, failure is not fatal: it is the courage to continue that counts."
        ]
    }
    return random.choice(captions.get(topic.lower(), captions["general"]))

def generate_hashtags(keywords, count=5):
    """
    Generates a list of viral-style hashtags based on keywords.

    Args:
        keywords (list): A list of keywords related to the content.
        count (int): The number of hashtags to generate.

    Returns:
        list: A list of hashtags.
    """
    if not isinstance(keywords, list) or not all(isinstance(k, str) for k in keywords):
        raise ValueError("Keywords must be a list of strings.")

    base_hashtags = ["#viral", "#trending", "#explorepage", "#instadaily", "#reels", "#fyp", "#foryou"]
    generated = []
    for keyword in keywords:
        generated.append(f"#{keyword.replace(\' \', \'\').lower()}")
    generated.extend(random.sample(base_hashtags, min(count - len(generated), len(base_hashtags))))
    return generated[:count]

def generate_viral_title(subject):
    """
    Generates a viral-style title for a given subject.

    Args:
        subject (str): The subject of the title.

    Returns:
        str: A viral title.
    """
    templates = [
        f"You Won\"t Believe What Happened When I {subject}",
        f"The Ultimate Guide to {subject}: Everything You Need to Know",
        f"{subject} Secrets Revealed: What They Don\"t Want You to Know",
        f"I Tried {subject} for 30 Days and Here\"s What Happened",
        f"Why Everyone Is Talking About {subject} Right Now"
    ]
    return random.choice(templates)

# Example Usage:
if __name__ == "__main__":
    print("--- Viral Tools Examples ---")
    print(f"Generated Caption (general): {generate_caption()}")
    print(f"Generated Caption (travel): {generate_caption(\'travel\')}")
    print(f"Generated Hashtags for [\'nepal\', \'mountains\']: {generate_hashtags([\'nepal\', \'mountains\'])}")
    print(f"Generated Viral Title for \'Making Money Online\': {generate_viral_title(\'Making Money Online\')}")
