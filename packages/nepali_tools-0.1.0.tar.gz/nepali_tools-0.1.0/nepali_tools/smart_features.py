"""Smart features using basic logic for auto-reply, personality, and motivation generation.
"""

import random

def generate_auto_reply(message):
    """
    Generates a simple auto-reply based on keywords in the message.

    Args:
        message (str): The incoming message.

    Returns:
        str: An auto-generated reply.
    """
    message = message.lower()
    if "hello" in message or "hi" in message:
        return "Hello there! How can I help you today?"
    elif "how are you" in message:
        return "I\"m doing great, thank you for asking! How about you?"
    elif "help" in message or "support" in message:
        return "I\"m here to help! Please describe your issue in more detail."
    elif "thank you" in message or "thanks" in message:
        return "You\"re most welcome! Glad I could assist."
    elif "bye" in message or "goodbye" in message:
        return "Goodbye! Have a great day!"
    else:
        return "I received your message and will get back to you shortly."

def generate_personality():
    """
    Generates a random personality trait or description.

    Returns:
        str: A personality description.
    """
    traits = [
        "You are a creative and imaginative individual, always looking for new ideas.",
        "You are a natural leader, confident and decisive.",
        "You are a compassionate and empathetic soul, always ready to help others.",
        "You are an adventurous spirit, eager to explore new places and experiences.",
        "You are a logical and analytical thinker, valuing reason and facts."
    ]
    return random.choice(traits)

def generate_motivation():
    """
    Generates a random motivational quote or message.

    Returns:
        str: A motivational message.
    """
    motivations = [
        "Believe you can and you\"re halfway there. - Theodore Roosevelt",
        "The only way to do great work is to love what you do. - Steve Jobs",
        "Success is not final, failure is not fatal: it is the courage to continue that counts. - Winston Churchill",
        "The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt",
        "It always seems impossible until it\"s done. - Nelson Mandela"
    ]
    return random.choice(motivations)

# Example Usage:
if __name__ == "__main__":
    print("--- Smart Features Examples ---")
    print(f"Auto-reply for \"Hello\": {generate_auto_reply(\"Hello\")}")
    print(f"Auto-reply for \"I need help\": {generate_auto_reply(\"I need help with my account.\")}")
    print(f"Generated Personality: {generate_personality()}")
    print(f"Generated Motivation: {generate_motivation()}")
