"""Date utilities for Nepali users, including AD to BS conversion.
"""

import datetime

# This is a simplified mapping for demonstration. A real implementation would need a comprehensive mapping table.
# For accurate AD to BS conversion, a robust library or a detailed mapping is# required.
# This example assumes a fixed offset for simplicity, which is NOT accurate for all dates.
# A proper implementation would involve a lookup table or a more complex algorithm.

def ad_to_bs_simple(ad_year, ad_month, ad_day):
    """
    Converts AD date to BS date using a simplified, approximate method.
    This is for demonstration and not fully accurate for all dates.

    Args:
        ad_year (int): AD year.
        ad_month (int): AD month.
        ad_day (int): AD day.

    Returns:
        str: Approximate BS date in YYYY-MM-DD format.
    """
    try:
        ad_date = datetime.date(ad_year, ad_month, ad_day)
    except ValueError:
        return "Invalid AD date provided."

    # Approximate offset: Nepali calendar (Bikram Sambat) is roughly 56 years, 8 months, 17 days ahead of AD.
    # This is a simplification and not precise for all dates due to varying month lengths and leap years.
    bs_year = ad_year + 56
    bs_month = ad_month + 8
    bs_day = ad_day + 17

    # Basic adjustments for month and day overflow (very simplified)
    if bs_day > 30: # Assuming average 30 days a month for simplicity
        bs_day -= 30
        bs_month += 1
    if bs_month > 12:
        bs_month -= 12
        bs_year += 1

    return f"{bs_year}-{bs_month:02d}-{bs_day:02d}"

def get_current_ad_date():
    """
    Returns the current AD date.

    Returns:
        str: Current AD date in YYYY-MM-DD format.
    """
    return datetime.date.today().strftime("%Y-%m-%d")

# Example Usage:
if __name__ == "__main__":
    print("--- Date Tools Examples ---")
    # AD to BS Conversion (simplified)
    ad_year_ex, ad_month_ex, ad_day_ex = 2023, 4, 5
    bs_date_approx = ad_to_bs_simple(ad_year_ex, ad_month_ex, ad_day_ex)
    print(f"AD {ad_year_ex}-{ad_month_ex:02d}-{ad_day_ex:02d} (approx) in BS: {bs_date_approx}")

    # Get Current AD Date
    current_ad = get_current_ad_date()
    print(f"Current AD Date: {current_ad}")
