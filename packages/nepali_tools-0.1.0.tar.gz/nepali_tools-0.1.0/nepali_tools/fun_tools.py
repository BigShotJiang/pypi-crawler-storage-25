"""Fun tools for jokes, meme ideas, and funny generators.
"""

import random

def get_nepali_joke():
    """
    Returns a random Nepali-themed joke.

    Returns:
        str: A Nepali joke.
    """
    jokes = [
        "शिक्षक: तिमी ठूलो भएर के बन्छौ ? विद्यार्थी: म ठूलो भएर पाइलट बन्छु। शिक्षक: अनि सानो भएर के बन्छौ ?",
        "डाक्टर: तपाईँलाई आराम चाहिएको छ। बिरामी: आरामले के हुन्छ र डाक्टर साब? डाक्टर: आरामले तपाईँको बिल बढ्छ।",
        "एकजनाले अर्कोलाई सोध्यो, \'तिम्रो नाम के हो?\' अर्कोले भन्यो, \'मेरो नाम \'म\' हो।\' पहिलोले भन्यो, \'म त \'म\' होइन, \'म\' त \'म\' हो।\'
    ]
    return random.choice(jokes)

def generate_meme_idea():
    """
    Generates a random meme idea.

    Returns:
        str: A meme idea.
    """
    subjects = ["Nepali student", "Kathmandu traffic", "Dal Bhat Tarkari", "Election promises", "Loadshedding"]
    situations = ["trying to study for exams", "when the internet is slow", "after eating too much", "waiting for development", "during unexpected power cuts"]
    reactions = ["confused face", "crying inside", "happy dance", "facepalm", "shocked Pikachu"]
    return f"Meme idea: {random.choice(subjects)} {random.choice(situations)} - {random.choice(reactions)} meme."

def generate_funny_excuse():
    """
    Generates a funny, random excuse.

    Returns:
        str: A funny excuse.
    """
    excuses = [
        "My pet goat ate my homework.",
        "I was abducted by aliens and they needed my help with their intergalactic taxes.",
        "My alarm clock decided to go on strike this morning.",
        "I accidentally joined a flash mob and couldn\'t leave.",
        "A squirrel stole my car keys and demanded a ransom of nuts."
    ]
    return random.choice(excuses)

# Example Usage:
if __name__ == "__main__":
    print("--- Fun Tools Examples ---")
    print(f"Nepali Joke: {get_nepali_joke()}")
    print(f"Meme Idea: {generate_meme_idea()}")
    print(f"Funny Excuse: {generate_funny_excuse()}")
