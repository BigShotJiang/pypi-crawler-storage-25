"""Manifest loaders, aspect queries, and stateless helpers.

This is the dependency root of the kanon package — pure reads from kit
YAML manifests with no side effects except caching.
"""

from __future__ import annotations

import re
import string
from collections.abc import Iterator
from datetime import datetime, timezone
from functools import cache, lru_cache
from pathlib import Path
from typing import Any

import click
import yaml

import kanon


def _load_yaml(path: Path, expected_type: type = dict) -> Any:
    """Load a YAML file and validate its top-level type.

    Wraps ``yaml.safe_load`` so that parse errors produce a clear
    :class:`click.ClickException` instead of a raw ``yaml.YAMLError``
    traceback.
    """
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except yaml.YAMLError as exc:
        raise click.ClickException(f"Invalid YAML in {path}: {exc}") from None
    if not isinstance(data, expected_type):
        type_name = "mapping" if expected_type is dict else expected_type.__name__
        raise click.ClickException(
            f"Malformed {path}: expected a YAML {type_name}."
        )
    return data


# Files the CLI always synthesizes (not sourced from any aspect's files/ tree).
_ALWAYS_SYNTHESIZED = ("AGENTS.md", ".kanon/config.yaml")

# Section names that stay unprefixed in AGENTS.md markers (cross-aspect by design).
_UNPREFIXED_SECTIONS = frozenset({"protocols-index"})

# Marker grammar — line-anchored (whitespace tolerated either side) so that a
# quoted marker inside user prose, an inline-code span, or a fenced code block
# is never mistaken for kit-managed content.
_MARKER_RE = re.compile(
    r"^[ \t]*<!-- kanon:(begin|end):([a-z0-9/_-]+) -->[ \t]*$",
    re.MULTILINE,
)
# A fence opener is a line beginning with 3+ backticks or 3+ tildes (the two
# CommonMark fence delimiters). The closing fence must use the same character.
_FENCE_RE = re.compile(r"^[ \t]*(`{3,}|~{3,})[^\n]*$", re.MULTILINE)


def _fenced_ranges(text: str) -> list[tuple[int, int]]:
    """Byte ranges covered by fenced code blocks.

    A range starts at the opening fence's first character and ends one past the
    closing fence's trailing newline (or end-of-text if unclosed).
    """
    ranges: list[tuple[int, int]] = []
    matches = list(_FENCE_RE.finditer(text))
    i = 0
    while i < len(matches):
        opener = matches[i]
        delim_char = opener.group(1)[0]
        delim_len = len(opener.group(1))
        j = i + 1
        while j < len(matches):
            cand = matches[j]
            if cand.group(1)[0] == delim_char and len(cand.group(1)) >= delim_len:
                break
            j += 1
        if j < len(matches):
            close_end = matches[j].end()
            if close_end < len(text) and text[close_end] == "\n":
                close_end += 1
            ranges.append((opener.start(), close_end))
            i = j + 1
        else:
            ranges.append((opener.start(), len(text)))
            i = len(matches)
    return ranges


def _iter_markers(text: str) -> Iterator[tuple[str, str, int, int]]:
    """Yield ``(kind, section, line_start, line_end)`` for each kanon marker.

    Only matches markers that occupy a line by themselves (leading or trailing
    tabs and spaces tolerated) and are not inside a fenced code block.
    ``line_end`` is one past the marker line's trailing newline (or ``len(text)``).
    """
    fences = _fenced_ranges(text)
    for m in _MARKER_RE.finditer(text):
        if any(s <= m.start() < e for s, e in fences):
            continue
        line_end = m.end() + 1 if m.end() < len(text) and text[m.end()] == "\n" else m.end()
        yield m.group(1), m.group(2), m.start(), line_end


def _find_section_pair(
    text: str, section: str
) -> tuple[int, int, int, int] | None:
    """Find the first well-ordered begin/end pair for *section*.

    Returns ``(begin_line_start, begin_line_end, end_line_start, end_line_end)``
    or ``None`` if the section has no recognised pair (only-begin and only-end
    both return ``None``). End markers without a preceding begin are ignored.
    """
    begin_bounds: tuple[int, int] | None = None
    for kind, sec, ls, le in _iter_markers(text):
        if sec != section:
            continue
        if kind == "begin":
            if begin_bounds is None:
                begin_bounds = (ls, le)
        elif begin_bounds is not None:
            return (begin_bounds[0], begin_bounds[1], ls, le)
    return None


def _kit_root() -> Path:
    return Path(kanon.__file__).parent / "kit"


# --- Manifest loaders ---


# Capability name grammar (INV-aspect-provides-capability-name-format).
# No underscores — keeps the namespace visually distinct from aspect names
# (which permit underscores) and prevents 1-token capability predicates from
# colliding with the depth-predicate parser's whitespace-tokenised form.
_CAPABILITY_NAME_RE = re.compile(r"^[a-z][a-z0-9-]*$")


# Aspect-name grammar (INV-project-aspects-namespace-grammar). Source-namespace
# prefixes: `kanon-` (kit-shipped) and `project-` (consumer-defined). Bare names
# at input surfaces sugar to `kanon-` (see `_normalise_aspect_name`). Other
# namespaces (e.g., `acme-`) are reserved by the grammar but not defined.
_ASPECT_NAME_RE = re.compile(r"^(kanon|project)-[a-z][a-z0-9-]*$")
_BARE_ASPECT_NAME_RE = re.compile(r"^[a-z][a-z0-9-]*$")
_KANON_NAMESPACE = "kanon"
_PROJECT_NAMESPACE = "project"


def _normalise_aspect_name(raw: str) -> str:
    """Return the canonical aspect name for *raw*.

    A prefixed name (matching ``_ASPECT_NAME_RE``) passes through unchanged.
    A bare name (matching ``_BARE_ASPECT_NAME_RE``) sugars to ``kanon-<raw>``.
    Other inputs raise :class:`click.ClickException`.

    Per ADR-0028 the bare-name shorthand resolves only to the ``kanon`` namespace;
    project-aspects must always be referenced by their full ``project-<local>`` name.
    """
    if _ASPECT_NAME_RE.match(raw):
        return raw
    if _BARE_ASPECT_NAME_RE.match(raw):
        return f"kanon-{raw}"
    raise click.ClickException(
        f"Invalid aspect name {raw!r}: must match {_ASPECT_NAME_RE.pattern} "
        f"or be a bare name (will sugar to `kanon-<raw>`)."
    )


def _split_aspect_name(name: str) -> tuple[str, str]:
    """Return ``(namespace, local)`` for a canonical aspect name.

    Assumes *name* is already in canonical form (i.e., post-``_normalise_aspect_name``).
    The first dash separates namespace from local; subsequent dashes are part of local.
    """
    namespace, _, local = name.partition("-")
    return namespace, local


def _validate_provides_field(path: Path, name: str, provides: Any) -> None:
    """Validate the optional ``provides:`` block at top-manifest load time."""
    if not isinstance(provides, list):
        raise click.ClickException(
            f"{path}: aspects.{name}.provides must be a list (got {type(provides).__name__})."
        )
    for capability in provides:
        if not isinstance(capability, str):
            raise click.ClickException(
                f"{path}: aspects.{name}.provides entry {capability!r} must be a string."
            )
        if not _CAPABILITY_NAME_RE.match(capability):
            raise click.ClickException(
                f"{path}: aspects.{name}.provides entry {capability!r} is invalid; "
                f"capability names must match {_CAPABILITY_NAME_RE.pattern}."
            )


@lru_cache(maxsize=1)
def _load_top_manifest() -> dict[str, Any]:
    """Load the aspect registry at src/kanon/kit/manifest.yaml."""
    path = _kit_root() / "manifest.yaml"
    if not path.is_file():
        raise click.ClickException(f"kit manifest missing: {path}")
    data: dict[str, Any] = _load_yaml(path)
    aspects = data.get("aspects")
    if not isinstance(aspects, dict) or not aspects:
        raise click.ClickException(f"{path}: missing or empty 'aspects' mapping.")
    for name, entry in aspects.items():
        # Kit-side aspect names must use the `kanon-` namespace per ADR-0028.
        # Project-side aspects (Phase 3) live under `.kanon/aspects/project-*/`
        # and are validated by `_discover_project_aspects`, not here.
        if not isinstance(name, str) or not name.startswith(f"{_KANON_NAMESPACE}-") \
                or not _ASPECT_NAME_RE.match(name):
            raise click.ClickException(
                f"{path}: aspects.{name!r}: kit-side aspect names must match "
                f"`^kanon-[a-z][a-z0-9-]*$` (ADR-0028 namespace ownership)."
            )
        if not isinstance(entry, dict):
            raise click.ClickException(f"{path}: aspects.{name} must be a mapping.")
        for field in ("path", "stability", "depth-range", "default-depth"):
            if field not in entry:
                raise click.ClickException(
                    f"{path}: aspects.{name}: missing required field {field!r}."
                )
        if entry["stability"] not in {"experimental", "stable", "deprecated"}:
            raise click.ClickException(
                f"{path}: aspects.{name}: invalid stability {entry['stability']!r}."
            )
        rng = entry["depth-range"]
        if not (isinstance(rng, list) and len(rng) == 2):
            raise click.ClickException(
                f"{path}: aspects.{name}.depth-range must be [min, max]."
            )
        if "provides" in entry:
            _validate_provides_field(path, name, entry["provides"])
    return data


def _aspect_provides(aspect: str) -> list[str]:
    """Return the capabilities declared by *aspect* (empty list when none)."""
    entry = _aspect_entry(aspect)
    if entry is None:
        raise click.ClickException(f"Unknown aspect: {aspect!r}.")
    return list(entry.get("provides", []) or [])


def _capability_suppliers(top: dict[str, Any], capability: str) -> list[str]:
    """Return the aspect names whose ``provides:`` includes *capability*.

    Iterates the supplied ``top`` registry. Callers that want kit + project
    coverage should pass the unified registry from :func:`_load_aspect_registry`.
    For pure-kit queries, callers may pass ``_load_top_manifest()`` directly.
    """
    return sorted(
        name
        for name, entry in top["aspects"].items()
        if capability in (entry.get("provides", []) or [])
    )


# --- Project-aspect discovery + active overlay (ADR-0028) ---


# Module-level overlay set by `_load_aspect_registry(target)` at CLI command
# entry. Existing `_aspect_*` helpers consult this transparently — see
# `_aspect_entry`. Tests reset via `_set_project_aspects_overlay(None)`.
_PROJECT_ASPECTS_OVERLAY: dict[str, dict[str, Any]] | None = None


def _set_project_aspects_overlay(
    overlay: dict[str, dict[str, Any]] | None,
) -> None:
    """Set or clear the active project-aspect overlay.

    Called by every CLI command at entry that operates against a target (via
    :func:`_load_aspect_registry`). Invalidates the cached sub-manifest reads
    so a different target's project-aspects don't return stale data.
    """
    global _PROJECT_ASPECTS_OVERLAY
    _PROJECT_ASPECTS_OVERLAY = overlay
    _load_aspect_manifest.cache_clear()


def _aspect_entry(aspect: str) -> dict[str, Any] | None:
    """Find the registry entry for *aspect*, consulting kit + active overlay.

    Returns the entry dict or ``None`` if no source registers *aspect*.
    Project entries carry ``_source`` (absolute path); kit entries carry
    only ``path`` (relative to ``_kit_root()``).
    """
    top = _load_top_manifest()
    if aspect in top["aspects"]:
        kit_entry: dict[str, Any] = top["aspects"][aspect]
        return kit_entry
    if _PROJECT_ASPECTS_OVERLAY is not None and aspect in _PROJECT_ASPECTS_OVERLAY:
        return _PROJECT_ASPECTS_OVERLAY[aspect]
    return None


def _all_known_aspects() -> dict[str, dict[str, Any]]:
    """Union of kit + active project-overlay aspect entries.

    Used by helpers that need to iterate over every registered aspect (e.g.,
    cross-source capability lookups). Project entries are appended after kit
    entries; the namespace grammar (ADR-0028) prevents key collisions.
    """
    top = _load_top_manifest()
    if _PROJECT_ASPECTS_OVERLAY is None:
        return dict(top["aspects"])
    return {**top["aspects"], **_PROJECT_ASPECTS_OVERLAY}


def _discover_project_aspects(target: Path) -> dict[str, dict[str, Any]]:
    """Walk ``<target>/.kanon/aspects/`` and return registry entries for each
    project-aspect found.

    Each entry includes ``_source`` set to the aspect's absolute directory
    path. Per ADR-0028 the consumer-side ``aspects/`` may only declare aspects
    in the ``project-`` namespace; ``kanon-`` (or any other prefix) directories
    under that path are rejected at load time with a single-line error naming
    the offending path and the namespace-ownership rule.
    """
    aspects_dir = target / ".kanon" / "aspects"
    if not aspects_dir.is_dir():
        return {}
    result: dict[str, dict[str, Any]] = {}
    for sub in sorted(aspects_dir.iterdir()):
        if not sub.is_dir():
            continue
        name = sub.name
        if name.startswith("."):
            continue
        # Namespace ownership (ADR-0028): only `project-<local>` is allowed.
        if not _ASPECT_NAME_RE.match(name) or not name.startswith(
            f"{_PROJECT_NAMESPACE}-"
        ):
            raise click.ClickException(
                f"Project-aspect directory '{sub.relative_to(target)}': aspect "
                f"name {name!r} must match `project-[a-z][a-z0-9-]*` "
                f"(ADR-0028 namespace ownership)."
            )
        manifest_path = sub / "manifest.yaml"
        if not manifest_path.is_file():
            raise click.ClickException(
                f"Project-aspect {name!r}: missing manifest.yaml at "
                f"'{manifest_path.relative_to(target)}'."
            )
        full = _load_yaml(manifest_path)
        for field in ("stability", "depth-range", "default-depth"):
            if field not in full:
                raise click.ClickException(
                    f"Project-aspect {name!r}: missing required field {field!r} "
                    f"in '{manifest_path.relative_to(target)}'."
                )
        if full["stability"] not in {"experimental", "stable", "deprecated"}:
            raise click.ClickException(
                f"Project-aspect {name!r}: invalid stability "
                f"{full['stability']!r} in '{manifest_path.relative_to(target)}'."
            )
        rng = full["depth-range"]
        if not (isinstance(rng, list) and len(rng) == 2):
            raise click.ClickException(
                f"Project-aspect {name!r}.depth-range must be [min, max] in "
                f"'{manifest_path.relative_to(target)}'."
            )
        if "provides" in full:
            _validate_provides_field(manifest_path, name, full["provides"])
        entry: dict[str, Any] = {
            "stability": full["stability"],
            "depth-range": full["depth-range"],
            "default-depth": full["default-depth"],
            "requires": full.get("requires", []) or [],
            "_source": str(sub),
            "path": str(sub),  # kit-shape compat for any path-only consumer
        }
        if "provides" in full:
            entry["provides"] = full["provides"]
        if "suggests" in full:
            entry["suggests"] = full["suggests"]
        result[name] = entry
    return result


def _load_aspect_registry(target: Path | None = None) -> dict[str, Any]:
    """Return the unified aspect registry (kit + project) for *target*.

    Mirrors the shape of :func:`_load_top_manifest` (``{aspects: {...}, ...}``)
    while side-effecting the active project-aspects overlay so downstream
    ``_aspect_*`` helpers see project-aspects without needing to thread
    *target* explicitly. Calling with ``target=None`` clears the overlay and
    returns the kit-only registry.

    Each entry in the returned ``aspects`` mapping carries ``_source`` (the
    absolute path to the aspect's directory) so collision detection and
    sub-manifest resolution work source-agnostically.
    """
    top = _load_top_manifest()
    kit_aspects: dict[str, dict[str, Any]] = {}
    for name, entry in top["aspects"].items():
        e = dict(entry)
        e["_source"] = str(_kit_root() / e["path"])
        kit_aspects[name] = e
    if target is None:
        _set_project_aspects_overlay(None)
        unified_top = dict(top)
        unified_top["aspects"] = kit_aspects
        return unified_top
    project = _discover_project_aspects(target)
    collisions = sorted(set(kit_aspects) & set(project))
    if collisions:
        raise click.ClickException(
            f"Aspect-name collision between kit and project sources: "
            f"{collisions}. Project-aspects must use the `project-` namespace "
            f"per ADR-0028."
        )
    _set_project_aspects_overlay(project)
    unified_top = dict(top)
    unified_top["aspects"] = {**kit_aspects, **project}
    return unified_top


# Recognised value types in an aspect's `config-schema:`. Anything else is
# rejected at sub-manifest load time.
_CONFIG_SCHEMA_TYPES = frozenset({"string", "integer", "boolean", "number"})
# Permitted descriptor fields under each `config-schema.<key>` entry.
_CONFIG_SCHEMA_FIELDS = frozenset({"type", "default", "description"})


def _validate_config_schema(sub_path: Path, schema: Any) -> None:
    """Validate the optional ``config-schema:`` block at sub-manifest load time."""
    if not isinstance(schema, dict):
        raise click.ClickException(
            f"{sub_path}: 'config-schema' must be a mapping of key → descriptor."
        )
    for key, descriptor in schema.items():
        if not isinstance(key, str) or not key:
            raise click.ClickException(
                f"{sub_path}: config-schema key must be a non-empty string, got {key!r}."
            )
        if not isinstance(descriptor, dict):
            raise click.ClickException(
                f"{sub_path}: config-schema.{key} must be a mapping (got {type(descriptor).__name__})."
            )
        if "type" not in descriptor:
            raise click.ClickException(
                f"{sub_path}: config-schema.{key} is missing required field 'type'."
            )
        type_val = descriptor["type"]
        if type_val not in _CONFIG_SCHEMA_TYPES:
            raise click.ClickException(
                f"{sub_path}: config-schema.{key}.type {type_val!r} is invalid; "
                f"expected one of {sorted(_CONFIG_SCHEMA_TYPES)}."
            )
        unknown = set(descriptor) - _CONFIG_SCHEMA_FIELDS
        if unknown:
            raise click.ClickException(
                f"{sub_path}: config-schema.{key} has unknown field(s) {sorted(unknown)!r}; "
                f"only {sorted(_CONFIG_SCHEMA_FIELDS)} are permitted."
            )


# Module-path grammar for `validators:` entries (ADR-0028 / project-aspects
# spec INV-7). A validator is an importable Python module whose dotted path
# appears as a YAML scalar — e.g., `my_pkg.checks.greenlight`. Each segment
# follows Python identifier rules; the joining `.` separators matter.
_VALIDATOR_MODULE_PATH_RE = re.compile(
    r"^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*$"
)


def _validate_validators_field(sub_path: Path, validators: Any) -> None:
    """Validate the optional ``validators:`` block at sub-manifest load time.

    The field is a list of dotted module paths; each module is expected to
    expose a callable ``check(target, errors, warnings) -> None`` (verified at
    invocation time, not here — schema validation is path-grammar only).
    """
    if not isinstance(validators, list):
        raise click.ClickException(
            f"{sub_path}: 'validators' must be a list (got "
            f"{type(validators).__name__})."
        )
    for entry in validators:
        if not isinstance(entry, str):
            raise click.ClickException(
                f"{sub_path}: validators entry {entry!r} must be a string "
                f"(dotted module path)."
            )
        if not _VALIDATOR_MODULE_PATH_RE.match(entry):
            raise click.ClickException(
                f"{sub_path}: validators entry {entry!r} is not a valid "
                f"dotted module path (expected `pkg.mod[.sub]`)."
            )


@cache
def _load_aspect_manifest(aspect: str) -> dict[str, Any]:
    """Load the aspect's per-aspect ``manifest.yaml``.

    For kit-aspects the file lives at ``src/kanon/kit/aspects/<aspect>/manifest.yaml``.
    For project-aspects the file lives at ``<target>/.kanon/aspects/<aspect>/manifest.yaml``
    (resolved via the active overlay set by :func:`_load_aspect_registry`).
    """
    entry = _aspect_entry(aspect)
    if entry is None:
        raise click.ClickException(f"Unknown aspect: {aspect!r}.")
    sub_path = _aspect_path(aspect) / "manifest.yaml"
    if not sub_path.is_file():
        raise click.ClickException(f"aspect sub-manifest missing: {sub_path}")
    data: dict[str, Any] = _load_yaml(sub_path)
    min_d, max_d = _aspect_depth_range(aspect)
    for d in range(min_d, max_d + 1):
        key = f"depth-{d}"
        if key not in data:
            raise click.ClickException(f"{sub_path}: missing {key!r} entry.")
        if not isinstance(data[key], dict):
            raise click.ClickException(f"{sub_path}: {key} must be a mapping.")
    if "config-schema" in data:
        _validate_config_schema(sub_path, data["config-schema"])
    if "validators" in data:
        _validate_validators_field(sub_path, data["validators"])
    return data


def _aspect_validators(aspect: str) -> list[str]:
    """Return the dotted module paths declared under ``validators:`` (project-
    aspects spec INV-7). Empty list when none.
    """
    sub = _load_aspect_manifest(aspect)
    raw = sub.get("validators") or []
    return [str(v) for v in raw if isinstance(v, str)]


def _aspect_config_schema(aspect: str) -> dict[str, dict[str, Any]] | None:
    """Return the aspect's ``config-schema:`` mapping, or None when none is declared."""
    sub = _load_aspect_manifest(aspect)
    schema = sub.get("config-schema")
    if schema is None:
        return None
    return dict(schema)


def _aspect_depth_range(aspect: str) -> tuple[int, int]:
    entry = _aspect_entry(aspect)
    if entry is None:
        raise click.ClickException(f"Unknown aspect: {aspect!r}.")
    rng = entry["depth-range"]
    return int(rng[0]), int(rng[1])


def _aspect_path(aspect: str) -> Path:
    """Return the on-disk directory holding *aspect*'s sub-manifest, files, etc.

    Project-aspect entries (set by :func:`_discover_project_aspects`) carry an
    absolute ``_source``; kit-aspect entries carry only ``path`` (relative to
    ``_kit_root()``). The fallback path keeps kit-only behaviour intact when
    no overlay is active.
    """
    entry = _aspect_entry(aspect)
    if entry is None:
        raise click.ClickException(f"Unknown aspect: {aspect!r}.")
    if "_source" in entry:
        return Path(entry["_source"])
    return _kit_root() / str(entry["path"])


def _aspect_items(aspect: str, depth: int, key: str) -> list[str]:
    """Return the union of *key* entries from depth-0 through *depth*."""
    sub = _load_aspect_manifest(aspect)
    min_d, _ = _aspect_depth_range(aspect)
    items: list[str] = []
    for d in range(min_d, depth + 1):
        items.extend(sub.get(f"depth-{d}", {}).get(key, []) or [])
    return items


def _aspect_files(aspect: str, depth: int) -> list[str]:
    sub = _load_aspect_manifest(aspect)
    base = list(sub.get("files", []) or [])
    base.extend(_aspect_items(aspect, depth, "files"))
    return base


def _aspect_protocols(aspect: str, depth: int) -> list[str]:
    return _aspect_items(aspect, depth, "protocols")


def _aspect_sections(aspect: str, depth: int) -> list[str]:
    return _aspect_items(aspect, depth, "sections")


def _aspect_depth_validators(aspect: str, depth: int) -> list[str]:
    """Return depth-gated validator module paths (union of depth-0..depth)."""
    return _aspect_items(aspect, depth, "validators")


def _all_aspect_sections(aspect: str) -> set[str]:
    """Every section name across all depths of aspect."""
    sub = _load_aspect_manifest(aspect)
    min_d, max_d = _aspect_depth_range(aspect)
    seen: set[str] = set()
    for d in range(min_d, max_d + 1):
        for name in sub.get(f"depth-{d}", {}).get("sections", []) or []:
            seen.add(name)
    return seen


def _namespaced_section(aspect: str, section: str) -> str:
    """Section name as it appears in an AGENTS.md marker."""
    if section in _UNPREFIXED_SECTIONS:
        return section
    return f"{aspect}/{section}"


def _default_aspects() -> dict[str, int]:
    """Read the ``defaults:`` key from the top manifest and return {name: default-depth}."""
    top = _load_top_manifest()
    names: list[str] = top.get("defaults", [])
    result: dict[str, int] = {}
    for name in names:
        if name not in top["aspects"]:
            raise click.ClickException(
                f"defaults: lists unknown aspect {name!r}."
            )
        result[name] = int(top["aspects"][name]["default-depth"])
    return result


def _expected_files(aspects: dict[str, int]) -> list[str]:
    """Return the full path list a project with these aspects must have."""
    paths: list[str] = list(_ALWAYS_SYNTHESIZED)
    # Kit-global files.
    top = _load_top_manifest()
    paths.extend(top.get("files", []) or [])
    for aspect, depth in aspects.items():
        paths.extend(_aspect_files(aspect, depth))
        paths.extend(
            f".kanon/protocols/{aspect}/{p}" for p in _aspect_protocols(aspect, depth)
        )
    return paths


# --- Small helpers ---


def _now_iso() -> str:
    return datetime.now(tz=timezone.utc).isoformat(timespec="seconds")


def _render_placeholder(text: str, context: dict[str, str]) -> str:
    return string.Template(text).safe_substitute(context)


def _parse_frontmatter(text: str) -> dict[str, Any]:
    if not text.startswith("---\n"):
        return {}
    end = text.find("\n---\n", 4)
    if end < 0:
        return {}
    data = yaml.safe_load(text[4:end])
    return data if isinstance(data, dict) else {}
