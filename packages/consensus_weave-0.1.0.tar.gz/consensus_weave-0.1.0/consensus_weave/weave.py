"""Consensus weaving: merge agent votes into fleet decisions."""

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Set


class VoteType(Enum):
    AGREE = "agree"
    DISAGREE = "disagree"
    VETO = "veto"
    ABSTAIN = "abstain"


@dataclass
class Vote:
    """A single agent's vote on a proposal."""
    agent_id: str
    vote: VoteType
    weight: float = 1.0
    reason: str = ""


@dataclass
class ConsensusResult:
    """Result of a consensus round."""
    proposal_id: str
    passed: bool
    agree_count: int = 0
    disagree_count: int = 0
    veto_count: int = 0
    abstain_count: int = 0
    weighted_score: float = 0.0
    threshold: float = 0.0
    voters: List[str] = field(default_factory=list)


@dataclass
class Ballot:
    """A proposal up for vote."""
    proposal_id: str
    description: str = ""
    created_at: float = field(default_factory=time.time)
    quorum: int = 2  # minimum voters needed
    threshold: float = 0.6  # weighted fraction of agree votes needed
    veto_power: Set[str] = field(default_factory=set)  # agents with veto


class ConsensusWeave:
    """Multi-agent consensus protocol.
    
    Usage:
        cw = ConsensusWeave()
        ballot = cw.propose("deploy-v1", "Deploy version 1", quorum=3)
        cw.vote("deploy-v1", Vote(agent_id="oracle1", vote=VoteType.AGREE))
        cw.vote("deploy-v1", Vote(agent_id="fm", vote=VoteType.AGREE))
        result = cw.resolve("deploy-v1")
    """
    
    def __init__(self):
        self.ballots: Dict[str, Ballot] = {}
        self.votes: Dict[str, List[Vote]] = {}
    
    def propose(self, proposal_id: str, description: str = "",
                quorum: int = 2, threshold: float = 0.6,
                veto_power: Optional[Set[str]] = None) -> Ballot:
        ballot = Ballot(
            proposal_id=proposal_id,
            description=description,
            quorum=quorum,
            threshold=threshold,
            veto_power=veto_power or set(),
        )
        self.ballots[proposal_id] = ballot
        self.votes[proposal_id] = []
        return ballot
    
    def vote(self, proposal_id: str, vote: Vote) -> bool:
        if proposal_id not in self.ballots:
            return False
        self.votes[proposal_id].append(vote)
        return True
    
    def resolve(self, proposal_id: str) -> Optional[ConsensusResult]:
        if proposal_id not in self.ballots:
            return None
        
        ballot = self.ballots[proposal_id]
        votes = self.votes.get(proposal_id, [])
        
        # Count votes
        agree_count = 0
        disagree_count = 0
        veto_count = 0
        abstain_count = 0
        agree_weight = 0.0
        total_weight = 0.0
        voters = []
        
        for v in votes:
            voters.append(v.agent_id)
            if v.vote == VoteType.AGREE:
                agree_count += 1
                agree_weight += v.weight
                total_weight += v.weight
            elif v.vote == VoteType.DISAGREE:
                disagree_count += 1
                total_weight += v.weight
            elif v.vote == VoteType.VETO:
                veto_count += 1
                # Check if agent has veto power
                if v.agent_id in ballot.veto_power:
                    return ConsensusResult(
                        proposal_id=proposal_id, passed=False,
                        veto_count=1, voters=voters,
                        threshold=ballot.threshold,
                    )
                disagree_count += 1
                total_weight += v.weight
            elif v.vote == VoteType.ABSTAIN:
                abstain_count += 1
                # abstain doesn't count toward total
        
        # Check quorum
        active_voters = agree_count + disagree_count + veto_count
        if active_voters < ballot.quorum:
            return ConsensusResult(
                proposal_id=proposal_id, passed=False,
                agree_count=agree_count, disagree_count=disagree_count,
                veto_count=veto_count, abstain_count=abstain_count,
                voters=voters, threshold=ballot.threshold,
            )
        
        # Calculate weighted score
        score = agree_weight / total_weight if total_weight > 0 else 0.0
        passed = score >= ballot.threshold
        
        return ConsensusResult(
            proposal_id=proposal_id, passed=passed,
            agree_count=agree_count, disagree_count=disagree_count,
            veto_count=veto_count, abstain_count=abstain_count,
            weighted_score=round(score, 4), threshold=ballot.threshold,
            voters=voters,
        )
    
    def active_ballots(self) -> List[str]:
        return list(self.ballots.keys())
