"""consensus-weave — Multi-agent agreement protocol.

Weave separate agent votes into a single fleet decision.
Quorum-based with configurable thresholds and veto power.
"""
__version__ = "0.1.0"
from .weave import ConsensusWeave, Vote, VoteType, Ballot, ConsensusResult
__all__ = ["ConsensusWeave", "Vote", "VoteType", "Ballot", "ConsensusResult"]
