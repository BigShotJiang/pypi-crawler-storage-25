"""Tests for consensus-weave."""
import pytest
from consensus_weave import ConsensusWeave, Vote, VoteType


def test_simple_majority():
    cw = ConsensusWeave()
    cw.propose("p1", quorum=2, threshold=0.5)
    cw.vote("p1", Vote(agent_id="a", vote=VoteType.AGREE, weight=1.0))
    cw.vote("p1", Vote(agent_id="b", vote=VoteType.AGREE, weight=1.0))
    result = cw.resolve("p1")
    assert result.passed
    assert result.agree_count == 2


def test_fails_below_quorum():
    cw = ConsensusWeave()
    cw.propose("p1", quorum=3)
    cw.vote("p1", Vote(agent_id="a", vote=VoteType.AGREE))
    result = cw.resolve("p1")
    assert not result.passed


def test_veto_blocks():
    cw = ConsensusWeave()
    cw.propose("p1", quorum=2, veto_power={"captain"})
    cw.vote("p1", Vote(agent_id="a", vote=VoteType.AGREE))
    cw.vote("p1", Vote(agent_id="captain", vote=VoteType.VETO))
    result = cw.resolve("p1")
    assert not result.passed
    assert result.veto_count == 1


def test_weighted_voting():
    cw = ConsensusWeave()
    cw.propose("p1", quorum=2, threshold=0.6)
    cw.vote("p1", Vote(agent_id="heavy", vote=VoteType.AGREE, weight=3.0))
    cw.vote("p1", Vote(agent_id="light", vote=VoteType.DISAGREE, weight=1.0))
    result = cw.resolve("p1")
    assert result.passed  # 3.0/4.0 = 0.75 >= 0.6
    assert result.weighted_score == 0.75


def test_abstain_doesnt_count():
    cw = ConsensusWeave()
    cw.propose("p1", quorum=2, threshold=0.5)
    cw.vote("p1", Vote(agent_id="a", vote=VoteType.AGREE))
    cw.vote("p1", Vote(agent_id="b", vote=VoteType.ABSTAIN))
    result = cw.resolve("p1")
    assert not result.passed  # only 1 active voter, quorum=2


def test_unknown_proposal():
    cw = ConsensusWeave()
    assert cw.resolve("nonexistent") is None
