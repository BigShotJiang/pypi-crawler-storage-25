# consensus-weave

Multi-agent consensus protocol. Weave separate agent votes into a single fleet decision with quorum thresholds, weighted voting, and veto power.

## Usage

```python
from consensus_weave import ConsensusWeave, Vote, VoteType

cw = ConsensusWeave()
cw.propose("deploy-v1", "Deploy to production", quorum=3, threshold=0.6, veto_power={"captain"})

cw.vote("deploy-v1", Vote(agent_id="oracle1", vote=VoteType.AGREE, weight=1.5))
cw.vote("deploy-v1", Vote(agent_id="fm", vote=VoteType.AGREE))
cw.vote("deploy-v1", Vote(agent_id="jc1", vote=VoteType.DISAGREE))

result = cw.resolve("deploy-v1")
# passed=True (2 agree vs 1 disagree, weighted score 2.5/3.5 = 0.71 >= 0.6)
```

Zero deps. `pip install consensus-weave`
