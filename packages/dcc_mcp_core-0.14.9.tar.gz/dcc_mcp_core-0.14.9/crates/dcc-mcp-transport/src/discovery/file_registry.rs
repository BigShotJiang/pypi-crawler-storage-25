//! File-based service registry.
//!
//! Stores service entries as JSON in a registry directory.
//! Uses `(dcc_type, instance_id)` as key to support multiple instances per DCC type.

use std::fs;
use std::path::PathBuf;
use std::sync::Mutex;
use std::time::{Duration, SystemTime};

use dashmap::DashMap;
use sysinfo::{Pid, ProcessesToUpdate, System};
use tracing;

use super::types::{GATEWAY_SENTINEL_DCC_TYPE, ServiceEntry, ServiceKey, ServiceStatus};
use crate::error::{TransportError, TransportResult};

/// Return `true` when `pid` refers to a currently running OS process.
///
/// Used by [`FileRegistry::prune_dead_pids`] to detect ghost entries left behind
/// when a DCC plugin crashes after registering but before the heartbeat loop
/// starts. See issue #227.
fn is_pid_alive(pid: u32) -> bool {
    let sp = Pid::from_u32(pid);
    let mut sys = System::new();
    sys.refresh_processes(ProcessesToUpdate::Some(&[sp]), true);
    sys.process(sp).is_some()
}

/// File name for the registry JSON.
const REGISTRY_FILE: &str = "services.json";

/// File-based service registry with instance-level keying.
///
/// Key improvement over the Python implementation: uses `(dcc_type, instance_id)` as key
/// instead of `dcc_type` alone, enabling multiple instances of the same DCC type.
///
/// **Hot-reload feature**: Detects external writes to services.json via mtime tracking.
/// When another process writes to the registry file, this process automatically reloads
/// the new entries without requiring a restart. This enables the gateway to discover
/// instances registered by other processes (e.g., Maya plugin using McpHttpConfig.gateway_port).
pub struct FileRegistry {
    /// In-memory cache of services.
    services: DashMap<ServiceKey, ServiceEntry>,
    /// Directory where registry file is stored.
    registry_dir: PathBuf,
    /// Last-seen modification time of services.json.
    /// Used to detect external writes (hot-reload).
    last_mtime: Mutex<Option<SystemTime>>,
}

impl FileRegistry {
    /// Create a new file registry at the given directory.
    pub fn new(registry_dir: impl Into<PathBuf>) -> TransportResult<Self> {
        let registry_dir = registry_dir.into();
        fs::create_dir_all(&registry_dir).map_err(|e| {
            TransportError::RegistryFile(format!(
                "failed to create registry dir {}: {}",
                registry_dir.display(),
                e
            ))
        })?;

        let registry = Self {
            services: DashMap::new(),
            registry_dir,
            last_mtime: Mutex::new(None),
        };

        // Load existing entries
        registry.load_from_file()?;
        registry.update_mtime()?;

        Ok(registry)
    }

    /// Reload from file if another process has written to it since our last read (hot-reload).
    ///
    /// This is O(1) on the happy path: single `stat` syscall + mutex check.
    /// Only does actual file I/O when another process has modified services.json.
    fn reload_if_stale(&self) -> TransportResult<()> {
        let path = self.registry_file_path();

        // Quick stat to get current mtime
        let Ok(meta) = fs::metadata(&path) else {
            // File doesn't exist yet, nothing to reload
            return Ok(());
        };
        let Ok(current_mtime) = meta.modified() else {
            // Can't get mtime, skip reload
            return Ok(());
        };

        // Compare with cached mtime
        let mut cached = self.last_mtime.lock().unwrap();
        if *cached == Some(current_mtime) {
            // File hasn't changed — fast path, no I/O
            return Ok(());
        }

        // File was modified by another process — drop lock and reload
        *cached = Some(current_mtime);
        drop(cached);

        // Load the new entries
        if let Err(e) = self.load_from_file() {
            tracing::warn!("FileRegistry hot-reload failed: {}", e);
        } else {
            tracing::debug!("FileRegistry hot-reloaded from disk");
        }
        Ok(())
    }

    /// Update the cached mtime to the current file modification time.
    fn update_mtime(&self) -> TransportResult<()> {
        let path = self.registry_file_path();
        if !path.exists() {
            return Ok(());
        }

        let Ok(meta) = fs::metadata(&path) else {
            return Ok(());
        };
        let Ok(mtime) = meta.modified() else {
            return Ok(());
        };

        let mut cached = self.last_mtime.lock().unwrap();
        *cached = Some(mtime);
        Ok(())
    }

    /// Register a service.
    pub fn register(&self, entry: ServiceEntry) -> TransportResult<()> {
        let key = entry.key();
        tracing::info!(
            dcc_type = %entry.dcc_type,
            instance_id = %entry.instance_id,
            host = %entry.host,
            port = entry.port,
            "registering service"
        );
        self.services.insert(key, entry);
        self.flush_to_file()
    }

    /// Deregister a service by key.
    pub fn deregister(&self, key: &ServiceKey) -> TransportResult<Option<ServiceEntry>> {
        let removed = self.services.remove(key).map(|(_, entry)| entry);
        if removed.is_some() {
            tracing::info!(
                dcc_type = %key.dcc_type,
                instance_id = %key.instance_id,
                "deregistered service"
            );
            self.flush_to_file()?;
        }
        Ok(removed)
    }

    /// Get a service entry by key.
    pub fn get(&self, key: &ServiceKey) -> Option<ServiceEntry> {
        self.services.get(key).map(|r| r.value().clone())
    }

    /// List all instances for a given DCC type.
    pub fn list_instances(&self, dcc_type: &str) -> Vec<ServiceEntry> {
        let _ = self.reload_if_stale();
        self.services
            .iter()
            .filter(|r| r.value().dcc_type == dcc_type)
            .map(|r| r.value().clone())
            .collect()
    }

    /// List all registered services.
    pub fn list_all(&self) -> Vec<ServiceEntry> {
        let _ = self.reload_if_stale();
        self.services.iter().map(|r| r.value().clone()).collect()
    }

    /// Update heartbeat for a service.
    pub fn heartbeat(&self, key: &ServiceKey) -> TransportResult<bool> {
        let found = if let Some(mut entry) = self.services.get_mut(key) {
            entry.value_mut().touch();
            true
        } else {
            false
        };
        // flush_to_file calls list_all which iterates the DashMap;
        // the write guard from get_mut must be dropped first to avoid deadlock.
        if found {
            self.flush_to_file()?;
        }
        Ok(found)
    }

    /// Update status for a service.
    pub fn update_status(&self, key: &ServiceKey, status: ServiceStatus) -> TransportResult<bool> {
        let found = if let Some(mut entry) = self.services.get_mut(key) {
            entry.value_mut().status = status;
            true
        } else {
            false
        };
        if found {
            self.flush_to_file()?;
        }
        Ok(found)
    }

    /// Update scene and/or version metadata for a service, and refresh heartbeat.
    ///
    /// This is the primary way for a running instance to report that the user
    /// has opened a different scene (e.g. switched documents in Photoshop) or
    /// that the DCC version has changed.
    pub fn update_metadata(
        &self,
        key: &ServiceKey,
        scene: Option<&str>,
        version: Option<&str>,
    ) -> TransportResult<bool> {
        let found = if let Some(mut entry) = self.services.get_mut(key) {
            let e = entry.value_mut();
            if let Some(s) = scene {
                e.scene = if s.is_empty() {
                    None
                } else {
                    Some(s.to_string())
                };
            }
            if let Some(v) = version {
                e.version = if v.is_empty() {
                    None
                } else {
                    Some(v.to_string())
                };
            }
            e.touch(); // also refresh heartbeat
            true
        } else {
            false
        };
        if found {
            self.flush_to_file()?;
        }
        Ok(found)
    }

    /// Update the active document, full document list, and optional display name.
    ///
    /// Designed for multi-document DCC applications (e.g. Photoshop, After Effects)
    /// that can have several files open simultaneously. For single-document DCCs
    /// (Maya, Blender, Houdini) it is equivalent to [`update_metadata`] with the
    /// `scene` field, but also stores `pid` and `display_name` when provided.
    ///
    /// # Parameters
    /// - `active_document` — the currently focused file; stored in `scene`.
    ///   Pass `Some("")` to clear.
    /// - `documents` — full list of open documents; replaces the previous list.
    ///   Pass `&[]` to clear.
    /// - `display_name` — human-readable instance label (e.g. `"PS-Marketing"`).
    ///   Pass `Some("")` to clear.  `None` leaves the existing value unchanged.
    ///
    /// Always refreshes the heartbeat so the gateway does not mark the instance stale.
    pub fn update_documents(
        &self,
        key: &ServiceKey,
        active_document: Option<&str>,
        documents: &[String],
        display_name: Option<&str>,
    ) -> TransportResult<bool> {
        let found = if let Some(mut entry) = self.services.get_mut(key) {
            let e = entry.value_mut();

            if let Some(doc) = active_document {
                e.scene = if doc.is_empty() {
                    None
                } else {
                    Some(doc.to_string())
                };
            }

            // Always replace the documents list (caller owns the authoritative set).
            e.documents = documents
                .iter()
                .filter(|d| !d.is_empty())
                .cloned()
                .collect();

            if let Some(name) = display_name {
                e.display_name = if name.is_empty() {
                    None
                } else {
                    Some(name.to_string())
                };
            }

            e.touch();
            true
        } else {
            false
        };

        if found {
            self.flush_to_file()?;
        }
        Ok(found)
    }

    /// Set the OS process ID for a registered service.
    ///
    /// Normally called once at registration time; exposed separately so that
    /// bridge plugins can set it after the initial [`register`] call if the PID
    /// was not known at startup.
    pub fn set_pid(&self, key: &ServiceKey, pid: u32) -> TransportResult<bool> {
        let found = if let Some(mut entry) = self.services.get_mut(key) {
            entry.value_mut().pid = Some(pid);
            entry.value_mut().touch();
            true
        } else {
            false
        };
        if found {
            self.flush_to_file()?;
        }
        Ok(found)
    }

    /// Remove stale services (no heartbeat within timeout).
    ///
    /// The gateway sentinel entry ([`GATEWAY_SENTINEL_DCC_TYPE`]) is
    /// **never** evicted here — its staleness is meaningful only if the
    /// gateway process itself is dead, which [`Self::prune_dead_pids`] handles
    /// via PID liveness probe. See issue #230.
    pub fn cleanup_stale(&self, timeout: Duration) -> TransportResult<usize> {
        let stale_keys: Vec<ServiceKey> = self
            .services
            .iter()
            .filter(|r| {
                let e = r.value();
                e.dcc_type != GATEWAY_SENTINEL_DCC_TYPE && e.is_stale(timeout)
            })
            .map(|r| r.key().clone())
            .collect();

        let count = stale_keys.len();
        for key in &stale_keys {
            self.services.remove(key);
            tracing::info!(
                dcc_type = %key.dcc_type,
                instance_id = %key.instance_id,
                "removed stale service"
            );
        }

        if count > 0 {
            self.flush_to_file()?;
        }
        Ok(count)
    }

    /// Remove entries whose owning OS process is no longer running.
    ///
    /// Complements [`Self::cleanup_stale`]: a plugin that crashes during
    /// `initializePlugin` (after `bind_and_register` wrote its row but before
    /// the heartbeat task started) would otherwise leak a ghost entry for up
    /// to `stale_timeout` seconds. This check runs a PID liveness probe and
    /// removes entries with dead PIDs immediately — including the gateway
    /// sentinel, since a dead gateway process must not keep the sentinel alive.
    ///
    /// Entries without a `pid` set are left untouched (fail-open — we cannot
    /// probe what we cannot identify). See issue #227.
    pub fn prune_dead_pids(&self) -> TransportResult<usize> {
        let dead_keys: Vec<ServiceKey> = self
            .services
            .iter()
            .filter(|r| r.value().pid.is_some_and(|p| !is_pid_alive(p)))
            .map(|r| r.key().clone())
            .collect();

        let count = dead_keys.len();
        for key in &dead_keys {
            self.services.remove(key);
            tracing::info!(
                dcc_type = %key.dcc_type,
                instance_id = %key.instance_id,
                "removed ghost entry (owning process is dead)"
            );
        }

        if count > 0 {
            self.flush_to_file()?;
        }
        Ok(count)
    }

    /// Get the number of registered services.
    pub fn len(&self) -> usize {
        self.services.len()
    }

    /// Check if the registry is empty.
    pub fn is_empty(&self) -> bool {
        self.services.is_empty()
    }

    // ── File I/O ──

    fn registry_file_path(&self) -> PathBuf {
        self.registry_dir.join(REGISTRY_FILE)
    }

    /// Load services from the JSON file into memory.
    fn load_from_file(&self) -> TransportResult<()> {
        let path = self.registry_file_path();
        if !path.exists() {
            return Ok(());
        }

        let content = fs::read_to_string(&path).map_err(|e| {
            TransportError::RegistryFile(format!("failed to read {}: {}", path.display(), e))
        })?;

        if content.trim().is_empty() {
            return Ok(());
        }

        let entries: Vec<ServiceEntry> = serde_json::from_str(&content).map_err(|e| {
            TransportError::RegistryFile(format!("failed to parse {}: {}", path.display(), e))
        })?;

        for entry in entries {
            let key = entry.key();
            self.services.insert(key, entry);
        }

        tracing::debug!(count = self.services.len(), "loaded services from file");
        Ok(())
    }

    /// Flush the in-memory services to the JSON file.
    fn flush_to_file(&self) -> TransportResult<()> {
        let entries: Vec<ServiceEntry> = self.list_all();
        let content = serde_json::to_string_pretty(&entries).map_err(|e| {
            TransportError::Serialization(format!("failed to serialize registry: {}", e))
        })?;

        let path = self.registry_file_path();
        fs::write(&path, content).map_err(|e| {
            TransportError::RegistryFile(format!("failed to write {}: {}", path.display(), e))
        })?;

        // Update cached mtime after write
        let _ = self.update_mtime();

        Ok(())
    }
}

#[cfg(test)]
#[path = "file_registry_tests.rs"]
mod tests;
