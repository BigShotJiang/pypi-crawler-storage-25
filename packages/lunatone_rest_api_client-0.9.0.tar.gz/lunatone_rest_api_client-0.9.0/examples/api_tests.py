import argparse
import asyncio

import aiohttp

from lunatone_rest_api_client import (
    Auth,
    Device,
    Devices,
    Info
)


parser = argparse.ArgumentParser(prog="API Test")
parser.add_argument("-i", "--ip", type=str, required=True,
                    help="Specify IP address of the device")
arguments = parser.parse_args()


REQUEST_COUNT = 3


async def test_consecutively_get_and_post_requests(auth: Auth):
    info = Info(auth)
    devices = Devices(info)
    await devices.async_update() # Send GET request to /devices

    device: Device = devices.devices[1]

    switch_on_fail_count = 0
    switch_off_fail_count = 0

    # Send POST request with { "switchable": true } to /device/<device-id>/control
    await device.switch_on()
    for i in range(1, REQUEST_COUNT + 1):
        await device.async_update() # Send GET request to /device/<device-id>
        print(f"request{i}: expected switchable=True, actual switchable={device.is_on}")
        if not device.is_on:
            switch_on_fail_count += 1

    # Send POST request with { "switchable": false } to /device/<device-id>/control
    await device.switch_off()
    for i in range(1, REQUEST_COUNT + 1):
        await device.async_update() # Send GET request to /device/<device-id>
        print(f"request{i}: expected switchable=False, actual switchable={device.is_on}")
        if device.is_on:
            switch_off_fail_count += 1

    print(
        f"Failed attempts: switch-on={switch_on_fail_count} switch-off={switch_off_fail_count}"
    )


async def main():
    async with aiohttp.ClientSession() as session:
        auth = Auth(session, f"http://{arguments.ip}")

        await test_consecutively_get_and_post_requests(auth)


if __name__ == "__main__":
    asyncio.run(main())
