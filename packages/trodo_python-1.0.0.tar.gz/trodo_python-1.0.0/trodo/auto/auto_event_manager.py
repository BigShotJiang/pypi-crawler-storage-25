"""Auto event manager — captures unhandled Python exceptions as server_error events."""

from __future__ import annotations

import sys
import threading
import traceback
from datetime import datetime, timezone
from typing import Any, Optional, TYPE_CHECKING

from ..types import EventPayload

if TYPE_CHECKING:
    from ..session.session_manager import SessionManager
    from ..api.http_client import HttpClient


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class AutoEventManager:
    def __init__(
        self,
        site_id: str,
        http_client: "HttpClient",
        session_manager: "SessionManager",
    ) -> None:
        self._site_id = site_id
        self._http = http_client
        self._session_manager = session_manager
        self._enabled = False
        self._prev_excepthook: Any = None
        self._prev_thread_excepthook: Any = None

    def enable(self) -> None:
        if self._enabled:
            return
        self._enabled = True

        # Wrap sys.excepthook
        self._prev_excepthook = sys.excepthook

        def _excepthook(exc_type, exc_value, exc_tb):
            self._track_error(
                exc_type.__name__ if exc_type else "Exception",
                str(exc_value),
                "".join(traceback.format_exception(exc_type, exc_value, exc_tb)),
            )
            if self._prev_excepthook:
                self._prev_excepthook(exc_type, exc_value, exc_tb)

        sys.excepthook = _excepthook

        # Wrap threading.excepthook (Python 3.8+)
        if hasattr(threading, "excepthook"):
            self._prev_thread_excepthook = threading.excepthook

            def _thread_excepthook(args):
                self._track_error(
                    args.exc_type.__name__ if args.exc_type else "ThreadException",
                    str(args.exc_value),
                    "".join(
                        traceback.format_exception(
                            args.exc_type, args.exc_value, args.exc_tb
                        )
                    ),
                )
                if self._prev_thread_excepthook:
                    self._prev_thread_excepthook(args)

            threading.excepthook = _thread_excepthook

    def disable(self) -> None:
        if not self._enabled:
            return
        self._enabled = False

        if self._prev_excepthook is not None:
            sys.excepthook = self._prev_excepthook
            self._prev_excepthook = None

        if hasattr(threading, "excepthook") and self._prev_thread_excepthook is not None:
            threading.excepthook = self._prev_thread_excepthook
            self._prev_thread_excepthook = None

    def is_enabled(self) -> bool:
        return self._enabled

    def track_error(
        self,
        error: Exception,
        error_type: Optional[str] = None,
        severity: str = "error",
        distinct_id: str = "server_global",
    ) -> None:
        self._track_error(
            error_type or type(error).__name__,
            str(error),
            traceback.format_exc() or repr(error),
            severity=severity,
            distinct_id=distinct_id,
        )

    def _track_error(
        self,
        error_type: str,
        message: str,
        stack: str,
        severity: str = "critical",
        distinct_id: str = "server_global",
    ) -> None:
        try:
            session = self._session_manager.get_or_create(distinct_id, self._site_id)
            self._session_manager.ensure_confirmed(session, self._http)

            event = EventPayload(
                event_type="auto",
                event_name="server_error",
                event_category="error",
                session_id=session.session_id,
                user_id=session.distinct_id,
                custom_properties={
                    "error_type": error_type,
                    "message": message,
                    "stack": stack,
                    "runtime": "python",
                    "severity": severity,
                    "timestamp": _now_iso(),
                },
            )
            self._http.post_event(event)
        except Exception:
            pass  # Never let error tracking crash the process
