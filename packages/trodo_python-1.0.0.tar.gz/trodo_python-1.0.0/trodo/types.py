"""Type definitions for the Trodo Python SDK."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union

# ----------------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------------

@dataclass
class TrodoConfig:
    site_id: str
    api_base: str = "https://sdkapi.trodo.ai"
    timeout: int = 10
    retries: int = 2
    batch_enabled: bool = False
    batch_size: int = 50
    batch_flush_interval: float = 5.0
    auto_events: bool = False
    on_error: Optional[Any] = None  # Callable[[Exception], None]
    debug: bool = False


# ----------------------------------------------------------------------------
# Session
# ----------------------------------------------------------------------------

@dataclass
class ServerSession:
    session_id: str
    site_id: str
    distinct_id: str
    start_time: str      # ISO 8601
    last_activity: float  # epoch seconds
    confirmed: bool = False


# ----------------------------------------------------------------------------
# Events
# ----------------------------------------------------------------------------

@dataclass
class EventPayload:
    event_type: str      # 'custom' | 'auto'
    event_name: str
    event_category: str
    session_id: str
    user_id: str
    custom_properties: Dict[str, Any] = field(default_factory=dict)
    page_data: None = None
    auto_event_data: Optional[Dict[str, Any]] = None
    element_data: None = None
    override_data: None = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_type": self.event_type,
            "event_name": self.event_name,
            "event_category": self.event_category,
            "session_id": self.session_id,
            "user_id": self.user_id,
            "custom_properties": self.custom_properties,
            "page_data": self.page_data,
            "auto_event_data": self.auto_event_data,
            "element_data": self.element_data,
            "override_data": self.override_data,
        }


# ----------------------------------------------------------------------------
# Results
# ----------------------------------------------------------------------------

ApiResult = Dict[str, Any]
IdentifyResult = Dict[str, Any]
WalletAddressResult = Dict[str, Any]
ResetResult = Dict[str, Any]
