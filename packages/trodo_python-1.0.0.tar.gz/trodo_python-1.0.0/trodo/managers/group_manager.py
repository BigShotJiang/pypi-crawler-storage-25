"""Group management methods and GroupProfile proxy."""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional, Union

from ..api import endpoints
from ..types import ApiResult


class GroupProfile:
    def __init__(
        self,
        http_client: object,
        site_id: str,
        distinct_id: str,
        group_key: str,
        group_id: str,
    ) -> None:
        self._http = http_client
        self._site_id = site_id
        self._distinct_id = distinct_id
        self._group_key = group_key
        self._group_id = group_id

    def _base(self) -> Dict[str, Any]:
        return {
            "siteId": self._site_id,
            "userId": self._distinct_id,
            "groupKey": self._group_key,
            "groupId": self._group_id,
        }

    def _call(self, method: str, extra: Optional[Dict[str, Any]] = None) -> ApiResult:
        payload = {**self._base(), **(extra or {})}
        return self._http.post_group(  # type: ignore[attr-defined]
            f"{endpoints.GROUPS_PROFILE}/{method}", payload
        )

    def set(self, properties: Dict[str, Any]) -> ApiResult:
        return self._call("set", {"properties": properties})

    def set_once(self, properties: Dict[str, Any]) -> ApiResult:
        return self._call("set_once", {"properties": properties})

    def union(self, list_name: str, values: List[Any]) -> ApiResult:
        return self._call("union", {"listName": list_name, "values": values})

    def remove(self, list_name: str, value: Any) -> ApiResult:
        return self._call("remove", {"listName": list_name, "value": value})

    def unset(self, property: str) -> ApiResult:
        return self._call("unset", {"property": property})

    def increment(self, property: str, value: float = 1) -> ApiResult:
        return self._call("increment", {"property": property, "value": value})

    def append(self, property: str, value: Any) -> ApiResult:
        return self._call("append", {"property": property, "value": value})

    def delete(self) -> ApiResult:
        return self._call("delete")


class GroupManager:
    def __init__(
        self,
        http_client: object,
        site_id: str,
        get_distinct_id: Callable[[], str],
    ) -> None:
        self._http = http_client
        self._site_id = site_id
        self._get_distinct_id = get_distinct_id

    def _base(self) -> Dict[str, Any]:
        return {"siteId": self._site_id, "userId": self._get_distinct_id()}

    def set_group(
        self, group_key: str, group_id: Union[str, List[str]]
    ) -> ApiResult:
        return self._http.post_group(  # type: ignore[attr-defined]
            endpoints.GROUPS_SET,
            {**self._base(), "groupKey": group_key, "groupId": group_id},
        )

    def add_group(self, group_key: str, group_id: str) -> ApiResult:
        return self._http.post_group(  # type: ignore[attr-defined]
            endpoints.GROUPS_ADD,
            {**self._base(), "groupKey": group_key, "groupId": group_id},
        )

    def remove_group(self, group_key: str, group_id: str) -> ApiResult:
        return self._http.post_group(  # type: ignore[attr-defined]
            endpoints.GROUPS_REMOVE,
            {**self._base(), "groupKey": group_key, "groupId": group_id},
        )

    def get_group(self, group_key: str, group_id: str) -> GroupProfile:
        return GroupProfile(
            self._http,
            self._site_id,
            self._get_distinct_id(),
            group_key,
            group_id,
        )
