"""People (user profile) methods."""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional, Union

from ..api import endpoints
from ..types import ApiResult


class PeopleManager:
    def __init__(
        self,
        http_client: object,
        site_id: str,
        get_distinct_id: Callable[[], str],
    ) -> None:
        self._http = http_client
        self._site_id = site_id
        self._get_distinct_id = get_distinct_id

    def _base(self) -> Dict[str, Any]:
        return {"siteId": self._site_id, "userId": self._get_distinct_id()}

    def set(self, properties: Dict[str, Any]) -> ApiResult:
        return self._http.post_people(  # type: ignore[attr-defined]
            endpoints.PEOPLE_SET, {**self._base(), "properties": properties}
        )

    def set_once(self, properties: Dict[str, Any]) -> ApiResult:
        return self._http.post_people(  # type: ignore[attr-defined]
            endpoints.PEOPLE_SET_ONCE, {**self._base(), "properties": properties}
        )

    def unset(self, keys: Union[str, List[str]]) -> ApiResult:
        k = [keys] if isinstance(keys, str) else keys
        return self._http.post_people(  # type: ignore[attr-defined]
            endpoints.PEOPLE_UNSET, {**self._base(), "keys": k}
        )

    def increment(self, key: str, amount: float = 1) -> ApiResult:
        return self._http.post_people(  # type: ignore[attr-defined]
            endpoints.PEOPLE_INCREMENT, {**self._base(), "key": key, "amount": amount}
        )

    def append(self, key: str, values: List[Any]) -> ApiResult:
        return self._http.post_people(  # type: ignore[attr-defined]
            endpoints.PEOPLE_APPEND, {**self._base(), "key": key, "values": values}
        )

    def union(self, key: str, values: List[Any]) -> ApiResult:
        return self._http.post_people(  # type: ignore[attr-defined]
            endpoints.PEOPLE_UNION, {**self._base(), "key": key, "values": values}
        )

    def remove(self, key: str, values: List[Any]) -> ApiResult:
        return self._http.post_people(  # type: ignore[attr-defined]
            endpoints.PEOPLE_REMOVE, {**self._base(), "key": key, "values": values}
        )

    def track_charge(
        self, amount: float, properties: Optional[Dict[str, Any]] = None
    ) -> ApiResult:
        return self._http.post_people(  # type: ignore[attr-defined]
            endpoints.PEOPLE_TRACK_CHARGE,
            {**self._base(), "amount": amount, "properties": properties or {}},
        )

    def clear_charges(self) -> ApiResult:
        return self._http.post_people(  # type: ignore[attr-defined]
            endpoints.PEOPLE_CLEAR_CHARGES, self._base()
        )

    def delete_user(self) -> ApiResult:
        return self._http.post_people(  # type: ignore[attr-defined]
            endpoints.PEOPLE_DELETE_USER, self._base()
        )
