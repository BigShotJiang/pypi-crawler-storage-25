"""Thread-safe in-memory event queue."""

from __future__ import annotations

import threading
from typing import List

from ..types import EventPayload


class EventQueue:
    def __init__(self, max_size: int = 500) -> None:
        self._max_size = max_size
        self._queue: List[EventPayload] = []
        self._lock = threading.Lock()

    def enqueue(self, event: EventPayload) -> bool:
        """Returns True if flush threshold reached."""
        with self._lock:
            self._queue.append(event)
            return len(self._queue) >= self._max_size

    def drain(self) -> List[EventPayload]:
        """Atomically take all queued events."""
        with self._lock:
            events = list(self._queue)
            self._queue.clear()
            return events

    def size(self) -> int:
        with self._lock:
            return len(self._queue)
