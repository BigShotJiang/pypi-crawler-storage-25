"""UserContext — user-bound proxy for all Trodo SDK operations."""

from __future__ import annotations

import traceback
from typing import Any, Dict, List, Optional, Union, TYPE_CHECKING

from .managers.people_manager import PeopleManager
from .managers.group_manager import GroupManager, GroupProfile
from .types import (
    ApiResult,
    IdentifyResult,
    ResetResult,
    WalletAddressResult,
    EventPayload,
)
from .session.server_session import now_iso

if TYPE_CHECKING:
    from .api.http_client import HttpClient
    from .session.session_manager import SessionManager
    from .queue.event_queue import EventQueue
    from .queue.batch_flusher import BatchFlusher
    from .auto.auto_event_manager import AutoEventManager
    from .types import ServerSession


class UserContext:
    def __init__(
        self,
        distinct_id: str,
        site_id: str,
        http_client: "HttpClient",
        session_manager: "SessionManager",
        event_queue: Optional["EventQueue"],
        batch_flusher: Optional["BatchFlusher"],
        auto_event_manager: "AutoEventManager",
        session_id: Optional[str] = None,
    ) -> None:
        self._distinct_id = distinct_id
        self._site_id = site_id
        self._http = http_client
        self._session_manager = session_manager
        self._event_queue = event_queue
        self._batch_flusher = batch_flusher
        self._auto_event_manager = auto_event_manager
        self._session_id_override = session_id
        self._session: Optional["ServerSession"] = None

        # Eagerly initialise session
        self._session = self._session_manager.get_or_create(
            distinct_id, site_id, session_id
        )

        self.people = PeopleManager(
            http_client, site_id, lambda: self._get_distinct_id()
        )
        self._group_manager = GroupManager(
            http_client, site_id, lambda: self._get_distinct_id()
        )

    def _get_distinct_id(self) -> str:
        if self._session:
            return self._session.distinct_id
        return self._distinct_id

    def _get_session(self) -> "ServerSession":
        if not self._session:
            self._session = self._session_manager.get_or_create(
                self._distinct_id, self._site_id, self._session_id_override
            )
        return self._session

    def _send_event(
        self,
        event_name: str,
        properties: Optional[Dict[str, Any]] = None,
        category: str = "custom",
    ) -> None:
        session = self._get_session()
        self._session_manager.ensure_confirmed(session, self._http)

        event = EventPayload(
            event_type="custom",
            event_name=event_name,
            event_category=category,
            session_id=session.session_id,
            user_id=session.distinct_id,
            custom_properties=properties or {},
        )

        if self._event_queue and self._batch_flusher:
            should_flush = self._event_queue.enqueue(event)
            if should_flush:
                self._batch_flusher.flush()
        else:
            self._http.post_event(event)

    # --------------------------------------------------------------------------
    # Event Tracking
    # --------------------------------------------------------------------------

    def track(
        self,
        event_name: str,
        properties: Optional[Dict[str, Any]] = None,
        category: str = "custom",
    ) -> None:
        self._send_event(event_name, properties, category)

    def track_event(
        self,
        event_name: str,
        properties: Optional[Dict[str, Any]] = None,
        category: str = "custom",
    ) -> None:
        """Alias for track() — matches frontend SDK naming."""
        self._send_event(event_name, properties, category)

    # --------------------------------------------------------------------------
    # Identity
    # --------------------------------------------------------------------------

    def identify(self, identify_id: str) -> IdentifyResult:
        session = self._get_session()
        self._session_manager.ensure_confirmed(session, self._http)

        result = self._http.post_identify({
            "siteId": self._site_id,
            "sessionId": session.session_id,
            "userId": session.distinct_id,
            "distinctId": session.distinct_id,
            "identifyId": identify_id,
        })

        new_distinct_id = result.get("newDistinctId") or result.get("distinctId")
        if new_distinct_id and new_distinct_id != session.distinct_id:
            session.distinct_id = new_distinct_id

        return result

    def wallet_address(self, wallet_addr: str) -> WalletAddressResult:
        session = self._get_session()
        self._session_manager.ensure_confirmed(session, self._http)

        return self._http.post_wallet_address({
            "siteId": self._site_id,
            "sessionId": session.session_id,
            "userId": session.distinct_id,
            "distinctId": session.distinct_id,
            "walletAddress": wallet_addr,
        })

    def reset(self) -> ResetResult:
        session = self._get_session()
        result = self._http.post_reset({
            "siteId": self._site_id,
            "sessionId": session.session_id,
            "userId": session.distinct_id,
            "distinctId": session.distinct_id,
        })
        self._session_manager.invalidate(self._distinct_id)
        self._session = None
        return result

    # --------------------------------------------------------------------------
    # People — accessible via user.people.set(...) etc.
    # --------------------------------------------------------------------------

    # --------------------------------------------------------------------------
    # Groups
    # --------------------------------------------------------------------------

    def set_group(self, group_key: str, group_id: Union[str, List[str]]) -> ApiResult:
        self._get_session()
        return self._group_manager.set_group(group_key, group_id)

    def add_group(self, group_key: str, group_id: str) -> ApiResult:
        self._get_session()
        return self._group_manager.add_group(group_key, group_id)

    def remove_group(self, group_key: str, group_id: str) -> ApiResult:
        self._get_session()
        return self._group_manager.remove_group(group_key, group_id)

    def get_group(self, group_key: str, group_id: str) -> GroupProfile:
        return self._group_manager.get_group(group_key, group_id)

    # --------------------------------------------------------------------------
    # Error capture
    # --------------------------------------------------------------------------

    def capture_error(
        self,
        error: Exception,
        severity: str = "error",
    ) -> None:
        session = self._get_session()
        self._auto_event_manager.track_error(
            error,
            error_type=type(error).__name__,
            severity=severity,
            distinct_id=session.distinct_id,
        )

    # --------------------------------------------------------------------------
    # Auto events (per-context toggle)
    # --------------------------------------------------------------------------

    def enable_auto_events(self) -> None:
        self._auto_event_manager.enable()

    def disable_auto_events(self) -> None:
        self._auto_event_manager.disable()

    # --------------------------------------------------------------------------
    # Session info
    # --------------------------------------------------------------------------

    def get_session_id(self) -> Optional[str]:
        return self._session.session_id if self._session else None

    def get_current_distinct_id(self) -> str:
        return self._get_distinct_id()
