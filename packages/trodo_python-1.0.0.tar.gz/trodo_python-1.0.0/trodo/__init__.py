"""
trodo-python — Trodo Analytics SDK for Python

Usage (module-level singleton):
    import trodo
    trodo.init(site_id='your-site-id')
    user = trodo.for_user('user-123')
    user.track('purchase_completed', {'amount': 99.99})

Usage (class):
    from trodo import TrodoClient
    client = TrodoClient(site_id='your-site-id')
    user = client.for_user('user-123')
    user.track('purchase_completed', {'amount': 99.99})
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

from .client import TrodoClient
from .user_context import UserContext
from .managers.group_manager import GroupProfile
from .types import ApiResult, IdentifyResult, ResetResult, WalletAddressResult

__all__ = [
    "TrodoClient",
    "UserContext",
    "GroupProfile",
    "init",
    "for_user",
    "track",
    "identify",
    "wallet_address",
    "reset",
    "enable_auto_events",
    "disable_auto_events",
    "flush",
    "shutdown",
]

# ============================================================================
# Singleton convenience API
# ============================================================================

_client: Optional[TrodoClient] = None


def _get_client() -> TrodoClient:
    if _client is None:
        raise RuntimeError(
            "trodo-python: Call trodo.init(site_id=...) before using the SDK."
        )
    return _client


def init(
    site_id: str,
    api_base: str = "https://sdkapi.trodo.ai",
    timeout: int = 10,
    retries: int = 2,
    batch_enabled: bool = False,
    batch_size: int = 50,
    batch_flush_interval: float = 5.0,
    auto_events: bool = False,
    on_error: Optional[Any] = None,
    debug: bool = False,
) -> TrodoClient:
    """Initialise the singleton SDK instance."""
    global _client
    _client = TrodoClient(
        site_id=site_id,
        api_base=api_base,
        timeout=timeout,
        retries=retries,
        batch_enabled=batch_enabled,
        batch_size=batch_size,
        batch_flush_interval=batch_flush_interval,
        auto_events=auto_events,
        on_error=on_error,
        debug=debug,
    )
    return _client


def for_user(
    distinct_id: str,
    session_id: Optional[str] = None,
) -> UserContext:
    """Return a UserContext bound to the given distinctId."""
    return _get_client().for_user(distinct_id, session_id)


def track(
    distinct_id: str,
    event_name: str,
    properties: Optional[Dict[str, Any]] = None,
    category: str = "custom",
) -> None:
    """Track an event for a user (direct-call pattern)."""
    _get_client().track(distinct_id, event_name, properties, category)


def identify(distinct_id: str, identify_id: str) -> IdentifyResult:
    """Alias a user's distinctId to an external identifier."""
    return _get_client().identify(distinct_id, identify_id)


def wallet_address(distinct_id: str, wallet_addr: str) -> WalletAddressResult:
    """Associate a wallet address with a user."""
    return _get_client().wallet_address(distinct_id, wallet_addr)


def reset(distinct_id: str) -> ResetResult:
    """Reset a user's session."""
    return _get_client().reset(distinct_id)


def enable_auto_events() -> None:
    _get_client().enable_auto_events()


def disable_auto_events() -> None:
    _get_client().disable_auto_events()


def flush() -> None:
    """Flush any queued batch events."""
    _get_client().flush()


def shutdown() -> None:
    """Flush, stop timers, and disable auto events."""
    _get_client().shutdown()
