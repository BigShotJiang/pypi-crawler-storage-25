"""Async HTTP client using httpx (optional dependency)."""

from __future__ import annotations

import sys
import asyncio
from typing import Any, Callable, Dict, Optional

from ..types import ApiResult, EventPayload


class AsyncHttpClient:
    def __init__(
        self,
        api_base: str,
        site_id: str,
        timeout: int = 10,
        retries: int = 2,
        on_error: Optional[Callable[[Exception], None]] = None,
        debug: bool = False,
    ) -> None:
        try:
            import httpx  # noqa: F401
        except ImportError:
            raise ImportError(
                "trodo-python async support requires httpx: pip install trodo-python[async]"
            )

        self.api_base = api_base.rstrip("/")
        self.site_id = site_id
        self.timeout = timeout
        self.retries = retries
        self.on_error = on_error
        self.debug = debug

    def _log(self, *args: Any) -> None:
        if self.debug:
            sys.stderr.write(f"[trodo-python-async] {' '.join(str(a) for a in args)}\n")

    async def _request(
        self, path: str, body: Dict[str, Any], attempt: int = 0
    ) -> ApiResult:
        import httpx

        url = f"{self.api_base}{path}"
        self._log(f"POST {url}")
        headers = {
            "Content-Type": "application/json",
            "X-Trodo-Site-Id": self.site_id,
        }
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(url, json=body, headers=headers)
            if resp.status_code >= 500 and attempt < self.retries:
                delay = 2 ** attempt
                self._log(f"Retry {attempt + 1} after {delay}s")
                await asyncio.sleep(delay)
                return await self._request(path, body, attempt + 1)
            try:
                return resp.json()
            except Exception:
                return {}
        except Exception as exc:
            if attempt < self.retries:
                await asyncio.sleep(2 ** attempt)
                return await self._request(path, body, attempt + 1)
            self._log(f"Error: {exc}")
            if self.on_error:
                self.on_error(exc)
            return {}

    async def post_track(self, session_data: Dict[str, Any]) -> ApiResult:
        return await self._request("/api/sdk/track", {"sessionData": session_data})

    async def post_event(self, event: EventPayload) -> ApiResult:
        return await self._request("/api/events", event.to_dict())

    async def post_bulk_events(self, events: list) -> ApiResult:
        return await self._request(
            "/api/events/bulk", {"events": [e.to_dict() for e in events]}
        )

    async def post_identify(self, payload: Dict[str, Any]) -> ApiResult:
        return await self._request("/api/sdk/identify", payload)

    async def post_wallet_address(self, payload: Dict[str, Any]) -> ApiResult:
        return await self._request("/api/sdk/wallet-address", payload)

    async def post_reset(self, payload: Dict[str, Any]) -> ApiResult:
        return await self._request("/api/sdk/reset", payload)

    async def post_people(self, path: str, payload: Dict[str, Any]) -> ApiResult:
        return await self._request(path, payload)

    async def post_group(self, path: str, payload: Dict[str, Any]) -> ApiResult:
        return await self._request(path, payload)
