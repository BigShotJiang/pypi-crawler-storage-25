"""Thread-safe in-process session cache."""

from __future__ import annotations

import threading
from typing import Dict, Optional

from ..types import ServerSession
from .server_session import build_session_payload, create_server_session


class SessionManager:
    def __init__(self) -> None:
        self._sessions: Dict[str, ServerSession] = {}
        self._lock = threading.Lock()
        self._confirmation_locks: Dict[str, threading.Event] = {}
        self._confirmation_started: Dict[str, bool] = {}

    def get_or_create(
        self,
        distinct_id: str,
        site_id: str,
        session_id: Optional[str] = None,
    ) -> ServerSession:
        with self._lock:
            if distinct_id in self._sessions:
                return self._sessions[distinct_id]
            session = create_server_session(site_id, distinct_id, session_id)
            self._sessions[distinct_id] = session
            return session

    def ensure_confirmed(self, session: ServerSession, http_client: object) -> None:
        """
        Block until the session has been confirmed via POST /api/sdk/track.
        Idempotent — concurrent callers share a single confirmation attempt.
        """
        if session.confirmed:
            return

        key = session.distinct_id

        with self._lock:
            if session.confirmed:
                return
            # Check if confirmation already in-flight
            if key not in self._confirmation_locks:
                event = threading.Event()
                self._confirmation_locks[key] = event
                should_run = True
            else:
                event = self._confirmation_locks[key]
                should_run = False

        if should_run:
            try:
                payload = build_session_payload(session)
                http_client.post_track(payload)  # type: ignore[attr-defined]
            except Exception:
                pass  # Confirmation failure is non-fatal
            finally:
                session.confirmed = True
                with self._lock:
                    self._confirmation_locks.pop(key, None)
                event.set()
        else:
            event.wait(timeout=10)

    def invalidate(self, distinct_id: str) -> None:
        with self._lock:
            self._sessions.pop(distinct_id, None)
            self._confirmation_locks.pop(distinct_id, None)

    def get_global_session(self, site_id: str) -> ServerSession:
        return self.get_or_create("server_global", site_id)
