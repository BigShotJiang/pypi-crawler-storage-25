# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.


from __future__ import annotations

from dataclasses import dataclass

from ... import telemetry_events
from .._qre import Trace
from .._application import Application
from ..interop import trace_from_qir


@dataclass
class QIRApplication(Application[None]):
    """Application that produces a resource estimation trace from base profile QIR code.

    Accepts QIR input as LLVM IR text or bitcode.  The QIR input must adhere to
    the base profile.

    Attributes:
        input (str | bytes): QIR input as LLVM IR text (str) or
            bitcode (bytes).
    """

    input: str | bytes

    def __post_init__(self):
        """Log telemetry for QIRApplication creation."""
        telemetry_events.on_qre_application_created("QIRApplication")

    def get_trace(self, parameters: None = None) -> Trace:
        """Return the resource estimation trace for the QIR program.

        Args:
            parameters (None): Unused. Defaults to None.

        Returns:
            Trace: The resource estimation trace.
        """
        return trace_from_qir(self.input)
