# Freesolo Agent CLI

Thin command-line client for queuing Freesolo backend training jobs.

The public package does not contain the Codex/GitHub/training worker. It only:

- validates JSON or interactive setup input
- prompts for or reads a request-provided Freesolo API key
- uploads a local dataset file or folder when `datasetPath` is provided
- enqueues `/api/training/jobs`
- polls `/api/training/jobs/{job_id}` until the backend worker finishes

The private worker implementation lives under `backend/src/training_agent`.

## Run

Interactive setup starts when the CLI is launched from a terminal without JSON
input:

```bash
uv run freesolo
```

Automation can call the JSON interface:

```bash
uv run freesolo '{"operation":"draft","apiKey":"fslo_...","orgId":"org_123","input":{"sourceRepoUrl":"https://github.com/acme/app.git","prompt":"Create a contract for the feature behavior..."}}'
```

Supported operations are `draft`, `edit`, `optimize`, and `training`.

To provide a local dataset, pass `datasetPath` as either a file or folder path.
The CLI uploads it to the backend first, then the backend worker materializes it
as read-only context for the training agent:

```bash
uv run freesolo '{"operation":"training","apiKey":"fslo_...","orgId":"org_123","input":{"targetRepoUrl":"https://github.com/acme/app-freesolo-training","datasetPath":"/mnt/data/my_dataset"}}'
```

## Environment

The CLI does not require environment variables.

- Interactive mode prompts for the Freesolo API key.
- JSON mode requires top-level `apiKey`.
- The backend URL and job polling interval use CLI defaults.

Private GitHub app credentials, Codex settings, Tinker dependencies, and training
runtime configuration belong to the backend worker, not this CLI package.
