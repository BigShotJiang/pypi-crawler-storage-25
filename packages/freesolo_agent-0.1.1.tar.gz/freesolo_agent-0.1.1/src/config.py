from __future__ import annotations

import re

HELP_COMMANDS = {"help", "-h", "--help"}
INTERACTIVE_COMMANDS = {"setup"}

TRAINING_JOBS_PATH = "/api/training/jobs"
DEFAULT_FREESOLO_BASE_URL = "https://api.freesolo.co"
DEFAULT_JOB_POLL_INTERVAL_SECONDS = 5.0
JOB_HEARTBEAT_SECONDS = 30.0

GITHUB_APP_SLUG = "freesolo-agent"
GITHUB_APP_INSTALL_URL = f"https://github.com/apps/{GITHUB_APP_SLUG}/installations/new"

MAX_ENVIRONMENT_VARIABLES = 100
MAX_ENVIRONMENT_VALUE_LENGTH = 100_000
ENVIRONMENT_VARIABLE_NAME_PATTERN = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
