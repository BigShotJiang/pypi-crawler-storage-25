from __future__ import annotations

import asyncio
import json
import sys
import traceback
from typing import cast

from client.auth import verify_freesolo_api_key
from client.jobs import run_backend_training_job
from config import HELP_COMMANDS, INTERACTIVE_COMMANDS
from client.datasets import sync_dataset_if_present
from commands.setup import run_interactive
from core.output import print_human, write_json
from core.types import JsonDict
from core.validation import validate_request


def read_input() -> str:
    if len(sys.argv) > 1:
        return sys.argv[1]
    return sys.stdin.read()


def usage() -> str:
    return "\n".join(
        [
            "Usage:",
            "  freesolo",
            "  freesolo setup",
            "  freesolo '<json request>'",
            "",
            "No-argument TTY usage starts interactive setup. JSON usage enqueues backend",
            "draft, edit, optimize, and training jobs, then polls until completion.",
            "Pass top-level apiKey and orgId for backend jobs.",
            "Pass input.datasetPath as a local dataset file or folder path when you want",
            "the backend worker to use uploaded data as a read-only source.",
            "Pass environmentVariables or input.environmentVariables as KEY/value pairs",
            "to make ephemeral env vars available only during the backend worker run.",
        ]
    )


async def run() -> int:
    try:
        if len(sys.argv) > 1 and sys.argv[1] in HELP_COMMANDS:
            print(usage())
            return 0

        if (len(sys.argv) > 1 and sys.argv[1] in INTERACTIVE_COMMANDS) or (
            len(sys.argv) == 1 and sys.stdin.isatty()
        ):
            return await run_interactive()

        parsed_json = json.loads(read_input())
        operation, bot_input, org_id, api_key = validate_request(parsed_json)
        verify_freesolo_api_key(api_key)
        dataset_id = sync_dataset_if_present(bot_input, api_key=api_key)
        result_json, job_id = await run_backend_training_job(
            operation,
            org_id,
            bot_input,
            api_key=api_key,
            dataset_id=dataset_id,
        )
        if dataset_id:
            result_json["datasetId"] = dataset_id
        write_json(
            sys.stdout,
            cast(JsonDict, {"ok": True, "result": result_json, "jobId": job_id}),
        )
        return 0
    except ValueError as error:
        print_human(str(error))
        write_json(sys.stderr, {"ok": False, "error": str(error)})
        return 1
    except Exception as error:
        traceback.print_exc(file=sys.stderr)
        write_json(sys.stderr, {"ok": False, "error": str(error)})
        return 1


def main() -> None:
    raise SystemExit(asyncio.run(run()))
