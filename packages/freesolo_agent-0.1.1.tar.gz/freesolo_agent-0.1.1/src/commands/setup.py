from __future__ import annotations

import getpass
import sys
import webbrowser
from typing import cast

from client.auth import verify_freesolo_api_key
from client.jobs import run_backend_training_job
from config import GITHUB_APP_INSTALL_URL, MAX_ENVIRONMENT_VARIABLES
from client.datasets import sync_dataset_if_present
from core.output import print_human, write_json
from core.types import DraftInput, JsonDict
from core.validation import (
    required_string,
    validate_dataset_path,
    validate_environment_variables,
)


def prompt_required_line(label: str, *, default: str | None = None) -> str:
    default_suffix = f" [{default}]" if default else ""
    while True:
        print(f"{label}{default_suffix}: ", file=sys.stderr, end="", flush=True)
        value = sys.stdin.readline()
        if value == "":
            raise EOFError(f"Missing input for {label}")
        trimmed = value.strip()
        if trimmed:
            return trimmed
        if default:
            return default
        print_human(f"{label} is required.")


def prompt_optional_line(label: str) -> str | None:
    print(f"{label} (optional, press Enter to skip): ", file=sys.stderr, end="", flush=True)
    value = sys.stdin.readline()
    if value == "":
        return None
    trimmed = value.strip()
    return trimmed or None


def prompt_optional_dataset_path() -> str | None:
    while True:
        try:
            return validate_dataset_path(prompt_optional_line("Dataset file or folder path"))
        except ValueError as error:
            print_human(str(error))


def prompt_environment_variables() -> dict[str, str]:
    variables: dict[str, str] = {}
    print_human("Environment variables for the backend training worker are optional.")
    print_human("Enter variable names one at a time. Press Enter on the name prompt to finish.")
    while True:
        raw_name = prompt_optional_line("Environment variable name")
        if raw_name is None:
            return variables
        name = raw_name.strip()
        try:
            validate_environment_variables({name: ""}, "environmentVariables")
        except ValueError as error:
            print_human(str(error))
            continue
        variables[name] = getpass.getpass(f"Value for {name}: ", stream=sys.stderr)
        if len(variables) >= MAX_ENVIRONMENT_VARIABLES:
            print_human(f"Reached the limit of {MAX_ENVIRONMENT_VARIABLES} variables.")
            return variables


def prompt_secret(label: str) -> str:
    while True:
        try:
            value = getpass.getpass(f"{label}: ", stream=sys.stderr).strip()
        except EOFError as error:
            raise EOFError(f"Missing input for {label}") from error
        if value:
            return value
        print_human(f"{label} is required.")


def prompt_freesolo_api_key() -> str:
    while True:
        api_key = prompt_secret("Freesolo API key")
        try:
            verify_freesolo_api_key(api_key)
            print_human("Freesolo API key accepted.")
            return api_key
        except ValueError as error:
            print_human(str(error))


def prompt_multiline_description() -> str:
    while True:
        print_human("Describe what you are trying to do.")
        print_human("Finish with a blank line.")
        lines: list[str] = []
        while True:
            line = sys.stdin.readline()
            if line == "":
                if not lines:
                    raise EOFError("Missing prompt")
                break
            stripped = line.rstrip("\n")
            if not stripped:
                if lines:
                    break
                print_human("Prompt is required.")
                continue
            lines.append(stripped)

        prompt = "\n".join(lines)
        try:
            return required_string(prompt, "prompt", 20, 8_000)
        except ValueError as error:
            print_human(str(error))


def offer_github_app_install() -> None:
    print_human("If the source repository is private, connect the Freesolo GitHub App:")
    print_human(GITHUB_APP_INSTALL_URL)
    opened = webbrowser.open(GITHUB_APP_INSTALL_URL, new=2)
    if not opened:
        print_human("Open the URL above in your browser.")
    print(
        "Press Enter once GitHub access is connected, or press Enter to continue for public repos: ",
        file=sys.stderr,
        end="",
        flush=True,
    )
    sys.stdin.readline()


async def run_interactive() -> int:
    api_key = prompt_freesolo_api_key()
    org_id = required_string(
        prompt_required_line("Freesolo org ID"),
        "orgId",
        1,
        100,
    )

    source_repo_url = required_string(
        prompt_required_line("Source repository URL"),
        "sourceRepoUrl",
        1,
        300,
    )
    offer_github_app_install()
    prompt = prompt_multiline_description()
    source_branch = prompt_optional_line("Source branch")
    dataset_path = prompt_optional_dataset_path()
    environment_variables = prompt_environment_variables()
    input_data = DraftInput(
        source_repo_url=source_repo_url,
        source_branch=source_branch,
        prompt=prompt,
        dataset_path=dataset_path,
        environment_variables=environment_variables,
    )
    print_human("Setup inputs collected. Queuing backend draft job.")
    dataset_id = sync_dataset_if_present(input_data, api_key=api_key)
    result_json, job_id = await run_backend_training_job(
        "draft",
        org_id,
        input_data,
        api_key=api_key,
        dataset_id=dataset_id,
    )
    if dataset_id:
        result_json["datasetId"] = dataset_id
    target_repo_url = result_json.get("targetRepoUrl")
    if isinstance(target_repo_url, str) and target_repo_url:
        print_human(f"Drafted training contract in {target_repo_url}")
    write_json(
        sys.stdout,
        cast(JsonDict, {"ok": True, "result": result_json, "jobId": job_id}),
    )
    return 0
