from __future__ import annotations

import httpx
from freesolo.utils.storage import FreesoloStorageClient

from config import DEFAULT_FREESOLO_BASE_URL


def require_freesolo_api_key(api_key: str) -> str:
    value = api_key.strip()
    if not value:
        raise ValueError("Freesolo API key is required")
    return value


def verify_freesolo_api_key(api_key: str) -> None:
    try:
        FreesoloStorageClient(
            api_key=require_freesolo_api_key(api_key),
            base_url=DEFAULT_FREESOLO_BASE_URL,
        ).verify_api_key()
    except httpx.HTTPStatusError as error:
        if error.response.status_code in {401, 403}:
            raise ValueError(
                "Freesolo API key was rejected by Freesolo. Create a new API key "
                "in the Freesolo app for the org that should own this run."
            ) from error
        raise
