from __future__ import annotations

import asyncio
import time
from collections.abc import Mapping
from typing import Any, cast

import httpx
from freesolo.utils.storage import FreesoloStorageClient

from client.auth import require_freesolo_api_key
from config import (
    DEFAULT_FREESOLO_BASE_URL,
    DEFAULT_JOB_POLL_INTERVAL_SECONDS,
    JOB_HEARTBEAT_SECONDS,
    TRAINING_JOBS_PATH,
)
from core.output import print_human
from core.types import (
    DraftInput,
    EditInput,
    OptimizeInput,
    TrainingInput,
    TrainingInputPayload,
)


def job_poll_interval_seconds() -> float:
    return DEFAULT_JOB_POLL_INTERVAL_SECONDS


def environment_variables_from_input(bot_input: TrainingInputPayload) -> dict[str, str]:
    return dict(bot_input.environment_variables)


def backend_training_payload(
    operation: str,
    org_id: str,
    bot_input: TrainingInputPayload,
    dataset_id: str | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {"action": operation, "orgId": org_id}
    if dataset_id is not None:
        payload["datasetId"] = dataset_id

    environment_variables = environment_variables_from_input(bot_input)
    if environment_variables:
        payload["environmentVariables"] = environment_variables

    if operation == "draft":
        draft_input = cast(DraftInput, bot_input)
        payload.update(
            {
                "sourceRepoUrl": draft_input.source_repo_url,
                "sourceBranch": draft_input.source_branch,
                "prompt": draft_input.prompt,
            }
        )
        return payload
    if operation == "edit":
        edit_input = cast(EditInput, bot_input)
        payload.update(
            {
                "targetRepoUrl": edit_input.target_repo_url,
                "targetBranch": edit_input.target_branch,
                "targetWorktreePath": edit_input.target_worktree_path,
                "prompt": edit_input.prompt,
            }
        )
        return payload
    if operation == "optimize":
        optimize_input = cast(OptimizeInput, bot_input)
        payload.update(
            {
                "targetRepoUrl": optimize_input.target_repo_url,
                "targetBranch": optimize_input.target_branch,
                "targetWorktreePath": optimize_input.target_worktree_path,
            }
        )
        return payload

    training_input = cast(TrainingInput, bot_input)
    payload.update(
        {
            "targetRepoUrl": training_input.target_repo_url,
            "targetBranch": training_input.target_branch,
            "targetWorktreePath": training_input.target_worktree_path,
        }
    )
    return payload


def backend_headers(
    storage_client: FreesoloStorageClient,
    *,
    track_usage: bool = False,
) -> dict[str, str]:
    headers = {
        "Authorization": f"Bearer {storage_client.api_key}",
        "Content-Type": "application/json",
    }
    if track_usage:
        headers["X-Freesolo-Function"] = "freesolo_agent.run_backend_training_job"
    return headers


def backend_json_response(response: httpx.Response, path: str) -> dict[str, Any]:
    try:
        payload = response.json() if response.content else {}
    except ValueError:
        payload = {}
    if response.is_error:
        raise RuntimeError(backend_error_message(payload, f"Freesolo {path} failed"))
    if not isinstance(payload, dict):
        raise RuntimeError(f"Freesolo {path} returned a non-object response")
    return payload


def backend_error_message(payload: object, fallback: str) -> str:
    if not isinstance(payload, dict):
        return fallback
    error = payload.get("error")
    if isinstance(error, str) and error.strip():
        return error
    detail = payload.get("detail")
    if isinstance(detail, str) and detail.strip():
        return detail
    return fallback


def job_from_response(payload: dict[str, Any]) -> dict[str, Any]:
    job = payload.get("job")
    if not isinstance(job, dict):
        raise RuntimeError("Freesolo training job response did not include a job object")
    return dict(job)


def job_id(job: Mapping[str, Any]) -> str:
    value = job.get("jobId")
    if not isinstance(value, str) or not value:
        raise RuntimeError("Freesolo training job response missing jobId")
    return value


def job_status(job: Mapping[str, Any]) -> str:
    value = job.get("status")
    if not isinstance(value, str) or not value:
        raise RuntimeError("Freesolo training job response missing status")
    return value


def job_result(job: Mapping[str, Any]) -> dict[str, Any]:
    result = job.get("result")
    if not isinstance(result, dict):
        raise RuntimeError("Freesolo training job succeeded without a result object")
    return dict(result)


async def run_backend_training_job(
    operation: str,
    org_id: str,
    bot_input: TrainingInputPayload,
    *,
    api_key: str,
    dataset_id: str | None = None,
) -> tuple[dict[str, Any], str]:
    storage_client = FreesoloStorageClient(
        api_key=require_freesolo_api_key(api_key),
        base_url=DEFAULT_FREESOLO_BASE_URL,
    )
    enqueue_headers = backend_headers(storage_client, track_usage=True)
    poll_headers = backend_headers(storage_client)
    poll_interval_seconds = job_poll_interval_seconds()
    payload = backend_training_payload(operation, org_id, bot_input, dataset_id=dataset_id)

    async with httpx.AsyncClient(timeout=storage_client.timeout_seconds) as client:
        enqueue_response = await client.post(
            f"{storage_client.base_url}{TRAINING_JOBS_PATH}",
            headers=enqueue_headers,
            json=payload,
        )
        job = job_from_response(backend_json_response(enqueue_response, TRAINING_JOBS_PATH))
        current_job_id = job_id(job)
        print_human(f"Queued backend {operation} job {current_job_id}.")
        return await poll_backend_training_job(
            client=client,
            base_url=storage_client.base_url,
            headers=poll_headers,
            job_id=current_job_id,
            initial_job=job,
            poll_interval_seconds=poll_interval_seconds,
        )


async def poll_backend_training_job(
    *,
    client: httpx.AsyncClient,
    base_url: str,
    headers: dict[str, str],
    job_id: str,
    initial_job: dict[str, Any],
    poll_interval_seconds: float,
) -> tuple[dict[str, Any], str]:
    job = initial_job
    last_status: str | None = None
    last_heartbeat_at = 0.0
    path = f"{TRAINING_JOBS_PATH}/{job_id}"
    while True:
        status = job_status(job)
        now = time.monotonic()
        if status != last_status:
            print_human(f"Backend job {job_id} is {status}.")
            last_status = status
            last_heartbeat_at = now
        elif now - last_heartbeat_at >= JOB_HEARTBEAT_SECONDS:
            print_human(f"Backend job {job_id} is still {status}.")
            last_heartbeat_at = now

        if status == "succeeded":
            return job_result(job), job_id
        if status in {"failed", "cancelled"}:
            error = job.get("error")
            if not isinstance(error, str) or not error.strip():
                error = f"Backend training job {job_id} {status}"
            raise RuntimeError(error)

        await asyncio.sleep(poll_interval_seconds)
        poll_response = await client.get(f"{base_url}{path}", headers=headers)
        job = job_from_response(backend_json_response(poll_response, path))
