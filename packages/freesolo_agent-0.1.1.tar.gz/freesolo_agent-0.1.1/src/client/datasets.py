from __future__ import annotations

from pathlib import Path

import httpx
from freesolo.utils.storage import FreesoloStorageClient

from client.auth import require_freesolo_api_key
from config import DEFAULT_FREESOLO_BASE_URL
from core.types import TrainingInputPayload


def dataset_path_from_input(bot_input: TrainingInputPayload) -> str | None:
    return bot_input.dataset_path


def sync_dataset_if_present(bot_input: TrainingInputPayload, *, api_key: str) -> str | None:
    dataset_path = dataset_path_from_input(bot_input)
    if dataset_path is None:
        return None
    try:
        return FreesoloStorageClient(
            api_key=require_freesolo_api_key(api_key),
            base_url=DEFAULT_FREESOLO_BASE_URL,
        ).upload_dataset(dataset_path, name=Path(dataset_path).name)
    except httpx.HTTPStatusError as error:
        if error.response.status_code in {401, 403}:
            raise ValueError(
                "Freesolo API key was rejected while uploading the dataset. Use an active "
                "key for the org that should own datasets and training runs."
            ) from error
        raise
