from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path

from config import (
    ENVIRONMENT_VARIABLE_NAME_PATTERN,
    MAX_ENVIRONMENT_VALUE_LENGTH,
    MAX_ENVIRONMENT_VARIABLES,
)
from core.types import DraftInput, EditInput, OptimizeInput, TrainingInput


def as_mapping(value: object) -> Mapping[str, object]:
    if not isinstance(value, dict):
        raise ValueError("Input must be a JSON object")
    return value


def optional_string(value: object, name: str, max_length: int) -> str | None:
    if value is None or value == "":
        return None
    if not isinstance(value, str):
        raise ValueError(f"{name} must be a string")
    trimmed = value.strip()
    if not trimmed:
        return None
    if len(trimmed) > max_length:
        raise ValueError(f"{name} must be at most {max_length} characters")
    return trimmed


def required_string(value: object, name: str, min_length: int, max_length: int) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{name} must be a string")
    trimmed = value.strip()
    if len(trimmed) < min_length:
        raise ValueError(f"{name} must be at least {min_length} characters")
    if len(trimmed) > max_length:
        raise ValueError(f"{name} must be at most {max_length} characters")
    return trimmed


def validate_dataset_path(value: object) -> str | None:
    raw_path = optional_string(value, "datasetPath", 2_000)
    if raw_path is None:
        return None

    try:
        resolved = Path(raw_path).expanduser().resolve(strict=True)
    except OSError as error:
        raise ValueError(f"datasetPath must exist: {raw_path}") from error
    if not resolved.is_file() and not resolved.is_dir():
        raise ValueError("datasetPath must be a file or folder")
    return str(resolved)


def validate_environment_variables(value: object, name: str) -> dict[str, str]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ValueError(f"{name} must be an object of environment variable names to values")
    if len(value) > MAX_ENVIRONMENT_VARIABLES:
        raise ValueError(f"{name} must include at most {MAX_ENVIRONMENT_VARIABLES} variables")

    variables: dict[str, str] = {}
    for raw_key, raw_value in value.items():
        if not isinstance(raw_key, str):
            raise ValueError(f"{name} keys must be strings")
        key = raw_key.strip()
        if not ENVIRONMENT_VARIABLE_NAME_PATTERN.fullmatch(key):
            raise ValueError(f"{name} key {raw_key!r} must be a valid environment variable name")
        if not isinstance(raw_value, str):
            raise ValueError(f"{name}.{key} must be a string")
        if len(raw_value) > MAX_ENVIRONMENT_VALUE_LENGTH:
            raise ValueError(f"{name}.{key} is too large")
        variables[key] = raw_value
    return variables


def merged_environment_variables(
    request_environment_variables: dict[str, str],
    input_payload: Mapping[str, object],
) -> dict[str, str]:
    variables = dict(request_environment_variables)
    variables.update(
        validate_environment_variables(
            input_payload.get("environmentVariables"),
            "input.environmentVariables",
        )
    )
    return variables


def validate_draft_input(
    value: object,
    request_environment_variables: dict[str, str] | None = None,
) -> DraftInput:
    payload = as_mapping(value)
    return DraftInput(
        source_repo_url=required_string(payload.get("sourceRepoUrl"), "sourceRepoUrl", 1, 300),
        source_branch=optional_string(payload.get("sourceBranch"), "sourceBranch", 120),
        prompt=required_string(payload.get("prompt"), "prompt", 20, 8_000),
        dataset_path=validate_dataset_path(payload.get("datasetPath")),
        environment_variables=merged_environment_variables(
            request_environment_variables or {},
            payload,
        ),
    )


def validate_edit_input(
    value: object,
    request_environment_variables: dict[str, str] | None = None,
) -> EditInput:
    payload = as_mapping(value)
    return EditInput(
        target_repo_url=required_string(payload.get("targetRepoUrl"), "targetRepoUrl", 1, 300),
        target_branch=optional_string(payload.get("targetBranch"), "targetBranch", 120),
        target_worktree_path=optional_string(
            payload.get("targetWorktreePath"),
            "targetWorktreePath",
            2_000,
        ),
        prompt=required_string(payload.get("prompt"), "prompt", 20, 8_000),
        dataset_path=validate_dataset_path(payload.get("datasetPath")),
        environment_variables=merged_environment_variables(
            request_environment_variables or {},
            payload,
        ),
    )


def validate_optimize_input(
    value: object,
    request_environment_variables: dict[str, str] | None = None,
) -> OptimizeInput:
    payload = as_mapping(value)
    return OptimizeInput(
        target_repo_url=required_string(payload.get("targetRepoUrl"), "targetRepoUrl", 1, 300),
        target_branch=optional_string(payload.get("targetBranch"), "targetBranch", 120),
        target_worktree_path=optional_string(
            payload.get("targetWorktreePath"),
            "targetWorktreePath",
            2_000,
        ),
        dataset_path=validate_dataset_path(payload.get("datasetPath")),
        environment_variables=merged_environment_variables(
            request_environment_variables or {},
            payload,
        ),
    )


def validate_training_input(
    value: object,
    request_environment_variables: dict[str, str] | None = None,
) -> TrainingInput:
    payload = as_mapping(value)
    return TrainingInput(
        target_repo_url=required_string(payload.get("targetRepoUrl"), "targetRepoUrl", 1, 300),
        target_branch=optional_string(payload.get("targetBranch"), "targetBranch", 120),
        target_worktree_path=optional_string(
            payload.get("targetWorktreePath"),
            "targetWorktreePath",
            2_000,
        ),
        dataset_path=validate_dataset_path(payload.get("datasetPath")),
        environment_variables=merged_environment_variables(
            request_environment_variables or {},
            payload,
        ),
    )


def validate_request(
    value: object,
) -> tuple[str, DraftInput | EditInput | OptimizeInput | TrainingInput, str, str]:
    payload = as_mapping(value)
    api_key = request_api_key(payload)
    org_id = request_org_id(payload)
    if org_id is None:
        raise ValueError(
            "orgId is required for backend training jobs."
        )

    request_environment_variables = validate_environment_variables(
        payload.get("environmentVariables"),
        "environmentVariables",
    )
    operation = payload.get("operation")
    if operation == "draft":
        return (
            operation,
            validate_draft_input(payload.get("input"), request_environment_variables),
            org_id,
            api_key,
        )
    if operation == "edit":
        return (
            operation,
            validate_edit_input(payload.get("input"), request_environment_variables),
            org_id,
            api_key,
        )
    if operation == "optimize":
        return (
            operation,
            validate_optimize_input(payload.get("input"), request_environment_variables),
            org_id,
            api_key,
        )
    if operation == "training":
        return (
            operation,
            validate_training_input(payload.get("input"), request_environment_variables),
            org_id,
            api_key,
        )
    raise ValueError("operation must be 'draft', 'edit', 'optimize', or 'training'")


def request_org_id(payload: Mapping[str, object]) -> str | None:
    return optional_string(payload.get("orgId"), "orgId", 100)


def request_api_key(payload: Mapping[str, object]) -> str:
    return required_string(payload.get("apiKey"), "apiKey", 1, 10_000)
