from __future__ import annotations

import json
import sys
from typing import TextIO

from core.types import JsonDict


def print_human(message: str = "") -> None:
    print(message, file=sys.stderr, flush=True)


def write_json(stream: TextIO, payload: JsonDict) -> None:
    stream.write(f"{json.dumps(payload, separators=(',', ':'))}\n")
