"""Shared public CLI helpers."""
