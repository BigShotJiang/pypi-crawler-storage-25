from __future__ import annotations

from dataclasses import dataclass, field
from typing import TypeAlias

JsonValue: TypeAlias = str | int | float | bool | None | list["JsonValue"] | dict[str, "JsonValue"]
JsonDict: TypeAlias = dict[str, JsonValue]


@dataclass(frozen=True)
class DraftInput:
    source_repo_url: str
    prompt: str
    source_branch: str | None = None
    dataset_path: str | None = None
    environment_variables: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class EditInput:
    target_repo_url: str
    prompt: str
    target_branch: str | None = None
    target_worktree_path: str | None = None
    dataset_path: str | None = None
    environment_variables: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class OptimizeInput:
    target_repo_url: str
    target_branch: str | None = None
    target_worktree_path: str | None = None
    dataset_path: str | None = None
    environment_variables: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class TrainingInput:
    target_repo_url: str
    target_branch: str | None = None
    target_worktree_path: str | None = None
    dataset_path: str | None = None
    environment_variables: dict[str, str] = field(default_factory=dict)


TrainingInputPayload: TypeAlias = DraftInput | EditInput | OptimizeInput | TrainingInput
