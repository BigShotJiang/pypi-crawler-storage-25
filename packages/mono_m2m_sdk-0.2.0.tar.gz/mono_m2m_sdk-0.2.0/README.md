# @monospay/sdk

Financial infrastructure for autonomous AI agents.

Your agent can think. Now it can pay.

```bash
npm install @monospay/sdk
```

---

## Quickstart

```typescript
import { Mono } from "@monospay/sdk";

const mono = new Mono({ apiKey: process.env.MONO_API_KEY });

// Check available budget
const { available_usdc } = await mono.balance();
console.log(`Budget: $${available_usdc}`);  // → Budget: $50.00

// Charge for a task
await mono.charge(0.003, "gpt-4o reasoning call");

// Pay another agent for a completed task
await mono.transfer({ to: "agent_data_02", amount: 1.50, memo: "dataset retrieval" });
```

That's it. No wallets. No gas. No KYC.

---

## How it works

monospay is a USDC settlement layer built on Base. Your agent gets a budget
assigned by a developer through the dashboard. Every `charge()` or `transfer()`
is an off-chain ledger write — confirmed in 15ms, settled on-chain periodically.

```
Developer (dashboard) → funds agent with USDC
Agent (your code)     → spends via mono.charge() / mono.transfer()
Dashboard             → shows real-time balance as agent spends
```

---

## API reference

### `mono.balance()`
Returns the agent's current off-chain ledger balance.

```typescript
const balance = await mono.balance();
// { available_usdc: 47.25, agent_id: "agent_01", currency: "USDC" }
```

### `mono.charge(amount, memo?)`
Deducts `amount` USDC from this agent's budget. Use for any cost your agent incurs.

```typescript
await mono.charge(0.02, "web search call");
// Throws MonoInsufficientBalance if budget is exhausted
```

### `mono.transfer({ to, amount, memo? })`
Pays another agent within the same monospay account. Off-chain, instant.

```typescript
await mono.transfer({ to: "agent_executor", amount: 5.00, memo: "task completed" });
```

### `mono.inference(service, payload)`
Pay-per-use LLM proxy. Calls the upstream model and auto-deducts cost.

```typescript
const result = await mono.inference("openai_gpt4o", {
  messages: [{ role: "user", content: "Summarize this document." }]
});
```

---

## LangChain integration

```typescript
import { MonoPayTool } from "@monospay/sdk/langchain";

const tools = [
  new MonoPayTool({ apiKey: process.env.MONO_API_KEY }),
  // ... your other tools
];

const agent = await createReactAgent({ llm, tools });
```

---

## Error handling

```typescript
import { MonoInsufficientBalance, MonoAuthError } from "@monospay/sdk";

try {
  await mono.charge(100.00, "expensive call");
} catch (err) {
  if (err instanceof MonoInsufficientBalance) {
    console.log("Agent is out of budget — request more funds from operator.");
  }
}
```

---

## Python

```bash
pip install mono-sdk
```

```python
from mono_sdk import MonoClient

with MonoClient(api_key=os.environ["MONO_API_KEY"]) as mono:
    balance = mono.balance()
    mono.inference("openai_gpt4o", {"messages": [{"role": "user", "content": "Hello"}]})
```

LangChain and OpenAI function bindings included in `mono_sdk.langchain_tools`
and `mono_sdk.openai_functions`.

---

## Environment variables

| Variable | Description |
|---|---|
| `MONO_API_KEY` | Agent API key from monospay dashboard |
| `MONO_GATEWAY_URL` | Override gateway URL (default: `https://api.monospay.com`) |

---

## Links

- Dashboard: [monospay.com](https://monospay.com)
- API endpoint: `https://api.monospay.com/v1`
- Contract: [BaseScan 0xA9DC3105…](https://basescan.org/address/0xA9DC3105ec1A84E4Bc3c9702dFC772a6efA2CDBA)
- Built on [Base](https://base.org) · Settled in [USDC](https://www.circle.com/usdc)
