"""Wheel smoke test — runs after each cibuildwheel-built free-core wheel install.

Verifies the structural protections we expect from a v0.2.0+ production
free-core wheel:

- **Dev-mode stripping (Phase B).** ``_dev_mode_real.py`` is excluded
  from the wheel; the dispatcher loads ``_dev_mode_stub`` and the stub's
  ``override_status()`` returns None even when constructed with
  ``enabled=True``. A reverse-engineer who unpacks the wheel finds only
  the stub — there is no bypass code to flip.
- **Cython-compiled IP modules (Phase C).** A representative sample of
  the algorithmic IP modules ship as compiled extensions (``.pyd`` on
  Windows, ``.so`` on Linux/macOS), not plain ``.py`` source. The full
  list lives in ``hatch_build.py`` _FREE_CORE_COMPILE_TARGETS — this
  smoke test samples one module per major group to catch the case where
  the Cython compile pass silently skipped or partially failed without
  the build itself failing loudly.

Invoked from ``.github/workflows/release.yml`` via cibuildwheel's
``CIBW_TEST_COMMAND`` after each wheel is built and installed in a
fresh test venv, and from ``.github/workflows/ci.yml`` after the
per-PR free-core wheel build.
"""

from __future__ import annotations

import sys

import memscope.analysis.region_usage as analysis_mod
import memscope.config.loader as config_mod
import memscope.diff.engine as diff_mod
import memscope.outputs.json_renderer as outputs_mod
import memscope.parsers.map.gnu_map_parser as parser_mod
import memscope.rules.evaluators.budget as rules_mod
import memscope.toolchains.gnu as toolchain_mod
from memscope.licensing.dev_mode import DeveloperModeLicenseBridge

errors: list[str] = []


def _expect(condition: bool, message: str) -> None:
    if not condition:
        errors.append(message)


# ---- Phase B: dev-mode bypass code is physically absent --------------

_expect(
    DeveloperModeLicenseBridge.__module__ == "memscope.licensing._dev_mode_stub",
    f"DeveloperModeLicenseBridge should resolve to the stub, "
    f"got {DeveloperModeLicenseBridge.__module__}",
)
_expect(
    DeveloperModeLicenseBridge(enabled=True).override_status() is None,
    "Stub bridge should always return None — the bypass code is gone",
)

# ---- Phase C: free-core IP modules ship as compiled extensions -------

_COMPILED_SAMPLES = [
    ("analysis.region_usage", analysis_mod),
    ("config.loader", config_mod),
    ("diff.engine", diff_mod),
    ("outputs.json_renderer", outputs_mod),
    ("parsers.map.gnu_map_parser", parser_mod),
    ("rules.evaluators.budget", rules_mod),
    ("toolchains.gnu", toolchain_mod),
]
for label, mod in _COMPILED_SAMPLES:
    _expect(
        mod.__file__.endswith((".pyd", ".so")),
        f"{label} should be a compiled extension (.pyd / .so), "
        f"got {mod.__file__} — Cython compile pass likely skipped this module",
    )

if errors:
    print("Wheel smoke test FAILED:", file=sys.stderr)
    for err in errors:
        print(f"  - {err}", file=sys.stderr)
    sys.exit(1)

print(
    f"Wheel smoke test passed — {len(_COMPILED_SAMPLES)} sampled IP modules "
    f"are compiled, dev-mode bypass is absent."
)
