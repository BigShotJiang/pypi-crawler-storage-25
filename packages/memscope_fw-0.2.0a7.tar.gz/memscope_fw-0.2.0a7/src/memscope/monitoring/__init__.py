"""Monitoring and telemetry stubs."""

from memscope.monitoring.telemetry import TelemetrySink, build_telemetry_sink

__all__ = ["TelemetrySink", "build_telemetry_sink"]
