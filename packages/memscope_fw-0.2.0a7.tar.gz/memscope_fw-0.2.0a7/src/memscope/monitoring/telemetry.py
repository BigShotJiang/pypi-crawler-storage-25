"""Opt-in telemetry sink (Phase 28 Wave 4 / T286).

Telemetry is **OFF by default** and emits **only** when the user has
explicitly opted in by setting both ``[telemetry] enabled = true`` AND
``[telemetry] endpoint = "https://..."`` in their MemScope config.

Privacy contract (also documented in ``docs/public/privacy.md``):

- Collected: tool version, license mode, command name, runtime in
  milliseconds, exit code.
- NOT collected: file paths, target names, toolchain identifiers, symbol
  names, issue counts, hostnames, IP addresses, license keys, machine
  fingerprints, or any user-supplied data.

Failures are silent — a network error or 5xx response from the endpoint
must never disrupt the CLI command. The emit call uses a short 1-second
timeout so a slow endpoint can't slow down the user.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx

from memscope.config.schema import TelemetryConfig

# Whitelist of payload fields that telemetry is allowed to emit. Anything
# else is silently dropped before the POST.
_ALLOWED_FIELDS: frozenset[str] = frozenset(
    {
        "version",
        "command",
        "runtime_ms",
        "exit_code",
    }
)

_REQUEST_TIMEOUT_SECONDS = 1.0


@dataclass(slots=True, frozen=True)
class TelemetrySink:
    """Opt-in telemetry transport with explicit status metadata."""

    enabled: bool
    mode: str
    endpoint: str | None
    reason: str

    def emit(self, event: str, payload: dict[str, Any]) -> None:
        """Best-effort POST of a whitelisted payload.

        Silent on every failure — network errors, timeouts, HTTP 4xx/5xx
        responses, malformed endpoint URLs all pass without raising. The
        whitelist of allowed fields is enforced here as a defense-in-depth
        check against accidental PII leakage from a future caller.
        """
        if not self.enabled or not self.endpoint:
            return
        try:
            sanitized = {k: v for k, v in payload.items() if k in _ALLOWED_FIELDS}
            httpx.post(
                self.endpoint,
                json={"event": event, "payload": sanitized},
                timeout=_REQUEST_TIMEOUT_SECONDS,
            )
        except (httpx.HTTPError, httpx.InvalidURL, ValueError, OSError):
            # Telemetry must never break the CLI. Drop the failure on the
            # floor and continue.
            return

    def status_dict(self) -> dict[str, Any]:
        return {
            "enabled": self.enabled,
            "mode": self.mode,
            "endpoint": self.endpoint,
            "reason": self.reason,
        }


def build_telemetry_sink(config: TelemetryConfig) -> TelemetrySink:
    if config.enabled and config.endpoint:
        return TelemetrySink(
            enabled=True,
            mode="opt-in-active",
            endpoint=config.endpoint,
            reason="user opted in via [telemetry] enabled+endpoint config",
        )
    if config.enabled and not config.endpoint:
        return TelemetrySink(
            enabled=False,
            mode="opt-in-misconfigured",
            endpoint=None,
            reason=(
                "[telemetry] enabled=true but endpoint is missing; "
                "no events will be emitted"
            ),
        )
    return TelemetrySink(
        enabled=False,
        mode="off",
        endpoint=None,
        reason="disabled-by-default",
    )
