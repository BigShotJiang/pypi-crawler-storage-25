"""ELF artifact parser (v1 lightweight implementation)."""

from __future__ import annotations

import re
from pathlib import Path

from memscope.parsers.errors import ParserError
from memscope.parsers.models import (
    ArtifactParseResult,
    ArtifactType,
    DiagnosticSeverity,
    ParseDiagnostic,
    SectionRecord,
    ToolchainKind,
)

_PRINTABLE_SECTION_NAME = re.compile(rb"\.(?:text|data|bss|rodata|init_array|fini_array|vectors)[\w.$]*")


class ELFParser:
    artifact_type = ArtifactType.ELF

    def parse(self, path: Path, *, toolchain: ToolchainKind) -> ArtifactParseResult:
        data = path.read_bytes()
        if not data.startswith(b"\x7fELF"):
            raise ParserError(
                ParseDiagnostic(
                    code="elf.invalid_magic",
                    severity=DiagnosticSeverity.ERROR,
                    message=f"Invalid ELF header in {path.name}.",
                    source_path=path,
                )
            )

        diagnostics: list[ParseDiagnostic] = []
        if len(data) < 16:
            diagnostics.append(
                ParseDiagnostic(
                    code="elf.truncated_header",
                    severity=DiagnosticSeverity.WARNING,
                    message=(
                        f"ELF file {path.name} has a truncated header ({len(data)} bytes). "
                        "Continuing with partial metadata."
                    ),
                    source_path=path,
                )
            )

        elf_class = "unknown"
        endianness = "unknown"
        if len(data) > 4:
            elf_class = {1: "ELF32", 2: "ELF64"}.get(data[4], "unknown")
        if len(data) > 5:
            endianness = {1: "little", 2: "big"}.get(data[5], "unknown")

        guessed_sections = sorted(
            {match.group(0).decode("ascii", errors="ignore") for match in _PRINTABLE_SECTION_NAME.finditer(data)}
        )
        sections = [
            SectionRecord(
                name=section_name,
                vma=0,
                lma=0,
                size=0,
                execution_region=None,
                load_region=None,
            )
            for section_name in guessed_sections
        ]

        return ArtifactParseResult(
            artifact_type=ArtifactType.ELF,
            path=path,
            toolchain=toolchain,
            sections=sections,
            diagnostics=diagnostics,
            raw_tree={
                "header": {
                    "class": elf_class,
                    "endianness": endianness,
                    "size_bytes": len(data),
                },
                "guessed_sections": guessed_sections,
            },
        )
