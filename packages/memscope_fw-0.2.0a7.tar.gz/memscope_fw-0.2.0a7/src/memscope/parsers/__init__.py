"""Parsing and ingestion layer for MemScope."""

from memscope.parsers.factory import detect_toolchain, identify_artifact_type, parse_artifact_set
from memscope.parsers.models import (
    ArtifactParseResult,
    ArtifactType,
    DiagnosticSeverity,
    ParsedArtifactSet,
    ParseDiagnostic,
    SectionRecord,
    SymbolRecord,
    ToolchainKind,
)

__all__ = [
    "ArtifactParseResult",
    "ArtifactType",
    "DiagnosticSeverity",
    "ParseDiagnostic",
    "ParsedArtifactSet",
    "SectionRecord",
    "SymbolRecord",
    "ToolchainKind",
    "detect_toolchain",
    "identify_artifact_type",
    "parse_artifact_set",
]

