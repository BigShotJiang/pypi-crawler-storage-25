"""Parser factory, artifact detection, and parse pipeline orchestration."""

from __future__ import annotations

import re
from collections.abc import Iterable
from pathlib import Path

from memscope.domain import BuildArtifactSet
from memscope.parsers.base import ArtifactParser
from memscope.parsers.dwarf_parser import DwarfParser
from memscope.parsers.elf_parser import ELFParser
from memscope.parsers.errors import ParserError
from memscope.parsers.linker.gnu_ld_parser import GNULdParser
from memscope.parsers.linker.iar_icf_parser import IARICFParser
from memscope.parsers.linker.keil_scatter_parser import KeilScatterParser
from memscope.parsers.map.gnu_map_parser import GNUMapParser
from memscope.parsers.map.iar_map_parser import IARMapParser
from memscope.parsers.map.keil_map_parser import KeilMapParser
from memscope.parsers.models import (
    ArtifactParseResult,
    ArtifactType,
    DiagnosticSeverity,
    ParsedArtifactSet,
    ParseDiagnostic,
    SectionRecord,
    ToolchainKind,
)

_LINKER_SUFFIXES = {".ld", ".lds", ".icf", ".scatter", ".scf", ".sct"}
_TOOLCHAIN_EXTENSION_HINTS: dict[str, ToolchainKind] = {
    ".icf": ToolchainKind.IAR,
    ".sct": ToolchainKind.KEIL,
    ".scf": ToolchainKind.KEIL,
    ".scatter": ToolchainKind.KEIL,
    ".ld": ToolchainKind.GNU,
    ".lds": ToolchainKind.GNU,
}
_TOOLCHAIN_PATTERNS: dict[ToolchainKind, tuple[tuple[re.Pattern[str], int], ...]] = {
    ToolchainKind.GNU: (
        (re.compile(r"\blinker script and memory map\b"), 6),
        (re.compile(r"\bmemory configuration\b"), 5),
        (re.compile(r"^\s*memory\s*\{", re.MULTILINE), 4),
        (re.compile(r"^\s*sections\s*\{", re.MULTILINE), 3),
    ),
    ToolchainKind.IAR: (
        (re.compile(r"\biar linker\b"), 6),
        (re.compile(r"\bplacement summary\b"), 5),
        (re.compile(r"^\s*define\s+region\b", re.MULTILINE), 4),
        (re.compile(r"^\s*define\s+symbol\b", re.MULTILINE), 3),
        (re.compile(r"^\s*place\s+in\b", re.MULTILINE), 3),
    ),
    ToolchainKind.KEIL: (
        (re.compile(r"\bscatter-loading\b"), 6),
        (re.compile(r"\barm linker\b"), 5),
        (re.compile(r"\bload region\b"), 5),
        (re.compile(r"\bexecution region\b"), 5),
        (re.compile(r"\blr_irom\b"), 4),
        (re.compile(r"\brw_iram\b"), 4),
    ),
}


def identify_artifact_type(path: Path) -> ArtifactType:
    suffix = path.suffix.lower()
    if suffix == ".map":
        return ArtifactType.MAP
    if suffix in _LINKER_SUFFIXES:
        return ArtifactType.LINKER
    if suffix in {".elf", ".axf", ".out"}:
        return ArtifactType.ELF

    if path.is_file():
        try:
            with path.open("rb") as handle:
                header = handle.read(4)
            if header == b"\x7fELF":
                return ArtifactType.ELF
        except OSError:
            return ArtifactType.UNKNOWN
    return ArtifactType.UNKNOWN


def _toolchain_from_hint(value: str | None) -> ToolchainKind:
    if value is None:
        return ToolchainKind.UNKNOWN
    normalized = value.strip().lower().replace("-", "_")
    if normalized in {"gnu", "arm_gnu", "gcc"}:
        return ToolchainKind.GNU
    if normalized in {"clang", "clang_lld", "lld"}:
        return ToolchainKind.CLANG_LLD
    if normalized == "iar":
        return ToolchainKind.IAR
    if normalized in {"keil", "armcc", "armclang_scatter"}:
        return ToolchainKind.KEIL
    return ToolchainKind.UNKNOWN


def detect_toolchain(artifacts: BuildArtifactSet, explicit_hint: str | None = None) -> ToolchainKind:
    from_hint = _toolchain_from_hint(explicit_hint or artifacts.toolchain_hint)
    if from_hint != ToolchainKind.UNKNOWN:
        return from_hint

    scores: dict[ToolchainKind, int] = {
        ToolchainKind.GNU: 0,
        ToolchainKind.IAR: 0,
        ToolchainKind.KEIL: 0,
    }

    probes: list[Path] = []
    for path in (artifacts.map_path, artifacts.linker_path):
        if path is not None:
            probe_path = Path(path)
            probes.append(probe_path)
            extension_hint = _TOOLCHAIN_EXTENSION_HINTS.get(probe_path.suffix.lower())
            if extension_hint is not None:
                scores[extension_hint] += 3

    for path in probes:
        try:
            text = path.read_text(encoding="utf-8", errors="ignore").lower()
        except OSError:
            continue

        for toolchain, patterns in _TOOLCHAIN_PATTERNS.items():
            for pattern, weight in patterns:
                if pattern.search(text):
                    scores[toolchain] += weight

    ranked = sorted(scores.items(), key=lambda item: item[1], reverse=True)
    if not ranked or ranked[0][1] <= 0:
        return ToolchainKind.UNKNOWN

    if len(ranked) >= 2 and ranked[0][1] == ranked[1][1]:
        return ToolchainKind.UNKNOWN

    return ranked[0][0]



def _parser_for(artifact_type: ArtifactType, toolchain: ToolchainKind) -> ArtifactParser | None:
    if artifact_type == ArtifactType.ELF:
        return ELFParser()
    if artifact_type == ArtifactType.MAP:
        if toolchain == ToolchainKind.IAR:
            return IARMapParser()
        if toolchain == ToolchainKind.KEIL:
            return KeilMapParser()
        if toolchain in {ToolchainKind.GNU, ToolchainKind.CLANG_LLD, ToolchainKind.UNKNOWN}:
            return GNUMapParser()
        return None
    if artifact_type == ArtifactType.LINKER:
        if toolchain == ToolchainKind.IAR:
            return IARICFParser()
        if toolchain == ToolchainKind.KEIL:
            return KeilScatterParser()
        if toolchain in {ToolchainKind.GNU, ToolchainKind.CLANG_LLD, ToolchainKind.UNKNOWN}:
            return GNULdParser()
        return None
    if artifact_type == ArtifactType.DWARF:
        return DwarfParser()
    return None


def _parse_one(
    path: Path,
    *,
    expected_type: ArtifactType,
    toolchain: ToolchainKind,
) -> ArtifactParseResult:
    detected_type = identify_artifact_type(path)
    diagnostics: list[ParseDiagnostic] = []

    effective_type = expected_type
    if detected_type != ArtifactType.UNKNOWN and detected_type != expected_type:
        diagnostics.append(
            ParseDiagnostic(
                code="parser.type_mismatch",
                severity=DiagnosticSeverity.WARNING,
                message=(
                    f"Expected {expected_type.value} artifact but detected {detected_type.value} for {path.name}. "
                    f"Attempting parse using expected type."
                ),
                source_path=path,
            )
        )

    parser = _parser_for(effective_type, toolchain)
    if parser is None:
        return ArtifactParseResult(
            artifact_type=effective_type,
            path=path,
            toolchain=toolchain,
            diagnostics=diagnostics
            + [
                ParseDiagnostic(
                    code="parser.unsupported_toolchain",
                    severity=DiagnosticSeverity.ERROR,
                    message=f"No parser available for {effective_type.value} with toolchain {toolchain.value}.",
                    source_path=path,
                )
            ],
            raw_tree={"status": "unsupported"},
        )

    try:
        result = parser.parse(path, toolchain=toolchain)
    except ParserError as exc:
        return ArtifactParseResult(
            artifact_type=effective_type,
            path=path,
            toolchain=toolchain,
            diagnostics=diagnostics + [exc.diagnostic],
            raw_tree={"status": "failed", "reason": exc.diagnostic.message},
        )
    except OSError as exc:
        return ArtifactParseResult(
            artifact_type=effective_type,
            path=path,
            toolchain=toolchain,
            diagnostics=diagnostics
            + [
                ParseDiagnostic(
                    code="parser.io_error",
                    severity=DiagnosticSeverity.ERROR,
                    message=str(exc),
                    source_path=path,
                )
            ],
            raw_tree={"status": "failed", "reason": str(exc)},
        )

    if diagnostics:
        result.diagnostics = diagnostics + result.diagnostics
    return result


def _region_names(result: ArtifactParseResult | None) -> set[str]:
    if result is None:
        return set()
    return {region.name for region in result.memory_regions}


def _iter_sections(results: Iterable[ArtifactParseResult | None]) -> list[SectionRecord]:
    sections: list[SectionRecord] = []
    for result in results:
        if result is not None:
            sections.extend(result.sections)
    return sections


def _cross_check_consistency(parsed: ParsedArtifactSet) -> list[ParseDiagnostic]:
    diagnostics: list[ParseDiagnostic] = []

    map_regions = _region_names(parsed.map)
    linker_regions = _region_names(parsed.linker)
    if map_regions and linker_regions and map_regions.isdisjoint(linker_regions):
        diagnostics.append(
            ParseDiagnostic(
                code="crosscheck.region_set_mismatch",
                severity=DiagnosticSeverity.WARNING,
                message=(
                    "MAP and linker region names have no overlap. "
                    "This may indicate parse ambiguity or mixed-toolchain artifacts."
                ),
                source_path=parsed.map.path if parsed.map else None,
            )
        )

    known_regions = map_regions | linker_regions
    for section in _iter_sections((parsed.map, parsed.linker)):
        if section.execution_region and section.execution_region not in known_regions:
            diagnostics.append(
                ParseDiagnostic(
                    code="crosscheck.unknown_execution_region",
                    severity=DiagnosticSeverity.WARNING,
                    message=(
                        f"Section {section.name} references unknown execution region "
                        f"{section.execution_region}."
                    ),
                    source_path=parsed.map.path if parsed.map else parsed.linker.path if parsed.linker else None,
                    line=section.line,
                )
            )
    return diagnostics


def parse_artifact_set(
    artifacts: BuildArtifactSet,
    *,
    explicit_toolchain: str | None = None,
    include_dwarf: bool = False,
) -> ParsedArtifactSet:
    toolchain = detect_toolchain(artifacts, explicit_hint=explicit_toolchain)

    assumptions: list[str] = []
    if toolchain == ToolchainKind.UNKNOWN:
        assumptions.append("toolchain.auto_detected=unknown")
    else:
        assumptions.append(f"toolchain.auto_detected={toolchain.value}")

    elf_result: ArtifactParseResult | None = None
    map_result: ArtifactParseResult | None = None
    linker_result: ArtifactParseResult | None = None
    dwarf_result: ArtifactParseResult | None = None

    if artifacts.elf_path:
        elf_result = _parse_one(Path(artifacts.elf_path), expected_type=ArtifactType.ELF, toolchain=toolchain)
    else:
        assumptions.append("input.missing.elf")

    if artifacts.map_path:
        map_result = _parse_one(Path(artifacts.map_path), expected_type=ArtifactType.MAP, toolchain=toolchain)
    else:
        assumptions.append("input.missing.map")

    if artifacts.linker_path:
        linker_result = _parse_one(Path(artifacts.linker_path), expected_type=ArtifactType.LINKER, toolchain=toolchain)
    else:
        assumptions.append("input.missing.linker")

    if include_dwarf and artifacts.elf_path:
        dwarf_result = _parse_one(Path(artifacts.elf_path), expected_type=ArtifactType.DWARF, toolchain=toolchain)

    parsed = ParsedArtifactSet(
        toolchain_detected=toolchain,
        elf=elf_result,
        map=map_result,
        linker=linker_result,
        dwarf=dwarf_result,
        assumptions=tuple(dict.fromkeys(assumptions)),
    )

    cross_checks = _cross_check_consistency(parsed)
    parsed.diagnostics.extend(cross_checks)

    ambiguity_codes = (
        "gnu_map.section_region_ambiguity",
        "iar_map.section_region_ambiguity",
        "keil_map.section_region_ambiguity",
        "keil_scatter.unresolved_execution_region",
        "crosscheck.region_set_mismatch",
        "crosscheck.unknown_execution_region",
    )
    ambiguity_messages: list[str] = []
    for diagnostic in parsed.all_diagnostics():
        if diagnostic.code in ambiguity_codes:
            ambiguity_messages.append(diagnostic.message)
    parsed.unresolved_ambiguities = tuple(dict.fromkeys(ambiguity_messages))

    return parsed
