"""GNU MAP parser (v1 focused implementation)."""

from __future__ import annotations

import re
from pathlib import Path

from memscope.parsers.models import (
    ArtifactParseResult,
    ArtifactType,
    DiagnosticSeverity,
    MemoryRegionRecord,
    ParseDiagnostic,
    SectionRecord,
    SymbolRecord,
    ToolchainKind,
)

_HEX_OR_INT = r"(?:0x[0-9a-fA-F]+|\d+)"
_REGION_LINE = re.compile(
    rf"^\s*(?P<name>[A-Za-z_][\w.$-]*)\s+(?P<origin>{_HEX_OR_INT})\s+(?P<length>{_HEX_OR_INT})\s*(?P<attrs>[A-Za-z!]*)\s*$"
)
_SECTION_LINE = re.compile(
    rf"^\s*(?P<name>\.[A-Za-z_][\w.$-]*)\s+(?P<vma>{_HEX_OR_INT})\s+(?P<size>{_HEX_OR_INT})(?P<rest>.*)$"
)
_LOAD_ADDRESS = re.compile(rf"load address\s+(?P<addr>{_HEX_OR_INT})")
_SYMBOL_LINE = re.compile(
    rf"^\s*(?P<addr>{_HEX_OR_INT})\s+(?P<name>[A-Za-z_][\w.$@-]*)\s*$"
)


def _parse_int(value: str) -> int:
    return int(value, 0)


def _guess_region_for_address(address: int, regions: list[MemoryRegionRecord]) -> str | None:
    for region in regions:
        if region.contains(address):
            return region.name
    return None


class GNUMapParser:
    artifact_type = ArtifactType.MAP

    def parse(self, path: Path, *, toolchain: ToolchainKind) -> ArtifactParseResult:
        text = path.read_text(encoding="utf-8", errors="replace")
        lines = text.splitlines()

        diagnostics: list[ParseDiagnostic] = []
        memory_regions: list[MemoryRegionRecord] = []
        sections: list[SectionRecord] = []
        symbols: list[SymbolRecord] = []

        for line_number, line in enumerate(lines, start=1):
            region_match = _REGION_LINE.match(line)
            if region_match:
                length = _parse_int(region_match.group("length"))
                if length > 0:
                    attributes = tuple(sorted({char for char in region_match.group("attrs").lower() if char.strip()}))
                    memory_regions.append(
                        MemoryRegionRecord(
                            name=region_match.group("name"),
                            start_address=_parse_int(region_match.group("origin")),
                            size=length,
                            attributes=attributes,
                            source="map",
                            line=line_number,
                        )
                    )
                continue

            section_match = _SECTION_LINE.match(line)
            if section_match:
                vma = _parse_int(section_match.group("vma"))
                size = _parse_int(section_match.group("size"))
                lma = vma
                load_match = _LOAD_ADDRESS.search(section_match.group("rest"))
                if load_match:
                    lma = _parse_int(load_match.group("addr"))

                sections.append(
                    SectionRecord(
                        name=section_match.group("name"),
                        vma=vma,
                        lma=lma,
                        size=size,
                        execution_region=_guess_region_for_address(vma, memory_regions),
                        load_region=_guess_region_for_address(lma, memory_regions),
                        line=line_number,
                    )
                )
                continue

            symbol_match = _SYMBOL_LINE.match(line)
            if symbol_match and sections:
                symbol_name = symbol_match.group("name")
                if symbol_name.startswith("."):
                    continue
                symbols.append(
                    SymbolRecord(
                        name=symbol_name,
                        address=_parse_int(symbol_match.group("addr")),
                        section_name=sections[-1].name,
                        line=line_number,
                    )
                )

        if not memory_regions:
            diagnostics.append(
                ParseDiagnostic(
                    code="gnu_map.missing_memory_regions",
                    severity=DiagnosticSeverity.WARNING,
                    message="No memory-region declarations were detected in MAP file.",
                    source_path=path,
                )
            )

        if not sections:
            diagnostics.append(
                ParseDiagnostic(
                    code="gnu_map.missing_sections",
                    severity=DiagnosticSeverity.WARNING,
                    message="No output section lines were detected in MAP file.",
                    source_path=path,
                )
            )

        unresolved_section_count = sum(1 for section in sections if section.execution_region is None)
        if unresolved_section_count:
            diagnostics.append(
                ParseDiagnostic(
                    code="gnu_map.section_region_ambiguity",
                    severity=DiagnosticSeverity.WARNING,
                    message=(
                        f"{unresolved_section_count} section(s) could not be mapped to a region "
                        "from MAP memory declarations."
                    ),
                    source_path=path,
                )
            )

        return ArtifactParseResult(
            artifact_type=ArtifactType.MAP,
            path=path,
            toolchain=ToolchainKind.GNU if toolchain == ToolchainKind.UNKNOWN else toolchain,
            memory_regions=memory_regions,
            sections=sections,
            symbols=symbols,
            diagnostics=diagnostics,
            raw_tree={
                "line_count": len(lines),
                "detected_regions": len(memory_regions),
                "detected_sections": len(sections),
                "detected_symbols": len(symbols),
            },
        )

