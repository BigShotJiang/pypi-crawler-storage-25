"""IAR MAP parser (v1 compatibility implementation)."""

from __future__ import annotations

import re
from pathlib import Path

from memscope.parsers.models import (
    ArtifactParseResult,
    ArtifactType,
    DiagnosticSeverity,
    MemoryRegionRecord,
    ParseDiagnostic,
    SectionRecord,
    SymbolRecord,
    ToolchainKind,
)

_HEX_OR_INT = r"(?:0x[0-9a-fA-F'][0-9a-fA-F']*|\d[\d']*)"
_REGION_LINE = re.compile(
    rf"^\s*(?P<name>[A-Za-z_][\w.$-]*)\s+(?P<origin>{_HEX_OR_INT})\s+(?P<size>{_HEX_OR_INT})\s+(?P<attrs>[A-Za-z]+)\s*$"
)
_LEGACY_SECTION_LINE = re.compile(
    rf"^\s*(?P<name>\.[A-Za-z_][\w.$-]*)\s+(?P<addr>{_HEX_OR_INT})\s+(?P<size>{_HEX_OR_INT})(?P<rest>.*)$"
)
_SYMBOL_LINE = re.compile(
    rf"^\s*(?P<name>[A-Za-z_][\w.$@-]*)\s+(?P<addr>{_HEX_OR_INT})\s*$"
)
_TABLE_SECTION_NAME = r"(?:\.[A-Za-z_][\w.$*-]*|__[A-Za-z0-9_.$-]+__?)"
_TABLE_SECTION_ROW = re.compile(
    rf"^\s*(?P<name>{_TABLE_SECTION_NAME})\s+(?P<kind>[A-Za-z][A-Za-z ]*?)\s+"
    rf"(?P<addr>{_HEX_OR_INT})\s+(?P<size>{_HEX_OR_INT})(?:\s+(?P<rest>.*))?$"
)
_TABLE_SECTION_NAME_ONLY_ROW = re.compile(rf"^\s*(?P<name>{_TABLE_SECTION_NAME})\s*$")
_TABLE_SECTION_CONTINUATION_ROW = re.compile(
    rf"^\s*(?P<kind>[A-Za-z][A-Za-z ]*?)\s+(?P<addr>{_HEX_OR_INT})\s+(?P<size>{_HEX_OR_INT})(?:\s+(?P<rest>.*))?$"
)
_OBJECT_FILE_TOKEN = re.compile(r"(?P<object>[^\s\[\]<>]+?\.(?:o|obj|a))\b", re.IGNORECASE)
_ENTRY_LIST_HEADER = re.compile(r"^\*{3}\s+ENTRY LIST\b", re.IGNORECASE)
_ENTRY_LIST_COLUMNS = re.compile(
    r"^\s*Entry\s+Address\s+Size\s+Type\s+Object\s*$",
    re.IGNORECASE,
)
_ENTRY_LIST_SEPARATOR = re.compile(r"^\s*-{3,}\s+-{3,}\s+-{3,}\s+-{3,}\s+-{3,}\s*$")
_ENTRY_SIZE_TOKEN = rf"(?:{_HEX_OR_INT}|--)"
_ENTRY_INLINE_ROW = re.compile(
    rf"^\s*(?P<name>\S+)\s+(?P<addr>{_HEX_OR_INT})\s+(?P<size>{_ENTRY_SIZE_TOKEN})\s+"
    rf"(?P<kind>[A-Za-z]+)\s+(?P<scope>[A-Za-z]+)\s+(?P<object>.+?)\s*$"
)
_ENTRY_CONTINUATION_ROW = re.compile(
    rf"^\s*(?P<addr>{_HEX_OR_INT})\s+(?P<size>{_ENTRY_SIZE_TOKEN})\s+"
    rf"(?P<kind>[A-Za-z]+)\s+(?P<scope>[A-Za-z]+)\s+(?P<object>.+?)\s*$"
)
_ENTRY_NAME_ONLY_ROW = re.compile(r"^\s*(?P<name>\S+)\s*$")


def _parse_int(value: str) -> int:
    return int(value.replace("'", "").replace("_", "").strip(), 0)


def _parse_optional_int(value: str) -> int | None:
    token = value.strip()
    if token == "--":
        return None
    return _parse_int(token)


def _guess_region_for_address(address: int, regions: list[MemoryRegionRecord]) -> str | None:
    for region in regions:
        if region.contains(address):
            return region.name
    return None


def _looks_like_iar_region(name: str, attrs: str) -> bool:
    lowered = name.lower()
    if any(
        token in lowered
        for token in (
            "flash",
            "sram",
            "ram",
            "rom",
            "itcm",
            "dtcm",
            "region",
            "memory",
        )
    ):
        return True
    if name.isupper():
        return True
    normalized_attrs = attrs.lower().strip()
    return bool(normalized_attrs) and all(ch in {"r", "w", "x"} for ch in normalized_attrs)


def _extract_object_file(text: str | None) -> str | None:
    if not text:
        return None
    match = _OBJECT_FILE_TOKEN.search(text)
    if not match:
        return None
    return match.group("object")


def _entry_type_to_section_hint(entry_type: str) -> str | None:
    token = entry_type.lower().strip()
    if token == "code":
        return ".code"
    if token == "data":
        return ".data"
    return None


def _parse_entry_list_symbols(lines: list[str]) -> list[SymbolRecord]:
    entry_header_index: int | None = None
    for index, line in enumerate(lines):
        if _ENTRY_LIST_HEADER.match(line.strip()):
            entry_header_index = index
            break
    if entry_header_index is None:
        return []

    column_header_index: int | None = None
    for index in range(entry_header_index, len(lines)):
        if _ENTRY_LIST_COLUMNS.match(lines[index]):
            column_header_index = index
            break
        if index > entry_header_index and lines[index].startswith("*** ") and not _ENTRY_LIST_HEADER.match(
            lines[index].strip()
        ):
            break
    if column_header_index is None:
        return []

    symbols: list[SymbolRecord] = []
    pending_name: str | None = None

    for line_number, line in enumerate(lines[column_header_index + 1 :], start=column_header_index + 2):
        stripped = line.strip()
        if line.startswith("*** "):
            break
        if not stripped:
            continue
        if _ENTRY_LIST_SEPARATOR.match(line):
            continue

        inline_match = _ENTRY_INLINE_ROW.match(line)
        if inline_match:
            pending_name = None
            size = _parse_optional_int(inline_match.group("size"))
            if size is None or size <= 0:
                continue
            symbols.append(
                SymbolRecord(
                    name=inline_match.group("name"),
                    address=_parse_int(inline_match.group("addr")),
                    size=size,
                    section_name=_entry_type_to_section_hint(inline_match.group("kind")),
                    object_file=_extract_object_file(inline_match.group("object")),
                    line=line_number,
                )
            )
            continue

        continuation_match = _ENTRY_CONTINUATION_ROW.match(line)
        if continuation_match and pending_name:
            size = _parse_optional_int(continuation_match.group("size"))
            if size is not None and size > 0:
                symbols.append(
                    SymbolRecord(
                        name=pending_name,
                        address=_parse_int(continuation_match.group("addr")),
                        size=size,
                        section_name=_entry_type_to_section_hint(continuation_match.group("kind")),
                        object_file=_extract_object_file(continuation_match.group("object")),
                        line=line_number,
                    )
                )
            pending_name = None
            continue

        name_only_match = _ENTRY_NAME_ONLY_ROW.match(line)
        if name_only_match and not stripped.lower().startswith("0x"):
            pending_name = name_only_match.group("name")
            continue

        pending_name = None

    return symbols


class IARMapParser:
    artifact_type = ArtifactType.MAP

    def parse(self, path: Path, *, toolchain: ToolchainKind) -> ArtifactParseResult:
        text = path.read_text(encoding="utf-8", errors="replace")
        lines = text.splitlines()

        diagnostics: list[ParseDiagnostic] = []
        memory_regions: list[MemoryRegionRecord] = []
        sections: list[SectionRecord] = []
        symbols: list[SymbolRecord] = []
        pending_section_name: str | None = None

        for line_number, line in enumerate(lines, start=1):
            region_match = _REGION_LINE.match(line)
            if region_match:
                size = _parse_int(region_match.group("size"))
                region_name = region_match.group("name")
                region_attrs = region_match.group("attrs")
                if (
                    size > 0
                    and not region_name.startswith(".")
                    and _looks_like_iar_region(region_name, region_attrs)
                ):
                    attributes = tuple(
                        sorted({char for char in region_attrs.lower() if char.strip()})
                    )
                    memory_regions.append(
                        MemoryRegionRecord(
                            name=region_name,
                            start_address=_parse_int(region_match.group("origin")),
                            size=size,
                            attributes=attributes,
                            source="map",
                            line=line_number,
                        )
                    )
                    continue

            section_match = _LEGACY_SECTION_LINE.match(line)
            if section_match:
                rest = section_match.group("rest").lower()
                if "<block>" in rest or "<init block>" in rest:
                    # Placement summary aggregate rows are followed by per-object rows.
                    # Keeping both double-counts region usage.
                    continue
                vma = _parse_int(section_match.group("addr"))
                size = _parse_int(section_match.group("size"))
                sections.append(
                    SectionRecord(
                        name=section_match.group("name"),
                        vma=vma,
                        lma=vma,
                        size=size,
                        execution_region=_guess_region_for_address(vma, memory_regions),
                        load_region=_guess_region_for_address(vma, memory_regions),
                        line=line_number,
                    )
                )
                continue

            table_row_match = _TABLE_SECTION_ROW.match(line)
            if table_row_match:
                pending_section_name = None
                section_name = table_row_match.group("name")
                vma = _parse_int(table_row_match.group("addr"))
                size = _parse_int(table_row_match.group("size"))
                sections.append(
                    SectionRecord(
                        name=section_name,
                        vma=vma,
                        lma=vma,
                        size=size,
                        execution_region=_guess_region_for_address(vma, memory_regions),
                        load_region=_guess_region_for_address(vma, memory_regions),
                        line=line_number,
                    )
                )
                object_file = _extract_object_file(table_row_match.group("rest"))
                if object_file and size > 0:
                    symbols.append(
                        SymbolRecord(
                            name=f"{section_name} ({object_file})",
                            address=vma,
                            size=size,
                            section_name=section_name,
                            object_file=object_file,
                            line=line_number,
                        )
                    )
                continue

            pending_name_match = _TABLE_SECTION_NAME_ONLY_ROW.match(line)
            if pending_name_match:
                pending_section_name = pending_name_match.group("name")
                continue

            if pending_section_name:
                continuation_match = _TABLE_SECTION_CONTINUATION_ROW.match(line)
                if continuation_match:
                    vma = _parse_int(continuation_match.group("addr"))
                    size = _parse_int(continuation_match.group("size"))
                    sections.append(
                        SectionRecord(
                            name=pending_section_name,
                            vma=vma,
                            lma=vma,
                            size=size,
                            execution_region=_guess_region_for_address(vma, memory_regions),
                            load_region=_guess_region_for_address(vma, memory_regions),
                            line=line_number,
                        )
                    )
                    object_file = _extract_object_file(continuation_match.group("rest"))
                    if object_file and size > 0:
                        symbols.append(
                            SymbolRecord(
                                name=f"{pending_section_name} ({object_file})",
                                address=vma,
                                size=size,
                                section_name=pending_section_name,
                                object_file=object_file,
                                line=line_number,
                            )
                        )
                    pending_section_name = None
                    continue
                pending_section_name = None

            symbol_match = _SYMBOL_LINE.match(line)
            if symbol_match and sections:
                symbol_name = symbol_match.group("name")
                if symbol_name.lower().endswith((".o", ".obj", ".a")):
                    continue
                symbols.append(
                    SymbolRecord(
                        name=symbol_name,
                        address=_parse_int(symbol_match.group("addr")),
                        section_name=sections[-1].name,
                        line=line_number,
                    )
                )

        if not memory_regions:
            diagnostics.append(
                ParseDiagnostic(
                    code="iar_map.missing_memory_regions",
                    severity=DiagnosticSeverity.WARNING,
                    message="No memory regions were detected in IAR MAP file.",
                    source_path=path,
                )
            )

        if not sections:
            diagnostics.append(
                ParseDiagnostic(
                    code="iar_map.missing_sections",
                    severity=DiagnosticSeverity.WARNING,
                    message="No output sections were detected in IAR MAP file.",
                    source_path=path,
                )
            )

        unresolved_section_count = sum(1 for section in sections if section.execution_region is None)
        if memory_regions and unresolved_section_count:
            diagnostics.append(
                ParseDiagnostic(
                    code="iar_map.section_region_ambiguity",
                    severity=DiagnosticSeverity.WARNING,
                    message=(
                        f"{unresolved_section_count} section(s) could not be mapped to a memory region "
                        "from IAR MAP declarations."
                    ),
                    source_path=path,
                )
            )

        entry_symbols = _parse_entry_list_symbols(lines)
        if entry_symbols:
            symbols = entry_symbols

        return ArtifactParseResult(
            artifact_type=ArtifactType.MAP,
            path=path,
            toolchain=ToolchainKind.IAR if toolchain == ToolchainKind.UNKNOWN else toolchain,
            memory_regions=memory_regions,
            sections=sections,
            symbols=symbols,
            diagnostics=diagnostics,
            raw_tree={
                "line_count": len(lines),
                "detected_regions": len(memory_regions),
                "detected_sections": len(sections),
                "detected_symbols": len(symbols),
            },
        )
