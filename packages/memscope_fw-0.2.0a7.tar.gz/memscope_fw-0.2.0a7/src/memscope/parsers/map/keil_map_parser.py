"""Keil/Arm MAP parser (v1 compatibility implementation)."""

from __future__ import annotations

import re
from pathlib import Path

from memscope.parsers.models import (
    ArtifactParseResult,
    ArtifactType,
    DiagnosticSeverity,
    MemoryRegionRecord,
    ParseDiagnostic,
    SectionRecord,
    SymbolRecord,
    ToolchainKind,
)

_HEX_OR_INT = r"(?:0x[0-9a-fA-F]+|\d+)"
_REGION_LINE = re.compile(
    rf"^\s*(?P<name>[A-Za-z_][\w.$-]*)\s+(?P<origin>{_HEX_OR_INT})\s+(?P<size>{_HEX_OR_INT})\s*(?P<attrs>[A-Za-z]*)\s*$"
)
_SECTION_LINE = re.compile(
    rf"^\s*(?P<name>\.[A-Za-z_][\w.$-]*)\s+(?P<addr>{_HEX_OR_INT})\s+(?P<size>{_HEX_OR_INT})(?P<rest>.*)$"
)
_SYMBOL_LINE = re.compile(
    rf"^\s*(?P<name>[A-Za-z_][\w.$@-]*)\s+(?P<addr>{_HEX_OR_INT})\s*$"
)


def _parse_int(value: str) -> int:
    return int(value, 0)


def _guess_region_for_address(address: int, regions: list[MemoryRegionRecord]) -> str | None:
    for region in regions:
        if region.contains(address):
            return region.name
    return None


def _looks_like_keil_region(name: str) -> bool:
    lowered = name.lower()
    return lowered.startswith(("er_", "rw_", "zi_", "lr_")) or "irom" in lowered or "iram" in lowered


class KeilMapParser:
    artifact_type = ArtifactType.MAP

    def parse(self, path: Path, *, toolchain: ToolchainKind) -> ArtifactParseResult:
        text = path.read_text(encoding="utf-8", errors="replace")
        lines = text.splitlines()

        diagnostics: list[ParseDiagnostic] = []
        memory_regions: list[MemoryRegionRecord] = []
        sections: list[SectionRecord] = []
        symbols: list[SymbolRecord] = []

        for line_number, line in enumerate(lines, start=1):
            region_match = _REGION_LINE.match(line)
            if region_match:
                name = region_match.group("name")
                size = _parse_int(region_match.group("size"))
                attrs = region_match.group("attrs")
                if size > 0 and not name.startswith(".") and (_looks_like_keil_region(name) or bool(attrs.strip())):
                    attributes = tuple(sorted({char for char in attrs.lower() if char.strip()}))
                    memory_regions.append(
                        MemoryRegionRecord(
                            name=name,
                            start_address=_parse_int(region_match.group("origin")),
                            size=size,
                            attributes=attributes,
                            source="map",
                            line=line_number,
                        )
                    )
                    continue

            section_match = _SECTION_LINE.match(line)
            if section_match:
                vma = _parse_int(section_match.group("addr"))
                size = _parse_int(section_match.group("size"))
                sections.append(
                    SectionRecord(
                        name=section_match.group("name"),
                        vma=vma,
                        lma=vma,
                        size=size,
                        execution_region=_guess_region_for_address(vma, memory_regions),
                        load_region=_guess_region_for_address(vma, memory_regions),
                        line=line_number,
                    )
                )
                continue

            symbol_match = _SYMBOL_LINE.match(line)
            if symbol_match and sections:
                symbols.append(
                    SymbolRecord(
                        name=symbol_match.group("name"),
                        address=_parse_int(symbol_match.group("addr")),
                        section_name=sections[-1].name,
                        line=line_number,
                    )
                )

        if not memory_regions:
            diagnostics.append(
                ParseDiagnostic(
                    code="keil_map.missing_memory_regions",
                    severity=DiagnosticSeverity.WARNING,
                    message="No memory regions were detected in Keil MAP file.",
                    source_path=path,
                )
            )

        if not sections:
            diagnostics.append(
                ParseDiagnostic(
                    code="keil_map.missing_sections",
                    severity=DiagnosticSeverity.WARNING,
                    message="No output sections were detected in Keil MAP file.",
                    source_path=path,
                )
            )

        unresolved_section_count = sum(1 for section in sections if section.execution_region is None)
        if unresolved_section_count:
            diagnostics.append(
                ParseDiagnostic(
                    code="keil_map.section_region_ambiguity",
                    severity=DiagnosticSeverity.WARNING,
                    message=(
                        f"{unresolved_section_count} section(s) could not be mapped to a memory region "
                        "from Keil MAP declarations."
                    ),
                    source_path=path,
                )
            )

        return ArtifactParseResult(
            artifact_type=ArtifactType.MAP,
            path=path,
            toolchain=ToolchainKind.KEIL if toolchain == ToolchainKind.UNKNOWN else toolchain,
            memory_regions=memory_regions,
            sections=sections,
            symbols=symbols,
            diagnostics=diagnostics,
            raw_tree={
                "line_count": len(lines),
                "detected_regions": len(memory_regions),
                "detected_sections": len(sections),
                "detected_symbols": len(symbols),
            },
        )
