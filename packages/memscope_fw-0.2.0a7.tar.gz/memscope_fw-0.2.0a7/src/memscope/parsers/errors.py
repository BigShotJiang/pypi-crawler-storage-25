"""Parser error types."""

from __future__ import annotations

from memscope.parsers.models import ParseDiagnostic


class ParserError(RuntimeError):
    """Structured parser failure carrying a diagnostic."""

    def __init__(self, diagnostic: ParseDiagnostic) -> None:
        self.diagnostic = diagnostic
        super().__init__(diagnostic.message)

