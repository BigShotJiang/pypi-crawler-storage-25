"""Parser-layer models and diagnostics."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path


class DiagnosticSeverity(StrEnum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"


class ArtifactType(StrEnum):
    ELF = "elf"
    MAP = "map"
    LINKER = "linker"
    DWARF = "dwarf"
    UNKNOWN = "unknown"


class ToolchainKind(StrEnum):
    GNU = "gnu"
    CLANG_LLD = "clang_lld"
    IAR = "iar"
    KEIL = "keil"
    UNKNOWN = "unknown"


@dataclass(slots=True)
class ParseDiagnostic:
    code: str
    severity: DiagnosticSeverity
    message: str
    source_path: Path | None = None
    line: int | None = None
    column: int | None = None

    def to_debug_dict(self) -> dict[str, object]:
        return {
            "code": self.code,
            "severity": self.severity.value,
            "message": self.message,
            "source_path": str(self.source_path) if self.source_path else None,
            "line": self.line,
            "column": self.column,
        }


@dataclass(slots=True)
class MemoryRegionRecord:
    name: str
    start_address: int
    size: int
    attributes: tuple[str, ...] = ()
    source: str = "parser"
    line: int | None = None

    @property
    def end_address(self) -> int:
        return self.start_address + self.size - 1

    def contains(self, address: int) -> bool:
        return self.start_address <= address <= self.end_address

    def to_debug_dict(self) -> dict[str, object]:
        return {
            "name": self.name,
            "start_address": self.start_address,
            "end_address": self.end_address,
            "size": self.size,
            "attributes": list(self.attributes),
            "source": self.source,
            "line": self.line,
        }


@dataclass(slots=True)
class SectionRecord:
    name: str
    vma: int
    lma: int
    size: int
    execution_region: str | None = None
    load_region: str | None = None
    line: int | None = None

    def to_debug_dict(self) -> dict[str, object]:
        return {
            "name": self.name,
            "vma": self.vma,
            "lma": self.lma,
            "size": self.size,
            "execution_region": self.execution_region,
            "load_region": self.load_region,
            "line": self.line,
        }


@dataclass(slots=True)
class SymbolRecord:
    name: str
    address: int
    size: int = 0
    section_name: str | None = None
    object_file: str | None = None
    line: int | None = None

    def to_debug_dict(self) -> dict[str, object]:
        return {
            "name": self.name,
            "address": self.address,
            "size": self.size,
            "section_name": self.section_name,
            "object_file": self.object_file,
            "line": self.line,
        }


@dataclass(slots=True)
class ArtifactParseResult:
    artifact_type: ArtifactType
    path: Path
    toolchain: ToolchainKind
    memory_regions: list[MemoryRegionRecord] = field(default_factory=list)
    sections: list[SectionRecord] = field(default_factory=list)
    symbols: list[SymbolRecord] = field(default_factory=list)
    diagnostics: list[ParseDiagnostic] = field(default_factory=list)
    raw_tree: dict[str, object] = field(default_factory=dict)

    def has_errors(self) -> bool:
        return any(diagnostic.severity == DiagnosticSeverity.ERROR for diagnostic in self.diagnostics)

    def to_debug_dict(self) -> dict[str, object]:
        return {
            "artifact_type": self.artifact_type.value,
            "path": str(self.path),
            "toolchain": self.toolchain.value,
            "memory_regions": [region.to_debug_dict() for region in self.memory_regions],
            "sections": [section.to_debug_dict() for section in self.sections],
            "symbols": [symbol.to_debug_dict() for symbol in self.symbols],
            "diagnostics": [diagnostic.to_debug_dict() for diagnostic in self.diagnostics],
            "raw_tree": _coerce_jsonish(self.raw_tree),
        }


@dataclass(slots=True)
class ParsedArtifactSet:
    toolchain_detected: ToolchainKind
    elf: ArtifactParseResult | None = None
    map: ArtifactParseResult | None = None
    linker: ArtifactParseResult | None = None
    dwarf: ArtifactParseResult | None = None
    diagnostics: list[ParseDiagnostic] = field(default_factory=list)
    assumptions: tuple[str, ...] = ()
    unresolved_ambiguities: tuple[str, ...] = ()

    def all_diagnostics(self) -> list[ParseDiagnostic]:
        result: list[ParseDiagnostic] = []
        for artifact_result in (self.elf, self.map, self.linker, self.dwarf):
            if artifact_result is not None:
                result.extend(artifact_result.diagnostics)
        result.extend(self.diagnostics)
        return result

    def has_errors(self) -> bool:
        return any(diagnostic.severity == DiagnosticSeverity.ERROR for diagnostic in self.all_diagnostics())

    def to_debug_dict(self) -> dict[str, object]:
        return {
            "toolchain_detected": self.toolchain_detected.value,
            "assumptions": list(self.assumptions),
            "unresolved_ambiguities": list(self.unresolved_ambiguities),
            "diagnostics": [diagnostic.to_debug_dict() for diagnostic in self.diagnostics],
            "elf": self.elf.to_debug_dict() if self.elf else None,
            "map": self.map.to_debug_dict() if self.map else None,
            "linker": self.linker.to_debug_dict() if self.linker else None,
            "dwarf": self.dwarf.to_debug_dict() if self.dwarf else None,
        }


def _coerce_jsonish(value: object) -> object:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(k): _coerce_jsonish(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_coerce_jsonish(item) for item in value]
    if isinstance(value, tuple):
        return [_coerce_jsonish(item) for item in value]
    return str(value)
