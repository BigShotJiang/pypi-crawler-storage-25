"""Base parser interfaces."""

from __future__ import annotations

from pathlib import Path
from typing import Protocol

from memscope.parsers.models import ArtifactParseResult, ArtifactType, ToolchainKind


class ArtifactParser(Protocol):
    artifact_type: ArtifactType

    def parse(self, path: Path, *, toolchain: ToolchainKind) -> ArtifactParseResult:
        """Parse one artifact file into structured intermediate data."""
        ...

