"""GNU ld script parser (v1 focused implementation)."""

from __future__ import annotations

import re
from pathlib import Path

from memscope.parsers.models import (
    ArtifactParseResult,
    ArtifactType,
    DiagnosticSeverity,
    MemoryRegionRecord,
    ParseDiagnostic,
    SectionRecord,
    ToolchainKind,
)

_MEMORY_LINE = re.compile(
    r"^\s*(?P<name>[A-Za-z_][\w.$-]*)\s*(?:\((?P<attrs>[^)]+)\))?\s*:\s*ORIGIN\s*=\s*(?P<origin>[^,]+),\s*LENGTH\s*=\s*(?P<length>.+?)\s*$"
)
_SECTION_START = re.compile(r"^\s*(?P<name>\.[A-Za-z_][\w.$-]*)\s*:[^{]*\{")
_SECTION_INLINE_REGION = re.compile(
    r"^\s*(?P<name>\.[A-Za-z_][\w.$-]*).*>\s*(?P<region>[A-Za-z_][\w.$-]*)(?:\s+AT\s*>\s*(?P<load>[A-Za-z_][\w.$-]*))?.*$"
)
_SECTION_CLOSE_REGION = re.compile(
    r"^\s*}\s*>\s*(?P<region>[A-Za-z_][\w.$-]*)(?:\s+AT\s*>\s*(?P<load>[A-Za-z_][\w.$-]*))?.*$"
)


def _parse_int_expression(token: str) -> int:
    normalized = token.strip().replace("_", "")
    suffix_multiplier = 1
    if normalized.endswith(("K", "k")):
        suffix_multiplier = 1024
        normalized = normalized[:-1]
    elif normalized.endswith(("M", "m")):
        suffix_multiplier = 1024 * 1024
        normalized = normalized[:-1]
    base_value = int(normalized, 0)
    return base_value * suffix_multiplier


class GNULdParser:
    artifact_type = ArtifactType.LINKER

    def parse(self, path: Path, *, toolchain: ToolchainKind) -> ArtifactParseResult:
        text = path.read_text(encoding="utf-8", errors="replace")
        lines = text.splitlines()

        diagnostics: list[ParseDiagnostic] = []
        memory_regions: list[MemoryRegionRecord] = []
        sections: list[SectionRecord] = []

        in_memory_block = False
        pending_section_name: str | None = None
        pending_section_line: int | None = None

        for line_number, line in enumerate(lines, start=1):
            stripped = line.strip()
            if stripped.startswith("MEMORY"):
                in_memory_block = True
                continue

            if in_memory_block:
                if stripped.startswith("}"):
                    in_memory_block = False
                    continue

                memory_match = _MEMORY_LINE.match(line)
                if memory_match:
                    try:
                        origin = _parse_int_expression(memory_match.group("origin"))
                        length = _parse_int_expression(memory_match.group("length"))
                    except ValueError:
                        diagnostics.append(
                            ParseDiagnostic(
                                code="gnu_ld.invalid_memory_row",
                                severity=DiagnosticSeverity.WARNING,
                                message=f"Could not parse MEMORY line: {line.strip()}",
                                source_path=path,
                                line=line_number,
                            )
                        )
                        continue

                    if length <= 0:
                        diagnostics.append(
                            ParseDiagnostic(
                                code="gnu_ld.invalid_memory_length",
                                severity=DiagnosticSeverity.WARNING,
                                message=f"Region {memory_match.group('name')} has non-positive length.",
                                source_path=path,
                                line=line_number,
                            )
                        )
                        continue

                    attrs_raw = memory_match.group("attrs") or ""
                    attributes = tuple(sorted({ch for ch in attrs_raw.lower() if ch.isalpha()}))
                    memory_regions.append(
                        MemoryRegionRecord(
                            name=memory_match.group("name"),
                            start_address=origin,
                            size=length,
                            attributes=attributes,
                            source="linker",
                            line=line_number,
                        )
                    )
                continue

            inline_match = _SECTION_INLINE_REGION.match(line)
            if inline_match:
                sections.append(
                    SectionRecord(
                        name=inline_match.group("name"),
                        vma=0,
                        lma=0,
                        size=0,
                        execution_region=inline_match.group("region"),
                        load_region=inline_match.group("load") or inline_match.group("region"),
                        line=line_number,
                    )
                )
                pending_section_name = None
                pending_section_line = None
                continue

            start_match = _SECTION_START.match(line)
            if start_match:
                pending_section_name = start_match.group("name")
                pending_section_line = line_number
                continue

            if pending_section_name:
                close_match = _SECTION_CLOSE_REGION.match(line)
                if close_match:
                    sections.append(
                        SectionRecord(
                            name=pending_section_name,
                            vma=0,
                            lma=0,
                            size=0,
                            execution_region=close_match.group("region"),
                            load_region=close_match.group("load") or close_match.group("region"),
                            line=pending_section_line,
                        )
                    )
                    pending_section_name = None
                    pending_section_line = None

        if not memory_regions:
            diagnostics.append(
                ParseDiagnostic(
                    code="gnu_ld.missing_memory_block",
                    severity=DiagnosticSeverity.WARNING,
                    message="No MEMORY regions were detected in linker script.",
                    source_path=path,
                )
            )

        if not sections:
            diagnostics.append(
                ParseDiagnostic(
                    code="gnu_ld.missing_sections",
                    severity=DiagnosticSeverity.WARNING,
                    message="No section placement rules were detected in linker script.",
                    source_path=path,
                )
            )

        return ArtifactParseResult(
            artifact_type=ArtifactType.LINKER,
            path=path,
            toolchain=ToolchainKind.GNU if toolchain == ToolchainKind.UNKNOWN else toolchain,
            memory_regions=memory_regions,
            sections=sections,
            diagnostics=diagnostics,
            raw_tree={
                "line_count": len(lines),
                "detected_regions": len(memory_regions),
                "detected_section_rules": len(sections),
            },
        )

