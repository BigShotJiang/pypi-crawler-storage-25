"""IAR ICF linker script parser (v1 compatibility implementation)."""

from __future__ import annotations

import ast
import re
from pathlib import Path

from memscope.parsers.models import (
    ArtifactParseResult,
    ArtifactType,
    DiagnosticSeverity,
    MemoryRegionRecord,
    ParseDiagnostic,
    SectionRecord,
    ToolchainKind,
)

_HEX_OR_INT = r"(?:0x[0-9a-fA-F']+|\d[\d']*)"
_IDENTIFIER = r"[A-Za-z_][\w.$-]*"
_SYMBOL_DEFINE_LINE = re.compile(
    rf"^\s*define\s+symbol\s+(?P<name>{_IDENTIFIER})\s*=\s*(?P<expr>.+?)\s*;\s*$",
    flags=re.IGNORECASE,
)
_REGION_DEFINE_LINE = re.compile(
    rf"^\s*define\s+region\s+(?P<name>{_IDENTIFIER})\s*=\s*[^[]*\[\s*from\s+(?P<origin>.+?)\s+size\s+(?P<size>.+?)\s*]\s*;\s*$",
    flags=re.IGNORECASE,
)
_BLOCK_START_LINE = re.compile(
    rf"^\s*define\s+block\s+(?P<name>{_IDENTIFIER})\b(?P<rest>.*)$",
    flags=re.IGNORECASE,
)
_PLACE_START_LINE = re.compile(
    rf'^\s*(?:"[^"]+"\s*:\s*)?place\s+in\s+(?P<region>{_IDENTIFIER})\s*\{{(?P<body>.*)$',
    flags=re.IGNORECASE,
)
_SECTION_TOKEN = re.compile(
    r"(?:readonly|readwrite)?\s*section\s+(?P<name>[A-Za-z_.][\w.$*-]*)",
    flags=re.IGNORECASE,
)
_BLOCK_TOKEN = re.compile(
    rf"(?:first|last)?\s*block\s+(?P<name>{_IDENTIFIER})",
    flags=re.IGNORECASE,
)
_COMMENT_BLOCK = re.compile(r"/\*.*?\*/")


def _strip_inline_comments(line: str) -> str:
    without_block = _COMMENT_BLOCK.sub("", line)
    if "//" in without_block:
        return without_block.split("//", maxsplit=1)[0]
    return without_block


def _normalize_numeric_tokens(expression: str) -> str:
    return expression.replace("'", "")


def _eval_expression(expression: str, symbols: dict[str, int]) -> int:
    normalized = _normalize_numeric_tokens(expression).strip()
    tree = ast.parse(normalized, mode="eval")

    def _visit(node: ast.AST) -> int:
        if isinstance(node, ast.Expression):
            return _visit(node.body)
        if isinstance(node, ast.Constant):
            if isinstance(node.value, bool):
                raise ValueError("Boolean values are not allowed.")
            if isinstance(node.value, int):
                return node.value
            raise ValueError("Only integer constants are supported.")
        if isinstance(node, ast.Name):
            if node.id not in symbols:
                raise KeyError(node.id)
            return symbols[node.id]
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            value = _visit(node.operand)
            return value if isinstance(node.op, ast.UAdd) else -value
        if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.FloorDiv, ast.Div)):
            left = _visit(node.left)
            right = _visit(node.right)
            if isinstance(node.op, ast.Add):
                return left + right
            if isinstance(node.op, ast.Sub):
                return left - right
            if right == 0:
                raise ValueError("Division by zero in expression.")
            if isinstance(node.op, ast.Mult):
                return left * right
            if isinstance(node.op, ast.FloorDiv):
                return left // right
            return left // right
        raise ValueError("Unsupported expression syntax.")

    return _visit(tree)


def _extract_body(buffer: list[str]) -> str:
    joined = " ".join(buffer)
    if "{" not in joined:
        return ""
    after_open = joined.split("{", maxsplit=1)[1]
    before_close = after_open.split("};", maxsplit=1)[0]
    return before_close.strip()


def _ordered_unique(items: list[str]) -> list[str]:
    return list(dict.fromkeys(items))


class IARICFParser:
    artifact_type = ArtifactType.LINKER

    def parse(self, path: Path, *, toolchain: ToolchainKind) -> ArtifactParseResult:
        text = path.read_text(encoding="utf-8", errors="replace")
        lines = text.splitlines()

        diagnostics: list[ParseDiagnostic] = []
        memory_regions: list[MemoryRegionRecord] = []
        sections: list[SectionRecord] = []
        resolved_symbols: dict[str, int] = {}
        unresolved_symbol_defs: list[tuple[str, str, int]] = []

        for line_number, line in enumerate(lines, start=1):
            stripped = _strip_inline_comments(line).strip()
            if not stripped:
                continue
            symbol_match = _SYMBOL_DEFINE_LINE.match(stripped)
            if not symbol_match:
                continue
            unresolved_symbol_defs.append(
                (
                    symbol_match.group("name"),
                    symbol_match.group("expr"),
                    line_number,
                )
            )

        pending_symbols = list(unresolved_symbol_defs)
        for _ in range(len(unresolved_symbol_defs) + 1):
            if not pending_symbols:
                break
            resolved_in_pass = False
            next_pending: list[tuple[str, str, int]] = []
            for name, expression, line_number in pending_symbols:
                try:
                    resolved_symbols[name] = _eval_expression(expression, resolved_symbols)
                    resolved_in_pass = True
                except KeyError:
                    next_pending.append((name, expression, line_number))
                except (SyntaxError, ValueError) as exc:
                    diagnostics.append(
                        ParseDiagnostic(
                            code="iar_icf.invalid_symbol_expression",
                            severity=DiagnosticSeverity.WARNING,
                            message=f"Could not evaluate symbol {name}: {exc}",
                            source_path=path,
                            line=line_number,
                        )
                    )
            pending_symbols = next_pending
            if not resolved_in_pass:
                break

        for name, expression, line_number in pending_symbols:
            diagnostics.append(
                ParseDiagnostic(
                    code="iar_icf.unresolved_symbol_expression",
                    severity=DiagnosticSeverity.WARNING,
                    message=(
                        f"Symbol {name} references unresolved expression '{expression.strip()}'."
                    ),
                    source_path=path,
                    line=line_number,
                )
            )

        block_sections: dict[str, list[str]] = {}
        pending_block_name: str | None = None
        pending_block_start_line: int | None = None
        pending_block_buffer: list[str] = []

        pending_place_region: str | None = None
        pending_place_line: int | None = None
        pending_place_buffer: list[str] = []

        for line_number, line in enumerate(lines, start=1):
            stripped = _strip_inline_comments(line).strip()
            if not stripped:
                continue

            region_match = _REGION_DEFINE_LINE.match(line)
            if region_match:
                region_name = region_match.group("name")
                try:
                    origin = _eval_expression(region_match.group("origin"), resolved_symbols)
                    size = _eval_expression(region_match.group("size"), resolved_symbols)
                except KeyError as exc:
                    diagnostics.append(
                        ParseDiagnostic(
                            code="iar_icf.unresolved_region_expression",
                            severity=DiagnosticSeverity.WARNING,
                            message=(
                                f"Could not resolve region {region_name} expression "
                                f"due to unknown symbol {exc.args[0]}."
                            ),
                            source_path=path,
                            line=line_number,
                        )
                    )
                    continue
                except (SyntaxError, ValueError) as exc:
                    diagnostics.append(
                        ParseDiagnostic(
                            code="iar_icf.invalid_region_expression",
                            severity=DiagnosticSeverity.WARNING,
                            message=f"Could not evaluate region {region_name}: {exc}",
                            source_path=path,
                            line=line_number,
                        )
                    )
                    continue

                if size > 0 and origin >= 0:
                    memory_regions.append(
                        MemoryRegionRecord(
                            name=region_name,
                            start_address=origin,
                            size=size,
                            attributes=(),
                            source="linker",
                            line=line_number,
                        )
                    )
                else:
                    diagnostics.append(
                        ParseDiagnostic(
                            code="iar_icf.non_positive_region_size",
                            severity=DiagnosticSeverity.WARNING,
                            message=f"Region {region_name} has non-positive size {size}.",
                            source_path=path,
                            line=line_number,
                        )
                    )
                continue

            if pending_block_name is None:
                block_start_match = _BLOCK_START_LINE.match(stripped)
                if block_start_match:
                    pending_block_name = block_start_match.group("name")
                    pending_block_start_line = line_number
                    pending_block_buffer = [stripped]
                    if "};" in stripped:
                        block_body = _extract_body(pending_block_buffer)
                        block_sections[pending_block_name] = _ordered_unique(
                            [match.group("name") for match in _SECTION_TOKEN.finditer(block_body)]
                        )
                        pending_block_name = None
                        pending_block_start_line = None
                        pending_block_buffer = []
                    continue
            else:
                pending_block_buffer.append(stripped)
                if "};" in stripped:
                    block_body = _extract_body(pending_block_buffer)
                    block_sections[pending_block_name] = _ordered_unique(
                        [match.group("name") for match in _SECTION_TOKEN.finditer(block_body)]
                    )
                    pending_block_name = None
                    pending_block_start_line = None
                    pending_block_buffer = []
                continue

            if pending_place_region is None:
                place_start_match = _PLACE_START_LINE.match(stripped)
                if not place_start_match:
                    continue

                pending_place_region = place_start_match.group("region")
                pending_place_line = line_number
                pending_place_buffer = [place_start_match.group("body")]
                if "};" not in stripped:
                    continue
            else:
                pending_place_buffer.append(stripped)
                if "};" not in stripped:
                    continue

            region_name = pending_place_region
            source_line = pending_place_line or line_number
            body = " ".join(pending_place_buffer).split("};", maxsplit=1)[0]
            section_names = [match.group("name") for match in _SECTION_TOKEN.finditer(body)]

            expanded_from_blocks: list[str] = []
            for block_match in _BLOCK_TOKEN.finditer(body):
                block_name = block_match.group("name")
                expanded_from_blocks.extend(block_sections.get(block_name, []))

            section_names.extend(expanded_from_blocks)
            section_names = _ordered_unique(section_names)
            if not section_names:
                lowered_body = body.lower()
                # Compatibility fallback when ICF placement does not list explicit sections.
                if "readonly" in lowered_body:
                    section_names = [".iar.readonly"]
                elif "readwrite" in lowered_body:
                    section_names = [".iar.readwrite"]
                else:
                    section_names = [".iar.group"]

            for section_name in section_names:
                sections.append(
                    SectionRecord(
                        name=section_name,
                        vma=0,
                        lma=0,
                        size=0,
                        execution_region=region_name,
                        load_region=region_name,
                        line=source_line,
                    )
                )

            pending_place_region = None
            pending_place_line = None
            pending_place_buffer = []

        if pending_block_name is not None:
            diagnostics.append(
                ParseDiagnostic(
                    code="iar_icf.unterminated_block_definition",
                    severity=DiagnosticSeverity.WARNING,
                    message=f"Block definition {pending_block_name} was not terminated with '}};'.",
                    source_path=path,
                    line=pending_block_start_line,
                )
            )

        if pending_place_region is not None:
            diagnostics.append(
                ParseDiagnostic(
                    code="iar_icf.unterminated_place_clause",
                    severity=DiagnosticSeverity.WARNING,
                    message=f"Placement rule for region {pending_place_region} was not terminated with '}};'.",
                    source_path=path,
                    line=pending_place_line,
                )
            )

        if not memory_regions:
            diagnostics.append(
                ParseDiagnostic(
                    code="iar_icf.missing_regions",
                    severity=DiagnosticSeverity.WARNING,
                    message="No region definitions were detected in IAR ICF script.",
                    source_path=path,
                )
            )

        if not sections:
            diagnostics.append(
                ParseDiagnostic(
                    code="iar_icf.missing_placements",
                    severity=DiagnosticSeverity.WARNING,
                    message="No placement rules were detected in IAR ICF script.",
                    source_path=path,
                )
            )

        return ArtifactParseResult(
            artifact_type=ArtifactType.LINKER,
            path=path,
            toolchain=ToolchainKind.IAR if toolchain == ToolchainKind.UNKNOWN else toolchain,
            memory_regions=memory_regions,
            sections=sections,
            diagnostics=diagnostics,
            raw_tree={
                "line_count": len(lines),
                "resolved_symbols": len(resolved_symbols),
                "detected_regions": len(memory_regions),
                "detected_block_definitions": len(block_sections),
                "detected_section_rules": len(sections),
            },
        )
