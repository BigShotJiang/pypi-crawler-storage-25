"""Keil scatter-file parser (v1 compatibility implementation)."""

from __future__ import annotations

import re
from pathlib import Path

from memscope.parsers.models import (
    ArtifactParseResult,
    ArtifactType,
    DiagnosticSeverity,
    MemoryRegionRecord,
    ParseDiagnostic,
    SectionRecord,
    ToolchainKind,
)

_HEX_OR_INT = r"(?:0x[0-9a-fA-F]+|\d+)"
_REGION_START = re.compile(
    rf"^\s*(?P<name>[A-Za-z_][\w.$-]*)\s+(?P<origin>{_HEX_OR_INT})\s+(?P<size>{_HEX_OR_INT}).*\{{\s*(?:;.*)?$"
)
_SECTION_LINE = re.compile(r"^\s*(?P<name>\.[A-Za-z_][\w.$-]*).*?(?:;.*)?$")


def _parse_int(value: str) -> int:
    return int(value, 0)


class KeilScatterParser:
    artifact_type = ArtifactType.LINKER

    def parse(self, path: Path, *, toolchain: ToolchainKind) -> ArtifactParseResult:
        text = path.read_text(encoding="utf-8", errors="replace")
        lines = text.splitlines()

        diagnostics: list[ParseDiagnostic] = []
        memory_regions: list[MemoryRegionRecord] = []
        sections: list[SectionRecord] = []

        region_stack: list[str] = []
        section_without_region = 0

        for line_number, line in enumerate(lines, start=1):
            region_match = _REGION_START.match(line)
            if region_match:
                region_name = region_match.group("name")
                size = _parse_int(region_match.group("size"))
                if size > 0:
                    memory_regions.append(
                        MemoryRegionRecord(
                            name=region_name,
                            start_address=_parse_int(region_match.group("origin")),
                            size=size,
                            attributes=(),
                            source="linker",
                            line=line_number,
                        )
                    )
                    region_stack.append(region_name)
                continue

            section_match = _SECTION_LINE.match(line)
            if section_match:
                current_region = region_stack[-1] if region_stack else None
                if current_region is None:
                    section_without_region += 1
                sections.append(
                    SectionRecord(
                        name=section_match.group("name"),
                        vma=0,
                        lma=0,
                        size=0,
                        execution_region=current_region,
                        load_region=current_region,
                        line=line_number,
                    )
                )

            close_count = line.count("}")
            if close_count and region_stack:
                region_stack = region_stack[: max(0, len(region_stack) - close_count)]

        if not memory_regions:
            diagnostics.append(
                ParseDiagnostic(
                    code="keil_scatter.missing_regions",
                    severity=DiagnosticSeverity.WARNING,
                    message="No region declarations were detected in Keil scatter file.",
                    source_path=path,
                )
            )

        if not sections:
            diagnostics.append(
                ParseDiagnostic(
                    code="keil_scatter.missing_placements",
                    severity=DiagnosticSeverity.WARNING,
                    message="No section placement entries were detected in Keil scatter file.",
                    source_path=path,
                )
            )

        if section_without_region:
            diagnostics.append(
                ParseDiagnostic(
                    code="keil_scatter.unresolved_execution_region",
                    severity=DiagnosticSeverity.WARNING,
                    message=(
                        f"{section_without_region} section placement line(s) had no active region context "
                        "while parsing scatter file."
                    ),
                    source_path=path,
                )
            )

        return ArtifactParseResult(
            artifact_type=ArtifactType.LINKER,
            path=path,
            toolchain=ToolchainKind.KEIL if toolchain == ToolchainKind.UNKNOWN else toolchain,
            memory_regions=memory_regions,
            sections=sections,
            diagnostics=diagnostics,
            raw_tree={
                "line_count": len(lines),
                "detected_regions": len(memory_regions),
                "detected_section_rules": len(sections),
            },
        )
