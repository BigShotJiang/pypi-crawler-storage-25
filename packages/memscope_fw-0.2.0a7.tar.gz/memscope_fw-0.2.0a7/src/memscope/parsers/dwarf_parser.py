"""DWARF parser placeholder for v1."""

from __future__ import annotations

from pathlib import Path

from memscope.parsers.models import (
    ArtifactParseResult,
    ArtifactType,
    DiagnosticSeverity,
    ParseDiagnostic,
    ToolchainKind,
)


class DwarfParser:
    artifact_type = ArtifactType.DWARF

    def parse(self, path: Path, *, toolchain: ToolchainKind) -> ArtifactParseResult:
        return ArtifactParseResult(
            artifact_type=ArtifactType.DWARF,
            path=path,
            toolchain=toolchain,
            diagnostics=[
                ParseDiagnostic(
                    code="dwarf.not_implemented",
                    severity=DiagnosticSeverity.WARNING,
                    message="DWARF parsing is not implemented yet; continuing without DWARF symbols.",
                    source_path=path,
                )
            ],
            raw_tree={"status": "stub"},
        )

