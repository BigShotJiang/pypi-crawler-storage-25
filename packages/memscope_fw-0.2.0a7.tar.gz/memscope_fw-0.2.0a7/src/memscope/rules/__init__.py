"""Rules and policy engine primitives."""

from memscope.rules.base import Rule, RuleContext, RuleEvaluation
from memscope.rules.registry import RuleRegistry, default_rule_registry
from memscope.rules.suppressions import (
    SuppressedIssue,
    SuppressionResult,
    SuppressionSet,
    apply_suppressions,
)

__all__ = [
    "Rule",
    "RuleContext",
    "RuleEvaluation",
    "RuleRegistry",
    "SuppressedIssue",
    "SuppressionResult",
    "SuppressionSet",
    "apply_suppressions",
    "default_rule_registry",
]
