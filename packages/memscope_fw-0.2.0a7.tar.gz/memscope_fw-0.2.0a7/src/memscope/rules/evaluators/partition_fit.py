"""OTA and partition-fit policy evaluator."""

from __future__ import annotations

from memscope.analysis.region_usage import compute_region_usage
from memscope.domain import Issue, IssueCategory, IssueSeverity
from memscope.rules.base import RuleContext, RuleEvaluation


class OtaPartitionFitRule:
    """Evaluate partition sizing and OTA slot fit policies."""

    rule_id = "ota_partition_fit"
    description = "Checks static partition limits and OTA slot fit constraints."

    def evaluate(self, context: RuleContext) -> RuleEvaluation:
        issues: list[Issue] = []
        existing_ids = {issue.id for issue in context.report.issues}
        region_usage = compute_region_usage(context.model)
        warn_ratio = context.config.policies.ota_warn_ratio

        for partition_name, max_bytes in sorted(context.config.policies.partition_max_bytes.items()):
            usage = region_usage.get(partition_name)
            if usage is None:
                issue_id = f"partition_fit.unknown_region.{partition_name}"
                if issue_id not in existing_ids:
                    issues.append(
                        Issue(
                            id=issue_id,
                            severity=IssueSeverity.WARNING,
                            category=IssueCategory.POLICY,
                            title="Partition policy references unknown region",
                            description=(
                                f"Partition limit is configured for region {partition_name}, "
                                "but it is missing from the normalized memory model."
                            ),
                            affected_entities=(partition_name,),
                            remediation_hint="Fix the configured region name or update linker parsing inputs.",
                        )
                    )
                    existing_ids.add(issue_id)
                continue

            used_bytes = usage.used_bytes
            overflow_id = f"partition_fit.{partition_name}"
            near_id = f"partition_near_capacity.{partition_name}"
            if used_bytes > max_bytes and overflow_id not in existing_ids:
                issues.append(
                    Issue(
                        id=overflow_id,
                        severity=IssueSeverity.ERROR,
                        category=IssueCategory.POLICY,
                        title="Partition size limit exceeded",
                        description=(
                            f"Region {partition_name} uses {used_bytes} bytes, "
                            f"above configured partition limit {max_bytes} bytes."
                        ),
                        affected_entities=(partition_name,),
                        remediation_hint="Reduce image size or increase this partition limit.",
                    )
                )
                existing_ids.add(overflow_id)
            elif (
                warn_ratio is not None
                and used_bytes >= int(max_bytes * warn_ratio)
                and near_id not in existing_ids
                and overflow_id not in existing_ids
            ):
                issues.append(
                    Issue(
                        id=near_id,
                        severity=IssueSeverity.WARNING,
                        category=IssueCategory.POLICY,
                        title="Partition near capacity",
                        description=(
                            f"Region {partition_name} uses {used_bytes} bytes, "
                            f"near configured partition limit {max_bytes} bytes."
                        ),
                        affected_entities=(partition_name,),
                        remediation_hint="Monitor growth for this partition.",
                    )
                )
                existing_ids.add(near_id)

        slot_limits = (
            ("slot_a", context.config.policies.ota_slot_a_max_bytes),
            ("slot_b", context.config.policies.ota_slot_b_max_bytes),
        )
        if any(limit is not None for _, limit in slot_limits):
            source_regions = context.config.policies.ota_source_regions
            missing_regions = [name for name in source_regions if name not in region_usage]
            for region_name in sorted(set(missing_regions)):
                issue_id = f"ota_source_region.{region_name}"
                if issue_id in existing_ids:
                    continue
                issues.append(
                    Issue(
                        id=issue_id,
                        severity=IssueSeverity.WARNING,
                        category=IssueCategory.POLICY,
                        title="OTA source region is missing",
                        description=(
                            f"Configured OTA source region {region_name} was not found in the build model."
                        ),
                        affected_entities=(region_name,),
                        remediation_hint="Update ota_source_regions or inspect parser inputs.",
                    )
                )
                existing_ids.add(issue_id)

            ota_image_bytes = sum(
                region_usage[name].used_bytes
                for name in source_regions
                if name in region_usage
            )

            for slot_name, limit in slot_limits:
                if limit is None:
                    continue
                overflow_id = f"ota_fit.{slot_name}"
                near_id = f"ota_near_capacity.{slot_name}"
                if ota_image_bytes > limit and overflow_id not in existing_ids:
                    issues.append(
                        Issue(
                            id=overflow_id,
                            severity=IssueSeverity.ERROR,
                            category=IssueCategory.POLICY,
                            title="OTA slot capacity exceeded",
                            description=(
                                f"OTA image footprint is {ota_image_bytes} bytes across "
                                f"{', '.join(source_regions) or 'configured regions'}, "
                                f"above {slot_name} capacity {limit} bytes."
                            ),
                            affected_entities=source_regions or (slot_name,),
                            remediation_hint=(
                                "Reduce image size or increase OTA slot size/partitioning."
                            ),
                        )
                    )
                    existing_ids.add(overflow_id)
                elif (
                    warn_ratio is not None
                    and ota_image_bytes >= int(limit * warn_ratio)
                    and near_id not in existing_ids
                    and overflow_id not in existing_ids
                ):
                    issues.append(
                        Issue(
                            id=near_id,
                            severity=IssueSeverity.WARNING,
                            category=IssueCategory.POLICY,
                            title="OTA slot near capacity",
                            description=(
                                f"OTA image footprint is {ota_image_bytes} bytes across "
                                f"{', '.join(source_regions) or 'configured regions'}, "
                                f"near {slot_name} capacity {limit} bytes."
                            ),
                            affected_entities=source_regions or (slot_name,),
                            remediation_hint="Monitor growth and keep OTA update headroom.",
                        )
                    )
                    existing_ids.add(near_id)

        return RuleEvaluation(rule_id=self.rule_id, issues=issues)
