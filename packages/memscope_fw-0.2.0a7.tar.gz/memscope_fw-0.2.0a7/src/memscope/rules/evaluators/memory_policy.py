"""Advanced memory policy packs (DMA/cacheability/retention)."""

from __future__ import annotations

from fnmatch import fnmatch

from memscope.domain import Issue, IssueCategory, IssueSeverity, MemoryRegion, MemoryRegionCategory
from memscope.rules.base import RuleContext, RuleEvaluation


class AdvancedMemoryPolicyRule:
    """Evaluate DMA, cacheability, and retention placement policies."""

    rule_id = "advanced_memory_policies"
    description = "Checks DMA/cacheability/retention section placement policies."

    def evaluate(self, context: RuleContext) -> RuleEvaluation:
        issues: list[Issue] = []
        existing_ids = {issue.id for issue in context.report.issues}
        regions_by_name = {region.name: region for region in context.model.memory_regions}

        dma_safe_regions = _lowered_name_set(context.config.policies.dma_safe_regions)
        non_cacheable_regions = _lowered_name_set(context.config.policies.non_cacheable_regions)
        cacheable_regions = _lowered_name_set(context.config.policies.cacheable_regions)
        retention_regions = _lowered_name_set(context.config.policies.retention_regions)

        for section in context.model.sections:
            section_name = section.name
            execution_region_name = section.execution_region
            region = regions_by_name.get(execution_region_name or "")
            affected_entities = (
                section_name,
                execution_region_name or "unmapped_execution_region",
            )

            if _matches_any(section_name, context.config.policies.dma_section_patterns):
                issue_id = f"memory_policy.dma.{section_name}.{execution_region_name or 'unmapped'}"
                if issue_id not in existing_ids and not _is_dma_safe_region(
                    region,
                    execution_region_name,
                    dma_safe_regions,
                ):
                    issues.append(
                        Issue(
                            id=issue_id,
                            severity=IssueSeverity.ERROR,
                            category=IssueCategory.POLICY,
                            title="DMA placement policy violated",
                            description=(
                                f"Section {section_name} is in {execution_region_name or 'unmapped region'}, "
                                "but DMA policy requires a DMA-safe region."
                            ),
                            affected_entities=affected_entities,
                            remediation_hint=(
                                "Move section to DMA-safe memory or configure policies.dma_safe_regions."
                            ),
                        )
                    )
                    existing_ids.add(issue_id)

            if _matches_any(section_name, context.config.policies.non_cacheable_section_patterns):
                issue_id = f"memory_policy.non_cacheable.{section_name}.{execution_region_name or 'unmapped'}"
                if issue_id not in existing_ids and not _is_non_cacheable_region(
                    region,
                    execution_region_name,
                    non_cacheable_regions,
                ):
                    issues.append(
                        Issue(
                            id=issue_id,
                            severity=IssueSeverity.ERROR,
                            category=IssueCategory.POLICY,
                            title="Non-cacheable placement policy violated",
                            description=(
                                f"Section {section_name} is in {execution_region_name or 'unmapped region'}, "
                                "but policy requires a non-cacheable region."
                            ),
                            affected_entities=affected_entities,
                            remediation_hint=(
                                "Move section to non-cacheable memory or configure policies.non_cacheable_regions."
                            ),
                        )
                    )
                    existing_ids.add(issue_id)

            if _matches_any(section_name, context.config.policies.cacheable_section_patterns):
                issue_id = f"memory_policy.cacheable.{section_name}.{execution_region_name or 'unmapped'}"
                if issue_id not in existing_ids and not _is_cacheable_region(
                    region,
                    execution_region_name,
                    cacheable_regions,
                    non_cacheable_regions,
                ):
                    issues.append(
                        Issue(
                            id=issue_id,
                            severity=IssueSeverity.ERROR,
                            category=IssueCategory.POLICY,
                            title="Cacheable placement policy violated",
                            description=(
                                f"Section {section_name} is in {execution_region_name or 'unmapped region'}, "
                                "but policy requires a cacheable region."
                            ),
                            affected_entities=affected_entities,
                            remediation_hint=(
                                "Move section to cacheable memory or configure policies.cacheable_regions."
                            ),
                        )
                    )
                    existing_ids.add(issue_id)

            if _matches_any(section_name, context.config.policies.retention_section_patterns):
                issue_id = f"memory_policy.retention.{section_name}.{execution_region_name or 'unmapped'}"
                if issue_id not in existing_ids and not _is_retention_region(
                    region,
                    execution_region_name,
                    retention_regions,
                ):
                    issues.append(
                        Issue(
                            id=issue_id,
                            severity=IssueSeverity.ERROR,
                            category=IssueCategory.POLICY,
                            title="Retention placement policy violated",
                            description=(
                                f"Section {section_name} is in {execution_region_name or 'unmapped region'}, "
                                "but policy requires a retention-capable region."
                            ),
                            affected_entities=affected_entities,
                            remediation_hint=(
                                "Move section to retention memory or configure policies.retention_regions."
                            ),
                        )
                    )
                    existing_ids.add(issue_id)

        return RuleEvaluation(rule_id=self.rule_id, issues=issues)


def _matches_any(value: str, patterns: tuple[str, ...]) -> bool:
    lowered_value = value.lower()
    return any(fnmatch(lowered_value, pattern.lower()) for pattern in patterns)


def _lowered_name_set(values: tuple[str, ...]) -> set[str]:
    return {value.lower() for value in values}


def _is_dma_safe_region(
    region: MemoryRegion | None,
    region_name: str | None,
    dma_safe_regions: set[str],
) -> bool:
    lowered_name = (region_name or "").lower()
    if lowered_name and lowered_name in dma_safe_regions:
        return True
    if region is None:
        return False
    attributes = set(region.attributes.values)
    if attributes & {"dma", "dma_safe", "dmasafe"}:
        return True
    return "dma" in region.name.lower()


def _is_non_cacheable_region(
    region: MemoryRegion | None,
    region_name: str | None,
    non_cacheable_regions: set[str],
) -> bool:
    lowered_name = (region_name or "").lower()
    if lowered_name and lowered_name in non_cacheable_regions:
        return True
    if region is None:
        return False
    attributes = set(region.attributes.values)
    if attributes & {"nocache", "noncache", "non_cacheable", "uncached", "nc"}:
        return True
    lowered_region_name = region.name.lower()
    return any(token in lowered_region_name for token in ("nocache", "noncache", "uncached"))


def _is_cacheable_region(
    region: MemoryRegion | None,
    region_name: str | None,
    cacheable_regions: set[str],
    non_cacheable_regions: set[str],
) -> bool:
    lowered_name = (region_name or "").lower()
    if lowered_name and lowered_name in cacheable_regions:
        return True
    if lowered_name and lowered_name in non_cacheable_regions:
        return False
    if region is None:
        return False
    attributes = set(region.attributes.values)
    if attributes & {"cacheable", "cache", "c"}:
        return True
    if attributes & {"nocache", "noncache", "non_cacheable", "uncached", "nc"}:
        return False
    lowered_region_name = region.name.lower()
    if any(token in lowered_region_name for token in ("nocache", "noncache", "uncached")):
        return False
    if "cache" in lowered_region_name:
        return True
    return region.category in {
        MemoryRegionCategory.FLASH,
        MemoryRegionCategory.RAM,
        MemoryRegionCategory.TCM,
        MemoryRegionCategory.EXTERNAL_FLASH,
        MemoryRegionCategory.EXTERNAL_RAM,
    }


def _is_retention_region(
    region: MemoryRegion | None,
    region_name: str | None,
    retention_regions: set[str],
) -> bool:
    lowered_name = (region_name or "").lower()
    if lowered_name and lowered_name in retention_regions:
        return True
    if region is None:
        return False
    if region.category == MemoryRegionCategory.RETENTION:
        return True
    attributes = set(region.attributes.values)
    if attributes & {"retention", "retain", "backup", "standby"}:
        return True
    lowered_region_name = region.name.lower()
    return any(token in lowered_region_name for token in ("retention", "retain", "backup", "standby"))
