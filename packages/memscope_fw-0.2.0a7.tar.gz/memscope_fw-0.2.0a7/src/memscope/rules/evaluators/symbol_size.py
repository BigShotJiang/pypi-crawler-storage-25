"""Symbol-size based policy evaluators."""

from __future__ import annotations

from memscope.domain import Issue, IssueCategory, IssueSeverity
from memscope.rules.base import RuleContext, RuleEvaluation


class MaxBssSymbolSizeRule:
    """Warn when BSS symbols exceed configured size."""

    rule_id = "max_bss_symbol_size"
    description = "Warns on large BSS symbols using configurable kilobyte threshold."

    def evaluate(self, context: RuleContext) -> RuleEvaluation:
        threshold_kb = context.config.policies.warn_on_large_bss_symbol_kb
        if threshold_kb is None:
            return RuleEvaluation(rule_id=self.rule_id, notes=("disabled",))

        threshold_bytes = threshold_kb * 1024
        existing_ids = {issue.id for issue in context.report.issues}
        issues: list[Issue] = []

        for symbol in sorted(context.model.symbols, key=lambda item: (item.name, -item.size)):
            section_name = (symbol.section_name or "").lower()
            if ".bss" not in section_name:
                continue
            if symbol.size < threshold_bytes:
                continue

            issue_id = f"large_bss_symbol.{_token(symbol.name)}"
            if issue_id in existing_ids:
                continue

            issues.append(
                Issue(
                    id=issue_id,
                    severity=IssueSeverity.WARNING,
                    category=IssueCategory.POLICY,
                    title="BSS symbol exceeds configured threshold",
                    description=(
                        f"Symbol {symbol.name} uses {symbol.size} bytes in BSS, "
                        f"above threshold {threshold_bytes} bytes."
                    ),
                    affected_entities=tuple(
                        value
                        for value in (
                            symbol.name,
                            symbol.section_name,
                            symbol.object_file,
                        )
                        if value
                    ),
                    remediation_hint="Move large buffers to dynamic allocation or reduce static footprint.",
                )
            )

        return RuleEvaluation(rule_id=self.rule_id, issues=issues)


def _token(value: str) -> str:
    return "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in value)
