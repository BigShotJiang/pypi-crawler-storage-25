"""Component placement restriction evaluator."""

from __future__ import annotations

from memscope.domain import Issue, IssueCategory, IssueSeverity
from memscope.rules.base import RuleContext, RuleEvaluation


class ForbiddenComponentPlacementRule:
    """Enforce component-to-region placement restrictions from policy config."""

    rule_id = "forbidden_component_placement"
    description = "Flags symbols belonging to restricted components in forbidden regions."

    def evaluate(self, context: RuleContext) -> RuleEvaluation:
        restricted_regions = {
            component_name: set(regions)
            for component_name, regions in context.config.policies.forbidden_component_regions.items()
        }
        if not restricted_regions:
            return RuleEvaluation(rule_id=self.rule_id)

        symbol_to_component: dict[str, str] = {}
        for component_group in context.report.components:
            for symbol_name in component_group.symbols:
                symbol_to_component[symbol_name] = component_group.name

        region_by_section = {
            section.name: section.execution_region for section in context.model.sections if section.execution_region
        }

        buckets: dict[tuple[str, str], list[str]] = {}
        for symbol in context.model.symbols:
            component_name = symbol_to_component.get(symbol.name)
            if component_name is None:
                continue
            forbidden = restricted_regions.get(component_name)
            if not forbidden:
                continue
            region = region_by_section.get(symbol.section_name or "")
            if region is None or region not in forbidden:
                continue
            key = (component_name, region)
            buckets.setdefault(key, []).append(symbol.name)

        existing_ids = {issue.id for issue in context.report.issues}
        issues: list[Issue] = []
        for (component_name, region), symbols in sorted(buckets.items()):
            issue_id = f"forbidden_component_placement.{_token(component_name)}.{_token(region)}"
            if issue_id in existing_ids:
                continue

            unique_symbols = sorted(set(symbols))
            sample = unique_symbols[:5]
            sample_suffix = "" if len(unique_symbols) <= len(sample) else ", ..."
            issues.append(
                Issue(
                    id=issue_id,
                    severity=IssueSeverity.ERROR,
                    category=IssueCategory.POLICY,
                    title="Component placed in forbidden region",
                    description=(
                        f"Component {component_name} has symbols mapped to forbidden region {region}. "
                        f"Examples: {', '.join(sample)}{sample_suffix}"
                    ),
                    affected_entities=tuple([component_name, region, *sample]),
                    remediation_hint="Update section placement rules or policy restrictions intentionally.",
                )
            )

        return RuleEvaluation(rule_id=self.rule_id, issues=issues)


def _token(value: str) -> str:
    return "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in value)
