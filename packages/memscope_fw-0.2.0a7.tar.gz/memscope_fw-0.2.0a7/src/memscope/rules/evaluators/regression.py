"""Regression policy rule hooks."""

from __future__ import annotations

from memscope.domain import Issue, IssueCategory, IssueSeverity
from memscope.rules.base import RuleContext, RuleEvaluation


class RamGrowthRegressionRule:
    """Hook for RAM regression gating when a baseline is present."""

    rule_id = "ram_growth_regression"
    description = "Checks RAM delta against optional policy threshold."

    def evaluate(self, context: RuleContext) -> RuleEvaluation:
        delta = _regression_delta(context, "ram_delta_bytes")
        if delta <= 0:
            return RuleEvaluation(rule_id=self.rule_id)

        threshold = context.config.policies.max_ram_growth_bytes
        severity = IssueSeverity.WARNING
        remediation = "Review top RAM contributors and trim growth."
        title = "RAM growth regression detected"
        if threshold is not None and delta > threshold:
            severity = IssueSeverity.ERROR
            remediation = "RAM growth exceeded configured threshold. Block and investigate before merge."
            title = "RAM growth exceeds configured threshold"

        return RuleEvaluation(
            rule_id=self.rule_id,
            issues=[
                Issue(
                    id="regression.ram_growth",
                    severity=severity,
                    category=IssueCategory.REGRESSION,
                    title=title,
                    description=_growth_description(
                        delta=delta,
                        threshold=threshold,
                        metric_name="RAM",
                    ),
                    remediation_hint=remediation,
                )
            ],
        )


class FlashGrowthRegressionRule:
    """Hook for FLASH regression gating when a baseline is present."""

    rule_id = "flash_growth_regression"
    description = "Checks FLASH delta against optional policy threshold."

    def evaluate(self, context: RuleContext) -> RuleEvaluation:
        delta = _regression_delta(context, "flash_delta_bytes")
        if delta <= 0:
            return RuleEvaluation(rule_id=self.rule_id)

        threshold = context.config.policies.max_flash_growth_bytes
        severity = IssueSeverity.WARNING
        remediation = "Review top FLASH contributors and trim growth."
        title = "FLASH growth regression detected"
        if threshold is not None and delta > threshold:
            severity = IssueSeverity.ERROR
            remediation = "FLASH growth exceeded configured threshold. Block and investigate before merge."
            title = "FLASH growth exceeds configured threshold"

        return RuleEvaluation(
            rule_id=self.rule_id,
            issues=[
                Issue(
                    id="regression.flash_growth",
                    severity=severity,
                    category=IssueCategory.REGRESSION,
                    title=title,
                    description=_growth_description(
                        delta=delta,
                        threshold=threshold,
                        metric_name="FLASH",
                    ),
                    remediation_hint=remediation,
                )
            ],
        )


def _regression_delta(context: RuleContext, key: str) -> int:
    regressions = context.report.regressions
    if regressions.get("status") != "ok":
        return 0
    value = regressions.get(key)
    if isinstance(value, bool):
        return 0
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    return 0


def _growth_description(delta: int, threshold: int | None, metric_name: str) -> str:
    if threshold is None:
        return f"{metric_name} grew by {delta} bytes versus the baseline."
    return (
        f"{metric_name} grew by {delta} bytes versus the baseline, "
        f"above configured threshold {threshold} bytes."
    )

