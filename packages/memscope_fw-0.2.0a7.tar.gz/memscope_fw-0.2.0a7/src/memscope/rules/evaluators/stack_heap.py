"""Stack/heap policy evaluator."""

from __future__ import annotations

from memscope.domain import Issue, IssueCategory, IssueSeverity
from memscope.rules.base import RuleContext, RuleEvaluation


class MissingStackHeapDefinitionRule:
    """Warn when stack and heap markers cannot be inferred."""

    rule_id = "missing_stack_heap_definition"
    description = "Checks stack/heap hint presence from normalized model."

    def evaluate(self, context: RuleContext) -> RuleEvaluation:
        hints = context.model.stack_heap_hints
        existing_ids = {issue.id for issue in context.report.issues}
        issues: list[Issue] = []

        stack_sections = tuple(hints.get("stack_sections", ()))
        stack_symbols = tuple(hints.get("stack_symbols", ()))
        if not stack_sections and not stack_symbols and "missing_stack_definition" not in existing_ids:
            issues.append(
                Issue(
                    id="missing_stack_definition",
                    severity=IssueSeverity.WARNING,
                    category=IssueCategory.POLICY,
                    title="Missing explicit stack definition",
                    description="No stack section or stack marker symbol was detected.",
                    remediation_hint="Define stack section/symbol explicitly in linker script for clearer analysis.",
                )
            )

        heap_sections = tuple(hints.get("heap_sections", ()))
        heap_symbols = tuple(hints.get("heap_symbols", ()))
        if not heap_sections and not heap_symbols and "missing_heap_definition" not in existing_ids:
            issues.append(
                Issue(
                    id="missing_heap_definition",
                    severity=IssueSeverity.WARNING,
                    category=IssueCategory.POLICY,
                    title="Missing explicit heap definition",
                    description="No heap section or heap marker symbol was detected.",
                    remediation_hint="Define heap section/symbol explicitly or disable dynamic allocation.",
                )
            )

        return RuleEvaluation(rule_id=self.rule_id, issues=issues)

