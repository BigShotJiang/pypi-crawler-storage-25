"""Budget and near-capacity rule evaluator."""

from __future__ import annotations

from memscope.domain import Issue, IssueCategory, IssueSeverity
from memscope.rules.base import RuleContext, RuleEvaluation


class BudgetThresholdRule:
    """Evaluate overflow, configured budgets, and near-capacity thresholds."""

    rule_id = "budget_thresholds"
    description = "Checks region overflow and capacity thresholds."

    def evaluate(self, context: RuleContext) -> RuleEvaluation:
        issues: list[Issue] = []
        existing_ids = {issue.id for issue in context.report.issues}
        utilization = context.report.summary.utilization_by_region
        near_capacity_ratio = context.config.policies.warn_on_near_capacity_ratio

        configured_budgets: dict[str, float] = {}
        configured_budgets.update(context.config.budgets.flash)
        configured_budgets.update(context.config.budgets.ram)

        for region_name, ratio in sorted(utilization.items()):
            overflow_issue_id = f"overflow.{region_name}"
            if ratio > 1.0 and overflow_issue_id not in existing_ids:
                issues.append(
                    Issue(
                        id=overflow_issue_id,
                        severity=IssueSeverity.ERROR,
                        category=IssueCategory.OVERFLOW,
                        title="Region overflow detected",
                        description=(
                            f"Region {region_name} utilization ratio is {ratio:.3f}, above 1.000."
                        ),
                        affected_entities=(region_name,),
                        remediation_hint="Reduce section usage or increase region capacity.",
                    )
                )

            budget_ratio = configured_budgets.get(region_name)
            budget_issue_id = f"budget.{region_name}"
            if budget_ratio is not None and ratio > budget_ratio and budget_issue_id not in existing_ids:
                issues.append(
                    Issue(
                        id=budget_issue_id,
                        severity=IssueSeverity.WARNING,
                        category=IssueCategory.POLICY,
                        title="Region budget threshold exceeded",
                        description=(
                            f"Region {region_name} utilization is {ratio:.3f}, "
                            f"above configured budget {budget_ratio:.3f}."
                        ),
                        affected_entities=(region_name,),
                        remediation_hint="Rebalance footprint or intentionally adjust the budget.",
                    )
                )

            if (
                near_capacity_ratio is not None
                and ratio <= 1.0
                and ratio >= near_capacity_ratio
                and f"near_capacity.{region_name}" not in existing_ids
                and budget_issue_id not in existing_ids
            ):
                issues.append(
                    Issue(
                        id=f"near_capacity.{region_name}",
                        severity=IssueSeverity.WARNING,
                        category=IssueCategory.POLICY,
                        title="Region near capacity",
                        description=(
                            f"Region {region_name} utilization is {ratio:.3f}, "
                            f"near configured threshold {near_capacity_ratio:.3f}."
                        ),
                        affected_entities=(region_name,),
                        remediation_hint="Monitor growth or tighten optimization for this region.",
                    )
                )

        # Warn about [budgets] keys that don't match any actual firmware
        # region. Without this check, a typo in `memscope.toml` (or a
        # stale region name left over after a linker-script rename) would
        # silently disable the budget — the customer would think they
        # have CI coverage they don't actually have.
        #
        # Severity: WARNING. We don't fail outright because some teams
        # legitimately share one `memscope.toml` across multiple build
        # variants (single-core / multicore / debug / release) where not
        # every region exists in every build. The warning still shows up
        # in `analyze` output + JSON + HTML so CI logs surface the typo.
        actual_region_names = set(utilization.keys())
        for budget_region_name in sorted(configured_budgets):
            if budget_region_name in actual_region_names:
                continue
            unknown_id = f"unknown_budget_region.{budget_region_name}"
            if unknown_id in existing_ids:
                continue
            issues.append(
                Issue(
                    id=unknown_id,
                    severity=IssueSeverity.WARNING,
                    category=IssueCategory.POLICY,
                    title="Configured budget references unknown region",
                    description=(
                        f"`memscope.toml` configures a budget for region "
                        f"`{budget_region_name}`, but no region by that name "
                        f"was found in the firmware. The budget is silently "
                        f"ignored. Likely causes: a typo in the budget key, "
                        f"a region renamed in the linker file without "
                        f"updating `memscope.toml`, or a region that only "
                        f"exists in a different build variant."
                    ),
                    affected_entities=(budget_region_name,),
                    remediation_hint=(
                        "Run `memscope analyze` and check the report's Memory "
                        "Layout section for the exact region name; update "
                        "`memscope.toml` `[budgets]` keys to match. Suppress "
                        f"with `id={unknown_id}` if the mismatch is intentional "
                        "(e.g. shared config across build variants)."
                    ),
                )
            )

        return RuleEvaluation(rule_id=self.rule_id, issues=issues)

