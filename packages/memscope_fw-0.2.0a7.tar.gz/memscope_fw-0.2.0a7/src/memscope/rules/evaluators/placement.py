"""Placement-oriented policy evaluators."""

from __future__ import annotations

from memscope.analysis.reserved_region_checks import (
    detect_reserved_region_violations,
    detect_suspicious_section_placement,
)
from memscope.rules.base import RuleContext, RuleEvaluation


class ReservedRegionViolationRule:
    """Checks for sections mapped into reserved regions."""

    rule_id = "reserved_region_violation"
    description = "Detects placements in reserved memory regions."

    def evaluate(self, context: RuleContext) -> RuleEvaluation:
        existing_ids = {issue.id for issue in context.report.issues}
        issues = [
            issue
            for issue in detect_reserved_region_violations(context.model)
            if issue.id not in existing_ids
        ]
        return RuleEvaluation(rule_id=self.rule_id, issues=issues)


class UnexpectedSectionLocationRule:
    """Checks for suspicious or unresolved section placements."""

    rule_id = "unexpected_section_location"
    description = "Detects suspicious section locations and unmapped regions."

    def evaluate(self, context: RuleContext) -> RuleEvaluation:
        existing_ids = {issue.id for issue in context.report.issues}
        issues = [
            issue
            for issue in detect_suspicious_section_placement(context.model)
            if issue.id not in existing_ids
        ]
        return RuleEvaluation(rule_id=self.rule_id, issues=issues)

