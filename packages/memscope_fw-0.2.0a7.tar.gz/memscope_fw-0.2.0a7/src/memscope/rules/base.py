"""Rule contracts and shared evaluation context."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol

from memscope.config import MemscopeConfig
from memscope.domain import AnalysisReport, Issue
from memscope.toolchains.base import NormalizedBuildModel


@dataclass(slots=True)
class RuleContext:
    """Inputs provided to every rule evaluator."""

    model: NormalizedBuildModel
    report: AnalysisReport
    config: MemscopeConfig


@dataclass(slots=True)
class RuleEvaluation:
    """Structured output returned by one rule execution."""

    rule_id: str
    issues: list[Issue] = field(default_factory=list)
    notes: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        self.notes = tuple(sorted({note.strip() for note in self.notes if note.strip()}))


class Rule(Protocol):
    """Protocol implemented by all rule evaluators."""

    rule_id: str
    description: str

    def evaluate(self, context: RuleContext) -> RuleEvaluation:
        ...

