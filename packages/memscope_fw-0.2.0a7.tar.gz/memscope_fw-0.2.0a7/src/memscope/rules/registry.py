"""Rule registry and default rule wiring."""

from __future__ import annotations

from dataclasses import dataclass

from memscope.rules.base import Rule, RuleContext, RuleEvaluation
from memscope.rules.evaluators import (
    AdvancedMemoryPolicyRule,
    BudgetThresholdRule,
    FlashGrowthRegressionRule,
    ForbiddenComponentPlacementRule,
    MaxBssSymbolSizeRule,
    MissingStackHeapDefinitionRule,
    OtaPartitionFitRule,
    RamGrowthRegressionRule,
    ReservedRegionViolationRule,
    UnexpectedSectionLocationRule,
)


def default_rule_registry() -> RuleRegistry:
    return RuleRegistry(
        rules=(
            BudgetThresholdRule(),
            ReservedRegionViolationRule(),
            UnexpectedSectionLocationRule(),
            MaxBssSymbolSizeRule(),
            RamGrowthRegressionRule(),
            FlashGrowthRegressionRule(),
            ForbiddenComponentPlacementRule(),
            MissingStackHeapDefinitionRule(),
            OtaPartitionFitRule(),
            AdvancedMemoryPolicyRule(),
        )
    )


@dataclass(slots=True)
class RuleRegistry:
    """Container for active policy rules."""

    rules: tuple[Rule, ...]

    def evaluate_all(self, context: RuleContext) -> tuple[RuleEvaluation, ...]:
        return tuple(rule.evaluate(context) for rule in self.rules)
