"""Suppression and waiver application for rule issues."""

from __future__ import annotations

from dataclasses import dataclass, field

from memscope.config import MemscopeConfig
from memscope.domain import Issue, IssueCategory


@dataclass(slots=True, frozen=True)
class SuppressedIssue:
    """Audit record for one suppressed issue."""

    issue: Issue
    reason: str


@dataclass(slots=True)
class SuppressionResult:
    """Partition of active vs suppressed issues."""

    active_issues: list[Issue] = field(default_factory=list)
    suppressed_issues: list[SuppressedIssue] = field(default_factory=list)


@dataclass(slots=True, frozen=True)
class SuppressionSet:
    """Configured suppression/waiver selectors."""

    issue_ids: frozenset[str] = frozenset()
    issue_prefixes: tuple[str, ...] = ()
    categories: frozenset[IssueCategory] = frozenset()

    @classmethod
    def from_config(cls, config: MemscopeConfig) -> SuppressionSet:
        category_values = {
            IssueCategory(value)
            for value in config.policies.suppress_categories
            if value in {category.value for category in IssueCategory}
        }
        return cls(
            issue_ids=frozenset(config.policies.suppress_issue_ids),
            issue_prefixes=tuple(config.policies.suppress_issue_prefixes),
            categories=frozenset(category_values),
        )

    def match_reason(self, issue: Issue) -> str | None:
        if issue.id in self.issue_ids:
            return f"issue_id:{issue.id}"
        for prefix in self.issue_prefixes:
            if issue.id.startswith(prefix):
                return f"issue_prefix:{prefix}"
        if issue.category in self.categories:
            return f"category:{issue.category.value}"
        return None


def apply_suppressions(issues: list[Issue], suppressions: SuppressionSet) -> SuppressionResult:
    """Apply suppressions and produce auditable output."""
    active_issues: list[Issue] = []
    suppressed_issues: list[SuppressedIssue] = []

    for issue in issues:
        reason = suppressions.match_reason(issue)
        if reason is None:
            active_issues.append(issue)
            continue
        suppressed_issues.append(SuppressedIssue(issue=issue, reason=reason))

    return SuppressionResult(
        active_issues=active_issues,
        suppressed_issues=suppressed_issues,
    )

