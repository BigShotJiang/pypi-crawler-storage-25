"""Symbol, object/archive, and memory attribution analyses."""

from __future__ import annotations

import re
from dataclasses import dataclass

from memscope.domain import MemoryRegionCategory, SectionPlacement, SymbolEntry
from memscope.toolchains.base import NormalizedBuildModel

_INITIALIZED_RAM_DATA_HINT_TOKENS = frozenset(
    {
        "data",
        "sdata",
        "tdata",
        "ramfunc",
        "ramcode",
    }
)
_UNINITIALIZED_SECTION_HINT_TOKENS = frozenset(
    {
        "bss",
        "sbss",
        "tbss",
        "noinit",
        "noload",
        "stack",
        "heap",
        "common",
        "zeroinit",
    }
)
_RAM_REGION_HINT_TOKENS = frozenset(
    {
        "ram",
        "sram",
        "tcm",
        "dtcm",
        "itcm",
        "xram",
        "dmem",
        "retention",
    }
)


@dataclass(slots=True)
class ItemSize:
    name: str
    size: int


@dataclass(slots=True)
class FlashRamAttribution:
    flash_bytes: int
    ram_bytes: int
    other_bytes: int


@dataclass(slots=True)
class InitializedRamCost:
    initialized_ram_bytes: int
    estimated_flash_init_payload_bytes: int


def top_symbols_by_size(symbols: list[SymbolEntry], *, limit: int = 25) -> list[ItemSize]:
    ranked = sorted(symbols, key=lambda symbol: (symbol.size, symbol.name), reverse=True)
    return [ItemSize(name=symbol.name, size=symbol.size) for symbol in ranked[:limit]]


def top_object_archive_contributors(
    symbols: list[SymbolEntry],
    *,
    limit: int = 25,
) -> list[ItemSize]:
    buckets: dict[str, int] = {}
    for symbol in symbols:
        bucket_name = symbol.archive or symbol.object_file or "unknown_object"
        buckets[bucket_name] = buckets.get(bucket_name, 0) + symbol.size
    ranked = sorted(buckets.items(), key=lambda item: (item[1], item[0]), reverse=True)
    return [ItemSize(name=name, size=size) for name, size in ranked[:limit]]


def compute_flash_ram_attribution(model: NormalizedBuildModel) -> FlashRamAttribution:
    category_by_region = {region.name: region.category for region in model.memory_regions}
    flash = 0
    ram = 0
    other = 0

    for section in model.sections:
        category = category_by_region.get(section.execution_region or "")
        if category in (MemoryRegionCategory.FLASH, MemoryRegionCategory.EXTERNAL_FLASH):
            flash += section.size
        elif category in (
            MemoryRegionCategory.RAM,
            MemoryRegionCategory.TCM,
            MemoryRegionCategory.RETENTION,
            MemoryRegionCategory.EXTERNAL_RAM,
        ):
            ram += section.size
        else:
            other += section.size

    return FlashRamAttribution(flash_bytes=flash, ram_bytes=ram, other_bytes=other)


def compute_initialized_ram_cost(model: NormalizedBuildModel) -> InitializedRamCost:
    initialized_ram = 0
    for section in model.sections:
        if _is_initialized_ram_section(section):
            initialized_ram += section.size
    return InitializedRamCost(
        initialized_ram_bytes=initialized_ram,
        estimated_flash_init_payload_bytes=initialized_ram,
    )


def _is_initialized_ram_section(section: SectionPlacement) -> bool:
    if section.size <= 0:
        return False

    lowered = section.name.lower()
    section_tokens = _identifier_tokens(lowered)
    if section_tokens & _UNINITIALIZED_SECTION_HINT_TOKENS:
        return False

    if "init_array" in lowered or "fini_array" in lowered:
        return True

    if section.load_region is not None and section.execution_region is not None:
        if section.load_region != section.execution_region and section.size > 0:
            return True

    if not section_tokens:
        return False
    if not (section_tokens & _INITIALIZED_RAM_DATA_HINT_TOKENS):
        return False

    execution_region_tokens = _identifier_tokens((section.execution_region or "").lower())
    if execution_region_tokens:
        return bool(execution_region_tokens & _RAM_REGION_HINT_TOKENS)

    # Fallback for section-only parsing where regions are not available.
    return "rodata" not in section_tokens


def _identifier_tokens(value: str) -> set[str]:
    return {token for token in re.split(r"[^a-z0-9]+", value.lower()) if token}
