"""Padding/alignment waste analysis."""

from __future__ import annotations

from dataclasses import dataclass

from memscope.domain import SectionPlacement
from memscope.toolchains.base import NormalizedBuildModel


@dataclass(slots=True)
class PaddingWasteResult:
    total_padding_bytes: int
    by_region: dict[str, int]


def compute_padding_waste(model: NormalizedBuildModel) -> PaddingWasteResult:
    region_bounds: dict[str, tuple[int, int]] = {}
    for region in model.memory_regions:
        region_bounds[region.name] = (region.start_address, region.end_address)

    grouped: dict[str, list[SectionPlacement]] = {}
    for section in model.sections:
        region_name = section.execution_region or "unmapped"
        grouped.setdefault(region_name, []).append(section)

    by_region: dict[str, int] = {}
    for region_name, sections in grouped.items():
        inline_padding = sum(
            max(0, section.padding_before) + max(0, section.padding_after)
            for section in sections
        )

        bounds = region_bounds.get(region_name)
        gap_waste = 0
        if bounds is not None:
            start, end = bounds
            region_size = max(0, end - start + 1)
            in_range = [
                section for section in sections
                if section.vma > 0 and start <= section.vma <= end and section.size > 0
            ]
            sorted_sections = sorted(in_range, key=lambda item: item.vma)
            for previous, current in zip(sorted_sections, sorted_sections[1:], strict=False):
                previous_end = previous.vma + max(previous.size, 0)
                gap = current.vma - previous_end
                if 0 < gap <= region_size:
                    gap_waste += gap

        by_region[region_name] = inline_padding + gap_waste

    total = sum(by_region.values())
    return PaddingWasteResult(total_padding_bytes=total, by_region=by_region)

