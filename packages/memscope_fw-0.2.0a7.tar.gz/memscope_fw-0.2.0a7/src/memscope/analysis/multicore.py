"""Multicore-awareness analysis helpers.

Authoritative multicore detection is driven exclusively by memory-region
partitioning. A build is only reported as multicore when the toolchain layer
has already assigned two or more distinct core identifiers to memory regions
(populated into ``NormalizedBuildModel.core_assignments`` by the region-name
inference step). Section names, symbol names, and object-file names are NOT
used to declare cores because those naming conventions are commonly present
in single-core builds (per-core scaffolding object files, framework stubs,
startup code variants) and cause false-positive "multicore" reports on
projects that actually share one memory map.

When region-level partitioning is present, per-core section and symbol
attribution still consults ``core_inference.infer_core_from_text`` as a
secondary signal to associate items that land in per-core regions.
"""

from __future__ import annotations

from memscope.domain.enums import MemoryRegionCategory
from memscope.toolchains.base import NormalizedBuildModel
from memscope.toolchains.core_inference import infer_core_from_text


def build_multicore_summary(model: NormalizedBuildModel) -> dict[str, object] | None:
    """Return multicore summary data when memory regions partition by core.

    Returns ``None`` for builds whose memory regions do not partition into
    two or more distinct cores, regardless of any per-core symbol or
    section naming conventions present in the image.
    """
    region_to_core = dict(sorted(model.core_assignments.items()))
    inferred_cores = set(region_to_core.values())
    if len(inferred_cores) < 2:
        return None

    region_categories = {region.name: region.category for region in model.memory_regions}

    section_to_core: dict[str, str] = {}
    section_counts_by_core: dict[str, int] = {}
    section_bytes_by_core: dict[str, int] = {}
    flash_bytes_by_core: dict[str, int] = {}
    ram_bytes_by_core: dict[str, int] = {}
    unassigned_sections = 0
    sources: set[str] = {"region-name"}

    for section in model.sections:
        core_id = _section_core_id(section.name, section.execution_region, section.load_region, region_to_core)
        if core_id is None or core_id not in inferred_cores:
            unassigned_sections += 1
            continue

        section_to_core.setdefault(section.name, core_id)
        section_counts_by_core[core_id] = section_counts_by_core.get(core_id, 0) + 1
        section_bytes_by_core[core_id] = section_bytes_by_core.get(core_id, 0) + max(section.size, 0)

        category = region_categories.get(section.execution_region or "")
        if category in {MemoryRegionCategory.FLASH, MemoryRegionCategory.EXTERNAL_FLASH}:
            flash_bytes_by_core[core_id] = flash_bytes_by_core.get(core_id, 0) + max(section.size, 0)
        elif category in {
            MemoryRegionCategory.RAM,
            MemoryRegionCategory.TCM,
            MemoryRegionCategory.RETENTION,
            MemoryRegionCategory.EXTERNAL_RAM,
        }:
            ram_bytes_by_core[core_id] = ram_bytes_by_core.get(core_id, 0) + max(section.size, 0)

        if section.execution_region in region_to_core:
            sources.add("execution-region")
        elif section.load_region in region_to_core:
            sources.add("load-region")
        else:
            sources.add("section-name")

    symbol_counts_by_core: dict[str, int] = {}
    symbol_bytes_by_core: dict[str, int] = {}
    unassigned_symbols = 0
    for symbol in model.symbols:
        core_id = _symbol_core_id(symbol.section_name, symbol.object_file, symbol.name, section_to_core)
        if core_id is None or core_id not in inferred_cores:
            unassigned_symbols += 1
            continue
        symbol_counts_by_core[core_id] = symbol_counts_by_core.get(core_id, 0) + 1
        symbol_bytes_by_core[core_id] = symbol_bytes_by_core.get(core_id, 0) + max(symbol.size, 0)

    if symbol_counts_by_core:
        sources.add("symbol-owner")

    return {
        "cores": sorted(inferred_cores),
        "region_to_core": region_to_core,
        "section_counts_by_core": _sorted_int_map(section_counts_by_core),
        "section_bytes_by_core": _sorted_int_map(section_bytes_by_core),
        "flash_bytes_by_core": _sorted_int_map(flash_bytes_by_core),
        "ram_bytes_by_core": _sorted_int_map(ram_bytes_by_core),
        "symbol_counts_by_core": _sorted_int_map(symbol_counts_by_core),
        "symbol_bytes_by_core": _sorted_int_map(symbol_bytes_by_core),
        "unassigned_sections": unassigned_sections,
        "unassigned_symbols": unassigned_symbols,
        "inference_sources": sorted(sources),
    }


def _section_core_id(
    section_name: str,
    execution_region: str | None,
    load_region: str | None,
    region_to_core: dict[str, str],
) -> str | None:
    if execution_region and execution_region in region_to_core:
        return region_to_core[execution_region]
    if load_region and load_region in region_to_core:
        return region_to_core[load_region]
    return infer_core_from_text(section_name)


def _symbol_core_id(
    section_name: str | None,
    object_file: str | None,
    symbol_name: str,
    section_to_core: dict[str, str],
) -> str | None:
    if section_name and section_name in section_to_core:
        return section_to_core[section_name]
    return infer_core_from_text(object_file) or infer_core_from_text(symbol_name)


def _sorted_int_map(values: dict[str, int]) -> dict[str, int]:
    return dict(sorted(values.items()))
