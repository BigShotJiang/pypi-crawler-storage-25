"""Analysis report assembly and high-level v1 analyses."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path

from memscope import __version__
from memscope.analysis.component_grouping import group_symbols_by_component
from memscope.analysis.multicore import build_multicore_summary
from memscope.analysis.padding_waste import compute_padding_waste
from memscope.analysis.region_usage import RegionUsageResult, compute_region_usage
from memscope.analysis.reserved_region_checks import (
    detect_reserved_region_violations,
    detect_suspicious_section_placement,
)
from memscope.analysis.section_usage import compute_section_usage
from memscope.analysis.symbol_breakdown import (
    compute_flash_ram_attribution,
    compute_initialized_ram_cost,
    top_object_archive_contributors,
    top_symbols_by_size,
)
from memscope.analysis.visualization_contracts import build_visualization_contract
from memscope.config import MemscopeConfig
from memscope.domain import (
    AnalysisReport,
    Issue,
    IssueCategory,
    IssueSeverity,
    ReportMetadata,
    ReportSummary,
)
from memscope.domain.schema import SCHEMA_VERSION
from memscope.toolchains.base import NormalizedBuildModel


def build_analysis_report(
    model: NormalizedBuildModel,
    config: MemscopeConfig,
    *,
    target_name: str | None = None,
    baseline_json_path: Path | None = None,
) -> AnalysisReport:
    region_usage = compute_region_usage(model)
    section_usage = compute_section_usage(model, region_usage)
    top_symbols = top_symbols_by_size(model.symbols, limit=25)
    top_objects = top_object_archive_contributors(model.symbols, limit=25)
    flash_ram = compute_flash_ram_attribution(model)
    initialized_ram = compute_initialized_ram_cost(model)
    padding_waste = compute_padding_waste(model)
    multicore_summary = build_multicore_summary(model)
    region_category_by_name = {
        region.name: region.category.value
        for region in model.memory_regions
    }
    section_category_by_name: dict[str, str] = {}
    for section in model.sections:
        section_name = section.name.strip()
        if not section_name:
            continue
        region_name = (section.execution_region or "").strip()
        category = region_category_by_name.get(region_name)
        if category and section_name not in section_category_by_name:
            section_category_by_name[section_name] = category

    components = group_symbols_by_component(
        model.symbols,
        config,
        section_category_by_name=section_category_by_name,
    )

    issues: list[Issue] = []
    issues.extend(_overflow_issues(region_usage))
    issues.extend(detect_reserved_region_violations(model))
    issues.extend(detect_suspicious_section_placement(model))
    issues.extend(_budget_threshold_issues(region_usage, config))

    summary = ReportSummary(
        total_flash=flash_ram.flash_bytes,
        total_ram=flash_ram.ram_bytes,
        utilization_by_region={
            name: result.utilization_ratio for name, result in sorted(region_usage.items())
        },
        issue_counts={
            "info": sum(1 for issue in issues if issue.severity == IssueSeverity.INFO),
            "warning": sum(1 for issue in issues if issue.severity == IssueSeverity.WARNING),
            "error": sum(1 for issue in issues if issue.severity == IssueSeverity.ERROR),
        },
        extra={
            "flash_ram_attribution": {
                "flash_bytes": flash_ram.flash_bytes,
                "ram_bytes": flash_ram.ram_bytes,
                "other_bytes": flash_ram.other_bytes,
            },
            "initialized_ram_cost": {
                "initialized_ram_bytes": initialized_ram.initialized_ram_bytes,
                "estimated_flash_init_payload_bytes": initialized_ram.estimated_flash_init_payload_bytes,
            },
            "padding_waste": {
                "total_padding_bytes": padding_waste.total_padding_bytes,
                "by_region": dict(sorted(padding_waste.by_region.items())),
            },
            **({"multicore": multicore_summary} if multicore_summary is not None else {}),
        },
    )
    baseline_regressions = _baseline_regressions(summary, baseline_json_path)
    visualization_payload = build_visualization_contract(
        model,
        region_usage=region_usage,
        padding_waste=padding_waste,
        components=components,
        issues=issues,
        regressions=baseline_regressions,
        features={
            "sankey_enabled": config.reports.enable_sankey_view,
            "relationship_graph_enabled": config.reports.enable_relationship_graph_view,
        },
    )

    report = AnalysisReport(
        metadata=ReportMetadata(
            tool_version=__version__,
            schema_version=SCHEMA_VERSION,
            analysis_timestamp=datetime.now(UTC).isoformat(),
            target_name=target_name or config.project.name,
            toolchain_detected=model.toolchain.value,
            parse_assumptions=model.parse_assumptions,
        ),
        summary=summary,
        regions=list(model.memory_regions),
        sections=list(model.sections),
        symbols=list(model.symbols),
        components=components,
        issues=issues,
        trends={
            "top_symbols_by_size": [{"name": item.name, "size": item.size} for item in top_symbols],
            "top_objects_by_size": [{"name": item.name, "size": item.size} for item in top_objects],
            "section_usage": [
                {
                    "name": item.section_name,
                    "execution_region": item.execution_region,
                    "load_region": item.load_region,
                    "size": item.size,
                    "utilization_ratio_in_region": item.utilization_ratio_in_region,
                }
                for item in section_usage
            ],
            "visualization": visualization_payload,
        },
        regressions=baseline_regressions,
        diagnostics={
            "parse_assumptions": list(model.parse_assumptions),
            "unresolved_ambiguities": list(model.unresolved_ambiguities),
            "stack_heap_hints": {key: list(values) for key, values in model.stack_heap_hints.items()},
            "visualization_contract": {
                "schema_version": str(visualization_payload.get("schema_version", "")),
                "regions_count": len(visualization_payload.get("regions", []))
                if isinstance(visualization_payload.get("regions"), list)
                else 0,
            },
            "config_summary": _build_config_summary(config),
            **({"multicore": multicore_summary} if multicore_summary is not None else {}),
        },
    )

    return report.sorted_copy()


def _overflow_issues(region_usage: dict[str, RegionUsageResult]) -> list[Issue]:
    issues: list[Issue] = []
    for region_name, result in sorted(region_usage.items()):
        overflow = result.overflow_bytes
        if overflow > 0:
            issues.append(
                Issue(
                    id=f"overflow.{region_name}",
                    severity=IssueSeverity.ERROR,
                    category=IssueCategory.OVERFLOW,
                    title="Region overflow detected",
                    description=f"Region {region_name} exceeds capacity by {overflow} bytes.",
                    affected_entities=(region_name,),
                    remediation_hint="Reduce section usage or increase region capacity in linker config.",
                )
            )
    return issues


def _build_config_summary(config: MemscopeConfig) -> dict[str, object]:
    """Snapshot of TOML rules the HTML renderer can show on region cards.

    Why: the renderer takes only `report`, not `config`, so we stash the few
    threshold values it needs (region budgets, partition caps, near-capacity
    ratio) under `diagnostics.config_summary`. Keep this minimal — it is a
    presentation hint, not a serialization contract.
    """
    return {
        "budgets": {
            "flash": dict(config.budgets.flash),
            "ram": dict(config.budgets.ram),
        },
        "policies": {
            "warn_on_near_capacity_ratio": config.policies.warn_on_near_capacity_ratio,
            "partition_max_bytes": dict(config.policies.partition_max_bytes),
            "fail_on_overflow": config.policies.fail_on_overflow,
            "fail_on_reserved_region_violation": config.policies.fail_on_reserved_region_violation,
        },
    }


def _budget_threshold_issues(region_usage: dict[str, RegionUsageResult], config: MemscopeConfig) -> list[Issue]:
    issues: list[Issue] = []
    for budget_map in (config.budgets.flash, config.budgets.ram):
        for region_name, budget_ratio in sorted(budget_map.items()):
            usage = region_usage.get(region_name)
            if usage is None:
                continue
            utilization_ratio = usage.utilization_ratio
            if utilization_ratio > budget_ratio:
                issues.append(
                    Issue(
                        id=f"budget.{region_name}",
                        severity=IssueSeverity.WARNING,
                        category=IssueCategory.POLICY,
                        title="Region budget threshold exceeded",
                        description=(
                            f"Region {region_name} utilization is {utilization_ratio:.3f}, "
                            f"above configured threshold {budget_ratio:.3f}."
                        ),
                        affected_entities=(region_name,),
                        remediation_hint="Rebalance footprint or update budget thresholds intentionally.",
                    )
                )
    return issues


def _baseline_regressions(summary: ReportSummary, baseline_json_path: Path | None) -> dict[str, object]:
    if baseline_json_path is None:
        return {}
    if not baseline_json_path.exists():
        return {"status": "baseline_missing", "path": str(baseline_json_path)}

    try:
        payload = json.loads(baseline_json_path.read_text(encoding="utf-8"))
    except (ValueError, OSError) as exc:
        return {"status": "baseline_unreadable", "path": str(baseline_json_path), "error": str(exc)}

    baseline_summary = payload.get("summary", {}) if isinstance(payload, dict) else {}
    if not isinstance(baseline_summary, dict):
        return {"status": "baseline_invalid", "path": str(baseline_json_path)}

    base_flash = _as_int(baseline_summary.get("total_flash"), default=0)
    base_ram = _as_int(baseline_summary.get("total_ram"), default=0)
    base_util = baseline_summary.get("utilization_by_region", {})
    if not isinstance(base_util, dict):
        base_util = {}

    region_deltas: dict[str, object] = {}
    for region_name, current_ratio in summary.utilization_by_region.items():
        baseline_ratio = _as_float(base_util.get(region_name), default=0.0)
        region_deltas[region_name] = {
            "current": current_ratio,
            "baseline": baseline_ratio,
            "delta": current_ratio - baseline_ratio,
        }

    return {
        "status": "ok",
        "baseline_path": str(baseline_json_path),
        "flash_delta_bytes": summary.total_flash - base_flash,
        "ram_delta_bytes": summary.total_ram - base_ram,
        "regions": region_deltas,
    }


def _as_int(value: object, *, default: int) -> int:
    if isinstance(value, bool):
        return default
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    return default


def _as_float(value: object, *, default: float) -> float:
    if isinstance(value, bool):
        return default
    if isinstance(value, (int, float)):
        return float(value)
    return default
