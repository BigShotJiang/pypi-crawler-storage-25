"""Component ownership/grouping analysis."""

from __future__ import annotations

import re
from collections.abc import Mapping
from fnmatch import fnmatch

from memscope.config import MemscopeConfig
from memscope.domain import ComponentGroup, SymbolEntry

_SCOPE_ALIASES = {
    "object": "object",
    "obj": "object",
    "archive": "archive",
    "ar": "archive",
    "compilation_unit": "compilation_unit",
    "unit": "compilation_unit",
    "source": "source",
    "src": "source",
    "symbol": "symbol",
    "sym": "symbol",
    "section": "section",
    "sec": "section",
}

_DEFAULT_GROUP_PATTERNS: dict[str, tuple[str, ...]] = {
    "Drivers": ("*driver*", "*drv*", "*hal*"),
    "RTOS": ("*freertos*", "*cmsis_os*", "*rtos*", "*threadx*", "*zephyr*"),
    "Middleware": ("*mbedtls*", "*lwip*", "*fatfs*", "*usb*", "*middleware*"),
    "Startup": ("symbol:__vectors*", "*startup*", "*crt0*"),
    "Application": ("*app/*", "*application/*", "*main*"),
}
_RAM_REGION_CATEGORIES = frozenset({"ram", "tcm", "retention", "external_ram"})
_FLASH_REGION_CATEGORIES = frozenset({"flash", "external_flash"})
_RAM_SECTION_TOKENS = frozenset(
    {
        "data",
        "sdata",
        "tdata",
        "bss",
        "sbss",
        "tbss",
        "heap",
        "stack",
        "noinit",
        "noload",
        "ram",
        "sram",
        "tcm",
        "dtcm",
        "itcm",
        "retention",
        "cacheable",
        "shareable",
        "shared",
    }
)
_FLASH_SECTION_TOKENS = frozenset(
    {
        "text",
        "code",
        "const",
        "rodata",
        "vector",
        "vectors",
        "intvec",
        "isr",
        "startup",
        "plt",
        "stub",
        "tramp",
    }
)


def group_symbols_by_component(
    symbols: list[SymbolEntry],
    config: MemscopeConfig,
    *,
    section_category_by_name: Mapping[str, str] | None = None,
) -> list[ComponentGroup]:
    groups: dict[str, ComponentGroup] = {
        name: ComponentGroup(name=name, matching_rules=patterns)
        for name, patterns in config.groups.items()
    }
    groups.setdefault("Unassigned", ComponentGroup(name="Unassigned", matching_rules=("*",)))

    for symbol in symbols:
        group_name, matching_rules = _resolve_group_name(symbol, config.groups)
        group = groups.get(group_name)
        if group is None:
            group = ComponentGroup(name=group_name, matching_rules=matching_rules)
            groups[group_name] = group

        group.symbols = tuple(sorted(set(group.symbols) | {symbol.name}))
        if symbol.object_file:
            group.objects = tuple(sorted(set(group.objects) | {symbol.object_file}))

        if _symbol_targets_ram(symbol, section_category_by_name):
            group.total_ram += symbol.size
        else:
            group.total_flash += symbol.size

    return sorted(groups.values(), key=lambda group: group.name)


def _resolve_group_name(
    symbol: SymbolEntry,
    group_patterns: Mapping[str, tuple[str, ...]],
) -> tuple[str, tuple[str, ...]]:
    values = _symbol_values(symbol)

    configured_match = _match_group(values, group_patterns)
    if configured_match is not None:
        group_name, patterns = configured_match
        return group_name, patterns

    if group_patterns:
        # When users provide explicit grouping rules, preserve a strict
        # "matched vs unassigned" behavior for predictability.
        return "Unassigned", ("*",)

    default_match = _match_group(values, _DEFAULT_GROUP_PATTERNS)
    if default_match is not None:
        group_name, patterns = default_match
        return group_name, patterns

    ownership_fallback = _ownership_component_name(symbol)
    if ownership_fallback:
        return ownership_fallback, (f"object:{ownership_fallback}",)

    return "Unassigned", ("*",)


def _match_group(
    values: Mapping[str, str],
    group_patterns: Mapping[str, tuple[str, ...]],
) -> tuple[str, tuple[str, ...]] | None:
    for group_name, patterns in group_patterns.items():
        for pattern in patterns:
            if _pattern_matches(values, pattern):
                return group_name, patterns
    return None


def _pattern_matches(values: Mapping[str, str], pattern: str) -> bool:
    normalized_pattern = pattern.strip().lower()
    if not normalized_pattern:
        return False

    scope, separator, scoped_pattern = normalized_pattern.partition(":")
    if separator:
        normalized_scope = _SCOPE_ALIASES.get(scope.strip())
        if normalized_scope is None:
            return False
        target = values.get(normalized_scope, "")
        return bool(target) and fnmatch(target, scoped_pattern)

    for target in values.values():
        if target and fnmatch(target, normalized_pattern):
            return True
    return False


def _symbol_values(symbol: SymbolEntry) -> dict[str, str]:
    object_value = (symbol.object_file or "").lower()
    archive_value = (symbol.archive or "").lower()
    compilation_unit_value = (symbol.compilation_unit or "").lower()
    source_value = (symbol.source_file or "").lower()
    symbol_value = symbol.name.lower()
    section_value = (symbol.section_name or "").lower()

    ownership_key = (
        object_value
        or archive_value
        or compilation_unit_value
        or source_value
        or symbol_value
    )

    return {
        "object": object_value,
        "archive": archive_value,
        "compilation_unit": compilation_unit_value,
        "source": source_value,
        "symbol": symbol_value,
        "section": section_value,
        "ownership": ownership_key,
    }


def _ownership_component_name(symbol: SymbolEntry) -> str | None:
    for candidate in (
        symbol.object_file,
        symbol.archive,
        symbol.compilation_unit,
        symbol.source_file,
    ):
        normalized = _normalize_ownership_label(candidate)
        if normalized:
            return normalized
    return None


def _normalize_ownership_label(value: str | None) -> str:
    if not value:
        return ""
    compact = value.strip().replace("\\", "/")
    if not compact:
        return ""
    if "/" in compact:
        compact = compact.rsplit("/", 1)[1]
    return compact.strip()


def _symbol_targets_ram(
    symbol: SymbolEntry,
    section_category_by_name: Mapping[str, str] | None,
) -> bool:
    section_name = (symbol.section_name or "").strip()
    if section_category_by_name and section_name:
        category = str(section_category_by_name.get(section_name, "")).strip().lower()
        if category in _RAM_REGION_CATEGORIES:
            return True
        if category in _FLASH_REGION_CATEGORIES:
            return False

    tokens = _identifier_tokens(section_name)
    if not tokens:
        return False
    if tokens & _RAM_SECTION_TOKENS:
        return True
    if tokens & _FLASH_SECTION_TOKENS:
        return False
    return False


def _identifier_tokens(value: str) -> set[str]:
    return {token for token in re.split(r"[^a-z0-9]+", value.lower()) if token}
