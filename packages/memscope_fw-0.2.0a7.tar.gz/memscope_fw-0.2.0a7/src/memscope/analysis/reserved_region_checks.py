"""Reserved-region and placement anomaly checks."""

from __future__ import annotations

from memscope.domain import Issue, IssueCategory, IssueSeverity, MemoryRegionCategory
from memscope.toolchains.base import NormalizedBuildModel

_RESERVED_REGION_HINTS = ("reserved", "rsv", "hse_fw", "bootloader_reserved")
_TEXT_SECTION_HINTS = (".text", ".rodata", ".init", ".vectors", ".isr")
_RAM_SECTION_HINTS = (".data", ".bss", ".heap", ".stack")


def detect_reserved_region_violations(model: NormalizedBuildModel) -> list[Issue]:
    reserved_regions = {
        region.name
        for region in model.memory_regions
        if any(hint in region.name.lower() for hint in _RESERVED_REGION_HINTS)
    }
    issues: list[Issue] = []
    for section in model.sections:
        if section.execution_region and section.execution_region in reserved_regions and section.size > 0:
            issues.append(
                Issue(
                    id=f"reserved_region.{section.execution_region}.{section.name}",
                    severity=IssueSeverity.ERROR,
                    category=IssueCategory.RESERVED,
                    title="Section placed in reserved region",
                    description=(
                        f"Section {section.name} is mapped to reserved region {section.execution_region}."
                    ),
                    affected_entities=(section.name, section.execution_region),
                    remediation_hint="Review linker placement rules for reserved/firmware regions.",
                )
            )
    return issues


def detect_suspicious_section_placement(model: NormalizedBuildModel) -> list[Issue]:
    category_by_region = {region.name: region.category for region in model.memory_regions}
    issues: list[Issue] = []
    for section in model.sections:
        if section.execution_region is None:
            issues.append(
                Issue(
                    id=f"placement.unmapped.{section.name}",
                    severity=IssueSeverity.WARNING,
                    category=IssueCategory.PLACEMENT,
                    title="Section has no resolved execution region",
                    description=f"Section {section.name} could not be mapped to a memory region.",
                    affected_entities=(section.name,),
                    remediation_hint="Check linker script and MAP region declarations.",
                )
            )
            continue

        category = category_by_region.get(section.execution_region)
        lowered_name = section.name.lower()
        if category in (MemoryRegionCategory.RAM, MemoryRegionCategory.TCM) and any(
            hint in lowered_name for hint in _TEXT_SECTION_HINTS
        ):
            issues.append(
                Issue(
                    id=f"placement.text_in_ram.{section.name}",
                    severity=IssueSeverity.WARNING,
                    category=IssueCategory.PLACEMENT,
                    title="Code/rodata section executing from RAM",
                    description=(
                        f"Section {section.name} executes from {section.execution_region} "
                        "which is RAM-like memory."
                    ),
                    affected_entities=(section.name, section.execution_region),
                    remediation_hint="If intentional, document it; otherwise adjust placement to FLASH.",
                )
            )

        if category in (MemoryRegionCategory.FLASH, MemoryRegionCategory.EXTERNAL_FLASH) and any(
            hint in lowered_name for hint in _RAM_SECTION_HINTS
        ):
            issues.append(
                Issue(
                    id=f"placement.ram_section_in_flash.{section.name}",
                    severity=IssueSeverity.WARNING,
                    category=IssueCategory.PLACEMENT,
                    title="RAM-oriented section mapped to FLASH",
                    description=(
                        f"Section {section.name} is mapped to {section.execution_region} "
                        "but appears RAM-oriented."
                    ),
                    affected_entities=(section.name, section.execution_region),
                    remediation_hint="Review section VMA/LMA mapping and startup copy rules.",
                )
            )

    return issues

