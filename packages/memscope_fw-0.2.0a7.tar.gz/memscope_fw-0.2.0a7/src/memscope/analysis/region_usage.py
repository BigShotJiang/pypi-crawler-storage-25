"""Region utilization analysis."""

from __future__ import annotations

from dataclasses import dataclass

from memscope.toolchains.base import NormalizedBuildModel


@dataclass(slots=True)
class RegionUsageResult:
    region_name: str
    region_size: int
    used_bytes: int
    free_bytes: int
    utilization_ratio: float
    overflow_bytes: int


def compute_region_usage(model: NormalizedBuildModel) -> dict[str, RegionUsageResult]:
    usage: dict[str, int] = {region.name: 0 for region in model.memory_regions}
    size_by_region: dict[str, int] = {region.name: region.size or 0 for region in model.memory_regions}

    for section in model.sections:
        if section.execution_region:
            usage[section.execution_region] = usage.get(section.execution_region, 0) + max(section.size, 0)

    results: dict[str, RegionUsageResult] = {}
    for region_name, used in usage.items():
        size = max(size_by_region.get(region_name, 0), 0)
        overflow = max(used - size, 0)
        free = max(size - used, 0)
        utilization = (used / size) if size > 0 else 0.0
        results[region_name] = RegionUsageResult(
            region_name=region_name,
            region_size=size,
            used_bytes=used,
            free_bytes=free,
            utilization_ratio=utilization,
            overflow_bytes=overflow,
        )

    return results

