"""Policy engine orchestration for rules evaluation and blocking decisions."""

from __future__ import annotations

from dataclasses import dataclass

from memscope.config import MemscopeConfig
from memscope.domain import AnalysisReport, Issue, IssueCategory, IssueSeverity
from memscope.domain.sorting import sort_issues
from memscope.rules import RuleContext, SuppressedIssue, SuppressionSet, apply_suppressions
from memscope.rules.base import RuleEvaluation
from memscope.rules.registry import default_rule_registry
from memscope.toolchains.base import NormalizedBuildModel


@dataclass(slots=True)
class PolicyEvaluationResult:
    """Final policy state for one analysis run."""

    issues: list[Issue]
    blocking_issue_ids: tuple[str, ...]
    suppressed_issues: tuple[SuppressedIssue, ...]
    rule_evaluations: tuple[RuleEvaluation, ...]
    blocking: bool

    def to_debug_dict(self) -> dict[str, object]:
        return {
            "blocking": self.blocking,
            "blocking_issue_ids": list(self.blocking_issue_ids),
            "issues_total": len(self.issues),
            "issues_by_severity": {
                "info": sum(1 for issue in self.issues if issue.severity == IssueSeverity.INFO),
                "warning": sum(1 for issue in self.issues if issue.severity == IssueSeverity.WARNING),
                "error": sum(1 for issue in self.issues if issue.severity == IssueSeverity.ERROR),
            },
            "suppressed_issues": [
                {"id": item.issue.id, "reason": item.reason, "severity": item.issue.severity.value}
                for item in self.suppressed_issues
            ],
            "rule_trace": [
                {
                    "rule_id": evaluation.rule_id,
                    "produced_issue_ids": [issue.id for issue in evaluation.issues],
                    "notes": list(evaluation.notes),
                }
                for evaluation in self.rule_evaluations
            ],
        }


def evaluate_policies(
    model: NormalizedBuildModel,
    report: AnalysisReport,
    config: MemscopeConfig,
) -> PolicyEvaluationResult:
    """Evaluate policy rules and return blocking/non-blocking decisions."""
    context = RuleContext(model=model, report=report, config=config)
    registry = default_rule_registry()
    evaluations = registry.evaluate_all(context)

    merged = _deduplicate_issues(
        list(report.issues)
        + [issue for evaluation in evaluations for issue in evaluation.issues]
    )

    suppression_set = SuppressionSet.from_config(config)
    suppression_result = apply_suppressions(merged, suppression_set)
    active_issues = sort_issues(suppression_result.active_issues)

    blocking_issue_ids = tuple(
        issue.id
        for issue in active_issues
        if _is_blocking_issue(issue, config)
    )

    return PolicyEvaluationResult(
        issues=active_issues,
        blocking_issue_ids=blocking_issue_ids,
        suppressed_issues=tuple(suppression_result.suppressed_issues),
        rule_evaluations=evaluations,
        blocking=bool(blocking_issue_ids),
    )


def _deduplicate_issues(issues: list[Issue]) -> list[Issue]:
    by_id: dict[str, Issue] = {}
    for issue in issues:
        by_id.setdefault(issue.id, issue)
    return list(by_id.values())


def _is_blocking_issue(issue: Issue, config: MemscopeConfig) -> bool:
    if issue.severity != IssueSeverity.ERROR:
        return False
    if issue.category == IssueCategory.OVERFLOW:
        return config.policies.fail_on_overflow
    if issue.category == IssueCategory.RESERVED:
        return config.policies.fail_on_reserved_region_violation
    return True

