"""Section utilization analysis."""

from __future__ import annotations

from dataclasses import dataclass

from memscope.analysis.region_usage import RegionUsageResult
from memscope.toolchains.base import NormalizedBuildModel


@dataclass(slots=True)
class SectionUsageResult:
    section_name: str
    execution_region: str | None
    load_region: str | None
    size: int
    utilization_ratio_in_region: float | None


def compute_section_usage(
    model: NormalizedBuildModel,
    region_usage: dict[str, RegionUsageResult],
) -> list[SectionUsageResult]:
    results: list[SectionUsageResult] = []
    for section in sorted(model.sections, key=lambda item: (item.execution_region or "", item.name)):
        ratio: float | None = None
        if section.execution_region and section.execution_region in region_usage:
            region_size = region_usage[section.execution_region].region_size
            ratio = (section.size / region_size) if region_size > 0 else None

        results.append(
            SectionUsageResult(
                section_name=section.name,
                execution_region=section.execution_region,
                load_region=section.load_region,
                size=section.size,
                utilization_ratio_in_region=ratio,
            )
        )

    return results

