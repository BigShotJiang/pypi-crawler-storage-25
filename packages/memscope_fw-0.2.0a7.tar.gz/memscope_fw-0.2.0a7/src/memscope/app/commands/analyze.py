"""Analyze command scaffold."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Annotated

import typer

from memscope.app.session import AnalyzeInputs, CommandResult, SessionManager

GetSessionManager = Callable[[typer.Context], SessionManager]
RunWithErrorHandling = Callable[[SessionManager, Callable[[SessionManager], CommandResult]], None]


def register_command(
    app: typer.Typer,
    get_session_manager: GetSessionManager,
    run_with_error_handling: RunWithErrorHandling,
) -> None:
    @app.command("analyze")
    def analyze_command(
        ctx: typer.Context,
        elf: Annotated[Path | None, typer.Option("--elf", help="Path to ELF file.")] = None,
        map_file: Annotated[Path | None, typer.Option("--map", help="Path to MAP file.")] = None,
        linker: Annotated[Path | None, typer.Option("--linker", help="Path to linker script/config file.")] = None,
        html: Annotated[Path | None, typer.Option("--html", help="Output HTML report path.")] = None,
        json_output: Annotated[Path | None, typer.Option("--json", help="Output JSON report path.")] = None,
        csv: Annotated[Path | None, typer.Option("--csv", help="Output CSV report path.")] = None,
        baseline_json: Annotated[
            Path | None, typer.Option("--baseline-json", help="Baseline report JSON path for comparison.")
        ] = None,
    ) -> None:
        def _run(session: SessionManager) -> CommandResult:
            return session.analyze(
                AnalyzeInputs(
                    elf=elf,
                    map_file=map_file,
                    linker=linker,
                    html=html,
                    json=json_output,
                    csv=csv,
                    baseline_json=baseline_json,
                )
            )

        run_with_error_handling(get_session_manager(ctx), _run)
