"""Developer command group scaffold."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Annotated

import typer

from memscope.app.session import CommandResult, SessionManager, ValidateInputs

GetSessionManager = Callable[[typer.Context], SessionManager]
RunWithErrorHandling = Callable[[SessionManager, Callable[[SessionManager], CommandResult]], None]


def register_group(
    app: typer.Typer,
    get_session_manager: GetSessionManager,
    run_with_error_handling: RunWithErrorHandling,
) -> None:
    dev_app = typer.Typer(help="Developer-mode commands.", no_args_is_help=True)
    inspect_app = typer.Typer(help="Inspect internal stage outputs.", no_args_is_help=True)

    @inspect_app.command("parse")
    def inspect_parse(
        ctx: typer.Context,
        elf: Annotated[Path | None, typer.Option("--elf", help="Path to ELF file.")] = None,
        map_file: Annotated[Path | None, typer.Option("--map", help="Path to MAP file.")] = None,
        linker: Annotated[Path | None, typer.Option("--linker", help="Path to linker script/config file.")] = None,
        output: Annotated[Path | None, typer.Option("--output", help="Optional output file path.")] = None,
    ) -> None:
        run_with_error_handling(
            get_session_manager(ctx),
            lambda session: session.inspect_parse(
                ValidateInputs(elf=elf, map_file=map_file, linker=linker),
                output,
            ),
        )

    @inspect_app.command("model")
    def inspect_model(
        ctx: typer.Context,
        output: Annotated[Path | None, typer.Option("--output", help="Optional output file path.")] = None,
    ) -> None:
        run_with_error_handling(get_session_manager(ctx), lambda session: session.dev_inspect("model", output))

    @inspect_app.command("timings")
    def inspect_timings(
        ctx: typer.Context,
        output: Annotated[Path | None, typer.Option("--output", help="Optional output file path.")] = None,
    ) -> None:
        run_with_error_handling(get_session_manager(ctx), lambda session: session.dev_inspect("timings", output))

    @inspect_app.command("rules")
    def inspect_rules(
        ctx: typer.Context,
        output: Annotated[Path | None, typer.Option("--output", help="Optional output file path.")] = None,
    ) -> None:
        run_with_error_handling(get_session_manager(ctx), lambda session: session.dev_inspect("rules", output))

    dev_app.add_typer(inspect_app, name="inspect")
    app.add_typer(dev_app, name="dev")
