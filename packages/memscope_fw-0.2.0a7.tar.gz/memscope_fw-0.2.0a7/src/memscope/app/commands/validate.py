"""Validate command scaffold."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Annotated

import typer

from memscope.app.session import CommandResult, SessionManager, ValidateInputs

GetSessionManager = Callable[[typer.Context], SessionManager]
RunWithErrorHandling = Callable[[SessionManager, Callable[[SessionManager], CommandResult]], None]


def register_command(
    app: typer.Typer,
    get_session_manager: GetSessionManager,
    run_with_error_handling: RunWithErrorHandling,
) -> None:
    @app.command("validate")
    def validate_command(
        ctx: typer.Context,
        elf: Annotated[Path | None, typer.Option("--elf", help="Path to ELF file.")] = None,
        map_file: Annotated[Path | None, typer.Option("--map", help="Path to MAP file.")] = None,
        linker: Annotated[Path | None, typer.Option("--linker", help="Path to linker script/config file.")] = None,
    ) -> None:
        def _run(session: SessionManager) -> CommandResult:
            return session.validate(ValidateInputs(elf=elf, map_file=map_file, linker=linker))

        run_with_error_handling(get_session_manager(ctx), _run)
