"""Diagnostics command group scaffold."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Annotated

import typer

from memscope.app.session import CommandResult, SessionManager

GetSessionManager = Callable[[typer.Context], SessionManager]
RunWithErrorHandling = Callable[[SessionManager, Callable[[SessionManager], CommandResult]], None]


def register_group(
    app: typer.Typer,
    get_session_manager: GetSessionManager,
    run_with_error_handling: RunWithErrorHandling,
) -> None:
    diagnostics_app = typer.Typer(help="Diagnostics commands.", no_args_is_help=True)

    @diagnostics_app.command("export")
    def diagnostics_export(
        ctx: typer.Context,
        output: Annotated[
            Path | None,
            typer.Option("--output", help="Diagnostics bundle output path."),
        ] = None,
    ) -> None:
        run_with_error_handling(get_session_manager(ctx), lambda session: session.diagnostics_export(output))

    app.add_typer(diagnostics_app, name="diagnostics")
