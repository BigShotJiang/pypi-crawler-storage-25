"""Diff command scaffold."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Annotated

import typer

from memscope.app.session import CommandResult, SessionManager

GetSessionManager = Callable[[typer.Context], SessionManager]
RunWithErrorHandling = Callable[[SessionManager, Callable[[SessionManager], CommandResult]], None]


def register_command(
    app: typer.Typer,
    get_session_manager: GetSessionManager,
    run_with_error_handling: RunWithErrorHandling,
) -> None:
    @app.command("diff")
    def diff_command(
        ctx: typer.Context,
        current_json: Annotated[Path, typer.Option("--current-json", help="Current report JSON path.")],
        baseline_json: Annotated[Path, typer.Option("--baseline-json", help="Baseline report JSON path.")],
        output_json: Annotated[Path | None, typer.Option("--json", help="Optional diff JSON output path.")] = None,
        output_html: Annotated[Path | None, typer.Option("--html", help="Optional diff HTML output path.")] = None,
    ) -> None:
        def _run(session: SessionManager) -> CommandResult:
            return session.diff(
                current_json=current_json,
                baseline_json=baseline_json,
                output_json=output_json,
                output_html=output_html,
            )

        run_with_error_handling(get_session_manager(ctx), _run)
