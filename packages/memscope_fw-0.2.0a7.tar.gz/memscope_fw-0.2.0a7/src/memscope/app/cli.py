"""Typer-based command-line entrypoint for MemScope."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from importlib.metadata import PackageNotFoundError, version
from typing import Annotated, TypeVar

import typer

from memscope.app.commands import analyze, dev, diagnostics, diff, validate
from memscope.app.logging_utils import configure_logging
from memscope.app.session import (
    CommandExecutionError,
    CommandResult,
    ExitCode,
    GlobalOptions,
    SessionManager,
)
from memscope.bundles import load_enabled_bundles

R = TypeVar("R", bound=CommandResult)


@dataclass(slots=True)
class AppContext:
    options: GlobalOptions


def _resolve_version() -> str:
    try:
        # PyPI distribution name (`memscope-fw`) — different from the
        # Python import name (`memscope`). See pyproject.toml.
        return version("memscope-fw")
    except PackageNotFoundError:
        from memscope import __version__

        return __version__


app = typer.Typer(
    name="memscope",
    no_args_is_help=True,
    invoke_without_command=True,
    add_completion=False,
    help="Local-first firmware footprint intelligence CLI.",
)


def _session_from_context(ctx: typer.Context) -> SessionManager:
    context = ctx.obj
    if not isinstance(context, AppContext):
        raise RuntimeError("CLI context not initialized")
    return SessionManager(context.options)


def _run_with_error_handling(
    session: SessionManager,
    action: Callable[[SessionManager], CommandResult],
) -> None:
    try:
        result = action(session)
    except CommandExecutionError as exc:
        typer.secho(exc.message, err=True, fg=typer.colors.RED)
        raise typer.Exit(code=int(exc.exit_code)) from exc

    if result.message:
        typer.echo(result.message)
    raise typer.Exit(code=int(result.exit_code))


@app.callback()
def app_callback(
    ctx: typer.Context,
    config: Annotated[
        str | None,
        typer.Option("--config", help="Path to MemScope TOML configuration file."),
    ] = None,
    log_level: Annotated[
        str,
        typer.Option("--log-level", help="Log verbosity: error|warning|info|debug|trace."),
    ] = "info",
    strict: Annotated[
        bool,
        typer.Option("--strict", help="Enable strict command behavior."),
    ] = False,
    toolchain: Annotated[
        str | None,
        typer.Option("--toolchain", help="Toolchain hint override."),
    ] = None,
    target_name: Annotated[
        str | None,
        typer.Option("--target-name", help="Target name override."),
    ] = None,
    show_version: Annotated[
        bool,
        typer.Option("--version", help="Show MemScope version and exit.", is_eager=True),
    ] = False,
) -> None:
    if show_version:
        typer.echo(_resolve_version())
        raise typer.Exit(code=0)

    normalized_log_level = log_level.strip().lower()
    allowed_levels = {"error", "warning", "info", "debug", "trace"}
    if normalized_log_level not in allowed_levels:
        typer.secho(
            f"Invalid --log-level '{log_level}'. Expected one of: {', '.join(sorted(allowed_levels))}.",
            err=True,
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=int(ExitCode.INPUT_OR_PARSING_ERROR))

    try:
        configure_logging(level=normalized_log_level, developer_mode=False)
    except ValueError as exc:
        typer.secho(str(exc), err=True, fg=typer.colors.RED)
        raise typer.Exit(code=int(ExitCode.INPUT_OR_PARSING_ERROR)) from exc

    ctx.obj = AppContext(
        options=GlobalOptions(
            config_path=config.strip() if config else None,
            log_level=normalized_log_level,
            strict=strict,
            toolchain=toolchain.strip() if toolchain else None,
            target_name=target_name.strip() if target_name else None,
            no_renewal_reminder=False,
        )
    )


analyze.register_command(app, _session_from_context, _run_with_error_handling)
diff.register_command(app, _session_from_context, _run_with_error_handling)
validate.register_command(app, _session_from_context, _run_with_error_handling)
diagnostics.register_group(app, _session_from_context, _run_with_error_handling)
dev.register_group(app, _session_from_context, _run_with_error_handling)


# Top-level `accept-terms` for explicit EULA acceptance (no prompt).
@app.command("accept-terms")
def accept_terms_command(ctx: typer.Context) -> None:
    """Record EULA acceptance without prompting; suitable for non-interactive setup."""
    session = _session_from_context(ctx)
    _run_with_error_handling(session, lambda s: s.accept_terms())


# Bundle registration. Free-core wheel: `load_enabled_bundles()` returns
# []; nothing happens. Customer-Bound Wheel: each Bundle gets a chance
# to add its own subcommand group to the main app. Activation errors
# raised by any Bundle's __init__ are swallowed (logged at WARNING) so
# a misconfigured Bundle can't break the rest of the CLI.
for _bundle in load_enabled_bundles():
    try:
        _bundle.register_cli_commands(app)
    except Exception:  # noqa: BLE001 — defence in depth; never break CLI
        # The Bundle module already logged via memscope.bundles logger
        # if the failure was at import time; re-import errors here are
        # rare and benign (Bundle ships a half-baked register hook).
        # Continue registering other Bundles.
        continue


def main() -> None:
    app()
