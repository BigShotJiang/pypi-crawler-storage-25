"""Session orchestration and command execution primitives."""

from __future__ import annotations

import json
import sys
from collections.abc import Mapping
from dataclasses import dataclass, field
from enum import IntEnum
from pathlib import Path
from time import perf_counter
from typing import Any

from memscope import __version__
from memscope.analysis import build_analysis_report, evaluate_policies
from memscope.app.logging_utils import get_logger
from memscope.config import ConfigValidationError, MemscopeConfig, load_config
from memscope.diff import compare_report_files, compare_with_baseline_file
from memscope.diff.render_helpers import render_diff_console_summary, render_diff_html
from memscope.domain import AnalysisReport, BuildArtifactSet
from memscope.domain.serialization import to_json_dict
from memscope.licensing import (
    EULA_TEXT,
    EulaStore,
)
from memscope.monitoring import build_telemetry_sink
from memscope.outputs import (
    build_json_payload,
    ensure_parent_dir,
    export_diagnostics_bundle,
    render_console_summary,
    resolve_report_path,
    write_csv_report,
    write_html_report,
    write_json_report,
)
from memscope.parsers import parse_artifact_set
from memscope.parsers.models import ParsedArtifactSet
from memscope.security import is_remote_reference
from memscope.toolchains import normalize_parsed_artifacts
from memscope.toolchains.base import NormalizedBuildModel


class ExitCode(IntEnum):
    """CLI exit codes aligned with architecture policy."""

    SUCCESS = 0
    POLICY_FAILURE = 1
    INPUT_OR_PARSING_ERROR = 2
    LICENSE_FAILURE = 3


@dataclass(slots=True)
class CommandResult:
    """Outcome returned by command handlers."""

    message: str
    exit_code: ExitCode = ExitCode.SUCCESS
    payload: dict[str, Any] = field(default_factory=dict)


class CommandExecutionError(RuntimeError):
    """Structured command failure with explicit exit code."""

    def __init__(self, message: str, exit_code: ExitCode) -> None:
        self.message = message
        self.exit_code = exit_code
        super().__init__(message)


@dataclass(slots=True)
class GlobalOptions:
    config_path: Path | str | None = None
    log_level: str = "info"
    strict: bool = False
    toolchain: str | None = None
    target_name: str | None = None
    no_renewal_reminder: bool = False


@dataclass(slots=True)
class AnalyzeInputs:
    elf: Path | None = None
    map_file: Path | None = None
    linker: Path | None = None
    html: Path | None = None
    json: Path | None = None
    csv: Path | None = None
    baseline_json: Path | None = None


@dataclass(slots=True)
class ValidateInputs:
    elf: Path | None = None
    map_file: Path | None = None
    linker: Path | None = None


@dataclass(slots=True)
class AnalysisPipelineResult:
    parsed: ParsedArtifactSet
    normalized: NormalizedBuildModel
    analysis_report: AnalysisReport
    policy_result: Any
    timings: dict[str, float]


class SessionManager:
    """Application-layer session manager for one CLI invocation."""

    def __init__(self, options: GlobalOptions) -> None:
        self.options = options
        self.logger = get_logger("session")
        self.eula_store = EulaStore()

    @staticmethod
    def _resolve_path(path: Path | str | None) -> Path | None:
        if path is None:
            return None
        raw = path.as_posix() if isinstance(path, Path) else str(path)
        if is_remote_reference(raw):
            raise CommandExecutionError(
                f"Remote/network path is not allowed in local-only mode: {raw}",
                ExitCode.INPUT_OR_PARSING_ERROR,
            )
        return Path(path).expanduser().resolve()

    @staticmethod
    def _must_exist(path: Path | None, option_name: str) -> None:
        if path is None:
            return
        if not path.exists():
            raise CommandExecutionError(
                f"{option_name} not found: {path}",
                ExitCode.INPUT_OR_PARSING_ERROR,
            )

    @staticmethod
    def _count_diagnostics(parsed: ParsedArtifactSet) -> dict[str, int]:
        counts = {"info": 0, "warning": 0, "error": 0}
        for diagnostic in parsed.all_diagnostics():
            counts[diagnostic.severity.value] += 1
        return counts

    @staticmethod
    def _write_json(path: Path, payload: Mapping[str, object]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")

    def _trace(self, message: str, *args: object) -> None:
        trace_fn = getattr(self.logger, "trace", None)
        if callable(trace_fn):
            trace_fn(message, *args)
        else:
            self.logger.debug(message, *args)

    def _require_eula(self, command_name: str) -> None:
        """Refuse the command if the EULA has not been accepted.

        On TTY, attempts to auto-prompt; on non-TTY contexts (CI /
        scripts), refuses with a hint to run ``memscope accept-terms``
        first. Re-prompts when the EULA hash changes.
        """
        state = self.eula_store.load()
        if state is not None and state.is_current():
            return
        if sys.stdin.isatty():
            sys.stderr.write(EULA_TEXT)
            sys.stderr.flush()
            try:
                response = input("[EULA] Type 'yes' to accept: ").strip().lower()
            except EOFError:
                response = ""
            if response in {"yes", "y"}:
                self.eula_store.record_acceptance()
                return
            raise CommandExecutionError(
                f'"{command_name}" cannot proceed without EULA acceptance.',
                ExitCode.LICENSE_FAILURE,
            )
        raise CommandExecutionError(
            (
                f'"{command_name}" requires EULA acceptance and the current '
                "shell is non-interactive. Run `memscope accept-terms` "
                "from a terminal first."
            ),
            ExitCode.LICENSE_FAILURE,
        )

    def accept_terms(self) -> CommandResult:
        """CLI-driven explicit EULA acceptance (no prompt; just records)."""
        state = self.eula_store.record_acceptance()
        return CommandResult(
            message=(
                f"EULA accepted at {state.accepted_at.isoformat()} "
                f"(hash {state.accepted_hash[:12]}...)."
            ),
            payload={
                "eula_accepted_at": state.accepted_at.isoformat(),
                "eula_accepted_hash": state.accepted_hash,
            },
        )

    def _run_analysis_pipeline(
        self,
        *,
        config: MemscopeConfig,
        artifacts: BuildArtifactSet,
        baseline_json_path: Path | None,
    ) -> AnalysisPipelineResult:
        timings: dict[str, float] = {}
        overall_started = perf_counter()

        self.logger.debug("analysis pipeline started")
        self._trace(
            "analysis inputs: target=%s toolchain_hint=%s elf=%s map=%s linker=%s",
            artifacts.target_name,
            artifacts.toolchain_hint,
            artifacts.elf_path,
            artifacts.map_path,
            artifacts.linker_path,
        )

        parse_started = perf_counter()
        parsed = parse_artifact_set(artifacts, explicit_toolchain=self.options.toolchain)
        timings["parse_seconds"] = perf_counter() - parse_started

        normalize_started = perf_counter()
        normalized = normalize_parsed_artifacts(parsed)
        timings["normalize_seconds"] = perf_counter() - normalize_started

        analysis_started = perf_counter()
        analysis_report = build_analysis_report(
            normalized,
            config,
            target_name=artifacts.target_name,
            baseline_json_path=None,
        )
        timings["analysis_seconds"] = perf_counter() - analysis_started

        policy_started = perf_counter()
        policy_result = evaluate_policies(normalized, analysis_report, config)
        timings["policy_seconds"] = perf_counter() - policy_started

        analysis_report.issues = list(policy_result.issues)
        analysis_report.summary.issue_counts = {
            "info": sum(1 for issue in analysis_report.issues if issue.severity.value == "info"),
            "warning": sum(1 for issue in analysis_report.issues if issue.severity.value == "warning"),
            "error": sum(1 for issue in analysis_report.issues if issue.severity.value == "error"),
        }
        analysis_report.diagnostics["policy"] = policy_result.to_debug_dict()
        telemetry_sink = build_telemetry_sink(config.telemetry)
        analysis_report.diagnostics["telemetry"] = telemetry_sink.status_dict()
        # Privacy-restricted payload — see docs/public/privacy.md and
        # monitoring/telemetry.py::_ALLOWED_FIELDS for the whitelist.
        # NOT emitted: target_name, toolchain, issues_total, file paths,
        # symbol names, or any user-supplied data.
        telemetry_sink.emit(
            "analysis_completed",
            {
                "version": analysis_report.metadata.tool_version,
                "command": "analyze",
                "runtime_ms": int((perf_counter() - overall_started) * 1000),
            },
        )

        diff_started = perf_counter()
        if baseline_json_path is not None:
            current_payload = build_json_payload(
                analysis_report,
                artifacts=artifacts,
                baseline_json_path=baseline_json_path,
            )
            diff_report = compare_with_baseline_file(current_payload, baseline_json_path)
            analysis_report.regressions = diff_report.to_dict()
        else:
            analysis_report.regressions = {}
        timings["diff_seconds"] = perf_counter() - diff_started

        timings["total_seconds"] = perf_counter() - overall_started
        analysis_report.diagnostics["timings"] = dict(sorted(timings.items()))
        analysis_report = analysis_report.sorted_copy()

        self.logger.debug(
            "analysis pipeline completed in %.4fs (parse=%.4fs normalize=%.4fs analysis=%.4fs policy=%.4fs diff=%.4fs)",
            timings["total_seconds"],
            timings["parse_seconds"],
            timings["normalize_seconds"],
            timings["analysis_seconds"],
            timings["policy_seconds"],
            timings["diff_seconds"],
        )

        return AnalysisPipelineResult(
            parsed=parsed,
            normalized=normalized,
            analysis_report=analysis_report,
            policy_result=policy_result,
            timings=timings,
        )

    @staticmethod
    def _resolve_report_outputs(config: MemscopeConfig) -> dict[str, Path | None]:
        return {
            "html": resolve_report_path(config.reports.html, config_source_path=config.source_path),
            "json": resolve_report_path(config.reports.json, config_source_path=config.source_path),
            "csv": resolve_report_path(config.reports.csv, config_source_path=config.source_path),
        }

    def _emit_report_outputs(
        self,
        *,
        report: AnalysisReport,
        artifacts: BuildArtifactSet,
        baseline_json_path: Path | None,
        output_paths: Mapping[str, Path | None],
    ) -> tuple[dict[str, str | None], dict[str, Any]]:
        json_payload: dict[str, Any] = build_json_payload(
            report,
            artifacts=artifacts,
            baseline_json_path=baseline_json_path,
        )

        json_output = output_paths.get("json")
        if json_output is not None:
            write_json_report(
                json_output,
                report,
                artifacts=artifacts,
                baseline_json_path=baseline_json_path,
            )

        html_output = output_paths.get("html")
        if html_output is not None:
            write_html_report(html_output, report)

        csv_output = output_paths.get("csv")
        if csv_output is not None:
            write_csv_report(csv_output, report)

        rendered_paths = {
            name: str(path) if path is not None else None
            for name, path in output_paths.items()
        }
        return rendered_paths, json_payload

    def _build_cli_overrides_for_analyze(self, params: AnalyzeInputs) -> dict[str, object]:
        project_overrides: dict[str, object] = {}
        if self.options.toolchain:
            project_overrides["toolchain"] = self.options.toolchain
        if self.options.target_name:
            project_overrides["name"] = self.options.target_name

        input_overrides: dict[str, object] = {}
        if params.elf is not None:
            input_overrides["elf"] = str(params.elf)
        if params.map_file is not None:
            input_overrides["map"] = str(params.map_file)
        if params.linker is not None:
            input_overrides["linker"] = str(params.linker)

        report_overrides: dict[str, object] = {}
        if params.html is not None:
            report_overrides["html"] = str(params.html)
        if params.json is not None:
            report_overrides["json"] = str(params.json)
        if params.csv is not None:
            report_overrides["csv"] = str(params.csv)

        overrides: dict[str, object] = {}
        if project_overrides:
            overrides["project"] = project_overrides
        if input_overrides:
            overrides["inputs"] = input_overrides
        if report_overrides:
            overrides["reports"] = report_overrides
        return overrides

    def _build_cli_overrides_for_validate(self, params: ValidateInputs) -> dict[str, object]:
        overrides: dict[str, object] = {}
        if self.options.toolchain or self.options.target_name:
            project_overrides: dict[str, object] = {}
            if self.options.toolchain:
                project_overrides["toolchain"] = self.options.toolchain
            if self.options.target_name:
                project_overrides["name"] = self.options.target_name
            overrides["project"] = project_overrides

        input_overrides: dict[str, object] = {}
        if params.elf is not None:
            input_overrides["elf"] = str(params.elf)
        if params.map_file is not None:
            input_overrides["map"] = str(params.map_file)
        if params.linker is not None:
            input_overrides["linker"] = str(params.linker)
        if input_overrides:
            overrides["inputs"] = input_overrides
        return overrides

    def _load_config_with_overrides(self, overrides: Mapping[str, object]) -> MemscopeConfig:
        try:
            return load_config(self.options.config_path, cli_overrides=overrides)
        except ConfigValidationError as exc:
            raise CommandExecutionError(str(exc), ExitCode.INPUT_OR_PARSING_ERROR) from exc
        except FileNotFoundError as exc:
            raise CommandExecutionError(str(exc), ExitCode.INPUT_OR_PARSING_ERROR) from exc
        except ValueError as exc:
            raise CommandExecutionError(str(exc), ExitCode.INPUT_OR_PARSING_ERROR) from exc

    def _artifact_set_from_config(self, config: MemscopeConfig) -> BuildArtifactSet:
        elf = self._resolve_path(config.inputs.elf)
        map_file = self._resolve_path(config.inputs.map)
        linker = self._resolve_path(config.inputs.linker)

        self._must_exist(elf, "--elf")
        self._must_exist(map_file, "--map")
        self._must_exist(linker, "--linker")

        return BuildArtifactSet(
            elf_path=elf,
            map_path=map_file,
            linker_path=linker,
            toolchain_hint=config.project.toolchain,
            target_name=config.project.name,
        )

    def analyze(self, params: AnalyzeInputs) -> CommandResult:
        params = AnalyzeInputs(
            elf=self._resolve_path(params.elf),
            map_file=self._resolve_path(params.map_file),
            linker=self._resolve_path(params.linker),
            html=self._resolve_path(params.html),
            json=self._resolve_path(params.json),
            csv=self._resolve_path(params.csv),
            baseline_json=self._resolve_path(params.baseline_json),
        )
        if params.baseline_json is not None:
            self._must_exist(params.baseline_json, "--baseline-json")

        overrides = self._build_cli_overrides_for_analyze(params)
        config = self._load_config_with_overrides(overrides)
        artifacts = self._artifact_set_from_config(config)

        if not any((artifacts.elf_path, artifacts.map_path, artifacts.linker_path)):
            raise CommandExecutionError(
                "No input artifacts provided. Supply --elf/--map/--linker or a config file.",
                ExitCode.INPUT_OR_PARSING_ERROR,
            )
        self._require_eula("analyze")

        pipeline = self._run_analysis_pipeline(
            config=config,
            artifacts=artifacts,
            baseline_json_path=params.baseline_json,
        )
        parsed = pipeline.parsed
        normalized = pipeline.normalized
        analysis_report = pipeline.analysis_report
        policy_result = pipeline.policy_result
        counts = self._count_diagnostics(parsed)

        resolved_report_paths = self._resolve_report_outputs(config)
        try:
            rendered_report_paths, json_payload = self._emit_report_outputs(
                report=analysis_report,
                artifacts=artifacts,
                baseline_json_path=params.baseline_json,
                output_paths=resolved_report_paths,
            )
        except OSError as exc:
            raise CommandExecutionError(
                f"Failed writing report outputs: {exc}",
                ExitCode.INPUT_OR_PARSING_ERROR,
            ) from exc

        if self.options.strict and counts["error"] > 0:
            raise CommandExecutionError(
                f"Analyze failed in strict mode due to {counts['error']} parser error(s).",
                ExitCode.INPUT_OR_PARSING_ERROR,
            )
        if self.options.strict and policy_result.blocking:
            raise CommandExecutionError(
                (
                    "Analyze failed in strict mode due to blocking policy issues: "
                    f"{', '.join(policy_result.blocking_issue_ids)}"
                ),
                ExitCode.POLICY_FAILURE,
            )

        return CommandResult(
            message=(
                render_console_summary(
                    analysis_report,
                    blocking=policy_result.blocking,
                    output_paths=rendered_report_paths,
                    suppress_renewal_reminder=self.options.no_renewal_reminder,
                )
                + "\n"
                + (
                    "Parser diagnostics: "
                    f"info={counts['info']} warning={counts['warning']} error={counts['error']}"
                )
            ),
            payload={
                "artifact_set": artifacts,
                "report_paths": rendered_report_paths,
                "parser": {
                    "toolchain_detected": parsed.toolchain_detected.value,
                    "assumptions": list(parsed.assumptions),
                    "unresolved_ambiguities": list(parsed.unresolved_ambiguities),
                    "diagnostics": counts,
                },
                "normalized": {
                    "toolchain": normalized.toolchain.value,
                    "regions": len(normalized.memory_regions),
                    "sections": len(normalized.sections),
                    "symbols": len(normalized.symbols),
                    "stack_heap_hints": {
                        key: list(values) for key, values in normalized.stack_heap_hints.items()
                    },
                    "parse_assumptions": list(normalized.parse_assumptions),
                    "unresolved_ambiguities": list(normalized.unresolved_ambiguities),
                },
                "analysis": {
                    "summary": {
                        "total_flash": analysis_report.summary.total_flash,
                        "total_ram": analysis_report.summary.total_ram,
                        "issue_counts": dict(analysis_report.summary.issue_counts),
                    },
                    "timings": dict(sorted(pipeline.timings.items())),
                    "policy": policy_result.to_debug_dict(),
                    "report": json_payload,
                    "report_domain": to_json_dict(analysis_report),
                },
            },
        )

    def validate(self, params: ValidateInputs) -> CommandResult:
        # `validate` is intentionally available in Free Edition: it is a
        # JSON-schema sanity check on the parser output, not a CI-gating
        # tool. Keeping it free is the wedge that gets MemScope into a
        # team's pipeline at all; once it's wired in, upgrading to
        # `analyze --strict` is a one-line change.
        self._require_eula("validate")
        params = ValidateInputs(
            elf=self._resolve_path(params.elf),
            map_file=self._resolve_path(params.map_file),
            linker=self._resolve_path(params.linker),
        )
        overrides = self._build_cli_overrides_for_validate(params)
        config = self._load_config_with_overrides(overrides)
        artifacts = self._artifact_set_from_config(config)

        if not any((artifacts.elf_path, artifacts.map_path, artifacts.linker_path)):
            raise CommandExecutionError(
                "Validation failed: no discoverable artifacts.",
                ExitCode.INPUT_OR_PARSING_ERROR,
            )

        parsed = parse_artifact_set(artifacts, explicit_toolchain=self.options.toolchain)
        normalized = normalize_parsed_artifacts(parsed)
        counts = self._count_diagnostics(parsed)
        if counts["error"] > 0:
            raise CommandExecutionError(
                f"Validation failed: parser reported {counts['error']} error(s).",
                ExitCode.INPUT_OR_PARSING_ERROR,
            )

        return CommandResult(
            message=(
                "Validation skeleton completed: configuration, artifact discovery, and parser compatibility are valid. "
                f"diagnostics(info={counts['info']}, warning={counts['warning']}, error={counts['error']})"
            ),
            payload={
                "artifact_set": artifacts,
                "parser": {
                    "toolchain_detected": parsed.toolchain_detected.value,
                    "assumptions": list(parsed.assumptions),
                    "unresolved_ambiguities": list(parsed.unresolved_ambiguities),
                    "diagnostics": counts,
                },
                "normalized": {
                    "toolchain": normalized.toolchain.value,
                    "regions": len(normalized.memory_regions),
                    "sections": len(normalized.sections),
                    "symbols": len(normalized.symbols),
                    "stack_heap_hints": {
                        key: list(values) for key, values in normalized.stack_heap_hints.items()
                    },
                    "parse_assumptions": list(normalized.parse_assumptions),
                    "unresolved_ambiguities": list(normalized.unresolved_ambiguities),
                },
                "telemetry": build_telemetry_sink(config.telemetry).status_dict(),
            },
        )

    def diff(
        self,
        *,
        current_json: Path,
        baseline_json: Path,
        output_json: Path | None = None,
        output_html: Path | None = None,
    ) -> CommandResult:
        current_json = self._resolve_path(current_json)  # type: ignore[assignment]
        baseline_json = self._resolve_path(baseline_json)  # type: ignore[assignment]
        output_json = self._resolve_path(output_json)
        output_html = self._resolve_path(output_html)

        self._require_eula("diff")

        self._must_exist(current_json, "--current-json")
        self._must_exist(baseline_json, "--baseline-json")

        diff_report = compare_report_files(current_json, baseline_json)
        diff_payload = diff_report.to_dict()

        if diff_report.status in {"current_unreadable", "current_invalid"}:
            raise CommandExecutionError(
                f"Diff failed: {diff_report.schema_error or 'current report could not be loaded'}",
                ExitCode.INPUT_OR_PARSING_ERROR,
            )

        output_paths = {
            "json": str(output_json) if output_json else None,
            "html": str(output_html) if output_html else None,
        }

        if output_json is not None:
            ensure_parent_dir(output_json)
            output_json.write_text(json.dumps(diff_payload, indent=2, sort_keys=True), encoding="utf-8")

        if output_html is not None:
            ensure_parent_dir(output_html)
            output_html.write_text(
                render_diff_html(diff_payload),
                encoding="utf-8",
            )

        return CommandResult(
            message=render_diff_console_summary(
                diff_payload,
                output_paths=output_paths,
            ),
            payload={
                "current_json": str(current_json),
                "baseline_json": str(baseline_json),
                "output_json": str(output_json) if output_json else None,
                "output_html": str(output_html) if output_html else None,
                "diff": diff_payload,
            },
        )

    def diagnostics_export(self, output_path: Path | None = None) -> CommandResult:
        resolved = self._resolve_path(output_path or Path("diagnostics.zip"))
        if resolved is None:
            raise CommandExecutionError(
                "Diagnostics output path could not be resolved.",
                ExitCode.INPUT_OR_PARSING_ERROR,
            )
        errors: list[str] = []

        config: MemscopeConfig | None = None
        artifacts: BuildArtifactSet | None = None
        parser_payload: dict[str, object] | None = None
        timings: dict[str, float] | None = None
        report: AnalysisReport | None = None

        try:
            config = load_config(self.options.config_path, cli_overrides={})
        except (ConfigValidationError, FileNotFoundError, ValueError) as exc:
            errors.append(f"config_load_error: {exc}")

        if config is not None:
            try:
                artifacts = self._artifact_set_from_config(config)
                if any((artifacts.elf_path, artifacts.map_path, artifacts.linker_path)):
                    pipeline = self._run_analysis_pipeline(
                        config=config,
                        artifacts=artifacts,
                        baseline_json_path=None,
                    )
                    parser_counts = self._count_diagnostics(pipeline.parsed)
                    parser_payload = {
                        "toolchain_detected": pipeline.parsed.toolchain_detected.value,
                        "diagnostics": parser_counts,
                        "assumptions": list(pipeline.parsed.assumptions),
                        "unresolved_ambiguities": list(pipeline.parsed.unresolved_ambiguities),
                    }
                    timings = pipeline.timings
                    report = pipeline.analysis_report
            except CommandExecutionError as exc:
                errors.append(f"analysis_for_diagnostics_error: {exc.message}")

        bundle_payload = export_diagnostics_bundle(
            resolved,
            tool_version=__version__,
            log_level=self.options.log_level,
            strict=self.options.strict,
            config=config,
            artifacts=artifacts,
            parser_payload=parser_payload,
            timings=timings,
            report=report,
            errors=errors,
        )

        return CommandResult(
            message=f"Diagnostics export completed: {resolved}",
            payload=bundle_payload,
        )

    def _run_pipeline_from_current_config(self) -> tuple[MemscopeConfig, BuildArtifactSet, AnalysisPipelineResult]:
        config = self._load_config_with_overrides({})
        artifacts = self._artifact_set_from_config(config)
        if not any((artifacts.elf_path, artifacts.map_path, artifacts.linker_path)):
            raise CommandExecutionError(
                "Developer inspect requires input artifacts from config.",
                ExitCode.INPUT_OR_PARSING_ERROR,
            )
        pipeline = self._run_analysis_pipeline(
            config=config,
            artifacts=artifacts,
            baseline_json_path=None,
        )
        return config, artifacts, pipeline

    def dev_inspect(self, topic: str, output_path: Path | None = None) -> CommandResult:
        allowed_topics = {"parse", "model", "timings", "rules"}
        normalized_topic = topic.strip().lower()
        if normalized_topic not in allowed_topics:
            raise CommandExecutionError(
                f"Unknown inspect topic: {topic}. Expected one of: {', '.join(sorted(allowed_topics))}.",
                ExitCode.INPUT_OR_PARSING_ERROR,
            )
        if normalized_topic == "parse":
            raise CommandExecutionError(
                "Use 'dev inspect parse' subcommand directly.",
                ExitCode.INPUT_OR_PARSING_ERROR,
            )

        _config, artifacts, pipeline = self._run_pipeline_from_current_config()
        payload: dict[str, object]
        if normalized_topic == "model":
            payload = {
                "artifacts": {
                    "elf": str(artifacts.elf_path) if artifacts.elf_path else None,
                    "map": str(artifacts.map_path) if artifacts.map_path else None,
                    "linker": str(artifacts.linker_path) if artifacts.linker_path else None,
                },
                "normalized": pipeline.normalized.to_debug_dict(),
                "report_summary": {
                    "total_flash": pipeline.analysis_report.summary.total_flash,
                    "total_ram": pipeline.analysis_report.summary.total_ram,
                    "issue_counts": dict(pipeline.analysis_report.summary.issue_counts),
                },
            }
        elif normalized_topic == "timings":
            payload = {
                "timings_seconds": dict(sorted(pipeline.timings.items())),
                "stages": [
                    "parse_seconds",
                    "normalize_seconds",
                    "analysis_seconds",
                    "policy_seconds",
                    "diff_seconds",
                    "total_seconds",
                ],
            }
        else:
            payload = {
                "policy": pipeline.policy_result.to_debug_dict(),
                "issue_ids": [issue.id for issue in pipeline.analysis_report.issues],
                "rule_trace": pipeline.policy_result.to_debug_dict().get("rule_trace", []),
            }

        resolved = self._resolve_path(output_path)
        if resolved is not None:
            self._write_json(resolved, payload)
        return CommandResult(
            message=f"Developer inspect completed for '{normalized_topic}'.",
            payload={"topic": normalized_topic, "output_path": str(resolved) if resolved else None, **payload},
        )

    def inspect_parse(self, params: ValidateInputs, output_path: Path | None = None) -> CommandResult:
        params = ValidateInputs(
            elf=self._resolve_path(params.elf),
            map_file=self._resolve_path(params.map_file),
            linker=self._resolve_path(params.linker),
        )
        overrides = self._build_cli_overrides_for_validate(params)
        config = self._load_config_with_overrides(overrides)
        artifacts = self._artifact_set_from_config(config)
        parse_started = perf_counter()
        parsed = parse_artifact_set(artifacts, explicit_toolchain=self.options.toolchain)
        parse_seconds = perf_counter() - parse_started

        normalize_started = perf_counter()
        normalized = normalize_parsed_artifacts(parsed)
        normalize_seconds = perf_counter() - normalize_started
        counts = self._count_diagnostics(parsed)

        payload = {
            "parsed": parsed.to_debug_dict(),
            "normalized": normalized.to_debug_dict(),
            "timings_seconds": {
                "parse_seconds": parse_seconds,
                "normalize_seconds": normalize_seconds,
            },
        }
        resolved_output = self._resolve_path(output_path)
        if resolved_output is not None:
            self._write_json(resolved_output, payload)

        return CommandResult(
            message=(
                "Developer parse inspect completed. "
                f"diagnostics(info={counts['info']}, warning={counts['warning']}, error={counts['error']})"
            ),
            payload={
                "topic": "parse",
                "output_path": str(resolved_output) if resolved_output else None,
                "parser": payload,
            },
        )
