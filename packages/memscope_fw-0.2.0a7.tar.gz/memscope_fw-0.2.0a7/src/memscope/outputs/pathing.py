"""Path resolution helpers for output artifacts."""

from __future__ import annotations

from pathlib import Path


def resolve_report_path(value: str | None, *, config_source_path: Path | None = None) -> Path | None:
    """Resolve a report output path from config/CLI value.

    Relative paths are resolved against the config file directory when available,
    otherwise against the current working directory.
    """
    if value is None:
        return None

    candidate = Path(value).expanduser()
    if not candidate.is_absolute():
        base = config_source_path.parent if config_source_path is not None else Path.cwd()
        candidate = base / candidate
    return candidate.resolve()


def ensure_parent_dir(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

