"""Diagnostics bundle export utilities."""

from __future__ import annotations

import json
import platform
import re
import zipfile
from collections.abc import Mapping
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from memscope.config import MemscopeConfig
from memscope.domain import AnalysisReport, BuildArtifactSet
from memscope.domain.serialization import to_json_dict
from memscope.outputs.pathing import ensure_parent_dir

_WINDOWS_ABS_PATH_PATTERN = re.compile(r"(?P<path>[a-zA-Z]:\\(?:[^\\/:*?\"<>|\r\n]+\\)*[^\\/:*?\"<>|\r\n]+)")
_UNC_PATH_PATTERN = re.compile(r"(?P<path>(?:\\\\|//)[^\s]+)")
_POSIX_ABS_PATH_PATTERN = re.compile(r"(?P<path>(?<![a-zA-Z0-9+.-]:)/(?:[^\s/]+/)*[^\s/]+)")


def export_diagnostics_bundle(
    output_path: Path,
    *,
    tool_version: str,
    log_level: str,
    strict: bool,
    config: MemscopeConfig | None = None,
    artifacts: BuildArtifactSet | None = None,
    parser_payload: Mapping[str, object] | None = None,
    timings: Mapping[str, float] | None = None,
    report: AnalysisReport | None = None,
    errors: list[str] | None = None,
) -> dict[str, object]:
    """Generate diagnostics ZIP with sanitized content."""
    ensure_parent_dir(output_path)

    manifest = {
        "generated_at": datetime.now(UTC).isoformat(),
        "tool_version": tool_version,
        "log_level": log_level,
        "strict": strict,
        "entries": [
            "manifest.json",
            "environment.json",
            "config_snapshot.json",
            "input_metadata.json",
            "parser_diagnostics.json",
            "analysis_timing.json",
            "report_summary.json",
            "errors.json",
        ],
    }

    environment = {
        "platform": platform.platform(),
        "system": platform.system(),
        "release": platform.release(),
        "version": platform.version(),
        "machine": platform.machine(),
        "python_version": platform.python_version(),
    }

    config_snapshot: dict[str, object] = {"status": "not_available"}
    if config is not None:
        config_snapshot = {"status": "ok", "config": _sanitize_obj(to_json_dict(config))}

    input_metadata: dict[str, object] = {"status": "not_available"}
    if artifacts is not None:
        input_metadata = {
            "status": "ok",
            "target_name": artifacts.target_name,
            "toolchain_hint": artifacts.toolchain_hint,
            "elf_path": _sanitize_path(artifacts.elf_path),
            "map_path": _sanitize_path(artifacts.map_path),
            "linker_path": _sanitize_path(artifacts.linker_path),
        }

    parser_diagnostics: dict[str, object] = {"status": "not_available"}
    if parser_payload is not None:
        parser_diagnostics = {"status": "ok", "payload": _sanitize_obj(dict(parser_payload))}

    analysis_timing = {
        "status": "ok" if timings else "not_available",
        "timings_seconds": dict(sorted((timings or {}).items())),
    }

    report_summary: dict[str, object] = {"status": "not_available"}
    if report is not None:
        report_summary = {
            "status": "ok",
            "target_name": report.metadata.target_name,
            "toolchain_detected": report.metadata.toolchain_detected,
            "issue_counts": dict(report.summary.issue_counts),
            "total_flash": report.summary.total_flash,
            "total_ram": report.summary.total_ram,
            "regressions_status": report.regressions.get("status"),
        }

    error_payload = {"errors": _sanitize_obj(list(errors or []))}

    with zipfile.ZipFile(output_path, mode="w", compression=zipfile.ZIP_DEFLATED) as archive:
        _write_zip_json(archive, "manifest.json", manifest)
        _write_zip_json(archive, "environment.json", environment)
        _write_zip_json(archive, "config_snapshot.json", config_snapshot)
        _write_zip_json(archive, "input_metadata.json", input_metadata)
        _write_zip_json(archive, "parser_diagnostics.json", parser_diagnostics)
        _write_zip_json(archive, "analysis_timing.json", analysis_timing)
        _write_zip_json(archive, "report_summary.json", report_summary)
        _write_zip_json(archive, "errors.json", error_payload)

    return {"output_path": str(output_path), "entries": manifest["entries"]}


def _write_zip_json(archive: zipfile.ZipFile, name: str, payload: Mapping[str, object]) -> None:
    archive.writestr(name, json.dumps(payload, indent=2, sort_keys=True))


def _sanitize_path(path: Path | None) -> str | None:
    if path is None:
        return None

    path = path.resolve()
    home = Path.home().resolve()
    cwd = Path.cwd().resolve()

    try:
        relative_home = path.relative_to(home)
        return f"~/{relative_home.as_posix()}"
    except ValueError:
        pass

    try:
        relative_cwd = path.relative_to(cwd)
        return f"$WORKDIR/{relative_cwd.as_posix()}"
    except ValueError:
        pass

    return f"<abs>/{path.name}"


def _sanitize_obj(value: Any) -> Any:
    if isinstance(value, dict):
        sanitized: dict[str, object] = {}
        for key, child in value.items():
            normalized_key = str(key)
            if _is_sensitive_key(normalized_key):
                sanitized[normalized_key] = "<redacted>"
            elif normalized_key.lower().endswith("_path") and isinstance(child, str):
                sanitized[normalized_key] = _sanitize_string(child)
            else:
                sanitized[normalized_key] = _sanitize_obj(child)
        return sanitized
    if isinstance(value, list):
        return [_sanitize_obj(child) for child in value]
    if isinstance(value, tuple):
        return [_sanitize_obj(child) for child in value]
    if isinstance(value, str):
        return _sanitize_string(value)
    return value


def _sanitize_string(value: str) -> str:
    normalized = value.strip()
    if not normalized:
        return value

    # Avoid leaking absolute or workspace-sensitive path details when they appear in free-form strings.
    try:
        path_candidate = Path(normalized)
        if path_candidate.is_absolute() or normalized.startswith("\\\\") or normalized.startswith("//"):
            sanitized = _sanitize_path(path_candidate)
            if sanitized is not None:
                return sanitized
    except (OSError, ValueError):
        pass

    sanitized = value
    for pattern in (_WINDOWS_ABS_PATH_PATTERN, _UNC_PATH_PATTERN, _POSIX_ABS_PATH_PATTERN):
        sanitized = pattern.sub(_replace_path_match, sanitized)
    return sanitized


def _replace_path_match(match: re.Match[str]) -> str:
    raw_path = match.group("path")
    try:
        sanitized = _sanitize_path(Path(raw_path))
    except (OSError, ValueError):
        return raw_path
    return sanitized if sanitized is not None else raw_path


def _is_sensitive_key(key: str) -> bool:
    lowered = key.lower()
    if lowered in {"license_id", "state", "mode", "source"}:
        return False
    sensitive_hints = (
        "token",
        "secret",
        "password",
        "activation_key",
        "license_key",
        "machine_fingerprint",
        "install_id",
        "signature",
    )
    return any(hint in lowered for hint in sensitive_hints)
