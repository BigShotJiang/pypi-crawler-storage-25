"""JSON report renderer with stable v1 schema payload."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from memscope.domain import AnalysisReport, BuildArtifactSet
from memscope.domain.serialization import JSONValue, to_json_dict
from memscope.outputs.pathing import ensure_parent_dir


def build_json_payload(
    report: AnalysisReport,
    *,
    artifacts: BuildArtifactSet | None = None,
    baseline_json_path: Path | None = None,
) -> dict[str, JSONValue]:
    """Build a stable JSON payload from one analysis report."""
    sorted_report = report.sorted_copy()
    metadata = to_json_dict(sorted_report.metadata)
    summary = to_json_dict(sorted_report.summary)

    payload: dict[str, JSONValue] = {
        "metadata": metadata,
        "inputs": {
            "elf_path": str(artifacts.elf_path) if artifacts and artifacts.elf_path else None,
            "map_path": str(artifacts.map_path) if artifacts and artifacts.map_path else None,
            "linker_path": str(artifacts.linker_path) if artifacts and artifacts.linker_path else None,
            "target_name": artifacts.target_name if artifacts else None,
            "toolchain_hint": artifacts.toolchain_hint if artifacts else None,
            "baseline_json": str(baseline_json_path) if baseline_json_path else None,
        },
        "summary": summary,
        "regions": [to_json_dict(region) for region in sorted_report.regions],
        "sections": [to_json_dict(section) for section in sorted_report.sections],
        "symbols_summary": {
            "total_symbols": len(sorted_report.symbols),
            "total_symbol_bytes": sum(symbol.size for symbol in sorted_report.symbols),
            "top_symbols_by_size": _as_list(sorted_report.trends.get("top_symbols_by_size")),
            "top_objects_by_size": _as_list(sorted_report.trends.get("top_objects_by_size")),
            "symbols": [to_json_dict(symbol) for symbol in sorted_report.symbols],
        },
        "components": [to_json_dict(component) for component in sorted_report.components],
        "issues": [to_json_dict(issue) for issue in sorted_report.issues],
        "visualization": _as_dict(sorted_report.trends.get("visualization")),
        "diff": _as_dict(sorted_report.regressions),
        "diagnostics": _as_dict(sorted_report.diagnostics),
    }
    return payload


def render_json_report(
    report: AnalysisReport,
    *,
    artifacts: BuildArtifactSet | None = None,
    baseline_json_path: Path | None = None,
    indent: int = 2,
) -> str:
    payload = build_json_payload(
        report,
        artifacts=artifacts,
        baseline_json_path=baseline_json_path,
    )
    return json.dumps(payload, indent=indent, sort_keys=True)


def write_json_report(
    path: Path,
    report: AnalysisReport,
    *,
    artifacts: BuildArtifactSet | None = None,
    baseline_json_path: Path | None = None,
    indent: int = 2,
) -> dict[str, JSONValue]:
    payload = build_json_payload(
        report,
        artifacts=artifacts,
        baseline_json_path=baseline_json_path,
    )
    ensure_parent_dir(path)
    path.write_text(json.dumps(payload, indent=indent, sort_keys=True), encoding="utf-8")
    return payload


def _as_dict(value: object) -> dict[str, Any]:
    if isinstance(value, dict):
        return dict(sorted((str(key), child) for key, child in value.items()))
    return {}


def _as_list(value: object) -> list[Any]:
    if isinstance(value, list):
        return value
    return []
