(function (global) {
  "use strict";

  var runtime = global.MemScopeRuntime || {};
  runtime.version = "0.8.1-xfilter";
  runtime.renderers = runtime.renderers || {};
  var LAYOUT_LANE_WIDTH_RATIO = 0.92;
  var LAYOUT_LABEL_GUTTER_MIN_PX = 104;
  var LAYOUT_LABEL_GUTTER_MAX_PX = 156;
  var LAYOUT_LABEL_GUTTER_RATIO = 0.14;
  var EXPLORER_VIEWPORT_HEIGHT_RATIO = 0.72;
  var EXPLORER_VIEWPORT_MIN_HEIGHT_PX = 480;
  var EXPLORER_VIEWPORT_MAX_HEIGHT_PX = 980;
  var EXPLORER_MAX_ZOOM = 10000;
  var REGION_BAND_GAP_PX = 30;
  var FOCUS_TOP_OFFSET_PX = 34;
  var BOUNDARY_LABEL_MIN_GAP_PX = 5;
  var BOUNDARY_LABEL_Y_PADDING_PX = 10;

  var KIND_ORDER = {
    free: 1,
    padding: 2,
    reserved: 3,
    protected: 4,
    section: 5,
    heap: 6,
    stack: 7,
  };

  function cssVar(name, fallback) {
    var value = global.getComputedStyle(document.body).getPropertyValue(name).trim();
    return value || fallback;
  }

  // Single shared help popover, attached to document.body so it escapes any
  // ancestor's overflow / stacking context. Triggers off of [data-help] on
  // any element. Hides on click / Escape / scroll so it doesn't linger after
  // the user activates a button.
  var _helpPopover = null;
  function ensureHelpPopover() {
    if (_helpPopover) return _helpPopover;
    var pop = document.createElement("div");
    pop.id = "ms-help-popover";
    pop.className = "ms-help-popover";
    pop.setAttribute("role", "tooltip");
    pop.setAttribute("aria-hidden", "true");
    document.body.appendChild(pop);
    _helpPopover = pop;
    return pop;
  }
  function showHelpPopover(target, text) {
    var pop = ensureHelpPopover();
    pop.textContent = text;
    pop.classList.add("is-visible");
    pop.setAttribute("aria-hidden", "false");
    var rect = target.getBoundingClientRect();
    var pw = pop.offsetWidth;
    var ph = pop.offsetHeight;
    var vw = global.innerWidth || document.documentElement.clientWidth;
    var vh = global.innerHeight || document.documentElement.clientHeight;
    var x = rect.left + rect.width / 2 - pw / 2;
    if (x < 8) x = 8;
    if (x + pw > vw - 8) x = vw - pw - 8;
    var y = rect.bottom + 10;
    if (y + ph > vh - 8) {
      // Flip above the target if there's no room below.
      y = rect.top - ph - 10;
      if (y < 8) y = 8;
    }
    pop.style.left = x + "px";
    pop.style.top = y + "px";
  }
  function hideHelpPopover() {
    if (!_helpPopover) return;
    _helpPopover.classList.remove("is-visible");
    _helpPopover.setAttribute("aria-hidden", "true");
  }
  function bindHelpPopovers(rootEl) {
    if (!rootEl || rootEl._helpBound) return;
    rootEl._helpBound = true;
    ensureHelpPopover();
    rootEl.addEventListener("mouseover", function (e) {
      var t = e.target && e.target.closest && e.target.closest("[data-help]");
      if (!t) return;
      showHelpPopover(t, t.getAttribute("data-help") || "");
    });
    rootEl.addEventListener("mouseout", function (e) {
      var t = e.target && e.target.closest && e.target.closest("[data-help]");
      if (!t) return;
      if (e.relatedTarget && t.contains(e.relatedTarget)) return;
      hideHelpPopover();
    });
    rootEl.addEventListener("focusin", function (e) {
      var t = e.target && e.target.closest && e.target.closest("[data-help]");
      if (t) showHelpPopover(t, t.getAttribute("data-help") || "");
    });
    rootEl.addEventListener("focusout", hideHelpPopover);
    rootEl.addEventListener("click", function (e) {
      var t = e.target && e.target.closest && e.target.closest("[data-help]");
      if (t && t.blur) t.blur();
      hideHelpPopover();
    });
  }
  if (typeof document !== "undefined") {
    document.addEventListener("scroll", hideHelpPopover, true);
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") hideHelpPopover();
    });
  }

  var _kindColorCache = null;

  function invalidateColorCache() {
    _kindColorCache = null;
  }

  function colorForKind(kind) {
    if (!_kindColorCache) {
      // Note: --ok and --chart-4 resolve to the SAME hex (#61c98f) in both
      // light and dark themes, which made stack and heap visually
      // indistinguishable. Hardcode heap to a teal so the two dynamic-memory
      // categories read as distinct on the layout map and minimap.
      _kindColorCache = {
        section: cssVar("--chart-1", "#4f8cff"),
        free: cssVar("--line", "#35506e"),
        padding: cssVar("--warning", "#f0b45a"),
        stack: cssVar("--ok", "#61c98f"),
        heap: "#1aa39b",
        reserved: cssVar("--error", "#ec6d86"),
        protected: cssVar("--chart-5", "#7ea4ff"),
      };
    }
    return _kindColorCache[kind] || cssVar("--accent", "#4f8cff");
  }

  function safeText(value) {
    if (value === null || value === undefined) {
      return "";
    }
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function formatAddress(value) {
    var number = Number(value || 0);
    if (!Number.isFinite(number)) {
      return "0x0";
    }
    return "0x" + Math.max(0, Math.floor(number)).toString(16).toUpperCase();
  }

  function formatBytes(value) {
    var bytes = Number(value || 0);
    if (!Number.isFinite(bytes)) {
      bytes = 0;
    }
    return Math.max(0, Math.floor(bytes)).toLocaleString("en-US") + " B";
  }

  function formatSignedBytes(value) {
    var bytes = Number(value || 0);
    if (!Number.isFinite(bytes)) {
      bytes = 0;
    }
    var normalized = Math.trunc(bytes);
    var sign = normalized > 0 ? "+" : "";
    return sign + normalized.toLocaleString("en-US") + " B";
  }

  function formatKiB(value) {
    var bytes = Number(value || 0);
    if (!Number.isFinite(bytes)) {
      bytes = 0;
    }
    return (bytes / 1024).toFixed(2) + " KiB";
  }

  function toArray(value) {
    return Array.isArray(value) ? value : [];
  }

  function normalizeText(value) {
    return String(value === null || value === undefined ? "" : value).trim();
  }

  function normalizeTextLower(value) {
    return normalizeText(value).toLowerCase();
  }

  function readFilters(options) {
    if (!options || typeof options !== "object") {
      return {};
    }
    var getFilters = options.getFilters;
    if (typeof getFilters !== "function") {
      return {};
    }
    var raw = getFilters();
    if (!raw || typeof raw !== "object") {
      return {};
    }
    return {
      region: normalizeText(raw.region),
      component: normalizeText(raw.component),
      section_query: normalizeText(raw.section_query || raw.sectionQuery),
      issue_query: normalizeText(raw.issue_query || raw.issueQuery),
      issue_severity: normalizeText(raw.issue_severity || raw.issueSeverity),
    };
  }

  function emitSelect(options, payload) {
    if (!options || typeof options !== "object") {
      return;
    }
    var callback = options.onSelect;
    if (typeof callback !== "function") {
      return;
    }
    try {
      callback(payload || {});
    } catch (_error) {
      // Swallow callback errors to avoid breaking report interaction.
    }
  }

  function stripPrefix(value, prefix) {
    var text = normalizeText(value);
    var tag = normalizeText(prefix);
    if (!tag || text.indexOf(tag) !== 0) {
      return text;
    }
    return text.slice(tag.length);
  }

  function resolveLaneGeometry(totalWidth, margin) {
    var availableWidth = Math.max(64, Number(totalWidth || 0) - Number(margin.left || 0) - Number(margin.right || 0));
    var suggestedLabelGutter = Math.floor(availableWidth * LAYOUT_LABEL_GUTTER_RATIO);
    var labelGutter = Math.max(
      LAYOUT_LABEL_GUTTER_MIN_PX,
      Math.min(LAYOUT_LABEL_GUTTER_MAX_PX, suggestedLabelGutter),
    );
    var drawableWidth = Math.max(64, availableWidth - labelGutter);
    var laneWidth = Math.max(64, Math.floor(drawableWidth * LAYOUT_LANE_WIDTH_RATIO));
    if (laneWidth > drawableWidth) {
      laneWidth = drawableWidth;
    }
    var laneX = Number(margin.left || 0) + Math.max(0, Math.floor((drawableWidth - laneWidth) / 2));
    var labelX = Math.max(laneX + laneWidth + 8, Number(margin.left || 0) + drawableWidth + 10);
    return {
      laneX: laneX,
      laneWidth: laneWidth,
      labelX: labelX,
      labelGutter: labelGutter,
      drawableWidth: drawableWidth,
    };
  }

  function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
  }

  function resolvePreferredRegionHeight(region) {
    var hints = region && region.render_hints && typeof region.render_hints === "object"
      ? region.render_hints
      : {};
    var minHeight = Math.max(180, Number(hints.min_height_px || 180));
    var preferredFromHints = Number(hints.preferred_height_px || 0);
    if (Number.isFinite(preferredFromHints) && preferredFromHints > 0) {
      return Math.floor(clamp(preferredFromHints, minHeight, 760));
    }
    var rangeCount = Number(region && (region.range_count || toArray(region.ranges).length) || 0);
    var densityScore = Number(region && region.density_score || 0);
    if (!Number.isFinite(densityScore)) {
      densityScore = 0;
    }
    var rangeBonus = clamp((rangeCount - 40) * 1.2, 0, 360);
    var densityBonus = clamp((densityScore - 1.0) * 140, 0, 220);
    return Math.floor(clamp(220 + rangeBonus + densityBonus, minHeight, 760));
  }

  function fallbackCard(container, text) {
    if (!container) {
      return;
    }
    container.innerHTML = "";
    var card = document.createElement("div");
    card.className = "ms-layout-empty";
    card.textContent = text;
    container.appendChild(card);
  }

  function ownerSummary(range) {
    var owners = range && range.owners && typeof range.owners === "object" ? range.owners : {};
    var objects = toArray(owners.objects);
    var archives = toArray(owners.archives);
    var sources = toArray(owners.sources);
    return {
      object: objects.length ? String(objects[0]) : "unknown",
      archive: archives.length ? String(archives[0]) : "unknown",
      source: sources.length ? String(sources[0]) : "unknown",
    };
  }

  function buildLodRanges(region, yScale) {
    var ranges = toArray(region && region.ranges).slice();
    ranges.sort(function (left, right) {
      return Number(left.start_address || 0) - Number(right.start_address || 0);
    });

    var lod = [];
    var bucket = null;

    function flushBucket() {
      if (!bucket) {
        return;
      }
      lod.push({
        id: bucket.id,
        kind: bucket.kind,
        role: bucket.role || null,
        label: bucket.kind + " (aggregated)",
        section_name: null,
        execution_region: region.name,
        load_region: null,
        start_address: bucket.start_address,
        end_address: bucket.end_address,
        size_bytes: bucket.size_bytes,
        size_kib: bucket.size_bytes / 1024,
        utilization_ratio_in_region: region.size_bytes > 0 ? bucket.size_bytes / region.size_bytes : 0,
        owners: { objects: [], archives: [], sources: [] },
        top_symbols: [],
        policy_issue_ids: bucket.policy_issue_ids,
        baseline_delta_bytes: null,
        panel: {
          section: {
            name: bucket.kind + " (aggregated)",
            execution_region: region.name,
            load_region: null,
            vma: bucket.start_address,
            lma: null,
            size_bytes: bucket.size_bytes,
            padding_before: 0,
            padding_after: 0,
          },
          symbol_breakdown: [],
          owners: { objects: [], archives: [], sources: [] },
          baseline: { delta_bytes: null, status: "unknown" },
          policy: {
            issue_ids: bucket.policy_issue_ids,
            violations_count: bucket.policy_issue_ids.length,
          },
        },
        is_synthetic: true,
        lod_group_key: bucket.id,
        is_lod_aggregate: true,
      });
      bucket = null;
    }

    for (var index = 0; index < ranges.length; index += 1) {
      var range = ranges[index];
      var start = Number(range.start_address || 0);
      var end = Number(range.end_address || start);
      if (end < start) {
        end = start;
      }
      var projectedHeight = Math.abs(yScale(end + 1) - yScale(start));
      var isSmall = projectedHeight < 1.5;
      var kind = String(range.kind || "section");

      if (isSmall) {
        var rangeRoleSmall = range && range.role ? String(range.role) : null;
        if (bucket && bucket.kind === kind && start <= bucket.end_address + 1) {
          bucket.end_address = Math.max(bucket.end_address, end);
          bucket.size_bytes += Math.max(0, Number(range.size_bytes || 0));
          if (bucket.role && bucket.role !== rangeRoleSmall) {
            bucket.role = null;
          }
          var policyIds = toArray(range.policy_issue_ids).map(String);
          policyIds.forEach(function (id) {
            if (bucket.policy_issue_ids.indexOf(id) < 0) {
              bucket.policy_issue_ids.push(id);
            }
          });
        } else {
          flushBucket();
          bucket = {
            id: region.name + ":lod:" + kind + ":" + start,
            kind: kind,
            role: rangeRoleSmall,
            start_address: start,
            end_address: end,
            size_bytes: Math.max(0, Number(range.size_bytes || 0)),
            policy_issue_ids: toArray(range.policy_issue_ids).map(String),
          };
        }
        continue;
      }

      flushBucket();
      var explicit = Object.assign({}, range);
      explicit.is_lod_aggregate = false;
      explicit.is_synthetic = Boolean(range.is_synthetic);
      explicit.lod_group_key = range.lod_group_key || null;
      lod.push(explicit);
    }

    flushBucket();
    lod.sort(function (left, right) {
      var leftOrder = KIND_ORDER[String(left.kind || "section")] || 99;
      var rightOrder = KIND_ORDER[String(right.kind || "section")] || 99;
      if (leftOrder !== rightOrder) {
        return leftOrder - rightOrder;
      }
      return Number(left.start_address || 0) - Number(right.start_address || 0);
    });
    return lod;
  }

  function LayoutExplorer(ctx) {
    this.ctx = ctx || {};
    this.payload = this.ctx.payload && typeof this.ctx.payload === "object" ? this.ctx.payload : {};
    this.options = this.ctx.options && typeof this.ctx.options === "object" ? this.ctx.options : {};
    this.container = document.getElementById(String(this.ctx.containerId || ""));
    this.minimapContainer = document.getElementById(String(this.ctx.minimapContainerId || ""));
    this.tooltip = document.getElementById(String(this.ctx.tooltipId || ""));
    this.panel = document.getElementById(String(this.ctx.panelId || ""));
    this.panelContent = document.getElementById(String(this.ctx.panelContentId || ""));
    this.panelClose = document.getElementById(String(this.ctx.panelCloseId || ""));
    this.panelBackdrop = document.getElementById(String(this.ctx.panelBackdropId || ""));
    this.policyIssueIndex = this.payload.policy_issue_index && typeof this.payload.policy_issue_index === "object"
      ? this.payload.policy_issue_index
      : {};
    this.onSelect = typeof this.options.onSelect === "function" ? this.options.onSelect : null;
    this.regions = [];
    this.regionLayouts = [];
    this.zoomTransform = global.d3 ? global.d3.zoomIdentity : null;
    this.composite = null;
    this.globalMinimap = null;
    this.focusIndex = 0;
    this.focusSelect = null;
    this.compositeCardNode = null;
    this.compositeBodyNode = null;
    this.hoveredRangeNode = null;
    this.regionGapPx = REGION_BAND_GAP_PX;
    this.resizeTimer = null;
    this.handleWindowResize = this.onWindowResize.bind(this);
    this.closePanelBound = this.closePanel.bind(this);
    this.handleDocumentPointerDownBound = this.handleDocumentPointerDown.bind(this);
    this.alignmentLens = false;
    this.paddingHeatmap = false;
    this.memoryRoles = false;
    this.pinnedRegions = [];
    this.compareStripNode = null;
    this.lensButtons = {};
    this.alignLegendEl = null;
    this.activeRegionName = "";
    this.activeRangeKey = "";
    // Also track the active range's address bounds so LOD aggregates
    // (which have their own bucket bounds, different from the source
    // range) can still be highlighted when they CONTAIN the selection.
    // Without this, jumping to a small section via Find leaves the LOD
    // bucket un-highlighted because its key doesn't match exactly.
    this.activeRangeStart = NaN;
    this.activeRangeEnd = NaN;
    this.regionAccessMap = {};
    this.handleSvgKeydownBound = this.handleSvgKeydown.bind(this);
  }

  function alignmentClass(value) {
    var n = Number(value || 0);
    if (!isFinite(n) || n <= 0) return "32";
    if ((n & 31) === 0) return "32";
    if ((n & 15) === 0) return "16";
    if ((n & 7) === 0) return "8";
    if ((n & 3) === 0) return "4";
    if ((n & 1) === 0) return "2";
    return "1";
  }

  function colorForAlignment(klass) {
    // Discrete 6-step ramp picked for max perceptual distance under both
    // light and dark themes. Hardcoded (not CSS vars) because the report's
    // chart-N tokens collide on green and don't read as "alignment classes"
    // visually. Order: high-alignment = cool/green (expensive but
    // structural), low-alignment = warm/red (suspicious — should be small).
    switch (klass) {
      case "32": return "#3eaf63";   // emerald — ≥32 B
      case "16": return "#1f9be8";   // azure — 16 B
      case "8":  return "#7c5cff";   // violet — 8 B
      case "4":  return "#f0b45a";   // amber — 4 B
      case "2":  return "#f0742f";   // orange — 2 B
      default:   return "#e84561";   // crimson — 1 B
    }
  }

  var ROLE_BADGE_TEXT = {
    bss: "BSS",
    data: "DATA",
    rodata: "RO",
    text: "CODE",
    heap: "HEAP",
    stack: "STACK",
    vectors: "VEC"
  };
  var ROLE_DESCRIPTIONS = {
    bss: "Zero-initialized globals (.bss / ZI)",
    data: "Initialized RAM data (load image copied at startup)",
    rodata: "Read-only / const data in flash",
    text: "Executable code (.text)",
    heap: "Dynamic allocator pool",
    stack: "Call stack",
    vectors: "Interrupt / reset vector table"
  };
  function colorForRole(role) {
    switch (role) {
      case "bss":     return cssVar("--chart-3", "#79d5ff");
      case "data":    return cssVar("--chart-2", "#22c1ff");
      case "rodata":  return cssVar("--chart-5", "#7ea4ff");
      case "text":    return cssVar("--ok", "#61c98f");
      case "heap":    return cssVar("--warning", "#f0b45a");
      case "stack":   return cssVar("--error", "#ec6d86");
      case "vectors": return cssVar("--accent-soft", "#8fd3ff");
      default:        return null;
    }
  }

  function regionMatchesFilters(region, filters) {
    if (!filters || !region) return true;
    if (filters.region && normalizeText(region.name || "") !== filters.region) return false;
    return true;
  }
  function rangeMatchesFilters(range, region, filters) {
    if (!filters) return true;
    if (!regionMatchesFilters(region, filters)) return false;
    var q = filters.section_query ? normalizeTextLower(filters.section_query) : "";
    if (q) {
      // The range payload doesn't have a `name` field — it has `label`,
      // `section_name`, and `kind`. The previous version only checked
      // `range.name`, which was always undefined, so EVERY range failed
      // the match (including the one the user just clicked) and
      // everything dimmed. Check the actual fields the contract emits.
      var text = (
        String((range && range.section_name) || "") + " " +
        String((range && range.label) || "") + " " +
        String((range && range.kind) || "")
      ).toLowerCase();
      if (text.indexOf(q) < 0) return false;
    }
    return true;
  }

  function regionPaddingRatio(region) {
    var total = Number(region && region.size_bytes || 0);
    if (!total) return 0;
    // Prefer the authoritative figure from the Python analysis pipeline
    // (`region.stats.padding_bytes`). This is what the summary card's
    // "Padding / Alignment Waste" total reflects — it includes BOTH
    // inline `padding_before/after` ranges AND inter-section gaps
    // (sections sorted by VMA; gaps between consecutive sections count).
    // Falls back to the legacy ranges-only sum if `stats.padding_bytes`
    // is absent (e.g. opening an old report saved before this field
    // was added).
    var stats = region && region.stats;
    if (stats && stats.padding_bytes != null) {
      var statsPad = Math.max(0, Number(stats.padding_bytes || 0));
      return Math.min(1, statsPad / total);
    }
    var ranges = toArray(region && region.ranges);
    var pad = 0;
    for (var i = 0; i < ranges.length; i++) {
      var r = ranges[i];
      if (!r) continue;
      var rk = String(r.kind);
      if (rk === "padding") {
        pad += Math.max(0, Number(r.size_bytes || 0));
      } else if (rk === "free" && r.is_inter_section_gap === true) {
        pad += Math.max(0, Number(r.size_bytes || 0));
      }
    }
    return Math.min(1, pad / total);
  }

  function regionStrictestAlignment(region) {
    // Return the strictest (largest power-of-two) alignment found among
    // section-range start addresses in this region. Padding/free ranges
    // are skipped — their alignment is a consequence, not a requirement.
    var ranges = toArray(region && region.ranges);
    var bestPow = 0;
    for (var i = 0; i < ranges.length; i++) {
      var r = ranges[i];
      if (!r) continue;
      var k = String(r.kind || "section");
      if (k !== "section") continue;
      var start = Number(r.start_address || 0);
      if (!isFinite(start) || start <= 0) continue;
      var p = 0;
      var v = start;
      while ((v & 1) === 0 && p < 16) {
        v = v >>> 1;
        p++;
      }
      if (p > bestPow) bestPow = p;
    }
    if (!bestPow) return null;
    var label;
    if (bestPow >= 10) label = "≥1 KB";
    else if (bestPow >= 5) label = "≥32 B";
    else if (bestPow === 4) label = "16 B";
    else if (bestPow === 3) label = "8 B";
    else if (bestPow === 2) label = "4 B";
    else if (bestPow === 1) label = "2 B";
    else label = "1 B";
    var klass;
    if (bestPow >= 5) klass = "32";
    else if (bestPow === 4) klass = "16";
    else if (bestPow === 3) klass = "8";
    else if (bestPow === 2) klass = "4";
    else if (bestPow === 1) klass = "2";
    else klass = "1";
    return { klass: klass, label: label };
  }

  function heatmapColor(ratio) {
    var clamped = Math.max(0, Math.min(1, Number(ratio || 0)));
    if (clamped < 0.04) return cssVar("--ok", "#61c98f");
    if (clamped < 0.10) return cssVar("--chart-3", "#79d5ff");
    if (clamped < 0.18) return cssVar("--warning", "#f0b45a");
    if (clamped < 0.28) return cssVar("--bar-warning-1", "#d09139");
    return cssVar("--error", "#ec6d86");
  }

  function activeRangeKey(range, region) {
    var start = Number(range && range.start_address || 0);
    var end = Number(range && range.end_address || start);
    return String(region && region.name || "") + "|" + String(range && range.kind || "section") + "|" +
      formatAddress(start) + "-" + formatAddress(end);
  }

  LayoutExplorer.prototype.init = function () {
    if (!this.container) {
      return;
    }
    if (!global.d3 || !global.d3.select || !global.d3.zoom || !global.d3.scaleLinear) {
      fallbackCard(this.container, "D3 runtime unavailable. Memory layout explorer could not start.");
      return;
    }

    var regions = toArray(this.payload.regions)
      .slice()
      .sort(function (left, right) {
        var byStart = Number(left.start_address || 0) - Number(right.start_address || 0);
        if (byStart !== 0) {
          return byStart;
        }
        var byEnd = Number(left.end_address || 0) - Number(right.end_address || 0);
        if (byEnd !== 0) {
          return byEnd;
        }
        return String(left.name || "").localeCompare(String(right.name || ""));
      });

    if (!regions.length) {
      fallbackCard(this.container, "No region geometry was produced for this report.");
      return;
    }

    this.container.innerHTML = "";
    if (this.minimapContainer) {
      this.minimapContainer.innerHTML = "";
    }

    var runtimeShell = document.createElement("div");
    runtimeShell.className = "ms-layout-runtime";

    var toolbar = document.createElement("div");
    toolbar.className = "ms-layout-toolbar";

    var toolbarMeta = document.createElement("div");
    toolbarMeta.className = "meta";
    toolbarMeta.textContent =
      "D3 " +
      String(global.d3.version || "unknown") +
      " | regions: " +
      String(regions.length) +
      " | runtime: " +
      String(this.options.runtimeVersion || runtime.version);

    var toolbarHint = document.createElement("div");
    toolbarHint.className = "ms-layout-cta";
    toolbarHint.textContent = "Hover a range, then click for details";

    var controls = document.createElement("div");
    controls.className = "ms-focus-controls";
    var focusSelect = document.createElement("select");
    focusSelect.id = "memory-layout-focus-region";
    focusSelect.setAttribute("aria-label", "Focus memory region");

    var focusButton = document.createElement("button");
    focusButton.type = "button";
    focusButton.id = "memory-layout-focus-go";
    focusButton.textContent = "Focus";

    var prevButton = document.createElement("button");
    prevButton.type = "button";
    prevButton.id = "memory-layout-focus-prev";
    prevButton.textContent = "Prev";

    var nextButton = document.createElement("button");
    nextButton.type = "button";
    nextButton.id = "memory-layout-focus-next";
    nextButton.textContent = "Next";

    var resetButton = document.createElement("button");
    resetButton.type = "button";
    resetButton.id = "memory-layout-focus-reset";
    resetButton.textContent = "Reset";

    var lensGroup = document.createElement("div");
    lensGroup.className = "ms-lens-controls";
    lensGroup.setAttribute("role", "group");
    lensGroup.setAttribute("aria-label", "Analytical lenses");

    function makeLensButton(label, helpText, extraClass) {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "ms-lens-toggle" + (extraClass ? " " + extraClass : "");
      btn.setAttribute("aria-pressed", "false");
      btn.setAttribute("data-help", helpText);
      btn.textContent = label;
      return { wrap: btn, button: btn };
    }

    var alignSpec = makeLensButton(
      "Alignment Lens",
      "Recolors every range by the alignment of its start address. " +
        "Per-region label shows the strictest alignment found inside."
    );
    var alignBtn = alignSpec.button;

    var heatSpec = makeLensButton(
      "Padding Heatmap",
      "Per-region heat strip showing padding bytes ÷ region size. " +
        "Includes inline padding + inter-section gaps; excludes trailing free space."
    );
    var heatBtn = heatSpec.button;

    var rolesSpec = makeLensButton(
      "Memory Roles",
      "Recolors sections by inferred role (CODE / BSS / DATA / HEAP / STACK / VECTORS) and overlays a role badge."
    );
    var rolesBtn = rolesSpec.button;

    var clearSpec = makeLensButton(
      "Clear Pins",
      "Remove all pinned regions from the comparison strip.",
      "ms-clear-pins"
    );
    var clearPinsBtn = clearSpec.button;
    clearPinsBtn.disabled = true;

    var alignLegend = document.createElement("div");
    alignLegend.className = "ms-align-legend";
    alignLegend.setAttribute("aria-hidden", "true");
    var legendTitle = document.createElement("span");
    legendTitle.className = "ms-align-legend-title";
    legendTitle.textContent = "Alignment:";
    alignLegend.appendChild(legendTitle);
    var legendEntries = [
      { klass: "32", label: "≥32 B" },
      { klass: "16", label: "16 B" },
      { klass: "8", label: "8 B" },
      { klass: "4", label: "4 B" },
      { klass: "2", label: "2 B" },
      { klass: "1", label: "1 B" }
    ];
    for (var li = 0; li < legendEntries.length; li++) {
      var entry = legendEntries[li];
      var item = document.createElement("span");
      item.className = "ms-align-legend-item";
      var swatch = document.createElement("span");
      swatch.className = "ms-align-legend-swatch";
      swatch.style.background = colorForAlignment(entry.klass);
      item.appendChild(swatch);
      item.appendChild(document.createTextNode(entry.label));
      alignLegend.appendChild(item);
    }

    lensGroup.appendChild(alignSpec.wrap);
    lensGroup.appendChild(heatSpec.wrap);
    lensGroup.appendChild(rolesSpec.wrap);
    lensGroup.appendChild(clearSpec.wrap);
    lensGroup.appendChild(alignLegend);

    this.lensButtons.alignment = alignBtn;
    this.lensButtons.heatmap = heatBtn;
    this.lensButtons.roles = rolesBtn;
    this.lensButtons.clearPins = clearPinsBtn;
    this.alignLegendEl = alignLegend;

    toolbar.appendChild(toolbarMeta);
    toolbar.appendChild(toolbarHint);
    controls.appendChild(focusSelect);
    controls.appendChild(focusButton);
    controls.appendChild(prevButton);
    controls.appendChild(nextButton);
    controls.appendChild(resetButton);
    toolbar.appendChild(controls);
    toolbar.appendChild(lensGroup);

    var kindLegend = document.createElement("div");
    kindLegend.className = "ms-kind-legend";
    kindLegend.setAttribute("aria-label", "Memory map color legend");
    var kindEntries = [
      { kind: "section", label: "Section",    title: "A placed section (default classification — light blue)." },
      { kind: "free",    label: "Free",       title: "Trailing unused capacity at the edges of the region. NOT counted in the X% pad metric." },
      { kind: "padding", label: "Padding",    title: "Bytes the linker spent on alignment — both inline padding before/after a section AND inter-section gaps. These bytes ARE counted in the X% pad metric." },
      { kind: "stack",   label: "Stack",      title: "Section/region whose name contains \"stack\"." },
      { kind: "heap",    label: "Heap",       title: "Section/region whose name contains \"heap\"." },
      { kind: "reserved",label: "Reserved",   title: "Section/region whose name contains \"reserved\"." },
      { kind: "protected",label: "Protected", title: "Section/region whose name contains \"protect\" or \"secure\"." }
    ];
    for (var ki = 0; ki < kindEntries.length; ki++) {
      var ke = kindEntries[ki];
      var kitem = document.createElement("span");
      kitem.className = "ms-kind-legend-item";
      kitem.setAttribute("tabindex", "0");
      kitem.setAttribute("data-help", ke.title);
      var kswatch = document.createElement("span");
      kswatch.className = "ms-kind-legend-swatch";
      kswatch.style.background = colorForKind(ke.kind);
      kitem.appendChild(kswatch);
      kitem.appendChild(document.createTextNode(ke.label));
      kindLegend.appendChild(kitem);
    }
    var kindLegendNote = document.createElement("span");
    kindLegendNote.className = "ms-kind-legend-note";
    kindLegendNote.textContent = "Default coloring is name-keyword inferred. Toggle Memory Roles or Alignment Lens for other views.";
    kindLegend.appendChild(kindLegendNote);
    toolbar.appendChild(kindLegend);

    // Bind to document.body so the styled popover works for ANY element
    // with `data-help` anywhere on the page — table headers, legend
    // items, lens buttons, etc. The internal `_helpBound` guard makes
    // this idempotent if other code paths re-enter the layout setup.
    bindHelpPopovers(document.body);

    var compositeCard = document.createElement("div");
    compositeCard.className = "ms-layout-canvas-card";
    var compositeBody = document.createElement("div");
    compositeBody.className = "ms-layout-canvas-body";
    var compositeSvg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    compositeSvg.setAttribute("class", "ms-composite-svg");
    compositeSvg.setAttribute("role", "application");
    compositeSvg.setAttribute("aria-roledescription", "Interactive memory layout. Use arrow keys to step ranges, Enter to open details.");
    compositeSvg.setAttribute("aria-label", "Composite memory layout map");
    compositeSvg.setAttribute("tabindex", "0");
    compositeSvg.addEventListener("keydown", this.handleSvgKeydownBound);
    compositeBody.appendChild(compositeSvg);
    compositeCard.appendChild(compositeBody);

    var minimapMount = this.minimapContainer;
    if (!minimapMount) {
      minimapMount = document.createElement("div");
      minimapMount.id = "memory-layout-minimap";
    }
    minimapMount.classList.add("memory-layout-minimap", "memory-layout-minimap--embedded");
    minimapMount.setAttribute("aria-label", "Memory layout minimap");
    compositeCard.appendChild(minimapMount);
    this.minimapContainer = minimapMount;

    var compareStrip = document.createElement("div");
    compareStrip.className = "ms-compare-strip is-empty";
    compareStrip.setAttribute("aria-label", "Pinned regions comparison strip");
    compareStrip.setAttribute("role", "region");
    this.compareStripNode = compareStrip;

    runtimeShell.appendChild(toolbar);
    runtimeShell.appendChild(compositeCard);
    runtimeShell.appendChild(compareStrip);
    this.container.appendChild(runtimeShell);
    this.compositeCardNode = compositeCard;
    this.compositeBodyNode = compositeBody;
    this.regions = regions;
    this.initializeComposite(compositeSvg);
    this.setupFocusControls(
      focusSelect,
      focusButton,
      prevButton,
      nextButton,
      resetButton
    );
    this.setupLensControls();
    this.createGlobalMinimap();
    this.renderCompareStrip();

    global.addEventListener("resize", this.handleWindowResize, { passive: true });

    var self = this;
    if (this.panelClose) {
      this.panelClose.removeEventListener("click", this.closePanelBound);
      this.panelClose.addEventListener("click", this.closePanelBound);
    }
    if (this.panelBackdrop) {
      this.panelBackdrop.classList.remove("is-open");
      this.panelBackdrop.setAttribute("aria-hidden", "true");
      this.panelBackdrop.removeEventListener("click", this.closePanelBound);
    }
    document.removeEventListener("keydown", this._panelEscHandler);
    this._panelEscHandler = function (event) {
      if (event.key === "Escape") {
        self.closePanel();
      }
    };
    document.addEventListener("keydown", this._panelEscHandler);
    document.removeEventListener("pointerdown", this.handleDocumentPointerDownBound, true);
    document.addEventListener("pointerdown", this.handleDocumentPointerDownBound, true);
  };

  LayoutExplorer.prototype.onWindowResize = function () {
    var self = this;
    if (self.resizeTimer) {
      global.clearTimeout(self.resizeTimer);
    }
    self.resizeTimer = global.setTimeout(function () {
      self.resizeComposite();
    }, 90);
  };

  LayoutExplorer.prototype.setupFocusControls = function (
    focusSelect,
    focusButton,
    prevButton,
    nextButton,
    resetButton
  ) {
    var self = this;
    this.focusSelect = focusSelect;
    this.focusSelect.innerHTML = "";
    this.regions.forEach(function (region, index) {
      var option = document.createElement("option");
      option.value = String(index);
      option.textContent = String(region.name || "region " + (index + 1));
      self.focusSelect.appendChild(option);
    });

    this.focusSelect.value = String(this.focusIndex);
    this.focusSelect.addEventListener("change", function () {
      self.focusIndex = Number(self.focusSelect.value || 0);
    });
    focusButton.addEventListener("click", function () {
      self.focusRegion(self.focusIndex);
    });
    prevButton.addEventListener("click", function () {
      self.focusRegionStep(-1);
    });
    nextButton.addEventListener("click", function () {
      self.focusRegionStep(1);
    });
    resetButton.addEventListener("click", function () {
      self.resetZoom();
    });
  };

  LayoutExplorer.prototype.resolveRegionBandHeight = function (region) {
    return resolvePreferredRegionHeight(region);
  };

  LayoutExplorer.prototype.buildRegionLayouts = function (regions, topStart, gapPx) {
    var layouts = [];
    var cursor = Number(topStart || 24);
    for (var index = 0; index < regions.length; index++) {
      var region = regions[index];
      var bandHeight = this.resolveRegionBandHeight(region);
      var headerHeight = 40;
      var contentPadding = 6;
      var bandTop = cursor;
      var bandBottom = bandTop + bandHeight;
      var contentTop = bandTop + headerHeight + contentPadding;
      var contentBottom = bandBottom - contentPadding;
      if (contentBottom <= contentTop + 8) {
        contentBottom = contentTop + 8;
      }
      var yBase = global.d3
        .scaleLinear()
        .domain([Number(region.start_address || 0), Number(region.end_address || 0) + 1])
        .range([contentTop, contentBottom]);
      var hints = region.render_hints && typeof region.render_hints === "object" ? region.render_hints : {};
      layouts.push({
        region: region,
        index: index,
        bandTop: bandTop,
        bandBottom: bandBottom,
        headerHeight: headerHeight,
        contentTop: contentTop,
        contentBottom: contentBottom,
        yBase: yBase,
        scaledForReadability: Boolean(hints.scaled_for_readability),
      });
      cursor = bandBottom + gapPx;
    }
    return {
      layouts: layouts,
      worldBottom: Math.max(cursor - gapPx, Number(topStart || 24)),
    };
  };

  LayoutExplorer.prototype.syncCompositeShellHeight = function (heightPx) {
    var resolvedHeight = Math.max(360, Math.ceil(Number(heightPx || 0)));
    var shellHeight = resolvedHeight + 16;
    if (this.compositeBodyNode) {
      this.compositeBodyNode.style.minHeight = shellHeight + "px";
    }
    if (this.compositeCardNode) {
      this.compositeCardNode.style.minHeight = shellHeight + "px";
    }
  };

  LayoutExplorer.prototype.resolveViewportHeight = function () {
    var viewportHeight = Number(
      global.innerHeight
      || (document.documentElement && document.documentElement.clientHeight)
      || 900
    );
    var viewportWidth = Number(
      global.innerWidth
      || (document.documentElement && document.documentElement.clientWidth)
      || 1280
    );
    var isNarrow = viewportWidth < 900;
    var ratio = isNarrow ? 0.62 : EXPLORER_VIEWPORT_HEIGHT_RATIO;
    var minHeight = isNarrow ? 360 : EXPLORER_VIEWPORT_MIN_HEIGHT_PX;
    var maxHeight = isNarrow ? 760 : EXPLORER_VIEWPORT_MAX_HEIGHT_PX;
    var preferred = Math.floor(viewportHeight * ratio);
    return Math.floor(clamp(preferred, minHeight, maxHeight));
  };

  LayoutExplorer.prototype.initializeComposite = function (svgNode) {
    var width = Math.max(360, Math.floor(svgNode.clientWidth || 880));
    var margin = { top: 24, right: 18, bottom: 24, left: 56 };
    var built = this.buildRegionLayouts(this.regions, margin.top, this.regionGapPx);
    var worldBottom = Math.max(520, Math.ceil(built.worldBottom + margin.bottom));
    var viewportHeight = this.resolveViewportHeight();
    svgNode.style.height = viewportHeight + "px";
    svgNode.setAttribute("height", String(viewportHeight));
    this.syncCompositeShellHeight(viewportHeight);

    var laneGeometry = resolveLaneGeometry(width, margin);
    var svg = global.d3.select(svgNode).attr("viewBox", "0 0 " + width + " " + viewportHeight);
    var rootLayer = svg.append("g");
    var regionLayer = rootLayer.append("g").attr("class", "layout-regions");
    var tickLayer = rootLayer.append("g").attr("class", "layout-ticks");
    var rangeLayer = rootLayer.append("g").attr("class", "layout-ranges");
    var labelLayer = rootLayer.append("g").attr("class", "layout-labels");

    var self = this;
    var zoomBehavior = global.d3
      .zoom()
      .scaleExtent([1, EXPLORER_MAX_ZOOM])
      .extent([
        [0, 0],
        [width, viewportHeight],
      ])
      .translateExtent([
        [0, -Math.max(worldBottom, viewportHeight) * 4],
        [width, Math.max(worldBottom, viewportHeight) * 4],
      ])
      .on("zoom", function (event) {
        self.zoomTransform = event.transform;
        self.scheduleRender();
        self.updateGlobalMinimapViewport();
      });

    svg.call(zoomBehavior).on("dblclick.zoom", null);

    this.composite = {
      svg: svg,
      svgNode: svgNode,
      width: width,
      height: viewportHeight,
      margin: margin,
      laneX: laneGeometry.laneX,
      laneWidth: laneGeometry.laneWidth,
      labelX: laneGeometry.labelX,
      worldBottom: worldBottom,
      rootLayer: rootLayer,
      regionLayer: regionLayer,
      tickLayer: tickLayer,
      rangeLayer: rangeLayer,
      labelLayer: labelLayer,
      zoomBehavior: zoomBehavior,
    };
    this.regionLayouts = built.layouts;
    this.zoomTransform = global.d3.zoomIdentity;
    this.renderComposite();
  };

  LayoutExplorer.prototype.resizeComposite = function () {
    if (!this.composite) {
      return;
    }
    var nextWidth = Math.max(360, Math.floor(this.composite.svgNode.clientWidth || this.composite.width));
    var nextHeight = this.resolveViewportHeight();
    var widthChanged = nextWidth !== this.composite.width;
    var heightChanged = nextHeight !== this.composite.height;
    if (!widthChanged && !heightChanged) {
      return;
    }
    this.composite.width = nextWidth;
    this.composite.height = nextHeight;
    this.composite.svgNode.style.height = nextHeight + "px";
    this.composite.svgNode.setAttribute("height", String(nextHeight));
    var laneGeometry = resolveLaneGeometry(nextWidth, this.composite.margin);
    this.composite.laneX = laneGeometry.laneX;
    this.composite.laneWidth = laneGeometry.laneWidth;
    this.composite.labelX = laneGeometry.labelX;
    this.composite.svg.attr("viewBox", "0 0 " + nextWidth + " " + nextHeight);
    this.composite.zoomBehavior.extent([
      [0, 0],
      [nextWidth, nextHeight],
    ]);
    this.composite.zoomBehavior.translateExtent([
      [0, -Math.max(this.composite.worldBottom, nextHeight) * 4],
      [nextWidth, Math.max(this.composite.worldBottom, nextHeight) * 4],
    ]);
    this.syncCompositeShellHeight(nextHeight);
    this.renderComposite();
    this.createGlobalMinimap();
    this.updateGlobalMinimapViewport();
  };

  LayoutExplorer.prototype.scheduleRender = function () {
    if (this._renderPending) return;
    this._renderPending = true;
    var self = this;
    global.requestAnimationFrame(function () {
      self._renderPending = false;
      self.renderComposite();
    });
  };

  LayoutExplorer.prototype.renderComposite = function () {
    if (!this.composite) {
      return;
    }
    // Re-render tears down every range node along with their listeners.
    // Hide any open hover tooltip before the teardown — otherwise its
    // anchor rect disappears and `mouseleave` never fires, leaving the
    // tooltip stuck visible until the user clicks somewhere else.
    this.hideTooltip();
    var composite = this.composite;
    var laneX = composite.laneX;
    var laneWidth = composite.laneWidth;
    var self = this;
    var zoomTransform = this.zoomTransform || global.d3.zoomIdentity;
    var visibleTop = zoomTransform.invertY(0);
    var visibleBottom = zoomTransform.invertY(composite.height);

    composite.regionLayer.selectAll("*").remove();
    composite.tickLayer.selectAll("*").remove();
    composite.rangeLayer.selectAll("*").remove();
    composite.labelLayer.selectAll("*").remove();
    this.hoveredRangeNode = null;

    this.regionAccessMap = {};
    var alignmentLens = Boolean(this.alignmentLens);
    var paddingHeatmap = Boolean(this.paddingHeatmap);
    var memoryRoles = Boolean(this.memoryRoles);
    var activeRegion = String(this.activeRegionName || "");
    var activeRange = String(this.activeRangeKey || "");
    var activeRangeStart = Number(this.activeRangeStart);
    var activeRangeEnd = Number(this.activeRangeEnd);
    var activeRangeBoundsValid = isFinite(activeRangeStart) && isFinite(activeRangeEnd) && activeRangeEnd >= activeRangeStart;
    var sharedFilters = readFilters(this.options);
    this.regionLayouts.forEach(function (layout, regionIndex) {
      var region = layout.region;
      var regionMatches = regionMatchesFilters(region, sharedFilters);
      var regionDim = regionMatches ? 1 : 0.18;
      var bandTop = zoomTransform.applyY(layout.bandTop);
      var bandBottom = zoomTransform.applyY(layout.bandBottom);
      if (bandBottom < -60 || bandTop > composite.height + 60) {
        return;
      }

      var bandHeight = Math.max(1, bandBottom - bandTop);
      var headerHeight = clamp(
        zoomTransform.applyY(layout.bandTop + layout.headerHeight) - zoomTransform.applyY(layout.bandTop),
        24,
        44
      );
      var headerTop = bandTop;
      var headerBottom = headerTop + headerHeight;
      var contentTop = Math.max(headerBottom + 2, zoomTransform.applyY(layout.contentTop));
      var contentBottom = Math.min(bandBottom - 2, zoomTransform.applyY(layout.contentBottom));
      if (contentBottom <= contentTop + 2) {
        contentBottom = contentTop + 2;
      }

      // When a section in this region is being inspected (sharedFilters.region
      // set), give the region's lane an unmistakable highlight: solid
      // accent border, ~14% accent fill, glow. The clicked section
      // inside still has its own brighter `is-active` outline, so the
      // user sees both "you are in THIS region" and "this is the
      // specific section".
      var isSelectedRegion = regionMatches && Boolean(sharedFilters.region);
      composite.regionLayer
        .append("rect")
        .attr("x", laneX)
        .attr("y", bandTop)
        .attr("width", laneWidth)
        .attr("height", bandHeight)
        .attr("fill", isSelectedRegion ? cssVar("--accent", "#4f8cff") : "transparent")
        .attr("fill-opacity", isSelectedRegion ? 0.14 : 0)
        .attr("stroke", isSelectedRegion ? cssVar("--accent", "#4f8cff") : cssVar("--line", "#35506e"))
        .attr("stroke-width", isSelectedRegion ? 2.4 : 1)
        .attr("stroke-opacity", regionMatches ? 1 : 0.3)
        .attr("rx", 6)
        .attr("ry", 6)
        .attr("class",
          "layout-region-divider" +
          (isSelectedRegion ? " is-selected" : "") +
          (regionMatches ? "" : " is-filtered-dim"));

      composite.regionLayer
        .append("rect")
        .attr("x", laneX)
        .attr("y", headerTop)
        .attr("width", laneWidth)
        .attr("height", headerHeight)
        .attr("fill", isSelectedRegion ? cssVar("--accent", "#4f8cff") : cssVar("--panel-soft", "#1e2d40"))
        .attr("fill-opacity", isSelectedRegion ? 0.32 : (0.68 * regionDim))
        .attr("class", "layout-region-header" + (isSelectedRegion ? " is-selected" : ""));

      if (paddingHeatmap) {
        var heatRatio = regionPaddingRatio(region);
        var heatColor = heatmapColor(heatRatio);
        composite.regionLayer
          .append("rect")
          .attr("class", "layout-heat-strip")
          .attr("x", laneX - 6)
          .attr("y", contentTop)
          .attr("width", 4)
          .attr("height", Math.max(2, contentBottom - contentTop))
          .attr("fill", heatColor)
          .attr("fill-opacity", 0.92)
          .attr("rx", 2)
          .attr("ry", 2);
        composite.labelLayer
          .append("text")
          .attr("x", laneX - 8)
          .attr("y", contentTop + 12)
          .attr("text-anchor", "end")
          .attr("class", "layout-heat-strip-label")
          .text((heatRatio * 100).toFixed(1) + "% pad");
      }

      if (alignmentLens) {
        // Per-region alignment summary: show the strictest alignment among
        // section start addresses inside the region. That's the alignment
        // requirement that's actually shaping how things pack here. Mirrors
        // the per-region "X% pad" overlay used by the Padding Heatmap so
        // the user gets the same kind of at-a-glance summary next to each
        // region label.
        var strict = regionStrictestAlignment(region);
        if (strict) {
          composite.regionLayer
            .append("rect")
            .attr("class", "layout-align-strip")
            .attr("x", laneX - 6)
            .attr("y", contentTop)
            .attr("width", 4)
            .attr("height", Math.max(2, contentBottom - contentTop))
            .attr("fill", colorForAlignment(strict.klass))
            .attr("fill-opacity", 0.92)
            .attr("rx", 2)
            .attr("ry", 2);
          composite.labelLayer
            .append("text")
            .attr("x", laneX - 8)
            .attr("y", contentTop + (paddingHeatmap ? 26 : 12))
            .attr("text-anchor", "end")
            .attr("class", "layout-heat-strip-label")
            .text(strict.label + " align");
        }
      }

      var headerLeft =
        String(region.name || "region") +
        " | " +
        ((Number(region.utilization_ratio || 0) * 100).toFixed(1) + "%") +
        " | " +
        formatBytes(region.size_bytes || 0);
      if (layout.scaledForReadability) {
        headerLeft += " | scaled";
      }
      composite.labelLayer
        .append("text")
        .attr("x", laneX + 8)
        .attr("y", headerTop + Math.max(14, Math.min(headerHeight - 18, 18)))
        .attr("class", "layout-region-header-text")
        .text(headerLeft);

      // Pin button — clickable thumbtack at the far right of the
      // region's header bar. Toggles whether the region appears in
      // the comparison strip below the layout. Discoverable because
      // it's always rendered; pinned regions show a brighter accent
      // fill so the state is visible at a glance even without hover.
      var pinSize = 16;
      var pinIconX = laneX + laneWidth - pinSize - 8;
      var pinIconY = headerTop + Math.max(4, (headerHeight - pinSize) / 2);
      var regionIsPinned = self.isRegionPinned(String(region.name || ""));
      var pinGroup = composite.labelLayer
        .append("g")
        .attr("class", "layout-region-pin" + (regionIsPinned ? " is-pinned" : ""))
        .attr("transform", "translate(" + pinIconX + "," + pinIconY + ")")
        .style("cursor", "pointer");
      pinGroup.append("title")
        .text(regionIsPinned ? "Unpin region from compare strip" : "Pin region for compare strip");
      // Slightly oversized invisible hit-rect so the icon is easy to
      // click on a touch device or with a quick mouse pass.
      pinGroup.append("rect")
        .attr("x", -4).attr("y", -4)
        .attr("width", pinSize + 8).attr("height", pinSize + 8)
        .attr("fill", "transparent");
      pinGroup.append("use")
        .attr("href", "#icon-pin")
        .attr("width", pinSize).attr("height", pinSize)
        .attr("class", "layout-region-pin-icon");
      var pinRegionName = String(region.name || "");
      pinGroup.on("click", function (event) {
        if (event && typeof event.stopPropagation === "function") {
          event.stopPropagation();
        }
        self.togglePin(pinRegionName);
        self.scheduleRender();
      });

      if (memoryRoles) {
        var rolesPresent = {};
        var rolesOrder = [];
        toArray(region.ranges).forEach(function (rng) {
          var rk = rng && rng.role ? String(rng.role) : "";
          if (!rk || !ROLE_BADGE_TEXT[rk]) return;
          var sz = Math.max(0, Number(rng.size_bytes || 0));
          if (sz <= 0) return;
          if (!rolesPresent[rk]) {
            rolesPresent[rk] = 0;
            rolesOrder.push(rk);
          }
          rolesPresent[rk] += sz;
        });
        rolesOrder = rolesOrder.filter(function (rk) { return rolesPresent[rk] > 0; });
        rolesOrder.sort(function (a, b) { return rolesPresent[b] - rolesPresent[a]; });
        var chipBaselineY = headerTop + Math.max(14, Math.min(headerHeight - 18, 18));
        // Reserve room at the right edge of the header for the pin icon
        // (pinSize + 8px gap on each side) so role chips don't collide
        // with it when the Memory Roles lens is on.
        var chipRightEdge = laneX + laneWidth - pinSize - 16;
        var chipPadX = 8;
        var chipPadY = 3;
        var chipGap = 6;
        var chipFontSize = 10;
        for (var ci = rolesOrder.length - 1; ci >= 0; ci--) {
          var role = rolesOrder[ci];
          var label = ROLE_BADGE_TEXT[role];
          var approxTextW = label.length * 6.5;
          var chipW = approxTextW + chipPadX * 2;
          var chipH = chipFontSize + chipPadY * 2;
          var chipX = chipRightEdge - chipW;
          var chipY = chipBaselineY - chipH + 3;
          composite.labelLayer
            .append("rect")
            .attr("x", chipX)
            .attr("y", chipY)
            .attr("width", chipW)
            .attr("height", chipH)
            .attr("rx", 4)
            .attr("ry", 4)
            .attr("class", "layout-role-chip")
            .attr("fill", colorForRole(role) || cssVar("--accent", "#79d5ff"))
            .attr("fill-opacity", 0.85);
          composite.labelLayer
            .append("text")
            .attr("x", chipX + chipW / 2)
            .attr("y", chipY + chipH / 2)
            .attr("text-anchor", "middle")
            .attr("dominant-baseline", "central")
            .attr("class", "layout-role-chip-text")
            .attr("pointer-events", "none")
            .text(label);
          chipRightEdge = chipX - chipGap;
        }
      }

      var yScale = zoomTransform.rescaleY(layout.yBase);
      var boundaries = toArray(region.boundaries)
        .map(function (boundary) {
          return {
            address: Number(boundary.address || 0),
            kind: String(boundary.kind || "internal"),
          };
        })
        .sort(function (left, right) {
          return left.address - right.address;
        });

      // Per-region label tracking — never shared across regions to prevent cross-region
      // interference; labels are placed at their true tick Y and skipped (never pushed)
      // when they would overlap the previous one.
      var lastLabelY = -Infinity;
      var labelX = Math.max(
        laneX + laneWidth + 8,
        Math.min(composite.width - 8, Number(composite.labelX || laneX + laneWidth + 8)),
      );

      boundaries.forEach(function (boundary) {
        var y = yScale(boundary.address);
        if (y < contentTop - 1 || y > contentBottom + 1) {
          return;
        }

        composite.tickLayer
          .append("line")
          .attr("x1", laneX - 6)
          .attr("x2", laneX + laneWidth + 6)
          .attr("y1", y)
          .attr("y2", y)
          .attr("class", "layout-tick-line");

        var labelYMin = contentTop + BOUNDARY_LABEL_Y_PADDING_PX;
        var labelYMax = contentBottom - 2;
        if (labelYMax < labelYMin) {
          return;
        }

        // Anchor the label directly at the tick — clamped within content area only.
        // Never shift a label away from its tick to avoid overlap; skip it instead.
        var labelY = clamp(y + 4, labelYMin, labelYMax);
        var isEndpoint = boundary.kind === "start" || boundary.kind === "end";
        // Endpoints need a smaller gap than internal marks so start/end always appear
        // when there's room; internal ticks need twice the gap to stay readable.
        var requiredGap = isEndpoint
          ? BOUNDARY_LABEL_MIN_GAP_PX
          : BOUNDARY_LABEL_MIN_GAP_PX * 2;

        if (labelY - lastLabelY < requiredGap) {
          return;
        }

        composite.labelLayer
          .append("text")
          .attr("x", labelX)
          .attr("y", labelY)
          .attr("text-anchor", "start")
          .attr("class", "layout-boundary-label")
          .text(formatAddress(boundary.address));
        lastLabelY = labelY;
      });

      var lodRanges = buildLodRanges(region, yScale);
      var regionAccess = [];
      self.regionAccessMap[String(region.name || "")] = regionAccess;
      lodRanges.forEach(function (range, rangeIndex) {
        var start = Number(range.start_address || 0);
        var end = Number(range.end_address || start);
        if (end < start) {
          end = start;
        }
        var yTop = yScale(start);
        var yBottom = yScale(end + 1);
        var y = Math.min(yTop, yBottom);
        var h = Math.max(1, Math.abs(yBottom - yTop));
        if (y + h < contentTop || y > contentBottom) {
          return;
        }
        var clippedTop = Math.max(y, contentTop);
        var clippedBottom = Math.min(y + h, contentBottom);
        var clippedHeight = Math.max(1, clippedBottom - clippedTop);
        var rangeKind = String(range.kind || "section");
        var rangeRole = range && range.role ? String(range.role) : "";
        var color = colorForKind(rangeKind);
        // Inter-section gaps are tagged kind="free" by the contract so they
        // don't get confused with placed sections, but they ARE counted in
        // the per-region "X% pad" metric (because the linker spent those
        // bytes on alignment, not capacity). Color them with padding's
        // amber so the visual matches the metric — otherwise users see
        // "7.4% pad" but no yellow anywhere on the region.
        if (rangeKind === "free" && range.is_inter_section_gap === true) {
          color = colorForKind("padding");
        }
        if (alignmentLens) {
          // When the lens is on, EVERY range is recolored by the alignment
          // of its start address — including section ranges. That way the
          // user can see at a glance which sections sit on strict
          // boundaries (cache lines, MPU regions, page boundaries) and
          // which start on loose ones. Padding and inter-section gap
          // ranges get the same treatment.
          color = colorForAlignment(alignmentClass(start));
        }
        if (memoryRoles && rangeRole) {
          var roleColor = colorForRole(rangeRole);
          if (roleColor) {
            color = roleColor;
          }
        }
        var rangeKey = String(region.name || "") + "|" + formatAddress(start) + "-" + formatAddress(end);
        // isActive matches when EITHER the rendered range's key equals
        // the active key (manual click case — exact same range object
        // is rendered) OR the rendered range fully contains the active
        // selection's address bounds (Find / LOD-aggregate case — the
        // bucket that absorbed the source range counts as active).
        var isActive = false;
        if (activeRegion === String(region.name || "")) {
          if (activeRangeKey(range, region) === activeRange) {
            isActive = true;
          } else if (activeRangeBoundsValid) {
            isActive = (start <= activeRangeStart && end >= activeRangeEnd);
          }
        }
        // When the user has actively pinned a specific range (clicked
        // it in the layout), narrow "matches" to ONLY that exact range
        // — even other ranges with the same section name (e.g. multiple
        // `.text` fragments at different addresses) should dim, since
        // the user pointed at one specific instance.
        // Fall back to filter-based matching only when there's no
        // explicit pin (search-palette flow, deep-link, etc.).
        var rangeMatches;
        if (activeRegion && activeRange) {
          rangeMatches = isActive;
        } else {
          rangeMatches = regionMatches && rangeMatchesFilters(range, region, sharedFilters);
        }
        var rangeDim = rangeMatches ? 1 : 0.18;
        regionAccess.push({ range: range, key: activeRangeKey(range, region) });
        var rect = composite.rangeLayer
          .append("rect")
          .attr("class", "layout-range" + (isActive ? " is-active" : "") + (rangeMatches ? "" : " is-filtered-dim"))
          .attr("x", laneX + 2)
          .attr("y", clippedTop)
          .attr("width", Math.max(1, laneWidth - 4))
          .attr("height", clippedHeight)
          .attr("fill", color)
          .attr("fill-opacity", (range.is_lod_aggregate ? 0.5 : 0.84) * rangeDim)
          .attr("stroke", isActive ? cssVar("--accent", "#79d5ff") : cssVar("--bg", "#0f131a"))
          .attr("stroke-width", isActive ? 1.6 : 0.8)
          .attr("stroke-opacity", rangeMatches ? 1 : 0.4)
          .attr("data-region", String(region.name || ""))
          .attr("data-range-key", rangeKey)
          .attr("data-role", rangeRole)
          .attr("role", "button")
          .attr("aria-label",
            String(region.name || "region") + " " + rangeKind + " " +
            formatAddress(start) + " size " + formatBytes(range.size_bytes || 0)
          );

        rect
          .on("mouseenter", function (event) {
            self.setHoveredRangeNode(this);
            self.showTooltip(event, region, range);
          })
          .on("mousemove", function (event) {
            self.setHoveredRangeNode(this);
            if (self._tooltipThrottleTimer) {
              self._tooltipPendingArgs = [event, region, range];
              return;
            }
            self.showTooltip(event, region, range);
            self._tooltipThrottleTimer = global.setTimeout(function () {
              self._tooltipThrottleTimer = null;
              if (self._tooltipPendingArgs) {
                var args = self._tooltipPendingArgs;
                self._tooltipPendingArgs = null;
                self.showTooltip(args[0], args[1], args[2]);
              }
            }, 16);
          })
          .on("mouseleave", function () {
            self.hideTooltip();
          })
          .on("click", function () {
            self.setHoveredRangeNode(this);
            // Delegate everything (state mutation, focus, panel open,
            // emitSelect) to selectRange so the manual click and the
            // Find-by-Address / Find-by-Symbol popovers go through the
            // same code path and produce identical visual state.
            self.selectRange(regionIndex, region, range);
          });

      });

      if (memoryRoles && (laneWidth - 4) >= 22) {
        var roleSpans = [];
        var currentSpan = null;
        lodRanges.forEach(function (range) {
          var role = range && range.role ? String(range.role) : "";
          var rs = Number(range.start_address || 0);
          var re = Number(range.end_address || rs);
          var top = yScale(rs);
          var bot = yScale(re);
          if (bot < top) { var t = top; top = bot; bot = t; }
          var ct = Math.max(top, contentTop);
          var cb = Math.min(bot, contentBottom);
          if (cb <= ct) { return; }
          if (!role || !ROLE_BADGE_TEXT[role]) {
            if (currentSpan) { roleSpans.push(currentSpan); currentSpan = null; }
            return;
          }
          if (currentSpan && currentSpan.role === role && ct <= currentSpan.bottom + 1) {
            currentSpan.bottom = Math.max(currentSpan.bottom, cb);
          } else {
            if (currentSpan) { roleSpans.push(currentSpan); }
            currentSpan = { role: role, top: ct, bottom: cb };
          }
        });
        if (currentSpan) { roleSpans.push(currentSpan); }
        roleSpans.forEach(function (span) {
          var spanH = span.bottom - span.top;
          if (spanH < 10) { return; }
          composite.labelLayer
            .append("text")
            .attr("x", laneX + (laneWidth - 4) / 2 + 2)
            .attr("y", span.top + spanH / 2)
            .attr("text-anchor", "middle")
            .attr("dominant-baseline", "central")
            .attr("class", "layout-role-badge")
            .attr("pointer-events", "none")
            .text(ROLE_BADGE_TEXT[span.role]);
        });
      }

      if (layout.scaledForReadability && visibleBottom >= layout.bandTop && visibleTop <= layout.bandBottom) {
        composite.labelLayer
          .append("text")
          .attr("x", laneX + laneWidth - 8)
          .attr("y", contentBottom - 6)
          .attr("text-anchor", "end")
          .attr("class", "layout-boundary-label")
          .text("scaled for readability");
      }
    });
  };

  LayoutExplorer.prototype.createGlobalMinimap = function () {
    if (!this.minimapContainer) {
      return;
    }
    this.minimapContainer.innerHTML = "";
    if (!this.composite || !this.regionLayouts.length) {
      var note = document.createElement("div");
      note.className = "ms-layout-empty";
      note.textContent = "Global minimap is unavailable for this report.";
      this.minimapContainer.appendChild(note);
      this.globalMinimap = null;
      return;
    }

    var card = document.createElement("div");
    card.className = "ms-global-minimap-card";
    var title = document.createElement("div");
    title.className = "ms-global-minimap-title";
    title.textContent = "Map Navigator";
    var svgNode = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svgNode.setAttribute("class", "ms-global-minimap-svg");
    card.appendChild(title);
    card.appendChild(svgNode);
    this.minimapContainer.appendChild(card);

    var width = Math.max(160, Math.floor(svgNode.clientWidth || 260));
    var height = Math.max(140, Math.floor(svgNode.clientHeight || 190));
    var margin = { top: 8, right: 10, bottom: 8, left: 10 };
    var trackWidth = Math.max(42, width - margin.left - margin.right);
    var worldMin = this.composite.margin.top;
    var worldMax = this.composite.worldBottom;
    var svg = global.d3.select(svgNode).attr("viewBox", "0 0 " + width + " " + height);
    var yMini = global.d3
      .scaleLinear()
      .domain([worldMin, worldMax])
      .range([margin.top, height - margin.bottom]);

    var base = svg.append("g");
    base
      .append("rect")
      .attr("x", margin.left)
      .attr("y", margin.top)
      .attr("width", trackWidth)
      .attr("height", Math.max(1, height - margin.top - margin.bottom))
      .attr("fill", "transparent")
      .attr("stroke", cssVar("--line", "#35506e"))
      .attr("stroke-width", 1)
      .attr("rx", 6)
      .attr("ry", 6);

    var regionLayer = base.append("g");
    var rangeLayer = base.append("g");
    var labelLayer = base.append("g");
    var self = this;
    var miniFilters = readFilters(this.options);
    for (var index = 0; index < this.regionLayouts.length; index++) {
      var layout = this.regionLayouts[index];
      var regionTop = yMini(layout.bandTop);
      var regionBottom = yMini(layout.bandBottom);
      var regionHeight = Math.max(1, regionBottom - regionTop);
      var regionIndex = index;
      var miniRegionMatches = regionMatchesFilters(layout.region, miniFilters);
      var miniRegionDim = miniRegionMatches ? 1 : 0.22;
      regionLayer
        .append("rect")
        .attr("x", margin.left + 1)
        .attr("y", regionTop)
        .attr("width", Math.max(1, trackWidth - 2))
        .attr("height", regionHeight)
        .attr("fill", cssVar("--panel-soft", "#1e2d40"))
        .attr("fill-opacity", 0.2 * miniRegionDim)
        .attr("stroke", cssVar("--line", "#35506e"))
        .attr("stroke-width", 0.5)
        .attr("stroke-opacity", miniRegionMatches ? 1 : 0.4)
        .style("cursor", "pointer")
        .on("dblclick", function () {
          var idx = Number(this.getAttribute("data-region-index") || 0);
          self.focusRegion(idx);
        })
        .attr("data-region-index", String(regionIndex));

      if (regionHeight >= 14) {
        labelLayer
          .append("text")
          .attr("x", margin.left + 4)
          .attr("y", regionTop + Math.min(11, regionHeight - 3))
          .attr("class", "ms-minimap-region-label")
          .style("pointer-events", "none")
          .text(String(layout.region.name || ""));
      }

      var miniMemoryRoles = Boolean(self.memoryRoles);
      var miniAlignmentLens = Boolean(self.alignmentLens);
      var miniRegion = layout.region;
      toArray(layout.region.ranges).forEach(function (range) {
        var start = Number(range.start_address || 0);
        var end = Number(range.end_address || start);
        if (end < start) {
          end = start;
        }
        var worldTop = layout.yBase(start);
        var worldBottom = layout.yBase(end + 1);
        var yTop = yMini(Math.min(worldTop, worldBottom));
        var yBottom = yMini(Math.max(worldTop, worldBottom));
        var rangeKind = String(range.kind || "section");
        var rangeRole = range && range.role ? String(range.role) : "";
        var fill = colorForKind(rangeKind);
        // Mirror the Layout Explorer's special-case for inter-section gaps:
        // they're tagged kind="free" but visually they're padding waste.
        // Without this, a region that's mostly gap waste shows as dark blue
        // here while the main map shows it amber — same data, two stories.
        if (rangeKind === "free" && range.is_inter_section_gap === true) {
          fill = colorForKind("padding");
        }
        if (miniAlignmentLens) {
          fill = colorForAlignment(alignmentClass(start));
        }
        if (miniMemoryRoles && rangeRole && Number(range.size_bytes || 0) > 0) {
          var roleColor = colorForRole(rangeRole);
          if (roleColor) { fill = roleColor; }
        }
        var miniRangeMatches = miniRegionMatches && rangeMatchesFilters(range, miniRegion, miniFilters);
        rangeLayer
          .append("rect")
          .attr("x", margin.left + 1)
          .attr("y", yTop)
          .attr("width", Math.max(1, trackWidth - 2))
          .attr("height", Math.max(1, yBottom - yTop))
          .attr("fill", fill)
          .attr("fill-opacity", 0.72 * (miniRangeMatches ? 1 : 0.22));
      });
    }

    var viewport = base
      .append("rect")
      .attr("class", "minimap-viewport")
      .attr("x", margin.left)
      .attr("y", margin.top)
      .attr("width", trackWidth)
      .attr("height", Math.max(10, (height - margin.top - margin.bottom) * 0.18))
      .attr("rx", 3)
      .attr("ry", 3);

    var self = this;
    var isDraggingMinimap = false;
    var minimapDragMoved = false;
    var suppressMinimapClick = false;

    function navigateFromMinimapEvent(event, animated) {
      if (!self.composite) {
        return;
      }
      var point = global.d3.pointer(event, svgNode);
      var y = clamp(point[1], margin.top, height - margin.bottom);
      var worldY = yMini.invert(y);
      var currentK = Number(self.zoomTransform && self.zoomTransform.k || 1);
      var targetTransform = global.d3.zoomIdentity
        .translate(0, self.composite.height / 2 - currentK * worldY)
        .scale(currentK);
      if (animated) {
        self.composite.svg
          .transition()
          .duration(180)
          .call(self.composite.zoomBehavior.transform, targetTransform);
      } else {
        self.composite.svg.call(self.composite.zoomBehavior.transform, targetTransform);
      }
    }

    svg.on("pointerdown", function (event) {
      if (event.pointerType === "mouse" && Number(event.button) !== 0) {
        return;
      }
      isDraggingMinimap = true;
      minimapDragMoved = false;
      suppressMinimapClick = false;
      if (svgNode && typeof svgNode.setPointerCapture === "function" && event.pointerId !== undefined) {
        try {
          svgNode.setPointerCapture(event.pointerId);
        } catch (_error) {
          // Ignore capture failures and keep interactive behavior.
        }
      }
      navigateFromMinimapEvent(event, false);
      if (event.preventDefault) {
        event.preventDefault();
      }
    });

    svg.on("pointermove", function (event) {
      if (!isDraggingMinimap) {
        return;
      }
      minimapDragMoved = true;
      navigateFromMinimapEvent(event, false);
      if (event.preventDefault) {
        event.preventDefault();
      }
    });

    svg.on("pointerup pointercancel", function (event) {
      if (!isDraggingMinimap) {
        return;
      }
      if (minimapDragMoved) {
        suppressMinimapClick = true;
      }
      isDraggingMinimap = false;
      if (svgNode && typeof svgNode.releasePointerCapture === "function" && event.pointerId !== undefined) {
        try {
          svgNode.releasePointerCapture(event.pointerId);
        } catch (_error) {
          // Ignore release failures.
        }
      }
    });

    svg.on("click", function (event) {
      if (suppressMinimapClick) {
        suppressMinimapClick = false;
        return;
      }
      navigateFromMinimapEvent(event, true);
    });

    this.globalMinimap = {
      svg: svg,
      yMini: yMini,
      viewport: viewport,
      margin: margin,
      trackWidth: trackWidth,
      worldMin: worldMin,
      worldMax: worldMax,
    };
    this.updateGlobalMinimapViewport();
  };

  LayoutExplorer.prototype.updateGlobalMinimapViewport = function () {
    if (!this.composite || !this.globalMinimap || !this.zoomTransform) {
      return;
    }
    var mini = this.globalMinimap;
    var visibleTop = this.zoomTransform.invertY(0);
    var visibleBottom = this.zoomTransform.invertY(this.composite.height);
    var topWorld = clamp(Math.min(visibleTop, visibleBottom), mini.worldMin, mini.worldMax);
    var bottomWorld = clamp(Math.max(visibleTop, visibleBottom), mini.worldMin, mini.worldMax);
    var yTop = mini.yMini(topWorld);
    var yBottom = mini.yMini(bottomWorld);
    var y = Math.max(mini.margin.top, Math.min(yTop, yBottom));
    var h = Math.max(8, Math.abs(yBottom - yTop));
    mini.viewport
      .attr("x", mini.margin.left)
      .attr("y", y)
      .attr("width", mini.trackWidth)
      .attr("height", h);
  };

  LayoutExplorer.prototype.focusRegion = function (index) {
    if (!this.composite || !this.regionLayouts.length) {
      return;
    }
    var normalizedIndex = ((Number(index || 0) % this.regionLayouts.length) + this.regionLayouts.length) % this.regionLayouts.length;
    this.focusIndex = normalizedIndex;
    if (this.focusSelect) {
      this.focusSelect.value = String(this.focusIndex);
    }
    var layout = this.regionLayouts[this.focusIndex];
    var currentK = Number(this.zoomTransform && this.zoomTransform.k || 1);
    var targetK = Math.max(currentK, 2.0);
    var focusWorldTop = Math.max(
      Number(this.composite.margin && this.composite.margin.top || 0),
      Number(layout.bandTop || 0)
    );
    var targetTransform = global.d3.zoomIdentity
      .translate(0, FOCUS_TOP_OFFSET_PX - targetK * focusWorldTop)
      .scale(targetK);
    this.composite.svg
      .transition()
      .duration(180)
      .call(this.composite.zoomBehavior.transform, targetTransform);
  };

  // Zoom + scroll so the given range fills ~60% of the viewport with
  // the region header still visible above it. Used by Find by Address /
  // Find by Symbol so the user lands on the EXACT range they searched
  // for, not just the enclosing region. Falls back to focusRegion when
  // the range bounds are missing or invalid.
  LayoutExplorer.prototype.focusRange = function (regionIndex, range) {
    if (!this.composite || !this.regionLayouts.length) return;
    var normalizedIndex = ((Number(regionIndex || 0) % this.regionLayouts.length) + this.regionLayouts.length) % this.regionLayouts.length;
    this.focusIndex = normalizedIndex;
    if (this.focusSelect) {
      this.focusSelect.value = String(this.focusIndex);
    }
    var layout = this.regionLayouts[this.focusIndex];
    if (!layout || typeof layout.yBase !== "function" || !range) {
      return this.focusRegion(regionIndex);
    }
    var start = Number(range.start_address);
    var end = Number(range.end_address);
    if (!isFinite(start) || !isFinite(end) || end < start) {
      return this.focusRegion(regionIndex);
    }
    var rangeWorldTop = layout.yBase(start);
    var rangeWorldBottom = layout.yBase(end + 1);
    var rangeWorldHeight = Math.max(1, rangeWorldBottom - rangeWorldTop);
    var viewportHeight = this.composite.height || EXPLORER_VIEWPORT_MIN_HEIGHT_PX;
    // Aim to fill ~55% of the visible canvas with the range itself —
    // tight enough to feel "zoomed in", loose enough to keep some
    // surrounding context visible above and below.
    var targetK = (viewportHeight * 0.55) / rangeWorldHeight;
    targetK = Math.max(2.0, Math.min(targetK, EXPLORER_MAX_ZOOM));
    // Shift the range a bit below the viewport top so the region
    // header band (region name + utilization line) stays visible.
    var topOffset = Math.max(FOCUS_TOP_OFFSET_PX + 28, 60);
    var targetTransform = global.d3.zoomIdentity
      .translate(0, topOffset - targetK * rangeWorldTop)
      .scale(targetK);
    this.composite.svg
      .transition()
      .duration(220)
      .call(this.composite.zoomBehavior.transform, targetTransform);
  };

  LayoutExplorer.prototype.focusRegionStep = function (delta) {
    if (!this.regionLayouts.length) {
      return;
    }
    this.focusRegion(this.focusIndex + Number(delta || 0));
  };

  LayoutExplorer.prototype.resetZoom = function () {
    if (!this.composite || !this.composite.zoomBehavior) {
      return;
    }
    this.composite.svg
      .transition()
      .duration(180)
      .call(this.composite.zoomBehavior.transform, global.d3.zoomIdentity);
  };

  LayoutExplorer.prototype.setHoveredRangeNode = function (node) {
    var nextNode = node || null;
    if (this.hoveredRangeNode === nextNode) {
      return;
    }
    if (this.hoveredRangeNode) {
      global.d3.select(this.hoveredRangeNode).classed("is-hover", false);
    }
    this.hoveredRangeNode = nextNode;
    if (this.hoveredRangeNode) {
      global.d3.select(this.hoveredRangeNode).classed("is-hover", true).raise();
    }
  };

  LayoutExplorer.prototype.showTooltip = function (event, region, range) {
    if (!this.tooltip) {
      return;
    }
    var owners = ownerSummary(range);
    var utilization = Number(range.utilization_ratio_in_region || 0) * 100;
    var roleKey = range && range.role ? String(range.role) : "";
    var roleLine = "";
    if (roleKey && ROLE_BADGE_TEXT[roleKey]) {
      var roleDesc = ROLE_DESCRIPTIONS[roleKey] || "";
      roleLine = "<div><strong>Role:</strong> " + safeText(ROLE_BADGE_TEXT[roleKey]) + (roleDesc ? " &mdash; " + safeText(roleDesc) : "") + "</div>";
    }
    var lines = [
      "<div><strong>Region:</strong> " + safeText(region.name || "unknown") + "</div>",
      "<div><strong>Section:</strong> " + safeText(range.section_name || range.label || "unknown") + "</div>",
      "<div><strong>Kind:</strong> " + safeText(String(range.kind || "section")) + "</div>",
      roleLine,
      "<div><strong>Address:</strong> " + safeText(formatAddress(range.start_address || 0)) + " - " + safeText(formatAddress(range.end_address || 0)) + "</div>",
      "<div><strong>Size:</strong> " + safeText(formatBytes(range.size_bytes || 0)) + " (" + safeText(formatKiB(range.size_bytes || 0)) + ")</div>",
      "<div><strong>Utilization:</strong> " + safeText(utilization.toFixed(1) + "%") + "</div>",
      "<div><strong>Object:</strong> " + safeText(owners.object) + "</div>",
      "<div><strong>Archive:</strong> " + safeText(owners.archive) + "</div>",
      "<div><strong>Source:</strong> " + safeText(owners.source) + "</div>",
      "<div class=\"tip-action\">Click to open detailed breakdown</div>",
    ];

    this.tooltip.innerHTML = lines.join("");
    this.tooltip.classList.add("is-visible");

    var x = Number(event.clientX || 0) + 14;
    var y = Number(event.clientY || 0) + 14;
    var maxX = global.innerWidth - this.tooltip.offsetWidth - 12;
    var maxY = global.innerHeight - this.tooltip.offsetHeight - 12;
    this.tooltip.style.left = Math.max(6, Math.min(x, maxX)) + "px";
    this.tooltip.style.top = Math.max(6, Math.min(y, maxY)) + "px";
  };

  LayoutExplorer.prototype.hideTooltip = function () {
    // Cancel any pending throttled tooltip work BEFORE clearing the
    // visibility class — otherwise a `mousemove` that scheduled a 16ms
    // timer right before the click can fire after `hideTooltip` and
    // re-show the tooltip with stale args. Double-clicking a range used
    // to hit this race window twice and leave the tooltip stuck.
    if (this._tooltipThrottleTimer) {
      global.clearTimeout(this._tooltipThrottleTimer);
      this._tooltipThrottleTimer = null;
    }
    this._tooltipPendingArgs = null;
    if (!this.tooltip) {
      return;
    }
    this.tooltip.classList.remove("is-visible");
    this.setHoveredRangeNode(null);
  };

  LayoutExplorer.prototype.openPanel = function (region, range) {
    if (!this.panel || !this.panelContent) {
      return;
    }

    var panel = range && range.panel && typeof range.panel === "object" ? range.panel : {};
    var section = panel.section && typeof panel.section === "object" ? panel.section : {};
    var baseline = panel.baseline && typeof panel.baseline === "object" ? panel.baseline : {};
    var policy = panel.policy && typeof panel.policy === "object" ? panel.policy : {};
    var issueIds = toArray(policy.issue_ids).map(String);
    // The Python contract groups panel symbols by section NAME, so
    // multiple ranges with the same name (e.g. several `.tc_code`
    // fragments at different addresses) all carry the union of every
    // such section's symbols. Narrow to the symbols whose address
    // actually lives inside THIS range's [start_address, end_address]
    // interval, so the panel matches what the user clicked. Symbols
    // without an address (synthetic / aggregate) are kept as a safe
    // fallback — better to over-show than under-show in that case.
    var rangeStart = Number(range && range.start_address);
    var rangeEnd = Number(range && range.end_address);
    var hasInterval = isFinite(rangeStart) && isFinite(rangeEnd) && rangeEnd >= rangeStart;
    var allSymbols = toArray(panel.symbol_breakdown);
    var filteredSymbols = !hasInterval
      ? allSymbols
      : allSymbols.filter(function (row) {
          if (!row || row.address == null) return true;
          var addr = Number(row.address);
          if (!isFinite(addr)) return true;
          return addr >= rangeStart && addr <= rangeEnd;
        });
    var symbolRows = filteredSymbols.slice(0, 20);
    var owners = ownerSummary(range);

    var baselineStatus = String(baseline.status || "unknown");
    var baselineDelta = baseline.delta_bytes;
    var baselineText = baselineStatus === "available" && baselineDelta !== null && baselineDelta !== undefined
      ? formatSignedBytes(baselineDelta)
      : "baseline: unknown";

    var issuesHtml = "";
    if (issueIds.length) {
      issuesHtml =
        "<ul class=\"layout-panel-list\">" +
        issueIds
          .map(
            function (id) {
              var issue = this.policyIssueIndex[id] || {};
              var title = issue.title ? String(issue.title) : id;
              var severity = issue.severity ? " [" + String(issue.severity) + "]" : "";
              return "<li><strong>" + safeText(id) + "</strong>: " + safeText(title + severity) + "</li>";
            }.bind(this),
          )
          .join("") +
        "</ul>";
    } else {
      issuesHtml = "<div class=\"layout-panel-placeholder\">No linked policy issues for this range.</div>";
    }

    var symbolsHtml = "";
    if (symbolRows.length) {
      symbolsHtml =
        "<table class=\"layout-panel-table\"><thead><tr><th>Symbol</th><th>Size</th><th>Object</th></tr></thead><tbody>" +
        symbolRows
          .map(function (row) {
            return (
              "<tr><td>" +
              safeText(row.name || "") +
              "</td><td>" +
              safeText(formatBytes(row.size || 0)) +
              "</td><td>" +
              safeText(row.object_file || row.archive || "unknown") +
              "</td></tr>"
            );
          })
          .join("") +
        "</tbody></table>";
    } else {
      symbolsHtml = "<div class=\"layout-panel-placeholder\">No symbol breakdown data available for this range.</div>";
    }

    // Pin lives on each region's header in the layout map — not in
    // this panel — because pinning is region-level, not range-level.

    var html =
      "<section class=\"layout-panel-block\">" +
      "<h4>Selection</h4>" +
      "<dl class=\"layout-panel-kv\">" +
      "<dt>Region</dt><dd>" + safeText(region.name || "unknown") + "</dd>" +
      "<dt>Section</dt><dd>" + safeText(section.name || range.section_name || range.label || "unknown") + "</dd>" +
      "<dt>Kind</dt><dd>" + safeText(String(range.kind || "section")) + "</dd>" +
      (range && range.role && ROLE_BADGE_TEXT[String(range.role)]
        ? "<dt>Role</dt><dd>" + safeText(ROLE_BADGE_TEXT[String(range.role)]) + " &mdash; " + safeText(ROLE_DESCRIPTIONS[String(range.role)] || "") + "</dd>"
        : "") +
      "<dt>Address</dt><dd>" + safeText(formatAddress(range.start_address || 0) + " - " + formatAddress(range.end_address || 0)) + "</dd>" +
      "<dt>Size</dt><dd>" + safeText(formatBytes(range.size_bytes || 0)) + " (" + safeText(formatKiB(range.size_bytes || 0)) + ")</dd>" +
      "<dt>Baseline</dt><dd>" + safeText(baselineText) + "</dd>" +
      "</dl>" +
      "</section>" +
      "<section class=\"layout-panel-block\">" +
      "<h4>Ownership</h4>" +
      "<dl class=\"layout-panel-kv\">" +
      "<dt>Object</dt><dd>" + safeText(owners.object) + "</dd>" +
      "<dt>Archive</dt><dd>" + safeText(owners.archive) + "</dd>" +
      "<dt>Source</dt><dd>" + safeText(owners.source) + "</dd>" +
      "</dl>" +
      "</section>" +
      "<section class=\"layout-panel-block\">" +
      "<h4>Top Symbols</h4>" +
      symbolsHtml +
      "</section>" +
      "<section class=\"layout-panel-block\">" +
      "<h4>Policy Violations</h4>" +
      issuesHtml +
      "</section>";

    this.panelContent.innerHTML = html;
    this.panel.classList.add("is-open");
    this.panel.setAttribute("aria-hidden", "false");
    if (this.panelBackdrop) {
      this.panelBackdrop.classList.remove("is-open");
      this.panelBackdrop.setAttribute("aria-hidden", "true");
    }
  };

  LayoutExplorer.prototype.closePanel = function () {
    if (this.panel) {
      this.panel.classList.remove("is-open");
      this.panel.setAttribute("aria-hidden", "true");
    }
    if (this.panelBackdrop) {
      this.panelBackdrop.classList.remove("is-open");
      this.panelBackdrop.setAttribute("aria-hidden", "true");
    }
    // Closing the panel means "I'm done with this selection". Clear the
    // layout-level region filter (which was dimming all other regions)
    // and the shareable URL hash. Without this, users dismiss the panel
    // and are confused why the map is still desaturated and why the URL
    // still says #?region=... — the visual state contradicts the
    // panel's hidden state.
    var hadSelection = Boolean(this.activeRegionName) || Boolean(this.activeRangeKey);
    this.activeRegionName = "";
    this.activeRangeKey = "";
    this.activeRangeStart = NaN;
    this.activeRangeEnd = NaN;
    if (hadSelection) {
      emitSelect(this.options, {
        source: "layout-explorer-close",
        no_scroll: true,
        clear_layout_selection: true,
      });
      this.scheduleRender();
    }
  };

  LayoutExplorer.prototype.handleDocumentPointerDown = function (event) {
    if (!this.panel || !this.panel.classList.contains("is-open")) {
      return;
    }
    var target = event && event.target;
    if (!target || typeof target.closest !== "function") {
      return;
    }
    if (this.panel.contains(target)) {
      return;
    }
    if (target.closest(".layout-range")) {
      return;
    }
    this.closePanel();
  };

  LayoutExplorer.prototype.setupLensControls = function () {
    var self = this;
    var alignBtn = this.lensButtons && this.lensButtons.alignment;
    var heatBtn = this.lensButtons && this.lensButtons.heatmap;
    var clearBtn = this.lensButtons && this.lensButtons.clearPins;
    if (alignBtn) {
      alignBtn.addEventListener("click", function () {
        self.alignmentLens = !self.alignmentLens;
        alignBtn.setAttribute("aria-pressed", self.alignmentLens ? "true" : "false");
        alignBtn.classList.toggle("is-on", self.alignmentLens);
        if (self.alignLegendEl) {
          self.alignLegendEl.classList.toggle("is-on", self.alignmentLens);
          self.alignLegendEl.setAttribute(
            "aria-hidden",
            self.alignmentLens ? "false" : "true"
          );
        }
        self.scheduleRender();
        if (typeof self.createGlobalMinimap === "function") {
          self.createGlobalMinimap();
        }
      });
    }
    if (heatBtn) {
      heatBtn.addEventListener("click", function () {
        self.paddingHeatmap = !self.paddingHeatmap;
        heatBtn.setAttribute("aria-pressed", self.paddingHeatmap ? "true" : "false");
        heatBtn.classList.toggle("is-on", self.paddingHeatmap);
        self.scheduleRender();
      });
    }
    var rolesBtn = this.lensButtons && this.lensButtons.roles;
    if (rolesBtn) {
      rolesBtn.addEventListener("click", function () {
        self.memoryRoles = !self.memoryRoles;
        rolesBtn.setAttribute("aria-pressed", self.memoryRoles ? "true" : "false");
        rolesBtn.classList.toggle("is-on", self.memoryRoles);
        self.scheduleRender();
        if (typeof self.createGlobalMinimap === "function") {
          self.createGlobalMinimap();
        }
      });
    }
    if (clearBtn) {
      clearBtn.addEventListener("click", function () {
        self.pinnedRegions = [];
        self.renderCompareStrip();
        // Re-render the SVG composite so the per-region pin buttons in
        // the layout headers reset to their unpinned visual state.
        // Without this, the compare strip empties but the buttons stay
        // toggled-on as if the regions were still pinned.
        self.scheduleRender();
      });
    }
  };

  LayoutExplorer.prototype.isRegionPinned = function (name) {
    var key = String(name || "");
    if (!key) return false;
    for (var i = 0; i < this.pinnedRegions.length; i++) {
      if (this.pinnedRegions[i] === key) return true;
    }
    return false;
  };

  LayoutExplorer.prototype.togglePin = function (name) {
    var key = String(name || "");
    if (!key) return;
    var idx = this.pinnedRegions.indexOf(key);
    if (idx >= 0) {
      this.pinnedRegions.splice(idx, 1);
    } else {
      if (this.pinnedRegions.length >= 4) {
        this.pinnedRegions.shift();
      }
      this.pinnedRegions.push(key);
    }
    this.renderCompareStrip();
  };

  LayoutExplorer.prototype.findRegionByName = function (name) {
    var key = String(name || "");
    for (var i = 0; i < this.regions.length; i++) {
      if (String(this.regions[i].name || "") === key) {
        return { region: this.regions[i], index: i };
      }
    }
    return null;
  };

  // Programmatic equivalent of the user clicking a range in the layout.
  // Used by the manual click handler AND by external callers (Find by
  // Address / Find by Symbol popovers) so visual state is identical
  // either way: active region/range pinned, focus dropdown updated,
  // tooltip dismissed, panel opened, filter state emitted to the host
  // page (which triggers the re-render that paints the highlight).
  LayoutExplorer.prototype.selectRange = function (regionIndex, region, range, opts) {
    if (!region || !range) return;
    this.activeRegionName = String(region.name || "");
    this.activeRangeKey = activeRangeKey(range, region);
    this.activeRangeStart = Number(range.start_address);
    this.activeRangeEnd = Number(range.end_address);
    if (typeof regionIndex === "number" && regionIndex >= 0) {
      this.focusIndex = regionIndex;
      if (this.focusSelect) {
        this.focusSelect.value = String(regionIndex);
      }
    }
    this.hideTooltip();
    this.openPanel(region, range);
    var owners = ownerSummary(range);
    var issueIds = toArray(range.policy_issue_ids).map(String);
    var findSource = opts && opts.findSource ? String(opts.findSource) : "";
    // navigationOnly = Find by Address / Find by Symbol path: zoom +
    // highlight + open panel, but do NOT pin a sharedFilter (so the
    // floating Clear button does NOT appear for find-and-look-around
    // gestures). Manual clicks DO pin (because they're a deliberate
    // "investigate this" action). Closing the panel clears the
    // highlight + active state in either case.
    var navigationOnly = Boolean(opts && opts.navigationOnly);
    emitSelect(this.options, {
      source: "layout-explorer",
      no_scroll: true,
      region: normalizeText(range.execution_region || region.name || ""),
      section: normalizeText(range.section_name || range.label || ""),
      object: owners.object,
      archive: owners.archive,
      source_file: owners.source,
      issue_ids: issueIds,
      issue_id: issueIds.length ? issueIds[0] : "",
      drill_section: issueIds.length ? "issues" : "section-explorer",
      find_source: findSource,
      no_filter_sync: navigationOnly,
    });
  };

  // Aggregate the per-pinned-region info for the comparison cards.
  // Walks the region's ranges to compute things the main Region
  // Utilization grid doesn't break out: top contributors, baseline
  // delta, and inline-vs-gap padding split. Returns plain numbers
  // only — formatting happens in the template below.
  function computeRegionCompareSummary(region) {
    var ranges = toArray(region && region.ranges);
    var totalSize = Math.max(0, Number(region && region.size_bytes || 0));
    var stats = (region && region.stats) || {};
    var paddingTotalFromStats = stats.padding_bytes != null ? Number(stats.padding_bytes) : null;

    var inlinePadding = 0;
    var gapPadding = 0;
    var sectionRangeCount = 0;
    var baselineDelta = 0;
    var hasBaseline = false;
    var symbols = [];

    for (var i = 0; i < ranges.length; i++) {
      var r = ranges[i];
      if (!r) continue;
      var kind = String(r.kind || "");
      var size = Math.max(0, Number(r.size_bytes || 0));
      if (kind === "padding") {
        inlinePadding += size;
      } else if (kind === "free" && r.is_inter_section_gap === true) {
        gapPadding += size;
      } else if (kind === "section" || kind === "stack" || kind === "heap" ||
                 kind === "reserved" || kind === "protected") {
        sectionRangeCount += 1;
      }
      if (r.baseline_delta_bytes != null && isFinite(Number(r.baseline_delta_bytes))) {
        baselineDelta += Number(r.baseline_delta_bytes);
        hasBaseline = true;
      }
      var panel = r.panel && typeof r.panel === "object" ? r.panel : null;
      if (panel) {
        var rangeSyms = toArray(panel.symbol_breakdown);
        for (var s = 0; s < rangeSyms.length; s++) {
          var sym = rangeSyms[s];
          if (!sym || !sym.name) continue;
          symbols.push({
            name: String(sym.name),
            size: Math.max(0, Number(sym.size || 0)),
            object: String(sym.object_file || ""),
          });
        }
      }
    }

    var paddingTotal = paddingTotalFromStats != null
      ? paddingTotalFromStats
      : (inlinePadding + gapPadding);
    // If only the total is known but not the split (older contracts),
    // attribute everything to inline so the bar renders coherently.
    if (paddingTotalFromStats != null && (inlinePadding + gapPadding) === 0 && paddingTotal > 0) {
      inlinePadding = paddingTotal;
    }

    symbols.sort(function (a, b) { return b.size - a.size; });
    var topSymbols = [];
    var seenNames = {};
    for (var k = 0; k < symbols.length && topSymbols.length < 3; k++) {
      var name = symbols[k].name;
      if (seenNames[name]) continue;
      seenNames[name] = true;
      topSymbols.push(symbols[k]);
    }

    return {
      totalSize: totalSize,
      utilizationRatio: Number(region && region.utilization_ratio || 0),
      paddingTotal: paddingTotal,
      paddingInline: inlinePadding,
      paddingGap: gapPadding,
      sectionCount: sectionRangeCount,
      baselineDelta: hasBaseline ? baselineDelta : null,
      topSymbols: topSymbols,
    };
  }

  LayoutExplorer.prototype.renderCompareStrip = function () {
    var node = this.compareStripNode;
    if (!node) return;
    var clearBtn = this.lensButtons && this.lensButtons.clearPins;
    if (clearBtn) {
      clearBtn.disabled = this.pinnedRegions.length === 0;
    }
    if (!this.pinnedRegions.length) {
      node.classList.add("is-empty");
      node.innerHTML =
        "<div class=\"ms-compare-empty\">Click the pin icon on a region's header to add it here. Pinned regions get a richer summary side-by-side: top contributors, padding breakdown, baseline delta.</div>";
      return;
    }
    node.classList.remove("is-empty");
    var html = "<div class=\"ms-compare-title\">Pinned regions (" + this.pinnedRegions.length + ")</div><div class=\"ms-compare-grid\">";
    var self = this;
    this.pinnedRegions.forEach(function (name) {
      var found = self.findRegionByName(name);
      if (!found) {
        html +=
          "<div class=\"ms-compare-card is-missing\">" +
          "<div class=\"ms-compare-card-head\">" +
          "<span class=\"ms-compare-card-name\">" + safeText(name) + "</span>" +
          "<button type=\"button\" class=\"ms-compare-unpin\" data-region-name=\"" + safeText(name) + "\" aria-label=\"Unpin " + safeText(name) + "\">&times;</button>" +
          "</div>" +
          "<div class=\"ms-compare-card-note\">Region not present in this report.</div>" +
          "</div>";
        return;
      }
      var region = found.region;
      var summary = computeRegionCompareSummary(region);
      var util = summary.utilizationRatio * 100;
      var totalSize = formatBytes(summary.totalSize);
      var usedBytes = Math.round(summary.utilizationRatio * summary.totalSize);
      var isOverflow = util > 100;
      var barWidth = Math.max(0, Math.min(100, util)).toFixed(1);
      var paddingPctOfRegion = summary.totalSize > 0
        ? (summary.paddingTotal / summary.totalSize) * 100
        : 0;
      var paddingInlineShare = summary.paddingTotal > 0
        ? (summary.paddingInline / summary.paddingTotal) * 100
        : 0;
      var paddingGapShare = summary.paddingTotal > 0
        ? (summary.paddingGap / summary.paddingTotal) * 100
        : 0;

      // ---- Baseline delta block (only when --baseline-json was used) ----
      var baselineHtml = "";
      if (summary.baselineDelta != null) {
        var deltaSign = summary.baselineDelta > 0 ? "▲" : (summary.baselineDelta < 0 ? "▼" : "→");
        var deltaClass = summary.baselineDelta > 0 ? "is-regression" :
                         (summary.baselineDelta < 0 ? "is-improvement" : "is-neutral");
        var deltaText = (summary.baselineDelta > 0 ? "+" : "") +
          formatBytes(Math.abs(summary.baselineDelta)) +
          (summary.baselineDelta < 0 ? " smaller" : (summary.baselineDelta > 0 ? " larger" : " unchanged"));
        baselineHtml =
          "<div class=\"ms-compare-row ms-compare-baseline " + deltaClass + "\">" +
          "<span class=\"ms-compare-row-label\">vs baseline</span>" +
          "<span class=\"ms-compare-row-value\"><span class=\"ms-compare-arrow\">" + deltaSign + "</span> " + safeText(deltaText) + "</span>" +
          "</div>";
      }

      // ---- Padding breakdown block (only render when there's padding) ----
      var paddingHtml = "";
      if (summary.paddingTotal > 0) {
        paddingHtml =
          "<div class=\"ms-compare-row\">" +
          "<span class=\"ms-compare-row-label\">padding</span>" +
          "<span class=\"ms-compare-row-value\">" + safeText(formatBytes(summary.paddingTotal)) +
          " <span class=\"ms-compare-row-sub\">(" + paddingPctOfRegion.toFixed(1) + "% of region)</span></span>" +
          "</div>" +
          "<div class=\"ms-compare-padbar\" title=\"Inline padding " + safeText(formatBytes(summary.paddingInline)) +
          " · Inter-section gaps " + safeText(formatBytes(summary.paddingGap)) + "\">" +
          "<span class=\"ms-compare-padbar-inline\" style=\"width:" + paddingInlineShare.toFixed(1) + "%\"></span>" +
          "<span class=\"ms-compare-padbar-gap\" style=\"width:" + paddingGapShare.toFixed(1) + "%\"></span>" +
          "</div>" +
          "<div class=\"ms-compare-padbar-legend\">" +
          "<span><span class=\"ms-compare-swatch ms-compare-swatch-inline\"></span>inline " + safeText(formatBytes(summary.paddingInline)) + "</span>" +
          "<span><span class=\"ms-compare-swatch ms-compare-swatch-gap\"></span>inter-section " + safeText(formatBytes(summary.paddingGap)) + "</span>" +
          "</div>";
      }

      // ---- Top contributors block ----
      var topHtml = "";
      if (summary.topSymbols.length) {
        topHtml = "<div class=\"ms-compare-top\">" +
          "<div class=\"ms-compare-row-label ms-compare-top-title\">top contributors</div>" +
          "<ul class=\"ms-compare-top-list\">";
        summary.topSymbols.forEach(function (sym) {
          var pctOfRegion = summary.totalSize > 0
            ? ((sym.size / summary.totalSize) * 100).toFixed(1) + "%"
            : "—";
          topHtml +=
            "<li>" +
            "<span class=\"ms-compare-top-name\" title=\"" + safeText(sym.name) + "\">" + safeText(sym.name) + "</span>" +
            "<span class=\"ms-compare-top-meta\">" + safeText(formatBytes(sym.size)) + " · " + pctOfRegion +
            (sym.object ? " · " + safeText(sym.object) : "") + "</span>" +
            "</li>";
        });
        topHtml += "</ul></div>";
      } else {
        topHtml = "<div class=\"ms-compare-top ms-compare-top-empty\">No symbol attribution available for this region.</div>";
      }

      html +=
        "<div class=\"ms-compare-card" + (isOverflow ? " is-overflow" : "") +
          "\" data-region-index=\"" + String(found.index) + "\">" +
        "<div class=\"ms-compare-card-head\">" +
          "<span class=\"ms-compare-card-name\" title=\"" + safeText(region.name || "region") + "\">" +
          safeText(region.name || "region") +
            (isOverflow ? " <span class=\"ms-compare-overflow-badge\" title=\"Region size exceeds capacity\">OVERFLOW</span>" : "") +
          "</span>" +
          "<button type=\"button\" class=\"ms-compare-unpin\" data-region-name=\"" + safeText(region.name || "") + "\" aria-label=\"Unpin " + safeText(region.name || "region") + "\">&times;</button>" +
        "</div>" +
        // Headline numbers row — used / total + util%
        "<div class=\"ms-compare-headline\">" +
          "<span class=\"ms-compare-headline-pct\">" + util.toFixed(1) + "%</span>" +
          "<span class=\"ms-compare-headline-bytes\">" + safeText(formatBytes(usedBytes)) + " / " + safeText(totalSize) + "</span>" +
        "</div>" +
        "<div class=\"ms-compare-bar" + (isOverflow ? " is-overflow" : "") +
          "\"><span style=\"width:" + barWidth + "%\"></span></div>" +
        "<div class=\"ms-compare-row\">" +
          "<span class=\"ms-compare-row-label\">sections</span>" +
          "<span class=\"ms-compare-row-value\">" + summary.sectionCount + " placed</span>" +
        "</div>" +
        baselineHtml +
        paddingHtml +
        topHtml +
        "<button type=\"button\" class=\"ms-compare-focus\" data-region-index=\"" + String(found.index) + "\">Focus in layout</button>" +
        "</div>";
    });
    html += "</div>";
    node.innerHTML = html;
    var explorer = this;
    var unpinButtons = node.querySelectorAll(".ms-compare-unpin");
    for (var i = 0; i < unpinButtons.length; i++) {
      unpinButtons[i].addEventListener("click", function () {
        explorer.togglePin(this.getAttribute("data-region-name") || "");
        explorer.scheduleRender();
      });
    }
    var focusButtons = node.querySelectorAll(".ms-compare-focus");
    for (var j = 0; j < focusButtons.length; j++) {
      focusButtons[j].addEventListener("click", function () {
        explorer.focusRegion(Number(this.getAttribute("data-region-index") || 0));
      });
    }
  };

  LayoutExplorer.prototype.handleSvgKeydown = function (event) {
    if (!event || !this.regions.length) return;
    var key = String(event.key || "");
    var step = function (delta) {
      this.focusRegionStep(delta);
      var name = String(this.regions[this.focusIndex] && this.regions[this.focusIndex].name || "");
      this.activeRegionName = name;
      var access = this.regionAccessMap[name];
      this.activeRangeKey = access && access.length ? access[0].key : "";
      this.scheduleRender();
    }.bind(this);
    if (key === "ArrowDown" || key === "PageDown") {
      step(1);
      event.preventDefault();
    } else if (key === "ArrowUp" || key === "PageUp") {
      step(-1);
      event.preventDefault();
    } else if (key === "ArrowRight" || key === "ArrowLeft") {
      var name = String(this.regions[this.focusIndex] && this.regions[this.focusIndex].name || "");
      var access = this.regionAccessMap[name] || [];
      if (!access.length) return;
      var idx = -1;
      for (var i = 0; i < access.length; i++) {
        if (access[i].key === this.activeRangeKey) { idx = i; break; }
      }
      var delta = key === "ArrowRight" ? 1 : -1;
      var nextIdx = (idx < 0 ? 0 : ((idx + delta) % access.length + access.length) % access.length);
      this.activeRegionName = name;
      this.activeRangeKey = access[nextIdx].key;
      this.scheduleRender();
      event.preventDefault();
    } else if (key === "Enter" || key === " " || key === "Spacebar") {
      var rname = String(this.activeRegionName || "");
      var raccess = this.regionAccessMap[rname] || [];
      var match = null;
      for (var k = 0; k < raccess.length; k++) {
        if (raccess[k].key === this.activeRangeKey) { match = raccess[k].range; break; }
      }
      var found = this.findRegionByName(rname);
      if (found && match) {
        this.openPanel(found.region, match);
        event.preventDefault();
      }
    } else if (key === "Home") {
      this.resetZoom();
      event.preventDefault();
    }
  };

  LayoutExplorer.prototype.applyFilters = function () {
    this.scheduleRender();
    if (typeof this.createGlobalMinimap === "function") {
      this.createGlobalMinimap();
    }
  };

  LayoutExplorer.prototype.destroy = function () {
    global.removeEventListener("resize", this.handleWindowResize);
    if (this.panelClose) {
      this.panelClose.removeEventListener("click", this.closePanelBound);
    }
    if (this.panelBackdrop) {
      this.panelBackdrop.removeEventListener("click", this.closePanelBound);
    }
    if (this._panelEscHandler) {
      document.removeEventListener("keydown", this._panelEscHandler);
    }
    document.removeEventListener("pointerdown", this.handleDocumentPointerDownBound, true);
    if (this.composite && this.composite.svgNode && this.handleSvgKeydownBound) {
      this.composite.svgNode.removeEventListener("keydown", this.handleSvgKeydownBound);
    }
    this.hideTooltip();
    this.closePanel();
    this.lanes = [];
  };

  function ensureExplorer(ctx) {
    if (global.__memscopeLayoutExplorer && typeof global.__memscopeLayoutExplorer.destroy === "function") {
      global.__memscopeLayoutExplorer.destroy();
    }
    var explorer = new LayoutExplorer(ctx);
    explorer.init();
    global.__memscopeLayoutExplorer = explorer;
  }

  runtime.renderers.layoutExplorer = function (ctx) {
    ensureExplorer(ctx || {});
  };

  runtime.renderers.treemapView = function (ctx) {
    var container = ctx && ctx.containerId ? document.getElementById(ctx.containerId) : null;
    if (!container) {
      return;
    }
    if (!global.echarts || typeof global.echarts.init !== "function") {
      fallbackCard(container, "ECharts runtime unavailable.");
      return;
    }
    var ownership = ctx.payload && ctx.payload.ownership && typeof ctx.payload.ownership === "object"
      ? ctx.payload.ownership
      : {};
    var filters = readFilters(ctx.options);
    var hierarchy = toArray(ownership.treemap_hierarchy);
    if (!hierarchy.length) {
      var objects = toArray(ownership.by_object).slice(0, 60);
      hierarchy = [
        {
          name: "Unassigned",
          children: objects.map(function (row) {
            return {
              name: String(row.name || "unknown"),
              value: Number(row.total_bytes || 0),
            };
          }),
        },
      ];
    }
    function filterTreemapHierarchy(nodes, activeFilters) {
      var componentFilter = normalizeText(activeFilters.component);
      var regionFilter = normalizeText(activeFilters.region);
      var sectionQuery = normalizeTextLower(activeFilters.section_query);

      function pruneNode(node, depth) {
        if (!node || typeof node !== "object") {
          return null;
        }
        var name = normalizeText(node.name);
        if (depth === 0 && componentFilter && name !== componentFilter) {
          return null;
        }
        var children = toArray(node.children)
          .map(function (child) {
            return pruneNode(child, depth + 1);
          })
          .filter(function (child) {
            return Boolean(child);
          });

        if (!children.length) {
          var nodeRegion = normalizeText(node.region_name);
          if (regionFilter && nodeRegion && nodeRegion !== regionFilter) {
            return null;
          }
          if (sectionQuery) {
            var searchBlob = (
              normalizeText(node.name) +
              " " +
              normalizeText(node.section_name) +
              " " +
              normalizeText(node.source_file)
            ).toLowerCase();
            if (searchBlob.indexOf(sectionQuery) < 0) {
              return null;
            }
          }
        }

        var clone = Object.assign({}, node);
        if (children.length) {
          clone.children = children;
        }
        return clone;
      }

      return toArray(nodes)
        .map(function (node) {
          return pruneNode(node, 0);
        })
        .filter(function (node) {
          return Boolean(node);
        });
    }

    hierarchy = filterTreemapHierarchy(hierarchy, filters);
    if (!hierarchy.length) {
      fallbackCard(container, "No ownership rows were available for treemap view.");
      return;
    }
    container.innerHTML = "";
    var host = document.createElement("div");
    host.style.width = "100%";
    host.style.height = "460px";
    host.style.minHeight = "360px";
    container.appendChild(host);
    if (container.__memscopeTreemapChart && typeof container.__memscopeTreemapChart.dispose === "function") {
      container.__memscopeTreemapChart.dispose();
    }
    var chart = global.echarts.init(host);
    container.__memscopeTreemapChart = chart;
    chart.setOption({
      backgroundColor: "transparent",
      tooltip: {
        trigger: "item",
        formatter: function (params) {
          var value = Number(params.value || 0);
          var path = toArray(params.treePathInfo)
            .map(function (item) {
              return String(item && item.name ? item.name : "");
            })
            .filter(function (item) {
              return item.length > 0;
            })
            .join(" / ");
          return (
            "<div><strong>" +
            safeText(path || String(params.name || "node")) +
            "</strong></div>" +
            "<div>" +
            safeText(formatBytes(value)) +
            "</div>"
          );
        },
      },
      series: [
        {
          type: "treemap",
          roam: true,
          nodeClick: "zoomToNode",
          breadcrumb: { show: true },
          label: {
            color: cssVar("--text", "#e8f0ff"),
          },
          upperLabel: {
            show: true,
            color: cssVar("--muted", "#a7b6cc"),
            fontSize: 11,
          },
          levels: [
            { itemStyle: { borderColor: cssVar("--line", "#35506e"), borderWidth: 1, gapWidth: 2 } },
            { itemStyle: { borderColor: cssVar("--line-strong", "#4b6a8d"), borderWidth: 1, gapWidth: 1 } },
            { itemStyle: { borderColor: cssVar("--line", "#35506e"), borderWidth: 1, gapWidth: 1 } },
          ],
          data: hierarchy,
        },
      ],
    });
    chart.off("click");
    chart.on("click", function (params) {
      var data = params && params.data && typeof params.data === "object" ? params.data : {};
      var pathInfo = toArray(params && params.treePathInfo)
        .map(function (item) {
          return normalizeText(item && item.name);
        })
        .filter(function (item) {
          return item.length > 0;
        });
      var nodeName = normalizeText(data.display_name || data.name || params.name || "");
      var sectionName = normalizeText(data.section_name);
      var regionName = normalizeText(data.region_name);
      var componentName = pathInfo.length ? pathInfo[0] : "";
      var objectName = pathInfo.length > 1 ? pathInfo[1] : "";

      emitSelect(ctx.options, {
        source: "treemap-view",
        component: componentName || nodeName,
        object: objectName,
        section: sectionName,
        symbol_name: sectionName ? nodeName : "",
        region: regionName,
        drill_section: sectionName ? "section-explorer" : "top-functions",
      });
    });
    global.setTimeout(function () {
      chart.resize();
    }, 0);
  };

  runtime.renderers.diffView = function (ctx) {
    var container = ctx && ctx.containerId ? document.getElementById(ctx.containerId) : null;
    if (!container) {
      return;
    }
    if (!global.echarts || typeof global.echarts.init !== "function") {
      fallbackCard(container, "ECharts runtime unavailable.");
      return;
    }
    var diff = ctx.payload && ctx.payload.diff && typeof ctx.payload.diff === "object"
      ? ctx.payload.diff
      : {};
    var filters = readFilters(ctx.options);
    var rows = toArray(diff.impact_ranking);
    if (!rows.length) {
      rows = toArray(diff.regions).map(function (row) {
        var deltaRatio = Number(row.delta_ratio || 0);
        return {
          name: String(row.region_name || "unknown"),
          delta_ratio: deltaRatio,
          delta_percent: deltaRatio * 100,
          direction: deltaRatio >= 0 ? "growth" : "shrink",
          abs_delta_ratio: Math.abs(deltaRatio),
          current_ratio: Number(row.current_ratio || 0),
          baseline_ratio: Number(row.baseline_ratio || 0),
        };
      });
    }
    if (filters.region) {
      rows = rows.filter(function (row) {
        return normalizeText(row.name || row.region_name) === filters.region;
      });
    }
    if (!rows.length) {
      fallbackCard(container, "No baseline diff region data was available.");
      return;
    }
    container.innerHTML = "";

    var shell = document.createElement("div");
    shell.className = "ms-layout-runtime";

    var controls = document.createElement("div");
    controls.className = "ms-layout-toolbar";
    var controlsMeta = document.createElement("div");
    controlsMeta.className = "meta";
    controlsMeta.textContent = "Sort impact ranking";
    controls.appendChild(controlsMeta);

    var sortModes = [
      { id: "abs", label: "Absolute Impact" },
      { id: "growth", label: "Growth" },
      { id: "shrink", label: "Shrink" },
    ];
    var sortButtons = {};
    sortModes.forEach(function (mode) {
      var button = document.createElement("button");
      button.type = "button";
      button.textContent = mode.label;
      button.dataset.mode = mode.id;
      controls.appendChild(button);
      sortButtons[mode.id] = button;
    });

    var chartHost = document.createElement("div");
    chartHost.style.width = "100%";
    chartHost.style.height = "320px";
    chartHost.style.minHeight = "240px";
    chartHost.style.border = "1px solid " + cssVar("--line", "#35506e");
    chartHost.style.borderRadius = "10px";
    chartHost.style.padding = "8px";
    chartHost.style.background = "color-mix(in srgb, var(--panel-alt) 80%, transparent)";

    var rankingWrap = document.createElement("div");
    rankingWrap.className = "data-container";
    rankingWrap.style.maxHeight = "280px";
    rankingWrap.style.marginTop = "8px";

    var rankingTable = document.createElement("table");
    rankingTable.className = "modern-table";
    rankingTable.innerHTML =
      "<thead class=\"table-header\"><tr>" +
      "<th data-help=\"Position of this region in the diff impact ranking — 1 = biggest impact (positive or negative).\">Rank</th>" +
      "<th data-help=\"The memory region whose utilization changed vs the baseline build.\">Region</th>" +
      "<th data-help=\"Whether the region grew (regression) or shrank (improvement) vs the baseline.\">Direction</th>" +
      "<th data-help=\"Change in utilization ratio (current − baseline), shown as a signed percentage. Positive = grew.\">Delta</th>" +
      "<th data-help=\"Current build's utilization ratio for this region.\">Current</th>" +
      "<th data-help=\"Baseline build's utilization ratio — the reference point everything else is measured against.\">Baseline</th>" +
      "</tr></thead><tbody></tbody>";
    rankingWrap.appendChild(rankingTable);

    shell.appendChild(controls);
    shell.appendChild(chartHost);
    shell.appendChild(rankingWrap);
    container.appendChild(shell);

    if (container.__memscopeDiffChart && typeof container.__memscopeDiffChart.dispose === "function") {
      container.__memscopeDiffChart.dispose();
    }
    var chart = global.echarts.init(chartHost);
    container.__memscopeDiffChart = chart;
    var currentMode = "abs";

    function sortedRows(mode) {
      var prepared = rows.slice();
      if (mode === "growth") {
        prepared = prepared.filter(function (row) {
          return Number(row.delta_ratio || 0) > 0;
        });
        prepared.sort(function (left, right) {
          return Number(right.delta_ratio || 0) - Number(left.delta_ratio || 0);
        });
        return prepared;
      }
      if (mode === "shrink") {
        prepared = prepared.filter(function (row) {
          return Number(row.delta_ratio || 0) < 0;
        });
        prepared.sort(function (left, right) {
          return Number(left.delta_ratio || 0) - Number(right.delta_ratio || 0);
        });
        return prepared;
      }
      prepared.sort(function (left, right) {
        return Math.abs(Number(right.delta_ratio || 0)) - Math.abs(Number(left.delta_ratio || 0));
      });
      return prepared;
    }

    function render(mode) {
      currentMode = mode;
      var list = sortedRows(mode).slice(0, 30);
      if (!list.length) {
        list = sortedRows("abs").slice(0, 30);
      }

      Object.keys(sortButtons).forEach(function (key) {
        if (sortButtons[key]) {
          sortButtons[key].style.borderColor = key === mode ? cssVar("--accent-soft", "#8fd3ff") : cssVar("--line", "#35506e");
        }
      });

      chart.setOption({
        backgroundColor: "transparent",
        animationDuration: 180,
        grid: { top: 26, left: 68, right: 20, bottom: 72 },
        tooltip: {
          trigger: "axis",
          formatter: function (params) {
            if (!params || !params.length) {
              return "";
            }
            var item = params[0];
            var row = list[item.dataIndex] || {};
            var delta = Number(row.delta_ratio || 0) * 100;
            var current = Number(row.current_ratio || 0) * 100;
            var baseline = Number(row.baseline_ratio || 0) * 100;
            return (
              "<div><strong>" +
              safeText(String(row.name || "unknown")) +
              "</strong></div>" +
              "<div>Delta: " +
              safeText((delta >= 0 ? "+" : "") + delta.toFixed(2) + "%") +
              "</div><div>Current: " +
              safeText(current.toFixed(1) + "%") +
              "</div><div>Baseline: " +
              safeText(baseline.toFixed(1) + "%") +
              "</div>"
            );
          },
        },
        xAxis: {
          type: "category",
          axisLabel: { color: cssVar("--muted", "#a7b6cc"), interval: 0, rotate: 28 },
          data: list.map(function (row) {
            return String(row.name || "unknown");
          }),
        },
        yAxis: {
          type: "value",
          axisLabel: {
            color: cssVar("--muted", "#a7b6cc"),
            formatter: function (value) {
              return Number(value).toFixed(2) + "%";
            },
          },
        },
        series: [
          {
            type: "bar",
            data: list.map(function (row) {
              return Number(row.delta_ratio || 0) * 100;
            }),
            itemStyle: {
              color: function (params) {
                return Number(params.value) >= 0
                  ? cssVar("--error", "#ec6d86")
                  : cssVar("--ok", "#61c98f");
              },
            },
          },
        ],
      });

      var tbody = rankingTable.querySelector("tbody");
      if (!tbody) {
        return;
      }
      tbody.innerHTML = "";
      list.forEach(function (row, index) {
        var tr = document.createElement("tr");
        tr.className = "table-row";
        var deltaPercent = Number(row.delta_ratio || 0) * 100;
        var currentPercent = Number(row.current_ratio || 0) * 100;
        var baselinePercent = Number(row.baseline_ratio || 0) * 100;
        tr.innerHTML =
          "<td>" +
          safeText(String(index + 1)) +
          "</td><td><div class=\"code-display\">" +
          safeText(String(row.name || "unknown")) +
          "</div></td><td>" +
          safeText(String(deltaPercent >= 0 ? "growth" : "shrink")) +
          "</td><td><span class=\"size-badge\">" +
          safeText((deltaPercent >= 0 ? "+" : "") + deltaPercent.toFixed(2) + "%") +
          "</span></td><td>" +
          safeText(currentPercent.toFixed(1) + "%") +
          "</td><td>" +
          safeText(baselinePercent.toFixed(1) + "%") +
          "</td>";
        tr.style.cursor = "pointer";
        tr.addEventListener("click", function () {
          emitSelect(ctx.options, {
            source: "diff-table",
            region: normalizeText(row.name || ""),
            drill_section: "section-explorer",
          });
        });
        tbody.appendChild(tr);
      });
    }

    sortModes.forEach(function (mode) {
      var button = sortButtons[mode.id];
      if (!button) {
        return;
      }
      button.addEventListener("click", function () {
        render(mode.id);
      });
    });

    render("abs");
    chart.off("click");
    chart.on("click", function (params) {
      var dataIndex = Number(params && params.dataIndex);
      if (!Number.isFinite(dataIndex)) {
        return;
      }
      var activeList = sortedRows(currentMode);
      var row = activeList[dataIndex] || {};
      var regionName = normalizeText(row.name || row.region_name);
      if (!regionName) {
        return;
      }
      emitSelect(ctx.options, {
        source: "diff-chart",
        region: regionName,
        drill_section: "section-explorer",
      });
    });
    global.setTimeout(function () {
      chart.resize();
    }, 0);
  };

  runtime.renderers.sankeyView = function (ctx) {
    var container = ctx && ctx.containerId ? document.getElementById(ctx.containerId) : null;
    if (!container) {
      return;
    }
    if (!global.echarts || typeof global.echarts.init !== "function") {
      fallbackCard(container, "ECharts runtime unavailable.");
      return;
    }
    var relationships = ctx.payload && ctx.payload.relationships && typeof ctx.payload.relationships === "object"
      ? ctx.payload.relationships
      : {};
    var filters = readFilters(ctx.options);
    var sankey = relationships.sankey && typeof relationships.sankey === "object"
      ? relationships.sankey
      : {};
    var nodes = toArray(sankey.nodes);
    var links = toArray(sankey.links);
    if (filters.region || filters.section_query) {
      var regionFilter = normalizeText(filters.region);
      var sectionQuery = normalizeTextLower(filters.section_query);
      var allowedNodeIds = new Set();
      nodes.forEach(function (node) {
        var kind = normalizeText(node.kind);
        var displayName = normalizeText(node.display_name || node.name);
        var id = normalizeText(node.name || node.id);
        if (!id) {
          return;
        }
        var keep = true;
        if (regionFilter && kind === "memory_region" && displayName !== regionFilter) {
          keep = false;
        }
        if (
          sectionQuery &&
          (kind === "input_section" || kind === "output_section") &&
          normalizeTextLower(displayName).indexOf(sectionQuery) < 0
        ) {
          keep = false;
        }
        if (keep) {
          allowedNodeIds.add(id);
        }
      });
      links = links.filter(function (link) {
        var sourceId = normalizeText(link.source);
        var targetId = normalizeText(link.target);
        return allowedNodeIds.has(sourceId) && allowedNodeIds.has(targetId);
      });
      var linkedIds = new Set();
      links.forEach(function (link) {
        linkedIds.add(normalizeText(link.source));
        linkedIds.add(normalizeText(link.target));
      });
      nodes = nodes.filter(function (node) {
        return linkedIds.has(normalizeText(node.name || node.id));
      });
    }
    if (!nodes.length || !links.length) {
      fallbackCard(container, "Sankey data is unavailable for this report.");
      return;
    }

    container.innerHTML = "";
    var shell = document.createElement("div");
    shell.className = "ms-layout-runtime";

    var toolbar = document.createElement("div");
    toolbar.className = "ms-layout-toolbar";
    var meta = document.createElement("div");
    meta.className = "meta";
    meta.textContent =
      "flow links: " +
      String(links.length) +
      " | nodes: " +
      String(nodes.length) +
      (sankey.truncated ? " | trimmed for responsiveness" : "");
    toolbar.appendChild(meta);
    shell.appendChild(toolbar);

    var host = document.createElement("div");
    host.style.width = "100%";
    host.style.height = "520px";
    host.style.minHeight = "360px";
    host.style.border = "1px solid " + cssVar("--line", "#35506e");
    host.style.borderRadius = "12px";
    host.style.background = "color-mix(in srgb, var(--panel-alt) 80%, transparent)";
    shell.appendChild(host);
    container.appendChild(shell);

    if (container.__memscopeSankeyChart && typeof container.__memscopeSankeyChart.dispose === "function") {
      container.__memscopeSankeyChart.dispose();
    }
    var chart = global.echarts.init(host);
    container.__memscopeSankeyChart = chart;

    function colorForNodeKind(kind) {
      if (kind === "input_section") {
        return cssVar("--chart-2", "#22c1ff");
      }
      if (kind === "output_section") {
        return cssVar("--chart-1", "#4f8cff");
      }
      if (kind === "memory_region") {
        return cssVar("--chart-4", "#61c98f");
      }
      return cssVar("--accent", "#4f8cff");
    }

    var nodeData = nodes.map(function (node) {
      var kind = String(node.kind || "node");
      var valueBytes = Number(node.value_bytes || 0);
      return {
        name: String(node.name || node.id || ""),
        display_name: String(node.display_name || node.name || node.id || "unknown"),
        kind: kind,
        value_bytes: valueBytes,
        value: valueBytes,
        itemStyle: {
          color: colorForNodeKind(kind),
          borderColor: cssVar("--line", "#35506e"),
          borderWidth: 1,
        },
      };
    });
    var linkData = links.map(function (link) {
      var valueBytes = Number(link.value_bytes || link.value || 0);
      return {
        source: String(link.source || ""),
        target: String(link.target || ""),
        value: valueBytes,
        value_bytes: valueBytes,
        kind: String(link.kind || "flow"),
      };
    });

    chart.setOption({
      backgroundColor: "transparent",
      animationDuration: 180,
      tooltip: {
        trigger: "item",
        confine: true,
        formatter: function (params) {
          if (params.dataType === "edge") {
            var link = params.data || {};
            return (
              "<div><strong>" +
              safeText(String(link.kind || "flow")) +
              "</strong></div>" +
              "<div>" +
              safeText(String(params.data.source || "")) +
              " -> " +
              safeText(String(params.data.target || "")) +
              "</div><div>" +
              safeText(formatBytes(link.value_bytes || link.value || 0)) +
              " (" +
              safeText(formatKiB(link.value_bytes || link.value || 0)) +
              ")</div>"
            );
          }
          var node = params.data || {};
          return (
            "<div><strong>" +
            safeText(String(node.display_name || params.name || "node")) +
            "</strong></div><div>kind: " +
            safeText(String(node.kind || "node")) +
            "</div><div>" +
            safeText(formatBytes(node.value_bytes || 0)) +
            " (" +
            safeText(formatKiB(node.value_bytes || 0)) +
            ")</div>"
          );
        },
      },
      series: [
        {
          type: "sankey",
          data: nodeData,
          links: linkData,
          nodeAlign: "justify",
          orient: "horizontal",
          draggable: true,
          emphasis: {
            focus: "adjacency",
          },
          nodeWidth: 20,
          nodeGap: 14,
          lineStyle: {
            color: "source",
            opacity: 0.58,
            curveness: 0.5,
          },
          label: {
            color: cssVar("--text", "#e8f0ff"),
            formatter: function (params) {
              var data = params.data || {};
              return String(data.display_name || params.name || "");
            },
            overflow: "truncate",
            width: 180,
          },
        },
      ],
    });
    chart.off("click");
    chart.on("click", function (params) {
      if (!params) {
        return;
      }
      if (params.dataType === "edge") {
        var edge = params.data && typeof params.data === "object" ? params.data : {};
        var source = normalizeText(edge.source);
        var target = normalizeText(edge.target);
        var sourceKind = source.indexOf("input::") === 0 ? "input_section" : source.indexOf("output::") === 0 ? "output_section" : source.indexOf("region::") === 0 ? "memory_region" : "unknown";
        var targetKind = target.indexOf("input::") === 0 ? "input_section" : target.indexOf("output::") === 0 ? "output_section" : target.indexOf("region::") === 0 ? "memory_region" : "unknown";
        emitSelect(ctx.options, {
          source: "sankey-link",
          section: sourceKind === "input_section" || sourceKind === "output_section" ? stripPrefix(source, sourceKind === "input_section" ? "input::" : "output::") : "",
          region: targetKind === "memory_region" ? stripPrefix(target, "region::") : sourceKind === "memory_region" ? stripPrefix(source, "region::") : "",
          drill_section: targetKind === "memory_region" ? "section-explorer" : "top-contributors",
        });
        return;
      }
      var node = params.data && typeof params.data === "object" ? params.data : {};
      var kind = normalizeText(node.kind);
      var displayName = normalizeText(node.display_name || node.name);
      emitSelect(ctx.options, {
        source: "sankey-node",
        region: kind === "memory_region" ? displayName : "",
        section: kind === "input_section" || kind === "output_section" ? displayName : "",
        drill_section: kind === "memory_region" ? "section-explorer" : "top-contributors",
      });
    });

    global.setTimeout(function () {
      chart.resize();
    }, 0);
  };

  runtime.renderers.relationshipGraphView = function (ctx) {
    var container = ctx && ctx.containerId ? document.getElementById(ctx.containerId) : null;
    if (!container) {
      return;
    }
    if (!global.echarts || typeof global.echarts.init !== "function") {
      fallbackCard(container, "ECharts runtime unavailable.");
      return;
    }
    var relationships = ctx.payload && ctx.payload.relationships && typeof ctx.payload.relationships === "object"
      ? ctx.payload.relationships
      : {};
    var filters = readFilters(ctx.options);
    var graph = relationships.graph && typeof relationships.graph === "object"
      ? relationships.graph
      : {};
    var nodes = toArray(graph.nodes);
    var links = toArray(graph.links);
    if (filters.component || filters.region || filters.section_query) {
      var componentFilter = normalizeText(filters.component);
      var regionFilter = normalizeText(filters.region);
      var sectionQuery = normalizeTextLower(filters.section_query);
      var allowedNodeIds = new Set();
      nodes.forEach(function (node) {
        var nodeId = normalizeText(node.id || node.name);
        if (!nodeId) {
          return;
        }
        var kind = normalizeText(node.kind);
        var name = normalizeText(node.display_name || node.name);
        var keep = true;
        if (componentFilter && kind === "component" && name !== componentFilter) {
          keep = false;
        }
        if (regionFilter && kind === "memory_region" && name !== regionFilter) {
          keep = false;
        }
        if (sectionQuery && (kind === "symbol" || kind === "object")) {
          keep = normalizeTextLower(name).indexOf(sectionQuery) >= 0;
        }
        if (keep) {
          allowedNodeIds.add(nodeId);
        }
      });
      links = links.filter(function (link) {
        var sourceId = normalizeText(link.source);
        var targetId = normalizeText(link.target);
        return allowedNodeIds.has(sourceId) && allowedNodeIds.has(targetId);
      });
      var connectedNodeIds = new Set();
      links.forEach(function (link) {
        connectedNodeIds.add(normalizeText(link.source));
        connectedNodeIds.add(normalizeText(link.target));
      });
      nodes = nodes.filter(function (node) {
        return connectedNodeIds.has(normalizeText(node.id || node.name));
      });
    }
    if (!nodes.length || !links.length) {
      fallbackCard(container, "Relationship graph data is unavailable for this report.");
      return;
    }

    container.innerHTML = "";
    var shell = document.createElement("div");
    shell.className = "ms-layout-runtime";

    var toolbar = document.createElement("div");
    toolbar.className = "ms-layout-toolbar";
    var meta = document.createElement("div");
    meta.className = "meta";
    meta.textContent =
      "nodes: " +
      String(nodes.length) +
      " | links: " +
      String(links.length) +
      (graph.truncated ? " | trimmed for responsiveness" : "");
    toolbar.appendChild(meta);
    shell.appendChild(toolbar);

    var host = document.createElement("div");
    host.style.width = "100%";
    host.style.height = "560px";
    host.style.minHeight = "380px";
    host.style.border = "1px solid " + cssVar("--line", "#35506e");
    host.style.borderRadius = "12px";
    host.style.background = "color-mix(in srgb, var(--panel-alt) 80%, transparent)";
    shell.appendChild(host);
    container.appendChild(shell);

    if (container.__memscopeGraphChart && typeof container.__memscopeGraphChart.dispose === "function") {
      container.__memscopeGraphChart.dispose();
    }
    var chart = global.echarts.init(host);
    container.__memscopeGraphChart = chart;

    function colorForGraphKind(kind) {
      if (kind === "component") {
        return cssVar("--chart-5", "#7ea4ff");
      }
      if (kind === "object") {
        return cssVar("--chart-1", "#4f8cff");
      }
      if (kind === "memory_region") {
        return cssVar("--chart-4", "#61c98f");
      }
      if (kind === "symbol") {
        return cssVar("--chart-2", "#22c1ff");
      }
      return cssVar("--accent", "#4f8cff");
    }

    var categoryIndex = {};
    var categories = [];
    function getCategory(kind) {
      var key = String(kind || "node");
      if (categoryIndex[key] !== undefined) {
        return categoryIndex[key];
      }
      var nextIndex = categories.length;
      categories.push({ name: key });
      categoryIndex[key] = nextIndex;
      return nextIndex;
    }

    var nodeData = nodes.map(function (node) {
      var valueBytes = Number(node.value_bytes || 0);
      var kind = String(node.kind || "node");
      var symbolSize = 10 + Math.min(52, Math.sqrt(Math.max(valueBytes, 1)) / 2.6);
      return {
        id: String(node.id || node.name || ""),
        name: String(node.display_name || node.name || node.id || "node"),
        raw_name: String(node.name || node.id || ""),
        kind: kind,
        value_bytes: valueBytes,
        value: valueBytes,
        category: getCategory(kind),
        symbolSize: symbolSize,
        itemStyle: {
          color: colorForGraphKind(kind),
          borderColor: cssVar("--line", "#35506e"),
          borderWidth: 1,
        },
      };
    });
    var linkData = links.map(function (link) {
      var valueBytes = Number(link.value_bytes || link.value || 0);
      return {
        source: String(link.source || ""),
        target: String(link.target || ""),
        value: valueBytes,
        value_bytes: valueBytes,
        kind: String(link.kind || "link"),
      };
    });

    chart.setOption({
      backgroundColor: "transparent",
      animationDuration: 200,
      legend: {
        data: categories.map(function (cat) {
          return cat.name;
        }),
        textStyle: {
          color: cssVar("--muted", "#a7b6cc"),
        },
      },
      tooltip: {
        confine: true,
        formatter: function (params) {
          if (params.dataType === "edge") {
            var edge = params.data || {};
            return (
              "<div><strong>" +
              safeText(String(edge.kind || "link")) +
              "</strong></div><div>" +
              safeText(String(edge.source || "")) +
              " -> " +
              safeText(String(edge.target || "")) +
              "</div><div>" +
              safeText(formatBytes(edge.value_bytes || edge.value || 0)) +
              "</div>"
            );
          }
          var node = params.data || {};
          return (
            "<div><strong>" +
            safeText(String(node.name || "node")) +
            "</strong></div><div>kind: " +
            safeText(String(node.kind || "node")) +
            "</div><div>" +
            safeText(formatBytes(node.value_bytes || 0)) +
            " (" +
            safeText(formatKiB(node.value_bytes || 0)) +
            ")</div>"
          );
        },
      },
      series: [
        {
          type: "graph",
          layout: "force",
          roam: true,
          draggable: true,
          focusNodeAdjacency: true,
          data: nodeData,
          links: linkData,
          categories: categories,
          force: {
            repulsion: 180,
            edgeLength: [34, 138],
            gravity: 0.08,
            friction: 0.14,
          },
          lineStyle: {
            color: "source",
            opacity: 0.46,
            width: 1.2,
            curveness: 0.12,
          },
          label: {
            show: true,
            color: cssVar("--text", "#e8f0ff"),
            formatter: function (params) {
              return String(params.data.name || "");
            },
            fontSize: 11,
          },
        },
      ],
    });
    chart.off("click");
    chart.on("click", function (params) {
      if (!params || params.dataType === "edge") {
        return;
      }
      var node = params.data && typeof params.data === "object" ? params.data : {};
      var kind = normalizeText(node.kind);
      var displayName = normalizeText(node.name);
      emitSelect(ctx.options, {
        source: "relationship-graph",
        component: kind === "component" ? displayName : "",
        object: kind === "object" ? displayName : "",
        symbol_name: kind === "symbol" ? displayName : "",
        section: kind === "symbol" ? displayName : "",
        region: kind === "memory_region" ? displayName : "",
        drill_section:
          kind === "memory_region"
            ? "section-explorer"
            : kind === "component"
            ? "top-functions"
            : kind === "object"
            ? "top-contributors"
            : "top-global-variables",
      });
    });

    global.setTimeout(function () {
      chart.resize();
    }, 0);
  };

  runtime.invalidateColorCache = invalidateColorCache;
  global.MemScopeRuntime = runtime;
  global.MemScopeRenderers = runtime.renderers;
})(window);
