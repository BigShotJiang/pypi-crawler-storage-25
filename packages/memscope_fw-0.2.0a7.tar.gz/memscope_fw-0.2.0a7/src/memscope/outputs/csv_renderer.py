"""CSV renderer for lightweight spreadsheet workflows."""

from __future__ import annotations

import csv
import io
from pathlib import Path

from memscope.domain import AnalysisReport
from memscope.outputs.pathing import ensure_parent_dir


def render_csv_report(report: AnalysisReport) -> str:
    output = io.StringIO()
    # Provenance preamble. RFC 4180 says "implementations may treat any
    # line beginning with '#' as a comment", and pandas / Excel /
    # csvkit / DuckDB all skip leading `#` lines by default.
    output.write(
        f"# MemScope CSV export — version={report.metadata.tool_version} "
        f"schema={report.metadata.schema_version} "
        f"generated={report.metadata.analysis_timestamp}\n"
    )
    writer = csv.writer(output)
    writer.writerow(["kind", "name", "metric_1", "metric_2", "metric_3", "notes"])

    for region in report.regions:
        utilization = report.summary.utilization_by_region.get(region.name, 0.0)
        writer.writerow(
            [
                "region",
                region.name,
                str(region.size or 0),
                f"{utilization:.6f}",
                region.category.value,
                "",
            ]
        )

    for section in report.sections:
        writer.writerow(
            [
                "section",
                section.name,
                str(section.size),
                section.execution_region or "",
                section.load_region or "",
                "",
            ]
        )

    for component in report.components:
        writer.writerow(
            [
                "component",
                component.name,
                str(component.total_flash),
                str(component.total_ram),
                str(len(component.symbols)),
                "",
            ]
        )

    for issue in report.issues:
        writer.writerow(
            [
                "issue",
                issue.id,
                issue.severity.value,
                issue.category.value,
                issue.title,
                issue.description,
            ]
        )

    return output.getvalue()


def write_csv_report(path: Path, report: AnalysisReport) -> None:
    ensure_parent_dir(path)
    path.write_text(render_csv_report(report), encoding="utf-8", newline="")

