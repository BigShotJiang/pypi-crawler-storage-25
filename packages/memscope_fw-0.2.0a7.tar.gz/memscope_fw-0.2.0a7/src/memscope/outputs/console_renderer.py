"""Terminal-oriented summary renderer."""

from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime

from memscope.domain import AnalysisReport


def render_console_summary(
    report: AnalysisReport,
    *,
    blocking: bool,
    output_paths: Mapping[str, str | None] | None = None,
    suppress_renewal_reminder: bool = False,
    now: datetime | None = None,
) -> str:
    """Build the human-readable analysis summary printed to the terminal.

    The ``suppress_renewal_reminder`` and ``now`` parameters are accepted for
    backwards compatibility with callers from the trial/paid-mode era; they
    are no-ops in the current free-core model (no license expiry to remind
    about).
    """
    _ = (suppress_renewal_reminder, now)  # accepted for API compat; no-ops
    summary = report.summary
    issue_counts = {
        "error": int(summary.issue_counts.get("error", 0)),
        "warning": int(summary.issue_counts.get("warning", 0)),
        "info": int(summary.issue_counts.get("info", 0)),
    }

    lines = [
        "MemScope Analysis Summary",
        f"Target: {report.metadata.target_name or 'unknown'}",
        f"Toolchain: {report.metadata.toolchain_detected or 'unknown'}",
        f"Total FLASH: {summary.total_flash} B",
        f"Total RAM: {summary.total_ram} B",
        (
            "Issues: "
            f"error={issue_counts['error']} "
            f"warning={issue_counts['warning']} "
            f"info={issue_counts['info']}"
        ),
        f"Blocking Policy: {'yes' if blocking else 'no'}",
    ]

    multicore = summary.extra.get("multicore")
    cores: list[str] = []
    if isinstance(multicore, dict):
        cores_value = multicore.get("cores")
        if isinstance(cores_value, list):
            cores = sorted({str(core) for core in cores_value if str(core).strip()})
    if cores:
        lines.append(f"Cores Detected: {len(cores)} ({', '.join(cores)})")
    else:
        lines.append("Cores Detected: 1 (single-core; no per-core region partitioning found)")

    top_regions = _top_regions(summary.utilization_by_region)
    if top_regions:
        lines.append("Top Region Utilization:")
        lines.extend(top_regions)

    regressions = report.regressions
    status = regressions.get("status")
    if isinstance(status, str):
        lines.append(f"Baseline Diff: {status}")
        if status == "ok":
            flash_delta = regressions.get("flash_delta_bytes", 0)
            ram_delta = regressions.get("ram_delta_bytes", 0)
            lines.append(f"- flash_delta_bytes: {flash_delta}")
            lines.append(f"- ram_delta_bytes: {ram_delta}")

            top_regressions = regressions.get("top_regressions")
            if isinstance(top_regressions, list) and top_regressions:
                lines.append("Top Regressions:")
                for item in top_regressions[:3]:
                    if isinstance(item, dict):
                        lines.append(
                            f"- {item.get('kind')}:{item.get('name')} delta={item.get('delta')}"
                        )

    if output_paths:
        rendered_paths = [
            (name, path)
            for name, path in sorted(output_paths.items())
            if path is not None
        ]
        if rendered_paths:
            lines.append("Report Outputs:")
            for name, path in rendered_paths:
                lines.append(f"- {name}: {path}")

    return "\n".join(lines)


def _top_regions(utilization_by_region: dict[str, float]) -> list[str]:
    ranked = sorted(
        utilization_by_region.items(),
        key=lambda item: (item[1], item[0]),
        reverse=True,
    )
    lines: list[str] = []
    for region_name, ratio in ranked[:5]:
        lines.append(f"- {region_name}: {ratio * 100:.1f}%")
    return lines
