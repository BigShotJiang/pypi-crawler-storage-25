"""Diff domain models and shared utilities."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any, Literal

Number = int | float
DiffStatus = Literal[
    "ok",
    "baseline_missing",
    "baseline_unreadable",
    "baseline_invalid",
    "current_unreadable",
    "current_invalid",
    "schema_mismatch",
]
EntryStatus = Literal["added", "removed", "changed", "unchanged"]


@dataclass(slots=True)
class DiffEntry:
    """Numeric delta for a named entity."""

    kind: str
    name: str
    status: EntryStatus
    current: Number
    baseline: Number
    delta: Number
    delta_pct: float | None
    details: dict[str, object] = field(default_factory=dict)

    def to_dict(self) -> dict[str, object]:
        return {
            "kind": self.kind,
            "name": self.name,
            "status": self.status,
            "current": self.current,
            "baseline": self.baseline,
            "delta": self.delta,
            "delta_pct": self.delta_pct,
            "details": dict(sorted(self.details.items())),
        }


@dataclass(slots=True)
class DiffBuildInfo:
    """Identifying info for one side of the diff — enough for a reader to tell
    which source file produced which numbers."""

    path: str | None = None
    target_name: str | None = None
    analysis_timestamp: str | None = None
    tool_version: str | None = None
    total_flash: int = 0
    total_ram: int = 0

    def to_dict(self) -> dict[str, object]:
        return {
            "path": self.path,
            "target_name": self.target_name,
            "analysis_timestamp": self.analysis_timestamp,
            "tool_version": self.tool_version,
            "total_flash": self.total_flash,
            "total_ram": self.total_ram,
        }


@dataclass(slots=True)
class DiffReport:
    """Top-level diff report emitted by analyze+diff flows."""

    status: DiffStatus = "ok"
    baseline_path: str | None = None
    current_schema_version: str | None = None
    baseline_schema_version: str | None = None
    schema_compatible: bool = True
    schema_error: str | None = None
    flash_delta_bytes: int = 0
    ram_delta_bytes: int = 0
    current_build: DiffBuildInfo = field(default_factory=DiffBuildInfo)
    baseline_build: DiffBuildInfo = field(default_factory=DiffBuildInfo)
    regions: list[DiffEntry] = field(default_factory=list)
    sections: list[DiffEntry] = field(default_factory=list)
    symbols: list[DiffEntry] = field(default_factory=list)
    components: list[DiffEntry] = field(default_factory=list)
    top_regressions: list[dict[str, object]] = field(default_factory=list)
    top_reductions: list[dict[str, object]] = field(default_factory=list)
    added_large_symbols: list[dict[str, object]] = field(default_factory=list)
    removed_symbols: list[str] = field(default_factory=list)
    removed_components: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, object]:
        return {
            "status": self.status,
            "baseline_path": self.baseline_path,
            "current_schema_version": self.current_schema_version,
            "baseline_schema_version": self.baseline_schema_version,
            "schema_compatible": self.schema_compatible,
            "schema_error": self.schema_error,
            "flash_delta_bytes": self.flash_delta_bytes,
            "ram_delta_bytes": self.ram_delta_bytes,
            "current_build": self.current_build.to_dict(),
            "baseline_build": self.baseline_build.to_dict(),
            "regions": [item.to_dict() for item in self.regions],
            "sections": [item.to_dict() for item in self.sections],
            "symbols": [item.to_dict() for item in self.symbols],
            "components": [item.to_dict() for item in self.components],
            "top_regressions": list(self.top_regressions),
            "top_reductions": list(self.top_reductions),
            "added_large_symbols": list(self.added_large_symbols),
            "removed_symbols": list(self.removed_symbols),
            "removed_components": list(self.removed_components),
        }


def compare_named_numeric_values(
    *,
    kind: str,
    current: Mapping[str, Number],
    baseline: Mapping[str, Number],
    details_by_name: dict[str, dict[str, object]] | None = None,
) -> list[DiffEntry]:
    """Compare two numeric maps and emit per-entity delta entries."""
    details_by_name = details_by_name or {}
    names = sorted(set(current) | set(baseline))
    result: list[DiffEntry] = []

    for name in names:
        cur = current.get(name, 0)
        base = baseline.get(name, 0)
        delta = cur - base

        if name not in baseline:
            status: EntryStatus = "added"
        elif name not in current:
            status = "removed"
        elif delta != 0:
            status = "changed"
        else:
            status = "unchanged"

        delta_pct: float | None
        if base == 0:
            delta_pct = None if cur != 0 else 0.0
        else:
            delta_pct = float(delta) / float(base)

        result.append(
            DiffEntry(
                kind=kind,
                name=name,
                status=status,
                current=cur,
                baseline=base,
                delta=delta,
                delta_pct=delta_pct,
                details=details_by_name.get(name, {}),
            )
        )

    return sorted(result, key=lambda item: (-abs(float(item.delta)), item.kind, item.name))


def extract_number(value: object, *, default: Number = 0) -> Number:
    if isinstance(value, bool):
        return default
    if isinstance(value, (int, float)):
        return value
    return default


def as_mapping(value: object) -> dict[str, Any]:
    if isinstance(value, dict):
        return {str(key): child for key, child in value.items()}
    return {}


def as_list(value: object) -> list[object]:
    if isinstance(value, list):
        return value
    return []
