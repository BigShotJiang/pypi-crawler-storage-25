"""Diff ranking and rendering helpers."""

from __future__ import annotations

import html
import json

from memscope.diff.model import DiffEntry
from memscope.licensing.labels import chip_css_for, chip_label_for, watermark_text_for
from memscope.licensing.models import LicenseStatus


def rank_top_regressions(entries: list[DiffEntry], *, limit: int = 10) -> list[dict[str, object]]:
    ranked = sorted(
        (entry for entry in entries if float(entry.delta) > 0),
        key=lambda entry: (-float(entry.delta), entry.kind, entry.name),
    )
    return [
        {
            "kind": entry.kind,
            "name": entry.name,
            "delta": entry.delta,
            "delta_pct": entry.delta_pct,
            "status": entry.status,
        }
        for entry in ranked[:limit]
    ]


def rank_top_reductions(entries: list[DiffEntry], *, limit: int = 10) -> list[dict[str, object]]:
    ranked = sorted(
        (entry for entry in entries if float(entry.delta) < 0),
        key=lambda entry: (float(entry.delta), entry.kind, entry.name),
    )
    return [
        {
            "kind": entry.kind,
            "name": entry.name,
            "delta": entry.delta,
            "delta_pct": entry.delta_pct,
            "status": entry.status,
        }
        for entry in ranked[:limit]
    ]


def added_large_symbols(entries: list[DiffEntry], *, min_size_bytes: int = 1024) -> list[dict[str, object]]:
    ranked = sorted(
        (
            entry
            for entry in entries
            if entry.kind == "symbol"
            and entry.status == "added"
            and int(entry.current) >= min_size_bytes
        ),
        key=lambda entry: (-int(entry.current), entry.name),
    )
    return [
        {"name": entry.name, "size": int(entry.current), "min_size_bytes": min_size_bytes}
        for entry in ranked
    ]


def render_diff_console_summary(
    diff_payload: dict[str, object],
    *,
    output_paths: dict[str, str | None] | None = None,
    license_status: LicenseStatus | None = None,
) -> str:
    status = str(diff_payload.get("status", "unknown"))
    lines = [
        "MemScope Diff Summary",
        f"Status: {status}",
    ]
    if license_status is not None:
        lines.append(f"License: {chip_label_for(license_status.state.value)}")
    lines.extend(
        [
            f"Current schema: {diff_payload.get('current_schema_version') or 'unknown'}",
            f"Baseline schema: {diff_payload.get('baseline_schema_version') or 'unknown'}",
        ]
    )

    if status == "ok":
        lines.extend(
            [
                f"Flash delta: {int(_as_number(diff_payload.get('flash_delta_bytes')))} B",
                f"RAM delta: {int(_as_number(diff_payload.get('ram_delta_bytes')))} B",
            ]
        )
        top_regressions = _as_list(diff_payload.get("top_regressions"))
        if top_regressions:
            lines.append("Top Regressions:")
            for item in top_regressions[:5]:
                entry = _as_mapping(item)
                lines.append(
                    f"- {entry.get('kind')}:{entry.get('name')} delta={entry.get('delta')}"
                )

        top_reductions = _as_list(diff_payload.get("top_reductions"))
        if top_reductions:
            lines.append("Top Reductions:")
            for item in top_reductions[:5]:
                entry = _as_mapping(item)
                lines.append(
                    f"- {entry.get('kind')}:{entry.get('name')} delta={entry.get('delta')}"
                )
    else:
        schema_error = diff_payload.get("schema_error")
        if schema_error:
            lines.append(f"Schema error: {schema_error}")

    if output_paths:
        resolved = [(name, path) for name, path in sorted(output_paths.items()) if path]
        if resolved:
            lines.append("Diff Outputs:")
            for name, path in resolved:
                lines.append(f"- {name}: {path}")

    return "\n".join(lines)


def render_diff_html(
    diff_payload: dict[str, object],
    *,
    license_status: LicenseStatus | None = None,
) -> str:
    top_regressions_list = _as_list(diff_payload.get("top_regressions"))
    top_reductions_list = _as_list(diff_payload.get("top_reductions"))
    regions_list = _as_list(diff_payload.get("regions"))
    top_regressions = json.dumps(top_regressions_list, indent=2)
    top_reductions = json.dumps(top_reductions_list, indent=2)
    regions = json.dumps(regions_list, indent=2)
    sections = json.dumps(_as_list(diff_payload.get("sections")), indent=2)
    symbols = json.dumps(_as_list(diff_payload.get("symbols")), indent=2)
    components = json.dumps(_as_list(diff_payload.get("components")), indent=2)
    diff_chart_entries = _safe_script_json(
        _build_diff_chart_entries(top_regressions_list, top_reductions_list)
    )
    flash_delta = int(_as_number(diff_payload.get("flash_delta_bytes")))
    ram_delta = int(_as_number(diff_payload.get("ram_delta_bytes")))
    status = html.escape(str(diff_payload.get("status", "unknown")))
    regressions_rows = _render_diff_table_rows(top_regressions_list)
    reductions_rows = _render_diff_table_rows(top_reductions_list)
    region_strip = _render_region_delta_strip(regions_list)
    comparison_card = _render_comparison_card(
        _as_mapping(diff_payload.get("current_build")),
        _as_mapping(diff_payload.get("baseline_build")),
    )

    flash_badge_class = "negative" if flash_delta > 0 else "positive" if flash_delta < 0 else "neutral"
    ram_badge_class = "negative" if ram_delta > 0 else "positive" if ram_delta < 0 else "neutral"
    flash_delta_text = f"{flash_delta:+,} B"
    ram_delta_text = f"{ram_delta:+,} B"
    status_class = {
        "ok": "ok",
        "schema_mismatch": "warn",
    }.get(str(diff_payload.get("status") or "").lower(), "warn")
    license_chip_html = _render_diff_license_chip(license_status)
    license_watermark_html = _render_diff_license_watermark(license_status)

    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>MemScope Diff Report</title>
  <style>
    /* Design tokens aligned with the analyze HTML (see outputs/html_renderer.py). */
    :root {{
      --bg: #0f131a;
      --bg-alt: #141c27;
      --panel: #1a2635;
      --panel-alt: #223146;
      --panel-soft: #1e2d40;
      --text: #e8f0ff;
      --muted: #a7b6cc;
      --text-dim: #7f8faa;
      --accent: #4f8cff;
      --accent-2: #22c1ff;
      --warning: #f0b45a;
      --error: #ec6d86;
      --ok: #61c98f;
      --line: #35506e;
      --line-strong: #4b6a8d;
      --shadow: 0 10px 28px rgba(0, 0, 0, 0.42);
      --font-sans: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      --font-mono: "Aptos Mono", "Consolas", "SF Mono", Menlo, Monaco, monospace;
      --report-max-width: clamp(900px, 92vw, 1600px);
    }}
    * {{
      box-sizing: border-box;
    }}
    body {{
      margin: 0;
      padding: 0;
      font-family: var(--font-sans);
      background:
        radial-gradient(1100px 500px at 85% -10%, rgba(34, 193, 255, 0.14), transparent 60%),
        radial-gradient(900px 420px at 10% 110%, rgba(79, 140, 255, 0.12), transparent 55%),
        var(--bg);
      color: var(--text);
      line-height: 1.5;
      -webkit-font-smoothing: antialiased;
    }}
    .wrap {{
      max-width: var(--report-max-width);
      margin: 0 auto;
      padding: 24px 32px 48px;
    }}
    .appbar {{
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 14px 32px;
      background: linear-gradient(180deg, rgba(26, 38, 53, 0.85), rgba(26, 38, 53, 0.55));
      border-bottom: 1px solid var(--line);
      backdrop-filter: blur(8px);
      position: sticky;
      top: 0;
      z-index: 10;
    }}
    .appbar-title {{
      font-size: 0.95rem;
      font-weight: 600;
      letter-spacing: 0.02em;
    }}
    .appbar-chip {{
      font-size: 0.72rem;
      font-family: var(--font-mono);
      padding: 3px 10px;
      border-radius: 999px;
      border: 1px solid var(--line);
      color: var(--muted);
      background: rgba(255, 255, 255, 0.03);
    }}
    .appbar-chip.is-status-ok {{
      color: var(--ok);
      border-color: color-mix(in srgb, var(--ok) 55%, var(--line));
    }}
    .appbar-chip.is-status-warn {{
      color: var(--warning);
      border-color: color-mix(in srgb, var(--warning) 55%, var(--line));
    }}
    .appbar-chip.is-license-active {{
      color: var(--ok);
      border-color: color-mix(in srgb, var(--ok) 45%, var(--line));
    }}
    .appbar-chip.is-license-trial {{
      color: var(--warning);
      border-color: color-mix(in srgb, var(--warning) 45%, var(--line));
    }}
    .appbar-chip.is-license-free {{
      color: var(--text-dim);
      border-color: color-mix(in srgb, var(--text-dim) 45%, var(--line));
    }}
    .appbar-chip.is-license-dev {{
      color: var(--accent-2);
      border-color: color-mix(in srgb, var(--accent-2) 55%, var(--line));
    }}
    .appbar-chip.is-license-expired,
    .appbar-chip.is-license-invalid,
    .appbar-chip.is-license-revoked {{
      color: var(--error);
      border-color: color-mix(in srgb, var(--error) 55%, var(--line));
    }}
    .ms-diff-watermark {{
      display: inline-block;
      margin-top: 8px;
      padding: 4px 10px;
      border-radius: 6px;
      border: 1px solid var(--warning);
      color: var(--warning);
      font-family: var(--font-mono);
      font-size: 0.72rem;
      letter-spacing: 0.05em;
      text-transform: uppercase;
    }}
    .ms-diff-watermark.is-error {{
      border-color: var(--error);
      color: var(--error);
    }}
    .ms-diff-watermark.is-dev {{
      border-color: var(--accent-2);
      color: var(--accent-2);
    }}
    .ms-diff-watermark.is-free {{
      border-color: var(--text-dim);
      color: var(--text-dim);
    }}
    .header {{
      padding: 18px 0 26px;
      border-bottom: 1px solid var(--line);
      margin-bottom: 26px;
    }}
    .header h1 {{
      margin: 0 0 6px;
      font-size: 1.6rem;
      letter-spacing: -0.01em;
    }}
    .header .subtitle {{
      color: var(--muted);
      font-size: 0.88rem;
      display: flex;
      gap: 18px;
      flex-wrap: wrap;
    }}
    .section {{
      background: linear-gradient(180deg, var(--panel), var(--panel-soft));
      border: 1px solid var(--line);
      border-radius: 14px;
      padding: 20px 22px;
      margin-bottom: 22px;
      box-shadow: var(--shadow);
    }}
    .section-title {{
      margin: 0 0 12px;
      font-size: 1.1rem;
      font-weight: 600;
      letter-spacing: 0.01em;
      color: var(--text);
    }}
    .summary-note {{
      margin: 0 0 14px;
      color: var(--muted);
      font-size: 0.88rem;
    }}
    .badge-row {{
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin-top: 4px;
    }}
    .badge {{
      border: 1px solid var(--line);
      border-radius: 999px;
      padding: 5px 12px;
      font-size: 0.85rem;
      color: var(--muted);
      background: rgba(255, 255, 255, 0.025);
      font-variant-numeric: tabular-nums;
    }}
    .badge.positive {{
      color: var(--ok);
      border-color: color-mix(in srgb, var(--ok) 55%, var(--line));
      background: color-mix(in srgb, var(--ok) 10%, transparent);
    }}
    .badge.negative {{
      color: var(--error);
      border-color: color-mix(in srgb, var(--error) 55%, var(--line));
      background: color-mix(in srgb, var(--error) 10%, transparent);
    }}
    .badge.neutral {{
      color: var(--muted);
    }}
    .chart-wrap {{
      margin-top: 18px;
      padding: 14px 12px 4px;
      border: 1px solid var(--line);
      border-radius: 10px;
      background: color-mix(in srgb, var(--panel-alt) 60%, transparent);
    }}
    .chart-wrap h3 {{
      margin: 0 0 8px;
      font-size: 0.95rem;
      color: var(--muted);
      font-weight: 500;
    }}
    canvas {{
      width: 100%;
      height: 280px;
      display: block;
    }}
    table {{
      width: 100%;
      border-collapse: collapse;
      font-size: 0.9rem;
      font-variant-numeric: tabular-nums;
    }}
    th, td {{
      border-bottom: 1px solid var(--line);
      text-align: left;
      vertical-align: top;
      padding: 9px 8px;
    }}
    th {{
      font-weight: 600;
      font-size: 0.8rem;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      color: var(--muted);
      background: rgba(255, 255, 255, 0.02);
    }}
    td {{
      color: var(--text);
    }}
    td.delta-pos {{
      color: var(--error);
      font-weight: 700;
    }}
    td.delta-neg {{
      color: var(--ok);
      font-weight: 700;
    }}
    td.is-mono {{
      font-family: var(--font-mono);
      font-size: 0.85rem;
    }}
    .kind-cell {{
      text-transform: uppercase;
      font-size: 0.72rem;
      letter-spacing: 0.06em;
      color: var(--muted);
    }}
    .status-cell {{
      font-size: 0.8rem;
      color: var(--text-dim);
    }}
    details {{
      margin-top: 12px;
      border: 1px solid var(--line);
      border-radius: 10px;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--panel-alt) 55%, transparent);
    }}
    summary {{
      cursor: pointer;
      color: var(--muted);
      font-size: 0.88rem;
      font-weight: 500;
    }}
    summary:hover {{
      color: var(--text);
    }}
    pre {{
      overflow: auto;
      white-space: pre-wrap;
      word-break: break-word;
      margin-top: 12px;
      padding: 12px;
      background: var(--bg-alt);
      border-radius: 8px;
      border: 1px solid var(--line);
      font-family: var(--font-mono);
      font-size: 0.82rem;
      color: var(--text-dim);
    }}
    .ms-diff-comparison {{
      padding: 18px 22px;
    }}
    .ms-diff-legend {{
      display: flex;
      flex-wrap: wrap;
      gap: 10px 16px;
      margin-bottom: 16px;
      padding-bottom: 14px;
      border-bottom: 1px solid var(--line);
    }}
    .ms-diff-legend-pill {{
      display: inline-flex;
      align-items: center;
      gap: 8px;
      font-size: 0.82rem;
      color: var(--muted);
    }}
    .ms-diff-legend-swatch {{
      width: 14px;
      height: 14px;
      border-radius: 4px;
      border: 1px solid var(--line);
    }}
    .ms-diff-legend-pill--grew .ms-diff-legend-swatch {{
      background: var(--error);
      border-color: color-mix(in srgb, var(--error) 60%, var(--line));
    }}
    .ms-diff-legend-pill--shrank .ms-diff-legend-swatch {{
      background: var(--ok);
      border-color: color-mix(in srgb, var(--ok) 60%, var(--line));
    }}
    .ms-diff-columns {{
      display: grid;
      grid-template-columns: 1fr auto 1fr;
      gap: 16px;
      align-items: stretch;
    }}
    @media (max-width: 780px) {{
      .ms-diff-columns {{
        grid-template-columns: 1fr;
      }}
      .ms-diff-arrow {{
        justify-self: center;
      }}
    }}
    .ms-diff-column {{
      padding: 14px 16px;
      border-radius: 10px;
      border: 1px solid var(--line);
      background: color-mix(in srgb, var(--panel-alt) 55%, transparent);
    }}
    .ms-diff-column--current {{
      border-left: 3px solid var(--error);
    }}
    .ms-diff-column--baseline {{
      border-left: 3px solid var(--ok);
    }}
    .ms-diff-column-role {{
      font-size: 0.72rem;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--muted);
      font-weight: 600;
      margin-bottom: 4px;
    }}
    .ms-diff-column--current .ms-diff-column-role {{
      color: var(--error);
    }}
    .ms-diff-column--baseline .ms-diff-column-role {{
      color: var(--ok);
    }}
    .ms-diff-column-file {{
      font-size: 0.95rem;
      color: var(--text);
      font-weight: 600;
      margin-bottom: 10px;
      word-break: break-all;
    }}
    .ms-diff-meta {{
      display: grid;
      gap: 4px;
    }}
    .ms-diff-meta-row {{
      display: grid;
      grid-template-columns: 110px 1fr;
      gap: 10px;
      font-size: 0.82rem;
    }}
    .ms-diff-meta-label {{
      color: var(--muted);
    }}
    .ms-diff-meta-value {{
      color: var(--text);
      font-variant-numeric: tabular-nums;
    }}
    .ms-diff-arrow {{
      align-self: center;
      font-family: var(--font-mono);
      color: var(--muted);
      font-size: 0.9rem;
      padding: 0 4px;
    }}
    .ms-region-delta-list {{
      list-style: none;
      padding: 0;
      margin: 4px 0 0;
      display: grid;
      gap: 10px;
    }}
    .ms-region-delta-row {{
      display: grid;
      grid-template-columns: minmax(160px, 220px) 1fr minmax(120px, 160px);
      grid-template-rows: auto auto;
      align-items: center;
      gap: 4px 14px;
    }}
    .ms-region-delta-name {{
      font-size: 0.86rem;
      color: var(--text);
      font-weight: 500;
      grid-row: 1;
      grid-column: 1;
    }}
    .ms-region-delta-rail {{
      position: relative;
      height: 10px;
      background: color-mix(in srgb, var(--panel-alt) 55%, transparent);
      border-radius: 999px;
      overflow: hidden;
      border: 1px solid var(--line);
      grid-row: 1;
      grid-column: 2;
    }}
    .ms-region-delta-bar {{
      position: absolute;
      left: 0;
      top: 0;
      height: 100%;
      border-radius: 999px;
      transition: width 240ms cubic-bezier(0.4, 0, 0.2, 1);
    }}
    .ms-region-delta-bar--up {{
      background: linear-gradient(90deg, color-mix(in srgb, var(--error) 70%, transparent), var(--error));
    }}
    .ms-region-delta-bar--down {{
      background: linear-gradient(90deg, color-mix(in srgb, var(--ok) 70%, transparent), var(--ok));
    }}
    .ms-region-delta-bar--flat {{
      background: var(--text-dim);
    }}
    .ms-region-delta-value {{
      text-align: right;
      font-size: 0.85rem;
      font-weight: 600;
      grid-row: 1;
      grid-column: 3;
    }}
    .ms-region-delta-row[data-direction="up"] .ms-region-delta-value {{
      color: var(--error);
    }}
    .ms-region-delta-row[data-direction="down"] .ms-region-delta-value {{
      color: var(--ok);
    }}
    .ms-region-delta-context {{
      grid-column: 1 / -1;
      grid-row: 2;
      font-size: 0.75rem;
      color: var(--muted);
      font-family: var(--font-mono);
      padding-left: 2px;
    }}
  </style>
</head>
<body>
  <div class="appbar">
    <span class="appbar-title">MemScope Diff</span>
    <span class="appbar-chip is-status-{status_class}">Status: {status}</span>
    {license_chip_html}
  </div>
  <div class="wrap">
    <header class="header">
      <h1>Build-to-build comparison</h1>
      {license_watermark_html}
      <p class="subtitle">
        <span>Flash delta: {flash_delta_text}</span>
        <span>RAM delta: {ram_delta_text}</span>
      </p>
    </header>

    {comparison_card}

    <section class="section">
      <h2 class="section-title">Headline deltas</h2>
      <p class="summary-note">
        Red bars and positive numbers (e.g. <strong>+4,521 B</strong>) mean the
        <strong>current</strong> build uses <strong>more</strong> than the baseline.
        Green bars and negative numbers (e.g. <strong>-1,280 B</strong>) mean the
        current build is leaner.
      </p>
      <div class="badge-row">
        <span class="badge {flash_badge_class}">Flash delta: {flash_delta_text}</span>
        <span class="badge {ram_badge_class}">RAM delta: {ram_delta_text}</span>
      </div>
      <div class="chart-wrap">
        <h3>Diff Impact Chart</h3>
        <canvas id="diff-impact-chart"></canvas>
      </div>
    </section>

    {region_strip}

    <section class="section">
      <h2 class="section-title">Top Regressions</h2>
      <p class="summary-note">Largest byte-level increases current-vs-baseline.</p>
      <table>
        <thead>
          <tr><th>Kind</th><th>Name</th><th>Delta</th><th>Status</th></tr>
        </thead>
        <tbody>
          {regressions_rows}
        </tbody>
      </table>
    </section>

    <section class="section">
      <h2 class="section-title">Top Reductions</h2>
      <p class="summary-note">Largest byte-level decreases current-vs-baseline.</p>
      <table>
        <thead>
          <tr><th>Kind</th><th>Name</th><th>Delta</th><th>Status</th></tr>
        </thead>
        <tbody>
          {reductions_rows}
        </tbody>
      </table>
    </section>

    <section class="section">
      <h2 class="section-title">Detailed Entity Diff</h2>
      <p class="summary-note">Full per-entity JSON for scripts and audits. Expand a panel to see raw records.</p>
      <details>
        <summary>Regions</summary>
        <pre>{html.escape(regions)}</pre>
      </details>
      <details>
        <summary>Sections</summary>
        <pre>{html.escape(sections)}</pre>
      </details>
      <details>
        <summary>Symbols</summary>
        <pre>{html.escape(symbols)}</pre>
      </details>
      <details>
        <summary>Components</summary>
        <pre>{html.escape(components)}</pre>
      </details>
      <details>
        <summary>Raw ranked entries</summary>
        <pre>{html.escape(top_regressions)}</pre>
        <pre>{html.escape(top_reductions)}</pre>
      </details>
    </section>
  </div>
  <script id="memscope-diff-chart-data" type="application/json">{diff_chart_entries}</script>
  <script>
    function parseChartData() {{
      const node = document.getElementById("memscope-diff-chart-data");
      if (!node || !node.textContent) return [];
      try {{
        return JSON.parse(node.textContent);
      }} catch (_error) {{
        return [];
      }}
    }}

    function setupCanvas(id, minHeight) {{
      const canvas = document.getElementById(id);
      if (!canvas) return null;
      const dpr = window.devicePixelRatio || 1;
      const width = Math.max(320, Math.floor(canvas.clientWidth || 320));
      const height = minHeight;
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      const ctx = canvas.getContext("2d");
      if (!ctx) return null;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      return {{ ctx, width, height }};
    }}

    function drawDiffChart() {{
      const entries = parseChartData();
      const setup = setupCanvas("diff-impact-chart", 280);
      if (!setup) return;
      const ctx = setup.ctx;
      const width = setup.width;
      const height = setup.height;
      // Chart colors match the dark design-token palette.
      const line = "#35506e";
      const text = "#e8f0ff";
      const good = "#61c98f";
      const bad = "#ec6d86";
      const muted = "#a7b6cc";

      ctx.clearRect(0, 0, width, height);
      if (!entries.length) {{
        ctx.fillStyle = muted;
        ctx.font = "13px system-ui, -apple-system, Segoe UI, Roboto, sans-serif";
        ctx.fillText("No diff chart entries available.", 12, 28);
        return;
      }}

      const centerX = Math.floor(width * 0.56);
      const top = 14;
      const rowHeight = Math.max(22, Math.floor((height - top - 8) / entries.length));
      const barHeight = Math.max(10, Math.floor(rowHeight * 0.5));
      const maxAbs = Math.max(1, ...entries.map((entry) => Math.abs(Number(entry.delta) || 0)));

      ctx.strokeStyle = line;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(centerX, 8);
      ctx.lineTo(centerX, height - 8);
      ctx.stroke();

      entries.forEach((entry, index) => {{
        const delta = Number(entry.delta) || 0;
        const ratio = Math.abs(delta) / maxAbs;
        const maxBarWidth = Math.floor(width * 0.35);
        const barWidth = Math.max(2, Math.floor(maxBarWidth * ratio));
        const y = top + index * rowHeight;
        const labelRaw = String(entry.label || "unknown");
        const label = labelRaw.length > 28 ? labelRaw.slice(0, 25) + "\\u2026" : labelRaw;

        const isRegression = delta > 0;
        const x = isRegression ? centerX : centerX - barWidth;
        ctx.fillStyle = isRegression ? bad : good;
        ctx.fillRect(x, y, barWidth, barHeight);

        ctx.fillStyle = text;
        ctx.font = "12px system-ui, -apple-system, Segoe UI, Roboto, sans-serif";
        ctx.fillText(label, 8, y + barHeight);
        const deltaText = (delta > 0 ? "+" : "") + delta.toFixed(0) + " B";
        const textWidth = ctx.measureText(deltaText).width;
        const dx = isRegression ? x + barWidth + 6 : x - textWidth - 6;
        ctx.fillText(deltaText, dx, y + barHeight);
      }});
    }}

    window.addEventListener("resize", function () {{
      window.clearTimeout(window.__memscopeDiffResizeTimer);
      window.__memscopeDiffResizeTimer = window.setTimeout(drawDiffChart, 80);
    }});
    drawDiffChart();
  </script>
</body>
</html>"""


def _render_comparison_card(current: dict[str, object], baseline: dict[str, object]) -> str:
    """Render a two-column header panel that identifies both sides of the diff."""
    def _meta_row(label: str, value: object) -> str:
        if value in (None, "", 0):
            return ""
        return (
            '<div class="ms-diff-meta-row">'
            f'<span class="ms-diff-meta-label">{html.escape(label)}</span>'
            f'<span class="ms-diff-meta-value is-mono">{html.escape(str(value))}</span>'
            "</div>"
        )

    def _bytes_row(label: str, value: object) -> str:
        n = 0
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            n = int(value)
        if n == 0:
            return ""
        return (
            '<div class="ms-diff-meta-row">'
            f'<span class="ms-diff-meta-label">{html.escape(label)}</span>'
            f'<span class="ms-diff-meta-value is-mono">{n:,} B</span>'
            "</div>"
        )

    def _column(role: str, role_label: str, info: dict[str, object]) -> str:
        path = info.get("path") or ""
        path_short = str(path).replace("\\", "/").rsplit("/", 1)[-1] if path else "(no file supplied)"
        target = info.get("target_name") or "unknown"
        timestamp = info.get("analysis_timestamp") or ""
        tool_version = info.get("tool_version") or ""
        total_flash = info.get("total_flash")
        total_ram = info.get("total_ram")

        meta_rows = [
            _meta_row("Target", target),
            _meta_row("Analyzed", str(timestamp).split("T", 1)[0] if timestamp else ""),
            _meta_row("Tool version", tool_version),
            _bytes_row("Total FLASH", total_flash),
            _bytes_row("Total RAM", total_ram),
        ]
        return (
            f'<div class="ms-diff-column ms-diff-column--{role}">'
            f'<div class="ms-diff-column-role">{html.escape(role_label)}</div>'
            f'<div class="ms-diff-column-file is-mono" title="{html.escape(str(path))}">{html.escape(path_short)}</div>'
            f'<div class="ms-diff-meta">{"".join(meta_rows)}</div>'
            f'</div>'
        )

    current_col = _column("current", "Current", current)
    baseline_col = _column("baseline", "Baseline", baseline)

    return f"""
    <section class="section ms-diff-comparison">
      <div class="ms-diff-legend">
        <span class="ms-diff-legend-pill ms-diff-legend-pill--grew">
          <span class="ms-diff-legend-swatch"></span>Red / positive = Current > Baseline (grew)
        </span>
        <span class="ms-diff-legend-pill ms-diff-legend-pill--shrank">
          <span class="ms-diff-legend-swatch"></span>Green / negative = Current &lt; Baseline (shrank)
        </span>
      </div>
      <div class="ms-diff-columns">
        {current_col}
        <div class="ms-diff-arrow" aria-hidden="true">vs.</div>
        {baseline_col}
      </div>
    </section>"""


def _safe_script_json(value: object) -> str:
    """Encode ``value`` for safe embedding inside an HTML ``<script>`` tag.

    Two constraints we have to satisfy:

    1. Browsers do NOT decode HTML entities inside ``<script>`` content
       (it's "raw text"), so the content must be literal JSON. The previous
       implementation passed it through ``html.escape`` which converted
       ``"`` to ``&quot;`` — that broke ``JSON.parse`` and the canvas
       chart silently rendered "no diff chart entries available".
    2. JSON content can theoretically contain a literal ``</script>``
       substring (e.g., a section name like ``</script>foo``). To prevent
       that prematurely closing the script tag, we replace ``<`` with the
       JSON unicode escape ``\\u003c`` (and ``>`` for symmetry). JSON.parse
       still decodes ``\\u003c`` as ``<``, so the runtime data is intact.
    """
    encoded = json.dumps(value, ensure_ascii=False)
    return encoded.replace("<", "\\u003c").replace(">", "\\u003e")


def _render_region_delta_strip(regions: list[object]) -> str:
    """Build the per-region delta-bar strip section, or '' when no data."""
    rows = []
    parsed: list[tuple[str, float, float, float]] = []
    for entry in regions:
        mapping = _as_mapping(entry)
        kind = str(mapping.get("kind", "")).strip()
        if kind != "region":
            continue
        name = str(mapping.get("name", "")).strip()
        if not name:
            continue
        delta = _as_number(mapping.get("delta"))
        current = _as_number(mapping.get("current"))
        baseline = _as_number(mapping.get("baseline"))
        parsed.append((name, delta, current, baseline))

    if not parsed:
        return ""

    max_abs = max((abs(delta) for _, delta, _, _ in parsed), default=0.0)
    if max_abs == 0:
        return ""
    parsed.sort(key=lambda item: abs(item[1]), reverse=True)
    parsed = parsed[:12]

    for name, delta, current, baseline in parsed:
        ratio_pct = max(2.0, min(100.0, (abs(delta) / max_abs) * 100.0))
        direction = "up" if delta > 0 else "down" if delta < 0 else "flat"
        # Region utilization values are 0..1 ratios — show them as % deltas.
        is_ratio = abs(current) <= 1.5 and abs(baseline) <= 1.5
        if is_ratio:
            delta_label = f"{delta * 100:+.1f}% util"
            current_label = f"{current * 100:.1f}% → {baseline * 100:.1f}% baseline"
        else:
            delta_label = f"{delta:+,.0f} B"
            current_label = f"{int(current):,} B vs {int(baseline):,} B baseline"
        rows.append(
            f'<li class="ms-region-delta-row" data-direction="{direction}">'
            f'<span class="ms-region-delta-name is-mono">{html.escape(name)}</span>'
            f'<span class="ms-region-delta-rail">'
            f'<span class="ms-region-delta-bar ms-region-delta-bar--{direction}" '
            f'style="width:{ratio_pct:.1f}%"></span>'
            f'</span>'
            f'<span class="ms-region-delta-value is-mono">{html.escape(delta_label)}</span>'
            f'<span class="ms-region-delta-context">{html.escape(current_label)}</span>'
            f'</li>'
        )

    return f"""
    <section class="section">
      <h2 class="section-title">Per-region delta vs baseline</h2>
      <p class="summary-note">
        Each bar is proportional to the absolute delta (current vs baseline).
        Red bars on the right grew; green bars on the left shrank.
      </p>
      <ul class="ms-region-delta-list">
        {"".join(rows)}
      </ul>
    </section>"""


def _render_diff_license_chip(license_status: LicenseStatus | None) -> str:
    if license_status is None:
        return ""
    state = license_status.state.value
    chip_class = chip_css_for(state)
    label = chip_label_for(state)
    return (
        f'<span class="appbar-chip {chip_class}" title="License mode">'
        f'License: {html.escape(label)}</span>'
    )


def _render_diff_license_watermark(license_status: LicenseStatus | None) -> str:
    if license_status is None:
        return ""
    state = license_status.state.value
    text = watermark_text_for(state)
    if not text:
        return ""
    if state == "developer-mode":
        css_class = "is-dev"
    elif state == "free":
        css_class = "is-free"
    elif state in {"expired", "invalid", "revoked"}:
        css_class = "is-error"
    else:
        css_class = ""
    return f'<div class="ms-diff-watermark {css_class}">{html.escape(text)}</div>'


def _render_diff_table_rows(entries: list[object]) -> str:
    if not entries:
        return (
            '<tr><td colspan="4" style="color: var(--muted); '
            'text-align: center; padding: 16px;">No entries.</td></tr>'
        )

    rows: list[str] = []
    for item in entries[:10]:
        mapping = _as_mapping(item)
        kind = html.escape(str(mapping.get("kind", "unknown")))
        name = html.escape(str(mapping.get("name", "unknown")))
        delta_value = _as_number(mapping.get("delta"))
        delta_text = f"{delta_value:+,.0f} B"
        status = html.escape(str(mapping.get("status", "unknown")))
        delta_class = "delta-pos" if delta_value > 0 else "delta-neg" if delta_value < 0 else ""
        rows.append(
            f'<tr>'
            f'<td class="kind-cell">{kind}</td>'
            f'<td class="is-mono">{name}</td>'
            f'<td class="{delta_class}">{delta_text}</td>'
            f'<td class="status-cell">{status}</td>'
            f'</tr>'
        )
    return "".join(rows)


def _build_diff_chart_entries(regressions: list[object], reductions: list[object]) -> list[dict[str, object]]:
    entries: list[dict[str, object]] = []
    for item in regressions[:6]:
        mapping = _as_mapping(item)
        delta = _as_number(mapping.get("delta"))
        if delta <= 0:
            continue
        entries.append({"label": f"{mapping.get('kind')}:{mapping.get('name')}", "delta": delta})
    for item in reductions[:6]:
        mapping = _as_mapping(item)
        delta = _as_number(mapping.get("delta"))
        if delta >= 0:
            continue
        entries.append({"label": f"{mapping.get('kind')}:{mapping.get('name')}", "delta": delta})
    return sorted(entries, key=lambda entry: abs(_as_number(entry.get("delta"))), reverse=True)[:10]


def _as_list(value: object) -> list[object]:
    if isinstance(value, list):
        return value
    return []


def _as_mapping(value: object) -> dict[str, object]:
    if isinstance(value, dict):
        return {str(key): child for key, child in value.items()}
    return {}


def _as_number(value: object) -> float:
    if isinstance(value, bool):
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    return 0.0
