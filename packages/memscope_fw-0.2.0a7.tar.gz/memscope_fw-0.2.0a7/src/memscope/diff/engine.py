"""Diff orchestration and baseline compatibility checks."""

from __future__ import annotations

import json
from collections.abc import Mapping
from pathlib import Path

from memscope.diff.compare_components import compare_components
from memscope.diff.compare_regions import compare_regions
from memscope.diff.compare_sections import compare_sections
from memscope.diff.compare_symbols import compare_symbols
from memscope.diff.model import DiffBuildInfo, DiffReport, as_mapping, extract_number
from memscope.diff.render_helpers import (
    added_large_symbols,
    rank_top_reductions,
    rank_top_regressions,
)
from memscope.domain.schema import is_backward_compatible, parse_schema_version


def load_report_payload(path: Path) -> tuple[dict[str, object] | None, str | None]:
    try:
        # Accept UTF-8 files with or without BOM (common in Windows editors).
        raw = path.read_text(encoding="utf-8-sig")
    except OSError as exc:
        return None, f"read_error: {exc}"

    try:
        payload = json.loads(raw)
    except ValueError as exc:
        return None, f"json_error: {exc}"

    if not isinstance(payload, dict):
        return None, "invalid_root: expected JSON object"
    return {str(key): value for key, value in payload.items()}, None


def compare_report_files(current_json_path: Path, baseline_json_path: Path) -> DiffReport:
    current_payload, current_error = load_report_payload(current_json_path)
    if current_payload is None:
        return DiffReport(
            status="current_unreadable",
            baseline_path=str(baseline_json_path),
            schema_compatible=False,
            schema_error=current_error,
        )

    baseline_payload, baseline_error = load_report_payload(baseline_json_path)
    if baseline_payload is None:
        return DiffReport(
            status="baseline_unreadable",
            baseline_path=str(baseline_json_path),
            schema_compatible=False,
            schema_error=baseline_error,
        )

    return compare_report_payloads(
        current_payload,
        baseline_payload,
        baseline_path=str(baseline_json_path),
        current_path=str(current_json_path),
    )


def compare_with_baseline_file(
    current_payload: Mapping[str, object],
    baseline_json_path: Path,
) -> DiffReport:
    if not baseline_json_path.exists():
        return DiffReport(
            status="baseline_missing",
            baseline_path=str(baseline_json_path),
            schema_compatible=False,
            schema_error="baseline path does not exist",
        )

    baseline_payload, baseline_error = load_report_payload(baseline_json_path)
    if baseline_payload is None:
        return DiffReport(
            status="baseline_unreadable",
            baseline_path=str(baseline_json_path),
            schema_compatible=False,
            schema_error=baseline_error,
        )

    return compare_report_payloads(
        current_payload,
        baseline_payload,
        baseline_path=str(baseline_json_path),
    )


def compare_report_payloads(
    current_payload: Mapping[str, object],
    baseline_payload: Mapping[str, object],
    *,
    baseline_path: str | None = None,
    current_path: str | None = None,
) -> DiffReport:
    current_schema = _schema_version(current_payload)
    baseline_schema = _schema_version(baseline_payload)
    schema_ok, schema_error = _schema_compatibility(current_schema, baseline_schema)
    current_build = _build_info(current_payload, path=current_path)
    baseline_build = _build_info(baseline_payload, path=baseline_path)

    if not schema_ok:
        return DiffReport(
            status="schema_mismatch",
            baseline_path=baseline_path,
            current_schema_version=current_schema,
            baseline_schema_version=baseline_schema,
            schema_compatible=False,
            schema_error=schema_error,
            current_build=current_build,
            baseline_build=baseline_build,
        )

    current_summary = as_mapping(current_payload.get("summary"))
    baseline_summary = as_mapping(baseline_payload.get("summary"))

    flash_delta = int(extract_number(current_summary.get("total_flash"), default=0)) - int(
        extract_number(baseline_summary.get("total_flash"), default=0)
    )
    ram_delta = int(extract_number(current_summary.get("total_ram"), default=0)) - int(
        extract_number(baseline_summary.get("total_ram"), default=0)
    )

    regions = compare_regions(current_payload, baseline_payload)
    sections = compare_sections(current_payload, baseline_payload)
    symbols = compare_symbols(current_payload, baseline_payload)
    components = compare_components(current_payload, baseline_payload)

    all_entries = [*regions, *sections, *symbols, *components]
    top_regressions = rank_top_regressions(all_entries, limit=15)
    top_reductions = rank_top_reductions(all_entries, limit=15)
    large_added_symbols = added_large_symbols(symbols, min_size_bytes=1024)

    removed_symbols = sorted(
        entry.name for entry in symbols if entry.status == "removed"
    )
    removed_components = sorted(
        entry.name for entry in components if entry.status == "removed"
    )

    return DiffReport(
        status="ok",
        baseline_path=baseline_path,
        current_schema_version=current_schema,
        baseline_schema_version=baseline_schema,
        schema_compatible=True,
        schema_error=None,
        flash_delta_bytes=flash_delta,
        ram_delta_bytes=ram_delta,
        current_build=current_build,
        baseline_build=baseline_build,
        regions=regions,
        sections=sections,
        symbols=symbols,
        components=components,
        top_regressions=top_regressions,
        top_reductions=top_reductions,
        added_large_symbols=large_added_symbols,
        removed_symbols=removed_symbols,
        removed_components=removed_components,
    )


def _build_info(payload: Mapping[str, object], *, path: str | None) -> DiffBuildInfo:
    metadata = as_mapping(payload.get("metadata"))
    summary = as_mapping(payload.get("summary"))

    def _text(value: object) -> str | None:
        if isinstance(value, str) and value.strip():
            return value.strip()
        return None

    return DiffBuildInfo(
        path=path,
        target_name=_text(metadata.get("target_name")),
        analysis_timestamp=_text(metadata.get("analysis_timestamp")),
        tool_version=_text(metadata.get("tool_version")),
        total_flash=int(extract_number(summary.get("total_flash"), default=0)),
        total_ram=int(extract_number(summary.get("total_ram"), default=0)),
    )


def _schema_version(payload: Mapping[str, object]) -> str | None:
    metadata = as_mapping(payload.get("metadata"))
    version = metadata.get("schema_version")
    if isinstance(version, str) and version.strip():
        return version.strip()
    return None


def _schema_compatibility(
    current_schema: str | None,
    baseline_schema: str | None,
) -> tuple[bool, str | None]:
    if current_schema is None:
        return False, "current report missing metadata.schema_version"
    if baseline_schema is None:
        return False, "baseline report missing metadata.schema_version"

    try:
        parse_schema_version(current_schema)
    except ValueError as exc:
        return False, f"current schema version invalid: {exc}"

    try:
        parse_schema_version(baseline_schema)
    except ValueError as exc:
        return False, f"baseline schema version invalid: {exc}"

    if not is_backward_compatible(baseline_schema, current_schema):
        return (
            False,
            f"baseline schema {baseline_schema} is not backward compatible with current schema {current_schema}",
        )

    return True, None
