"""Component comparison helpers."""

from __future__ import annotations

from collections.abc import Mapping

from memscope.diff.model import (
    DiffEntry,
    as_list,
    as_mapping,
    compare_named_numeric_values,
    extract_number,
)


def compare_components(
    current_payload: Mapping[str, object],
    baseline_payload: Mapping[str, object],
) -> list[DiffEntry]:
    current_components = as_list(current_payload.get("components"))
    baseline_components = as_list(baseline_payload.get("components"))

    current_values: dict[str, int] = {}
    baseline_values: dict[str, int] = {}
    details_by_name: dict[str, dict[str, object]] = {}

    for item in current_components:
        component = as_mapping(item)
        name = str(component.get("name", "")).strip()
        if not name:
            continue
        flash = int(extract_number(component.get("total_flash"), default=0))
        ram = int(extract_number(component.get("total_ram"), default=0))
        current_values[name] = flash + ram
        details_by_name.setdefault(name, {})["flash_current"] = flash
        details_by_name[name]["ram_current"] = ram

    for item in baseline_components:
        component = as_mapping(item)
        name = str(component.get("name", "")).strip()
        if not name:
            continue
        flash = int(extract_number(component.get("total_flash"), default=0))
        ram = int(extract_number(component.get("total_ram"), default=0))
        baseline_values[name] = flash + ram
        details_by_name.setdefault(name, {})["flash_baseline"] = flash
        details_by_name[name]["ram_baseline"] = ram

    return compare_named_numeric_values(
        kind="component",
        current=current_values,
        baseline=baseline_values,
        details_by_name=details_by_name,
    )
