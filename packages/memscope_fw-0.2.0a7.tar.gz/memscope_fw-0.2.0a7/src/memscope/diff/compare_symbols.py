"""Symbol comparison helpers."""

from __future__ import annotations

from collections.abc import Mapping

from memscope.diff.model import (
    DiffEntry,
    as_list,
    as_mapping,
    compare_named_numeric_values,
    extract_number,
)


def compare_symbols(
    current_payload: Mapping[str, object],
    baseline_payload: Mapping[str, object],
) -> list[DiffEntry]:
    current_symbols = _symbols_list(current_payload)
    baseline_symbols = _symbols_list(baseline_payload)

    current_values: dict[str, int] = {}
    baseline_values: dict[str, int] = {}
    details_by_name: dict[str, dict[str, object]] = {}

    for item in current_symbols:
        symbol = as_mapping(item)
        name = str(symbol.get("name", "")).strip()
        if not name:
            continue
        size = int(extract_number(symbol.get("size"), default=0))
        current_values[name] = size
        details_by_name.setdefault(name, {})["section_name_current"] = symbol.get("section_name")
        details_by_name[name]["object_file_current"] = symbol.get("object_file")

    for item in baseline_symbols:
        symbol = as_mapping(item)
        name = str(symbol.get("name", "")).strip()
        if not name:
            continue
        size = int(extract_number(symbol.get("size"), default=0))
        baseline_values[name] = size
        details_by_name.setdefault(name, {})["section_name_baseline"] = symbol.get("section_name")
        details_by_name[name]["object_file_baseline"] = symbol.get("object_file")

    return compare_named_numeric_values(
        kind="symbol",
        current=current_values,
        baseline=baseline_values,
        details_by_name=details_by_name,
    )


def _symbols_list(payload: Mapping[str, object]) -> list[object]:
    symbols_summary = as_mapping(payload.get("symbols_summary"))
    return as_list(symbols_summary.get("symbols"))
