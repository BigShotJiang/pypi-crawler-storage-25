"""Section comparison helpers."""

from __future__ import annotations

from collections.abc import Mapping

from memscope.diff.model import (
    DiffEntry,
    as_list,
    as_mapping,
    compare_named_numeric_values,
    extract_number,
)


def compare_sections(
    current_payload: Mapping[str, object],
    baseline_payload: Mapping[str, object],
) -> list[DiffEntry]:
    current_sections = as_list(current_payload.get("sections"))
    baseline_sections = as_list(baseline_payload.get("sections"))

    current_values: dict[str, int] = {}
    baseline_values: dict[str, int] = {}
    details_by_name: dict[str, dict[str, object]] = {}

    for item in current_sections:
        section = as_mapping(item)
        name = str(section.get("name", "")).strip()
        if not name:
            continue
        size = int(extract_number(section.get("size"), default=0))
        current_values[name] = size
        details_by_name.setdefault(name, {})["execution_region_current"] = section.get("execution_region")
        details_by_name[name]["load_region_current"] = section.get("load_region")

    for item in baseline_sections:
        section = as_mapping(item)
        name = str(section.get("name", "")).strip()
        if not name:
            continue
        size = int(extract_number(section.get("size"), default=0))
        baseline_values[name] = size
        details_by_name.setdefault(name, {})["execution_region_baseline"] = section.get("execution_region")
        details_by_name[name]["load_region_baseline"] = section.get("load_region")

    return compare_named_numeric_values(
        kind="section",
        current=current_values,
        baseline=baseline_values,
        details_by_name=details_by_name,
    )
