"""Region comparison helpers."""

from __future__ import annotations

from collections.abc import Mapping

from memscope.diff.model import DiffEntry, as_mapping, compare_named_numeric_values, extract_number


def compare_regions(
    current_payload: Mapping[str, object],
    baseline_payload: Mapping[str, object],
) -> list[DiffEntry]:
    current_summary = as_mapping(current_payload.get("summary"))
    baseline_summary = as_mapping(baseline_payload.get("summary"))

    current_utilization = as_mapping(current_summary.get("utilization_by_region"))
    baseline_utilization = as_mapping(baseline_summary.get("utilization_by_region"))

    current_values = {
        name: float(extract_number(value, default=0.0))
        for name, value in current_utilization.items()
    }
    baseline_values = {
        name: float(extract_number(value, default=0.0))
        for name, value in baseline_utilization.items()
    }

    return compare_named_numeric_values(
        kind="region",
        current=current_values,
        baseline=baseline_values,
    )
