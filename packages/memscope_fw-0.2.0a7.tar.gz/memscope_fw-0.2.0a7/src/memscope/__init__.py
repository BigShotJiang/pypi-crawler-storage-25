"""MemScope package root.

Exposes ``__version__`` resolved at import time from the installed
distribution metadata. The single source of truth is the latest
``vX.Y.Z`` git tag — hatch-vcs embeds that into the wheel at build
time, ``importlib.metadata`` reads it back here. See Phase 30 Wave A
in `docs/internal/release/distribution-plan.md`.

Source-tree fallback: when imported from a checkout that has no
installed wheel (e.g. running tests from a fresh clone before
``pip install -e .``), ``PackageNotFoundError`` is raised by
``importlib.metadata`` and we return ``"0.0.0+unknown"`` so the rest
of the codebase can keep stringifying it without a special case.
"""

from importlib.metadata import PackageNotFoundError, version

__all__ = ["__version__"]

try:
    # PyPI distribution name is `memscope-fw` (Python import stays
    # `memscope` — see `[project] name` in pyproject.toml for the
    # rationale). importlib.metadata keys on the distribution name.
    __version__ = version("memscope-fw")
except PackageNotFoundError:
    __version__ = "0.0.0+unknown"
