"""GNU-family adapter from parser records to normalized domain entities."""

from __future__ import annotations

from dataclasses import dataclass

from memscope.domain import (
    MemoryRegion,
    MemoryRegionCategory,
    RegionSourceOrigin,
    SectionPlacement,
    SymbolEntry,
)
from memscope.domain.value_objects import AttributeSet
from memscope.parsers.models import (
    MemoryRegionRecord,
    ParsedArtifactSet,
    SymbolRecord,
    ToolchainKind,
)
from memscope.toolchains.base import NormalizedBuildModel
from memscope.toolchains.core_inference import infer_region_core_assignments


@dataclass(slots=True)
class _RegionAggregate:
    start_address: int
    size: int
    attributes: set[str]
    sources: set[str]

    @property
    def end_address(self) -> int:
        return self.start_address + self.size - 1


class GNUToolchainAdapter:
    """Normalize GNU/LLD-compatible parse outputs."""

    def normalize(self, parsed: ParsedArtifactSet) -> NormalizedBuildModel:
        regions = self._normalize_regions(parsed)
        sections = self._normalize_sections(parsed)
        symbols = self._normalize_symbols(parsed, sections)
        stack_heap_hints = self._stack_heap_hints(sections, symbols)
        core_assignments = _multicore_region_assignments(regions)

        assumptions = list(parsed.assumptions)
        ambiguities = list(parsed.unresolved_ambiguities)

        if parsed.toolchain_detected == ToolchainKind.UNKNOWN:
            assumptions.append("adapter.gnu_fallback_for_unknown_toolchain")
        if any(section.size == 0 for section in sections):
            assumptions.append("section_sizes_may_be_partial_for_linker_only_rules")
        if core_assignments:
            assumptions.append("multicore.region_name_inference")

        unresolved_section_regions = [
            section.name for section in sections if section.execution_region is None
        ]
        if unresolved_section_regions:
            ambiguities.append(
                "sections_without_execution_region="
                + ",".join(sorted(set(unresolved_section_regions)))
            )

        return NormalizedBuildModel(
            toolchain=parsed.toolchain_detected
            if parsed.toolchain_detected != ToolchainKind.UNKNOWN
            else ToolchainKind.GNU,
            memory_regions=regions,
            sections=sections,
            symbols=symbols,
            stack_heap_hints=stack_heap_hints,
            core_assignments=core_assignments,
            parse_assumptions=tuple(dict.fromkeys(assumptions)),
            unresolved_ambiguities=tuple(dict.fromkeys(ambiguities)),
        )

    def _normalize_regions(self, parsed: ParsedArtifactSet) -> list[MemoryRegion]:
        aggregates: dict[str, _RegionAggregate] = {}

        for record in self._iter_region_records(parsed):
            existing = aggregates.get(record.name)
            if existing is None:
                aggregates[record.name] = _RegionAggregate(
                    start_address=record.start_address,
                    size=record.size,
                    attributes=set(record.attributes),
                    sources={record.source},
                )
                continue

            if record.size > existing.size:
                existing.start_address = record.start_address
                existing.size = record.size
            existing.attributes.update(record.attributes)
            existing.sources.add(record.source)

        normalized: list[MemoryRegion] = []
        for name, aggregate in aggregates.items():
            category = _infer_region_category(name, aggregate.attributes)
            origin = (
                RegionSourceOrigin.LINKER
                if {"linker", "map"} & aggregate.sources
                else RegionSourceOrigin.INFERRED
            )
            normalized.append(
                MemoryRegion(
                    name=name,
                    category=category,
                    start_address=aggregate.start_address,
                    end_address=aggregate.end_address,
                    size=aggregate.size,
                    attributes=AttributeSet.from_iterable(aggregate.attributes),
                    source_origin=origin,
                )
            )

        return sorted(normalized, key=lambda region: (region.start_address, region.name))

    @staticmethod
    def _iter_region_records(parsed: ParsedArtifactSet) -> list[MemoryRegionRecord]:
        records: list[MemoryRegionRecord] = []
        for artifact in (parsed.linker, parsed.map, parsed.elf):
            if artifact is not None:
                records.extend(artifact.memory_regions)
        return records

    def _normalize_sections(self, parsed: ParsedArtifactSet) -> list[SectionPlacement]:
        map_sections = parsed.map.sections if parsed.map else []
        linker_sections = parsed.linker.sections if parsed.linker else []
        linker_by_name = {section.name: section for section in linker_sections}

        normalized: list[SectionPlacement] = []
        consumed_linker_names: set[str] = set()

        for section in map_sections:
            linker_hint = linker_by_name.get(section.name)
            if linker_hint:
                consumed_linker_names.add(section.name)
            normalized.append(
                SectionPlacement(
                    name=section.name,
                    execution_region=(
                        section.execution_region
                        or (linker_hint.execution_region if linker_hint else None)
                    ),
                    load_region=section.load_region or (linker_hint.load_region if linker_hint else None),
                    vma=section.vma,
                    lma=section.lma,
                    size=section.size,
                    input_contributors=("map", "linker") if linker_hint else ("map",),
                )
            )

        for section in linker_sections:
            if section.name in consumed_linker_names:
                continue
            normalized.append(
                SectionPlacement(
                    name=section.name,
                    execution_region=section.execution_region,
                    load_region=section.load_region,
                    vma=section.vma,
                    lma=section.lma,
                    size=section.size,
                    input_contributors=("linker",),
                )
            )

        return sorted(normalized, key=lambda section: (section.vma, section.name))

    def _normalize_symbols(
        self,
        parsed: ParsedArtifactSet,
        sections: list[SectionPlacement],
    ) -> list[SymbolEntry]:
        section_ranges = [
            (section.name, section.vma, section.vma + section.size)
            for section in sections
            if section.size > 0
        ]

        symbols: list[SymbolEntry] = []
        map_symbols = parsed.map.symbols if parsed.map else []

        for symbol in map_symbols:
            inferred_section = _infer_symbol_section(symbol, section_ranges)
            section_name = _resolve_symbol_section(symbol.section_name, inferred_section)
            symbols.append(
                SymbolEntry(
                    name=symbol.name,
                    symbol_type="map_symbol",
                    section_name=section_name,
                    address=symbol.address,
                    size=symbol.size,
                    object_file=symbol.object_file,
                )
            )

        return sorted(symbols, key=lambda symbol: (symbol.address if symbol.address is not None else -1, symbol.name))

    def _stack_heap_hints(
        self,
        sections: list[SectionPlacement],
        symbols: list[SymbolEntry],
    ) -> dict[str, tuple[str, ...]]:
        stack_sections = tuple(
            sorted({section.name for section in sections if "stack" in section.name.lower()})
        )
        heap_sections = tuple(
            sorted({section.name for section in sections if "heap" in section.name.lower()})
        )
        stack_symbols = tuple(
            sorted(
                {
                    symbol.name
                    for symbol in symbols
                    if symbol.name and ("stack" in symbol.name.lower() or "sp_" in symbol.name.lower())
                }
            )
        )
        heap_symbols = tuple(
            sorted(
                {
                    symbol.name
                    for symbol in symbols
                    if symbol.name and "heap" in symbol.name.lower()
                }
            )
        )

        notes: list[str] = []
        if not stack_sections and not stack_symbols:
            notes.append("no_explicit_stack_marker_detected")
        if not heap_sections and not heap_symbols:
            notes.append("no_explicit_heap_marker_detected")

        return {
            "stack_sections": stack_sections,
            "heap_sections": heap_sections,
            "stack_symbols": stack_symbols,
            "heap_symbols": heap_symbols,
            "notes": tuple(notes),
        }


def _infer_region_category(name: str, attributes: set[str]) -> MemoryRegionCategory:
    lowered = name.lower()
    if "itcm" in lowered or "dtcm" in lowered or "tcm" in lowered:
        return MemoryRegionCategory.TCM
    if "retention" in lowered or "standby" in lowered:
        return MemoryRegionCategory.RETENTION
    if "ext" in lowered and "flash" in lowered:
        return MemoryRegionCategory.EXTERNAL_FLASH
    if "ext" in lowered and "ram" in lowered:
        return MemoryRegionCategory.EXTERNAL_RAM
    if "flash" in lowered:
        return MemoryRegionCategory.FLASH
    if "ram" in lowered or "sram" in lowered:
        return MemoryRegionCategory.RAM

    attr_set = {attr.lower() for attr in attributes}
    if "x" in attr_set and "w" not in attr_set:
        return MemoryRegionCategory.FLASH
    if "w" in attr_set or "rw" in attr_set:
        return MemoryRegionCategory.RAM
    return MemoryRegionCategory.CUSTOM


def _infer_symbol_section(
    symbol: SymbolRecord,
    ranges: list[tuple[str, int, int]],
) -> str | None:
    for section_name, start, end in ranges:
        if start <= symbol.address < end:
            return section_name
    return None


def _resolve_symbol_section(hint: str | None, inferred: str | None) -> str | None:
    normalized_hint = (hint or "").strip()
    if normalized_hint in {"", ".code", ".data"}:
        return inferred or (normalized_hint if normalized_hint else None)
    return normalized_hint


def _multicore_region_assignments(regions: list[MemoryRegion]) -> dict[str, str]:
    inferred = infer_region_core_assignments(region.name for region in regions)
    if len(set(inferred.values())) <= 1:
        return {}
    return inferred
