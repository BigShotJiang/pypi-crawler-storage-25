"""Shared core-name inference helpers for multicore-aware analysis."""

from __future__ import annotations

import re
from collections.abc import Iterable

_CORE_CPU_PATTERN = re.compile(r"(?:^|[^a-z0-9])(core|cpu)[_-]?(?P<id>\d+)(?:$|[^a-z0-9])", re.IGNORECASE)
_CM_PATTERN = re.compile(r"(?:^|[^a-z0-9])cm(?P<id>\d+)(?:$|[^a-z0-9])", re.IGNORECASE)
_CORTEX_M_PATTERN = re.compile(r"(?:^|[^a-z0-9])cortex[_-]?m(?P<id>\d+)(?:$|[^a-z0-9])", re.IGNORECASE)


def infer_core_from_text(value: str | None) -> str | None:
    """Infer a normalized core identifier from free-form text."""
    if not value:
        return None
    normalized = value.strip().lower()
    if not normalized:
        return None

    match = _CORE_CPU_PATTERN.search(normalized)
    if match:
        return f"core{match.group('id')}"

    match = _CM_PATTERN.search(normalized)
    if match:
        return f"cm{match.group('id')}"

    match = _CORTEX_M_PATTERN.search(normalized)
    if match:
        return f"cm{match.group('id')}"

    return None


def infer_region_core_assignments(region_names: Iterable[str]) -> dict[str, str]:
    """Infer core assignments from region naming conventions."""
    assignments: dict[str, str] = {}
    for region_name in region_names:
        core_id = infer_core_from_text(region_name)
        if core_id is not None:
            assignments[region_name] = core_id
    return dict(sorted(assignments.items()))
