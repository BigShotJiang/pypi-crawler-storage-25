"""Toolchain adapter selection and normalization entrypoint."""

from __future__ import annotations

from memscope.parsers.models import ParsedArtifactSet, ToolchainKind
from memscope.toolchains.base import NormalizedBuildModel, ToolchainAdapter
from memscope.toolchains.clang_lld import ClangLLDToolchainAdapter
from memscope.toolchains.gnu import GNUToolchainAdapter
from memscope.toolchains.iar import IARToolchainAdapter
from memscope.toolchains.keil import KeilToolchainAdapter


def get_adapter(toolchain: ToolchainKind) -> ToolchainAdapter:
    if toolchain == ToolchainKind.CLANG_LLD:
        return ClangLLDToolchainAdapter()
    if toolchain == ToolchainKind.IAR:
        return IARToolchainAdapter()
    if toolchain == ToolchainKind.KEIL:
        return KeilToolchainAdapter()
    return GNUToolchainAdapter()


def normalize_parsed_artifacts(parsed: ParsedArtifactSet) -> NormalizedBuildModel:
    adapter = get_adapter(parsed.toolchain_detected)
    return adapter.normalize(parsed)
