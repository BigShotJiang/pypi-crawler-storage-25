"""Clang/LLD compatibility adapter (delegates to GNU semantics for v1)."""

from __future__ import annotations

from memscope.parsers.models import ParsedArtifactSet, ToolchainKind
from memscope.toolchains.base import NormalizedBuildModel
from memscope.toolchains.gnu import GNUToolchainAdapter


class ClangLLDToolchainAdapter:
    """Reuse GNU normalization while flagging compatibility assumptions."""

    def __init__(self) -> None:
        self._gnu = GNUToolchainAdapter()

    def normalize(self, parsed: ParsedArtifactSet) -> NormalizedBuildModel:
        normalized = self._gnu.normalize(parsed)
        assumptions = list(normalized.parse_assumptions)
        assumptions.append("clang_lld_compatibility_mode")
        normalized.parse_assumptions = tuple(dict.fromkeys(assumptions))
        if normalized.toolchain == ToolchainKind.GNU:
            normalized.toolchain = ToolchainKind.CLANG_LLD
        return normalized

