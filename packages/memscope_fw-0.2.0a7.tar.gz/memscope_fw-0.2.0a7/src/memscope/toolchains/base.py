"""Toolchain adapter contracts and normalized model types."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol

from memscope.domain import MemoryRegion, SectionPlacement, SymbolEntry
from memscope.parsers.models import ParsedArtifactSet, ToolchainKind


@dataclass(slots=True)
class NormalizedBuildModel:
    """Toolchain-agnostic normalized model consumed by analysis layers."""

    toolchain: ToolchainKind
    memory_regions: list[MemoryRegion] = field(default_factory=list)
    sections: list[SectionPlacement] = field(default_factory=list)
    symbols: list[SymbolEntry] = field(default_factory=list)
    stack_heap_hints: dict[str, tuple[str, ...]] = field(default_factory=dict)
    core_assignments: dict[str, str] = field(default_factory=dict)
    parse_assumptions: tuple[str, ...] = ()
    unresolved_ambiguities: tuple[str, ...] = ()

    def to_debug_dict(self) -> dict[str, object]:
        return {
            "toolchain": self.toolchain.value,
            "memory_regions": [region.name for region in self.memory_regions],
            "sections": [section.name for section in self.sections],
            "symbols_count": len(self.symbols),
            "stack_heap_hints": {key: list(values) for key, values in self.stack_heap_hints.items()},
            "core_assignments": dict(sorted(self.core_assignments.items())),
            "parse_assumptions": list(self.parse_assumptions),
            "unresolved_ambiguities": list(self.unresolved_ambiguities),
        }


class ToolchainAdapter(Protocol):
    """Adapter contract from parser output to normalized domain model."""

    def normalize(self, parsed: ParsedArtifactSet) -> NormalizedBuildModel:
        ...
