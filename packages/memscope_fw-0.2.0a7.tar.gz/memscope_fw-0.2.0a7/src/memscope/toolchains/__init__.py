"""Toolchain adapter layer."""

from memscope.toolchains.base import NormalizedBuildModel, ToolchainAdapter
from memscope.toolchains.clang_lld import ClangLLDToolchainAdapter
from memscope.toolchains.factory import get_adapter, normalize_parsed_artifacts
from memscope.toolchains.gnu import GNUToolchainAdapter
from memscope.toolchains.iar import IARToolchainAdapter
from memscope.toolchains.keil import KeilToolchainAdapter

__all__ = [
    "ClangLLDToolchainAdapter",
    "GNUToolchainAdapter",
    "IARToolchainAdapter",
    "KeilToolchainAdapter",
    "NormalizedBuildModel",
    "ToolchainAdapter",
    "get_adapter",
    "normalize_parsed_artifacts",
]
