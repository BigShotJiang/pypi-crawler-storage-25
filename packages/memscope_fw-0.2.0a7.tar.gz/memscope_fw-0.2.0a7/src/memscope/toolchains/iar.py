"""IAR toolchain compatibility adapter."""

from __future__ import annotations

from memscope.parsers.models import ParsedArtifactSet, ToolchainKind
from memscope.toolchains.base import NormalizedBuildModel
from memscope.toolchains.gnu import GNUToolchainAdapter


class IARToolchainAdapter:
    """Reuse GNU normalization while marking IAR compatibility assumptions."""

    def __init__(self) -> None:
        self._gnu = GNUToolchainAdapter()

    def normalize(self, parsed: ParsedArtifactSet) -> NormalizedBuildModel:
        normalized = self._gnu.normalize(parsed)
        assumptions = list(normalized.parse_assumptions)
        assumptions.append("iar_compatibility_mode")
        normalized.parse_assumptions = tuple(dict.fromkeys(assumptions))
        normalized.toolchain = ToolchainKind.IAR
        return normalized
