"""Path/reference policy checks for local-only operation."""

from __future__ import annotations

import re

_SCHEME_PREFIX = re.compile(r"^(?P<scheme>[a-zA-Z][a-zA-Z0-9+.-]*):(?P<rest>/.*)$")
_WINDOWS_DRIVE_PREFIX = re.compile(r"^[a-zA-Z]:/")


def is_remote_reference(value: str) -> bool:
    """Return True when a path-like reference points to a network location."""
    normalized = value.strip()
    if not normalized:
        return False

    slash_normalized = normalized.replace("\\", "/")

    # UNC paths represent network shares and are treated as non-local.
    if slash_normalized.startswith("//"):
        return True

    # Drive-letter paths are local on Windows.
    if _WINDOWS_DRIVE_PREFIX.match(slash_normalized):
        return False

    scheme_match = _SCHEME_PREFIX.match(slash_normalized)
    if not scheme_match:
        return False

    scheme = scheme_match.group("scheme").lower()
    return scheme != "file"
