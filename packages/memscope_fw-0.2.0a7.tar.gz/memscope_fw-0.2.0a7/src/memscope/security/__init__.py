"""Security and locality policy helpers."""

from memscope.security.path_policy import is_remote_reference

__all__ = ["is_remote_reference"]
