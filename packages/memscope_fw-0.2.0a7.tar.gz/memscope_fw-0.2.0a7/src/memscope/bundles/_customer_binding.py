"""Customer-binding constants for Customer-Bound Wheels.

This file is REGENERATED at build time for Customer-Bound Wheels (with
real values from the customer's manifest YAML). For the free-core PyPI
distribution and editable installs, the constants below stay at their
empty-stub values, `CUSTOMER_BUNDLES` is empty, and no Bundle code
loads.

DO NOT edit by hand — the build pipeline overwrites this file. See
`docs/internal/handbook/bundle-architecture.md` for the build-step
mechanics and `scripts/build_customer_wheel.py` for the driver.
"""

from __future__ import annotations

CUSTOMER_NAME: str = ""
CUSTOMER_LICENSE_ID: str = ""
CUSTOMER_TIER: str = ""
CUSTOMER_EXPIRES: str = ""
CUSTOMER_BUILD_DATE: str = ""
CUSTOMER_BUNDLES: tuple[str, ...] = ()
