"""Entitlement-check API for Subscription Bundles.

Subscription Bundles call `verify_entitlement(bundle_name)` on first
run (and on periodic refresh) to confirm their license is still
valid. The implementation here is a thin wrapper that — once the
licensing service is wired in by a real Bundle — calls into
`memscope.licensing.LicenseService` and caches the resulting
activation receipt at `~/.memscope/bundles/<bundle_name>.lock`.

For the free-core distribution this module is dead code (no Bundle
ever calls it). It lives in the bundles package so that Bundles
have a single, stable entitlement API to import from regardless of
whether the licensing module's internals change in the future.

Architecture: `docs/internal/handbook/bundle-architecture.md`.
State-machine semantics: `docs/internal/handbook/licensing-state-machine.md`.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class EntitlementStatus:
    """Result of an entitlement check.

    `state` mirrors the per-Bundle 3-state machine documented in
    `licensing-state-machine.md`: `not_activated`, `active`, or
    `expired`. Bundles use `ok` as the boolean go/no-go for their
    runtime; `state` and `message` are for the user-facing
    diagnostics.
    """

    ok: bool
    state: str
    message: str


def verify_entitlement(bundle_name: str) -> EntitlementStatus:
    """Check whether the named Bundle has an active entitlement.

    Default implementation returns `not_activated` so Bundles built
    against this API can develop and test against a known stub. The
    first real Subscription Bundle (Phase 7 of the implementation
    plan) overrides this by calling into the licensing service
    directly and caching the result at
    `~/.memscope/bundles/<bundle_name>.lock`.

    The free core never calls this function. Bundles call it to
    decide whether to enable their gated features.
    """
    return EntitlementStatus(
        ok=False,
        state="not_activated",
        message=(
            f"Bundle '{bundle_name}' is not activated. "
            f"Run `memscope {bundle_name} activate <KEY>` to enable."
        ),
    )


__all__ = ["EntitlementStatus", "verify_entitlement"]
