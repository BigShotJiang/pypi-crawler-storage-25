"""Bundle contract — the protocol every commercial Bundle must implement.

A Bundle is a Python sub-package under `src/memscope/bundles/<name>/`
that registers CLI commands (and optionally report sections /
analyzers / hooks) with the MemScope core, and that ships only inside
Customer-Bound Wheels — never on PyPI.

The contract here is **stable**. Changes here cascade to every Bundle
and must coordinate with the design doc:
`docs/internal/handbook/bundle-architecture.md`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    import typer


@dataclass(frozen=True, slots=True)
class ActivationResult:
    """Outcome of `Bundle.activate()`.

    `ok=True` means the Bundle is ready to run; the host will register
    its CLI commands. `ok=False` means the Bundle should be skipped
    (e.g. its license has expired) — the host logs `message` and
    continues with the other Bundles.
    """

    ok: bool
    message: str


@runtime_checkable
class Bundle(Protocol):
    """Every Bundle's `bundle` module attribute must conform to this.

    The host imports `memscope.bundles.<name>` and reads its `bundle`
    attribute (set by the Bundle's `__init__.py`). The attribute must
    be an instance whose duck-type matches this Protocol.

    Method semantics:

    - `activate(self) -> ActivationResult` — called once on Bundle
      load. Subscription Bundles use this to validate their License
      Key against Keygen and cache an activation receipt; One-Time and
      Bespoke Bundles return `ok=True` immediately.
    - `register_cli_commands(self, app)` — Bundle adds its commands to
      the main Typer app, namespaced (e.g. `memscope <name> activate`,
      `memscope <name> post-comment`). Called only when `activate()`
      returned `ok=True`.
    """

    name: str
    version: str
    requires_entitlement: bool

    def activate(self) -> ActivationResult: ...

    def register_cli_commands(self, app: typer.Typer) -> None: ...
