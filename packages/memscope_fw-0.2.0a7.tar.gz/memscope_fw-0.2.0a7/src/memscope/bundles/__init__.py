"""Bundle registry for MemScope.

This module is the entry point for the optional commercial Bundles
system. The free `memscope-fw` core distribution on PyPI ships with
this module's `ENABLED_BUNDLES` empty — no Bundle code is included
in the wheel. `pip install memscope-fw` users see no Bundle behaviour.

Customer-Bound Wheels rebuild this file at build time with the
customer's purchased Bundle list. At runtime, the host
(`memscope.app.cli`) calls `load_enabled_bundles()` which imports
each enabled Bundle's sub-package and returns its `bundle` instance
ready to be wired into the CLI.

Architecture: `docs/internal/handbook/bundle-architecture.md`.
Build pipeline: `docs/internal/release/customer-wheel-rebuild-runbook.md`.
"""

from __future__ import annotations

import importlib
import logging
from typing import TYPE_CHECKING

from memscope.bundles._customer_binding import CUSTOMER_BUNDLES

if TYPE_CHECKING:
    from memscope.bundles._contract import Bundle

# The single source of truth for which Bundles this wheel was built
# with. The free wheel on PyPI has `CUSTOMER_BUNDLES = ()`; a
# Customer-Bound Wheel has the customer's purchased Bundle names.
ENABLED_BUNDLES: tuple[str, ...] = CUSTOMER_BUNDLES

_logger = logging.getLogger("memscope.bundles")


def load_enabled_bundles() -> list[Bundle]:
    """Import each enabled Bundle and return its `bundle` instance.

    Free-core wheel: returns `[]`. No Bundle subdirectories exist in
    the wheel; nothing is imported.

    Customer-Bound Wheel: returns one `Bundle` instance per enabled
    Bundle name in `ENABLED_BUNDLES`. The host (`cli.py`) iterates
    these and registers each Bundle's CLI commands.

    Import errors are logged at WARNING level and tolerated — a
    missing Bundle subdirectory means the wheel was built with a
    manifest that referenced a Bundle whose source isn't in this
    tree, but the free core should still operate. Activation errors
    raised by the Bundle's `__init__.py` are also tolerated for the
    same reason.
    """
    bundles: list[Bundle] = []
    for name in ENABLED_BUNDLES:
        try:
            module = importlib.import_module(f"memscope.bundles.{name}")
        except ImportError as exc:
            _logger.warning(
                "Bundle %r is in CUSTOMER_BUNDLES but its module is not "
                "importable; skipping. (%s)",
                name,
                exc,
            )
            continue
        bundle = getattr(module, "bundle", None)
        if bundle is None:
            _logger.warning(
                "Bundle %r imported but has no `bundle` attribute; "
                "skipping. The Bundle's __init__.py must expose its "
                "Bundle instance as `bundle = MyBundle()`.",
                name,
            )
            continue
        bundles.append(bundle)
    return bundles


__all__ = ["ENABLED_BUNDLES", "load_enabled_bundles"]
