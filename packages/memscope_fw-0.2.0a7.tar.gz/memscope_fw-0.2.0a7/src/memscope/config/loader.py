"""Config loader: defaults + TOML file + CLI overrides."""

from __future__ import annotations

import tomllib
from collections.abc import Mapping
from copy import deepcopy
from pathlib import Path

from memscope.config.defaults import ConfigDict, ConfigValue, get_default_config
from memscope.config.schema import MemscopeConfig
from memscope.config.validator import validate_or_raise
from memscope.security import is_remote_reference

DEFAULT_CONFIG_FILENAMES: tuple[str, ...] = (
    "memscope.toml",
    ".memscope.toml",
    "memscope.config.toml",
)


def _as_config_dict(data: Mapping[str, object]) -> ConfigDict:
    normalized: ConfigDict = {}
    for key, value in data.items():
        normalized[str(key)] = _coerce_config_value(value)
    return normalized


def _coerce_config_value(value: object) -> ConfigValue:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, list):
        return [_coerce_config_value(item) for item in value]
    if isinstance(value, Mapping):
        return _as_config_dict({str(key): child for key, child in value.items()})
    raise ValueError(f"Unsupported config value type: {type(value)!r}")


def _deep_merge(base: ConfigDict, override: Mapping[str, object]) -> ConfigDict:
    merged: ConfigDict = deepcopy(base)

    for key_raw, value in override.items():
        key = str(key_raw)
        existing = merged.get(key)
        if isinstance(existing, dict) and isinstance(value, Mapping):
            merged[key] = _deep_merge(existing, value)
        else:
            merged[key] = _coerce_config_value(deepcopy(value))
    return merged


def discover_config_path(search_root: Path | None = None) -> Path | None:
    root = (search_root or Path.cwd()).resolve()
    for filename in DEFAULT_CONFIG_FILENAMES:
        candidate = root / filename
        if candidate.is_file():
            return candidate
    return None


def load_config_file(path: Path) -> ConfigDict:
    if not path.is_file():
        raise FileNotFoundError(f"Config file not found: {path}")

    with path.open("rb") as file_handle:
        parsed = tomllib.load(file_handle)

    if not isinstance(parsed, dict):
        raise ValueError(f"Expected TOML object at top level in {path}")

    normalized = _as_config_dict(parsed)
    validate_or_raise(normalized)
    return normalized


def merge_config_layers(
    *,
    file_config: Mapping[str, object] | None = None,
    cli_overrides: Mapping[str, object] | None = None,
) -> ConfigDict:
    merged = get_default_config()
    if file_config:
        merged = _deep_merge(merged, file_config)
    if cli_overrides:
        merged = _deep_merge(merged, cli_overrides)
    validate_or_raise(merged)
    return merged


def load_config(
    config_path: Path | str | None = None,
    *,
    cli_overrides: Mapping[str, object] | None = None,
    search_root: Path | None = None,
) -> MemscopeConfig:
    file_config: ConfigDict | None
    resolved_path: Path | None
    if config_path is not None:
        if is_remote_reference(str(config_path)):
            raise ValueError("Remote config paths are not allowed in local-only mode.")
        resolved_path = Path(config_path).expanduser().resolve()
        file_config = load_config_file(resolved_path)
    else:
        resolved_path = discover_config_path(search_root)
        file_config = load_config_file(resolved_path) if resolved_path else None

    merged = merge_config_layers(file_config=file_config, cli_overrides=cli_overrides)
    return MemscopeConfig.from_dict(merged, source_path=resolved_path)
