"""Typed configuration schema models."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path


def _string_or_none(value: object, field_path: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError(f"{field_path}: expected string or null")
    normalized = value.strip()
    if not normalized:
        raise ValueError(f"{field_path}: expected non-empty string when provided")
    return normalized


def _bool(value: object, field_path: str) -> bool:
    if not isinstance(value, bool):
        raise ValueError(f"{field_path}: expected boolean")
    return value


def _int_or_none(value: object, field_path: str) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{field_path}: expected integer or null")
    return value


def _float_or_none(value: object, field_path: str) -> float | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{field_path}: expected number or null")
    return float(value)


def _ratio_map(value: object, field_path: str) -> dict[str, float]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{field_path}: expected table")

    parsed: dict[str, float] = {}
    for key, raw in value.items():
        normalized_key = str(key).strip()
        if not normalized_key:
            raise ValueError(f"{field_path}: found empty key")
        if isinstance(raw, bool) or not isinstance(raw, (int, float)):
            raise ValueError(f"{field_path}.{normalized_key}: expected number")
        parsed[normalized_key] = float(raw)
    return parsed


def _int_map(value: object, field_path: str) -> dict[str, int]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{field_path}: expected table")

    parsed: dict[str, int] = {}
    for key, raw in value.items():
        normalized_key = str(key).strip()
        if not normalized_key:
            raise ValueError(f"{field_path}: found empty key")
        if isinstance(raw, bool) or not isinstance(raw, int):
            raise ValueError(f"{field_path}.{normalized_key}: expected integer")
        parsed[normalized_key] = raw
    return parsed


def _group_patterns(value: object, field_path: str) -> dict[str, tuple[str, ...]]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{field_path}: expected table")

    groups: dict[str, tuple[str, ...]] = {}
    for group_name_raw, patterns_raw in value.items():
        group_name = str(group_name_raw).strip()
        if not group_name:
            raise ValueError(f"{field_path}: found empty group name")
        if not isinstance(patterns_raw, list):
            raise ValueError(f"{field_path}.{group_name}: expected list of patterns")

        patterns: list[str] = []
        for idx, pattern in enumerate(patterns_raw):
            if not isinstance(pattern, str) or not pattern.strip():
                raise ValueError(f"{field_path}.{group_name}[{idx}]: expected non-empty string")
            patterns.append(pattern.strip())

        groups[group_name] = tuple(sorted(set(patterns)))
    return groups


def _mapping(value: object, field_path: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{field_path}: expected table")
    normalized: dict[str, object] = {}
    for key, child_value in value.items():
        normalized[str(key)] = child_value
    return normalized


def _string_tuple(value: object, field_path: str) -> tuple[str, ...]:
    if value is None:
        return ()
    if not isinstance(value, list):
        raise ValueError(f"{field_path}: expected list of strings")

    normalized: list[str] = []
    for idx, item in enumerate(value):
        if not isinstance(item, str) or not item.strip():
            raise ValueError(f"{field_path}[{idx}]: expected non-empty string")
        normalized.append(item.strip())
    return tuple(sorted(set(normalized)))


@dataclass(slots=True)
class ProjectConfig:
    name: str | None = None
    toolchain: str | None = None

    @classmethod
    def from_dict(cls, data: Mapping[str, object]) -> ProjectConfig:
        return cls(
            name=_string_or_none(data.get("name"), "project.name"),
            toolchain=_string_or_none(data.get("toolchain"), "project.toolchain"),
        )


@dataclass(slots=True)
class InputsConfig:
    elf: str | None = None
    map: str | None = None
    linker: str | None = None

    @classmethod
    def from_dict(cls, data: Mapping[str, object]) -> InputsConfig:
        return cls(
            elf=_string_or_none(data.get("elf"), "inputs.elf"),
            map=_string_or_none(data.get("map"), "inputs.map"),
            linker=_string_or_none(data.get("linker"), "inputs.linker"),
        )


@dataclass(slots=True)
class ReportsConfig:
    html: str | None = None
    json: str | None = None
    csv: str | None = None
    enable_sankey_view: bool = False
    enable_relationship_graph_view: bool = False

    @classmethod
    def from_dict(cls, data: Mapping[str, object]) -> ReportsConfig:
        return cls(
            html=_string_or_none(data.get("html"), "reports.html"),
            json=_string_or_none(data.get("json"), "reports.json"),
            csv=_string_or_none(data.get("csv"), "reports.csv"),
            enable_sankey_view=_bool(
                data.get("enable_sankey_view", False),
                "reports.enable_sankey_view",
            ),
            enable_relationship_graph_view=_bool(
                data.get("enable_relationship_graph_view", False),
                "reports.enable_relationship_graph_view",
            ),
        )


@dataclass(slots=True)
class BudgetsConfig:
    flash: dict[str, float] = field(default_factory=dict)
    ram: dict[str, float] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Mapping[str, object]) -> BudgetsConfig:
        return cls(
            flash=_ratio_map(data.get("flash", {}), "budgets.flash"),
            ram=_ratio_map(data.get("ram", {}), "budgets.ram"),
        )


@dataclass(slots=True)
class PoliciesConfig:
    fail_on_overflow: bool = True
    fail_on_reserved_region_violation: bool = True
    warn_on_large_bss_symbol_kb: int | None = 8
    warn_on_near_capacity_ratio: float | None = 0.9
    max_ram_growth_bytes: int | None = None
    max_flash_growth_bytes: int | None = None
    partition_max_bytes: dict[str, int] = field(default_factory=dict)
    ota_source_regions: tuple[str, ...] = ()
    ota_slot_a_max_bytes: int | None = None
    ota_slot_b_max_bytes: int | None = None
    ota_warn_ratio: float | None = 0.9
    dma_section_patterns: tuple[str, ...] = ()
    dma_safe_regions: tuple[str, ...] = ()
    non_cacheable_section_patterns: tuple[str, ...] = ()
    non_cacheable_regions: tuple[str, ...] = ()
    cacheable_section_patterns: tuple[str, ...] = ()
    cacheable_regions: tuple[str, ...] = ()
    retention_section_patterns: tuple[str, ...] = ()
    retention_regions: tuple[str, ...] = ()
    forbidden_component_regions: dict[str, tuple[str, ...]] = field(default_factory=dict)
    suppress_issue_ids: tuple[str, ...] = ()
    suppress_issue_prefixes: tuple[str, ...] = ()
    suppress_categories: tuple[str, ...] = ()

    @classmethod
    def from_dict(cls, data: Mapping[str, object]) -> PoliciesConfig:
        return cls(
            fail_on_overflow=_bool(data.get("fail_on_overflow", True), "policies.fail_on_overflow"),
            fail_on_reserved_region_violation=_bool(
                data.get("fail_on_reserved_region_violation", True),
                "policies.fail_on_reserved_region_violation",
            ),
            warn_on_large_bss_symbol_kb=_int_or_none(
                data.get("warn_on_large_bss_symbol_kb", 8),
                "policies.warn_on_large_bss_symbol_kb",
            ),
            warn_on_near_capacity_ratio=_float_or_none(
                data.get("warn_on_near_capacity_ratio", 0.9),
                "policies.warn_on_near_capacity_ratio",
            ),
            max_ram_growth_bytes=_int_or_none(
                data.get("max_ram_growth_bytes", None),
                "policies.max_ram_growth_bytes",
            ),
            max_flash_growth_bytes=_int_or_none(
                data.get("max_flash_growth_bytes", None),
                "policies.max_flash_growth_bytes",
            ),
            partition_max_bytes=_int_map(
                data.get("partition_max_bytes", {}),
                "policies.partition_max_bytes",
            ),
            ota_source_regions=_string_tuple(
                data.get("ota_source_regions", []),
                "policies.ota_source_regions",
            ),
            ota_slot_a_max_bytes=_int_or_none(
                data.get("ota_slot_a_max_bytes", None),
                "policies.ota_slot_a_max_bytes",
            ),
            ota_slot_b_max_bytes=_int_or_none(
                data.get("ota_slot_b_max_bytes", None),
                "policies.ota_slot_b_max_bytes",
            ),
            ota_warn_ratio=_float_or_none(
                data.get("ota_warn_ratio", 0.9),
                "policies.ota_warn_ratio",
            ),
            dma_section_patterns=_string_tuple(
                data.get("dma_section_patterns", []),
                "policies.dma_section_patterns",
            ),
            dma_safe_regions=_string_tuple(
                data.get("dma_safe_regions", []),
                "policies.dma_safe_regions",
            ),
            non_cacheable_section_patterns=_string_tuple(
                data.get("non_cacheable_section_patterns", []),
                "policies.non_cacheable_section_patterns",
            ),
            non_cacheable_regions=_string_tuple(
                data.get("non_cacheable_regions", []),
                "policies.non_cacheable_regions",
            ),
            cacheable_section_patterns=_string_tuple(
                data.get("cacheable_section_patterns", []),
                "policies.cacheable_section_patterns",
            ),
            cacheable_regions=_string_tuple(
                data.get("cacheable_regions", []),
                "policies.cacheable_regions",
            ),
            retention_section_patterns=_string_tuple(
                data.get("retention_section_patterns", []),
                "policies.retention_section_patterns",
            ),
            retention_regions=_string_tuple(
                data.get("retention_regions", []),
                "policies.retention_regions",
            ),
            forbidden_component_regions=_group_patterns(
                data.get("forbidden_component_regions", {}),
                "policies.forbidden_component_regions",
            ),
            suppress_issue_ids=_string_tuple(
                data.get("suppress_issue_ids", []),
                "policies.suppress_issue_ids",
            ),
            suppress_issue_prefixes=_string_tuple(
                data.get("suppress_issue_prefixes", []),
                "policies.suppress_issue_prefixes",
            ),
            suppress_categories=_string_tuple(
                data.get("suppress_categories", []),
                "policies.suppress_categories",
            ),
        )


@dataclass(slots=True)
class TelemetryConfig:
    enabled: bool = False
    endpoint: str | None = None
    emit_command_usage: bool = False
    emit_crash_reports: bool = False

    @classmethod
    def from_dict(cls, data: Mapping[str, object]) -> TelemetryConfig:
        return cls(
            enabled=_bool(data.get("enabled", False), "telemetry.enabled"),
            endpoint=_string_or_none(data.get("endpoint"), "telemetry.endpoint"),
            emit_command_usage=_bool(
                data.get("emit_command_usage", False),
                "telemetry.emit_command_usage",
            ),
            emit_crash_reports=_bool(
                data.get("emit_crash_reports", False),
                "telemetry.emit_crash_reports",
            ),
        )


@dataclass(slots=True)
class MemscopeConfig:
    project: ProjectConfig = field(default_factory=ProjectConfig)
    inputs: InputsConfig = field(default_factory=InputsConfig)
    reports: ReportsConfig = field(default_factory=ReportsConfig)
    budgets: BudgetsConfig = field(default_factory=BudgetsConfig)
    policies: PoliciesConfig = field(default_factory=PoliciesConfig)
    groups: dict[str, tuple[str, ...]] = field(default_factory=dict)
    telemetry: TelemetryConfig = field(default_factory=TelemetryConfig)
    source_path: Path | None = None

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, object],
        *,
        source_path: Path | None = None,
    ) -> MemscopeConfig:
        project = ProjectConfig.from_dict(_mapping(data.get("project", {}), "project"))
        inputs = InputsConfig.from_dict(_mapping(data.get("inputs", {}), "inputs"))
        reports = ReportsConfig.from_dict(_mapping(data.get("reports", {}), "reports"))
        budgets = BudgetsConfig.from_dict(_mapping(data.get("budgets", {}), "budgets"))
        policies = PoliciesConfig.from_dict(_mapping(data.get("policies", {}), "policies"))
        groups = _group_patterns(data.get("groups", {}), "groups")
        telemetry = TelemetryConfig.from_dict(_mapping(data.get("telemetry", {}), "telemetry"))

        return cls(
            project=project,
            inputs=inputs,
            reports=reports,
            budgets=budgets,
            policies=policies,
            groups=groups,
            telemetry=telemetry,
            source_path=source_path,
        )
