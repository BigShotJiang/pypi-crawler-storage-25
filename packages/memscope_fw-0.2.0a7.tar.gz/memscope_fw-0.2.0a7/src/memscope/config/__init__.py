"""Configuration system for MemScope."""

from memscope.config.defaults import DEFAULT_CONFIG, get_default_config
from memscope.config.loader import (
    DEFAULT_CONFIG_FILENAMES,
    discover_config_path,
    load_config,
    load_config_file,
    merge_config_layers,
)
from memscope.config.schema import (
    BudgetsConfig,
    InputsConfig,
    MemscopeConfig,
    PoliciesConfig,
    ProjectConfig,
    ReportsConfig,
    TelemetryConfig,
)
from memscope.config.validator import (
    ConfigValidationError,
    ValidationIssue,
    validate_config_dict,
    validate_or_raise,
)

__all__ = [
    "BudgetsConfig",
    "ConfigValidationError",
    "DEFAULT_CONFIG",
    "DEFAULT_CONFIG_FILENAMES",
    "InputsConfig",
    "MemscopeConfig",
    "PoliciesConfig",
    "ProjectConfig",
    "ReportsConfig",
    "TelemetryConfig",
    "ValidationIssue",
    "discover_config_path",
    "get_default_config",
    "load_config",
    "load_config_file",
    "merge_config_layers",
    "validate_config_dict",
    "validate_or_raise",
]
