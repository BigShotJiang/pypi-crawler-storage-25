"""Config dictionary validator with path-aware errors."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass

from memscope.config.defaults import ConfigValue
from memscope.config.schema import MemscopeConfig
from memscope.domain import IssueCategory
from memscope.security import is_remote_reference


@dataclass(frozen=True, slots=True)
class ValidationIssue:
    path: str
    message: str

    def render(self) -> str:
        return f"{self.path}: {self.message}"


class ConfigValidationError(ValueError):
    def __init__(self, issues: list[ValidationIssue]) -> None:
        self.issues = tuple(issues)
        rendered = "; ".join(issue.render() for issue in issues) if issues else "invalid configuration"
        super().__init__(rendered)


def _is_mapping(value: object) -> bool:
    return isinstance(value, Mapping)


def _validate_section_types(data: Mapping[str, ConfigValue]) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    expected_table_sections = ("project", "inputs", "reports", "budgets", "policies", "groups", "telemetry")
    for section in expected_table_sections:
        raw = data.get(section)
        if raw is None:
            continue
        if not _is_mapping(raw):
            issues.append(ValidationIssue(section, "expected table"))
    return issues


def _validate_inputs_presence(config: MemscopeConfig) -> list[ValidationIssue]:
    if config.inputs.elf or config.inputs.map or config.inputs.linker:
        return []
    return [
        ValidationIssue(
            "inputs",
            "at least one artifact path is required (inputs.elf, inputs.map, or inputs.linker)",
        )
    ]


def _validate_budgets(config: MemscopeConfig) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    for group_name, budget_map in (("flash", config.budgets.flash), ("ram", config.budgets.ram)):
        for region_name, ratio in budget_map.items():
            if ratio <= 0 or ratio > 1:
                issues.append(
                    ValidationIssue(
                        f"budgets.{group_name}.{region_name}",
                        "value must be within (0, 1]",
                    )
                )
    return issues


def _validate_policies(config: MemscopeConfig) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    threshold = config.policies.warn_on_large_bss_symbol_kb
    if threshold is not None and threshold <= 0:
        issues.append(
            ValidationIssue(
                "policies.warn_on_large_bss_symbol_kb",
                "value must be a positive integer when provided",
            )
        )

    near_capacity = config.policies.warn_on_near_capacity_ratio
    if near_capacity is not None and (near_capacity <= 0 or near_capacity > 1):
        issues.append(
            ValidationIssue(
                "policies.warn_on_near_capacity_ratio",
                "value must be within (0, 1] when provided",
            )
        )

    for field_name, value in (
        ("policies.max_ram_growth_bytes", config.policies.max_ram_growth_bytes),
        ("policies.max_flash_growth_bytes", config.policies.max_flash_growth_bytes),
    ):
        if value is not None and value < 0:
            issues.append(
                ValidationIssue(
                    field_name,
                    "value must be >= 0 when provided",
                )
            )

    for field_name, value in (
        ("policies.ota_slot_a_max_bytes", config.policies.ota_slot_a_max_bytes),
        ("policies.ota_slot_b_max_bytes", config.policies.ota_slot_b_max_bytes),
    ):
        if value is not None and value <= 0:
            issues.append(
                ValidationIssue(
                    field_name,
                    "value must be > 0 when provided",
                )
            )

    ota_warn_ratio = config.policies.ota_warn_ratio
    if ota_warn_ratio is not None and (ota_warn_ratio <= 0 or ota_warn_ratio > 1):
        issues.append(
            ValidationIssue(
                "policies.ota_warn_ratio",
                "value must be within (0, 1] when provided",
            )
        )

    for partition_name, max_bytes in config.policies.partition_max_bytes.items():
        if max_bytes <= 0:
            issues.append(
                ValidationIssue(
                    f"policies.partition_max_bytes.{partition_name}",
                    "value must be > 0",
                )
            )

    ota_slots_configured = any(
        value is not None
        for value in (
            config.policies.ota_slot_a_max_bytes,
            config.policies.ota_slot_b_max_bytes,
        )
    )
    if ota_slots_configured and not config.policies.ota_source_regions:
        issues.append(
            ValidationIssue(
                "policies.ota_source_regions",
                "at least one region is required when OTA slot limits are configured",
            )
        )

    cacheable_regions = {name.lower() for name in config.policies.cacheable_regions}
    non_cacheable_regions = {name.lower() for name in config.policies.non_cacheable_regions}
    overlap = sorted(cacheable_regions & non_cacheable_regions)
    for region_name in overlap:
        issues.append(
            ValidationIssue(
                f"policies.cacheable_regions.{region_name}",
                "region cannot be both cacheable and non-cacheable",
            )
        )

    for component_name, region_names in config.policies.forbidden_component_regions.items():
        if not component_name.strip():
            issues.append(
                ValidationIssue(
                    "policies.forbidden_component_regions",
                    "component keys must be non-empty strings",
                )
            )
        if not region_names:
            issues.append(
                ValidationIssue(
                    f"policies.forbidden_component_regions.{component_name}",
                    "at least one restricted region is required",
                )
            )

    valid_categories = {category.value for category in IssueCategory}
    for idx, category in enumerate(config.policies.suppress_categories):
        if category not in valid_categories:
            issues.append(
                ValidationIssue(
                    f"policies.suppress_categories[{idx}]",
                    f"unknown category '{category}', expected one of: {', '.join(sorted(valid_categories))}",
                )
            )
    return issues


def _validate_groups(config: MemscopeConfig) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    for group_name, patterns in config.groups.items():
        if not patterns:
            issues.append(
                ValidationIssue(
                    f"groups.{group_name}",
                    "at least one pattern is required",
                )
            )
    return issues


def _validate_local_path(value: str | None, field_path: str) -> ValidationIssue | None:
    if value is None:
        return None
    if is_remote_reference(value):
        return ValidationIssue(
            field_path,
            "remote/network references are not allowed; use local filesystem paths only",
        )
    return None


def _validate_local_only_paths(config: MemscopeConfig) -> list[ValidationIssue]:
    checks = (
        (config.inputs.elf, "inputs.elf"),
        (config.inputs.map, "inputs.map"),
        (config.inputs.linker, "inputs.linker"),
        (config.reports.html, "reports.html"),
        (config.reports.json, "reports.json"),
        (config.reports.csv, "reports.csv"),
    )
    issues: list[ValidationIssue] = []
    for value, field_path in checks:
        issue = _validate_local_path(value, field_path)
        if issue is not None:
            issues.append(issue)
    return issues


def _validate_telemetry(config: MemscopeConfig) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    if config.telemetry.enabled and not config.telemetry.endpoint:
        issues.append(
            ValidationIssue(
                "telemetry.endpoint",
                "endpoint is required when telemetry.enabled is true",
            )
        )
    return issues


def validate_config_dict(data: Mapping[str, ConfigValue]) -> list[ValidationIssue]:
    issues = _validate_section_types(data)
    if issues:
        return issues

    try:
        typed = MemscopeConfig.from_dict(data)
    except ValueError as exc:
        message = str(exc)
        path, _, detail = message.partition(": ")
        return [ValidationIssue(path=path or "config", message=detail or message)]

    issues.extend(_validate_inputs_presence(typed))
    issues.extend(_validate_budgets(typed))
    issues.extend(_validate_policies(typed))
    issues.extend(_validate_groups(typed))
    issues.extend(_validate_local_only_paths(typed))
    issues.extend(_validate_telemetry(typed))
    return issues


def validate_or_raise(data: Mapping[str, ConfigValue]) -> None:
    issues = validate_config_dict(data)
    if issues:
        raise ConfigValidationError(issues)
