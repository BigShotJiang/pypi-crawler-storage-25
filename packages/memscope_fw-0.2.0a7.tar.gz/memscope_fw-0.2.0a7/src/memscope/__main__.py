"""Enable `python -m memscope` execution."""

from memscope.app.cli import main

if __name__ == "__main__":
    main()

