"""Primary analysis report model and nested report blocks."""

from __future__ import annotations

from dataclasses import dataclass, field

from memscope.domain.component_group import ComponentGroup
from memscope.domain.issue import Issue
from memscope.domain.memory_region import MemoryRegion
from memscope.domain.section_placement import SectionPlacement
from memscope.domain.symbol_entry import SymbolEntry


@dataclass(slots=True)
class ReportMetadata:
    tool_version: str
    schema_version: str
    analysis_timestamp: str
    target_name: str | None = None
    toolchain_detected: str | None = None
    parse_assumptions: tuple[str, ...] = ()
    license_mode: str | None = None
    license_tier: str | None = None
    extra: dict[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.parse_assumptions = tuple(
            sorted({assumption.strip() for assumption in self.parse_assumptions if assumption.strip()})
        )


@dataclass(slots=True)
class ReportSummary:
    total_flash: int = 0
    total_ram: int = 0
    utilization_by_region: dict[str, float] = field(default_factory=dict)
    issue_counts: dict[str, int] = field(default_factory=dict)
    extra: dict[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.total_flash < 0:
            raise ValueError("total_flash must be >= 0")
        if self.total_ram < 0:
            raise ValueError("total_ram must be >= 0")


@dataclass(slots=True)
class AnalysisReport:
    metadata: ReportMetadata
    summary: ReportSummary = field(default_factory=ReportSummary)
    regions: list[MemoryRegion] = field(default_factory=list)
    sections: list[SectionPlacement] = field(default_factory=list)
    symbols: list[SymbolEntry] = field(default_factory=list)
    components: list[ComponentGroup] = field(default_factory=list)
    issues: list[Issue] = field(default_factory=list)
    trends: dict[str, object] = field(default_factory=dict)
    regressions: dict[str, object] = field(default_factory=dict)
    diagnostics: dict[str, object] = field(default_factory=dict)

    def sorted_copy(self) -> AnalysisReport:
        from memscope.domain.sorting import normalize_report_for_output

        return normalize_report_for_output(self)

