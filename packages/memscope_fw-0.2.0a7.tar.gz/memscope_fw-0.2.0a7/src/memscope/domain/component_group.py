"""Component grouping entity for ownership analysis."""

from __future__ import annotations

from dataclasses import dataclass


def _normalize_names(values: tuple[str, ...]) -> tuple[str, ...]:
    return tuple(sorted({v.strip() for v in values if v.strip()}))


@dataclass(slots=True)
class ComponentGroup:
    name: str
    matching_rules: tuple[str, ...] = ()
    symbols: tuple[str, ...] = ()
    objects: tuple[str, ...] = ()
    total_flash: int = 0
    total_ram: int = 0

    def __post_init__(self) -> None:
        self.matching_rules = _normalize_names(self.matching_rules)
        self.symbols = _normalize_names(self.symbols)
        self.objects = _normalize_names(self.objects)

        if self.total_flash < 0:
            raise ValueError("total_flash must be >= 0")
        if self.total_ram < 0:
            raise ValueError("total_ram must be >= 0")

