"""Deterministic ordering helpers for stable report outputs."""

from __future__ import annotations

from collections.abc import Mapping
from copy import deepcopy
from dataclasses import replace
from typing import Any

from memscope.domain.analysis_report import AnalysisReport
from memscope.domain.component_group import ComponentGroup
from memscope.domain.issue import Issue
from memscope.domain.memory_region import MemoryRegion
from memscope.domain.section_placement import SectionPlacement
from memscope.domain.symbol_entry import SymbolEntry

_SEVERITY_RANK = {"error": 0, "warning": 1, "info": 2}


def sort_memory_regions(regions: list[MemoryRegion]) -> list[MemoryRegion]:
    return sorted(regions, key=lambda item: (item.start_address, item.end_address, item.name))


def sort_sections(sections: list[SectionPlacement]) -> list[SectionPlacement]:
    return sorted(sections, key=lambda item: (item.vma, item.lma, item.name))


def sort_symbols(symbols: list[SymbolEntry]) -> list[SymbolEntry]:
    return sorted(
        symbols,
        key=lambda item: (item.address is None, item.address or 0, item.name, -item.size),
    )


def sort_components(components: list[ComponentGroup]) -> list[ComponentGroup]:
    return sorted(components, key=lambda item: item.name)


def sort_issues(issues: list[Issue]) -> list[Issue]:
    return sorted(
        issues,
        key=lambda item: (_SEVERITY_RANK[item.severity.value], item.category.value, item.id),
    )


def _sort_mapping(value: Mapping[str, Any]) -> dict[str, Any]:
    sorted_result: dict[str, Any] = {}
    for key in sorted(value):
        child = value[key]
        if isinstance(child, Mapping):
            sorted_result[key] = _sort_mapping(child)
        elif isinstance(child, list):
            sorted_result[key] = [_sort_mapping(v) if isinstance(v, Mapping) else deepcopy(v) for v in child]
        else:
            sorted_result[key] = deepcopy(child)
    return sorted_result


def normalize_report_for_output(report: AnalysisReport) -> AnalysisReport:
    """Return a deep-copied report with deterministic ordering applied."""
    return replace(
        report,
        summary=replace(
            report.summary,
            utilization_by_region=_sort_mapping(report.summary.utilization_by_region),
            issue_counts=_sort_mapping(report.summary.issue_counts),
            extra=_sort_mapping(report.summary.extra),
        ),
        regions=sort_memory_regions(list(report.regions)),
        sections=sort_sections(list(report.sections)),
        symbols=sort_symbols(list(report.symbols)),
        components=sort_components(list(report.components)),
        issues=sort_issues(list(report.issues)),
        trends=_sort_mapping(report.trends),
        regressions=_sort_mapping(report.regressions),
        diagnostics=_sort_mapping(report.diagnostics),
    )

