"""MemScope normalized domain model exports."""

from memscope.domain.analysis_report import AnalysisReport, ReportMetadata, ReportSummary
from memscope.domain.build_artifact_set import BuildArtifactSet
from memscope.domain.component_group import ComponentGroup
from memscope.domain.enums import (
    IssueCategory,
    IssueSeverity,
    MemoryRegionCategory,
    RegionSourceOrigin,
)
from memscope.domain.issue import Issue
from memscope.domain.memory_region import MemoryRegion
from memscope.domain.section_placement import SectionPlacement
from memscope.domain.symbol_entry import SymbolEntry
from memscope.domain.value_objects import AddressRange, AttributeSet

__all__ = [
    "AddressRange",
    "AnalysisReport",
    "AttributeSet",
    "BuildArtifactSet",
    "ComponentGroup",
    "Issue",
    "IssueCategory",
    "IssueSeverity",
    "MemoryRegion",
    "MemoryRegionCategory",
    "RegionSourceOrigin",
    "ReportMetadata",
    "ReportSummary",
    "SectionPlacement",
    "SymbolEntry",
]

