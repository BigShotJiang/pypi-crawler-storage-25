"""Issue entity emitted by analysis and policy layers."""

from __future__ import annotations

from dataclasses import dataclass

from memscope.domain.enums import IssueCategory, IssueSeverity


@dataclass(slots=True)
class Issue:
    id: str
    severity: IssueSeverity
    category: IssueCategory
    title: str
    description: str
    affected_entities: tuple[str, ...] = ()
    remediation_hint: str | None = None

    def __post_init__(self) -> None:
        if not self.id.strip():
            raise ValueError("id must not be empty")
        if not self.title.strip():
            raise ValueError("title must not be empty")
        if isinstance(self.severity, str):
            self.severity = IssueSeverity(self.severity)
        if isinstance(self.category, str):
            self.category = IssueCategory(self.category)
        self.affected_entities = tuple(
            sorted({entity.strip() for entity in self.affected_entities if entity.strip()})
        )

