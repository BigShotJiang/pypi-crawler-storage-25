"""Shared enum types for MemScope's domain layer."""

from enum import StrEnum


class MemoryRegionCategory(StrEnum):
    FLASH = "flash"
    RAM = "ram"
    TCM = "tcm"
    RETENTION = "retention"
    EXTERNAL_FLASH = "external_flash"
    EXTERNAL_RAM = "external_ram"
    CUSTOM = "custom"


class RegionSourceOrigin(StrEnum):
    LINKER = "linker"
    INFERRED = "inferred"
    PROFILE = "profile"
    OVERRIDE = "override"


class IssueSeverity(StrEnum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"


class IssueCategory(StrEnum):
    PLACEMENT = "placement"
    OVERFLOW = "overflow"
    RESERVED = "reserved"
    POLICY = "policy"
    REGRESSION = "regression"
    PARSING = "parsing"

