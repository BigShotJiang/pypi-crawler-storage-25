"""Serialization helpers for deterministic JSON-ready output."""

from __future__ import annotations

import json
from dataclasses import fields, is_dataclass
from datetime import date, datetime
from enum import Enum
from pathlib import Path
from typing import Any, TypeAlias, cast

from memscope.domain.value_objects import AddressRange, AttributeSet

JSONScalar: TypeAlias = str | int | float | bool | None
JSONValue: TypeAlias = JSONScalar | list["JSONValue"] | dict[str, "JSONValue"]


def to_serializable(value: Any) -> JSONValue:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value

    if isinstance(value, (datetime, date)):
        return value.isoformat()

    if isinstance(value, Enum):
        return value.value

    if isinstance(value, Path):
        return str(value)

    if isinstance(value, AttributeSet):
        return [to_serializable(v) for v in value.to_list()]

    if isinstance(value, AddressRange):
        return {
            "start_address": value.start_address,
            "end_address": value.end_address,
            "size": value.size,
        }

    if is_dataclass(value):
        serialized: dict[str, JSONValue] = {}
        for field in fields(value):
            serialized[field.name] = to_serializable(getattr(value, field.name))
        return serialized

    if isinstance(value, dict):
        return {str(k): to_serializable(v) for k, v in sorted(value.items(), key=lambda item: str(item[0]))}

    if isinstance(value, (list, tuple)):
        return [to_serializable(item) for item in value]

    if isinstance(value, (set, frozenset)):
        return [to_serializable(item) for item in sorted(value, key=str)]

    raise TypeError(f"Unsupported type for serialization: {type(value)!r}")


def to_json_dict(value: Any) -> dict[str, JSONValue]:
    serialized = to_serializable(value)
    if not isinstance(serialized, dict):
        raise TypeError("Expected a mapping at the serialization root")
    return serialized


def to_json_string(value: Any, *, indent: int = 2) -> str:
    return json.dumps(to_json_dict(value), indent=indent, sort_keys=True)


def load_json_string(payload: str) -> dict[str, JSONValue]:
    loaded = json.loads(payload)
    if not isinstance(loaded, dict):
        raise ValueError("Expected top-level JSON object")
    return cast(dict[str, JSONValue], loaded)

