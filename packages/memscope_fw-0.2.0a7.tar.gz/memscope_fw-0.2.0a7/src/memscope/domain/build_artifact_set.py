"""Input artifact entity for one analysis run."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass(slots=True)
class BuildArtifactSet:
    elf_path: Path | None = None
    map_path: Path | None = None
    linker_path: Path | None = None
    dwarf_available: bool = False
    toolchain_hint: str | None = None
    target_name: str | None = None
    build_id: str | None = None
    build_metadata: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        for field_name in ("elf_path", "map_path", "linker_path"):
            value = getattr(self, field_name)
            if value is not None and not isinstance(value, Path):
                setattr(self, field_name, Path(value))

