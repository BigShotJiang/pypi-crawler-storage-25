"""Schema version constants and compatibility helpers."""

from __future__ import annotations

import re

SCHEMA_VERSION = "1.0.0"
SUPPORTED_SCHEMA_VERSIONS: tuple[str, ...] = (SCHEMA_VERSION,)

_SEMVER_PATTERN = re.compile(r"^(?P<major>\d+)\.(?P<minor>\d+)\.(?P<patch>\d+)$")


def parse_schema_version(value: str) -> tuple[int, int, int]:
    match = _SEMVER_PATTERN.match(value.strip())
    if not match:
        raise ValueError(f"Invalid schema version: {value!r}")
    return int(match["major"]), int(match["minor"]), int(match["patch"])


def is_schema_supported(value: str) -> bool:
    return value.strip() in SUPPORTED_SCHEMA_VERSIONS


def assert_schema_supported(value: str) -> None:
    if not is_schema_supported(value):
        raise ValueError(
            f"Unsupported schema version {value!r}. "
            f"Supported versions: {', '.join(SUPPORTED_SCHEMA_VERSIONS)}"
        )


def is_backward_compatible(read_version: str, current_version: str = SCHEMA_VERSION) -> bool:
    read_major, read_minor, _ = parse_schema_version(read_version)
    current_major, current_minor, _ = parse_schema_version(current_version)
    if read_major != current_major:
        return False
    return read_minor <= current_minor

