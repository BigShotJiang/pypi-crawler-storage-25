"""Normalized section-placement entity."""

from __future__ import annotations

from dataclasses import dataclass, field

from memscope.domain.value_objects import AttributeSet


@dataclass(slots=True)
class SectionPlacement:
    name: str
    execution_region: str | None
    load_region: str | None
    vma: int
    lma: int
    size: int
    alignment: int | None = None
    padding_before: int = 0
    padding_after: int = 0
    attributes: AttributeSet = field(default_factory=AttributeSet)
    input_contributors: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if self.size < 0:
            raise ValueError("size must be >= 0")
        if self.vma < 0 or self.lma < 0:
            raise ValueError("vma and lma must be >= 0")
        if self.padding_before < 0 or self.padding_after < 0:
            raise ValueError("padding must be >= 0")
        if self.alignment is not None and self.alignment <= 0:
            raise ValueError("alignment must be > 0 when set")

        if not isinstance(self.attributes, AttributeSet):
            self.attributes = AttributeSet.from_iterable(self.attributes)

        self.input_contributors = tuple(
            sorted({contributor.strip() for contributor in self.input_contributors if contributor.strip()})
        )

