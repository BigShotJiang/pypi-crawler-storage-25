"""Normalized symbol entity."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class SymbolEntry:
    name: str
    demangled_name: str | None = None
    symbol_type: str | None = None
    section_name: str | None = None
    address: int | None = None
    size: int = 0
    object_file: str | None = None
    archive: str | None = None
    compilation_unit: str | None = None
    source_file: str | None = None
    language: str | None = None
    is_weak: bool = False
    is_generated: bool = False

    def __post_init__(self) -> None:
        if self.address is not None and self.address < 0:
            raise ValueError("address must be >= 0 when set")
        if self.size < 0:
            raise ValueError("size must be >= 0")

