"""Reusable value objects shared by domain models."""

from __future__ import annotations

from collections.abc import Iterable, Iterator
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class AddressRange:
    """Inclusive address range used by normalized memory entities."""

    start_address: int
    end_address: int

    def __post_init__(self) -> None:
        if self.start_address < 0:
            raise ValueError("start_address must be >= 0")
        if self.end_address < self.start_address:
            raise ValueError("end_address must be >= start_address")

    @property
    def size(self) -> int:
        """Size in bytes for an inclusive range."""
        return (self.end_address - self.start_address) + 1

    def contains(self, address: int) -> bool:
        return self.start_address <= address <= self.end_address

    @classmethod
    def from_start_and_size(cls, start_address: int, size: int) -> AddressRange:
        if size <= 0:
            raise ValueError("size must be > 0")
        return cls(start_address=start_address, end_address=start_address + size - 1)


@dataclass(frozen=True, slots=True)
class AttributeSet:
    """Normalized set of attributes represented as a deterministic tuple."""

    values: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        normalized = tuple(sorted({v.strip().lower() for v in self.values if v.strip()}))
        object.__setattr__(self, "values", normalized)

    @classmethod
    def from_iterable(cls, values: Iterable[str]) -> AttributeSet:
        return cls(tuple(values))

    def to_list(self) -> list[str]:
        return list(self.values)

    def __contains__(self, value: str) -> bool:
        return value.strip().lower() in self.values

    def __iter__(self) -> Iterator[str]:
        return iter(self.values)

