"""Normalized memory-region entity."""

from __future__ import annotations

from dataclasses import dataclass, field

from memscope.domain.enums import MemoryRegionCategory, RegionSourceOrigin
from memscope.domain.value_objects import AddressRange, AttributeSet


@dataclass(slots=True)
class MemoryRegion:
    name: str
    category: MemoryRegionCategory = MemoryRegionCategory.CUSTOM
    start_address: int = 0
    end_address: int = 0
    size: int | None = None
    attributes: AttributeSet = field(default_factory=AttributeSet)
    source_origin: RegionSourceOrigin = RegionSourceOrigin.INFERRED
    aliases: tuple[str, ...] = ()
    parent_region: str | None = None
    bank_info: dict[str, str | int | float | bool] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.start_address < 0:
            raise ValueError("start_address must be >= 0")
        if self.end_address < self.start_address:
            raise ValueError("end_address must be >= start_address")

        if isinstance(self.category, str):
            self.category = MemoryRegionCategory(self.category)

        if isinstance(self.source_origin, str):
            self.source_origin = RegionSourceOrigin(self.source_origin)

        if not isinstance(self.attributes, AttributeSet):
            self.attributes = AttributeSet.from_iterable(self.attributes)

        self.aliases = tuple(sorted({alias.strip() for alias in self.aliases if alias.strip()}))

        inferred_size = (self.end_address - self.start_address) + 1
        if self.size is None:
            self.size = inferred_size
        elif self.size <= 0:
            raise ValueError("size must be > 0")

    @property
    def address_range(self) -> AddressRange:
        return AddressRange(self.start_address, self.end_address)

