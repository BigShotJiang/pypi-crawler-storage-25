"""Licensing state models."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Any


class LicenseState(StrEnum):
    FREE = "free"           # Default for fresh installs — visibility-only, no clock.
    TRIAL = "trial"         # 14-day paid-feature evaluation window (starts on first
                            # attempted use of a paid feature, not on first install).
    ACTIVE = "active"
    EXPIRED = "expired"     # Paid trial elapsed; user can still use FREE-tier features.
    INVALID = "invalid"
    OFFLINE_VALID = "offline-valid"
    DEVELOPER_MODE = "developer-mode"
    REVOKED = "revoked"


class LicenseTier(StrEnum):
    """Coarse feature-access tier derived from a :class:`LicenseState`.

    The state machine has more granularity than the feature gate cares about
    (``ACTIVE`` and ``OFFLINE_VALID`` are both "you have a working license";
    ``EXPIRED`` and ``INVALID`` and ``REVOKED`` are all "no paid access"). The
    tier collapses those into five buckets command guards actually act on:
    which features unlock, which require activation, which are bypassed by
    the internal developer build, and the new ``FREE`` baseline that's
    available to anyone for visibility (no time limit, no paid features).
    """

    FREE = "free"
    TRIAL = "trial"
    PAID = "paid"
    DEVELOPER = "developer"
    UNAVAILABLE = "unavailable"


_STATE_TO_TIER: dict[LicenseState, LicenseTier] = {
    LicenseState.FREE: LicenseTier.FREE,
    LicenseState.TRIAL: LicenseTier.TRIAL,
    LicenseState.ACTIVE: LicenseTier.PAID,
    LicenseState.OFFLINE_VALID: LicenseTier.PAID,
    LicenseState.DEVELOPER_MODE: LicenseTier.DEVELOPER,
    LicenseState.EXPIRED: LicenseTier.UNAVAILABLE,
    LicenseState.INVALID: LicenseTier.UNAVAILABLE,
    LicenseState.REVOKED: LicenseTier.UNAVAILABLE,
}


@dataclass(slots=True, frozen=True)
class LicenseDecision:
    """Result of evaluating license state for one command."""

    state: LicenseState
    allowed: bool
    source: str
    message: str


@dataclass(slots=True, frozen=True)
class LicenseStatus:
    """Public status snapshot returned by the licensing service."""

    state: LicenseState
    allowed: bool
    source: str
    message: str
    license_id: str | None = None
    expires_at: str | None = None
    provider: str | None = None
    cache_present: bool = False

    @property
    def tier(self) -> LicenseTier:
        """Coarse feature-access tier (see :class:`LicenseTier`)."""
        return _STATE_TO_TIER[self.state]

    @property
    def paid_features_allowed(self) -> bool:
        """True when this status unlocks paid-tier features.

        Per ``docs/internal/handbook/licensing-state-machine.md``:

        - ``TRIAL`` (14-day evaluation window) → True. Prospective buyers
          must be able to test ``--strict``, ``validate``, ``diff``,
          custom budgets and CSV export to decide if the product is
          worth buying. Locking them out during the trial would defeat
          the whole point.
        - ``PAID`` (ACTIVE / OFFLINE_VALID) → True. Real Keygen license.
        - ``DEVELOPER`` → True. Internal-build bypass.
        - ``FREE`` (post-trial visibility-only) → False. Visibility kept;
          enforcement features blocked.
        - ``UNAVAILABLE`` (EXPIRED / INVALID / REVOKED) → False.
        """
        return self.tier in (LicenseTier.TRIAL, LicenseTier.PAID, LicenseTier.DEVELOPER)

    def to_public_dict(self) -> dict[str, Any]:
        return {
            "state": self.state.value,
            "tier": self.tier.value,
            "paid_features_allowed": self.paid_features_allowed,
            "allowed": self.allowed,
            "source": self.source,
            "message": self.message,
            "license_id": self.license_id,
            "expires_at": self.expires_at,
            "provider": self.provider,
            "cache_present": self.cache_present,
        }
