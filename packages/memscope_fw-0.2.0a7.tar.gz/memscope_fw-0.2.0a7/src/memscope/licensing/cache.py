"""Local license cache persistence."""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

# Per-build peppers for cache HMAC. Anyone with the wheel can extract these
# constants, so they are not true secrets. Their job is to make naive JSON
# edits of the cache files fail HMAC verification (which then forces the
# user back through trial-end / re-activation), not to defeat motivated
# reverse-engineering. Separate constants are used per cache file so that
# extracting one doesn't compromise the other.
_TRIAL_HMAC_PEPPER = b"memscope-trial-pepper-v1"
_LICENSE_HMAC_PEPPER = b"memscope-license-pepper-v1"

# Field name reserved for the HMAC signature inside the persisted license
# blob. The signature covers the canonical-JSON of every other field.
_LICENSE_SIGNATURE_FIELD = "_signature"


@dataclass(frozen=True, slots=True)
class TrialClock:
    """Persistent trial-window state for a fresh install."""

    first_run_at: datetime
    nonce: str

    def days_used(self, *, now: datetime) -> int:
        delta = now - self.first_run_at
        return max(0, delta.days)

    def days_remaining(self, *, now: datetime, trial_days: int) -> int:
        return max(0, trial_days - self.days_used(now=now))

    def is_expired(self, *, now: datetime, trial_days: int) -> bool:
        return self.days_remaining(now=now, trial_days=trial_days) <= 0


class TrialStateTamperedError(RuntimeError):
    """Raised when the persisted trial state fails HMAC verification."""


class LicenseCacheTamperedError(RuntimeError):
    """Raised when the persisted license blob fails HMAC verification.

    The service treats this the same as "no cached activation" and forces
    the user to re-activate, rather than silently trusting a hand-edited
    cache file.
    """


class ActivationCache:
    """Reads/writes local cached activation blob and trial-clock state."""

    def __init__(
        self,
        path: Path | None = None,
        *,
        trial_path: Path | None = None,
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        self.path = path or _default_cache_path()
        self.trial_path = trial_path or (self.path.parent / "trial_state.json")
        self._clock = clock or _utcnow

    def now(self) -> datetime:
        return self._clock()

    def load_local_license(self) -> dict[str, Any] | None:
        """Return the persisted license blob, or ``None`` when absent.

        Raises :class:`LicenseCacheTamperedError` when the file exists but
        its HMAC signature does not match. Callers that want "graceful
        degradation to no-license" should catch and treat the same as
        ``None``; callers that want strict integrity (e.g., the licensing
        service) should propagate the failure as ``EXPIRED`` so a
        hand-edited cache cannot extend a license forever.
        """
        if not self.path.exists():
            return None
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8-sig"))
        except (OSError, ValueError) as exc:
            raise LicenseCacheTamperedError(
                f"License cache file is unreadable: {exc}"
            ) from exc
        if not isinstance(payload, dict):
            raise LicenseCacheTamperedError("License cache file is not a JSON object")

        signature = payload.pop(_LICENSE_SIGNATURE_FIELD, None)
        if not isinstance(signature, str):
            raise LicenseCacheTamperedError(
                "License cache is missing its HMAC signature"
                " (file was created by an older build or has been hand-edited)"
            )

        normalized = {str(key): value for key, value in payload.items()}
        expected = _sign_license_blob(normalized)
        if not hmac.compare_digest(expected, signature):
            raise LicenseCacheTamperedError("License cache HMAC verification failed")
        return normalized

    def save_local_license(self, payload: dict[str, Any]) -> None:
        # Strip any pre-existing signature field so the HMAC covers only
        # caller-provided data.
        clean = {str(key): value for key, value in payload.items() if key != _LICENSE_SIGNATURE_FIELD}
        signed = dict(clean)
        signed[_LICENSE_SIGNATURE_FIELD] = _sign_license_blob(clean)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(signed, indent=2, sort_keys=True), encoding="utf-8")

    def clear_local_license(self) -> None:
        if self.path.exists():
            self.path.unlink()

    def load_trial_clock(self) -> TrialClock | None:
        """Return the persisted trial clock, or ``None`` when absent.

        Raises :class:`TrialStateTamperedError` when the file exists but its
        HMAC signature does not match. Callers should treat tampering as
        equivalent to an expired trial rather than silently re-initializing.
        """
        if not self.trial_path.exists():
            return None
        try:
            raw = self.trial_path.read_text(encoding="utf-8-sig")
            payload = json.loads(raw)
        except (OSError, ValueError) as exc:
            raise TrialStateTamperedError("trial state file is unreadable") from exc
        if not isinstance(payload, dict):
            raise TrialStateTamperedError("trial state file is not a JSON object")

        first_run_at_raw = payload.get("first_run_at")
        nonce = payload.get("nonce")
        signature = payload.get("signature")
        if not isinstance(first_run_at_raw, str) or not isinstance(nonce, str) or not isinstance(signature, str):
            raise TrialStateTamperedError("trial state file is missing required fields")

        expected = _sign_trial_state(first_run_at=first_run_at_raw, nonce=nonce)
        if not hmac.compare_digest(expected, signature):
            raise TrialStateTamperedError("trial state HMAC verification failed")

        try:
            first_run_at = datetime.fromisoformat(first_run_at_raw)
        except ValueError as exc:
            raise TrialStateTamperedError("trial state timestamp is malformed") from exc
        if first_run_at.tzinfo is None:
            first_run_at = first_run_at.replace(tzinfo=UTC)
        return TrialClock(first_run_at=first_run_at, nonce=nonce)

    def initialize_trial_clock(self) -> TrialClock:
        """Persist a fresh trial clock anchored at the current injected time."""
        first_run_at = self._clock()
        if first_run_at.tzinfo is None:
            first_run_at = first_run_at.replace(tzinfo=UTC)
        nonce = secrets.token_hex(16)
        first_run_at_raw = first_run_at.isoformat()
        signature = _sign_trial_state(first_run_at=first_run_at_raw, nonce=nonce)
        payload = {
            "first_run_at": first_run_at_raw,
            "nonce": nonce,
            "signature": signature,
        }
        self.trial_path.parent.mkdir(parents=True, exist_ok=True)
        self.trial_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
        return TrialClock(first_run_at=first_run_at, nonce=nonce)

    def clear_trial_clock(self) -> None:
        if self.trial_path.exists():
            self.trial_path.unlink()


def _sign_trial_state(*, first_run_at: str, nonce: str) -> str:
    payload = f"{first_run_at}|{nonce}".encode()
    return hmac.new(_TRIAL_HMAC_PEPPER, payload, hashlib.sha256).hexdigest()


def _sign_license_blob(blob: Mapping[str, Any]) -> str:
    """HMAC the canonical-JSON encoding of a license blob.

    Sorting keys + compact separators makes the encoding deterministic so
    the same blob always produces the same signature regardless of
    insertion order or ``json.dumps`` version differences.
    """
    canonical = json.dumps(blob, sort_keys=True, separators=(",", ":"))
    return hmac.new(_LICENSE_HMAC_PEPPER, canonical.encode("utf-8"), hashlib.sha256).hexdigest()


def _utcnow() -> datetime:
    return datetime.now(UTC)


def _default_cache_path() -> Path:
    raw = os.getenv("MEMSCOPE_LICENSE_CACHE_PATH")
    if raw:
        return Path(raw).expanduser().resolve()
    return (Path.home() / ".memscope" / "license_cache.json").resolve()
