"""Real developer-mode licensing bypass — included only in developer wheels.

This module is **excluded from the production wheel** by the hatchling
build hook (`hatch_build.py`) when `MEMSCOPE_BUILD_PROFILE=production`.
The dispatcher in `dev_mode.py` falls back to `_dev_mode_stub` when this
file is absent, so production customers cannot enable the bypass by
flipping any flag — there is no code to flip.

See `docs/internal/release/distribution-plan.md` Phase B for the full design.
"""

from __future__ import annotations

from dataclasses import dataclass

from memscope.licensing.models import LicenseState, LicenseStatus


@dataclass(slots=True, frozen=True)
class DeveloperModeLicenseBridge:
    """Provides synthetic licensing state when developer mode is enabled."""

    enabled: bool = False

    def override_status(self) -> LicenseStatus | None:
        if not self.enabled:
            return None
        return LicenseStatus(
            state=LicenseState.DEVELOPER_MODE,
            allowed=True,
            source="developer-mode",
            message="Developer mode enabled; production license checks are bypassed.",
            provider="developer-mode",
            cache_present=False,
        )
