"""Machine fingerprint provider used for node-locked licensing."""

from __future__ import annotations

import hashlib
import os
import platform
import uuid
from pathlib import Path


class MachineFingerprintProvider:
    """Provide stable local machine/install identity."""

    def __init__(self, install_id_path: Path | None = None) -> None:
        self.install_id_path = install_id_path or _default_install_id_path()

    def get_machine_fingerprint(self) -> str:
        raw = "|".join(
            [
                platform.node(),
                platform.system(),
                platform.machine(),
                self.get_install_id(),
            ]
        )
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def get_os_summary(self) -> dict[str, str]:
        return {
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "python_version": platform.python_version(),
        }

    def get_install_id(self) -> str:
        if self.install_id_path.exists():
            value = self.install_id_path.read_text(encoding="utf-8").strip()
            if value:
                return value

        install_id = str(uuid.uuid4())
        self.install_id_path.parent.mkdir(parents=True, exist_ok=True)
        self.install_id_path.write_text(install_id, encoding="utf-8")
        return install_id


def _default_install_id_path() -> Path:
    raw = os.getenv("MEMSCOPE_INSTALL_ID_PATH")
    if raw:
        return Path(raw).expanduser().resolve()
    return (Path.home() / ".memscope" / "install_id").resolve()

