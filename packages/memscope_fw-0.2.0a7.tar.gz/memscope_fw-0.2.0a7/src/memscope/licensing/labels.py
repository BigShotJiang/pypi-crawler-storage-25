"""Single source of truth for user-facing license labels.

Surfaces (analyze HTML chip, diff HTML chip, console banners, audit footer,
report metadata) all map a ``LicenseState`` value to the same short label
and CSS class. Keeping the mapping here means a rename in one surface
doesn't drift away from the others.
"""

from __future__ import annotations

LICENSE_CHIP_LABEL: dict[str, str] = {
    "active": "active",
    "offline-valid": "active (offline)",
    "trial": "trial",
    "free": "free",
    "developer-mode": "developer mode",
    "expired": "expired",
    "invalid": "invalid",
    "revoked": "revoked",
}

LICENSE_CHIP_CSS: dict[str, str] = {
    "active": "is-license-active",
    "offline-valid": "is-license-active",
    "trial": "is-license-trial",
    "free": "is-license-free",
    "developer-mode": "is-license-dev",
    "expired": "is-license-expired",
    "invalid": "is-license-invalid",
    "revoked": "is-license-revoked",
}

LICENSE_WATERMARK_TEXT: dict[str, str] = {
    "trial": "TRIAL - FULL FEATURES, EVALUATION ONLY",
    "free": "FREE EDITION - paid features locked",
    "developer-mode": "DEVELOPER MODE",
    "expired": "LICENSE EXPIRED - ACTIVATION REQUIRED",
    "revoked": "LICENSE REVOKED - CONTACT YOUR ADMINISTRATOR",
    "invalid": "LICENSE INVALID - CACHED BLOB UNUSABLE",
}


def chip_label_for(state_value: str | None) -> str:
    if not state_value:
        return ""
    return LICENSE_CHIP_LABEL.get(state_value, state_value)


def chip_css_for(state_value: str | None) -> str:
    if not state_value:
        return ""
    return LICENSE_CHIP_CSS.get(state_value, "")


def watermark_text_for(state_value: str | None) -> str:
    if not state_value:
        return ""
    return LICENSE_WATERMARK_TEXT.get(state_value, "")
