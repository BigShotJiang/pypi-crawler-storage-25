"""License provider abstraction and default demo provider."""

from __future__ import annotations

import os
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import Protocol

from memscope.licensing.models import LicenseState


class LicenseProviderError(RuntimeError):
    """Base provider failure."""


class ProviderConnectionError(LicenseProviderError):
    """Raised when provider cannot be reached."""


class InvalidLicenseKeyError(LicenseProviderError):
    """Raised for malformed or rejected activation keys."""


@dataclass(slots=True, frozen=True)
class ActivationResult:
    state: LicenseState
    license_id: str
    license_blob: dict[str, object] = field(default_factory=dict)
    message: str = ""


@dataclass(slots=True, frozen=True)
class ValidationResult:
    state: LicenseState
    message: str = ""
    refresh_blob: dict[str, object] | None = None


class LicenseProvider(Protocol):
    def activate(self, key: str, machine_info: Mapping[str, object]) -> ActivationResult: ...

    def deactivate(self, license_id: str) -> None: ...

    def supports_floating(self, local_license_blob: Mapping[str, object]) -> bool: ...

    def acquire_lease(
        self,
        local_license_blob: Mapping[str, object],
        machine_info: Mapping[str, object],
    ) -> ValidationResult: ...

    def release_lease(self, local_license_blob: Mapping[str, object]) -> None: ...

    def validate(self, local_license_blob: Mapping[str, object]) -> ValidationResult: ...

    def refresh(self, local_license_blob: Mapping[str, object]) -> ValidationResult: ...

    def license_status(self, local_license_blob: Mapping[str, object]) -> ValidationResult: ...


class DemoLicenseProvider:
    """Local demo provider implementation behind the provider abstraction.

    Key format:
    - MEMSCOPE-ACTIVE-<token>
    - MEMSCOPE-FLOAT-<token> (demo floating-seat option)
    - MEMSCOPE-TRIAL-<token>
    - MEMSCOPE-EXPIRED-<token>
    - MEMSCOPE-REVOKED-<token>
    """

    def activate(self, key: str, machine_info: Mapping[str, object]) -> ActivationResult:
        normalized = key.strip().upper()
        if not normalized.startswith("MEMSCOPE-") or len(normalized.split("-")) < 3:
            raise InvalidLicenseKeyError("Activation key format is invalid.")

        now = datetime.now(UTC)
        state = self._state_from_key(normalized)
        license_id = f"demo-{abs(hash(normalized))}"

        if state is LicenseState.TRIAL:
            expires_at = now + timedelta(days=14)
        elif state is LicenseState.ACTIVE:
            expires_at = now + timedelta(days=365)
        elif state is LicenseState.EXPIRED:
            expires_at = now - timedelta(days=1)
        else:  # revoked
            expires_at = now + timedelta(days=365)

        floating_enabled = "-FLOAT-" in normalized
        lease_blob: dict[str, object] = {}
        if floating_enabled:
            lease_blob = self._build_lease_blob(machine_info)

        blob = {
            "license_id": license_id,
            "state": state.value,
            "activation_key_hint": normalized[:24],
            "machine_fingerprint": machine_info.get("machine_fingerprint"),
            "issued_at": now.isoformat(),
            "expires_at": expires_at.isoformat(),
            "provider": "demo",
            "license_mode": "floating" if floating_enabled else "node-locked",
            "floating_enabled": floating_enabled,
            **lease_blob,
        }
        return ActivationResult(
            state=state,
            license_id=license_id,
            license_blob=blob,
            message="Activation recorded in local cache.",
        )

    def deactivate(self, license_id: str) -> None:
        if not license_id.strip():
            raise LicenseProviderError("Missing license id for deactivation.")

    def supports_floating(self, local_license_blob: Mapping[str, object]) -> bool:
        return bool(local_license_blob.get("floating_enabled")) or (
            str(local_license_blob.get("license_mode", "")).strip().lower() == "floating"
        )

    def acquire_lease(
        self,
        local_license_blob: Mapping[str, object],
        machine_info: Mapping[str, object],
    ) -> ValidationResult:
        if os.getenv("MEMSCOPE_LICENSE_FORCE_OFFLINE") == "1":
            raise ProviderConnectionError("Provider network unavailable.")
        if not self.supports_floating(local_license_blob):
            return ValidationResult(
                state=LicenseState.INVALID,
                message="Floating lease acquisition requested for a non-floating activation.",
            )

        evaluated = self._evaluate(local_license_blob)
        if evaluated.state in {LicenseState.EXPIRED, LicenseState.REVOKED, LicenseState.INVALID}:
            return evaluated

        refreshed_blob = dict(local_license_blob)
        refreshed_blob.update(self._build_lease_blob(machine_info))
        refreshed_blob["floating_enabled"] = True
        refreshed_blob["license_mode"] = "floating"
        return ValidationResult(
            state=LicenseState.ACTIVE,
            message="Floating lease acquired/refreshed.",
            refresh_blob=refreshed_blob,
        )

    def release_lease(self, local_license_blob: Mapping[str, object]) -> None:
        if not self.supports_floating(local_license_blob):
            return
        lease_id = _as_str(local_license_blob.get("lease_id"))
        if not lease_id:
            raise LicenseProviderError("Missing lease id for release.")

    def validate(self, local_license_blob: Mapping[str, object]) -> ValidationResult:
        if os.getenv("MEMSCOPE_LICENSE_FORCE_OFFLINE") == "1":
            raise ProviderConnectionError("Provider network unavailable.")
        return self._evaluate(local_license_blob)

    def refresh(self, local_license_blob: Mapping[str, object]) -> ValidationResult:
        return self.validate(local_license_blob)

    def license_status(self, local_license_blob: Mapping[str, object]) -> ValidationResult:
        return self._evaluate(local_license_blob)

    def _evaluate(self, local_license_blob: Mapping[str, object]) -> ValidationResult:
        state_raw = str(local_license_blob.get("state", "")).strip().lower()
        try:
            state = LicenseState(state_raw)
        except ValueError:
            return ValidationResult(state=LicenseState.INVALID, message="Cached license state is invalid.")

        if state is LicenseState.REVOKED:
            return ValidationResult(state=LicenseState.REVOKED, message="License was revoked.")

        if self.supports_floating(local_license_blob):
            lease_expires = self._parse_timestamp(local_license_blob.get("lease_expires_at"))
            now = datetime.now(UTC)
            if lease_expires is None or lease_expires <= now:
                return ValidationResult(
                    state=LicenseState.EXPIRED,
                    message="Floating lease is missing or expired.",
                )
            return ValidationResult(
                state=LicenseState.ACTIVE,
                message="Floating lease is valid.",
            )

        expires = self._parse_timestamp(local_license_blob.get("expires_at"))
        now = datetime.now(UTC)
        if expires is not None and expires <= now:
            return ValidationResult(state=LicenseState.EXPIRED, message="License has expired.")

        if state in (LicenseState.ACTIVE, LicenseState.TRIAL):
            return ValidationResult(state=state, message="License is valid.")

        return ValidationResult(state=LicenseState.INVALID, message="Unsupported cached state.")

    @staticmethod
    def _state_from_key(key: str) -> LicenseState:
        if "-FLOAT-" in key:
            return LicenseState.ACTIVE
        if "-ACTIVE-" in key:
            return LicenseState.ACTIVE
        if "-TRIAL-" in key:
            return LicenseState.TRIAL
        if "-EXPIRED-" in key:
            return LicenseState.EXPIRED
        if "-REVOKED-" in key:
            return LicenseState.REVOKED
        raise InvalidLicenseKeyError("Activation key is not recognized by provider.")

    @staticmethod
    def _parse_timestamp(value: object) -> datetime | None:
        if not isinstance(value, str) or not value.strip():
            return None
        try:
            parsed = datetime.fromisoformat(value)
        except ValueError:
            return None
        if parsed.tzinfo is None:
            return parsed.replace(tzinfo=UTC)
        return parsed.astimezone(UTC)

    @staticmethod
    def _build_lease_blob(machine_info: Mapping[str, object]) -> dict[str, object]:
        now = datetime.now(UTC)
        lease_seed = f"{machine_info.get('install_id')}-{now.isoformat()}"
        lease_id = f"lease-{abs(hash(lease_seed))}"
        return {
            "lease_id": lease_id,
            "lease_issued_at": now.isoformat(),
            "lease_expires_at": (now + timedelta(hours=8)).isoformat(),
        }


class EnterpriseLicenseProvider:
    """Enterprise provider implementation for activation and lease workflows.

    Key format:
    - MEMSCOPE-ENT-ACTIVE-<token>
    - MEMSCOPE-ENT-FLOAT-<token>
    - MEMSCOPE-ENT-TRIAL-<token>
    - MEMSCOPE-ENT-EXPIRED-<token>
    - MEMSCOPE-ENT-REVOKED-<token>
    """

    def activate(self, key: str, machine_info: Mapping[str, object]) -> ActivationResult:
        normalized = key.strip().upper()
        if not normalized.startswith("MEMSCOPE-ENT-") or len(normalized.split("-")) < 4:
            raise InvalidLicenseKeyError("Enterprise activation key format is invalid.")
        if os.getenv("MEMSCOPE_LICENSE_FORCE_OFFLINE") == "1":
            raise ProviderConnectionError(
                "Enterprise activation requires online provider connectivity.",
            )

        now = datetime.now(UTC)
        state = self._state_from_key(normalized)
        floating_enabled = "-FLOAT-" in normalized
        license_id = f"ent-{abs(hash(normalized))}"
        account_id = self._account_id_from_key(normalized)

        if state is LicenseState.TRIAL:
            expires_at = now + timedelta(days=30)
        elif state is LicenseState.ACTIVE:
            expires_at = now + timedelta(days=365)
        elif state is LicenseState.EXPIRED:
            expires_at = now - timedelta(days=1)
        else:
            expires_at = now + timedelta(days=365)

        lease_blob: dict[str, object] = {}
        if floating_enabled:
            lease_blob = self._build_lease_blob(machine_info)

        blob = {
            "license_id": license_id,
            "state": state.value,
            "provider": "enterprise",
            "activation_flow": "enterprise",
            "activation_key_hint": normalized[:24],
            "machine_fingerprint": machine_info.get("machine_fingerprint"),
            "issued_at": now.isoformat(),
            "expires_at": expires_at.isoformat(),
            "enterprise_account_id": account_id,
            "seat_kind": "floating" if floating_enabled else "node-locked",
            "license_mode": "floating" if floating_enabled else "node-locked",
            "floating_enabled": floating_enabled,
            "lease_generation": 1 if floating_enabled else 0,
            **lease_blob,
        }

        return ActivationResult(
            state=state,
            license_id=license_id,
            license_blob=blob,
            message="Enterprise activation recorded in local cache.",
        )

    def deactivate(self, license_id: str) -> None:
        if not license_id.strip():
            raise LicenseProviderError("Missing enterprise license id for deactivation.")

    def supports_floating(self, local_license_blob: Mapping[str, object]) -> bool:
        return bool(local_license_blob.get("floating_enabled")) or (
            str(local_license_blob.get("seat_kind", "")).strip().lower() == "floating"
        )

    def acquire_lease(
        self,
        local_license_blob: Mapping[str, object],
        machine_info: Mapping[str, object],
    ) -> ValidationResult:
        if os.getenv("MEMSCOPE_LICENSE_FORCE_OFFLINE") == "1":
            raise ProviderConnectionError("Enterprise lease service is unavailable.")
        if not self.supports_floating(local_license_blob):
            return ValidationResult(
                state=LicenseState.INVALID,
                message="Enterprise lease acquisition requested for non-floating activation.",
            )

        evaluated = self._evaluate(local_license_blob)
        if evaluated.state in {LicenseState.EXPIRED, LicenseState.REVOKED, LicenseState.INVALID}:
            return evaluated

        refreshed_blob = dict(local_license_blob)
        refreshed_blob.update(self._build_lease_blob(machine_info))
        refreshed_blob["floating_enabled"] = True
        refreshed_blob["seat_kind"] = "floating"
        refreshed_blob["license_mode"] = "floating"
        refreshed_blob["lease_generation"] = _as_int(refreshed_blob.get("lease_generation")) + 1
        refreshed_blob["last_lease_refresh"] = datetime.now(UTC).isoformat()
        return ValidationResult(
            state=LicenseState.ACTIVE,
            message="Enterprise floating lease acquired/refreshed.",
            refresh_blob=refreshed_blob,
        )

    def release_lease(self, local_license_blob: Mapping[str, object]) -> None:
        if not self.supports_floating(local_license_blob):
            return
        lease_id = _as_str(local_license_blob.get("lease_id"))
        if not lease_id:
            raise LicenseProviderError("Missing enterprise lease id for release.")

    def validate(self, local_license_blob: Mapping[str, object]) -> ValidationResult:
        if os.getenv("MEMSCOPE_LICENSE_FORCE_OFFLINE") == "1":
            raise ProviderConnectionError("Enterprise license service is unavailable.")
        return self._evaluate(local_license_blob)

    def refresh(self, local_license_blob: Mapping[str, object]) -> ValidationResult:
        return self.validate(local_license_blob)

    def license_status(self, local_license_blob: Mapping[str, object]) -> ValidationResult:
        return self._evaluate(local_license_blob)

    def _evaluate(self, local_license_blob: Mapping[str, object]) -> ValidationResult:
        state_raw = str(local_license_blob.get("state", "")).strip().lower()
        try:
            state = LicenseState(state_raw)
        except ValueError:
            return ValidationResult(
                state=LicenseState.INVALID,
                message="Cached enterprise state is invalid.",
            )

        if state is LicenseState.REVOKED:
            return ValidationResult(
                state=LicenseState.REVOKED,
                message="Enterprise license entitlement was revoked.",
            )

        expires = self._parse_timestamp(local_license_blob.get("expires_at"))
        now = datetime.now(UTC)
        if expires is not None and expires <= now:
            return ValidationResult(
                state=LicenseState.EXPIRED,
                message="Enterprise license entitlement has expired.",
            )

        if self.supports_floating(local_license_blob):
            lease_expires = self._parse_timestamp(local_license_blob.get("lease_expires_at"))
            if lease_expires is None or lease_expires <= now:
                return ValidationResult(
                    state=LicenseState.EXPIRED,
                    message="Enterprise floating lease is missing or expired.",
                )

        if state in (LicenseState.ACTIVE, LicenseState.TRIAL):
            return ValidationResult(
                state=state,
                message="Enterprise license entitlement is valid.",
            )

        return ValidationResult(
            state=LicenseState.INVALID,
            message="Unsupported enterprise license state.",
        )

    @staticmethod
    def _state_from_key(key: str) -> LicenseState:
        if "-FLOAT-" in key:
            return LicenseState.ACTIVE
        if "-ACTIVE-" in key:
            return LicenseState.ACTIVE
        if "-TRIAL-" in key:
            return LicenseState.TRIAL
        if "-EXPIRED-" in key:
            return LicenseState.EXPIRED
        if "-REVOKED-" in key:
            return LicenseState.REVOKED
        raise InvalidLicenseKeyError("Enterprise activation key is not recognized.")

    @staticmethod
    def _parse_timestamp(value: object) -> datetime | None:
        if not isinstance(value, str) or not value.strip():
            return None
        try:
            parsed = datetime.fromisoformat(value)
        except ValueError:
            return None
        if parsed.tzinfo is None:
            return parsed.replace(tzinfo=UTC)
        return parsed.astimezone(UTC)

    @staticmethod
    def _build_lease_blob(machine_info: Mapping[str, object]) -> dict[str, object]:
        now = datetime.now(UTC)
        lease_seed = f"enterprise-{machine_info.get('install_id')}-{now.isoformat()}"
        lease_id = f"ent-lease-{abs(hash(lease_seed))}"
        return {
            "lease_id": lease_id,
            "lease_issued_at": now.isoformat(),
            "lease_expires_at": (now + timedelta(hours=8)).isoformat(),
        }

    @staticmethod
    def _account_id_from_key(key: str) -> str:
        parts = key.split("-")
        if len(parts) < 5:
            return "enterprise-default"
        return f"org-{parts[-1].lower()}"


class RoutedLicenseProvider:
    """Route license operations to the demo, enterprise, or Keygen provider.

    Routing strategy (key-prefix-based, deterministic):

    - ``MEMSCOPE-ENT-...`` → enterprise (in-house enterprise format)
    - ``MEMSCOPE-...`` (other prefixes) → demo (test/dev keys for the
      ``DemoLicenseProvider`` synthetic state machine)
    - Anything else → Keygen (real customer keys look like
      ``B48CA6-2B49C5-A8CEA5-8B7153-BD33FB-V3``)

    For cached blobs, the provider is selected by the blob's ``provider``
    field. This means once a license is activated, every subsequent call
    uses the same backend that issued it.
    """

    def __init__(
        self,
        *,
        demo_provider: LicenseProvider | None = None,
        enterprise_provider: LicenseProvider | None = None,
        keygen_provider: LicenseProvider | None = None,
    ) -> None:
        self._demo_provider = demo_provider or DemoLicenseProvider()
        self._enterprise_provider = enterprise_provider or EnterpriseLicenseProvider()
        # Keygen instantiation is lazy: building an httpx.Client costs
        # ~300ms (cert/session setup), which would multiply across hundreds
        # of tests that never route to Keygen. We construct on first use
        # via _get_keygen_provider(); the explicit override path
        # (``keygen_provider=...``) bypasses lazy-init for tests that DO
        # want to inject a mock client.
        self._keygen_provider_override = keygen_provider
        self._keygen_provider_cached: LicenseProvider | None = None

    def activate(self, key: str, machine_info: Mapping[str, object]) -> ActivationResult:
        provider = self._provider_for_activation_key(key)
        return provider.activate(key, machine_info)

    def deactivate(self, license_id: str) -> None:
        provider = self._provider_for_license_id(license_id)
        provider.deactivate(license_id)

    def supports_floating(self, local_license_blob: Mapping[str, object]) -> bool:
        provider = self._provider_for_blob(local_license_blob)
        return provider.supports_floating(local_license_blob)

    def acquire_lease(
        self,
        local_license_blob: Mapping[str, object],
        machine_info: Mapping[str, object],
    ) -> ValidationResult:
        provider = self._provider_for_blob(local_license_blob)
        return provider.acquire_lease(local_license_blob, machine_info)

    def release_lease(self, local_license_blob: Mapping[str, object]) -> None:
        provider = self._provider_for_blob(local_license_blob)
        provider.release_lease(local_license_blob)

    def validate(self, local_license_blob: Mapping[str, object]) -> ValidationResult:
        provider = self._provider_for_blob(local_license_blob)
        return provider.validate(local_license_blob)

    def refresh(self, local_license_blob: Mapping[str, object]) -> ValidationResult:
        provider = self._provider_for_blob(local_license_blob)
        return provider.refresh(local_license_blob)

    def license_status(self, local_license_blob: Mapping[str, object]) -> ValidationResult:
        provider = self._provider_for_blob(local_license_blob)
        return provider.license_status(local_license_blob)

    def _get_keygen_provider(self) -> LicenseProvider:
        if self._keygen_provider_override is not None:
            return self._keygen_provider_override
        if self._keygen_provider_cached is None:
            from memscope.licensing.keygen_provider import KeygenLicenseProvider

            self._keygen_provider_cached = KeygenLicenseProvider()
        return self._keygen_provider_cached

    def _provider_for_activation_key(self, key: str) -> LicenseProvider:
        normalized = key.strip().upper()
        if normalized.startswith("MEMSCOPE-ENT-"):
            return self._enterprise_provider
        if normalized.startswith("MEMSCOPE-"):
            return self._demo_provider
        return self._get_keygen_provider()

    def _provider_for_license_id(self, license_id: str) -> LicenseProvider:
        normalized = license_id.strip().lower()
        if normalized.startswith("ent-"):
            return self._enterprise_provider
        if normalized.startswith("demo-"):
            return self._demo_provider
        return self._get_keygen_provider()

    def _provider_for_blob(self, local_license_blob: Mapping[str, object]) -> LicenseProvider:
        provider_name = _as_str(local_license_blob.get("provider")).lower()
        if provider_name == "enterprise":
            return self._enterprise_provider
        if provider_name == "demo":
            return self._demo_provider
        if provider_name == "keygen":
            return self._get_keygen_provider()
        # Legacy/unknown blobs default to demo (matches prior behavior).
        return self._demo_provider


def _as_str(value: object) -> str:
    return str(value).strip() if value is not None else ""


def _as_int(value: object) -> int:
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        stripped = value.strip()
        if stripped:
            try:
                return int(stripped)
            except ValueError:
                return 0
    return 0
