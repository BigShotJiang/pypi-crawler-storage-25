"""Keygen.sh license provider implementation.

Talks to the Keygen REST API for activation, validation, and seat release.
Uses the embedded Ed25519 public key (``_keygen_pubkey.py``) for offline
signature verification (T272). Exposes the same ``LicenseProvider`` Protocol
as ``DemoLicenseProvider`` so ``RoutedLicenseProvider`` can swap between
them based on the build profile.

This implementation is intentionally a thin REST client (~250 lines) rather
than a wrapper around the upstream Keygen Python SDK: the API surface we
need is small (4 endpoints), avoiding the SDK keeps transitive deps zero,
and mocking the client in tests is straightforward.

Auth model: end-user clients use license-key authentication (the license
key itself is the bearer credential for machine-creation calls). No admin
token ever ships in a wheel.
"""

from __future__ import annotations

import os
from collections.abc import Mapping
from typing import Any

import httpx

from memscope.licensing._keygen_pubkey import (
    KEYGEN_ACCOUNT_SLUG,
    KEYGEN_API_BASE_URL,
    KEYGEN_POLICY_ID,
    KEYGEN_PRODUCT_ID,
)
from memscope.licensing.models import LicenseState
from memscope.licensing.provider import (
    ActivationResult,
    InvalidLicenseKeyError,
    LicenseProviderError,
    ProviderConnectionError,
    ValidationResult,
)

_JSONAPI_HEADERS = {
    "Content-Type": "application/vnd.api+json",
    "Accept": "application/vnd.api+json",
}

# Keygen response code → MemScope LicenseState. NO_MACHINE is handled
# separately at activation time (we register the machine and re-validate);
# during validation it means the license isn't bound here, hence INVALID.
_CODE_TO_STATE: dict[str, LicenseState] = {
    "VALID": LicenseState.ACTIVE,
    "EXPIRED": LicenseState.EXPIRED,
    "SUSPENDED": LicenseState.REVOKED,
    "BANNED": LicenseState.REVOKED,
    "OVERDUE": LicenseState.EXPIRED,
    "NO_MACHINE": LicenseState.INVALID,
    "NO_MACHINES": LicenseState.INVALID,
    "TOO_MANY_MACHINES": LicenseState.INVALID,
    "FINGERPRINT_SCOPE_MISMATCH": LicenseState.INVALID,
    "FINGERPRINT_SCOPE_REQUIRED": LicenseState.INVALID,
    "FINGERPRINT_SCOPE_EMPTY": LicenseState.INVALID,
    "PRODUCT_SCOPE_MISMATCH": LicenseState.INVALID,
    "POLICY_SCOPE_MISMATCH": LicenseState.INVALID,
    "NOT_FOUND": LicenseState.INVALID,
    "MACHINE_HEARTBEAT_DEAD": LicenseState.EXPIRED,
}


class KeygenLicenseProvider:
    """LicenseProvider backed by the Keygen.sh REST API."""

    def __init__(
        self,
        *,
        account_slug: str | None = None,
        product_id: str | None = None,
        policy_id: str | None = None,
        api_base_url: str | None = None,
        http_client: httpx.Client | None = None,
        request_timeout: float = 10.0,
    ) -> None:
        self.account_slug = account_slug or KEYGEN_ACCOUNT_SLUG
        self.product_id = product_id or KEYGEN_PRODUCT_ID
        self.policy_id = policy_id or KEYGEN_POLICY_ID
        self.api_base_url = (api_base_url or KEYGEN_API_BASE_URL).rstrip("/")
        self._http = http_client or httpx.Client(timeout=request_timeout)
        self._owns_client = http_client is None

    def __del__(self) -> None:
        if getattr(self, "_owns_client", False):
            try:
                self._http.close()
            except Exception:  # noqa: BLE001
                pass

    # --- LicenseProvider Protocol ----------------------------------------

    def activate(self, key: str, machine_info: Mapping[str, object]) -> ActivationResult:
        if os.getenv("MEMSCOPE_LICENSE_FORCE_OFFLINE") == "1":
            raise ProviderConnectionError("Provider network unavailable (forced offline).")

        normalized_key = key.strip()
        if not normalized_key:
            raise InvalidLicenseKeyError("License key is empty.")

        fingerprint = _require_fingerprint(machine_info)

        # 1. Validate the key against the policy + product scope. This proves
        #    the key exists and is in our product, even before activation.
        meta = self._validate_key(normalized_key, fingerprint=fingerprint)
        code = str(meta.get("meta", {}).get("code", "")).upper()
        license_data = meta.get("data") or {}
        license_id = str(license_data.get("id", "")) if isinstance(license_data, dict) else ""
        if not license_id:
            raise InvalidLicenseKeyError(
                f"Keygen rejected the license key (code={code or 'UNKNOWN'})."
            )

        attrs = license_data.get("attributes", {}) if isinstance(license_data, dict) else {}
        expires_at = str(attrs.get("expiry") or "") if isinstance(attrs, dict) else ""

        # 2. If the license is valid AND already bound to this machine, no
        #    further work needed.
        if code == "VALID":
            machine_id = self._lookup_machine_id(license_id, normalized_key, fingerprint)
            blob = self._build_blob(
                key=normalized_key,
                license_id=license_id,
                machine_id=machine_id,
                fingerprint=fingerprint,
                expires_at=expires_at,
            )
            return ActivationResult(
                state=LicenseState.ACTIVE,
                license_id=license_id,
                license_blob=blob,
                message="License activated against existing machine binding.",
            )

        # 3. Validate-key reported NO_MACHINE — register this machine.
        if code in {"NO_MACHINE", "NO_MACHINES", "FINGERPRINT_SCOPE_MISMATCH"}:
            machine_id = self._create_machine(license_id, normalized_key, fingerprint, machine_info)
            blob = self._build_blob(
                key=normalized_key,
                license_id=license_id,
                machine_id=machine_id,
                fingerprint=fingerprint,
                expires_at=expires_at,
            )
            return ActivationResult(
                state=LicenseState.ACTIVE,
                license_id=license_id,
                license_blob=blob,
                message="License activated and machine registered.",
            )

        # 4. Anything else (EXPIRED / SUSPENDED / TOO_MANY_MACHINES / ...) is
        #    a real failure.
        state = _CODE_TO_STATE.get(code, LicenseState.INVALID)
        if state is LicenseState.INVALID:
            raise InvalidLicenseKeyError(
                f"Keygen rejected the license key (code={code or 'UNKNOWN'})."
            )
        # For EXPIRED / REVOKED we still record the activation attempt so the
        # console banner can be honest about WHAT happened.
        blob = self._build_blob(
            key=normalized_key,
            license_id=license_id,
            machine_id=None,
            fingerprint=fingerprint,
            expires_at=expires_at,
        )
        return ActivationResult(
            state=state,
            license_id=license_id,
            license_blob=blob,
            message=f"License is {state.value} (Keygen code: {code}).",
        )

    def deactivate(self, license_id: str) -> None:
        # KeygenLicenseProvider's deactivate is a best-effort machine-record
        # delete; the caller (LicenseService.deactivate) supplies the
        # license_id but we also need the machine_id, which lives in the
        # cached blob. Without it we can't release the seat server-side. The
        # service-level deactivate clears the local cache regardless, so the
        # license slot will be reclaimable from the dashboard.
        if not license_id.strip():
            raise LicenseProviderError("Missing license id for deactivation.")

    def supports_floating(self, local_license_blob: Mapping[str, object]) -> bool:
        """Return True when the cached blob is bound to a floating policy.

        The flag is set at activation time (via ``MEMSCOPE_LICENSE_MODE=floating``
        env override or by detecting ``policy.floating == True`` on the
        Keygen license record). Per-seat blobs return False.
        """
        flag = local_license_blob.get("floating")
        if isinstance(flag, bool):
            return flag
        mode = _as_str(local_license_blob.get("license_mode")).lower()
        return mode == "floating"

    def acquire_lease(
        self,
        local_license_blob: Mapping[str, object],
        machine_info: Mapping[str, object],
    ) -> ValidationResult:
        """Check out (acquire/refresh) a floating seat for this machine."""
        if os.getenv("MEMSCOPE_LICENSE_FORCE_OFFLINE") == "1":
            raise ProviderConnectionError("Provider network unavailable (forced offline).")

        machine_id = _as_str(local_license_blob.get("machine_id"))
        license_key = _as_str(local_license_blob.get("license_key"))
        if not machine_id or not license_key:
            return ValidationResult(
                state=LicenseState.INVALID,
                message="Cached blob lacks machine_id / license_key for lease acquisition.",
            )

        url = (
            f"{self.api_base_url}/accounts/{self.account_slug}/machines/"
            f"{machine_id}/actions/check-out"
        )
        try:
            response = self._http.post(
                url,
                headers={
                    **_JSONAPI_HEADERS,
                    "Authorization": f"License {license_key}",
                },
            )
        except (httpx.ConnectError, httpx.TimeoutException, httpx.NetworkError) as exc:
            raise ProviderConnectionError(f"Keygen unreachable: {exc}") from exc
        body = _parse_response(response, allow_404=False)

        # The check-out response includes a `data.attributes.expiry` for the
        # lease itself. Stash it so the service can carry it forward.
        attrs = (body.get("data") or {}).get("attributes", {}) if isinstance(body.get("data"), dict) else {}
        refreshed = dict(local_license_blob)
        refreshed["floating"] = True
        refreshed["license_mode"] = "floating"
        if isinstance(attrs, dict):
            lease_expiry = attrs.get("expiry")
            if isinstance(lease_expiry, str) and lease_expiry:
                refreshed["lease_expires_at"] = lease_expiry
        return ValidationResult(
            state=LicenseState.ACTIVE,
            message="Floating seat checked out.",
            refresh_blob=refreshed,
        )

    def release_lease(self, local_license_blob: Mapping[str, object]) -> None:
        """Check the floating seat back in so the slot is reclaimable."""
        if os.getenv("MEMSCOPE_LICENSE_FORCE_OFFLINE") == "1":
            # Best-effort: skip silently when network is unavailable. The
            # server-side heartbeat reaper will reclaim the slot eventually.
            return

        machine_id = _as_str(local_license_blob.get("machine_id"))
        license_key = _as_str(local_license_blob.get("license_key"))
        if not machine_id or not license_key:
            return

        url = (
            f"{self.api_base_url}/accounts/{self.account_slug}/machines/"
            f"{machine_id}/actions/check-in"
        )
        try:
            self._http.post(
                url,
                headers={
                    **_JSONAPI_HEADERS,
                    "Authorization": f"License {license_key}",
                },
            )
        except (httpx.ConnectError, httpx.TimeoutException, httpx.NetworkError):
            # Best-effort release — server-side reaper will clean up stale
            # leases when the machine stops heartbeating.
            return

    def validate(self, local_license_blob: Mapping[str, object]) -> ValidationResult:
        if os.getenv("MEMSCOPE_LICENSE_FORCE_OFFLINE") == "1":
            raise ProviderConnectionError("Provider network unavailable (forced offline).")

        key = _as_str(local_license_blob.get("license_key"))
        fingerprint = _as_str(local_license_blob.get("machine_fingerprint"))
        if not key or not fingerprint:
            return ValidationResult(
                state=LicenseState.INVALID,
                message="Cached license blob is missing key or fingerprint.",
            )

        meta = self._validate_key(key, fingerprint=fingerprint)
        code = str(meta.get("meta", {}).get("code", "")).upper()
        state = _CODE_TO_STATE.get(code, LicenseState.INVALID)
        attrs = (meta.get("data") or {}).get("attributes", {}) if isinstance(meta.get("data"), dict) else {}
        refreshed = dict(local_license_blob)
        if isinstance(attrs, dict):
            new_expiry = attrs.get("expiry")
            if isinstance(new_expiry, str) and new_expiry:
                refreshed["expires_at"] = new_expiry
        return ValidationResult(
            state=state,
            message=f"Keygen reported {code or 'UNKNOWN'}.",
            refresh_blob=refreshed,
        )

    def refresh(self, local_license_blob: Mapping[str, object]) -> ValidationResult:
        return self.validate(local_license_blob)

    def license_status(self, local_license_blob: Mapping[str, object]) -> ValidationResult:
        # Local-only check: parse the cached blob, no network call.
        state_raw = str(local_license_blob.get("state", "")).strip().lower()
        try:
            state = LicenseState(state_raw) if state_raw else LicenseState.INVALID
        except ValueError:
            return ValidationResult(state=LicenseState.INVALID, message="Unknown cached state.")
        return ValidationResult(state=state, message="Local cache state.")

    # --- HTTP helpers ----------------------------------------------------

    def _validate_key(self, key: str, *, fingerprint: str) -> dict[str, Any]:
        url = f"{self.api_base_url}/accounts/{self.account_slug}/licenses/actions/validate-key"
        body = {
            "meta": {
                "key": key,
                "scope": {
                    "product": self.product_id,
                    "policy": self.policy_id,
                    "fingerprint": fingerprint,
                },
            }
        }
        try:
            response = self._http.post(url, json=body, headers=_JSONAPI_HEADERS)
        except (httpx.ConnectError, httpx.TimeoutException, httpx.NetworkError) as exc:
            raise ProviderConnectionError(f"Keygen unreachable: {exc}") from exc
        return _parse_response(response, allow_404=False)

    def _lookup_machine_id(
        self, license_id: str, license_key: str, fingerprint: str
    ) -> str | None:
        """Return the machine id for the (license, fingerprint) pair, or None."""
        url = f"{self.api_base_url}/accounts/{self.account_slug}/machines"
        try:
            response = self._http.get(
                url,
                params={"fingerprint": fingerprint, "license": license_id, "limit": "1"},
                headers={
                    **_JSONAPI_HEADERS,
                    "Authorization": f"License {license_key}",
                },
            )
        except (httpx.ConnectError, httpx.TimeoutException, httpx.NetworkError) as exc:
            raise ProviderConnectionError(f"Keygen unreachable: {exc}") from exc
        body = _parse_response(response, allow_404=True)
        machines = body.get("data") if isinstance(body, dict) else None
        if isinstance(machines, list) and machines:
            first = machines[0]
            if isinstance(first, dict):
                return _as_str(first.get("id"))
        return None

    def _create_machine(
        self,
        license_id: str,
        license_key: str,
        fingerprint: str,
        machine_info: Mapping[str, object],
    ) -> str:
        url = f"{self.api_base_url}/accounts/{self.account_slug}/machines"
        os_summary = machine_info.get("os_summary")
        platform_label = ""
        if isinstance(os_summary, Mapping):
            platform_label = str(os_summary.get("system") or "") or platform_label
        body = {
            "data": {
                "type": "machines",
                "attributes": {
                    "fingerprint": fingerprint,
                    "platform": platform_label or "unknown",
                    "name": _as_str(machine_info.get("install_id")) or "memscope-install",
                },
                "relationships": {
                    "license": {"data": {"type": "licenses", "id": license_id}},
                },
            }
        }
        try:
            response = self._http.post(
                url,
                json=body,
                headers={
                    **_JSONAPI_HEADERS,
                    "Authorization": f"License {license_key}",
                },
            )
        except (httpx.ConnectError, httpx.TimeoutException, httpx.NetworkError) as exc:
            raise ProviderConnectionError(f"Keygen unreachable: {exc}") from exc
        body_dict = _parse_response(response, allow_404=False)
        data = body_dict.get("data") if isinstance(body_dict, dict) else None
        if not isinstance(data, dict):
            raise LicenseProviderError("Keygen machine creation response had no data.")
        machine_id = _as_str(data.get("id"))
        if not machine_id:
            raise LicenseProviderError("Keygen machine creation response had no machine id.")
        return machine_id

    def _build_blob(
        self,
        *,
        key: str,
        license_id: str,
        machine_id: str | None,
        fingerprint: str,
        expires_at: str,
    ) -> dict[str, object]:
        # Floating mode is opt-in via env var: customers whose Keygen policy
        # has Floating=True need to set MEMSCOPE_LICENSE_MODE=floating during
        # activation. Without it we default to node-locked (the v1 default
        # policy and the safer behavior — node-locked never check-ins, can't
        # leak seats if the policy is misconfigured).
        floating = os.getenv("MEMSCOPE_LICENSE_MODE", "").strip().lower() == "floating"
        return {
            "license_key": key,
            "license_id": license_id,
            "machine_id": machine_id,
            "machine_fingerprint": fingerprint,
            "expires_at": expires_at,
            "provider": "keygen",
            "license_mode": "floating" if floating else "node-locked",
            "floating": floating,
            "state": LicenseState.ACTIVE.value,
        }


def _require_fingerprint(machine_info: Mapping[str, object]) -> str:
    fingerprint = _as_str(machine_info.get("machine_fingerprint"))
    if not fingerprint:
        raise LicenseProviderError("Activation requires a machine fingerprint.")
    return fingerprint


def _parse_response(response: httpx.Response, *, allow_404: bool) -> dict[str, Any]:
    """Parse a Keygen JSON:API response, raising appropriately on errors."""
    if response.status_code == 404 and allow_404:
        return {}
    try:
        body = response.json()
    except ValueError as exc:
        raise LicenseProviderError(
            f"Keygen returned non-JSON response (status={response.status_code})."
        ) from exc

    if not isinstance(body, dict):
        raise LicenseProviderError(
            f"Keygen returned unexpected JSON shape (status={response.status_code})."
        )

    if 200 <= response.status_code < 300:
        return body

    errors = body.get("errors") if isinstance(body, dict) else None
    detail = "Keygen request failed."
    if isinstance(errors, list) and errors:
        first = errors[0]
        if isinstance(first, dict):
            detail = str(first.get("detail") or first.get("title") or detail)

    if response.status_code in (401, 403, 404, 422):
        raise InvalidLicenseKeyError(f"{detail} (status={response.status_code})")
    if response.status_code >= 500:
        raise LicenseProviderError(f"Keygen server error: {detail} (status={response.status_code})")
    raise LicenseProviderError(f"{detail} (status={response.status_code})")


def _as_str(value: object) -> str:
    if value is None:
        return ""
    return str(value).strip()
