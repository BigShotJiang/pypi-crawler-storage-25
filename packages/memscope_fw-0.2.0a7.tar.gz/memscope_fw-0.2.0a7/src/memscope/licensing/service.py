"""Licensing service orchestration and enforcement."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any

from memscope.licensing.cache import (
    ActivationCache,
    LicenseCacheTamperedError,
    TrialClock,
    TrialStateTamperedError,
)
from memscope.licensing.dev_mode import DeveloperModeLicenseBridge
from memscope.licensing.machine_fingerprint import MachineFingerprintProvider
from memscope.licensing.models import LicenseState, LicenseStatus
from memscope.licensing.provider import (
    InvalidLicenseKeyError,
    LicenseProvider,
    LicenseProviderError,
    ProviderConnectionError,
    RoutedLicenseProvider,
)

TRIAL_DAYS = 14

# After every successful online refresh, the licensing service stamps the
# cached blob with ``offline_valid_until = now + OFFLINE_GRACE_DAYS``. While
# that timestamp is in the future, the tool runs offline using the cached
# state. Past it, commands are refused with EXPIRED until the next online
# refresh succeeds. Matches the "Require Check-In" / "Heartbeat Duration"
# semantics in the Keygen policy without depending on Keygen's heartbeat
# infrastructure (which would force every machine to phone home periodically
# even when the user just wants to inspect a report).
OFFLINE_GRACE_DAYS = 7

_ALLOWED_COMMERCIAL_STATES: frozenset[LicenseState] = frozenset(
    {
        LicenseState.TRIAL,
        LicenseState.ACTIVE,
        LicenseState.OFFLINE_VALID,
        LicenseState.DEVELOPER_MODE,
    }
)


class LicenseServiceError(RuntimeError):
    """Base licensing service error."""


class LicenseActivationError(LicenseServiceError):
    """Activation failed because key/provider response was invalid."""


class LicenseEnforcementError(LicenseServiceError):
    """Raised when a command requires a valid commercial license state."""

    def __init__(self, *, command_name: str, status: LicenseStatus) -> None:
        self.command_name = command_name
        self.status = status
        super().__init__(
            f"License check failed for '{command_name}': "
            f"{status.state.value} ({status.message})"
        )


@dataclass(slots=True)
class LicenseService:
    provider: LicenseProvider
    machine: MachineFingerprintProvider
    cache: ActivationCache
    dev_mode: DeveloperModeLicenseBridge

    def activate(self, key: str) -> LicenseStatus:
        normalized_key = key.strip()
        if not normalized_key:
            raise LicenseActivationError("License activation key cannot be empty.")

        machine_info = self._machine_info()
        try:
            result = self.provider.activate(normalized_key, machine_info)
        except InvalidLicenseKeyError as exc:
            raise LicenseActivationError(str(exc)) from exc
        except LicenseProviderError as exc:
            raise LicenseServiceError(str(exc)) from exc

        blob = dict(result.license_blob)
        if not blob:
            blob = {
                "state": result.state.value,
                "license_id": result.license_id,
                "provider": "unknown",
            }
        self._stamp_offline_grace(blob)
        self.cache.save_local_license(blob)
        return self._status_from_state(
            result.state,
            source="activation",
            message=result.message or "Activation recorded.",
            cache_blob=blob,
        )

    def deactivate(self) -> LicenseStatus:
        cached = self.cache.load_local_license()
        if cached is None:
            return LicenseStatus(
                state=LicenseState.TRIAL,
                allowed=True,
                source="deactivate",
                message="No local activation was found; remaining in trial mode.",
                cache_present=False,
            )

        license_id = _optional_str(cached.get("license_id"))
        if self.provider.supports_floating(cached):
            try:
                self.provider.release_lease(cached)
            except LicenseProviderError:
                # Local deactivation should proceed even when remote lease release fails.
                pass
        if license_id:
            try:
                self.provider.deactivate(license_id)
            except LicenseProviderError:
                # Local deactivation should still proceed even if provider call fails.
                pass
        self.cache.clear_local_license()
        return LicenseStatus(
            state=LicenseState.TRIAL,
            allowed=True,
            source="deactivate",
            message="Local activation cache cleared. Trial mode is active.",
            cache_present=False,
        )

    def status(self, *, allow_online: bool) -> LicenseStatus:
        override = self.dev_mode.override_status()
        if override is not None:
            return override

        try:
            cached = self.cache.load_local_license()
        except LicenseCacheTamperedError as exc:
            return LicenseStatus(
                state=LicenseState.EXPIRED,
                allowed=False,
                source="cache-tampered",
                message=(
                    f"License cache file is corrupt or modified ({exc}). "
                    "Please re-activate your license."
                ),
                cache_present=False,
            )
        if cached is None:
            return self._evaluate_trial_state()

        if allow_online and self.provider.supports_floating(cached):
            return self._status_with_floating_lease(cached)

        if not allow_online:
            return self._status_from_local_cache(cached)

        try:
            validation = self.provider.validate(cached)
        except ProviderConnectionError:
            return self._status_for_offline(cached)
        except LicenseProviderError as exc:
            return LicenseStatus(
                state=LicenseState.INVALID,
                allowed=False,
                source="provider-error",
                message=f"License validation failed: {exc}",
                license_id=_optional_str(cached.get("license_id")),
                expires_at=_optional_str(cached.get("expires_at")),
                provider=_optional_str(cached.get("provider")),
                cache_present=True,
            )

        refresh_blob = validation.refresh_blob
        if isinstance(refresh_blob, dict) and refresh_blob:
            updated = dict(refresh_blob)
            self._stamp_offline_grace(updated)
            self.cache.save_local_license(updated)
            cached = updated
        elif validation.state in {LicenseState.ACTIVE, LicenseState.OFFLINE_VALID}:
            # No refresh blob was returned (provider didn't echo a fresh blob)
            # but the validation succeeded — bump the grace stamp on the
            # existing cache so future offline runs honor it.
            updated = dict(cached)
            self._stamp_offline_grace(updated)
            self.cache.save_local_license(updated)
            cached = updated

        return self._status_from_state(
            validation.state,
            source="provider-validate",
            message=validation.message or "License validated.",
            cache_blob=cached,
        )

    def require_commercial_use(self, command_name: str, *, allow_online: bool = False) -> LicenseStatus:
        status = self.status(allow_online=allow_online)
        if status.allowed:
            return status
        raise LicenseEnforcementError(command_name=command_name, status=status)

    def _evaluate_trial_state(self) -> LicenseStatus:
        """Resolve the user's state when no activation is cached.

        State machine for unactivated installs:

        - **First run** → initialize trial clock → ``TRIAL`` (14 days, full
          paid features unlocked). The dev gets the wow-moment of the full
          product immediately.
        - **Within 14 days** → ``TRIAL`` (paid features still unlocked).
        - **Past 14 days** → ``FREE`` (visibility still works — analyze
          runs, reports generate, baseline diff visible. Paid features
          like ``--strict`` / ``validate`` / ``diff`` / custom budgets
          are blocked, but the build doesn't break). This is the
          devolve-to-free behavior that keeps developer cmake builds
          working forever.
        - **Activated** (handled elsewhere) → ``ACTIVE`` / ``OFFLINE_VALID``
          (the trial clock becomes irrelevant once the user pays).

        Tampered trial state file → ``EXPIRED`` (tampering is treated as
        explicit license invalidation, not graceful devolve).
        """
        try:
            clock = self.cache.load_trial_clock()
        except TrialStateTamperedError as exc:
            return LicenseStatus(
                state=LicenseState.EXPIRED,
                allowed=False,
                source="trial-tampered",
                message=(
                    f"Trial state file is corrupt or modified ({exc}). "
                    "Please activate a license to continue."
                ),
                cache_present=False,
            )

        if clock is None:
            clock = self.cache.initialize_trial_clock()
            return self._trial_status_from_clock(clock, source="trial-initialized")
        return self._trial_status_from_clock(clock, source="trial-active")

    def _trial_status_from_clock(self, clock: TrialClock, *, source: str) -> LicenseStatus:
        """Map a persisted trial clock into the appropriate user-facing state.

        Returns ``TRIAL`` while the clock is within its 14-day window. After
        the window elapses, returns ``FREE`` (visibility-only, no time
        limit) — see ``docs/internal/handbook/licensing-state-machine.md`` for the rationale.
        FREE is *allowed* (so plain ``analyze`` runs forever) but
        ``paid_features_allowed`` is False, so the existing paid-tier
        gates correctly refuse ``--strict`` / ``validate`` / etc.
        """
        now = self.cache.now()
        remaining = clock.days_remaining(now=now, trial_days=TRIAL_DAYS)
        expires_at = (clock.first_run_at + timedelta(days=TRIAL_DAYS)).isoformat()
        if clock.is_expired(now=now, trial_days=TRIAL_DAYS):
            return LicenseStatus(
                state=LicenseState.FREE,
                allowed=True,
                source="free-edition",
                message=(
                    f"Free Edition (paid trial expired {expires_at}). "
                    "`analyze` and report generation continue to work; "
                    "`--strict`, `validate`, `diff`, `--csv`, and custom "
                    "[budgets] / [policies] require activation. "
                    "Run `memscope license activate <KEY>` to enable CI gating."
                ),
                expires_at=expires_at,
                cache_present=False,
            )
        message = (
            f"Trial: {remaining} day{'s' if remaining != 1 else ''} remaining "
            f"(expires {expires_at})."
        )
        return LicenseStatus(
            state=LicenseState.TRIAL,
            allowed=True,
            source=source,
            message=message,
            expires_at=expires_at,
            cache_present=False,
        )

    def _status_from_local_cache(self, cached: Mapping[str, object]) -> LicenseStatus:
        local = self.provider.license_status(cached)
        if local.state in {LicenseState.ACTIVE, LicenseState.TRIAL}:
            grace_failure = self._offline_grace_failure(cached)
            if grace_failure is not None:
                return grace_failure
            message = "Using cached local activation status (online refresh disabled)."
            if self.provider.supports_floating(cached):
                message = "Using cached floating lease status (online lease refresh disabled)."
            return LicenseStatus(
                state=LicenseState.OFFLINE_VALID,
                allowed=True,
                source="local-cache",
                message=message,
                license_id=_optional_str(cached.get("license_id")),
                expires_at=_optional_str(cached.get("expires_at")),
                provider=_optional_str(cached.get("provider")),
                cache_present=True,
            )
        return self._status_from_state(
            local.state,
            source="local-cache",
            message=local.message or "Cached activation is not valid for commercial commands.",
            cache_blob=cached,
        )

    def _status_for_offline(self, cached: Mapping[str, object]) -> LicenseStatus:
        local = self.provider.license_status(cached)
        if local.state in {LicenseState.ACTIVE, LicenseState.TRIAL}:
            grace_failure = self._offline_grace_failure(cached)
            if grace_failure is not None:
                return grace_failure
            message = (
                "License provider is unavailable; using cached activation "
                "for offline operation."
            )
            if self.provider.supports_floating(cached):
                message = (
                    "License provider is unavailable; using cached floating lease "
                    "for offline operation."
                )
            return LicenseStatus(
                state=LicenseState.OFFLINE_VALID,
                allowed=True,
                source="offline-cache",
                message=message,
                license_id=_optional_str(cached.get("license_id")),
                expires_at=_optional_str(cached.get("expires_at")),
                provider=_optional_str(cached.get("provider")),
                cache_present=True,
            )
        return self._status_from_state(
            local.state,
            source="offline-cache",
            message=(
                local.message
                or "License provider is unavailable and cached activation is not usable."
            ),
            cache_blob=cached,
        )

    def _offline_grace_failure(self, cached: Mapping[str, object]) -> LicenseStatus | None:
        """Return an EXPIRED status when the cached offline-grace has lapsed.

        ``None`` means the cached grace is still valid (or there's no grace
        timestamp yet, in which case we trust the cache — that case only
        happens for blobs written before T273 landed; the next online
        refresh stamps a fresh grace).
        """
        until = _parse_iso_datetime(cached.get("offline_valid_until"))
        if until is None:
            return None
        now = self.cache.now()
        if now <= until:
            return None
        return LicenseStatus(
            state=LicenseState.EXPIRED,
            allowed=False,
            source="offline-grace-expired",
            message=(
                f"License could not be re-validated online and the {OFFLINE_GRACE_DAYS}-day "
                f"offline grace expired on {until.isoformat()}. "
                "Reconnect to the network and run any MemScope command to refresh, "
                "or run `memscope license activate <KEY>`."
            ),
            license_id=_optional_str(cached.get("license_id")),
            expires_at=_optional_str(cached.get("expires_at")),
            provider=_optional_str(cached.get("provider")),
            cache_present=True,
        )

    def _stamp_offline_grace(self, blob: dict[str, object]) -> None:
        """Set ``offline_valid_until`` to ``now + OFFLINE_GRACE_DAYS``."""
        until = self.cache.now() + timedelta(days=OFFLINE_GRACE_DAYS)
        blob["offline_valid_until"] = until.isoformat()

    def _status_with_floating_lease(self, cached: Mapping[str, object]) -> LicenseStatus:
        machine_info = self._machine_info()
        try:
            leased = self.provider.acquire_lease(cached, machine_info)
        except ProviderConnectionError:
            return self._status_for_offline(cached)
        except LicenseProviderError as exc:
            return LicenseStatus(
                state=LicenseState.INVALID,
                allowed=False,
                source="provider-lease-error",
                message=f"Floating lease acquisition failed: {exc}",
                license_id=_optional_str(cached.get("license_id")),
                expires_at=_optional_str(cached.get("expires_at")),
                provider=_optional_str(cached.get("provider")),
                cache_present=True,
            )

        refresh_blob = leased.refresh_blob
        if isinstance(refresh_blob, dict) and refresh_blob:
            self.cache.save_local_license(dict(refresh_blob))
            cached = dict(refresh_blob)

        return self._status_from_state(
            leased.state,
            source="provider-lease",
            message=leased.message or "Floating lease status updated.",
            cache_blob=cached,
        )

    def _status_from_state(
        self,
        state: LicenseState,
        *,
        source: str,
        message: str,
        cache_blob: Mapping[str, object] | None = None,
    ) -> LicenseStatus:
        return LicenseStatus(
            state=state,
            allowed=state in _ALLOWED_COMMERCIAL_STATES,
            source=source,
            message=message,
            license_id=_optional_str(cache_blob.get("license_id")) if cache_blob else None,
            expires_at=_optional_str(cache_blob.get("expires_at")) if cache_blob else None,
            provider=_optional_str(cache_blob.get("provider")) if cache_blob else None,
            cache_present=cache_blob is not None,
        )

    def _machine_info(self) -> dict[str, Any]:
        return {
            "machine_fingerprint": self.machine.get_machine_fingerprint(),
            "os_summary": self.machine.get_os_summary(),
            "install_id": self.machine.get_install_id(),
        }


def build_default_license_service(*, developer_mode: bool) -> LicenseService:
    return LicenseService(
        provider=RoutedLicenseProvider(),
        machine=MachineFingerprintProvider(),
        cache=ActivationCache(),
        dev_mode=DeveloperModeLicenseBridge(enabled=developer_mode),
    )


def _optional_str(value: object) -> str | None:
    if value is None:
        return None
    normalized = str(value).strip()
    return normalized or None


def _parse_iso_datetime(value: object) -> datetime | None:
    """Parse an ISO-8601 timestamp from a cached blob field, or return None.

    Naive datetimes are normalized to UTC so ``cache.now()`` (which is
    always UTC-aware) can be compared without ``TypeError``.
    """
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed
