"""Keygen.sh account constants for license validation.

These values identify MemScope's Keygen tenant and the Ed25519 public key
used to verify cached license tokens during the 7-day offline grace window.
All values here are public material — anyone with them can only validate
licenses, not issue or revoke them. Safe to commit.

If Keygen rotates the public key (e.g., after a security incident), update
``KEYGEN_PUBKEY_HEX`` here and ship a new wheel; existing wheels with the
old key will reject new license tokens but continue honoring cached tokens
until their offline grace expires.

Captured 2026-04-23 during Phase 28 Wave 2 (T269 operational setup).
"""

from __future__ import annotations

# Account / product / policy identifiers used in Keygen API URLs.
KEYGEN_ACCOUNT_SLUG: str = "mem-scope"
KEYGEN_PRODUCT_ID: str = "e5bf063b-93dd-435c-893a-efc9f1b8745f"
KEYGEN_POLICY_ID: str = "85b88c20-5461-4892-88e1-5371ec2ec749"

# Base URL of the Keygen REST API. Override via env var for staging/sandbox.
KEYGEN_API_BASE_URL: str = "https://api.keygen.sh/v1"

# Ed25519 verification key (32 bytes / 256 bits, stored as hex).
# Despite Keygen's UI labelling this "128-bit Verify Key", Ed25519 keys are
# specified as 32 bytes by RFC 8032 — the label is cosmetic.
KEYGEN_PUBKEY_HEX: str = "3dd72e770d68bb03414b6a6ea0b1be8f417d03d43932aa815cf10611a78aa3c5"


def keygen_pubkey_bytes() -> bytes:
    """Return the verification public key as 32 raw bytes."""
    return bytes.fromhex(KEYGEN_PUBKEY_HEX)
