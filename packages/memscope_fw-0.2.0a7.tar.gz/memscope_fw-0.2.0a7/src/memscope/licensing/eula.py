"""End-User License Agreement (EULA) text + acceptance persistence.

The EULA text below is a v1 placeholder — replace with the lawyer-reviewed
final text before the GA release. The persistence and re-prompt machinery
is independent of the text content: changing the text changes the SHA-256
hash, which forces every install to re-accept on the next commercial
command.

Acceptance is stored separately from the activation cache so that
``memscope license deactivate`` does NOT clear it (a user shouldn't have
to re-accept terms every time they swap a license key).
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

# Placeholder EULA text. Replace before GA. Changing this string changes
# EULA_HASH, which invalidates every cached acceptance and forces re-prompt.
EULA_TEXT: str = """\
MemScope End-User License Agreement (v1 - Placeholder)

By using MemScope you agree to:

1. Use the software only on machines you own or are authorized to operate.
2. Not redistribute, resell, or relicense the software without written
   permission from the publisher.
3. Use commercial features only with a valid, non-expired license.
4. Accept that the software is provided AS IS, without warranty of any
   kind, express or implied. In no event shall the authors be liable for
   any claim, damages, or other liability arising from use of the software.

Type "yes" to accept these terms, or anything else to decline.
"""


def _eula_hash() -> str:
    return hashlib.sha256(EULA_TEXT.encode("utf-8")).hexdigest()


EULA_HASH: str = _eula_hash()


@dataclass(frozen=True, slots=True)
class EulaState:
    """Persistent record of when the EULA was accepted and which version."""

    accepted_at: datetime
    accepted_hash: str

    def is_current(self) -> bool:
        return self.accepted_hash == EULA_HASH


class EulaStore:
    """Reads/writes the EULA acceptance state to a JSON file.

    Sits next to the activation cache and the trial-clock state. No HMAC
    is needed here — falsifying acceptance just dodges a one-time prompt,
    which is not a meaningful threat (legal enforceability lives in the
    license agreement, not in tamper-resistant acceptance records).
    """

    def __init__(
        self,
        path: Path | None = None,
        *,
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        self.path = path or _default_eula_path()
        self._clock = clock or _utcnow

    def load(self) -> EulaState | None:
        if not self.path.exists():
            return None
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8-sig"))
        except (OSError, ValueError):
            return None
        if not isinstance(payload, dict):
            return None
        accepted_at_raw = payload.get("accepted_at")
        accepted_hash = payload.get("accepted_hash")
        if not isinstance(accepted_at_raw, str) or not isinstance(accepted_hash, str):
            return None
        try:
            accepted_at = datetime.fromisoformat(accepted_at_raw)
        except ValueError:
            return None
        if accepted_at.tzinfo is None:
            accepted_at = accepted_at.replace(tzinfo=UTC)
        return EulaState(accepted_at=accepted_at, accepted_hash=accepted_hash)

    def record_acceptance(self) -> EulaState:
        accepted_at = self._clock()
        if accepted_at.tzinfo is None:
            accepted_at = accepted_at.replace(tzinfo=UTC)
        state = EulaState(accepted_at=accepted_at, accepted_hash=EULA_HASH)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(
            json.dumps(
                {
                    "accepted_at": state.accepted_at.isoformat(),
                    "accepted_hash": state.accepted_hash,
                },
                indent=2,
                sort_keys=True,
            ),
            encoding="utf-8",
        )
        return state

    def clear(self) -> None:
        if self.path.exists():
            self.path.unlink()


def _utcnow() -> datetime:
    return datetime.now(UTC)


def _default_eula_path() -> Path:
    import os

    raw = os.getenv("MEMSCOPE_EULA_STATE_PATH")
    if raw:
        return Path(raw).expanduser().resolve()
    return (Path.home() / ".memscope" / "eula_state.json").resolve()
