"""Developer-mode bridge dispatcher.

Re-exports `DeveloperModeLicenseBridge` from whichever sibling module
ships in the current build:

- Developer wheels include `_dev_mode_real.py` → real bypass.
- Production wheels include `_dev_mode_stub.py` only → no bypass.

The hatchling build hook (`hatch_build.py`) decides which file gets
bundled based on `MEMSCOPE_BUILD_PROFILE`. See
`docs/internal/release/distribution-plan.md` Phase B for the full design.

Why a dispatcher and not a direct import?

The production wheel must not contain any code path that grants the
developer-mode override, even one guarded behind a flag. Splitting the
real and stub implementations into separate physical files lets the
build hook *exclude the real one entirely* from production wheels.
The dispatcher tolerates that absence transparently.
"""

from __future__ import annotations

try:
    from memscope.licensing._dev_mode_real import DeveloperModeLicenseBridge
except ImportError:
    # The real and stub bridges expose the same name + interface; the
    # rebinding is intentional. mypy can't model "either-or" imports
    # without a Protocol, which would buy us nothing at runtime.
    from memscope.licensing._dev_mode_stub import (  # type: ignore[assignment]
        DeveloperModeLicenseBridge,
    )

__all__ = ["DeveloperModeLicenseBridge"]
