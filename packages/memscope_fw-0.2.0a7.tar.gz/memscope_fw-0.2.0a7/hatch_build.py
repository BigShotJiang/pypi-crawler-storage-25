"""Hatchling build hook — production wheel hardening.

Runs two phases at wheel-build time:

1. **Build-profile selection (Phase B).** Reads ``MEMSCOPE_BUILD_PROFILE``
   (``production`` | ``developer``, default ``production``). For production
   builds, physically moves ``_dev_mode_real.py`` out of the source tree
   into a system-temp stash so the bypass code never reaches the wheel.
   The dispatcher in ``dev_mode.py`` falls back to ``_dev_mode_stub`` at
   runtime, which has no override branch to flip.

2. **Cython compilation of the licensing gates (Phase C).** For production
   builds, runs ``Cython.Build.cythonize()`` on the listed licensing
   modules to produce ``.c`` files, then ``setuptools.build_ext`` to
   compile them into platform-specific extensions (``.pyd`` on Windows,
   ``.so`` elsewhere). Adds the compiled extensions to the wheel via
   ``build_data["force_include"]`` and stashes the corresponding ``.py``
   sources so they don't ship alongside the binary. The wheel ends up
   with ``service.cp311-cp311-win_amd64.pyd`` instead of ``service.py``,
   raising the bypass cost from ``sed -i 's/False/True/'`` to a Ghidra
   session.

   **What this gives you (and doesn't).** Cython is a Python-to-C
   compiler, not a binary obfuscator. Even with the hardening directives
   applied here (``binding=False``, ``embedsignature=False``,
   ``-fvisibility=hidden``, post-compile ``strip``), a reverse engineer
   with Ghidra / IDA / Binary Ninja experience can reconstruct readable
   pseudocode of the gates in roughly **a working day**. The honest
   threat-model doc is at
   ``docs/internal/handbook/license-gate-threat-model.md`` —
   the production-wheel Cython layer is *thin disguise that hides the
   gates from casual editors*, not anti-piracy. The actual defence
   layers are server-side Keygen license validation (forging signed
   responses requires the Ed25519 private key, which never ships) and
   the proprietary EULA's restrictions clause (clause 5) read together
   with the Romanian governing-law clause (clause 11), which give
   contractual + legal recourse against corporate-scale evasion.

Skip Cython for a build with ``MEMSCOPE_SKIP_CYTHON=1`` (devs without a
C compiler, fast iteration). The wheel will then ship plain ``.py``
files for the licensing modules and lose the Phase-C disguise layer
(Phase B still applies).

Wired in ``pyproject.toml`` via:

    [tool.hatch.build.targets.wheel.hooks.custom]
    path = "hatch_build.py"

Crash safety: stash files live in the system temp dir under a unique
``memscope-build-stash`` directory, **not** inside the source tree. If a
build crashes mid-way the source tree merely has the listed files
missing — re-running any build self-heals from the stash. The stash
directory is also recovered at the start of every build.

Editable installs (``pip install -e .``) bypass this hook entirely
because hatchling's PEP 660 editable target does not run wheel-target
hooks. Tests and dev workflows continue to run against ``.py`` source.
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

from hatchling.builders.hooks.plugin.interface import BuildHookInterface

_PROFILE_ENV = "MEMSCOPE_BUILD_PROFILE"
_VALID_PROFILES = frozenset({"production-public", "production-customer", "developer"})
_DEFAULT_PROFILE = "production-public"

# Opt-in: enable Cython compilation. Off by default in v0.2.0+ — the
# free core is pure-Python and doesn't need it. Customer-Bound Wheels
# (production-customer profile) implicitly enable this. Setting
# explicitly is supported for testing the Cython output without going
# through the customer-wheel build script.
_COMPILE_LICENSING_ENV = "MEMSCOPE_COMPILE_LICENSING"

# Customer-Bound Wheel manifest path. When set together with
# `production-customer` profile, the build pipeline stashes all
# bundle directories not listed in the manifest, regenerates
# `bundles/__init__.py` and `bundles/_customer_binding.py` from the
# manifest, and Cython-compiles the surviving Bundle code +
# customer-binding constants + (for Subscription Bundles) the
# licensing modules.
_CUSTOMER_MANIFEST_ENV = "MEMSCOPE_CUSTOMER_MANIFEST"

# Files unconditionally removed from the build tree during a production
# build (Phase B). Each entry is a path relative to the repository root.
_PRODUCTION_EXCLUDED_FILES: tuple[str, ...] = (
    "src/memscope/licensing/_dev_mode_real.py",
)

# Free-core IP modules — Cython-compiled in BOTH production profiles.
# These are the analyse / parse / diff / rule-evaluate algorithms that
# represent MemScope's actual engineering value. The free wheel ships
# them as compiled .pyd/.so so a `pip install memscope-fw` user gets a
# binary they can run but not trivially `cat` from `site-packages/`.
# Customer-Bound Wheels inherit this list (the IP doesn't change between
# distribution channels).
#
# Modules deliberately NOT in this list:
#   - `__init__.py` files (re-export shims; Cython on package init is
#     risky and adds no disguise);
#   - `domain/*.py`, `parsers/models.py`, `diff/model.py`, `config/schema.py`
#     (pure data interface — dataclasses + StrEnums; low IP value, and
#     dataclass metaprogramming is brittle under Cython);
#   - `parsers/base.py`, `rules/base.py`, `toolchains/base.py`,
#     `bundles/_contract.py`, `licensing/provider.py` (Protocol + ABC
#     interfaces; runtime_checkable Protocols misbehave when compiled);
#   - `app/cli.py`, `app/commands/*` (Typer relies on signature
#     introspection which Cython's `binding=False` directive removes);
#   - `outputs/html_renderer.py` (9000+ lines, template-heavy; the
#     rendered HTML / shipped JS+CSS assets are unobfuscated regardless,
#     so the marginal disguise is low — deferred for a follow-up);
#   - `outputs/frontend_runtime.py` (uses `__file__` as the JS asset
#     anchor; works fine under Cython but tests are happier with .py);
#   - `bundles/*` (must remain plain Python so `load_enabled_bundles`
#     can `importlib.import_module` per Customer-Bound build);
#   - `licensing/*` (handled by `_LICENSING_COMPILE_TARGETS` below — only
#     compiled for production-customer because the free wheel doesn't
#     exercise license validation).
_FREE_CORE_COMPILE_TARGETS: tuple[str, ...] = (
    # 50 algorithmic IP modules — Cython-compiled in BOTH production
    # profiles (production-public for the free PyPI wheel, production-
    # customer for Customer-Bound Wheels). The same source code ships
    # in both wheels, so the compile coverage is identical.
    #
    # Vetted end-to-end against `memscope analyze` on the GNU sample
    # fixture. The directive set in `_compile_listed_modules` keeps
    # boundscheck / wraparound / nonecheck / cdivision at their safe
    # defaults — those affect runtime correctness on real Python code
    # (e.g. `merged[-1]` corrupts under `wraparound=False`) and add
    # essentially no disguise on pure-Python modules. The disguise
    # comes from `binding=False`, `embedsignature=False`, the
    # `Options.docstrings=False` pre-cythonize hook, and the post-link
    # `-fvisibility=hidden` / `--strip-all` flags — all preserved.
    # Group 1 — analysis/ (algorithmic core).
    "src/memscope/analysis/component_grouping.py",
    "src/memscope/analysis/multicore.py",
    "src/memscope/analysis/padding_waste.py",
    "src/memscope/analysis/policy_engine.py",
    "src/memscope/analysis/region_usage.py",
    "src/memscope/analysis/reserved_region_checks.py",
    "src/memscope/analysis/section_usage.py",
    "src/memscope/analysis/summary.py",
    "src/memscope/analysis/symbol_breakdown.py",
    "src/memscope/analysis/visualization_contracts.py",
    # Group 2 — diff/ comparators + engine.
    "src/memscope/diff/compare_components.py",
    "src/memscope/diff/compare_regions.py",
    "src/memscope/diff/compare_sections.py",
    "src/memscope/diff/compare_symbols.py",
    "src/memscope/diff/engine.py",
    "src/memscope/diff/render_helpers.py",
    # Group 3 — rules + evaluators.
    "src/memscope/rules/evaluators/budget.py",
    "src/memscope/rules/evaluators/component_placement.py",
    "src/memscope/rules/evaluators/memory_policy.py",
    "src/memscope/rules/evaluators/partition_fit.py",
    "src/memscope/rules/evaluators/placement.py",
    "src/memscope/rules/evaluators/regression.py",
    "src/memscope/rules/evaluators/stack_heap.py",
    "src/memscope/rules/evaluators/symbol_size.py",
    "src/memscope/rules/registry.py",
    "src/memscope/rules/suppressions.py",
    # Group 4 — toolchain inference.
    "src/memscope/toolchains/clang_lld.py",
    "src/memscope/toolchains/core_inference.py",
    "src/memscope/toolchains/factory.py",
    "src/memscope/toolchains/gnu.py",
    "src/memscope/toolchains/iar.py",
    "src/memscope/toolchains/keil.py",
    # Group 5 — output renderers (HTML deferred for size, frontend
    # stays plain because of __file__ asset anchoring).
    "src/memscope/outputs/console_renderer.py",
    "src/memscope/outputs/csv_renderer.py",
    "src/memscope/outputs/diagnostics_bundle.py",
    "src/memscope/outputs/json_renderer.py",
    "src/memscope/outputs/pathing.py",
    # Group 6 — security / config / monitoring.
    "src/memscope/security/path_policy.py",
    "src/memscope/config/defaults.py",
    "src/memscope/config/loader.py",
    "src/memscope/config/validator.py",
    "src/memscope/monitoring/telemetry.py",
    # Group 7 — parsers (DWARF, ELF, GNU/IAR/Keil map + linker scripts).
    "src/memscope/parsers/dwarf_parser.py",
    "src/memscope/parsers/elf_parser.py",
    "src/memscope/parsers/factory.py",
    "src/memscope/parsers/linker/gnu_ld_parser.py",
    "src/memscope/parsers/linker/iar_icf_parser.py",
    "src/memscope/parsers/linker/keil_scatter_parser.py",
    "src/memscope/parsers/map/gnu_map_parser.py",
    "src/memscope/parsers/map/iar_map_parser.py",
    "src/memscope/parsers/map/keil_map_parser.py",
    # Group 8 — app/session.py orchestration. cli.py + commands/* +
    # logging_utils.py stay plain (Typer signature inspection +
    # Logger.trace descriptor-protocol issue).
    "src/memscope/app/session.py",
    # NOTE: `app/*` modules are intentionally NOT compiled. Reasons:
    #   - cli.py / commands/* — Typer reads `inspect.signature()` of
    #     command functions; our `binding=False` directive removes the
    #     Python-level signature wrapper.
    #   - logging_utils.py — monkey-patches `logging.Logger.trace`, and
    #     Cython-compiled functions don't bind `self` correctly when
    #     assigned as instance methods (descriptor protocol bypassed
    #     by `binding=False`).
    #   - session.py — orchestration that touches Typer context, the
    #     monkey-patched logger, and many compiled IP modules; the
    #     interaction surface is wide enough to produce hard-to-debug
    #     C-level crashes. The IP value of session.py itself is low
    #     (state-machine wiring), so the trade-off favours keeping it
    #     plain so the compiled-module boundaries stay clean.
)

# Subscription-Bundle gates — Cython-compiled ONLY for production-customer.
# Dead code in the free wheel; no point paying the compile cost there.
_LICENSING_COMPILE_TARGETS: tuple[str, ...] = (
    "src/memscope/licensing/service.py",
    "src/memscope/licensing/cache.py",
    "src/memscope/licensing/_keygen_pubkey.py",
    "src/memscope/licensing/keygen_provider.py",
    "src/memscope/_build_profile.py",
)

# Backwards-compat alias — historical name used by the customer-wheel
# build script. New code should reference _LICENSING_COMPILE_TARGETS.
_CYTHON_COMPILE_TARGETS = _LICENSING_COMPILE_TARGETS

# Customer-binding constants — Cython-compiled ONLY for production-customer.
# `_customer_binding.py` carries the licensed organisation's identity and
# must not ship as plain `.py` — `strings <wheel>.pyd | grep <CustomerName>`
# would trivially identify the licensee otherwise.
_CUSTOMER_BOUND_COMPILE_TARGETS: tuple[str, ...] = (
    "src/memscope/bundles/_customer_binding.py",
)

# Stash directory must be **outside** the source tree so hatchling's
# file collector does not pick stashed copies up and ship them in the
# wheel under a `.profile-stash` filename.
_STASH_DIR_NAME = "memscope-build-stash"


class CustomBuildHook(BuildHookInterface):  # type: ignore[type-arg]
    """Production-wheel hardening: dev-mode exclusion + Cython-compiled gates."""

    PLUGIN_NAME = "custom"

    def initialize(self, version: str, build_data: dict[str, Any]) -> None:
        # Self-heal from any crashed previous build before doing anything else.
        self._restore_orphan_stashes()

        # Backwards-compat: accept the legacy "production" profile name
        # and remap to "production-public" (the v0.2.0 default).
        profile = os.environ.get(_PROFILE_ENV, _DEFAULT_PROFILE).strip().lower()
        if profile == "production":
            profile = "production-public"
        if profile not in _VALID_PROFILES:
            raise ValueError(
                f"{_PROFILE_ENV} must be one of {sorted(_VALID_PROFILES)}; "
                f"got {profile!r}."
            )

        self._stashed: list[tuple[Path, Path]] = []
        self._cython_artifacts: list[Path] = []

        if profile == "developer":
            return

        stash_dir = self._stash_dir()
        stash_dir.mkdir(parents=True, exist_ok=True)

        # Phase B: stash _dev_mode_real.py for both production profiles.
        for relative in _PRODUCTION_EXCLUDED_FILES:
            target = Path(self.root) / relative
            if not target.exists():
                continue
            stashed = stash_dir / self._stash_name(relative)
            shutil.move(str(target), str(stashed))
            self._stashed.append((target, stashed))

        # Both production profiles compile the free-core IP modules
        # (analyse, parse, diff, rule-evaluate). The free-core wheel
        # ships them as .pyd/.so so the published binary isn't trivially
        # readable from `site-packages/`. Customer-Bound Wheels inherit
        # the same core compile list and add licensing + customer-binding
        # on top.
        #
        # production-customer additionally compiles:
        #   - licensing/* (gates Subscription Bundles call into); and
        #   - bundles/_customer_binding.py (hides the licensee name).
        #
        # The MEMSCOPE_COMPILE_LICENSING env var lets a developer
        # exercise the licensing-module compile path on a public build
        # (rare — used to debug Cython directives without going through
        # the customer-wheel script).
        compile_licensing = (
            profile == "production-customer"
            or os.environ.get(_COMPILE_LICENSING_ENV, "").strip().lower() in {"1", "true", "yes"}
        )
        targets: tuple[str, ...] = _FREE_CORE_COMPILE_TARGETS
        if compile_licensing:
            targets = targets + _LICENSING_COMPILE_TARGETS
        if profile == "production-customer":
            targets = targets + _CUSTOMER_BOUND_COMPILE_TARGETS

        compiled_paths = self._compile_listed_modules(targets)
        # Reuse the resolved target tuple for the source-stash step
        # below so it matches what was actually compiled.
        extra_targets = targets

        # Add each compiled extension to the wheel under its package path.
        for compiled_path in compiled_paths:
            self._cython_artifacts.append(compiled_path)
            wheel_dest = self._wheel_dest_for_compiled(compiled_path)
            build_data["force_include"][str(compiled_path)] = wheel_dest

        # Stash the .py source for each compiled module so the wheel
        # only contains the .pyd/.so version.
        for relative in extra_targets:
            target = Path(self.root) / relative
            if not target.exists():
                continue
            stashed = stash_dir / self._stash_name(relative)
            shutil.move(str(target), str(stashed))
            self._stashed.append((target, stashed))

        # Tell hatchling this is no longer a pure-Python wheel — it has
        # platform-specific binaries, so the wheel filename gets a real
        # platform tag (e.g. cp311-cp311-win_amd64) instead of
        # py3-none-any.
        build_data["infer_tag"] = True
        build_data["pure_python"] = False

    def finalize(
        self, version: str, build_data: dict[str, Any], artifact_path: str
    ) -> None:
        # Restore stashed source files (.py originals).
        for target, stashed in self._stashed:
            if stashed.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(stashed), str(target))
        self._stashed = []

        # Clean up Cython intermediates (.c files) and the compiled
        # extensions (.pyd/.so) we left next to the .py sources during
        # the build. The wheel already contains them; they're not
        # needed in the working tree.
        for compiled in self._cython_artifacts:
            if compiled.exists():
                compiled.unlink()
            c_intermediate = compiled.with_suffix("").with_suffix(".c")
            if c_intermediate.exists():
                c_intermediate.unlink()
        self._cython_artifacts = []

        # Best-effort cleanup of the stash dir (only if empty).
        stash_dir = self._stash_dir()
        if stash_dir.exists():
            try:
                stash_dir.rmdir()
            except OSError:
                pass

    # ---- Cython helpers ---------------------------------------------------

    def _compile_licensing_modules(self) -> list[Path]:
        """Backwards-compat wrapper kept for existing callers."""
        return self._compile_listed_modules(_CYTHON_COMPILE_TARGETS)

    def _compile_listed_modules(self, targets: tuple[str, ...]) -> list[Path]:
        """Run cythonize + build_ext on the given target list.

        Returns the list of produced extension files (``.pyd`` / ``.so``)
        as absolute paths in the source tree. Raises on any compilation
        failure — silent failure here would mean shipping an unprotected
        wheel that *appears* to be production-tagged.
        """
        try:
            from Cython.Build import cythonize
            from Cython.Compiler import Options as CythonOptions
            from setuptools import Extension
            from setuptools.command.build_ext import build_ext
            from setuptools.dist import Distribution
        except ImportError as exc:
            raise RuntimeError(
                f"Cython compilation requires `cython` and `setuptools` "
                f"in the build environment but neither is importable ({exc}). "
                f"Either install them, or build the free-core wheel which "
                f"does not require Cython."
            ) from exc

        # Strip every docstring from the compiled binary.
        # `Cython.Compiler.Options.docstrings` is a module-level setting
        # (NOT a per-call directive), so we flip it before cythonize()
        # and restore it after to avoid leaking the override into any
        # other Cython compilation in the same process. We grep'd
        # licensing modules + tests and confirmed nothing reads __doc__
        # — re-check before adding any introspection-based test.
        _previous_docstrings_setting = CythonOptions.docstrings
        CythonOptions.docstrings = False

        # Resolve targets to absolute Path objects + module names.
        # ext_definitions: (absolute_py_path, module_name)
        ext_definitions: list[tuple[Path, str]] = []
        src_root = Path(self.root) / "src"
        for relative in targets:
            py_path = Path(self.root) / relative
            if not py_path.exists():
                self.app.display_warning(
                    f"Cython target missing on disk: {relative} — skipping."
                )
                continue
            module_rel = py_path.relative_to(src_root).with_suffix("")
            module_name = ".".join(module_rel.parts)
            ext_definitions.append((py_path, module_name))

        if not ext_definitions:
            return []

        # Step 1: cythonize the .py files in place. Produces a .c next
        # to each .py.
        #
        # Hardening directives — chosen for production wheels, NOT for
        # editable / test runs (those bypass Cython entirely). Together
        # they raise the cost of `strings` / `nm` / `objdump` reading
        # the binary, but they do NOT defeat a Ghidra session — see
        # `docs/internal/handbook/license-gate-threat-model.md`.
        #
        # - binding=False: do NOT generate Python-level wrappers that
        #   carry signature + docstring metadata at runtime. Removes the
        #   "free decompilation" that comes from `inspect.signature()`.
        # - embedsignature=False: do not embed the source signature in
        #   the function's __doc__ (Cython's default does, which is
        #   helpful in REPLs and terrible for protection).
        # - c_string_encoding="ascii": no UTF-16/UCS-4 helper tables
        #   embedded for default str interop.
        # - boundscheck/wraparound/initializedcheck/nonecheck=False:
        #   strip Cython's runtime safety checks. Each one removes a
        #   distinctive pattern in the generated C that a reverse-
        #   engineering script can grep for.
        # - cdivision=True: drop the Python-style negative-modulo
        #   normalisation, which generates a recognisable branch.
        # - profile/linetrace=False: no profiler/coverage hooks (these
        #   would embed source line numbers in the binary).
        # - optimize.use_switch=True: emit C `switch` for if/elif chains
        #   on integers — collapses constant tables into one switch.
        py_paths = [str(p) for p, _ in ext_definitions]
        try:
            cythonize(
                py_paths,
                language_level=3,
                compiler_directives={
                    "binding": False,
                    "embedsignature": False,
                    "language_level": 3,
                    # IMPORTANT: keep boundscheck + wraparound ON. They
                    # only affect typed `cdef` arrays (which we don't use)
                    # but on a few Cython versions wraparound=False has
                    # been observed to corrupt Python-list negative
                    # indexing (`some_list[-1]` returns garbage instead
                    # of the last element). The disguise gain from
                    # turning them off is essentially zero for pure-
                    # Python compiled modules; the runtime correctness
                    # cost is real.
                    "boundscheck": True,
                    "wraparound": True,
                    "initializedcheck": True,
                    "nonecheck": True,
                    # cdivision affects integer `/` and `%` semantics —
                    # OK for licensing modules where every integer op was
                    # audited, NOT OK for free-core modules where any
                    # negative-modulo path silently changes behaviour.
                    "cdivision": False,
                    "profile": False,
                    "linetrace": False,
                    "c_string_encoding": "ascii",
                    "optimize.use_switch": True,
                    "optimize.unpack_method_calls": True,
                    # CRITICAL: do NOT treat PEP 484 type hints as cdef
                    # declarations. Without this flag, `: dict[...]` on a
                    # local variable becomes a strict C-level type check
                    # that rejects subclasses (e.g. `collections.defaultdict`
                    # vs `dict`), and `: str` on function args raises on
                    # None values that plain Python tolerates. Our type
                    # hints are written for mypy, not Cython.
                    "annotation_typing": False,
                },
                quiet=True,
            )
        finally:
            CythonOptions.docstrings = _previous_docstrings_setting

        # Step 2: setuptools.build_ext compiles each .c into .pyd / .so.
        # We pass `package_dir = {"": "src"}` so the dotted module name
        # `memscope.licensing.service` resolves to `src/memscope/licensing/`
        # — without this, inplace mode tries to write the .pyd at the
        # repo root and fails because `memscope/` doesn't exist there.
        #
        # Compiler/linker hardening flags applied per-platform:
        # - Unix (gcc / clang): `-fvisibility=hidden` so non-PyInit
        #   symbols don't end up in the dynamic symbol table; `-O2`
        #   for size + speed (no `-g`, no `-Og`); `-Wl,--strip-all`
        #   on the link to drop debug + local symbol tables that
        #   `nm` would otherwise read. macOS uses `-Wl,-x` instead
        #   (BSD `ld` doesn't grok `--strip-all`).
        # - Windows (MSVC): no `/DEBUG`, no `/Zi`. `/Os` favours small
        #   code; `/GL` enables whole-program optimisation; the linker
        #   already omits a separate .pdb when `/DEBUG` isn't set,
        #   which is what we want for production wheels.
        extra_compile_args, extra_link_args = self._hardened_build_flags()
        extensions = [
            Extension(
                name=mod,
                sources=[str(py_path.with_suffix(".c"))],
                extra_compile_args=extra_compile_args,
                extra_link_args=extra_link_args,
            )
            for py_path, mod in ext_definitions
        ]
        dist = Distribution(
            {
                "name": "memscope",
                "ext_modules": extensions,
                "package_dir": {"": "src"},
            }
        )
        dist.script_name = "setup.py"
        cmd = build_ext(dist)
        cmd.inplace = 1
        cmd.ensure_finalized()
        # build_ext invokes the C compiler from the directory it was
        # initialized in. Force CWD to the repo root so the relative
        # paths in the Extension sources resolve.
        prev_cwd = Path.cwd()
        try:
            os.chdir(self.root)
            cmd.run()
        finally:
            os.chdir(prev_cwd)

        # Step 3: collect the produced extension files. setuptools
        # writes each Extension to the directory of its first source
        # file (because we set inplace=1).
        compiled_paths: list[Path] = []
        for py_path, _mod in ext_definitions:
            ext_dir = py_path.parent
            stem = py_path.stem
            # The exact filename depends on Python version + ABI tag +
            # platform. Glob for both .pyd (Windows) and .so (others).
            matches = list(ext_dir.glob(f"{stem}.*.pyd")) + list(
                ext_dir.glob(f"{stem}.*.so")
            )
            if not matches:
                raise RuntimeError(
                    f"Cython compilation of {py_path} produced no .pyd/.so "
                    f"output in {ext_dir}. The wheel would silently ship "
                    f"unprotected source. Aborting build."
                )
            # Pick the most recent match in case of stale leftovers.
            matches.sort(key=lambda p: p.stat().st_mtime, reverse=True)
            compiled_paths.append(matches[0])

        # Step 4: delete the .c intermediates BEFORE hatchling collects
        # files. Otherwise the wheel ends up with both the compiled
        # binary and the C source, which (a) bloats the wheel and
        # (b) leaks partial Cython output that competitors don't need.
        # The actual binaries (.pyd/.so) stay until finalize().
        for py_path, _mod in ext_definitions:
            c_intermediate = py_path.with_suffix(".c")
            if c_intermediate.exists():
                c_intermediate.unlink()

        # Step 5: belt-and-suspenders post-link strip on platforms
        # where it does anything useful. The linker `--strip-all`
        # flag passed via `extra_link_args` already removes most
        # debug + local symbols; running `strip` again catches any
        # toolchain (older binutils, Apple ld) that ignored or
        # silently dropped the linker flag. No-op on Windows.
        for compiled_path in compiled_paths:
            self._strip_compiled_extension(compiled_path)

        return compiled_paths

    def _hardened_build_flags(self) -> tuple[list[str], list[str]]:
        """Return (extra_compile_args, extra_link_args) for the production wheel.

        These raise the cost of `nm` / `objdump` / `strings` on the
        compiled extension by hiding non-PyInit symbols and stripping
        debug + local-symbol tables. They do NOT defeat a Ghidra session
        — see the threat-model doc.

        Detection is conservative: anything we don't recognise (e.g. a
        custom toolchain on a niche platform) gets the empty flag list,
        which means the wheel still builds, just without the extra
        hardening on that platform. Builds shipping that wheel must
        still run through `_strip_compiled_extension` for the post-link
        belt-and-suspenders pass.
        """
        if sys.platform == "win32":
            # MSVC. /Os = favour size; /GL = whole-program optimisation;
            # /Oy = omit frame pointer (no-op on x64 — MSVC always
            # omits frame pointers there — kept for x86 wheel builds).
            # No /Zi, no /DEBUG — production wheels ship without a PDB.
            # We deliberately do NOT add /OPT:REF /OPT:ICF here because
            # build_ext on MSVC already sets /OPT:REF for release builds
            # and adding ICF can produce surprising symbol coalescing
            # that breaks ABI assumptions on some Cython output.
            #
            # /LTCG must pair with the compiler's /GL — without it the
            # linker silently emits .obj as ordinary object files and
            # the whole-program optimisation pass is wasted (but the
            # build still succeeds, which is why this was missed
            # initially). Pairing them is required by MSVC docs.
            return (
                ["/Os", "/GL", "/Oy"],
                ["/LTCG"],
            )
        if sys.platform == "darwin":
            # Apple clang. -fvisibility=hidden hides non-PyInit symbols
            # from the dynamic symbol table. -Wl,-x strips local
            # symbols at link time (BSD ld doesn't accept --strip-all).
            return (
                ["-fvisibility=hidden", "-Os", "-fno-ident"],
                ["-Wl,-x", "-Wl,-dead_strip"],
            )
        if sys.platform.startswith("linux"):
            # GCC / clang on glibc / musl. -fvisibility=hidden + linker
            # --strip-all is the canonical Linux equivalent of MSVC's
            # default release behaviour. -fno-asynchronous-unwind-tables
            # drops the .eh_frame section that Ghidra uses to recover
            # function boundaries cheaply.
            return (
                [
                    "-fvisibility=hidden",
                    "-Os",
                    "-fno-ident",
                    "-fno-asynchronous-unwind-tables",
                ],
                ["-Wl,--strip-all", "-Wl,--gc-sections"],
            )
        # Unknown platform — do nothing. The post-link strip step still
        # runs and will pick up whatever the platform's `strip` knows.
        return ([], [])

    def _strip_compiled_extension(self, compiled_path: Path) -> None:
        """Run `strip` on the compiled extension if the host has it.

        Belt-and-suspenders to the linker `--strip-all` already passed
        via ``extra_link_args``: catches toolchains that ignored or
        silently dropped the linker flag. No-op on Windows (MSVC's
        production wheels ship without a separate .pdb already, and
        running `strip.exe` from MSYS2 on a `.pyd` corrupts it).

        Failures are logged and tolerated — a missing `strip` binary
        on a build host is not a reason to fail the whole wheel
        build, but it IS a reason to print a warning so the operator
        knows the protection is weaker than intended.
        """
        if sys.platform == "win32":
            return
        strip_bin = shutil.which("strip")
        if strip_bin is None:
            self.app.display_warning(
                f"`strip` not found on PATH; skipping post-link symbol "
                f"strip on {compiled_path.name}. The linker --strip-all "
                f"flag should still apply, but binutils on this host "
                f"may have ignored it. Install binutils to silence."
            )
            return
        # macOS strip wants -x (strip local symbols only); GNU strip
        # wants --strip-unneeded (keep dynamic, drop everything else).
        if sys.platform == "darwin":
            args = [strip_bin, "-x", str(compiled_path)]
        else:
            args = [strip_bin, "--strip-unneeded", str(compiled_path)]
        try:
            subprocess.run(args, check=True, capture_output=True, text=True)
        except subprocess.CalledProcessError as exc:
            self.app.display_warning(
                f"`strip` failed on {compiled_path.name} "
                f"(exit {exc.returncode}): {exc.stderr.strip()}. "
                f"Wheel will still ship but with more symbols visible "
                f"to `nm` than intended."
            )

    def _wheel_dest_for_compiled(self, compiled_path: Path) -> str:
        """Map an absolute .pyd/.so source path to its wheel destination.

        E.g. ``<root>/src/memscope/licensing/service.cp311-...-win_amd64.pyd``
        → ``memscope/licensing/service.cp311-...-win_amd64.pyd``.
        Hatchling treats force_include destinations as wheel-relative
        POSIX paths — backslashes break the pack step on Windows
        (this is the bug we worked around hatch-cython hitting).
        """
        rel_to_src = compiled_path.relative_to(Path(self.root) / "src")
        return rel_to_src.as_posix()

    # ---- Stash helpers (shared between Phase B + Phase C) ----------------

    def _stash_dir(self) -> Path:
        """Per-source-tree stash directory in the system temp location.

        Keyed on the absolute repo root so concurrent builds of different
        checkouts don't collide.
        """
        repo_id = str(Path(self.root).resolve()).replace(os.sep, "_").replace(":", "")
        return Path(tempfile.gettempdir()) / _STASH_DIR_NAME / repo_id

    def _stash_name(self, relative: str) -> str:
        """Convert a project-relative path to a flat stash filename."""
        return relative.replace("/", "__").replace("\\", "__")

    def _restore_orphan_stashes(self) -> None:
        """Restore stashed files left over from a crashed previous build.

        Without this, a Ctrl+C between ``initialize`` and ``finalize`` would
        leave the source tree without the listed files until the user
        recovered them manually. Recovering at the start of every build
        makes the situation self-healing.
        """
        stash_dir = self._stash_dir()
        if not stash_dir.exists():
            return
        all_relatives = (*_PRODUCTION_EXCLUDED_FILES, *_CYTHON_COMPILE_TARGETS)
        for relative in all_relatives:
            target = Path(self.root) / relative
            stashed = stash_dir / self._stash_name(relative)
            if stashed.exists() and not target.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(stashed), str(target))
        try:
            stash_dir.rmdir()
        except OSError:
            pass
