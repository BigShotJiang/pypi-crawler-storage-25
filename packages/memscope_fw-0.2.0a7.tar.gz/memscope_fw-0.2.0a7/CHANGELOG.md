# Changelog

All notable changes to `memscope-fw` will be documented in this file.

This project follows [Semantic Versioning](https://semver.org/) for the
public Python API and CLI surface; the version itself is sourced from
hatch-vcs / git tags.

## [0.2.0] - 2026-05-01

### **BREAKING CHANGE: licensing model overhaul**

The trial / paid-mode framework that gated `--strict`, custom
`[budgets]` / `[policies]`, CSV export, and `validate` has been
**retired**. The free core on PyPI is now genuinely free for any use,
including commercial use by companies of any size, with no license
key, no watermark, no trial countdown, and no devolution mechanic.

Optional commercial features will ship in a forthcoming Bundle catalog
delivered as Customer-Bound Wheels separately from PyPI; the
LICENSE (Interim v2) describes three Bundle license modes
(Subscription / One-Time / Bespoke). Bundle licences are not yet
generally available for sale.

#### Removed

- `--strict` CI-gating exit codes are now **free** in the core (no
  license check).
- Custom `[budgets]` / `[policies]` / `[suppressions]` config sections
  are now **free** in the core (no silent override to defaults).
- CSV export is now **free** in the core (no skip-and-warn behaviour).
- `validate` is **free** (already free since the previous release;
  reaffirmed here).
- The 14-day trial clock is removed. New installs run the free core
  forever from day 1.
- The `--developer-mode` global flag is removed (nothing to bypass).
- The `memscope license activate` / `license status` / `license
  deactivate` / `license accept-terms` subcommands are removed. EULA
  acceptance is now a single top-level command: `memscope accept-terms`.
- HTML report watermarks (`TRIAL` / `FREE EDITION` / `LICENSE EXPIRED` /
  `LICENSE REVOKED` / `LICENSE INVALID` / `DEVELOPER MODE`) are removed.
- HTML report license-attestation footer (`<footer
  class="ms-license-footer">`) is removed.
- HTML report appbar license chip is removed.
- HTML head `<meta name="memscope-license-mode">` /
  `memscope-license-tier` tags are removed.
- HTML body `data-license-mode` / `data-license-tier` /
  `data-export-stamp` attributes are removed.
- `@media print` license-mode stamp is removed.
- CSV preamble `license_mode` / `license_tier` fields are removed.
- Console-summary `License: ...` line is removed.
- Console-summary renewal-reminder banner is removed.
- Diagnostics-export bundle's `license_status.json` entry is removed.
- Telemetry payload's `license_mode` / `license_tier` whitelisted
  fields are removed.

#### Changed

- LICENSE rewritten as **Interim v2**: drops the operating-modes
  framing (TRIAL / FREE EDITION / PAID), adds the Bundle clauses
  (clause 3), strengthens clause 5 (no redistribution including to
  affiliates, no Customer-Bound Wheel re-binding forgery, annual
  audit right). Governing law clause 11 + entire-agreement clause 12
  carry over from Interim v1.
- `memscope --version` now prints just the version string (build-
  profile labels `(production build)` / `(developer build)` are
  retired).
- `memscope-fw` core wheel ships as a per-platform Cython-compiled
  wheel (`cp31x-cp31x-<platform>`) for cp311-cp314 on Linux x86_64,
  Windows AMD64, and macOS arm64. The free-core IP modules
  (parsers, analyzers, diff engine, rule evaluators, toolchain
  inference, etc. — see `hatch_build.py` `_FREE_CORE_COMPILE_TARGETS`)
  ship as compiled `.pyd`/`.so` so a `pip install memscope-fw` user
  receives a binary they can run but not trivially `cat` from
  `site-packages/`. The licensing modules are NOT compiled in the
  free wheel (they're dead code there); they are compiled only in
  Customer-Bound Wheels where Subscription Bundles need them.

#### Added

- `memscope accept-terms` top-level command for non-interactive EULA
  acceptance.
- New documentation:
  - `docs/internal/sales/pricing-tiers.md` (sales playbook).
  - `docs/internal/handbook/bundle-architecture.md` (Bundle technical
    design).
  - `docs/internal/operations/keygen-cost-model.md` (when Keygen is
    justified).
  - `docs/internal/release/customer-wheel-rebuild-runbook.md`
    (operational runbook for customer-wheel releases).
- LICENSE Plain-English Summary preamble (NOT legally binding) so a
  procurement reviewer can decide in 30 seconds.

### Migration

- **Existing free-tier users:** no action required. `pip install
  --upgrade memscope-fw` and continue. All commands you were using
  remain available; watermarks vanish.
- **Existing trial users:** trial is no longer relevant. The features
  you had during trial (`--strict`, custom budgets/policies, CSV)
  remain available indefinitely after upgrade.
- **CI environments using `memscope license activate`:** the command
  no longer exists. Remove it from your CI scripts. The free core
  works without activation.
- **EULA re-acceptance prompt** may fire on first run after upgrade
  because the LICENSE hash changed (Interim v1 → Interim v2). On
  non-TTY contexts (CI), run `memscope accept-terms` once to record
  acceptance.

## Earlier versions

Earlier releases are summarised in the git history; this CHANGELOG
starts at v0.2.0 because that is the first release with the new
licensing model. Pre-v0.2.0 release notes can be reconstructed from
`git log v0.1.0a0..v0.1.0a17`.
