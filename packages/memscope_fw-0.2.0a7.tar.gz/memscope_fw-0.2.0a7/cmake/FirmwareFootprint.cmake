# MemScope CMake integration helpers.
#
# Usage:
#   include(cmake/FirmwareFootprint.cmake)
#
#   firmware_footprint_report(
#     TARGET app
#     ELF $<TARGET_FILE:app>
#     MAP ${CMAKE_BINARY_DIR}/app.map
#     LINKER ${CMAKE_SOURCE_DIR}/linker.ld
#     CONFIG ${CMAKE_SOURCE_DIR}/memscope.toml
#     HTML ${CMAKE_BINARY_DIR}/reports/app.html
#     JSON ${CMAKE_BINARY_DIR}/reports/app.json
#     CSV  ${CMAKE_BINARY_DIR}/reports/app.csv
#     STRICT
#   )
#
#   firmware_footprint_custom_target(
#     NAME app_footprint
#     MAP ${CMAKE_BINARY_DIR}/app.map
#     LINKER ${CMAKE_SOURCE_DIR}/linker.ld
#     JSON ${CMAKE_BINARY_DIR}/reports/app.json
#   )
#
#   firmware_footprint_diff_target(
#     NAME app_footprint_diff
#     CURRENT_JSON ${CMAKE_BINARY_DIR}/reports/app_current.json
#     BASELINE_JSON ${CMAKE_SOURCE_DIR}/ci/baseline/app.json
#     OUTPUT_JSON ${CMAKE_BINARY_DIR}/reports/app_diff.json
#     OUTPUT_HTML ${CMAKE_BINARY_DIR}/reports/app_diff.html
#   )

include_guard(GLOBAL)
include(CMakeParseArguments)

# Empty prefix retained as an extension point. Earlier versions set
# MEMSCOPE_INVOKED_FROM_BUILD=1 here to enforce paid-tier on every build
# invocation, but that broke the local-developer experience: every team
# member running ``cmake --build`` would have needed a paid seat just to
# compile. The current model gates the *enforcement* lever (``--strict``)
# instead, which leaves the visibility-only path (report generation)
# free for trial users and local developer builds.
set(_MEMSCOPE_BUILD_ENV_PREFIX "")


function(_memscope_resolve_executable out_var explicit_path)
  if(explicit_path)
    set(${out_var} "${explicit_path}" PARENT_SCOPE)
    return()
  endif()

  find_program(_memscope_from_path NAMES memscope)
  if(_memscope_from_path)
    set(${out_var} "${_memscope_from_path}" PARENT_SCOPE)
  else()
    # Fall back to plain command name so local virtualenv wrappers still work.
    set(${out_var} "memscope" PARENT_SCOPE)
  endif()
endfunction()

function(_memscope_append_arg list_name flag value)
  if(value)
    list(APPEND ${list_name} "${flag}" "${value}")
    set(${list_name} "${${list_name}}" PARENT_SCOPE)
  endif()
endfunction()

function(_memscope_build_analyze_command out_var)
  set(options STRICT)
  set(one_value_args
    ELF MAP LINKER CONFIG HTML JSON CSV BASELINE_JSON TOOLCHAIN TARGET_NAME LOG_LEVEL MEMSCOPE_EXECUTABLE
  )
  cmake_parse_arguments(FW "${options}" "${one_value_args}" "" ${ARGN})

  _memscope_resolve_executable(_memscope_bin "${FW_MEMSCOPE_EXECUTABLE}")
  set(_cmd "${_memscope_bin}")

  if(FW_LOG_LEVEL)
    list(APPEND _cmd "--log-level" "${FW_LOG_LEVEL}")
  endif()
  if(FW_STRICT)
    list(APPEND _cmd "--strict")
  endif()

  list(APPEND _cmd "analyze")

  _memscope_append_arg(_cmd "--elf" "${FW_ELF}")
  _memscope_append_arg(_cmd "--map" "${FW_MAP}")
  _memscope_append_arg(_cmd "--linker" "${FW_LINKER}")
  _memscope_append_arg(_cmd "--config" "${FW_CONFIG}")
  _memscope_append_arg(_cmd "--html" "${FW_HTML}")
  _memscope_append_arg(_cmd "--json" "${FW_JSON}")
  _memscope_append_arg(_cmd "--csv" "${FW_CSV}")
  _memscope_append_arg(_cmd "--baseline-json" "${FW_BASELINE_JSON}")
  _memscope_append_arg(_cmd "--toolchain" "${FW_TOOLCHAIN}")
  _memscope_append_arg(_cmd "--target-name" "${FW_TARGET_NAME}")

  set(${out_var} "${_cmd}" PARENT_SCOPE)
endfunction()

function(firmware_footprint_report)
  set(options STRICT)
  set(one_value_args
    TARGET
    ELF MAP LINKER CONFIG HTML JSON CSV BASELINE_JSON TOOLCHAIN TARGET_NAME LOG_LEVEL
    WORKING_DIRECTORY
    MEMSCOPE_EXECUTABLE
  )
  cmake_parse_arguments(FW "${options}" "${one_value_args}" "" ${ARGN})

  if(NOT FW_TARGET)
    message(FATAL_ERROR "firmware_footprint_report requires TARGET.")
  endif()
  if(NOT TARGET "${FW_TARGET}")
    message(FATAL_ERROR "firmware_footprint_report TARGET does not exist: ${FW_TARGET}")
  endif()
  if(NOT FW_ELF AND NOT FW_MAP AND NOT FW_LINKER)
    message(FATAL_ERROR "firmware_footprint_report requires at least one of ELF, MAP, or LINKER.")
  endif()

  if(FW_STRICT)
    _memscope_build_analyze_command(
      _memscope_cmd
      ELF "${FW_ELF}"
      MAP "${FW_MAP}"
      LINKER "${FW_LINKER}"
      CONFIG "${FW_CONFIG}"
      HTML "${FW_HTML}"
      JSON "${FW_JSON}"
      CSV "${FW_CSV}"
      BASELINE_JSON "${FW_BASELINE_JSON}"
      TOOLCHAIN "${FW_TOOLCHAIN}"
      TARGET_NAME "${FW_TARGET_NAME}"
      LOG_LEVEL "${FW_LOG_LEVEL}"
      MEMSCOPE_EXECUTABLE "${FW_MEMSCOPE_EXECUTABLE}"
      STRICT
    )
  else()
    _memscope_build_analyze_command(
      _memscope_cmd
      ELF "${FW_ELF}"
      MAP "${FW_MAP}"
      LINKER "${FW_LINKER}"
      CONFIG "${FW_CONFIG}"
      HTML "${FW_HTML}"
      JSON "${FW_JSON}"
      CSV "${FW_CSV}"
      BASELINE_JSON "${FW_BASELINE_JSON}"
      TOOLCHAIN "${FW_TOOLCHAIN}"
      TARGET_NAME "${FW_TARGET_NAME}"
      LOG_LEVEL "${FW_LOG_LEVEL}"
      MEMSCOPE_EXECUTABLE "${FW_MEMSCOPE_EXECUTABLE}"
    )
  endif()

  set(_working_dir "${CMAKE_CURRENT_BINARY_DIR}")
  if(FW_WORKING_DIRECTORY)
    set(_working_dir "${FW_WORKING_DIRECTORY}")
  endif()

  add_custom_command(
    TARGET "${FW_TARGET}"
    POST_BUILD
    COMMAND ${_MEMSCOPE_BUILD_ENV_PREFIX} ${_memscope_cmd}
    WORKING_DIRECTORY "${_working_dir}"
    COMMENT "MemScope analyze (${FW_TARGET})"
    VERBATIM
  )
endfunction()

function(firmware_footprint_custom_target)
  set(options STRICT)
  set(one_value_args
    NAME
    ELF MAP LINKER CONFIG HTML JSON CSV BASELINE_JSON TOOLCHAIN TARGET_NAME LOG_LEVEL
    WORKING_DIRECTORY
    MEMSCOPE_EXECUTABLE
  )
  cmake_parse_arguments(FW "${options}" "${one_value_args}" "" ${ARGN})

  if(NOT FW_NAME)
    message(FATAL_ERROR "firmware_footprint_custom_target requires NAME.")
  endif()
  if(NOT FW_ELF AND NOT FW_MAP AND NOT FW_LINKER)
    message(FATAL_ERROR "firmware_footprint_custom_target requires at least one of ELF, MAP, or LINKER.")
  endif()

  if(FW_STRICT)
    _memscope_build_analyze_command(
      _memscope_cmd
      ELF "${FW_ELF}"
      MAP "${FW_MAP}"
      LINKER "${FW_LINKER}"
      CONFIG "${FW_CONFIG}"
      HTML "${FW_HTML}"
      JSON "${FW_JSON}"
      CSV "${FW_CSV}"
      BASELINE_JSON "${FW_BASELINE_JSON}"
      TOOLCHAIN "${FW_TOOLCHAIN}"
      TARGET_NAME "${FW_TARGET_NAME}"
      LOG_LEVEL "${FW_LOG_LEVEL}"
      MEMSCOPE_EXECUTABLE "${FW_MEMSCOPE_EXECUTABLE}"
      STRICT
    )
  else()
    _memscope_build_analyze_command(
      _memscope_cmd
      ELF "${FW_ELF}"
      MAP "${FW_MAP}"
      LINKER "${FW_LINKER}"
      CONFIG "${FW_CONFIG}"
      HTML "${FW_HTML}"
      JSON "${FW_JSON}"
      CSV "${FW_CSV}"
      BASELINE_JSON "${FW_BASELINE_JSON}"
      TOOLCHAIN "${FW_TOOLCHAIN}"
      TARGET_NAME "${FW_TARGET_NAME}"
      LOG_LEVEL "${FW_LOG_LEVEL}"
      MEMSCOPE_EXECUTABLE "${FW_MEMSCOPE_EXECUTABLE}"
    )
  endif()

  set(_working_dir "${CMAKE_CURRENT_BINARY_DIR}")
  if(FW_WORKING_DIRECTORY)
    set(_working_dir "${FW_WORKING_DIRECTORY}")
  endif()

  add_custom_target(
    "${FW_NAME}"
    COMMAND ${_MEMSCOPE_BUILD_ENV_PREFIX} ${_memscope_cmd}
    WORKING_DIRECTORY "${_working_dir}"
    COMMENT "MemScope analyze custom target (${FW_NAME})"
    VERBATIM
    USES_TERMINAL
  )
endfunction()

function(firmware_footprint_diff_target)
  set(one_value_args
    NAME
    CURRENT_JSON
    BASELINE_JSON
    OUTPUT_JSON
    OUTPUT_HTML
    WORKING_DIRECTORY
    MEMSCOPE_EXECUTABLE
  )
  cmake_parse_arguments(FW "" "${one_value_args}" "" ${ARGN})

  if(NOT FW_NAME)
    message(FATAL_ERROR "firmware_footprint_diff_target requires NAME.")
  endif()
  if(NOT FW_CURRENT_JSON OR NOT FW_BASELINE_JSON)
    message(FATAL_ERROR "firmware_footprint_diff_target requires CURRENT_JSON and BASELINE_JSON.")
  endif()

  _memscope_resolve_executable(_memscope_bin "${FW_MEMSCOPE_EXECUTABLE}")
  set(_cmd
    "${_memscope_bin}" "diff"
    "--current-json" "${FW_CURRENT_JSON}"
    "--baseline-json" "${FW_BASELINE_JSON}"
  )
  _memscope_append_arg(_cmd "--json" "${FW_OUTPUT_JSON}")
  _memscope_append_arg(_cmd "--html" "${FW_OUTPUT_HTML}")

  set(_working_dir "${CMAKE_CURRENT_BINARY_DIR}")
  if(FW_WORKING_DIRECTORY)
    set(_working_dir "${FW_WORKING_DIRECTORY}")
  endif()

  add_custom_target(
    "${FW_NAME}"
    COMMAND ${_MEMSCOPE_BUILD_ENV_PREFIX} ${_cmd}
    WORKING_DIRECTORY "${_working_dir}"
    COMMENT "MemScope diff (${FW_NAME})"
    VERBATIM
    USES_TERMINAL
  )
endfunction()
