"""Backends registry — holds connected clients for service code to retrieve."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, TypeVar, overload

from ._base import Backend
from ._db import DbBackend
from ._nats import NatsBackend
from ._s3 import S3Backend

if TYPE_CHECKING:
    from nats.aio.client import Client as NatsClient
    from nats.js.client import JetStreamContext
    from sqlalchemy import Engine

_DEFAULT = "default"
T = TypeVar("T")


class Backends:
    """Registry of connected backends, returned by check_backends()."""

    def __init__(self) -> None:
        self._db: dict[str, DbBackend] = {}
        self._nats: dict[str, NatsBackend] = {}
        self._s3: dict[str, S3Backend] = {}

    def _register(self, backend: Backend) -> None:
        if isinstance(backend, DbBackend):
            self._db[backend.name] = backend
        elif isinstance(backend, NatsBackend):
            self._nats[backend.name] = backend
        elif isinstance(backend, S3Backend):
            self._s3[backend.name] = backend

    def db(self, name: str | None = None) -> Engine | None:
        """Get a SQLAlchemy Engine by backend name. None uses 'default'."""
        return self._db[name or _DEFAULT].get_client()

    @overload
    def db_tables(self, name: str | None = ...) -> dict[str, str]: ...
    @overload
    def db_tables(self, name: str | None = ..., *, cls: type[T]) -> T: ...
    def db_tables(
        self, name: str | None = None, *, cls: type | None = None
    ) -> dict[str, str] | Any:
        """Get tables for a DB backend. Pass *cls* for a typed dataclass."""
        d = self._db[name or _DEFAULT].tables()
        return cls(**d) if cls is not None else d

    def nats(
        self, name: str | None = None
    ) -> tuple[NatsClient | None, JetStreamContext | None]:
        """Get a (NatsClient, JetStreamContext) tuple by backend name. None uses 'default'."""
        return self._nats[name or _DEFAULT].get_client()

    def s3(self, name: str | None = None) -> Any:
        """Get a boto3 S3 client by backend name. None uses 'default'."""
        return self._s3[name or _DEFAULT].get_client()

    @overload
    def s3_buckets(self, name: str | None = ...) -> dict[str, str]: ...
    @overload
    def s3_buckets(self, name: str | None = ..., *, cls: type[T]) -> T: ...
    def s3_buckets(
        self, name: str | None = None, *, cls: type | None = None
    ) -> dict[str, str] | Any:
        """Get buckets for an S3 backend. Pass *cls* for a typed dataclass."""
        d = self._s3[name or _DEFAULT].buckets()
        return cls(**d) if cls is not None else d

    # -- Typed NATS resource accessors -----------------------------------

    @overload
    def nats_streams(self, name: str | None = ...) -> dict[str, str]: ...
    @overload
    def nats_streams(self, name: str | None = ..., *, cls: type[T]) -> T: ...
    def nats_streams(
        self, name: str | None = None, *, cls: type | None = None
    ) -> dict[str, str] | Any:
        """Get streams for a NATS backend. Pass *cls* for a typed dataclass."""
        d = self._nats[name or _DEFAULT].streams()
        return cls(**d) if cls is not None else d

    @overload
    def nats_kv(self, name: str | None = ...) -> dict[str, str]: ...
    @overload
    def nats_kv(self, name: str | None = ..., *, cls: type[T]) -> T: ...
    def nats_kv(
        self, name: str | None = None, *, cls: type | None = None
    ) -> dict[str, str] | Any:
        """Get KV buckets for a NATS backend. Pass *cls* for a typed dataclass."""
        d = self._nats[name or _DEFAULT].kv()
        return cls(**d) if cls is not None else d

    @overload
    def nats_kv_keys(self, alias: str, name: str | None = ...) -> dict[str, str]: ...
    @overload
    def nats_kv_keys(
        self, alias: str, name: str | None = ..., *, cls: type[T]
    ) -> T: ...
    def nats_kv_keys(
        self, alias: str, name: str | None = None, *, cls: type | None = None
    ) -> dict[str, str] | Any:
        """Get keys for a KV bucket alias. Pass *cls* for a typed dataclass."""
        d = self._nats[name or _DEFAULT].kv_keys(alias)
        return cls(**d) if cls is not None else d

    @overload
    def nats_subjects(self, name: str | None = ...) -> dict[str, str]: ...
    @overload
    def nats_subjects(self, name: str | None = ..., *, cls: type[T]) -> T: ...
    def nats_subjects(
        self, name: str | None = None, *, cls: type | None = None
    ) -> dict[str, str] | Any:
        """Get subjects for a NATS backend. Pass *cls* for a typed dataclass."""
        d = self._nats[name or _DEFAULT].subjects()
        return cls(**d) if cls is not None else d
