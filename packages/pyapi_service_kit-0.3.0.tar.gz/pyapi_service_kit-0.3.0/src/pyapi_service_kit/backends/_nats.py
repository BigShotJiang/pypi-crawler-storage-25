"""NATS JetStream backend."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._base import Backend, ConnectResult, ResourceResult, _check_files

if TYPE_CHECKING:
    from nats.aio.client import Client as NatsClient
    from nats.js.client import JetStreamContext


def _normalise_kv(value: str | dict) -> dict:
    """Accept ``"bucket-name"`` or ``{"bucket": "bucket-name", "keys": {...}}``."""
    if isinstance(value, str):
        return {"bucket": value}
    return value


class NatsBackend(Backend):
    def __init__(
        self,
        name: str,
        connection: dict,
        streams: dict[str, str] | None = None,
        kv: dict[str, str | dict] | None = None,
        subjects: dict[str, str] | None = None,
    ):
        super().__init__(name, "nats", connection)
        self._streams = streams or {}
        self._kv = {alias: _normalise_kv(v) for alias, v in (kv or {}).items()}
        self._subjects = subjects or {}
        self._nc: NatsClient | None = None
        self._js: JetStreamContext | None = None

    async def connect(self) -> ConnectResult:
        try:
            try:
                import nats
            except ImportError:
                return ConnectResult(
                    False,
                    "nats-py not installed — install with: pip install nats-py",
                )
            import ssl

            c = self._connection_config
            options = dict(c.get("options", {}))

            file_err = _check_files(options, ["user_credentials", "tls_ca"], self.label)
            if file_err:
                return ConnectResult(False, file_err)

            servers = c.get("servers", [])

            # Process tls_ca into an SSL context
            tls_ca = options.pop("tls_ca", None)
            if tls_ca:
                ctx = ssl.create_default_context(cafile=tls_ca)
                # Workaround for CAs without key usage extension (Python 3.13+)
                ctx.verify_flags &= ~ssl.VERIFY_X509_STRICT
                options["tls"] = ctx

            self._nc = await nats.connect(servers, **options)
            self._js = self._nc.jetstream()
            self._connected = True
            return ConnectResult(True, "connected")
        except Exception as exc:
            self._connected = False
            return ConnectResult(False, str(exc))

    async def check_resources(self) -> list[ResourceResult]:
        results: list[ResourceResult] = []
        if not self._js:
            for s in self._streams.values():
                results.append(ResourceResult(f"stream {s}", False, "not connected"))
            for entry in self._kv.values():
                bucket = entry["bucket"]
                results.append(ResourceResult(f"kv {bucket}", False, "not connected"))
            return results

        for stream_name in self._streams.values():
            try:
                await self._js.stream_info(stream_name)
                results.append(ResourceResult(f"stream {stream_name}", True, "exists"))
            except Exception as exc:
                err = str(exc)
                if "not found" in err.lower():
                    results.append(
                        ResourceResult(f"stream {stream_name}", False, "not found")
                    )
                else:
                    results.append(ResourceResult(f"stream {stream_name}", False, err))

        for entry in self._kv.values():
            kv_name = entry["bucket"]
            try:
                await self._js.key_value(kv_name)
                results.append(ResourceResult(f"kv {kv_name}", True, "exists"))
            except Exception as exc:
                err = str(exc)
                if "not found" in err.lower():
                    results.append(ResourceResult(f"kv {kv_name}", False, "not found"))
                else:
                    results.append(ResourceResult(f"kv {kv_name}", False, err))

        return results

    def get_client(self) -> tuple[NatsClient | None, JetStreamContext | None]:
        return self._nc, self._js

    def streams(self) -> dict[str, str]:
        """Return the configured stream alias mapping."""
        return dict(self._streams)

    def kv(self) -> dict[str, str]:
        """Return the configured KV bucket alias mapping (alias → bucket name)."""
        return {alias: entry["bucket"] for alias, entry in self._kv.items()}

    def kv_keys(self, alias: str) -> dict[str, str]:
        """Return the keys configured for a specific KV bucket alias."""
        entry = self._kv.get(alias, {})
        return dict(entry.get("keys", {}))

    def subjects(self) -> dict[str, str]:
        """Return the configured subject alias mapping."""
        return dict(self._subjects)

    def resource_names(self) -> list[str]:
        return [f"stream {s}" for s in self._streams.values()] + [
            f"kv {entry['bucket']}" for entry in self._kv.values()
        ]
