"""S3-compatible object storage backend."""

from __future__ import annotations

import asyncio
from typing import Any

from ._base import Backend, ConnectResult, ResourceResult


class S3Backend(Backend):
    def __init__(
        self,
        name: str,
        connection: dict,
        buckets: dict[str, str] | None = None,
    ):
        super().__init__(name, "s3", connection)
        self._buckets = buckets or {}
        self._client: Any = None

    async def connect(self) -> ConnectResult:
        try:
            try:
                import boto3
            except ImportError:
                return ConnectResult(
                    False,
                    "boto3 not installed — install with: pip install pyapi-service-kit[s3]",
                )

            c = self._connection_config
            self._client = boto3.client(
                "s3",
                endpoint_url=c["endpoint_url"],
                aws_access_key_id=c["access_key_id"],
                aws_secret_access_key=c["secret_access_key"],
                region_name=c["region"],
            )

            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, self._client.list_buckets)
            self._connected = True
            return ConnectResult(True, "connected")
        except Exception as exc:
            self._connected = False
            return ConnectResult(False, str(exc))

    async def check_resources(self) -> list[ResourceResult]:
        results: list[ResourceResult] = []
        if not self._client:
            for b in self._buckets.values():
                results.append(ResourceResult(f"bucket {b}", False, "not connected"))
            return results

        loop = asyncio.get_running_loop()
        for bucket_name in self._buckets.values():
            try:

                def _head(b: str = bucket_name) -> Any:
                    return self._client.head_bucket(Bucket=b)

                await loop.run_in_executor(None, _head)
                results.append(
                    ResourceResult(f"bucket {bucket_name}", True, "accessible")
                )
            except Exception as exc:
                err = str(exc)
                if "Not Found" in err or "NoSuchBucket" in err:
                    results.append(
                        ResourceResult(f"bucket {bucket_name}", False, "not found")
                    )
                elif "InvalidAccessKeyId" in err or "Forbidden" in err:
                    results.append(
                        ResourceResult(
                            f"bucket {bucket_name}", False, f"access denied: {err}"
                        )
                    )
                else:
                    results.append(ResourceResult(f"bucket {bucket_name}", False, err))

        return results

    def get_client(self) -> Any:
        return self._client

    def buckets(self) -> dict[str, str]:
        """Return the configured bucket alias mapping."""
        return dict(self._buckets)

    def resource_names(self) -> list[str]:
        return [f"bucket {b}" for b in self._buckets.values()]
