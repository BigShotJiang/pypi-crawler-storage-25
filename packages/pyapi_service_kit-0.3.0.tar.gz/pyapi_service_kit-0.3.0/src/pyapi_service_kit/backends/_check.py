"""Config parsing and main check loop."""

from __future__ import annotations

import asyncio
import logging
import time

from ._base import Backend, _ResourceState
from ._db import DbBackend
from ._nats import NatsBackend
from ._s3 import S3Backend
from ._registry import Backends
from .errors import ResourceNotReadyError

LOGGER = logging.getLogger(__name__)


def _parse_backends(config: dict | list) -> list[Backend]:
    """Parse a backends config into Backend objects.

    Accepts a flat list of entries, each with a ``type`` field::

        [
            {"name": "mariadb", "type": "db", "connection": {...}, "tables": [...]},
            {"name": "stone", "type": "nats", "connection": {...}, "streams": [...]},
            {"name": "rustfs", "type": "s3", "connection": {...}, "buckets": [...]},
        ]
    """
    entries = config if isinstance(config, list) else config.get("backends", config)
    if not isinstance(entries, list):
        return []

    backends: list[Backend] = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        backend_type = entry.get("type", "")
        name = entry.get("name", "")

        if backend_type == "db":
            backends.append(
                DbBackend(
                    name=name,
                    connection=entry.get("connection", {}),
                    tables=entry.get("tables"),
                )
            )
        elif backend_type == "nats":
            backends.append(
                NatsBackend(
                    name=name,
                    connection=entry.get("connection", {}),
                    streams=entry.get("streams"),
                    kv=entry.get("kv"),
                    subjects=entry.get("subjects"),
                )
            )
        elif backend_type == "s3":
            backends.append(
                S3Backend(
                    name=name,
                    connection=entry.get("connection", {}),
                    buckets=entry.get("buckets"),
                )
            )
        else:
            LOGGER.warning(
                "Unknown backend type '%s' for '%s' — skipping", backend_type, name
            )

    return backends


async def check_backends(
    config: dict | list,
    interval: float | None = None,
    timeout: float | None = None,
    names: list[str] | None = None,
    once: bool = False,
) -> Backends:
    """Parse config, connect to backends, and wait for all resources.

    Args:
        config: Either a list of backend entries (each with ``type`` and ``name``),
                or a dict with optional ``interval``/``timeout`` keys.
        interval: Override retry interval (default from config or 5s).
        timeout: Override timeout (default from config or 0=forever).
        names: If set, only check backends with these names.
        once: If True, check once and raise on failure instead of retrying.

    Returns:
        A :class:`Backends` registry with connected clients.

    Raises:
        TimeoutError: If timeout exceeded.
        RuntimeError: If ``once=True`` and any resource is not ready.
    """
    cfg = config if isinstance(config, dict) else {}
    _interval = interval if interval is not None else cfg.get("interval", 5.0)
    _timeout = timeout if timeout is not None else cfg.get("timeout", 0.0)

    all_backends = _parse_backends(config)

    if names:
        name_set = set(names)
        all_backends = [b for b in all_backends if b.name in name_set]

    if not all_backends:
        return Backends()

    # Collect all resource states
    resource_states: list[_ResourceState] = []
    for b in all_backends:
        for rname in b.resource_names():
            resource_states.append(_ResourceState(b.name, rname))

    labels = ", ".join(b.label for b in all_backends)
    total_resources = len(resource_states)
    LOGGER.info("Waiting for %d backends: [%s]", len(all_backends), labels)

    registry = Backends()
    start = time.monotonic()
    first_round = True

    while True:
        # Reset resource states for this round
        for rs in resource_states:
            rs.ready = False

        for b in all_backends:
            # Phase 1+2: Connect (includes auth)
            if not b._connected:
                ok, detail = await b.connect()
                if first_round or not ok:
                    mark = "\u2713" if ok else "\u2717"
                    LOGGER.info("  %s %s — %s", mark, b.label, detail)
                if not ok:
                    # Mark all resources for this backend as not ready
                    for rs in resource_states:
                        if rs.backend_name == b.name:
                            rs.last_detail = f"not connected: {detail}"
                    continue

            # Phase 3: Check resources
            results = await b.check_resources()
            for res_name, ready, detail in results:
                for rs in resource_states:
                    if rs.backend_name == b.name and rs.resource_name == res_name:
                        changed = detail != rs.last_detail
                        rs.ready = ready
                        rs.last_detail = detail
                        if first_round or changed:
                            mark = "\u2713" if ready else "\u2717"
                            LOGGER.info(
                                "  %s %s %s — %s", mark, b.label, res_name, detail
                            )
                        break

        ready_count = sum(1 for rs in resource_states if rs.ready)

        if ready_count == total_resources:
            LOGGER.info(
                "All %d resources across %d backends ready.",
                total_resources,
                len(all_backends),
            )
            for b in all_backends:
                registry._register(b)
            return registry

        if once:
            not_ready = [rs for rs in resource_states if not rs.ready]
            if not_ready:
                rs = not_ready[0]
                raise ResourceNotReadyError(
                    backend=rs.backend_name,
                    resource=rs.resource_name,
                    detail=rs.last_detail or "not ready",
                )

        if _timeout > 0 and (time.monotonic() - start) >= _timeout:
            pending = [
                f"{rs.backend_name}:{rs.resource_name}"
                for rs in resource_states
                if not rs.ready
            ]
            raise TimeoutError(
                f"Timed out after {_timeout}s waiting for: {', '.join(pending)}"
            )

        pending = [rs.resource_name for rs in resource_states if not rs.ready]
        LOGGER.info(
            "%d/%d ready — waiting for: [%s] — retrying in %ds...",
            ready_count,
            total_resources,
            ", ".join(pending),
            int(_interval),
        )

        first_round = False
        await asyncio.sleep(_interval)


# Convenience alias
wait_for_dependencies = check_backends
