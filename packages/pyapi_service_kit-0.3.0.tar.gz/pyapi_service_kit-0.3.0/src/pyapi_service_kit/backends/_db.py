"""Database (MariaDB/MySQL) backend."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from ._base import Backend, ConnectResult, ResourceResult, _check_files

if TYPE_CHECKING:
    from sqlalchemy import Engine

_VALID_TABLE_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_.]*$")


def _normalise_table(value: str | dict) -> dict:
    """Accept ``"schema.table"`` or ``{"name": "schema.table", "min_rows": 1}``."""
    if isinstance(value, str):
        return {"name": value}
    return value


class DbBackend(Backend):
    def __init__(
        self,
        name: str,
        connection: dict,
        tables: dict[str, str | dict] | None = None,
    ):
        super().__init__(name, "db", connection)
        self._tables = {
            alias: _normalise_table(v) for alias, v in (tables or {}).items()
        }
        self._engine: Engine | None = None

    async def connect(self) -> ConnectResult:
        try:
            try:
                from sqlalchemy import create_engine, text
            except ImportError:
                return ConnectResult(
                    False,
                    "sqlalchemy not installed — install with: pip install pyapi-service-kit[db]",
                )

            c = self._connection_config
            ssl_config = c.get("ssl_config", {})

            file_err = _check_files(ssl_config, ["ssl_ca"], self.label)
            if file_err:
                return ConnectResult(False, file_err)

            hostname = c["hostname"]
            port = c.get("port", 3306)
            username = c["username"]
            password = c["password"]
            ssl_ca = ssl_config.get("ssl_ca")

            connect_args = {}
            if ssl_ca:
                connect_args["ssl"] = {"ca": ssl_ca}
            connect_args.update(c.get("connect_kwargs", {}))

            engine_kwargs = dict(c.get("engine_kwargs", {}))

            url = f"mariadb+mariadbconnector://{username}:{password}@{hostname}:{port}"
            self._engine = create_engine(
                url, connect_args=connect_args, **engine_kwargs
            )

            with self._engine.connect() as conn:
                conn.execute(text("SELECT 1"))

            self._connected = True
            return ConnectResult(True, "connected")
        except Exception as exc:
            self._connected = False
            return ConnectResult(False, str(exc))

    async def check_resources(self) -> list[ResourceResult]:
        results: list[ResourceResult] = []
        if not self._engine:
            for t in self._tables.values():
                results.append(ResourceResult(t["name"], False, "not connected"))
            return results

        from sqlalchemy import text

        for t in self._tables.values():
            fqn = t["name"]  # "schema.table"
            min_rows = t.get("min_rows", 0)

            if not _VALID_TABLE_RE.match(fqn):
                results.append(
                    ResourceResult(fqn, False, f"invalid table name: {fqn!r}")
                )
                continue

            parts = fqn.split(".")
            quoted = ".".join(f"`{p}`" for p in parts)
            try:
                with self._engine.connect() as conn:
                    result = conn.execute(text(f"SELECT COUNT(*) FROM {quoted}"))
                    count = result.scalar() or 0

                if min_rows > 0 and count < min_rows:
                    results.append(
                        ResourceResult(
                            fqn, False, f"need ≥{min_rows} rows, found {count}"
                        )
                    )
                else:
                    results.append(ResourceResult(fqn, True, f"{count} rows"))
            except Exception as exc:
                results.append(ResourceResult(fqn, False, str(exc)))

        return results

    def get_client(self) -> Engine | None:
        return self._engine

    def tables(self) -> dict[str, str]:
        """Return the configured table alias mapping (alias → FQN)."""
        return {alias: t["name"] for alias, t in self._tables.items()}

    def resource_names(self) -> list[str]:
        return [t["name"] for t in self._tables.values()]
