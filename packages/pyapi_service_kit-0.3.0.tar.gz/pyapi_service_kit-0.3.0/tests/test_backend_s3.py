"""Tests for S3Backend."""

from unittest.mock import MagicMock

import pytest

from pyapi_service_kit.backends import S3Backend


class TestS3Backend:
    @pytest.mark.asyncio
    async def test_check_bucket_accessible(self):
        backend = S3Backend("storage", {}, buckets={"data": "my-data"})
        backend._client = MagicMock()
        backend._client.head_bucket.return_value = {}

        results = await backend.check_resources()
        name, ready, detail = results[0]
        assert ready is True

    @pytest.mark.asyncio
    async def test_check_bucket_not_found(self):
        backend = S3Backend("storage", {}, buckets={"data": "my-data"})
        backend._client = MagicMock()
        backend._client.head_bucket.side_effect = Exception("Not Found")

        results = await backend.check_resources()
        name, ready, detail = results[0]
        assert ready is False
        assert "not found" in detail

    @pytest.mark.asyncio
    async def test_check_bucket_access_denied(self):
        backend = S3Backend("storage", {}, buckets={"data": "my-data"})
        backend._client = MagicMock()
        backend._client.head_bucket.side_effect = Exception(
            "InvalidAccessKeyId: bad key"
        )

        results = await backend.check_resources()
        name, ready, detail = results[0]
        assert ready is False
        assert "access denied" in detail

    def test_buckets_stored(self):
        backend = S3Backend("storage", {}, buckets={"data": "my-data"})
        assert backend.buckets() == {"data": "my-data"}

    def test_buckets_default_empty(self):
        backend = S3Backend("storage", {})
        assert backend.buckets() == {}
