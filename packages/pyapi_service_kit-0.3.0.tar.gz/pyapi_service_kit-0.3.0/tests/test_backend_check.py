"""Tests for config parsing, check_backends, and result types."""

from unittest.mock import patch

import pytest

from pyapi_service_kit.backends import (
    Backends,
    ConnectResult,
    DbBackend,
    NatsBackend,
    ResourceNotReadyError,
    ResourceResult,
    S3Backend,
    check_backends,
)
from pyapi_service_kit.backends._check import _parse_backends


class TestParseBackends:
    def test_parse_db(self):
        config = [
            {
                "name": "primary",
                "type": "db",
                "connection": {
                    "hostname": "h",
                    "port": 3306,
                    "username": "u",
                    "password": "p",
                },
                "tables": {"users": "app.users"},
            }
        ]
        backends = _parse_backends(config)
        assert len(backends) == 1
        assert isinstance(backends[0], DbBackend)
        assert backends[0].name == "primary"

    def test_parse_nats(self):
        config = [
            {
                "name": "messaging",
                "type": "nats",
                "connection": {"servers": ["nats://localhost:4222"]},
                "streams": {"events": "EVENTS"},
                "kv": {"state": "APP_STATE"},
            }
        ]
        backends = _parse_backends(config)
        assert len(backends) == 1
        assert isinstance(backends[0], NatsBackend)

    def test_parse_nats_with_subjects(self):
        config = [
            {
                "name": "messaging",
                "type": "nats",
                "connection": {"servers": ["nats://localhost:4222"]},
                "subjects": {"time": "local.time-server"},
            }
        ]
        backends = _parse_backends(config)
        assert len(backends) == 1
        assert backends[0]._subjects == {"time": "local.time-server"}

    def test_parse_s3(self):
        config = [
            {
                "name": "storage",
                "type": "s3",
                "connection": {
                    "endpoint_url": "http://localhost:9000",
                    "access_key_id": "k",
                    "secret_access_key": "s",
                    "region": "us-east-1",
                },
                "buckets": {"data": "b1"},
            }
        ]
        backends = _parse_backends(config)
        assert len(backends) == 1
        assert isinstance(backends[0], S3Backend)

    def test_parse_mixed(self):
        config = [
            {
                "name": "db1",
                "type": "db",
                "connection": {
                    "hostname": "h",
                    "port": 3306,
                    "username": "u",
                    "password": "p",
                },
            },
            {"name": "n1", "type": "nats", "connection": {"servers": []}},
            {
                "name": "s1",
                "type": "s3",
                "connection": {
                    "endpoint_url": "u",
                    "access_key_id": "k",
                    "secret_access_key": "s",
                    "region": "us-east-1",
                },
                "buckets": {"b": "b"},
            },
        ]
        backends = _parse_backends(config)
        assert len(backends) == 3

    def test_parse_empty(self):
        assert _parse_backends([]) == []


class TestCheckBackends:
    @pytest.mark.asyncio
    async def test_all_ready_immediately(self):
        config = [
            {
                "name": "testdb",
                "type": "db",
                "connection": {
                    "hostname": "h",
                    "port": 3306,
                    "username": "u",
                    "password": "p",
                },
                "tables": {"items": "app.items"},
            },
        ]

        with (
            patch.object(
                DbBackend, "connect", return_value=ConnectResult(True, "connected")
            ),
            patch.object(
                DbBackend,
                "check_resources",
                return_value=[ResourceResult("app.items", True, "1 rows")],
            ),
        ):
            result = await check_backends(config, interval=0.01)

        assert isinstance(result, Backends)

    @pytest.mark.asyncio
    async def test_once_mode_fails(self):
        config = [
            {
                "name": "testdb",
                "type": "db",
                "connection": {
                    "hostname": "h",
                    "port": 3306,
                    "username": "u",
                    "password": "p",
                },
                "tables": {"items": {"name": "app.items", "min_rows": 1}},
            },
        ]

        with (
            patch.object(
                DbBackend, "connect", return_value=ConnectResult(True, "connected")
            ),
            patch.object(
                DbBackend,
                "check_resources",
                return_value=[
                    ResourceResult("app.items", False, "need \u22651 rows, found 0")
                ],
            ),
        ):
            with pytest.raises(ResourceNotReadyError):
                await check_backends(config, once=True)

    @pytest.mark.asyncio
    async def test_name_filter(self):
        config = [
            {
                "name": "db1",
                "type": "db",
                "connection": {
                    "hostname": "h",
                    "port": 3306,
                    "username": "u",
                    "password": "p",
                },
                "tables": {"a": "a.a"},
            },
            {
                "name": "db2",
                "type": "db",
                "connection": {
                    "hostname": "h",
                    "port": 3306,
                    "username": "u",
                    "password": "p",
                },
                "tables": {"b": "b.b"},
            },
        ]

        call_count = 0

        async def counting_connect(self):
            nonlocal call_count
            call_count += 1
            return ConnectResult(True, "connected")

        with (
            patch.object(DbBackend, "connect", counting_connect),
            patch.object(
                DbBackend,
                "check_resources",
                return_value=[ResourceResult("a.a", True, "ok")],
            ),
        ):
            await check_backends(config, names=["db1"], interval=0.01)

        assert call_count == 1  # only db1 was checked

    @pytest.mark.asyncio
    async def test_timeout(self):
        config = [
            {
                "name": "testdb",
                "type": "db",
                "connection": {
                    "hostname": "h",
                    "port": 3306,
                    "username": "u",
                    "password": "p",
                },
                "tables": {"items": "app.items"},
            },
        ]

        with patch.object(
            DbBackend, "connect", return_value=ConnectResult(False, "refused")
        ):
            with pytest.raises(TimeoutError):
                await check_backends(config, timeout=0.05, interval=0.01)


class TestResultTypes:
    def test_connect_result_unpacking(self):
        r = ConnectResult(True, "connected")
        ok, detail = r
        assert ok is True
        assert detail == "connected"

    def test_resource_result_unpacking(self):
        r = ResourceResult("app.items", True, "500 rows")
        name, ready, detail = r
        assert name == "app.items"
        assert ready is True

    def test_resource_not_ready_error(self):
        err = ResourceNotReadyError("testdb", "app.items", "need more rows")
        assert err.backend == "testdb"
        assert err.resource == "app.items"
        assert "app.items" in str(err)
