"""Tests for Backends registry."""

from dataclasses import dataclass

import pytest

from pyapi_service_kit.backends import (
    Backends,
    DbBackend,
    NatsBackend,
    S3Backend,
)


class TestBackendsRegistry:
    def test_db_accessor(self):
        registry = Backends()
        backend = DbBackend("primary", {})
        backend._engine = "engine"
        registry._register(backend)
        assert registry.db("primary") == "engine"

    def test_db_tables_accessor(self):
        registry = Backends()
        backend = DbBackend("default", {}, tables={"users": "app.users"})
        registry._register(backend)
        assert registry.db_tables() == {"users": "app.users"}

    def test_nats_accessor(self):
        registry = Backends()
        backend = NatsBackend("messaging", {})
        backend._nc = "nc"
        backend._js = "js"
        registry._register(backend)
        assert registry.nats("messaging") == ("nc", "js")

    def test_nats_streams_accessor(self):
        registry = Backends()
        backend = NatsBackend("default", {}, streams={"events": "EVENTS"})
        registry._register(backend)
        assert registry.nats_streams() == {"events": "EVENTS"}

    def test_nats_kv_accessor(self):
        registry = Backends()
        backend = NatsBackend("default", {}, kv={"state": "APP_STATE"})
        registry._register(backend)
        assert registry.nats_kv() == {"state": "APP_STATE"}

    def test_nats_kv_keys_accessor(self):
        @dataclass
        class ApiKeys:
            latest: str

        registry = Backends()
        backend = NatsBackend(
            "default",
            {},
            kv={"api": {"bucket": "my-bucket", "keys": {"latest": "key.latest"}}},
        )
        registry._register(backend)
        assert registry.nats_kv_keys("api") == {"latest": "key.latest"}
        result = registry.nats_kv_keys("api", cls=ApiKeys)
        assert isinstance(result, ApiKeys)
        assert result.latest == "key.latest"

    def test_nats_subjects_accessor(self):
        registry = Backends()
        backend = NatsBackend("default", {}, subjects={"time": "local.time-server"})
        registry._register(backend)
        assert registry.nats_subjects() == {"time": "local.time-server"}

    def test_nats_subjects_typed_accessor(self):
        @dataclass
        class Subjects:
            time: str

        registry = Backends()
        backend = NatsBackend("default", {}, subjects={"time": "local.time-server"})
        registry._register(backend)
        result = registry.nats_subjects(cls=Subjects)
        assert isinstance(result, Subjects)
        assert result.time == "local.time-server"

    def test_s3_accessor(self):
        registry = Backends()
        backend = S3Backend("storage", {})
        backend._client = "client"
        registry._register(backend)
        assert registry.s3("storage") == "client"

    def test_s3_buckets_accessor(self):
        registry = Backends()
        backend = S3Backend("default", {}, buckets={"data": "my-bucket"})
        registry._register(backend)
        assert registry.s3_buckets() == {"data": "my-bucket"}

    def test_missing_key_raises(self):
        registry = Backends()
        with pytest.raises(KeyError):
            registry.db("nonexistent")
