"""Tests for DbBackend."""

from unittest.mock import MagicMock, patch

import pytest

from pyapi_service_kit.backends import DbBackend


class TestDbBackend:
    @pytest.mark.asyncio
    async def test_connect_success(self):
        backend = DbBackend(
            "testdb",
            {"hostname": "localhost", "port": 3306, "username": "u", "password": "p"},
        )
        with patch("sqlalchemy.create_engine") as mock_ce:
            mock_engine = MagicMock()
            mock_conn = MagicMock()
            mock_engine.connect.return_value.__enter__ = MagicMock(
                return_value=mock_conn
            )
            mock_engine.connect.return_value.__exit__ = MagicMock(return_value=False)
            mock_ce.return_value = mock_engine

            ok, detail = await backend.connect()
            assert ok is True
            assert "connected" in detail

    @pytest.mark.asyncio
    async def test_connect_failure(self):
        backend = DbBackend(
            "testdb",
            {"hostname": "bad", "port": 3306, "username": "u", "password": "p"},
        )
        with patch(
            "sqlalchemy.create_engine", side_effect=Exception("Connection refused")
        ):
            ok, detail = await backend.connect()
            assert ok is False
            assert "Connection refused" in detail

    @pytest.mark.asyncio
    async def test_check_resources_table_ready(self):
        backend = DbBackend(
            "testdb", {}, tables={"users": {"name": "app.users", "min_rows": 1}}
        )
        mock_engine = MagicMock()
        mock_conn = MagicMock()
        mock_engine.connect.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_engine.connect.return_value.__exit__ = MagicMock(return_value=False)
        mock_conn.execute.return_value.scalar.return_value = 500
        backend._engine = mock_engine

        results = await backend.check_resources()
        assert len(results) == 1
        name, ready, detail = results[0]
        assert ready is True
        assert "500 rows" in detail

    @pytest.mark.asyncio
    async def test_check_resources_table_empty(self):
        backend = DbBackend(
            "testdb", {}, tables={"users": {"name": "app.users", "min_rows": 1}}
        )
        mock_engine = MagicMock()
        mock_conn = MagicMock()
        mock_engine.connect.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_engine.connect.return_value.__exit__ = MagicMock(return_value=False)
        mock_conn.execute.return_value.scalar.return_value = 0
        backend._engine = mock_engine

        results = await backend.check_resources()
        name, ready, detail = results[0]
        assert ready is False
        assert "found 0" in detail

    def test_get_client(self):
        backend = DbBackend("testdb", {})
        backend._engine = "fake_engine"
        assert backend.get_client() == "fake_engine"

    def test_label(self):
        backend = DbBackend("primary", {})
        assert backend.label == "db:primary"

    def test_tables_simple_string(self):
        backend = DbBackend("testdb", {}, tables={"users": "app.users"})
        assert backend.tables() == {"users": "app.users"}

    def test_tables_rich_dict(self):
        backend = DbBackend(
            "testdb", {}, tables={"users": {"name": "app.users", "min_rows": 1}}
        )
        assert backend.tables() == {"users": "app.users"}

    def test_tables_default_empty(self):
        backend = DbBackend("testdb", {})
        assert backend.tables() == {}


class TestDbBackendSQLSafety:
    @pytest.mark.asyncio
    async def test_rejects_invalid_table_name(self):
        backend = DbBackend("testdb", {}, tables={"bad": "app; DROP TABLE users;--"})
        mock_engine = MagicMock()
        backend._engine = mock_engine

        results = await backend.check_resources()
        assert len(results) == 1
        assert results[0].ready is False
        assert "invalid table name" in results[0].detail

    @pytest.mark.asyncio
    async def test_accepts_valid_dotted_name(self):
        backend = DbBackend("testdb", {}, tables={"users": "myschema.users"})
        mock_engine = MagicMock()
        mock_conn = MagicMock()
        mock_engine.connect.return_value.__enter__ = MagicMock(return_value=mock_conn)
        mock_engine.connect.return_value.__exit__ = MagicMock(return_value=False)
        mock_conn.execute.return_value.scalar.return_value = 10
        backend._engine = mock_engine

        results = await backend.check_resources()
        assert results[0].ready is True

        # Verify the query uses backtick quoting
        call_args = mock_conn.execute.call_args[0][0]
        assert "`myschema`.`users`" in str(call_args)
