"""Tests for NatsBackend."""

from unittest.mock import AsyncMock

import pytest

from pyapi_service_kit.backends import NatsBackend


class TestNatsBackend:
    @pytest.mark.asyncio
    async def test_check_stream_exists(self):
        backend = NatsBackend("messaging", {}, streams={"events": "EVENTS"})
        backend._js = AsyncMock()
        backend._js.stream_info.return_value = {}

        results = await backend.check_resources()
        assert len(results) == 1
        name, ready, detail = results[0]
        assert ready is True

    @pytest.mark.asyncio
    async def test_check_stream_not_found(self):
        backend = NatsBackend("messaging", {}, streams={"events": "EVENTS"})
        backend._js = AsyncMock()
        backend._js.stream_info.side_effect = Exception("stream not found")

        results = await backend.check_resources()
        name, ready, detail = results[0]
        assert ready is False
        assert "not found" in detail

    @pytest.mark.asyncio
    async def test_check_kv_exists(self):
        backend = NatsBackend("messaging", {}, kv={"state": "APP_STATE"})
        backend._js = AsyncMock()
        backend._js.key_value.return_value = {}

        results = await backend.check_resources()
        name, ready, detail = results[0]
        assert ready is True

    @pytest.mark.asyncio
    async def test_check_kv_not_found(self):
        backend = NatsBackend("messaging", {}, kv={"state": "APP_STATE"})
        backend._js = AsyncMock()
        backend._js.key_value.side_effect = Exception("bucket not found")

        results = await backend.check_resources()
        name, ready, detail = results[0]
        assert ready is False
        assert "not found" in detail

    def test_get_client(self):
        backend = NatsBackend("messaging", {})
        backend._nc = "nc"
        backend._js = "js"
        assert backend.get_client() == ("nc", "js")

    def test_streams_stored(self):
        backend = NatsBackend("messaging", {}, streams={"events": "EVENTS"})
        assert backend.streams() == {"events": "EVENTS"}

    def test_kv_simple_stored(self):
        backend = NatsBackend("messaging", {}, kv={"state": "APP_STATE"})
        assert backend.kv() == {"state": "APP_STATE"}
        assert backend.kv_keys("state") == {}

    def test_kv_rich_stored(self):
        backend = NatsBackend(
            "messaging",
            {},
            kv={
                "api": {
                    "bucket": "my-bucket",
                    "keys": {"latest": "key.latest", "count": "key.count"},
                }
            },
        )
        assert backend.kv() == {"api": "my-bucket"}
        assert backend.kv_keys("api") == {"latest": "key.latest", "count": "key.count"}

    def test_kv_keys_missing_alias(self):
        backend = NatsBackend("messaging", {}, kv={"state": "APP_STATE"})
        assert backend.kv_keys("nonexistent") == {}

    def test_subjects_stored(self):
        backend = NatsBackend("messaging", {}, subjects={"time": "local.time-server"})
        assert backend.subjects() == {"time": "local.time-server"}

    def test_defaults_empty(self):
        backend = NatsBackend("messaging", {})
        assert backend.streams() == {}
        assert backend.kv() == {}
        assert backend.subjects() == {}

    def test_subjects_not_in_resource_names(self):
        backend = NatsBackend(
            "messaging",
            {},
            streams={"events": "EVENTS"},
            subjects={"time": "local.time-server"},
        )
        names = backend.resource_names()
        assert names == ["stream EVENTS"]
