import json
import setuptools

kwargs = json.loads(
    """
{
    "name": "jjrawlins-cdk-diff-pr-github-action",
    "version": "1.10.7",
    "description": "A GitHub Action that creates a CDK diff for a pull request.",
    "license": "Apache-2.0",
    "url": "https://jjrawlins@github.com/JaysonRawlins/cdk-diff-pr-github-action.git",
    "long_description_content_type": "text/markdown",
    "author": "Jayson Rawlins<JaysonJ.Rawlins@gmail.com>",
    "bdist_wheel": {
        "universal": true
    },
    "project_urls": {
        "Source": "https://jjrawlins@github.com/JaysonRawlins/cdk-diff-pr-github-action.git"
    },
    "package_dir": {
        "": "src"
    },
    "packages": [
        "jjrawlins_cdk_diff_pr_github_action",
        "jjrawlins_cdk_diff_pr_github_action._jsii"
    ],
    "package_data": {
        "jjrawlins_cdk_diff_pr_github_action._jsii": [
            "cdk-diff-pr-github-action@1.10.7.jsii.tgz"
        ],
        "jjrawlins_cdk_diff_pr_github_action": [
            "py.typed"
        ]
    },
    "python_requires": "~=3.9",
    "install_requires": [
        "aws-cdk-lib>=2.85.0, <3.0.0",
        "constructs>=10.0.5, <11.0.0",
        "jsii>=1.127.0, <2.0.0",
        "publication>=0.0.3",
        "typeguard==2.13.3"
    ],
    "classifiers": [
        "Intended Audience :: Developers",
        "Operating System :: OS Independent",
        "Programming Language :: JavaScript",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Typing :: Typed",
        "Development Status :: 4 - Beta",
        "License :: OSI Approved"
    ],
    "scripts": []
}
"""
)

with open("README.md", encoding="utf8") as fp:
    kwargs["long_description"] = fp.read()


setuptools.setup(**kwargs)
