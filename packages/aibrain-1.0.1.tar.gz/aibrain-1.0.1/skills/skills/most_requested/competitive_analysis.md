# Competitive Analysis

> Systematically evaluate competitors to inform strategy.

## When to Use
- Market positioning decisions
- "Compare us to X" / "Who are our competitors?"
- Feature gap analysis, pricing research

## Framework
```
## Competitive Analysis: [Your Product] vs [Market]

### Landscape Overview
| Competitor | Category | Pricing | Key Strength | Key Weakness |
|-----------|----------|---------|-------------|-------------|

### Feature Comparison Matrix
| Feature | Us | Competitor A | Competitor B | Competitor C |
|---------|----|-----------|-----------|-----------| 

### Positioning Map
[Plot competitors on 2 axes that matter to your market]
X-axis: [e.g., Ease of use → Technical depth]
Y-axis: [e.g., Free → Enterprise pricing]

### Their Customers Say (review mining)
[Top 3 complaints about each competitor from G2/Reddit/HN]

### Our Differentiation
[1-2 sentences: why would someone choose us over each competitor?]

### Risks
[Where are competitors stronger? What could they ship that erodes our position?]
```

## Sources
- Product websites and pricing pages
- G2, Capterra, TrustPilot reviews
- Reddit discussions, HN threads
- Job postings (reveal tech stack and priorities)
- GitHub repos (if open source — stars, issues, commit frequency)
