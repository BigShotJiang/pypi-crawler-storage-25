# Meeting Notes & Summarization

> Transform meeting transcripts or notes into actionable summaries.

## When to Use
- "Summarize this meeting"
- Post-meeting action item extraction
- Converting raw notes to structured summary

## Output Structure
```
## Meeting: [Title]
**Date:** [Date] | **Duration:** [Duration] | **Attendees:** [Names]

### Key Decisions
1. [Decision with context]
2. [Decision with context]

### Action Items
| Owner | Action | Deadline |
|-------|--------|----------|
| [Name] | [Specific task] | [Date] |

### Discussion Summary
[3-5 sentences capturing the main topics and conclusions]

### Open Questions
- [Unresolved items that need follow-up]

### Next Meeting
[Date/time if scheduled, or "TBD"]
```

## Principles
- Decisions and action items FIRST — that's what people need
- Attribute every action item to a specific person
- Every action item has a deadline (even if it's "by next meeting")
- Keep discussion summary to essentials — if people wanted full detail, they'd watch the recording
