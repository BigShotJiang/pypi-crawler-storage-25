# Resume / CV Optimization

> Craft a targeted, achievement-focused resume.

## When to Use
- Job application preparation
- "Review my resume" / "Optimize for X role"

## Principles
1. **Achievements, not responsibilities** — "Reduced deploy time by 60%" not "Responsible for deployments"
2. **Quantify everything** — numbers, percentages, dollar amounts, time saved
3. **Tailor to the job posting** — mirror their language, prioritize relevant experience
4. **One page unless 10+ years experience** — ruthlessly cut the least relevant items
5. **No objectives/summaries** — replace with a skills section or key achievements header
6. **Consistent format** — same date format, same verb tense, same structure throughout

## Achievement Formula
```
[Action verb] + [what you did] + [quantified result] + [context/scope]

"Implemented automated testing pipeline reducing deployment failures by 73% across 12 microservices"
"Designed and shipped memory retrieval system achieving SOTA on 5/8 benchmarks using 22MB model"
```

## Action Verbs by Category
- Built: architected, designed, developed, engineered, implemented, created
- Improved: optimized, accelerated, reduced, streamlined, automated, enhanced
- Led: managed, coordinated, directed, mentored, spearheaded
- Analyzed: researched, evaluated, assessed, diagnosed, investigated
