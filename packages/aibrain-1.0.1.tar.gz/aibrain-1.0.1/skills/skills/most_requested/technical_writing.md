# Technical Writing

> Explain complex technical concepts clearly for a specific audience.

## When to Use
- Blog posts, tutorials, white papers
- Internal technical documents
- "Explain X" / "Write about Y"

## Approach
1. **Name your reader** — "a backend developer with 2 years experience" not "everyone"
2. **One idea per paragraph** — if a paragraph covers two ideas, split it
3. **Concrete before abstract** — show an example, THEN explain the principle
4. **Use analogies** — connect new concepts to things the reader already knows
5. **Active voice** — "the server processes the request" not "the request is processed"
6. **Short sentences for complex ideas** — complexity in the concept, not the grammar

## Structure for Tutorials
```
1. What you'll build (screenshot/result first)
2. Prerequisites (everything needed, no assumptions)
3. Step-by-step with code blocks
4. Explanation of WHY each step matters
5. Common errors and how to fix them
6. Next steps
```

## Common Mistakes
- Explaining what you know, not what the reader needs
- Assuming knowledge ("obviously, just use X" — nothing is obvious)
- No code examples — show, don't just tell
- Burying the lead — tell them the conclusion first, then the reasoning
