# Research Synthesis

> Combine multiple sources into a coherent, balanced analysis.

## When to Use
- "Research X and give me a summary"
- Comparing technologies, products, approaches
- Literature review, market analysis

## Approach
1. **Define the question clearly** — what specifically are we trying to learn?
2. **Identify source types** — primary (papers, docs) vs secondary (blogs, reviews)
3. **Look for consensus AND disagreement** — where do sources agree/disagree?
4. **Separate facts from opinions** — label which is which
5. **Identify gaps** — what don't the sources cover?
6. **Synthesize, don't summarize** — find the connections between sources

## Output Structure
```
## Research: [Question]

### Bottom Line (TL;DR)
[1-2 sentences: the answer, with confidence level]

### Key Findings
1. [Finding + source]
2. [Finding + source]

### Areas of Agreement
[What multiple sources confirm]

### Areas of Disagreement
[Where sources conflict + why they might differ]

### Gaps & Limitations
[What we still don't know]

### Recommendations
[Based on the evidence, what should we do?]

### Sources
[Numbered list with brief reliability note]
```
