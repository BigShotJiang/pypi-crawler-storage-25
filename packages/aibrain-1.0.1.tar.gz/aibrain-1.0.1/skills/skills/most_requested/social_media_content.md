# Social Media Content Creation

> Create platform-appropriate content that engages and converts.

## When to Use
- "Write a post about X for LinkedIn/Twitter/etc"
- Content calendar creation
- Repurposing content across platforms

## Platform Rules
**LinkedIn:** Professional insight, 1200-1500 chars, open with a bold statement, use line breaks liberally, end with a question or CTA, 3-5 hashtags
**X/Twitter:** Hook in first line, 280 chars max per tweet, threads for depth (7 max), visual or data point in tweet 1
**Reddit:** Value first, never promotional in tone, match the subreddit culture, include technical depth
**TikTok/Reels:** Hook in 3 seconds, problem→solution in 30-60 sec, caption is secondary to audio/visual
**Medium:** 1500-2500 words, clear structure with headers, code blocks for technical, submit to publications

## Hook Formulas
- "Here's a number that should concern you: [stat]"
- "I spent [time] doing [thing]. Here's what I learned."
- "Everyone says [common belief]. They're wrong."
- "[Specific result]. Here's how."
- "The problem nobody talks about: [problem]"

## Common Mistakes
- Same content copy-pasted across platforms — each has different norms
- Leading with the product — lead with the insight, product is the CTA
- No visual — posts with images/videos get 2-3x engagement
- Posting and ghosting — engage with comments for at least 2 hours after posting
