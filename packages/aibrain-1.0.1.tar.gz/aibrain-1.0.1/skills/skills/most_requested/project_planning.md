# Project Planning

> Break down projects into actionable phases, milestones, and tasks.

## When to Use
- Starting a new project
- "Help me plan X"
- Sprint planning, roadmap creation

## Approach
1. **Define the outcome** — what does "done" look like? Be specific.
2. **Work backwards** — from deadline to today, what has to happen when?
3. **Break into phases** — each phase has a deliverable and a demo-able outcome
4. **Estimate honestly** — then multiply by 1.5 (planning fallacy is real)
5. **Identify dependencies** — what blocks what?
6. **Identify risks** — what could go wrong? what's the mitigation?
7. **Define the MVP** — what's the smallest version that delivers value?

## Output Structure
```
## Project: [Name]
**Goal:** [One sentence]
**Deadline:** [Date]
**MVP by:** [Earlier date]

### Phase 1: [Name] — [Date range]
- [ ] Task 1 (estimate: X hours) [dependency: none]
- [ ] Task 2 (estimate: X hours) [dependency: Task 1]
**Deliverable:** [What's demo-able at end of phase]

### Risks
| Risk | Probability | Impact | Mitigation |
|------|------------|--------|------------|
| [Risk] | High/Med/Low | High/Med/Low | [Plan] |

### Out of Scope
[Explicitly list what this project does NOT include]
```
