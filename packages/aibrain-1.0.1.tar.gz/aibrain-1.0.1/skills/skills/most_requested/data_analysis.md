# Data Analysis

> Extract insights from datasets and present findings clearly.

## When to Use
- "Analyze this data"
- CSV/JSON/database exploration
- Trend identification, anomaly detection

## Approach
1. **Understand the data first** — shape, types, missing values, distributions
2. **Ask "so what?"** — every finding should answer "why does this matter?"
3. **Start broad, then narrow** — overview → interesting patterns → specific insights
4. **Quantify everything** — "sales increased" → "sales increased 23% MoM"
5. **Check for confounders** — correlation ≠ causation
6. **Visualize for clarity** — tables for precision, charts for patterns

## Analysis Checklist
- [ ] Data shape: rows, columns, types
- [ ] Missing values: count, pattern (random or systematic?)
- [ ] Distributions: normal? skewed? outliers?
- [ ] Correlations: what moves together?
- [ ] Time trends: increasing? decreasing? seasonal?
- [ ] Segments: do different groups behave differently?
- [ ] Anomalies: any data points that don't fit?

## Common Mistakes
- Presenting raw data instead of insights
- Cherry-picking metrics that support a conclusion
- Ignoring sample size ("100% conversion rate" on 2 visits)
- Not stating assumptions and limitations
