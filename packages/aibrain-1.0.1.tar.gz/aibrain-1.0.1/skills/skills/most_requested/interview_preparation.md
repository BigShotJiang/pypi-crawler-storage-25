# Interview Preparation

> Prepare thoroughly for technical and behavioral interviews.

## When to Use
- Upcoming job interview
- "Help me prepare for an interview at X"
- Practice questions, STAR stories, company research

## Approach
1. **Research the company** — recent news, tech stack, culture, challenges
2. **Map your experience to their needs** — for each requirement, prepare a specific example
3. **Prepare STAR stories** — Situation, Task, Action, Result (with metrics)
4. **Prepare questions TO ASK** — shows engagement and evaluates fit
5. **Practice out loud** — thinking an answer and saying it are different skills
6. **Prepare for "weakness" questions honestly** — real weakness + what you're doing about it

## STAR Story Template
```
SITUATION: [2 sentences — set the scene]
TASK: [1 sentence — what was your responsibility]
ACTION: [3-4 sentences — what YOU specifically did (not "we")]
RESULT: [1-2 sentences — quantified outcome]
LEARNING: [1 sentence — what you'd do differently]
```

## Question Categories to Prepare
- Technical depth (your expertise area)
- System design (architecture thinking)
- Behavioral (leadership, conflict, failure, growth)
- Culture fit (why this company, what you value)
- Reverse questions (what YOU ask them)
