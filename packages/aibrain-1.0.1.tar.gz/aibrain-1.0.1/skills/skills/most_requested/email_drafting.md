# Email Drafting

> Write clear, professional, action-oriented emails.

## When to Use
- Any email composition request
- "Draft an email to X about Y"
- Follow-ups, introductions, proposals, requests

## Approach
1. **Subject line = action required + topic** — "Review needed: Q2 security report" not "Report"
2. **First sentence = the ask** — don't bury the point in paragraph 3
3. **One email, one topic** — if you have two things, send two emails
4. **Scannable structure** — short paragraphs, bullet points for multiple items
5. **Clear next step** — what do you want the recipient to DO?
6. **Match their tone** — formal to formal, casual to casual, never more casual than them

## Template
```
Subject: [Action] — [Topic] [Deadline if applicable]

Hi [Name],

[One sentence: what you need from them]

[2-3 sentences: context they need to take that action]

[If multiple items, use bullets:]
- Item 1
- Item 2
- Item 3

[Clear next step with deadline:]
Could you [specific action] by [date]?

[Warm close],
[Your name]
```

## Common Mistakes
- No clear ask — if the recipient doesn't know what to do next, the email failed
- Too long — if it's more than a screen, it won't be read fully
- Passive-aggressive tone — say what you mean directly
- Reply-all when unnecessary — ask "does everyone need to see this?"
