# Migration Planning

> Plan and execute system migrations with minimal downtime and risk.

## When to Use
- Database migration, cloud migration, framework upgrade
- "We need to move from X to Y"
- Major version upgrades

## Migration Phases
1. **Assessment** — current state inventory, dependency mapping, risk identification
2. **Planning** — migration strategy, rollback plan, success criteria, timeline
3. **Preparation** — build tooling, write migration scripts, set up monitoring
4. **Execution** — run migration (ideally automated), monitor closely
5. **Validation** — verify all data, test all functionality, check performance
6. **Cutover** — switch traffic, decommission old system
7. **Post-migration** — monitor for 7 days, document lessons

## Migration Strategy Options
- **Big Bang** — migrate everything at once (fastest, highest risk)
- **Strangler Fig** — gradually replace components (safest, slowest)
- **Blue-Green** — run both systems, switch traffic (requires 2x resources)
- **Feature Flags** — migrate per-feature behind flags (flexible, complex)

## Rollback Plan (REQUIRED)
Every migration MUST have a rollback plan that can be executed in under 30 minutes. Test the rollback before you execute the migration.

## Checklist
- [ ] Rollback plan written and tested
- [ ] Success criteria defined (how do we know it worked?)
- [ ] Monitoring alerts configured for post-migration
- [ ] Communication plan for stakeholders
- [ ] Maintenance window scheduled if needed
- [ ] Data backup taken immediately before migration
