# Retrospective Analysis

> Facilitate productive team retrospectives that lead to real improvements.

## When to Use
- Sprint/project retrospective
- Post-incident review
- "What did we learn?"

## Framework: Start/Stop/Continue + Actions
```
### What should we START doing?
[New practices, tools, or habits]

### What should we STOP doing?
[Things that waste time, cause friction, or aren't working]

### What should we CONTINUE doing?
[Things that are working — reinforce the positive]

### Top 3 Action Items
| Action | Owner | Deadline | Success Metric |
|--------|-------|----------|---------------|
```

## Facilitation Principles
- **Blameless** — focus on systems and processes, not individuals
- **Specific** — "our deploys are slow" → "deploys take 45 min because of X"
- **Actionable** — every insight becomes an action item or it's just venting
- **Time-boxed** — 60 minutes maximum, strict facilitation
- **Follow up** — review last retro's action items FIRST
