# Onboarding Guide Creation

> Create comprehensive onboarding documentation for new team members.

## When to Use
- New hire joining the team
- "Create an onboarding guide for a new [role]"
- Team documentation refresh

## Onboarding Guide Structure
```
# Welcome to [Team/Project]

## Day 1: Get Set Up
- [ ] Accounts to create (with links)
- [ ] Tools to install (with versions)
- [ ] Repos to clone (with setup commands)
- [ ] Run the project locally (exact steps)
- [ ] People to meet (name, role, how to reach them)

## Week 1: Understand the System
- [ ] Architecture overview (link to diagram)
- [ ] Key ADRs to read (link to top 5)
- [ ] Codebase walkthrough (which files matter most)
- [ ] Deploy pipeline (how code gets to production)
- [ ] Monitoring (how to check if things are working)

## Week 2: First Contribution
- [ ] Starter issues tagged "good first issue"
- [ ] How to create a PR (branch naming, review process)
- [ ] How to deploy (and how to rollback)
- [ ] Who to ask for help (and when to escalate)

## Ongoing Reference
- Team rituals (standups, retros, demos — when/where)
- Communication norms (Slack channels, email vs chat, response expectations)
- On-call rotation (schedule, escalation, runbook locations)
- Glossary (project-specific terms and acronyms)
```

## Principles
- Test the guide with a real new hire — if they get stuck, the guide is wrong
- Keep it in one place — a scattered onboarding is worse than none
- Update quarterly — stale onboarding wastes everyone's time
