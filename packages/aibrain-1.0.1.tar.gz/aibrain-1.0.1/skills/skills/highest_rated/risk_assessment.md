# Risk Assessment

> Identify, analyze, and prioritize risks to projects, products, or operations.

## When to Use
- Project kickoff
- Major decision points
- "What could go wrong?"

## Risk Matrix
| Probability → | Low | Medium | High |
|--------------|-----|--------|------|
| **Impact: High** | Medium risk | High risk | Critical risk |
| **Impact: Medium** | Low risk | Medium risk | High risk |
| **Impact: Low** | Negligible | Low risk | Medium risk |

## Risk Register Template
| ID | Risk | Probability | Impact | Risk Level | Mitigation | Owner | Status |
|----|------|-----------|--------|-----------|------------|-------|--------|
| R-001 | Key developer leaves | Medium | High | High | Document everything, cross-train | Lead | Active |
| R-002 | API rate limit exceeded | High | Medium | High | Implement caching + backoff | Backend | Mitigated |

## Risk Response Strategies
- **Avoid** — eliminate the risk by changing the plan
- **Mitigate** — reduce probability or impact
- **Transfer** — insurance, contracts, SLAs
- **Accept** — acknowledge and monitor (with justification)
