# Release Notes

> Write clear, useful release notes that users actually read.

## When to Use
- Software release, feature launch, update announcement
- "Write release notes for v0.9.0"

## Structure
```
# aibrain v0.9.0 — [Codename or Theme]
**Released:** [Date]

## Highlights
[1-2 sentences: the most important thing in this release]

## New Features
- **[Feature name]** — [what it does in one sentence] ([link to docs])

## Improvements
- [Specific improvement with measurable impact]

## Bug Fixes
- Fixed: [issue description] (#[issue number])

## Breaking Changes
- [What changed, what to do about it, link to migration guide]

## Known Issues
- [Issue] — workaround: [workaround]

## Upgrade Guide
[Steps to upgrade from previous version]
```

## Principles
- Lead with what users GAIN, not what you built
- Link to documentation for every new feature
- Breaking changes get their own prominent section
- Include upgrade steps, not just "pip install --upgrade"
