# Troubleshooting Guide Creation

> Create systematic troubleshooting guides that resolve issues efficiently.

## When to Use
- Documenting common support issues
- Runbook creation for operations
- "Help me troubleshoot X"

## Troubleshooting Entry Template
```
## Problem: [Exact symptom the user sees]

### Quick Check
[The one thing that fixes it 80% of the time]

### Diagnostic Steps
1. Check [specific thing] — expected: [value], if different: [meaning]
2. Run [specific command] — look for [specific output]
3. Verify [specific condition]

### Common Causes
| Cause | How to Identify | Fix |
|-------|----------------|-----|
| [Cause A] | [Diagnostic] | [Exact fix steps] |
| [Cause B] | [Diagnostic] | [Exact fix steps] |

### If Nothing Works
[Escalation path: who to contact, what information to include]
```

## Principles
- Start with the most common cause, not the most interesting
- Every diagnostic step must be copy-pasteable
- Include expected output — "you should see X"
- Always end with an escalation path
