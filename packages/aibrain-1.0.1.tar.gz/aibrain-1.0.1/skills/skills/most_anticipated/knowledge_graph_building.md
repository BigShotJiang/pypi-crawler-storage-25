# Knowledge Graph Building

> Extract entities and relationships from text to build structured knowledge graphs.

## When to Use
- "Build a knowledge graph from this data"
- Entity relationship extraction
- Connecting information across documents

## Approach
1. **Entity extraction** — identify nouns (people, orgs, technologies, concepts)
2. **Relationship extraction** — how do entities connect? (uses, built_by, depends_on)
3. **Deduplication** — "Python" and "Python 3.11" refer to the same entity
4. **Confidence scoring** — how certain is each relationship?
5. **Temporal awareness** — relationships change over time (worked_at has a timespan)

## Entity Types
- Person, Organization, Technology, Product, Location, Event, Concept

## Relationship Types
- uses, built_by, depends_on, part_of, works_at, located_in
- related_to, preceded_by, alternative_to, integrates_with

## Graph Schema
```
Node: {id, name, type, properties, first_seen, last_seen}
Edge: {source_id, target_id, relationship, confidence, valid_from, valid_to}
```

## Output Format
```
ENTITIES:
- [Python] (Technology) — programming language
- [Django] (Technology) — web framework
- [Simon Willison] (Person) — co-creator of Django

RELATIONSHIPS:
- Simon Willison --created--> Django (confidence: 0.95)
- Django --built_with--> Python (confidence: 0.99)
```
