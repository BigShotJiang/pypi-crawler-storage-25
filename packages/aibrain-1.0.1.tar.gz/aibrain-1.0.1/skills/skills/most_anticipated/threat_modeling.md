# Threat Modeling

> Identify and prioritize threats to a system before they're exploited.

## When to Use
- New system design
- Major feature additions
- "What could go wrong with this architecture?"

## STRIDE Framework
- **S**poofing — can an attacker impersonate a user or service?
- **T**ampering — can data be modified in transit or at rest?
- **R**epudiation — can actions be denied (no audit trail)?
- **I**nformation Disclosure — can sensitive data leak?
- **D**enial of Service — can the system be made unavailable?
- **E**levation of Privilege — can a low-privilege user gain admin access?

## Process
1. **Draw the data flow diagram** — users, services, data stores, trust boundaries
2. **Identify entry points** — every place external input enters the system
3. **Apply STRIDE to each component** — systematically check all 6 categories
4. **Rate risks** — likelihood × impact
5. **Propose mitigations** — for each high-risk threat, specific countermeasure
6. **Document accepted risks** — risks you choose not to mitigate (with justification)

## Threat Entry Template
| Threat | STRIDE | Component | Likelihood | Impact | Risk | Mitigation |
|--------|--------|-----------|-----------|--------|------|------------|
| Stolen JWT | Spoofing | Auth API | Medium | High | High | Short TTL + refresh tokens |
