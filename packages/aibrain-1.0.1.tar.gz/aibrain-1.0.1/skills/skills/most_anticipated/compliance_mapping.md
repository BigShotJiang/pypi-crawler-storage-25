# Compliance Framework Mapping

> Map security controls and findings to regulatory compliance frameworks.

## When to Use
- Audit preparation
- Security findings to compliance report
- "Map this to PCI-DSS / NIST / ISO 27001"

## Supported Frameworks
- **PCI-DSS 4.0** — payment card security
- **NIST 800-53** — federal information systems
- **ISO 27001** — information security management
- **Essential Eight** — Australian Signals Directorate baseline
- **SOC 2** — service organization controls
- **OWASP Top 10** — web application security
- **CIS Controls v8** — prioritized security actions
- **GDPR** — EU data protection
- **HIPAA** — US healthcare data

## Mapping Approach
1. Identify the finding (vulnerability, misconfiguration, gap)
2. Determine which control(s) it violates in each relevant framework
3. Assess the compliance impact (fail, partial, informational)
4. Recommend the remediation that satisfies the MOST frameworks simultaneously
5. Prioritize by framework overlap — fix one thing, satisfy multiple auditors

## Output Format
| Finding | PCI-DSS | NIST | ISO 27001 | Essential Eight | Remediation |
|---------|---------|------|-----------|----------------|-------------|
| No MFA on admin | 8.3.1 | IA-2(1) | A.9.4.2 | Maturity Level 1 | Enforce MFA for all privileged access |
