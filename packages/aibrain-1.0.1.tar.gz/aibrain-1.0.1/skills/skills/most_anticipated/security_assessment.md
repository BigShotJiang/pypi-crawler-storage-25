# Security Vulnerability Assessment

> Systematic identification and classification of security vulnerabilities in code and systems.

## When to Use
- Code security review
- "Check this for security issues"
- Pre-deployment security scan

## Approach
1. **Map the attack surface** — endpoints, inputs, auth boundaries, data flows
2. **Check OWASP Top 10** systematically — injection, broken auth, sensitive data exposure, XXE, broken access control, misconfiguration, XSS, insecure deserialization, using components with known vulns, insufficient logging
3. **Trace data flows** — follow user input from entry to storage/output — where is it sanitized?
4. **Check auth at every boundary** — not just the front door, every internal service call
5. **Look for secrets** — hardcoded API keys, credentials in config, tokens in logs
6. **Check dependencies** — known CVEs in your dependency tree

## Vulnerability Report Format
| ID | Severity | Category | Location | Description | Remediation | CVSS |
|----|----------|----------|----------|-------------|-------------|------|
| V-001 | Critical | SQLi | api.py:45 | String interpolation in SQL query | Use parameterized queries | 9.8 |

## Severity Classification
- **Critical (CVSS 9.0-10.0):** Remote code execution, auth bypass, data exfiltration
- **High (7.0-8.9):** Privilege escalation, stored XSS, SSRF
- **Medium (4.0-6.9):** Reflected XSS, CSRF, information disclosure
- **Low (0.1-3.9):** Missing headers, verbose errors, minor misconfig

## Common Missed Vulnerabilities
- IDOR (Insecure Direct Object Reference) — can user A access user B's data by changing an ID?
- Race conditions — what happens with concurrent requests to the same resource?
- JWT issues — algorithm confusion, missing expiry, weak secret
- SSRF — can the server be tricked into making requests to internal services?
