# Autonomous Research Agent

> Conduct multi-step research with source verification and synthesis.

## When to Use
- Complex research questions requiring multiple sources
- "Research everything about X"
- Due diligence, market research, technical investigation

## Research Protocol
1. **Decompose the question** — break into 3-5 sub-questions
2. **Search systematically** — different queries for different sub-questions
3. **Verify claims** — cross-reference across at least 2 sources
4. **Track provenance** — every fact links back to its source
5. **Identify contradictions** — flag where sources disagree
6. **Synthesize** — connect findings into coherent narrative
7. **Assess confidence** — high/medium/low for each finding

## Source Reliability Hierarchy
1. Primary sources (official docs, peer-reviewed papers, company announcements)
2. Authoritative secondary (established journalists, recognized experts)
3. Community sources (Reddit, HN — useful for sentiment, not facts)
4. AI-generated content (verify everything, trust nothing)

## Output Format
```
## Research: [Question]
**Confidence:** [High/Medium/Low]
**Sources consulted:** [N]
**Time span of sources:** [Date range]

### Findings
[Numbered findings with inline source citations]

### Confidence Assessment
| Finding | Confidence | Sources | Notes |
|---------|-----------|---------|-------|

### What We Don't Know
[Explicit gaps in the research]
```
