# Prompt Engineering

> Design effective prompts for LLMs that produce reliable, high-quality outputs.

## When to Use
- Building LLM-powered features
- "Write a prompt for X"
- Optimizing existing prompts

## Core Principles
1. **Be specific about the output format** — "Return JSON with keys: name, score, reason"
2. **Provide examples** — 2-3 input/output examples dramatically improve consistency
3. **Think step by step** — for complex tasks, instruct the model to reason before answering
4. **Separate instructions from data** — use delimiters (XML tags, markdown headers)
5. **Constrain the output** — enums, max length, required fields
6. **Test with adversarial inputs** — what happens with edge cases?

## Prompt Structure
```
<role>You are a [specific role] with expertise in [domain].</role>

<task>
[Clear description of what to do]
</task>

<constraints>
- Output format: [specify exactly]
- Tone: [specify]
- Length: [specify]
- Must include: [specify]
- Must NOT include: [specify]
</constraints>

<examples>
Input: [example]
Output: [example]
</examples>

<input>
[The actual content to process]
</input>
```

## Common Mistakes
- Vague instructions ("make it better" — better how?)
- No output format specification — the model guesses
- No examples — the model interprets your intent differently than you meant
- Prompt too long — dilutes the important instructions
