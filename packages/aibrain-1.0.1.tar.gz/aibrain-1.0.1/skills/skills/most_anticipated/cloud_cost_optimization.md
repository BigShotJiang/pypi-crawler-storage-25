# Cloud Cost Optimization

> Reduce cloud infrastructure costs without sacrificing performance.

## When to Use
- Monthly cloud bill review
- "Why is our AWS/GCP/Azure bill so high?"
- Infrastructure right-sizing

## Cost Reduction Checklist
- [ ] **Unused resources** — stopped instances still paying for storage, unattached EBS volumes, idle load balancers
- [ ] **Right-sizing** — are instances over-provisioned? Check CPU/memory utilization
- [ ] **Reserved/spot instances** — predictable workloads should use reserved pricing (40-60% savings)
- [ ] **Storage tiering** — move infrequently accessed data to cheaper tiers (S3 Glacier, Cool Storage)
- [ ] **Database optimization** — read replicas vs bigger instance, serverless vs provisioned
- [ ] **Network costs** — cross-region data transfer adds up; colocate services
- [ ] **Auto-scaling** — scale down during off-peak, don't pay for idle capacity
- [ ] **Orphaned resources** — snapshots, AMIs, old container images, unused Elastic IPs

## Quick Wins (usually 20-40% savings)
1. Delete unused resources (storage, IPs, load balancers)
2. Schedule dev/staging environments to shut down nights/weekends
3. Switch to spot instances for fault-tolerant workloads
4. Enable S3 lifecycle policies for log buckets
5. Right-size the top 5 most expensive instances
