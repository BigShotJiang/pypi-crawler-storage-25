# Incident Response

> Structured approach to handling security incidents and system outages.

## When to Use
- System is down or compromised
- Security breach detected
- "We're having an incident"

## Incident Response Flow
1. **Detect & Classify** — what's happening? severity? blast radius?
2. **Contain** — stop the bleeding without destroying evidence
3. **Communicate** — notify stakeholders with facts, not speculation
4. **Investigate** — what happened, when, how, what was affected
5. **Remediate** — fix the root cause, not just the symptom
6. **Recover** — restore normal operations
7. **Review** — blameless postmortem within 48 hours

## Severity Levels
| Level | Definition | Response Time | Escalation |
|-------|-----------|--------------|-----------|
| SEV-1 | Service down, data breach, active attack | Immediate | Everyone |
| SEV-2 | Degraded service, potential breach | < 1 hour | On-call + lead |
| SEV-3 | Minor issue, no user impact | < 4 hours | On-call |
| SEV-4 | Cosmetic, informational | Next business day | Ticket |

## Postmortem Template
```
## Incident: [Title]
**Severity:** [SEV-1/2/3/4]
**Duration:** [Start time] → [Resolution time]
**Impact:** [Who/what was affected, quantified]

### Timeline
[Timestamp] — [Event]

### Root Cause
[Technical explanation]

### What Went Well
- [List]

### What Went Poorly
- [List]

### Action Items
| Action | Owner | Deadline |
|--------|-------|----------|

### Lessons Learned
[What do we know now that we didn't before?]
```
