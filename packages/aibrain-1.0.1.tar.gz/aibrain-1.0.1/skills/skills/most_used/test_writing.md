# Test Writing

> Write effective, maintainable tests that catch real bugs.

## When to Use
- New feature development (write tests first or alongside)
- Bug fixes (write a failing test before fixing)
- "Write tests for X"

## Approach
1. **Test behavior, not implementation** — test what the function does, not how
2. **One assertion per concept** — test one thing per test function
3. **Name tests as sentences** — `test_user_cannot_login_with_wrong_password`
4. **Arrange-Act-Assert pattern** — setup, execute, verify
5. **Test the edges** — empty input, null, max values, concurrent access
6. **Test the error paths** — what happens when things go wrong?

## Test Structure
```python
def test_memory_search_returns_relevant_results():
    # Arrange
    db = create_test_db()
    store_memory(db, "user prefers dark mode", type="preference")
    store_memory(db, "project uses Python 3.11", type="project")

    # Act
    results = search(db, "dark mode")

    # Assert
    assert len(results) >= 1
    assert "dark mode" in results[0]["content"].lower()
```

## Test Categories
- **Unit tests:** single function, mocked dependencies, fast
- **Integration tests:** multiple components, real database, medium speed
- **Smoke tests:** full system, real endpoints, slow but critical
- **Edge case tests:** boundary values, empty inputs, malformed data

## Common Mistakes
- Testing only the happy path — bugs live in the unhappy paths
- Tests that depend on each other — each test must be independent
- Tests that test the mock, not the code — if you mock everything, you test nothing
- Brittle tests that break when implementation changes but behavior doesn't
