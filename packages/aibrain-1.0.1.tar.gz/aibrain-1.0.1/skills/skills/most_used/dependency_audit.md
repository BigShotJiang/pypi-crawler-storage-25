# Dependency Audit

> Review project dependencies for security, licensing, and maintenance risks.

## When to Use
- Regular security review (monthly recommended)
- Before shipping a release
- "Check our dependencies" / "audit packages"

## Approach
1. **List all dependencies** — direct AND transitive
2. **Check for known vulnerabilities** — `pip audit`, `npm audit`, `cargo audit`
3. **Check maintenance status** — last commit date, open issues, bus factor
4. **Check license compatibility** — GPL dependencies in MIT projects = problem
5. **Check for outdated versions** — security patches in newer versions?
6. **Assess necessity** — do you really need this dependency or can you inline 20 lines?

## Red Flags
- Dependency with no commits in 2+ years
- Single maintainer with no succession plan
- Vulnerability with no patch available
- License incompatible with your project
- Dependency that pulls in 50+ transitive dependencies for one function

## Output Format
| Package | Version | Latest | Vulnerabilities | Last Updated | License | Risk |
|---------|---------|--------|----------------|-------------|---------|------|
| requests | 2.31.0 | 2.32.0 | None | 2024-05 | Apache-2.0 | Low |
