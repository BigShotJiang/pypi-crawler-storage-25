# Git Commit Messages

> Write clear, consistent, informative commit messages.

## When to Use
- Any git commit
- "Write a commit message for this change"

## Format
```
<type>(<scope>): <subject>

<body>

<footer>
```

**Types:** feat, fix, refactor, docs, test, chore, perf, style, ci, build
**Scope:** module or area affected (optional)
**Subject:** imperative mood, lowercase, no period, < 72 chars
**Body:** what and WHY (not how — the diff shows how), wrap at 72 chars
**Footer:** BREAKING CHANGE:, Fixes #123, Refs #456

## Examples
```
feat(memory): add passage-level chunking for long memories

Long memories (>5 lines) are now split into overlapping passages
with role-based weighting. User turns get 2x weight. This improves
retrieval accuracy for queries targeting specific parts of a
conversation.

Refs #42
```

```
fix(auth): prevent timing attack on API key comparison

Replace == with hmac.compare_digest for constant-time comparison.
Previous implementation leaked key length via response timing.

BREAKING CHANGE: None
Fixes #87
```

## Common Mistakes
- "fixed stuff" / "updates" / "WIP" — meaningless to future readers
- Describing WHAT changed (the diff does that) instead of WHY
- Mixing multiple changes in one commit — one logical change per commit
