# Bug Debugging

> Systematic diagnosis and resolution of software defects.

## When to Use
- "This isn't working" / "I have a bug"
- Error messages, stack traces, unexpected behavior
- Regression investigation

## Approach
1. **Reproduce first** — confirm the bug exists and get exact reproduction steps
2. **Read the error message carefully** — the answer is often in the traceback
3. **Identify what changed** — recent commits, dependency updates, config changes
4. **Narrow the scope** — binary search: is the bug in the input, the processing, or the output?
5. **Check assumptions** — print/log the actual values at each step, don't assume
6. **Look for the second bug** — the fix for the first bug often reveals a second
7. **Write a test that fails** — before fixing, write a test that reproduces the bug

## Debugging Checklist
- [ ] Can I reproduce it consistently?
- [ ] What's the exact error message/unexpected behavior?
- [ ] When did it last work correctly?
- [ ] What changed between then and now?
- [ ] Is this environment-specific (works locally, fails in prod)?
- [ ] Are there related issues in the issue tracker?

## Common Mistakes
- Fixing symptoms instead of root cause
- Changing multiple things at once — change one thing, test, repeat
- Not checking the logs — always check logs first
- Assuming the bug is in your code — it might be in a dependency, config, or environment
