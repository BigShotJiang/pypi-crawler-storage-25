"""Built-in guard implementations."""
