# GuardBench — Benchmark, Compare & Gate Your AI Safety Guards

[![CI](https://github.com/samvardani/GuardBench/actions/workflows/guardbench-eval.yml/badge.svg)](https://github.com/samvardani/GuardBench/actions/workflows/guardbench-eval.yml)
[![Python 3.9+](https://img.shields.io/badge/python-3.9%2B-blue.svg)](https://python.org)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

AI safety guards often ship without rigorous evaluation — developers don't know which guard performs better, how much it improves recall, or whether a new version regresses on edge-case categories. GuardBench solves this: it's an open-source evaluation framework that benchmarks any AI content-safety guard against labeled datasets, generates interactive HTML reports, and enforces CI gates so regressions never ship.

## Quick Start

```bash
pip install -e ".[dev]"
guardbench init
guardbench compare --baseline regex --candidate regex --dataset dataset/sample.jsonl
guardbench report --run latest --open
guardbench gate --config gate.json
```

## Architecture

```mermaid
graph LR
    DS[Dataset<br>CSV / JSONL] --> EV[Evaluator]
    EV --> BG[Baseline Guard]
    EV --> CG[Candidate Guard]
    BG --> M[Metrics<br>recall · FPR · F1 · latency]
    CG --> M
    M --> R[HTML Report]
    M --> G[CI Gate<br>exit 0 / 1]
    R --> S[(SQLite Store)]
    G --> S
```

## Plug in Any Guard

Implement the `Guard` ABC and call `register()`:

```python
from guardbench.core.guard import Guard, GuardResult
from guardbench.core.registry import register
import time

class MyGuard(Guard):
    name = "my_guard"
    version = "1.0.0"

    def predict(self, text: str, **meta) -> GuardResult:
        start = time.perf_counter()
        flagged = "bomb" in text.lower()
        return GuardResult(
            prediction="flag" if flagged else "pass",
            score=0.9 if flagged else 0.1,
            latency_ms=int((time.perf_counter() - start) * 1000),
        )

register("my_guard", MyGuard)
```

Then evaluate it:

```bash
guardbench compare \
  --baseline regex \
  --candidate my_package.guards.my_guard.MyGuard \
  --dataset dataset/sample.csv
```

## CI Integration

```yaml
# .github/workflows/guardbench.yml
- run: pip install -e ".[dev]"
- run: pytest tests/guardbench/ --cov=guardbench -q
- run: guardbench compare --baseline regex --candidate regex --dataset dataset/sample.csv
- run: guardbench report --run latest
- run: guardbench gate --config gate.json --run latest
```

## Gate Configuration (`gate.json`)

```json
{
  "mode": "strict",
  "global_thresholds": {
    "min_recall": 0.90,
    "max_fpr": 0.05,
    "max_latency_p99_ms": 500,
    "min_f1": 0.80
  },
  "slices": {
    "*/fa": { "min_recall": 0.75 }
  },
  "on_failure": "block"
}
```

## License & Contributing

MIT License. See [CONTRIBUTING.md](CONTRIBUTING.md) for contribution guidelines.
