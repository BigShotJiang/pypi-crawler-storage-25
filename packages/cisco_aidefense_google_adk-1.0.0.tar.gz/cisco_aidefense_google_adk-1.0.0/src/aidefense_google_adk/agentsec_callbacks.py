# Copyright 2026 Cisco Systems, Inc. and its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# SPDX-License-Identifier: Apache-2.0

"""
Standalone callback factories using agentsec Inspectors for agent-level
(Tier 1) integration.

Use these when you want per-agent AI Defense inspection backed by the
higher-level ``LLMInspector`` / ``MCPInspector`` from the agentsec SDK,
which add retry, fail-open semantics, and structured ``Decision`` objects.

Usage::

    from aidefense_google_adk import make_agentsec_callbacks

    cbs = make_agentsec_callbacks(mode="enforce")

    agent = LlmAgent(
        model="gemini-2.5-flash",
        name="my_agent",
        instruction="...",
        before_model_callback=cbs.before_model,
        after_model_callback=cbs.after_model,
        before_tool_callback=cbs.before_tool,
        after_tool_callback=cbs.after_tool,
    )
"""

from __future__ import annotations

import logging
import os
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any, Optional

from google.adk.agents.callback_context import CallbackContext
from google.adk.models.llm_request import LlmRequest
from google.adk.models.llm_response import LlmResponse
from google.adk.tools.base_tool import BaseTool
from google.adk.tools.tool_context import ToolContext
from google.genai import types

from aidefense.runtime.agentsec.inspectors import LLMInspector, MCPInspector

from ._helpers import extract_last_user_text, extract_model_text
from ._payload_builder import build_tool_block_payload

logger = logging.getLogger("aidefense_google_adk.agentsec")

_VALID_MODES = ("monitor", "enforce", "off")
_LLM_API_KEY_ENV = "AI_DEFENSE_API_MODE_LLM_API_KEY"
_MCP_API_KEY_ENV = "AI_DEFENSE_API_MODE_MCP_API_KEY"


@dataclass(frozen=True)
class AgentsecCallbacks:
    """Container for the four agent-level callback functions.

    Each attribute is an ``async def`` that matches the corresponding
    ADK callback signature and can be passed directly to ``LlmAgent``.

    Use :meth:`apply_to` to wire all four callbacks onto an agent in
    one call instead of assigning each field manually.

    Call :meth:`close` when the callbacks are no longer needed to release
    resources held by the underlying inspectors.
    """

    before_model: Callable[..., Awaitable[Optional[Any]]]
    after_model: Callable[..., Awaitable[Optional[Any]]]
    before_tool: Callable[..., Awaitable[Optional[dict[str, Any]]]]
    after_tool: Callable[..., Awaitable[Optional[dict[str, Any]]]]
    _close_fn: Optional[Callable[[], None]] = None

    def apply_to(self, agent: Any) -> None:
        """Attach all four callbacks to *agent*.

        Equivalent to::

            agent.before_model_callback = cbs.before_model
            agent.after_model_callback  = cbs.after_model
            agent.before_tool_callback  = cbs.before_tool
            agent.after_tool_callback   = cbs.after_tool
        """
        agent.before_model_callback = self.before_model
        agent.after_model_callback = self.after_model
        agent.before_tool_callback = self.before_tool
        agent.after_tool_callback = self.after_tool

    def close(self) -> None:
        """Release resources held by the underlying inspectors."""
        if self._close_fn is not None:
            self._close_fn()


def make_agentsec_callbacks(
    *,
    mode: str = "monitor",
    llm_mode: Optional[str] = None,
    mcp_mode: Optional[str] = None,
    on_violation: Optional[Callable[[Any], None]] = None,
    api_key: Optional[str] = None,
    endpoint: Optional[str] = None,
    mcp_api_key: Optional[str] = None,
    mcp_endpoint: Optional[str] = None,
    fail_open: bool = True,
    timeout_ms: Optional[int] = None,
    retry_total: Optional[int] = None,
    retry_backoff: Optional[float] = None,
    default_rules: Optional[list[Any]] = None,
    entity_types: Optional[list[str]] = None,
    app_name: str = "google_adk",
) -> AgentsecCallbacks:
    """Create agent-level callbacks wired to agentsec Inspectors.

    Compared to ``make_aidefense_callbacks`` (which uses the lower-level
    ``ChatInspectionClient`` / ``MCPInspectionClient``), this variant adds
    retry with exponential backoff, structured ``Decision`` objects, and
    fail-open/fail-closed semantics.

    Args:
        mode: Default inspection mode (``"monitor"`` | ``"enforce"`` | ``"off"``).
        llm_mode: Override mode for LLM callbacks only.
        mcp_mode: Override mode for MCP/tool callbacks only.
        on_violation: Optional callback invoked on every violation.
            Receives a ``Decision`` object.
        api_key: Cisco AI Defense API key. If ``None``, resolved from env.
        endpoint: Base URL for AI Defense API. If ``None``, resolved from env.
        mcp_api_key: Separate API key for MCP inspection.
        mcp_endpoint: Separate endpoint for MCP inspection.
        fail_open: Allow requests when the AI Defense API is unreachable.
        timeout_ms: Request timeout in milliseconds.
        retry_total: Total retry attempts.
        retry_backoff: Exponential backoff factor in seconds.
        default_rules: Default rules for LLM inspection.
        entity_types: Entity types to filter for.
        app_name: Application name included in inspection metadata.

    Returns:
        An ``AgentsecCallbacks`` instance whose attributes can be
        assigned directly to ``LlmAgent`` callback fields.
    """
    for label, value in [("mode", mode), ("llm_mode", llm_mode), ("mcp_mode", mcp_mode)]:
        if value is not None and value not in _VALID_MODES:
            raise ValueError(
                f"{label} must be one of {_VALID_MODES!r}, got {value!r}"
            )

    effective_llm = llm_mode or mode
    effective_mcp = mcp_mode or mode

    if (
        api_key is None
        and not os.environ.get(_LLM_API_KEY_ENV)
        and effective_llm != "off"
    ):
        logger.warning(
            "No LLM API key found. Set the %s env var or pass "
            "api_key=... to enable LLM inspection.",
            _LLM_API_KEY_ENV,
        )
    resolved_mcp_key = mcp_api_key or api_key
    if (
        resolved_mcp_key is None
        and not os.environ.get(_MCP_API_KEY_ENV)
        and effective_mcp != "off"
    ):
        logger.warning(
            "No MCP API key found. Set the %s env var or pass "
            "mcp_api_key=... to enable tool inspection.",
            _MCP_API_KEY_ENV,
        )

    llm_inspector = None
    if effective_llm != "off":
        llm_kwargs: dict[str, Any] = {"fail_open": fail_open}
        if api_key is not None:
            llm_kwargs["api_key"] = api_key
        if endpoint is not None:
            llm_kwargs["endpoint"] = endpoint
        if timeout_ms is not None:
            llm_kwargs["timeout_ms"] = timeout_ms
        if retry_total is not None:
            llm_kwargs["retry_total"] = retry_total
        if retry_backoff is not None:
            llm_kwargs["retry_backoff"] = retry_backoff
        if default_rules is not None:
            llm_kwargs["default_rules"] = default_rules
        if entity_types is not None:
            llm_kwargs["entity_types"] = entity_types
        llm_inspector = LLMInspector(**llm_kwargs)

    mcp_inspector = None
    if effective_mcp != "off":
        mcp_kwargs: dict[str, Any] = {"fail_open": fail_open}
        if mcp_api_key is not None:
            mcp_kwargs["api_key"] = mcp_api_key
        elif api_key is not None:
            mcp_kwargs["api_key"] = api_key
        if mcp_endpoint is not None:
            mcp_kwargs["endpoint"] = mcp_endpoint
        elif endpoint is not None:
            mcp_kwargs["endpoint"] = endpoint
        if timeout_ms is not None:
            mcp_kwargs["timeout_ms"] = timeout_ms
        if retry_total is not None:
            mcp_kwargs["retry_total"] = retry_total
        if retry_backoff is not None:
            mcp_kwargs["retry_backoff"] = retry_backoff
        mcp_inspector = MCPInspector(**mcp_kwargs)

    # ------------------------------------------------------------------
    # LLM callbacks
    # ------------------------------------------------------------------

    async def before_model(
        *,
        callback_context: CallbackContext,
        llm_request: LlmRequest,
    ) -> Optional[LlmResponse]:
        if effective_llm == "off":
            return None

        prompt_text = extract_last_user_text(llm_request.contents)
        if not prompt_text:
            return None

        messages = [{"role": "user", "content": prompt_text}]
        metadata = {"src_app": app_name}

        logger.debug("AI Defense: inspecting prompt (mode=%s)", effective_llm)
        try:
            decision = await llm_inspector.ainspect_conversation(messages, metadata)
        except Exception:
            logger.exception("AI Defense prompt inspection failed")
            if not fail_open and effective_llm == "enforce":
                return LlmResponse(
                    content=types.Content(
                        role="model",
                        parts=[types.Part(text="Request blocked: AI Defense inspection unavailable.")],
                    ),
                )
            return None
        logger.debug("AI Defense: prompt result (allows=%s, action=%s)", decision.allows(), decision.action)

        if not decision.allows():
            logger.warning(
                "AI Defense: prompt violation (action=%s, severity=%s, event_id=%s)",
                decision.action,
                decision.severity,
                decision.event_id,
            )
            if on_violation:
                try:
                    on_violation(decision)
                except Exception:
                    logger.debug("on_violation raised", exc_info=True)
            if effective_llm == "enforce":
                return LlmResponse(
                    content=types.Content(
                        role="model",
                        parts=[types.Part(text="Request blocked by Cisco AI Defense policy.")],
                    ),
                )
        return None

    async def after_model(
        *,
        callback_context: CallbackContext,
        llm_response: LlmResponse,
    ) -> Optional[LlmResponse]:
        if effective_llm == "off":
            return None

        response_text = extract_model_text(llm_response)
        if not response_text:
            return None

        messages = [
            {"role": "user", "content": "(prior turn)"},
            {"role": "assistant", "content": response_text},
        ]
        metadata = {"src_app": app_name}

        logger.debug("AI Defense: inspecting response (mode=%s)", effective_llm)
        try:
            decision = await llm_inspector.ainspect_conversation(messages, metadata)
        except Exception:
            logger.exception("AI Defense response inspection failed")
            if not fail_open and effective_llm == "enforce":
                return LlmResponse(
                    content=types.Content(
                        role="model",
                        parts=[types.Part(text="Response blocked: AI Defense inspection unavailable.")],
                    ),
                )
            return None
        logger.debug("AI Defense: response result (allows=%s, action=%s)", decision.allows(), decision.action)

        if not decision.allows():
            logger.warning(
                "AI Defense: response violation (action=%s, severity=%s, event_id=%s)",
                decision.action,
                decision.severity,
                decision.event_id,
            )
            if on_violation:
                try:
                    on_violation(decision)
                except Exception:
                    logger.debug("on_violation raised", exc_info=True)
            if effective_llm == "enforce":
                return LlmResponse(
                    content=types.Content(
                        role="model",
                        parts=[types.Part(text="Response blocked by Cisco AI Defense policy.")],
                    ),
                )
        return None

    # ------------------------------------------------------------------
    # Tool callbacks
    # ------------------------------------------------------------------

    async def before_tool(
        tool: BaseTool,
        tool_args: Optional[dict[str, Any]] = None,
        tool_context: Optional[ToolContext] = None,
        **kwargs: Any,
    ) -> Optional[dict]:
        args = tool_args if tool_args is not None else kwargs.pop("args", None)
        if args is None:
            args = {}
        if effective_mcp == "off":
            return None

        metadata = {"src_app": app_name}

        logger.debug("AI Defense: inspecting tool request (tool=%s, mode=%s)", tool.name, effective_mcp)
        try:
            decision = await mcp_inspector.ainspect_request(
                tool_name=tool.name,
                arguments=args,
                metadata=metadata,
                method="tools/call",
            )
        except Exception:
            logger.exception("AI Defense tool-request inspection failed (tool=%s)", tool.name)
            if not fail_open and effective_mcp == "enforce":
                return build_tool_block_payload(
                    tool_name=tool.name,
                    stage="tool_request",
                    inspection=None,
                    reason="AI Defense inspection unavailable",
                )
            return None
        logger.debug("AI Defense: tool request result (tool=%s, allows=%s)", tool.name, decision.allows())

        if not decision.allows():
            logger.warning(
                "AI Defense: tool-request violation (tool=%s, action=%s, severity=%s)",
                tool.name,
                decision.action,
                decision.severity,
            )
            if on_violation:
                try:
                    on_violation(decision)
                except Exception:
                    logger.debug("on_violation raised", exc_info=True)
            if effective_mcp == "enforce":
                return build_tool_block_payload(
                    tool_name=tool.name,
                    stage="tool_request",
                    inspection=decision,
                )
        return None

    async def after_tool(
        tool: BaseTool,
        tool_args: Optional[dict[str, Any]] = None,
        tool_context: Optional[ToolContext] = None,
        result: Optional[dict] = None,
        **kwargs: Any,
    ) -> Optional[dict]:
        args = tool_args if tool_args is not None else kwargs.pop("args", None)
        if args is None:
            args = {}
        tool_response = result if result is not None else kwargs.pop("tool_response", None)
        if tool_response is None:
            tool_response = {}
        if effective_mcp == "off":
            return None

        metadata = {"src_app": app_name}

        logger.debug("AI Defense: inspecting tool response (tool=%s, mode=%s)", tool.name, effective_mcp)
        try:
            decision = await mcp_inspector.ainspect_response(
                tool_name=tool.name,
                arguments=args,
                result=tool_response,
                metadata=metadata,
                method="tools/call",
            )
        except Exception:
            logger.exception("AI Defense tool-response inspection failed (tool=%s)", tool.name)
            if not fail_open and effective_mcp == "enforce":
                return build_tool_block_payload(
                    tool_name=tool.name,
                    stage="tool_response",
                    inspection=None,
                    reason="AI Defense inspection unavailable",
                )
            return None
        logger.debug("AI Defense: tool response result (tool=%s, allows=%s)", tool.name, decision.allows())

        if not decision.allows():
            logger.warning(
                "AI Defense: tool-response violation (tool=%s, action=%s, severity=%s)",
                tool.name,
                decision.action,
                decision.severity,
            )
            if on_violation:
                try:
                    on_violation(decision)
                except Exception:
                    logger.debug("on_violation raised", exc_info=True)
            if effective_mcp == "enforce":
                return build_tool_block_payload(
                    tool_name=tool.name,
                    stage="tool_response",
                    inspection=decision,
                )
        return None

    def _close() -> None:
        nonlocal llm_inspector, mcp_inspector
        for inspector in (llm_inspector, mcp_inspector):
            if inspector is not None and hasattr(inspector, "close"):
                try:
                    inspector.close()
                except Exception:
                    logger.debug("Error closing inspector", exc_info=True)
        llm_inspector = None
        mcp_inspector = None

    return AgentsecCallbacks(
        before_model=before_model,
        after_model=after_model,
        before_tool=before_tool,
        after_tool=after_tool,
        _close_fn=_close,
    )
