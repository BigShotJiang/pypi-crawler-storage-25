# Copyright 2026 Cisco Systems, Inc. and its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# SPDX-License-Identifier: Apache-2.0

"""Helpers to extract text from Google ADK request/response types."""

from __future__ import annotations

from typing import Optional

from google.genai import types

from google.adk.models.llm_response import LlmResponse


def extract_last_user_text(contents: Optional[list[types.Content]]) -> Optional[str]:
    """Extract the text of the most recent user message from a content list.

    Walks the content list in reverse to find the last entry with
    ``role="user"`` and concatenates its text parts.

    Args:
        contents: The ``LlmRequest.contents`` list of ``types.Content``.

    Returns:
        The concatenated user text, or ``None`` if no user text is found.
    """
    if not contents:
        return None
    for content in reversed(contents):
        if content.role != "user":
            continue
        if not content.parts:
            continue
        text_parts = [
            part.text for part in content.parts
            if hasattr(part, "text") and part.text
        ]
        if text_parts:
            return "\n".join(text_parts)
    return None


def extract_model_text(llm_response: Optional[LlmResponse]) -> Optional[str]:
    """Extract the model's text from an ``LlmResponse``.

    Args:
        llm_response: The ADK ``LlmResponse`` object.

    Returns:
        The concatenated model text, or ``None`` if no text is found.
    """
    if llm_response is None:
        return None
    if not llm_response.content or not llm_response.content.parts:
        return None
    text_parts = [
        part.text for part in llm_response.content.parts
        if hasattr(part, "text") and part.text
    ]
    return "\n".join(text_parts) if text_parts else None


def extract_all_user_text(contents: Optional[list[types.Content]]) -> Optional[str]:
    """Extract text from *all* user messages, preserving conversation order.

    Useful when the full conversation history should be inspected rather
    than just the latest turn.

    Args:
        contents: The ``LlmRequest.contents`` list.

    Returns:
        Newline-joined user messages, or ``None`` if none found.
    """
    if not contents:
        return None
    parts: list[str] = []
    for content in contents:
        if content.role != "user" or not content.parts:
            continue
        for part in content.parts:
            if hasattr(part, "text") and part.text:
                parts.append(part.text)
    return "\n".join(parts) if parts else None
