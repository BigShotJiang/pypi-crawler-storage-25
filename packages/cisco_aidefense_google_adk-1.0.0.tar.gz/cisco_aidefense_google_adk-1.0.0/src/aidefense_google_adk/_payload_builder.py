# Copyright 2026 Cisco Systems, Inc. and its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# SPDX-License-Identifier: Apache-2.0

"""Helpers for block payloads returned from tool callbacks."""

from __future__ import annotations

from typing import Any


def _field_value(item: Any, *names: str) -> Any:
    for name in names:
        if isinstance(item, dict):
            value = item.get(name)
        else:
            value = getattr(item, name, None)
        if value is not None:
            return value
    return None


def _as_text(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def extract_classifications(inspection: Any) -> list[str] | None:
    raw_items = _field_value(inspection, "classifications")
    if not raw_items:
        return None

    values: list[str] = []
    for item in raw_items:
        if isinstance(item, str):
            clean = _as_text(item)
        else:
            clean = _as_text(_field_value(item, "classification", "value", "name"))
        if clean and clean not in values:
            values.append(clean)

    return values or None


def extract_rules(inspection: Any) -> list[dict[str, Any]] | None:
    raw_items = _field_value(inspection, "rules")
    if not raw_items:
        return None

    values: list[dict[str, Any]] = []
    for item in raw_items:
        if isinstance(item, str):
            rule_name = _as_text(item)
            classification = None
        else:
            rule_name = _as_text(_field_value(item, "rule_name", "name", "value"))
            classification = _as_text(_field_value(item, "classification"))
        if not rule_name:
            continue
        values.append(
            {
                "rule_name": rule_name,
                "classification": classification,
            }
        )

    return values or None


def build_tool_block_payload(
    *,
    tool_name: str,
    stage: str,
    inspection: Any = None,
    request_id: str | None = None,
    reason: str | None = None,
) -> dict[str, Any]:
    if reason:
        error_text = reason
    elif stage == "tool_request":
        error_text = f"Tool call '{tool_name}' blocked by Cisco AI Defense policy."
    else:
        error_text = f"Tool response from '{tool_name}' blocked by Cisco AI Defense policy."

    payload: dict[str, Any] = {
        "error": error_text,
        "blocked": True,
        "action": _as_text(_field_value(inspection, "action")) or "block" if inspection else "block",
        "stage": stage,
    }

    severity = _as_text(_field_value(inspection, "severity"))
    if severity:
        payload["severity"] = severity

    classifications = extract_classifications(inspection)
    if classifications:
        payload["classifications"] = classifications

    rules = extract_rules(inspection)
    if rules:
        payload["rules"] = rules

    event_id = _as_text(_field_value(inspection, "event_id"))
    if event_id:
        payload["event_id"] = event_id

    if request_id:
        payload["request_id"] = request_id

    return payload
