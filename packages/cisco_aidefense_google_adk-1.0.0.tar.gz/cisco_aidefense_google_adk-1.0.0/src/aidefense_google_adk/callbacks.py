# Copyright 2026 Cisco Systems, Inc. and its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# SPDX-License-Identifier: Apache-2.0

"""
Standalone callback factories for agent-level (Tier 1) integration.

Use these when you want per-agent AI Defense inspection instead of the
global plugin approach.

Usage::

    from aidefense_google_adk import make_aidefense_callbacks

    cbs = make_aidefense_callbacks(api_key="...", mode="enforce")

    agent = LlmAgent(
        model="gemini-2.5-flash",
        name="my_agent",
        instruction="...",
        before_model_callback=cbs.before_model,
        after_model_callback=cbs.after_model,
        before_tool_callback=cbs.before_tool,
        after_tool_callback=cbs.after_tool,
    )
"""

from __future__ import annotations

import asyncio
import logging
import os
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any, Optional

from google.adk.agents.callback_context import CallbackContext
from google.adk.models.llm_request import LlmRequest
from google.adk.models.llm_response import LlmResponse
from google.adk.tools.base_tool import BaseTool
from google.adk.tools.tool_context import ToolContext
from google.genai import types

from aidefense.runtime import ChatInspectionClient
from aidefense.runtime.mcp_models import MCPMessage

from ._helpers import extract_last_user_text, extract_model_text
from ._payload_builder import build_tool_block_payload

logger = logging.getLogger("aidefense_google_adk")

_VALID_MODES = ("monitor", "enforce", "off")
_API_KEY_ENV = "AI_DEFENSE_API_KEY"
_MCP_API_KEY_ENV = "AI_DEFENSE_MCP_API_KEY"


@dataclass(frozen=True)
class AIDefenseCallbacks:
    """Container for the four agent-level callback functions.

    Each attribute is an ``async def`` that matches the corresponding
    ADK callback signature and can be passed directly to ``LlmAgent``.

    Use :meth:`apply_to` to wire all four callbacks onto an agent in
    one call instead of assigning each field manually.

    Call :meth:`close` when the callbacks are no longer needed to release
    resources held by the underlying inspection clients.
    """

    before_model: Callable[..., Awaitable[Optional[Any]]]
    after_model: Callable[..., Awaitable[Optional[Any]]]
    before_tool: Callable[..., Awaitable[Optional[dict[str, Any]]]]
    after_tool: Callable[..., Awaitable[Optional[dict[str, Any]]]]
    _close_fn: Optional[Callable[[], None]] = None

    def apply_to(self, agent: Any) -> None:
        """Attach all four callbacks to *agent*.

        Equivalent to::

            agent.before_model_callback = cbs.before_model
            agent.after_model_callback  = cbs.after_model
            agent.before_tool_callback  = cbs.before_tool
            agent.after_tool_callback   = cbs.after_tool
        """
        agent.before_model_callback = self.before_model
        agent.after_model_callback = self.after_model
        agent.before_tool_callback = self.before_tool
        agent.after_tool_callback = self.after_tool

    def close(self) -> None:
        """Release resources held by the underlying inspection clients."""
        if self._close_fn is not None:
            self._close_fn()


def make_aidefense_callbacks(
    api_key: Optional[str] = None,
    *,
    mode: str = "monitor",
    llm_mode: Optional[str] = None,
    mcp_mode: Optional[str] = None,
    on_violation: Optional[Callable[[Any], None]] = None,
    config: Optional[Any] = None,
    fail_open: bool = True,
    mcp_api_key: Optional[str] = None,
    mcp_config: Optional[Any] = None,
) -> AIDefenseCallbacks:
    """Create a set of agent-level callbacks wired to AI Defense inspection.

    Args:
        api_key: Cisco AI Defense API key.  When ``None``, the key is read
            from the ``AI_DEFENSE_API_KEY`` environment variable.
        mode: Default inspection mode (``"monitor"`` | ``"enforce"`` | ``"off"``).
        llm_mode: Override mode for LLM callbacks only.
        mcp_mode: Override mode for MCP/tool callbacks only.
        on_violation: Optional callback invoked on every violation.  Receives the
            ``InspectResponse`` object which includes ``is_safe``, ``action``,
            ``severity``, ``classifications``, ``rules``, and ``event_id``.
        config: Optional ``aidefense.config.Config`` instance. Use this to set
            a custom ``runtime_base_url``, region, retry, or pool config.
            If ``None``, the SDK default is used.
        fail_open: If ``True`` (default), inspection API errors are logged and
            traffic passes through.  If ``False``, API errors cause the request
            to be blocked in enforce mode.
        mcp_api_key: API key for MCP inspection.  When ``None``, the key is
            read from the ``AI_DEFENSE_MCP_API_KEY`` environment variable.
        mcp_config: Optional separate config for the MCP client.

    Returns:
        An ``AIDefenseCallbacks`` instance whose attributes can be
        assigned directly to ``LlmAgent`` callback fields.
    """
    for label, value in [("mode", mode), ("llm_mode", llm_mode), ("mcp_mode", mcp_mode)]:
        if value is not None and value not in _VALID_MODES:
            raise ValueError(
                f"{label} must be one of {_VALID_MODES!r}, got {value!r}"
            )

    effective_llm = llm_mode or mode
    effective_mcp = mcp_mode or mode

    resolved_api_key = api_key or os.environ.get(_API_KEY_ENV, "")
    resolved_mcp_key = mcp_api_key or os.environ.get(_MCP_API_KEY_ENV, "")

    if not resolved_api_key and effective_llm != "off":
        logger.warning(
            "No AI Defense API key found. Set the %s env var or pass "
            "api_key=... to enable LLM inspection.",
            _API_KEY_ENV,
        )
    if not resolved_mcp_key and effective_mcp != "off":
        logger.warning(
            "No MCP API key found. Set the %s env var or pass "
            "mcp_api_key=... to enable tool inspection.",
            _MCP_API_KEY_ENV,
        )

    chat_client = None
    if effective_llm != "off":
        kwargs: dict[str, Any] = {"api_key": resolved_api_key}
        if config is not None:
            kwargs["config"] = config
        chat_client = ChatInspectionClient(**kwargs)
    _mcp_client_cache: dict[str, Any] = {}

    def _get_mcp_client():
        if "client" not in _mcp_client_cache:
            from aidefense.runtime import MCPInspectionClient
            mcp_kwargs: dict[str, Any] = {"api_key": resolved_mcp_key}
            cfg = mcp_config or config
            if cfg is not None:
                mcp_kwargs["config"] = cfg
            _mcp_client_cache["client"] = MCPInspectionClient(**mcp_kwargs)
        return _mcp_client_cache["client"]

    # ------------------------------------------------------------------
    # LLM callbacks
    # ------------------------------------------------------------------

    async def before_model(
        *,
        callback_context: CallbackContext,
        llm_request: LlmRequest,
    ) -> Optional[LlmResponse]:
        if effective_llm == "off":
            return None

        prompt_text = extract_last_user_text(llm_request.contents)
        if not prompt_text:
            return None

        request_id = str(uuid.uuid4())
        logger.debug("AI Defense: inspecting prompt (request_id=%s, mode=%s)", request_id, effective_llm)
        try:
            result = await asyncio.to_thread(
                chat_client.inspect_prompt, prompt_text, request_id=request_id,
            )
        except Exception:
            logger.exception("AI Defense prompt inspection failed")
            if not fail_open and effective_llm == "enforce":
                return LlmResponse(
                    content=types.Content(
                        role="model",
                        parts=[types.Part(text="Request blocked: AI Defense inspection unavailable.")],
                    ),
                )
            return None

        logger.debug(
            "AI Defense: prompt result (request_id=%s, safe=%s, action=%s)",
            request_id, result.is_safe, result.action,
        )
        if not result.is_safe:
            logger.warning(
                "AI Defense: prompt violation "
                "(request_id=%s, action=%s, severity=%s, classifications=%s, event_id=%s)",
                request_id,
                result.action,
                result.severity,
                getattr(result, "classifications", []),
                getattr(result, "event_id", None),
            )
            if on_violation:
                try:
                    on_violation(result)
                except Exception:
                    logger.debug("on_violation raised", exc_info=True)
            if effective_llm == "enforce":
                return LlmResponse(
                    content=types.Content(
                        role="model",
                        parts=[types.Part(text="Request blocked by Cisco AI Defense policy.")],
                    ),
                )
        return None

    async def after_model(
        *,
        callback_context: CallbackContext,
        llm_response: LlmResponse,
    ) -> Optional[LlmResponse]:
        if effective_llm == "off":
            return None

        response_text = extract_model_text(llm_response)
        if not response_text:
            return None

        request_id = str(uuid.uuid4())
        logger.debug("AI Defense: inspecting response (request_id=%s, mode=%s)", request_id, effective_llm)
        try:
            result = await asyncio.to_thread(
                chat_client.inspect_response, response_text, request_id=request_id,
            )
        except Exception:
            logger.exception("AI Defense response inspection failed")
            if not fail_open and effective_llm == "enforce":
                return LlmResponse(
                    content=types.Content(
                        role="model",
                        parts=[types.Part(text="Response blocked: AI Defense inspection unavailable.")],
                    ),
                )
            return None

        logger.debug(
            "AI Defense: response result (request_id=%s, safe=%s, action=%s)",
            request_id, result.is_safe, result.action,
        )
        if not result.is_safe:
            logger.warning(
                "AI Defense: response violation "
                "(request_id=%s, action=%s, severity=%s, classifications=%s, event_id=%s)",
                request_id,
                result.action,
                result.severity,
                getattr(result, "classifications", []),
                getattr(result, "event_id", None),
            )
            if on_violation:
                try:
                    on_violation(result)
                except Exception:
                    logger.debug("on_violation raised", exc_info=True)
            if effective_llm == "enforce":
                return LlmResponse(
                    content=types.Content(
                        role="model",
                        parts=[types.Part(text="Response blocked by Cisco AI Defense policy.")],
                    ),
                )
        return None

    # ------------------------------------------------------------------
    # Tool callbacks
    # ------------------------------------------------------------------

    async def before_tool(
        tool: BaseTool,
        tool_args: Optional[dict[str, Any]] = None,
        tool_context: Optional[ToolContext] = None,
        **kwargs: Any,
    ) -> Optional[dict]:
        args = tool_args if tool_args is not None else kwargs.pop("args", None)
        if args is None:
            args = {}
        if effective_mcp == "off":
            return None

        mcp_client = _get_mcp_client()
        message = MCPMessage(
            jsonrpc="2.0",
            method="tools/call",
            params={"name": tool.name, "arguments": args},
            id=str(uuid.uuid4()),
        )
        request_id = str(uuid.uuid4())
        logger.debug("AI Defense: inspecting tool request (tool=%s, request_id=%s, mode=%s)", tool.name, request_id, effective_mcp)
        try:
            result = await asyncio.to_thread(
                mcp_client.inspect, message, request_id=request_id,
            )
        except Exception:
            logger.exception("AI Defense tool-request inspection failed (tool=%s)", tool.name)
            if not fail_open and effective_mcp == "enforce":
                return {
                    "error": f"Tool call '{tool.name}' blocked: AI Defense inspection unavailable.",
                    "blocked": True,
                }
            return None

        inspection = result.result
        logger.debug(
            "AI Defense: tool request result (tool=%s, request_id=%s, safe=%s)",
            tool.name, request_id, inspection.is_safe if inspection else "N/A",
        )
        if inspection and not inspection.is_safe:
            logger.warning(
                "AI Defense: tool-request violation "
                "(tool=%s, action=%s, severity=%s, classifications=%s, event_id=%s)",
                tool.name,
                inspection.action,
                inspection.severity,
                getattr(inspection, "classifications", []),
                getattr(inspection, "event_id", None),
            )
            if on_violation:
                try:
                    on_violation(inspection)
                except Exception:
                    logger.debug("on_violation raised", exc_info=True)
            if effective_mcp == "enforce":
                return build_tool_block_payload(
                    tool_name=tool.name,
                    stage="tool_request",
                    inspection=inspection,
                    request_id=request_id,
                )
        return None

    async def after_tool(
        tool: BaseTool,
        tool_args: Optional[dict[str, Any]] = None,
        tool_context: Optional[ToolContext] = None,
        result: Optional[dict] = None,
        **kwargs: Any,
    ) -> Optional[dict]:
        args = tool_args if tool_args is not None else kwargs.pop("args", None)
        if args is None:
            args = {}
        tool_response = result if result is not None else kwargs.pop("tool_response", None)
        if tool_response is None:
            tool_response = {}
        if effective_mcp == "off":
            return None

        mcp_client = _get_mcp_client()
        message = MCPMessage(
            jsonrpc="2.0",
            result=tool_response,
            id=str(uuid.uuid4()),
        )
        request_id = str(uuid.uuid4())
        logger.debug("AI Defense: inspecting tool response (tool=%s, request_id=%s, mode=%s)", tool.name, request_id, effective_mcp)
        try:
            mcp_result = await asyncio.to_thread(
                mcp_client.inspect, message, request_id=request_id,
            )
        except Exception:
            logger.exception("AI Defense tool-response inspection failed (tool=%s)", tool.name)
            if not fail_open and effective_mcp == "enforce":
                return {
                    "error": f"Tool response from '{tool.name}' blocked: AI Defense inspection unavailable.",
                    "blocked": True,
                }
            return None

        inspection = mcp_result.result
        logger.debug(
            "AI Defense: tool response result (tool=%s, request_id=%s, safe=%s)",
            tool.name, request_id, inspection.is_safe if inspection else "N/A",
        )
        if inspection and not inspection.is_safe:
            logger.warning(
                "AI Defense: tool-response violation "
                "(tool=%s, action=%s, severity=%s, classifications=%s, event_id=%s)",
                tool.name,
                inspection.action,
                inspection.severity,
                getattr(inspection, "classifications", []),
                getattr(inspection, "event_id", None),
            )
            if on_violation:
                try:
                    on_violation(inspection)
                except Exception:
                    logger.debug("on_violation raised", exc_info=True)
            if effective_mcp == "enforce":
                return build_tool_block_payload(
                    tool_name=tool.name,
                    stage="tool_response",
                    inspection=inspection,
                    request_id=request_id,
                )
        return None

    def _close() -> None:
        nonlocal chat_client
        clients = [chat_client, _mcp_client_cache.get("client")]
        for client in clients:
            if client is not None and hasattr(client, "close"):
                try:
                    client.close()
                except Exception:
                    logger.debug("Error closing inspection client", exc_info=True)
        chat_client = None  # type: ignore[assignment]
        _mcp_client_cache.clear()

    return AIDefenseCallbacks(
        before_model=before_model,
        after_model=after_model,
        before_tool=before_tool,
        after_tool=after_tool,
        _close_fn=_close,
    )
