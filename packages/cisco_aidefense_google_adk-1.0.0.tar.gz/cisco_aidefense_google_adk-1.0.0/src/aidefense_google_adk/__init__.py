# Copyright 2026 Cisco Systems, Inc. and its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# SPDX-License-Identifier: Apache-2.0

"""Cisco AI Defense plugin for Google ADK."""

import logging
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("cisco-aidefense-google-adk")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"

from .callbacks import AIDefenseCallbacks, make_aidefense_callbacks
from .plugin import CiscoAIDefensePlugin
from .agentsec_callbacks import AgentsecCallbacks, make_agentsec_callbacks
from .agentsec_plugin import AgentsecPlugin
from ._convenience import configure_logging, defend

logging.getLogger(__name__).addHandler(logging.NullHandler())

__all__ = [
    "AIDefenseCallbacks",
    "AgentsecCallbacks",
    "AgentsecPlugin",
    "CiscoAIDefensePlugin",
    "configure_logging",
    "make_agentsec_callbacks",
    "make_aidefense_callbacks",
    "defend",
]
