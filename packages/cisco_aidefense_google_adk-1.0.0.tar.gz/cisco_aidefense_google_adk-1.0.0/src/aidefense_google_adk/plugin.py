# Copyright 2026 Cisco Systems, Inc. and its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# SPDX-License-Identifier: Apache-2.0

"""
Cisco AI Defense plugin for Google ADK.

Provides ``CiscoAIDefensePlugin``, a ``BasePlugin`` subclass that inspects
LLM requests/responses via ``ChatInspectionClient`` and MCP tool
calls/results via ``MCPInspectionClient``.

Usage::

    from aidefense_google_adk import CiscoAIDefensePlugin

    runner = Runner(
        app_name="my_app",
        agent=agent,
        session_service=session_service,
        plugins=[CiscoAIDefensePlugin(api_key="...", mode="enforce")],
    )
"""

from __future__ import annotations

import asyncio
import logging
import os
import uuid
from collections.abc import Callable
from typing import Any, Optional

from google.adk.agents.callback_context import CallbackContext
from google.adk.models.llm_request import LlmRequest
from google.adk.models.llm_response import LlmResponse
from google.adk.plugins.base_plugin import BasePlugin
from google.adk.tools.base_tool import BaseTool
from google.adk.tools.tool_context import ToolContext
from google.genai import types

from aidefense.runtime import ChatInspectionClient
from aidefense.runtime.mcp_models import MCPMessage

from ._helpers import extract_last_user_text, extract_model_text
from ._payload_builder import build_tool_block_payload

logger = logging.getLogger("aidefense_google_adk")

_VALID_MODES = ("monitor", "enforce", "off")

_API_KEY_ENV = "AI_DEFENSE_API_KEY"
_MCP_API_KEY_ENV = "AI_DEFENSE_MCP_API_KEY"


class CiscoAIDefensePlugin(BasePlugin):
    """Google ADK plugin that inspects LLM and tool interactions with Cisco AI Defense.

    This plugin hooks into the ADK Runner lifecycle via ``BasePlugin`` callbacks.
    It runs **before** any agent-level callbacks, making it the outermost
    defense layer.

    Modes:
        - ``"monitor"``: Inspect all traffic; log violations but never block.
        - ``"enforce"``: Inspect all traffic; block (short-circuit) on violations.
        - ``"off"``: Skip all inspection (no-op).

    Args:
        api_key: Cisco AI Defense API key.  When ``None``, the key is read
            from the ``AI_DEFENSE_API_KEY`` environment variable.
        mode: Inspection mode — ``"monitor"`` (default), ``"enforce"``, or ``"off"``.
        llm_mode: Override mode for LLM inspection only. Falls back to ``mode``.
        mcp_mode: Override mode for MCP/tool inspection only. Falls back to ``mode``.
        on_violation: Optional callback invoked on every violation, regardless
            of mode. Receives the ``InspectResponse`` object which includes
            ``is_safe``, ``action``, ``severity``, ``classifications``,
            ``rules``, and ``event_id``.
        config: Optional ``aidefense.config.Config`` instance. Use this to set
            a custom ``runtime_base_url``, region, retry, or pool config.
            If ``None``, the SDK default is used.
        fail_open: If ``True`` (default), inspection API errors are logged
            and traffic passes through.  If ``False``, API errors cause
            the request to be blocked in enforce mode or re-raised in
            monitor mode.
        mcp_api_key: API key for MCP inspection.  When ``None``, the key is
            read from the ``AI_DEFENSE_MCP_API_KEY`` environment variable.
        mcp_config: Optional separate config for the MCP client.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        mode: str = "monitor",
        llm_mode: Optional[str] = None,
        mcp_mode: Optional[str] = None,
        on_violation: Optional[Callable[[Any], None]] = None,
        config: Optional[Any] = None,
        fail_open: bool = True,
        mcp_api_key: Optional[str] = None,
        mcp_config: Optional[Any] = None,
    ) -> None:
        super().__init__(name="cisco_ai_defense")

        for label, value in [("mode", mode), ("llm_mode", llm_mode), ("mcp_mode", mcp_mode)]:
            if value is not None and value not in _VALID_MODES:
                raise ValueError(
                    f"{label} must be one of {_VALID_MODES!r}, got {value!r}"
                )

        self._llm_mode = llm_mode or mode
        self._mcp_mode = mcp_mode or mode
        self._on_violation = on_violation
        self._fail_open = fail_open
        self._config = config
        self._mcp_config = mcp_config

        self._api_key = api_key or os.environ.get(_API_KEY_ENV, "")
        self._mcp_api_key = mcp_api_key or os.environ.get(_MCP_API_KEY_ENV, "")

        if not self._api_key and self._llm_mode != "off":
            logger.warning(
                "No AI Defense API key found. Set the %s env var or pass "
                "api_key=... to enable LLM inspection.",
                _API_KEY_ENV,
            )
        if not self._mcp_api_key and self._mcp_mode != "off":
            logger.warning(
                "No MCP API key found. Set the %s env var or pass "
                "mcp_api_key=... to enable tool inspection.",
                _MCP_API_KEY_ENV,
            )

        self._chat_client = None
        if self._llm_mode != "off":
            kwargs: dict[str, Any] = {"api_key": self._api_key}
            if config is not None:
                kwargs["config"] = config
            self._chat_client = ChatInspectionClient(**kwargs)
        self._mcp_client: Optional[Any] = None

    def _get_mcp_client(self):
        """Lazy-init the MCP client so the import only happens when needed."""
        if self._mcp_client is None:
            from aidefense.runtime import MCPInspectionClient
            kwargs: dict[str, Any] = {"api_key": self._mcp_api_key}
            cfg = self._mcp_config or self._config
            if cfg is not None:
                kwargs["config"] = cfg
            self._mcp_client = MCPInspectionClient(**kwargs)
        return self._mcp_client

    # ------------------------------------------------------------------
    # LLM callbacks
    # ------------------------------------------------------------------

    async def before_model_callback(
        self,
        *,
        callback_context: CallbackContext,
        llm_request: LlmRequest,
    ) -> Optional[LlmResponse]:
        """Inspect the user prompt before it is sent to the LLM.

        In enforce mode, returns a blocked ``LlmResponse`` to prevent
        the LLM call.  In monitor mode, logs the violation and returns
        ``None`` so execution continues.
        """
        if self._llm_mode == "off":
            return None

        prompt_text = extract_last_user_text(llm_request.contents)
        if not prompt_text:
            return None

        request_id = str(uuid.uuid4())
        logger.debug("AI Defense: inspecting prompt (request_id=%s, mode=%s)", request_id, self._llm_mode)
        try:
            result = await asyncio.to_thread(
                self._chat_client.inspect_prompt,
                prompt_text, request_id=request_id,
            )
        except Exception:
            logger.exception("AI Defense prompt inspection failed (request_id=%s)", request_id)
            if not self._fail_open and self._llm_mode == "enforce":
                return LlmResponse(
                    content=types.Content(
                        role="model",
                        parts=[types.Part(text="Request blocked: AI Defense inspection unavailable.")],
                    ),
                )
            return None

        logger.debug("AI Defense: prompt result (request_id=%s, safe=%s, action=%s)", request_id, result.is_safe, result.action)
        if not result.is_safe:
            logger.warning(
                "AI Defense: prompt violation detected "
                "(request_id=%s, action=%s, severity=%s, classifications=%s, event_id=%s)",
                request_id,
                result.action,
                result.severity,
                getattr(result, "classifications", []),
                getattr(result, "event_id", None),
            )
            if self._on_violation:
                try:
                    self._on_violation(result)
                except Exception:
                    logger.debug("on_violation callback raised", exc_info=True)

            if self._llm_mode == "enforce":
                return LlmResponse(
                    content=types.Content(
                        role="model",
                        parts=[types.Part(text="Request blocked by Cisco AI Defense policy.")],
                    ),
                )
        return None

    async def after_model_callback(
        self,
        *,
        callback_context: CallbackContext,
        llm_response: LlmResponse,
    ) -> Optional[LlmResponse]:
        """Inspect the LLM response before it is returned to the agent."""
        if self._llm_mode == "off":
            return None

        response_text = extract_model_text(llm_response)
        if not response_text:
            return None

        request_id = str(uuid.uuid4())
        logger.debug("AI Defense: inspecting response (request_id=%s, mode=%s)", request_id, self._llm_mode)
        try:
            result = await asyncio.to_thread(
                self._chat_client.inspect_response,
                response_text, request_id=request_id,
            )
        except Exception:
            logger.exception("AI Defense response inspection failed (request_id=%s)", request_id)
            if not self._fail_open and self._llm_mode == "enforce":
                return LlmResponse(
                    content=types.Content(
                        role="model",
                        parts=[types.Part(text="Response blocked: AI Defense inspection unavailable.")],
                    ),
                )
            return None

        logger.debug("AI Defense: response result (request_id=%s, safe=%s, action=%s)", request_id, result.is_safe, result.action)
        if not result.is_safe:
            logger.warning(
                "AI Defense: response violation detected "
                "(request_id=%s, action=%s, severity=%s, classifications=%s, event_id=%s)",
                request_id,
                result.action,
                result.severity,
                getattr(result, "classifications", []),
                getattr(result, "event_id", None),
            )
            if self._on_violation:
                try:
                    self._on_violation(result)
                except Exception:
                    logger.debug("on_violation callback raised", exc_info=True)

            if self._llm_mode == "enforce":
                return LlmResponse(
                    content=types.Content(
                        role="model",
                        parts=[types.Part(text="Response blocked by Cisco AI Defense policy.")],
                    ),
                )
        return None

    # ------------------------------------------------------------------
    # Tool callbacks
    # ------------------------------------------------------------------

    async def before_tool_callback(
        self,
        *,
        tool: BaseTool,
        tool_args: dict[str, Any],
        tool_context: ToolContext,
    ) -> Optional[dict]:
        """Inspect a tool call request before the tool executes."""
        if self._mcp_mode == "off":
            return None

        mcp_client = self._get_mcp_client()
        message = MCPMessage(
            jsonrpc="2.0",
            method="tools/call",
            params={"name": tool.name, "arguments": tool_args},
            id=str(uuid.uuid4()),
        )
        request_id = str(uuid.uuid4())
        logger.debug("AI Defense: inspecting tool request (tool=%s, request_id=%s, mode=%s)", tool.name, request_id, self._mcp_mode)

        try:
            result = await asyncio.to_thread(
                mcp_client.inspect, message, request_id=request_id,
            )
        except Exception:
            logger.exception("AI Defense tool-request inspection failed (tool=%s)", tool.name)
            if not self._fail_open and self._mcp_mode == "enforce":
                return {
                    "error": f"Tool call '{tool.name}' blocked: AI Defense inspection unavailable.",
                    "blocked": True,
                }
            return None

        inspection = result.result
        logger.debug("AI Defense: tool request result (tool=%s, request_id=%s, safe=%s)", tool.name, request_id, inspection.is_safe if inspection else "N/A")
        if inspection and not inspection.is_safe:
            logger.warning(
                "AI Defense: tool-request violation "
                "(tool=%s, action=%s, severity=%s, classifications=%s, event_id=%s)",
                tool.name,
                inspection.action,
                inspection.severity,
                getattr(inspection, "classifications", []),
                getattr(inspection, "event_id", None),
            )
            if self._on_violation:
                try:
                    self._on_violation(inspection)
                except Exception:
                    logger.debug("on_violation callback raised", exc_info=True)

            if self._mcp_mode == "enforce":
                return build_tool_block_payload(
                    tool_name=tool.name,
                    stage="tool_request",
                    inspection=inspection,
                    request_id=request_id,
                )
        return None

    async def after_tool_callback(
        self,
        *,
        tool: BaseTool,
        tool_args: dict[str, Any],
        tool_context: ToolContext,
        result: dict,
    ) -> Optional[dict]:
        """Inspect a tool call result after the tool executes."""
        if self._mcp_mode == "off":
            return None

        mcp_client = self._get_mcp_client()
        message = MCPMessage(
            jsonrpc="2.0",
            result=result,
            id=str(uuid.uuid4()),
        )
        request_id = str(uuid.uuid4())
        logger.debug("AI Defense: inspecting tool response (tool=%s, request_id=%s, mode=%s)", tool.name, request_id, self._mcp_mode)

        try:
            mcp_result = await asyncio.to_thread(
                mcp_client.inspect, message, request_id=request_id,
            )
        except Exception:
            logger.exception("AI Defense tool-response inspection failed (tool=%s)", tool.name)
            if not self._fail_open and self._mcp_mode == "enforce":
                return {
                    "error": f"Tool response from '{tool.name}' blocked: AI Defense inspection unavailable.",
                    "blocked": True,
                }
            return None

        inspection = mcp_result.result
        logger.debug("AI Defense: tool response result (tool=%s, request_id=%s, safe=%s)", tool.name, request_id, inspection.is_safe if inspection else "N/A")
        if inspection and not inspection.is_safe:
            logger.warning(
                "AI Defense: tool-response violation "
                "(tool=%s, action=%s, severity=%s, classifications=%s, event_id=%s)",
                tool.name,
                inspection.action,
                inspection.severity,
                getattr(inspection, "classifications", []),
                getattr(inspection, "event_id", None),
            )
            if self._on_violation:
                try:
                    self._on_violation(inspection)
                except Exception:
                    logger.debug("on_violation callback raised", exc_info=True)

            if self._mcp_mode == "enforce":
                return build_tool_block_payload(
                    tool_name=tool.name,
                    stage="tool_response",
                    inspection=inspection,
                    request_id=request_id,
                )
        return None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def close(self) -> None:
        """Release resources held by inspection clients."""
        for client in (self._chat_client, self._mcp_client):
            if client is not None and hasattr(client, "close"):
                try:
                    client.close()
                except Exception:
                    logger.debug("Error closing inspection client", exc_info=True)
        self._chat_client = None  # type: ignore[assignment]
        self._mcp_client = None
