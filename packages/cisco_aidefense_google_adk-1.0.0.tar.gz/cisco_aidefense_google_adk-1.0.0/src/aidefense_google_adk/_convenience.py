# Copyright 2026 Cisco Systems, Inc. and its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# SPDX-License-Identifier: Apache-2.0

"""
High-level convenience helpers for the most common integration patterns.

``defend()`` is a one-liner that covers 90 % of use cases::

    from aidefense_google_adk import defend

    # Attach AI Defense callbacks to an agent (returns the agent)
    agent = defend(agent)

    # Or get an App-level plugin
    plugin = defend()

``configure_logging()`` enables human-readable console output for the
library without requiring callers to set up ``logging.basicConfig``::

    from aidefense_google_adk import configure_logging
    configure_logging()
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any, Optional, Union

logger = logging.getLogger("aidefense_google_adk")

_VALID_VARIANTS = ("raw", "inspector")


def defend(
    agent: Optional[Any] = None,
    *,
    mode: str = "monitor",
    fail_open: bool = True,
    variant: str = "raw",
    api_key: Optional[str] = None,
    mcp_api_key: Optional[str] = None,
    config: Optional[Any] = None,
    mcp_config: Optional[Any] = None,
    on_violation: Optional[Callable[[Any], None]] = None,
    **kwargs: Any,
) -> Any:
    """One-liner to add Cisco AI Defense inspection.

    When called **with** an agent, it creates per-agent callbacks and
    attaches them via ``apply_to``, then returns the agent so it can be
    used inline::

        agent = defend(agent, mode="enforce")

    When called **without** an agent, it returns a ``BasePlugin`` instance
    that can be passed to ``App(plugins=[...])``::

        plugin = defend(mode="enforce")
        app = App(name="my_app", root_agent=agent, plugins=[plugin])
        runner = Runner(app=app, session_service=session_service)

    Args:
        agent: An ``LlmAgent`` instance.  If provided, callbacks are
            attached and the agent is returned.  If ``None``, a plugin
            is returned instead.
        mode: Inspection mode (``"monitor"`` | ``"enforce"`` | ``"off"``).
        fail_open: Allow traffic when the AI Defense API is unreachable.
        variant: ``"raw"`` (default) uses ``ChatInspectionClient`` /
            ``MCPInspectionClient``.  ``"inspector"`` uses
            ``LLMInspector`` / ``MCPInspector`` from agentsec.
        api_key: Cisco AI Defense API key (falls back to env vars).
        mcp_api_key: Separate API key for MCP inspection.
        config: Optional ``aidefense.config.Config`` (raw variant only).
        mcp_config: Optional separate config for MCP (raw variant only).
        on_violation: Callback invoked on every violation.
        **kwargs: Extra keyword arguments forwarded to the underlying
            plugin or callback factory (e.g. ``retry_total``,
            ``endpoint``).

    Returns:
        The *agent* (if one was passed) or a *plugin* instance.
    """
    if variant not in _VALID_VARIANTS:
        raise ValueError(
            f"variant must be one of {_VALID_VARIANTS!r}, got {variant!r}"
        )

    if variant == "inspector" and (config is not None or mcp_config is not None):
        logger.warning(
            "config/mcp_config are ignored when variant='inspector'. "
            "Use endpoint/mcp_endpoint instead."
        )

    if agent is not None:
        return _attach_callbacks(
            agent,
            mode=mode,
            fail_open=fail_open,
            variant=variant,
            api_key=api_key,
            mcp_api_key=mcp_api_key,
            config=config,
            mcp_config=mcp_config,
            on_violation=on_violation,
            **kwargs,
        )

    return _make_plugin(
        mode=mode,
        fail_open=fail_open,
        variant=variant,
        api_key=api_key,
        mcp_api_key=mcp_api_key,
        config=config,
        mcp_config=mcp_config,
        on_violation=on_violation,
        **kwargs,
    )


def _attach_callbacks(
    agent: Any,
    *,
    variant: str,
    **kwargs: Any,
) -> Any:
    """Create callbacks and wire them onto *agent*."""
    if variant == "inspector":
        from .agentsec_callbacks import make_agentsec_callbacks

        inspector_kwargs = {k: v for k, v in kwargs.items() if k != "config" and k != "mcp_config"}
        cbs = make_agentsec_callbacks(**inspector_kwargs)
    else:
        from .callbacks import make_aidefense_callbacks

        cbs = make_aidefense_callbacks(**kwargs)

    cbs.apply_to(agent)
    agent._aidefense_cbs = cbs
    return agent


def _make_plugin(
    *,
    variant: str,
    **kwargs: Any,
) -> Any:
    """Instantiate the appropriate plugin class."""
    if variant == "inspector":
        from .agentsec_plugin import AgentsecPlugin

        inspector_kwargs = {k: v for k, v in kwargs.items() if k != "config" and k != "mcp_config"}
        return AgentsecPlugin(**inspector_kwargs)
    else:
        from .plugin import CiscoAIDefensePlugin

        return CiscoAIDefensePlugin(**kwargs)


def configure_logging(
    level: int = logging.INFO,
    fmt: str = "[%(name)s] %(levelname)s: %(message)s",
) -> None:
    """Enable console logging for the ``aidefense_google_adk`` library.

    Call this once at startup to see inspection results without
    configuring Python's logging system yourself::

        from aidefense_google_adk import configure_logging
        configure_logging()

    This configures the ``aidefense_google_adk`` logger *only*. It does
    **not** call ``logging.basicConfig()`` or change the root logger, so
    it won't interfere with your application's logging setup.  Messages
    propagate to ancestor loggers by default; set
    ``logging.getLogger("aidefense_google_adk").propagate = False`` if
    you want this handler to be the sole output.

    Args:
        level: Logging level (default ``logging.INFO``).
        fmt: Log format string.
    """
    lib_logger = logging.getLogger("aidefense_google_adk")
    has_real_handler = any(
        not isinstance(h, logging.NullHandler) for h in lib_logger.handlers
    )
    if not has_real_handler:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter(fmt))
        lib_logger.addHandler(handler)
    else:
        for h in lib_logger.handlers:
            if isinstance(h, logging.StreamHandler) and not isinstance(h, logging.NullHandler):
                h.setFormatter(logging.Formatter(fmt))
    lib_logger.setLevel(level)
