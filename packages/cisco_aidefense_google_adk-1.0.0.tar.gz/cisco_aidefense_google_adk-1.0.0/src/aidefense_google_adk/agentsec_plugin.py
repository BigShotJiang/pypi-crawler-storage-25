# Copyright 2026 Cisco Systems, Inc. and its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# SPDX-License-Identifier: Apache-2.0

"""
Cisco AI Defense plugin for Google ADK — agentsec Inspector variant.

Provides ``AgentsecPlugin``, a ``BasePlugin`` subclass that inspects
LLM requests/responses via ``LLMInspector`` and MCP tool calls/results
via ``MCPInspector`` from the agentsec SDK layer.

Compared to ``CiscoAIDefensePlugin`` (which uses the lower-level
``ChatInspectionClient`` / ``MCPInspectionClient``), this variant adds
retry with exponential backoff, structured ``Decision`` objects, and
fail-open/fail-closed semantics out of the box.

Usage::

    from aidefense_google_adk import AgentsecPlugin

    runner = Runner(
        app_name="my_app",
        agent=agent,
        session_service=session_service,
        plugins=[AgentsecPlugin(mode="enforce")],
    )
"""

from __future__ import annotations

import logging
import os
from collections.abc import Callable
from typing import Any, Optional

from google.adk.agents.callback_context import CallbackContext
from google.adk.models.llm_request import LlmRequest
from google.adk.models.llm_response import LlmResponse
from google.adk.plugins.base_plugin import BasePlugin
from google.adk.tools.base_tool import BaseTool
from google.adk.tools.tool_context import ToolContext
from google.genai import types

from aidefense.runtime.agentsec.inspectors import LLMInspector, MCPInspector

from ._helpers import extract_last_user_text, extract_model_text
from ._payload_builder import build_tool_block_payload

logger = logging.getLogger("aidefense_google_adk.agentsec")

_VALID_MODES = ("monitor", "enforce", "off")
_LLM_API_KEY_ENV = "AI_DEFENSE_API_MODE_LLM_API_KEY"
_MCP_API_KEY_ENV = "AI_DEFENSE_API_MODE_MCP_API_KEY"


class AgentsecPlugin(BasePlugin):
    """Google ADK plugin using agentsec Inspectors for LLM and tool inspection.

    This plugin hooks into the ADK Runner lifecycle via ``BasePlugin``
    callbacks, using the higher-level ``LLMInspector`` and ``MCPInspector``
    from the agentsec SDK.

    Compared to ``CiscoAIDefensePlugin``:
        - Built-in retry with exponential backoff.
        - Structured ``Decision`` objects with severity, classifications,
          rules, and event IDs.
        - Fail-open / fail-closed semantics via the ``fail_open`` parameter.
        - API keys and endpoints auto-resolve from environment variables.

    Modes:
        - ``"monitor"``: Inspect all traffic; log violations but never block.
        - ``"enforce"``: Inspect all traffic; block (short-circuit) on violations.
        - ``"off"``: Skip all inspection (no-op).

    Args:
        mode: Default inspection mode (``"monitor"`` | ``"enforce"`` | ``"off"``).
        llm_mode: Override mode for LLM inspection only. Falls back to ``mode``.
        mcp_mode: Override mode for MCP/tool inspection only. Falls back to ``mode``.
        on_violation: Optional callback invoked on every violation, regardless
            of mode. Receives a ``Decision`` object.
        api_key: Cisco AI Defense API key. If ``None``, resolved from
            ``AI_DEFENSE_API_MODE_LLM_API_KEY`` env var by the Inspector.
        endpoint: Base URL for AI Defense API. If ``None``, resolved from
            ``AI_DEFENSE_API_MODE_LLM_ENDPOINT`` env var.
        mcp_api_key: Separate API key for MCP inspection. Falls back to
            ``AI_DEFENSE_API_MODE_MCP_API_KEY`` env var.
        mcp_endpoint: Separate endpoint for MCP inspection. Falls back to
            ``AI_DEFENSE_API_MODE_MCP_ENDPOINT`` env var.
        fail_open: Allow requests when the AI Defense API is unreachable.
        timeout_ms: Request timeout in milliseconds.
        retry_total: Total retry attempts (default 1, no retry).
        retry_backoff: Exponential backoff factor in seconds.
        default_rules: Default rules for LLM inspection.
        entity_types: Entity types to filter for (e.g., ``["EMAIL"]``).
        app_name: Application name included in inspection metadata.
    """

    def __init__(
        self,
        *,
        mode: str = "monitor",
        llm_mode: Optional[str] = None,
        mcp_mode: Optional[str] = None,
        on_violation: Optional[Callable[[Any], None]] = None,
        api_key: Optional[str] = None,
        endpoint: Optional[str] = None,
        mcp_api_key: Optional[str] = None,
        mcp_endpoint: Optional[str] = None,
        fail_open: bool = True,
        timeout_ms: Optional[int] = None,
        retry_total: Optional[int] = None,
        retry_backoff: Optional[float] = None,
        default_rules: Optional[list[Any]] = None,
        entity_types: Optional[list[str]] = None,
        app_name: str = "google_adk",
    ) -> None:
        super().__init__(name="cisco_ai_defense_agentsec")

        for label, value in [("mode", mode), ("llm_mode", llm_mode), ("mcp_mode", mcp_mode)]:
            if value is not None and value not in _VALID_MODES:
                raise ValueError(
                    f"{label} must be one of {_VALID_MODES!r}, got {value!r}"
                )

        self._llm_mode = llm_mode or mode
        self._mcp_mode = mcp_mode or mode
        self._on_violation = on_violation
        self._fail_open = fail_open
        self._app_name = app_name

        if (
            api_key is None
            and not os.environ.get(_LLM_API_KEY_ENV)
            and self._llm_mode != "off"
        ):
            logger.warning(
                "No LLM API key found. Set the %s env var or pass "
                "api_key=... to enable LLM inspection.",
                _LLM_API_KEY_ENV,
            )
        resolved_mcp_key = mcp_api_key or api_key
        if (
            resolved_mcp_key is None
            and not os.environ.get(_MCP_API_KEY_ENV)
            and self._mcp_mode != "off"
        ):
            logger.warning(
                "No MCP API key found. Set the %s env var or pass "
                "mcp_api_key=... to enable tool inspection.",
                _MCP_API_KEY_ENV,
            )

        self._llm_inspector = None
        if self._llm_mode != "off":
            llm_kwargs: dict[str, Any] = {"fail_open": fail_open}
            if api_key is not None:
                llm_kwargs["api_key"] = api_key
            if endpoint is not None:
                llm_kwargs["endpoint"] = endpoint
            if timeout_ms is not None:
                llm_kwargs["timeout_ms"] = timeout_ms
            if retry_total is not None:
                llm_kwargs["retry_total"] = retry_total
            if retry_backoff is not None:
                llm_kwargs["retry_backoff"] = retry_backoff
            if default_rules is not None:
                llm_kwargs["default_rules"] = default_rules
            if entity_types is not None:
                llm_kwargs["entity_types"] = entity_types
            self._llm_inspector = LLMInspector(**llm_kwargs)

        self._mcp_inspector = None
        if self._mcp_mode != "off":
            mcp_kwargs: dict[str, Any] = {"fail_open": fail_open}
            if mcp_api_key is not None:
                mcp_kwargs["api_key"] = mcp_api_key
            elif api_key is not None:
                mcp_kwargs["api_key"] = api_key
            if mcp_endpoint is not None:
                mcp_kwargs["endpoint"] = mcp_endpoint
            elif endpoint is not None:
                mcp_kwargs["endpoint"] = endpoint
            if timeout_ms is not None:
                mcp_kwargs["timeout_ms"] = timeout_ms
            if retry_total is not None:
                mcp_kwargs["retry_total"] = retry_total
            if retry_backoff is not None:
                mcp_kwargs["retry_backoff"] = retry_backoff
            self._mcp_inspector = MCPInspector(**mcp_kwargs)

    # ------------------------------------------------------------------
    # LLM callbacks
    # ------------------------------------------------------------------

    async def before_model_callback(
        self,
        *,
        callback_context: CallbackContext,
        llm_request: LlmRequest,
    ) -> Optional[LlmResponse]:
        """Inspect the user prompt before it is sent to the LLM."""
        if self._llm_mode == "off":
            return None

        prompt_text = extract_last_user_text(llm_request.contents)
        if not prompt_text:
            return None

        messages = [{"role": "user", "content": prompt_text}]
        metadata = {"src_app": self._app_name}

        logger.debug("AI Defense: inspecting prompt (mode=%s)", self._llm_mode)
        try:
            decision = await self._llm_inspector.ainspect_conversation(messages, metadata)
        except Exception:
            logger.exception("AI Defense prompt inspection failed")
            if not self._fail_open and self._llm_mode == "enforce":
                return LlmResponse(
                    content=types.Content(
                        role="model",
                        parts=[types.Part(text="Request blocked: AI Defense inspection unavailable.")],
                    ),
                )
            return None
        logger.debug("AI Defense: prompt result (allows=%s, action=%s)", decision.allows(), decision.action)

        if not decision.allows():
            logger.warning(
                "AI Defense: prompt violation (action=%s, severity=%s, event_id=%s)",
                decision.action,
                decision.severity,
                decision.event_id,
            )
            if self._on_violation:
                try:
                    self._on_violation(decision)
                except Exception:
                    logger.debug("on_violation callback raised", exc_info=True)

            if self._llm_mode == "enforce":
                return LlmResponse(
                    content=types.Content(
                        role="model",
                        parts=[types.Part(text="Request blocked by Cisco AI Defense policy.")],
                    ),
                )
        return None

    async def after_model_callback(
        self,
        *,
        callback_context: CallbackContext,
        llm_response: LlmResponse,
    ) -> Optional[LlmResponse]:
        """Inspect the LLM response before it is returned to the agent."""
        if self._llm_mode == "off":
            return None

        response_text = extract_model_text(llm_response)
        if not response_text:
            return None

        messages = [
            {"role": "user", "content": "(prior turn)"},
            {"role": "assistant", "content": response_text},
        ]
        metadata = {"src_app": self._app_name}

        logger.debug("AI Defense: inspecting response (mode=%s)", self._llm_mode)
        try:
            decision = await self._llm_inspector.ainspect_conversation(messages, metadata)
        except Exception:
            logger.exception("AI Defense response inspection failed")
            if not self._fail_open and self._llm_mode == "enforce":
                return LlmResponse(
                    content=types.Content(
                        role="model",
                        parts=[types.Part(text="Response blocked: AI Defense inspection unavailable.")],
                    ),
                )
            return None
        logger.debug("AI Defense: response result (allows=%s, action=%s)", decision.allows(), decision.action)

        if not decision.allows():
            logger.warning(
                "AI Defense: response violation (action=%s, severity=%s, event_id=%s)",
                decision.action,
                decision.severity,
                decision.event_id,
            )
            if self._on_violation:
                try:
                    self._on_violation(decision)
                except Exception:
                    logger.debug("on_violation callback raised", exc_info=True)

            if self._llm_mode == "enforce":
                return LlmResponse(
                    content=types.Content(
                        role="model",
                        parts=[types.Part(text="Response blocked by Cisco AI Defense policy.")],
                    ),
                )
        return None

    # ------------------------------------------------------------------
    # Tool callbacks
    # ------------------------------------------------------------------

    async def before_tool_callback(
        self,
        *,
        tool: BaseTool,
        tool_args: dict[str, Any],
        tool_context: ToolContext,
    ) -> Optional[dict]:
        """Inspect a tool call request before the tool executes."""
        if self._mcp_mode == "off":
            return None

        metadata = {"src_app": self._app_name}

        logger.debug("AI Defense: inspecting tool request (tool=%s, mode=%s)", tool.name, self._mcp_mode)
        try:
            decision = await self._mcp_inspector.ainspect_request(
                tool_name=tool.name,
                arguments=tool_args,
                metadata=metadata,
                method="tools/call",
            )
        except Exception:
            logger.exception("AI Defense tool-request inspection failed (tool=%s)", tool.name)
            if not self._fail_open and self._mcp_mode == "enforce":
                return build_tool_block_payload(
                    tool_name=tool.name,
                    stage="tool_request",
                    reason="AI Defense inspection unavailable",
                )
            return None
        logger.debug("AI Defense: tool request result (tool=%s, allows=%s)", tool.name, decision.allows())

        if not decision.allows():
            logger.warning(
                "AI Defense: tool-request violation (tool=%s, action=%s, severity=%s)",
                tool.name,
                decision.action,
                decision.severity,
            )
            if self._on_violation:
                try:
                    self._on_violation(decision)
                except Exception:
                    logger.debug("on_violation callback raised", exc_info=True)

            if self._mcp_mode == "enforce":
                return build_tool_block_payload(
                    tool_name=tool.name,
                    stage="tool_request",
                    inspection=decision,
                )
        return None

    async def after_tool_callback(
        self,
        *,
        tool: BaseTool,
        tool_args: dict[str, Any],
        tool_context: ToolContext,
        result: dict,
    ) -> Optional[dict]:
        """Inspect a tool call result after the tool executes."""
        if self._mcp_mode == "off":
            return None

        metadata = {"src_app": self._app_name}

        logger.debug("AI Defense: inspecting tool response (tool=%s, mode=%s)", tool.name, self._mcp_mode)
        try:
            decision = await self._mcp_inspector.ainspect_response(
                tool_name=tool.name,
                arguments=tool_args,
                result=result,
                metadata=metadata,
                method="tools/call",
            )
        except Exception:
            logger.exception("AI Defense tool-response inspection failed (tool=%s)", tool.name)
            if not self._fail_open and self._mcp_mode == "enforce":
                return build_tool_block_payload(
                    tool_name=tool.name,
                    stage="tool_response",
                    reason="AI Defense inspection unavailable",
                )
            return None
        logger.debug("AI Defense: tool response result (tool=%s, allows=%s)", tool.name, decision.allows())

        if not decision.allows():
            logger.warning(
                "AI Defense: tool-response violation (tool=%s, action=%s, severity=%s)",
                tool.name,
                decision.action,
                decision.severity,
            )
            if self._on_violation:
                try:
                    self._on_violation(decision)
                except Exception:
                    logger.debug("on_violation callback raised", exc_info=True)

            if self._mcp_mode == "enforce":
                return build_tool_block_payload(
                    tool_name=tool.name,
                    stage="tool_response",
                    inspection=decision,
                )
        return None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def close(self) -> None:
        """Release resources held by inspection clients."""
        for inspector in (self._llm_inspector, self._mcp_inspector):
            if inspector is not None and hasattr(inspector, "close"):
                try:
                    inspector.close()
                except Exception:
                    logger.debug("Error closing inspector", exc_info=True)
        self._llm_inspector = None
        self._mcp_inspector = None
