# Jentic API Tools - Analyze

Multi-backend OpenAPI validation using Redocly, Spectral, Speclynx, and optional LLM-powered semantic analysis. Produces unified diagnostics with severity, source, and structured metadata.

## Key Features

The `OpenAPIAnalyzer` class validates specs against multiple backends in parallel. Redocly checks standards compliance, Spectral applies linting rules, the Speclynx backend uses the ApiDOM engine with custom JavaScript plugins for reference resolution analysis, and the optional semantic backend uses LLMs to evaluate description clarity. Each backend produces `JenticDiagnostic` objects with consistent severity levels. Error handling wraps each backend so failures don't block others.

## Dependencies

Internal: `jentic.apitools.common`, `jentic.apitools.llm`. External: jentic-openapi-validator (with redocly, spectral, and speclynx backends), DeepDiff.

## Installation

```bash
pip install jentic-apitools-analyze
```

## Quick Start

```python
from jentic.apitools.analyze.openapi_analyzer import OpenAPIAnalyzer
from jentic.apitools.common.models import DiagnosticTarget

analyzer = OpenAPIAnalyzer()
diagnostics = analyzer.analyze(
    "file:///path/to/spec.json",
    base_url="https://api.example.com",
    target=DiagnosticTarget.BUNDLED_SPEC,
)
print(f"Found {len(diagnostics)} issues")
```

## Testing

```bash
pytest tests -v
```
