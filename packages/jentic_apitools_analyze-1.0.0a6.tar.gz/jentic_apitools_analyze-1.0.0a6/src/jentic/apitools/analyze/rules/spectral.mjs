/**
 * JavaScript Ruleset Format: https://docs.stoplight.io/docs/spectral/aa15cdee143a1-java-script-ruleset-format
 */

import { oas3, oas3_0, oas3_1 } from '@stoplight/spectral-formats';
import { truthy, falsy, pattern, enumeration, schema, defined, xor } from '@stoplight/spectral-functions';
import { oasExample } from '@stoplight/spectral-rulesets/dist/oas/functions/index.js';
import oasRuleset from '@stoplight/spectral-rulesets/dist/oas/index.js';

// Custom function: checks that schemas using oneOf with object variants
// have a discriminator defined. Replaces the JSONPath `^` parent approach
// which incorrectly navigated to the oneOf array instead of the schema object.
const oneOfObjectsNeedDiscriminator = (targetVal) => {
  if (!targetVal || !Array.isArray(targetVal.oneOf)) return [];

  const hasObjectVariant = targetVal.oneOf.some(item =>
    item && (item.type === 'object' || item.properties || item.allOf || item.anyOf || item.$ref)
  );
  if (!hasObjectVariant) return [];
  if (targetVal.discriminator) return [];

  return [{
    message: 'When modeling object polymorphism with oneOf, define a discriminator for reliable deserialization.',
  }];
};

// Custom wrapper around oasExample that skips XML-related examples
const oasExampleNonXml = (targetVal, opts, context) => {
  const path = context.path || [];
  const pathString = path.join('.');

  // Case 1: Media Type Objects - filter by media type in path
  // Path format: paths./station-timetables.get.responses[200].content.application/xml.examples
  // Matches patterns like: .content.application/xml. or .content.image/svg+xml.
  if (pathString.match(/\.content\.[^.]*(\/xml|\+xml)\b/i)) {
    return [];
  }

  // Case 2 & 3: Header/Parameter Objects - check if their schema has xml property
  // Path format: paths./stations.get.parameters[0].schema or paths./.headers.X-Custom.schema
  // The targetVal is the object with schema and example/examples
  if (targetVal && targetVal.schema && targetVal.schema.xml) {
    return [];
  }

  // Otherwise, delegate to the original oasExample function
  return oasExample(targetVal, opts, context);
};

export default {
  extends: [oasRuleset],

  rules: {
    'oas3-schema': 'error',
    'oas3-server-trailing-slash': 'warn',

    // --- MEDIA EXAMPLES ---
    // Override to skip XML media type validation using custom wrapper function
    'oas3-valid-media-example': {
      description: 'Examples must be valid against their defined schema (non-XML media only).',
      message: '{{error}}',
      severity: 'warn',
      formats: [oas3],
      given: [
        '$..content..[?(@ && @.schema && (@.example !== void 0 || @.examples))]',
        '$..headers..[?(@ && @.schema && (@.example !== void 0 || @.examples))]',
        '$..parameters..[?(@ && @.schema && (@.example !== void 0 || @.examples))]',
      ],
      then: {
        function: oasExampleNonXml,
        functionOptions: {
          schemaField: 'schema',
          oasVersion: 3,
          type: 'media'
        }
      }
    },

    // --- SCHEMA EXAMPLES ---
    // Override to skip schemas that have an xml property at the top level
    'oas3-valid-schema-example': {
      description: 'Examples must be valid against their defined schema (skip schemas that declare XML mapping).',
      message: '{{error}}',
      severity: 'warn',
      formats: [oas3],
      given: [
        "$.components.schemas..[?(@property !== 'properties' && @ && (@.example !== void 0 || @.default !== void 0) && (@.enum || @.type || @.format || @.$ref || @.properties || @.items) && !@.xml)]",
        "$..content..[?(@property !== 'properties' && @ && (@.example !== void 0 || @.default !== void 0) && (@.enum || @.type || @.format || @.$ref || @.properties || @.items) && !@.xml)]",
        "$..headers..[?(@property !== 'properties' && @ && (@.example !== void 0 || @.default !== void 0) && (@.enum || @.type || @.format || @.$ref || @.properties || @.items) && !@.xml)]",
        "$..parameters..[?(@property !== 'properties' && @ && (@.example !== void 0 || @.default !== void 0) && (@.enum || @.type || @.format || @.$ref || @.properties || @.items) && !@.xml)]"
      ],
      then: {
        function: oasExample,
        functionOptions: {
          schemaField: '$',
          oasVersion: 3,
          type: 'schema'
        }
      }
    },

    // Author: Frank Kilcommins (https://github.com/frankkilcommins)
    'no-errors-without-content': {
      message: 'Error responses MUST describe the error',
      description: 'Error responses should describe the error that occurred. This is useful for the API consumer to understand what went wrong and how to fix it. Please provide a description of the error in the response.',
      given: '$.paths[*]..responses[?(@property.match(/^(4|5)/))]',
      then: {
        field: 'content',
        function: truthy,
      },
      formats: [oas3],
      severity: 'warn',
    },

    // Author: Phil Sturgeon (https://github.com/philsturgeon)
    'no-unknown-error-format': {
      message: 'Error response should use a standard error format.',
      description: 'Error responses can be unique snowflakes, different to every API, but standards exist to make them consistent, which reduces surprises and increase interoperability. Please use either RFC 7807 (https://tools.ietf.org/html/rfc7807) or the JSON:API Error format (https://jsonapi.org/format/#error-objects).',
      given: '$.paths[*]..responses[?(("" + @property).match(/^(4|5)/))].content.*~',
      then: {
        function: enumeration,
        functionOptions: {
          values: [
            'application/vnd.api+json',
            'application/problem+json',
            'application/problem+xml',
          ],
        },
      },
      formats: [oas3],
      severity: 'warn',
    },

    // ──────────────────────────────────────────────────────────────────────────────
    // invalid_model_shape: type: object but no useful shape
    // Allow any of:
    //   - properties
    //   - allOf / anyOf / oneOf
    //   - additionalProperties (3.0+) or unevaluatedProperties (3.1)
    //   - explicit empty object is NOT allowed unless AP/UP is set
    // ──────────────────────────────────────────────────────────────────────────────
    'jentic-object-should-have-shape': {
      description: 'Schemas with type: object should define properties, composition, or allow (un)evaluated properties.',
      severity: 'warn',
      formats: [oas3_0, oas3_1],
      given: "$..[?(@ && @.type==='object')]",
      then: {
        function: schema,
        functionOptions: {
          schema: {
            anyOf: [
              { required: ['properties'] },
              { required: ['allOf'] },
              { required: ['anyOf'] },
              { required: ['oneOf'] },
              {
                properties: {
                  additionalProperties: {},
                },
                required: ['additionalProperties'],
              },
              {
                properties: {
                  unevaluatedProperties: {}, // OAS 3.1 / JSON Schema 2020-12
                },
                required: ['unevaluatedProperties'],
              },
            ],
          },
        },
      },
    },

    // ──────────────────────────────────────────────────────────────────────────────
    // contradictory_typing: type/format mismatches
    //
    // Note: JSON Schema treats "format" as annotation; this rule is opinionated:
    // numeric formats → number/integer; date*/byte/binary/password → string
    // ──────────────────────────────────────────────────────────────────────────────
    'jentic-format-must-match-type-numeric': {
      description: 'Numeric formats (int32,int64,float,double) must use type: integer/number.',
      severity: 'warn',
      formats: [oas3_0, oas3_1],
      given: "$..[?(@ && @.format && (@.format==='int32' || @.format==='int64' || @.format==='float' || @.format==='double'))]",
      then: {
        function: schema,
        functionOptions: {
          schema: {
            anyOf: [
              {
                properties: {
                  type: {
                    enum: ['integer', 'number'],
                  },
                },
                required: ['type'],
              },
              // Also accept composed schemas that set type via allOf/anyOf/oneOf
              {
                anyOf: [
                  { required: ['allOf'] },
                  { required: ['anyOf'] },
                  { required: ['oneOf'] },
                ],
              },
            ],
          },
        },
      },
    },

    'jentic-format-must-match-type-stringy': {
      description: 'Stringy formats (date, date-time, byte, binary, password, email, uri) must use type: string.',
      severity: 'warn',
      formats: [oas3_0, oas3_1],
      given: "$..[?(@ && @.format && (@.format==='date' || @.format==='date-time' || @.format==='byte' || @.format==='binary' || @.format==='password' || @.format==='email' || @.format==='uri'))]",
      then: {
        field: 'type',
        function: pattern,
        functionOptions: {
          // accept string or union including string (looser via pattern over direct const)
          match: '^string$',
        },
      },
    },

    // ──────────────────────────────────────────────────────────────────────────────
    // broken_polymorphism: oneOf without discriminator for object unions
    // (Opinionated: OAS does not *require* discriminator; we recommend it.)
    // ──────────────────────────────────────────────────────────────────────────────
    'jentic-oneof-requires-discriminator-for-objects': {
      description: 'When modeling object polymorphism with oneOf, define a discriminator for reliable deserialization.',
      severity: 'warn',
      formats: [oas3_0, oas3_1],
      given: "$..[?(@ && @.oneOf)]",
      then: {
        function: oneOfObjectsNeedDiscriminator,
      },
    },

    // ──────────────────────────────────────────────────────────────────────────────
    // request_response_undefined: empty/missing schemas in request/response bodies
    // ──────────────────────────────────────────────────────────────────────────────
    'jentic-request-body-must-have-schema': {
      description: 'requestBody.content.* must define a non-empty schema.',
      severity: 'warn',
      formats: [oas3_0, oas3_1],
      given: '$.paths..requestBody.content.*',
      then: {
        field: 'schema',
        function: truthy,
      },
    },

    'jentic-response-content-should-have-schema': {
      description: 'responses.*.content.* should define a schema (except for truly no-body responses).',
      severity: 'warn',
      formats: [oas3_0, oas3_1],
      given: '$.paths..responses.*.content.*',
      then: {
        field: 'schema',
        function: truthy,
      },
    },

    // from https://github.com/apisyouwonthate/style-guide

    // Author: Phil Sturgeon (https://github.com/philsturgeon)
    'api-health': {
      message: 'APIs MUST have a health path (`/health`) defined.',
      description: 'Creating a `/health` endpoint is a simple solution for pull-based monitoring and manually checking the status of an API. To learn more about health check endpoints see https://apisyouwonthate.com/blog/health-checks-with-kubernetes.',
      given: '$.paths',
      then: {
        field: '/health',
        function: truthy,
      },
      severity: 'warn',
    },

    // Author: Phil Sturgeon (https://github.com/philsturgeon)
    'api-health-format': {
      message: 'Health path (`/health`) SHOULD support Health Check Response Format',
      description: 'Use existing standards (and draft standards) wherever possible, like the draft standard for health checks: https://datatracker.ietf.org/doc/html/draft-inadarei-api-health-check. To learn more about health check endpoints see https://apisyouwonthate.com/blog/health-checks-with-kubernetes.',
      formats: [oas3],
      given: '$.paths[/health]..responses[*].content.*~',
      then: {
        function: enumeration,
        functionOptions: {
          values: ['application/health+json'],
        },
      },
      severity: 'warn',
    },

    // Author: Phil Sturgeon (https://github.com/philsturgeon)
    'no-http-basic': {
      message: 'Please consider a more secure alternative to HTTP Basic.',
      description: "HTTP Basic is an inherently insecure way to pass credentials to the API. They're placed in the URL in base64 which can be decrypted easily. Even if you're using a token, there are far better ways to handle passing tokens to an API which are less likely to leak.\n\nSee OWASP advice: https://github.com/OWASP/API-Security/blob/master/2019/en/src/0xa2-broken-user-authentication.md",
      given: '$.components.securitySchemes[*]',
      then: {
        field: 'scheme',
        function: pattern,
        functionOptions: {
          notMatch: 'basic',
        },
      },
      severity: 'warn',
    },

    // Author: Phil Sturgeon (https://github.com/philsturgeon)
    'no-x-headers': {
      message: 'Header `{{property}}` should not start with "X-".',
      description: "Headers starting with X- is an awkward convention which is entirely unnecessary. There is probably a standard for what you're trying to do, so it would be better to use that. If there is not a standard already perhaps there's a draft that you could help mature through use and feedback.\n\nSee what you can find on https://standards.rest.\n\nMore about X- headers here: https://tools.ietf.org/html/rfc6648.",
      given: "$..parameters[?(@ && @.in==='header')].name",
      then: {
        function: pattern,
        functionOptions: {
          notMatch: '^(x|X)-',
        },
      },
      severity: 'warn',
    },

    // Author: Phil Sturgeon (https://github.com/philsturgeon)
    'no-x-response-headers': {
      message: 'Header `{{property}}` should not start with "X-".',
      description: "Headers starting with X- is an awkward convention which is entirely unnecessary. There is probably a standard for what you're trying to do, so it would be better to use that. If there is not a standard already perhaps there's a draft that you could help mature through use and feedback.\n\nSee what you can find on https://standards.rest.\n\nMore about X- headers here: https://tools.ietf.org/html/rfc6648.",
      given: '$..headers.*~',
      then: {
        function: pattern,
        functionOptions: {
          notMatch: '^(x|X)-',
        },
      },
      severity: 'warn',
    },

    // Author: Andrzej (https://github.com/jerzyn)
    'request-GET-no-body-oas3': {
      message: 'A `GET` request MUST NOT accept a request body.',
      description: 'Defining a request body on a HTTP GET is supported in some implementations, but is increasingly frowned upon due to the confusion that comes from unspecified behavior in the HTTP specification.',
      given: '$.paths..get.requestBody',
      then: {
        // In YAML we can use the built-in 'falsy' to fail if a requestBody exists.
        function: falsy,
      },
      formats: [oas3],
      severity: 'warn',
    },

    // Author: Andrzej (https://github.com/jerzyn)
    'hosts-https-only-oas3': {
      message: 'Servers MUST be https and no other protocol is allowed.',
      description: 'Using http in production is reckless, advised against by OWASP API Security, and generally unnecessary thanks to free SSL on loads of hosts, gateways like Cloudflare, and OSS tools like Lets Encrypt.',
      given: '$.servers..url',
      then: {
        function: pattern,
        functionOptions: {
          match: '^https:',
        },
      },
      formats: [oas3],
      severity: 'warn',
    },

    // from https://github.com/digitalocean/openapi/blob/main/spectral/ruleset.yml

    'params-must-include-examples': {
      description: 'Parameters must include examples',
      given: '$..parameters.*',
      severity: 'warn',
      message: '{{description}}; missing {{property}}',
      then: {
        function: xor,
        functionOptions: {
          properties: [
            'example',
            'examples',
          ],
        },
      },
    },

    // from https://github.com/team-monite/api-style-guide/blob/main/spectral

    'monite-openapi-schema-in-name': {
      message: 'The schema name should not have "Schema" in it, this is redundant',
      severity: 'info',
      given: '$.components.schemas.*~',
      then: {
        function: pattern,
        functionOptions: {
          notMatch: '(Schema)',
        },
      },
    },

    'monite-openapi-operation-summary': {
      message: 'Each operation should have a summary',
      severity: 'info',
      given: '$.paths.*[get,post,patch,put,delete,options,head,trace]',
      then: {
        field: 'summary',
        function: truthy,
      },
    },

    'monite-openapi-operation-summary-sentence-case': {
      message: 'Operation summaries should start with a capital letter',
      severity: 'info',
      given: '$.paths.*.*.summary',
      then: {
        function: pattern,
        functionOptions: {
          match: '^[A-Z].*',
        },
      },
    },

    'monite-openapi-number-boundaries': {
      message: 'Numeric types need to have their minimum and maximum defined',
      severity: 'info',
      given: [
        "$..properties[?(@ && @.type==='number')]",
        "$..properties[?(@ && @.type==='integer')]",
      ],
      then: [
        {
          field: 'maximum',
          function: defined,
        },
        {
          field: 'minimum',
          function: defined,
        },
      ],
    },

    'monite-general-exposing-internals': {
      message: 'Potentially exposing internals (words "private" or "internal" spotted)',
      severity: 'warn',
      given: [
        '$.info.title',
        '$.info.summary',
        '$.info.description',
        '$.paths.*~',
        "$.paths.*.*.parameters[?(@ && (@.in==='query' || @.in==='path' || @.in==='cookie'))].name",
        "$.paths.*.*.parameters[?(@ && (@.in==='query' || @.in==='path' || @.in==='cookie'))].description",
        '$.components.schemas.*~',
        '$..properties.*~',
      ],
      then: {
        function: pattern,
        functionOptions: {
          notMatch: '(internal|Internal|private|Private)',
        },
      },
    },

    'monite-security-no-secrets-in-path-or-query-parameters': {
      message: 'Secrets, tokens, passwords and api keys must be passed in headers, not in path or query parameters',
      severity: 'warn',
      given: [
        "$..parameters[?(@ && @.in==='path')].name",
        "$..parameters[?(@ && @.in==='query')].name",
      ],
      then: {
        function: pattern,
        functionOptions: {
          notMatch: '(client_secret|token|access_token|refresh_token|id_token|password|secret|apikey)',
        },
      },
    },

    'monite-data-missing-integer-format': {
      message: 'Format is not specified for an integer property',
      severity: 'info',
      given: "$.paths.*.*..schema..properties[?(@ && @.type==='integer')]",
      then: {
        field: 'format',
        function: defined,
      },
    },

    'monite-data-missing-number-format': {
      message: 'Format is not specified for a number property',
      severity: 'info',
      given: "$.paths.*.*..schema..properties[?(@ && @.type==='number')]",
      then: {
        field: 'format',
        function: defined,
      },
    },

    'monite-data-incorrect-integer-format': {
      message: 'Incorrect integer format: {{value}}. Must be one of: int32, int64',
      severity: 'warn',
      given: "$..[?(@ && @.type==='integer')]",
      then: {
        field: 'format',
        function: enumeration,
        functionOptions: {
          values: [
            'int32',
            'int64',
          ],
        },
      },
    },

    'monite-data-incorrect-number-format': {
      message: 'Incorrect number format: {{value}}. Must be one of: float, double',
      severity: 'warn',
      given: "$..[?(@ && @.type==='number')]",
      then: {
        field: 'format',
        function: enumeration,
        functionOptions: {
          values: [
            'float',
            'double',
          ],
        },
      },
    },

    'monite-uri-no-empty-path-segments': {
      message: 'Empty path segments are not allowed',
      severity: 'error',
      given: '$.paths.*~',
      then: {
        function: pattern,
        functionOptions: {
          notMatch: '//',
        },
      },
    },
  },
};
