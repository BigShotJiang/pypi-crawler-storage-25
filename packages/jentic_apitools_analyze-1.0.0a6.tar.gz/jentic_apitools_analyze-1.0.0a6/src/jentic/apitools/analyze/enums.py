"""Shared enums for the scoring module."""

from enum import Enum


__all__ = ["DiagnosticCode"]


class DiagnosticCode(str, Enum):
    """Diagnostic codes produced by the scoring validator backends.

    These codes identify specific diagnostics that can be referenced
    by signal calculators to declare their dependencies.

    Note: This enum covers diagnostics from validation backends (speclynx, redocly, spectral, semantic).
    External diagnostic codes (e.g., from Spectral linter) should be referenced
    as plain strings in signal metadata.
    """

    TOTAL_OPERATIONS = "total_operations"
    OPERATIONS_USING_RFC9457 = "operations_using_RFC9457"
    OPERATIONS_WITH_OPERATIONID = "operations_with_operationId"
    SCHEMA_COUNT = "schema_count"
    SECURITY_SCHEME_COUNT = "security_scheme_count"
    SECURITY_SCHEME_TYPES = "security_scheme_types"
    SECURITY_SCHEMES = "security_schemes"
    TAG_COUNT = "tag_count"
    SCHEMA_INVALID_MIN_MAX = "schema_invalid_min_max"
    EXPECTED_EXAMPLES = "expected_examples"
    PRESENT_EXAMPLES = "present_examples"
    TOTAL_EXAMPLES = "total_examples"
    SUMMARIES_EXPECTED = "summaries_expected"
    SUMMARIES_PRESENT = "summaries_present"
    DESCRIBABLE_ELEMENTS = "describable_elements"
    DESCRIBED_ELEMENTS = "described_elements"
    MAX_SCHEMA_DEPTH = "max_schema_depth"
    TOTAL_REFS = "total_refs"
    RESOLVED_REFS = "resolved_refs"
    SEMANTIC_ANALYSIS_SUMMARY = "semantic-analysis-summary"
    POOR_OPERATION_SEMANTICS = "POOR_OPERATION_SEMANTICS"
    AMBIGUOUS_OPERATION_ID = "ambiguous_operation_id"
    OPERATION_ID_CASING = "operation_id_casing"
    OPERATION_RESPONSE_COVERAGE = "operation_response_coverage"
