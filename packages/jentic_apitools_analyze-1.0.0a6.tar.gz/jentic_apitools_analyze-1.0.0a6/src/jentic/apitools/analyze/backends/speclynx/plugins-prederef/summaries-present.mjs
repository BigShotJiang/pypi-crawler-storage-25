/**
 * Pre-deref visitor plugin that counts elements that HAVE summaries.
 *
 * Tracks elements with a non-empty summary value. Runs before dereferencing
 * to avoid counting duplicates from inlined $ref expansions.
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @returns {Object} Object with visitor and post() for diagnostics
 */
import getHelpers from '../helpers.mjs';

export default (toolbox) => {
    const {diagnostics, deps} = toolbox;
    const {toValue} = deps['@speclynx/apidom-core'];
    const {isStringElement} = deps['@speclynx/apidom-datamodel'];
    const {cachedFixedFields, createDiagnostic} = getHelpers(deps);

    let count = 0;
    const paths = [];

    return {
        visitor: {
            enter(path) {
                const fields = cachedFixedFields(path.node);
                if (!('summary' in fields)) return;
                if (!isStringElement(path.node.summary)) return;

                const summary = toValue(path.node.summary);
                if (summary.trim().length === 0) return;

                count++;
                paths.push(path.getPathKeys());
            },
        },
        post() {
            diagnostics.push(createDiagnostic({
                message: `Summaries present: ${count}`,
                code: 'summaries_present',
                data: { summaries_present: count, paths },
            }));
        },
    };
};
