/**
 * Plugin that detects operationId casing styles.
 *
 * Runs after 02-deref.mjs has fully dereferenced the document.
 * For each operation under paths that has an operationId, detects its casing style
 * and produces one diagnostic per operationId.
 *
 * Supported casing styles: camelCase, PascalCase, snake_case, kebab-case,
 * SCREAMING_SNAKE_CASE, lowercase, UPPERCASE, unknown.
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @returns {Object} Plugin object with visitor methods
 */
import getHelpers from '../helpers.mjs';

export default (toolbox) => {
    const {diagnostics, deps} = toolbox;
    const {toValue} = deps['@speclynx/apidom-core'];
    const {isStringElement} = deps['@speclynx/apidom-datamodel'];
    const {createDiagnostic} = getHelpers(deps);

    const casings = [];

    function isScreamingSnakeCase(operationId) {
        if (!operationId.includes('_')) return false;
        return /^[\p{Lu}\p{N}_]+$/u.test(operationId) && /\p{Lu}/u.test(operationId);
    }

    function isSnakeCase(operationId) {
        if (!operationId.includes('_')) return false;
        return /^[\p{Ll}\p{N}_]+$/u.test(operationId) && /\p{Ll}/u.test(operationId);
    }

    function isKebabCase(operationId) {
        if (!operationId.includes('-')) return false;
        return /^[\p{Ll}\p{N}-]+$/u.test(operationId) && /\p{Ll}/u.test(operationId);
    }

    function isPascalCase(operationId) {
        if (!/^[\p{L}\p{N}]+$/u.test(operationId)) return false;
        if (!/\p{Lu}/u.test(operationId) || !/\p{Ll}/u.test(operationId)) return false;
        const firstLetter = operationId.match(/\p{L}/u);
        return firstLetter !== null && firstLetter[0] === firstLetter[0].toUpperCase();
    }

    function isCamelCase(operationId) {
        if (!/^[\p{L}\p{N}]+$/u.test(operationId)) return false;
        if (!/\p{Lu}/u.test(operationId) || !/\p{Ll}/u.test(operationId)) return false;
        const firstLetter = operationId.match(/\p{L}/u);
        return firstLetter !== null && firstLetter[0] === firstLetter[0].toLowerCase();
    }

    function detectCasingStyle(operationId) {
        if (!operationId) return 'unknown';

        // check styles with special delimiters first
        if (isScreamingSnakeCase(operationId)) return 'SCREAMING_SNAKE_CASE';
        if (isSnakeCase(operationId)) return 'snake_case';
        if (isKebabCase(operationId)) return 'kebab-case';

        // check mixed case styles
        if (isPascalCase(operationId)) return 'PascalCase';
        if (isCamelCase(operationId)) return 'camelCase';

        // check single case styles
        if (/^[\p{Lu}\p{N}]+$/u.test(operationId) && /\p{Lu}/u.test(operationId)) return 'UPPERCASE';
        if (/^[\p{Ll}\p{N}]+$/u.test(operationId) && /\p{Ll}/u.test(operationId)) return 'lowercase';

        return 'unknown';
    }

    return {
        visitor: {
            OperationElement(path) {
                // find closest PathItem ancestor
                const pathItemParent = path.findParent((p) => p.node.element === 'pathItem');
                if (!pathItemParent?.node.hasMetaProperty('path')) return path.skip();
                if (!isStringElement(path.node.operationId)) return path.skip();

                const operationId = toValue(path.node.operationId);
                const casing = detectCasingStyle(operationId);

                casings.push({
                    casing,
                    operation_id: operationId,
                    path: [...path.getPathKeys(), 'operationId'],
                });

                path.skip();
            },
        },
        post() {
            for (const entry of casings) {
                diagnostics.push(createDiagnostic({
                    message: `OperationId '${entry.operation_id}' uses ${entry.casing} casing`,
                    code: 'operation_id_casing',
                    data: entry,
                }));
            }
        },
    };
};
