/**
 * Plugin that analyzes response coverage per operation.
 *
 * Runs after 02-deref.mjs has fully dereferenced the document.
 * For each operation under paths, checks which response categories are defined:
 * - 2XX (success responses)
 * - 4XX (client error responses)
 * - 5XX (server error responses)
 * - default response
 *
 * Produces one diagnostic per operation with boolean coverage flags.
 * Wildcards (2XX, 4XX, 5XX) are treated as their respective categories.
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @returns {Object} Plugin object with visitor methods
 */
import getHelpers from '../helpers.mjs';

export default (toolbox) => {
    const {diagnostics, deps} = toolbox;
    const {toValue} = deps['@speclynx/apidom-core'];
    const {createDiagnostic} = getHelpers(deps);

    const operationCoverage = [];

    return {
        visitor: {
            ResponsesElement(path) {
                // find closest PathItem ancestor to check 'path' metadata
                const pathItemParent = path.findParent((p) => p.node.element === 'pathItem');

                if (!pathItemParent?.node.hasMetaProperty('path')) return path.skip();

                let has2XX = false;
                let has4XX = false;
                let has5XX = false;
                let hasDefault = false;

                for (const member of path.node) {
                    if (member.value.element !== 'response') continue;

                    const statusCode = String(toValue(member.key));

                    if (statusCode === 'default') {
                        hasDefault = true;
                    } else if (statusCode.startsWith('2')) {
                        has2XX = true;
                    } else if (statusCode.startsWith('4')) {
                        has4XX = true;
                    } else if (statusCode.startsWith('5')) {
                        has5XX = true;
                    }
                }

                operationCoverage.push({
                    path: path.parentPath.getPathKeys(),
                    '2XX': has2XX,
                    '4XX': has4XX,
                    '5XX': has5XX,
                    'default': hasDefault,
                });

                path.skip();
            },
        },
        post() {
            for (const op of operationCoverage) {
                diagnostics.push(createDiagnostic({
                    message: `Response coverage: 2XX=${op['2XX']}, 4XX=${op['4XX']}, 5XX=${op['5XX']}, default=${op['default']}`,
                    code: 'operation_response_coverage',
                    data: op,
                }));
            }
        },
    };
};
