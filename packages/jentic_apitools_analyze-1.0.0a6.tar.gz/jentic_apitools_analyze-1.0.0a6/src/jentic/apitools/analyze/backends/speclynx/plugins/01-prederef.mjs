/**
 * Plugin that runs pre-dereference visitors in a single sub-traversal.
 *
 * Imports visitor plugins from ../plugins-prederef/ and dispatches them
 * using dispatchRefractorPlugins before 02-deref.mjs modifies the tree.
 * This allows pre-deref plugins to see the original document with $ref fields intact.
 *
 * The full plugin lifecycle (pre, visitor, post) is handled automatically
 * by dispatchRefractorPluginsAsync.
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @returns {Object} Plugin object with visitor methods
 */
import {promisify} from 'node:util';
import totalRefs from '../plugins-prederef/total-refs.mjs';
import schemaCount from '../plugins-prederef/schema-count.mjs';
import describableElements from '../plugins-prederef/describable-elements.mjs';
import describedElements from '../plugins-prederef/described-elements.mjs';
import summariesExpected from '../plugins-prederef/summaries-expected.mjs';
import summariesPresent from '../plugins-prederef/summaries-present.mjs';
import expectedExamples from '../plugins-prederef/expected-examples.mjs';
import presentExamples from '../plugins-prederef/present-examples.mjs';
import totalExamples from '../plugins-prederef/total-examples.mjs';

export default (toolbox) => {
    const {deps} = toolbox;
    const {dispatchRefractorPlugins} = deps['@speclynx/apidom-core'];

    const dispatchRefractorPluginsAsync = promisify(dispatchRefractorPlugins);
    const plugins = [
        totalRefs,
        schemaCount,
        describableElements,
        describedElements,
        summariesExpected,
        summariesPresent,
        expectedExamples,
        presentExamples,
        totalExamples,
    ];

    return {
        visitor: {
            async enter(path) {
                await dispatchRefractorPluginsAsync(path.node, plugins, {
                    toolboxCreator: () => toolbox,
                });
                path.stop();
            },
        },
    };
};
