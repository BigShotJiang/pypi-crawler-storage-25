"""Semantic validator backend for OpenAPI operation quality assessment."""

import json
import os
import random
from collections.abc import Sequence
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Literal

from jentic.apitools.openapi.validator.backends.base import BaseValidatorBackend
from jentic.apitools.openapi.validator.core.diagnostics import JenticDiagnostic, ValidationResult
from lsprotocol.types import DiagnosticSeverity, Position, Range

from jentic.apitools.analyze.backends.semantic.prompts import POOR_OPERATION_SEMANTICS_PROMPT
from jentic.apitools.analyze.enums import DiagnosticCode
from jentic.apitools.common.utils.logging import get_module_logger
from jentic.apitools.llm import LLMError, LLMHelper, LLMTruncatedError
from jentic.apitools.llm.context.semantic_context_builder import (
    batch_operations_smart,
    extract_semantic_context,
    prepare_batch_for_llm,
)


__all__ = ["SemanticValidatorBackend"]

logger = get_module_logger(__name__)


class SemanticValidatorBackend(BaseValidatorBackend):
    """
    Validator backend that uses LLM to assess semantic quality of operation descriptions.

    This backend:
    1. Extracts semantic context once (API info, schemas, security, tags)
    2. Batches operations intelligently (5-10 per batch)
    3. Calls LLM for quality assessment with suggestions
    4. Returns diagnostics with improvement recommendations
    """

    def __init__(self, batch_size: int = 7, max_batches: int = 7, seed: int = 42):
        """
        Initialize the semantic validator backend.

        Args:
            batch_size: Number of operations per LLM call (default: 7)
            max_batches: Maximum number of batches to process (default: 7, None = all)
            seed: Random seed for reproducible batch sampling (default: 42)
        """
        self.batch_size = batch_size
        self.max_batches = max_batches
        self.seed = seed

    def validate(
        self, document: str | dict, *, base_url: str | None = None, target: str | None = None
    ) -> ValidationResult:
        """
        Validate semantic quality of operation descriptions using LLM.

        Args:
            document: OpenAPI specification (dict format required)
            base_url: Optional base URL (not used)
            target: Optional target identifier for diagnostics

        Returns:
            ValidationResult with diagnostics for operations needing improvement
        """
        source = "semantic_analyzer"

        logger.info("validate start")
        # Validate input format
        if not isinstance(document, dict):
            diagnostic = JenticDiagnostic(
                range=Range(
                    start=Position(line=0, character=0),
                    end=Position(line=0, character=12),
                ),
                severity=DiagnosticSeverity.Error,
                code="validation-error-dict-required",
                source=source,
                message="SemanticAnalyzerBackend only accepts dict format",
            )
            diagnostic.set_target(target)
            return ValidationResult(diagnostics=[diagnostic])

        diagnostics: list[JenticDiagnostic] = []
        try:
            # Initialize LLM helper
            llm_helper = LLMHelper(light_mode=True)

            # Step 1: Extract semantic context once
            semantic_context = extract_semantic_context(document)

            # Step 2: Batch operations intelligently with token-aware sizing
            # Use max_tokens=8000 for smart batching (matches LLM call max_tokens)
            batches = batch_operations_smart(document, self.batch_size, max_output_tokens=8000)

            # Randomly sample batches if we have more than max_batches
            if isinstance(self.max_batches, int) and self.max_batches < len(batches):
                rng = random.Random(self.seed)
                batches = rng.sample(batches, self.max_batches)

            # Step 3: Process batches in parallel with LLM
            total_operations_analyzed = 0
            total_issues_found = 0
            max_workers = int(os.getenv("LLM_MAX_ANALYSIS_WORKERS") or 7)
            batch_timeout = int(os.getenv("LLM_ANALYSIS_TIMEOUT") or 300)  # 5 min default

            logger.info(f"Processing {len(batches)} batches with {max_workers} workers")

            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {
                    executor.submit(
                        self._process_batch,
                        batch_idx,
                        operations_batch,
                        semantic_context,
                        llm_helper,
                        target,
                        source,
                    ): batch_idx
                    for batch_idx, operations_batch in enumerate(batches)
                }

                try:
                    for future in as_completed(futures, timeout=batch_timeout):
                        batch_idx = futures[future]
                        try:
                            batch_diagnostics, ops_analyzed, issues = future.result()
                            diagnostics.extend(batch_diagnostics)
                            total_operations_analyzed += ops_analyzed
                            total_issues_found += issues
                        except Exception as e:
                            logger.exception(f"Batch {batch_idx} failed unexpectedly: {e}")
                except TimeoutError:
                    logger.warning(f"Timeout waiting for batch completion after {batch_timeout}s")

            logger.info(
                f"Parallel processing completed: {total_operations_analyzed} operations, {total_issues_found} issues"
            )

            # Add summary diagnostic
            summary_diagnostic = JenticDiagnostic(
                range=Range(
                    start=Position(line=0, character=0),
                    end=Position(line=0, character=12),
                ),
                severity=DiagnosticSeverity.Information,
                code=DiagnosticCode.SEMANTIC_ANALYSIS_SUMMARY,
                source=source,
                message=f"Semantic analysis completed: {total_operations_analyzed} operations analyzed, {total_issues_found} quality issues found",
            )
            if target:
                summary_diagnostic.set_target(target)
            summary_diagnostic.set_data_field(
                "total_operations_analyzed", total_operations_analyzed
            )
            summary_diagnostic.set_data_field("total_issues_found", total_issues_found)
            summary_diagnostic.set_data_field("batches_processed", len(batches))
            diagnostics.append(summary_diagnostic)

        except Exception as e:
            # Catch-all for unexpected errors
            error_diagnostic = JenticDiagnostic(
                range=Range(
                    start=Position(line=0, character=0),
                    end=Position(line=0, character=12),
                ),
                severity=DiagnosticSeverity.Error,
                code="semantic-analysis-failed",
                source=source,
                message=f"Semantic analysis failed: {str(e)}",
            )
            if target:
                error_diagnostic.set_target(target)
            diagnostics.append(error_diagnostic)

        return ValidationResult(diagnostics)

    def _process_batch(
        self,
        batch_idx: int,
        operations_batch: list,
        semantic_context: dict,
        llm_helper: LLMHelper,
        target: str | None,
        source: str,
    ) -> tuple[list[JenticDiagnostic], int, int]:
        """Process a single batch of operations with LLM - designed for parallel execution.

        Args:
            batch_idx: Index of this batch
            operations_batch: List of operations to analyze
            semantic_context: Semantic context for the API
            llm_helper: LLM helper instance
            target: Target identifier for diagnostics
            source: Source identifier for diagnostics

        Returns:
            Tuple of (diagnostics, operations_analyzed, issues_found)
        """
        batch_diagnostics: list[JenticDiagnostic] = []
        operations_analyzed = 0
        issues_found = 0

        if not operations_batch:
            return batch_diagnostics, operations_analyzed, issues_found

        # Prepare context for LLM
        batch_context = prepare_batch_for_llm(semantic_context, operations_batch)
        # Build LLM prompts
        system_prompt = self._build_system_prompt(batch_context)
        user_prompt = self._build_user_prompt(batch_context)

        try:
            llm_response = llm_helper.call_llm(
                prompt=user_prompt,
                system_prompt=system_prompt,
                max_tokens=8000,  # Allow for detailed responses
            )
            # Parse LLM response
            parsed_response = llm_helper.parse_llm_json(llm_response)
            if not parsed_response or not parsed_response.get("success"):
                # LLM failed to analyze this batch
                return batch_diagnostics, operations_analyzed, issues_found

            # Extract operation suggestions
            suggestions = parsed_response.get("output", [])
            if not isinstance(suggestions, list):
                return batch_diagnostics, operations_analyzed, issues_found

            # Build lookup for operation context by operation_id
            op_lookup = {op["operation_id"]: op for op in operations_batch}

            # Create diagnostics for operations with quality issues
            for suggestion in suggestions:
                if not isinstance(suggestion, dict):
                    continue
                operations_analyzed += 1

                has_issues = suggestion.get("has_quality_issues", False)
                if not has_issues:
                    continue

                issues_found += 1

                # Create diagnostic for this operation
                operation_id = suggestion.get("operation_id", "unknown")
                issues_list = suggestion.get("issues_found", [])
                reasoning = suggestion.get("reasoning", "")

                message = (
                    f"Operation '{operation_id}' has semantic quality issues: "
                    f"{', '.join(issues_list)}. {reasoning}"
                )

                diagnostic = JenticDiagnostic(
                    range=Range(
                        start=Position(line=0, character=0),
                        end=Position(line=0, character=0),
                    ),
                    severity=DiagnosticSeverity.Warning,
                    code=DiagnosticCode.POOR_OPERATION_SEMANTICS,
                    source=source,
                    message=message,
                )

                if target:
                    diagnostic.set_target(target)

                # Attach suggestion data for fixer to use
                diagnostic.set_data_field("operation_id", operation_id)
                diagnostic.set_data_field("has_quality_issues", has_issues)
                diagnostic.set_data_field("issues_found", issues_list)
                diagnostic.set_data_field("current_summary", suggestion.get("current_summary"))
                diagnostic.set_data_field(
                    "current_description", suggestion.get("current_description")
                )
                if (suggestion.get("summary_suggestion") or "").lower().strip() != (
                    suggestion.get("current_summary") or ""
                ).lower().strip():
                    diagnostic.set_data_field(
                        "summary_suggestion", suggestion.get("summary_suggestion")
                    )
                if (suggestion.get("description_suggestion") or "").lower().strip() != (
                    suggestion.get("current_description") or ""
                ).lower().strip():
                    diagnostic.set_data_field(
                        "description_suggestion", suggestion.get("description_suggestion")
                    )
                diagnostic.set_data_field("reasoning", reasoning)
                diagnostic.set_data_field("batch_index", batch_idx)

                # Add path for the operation (always at operation level)
                matching_op = op_lookup.get(operation_id)
                if matching_op:
                    operation_path = ["paths", matching_op["path"], matching_op["method"].lower()]
                    diagnostic.set_path(operation_path)

                    # Add paths for specific fields with suggestions
                    field_paths = []
                    if suggestion.get("summary_suggestion"):
                        field_paths.append([*operation_path, "summary"])
                    if suggestion.get("description_suggestion"):
                        field_paths.append([*operation_path, "description"])
                    if field_paths:
                        diagnostic.set_data_field("paths", field_paths)

                batch_diagnostics.append(diagnostic)

        except LLMTruncatedError as e:
            # Log truncation warning - batch was too large for response
            logger.warning(
                f"Batch {batch_idx} truncated: {str(e)} - "
                f"batch had {len(operations_batch)} operations, "
                f"consider reducing batch size or enabling smart batching"
            )
            truncation_diagnostic = JenticDiagnostic(
                range=Range(
                    start=Position(line=0, character=0),
                    end=Position(line=0, character=12),
                ),
                severity=DiagnosticSeverity.Warning,
                code="llm-response-truncated",
                source=source,
                message=f"LLM response truncated for batch {batch_idx}: response exceeded max tokens. "
                f"Batch contained {len(operations_batch)} operations.",
            )
            if target:
                truncation_diagnostic.set_target(target)
            truncation_diagnostic.set_data_field("batch_index", batch_idx)
            truncation_diagnostic.set_data_field("operations_in_batch", len(operations_batch))
            truncation_diagnostic.set_data_field("output_tokens", e.output_tokens)
            truncation_diagnostic.set_data_field("partial_response_length", len(e.partial_response))
            batch_diagnostics.append(truncation_diagnostic)

        except LLMError as e:
            # Log LLM error but continue with other batches
            error_diagnostic = JenticDiagnostic(
                range=Range(
                    start=Position(line=0, character=0),
                    end=Position(line=0, character=12),
                ),
                severity=DiagnosticSeverity.Information,
                code="llm-analysis-error",
                source=source,
                message=f"LLM analysis failed for batch {batch_idx}: {str(e)}",
            )
            if target:
                error_diagnostic.set_target(target)
            batch_diagnostics.append(error_diagnostic)

        return batch_diagnostics, operations_analyzed, issues_found

    def _build_system_prompt(self, batch_context: dict) -> str:
        """Build system prompt with semantic context."""
        semantic_context = batch_context.get("semantic_context", {})

        prompt = "You are an API documentation expert specializing in improving OpenAPI operation descriptions for AI agent interpretability.\n\n"
        prompt += "**API Context:**\n"
        prompt += json.dumps(semantic_context, indent=2)
        prompt += "\n\n"
        prompt += (
            "Use this context to ensure terminology consistency and domain-appropriate suggestions."
        )

        return prompt

    def _build_user_prompt(self, batch_context: dict) -> str:
        """Build user prompt with operations batch."""
        operations = batch_context.get("operations", [])

        prompt = POOR_OPERATION_SEMANTICS_PROMPT

        prompt += "\n\nAnalyze the following operations for semantic quality:\n\n"

        for op in operations:
            prompt += f"**Operation: {op.get('operation_id')}**\n"
            prompt += f"- Path: {op.get('path')}\n"
            prompt += f"- Method: {op.get('method')}\n"
            prompt += f"- Current Summary: {op.get('current_summary', '(none)')}\n"
            prompt += f"- Current Description: {op.get('current_description', '(none)')}\n"

            tags = op.get("tags", [])
            if tags:
                prompt += f"- Tags: {', '.join(tags)}\n"

            params = op.get("parameters", [])
            if params:
                prompt += f"- Parameters: {len(params)} parameter(s)\n"

            request_schema = op.get("request_schema")
            if request_schema:
                prompt += f"- Request Schema: {request_schema if isinstance(request_schema, str) else 'inline'}\n"

            response_schemas = op.get("response_schemas", {})
            if response_schemas:
                prompt += f"- Response Schemas: {', '.join(response_schemas.keys())}\n"

            prompt += "\n"

        prompt += "\nProvide your analysis in the required JSON format as specified above."

        return prompt

    @staticmethod
    def execution_type() -> Literal["io"]:
        return "io"

    @staticmethod
    def accepts() -> Sequence[Literal["dict"]]:
        """Return the document formats this validator can accept.

        Returns:
            Sequence of supported document format identifiers:
            - "dict": Python dictionary containing OpenAPI Document data
        """
        return ["dict"]


# Backward compatibility alias
SemanticAnalyzerBackend = SemanticValidatorBackend
