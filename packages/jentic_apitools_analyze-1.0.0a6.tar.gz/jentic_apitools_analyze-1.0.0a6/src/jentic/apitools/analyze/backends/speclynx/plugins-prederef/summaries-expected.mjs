/**
 * Pre-deref visitor plugin that counts elements that CAN have summaries.
 *
 * Tracks all elements with a summary fixed field, regardless of whether
 * the summary is populated. Runs before dereferencing to avoid counting
 * duplicates from inlined $ref expansions.
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @returns {Object} Object with visitor and post() for diagnostics
 */
import getHelpers from '../helpers.mjs';

export default (toolbox) => {
    const {diagnostics, deps} = toolbox;
    const {cachedFixedFields, createDiagnostic} = getHelpers(deps);

    let count = 0;
    const paths = [];

    return {
        visitor: {
            enter(path) {
                const fields = cachedFixedFields(path.node);
                if (!('summary' in fields)) return;

                count++;
                paths.push(path.getPathKeys());
            },
        },
        post() {
            diagnostics.push(createDiagnostic({
                message: `Summaries expected: ${count}`,
                code: 'summaries_expected',
                data: { summaries_expected: count, paths },
            }));
        },
    };
};
