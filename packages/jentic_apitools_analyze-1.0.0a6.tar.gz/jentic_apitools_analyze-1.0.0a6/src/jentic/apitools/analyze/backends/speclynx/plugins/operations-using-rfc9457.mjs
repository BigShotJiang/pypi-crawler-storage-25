/**
 * Plugin that detects operations using RFC 9457/7807 Problem Details for error responses.
 *
 * Runs after 02-deref.mjs has fully dereferenced the document.
 *
 * An operation is counted as compliant if:
 * - All explicit error responses (4xx, 5xx) use RFC 9457/7807 format, OR
 * - No explicit errors exist but `default` response uses RFC 9457/7807 format
 *
 * Detection uses two tiers:
 * 1. Media type check: application/problem+json or application/problem+xml
 * 2. Schema inspection: schema has at least 2 RFC fields (type, title, status, detail, instance)
 *    under direct properties
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @returns {Object} Plugin object with visitor methods
 */
import getHelpers from '../helpers.mjs';

export default (toolbox) => {
    const {diagnostics, deps} = toolbox;
    const {isObjectElement} = deps['@speclynx/apidom-datamodel'];
    const {toValue} = deps['@speclynx/apidom-core'];
    const {cachedFixedFields, createDiagnostic} = getHelpers(deps);

    const RFC_9457_MEDIA_TYPES = new Set([
        'application/problem+json',
        'application/problem+xml',
    ]);

    const RFC_9457_FIELDS = new Set([
        'type', 'title', 'status', 'detail', 'instance',
    ]);

    const RFC_9457_MIN_FIELDS = 2;

    const rfc9457Paths = [];

    /**
     * Check if a schema has at least RFC_9457_MIN_FIELDS RFC 9457 fields
     * under direct properties.
     */
    function hasRFC9457Schema(schemaElement) {
        if (schemaElement?.element !== 'schema') return false;

        const fields = cachedFixedFields(schemaElement);
        if (!('properties' in fields)) return false;
        if (!isObjectElement(schemaElement.properties)) return false;

        let foundCount = 0;
        for (const member of schemaElement.properties) {
            const propName = toValue(member.key);
            if (RFC_9457_FIELDS.has(propName)) {
                foundCount++;
                if (foundCount >= RFC_9457_MIN_FIELDS) return true;
            }
        }

        return false;
    }

    /**
     * Check if a response uses RFC 9457/7807 Problem Details format.
     */
    function isRFC9457Response(responseElement) {
        if (responseElement?.element !== 'response') return false;
        if (!isObjectElement(responseElement.contentField)) return false;

        for (const member of responseElement.contentField) {
            const mediaType = toValue(member.key);

            // tier 1: check media type
            if (RFC_9457_MEDIA_TYPES.has(mediaType)) return true;

            // tier 2: check schema structure
            if (hasRFC9457Schema(member?.value?.schema)) return true;
        }

        return false;
    }

    return {
        visitor: {
            ResponsesElement(path) {
                // find closest PathItem ancestor to check 'path' metadata
                const pathItemParent = path.findParent((p) => p.node.element === 'pathItem');

                if (!pathItemParent?.node.hasMetaProperty('path')) return path.skip();

                const explicitErrors = [];
                let defaultResponse = null;

                for (const member of path.node) {
                    const statusCode = String(toValue(member.key));

                    if (statusCode === 'default') {
                        defaultResponse = member.value;
                    } else if (statusCode.startsWith('4') || statusCode.startsWith('5')) {
                        explicitErrors.push(member.value);
                    }
                }

                let isCompliant = false;

                if (explicitErrors.length > 0) {
                    // if explicit errors exist, ALL must be RFC compliant
                    isCompliant = explicitErrors.every(isRFC9457Response);
                } else if (defaultResponse && isRFC9457Response(defaultResponse)) {
                    // no explicit errors, but default is RFC compliant
                    isCompliant = true;
                }

                if (isCompliant) {
                    rfc9457Paths.push(path.parentPath.getPathKeys());
                }

                path.skip();
            },
        },
        post() {
            diagnostics.push(createDiagnostic({
                message: `Operations using RFC 9457: ${rfc9457Paths.length}`,
                code: 'operations_using_RFC9457',
                data: { operations_using_RFC9457: rfc9457Paths.length, paths: rfc9457Paths },
            }));
        },
    };
};
