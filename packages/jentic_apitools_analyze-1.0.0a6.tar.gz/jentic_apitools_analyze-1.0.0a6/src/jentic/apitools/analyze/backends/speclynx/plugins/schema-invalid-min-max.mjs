/**
 * Plugin that detects Schema objects with invalid minimum/maximum constraints.
 *
 * Runs after 02-deref.mjs has fully dereferenced the document.
 * Detects schemas where minimum > maximum, which is invalid according to JSON Schema.
 * Produces one Warning diagnostic per invalid schema.
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @returns {Object} Plugin object with visitor methods
 */
import getHelpers from '../helpers.mjs';

export default (toolbox) => {
    const {diagnostics, deps} = toolbox;
    const {toValue} = deps['@speclynx/apidom-core'];
    const {isNumberElement} = deps['@speclynx/apidom-datamodel'];
    const {DiagnosticSeverity} = deps['vscode-languageserver-types'];
    const {createDiagnostic} = getHelpers(deps);

    return {
        visitor: {
            SchemaElement(path) {
                if (!isNumberElement(path.node.minimum)) return;
                if (!isNumberElement(path.node.maximum)) return;

                const minVal = toValue(path.node.minimum);
                const maxVal = toValue(path.node.maximum);

                if (minVal > maxVal) {
                    diagnostics.push(createDiagnostic({
                        message: `Schema has invalid constraints: minimum (${minVal}) > maximum (${maxVal})`,
                        code: 'schema_invalid_min_max',
                        severity: DiagnosticSeverity.Warning,
                        data: { path: path.getPathKeys() },
                    }));
                }
            },
        },
    };
};
