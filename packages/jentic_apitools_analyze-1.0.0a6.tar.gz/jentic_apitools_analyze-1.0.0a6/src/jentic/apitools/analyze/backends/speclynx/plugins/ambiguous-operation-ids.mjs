/**
 * Plugin that detects case-insensitively ambiguous operationIds.
 *
 * Runs after 02-deref.mjs has fully dereferenced the document.
 * Collects all operationIds from operations under paths, then groups them
 * by lowercase value. If multiple operationIds share the same lowercase key,
 * they are considered ambiguous and one Warning diagnostic is produced per
 * ambiguous operationId.
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @returns {Object} Plugin object with visitor methods
 */
import getHelpers from '../helpers.mjs';

export default (toolbox) => {
    const {diagnostics, deps} = toolbox;
    const {toValue} = deps['@speclynx/apidom-core'];
    const {isStringElement} = deps['@speclynx/apidom-datamodel'];
    const {DiagnosticSeverity} = deps['vscode-languageserver-types'];
    const {createDiagnostic} = getHelpers(deps);

    const operationIds = [];

    return {
        visitor: {
            OperationElement(path) {
                // find closest PathItem ancestor
                const pathItemParent = path.findParent((p) => p.node.element === 'pathItem');
                if (!pathItemParent?.node.hasMetaProperty('path')) return path.skip();
                if (!isStringElement(path.node.operationId)) return path.skip();

                const operationId = toValue(path.node.operationId);

                operationIds.push({
                    operationId,
                    path: [...path.getPathKeys(), 'operationId'],
                });

                path.skip();
            },
        },
        post() {
            // group by lowercase to find ambiguity groups
            const groups = new Map();
            for (const entry of operationIds) {
                const key = entry.operationId.toLowerCase();
                if (!groups.has(key)) groups.set(key, []);
                groups.get(key).push(entry);
            }

            for (const [lowercase, items] of groups) {
                if (items.length <= 1) continue;

                for (const entry of items) {
                    diagnostics.push(createDiagnostic({
                        message: `OperationId '${entry.operationId}' is ambiguous (case-insensitive collision with '${lowercase}')`,
                        code: 'ambiguous_operation_id',
                        severity: DiagnosticSeverity.Warning,
                        data: {
                            lowercase,
                            operation_id: entry.operationId,
                            path: entry.path,
                        },
                    }));
                }
            }
        },
    };
};
