/**
 * Plugin that dereferences the entire OpenAPI document at the start of traversal.
 *
 * Runs a full in-place dereference on the root node, resolving all $ref references.
 * After dereferencing, stops traversal so that subsequent plugins in the merged
 * visitor pipeline operate on a fully resolved document tree.
 *
 * Runs after 01-prederef.mjs (which counts original $ref fields) and before
 * resolved-refs.mjs (which counts successfully resolved references).
 *
 * If dereferencing fails (e.g., missing baseURI or unmatched strategy),
 * a diagnostic is emitted so consumers can distinguish "0 resolved refs"
 * from "deref failed". Individual ref resolution errors are collected
 * via continueOnError and emitted as separate diagnostics.
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @returns {Object} Plugin object with visitor methods
 */
import getHelpers from '../helpers.mjs';

export default (toolbox) => {
    const {diagnostics, deps} = toolbox;
    const {dereferenceApiDOM, options} = deps['@speclynx/apidom-reference'];
    const {DiagnosticSeverity} = deps['vscode-languageserver-types'];
    const {createDiagnostic} = getHelpers(deps);

    const derefErrors = [];

    return {
        visitor: {
            async enter(path) {
                try {
                    await dereferenceApiDOM(path.node, {
                        resolve: {baseURI: options.resolve.baseURI},
                        dereference: {
                            immutable: false,
                            continueOnError: (error) => {
                                derefErrors.push(error);
                            },
                        },
                    });
                } catch (error) {
                    derefErrors.push(error);
                }
                path.stop();
            },
        },
        post() {
            for (const error of derefErrors) {
                diagnostics.push(createDiagnostic({
                    message: `Dereference error: ${error.message}`,
                    code: 'dereference_error',
                    severity: DiagnosticSeverity.Error,
                    data: { error: error.message, path: error.location ?? [] },
                }));
            }
        },
    };
};
