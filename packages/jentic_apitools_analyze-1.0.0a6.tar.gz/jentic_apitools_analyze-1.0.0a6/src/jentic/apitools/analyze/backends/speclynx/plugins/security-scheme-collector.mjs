/**
 * Plugin that collects security scheme information for auth_strength signal.
 *
 * Runs after 02-deref.mjs has fully dereferenced the document.
 * Collects structured data about each security scheme including type,
 * http scheme, bearer format, API key location, and OAuth2 flows.
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @returns {Object} Plugin object with visitor methods
 */
import getHelpers from '../helpers.mjs';

export default (toolbox) => {
    const {diagnostics, deps} = toolbox;
    const {toValue} = deps['@speclynx/apidom-core'];
    const {isStringElement} = deps['@speclynx/apidom-datamodel'];
    const {createDiagnostic} = getHelpers(deps);

    const schemes = [];
    const paths = [];

    return {
        visitor: {
            SecuritySchemeElement(path) {
                const scheme = path.node;
                paths.push(path.getPathKeys());

                const schemeType = isStringElement(scheme.type) ? toValue(scheme.type) : null;

                const schemeInfo = {
                    type: schemeType,
                    http_scheme: null,
                    bearer_format: null,
                    apikey_in: null,
                    apikey_name: null,
                    oauth2_flows: [],
                };

                if (schemeType === 'apiKey') {
                    if (isStringElement(scheme.in)) schemeInfo.apikey_in = toValue(scheme.in);
                    if (isStringElement(scheme.name)) schemeInfo.apikey_name = toValue(scheme.name);
                }

                if (schemeType === 'http') {
                    if (isStringElement(scheme.scheme)) schemeInfo.http_scheme = toValue(scheme.scheme);
                    if (isStringElement(scheme.bearerFormat)) schemeInfo.bearer_format = toValue(scheme.bearerFormat);
                }

                if (schemeType === 'oauth2' && scheme.flows) {
                    const flows = scheme.flows;
                    if (flows.implicit?.element === 'oAuthFlow') schemeInfo.oauth2_flows.push('implicit');
                    if (flows.password?.element === 'oAuthFlow') schemeInfo.oauth2_flows.push('password');
                    if (flows.clientCredentials?.element === 'oAuthFlow') schemeInfo.oauth2_flows.push('clientCredentials');
                    if (flows.authorizationCode?.element === 'oAuthFlow') schemeInfo.oauth2_flows.push('authorizationCode');
                }

                schemes.push(schemeInfo);
                path.skip();
            },
        },
        post() {
            diagnostics.push(createDiagnostic({
                message: `Security Schemes count: ${schemes.length}`,
                code: 'security_scheme_count',
                data: { security_scheme_count: schemes.length, paths },
            }));
            diagnostics.push(createDiagnostic({
                message: `Security schemes: ${schemes.length} Security Schemes`,
                code: 'security_schemes',
                data: { security_schemes: schemes, paths },
            }));
        },
    };
};
