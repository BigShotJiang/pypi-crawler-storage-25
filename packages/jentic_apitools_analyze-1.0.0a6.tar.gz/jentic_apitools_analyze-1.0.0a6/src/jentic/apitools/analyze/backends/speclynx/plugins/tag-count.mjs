/**
 * Plugin that counts unique tags in the OpenAPI document.
 *
 * Runs after 02-deref.mjs has fully dereferenced the document.
 * Collects unique tag names from both the top-level tags array
 * and operation-level tags.
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @returns {Object} Plugin object with visitor methods
 */
import getHelpers from '../helpers.mjs';

export default (toolbox) => {
    const {diagnostics, deps} = toolbox;
    const {toValue} = deps['@speclynx/apidom-core'];
    const {isStringElement, isArrayElement} = deps['@speclynx/apidom-datamodel'];
    const {createDiagnostic} = getHelpers(deps);

    const tags = new Set();
    const paths = [];

    return {
        visitor: {
            TagElement(path) {
                if (!isStringElement(path.node.name)) return;

                const name = toValue(path.node.name);
                if (!tags.has(name)) {
                    tags.add(name);
                    paths.push(path.getPathKeys());
                }
            },
            OperationElement(path) {
                if (!isArrayElement(path.node.tags)) return;

                for (const tag of path.node.tags) {
                    if (isStringElement(tag)) {
                        const name = toValue(tag);
                        if (!tags.has(name)) {
                            tags.add(name);
                            paths.push(path.getPathKeys());
                        }
                    }
                }
            },
        },
        post() {
            diagnostics.push(createDiagnostic({
                message: `Tags count: ${tags.size}`,
                code: 'tag_count',
                data: { tag_count: tags.size, paths },
            }));
        },
    };
};
