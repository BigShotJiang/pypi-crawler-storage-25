/**
 * Shared helpers for speclynx plugins.
 *
 * Exports a factory function that creates helper instances bound to the
 * plugin's deps. Both the helpers object and internal caches are singletons
 * at module level, shared across all plugins.
 */

let helpers = null;

/**
 * Get helpers bound to the given deps. Returns a cached singleton —
 * only the first call creates the helpers, subsequent calls return the same instance.
 *
 * @param {Object} deps - Dependencies object from plugin toolbox
 * @returns {Object} Helper functions
 */
export default function getHelpers(deps) {
    if (helpers !== null) return helpers;

    const {fixedFields} = deps['@speclynx/apidom-core'];
    const {Diagnostic, Range, DiagnosticSeverity} = deps['vscode-languageserver-types'];
    const fixedFieldsCache = new Map();
    const defaultRange = Range.create(0, 0, 0, 0);

    helpers = {
        /**
         * Cached version of fixedFields that caches results by element constructor.
         * Since fixed fields are determined by element type (not instance), the result
         * is the same for all elements of the same class (e.g., all OpenAPI 3.0 SchemaElements).
         *
         * @param {Object} element - An ApiDOM element
         * @returns {Object} Indexed fixed fields for the element's type
         */
        cachedFixedFields(element) {
            const ctor = element.constructor;
            if (!fixedFieldsCache.has(ctor)) {
                fixedFieldsCache.set(ctor, fixedFields(element, {indexed: true}));
            }
            return fixedFieldsCache.get(ctor);
        },

        /**
         * Create a diagnostic with sensible defaults.
         *
         * @param {Object} options
         * @param {string} options.message - Diagnostic message
         * @param {string} options.code - Diagnostic code
         * @param {Object} [options.data] - Optional data to attach
         * @param {Object} [options.range] - LSP Range (defaults to 0,0,0,0)
         * @param {number} [options.severity] - LSP DiagnosticSeverity (defaults to Information)
         * @returns {Object} LSP Diagnostic
         */
        createDiagnostic({ message, code, data, range = defaultRange, severity = DiagnosticSeverity.Information }) {
            const diagnostic = Diagnostic.create(range, message, severity, code);
            if (data !== undefined) {
                diagnostic.data = data;
            }
            return diagnostic;
        },
    };

    return helpers;
}
