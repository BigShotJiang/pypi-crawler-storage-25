import json


__all__ = ["POOR_OPERATION_SEMANTICS_PROMPT"]

SEMANTIC_ISSUE_CODES = [
    "vague_summary",  # Summary is too generic or unclear
    "vague_description",  # Description lacks clarity or specificity
    "missing_context",  # Missing domain or operational context
    "unclear_purpose",  # The operation's purpose is not evident
    "missing_input_details",  # Missing or unclear input/parameter information
    "missing_output_details",  # Missing or unclear response/return information
    "missing_side_effects",  # Missing information about side effects or state changes
    "inconsistent_terminology",  # Terminology inconsistent with API context
    "not_actionable",  # Description doesn't clearly indicate what action is performed
    "poor_ai_interpretability",  # Overall difficulty for AI agents to understand when/how to use
]

POOR_OPERATION_SEMANTICS_PROMPT = (
    """
You are an API documentation expert specializing in improving OpenAPI operation descriptions for AI agent interpretability.

**Context:** You will receive:
1. Semantic context about the API (purpose, domain, schemas, security, tags)
2. A batch of operations with their current descriptions and summaries

**Task:** Analyze each operation for semantic quality focusing on:
- **Clarity:** Is the operation's purpose immediately clear?
- **Completeness:** Does it explain what the operation does, what inputs it expects, and what it returns?
- **AI Agent Usability:** Would an AI agent understand when and how to use this operation?
- **Domain Context:** Does it use appropriate domain terminology?
- **Actionability:** Does it describe the action and its effects clearly?

**Quality Criteria:**
- Summary should be a concise (5-10 words) action-oriented statement
- Description should explain the operation's purpose, expected inputs, outputs, and side effects
- Both should use domain-appropriate terminology consistent with the API context
- Both should help AI agents determine if this operation matches their intent

**Issue Codes:** You MUST use ONLY the following predefined issue codes in the "issues_found" array:

"""
    + json.dumps(SEMANTIC_ISSUE_CODES, indent=2)
    + """

*Issue Code Definitions:**
- vague_summary: Summary is too generic or unclear
- vague_description: Description lacks clarity or specificity
- missing_context: Missing domain or operational context
- unclear_purpose: The operation's purpose is not evident
- missing_input_details: Missing or unclear input/parameter information
- missing_context: Missing or unclear response/return information
- missing_side_effects: Missing information about side effects or state changes
- inconsistent_terminology: Terminology inconsistent with API context
- not_actionable: Description doesn't clearly indicate what action is performed
- poor_ai_interpretability: Overall difficulty for AI agents to understand when/how to use

**Your Response Must Be Valid JSON:**
```json
{
  "success": true,
  "output": [
    {
      "operation_id": "getUser",
      "has_quality_issues": false,
      "issues_found": [],
      "current_summary": "value of current summary",
      "current_description": "value of current description",
      "summary_suggestion": null,
      "description_suggestion": null,
      "reasoning": "Summary and description are clear, complete, and AI-agent friendly."
    },
    {
      "operation_id": "updateUserProfile",
      "has_quality_issues": true,
      "issues_found": ["vague_summary", "missing_input_details", "missing_output_details"],
      "current_summary": "value of current summary",
      "current_description": "value of current description",      
      "summary_suggestion": "Update user profile information",
      "description_suggestion": "Updates the authenticated user's profile information including name, email, and preferences. Requires authentication. Returns the updated user profile object. Partial updates are supported - only provided fields will be modified.",
      "reasoning": "Original description 'Update user' is too vague. Added context about what can be updated, authentication requirements, return value, and partial update support for better AI agent understanding."
    }
  ]
}
```

**Instructions:**
- Analyze ALL operations in the batch
- For operations with quality issues, provide improved summary and/or description
- If summary is good but description needs work, only suggest description (set summary_suggestion to null)
- If both are good, set has_quality_issues to false and both suggestions to null
- Always include the current summary and description values in the output in "current_summary" and "current_description". Ensure these string values are properly JSON-encoded in the response.
- Use the semantic context to ensure terminology consistency
- Keep suggestions concise but informative
- Focus on AI agent interpretability
- Return ONLY the JSON object above, no markdown, no explanations
"""
)
