/**
 * Pre-deref visitor plugin that counts elements that HAVE examples.
 *
 * Tracks elements with at least one example value present. Checks both
 * the 'example' field (single value) and 'examples' field (array for Schema 3.1,
 * map for MediaType/Parameter/Header). Skips Components element.
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @returns {Object} Object with visitor and post() for diagnostics
 */
import getHelpers from '../helpers.mjs';

export default (toolbox) => {
    const {diagnostics, deps} = toolbox;
    const {isArrayElement, isObjectElement} = deps['@speclynx/apidom-datamodel'];
    const {cachedFixedFields, createDiagnostic} = getHelpers(deps);

    let count = 0;
    const paths = [];

    return {
        visitor: {
            enter(path) {
                if (path.node.element === 'components') return;

                const fields = cachedFixedFields(path.node);
                const hasExampleField = 'example' in fields;
                const hasExamplesField = 'examples' in fields;
                if (!hasExampleField && !hasExamplesField) return;

                // check single 'example' field
                if (hasExampleField && path.node.example !== undefined) {
                    count++;
                    paths.push(path.getPathKeys());
                    return;
                }

                // check 'examples' field
                if (hasExamplesField && path.node.examples !== undefined) {
                    // Schema Object (OpenAPI 3.1) has examples as array
                    if (isArrayElement(path.node.examples) && path.node.examples.length > 0) {
                        count++;
                        paths.push(path.getPathKeys());
                    }
                    // MediaType, Parameter, Header have examples as Map[string, Example Object]
                    else if (isObjectElement(path.node.examples) && path.node.examples.length > 0) {
                        count++;
                        paths.push(path.getPathKeys());
                    }
                }
            },
        },
        post() {
            diagnostics.push(createDiagnostic({
                message: `Present examples: ${count}`,
                code: 'present_examples',
                data: { present_examples: count, paths },
            }));
        },
    };
};
