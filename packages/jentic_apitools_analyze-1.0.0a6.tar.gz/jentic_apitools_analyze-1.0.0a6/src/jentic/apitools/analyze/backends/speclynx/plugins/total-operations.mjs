/**
 * Plugin that counts Operation objects in the OpenAPI document.
 *
 * Runs after 02-deref.mjs has fully dereferenced the document.
 * Counts operations whose closest PathItem ancestor has 'path' metadata,
 * which identifies it as belonging to the paths object. This implicitly
 * excludes operations from webhooks, callbacks, and components.
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @returns {Object} Plugin object with visitor methods
 */
import getHelpers from '../helpers.mjs';

export default (toolbox) => {
    const {diagnostics, deps} = toolbox;
    const {createDiagnostic} = getHelpers(deps);

    let count = 0;
    const paths = [];

    return {
        visitor: {
            OperationElement(path) {
                // find closest PathItem ancestor
                const pathItemParentPath = path.findParent((p) => p.node.element === 'pathItem');

                // only count if PathItem has 'path' metadata (set on items under paths object)
                if (!pathItemParentPath?.node.hasMetaProperty('path')) return path.skip();

                count++;
                paths.push(path.getPathKeys());

                path.skip();
            },
        },
        post() {
            diagnostics.push(createDiagnostic({
                message: `Total Operations count: ${count}`,
                code: 'total_operations',
                data: { total_operations: count, paths },
            }));
        },
    };
};
