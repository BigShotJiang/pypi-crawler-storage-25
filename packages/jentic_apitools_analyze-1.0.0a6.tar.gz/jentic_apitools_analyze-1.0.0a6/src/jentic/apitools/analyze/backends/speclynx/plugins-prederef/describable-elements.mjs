/**
 * Pre-deref visitor plugin that counts elements that CAN have descriptions.
 *
 * Tracks all elements with a description fixed field, regardless of whether
 * the description is populated. Runs before dereferencing to avoid counting
 * duplicates from inlined $ref expansions.
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @returns {Object} Object with visitor and post() for diagnostics
 */
import getHelpers from '../helpers.mjs';

export default (toolbox) => {
    const {diagnostics, deps} = toolbox;
    const {cachedFixedFields, createDiagnostic} = getHelpers(deps);

    let count = 0;
    const paths = [];

    return {
        visitor: {
            enter(path) {
                const fields = cachedFixedFields(path.node);
                if (!('description' in fields)) return;

                count++;
                paths.push(path.getPathKeys());
            },
        },
        post() {
            diagnostics.push(createDiagnostic({
                message: `Describable elements: ${count}`,
                code: 'describable_elements',
                data: { describable_elements: count, paths },
            }));
        },
    };
};
