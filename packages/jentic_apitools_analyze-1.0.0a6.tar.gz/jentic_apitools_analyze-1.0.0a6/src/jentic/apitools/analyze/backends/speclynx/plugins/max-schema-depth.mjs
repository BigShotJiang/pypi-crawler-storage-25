/**
 * Plugin that calculates the maximum schema nesting depth in the OpenAPI document.
 *
 * Runs after 02-deref.mjs has fully dereferenced the document.
 * Since all $ref chains are resolved inline, depth is simply tracked
 * incrementally during traversal (increment on enter, decrement on leave).
 * No ref resolution, cycle detection, or caching needed.
 *
 * Tracks:
 * - max_depth: the deepest nesting level found
 * - deep_schema_paths: unique schema roots exceeding the depth threshold (default: 18)
 * - max_depth_path: path to the schema root that achieved max depth
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @returns {Object} Plugin object with visitor methods
 */
import getHelpers from '../helpers.mjs';

export default (toolbox) => {
    const {diagnostics, deps} = toolbox;
    const {createDiagnostic} = getHelpers(deps);

    const depthThreshold = 18;
    let currentDepth = 0;
    let maxDepth = 0;
    let maxDepthPath = null;
    let schemaRootPath = null;
    let currentRootExceedsThreshold = false;
    const deepSchemaPaths = [];

    return {
        visitor: {
            SchemaElement: {
                enter(path) {
                    currentDepth++;

                    // track schema root (depth 1) for max_depth_path reporting
                    if (currentDepth === 1) {
                        schemaRootPath = path.getPathKeys();
                        currentRootExceedsThreshold = false;
                    }

                    // update max depth
                    if (currentDepth > maxDepth) {
                        maxDepth = currentDepth;
                        maxDepthPath = schemaRootPath;
                    }

                    // record schema root once when any element exceeds depth threshold
                    if (!currentRootExceedsThreshold && currentDepth >= depthThreshold && schemaRootPath != null) {
                        currentRootExceedsThreshold = true;
                        deepSchemaPaths.push(schemaRootPath);
                    }
                },
                leave() {
                    currentDepth--;
                },
            },
        },
        post() {
            diagnostics.push(createDiagnostic({
                message: `Deepest nesting found across all schemas: ${maxDepth}`,
                code: 'max_schema_depth',
                data: {
                    max_schema_depth: maxDepth,
                    path: maxDepthPath,
                    paths: deepSchemaPaths,
                },
            }));
        },
    };
};