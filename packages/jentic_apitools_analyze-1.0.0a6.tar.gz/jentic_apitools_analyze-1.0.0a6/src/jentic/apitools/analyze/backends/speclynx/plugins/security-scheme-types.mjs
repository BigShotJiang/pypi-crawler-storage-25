/**
 * Plugin that collects unique security scheme types from the OpenAPI document.
 *
 * Runs after 02-deref.mjs has fully dereferenced the document.
 * Collects unique security scheme type values (apiKey, http, oauth2, openIdConnect, mutualTLS).
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @returns {Object} Plugin object with visitor methods
 */
import getHelpers from '../helpers.mjs';

export default (toolbox) => {
    const {diagnostics, deps} = toolbox;
    const {toValue} = deps['@speclynx/apidom-core'];
    const {isStringElement} = deps['@speclynx/apidom-datamodel'];
    const {createDiagnostic} = getHelpers(deps);

    const types = new Set();
    const paths = [];

    return {
        visitor: {
            SecuritySchemeElement(path) {
                if (!isStringElement(path.node.type)) return;

                types.add(toValue(path.node.type));
                paths.push(path.getPathKeys());
                path.skip();
            },
        },
        post() {
            diagnostics.push(createDiagnostic({
                message: `Security scheme types: ${JSON.stringify([...types].sort())}`,
                code: 'security_scheme_types',
                data: { security_scheme_types: [...types].sort(), paths },
            }));
        },
    };
};
