/**
 * Plugin that counts operations with operationId and collects their values.
 *
 * Runs after 02-deref.mjs has fully dereferenced the document.
 * For each operation under paths (identified by PathItem 'path' metadata),
 * checks if the operation has an operationId field and collects the values.
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @returns {Object} Plugin object with visitor methods
 */
import getHelpers from '../helpers.mjs';

export default (toolbox) => {
    const {diagnostics, deps} = toolbox;
    const {toValue} = deps['@speclynx/apidom-core'];
    const {isStringElement} = deps['@speclynx/apidom-datamodel'];
    const {createDiagnostic} = getHelpers(deps);

    const operationIds = [];
    const operationIdPaths = [];

    return {
        visitor: {
            OperationElement(path) {
                // find closest PathItem ancestor
                const pathItemParent = path.findParent((p) => p.node.element === 'pathItem');
                // only count if PathItem has 'path' metadata (under paths object)
                if (!pathItemParent?.node.hasMetaProperty('path')) return path.skip();
                if (!isStringElement(path.node.operationId)) return path.skip();

                const operationId = toValue(path.node.operationId);

                operationIds.push(operationId);
                operationIdPaths.push(path.getPathKeys());

                path.skip();
            },
        },
        post() {
            diagnostics.push(createDiagnostic({
                message: `Operations with operationId: ${operationIdPaths.length}`,
                code: 'operations_with_operationId',
                data: {
                    operations_with_operationId: operationIdPaths.length,
                    operation_ids: operationIds,
                    paths: operationIdPaths,
                },
            }));
        },
    };
};
