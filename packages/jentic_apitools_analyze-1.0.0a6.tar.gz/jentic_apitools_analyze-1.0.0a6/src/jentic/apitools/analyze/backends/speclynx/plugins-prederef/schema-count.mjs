/**
 * Pre-deref visitor plugin that counts Schema objects in the OpenAPI document.
 *
 * Runs before dereferencing to count unique schemas (not inflated by $ref expansion).
 * Imported and merged by 01-prederef.mjs.
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @returns {Object} Object with visitor and post() for diagnostics
 */
import getHelpers from '../helpers.mjs';

export default (toolbox) => {
    const {diagnostics, deps} = toolbox;
    const {createDiagnostic} = getHelpers(deps);

    let count = 0;
    const paths = [];

    return {
        visitor: {
            SchemaElement(path) {
                count++;
                paths.push(path.getPathKeys());
            },
        },
        post() {
            diagnostics.push(createDiagnostic({
                message: `Schemas count: ${count}`,
                code: 'schema_count',
                data: { schema_count: count, paths },
            }));
        },
    };
};
