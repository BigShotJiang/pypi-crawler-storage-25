/**
 * Pre-deref visitor plugin that counts total number of individual examples.
 *
 * Unlike expected/present-examples which count elements, this counts the actual
 * number of example values. A node with 5 examples in its 'examples' map counts
 * as 5. Skips Components element.
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @returns {Object} Object with visitor and post() for diagnostics
 */
import getHelpers from '../helpers.mjs';

export default (toolbox) => {
    const {diagnostics, deps} = toolbox;
    const {isArrayElement, isObjectElement} = deps['@speclynx/apidom-datamodel'];
    const {cachedFixedFields, createDiagnostic} = getHelpers(deps);

    let count = 0;
    const paths = [];

    return {
        visitor: {
            enter(path) {
                if (path.node.element === 'components') return;

                const fields = cachedFixedFields(path.node);
                const hasExampleField = 'example' in fields;
                const hasExamplesField = 'examples' in fields;
                if (!hasExampleField && !hasExamplesField) return;

                let countAtNode = 0;

                // count single 'example' field
                if (hasExampleField && path.node.example !== undefined) {
                    countAtNode += 1;
                }

                // count items in 'examples' field
                if (hasExamplesField && path.node.examples !== undefined) {
                    // Schema Object (OpenAPI 3.1) has examples as array
                    if (isArrayElement(path.node.examples) && path.node.examples.length > 0) {
                        countAtNode += path.node.examples.length;
                    }
                    // MediaType, Parameter, Header have examples as Map[string, Example Object]
                    else if (isObjectElement(path.node.examples) && path.node.examples.length > 0) {
                        countAtNode += path.node.examples.length;
                    }
                }

                if (countAtNode > 0) {
                    count += countAtNode;
                    paths.push(path.getPathKeys());
                }
            },
        },
        post() {
            diagnostics.push(createDiagnostic({
                message: `Total examples: ${count}`,
                code: 'total_examples',
                data: { total_examples: count, paths },
            }));
        },
    };
};
