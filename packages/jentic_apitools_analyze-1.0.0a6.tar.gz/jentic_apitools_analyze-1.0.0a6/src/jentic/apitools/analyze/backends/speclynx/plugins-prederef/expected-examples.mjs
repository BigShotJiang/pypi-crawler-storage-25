/**
 * Pre-deref visitor plugin that counts elements that CAN have examples.
 *
 * Tracks all elements with an example or examples fixed field, regardless of
 * whether any example is populated. Skips Components element since its examples
 * field is for storing reusable examples.
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @returns {Object} Object with visitor and post() for diagnostics
 */
import getHelpers from '../helpers.mjs';

export default (toolbox) => {
    const {diagnostics, deps} = toolbox;
    const {cachedFixedFields, createDiagnostic} = getHelpers(deps);

    let count = 0;
    const paths = [];

    return {
        visitor: {
            enter(path) {
                if (path.node.element === 'components') return;

                const fields = cachedFixedFields(path.node);
                if (!('example' in fields) && !('examples' in fields)) return;

                count++;
                paths.push(path.getPathKeys());
            },
        },
        post() {
            diagnostics.push(createDiagnostic({
                message: `Expected examples: ${count}`,
                code: 'expected_examples',
                data: { expected_examples: count, paths },
            }));
        },
    };
};
