/**
 * Pre-deref visitor plugin that counts total reference fields in OpenAPI documents.
 *
 * Runs before dereferencing to count original $ref fields.
 * Imported and merged by 01-prederef.mjs.
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @returns {Object} Object with visitor and post() for diagnostics
 */
import getHelpers from '../helpers.mjs';

export default (toolbox) => {
    const {diagnostics, deps} = toolbox;
    const {includesClasses} = deps['@speclynx/apidom-datamodel'];
    const {createDiagnostic} = getHelpers(deps);

    let count = 0;
    const paths = [];
    const referenceClasses = ['reference-element'];

    return {
        visitor: {
            enter(path) {
                if (!includesClasses(path.node, referenceClasses)) return;

                count++;
                paths.push(path.getPathKeys());
            },
        },
        post() {
            diagnostics.push(createDiagnostic({
                message: `Total references: ${count}`,
                code: 'total_refs',
                data: { total_refs: count, paths },
            }));
        },
    };
};
