/**
 * Plugin that counts resolved references in OpenAPI documents.
 *
 * Runs after 02-deref.mjs has fully dereferenced the document in-place.
 * Counts elements that were successfully resolved by checking for the 'ref-type'
 * metadata property set by the dereferencing process.
 *
 * Currently counts:
 * - Elements with ref-type 'reference' (Reference.$ref, PathItem.$ref, etc.)
 *
 * Not currently processed:
 * - Link.operationRef
 * - Schema.$dynamicRef (OpenAPI 3.1+ only and not supported by SpecLynx ApiDOM)
 *
 * @param {Object} toolbox - Plugin toolbox provided by speclynx
 * @param {Array} toolbox.diagnostics - Array to collect validation diagnostics
 * @param {Object} toolbox.deps - Dependencies object
 * @returns {Object} Plugin object with visitor methods
 */
import getHelpers from '../helpers.mjs';

export default (toolbox) => {
    const {diagnostics, deps} = toolbox;
    const {createDiagnostic} = getHelpers(deps);

    let count = 0;
    const paths = [];

    return {
        visitor: {
            enter(path) {
                if (!path.node.hasMetaProperty('ref-type')) return;

                count++;
                paths.push(path.getPathKeys());
                path.skip();
            },
        },
        post() {
            diagnostics.push(createDiagnostic({
                message: `Resolved references: ${count}`,
                code: 'resolved_refs',
                data: { resolved_refs: count, paths },
            }));
        }
    };
};
