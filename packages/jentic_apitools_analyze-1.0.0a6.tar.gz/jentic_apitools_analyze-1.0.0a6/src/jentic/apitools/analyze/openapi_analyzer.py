import os
import time
from importlib.resources import files

from jentic.apitools.openapi.validator.backends.base import BaseValidatorBackend
from jentic.apitools.openapi.validator.backends.default import DefaultOpenAPIValidatorBackend
from jentic.apitools.openapi.validator.backends.openapi_spec import OpenAPISpecValidatorBackend
from jentic.apitools.openapi.validator.backends.redocly import RedoclyValidatorBackend
from jentic.apitools.openapi.validator.backends.speclynx import SpeclynxValidatorBackend
from jentic.apitools.openapi.validator.backends.spectral import SpectralValidatorBackend
from jentic.apitools.openapi.validator.core import (
    JenticDiagnostic,
    OpenAPIValidator,
    ValidationResult,
)
from lsprotocol.types import DiagnosticSeverity, Position, Range

from jentic.apitools.analyze.backends.semantic import SemanticValidatorBackend
from jentic.apitools.common.models import DiagnosticTarget
from jentic.apitools.common.utils.cpu_utils import get_available_cpu_count
from jentic.apitools.common.utils.logging import get_module_logger


__all__ = ["OpenAPIAnalyzer"]


class OpenAPIAnalyzer:
    """
    Provides an analyzer entry point for OpenAPI specifications.

    Attributes:
    """

    def __init__(self):
        self.logger = get_module_logger(__name__)
        self.ruleset_dir = files("jentic.apitools.analyze").joinpath("rules")
        self.spectral_ruleset_path = self.ruleset_dir.joinpath("spectral.mjs")
        self.redocly_ruleset_path = self.ruleset_dir.joinpath("redocly.yaml")
        self.speclynx_plugins_dir = files("jentic.apitools.analyze.backends.speclynx").joinpath(
            "plugins"
        )
        self.deterministic_backends = [
            OpenAPISpecValidatorBackend(),
            DefaultOpenAPIValidatorBackend(),
            RedoclyValidatorBackend(ruleset_path=str(self.redocly_ruleset_path)),
            SpectralValidatorBackend(ruleset_path=str(self.spectral_ruleset_path)),
            SpeclynxValidatorBackend(plugins_dir=str(self.speclynx_plugins_dir), source_map=False),
        ]

        batch_size = os.getenv("LLM_ANALYSIS_BATCH_SIZE")
        if batch_size and batch_size.isdigit() and int(batch_size) > 0:
            self.llm_backends = [SemanticValidatorBackend(batch_size=int(batch_size))]
        else:
            self.llm_backends = [SemanticValidatorBackend()]

    def analyze(
        self,
        document_uri: str,
        *,
        base_url: str,
        target: DiagnosticTarget,
        spec_type: str = "spec",
        enable_llm_analysis: bool = False,
    ) -> list[JenticDiagnostic]:
        """
        Analyze an OpenAPI document.

        Args:
            document_uri: URI to the spec to validate (usually file:// URI)
            base_url: Base URL for resolving references
            target: Diagnostic target for error reporting
            spec_type: Description of spec type for error messages (e.g., "bundled-spec", "root-spec")

        Returns:
            List of validation diagnostics from all backends

        """
        backends = (
            self.deterministic_backends
            if not enable_llm_analysis
            else self.deterministic_backends + self.llm_backends
        )
        return self.validate(
            validation_uri=document_uri,
            base_url=base_url,
            backends=backends,
            target=target,
            spec_type=spec_type,
        )

    def validate(
        self,
        validation_uri: str,
        base_url: str,
        backends: list[str | BaseValidatorBackend],
        target: DiagnosticTarget,
        spec_type: str = "spec",
    ) -> list[JenticDiagnostic]:
        """Validate a spec with multiple validation backends in parallel.

        This function wraps each backend with error handling and runs validation
        across all provided backends. Backends are executed in parallel when
        multiple workers are available.

        Args:
            validation_uri: URI to the spec to validate (usually file:// URI)
            base_url: Base URL for resolving references
            backends: List of validation backends to use
            target: Diagnostic target for error reporting
            spec_type: Description of spec type for error messages (e.g., "bundled-spec", "root-spec")

        Returns:
            List of validation diagnostics from all backends

        Example:
            >>> diagnostics = validate(
            ...     str(spec_path.as_uri()),
            ...     base_url,
            ...     all_backends,
            ...     DiagnosticTarget.REPAIR_SPEC,
            ...     "bundled-spec"
            ... )
        """

        # Get backend instances from OpenAPIValidator
        backend_instances = OpenAPIValidator(backends=backends).backends

        # Wrap each backend with error handling
        wrapped_backends = [
            _ErrorHandlingBackendWrapper(
                backend, spec_type, target, OpenAPIAnalyzer.build_diagnostic
            )
            for backend in backend_instances
        ]

        # Determine parallelism
        max_workers = int(os.getenv("MAX_OPENAPI_VALIDATION_WORKERS") or get_available_cpu_count())

        # Single validator call with all wrapped backends (runs in parallel when max_workers > 1)
        validation_result = OpenAPIValidator(backends=wrapped_backends).validate(
            validation_uri,
            base_url=base_url,
            target=str(target),
            parallel=max_workers > 1,
            max_workers=max_workers,
        )

        return validation_result.diagnostics if validation_result.diagnostics else []

    @staticmethod
    def build_diagnostic(
        msg: str,
        code: str,
        source: str,
        severity: DiagnosticSeverity | None = DiagnosticSeverity.Error,
        *,
        target: DiagnosticTarget | None = None,
        path: list[str | int] | None = None,
        fixable: bool = True,
    ) -> JenticDiagnostic:
        diag = JenticDiagnostic(
            range=Range(Position(0, 0), Position(0, 0)),
            message=msg,
            code=code,
            source=source,
            severity=severity,
        )
        if target:
            diag.set_target(target.value)
        diag.set_path(path)
        diag.set_fixable(fixable)
        return diag


class _ErrorHandlingBackendWrapper(BaseValidatorBackend):
    """Wraps a backend to add error handling to its validate() method.

    This wrapper catches exceptions from the underlying backend's validate()
    method and logs them as diagnostics, allowing other backends to continue.
    """

    def __init__(
        self,
        backend: BaseValidatorBackend,
        spec_type: str,
        target: DiagnosticTarget,
        build_diagnostic_fn,
    ):
        self._backend = backend
        self._spec_type = spec_type
        self._target = target
        self._logger = get_module_logger(__name__)
        self._build_diagnostic = build_diagnostic_fn

    def __getstate__(self):
        state = self.__dict__.copy()
        state.pop("_logger", None)
        return state

    def __setstate__(self, state: dict):
        for key, value in state.items():
            object.__setattr__(self, key, value)
        self._logger = get_module_logger(__name__)

    def validate(self, document: str | dict, **kwargs):
        """Validate with error handling.

        Wraps the underlying backend's validate() call, catching any exception
        and returning a ValidationResult containing an error diagnostic instead
        of propagating the failure.
        """
        try:
            backend_name = type(self._backend).__name__
            self._logger.debug(f"Validating {document} with backend: {self._backend}")
            t0 = time.monotonic()
            result = self._backend.validate(document, **kwargs)
            elapsed = time.monotonic() - t0
            uri_label = str(document)[:120] if not isinstance(document, str) else document[:120]
            self._logger.info(
                "Backend %s completed in %.1fs for %s", backend_name, elapsed, uri_label
            )
            return result
        except Exception as e:
            self._logger.exception(
                f"Failed to validate {self._spec_type} with validator backend: {self._backend}"
            )
            error_diagnostic = self._build_diagnostic(
                f"Failed to validate {self._spec_type} with validator backend {self._backend}: {e}",
                f"failed-to-validate-{self._spec_type}",
                "validator",
                target=self._target,
            )
            # Return error diagnostic in result so it survives process boundaries
            # and flows back through future.result() aggregation
            return ValidationResult(diagnostics=[error_diagnostic])

    def execution_type(self) -> str:
        return self._backend.execution_type()

    def accepts(self):
        return self._backend.accepts()
