""".yml file configuration management.

Provides YmlConfigFile base class for .yml files. Functionally identical to
YamlConfigFile with "yml" extension instead of "yaml".

Example:
    >>> from pathlib import Path
    >>> from typing import Any
    >>> from pyrig.rig.configs.base.yml import YmlConfigFile
    >>>
    >>> class MkDocsConfigFile(YmlConfigFile):
    ...
    ...     def parent_path(self) -> Path:
    ...         return Path()
    ...
    ...
    ...     def _configs(self) -> ConfigDict:
    ...         return {"site_name": "My Project", "theme": {"name": "material"}}
"""

from pyrig.rig.configs.base.config_file import ConfigDict, ConfigT
from pyrig.rig.configs.base.yaml import YamlConfigFile


class YmlConfigFile(YamlConfigFile[ConfigT]):
    """Base class for .yml files.

    Extends YamlConfigFile with "yml" extension. All functionality inherited.

    Subclasses must implement:
        - `parent_path`: Directory containing the .yml file
        - `_configs`: Expected YAML configuration structure

    See Also:
        pyrig.rig.configs.base.yaml.YamlConfigFile: Parent class
    """

    def extension(self) -> str:
        """Return "yml"."""
        return "yml"


class DictYmlConfigFile(YmlConfigFile[ConfigDict]):
    """Base class for .yml files with dict structure.

    Extends YmlConfigFile with dict-specific type hints. All functionality inherited.

    Subclasses must implement:
        - `parent_path`: Directory containing the .yml file
        - `_configs`: Expected YAML configuration structure as a dict

    See Also:
        pyrig.rig.configs.base.yaml.YamlConfigFile: Parent class
    """
