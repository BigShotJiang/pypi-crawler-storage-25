"""Locations as specified (by example) in locations.json.

The schema how locations are hierarchically defined is defined in
schema.json.

Recognised keys are:
- name      (str|int) : what this location is called
- display   (str) : How the name of sub elements should be displayed. String that can include {name} and {shortcut}
                    and {sep} and {separator} (replaced by the global option separator and long_separator)
                    and is interpreted as python format string. E.g. "↑ {name}" for when the name of sub elements
                    say how high the thing is.
                    If no {name} or {shortcut} is included, it is used as a prefix, i.e. {name} is appended.
                    Default is "{separator} {name}"
- shortcut  (str|int) : how this location is called in a short location string
- display_shortcut (str) : same as display but for when a shortcut is requested. Default is "{sep} {shortcut}".
- levelname (str) : key for specifying subelements
- subs      (dict): same information for the subelements (a list of schemas)
                    if non-existing, all names are accepted
- subschema (dict): information given to all subelements
- label     (dict): default values, mostly width and height, for labels of boxes in this location
                    label information are not passed down to subs, so usually they are
                    specified in subschema

The location.yaml files for the things have:
- keys      (str) : given by levelname
- values    (str|int): the possible values given by the keys in the
                       subs Schema or any value if no subs are given
"""

import itertools

import logging

import pathlib
import string

from typing import Any, Union, Optional, Self, Literal, MutableMapping
import os.path
import yaml

from . import constant, defaulted_data

Value = Union[str, int, float, bool]
"""Valid level specifier types (values in location dict)."""

EMPTY: list[Any] = [None, "", [], {}]
"""Values that are considered empty and mean that nothing should be saved."""


class InvalidLocationSchema(Exception):
    """Raised if the schema is invalid.

    Should be raised "from" the original exception.
    """


class InvalidLocation(Exception):
    """Raised if a location is invalid.

    Should be raised "from" the original exception.
    """


class Schema:
    """Schema as described in module docstring, possibly with sub-schemas.

    self._is_default: bool (= self.is_default()): True for Schemas that are holders for information
        for other Schemas but not themselves usable by locations.
    self._default: Optional[Schema]: Schema with data that is used if not specified in itself.
        This value is not changeable after __init__
        but the default schema itself can change its values.
        Can be None, but should only be None for the uppermost Schema and for default schemas to avoid
        infinite recursion.
        If self.default is queried, a new empty default sub schema is created.
    self._sub_schema_default: Optional[Schema]: Schema that is used as the _default for sub schemas.
        Can be None. Then the sub schema default of the _default is used. If that is empty, you get None.
    self._name: Not existing | Value: name of the Schema.
        Used to specify it in location info. Raises Attribute Error
        for default schemas (those with self.is_default()). Must not be in EMPTY for others.
    self._display: str | None: format string for displaying name of subs. If None, use display of default. If None as
        well, use "{separator} {name}". If no {name} nor {shortcut} is included, add " {name}".
    self._shortcut: Not existing | Value: shortcut for the name.
        Raises Attribute Error for default Subschemas.
        Has default value based on the name if not otherwise given.
    self._display_shortcut: str | None: format string for displaying shortcut of subs.
        If None, use display_shortcut of default. If None as well, use "{sep} {shortcut}"
        If no {name} nor {shortcut} is included, add " {name}".
    self.description: Optional[str]: Read-write attribute, not used by anything else.
    self._levelname: Optional[str]: How subschemas are given in location info (the keys).
        If self._levelname is None (lowermost schema level), self.levelname raises InvalidLocation.
        If you change this, all location files need to be rewritten. This is not done automatically!
    self._subs: list[Schema]: is a list of sub schemas as listed in the json definition. Empty list
        is possible. Then all values are eligible for new subschemas.
    self._inofficial_subs: Optional[list[Schema]] is a list of sub schemas that are created and
        returned when needed but should not get recreated with the same name.
    self._label and self.label: Sign-like defaulted dict - information about labels, mainly width and height that can be used
        if no information is given for the specific label.
        The default values (as this is a defaulted dict) come from the label of the default schema.

    In earlier versions, self._default had a different meaning: it was the subschema
    that was used if none are given in a location info. This functionality is removed now.
    """

    def __init__(
        self,
        json_content: dict[str, Any],
        options: constant.Options,
        is_default: bool = False,
        default: Self = None,
    ):
        """Create schema with sub schemas.

        Args:
            json_content: dict-list-str-... structure from reading json/yaml with data
            is_default:
                if True, this is not a real Schema but a default value holder for schemas
                if False, this is a real Schema and therefore has to have a name
            default: a Schema with is_default == True with default values. If None, no default
                values exist
        """
        self._default = default
        self.options = options
        self._is_default = (
            is_default  # should not be changed, therefore private without setter
        )
        self._set_name(json_content.get("name", None))
        # may raise InvalidLocationSchema if name is "" or " " or missing
        self.shortcut = json_content.get("shortcut", None)
        self.description = json_content.get("description", None)
        # check that the default has a label. This should always be the case because _label is always
        # created as seen in the next step:
        assert (
            self._is_default or self.default is None or self._default.label is not None
        )
        # can be changed but should not be replaced, therefore private:
        self._label = (
            # Note that this definition here is slightly different from that of Sign
            # since here width, height, etc. are defaulted to default label info
            defaulted_data.DefaultedDict(
                json_content.get("label", {}),
                default=({} if self._default is None else self._default.label),
                translated=("fontsize", "font_size"),
                default_order=(
                    "width",
                    "height",
                    "font_size",
                    "font_size_location",
                    "location_shift_down",
                    "fontsize",
                    "name_height",
                    "font_size_location",
                ),
                non_defaulted=[],
                lists=["font_size", "fontsize"],
                options=options,
            )
        )
        self._levelname = json_content.get("levelname", None)
        self._display = None  # overwritten in next step:
        self.display_format = json_content.get("display", None)
        self._display_shortcut = None  # overwritten in next step:
        self.display_shortcut_format = json_content.get("display_shortcut", None)
        self._sub_schema_default = (
            type(self)(
                json_content["subschema"],
                is_default=True,
                default=self.default.sub_schema_default,
                options=self.options,
            )
            if "subschema" in json_content
            else None
        )
        self._initialise_subs(json_content)
        self._inofficial_subs = []
        try:
            _ = self.levelname
        except InvalidLocation:
            if self._subs:
                raise InvalidLocationSchema(
                    f"If sub schemas for {"a default schema" if self._is_default else self.name} are mentioned, "
                    "also a levelname is necessary "
                    f"to specify the subschema. Tried to have {len(self._subs)} subschemas."
                )

    @property
    def default(self) -> Self:
        """A default value holder schema. Create, if it does not exist yet."""
        if self._default is None:
            self._default = type(self)({}, is_default=True, options=self.options)
        return self._default

    def _initialise_subs(self, json_content: dict[str, Any]):
        """Read sub element information and return info accordingly."""
        self._subs: Optional[list[Self]] = []
        sub_element_list = json_content.get("subs", [])
        try:
            sub_element_iter = iter(sub_element_list)
        except TypeError as typeerror:
            raise InvalidLocationSchema(
                "subs contains something that is not a list"
            ) from typeerror
        for sub_element in sub_element_iter:
            self.add_sub(sub_element)
        assert len(self._subs) == len(sub_element_list)
        if not self._subs:
            self._subs = None

    @property
    def sub_schema_default(self) -> Optional[Self]:
        """The default-schema value holder for sub schemas. Can be effectively empty.

        This is a property so that it is only created if actually needed.
        Otherwise, the underlying private property can stay None, avoiding
        infinite recursion during object creation.

        Setting the sub schema default is not possible. Instead, use the existing
        one and change it.

        Remark: we might have a problem here if the default of self is empty. Then the sub schema default
            has no default itself. But if this default is filled later, it is not connected to the subs
            of self.

        Returns:
            None if neither this nor the default have a sub schema default.
            The own sub schema default if it exists.
            Otherwise, the default's sub schema default.
        """
        if self._sub_schema_default is None:
            if self.default.empty():
                return None
            return self.default.sub_schema_default
        return self._sub_schema_default

    def ensure_own_sub_schema_default(self) -> Self:
        """Return sub schema default, ensuring it's this schema's own without resorting to the default's.

        If this schema has a sub schema default, use it.
        If it does not, create it empty.
        """
        if self._sub_schema_default is None:
            self._sub_schema_default = type(self)({}, self.options, True)
        return self._sub_schema_default

    @property
    def subs(self) -> tuple[Self]:
        """List of sub schemas.

        Do not include unofficial sub schemas.

        Use sub schemas from default if None are saved here.

        Empty tuple in case of no saved sub schemas.
        """
        if not self._subs:
            if self._default is not None:
                return tuple(self._default.subs)
            return tuple()
        return tuple(self._subs)

    def add_sub(self, sub_element: Union[dict[str, Any], str]):
        """Add a sub schema.

        The sub schema gets the subschema default as the default.
        Args:
            sub_element: if str or int, use as name. If dict, use all information in dict.
        Raises:
            InvalidLocationSchema: if name of sub_element already exists in a subschema
        """
        if isinstance(sub_element, (str, int)):
            if any(sub.name == sub_element for sub in self._subs):
                raise InvalidLocationSchema(
                    f"The name {sub_element} is already taken "
                    f"by a subschema of {'a default schema' if self.is_default() else self.name}."
                )
            self._subs.append(
                type(self)(
                    {"name": sub_element},
                    default=self.sub_schema_default,
                    options=self.options,
                )
            )
        elif isinstance(sub_element, dict):
            if "name" in sub_element and any(
                sub.name == sub_element for sub in self._subs
            ):
                raise InvalidLocationSchema(
                    f"The name {sub_element} is already taken "
                    f"by a subschema of {'a default schema' if self.is_default() else self.name}."
                )
            # if "name" not in sub_element, a different error is raised later
            self._subs.append(
                type(self)(
                    sub_element, default=self.sub_schema_default, options=self.options
                )
            )
        else:
            raise InvalidLocationSchema(
                'Elements of list in "subs" or new sub schema information must be '
                "str, int (name) or dict (schema)."
            )

    def empty(self) -> bool:
        """True if no information is saved within this schema.

        To be used to avoid infinite recursion and avoiding saving empty dictionaries to file.
        """
        return (
            (self.is_default() or self._name in EMPTY)
            and (self._sub_schema_default is None or self._sub_schema_default.empty())
            and self._levelname is None
            and (self.is_default() or self._shortcut is None)
            and (not self.subs)  # empty or None
            and (not self._label.to_jsonable_data())
        )

    def get_subschema(self, key: str | int) -> Self:
        """Get the subschema for the given key.

        If subs are given, first their names are checked for a match,
        then their shortcuts.
        Otherwise, a generic schema based on the default schema is given.
        In this case, all keys are accepted and if a subschema with this name
        was queried before, it is reused.
        """
        try:
            _ = self.levelname
        except AttributeError:
            assert self._subs is None and len(self._inofficial_subs) == 0, (
                "No levelname is saved but subschema names for "
                f"{'a default schema' if self.is_default() else self.name}"
            )
            raise InvalidLocation(
                "Try to get a subschema for a schema without a levelname. "
                "That cannot work."
            )
        if self._subs is None:  # todo error
            suitably_named_subs = [
                sub for sub in self._inofficial_subs if sub.name == key
            ]
            if len(suitably_named_subs) == 1:
                return suitably_named_subs[0]
            assert (
                len(suitably_named_subs) == 0
            ), f"Somehow two inofficial subschemas with name {key} were created."
            new_subschema = type(self)(
                {"name": key}, default=self.sub_schema_default, options=self.options
            )
            self._inofficial_subs.append(new_subschema)
            return new_subschema
        suitably_named_subs = [sub for sub in self._subs if sub.name == key]
        if len(suitably_named_subs) == 1:
            return suitably_named_subs[0]
        if len(suitably_named_subs) > 1:
            raise InvalidLocationSchema(
                f"{self._levelname} has the name " f"{key} twice in subschemas."
            )
        suitably_named_subs = [sub for sub in self._subs if sub.shortcut == key]
        if len(suitably_named_subs) == 1:
            return suitably_named_subs[0]
        if len(suitably_named_subs) > 1:
            raise InvalidLocationSchema(
                f"{self._levelname} has the shortcut " f"{key} twice in subschemas."
            )
        raise InvalidLocation(
            f"The key {key} is not a valid subschema "
            f"for {self._name} (levelname: {self._levelname}.)"
        )

    @property
    def name(self) -> str | int:
        """Get the name used in location strings and for specifying this schema.

        Raises:
            AttributeError: if is_default is True
        """
        # Ignore default because name cannot come from default.
        return self._name

    def _set_name(self, new_name: Optional[Value]):
        """Set the name without alerting other objects.

        Args:
            new_name. The new name for this Schema. Must be None or pure whitespace string
            for default schemas (those with is_default == True)
        Raises:
            InvalidLocationSchema: if new_name is essentially empty if not is_default
                or non-empty if is_default
        """
        new_name = (
            new_name.strip()
            if isinstance(new_name, str)
            else (None if new_name is None else int(new_name))
        )
        if self.is_default():
            if new_name not in EMPTY:
                raise InvalidLocationSchema("A default schema cannot have a name.")
            try:
                _ = self._name
            except AttributeError:
                return  # correct
            else:
                assert (
                    False
                ), f"Somehow the name {self._name} sneaked into a default schema."
        else:
            if new_name in EMPTY:
                raise InvalidLocationSchema(
                    "A schema name must exist and not be empty or a pure whitespace string."
                )
        self._name = new_name

    @name.setter
    def name(self, new_name: Value) -> None:
        """Set the name.

        Note that locations using this schema need to be saved. This is not done within this setter.
        """
        self._set_name(new_name=new_name)

    @property
    def display_format(self) -> str | None:
        """Return the used display format. Can come from default schema.

        If this is a default location schema, return None if nothing is found. Otherwise, return {separator} {name}.
        """
        if self._display:
            return self._check_display_format(self._display, "name")
        if self._default is not None:
            default_format = self._default.display_format
            if default_format:
                return default_format
        if self.is_default():
            return None
        # thin space around separator is in default of {separator}
        return "{separator}{name}"

    @property
    def display_shortcut_format(self) -> str | None:
        """Return the used display format for shortcuts. Can come from default schema.

        If not specified, use the one for display (non-shortcut) but with {shortcut} added
        if {name} is missing.

        If this is a default location schema, return None if nothing is found. Otherwise, return {sep} {shortcut}.
        """
        if self._display_shortcut:
            return self._check_display_format(self._display_shortcut, "shortcut")
        if self._default is not None:
            default_format = self._default.display_shortcut_format
            if default_format:
                return default_format
        if self._display:
            return self._check_display_format(self._display, "shortcut")
        if self._default is not None:
            default_format = self._default.display_format
            if default_format:
                return default_format
        if self.is_default():
            return None
        return "{sep}{shortcut}"

    @staticmethod
    def _check_display_format(
        display: str | None,
        added_keyword: str,
        needed_keywords: set[str] = {"name", "shortcut"},
        extra_allowed_keywords: set[str] = {"sep", "separator"},
    ) -> str:
        """Check if the display format string is usable.

        Args:
            display: format string to be checked
            added_keyword: keyword that is added if none of the needed_keywords is included
            needed_keywords: keywords that are allowed to appear in the format string of which at least one must appear,
                otherwise the added_keyword is added.
            extra_allowed_keywords: other keywords that are allowed but are not obligatory
        Raises:
            InvalidLocationSchema: if the condition above is not satisfied.
        Returns:
            format string with added_keyword appended if no needed_keyword is included
            None if display is None
        """
        if display is None:
            # no further checks
            return None
        keywords = {
            keyword
            for _, keyword, _, _ in string.Formatter().parse(display)
            if keyword is not None
        }
        if not keywords.issubset(needed_keywords.union(extra_allowed_keywords)):
            raise InvalidLocationSchema(
                f"A display format {display} is invalid because only the placeholders "
                f"{' and '.join(needed_keywords.union(extra_allowed_keywords))} are allowed, not "
                f"{', '.join(keywords.difference(needed_keywords, extra_allowed_keywords))}."
            )
        if not keywords.intersection(needed_keywords):
            return f"{display}{{{added_keyword}}}"
        return display

    @display_format.setter
    def display_format(self, display: str | None) -> None:
        """Set the display format string.

        It is interpreted as a python format string and allows the placeholders {name} and {shortcut}.

        If None, the default will be used.

        Raises:
            InvalidLocationSchema: if the condition above is not satisfied.
        """
        self._check_display_format(display, "{name}")
        # ! the result of the previous function is not saved. If needed "{name}" is added when the display is used.
        self._display = display

    @display_shortcut_format.setter
    def display_shortcut_format(self, display: str | None) -> None:
        """Set the display shortcut format string.

        It is interpreted as a python format string and allows the placeholders {name} and {shortcut} of which
        at least one must be included.

        If None, the default will be used.

        Raises:
            InvalidLocationSchema: if the condition above is not satisfied.
        """
        self._check_display_format(display, "{shortcut}")
        # ! the result of the previous function is not saved. If needed "{shortcut}" is added when the display is used.
        self._display_shortcut = display

    def display(self, sub: Self) -> str:
        """Display the name of sub.

        Use the display format string.
        """
        return self.display_format.format(
            name=sub.name,
            shortcut=sub.shortcut,
            sep=self.options.separator,
            separator=self.options.long_separator,
        )

    def display_shortcut(self, sub: Self) -> str:
        """Display the shortcut of sub.

        Use the display shortcut format string.
        """
        return self.display_shortcut_format.format(
            name=sub.name,
            shortcut=sub.shortcut,
            sep=self.options.separator,
            separator=self.options.long_separator,
        )

    @property
    def shortcut(self) -> str | int:
        """Get the shortcut used in location strings.

        Raises:
            AttributeError: if is_default is True
        """
        # Ignore default because name cannot come from default.
        if self._shortcut is None:
            return self.name[0] if isinstance(self._name, str) else int(self._name)
        return self._shortcut

    @shortcut.setter
    def shortcut(self, new_shortcut: Optional[Value]) -> None:
        """Set the shortcut.

        If None or empty string, use default shortcut based on name (first letter).
        """
        new_shortcut = (
            new_shortcut.strip()
            if isinstance(new_shortcut, str)
            else (None if new_shortcut is None else int(new_shortcut))
        )
        if self.is_default():
            if new_shortcut not in EMPTY:
                raise InvalidLocationSchema("A default schema cannot have a shortcut.")
            try:
                _ = self._shortcut
            except AttributeError:
                return  # correct
            else:
                assert (
                    False
                ), f"Somehow the shortcut {self._shortcut} sneaked into a default schema."
        else:
            if new_shortcut in EMPTY:
                new_shortcut = None
        self._shortcut = new_shortcut

    def is_default(self) -> bool:
        """True if this schema is a default value holder for subschemas.

        If True, it has no name and no shortcut.
        """
        return self._is_default

    @property
    def levelname(self) -> str:
        """Get levelname, which is the key in locations to specify the subschema.

        If not specified explicitly, use levelname from default.

        A levelname which is the empty string "" is used as if no levelname is given but also overwrites
        a levelname from the default.

        Raises:
            InvalidLocation if no subschemas are allowed due to missing levelname.
        """
        if self._levelname == "":
            raise InvalidLocation(
                f"The schema {"(a default)" if self.is_default() else self._name} "
                "has explicitly no levelname (overwriting possible levelname from default)."
            )
        if self._levelname is None:
            if self._default is not None:
                try:
                    return self.default.levelname
                except InvalidLocation:
                    raise InvalidLocation(
                        f"The schema {"(a default)" if self.is_default() else self._name} "
                        "and its default have no levelname."
                    )
            raise InvalidLocation(
                f"The schema {"(a default)" if self.is_default() else self._name} has no levelname."
            )
        return self._levelname

    @levelname.setter
    def levelname(self, new_levelname: str) -> None:
        """Set the levelname.

        Changing all locations with this levelname might be necessary.
        Checking if the new levelname clashes with higher or lower levels is
        hard but necessary.

        If there was no levelname before, maybe creating new sub schemas
        is necessary.

        Surrounding whitespace is removed.

        As described in levelname (setter), an empty string sets this schema to have no levelname,
        possibly overwriting a levelname from the default.
        """
        new_levelname = new_levelname.strip()
        if new_levelname == "":
            if self._subs or len(self._inofficial_subs) > 0:
                # or any change listeners are registered
                raise ValueError(
                    "Levelnames must be non-empty strings. "
                    "Deleting levelnames is only supported "
                    "if no sub elements are known. Just don't use it."
                )
        self._levelname = new_levelname

    def get_levelname(self) -> Optional[str]:
        """Get levelname without resorting to default. Can be None."""
        return self._levelname

    @property
    def label(self) -> defaulted_data.DefaultedDict:
        """Label sizes etc. for those labels that are not have those information themselves.

        Returns:
            Saved label info, can be without data.
        """
        return self._label

    def get_schema_hierarchy(self, location_info: dict[str, Any]) -> list[Self]:
        """Return a list of nested schemas for this location starting with this."""
        try:
            levelname = self.levelname
        except InvalidLocation:
            return [self]
        if (
            levelname is None  # this schema has no subelements
            # no sub is given
            or levelname not in location_info
            # sub is explicitly set to None
            or (levelname in location_info and location_info[levelname] is None)
        ):
            return [self]
        return [self] + self.get_subschema(
            location_info[levelname]
        ).get_schema_hierarchy(location_info)

    def get_valid_subs(
        self, shortcuts: Literal["yes", "only", "()", "*", "no"] = "yes"
    ) -> Optional[list[Union[str, int]]]:
        """A list of valid sub schemas. Usable for suggesting options.

        Args:
            shortcuts: if valid shortcuts should be listed as well:
                'no': shortcuts are not listed
                'yes': shortcuts listed in the same way as names,
                'only': only shortcuts are listed
                '()': shortcuts are listed in parentheses after the name (note: result
                    elements are not valid values)
                '*': shortcuts are marked with ** ** if they are in the name, otherwise like '()'
        Return:
            None if no levelname is given,
            an empty list if everything is valid

        todo:
            handle subs in default schema!
        """
        try:
            _ = self._levelname
        except InvalidLocation:
            return None
        if shortcuts == "no":
            return [sub.name for sub in self.subs]
        if shortcuts == "yes":
            return [name for sub in self.subs for name in (sub.name, sub.shortcut)]
        if shortcuts == "only":
            return [sub.shortcut for sub in self.subs]
        if shortcuts == "()":
            return [f"{sub.name} ({sub.shortcut})" for sub in self.subs]
        if shortcuts == "*":
            return [
                (
                    (
                        f"{str(sub.name)[:str(sub.name).index(str(sub.shortcut))]}"
                        f"**{sub.shortcut}**"
                        + str(sub.name)[
                            str(sub.name).index(str(sub.shortcut))
                            + len(str(sub.shortcut)) :
                        ]
                    )
                    if str(sub.shortcut) in str(sub.name)
                    else f"{sub.name} ({sub.shortcut})"
                )
                for sub in self.subs
            ]
        raise ValueError('shortcuts needs to be one of "yes", "only", "()", "*"')

    @classmethod
    def from_file(cls, directory: pathlib.Path, options: constant.Options):
        """Read schema from SCHEMA_FILE in directory.

        If file does not exist, create empty schema.
        """
        try:
            schema_file = open(directory / constant.SCHEMA_FILE)
        except FileNotFoundError:
            return cls({"name": "Workshop"}, options=options)
        return cls(yaml.safe_load(schema_file), options=options)

    def to_dict(self) -> dict[str, Any] | str | int:
        """Json representation of this Schema (and its subschemas).

        It can be fully recreated with the result of this function.
        """
        json = dict()
        if not self.is_default():
            json["name"] = self.name
            if self._shortcut:
                json["shortcut"] = self.shortcut
        if self.description not in EMPTY:
            json["description"] = self.description
        if self._levelname not in EMPTY or self._levelname == "":
            json["levelname"] = self._levelname
        if self._label is not None and (label_info := self._label.to_jsonable_data()):
            # non-empty
            json["label"] = label_info
        if self._display is not None:
            json["display"] = self._display
        if self._display_shortcut is not None:
            json["display_shortcut"] = self._display_shortcut
        if self._sub_schema_default and not self._sub_schema_default.empty():
            json["subschema"] = self.sub_schema_default.to_dict()
        if self._subs:  # non-empty
            json["subs"] = [sub.to_dict() for sub in self._subs]
        if len(json) == 1 and not self.is_default() and "name" in json:
            # the simple case
            return self.name
        return json

    def save(self, directory: pathlib.Path) -> None:
        """Save this schema to file as yaml."""
        with open(directory / constant.SCHEMA_FILE, mode="w") as schema_file:
            yaml.dump(self.to_dict(), schema_file, **constant.YAML_DUMP_OPTIONS)


class Location(MutableMapping[str, Value]):
    """A location for stuff. Member var definition in schema.

    Values are accessed with dict member notation. `loc["shelf"] = 5`

    Attributes:
        _schema: schema defining the meaning of the keys
        _levels: list of schemas for all levels of the location hierarchy
        _extra: extra information that does not fit into the schema
                hierarchy but might again after changes
        options: global options including the seperator
    """

    def __init__(
        self,
        schema: Schema,
        data: dict[str, Value],
        directory: None | str | pathlib.Path,
        options: constant.Options,
    ):
        """Create a location from data and the schema.

        schema: location schema
        data: location data as a dict
        directory: where to save this location to (saved to directory/{constant.LOCATION_FILE})
        options: general inventory options (separator is used)
        """
        self._directory = None  # no autosave during initialisation
        self.options = options
        self._directory = None if directory is None else pathlib.Path(directory)
        self._logger = logging.getLogger(__name__)
        self._schema = schema
        self._levels = self._schema.get_schema_hierarchy(data)
        self._extra = {
            key: data[key]
            for key in data
            if key not in self.from_schema_hierarchy(self._levels)
        }
        if self._extra:
            logging.getLogger(f"location {self} @ {self._directory}").info(
                f"has extra information {self._extra}."
            )

    def __getitem__(self, key, /) -> Value:
        """Get the value for a key, usually levelname.

        Raises:
            KeyError: if the key does not exist or is in lowest-most level.
        """
        for index in range(len(self._levels) - 1):
            if self._levels[index].levelname == key:
                return self._levels[index + 1].name
        return self._extra[key]  # may raise KeyError

    def _shortcut(self) -> str:
        """Get string representation with shortcuts.

        Returns:
            shortcuts of levels separated by separator. "" if no information is saved.
            In particular in that case no default values for top levels are shown.
        """
        if not self._levels:
            return ""
        return "".join(
            itertools.chain(
                (str(self._levels[0].shortcut),),
                (
                    level.display_shortcut(sub)
                    for level, sub in zip(self._levels[:-1], self._levels[1:])
                ),
            )
        )

    @property
    def long_name(self) -> str:
        """Get the string representation with names.

        Returns:
            names of levels separated by long_separator. "" if no information is saved.
            In particular in that case no default values for top levels are shown.
        """
        if not self._levels:
            return ""
        return "".join(
            itertools.chain(
                (str(self._levels[0].name),),
                (
                    level.display(sub)
                    for level, sub in zip(self._levels[:-1], self._levels[1:])
                ),
            )
        )

    @property
    def schema(self) -> Schema:
        """Return the schema given in the location file used to define this location."""
        return self._schema

    def __str__(self):
        """Get string representation of the location.

        Uses the schema and the separator.

        Assumes that the schema is valid.

        Raises:
            InvalidLocation: if the location info do not suit
            the schema
        Returns:
            shortcuts for places separated by
            separator given at initialisation
            Can be an empty string if the top-level schema
            is not present or None.
        """
        return self._shortcut()

    def to_sortable_tuple(self):
        """Return the data of this location as sortable tuple."""
        return (level.name for level in self._levels)

    def update_from_dict(self, data: dict[str, Value], save: bool = True):
        """Save all applicable information from data in level, rest in extra.

        Replaces information held in this location.
        Save to file.

        Args:
            data: data to be saved. Keys are level names of schema
            save: flag. If Falsish, do not save to file. Use to avoid infinite recursion
                  or unnecessary I/O.
        """
        self._levels = self._schema.get_schema_hierarchy(data)
        used_data = self.from_schema_hierarchy(self._levels)
        self._extra = {key: data[key] for key in data if key not in used_data}
        if self._extra:
            logging.getLogger(f"location {self} @ {self._directory}").info(
                f"has extra information {self._extra}."
            )
        if self._directory is not None and save:
            self.save()

    def __setitem__(self, level: str, value: Value) -> None:
        """Set one level info.

        Or deletes it if it's None or "" or [] or {} (see EMPTY)

        Update internal info.
        """
        data = self.to_jsonable_data()
        if value in EMPTY:
            if level in data:
                del data[level]
        else:
            data[level] = value
        self.update_from_dict(data)

    def __delitem__(self, key: str) -> None:
        """Deletes one information.

        Update internal info.

        Raises:
            KeyError: if the key does not exist
        """
        data = self.to_jsonable_data()
        del data[key]
        self.update_from_dict(data)

    def __bool__(self):
        """True if something is saved."""
        return len(self._levels) > 1 or len(self._extra) > 0

    def save(self):
        """Save location data to yaml file."""
        if self.directory is None:
            return
        path = self._directory / constant.LOCATION_FILE
        if self:  # not empty?
            os.makedirs(self._directory, exist_ok=True)
            with open(path, mode="w", encoding="utf-8") as location_file:
                yaml.dump(
                    data=self.to_jsonable_data(),
                    stream=location_file,
                    **constant.YAML_DUMP_OPTIONS,
                )
            self._logger.info(f"Saved {self.directory} location to {path}.")
        else:
            if path.is_file():
                self._logger.info(f"Delete {path}")
            path.unlink(missing_ok=True)

    @staticmethod
    def from_schema_hierarchy(schema_hierarchy: list[Schema]) -> dict[str, Value]:
        """Get levelname: name pairs."""
        return {
            level.levelname: schema_hierarchy[index + 1].name
            for index, level in list(enumerate(schema_hierarchy))[:-1]
        }

    def to_jsonable_data(self) -> dict[str, Value]:
        """Convert to dict with levelnames as keys.

        Ignores extra information with the same key as levelnames
        in the saved levels.

        Sorts by schema hierarchy.
        """
        # check that _extra cannot overwrite information from schema hierarchy in the | operator:
        assert set(self._extra).isdisjoint(
            set(self.from_schema_hierarchy(self._levels))
        )
        return self.from_schema_hierarchy(self._levels) | self._extra

    @classmethod
    def from_yaml_file(
        cls, directory: str | pathlib.Path, schema: Schema, options: constant.Options
    ):
        """Create location from yaml file.

        Args:
            directory: file is directory/{constant.LOCATION_FILE}
            schema: location schema for interpreting the data
            options: inventory-wide options, in particular separator
        """
        path = pathlib.Path(directory) / constant.LOCATION_FILE
        try:
            location_file = open(path, mode="r", encoding="utf-8")
        except FileNotFoundError:
            return cls(schema=schema, data={}, directory=directory, options=options)
        with location_file:
            data = yaml.safe_load(location_file)
            return cls(
                schema=schema,
                data=data if data is not None else {},
                directory=directory,
                options=options,
            )

    @property
    def directory(self) -> Optional[str]:
        """The directory in which the location data file is saved.

        If none, changes are not saved.
        """
        return self._directory

    @directory.setter
    def directory(self, new_directory: str | pathlib.Path):
        """Set the directory in which the data file is saved.

        Save the data there.
        The old data file is removed.
        """
        if self._directory is not None:
            (self._directory / constant.LOCATION_FILE).unlink(missing_ok=True)
        assert (
            new_directory is not None
        ), "Set None directory to location is not supported."
        self._directory = pathlib.Path(new_directory)
        self.save()

    def __len__(self):
        """Amount of information.

        Sum of extra information and non-bottom-most level.
        """
        return max(0, len(self._levels) - 1 + len(self._extra))

    def __iter__(self):
        """Lists all keys."""
        iter(self.to_jsonable_data())

    @property
    def label(self) -> Union[Literal[{}], defaulted_data.DefaultedDict]:
        """Label information of the most concrete schema of this location.

        If location is empty, return empty dict.
        """
        if self._levels:
            return self._levels[-1].label
        return {}
