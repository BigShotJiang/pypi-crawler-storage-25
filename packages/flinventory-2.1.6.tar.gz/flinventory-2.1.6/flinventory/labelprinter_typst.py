#!/usr/bin/env python3
"""Use a typst document to create labels (for printing and gluing to boxes)."""
import importlib.resources
import json
import logging
import pathlib
from typing import Union, Optional, Literal

from .box import BoxedThing
from . import inventory_io, box
from . import thingtemplate_typst
from . import defaulted_data

try:
    from .font_location import FONT
except ImportError:
    try:
        from font_location import FONT
    except ImportError:
        # not patched, no font available via font_location but maybe via env var
        FONT = ""


import typst

TYPST_CODE = "label.typ"
# todo: maybe not necessary due to importtools resources to_file supporting direct

UNIT = "cm"  # todo: replace by length_unit in options, includes scaling the constants
# default font size unit if it's saved as a number
FONT_UNIT = "pt"
# valid units and their length in UNIT
TYPST_UNITS = {"pt": 2.54 / 72, "mm": 0.1, "cm": 1, "in": 2.54}

# paper text width (a4 = 21 cm wide) in cm
PAPER_TEXT_WIDTH = 20
# minimal height of label for including an image (in cm)
MINIMAL_HEIGHT_FOR_IMAGE = 3

# maximum width of a label [cm]
MAX_WIDTH = 18  # otherwise too wide for A4 page
# maximum height for a label [cm]
MAX_HEIGHT = 28  # otherwise too long for A4 page


class LabelPrinter:
    # pylint: disable=too-many-instance-attributes
    """Class encapsulating algorithm for creating printable signs from thing list.

    Bad design choice: you have to create an object but actually this object is never used,
    could all just be module or class functions.
    """

    def __init__(self):
        """Create SignPrinter by reading in template files."""
        self.logger = logging.getLogger(__name__)

    def in_unit(
        self, length: None | int | float | str, default_unit: str = UNIT
    ) -> None | float | int:
        """Convert length to UNIT, using factors given by TYPST_UNITS.

        If length is None, return None.
        If length is number, assume unit is default_unit.
        If length is str, check for unit. If not a valid length
        (meaning number + unit or just number), log error and return None.
        Returns:
            None or length in UNIT as float or int.
        Raises KeyError:
            if default_unit not in TYPST_UNITS
        """
        if length is None:
            return None
        try:
            in_default_unit = float(length)
        except ValueError:
            if not isinstance(length, str):
                self.logger.error(
                    f"Cannot understand {length} of type {type(length)} as a length."
                )
                return None
            for unit in TYPST_UNITS:
                assert (len(unit)) > 0, "What weird unit '' was introduced?"
                if length.endswith(unit):
                    try:
                        length_in_unit = float(length[: -len(unit)])
                    except ValueError:
                        self.logger.error(
                            f"Cannot understand {length} of unit {unit} and non-number {length[:len(unit)]}."
                        )
                        return None
                    in_unit = length_in_unit * TYPST_UNITS[unit]
                    break
            else:
                self.logger.error(
                    f"Cannot find a valid unit in {length}. Valid units are {list(TYPST_UNITS)}."
                )
                return None
        else:
            in_unit = in_default_unit * TYPST_UNITS[default_unit]
        if in_unit <= 0:
            self.logger.error(
                f"{length} is non-positive and therefore not a valid length. "
                f"Use default instead."
            )
            return None
        if int(in_unit) == in_unit:
            return int(in_unit)
        return in_unit

    @staticmethod
    def get_label_value(thing: BoxedThing, key: defaulted_data.Key):
        """Get value from thing.sign. If missing, get value from thing.location.label.

        Otherwise, return None.
        """
        return thing.sign.get(key, thing.location.label.get(key, None))

    def controlled_length(
        self,
        thing: BoxedThing,
        key: str,
        maximum: Union[int, float],
    ):
        """Get the value for the key if it exists and is a number or length and > 0, otherwise None.

        If it's bigger than maximum, use maximum (in UNIT).
        The default (backup) value is in the label typst code.

        Add UNIT.

        Args:
            thing: thing with sign and location. Use information from sign if it has it.
                Otherwise, from label in location. Otherwise, None.
            key: the queried dimension
            maximum: Maximum value.
        """
        value = self.in_unit(self.get_label_value(thing, key))
        if value is None:
            return None
        value = min(value, maximum)
        return f"{value}{UNIT}" if isinstance(value, int) else f"{value:3f}{UNIT}"

    def ensure_font_size(self, thing: BoxedThing, key: str):
        """Convert thing.sign["key"] to length, assuming pt as unit if unit not given."""
        return self.in_unit(self.get_label_value(thing, key), default_unit="pt")

    def thing_data(self, thing: BoxedThing) -> dict[str, str]:
        """Get values for the insertion into the templates for one thing."""
        data: dict[str, int | float | None | str] = {
            "width": self.controlled_length(thing, key="width", maximum=MAX_WIDTH),
            "height": self.controlled_length(thing, key="height", maximum=MAX_HEIGHT),
            "name_1": thing.sign.get(("name", 0), None),
            "name_1_height": self.get_label_value(thing, ("name_height", 0)),
            "name_1_font_size": self.ensure_font_size(thing, ("font_size", 0)),
            "lang_1": thing.options.languages[0],  # one language is guaranteed
            "name_2": thing.sign.get(("name", 1), None),
            "name_2_height": self.get_label_value(thing, ("name_height", 1)),
            "name_2_font_size": self.ensure_font_size(thing, ("font_size", 1)),
            "lang_2": (thing.options.languages + [None])[1],  # None is default
            "image": thing.thing.image_path(),  # might be None, use dummy image then
            "where": (
                str(thing.location.long_name)
                if thing.sign.get("location_long", True)
                else str(thing.where)
            ),
            "where_font_size": self.ensure_font_size(thing, "font_size_location"),
        }

        if not data["where"]:  # empty string
            self.logger.warning(
                f"Print sign for {data["name_1"]} ({data["name_2"]}) without location."
            )

        if data["image"] is None:
            self.logger.warning(f"Missing image for {thing.identification_for_log()}.")
        # at first only portrait sign, landscape sign can be implemented later
        # if self.if_use_landscape_template(thing):  # would need different condition

        return {key: str(data[key]) for key in data if data[key] is not None}

    def sign_things_to_be_printed(
        self, inventory: inventory_io.Inventory
    ) -> dict[box.BoxedThing, dict[str, str]]:
        """Get all things to be printed from inventory with their print data.

        Returns:
            dict thing to its data for printing
        """
        return {
            thing: thing_data
            for thing in inventory
            if (
                thing.sign.should_be_printed()
                and "width" in (thing_data := self.thing_data(thing))
                and "height" in thing_data
                and ("name_1" in thing_data or "name_2" in thing_data)
                and "where" in thing_data
            )
        }

    def things_data(self, inventory: inventory_io.Inventory) -> list[dict[str, str]]:
        """Get data for all things to be printed from inventory.

        Only include things that have labels saying that they want to be printed.

        Sorted by label height.
        """
        return sorted(
            self.sign_things_to_be_printed(inventory).values(),
            key=lambda data: data["height"],
        )

    def create_label(
        self,
        thing: BoxedThing,
        out: Union[
            Literal["svg"],
            Literal["pdf"],
            Literal["html"],
            Literal["png"],
            pathlib.Path,
        ] = "svg",
    ) -> Optional[bytes]:
        """Create a label based on the template label.typ.

        Args:
            thing: thing for which label should be created
            out: "svg", "pdf", "png": output is bytes object with this data format, path: saved to this path
                if path is used and file type is png or svg, must include {n} to be replaced by the page number(s)
        Returns:
            bytes object if out is not a path. None otherwise.
        Raises:
            typst.TypstError: if typst did not compile
        """
        data = self.thing_data(thing)
        assert "data" not in data, "a key 'data' is reserved for case for many labels"
        try:
            data["image"] = str(pathlib.Path(data["image"]).absolute())
        except KeyError:
            pass  # no image, fine
        return self.run_typst(
            out=out,
            template="label.typ",
            data=data,
            description=f"label for {thing.identification_for_log()}",
        )

    def create_labels(
        self,
        things: inventory_io.Inventory,
        out: Union[
            Literal["svg"],
            Literal["pdf"],
            Literal["html"],
            Literal["png"],
            pathlib.Path,
        ] = "pdf",
    ) -> Optional[bytes]:
        """Create a label based on the template label.typ.

        Args:
            things: inventory with things for which labels should be created
            out: "svg", "pdf", "png": output is bytes object with this data format, path: saved to this path
                if path is used and file type is png or svg, must include {n} to be replaced by the page number(s)
        """
        data = self.things_data(things)
        for thing_data in data:
            try:
                thing_data["image"] = str(pathlib.Path(thing_data["image"]).absolute())
            except KeyError:
                pass  # no image, fine
        return self.run_typst(
            out=out,
            template="label.typ",
            data={"data": json.dumps(data)},
            description=f"labels for {len(data)} things",
        )

    def run_typst(
        self,
        out: Union[
            Literal["svg"],
            Literal["pdf"],
            Literal["html"],
            Literal["png"],
            pathlib.Path,
        ],
        data: dict[str, str],
        template: str,
        description: str,
    ) -> Optional[bytes]:
        """Compile a typst file including error-handling.

        If included files are data, make them absolute. The root of the project given to typst is "/".

        Args:
            out: "svg", "pdf", "png": output is bytes object with this data format, path: saved to this path
                if path is used and file type is png or svg, must include {n} to be replaced by the page number(s)
            data: data included as sysinputs
            template: file out of thingtemplate_typst to be used
            description: description what is created for warning / error message
        Returns:
            None if out is a path, bytes if out is a format. Then the content of the result file.
        Raises:
            typst.TypstError: if typst did not compile
        """
        with importlib.resources.as_file(
            importlib.resources.files(thingtemplate_typst)
        ) as template_dir:
            assert isinstance(template_dir, pathlib.Path)
            file_format = (
                out.suffix.lstrip(".")
                if isinstance(out, pathlib.Path)
                and out.suffix.lstrip(".") in ["pdf", "html", "svg", "png"]
                else (out if out in ["pdf", "html", "svg", "png"] else None)
            )
            font_paths = [pathlib.Path(FONT)] if FONT else []
            try:
                output, warnings = typst.compile_with_warnings(
                    input=template_dir / template,
                    root="/",
                    output=out if isinstance(out, pathlib.Path) else None,
                    format=file_format,
                    sys_inputs=data,
                    font_paths=font_paths,
                    ignore_system_fonts=bool(FONT),
                )
            except typst.TypstError as compile_error:
                self.logger.error(f"Typst error: {compile_error}")
                raise
            finally:
                logging.info(
                    f"Tried to create file {out if isinstance(out, pathlib.Path) else None} "
                    f"with format {file_format} and root / and font_paths {font_paths}"
                )
        if warnings:
            self.logger.warning(f"Warnings from typst for {description}: {warnings}")
        return output
