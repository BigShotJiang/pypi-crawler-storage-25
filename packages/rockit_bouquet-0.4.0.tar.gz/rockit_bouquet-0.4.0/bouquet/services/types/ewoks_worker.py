from typing import Any
from pydantic import Field
from ...models import ServiceConfig
from ...defaults import get_default


class EwoksWorkerServiceConfig(ServiceConfig):
    """
    Configuration for Ewoks Worker service.
    """
    redis: str = Field(default="redis")
    redis_port: int = Field(default=6379)
    resource_dir: str = Field(default="")

    def __init__(self, **kwargs: Any):
        super().__init__(**kwargs)
        allowed_service_types = get_default("ALLOWED_SERVICE_TYPES")
        self._service_type = "ewoks_worker"

        if "redis" not in self.model_fields_set:
            self.redis = f"redis_{self.container_name}"

        if not self.container_name:
            self.container_name = "ewoks_worker"
        if not self.image:
            self.image = allowed_service_types["ewoks_worker"]
        if not self.restart:
            self.restart = "always"
        if not self.networks:
            self.networks = ["internal"]
        if not self.depends_on:
            self.depends_on = [self.redis]

        if not self.volumes:
            self.volumes = []
        if self.resource_dir:
            self.volumes.append(f"{self.resource_dir}:/ewoksweb_app/resources")

        default_env = {
            "REDIS_PORT": self.redis_port,
            "REDIS_HOST": self.redis
        }
        if isinstance(self.environment, dict):
            default_env.update(self.environment)
        self.environment = default_env

    class Config:
        extra = "forbid"