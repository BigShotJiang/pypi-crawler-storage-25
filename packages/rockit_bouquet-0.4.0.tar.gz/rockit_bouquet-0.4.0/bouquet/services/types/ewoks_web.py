from typing import Any
from pydantic import Field
import re
from ...models import ServiceConfig
from ...defaults import get_default


class EwoksWebServiceConfig(ServiceConfig):
    """
    Configuration for Ewoks Web service (GUI + Server).
    """
    redis: str = Field(default="redis")
    redis_port: int = Field(default=6379)
    app_port: int = Field(default=8000)
    host_ip: str = Field(default=get_default("DEFAULT_HOST_IP_ADDRESS"))
    host_port: str | int = Field(default=8001)
    allow_traefik: bool = Field(default=True)
    apply_traefik_labels: bool = Field(default=get_default("DEFAULT_APPLY_TRAEFIK_LABELS"))
    resource_dir: str = Field(default="")

    def __init__(self, **kwargs: Any):
        super().__init__(**kwargs)
        allowed_service_types = get_default("ALLOWED_SERVICE_TYPES")
        self.apply_traefik_labels = get_default("DEFAULT_APPLY_TRAEFIK_LABELS")
        self._service_type = "ewoks_web"

        if "redis" not in self.model_fields_set:
            self.redis = f"redis_{self.container_name}"

        if not self.container_name:
            self.container_name = "ewoks_web"
        if not self.image:
            self.image = allowed_service_types["ewoks_web"]
        if not self.restart:
            self.restart = "always"
        if not self.networks:
            self.networks = ["internal"]
        if not self.ports:
            self.ports = [f"{self.host_ip}:{self.host_port}:{self.app_port}"]
        if not self.depends_on:
            self.depends_on = [self.redis]

        if not self.volumes:
            self.volumes = []
        if self.resource_dir:
            self.volumes.append(f"{self.resource_dir}:/ewoksweb_app/resources")

        default_env = {
            "REDIS_PORT": self.redis_port,
            "APP_PORT": self.app_port,
        }
        if isinstance(self.environment, dict):
            default_env.update(self.environment)
        self.environment = default_env

        # Traefik labels integration
        if self.apply_traefik_labels:
            safe_name = re.sub(r"[^a-zA-Z0-9-]", "", self.container_name.replace("_", "-"))
            beamline = re.sub(r"[^a-zA-Z0-9-]", "", get_default("DEFAULT_BEAMLINE_NAME").replace("_", "-"))

            if not self.labels: self.labels = {}
            self.labels.update({
                "traefik.enable": "true" if self.allow_traefik else "false",
                f"traefik.http.routers.{safe_name}.rule": f'Host("{safe_name}.{beamline}")',
                f"traefik.http.services.{safe_name}.loadbalancer.server.port": self.app_port,
            })

    class Config:
        extra = "forbid"