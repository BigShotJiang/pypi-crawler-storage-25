from __future__ import annotations

import syneltra


def test_public_api_exports_core_search_objects():
    assert syneltra.MechanismSearchConfig.recommended().beam_mode == "softmax_beam"
    assert syneltra.Transition("LP-/B+", (1,), (1, 2)).head == "LP-"
    assert "MechanismEnumerator" in syneltra.__all__
    assert "ReactionCase" in syneltra.__all__
