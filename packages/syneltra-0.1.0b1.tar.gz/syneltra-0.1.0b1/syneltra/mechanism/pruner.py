from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, Optional, Tuple, List

import networkx as nx

from ..chemistry.graph import edge_order, materialize_full_graph
from ..core.models import StateSnapshot, Transition, ExpansionContext
from ..core.plan_utils import (
    history_transition_keys,
    next_compatible_encoded_plans,
    plan_boundary_after_step,
    transition_key,
)


class GraphValidityOracle:
    """Validate states by converting the full mapped graph to SMILES."""

    def __init__(
        self,
        graph_to_smi_fn: Optional[Callable[[nx.Graph], Optional[str]]] = None,
        *,
        recompute_charge_before_check: bool = True,
    ) -> None:
        self._graph_to_smi_fn = graph_to_smi_fn
        self._resolved = graph_to_smi_fn is not None
        self.recompute_charge_before_check = bool(recompute_charge_before_check)

    def _resolve_fn(self) -> Optional[Callable[[nx.Graph], Optional[str]]]:
        if not self._resolved:
            try:
                from synkit.IO import graph_to_smi as _graph_to_smi
            except Exception:
                _graph_to_smi = None
            self._graph_to_smi_fn = _graph_to_smi
            self._resolved = True
        return self._graph_to_smi_fn

    def smiles(self, graph: nx.Graph) -> Optional[str]:
        fn = self._resolve_fn()
        if fn is None:
            return None
        full_graph = materialize_full_graph(
            graph,
            recompute_charge=self.recompute_charge_before_check,
        )
        try:
            smi = fn(full_graph)
        except Exception:
            return None
        return smi if smi else None

    def is_valid(self, graph: nx.Graph) -> bool:
        return self.smiles(graph) is not None

    def cache_key(self, graph: nx.Graph) -> Tuple:
        full_graph = materialize_full_graph(
            graph,
            recompute_charge=self.recompute_charge_before_check,
        )
        node_sig = tuple(
            sorted(
                (
                    int(n),
                    full_graph.nodes[n].get("element"),
                    int(full_graph.nodes[n].get("hcount", 0)),
                    int(full_graph.nodes[n].get("lone_pairs", 0)),
                    int(full_graph.nodes[n].get("charge", 0)),
                )
                for n in full_graph.nodes()
            )
        )
        edge_sig = tuple(
            sorted(
                (
                    min(int(u), int(v)),
                    max(int(u), int(v)),
                    float(edge_order(full_graph, u, v)),
                )
                for u, v in full_graph.edges()
            )
        )
        return (node_sig, edge_sig)


@dataclass
class FixedArrowValidityGate:
    """
    Require validity at fixed arrow checkpoints.

    Two modes are supported.

    1. Fixed-span mode:
       if no explicit checkpoint pattern is attached, validity is required
       exactly every ``arrows`` micro-steps from the last valid anchor.

    2. Pattern mode:
       if ``bundle_spans`` or ``checkpoint_pattern`` is present, each span is
       consumed in sequence, e.g. ``(2, 2)`` means check at +2, then +2 again
       from the new valid anchor.
    """

    arrows: int = 2
    bundle_spans: Optional[Tuple[int, ...]] = None
    cache_smiles: bool = False

    def __post_init__(self) -> None:
        self.arrows = max(1, int(self.arrows))
        if self.bundle_spans is not None:
            self.bundle_spans = tuple(max(1, int(x)) for x in self.bundle_spans)

    def initialize_root(self, state: StateSnapshot) -> None:
        preferred = state.graph.graph.get("preferred_checkpoint_pattern")
        pattern = tuple(int(x) for x in preferred) if preferred is not None else self.bundle_spans
        state.memory.setdefault(
            "checkpoint_arrows",
            None if pattern is not None else int(self.arrows),
        )
        if pattern is not None:
            state.memory.setdefault("checkpoint_pattern", pattern)
            state.memory.setdefault("checkpoint_index", 0)
        state.memory.setdefault("last_valid_depth", 0)
        state.memory.setdefault("checkpoint_checked", False)
        state.memory.setdefault("last_graph_valid", True)
        state.memory.setdefault("state_smiles", None)
        state.memory.setdefault("validity_gap", 0)
        state.memory.setdefault("checkpoint_depths", [0])
        state.memory.setdefault("checkpoint_validity", [True])
        state.memory.setdefault("arrow_boundary_reached", False)
        state.memory.setdefault("arrow_step_index", 0)

    def _state_smiles(
        self,
        state: StateSnapshot,
        *,
        oracle: GraphValidityOracle,
        validity_cache: Dict[Tuple, Tuple[bool, Optional[str]]],
    ) -> Optional[str]:
        key = oracle.cache_key(state.graph)
        if key not in validity_cache:
            smi = oracle.smiles(state.graph)
            validity_cache[key] = (smi is not None, smi)
        return validity_cache[key][1]

    def _required_span(self, current: StateSnapshot) -> int:
        pattern = current.memory.get("checkpoint_pattern")
        if pattern is None:
            pattern = self.bundle_spans
        if pattern is not None:
            pattern = tuple(pattern)
            idx = int(current.memory.get("checkpoint_index", 0))
            if idx >= len(pattern):
                return int(pattern[-1])
            return int(pattern[idx])
        return int(self.arrows)

    def _annotate_base_memory(
        self,
        current: StateSnapshot,
        next_state: StateSnapshot,
        gap: int,
        next_depth: int,
    ) -> None:
        next_state.memory["checkpoint_arrows"] = None if self.bundle_spans is not None else int(self.arrows)
        next_state.memory["checkpoint_pattern"] = current.memory.get(
            "checkpoint_pattern",
            (None if self.bundle_spans is None else tuple(int(x) for x in self.bundle_spans)),
        )
        next_state.memory["checkpoint_index"] = int(current.memory.get("checkpoint_index", 0))
        next_state.memory["last_valid_depth"] = int(current.memory.get("last_valid_depth", 0))
        next_state.memory["checkpoint_checked"] = False
        next_state.memory["last_graph_valid"] = bool(current.memory.get("last_graph_valid", True))
        next_state.memory["state_smiles"] = None
        next_state.memory["validity_gap"] = int(gap)
        next_state.memory["checkpoint_depths"] = list(current.memory.get("checkpoint_depths", [0]))
        next_state.memory["checkpoint_validity"] = list(current.memory.get("checkpoint_validity", [True]))
        next_state.memory["arrow_boundary_reached"] = False
        next_state.memory["arrow_step_index"] = int(next_depth)

    def _plan_boundary_status(
        self,
        ctx: ExpansionContext,
        transition: Transition,
    ) -> Tuple[bool, List[Tuple[Tuple[Tuple[str, Tuple[int, ...], Tuple[int, ...]], ...], ...]]]:
        raw_plans = ctx.current.graph.graph.get("arrow_plans", ())
        if not raw_plans:
            return False, []
        prefix = history_transition_keys(ctx.history)
        candidate = transition_key(transition)
        matches = next_compatible_encoded_plans(prefix, candidate, raw_plans)
        if not matches:
            return False, []
        step_idx = len(prefix) + 1
        boundary = any(plan_boundary_after_step(plan, step_idx) for plan in matches)
        return bool(boundary), matches

    def evaluate_transition(
        self,
        ctx: ExpansionContext,
        transition: Transition,
        next_state: StateSnapshot,
        next_depth: int,
        *,
        oracle: GraphValidityOracle,
        validity_cache: Dict[Tuple, Tuple[bool, Optional[str]]],
    ) -> bool:
        current = ctx.current
        anchor = int(current.memory.get("last_valid_depth", 0))
        gap = int(next_depth) - anchor
        self._annotate_base_memory(current, next_state, gap, next_depth)

        required = self._required_span(current)
        next_state.memory["arrow_boundary_reached"] = bool(gap == int(required))

        if gap < int(required):
            return True
        if gap > int(required):
            return False

        smi = self._state_smiles(
            next_state,
            oracle=oracle,
            validity_cache=validity_cache,
        )
        valid = smi is not None

        next_state.memory["checkpoint_checked"] = True
        next_state.memory["last_graph_valid"] = bool(valid)
        next_state.memory["state_smiles"] = smi
        next_state.memory["checkpoint_depths"] = list(next_state.memory["checkpoint_depths"]) + [int(next_depth)]
        next_state.memory["checkpoint_validity"] = list(next_state.memory["checkpoint_validity"]) + [bool(valid)]

        if self.cache_smiles and smi is not None:
            next_state.memory["smiles"] = smi

        if not valid:
            return False

        next_state.memory["last_valid_depth"] = int(next_depth)
        next_state.memory["validity_gap"] = 0

        pattern = next_state.memory.get("checkpoint_pattern")
        if pattern is not None:
            idx = int(next_state.memory.get("checkpoint_index", 0))
            pattern = tuple(pattern)
            if idx < len(pattern):
                next_state.memory["checkpoint_index"] = idx + 1

        return True

    def evaluate_next_state(
        self,
        current: StateSnapshot,
        next_state: StateSnapshot,
        next_depth: int,
        *,
        oracle: GraphValidityOracle,
        validity_cache: Dict[Tuple, Tuple[bool, Optional[str]]],
    ) -> bool:
        anchor = int(current.memory.get("last_valid_depth", 0))
        gap = int(next_depth) - anchor
        self._annotate_base_memory(current, next_state, gap, next_depth)

        required = self._required_span(current)
        if gap < int(required):
            return True
        if gap > int(required):
            return False

        smi = self._state_smiles(
            next_state,
            oracle=oracle,
            validity_cache=validity_cache,
        )
        valid = smi is not None

        next_state.memory["checkpoint_checked"] = True
        next_state.memory["last_graph_valid"] = bool(valid)
        next_state.memory["state_smiles"] = smi
        next_state.memory["checkpoint_depths"] = list(next_state.memory["checkpoint_depths"]) + [int(next_depth)]
        next_state.memory["checkpoint_validity"] = list(next_state.memory["checkpoint_validity"]) + [bool(valid)]

        if not valid:
            return False

        next_state.memory["last_valid_depth"] = int(next_depth)
        next_state.memory["validity_gap"] = 0

        pattern = next_state.memory.get("checkpoint_pattern")
        if pattern is not None:
            idx = int(next_state.memory.get("checkpoint_index", 0))
            pattern = tuple(pattern)
            if idx < len(pattern):
                next_state.memory["checkpoint_index"] = idx + 1

        return True

    def rank_next_state(self, next_state: StateSnapshot) -> Tuple[int, int, int]:
        checked = bool(next_state.memory.get("checkpoint_checked", False))
        valid = bool(next_state.memory.get("last_graph_valid", False))
        gap = int(next_state.memory.get("validity_gap", 0))
        boundary = bool(next_state.memory.get("arrow_boundary_reached", False))

        if not checked:
            return (1 if boundary else 0, 1, gap)
        return (0 if valid else 2, 0 if boundary else 1, 0)


@dataclass
class RollingValidityPruner:
    """
    Require each branch to become valid again within a fixed offset window.

    The default window ``(2, 3)`` means: after a valid anchor, a branch may pass
    through one unstable step, and must recover to a valid SMILES at step +2 or
    step +3. If it is still invalid at step +3, or only becomes valid later,
    the branch is pruned.

    Notes
    -----
    This class is retained for backward compatibility. New code should prefer
    :class:`FixedArrowValidityGate`.
    """

    valid_offsets: Tuple[int, int] = (2, 3)
    prefer_valid_when_window_open: bool = True
    cache_smiles: bool = False
    min_valid_span: Optional[int] = None
    max_valid_span: Optional[int] = None

    def __post_init__(self) -> None:
        if self.min_valid_span is not None or self.max_valid_span is not None:
            lo = 2 if self.min_valid_span is None else int(self.min_valid_span)
            hi = 3 if self.max_valid_span is None else int(self.max_valid_span)
            lo = max(1, lo)
            hi = max(lo, hi)
            self.valid_offsets = (lo, hi)
        else:
            lo, hi = self.valid_offsets
            lo = max(1, int(lo))
            hi = max(lo, int(hi))
            self.valid_offsets = (lo, hi)

    def initialize_root(self, state: StateSnapshot) -> None:
        state.memory.setdefault("last_valid_depth", 0)
        state.memory.setdefault("first_window_pending", True)
        state.memory.setdefault("validity_checked", False)
        state.memory.setdefault("last_graph_valid", True)
        state.memory.setdefault("validity_gap", 0)
        state.memory.setdefault("valid_window", self.valid_offsets)
        state.memory.setdefault("validity_history", [True])
        state.memory.setdefault("smiles_history", [None])

    def _state_smiles(
        self,
        state: StateSnapshot,
        *,
        oracle: GraphValidityOracle,
        validity_cache: Dict[Tuple, Tuple[bool, Optional[str]]],
    ) -> Optional[str]:
        key = oracle.cache_key(state.graph)
        if key not in validity_cache:
            smi = oracle.smiles(state.graph)
            validity_cache[key] = (smi is not None, smi)
        return validity_cache[key][1]

    def evaluate_next_state(
        self,
        current: StateSnapshot,
        next_state: StateSnapshot,
        next_depth: int,
        *,
        oracle: GraphValidityOracle,
        codec,
        validity_cache: Dict[Tuple, Tuple[bool, Optional[str]]],
    ) -> bool:
        smi = self._state_smiles(next_state, oracle=oracle, validity_cache=validity_cache)
        valid = smi is not None

        prev_hist = list(current.memory.get("validity_history", [True]))
        prev_smis = list(current.memory.get("smiles_history", [None]))
        hist = prev_hist + [valid]
        smis = prev_smis + [smi]

        next_state.memory["state_smiles"] = smi
        next_state.memory["validity_history"] = hist
        next_state.memory["smiles_history"] = smis
        next_state.memory["last_graph_valid"] = bool(valid)
        next_state.memory["valid_window"] = self.valid_offsets

        lo, hi = self.valid_offsets
        anchor = int(current.memory.get("last_valid_depth", 0))
        first_window_pending = bool(current.memory.get("first_window_pending", True))
        if first_window_pending:
            anchor = 0

        gap = int(next_depth) - anchor
        next_state.memory["validity_gap"] = int(gap)
        next_state.memory["validity_checked"] = gap >= lo
        next_state.memory["last_valid_depth"] = int(anchor)
        next_state.memory["first_window_pending"] = bool(first_window_pending)

        if gap > hi:
            return False

        if gap < lo:
            if self.cache_smiles and valid and smi is not None:
                next_state.memory["smiles"] = smi
            return True

        if valid:
            next_state.memory["last_valid_depth"] = int(next_depth)
            next_state.memory["validity_gap"] = 0
            next_state.memory["first_window_pending"] = False
            if self.cache_smiles and smi is not None:
                next_state.memory["smiles"] = smi
            return True

        if gap >= hi:
            return False

        return True

    def rank_next_state(self, next_state: StateSnapshot) -> Tuple[int, int, int]:
        checked = bool(next_state.memory.get("validity_checked", False))
        valid = bool(next_state.memory.get("last_graph_valid", False))
        gap = int(next_state.memory.get("validity_gap", 0))

        if not checked:
            return (1, gap, 0)
        if self.prefer_valid_when_window_open:
            return (0 if valid else 2, gap, 0)
        return (1, gap, 0)
