from __future__ import annotations

from typing import Iterable, List, Optional

from ..core.models import StateSnapshot, Transition
from .operators import BaseOperator
from .operators import (
    BondToBondOperator,
    BondToLPOperator,
    HomolyticBondCleavageOperator,
    HydrogenAtomTransferOperator,
    HydrogenToBondOperator,
    LPToBondOperator,
    RadicalAdditionOperator,
    RadicalCouplingOperator,
)


class OperatorVocabulary:
    """
    Registry of pluggable operator templates.
    """

    def __init__(self, operators: Optional[Iterable[BaseOperator]] = None) -> None:
        self._operators: List[BaseOperator] = []
        self._by_kind = {}

        if operators is not None:
            for operator in operators:
                self.register(operator)

    def register(self, operator: BaseOperator) -> None:
        """Register one operator instance."""
        if operator.kind in self._by_kind:
            raise ValueError(f"Duplicate operator kind: {operator.kind}")
        self._operators.append(operator)
        self._by_kind[operator.kind] = operator

    @property
    def operators(self) -> List[BaseOperator]:
        """Return registered operators."""
        return list(self._operators)

    def propose(
        self,
        state: StateSnapshot,
        goal: StateSnapshot,
    ) -> List[Transition]:
        """Collect and deduplicate candidates from all operators."""
        out: List[Transition] = []
        seen = set()

        for operator in self._operators:
            for transition in operator.propose(state, goal):
                key = transition.dedup_key()
                if key in seen:
                    continue
                seen.add(key)
                out.append(transition)

        return out

    def apply(
        self,
        state: StateSnapshot,
        transition: Transition,
    ):
        """Dispatch application to the operator matching ``transition.kind``."""
        operator = self._by_kind.get(transition.kind)
        if operator is None:
            raise KeyError(f"No operator registered for kind: {transition.kind}")
        return operator.apply(state, transition)


def default_vocabulary() -> OperatorVocabulary:
    """Return the default explicit-bond unit-arrow vocabulary.

    Hydrogen is handled as an ordinary explicit atom when it is present in the
    graph.  The default grammar therefore avoids implicit ``*/H+`` and
    ``H-/*`` bookkeeping actions; explicit C--H, O--H, and H--H changes are
    represented by the same ``LP-/B+``, ``B-/LP+``, and ``B-/B+`` operators as
    all other bond changes.
    """
    return OperatorVocabulary(
        operators=[
            LPToBondOperator(),
            BondToLPOperator(),
            BondToBondOperator(),
        ]
    )


def pericyclic_vocabulary() -> OperatorVocabulary:
    """Return the B-/B+ only vocabulary for concerted bond-flow reactions.

    Suitable for Diels-Alder, sigmatropic, electrocyclic, and other
    pericyclic reactions where all electron flow is bond-to-bond and no
    lone-pair or charge changes occur.  The enumerator auto-selects this
    mode via ``_infer_bond_only_mode`` when the reaction center contains
    only bond-order changes with no LP or charge deltas.
    """
    return OperatorVocabulary(operators=[BondToBondOperator()])


def radical_vocabulary() -> OperatorVocabulary:
    """Return all ionic operators plus the four radical single-electron operators.

    Radical operators are gated by the ``allow_radical_ops`` graph flag
    (default ``True``).  ``HydrogenAtomTransferOperator`` is additionally
    gated by ``allow_h_ops``.

    Radical operator kinds added
    ----------------------------
    ``B-/2R•``       HomolyticBondCleavageOperator    — initiation / homolysis
    ``2R•-/B+``      RadicalCouplingOperator          — termination / recombination
    ``R•/B-/B+``     RadicalAdditionOperator          — chain propagation
    ``R•-/H-/R•+``   HydrogenAtomTransferOperator     — HAT / H-abstraction
    """
    return OperatorVocabulary(
        operators=[
            LPToBondOperator(),
            BondToLPOperator(),
            BondToBondOperator(),
            HydrogenToBondOperator(),
            HomolyticBondCleavageOperator(),
            RadicalCouplingOperator(),
            RadicalAdditionOperator(),
            HydrogenAtomTransferOperator(),
        ]
    )
