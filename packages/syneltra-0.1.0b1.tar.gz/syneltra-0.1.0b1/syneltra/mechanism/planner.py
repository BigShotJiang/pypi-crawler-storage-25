from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from typing import Iterable, List, Optional, Sequence, Set, Tuple

import networkx as nx

from ..chemistry.graph import atom_element, edge_order, possible_edge_keys
from ..core.models import Transition
from ..core.plan_utils import (
    compatible_encoded_plans,
    flatten_encoded_plan,
    history_transition_keys,
    next_compatible_encoded_plans,
    plan_boundary_after_step,
    transition_key,
)


@dataclass(frozen=True)
class BondFlowStep:
    """One local bond-flow micro-step ``src_edge -> dst_edge`` sharing an anchor."""

    src_edge: Tuple[int, int]
    dst_edge: Tuple[int, int]
    anchor: int

    @property
    def frontier(self) -> Tuple[int, int]:
        src_atoms = set(self.src_edge)
        dst_atoms = set(self.dst_edge)
        touched = tuple(sorted((src_atoms | dst_atoms) - {int(self.anchor)}))
        if len(touched) == 2:
            return touched
        if len(touched) == 1:
            return (touched[0], touched[0])
        return (int(self.anchor), int(self.anchor))

    def as_key(self) -> Tuple[Tuple[int, int], Tuple[int, int]]:
        return (tuple(sorted(self.src_edge)), tuple(sorted(self.dst_edge)))

    def as_transition(self) -> Transition:
        return Transition(
            kind="B-/B+",
            src=tuple(sorted(self.src_edge)),
            dst=tuple(sorted(self.dst_edge)),
            data={"shared_atom": int(self.anchor), "proposal_origin": "its_plan"},
        )


@dataclass(frozen=True)
class BondFlowPlan:
    """A complete exact-cover bond-flow plan on the reactant-map graph."""

    steps: Tuple[BondFlowStep, ...]
    score: Tuple[int, ...] = field(default_factory=tuple)

    def as_transition_keys(self) -> Tuple[Tuple[Tuple[int, int], Tuple[int, int]], ...]:
        return tuple(step.as_key() for step in self.steps)


@dataclass(frozen=True)
class ArrowBundle:
    """One mechanistic arrow, realized as a contiguous block of micro-steps."""

    index: int
    micro_steps: Tuple[Transition, ...]
    family: str = "generic"

    def __len__(self) -> int:
        return len(self.micro_steps)

    def transition_keys(
        self,
    ) -> Tuple[Tuple[str, Tuple[int, ...], Tuple[int, ...]], ...]:
        return tuple(transition_key(step) for step in self.micro_steps)


@dataclass(frozen=True)
class ArrowPlan:
    """A high-level mechanism plan grouped into user-facing arrows."""

    arrows: Tuple[ArrowBundle, ...]
    family: str = "generic"
    score: Tuple[int, ...] = field(default_factory=tuple)
    metadata: Tuple[Tuple[str, object], ...] = field(default_factory=tuple)

    def __len__(self) -> int:
        return len(self.arrows)

    @property
    def micro_steps(self) -> Tuple[Transition, ...]:
        out: List[Transition] = []
        for bundle in self.arrows:
            out.extend(bundle.micro_steps)
        return tuple(out)

    def flatten_transition_keys(
        self,
    ) -> Tuple[Tuple[str, Tuple[int, ...], Tuple[int, ...]], ...]:
        return tuple(transition_key(step) for step in self.micro_steps)

    def transition_keys(
        self,
    ) -> Tuple[Tuple[Tuple[str, Tuple[int, ...], Tuple[int, ...]], ...], ...]:
        return tuple(bundle.transition_keys() for bundle in self.arrows)

    def boundary_depths(self) -> Tuple[int, ...]:
        total = 0
        out: List[int] = []
        for bundle in self.arrows:
            total += len(bundle)
            out.append(int(total))
        return tuple(out)


# ---------------------------------------------------------------------------
# Boundary-aware graph simulation helpers
# ---------------------------------------------------------------------------


def _copy_graph_exact(start: nx.Graph) -> nx.Graph:
    """Return an exact working copy preserving nodes, edges, and graph attrs."""
    g = nx.Graph()
    g.add_nodes_from((int(n), dict(attrs)) for n, attrs in start.nodes(data=True))
    for u, v, attrs in start.edges(data=True):
        g.add_edge(int(u), int(v), **dict(attrs))
    g.graph.update(dict(start.graph))
    return g


def _apply_bond_flow_transition_inplace(g: nx.Graph, transition: Transition) -> None:
    """Apply one ``B-/B+`` transition in place on a working graph copy."""
    from ..chemistry.graph import set_edge_order

    if str(transition.kind) != "B-/B+" or len(transition.src) != 2 or len(transition.dst) != 2:
        raise ValueError("Boundary simulation only supports B-/B+ transitions.")

    u1, v1 = int(transition.src[0]), int(transition.src[1])
    u2, v2 = int(transition.dst[0]), int(transition.dst[1])
    set_edge_order(g, u1, v1, edge_order(g, u1, v1) - 1.0)
    set_edge_order(g, u2, v2, edge_order(g, u2, v2) + 1.0)


def _graph_smiles_or_none(g: nx.Graph) -> Optional[str]:
    """Best-effort graph validity probe using the user's SynKit environment."""
    try:
        from synkit.IO import graph_to_smi as _graph_to_smi  # type: ignore
    except Exception:
        return None

    from ..chemistry.graph import materialize_full_graph

    try:
        full = materialize_full_graph(
            g,
            recompute_charge=not bool(g.graph.get("suppress_charge_recompute", False)),
        )
        smi = _graph_to_smi(full)
    except Exception:
        return None
    return smi if smi else None


def _boundary_validities(
    start: nx.Graph, transitions: Sequence[Transition], bundle_sizes: Sequence[int]
) -> Tuple[Optional[bool], ...]:
    """Return per-arrow boundary validity for a proposed bundle split."""
    g = _copy_graph_exact(start)

    checkpoints: List[int] = []
    total = 0
    for size in bundle_sizes:
        total += int(size)
        checkpoints.append(total)

    validities: List[Optional[bool]] = []
    cp_set = set(checkpoints)
    step_idx = 0
    for tr in transitions:
        step_idx += 1
        _apply_bond_flow_transition_inplace(g, tr)
        if step_idx in cp_set:
            smi = _graph_smiles_or_none(g)
            validities.append(None if smi is None else True)
    return tuple(validities)


def _compositions(total: int, parts: int) -> Iterable[Tuple[int, ...]]:
    """Yield ordered positive integer compositions of ``total`` into ``parts`` parts."""
    if total <= 0 or parts <= 0 or parts > total:
        return []
    if parts == 1:
        return [(int(total),)]

    out = []
    for cuts in itertools.combinations(range(1, total), parts - 1):
        prev = 0
        comp = []
        for c in cuts + (total,):
            comp.append(int(c - prev))
            prev = c
        out.append(tuple(comp))
    return out


# ---------------------------------------------------------------------------
# Signed bond-delta planner
# ---------------------------------------------------------------------------


def _edge_units(order_delta: float) -> int:
    return int(round(abs(float(order_delta))))


def _expand_edge_units(start: nx.Graph, goal: nx.Graph) -> Tuple[List[Tuple[int, int]], List[Tuple[int, int]]]:
    extra_edges: List[Tuple[int, int]] = []
    missing_edges: List[Tuple[int, int]] = []
    for u, v in possible_edge_keys(start):
        delta = float(edge_order(goal, u, v) - edge_order(start, u, v))
        key = tuple(sorted((int(u), int(v))))
        if delta > 0:
            missing_edges.extend([key] * _edge_units(delta))
        elif delta < 0:
            extra_edges.extend([key] * _edge_units(delta))
    return extra_edges, missing_edges


def _shared_anchor(src_edge: Tuple[int, int], dst_edge: Tuple[int, int]) -> Optional[int]:
    shared = set(src_edge) & set(dst_edge)
    if len(shared) != 1:
        return None
    return int(next(iter(shared)))


def _pair_candidates(
    extra_edges: Sequence[Tuple[int, int]],
    missing_edges: Sequence[Tuple[int, int]],
) -> List[BondFlowStep]:
    pairs: List[BondFlowStep] = []
    for src_edge in extra_edges:
        for dst_edge in missing_edges:
            anchor = _shared_anchor(src_edge, dst_edge)
            if anchor is None:
                continue
            pairs.append(BondFlowStep(src_edge=src_edge, dst_edge=dst_edge, anchor=anchor))
    return pairs


def _step_overlap(a: BondFlowStep, b: BondFlowStep) -> int:
    return len(set(a.frontier) & set(b.frontier))


def _step_touches(a: BondFlowStep, b: BondFlowStep) -> bool:
    atoms_a = set(a.src_edge) | set(a.dst_edge)
    atoms_b = set(b.src_edge) | set(b.dst_edge)
    return bool(atoms_a & atoms_b)


def _plan_score(steps: Sequence[BondFlowStep]) -> Tuple[int, ...]:
    if not steps:
        return (999, 999, 999)

    continuity_penalty = 0
    frontier_penalty = 0
    for prev, cur in zip(steps[:-1], steps[1:]):
        if not _step_touches(prev, cur):
            continuity_penalty += 1
        if _step_overlap(prev, cur) == 0:
            frontier_penalty += 1

    hetero_penalty = 0
    for step in steps:
        if set(step.src_edge) == set(step.dst_edge):
            hetero_penalty += 1

    return (continuity_penalty, frontier_penalty, hetero_penalty, len(steps))


class ITSWalkPlanner:
    """
    Plan alternating ``B-/B+`` walks directly on reactant-map bond deltas.

    The planner treats the ITS/goal delta only as a signed anchor and returns
    small sets of exact-cover bond-flow plans. Each plan is a sequence of
    consecutive ``src_edge -> dst_edge`` replacements that collectively consume
    all signed bond changes.
    """

    def __init__(self, *, max_plans: int = 64) -> None:
        self.max_plans = int(max_plans)

    @staticmethod
    def _valid_delta_counts(
        extra_edges: Sequence[Tuple[int, int]],
        missing_edges: Sequence[Tuple[int, int]],
    ) -> bool:
        return bool(extra_edges) and bool(missing_edges) and (len(extra_edges) == len(missing_edges))

    @staticmethod
    def _dedup_edges(
        edges: Sequence[Tuple[int, int]],
    ) -> List[Tuple[int, int]]:
        return list(dict.fromkeys(edges))

    def _candidate_steps(
        self,
        remaining_extra: Sequence[Tuple[int, int]],
        remaining_missing: Sequence[Tuple[int, int]],
    ) -> List[BondFlowStep]:
        candidate_steps: List[BondFlowStep] = []
        for src_edge in self._dedup_edges(remaining_extra):
            for dst_edge in self._dedup_edges(remaining_missing):
                anchor = _shared_anchor(src_edge, dst_edge)
                if anchor is None:
                    continue
                candidate_steps.append(
                    BondFlowStep(
                        src_edge=src_edge,
                        dst_edge=dst_edge,
                        anchor=anchor,
                    )
                )
        return candidate_steps

    @staticmethod
    def _rank_step(
        step: BondFlowStep,
        *,
        partial: Sequence[BondFlowStep],
        frontier_atoms: Set[int],
    ) -> Tuple[int, int, int, Tuple[int, int], Tuple[int, int]]:
        step_atoms = set(step.src_edge) | set(step.dst_edge)
        touch_frontier = 0 if (frontier_atoms and step_atoms & frontier_atoms) else 1
        overlap = 0 if (partial and _step_overlap(partial[-1], step) > 0) else 1
        anchor_bias = abs(step.src_edge[0] - step.anchor) + abs(step.src_edge[1] - step.anchor)
        return (
            touch_frontier,
            overlap,
            anchor_bias,
            step.src_edge,
            step.dst_edge,
        )

    def _finish_plan(
        self,
        partial: Sequence[BondFlowStep],
        *,
        plans: List[BondFlowPlan],
        seen: Set[Tuple[Tuple[Tuple[int, int], Tuple[int, int]], ...]],
    ) -> None:
        key = tuple(step.as_key() for step in partial)
        if key in seen:
            return
        seen.add(key)
        plans.append(BondFlowPlan(steps=tuple(partial), score=_plan_score(partial)))

    def _dfs_plans(
        self,
        remaining_extra: List[Tuple[int, int]],
        remaining_missing: List[Tuple[int, int]],
        partial: List[BondFlowStep],
        *,
        plans: List[BondFlowPlan],
        seen: Set[Tuple[Tuple[Tuple[int, int], Tuple[int, int]], ...]],
    ) -> None:
        if len(plans) >= self.max_plans:
            return

        if not remaining_extra and not remaining_missing:
            self._finish_plan(partial, plans=plans, seen=seen)
            return

        frontier_atoms: Set[int] = set(partial[-1].frontier) if partial else set()
        candidate_steps = self._candidate_steps(remaining_extra, remaining_missing)
        candidate_steps.sort(
            key=lambda step: self._rank_step(
                step,
                partial=partial,
                frontier_atoms=frontier_atoms,
            )
        )

        for step in candidate_steps:
            try:
                src_idx = remaining_extra.index(step.src_edge)
                dst_idx = remaining_missing.index(step.dst_edge)
            except ValueError:
                continue

            next_extra = list(remaining_extra)
            next_missing = list(remaining_missing)
            next_extra.pop(src_idx)
            next_missing.pop(dst_idx)

            partial.append(step)
            self._dfs_plans(
                next_extra,
                next_missing,
                partial,
                plans=plans,
                seen=seen,
            )
            partial.pop()

    def plan(self, start: nx.Graph, goal: nx.Graph) -> List[BondFlowPlan]:
        extra_edges, missing_edges = _expand_edge_units(start, goal)
        if not self._valid_delta_counts(extra_edges, missing_edges):
            return []

        if not _pair_candidates(extra_edges, missing_edges):
            return []

        plans: List[BondFlowPlan] = []
        seen: Set[Tuple[Tuple[Tuple[int, int], Tuple[int, int]], ...]] = set()

        self._dfs_plans(
            list(extra_edges),
            list(missing_edges),
            [],
            plans=plans,
            seen=seen,
        )

        plans.sort(key=lambda plan: plan.score)
        return plans[: self.max_plans]


# ---------------------------------------------------------------------------
# High-level ITS planner: classify and bundle micro-steps into arrows
# ---------------------------------------------------------------------------


class ITSPlanner:
    """
    Build high-level arrow plans from ITS/goal deltas.

    The planner keeps the search state on the reactant graph but derives a
    bundle-aware macro plan from the signed ITS bond changes. For now, bond-only
    mechanisms are planned exactly; mixed bond/H/LP mechanisms fall back to the
    older local search when no reliable arrow plan is available.
    """

    def __init__(self, *, max_plans: int = 64) -> None:
        self.max_plans = int(max_plans)
        self.walk_planner = ITSWalkPlanner(max_plans=max_plans)

    def classify(self, start: nx.Graph, goal: nx.Graph) -> str:
        workspace_nodes = [
            int(n) for n in start.graph.get("workspace_nodes", start.nodes()) if n in start and n in goal
        ]
        if not workspace_nodes:
            return "generic"

        changed_bond = any(
            abs(edge_order(start, u, v) - edge_order(goal, u, v)) > 1e-8 for u, v in possible_edge_keys(start)
        )
        if not changed_bond:
            return "generic"

        lp_or_charge_delta = False
        h_delta_nodes: List[int] = []
        for n in workspace_nodes:
            if int(start.nodes[n].get("lone_pairs", 0)) != int(goal.nodes[n].get("lone_pairs", 0)):
                lp_or_charge_delta = True
                break
            if int(start.nodes[n].get("charge", 0)) != int(goal.nodes[n].get("charge", 0)):
                lp_or_charge_delta = True
                break
            if int(start.nodes[n].get("hcount", 0)) != int(goal.nodes[n].get("hcount", 0)):
                h_delta_nodes.append(int(n))

        if lp_or_charge_delta:
            return "mixed"

        for n in h_delta_nodes:
            element = atom_element(start if n in start else goal, n)
            if element not in {"C"}:
                return "mixed"

        return "bond_only"

    def _bundle_transitions(
        self,
        transitions: Sequence[Transition],
        *,
        bundle_sizes: Sequence[int],
        family: str,
    ) -> Tuple[ArrowBundle, ...]:
        bundles: List[ArrowBundle] = []
        offset = 0
        for i, size in enumerate(bundle_sizes):
            end = offset + int(size)
            chunk = tuple(transitions[offset:end])
            if chunk:
                bundles.append(ArrowBundle(index=i, micro_steps=chunk, family=family))
            offset = end
        return tuple(bundles)

    def _candidate_bundle_sizes(
        self,
        n_steps: int,
        arrows: Optional[int],
        bundle_spans: Optional[Sequence[int]] = None,
    ) -> List[Tuple[int, ...]]:
        if n_steps <= 0:
            return []

        if bundle_spans is not None:
            spans = tuple(int(x) for x in bundle_spans)
            if spans and sum(spans) == int(n_steps) and all(int(x) > 0 for x in spans):
                return [spans]
            return []

        if arrows is None:
            return [tuple(1 for _ in range(n_steps))]

        n_arrows = max(1, min(int(arrows), n_steps))
        if n_arrows == 2 and int(n_steps) == 4:
            return [(2, 2)]

        if n_arrows == 2 and int(n_steps) == 2:
            return [(1, 1), (2,)]

        comps = list(_compositions(n_steps, n_arrows))
        if not comps:
            return [tuple(1 for _ in range(n_steps))]
        return comps

    def _bundle_score(
        self,
        start: nx.Graph,
        transitions: Sequence[Transition],
        bundle_sizes: Sequence[int],
    ) -> Tuple[int, int, Tuple[int, ...]]:
        validities = _boundary_validities(start, transitions, bundle_sizes)
        invalid = sum(1 for v in validities if v is None or v is False)
        return (
            invalid,
            max(bundle_sizes) if bundle_sizes else 0,
            tuple(int(x) for x in bundle_sizes),
        )

    def _plan_bond_only(
        self,
        start: nx.Graph,
        goal: nx.Graph,
        *,
        arrows: Optional[int],
        bundle_spans: Optional[Sequence[int]] = None,
    ) -> List[ArrowPlan]:
        walk_plans = self.walk_planner.plan(start, goal)
        if not walk_plans:
            return []

        candidates: List[Tuple[Tuple[int, int, Tuple[int, ...]], ArrowPlan]] = []
        for walk in walk_plans:
            transitions = tuple(step.as_transition() for step in walk.steps)
            for bundle_sizes in self._candidate_bundle_sizes(len(transitions), arrows, bundle_spans=bundle_spans):
                bundles = self._bundle_transitions(transitions, bundle_sizes=bundle_sizes, family="bond_only")
                if not bundles:
                    continue

                bundle_score = self._bundle_score(start, transitions, bundle_sizes)
                meta = (
                    ("micro_steps", len(transitions)),
                    ("requested_arrows", arrows),
                    (
                        "requested_bundle_spans",
                        (None if bundle_spans is None else tuple(int(x) for x in bundle_spans)),
                    ),
                    ("bundle_sizes", tuple(int(x) for x in bundle_sizes)),
                    ("walk_score", walk.score),
                    ("bundle_score", bundle_score),
                )
                plan = ArrowPlan(
                    arrows=bundles,
                    family="bond_only",
                    score=tuple(walk.score) + tuple(bundle_score),
                    metadata=meta,
                )
                candidates.append((bundle_score, plan))

        if not candidates:
            return []

        best_bundle = min(score for score, _ in candidates)
        filtered = [plan for score, plan in candidates if score == best_bundle]
        filtered.sort(key=lambda plan: plan.score)
        return filtered[: self.max_plans]

    def plan(
        self,
        start: nx.Graph,
        goal: nx.Graph,
        *,
        arrows: Optional[int] = None,
        bundle_spans: Optional[Sequence[int]] = None,
    ) -> List[ArrowPlan]:
        family = self.classify(start, goal)
        if family == "mixed":
            return []
        return self._plan_bond_only(start, goal, arrows=arrows, bundle_spans=bundle_spans)


__all__ = [
    "ArrowBundle",
    "ArrowPlan",
    "BondFlowPlan",
    "BondFlowStep",
    "ITSPlanner",
    "ITSWalkPlanner",
    "compatible_encoded_plans",
    "flatten_encoded_plan",
    "history_transition_keys",
    "next_compatible_encoded_plans",
    "plan_boundary_after_step",
    "transition_key",
]
