from __future__ import annotations

import copy
from abc import ABC, abstractmethod
from typing import Iterable, Optional, Set

from ..chemistry.delta import GoalDelta
from ..chemistry.graph import (
    atom_element,
    decrement_edge_order_for_arrow,
    edge_order,
    get_charge,
    get_h,
    get_lp,
    get_radical,
    increment_edge_order_for_arrow,
    set_edge_order,
    set_h,
    set_lp,
    set_radical,
    validate_nonnegative_state,
)
from ..core.models import StateSnapshot, Transition


class BaseOperator(ABC):
    """
    Base class for pluggable mechanism operators.
    """

    kind: str

    @abstractmethod
    def propose(
        self,
        state: StateSnapshot,
        goal: StateSnapshot,
    ) -> Iterable[Transition]:
        """Yield candidate transitions from ``state`` toward ``goal``."""
        raise NotImplementedError

    @abstractmethod
    def apply(
        self,
        state: StateSnapshot,
        transition: Transition,
    ) -> Optional[StateSnapshot]:
        """Apply one candidate transition to ``state``."""
        raise NotImplementedError


def _workspace_nodes(graph) -> list[int]:
    """Return search-active nodes only; non-workspace atoms are fixed context."""
    nodes = graph.graph.get("workspace_nodes")
    if nodes:
        return [int(n) for n in sorted(nodes) if int(n) in graph]
    return [int(n) for n in graph.nodes()]


def _has_lp_source(graph, atom: int) -> bool:
    """Return True when ``atom`` can serve as an LP- electron-pair source.

    SynEltra uses the abstract ``LP-/B+`` action for all atom-centered
    nucleophilic bond formation. Therefore, a formal anion must be considered
    an LP source even when upstream graph annotation did not materialize the
    electron pair in the ``lone_pairs`` field.
    """
    atom = int(atom)
    if atom not in graph:
        return False
    return get_lp(graph, atom) > 0 or get_charge(graph, atom) < 0


def _consume_lp_source(graph, atom: int) -> None:
    """Consume one explicit LP if present.

    If no explicit LP exists, charge recomputation accounts for the anionic
    electron pair after the new bond is formed.
    """
    atom = int(atom)
    lp = get_lp(graph, atom)
    if lp > 0:
        set_lp(graph, atom, lp - 1)


def _allow_radical(graph) -> bool:
    """Return True when radical single-electron operators are enabled for this graph."""
    return bool(graph.graph.get("allow_radical_ops", True))


def _transition_payload(
    kind: str,
    src,
    dst,
    *,
    proposal_origin: str = "goal",
    shared_atom=None,
    **extra_data,
) -> Transition:
    data = {"proposal_origin": proposal_origin}

    if shared_atom is not None:
        data["shared_atom"] = int(shared_atom)

    data.update(extra_data)
    return Transition(kind, src=tuple(src), dst=tuple(dst), data=data)


def _goal_transition(
    kind: str,
    src,
    dst,
    *,
    shared_atom=None,
    **extra_data,
) -> Transition:
    return _transition_payload(
        kind,
        src,
        dst,
        proposal_origin="goal",
        shared_atom=shared_atom,
        **extra_data,
    )


def _adjacent_rc_transition(
    kind: str,
    src,
    dst,
    *,
    shared_atom=None,
    **extra_data,
) -> Transition:
    return _transition_payload(
        kind,
        src,
        dst,
        proposal_origin="adjacent_rc",
        shared_atom=shared_atom,
        **extra_data,
    )


def _kekule_bond_sum(graph, atom: int) -> float:
    """Sum kekule_order for all bonds incident to atom."""
    total = 0.0
    for _, _, data in graph.edges(int(atom), data=True):
        total += float(data.get("kekule_order", data.get("order", 1.0)))
    return total


def _recompute_charges_from_state_delta(
    new_graph,
    old_graph,
    affected_atoms: Set[int],
    lp_charge_deltas=None,
) -> None:
    """Update formal charges by comparing kekule bond sum, hcount, and radical changes.

    Auto formula:  ΔFC = -(ΔH + Δkekule_bond_sum + Δradical)
    LP term added: ΔFC += -(2 * ΔLP)  only for atoms in lp_charge_deltas.

    LP is NOT auto-detected from state differences because bookkeeping LP
    assignments (e.g. sink_goal_lp) must not trigger charge changes.
    """
    lp_deltas = lp_charge_deltas or {}
    for atom in affected_atoms:
        atom = int(atom)
        if atom not in new_graph:
            continue
        new_data = new_graph.nodes[atom]
        if "charge" not in new_data:
            continue
        old_data = old_graph.nodes.get(atom, {})

        d_lp = lp_deltas.get(atom, 0)
        d_h = int(new_data.get("hcount", 0)) - int(old_data.get("hcount", 0))
        d_kekule = _kekule_bond_sum(new_graph, atom) - _kekule_bond_sum(old_graph, atom)
        d_radical = int(new_data.get("radical_electrons", 0)) - int(old_data.get("radical_electrons", 0))

        # Expanded-valence atoms (sulfone S, pentavalent P) that started with
        # bond_sum > 4 use unconventional LP conventions in synkit; the ΔFC
        # formula gives wrong results for them. Guard with expanded_valence_atoms
        # (set at search init in enumerate_from_its) so transient pentacoordinate
        # intermediates (e.g. SNi S reaching bond_sum=5 temporarily) are NOT
        # skipped — only truly expanded-valence atoms are exempt.
        ev_atoms = old_graph.graph.get("expanded_valence_atoms", frozenset())
        old_ks = _kekule_bond_sum(old_graph, atom)
        elem = str(new_data.get("element", "")).upper()
        if elem in ("S", "P") and old_ks > 4 and int(atom) in ev_atoms:
            continue

        charge_delta = -(2 * d_lp + d_h + int(round(d_kekule)) + d_radical)
        if charge_delta:
            new_data["charge"] = int(new_data["charge"]) + charge_delta


def _finalize_state(
    graph,
    old_graph,
    memory,
    affected_atoms: Set[int],
    *,
    lp_charge_deltas=None,
) -> Optional[StateSnapshot]:
    if not bool(graph.graph.get("suppress_charge_recompute", False)):
        _recompute_charges_from_state_delta(graph, old_graph, affected_atoms, lp_charge_deltas)

    out = StateSnapshot(graph=graph, memory=copy.deepcopy(memory))
    return out if validate_nonnegative_state(out) else None


class LPToBondOperator(BaseOperator):
    kind = "LP-/B+"

    def propose(
        self,
        state: StateSnapshot,
        goal: StateSnapshot,
    ) -> Iterable[Transition]:
        delta = GoalDelta(state.graph, goal.graph)

        for a in _workspace_nodes(state.graph):
            if not _has_lp_source(state.graph, a):
                continue

            for cand in delta.missing_bond_candidates():
                u, v = cand.edge
                if a == u or a == v:
                    payload = dict(cand.payload())
                    sink = v if a == u else u
                    if sink in goal.graph:
                        payload["sink_goal_lp"] = get_lp(goal.graph, sink)
                    yield _transition_payload(
                        self.kind,
                        (a,),
                        (u, v),
                        shared_atom=a,
                        **payload,
                    )

    def apply(
        self,
        state: StateSnapshot,
        transition: Transition,
    ) -> Optional[StateSnapshot]:
        g = copy.deepcopy(state.graph)

        a = int(transition.src[0])
        u, v = int(transition.dst[0]), int(transition.dst[1])

        if not _has_lp_source(g, a):
            return None

        old_lp_a = get_lp(state.graph, a)
        _consume_lp_source(g, a)
        # Track actual LP consumed (-1 if LP was explicit, 0 if anion path).
        lp_delta_a = get_lp(g, a) - old_lp_a

        retargeted = increment_edge_order_for_arrow(g, u, v)
        if (
            not retargeted
            and transition.data.get("context_role") == "carbonyl_target"
            and bool(g.nodes[a].get("_placeholder_repaired", False))
            and edge_order(g, u, v) < 1.5
        ):
            # Product-only water oxygen can be mapped as a hidden reagent.  In
            # Hofmann-style probes, its LP attack is the carbonyl-forming arrow
            # for C=O, so one abstract transition must reach the product double
            # bond rather than stopping at an unrecoverable single C-O bond.
            retargeted = increment_edge_order_for_arrow(g, u, v)

        lp_cd = {a: lp_delta_a} if lp_delta_a else None

        sink = v if a == u else u if a == v else None
        if (
            not retargeted
            and sink is not None
            and atom_element(g, sink) in {"N", "P"}
            and get_charge(g, sink) > 0
            and get_lp(g, sink) < int(transition.data.get("sink_goal_lp", 0) or 0)
        ):
            # Bookkeeping LP on sink — does NOT affect charge.
            set_lp(g, sink, get_lp(g, sink) + 1)
        # Kekulé retargeting shifts kekule_order for ring atoms without real
        # electron flow — exclude retargeted-only atoms from charge recomputation
        # to avoid phantom ΔFC from Kekulé reassignment.
        return _finalize_state(g, state.graph, state.memory, {a, u, v}, lp_charge_deltas=lp_cd)


class BondToLPOperator(BaseOperator):
    kind = "B-/LP+"

    def propose(
        self,
        state: StateSnapshot,
        goal: StateSnapshot,
    ) -> Iterable[Transition]:
        delta = GoalDelta(state.graph, goal.graph)

        for u, v in delta.extra_bond_edges():
            yield _goal_transition(self.kind, (u, v), (u,), shared_atom=u)
            yield _goal_transition(self.kind, (u, v), (v,), shared_atom=v)

        for cand in delta.context_source_bond_candidates():
            u, v = cand.edge
            payload = dict(cand.payload())

            yield _transition_payload(
                self.kind,
                (u, v),
                (u,),
                shared_atom=u,
                **payload,
            )
            yield _transition_payload(
                self.kind,
                (u, v),
                (v,),
                shared_atom=v,
                **payload,
            )

    def apply(
        self,
        state: StateSnapshot,
        transition: Transition,
    ) -> Optional[StateSnapshot]:
        g = copy.deepcopy(state.graph)

        u, v = int(transition.src[0]), int(transition.src[1])
        x = int(transition.dst[0])

        if edge_order(g, u, v) <= 0:
            return None

        decrement_edge_order_for_arrow(g, u, v)
        set_lp(g, x, get_lp(g, x) + 1)
        # x gains 1 explicit LP — contribute +1 ΔLP to charge formula.
        lp_cd = {x: 1}

        # Kekulé retargeting shifts kekule_order for ring atoms without real
        # electron flow — exclude retargeted-only atoms from charge recomputation.
        return _finalize_state(g, state.graph, state.memory, {u, v, x}, lp_charge_deltas=lp_cd)


class HydrogenToBondOperator(BaseOperator):
    kind = "H-/B+"

    def propose(
        self,
        state: StateSnapshot,
        goal: StateSnapshot,
    ) -> Iterable[Transition]:
        if not bool(state.graph.graph.get("allow_h_ops", True)):
            return

        delta = GoalDelta(state.graph, goal.graph)
        missing_bonds = delta.missing_bond_candidates()

        for a in delta.nodes_with_extra_h():
            for cand in missing_bonds:
                u, v = cand.edge
                if a == u or a == v:
                    payload = dict(cand.payload())
                    yield _transition_payload(
                        self.kind,
                        (a,),
                        (u, v),
                        shared_atom=a,
                        **payload,
                    )

    def apply(
        self,
        state: StateSnapshot,
        transition: Transition,
    ) -> Optional[StateSnapshot]:
        g = copy.deepcopy(state.graph)

        a = int(transition.src[0])
        u, v = int(transition.dst[0]), int(transition.dst[1])

        if get_h(g, a) <= 0:
            return None

        set_h(g, a, get_h(g, a) - 1)
        set_edge_order(g, u, v, edge_order(g, u, v) + 1.0)

        return _finalize_state(g, state.graph, state.memory, {a, u, v})


class BondToBondOperator(BaseOperator):
    kind = "B-/B+"

    def propose(
        self,
        state: StateSnapshot,
        goal: StateSnapshot,
    ) -> Iterable[Transition]:
        delta = GoalDelta(state.graph, goal.graph)
        pairs = delta.bond_flow_pairs(
            include_context_sources=True,
            require_shared_atom=True,
        )

        src_partner_count = {}
        dst_partner_count = {}

        for item in pairs:
            src_edge, dst_edge = item[0], item[1]
            src_partner_count[src_edge] = src_partner_count.get(src_edge, 0) + 1
            dst_partner_count[dst_edge] = dst_partner_count.get(dst_edge, 0) + 1

        for item in pairs:
            if len(item) == 4:
                src_edge, dst_edge, anchor, origin = item
                extra = {}
            else:
                src_edge, dst_edge, anchor, origin, extra = item

            payload = {
                "src_partner_count": int(src_partner_count.get(src_edge, 0)),
                "dst_partner_count": int(dst_partner_count.get(dst_edge, 0)),
            }
            payload.update(dict(extra or {}))

            origin = str(payload.pop("proposal_origin", origin))
            anchor = payload.pop("shared_atom", anchor)

            yield _transition_payload(
                self.kind,
                src_edge,
                dst_edge,
                proposal_origin=origin,
                shared_atom=anchor,
                **payload,
            )

    def apply(
        self,
        state: StateSnapshot,
        transition: Transition,
    ) -> Optional[StateSnapshot]:
        g = copy.deepcopy(state.graph)

        u1, v1 = int(transition.src[0]), int(transition.src[1])
        u2, v2 = int(transition.dst[0]), int(transition.dst[1])

        if edge_order(g, u1, v1) <= 0:
            return None

        retargeted = decrement_edge_order_for_arrow(g, u1, v1)
        retargeted |= increment_edge_order_for_arrow(g, u2, v2)
        water_proton_transfer_source = None
        water_proton_transfer_acceptor = None
        shared = {u1, v1} & {u2, v2}
        if len(shared) == 1:
            h_atom = next(iter(shared))
            donor = v1 if u1 == h_atom else u1
            acceptor = v2 if u2 == h_atom else u2
            if (
                str(g.nodes[donor].get("element", "")).upper() == "O"
                and bool(g.nodes[donor].get("_placeholder_repaired", False))
                and str(g.nodes[acceptor].get("element", "")).upper() in {"F", "CL", "BR", "I"}
            ):
                water_proton_transfer_source = int(donor)
                water_proton_transfer_acceptor = int(acceptor)

        lp_cd = {}
        if water_proton_transfer_source is not None and get_lp(g, water_proton_transfer_source) < 2:
            set_lp(
                g,
                water_proton_transfer_source,
                get_lp(g, water_proton_transfer_source) + 1,
            )
            lp_cd[water_proton_transfer_source] = 1
        if water_proton_transfer_acceptor is not None and get_lp(g, water_proton_transfer_acceptor) > 3:
            set_lp(
                g,
                water_proton_transfer_acceptor,
                get_lp(g, water_proton_transfer_acceptor) - 1,
            )
            lp_cd[water_proton_transfer_acceptor] = -1
        # Kekulé retargeting shifts kekule_order for ring atoms without real
        # electron flow — exclude retargeted-only atoms from charge recomputation.
        return _finalize_state(
            g,
            state.graph,
            state.memory,
            {u1, v1, u2, v2},
            lp_charge_deltas=lp_cd or None,
        )


# ---------------------------------------------------------------------------
# Radical (single-electron) operators
# ---------------------------------------------------------------------------


class HomolyticBondCleavageOperator(BaseOperator):
    """Bond breaks homolytically — each fragment gains one unpaired electron.

    Covers initiation steps (Cl–Cl → 2 Cl•) and β-scission (one side already
    carries a radical, net result is a new radical + higher-order bond on the
    other fragment when combined with RadicalAdditionOperator).
    """

    kind = "B-/2R•"

    def propose(
        self,
        state: StateSnapshot,
        goal: StateSnapshot,
    ) -> Iterable[Transition]:
        if not _allow_radical(state.graph):
            return

        delta = GoalDelta(state.graph, goal.graph)
        needing = set(delta.nodes_needing_radical())

        for u, v in delta.extra_bond_edges():
            if u in needing and v in needing:
                yield _goal_transition(
                    self.kind,
                    (u, v),
                    (u, v),
                    shared_atom=u,
                )

    def apply(
        self,
        state: StateSnapshot,
        transition: Transition,
    ) -> Optional[StateSnapshot]:
        g = copy.deepcopy(state.graph)

        u, v = int(transition.src[0]), int(transition.src[1])

        if edge_order(g, u, v) <= 0:
            return None

        retargeted = decrement_edge_order_for_arrow(g, u, v)
        set_radical(g, u, get_radical(g, u) + 1)
        set_radical(g, v, get_radical(g, v) + 1)

        return _finalize_state(g, state.graph, state.memory, {u, v} | retargeted)


class RadicalCouplingOperator(BaseOperator):
    """Two radical centres combine to form a new bond.

    This is the termination step in radical chain reactions (e.g. 2 CH₃• →
    C₂H₆) and also models radical cross-coupling.
    """

    kind = "2R•-/B+"

    def propose(
        self,
        state: StateSnapshot,
        goal: StateSnapshot,
    ) -> Iterable[Transition]:
        if not _allow_radical(state.graph):
            return

        delta = GoalDelta(state.graph, goal.graph)

        for cand in delta.missing_bond_candidates():
            u, v = cand.edge
            if get_radical(state.graph, u) > 0 and get_radical(state.graph, v) > 0:
                payload = dict(cand.payload())
                yield _transition_payload(
                    self.kind,
                    (u, v),
                    (u, v),
                    shared_atom=u,
                    **payload,
                )

    def apply(
        self,
        state: StateSnapshot,
        transition: Transition,
    ) -> Optional[StateSnapshot]:
        g = copy.deepcopy(state.graph)

        u, v = int(transition.src[0]), int(transition.src[1])

        if get_radical(g, u) <= 0 or get_radical(g, v) <= 0:
            return None

        set_radical(g, u, get_radical(g, u) - 1)
        set_radical(g, v, get_radical(g, v) - 1)
        retargeted = increment_edge_order_for_arrow(g, u, v)

        return _finalize_state(g, state.graph, state.memory, {u, v} | retargeted)


class RadicalAdditionOperator(BaseOperator):
    """Radical adds to a π bond — the workhorse of radical chain propagation.

    A radical on atom *r* attacks atom *a* in π bond (*a*–*b*):
    the new σ bond r–a forms, the π bond a=b is reduced, and *b* inherits
    the radical.  Covers anti-Markovnikov HBr addition (with peroxide) and
    radical polymerisation.
    """

    kind = "R•/B-/B+"

    def propose(
        self,
        state: StateSnapshot,
        goal: StateSnapshot,
    ) -> Iterable[Transition]:
        if not _allow_radical(state.graph):
            return

        delta = GoalDelta(state.graph, goal.graph)
        extra_bonds = delta.extra_bond_edges()

        for r in delta.nodes_with_extra_radical():
            for cand in delta.missing_bond_candidates():
                u, v = cand.edge
                if r != u and r != v:
                    continue
                a = v if r == u else u

                for ab in extra_bonds:
                    au, av = ab
                    if a not in (au, av):
                        continue
                    b = av if a == au else au
                    if b == r:
                        continue

                    payload = dict(cand.payload())
                    yield _transition_payload(
                        self.kind,
                        (r, a, b),
                        (r, a, b),
                        shared_atom=a,
                        **payload,
                    )

    def apply(
        self,
        state: StateSnapshot,
        transition: Transition,
    ) -> Optional[StateSnapshot]:
        g = copy.deepcopy(state.graph)

        r = int(transition.src[0])
        a = int(transition.src[1])
        b = int(transition.src[2])

        if get_radical(g, r) <= 0:
            return None
        if edge_order(g, a, b) <= 0:
            return None

        set_radical(g, r, get_radical(g, r) - 1)
        retargeted = increment_edge_order_for_arrow(g, r, a)
        retargeted |= decrement_edge_order_for_arrow(g, a, b)
        set_radical(g, b, get_radical(g, b) + 1)

        return _finalize_state(g, state.graph, state.memory, {r, a, b} | retargeted)


class HydrogenAtomTransferOperator(BaseOperator):
    """Radical abstracts a hydrogen atom from a donor (HAT mechanism).

    R• + H–A → R–H + A•

    Unlike ionic proton transfer (LP-/H+, H-/LP+), both the hydrogen *and*
    its bonding electron move together as a neutral atom.  This is the key
    propagation step in radical halogenation (e.g. CH₄ + Cl• → CH₃• + HCl).
    """

    kind = "R•-/H-/R•+"

    def propose(
        self,
        state: StateSnapshot,
        goal: StateSnapshot,
    ) -> Iterable[Transition]:
        if not _allow_radical(state.graph):
            return
        if not bool(state.graph.graph.get("allow_h_ops", True)):
            return

        delta = GoalDelta(state.graph, goal.graph)
        needing_radical = set(delta.nodes_needing_radical())
        extra_h_nodes = delta.nodes_with_extra_h()
        needing_h_set = set(delta.nodes_needing_h())

        for r in delta.nodes_with_extra_radical():
            if r not in needing_h_set:
                continue

            for a in extra_h_nodes:
                if a not in needing_radical:
                    continue

                yield _goal_transition(
                    self.kind,
                    (r, a),
                    (r, a),
                    shared_atom=r,
                )

    def apply(
        self,
        state: StateSnapshot,
        transition: Transition,
    ) -> Optional[StateSnapshot]:
        g = copy.deepcopy(state.graph)

        r = int(transition.src[0])
        a = int(transition.src[1])

        if get_radical(g, r) <= 0:
            return None
        if get_h(g, a) <= 0:
            return None

        set_radical(g, r, get_radical(g, r) - 1)
        set_h(g, r, get_h(g, r) + 1)
        set_h(g, a, get_h(g, a) - 1)
        set_radical(g, a, get_radical(g, a) + 1)

        return _finalize_state(g, state.graph, state.memory, {r, a})
