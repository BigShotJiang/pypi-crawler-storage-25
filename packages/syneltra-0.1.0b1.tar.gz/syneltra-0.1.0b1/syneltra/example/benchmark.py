"""Single-file organic chemistry benchmark example for SynEltra.

This module merges the previous ``benchmark.cases``, ``benchmark.runner``, and
``benchmark.__main__`` implementation into one example module. The JSON data
file remains adjacent to this file as ``cases.json`` so the benchmark cases can
be edited without touching Python code.

Typical use::

    from example import get_case, run_benchmark, BenchmarkRunConfig

    case = get_case("esterification")
    print(case.reaction_smiles)

The executable runner requires the SynEltra runtime imports
``syneltra.core.config.MechanismSearchConfig`` and
``syneltra.mechanism.enumerator.MechanismEnumerator``.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from dataclasses import asdict, dataclass, field
import csv
import json
from pathlib import Path
import time
import traceback
from typing import (
    Any,
    Callable,
    Dict,
    Iterable,
    Iterator,
    List,
    Mapping,
    Optional,
    Sequence,
    Tuple,
)

from syneltra.core.config import MechanismSearchConfig
from syneltra.search import MechanismEnumerator

_PACKAGE_DIR = Path(__file__).resolve().parent
_CASES_JSON = _PACKAGE_DIR / "cases.json"

_ALLOWED_DIFFICULTIES = {"easy", "medium", "hard"}
_ALLOWED_MODES = {"polar", "radical", "pericyclic", "ionic", "organometallic"}
_REQUIRED_FIELDS = ("name", "family", "mode", "difficulty", "reaction_smiles", "notes")
_DEFAULT_VALIDITY_CHECK_ARROWS = 2


@dataclass(frozen=True)
class ReactionCase:
    """Structured organic benchmark entry.

    :param name:
        Unique case identifier.
    :param family:
        High-level reaction family, for example ``carbonyl_and_acyl``.
    :param mode:
        Mechanistic mode, typically ``polar``, ``radical``, or
        ``pericyclic``.
    :param difficulty:
        Heuristic difficulty label, usually ``easy``, ``medium``, or
        ``hard``.
    :param reaction_smiles:
        Atom-mapped reaction SMILES.
    :param notes:
        Short description of the benchmark intent.
    """

    name: str
    family: str
    mode: str
    difficulty: str
    reaction_smiles: str
    notes: str = ""

    @classmethod
    def from_mapping(cls, entry: Mapping[str, Any]) -> "ReactionCase":
        """Build a case from one JSON dictionary.

        Extra fields in the JSON are ignored deliberately so the benchmark file
        can grow later without breaking old code.
        """

        # Support both flat {"family": "..."} and nested {"hierarchy": {"family": {"key": "..."}}}
        family = entry.get("family") or ((entry.get("hierarchy") or {}).get("family") or {}).get("key", "")

        missing = [field for field in _REQUIRED_FIELDS if field != "family" and field not in entry]
        if not family:
            missing.append("family")
        if missing:
            raise ValueError(f"Case entry is missing required fields: {missing}")

        return cls(
            name=str(entry["name"]).strip(),
            family=str(family).strip(),
            mode=str(entry["mode"]).strip(),
            difficulty=str(entry["difficulty"]).strip(),
            reaction_smiles=str(entry["reaction_smiles"]).strip(),
            notes=str(entry.get("notes", "")).strip(),
        )

    def to_dict(self) -> Dict[str, str]:
        """Return a plain dictionary representation."""

        return asdict(self)

    @property
    def rsmi(self) -> str:
        """Alias for :attr:`reaction_smiles` used by benchmark runners."""

        return self.reaction_smiles


def load_case_dicts(path: Path = _CASES_JSON) -> List[Dict[str, Any]]:
    """Load raw case dictionaries from the JSON dataset.

    :param path:
        Path to a JSON file containing a list of case dictionaries.
    :return:
        Raw list of dictionaries.
    :raises ValueError:
        Raised when the JSON root is not a list.
    """

    with Path(path).open("r", encoding="utf-8") as handle:
        payload = json.load(handle)

    if not isinstance(payload, list):
        raise ValueError(f"Expected a list of cases in {path}, got {type(payload).__name__}")

    return payload


def load_cases(path: Path = _CASES_JSON) -> List[ReactionCase]:
    """Load :class:`ReactionCase` records from the JSON dataset."""

    return [ReactionCase.from_mapping(entry) for entry in load_case_dicts(path)]


def build_family_index(cases: Iterable[ReactionCase]) -> Dict[str, List[str]]:
    """Build a ``family -> sorted case names`` index."""

    index: Dict[str, List[str]] = {}

    for case in cases:
        index.setdefault(case.family, []).append(case.name)

    for names in index.values():
        names.sort()

    return dict(sorted(index.items()))


def build_mode_summary(cases: Iterable[ReactionCase]) -> Dict[str, int]:
    """Build counts per mechanism mode."""

    summary: Dict[str, int] = {}

    for case in cases:
        summary[case.mode] = summary.get(case.mode, 0) + 1

    return dict(sorted(summary.items()))


def build_difficulty_summary(cases: Iterable[ReactionCase]) -> Dict[str, int]:
    """Build counts per difficulty label."""

    summary: Dict[str, int] = {}

    for case in cases:
        summary[case.difficulty] = summary.get(case.difficulty, 0) + 1

    return dict(sorted(summary.items()))


def _assert_non_empty(value: str, field_name: str, case_name: str) -> None:
    if not value:
        raise ValueError(f"Case {case_name!r} has an empty {field_name!r} field")


def validate_cases(
    cases: Sequence[ReactionCase],
    *,
    allowed_difficulties: Optional[Iterable[str]] = None,
    allowed_modes: Optional[Iterable[str]] = None,
    require_atom_mapping: bool = True,
) -> None:
    """Run lightweight consistency checks on a benchmark set.

    :param cases:
        Cases to validate.
    :param allowed_difficulties:
        Optional set of accepted difficulty labels.
    :param allowed_modes:
        Optional set of accepted mechanism-mode labels.
    :param require_atom_mapping:
        If ``True``, require at least one atom-map token ``:n`` in the RSMI.
    :raises ValueError:
        Raised when the dataset fails a consistency check.
    """

    seen = set()
    difficulties = set(allowed_difficulties or _ALLOWED_DIFFICULTIES)
    modes = set(allowed_modes or _ALLOWED_MODES)

    for case in cases:
        _assert_non_empty(case.name, "name", case.name or "<unknown>")
        _assert_non_empty(case.family, "family", case.name)
        _assert_non_empty(case.mode, "mode", case.name)
        _assert_non_empty(case.difficulty, "difficulty", case.name)
        _assert_non_empty(case.reaction_smiles, "reaction_smiles", case.name)

        if case.name in seen:
            raise ValueError(f"Duplicate case name detected: {case.name}")
        seen.add(case.name)

        if case.difficulty not in difficulties:
            raise ValueError(f"Unsupported difficulty label for {case.name}: {case.difficulty}")

        if case.mode not in modes:
            raise ValueError(f"Unsupported mechanism mode for {case.name}: {case.mode}")

        if ">>" not in case.reaction_smiles:
            raise ValueError(f"Reaction arrow missing from case {case.name}: {case.reaction_smiles}")

        left, right = case.reaction_smiles.split(">>", 1)
        if not left or not right:
            raise ValueError(f"Reaction side missing from case {case.name}")

        if require_atom_mapping and ":" not in case.reaction_smiles:
            raise ValueError(f"Atom-map labels missing from case {case.name}")


def filter_cases(
    cases: Iterable[ReactionCase],
    *,
    names: Optional[Iterable[str]] = None,
    families: Optional[Iterable[str]] = None,
    modes: Optional[Iterable[str]] = None,
    difficulties: Optional[Iterable[str]] = None,
    limit: Optional[int] = None,
) -> List[ReactionCase]:
    """Filter benchmark cases by name, family, mode, and difficulty."""

    name_set = set(names or [])
    family_set = set(families or [])
    mode_set = set(modes or [])
    difficulty_set = set(difficulties or [])

    selected: List[ReactionCase] = []

    for case in cases:
        if name_set and case.name not in name_set:
            continue
        if family_set and case.family not in family_set:
            continue
        if mode_set and case.mode not in mode_set:
            continue
        if difficulty_set and case.difficulty not in difficulty_set:
            continue

        selected.append(case)

        if limit is not None and len(selected) >= limit:
            break

    return selected


ORGANIC_BENCHMARK_LIST: List[ReactionCase] = load_cases()
validate_cases(ORGANIC_BENCHMARK_LIST)

ORGANIC_BENCHMARK_CASES: Dict[str, ReactionCase] = {case.name: case for case in ORGANIC_BENCHMARK_LIST}
FAMILY_INDEX: Dict[str, List[str]] = build_family_index(ORGANIC_BENCHMARK_LIST)
FAMILY_SUMMARY: Dict[str, int] = {family: len(names) for family, names in FAMILY_INDEX.items()}
MODE_SUMMARY: Dict[str, int] = build_mode_summary(ORGANIC_BENCHMARK_LIST)
DIFFICULTY_SUMMARY: Dict[str, int] = build_difficulty_summary(ORGANIC_BENCHMARK_LIST)


def iter_cases() -> Iterator[ReactionCase]:
    """Yield all benchmark cases in dataset order."""

    yield from ORGANIC_BENCHMARK_LIST


def get_case(name: str) -> ReactionCase:
    """Return a benchmark case by name."""

    try:
        return ORGANIC_BENCHMARK_CASES[name]
    except KeyError as exc:
        available = ", ".join(list_case_names()[:8])
        raise KeyError(f"Unknown benchmark case {name!r}. Examples: {available}") from exc


def get_cases_by_family(family: str) -> List[ReactionCase]:
    """Return all benchmark cases for one reaction family."""

    return filter_cases(ORGANIC_BENCHMARK_LIST, families=[family])


def get_cases_by_mode(mode: str) -> List[ReactionCase]:
    """Return all benchmark cases for one mechanism mode."""

    return filter_cases(ORGANIC_BENCHMARK_LIST, modes=[mode])


def get_cases_by_difficulty(difficulty: str) -> List[ReactionCase]:
    """Return all benchmark cases for one difficulty label."""

    return filter_cases(ORGANIC_BENCHMARK_LIST, difficulties=[difficulty])


def list_case_names() -> List[str]:
    """Return all case names in sorted order."""

    return sorted(ORGANIC_BENCHMARK_CASES)


def list_families() -> List[str]:
    """Return all family names in sorted order."""

    return sorted(FAMILY_INDEX)


def list_modes() -> List[str]:
    """Return all mechanism modes in sorted order."""

    return sorted(MODE_SUMMARY)


def list_difficulties() -> List[str]:
    """Return all difficulty labels in sorted order."""

    return sorted(DIFFICULTY_SUMMARY)


def as_dict(case: ReactionCase) -> Dict[str, str]:
    """Convert a :class:`ReactionCase` into a plain dictionary."""

    return case.to_dict()


def validate_dataset() -> None:
    """Validate the built-in benchmark dataset."""

    validate_cases(ORGANIC_BENCHMARK_LIST)


SuccessPredicate = Callable[[ReactionCase, Sequence[Any]], bool]


def _unique_int_tuple(
    values: Iterable[int],
    *,
    min_value: int,
    label: str,
) -> Tuple[int, ...]:
    """Return validated integer values while preserving first occurrence order."""

    unique: List[int] = []
    seen = set()

    for value in values:
        int_value = int(value)

        if int_value < min_value:
            if min_value == 0:
                raise ValueError(f"{label} fallback values must be non-negative integers, " f"got {value!r}")
            raise ValueError(f"{label} fallback values must be integers >= {min_value}, " f"got {value!r}")

        if int_value not in seen:
            seen.add(int_value)
            unique.append(int_value)

    if not unique:
        raise ValueError(f"At least one {label} fallback value is required")

    return tuple(unique)


@dataclass(frozen=True)
class BenchmarkAttemptSpec:
    """One concrete mechanism-search setting tried for a benchmark case.

    :param attempt_index:
        One-based attempt number within the case.
    :param k:
        Reaction-center context expansion radius.
    :param validity_check_arrows:
        Number of elementary graph edits between validity checkpoints.
    """

    attempt_index: int
    k: int
    validity_check_arrows: int

    def to_dict(self) -> Dict[str, int]:
        """Serialize the attempt setting."""

        return asdict(self)


@dataclass(frozen=True)
class BenchmarkRunConfig:
    """Configuration for running benchmark cases."""

    search_config: Optional[MechanismSearchConfig] = None
    max_depth: int = 50
    k: int = 1
    k_values: Optional[Tuple[int, ...]] = None
    validity_check_arrows_values: Optional[Tuple[int, ...]] = None
    fallback_on_empty: bool = True
    fallback_on_error: bool = True
    max_results: int = 50
    context_proposal_mode: str = "adaptive"
    mode: str = "reactant"
    include_product_context: bool = False
    allow_h_ops: Optional[bool] = None
    bond_only_mode: Optional[bool] = None
    ignore_hcount: Optional[bool] = None
    ignore_h_implicit: Optional[bool] = None
    auto_bond_only: bool = True
    drop_non_aam: bool = False
    use_index_as_atom_map: bool = True
    families: Optional[Tuple[str, ...]] = None
    modes: Optional[Tuple[str, ...]] = None
    difficulties: Optional[Tuple[str, ...]] = None
    names: Optional[Tuple[str, ...]] = None
    limit: Optional[int] = None
    stop_on_error: bool = False
    include_traceback: bool = False

    def resolved_search_config(self) -> MechanismSearchConfig:
        """Return a usable mechanism-search configuration."""

        return self.search_config if self.search_config is not None else MechanismSearchConfig()

    def resolved_k_values(self) -> Tuple[int, ...]:
        """Return the ordered context radii used for fallback attempts."""

        if self.k_values is not None:
            return _unique_int_tuple(self.k_values, min_value=0, label="k")

        primary = int(self.k)
        fallback = 1 if primary == 0 else (2 if primary != 2 else 1)

        return _unique_int_tuple((primary, fallback), min_value=0, label="k")

    def resolved_validity_check_arrows_values(self) -> Tuple[int, ...]:
        """Return the ordered validity checkpoint widths used for fallback attempts."""

        if self.validity_check_arrows_values is not None:
            return _unique_int_tuple(
                self.validity_check_arrows_values,
                min_value=1,
                label="validity_check_arrows",
            )

        if self.search_config is not None:
            primary = int(self.search_config.validity_check_arrows)
        else:
            primary = _DEFAULT_VALIDITY_CHECK_ARROWS

        fallback = 3 if primary != 3 else 2

        return _unique_int_tuple(
            (primary, fallback),
            min_value=1,
            label="validity_check_arrows",
        )

    def attempt_specs(self) -> Tuple[BenchmarkAttemptSpec, ...]:
        """Return ordered fallback attempts.

        Attempts are ordered by validity-check width first and then context
        radius. With defaults this yields ``(1,2)``, ``(2,2)``, ``(1,3)``,
        ``(2,3)`` for ``(k, validity_check_arrows)``.
        """

        specs: List[BenchmarkAttemptSpec] = []

        for arrows in self.resolved_validity_check_arrows_values():
            for k_value in self.resolved_k_values():
                specs.append(
                    BenchmarkAttemptSpec(
                        attempt_index=len(specs) + 1,
                        k=k_value,
                        validity_check_arrows=arrows,
                    )
                )

        return tuple(specs)


@dataclass(frozen=True)
class BenchmarkAttemptResult:
    """Result from one fallback attempt for one benchmark case."""

    attempt_index: int
    k: int
    validity_check_arrows: int
    status: str
    success: bool
    trajectory_count: int = 0
    elapsed_sec: float = 0.0
    error_type: str = ""
    error_message: str = ""
    traceback_text: str = ""

    @classmethod
    def from_spec(
        cls,
        spec: BenchmarkAttemptSpec,
        *,
        status: str,
        success: bool,
        trajectory_count: int = 0,
        elapsed_sec: float = 0.0,
        error_type: str = "",
        error_message: str = "",
        traceback_text: str = "",
    ) -> "BenchmarkAttemptResult":
        """Create an attempt result from one attempt specification."""

        return cls(
            attempt_index=spec.attempt_index,
            k=spec.k,
            validity_check_arrows=spec.validity_check_arrows,
            status=status,
            success=success,
            trajectory_count=int(trajectory_count),
            elapsed_sec=float(elapsed_sec),
            error_type=error_type,
            error_message=error_message,
            traceback_text=traceback_text,
        )

    def to_dict(self) -> Dict[str, Any]:
        """Serialize the attempt result."""

        return asdict(self)


@dataclass(frozen=True)
class BenchmarkCaseResult:
    """Result of running one benchmark case."""

    name: str
    family: str
    mode: str
    difficulty: str
    status: str
    success: bool
    trajectory_count: int = 0
    elapsed_sec: float = 0.0
    k: Optional[int] = None
    validity_check_arrows: Optional[int] = None
    attempt_count: int = 0
    attempts: Tuple[BenchmarkAttemptResult, ...] = field(default_factory=tuple)
    error_type: str = ""
    error_message: str = ""
    traceback_text: str = ""
    notes: str = ""

    @classmethod
    def from_case(
        cls,
        case: ReactionCase,
        *,
        status: str,
        success: bool,
        trajectory_count: int = 0,
        elapsed_sec: float = 0.0,
        k: Optional[int] = None,
        validity_check_arrows: Optional[int] = None,
        attempts: Sequence[BenchmarkAttemptResult] = (),
        error_type: str = "",
        error_message: str = "",
        traceback_text: str = "",
    ) -> "BenchmarkCaseResult":
        """Create a result object using metadata from one case."""

        attempts_tuple = tuple(attempts)

        return cls(
            name=case.name,
            family=case.family,
            mode=case.mode,
            difficulty=case.difficulty,
            status=status,
            success=success,
            trajectory_count=int(trajectory_count),
            elapsed_sec=float(elapsed_sec),
            k=k,
            validity_check_arrows=validity_check_arrows,
            attempt_count=len(attempts_tuple),
            attempts=attempts_tuple,
            error_type=error_type,
            error_message=error_message,
            traceback_text=traceback_text,
            notes=case.notes,
        )

    @property
    def fallback_used(self) -> bool:
        """Whether success required more than the first attempt."""

        return self.status == "success" and self.attempt_count > 1

    def to_dict(self) -> Dict[str, Any]:
        """Serialize the result as a dictionary."""

        data = asdict(self)
        data["attempts"] = [attempt.to_dict() for attempt in self.attempts]
        data["fallback_used"] = self.fallback_used
        return data


@dataclass(frozen=True)
class BenchmarkReport:
    """Summary of a benchmark run."""

    results: Tuple[BenchmarkCaseResult, ...]
    elapsed_sec: float = 0.0
    config: Dict[str, Any] = field(default_factory=dict)

    @property
    def total(self) -> int:
        return len(self.results)

    @property
    def success_count(self) -> int:
        return sum(1 for result in self.results if result.status == "success")

    @property
    def fail_count(self) -> int:
        return sum(1 for result in self.results if result.status == "fail")

    @property
    def error_count(self) -> int:
        return sum(1 for result in self.results if result.status == "error")

    @property
    def skipped_count(self) -> int:
        return sum(1 for result in self.results if result.status == "skipped")

    @property
    def attempted_count(self) -> int:
        return self.success_count + self.fail_count + self.error_count

    @property
    def fallback_success_count(self) -> int:
        return sum(1 for result in self.results if result.fallback_used)

    @property
    def total_attempt_count(self) -> int:
        return sum(result.attempt_count for result in self.results)

    @property
    def success_rate(self) -> float:
        return self.success_count / self.attempted_count if self.attempted_count else 0.0

    @property
    def fail_rate(self) -> float:
        return (self.fail_count + self.error_count) / self.attempted_count if self.attempted_count else 0.0

    @property
    def empty_fail_rate(self) -> float:
        return self.fail_count / self.attempted_count if self.attempted_count else 0.0

    @property
    def error_rate(self) -> float:
        return self.error_count / self.attempted_count if self.attempted_count else 0.0

    def group_summary(self, key: str) -> Dict[str, Dict[str, Any]]:
        """Summarize success/fail rates grouped by ``family``, ``mode``, or ``difficulty``."""

        buckets: Dict[str, List[BenchmarkCaseResult]] = defaultdict(list)

        for result in self.results:
            buckets[str(getattr(result, key))].append(result)

        summary: Dict[str, Dict[str, Any]] = {}

        for label, values in sorted(buckets.items()):
            attempted = sum(1 for value in values if value.status != "skipped")
            success = sum(1 for value in values if value.status == "success")
            fail = sum(1 for value in values if value.status == "fail")
            error = sum(1 for value in values if value.status == "error")
            fallback_success = sum(1 for value in values if value.fallback_used)

            summary[label] = {
                "total": len(values),
                "attempted": attempted,
                "success": success,
                "fail": fail,
                "error": error,
                "fallback_success": fallback_success,
                "success_rate": success / attempted if attempted else 0.0,
                "fail_rate": (fail + error) / attempted if attempted else 0.0,
            }

        return summary

    def attempt_summary(self) -> Dict[str, Dict[str, Any]]:
        """Summarize outcomes by fallback setting, e.g. ``k=2|arrows=3``."""

        buckets: Dict[str, List[BenchmarkAttemptResult]] = defaultdict(list)

        for result in self.results:
            for attempt in result.attempts:
                key = f"k={attempt.k}|arrows={attempt.validity_check_arrows}"
                buckets[key].append(attempt)

        summary: Dict[str, Dict[str, Any]] = {}

        for key, attempts in sorted(buckets.items()):
            total = len(attempts)
            success = sum(1 for attempt in attempts if attempt.status == "success")
            fail = sum(1 for attempt in attempts if attempt.status == "fail")
            error = sum(1 for attempt in attempts if attempt.status == "error")

            summary[key] = {
                "attempts": total,
                "success": success,
                "fail": fail,
                "error": error,
                "success_rate": success / total if total else 0.0,
            }

        return summary

    def to_dict(self) -> Dict[str, Any]:
        """Serialize the full report as a dictionary."""

        return {
            "total": self.total,
            "attempted": self.attempted_count,
            "success": self.success_count,
            "fail": self.fail_count,
            "error": self.error_count,
            "skipped": self.skipped_count,
            "fallback_success": self.fallback_success_count,
            "total_search_attempts": self.total_attempt_count,
            "success_rate": self.success_rate,
            "fail_rate": self.fail_rate,
            "empty_fail_rate": self.empty_fail_rate,
            "error_rate": self.error_rate,
            "elapsed_sec": self.elapsed_sec,
            "by_family": self.group_summary("family"),
            "by_mode": self.group_summary("mode"),
            "by_difficulty": self.group_summary("difficulty"),
            "by_attempt_setting": self.attempt_summary(),
            "config": self.config,
            "results": [result.to_dict() for result in self.results],
        }

    def to_json(self, *, indent: int = 2) -> str:
        """Serialize the report as JSON."""

        return json.dumps(self.to_dict(), indent=indent, sort_keys=True)

    def save_json(self, path: str | Path, *, indent: int = 2) -> Path:
        """Write the report to a JSON file and return the path."""

        out = Path(path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(self.to_json(indent=indent), encoding="utf-8")
        return out

    def save_csv(self, path: str | Path) -> Path:
        """Write one row per case to a CSV file and return the path."""

        out = Path(path)
        out.parent.mkdir(parents=True, exist_ok=True)

        rows = [result.to_dict() for result in self.results]

        if rows:
            fieldnames = list(rows[0].keys())
        else:
            fieldnames = list(BenchmarkCaseResult("", "", "", "", "", False).to_dict().keys())

        with out.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()

            for row in rows:
                csv_row = {
                    key: (json.dumps(value, sort_keys=True) if isinstance(value, (list, dict, tuple)) else value)
                    for key, value in row.items()
                }
                writer.writerow(csv_row)

        return out

    def format_summary(self) -> str:
        """Return a compact human-readable summary."""

        lines = [
            "SynEltra benchmark report",
            "-------------------------",
            f"total cases       : {self.total}",
            f"attempted         : {self.attempted_count}",
            f"success           : {self.success_count}",
            f"fail/no trajectory: {self.fail_count}",
            f"error             : {self.error_count}",
            f"skipped           : {self.skipped_count}",
            f"fallback successes: {self.fallback_success_count}",
            f"search attempts   : {self.total_attempt_count}",
            f"success rate      : {self.success_rate:.2%}",
            f"fail rate         : {self.fail_rate:.2%}",
            f"elapsed           : {self.elapsed_sec:.2f} s",
        ]

        return "\n".join(lines)


def default_success_predicate(case: ReactionCase, trajectories: Sequence[Any]) -> bool:
    """Default success criterion: at least one trajectory was found."""

    return len(trajectories) > 0


def _config_to_dict(config: BenchmarkRunConfig) -> Dict[str, Any]:
    raw = asdict(config)
    search_config = raw.pop("search_config", None)

    raw["search_config"] = asdict(config.resolved_search_config()) if search_config is not None else "default"
    raw["resolved_k_values"] = list(config.resolved_k_values())
    raw["resolved_validity_check_arrows_values"] = list(config.resolved_validity_check_arrows_values())
    raw["attempt_schedule"] = [spec.to_dict() for spec in config.attempt_specs()]

    return raw


def _search_config_for_attempt(
    base_config: MechanismSearchConfig,
    spec: BenchmarkAttemptSpec,
) -> MechanismSearchConfig:
    """Return a search config with the attempt-specific validity checkpoint."""

    return base_config.with_updates(validity_check_arrows=spec.validity_check_arrows)


def _should_continue_after_attempt(
    attempt: BenchmarkAttemptResult,
    run_config: BenchmarkRunConfig,
) -> bool:
    """Decide whether fallback should continue after a non-success attempt."""

    if attempt.status == "fail":
        return bool(run_config.fallback_on_empty)

    if attempt.status == "error":
        return bool(run_config.fallback_on_error)

    return False


def select_benchmark_cases(
    cases: Optional[Iterable[ReactionCase]] = None,
    *,
    config: Optional[BenchmarkRunConfig] = None,
    names: Optional[Iterable[str]] = None,
    families: Optional[Iterable[str]] = None,
    modes: Optional[Iterable[str]] = None,
    difficulties: Optional[Iterable[str]] = None,
    limit: Optional[int] = None,
) -> List[ReactionCase]:
    """Select cases from either an explicit iterable or the built-in dataset."""

    run_config = config or BenchmarkRunConfig()
    source = list(cases) if cases is not None else ORGANIC_BENCHMARK_LIST

    return filter_cases(
        source,
        names=names if names is not None else run_config.names,
        families=families if families is not None else run_config.families,
        modes=modes if modes is not None else run_config.modes,
        difficulties=(difficulties if difficulties is not None else run_config.difficulties),
        limit=limit if limit is not None else run_config.limit,
    )


def _run_attempt(
    case: ReactionCase,
    *,
    spec: BenchmarkAttemptSpec,
    searcher: Optional[MechanismEnumerator],
    search_config: MechanismSearchConfig,
    run_config: BenchmarkRunConfig,
    success_predicate: SuccessPredicate,
) -> BenchmarkAttemptResult:
    """Run one fallback attempt for one case."""

    started = time.perf_counter()

    try:
        actual_searcher = searcher or MechanismEnumerator(config=search_config)

        trajectories = actual_searcher.enumerate_from_rsmi(
            case.reaction_smiles,
            max_depth=run_config.max_depth,
            k=spec.k,
            mode=run_config.mode,  # type: ignore[arg-type]
            include_product_context=run_config.include_product_context,
            context_proposal_mode=run_config.context_proposal_mode,
            allow_h_ops=run_config.allow_h_ops,
            bond_only_mode=run_config.bond_only_mode,
            ignore_hcount=run_config.ignore_hcount,
            ignore_h_implicit=run_config.ignore_h_implicit,
            auto_bond_only=run_config.auto_bond_only,
            max_results=run_config.max_results,
            drop_non_aam=run_config.drop_non_aam,
            use_index_as_atom_map=run_config.use_index_as_atom_map,
        )

        elapsed = time.perf_counter() - started
        success = bool(success_predicate(case, trajectories))

        return BenchmarkAttemptResult.from_spec(
            spec,
            status="success" if success else "fail",
            success=success,
            trajectory_count=len(trajectories),
            elapsed_sec=elapsed,
        )

    except Exception as exc:  # pragma: no cover - depends on external chemistry stack
        elapsed = time.perf_counter() - started

        if run_config.stop_on_error:
            raise

        tb = traceback.format_exc() if run_config.include_traceback else ""

        return BenchmarkAttemptResult.from_spec(
            spec,
            status="error",
            success=False,
            trajectory_count=0,
            elapsed_sec=elapsed,
            error_type=type(exc).__name__,
            error_message=str(exc),
            traceback_text=tb,
        )


def _finalize_case_result(
    case: ReactionCase,
    attempts: Sequence[BenchmarkAttemptResult],
    elapsed_sec: float,
) -> BenchmarkCaseResult:
    """Collapse attempt-level results into one case-level result."""

    if not attempts:
        return BenchmarkCaseResult.from_case(
            case,
            status="skipped",
            success=False,
            elapsed_sec=elapsed_sec,
            attempts=(),
        )

    successful = next(
        (attempt for attempt in attempts if attempt.status == "success"),
        None,
    )

    if successful is not None:
        return BenchmarkCaseResult.from_case(
            case,
            status="success",
            success=True,
            trajectory_count=successful.trajectory_count,
            elapsed_sec=elapsed_sec,
            k=successful.k,
            validity_check_arrows=successful.validity_check_arrows,
            attempts=attempts,
        )

    last = attempts[-1]
    any_fail = any(attempt.status == "fail" for attempt in attempts)
    status = "fail" if any_fail else "error"

    representative_error = next(
        (attempt for attempt in reversed(attempts) if attempt.status == "error"),
        last,
    )

    return BenchmarkCaseResult.from_case(
        case,
        status=status,
        success=False,
        trajectory_count=last.trajectory_count,
        elapsed_sec=elapsed_sec,
        k=last.k,
        validity_check_arrows=last.validity_check_arrows,
        attempts=attempts,
        error_type=representative_error.error_type,
        error_message=representative_error.error_message,
        traceback_text=representative_error.traceback_text,
    )


def run_case(
    case: ReactionCase | str,
    *,
    searcher: Optional[MechanismEnumerator] = None,
    config: Optional[BenchmarkRunConfig] = None,
    success_predicate: SuccessPredicate = default_success_predicate,
) -> BenchmarkCaseResult:
    """Run one benchmark case with fallback and return a structured result.

    The runner tries all configured fallback combinations until one attempt
    produces an acceptable trajectory or fallback is disabled for the observed
    failure type.

    A case is counted as:

    - ``success`` if any attempt succeeds;
    - ``fail`` if at least one attempt completed but no acceptable trajectory
      was found;
    - ``error`` if all executed attempts raised exceptions;
    - ``skipped`` only when no attempts were configured.
    """

    run_config = config or BenchmarkRunConfig()
    actual_case = get_case(case) if isinstance(case, str) else case
    base_search_config = run_config.resolved_search_config()

    attempts: List[BenchmarkAttemptResult] = []
    started = time.perf_counter()

    for spec in run_config.attempt_specs():
        attempt_search_config = _search_config_for_attempt(base_search_config, spec)

        # A supplied searcher may carry custom state/config. It is only safe to
        # reuse for the first attempt; later attempts need a fresh enumerator so
        # validity_check_arrows can actually change.
        attempt_searcher = (
            searcher
            if spec.attempt_index == 1
            and int(base_search_config.validity_check_arrows) == int(spec.validity_check_arrows)
            else None
        )

        attempt = _run_attempt(
            actual_case,
            spec=spec,
            searcher=attempt_searcher,
            search_config=attempt_search_config,
            run_config=run_config,
            success_predicate=success_predicate,
        )

        attempts.append(attempt)

        if attempt.status == "success":
            break

        if not _should_continue_after_attempt(attempt, run_config):
            break

    elapsed = time.perf_counter() - started

    return _finalize_case_result(actual_case, attempts, elapsed)


def run_benchmark(
    cases: Optional[Iterable[ReactionCase]] = None,
    *,
    searcher: Optional[MechanismEnumerator] = None,
    config: Optional[BenchmarkRunConfig] = None,
    success_predicate: SuccessPredicate = default_success_predicate,
    progress: bool = False,
) -> BenchmarkReport:
    """Run a benchmark suite and report final success/fail rates.

    :param cases:
        Optional explicit cases. If omitted, the built-in Clayden-style
        benchmark is used.
    :param searcher:
        Optional preconfigured enumerator for the first attempt of each case.
        Fallback attempts that need altered search configuration create a fresh
        enumerator automatically.
    :param config:
        Benchmark execution configuration.
    :param success_predicate:
        Predicate deciding whether a completed enumeration is successful.
    :param progress:
        If ``True``, print one compact line per case, including the successful
        fallback setting when found.
    :return:
        :class:`BenchmarkReport` with global and grouped rates.
    """

    run_config = config or BenchmarkRunConfig()
    selected_cases = select_benchmark_cases(cases, config=run_config)

    results: List[BenchmarkCaseResult] = []
    started = time.perf_counter()

    for index, case in enumerate(selected_cases, start=1):
        result = run_case(
            case,
            searcher=searcher,
            config=run_config,
            success_predicate=success_predicate,
        )

        results.append(result)

        if progress:
            setting = (
                f"k={result.k},a={result.validity_check_arrows}"
                if result.k is not None and result.validity_check_arrows is not None
                else "k=?,a=?"
            )

            print(
                f"[{index:>3}/{len(selected_cases):<3}] "
                f"{result.status:<7} {case.name:<38} "
                f"n={result.trajectory_count:<3} attempts={result.attempt_count:<2} "
                f"{setting:<9} {result.elapsed_sec:7.2f}s"
            )

    elapsed = time.perf_counter() - started

    return BenchmarkReport(
        results=tuple(results),
        elapsed_sec=elapsed,
        config=_config_to_dict(run_config),
    )


def report_success_fail_rate(report: BenchmarkReport) -> Dict[str, float]:
    """Return the final success/fail rates from a benchmark report."""

    return {
        "success_rate": report.success_rate,
        "fail_rate": report.fail_rate,
        "empty_fail_rate": report.empty_fail_rate,
        "error_rate": report.error_rate,
    }


def _csv_tuple(values: Optional[str]) -> Optional[Tuple[str, ...]]:
    if not values:
        return None

    return tuple(item.strip() for item in values.split(",") if item.strip())


def _csv_int_tuple(values: Optional[str]) -> Optional[Tuple[int, ...]]:
    if not values:
        return None

    return tuple(int(item.strip()) for item in values.split(",") if item.strip())


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run SynEltra's Clayden-style organic benchmark.")

    parser.add_argument("--names", help="Comma-separated case names to run.")
    parser.add_argument("--families", help="Comma-separated family labels to run.")
    parser.add_argument("--modes", help="Comma-separated mechanism modes to run.")
    parser.add_argument(
        "--difficulties",
        help="Comma-separated difficulty labels to run.",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Run only the first N selected cases.",
    )
    parser.add_argument(
        "--k",
        type=int,
        default=1,
        help=("Primary reaction-center context radius. " "Use 0 for exact reaction-center context only."),
    )
    parser.add_argument(
        "--k-values",
        default=None,
        help="Comma-separated fallback k values. 0 is allowed, e.g. 0,1,2.",
    )
    parser.add_argument(
        "--validity-check-arrows",
        type=int,
        default=2,
        help="Primary validity-check arrow window.",
    )
    parser.add_argument(
        "--validity-check-arrows-values",
        default=None,
        help=("Comma-separated fallback validity windows. " "Default uses primary value and 3, e.g. 2,3."),
    )
    parser.add_argument(
        "--no-fallback-empty",
        action="store_true",
        help="Do not continue fallback when a setting returns zero trajectories.",
    )
    parser.add_argument(
        "--no-fallback-error",
        action="store_true",
        help="Do not continue fallback when a setting raises an exception.",
    )
    parser.add_argument(
        "--max-depth",
        type=int,
        default=50,
        help="Maximum search depth.",
    )
    parser.add_argument(
        "--max-results",
        type=int,
        default=50,
        help="Maximum trajectories per case.",
    )
    parser.add_argument(
        "--beam-width",
        type=int,
        default=64,
        help="Beam width.",
    )
    parser.add_argument(
        "--beam-mode",
        default="softmax_beam",
        choices=["recall_beam", "cumulative_beam", "softmax_beam", "custom"],
        help="Beam search ranking mode.",
    )
    parser.add_argument(
        "--context-proposal-mode",
        default="adaptive",
        help="Candidate proposal mode passed to MechanismEnumerator.",
    )
    parser.add_argument(
        "--include-traceback",
        action="store_true",
        help="Store Python tracebacks for error cases in the JSON output.",
    )
    parser.add_argument(
        "--json",
        type=Path,
        default=None,
        help="Write a JSON report.",
    )
    parser.add_argument(
        "--csv",
        type=Path,
        default=None,
        help="Write per-case CSV results.",
    )
    parser.add_argument(
        "--no-progress",
        action="store_true",
        help="Disable per-case progress lines.",
    )

    return parser


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)

    search_config = MechanismSearchConfig(
        search_strategy="beam",
        beam_mode=args.beam_mode,
        beam_width=args.beam_width,
        validity_check_arrows=args.validity_check_arrows,
    )

    config = BenchmarkRunConfig(
        search_config=search_config,
        max_depth=args.max_depth,
        k=args.k,
        k_values=_csv_int_tuple(args.k_values),
        validity_check_arrows_values=_csv_int_tuple(args.validity_check_arrows_values),
        fallback_on_empty=not args.no_fallback_empty,
        fallback_on_error=not args.no_fallback_error,
        max_results=args.max_results,
        context_proposal_mode=args.context_proposal_mode,
        names=_csv_tuple(args.names),
        families=_csv_tuple(args.families),
        modes=_csv_tuple(args.modes),
        difficulties=_csv_tuple(args.difficulties),
        limit=args.limit,
        include_traceback=args.include_traceback,
    )

    report = run_benchmark(config=config, progress=not args.no_progress)

    print(report.format_summary())

    if args.json:
        print(f"JSON report: {report.save_json(args.json)}")

    if args.csv:
        print(f"CSV report : {report.save_csv(args.csv)}")

    return 0 if report.error_count == 0 else 1


__all__ = [
    "BenchmarkAttemptResult",
    "BenchmarkAttemptSpec",
    "BenchmarkCaseResult",
    "BenchmarkReport",
    "BenchmarkRunConfig",
    "DIFFICULTY_SUMMARY",
    "FAMILY_INDEX",
    "FAMILY_SUMMARY",
    "MODE_SUMMARY",
    "ORGANIC_BENCHMARK_CASES",
    "ORGANIC_BENCHMARK_LIST",
    "ReactionCase",
    "as_dict",
    "build_parser",
    "default_success_predicate",
    "filter_cases",
    "get_case",
    "get_cases_by_difficulty",
    "get_cases_by_family",
    "get_cases_by_mode",
    "iter_cases",
    "list_case_names",
    "list_difficulties",
    "list_families",
    "list_modes",
    "load_case_dicts",
    "load_cases",
    "main",
    "report_success_fail_rate",
    "run_benchmark",
    "run_case",
    "select_benchmark_cases",
    "validate_cases",
    "validate_dataset",
]


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
