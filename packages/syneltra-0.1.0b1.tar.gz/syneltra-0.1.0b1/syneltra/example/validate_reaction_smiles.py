#!/usr/bin/env python3
"""
Validate SynMechBench reaction SMILES using synkit.

Checks
------
1. JSON structure and required fields.
2. Standardization via synkit.Chem.Reaction.standardize.Standardize.
3. Canonicalization via synkit.Chem.Reaction.canon_rsmi.CanonRSMI.
4. Atom-map balance: reactant and product graph node counts must match
   (non-AAM atoms dropped before comparison).
5. Hydrogen completion: HComplete checks whether H assignment is unambiguous
   (new_its is None → ambiguous, recorded as a warning).

Usage
-----
# From any directory (paths are relative to CWD or absolute)
python -m syneltra.example.validate_reaction_smiles cases.json
python validate_reaction_smiles.py cases.json
python validate_reaction_smiles.py /path/to/cases.json

# With output files
python validate_reaction_smiles.py cases.json --out validation_report.json
python validate_reaction_smiles.py cases.json --fail-out failed_cases.json
python validate_reaction_smiles.py cases.json --csv validation_report.csv

# With logging control
python validate_reaction_smiles.py cases.json -v          # INFO level
python validate_reaction_smiles.py cases.json -vv         # DEBUG level
python validate_reaction_smiles.py cases.json -q          # ERROR level only

# Strict mode (fail if any case fails)
python validate_reaction_smiles.py cases.json --strict
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import logging
import sys
from collections import Counter
from copy import deepcopy
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Tuple

import networkx as nx

from synkit.Chem.Reaction.standardize import Standardize
from synkit.Chem.Reaction.canon_rsmi import CanonRSMI
from synkit.IO import rsmi_to_graph
from synkit.Graph.Feature.wl_hash import WLHash
from synkit.Graph.ITS.its_construction import ITSConstruction
from synkit.Graph.ITS.its_decompose import get_rc, its_decompose
from synkit.Graph.Hyrogen._misc import (
    check_hcount_change,
    check_explicit_hydrogen,
    get_priority,
    check_equivariant_graph,
)

logger = logging.getLogger(__name__)

_std = Standardize()
_canon = CanonRSMI()

GraphPair = Tuple[Optional[nx.Graph], Optional[nx.Graph]]
Candidate = Tuple[nx.Graph, nx.Graph, nx.Graph, nx.Graph, str]


@dataclass
class HComplete:
    """
    Hydrogen completion for one ITS graph and one optional RC graph.

    Returns (None, None) if H assignment is ambiguous or impossible.
    """

    ignore_aromaticity: bool = False
    balance_its: bool = True
    get_priority_graph: bool = False
    max_hydrogen: int = 7
    max_permutations: int = 10_000
    infer_rc_when_missing: bool = True

    def __call__(self, its: nx.Graph, rc: Optional[nx.Graph] = None) -> GraphPair:
        return self.process(its, rc)

    def process(self, its: nx.Graph, rc: Optional[nx.Graph] = None) -> GraphPair:
        if not self._is_nonempty_graph(its):
            return None, None

        direct_h_change = self._direct_its_hcount_change(its)

        if direct_h_change is not None and direct_h_change == 0:
            return self._return_without_h_completion(its, rc)

        if direct_h_change is not None and direct_h_change > self.max_hydrogen:
            logger.warning(
                "Direct ITS H-count change %s exceeds max_hydrogen=%s",
                direct_h_change,
                self.max_hydrogen,
            )
            return None, None

        try:
            react_graph, prod_graph = its_decompose(its)
        except Exception as exc:
            logger.warning("Could not decompose ITS graph: %s", exc)
            return None, None

        try:
            hcount_change = check_hcount_change(react_graph, prod_graph)
        except Exception as exc:
            logger.warning("Could not check H-count change: %s", exc)
            return None, None

        if hcount_change == 0:
            return self._return_without_h_completion(its, rc)

        if hcount_change > self.max_hydrogen:
            logger.warning(
                "H-count change %s exceeds max_hydrogen=%s",
                hcount_change,
                self.max_hydrogen,
            )
            return None, None

        candidates = self._build_hydrogen_completion_candidates(react_graph, prod_graph)

        if not candidates:
            return None, None

        return self._select_unique_candidate(candidates)

    def _return_without_h_completion(self, its: nx.Graph, rc: Optional[nx.Graph]) -> GraphPair:
        if isinstance(rc, nx.Graph):
            return its.copy(), rc.copy()
        if self.infer_rc_when_missing:
            return its.copy(), self._safe_get_rc(its)
        return its.copy(), None

    @staticmethod
    def _direct_its_hcount_change(its: nx.Graph) -> Optional[int]:
        total = 0
        found = False
        for _, data in its.nodes(data=True):
            hcount = data.get("hcount")
            if isinstance(hcount, (tuple, list)) and len(hcount) == 2:
                found = True
                h_r, h_p = int(hcount[0] or 0), int(hcount[1] or 0)
                total += abs(h_r - h_p)
        return total if found else None

    def _build_hydrogen_completion_candidates(  # noqa: C901
        self, react_graph: nx.Graph, prod_graph: nx.Graph
    ) -> List[Candidate]:
        react_base = react_graph.copy()
        prod_base = prod_graph.copy()

        try:
            _, react_h_nodes = check_explicit_hydrogen(react_base)
            _, prod_h_nodes = check_explicit_hydrogen(prod_base)
        except Exception as exc:
            logger.warning("Could not check explicit hydrogens: %s", exc)
            return []

        hydrogen_nodes_form: List[int] = []
        hydrogen_nodes_break: List[int] = []

        for node_id in set(react_base.nodes) | set(prod_base.nodes):
            if node_id not in react_base.nodes or node_id not in prod_base.nodes:
                continue
            react_h = int(react_base.nodes[node_id].get("hcount", 0) or 0)
            prod_h = int(prod_base.nodes[node_id].get("hcount", 0) or 0)
            diff = react_h - prod_h
            if diff > 0:
                hydrogen_nodes_break.extend([node_id] * diff)
            elif diff < 0:
                hydrogen_nodes_form.extend([node_id] * (-diff))

        if not hydrogen_nodes_break and not hydrogen_nodes_form:
            return []

        max_index = max(
            max(react_base.nodes, default=0),
            max(prod_base.nodes, default=0),
        )

        reusable = self._choose_reusable_hydrogen_ids(
            react_h_nodes, prod_h_nodes, hydrogen_nodes_break, hydrogen_nodes_form
        )
        required = max(len(hydrogen_nodes_break), len(hydrogen_nodes_form))
        n_new = max(0, required - len(reusable))
        new_ids = list(range(max_index + 1, max_index + 1 + n_new))
        combined = new_ids + reusable

        if not combined or len(combined) < required:
            logger.warning("Not enough hydrogen IDs: need %s, have %s", required, len(combined))
            return []

        candidates: List[Candidate] = []
        first_sig: Optional[str] = None

        for perm_id, permutation in enumerate(self._limited_permutations(combined)):
            if perm_id >= self.max_permutations:
                logger.warning("Stopped after max_permutations=%s", self.max_permutations)
                break

            react_c = self._add_hydrogen_nodes(react_base, zip(hydrogen_nodes_break, combined), False)
            prod_c = self._add_hydrogen_nodes(prod_base, zip(hydrogen_nodes_form, permutation), True)

            try:
                its_c = ITSConstruction().ITSGraph(
                    react_c,
                    prod_c,
                    ignore_aromaticity=self.ignore_aromaticity,
                    balance_its=self.balance_its,
                )
            except Exception as exc:
                logger.debug("ITS construction failed for candidate %s: %s", perm_id, exc)
                continue

            rc_c = self._safe_get_rc(its_c)
            if not self._is_nonempty_graph(rc_c):
                continue

            sig = self._safe_rc_hash(rc_c)
            if sig is None:
                continue

            if not self.get_priority_graph:
                if first_sig is None:
                    first_sig = sig
                elif sig != first_sig:
                    return []

            candidates.append((react_c, prod_c, its_c, rc_c, sig))

        return candidates

    @staticmethod
    def _choose_reusable_hydrogen_ids(
        react_h_nodes: Iterable[int],
        prod_h_nodes: Iterable[int],
        hydrogen_nodes_break: List[int],
        hydrogen_nodes_form: List[int],
    ) -> List[int]:
        react_h = list(react_h_nodes)
        prod_h = list(prod_h_nodes)
        if hydrogen_nodes_break and not hydrogen_nodes_form:
            return react_h
        if hydrogen_nodes_form and not hydrogen_nodes_break:
            return react_h or prod_h
        seen: set = set()
        merged = []
        for h in react_h + prod_h:
            if h not in seen:
                seen.add(h)
                merged.append(h)
        return merged

    def _select_unique_candidate(self, candidates: List[Candidate]) -> GraphPair:
        if not candidates:
            return None, None
        if len(candidates) == 1:
            _, _, its, rc, _ = candidates[0]
            return its, rc

        rc_list = [c[3] for c in candidates]
        its_list = [c[2] for c in candidates]
        rc_sig = [c[4] for c in candidates]

        if self._all_rcs_equivariant(rc_list, rc_sig):
            return its_list[0], rc_list[0]

        if not self.get_priority_graph:
            return None, None

        try:
            priority_indices = get_priority(rc_list)
        except Exception as exc:
            logger.warning("Priority graph selection failed: %s", exc)
            return None, None

        rc_list = [rc_list[i] for i in priority_indices]
        its_list = [its_list[i] for i in priority_indices]
        rc_sig = [rc_sig[i] for i in priority_indices]

        if self._all_rcs_equivariant(rc_list, rc_sig):
            return its_list[0], rc_list[0]

        return None, None

    @staticmethod
    def _add_hydrogen_nodes(
        graph: nx.Graph, node_id_pairs: Iterable[Tuple[int, int]], atom_map_update: bool
    ) -> nx.Graph:
        new_graph = deepcopy(graph)
        for node_id, h_id in node_id_pairs:
            if node_id not in new_graph.nodes:
                continue
            atom_map_val = h_id if atom_map_update else new_graph.nodes[node_id].get("atom_map", 0)
            if h_id not in new_graph.nodes:
                new_graph.add_node(
                    h_id,
                    charge=0,
                    hcount=0,
                    aromatic=False,
                    element="H",
                    atom_map=atom_map_val,
                )
            if not new_graph.has_edge(node_id, h_id):
                new_graph.add_edge(node_id, h_id, order=1.0, bond_type="SINGLE")
            old_h = int(new_graph.nodes[node_id].get("hcount", 0) or 0)
            new_graph.nodes[node_id]["hcount"] = max(0, old_h - 1)
        return new_graph

    @staticmethod
    def _limited_permutations(values: List[int]) -> Iterator[Tuple[int, ...]]:
        yield from itertools.permutations(values)

    @staticmethod
    def _is_nonempty_graph(graph: Optional[nx.Graph]) -> bool:
        return isinstance(graph, nx.Graph) and graph.number_of_nodes() > 0

    @staticmethod
    def _safe_get_rc(its: nx.Graph) -> Optional[nx.Graph]:
        try:
            rc = get_rc(its)
        except Exception as exc:
            logger.debug("Could not extract RC: %s", exc)
            return None
        return rc if isinstance(rc, nx.Graph) and rc.number_of_nodes() > 0 else None

    @staticmethod
    def _safe_rc_hash(rc: nx.Graph) -> Optional[str]:
        try:
            return WLHash(iterations=3).weisfeiler_lehman_graph_hash(rc)
        except Exception as exc:
            logger.debug("Could not compute RC WL hash: %s", exc)
            return None

    @staticmethod
    def _all_rcs_equivariant(rc_list: List[nx.Graph], rc_sig: List[str]) -> bool:
        if not rc_list:
            return False
        if len(rc_list) == 1:
            return True
        if len(set(rc_sig)) != 1:
            return False
        try:
            _, equivariant = check_equivariant_graph(rc_list)
        except Exception:
            return False
        return equivariant == len(rc_list) - 1


_hcomplete = HComplete(
    ignore_aromaticity=False,
    balance_its=True,
    get_priority_graph=False,
    max_hydrogen=7,
)


@dataclass
class CaseValidation:
    case_id: str
    name: str
    reaction_code: str
    status: str
    parse_ok: bool
    canonical_rsmi: str
    atom_maps_balanced: bool
    reactant_node_count: int
    product_node_count: int
    h_complete_ok: bool
    errors: List[str]
    warnings: List[str]


def validate_case(case: Dict[str, Any]) -> CaseValidation:  # noqa: C901
    case_id = str(case.get("case_id") or "")
    name = str(case.get("name") or "")
    reaction_code = str(case.get("reaction_code") or "")
    rxn = str(case.get("reaction_smiles") or "")

    logger.debug(f"Validating case {case_id}: {name}")

    errors: List[str] = []
    warnings: List[str] = []

    for key in ["case_id", "name", "reaction_smiles"]:
        if not case.get(key):
            msg = f"Missing required field: {key}"
            errors.append(msg)
            logger.warning(f"Case {case_id}: {msg}")

    if not rxn or errors:
        return CaseValidation(
            case_id=case_id,
            name=name,
            reaction_code=reaction_code,
            status="fail",
            parse_ok=False,
            canonical_rsmi="",
            atom_maps_balanced=False,
            reactant_node_count=0,
            product_node_count=0,
            h_complete_ok=False,
            errors=errors,
            warnings=warnings,
        )

    # Step 1: Standardize (optional — fall back to original SMILES if it fails)
    try:
        std_rsmi = _std.fit(rxn, remove_aam=False)
        if std_rsmi is None:
            warnings.append("Standardization returned None; using original SMILES")
            std_rsmi = rxn
    except Exception as exc:
        warnings.append(f"Standardization failed ({exc}); using original SMILES")
        std_rsmi = rxn

    parse_ok = True

    # Step 2: Canonicalize
    canonical_rsmi = std_rsmi
    try:
        canonical_rsmi = _canon.canonicalise(std_rsmi).canonical_rsmi
    except Exception as exc:
        warnings.append(f"Canonicalization failed, using standardized form: {exc}")

    # Step 3: Graph-based atom-map balance check.
    # If standardization dropped atoms (artificial imbalance), retry on the canonicalized
    # original SMILES — std is a normalizer, not the source of truth for atom-map balance.
    atom_maps_balanced = False
    r_nodes = p_nodes = 0
    _r_graph: Optional[nx.Graph] = None
    _p_graph: Optional[nx.Graph] = None

    try:
        r, p = rsmi_to_graph(canonical_rsmi, drop_non_aam=True)
        if r is not None and p is not None:
            r_nodes = r.number_of_nodes()
            p_nodes = p.number_of_nodes()
            atom_maps_balanced = r_nodes == p_nodes
            if atom_maps_balanced:
                _r_graph, _p_graph = r, p
            else:
                try:
                    orig_canon = _canon.canonicalise(rxn).canonical_rsmi
                    r2, p2 = rsmi_to_graph(orig_canon, drop_non_aam=True)
                    if r2 is not None and p2 is not None and r2.number_of_nodes() == p2.number_of_nodes():
                        warnings.append(
                            f"Standardization dropped atoms (std: r={r_nodes}, p={p_nodes}); "
                            "balance confirmed on original SMILES"
                        )
                        r_nodes, p_nodes = r2.number_of_nodes(), p2.number_of_nodes()
                        atom_maps_balanced = True
                        _r_graph, _p_graph = r2, p2
                    else:
                        errors.append(f"Atom-map imbalance: reactant nodes={r_nodes}, product nodes={p_nodes}")
                except Exception:
                    errors.append(f"Atom-map imbalance: reactant nodes={r_nodes}, product nodes={p_nodes}")
        else:
            errors.append("Graph conversion returned None")
    except Exception as exc:
        errors.append(f"Graph conversion failed: {exc}")

    # Step 4: Hydrogen completion check (ambiguity detection).
    # Runs only when atom-map balance is confirmed.
    # new_its is None → H assignment is ambiguous → recorded as a warning.
    h_complete_ok = False
    if atom_maps_balanced and _r_graph is not None and _p_graph is not None:
        try:
            its = ITSConstruction().construct(_r_graph, _p_graph)
            rc = _hcomplete._safe_get_rc(its)
            new_its, _ = _hcomplete.process(its, rc)
            if new_its is None:
                warnings.append("Hydrogen completion is ambiguous or failed")
                h_complete_ok = False
            else:
                h_complete_ok = True
                logger.debug(f"Case {case_id}: H-completion OK")
        except Exception as exc:
            warnings.append(f"Hydrogen completion check error: {exc}")

    status = "pass" if parse_ok and atom_maps_balanced and not errors else "fail"

    return CaseValidation(
        case_id=case_id,
        name=name,
        reaction_code=reaction_code,
        status=status,
        parse_ok=parse_ok,
        canonical_rsmi=canonical_rsmi,
        atom_maps_balanced=atom_maps_balanced,
        reactant_node_count=r_nodes,
        product_node_count=p_nodes,
        h_complete_ok=h_complete_ok,
        errors=errors,
        warnings=warnings,
    )


def load_cases(path: Path) -> List[Dict[str, Any]]:
    logger.info(f"Loading cases from {path}")
    data = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(data, list):
        logger.info(f"Loaded {len(data)} cases")
        return data
    if isinstance(data, dict):
        for key in ["cases", "data", "reactions"]:
            if isinstance(data.get(key), list):
                logger.info(f"Loaded {len(data[key])} cases from '{key}' key")
                return data[key]
    raise ValueError("Input JSON must be a list of cases or an object with a cases/data/reactions list.")


def setup_logging(verbose: int = 0, quiet: int = 0) -> None:
    if quiet:
        level = logging.ERROR
    elif verbose >= 2:
        level = logging.DEBUG
    elif verbose == 1:
        level = logging.INFO
    else:
        level = logging.WARNING

    logging.basicConfig(
        level=level,
        format="%(levelname)s: %(message)s",
        stream=sys.stderr,
    )


def write_csv(path: Path, rows: List[CaseValidation]) -> None:
    fields = [
        "case_id",
        "reaction_code",
        "name",
        "status",
        "parse_ok",
        "canonical_rsmi",
        "atom_maps_balanced",
        "reactant_node_count",
        "product_node_count",
        "h_complete_ok",
        "errors",
        "warnings",
    ]
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        for r in rows:
            d = asdict(r)
            for k in list(d):
                if k not in fields:
                    d.pop(k)
            for k, v in d.items():
                if isinstance(v, list):
                    d[k] = json.dumps(v, ensure_ascii=False)
            writer.writerow(d)


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Validate SynMechBench reaction SMILES")
    parser.add_argument(
        "cases_json",
        type=Path,
        help="Path to cases JSON file (relative to CWD or absolute)",
    )
    parser.add_argument("--out", type=Path, default=None, help="Write full JSON validation report.")
    parser.add_argument(
        "--fail-out",
        type=Path,
        default=None,
        help="Write JSON report of failed cases with reasons.",
    )
    parser.add_argument("--csv", type=Path, default=None, help="Write compact CSV validation report.")
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Return nonzero exit code if any case fails.",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="count",
        default=0,
        help="Increase verbosity (-v INFO, -vv DEBUG).",
    )
    parser.add_argument(
        "-q",
        "--quiet",
        action="count",
        default=0,
        help="Suppress output (-q for ERROR only).",
    )
    args = parser.parse_args(argv)

    setup_logging(verbose=args.verbose, quiet=args.quiet)

    input_path = Path(args.cases_json).resolve()
    if not input_path.exists():
        logger.error(f"Input file not found: {input_path}")
        return 1

    try:
        cases = load_cases(input_path)
    except Exception as exc:
        logger.error(f"Failed to load cases: {exc}")
        return 1

    logger.info(f"Validating {len(cases)} cases...")
    results = []
    passed = failed = 0
    for i, c in enumerate(cases, 1):
        result = validate_case(c)
        results.append(result)
        if result.status == "pass":
            passed += 1
            logger.debug(f"  [{i}/{len(cases)}] PASS: {result.case_id}")
        else:
            failed += 1
            logger.warning(f"  [{i}/{len(cases)}] FAIL: {result.case_id} - {', '.join(result.errors[:1])}")

    counts = Counter(r.status for r in results)
    h_ambiguous = sum(1 for r in results if not r.h_complete_ok)
    summary = {
        "input": str(input_path),
        "total_cases": len(results),
        "status_counts": dict(counts),
        "h_ambiguous_count": h_ambiguous,
        "failed_cases": [r.case_id for r in results if r.status != "pass"],
        "h_ambiguous_cases": [r.case_id for r in results if not r.h_complete_ok],
    }
    report = {"summary": summary, "results": [asdict(r) for r in results]}

    if args.out:
        out_path = Path(args.out).resolve()
        out_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
        logger.info(f"Wrote full report to {out_path}")

    if args.fail_out:
        fail_path = Path(args.fail_out).resolve()
        failed_results = [
            {
                "case_id": r.case_id,
                "name": r.name,
                "reaction_code": r.reaction_code,
                "reaction_smiles": c.get("reaction_smiles", ""),
                "errors": r.errors,
                "warnings": r.warnings,
            }
            for r, c in zip(results, cases)
            if r.status != "pass"
        ]
        fail_path.write_text(
            json.dumps(
                {"total_failed": len(failed_results), "cases": failed_results},
                indent=2,
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
        logger.info(f"Wrote {len(failed_results)} failed cases to {fail_path}")

    if args.csv:
        csv_path = Path(args.csv).resolve()
        write_csv(csv_path, results)
        logger.info(f"Wrote CSV report to {csv_path}")

    print(json.dumps(summary, indent=2, ensure_ascii=False))
    logger.info(f"Done: {passed} passed, {failed} failed, {h_ambiguous} H-ambiguous")

    if args.strict and counts.get("fail", 0) > 0:
        logger.error(f"Strict mode: {counts['fail']} case(s) failed")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
