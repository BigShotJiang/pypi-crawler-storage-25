"""Organic chemistry benchmark example namespace.

The implementation lives in :mod:`example.benchmark`.  Imports are lazy so
``python -m example.benchmark`` does not import the module twice.
"""

__all__ = [
    "BenchmarkAttemptResult",
    "BenchmarkAttemptSpec",
    "BenchmarkCaseResult",
    "BenchmarkReport",
    "BenchmarkRunConfig",
    "DIFFICULTY_SUMMARY",
    "FAMILY_INDEX",
    "FAMILY_SUMMARY",
    "MODE_SUMMARY",
    "ORGANIC_BENCHMARK_CASES",
    "ORGANIC_BENCHMARK_LIST",
    "ReactionCase",
    "as_dict",
    "build_parser",
    "default_success_predicate",
    "filter_cases",
    "get_case",
    "get_cases_by_difficulty",
    "get_cases_by_family",
    "get_cases_by_mode",
    "iter_cases",
    "list_case_names",
    "list_difficulties",
    "list_families",
    "list_modes",
    "load_case_dicts",
    "load_cases",
    "main",
    "report_success_fail_rate",
    "run_benchmark",
    "run_case",
    "select_benchmark_cases",
    "validate_cases",
    "validate_dataset",
]


def __getattr__(name: str):
    if name in __all__:
        from . import benchmark as _benchmark

        return getattr(_benchmark, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__():
    return sorted(set(globals()) | set(__all__))
