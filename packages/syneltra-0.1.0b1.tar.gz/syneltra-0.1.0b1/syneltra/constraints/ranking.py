from __future__ import annotations

from typing import Optional, Set, Tuple

import networkx as nx

from ..chemistry.graph import atom_element, edge_order, possible_edge_keys
from ..core.models import ExpansionContext, Transition
from .base import BaseConstraint, RankKey


class PolarEditPriorityConstraint(BaseConstraint):
    """Generic edit-level ranking from the current ITS residual and grammar."""

    name = "polar_edit_priority"
    _HALOGENS = {"F", "CL", "BR", "I"}
    _LONE_PAIR_DONORS = {"N", "O", "S", "P", "SE"}

    _EN = {
        "H": 2.20,
        "B": 2.04,
        "C": 2.55,
        "N": 3.04,
        "O": 3.44,
        "F": 3.98,
        "P": 2.19,
        "S": 2.58,
        "CL": 3.16,
        "BR": 2.96,
        "I": 2.66,
        "SE": 2.55,
    }

    @staticmethod
    def _element(g: nx.Graph, atom: int) -> str:
        return atom_element(g, int(atom))

    @staticmethod
    def _scalar_attr(g: nx.Graph, atom: int, key: str, default=0.0):
        if int(atom) not in g:
            return default

        value = g.nodes[int(atom)].get(key, default)

        if isinstance(value, (tuple, list)):
            return value[0] if value else default

        return value

    @classmethod
    def _numeric_attr(
        cls,
        g: nx.Graph,
        atom: int,
        key: str,
        default: float = 0.0,
    ) -> float:
        try:
            return float(cls._scalar_attr(g, int(atom), key, default))
        except Exception:
            return float(default)

    @classmethod
    def _bool_attr(
        cls,
        g: nx.Graph,
        atom: int,
        key: str,
        default: bool = False,
    ) -> bool:
        return bool(cls._scalar_attr(g, int(atom), key, default))

    @classmethod
    def _string_attr(
        cls,
        g: nx.Graph,
        atom: int,
        key: str,
        default: str = "",
    ) -> str:
        return str(cls._scalar_attr(g, int(atom), key, default)).upper()

    @classmethod
    def _is_h(cls, g: nx.Graph, atom: int) -> bool:
        return cls._element(g, int(atom)) == "H"

    @classmethod
    def _en(cls, g: nx.Graph, atom: int) -> float:
        return cls._EN.get(cls._element(g, int(atom)), 2.5)

    @classmethod
    def _is_heavy_edge(cls, g: nx.Graph, u: int, v: int) -> bool:
        return not cls._is_h(g, u) and not cls._is_h(g, v)

    @staticmethod
    def _bond_delta(cur: nx.Graph, goal: nx.Graph, u: int, v: int) -> float:
        return float(edge_order(goal, int(u), int(v)) - edge_order(cur, int(u), int(v)))

    @staticmethod
    def _same_edge(a: int, b: int, c: int, d: int) -> bool:
        return tuple(sorted((int(a), int(b)))) == tuple(sorted((int(c), int(d))))

    @classmethod
    def _product_conjugated(cls, goal: nx.Graph, u: int, v: int) -> bool:
        u, v = int(u), int(v)

        if goal.has_edge(u, v):
            data = goal.edges[u, v]

            if bool(data.get("conjugated", False)) or bool(data.get("in_ring", False)):
                return True

            if str(data.get("bond_type", "")).upper() == "AROMATIC":
                return True

        return bool(goal.nodes[u].get("aromatic", False)) or bool(goal.nodes[v].get("aromatic", False))

    @classmethod
    def _neighbors_in_current_or_goal(
        cls,
        cur: nx.Graph,
        goal: nx.Graph,
        atom: int,
    ) -> Set[int]:
        """Collect neighbors from both current and goal graphs."""
        atom = int(atom)
        nbrs: Set[int] = set()

        if atom in cur:
            nbrs.update(int(n) for n in cur.neighbors(atom))

        if atom in goal:
            nbrs.update(int(n) for n in goal.neighbors(atom))

        return nbrs

    @classmethod
    def _unresolved_heavy_delta_around(
        cls,
        cur: nx.Graph,
        goal: nx.Graph,
        atom: int,
    ) -> bool:
        """Return True for atom with any unresolved non-H delta."""
        atom = int(atom)

        for nbr in cls._neighbors_in_current_or_goal(cur, goal, atom):
            ref = cur if atom in cur and nbr in cur else goal

            if cls._is_h(ref, nbr):
                continue

            delta = edge_order(goal, atom, nbr) - edge_order(cur, atom, nbr)

            if abs(delta) > 1e-8:
                return True

        return False

    @classmethod
    def _has_unresolved_heavy_core_delta(
        cls,
        cur: nx.Graph,
        goal: nx.Graph,
    ) -> bool:
        """Return True if any non-H/non-H bond-order delta remains."""
        for u, v in possible_edge_keys(cur):
            u, v = int(u), int(v)
            ref = cur if u in cur and v in cur else goal

            if cls._is_h(ref, u) or cls._is_h(ref, v):
                continue

            delta = edge_order(goal, u, v) - edge_order(cur, u, v)

            if abs(delta) > 1e-8:
                return True

        return False

    @classmethod
    def _donor_pi_penalty(cls, cur: nx.Graph, donor: int) -> int:
        """Penalty for using LPs on atoms already in multiple bonds."""
        donor = int(donor)

        if donor not in cur:
            return 0

        penalty = 0

        for nbr in cur.neighbors(donor):
            order = edge_order(cur, donor, int(nbr))

            if order >= 2.9:
                penalty += 3
            elif order >= 1.9:
                penalty += 2
            elif order > 1.1:
                penalty += 1

        return penalty

    @classmethod
    def _donor_strength(cls, cur: nx.Graph, atom: int) -> Tuple[int, int, int]:
        """Rank lone-pair donors; lower is better."""
        atom = int(atom)

        if atom not in cur:
            return (9, 0, atom)

        element = cls._element(cur, atom)
        charge = cls._numeric_attr(cur, atom, "charge")
        lone_pairs = cls._numeric_attr(cur, atom, "lone_pairs")
        pi_penalty = cls._donor_pi_penalty(cur, atom)

        if charge < -1e-8:
            return (0, pi_penalty, atom)

        if element in cls._HALOGENS:
            return (4, pi_penalty, atom)

        if element in cls._LONE_PAIR_DONORS and lone_pairs > 0:
            if cls._bool_attr(cur, atom, "aromatic") or pi_penalty > 0:
                return (2, pi_penalty, atom)

            return (1, pi_penalty, atom)

        if lone_pairs > 0:
            return (3, pi_penalty, atom)

        return (9, pi_penalty, atom)

    @classmethod
    def _max_outgoing_heavy_release(
        cls,
        cur: nx.Graph,
        goal: nx.Graph,
        atom: int,
        *,
        exclude: Tuple[int, int],
    ) -> float:
        """Largest heavy-bond decrease still attached to ``atom``."""
        atom = int(atom)
        ex_u, ex_v = int(exclude[0]), int(exclude[1])
        best = 0.0

        for nbr in cls._neighbors_in_current_or_goal(cur, goal, atom):
            if cls._same_edge(atom, nbr, ex_u, ex_v):
                continue

            ref = cur if atom in cur and nbr in cur else goal

            if cls._is_h(ref, nbr):
                continue

            delta = edge_order(goal, atom, nbr) - edge_order(cur, atom, nbr)

            if delta < -1e-8:
                best = max(best, abs(float(delta)))

        return best

    @classmethod
    def _has_leaving_group_neighbor(
        cls,
        cur: nx.Graph,
        goal: nx.Graph,
        atom: int,
    ) -> bool:
        """Return True when ``atom`` loses a plausible leaving group."""
        atom = int(atom)

        for nbr in cls._neighbors_in_current_or_goal(cur, goal, atom):
            ref = cur if atom in cur and nbr in cur else goal
            element = cls._element(ref, nbr)
            cur_order = edge_order(cur, atom, nbr)
            delta = edge_order(goal, atom, nbr) - cur_order

            if element in cls._HALOGENS and cur_order > 1e-8:
                return True

            if element in cls._LONE_PAIR_DONORS | cls._HALOGENS and delta < -1e-8:
                return True

        return False

    @classmethod
    def _positive_partial_charge(cls, cur: nx.Graph, atom: int) -> float:
        """Positive partial charge with a small molecule-local correction."""
        atom = int(atom)
        partial = cls._numeric_attr(cur, atom, "partial_charge")

        if partial <= 0.0:
            return 0.0

        charges = sorted(
            cls._numeric_attr(cur, node, "partial_charge") for node in cur.nodes if not cls._is_h(cur, int(node))
        )

        if not charges:
            return partial

        median = charges[len(charges) // 2]
        return max(partial, partial - median)

    @classmethod
    def _acceptor_activation_rank(
        cls,
        cur: nx.Graph,
        goal: nx.Graph,
        atom: int,
        *,
        exclude: Tuple[int, int],
    ) -> Optional[RankKey]:
        """Return ranked electrophile features for a carbon acceptor."""
        atom = int(atom)
        ref = cur if atom in cur else goal

        if cls._element(ref, atom) != "C":
            return None

        formal_charge = cls._numeric_attr(cur, atom, "charge")
        partial_charge = cls._positive_partial_charge(cur, atom)
        release = cls._max_outgoing_heavy_release(
            cur,
            goal,
            atom,
            exclude=exclude,
        )
        has_lg = cls._has_leaving_group_neighbor(cur, goal, atom)
        has_hetero_release = cls._has_releasing_hetero_multiple_bond(
            cur,
            goal,
            atom,
            exclude=exclude,
        )
        hybridization = cls._string_attr(cur, atom, "hybridization")

        if formal_charge > 0:
            activation_class = 0
        elif has_lg and hybridization == "SP3":
            activation_class = 1
        elif has_hetero_release:
            activation_class = 2
        elif has_lg:
            activation_class = 3
        elif partial_charge > 0.05:
            activation_class = 4
        elif release > 1e-8:
            activation_class = 5
        else:
            return None

        return (
            activation_class,
            0 if has_lg else 1,
            0 if has_hetero_release else 1,
            -round(partial_charge, 3),
            -round(release, 3),
        )

    @classmethod
    def _goal_lp_attack_features(
        cls,
        cur: nx.Graph,
        goal: nx.Graph,
        transition: Transition,
    ) -> Optional[RankKey]:
        """Return ranked features for goal-missing activated LP attacks."""
        if not cls._is_lp_to_bond_transition(transition):
            return None

        donor = int(transition.src[0])
        partner = cls._lp_attack_partner(transition)

        if partner is None:
            return None

        u, v = int(transition.dst[0]), int(transition.dst[1])
        ref = cur if u in cur and v in cur else goal
        delta = cls._bond_delta(cur, goal, u, v)

        if delta <= 1e-8:
            return None

        if not cls._is_heavy_edge(ref, u, v):
            return None

        donor_rank = cls._donor_strength(cur, donor)

        if donor_rank[0] >= 9:
            return None

        acceptor_rank = cls._acceptor_activation_rank(
            cur,
            goal,
            partner,
            exclude=(u, v),
        )

        if acceptor_rank is None:
            return None

        conj = 0 if cls._product_conjugated(goal, u, v) else 1

        return (
            *donor_rank,
            *acceptor_rank,
            conj,
            -round(delta, 3),
            min(u, v),
            max(u, v),
        )

    @classmethod
    def _is_goal_directed_lp_attack(
        cls,
        cur: nx.Graph,
        goal: nx.Graph,
        transition: Transition,
    ) -> bool:
        """Return True for goal-missing activated LP attacks."""
        return (
            cls._goal_lp_attack_features(
                cur,
                goal,
                transition,
            )
            is not None
        )

    @staticmethod
    def _lp_attack_partner(transition: Transition) -> Optional[int]:
        if transition.kind != "LP-/B+" or len(transition.src) != 1 or len(transition.dst) != 2:
            return None

        donor = int(transition.src[0])
        u, v = int(transition.dst[0]), int(transition.dst[1])

        if donor == u:
            return v

        if donor == v:
            return u

        return None

    @staticmethod
    def _is_lp_to_bond_transition(transition: Transition) -> bool:
        return transition.kind == "LP-/B+" and len(transition.src) == 1 and len(transition.dst) == 2

    @classmethod
    def _is_hydride_like_donor(cls, cur: nx.Graph, donor: int) -> bool:
        """Return True if donor is an explicit hydride-like H atom."""
        donor = int(donor)

        if donor not in cur:
            return False

        if cls._element(cur, donor) != "H":
            return False

        try:
            charge = int(cur.nodes[donor].get("charge", 0))
            lone_pairs = int(cur.nodes[donor].get("lone_pairs", 0))
        except Exception:
            return False

        return charge < 0 or lone_pairs > 0

    @classmethod
    def _is_carbonyl_like_acceptor(
        cls,
        cur: nx.Graph,
        goal: nx.Graph,
        atom: int,
    ) -> bool:
        """Return True if atom is a carbonyl-like carbon acceptor."""
        atom = int(atom)
        ref = cur if atom in cur else goal
        return cls._element(ref, atom) == "C"

    @classmethod
    def _has_releasing_hetero_multiple_bond(
        cls,
        cur: nx.Graph,
        goal: nx.Graph,
        center: int,
        *,
        exclude: Tuple[int, int],
    ) -> bool:
        """Return True if center has a C=X-like bond that decreases in goal."""
        center = int(center)
        ex_u, ex_v = int(exclude[0]), int(exclude[1])

        for nbr in cls._neighbors_in_current_or_goal(cur, goal, center):
            if cls._same_edge(center, nbr, ex_u, ex_v):
                continue

            ref = cur if center in cur and nbr in cur else goal
            hetero = cls._element(ref, nbr)

            if hetero not in {"O", "N", "S", "SE"}:
                continue

            cur_order = edge_order(cur, center, nbr)
            delta = edge_order(goal, center, nbr) - cur_order

            if cur_order >= 1.8 and delta < -1e-8:
                return True

        return False

    @classmethod
    def _is_hydride_carbonyl_attack(
        cls,
        cur: nx.Graph,
        goal: nx.Graph,
        transition: Transition,
    ) -> bool:
        """Return True for H- LP attack into a carbonyl-like C=X center."""
        if not cls._is_lp_to_bond_transition(transition):
            return False

        donor = int(transition.src[0])

        if not cls._is_hydride_like_donor(cur, donor):
            return False

        partner = cls._lp_attack_partner(transition)

        if partner is None:
            return False

        if not cls._is_carbonyl_like_acceptor(cur, goal, partner):
            return False

        return cls._has_releasing_hetero_multiple_bond(
            cur,
            goal,
            partner,
            exclude=(int(transition.dst[0]), int(transition.dst[1])),
        )

    def rank_transition(
        self,
        ctx: ExpansionContext,
        transition: Transition,
    ) -> RankKey:
        cur = ctx.current.graph
        goal = ctx.goal.graph

        if transition.kind == "LP-/B+" and len(transition.dst) == 2:
            u, v = int(transition.dst[0]), int(transition.dst[1])
            ref = cur if u in cur and v in cur else goal
            delta = self._bond_delta(cur, goal, u, v)
            cur_order = edge_order(cur, u, v)
            is_heavy = self._is_heavy_edge(ref, u, v)
            donor = int(transition.src[0]) if len(transition.src) == 1 else min(u, v)
            partner = self._lp_attack_partner(transition)

            if delta > 1e-8 and self._is_hydride_carbonyl_attack(
                cur,
                goal,
                transition,
            ):
                release = 0.0

                if partner is not None:
                    release = self._max_outgoing_heavy_release(
                        cur,
                        goal,
                        partner,
                        exclude=(u, v),
                    )

                return (
                    0,
                    0,
                    0,
                    -round(release, 3),
                    0,
                    -round(delta, 3),
                    min(u, v),
                    max(u, v),
                    donor,
                )

            lp_features = self._goal_lp_attack_features(cur, goal, transition)

            if lp_features is not None:
                return (
                    0,
                    0,
                    *lp_features,
                )

            if delta > 1e-8 and is_heavy:
                edit_class = 0 if cur_order > 1e-8 else 1
                donor_pi = self._donor_pi_penalty(cur, donor)
                release = 0.0

                if partner is not None:
                    release = self._max_outgoing_heavy_release(
                        cur,
                        goal,
                        partner,
                        exclude=(u, v),
                    )

                conj = 0 if self._product_conjugated(goal, u, v) else 1

                return (
                    0,
                    edit_class,
                    donor_pi,
                    -round(release, 3),
                    conj,
                    -round(delta, 3),
                    min(u, v),
                    max(u, v),
                    donor,
                )

            if delta > 1e-8 and not is_heavy:
                h_atom = u if self._is_h(ref, u) else v if self._is_h(ref, v) else None
                x_atom = v if h_atom == u else u if h_atom == v else None

                delayed = False
                x_pi = 0

                if x_atom is not None:
                    delayed = self._unresolved_heavy_delta_around(
                        cur,
                        goal,
                        x_atom,
                    )
                    x_pi = self._donor_pi_penalty(cur, x_atom)

                global_core = self._has_unresolved_heavy_core_delta(cur, goal)

                return (
                    9 if delayed or global_core else 4,
                    x_pi,
                    -round(delta, 3),
                    min(u, v),
                    max(u, v),
                )

            return (8, min(u, v), max(u, v))

        if transition.kind == "B-/LP+" and len(transition.src) == 2:
            u, v = int(transition.src[0]), int(transition.src[1])
            sink = int(transition.dst[0]) if transition.dst else u
            delta = self._bond_delta(cur, goal, u, v)
            residual_ok = delta < -1e-8
            other = v if sink == u else u

            sink_ref = cur if sink in cur else goal
            other_ref = cur if other in cur else goal

            en_good = 0 if self._en(sink_ref, sink) >= self._en(other_ref, other) else 1

            h_bond = 0 if (self._is_h(cur if u in cur else goal, u) or self._is_h(cur if v in cur else goal, v)) else 1

            return (
                1 if residual_ok else 5,
                h_bond,
                en_good,
                -round(abs(delta), 3),
                min(u, v),
                max(u, v),
                sink,
            )

        if transition.kind == "B-/B+" and len(transition.src) == 2 and len(transition.dst) == 2:
            su, sv = int(transition.src[0]), int(transition.src[1])
            du, dv = int(transition.dst[0]), int(transition.dst[1])

            src_delta = self._bond_delta(cur, goal, su, sv)
            dst_delta = self._bond_delta(cur, goal, du, dv)

            src_ok = src_delta < -1e-8
            dst_ok = dst_delta > 1e-8

            src_ref = cur if su in cur and sv in cur else goal
            dst_ref = cur if du in cur and dv in cur else goal

            heavy = self._is_heavy_edge(src_ref, su, sv) and self._is_heavy_edge(dst_ref, du, dv)

            if src_ok and dst_ok and heavy:
                return (
                    2,
                    0 if self._product_conjugated(goal, du, dv) else 1,
                    -round(abs(src_delta) + abs(dst_delta), 3),
                    min(du, dv),
                    max(du, dv),
                )

            return (7, min(su, sv), max(su, sv), min(du, dv), max(du, dv))

        return (
            8,
            str(transition.kind),
            tuple(int(x) for x in transition.src),
            tuple(int(x) for x in transition.dst),
        )


class ContextProposalPriorityConstraint(BaseConstraint):
    """Rank pure goal-delta proposals before adjacent-RC context proposals."""

    name = "context_proposal_priority"

    def rank_transition(
        self,
        ctx: ExpansionContext,
        transition: Transition,
    ) -> RankKey:
        origin = transition.data.get("proposal_origin", "goal")
        return (0,) if origin == "goal" else (1,)


class GenericContextGuidanceConstraint(BaseConstraint):
    """Refine adaptive outside-core proposals using role and aromatic class."""

    name = "generic_context_guidance"

    @staticmethod
    def _int(data: dict, key: str, default: int = 0) -> int:
        try:
            return int(data.get(key, default))
        except Exception:
            return int(default)

    @staticmethod
    def _float(data: dict, key: str, default: float = 0.0) -> float:
        try:
            return float(data.get(key, default))
        except Exception:
            return float(default)

    def rank_transition(
        self,
        ctx: ExpansionContext,
        transition: Transition,
    ) -> RankKey:
        data = dict(transition.data or {})

        origin = str(data.get("proposal_origin", "goal"))
        role = str(
            data.get(
                "context_role",
                data.get("target_context_role", "goal_missing"),
            )
        )
        aromatic = data.get(
            "aromatic_position_class",
            data.get("target_aromatic_position_class"),
        )

        dist = max(0, self._int(data, "context_distance", 0))
        rep = max(1, self._int(data, "representative_size", 1))
        target_rep = max(0, self._int(data, "target_representative_size", 0))
        score_hint = self._float(data, "context_score_hint", 0.0)

        origin_rank = {
            "goal": 0,
            "adjacent_rc": 1,
            "generic_context": 2,
        }.get(origin, 2)

        role_rank = {
            "goal_missing": 0,
            "carbonyl_target": 0,
            "hetero_pi": 1,
            "proton_source": 1,
            "aromatic_target": 1,
            "aromatic_pi": 1,
            "pi_bond": 2,
            "conjugated_bond": 2,
            "leaving_group_sigma": 2,
            "adjacent_sigma": 4,
        }.get(role, 3)

        aromatic_rank = {
            "para": 0,
            "ortho": 1,
            "meta": 2,
            "ipso": 4,
        }.get(str(aromatic), 3 if aromatic is not None else 1)

        rep_rank = -min(8, rep + target_rep)
        score_rank = -round(score_hint, 4)

        return (
            origin_rank,
            role_rank,
            dist,
            aromatic_rank,
            rep_rank,
            score_rank,
        )
