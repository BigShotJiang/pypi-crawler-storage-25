from __future__ import annotations

from typing import Dict, Optional, Set, Tuple

from ..chemistry.graph import atom_element, edge_order, get_charge, get_lp
from ..core.models import ExpansionContext, Transition
from .base import BaseConstraint, RankKey


def transition_touched_atoms(transition: Transition) -> Set[int]:
    """Return the atom indices touched by a transition."""
    return {int(a) for a in (*transition.src, *transition.dst)}


def transition_frontier_atoms(transition: Transition) -> Set[int]:
    """Return atoms carrying the unresolved electronic imbalance after one move."""
    shared = transition.data.get("shared_atom")
    atoms = transition_touched_atoms(transition)
    if shared is None:
        return atoms
    try:
        shared_atom = int(shared)
    except Exception:
        return atoms
    remainder = {a for a in atoms if a != shared_atom}
    return remainder or {shared_atom}


class ElectronFlowConstraint(BaseConstraint):
    """Frontier-state automaton for continuity of polar electron flow."""

    name = "electron_flow"

    def __init__(self, require_touch: bool = False) -> None:
        self.require_touch = bool(require_touch)

    @staticmethod
    def _frontier_payload(ctx: ExpansionContext) -> Dict[str, object]:
        mem = ctx.current.memory
        preferred_edge = ctx.current.memory.get("frontier_preferred_src_edge")
        if preferred_edge is None:
            preferred_edge_tuple = ()
        else:
            preferred_edge_tuple = tuple(sorted(int(x) for x in preferred_edge))
        preferred_sink = ctx.current.memory.get("frontier_preferred_lp_sink")
        return_atom = ctx.current.memory.get("frontier_return_atom")
        forbidden = ctx.current.memory.get("frontier_forbidden_src_neighbors", ())
        mode = mem.get("frontier_mode")
        kind = mem.get("frontier_kind")
        status_explicit = "frontier_status" in mem
        status = mem.get("frontier_status")
        if kind is None:
            if mode in {"bond_out", "bond_thread"}:
                kind = "bond"
            elif mode == "lp_source":
                kind = "lp"
        if status is None:
            status = "required" if bool(mem.get("frontier_required", False)) else "active"
        return {
            "mode": mode,
            "kind": kind,
            "status": str(status),
            "status_explicit": bool(status_explicit),
            "anchor": mem.get("frontier_anchor_atom"),
            "basin": tuple(int(x) for x in mem.get("frontier_basin_atoms", ())),
            "required": bool(mem.get("frontier_required", False)),
            "reason": mem.get("frontier_reason"),
            "preferred_edge": preferred_edge_tuple,
            "preferred_sink": None if preferred_sink is None else int(preferred_sink),
            "return_atom": None if return_atom is None else int(return_atom),
            "forbidden_neighbors": tuple(int(x) for x in forbidden),
            "source_contains_h": bool(ctx.current.memory.get("frontier_source_contains_h", False)),
            "heavy_bond_lp_frontier": bool(ctx.current.memory.get("frontier_heavy_bond_lp_frontier", False)),
        }

    @staticmethod
    def _src_bond_atoms(transition: Transition) -> Set[int]:
        if transition.head != "B-" or len(transition.src) != 2:
            return set()
        return {int(transition.src[0]), int(transition.src[1])}

    def _expected_frontier(self, ctx: ExpansionContext) -> Set[int]:
        payload = self._frontier_payload(ctx)
        basin = set(payload["basin"])
        if basin:
            return basin
        if ctx.history:
            return transition_frontier_atoms(ctx.history[-1])
        return set()

    @staticmethod
    def _element(g, atom: int) -> str:
        return atom_element(g, int(atom))

    @classmethod
    def _is_hetero_or_halogen(cls, el: str) -> bool:
        return el in {"N", "O", "S", "P", "F", "CL", "BR", "I"}

    def _matches_hard_bond_out(  # noqa: C901
        self,
        ctx: ExpansionContext,
        transition: Transition,
        anchor: int,
        *,
        preferred_edge: Tuple[int, ...] = (),
        preferred_sink: Optional[int] = None,
        forbidden_neighbors: Tuple[int, ...] = (),
    ) -> bool:
        if transition.head != "B-" or int(anchor) not in self._src_bond_atoms(transition):
            return False
        g = ctx.current.graph
        anchor = int(anchor)
        if forbidden_neighbors and len(transition.src) == 2:
            src_atoms = tuple(int(x) for x in transition.src)
            other = src_atoms[1] if src_atoms[0] == anchor else src_atoms[0]
            if int(other) in {int(x) for x in forbidden_neighbors}:
                return False
        if preferred_edge:
            src_edge = tuple(sorted(int(x) for x in transition.src)) if len(transition.src) == 2 else ()
            if src_edge != tuple(sorted(int(x) for x in preferred_edge)):
                return False
            if preferred_sink is not None:
                if (
                    transition.kind == "B-/LP+"
                    and len(transition.dst) == 1
                    and int(transition.dst[0]) == int(preferred_sink)
                ):
                    return True
                # Concerted E2 bond shift: anionic base abstracted H, now C-H
                # breaks while C=C forms.  Only allowed when the LP donor was
                # anionic in the REACTANT (ctx.states[0]), not just transiently
                # anionic due to a preceding mechanism step (e.g. keto-enol).
                if transition.kind == "B-/B+" and len(forbidden_neighbors) == 1:
                    donor = int(forbidden_neighbors[0])
                    reactant_states = getattr(ctx, "states", ())
                    if reactant_states:
                        reactant_g = reactant_states[0].graph
                        if donor in reactant_g:
                            try:
                                if int(get_charge(reactant_g, donor)) < 0:
                                    return True
                            except Exception:
                                pass
                return False
            return True
        if self._element(g, anchor) != "H":
            return True
        hetero_neighbors = [
            int(nbr) for nbr in g.neighbors(anchor) if self._is_hetero_or_halogen(self._element(g, int(nbr)))
        ]
        if not hetero_neighbors:
            return True
        if transition.kind != "B-/LP+" or len(transition.dst) != 1:
            return False
        return int(transition.dst[0]) in set(hetero_neighbors)

    @staticmethod
    def _matches_lp_continuity(transition: Transition, anchor: int) -> bool:
        """Return True if a new LP+ frontier is consumed by LP- from same atom."""
        if transition.head == "LP-" and len(transition.src) == 1 and int(transition.src[0]) == int(anchor):
            return True
        # Also allow B-/B+ where anchor appears in dst: LP-source atom abstracts
        # a proton (concerted transfer, e.g. Br⁻ + N–H → HBr + N:).
        if transition.kind == "B-/B+" and len(transition.dst) == 2 and int(anchor) in {int(x) for x in transition.dst}:
            return True
        return False

    @staticmethod
    def _lp_continuity_is_active(ctx: ExpansionContext, anchor: int) -> bool:
        """Return whether an LP+ endpoint should constrain the next arrow."""
        g = ctx.current.graph
        mem = ctx.current.memory or {}
        if bool(g.graph.get("lp_continuity_heavy_bond_frontier", True)) and bool(
            mem.get("frontier_heavy_bond_lp_frontier", False)
        ):
            # Only enforce if anchor still has a bond that needs to increase
            # toward goal (i.e., somewhere to donate the lone pair).
            # If the LP receiver is already at goal state (e.g., water after
            # N–O departure in a Beckmann), there is nothing to donate toward
            # and forcing LP continuity would block legitimate 1,2-shifts.
            if ctx.goal is not None:
                goal_g = ctx.goal.graph
                anchor_int = int(anchor)
                if anchor_int in goal_g:
                    has_pending_formation = any(
                        edge_order(goal_g, anchor_int, int(nbr)) > edge_order(g, anchor_int, int(nbr)) + 1e-8
                        for nbr in goal_g.neighbors(anchor_int)
                        if int(nbr) in g
                    )
                    if not has_pending_formation:
                        return False
            return True
        if not bool(g.graph.get("lp_continuity_requires_negative_charge", True)):
            return True
        try:
            return int(get_charge(g, int(anchor))) < 0
        except Exception:
            return False

    @classmethod
    def _matches_bond_thread_continuity(
        cls,
        transition: Transition,
        anchor: int,
        *,
        forbidden_neighbors: Tuple[int, ...] = (),
    ) -> bool:
        """Return True if the next move continues out of a B+ frontier."""
        if transition.head != "B-" or len(transition.src) != 2:
            return False
        src_atoms = tuple(int(x) for x in transition.src)
        if int(anchor) not in src_atoms:
            return False
        other = src_atoms[1] if src_atoms[0] == int(anchor) else src_atoms[0]
        return int(other) not in {int(x) for x in forbidden_neighbors}

    @classmethod
    def _is_hidden_water_to_halogen_bond_flow(cls, ctx: ExpansionContext, transition: Transition) -> bool:
        if transition.kind != "B-/B+" or len(transition.src) != 2 or len(transition.dst) != 2:
            return False
        src = {int(x) for x in transition.src}
        dst = {int(x) for x in transition.dst}
        shared = src & dst
        if len(shared) != 1:
            return False
        h_atom = next(iter(shared))
        g = ctx.current.graph
        if cls._element(g, h_atom) != "H":
            return False
        donor = next(iter(src - {h_atom}))
        acceptor = next(iter(dst - {h_atom}))
        return (
            cls._element(g, donor) == "O"
            and bool(g.nodes[donor].get("_placeholder_repaired", False))
            and cls._element(g, acceptor) in {"F", "CL", "BR", "I"}
        )

    def allow_transition(self, ctx: ExpansionContext, transition: Transition) -> bool:  # noqa: C901
        if self._is_hidden_water_to_halogen_bond_flow(ctx, transition):
            return True
        payload = self._frontier_payload(ctx)
        mode = payload["mode"]
        kind = payload.get("kind")
        status = payload.get("status")
        anchor = payload["anchor"]
        required = payload["required"]
        if payload.get("status_explicit"):
            if status in {"satisfied", "inactive"} or anchor is None:
                return True
            if status == "required":
                if kind == "bond":
                    if mode == "bond_out" or payload.get("preferred_edge"):
                        return self._matches_hard_bond_out(
                            ctx,
                            transition,
                            int(anchor),
                            preferred_edge=tuple(payload.get("preferred_edge", ())),
                            preferred_sink=payload.get("preferred_sink"),
                            forbidden_neighbors=tuple(payload.get("forbidden_neighbors", ())),
                        )
                    return self._matches_bond_thread_continuity(
                        transition,
                        int(anchor),
                        forbidden_neighbors=tuple(payload.get("forbidden_neighbors", ())),
                    )
                if kind == "lp":
                    if not bool(ctx.current.graph.graph.get("enforce_lp_continuity", True)):
                        return True
                    anchor_int = int(anchor)
                    g = ctx.current.graph
                    if get_lp(g, anchor_int) <= 0 and int(get_charge(g, anchor_int)) >= 0:
                        return True
                    return self._matches_lp_continuity(transition, anchor_int)
                return True

            # Active frontiers keep the legacy continuity filter.  The new
            # status model only relaxes frontiers explicitly marked satisfied
            # or inactive; otherwise long solved cases lose beam survival.
            if mode == "bond_out" and required:
                return self._matches_hard_bond_out(
                    ctx,
                    transition,
                    int(anchor),
                    preferred_edge=tuple(payload.get("preferred_edge", ())),
                    preferred_sink=payload.get("preferred_sink"),
                    forbidden_neighbors=tuple(payload.get("forbidden_neighbors", ())),
                )
            if mode == "bond_thread" and bool(ctx.current.graph.graph.get("enforce_bond_continuity", True)):
                return self._matches_bond_thread_continuity(
                    transition,
                    int(anchor),
                    forbidden_neighbors=tuple(payload.get("forbidden_neighbors", ())),
                )
            if mode == "lp_source" and bool(ctx.current.graph.graph.get("enforce_lp_continuity", True)):
                if self._lp_continuity_is_active(ctx, int(anchor)):
                    anchor_int = int(anchor)
                    g = ctx.current.graph
                    if get_lp(g, anchor_int) <= 0 and int(get_charge(g, anchor_int)) >= 0:
                        return True
                    return self._matches_lp_continuity(transition, anchor_int)
                return True
            return True

        if mode == "bond_out" and required and anchor is not None:
            return self._matches_hard_bond_out(
                ctx,
                transition,
                int(anchor),
                preferred_edge=tuple(payload.get("preferred_edge", ())),
                preferred_sink=payload.get("preferred_sink"),
                forbidden_neighbors=tuple(payload.get("forbidden_neighbors", ())),
            )

        if (
            mode == "bond_thread"
            and anchor is not None
            and bool(ctx.current.graph.graph.get("enforce_bond_continuity", True))
        ):
            return self._matches_bond_thread_continuity(
                transition,
                int(anchor),
                forbidden_neighbors=tuple(payload.get("forbidden_neighbors", ())),
            )

        if (
            mode == "lp_source"
            and anchor is not None
            and bool(ctx.current.graph.graph.get("enforce_lp_continuity", True))
        ):
            if self._lp_continuity_is_active(ctx, int(anchor)):
                # Only enforce if anchor can actually donate a lone pair.
                # If it has no LP and no negative charge, forcing LP- continuity
                # would cause an impossible dead-end (e.g. C5 after LP-/B+ donates).
                anchor_int = int(anchor)
                g = ctx.current.graph
                if get_lp(g, anchor_int) <= 0 and int(get_charge(g, anchor_int)) >= 0:
                    return True
                return self._matches_lp_continuity(transition, anchor_int)
            return True

        require_touch = self.require_touch or bool(ctx.current.graph.graph.get("bond_only_mode", False))
        if ctx.depth == 0 or not require_touch:
            return True
        expected = self._expected_frontier(ctx)
        if not expected:
            return True
        return bool(transition_touched_atoms(transition) & expected)

    def rank_transition(self, ctx: ExpansionContext, transition: Transition) -> RankKey:
        if ctx.depth == 0:
            return ()

        continuity_mode = str(ctx.current.graph.graph.get("continuity_mode", "frontier"))
        payload = self._frontier_payload(ctx)
        mode = payload["mode"]
        if payload.get("status_explicit") and payload.get("status") in {
            "satisfied",
            "inactive",
        }:
            return (1, 0, 0)
        anchor = payload["anchor"]
        basin = set(payload["basin"])
        reason = payload.get("reason")
        preferred_edge = tuple(payload.get("preferred_edge", ()))
        preferred_sink = payload.get("preferred_sink")
        return_atom = payload.get("return_atom")

        if continuity_mode == "frontier" and mode == "bond_out" and anchor is not None:
            good = self._matches_hard_bond_out(
                ctx,
                transition,
                int(anchor),
                preferred_edge=preferred_edge,
                preferred_sink=preferred_sink,
            )
            g = ctx.current.graph
            exact = 0
            if preferred_edge:
                src_edge = tuple(sorted(int(x) for x in transition.src)) if len(transition.src) == 2 else ()
                exact = (
                    0
                    if src_edge == preferred_edge
                    and (
                        preferred_sink is None
                        or (
                            transition.kind == "B-/LP+"
                            and len(transition.dst) == 1
                            and int(transition.dst[0]) == int(preferred_sink)
                        )
                    )
                    else 1
                )
            if self._element(g, int(anchor)) == "H":
                preferred_tail = 0 if transition.kind == "B-/LP+" else 1
            else:
                preferred_tail = 0 if transition.kind in {"B-/LP+", "B-/B+"} else 1
            return (0 if good else 1, exact, preferred_tail)

        if (
            continuity_mode == "frontier"
            and mode == "lp_source"
            and basin
            and anchor is not None
            and self._lp_continuity_is_active(ctx, int(anchor))
        ):
            same_atom = transition.head == "LP-" and len(transition.src) == 1 and int(transition.src[0]) == int(anchor)
            same_basin_lp = transition.head == "LP-" and len(transition.src) == 1 and int(transition.src[0]) in basin
            same_basin_bond = transition.head == "B-" and bool(self._src_bond_atoms(transition) & basin)
            if reason == "carbonyl_pi_open" and anchor is not None and return_atom is not None:
                same_atom_reclose = (
                    transition.kind == "LP-/B+"
                    and len(transition.src) == 1
                    and int(transition.src[0]) == int(anchor)
                    and int(return_atom) in {int(a) for a in transition.dst}
                )
                return (
                    0 if same_atom_reclose else 1,
                    0 if same_atom else 1,
                    0 if transition.tail == "B+" else 1,
                )
            return (
                0 if same_atom else 1,
                0 if same_basin_lp else (1 if same_basin_bond else 2),
                0 if transition.tail == "B+" else 1,
            )

        if continuity_mode == "frontier" and mode == "bond_thread" and basin:
            touched = transition_touched_atoms(transition)
            shared = transition.data.get("shared_atom")
            forbidden_neighbors = tuple(payload.get("forbidden_neighbors", ()))
            anchor_atom = int(anchor) if anchor is not None else next(iter(basin))
            exact_thread = self._matches_bond_thread_continuity(
                transition,
                anchor_atom,
                forbidden_neighbors=forbidden_neighbors,
            )
            shared_bonus = 0 if shared is not None and int(shared) in basin else 1
            thread_bonus = 0 if exact_thread else (1 if transition.head == "B-" and (touched & basin) else 2)
            tail_bonus = 0 if transition.kind in {"B-/LP+", "B-/B+"} else 1
            return (thread_bonus, tail_bonus, shared_bonus)

        expected = self._expected_frontier(ctx)
        if not expected:
            return (1, 0, 0)
        touched = transition_touched_atoms(transition)
        shared = transition.data.get("shared_atom")
        shared_bonus = 0 if shared is not None and int(shared) in expected else 1
        overlap_penalty = 0 if (touched & expected) else 1
        partner_penalty = int(transition.data.get("src_partner_count", 0)) + int(
            transition.data.get("dst_partner_count", 0)
        )
        return (overlap_penalty, shared_bonus, partner_penalty)
