from __future__ import annotations

from typing import Dict, Optional, Set, Tuple

import networkx as nx

from ..chemistry.graph import atom_element, edge_order, get_h, get_lp
from ..core.models import ExpansionContext, StateSnapshot, Transition
from .base import BaseConstraint, RankKey
from .electron_flow import transition_touched_atoms


def bond_order_sum(g: nx.Graph, n: int) -> float:
    """Return the sum of bond orders incident to ``n``."""
    total = 0.0
    for nbr in g.neighbors(n):
        total += edge_order(g, n, nbr)
    return float(total)


def electron_occupancy(g: nx.Graph, n: int) -> int:
    """Return a simple local electron-octet occupancy estimate."""
    occ = 2.0 * (bond_order_sum(g, n) + get_h(g, n) + get_lp(g, n))
    return int(round(occ))


def octet_target(element: Optional[str]) -> Optional[int]:
    """Return the default target valence-shell occupancy for one element."""
    if element is None:
        return None

    el = str(element).strip().upper()

    if el == "H":
        return 2
    if el == "B":
        return 6
    if el in {"C", "N", "O", "F"}:
        return 8
    if el in {"P", "S", "CL", "BR", "I", "SI"}:
        return None

    return None


def atom_instability_score(g: nx.Graph, n: int) -> int:
    """Return a non-negative local instability score for one atom."""
    element = atom_element(g, n)
    target = octet_target(element)
    if target is None:
        return 0

    occ = electron_occupancy(g, n)
    return abs(int(target) - int(occ))


def unstable_atom_scores(g: nx.Graph) -> Dict[int, int]:
    """Return ``{atom: score}`` for all atoms with positive instability score."""
    out: Dict[int, int] = {}
    for n in g.nodes():
        score = atom_instability_score(g, n)
        if score > 0:
            out[int(n)] = int(score)
    return out


class LocalInstabilityConstraint(BaseConstraint):
    """Rank moves that repair local electronic defects created by the previous move."""

    name = "local_instability"

    def __init__(
        self,
        only_new: bool = True,
        require_touch: bool = False,
        require_improvement: bool = False,
    ) -> None:
        self.only_new = bool(only_new)
        self.require_touch = bool(require_touch)
        self.require_improvement = bool(require_improvement)

    def _previous_current_scores(
        self,
        ctx: ExpansionContext,
    ) -> Tuple[Dict[int, int], Dict[int, int]]:
        if len(ctx.states) < 2:
            return {}, unstable_atom_scores(ctx.current.graph)

        prev_graph = ctx.states[-2].graph
        return unstable_atom_scores(prev_graph), unstable_atom_scores(ctx.current.graph)

    def _active_atoms(self, ctx: ExpansionContext) -> Set[int]:
        prev_scores, cur_scores = self._previous_current_scores(ctx)

        if not self.only_new:
            return set(cur_scores)

        active = set()
        for atom, cur in cur_scores.items():
            prev = prev_scores.get(atom, 0)
            if cur > prev:
                active.add(int(atom))
        return active

    def allow_transition(self, ctx: ExpansionContext, transition: Transition) -> bool:
        if not self.require_touch or ctx.depth == 0:
            return True

        active = self._active_atoms(ctx)
        if not active:
            return True

        return bool(transition_touched_atoms(transition) & active)

    def allow_next_state(
        self,
        ctx: ExpansionContext,
        transition: Transition,
        next_state: StateSnapshot,
    ) -> bool:
        if not self.require_improvement or ctx.depth == 0:
            return True

        active = self._active_atoms(ctx)
        if not active:
            return True

        cur_scores = unstable_atom_scores(ctx.current.graph)
        next_scores = unstable_atom_scores(next_state.graph)
        cur_total = sum(cur_scores.get(atom, 0) for atom in active)
        next_total = sum(next_scores.get(atom, 0) for atom in active)
        return next_total < cur_total

    def rank_next_state(
        self,
        ctx: ExpansionContext,
        transition: Transition,
        next_state: StateSnapshot,
    ) -> RankKey:
        if ctx.depth == 0:
            return ()

        active = self._active_atoms(ctx)
        if not active:
            return (1, 0, 0)

        touched = transition_touched_atoms(transition)
        touch_penalty = 0 if (touched & active) else 1

        cur_scores = unstable_atom_scores(ctx.current.graph)
        next_scores = unstable_atom_scores(next_state.graph)
        cur_total = sum(cur_scores.get(atom, 0) for atom in active)
        next_total = sum(next_scores.get(atom, 0) for atom in active)
        improvement = cur_total - next_total
        return (touch_penalty, -improvement, next_total)
