from __future__ import annotations

from typing import Iterable, List, Optional

from ..core.models import ExpansionContext, StateSnapshot, Transition
from .base import BaseConstraint, RankKey


class ConstraintRegistry:
    """Registry and orchestrator for search constraints."""

    def __init__(self, constraints: Optional[Iterable[BaseConstraint]] = None) -> None:
        self._constraints: List[BaseConstraint] = []
        if constraints is not None:
            for constraint in constraints:
                self.register(constraint)

    def register(self, constraint: BaseConstraint) -> None:
        self._constraints.append(constraint)

    @property
    def constraints(self) -> List[BaseConstraint]:
        return list(self._constraints)

    def allow_transition(self, ctx: ExpansionContext, transition: Transition) -> bool:
        return all(c.allow_transition(ctx, transition) for c in self._constraints)

    def allow_next_state(
        self,
        ctx: ExpansionContext,
        transition: Transition,
        next_state: StateSnapshot,
    ) -> bool:
        return all(c.allow_next_state(ctx, transition, next_state) for c in self._constraints)

    def rank_transition(self, ctx: ExpansionContext, transition: Transition) -> RankKey:
        key = []
        for constraint in self._constraints:
            part = constraint.rank_transition(ctx, transition)
            if isinstance(part, tuple):
                key.extend(part)
            else:
                key.append(part)
        return tuple(key)

    def rank_next_state(
        self,
        ctx: ExpansionContext,
        transition: Transition,
        next_state: StateSnapshot,
    ) -> RankKey:
        key = []
        for constraint in self._constraints:
            part = constraint.rank_next_state(ctx, transition, next_state)
            if isinstance(part, tuple):
                key.extend(part)
            else:
                key.append(part)
        return tuple(key)
