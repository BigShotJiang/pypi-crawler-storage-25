from __future__ import annotations

from typing import Dict, Set, Tuple

import networkx as nx

from ..chemistry.graph import atom_element, edge_order
from ..core.models import ExpansionContext, StateSnapshot, Transition
from .base import BaseConstraint, RankKey


class PolarChemistryConstraint(BaseConstraint):
    """Chemistry-aware ranking for polar prefixes and ionic intermediates."""

    name = "polar_chemistry"

    @staticmethod
    def _element(g: nx.Graph, atom: int) -> str:
        return atom_element(g, int(atom))

    @staticmethod
    def _charge(g: nx.Graph, atom: int) -> int:
        return int(g.nodes[int(atom)].get("charge", 0))

    @staticmethod
    def _is_halogen(el: str) -> bool:
        return el in {"F", "CL", "BR", "I"}

    @classmethod
    def _is_hetero(cls, el: str) -> bool:
        return el in {"N", "O", "S", "P"} or cls._is_halogen(el)

    @classmethod
    def _is_pi_edge(cls, g: nx.Graph, edge: Tuple[int, int]) -> bool:
        order = edge_order(g, int(edge[0]), int(edge[1]))
        if order >= 2.0 or abs(order - 1.5) < 1e-8:
            return True
        if g.has_edge(*edge):
            bond_type = str(g.edges[edge].get("bond_type", "")).upper()
            if bond_type in {"DOUBLE", "TRIPLE", "AROMATIC"}:
                return True
        return False

    @classmethod
    def _free_proton_atoms(cls, g: nx.Graph) -> Set[int]:
        out: Set[int] = set()
        for n in g.nodes():
            n = int(n)
            if cls._element(g, n) != "H":
                continue
            if cls._charge(g, n) > 0 or g.degree(n) == 0:
                out.add(n)
        return out

    @classmethod
    def _counterion_atoms(cls, g: nx.Graph) -> Set[int]:
        out: Set[int] = set()
        for n in g.nodes():
            n = int(n)
            el = cls._element(g, n)
            if el == "H":
                continue
            if cls._charge(g, n) < 0:
                out.add(n)
                continue
            if cls._is_halogen(el) and g.degree(n) == 0:
                out.add(n)
        return out

    @classmethod
    def _protonation_context(cls, ctx: ExpansionContext) -> bool:
        g = ctx.current.graph
        has_unsat = any(
            cls._element(g, int(u)) != "H" and cls._element(g, int(v)) != "H" and cls._is_pi_edge(g, (int(u), int(v)))
            for u, v in g.edges()
        )
        return bool(has_unsat and cls._free_proton_atoms(g) and cls._counterion_atoms(g))

    @classmethod
    def _goal_allows_carbanion(cls, goal: nx.Graph, atom: int) -> bool:
        if atom not in goal:
            return False
        if cls._element(goal, atom) != "C":
            return False
        if int(goal.nodes[atom].get("charge", 0)) < 0:
            return True
        if int(goal.nodes[atom].get("lone_pairs", 0)) > 0:
            return True
        return False

    @classmethod
    def _resonance_stabilized_carbanion(cls, g: nx.Graph, atom: int) -> bool:
        if atom not in g or cls._element(g, atom) != "C":
            return False
        for nbr in g.neighbors(atom):
            nbr = int(nbr)
            el = cls._element(g, nbr)
            order = edge_order(g, atom, nbr)
            conjugated = bool(g.edges[atom, nbr].get("conjugated", False))
            if el in {"O", "N", "S"} and order >= 2.0:
                return True
            if conjugated or order >= 2.0 or abs(order - 1.5) < 1e-8:
                for nn in g.neighbors(nbr):
                    nn = int(nn)
                    if nn == atom:
                        continue
                    if cls._element(g, nn) in {"O", "N", "S"} and edge_order(g, nbr, nn) >= 2.0:
                        return True
        return False

    @staticmethod
    def _frontier(ctx: ExpansionContext) -> Dict[str, object]:
        return {
            "mode": ctx.current.memory.get("frontier_mode"),
            "anchor": ctx.current.memory.get("frontier_anchor_atom"),
            "reason": ctx.current.memory.get("frontier_reason"),
        }

    @classmethod
    def _matches_hx_cleavage(cls, ctx: ExpansionContext, transition: Transition) -> bool:
        payload = cls._frontier(ctx)
        anchor = payload.get("anchor")
        if payload.get("mode") != "bond_out" or anchor is None:
            return False
        anchor = int(anchor)
        if cls._element(ctx.current.graph, anchor) != "H":
            return False
        if transition.kind != "B-/LP+" or len(transition.src) != 2 or len(transition.dst) != 1:
            return False
        src = {int(transition.src[0]), int(transition.src[1])}
        if anchor not in src:
            return False
        dst = int(transition.dst[0])
        return cls._is_hetero(cls._element(ctx.current.graph, dst))

    @classmethod
    def _matches_anion_capture(cls, ctx: ExpansionContext, transition: Transition) -> bool:
        payload = cls._frontier(ctx)
        anchor = payload.get("anchor")
        if payload.get("mode") != "lp_source" or anchor is None:
            return False
        anchor = int(anchor)
        g = ctx.current.graph
        if transition.kind != "LP-/B+" or len(transition.src) != 1 or len(transition.dst) != 2:
            return False
        if int(transition.src[0]) != anchor:
            return False
        if anchor not in {int(transition.dst[0]), int(transition.dst[1])}:
            return False
        other = int(transition.dst[0]) if int(transition.dst[1]) == anchor else int(transition.dst[1])
        return cls._charge(g, other) > 0 and cls._element(g, other) == "C"

    @classmethod
    def _is_carbonyl_pi_open(cls, g: nx.Graph, transition: Transition) -> bool:
        if transition.kind != "B-/LP+" or len(transition.src) != 2 or len(transition.dst) != 1:
            return False
        sink = int(transition.dst[0])
        if sink not in {int(transition.src[0]), int(transition.src[1])}:
            return False
        other = int(transition.src[1]) if int(transition.src[0]) == sink else int(transition.src[0])
        if cls._element(g, sink) not in {"O", "N", "S"}:
            return False
        if cls._element(g, other) not in {"C", "P", "S"}:
            return False
        return edge_order(g, sink, other) >= 2.0

    @classmethod
    def _is_unactivated_acyl_sigma_cleavage(cls, g: nx.Graph, transition: Transition) -> bool:
        if transition.kind != "B-/LP+" or len(transition.src) != 2 or len(transition.dst) != 1:
            return False
        sink = int(transition.dst[0])
        if sink not in {int(transition.src[0]), int(transition.src[1])}:
            return False
        carbon = int(transition.src[1]) if int(transition.src[0]) == sink else int(transition.src[0])
        if cls._element(g, carbon) != "C" or cls._element(g, sink) not in {
            "O",
            "N",
            "S",
        }:
            return False
        if edge_order(g, carbon, sink) > 1.1:
            return False

        has_adjacent_pi_hetero = False
        for nbr in g.neighbors(carbon):
            nbr = int(nbr)
            if nbr == sink:
                continue
            if cls._element(g, nbr) in {"O", "N", "S"} and edge_order(g, carbon, nbr) >= 2.0:
                has_adjacent_pi_hetero = True
                break
        if not has_adjacent_pi_hetero:
            return False
        if cls._charge(g, sink) > 0:
            return False
        h_neighbors = [int(nbr) for nbr in g.neighbors(sink) if cls._element(g, int(nbr)) == "H"]
        return len(h_neighbors) == 0

    @classmethod
    def _lp_donor_class(cls, g: nx.Graph, atom: int) -> Tuple[int, int, int]:
        el = cls._element(g, atom)
        charge = cls._charge(g, atom)
        hetero_rank = 0 if cls._is_hetero(el) else (1 if el == "C" else 2)
        neg_rank = 0 if charge < 0 else (1 if charge == 0 else 2)
        return hetero_rank, neg_rank, atom

    @classmethod
    def _bond_lp_sink_penalty(cls, g: nx.Graph, goal: nx.Graph, atom: int) -> Tuple[int, int, int]:
        el = cls._element(g, atom)
        if cls._is_hetero(el):
            return (0, 0, atom)
        if el == "C":
            allowed = cls._goal_allows_carbanion(goal, atom) or cls._resonance_stabilized_carbanion(g, atom)
            return (2, 1, atom) if allowed else (20, 6, atom)
        return (4, 1, atom)

    def _rank_bond_to_lp(
        self,
        ctx: ExpansionContext,
        transition: Transition,
    ) -> RankKey:
        g = ctx.current.graph
        goal = ctx.goal.graph
        dst = int(transition.dst[0]) if transition.dst else None
        if dst is None:
            return ()

        if self._is_carbonyl_pi_open(g, transition):
            return (0, 0, 0, dst)

        if self._is_unactivated_acyl_sigma_cleavage(g, transition):
            penalty = self._bond_lp_sink_penalty(g, goal, dst)
            return (9, 9, *penalty)

        hx = 0 if self._matches_hx_cleavage(ctx, transition) else 1
        penalty = self._bond_lp_sink_penalty(g, goal, dst)
        return (hx, *penalty)

    def _rank_lp_to_bond(
        self,
        ctx: ExpansionContext,
        transition: Transition,
    ) -> RankKey:
        g = ctx.current.graph
        src = int(transition.src[0])
        donor_rank = self._lp_donor_class(g, src)
        capture = 0 if self._matches_anion_capture(ctx, transition) else 1

        frontier = self._frontier(ctx)
        return_atom = ctx.current.memory.get("frontier_return_atom")
        carbonyl_reclose = 1
        if (
            frontier.get("reason") == "carbonyl_pi_open"
            and frontier.get("anchor") is not None
            and return_atom is not None
        ):
            if src == int(frontier["anchor"]) and int(return_atom) in {int(a) for a in transition.dst}:
                carbonyl_reclose = 0

        proton_context = self._protonation_context(ctx)
        halide_wrong_start = 0
        if proton_context and ctx.depth == 0:
            dst_other = None
            if len(transition.dst) == 2:
                a, b = int(transition.dst[0]), int(transition.dst[1])
                dst_other = b if a == src else a if b == src else None
            if src in self._counterion_atoms(g) and dst_other is not None and self._element(g, dst_other) == "C":
                halide_wrong_start = 50

        sink_rank = self._lp_to_bond_sink_rank(g, src, transition)
        return (
            carbonyl_reclose,
            halide_wrong_start,
            capture,
            *donor_rank,
            *sink_rank,
        )

    def _lp_to_bond_sink_rank(
        self,
        g: nx.Graph,
        src: int,
        transition: Transition,
    ) -> Tuple[int, int]:
        if len(transition.dst) != 2:
            return (2, 99)

        a, b = int(transition.dst[0]), int(transition.dst[1])
        other = b if a == src else a if b == src else None
        if other is None:
            return (2, 99)

        other_el = self._element(g, other)
        other_charge = self._charge(g, other)
        return (
            (0 if (other_el == "C" and other_charge > 0) else (1 if other_charge > 0 else 2)),
            other,
        )

    def _rank_bond_to_bond(
        self,
        ctx: ExpansionContext,
        transition: Transition,
    ) -> RankKey:
        g = ctx.current.graph
        src_edge = (int(transition.src[0]), int(transition.src[1]))
        dst_edge = (int(transition.dst[0]), int(transition.dst[1]))
        proton_atoms = self._free_proton_atoms(g)
        proton_start = (
            0
            if (
                self._is_pi_edge(g, src_edge)
                and any(int(a) in proton_atoms or self._element(g, int(a)) == "H" for a in dst_edge)
            )
            else 1
        )
        pi_rank = 0 if self._is_pi_edge(g, src_edge) else 1
        return (proton_start, pi_rank, -edge_order(g, *src_edge))

    def rank_transition(self, ctx: ExpansionContext, transition: Transition) -> RankKey:
        if transition.kind == "B-/LP+":
            return self._rank_bond_to_lp(ctx, transition)

        if transition.kind == "LP-/B+" and len(transition.src) == 1:
            return self._rank_lp_to_bond(ctx, transition)

        if transition.kind == "B-/B+" and len(transition.src) == 2 and len(transition.dst) == 2:
            return self._rank_bond_to_bond(ctx, transition)

        return ()

    def rank_next_state(
        self,
        ctx: ExpansionContext,
        transition: Transition,
        next_state: StateSnapshot,
    ) -> RankKey:
        g = next_state.graph
        goal = ctx.goal.graph
        if not bool(g.graph.get("prefer_ionic_intermediates", True)):
            return ()

        workspace = [int(n) for n in g.graph.get("workspace_nodes", g.nodes()) if n in g]
        pos_hetero = 0
        neg_hetero = 0
        pos_c = 0
        neg_c_unstable = 0
        for atom in workspace:
            charge = self._charge(g, atom)
            el = self._element(g, atom)
            if charge > 0:
                if el == "C":
                    pos_c += 1
                elif self._is_hetero(el):
                    pos_hetero += 1
            elif charge < 0:
                if self._is_hetero(el):
                    neg_hetero += 1
                elif el == "C":
                    if not (self._goal_allows_carbanion(goal, atom) or self._resonance_stabilized_carbanion(g, atom)):
                        neg_c_unstable += 1
        ionic_pair_bonus = 0 if (pos_c > 0 and neg_hetero > 0) else 1
        return (pos_hetero, neg_c_unstable, ionic_pair_bonus, abs(pos_c - neg_hetero))
