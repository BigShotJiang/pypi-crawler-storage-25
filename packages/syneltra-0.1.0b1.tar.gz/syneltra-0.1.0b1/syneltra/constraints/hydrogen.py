from __future__ import annotations

from typing import List, Set

import networkx as nx

from ..chemistry.graph import atom_element, edge_order, get_h
from ..core.models import ExpansionContext, StateSnapshot, Transition
from .base import BaseConstraint, RankKey


class HydrogenFlowConstraint(BaseConstraint):
    """Enforce that any ``H-/*`` step must be preceded by enough earlier ``*/H+`` steps.

    For explicit H-H bonds in the workspace, only ``B-/B+`` transitions that
    move electrons along the H-H bond are permitted.  H-H atoms are detected
    directly from the current graph rather than from pre-computed metadata.
    """

    name = "hydrogen_flow"

    @classmethod
    def _atom_is_hh(cls, g: nx.Graph, atom: int) -> bool:
        """Return True if ``atom`` (element H) currently has any H-H bond."""
        atom = int(atom)
        if atom not in g or atom_element(g, atom) != "H":
            return False
        return any(
            atom_element(g, int(nbr)) == "H" and edge_order(g, atom, int(nbr)) > 1e-8 for nbr in g.neighbors(atom)
        )

    @classmethod
    def _touches_hh_atom(cls, ctx: ExpansionContext, transition: Transition) -> bool:
        g = ctx.current.graph
        touched = {int(a) for a in transition.src} | {int(a) for a in transition.dst}
        return any(cls._atom_is_hh(g, a) for a in touched)

    @classmethod
    def _is_hh_bond_flow(cls, ctx: ExpansionContext, transition: Transition) -> bool:
        if transition.kind != "B-/B+":
            return False
        g = ctx.current.graph
        src = {int(a) for a in transition.src}
        dst = {int(a) for a in transition.dst}
        return all(cls._atom_is_hh(g, a) for a in src) or any(cls._atom_is_hh(g, a) for a in dst)

    @classmethod
    def _is_hh_proton_source_cleavage(cls, ctx: ExpansionContext, transition: Transition) -> bool:
        if transition.kind != "B-/LP+":
            return False
        if len(transition.src) != 2 or len(transition.dst) != 1:
            return False
        g = ctx.current.graph
        sink = int(transition.dst[0])
        src = tuple(int(a) for a in transition.src)
        if sink not in src or atom_element(g, sink) == "H":
            return False
        other = src[0] if src[1] == sink else src[1]
        return cls._atom_is_hh(g, other)

    @staticmethod
    def _hplus_count(history: List[Transition]) -> int:
        return sum(1 for t in history if t.tail == "H+")

    @staticmethod
    def _hminus_count(history: List[Transition]) -> int:
        return sum(1 for t in history if t.head == "H-")

    def allow_transition(self, ctx: ExpansionContext, transition: Transition) -> bool:
        if self._touches_hh_atom(ctx, transition):
            return self._is_hh_bond_flow(ctx, transition) or self._is_hh_proton_source_cleavage(ctx, transition)
        if transition.head != "H-":
            return True
        return self._hplus_count(ctx.history) > self._hminus_count(ctx.history)


class HydrogenTransientConstraint(BaseConstraint):
    """Allow one transient ``|hcount - goal_hcount| > 1`` state, but force the next arrow to resolve it."""

    name = "hydrogen_transient"

    @staticmethod
    def _overshot_atoms(cur: nx.Graph, goal: nx.Graph) -> Set[int]:
        atoms: Set[int] = set()
        if bool(cur.graph.get("ignore_hcount_in_signature", False)):
            return atoms
        workspace = set(int(n) for n in cur.graph.get("workspace_nodes", cur.nodes()) if n in cur and n in goal)
        for n in workspace:
            if abs(get_h(cur, n) - get_h(goal, n)) > 1:
                atoms.add(int(n))
        return atoms

    def allow_next_state(
        self,
        ctx: ExpansionContext,
        transition: Transition,
        next_state: StateSnapshot,
    ) -> bool:
        current_bad = self._overshot_atoms(ctx.current.graph, ctx.goal.graph)
        next_bad = self._overshot_atoms(next_state.graph, ctx.goal.graph)
        if not current_bad:
            return True
        return not next_bad

    def rank_next_state(
        self,
        ctx: ExpansionContext,
        transition: Transition,
        next_state: StateSnapshot,
    ) -> RankKey:
        current_bad = self._overshot_atoms(ctx.current.graph, ctx.goal.graph)
        next_bad = self._overshot_atoms(next_state.graph, ctx.goal.graph)
        if current_bad:
            return (0 if not next_bad else 1, len(next_bad))
        return (0 if not next_bad else 1, len(next_bad))
