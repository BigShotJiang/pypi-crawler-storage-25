from __future__ import annotations

from abc import ABC
from typing import Tuple

from ..core.models import ExpansionContext, StateSnapshot, Transition

RankKey = Tuple


class BaseConstraint(ABC):
    """
    Base class for pluggable search constraints.

    Notes
    -----
    Constraints can do four things:

    1. hard-filter a candidate before application
    2. hard-filter the resulting state after application
    3. rank a candidate before application
    4. rank a resulting state after application
    """

    name: str = "constraint"

    def allow_transition(
        self,
        ctx: ExpansionContext,
        transition: Transition,
    ) -> bool:
        return True

    def allow_next_state(
        self,
        ctx: ExpansionContext,
        transition: Transition,
        next_state: StateSnapshot,
    ) -> bool:
        return True

    def rank_transition(
        self,
        ctx: ExpansionContext,
        transition: Transition,
    ) -> RankKey:
        return ()

    def rank_next_state(
        self,
        ctx: ExpansionContext,
        transition: Transition,
        next_state: StateSnapshot,
    ) -> RankKey:
        return ()
