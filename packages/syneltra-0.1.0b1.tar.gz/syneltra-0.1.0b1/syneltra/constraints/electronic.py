from __future__ import annotations

from typing import Tuple

from ..core.models import ExpansionContext, Transition
from ..scoring import ElectronicTransitionScorer
from .base import BaseConstraint, RankKey


class ElectronicGuidanceConstraint(BaseConstraint):
    """Refine candidate ordering with an FMO/Hückel-inspired score."""

    name = "electronic_guidance"

    @staticmethod
    def _stable_tiebreak(transition: Transition) -> Tuple[int, ...]:
        atoms = tuple(sorted(int(a) for a in (*transition.src, *transition.dst)))
        return atoms

    def rank_transition(self, ctx: ExpansionContext, transition: Transition) -> RankKey:
        g = ctx.current.graph
        if not bool(g.graph.get("electronic_guidance", True)):
            return ()
        mode = str(g.graph.get("electronic_mode", "consensus")).lower()
        if mode in {"none", "off", "false"}:
            return ()
        if transition.kind not in {"LP-/B+", "B-/B+", "B-/LP+", "LP-/H+", "H-/LP+"}:
            return ()
        scorer = ElectronicTransitionScorer(g, mode=mode)
        score = scorer.score_transition(transition)
        return (-round(float(score), 6), *self._stable_tiebreak(transition))
