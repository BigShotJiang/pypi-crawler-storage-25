from __future__ import annotations

from typing import Optional, Set, Tuple

import networkx as nx

from ..chemistry.graph import atom_element, edge_order, get_charge, possible_edge_keys
from ..core.models import ExpansionContext, Transition
from .base import BaseConstraint, RankKey


class InitialStepConstraint(BaseConstraint):
    """Family-aware first-step policy for the practical three-action grammar."""

    name = "initial_step"

    @staticmethod
    def _element(g: nx.Graph, atom: int) -> str:
        return atom_element(g, int(atom))

    @staticmethod
    def _is_halogen(el: str) -> bool:
        return el in {"F", "CL", "BR", "I"}

    @staticmethod
    def _is_hetero_donor(el: str) -> bool:
        return el in {"N", "O", "S", "P", "F", "CL", "BR", "I"}

    @staticmethod
    def _bond_order(g: nx.Graph, edge: Tuple[int, int]) -> float:
        return edge_order(g, int(edge[0]), int(edge[1]))

    @classmethod
    def _is_pi_bond(cls, g: nx.Graph, edge: Tuple[int, int]) -> bool:
        order = cls._bond_order(g, edge)
        if order >= 2.0 or abs(order - 1.5) < 1e-8:
            return True
        if g.has_edge(*edge):
            bond_type = str(g.edges[edge].get("bond_type", "")).upper()
            return bond_type in {"DOUBLE", "TRIPLE", "AROMATIC"}
        return False

    @staticmethod
    def _other_endpoint(edge: Tuple[int, int], atom: int) -> Optional[int]:
        u, v = int(edge[0]), int(edge[1])
        atom = int(atom)
        if u == atom:
            return v
        if v == atom:
            return u
        return None

    @classmethod
    def _is_hx_addition_context(cls, cur: nx.Graph, goal: nx.Graph) -> bool:
        broken_hx = []
        new_h_bonds = []
        consumed_unsat = []
        for u, v in possible_edge_keys(cur):
            cur_order = edge_order(cur, u, v)
            goal_order = edge_order(goal, u, v)
            if abs(cur_order - goal_order) <= 1e-8:
                continue
            eu = cls._element(cur if u in cur else goal, u)
            ev = cls._element(cur if v in cur else goal, v)
            if cur_order > goal_order:
                if eu == "H" and cls._is_halogen(ev):
                    broken_hx.append((int(u), int(v)))
                elif ev == "H" and cls._is_halogen(eu):
                    broken_hx.append((int(u), int(v)))
                elif eu != "H" and ev != "H" and cur_order >= 2.0:
                    consumed_unsat.append((int(u), int(v)))
            if goal_order > cur_order and (eu == "H" or ev == "H"):
                new_h_bonds.append((int(u), int(v)))
        return bool(broken_hx and new_h_bonds and consumed_unsat)

    @classmethod
    def _free_proton_atoms(cls, g: nx.Graph) -> Set[int]:
        out: Set[int] = set()
        for n in g.nodes():
            n = int(n)
            if cls._element(g, n) != "H":
                continue
            charge = int(g.nodes[n].get("charge", 0))
            if charge > 0 or g.degree(n) == 0:
                out.add(n)
        return out

    @classmethod
    def _atom_has_carbonyl_like_release(cls, cur: nx.Graph, goal: nx.Graph, atom: int, *, exclude: int) -> bool:
        """Return True if ``atom`` carries an unresolved C=X -> C-X decrease."""
        atom = int(atom)
        exclude = int(exclude)
        nbrs: Set[int] = set()
        if atom in cur:
            nbrs.update(int(n) for n in cur.neighbors(atom))
        if atom in goal:
            nbrs.update(int(n) for n in goal.neighbors(atom))
        for nbr in nbrs:
            if nbr == exclude:
                continue
            ref = cur if atom in cur and nbr in cur else goal
            if cls._element(ref, nbr) not in {"O", "N", "S", "SE"}:
                continue
            if edge_order(cur, atom, nbr) >= 1.8 and (edge_order(goal, atom, nbr) - edge_order(cur, atom, nbr)) < -1e-8:
                return True
        return False

    @classmethod
    def _atom_has_local_pi_release(cls, cur: nx.Graph, goal: nx.Graph, atom: int, *, exclude: int) -> bool:
        """Return True if ``atom`` has an unresolved heavy pi-bond decrease."""
        atom = int(atom)
        exclude = int(exclude)
        nbrs: Set[int] = set()
        if atom in cur:
            nbrs.update(int(n) for n in cur.neighbors(atom))
        if atom in goal:
            nbrs.update(int(n) for n in goal.neighbors(atom))
        for nbr in nbrs:
            if nbr == exclude:
                continue
            ref = cur if atom in cur and nbr in cur else goal
            if cls._element(ref, nbr) == "H":
                continue
            if edge_order(cur, atom, nbr) >= 1.8 and (edge_order(goal, atom, nbr) - edge_order(cur, atom, nbr)) < -1e-8:
                return True
        return False

    @classmethod
    def _is_pi_acceptor_nucleophile(cls, cur: nx.Graph, goal: nx.Graph, atom: int) -> bool:
        """True for an anionic/LP donor forming a bond to a pi acceptor."""
        atom = int(atom)
        if atom not in cur or atom not in goal:
            return False

        el = cls._element(cur, atom)
        if cls._is_halogen(el):
            return False

        charge = int(cur.nodes[atom].get("charge", 0))
        lone_pairs = int(cur.nodes[atom].get("lone_pairs", 0))
        if charge >= 0 and lone_pairs <= 0:
            return False

        for nbr in goal.neighbors(atom):
            nbr = int(nbr)
            if cls._element(goal, nbr) != "C":
                continue
            if edge_order(goal, atom, nbr) <= edge_order(cur, atom, nbr) + 1e-8:
                continue
            if cls._atom_has_carbonyl_like_release(cur, goal, nbr, exclude=atom):
                return True
            if cls._atom_has_local_pi_release(cur, goal, nbr, exclude=atom):
                return True
        return False

    _is_carbonyl_nucleophile = _is_pi_acceptor_nucleophile

    @classmethod
    def _counterion_atoms(cls, cur: nx.Graph, goal: nx.Graph) -> Set[int]:
        out: Set[int] = set()
        for n in cur.nodes():
            n = int(n)
            el = cls._element(cur, n)
            charge = int(cur.nodes[n].get("charge", 0))

            if el == "H":
                continue

            if cls._is_pi_acceptor_nucleophile(cur, goal, n):
                continue

            is_counter = charge < 0
            if cls._is_halogen(el) and cur.degree(n) == 0:
                is_counter = True
            if not is_counter:
                continue

            goal_new_bond = False
            if n in goal:
                for nbr in goal.neighbors(n):
                    nbr = int(nbr)
                    if cls._element(goal, nbr) == "C" and edge_order(goal, n, nbr) > edge_order(cur, n, nbr):
                        goal_new_bond = True
                        break

            if goal_new_bond or (cls._is_halogen(el) and (charge < 0 or cur.degree(n) == 0)):
                out.add(n)
        return out

    @classmethod
    def _is_counterion_protonation_context(cls, cur: nx.Graph, goal: nx.Graph) -> bool:
        consumed_unsat = False
        proton_targets: Set[int] = set()
        for u, v in possible_edge_keys(cur):
            cur_order = edge_order(cur, u, v)
            goal_order = edge_order(goal, u, v)
            if abs(cur_order - goal_order) <= 1e-8:
                continue
            eu = cls._element(cur if u in cur else goal, u)
            ev = cls._element(cur if v in cur else goal, v)
            if cur_order > goal_order and eu != "H" and ev != "H" and cur_order >= 2.0:
                consumed_unsat = True
            if goal_order > cur_order:
                if eu == "H" and int(cur.nodes[int(u)].get("charge", 0)) > 0 and ev != "H":
                    proton_targets.add(int(u))
                elif ev == "H" and int(cur.nodes[int(v)].get("charge", 0)) > 0 and eu != "H":
                    proton_targets.add(int(v))

        if not proton_targets:
            proton_targets = cls._free_proton_atoms(cur)
            proton_targets = {
                h
                for h in proton_targets
                if h in goal
                and any(
                    cls._element(goal, int(nbr)) != "H" and edge_order(goal, h, int(nbr)) > edge_order(cur, h, int(nbr))
                    for nbr in goal.neighbors(h)
                )
            }

        counterions = cls._counterion_atoms(cur, goal)
        return bool(consumed_unsat and proton_targets and counterions)

    @classmethod
    def _is_protonation_addition_context(cls, cur: nx.Graph, goal: nx.Graph) -> bool:
        return cls._is_hx_addition_context(cur, goal) or cls._is_counterion_protonation_context(cur, goal)

    @classmethod
    def _transition_matches_protonation_pi_start(
        cls, g: nx.Graph, transition: Transition, *, goal: Optional[nx.Graph] = None
    ) -> bool:
        if transition.kind != "B-/B+" or len(transition.src) != 2 or len(transition.dst) != 2:
            return False
        src_edge = (int(transition.src[0]), int(transition.src[1]))
        dst_edge = (int(transition.dst[0]), int(transition.dst[1]))
        if not cls._is_pi_bond(g, src_edge):
            return False
        h_atoms = [a for a in dst_edge if cls._element(g, a) == "H"]
        if len(h_atoms) != 1:
            return False
        h = int(h_atoms[0])
        if int(g.nodes[h].get("charge", 0)) > 0 or g.degree(h) == 0:
            return True
        if g.degree(h) == 1:
            nbr = next(iter(g.neighbors(h)))
            return cls._is_halogen(cls._element(g, int(nbr)))
        return False

    @classmethod
    def _transition_targets_carbonyl(cls, g: nx.Graph, transition: Transition) -> bool:
        if transition.kind != "LP-/B+" or len(transition.dst) != 2 or len(transition.src) != 1:
            return False
        donor = int(transition.src[0])
        donor_el = cls._element(g, donor)
        donor_charge = int(g.nodes[donor].get("charge", 0))
        donor_lp = int(g.nodes[donor].get("lone_pairs", 0))
        if not (cls._is_hetero_donor(donor_el) or (donor_el in {"H", "C"} and (donor_charge < 0 or donor_lp > 0))):
            return False
        shared = transition.data.get("shared_atom")
        if shared is None:
            return False
        shared = int(shared)
        sink = cls._other_endpoint((int(transition.dst[0]), int(transition.dst[1])), shared)
        if sink is None or cls._element(g, sink) != "C":
            return False
        for nbr in g.neighbors(sink):
            if int(nbr) == donor:
                continue
            if edge_order(g, sink, nbr) >= 2.0 and cls._element(g, int(nbr)) in {
                "O",
                "N",
                "S",
            }:
                return True
        return False

    @classmethod
    def _halide_lp_start_penalty(cls, g: nx.Graph, transition: Transition) -> int:
        if transition.kind != "LP-/B+" or len(transition.src) != 1:
            return 0
        atom = int(transition.src[0])
        el = cls._element(g, atom)
        if not cls._is_halogen(el):
            return 0
        for nbr in g.neighbors(atom):
            if cls._element(g, int(nbr)) == "H":
                return 1
        return 0

    def allow_transition(self, ctx: ExpansionContext, transition: Transition) -> bool:
        if ctx.depth != 0:
            return True
        if transition.head not in {"LP-", "B-"}:
            return False
        g = ctx.current.graph
        proton_context = self._is_protonation_addition_context(ctx.current.graph, ctx.goal.graph)
        if proton_context:
            return transition.kind == "B-/B+" and self._transition_matches_protonation_pi_start(
                g, transition, goal=ctx.goal.graph
            )
        return True

    def rank_transition(self, ctx: ExpansionContext, transition: Transition) -> RankKey:
        if ctx.depth != 0:
            return ()

        g = ctx.current.graph
        proton_context = self._is_protonation_addition_context(ctx.current.graph, ctx.goal.graph)

        if proton_context and self._transition_matches_protonation_pi_start(g, transition, goal=ctx.goal.graph):
            src_edge = (int(transition.src[0]), int(transition.src[1]))
            return (0, 0, -self._bond_order(g, src_edge), min(src_edge), max(src_edge))

        if transition.kind == "LP-/B+" and self._transition_targets_carbonyl(g, transition):
            atom = int(transition.src[0])
            charge = get_charge(g, atom)
            return (1, 0 if charge < 0 else 1, charge, atom)

        if transition.kind == "LP-/B+":
            atom = int(transition.src[0])
            charge = get_charge(g, atom)
            el = self._element(g, atom)
            halide_penalty = 5 if proton_context and self._halide_lp_start_penalty(g, transition) else 0
            donor_class = 0 if charge < 0 else (1 if self._is_hetero_donor(el) else 2)
            return (2 + halide_penalty, donor_class, charge, atom)

        if transition.kind == "B-/B+":
            u, v = (int(transition.src[0]), int(transition.src[1]))
            shared = transition.data.get("shared_atom")
            shared_penalty = 0 if shared is not None and int(shared) >= 0 else 1
            src_partner_count = int(transition.data.get("src_partner_count", 99))
            dst_partner_count = int(transition.data.get("dst_partner_count", 99))
            pi_bonus = 0 if self._is_pi_bond(g, (u, v)) else 1
            return (
                3,
                pi_bonus,
                shared_penalty,
                src_partner_count + dst_partner_count,
                -edge_order(g, u, v),
                min(u, v),
                max(u, v),
            )

        if transition.kind == "B-/LP+":
            u, v = (int(transition.src[0]), int(transition.src[1]))
            leaving = int(transition.dst[0]) if transition.dst else min(u, v)
            el = self._element(g, leaving)
            hetero_bonus = 0 if self._is_hetero_donor(el) else 1
            return (
                4,
                hetero_bonus,
                -edge_order(g, u, v),
                min(u, v),
                max(u, v),
                leaving,
            )

        return (99,)
