from __future__ import annotations

from typing import Optional

from ..core.config import MechanismSearchConfig
from .chemistry import PolarChemistryConstraint
from .electronic import ElectronicGuidanceConstraint
from .electron_flow import ElectronFlowConstraint
from .grammar import PolarGrammarConstraint
from .hydrogen import HydrogenFlowConstraint, HydrogenTransientConstraint
from .initial import InitialStepConstraint
from .local_instability import LocalInstabilityConstraint
from .plans import ArrowPlanConstraint, BondOnlyConstraint, ITSWalkConstraint
from .ranking import (
    ContextProposalPriorityConstraint,
    GenericContextGuidanceConstraint,
    PolarEditPriorityConstraint,
)
from .reaction_center import RCBondAnchorConstraint
from .registry import ConstraintRegistry


def default_constraints(
    config: Optional[MechanismSearchConfig] = None,
) -> ConstraintRegistry:
    """Return the default constraint registry."""
    cfg = config or MechanismSearchConfig()
    constraints = [
        PolarGrammarConstraint(),
        PolarEditPriorityConstraint(),
        InitialStepConstraint(),
        HydrogenFlowConstraint(),
        ContextProposalPriorityConstraint(),
        RCBondAnchorConstraint(),
        ArrowPlanConstraint(),
        ITSWalkConstraint(),
        BondOnlyConstraint(),
        ElectronFlowConstraint(require_touch=False),
        PolarChemistryConstraint(),
        GenericContextGuidanceConstraint(),
        ElectronicGuidanceConstraint(),
        HydrogenTransientConstraint(),
        LocalInstabilityConstraint(
            only_new=True,
            require_touch=False,
            require_improvement=False,
        ),
    ]
    if not cfg.use_online_ranker:
        constraints = [
            c
            for c in constraints
            if c.name
            not in {
                "initial_step",
                "electron_flow",
                "local_instability",
                "polar_chemistry",
                "electronic_guidance",
                "generic_context_guidance",
            }
        ]
    return ConstraintRegistry(constraints=constraints)
