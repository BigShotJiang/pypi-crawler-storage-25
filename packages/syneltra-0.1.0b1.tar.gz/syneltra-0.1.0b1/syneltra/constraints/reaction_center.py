from __future__ import annotations

from typing import List, Set, Tuple

import networkx as nx

from ..chemistry.graph import edge_order, possible_edge_keys
from ..core.models import ExpansionContext, Transition
from .base import BaseConstraint, RankKey
from .electron_flow import transition_touched_atoms


class RCBondAnchorConstraint(BaseConstraint):
    """Keep mixed RC mechanisms anchored on outstanding bond deltas."""

    name = "rc_bond_anchor"

    @staticmethod
    def _outstanding_bond_edges(cur: nx.Graph, goal: nx.Graph) -> Set[Tuple[int, int]]:
        edges: Set[Tuple[int, int]] = set()
        for u, v in possible_edge_keys(cur):
            if abs(edge_order(cur, u, v) - edge_order(goal, u, v)) > 1e-8:
                edges.add(tuple(sorted((int(u), int(v)))))
        return edges

    def _touches_outstanding_bond(
        self,
        ctx: ExpansionContext,
        transition: Transition,
    ) -> bool:
        outstanding = self._outstanding_bond_edges(ctx.current.graph, ctx.goal.graph)
        if not outstanding:
            return False
        edges: Set[Tuple[int, int]] = set()
        if transition.kind in {"LP-/B+", "H-/B+"} and len(transition.dst) == 2:
            edges.add(tuple(sorted((int(transition.dst[0]), int(transition.dst[1])))))
        elif transition.kind == "B-/LP+" and len(transition.src) == 2:
            edges.add(tuple(sorted((int(transition.src[0]), int(transition.src[1])))))
        elif transition.kind == "B-/B+":
            if len(transition.src) == 2:
                edges.add(tuple(sorted((int(transition.src[0]), int(transition.src[1])))))
            if len(transition.dst) == 2:
                edges.add(tuple(sorted((int(transition.dst[0]), int(transition.dst[1])))))
        return bool(edges & outstanding)

    @staticmethod
    def _has_prior_bond_anchor(history: List[Transition]) -> bool:
        return any(t.kind in {"LP-/B+", "B-/LP+", "B-/B+", "H-/B+"} for t in history)

    def _touches_outstanding_bond_atoms(
        self,
        ctx: ExpansionContext,
        transition: Transition,
    ) -> bool:
        outstanding = self._outstanding_bond_edges(ctx.current.graph, ctx.goal.graph)
        if not outstanding:
            return False
        outstanding_atoms = {int(a) for edge in outstanding for a in edge}
        return bool(transition_touched_atoms(transition) & outstanding_atoms)

    def allow_transition(self, ctx: ExpansionContext, transition: Transition) -> bool:
        outstanding = self._outstanding_bond_edges(ctx.current.graph, ctx.goal.graph)
        if not outstanding:
            return True
        if self._touches_outstanding_bond(ctx, transition):
            return True
        if self._has_prior_bond_anchor(ctx.history):
            return True
        if transition.kind in {
            "LP-/H+",
            "H-/LP+",
        } and self._touches_outstanding_bond_atoms(ctx, transition):
            return True
        if transition.data.get("proposal_origin") == "auxiliary" and self._touches_outstanding_bond_atoms(
            ctx, transition
        ):
            return True
        return False

    def rank_transition(self, ctx: ExpansionContext, transition: Transition) -> RankKey:
        outstanding = self._outstanding_bond_edges(ctx.current.graph, ctx.goal.graph)
        if not outstanding:
            return ()
        direct_touch = self._touches_outstanding_bond(ctx, transition)
        atom_touch = self._touches_outstanding_bond_atoms(ctx, transition)
        touch = 0 if direct_touch else (1 if atom_touch else 2)
        pure_h = 1 if transition.kind in {"LP-/H+", "H-/LP+"} else 0
        return (touch, pure_h)
