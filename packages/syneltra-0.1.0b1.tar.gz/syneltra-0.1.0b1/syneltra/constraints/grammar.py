from __future__ import annotations

from typing import Tuple

import networkx as nx

from ..chemistry.graph import atom_element, edge_order
from ..core.models import ExpansionContext, Transition
from .base import BaseConstraint
from .ranking import PolarEditPriorityConstraint


class PolarGrammarConstraint(BaseConstraint):
    """Hard generic polar grammar filters.

    - B-/B+ can involve explicit H only when it follows an endpoint-directed
      bond-flow delta.  H-H bonds are detected directly from the graph; no
      pre-computed metadata is required.
    - Polar heterolysis of a C--hetero bond returns the electron pair to the
      more electronegative side.
    """

    name = "polar_grammar"
    _EN = PolarEditPriorityConstraint._EN

    @staticmethod
    def _element(g: nx.Graph, atom: int) -> str:
        return atom_element(g, int(atom))

    @classmethod
    def _is_h(cls, g: nx.Graph, atom: int) -> bool:
        return cls._element(g, int(atom)) == "H"

    @classmethod
    def _en(cls, g: nx.Graph, atom: int) -> float:
        return cls._EN.get(cls._element(g, int(atom)), 2.5)

    @classmethod
    def _h_atoms(cls, cur: nx.Graph, goal: nx.Graph, atoms) -> Tuple[int, ...]:
        out = []
        for atom in atoms:
            atom = int(atom)
            if cls._is_h(cur if atom in cur else goal, atom):
                out.append(atom)
        return tuple(out)

    @classmethod
    def _is_hh_bond(cls, cur: nx.Graph, goal: nx.Graph, u: int, v: int) -> bool:
        return cls._is_h(cur if u in cur else goal, u) and cls._is_h(cur if v in cur else goal, v)

    @classmethod
    def _h_has_hh_neighbor(cls, g: nx.Graph, atom: int) -> bool:
        """Return True if H atom currently has any H-H bond in g."""
        if atom not in g:
            return False
        for nbr in g.neighbors(atom):
            if cls._is_h(g, int(nbr)) and edge_order(g, atom, int(nbr)) > 1e-8:
                return True
        return False

    def _allow_explicit_h_bond_to_bond(
        self,
        cur: nx.Graph,
        goal: nx.Graph,
        su: int,
        sv: int,
        du: int,
        dv: int,
    ) -> bool:
        src_delta = edge_order(goal, su, sv) - edge_order(cur, su, sv)
        dst_delta = edge_order(goal, du, dv) - edge_order(cur, du, dv)

        if self._is_hh_bond(cur, goal, su, sv):
            # H-H source: allow only if this bond is being broken and dst gains
            return src_delta < -1e-8 and dst_delta > 1e-8

        src_h = set(self._h_atoms(cur, goal, (su, sv)))

        if src_h == {int(su), int(sv)}:
            # Both src atoms are H but not an H-H bond — reject
            return False

        return src_delta < -1e-8 and dst_delta > 1e-8

    def allow_transition(self, ctx: ExpansionContext, transition: Transition) -> bool:
        cur = ctx.current.graph
        goal = ctx.goal.graph

        if transition.kind == "B-/B+" and len(transition.src) == 2 and len(transition.dst) == 2:
            su, sv = int(transition.src[0]), int(transition.src[1])
            du, dv = int(transition.dst[0]), int(transition.dst[1])
            src_has_h = self._is_h(cur if su in cur else goal, su) or self._is_h(cur if sv in cur else goal, sv)
            dst_has_h = self._is_h(cur if du in cur else goal, du) or self._is_h(cur if dv in cur else goal, dv)
            if src_has_h or dst_has_h:
                return self._allow_explicit_h_bond_to_bond(cur, goal, su, sv, du, dv)

        if transition.kind == "B-/LP+" and len(transition.src) == 2 and len(transition.dst) == 1:
            u, v = int(transition.src[0]), int(transition.src[1])
            sink = int(transition.dst[0])
            if edge_order(cur, u, v) <= edge_order(goal, u, v) + 1e-8:
                return True
            if self._is_h(cur if u in cur else goal, u) or self._is_h(cur if v in cur else goal, v):
                h = u if self._is_h(cur if u in cur else goal, u) else v
                return sink != h
            eu = self._element(cur if u in cur else goal, u)
            ev = self._element(cur if v in cur else goal, v)
            if "C" in {eu, ev} and eu != ev:
                expected = u if self._en(cur if u in cur else goal, u) >= self._en(cur if v in cur else goal, v) else v
                return sink == expected
        return True
