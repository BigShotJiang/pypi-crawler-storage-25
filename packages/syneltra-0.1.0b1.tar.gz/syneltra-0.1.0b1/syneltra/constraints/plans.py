from __future__ import annotations

from typing import List, Tuple

from ..core.models import ExpansionContext, Transition
from ..core.plan_utils import (
    history_transition_keys,
    next_compatible_encoded_plans,
    plan_boundary_after_step,
    transition_key,
)

from .base import BaseConstraint, RankKey


class ArrowPlanConstraint(BaseConstraint):
    """Enforce exact micro-step prefixes from precomputed arrow plans."""

    name = "arrow_plan"

    def _plans(self, ctx: ExpansionContext):
        return list(ctx.current.graph.graph.get("arrow_plans", ()))

    def allow_transition(self, ctx: ExpansionContext, transition: Transition) -> bool:
        plans = self._plans(ctx)
        if not plans:
            return True
        if not bool(ctx.current.graph.graph.get("enforce_arrow_plans", False)):
            return True
        prefix = history_transition_keys(ctx.history)
        candidate = transition_key(transition)
        return bool(next_compatible_encoded_plans(prefix, candidate, plans))

    def rank_transition(self, ctx: ExpansionContext, transition: Transition) -> RankKey:
        plans = self._plans(ctx)
        if not plans:
            return ()
        prefix = history_transition_keys(ctx.history)
        candidate = transition_key(transition)
        matches = next_compatible_encoded_plans(prefix, candidate, plans)
        matched = 0 if matches else 1
        step_idx = len(prefix) + 1
        boundary = 0 if any(plan_boundary_after_step(plan, step_idx) for plan in matches) else 1
        remaining = min(
            (len([step for arrow in plan for step in arrow]) - step_idx for plan in matches),
            default=999,
        )
        return (matched, boundary, remaining)


class ITSWalkConstraint(BaseConstraint):
    """Restrict ``B-/B+`` search to ITS-derived alternating walk plans."""

    name = "its_walk"

    def _plans(self, ctx: ExpansionContext) -> List[Tuple[Tuple[Tuple[int, int], Tuple[int, int]], ...]]:
        raw = ctx.current.graph.graph.get("its_walk_plans", ())
        out = []
        for plan in raw:
            try:
                # Normalize each undirected bond edge so plan matching is robust
                # against (u, v) vs (v, u) ordering.
                norm = tuple(
                    (
                        tuple(sorted((int(step[0][0]), int(step[0][1])))),
                        tuple(sorted((int(step[1][0]), int(step[1][1])))),
                    )
                    for step in plan
                )
            except Exception:
                continue
            out.append(norm)
        return out

    def _bond_history(self, ctx: ExpansionContext) -> List[Tuple[Tuple[int, int], Tuple[int, int]]]:
        out = []
        for tr in ctx.history:
            if tr.kind != "B-/B+":
                continue
            if len(tr.src) != 2 or len(tr.dst) != 2:
                continue
            out.append(
                (
                    tuple(sorted((int(tr.src[0]), int(tr.src[1])))),
                    tuple(sorted((int(tr.dst[0]), int(tr.dst[1])))),
                )
            )
        return out

    def _compatible_plans(self, ctx: ExpansionContext) -> List[Tuple[Tuple[Tuple[int, int], Tuple[int, int]], ...]]:
        plans = self._plans(ctx)
        if not plans:
            return []
        prefix = self._bond_history(ctx)
        if not prefix:
            return plans
        out = []
        for plan in plans:
            if len(plan) < len(prefix):
                continue
            if list(plan[: len(prefix)]) == prefix:
                out.append(plan)
        return out

    def _candidate(self, transition: Transition) -> Tuple[Tuple[int, int], Tuple[int, int]]:
        return (
            tuple(sorted((int(transition.src[0]), int(transition.src[1])))),
            tuple(sorted((int(transition.dst[0]), int(transition.dst[1])))),
        )

    def _matches_next_plan_step(
        self,
        plans: List[Tuple[Tuple[Tuple[int, int], Tuple[int, int]], ...]],
        step_idx: int,
        candidate: Tuple[Tuple[int, int], Tuple[int, int]],
    ) -> bool:
        return any(len(plan) > step_idx and plan[step_idx] == candidate for plan in plans)

    def allow_transition(self, ctx: ExpansionContext, transition: Transition) -> bool:
        all_plans = self._plans(ctx)
        plans = self._compatible_plans(ctx)

        if not all_plans:
            return True

        # Default preserves the old fail-open behavior. Set fail_closed/enforce
        # flags when ITS walks should be strict.
        if not plans:
            return not bool(ctx.current.graph.graph.get("fail_closed_its_walks", False))

        if transition.kind != "B-/B+":
            return not bool(ctx.current.graph.graph.get("bond_only_mode", False))

        step_idx = len(self._bond_history(ctx))
        candidate = self._candidate(transition)
        matched = self._matches_next_plan_step(plans, step_idx, candidate)

        if bool(ctx.current.graph.graph.get("enforce_its_walks", True)):
            return matched
        return True

    def rank_transition(self, ctx: ExpansionContext, transition: Transition) -> RankKey:
        plans = self._compatible_plans(ctx)
        if not plans or transition.kind != "B-/B+":
            return ()
        step_idx = len(self._bond_history(ctx))
        candidate = self._candidate(transition)
        matched = 0 if self._matches_next_plan_step(plans, step_idx, candidate) else 1
        remaining = min(
            (len(plan) - step_idx for plan in plans if len(plan) > step_idx and plan[step_idx] == candidate),
            default=999,
        )
        return (matched, remaining)


class BondOnlyConstraint(BaseConstraint):
    """Optionally restrict the search to pure ``B-/B+`` steps."""

    name = "bond_only"

    def allow_transition(self, ctx: ExpansionContext, transition: Transition) -> bool:
        if not bool(ctx.current.graph.graph.get("bond_only_mode", False)):
            return True
        return transition.kind == "B-/B+"
