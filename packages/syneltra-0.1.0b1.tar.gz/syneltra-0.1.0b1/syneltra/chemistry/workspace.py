from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Literal, Optional, Set, Tuple

import networkx as nx

from .graph import canonical_edge

WorkspaceMode = Literal["reactant", "product", "union"]


@dataclass(frozen=True)
class WorkspaceSpec:
    """
    Search workspace derived from a minimal RC plus optional resonance context.

    Parameters
    ----------
    nodes:
        Workspace node set.
    edge_universe:
        Allowed undirected edge universe.
    rc_nodes:
        Minimal RC node set.
    rc_edges:
        Minimal RC edge set.
    node_roles:
        Mapping ``node -> 'rc' | 'context'``.
    edge_roles:
        Mapping ``edge -> 'rc' | 'context'``.
    """

    nodes: Set[int]
    edge_universe: Set[Tuple[int, int]]
    rc_nodes: Set[int]
    rc_edges: Set[Tuple[int, int]]
    node_roles: Dict[int, str]
    edge_roles: Dict[Tuple[int, int], str]


class RCWorkspaceBuilder:
    """
    Expand a minimal RC into a local mechanistic workspace.

    Notes
    -----
    - ``rc_graph`` defines the minimal changed core.
    - ``reactant_graph`` and ``product_graph`` define the real chemistry.
    - with ``k=0``, topology is RC-only plus immediately required polar-relief
      multiple bonds such as an adjacent C=O next to an acyl reaction center.
    - with ``k>0``, only *resonance-relevant* context is added.

    Resonance-relevant context is intentionally conservative. By default, a
    context edge contributes only if it is part of a conjugated or unsaturated
    system, e.g. aromatic, double, triple, or explicitly conjugated.
    """

    @staticmethod
    def _edge_order(attrs: dict) -> float:
        try:
            return float(attrs.get("order", attrs.get("kekule_order", 0.0)))
        except Exception:
            return 0.0

    @classmethod
    def _is_resonance_edge(cls, attrs: dict) -> bool:
        order = cls._edge_order(attrs)
        bond_type = str(attrs.get("bond_type", "") or "").upper()
        conjugated = bool(attrs.get("conjugated", False))
        return conjugated or abs(order - 1.5) < 1e-8 or order >= 2.0 or bond_type in {"DOUBLE", "TRIPLE", "AROMATIC"}

    @staticmethod
    def _element(graph: nx.Graph, node: int) -> str:
        try:
            value = graph.nodes[int(node)].get("element", "")
            if isinstance(value, (tuple, list)) and value:
                value = value[0]
            return str(value).strip().upper()
        except Exception:
            return ""

    @classmethod
    def _is_aromatic_resonance_edge(
        cls,
        graph: nx.Graph,
        u: int,
        v: int,
        attrs: dict,
    ) -> bool:
        order = cls._edge_order(attrs)
        bond_type = str(attrs.get("bond_type", "") or "").upper()
        if abs(order - 1.5) < 1e-8 or bond_type == "AROMATIC":
            return True
        return (
            bool(attrs.get("in_ring", False))
            and cls._element(graph, int(u)) != "H"
            and cls._element(graph, int(v)) != "H"
            and bool(graph.nodes[int(u)].get("aromatic", False))
            and bool(graph.nodes[int(v)].get("aromatic", False))
        )

    @classmethod
    def _is_resonance_bond(
        cls,
        graph: nx.Graph,
        u: int,
        v: int,
        attrs: dict,
    ) -> bool:
        return cls._is_resonance_edge(attrs) or cls._is_aromatic_resonance_edge(
            graph,
            int(u),
            int(v),
            attrs,
        )

    @classmethod
    def _is_polar_relief_multiple_bond(cls, graph: nx.Graph, u: int, v: int, attrs: dict) -> bool:
        """Return True for adjacent C=hetero relief bonds such as C=O.

        These bonds may be unchanged in the net endpoints but are chemically
        required to relieve an overfilled electrophilic center after LP attack.
        """
        order = cls._edge_order(attrs)
        if order < 1.8:
            return False
        elems = {cls._element(graph, int(u)), cls._element(graph, int(v))}
        return "C" in elems and bool(elems & {"O", "N", "S"})

    @classmethod
    def _khop_expand_resonance(
        cls,
        seeds: Set[int],
        graph: nx.Graph,
        k: int,
    ) -> Set[int]:
        """Return the inclusive resonance-only ``k``-hop expansion."""
        if k <= 0:
            return set(seeds)

        out = set(int(n) for n in seeds)
        frontier = set(int(n) for n in seeds)
        for _ in range(int(k)):
            nxt: Set[int] = set()
            for n in frontier:
                if n not in graph:
                    continue
                for nbr in graph.neighbors(n):
                    attrs = graph.edges[n, nbr]
                    if cls._is_resonance_bond(graph, int(n), int(nbr), attrs):
                        nxt.add(int(nbr))
            nxt -= out
            if not nxt:
                break
            out |= nxt
            frontier = nxt
        return out

    @staticmethod
    def _graphs_for_mode(
        reactant_graph: nx.Graph,
        product_graph: Optional[nx.Graph],
        mode: WorkspaceMode,
        include_product_context: bool,
    ) -> list[nx.Graph]:
        if mode == "reactant":
            graphs = [reactant_graph]
            if include_product_context and product_graph is not None:
                graphs.append(product_graph)
            return graphs

        if mode == "product":
            return [product_graph] if product_graph is not None else [reactant_graph]

        graphs = [reactant_graph]
        if product_graph is not None:
            graphs.append(product_graph)
        return graphs

    def expand_from_rc(
        self,
        rc_graph: nx.Graph,
        reactant_graph: nx.Graph,
        product_graph: Optional[nx.Graph] = None,
        k: int = 0,
        mode: WorkspaceMode = "reactant",
        include_product_context: bool = False,
    ) -> WorkspaceSpec:
        rc_nodes = {int(n) for n in rc_graph.nodes()}
        rc_edges = {canonical_edge(int(u), int(v)) for u, v in rc_graph.edges()}

        graphs = self._graphs_for_mode(
            reactant_graph=reactant_graph,
            product_graph=product_graph,
            mode=mode,
            include_product_context=include_product_context,
        )

        nodes = set(rc_nodes)

        # Essential polar context: acyl/carbonyl substitutions often have a net
        # unchanged C=O bond adjacent to the RC.  The mechanism still needs that
        # bond for temporary pi opening/reclosure.  Include only immediate
        # C=hetero multiple bonds attached to RC nodes, so k=0 remains compact
        # but no longer dead-ends on carbonyl clearance.
        essential_context_edges: Set[Tuple[int, int]] = set()
        for g in graphs:
            for u, v, attrs in g.edges(data=True):
                u = int(u)
                v = int(v)
                if not ({u, v} & rc_nodes):
                    continue
                if self._is_polar_relief_multiple_bond(g, u, v, dict(attrs)):
                    edge = canonical_edge(u, v)
                    essential_context_edges.add(edge)
                    nodes.update(edge)

        if k > 0:
            for g in graphs:
                nodes |= self._khop_expand_resonance(rc_nodes, g, k)

        edge_universe: Set[Tuple[int, int]] = set(rc_edges) | set(essential_context_edges)
        if k > 0:
            for g in graphs:
                for u, v, attrs in g.edges(data=True):
                    u = int(u)
                    v = int(v)
                    if u not in nodes or v not in nodes:
                        continue
                    if self._is_resonance_bond(g, u, v, dict(attrs)):
                        edge_universe.add(canonical_edge(u, v))

        node_roles = {n: ("rc" if n in rc_nodes else "context") for n in nodes}
        edge_roles = {e: ("rc" if e in rc_edges else "context") for e in edge_universe}

        return WorkspaceSpec(
            nodes=nodes,
            edge_universe=edge_universe,
            rc_nodes=rc_nodes,
            rc_edges=rc_edges,
            node_roles=node_roles,
            edge_roles=edge_roles,
        )
