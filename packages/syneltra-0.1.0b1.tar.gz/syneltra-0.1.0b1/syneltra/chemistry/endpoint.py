from __future__ import annotations

from typing import Optional, Tuple
import copy

import networkx as nx

from .graph import (
    DEFAULT_EDGE_TEMPLATE,
    register_edge_template,
    canonical_edge,
    normalize_edge_attrs,
)
from ..core.models import StateSnapshot
from .workspace import RCWorkspaceBuilder, WorkspaceMode, WorkspaceSpec


def _select_side_attr_value(value, side_index: int):
    """Select reactant/product component from SynKit ITS tuple attrs."""
    if isinstance(value, tuple) and len(value) == 2:
        return copy.deepcopy(value[int(side_index)])
    return copy.deepcopy(value)


def normalize_side_graph_attrs(graph: nx.Graph, side_index: int) -> nx.Graph:
    """Return a graph whose tuple-valued ITS attrs are side-specific scalars.

    SynKit reverter outputs are usually already side-specific, but some
    versions preserve ITS tuples such as ``element=("C", "C")`` or
    ``order=(2.0, 1.0)``.  Search constraints need scalar side attributes.
    """
    g = copy.deepcopy(graph)
    for _n, data in g.nodes(data=True):
        for key, value in list(data.items()):
            data[key] = _select_side_attr_value(value, side_index)
    for _u, _v, data in g.edges(data=True):
        for key, value in list(data.items()):
            data[key] = _select_side_attr_value(value, side_index)
    return g


def _element(graph: nx.Graph, node: int) -> str:
    try:
        return str(graph.nodes[int(node)].get("element", "")).strip().upper()
    except Exception:
        return ""


def _repair_placeholder_atoms_from_reference(side_graph: nx.Graph, reference_graph: nx.Graph) -> None:
    """Fill product/reactant-only placeholder atoms from the opposite endpoint.

    SynKit may materialize mapped atoms absent on one side as ``*`` placeholders.
    Search still needs the chemical identity of those explicit atoms, especially
    for product-only water/oxygen/hydrogen atoms used in multi-step probes.
    """
    for node in list(side_graph.nodes()):
        node = int(node)
        if node not in reference_graph:
            continue
        if _element(side_graph, node) not in {"", "*"}:
            continue
        preserved = dict(side_graph.nodes[node])
        repaired = copy.deepcopy(reference_graph.nodes[node])
        repaired.update({key: value for key, value in preserved.items() if key in {"rc", "workspace_role"}})
        repaired["atom_map"] = int(node)
        repaired["_placeholder_repaired"] = True
        side_graph.nodes[node].clear()
        side_graph.nodes[node].update(repaired)


def _single_bond_attrs() -> dict:
    return normalize_edge_attrs(
        {
            "order": 1.0,
            "kekule_order": 1.0,
            "bond_type": "SINGLE",
            "conjugated": False,
            "in_ring": False,
        }
    )


def _infer_product_only_water_reagent(  # noqa: C901
    reactant_graph: nx.Graph, product_graph: nx.Graph, rc_graph: nx.Graph
) -> None:
    """Materialize omitted mapped water when products consume its O/H atoms.

    Some benchmark RSMI strings omit reagent water on the reactant side while
    still mapping its O/H atoms into products.  If a repaired product-only O is
    free in the reactant endpoint and two repaired product-only H atoms become
    H--halogen bonds in the product endpoint, represent the missing reagent as
    H--O--H so bond-flow arrows can use those source bonds.
    """
    halogens = {"F", "CL", "BR", "I"}
    h_atoms = []
    for h in reactant_graph.nodes():
        h = int(h)
        if _element(reactant_graph, h) != "H":
            continue
        if not reactant_graph.nodes[h].get("_placeholder_repaired", False):
            continue
        if reactant_graph.degree(h) != 0:
            continue
        if h not in product_graph or product_graph.degree(h) != 1:
            continue
        nbr = next(iter(product_graph.neighbors(h)))
        if _element(product_graph, int(nbr)) in halogens:
            h_atoms.append(h)

    if len(h_atoms) < 2:
        return

    for oxygen in sorted(int(n) for n in reactant_graph.nodes()):
        if _element(reactant_graph, oxygen) != "O":
            continue
        if not reactant_graph.nodes[oxygen].get("_placeholder_repaired", False):
            continue
        if reactant_graph.degree(oxygen) != 0:
            continue

        chosen = sorted(h_atoms)[:2]
        for h in chosen:
            attrs = _single_bond_attrs()
            reactant_graph.add_edge(oxygen, h, **copy.deepcopy(attrs))
            if oxygen not in rc_graph:
                rc_graph.add_node(oxygen, **copy.deepcopy(reactant_graph.nodes[oxygen]))
            if h not in rc_graph:
                rc_graph.add_node(h, **copy.deepcopy(reactant_graph.nodes[h]))
            rc_graph.add_edge(oxygen, h, **copy.deepcopy(attrs))
        for graph in (reactant_graph, product_graph, rc_graph):
            graph.graph["force_ignore_charge_in_signature"] = True
        return


def _relax_explicit_hx_hetero_protonation_charge(
    reactant_graph: nx.Graph, product_graph: nx.Graph, rc_graph: nx.Graph
) -> None:
    """Avoid local charge-recompute noise for explicit H-X protonation salts.

    Aromatic/basic heteroatom protonation from a mapped H-X reagent is already
    fully described by the bond deltas X-H -> Y-H.  The endpoint formal charges
    can be representation-sensitive after local recomputation, especially for
    aromatic N systems, so endpoint matching should trust the bond/LP changes.
    """
    halogens = {"F", "CL", "BR", "I"}
    hetero_targets = {"N", "O", "S", "P"}

    for h in reactant_graph.nodes():
        h = int(h)
        if _element(reactant_graph, h) != "H" or _element(product_graph, h) != "H":
            continue
        if reactant_graph.degree(h) != 1 or product_graph.degree(h) != 1:
            continue

        src = int(next(iter(reactant_graph.neighbors(h))))
        dst = int(next(iter(product_graph.neighbors(h))))
        if src == dst:
            continue
        if _element(reactant_graph, src) not in halogens:
            continue
        if _element(product_graph, dst) not in hetero_targets:
            continue
        if _edge_order(reactant_graph, src, h) <= 0:
            continue
        if _edge_order(product_graph, dst, h) <= 0:
            continue
        if _edge_order(product_graph, src, h) > 0:
            continue

        for graph in (reactant_graph, product_graph, rc_graph):
            graph.graph["force_ignore_charge_in_signature"] = True
        return


def _int_attr(graph: nx.Graph, node: int, key: str, default: int = 0) -> int:
    try:
        return int(round(float(graph.nodes[int(node)].get(key, default))))
    except Exception:
        return int(default)


def _edge_order(graph: nx.Graph, u: int, v: int) -> float:
    if not graph.has_edge(int(u), int(v)):
        return 0.0
    try:
        data = graph.edges[int(u), int(v)]
        return float(data.get("order", data.get("kekule_order", 1.0)))
    except Exception:
        return 0.0


def _explicit_h_is_available_for_bond(source_graph: nx.Graph, target_graph: nx.Graph, h_atom: int) -> bool:
    """Return True if a mapped explicit H should be kept explicit.

    Some upstream graph conversions encode the destination of a mapped explicit
    H by increasing the heavy atom's ``hcount`` while leaving the H node free.
    SynEltra's mechanism grammar is explicit-atom based, so this helper detects
    such H nodes before search and promotes the hcount delta into an explicit
    H--X bond in the target endpoint.
    """
    h_atom = int(h_atom)
    if h_atom not in source_graph or h_atom not in target_graph:
        return False
    if _element(source_graph, h_atom) != "H" or _element(target_graph, h_atom) != "H":
        return False
    if source_graph.degree(h_atom) != 0 or target_graph.degree(h_atom) != 0:
        return False

    q0 = _int_attr(source_graph, h_atom, "charge", 0)
    q1 = _int_attr(target_graph, h_atom, "charge", 0)
    lp0 = _int_attr(source_graph, h_atom, "lone_pairs", 0)
    lp1 = _int_attr(target_graph, h_atom, "lone_pairs", 0)

    # Explicit H anion/electron-pair donor or explicit proton-like acceptor that
    # becomes neutral in the target endpoint.  We do not create an H operator;
    # we only make the already-mapped H atom participate in an explicit bond.
    if q0 < 0 and q1 >= q0 and lp1 <= lp0:
        return True
    if q0 > 0 and q1 <= q0:
        return True
    return False


def _heavy_hcount_acceptor_score(source_graph: nx.Graph, target_graph: nx.Graph, atom: int) -> tuple:
    """Rank a heavy atom whose target hcount increased.

    Prefer atoms with an outgoing heavy-bond order decrease, e.g. C=O -> C-O
    during atom-centered addition.  This remains a generic graph-delta rule.
    """
    atom = int(atom)
    release = 0.0
    nbrs = set()
    if atom in source_graph:
        nbrs.update(int(n) for n in source_graph.neighbors(atom))
    if atom in target_graph:
        nbrs.update(int(n) for n in target_graph.neighbors(atom))
    for nbr in nbrs:
        ref = source_graph if nbr in source_graph else target_graph
        if _element(ref, nbr) == "H":
            continue
        delta = _edge_order(source_graph, atom, nbr) - _edge_order(target_graph, atom, nbr)
        if delta > release:
            release = float(delta)
    try:
        pcharge = float(target_graph.nodes[atom].get("partial_charge", 0.0))
    except Exception:
        pcharge = 0.0
    return (-round(release, 3), -round(pcharge, 3), int(atom))


def _promote_explicit_hcount_delta_direction(
    source_graph: nx.Graph, target_graph: nx.Graph, rc_graph: nx.Graph
) -> None:
    """Promote target-side hcount increases to explicit H--X bonds in-place.

    This is endpoint normalization, not a mechanism operation.  It prevents a
    mapped explicit H atom from being lost into implicit ``hcount`` bookkeeping.
    """
    used_h: set[int] = set()
    used_acceptors: set[int] = set()

    for h_atom in sorted(int(n) for n in source_graph.nodes()):
        if h_atom in used_h:
            continue
        if not _explicit_h_is_available_for_bond(source_graph, target_graph, h_atom):
            continue

        candidates = []
        for atom in target_graph.nodes():
            atom = int(atom)
            if atom == h_atom or _element(target_graph, atom) == "H":
                continue
            if atom in used_acceptors:
                continue
            if target_graph.has_edge(h_atom, atom):
                continue
            dh = _int_attr(target_graph, atom, "hcount", 0) - _int_attr(source_graph, atom, "hcount", 0)
            if dh <= 0:
                continue
            candidates.append((_heavy_hcount_acceptor_score(source_graph, target_graph, atom), atom))

        if not candidates:
            continue
        candidates.sort(key=lambda item: item[0])
        acceptor = int(candidates[0][1])

        attrs = normalize_edge_attrs(
            {
                "order": 1.0,
                "kekule_order": 1.0,
                "bond_type": "SINGLE",
                "conjugated": False,
                "in_ring": False,
            }
        )
        target_graph.add_edge(h_atom, acceptor, **attrs)
        target_graph.nodes[acceptor]["hcount"] = max(0, _int_attr(target_graph, acceptor, "hcount", 0) - 1)

        if h_atom not in rc_graph:
            rc_graph.add_node(h_atom, **copy.deepcopy(target_graph.nodes[h_atom]))
        if acceptor not in rc_graph:
            rc_graph.add_node(acceptor, **copy.deepcopy(target_graph.nodes[acceptor]))
        rc_graph.add_edge(h_atom, acceptor, **copy.deepcopy(attrs))

        used_h.add(h_atom)
        used_acceptors.add(acceptor)


def promote_explicit_hcount_deltas_to_bonds(
    reactant_graph: nx.Graph, product_graph: nx.Graph, rc_graph: nx.Graph
) -> None:
    """Normalize mapped explicit-H / hcount mixed representations in-place."""
    _promote_explicit_hcount_delta_direction(reactant_graph, product_graph, rc_graph)
    _promote_explicit_hcount_delta_direction(product_graph, reactant_graph, rc_graph)


def extract_its_components(
    its: nx.Graph,
    reverter_cls=None,
    rc_extractor=None,
) -> Tuple[nx.Graph, nx.Graph, nx.Graph]:
    if reverter_cls is None:
        from synkit.Graph.ITS.its_reverter import ITSReverter

        reverter_cls = ITSReverter
    if rc_extractor is None:
        from synkit.Graph.ITS.rc_extractor import RCExtractor

        rc_extractor = RCExtractor()
    reverter = reverter_cls(its)
    reactant_graph = reverter.to_reactant_graph()
    product_graph = reverter.to_product_graph()
    rc_graph = rc_extractor.extract(its)
    return rc_graph, reactant_graph, product_graph


def build_working_graph(
    side_graph: nx.Graph,
    workspace: WorkspaceSpec,
    *,
    full_reference_graph: Optional[nx.Graph] = None,
) -> nx.Graph:
    """Materialize a working graph from one side of the reaction and a workspace.

    :param side_graph: Reactant-side or product-side graph.
    :type side_graph: nx.Graph
    :param workspace: Workspace specification defining which atoms and bonds are
        carried into the search state.
    :type workspace: WorkspaceSpec
    :param full_reference_graph: Optional full graph used to fill missing node or
        edge attributes.
    :type full_reference_graph: Optional[nx.Graph]
    :return: Working graph used by :class:`Mech.models.StateSnapshot`.
    :rtype: nx.Graph
    """
    full = copy.deepcopy(full_reference_graph if full_reference_graph is not None else side_graph)
    g = nx.Graph()
    g.add_nodes_from((int(n), dict(attrs)) for n, attrs in full.nodes(data=True))
    for u, v, attrs in full.edges(data=True):
        g.add_edge(int(u), int(v), **normalize_edge_attrs(dict(attrs)))

    g.graph["edge_templates"] = {}
    g.graph["rc_nodes"] = set(int(n) for n in workspace.rc_nodes)
    g.graph["rc_edges"] = set(workspace.rc_edges)
    g.graph["workspace_nodes"] = set(int(n) for n in workspace.nodes)
    g.graph["candidate_edge_universe"] = set(workspace.edge_universe)
    g.graph["k"] = int(workspace.__dict__.get("k", 0)) if hasattr(workspace, "__dict__") else 0
    g.graph.setdefault("context_proposal_mode", "none")
    g.graph["recompute_charge"] = True
    if bool(full.graph.get("force_ignore_charge_in_signature", False)):
        g.graph["force_ignore_charge_in_signature"] = True
    g.graph["full_reference_graph"] = copy.deepcopy(
        full_reference_graph if full_reference_graph is not None else side_graph
    )

    for n in g.nodes():
        g.nodes[n].setdefault("atom_map", int(n))
        g.nodes[n]["hcount"] = int(g.nodes[n].get("hcount", 0))
        g.nodes[n]["lone_pairs"] = int(g.nodes[n].get("lone_pairs", 0))
        g.nodes[n]["charge"] = int(round(float(g.nodes[n].get("charge", 0))))
        if n in workspace.nodes:
            g.nodes[n]["workspace_role"] = workspace.node_roles.get(int(n), "context")
            g.nodes[n]["rc"] = int(n) in workspace.rc_nodes

    for u, v in sorted(workspace.edge_universe):
        key = canonical_edge(int(u), int(v))
        if side_graph.has_edge(u, v):
            template_attrs = dict(side_graph.edges[u, v])
        else:
            template_attrs = dict(DEFAULT_EDGE_TEMPLATE)
        register_edge_template(g, int(u), int(v), template_attrs)
        if g.has_edge(u, v):
            g.edges[u, v]["workspace_role"] = workspace.edge_roles.get(key, "context")
            g.edges[u, v]["rc"] = key in workspace.rc_edges
    return g


def build_endpoint_states_from_graphs(
    reactant_graph: nx.Graph,
    product_graph: nx.Graph,
    rc_graph: nx.Graph,
    *,
    k: int = 0,
    mode: WorkspaceMode = "reactant",
    include_product_context: bool = False,
    workspace_builder: Optional[RCWorkspaceBuilder] = None,
) -> Tuple[StateSnapshot, StateSnapshot, WorkspaceSpec]:
    reactant_graph = normalize_side_graph_attrs(reactant_graph, 0)
    product_graph = normalize_side_graph_attrs(product_graph, 1)
    rc_graph = normalize_side_graph_attrs(rc_graph, 0)
    _repair_placeholder_atoms_from_reference(reactant_graph, product_graph)
    _repair_placeholder_atoms_from_reference(product_graph, reactant_graph)
    _infer_product_only_water_reagent(reactant_graph, product_graph, rc_graph)
    _relax_explicit_hx_hetero_protonation_charge(reactant_graph, product_graph, rc_graph)
    promote_explicit_hcount_deltas_to_bonds(reactant_graph, product_graph, rc_graph)
    builder = workspace_builder or RCWorkspaceBuilder()
    workspace = builder.expand_from_rc(
        rc_graph=rc_graph,
        reactant_graph=reactant_graph,
        product_graph=product_graph,
        k=k,
        mode=mode,
        include_product_context=include_product_context,
    )
    start = StateSnapshot(
        graph=build_working_graph(
            side_graph=reactant_graph,
            workspace=workspace,
            full_reference_graph=reactant_graph,
        ),
        memory={},
    )
    goal = StateSnapshot(
        graph=build_working_graph(
            side_graph=product_graph,
            workspace=workspace,
            full_reference_graph=product_graph,
        ),
        memory={},
    )
    start.graph.graph["k"] = int(k)
    goal.graph.graph["k"] = int(k)
    return start, goal, workspace


def build_endpoint_states_from_its(
    its: nx.Graph,
    *,
    k: int = 0,
    mode: WorkspaceMode = "reactant",
    include_product_context: bool = False,
    reverter_cls=None,
    rc_extractor=None,
    workspace_builder: Optional[RCWorkspaceBuilder] = None,
) -> Tuple[StateSnapshot, StateSnapshot, WorkspaceSpec, nx.Graph, nx.Graph, nx.Graph]:
    rc_graph, reactant_graph, product_graph = extract_its_components(
        its,
        reverter_cls=reverter_cls,
        rc_extractor=rc_extractor,
    )
    start, goal, workspace = build_endpoint_states_from_graphs(
        reactant_graph=reactant_graph,
        product_graph=product_graph,
        rc_graph=rc_graph,
        k=k,
        mode=mode,
        include_product_context=include_product_context,
        workspace_builder=workspace_builder,
    )
    return start, goal, workspace, rc_graph, reactant_graph, product_graph


build_endpoint_states = build_endpoint_states_from_graphs
