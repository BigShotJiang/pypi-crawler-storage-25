from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

import networkx as nx

from ..core.models import StateSnapshot

EdgeKey = Tuple[int, int]

DEFAULT_EDGE_TEMPLATE: Dict[str, Any] = {
    "kekule_order": 1.0,
    "order": 1.0,
    "bond_type": "SINGLE",
    "conjugated": False,
    "in_ring": False,
}


@dataclass(frozen=True)
class AromaticChargeContext:
    """Local aromatic heteroatom context used for charge bookkeeping."""

    element: str
    formal_charge_hint: int
    h_total: int
    heavy_degree: int
    aromatic_bonds: int
    nonaromatic_heavy_sigma_bonds: int


def _scalar(value: Any, default: Any = None) -> Any:
    """Return scalar value from scalar or ITS-style side tuple/list."""
    if isinstance(value, (tuple, list)):
        if len(value) == 0:
            return default
        return value[0]
    return value if value is not None else default


def _side_value(value: Any, side_index: int, default: Any = None) -> Any:
    """Extract reactant/product side value from tuple-like ITS attributes."""
    if isinstance(value, (tuple, list)):
        if len(value) > side_index:
            return value[side_index]
        if value:
            return value[0]
        return default
    return value if value is not None else default


def _as_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(_scalar(value, default))
    except Exception:
        return float(default)


def _as_int(value: Any, default: int = 0) -> int:
    try:
        return int(round(float(_scalar(value, default))))
    except Exception:
        return int(default)


def _as_bool(value: Any, default: bool = False) -> bool:
    try:
        value = _scalar(value, default)
        if isinstance(value, str):
            return value.strip().lower() in {"1", "true", "yes", "y"}
        return bool(value)
    except Exception:
        return bool(default)


def canonical_edge(u: int, v: int) -> EdgeKey:
    return (int(u), int(v)) if int(u) <= int(v) else (int(v), int(u))


def bond_type_from_order(order: float) -> str:
    x = round(float(order), 1)

    if abs(x - 1.0) < 1e-8:
        return "SINGLE"
    if abs(x - 2.0) < 1e-8:
        return "DOUBLE"
    if abs(x - 3.0) < 1e-8:
        return "TRIPLE"
    if abs(x - 1.5) < 1e-8:
        return "AROMATIC"

    return "SINGLE"


def normalize_edge_attrs(attrs: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """
    Normalize edge attributes.

    Important distinction
    ---------------------
    ``order``:
        Current graph/search order. Aromatic edges may be 1.5.

    ``kekule_order``:
        Integer-ish formal bond order used for charge bookkeeping when
        available.

    ``formal_order``:
        Optional strongest override for formal-charge bookkeeping.
    """
    out = dict(DEFAULT_EDGE_TEMPLATE)
    given = dict(attrs or {})

    if given:
        out.update(given)

    order = _as_float(out.get("order", out.get("kekule_order", 1.0)), 1.0)
    out["order"] = order

    if "kekule_order" in given:
        out["kekule_order"] = _as_float(given.get("kekule_order"), order)
    else:
        out["kekule_order"] = _as_float(out.get("kekule_order", order), order)

    if "formal_order" in given:
        out["formal_order"] = _as_float(given.get("formal_order"), out["kekule_order"])

    if "bond_type" not in given:
        out["bond_type"] = bond_type_from_order(order)
    else:
        out["bond_type"] = str(_scalar(out.get("bond_type", "SINGLE"), "SINGLE"))

    if "conjugated" not in given:
        out["conjugated"] = bool(
            abs(order - 1.5) < 1e-8
            or abs(_as_float(out.get("kekule_order", 0.0), 0.0) - 1.5) < 1e-8
            or str(out.get("bond_type", "")).upper() == "AROMATIC"
        )
    else:
        out["conjugated"] = _as_bool(out.get("conjugated", False), False)

    out["in_ring"] = _as_bool(out.get("in_ring", False), False)

    return out


def possible_edge_keys(g: nx.Graph) -> Iterable[EdgeKey]:
    candidate = g.graph.get("candidate_edge_universe")

    if candidate is not None:
        return sorted(canonical_edge(int(u), int(v)) for u, v in candidate)

    templates = g.graph.get("edge_templates", {})

    if templates:
        return sorted(canonical_edge(int(u), int(v)) for u, v in templates)

    return sorted(canonical_edge(int(u), int(v)) for u, v in g.edges())


def edge_template_attrs(g: nx.Graph, u: int, v: int) -> Dict[str, Any]:
    return dict(g.graph.get("edge_templates", {}).get(canonical_edge(int(u), int(v)), {}))


def register_edge_template(
    g: nx.Graph,
    u: int,
    v: int,
    attrs: Dict[str, Any] | None = None,
) -> None:
    g.graph.setdefault("edge_templates", {})
    g.graph["edge_templates"][canonical_edge(int(u), int(v))] = normalize_edge_attrs(attrs)


def _edge_data(g: nx.Graph, u: int, v: int) -> Dict[str, Any]:
    if not g.has_edge(u, v):
        return {}

    data = g.get_edge_data(u, v, default={})

    if g.is_multigraph():
        if not data:
            return {}
        first_key = next(iter(data))
        return dict(data[first_key])

    return dict(data)


def edge_order(g: nx.Graph, u: int, v: int) -> float:
    if g.has_edge(u, v):
        return _as_float(_edge_data(g, u, v).get("order", 0.0), 0.0)

    return 0.0


def _edge_is_aromatic_like(g: nx.Graph, u: int, v: int) -> bool:
    if not g.has_edge(int(u), int(v)):
        return False

    data = _edge_data(g, int(u), int(v))
    order = _as_float(data.get("order", 0.0), 0.0)
    bond_type = str(_scalar(data.get("bond_type", ""), "")).upper()

    if abs(order - 1.5) < 1e-8 or bond_type == "AROMATIC":
        return True

    if _as_bool(data.get("aromatic", False), False):
        return True

    if (
        _as_bool(data.get("in_ring", False), False)
        and _as_bool(g.nodes[int(u)].get("aromatic", False), False)
        and _as_bool(g.nodes[int(v)].get("aromatic", False), False)
    ):
        return True

    return (
        _as_bool(data.get("conjugated", False), False)
        and _as_bool(g.nodes[int(u)].get("aromatic", False), False)
        and _as_bool(g.nodes[int(v)].get("aromatic", False), False)
    )


def _aromatic_edge_component(g: nx.Graph, u: int, v: int) -> Optional[nx.Graph]:
    u = int(u)
    v = int(v)

    if not _edge_is_aromatic_like(g, u, v):
        return None

    aromatic = nx.Graph()

    for a, b in g.edges():
        a = int(a)
        b = int(b)
        if _edge_is_aromatic_like(g, a, b):
            aromatic.add_edge(a, b)

    if not aromatic.has_edge(u, v):
        return None

    nodes = nx.node_connected_component(aromatic, u)
    if v not in nodes:
        return None

    return aromatic.subgraph(nodes).copy()


def retarget_aromatic_kekule_for_edge(
    g: nx.Graph,
    u: int,
    v: int,
    *,
    target_order: float = 2.0,
) -> Set[int]:
    """
    Choose a local Kekule form where aromatic edge ``u-v`` is formally double.

    Arrow operators move one electron pair at a time, so they must operate on
    integer Kekule orders rather than aromatic display orders.  This helper
    updates the ``kekule_order`` values of the aromatic component containing
    ``u-v`` to a matching-like single/double assignment with ``u-v`` forced
    double.  The aromatic ``order`` remains unchanged (usually ``1.5``), so the
    aromatic graph can still guide arrow proposals.  Returns the retargeted
    component nodes, or an empty set if no aromatic retarget was possible.
    """
    u = int(u)
    v = int(v)

    if abs(float(target_order) - 2.0) > 1e-8:
        return set()

    component = _aromatic_edge_component(g, u, v)
    if component is None:
        return set()

    source = canonical_edge(u, v)
    if source not in {canonical_edge(a, b) for a, b in component.edges()}:
        return set()

    remaining = component.copy()
    remaining.remove_nodes_from([u, v])

    for a, b in remaining.edges():
        data = _edge_data(g, int(a), int(b))
        current = _as_float(
            data.get("kekule_order", data.get("order", 1.0)),
            1.0,
        )
        remaining.edges[a, b]["weight"] = 2.0 if current >= 1.8 else 1.0

    matching = nx.algorithms.matching.max_weight_matching(
        remaining,
        maxcardinality=True,
        weight="weight",
    )
    double_edges = {source}
    double_edges.update(canonical_edge(int(a), int(b)) for a, b in matching)

    for a, b in component.edges():
        a = int(a)
        b = int(b)
        order = 2.0 if canonical_edge(a, b) in double_edges else 1.0
        data = g.edges[a, b]
        data["kekule_order"] = order
        data["conjugated"] = True
        data.setdefault("in_ring", True)

    return {int(node) for node in component.nodes()}


def decrement_edge_order_for_arrow(g: nx.Graph, u: int, v: int) -> Set[int]:
    """
    Apply the source side of a unit arrow.

    Aromatic edges keep using ``order`` as the search residual, but their
    ``kekule_order`` is retargeted and updated independently for formal
    bookkeeping.
    """
    u = int(u)
    v = int(v)

    if not _edge_is_aromatic_like(g, u, v):
        set_edge_order(g, u, v, edge_order(g, u, v) - 1.0)
        return set()

    retargeted = retarget_aromatic_kekule_for_edge(g, u, v)
    if not retargeted:
        return set()

    data = g.edges[u, v]
    old_order = edge_order(g, u, v)
    new_order = max(0.0, old_order - 1.0)
    order_delta = old_order - new_order
    current = _as_float(data.get("kekule_order", data.get("order", 1.0)), 1.0)
    data["order"] = new_order
    data["kekule_order"] = max(0.0, current - order_delta)
    data["bond_type"] = bond_type_from_order(data["order"])
    data["conjugated"] = True
    data.setdefault("in_ring", True)
    return retargeted


def increment_edge_order_for_arrow(g: nx.Graph, u: int, v: int) -> Set[int]:
    """
    Apply the destination side of a unit arrow.

    Aromatic edges update search ``order`` while retargeting ``kekule_order`` so
    the destination edge becomes formally double.
    """
    u = int(u)
    v = int(v)

    if not _edge_is_aromatic_like(g, u, v):
        set_edge_order(g, u, v, edge_order(g, u, v) + 1.0)
        return set()

    retargeted = retarget_aromatic_kekule_for_edge(g, u, v)
    if not retargeted:
        return set()

    data = g.edges[u, v]
    data["order"] = edge_order(g, u, v) + 1.0
    data["kekule_order"] = 2.0
    data["bond_type"] = bond_type_from_order(data["order"])
    data["conjugated"] = True
    data.setdefault("in_ring", True)
    return retargeted


def set_edge_order(g: nx.Graph, u: int, v: int, order: float) -> None:
    """
    Set the current edge order.

    For aromatic ``order=1.5``, existing/template ``kekule_order`` is preserved
    when available. This avoids destroying formal-charge bookkeeping.
    """
    u = int(u)
    v = int(v)
    order = float(order)
    key = canonical_edge(u, v)

    g.graph.setdefault("edge_templates", {})

    if key not in g.graph["edge_templates"]:
        register_edge_template(g, u, v, DEFAULT_EDGE_TEMPLATE)

    if order <= 0.0:
        if g.has_edge(u, v):
            g.remove_edge(u, v)
        return

    attrs = normalize_edge_attrs(edge_template_attrs(g, u, v))

    if g.has_edge(u, v):
        old = _edge_data(g, u, v)
        attrs.update(old)

    attrs = normalize_edge_attrs(attrs)
    attrs["order"] = order

    if abs(order - 1.5) < 1e-8:
        attrs["bond_type"] = "AROMATIC"
        attrs["conjugated"] = True
        attrs.setdefault("kekule_order", 1.5)
    else:
        attrs["kekule_order"] = order
        attrs["bond_type"] = bond_type_from_order(order)
        attrs["conjugated"] = bool(order >= 2.0)

    attrs.setdefault("in_ring", False)

    preserved = {}
    if g.has_edge(u, v):
        old = _edge_data(g, u, v)
        for key2 in ("workspace_role", "rc"):
            if key2 in old:
                preserved[key2] = old[key2]

    attrs.update(preserved)

    if not g.has_edge(u, v):
        g.add_edge(u, v, **attrs)
    else:
        g[u][v].clear()
        g[u][v].update(attrs)


def get_lp(g: nx.Graph, n: int) -> int:
    return _as_int(g.nodes[int(n)].get("lone_pairs", 0), 0)


def set_lp(g: nx.Graph, n: int, value: int) -> None:
    g.nodes[int(n)]["lone_pairs"] = int(value)


def get_h(g: nx.Graph, n: int) -> int:
    return _as_int(g.nodes[int(n)].get("hcount", 0), 0)


def set_h(g: nx.Graph, n: int, value: int) -> None:
    g.nodes[int(n)]["hcount"] = int(value)


def get_charge(g: nx.Graph, n: int) -> int:
    return _as_int(g.nodes[int(n)].get("charge", 0), 0)


def get_radical(g: nx.Graph, n: int) -> int:
    return _as_int(g.nodes[int(n)].get("radical_electrons", 0), 0)


def set_radical(g: nx.Graph, n: int, value: int) -> None:
    g.nodes[int(n)]["radical_electrons"] = int(value)


def validate_nonnegative_state(state: StateSnapshot) -> bool:
    g = state.graph

    for n in g.graph.get("workspace_nodes", g.nodes()):
        if n not in g:
            continue

        if get_lp(g, n) < 0 or get_h(g, n) < 0 or get_radical(g, n) < 0:
            return False

    for u, v in possible_edge_keys(g):
        if edge_order(g, u, v) < 0:
            return False

    return True


def atom_element(g: nx.Graph, node: int, *, default: str = "") -> str:
    """Return normalized atomic element symbol for one graph node."""
    try:
        value = g.nodes[int(node)].get("element", default)
    except Exception:
        value = default

    value = _scalar(value, default)
    return str(value).strip().upper()


def _node_element_for_charge(g: nx.Graph, node: int) -> str:
    return atom_element(g, int(node))


def actual_neighbor_elements(g: nx.Graph, node: int) -> List[str]:
    node = int(node)
    return sorted(atom_element(g, int(nbr)) for nbr in g.neighbors(node))


def cached_neighbor_elements(g: nx.Graph, node: int) -> List[str]:
    node = int(node)
    raw = g.nodes[node].get("neighbors", [])
    if raw is None:
        raw = []
    return sorted(str(_scalar(x, "")).strip().upper() for x in raw)


def audit_neighbor_cache(
    g: nx.Graph,
    nodes: Optional[Iterable[int]] = None,
) -> List[Dict[str, Any]]:
    """
    Return nodes where cached ``node['neighbors']`` disagrees with actual edges.

    This is a diagnostic only. Charge recomputation should trust actual edges
    after a molecular state has been materialized.
    """
    target_nodes = list(g.nodes) if nodes is None else list(nodes)
    issues: List[Dict[str, Any]] = []

    for node in target_nodes:
        node = int(node)

        if node not in g:
            continue

        cached = cached_neighbor_elements(g, node)
        actual = actual_neighbor_elements(g, node)

        if cached != actual:
            issues.append(
                {
                    "node": node,
                    "element": atom_element(g, node),
                    "cached_neighbors": cached,
                    "actual_neighbors": actual,
                }
            )

    return issues


def format_neighbor_cache_issues(issues: Iterable[Dict[str, Any]]) -> str:
    lines = ["Cached neighbors disagree with actual graph edges:"]

    for issue in issues:
        lines.append(
            f"  node {issue['node']} {issue['element']}: "
            f"cached={issue['cached_neighbors']} "
            f"actual={issue['actual_neighbors']}"
        )

    return "\n".join(lines)


def _atom_has_pi_bond(g: nx.Graph, node: int) -> bool:
    """Return True if the atom still has at least one double/triple/aromatic bond.

    Uses only the current ``order`` field (not ``bond_type`` or ``kekule_order``)
    because ``bond_type`` is set at graph-build time and may be stale after bond
    order changes during the mechanism.
    """
    for nbr in g.neighbors(node):
        data = g.get_edge_data(node, nbr, default={})
        order = _as_float(data.get("order", 1.0), 1.0)
        if order >= 1.5:
            return True
    return False


def refresh_neighbor_cache(
    g: nx.Graph,
    nodes: Optional[Iterable[int]] = None,
    *,
    inplace: bool = True,
    update_explicit_hcount: bool = True,
) -> nx.Graph:
    """
    Refresh cached neighbor descriptors from actual graph edges.

    ``hcount`` is not modified because SynEltra treats it as implicit-H count.
    Explicit H atoms are instead counted through actual graph edges.

    Also clears stale ``conjugated`` flags on adjacent single bonds when an atom
    transitions from sp2 to sp3 (loses all π bonds). The ``conjugated`` attribute
    is set at graph-build time and becomes incorrect after bond-order changes.
    """
    out = g if inplace else copy.deepcopy(g)
    target_nodes = list(out.nodes) if nodes is None else list(nodes)

    for node in target_nodes:
        node = int(node)

        if node not in out:
            continue

        out.nodes[node]["neighbors"] = [atom_element(out, int(nbr)) for nbr in out.neighbors(node)]

        if update_explicit_hcount:
            out.nodes[node]["explicit_hcount"] = sum(
                1 for nbr in out.neighbors(node) if atom_element(out, int(nbr)) == "H"
            )

        # If this atom was originally sp2 (hybridization=SP2/SP) and currently
        # has no π bonds, it has undergone an sp2→sp3 hybridization change during
        # the mechanism. Clear the stale ``conjugated`` flags on its adjacent
        # non-ring single bonds (and their templates) so that
        # _is_resonance_eligible_edge does not create false resonance components.
        # Atoms that were always sp3 (e.g., alpha carbons) retain their conjugated
        # flags because those flags reflect their position adjacent to a π system.
        orig_hyb = str(out.nodes[node].get("hybridization", "") or "").upper()
        was_sp2 = orig_hyb in {"SP", "SP2"}
        if was_sp2 and not _atom_has_pi_bond(out, node):
            templates = out.graph.get("edge_templates", {})
            for nbr in out.neighbors(node):
                edata = out.get_edge_data(node, nbr, default={})
                order = _as_float(edata.get("order", 1.0), 1.0)
                in_ring = _as_bool(edata.get("in_ring", False), False)
                # Only clear for non-ring single bonds; ring bonds maintain
                # their conjugation via the ring system even if one atom changes.
                if abs(order - 1.0) < 1e-8 and not in_ring:
                    edata["conjugated"] = False
                    key = canonical_edge(node, int(nbr))
                    if key in templates:
                        templates[key]["conjugated"] = False

    return out


def _edge_is_aromatic_for_charge(
    g: nx.Graph,
    u: int,
    v: int,
    *,
    order_key: str = "order",
) -> bool:
    if _edge_is_aromatic_like(g, int(u), int(v)):
        return True

    data = _edge_data(g, int(u), int(v))

    try:
        if _as_bool(data.get("aromatic", False), False):
            return True
    except Exception:
        pass

    try:
        if str(_scalar(data.get("bond_type", ""), "")).upper() == "AROMATIC":
            return True
    except Exception:
        pass

    try:
        order = _as_float(data.get(order_key, data.get("order", 0.0)), 0.0)
        return abs(order - 1.5) < 1e-8
    except Exception:
        return False


def formal_edge_order_for_charge(
    g: nx.Graph,
    u: int,
    v: int,
    *,
    order_key: str = "order",
    default: float = 1.0,
) -> float:
    """
    Return bond order used for formal-charge recomputation.

    Priority:
    1. ``formal_order`` if available.
    2. ``kekule_order`` for aromatic edges if available.
    3. ``order`` otherwise, with sub-single residual search orders treated as
       non-bonds for formal-charge bookkeeping.

    This fixes the common bug where aromatic ``order=1.5`` makes atoms such as
    C15 appear as ``-1`` or hides quaternized aromatic N as neutral.
    """
    data = _edge_data(g, int(u), int(v))

    if not data:
        return 0.0

    if "formal_order" in data:
        return _as_float(data.get("formal_order"), default)

    current_order = _as_float(data.get(order_key, data.get("order", default)), default)

    if _edge_is_aromatic_for_charge(g, u, v, order_key=order_key):
        if "kekule_order" in data:
            kekule_order = _as_float(data.get("kekule_order"), current_order)
            if 0.0 < current_order < 1.0 and kekule_order < 1.0:
                return 0.0
            return kekule_order

    # Unit electron-pair moves may turn an aromatic 1.5 edge into a temporary
    # 0.5 residual edge. Keep that edge in the search graph, but do not let a
    # fractional sub-single bond contribute half a sigma bond to formal charge.
    if 0.0 < current_order < 1.0:
        return 0.0

    return current_order


def _edge_order_for_charge(
    g: nx.Graph,
    u: int,
    v: int,
    *,
    order_key: str = "order",
    default: float = 1.0,
) -> float:
    return formal_edge_order_for_charge(
        g,
        int(u),
        int(v),
        order_key=order_key,
        default=default,
    )


def _explicit_h_neighbor_count_for_charge(g: nx.Graph, node: int) -> int:
    node = int(node)
    return sum(1 for nbr in g.neighbors(node) if _node_element_for_charge(g, int(nbr)) == "H")


def _heavy_neighbor_count_for_charge(g: nx.Graph, node: int) -> int:
    node = int(node)
    return sum(1 for nbr in g.neighbors(node) if _node_element_for_charge(g, int(nbr)) != "H")


def _node_is_aromatic_for_charge(g: nx.Graph, node: int) -> bool:
    try:
        return _as_bool(g.nodes[int(node)].get("aromatic", False), False)
    except Exception:
        return False


def _count_aromatic_charge_bonds(
    g: nx.Graph,
    node: int,
    *,
    order_key: str = "order",
) -> Tuple[int, int]:
    """Count aromatic and non-aromatic heavy sigma bonds around ``node``."""
    aromatic_bonds = 0
    nonaromatic_heavy_sigma_bonds = 0

    for nbr in g.neighbors(int(node)):
        nbr = int(nbr)

        if _edge_is_aromatic_for_charge(g, node, nbr, order_key=order_key):
            aromatic_bonds += 1
            continue

        if _node_element_for_charge(g, nbr) == "H":
            continue

        order = _edge_order_for_charge(g, node, nbr, order_key=order_key)

        if order <= 1.1:
            nonaromatic_heavy_sigma_bonds += 1

    return aromatic_bonds, nonaromatic_heavy_sigma_bonds


def _aromatic_charge_context(
    g: nx.Graph,
    node: int,
    *,
    order_key: str = "order",
) -> AromaticChargeContext:
    node = int(node)
    data = g.nodes[node]

    h_total = _as_int(data.get("hcount", 0), 0) + _explicit_h_neighbor_count_for_charge(
        g,
        node,
    )
    aromatic_bonds, nonaromatic_sigma = _count_aromatic_charge_bonds(
        g,
        node,
        order_key=order_key,
    )

    return AromaticChargeContext(
        element=_node_element_for_charge(g, node),
        formal_charge_hint=_as_int(data.get("charge", 0), 0),
        h_total=h_total,
        heavy_degree=_heavy_neighbor_count_for_charge(g, node),
        aromatic_bonds=aromatic_bonds,
        nonaromatic_heavy_sigma_bonds=nonaromatic_sigma,
    )


def _nitrogen_is_aromatic_lp_donor(ctx: AromaticChargeContext) -> bool:
    """Return True for pyrrolic or anionic aromatic nitrogen cases."""
    if ctx.formal_charge_hint <= 0 and ctx.aromatic_bonds >= 2:
        if ctx.h_total > 0 and ctx.heavy_degree == 2:
            return True

        if ctx.h_total == 0 and ctx.heavy_degree == 3:
            return True

    if ctx.formal_charge_hint < 0 and ctx.heavy_degree <= 2:
        return True

    return False


def _chalcogen_is_aromatic_lp_donor(ctx: AromaticChargeContext) -> bool:
    return ctx.formal_charge_hint <= 0 and ctx.heavy_degree <= 2 and ctx.aromatic_bonds >= 2


def _phosphorus_is_aromatic_lp_donor(ctx: AromaticChargeContext) -> bool:
    return ctx.formal_charge_hint <= 0 and ctx.h_total > 0 and ctx.heavy_degree == 2 and ctx.aromatic_bonds >= 2


def _is_aromatic_lp_donor_for_charge(
    g: nx.Graph,
    node: int,
    *,
    order_key: str = "order",
) -> bool:
    """
    Keep this helper for compatibility with older charge logic.

    The new charge model primarily uses ``formal_order`` / ``kekule_order``.
    """
    node = int(node)

    if node not in g:
        return False

    if not _node_is_aromatic_for_charge(g, node):
        return False

    ctx = _aromatic_charge_context(g, node, order_key=order_key)

    if ctx.element == "N":
        return _nitrogen_is_aromatic_lp_donor(ctx)

    if ctx.element in {"O", "S", "SE", "TE"}:
        return _chalcogen_is_aromatic_lp_donor(ctx)

    if ctx.element == "P":
        return _phosphorus_is_aromatic_lp_donor(ctx)

    return False


def _bond_order_sum_for_charge(
    g: nx.Graph,
    node: int,
    *,
    order_key: str = "order",
) -> float:
    """
    Bond-order sum for formal-charge recomputation.

    This must not blindly sum aromatic ``order=1.5`` when ``kekule_order`` or
    ``formal_order`` exists.
    """
    node = int(node)
    total = 0.0

    for nbr in g.neighbors(node):
        total += formal_edge_order_for_charge(
            g,
            node,
            int(nbr),
            order_key=order_key,
            default=1.0,
        )

    return float(total)


def _expanded_local_nodes(g: nx.Graph, nodes: Iterable[int]) -> Set[int]:
    expanded: Set[int] = set()

    for node in nodes:
        node = int(node)

        if node not in g:
            continue

        expanded.add(node)
        expanded.update(int(nbr) for nbr in g.neighbors(node))

    return expanded


def update_charge_local(
    graph: nx.Graph,
    nodes: Iterable[int],
    *,
    inplace: bool = True,
    order_key: str = "order",
    strict_neighbor_cache: bool = False,
    refresh_neighbors: bool = True,
) -> nx.Graph:
    """
    Recompute formal charges for selected nodes.

    Assumption
    ----------
    The current edge set is a real molecular state.

    Do not use this directly on a mixed ITS/union graph. For ITS graphs, first
    materialize a reactant/product/current molecular graph.

    Parameters
    ----------
    strict_neighbor_cache:
        If True, raise when cached ``neighbors`` disagree with actual edges.

    refresh_neighbors:
        If True, refresh cached ``neighbors`` and ``explicit_hcount`` after
        charge recomputation.
    """
    g = graph if inplace else copy.deepcopy(graph)
    target_nodes = {int(n) for n in nodes if int(n) in g}

    if strict_neighbor_cache:
        issues = audit_neighbor_cache(g, target_nodes)
        if issues:
            raise ValueError(format_neighbor_cache_issues(issues))

    for node in target_nodes:
        data = g.nodes[node]

        if "valence_electrons" not in data:
            continue

        valence_electrons = _as_int(data.get("valence_electrons"), 0)
        if valence_electrons == 0:
            # synkit stores valence_electrons=0 for all atoms; the formula
            # charge = ve - (2*lp + hcount + bonds) would always give wrong
            # results. Charge tracking is handled by _apply_charge_deltas.
            continue
        lone_pairs = _as_int(data.get("lone_pairs", 0), 0)
        if lone_pairs == 0 and _is_aromatic_lp_donor_for_charge(g, node, order_key=order_key):
            lone_pairs = 1

        # hcount is implicit H count. Explicit H atoms are counted via edges.
        hcount = _as_int(data.get("hcount", 0), 0)

        bond_order_sum = _bond_order_sum_for_charge(g, node, order_key=order_key)
        data["lp_bond_order_sum"] = round(float(bond_order_sum), 3)

        radical_electrons = _as_int(data.get("radical_electrons", 0), 0)
        charge = valence_electrons - (2 * lone_pairs + hcount + bond_order_sum + radical_electrons)
        data["charge"] = int(round(charge))

    if refresh_neighbors:
        refresh_neighbor_cache(
            g,
            _expanded_local_nodes(g, target_nodes),
            inplace=True,
            update_explicit_hcount=True,
        )

    return g


def total_abs_charge(g: nx.Graph) -> int:
    nodes = g.graph.get("workspace_nodes", g.nodes())
    return int(sum(abs(get_charge(g, int(n))) for n in nodes if n in g))


def materialize_side_graph_from_its(
    its: nx.Graph,
    *,
    side: str = "reactant",
    recompute_charge: bool = True,
    order_key: str = "order",
) -> nx.Graph:
    """
    Materialize a real molecular graph from an ITS-style graph.

    ``side`` must be ``"reactant"`` or ``"product"``.

    Tuple/list node and edge attributes are interpreted as:

    ``(reactant_value, product_value)``.
    """
    if side not in {"reactant", "product"}:
        raise ValueError("side must be 'reactant' or 'product'")

    side_index = 0 if side == "reactant" else 1

    g = nx.Graph()

    for node, data in its.nodes(data=True):
        new_data = {}

        for key, value in data.items():
            new_data[key] = copy.deepcopy(_side_value(value, side_index, value))

        g.add_node(int(node), **new_data)

    for u, v, data in its.edges(data=True):
        new_data = {}

        for key, value in data.items():
            new_data[key] = copy.deepcopy(_side_value(value, side_index, value))

        new_data = normalize_edge_attrs(new_data)

        order = _as_float(new_data.get(order_key, new_data.get("order", 0.0)), 0.0)
        kekule_order = _as_float(new_data.get("kekule_order", order), order)

        if max(order, kekule_order) > 1e-8:
            g.add_edge(int(u), int(v), **new_data)

    refresh_neighbor_cache(g, inplace=True)

    if recompute_charge:
        update_charge_local(g, list(g.nodes()), inplace=True, order_key=order_key)

    return g


def _materialize_without_reference(
    working_graph: nx.Graph,
    *,
    recompute_charge: bool | None = None,
    refresh_neighbors: bool = True,
    strict_neighbor_cache: bool = False,
) -> nx.Graph:
    out = copy.deepcopy(working_graph)

    if refresh_neighbors:
        refresh_neighbor_cache(out, inplace=True)

    if recompute_charge is not False:
        update_charge_local(
            out,
            list(out.nodes()),
            inplace=True,
            order_key="order",
            strict_neighbor_cache=strict_neighbor_cache,
            refresh_neighbors=refresh_neighbors,
        )

    return out


def _materialization_workspace_nodes(working_graph: nx.Graph) -> Set[int]:
    return {
        int(n) for n in working_graph.graph.get("workspace_nodes", working_graph.nodes()) if int(n) in working_graph
    }


def _copy_workspace_node_attrs(
    full: nx.Graph,
    working_graph: nx.Graph,
    workspace_nodes: Set[int],
) -> None:
    for n in workspace_nodes:
        if n not in working_graph or n not in full:
            continue

        src = working_graph.nodes[n]
        dst = full.nodes[n]

        for key, value in src.items():
            if key in {"workspace_role", "rc"}:
                continue

            dst[key] = copy.deepcopy(value)


def _sync_workspace_edges(full: nx.Graph, working_graph: nx.Graph) -> None:
    for u, v in possible_edge_keys(working_graph):
        u = int(u)
        v = int(v)

        if edge_order(working_graph, u, v) > 0.0:
            attrs = edge_template_attrs(working_graph, u, v)

            if working_graph.has_edge(u, v):
                attrs.update(_edge_data(working_graph, u, v))

            attrs = normalize_edge_attrs(attrs)
            full.add_edge(u, v, **attrs)

        elif full.has_edge(u, v):
            full.remove_edge(u, v)


def materialize_full_graph(
    working_graph: nx.Graph,
    *,
    recompute_charge: bool | None = None,
    refresh_neighbors: bool = True,
    strict_neighbor_cache: bool = False,
) -> nx.Graph:
    """
    Materialize a full molecular graph from a workspace graph.

    Charge recomputation is done only after edge updates and optional neighbor
    cache refresh.
    """
    base = working_graph.graph.get("full_reference_graph")

    if base is None:
        return _materialize_without_reference(
            working_graph,
            recompute_charge=recompute_charge,
            refresh_neighbors=refresh_neighbors,
            strict_neighbor_cache=strict_neighbor_cache,
        )

    full = copy.deepcopy(base)
    workspace_nodes = _materialization_workspace_nodes(working_graph)

    _copy_workspace_node_attrs(full, working_graph, workspace_nodes)
    _sync_workspace_edges(full, working_graph)

    affected_nodes = _expanded_local_nodes(full, workspace_nodes)

    if refresh_neighbors:
        refresh_neighbor_cache(full, affected_nodes, inplace=True)

    use_recompute = True if recompute_charge is None else bool(recompute_charge)

    if use_recompute:
        update_charge_local(
            full,
            affected_nodes,
            inplace=True,
            order_key="order",
            strict_neighbor_cache=strict_neighbor_cache,
            refresh_neighbors=refresh_neighbors,
        )

    return full


def _edge_attrs_for_signature(g: nx.Graph, u: int, v: int) -> Dict[str, Any]:
    attrs = edge_template_attrs(g, u, v)

    if g.has_edge(u, v):
        attrs.update(_edge_data(g, u, v))

    return normalize_edge_attrs(attrs)


def _is_resonance_edge_like(attrs: Dict[str, Any]) -> bool:
    attrs = normalize_edge_attrs(attrs)
    order = _as_float(attrs.get("order", attrs.get("kekule_order", 0.0)), 0.0)
    kekule = _as_float(attrs.get("kekule_order", order), order)
    bond_type = str(attrs.get("bond_type", "") or "").upper()
    conjugated = _as_bool(attrs.get("conjugated", False), False)

    return (
        conjugated
        or abs(order - 1.5) < 1e-8
        or abs(kekule - 1.5) < 1e-8
        or order >= 2.0
        or kekule >= 2.0
        or bond_type in {"DOUBLE", "TRIPLE", "AROMATIC"}
    )


def _is_resonance_eligible_edge(g: nx.Graph, u: int, v: int) -> bool:
    current_attrs = normalize_edge_attrs(_edge_data(g, u, v)) if g.has_edge(u, v) else {}
    template_attrs = normalize_edge_attrs(edge_template_attrs(g, u, v))

    return _is_resonance_edge_like(current_attrs) or _is_resonance_edge_like(template_attrs)


class StateCodec:
    def _ignore_electron_metadata_for_node(self, g: nx.Graph, n: int) -> bool:
        """Return True when LP/charge should be ignored for node ``n``."""
        if _as_bool(g.graph.get("ignore_charge_in_signature", False), False) and _as_bool(
            g.graph.get("ignore_lp_in_signature", False), False
        ):
            return True

        if not _as_bool(
            g.graph.get("ignore_aromatic_electron_metadata_in_signature", False),
            False,
        ):
            return False

        try:
            if _as_bool(g.nodes[int(n)].get("aromatic", False), False):
                return True

            for nbr in g.neighbors(int(n)):
                edata = _edge_data(g, int(n), int(nbr))

                if (
                    _as_bool(edata.get("conjugated", False), False)
                    or str(edata.get("bond_type", "")).upper() == "AROMATIC"
                ):
                    return True

        except Exception:
            return False

        return False

    def _node_lp_for_signature(self, g: nx.Graph, n: int) -> int:
        if _as_bool(g.graph.get("ignore_lp_in_signature", False), False):
            return 0

        if self._ignore_electron_metadata_for_node(g, int(n)):
            return 0

        # Expanded-valence atoms (e.g. sulfone S) tagged at search init: their
        # LP is not tracked per-step by operators, so exclude from signature.
        if int(n) in g.graph.get("expanded_valence_atoms", frozenset()):
            return 0

        # charge_stable_bond_gain_atoms: LP-/B+ sinks and concerted-mechanism
        # bases (e.g. O accepting two H's in a pericyclic elimination) donate
        # their LP during the search but the ITS shows stable LP (synkit doesn't
        # track LP changes on spectator heteroatoms). Exempt from LP signature
        # so the mechanism can be found despite the LP bookkeeping mismatch.
        if int(n) in g.graph.get("charge_stable_bond_gain_atoms", frozenset()):
            return 0

        return get_lp(g, int(n))

    def _node_charge_for_signature(self, g: nx.Graph, n: int) -> int:
        if _as_bool(g.graph.get("ignore_charge_in_signature", False), False):
            return 0

        if self._ignore_electron_metadata_for_node(g, int(n)):
            return 0

        # Atoms that net-gain bond order in the ITS while keeping stable charge,
        # LP, and hcount (LP-/B+ sink). The ΔFC formula assigns charge=-1 due
        # to Δkekule=+1, but the electrons came from the donor so the product
        # atom stays neutral. Tagged at search init in enumerate_from_its.
        if int(n) in g.graph.get("charge_stable_bond_gain_atoms", frozenset()):
            return 0
        # Legacy key name — kept for backward compatibility with cached graphs.
        if int(n) in g.graph.get("aromatic_bond_gain_atoms", frozenset()):
            return 0

        return get_charge(g, int(n))

    def _node_hcount_for_signature(self, g: nx.Graph, n: int) -> int:
        if _as_bool(g.graph.get("ignore_hcount_in_signature", False), False):
            return 0

        return get_h(g, int(n))

    def graph_signature(self, g: nx.Graph) -> Tuple[Any, ...]:
        nodes = sorted(int(n) for n in g.graph.get("workspace_nodes", g.nodes()) if int(n) in g)

        node_sig = tuple(
            (
                n,
                atom_element(g, n),
                g.nodes[n].get("atom_map", n),
                self._node_hcount_for_signature(g, n),
                self._node_lp_for_signature(g, n),
                self._node_charge_for_signature(g, n),
                get_radical(g, n),
            )
            for n in nodes
        )

        edge_sig = tuple(
            sorted(
                (
                    int(u),
                    int(v),
                    round(float(edge_order(g, u, v)), 3),
                )
                for u, v in possible_edge_keys(g)
                if edge_order(g, u, v) > 0.0
            )
        )

        return node_sig, edge_sig

    def _freeze_memory_value(self, value: Any) -> Any:
        if isinstance(value, list):
            return tuple(self._freeze_memory_value(v) for v in value)

        if isinstance(value, tuple):
            return tuple(self._freeze_memory_value(v) for v in value)

        if isinstance(value, dict):
            return tuple(sorted((k, self._freeze_memory_value(v)) for k, v in value.items()))

        if isinstance(value, set):
            return tuple(sorted(self._freeze_memory_value(v) for v in value))

        return value

    def memory_signature(self, memory: dict) -> Tuple[Any, ...]:
        ignored = {
            "smiles",
            "state_smiles",
            "validity_history",
            "smiles_history",
            "last_valid_depth",
            "validity_checked",
            "last_graph_valid",
            "validity_gap",
            "valid_window",
            "first_window_pending",
            "checkpoint_arrows",
            "checkpoint_pattern",
            "checkpoint_index",
            "checkpoint_checked",
            "checkpoint_depths",
            "checkpoint_validity",
            "arrow_boundary_reached",
            "arrow_step_index",
            "flow_anchor_atom",
            "flow_frontier_atoms",
            "last_transition_kind",
            "last_touched_atoms",
            "frontier_mode",
            "frontier_kind",
            "frontier_status",
            "frontier_anchor_atom",
            "frontier_basin_atoms",
            "frontier_required",
            "frontier_reason",
        }

        items = []

        for k, v in sorted(memory.items()):
            if k in ignored:
                continue

            items.append((k, self._freeze_memory_value(v)))

        return tuple(items)

    def signature(self, state: StateSnapshot) -> Tuple[Any, ...]:
        return self.graph_signature(state.graph), self.memory_signature(state.memory)


class ContextResonanceStateCodec(StateCodec):
    """
    Exact state codec with optional k-context resonance collapsing.

    When ``k > 0``, this codec collapses Lewis microstates that differ only by
    electron redistribution inside a context resonance manifold.
    """

    def __init__(
        self,
        *,
        collapse_when_k_positive: bool = True,
        include_hetero_rc_boundary: bool = True,
        hetero_elements: Optional[Iterable[str]] = None,
    ) -> None:
        super().__init__()
        self.collapse_when_k_positive = bool(collapse_when_k_positive)
        self.include_hetero_rc_boundary = bool(include_hetero_rc_boundary)
        self.hetero_elements = set(hetero_elements or {"O", "N", "S", "P"})

    def _workspace_nodes(self, g: nx.Graph) -> Set[int]:
        return {int(n) for n in g.graph.get("workspace_nodes", g.nodes()) if int(n) in g}

    def _rc_edges(self, g: nx.Graph) -> Set[EdgeKey]:
        return {canonical_edge(int(u), int(v)) for u, v in g.graph.get("rc_edges", set())}

    def _iter_workspace_non_rc_edges(
        self,
        g: nx.Graph,
        workspace_nodes: Set[int],
        rc_edges: Set[EdgeKey],
    ) -> Iterable[EdgeKey]:
        for u, v in possible_edge_keys(g):
            u = int(u)
            v = int(v)
            key = canonical_edge(u, v)

            if u not in workspace_nodes or v not in workspace_nodes:
                continue

            if key in rc_edges:
                continue

            yield key

    def _seed_resonance_graph(
        self,
        g: nx.Graph,
        workspace_nodes: Set[int],
        rc_edges: Set[EdgeKey],
    ) -> Tuple[nx.Graph, bool]:
        h = nx.Graph()
        h.add_nodes_from(workspace_nodes)

        seed_found = False

        for u, v in self._iter_workspace_non_rc_edges(g, workspace_nodes, rc_edges):
            if _is_resonance_eligible_edge(g, u, v):
                h.add_edge(u, v)
                seed_found = True

        return h, seed_found

    def _component_nodes_from_graph(self, h: nx.Graph) -> Set[int]:
        return {int(n) for edge in h.edges() for n in edge}

    def _should_expand_across_rc(
        self,
        g: nx.Graph,
        u: int,
        v: int,
        workspace_nodes: Set[int],
        component_nodes: Set[int],
        rc_edges: Set[EdgeKey],
    ) -> bool:
        key = canonical_edge(u, v)

        if key not in rc_edges:
            return False

        if not ((u in component_nodes) ^ (v in component_nodes)):
            return False

        outside = v if u in component_nodes else u

        if outside not in workspace_nodes:
            return False

        return atom_element(g, outside) in self.hetero_elements

    def _expand_hetero_rc_boundary(
        self,
        g: nx.Graph,
        h: nx.Graph,
        workspace_nodes: Set[int],
        rc_edges: Set[EdgeKey],
    ) -> None:
        changed = True

        while changed:
            changed = False
            component_nodes = self._component_nodes_from_graph(h)

            for u, v in possible_edge_keys(g):
                u = int(u)
                v = int(v)

                if self._should_expand_across_rc(
                    g,
                    u,
                    v,
                    workspace_nodes,
                    component_nodes,
                    rc_edges,
                ):
                    if not h.has_edge(u, v):
                        h.add_edge(u, v)
                        changed = True

    def _context_resonance_components(self, g: nx.Graph) -> List[Set[int]]:
        workspace_nodes = self._workspace_nodes(g)
        rc_edges = self._rc_edges(g)

        h, seed_found = self._seed_resonance_graph(g, workspace_nodes, rc_edges)

        if self.include_hetero_rc_boundary and seed_found:
            self._expand_hetero_rc_boundary(g, h, workspace_nodes, rc_edges)

        if h.number_of_edges() == 0:
            return []

        return [{int(n) for n in comp} for comp in nx.connected_components(h.edge_subgraph(h.edges()).copy())]

    def _collapsed_exact_node_signature(
        self,
        g: nx.Graph,
        workspace_nodes: List[int],
        collapsed_nodes: Set[int],
    ) -> Tuple[Any, ...]:
        return tuple(
            (
                n,
                atom_element(g, n),
                g.nodes[n].get("atom_map", n),
                self._node_hcount_for_signature(g, n),
                self._node_lp_for_signature(g, n),
                self._node_charge_for_signature(g, n),
                get_radical(g, n),
            )
            for n in workspace_nodes
            if n not in collapsed_nodes
        )

    def _component_skeleton(
        self,
        g: nx.Graph,
        comp: Set[int],
    ) -> Tuple[Any, ...]:
        return tuple(
            sorted(
                (
                    int(n),
                    atom_element(g, n),
                    g.nodes[n].get("atom_map", n),
                    self._node_hcount_for_signature(g, n),
                    bool(g.nodes[n].get("rc", False)),
                )
                for n in comp
            )
        )

    def _component_internal_edge_summary(
        self,
        g: nx.Graph,
        comp: Set[int],
    ) -> Tuple[Tuple[EdgeKey, ...], float]:
        internal_edges: List[EdgeKey] = []
        total_internal_order = 0.0

        for u, v in possible_edge_keys(g):
            u = int(u)
            v = int(v)

            if u not in comp or v not in comp:
                continue

            order = float(edge_order(g, u, v))

            if order <= 0.0:
                continue

            internal_edges.append(canonical_edge(u, v))
            total_internal_order += order

        return tuple(sorted(set(internal_edges))), round(total_internal_order, 3)

    def _component_signature(
        self,
        g: nx.Graph,
        comp: Set[int],
    ) -> Tuple[Any, ...]:
        internal_edges, total_internal_order = self._component_internal_edge_summary(
            g,
            comp,
        )

        return (
            "res_component",
            self._component_skeleton(g, comp),
            int(sum(self._node_hcount_for_signature(g, n) for n in comp)),
            int(sum(self._node_lp_for_signature(g, n) for n in comp)),
            int(sum(self._node_charge_for_signature(g, n) for n in comp)),
            int(sum(get_radical(g, n) for n in comp)),
            total_internal_order,
            internal_edges,
        )

    def _component_signatures(
        self,
        g: nx.Graph,
        components: List[Set[int]],
    ) -> Tuple[Any, ...]:
        return tuple(sorted(self._component_signature(g, comp) for comp in components))

    def _collapsed_exact_edge_signature(
        self,
        g: nx.Graph,
        node_to_component: Dict[int, int],
    ) -> Tuple[Any, ...]:
        edge_sig = []

        for u, v in possible_edge_keys(g):
            u = int(u)
            v = int(v)

            if edge_order(g, u, v) <= 0.0:
                continue

            same_component = (
                u in node_to_component and v in node_to_component and node_to_component[u] == node_to_component[v]
            )

            if same_component:
                continue

            edge_sig.append((u, v, round(float(edge_order(g, u, v)), 3)))

        return tuple(sorted(edge_sig))

    def _collapsed_graph_signature(self, g: nx.Graph) -> Tuple[Any, ...]:
        workspace_nodes = sorted(int(n) for n in g.graph.get("workspace_nodes", g.nodes()) if int(n) in g)
        components = self._context_resonance_components(g)

        node_to_component: Dict[int, int] = {}

        for comp_idx, comp in enumerate(components):
            for n in comp:
                node_to_component[int(n)] = int(comp_idx)

        collapsed_nodes = set(node_to_component)

        exact_node_sig = self._collapsed_exact_node_signature(
            g,
            workspace_nodes,
            collapsed_nodes,
        )
        component_sigs = self._component_signatures(g, components)
        exact_edge_sig = self._collapsed_exact_edge_signature(g, node_to_component)

        return exact_node_sig, component_sigs, exact_edge_sig

    def graph_signature(self, g: nx.Graph) -> Tuple[Any, ...]:
        if self.collapse_when_k_positive and int(g.graph.get("k", 0)) <= 0:
            return super().graph_signature(g)

        return self._collapsed_graph_signature(g)
