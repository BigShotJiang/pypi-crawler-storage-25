"""SynKit-backed reaction graph and ITS construction utilities.

This module is the canonical IO boundary for SynEltra.  It converts a mapped
reaction SMILES (RSMI) into the reactant/product graph pair and the ITS graph
used by the mechanism search layer.  SynKit is imported lazily so that the
rest of the package can still be inspected without SynKit installed.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, List, Optional, Sequence, Tuple

import networkx as nx

from .endpoint import build_endpoint_states_from_its
from .workspace import RCWorkspaceBuilder, WorkspaceMode
from ..core.models import StateSnapshot, Trajectory

DEFAULT_NODE_ATTRS: Tuple[str, ...] = (
    "element",
    "aromatic",
    "hcount",
    "charge",
    "neighbors",
    "hybridization",
    "atom_map",
    "lone_pairs",
    "valence_electrons",
    "partial_charge",
    "oxidation_state",
)

DEFAULT_EDGE_ATTRS: Tuple[str, ...] = (
    "kekule_order",
    "order",
    "bond_type",
    "conjugated",
    "in_ring",
)


@dataclass(frozen=True)
class ReactionGraphBundle:
    """Container for the SynKit graph representation of one reaction.

    :param reactant_graph: Reactant-side graph.
    :param product_graph: Product-side graph.
    :param its: Imaginary transition-state graph from SynKit.
    :param node_attrs: Node attributes requested from SynKit.
    :param edge_attrs: Edge attributes requested from SynKit.
    """

    reactant_graph: nx.Graph
    product_graph: nx.Graph
    its: nx.Graph
    node_attrs: Tuple[str, ...] = DEFAULT_NODE_ATTRS
    edge_attrs: Tuple[str, ...] = DEFAULT_EDGE_ATTRS


def _as_tuple(values: Optional[Iterable[str]], default: Sequence[str]) -> Tuple[str, ...]:
    if values is None:
        return tuple(default)
    return tuple(str(x) for x in values)


def rsmi_to_reaction_graphs(
    rsmi: str,
    *,
    node_attrs: Optional[Iterable[str]] = None,
    edge_attrs: Optional[Iterable[str]] = None,
    drop_non_aam: bool = False,
    use_index_as_atom_map: bool = True,
    **kwargs,
) -> Tuple[nx.Graph, nx.Graph]:
    """Convert a mapped reaction SMILES into reactant and product graphs.

    This is a thin, explicit wrapper around :func:`synkit.IO.rsmi_to_graph`
    with SynEltra's preferred chemistry attributes as defaults.
    """

    try:
        from synkit.IO import rsmi_to_graph
    except Exception as exc:  # pragma: no cover - optional dependency path
        raise ImportError(
            "rsmi_to_reaction_graphs requires SynKit. Install/enable synkit "
            "or pass prebuilt graphs to enumerate_from_graphs()."
        ) from exc

    selected_node_attrs = _as_tuple(node_attrs, DEFAULT_NODE_ATTRS)
    selected_edge_attrs = _as_tuple(edge_attrs, DEFAULT_EDGE_ATTRS)
    return rsmi_to_graph(
        rsmi,
        node_attrs=list(selected_node_attrs),
        edge_attrs=list(selected_edge_attrs),
        drop_non_aam=bool(drop_non_aam),
        use_index_as_atom_map=bool(use_index_as_atom_map),
        **kwargs,
    )


def construct_its_from_graphs(
    reactant_graph: nx.Graph,
    product_graph: nx.Graph,
    *,
    node_attrs: Optional[Iterable[str]] = None,
    edge_attrs: Optional[Iterable[str]] = None,
    its_constructor=None,
) -> nx.Graph:
    """Construct an ITS graph from a reactant/product graph pair."""

    selected_node_attrs = _as_tuple(node_attrs, DEFAULT_NODE_ATTRS)
    selected_edge_attrs = _as_tuple(edge_attrs, DEFAULT_EDGE_ATTRS)
    if its_constructor is None:
        try:
            from synkit.Graph.ITS.its_construction import ITSConstruction
        except Exception as exc:  # pragma: no cover - optional dependency path
            raise ImportError("construct_its_from_graphs requires SynKit's ITSConstruction.") from exc
        its_constructor = ITSConstruction()

    return its_constructor.construct(
        reactant_graph,
        product_graph,
        node_attrs=list(selected_node_attrs),
        edge_attrs=list(selected_edge_attrs),
    )


def rsmi_to_its(
    rsmi: str,
    *,
    node_attrs: Optional[Iterable[str]] = None,
    edge_attrs: Optional[Iterable[str]] = None,
    drop_non_aam: bool = False,
    use_index_as_atom_map: bool = True,
    its_constructor=None,
    **kwargs,
) -> nx.Graph:
    """Convert RSMI directly to a SynKit ITS graph."""

    selected_node_attrs = _as_tuple(node_attrs, DEFAULT_NODE_ATTRS)
    selected_edge_attrs = _as_tuple(edge_attrs, DEFAULT_EDGE_ATTRS)
    r_graph, p_graph = rsmi_to_reaction_graphs(
        rsmi,
        node_attrs=selected_node_attrs,
        edge_attrs=selected_edge_attrs,
        drop_non_aam=drop_non_aam,
        use_index_as_atom_map=use_index_as_atom_map,
        **kwargs,
    )
    return construct_its_from_graphs(
        r_graph,
        p_graph,
        node_attrs=selected_node_attrs,
        edge_attrs=selected_edge_attrs,
        its_constructor=its_constructor,
    )


def rsmi_to_reaction_bundle(
    rsmi: str,
    *,
    node_attrs: Optional[Iterable[str]] = None,
    edge_attrs: Optional[Iterable[str]] = None,
    drop_non_aam: bool = False,
    use_index_as_atom_map: bool = True,
    its_constructor=None,
    **kwargs,
) -> ReactionGraphBundle:
    """Return reactant graph, product graph, and ITS graph for one RSMI."""

    selected_node_attrs = _as_tuple(node_attrs, DEFAULT_NODE_ATTRS)
    selected_edge_attrs = _as_tuple(edge_attrs, DEFAULT_EDGE_ATTRS)
    r_graph, p_graph = rsmi_to_reaction_graphs(
        rsmi,
        node_attrs=selected_node_attrs,
        edge_attrs=selected_edge_attrs,
        drop_non_aam=drop_non_aam,
        use_index_as_atom_map=use_index_as_atom_map,
        **kwargs,
    )
    its = construct_its_from_graphs(
        r_graph,
        p_graph,
        node_attrs=selected_node_attrs,
        edge_attrs=selected_edge_attrs,
        its_constructor=its_constructor,
    )
    return ReactionGraphBundle(
        reactant_graph=r_graph,
        product_graph=p_graph,
        its=its,
        node_attrs=selected_node_attrs,
        edge_attrs=selected_edge_attrs,
    )


def endpoint_states_from_rsmi(
    rsmi: str,
    *,
    k: int = 0,
    mode: WorkspaceMode = "reactant",
    include_product_context: bool = False,
    workspace_builder: Optional[RCWorkspaceBuilder] = None,
    node_attrs: Optional[Iterable[str]] = None,
    edge_attrs: Optional[Iterable[str]] = None,
    drop_non_aam: bool = False,
    use_index_as_atom_map: bool = True,
    its_constructor=None,
    **kwargs,
) -> Tuple[StateSnapshot, StateSnapshot, object, nx.Graph, nx.Graph, nx.Graph]:
    """Build start/goal mechanism states directly from a mapped RSMI."""

    its = rsmi_to_its(
        rsmi,
        node_attrs=node_attrs,
        edge_attrs=edge_attrs,
        drop_non_aam=drop_non_aam,
        use_index_as_atom_map=use_index_as_atom_map,
        its_constructor=its_constructor,
        **kwargs,
    )
    return build_endpoint_states_from_its(
        its=its,
        k=k,
        mode=mode,
        include_product_context=include_product_context,
        workspace_builder=workspace_builder,
    )


def print_reaction_graph_attributes(bundle: ReactionGraphBundle) -> None:
    """Debug helper that delegates to SynKit's graph attribute printer."""

    try:
        from synkit.Graph import print_graph_attributes
    except Exception as exc:  # pragma: no cover - optional dependency path
        raise ImportError("print_reaction_graph_attributes requires SynKit.") from exc
    print_graph_attributes(bundle.reactant_graph)
    print_graph_attributes(bundle.product_graph)
    print_graph_attributes(bundle.its)


def rsmi_to_trajs(
    rsmi: str,
    *,
    family: Optional[str] = None,
    k: int = 0,
    max_depth: int = 20,
    beam_width: int = 64,
    max_results: int = 20,
    electronic_mode: str = "fmo-hsab-resonance",
    node_attrs: Optional[Iterable[str]] = None,
    edge_attrs: Optional[Iterable[str]] = None,
) -> List[Trajectory]:
    """Enumerate and rank all trajectories for a mapped reaction SMILES.

    One-stop convenience function: builds the ITS, runs beam search, ranks by
    family-specific scorer, and returns trajectories sorted best-first so that
    ``trajs[0]`` is the best mechanism and ``trajs[0].graphs()`` gives the
    intermediate state graphs.

    Parameters
    ----------
    rsmi:
        Atom-mapped reaction SMILES (``reactants>>products``).
    family:
        Mechanism family for ranking (``"polar"``, ``"pericyclic"``,
        ``"radical"``).  Auto-inferred from the ITS when ``None``.
    k:
        Context-expansion radius passed to the workspace builder.
    max_depth:
        Maximum arrow-step depth for the beam search.
    beam_width:
        Beam width; wider beams find more diverse trajectories at higher cost.
    max_results:
        Maximum number of trajectories returned by the enumerator before
        ranking.
    electronic_mode:
        Electronic scoring mode forwarded to the ranker
        (e.g. ``"fmo-hsab-resonance"``, ``"consensus"``).
    node_attrs / edge_attrs:
        Attribute lists forwarded to SynKit graph construction.  Defaults to
        :data:`DEFAULT_NODE_ATTRS` / :data:`DEFAULT_EDGE_ATTRS`.

    Returns
    -------
    List[Trajectory]
        Trajectories sorted best-first.  Empty list when no mechanism is found.

    Examples
    --------
    >>> trajs = rsmi_to_trajs("[CH3:1][Br:2].[OH-:3]>>[CH3:1][OH:3].[Br-:2]")
    >>> best = trajs[0]
    >>> graphs = best.graphs()          # list of nx.Graph per step
    >>> graphs_full = best.graphs(full=True)  # full molecular graphs
    """
    from ..search.enumerator import MechanismEnumerator
    from ..ranker import TrajectoryRankerFactory
    from ..mechanism.planner import ITSPlanner

    bundle = rsmi_to_reaction_bundle(
        rsmi,
        node_attrs=node_attrs,
        edge_attrs=edge_attrs,
    )

    trajectories: List[Trajectory] = MechanismEnumerator().enumerate_from_its(
        its=bundle.its,
        k=k,
        max_depth=max_depth,
        beam_width=beam_width,
        max_results=max_results,
        context_proposal_mode="adaptive",
    )

    if not trajectories:
        return []

    _VALID_FAMILIES = {"polar", "pericyclic", "radical"}
    _inferred = (family or ITSPlanner().classify(bundle.reactant_graph, bundle.product_graph)).lower()
    resolved_family = _inferred if _inferred in _VALID_FAMILIES else "polar"

    result = TrajectoryRankerFactory.create(
        resolved_family,
        graph=bundle.reactant_graph,
        electronic_mode=electronic_mode,
    ).rank(trajectories)

    return list(result.new_order_trajs)
