from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Tuple

import networkx as nx

from .graph import atom_element, canonical_edge, edge_order, get_lp, possible_edge_keys


@dataclass(frozen=True)
class BondCandidate:
    """Representative bond-level candidate used for adaptive context search.

    :param edge: Candidate bond edge.
    :type edge: Tuple[int, int]
    :param origin: Proposal origin such as ``"goal"`` or ``"generic_context"``.
    :type origin: str
    :param role: Coarse context role, for example ``"proton_source"`` or
        ``"aromatic_target"``.
    :type role: str
    :param distance: Graph distance from the reaction core.
    :type distance: int
    :param representative_size: Number of explicit candidates compressed into
        this representative.
    :type representative_size: int
    :param class_id: Stable class identifier used for debugging and scoring.
    :type class_id: str
    :param aromatic_position_class: Optional aromatic positional label such as
        ``"ortho"`` or ``"para"``.
    :type aromatic_position_class: Optional[str]
    :param score_hint: Lightweight score hint used before the main ranker runs.
    :type score_hint: float
    :param metadata: Additional metadata copied into the transition payload.
    :type metadata: Dict[str, object] | None
    """

    edge: Tuple[int, int]
    origin: str
    role: str
    distance: int
    representative_size: int = 1
    class_id: str = ""
    aromatic_position_class: Optional[str] = None
    score_hint: float = 0.0
    metadata: Dict[str, object] | None = None

    def payload(self) -> Dict[str, object]:
        """Return transition payload metadata for this candidate."""
        data: Dict[str, object] = {
            "proposal_origin": self.origin,
            "context_role": self.role,
            "context_distance": int(self.distance),
            "representative_size": int(self.representative_size),
            "context_class_id": str(self.class_id or ""),
            "context_score_hint": float(self.score_hint),
        }

        if self.aromatic_position_class:
            data["aromatic_position_class"] = str(self.aromatic_position_class)

        if self.metadata:
            data.update(dict(self.metadata))

        return data


@dataclass(frozen=True)
class ContextSourceConfig:
    """Configuration extracted from graph metadata for context proposals."""

    mode: str
    rc_nodes: frozenset[int]
    rc_edges: frozenset[Tuple[int, int]]
    shell_radius: int
    max_classes: int
    adaptive: bool
    k: int
    conjugation_only: bool


def _norm_element(graph: nx.Graph, atom: int) -> str:
    return atom_element(graph, int(atom))


def _is_aromatic_atom(graph: nx.Graph, atom: int) -> bool:
    atom = int(atom)

    if atom not in graph:
        return False

    if bool(graph.nodes[atom].get("aromatic", False)):
        return True

    for nbr in graph.neighbors(atom):
        data = graph.edges[atom, int(nbr)]
        order = float(data.get("order", 0.0))
        bond_type = str(data.get("bond_type", "")).strip().upper()

        if abs(order - 1.5) < 1e-8 or bond_type == "AROMATIC":
            return True

    return False


def _is_aromatic_edge(graph: nx.Graph, edge: Tuple[int, int]) -> bool:
    u, v = int(edge[0]), int(edge[1])

    if not graph.has_edge(u, v):
        return False

    data = graph.edges[u, v]
    order = float(data.get("order", 0.0))
    bond_type = str(data.get("bond_type", "")).strip().upper()

    has_aromatic_context = (
        (bool(data.get("conjugated", False)) or bool(data.get("in_ring", False)))
        and _is_aromatic_atom(graph, u)
        and _is_aromatic_atom(graph, v)
    )

    return has_aromatic_context or abs(order - 1.5) < 1e-8 or bond_type == "AROMATIC"


def _numeric_edge_attr(data: dict, key: str, default: float = 0.0) -> float:
    try:
        value = data.get(key, default)
        if isinstance(value, (tuple, list)):
            value = value[0] if value else default
        return float(value)
    except Exception:
        return float(default)


def _formal_source_order(graph: nx.Graph, edge: Tuple[int, int]) -> float:
    u, v = int(edge[0]), int(edge[1])

    if not graph.has_edge(u, v):
        return 0.0

    data = graph.edges[u, v]
    order = _numeric_edge_attr(data, "order", 0.0)

    if "formal_order" in data:
        return _numeric_edge_attr(data, "formal_order", order)

    if _is_aromatic_edge(graph, edge) and "kekule_order" in data:
        return _numeric_edge_attr(data, "kekule_order", order)

    return order


def _is_pi_edge(graph: nx.Graph, edge: Tuple[int, int]) -> bool:
    u, v = int(edge[0]), int(edge[1])

    if not graph.has_edge(u, v):
        return False

    data = graph.edges[u, v]
    order = _formal_source_order(graph, edge)
    bond_type = str(data.get("bond_type", "")).strip().upper()

    if _is_aromatic_edge(graph, edge):
        return True

    return order >= 2.0 or (bool(data.get("conjugated", False)) and order >= 1.8) or bond_type in {"DOUBLE", "TRIPLE"}


def _node_signature(graph: nx.Graph, atom: int) -> Tuple[object, ...]:
    atom = int(atom)
    elem = _norm_element(graph, atom)
    charge = int(graph.nodes[atom].get("charge", 0))
    aromatic = bool(graph.nodes[atom].get("aromatic", False))
    degree = int(graph.degree(atom))
    lp = int(get_lp(graph, atom)) if atom in graph else 0
    nbrs = tuple(sorted(_norm_element(graph, int(n)) for n in graph.neighbors(atom)))

    return elem, charge, aromatic, degree, lp, nbrs


def _edge_signature(graph: nx.Graph, edge: Tuple[int, int]) -> Tuple[object, ...]:
    u, v = canonical_edge(int(edge[0]), int(edge[1]))
    sig_u = _node_signature(graph, u)
    sig_v = _node_signature(graph, v)

    if sig_v < sig_u:
        sig_u, sig_v = sig_v, sig_u

    if graph.has_edge(u, v):
        data = graph.edges[u, v]
        order = float(data.get("order", 0.0))
        conjugated = bool(data.get("conjugated", False))
        bond_type = str(data.get("bond_type", "")).strip().upper()
    else:
        order = 0.0
        conjugated = False
        bond_type = ""

    return sig_u, sig_v, round(order, 3), conjugated, bond_type


def _edge_distance_to_rc(
    graph: nx.Graph,
    edge: Tuple[int, int],
    rc_nodes: Iterable[int],
) -> int:
    """Return the shortest finite distance from ``edge`` to any RC node.

    The graph may be disconnected because a reaction complex often contains
    separate reagents, bases, counterions, and leaving groups. Unreachable RC
    nodes are ignored and the minimum finite distance is returned.
    """
    rc = [int(x) for x in rc_nodes if int(x) in graph]

    if not rc:
        return 99

    best = math.inf

    for endpoint in edge:
        endpoint = int(endpoint)

        if endpoint not in graph:
            continue

        for r in rc:
            try:
                dist = nx.shortest_path_length(graph, endpoint, int(r))
            except (nx.NetworkXNoPath, nx.NodeNotFound):
                continue
            except Exception:
                continue

            if dist < best:
                best = dist

                if best == 0:
                    return 0

    return 99 if math.isinf(best) else int(best)


def _aromatic_component(graph: nx.Graph, atom: int) -> Tuple[int, ...]:
    atom = int(atom)

    if atom not in graph or not _is_aromatic_atom(graph, atom):
        return ()

    aromatic_nodes = {int(n) for n in graph.nodes() if _is_aromatic_atom(graph, int(n))}

    sg = graph.subgraph(aromatic_nodes)

    for comp in nx.connected_components(sg):
        if atom in comp:
            return tuple(sorted(int(n) for n in comp))

    return ()


def _component_cycle_order(
    graph: nx.Graph,
    component: Tuple[int, ...],
) -> Tuple[int, ...]:
    if not component:
        return ()

    sg = graph.subgraph(component)
    cycles = nx.cycle_basis(sg)

    if not cycles:
        return tuple(sorted(component))

    cycle = max(cycles, key=len)
    return tuple(int(x) for x in cycle)


def _aromatic_position_class(
    graph: nx.Graph,
    atom: int,
    rc_nodes: Iterable[int],
) -> Optional[str]:
    atom = int(atom)
    comp = _aromatic_component(graph, atom)

    if not comp:
        return None

    cycle = _component_cycle_order(graph, comp)

    if atom not in cycle:
        return "aryl"

    anchors = [int(a) for a in rc_nodes if int(a) in comp]

    if not anchors:
        anchors = [int(a) for a in comp if any(int(nbr) not in comp for nbr in graph.neighbors(int(a)))]

    if not anchors:
        return "aryl"

    n_cycle = len(cycle)
    positions = {a: i for i, a in enumerate(cycle)}
    atom_idx = positions[atom]
    best = n_cycle

    for anchor in anchors:
        if anchor not in positions:
            continue

        anchor_idx = positions[anchor]
        dist = abs(atom_idx - anchor_idx)
        dist = min(dist, n_cycle - dist)

        if dist < best:
            best = dist

    if n_cycle == 6:
        return {
            0: "ipso",
            1: "ortho",
            2: "meta",
            3: "para",
        }.get(best, f"ring_d{best}")

    return f"ring_d{best}"


def _classify_source_role(
    graph: nx.Graph,
    edge: Tuple[int, int],
) -> Tuple[str, float]:
    u, v = int(edge[0]), int(edge[1])
    elems = {_norm_element(graph, u), _norm_element(graph, v)}
    order = _formal_source_order(graph, edge)

    if _is_aromatic_edge(graph, edge):
        return "aromatic_pi", 10.0

    if "H" in elems and (elems & {"F", "CL", "BR", "I", "O", "N", "S"}):
        return "proton_source", 12.0

    if order >= 2.0 and elems & {"O", "N", "S"}:
        return "hetero_pi", 11.0

    if order >= 2.0:
        return "pi_bond", 8.0

    if elems & {"F", "CL", "BR", "I"}:
        return "leaving_group_sigma", 7.0

    if _is_pi_edge(graph, edge):
        return "conjugated_bond", 6.0

    return "adjacent_sigma", 1.5


def _classify_missing_target(
    graph: nx.Graph,
    edge: Tuple[int, int],
    rc_nodes: Iterable[int],
) -> Tuple[str, float, Optional[str]]:
    u, v = int(edge[0]), int(edge[1])
    pos_u = _aromatic_position_class(graph, u, rc_nodes)
    pos_v = _aromatic_position_class(graph, v, rc_nodes)

    aromatic_pos = pos_u or pos_v
    score = 0.0
    role = "goal_missing"

    if aromatic_pos:
        role = "aromatic_target"
        score += {
            "ipso": -3.0,
            "ortho": 5.0,
            "meta": 2.0,
            "para": 6.0,
        }.get(aromatic_pos, 3.0)

    for atom in (u, v):
        if _norm_element(graph, atom) != "C":
            continue

        for nbr in graph.neighbors(atom):
            nbr = int(nbr)

            if _norm_element(graph, nbr) in {"O", "N", "S"} and edge_order(graph, atom, nbr) >= 2.0:
                role = "carbonyl_target"
                score += 8.0

    return role, score, aromatic_pos


def representative_missing_bond_candidates(
    cur: nx.Graph,
    goal: nx.Graph,
) -> List[BondCandidate]:
    """Return representative missing-bond candidates for adaptive context mode.

    The function groups explicit missing bonds into symmetry- and
    environment-aware classes so the search can reason over compressed outside-
    core choices rather than exploding atom-by-atom.

    :param cur: Current search-state graph.
    :type cur: nx.Graph
    :param goal: Goal graph.
    :type goal: nx.Graph
    :return: Representative missing-bond candidates sorted by descending hint
        score.
    :rtype: List[BondCandidate]

    Example
    -------
    .. code-block:: python

        reps = representative_missing_bond_candidates(current_graph, goal_graph)
        for cand in reps[:3]:
            print(cand.edge, cand.role, cand.score_hint)
    """
    rc_nodes = {int(n) for n in cur.graph.get("rc_nodes", set())}
    adaptive = str(cur.graph.get("context_proposal_mode", "none")).lower() == "adaptive"

    raw: List[BondCandidate] = []

    for u, v in possible_edge_keys(cur):
        if edge_order(cur, u, v) >= edge_order(goal, u, v):
            continue

        role, bonus, aromatic_pos = _classify_missing_target(
            goal if goal is not None else cur,
            (u, v),
            rc_nodes,
        )
        dist = _edge_distance_to_rc(cur, (u, v), rc_nodes)
        score = 100.0 + bonus - 1.25 * dist

        # When H-to-heteroatom bonds collapse into one representative, prefer
        # the H that currently comes from N/O/S (amine/alcohol) over aromatic
        # C-H. The former initiates the mechanism; the latter is rearomatization.
        for _a in (u, v):
            if int(_a) in cur and _norm_element(cur, int(_a)) == "H":
                _nbrs = [int(_n) for _n in cur.neighbors(int(_a))]
                if _nbrs and _norm_element(cur, _nbrs[0]) in {
                    "N",
                    "O",
                    "S",
                    "F",
                    "CL",
                    "BR",
                    "I",
                }:
                    score += 5.0
                break

        raw.append(
            BondCandidate(
                edge=canonical_edge(u, v),
                origin="goal",
                role=role,
                distance=dist,
                representative_size=1,
                class_id=f"goal:{u}:{v}",
                aromatic_position_class=aromatic_pos,
                score_hint=score,
            )
        )

    if not adaptive:
        return raw

    grouped: Dict[Tuple[object, ...], List[BondCandidate]] = {}

    for cand in raw:
        edge_sig = _edge_signature(goal if goal is not None else cur, cand.edge)
        key = cand.role, cand.aromatic_position_class, cand.distance, edge_sig
        grouped.setdefault(key, []).append(cand)

    out: List[BondCandidate] = []

    for key, items in grouped.items():
        best = max(items, key=lambda c: c.score_hint)

        out.append(
            BondCandidate(
                edge=best.edge,
                origin=best.origin,
                role=best.role,
                distance=best.distance,
                representative_size=len(items),
                class_id=f"missing:{abs(hash(key))}",
                aromatic_position_class=best.aromatic_position_class,
                score_hint=best.score_hint + min(4.0, 0.75 * (len(items) - 1)),
                metadata={"collapsed_missing_count": len(items)},
            )
        )

    out.sort(key=lambda c: (-c.score_hint, c.distance, c.edge))
    return out


def _context_source_config(cur: nx.Graph) -> ContextSourceConfig:
    mode = str(cur.graph.get("context_proposal_mode", "none")).lower()

    rc_nodes = frozenset(int(n) for n in cur.graph.get("rc_nodes", set()))
    rc_edges = frozenset(canonical_edge(int(u), int(v)) for u, v in cur.graph.get("rc_edges", set()))

    return ContextSourceConfig(
        mode=mode,
        rc_nodes=rc_nodes,
        rc_edges=rc_edges,
        shell_radius=int(cur.graph.get("context_shell_radius", 2)),
        max_classes=int(cur.graph.get("context_max_classes", 8)),
        adaptive=mode == "adaptive",
        k=int(cur.graph.get("k", 0)),
        conjugation_only=bool(cur.graph.get("context_conjugation_only", True)),
    )


def _context_edge_is_allowed_by_distance(
    cfg: ContextSourceConfig,
    distance: int,
) -> bool:
    if cfg.mode == "adjacent_rc" and distance > 1:
        return False

    if cfg.adaptive and distance > cfg.shell_radius:
        return False

    return True


def _context_edge_is_allowed_by_conjugation(
    cur: nx.Graph,
    edge: Tuple[int, int],
    cfg: ContextSourceConfig,
) -> bool:
    if not cfg.adaptive:
        return True

    if cfg.k <= 0:
        return True

    if not cfg.conjugation_only:
        return True

    return _is_pi_edge(cur, edge)


def _context_aromatic_position_class(
    cur: nx.Graph,
    edge: Tuple[int, int],
    role: str,
    rc_nodes: Iterable[int],
) -> Optional[str]:
    if role != "aromatic_pi":
        return None

    return _aromatic_position_class(
        cur,
        edge[0],
        rc_nodes,
    ) or _aromatic_position_class(
        cur,
        edge[1],
        rc_nodes,
    )


def _context_source_score(role: str, base: float, distance: int) -> float:
    score = base - 1.5 * max(0, distance - 1)

    if role == "adjacent_sigma" and distance > 1:
        score -= 3.0

    return score


def _build_context_source_candidate(
    cur: nx.Graph,
    goal: nx.Graph,
    edge: Tuple[int, int],
    cfg: ContextSourceConfig,
) -> Optional[BondCandidate]:
    if edge in cfg.rc_edges:
        return None

    u, v = edge

    if edge_order(cur, u, v) <= 0.0:
        return None

    if edge_order(cur, u, v) > edge_order(goal, u, v):
        # Already handled by goal delta; keep context space for unchanged support bonds.
        return None

    distance = _edge_distance_to_rc(cur, edge, cfg.rc_nodes)

    if not _context_edge_is_allowed_by_distance(cfg, distance):
        return None

    if not _context_edge_is_allowed_by_conjugation(cur, edge, cfg):
        return None

    role, base = _classify_source_role(cur, edge)
    aromatic_pos = _context_aromatic_position_class(cur, edge, role, cfg.rc_nodes)
    score = _context_source_score(role, base, distance)

    return BondCandidate(
        edge=edge,
        origin="adjacent_rc" if distance <= 1 else "generic_context",
        role=role,
        distance=distance,
        representative_size=1,
        class_id=f"ctx:{u}:{v}",
        aromatic_position_class=aromatic_pos,
        score_hint=score,
    )


def _context_group_key(
    cur: nx.Graph,
    cand: BondCandidate,
) -> Tuple[object, ...]:
    return (
        cand.role,
        cand.distance,
        cand.aromatic_position_class,
        _edge_signature(cur, cand.edge),
    )


def _collapse_context_group(
    key: Tuple[object, ...],
    items: List[BondCandidate],
) -> BondCandidate:
    best = max(items, key=lambda c: c.score_hint)

    return BondCandidate(
        edge=best.edge,
        origin=best.origin,
        role=best.role,
        distance=best.distance,
        representative_size=len(items),
        class_id=f"ctxclass:{abs(hash(key))}",
        aromatic_position_class=best.aromatic_position_class,
        score_hint=best.score_hint + min(3.0, 0.5 * (len(items) - 1)),
        metadata={"collapsed_context_count": len(items)},
    )


def _collapse_context_candidates(
    cur: nx.Graph,
    raw: List[BondCandidate],
    max_classes: int,
) -> List[BondCandidate]:
    near_rc = [cand for cand in raw if cand.distance <= 1 or str(cand.origin) == "adjacent_rc"]
    far_context = [cand for cand in raw if not (cand.distance <= 1 or str(cand.origin) == "adjacent_rc")]

    grouped: Dict[Tuple[object, ...], List[BondCandidate]] = {}

    for cand in far_context:
        key = _context_group_key(cur, cand)
        grouped.setdefault(key, []).append(cand)

    out = [_collapse_context_group(key, items) for key, items in grouped.items()]
    out.sort(key=lambda c: (-c.score_hint, c.distance, c.edge))

    if max_classes > 0:
        out = out[:max_classes]

    combined = near_rc + out
    combined.sort(key=lambda c: (-c.score_hint, c.distance, c.edge))
    return combined


def context_source_bond_candidates(
    cur: nx.Graph,
    goal: nx.Graph,
) -> List[BondCandidate]:
    """Return representative source-bond candidates near the reaction core.

    :param cur: Current search-state graph.
    :type cur: nx.Graph
    :param goal: Goal graph.
    :type goal: nx.Graph
    :return: Representative bond-source candidates sorted by descending hint
        score.
    :rtype: List[BondCandidate]
    """
    cfg = _context_source_config(cur)

    if cfg.mode == "none":
        return []

    raw: List[BondCandidate] = []

    for u, v in possible_edge_keys(cur):
        edge = canonical_edge(u, v)
        cand = _build_context_source_candidate(cur, goal, edge, cfg)

        if cand is not None:
            raw.append(cand)

    raw.sort(key=lambda c: (-c.score_hint, c.distance, c.edge))

    if not cfg.adaptive:
        return raw

    return _collapse_context_candidates(cur, raw, cfg.max_classes)
