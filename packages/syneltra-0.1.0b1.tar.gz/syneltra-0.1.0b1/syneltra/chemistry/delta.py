from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import networkx as nx

from .graph import canonical_edge, edge_order, get_h, get_radical, possible_edge_keys
from .context import (
    BondCandidate,
    context_source_bond_candidates,
    representative_missing_bond_candidates,
)


@dataclass(frozen=True)
class GoalDelta:
    """
    Lightweight current-vs-goal view used by operator templates.

    Notes
    -----
    This class remains mostly goal-directed for speed, but can optionally
    expose a very narrow class of context bonds: explicit non-RC bonds that are
    adjacent to an RC node. This is useful for intermediates such as carbonyl
    activation where a context bond (e.g. C=O) must be used even though its net
    bond order is unchanged between endpoints.

    It also exposes a small set of helpers for **alternating electron flow**.
    Following the EPD framing, the natural bond-to-bond step is the replacement
    of one edge by a consecutive edge sharing one anchor atom. This is the
    right abstraction for pericyclic and conjugated bond-shift chemistry.
    """

    cur: nx.Graph
    goal: nx.Graph

    def context_proposal_mode(self) -> str:
        return str(self.cur.graph.get("context_proposal_mode", "none"))

    def rc_nodes(self) -> set[int]:
        return {int(n) for n in self.cur.graph.get("rc_nodes", set())}

    def rc_edges(self) -> set[Tuple[int, int]]:
        return {canonical_edge(int(u), int(v)) for u, v in self.cur.graph.get("rc_edges", set())}

    def edge_delta(self, u: int, v: int) -> float:
        return float(edge_order(self.goal, u, v) - edge_order(self.cur, u, v))

    def missing_bond_edges(self) -> List[Tuple[int, int]]:
        """Return edges whose current bond order is below the goal value."""
        out = []
        for u, v in possible_edge_keys(self.cur):
            if edge_order(self.cur, u, v) < edge_order(self.goal, u, v):
                out.append((u, v))
        return out

    def missing_bond_candidates(self) -> List[BondCandidate]:
        """Return representative missing-bond targets for proposal generation."""
        return representative_missing_bond_candidates(self.cur, self.goal)

    def context_source_bond_candidates(self) -> List[BondCandidate]:
        """Return representative reducible context bonds outside the RC."""
        return context_source_bond_candidates(self.cur, self.goal)

    def extra_bond_edges(self) -> List[Tuple[int, int]]:
        """Return edges whose current bond order is above the goal value."""
        out = []
        for u, v in possible_edge_keys(self.cur):
            if edge_order(self.cur, u, v) > edge_order(self.goal, u, v):
                out.append((u, v))
        return out

    def changed_bond_edges(self) -> List[Tuple[int, int]]:
        """Return edges whose bond order differs between current and goal."""
        out = []
        for u, v in possible_edge_keys(self.cur):
            if abs(self.edge_delta(u, v)) > 1e-8:
                out.append((u, v))
        return out

    def adjacent_rc_context_reducible_edges(self) -> List[Tuple[int, int]]:
        """
        Return explicit positive-order context edges adjacent to RC.

        In ``adaptive`` mode this method returns the *representative* context
        edges chosen by :mod:`Mech.context`, while preserving the older
        adjacent-RC behavior for compatibility.
        """
        mode = self.context_proposal_mode()
        if mode == "none":
            return []
        if mode == "adaptive":
            return [cand.edge for cand in self.context_source_bond_candidates()]

        rc_nodes = self.rc_nodes()
        rc_edges = self.rc_edges()
        out = []
        seen = set()
        for u, v in possible_edge_keys(self.cur):
            key = canonical_edge(u, v)
            if key in rc_edges:
                continue
            if edge_order(self.cur, u, v) <= 0.0:
                continue
            if not ({u, v} & rc_nodes):
                continue
            if edge_order(self.cur, u, v) > edge_order(self.goal, u, v):
                continue
            if key not in seen:
                seen.add(key)
                out.append(key)
        return out

    def consecutive_anchor(self, src_edge: Tuple[int, int], dst_edge: Tuple[int, int]) -> Optional[int]:
        """Return the shared anchor atom if two edges are consecutive, else ``None``."""
        shared = set(src_edge) & set(dst_edge)
        if len(shared) != 1:
            return None
        return int(next(iter(shared)))

    def bond_flow_pairs(
        self,
        *,
        include_context_sources: bool = True,
        require_shared_atom: bool = True,
    ) -> List[Tuple[Tuple[int, int], Tuple[int, int], int, str]]:
        """
        Return candidate ``(source_edge, target_edge, anchor_atom, origin)`` pairs.

        The source edge is a bond whose order must decrease now; the target edge
        is a bond whose order must increase now. When ``require_shared_atom`` is
        ``True``, only consecutive bond moves of the form ``xy -> yz`` are
        returned. This is the natural EPD step and is crucial for mechanisms
        such as Diels–Alder, electrocyclizations, and conjugated bond shifts.
        """
        sources: List[Tuple[Tuple[int, int], str, Dict[str, object]]] = [
            (
                canonical_edge(u, v),
                "goal",
                {
                    "proposal_origin": "goal",
                    "context_role": "goal_source",
                    "context_score_hint": 100.0,
                },
            )
            for u, v in self.extra_bond_edges()
        ]
        if include_context_sources:
            for cand in self.context_source_bond_candidates():
                key = canonical_edge(*cand.edge)
                if key not in {edge for edge, _, _ in sources}:
                    sources.append((key, cand.origin, cand.payload()))

        target_cands = self.missing_bond_candidates()
        targets = [(canonical_edge(*cand.edge), cand.payload()) for cand in target_cands]

        out: List[Tuple[Tuple[int, int], Tuple[int, int], int, str, Dict[str, object]]] = []
        seen = set()
        for src_edge, origin, src_meta in sources:
            for dst_edge, dst_meta in targets:
                if src_edge == dst_edge:
                    continue
                anchor = self.consecutive_anchor(src_edge, dst_edge)
                if require_shared_atom and anchor is None:
                    continue
                merged = dict(src_meta)
                merged.update(
                    {
                        "target_context_role": dst_meta.get("context_role"),
                        "target_context_class_id": dst_meta.get("context_class_id"),
                        "target_representative_size": dst_meta.get("representative_size"),
                        "target_aromatic_position_class": dst_meta.get("aromatic_position_class"),
                        "target_context_score_hint": dst_meta.get("context_score_hint", 0.0),
                    }
                )
                if "aromatic_position_class" not in merged and dst_meta.get("aromatic_position_class") is not None:
                    merged["aromatic_position_class"] = dst_meta.get("aromatic_position_class")
                merged["context_score_hint"] = float(src_meta.get("context_score_hint", 0.0)) + float(
                    dst_meta.get("context_score_hint", 0.0)
                )
                record = (
                    src_edge,
                    dst_edge,
                    int(anchor) if anchor is not None else -1,
                    origin,
                    tuple(sorted((str(k), str(v)) for k, v in merged.items())),
                )
                if record not in seen:
                    seen.add(record)
                    out.append(
                        (
                            src_edge,
                            dst_edge,
                            int(anchor) if anchor is not None else -1,
                            origin,
                            merged,
                        )
                    )
        return out

    def signed_vertex_balance(self) -> Dict[int, Tuple[float, float]]:
        """Return ``{atom: (plus, minus)}`` over bond-order deltas only."""
        balance: Dict[int, List[float]] = {}
        for u, v in self.changed_bond_edges():
            delta = self.edge_delta(u, v)
            if abs(delta) <= 1e-8:
                continue
            for atom in (int(u), int(v)):
                if atom not in balance:
                    balance[atom] = [0.0, 0.0]
                if delta > 0:
                    balance[atom][0] += float(delta)
                else:
                    balance[atom][1] += float(-delta)
        return {atom: (vals[0], vals[1]) for atom, vals in balance.items()}

    def is_bond_flow_balanced(self) -> bool:
        """Return ``True`` if the bond-only difference graph satisfies ``d+ == d-`` at every atom."""
        return all(abs(pos - neg) <= 1e-8 for pos, neg in self.signed_vertex_balance().values())

    def _workspace_nodes(self) -> List[int]:
        nodes = self.cur.graph.get("workspace_nodes")
        if nodes:
            return [int(n) for n in sorted(nodes) if int(n) in self.cur and int(n) in self.goal]
        return [int(n) for n in self.cur.nodes() if int(n) in self.goal]

    def nodes_needing_h(self) -> List[int]:
        """Return workspace nodes whose hydrogen count is below the goal value."""
        return [n for n in self._workspace_nodes() if get_h(self.cur, n) < get_h(self.goal, n)]

    def nodes_with_extra_h(self) -> List[int]:
        """Return workspace nodes whose hydrogen count is above the goal value."""
        return [n for n in self._workspace_nodes() if get_h(self.cur, n) > get_h(self.goal, n)]

    def nodes_needing_radical(self) -> List[int]:
        """Return workspace nodes whose radical electron count is below the goal value."""
        return [n for n in self._workspace_nodes() if get_radical(self.cur, n) < get_radical(self.goal, n)]

    def nodes_with_extra_radical(self) -> List[int]:
        """Return workspace nodes whose radical electron count is above the goal value."""
        return [n for n in self._workspace_nodes() if get_radical(self.cur, n) > get_radical(self.goal, n)]
