from __future__ import annotations

from typing import Dict, Optional

import networkx as nx

from .base import BaseTrajectoryRanker
from .family import TrajectoryFamily
from .pericyclic import PericyclicTrajectoryRanker
from .polar import PolarTrajectoryRanker
from .radical import RadicalTrajectoryRanker


class TrajectoryRankerFactory:
    """Factory for family-specific trajectory rankers."""

    @staticmethod
    def create(
        family: str | TrajectoryFamily,
        graph: nx.Graph,
        elementary_arrows: Optional[int] = None,
        weights: Optional[Dict[str, float]] = None,
        electronic_mode: Optional[str] = None,
    ) -> BaseTrajectoryRanker:
        """Create a family-specific trajectory ranker.

        :param family: Mechanism family name or enum value.
        :type family: str | TrajectoryFamily
        :param graph: Reference graph used by the ranker.
        :type graph: nx.Graph
        :param elementary_arrows: Size of the elementary event block for the
            ranker. When omitted, a family-specific default is used.
        :type elementary_arrows: Optional[int]
        :param weights: Optional weight overrides for the selected ranker.
        :type weights: Optional[Dict[str, float]]
        :param electronic_mode: Optional override for the electronic guidance
            mode.
        :type electronic_mode: Optional[str]
        :return: Instantiated trajectory ranker.
        :rtype: BaseTrajectoryRanker

        Example
        -------
        .. code-block:: python

            from Mech.ranker import TrajectoryRankerFactory

            ranker = TrajectoryRankerFactory.create(
                "polar",
                graph=r_graph,
                electronic_mode="consensus",
            )
        """
        if not isinstance(family, TrajectoryFamily):
            family = TrajectoryFamily(str(family).lower())

        if family is TrajectoryFamily.POLAR:
            return PolarTrajectoryRanker(
                graph=graph,
                elementary_arrows=2 if elementary_arrows is None else elementary_arrows,
                weights=weights,
                electronic_mode=electronic_mode,
            )
        if family is TrajectoryFamily.PERICYCLIC:
            return PericyclicTrajectoryRanker(
                graph=graph,
                elementary_arrows=3 if elementary_arrows is None else elementary_arrows,
                weights=weights,
                electronic_mode=electronic_mode,
            )
        if family is TrajectoryFamily.RADICAL:
            return RadicalTrajectoryRanker(
                graph=graph,
                elementary_arrows=1 if elementary_arrows is None else elementary_arrows,
                weights=weights,
                electronic_mode=electronic_mode,
            )

        raise ValueError(f"Unsupported family: {family}")
