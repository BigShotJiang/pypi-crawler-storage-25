from __future__ import annotations

from typing import Dict, Optional, Sequence, Tuple

import networkx as nx

from .base import BaseTrajectoryRanker
from .family import TrajectoryFamily
from .models import Step, Trajectory, TrajectoryScore


class PericyclicTrajectoryRanker(BaseTrajectoryRanker):
    """Ranker for pericyclic trajectories.

    Main intended use
    -----------------
    - Diels-Alder-like bond-flow trajectories
    - cycloaddition-like cyclic bond reorganization

    Philosophy
    ----------
    This scorer does not prioritize lone pairs. It prefers:
    - conjugated source bonds
    - cyclic closure inside one elementary block
    - two new inter-component sigma bonds
    - one internal bond reorganization
    - terminal donor/acceptor polarity matching
    """

    DEFAULT_WEIGHTS: Dict[str, float] = {
        "incomplete_block_penalty": 50.0,
        "non_bond_flow_penalty": 20.0,
        "all_bond_flow_bonus": 10.0,
        "conjugated_source_bonus": 8.0,
        "pi_bond_bonus": 5.0,
        "new_sigma_bridge_bonus": 12.0,
        "internal_reorganization_bonus": 10.0,
        "cycle_closure_bonus": 22.0,
        "component_pattern_bonus": 20.0,
        "terminal_polarity_scale": 10.0,
        "concertedness_bonus": 12.0,
        "disconnected_penalty": 18.0,
        "family_match_bonus": 12.0,
        "checkpoint_boundary_bonus": 4.0,
        "checkpoint_valid_bonus": 6.0,
        "checkpoint_invalid_penalty": 20.0,
        "electronic_bond_flow_scale": 0.55,
        "length_penalty": 0.75,
    }

    def __init__(
        self,
        graph,
        elementary_arrows: int = 3,
        weights: Optional[Dict[str, float]] = None,
        electronic_mode: Optional[str] = None,
    ) -> None:
        super().__init__(
            graph=graph,
            family=TrajectoryFamily.PERICYCLIC,
            elementary_arrows=elementary_arrows,
            weights=weights,
            electronic_mode=electronic_mode,
        )

    def score_trajectory(self, trajectory: Trajectory | object) -> TrajectoryScore:
        trajectory = self._coerce_trajectory(trajectory)
        result = TrajectoryScore(family=self.family)

        if trajectory.n_steps == 0:
            result.invalidate("empty trajectory", penalty=80.0)
            return result

        blocks = trajectory.elementary_blocks(self.elementary_arrows)
        for block_index, block in enumerate(blocks, start=1):
            if len(block) != self.elementary_arrows:
                result.penalize(
                    "incomplete_block",
                    self.weights["incomplete_block_penalty"],
                    block_index=block_index,
                    observed_steps=len(block),
                    expected_steps=self.elementary_arrows,
                )
                result.reasons.append(f"block {block_index} is incomplete")
                continue

            block_score = self._score_block(block, block_index)
            result.total_score += block_score.total_score
            result.components.extend(block_score.components)
            result.reasons.extend(block_score.reasons)
            result.valid = result.valid and block_score.valid

        self._score_family_match(trajectory, result)
        self._score_length_regularization(trajectory, result)
        return result

    def _score_length_regularization(self, trajectory: Trajectory, result: TrajectoryScore) -> None:
        lam = float(self.graph.graph.get("length_penalty", self.weights.get("length_penalty", 0.75)))
        if lam <= 0:
            return
        penalty = lam * float(trajectory.n_steps)
        result.penalize("length_regularization", penalty, steps=trajectory.n_steps)
        result.reasons.append(f"length regularization: -{penalty:.2f} for {trajectory.n_steps} steps")

    def _score_block(self, block: Tuple[Step, ...], block_index: int) -> TrajectoryScore:
        result = TrajectoryScore(family=self.family)

        if all(step.action == "B-/B+" for step in block):
            result.add(
                "all_bond_flow",
                self.weights["all_bond_flow_bonus"],
                block_index=block_index,
            )
        else:
            off_family = sum(step.action != "B-/B+" for step in block)
            result.penalize(
                "off_family_steps",
                self.weights["non_bond_flow_penalty"] * off_family,
                block_index=block_index,
            )

        for step_index, step in enumerate(block, start=1):
            value, reason = self._score_step(step)
            result.add(
                "step",
                value,
                block_index=block_index,
                step_index=step_index,
                action=step.action,
                reason=reason,
            )

        src_bonds = [tuple(step.src) for step in block if len(step.src) == 2]
        dst_bonds = [tuple(step.dst) for step in block if len(step.dst) == 2]

        if self._is_concerted_cycle(src_bonds, dst_bonds):
            result.add(
                "cycle_closure",
                self.weights["cycle_closure_bonus"],
                block_index=block_index,
            )

        components = self._partition_pi_components(src_bonds)
        if self._is_diels_alder_component_pattern(components):
            result.add(
                "component_pattern",
                self.weights["component_pattern_bonus"],
                block_index=block_index,
            )
            result.add(
                "sigma_bridge_pattern",
                self._score_new_sigma_bridges(components, dst_bonds),
                block_index=block_index,
            )
            result.add(
                "terminal_polarity_match",
                self._terminal_polarity_match(components, dst_bonds),
                block_index=block_index,
            )

        if self._is_concerted_local(block):
            result.add(
                "concertedness",
                self.weights["concertedness_bonus"],
                block_index=block_index,
            )
        else:
            result.penalize(
                "concertedness",
                self.weights["disconnected_penalty"],
                block_index=block_index,
            )

        result.add(
            "checkpoint_quality",
            self._score_checkpoint_quality(block),
            block_index=block_index,
        )
        return result

    def _score_family_match(self, trajectory: Trajectory, result: TrajectoryScore) -> None:
        b2b = sum(step.action == "B-/B+" for step in trajectory)
        if b2b >= max(2, len(trajectory) - 1):
            result.add("family_match", self.weights["family_match_bonus"], b2b_steps=b2b)

    def _score_step(self, step: Step) -> Tuple[float, str]:
        if step.action != "B-/B+":
            return -8.0, f"{step.action} is off-family for pericyclic scoring"
        if len(step.src) != 2 or len(step.dst) != 2:
            return -100.0, "malformed B-/B+"

        a, b = step.src
        c, d = step.dst
        score = 0.0

        if self._has_edge(a, b):
            edge = self._edge(a, b)
            if bool(edge.get("conjugated", False)):
                score += self.weights["conjugated_source_bonus"]
            if float(edge.get("order", 0.0)) > 1.0:
                score += self.weights["pi_bond_bonus"]
        else:
            score -= 10.0

        if not self._has_edge(c, d):
            score += self.weights["new_sigma_bridge_bonus"]
        else:
            if self._bond_order(c, d) >= 1.0:
                score += self.weights["internal_reorganization_bonus"]

        e_score = self.electronic.score_bond_to_bond((a, b), (c, d), shared_atom=step.shared_atom)
        score += self.weights["electronic_bond_flow_scale"] * e_score.total
        ctx_score, ctx_reason = self._contextual_step_adjustment(step)
        score += ctx_score
        reason = (
            f"bond flow {a}-{b} -> {c}-{d}; "
            f"electronic={e_score.total:.2f} (FMO={e_score.fmo:.2f},"
            f" Hückel={e_score.huckel:.2f}, HSAB={e_score.hsab:.2f})"
        )
        if ctx_reason:
            reason = f"{reason}; {ctx_reason}"
        return score, reason

    def _score_checkpoint_quality(self, block: Tuple[Step, ...]) -> float:
        last = block[-1]
        score = 0.0
        if last.arrow_boundary_reached:
            score += self.weights["checkpoint_boundary_bonus"]
        if last.last_graph_valid is True:
            score += self.weights["checkpoint_valid_bonus"]
        elif last.last_graph_valid is False:
            score -= self.weights["checkpoint_invalid_penalty"]
        return score

    def _is_concerted_cycle(self, src_bonds: Sequence[Tuple[int, int]], dst_bonds: Sequence[Tuple[int, int]]) -> bool:
        if len(src_bonds) != self.elementary_arrows or len(dst_bonds) != self.elementary_arrows:
            return False

        atoms = []
        for bond in list(src_bonds) + list(dst_bonds):
            atoms.extend(bond)

        counts: Dict[int, int] = {}
        for atom in atoms:
            counts[atom] = counts.get(atom, 0) + 1

        return all(v >= 2 for v in counts.values()) and len(counts) <= 6

    def _is_concerted_local(self, block: Sequence[Step]) -> bool:
        atoms = [set(step.src) | set(step.dst) for step in block]
        for i in range(len(atoms) - 1):
            if not atoms[i] & atoms[i + 1]:
                close = False
                for a in atoms[i]:
                    for b in atoms[i + 1]:
                        if self._graph_distance(a, b) <= 1:
                            close = True
                            break
                    if close:
                        break
                if not close:
                    return False
        return True

    def _partition_pi_components(self, src_bonds: Sequence[Tuple[int, int]]) -> list[set[int]]:
        pi_graph = nx.Graph()
        for a, b in src_bonds:
            pi_graph.add_node(a)
            pi_graph.add_node(b)
            if self._has_edge(a, b):
                edge = self._edge(a, b)
                if bool(edge.get("conjugated", False)) or float(edge.get("order", 0.0)) > 1.0:
                    pi_graph.add_edge(a, b)

        return [set(comp) for comp in nx.connected_components(pi_graph)] if pi_graph.nodes else []

    def _is_diels_alder_component_pattern(self, components: Sequence[set[int]]) -> bool:
        sizes = sorted(len(comp) for comp in components)
        return sizes == [2, 4]

    def _score_new_sigma_bridges(self, components: Sequence[set[int]], dst_bonds: Sequence[Tuple[int, int]]) -> float:
        if len(components) != 2:
            return 0.0

        comp1, comp2 = components
        bridge_count = 0
        internal_count = 0

        for a, b in dst_bonds:
            in_1 = a in comp1 and b in comp1
            in_2 = a in comp2 and b in comp2
            cross = (a in comp1 and b in comp2) or (a in comp2 and b in comp1)

            if cross and not self._has_edge(a, b):
                bridge_count += 1
            elif in_1 or in_2:
                internal_count += 1

        score = 0.0
        if bridge_count == 2:
            score += 2.0 * self.weights["new_sigma_bridge_bonus"]
        elif bridge_count == 1:
            score += 0.5 * self.weights["new_sigma_bridge_bonus"]
        else:
            score -= 10.0

        if internal_count >= 1:
            score += self.weights["internal_reorganization_bonus"]
        return score

    def _terminal_polarity_match(self, components: Sequence[set[int]], dst_bonds: Sequence[Tuple[int, int]]) -> float:
        if len(components) != 2:
            return 0.0

        comp_small, comp_large = sorted(components, key=len)
        diene = comp_large
        dienophile = comp_small

        score = 0.0
        for a, b in dst_bonds:
            if self._has_edge(a, b):
                continue

            if a in diene and b in dienophile:
                score += self._diene_terminal_donor_score(a) + self._dienophile_terminal_acceptor_score(b)
            elif b in diene and a in dienophile:
                score += self._diene_terminal_donor_score(b) + self._dienophile_terminal_acceptor_score(a)

        return self.weights["terminal_polarity_scale"] * score

    def _diene_terminal_donor_score(self, atom: int) -> float:
        elem = self._element(atom)
        partial = self._partial_charge(atom)
        score = max(-1.0, min(1.0, -4.0 * partial))
        if elem in {"O", "N", "S"}:
            score += 0.4
        if self._incident_conjugated(atom):
            score += 0.2
        return score

    def _dienophile_terminal_acceptor_score(self, atom: int) -> float:
        partial = self._partial_charge(atom)
        score = max(-1.0, min(1.0, 4.0 * partial))
        if any(self._element(nbr) in {"O", "N", "F", "Cl", "Br"} for nbr in self.graph.neighbors(atom)):
            score += 0.3
        return score
