from __future__ import annotations

from enum import Enum


class TrajectoryFamily(str, Enum):
    """Supported chemistry families for trajectory ranking."""

    POLAR = "polar"
    PERICYCLIC = "pericyclic"
    RADICAL = "radical"
