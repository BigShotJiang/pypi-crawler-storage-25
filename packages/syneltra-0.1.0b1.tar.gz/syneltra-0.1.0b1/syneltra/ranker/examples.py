from __future__ import annotations

"""Small usage examples for the ranker package."""

from .factory import TrajectoryRankerFactory
from .models import Trajectory


def example_polar_rank(graph, engine_trajectories):
    """Rank raw engine trajectories using the polar ranker."""
    ranker = TrajectoryRankerFactory.create("polar", graph)
    ranking = ranker.rank(engine_trajectories)
    return {
        "traj_numbers": ranking.traj_numbers,
        "scores": ranking.scores,
        "new_order_trajs": ranking.new_order_trajs,
        "adapted_trajs": ranking.adapted_trajs,
    }


def example_pericyclic_rank(graph):
    """Score one simple hand-built pericyclic trajectory."""
    ranker = TrajectoryRankerFactory.create("pericyclic", graph, elementary_arrows=3)

    traj = Trajectory.from_raw(
        [
            ("B-/B+", (1, 2), (1, 6)),
            ("B-/B+", (3, 4), (4, 5)),
            ("B-/B+", (5, 6), (2, 3)),
        ]
    )
    return ranker.score_trajectory(traj)


def example_electronic_guided_rank(graph, engine_trajectories):
    """Rank polar trajectories with default FMO + Hückel + HSAB consensus guidance."""
    ranker = TrajectoryRankerFactory.create("polar", graph, electronic_mode="consensus")
    ranking = ranker.rank(engine_trajectories)
    return ranking.new_order_trajs, ranking.scores, ranking.traj_numbers
