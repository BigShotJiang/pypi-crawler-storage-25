from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import networkx as nx


def _to_atom_tuple(x: Iterable[int] | int | Tuple[int, ...]) -> Tuple[int, ...]:
    """Normalize atom input to a tuple."""
    if isinstance(x, tuple):
        return x
    if isinstance(x, int):
        return (x,)
    return tuple(x)


def _safe_memory(state: Any) -> Dict[str, Any]:
    """Return a state memory dictionary if available."""
    mem = getattr(state, "memory", None)
    if mem is None:
        return {}
    return dict(mem)


def _safe_graph(state: Any) -> Optional[nx.Graph]:
    """Return a state graph if available."""
    return getattr(state, "graph", None)


def _safe_seq_tuple(values: Any) -> Tuple[Any, ...]:
    """Return a tuple for sequence-like state containers."""
    if values is None:
        return ()
    try:
        return tuple(values)
    except Exception:
        return ()


@dataclass(frozen=True)
class Step:
    """One primitive mechanism step.

    This object can be created from:
    - raw ``(action, src, dst)`` tuples
    - raw ``(action, src, dst, data)`` tuples
    - engine ``Transition`` objects plus optional state context

    Parameters
    ----------
    action:
        Primitive action label such as ``"LP-/B+"`` or ``"B-/B+"``.
    src:
        Source atom tuple.
    dst:
        Destination atom tuple.
    data:
        Optional transition metadata.
    pre_graph, post_graph:
        Graph state before and after the step.
    pre_memory, post_memory:
        State memory before and after the step.
    raw_transition:
        Original transition object from the enumerator.
    """

    action: str
    src: Tuple[int, ...]
    dst: Tuple[int, ...]
    data: Dict[str, Any] = field(default_factory=dict, compare=False)
    pre_graph: Optional[nx.Graph] = field(default=None, compare=False, repr=False)
    post_graph: Optional[nx.Graph] = field(default=None, compare=False, repr=False)
    pre_memory: Dict[str, Any] = field(default_factory=dict, compare=False, repr=False)
    post_memory: Dict[str, Any] = field(default_factory=dict, compare=False, repr=False)
    raw_transition: Any = field(default=None, compare=False, repr=False)

    @classmethod
    def from_raw(
        cls,
        action: str,
        src: Iterable[int] | int,
        dst: Iterable[int] | int,
        data: Optional[Dict[str, Any]] = None,
    ) -> "Step":
        """Build a :class:`Step` from raw values."""
        return cls(
            action=action,
            src=_to_atom_tuple(src),
            dst=_to_atom_tuple(dst),
            data={} if data is None else dict(data),
        )

    @classmethod
    def from_engine_transition(
        cls,
        transition: Any,
        pre_state: Any = None,
        post_state: Any = None,
    ) -> "Step":
        """Build a :class:`Step` from an engine transition object."""
        return cls(
            action=str(getattr(transition, "kind")),
            src=_to_atom_tuple(getattr(transition, "src")),
            dst=_to_atom_tuple(getattr(transition, "dst")),
            data=dict(getattr(transition, "data", {}) or {}),
            pre_graph=_safe_graph(pre_state),
            post_graph=_safe_graph(post_state),
            pre_memory=_safe_memory(pre_state),
            post_memory=_safe_memory(post_state),
            raw_transition=transition,
        )

    @property
    def shared_atom(self) -> Optional[int]:
        """Shared atom ID from transition metadata if available."""
        value = self.data.get("shared_atom")
        return int(value) if value is not None else None

    @property
    def arrow_step_index(self) -> Optional[int]:
        """Post-state arrow step index if present."""
        value = self.post_memory.get("arrow_step_index")
        return int(value) if value is not None else None

    @property
    def arrow_boundary_reached(self) -> bool:
        """Whether this step ends at an arrow boundary checkpoint."""
        return bool(self.post_memory.get("arrow_boundary_reached", False))

    @property
    def last_graph_valid(self) -> Optional[bool]:
        """Whether the post-step graph was marked valid."""
        value = self.post_memory.get("last_graph_valid")
        return None if value is None else bool(value)

    @property
    def state_smiles(self) -> Optional[str]:
        """Checkpoint SMILES at the post-step state if present."""
        value = self.post_memory.get("state_smiles")
        return None if value is None else str(value)


@dataclass(frozen=True)
class Trajectory:
    """Enriched trajectory container.

    Parameters
    ----------
    steps:
        Adapted primitive steps.
    state_graphs:
        Graph sequence aligned with states.
    state_memories:
        Memory sequence aligned with states.
    states_raw:
        Original engine states.
    transitions_raw:
        Original engine transitions.
    raw_trajectory:
        Original engine trajectory object.
    """

    steps: Tuple[Step, ...]
    state_graphs: Tuple[Optional[nx.Graph], ...] = ()
    state_memories: Tuple[Dict[str, Any], ...] = ()
    states_raw: Tuple[Any, ...] = field(default_factory=tuple, repr=False)
    transitions_raw: Tuple[Any, ...] = field(default_factory=tuple, repr=False)
    raw_trajectory: Any = field(default=None, repr=False)

    @classmethod
    def from_raw(
        cls,
        raw_steps: Sequence[
            Step
            | Tuple[str, Iterable[int] | int, Iterable[int] | int]
            | Tuple[str, Iterable[int] | int, Iterable[int] | int, Dict[str, Any]]
        ],
    ) -> "Trajectory":
        """Build a trajectory from raw step tuples or :class:`Step` objects."""
        steps: List[Step] = []
        for item in raw_steps:
            if isinstance(item, Step):
                steps.append(item)
                continue

            if len(item) == 3:
                action, src, dst = item
                data = {}
            elif len(item) == 4:
                action, src, dst, data = item
            else:
                raise ValueError(f"Unsupported raw step format: {item}")

            steps.append(Step.from_raw(action, src, dst, data))

        return cls(steps=tuple(steps))

    @classmethod
    def from_engine_trajectory(cls, traj: Any) -> "Trajectory":
        """Build a trajectory from an engine trajectory object.

        Expected attributes
        -------------------
        - ``states``
        - ``transitions``
        """
        raw_states = tuple(getattr(traj, "states", []) or [])
        raw_transitions = tuple(getattr(traj, "transitions", []) or [])

        steps: List[Step] = []
        for i, transition in enumerate(raw_transitions):
            pre_state = raw_states[i] if i < len(raw_states) else None
            post_state = raw_states[i + 1] if i + 1 < len(raw_states) else None
            steps.append(Step.from_engine_transition(transition, pre_state, post_state))

        state_graphs = tuple(_safe_graph(st) for st in raw_states)
        state_memories = tuple(_safe_memory(st) for st in raw_states)

        return cls(
            steps=tuple(steps),
            state_graphs=state_graphs,
            state_memories=state_memories,
            states_raw=raw_states,
            transitions_raw=raw_transitions,
            raw_trajectory=traj,
        )

    def __iter__(self):
        return iter(self.steps)

    def __len__(self) -> int:
        return len(self.steps)

    def __getitem__(self, item: int) -> Step:
        return self.steps[item]

    @property
    def transitions(self) -> Tuple[Step, ...]:
        """Compatibility alias exposing primitive steps as transitions."""
        return self.steps

    @property
    def states(self) -> Tuple[Any, ...]:
        """Compatibility alias exposing raw engine states when available."""
        return self.states_raw

    @property
    def n_steps(self) -> int:
        """Number of primitive steps."""
        return len(self.steps)

    @property
    def n_states(self) -> int:
        """Number of stored states."""
        return len(self.state_graphs)

    @property
    def checkpoint_state_indices(self) -> Tuple[int, ...]:
        """Indices of checkpoint states."""
        indices: List[int] = []
        for i, mem in enumerate(self.state_memories):
            if mem.get("arrow_boundary_reached", False):
                indices.append(i)
        return tuple(indices)

    @property
    def checkpoint_smiles(self) -> Tuple[str, ...]:
        """Checkpoint SMILES strings collected from state memory."""
        smiles: List[str] = []
        for mem in self.state_memories:
            value = mem.get("state_smiles")
            if value:
                smiles.append(str(value))
        return tuple(smiles)

    def elementary_blocks(self, arrows: int) -> List[Tuple[Step, ...]]:
        """Split the trajectory into fixed-size elementary blocks."""
        if arrows < 1:
            raise ValueError("arrows must be >= 1")
        return [tuple(self.steps[i : i + arrows]) for i in range(0, len(self.steps), arrows)]  # noqa


@dataclass(frozen=True)
class RankedTrajectory:
    """One ranked trajectory entry.

    Parameters
    ----------
    traj_number:
        Original 1-based position of the trajectory in the input sequence.
    adapted_trajectory:
        Adapted trajectory object used internally for scoring.
    score:
        Structured score for the trajectory.
    raw:
        Original trajectory object from the caller, if available.
    """

    traj_number: int
    adapted_trajectory: Trajectory
    score: TrajectoryScore
    raw: Any = field(default=None, repr=False, compare=False)

    @property
    def original_index(self) -> int:
        """1-based original input index."""
        return self.traj_number

    @property
    def total_score(self) -> float:
        """Convenience proxy for ``score.total_score``."""
        return self.score.total_score

    @property
    def valid(self) -> bool:
        """Convenience proxy for ``score.valid``."""
        return self.score.valid

    @property
    def original_trajectory(self) -> Any:
        """Return the original input trajectory when available."""
        return self.raw if self.raw is not None else self.adapted_trajectory

    @property
    def trajectory(self) -> Any:
        """Primary downstream trajectory view.

        This intentionally returns the original input trajectory so code such as
        ``ranking.best.trajectory.transitions`` preserves the enumerator
        ``Transition`` objects needed by visualization.
        """
        return self.original_trajectory

    def as_tuple(self) -> Tuple[int, TrajectoryScore, Any]:
        """Return ``(traj_number, score, original_trajectory)``."""
        return (self.traj_number, self.score, self.original_trajectory)

    def as_scored_tuple(self) -> Tuple[int, TrajectoryScore, Trajectory]:
        """Return ``(traj_number, score, adapted_trajectory)``."""
        return (self.traj_number, self.score, self.adapted_trajectory)

    def __iter__(self):
        """Backward-compatible unpacking as ``(trajectory, score)``.

        This yields the original input trajectory so downstream code keeps the
        same object type it passed into :meth:`rank`.
        """
        yield self.original_trajectory
        yield self.score


@dataclass
class RankResult:
    """Container returned by :meth:`BaseTrajectoryRanker.rank`.

    This object is intentionally easy to use downstream:

    - ``result.new_order_trajs`` gives the reordered original trajectories
    - ``result.scores`` gives aligned scores
    - ``result.traj_numbers`` gives original 1-based trajectory numbers
    - ``result.adapted_trajs`` gives the normalized trajectories used internally
      for scoring

    It also keeps ranked entries with metadata for inspection.
    """

    entries: List[RankedTrajectory] = field(default_factory=list)

    def __iter__(self):
        return iter(self.entries)

    def __len__(self) -> int:
        return len(self.entries)

    def __getitem__(self, item):
        return self.entries[item]

    @property
    def ranked(self) -> List[RankedTrajectory]:
        """Alias for the ranked entry list."""
        return list(self.entries)

    @property
    def new_order_trajs(self) -> List[Any]:
        """Reordered original trajectories from best to worst.

        These are the same objects passed into :meth:`rank` whenever possible,
        so downstream code can use them directly without format conversion.
        """
        return [entry.original_trajectory for entry in self.entries]

    @property
    def trajectories(self) -> List[Any]:
        """Alias for :attr:`new_order_trajs`."""
        return self.new_order_trajs

    @property
    def adapted_trajs(self) -> List[Trajectory]:
        """Normalized trajectories aligned with the ranking.

        These are the internal :class:`Trajectory` wrappers used for scoring.
        """
        return [entry.adapted_trajectory for entry in self.entries]

    @property
    def scores(self) -> List[TrajectoryScore]:
        """Scores aligned with :attr:`new_order_trajs`."""
        return [entry.score for entry in self.entries]

    @property
    def traj_numbers(self) -> List[int]:
        """Original 1-based trajectory numbers aligned with the ranking."""
        return [entry.traj_number for entry in self.entries]

    @property
    def best(self) -> Optional[RankedTrajectory]:
        """Best-ranked entry, or ``None`` when empty."""
        return self.entries[0] if self.entries else None

    @property
    def best_entry(self) -> Optional[RankedTrajectory]:
        """Explicit alias for the best ranked entry."""
        return self.best

    @property
    def best_traj(self) -> Optional[Any]:
        """Best-ranked original trajectory for direct downstream use."""
        entry = self.best
        return None if entry is None else entry.trajectory

    @property
    def best_score(self) -> Optional[TrajectoryScore]:
        """Score aligned with :attr:`best_traj`."""
        entry = self.best
        return None if entry is None else entry.score

    @property
    def best_traj_number(self) -> Optional[int]:
        """Original 1-based index of :attr:`best_traj`."""
        entry = self.best
        return None if entry is None else entry.traj_number

    def as_pairs(self) -> List[Tuple[Any, TrajectoryScore]]:
        """Return legacy ``(trajectory, score)`` pairs.

        The trajectory in each pair is the original input object.
        """
        return [(entry.original_trajectory, entry.score) for entry in self.entries]

    def as_triplets(self) -> List[Tuple[int, TrajectoryScore, Any]]:
        """Return ``(traj_number, score, original_trajectory)`` triplets."""
        return [entry.as_tuple() for entry in self.entries]

    def as_scored_triplets(self) -> List[Tuple[int, TrajectoryScore, Trajectory]]:
        """Return ``(traj_number, score, adapted_trajectory)`` triplets."""
        return [entry.as_scored_tuple() for entry in self.entries]


@dataclass
class ScoreComponent:
    """One labeled score contribution."""

    label: str
    score: float
    meta: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TrajectoryScore:
    """Structured scoring result for one trajectory."""

    family: Any
    valid: bool = True
    total_score: float = 0.0
    components: List[ScoreComponent] = field(default_factory=list)
    reasons: List[str] = field(default_factory=list)

    def add(self, label: str, score: float, **meta: Any) -> None:
        """Add a signed score contribution."""
        value = float(score)
        self.total_score += value
        self.components.append(ScoreComponent(label=label, score=value, meta=dict(meta)))

    def penalize(self, label: str, score: float, **meta: Any) -> None:
        """Add a negative score contribution."""
        self.add(label=label, score=-abs(float(score)), **meta)

    def invalidate(self, reason: str, penalty: float = 100.0) -> None:
        """Mark score invalid and apply a penalty."""
        self.valid = False
        self.reasons.append(reason)
        self.penalize("invalid", penalty, reason=reason)

    @property
    def total(self) -> float:
        """Compatibility alias for :attr:`total_score`."""
        return self.total_score
