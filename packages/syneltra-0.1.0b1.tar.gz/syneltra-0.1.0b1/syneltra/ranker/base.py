from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
import math

import networkx as nx

from .family import TrajectoryFamily
from .models import RankResult, RankedTrajectory, Step, Trajectory, TrajectoryScore
from ..scoring import ElectronicTransitionScorer


def _coerce_scalar(value: Any, default: float = 0.0) -> float:
    """Convert graph attributes to a numeric scalar.

    Tuple/list values are interpreted by taking the first element recursively.
    NaN and unparsable values fall back to ``default``.
    """
    while isinstance(value, (tuple, list)):
        if not value:
            return float(default)
        value = value[0]
    try:
        value = float(value)
    except Exception:
        return float(default)
    return float(default) if math.isnan(value) else float(value)


def _coerce_bool(value: Any) -> bool:
    while isinstance(value, (tuple, list)):
        if not value:
            return False
        value = value[0]
    return bool(value)


class BaseTrajectoryRanker(ABC):
    """Base class for family-specific trajectory rankers.

    :param graph: Reference graph used for local chemistry descriptors.
    :type graph: nx.Graph
    :param family: Mechanism family represented by the ranker.
    :type family: TrajectoryFamily
    :param elementary_arrows: Number of elementary arrows grouped into one
        event block by the ranker.
    :type elementary_arrows: int
    :param weights: Optional score-weight overrides.
    :type weights: Optional[Dict[str, float]]
    :param electronic_mode: Optional override for the electronic guidance mode.
    :type electronic_mode: Optional[str]
    """

    DEFAULT_WEIGHTS: Dict[str, float] = {}

    def __init__(
        self,
        graph: nx.Graph,
        family: TrajectoryFamily,
        elementary_arrows: int,
        weights: Optional[Dict[str, float]] = None,
        electronic_mode: Optional[str] = None,
    ) -> None:
        if elementary_arrows < 1:
            raise ValueError("elementary_arrows must be >= 1")

        self.graph = graph
        self.family = family
        self.elementary_arrows = int(elementary_arrows)
        self.weights: Dict[str, float] = dict(self.DEFAULT_WEIGHTS)
        if weights:
            self.weights.update(weights)
        self.electronic_mode = str(electronic_mode or graph.graph.get("electronic_mode", "consensus")).lower()
        self.electronic = ElectronicTransitionScorer(
            graph=graph,
            mode=self.electronic_mode,
        )

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(family={self.family.value!r}, " f"elementary_arrows={self.elementary_arrows})"
        )

    def rank(self, trajectories: Sequence[Any]) -> RankResult:
        """Score and rank trajectories from best to worst.

        :param trajectories: Engine trajectories, :class:`Trajectory` objects,
            raw transitions, or step lists.
        :type trajectories: Sequence[Any]
        :return: Structured ranking result containing aligned trajectory numbers,
            scores, and reordered trajectories.
        :rtype: RankResult

        Example
        -------
        .. code-block:: python

            ranking = ranker.rank(engine_trajectories)
            best = ranking.best
            best_traj = ranking.new_order_trajs[0]
            best_score = ranking.scores[0]
            original_number = ranking.traj_numbers[0]
        """
        entries: List[RankedTrajectory] = []
        for traj_number, traj in enumerate(trajectories, start=1):
            trajectory = self._coerce_trajectory(traj)
            score = self.score_trajectory(trajectory)
            entries.append(
                RankedTrajectory(
                    traj_number=traj_number,
                    adapted_trajectory=trajectory,
                    score=score,
                    raw=traj,
                )
            )

        entries.sort(key=lambda x: (x.score.valid, x.score.total_score), reverse=True)
        return RankResult(entries=entries)

    def rank_scores(self, trajectories: Sequence[Any]) -> List[Tuple[int, TrajectoryScore]]:
        """Return ``(original_traj_number, score)`` pairs in ranked order."""
        ranking = self.rank(trajectories)
        return [(entry.traj_number, entry.score) for entry in ranking]

    @abstractmethod
    def score_trajectory(self, trajectory: Trajectory) -> TrajectoryScore:
        """Score one trajectory."""
        raise NotImplementedError

    def _coerce_trajectory(self, traj: Any) -> Trajectory:
        """Accept wrapped trajectories, engine trajectories, steps, or raw tuples."""
        if isinstance(traj, Trajectory):
            return traj

        if hasattr(traj, "transitions") and hasattr(traj, "states"):
            return Trajectory.from_engine_trajectory(traj)

        if not traj:
            return Trajectory.from_raw(())

        first = traj[0]

        if isinstance(first, Step):
            return Trajectory(steps=tuple(traj))

        if hasattr(first, "kind") and hasattr(first, "src") and hasattr(first, "dst"):
            steps = [Step.from_engine_transition(t) for t in traj]
            return Trajectory(steps=tuple(steps))

        return Trajectory.from_raw(traj)

    def _node(self, atom: int) -> Dict[str, Any]:
        return dict(self.graph.nodes[atom])

    def _edge(self, a: int, b: int) -> Dict[str, Any]:
        return dict(self.graph.edges[a, b])

    def _has_edge(self, a: int, b: int) -> bool:
        return self.graph.has_edge(a, b)

    def _partial_charge(self, atom: int) -> float:
        return _coerce_scalar(self.graph.nodes[atom].get("partial_charge", 0.0))

    def _formal_charge(self, atom: int) -> float:
        return _coerce_scalar(self.graph.nodes[atom].get("charge", 0.0))

    def _element(self, atom: int) -> str:
        value = self.graph.nodes[atom].get("element", "")
        while isinstance(value, (tuple, list)):
            if not value:
                value = ""
                break
            value = value[0]
        return str(value).strip().upper()

    def _hybridization(self, atom: int) -> str:
        return str(self.graph.nodes[atom].get("hybridization", ""))

    def _lone_pairs(self, atom: int) -> float:
        return _coerce_scalar(self.graph.nodes[atom].get("lone_pairs", 0.0))

    def _hcount(self, atom: int) -> float:
        return _coerce_scalar(self.graph.nodes[atom].get("hcount", 0.0))

    def _aromatic(self, atom: int) -> bool:
        return _coerce_bool(self.graph.nodes[atom].get("aromatic", False))

    def _incident_conjugated(self, atom: int) -> bool:
        for nbr in self.graph.neighbors(atom):
            if bool(self.graph.edges[atom, nbr].get("conjugated", False)):
                return True
        return False

    def _bond_order(self, a: int, b: int) -> float:
        if not self._has_edge(a, b):
            return 0.0
        return _coerce_scalar(self.graph.edges[a, b].get("order", 0.0))

    def _graph_distance(self, a: int, b: int) -> float:
        try:
            return float(nx.shortest_path_length(self.graph, a, b))
        except nx.NetworkXNoPath:
            return math.inf

    def _contextual_step_adjustment(self, step: Step) -> Tuple[float, str]:
        """Return a small generic adjustment from adaptive context metadata."""
        data = dict(step.data or {})
        if not data:
            return 0.0, ""
        origin = str(data.get("proposal_origin", "goal"))
        try:
            hint = float(data.get("context_score_hint", 0.0))
        except Exception:
            hint = 0.0
        try:
            dist = int(data.get("context_distance", 0))
        except Exception:
            dist = 0
        try:
            rep = int(data.get("representative_size", 1)) + int(data.get("target_representative_size", 0))
        except Exception:
            rep = 1
        aromatic = data.get("aromatic_position_class", data.get("target_aromatic_position_class"))
        score = 0.04 * hint
        score += 0.8 * math.log1p(max(1, rep))
        score -= 0.6 * max(0, dist - 1)
        score += {"goal": 1.2, "adjacent_rc": 0.5, "generic_context": 0.0}.get(origin, 0.0)
        score += {"para": 1.5, "ortho": 1.0, "meta": 0.5, "ipso": -1.0}.get(str(aromatic), 0.0)
        pieces = []
        role = data.get("context_role") or data.get("target_context_role")
        if role:
            pieces.append(f"role={role}")
        if aromatic:
            pieces.append(f"pos={aromatic}")
        if origin != "goal":
            pieces.append(f"origin={origin}")
        if rep > 1:
            pieces.append(f"rep={rep}")
        return score, ("context " + ", ".join(pieces)) if pieces else ""

    def _best_atom_margin(self, atom: int, score_fn, candidates: Optional[Iterable[int]] = None) -> float:
        """Return score margin against the best competing atom."""
        if candidates is None:
            candidates = self.graph.nodes()

        atom_score = score_fn(atom)
        others = [score_fn(i) for i in candidates if i != atom]
        if not others:
            return 0.0
        return atom_score - max(others)

    @staticmethod
    def detect_family(trajectory: Trajectory) -> TrajectoryFamily:
        """Very rough family guess from action labels."""
        counts = {
            TrajectoryFamily.POLAR: 0,
            TrajectoryFamily.PERICYCLIC: 0,
            TrajectoryFamily.RADICAL: 0,
        }

        for step in trajectory:
            if "LP" in step.action or "H+" in step.action or "LP+" in step.action:
                counts[TrajectoryFamily.POLAR] += 2
            if step.action == "B-/B+":
                counts[TrajectoryFamily.PERICYCLIC] += 2
            if any(token in step.action for token in ("R·", "SET", "homolytic", "radical")):
                counts[TrajectoryFamily.RADICAL] += 3

        return max(counts, key=counts.get)
