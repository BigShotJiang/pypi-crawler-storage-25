from __future__ import annotations

from typing import Dict, Optional, Tuple
import math

from .base import BaseTrajectoryRanker
from .family import TrajectoryFamily
from .models import Step, Trajectory, TrajectoryScore


class PolarTrajectoryRanker(BaseTrajectoryRanker):
    """Ranker for polar / heterolytic trajectories.

    Core ideas
    ----------
    - elementary block usually contains 2 arrows
    - if a block starts with ``LP-``, it should normally close with ``LP+``
    - donor, electrophile, and leaving-group roles are scored separately
    - strong local coupling between consecutive arrows is rewarded
    - checkpoint validity can contribute to the score when available
    """

    DEFAULT_WEIGHTS: Dict[str, float] = {
        "lp_closure_bonus": 10.0,
        "lp_closure_penalty": 35.0,
        "shared_center_bonus": 12.0,
        "locality_bonus": 6.0,
        "subst_motif_bonus": 30.0,
        "attack_then_deprot_bonus": 14.0,
        "proton_shuttle_bonus": 12.0,
        "departure_before_attack_penalty": 16.0,
        "deprot_before_attack_penalty": 10.0,
        "bad_halogen_lp_h_penalty": 14.0,
        "incomplete_block_penalty": 40.0,
        "tail_block_penalty": 8.0,
        "global_attack_before_departure_bonus": 8.0,
        "global_departure_before_attack_penalty": 14.0,
        "global_deprot_after_attack_bonus": 6.0,
        "global_deprot_before_attack_penalty": 8.0,
        "chemoselectivity_scale": 0.40,
        "resonance_penalty": 3.0,
        "formal_charge_scale": 9.0,
        "partial_charge_scale": 18.0,
        "checkpoint_boundary_bonus": 4.0,
        "checkpoint_valid_bonus": 6.0,
        "checkpoint_invalid_penalty": 20.0,
        "checkpoint_smiles_bonus": 2.0,
        "hx_pi_protonation_bonus": 28.0,
        "hx_cleavage_bonus": 24.0,
        "hx_halide_capture_bonus": 22.0,
        "hx_wrong_halide_attack_penalty": 42.0,
        "hx_missing_proton_engagement_penalty": 22.0,
        "carbon_lp_sink_penalty": 48.0,
        "carbon_lp_sink_allowed_penalty": 14.0,
        "carbonyl_opening_bonus": 26.0,
        "carbonyl_neutral_departure_penalty": 36.0,
        "carbonyl_reclosure_immediate_bonus": 26.0,
        "carbonyl_reclosure_late_bonus": 12.0,
        "electronic_lp_attack_scale": 0.30,
        "electronic_bond_flow_scale": 0.35,
        "electronic_bond_cleavage_scale": 0.25,
        "relay_continuation_bonus": 18.0,
        "relay_carbonyl_continuation_bonus": 26.0,
        "relay_interruption_penalty": 28.0,
        "relay_carbonyl_interruption_penalty": 42.0,
        "repeated_step_penalty": 12.0,
        "repeated_pair_penalty": 18.0,
        "length_penalty": 0.75,
        "premature_terminal_h_transfer_penalty": 42.0,
        "heavy_delta_before_h_bonus": 8.0,
        "aromatic_cation_adjacent_sink_bonus": 42.0,
        "anionic_ring_opening_first_attack_bonus": 110.0,
        "anionic_ring_opening_delayed_attack_penalty": 35.0,
        "anionic_ring_opening_proton_before_attack_penalty": 90.0,
        "anionic_ring_opening_internal_donor_relay_penalty": 45.0,
        "anionic_carbonyl_first_attack_bonus": 140.0,
        "anionic_carbonyl_delayed_attack_penalty": 45.0,
        "anionic_carbonyl_proton_before_attack_penalty": 100.0,
        "anionic_carbonyl_pi_before_attack_penalty": 80.0,
    }

    def __init__(
        self,
        graph,
        elementary_arrows: int = 2,
        weights: Optional[Dict[str, float]] = None,
        electronic_mode: Optional[str] = None,
    ) -> None:
        super().__init__(
            graph=graph,
            family=TrajectoryFamily.POLAR,
            elementary_arrows=elementary_arrows,
            weights=weights,
            electronic_mode=electronic_mode,
        )

    def score_trajectory(self, trajectory: Trajectory | object) -> TrajectoryScore:
        trajectory = self._coerce_trajectory(trajectory)
        result = TrajectoryScore(family=self.family)

        if trajectory.n_steps == 0:
            result.invalidate("empty trajectory", penalty=80.0)
            return result

        blocks = trajectory.elementary_blocks(self.elementary_arrows)
        n_blocks = len(blocks)
        for block_index, block in enumerate(blocks, start=1):
            if len(block) != self.elementary_arrows:
                penalty = (
                    self.weights["tail_block_penalty"]
                    if block_index == n_blocks
                    else self.weights["incomplete_block_penalty"]
                )
                result.penalize(
                    "incomplete_block",
                    penalty,
                    block_index=block_index,
                    observed_steps=len(block),
                    expected_steps=self.elementary_arrows,
                )
                if block_index == n_blocks:
                    result.reasons.append(f"block {block_index} is shorter than checkpoint size")
                else:
                    result.reasons.append(f"block {block_index} is incomplete")
                continue

            block_score = self._score_block(block, block_index)
            result.total_score += block_score.total_score
            result.components.extend(block_score.components)
            result.reasons.extend(block_score.reasons)
            result.valid = result.valid and block_score.valid

        if self._is_protonation_addition_context():
            self._score_protonation_addition_order(trajectory, result)
        self._score_anionic_ring_opening_order(trajectory, result)
        self._score_anionic_carbonyl_addition_order(trajectory, result)
        self._score_flow_continuity(trajectory, result)
        self._score_redundant_flow(trajectory, result)
        self._score_carbonyl_continuity(trajectory, result)
        self._score_global_order(trajectory, result)
        self._score_terminal_h_timing(trajectory, result)
        self._score_family_match(trajectory, result)
        self._score_length_regularization(trajectory, result)
        return result

    @staticmethod
    def _graph_element(g, atom: int) -> str:
        if g is None or int(atom) not in g:
            return ""
        value = g.nodes[int(atom)].get("element", "")
        if isinstance(value, (tuple, list)) and value:
            value = value[0]
        return str(value).strip().upper()

    @classmethod
    def _step_forms_h_bond(cls, step: Step) -> Optional[Tuple[int, int]]:
        """Return ``(heavy_atom, h_atom)`` if this step forms an X--H bond."""
        if step.action not in {"LP-/B+", "B-/B+"} or len(step.dst) != 2:
            return None
        g = step.pre_graph
        a, b = int(step.dst[0]), int(step.dst[1])
        ea = cls._graph_element(g, a)
        eb = cls._graph_element(g, b)
        if ea == "H" and eb != "H":
            return b, a
        if eb == "H" and ea != "H":
            return a, b
        # Fall back to atom labels from the ranker graph is intentionally avoided:
        # atom maps may be absent in raw-step tests.  If we cannot identify H,
        # do not penalize.
        return None

    @classmethod
    def _step_breaks_heavy_bond_from(cls, step: Step, atom: int) -> bool:
        """Return True if this step breaks an atom--heavy bond involving ``atom``."""
        if step.action != "B-/LP+" or len(step.src) != 2:
            return False
        u, v = int(step.src[0]), int(step.src[1])
        if atom not in {u, v}:
            return False
        other = v if atom == u else u
        g = step.pre_graph
        return cls._graph_element(g, other) != "H"

    def _score_terminal_h_timing(self, trajectory: Trajectory, result: TrajectoryScore) -> None:
        """Penalize terminal X--H formation before later X--heavy bond departure.

        This is a general path-level causality term.  It does not know about
        esterification or acyl chemistry.  It simply says that if a trajectory
        forms X--H and only later breaks an X--heavy bond, the H transfer was
        likely used as endpoint bookkeeping before resolving the heavy-atom
        mechanism.  The penalty is soft so acid-catalyzed exceptions can still
        survive if other evidence strongly supports them.
        """
        steps = list(trajectory)
        if not steps:
            return
        penalty = float(self.weights.get("premature_terminal_h_transfer_penalty", 42.0))
        bonus = float(self.weights.get("heavy_delta_before_h_bonus", 8.0))
        for i, step in enumerate(steps):
            formed = self._step_forms_h_bond(step)
            if formed is None:
                continue
            x, h = formed
            # H+ (free proton, formal charge > 0 in reactant) protonating a
            # leaving group is acid-catalyzed activation — not premature bookkeeping.
            if self._formal_charge(int(h)) > 0:
                earlier_departure = any(self._step_breaks_heavy_bond_from(prev, x) for prev in steps[:i])
                if earlier_departure and bonus > 0:
                    result.add(
                        "terminal_h_after_heavy_delta",
                        bonus,
                        step_index=i + 1,
                        atom=x,
                        hydrogen=h,
                    )
                continue
            later_departure = any(self._step_breaks_heavy_bond_from(later, x) for later in steps[i + 1 :])  # noqa
            earlier_departure = any(self._step_breaks_heavy_bond_from(prev, x) for prev in steps[:i])
            if later_departure:
                result.penalize(
                    "premature_terminal_h_transfer",
                    penalty,
                    step_index=i + 1,
                    atom=x,
                    hydrogen=h,
                )
                result.reasons.append(
                    f"step {i + 1}: terminal H transfer to atom {x} occurs before later heavy-bond departure"
                )
            elif earlier_departure and bonus > 0:
                result.add(
                    "terminal_h_after_heavy_delta",
                    bonus,
                    step_index=i + 1,
                    atom=x,
                    hydrogen=h,
                )
                result.reasons.append(f"step {i + 1}: terminal H transfer follows heavy-bond departure at atom {x}")

    def _score_length_regularization(self, trajectory: Trajectory, result: TrajectoryScore) -> None:
        """Apply a small length penalty so longer resonance detours do not win."""
        lam = float(self.graph.graph.get("length_penalty", self.weights.get("length_penalty", 0.75)))
        if lam <= 0:
            return
        penalty = lam * float(trajectory.n_steps)
        result.penalize("length_regularization", penalty, steps=trajectory.n_steps)
        result.reasons.append(f"length regularization: -{penalty:.2f} for {trajectory.n_steps} steps")

    def _explicit_hx_pairs(self):
        pairs = []
        for u, v in self.graph.edges():
            eu = self._element(u)
            ev = self._element(v)
            if eu == "H" and ev in {"F", "Cl", "Br", "I"}:
                pairs.append((int(u), int(v)))
            elif ev == "H" and eu in {"F", "Cl", "Br", "I"}:
                pairs.append((int(v), int(u)))
        return pairs

    def _free_proton_atoms(self):
        out = set()
        for n in self.graph.nodes():
            if self._element(n) != "H":
                continue
            if int(self.graph.nodes[n].get("charge", 0)) > 0 or self.graph.degree(n) == 0:
                out.add(int(n))
        return out

    def _counterion_atoms(self):
        out = set()
        for n in self.graph.nodes():
            n = int(n)
            el = self._element(n)
            charge = int(self.graph.nodes[n].get("charge", 0))
            if charge < 0:
                out.add(n)
                continue
            if el in {"F", "Cl", "Br", "I"} and self.graph.degree(n) == 0:
                out.add(n)
        return out

    def _protonation_counterion_atoms(self):
        return {atom for atom in self._counterion_atoms() if self._element(atom) in {"F", "Cl", "Br", "I"}}

    def _carbonyl_counterion_atoms(self):
        if not self._has_carbonyl_bond():
            return set()
        return {atom for atom in self._counterion_atoms() if self._element(atom) == "C"}

    def _has_explicit_hx(self) -> bool:
        return bool(self._explicit_hx_pairs())

    def _has_unsaturated_non_h_bond(self) -> bool:
        for u, v in self.graph.edges():
            if self._element(u) == "H" or self._element(v) == "H":
                continue
            if self._bond_order(u, v) >= 2.0 or abs(self._bond_order(u, v) - 1.5) < 1e-8:
                return True
        return False

    def _has_carbonyl_bond(self) -> bool:
        for u, v in self.graph.edges():
            eu = self._element(u)
            ev = self._element(v)
            if "H" in {eu, ev} or "C" not in {eu, ev}:
                continue
            other = ev if eu == "C" else eu
            if other in {"O", "N", "S"} and self._bond_order(u, v) >= 2.0:
                return True
        return False

    def _is_hx_addition_context(self) -> bool:
        return self._has_explicit_hx() and self._has_unsaturated_non_h_bond()

    def _is_counterion_protonation_context(self) -> bool:
        if not self._free_proton_atoms():
            return False
        return bool(self._protonation_counterion_atoms() and self._has_unsaturated_non_h_bond())

    def _is_protonation_addition_context(self) -> bool:
        return self._is_hx_addition_context() or self._is_counterion_protonation_context()

    def _explicit_hx_atoms(self):
        h_atoms = set()
        x_atoms = set()
        for h, x in self._explicit_hx_pairs():
            h_atoms.add(int(h))
            x_atoms.add(int(x))
        return h_atoms, x_atoms

    def _proton_acceptor_atoms(self):
        h_atoms, _ = self._explicit_hx_atoms()
        return set(h_atoms) | set(self._free_proton_atoms())

    def _capture_donor_atoms(self):
        _, x_atoms = self._explicit_hx_atoms()
        return set(x_atoms) | set(self._protonation_counterion_atoms())

    def _is_pi_to_h_start(self, step: Step) -> bool:
        if step.action != "B-/B+" or len(step.src) != 2 or len(step.dst) != 2:
            return False
        if self._bond_order(*step.src) < 2.0 and abs(self._bond_order(*step.src) - 1.5) > 1e-8:
            return False
        return bool(set(step.dst) & self._proton_acceptor_atoms())

    def _is_hx_cleavage(self, step: Step) -> bool:
        if step.action != "B-/LP+" or len(step.src) != 2 or len(step.dst) != 1:
            return False
        h_atoms, x_atoms = self._explicit_hx_atoms()
        return bool(set(step.src) & h_atoms) and int(step.dst[0]) in x_atoms

    def _is_halide_capture(self, step: Step) -> bool:
        if step.action != "LP-/B+" or len(step.src) != 1 or len(step.dst) != 2:
            return False
        donor = int(step.src[0])
        if donor not in self._capture_donor_atoms():
            return False
        other = next((int(a) for a in step.dst if int(a) != donor), None)
        return other is not None and self._element(other) == "C"

    def _is_wrong_halide_attack(self, step: Step) -> bool:
        return self._is_halide_capture(step)

    @staticmethod
    def _bond_order_on(graph, a: int, b: int) -> float:
        if graph is None or a not in graph or b not in graph or not graph.has_edge(a, b):
            return 0.0
        return float(graph.edges[a, b].get("order", 0.0))

    def _targets_carbonyl(self, step: Step) -> bool:
        if step.action != "LP-/B+" or len(step.src) != 1 or len(step.dst) != 2:
            return False
        donor = step.src[0]
        if self._element(donor) not in {
            "H",
            "C",
            "O",
            "N",
            "S",
            "P",
            "F",
            "Cl",
            "Br",
            "I",
        }:
            return False
        if self._element(donor) in {"H", "C"} and self._formal_charge(donor) >= 0:
            return False
        g = step.pre_graph if step.pre_graph is not None else self.graph
        sink = next((x for x in step.dst if x != donor), None)
        if sink is None or sink not in g or self._element(sink) != "C":
            return False
        for nbr in g.neighbors(sink):
            nbr = int(nbr)
            if nbr == donor:
                continue
            if self._element(nbr) in {"O", "N", "S"} and self._bond_order_on(g, sink, nbr) >= 2.0:
                return True
        return False

    def _carbonyl_bonds(self) -> list[Tuple[int, int]]:
        pairs: list[Tuple[int, int]] = []
        for u, v in self.graph.edges():
            u, v = int(u), int(v)
            eu = self._element(u)
            ev = self._element(v)
            if {eu, ev} & {"H"} or "C" not in {eu, ev}:
                continue
            carbon = u if eu == "C" else v
            hetero = v if carbon == u else u
            if self._element(hetero) in {"O", "N", "S"} and self._bond_order(carbon, hetero) >= 2.0:
                pairs.append((carbon, hetero))
        return pairs

    def _anionic_carbonyl_donors(self) -> list[int]:
        return [
            int(atom)
            for atom in self.graph.nodes()
            if self._element(int(atom)) in {"C", "H"}
            and self._formal_charge(int(atom)) < 0
            and self._lone_pairs(int(atom)) > 0
        ]

    def _anionic_carbonyl_addition_pairs(self) -> list[Tuple[int, int, int, float]]:
        pairs: list[Tuple[int, int, int, float]] = []
        for donor in self._anionic_carbonyl_donors():
            for carbon, hetero in self._carbonyl_bonds():
                if donor in {carbon, hetero}:
                    continue
                total = (
                    self._lp_donor_score(donor, action="LP-/B+")
                    + self._electrophile_score(carbon)
                    + self._pair_compatibility_score(donor, carbon)
                )
                pairs.append((donor, carbon, hetero, total))
        return pairs

    def _is_exact_carbonyl_attack(self, step: Step, donor: int, carbon: int) -> bool:
        return (
            step.action == "LP-/B+"
            and len(step.src) == 1
            and int(step.src[0]) == int(donor)
            and self._step_forms_bond_between(step, donor, carbon)
        )

    def _is_exact_carbonyl_pi_open(self, step: Step, carbon: int, hetero: int) -> bool:
        return self._step_breaks_bond_to(step, carbon, hetero, hetero)

    def _score_anionic_carbonyl_addition_order(self, trajectory: Trajectory, result: TrajectoryScore) -> None:
        steps = list(trajectory)
        attacks: list[Tuple[int, int, int, int, float]] = []
        for donor, carbon, hetero, score in self._anionic_carbonyl_addition_pairs():
            idx = next(
                (i for i, step in enumerate(steps) if self._is_exact_carbonyl_attack(step, donor, carbon)),
                None,
            )
            if idx is not None:
                attacks.append((idx, donor, carbon, hetero, score))
        if not attacks:
            return

        idx_attack, donor, carbon, hetero, _score = min(attacks, key=lambda item: (item[0], -item[4]))

        if idx_attack == 0:
            result.add(
                "anionic_carbonyl_first_attack",
                self.weights["anionic_carbonyl_first_attack_bonus"],
                donor=donor,
                electrophile=carbon,
                hetero=hetero,
            )
        else:
            result.penalize(
                "anionic_carbonyl_delayed_attack",
                self.weights["anionic_carbonyl_delayed_attack_penalty"] * float(idx_attack),
                donor=donor,
                electrophile=carbon,
                hetero=hetero,
                attack_step=idx_attack + 1,
            )
            result.reasons.append(
                f"anionic carbonyl attack from {donor} to {carbon} is delayed " f"until step {idx_attack + 1}"
            )

        idx_proton = None
        idx_pi_open = None
        for i, step in enumerate(steps):
            formed_h_bond = self._step_forms_h_bond(step)
            if idx_proton is None and formed_h_bond is not None:
                if formed_h_bond[0] == hetero:
                    idx_proton = i
            if idx_pi_open is None and self._is_exact_carbonyl_pi_open(step, carbon, hetero):
                idx_pi_open = i

        if idx_proton is not None and idx_proton < idx_attack:
            result.penalize(
                "anionic_carbonyl_proton_before_attack",
                self.weights["anionic_carbonyl_proton_before_attack_penalty"],
                donor=donor,
                electrophile=carbon,
                hetero=hetero,
                protonation_step=idx_proton + 1,
                attack_step=idx_attack + 1,
            )
        if idx_pi_open is not None and idx_pi_open < idx_attack:
            result.penalize(
                "anionic_carbonyl_pi_before_attack",
                self.weights["anionic_carbonyl_pi_before_attack_penalty"],
                donor=donor,
                electrophile=carbon,
                hetero=hetero,
                pi_open_step=idx_pi_open + 1,
                attack_step=idx_attack + 1,
            )

    def _is_carbonyl_pi_open(self, step: Step) -> bool:
        if step.action != "B-/LP+" or len(step.src) != 2 or len(step.dst) != 1:
            return False
        sink = step.dst[0]
        if sink not in step.src:
            return False
        g = step.pre_graph if step.pre_graph is not None else self.graph
        other = step.src[1] if step.src[0] == sink else step.src[0]
        if sink not in g or other not in g:
            return False
        if self._element(sink) not in {"O", "N", "S"} or self._element(other) != "C":
            return False
        return self._bond_order_on(g, sink, other) >= 2.0

    def _is_unactivated_acyl_sigma_departure(self, step: Step) -> bool:
        if step.action != "B-/LP+" or len(step.src) != 2 or len(step.dst) != 1:
            return False
        sink = step.dst[0]
        if sink not in step.src:
            return False
        g = step.pre_graph if step.pre_graph is not None else self.graph
        carbon = step.src[1] if step.src[0] == sink else step.src[0]
        if sink not in g or carbon not in g:
            return False
        if self._element(carbon) != "C" or self._element(sink) not in {"O", "N", "S"}:
            return False
        if self._bond_order_on(g, carbon, sink) > 1.1:
            return False
        if int(g.nodes[sink].get("charge", 0)) > 0:
            return False
        has_adjacent_pi_hetero = False
        for nbr in g.neighbors(carbon):
            nbr = int(nbr)
            if nbr == sink:
                continue
            if self._element(nbr) in {"O", "N", "S"} and self._bond_order_on(g, carbon, nbr) >= 2.0:
                has_adjacent_pi_hetero = True
                break
        return has_adjacent_pi_hetero

    def _is_carbonyl_reclosure(self, step: Step) -> bool:
        if step.action != "LP-/B+" or len(step.src) != 1 or len(step.dst) != 2:
            return False
        pre = step.pre_memory or {}
        anchor = pre.get("frontier_anchor_atom")
        return_atom = pre.get("frontier_return_atom")
        if pre.get("frontier_reason") != "carbonyl_pi_open" or anchor is None or return_atom is None:
            return False
        if int(step.src[0]) != int(anchor):
            return False
        return int(return_atom) in {int(a) for a in step.dst}

    def _is_carbon_lp_sink_allowed(self, atom: int, step: Optional[Step] = None) -> bool:
        if self._element(atom) != "C":
            return True
        g = step.pre_graph if step is not None and step.pre_graph is not None else self.graph
        if atom not in g:
            return False
        if int(g.nodes[atom].get("charge", 0)) < 0 or int(g.nodes[atom].get("lone_pairs", 0)) > 0:
            return True
        for nbr in g.neighbors(atom):
            nbr = int(nbr)
            if self._element(nbr) in {"O", "N", "S"} and self._bond_order(atom, nbr) >= 2.0:
                return True
            if bool(g.edges[atom, nbr].get("conjugated", False)):
                for nn in g.neighbors(nbr):
                    nn = int(nn)
                    if nn == atom:
                        continue
                    if self._element(nn) in {"O", "N", "S"} and self._bond_order(nbr, nn) >= 2.0:
                        return True
        return False

    def _score_protonation_addition_order(self, trajectory: Trajectory, result: TrajectoryScore) -> None:
        if not self._is_protonation_addition_context():
            return

        if trajectory.steps and self._is_wrong_halide_attack(trajectory.steps[0]):
            result.penalize(
                "hx_wrong_halide_attack",
                self.weights["hx_wrong_halide_attack_penalty"],
            )
            result.reasons.append("protonation addition should start from the pi bond into H, not counterion lone pair")

        idx_pi = next(
            (i for i, st in enumerate(trajectory) if self._is_pi_to_h_start(st)),
            None,
        )
        idx_cleave = next(
            (i for i, st in enumerate(trajectory) if self._is_hx_cleavage(st)),
            None,
        )
        idx_capture = next(
            (i for i, st in enumerate(trajectory) if self._is_halide_capture(st)),
            None,
        )

        if idx_pi is not None:
            result.add(
                "hx_pi_protonation",
                self.weights["hx_pi_protonation_bonus"],
                step_index=idx_pi + 1,
            )
        else:
            result.penalize(
                "hx_missing_proton_engagement",
                self.weights["hx_missing_proton_engagement_penalty"],
            )
            result.reasons.append("protonation addition path does not engage the electrophilic proton")

        if self._is_hx_addition_context() and idx_cleave is not None:
            result.add(
                "hx_cleavage",
                self.weights["hx_cleavage_bonus"],
                step_index=idx_cleave + 1,
            )
        if idx_capture is not None:
            result.add(
                "hx_halide_capture",
                self.weights["hx_halide_capture_bonus"],
                step_index=idx_capture + 1,
            )

        if idx_pi is not None and idx_cleave is not None and idx_cleave <= idx_pi:
            result.penalize(
                "hx_bad_order",
                20.0,
                pi_step=idx_pi + 1,
                cleavage_step=idx_cleave + 1,
            )
        if self._is_hx_addition_context():
            if idx_cleave is not None and idx_capture is not None and idx_capture <= idx_cleave:
                result.penalize(
                    "hx_bad_order",
                    18.0,
                    cleavage_step=idx_cleave + 1,
                    capture_step=idx_capture + 1,
                )
        else:
            if idx_pi is not None and idx_capture is not None and idx_capture <= idx_pi:
                result.penalize(
                    "hx_bad_order",
                    18.0,
                    protonation_step=idx_pi + 1,
                    capture_step=idx_capture + 1,
                )

    def _ring_opening_leaving_options(self) -> list[Tuple[int, int]]:
        """Return ``(electrophile, leaving)`` pairs for 3-membered heterorings."""
        options: list[Tuple[int, int]] = []
        for leaving in self.graph.nodes():
            leaving = int(leaving)
            if self._element(leaving) not in {"O", "N", "S"}:
                continue
            carbon_neighbors = [int(n) for n in self.graph.neighbors(leaving) if self._element(int(n)) == "C"]
            for i, c1 in enumerate(carbon_neighbors):
                for c2 in carbon_neighbors[i + 1 :]:
                    if self.graph.has_edge(c1, c2):
                        options.append((c1, leaving))
                        options.append((c2, leaving))
        return options

    def _anionic_ring_opening_pairs(self) -> list[Tuple[int, int, int, float]]:
        donors = [
            int(a) for a in self.graph.nodes() if self._formal_charge(int(a)) < 0 and self._lone_pairs(int(a)) > 0
        ]
        if not donors:
            return []

        pairs: list[Tuple[int, int, int, float]] = []
        for electrophile, leaving in self._ring_opening_leaving_options():
            for donor in donors:
                if donor in {electrophile, leaving}:
                    continue
                total = (
                    self._lp_donor_score(donor, action="LP-/B+")
                    + self._electrophile_score(electrophile)
                    + self._leaving_group_score(leaving)
                    + self._pair_compatibility_score(donor, electrophile)
                )
                pairs.append((donor, electrophile, leaving, total))
        return pairs

    @staticmethod
    def _step_forms_bond_between(step: Step, a: int, b: int) -> bool:
        return len(step.dst) == 2 and {int(x) for x in step.dst} == {int(a), int(b)}

    @staticmethod
    def _step_breaks_bond_to(step: Step, a: int, b: int, sink: int) -> bool:
        return (
            step.action == "B-/LP+"
            and len(step.src) == 2
            and {int(x) for x in step.src} == {int(a), int(b)}
            and len(step.dst) == 1
            and int(step.dst[0]) == int(sink)
        )

    def _is_exact_ring_opening_attack(self, step: Step, donor: int, electrophile: int) -> bool:
        return (
            step.action == "LP-/B+"
            and len(step.src) == 1
            and int(step.src[0]) == int(donor)
            and self._step_forms_bond_between(step, donor, electrophile)
        )

    def _is_internal_donor_relay(self, step: Step, donor: int) -> bool:
        if int(donor) not in {int(a) for a in step.src}:
            return False
        return step.action in {"B-/LP+", "B-/B+"}

    def _score_anionic_ring_opening_order(self, trajectory: Trajectory, result: TrajectoryScore) -> None:
        steps = list(trajectory)
        attacks: list[Tuple[int, int, int, int, float]] = []
        for donor, electrophile, leaving, score in self._anionic_ring_opening_pairs():
            idx = next(
                (i for i, step in enumerate(steps) if self._is_exact_ring_opening_attack(step, donor, electrophile)),
                None,
            )
            if idx is not None:
                attacks.append((idx, donor, electrophile, leaving, score))
        if not attacks:
            return

        idx_attack, donor, electrophile, leaving, _score = min(attacks, key=lambda item: (item[0], -item[4]))

        if idx_attack == 0:
            result.add(
                "anionic_ring_opening_first_attack",
                self.weights["anionic_ring_opening_first_attack_bonus"],
                donor=donor,
                electrophile=electrophile,
                leaving=leaving,
            )
        else:
            result.penalize(
                "anionic_ring_opening_delayed_attack",
                self.weights["anionic_ring_opening_delayed_attack_penalty"] * float(idx_attack),
                donor=donor,
                electrophile=electrophile,
                leaving=leaving,
                attack_step=idx_attack + 1,
            )
            result.reasons.append(
                f"anionic ring opening attack from {donor} to {electrophile} " f"is delayed until step {idx_attack + 1}"
            )

        idx_proton = None
        for i, step in enumerate(steps):
            formed_h_bond = self._step_forms_h_bond(step)
            if formed_h_bond is not None and formed_h_bond[0] == leaving:
                idx_proton = i
                break
        if idx_proton is not None and idx_proton < idx_attack:
            result.penalize(
                "anionic_ring_opening_proton_before_attack",
                self.weights["anionic_ring_opening_proton_before_attack_penalty"],
                donor=donor,
                electrophile=electrophile,
                leaving=leaving,
                protonation_step=idx_proton + 1,
                attack_step=idx_attack + 1,
            )
            result.reasons.append(f"leaving atom {leaving} is protonated before anionic attack")

        if any(self._is_internal_donor_relay(step, donor) for step in steps[:idx_attack]):
            result.penalize(
                "anionic_ring_opening_internal_donor_relay",
                self.weights["anionic_ring_opening_internal_donor_relay_penalty"],
                donor=donor,
                attack_step=idx_attack + 1,
            )
            result.reasons.append(f"donor atom {donor} performs internal bond relay before ring opening")

        has_departure = any(self._step_breaks_bond_to(step, electrophile, leaving, leaving) for step in steps)
        if has_departure:
            result.add(
                "anionic_ring_opening_departure",
                18.0,
                electrophile=electrophile,
                leaving=leaving,
            )

    def _score_block(self, block: Tuple[Step, ...], block_index: int) -> TrajectoryScore:
        result = TrajectoryScore(family=self.family)

        self._score_block_steps(block, block_index, result)

        first, second = block[0], block[1]
        self._score_block_closure(first, second, block_index, result)
        self._score_block_coupling(first, second, block_index, result)
        self._score_block_patterns(first, second, block_index, result)

        checkpoint_score = self._score_checkpoint_quality(block)
        result.add("checkpoint_quality", checkpoint_score, block_index=block_index)

        return result

    def _score_block_steps(
        self,
        block: Tuple[Step, ...],
        block_index: int,
        result: TrajectoryScore,
    ) -> None:
        for step_index, step in enumerate(block, start=1):
            value, reason = self._score_step(step)
            result.add(
                label="step",
                score=value,
                block_index=block_index,
                step_index=step_index,
                action=step.action,
                reason=reason,
            )

    def _score_block_closure(
        self,
        first: Step,
        second: Step,
        block_index: int,
        result: TrajectoryScore,
    ) -> None:
        if not first.action.startswith("LP-"):
            return

        if second.action.endswith("LP+"):
            result.add(
                "lp_block_closure",
                self.weights["lp_closure_bonus"],
                block_index=block_index,
                first_action=first.action,
                second_action=second.action,
            )
            return

        # E2 exception: LP-/B+(base abstracts H) followed by B-/B+(C-H breaks,
        # C=C forms) is the concerted proton-abstraction / beta-bond-shift of E2
        # elimination — not an incomplete LP thread.
        if second.action == "B-/B+":
            xh = self._step_forms_h_bond(first)
            if xh is not None:
                _, h_atom = xh
                if h_atom in {int(a) for a in second.src}:
                    return

        result.penalize(
            "lp_block_closure",
            self.weights["lp_closure_penalty"],
            block_index=block_index,
            first_action=first.action,
            second_action=second.action,
        )
        result.reasons.append(f"block {block_index}: starts with LP- but does not close with LP+")

    def _score_block_coupling(
        self,
        first: Step,
        second: Step,
        block_index: int,
        result: TrajectoryScore,
    ) -> None:
        if self._shared_center(first, second):
            result.add(
                "shared_center",
                self.weights["shared_center_bonus"],
                block_index=block_index,
            )
        if self._locality(first, second):
            result.add(
                "locality",
                self.weights["locality_bonus"],
                block_index=block_index,
            )

    def _score_block_patterns(
        self,
        first: Step,
        second: Step,
        block_index: int,
        result: TrajectoryScore,
    ) -> None:
        self._score_attack_departure_pattern(first, second, block_index, result)
        self._score_attack_deprot_pattern(first, second, block_index, result)
        self._score_proton_shuttle_pattern(first, second, block_index, result)
        self._score_bad_order_patterns(first, second, block_index, result)

    def _score_attack_departure_pattern(
        self,
        first: Step,
        second: Step,
        block_index: int,
        result: TrajectoryScore,
    ) -> None:
        if not (first.action == "LP-/B+" and second.action == "B-/LP+"):
            return

        is_connected = self._is_connected_substitution(first, second)
        is_carbonyl_attack = self._targets_carbonyl(first)

        if is_carbonyl_attack and self._is_carbonyl_pi_open(second) and is_connected:
            result.add(
                "carbonyl_opening",
                self.weights["carbonyl_opening_bonus"],
                block_index=block_index,
            )
            return

        if is_carbonyl_attack and self._is_unactivated_acyl_sigma_departure(second) and is_connected:
            result.penalize(
                "carbonyl_neutral_departure",
                self.weights["carbonyl_neutral_departure_penalty"],
                block_index=block_index,
            )
            result.reasons.append(
                f"block {block_index}: neutral acyl leaving-group departure outruns " f"carbonyl opening"
            )
            return

        if is_connected and not self._is_protonation_addition_context() and not is_carbonyl_attack:
            result.add(
                "substitution_motif",
                self.weights["subst_motif_bonus"],
                block_index=block_index,
            )

    def _score_attack_deprot_pattern(
        self,
        first: Step,
        second: Step,
        block_index: int,
        result: TrajectoryScore,
    ) -> None:
        if not (first.action == "LP-/B+" and second.action == "H-/LP+"):
            return
        if len(first.src) == 1 and len(second.dst) == 1 and first.src[0] == second.dst[0]:
            result.add(
                "attack_then_deprot",
                self.weights["attack_then_deprot_bonus"],
                block_index=block_index,
            )

    def _score_proton_shuttle_pattern(
        self,
        first: Step,
        second: Step,
        block_index: int,
        result: TrajectoryScore,
    ) -> None:
        if not (first.action == "LP-/H+" and second.action == "H-/LP+"):
            return
        if len(first.src) == 1 and len(second.dst) == 1 and first.src[0] == second.dst[0]:
            result.add(
                "proton_shuttle",
                self.weights["proton_shuttle_bonus"],
                block_index=block_index,
            )

    def _score_bad_order_patterns(
        self,
        first: Step,
        second: Step,
        block_index: int,
        result: TrajectoryScore,
    ) -> None:
        if first.action == "B-/LP+" and second.action == "LP-/B+":
            result.penalize(
                "departure_before_attack",
                self.weights["departure_before_attack_penalty"],
                block_index=block_index,
            )

        if first.action == "H-/LP+" and second.action == "LP-/B+":
            if len(first.dst) == 1 and len(second.src) == 1 and first.dst[0] == second.src[0]:
                result.penalize(
                    "deprot_before_attack",
                    self.weights["deprot_before_attack_penalty"],
                    block_index=block_index,
                )

    def _step_atoms(self, step: Step) -> set[int]:
        return {int(a) for a in step.src} | {int(a) for a in step.dst}

    def _step_source_atoms(self, step: Step) -> set[int]:
        return {int(a) for a in step.src}

    def _relay_frontier_atom(self, step: Step) -> Optional[int]:
        if step.action == "B-/LP+" and len(step.dst) == 1:
            return int(step.dst[0])
        if step.action == "H-/LP+" and len(step.dst) == 1:
            return int(step.dst[0])
        return None

    def _frontier_strength(self, step: Step) -> Tuple[bool, float, str]:
        frontier = self._relay_frontier_atom(step)
        if frontier is None:
            return False, 0.0, ""

        if self._is_carbonyl_pi_open(step):
            return (
                True,
                self.weights["relay_carbonyl_continuation_bonus"],
                "carbonyl_open",
            )

        role = str(step.data.get("context_role", "") or "").lower()
        if role in {"hetero_pi", "carbonyl_target", "goal_source"}:
            return (
                True,
                self.weights["relay_carbonyl_continuation_bonus"],
                role or "context",
            )

        elem = self._element(frontier)
        if elem in {"O", "N", "S", "P"}:
            return True, self.weights["relay_continuation_bonus"], elem

        return False, 0.0, ""

    def _starts_from_frontier(self, step: Step, atom: int) -> bool:
        atom = int(atom)
        if step.action in {"LP-/B+", "LP-/H+"}:
            return len(step.src) == 1 and int(step.src[0]) == atom
        if step.action == "B-/B+":
            return atom in {int(a) for a in step.src}
        return False

    def _score_flow_continuity(self, trajectory: Trajectory, result: TrajectoryScore) -> None:
        steps = list(trajectory)
        for i in range(len(steps) - 1):
            prev = steps[i]
            nxt = steps[i + 1]
            frontier = self._relay_frontier_atom(prev)
            if frontier is None:
                continue

            should_continue, base_bonus, frontier_reason = self._frontier_strength(prev)
            if not should_continue:
                continue

            if self._starts_from_frontier(nxt, frontier):
                result.add(
                    "relay_continuation",
                    base_bonus,
                    from_step=i + 1,
                    to_step=i + 2,
                    frontier_atom=frontier,
                    frontier_reason=frontier_reason,
                )
                continue

            # E1/E2 exception: after C-heteroatom sigma-bond departure
            # B-/LP+(C,X→X) with X=O/N/S, if the very next step is a bond
            # shift (B-/B+), this is the alkene-forming step of an elimination
            # — relay stops at X. Do NOT apply to pi-bond breaking (C=O, C=N
            # in carbonyl/imine/aromatic): those have bond_order > 1 and are
            # nucleophilic-addition contexts where relay_interruption should fire.
            if prev.action == "B-/LP+" and len(prev.src) == 2 and len(prev.dst) == 1 and nxt.action == "B-/B+":
                _sink = int(prev.dst[0])
                _other = int(prev.src[1]) if int(prev.src[0]) == _sink else int(prev.src[0])
                if (
                    self._element(_other) == "C"
                    and self._element(_sink) in {"O", "N", "S"}
                    and self._bond_order(_other, _sink) < 1.5
                ):
                    continue

            penalty = (
                self.weights["relay_carbonyl_interruption_penalty"]
                if frontier_reason in {"carbonyl_open", "hetero_pi", "carbonyl_target", "goal_source"}
                else self.weights["relay_interruption_penalty"]
            )
            if self._step_atoms(prev).isdisjoint(self._step_atoms(nxt)):
                penalty += 6.0

            result.penalize(
                "relay_interruption",
                penalty,
                from_step=i + 1,
                to_step=i + 2,
                frontier_atom=frontier,
                frontier_reason=frontier_reason,
                next_action=nxt.action,
            )
            result.reasons.append(
                f"step {i + 2} breaks electron-flow continuity: frontier atom "
                f"{frontier} from step {i + 1} should continue before a new relay starts"
            )

    def _score_redundant_flow(self, trajectory: Trajectory, result: TrajectoryScore) -> None:
        steps = list(trajectory)
        seen_steps: Dict[Tuple[str, Tuple[int, ...], Tuple[int, ...]], int] = {}
        for i, step in enumerate(steps):
            key = (step.action, tuple(step.src), tuple(step.dst))
            if key in seen_steps:
                result.penalize(
                    "repeated_step",
                    self.weights["repeated_step_penalty"],
                    first_step=seen_steps[key] + 1,
                    repeated_step=i + 1,
                    action=step.action,
                )
                result.reasons.append(
                    f"step {i + 1} repeats an earlier primitive move from step " f"{seen_steps[key] + 1}"
                )
            else:
                seen_steps[key] = i

        seen_pairs: Dict[
            Tuple[
                Tuple[str, Tuple[int, ...], Tuple[int, ...]],
                Tuple[str, Tuple[int, ...], Tuple[int, ...]],
            ],
            int,
        ] = {}
        for i in range(len(steps) - 1):
            k1 = (steps[i].action, tuple(steps[i].src), tuple(steps[i].dst))
            k2 = (steps[i + 1].action, tuple(steps[i + 1].src), tuple(steps[i + 1].dst))
            pair = (k1, k2)
            if pair in seen_pairs:
                result.penalize(
                    "repeated_pair",
                    self.weights["repeated_pair_penalty"],
                    first_pair_start=seen_pairs[pair] + 1,
                    repeated_pair_start=i + 1,
                )
                result.reasons.append(
                    f"steps {i + 1}-{i + 2} repeat an earlier two-step relay from "
                    f"steps {seen_pairs[pair] + 1}-{seen_pairs[pair] + 2}"
                )
            else:
                seen_pairs[pair] = i

    def _score_carbonyl_continuity(self, trajectory: Trajectory, result: TrajectoryScore) -> None:
        steps = list(trajectory)
        for i, step in enumerate(steps):
            if not self._is_carbonyl_pi_open(step):
                continue
            sink = int(step.dst[0])
            carbon = int(step.src[1]) if int(step.src[0]) == sink else int(step.src[0])
            j = next(
                (
                    k
                    for k in range(i + 1, len(steps))
                    if steps[k].action == "LP-/B+"
                    and len(steps[k].src) == 1
                    and int(steps[k].src[0]) == sink
                    and carbon in {int(a) for a in steps[k].dst}
                ),
                None,
            )
            if j is None:
                continue
            label = "carbonyl_reclosure_immediate" if j == i + 1 else "carbonyl_reclosure_late"
            bonus = (
                self.weights["carbonyl_reclosure_immediate_bonus"]
                if j == i + 1
                else self.weights["carbonyl_reclosure_late_bonus"]
            )
            result.add(
                label,
                bonus,
                opening_step=i + 1,
                reclosure_step=j + 1,
                donor=sink,
                electrophile=carbon,
            )

    def _score_global_order(self, trajectory: Trajectory, result: TrajectoryScore) -> None:
        idx_attack = self._first_index(trajectory, "LP-/B+")
        if idx_attack is None and self._is_protonation_addition_context():
            idx_attack = next(
                (i for i, st in enumerate(trajectory) if self._is_pi_to_h_start(st)),
                None,
            )
        idx_depart = self._first_index(trajectory, "B-/LP+")
        idx_deprot = self._first_index(trajectory, "H-/LP+")

        if idx_attack is not None and idx_depart is not None:
            if idx_attack < idx_depart:
                result.add(
                    "global_attack_before_departure",
                    self.weights["global_attack_before_departure_bonus"],
                )
            else:
                result.penalize(
                    "global_attack_before_departure",
                    self.weights["global_departure_before_attack_penalty"],
                )

        if idx_attack is not None and idx_deprot is not None:
            if idx_deprot > idx_attack:
                result.add(
                    "global_deprot_after_attack",
                    self.weights["global_deprot_after_attack_bonus"],
                )
            else:
                result.penalize(
                    "global_deprot_after_attack",
                    self.weights["global_deprot_before_attack_penalty"],
                )

    def _score_family_match(self, trajectory: Trajectory, result: TrajectoryScore) -> None:
        if self._is_protonation_addition_context():
            return
        best_pair = self._best_substitution_pair()
        if best_pair is None:
            return

        donor, electrophile, leaving = best_pair
        has_attack = any(
            st.action == "LP-/B+" and len(st.src) == 1 and st.src[0] == donor and set(st.dst) == {donor, electrophile}
            for st in trajectory
        )
        has_depart = any(
            st.action == "B-/LP+" and set(st.src) == {leaving, electrophile} and st.dst == (leaving,)
            for st in trajectory
        )
        has_deprot = any(st.action == "H-/LP+" and st.dst == (donor,) for st in trajectory)

        if has_attack:
            result.add("best_attack_pair", 18.0, donor=donor, electrophile=electrophile)
        if has_depart:
            result.add(
                "best_departure_pair",
                14.0,
                leaving=leaving,
                electrophile=electrophile,
            )
        if has_attack and has_depart:
            result.add(
                "best_substitution_family",
                20.0,
                donor=donor,
                electrophile=electrophile,
                leaving=leaving,
            )
        if has_deprot and has_attack:
            result.add("post_attack_deprotonation", 10.0, donor=donor)

    def _score_step(self, step: Step) -> Tuple[float, str]:
        if step.action == "LP-/B+":
            score, reason = self._score_lp_to_bond(step)
        elif step.action == "LP-/H+":
            score, reason = self._score_lp_to_proton(step)
        elif step.action == "B-/LP+":
            score, reason = self._score_bond_to_lp(step)
        elif step.action == "H-/LP+":
            score, reason = self._score_h_to_lp(step)
        elif step.action == "H-/B+":
            score, reason = self._score_h_to_bond(step)
        elif step.action == "B-/B+":
            score, reason = self._score_bond_to_bond(step)
        else:
            return -40.0, f"unknown action {step.action}"
        ctx_score, ctx_reason = self._contextual_step_adjustment(step)
        if ctx_reason:
            reason = f"{reason}; {ctx_reason}"
        return score + ctx_score, reason

    def _score_lp_to_bond(self, step: Step) -> Tuple[float, str]:
        if len(step.src) != 1 or len(step.dst) != 2:
            return -100.0, "malformed LP-/B+"

        donor = step.src[0]
        electrophile = next((x for x in step.dst if x != donor), None)
        if electrophile is None:
            return -100.0, "LP-/B+ destination must contain donor and electrophile"

        donor_score = self._lp_donor_score(donor, action="LP-/B+")
        electrophile_score = self._electrophile_score(electrophile)
        pair_score = self._pair_compatibility_score(donor, electrophile)
        chemoselectivity = self.weights["chemoselectivity_scale"] * self._best_atom_margin(
            donor,
            lambda a: self._lp_donor_score(a, action="LP-/B+"),
            candidates=[a for a in self.graph.nodes() if self._lone_pairs(a) > 0],
        )

        total = donor_score + electrophile_score + pair_score + chemoselectivity
        if self._is_carbonyl_reclosure(step):
            total += self.weights["carbonyl_reclosure_immediate_bonus"]
        e_score = self.electronic.score_lp_to_bond(int(donor), int(electrophile))
        total += self.weights["electronic_lp_attack_scale"] * e_score.total
        return total, (
            f"LP donor {donor} attacks electrophile {electrophile}; "
            f"electronic={e_score.total:.2f} "
            f"(FMO={e_score.fmo:.2f}, Hückel={e_score.huckel:.2f}, HSAB={e_score.hsab:.2f})"
        )

    def _score_lp_to_proton(self, step: Step) -> Tuple[float, str]:
        if len(step.src) != 1:
            return -100.0, "malformed LP-/H+"

        atom = step.src[0]
        base = self._lp_donor_score(atom, action="LP-/H+")
        elem = self._element(atom)

        if elem in {"Br", "Cl", "I"} and self.graph.degree(atom) == 1:
            base -= self.weights["bad_halogen_lp_h_penalty"]

        return base, f"LP on atom {atom} accepts proton"

    @staticmethod
    def _graph_charge(g, atom: int) -> int:
        if g is None or int(atom) not in g:
            return 0
        try:
            value = g.nodes[int(atom)].get("charge", 0)
            if isinstance(value, (tuple, list)) and value:
                value = value[0]
            return int(round(float(value)))
        except Exception:
            return 0

    @staticmethod
    def _graph_aromatic(g, atom: int) -> bool:
        if g is None or int(atom) not in g:
            return False
        try:
            value = g.nodes[int(atom)].get("aromatic", False)
            if isinstance(value, (tuple, list)) and value:
                value = value[0]
            return bool(value)
        except Exception:
            return False

    def _is_aromatic_cation_adjacent_sink(self, step: Step, sink: int) -> bool:
        role = str(step.data.get("context_role", "") or "").lower()
        if role != "aromatic_pi":
            return False

        g = step.pre_graph if step.pre_graph is not None else self.graph
        sink = int(sink)
        if not self._graph_aromatic(g, sink):
            return False

        for nbr in g.neighbors(sink):
            nbr = int(nbr)
            if nbr in {int(x) for x in step.src} and nbr != sink:
                continue
            if self._graph_charge(g, nbr) > 0:
                return True

        return False

    def _score_bond_to_lp(self, step: Step) -> Tuple[float, str]:
        if len(step.src) != 2 or len(step.dst) != 1:
            return -100.0, "malformed B-/LP+"

        a, b = step.src
        sink = step.dst[0]
        if sink not in {a, b}:
            return -30.0, "LP sink is not one endpoint of the breaking bond"

        sink_score = self._leaving_group_score(sink)
        other = b if sink == a else a
        polarization = self._partial_charge(other) - self._partial_charge(sink)
        edge_bonus = 2.0 if self._has_edge(a, b) and self._bond_order(a, b) >= 1.0 else -5.0
        total = 6.0 + sink_score + max(-4.0, min(4.0, 10.0 * polarization)) + edge_bonus
        if self._is_carbonyl_pi_open(step):
            total += self.weights["carbonyl_opening_bonus"]
        elif self._is_unactivated_acyl_sigma_departure(step):
            total -= self.weights["carbonyl_neutral_departure_penalty"]
        if self._element(sink) == "C":
            if self._is_carbon_lp_sink_allowed(sink, step=step):
                total -= self.weights["carbon_lp_sink_allowed_penalty"]
            else:
                total -= self.weights["carbon_lp_sink_penalty"]
        if self._is_aromatic_cation_adjacent_sink(step, int(sink)):
            total += self.weights["aromatic_cation_adjacent_sink_bonus"]
        e_score = self.electronic.score_bond_to_lp((int(a), int(b)), int(sink))
        total += self.weights["electronic_bond_cleavage_scale"] * e_score.total
        return total, (
            f"bond {a}-{b} breaks to LP on {sink}; "
            f"electronic={e_score.total:.2f} "
            f"(FMO={e_score.fmo:.2f}, Hückel={e_score.huckel:.2f}, HSAB={e_score.hsab:.2f})"
        )

    def _score_bond_to_bond(self, step: Step) -> Tuple[float, str]:
        if len(step.src) != 2 or len(step.dst) != 2:
            return -100.0, "malformed B-/B+"

        a, b = int(step.src[0]), int(step.src[1])
        c, d = int(step.dst[0]), int(step.dst[1])
        shared = step.shared_atom
        score = -2.0
        if self._has_edge(a, b):
            if self._bond_order(a, b) >= 2.0 or abs(self._bond_order(a, b) - 1.5) < 1e-8:
                score += 6.0
            elif bool(self._edge(a, b).get("conjugated", False)):
                score += 3.0
        else:
            score -= 10.0

        e_score = self.electronic.score_bond_to_bond(
            (a, b),
            (c, d),
            shared_atom=shared,
        )
        score += self.weights["electronic_bond_flow_scale"] * e_score.total
        return score, (
            f"bond {a}-{b} donates into {c}-{d}; "
            f"electronic={e_score.total:.2f} "
            f"(FMO={e_score.fmo:.2f}, Hückel={e_score.huckel:.2f}, HSAB={e_score.hsab:.2f})"
        )

    def _score_h_to_lp(self, step: Step) -> Tuple[float, str]:
        if len(step.src) != 1 or len(step.dst) != 1:
            return -100.0, "malformed H-/LP+"

        atom = step.dst[0]
        elem = self._element(atom)
        score = 3.0

        if elem in {"O", "N", "S"}:
            score += 10.0
        elif elem in {"Br", "Cl", "I"}:
            score += 1.0
        else:
            score -= 6.0

        if self._hcount(step.src[0]) >= 1:
            score += 1.0

        return score, f"H returns electrons to LP on atom {atom}"

    def _score_h_to_bond(self, step: Step) -> Tuple[float, str]:
        if len(step.src) != 1 or len(step.dst) != 2:
            return -100.0, "malformed H-/B+"

        src = step.src[0]
        other = next((x for x in step.dst if x != src), None)
        if other is None:
            return -100.0, "H-/B+ destination must contain source atom"

        score = -3.0
        if self._element(src) in {"O", "N", "S"}:
            score += 2.0
        if self._element(other) == "C" and any(
            self._element(nbr) in {"Br", "Cl", "I"} for nbr in self.graph.neighbors(other)
        ):
            score += 1.0
        return score, f"H contributes to bond involving atom {other}"

    def _score_checkpoint_quality(self, block: Tuple[Step, ...]) -> float:
        last = block[-1]
        score = 0.0
        if last.arrow_boundary_reached:
            score += self.weights["checkpoint_boundary_bonus"]
        if last.last_graph_valid is True:
            score += self.weights["checkpoint_valid_bonus"]
        elif last.last_graph_valid is False:
            score -= self.weights["checkpoint_invalid_penalty"]
        if last.state_smiles:
            score += self.weights["checkpoint_smiles_bonus"]
        return score

    def _lp_donor_score(self, atom: int, action: str) -> float:
        lp = self._lone_pairs(atom)
        if lp <= 0:
            return -100.0

        elem = self._element(atom)
        hyb = self._hybridization(atom)
        formal = self._formal_charge(atom)
        partial = self._partial_charge(atom)

        score = 6.0 + min(lp, 3.0)
        score += self.weights["formal_charge_scale"] * max(0.0, -formal)
        score -= self.weights["formal_charge_scale"] * max(0.0, formal)
        score += max(-6.0, min(8.0, -self.weights["partial_charge_scale"] * partial))

        if action == "LP-/B+":
            score += {
                "O": 10.0,
                "N": 8.0,
                "S": 8.0,
                "P": 5.0,
                "Br": -7.0,
                "Cl": -9.0,
                "I": -5.0,
                "C": -20.0,
            }.get(elem, 0.0)
        elif action == "LP-/H+":
            score += {
                "O": 7.0,
                "N": 7.0,
                "S": 5.0,
                "P": 4.0,
                "Br": -6.0,
                "Cl": -7.0,
                "I": -4.0,
                "C": -18.0,
            }.get(elem, 0.0)

        if elem in {"O", "N", "S"} and hyb == "SP3":
            score += 2.0
        elif elem in {"O", "N"} and hyb == "SP2":
            score -= 2.0

        if self._aromatic(atom):
            score -= self.weights["resonance_penalty"] + 1.0
        elif self._incident_conjugated(atom):
            score -= self.weights["resonance_penalty"]

        return score

    def _electrophile_score(self, atom: int) -> float:
        elem = self._element(atom)
        hyb = self._hybridization(atom)
        partial = self._partial_charge(atom)

        score = max(-4.0, min(8.0, 24.0 * partial))
        if elem == "C":
            score += 5.0
        if hyb == "SP3":
            score += 2.0

        lg_neighbors = [nbr for nbr in self.graph.neighbors(atom) if self._element(nbr) in {"Br", "Cl", "I"}]
        if lg_neighbors:
            score += 8.0 + 2.0 * len(lg_neighbors)

        return score

    def _leaving_group_score(self, atom: int) -> float:
        elem = self._element(atom)
        score = {
            "I": 14.0,
            "Br": 12.0,
            "Cl": 8.0,
            "O": 4.0,
            "N": 2.0,
            "C": -10.0,
        }.get(elem, 0.0)
        partial = self._partial_charge(atom)
        score += max(-3.0, min(3.0, -8.0 * partial))
        return score

    def _pair_compatibility_score(self, donor: int, electrophile: int) -> float:
        score = 0.0
        distance = self._graph_distance(donor, electrophile)
        if distance == 1:
            score -= 6.0
        elif distance == 2:
            score += 1.0

        lg_neighbors = [nbr for nbr in self.graph.neighbors(electrophile) if self._element(nbr) in {"Br", "Cl", "I"}]
        if lg_neighbors:
            score += 8.0

        if self._element(donor) in {"O", "N", "S"} and self._element(electrophile) == "C":
            score += 5.0
        return score

    def _shared_center(self, step1: Step, step2: Step) -> bool:
        atoms1 = set(step1.src) | set(step1.dst)
        atoms2 = set(step2.src) | set(step2.dst)
        return bool(atoms1 & atoms2)

    def _locality(self, step1: Step, step2: Step) -> bool:
        atoms1 = set(step1.src) | set(step1.dst)
        atoms2 = set(step2.src) | set(step2.dst)
        for a in atoms1:
            for b in atoms2:
                if self._graph_distance(a, b) <= 1:
                    return True
        return False

    def _is_connected_substitution(self, step1: Step, step2: Step) -> bool:
        if step1.action != "LP-/B+" or step2.action != "B-/LP+":
            return False
        donor = step1.src[0]
        electrophile = next((x for x in step1.dst if x != donor), None)
        return electrophile is not None and electrophile in step2.src

    def _first_index(self, trajectory: Trajectory, action: str) -> Optional[int]:
        for i, step in enumerate(trajectory):
            if step.action == action:
                return i
        return None

    def _best_substitution_pair(self) -> Optional[Tuple[int, int, int]]:
        donors = [a for a in self.graph.nodes() if self._lone_pairs(a) > 0]
        electrophiles = [a for a in self.graph.nodes() if self._element(a) == "C"]
        best: Optional[Tuple[int, int, int]] = None
        best_score = -math.inf

        for donor in donors:
            donor_score = self._lp_donor_score(donor, action="LP-/B+")
            if donor_score < -50:
                continue

            for electrophile in electrophiles:
                lg_neighbors = [
                    nbr for nbr in self.graph.neighbors(electrophile) if self._element(nbr) in {"Br", "Cl", "I"}
                ]
                for leaving in lg_neighbors:
                    total = (
                        donor_score
                        + self._electrophile_score(electrophile)
                        + self._leaving_group_score(leaving)
                        + self._pair_compatibility_score(donor, electrophile)
                    )
                    if total > best_score:
                        best_score = total
                        best = (donor, electrophile, leaving)

        return best
