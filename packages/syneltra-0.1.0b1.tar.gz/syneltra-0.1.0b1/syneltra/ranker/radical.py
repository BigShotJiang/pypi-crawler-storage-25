from __future__ import annotations

from typing import Dict, Optional

from .base import BaseTrajectoryRanker
from .family import TrajectoryFamily
from .models import Trajectory, TrajectoryScore


class RadicalTrajectoryRanker(BaseTrajectoryRanker):
    """Placeholder for future radical ranking logic."""

    def __init__(
        self,
        graph,
        elementary_arrows: int = 1,
        weights: Optional[Dict[str, float]] = None,
        electronic_mode: Optional[str] = None,
    ) -> None:
        super().__init__(
            graph=graph,
            family=TrajectoryFamily.RADICAL,
            elementary_arrows=elementary_arrows,
            weights=weights,
            electronic_mode=electronic_mode,
        )

    def score_trajectory(self, trajectory: Trajectory | object) -> TrajectoryScore:
        trajectory = self._coerce_trajectory(trajectory)
        raise NotImplementedError("RadicalTrajectoryRanker is reserved for later implementation.")
