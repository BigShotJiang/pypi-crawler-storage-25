from __future__ import annotations

"""Simple data models for mechanism visualization."""

from dataclasses import dataclass
from typing import Any, Dict, Tuple


@dataclass(frozen=True)
class Transition:
    """Minimal transition record used by the visualizer.

    :param kind: Transition kind, e.g. ``'LP-/B+'`` or ``'B-/B+'``.
    :type kind: str
    :param src: Source atom/bond tuple.
    :type src: Tuple[int, ...]
    :param dst: Destination atom/bond tuple.
    :type dst: Tuple[int, ...]
    :param data: Auxiliary metadata such as ``shared_atom``.
    :type data: Dict[str, Any]
    """

    kind: str
    src: Tuple[int, ...]
    dst: Tuple[int, ...]
    data: Dict[str, Any]
