from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple
import copy

import networkx as nx

Memory = Dict[str, Any]


@dataclass(frozen=True)
class Transition:
    """
    One abstract unit operation in the mechanism search.

    :param kind:
        Operator label, e.g. ``"LP-/B+"`` or ``"B-/LP+"``.
    :type kind: str
    :param src:
        Source atom/bond tuple.
    :type src: Tuple[int, ...]
    :param dst:
        Destination atom/bond tuple.
    :type dst: Tuple[int, ...]
    :param data:
        Optional extensible payload for operator-specific metadata.
    :type data: Dict[str, Any]
    """

    kind: str
    src: Tuple[int, ...]
    dst: Tuple[int, ...]
    data: Dict[str, Any] = field(default_factory=dict)

    def __str__(self) -> str:
        return f"{self.kind}: {self.src} -> {self.dst}"

    @property
    def head(self) -> str:
        """Return the left-hand token of ``kind``."""
        return self.kind.split("/", 1)[0]

    @property
    def tail(self) -> str:
        """Return the right-hand token of ``kind``."""
        return self.kind.split("/", 1)[1]

    def dedup_key(self) -> Tuple[Any, ...]:
        """Return a stable key for candidate deduplication."""
        return (self.kind, self.src, self.dst)


@dataclass
class StateSnapshot:
    """
    One search state.

    :param graph:
        Working graph at this state.
    :type graph: nx.Graph
    :param memory:
        Generic per-state memory for future extensions.
    :type memory: Dict[str, Any]
    """

    graph: nx.Graph
    memory: Memory = field(default_factory=dict)

    def clone(self) -> "StateSnapshot":
        """Return a deep copy of the state."""
        return StateSnapshot(
            graph=copy.deepcopy(self.graph),
            memory=copy.deepcopy(self.memory),
        )


@dataclass
class Trajectory:
    """
    One complete path from start state to goal state.

    Notes
    -----
    ``states[i] --transitions[i]--> states[i + 1]``
    """

    states: List[StateSnapshot]
    transitions: List[Transition]

    def graphs(
        self,
        *,
        full: bool = False,
        recompute_charge: Optional[bool] = True,
    ) -> List[nx.Graph]:
        """
        Return graphs for each stored state.

        :param full:
            If ``True``, map the current state back onto the stored full
            reactant/product reference graph.
        :type full: bool
        :param recompute_charge:
            Override whether formal charge should be recomputed on the returned
            full graphs. Ignored when ``full=False``.
        :type recompute_charge: Optional[bool]
        :return: Graph list for the trajectory states.
        :rtype: List[nx.Graph]
        """
        if not full:
            return [state.graph for state in self.states]

        from ..chemistry.graph import materialize_full_graph

        return [materialize_full_graph(state.graph, recompute_charge=recompute_charge) for state in self.states]

    def smiles(
        self,
        *,
        full: bool = True,
        recompute_charge: Optional[bool] = True,
        graph_to_smi_fn=None,
    ) -> List[Optional[str]]:
        """
        Return one SMILES string for each stored state.

        :param full:
            If ``True``, convert the full mapped graph for each state.
            Otherwise convert the working graph fragment itself.
        :type full: bool
        :param recompute_charge:
            Whether to recompute formal charges before converting the full
            graph. Ignored when ``full=False``.
        :type recompute_charge: Optional[bool]
        :param graph_to_smi_fn:
            Optional callable to convert a graph to a SMILES string. If not
            provided, this method imports ``graph_to_smi`` lazily from
            ``synkit.IO``.
        :type graph_to_smi_fn: Any
        :return: A list of SMILES strings or ``None`` for states that fail
            conversion.
        :rtype: List[Optional[str]]
        """
        fn = graph_to_smi_fn
        if fn is None:
            try:
                from synkit.IO import graph_to_smi as fn
            except Exception:
                fn = None

        out: List[Optional[str]] = []
        graphs = self.graphs(full=full, recompute_charge=recompute_charge)
        for g in graphs:
            if fn is None:
                out.append(None)
                continue
            try:
                smi = fn(g)
            except Exception:
                smi = None
            out.append(smi if smi else None)
        return out


@dataclass
class ExpansionContext:
    """
    Context passed to constraints during expansion.

    :param current:
        Current search state.
    :type current: StateSnapshot
    :param goal:
        Goal search state.
    :type goal: StateSnapshot
    :param history:
        Transition history leading to ``current``.
    :type history: List[Transition]
    :param states:
        State history leading to ``current``.
    :type states: List[StateSnapshot]
    :param depth:
        Current search depth.
    :type depth: int
    """

    current: StateSnapshot
    goal: StateSnapshot
    history: List[Transition]
    states: List[StateSnapshot]
    depth: int
