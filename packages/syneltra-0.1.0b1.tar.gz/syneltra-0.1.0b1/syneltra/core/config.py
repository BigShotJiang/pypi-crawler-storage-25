from __future__ import annotations

from dataclasses import dataclass, fields
from typing import Literal, Optional, Tuple, Union

SearchStrategy = Literal["beam", "dfs", "bfs", "best_first"]
BeamMode = Literal[
    "recall_beam",
    "cumulative_beam",
    "softmax_beam",
    "recall",
    "legacy",
    "cumulative",
    "softmax",
    "custom",
]
BeamScoreMode = Literal["legacy", "cumulative", "softmax_logprob"]
ValidityCheckMode = Union[bool, Literal["fixed", "window", "off"]]
SearchLogLevel = Literal["summary", "candidates", "all"]
ElectronicMode = Literal[
    "none",
    "fmo",
    "fmo_huckel",
    "fmo_hsab",
    "fmo_hsba",
    "consensus",
]


@dataclass(frozen=True)
class MechanismSearchConfig:
    """Configuration for :class:`syneltra.mechanism_search.MechanismEnumerator`.

    Beam behavior is selected with one constructor argument, ``beam_mode``:

    - ``"recall_beam"``: legacy/recall-safe ranking, matching the prior
      working behavior.
    - ``"cumulative_beam"``: generation-style cumulative path cost.
    - ``"softmax_beam"``: generation-style sibling-normalized log-probability.

    ``beam_score_mode`` and ``beam_use_prefix_score`` are internal switches
    derived from ``beam_mode``. Use ``beam_mode="custom"`` only if you want to
    control those low-level switches manually.
    """

    ignore_h_implicit: bool = False
    use_online_ranker: bool = True
    beam_guidance: bool = True
    search_strategy: SearchStrategy = "beam"
    beam_mode: BeamMode = "softmax_beam"
    beam_width: int = 96

    # Exact/debug search controls.
    exact_global_dedup: bool = True
    resonance_state_dedup: bool = True
    exact_use_candidate_limits: bool = False
    best_first_open_limit: int = 4096

    # Candidate controls. A value <= 0 disables the corresponding hard cap.
    max_transition_proposals: int = 0
    max_expanded_candidates: int = 0

    # Beam-specific controls. Recall-safe defaults do not globally discard
    # alternative histories that reach the same state signature.
    beam_score_dedup: bool = False
    beam_frontier_signature_dedup: bool = False
    beam_state_dominance_epsilon: float = 1e-9
    beam_diversity: bool = False
    beam_diversity_per_key: int = 8
    beam_pool_multiplier: int = 6
    beam_goal_bucket_size: int = 2
    beam_keep_completed: bool = True
    beam_stop_when_enough_goals: bool = False

    # Internal beam path scoring controls. These are overwritten by beam_mode
    # unless beam_mode="custom".
    # legacy: previous working behavior, sort by concatenated lexicographic rank.
    # cumulative: generation-style child_cost = parent_cost + local_cost + penalty.
    # softmax_logprob: cumulative sibling-normalized local log-probability.
    beam_score_mode: BeamScoreMode = "legacy"
    beam_use_prefix_score: bool = False
    beam_score_temperature: float = 1.0
    beam_length_normalization_alpha: float = 0.0
    beam_paths_per_state: int = 0

    # Operator-balanced candidate caps. Disabled by default to preserve recall.
    beam_operator_balance: bool = False
    max_transition_proposals_per_kind: int = 0
    max_expanded_candidates_per_kind: int = 0

    # Scoring extensions.
    length_penalty: float = 0.75
    resonance_score_scale: float = 0.18
    pka_score_scale: float = 0.20
    phase_score_scale: float = 0.16

    # Chemistry constraints/ranking controls.
    continuity_mode: Literal["frontier", "legacy"] = "frontier"
    # Hard continuity constraints are disabled by default. Electron flow is
    # guided by a soft segment objective instead, because multi-site mechanisms
    # can legitimately end one LP thread and start another.
    enforce_lp_continuity: bool = True
    # If True, an LP+ endpoint only creates an enforced/strong LP frontier
    # when the atom is actually an anionic electron-rich site after the step.
    # This avoids over-constraining neutralization proton transfers, e.g.
    # N+--H -> N: where the next chemically relevant LP- may come from a
    # different neutral heteroatom. Carbonyl opening O- remains enforced.
    lp_continuity_requires_negative_charge: bool = True
    # If True, a B-/LP+ step from a non-H heavy bond creates an active LP
    # frontier even when charge recomputation is disabled/relaxed. This
    # captures carbonyl opening / heteroatom lone-pair generation while still
    # avoiding hard continuity after ordinary X-H neutralization.
    lp_continuity_heavy_bond_frontier: bool = True
    enforce_bond_continuity: bool = True
    hard_bplus_clearance: bool = True

    # Local edit scoring is mechanistic and centralized in the beam search:
    # hard grammar filters first, then a local edit scorer, then cumulative/
    # softmax path scoring. Product-context/electronic hints are tie-breakers.

    # Soft electron-flow segmentation. This replaces hard LP/B frontier
    # enforcement and the older LP-specific source preference. The objective
    # prefers fewer independent electron-flow threads, rewards continuation of
    # an active frontier, and softly penalizes detached new segments.
    electron_flow_guidance: bool = True
    electron_flow_continuity_bonus: float = 4.0
    electron_flow_touch_bonus: float = 1.0
    electron_flow_new_segment_penalty: float = 1.5
    electron_flow_unresolved_frontier_penalty: float = 4.0

    # Graph-validity checkpoints.  Enabled by default so multi-step arrows may
    # pass through transient invalid intermediates but must recover at the arrow
    # boundary.  ``True`` maps to fixed checkpoints every
    # ``validity_check_arrows`` micro-steps; ``False`` or ``"off"`` is an
    # explicit escape hatch for exhaustive/debug runs.
    validity_check_mode: ValidityCheckMode = True
    validity_check_arrows: int = 2
    validity_check_window: Tuple[int, int] = (2, 3)
    prefer_three_action_policy: bool = True
    enforce_arrow_plans: bool = False
    prefer_ionic_intermediates: bool = True
    electronic_guidance: bool = True
    electronic_mode: ElectronicMode = "consensus"

    # Context controls.
    context_shell_radius: int = 2
    context_max_classes: int = 8
    context_conjugation_only: bool = True

    # Working-order/Kekule policy is intentionally internal: the enumerator
    # automatically switches to integer Kekule working orders when changed
    # reaction-center edges contain aromatic order=1.5, and relaxes aromatic
    # electron metadata in that internal representation.

    # Structured debug logging.  When enabled, events are stored on the
    # enumerator as ``search_log`` and optionally written as JSONL to
    # ``search_log_path``.  ``all`` logs every proposed transition and rejection
    # stage; ``candidates`` logs expansion-level candidate decisions; ``summary``
    # logs only working-order decisions, layers, and goal hits.
    search_logging: bool = False
    search_log_path: Optional[str] = None
    search_log_level: SearchLogLevel = "summary"
    search_log_max_events: int = 0
    search_log_append: bool = False
    search_log_store_memory: bool = True

    @property
    def mechanism_search_strategy(self) -> SearchStrategy:
        """Backward-compatible alias for :attr:`search_strategy`.

        Older internal code and notebooks may still refer to
        ``mechanism_search_strategy`` after the search package was renamed from
        graph search to mechanism search. The public configuration field is
        still ``search_strategy``.
        """
        return self.search_strategy

    @staticmethod
    def _normalize_validity_check_mode(
        value: ValidityCheckMode,
    ) -> Literal["fixed", "window", "off"]:
        """Normalize bool/string checkpoint configuration to one small enum."""
        if isinstance(value, bool):
            return "fixed" if value else "off"
        mode = str(value).lower().strip()
        aliases = {
            "true": "fixed",
            "yes": "fixed",
            "on": "fixed",
            "1": "fixed",
            "fixed": "fixed",
            "window": "window",
            "false": "off",
            "no": "off",
            "off": "off",
            "none": "off",
            "0": "off",
        }
        if mode not in aliases:
            raise ValueError("validity_check_mode must be True, False, 'fixed', 'window', or 'off'")
        return aliases[mode]

    def __post_init__(self) -> None:
        """Normalize the high-level beam mode into internal search switches."""
        mode = str(self.beam_mode).lower().strip()
        aliases = {
            "recall": "recall_beam",
            "legacy": "recall_beam",
            "legacy_beam": "recall_beam",
            "cumulative": "cumulative_beam",
            "generation": "cumulative_beam",
            "generative": "cumulative_beam",
            "generative_beam": "cumulative_beam",
            "softmax": "softmax_beam",
            "softmax_logprob": "softmax_beam",
        }
        mode = aliases.get(mode, mode)
        valid = {"recall_beam", "cumulative_beam", "softmax_beam", "custom"}
        if mode not in valid:
            raise ValueError(
                "beam_mode must be one of " "'recall_beam', 'cumulative_beam', 'softmax_beam', or 'custom'"
            )
        object.__setattr__(self, "beam_mode", mode)

        validity_mode = self._normalize_validity_check_mode(self.validity_check_mode)
        object.__setattr__(self, "validity_check_mode", validity_mode)

        if mode == "custom":
            return
        if mode == "recall_beam":
            object.__setattr__(self, "beam_score_mode", "legacy")
            object.__setattr__(self, "beam_use_prefix_score", False)
        elif mode == "cumulative_beam":
            object.__setattr__(self, "beam_score_mode", "cumulative")
            object.__setattr__(self, "beam_use_prefix_score", True)
        elif mode == "softmax_beam":
            object.__setattr__(self, "beam_score_mode", "softmax_logprob")
            object.__setattr__(self, "beam_use_prefix_score", True)

    @classmethod
    def recommended(cls) -> "MechanismSearchConfig":
        """Return the recall-safe default beam configuration."""
        return cls(beam_mode="softmax_beam")

    @classmethod
    def recall_beam(cls, **kwargs) -> "MechanismSearchConfig":
        """Compatibility wrapper for ``beam_mode='recall_beam'``."""
        data = {
            "beam_mode": "recall_beam",
            "search_strategy": "beam",
            "beam_width": 96,
            "max_transition_proposals": 0,
            "max_expanded_candidates": 0,
            "beam_score_dedup": False,
            "beam_frontier_signature_dedup": False,
            "beam_diversity": False,
            "beam_stop_when_enough_goals": False,
            "beam_paths_per_state": 0,
            "beam_operator_balance": False,
        }
        data.update(kwargs)
        return cls(**data)

    @classmethod
    def cumulative_beam(cls, **kwargs) -> "MechanismSearchConfig":
        """Compatibility wrapper for ``beam_mode='cumulative_beam'``."""
        data = {
            "beam_mode": "cumulative_beam",
            "search_strategy": "beam",
            "beam_width": 96,
            "max_transition_proposals": 0,
            "max_expanded_candidates": 0,
            "beam_score_dedup": False,
            "beam_frontier_signature_dedup": False,
            "beam_diversity": False,
            "beam_stop_when_enough_goals": False,
            "beam_paths_per_state": 0,
            "beam_operator_balance": False,
        }
        data.update(kwargs)
        return cls(**data)

    @classmethod
    def generative_beam(cls, **kwargs) -> "MechanismSearchConfig":
        """Alias for :meth:`cumulative_beam`."""
        return cls.cumulative_beam(**kwargs)

    @classmethod
    def softmax_beam(cls, **kwargs) -> "MechanismSearchConfig":
        """Compatibility wrapper for ``beam_mode='softmax_beam'``."""
        data = {
            "beam_mode": "softmax_beam",
            "search_strategy": "beam",
            "beam_width": 96,
            "max_transition_proposals": 0,
            "max_expanded_candidates": 0,
            "beam_score_dedup": False,
            "beam_frontier_signature_dedup": False,
            "beam_diversity": False,
            "beam_stop_when_enough_goals": False,
            "beam_score_temperature": 1.0,
            "beam_paths_per_state": 0,
            "beam_operator_balance": False,
        }
        data.update(kwargs)
        return cls(**data)

    @classmethod
    def fast_beam(cls, **kwargs) -> "MechanismSearchConfig":
        """Return a faster recall-beam configuration for large reactions."""
        data = {
            "beam_mode": "recall_beam",
            "search_strategy": "beam",
            "beam_width": 32,
            "max_transition_proposals": 128,
            "max_expanded_candidates": 96,
            "beam_score_dedup": False,
            "beam_frontier_signature_dedup": False,
            "beam_diversity": True,
            "beam_diversity_per_key": 6,
            "beam_pool_multiplier": 6,
            "beam_stop_when_enough_goals": False,
            "beam_paths_per_state": 0,
            "beam_operator_balance": False,
        }
        data.update(kwargs)
        return cls(**data)

    @classmethod
    def strong_beam(cls, **kwargs) -> "MechanismSearchConfig":
        """Return a wider recall-oriented beam configuration."""
        data = {
            "beam_mode": "recall_beam",
            "search_strategy": "beam",
            "beam_width": 160,
            "max_transition_proposals": 0,
            "max_expanded_candidates": 0,
            "beam_score_dedup": False,
            "beam_frontier_signature_dedup": False,
            "beam_diversity": True,
            "beam_diversity_per_key": 12,
            "beam_pool_multiplier": 8,
            "beam_stop_when_enough_goals": False,
            "beam_paths_per_state": 0,
            "beam_operator_balance": False,
        }
        data.update(kwargs)
        return cls(**data)

    @classmethod
    def balanced_beam(cls, **kwargs) -> "MechanismSearchConfig":
        """Return a moderate recall beam with diversity but no hard caps."""
        data = {
            "beam_mode": "recall_beam",
            "search_strategy": "beam",
            "beam_width": 64,
            "max_transition_proposals": 0,
            "max_expanded_candidates": 0,
            "beam_score_dedup": False,
            "beam_frontier_signature_dedup": False,
            "beam_diversity": True,
            "beam_diversity_per_key": 8,
            "beam_pool_multiplier": 6,
            "beam_stop_when_enough_goals": False,
            "beam_paths_per_state": 0,
            "beam_operator_balance": False,
        }
        data.update(kwargs)
        return cls(**data)

    @classmethod
    def aggressive_beam(cls, **kwargs) -> "MechanismSearchConfig":
        """Return a strict speed-first beam preset."""
        data = {
            "beam_mode": "recall_beam",
            "search_strategy": "beam",
            "beam_width": 24,
            "max_transition_proposals": 64,
            "max_expanded_candidates": 40,
            "beam_score_dedup": True,
            "beam_frontier_signature_dedup": True,
            "beam_diversity": True,
            "beam_diversity_per_key": 3,
            "beam_pool_multiplier": 3,
            "beam_stop_when_enough_goals": True,
            "beam_paths_per_state": 1,
            "beam_operator_balance": False,
        }
        data.update(kwargs)
        return cls(**data)

    @classmethod
    def exact_bfs(cls, **kwargs) -> "MechanismSearchConfig":
        """Return a configuration for exact breadth-first enumeration."""
        data = {"search_strategy": "bfs", "beam_width": 0}
        data.update(kwargs)
        return cls(**data)

    @classmethod
    def exact_dfs(cls, **kwargs) -> "MechanismSearchConfig":
        """Return a configuration for exact depth-first enumeration."""
        data = {"search_strategy": "dfs", "beam_width": 0}
        data.update(kwargs)
        return cls(**data)

    @classmethod
    def best_first(cls, **kwargs) -> "MechanismSearchConfig":
        """Return a bounded greedy best-first configuration."""
        data = {"search_strategy": "best_first"}
        data.update(kwargs)
        return cls(**data)

    def with_updates(self, **kwargs) -> "MechanismSearchConfig":
        """Return a copy with selected fields replaced."""
        data = {field.name: getattr(self, field.name) for field in fields(self)}
        data.update(kwargs)
        return type(self)(**data)
