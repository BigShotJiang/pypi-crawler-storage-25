from __future__ import annotations

"""Shared encoded-arrow-plan utilities.

This module lives in ``syneltra.core`` so low-level constraint code and
mechanism/search code can use the same helpers without importing each other.
This prevents cycles such as:

    constraints.plans -> search.planner -> search.frontier -> constraints

or:

    constraints.plans -> mechanism.planner -> mechanism.pruner -> constraints
"""

from typing import List, Sequence, Tuple

from .models import Transition

EncodedTransitionKey = Tuple[str, Tuple[int, ...], Tuple[int, ...]]
EncodedArrow = Tuple[EncodedTransitionKey, ...]
EncodedArrowPlan = Tuple[EncodedArrow, ...]


def transition_key(transition: Transition) -> EncodedTransitionKey:
    """Return the stable encoded key for a transition."""

    return (
        str(transition.kind),
        tuple(int(x) for x in transition.src),
        tuple(int(x) for x in transition.dst),
    )


def history_transition_keys(
    history: Sequence[Transition],
) -> Tuple[EncodedTransitionKey, ...]:
    """Return encoded keys for a transition history."""

    return tuple(transition_key(t) for t in history)


def flatten_encoded_plan(
    plan: Sequence[Sequence[EncodedTransitionKey]],
) -> Tuple[EncodedTransitionKey, ...]:
    """Flatten an encoded arrow plan into micro-step order."""

    out: List[EncodedTransitionKey] = []
    for arrow in plan:
        out.extend(tuple(step) for step in arrow)
    return tuple(out)


def compatible_encoded_plans(
    prefix: Sequence[EncodedTransitionKey],
    raw_plans: Sequence[Sequence[Sequence[EncodedTransitionKey]]],
) -> List[EncodedArrowPlan]:
    """Return normalized plans whose flattened prefix matches ``prefix``."""

    prefix_t = tuple(prefix)
    out: List[EncodedArrowPlan] = []

    for plan in raw_plans:
        try:
            normalized: EncodedArrowPlan = tuple(tuple(tuple(step) for step in arrow) for arrow in plan)
        except Exception:
            continue

        flat = flatten_encoded_plan(normalized)

        if len(flat) < len(prefix_t):
            continue

        if flat[: len(prefix_t)] == prefix_t:
            out.append(normalized)

    return out


def next_compatible_encoded_plans(
    prefix: Sequence[EncodedTransitionKey],
    candidate: EncodedTransitionKey,
    raw_plans: Sequence[Sequence[Sequence[EncodedTransitionKey]]],
) -> List[EncodedArrowPlan]:
    """Return plans compatible with ``prefix + candidate``."""

    next_prefix = tuple(prefix) + (tuple(candidate),)
    return compatible_encoded_plans(next_prefix, raw_plans)


def plan_boundary_after_step(
    plan: Sequence[Sequence[EncodedTransitionKey]],
    step_count: int,
) -> bool:
    """Return True when ``step_count`` ends exactly at an arrow boundary."""

    total = 0

    for arrow in plan:
        total += len(tuple(arrow))

        if total == int(step_count):
            return True

    return False


__all__ = [
    "EncodedArrow",
    "EncodedArrowPlan",
    "EncodedTransitionKey",
    "compatible_encoded_plans",
    "flatten_encoded_plan",
    "history_transition_keys",
    "next_compatible_encoded_plans",
    "plan_boundary_after_step",
    "transition_key",
]
