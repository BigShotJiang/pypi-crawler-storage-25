from __future__ import annotations

from typing import Set, Tuple

from ..core.models import ExpansionContext, Transition


class ElectronFlowGuidanceMixin:
    """Soft electron-flow continuity scoring used by mechanism search."""

    @staticmethod
    def _memory_int_set(mem: dict, key: str) -> Set[int]:
        """Read a memory sequence as a set of integers."""

        return {int(x) for x in mem.get(key, ()) or ()}

    @staticmethod
    def _transition_src_atom_set(transition: Transition) -> Set[int]:
        """Return transition source atoms as integers."""

        return {int(x) for x in transition.src}

    def _electron_flow_weights(self) -> Tuple[float, float, float, float]:
        """Return electron-flow soft scoring weights."""

        cont_bonus = float(getattr(self.config, "electron_flow_continuity_bonus", 4.0) or 0.0)
        touch_bonus = float(getattr(self.config, "electron_flow_touch_bonus", 1.0) or 0.0)
        new_segment_penalty = float(getattr(self.config, "electron_flow_new_segment_penalty", 1.5) or 0.0)
        unresolved_penalty = float(getattr(self.config, "electron_flow_unresolved_frontier_penalty", 4.0) or 0.0)
        return cont_bonus, touch_bonus, new_segment_penalty, unresolved_penalty

    def _score_lp_source_flow(
        self,
        ctx: ExpansionContext,
        transition: Transition,
        mem: dict,
        *,
        anchor: int,
        basin: Set[int],
        touched: Set[int],
        cont_bonus: float,
        touch_bonus: float,
        new_segment_penalty: float,
        unresolved_penalty: float,
    ) -> float:
        """Score continuation from an LP+ frontier."""

        active = self._lp_frontier_is_active_for_flow(ctx, anchor)

        if active:
            if transition.head == "LP-" and len(transition.src) == 1:
                src = int(transition.src[0])
                if src == anchor:
                    return cont_bonus
                if src in basin:
                    return 0.5 * cont_bonus

            if transition.head == "B-" and bool(self._transition_src_atom_set(transition) & basin):
                return 0.25 * cont_bonus

            return -unresolved_penalty

        last_touched = self._memory_int_set(mem, "last_touched_atoms")
        local_region = last_touched | basin
        return touch_bonus if touched & local_region else -new_segment_penalty

    def _score_bond_thread_flow(
        self,
        transition: Transition,
        mem: dict,
        *,
        anchor: int,
        basin: Set[int],
        touched: Set[int],
        forbidden: Set[int],
        cont_bonus: float,
        touch_bonus: float,
        new_segment_penalty: float,
        unresolved_penalty: float,
    ) -> float:
        """Score continuation along a bond-thread frontier."""

        status = str(mem.get("frontier_status") or "")
        required = status == "required" or (not status and bool(mem.get("frontier_required", False)))
        if status in {"satisfied", "inactive"}:
            return self._score_no_frontier_flow(
                mem,
                touched=touched,
                touch_bonus=touch_bonus,
                new_segment_penalty=new_segment_penalty,
            )

        if transition.head == "B-" and len(transition.src) == 2:
            src = tuple(int(x) for x in transition.src)
            if anchor in src:
                other = src[1] if src[0] == anchor else src[0]
                if other not in forbidden:
                    return cont_bonus

        if touched & (basin | {anchor}):
            return touch_bonus

        return -unresolved_penalty if required else -new_segment_penalty

    def _score_bond_out_flow(
        self,
        transition: Transition,
        mem: dict,
        *,
        anchor: int,
        basin: Set[int],
        touched: Set[int],
        cont_bonus: float,
        touch_bonus: float,
        new_segment_penalty: float,
        unresolved_penalty: float,
    ) -> float:
        """Score continuation of a hard B+ clearance frontier."""

        status = str(mem.get("frontier_status") or "")
        required = status == "required" or (not status and bool(mem.get("frontier_required", False)))
        if status in {"satisfied", "inactive"}:
            return self._score_no_frontier_flow(
                mem,
                touched=touched,
                touch_bonus=touch_bonus,
                new_segment_penalty=new_segment_penalty,
            )
        preferred_edge = tuple(mem.get("frontier_preferred_src_edge", ()) or ())

        if transition.head == "B-" and len(transition.src) == 2:
            src = tuple(sorted(int(x) for x in transition.src))
            if preferred_edge and src == tuple(sorted(int(x) for x in preferred_edge)):
                return cont_bonus
            if anchor in src:
                return 0.5 * cont_bonus

        if touched & (basin | {anchor}):
            return touch_bonus

        return -unresolved_penalty if required else -new_segment_penalty

    def _score_no_frontier_flow(
        self,
        mem: dict,
        *,
        touched: Set[int],
        touch_bonus: float,
        new_segment_penalty: float,
    ) -> float:
        """Score local continuation when no active frontier exists."""

        last_touched = self._memory_int_set(mem, "last_touched_atoms")
        if not last_touched:
            return 0.0
        return touch_bonus if touched & last_touched else -new_segment_penalty

    def _electron_flow_score(
        self,
        ctx: ExpansionContext,
        transition: Transition,
    ) -> float:
        """Soft score for minimizing separated electron-flow threads."""

        if not bool(getattr(self.config, "electron_flow_guidance", True)):
            return 0.0
        if int(ctx.depth) <= 0:
            return 0.0

        (
            cont_bonus,
            touch_bonus,
            new_segment_penalty,
            unresolved_penalty,
        ) = self._electron_flow_weights()

        mem = ctx.current.memory or {}
        mode = mem.get("frontier_mode")
        kind = mem.get("frontier_kind")
        status = mem.get("frontier_status")
        anchor = mem.get("frontier_anchor_atom")
        basin = self._memory_int_set(mem, "frontier_basin_atoms")
        forbidden = self._memory_int_set(mem, "frontier_forbidden_src_neighbors")
        touched = self._transition_touched_set(transition)

        if anchor is not None:
            anchor = int(anchor)

        if status in {"satisfied", "inactive"}:
            return self._score_no_frontier_flow(
                mem,
                touched=touched,
                touch_bonus=touch_bonus,
                new_segment_penalty=new_segment_penalty,
            )

        if (mode == "lp_source" or kind == "lp") and anchor is not None:
            return self._score_lp_source_flow(
                ctx,
                transition,
                mem,
                anchor=anchor,
                basin=basin,
                touched=touched,
                cont_bonus=cont_bonus,
                touch_bonus=touch_bonus,
                new_segment_penalty=new_segment_penalty,
                unresolved_penalty=unresolved_penalty,
            )

        if mode == "bond_thread" and anchor is not None:
            return self._score_bond_thread_flow(
                transition,
                mem,
                anchor=anchor,
                basin=basin,
                touched=touched,
                forbidden=forbidden,
                cont_bonus=cont_bonus,
                touch_bonus=touch_bonus,
                new_segment_penalty=new_segment_penalty,
                unresolved_penalty=unresolved_penalty,
            )

        if (mode == "bond_out" or kind == "bond") and anchor is not None:
            return self._score_bond_out_flow(
                transition,
                mem,
                anchor=anchor,
                basin=basin,
                touched=touched,
                cont_bonus=cont_bonus,
                touch_bonus=touch_bonus,
                new_segment_penalty=new_segment_penalty,
                unresolved_penalty=unresolved_penalty,
            )

        return self._score_no_frontier_flow(
            mem,
            touched=touched,
            touch_bonus=touch_bonus,
            new_segment_penalty=new_segment_penalty,
        )
