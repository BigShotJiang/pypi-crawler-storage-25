from __future__ import annotations

from typing import List, Optional, Tuple

from ..chemistry.graph import atom_element, edge_order
from ..core.models import StateSnapshot, Transition
from ..constraints.local_instability import electron_occupancy, octet_target


class BondPlusFrontierMixin:
    """Frontier-memory logic after B+ bond formation."""

    @staticmethod
    def _empty_frontier_payload() -> dict:
        """Return the default frontier payload."""

        return {
            "mode": None,
            "kind": None,
            "status": "inactive",
            "anchor": None,
            "basin": (),
            "required": False,
            "reason": None,
            "preferred_src_edge": None,
            "preferred_lp_sink": None,
            "return_atom": None,
            "forbidden_src_neighbors": (),
        }

    def _make_bond_thread_payload(
        self,
        next_state: StateSnapshot,
        *,
        anchor: int,
        required: bool,
        reason: str = "bond_thread",
        forbidden_src_neighbors: Tuple[int, ...] = (),
    ) -> dict:
        """Create a bond-thread frontier payload."""

        payload = self._empty_frontier_payload()
        payload["mode"] = "bond_thread"
        payload["kind"] = "bond"
        payload["status"] = "required" if bool(required) else "active"
        payload["anchor"] = int(anchor)
        payload["basin"] = self._resonance_basin(next_state.graph, int(anchor))
        payload["required"] = bool(required)
        payload["reason"] = str(reason)
        payload["forbidden_src_neighbors"] = tuple(sorted(int(x) for x in forbidden_src_neighbors))
        return payload

    def _explicit_h_transfer_clearance_payload(
        self,
        current: StateSnapshot,
        *,
        sink: int,
        shared_atom: Optional[int],
    ) -> Optional[dict]:
        """Force cleavage of the old X--H bond after forming a new X--H bond."""

        if self._current_element(current, sink) != "H":
            return None

        old_neighbors: List[int] = []
        if sink in current.graph:
            for nbr in current.graph.neighbors(sink):
                nbr = int(nbr)
                if shared_atom is not None and nbr == int(shared_atom):
                    continue
                if edge_order(current.graph, sink, nbr) <= 1e-8:
                    continue
                # Skip H-H bond: sink is H and nbr is H with a real H-H bond
                if self._current_element(current, nbr) == "H" and edge_order(current.graph, int(sink), nbr) > 1e-8:
                    continue
                old_neighbors.append(nbr)

        if not old_neighbors:
            return None

        old_neighbors.sort(key=lambda n: (-self._en_for_rank(current.graph, n), int(n)))
        old = int(old_neighbors[0])

        payload = self._empty_frontier_payload()
        payload["mode"] = "bond_out"
        payload["kind"] = "bond"
        payload["status"] = "required"
        payload["anchor"] = int(sink)
        payload["basin"] = tuple(sorted((int(sink), old)))
        payload["required"] = True
        payload["reason"] = "explicit_h_transfer_clearance"
        payload["preferred_src_edge"] = tuple(sorted((int(sink), old)))
        payload["preferred_lp_sink"] = old

        if shared_atom is not None:
            payload["forbidden_src_neighbors"] = (int(shared_atom),)

        return payload

    def _proton_clearance_payload(
        self,
        current: StateSnapshot,
        *,
        sink: int,
        shared_atom: Optional[int],
    ) -> Optional[dict]:
        """Create a generic proton-clearance payload when H has hetero neighbors."""

        if self._current_element(current, sink) != "H":
            return None

        proton_neighbors = self._hetero_neighbors(current, sink)
        if not proton_neighbors:
            return None

        payload = self._empty_frontier_payload()
        payload["mode"] = "bond_out"
        payload["kind"] = "bond"
        payload["status"] = "required"
        payload["anchor"] = int(sink)
        payload["basin"] = (int(sink),)
        payload["required"] = True
        payload["reason"] = "proton_clearance"

        if shared_atom is not None:
            payload["forbidden_src_neighbors"] = (int(shared_atom),)

        return payload

    def _h_bondplus_clearance_payload(
        self,
        current: StateSnapshot,
        *,
        sink: int,
        shared_atom: Optional[int],
    ) -> Optional[dict]:
        """Return H-transfer/proton-clearance payload if applicable."""

        explicit = self._explicit_h_transfer_clearance_payload(
            current,
            sink=sink,
            shared_atom=shared_atom,
        )
        if explicit is not None:
            return explicit

        return self._proton_clearance_payload(
            current,
            sink=sink,
            shared_atom=shared_atom,
        )

    def _ps_pi_clearance_payload(
        self,
        current: StateSnapshot,
        next_state: StateSnapshot,
        goal: Optional[StateSnapshot],
        *,
        sink: int,
        shared_atom: Optional[int],
        dst_edge: Tuple[int, int] | Tuple[()],
    ) -> Optional[dict]:
        """Pi-clearance for expanded-octet P/S after nucleophilic attack (LP-/B+).

        Phosphorus and sulfur can exceed an octet, so ``octet_target`` returns
        None for them and the standard clearance gate is never reached.  When a
        nucleophile attacks P or S and a pi bond to O/N/S is available in the
        search workspace, guide the next step toward opening that pi bond (the
        same way the carbonyl C=O opens in addition-elimination).  If the pi
        bond is not in the workspace (context_k=0, SN2 cases), fall back to
        endpoint-release so the leaving group departs directly instead.
        """
        el = atom_element(current.graph, sink)
        if el not in {"P", "S"}:
            return None

        # After a carbonyl_pi_open + rebound cycle, the previous state's
        # frontier_reason is "carbonyl_pi_open".  The rebound (LP-/B+ that
        # re-forms P=O / S=O) fires _ps_pi_clearance_payload again.  For
        # polyoxo atoms like sulfonyl (S with two S=O bonds), _carbonyl_
        # clearance_payload would pick the *other* S=O and wrongly force a
        # second pi-opening.  Detect this by checking if we're immediately
        # after a pi-open frontier, and fall through to endpoint-release
        # instead so the leaving group can depart.
        prev_reason = current.memory.get("frontier_reason", "")
        after_pi_rebound = prev_reason == "carbonyl_pi_open"

        basin, preferred_src_edge, preferred_lp_sink, reason = self._carbonyl_clearance_payload(current, sink)
        if preferred_src_edge is None:
            return None

        just_formed_edge = tuple(sorted(int(x) for x in dst_edge)) if len(dst_edge) == 2 else None
        reopen_just_formed = (
            just_formed_edge is not None and tuple(sorted(int(x) for x in preferred_src_edge)) == just_formed_edge
        )
        preferred_missing = not self._edge_available_to_search(next_state.graph, preferred_src_edge)

        if goal is not None and (after_pi_rebound or preferred_missing or reopen_just_formed):
            basin, preferred_src_edge, preferred_lp_sink, reason = self._endpoint_release_payload(
                next_state,
                goal,
                sink,
                forbidden_neighbors=((int(shared_atom),) if shared_atom is not None else ()),
            )

        payload = self._empty_frontier_payload()
        payload["mode"] = "bond_out"
        payload["kind"] = "bond"
        payload["status"] = "required" if preferred_src_edge is not None else "active"
        payload["anchor"] = int(sink)
        payload["basin"] = basin
        payload["required"] = bool(preferred_src_edge is not None)
        payload["reason"] = reason
        payload["preferred_src_edge"] = preferred_src_edge
        payload["preferred_lp_sink"] = preferred_lp_sink
        if shared_atom is not None:
            payload["forbidden_src_neighbors"] = (int(shared_atom),)
        return payload

    def _octet_bondplus_clearance_payload(
        self,
        current: StateSnapshot,
        next_state: StateSnapshot,
        goal: Optional[StateSnapshot],
        *,
        sink: int,
        shared_atom: Optional[int],
        dst_edge: Tuple[int, int] | Tuple[()],
    ) -> Optional[dict]:
        """Return octet-clearance payload for an overfilled B+ sink."""

        target = octet_target(atom_element(current.graph, sink))
        occupancy = electron_occupancy(current.graph, sink)

        if not bool(self.config.hard_bplus_clearance):
            return None
        if target != 8 or occupancy < 8:
            return None

        # Skip forced LP release when H from H-H bond is being added.
        # The overfilled sp carbon receiving H2 hydrogen needs no LP clearance.
        if shared_atom is not None and self._current_element(current, int(shared_atom)) == "H":
            g = current.graph
            sa = int(shared_atom)
            if sa in g and any(
                atom_element(g, int(nbr)) == "H" and edge_order(g, sa, int(nbr)) > 1e-8 for nbr in g.neighbors(sa)
            ):
                return None

        basin, preferred_src_edge, preferred_lp_sink, reason = self._carbonyl_clearance_payload(current, sink)

        just_formed_edge = tuple(sorted(int(x) for x in dst_edge)) if len(dst_edge) == 2 else None
        reopen_just_formed = (
            preferred_src_edge is not None
            and just_formed_edge is not None
            and tuple(sorted(int(x) for x in preferred_src_edge)) == just_formed_edge
        )
        preferred_missing = preferred_src_edge is not None and not self._edge_available_to_search(
            next_state.graph, preferred_src_edge
        )

        # After a carbonyl_pi_open + rebound cycle the pi bond is restored and C
        # is pentavalent again, but _carbonyl_clearance_payload finds no pi bond
        # in `current` (it was single-bond at that snapshot).  Force endpoint
        # release so the leaving group must depart rather than letting the search
        # wander to unrelated steps.  Guard with next_state occupancy > 8 to
        # avoid false-firing on NHC or other chemistry where the atom is not
        # actually pentavalent after the rebound.
        _pi_anchor = current.memory.get("frontier_anchor_atom")
        _pi_anchor_is_oxygen = _pi_anchor is not None and atom_element(current.graph, int(_pi_anchor)) == "O"
        after_carbonyl_rebound = (
            preferred_src_edge is None
            and current.memory.get("frontier_reason") == "carbonyl_pi_open"
            and _pi_anchor_is_oxygen
            and current.memory.get("frontier_return_atom") == sink
            and electron_occupancy(next_state.graph, sink) > 8
        )
        if goal is not None and after_carbonyl_rebound:
            _ep_basin, _ep_pse, _ep_plps, _ep_reason = self._endpoint_release_payload(
                next_state,
                goal,
                sink,
                forbidden_neighbors=((int(shared_atom),) if shared_atom is not None else ()),
            )
            # Only force LG departure when the identified bond doesn't involve H.
            # A C-H bond in the endpoint means proton transfer (e.g. Stetter), not
            # a true heteroatom leaving group departure (e.g. acyl substitution).
            _pse_involves_h = _ep_pse is not None and any(
                atom_element(next_state.graph, int(a)) == "H" for a in _ep_pse
            )
            if _ep_pse is not None and not _pse_involves_h:
                basin, preferred_src_edge, preferred_lp_sink, reason = (
                    _ep_basin,
                    _ep_pse,
                    _ep_plps,
                    _ep_reason,
                )
        elif preferred_src_edge is not None and goal is not None and (preferred_missing or reopen_just_formed):
            basin, preferred_src_edge, preferred_lp_sink, reason = self._endpoint_release_payload(
                next_state,
                goal,
                sink,
                forbidden_neighbors=((int(shared_atom),) if shared_atom is not None else ()),
            )

        payload = self._empty_frontier_payload()
        payload["mode"] = "bond_out"
        payload["kind"] = "bond"
        payload["status"] = "required" if preferred_src_edge is not None else "active"
        payload["anchor"] = int(sink)
        payload["basin"] = basin
        payload["required"] = bool(preferred_src_edge is not None)
        payload["reason"] = reason
        payload["preferred_src_edge"] = preferred_src_edge
        payload["preferred_lp_sink"] = preferred_lp_sink

        if shared_atom is not None:
            payload["forbidden_src_neighbors"] = (int(shared_atom),)

        return payload

    def _bondplus_frontier_payload(  # noqa: C901
        self,
        current: StateSnapshot,
        transition: Transition,
        next_state: StateSnapshot,
        shared_atom: Optional[int],
        goal: Optional[StateSnapshot] = None,
    ) -> dict:
        """Return frontier payload after a transition with a B+ tail."""

        payload = self._empty_frontier_payload()
        dst_edge = self._bond_atoms(transition, side="dst")
        sink = None

        if len(dst_edge) == 2 and shared_atom is not None:
            sink = self._other_endpoint(dst_edge, shared_atom)

        if sink is None:
            if transition.kind == "B-/B+" and shared_atom is not None:
                return self._make_bond_thread_payload(
                    next_state,
                    anchor=int(shared_atom),
                    required=False,
                    reason="bond_thread",
                )
            return payload

        sink = int(sink)

        h_payload = self._h_bondplus_clearance_payload(
            current,
            sink=sink,
            shared_atom=shared_atom,
        )
        if h_payload is not None:
            return h_payload

        # For LP-/B+ transitions (nucleophile attacks P or S), guide the
        # pi-bond clearance before falling through to the generic octet check.
        if transition.kind == "LP-/B+":
            ps_payload = self._ps_pi_clearance_payload(
                current,
                next_state,
                goal,
                sink=sink,
                shared_atom=shared_atom,
                dst_edge=dst_edge,
            )
            if ps_payload is not None:
                return ps_payload

        octet_payload = self._octet_bondplus_clearance_payload(
            current,
            next_state,
            goal,
            sink=sink,
            shared_atom=shared_atom,
            dst_edge=dst_edge,
        )
        if octet_payload is not None:
            return octet_payload

        if transition.kind == "B-/B+" and shared_atom is not None:
            # Explicit H additions are terminal; don't force a bond thread out
            # of the newly attached hydrogen.
            g = current.graph
            sa = int(shared_atom)
            if (
                self._current_element(current, sa) == "H"
                and sa in g
                and any(
                    atom_element(g, int(nbr)) == "H" and edge_order(g, sa, int(nbr)) > 1e-8 for nbr in g.neighbors(sa)
                )
            ):
                return payload
            if self._current_element(current, sink) == "H":
                return payload

            # If the new bond satisfies a positively charged/electron-poor
            # sink without forcing a clearance payload above, the local
            # bond frontier is complete and another electron-flow segment may
            # start.  Clearance cases have already returned before this point.
            try:
                current_charge = int(current.graph.nodes[sink].get("charge", 0))
                next_charge = int(next_state.graph.nodes[sink].get("charge", 0))
            except Exception:
                current_charge = next_charge = 0
            if current_charge > 0 and next_charge <= 0:
                payload = self._empty_frontier_payload()
                payload["mode"] = "bond_thread"
                payload["kind"] = "bond"
                payload["status"] = "satisfied"
                payload["anchor"] = sink
                payload["basin"] = self._resonance_basin(next_state.graph, sink)
                payload["required"] = False
                payload["reason"] = "satisfied_cation_attack"
                return payload

            return self._make_bond_thread_payload(
                next_state,
                anchor=sink,
                required=True,
                reason="bond_thread",
                forbidden_src_neighbors=(int(shared_atom),),
            )

        return payload
