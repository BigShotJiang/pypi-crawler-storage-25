from __future__ import annotations

from typing import List, Tuple

from ..core.models import ExpansionContext, StateSnapshot, Trajectory, Transition
from .types import BeamBranch


class BeamSearchMixin:
    """Beam-search implementation for MechanismEnumerator."""

    def _new_root_branch(self, root: StateSnapshot, root_sig: Tuple) -> BeamBranch:
        """Create the root beam branch."""

        return BeamBranch(
            current=root,
            states=[root],
            history=[],
            seen_on_path={root_sig},
            score=(),
        )

    def _maybe_collect_goal_branch(
        self,
        branch: BeamBranch,
        *,
        depth: int,
        goal: StateSnapshot,
        results: List[Tuple[Tuple, Trajectory]],
        next_frontier: List[BeamBranch],
    ) -> bool:
        """Collect a completed branch if it has reached the goal."""

        if not self.is_goal_state(branch.current, goal):
            return False

        self._log_event(
            "goal_reached",
            level="summary",
            depth=int(depth),
            history_len=len(branch.history),
            score=branch.score,
            cost=branch.cost,
            logscore=branch.logscore,
        )

        results.append(
            (
                self._result_selection_key(branch),
                self._trajectory_from_path(branch.states, branch.history),
            )
        )

        if not bool(getattr(self.config, "beam_keep_completed", True)):
            next_frontier.append(branch)

        return True

    def _child_branch_scores(
        self,
        branch: BeamBranch,
        *,
        local_rank: Tuple,
        local_logprob: float,
        depth: int,
        score_mode: str,
    ) -> Tuple[Tuple, float, float]:
        """Return child score tuple, scalar cost, and logscore."""

        score = tuple(branch.score) + tuple(local_rank)
        local_cost = self._rank_cost(local_rank)
        length_penalty = float(getattr(self.config, "length_penalty", 0.75))

        if score_mode == "softmax_logprob":
            child_logscore = float(branch.logscore) + float(local_logprob)
            child_cost = -child_logscore + length_penalty * float(depth + 1)
            return score, child_cost, child_logscore

        child_cost = float(branch.cost) + float(local_cost) + length_penalty
        child_logscore = float(branch.logscore) - float(local_cost) - length_penalty
        return score, child_cost, child_logscore

    def _make_child_branch(
        self,
        branch: BeamBranch,
        *,
        transition: Transition,
        next_state: StateSnapshot,
        sig: Tuple,
        score: Tuple,
        child_cost: float,
        child_logscore: float,
    ) -> BeamBranch:
        """Create one child beam branch."""

        return BeamBranch(
            current=next_state,
            states=branch.states + [next_state],
            history=branch.history + [transition],
            seen_on_path=set(branch.seen_on_path) | {sig},
            score=score,
            cost=child_cost,
            logscore=child_logscore,
        )

    def _expand_beam_branch(
        self,
        branch: BeamBranch,
        *,
        depth: int,
        goal: StateSnapshot,
        best_seen_by_sig: dict[Tuple, Tuple[int, float]],
    ) -> List[Tuple[BeamBranch, Tuple]]:
        """Expand one beam branch into child branches."""

        ctx = ExpansionContext(
            current=branch.current,
            goal=goal,
            history=branch.history,
            states=branch.states,
            depth=depth,
        )

        ranked_next = self._expand_candidates(
            ctx,
            seen_on_path=branch.seen_on_path,
            next_depth=depth + 1,
        )

        score_mode = str(getattr(self.config, "beam_score_mode", "legacy")).lower()
        local_logprobs = (
            self._local_transition_logprobs(ranked_next)
            if score_mode == "softmax_logprob"
            else [0.0 for _ in ranked_next]
        )

        children: List[Tuple[BeamBranch, Tuple]] = []

        for idx, (local_rank, transition, next_state, sig) in enumerate(ranked_next):
            score, child_cost, child_logscore = self._child_branch_scores(
                branch,
                local_rank=local_rank,
                local_logprob=local_logprobs[idx],
                depth=depth,
                score_mode=score_mode,
            )

            if not self._beam_state_allows(
                best_seen_by_sig,
                sig,
                depth + 1,
                child_cost,
            ):
                continue

            child = self._make_child_branch(
                branch,
                transition=transition,
                next_state=next_state,
                sig=sig,
                score=score,
                child_cost=child_cost,
                child_logscore=child_logscore,
            )
            children.append((child, sig))

        return children

    def _add_beam_child(
        self,
        child: BeamBranch,
        sig: Tuple,
        *,
        next_frontier: List[BeamBranch],
        best_by_sig: dict[Tuple, BeamBranch],
        use_frontier_dedup: bool,
    ) -> None:
        """Add a child branch to the next frontier or frontier-dedup map."""

        if not use_frontier_dedup:
            next_frontier.append(child)
            return

        incumbent = best_by_sig.get(sig)
        if incumbent is None:
            best_by_sig[sig] = child
            return

        if self._branch_selection_key(child) < self._branch_selection_key(incumbent):
            best_by_sig[sig] = child

    def _beam_should_stop(
        self,
        *,
        frontier: List[BeamBranch],
        results: List[Tuple[Tuple, Trajectory]],
        max_results: int | None,
    ) -> bool:
        """Return True when beam enumeration should stop."""

        if (
            bool(getattr(self.config, "beam_stop_when_enough_goals", False))
            and max_results is not None
            and len(results) >= int(max_results)
        ):
            return True
        return not frontier

    def _enumerate_beam(
        self,
        start: StateSnapshot,
        goal: StateSnapshot,
        *,
        max_depth: int,
        beam_width: int,
        max_results: int | None = None,
    ) -> List[Trajectory]:
        """Chemistry-guided beam search."""

        root = self._prepare_root(start)
        root_sig = self.codec.signature(root)

        frontier = [self._new_root_branch(root, root_sig)]
        results: List[Tuple[Tuple, Trajectory]] = []
        best_seen_by_sig: dict[Tuple, Tuple[int, float]] = {root_sig: (0, 0.0)}

        for depth in range(0, max_depth + 1):
            self._log_event(
                "beam_layer_start",
                level="summary",
                depth=int(depth),
                frontier_size=len(frontier),
                results=len(results),
                beam_width=int(beam_width),
            )

            next_frontier: List[BeamBranch] = []
            best_by_sig: dict[Tuple, BeamBranch] = {}
            use_frontier_dedup = bool(getattr(self.config, "beam_frontier_signature_dedup", False))

            for branch in frontier:
                if self._maybe_collect_goal_branch(
                    branch,
                    depth=depth,
                    goal=goal,
                    results=results,
                    next_frontier=next_frontier,
                ):
                    continue

                if depth >= max_depth:
                    continue

                for child, sig in self._expand_beam_branch(
                    branch,
                    depth=depth,
                    goal=goal,
                    best_seen_by_sig=best_seen_by_sig,
                ):
                    self._add_beam_child(
                        child,
                        sig,
                        next_frontier=next_frontier,
                        best_by_sig=best_by_sig,
                        use_frontier_dedup=use_frontier_dedup,
                    )

            if use_frontier_dedup:
                next_frontier.extend(best_by_sig.values())

            raw_next_frontier_size = len(next_frontier)
            frontier = self._select_beam_frontier(
                next_frontier,
                beam_width=int(beam_width),
                goal=goal,
            )

            self._log_event(
                "beam_layer_end",
                level="summary",
                depth=int(depth),
                raw_next_frontier_size=raw_next_frontier_size,
                selected_frontier_size=len(frontier),
                results=len(results),
            )

            if self._beam_should_stop(
                frontier=frontier,
                results=results,
                max_results=max_results,
            ):
                break

        results.sort(key=lambda item: (item[0], len(item[1].transitions)))
        trajectories = [traj for _, traj in results]

        return trajectories[: int(max_results)] if max_results is not None else trajectories
