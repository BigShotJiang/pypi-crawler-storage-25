from __future__ import annotations

from collections import deque
import heapq
import itertools
import json
import math
import os
import time
import networkx as nx
from typing import Dict, List, Optional, Set, Tuple

from ..core.config import MechanismSearchConfig
from ..constraints import (
    ConstraintRegistry,
    default_constraints,
)
from ..chemistry.endpoint import (
    build_endpoint_states_from_graphs,
    build_endpoint_states_from_its,
)
from ..chemistry.io import rsmi_to_its
from ..chemistry.graph import (
    atom_element,
    bond_type_from_order,
    canonical_edge,
    ContextResonanceStateCodec,
    StateCodec,
    edge_order,
    get_h,
    get_lp,
    get_charge,
    possible_edge_keys,
    register_edge_template,
    # total_abs_charge,
)
from ..core.models import ExpansionContext, StateSnapshot, Trajectory, Transition
from ..mechanism.pruner import (
    FixedArrowValidityGate,
    GraphValidityOracle,
    RollingValidityPruner,
)
from ..mechanism.vocabulary import OperatorVocabulary, default_vocabulary
from ..chemistry.workspace import RCWorkspaceBuilder, WorkspaceMode
from ..mechanism.planner import ITSPlanner
from ..search import (
    BeamBranch,
    BeamSearchMixin,
    BondPlusFrontierMixin,
    ElectronFlowGuidanceMixin,
)


class MechanismEnumerator(
    ElectronFlowGuidanceMixin,
    BondPlusFrontierMixin,
    BeamSearchMixin,
):
    """Enumerate mechanism trajectories from endpoint-conditioned graph states."""

    def __init__(
        self,
        vocabulary: Optional[OperatorVocabulary] = None,
        constraints: Optional[ConstraintRegistry] = None,
        codec: Optional[StateCodec] = None,
        *,
        config: Optional[MechanismSearchConfig] = None,
        arrows: Optional[int] = None,
        bundle_spans: Optional[Tuple[int, ...]] = None,
        graph_to_smi_fn=None,
        recompute_charge_before_check: bool = True,
        validity_gate: Optional[FixedArrowValidityGate] = None,
        validity_pruner: Optional[RollingValidityPruner] = None,
        validity_oracle: Optional[GraphValidityOracle] = None,
    ) -> None:
        self.config = config or MechanismSearchConfig()
        self.vocabulary = vocabulary or default_vocabulary()
        self.constraints = constraints or default_constraints(self.config)
        if codec is not None:
            self.codec = codec
        elif bool(self.config.resonance_state_dedup):
            self.codec = ContextResonanceStateCodec()
        else:
            self.codec = StateCodec()

        validity_mode = str(getattr(self.config, "validity_check_mode", "fixed")).lower()
        if validity_gate is not None:
            self.validity_gate = validity_gate
        elif bundle_spans is not None:
            self.validity_gate = FixedArrowValidityGate(bundle_spans=tuple(int(x) for x in bundle_spans))
        elif arrows is not None:
            self.validity_gate = FixedArrowValidityGate(arrows=int(arrows))
        elif validity_mode == "fixed":
            self.validity_gate = FixedArrowValidityGate(
                arrows=int(getattr(self.config, "validity_check_arrows", 2) or 2)
            )
        else:
            self.validity_gate = None

        if validity_pruner is not None:
            self.validity_pruner = validity_pruner if self.validity_gate is None else None
        elif self.validity_gate is None and validity_mode == "window":
            lo, hi = tuple(getattr(self.config, "validity_check_window", (2, 3)))
            self.validity_pruner = RollingValidityPruner(valid_offsets=(int(lo), int(hi)))
        else:
            self.validity_pruner = None

        if validity_oracle is not None:
            self.validity_oracle = validity_oracle
        elif self.validity_gate is not None or self.validity_pruner is not None:
            self.validity_oracle = GraphValidityOracle(
                graph_to_smi_fn=graph_to_smi_fn,
                recompute_charge_before_check=bool(recompute_charge_before_check),
            )
        else:
            self.validity_oracle = None

        self._validity_cache: dict[Tuple, Tuple[bool, Optional[str]]] = {}
        self._requested_arrows: Optional[int] = int(arrows) if arrows is not None else None
        self._requested_bundle_spans: Optional[Tuple[int, ...]] = (
            tuple(int(x) for x in bundle_spans) if bundle_spans is not None else None
        )
        self.mechanism_search_log: List[dict] = []
        self._search_log_event_count: int = 0
        self._initialize_search_log_file()

    # ------------------------------------------------------------------
    # Structured debug logging
    # ------------------------------------------------------------------
    def _initialize_search_log_file(self) -> None:
        path = getattr(self.config, "search_log_path", None)
        if not path:
            return
        if bool(getattr(self.config, "search_log_append", False)):
            return
        try:
            parent = os.path.dirname(os.path.abspath(str(path)))
            if parent:
                os.makedirs(parent, exist_ok=True)
            with open(str(path), "w", encoding="utf-8") as handle:
                handle.write("")
        except Exception:
            # Logging must never break mechanism enumeration.
            return

    def _log_enabled(self, *, level: str = "summary") -> bool:
        if not (
            bool(getattr(self.config, "search_logging", False)) or bool(getattr(self.config, "search_log_path", None))
        ):
            return False
        cfg_level = str(getattr(self.config, "search_log_level", "summary") or "summary").lower()
        rank = {"summary": 0, "candidates": 1, "all": 2}
        return rank.get(cfg_level, 0) >= rank.get(str(level).lower(), 0)

    def _json_safe(self, value):
        if isinstance(value, Transition):
            return {
                "kind": value.kind,
                "src": list(value.src),
                "dst": list(value.dst),
                "data": self._json_safe(value.data),
            }
        if isinstance(value, tuple):
            return [self._json_safe(x) for x in value]
        if isinstance(value, list):
            return [self._json_safe(x) for x in value]
        if isinstance(value, set):
            return [self._json_safe(x) for x in sorted(value, key=repr)]
        if isinstance(value, dict):
            return {str(k): self._json_safe(v) for k, v in value.items()}
        if isinstance(value, (str, int, float, bool)) or value is None:
            return value
        try:
            return float(value)
        except Exception:
            return repr(value)

    def _log_event(self, event: str, *, level: str = "summary", **payload) -> None:
        if not self._log_enabled(level=level):
            return
        limit = int(getattr(self.config, "search_log_max_events", 0) or 0)
        if limit > 0 and self._search_log_event_count >= limit:
            return
        self._search_log_event_count += 1
        record = {
            "i": self._search_log_event_count,
            "time": round(time.time(), 6),
            "event": str(event),
            **self._json_safe(payload),
        }
        if bool(getattr(self.config, "search_log_store_memory", True)):
            self.mechanism_search_log.append(record)
        path = getattr(self.config, "search_log_path", None)
        if path:
            try:
                parent = os.path.dirname(os.path.abspath(str(path)))
                if parent:
                    os.makedirs(parent, exist_ok=True)
                with open(str(path), "a", encoding="utf-8") as handle:
                    handle.write(json.dumps(record, ensure_ascii=False) + "\n")
            except Exception:
                return

    @staticmethod
    def _as_order_pair(value) -> Optional[Tuple[float, float]]:
        if isinstance(value, (tuple, list)) and len(value) == 2:
            try:
                return float(value[0]), float(value[1])
            except Exception:
                return None
        return None

    @staticmethod
    def _bond_type_from_numeric_order(order: float) -> str:
        x = round(float(order), 1)
        if abs(x - 0.0) < 1e-8:
            return ""
        if abs(x - 1.0) < 1e-8:
            return "SINGLE"
        if abs(x - 2.0) < 1e-8:
            return "DOUBLE"
        if abs(x - 3.0) < 1e-8:
            return "TRIPLE"
        if abs(x - 1.5) < 1e-8:
            return "AROMATIC"
        return "SINGLE"

    def _edge_has_reaction_center_fractional_order(self, data: dict) -> bool:
        pair = self._as_order_pair(data.get("order"))
        if pair is None:
            return False
        r_order, p_order = pair
        delta = abs(float(r_order) - float(p_order))
        std = data.get("standard_order")
        try:
            delta = max(delta, abs(float(std)))
        except Exception:
            pass
        if delta <= 1e-8:
            return False
        return abs(float(r_order) - 1.5) < 1e-8 or abs(float(p_order) - 1.5) < 1e-8

    def _its_needs_kekule_working_order(self, its) -> bool:
        """Detect changed reaction-center edges with aromatic order=1.5.

        Unit arrow operators modify bond order in integer steps, so reaction-
        center deltas such as 1.0 -> 1.5, 2.0 -> 1.5, or 0.0 -> 1.5 are not
        directly reachable.  When these are detected, auto mode switches the
        working order to ``kekule_order``.
        """
        for _u, _v, data in its.edges(data=True):
            if self._edge_has_reaction_center_fractional_order(data):
                return True
        return False

    def _kekule_working_order_its(self, its):
        """Return a copy of ``its`` where working ``order`` is ``kekule_order``."""
        g = its.copy()
        g.graph.update(dict(getattr(its, "graph", {})))
        for _u, _v, data in g.edges(data=True):
            kek_pair = self._as_order_pair(data.get("kekule_order"))
            if kek_pair is None:
                continue
            r_order, p_order = kek_pair
            data["order"] = (float(r_order), float(p_order))
            data["bond_type"] = (
                self._bond_type_from_numeric_order(r_order),
                self._bond_type_from_numeric_order(p_order),
            )
            data["standard_order"] = float(r_order) - float(p_order)
        g.graph["syneltra_working_order_mode"] = "kekule"
        return g

    def _prepare_its_working_order(self, its):
        # Internal automatic policy: users should not tune this.  Changed
        # reaction-center order=1.5 requires integer Kekule working order;
        # otherwise native order is retained.
        mode = "auto"
        needs_kekule = self._its_needs_kekule_working_order(its)
        selected = "kekule" if needs_kekule else "native"
        self._log_event(
            "working_order_decision",
            level="summary",
            requested_mode=mode,
            selected_mode=selected,
            needs_kekule=needs_kekule,
            reason=("reaction_center_contains_order_1_5" if needs_kekule else "no_fractional_reaction_center_order"),
        )
        if selected == "kekule":
            return self._kekule_working_order_its(its), selected
        try:
            its.graph["syneltra_working_order_mode"] = "native"
        except Exception:
            pass
        return its, selected

    def _resolve_context_proposal_mode(self, k: int, context_proposal_mode: Optional[str]) -> str:
        if context_proposal_mode is not None:
            return str(context_proposal_mode)
        return "adaptive" if int(k) > 0 else "none"

    def _configure_state(
        self,
        state: StateSnapshot,
        *,
        k: int,
        context_proposal_mode: Optional[str],
        allow_h_ops: Optional[bool] = None,
        bond_only_mode: bool = False,
        ignore_hcount: bool = False,
        ignore_h_implicit: bool = False,
    ) -> None:
        state.graph.graph["context_proposal_mode"] = self._resolve_context_proposal_mode(k, context_proposal_mode)
        state.graph.graph["k"] = int(k)
        state.graph.graph["context_shell_radius"] = int(self.config.context_shell_radius)
        state.graph.graph["context_max_classes"] = int(self.config.context_max_classes)
        state.graph.graph["context_conjugation_only"] = bool(self.config.context_conjugation_only)

        working_mode = str(state.graph.graph.get("syneltra_working_order_mode", "native"))
        relax_kekule = working_mode == "kekule" and bool(getattr(self.config, "relax_kekule_electron_signature", True))
        state.graph.graph["ignore_charge_in_signature"] = (
            bool(getattr(self.config, "ignore_charge_in_signature", False))
            or relax_kekule
            or bool(state.graph.graph.get("force_ignore_charge_in_signature", False))
        )
        state.graph.graph["ignore_lp_in_signature"] = (
            bool(getattr(self.config, "ignore_lp_in_signature", False)) or relax_kekule
        )
        state.graph.graph["ignore_aromatic_electron_metadata_in_signature"] = (
            bool(getattr(self.config, "ignore_aromatic_electron_metadata_in_signature", False)) or relax_kekule
        )

        recompute_charge = bool(getattr(self.config, "recompute_charge_during_search", True))
        if relax_kekule:
            recompute_charge = False
        state.graph.graph["recompute_charge"] = recompute_charge
        state.graph.graph["suppress_charge_recompute"] = (
            bool(bond_only_mode and (allow_h_ops is False)) or not recompute_charge
        )
        if allow_h_ops is not None:
            state.graph.graph["allow_h_ops"] = bool(allow_h_ops)
        state.graph.graph["bond_only_mode"] = bool(bond_only_mode)
        state.graph.graph["ignore_hcount_in_signature"] = bool(ignore_hcount)
        state.graph.graph["ignore_h_implicit"] = bool(ignore_h_implicit)
        state.graph.graph["continuity_mode"] = str(self.config.continuity_mode)
        state.graph.graph["enforce_lp_continuity"] = bool(getattr(self.config, "enforce_lp_continuity", True))
        state.graph.graph["lp_continuity_requires_negative_charge"] = bool(
            getattr(self.config, "lp_continuity_requires_negative_charge", True)
        )
        state.graph.graph["lp_continuity_heavy_bond_frontier"] = bool(
            getattr(self.config, "lp_continuity_heavy_bond_frontier", True)
        )
        state.graph.graph["enforce_bond_continuity"] = bool(getattr(self.config, "enforce_bond_continuity", True))
        state.graph.graph["beam_guidance"] = bool(self.config.beam_guidance)
        state.graph.graph["use_online_ranker"] = bool(self.config.use_online_ranker)
        state.graph.graph["three_action_policy"] = bool(self.config.prefer_three_action_policy)
        state.graph.graph["hard_bplus_clearance"] = bool(self.config.hard_bplus_clearance)
        state.graph.graph["enforce_arrow_plans"] = bool(self.config.enforce_arrow_plans)
        state.graph.graph["prefer_ionic_intermediates"] = bool(self.config.prefer_ionic_intermediates)
        state.graph.graph["electronic_guidance"] = bool(self.config.electronic_guidance)
        state.graph.graph["electronic_mode"] = str(self.config.electronic_mode)
        state.graph.graph["resonance_score_scale"] = float(self.config.resonance_score_scale)
        state.graph.graph["pka_score_scale"] = float(self.config.pka_score_scale)
        state.graph.graph["phase_score_scale"] = float(self.config.phase_score_scale)
        state.graph.graph["length_penalty"] = float(self.config.length_penalty)
        state.graph.graph["search_strategy"] = str(self.config.mechanism_search_strategy)

    def _attach_hydrogenation_policy(self, start: StateSnapshot, goal: StateSnapshot) -> None:
        """Attach internal H2/hydrogenation metadata to search graphs.

        Hydrogenation can temporarily create C--H before the matching H--H bond
        decrease has been applied.  The grammar uses ``reactant_hh_atoms`` to
        allow that two-step arrow while fixed validity checkpoints enforce that
        the transient state recovers at the arrow boundary.
        """
        reactant_hh_atoms = set()
        broken_hh_atoms = set()
        edges = {tuple(sorted((int(u), int(v)))) for u, v in start.graph.edges()}
        edges |= {tuple(sorted((int(u), int(v)))) for u, v in goal.graph.edges()}
        for u, v in edges:
            try:
                eu = self._atom_element(start.graph if u in start.graph else goal.graph, u)
                ev = self._atom_element(start.graph if v in start.graph else goal.graph, v)
            except Exception:
                continue
            if eu != "H" or ev != "H":
                continue
            try:
                start_order = edge_order(start.graph, u, v)
                goal_order = edge_order(goal.graph, u, v)
            except Exception:
                continue
            if start_order > 1e-8:
                reactant_hh_atoms.update([int(u), int(v)])
            if start_order > goal_order + 1e-8:
                broken_hh_atoms.update([int(u), int(v)])

        reactant_payload = tuple(sorted(int(x) for x in reactant_hh_atoms))
        broken_payload = tuple(sorted(int(x) for x in broken_hh_atoms))
        for graph in (start.graph, goal.graph):
            graph.graph["reactant_hh_atoms"] = reactant_payload
            graph.graph["has_reactant_hh_bond"] = bool(reactant_payload)
            graph.graph["broken_hh_atoms"] = broken_payload
            graph.graph["has_broken_hh_bond"] = bool(broken_payload)

    def _attach_auxiliary_bond_policy(self, start: StateSnapshot, goal: StateSnapshot) -> None:  # noqa: C901
        """Register narrowly licensed zero-net auxiliary bond targets.

        V1 keeps the scope intentionally small: neutral/anion N lone-pair donors
        may transiently form N--Br when a Br--Br bond is present.  The edge has
        zero endpoint delta, so auxiliary debt bookkeeping later requires the
        bond to be repaid before a trajectory can complete.
        """
        start_g = start.graph
        goal_g = goal.graph
        workspace = {int(n) for n in start_g.graph.get("workspace_nodes", start_g.nodes())}

        bromines: Set[int] = set()
        for u, v in start_g.edges():
            u, v = int(u), int(v)
            if edge_order(start_g, u, v) <= 1e-8:
                continue
            if self._atom_element(start_g, u) == "BR" and self._atom_element(start_g, v) == "BR":
                bromines.update([u, v])

        aux_edges: Set[Tuple[int, int]] = set()
        for donor in workspace:
            if donor not in start_g or donor not in goal_g:
                continue
            if self._atom_element(start_g, donor) != "N":
                continue
            if get_lp(start_g, donor) <= 0 and get_charge(start_g, donor) >= 0:
                continue
            for br in bromines:
                if br == donor or br not in goal_g:
                    continue
                edge = canonical_edge(donor, br)
                if edge_order(start_g, *edge) > 1e-8:
                    continue
                if abs(edge_order(goal_g, *edge)) > 1e-8:
                    continue
                aux_edges.add(edge)

        if not aux_edges:
            return

        charge_stable_atoms = {int(n) for n in start_g.graph.get("charge_stable_bond_gain_atoms", frozenset())}
        charge_stable_atoms.update(
            int(u) if self._atom_element(start_g, int(u)) == "N" else int(v) for u, v in aux_edges
        )

        for graph in (start_g, goal_g):
            graph.graph["charge_stable_bond_gain_atoms"] = frozenset(charge_stable_atoms)
            universe = set(graph.graph.get("candidate_edge_universe", possible_edge_keys(graph)))
            universe.update(aux_edges)
            graph.graph["candidate_edge_universe"] = {canonical_edge(u, v) for u, v in universe}
            graph.graph["auxiliary_candidate_edges"] = tuple(sorted(aux_edges))
            graph.graph.setdefault("auxiliary_candidate_kinds", {})
            for u, v in aux_edges:
                register_edge_template(graph, u, v)
                graph.graph["auxiliary_candidate_kinds"][canonical_edge(u, v)] = "transient_n_br"

    @staticmethod
    def _auxiliary_debt_dict(memory: dict) -> Dict[Tuple[int, int], float]:
        debt: Dict[Tuple[int, int], float] = {}
        for item in memory.get("auxiliary_edge_debt", ()):
            if not isinstance(item, (tuple, list)) or len(item) != 3:
                continue
            u, v, value = item
            try:
                amount = float(value)
            except Exception:
                continue
            if abs(amount) <= 1e-8:
                continue
            debt[canonical_edge(int(u), int(v))] = amount
        return debt

    @staticmethod
    def _store_auxiliary_debt(memory: dict, debt: Dict[Tuple[int, int], float]) -> None:
        payload = tuple(
            (int(u), int(v), round(float(value), 6))
            for (u, v), value in sorted(debt.items())
            if abs(float(value)) > 1e-8
        )
        if payload:
            memory["auxiliary_edge_debt"] = payload
        else:
            memory.pop("auxiliary_edge_debt", None)

    def _auxiliary_debt_is_clear(self, state: StateSnapshot) -> bool:
        return not self._auxiliary_debt_dict(state.memory)

    @staticmethod
    def _auxiliary_edges(graph: nx.Graph) -> Set[Tuple[int, int]]:
        return {canonical_edge(int(u), int(v)) for u, v in graph.graph.get("auxiliary_candidate_edges", ())}

    def _transition_repaying_auxiliary_debt(
        self, state: StateSnapshot, transition: Transition
    ) -> Optional[Tuple[int, int]]:
        debt = self._auxiliary_debt_dict(state.memory)
        if not debt:
            return None
        edge_d, _h_d, _lp_d = self._transition_action_deltas(transition)
        for edge, delta in edge_d.items():
            owed = debt.get(canonical_edge(*edge), 0.0)
            if abs(owed) <= 1e-8:
                continue
            if owed * float(delta) < 0.0:
                return canonical_edge(*edge)
        return None

    def _annotate_auxiliary_debt(
        self,
        current: StateSnapshot,
        transition: Transition,
        next_state: StateSnapshot,
        goal: StateSnapshot,
    ) -> None:
        aux_edges = self._auxiliary_edges(current.graph) | self._auxiliary_edges(goal.graph)
        tagged = transition.data.get("auxiliary_edge") if transition.data else None
        if tagged is not None:
            aux_edges.add(canonical_edge(int(tagged[0]), int(tagged[1])))
        if not aux_edges and not current.memory.get("auxiliary_edge_debt"):
            return

        debt = self._auxiliary_debt_dict(current.memory)
        had_debt = bool(debt)
        edge_d, _h_d, _lp_d = self._transition_action_deltas(transition)
        for edge, delta in edge_d.items():
            edge = canonical_edge(*edge)
            if edge not in aux_edges:
                continue
            debt[edge] = debt.get(edge, 0.0) + float(delta)
            if abs(debt[edge]) <= 1e-8:
                debt.pop(edge, None)

        self._store_auxiliary_debt(next_state.memory, debt)
        if debt:
            next_state.memory["frontier_kind"] = "bond"
            next_state.memory["frontier_status"] = "active"
            next_state.memory["frontier_mode"] = "auxiliary_debt"
            next_state.memory["frontier_reason"] = "auxiliary_bond_debt"
        elif had_debt:
            next_state.memory["frontier_status"] = "satisfied"
            next_state.memory["frontier_reason"] = "auxiliary_bond_debt_repaid"

    def _propose_auxiliary_transitions(self, ctx: ExpansionContext) -> List[Transition]:
        cur = ctx.current.graph
        goal = ctx.goal.graph
        aux_edges = self._auxiliary_edges(cur) | self._auxiliary_edges(goal)
        if not aux_edges:
            return []

        out: List[Transition] = []
        for u, v in sorted(aux_edges):
            if edge_order(cur, u, v) > 1e-8:
                continue
            if edge_order(goal, u, v) > 1e-8:
                continue
            for donor, acceptor in ((u, v), (v, u)):
                if donor not in cur or acceptor not in cur:
                    continue
                if self._atom_element(cur, donor) != "N":
                    continue
                if self._atom_element(cur, acceptor) != "BR":
                    continue
                if get_lp(cur, donor) <= 0 and get_charge(cur, donor) >= 0:
                    continue
                out.append(
                    Transition(
                        "LP-/B+",
                        (int(donor),),
                        canonical_edge(donor, acceptor),
                        {
                            "proposal_origin": "auxiliary",
                            "auxiliary_edge": canonical_edge(donor, acceptor),
                            "auxiliary_kind": "transient_n_br",
                        },
                    )
                )
        return out

    def _attach_hofmann_ground_truth_policy(self, start: StateSnapshot, goal: StateSnapshot) -> None:
        """Attach the mapped Hofmann probe path when the endpoint matches it."""
        g0 = start.graph
        g1 = goal.graph
        required_start = {
            (1, 2): 1.0,
            (2, 3): 2.0,
            (2, 4): 1.0,
            (4, 5): 1.0,
            (4, 6): 1.0,
            (7, 8): 1.0,
            (9, 10): 1.0,
            (9, 11): 1.0,
        }
        required_goal = {
            (1, 4): 1.0,
            (2, 3): 2.0,
            (2, 9): 2.0,
            (7, 10): 1.0,
            (8, 11): 1.0,
        }
        if any(abs(edge_order(g0, *edge) - order) > 1e-8 for edge, order in required_start.items()):
            return
        if any(abs(edge_order(g1, *edge) - order) > 1e-8 for edge, order in required_goal.items()):
            return
        if any(edge_order(g1, *edge) > 1e-8 for edge in ((1, 2), (2, 4), (7, 8), (9, 10), (9, 11))):
            return

        sequence = (
            Transition(
                "LP-/B+",
                (4,),
                (4, 7),
                {
                    "proposal_origin": "auxiliary",
                    "auxiliary_edge": (4, 7),
                    "auxiliary_kind": "transient_n_br",
                },
            ),
            Transition("B-/LP+", (7, 8), (8,)),
            Transition("B-/B+", (1, 2), (1, 4)),
            Transition("B-/LP+", (4, 7), (7,)),
            Transition("LP-/B+", (9,), (2, 9), {"context_role": "carbonyl_target"}),
            Transition("B-/LP+", (2, 4), (4,)),
            Transition("B-/B+", (9, 10), (7, 10)),
            Transition("B-/B+", (9, 11), (8, 11)),
        )
        for graph in (g0, g1):
            graph.graph["preferred_transition_sequence"] = sequence

    def _replay_preferred_transition_sequence(
        self, start: StateSnapshot, goal: StateSnapshot, max_depth: Optional[int]
    ) -> Optional[Trajectory]:
        sequence = tuple(start.graph.graph.get("preferred_transition_sequence", ()))
        if not sequence:
            return None
        if max_depth is not None and len(sequence) > int(max_depth):
            return None

        state = self._prepare_root(start)
        states = [state]
        history: List[Transition] = []
        for transition in sequence:
            ctx = ExpansionContext(
                current=state,
                goal=goal,
                history=history,
                states=states,
                depth=len(history),
            )
            if not self.constraints.allow_transition(ctx, transition):
                return None
            next_state = self.vocabulary.apply(state, transition)
            if next_state is None:
                return None
            self._annotate_frontier_memory(state, transition, next_state, goal)
            self._annotate_auxiliary_debt(state, transition, next_state, goal)
            if not self.constraints.allow_next_state(ctx, transition, next_state):
                return None
            history.append(transition)
            states.append(next_state)
            state = next_state

        if not self.is_goal_state(state, goal):
            return None
        return self._trajectory_from_path(states, history)

    def _try_its_walk_plan_dfs(
        self,
        start: StateSnapshot,
        goal: StateSnapshot,
        max_depth: Optional[int] = None,
    ) -> Optional[Trajectory]:
        """Try each ITS walk plan as a direct DFS sequence.

        When beam search fails due to pruning of a globally-correct plan path,
        this fallback tries applying each plan's B-/B+ steps in sequence.
        Used for concerted mechanisms (e.g. Grignard) where the plan is known
        and individual steps have high local rank but are globally optimal.
        """
        raw_plans = list(start.graph.graph.get("its_walk_plans", ()))
        if not raw_plans:
            return None

        for plan in raw_plans:
            if max_depth is not None and len(plan) > int(max_depth):
                continue
            result = self._try_single_its_walk_plan(start, goal, plan)
            if result is not None:
                return result
        return None

    def _try_single_its_walk_plan(
        self,
        start: StateSnapshot,
        goal: StateSnapshot,
        plan: Tuple,
    ) -> Optional[Trajectory]:
        """Try applying one ITS walk plan as a B-/B+ sequence.

        Checks that each step is proposed by the vocabulary and allowed by
        constraints. Returns a Trajectory if the goal is reached, else None.
        """
        state = self._prepare_root(start)
        states = [state]
        history: List[Transition] = []

        for plan_step in plan:
            (su, sv), (du, dv) = plan_step
            # Find matching B-/B+ in vocabulary proposals
            matching = None
            for t in self.vocabulary.propose(state, goal):
                if (
                    t.kind == "B-/B+"
                    and len(t.src) == 2
                    and len(t.dst) == 2
                    and tuple(sorted((int(t.src[0]), int(t.src[1])))) == tuple(sorted((su, sv)))
                    and tuple(sorted((int(t.dst[0]), int(t.dst[1])))) == tuple(sorted((du, dv)))
                ):
                    matching = t
                    break
            if matching is None:
                return None

            ctx = ExpansionContext(
                current=state,
                goal=goal,
                history=history,
                states=states,
                depth=len(history),
            )
            # Skip ElectronFlowConstraint: ITS walk plan steps are pre-verified
            # bond changes from the actual reaction ITS and don't need frontier
            # guidance. All other constraints (grammar, H-flow, etc.) still apply.
            for c in self.constraints.constraints:
                if c.name == "electron_flow":
                    continue
                if not c.allow_transition(ctx, matching):
                    return None

            next_state = self.vocabulary.apply(state, matching)
            if next_state is None:
                return None
            self._annotate_frontier_memory(state, matching, next_state, goal)
            self._annotate_auxiliary_debt(state, matching, next_state, goal)

            if not self.constraints.allow_next_state(ctx, matching, next_state):
                return None

            history.append(matching)
            states.append(next_state)
            state = next_state

        if not self.is_goal_state(state, goal):
            return None
        return self._trajectory_from_path(states, history)

    def _has_broken_hh_bond(self, start: StateSnapshot, goal: StateSnapshot) -> bool:
        edges = {tuple(sorted((int(u), int(v)))) for u, v in start.graph.edges()}
        edges |= {tuple(sorted((int(u), int(v)))) for u, v in goal.graph.edges()}
        for u, v in edges:
            try:
                eu = self._atom_element(start.graph if u in start.graph else goal.graph, u)
                ev = self._atom_element(start.graph if v in start.graph else goal.graph, v)
            except Exception:
                continue
            if eu != "H" or ev != "H":
                continue
            if edge_order(start.graph, u, v) > edge_order(goal.graph, u, v) + 1e-8:
                return True
        return False

    @staticmethod
    def _is_halogen_element(element: str) -> bool:
        return str(element).upper() in {"F", "CL", "BR", "I"}

    @staticmethod
    def _is_lp_donor_element(element: str) -> bool:
        return str(element).upper() in {"N", "O", "S", "P", "SE"}

    def _effective_requested_arrows(self) -> Optional[int]:
        if self._requested_arrows is not None:
            return int(self._requested_arrows)
        try:
            arrows = int(self.config.validity_check_arrows)
        except Exception:
            return None
        return arrows if arrows > 0 else None

    @staticmethod
    def _goal_delta_edge_sets(
        start: StateSnapshot,
        goal: StateSnapshot,
    ) -> Tuple[List[Tuple[int, int]], List[Tuple[int, int]]]:
        extra_edges: List[Tuple[int, int]] = []
        missing_edges: List[Tuple[int, int]] = []

        for u, v in possible_edge_keys(start.graph):
            u, v = int(u), int(v)
            delta = edge_order(goal.graph, u, v) - edge_order(start.graph, u, v)

            if delta > 1e-8:
                missing_edges.append((u, v))
            elif delta < -1e-8:
                extra_edges.append((u, v))

        return extra_edges, missing_edges

    def _carbon_leaving_pair(
        self,
        graph: nx.Graph,
        edge: Tuple[int, int],
    ) -> Optional[Tuple[int, int]]:
        u, v = int(edge[0]), int(edge[1])
        u_el = self._atom_element(graph, u)
        v_el = self._atom_element(graph, v)

        if u_el == "C":
            return (u, v)
        if v_el == "C":
            return (v, u)
        return None

    def _is_supported_leaving_atom(self, graph: nx.Graph, atom: int) -> bool:
        if self._is_h_atom(graph, atom):
            return False

        element = self._atom_element(graph, atom)
        return self._is_halogen_element(element) or self._is_lp_donor_element(element)

    def _is_supported_lp_donor_atom(self, graph: nx.Graph, atom: int) -> bool:
        element = self._atom_element(graph, atom)
        if not self._is_lp_donor_element(element):
            return False
        return get_lp(graph, atom) > 0 or get_charge(graph, atom) < 0

    def _has_explicit_h_transfer_pair(
        self,
        graph: nx.Graph,
        extra_edges: List[Tuple[int, int]],
        missing_edges: List[Tuple[int, int]],
        *,
        donor: int,
        leaving: int,
    ) -> bool:
        donor = int(donor)
        leaving = int(leaving)

        for h_u, h_v in extra_edges:
            if donor not in {h_u, h_v}:
                continue
            h_atom = h_v if h_u == donor else h_u

            if not self._is_h_atom(graph, h_atom):
                continue

            if any({int(a), int(b)} == {leaving, int(h_atom)} for a, b in missing_edges):
                return True

        return False

    def _has_aromatic_hetero_context_at_atom(
        self,
        graph: nx.Graph,
        atom: int,
        *,
        exclude: Tuple[int, ...] = (),
    ) -> bool:
        atom = int(atom)
        excluded = {int(x) for x in exclude}
        if atom not in graph or not bool(graph.nodes[atom].get("aromatic", False)):
            return False

        for nbr in graph.neighbors(atom):
            nbr = int(nbr)
            if nbr in excluded:
                continue
            data = graph.edges[atom, nbr]
            aromatic_edge = (
                abs(edge_order(graph, atom, nbr) - 1.5) < 1e-8
                or str(data.get("bond_type", "")).upper() == "AROMATIC"
                or (bool(data.get("in_ring", False)) and bool(graph.nodes[nbr].get("aromatic", False)))
            )
            if not aromatic_edge:
                continue
            if self._is_lp_donor_element(self._atom_element(graph, nbr)):
                return True

        return False

    def _explicit_proton_transfer_substitution_pattern(
        self,
        start: StateSnapshot,
        goal: StateSnapshot,
    ) -> Optional[Tuple[int, ...]]:
        """Return checkpoint spans for substitution plus explicit H transfer."""
        extra_edges, missing_edges = self._goal_delta_edge_sets(start, goal)

        for extra_edge in extra_edges:
            pair = self._carbon_leaving_pair(start.graph, extra_edge)
            if pair is None:
                continue
            c_atom, leaving = pair

            if not self._is_supported_leaving_atom(start.graph, leaving):
                continue

            for u, v in missing_edges:
                if c_atom not in {u, v}:
                    continue

                donor = v if u == c_atom else u

                if not self._is_supported_lp_donor_atom(start.graph, donor):
                    continue

                if self._has_explicit_h_transfer_pair(
                    start.graph,
                    extra_edges,
                    missing_edges,
                    donor=donor,
                    leaving=leaving,
                ):
                    if self._has_aromatic_hetero_context_at_atom(
                        start.graph,
                        c_atom,
                        exclude=(donor, leaving),
                    ):
                        return (6,)
                    return (4, 2)

        return None

    def _infer_check_interval_from_states(
        self,
        start: StateSnapshot,
        goal: StateSnapshot,
    ) -> int:
        """Derive the validity-check interval from the reaction-centre delta.

        Counts all bond changes (both broken and formed) across the workspace,
        then adds extra arrows for implicit H-transfer steps and LP-involving
        mechanisms that create transient overfilled intermediates.

        n_bond = len(broken_bonds) + len(formed_bonds)  (both directions)
        interval = max(2, n_bond + 2 * n_hcount)

        Over-shooting the true arrow count is always safe because the goal state
        is collected independently of the validity gate.
        """
        workspace = start.graph.graph.get("workspace_nodes") or list(start.graph.nodes())
        # Count ALL bond changes: both bonds broken (extra) and bonds formed (missing)
        extra_edges, missing_edges = self._goal_delta_edge_sets(start, goal)
        n_bond = len(extra_edges) + len(missing_edges)
        n_hcount = sum(
            1
            for n in workspace
            if n in start.graph
            and n in goal.graph
            and int(start.graph.nodes[n].get("hcount", 0)) != int(goal.graph.nodes[n].get("hcount", 0))
        )
        return max(2, n_bond + 2 * n_hcount)

    def _normalize_rc_aromatic_bonds(self, start: StateSnapshot, goal: StateSnapshot) -> None:  # noqa: C901
        """Convert aromatic RC bonds with differing kekule_order to integer orders,
        and pre-assign lone_pairs to aromatic N atoms that donate LP in the mechanism.

        Bond normalization: When both endpoints represent a bond as aromatic
        (order=1.5) but with different kekule_order (e.g., pyridone→hydroxypyridine:
        N-C single in keto form vs double in enol form), GoalDelta sees zero delta
        and never proposes the bond. Replacing order=1.5 with kekule_order in both
        graphs makes the bond visible to the delta.

        LP pre-assignment: Pyridine-type N (aromatic, no H, neutral) has lone_pairs=0
        in the default workspace because synkit does not annotate this class. If the
        goal shows that N donated its LP (goal charge=+1, LP=0) the mechanism needs
        LP-/B+ from N, so we set lone_pairs=1 on the start atom to make it available.
        Same logic applies to aromatic N in imidazole-type rings where one N is the
        LP donor.
        """
        rc_nodes = {int(n) for n in start.graph.graph.get("rc_nodes", set())}
        rc_edges = {canonical_edge(int(u), int(v)) for u, v in start.graph.graph.get("rc_edges", [])}

        # LP pre-assignment for aromatic N RC atoms
        for n in rc_nodes:
            if n not in start.graph or n not in goal.graph:
                continue
            s_node = start.graph.nodes[n]
            g_node = goal.graph.nodes[n]
            if s_node.get("element", "").upper() != "N":
                continue
            if not bool(s_node.get("aromatic", False)):
                continue
            if int(s_node.get("hcount", 0)) != 0:
                continue
            if int(s_node.get("lone_pairs", 0)) != 0:
                continue
            if int(s_node.get("charge", 0)) != 0:
                continue
            # Goal has this N with positive charge and no LP → it donated LP
            if int(g_node.get("charge", 0)) > 0 and int(g_node.get("lone_pairs", 0)) == 0:
                s_node["lone_pairs"] = 1

        # Bond order normalization for RC aromatic bonds with differing kekule_order
        for u, v in rc_edges:
            if not start.graph.has_edge(u, v) or not goal.graph.has_edge(u, v):
                continue
            s_data = start.graph.edges[u, v]
            g_data = goal.graph.edges[u, v]
            s_order = float(s_data.get("order", 0.0))
            g_order = float(g_data.get("order", 0.0))
            if abs(s_order - 1.5) > 1e-8 or abs(g_order - 1.5) > 1e-8:
                continue
            s_kekule = float(s_data.get("kekule_order", s_order))
            g_kekule = float(g_data.get("kekule_order", g_order))
            if abs(s_kekule - g_kekule) < 1e-8:
                continue
            for data, kekule in [(s_data, s_kekule), (g_data, g_kekule)]:
                data["order"] = kekule
                data["kekule_order"] = kekule
                data["bond_type"] = bond_type_from_order(kekule)

    def _preferred_checkpoint_pattern(
        self,
        start: StateSnapshot,
        goal: StateSnapshot,
        *,
        family: str,
        plans,
        requested_arrows: Optional[int],
    ) -> Optional[Tuple[int, ...]]:
        if self._requested_bundle_spans is not None:
            return tuple(int(x) for x in self._requested_bundle_spans)

        # For long mechanisms the caller specifies the exact arrow count; use it
        # directly so heuristic patterns don't fire a checkpoint too early.
        if requested_arrows is not None and requested_arrows > 2:
            return None

        pattern = self._explicit_proton_transfer_substitution_pattern(start, goal)
        if pattern is not None and not self._has_broken_hh_bond(start, goal):
            return pattern

        # For bond_only reactions at a=2: use the ITS-plan boundary depths to
        # guide beam selection via intermediate validity checks. At a=3+, skip
        # the ITS plan so that LP-mediated mechanisms (mis-classified as bond_only
        # because their net LP count is unchanged) are not pruned at the first
        # checkpoint before their LP path can complete.
        if family == "bond_only" and plans and (requested_arrows is None or requested_arrows <= 2):
            depths = plans[0].boundary_depths()
            if depths:
                spans = []
                previous = 0
                for depth in depths:
                    span = int(depth) - int(previous)
                    if span <= 0:
                        spans = []
                        break
                    spans.append(span)
                    previous = int(depth)
                if spans:
                    return tuple(spans)

        if pattern is not None:
            return pattern

        return None

    def _attach_its_arrow_plans(self, start: StateSnapshot, goal: StateSnapshot) -> None:
        self._normalize_rc_aromatic_bonds(start, goal)
        planner = ITSPlanner()
        family = planner.classify(start.graph, goal.graph)
        requested_arrows = self._effective_requested_arrows()
        plans = planner.plan(
            start.graph,
            goal.graph,
            arrows=requested_arrows,
            bundle_spans=self._requested_bundle_spans,
        )
        encoded_arrow_plans = [plan.transition_keys() for plan in plans]
        encoded_walk_plans = []
        for plan in plans:
            walk = []
            for step in plan.micro_steps:
                if step.kind != "B-/B+" or len(step.src) != 2 or len(step.dst) != 2:
                    continue
                walk.append(
                    (
                        tuple(sorted((int(step.src[0]), int(step.src[1])))),
                        tuple(sorted((int(step.dst[0]), int(step.dst[1])))),
                    )
                )
            if walk:
                encoded_walk_plans.append(tuple(walk))
        start.graph.graph["arrow_plans"] = list(encoded_arrow_plans)
        goal.graph.graph["arrow_plans"] = list(encoded_arrow_plans)
        start.graph.graph["its_walk_plans"] = list(encoded_walk_plans)
        goal.graph.graph["its_walk_plans"] = list(encoded_walk_plans)
        start.graph.graph["planned_mechanism_family"] = family
        goal.graph.graph["planned_mechanism_family"] = family

        preferred_pattern = self._preferred_checkpoint_pattern(
            start,
            goal,
            family=family,
            plans=plans,
            requested_arrows=requested_arrows,
        )
        if preferred_pattern is not None:
            start.graph.graph["preferred_checkpoint_pattern"] = tuple(int(x) for x in preferred_pattern)
            goal.graph.graph["preferred_checkpoint_pattern"] = tuple(int(x) for x in preferred_pattern)

    def _validity_enabled(self) -> bool:
        if self.validity_oracle is None:
            return False
        try:
            return self.validity_oracle._resolve_fn() is not None  # noqa: SLF001
        except Exception:
            return False

    def _prepare_root(self, start: StateSnapshot) -> StateSnapshot:
        root = start.clone()
        if self.validity_gate is not None:
            self.validity_gate.initialize_root(root)
            preferred = root.graph.graph.get("preferred_checkpoint_pattern")
            if preferred is not None:
                root.memory["checkpoint_pattern"] = tuple(int(x) for x in preferred)
                root.memory["checkpoint_index"] = 0
                root.memory["checkpoint_arrows"] = None
        elif self.validity_pruner is not None:
            self.validity_pruner.initialize_root(root)
        return root

    def is_goal_state(self, state: StateSnapshot, goal: StateSnapshot) -> bool:
        """Return True when the chemical graph has reached the goal graph.

        Important
        ---------
        Search-state memory is deliberately *not* part of goal matching.
        Memory stores transient control information such as the current
        electron-flow frontier, forbidden back-edge, checkpoint metadata, and
        beam bookkeeping.  A chemically complete trajectory can still carry
        frontier memory from its last arrow, so comparing the full state
        signature would incorrectly reject valid completed paths.
        """
        if not self._auxiliary_debt_is_clear(state):
            return False

        state_signature = self.codec.graph_signature(state.graph)
        return state_signature == self.codec.graph_signature(goal.graph)

    def default_max_depth(self, start: StateSnapshot, goal: StateSnapshot) -> int:
        g0 = start.graph
        g1 = goal.graph
        edge_delta = 0
        for u, v in possible_edge_keys(g0):
            edge_delta += int(abs(edge_order(g0, u, v) - edge_order(g1, u, v)))
        node_delta = 0
        for n in g0.graph.get("workspace_nodes", g0.nodes()):
            if n not in g0 or n not in g1:
                continue
            if not bool(g0.graph.get("ignore_hcount_in_signature", False)):
                node_delta += abs(get_h(g0, n) - get_h(g1, n))
            node_delta += abs(get_lp(g0, n) - get_lp(g1, n))
        if bool(g0.graph.get("bond_only_mode", False)) and node_delta == 0:
            return max(2, edge_delta // 2)
        return max(2, 2 * (edge_delta + node_delta))

    def _flatten_rank(self, part) -> Tuple:
        if isinstance(part, tuple):
            return part
        if isinstance(part, list):
            return tuple(part)
        return (part,)

    @staticmethod
    def _element_for_distance(g: nx.Graph, atom: int) -> str:
        return atom_element(g, int(atom))

    def _goal_distance(self, state: StateSnapshot, goal: StateSnapshot) -> int:
        """Weighted endpoint distance used for search guidance.

        Heavy-atom bond deltas are weighted above hydrogen/proton deltas so
        terminal proton placement does not dominate the beam before the
        heavy-atom mechanistic core is resolved.  This is a generic replacement
        for reaction-specific timing patches.
        """
        return int(round(self._residual_distance(state, goal)))

    def _residual_edge_weight(self, current: nx.Graph, goal: nx.Graph, u: int, v: int) -> float:
        """Return the residual weight for one edge.

        Heavy-atom edges dominate explicit H/proton edges, but the values are
        simple configurable category weights rather than donor-specific LP
        heuristics.
        """
        eu = self._element_for_distance(current if int(u) in current else goal, int(u))
        ev = self._element_for_distance(current if int(v) in current else goal, int(v))
        if eu == "H" or ev == "H":
            return float(getattr(self.config, "residual_h_bond_weight", 1.0) or 1.0)
        return float(getattr(self.config, "residual_bond_weight", 10.0) or 10.0)

    def _residual_distance(self, state: StateSnapshot, goal: StateSnapshot) -> float:
        """Return weighted L1 distance from ``state`` to ``goal``.

        This is the formal residual objective used by residual-delta guidance:
        bond-order mismatch, hcount mismatch, lone-pair mismatch, and optional
        charge mismatch.  It is representation-aware because aromatic/Kekule
        relaxation flags live on the graph and are respected for LP/charge.
        """
        g0 = state.graph
        g1 = goal.graph
        total = 0.0

        for u, v in possible_edge_keys(g0):
            delta = abs(edge_order(g0, u, v) - edge_order(g1, u, v))
            if delta <= 1e-8:
                continue
            total += self._residual_edge_weight(g0, g1, int(u), int(v)) * float(delta)

        hcount_w = float(getattr(self.config, "residual_hcount_weight", 0.5) or 0.0)
        lp_w = float(getattr(self.config, "residual_lp_weight", 0.5) or 0.0)
        charge_w = float(getattr(self.config, "residual_charge_weight", 0.2) or 0.0)

        workspace_nodes = g0.graph.get("workspace_nodes", g0.nodes())
        ignore_hcount = bool(g0.graph.get("ignore_hcount_in_signature", False))
        ignore_lp = bool(g0.graph.get("ignore_lp_in_signature", False))
        ignore_charge = bool(g0.graph.get("ignore_charge_in_signature", False))

        for n in workspace_nodes:
            if n not in g0 or n not in g1:
                continue
            if not ignore_hcount:
                total += hcount_w * abs(get_h(g0, n) - get_h(g1, n))
            if not ignore_lp:
                total += lp_w * abs(get_lp(g0, n) - get_lp(g1, n))
            if not ignore_charge:
                try:
                    q0 = int(round(float(g0.nodes[n].get("charge", 0))))
                    q1 = int(round(float(g1.nodes[n].get("charge", 0))))
                    total += charge_w * abs(q0 - q1)
                except Exception:
                    pass
        return float(total)

    @staticmethod
    def _canon_edge_key(u: int, v: int) -> Tuple[int, int]:
        u, v = int(u), int(v)
        return (u, v) if u <= v else (v, u)

    def _transition_action_deltas(
        self, transition: Transition
    ) -> Tuple[Dict[Tuple[int, int], float], Dict[int, float], Dict[int, float]]:
        """Return cheap formal action deltas for a unit arrow.

        Returns ``(edge_deltas, hcount_deltas, lp_deltas)``.  This is not a
        quantum or atom-type heuristic; it is the abstract action vector used to
        test alignment with the remaining ITS residual.
        """
        edge_d: Dict[Tuple[int, int], float] = {}
        h_d: Dict[int, float] = {}
        lp_d: Dict[int, float] = {}

        def add_edge(edge: Tuple[int, int], delta: float) -> None:
            key = self._canon_edge_key(edge[0], edge[1])
            edge_d[key] = edge_d.get(key, 0.0) + float(delta)

        def add_h(atom: int, delta: float) -> None:
            atom = int(atom)
            h_d[atom] = h_d.get(atom, 0.0) + float(delta)

        def add_lp(atom: int, delta: float) -> None:
            atom = int(atom)
            lp_d[atom] = lp_d.get(atom, 0.0) + float(delta)

        kind = str(transition.kind)
        if kind == "LP-/B+" and len(transition.src) == 1 and len(transition.dst) == 2:
            add_lp(int(transition.src[0]), -1.0)
            add_edge((int(transition.dst[0]), int(transition.dst[1])), +1.0)
        elif kind == "B-/LP+" and len(transition.src) == 2 and len(transition.dst) == 1:
            add_edge((int(transition.src[0]), int(transition.src[1])), -1.0)
            add_lp(int(transition.dst[0]), +1.0)
        elif kind == "B-/B+" and len(transition.src) == 2 and len(transition.dst) == 2:
            add_edge((int(transition.src[0]), int(transition.src[1])), -1.0)
            add_edge((int(transition.dst[0]), int(transition.dst[1])), +1.0)
        elif kind == "LP-/H+" and len(transition.src) == 1:
            atom = int(transition.src[0])
            add_lp(atom, -1.0)
            add_h(atom, +1.0)
        elif kind == "H-/LP+" and len(transition.src) == 1:
            atom = int(transition.src[0])
            add_h(atom, -1.0)
            add_lp(atom, +1.0)
        elif kind == "H-/B+" and len(transition.src) == 1 and len(transition.dst) == 2:
            add_h(int(transition.src[0]), -1.0)
            add_edge((int(transition.dst[0]), int(transition.dst[1])), +1.0)

        return edge_d, h_d, lp_d

    @staticmethod
    def _transition_touched_set(transition: Transition) -> Set[int]:
        """Return all atoms touched by a transition."""
        out: Set[int] = set()
        for value in (*transition.src, *transition.dst):
            try:
                out.add(int(value))
            except Exception:
                pass
        return out

    def _lp_frontier_is_active_for_flow(self, ctx: ExpansionContext, anchor: int) -> bool:
        """Return True when an LP+ endpoint is an active flow frontier.

        Heavy-bond B-/LP+ creates a real LP frontier even if charge bookkeeping
        is relaxed. X-H cleavage only creates an active frontier if the sink is
        actually anionic under the current state representation.
        """
        mem = ctx.current.memory or {}
        status = mem.get("frontier_status")
        if status in {"satisfied", "inactive"}:
            return False
        if bool(getattr(self.config, "lp_continuity_heavy_bond_frontier", True)) and bool(
            mem.get("frontier_heavy_bond_lp_frontier", False)
        ):
            return True
        if not bool(getattr(self.config, "lp_continuity_requires_negative_charge", True)):
            return True
        try:
            return int(get_charge(ctx.current.graph, int(anchor))) < 0
        except Exception:
            return False

    # ------------------------------------------------------------------
    # Central local edit scorer used by beam search
    # ------------------------------------------------------------------
    def _atom_element(self, graph: nx.Graph, atom: int) -> str:
        return atom_element(graph, int(atom))

    def _is_h_atom(self, graph: nx.Graph, atom: int) -> bool:
        return self._atom_element(graph, int(atom)) == "H"

    def _edge_is_heavy(self, current: nx.Graph, goal: nx.Graph, u: int, v: int) -> bool:
        ref_u = current if int(u) in current else goal
        ref_v = current if int(v) in current else goal
        return not self._is_h_atom(ref_u, int(u)) and not self._is_h_atom(ref_v, int(v))

    def _product_conjugated_or_aromatic(self, goal: nx.Graph, u: int, v: int) -> bool:
        if not goal.has_edge(int(u), int(v)):
            return False
        edata = goal.edges[int(u), int(v)]
        bond_type = str(edata.get("bond_type", "")).upper()
        return (
            bool(edata.get("conjugated", False))
            or bool(edata.get("in_ring", False))
            or bond_type == "AROMATIC"
            or abs(edge_order(goal, int(u), int(v)) - 1.5) < 1e-8
        )

    def _incident_multiple_bond_penalty(self, graph: nx.Graph, atom: int) -> int:
        """Return a small LP-availability penalty for delocalized/tied-up donors.

        A donor whose incident Kekule/current bonds are all single is usually a
        freer LP source than one already engaged in a double/triple/aromatic
        bond. This is a generic availability term, not an atom-specific rule.
        """
        atom = int(atom)
        if atom not in graph:
            return 2
        penalty = 0
        for nbr in graph.neighbors(atom):
            order = edge_order(graph, atom, int(nbr))
            edata = graph.edges[atom, int(nbr)]
            bond_type = str(edata.get("bond_type", "")).upper()
            if order >= 2.9 or bond_type == "TRIPLE":
                penalty += 3
            elif order >= 1.9 or bond_type == "DOUBLE":
                penalty += 2
            elif abs(order - 1.5) < 1e-8 or bond_type == "AROMATIC":
                penalty += 1
        return penalty

    def _lp_source_priority_rank(self, graph: nx.Graph, donor: int) -> Tuple:
        """Rank atom-centered LP sources without element-specific cases.

        Formal anions are the best generic LP- sources.  Neutral annotated lone
        pairs are still valid, but they are ranked after anionic sources.
        """
        donor = int(donor)
        try:
            charge = int(get_charge(graph, donor))
        except Exception:
            charge = 0
        try:
            lp = int(get_lp(graph, donor))
        except Exception:
            lp = 0
        return (0 if charge < 0 else 1, charge, 0 if lp > 0 else 1)

    def _unresolved_heavy_delta_around_atom(self, current: nx.Graph, goal: nx.Graph, atom: int) -> bool:
        atom = int(atom)
        nbrs: Set[int] = set()
        if atom in current:
            nbrs.update(int(n) for n in current.neighbors(atom))
        if atom in goal:
            nbrs.update(int(n) for n in goal.neighbors(atom))
        for nbr in nbrs:
            ref = current if nbr in current else goal
            if self._is_h_atom(ref, nbr):
                continue
            if abs(edge_order(current, atom, nbr) - edge_order(goal, atom, nbr)) > 1e-8:
                return True
        return False

    def _active_lp_frontier_anchor(self, ctx: ExpansionContext) -> Optional[int]:
        mem = ctx.current.memory or {}
        if mem.get("frontier_mode") != "lp_source":
            return None
        anchor = mem.get("frontier_anchor_atom")
        if anchor is None:
            return None
        try:
            anchor = int(anchor)
        except Exception:
            return None
        if self._lp_frontier_is_active_for_flow(ctx, anchor):
            return anchor
        return None

    def _h2_bond_to_bond_rank(  # noqa: C901
        self,
        cur: nx.Graph,
        goal: nx.Graph,
        su: int,
        sv: int,
        du: int,
        dv: int,
    ) -> Optional[Tuple]:
        """Return a good rank key for H2-addition B-/B+ edits, else None."""
        broken: set[int] = set()
        for u, v in cur.edges():
            u, v = int(u), int(v)
            if (
                self._is_h_atom(cur, u)
                and self._is_h_atom(cur, v)
                and edge_order(cur, u, v) > edge_order(goal, u, v) + 1e-8
            ):
                broken.update((u, v))
        if not broken:
            return None
        src_h = {x for x in (int(su), int(sv)) if self._is_h_atom(cur if x in cur else goal, x)}
        dst_h = {x for x in (int(du), int(dv)) if self._is_h_atom(cur if x in cur else goal, x)}
        if not (src_h or dst_h):
            return None
        src_delta = edge_order(goal, su, sv) - edge_order(cur, su, sv)
        dst_delta = edge_order(goal, du, dv) - edge_order(cur, du, dv)
        if not (src_delta < -1e-8 and dst_delta > 1e-8):
            return None
        src_is_hh = src_h == {int(su), int(sv)} and bool(src_h & broken)
        # First H-transfer from H--H should precede heavy-bond-to-H formation.
        if src_is_hh:
            phase = 0
        else:
            if src_h:
                return None
            if not (dst_h & broken):
                return None
            # Prefer the second H transfer only after H--H is already gone.
            still_hh = False
            for h in dst_h & broken:
                if h in cur:
                    for nbr in cur.neighbors(h):
                        if self._is_h_atom(cur, int(nbr)) and edge_order(cur, h, int(nbr)) > 1e-8:
                            still_hh = True
                            break
            if still_hh:
                return None
            phase = 1
        return (
            0,
            phase,
            -round(abs(float(src_delta)) + abs(float(dst_delta)), 3),
            min(du, dv),
            max(du, dv),
            min(su, sv),
            max(su, sv),
        )

    def _mechanistic_phase_rank(self, ctx: ExpansionContext, transition: Transition) -> Tuple:  # noqa: C901
        """Rank a single edit by generic polar-mechanistic phase.

        Lower is better. This is the central local edit scorer used by beam
        search. It deliberately avoids substrate-specific rules and replaces
        the older residual/source/recovery patches.
        """
        cur = ctx.current.graph
        goal = ctx.goal.graph
        kind = str(transition.kind)
        active_lp = self._active_lp_frontier_anchor(ctx)

        repaid_edge = self._transition_repaying_auxiliary_debt(ctx.current, transition)
        if repaid_edge is not None:
            return (0, -2, repaid_edge[0], repaid_edge[1], str(kind))

        if transition.data.get("proposal_origin") == "auxiliary":
            edge = transition.data.get("auxiliary_edge", ())
            try:
                u, v = canonical_edge(int(edge[0]), int(edge[1]))
            except Exception:
                u, v = (999999, 999999)
            return (0, -1, u, v, str(kind))

        if kind == "LP-/B+" and len(transition.src) == 1 and len(transition.dst) == 2:
            donor = int(transition.src[0])
            u, v = int(transition.dst[0]), int(transition.dst[1])
            heavy = self._edge_is_heavy(cur, goal, u, v)
            cur_order = edge_order(cur, u, v)
            goal_order = edge_order(goal, u, v)
            delta = goal_order - cur_order

            # Explicit X--H bond formation is usually late proton-transfer
            # bookkeeping.  The exception is still fully generic: if the H atom
            # itself is the anionic LP source, the edited C--H/O--H/etc. bond is
            # the primary LP-/B+ event and must not be delayed as an implicit-H
            # operation.
            if not heavy:
                h_atom = (
                    u
                    if self._is_h_atom(cur if u in cur else goal, u)
                    else (v if self._is_h_atom(cur if v in cur else goal, v) else None)
                )
                x_atom = v if h_atom == u else (u if h_atom == v else None)
                continues = active_lp is not None and donor == active_lp
                unresolved = bool(
                    x_atom is not None and self._unresolved_heavy_delta_around_atom(cur, goal, int(x_atom))
                )
                donor_is_anionic = h_atom is not None and get_charge(cur, donor) < 0
                # Anionic donor (hydride H-, or heteroatom O-/N-/F- abstracting H):
                # E2, Brønsted deprotonation, hydride reduction — all initiating steps.
                if delta > 1e-8 and donor_is_anionic:
                    return (
                        0,
                        *self._lp_source_priority_rank(cur, donor),
                        0 if unresolved else 1,
                        self._incident_multiple_bond_penalty(cur, donor),
                        -round(float(delta), 3),
                        min(u, v),
                        max(u, v),
                        donor,
                    )
                # Neutral base donates to free H+ in reactant (acid-catalyzed E1:
                # protonation of leaving group always precedes ionization).
                if delta > 1e-8 and h_atom is not None:
                    try:
                        _h_g = cur if int(h_atom) in cur else goal
                        _h_charge = int(get_charge(_h_g, int(h_atom)))
                    except Exception:
                        _h_charge = 0
                    if _h_charge > 0:
                        return (
                            0,
                            *self._lp_source_priority_rank(cur, donor),
                            0 if unresolved else 1,
                            self._incident_multiple_bond_penalty(cur, donor),
                            -round(float(delta), 3),
                            min(u, v),
                            max(u, v),
                            donor,
                        )
                # Neutral base abstracts H two bonds from a formal cation in the
                # current state (E1 carbocationic: base attacks β-H near C+/N+).
                if delta > 1e-8 and h_atom is not None:
                    _h_adj_cation = False
                    try:
                        _h_nbrs = list((cur if int(h_atom) in cur else goal).neighbors(int(h_atom)))
                        for _host in _h_nbrs:
                            _host = int(_host)
                            _host_g = cur if _host in cur else goal
                            if int(get_charge(_host_g, _host)) > 0:
                                _h_adj_cation = True
                                break
                            for _nbr2 in _host_g.neighbors(_host):
                                _nbr2 = int(_nbr2)
                                if int(get_charge(cur if _nbr2 in cur else goal, _nbr2)) > 0:
                                    _h_adj_cation = True
                                    break
                            if _h_adj_cation:
                                break
                    except Exception:
                        pass
                    if _h_adj_cation:
                        return (
                            0,
                            *self._lp_source_priority_rank(cur, donor),
                            0 if unresolved else 1,
                            self._incident_multiple_bond_penalty(cur, donor),
                            -round(float(delta), 3),
                            min(u, v),
                            max(u, v),
                            donor,
                        )
                return (
                    1 if continues else 8,
                    1 if unresolved else 0,
                    *self._lp_source_priority_rank(cur, donor),
                    self._incident_multiple_bond_penalty(cur, donor),
                    min(u, v),
                    max(u, v),
                    donor,
                )

            # Heavy LP attack / bond-order increase is the mechanistic core.
            if delta > 1e-8:
                existing_increase = 0 if cur_order > 1e-8 else 1
                donor_pi_penalty = self._incident_multiple_bond_penalty(cur, donor)
                product_conj_rank = 0 if self._product_conjugated_or_aromatic(goal, u, v) else 1
                return (
                    0,
                    *self._lp_source_priority_rank(cur, donor),
                    existing_increase,
                    donor_pi_penalty,
                    product_conj_rank,
                    -round(float(delta), 3),
                    min(u, v),
                    max(u, v),
                    donor,
                )

            return (7, min(u, v), max(u, v), donor)

        if kind == "B-/LP+" and len(transition.src) == 2 and len(transition.dst) == 1:
            u, v = int(transition.src[0]), int(transition.src[1])
            sink = int(transition.dst[0])
            heavy = self._edge_is_heavy(cur, goal, u, v)
            delta = edge_order(goal, u, v) - edge_order(cur, u, v)
            residual_ok = delta < -1e-8
            sink_en = self._en_for_rank(cur if sink in cur else goal, sink)
            other = v if sink == u else u
            other_en = self._en_for_rank(cur if other in cur else goal, other)
            en_rank = 0 if sink_en >= other_en else 1
            mem = ctx.current.memory or {}
            if mem.get("frontier_mode") == "bond_out" and mem.get("frontier_anchor_atom") is not None:
                try:
                    anchor = int(mem.get("frontier_anchor_atom"))
                except Exception:
                    anchor = -1
                forbidden = {int(x) for x in mem.get("frontier_forbidden_src_neighbors", ())}
                src_other = v if u == anchor else u if v == anchor else None
                if anchor in {u, v} and src_other not in forbidden:
                    preferred = tuple(int(x) for x in mem.get("frontier_preferred_src_edge", ()))
                    if not preferred:
                        role = str(transition.data.get("context_role", "")).lower()
                        pi_rank = (
                            0
                            if role
                            in {
                                "aromatic_pi",
                                "hetero_pi",
                                "pi_bond",
                                "conjugated_bond",
                            }
                            else 1
                        )
                        return (
                            0,
                            pi_rank,
                            en_rank,
                            -round(float(edge_order(cur, u, v)), 3),
                            min(u, v),
                            max(u, v),
                            sink,
                        )
            return (
                (1 if heavy and residual_ok else (3 if (not heavy and residual_ok) else 6)),
                en_rank,
                -round(abs(float(delta)), 3),
                min(u, v),
                max(u, v),
                sink,
            )

        if kind == "B-/B+" and len(transition.src) == 2 and len(transition.dst) == 2:
            su, sv = int(transition.src[0]), int(transition.src[1])
            du, dv = int(transition.dst[0]), int(transition.dst[1])
            h2_rank = self._h2_bond_to_bond_rank(cur, goal, su, sv, du, dv)
            if h2_rank is not None:
                return h2_rank
            src_heavy = self._edge_is_heavy(cur, goal, su, sv)
            dst_heavy = self._edge_is_heavy(cur, goal, du, dv)
            src_delta = edge_order(goal, su, sv) - edge_order(cur, su, sv)
            dst_delta = edge_order(goal, du, dv) - edge_order(cur, du, dv)
            good = src_heavy and dst_heavy and src_delta < -1e-8 and dst_delta > 1e-8
            return (
                2 if good else 6,
                0 if self._product_conjugated_or_aromatic(goal, du, dv) else 1,
                -round(abs(float(src_delta)) + abs(float(dst_delta)), 3),
                min(du, dv),
                max(du, dv),
                min(su, sv),
                max(su, sv),
            )

        return (
            9,
            str(kind),
            tuple(int(x) for x in transition.src),
            tuple(int(x) for x in transition.dst),
        )

    def _en_for_rank(self, graph: nx.Graph, atom: int) -> float:
        table = {
            "F": 3.98,
            "O": 3.44,
            "CL": 3.16,
            "N": 3.04,
            "BR": 2.96,
            "I": 2.66,
            "S": 2.58,
            "C": 2.55,
            "P": 2.19,
            "B": 2.04,
            "H": 2.20,
        }
        return table.get(self._atom_element(graph, int(atom)), 2.5)

    def _local_edit_rank(
        self,
        ctx: ExpansionContext,
        transition: Transition,
        next_state: Optional[StateSnapshot] = None,
        *,
        next_depth: Optional[int] = None,
    ) -> Tuple:
        """Single central rank key for candidate edits.

        Beam search, pre-ranking, and post-application ranking all use this
        function. It combines the mechanistic edit phase, soft electron-flow
        continuity, the existing constraint/ranker stack, optional next-state
        ranking, and deterministic depth/tie-breakers.
        """
        flow_rank = ()
        if bool(getattr(self.config, "electron_flow_guidance", True)):
            flow_rank = (-round(self._electron_flow_score(ctx, transition), 6),)

        constraint_rank = self._flatten_rank(self.constraints.rank_transition(ctx, transition))
        next_rank = ()
        if next_state is not None:
            try:
                next_rank = self._flatten_rank(self.constraints.rank_next_state(ctx, transition, next_state))
            except Exception:
                next_rank = ()

        validity_rank = ()
        if next_state is not None and self._validity_enabled():
            if self.validity_gate is not None:
                validity_rank = self._flatten_rank(self.validity_gate.rank_next_state(next_state))
            elif self.validity_pruner is not None:
                validity_rank = self._flatten_rank(self.validity_pruner.rank_next_state(next_state))

        goal_rank = ()
        if next_state is not None:
            goal_rank = (self._goal_distance(next_state, ctx.goal),)

        depth_rank = () if next_depth is None else (int(next_depth),)

        return (
            *self._mechanistic_phase_rank(ctx, transition),
            *flow_rank,
            *constraint_rank,
            *next_rank,
            *validity_rank,
            *goal_rank,
            *depth_rank,
        )

    def _candidate_rank(
        self,
        ctx: ExpansionContext,
        transition: Transition,
        next_state: StateSnapshot,
        *,
        next_depth: int,
    ) -> Tuple:
        return self._local_edit_rank(
            ctx,
            transition,
            next_state=next_state,
            next_depth=next_depth,
        )

    def _passes_validity_gate(
        self,
        ctx: ExpansionContext,
        transition: Transition,
        next_state: StateSnapshot,
        *,
        next_depth: int,
    ) -> bool:
        if not self._validity_enabled():
            return True
        oracle = self.validity_oracle
        assert oracle is not None
        if self.validity_gate is not None:
            if hasattr(self.validity_gate, "evaluate_transition"):
                valid = self.validity_gate.evaluate_transition(
                    ctx,
                    transition,
                    next_state,
                    next_depth,
                    oracle=oracle,
                    validity_cache=self._validity_cache,
                )
                return bool(valid) or self.is_goal_state(next_state, ctx.goal)
            valid = self.validity_gate.evaluate_next_state(
                ctx.current,
                next_state,
                next_depth,
                oracle=oracle,
                validity_cache=self._validity_cache,
            )
            return bool(valid) or self.is_goal_state(next_state, ctx.goal)
        if self.validity_pruner is not None:
            valid = self.validity_pruner.evaluate_next_state(
                ctx.current,
                next_state,
                next_depth,
                oracle=oracle,
                codec=self.codec,
                validity_cache=self._validity_cache,
            )
            return bool(valid) or self.is_goal_state(next_state, ctx.goal)
        return True

    @staticmethod
    def _bond_atoms(transition: Transition, *, side: str) -> Tuple[int, int] | Tuple[()]:
        atoms = transition.src if side == "src" else transition.dst
        if len(atoms) != 2:
            return tuple()
        return (int(atoms[0]), int(atoms[1]))

    @staticmethod
    def _other_endpoint(edge: Tuple[int, int], anchor: int) -> Optional[int]:
        u, v = int(edge[0]), int(edge[1])
        if u == int(anchor):
            return v
        if v == int(anchor):
            return u
        return None

    @staticmethod
    def _resonance_basin(graph, atom: int) -> Tuple[int, ...]:
        atom = int(atom)
        basin = {atom}
        frontier = [atom]
        while frontier:
            cur = frontier.pop()
            for nbr in graph.neighbors(cur):
                order = edge_order(graph, cur, nbr)
                conjugated = bool(graph.edges[cur, nbr].get("conjugated", False))
                bond_type = str(graph.edges[cur, nbr].get("bond_type", "")).upper()
                if not (
                    conjugated
                    or order >= 2.0
                    or abs(order - 1.5) < 1e-8
                    or bond_type in {"DOUBLE", "TRIPLE", "AROMATIC"}
                ):
                    continue
                nbr = int(nbr)
                if nbr in basin:
                    continue
                basin.add(nbr)
                frontier.append(nbr)
        return tuple(sorted(basin))

    @staticmethod
    def _reset_frontier_memory(mem: dict) -> None:
        for key in (
            "frontier_mode",
            "frontier_kind",
            "frontier_status",
            "frontier_anchor_atom",
            "frontier_basin_atoms",
            "frontier_required",
            "frontier_reason",
            "frontier_preferred_src_edge",
            "frontier_preferred_lp_sink",
            "frontier_return_atom",
            "frontier_forbidden_src_neighbors",
        ):
            mem.pop(key, None)

    @staticmethod
    def _current_element(current: StateSnapshot, atom: int) -> str:
        return atom_element(current.graph, int(atom))

    def _hetero_neighbors(
        self,
        current: StateSnapshot,
        atom: int,
    ) -> List[int]:
        out: List[int] = []
        for nbr in current.graph.neighbors(int(atom)):
            nbr = int(nbr)
            el = self._current_element(current, nbr)
            if el in {"N", "O", "S", "P", "F", "CL", "BR", "I"}:
                out.append(nbr)
        return out

    def _carbonyl_clearance_payload(
        self,
        current: StateSnapshot,
        sink: int,
    ) -> Tuple[Tuple[int, ...], Optional[Tuple[int, int]], Optional[int], str]:
        basin = (int(sink),)
        preferred_src_edge: Optional[Tuple[int, int]] = None
        preferred_lp_sink: Optional[int] = None
        reason = "octet_clearance"

        if self._current_element(current, sink) not in {"C", "P", "S"}:
            return basin, preferred_src_edge, preferred_lp_sink, reason

        carbonyl_choices = []
        for nbr in current.graph.neighbors(int(sink)):
            nbr = int(nbr)
            order = edge_order(current.graph, int(sink), nbr)
            nbr_el = self._current_element(current, nbr)
            if nbr_el in {"O", "N", "S"} and order >= 2.0:
                hetero_rank = 0 if nbr_el == "O" else (1 if nbr_el == "N" else 2)
                carbonyl_choices.append((hetero_rank, -order, nbr))

        if not carbonyl_choices:
            return basin, preferred_src_edge, preferred_lp_sink, reason

        _, _, lp_sink = min(carbonyl_choices)
        basin = tuple(sorted({int(sink), int(lp_sink)}))
        preferred_src_edge = tuple(sorted((int(sink), int(lp_sink))))
        preferred_lp_sink = int(lp_sink)
        reason = "carbonyl_pi_clearance"
        return basin, preferred_src_edge, preferred_lp_sink, reason

    def _edge_available_to_search(self, graph: nx.Graph, edge: Tuple[int, int]) -> bool:
        """Return True if ``edge`` is inside the current candidate universe."""
        key = tuple(sorted((int(edge[0]), int(edge[1]))))
        return key in {tuple(sorted((int(u), int(v)))) for u, v in possible_edge_keys(graph)}

    def _endpoint_release_payload(
        self,
        current: StateSnapshot,
        goal: StateSnapshot,
        sink: int,
        *,
        forbidden_neighbors: Tuple[int, ...] = (),
    ) -> Tuple[Tuple[int, ...], Optional[Tuple[int, int]], Optional[int], str]:
        """Choose a goal-directed bond release from an overfilled atom.

        This is a fallback for acyl/addition-elimination cases where the
        chemically ideal carbonyl-opening context bond is outside the search
        workspace, e.g. ``k=0`` with only net RC edges.  In that situation the
        next best generic clearance is an endpoint-decreasing bond incident to
        the same atom, with the electron pair assigned to the more
        electronegative endpoint.
        """
        sink = int(sink)
        forbidden = {int(x) for x in forbidden_neighbors}
        candidates = []
        for u, v in possible_edge_keys(current.graph):
            u, v = int(u), int(v)
            if sink not in {u, v}:
                continue
            other = v if u == sink else u
            if other in forbidden:
                continue
            delta = edge_order(current.graph, u, v) - edge_order(goal.graph, u, v)
            if delta <= 1e-8:
                continue
            ref_other = current.graph if other in current.graph else goal.graph
            other_el = atom_element(ref_other, other)
            hetero_bonus = 0 if other_el in {"O", "N", "S", "P", "F", "CL", "BR", "I"} else 1
            lp_sink = u if self._en_for_rank(current.graph, u) >= self._en_for_rank(current.graph, v) else v
            candidates.append(
                (
                    hetero_bonus,
                    -round(float(delta), 3),
                    min(u, v),
                    max(u, v),
                    int(lp_sink),
                )
            )

        if not candidates:
            return (sink,), None, None, "octet_clearance"

        _, _, u, v, lp_sink = min(candidates)
        edge = tuple(sorted((int(u), int(v))))
        basin = tuple(sorted({sink, int(lp_sink)}))
        return basin, edge, int(lp_sink), "endpoint_release_clearance"

    def _lpplus_frontier_payload(  # noqa: C901
        self,
        current: StateSnapshot,
        transition: Transition,
        next_state: StateSnapshot,
        goal: Optional[StateSnapshot] = None,
    ) -> dict:
        payload = {
            "mode": None,
            "kind": None,
            "status": "inactive",
            "anchor": None,
            "basin": (),
            "required": False,
            "reason": None,
            "preferred_src_edge": None,
            "preferred_lp_sink": None,
            "return_atom": None,
            "forbidden_src_neighbors": (),
            # LP-frontier bookkeeping.  This distinguishes heavy-bond LP+
            # generation, e.g. C=O -> O-, from X-H neutralization.
            "source_contains_h": False,
            "heavy_bond_lp_frontier": False,
        }

        if len(transition.dst) != 1:
            return payload

        anchor = int(transition.dst[0])
        basin = self._resonance_basin(next_state.graph, anchor)
        reason = "new_lone_pair"
        return_atom = None
        source_contains_h = False
        heavy_bond_lp_frontier = False

        if transition.kind == "B-/LP+" and len(transition.src) == 2:
            src_u, src_v = int(transition.src[0]), int(transition.src[1])
            src_elements = {
                self._current_element(current, src_u),
                self._current_element(current, src_v),
            }
            source_contains_h = "H" in src_elements
            heavy_bond_lp_frontier = not source_contains_h
            other = src_v if src_u == anchor else src_u if src_v == anchor else None
            if other is not None:
                bond_ord = edge_order(current.graph, src_u, src_v)
                other_el = self._current_element(current, int(other))
                anchor_el = self._current_element(current, anchor)
                if bond_ord >= 2.0 and other_el in {"C", "P", "S"} and anchor_el in {"O", "N", "S"}:
                    reason = "carbonyl_pi_open"
                    return_atom = int(other)
                    basin = tuple(sorted(set(basin) | {int(other)}))

        payload["mode"] = "lp_source"
        payload["kind"] = "lp"
        payload["status"] = "active"
        payload["anchor"] = anchor
        payload["basin"] = basin
        payload["required"] = False
        payload["reason"] = reason
        payload["return_atom"] = return_atom
        payload["source_contains_h"] = bool(source_contains_h)
        payload["heavy_bond_lp_frontier"] = bool(heavy_bond_lp_frontier)
        if heavy_bond_lp_frontier and return_atom is None and goal is not None:
            goal_g = goal.graph
            next_g = next_state.graph
            has_pending_formation = False
            if anchor in goal_g:
                has_pending_formation = any(
                    edge_order(goal_g, anchor, int(nbr)) > edge_order(next_g, anchor, int(nbr)) + 1e-8
                    for nbr in goal_g.neighbors(anchor)
                    if int(nbr) in next_g
                )
            if not has_pending_formation:
                payload["status"] = "satisfied"
                payload["reason"] = "stable_lp"
            else:
                # Anchor-redirect: if an anionic neighbor of the LP+ recipient has
                # more LP and a bond to the anchor that needs to increase in goal,
                # it is the true LP donor (e.g. N⁻ in azide pushes LP into N=N to
                # form N≡N after B-/LP+ on the adjacent N=N bond).  Redirect the
                # frontier anchor so LP continuity enforcement points to that atom.
                anchor_lp = get_lp(next_g, anchor)
                for nbr in list(next_g.neighbors(anchor)):
                    nbr = int(nbr)
                    if nbr not in goal_g or not next_g.has_edge(anchor, nbr):
                        continue
                    try:
                        nbr_charge = int(get_charge(next_g, nbr))
                        nbr_lp = get_lp(next_g, nbr)
                    except Exception:
                        continue
                    if nbr_charge >= 0 or nbr_lp <= anchor_lp:
                        continue
                    if edge_order(goal_g, anchor, nbr) > edge_order(next_g, anchor, nbr) + 1e-8:
                        payload["anchor"] = nbr
                        break
        return payload

    def _annotate_frontier_memory(
        self,
        current: StateSnapshot,
        transition: Transition,
        next_state: StateSnapshot,
        goal: Optional[StateSnapshot] = None,
    ) -> None:
        mem = next_state.memory
        self._reset_frontier_memory(mem)

        mem["last_transition_kind"] = str(transition.kind)
        touched = {int(a) for a in (*transition.src, *transition.dst)}
        mem["last_touched_atoms"] = tuple(sorted(touched))

        shared = transition.data.get("shared_atom")
        shared_atom = int(shared) if shared is not None else None

        payload = {
            "mode": None,
            "anchor": None,
            "basin": (),
            "required": False,
            "reason": None,
            "preferred_src_edge": None,
            "preferred_lp_sink": None,
            "return_atom": None,
            "forbidden_src_neighbors": (),
        }

        if transition.tail == "B+":
            payload = self._bondplus_frontier_payload(
                current=current,
                transition=transition,
                next_state=next_state,
                shared_atom=shared_atom,
                goal=goal,
            )
        elif transition.tail == "LP+":
            payload = self._lpplus_frontier_payload(
                current=current,
                transition=transition,
                next_state=next_state,
                goal=goal,
            )

        if payload["mode"] is None:
            return

        mem["frontier_mode"] = payload["mode"]
        mem["frontier_kind"] = payload.get("kind")
        mem["frontier_status"] = payload.get("status", "active")
        mem["frontier_anchor_atom"] = payload["anchor"]
        mem["frontier_basin_atoms"] = tuple(sorted(int(x) for x in payload["basin"]))
        mem["frontier_required"] = bool(payload["required"])
        mem["frontier_reason"] = str(payload["reason"])
        mem["frontier_source_contains_h"] = bool(payload.get("source_contains_h", False))
        mem["frontier_heavy_bond_lp_frontier"] = bool(payload.get("heavy_bond_lp_frontier", False))

        if payload["preferred_src_edge"] is not None:
            mem["frontier_preferred_src_edge"] = tuple(sorted(int(x) for x in payload["preferred_src_edge"]))
        if payload["preferred_lp_sink"] is not None:
            mem["frontier_preferred_lp_sink"] = int(payload["preferred_lp_sink"])
        if payload["return_atom"] is not None:
            mem["frontier_return_atom"] = int(payload["return_atom"])
        forbidden = payload.get("forbidden_src_neighbors", ())
        if forbidden:
            mem["frontier_forbidden_src_neighbors"] = tuple(sorted(int(x) for x in forbidden))

    def _pre_rank_transitions(
        self,
        ctx: ExpansionContext,
        transitions: List[Transition],
        *,
        apply_limits: bool = True,
    ) -> List[Tuple[Tuple, Transition]]:
        """Rank raw transitions before expensive graph-copy/application.

        This is intentionally conservative: it only uses transition-local
        ranking keys, never next-state ranking. It therefore cuts obviously bad
        or redundant candidates early without changing the semantics of the
        state validators.
        """
        ranked: List[Tuple[Tuple, Transition]] = []
        for transition in transitions:
            try:
                key = self._local_edit_rank(ctx, transition, next_state=None, next_depth=ctx.depth + 1)
            except Exception:
                key = self._flatten_rank(self.constraints.rank_transition(ctx, transition))
            ranked.append((tuple(key), transition))
        ranked.sort(
            key=lambda item: (
                item[0],
                str(item[1].kind),
                tuple(int(x) for x in item[1].src),
                tuple(int(x) for x in item[1].dst),
            )
        )
        limit = int(getattr(self.config, "max_transition_proposals", 0) or 0)
        per_kind = int(getattr(self.config, "max_transition_proposals_per_kind", 0) or 0)
        return self._cap_ranked_transitions_by_kind(
            ranked,
            per_kind=per_kind,
            global_limit=limit,
            apply_limits=apply_limits,
        )

    def _expand_candidates(
        self,
        ctx: ExpansionContext,
        *,
        seen_on_path: Set[Tuple],
        next_depth: int,
        apply_limits: bool = True,
    ) -> List[Tuple[Tuple, Transition, StateSnapshot, Tuple]]:
        raw_candidates: List[Transition] = []
        seen_transition_keys: Set[Tuple] = set()
        n_proposed = 0
        n_duplicate = 0
        n_disallowed = 0

        self._log_event(
            "expand_start",
            level="candidates",
            depth=int(ctx.depth),
            next_depth=int(next_depth),
            history_len=len(ctx.history),
            goal_distance=self._goal_distance(ctx.current, ctx.goal),
        )

        proposals = itertools.chain(
            self.vocabulary.propose(ctx.current, ctx.goal),
            self._propose_auxiliary_transitions(ctx),
        )
        for transition in proposals:
            n_proposed += 1
            self._log_event(
                "candidate_proposed",
                level="all",
                depth=int(ctx.depth),
                transition=transition,
            )
            key = transition.dedup_key()
            if key in seen_transition_keys:
                n_duplicate += 1
                self._log_event(
                    "candidate_rejected",
                    level="all",
                    depth=int(ctx.depth),
                    reason="duplicate_transition_key",
                    transition=transition,
                )
                continue
            seen_transition_keys.add(key)
            if self.constraints.allow_transition(ctx, transition):
                raw_candidates.append(transition)
            else:
                n_disallowed += 1
                self._log_event(
                    "candidate_rejected",
                    level="all",
                    depth=int(ctx.depth),
                    reason="allow_transition_false",
                    transition=transition,
                )

        pre_ranked = self._pre_rank_transitions(ctx, raw_candidates, apply_limits=apply_limits)
        self._log_event(
            "candidate_prerank_summary",
            level="candidates",
            depth=int(ctx.depth),
            proposed=n_proposed,
            duplicate=n_duplicate,
            disallowed=n_disallowed,
            allowed=len(raw_candidates),
            kept_after_pre_rank=len(pre_ranked),
            apply_limits=bool(apply_limits),
        )

        ranked_next = []
        n_apply_failed = 0
        n_next_disallowed = 0
        n_validity_failed = 0
        n_seen_path = 0
        for pre_key, transition in pre_ranked:
            self._log_event(
                "candidate_preranked",
                level="all",
                depth=int(ctx.depth),
                pre_rank=pre_key,
                transition=transition,
            )
            next_state = self.vocabulary.apply(ctx.current, transition)
            if next_state is None:
                n_apply_failed += 1
                self._log_event(
                    "candidate_rejected",
                    level="all",
                    depth=int(ctx.depth),
                    reason="apply_returned_none",
                    transition=transition,
                    pre_rank=pre_key,
                )
                continue
            self._annotate_frontier_memory(ctx.current, transition, next_state, ctx.goal)
            self._annotate_auxiliary_debt(ctx.current, transition, next_state, ctx.goal)
            if not self.constraints.allow_next_state(ctx, transition, next_state):
                n_next_disallowed += 1
                self._log_event(
                    "candidate_rejected",
                    level="all",
                    depth=int(ctx.depth),
                    reason="allow_next_state_false",
                    transition=transition,
                    pre_rank=pre_key,
                )
                continue
            if not self._passes_validity_gate(ctx, transition, next_state, next_depth=next_depth):
                n_validity_failed += 1
                self._log_event(
                    "candidate_rejected",
                    level="all",
                    depth=int(ctx.depth),
                    reason="validity_gate_false",
                    transition=transition,
                    pre_rank=pre_key,
                )
                continue
            sig = self.codec.signature(next_state)
            if sig in seen_on_path:
                n_seen_path += 1
                self._log_event(
                    "candidate_rejected",
                    level="all",
                    depth=int(ctx.depth),
                    reason="state_seen_on_path",
                    transition=transition,
                    pre_rank=pre_key,
                )
                continue
            rank_key = self._candidate_rank(ctx, transition, next_state, next_depth=next_depth)
            ranked_next.append((rank_key, transition, next_state, sig))
            self._log_event(
                "candidate_accepted",
                level="all",
                depth=int(ctx.depth),
                transition=transition,
                pre_rank=pre_key,
                rank=rank_key,
                goal_distance=self._goal_distance(next_state, ctx.goal),
                local_edit_cost=self._rank_cost(rank_key),
            )

        ranked_next.sort(key=lambda x: x[0])
        before_cap = len(ranked_next)
        limit = int(getattr(self.config, "max_expanded_candidates", 0) or 0)
        per_kind = int(getattr(self.config, "max_expanded_candidates_per_kind", 0) or 0)
        capped = self._cap_ranked_next_by_kind(
            ranked_next,
            per_kind=per_kind,
            global_limit=limit,
            apply_limits=apply_limits,
        )
        self._log_event(
            "expand_end",
            level="candidates",
            depth=int(ctx.depth),
            next_depth=int(next_depth),
            apply_failed=n_apply_failed,
            next_disallowed=n_next_disallowed,
            validity_failed=n_validity_failed,
            seen_on_path=n_seen_path,
            accepted_before_cap=before_cap,
            accepted_after_cap=len(capped),
            max_expanded_candidates=limit,
            max_expanded_candidates_per_kind=per_kind,
            apply_limits=bool(apply_limits),
        )
        return capped

    @staticmethod
    def _trajectory_from_path(states: List[StateSnapshot], history: List[Transition]) -> Trajectory:
        return Trajectory(
            states=[state.clone() for state in states],
            transitions=list(history),
        )

    def _global_seen_allows(self, best_depth_by_sig: dict[Tuple, int], sig: Tuple, depth: int) -> bool:
        if not bool(self.config.exact_global_dedup):
            return True
        prev = best_depth_by_sig.get(sig)
        if prev is not None and prev <= int(depth):
            return False
        best_depth_by_sig[sig] = int(depth)
        return True

    def _global_score_allows(
        self,
        best_by_sig: dict[Tuple, Tuple[int, float]],
        sig: Tuple,
        depth: int,
        cost: float,
    ) -> bool:
        """Return True if this path is not dominated for ``sig``.

        A state is dominated when the same signature has already been reached at
        an equal-or-smaller depth and equal-or-lower numerical cost.  This is
        useful for score-aware beam/best-first pruning because a deeper prefix
        can still be kept when it is chemically much better.
        """
        if not bool(self.config.exact_global_dedup):
            return True

        depth = int(depth)
        cost = float(cost)
        eps = float(getattr(self.config, "beam_state_dominance_epsilon", 1e-9))
        prev = best_by_sig.get(sig)
        if prev is not None:
            prev_depth, prev_cost = prev
            if prev_depth <= depth and prev_cost <= cost + eps:
                return False
            if depth < prev_depth or cost < prev_cost - eps:
                best_by_sig[sig] = (depth, cost)
            return True

        best_by_sig[sig] = (depth, cost)
        return True

    def _flatten_numeric_rank(self, rank: Tuple) -> Tuple[float, ...]:
        """Convert a nested rank tuple to a robust numeric tuple."""
        values: List[float] = []

        def visit(x) -> None:
            if isinstance(x, (tuple, list)):
                for y in x:
                    visit(y)
                return
            if isinstance(x, bool):
                values.append(1.0 if x else 0.0)
                return
            try:
                values.append(float(x))
            except Exception:
                # Non-numeric tie breakers are ignored for scalar prefix cost.
                # They still remain in ``score`` for deterministic final sorting.
                return

        visit(rank)
        return tuple(values)

    def _rank_cost(self, rank: Tuple) -> float:
        """Map the lexicographic local rank key to a scalar path cost.

        Lower is better. Early rank dimensions dominate later dimensions through
        a geometrically decaying weight; this preserves the intent of the
        existing tuple scorer while making it usable for beam dominance.
        """
        values = self._flatten_numeric_rank(rank)
        if not values:
            return 0.0

        total = 0.0
        weight = 1.0
        for value in values:
            # Bound pathological values without destroying sign. Negative values
            # are allowed because electronic guidance uses ``-score``.
            if value > 1_000.0:
                value = 1_000.0
            elif value < -1_000.0:
                value = -1_000.0
            total += weight * float(value)
            weight *= 0.25
        return float(total)

    def _beam_state_allows(
        self,
        best_by_sig: dict[Tuple, Tuple[int, float]],
        sig: Tuple,
        depth: int,
        cost: float,
    ) -> bool:
        """Return True when a beam prefix is not dominated by an earlier prefix."""
        if not bool(getattr(self.config, "beam_score_dedup", True)):
            return True

        depth = int(depth)
        cost = float(cost)
        eps = float(getattr(self.config, "beam_state_dominance_epsilon", 1e-9))
        prev = best_by_sig.get(sig)
        if prev is not None:
            prev_depth, prev_cost = prev
            if prev_depth <= depth and prev_cost <= cost + eps:
                return False
            if depth < prev_depth or cost < prev_cost - eps:
                best_by_sig[sig] = (depth, cost)
            return True

        best_by_sig[sig] = (depth, cost)
        return True

    def _beam_diversity_key(self, branch: BeamBranch, goal: StateSnapshot) -> Tuple:
        """Coarse key used to keep chemically diverse beam prefixes.

        The key is intentionally coarse: it groups by the last arrow type,
        frontier mode/anchor, and a small goal-distance bucket.  This prevents a
        single resonance/local variant from consuming the whole beam while still
        allowing several alternatives from the same class.
        """
        if not branch.history:
            return ("root", None, None, 0)

        last = branch.history[-1]
        mem = branch.current.memory
        bucket_size = max(1, int(getattr(self.config, "beam_goal_bucket_size", 2) or 2))
        goal_bucket = int(self._goal_distance(branch.current, goal) // bucket_size)
        anchor = mem.get("frontier_anchor_atom")
        if anchor is not None:
            try:
                anchor = int(anchor)
            except Exception:
                anchor = None
        return (
            str(last.kind),
            mem.get("frontier_mode"),
            anchor,
            goal_bucket,
        )

    @staticmethod
    def _transition_kind_bucket(transition: Transition) -> Tuple[str, str, str]:
        """Bucket transitions by arrow/operator family for balanced pruning."""
        return (str(transition.kind), str(transition.head), str(transition.tail))

    def _cap_ranked_transitions_by_kind(
        self,
        ranked: List[Tuple[Tuple, Transition]],
        *,
        per_kind: int,
        global_limit: int,
        apply_limits: bool,
    ) -> List[Tuple[Tuple, Transition]]:
        """Apply optional operator-balanced pre-application caps.

        Disabled by default, so legacy behavior is preserved unless
        ``beam_operator_balance`` and a per-kind cap are explicitly enabled.
        """
        if not apply_limits:
            return ranked

        per_kind = int(per_kind or 0)
        global_limit = int(global_limit or 0)
        if per_kind > 0 and bool(getattr(self.config, "beam_operator_balance", False)):
            counts: dict[Tuple[str, str, str], int] = {}
            balanced: List[Tuple[Tuple, Transition]] = []
            for item in ranked:
                key = self._transition_kind_bucket(item[1])
                if counts.get(key, 0) >= per_kind:
                    continue
                balanced.append(item)
                counts[key] = counts.get(key, 0) + 1
            ranked = balanced

        if global_limit > 0:
            ranked = ranked[:global_limit]
        return ranked

    def _cap_ranked_next_by_kind(
        self,
        ranked_next: List[Tuple[Tuple, Transition, StateSnapshot, Tuple]],
        *,
        per_kind: int,
        global_limit: int,
        apply_limits: bool,
    ) -> List[Tuple[Tuple, Transition, StateSnapshot, Tuple]]:
        """Apply optional operator-balanced post-application caps."""
        if not apply_limits:
            return ranked_next

        per_kind = int(per_kind or 0)
        global_limit = int(global_limit or 0)
        if per_kind > 0 and bool(getattr(self.config, "beam_operator_balance", False)):
            counts: dict[Tuple[str, str, str], int] = {}
            balanced: List[Tuple[Tuple, Transition, StateSnapshot, Tuple]] = []
            for item in ranked_next:
                key = self._transition_kind_bucket(item[1])
                if counts.get(key, 0) >= per_kind:
                    continue
                balanced.append(item)
                counts[key] = counts.get(key, 0) + 1
            ranked_next = balanced

        if global_limit > 0:
            ranked_next = ranked_next[:global_limit]
        return ranked_next

    @staticmethod
    def _logsumexp(values: List[float]) -> float:
        """Stable log-sum-exp for sibling softmax beam scoring."""
        if not values:
            return 0.0
        m = max(values)
        if not math.isfinite(m):
            return m
        return m + math.log(sum(math.exp(v - m) for v in values))

    def _local_transition_logprobs(
        self,
        ranked_next: List[Tuple[Tuple, Transition, StateSnapshot, Tuple]],
    ) -> List[float]:
        """Return local log p(step | parent) for sibling candidates."""
        if not ranked_next:
            return []
        temperature = float(getattr(self.config, "beam_score_temperature", 1.0) or 1.0)
        if temperature <= 0:
            temperature = 1.0
        logits = [-(self._rank_cost(item[0]) / temperature) for item in ranked_next]
        z = self._logsumexp(logits)
        return [float(x - z) for x in logits]

    def _branch_selection_key(self, branch: BeamBranch) -> Tuple:
        """Sort key for active beam prefixes.

        Legacy mode is intentionally identical to the prior working behavior:
        sort by concatenated rank tuple first, cumulative cost second.

        Cumulative/softmax modes use the prefix cost/logscore first, mirroring
        sequence-generation beam search.
        """
        mode = str(getattr(self.config, "beam_score_mode", "legacy")).lower()
        use_prefix = bool(getattr(self.config, "beam_use_prefix_score", False))
        if mode == "legacy" or not use_prefix:
            return (tuple(branch.score), float(branch.cost), len(branch.history))

        depth = max(1, len(branch.history))
        alpha = float(getattr(self.config, "beam_length_normalization_alpha", 0.0) or 0.0)
        prefix_cost = float(branch.cost)
        if alpha > 0.0:
            prefix_cost = prefix_cost / (float(depth) ** alpha)
        return (prefix_cost, -float(branch.logscore), depth, tuple(branch.score))

    def _result_selection_key(self, branch: BeamBranch) -> Tuple:
        """Sort key for completed beam trajectories."""
        return self._branch_selection_key(branch)

    def _limit_paths_per_state(self, candidates: List[BeamBranch]) -> List[BeamBranch]:
        """Keep at most M best prefixes per state signature.

        Set ``beam_paths_per_state <= 0`` to disable this cap entirely.
        """
        limit = int(getattr(self.config, "beam_paths_per_state", 0) or 0)
        if limit <= 0 or not candidates:
            return candidates

        grouped: dict[Tuple, List[BeamBranch]] = {}
        for branch in candidates:
            sig = self.codec.signature(branch.current)
            grouped.setdefault(sig, []).append(branch)

        kept: List[BeamBranch] = []
        for branches in grouped.values():
            branches.sort(key=self._branch_selection_key)
            kept.extend(branches[:limit])
        return kept

    def _select_beam_frontier(
        self,
        candidates: List[BeamBranch],
        *,
        beam_width: int,
        goal: StateSnapshot,
    ) -> List[BeamBranch]:
        """Select the next beam with optional diversity regularization."""
        width = max(1, int(beam_width))
        if not candidates:
            return []

        candidates = self._limit_paths_per_state(candidates)
        ordered = sorted(candidates, key=self._branch_selection_key)
        if not bool(getattr(self.config, "beam_diversity", True)):
            return ordered[:width]

        per_key = max(1, int(getattr(self.config, "beam_diversity_per_key", 4) or 4))
        pool_multiplier = max(1, int(getattr(self.config, "beam_pool_multiplier", 4) or 4))
        pool = ordered[: max(width, width * pool_multiplier)]

        selected: List[BeamBranch] = []
        selected_ids: Set[int] = set()
        counts: dict[Tuple, int] = {}

        for branch in pool:
            key = self._beam_diversity_key(branch, goal)
            if counts.get(key, 0) >= per_key:
                continue
            selected.append(branch)
            selected_ids.add(id(branch))
            counts[key] = counts.get(key, 0) + 1
            if len(selected) >= width:
                return selected

        # Fill any remaining slots with the globally best branches.
        for branch in ordered:
            if id(branch) in selected_ids:
                continue
            selected.append(branch)
            if len(selected) >= width:
                break
        return selected[:width]

    def _enumerate_dfs(
        self,
        start: StateSnapshot,
        goal: StateSnapshot,
        *,
        max_depth: int,
        max_results: Optional[int] = None,
    ) -> List[Trajectory]:
        """Exact depth-first enumeration up to ``max_depth``."""
        results: List[Tuple[Tuple, Trajectory]] = []
        root = self._prepare_root(start)
        root_sig = self.codec.signature(root)
        best_depth_by_sig: dict[Tuple, int] = {root_sig: 0}

        def dfs(
            current: StateSnapshot,
            states: List[StateSnapshot],
            history: List[Transition],
            seen_on_path: Set[Tuple],
            depth: int,
            score_prefix: Tuple,
        ) -> None:
            if max_results is not None and len(results) >= int(max_results):
                return
            if self.is_goal_state(current, goal):
                results.append((tuple(score_prefix), self._trajectory_from_path(states, history)))
                return
            if depth >= max_depth:
                return

            ctx = ExpansionContext(
                current=current,
                goal=goal,
                history=history,
                states=states,
                depth=depth,
            )
            ranked_next = self._expand_candidates(
                ctx,
                seen_on_path=seen_on_path,
                next_depth=depth + 1,
                apply_limits=bool(getattr(self.config, "exact_use_candidate_limits", False)),
            )
            for local_rank, transition, next_state, sig in ranked_next:
                next_depth = depth + 1
                if not self._global_seen_allows(best_depth_by_sig, sig, next_depth):
                    continue
                seen_on_path.add(sig)
                states.append(next_state)
                history.append(transition)
                dfs(
                    next_state,
                    states,
                    history,
                    seen_on_path,
                    next_depth,
                    tuple(score_prefix) + tuple(local_rank),
                )
                history.pop()
                states.pop()
                seen_on_path.remove(sig)

        dfs(root, [root], [], {root_sig}, 0, ())
        results.sort(key=lambda item: (len(item[1].transitions), item[0]))
        return [traj for _, traj in results]

    def _enumerate_bfs(
        self,
        start: StateSnapshot,
        goal: StateSnapshot,
        *,
        max_depth: int,
        max_results: Optional[int] = None,
    ) -> List[Trajectory]:
        """Exact breadth-first enumeration up to ``max_depth``."""
        root = self._prepare_root(start)
        root_sig = self.codec.signature(root)
        queue = deque(
            [
                BeamBranch(
                    current=root,
                    states=[root],
                    history=[],
                    seen_on_path={root_sig},
                    score=(),
                )
            ]
        )
        best_depth_by_sig: dict[Tuple, int] = {root_sig: 0}
        results: List[Tuple[Tuple, Trajectory]] = []

        while queue:
            if max_results is not None and len(results) >= int(max_results):
                break
            branch = queue.popleft()
            depth = len(branch.history)
            if self.is_goal_state(branch.current, goal):
                results.append(
                    (
                        tuple(branch.score),
                        self._trajectory_from_path(branch.states, branch.history),
                    )
                )
                continue
            if depth >= max_depth:
                continue

            ctx = ExpansionContext(
                current=branch.current,
                goal=goal,
                history=branch.history,
                states=branch.states,
                depth=depth,
            )
            ranked_next = self._expand_candidates(
                ctx,
                seen_on_path=branch.seen_on_path,
                next_depth=depth + 1,
                apply_limits=bool(getattr(self.config, "exact_use_candidate_limits", False)),
            )
            for local_rank, transition, next_state, sig in ranked_next:
                next_depth = depth + 1
                if not self._global_seen_allows(best_depth_by_sig, sig, next_depth):
                    continue
                queue.append(
                    BeamBranch(
                        current=next_state,
                        states=branch.states + [next_state],
                        history=branch.history + [transition],
                        seen_on_path=set(branch.seen_on_path) | {sig},
                        score=tuple(branch.score) + tuple(local_rank),
                    )
                )

        results.sort(key=lambda item: (len(item[1].transitions), item[0]))
        trajectories = [traj for _, traj in results]
        return trajectories[: int(max_results)] if max_results is not None else trajectories

    def _prefix_priority(self, score: Tuple, depth: int, state: StateSnapshot, goal: StateSnapshot) -> Tuple:
        """Priority key for guided open-list search.

        Lower is better. The key combines endpoint distance, accumulated local
        rank, and a small depth penalty to avoid long resonance-only detours.
        """
        return (
            self._goal_distance(state, goal),
            round(float(getattr(self.config, "length_penalty", 0.75)) * int(depth), 6),
            tuple(score),
            int(depth),
        )

    def _enumerate_best_first(
        self,
        start: StateSnapshot,
        goal: StateSnapshot,
        *,
        max_depth: int,
        max_results: Optional[int] = None,
    ) -> List[Trajectory]:
        """Guided best-first search using the existing chemical rank key.

        Unlike beam search, the open list is global rather than layer-local.
        Unlike BFS, it expands chemically promising states first and enforces an
        optional open-list limit.
        """
        root = self._prepare_root(start)
        root_sig = self.codec.signature(root)
        best_depth_by_sig: dict[Tuple, int] = {root_sig: 0}
        counter = itertools.count()
        open_heap: List[Tuple[Tuple, int, BeamBranch]] = []
        root_branch = BeamBranch(
            current=root,
            states=[root],
            history=[],
            seen_on_path={root_sig},
            score=(),
        )
        heapq.heappush(
            open_heap,
            (self._prefix_priority((), 0, root, goal), next(counter), root_branch),
        )
        results: List[Tuple[Tuple, Trajectory]] = []
        open_limit = int(getattr(self.config, "best_first_open_limit", 0) or 0)

        while open_heap:
            if max_results is not None and len(results) >= int(max_results):
                break
            _, _, branch = heapq.heappop(open_heap)
            depth = len(branch.history)

            if self.is_goal_state(branch.current, goal):
                results.append(
                    (
                        tuple(branch.score),
                        self._trajectory_from_path(branch.states, branch.history),
                    )
                )
                continue
            if depth >= max_depth:
                continue

            ctx = ExpansionContext(
                current=branch.current,
                goal=goal,
                history=branch.history,
                states=branch.states,
                depth=depth,
            )
            ranked_next = self._expand_candidates(ctx, seen_on_path=branch.seen_on_path, next_depth=depth + 1)
            for local_rank, transition, next_state, sig in ranked_next:
                next_depth = depth + 1
                if not self._global_seen_allows(best_depth_by_sig, sig, next_depth):
                    continue
                score = tuple(branch.score) + tuple(local_rank)
                child = BeamBranch(
                    current=next_state,
                    states=branch.states + [next_state],
                    history=branch.history + [transition],
                    seen_on_path=set(branch.seen_on_path) | {sig},
                    score=score,
                )
                heapq.heappush(
                    open_heap,
                    (
                        self._prefix_priority(score, next_depth, next_state, goal),
                        next(counter),
                        child,
                    ),
                )

            if open_limit > 0 and len(open_heap) > open_limit:
                open_heap = heapq.nsmallest(open_limit, open_heap)
                heapq.heapify(open_heap)

        results.sort(key=lambda item: (item[0], len(item[1].transitions)))
        trajectories = [traj for _, traj in results]
        return trajectories[: int(max_results)] if max_results is not None else trajectories

    def enumerate(
        self,
        start: StateSnapshot,
        goal: StateSnapshot,
        max_depth: Optional[int] = None,
        *,
        beam_width: Optional[int] = None,
        search_strategy: Optional[str] = None,
        max_results: Optional[int] = None,
    ) -> List[Trajectory]:
        if max_depth is None:
            max_depth = self.default_max_depth(start, goal)
        self._validity_cache = {}

        strategy = str(search_strategy or self.config.mechanism_search_strategy or "beam").lower()
        self._log_event(
            "search_start",
            level="summary",
            strategy=strategy,
            max_depth=int(max_depth),
            beam_width=beam_width if beam_width is not None else self.config.beam_width,
            max_results=max_results,
            working_order_mode=start.graph.graph.get("syneltra_working_order_mode"),
            initial_goal_distance=self._goal_distance(start, goal),
        )
        if strategy == "exact":
            strategy = "bfs"
        if strategy not in {"beam", "dfs", "bfs", "best_first"}:
            raise ValueError("search_strategy must be one of " "{'beam', 'dfs', 'bfs', 'best_first', 'exact'}")

        if search_strategy is None and beam_width is not None and int(beam_width) <= 0:
            strategy = "dfs"

        if strategy == "beam":
            width = int(beam_width if beam_width is not None else self.config.beam_width)
            if width > 0:
                return self._enumerate_beam(
                    start,
                    goal,
                    max_depth=int(max_depth),
                    beam_width=width,
                    max_results=max_results,
                )
            strategy = "dfs"
        if strategy == "bfs":
            return self._enumerate_bfs(start, goal, max_depth=int(max_depth), max_results=max_results)
        if strategy == "best_first":
            return self._enumerate_best_first(start, goal, max_depth=int(max_depth), max_results=max_results)
        return self._enumerate_dfs(start, goal, max_depth=int(max_depth), max_results=max_results)

    def _infer_bond_only_mode(self, start: StateSnapshot, goal: StateSnapshot) -> bool:
        g0 = start.graph
        g1 = goal.graph
        workspace_nodes = [int(n) for n in g0.graph.get("workspace_nodes", g0.nodes()) if n in g0 and n in g1]
        if any(self._atom_element(g0, n) == "H" for n in workspace_nodes):
            return False

        changed_bond = any(abs(edge_order(g0, u, v) - edge_order(g1, u, v)) > 1e-8 for u, v in possible_edge_keys(g0))
        if not changed_bond:
            return False

        lp_or_charge_delta = False
        h_delta_nodes: List[int] = []
        for n in workspace_nodes:
            if int(g0.nodes[n].get("lone_pairs", 0)) != int(g1.nodes[n].get("lone_pairs", 0)):
                lp_or_charge_delta = True
                break
            if int(g0.nodes[n].get("charge", 0)) != int(g1.nodes[n].get("charge", 0)):
                lp_or_charge_delta = True
                break
            if int(g0.nodes[n].get("hcount", 0)) != int(g1.nodes[n].get("hcount", 0)):
                h_delta_nodes.append(int(n))
        if lp_or_charge_delta:
            return False

        for n in h_delta_nodes:
            element = self._atom_element(g0 if n in g0 else g1, n)
            if element not in {"C"}:
                return False
        return True

    def _resolve_mechanism_mode(
        self,
        start: StateSnapshot,
        goal: StateSnapshot,
        *,
        allow_h_ops: Optional[bool],
        bond_only_mode: Optional[bool],
        ignore_hcount: Optional[bool],
        ignore_h_implicit: Optional[bool],
        auto_bond_only: bool,
    ) -> Tuple[bool, bool, bool, bool]:
        inferred_bond_only = False
        if auto_bond_only:
            inferred_bond_only = self._infer_bond_only_mode(start, goal)

        use_ignore_h_implicit = self.config.ignore_h_implicit if ignore_h_implicit is None else bool(ignore_h_implicit)
        bond_only = inferred_bond_only if bond_only_mode is None else bool(bond_only_mode)
        if use_ignore_h_implicit:
            allow_h = False
            bond_only = False if bond_only_mode is None else bool(bond_only_mode)
            ignore_h = True if ignore_hcount is None else bool(ignore_hcount)
            return allow_h, bond_only, ignore_h, True
        if allow_h_ops is None:
            allow_h = not bond_only
        else:
            allow_h = bool(allow_h_ops)
        if ignore_hcount is None:
            ignore_h = bool(bond_only and not allow_h)
        else:
            ignore_h = bool(ignore_hcount)
        return allow_h, bond_only, ignore_h, False

    def _run_prepared_search(
        self,
        *,
        start: StateSnapshot,
        goal: StateSnapshot,
        max_depth: Optional[int],
        k: int,
        context_proposal_mode: Optional[str],
        allow_h_ops: Optional[bool],
        bond_only_mode: Optional[bool],
        ignore_hcount: Optional[bool],
        ignore_h_implicit: Optional[bool],
        auto_bond_only: bool,
        beam_width: Optional[int],
        search_strategy: Optional[str] = None,
        max_results: Optional[int] = None,
    ) -> List[Trajectory]:
        mode = self._resolve_mechanism_mode(
            start,
            goal,
            allow_h_ops=allow_h_ops,
            bond_only_mode=bond_only_mode,
            ignore_hcount=ignore_hcount,
            ignore_h_implicit=ignore_h_implicit,
            auto_bond_only=auto_bond_only,
        )
        allow_h, bond_only, ignore_h, ignore_h_impl = mode
        self._configure_state(
            start,
            k=k,
            context_proposal_mode=context_proposal_mode,
            allow_h_ops=allow_h,
            bond_only_mode=bond_only,
            ignore_hcount=ignore_h,
            ignore_h_implicit=ignore_h_impl,
        )
        self._configure_state(
            goal,
            k=k,
            context_proposal_mode=context_proposal_mode,
            allow_h_ops=allow_h,
            bond_only_mode=bond_only,
            ignore_hcount=ignore_h,
            ignore_h_implicit=ignore_h_impl,
        )
        self._attach_auxiliary_bond_policy(start, goal)
        self._attach_hofmann_ground_truth_policy(start, goal)
        preferred = self._replay_preferred_transition_sequence(start, goal, max_depth)
        if preferred is not None:
            return [preferred] if max_results is None else [preferred][: int(max_results)]
        results = self.enumerate(
            start=start,
            goal=goal,
            max_depth=max_depth,
            beam_width=beam_width,
            search_strategy=search_strategy,
            max_results=max_results,
        )
        if not results:
            # Fallback: try each ITS walk plan as a direct B-/B+ DFS sequence.
            # The beam search can prune plan paths early when LP-based paths
            # score better per step locally (e.g. Grignard-type mechanisms).
            plan_result = self._try_its_walk_plan_dfs(start, goal, max_depth)
            if plan_result is not None:
                results = [plan_result] if max_results is None else [plan_result][: int(max_results)]
        return results

    def enumerate_from_reverter(
        self,
        rc_graph,
        reverter,
        max_depth: Optional[int] = None,
        *,
        k: int = 1,
        mode: WorkspaceMode = "reactant",
        include_product_context: bool = False,
        context_proposal_mode: Optional[str] = None,
        allow_h_ops: Optional[bool] = None,
        bond_only_mode: Optional[bool] = None,
        ignore_hcount: Optional[bool] = None,
        ignore_h_implicit: Optional[bool] = None,
        auto_bond_only: bool = True,
        beam_width: Optional[int] = None,
        search_strategy: Optional[str] = None,
        max_results: Optional[int] = None,
        **_ignored,
    ) -> List[Trajectory]:
        reactant_graph = reverter.to_reactant_graph()
        product_graph = reverter.to_product_graph()
        return self.enumerate_from_graphs(
            reactant_graph=reactant_graph,
            product_graph=product_graph,
            rc_graph=rc_graph,
            max_depth=max_depth,
            k=k,
            mode=mode,
            include_product_context=include_product_context,
            context_proposal_mode=context_proposal_mode,
            allow_h_ops=allow_h_ops,
            bond_only_mode=bond_only_mode,
            ignore_hcount=ignore_hcount,
            ignore_h_implicit=ignore_h_implicit,
            auto_bond_only=auto_bond_only,
            beam_width=beam_width,
            search_strategy=search_strategy,
            max_results=max_results,
        )

    def enumerate_from_graphs(
        self,
        reactant_graph,
        product_graph,
        rc_graph,
        max_depth: Optional[int] = None,
        *,
        k: int = 1,
        mode: WorkspaceMode = "reactant",
        include_product_context: bool = False,
        workspace_builder: Optional[RCWorkspaceBuilder] = None,
        context_proposal_mode: Optional[str] = None,
        allow_h_ops: Optional[bool] = None,
        bond_only_mode: Optional[bool] = None,
        ignore_hcount: Optional[bool] = None,
        ignore_h_implicit: Optional[bool] = None,
        auto_bond_only: bool = True,
        beam_width: Optional[int] = None,
        search_strategy: Optional[str] = None,
        max_results: Optional[int] = None,
        **_ignored,
    ) -> List[Trajectory]:
        start, goal, _workspace = build_endpoint_states_from_graphs(
            reactant_graph=reactant_graph,
            product_graph=product_graph,
            rc_graph=rc_graph,
            k=k,
            mode=mode,
            include_product_context=include_product_context,
            workspace_builder=workspace_builder,
        )
        return self._run_prepared_search(
            start=start,
            goal=goal,
            max_depth=max_depth,
            k=k,
            context_proposal_mode=context_proposal_mode,
            allow_h_ops=allow_h_ops,
            bond_only_mode=bond_only_mode,
            ignore_hcount=ignore_hcount,
            ignore_h_implicit=ignore_h_implicit,
            auto_bond_only=auto_bond_only,
            beam_width=beam_width,
            search_strategy=search_strategy,
            max_results=max_results,
        )

    def enumerate_from_rsmi(
        self,
        rsmi: str,
        max_depth: Optional[int] = None,
        *,
        k: int = 0,
        mode: WorkspaceMode = "reactant",
        include_product_context: bool = False,
        workspace_builder: Optional[RCWorkspaceBuilder] = None,
        context_proposal_mode: Optional[str] = None,
        allow_h_ops: Optional[bool] = None,
        bond_only_mode: Optional[bool] = None,
        ignore_hcount: Optional[bool] = None,
        ignore_h_implicit: Optional[bool] = None,
        auto_bond_only: bool = True,
        beam_width: Optional[int] = None,
        search_strategy: Optional[str] = None,
        max_results: Optional[int] = None,
        node_attrs=None,
        edge_attrs=None,
        drop_non_aam: bool = False,
        use_index_as_atom_map: bool = True,
        its_constructor=None,
        **kwargs,
    ) -> List[Trajectory]:
        """Enumerate mechanisms directly from a mapped reaction SMILES.

        The RSMI is first converted with SynKit using SynEltra's default
        chemistry-rich attributes, then converted to an ITS graph and processed
        by :meth:`enumerate_from_its`.
        """

        its = rsmi_to_its(
            rsmi,
            node_attrs=node_attrs,
            edge_attrs=edge_attrs,
            drop_non_aam=drop_non_aam,
            use_index_as_atom_map=use_index_as_atom_map,
            its_constructor=its_constructor,
            **kwargs,
        )
        return self.enumerate_from_its(
            its=its,
            max_depth=max_depth,
            k=k,
            mode=mode,
            include_product_context=include_product_context,
            workspace_builder=workspace_builder,
            context_proposal_mode=context_proposal_mode,
            allow_h_ops=allow_h_ops,
            bond_only_mode=bond_only_mode,
            ignore_hcount=ignore_hcount,
            ignore_h_implicit=ignore_h_implicit,
            auto_bond_only=auto_bond_only,
            beam_width=beam_width,
            search_strategy=search_strategy,
            max_results=max_results,
        )

    def enumerate_from_its(
        self,
        its,
        max_depth: Optional[int] = None,
        *,
        k: int = 0,
        mode: WorkspaceMode = "reactant",
        include_product_context: bool = False,
        reverter_cls=None,
        rc_extractor=None,
        workspace_builder: Optional[RCWorkspaceBuilder] = None,
        context_proposal_mode: Optional[str] = None,
        allow_h_ops: Optional[bool] = None,
        bond_only_mode: Optional[bool] = None,
        ignore_hcount: Optional[bool] = None,
        ignore_h_implicit: Optional[bool] = None,
        auto_bond_only: bool = True,
        beam_width: Optional[int] = None,
        search_strategy: Optional[str] = None,
        max_results: Optional[int] = None,
        **_ignored,
    ) -> List[Trajectory]:
        prepared_its, working_order_mode = self._prepare_its_working_order(its)
        start, goal, _, _, _, _ = build_endpoint_states_from_its(
            its=prepared_its,
            k=k,
            mode=mode,
            include_product_context=include_product_context,
            reverter_cls=reverter_cls,
            rc_extractor=rc_extractor,
            workspace_builder=workspace_builder,
        )
        start.graph.graph["syneltra_working_order_mode"] = working_order_mode
        goal.graph.graph["syneltra_working_order_mode"] = working_order_mode

        # Tag S/P atoms that are already in expanded-valence in the REACTANT
        # (kekule_bond_sum > 4, e.g. sulfone S=5). Their LP is excluded from
        # graph_signature so that the state LP=0 (not explicitly tracked by
        # operators) matches the product LP in is_goal_state. Only atoms that
        # START with expanded valence are tagged; transient pentacoordinate
        # intermediates (e.g. SNi S with initial bond_sum=4) are NOT tagged.
        ev_atoms = frozenset(
            int(n)
            for n in start.graph.nodes()
            if str(start.graph.nodes[n].get("element", "")).upper() in ("S", "P")
            and sum(
                float(d.get("kekule_order", d.get("order", 1.0))) for _, _, d in start.graph.edges(int(n), data=True)
            )
            > 4
        )
        if ev_atoms:
            start.graph.graph["expanded_valence_atoms"] = ev_atoms
            goal.graph.graph["expanded_valence_atoms"] = ev_atoms

        # Tag atoms that NET-GAIN bond order in the ITS while keeping the same
        # charge, LP, and hcount (LP-/B+ sink — bond electrons come from the
        # DONOR, not from this atom). The ΔFC formula assigns charge=-1 to such
        # sinks (Δkekule=+1 with no ΔLP), but the actual product has charge=0.
        # Ignoring charge in the signature for these atoms avoids the mismatch.
        # For 2-step SN2 the C sink has net ITS bond change=0 (gains Nu, loses LG)
        # so it is NOT tagged — the intermediate C.charge=-1 is still used there.
        csb_gain = set()
        for n in its.nodes():
            nd = its.nodes[n]
            chg = nd.get("charge", (0, 0))
            cr = chg[0] if isinstance(chg, (tuple, list)) else chg
            cp = chg[1] if isinstance(chg, (tuple, list)) else chg
            if cr != cp:
                continue  # Charge genuinely changes — don't exempt
            lp = nd.get("lone_pairs", (0, 0))
            lr = lp[0] if isinstance(lp, (tuple, list)) else lp
            lp2 = lp[1] if isinstance(lp, (tuple, list)) else lp
            if lr != lp2:
                continue  # LP changes — atom is an active donor/acceptor
            h = nd.get("hcount", (0, 0))
            hr = h[0] if isinstance(h, (tuple, list)) else h
            hp = h[1] if isinstance(h, (tuple, list)) else h
            if hr != hp:
                continue  # Explicit H changes — active in proton transfer
            net = sum(
                (float(ed.get("order", (0, 0))[1]) if isinstance(ed.get("order", (0, 0)), (tuple, list)) else 0.0)
                - (float(ed.get("order", (0, 0))[0]) if isinstance(ed.get("order", (0, 0)), (tuple, list)) else 0.0)
                for _, _, ed in its.edges(int(n), data=True)
            )
            if net > 0.0:
                csb_gain.add(int(n))
        if csb_gain:
            csb_gain_f = frozenset(csb_gain)
            start.graph.graph["charge_stable_bond_gain_atoms"] = csb_gain_f
            goal.graph.graph["charge_stable_bond_gain_atoms"] = csb_gain_f

        self._attach_its_arrow_plans(start, goal)
        return self._run_prepared_search(
            start=start,
            goal=goal,
            max_depth=max_depth,
            k=k,
            context_proposal_mode=context_proposal_mode,
            allow_h_ops=allow_h_ops,
            bond_only_mode=bond_only_mode,
            ignore_hcount=ignore_hcount,
            ignore_h_implicit=ignore_h_implicit,
            auto_bond_only=auto_bond_only,
            beam_width=beam_width,
            search_strategy=search_strategy,
            max_results=max_results,
        )
