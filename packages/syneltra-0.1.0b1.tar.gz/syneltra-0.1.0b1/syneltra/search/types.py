from __future__ import annotations

from dataclasses import dataclass
from typing import List, Set, Tuple

from ..core.models import StateSnapshot, Transition


@dataclass
class BeamBranch:
    """One active branch in beam/open-list search."""

    current: StateSnapshot
    states: List[StateSnapshot]
    history: List[Transition]
    seen_on_path: Set[Tuple]
    score: Tuple
    cost: float = 0.0
    logscore: float = 0.0
