"""Hückel-like π-system FMO scoring for nucleophilicity and regioselectivity.

Implements a local tight-binding Hückel model with:
- Coulomb integrals α derived from electronegativity (not hardcoded)
- Resonance integrals β scaled by atom-pair orbital overlap
- Fukui functions f⁻ (nucleophilicity), f⁺ (electrophilicity), Δf (regioselectivity)
- Proper FMO density-based weights for mechanistic pathway detection
"""

from __future__ import annotations

from functools import lru_cache
from typing import Dict, Optional, Tuple
import math

import numpy as np

from .common import clamp, element_en, scalar_numeric


class HuckelScoringMixin:
    """FMO-based π-system scoring for nucleophilicity and mechanistic regioselectivity.

    Uses Hückel tight-binding model with electronegativity-derived parameters.
    Computes Fukui functions for nucleophilic and electrophilic attack sites.
    """

    # Scaling constants for α derivation from electronegativity
    EN_C = 2.55  # Carbon electronegativity reference
    K_ALPHA = 1.5  # Scale factor: h_x = K_ALPHA * (en_x - en_C) / en_C

    def _alpha(self, atom: int) -> float:
        """Coulomb integral (site energy) derived from electronegativity.

        More electronegative atoms have lower site energy (higher ionization).
        """
        elem = self._element(atom)
        en = element_en(elem, default=self.EN_C)
        charge = self._formal_charge(atom)

        # Base: electronegativity-derived shift from carbon reference
        h_base = self.K_ALPHA * (en - self.EN_C) / self.EN_C

        # Charge effect: positive charge raises site energy (more electrophilic)
        h_charge = 0.30 * charge

        # Lone-pair context: pyrrole-like N or O (sp3-like in aromatic ring)
        # donating lone pair into ring = lower site energy (more nucleophilic)
        h_lp = 0.0
        if self._aromatic(atom) and elem in {"N", "O"}:
            if hasattr(self, "_hybridization"):
                hyb = self._hybridization(atom)
                if hyb in {"SP3", "SP"}:  # Lone pair in ring
                    h_lp = -0.15

        return h_base + h_charge + h_lp

    def _beta(self, a: int, b: int) -> float:
        """Resonance integral (bond coupling) scaled by orbital overlap.

        Smaller for C-O, C-N (high EN neighbors); similar for C-S (lower EN).
        Bond order and conjugation increase overlap.
        """
        # Base: single C-C bond
        beta_cc = -1.0

        # Atom-pair orbital contraction factor (more electronegative = smaller orbital)
        en_a = element_en(self._element(a), default=self.EN_C)
        en_b = element_en(self._element(b), default=self.EN_C)

        # f_x = 1 - 0.5 * |en_x - en_C| / en_C; ranges ~[0.5, 1.0]
        f_a = 1.0 - 0.5 * abs(en_a - self.EN_C) / self.EN_C
        f_b = 1.0 - 0.5 * abs(en_b - self.EN_C) / self.EN_C
        overlap_factor = math.sqrt(f_a * f_b)

        # Bond order factor
        edge = self._edge_data(a, b)
        order = scalar_numeric(edge.get("order", 1.0))
        conjugated = bool(edge.get("conjugated", False))

        if order >= 3.0:
            bond_factor = 1.35
        elif order >= 2.0:
            bond_factor = 1.15
        elif abs(order - 1.5) < 1e-8:
            bond_factor = 1.05
        else:
            bond_factor = 1.0

        if conjugated:
            bond_factor += 0.05

        return beta_cc * overlap_factor * bond_factor

    def _pi_electrons(self, atom: int) -> int:
        """Count π electrons contributed by atom (context-sensitive).

        Handles carbocations/carbanions, pyridine vs pyrrole nitrogens,
        furan-like oxygens, etc.
        """
        elem = self._element(atom)
        charge = self._formal_charge(atom)

        if elem == "C":
            return self._carbon_pi_electrons(charge)
        if elem == "N":
            return self._nitrogen_pi_electrons(atom, charge)
        if elem in {"O", "S"}:
            return self._chalcogen_pi_electrons(charge)
        if elem == "P":
            return self._phosphorus_pi_electrons(atom, charge)
        return 1  # Default for unknown elements

    @staticmethod
    def _carbon_pi_electrons(charge: int) -> int:
        if charge > 0:
            return 0  # Carbocation
        if charge < 0:
            return 2  # Carbanion
        return 1  # Neutral carbon

    def _nitrogen_pi_electrons(self, atom: int, charge: int) -> int:
        if charge > 0:
            return 0  # Ammonium (no lone pair for π)
        if not self._aromatic(atom):
            return 1  # Aliphatic secondary amine

        # Distinguish pyridine (lone pair out of ring) vs pyrrole (in ring).
        hyb = self._pi_hybridization(atom)
        if hyb is None:
            return 1  # Default for aromatic N without hybridization: assume pyridine
        if hyb in {"SP3", "SP"}:
            return 2  # Pyrrole-like: lone pair in ring
        return 1  # Pyridine-like: lone pair out of ring

    @staticmethod
    def _chalcogen_pi_electrons(charge: int) -> int:
        if charge > 0:
            return 1  # Oxonium/sulfonium
        return 2  # Neutral or anionic: both lone pairs

    def _phosphorus_pi_electrons(self, atom: int, charge: int) -> int:
        # Similar to N: lone pair may or may not be in π system.
        if charge > 0:
            return 0
        if not self._aromatic(atom):
            return 1

        hyb = self._pi_hybridization(atom)
        if hyb is None:
            return 1
        if hyb in {"SP3", "SP"}:
            return 2
        return 1

    def _pi_hybridization(self, atom: int) -> Optional[str]:
        if not hasattr(self, "_hybridization"):
            return None
        return self._hybridization(atom)

    @lru_cache(maxsize=None)
    def _huckel_component_data(self, component: Tuple[int, ...]) -> Optional[Dict[str, object]]:
        """Build Hückel matrix, diagonalise, compute Fukui functions.

        Stores eigenvalues, eigenvectors, Fukui densities, HOMO/LUMO indices.
        """
        if not component:
            return None

        atoms = tuple(sorted(int(a) for a in component))
        n = len(atoms)
        if n == 0:
            return None

        index = {atom: i for i, atom in enumerate(atoms)}

        # Build Hamiltonian matrix
        mat = np.zeros((n, n), dtype=float)
        for atom, i in index.items():
            mat[i, i] = self._alpha(atom)
        for atom in atoms:
            for nbr in atoms:
                if nbr <= atom or not self._has_edge(atom, nbr):
                    continue
                beta = self._beta(atom, nbr)
                ia = index[atom]
                ib = index[nbr]
                mat[ia, ib] = beta
                mat[ib, ia] = beta

        # Diagonalise
        evals, evecs = np.linalg.eigh(mat)

        # HOMO/LUMO indices
        electron_count = max(1, sum(self._pi_electrons(atom) for atom in atoms))
        homo_idx = max(0, min(n - 1, int(math.ceil(electron_count / 2.0)) - 1))
        lumo_idx = min(n - 1, homo_idx + 1)

        # Compute Fukui functions
        fukui_minus = np.zeros(n)  # f⁻(r) = sum of HOMO and HOMO-1 densities
        fukui_plus = np.zeros(n)  # f⁺(r) = LUMO density
        dual_descriptor = np.zeros(n)  # Δf(r) = f⁺ - f⁻

        # f⁻: top-2 occupied orbital densities (HOMO-1 and HOMO)
        for i in range(max(0, homo_idx - 1), homo_idx + 1):
            if i < 0:
                continue
            c_i = evecs[:, i]
            fukui_minus += c_i**2

        if electron_count > 0:
            fukui_minus /= electron_count

        # f⁺: LUMO density
        if lumo_idx < n:
            c_lumo = evecs[:, lumo_idx]
            fukui_plus = c_lumo**2

        # Δf: dual descriptor (regioselectivity)
        dual_descriptor = fukui_plus - fukui_minus

        return {
            "atoms": atoms,
            "index": index,
            "evals": evals,
            "evecs": evecs,
            "homo_idx": homo_idx,
            "lumo_idx": lumo_idx,
            "fukui_minus": fukui_minus,
            "fukui_plus": fukui_plus,
            "dual_descriptor": dual_descriptor,
        }

    def _has_huckel(self) -> bool:
        return self.mode in {"fmo_huckel", "consensus"}

    def _fukui_minus(self, atom: int) -> float:
        """Fukui f⁻(r): nucleophilicity density at atom (top-2 occupied MOs)."""
        comp = self._component_for_atom(atom)
        if comp is None:
            return 0.0
        data = self._huckel_component_data(comp)
        if data is None:
            return 0.0
        idx = data["index"][int(atom)]
        return float(data["fukui_minus"][idx])

    def _fukui_plus(self, atom: int) -> float:
        """Fukui f⁺(r): electrophilicity density at atom (LUMO)."""
        comp = self._component_for_atom(atom)
        if comp is None:
            return 0.0
        data = self._huckel_component_data(comp)
        if data is None:
            return 0.0
        idx = data["index"][int(atom)]
        return float(data["fukui_plus"][idx])

    def _dual_descriptor(self, atom: int) -> float:
        """Dual descriptor Δf(r) = f⁺ - f⁻: regioselectivity at atom.

        Positive → electrophilic site. Negative → nucleophilic site.
        """
        comp = self._component_for_atom(atom)
        if comp is None:
            return 0.0
        data = self._huckel_component_data(comp)
        if data is None:
            return 0.0
        idx = data["index"][int(atom)]
        return float(data["dual_descriptor"][idx])

    def _huckel_atom_coeff(self, atom: int, role: str) -> float:
        """Orbital coefficient: HOMO (donor) or LUMO (acceptor).

        Scaled by sqrt(component size) for comparability across π-systems.
        """
        if not self._has_huckel():
            return 0.0
        comp = self._component_for_atom(atom)
        if comp is None:
            return 0.0
        data = self._huckel_component_data(comp)
        if data is None:
            return 0.0
        idx = data["index"][int(atom)]
        vec_idx = int(data["homo_idx"] if role == "donor" else data["lumo_idx"])
        coeff = float(data["evecs"][idx, vec_idx])
        return clamp(math.sqrt(len(comp)) * coeff, -1.5, 1.5)

    def _huckel_atom_weight(self, atom: int, role: str) -> float:
        """FMO weight for nucleophilicity/electrophilicity at atom.

        Donor: Fukui f⁻ (nucleophilic sites). Acceptor: Fukui f⁺ (electrophilic sites).
        """
        if not self._has_huckel():
            return 0.0
        if role == "donor":
            return max(0.0, self._fukui_minus(atom))  # f⁻ is always non-negative
        else:
            return max(0.0, self._fukui_plus(atom))  # f⁺ is always non-negative

    def _huckel_bond_coeff(self, edge: Tuple[int, int], role: str) -> float:
        """Bond coefficient: average of atom coefficients in the pi bond."""
        a, b = int(edge[0]), int(edge[1])
        return 0.5 * (self._huckel_atom_coeff(a, role) + self._huckel_atom_coeff(b, role))

    def _huckel_bond_weight(self, edge: Tuple[int, int], role: str) -> float:
        """Pi-bond reactivity: average of endpoint Fukui densities."""
        a, b = int(edge[0]), int(edge[1])
        if role == "donor":
            return 0.5 * (self._fukui_minus(a) + self._fukui_minus(b))
        else:
            return 0.5 * (self._fukui_plus(a) + self._fukui_plus(b))

    def _phase_score_atoms(self, donor: int, acceptor: int) -> float:
        """Orbital phase overlap weighted by Fukui densities.

        Positive phase = constructive overlap (favorable). Accounts for HOMO/LUMO
        sign and magnitude of nucleophilic/electrophilic sites.
        """
        if not self._has_huckel():
            return 0.0

        c_homo = self._huckel_atom_coeff(donor, "donor")
        c_lumo = self._huckel_atom_coeff(acceptor, "acceptor")

        if abs(c_homo) < 1e-12 or abs(c_lumo) < 1e-12:
            return 0.0

        # Orbital phase: sign product (constructive = +1, destructive = -1)
        phase = math.copysign(1.0, c_homo * c_lumo)

        # Weight by Fukui densities: f⁻ at donor, f⁺ at acceptor
        f_donor = self._fukui_minus(donor)
        f_acceptor = self._fukui_plus(acceptor)

        # Magnitude of FMO participation
        fmo_product = math.sqrt(abs(f_donor * f_acceptor))

        # Scale by component size for consistency
        comp = self._component_for_atom(donor)
        size_factor = math.sqrt(len(comp)) if comp else 1.0

        return phase * fmo_product * size_factor * 6.0

    def _phase_score_bond_atom(self, edge: Tuple[int, int], acceptor: int) -> float:
        """Phase overlap for pi-bond donor to atom acceptor."""
        if not self._has_huckel():
            return 0.0

        c_bond = self._huckel_bond_coeff(edge, "donor")
        c_lumo = self._huckel_atom_coeff(acceptor, "acceptor")

        if abs(c_bond) < 1e-12 or abs(c_lumo) < 1e-12:
            return 0.0

        phase = math.copysign(1.0, c_bond * c_lumo)

        a, b = int(edge[0]), int(edge[1])
        f_bond = 0.5 * (self._fukui_minus(a) + self._fukui_minus(b))
        f_acceptor = self._fukui_plus(acceptor)

        fmo_product = math.sqrt(abs(f_bond * f_acceptor))

        comp = self._component_for_atom(a)
        size_factor = math.sqrt(len(comp)) if comp else 1.0

        return phase * fmo_product * size_factor * 6.0
