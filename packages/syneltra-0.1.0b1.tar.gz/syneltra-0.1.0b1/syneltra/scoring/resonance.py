"""Resonance and delocalization scoring terms."""

from __future__ import annotations

from syneltra.scoring.common import ELECTRONEGATIVITY, element_en


class ResonanceScoringMixin:
    """Empirical stabilization score for charge created at local sites.

    Balances specific chemistry patterns (aromatic, carbonyl) with general
    principles (conjugation depth, heteroatom electronegativity, hybridization
    context) to generalize beyond hardcoded cases.
    """

    def _resonance_site_score(self, atom: int, role: str = "acceptor") -> float:
        """Score whether a charge/radical at ``atom`` can delocalize."""

        atom = int(atom)
        if atom not in self.graph:
            return 0.0
        score = 0.0

        # Base empirical patterns (proven high-impact)
        if self._aromatic(atom):
            score += 3.0
        if self._is_carbonyl_carbon(atom):
            score += 2.5 if role == "acceptor" else 1.5

        # Conjugation: combine base effect with context bonuses
        if self._incident_conjugated(atom):
            score += 2.5
            score += self._conjugation_depth_bonus(atom)
            score += self._adjacent_heteroatom_bonus(atom, role)

        # Allylic (sp3 next to sp2 conjugation)
        if self._is_allylic(atom) and not self._aromatic(atom):
            score += 1.0

        # Benzylic (sp3 next to aromatic)
        if self._is_benzylic(atom):
            score += 1.5

        if self._is_resonance_stabilized_site(atom):
            score += 1.0

        return score

    def _conjugation_depth_bonus(self, atom: int) -> float:
        """Bonus for longer conjugation chains (better delocalization)."""
        depth = self._max_conjugation_depth(atom)
        return min(1.5, 0.3 * depth)

    def _adjacent_heteroatom_bonus(self, atom: int, role: str) -> float:
        """Bonus scaled by heteroatom electronegativity in conjugation context.

        For anions (acceptor), electron-withdrawing heteroatoms stabilize.
        For radicals, electron-donating heteroatoms stabilize.
        """
        bonus = 0.0
        for neighbor in self.graph.neighbors(atom):
            elem = self._element(neighbor)
            if elem not in ELECTRONEGATIVITY:
                continue
            if not self._incident_conjugated(neighbor):
                continue

            en = element_en(elem)
            if role == "acceptor":
                bonus += 0.4 * (en - 2.55)  # Higher EN → stabilizes anions
            else:
                bonus += 0.3 * (3.5 - en)  # Lower EN → stabilizes radicals

        return min(2.0, bonus)

    def _is_allylic(self, atom: int) -> bool:
        """sp3 carbon adjacent to sp2 in conjugation."""
        if not hasattr(self, "_hybridization"):
            return False
        if self._hybridization(atom) != "SP3":
            return False
        for neighbor in self.graph.neighbors(atom):
            if self._incident_conjugated(neighbor):
                return True
        return False

    def _is_benzylic(self, atom: int) -> bool:
        """sp3 carbon adjacent to aromatic ring."""
        if not hasattr(self, "_hybridization"):
            return False
        if self._hybridization(atom) != "SP3":
            return False
        for neighbor in self.graph.neighbors(atom):
            if self._aromatic(neighbor):
                return True
        return False

    def _max_conjugation_depth(self, atom: int) -> float:
        """Estimate conjugation chain length (capped at 3)."""
        visited = set()
        return self._conjugation_depth_recursive(atom, visited, depth=0, max_depth=3)

    def _conjugation_depth_recursive(self, atom: int, visited: set, depth: int, max_depth: int) -> float:
        """Traverse conjugation chain breadth-first, capped at max_depth."""
        if depth > max_depth or atom in visited:
            return depth
        visited.add(atom)
        if not self._incident_conjugated(atom):
            return depth
        max_d = depth
        for neighbor in self.graph.neighbors(atom):
            d = self._conjugation_depth_recursive(neighbor, visited, depth + 1, max_depth)
            max_d = max(max_d, d)
        return max_d
