"""Scoring dataclasses."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ElectronicScore:
    """Electronic ranking breakdown for one candidate move.

    ``total`` is the mode-dependent score used by the ranker. The other fields
    are component scores and are kept for diagnostics.
    """

    total: float
    fmo: float
    huckel: float
    reason: str
    hsab: float = 0.0
    resonance: float = 0.0
    pka: float = 0.0
    phase: float = 0.0
    consensus: float = 0.0
