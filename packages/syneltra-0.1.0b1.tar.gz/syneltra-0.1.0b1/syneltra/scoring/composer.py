"""Mode-dependent electronic score composition for mechanistic pathways.

Rebalanced weights prioritize FMO theory (Hückel) and HSAB over heuristics,
with regioselectivity guidance from dual descriptor.
"""

from __future__ import annotations

from .common import bounded
from .models import ElectronicScore


class ElectronicScoreComposerMixin:
    """Compose FMO, Hückel, HSAB, resonance, pKa, and regioselectivity terms.

    For mechanistic pathway detection: Hückel (true MO) and HSAB (acid-base)
    are weighted more heavily than FMO heuristics. Dual descriptor guides
    regioselectivity within conjugated systems.
    """

    MODE_ALIASES = {
        "off": "none",
        "false": "none",
        "disabled": "none",
        "huckel": "fmo_huckel",
        "fmo_huckel_hsab": "consensus",
        "fmo_huckel_hsba": "consensus",
        "fmo_hsab_huckel": "consensus",
        "fmo_hsba_huckel": "consensus",
        "hsab": "fmo_hsab",
        "hsba": "fmo_hsab",
        "fmo_hsba": "fmo_hsab",
        "all": "consensus",
    }

    def _compose_score(
        self,
        fmo: float,
        huckel: float,
        hsab: float,
        reason: str,
        *,
        resonance: float = 0.0,
        pka: float = 0.0,
        phase: float = 0.0,
    ) -> ElectronicScore:
        """Compose component scores into total and consensus via mode-dependent weighting.

        Modes:
        - "none": no scoring (all zeros)
        - "fmo": FMO heuristics only
        - "fmo_huckel": FMO + true MO theory (Hückel)
        - "fmo_hsab": FMO + hard-soft acid-base
        - "consensus": all components, rebalanced for mechanistic guidance

        Consensus weights (for mechanistic pathway detection):
        - huckel (true MO): 0.32 (most physics-based)
        - fmo (generalised): 0.30 (broadened element coverage)
        - hsab (HSAB): 0.28 (smoothed thresholds, reduced carbonyl bias)
        - resonance: stabilization bonus
        - pka: proton transfer favorability
        - phase: orbital phase overlap
        """
        mode = self.mode
        if mode == "none":
            total = 0.0
            consensus = 0.0
        elif mode == "fmo":
            total = fmo
            consensus = fmo
        elif mode == "fmo_huckel":
            # Hückel (true MO theory) takes precedence over FMO heuristics
            total = bounded(fmo, 28.0) + bounded(huckel, 12.0)
            consensus = total
        elif mode == "fmo_hsab":
            # HSAB (acid-base) takes precedence over FMO heuristics
            total = bounded(fmo, 28.0) + bounded(hsab, 14.0)
            consensus = total
        elif mode == "consensus":
            # Rebalanced consensus: physics > acid-base > heuristics
            # Regioselectivity bonus from dual descriptor if available
            regio_bonus = 0.0
            if hasattr(self, "_dual_descriptor"):
                # Add regioselectivity reward if available (non-zero dual descriptor)
                # This would be applied per-atom but is computed in _bond_attack_score
                regio_bonus = 0.0  # Applied contextually via _pair_compatibility

            consensus = (
                0.32 * bounded(huckel, 12.0)  # Hückel: true π-system MO theory
                + 0.28 * bounded(hsab, 14.0)  # HSAB: acid-base favorability (thresholds smoothed)
                + 0.30 * bounded(fmo, 28.0)  # FMO: generalised donor/acceptor
                + self.resonance_scale * bounded(resonance, 10.0)
                + self.pka_scale * bounded(pka, 20.0)
                + self.phase_scale * bounded(phase, 8.0)
                + regio_bonus
            )
            total = consensus
        else:
            # Unknown modes degrade gracefully to FMO
            total = fmo
            consensus = fmo

        return ElectronicScore(
            total=float(total),
            fmo=float(fmo),
            huckel=float(huckel),
            hsab=float(hsab),
            resonance=float(resonance),
            pka=float(pka),
            phase=float(phase),
            consensus=float(consensus),
            reason=reason,
        )
