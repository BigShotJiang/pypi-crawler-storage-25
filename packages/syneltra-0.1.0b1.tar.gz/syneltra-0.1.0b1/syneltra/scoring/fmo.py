"""FMO-like donor/acceptor scoring for mechanistic pathway detection.

Enhanced with electronegativity-based scoring and Fukui function awareness
for improved mechanistic pathway guidance.
"""

from __future__ import annotations

from typing import Tuple

from .common import clamp, element_en

# Leaving-group base scores keyed by normalised element symbol.
# Values represent departure-ease as an anion/neutral, calibrated to
# conjugate-acid pKa ordering (lower pKaH → higher score).
# Anything not listed uses a softness/hardness formula fallback.
_LG_BASE_SCORE: dict = {
    # ── Halogens (best → worst LG as anions) ──
    "AT": 16.0,  # astatide  – softest halogen
    "I": 15.0,  # iodide    – benchmark LG
    "BR": 13.0,  # bromide
    "CL": 10.0,  # chloride
    "F": 3.0,  # fluoride  – hard anion, poor LG
    # ── Chalcogens ──
    "PO": 10.0,  # polonide  – very soft heavy chalcogen
    "TE": 11.0,  # telluride – excellent LG
    "SE": 9.0,  # selenide
    "S": 7.0,  # thiolate
    "O": 5.0,  # hydroxide (neutral O → water when protonated)
    # ── Pnictogens ──
    "BI": 7.0,  # bismuthide – soft heavy metal
    "SB": 6.0,  # stibide
    "AS": 4.0,  # arsenide
    "P": 2.0,  # phosphide / phosphonate ester
    "N": 1.0,  # amide     – poor LG (NH₃ pKa≈38)
    # ── Carbon group ──
    "PB": 5.0,  # plumbide  – soft
    "SN": 4.0,  # stannide  – organotin LG (Stille coupling)
    "GE": 1.0,  # germanide
    "SI": -1.0,  # silyl     – rarely leaves as Si⁻
    "C": -8.0,  # carbanion – worst LG
    # ── Boron / Aluminum group ──
    "TL": 6.0,  # thallide  – very soft
    "IN": 2.0,  # indide
    "GA": 0.0,
    "AL": -1.0,  # aluminide – Lewis acid; Al⁻ very poor LG
    "B": -3.0,  # boride    – Lewis acid; B⁻ very poor LG
    # ── Transition metals as organometallic LG ──
    "HG": 8.0,  # mercuride – demercuration
    "AU": 7.0,  # auride    – very soft
    "PT": 5.0,  # platinide
    "PD": 4.0,  # palladide – reductive elimination
    "AG": 4.0,  # argentide
    "CD": 3.0,  # cadmide
    "CU": 3.0,  # cupride   – cuprate coupling
    "ZN": 1.0,  # zincide   – Reformatsky
    # ── Alkali / alkaline earth (organometallic) ──
    "H": -5.0,  # hydride   – H⁻ pKa≈36
    "LI": -4.0,  # lithide   – organolithium
    "NA": -5.0,
    "K": -6.0,
    "MG": -3.0,  # Grignard
    "CA": -3.0,
}

# Lewis-acid acceptor elements for heteroatom donor pairing.
_LEWIS_ACID_ELEMS: frozenset = frozenset(
    {
        "C",
        "B",
        "AL",
        "SI",
        "GE",
        "SN",
        "P",
        "AS",
        "FE",
        "CU",
        "ZN",
        "MG",
        "TI",
        "NI",
        "CO",
    }
)


class FMOScoringMixin:
    """Frontier-orbital-inspired donor/acceptor scoring for mechanistic pathways.

    Uses electronegativity, formal/partial charges, and Fukui-aware weights
    to identify nucleophilic and electrophilic sites.
    """

    def _estimate_lp_donor(self, atom: int) -> float:
        """Estimate nucleophilicity of a lone-pair donor.

        Score increases with: lone pairs, softness, negative charge,
        electron-donating nature (low EN).
        """
        atom = int(atom)
        lp = self._lone_pairs(atom)
        if lp <= 0:
            return 0.0

        elem = self._element(atom)
        en = element_en(elem)
        formal = self._formal_charge(atom)
        partial = self._partial_charge(atom)
        softness = self._atom_softness(atom)

        # Base nucleophilicity from element type and electronegativity
        # Less electronegative atoms are better nucleophiles
        base_en_score = 25.0 - (en - 2.0) * 8.0

        # Lone pair contribution: up to 3 lone pairs
        lp_score = 5.0 * min(lp, 3.0)

        # Formal charge: negative charge increases nucleophilicity
        charge_score = 9.0 * max(0.0, -formal) - 8.0 * max(0.0, formal)

        # Partial charge: electron density at atom
        partial_score = clamp(-20.0 * partial, -6.0, 7.0)

        # Softness bonus: polarizability aids nucleophilicity
        softness_score = 3.5 * softness

        total = base_en_score + lp_score + charge_score + partial_score + softness_score

        # Hybridization context: sp3 heteroatoms are better nucleophiles
        if hasattr(self, "_hybridization"):
            hyb = self._hybridization(atom)
            if hyb == "SP3" and elem in {"O", "N", "S"}:
                total += 2.5
            elif hyb == "SP2" and elem in {"O", "N"}:
                total -= 1.5  # sp2 less nucleophilic than sp3

        # Aromaticity and conjugation reduce nucleophilicity (delocalization)
        if self._aromatic(atom):
            total -= 4.0
        elif self._incident_conjugated(atom):
            total -= 2.5

        # Fukui f- bonus (if Hückel is available): nucleophilicity from MO
        if hasattr(self, "_fukui_minus"):
            fukui_minus = self._fukui_minus(atom)
            total += 6.0 * fukui_minus

        return total

    def _estimate_bond_donor(self, a: int, b: int) -> float:
        """Estimate π-bond reactivity as a nucleophile.

        Score increases with: bond order, conjugation, softness,
        negative character of the bond.
        """
        a, b = int(a), int(b)
        if not self._has_edge(a, b):
            return 0.0

        order = self._bond_order(a, b)
        edge = self._edge_data(a, b)
        score = 2.0 + 4.0 * min(order, 3.0)

        # Pi bonds are strong donors
        if self._is_pi_edge(a, b):
            score += 10.0
            if bool(edge.get("conjugated", False)):
                score += 4.0

        # Charge effects: electron density on the bond
        partial_avg = (self._partial_charge(a) + self._partial_charge(b)) / 2.0
        formal_avg = (self._formal_charge(a) + self._formal_charge(b)) / 2.0

        score += 4.0 * max(0.0, -partial_avg)
        score += 2.5 * max(0.0, -formal_avg)

        # Bond softness: polarizable bonds are better donors
        score += 2.5 * self._edge_softness((a, b))

        # Heteroatom bonus: C-N, C-O, C-S bonds more reactive than C-C
        if self._is_hetero(a) or self._is_hetero(b):
            score += 1.5

        # Fukui bond density bonus (if Hückel available)
        if hasattr(self, "_huckel_bond_weight"):
            fukui_bond = self._huckel_bond_weight((a, b), "donor")
            score += 8.0 * fukui_bond

        return score

    def _estimate_acceptor(self, atom: int) -> float:
        """Estimate electrophilicity of an electron acceptor.

        Score increases with: formal positive charge, partial positive charge,
        electron-withdrawing nature (high EN), carbocation character.
        """
        atom = int(atom)
        elem = self._element(atom)
        formal = self._formal_charge(atom)
        partial = self._partial_charge(atom)
        hardness = self._atom_hardness(atom)
        # en = element_en(elem)

        # Formal charge: strong indicator of electrophilicity
        score = 12.0 * max(0.0, formal)

        # Partial charge: secondary electrostatic effect
        score += clamp(24.0 * partial, -5.0, 10.0)

        # Carbon baseline: carbons are intrinsic acceptors
        if elem == "C":
            score += 5.0

        # Carbonyl carbon: one of the strongest electrophiles
        if self._is_carbonyl_carbon(atom):
            score += 12.0

        # Hybridization: sp and sp2 carbons more electrophilic
        if hasattr(self, "_hybridization"):
            hyb = self._hybridization(atom)
            if hyb in {"SP", "SP2"}:
                score += 2.5

        # Leaving group neighbor: good leaving groups activate the center
        if self._has_leaving_group_neighbor(atom):
            score += 8.0

        # Heteroatoms: neutral heteroatoms are usually poor acceptors
        if self._is_hetero(atom) and formal <= 0:
            score -= 6.0

        # Hardness: hard, polarized centers are good hard acceptors
        score += 2.0 * hardness

        # Fukui f+ bonus (if Hückel available): electrophilicity from MO
        if hasattr(self, "_fukui_plus"):
            fukui_plus = self._fukui_plus(atom)
            score += 8.0 * fukui_plus

        return score

    def _estimate_leaving_group(self, atom: int) -> float:
        """Estimate leaving group ability of an atom.

        Better leaving groups: halogens > heteroatoms > hydrocarbons.
        Softness and negative charge improve leaving group ability.
        """
        atom = int(atom)
        elem = self._element(atom)
        formal = self._formal_charge(atom)
        partial = self._partial_charge(atom)
        softness = self._atom_softness(atom)

        # Element-specific base scores from comprehensive periodic-table table.
        # Fallback formula uses softness/hardness for elements not listed.
        if elem in _LG_BASE_SCORE:
            base_score = _LG_BASE_SCORE[elem]
        else:
            en = element_en(elem)
            hardness = self._atom_hardness(atom)
            base_score = 10.0 * softness - 4.0 * hardness + 2.0 * (2.55 - en)
            base_score = clamp(base_score, -6.0, 12.0)

        # Negative charge (anion) is a good leaving group
        base_score += 7.0 * max(0.0, -formal)

        # Partial negative charge aids departure
        base_score += clamp(-10.0 * partial, -4.0, 4.0)

        # Softness (polarizability) enables easy departure
        base_score += 5.0 * softness

        return base_score

    def _pair_compatibility(self, donor: int, acceptor: int) -> float:
        """Score donor-acceptor pair for nucleophilic attack compatibility.

        Rewards: O/N/S donors attacking C; carbonyl acceptors;
        sites with leaving groups; polarity matching.
        """
        donor = int(donor)
        acceptor = int(acceptor)
        score = 0.0

        acc_el = self._element(acceptor)

        # Heteroatom LP donor attacks any Lewis-acid center (C, B, Al, Si, metals…)
        if self._lone_pairs(donor) > 0 and self._is_hetero(donor):
            if acc_el in _LEWIS_ACID_ELEMS or self._formal_charge(acceptor) > 0:
                score += 5.0

        # Carbonyl carbon as acceptor: strong preference
        if self._is_carbonyl_carbon(acceptor):
            score += 5.0

        # Leaving group presence activates the acceptor
        if self._has_leaving_group_neighbor(acceptor):
            score += 6.0

        # Electrostatic polarity: positive acceptor attracts negative donor
        acc_partial = self._partial_charge(acceptor)
        don_partial = self._partial_charge(donor)
        formal_diff = self._formal_charge(acceptor) - self._formal_charge(donor)

        polarity = (acc_partial - don_partial) + 0.25 * formal_diff
        score += clamp(10.0 * polarity, -5.0, 6.0)

        # Regioselectivity bonus: use dual descriptor if available
        if hasattr(self, "_dual_descriptor"):
            dual_desc = self._dual_descriptor(acceptor)
            score += 3.0 * max(dual_desc, 0.0)  # Positive Δf = electrophilic

        return score

    def _bond_acceptor_projection(self, src_edge: Tuple[int, int], acceptor: int) -> float:
        """Score how well the π-bond orients toward the acceptor.

        The acceptor's electrostatic pull is projected onto the π-bond.
        """
        a, b = int(src_edge[0]), int(src_edge[1])
        acceptor = int(acceptor)

        # Electrostatic attraction from acceptor to bond midpoint
        midpoint_partial = (self._partial_charge(a) + self._partial_charge(b)) / 2.0
        partial_pull = self._partial_charge(acceptor) - midpoint_partial

        score = clamp(10.0 * partial_pull, -4.0, 6.0)

        # Formal charge effects (stronger than partial)
        formal_pull = self._formal_charge(acceptor) - (self._formal_charge(a) + self._formal_charge(b)) / 2.0
        score += clamp(4.0 * formal_pull, -3.0, 3.0)

        return score
