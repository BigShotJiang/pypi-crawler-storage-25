"""Orchestrator for modular electronic transition scoring."""

from __future__ import annotations

from typing import Optional, Tuple

import networkx as nx

try:
    from ..core.models import Transition
except Exception:  # pragma: no cover - standalone ranker package fallback
    from types import SimpleNamespace as Transition

from .common import BASE_HARDNESS, BASE_SOFTNESS, ELECTRONEGATIVITY, clamp
from .composer import ElectronicScoreComposerMixin
from .descriptors import GraphDescriptorMixin
from .fmo import FMOScoringMixin
from .hsab import HSABScoringMixin
from .huckel import HuckelScoringMixin
from .models import ElectronicScore
from .pka import PkaScoringMixin
from .resonance import ResonanceScoringMixin


class ElectronicTransitionScorer(
    GraphDescriptorMixin,
    FMOScoringMixin,
    HuckelScoringMixin,
    HSABScoringMixin,
    ResonanceScoringMixin,
    PkaScoringMixin,
    ElectronicScoreComposerMixin,
):
    """Graph-local empirical electronic scorer for transition guidance.

    The component implementation is intentionally split across files:

    - :mod:`syneltra.scoring.fmo`: donor/acceptor and polarity terms
    - :mod:`syneltra.scoring.huckel`: local π-system coefficients
    - :mod:`syneltra.scoring.hsab`: hard-soft acid-base compatibility
    - :mod:`syneltra.scoring.resonance`: delocalization stabilization
    - :mod:`syneltra.scoring.pka`: proton-transfer proxy
    - :mod:`syneltra.scoring.composer`: score-mode composition

    The scorer remains lightweight and does not run quantum chemistry.
    """

    BASE_HARDNESS = BASE_HARDNESS
    BASE_SOFTNESS = BASE_SOFTNESS
    ELECTRONEGATIVITY = ELECTRONEGATIVITY

    def __init__(self, graph: nx.Graph, mode: str = "consensus") -> None:
        self.graph = graph
        raw_mode = str(mode or "consensus").lower()
        self.mode = self.MODE_ALIASES.get(raw_mode, raw_mode)
        self.resonance_scale = float(graph.graph.get("resonance_score_scale", 0.18))
        self.pka_scale = float(graph.graph.get("pka_score_scale", 0.20))
        self.phase_scale = float(graph.graph.get("phase_score_scale", 0.16))

    def _lp_attack_score(self, donor: int, acceptor: int) -> ElectronicScore:
        fmo = (
            self._estimate_lp_donor(donor)
            + self._estimate_acceptor(acceptor)
            + self._pair_compatibility(donor, acceptor)
        )
        huckel = 0.0
        phase = 0.0
        if self._has_huckel():
            d_homo = self._huckel_atom_weight(donor, "donor")
            a_lumo = self._huckel_atom_weight(acceptor, "acceptor")
            huckel += 7.0 * a_lumo
            if self._incident_conjugated(donor):
                huckel += 3.0 * d_homo
            huckel += 5.0 * d_homo * a_lumo
            phase = self._phase_score_atoms(donor, acceptor)
            # Regioselectivity bonus: reward electrophilic sites (positive Δf)
            dual_desc = self._dual_descriptor(acceptor)
            if dual_desc > 0.05:
                huckel += 3.0 * dual_desc
        hsab = self._hsab_pair_score(donor, acceptor) if self._has_hsab() else 0.0
        resonance = self._resonance_site_score(acceptor, role="acceptor") + 0.5 * self._resonance_site_score(
            donor, role="donor"
        )
        return self._compose_score(
            fmo,
            huckel,
            hsab,
            reason=f"LP donor {int(donor)} -> electrophile {int(acceptor)}",
            resonance=resonance,
            phase=phase,
        )

    def _pick_bond_attack_acceptor(
        self,
        src_edge: Tuple[int, int],
        dst_edge: Tuple[int, int],
        shared_atom: Optional[int],
    ) -> int:
        src_set = {int(src_edge[0]), int(src_edge[1])}
        dst_atoms = [int(dst_edge[0]), int(dst_edge[1])]
        if shared_atom is not None and int(shared_atom) in dst_atoms:
            other = dst_atoms[0] if dst_atoms[1] == int(shared_atom) else dst_atoms[1]
            return int(other)
        fresh = [atom for atom in dst_atoms if atom not in src_set]
        if fresh:
            return int(fresh[0])
        return max(dst_atoms, key=lambda atom: self._estimate_acceptor(atom))

    def _bond_attack_score(
        self,
        src_edge: Tuple[int, int],
        dst_edge: Tuple[int, int],
        *,
        shared_atom: Optional[int] = None,
    ) -> ElectronicScore:
        acceptor = self._pick_bond_attack_acceptor(src_edge, dst_edge, shared_atom)
        fmo = (
            self._estimate_bond_donor(*src_edge)
            + self._estimate_acceptor(acceptor)
            + self._bond_acceptor_projection(src_edge, acceptor)
        )
        huckel = 0.0
        phase = 0.0
        if self._has_huckel():
            edge_homo = self._huckel_bond_weight(src_edge, "donor")
            acc_lumo = self._huckel_atom_weight(acceptor, "acceptor")
            huckel += 8.0 * edge_homo
            huckel += 6.0 * acc_lumo
            huckel += 7.0 * edge_homo * acc_lumo
            phase = self._phase_score_bond_atom(src_edge, acceptor)
            # Regioselectivity bonus: reward sites with positive dual descriptor
            dual_desc = self._dual_descriptor(acceptor)
            if dual_desc > 0.05:
                huckel += 4.0 * dual_desc
        hsab = self._hsab_bond_attack_score(src_edge, acceptor) if self._has_hsab() else 0.0
        resonance = (
            self._resonance_site_score(src_edge[0], role="donor")
            + self._resonance_site_score(src_edge[1], role="donor")
            + self._resonance_site_score(acceptor, role="acceptor")
        )
        return self._compose_score(
            fmo,
            huckel,
            hsab,
            reason=f"bond {int(src_edge[0])}-{int(src_edge[1])} attacks site {acceptor}",
            resonance=resonance,
            phase=phase,
        )

    def _bond_cleavage_score(self, src_edge: Tuple[int, int], sink: int) -> ElectronicScore:
        a, b = int(src_edge[0]), int(src_edge[1])
        sink = int(sink)
        other = b if sink == a else a
        fmo = self._estimate_leaving_group(sink)
        fmo += clamp(10.0 * (self._partial_charge(other) - self._partial_charge(sink)), -4.0, 4.0)
        if self._has_edge(a, b) and self._bond_order(a, b) >= 1.0:
            fmo += 2.0
        if self._is_pi_edge(a, b) and self._is_hetero(sink):
            fmo += 4.0
        huckel = 0.0
        phase = 0.0
        if self._has_huckel():
            if self._is_pi_edge(a, b):
                # π-bond breaks: π-electron HOMO drives the cleavage.
                # Score how electron-rich the bond is and how well the
                # leaving group's π-HOMO absorbs the electrons.
                edge_homo = self._huckel_bond_weight(src_edge, "donor")
                sink_homo = self._huckel_atom_weight(sink, "donor")
                huckel += 4.0 * edge_homo
                huckel += 2.0 * sink_homo
                phase = self._phase_score_bond_atom(src_edge, sink)
            else:
                # σ-bond breaks (SN1-type ionisation, protonated LG departure).
                # The σ-electrons have no π-HOMO to score, but the forming
                # cation ('other') may be stabilised by an adjacent π-system:
                # f⁺(other) = LUMO density at the cation centre.
                # f⁻(sink)  = HOMO density at the LG if it is conjugated.
                other_lumo = self._huckel_atom_weight(other, "acceptor")
                sink_homo = self._huckel_atom_weight(sink, "donor")
                huckel += 6.0 * other_lumo
                huckel += 2.0 * sink_homo
        hsab = self._hsab_cleavage_score(src_edge, sink) if self._has_hsab() else 0.0
        resonance = self._resonance_site_score(sink, role="donor") + 0.5 * self._resonance_site_score(
            other, role="acceptor"
        )
        return self._compose_score(
            fmo,
            huckel,
            hsab,
            reason=f"bond {a}-{b} cleaves to lone pair on {sink}",
            resonance=resonance,
            phase=phase,
        )

    def score_lp_to_bond(self, donor: int, acceptor: int) -> ElectronicScore:
        return self._lp_attack_score(donor, acceptor)

    def score_bond_to_bond(
        self,
        src_edge: Tuple[int, int],
        dst_edge: Tuple[int, int],
        *,
        shared_atom: Optional[int] = None,
    ) -> ElectronicScore:
        return self._bond_attack_score(src_edge, dst_edge, shared_atom=shared_atom)

    def score_bond_to_lp(self, src_edge: Tuple[int, int], sink: int) -> ElectronicScore:
        return self._bond_cleavage_score(src_edge, sink)

    def score_transition(self, transition: Transition) -> float:
        kind = str(transition.kind)
        if kind == "LP-/B+" and len(transition.src) == 1 and len(transition.dst) == 2:
            donor = int(transition.src[0])
            acceptor = next((int(a) for a in transition.dst if int(a) != donor), donor)
            return self.score_lp_to_bond(donor, acceptor).total
        if kind == "B-/B+" and len(transition.src) == 2 and len(transition.dst) == 2:
            return self.score_bond_to_bond(
                (int(transition.src[0]), int(transition.src[1])),
                (int(transition.dst[0]), int(transition.dst[1])),
                shared_atom=transition.data.get("shared_atom"),
            ).total
        if kind == "B-/LP+" and len(transition.src) == 2 and len(transition.dst) == 1:
            return self.score_bond_to_lp(
                (int(transition.src[0]), int(transition.src[1])),
                int(transition.dst[0]),
            ).total
        if kind == "LP-/H+" and len(transition.src) == 1 and len(transition.dst) == 1:
            return self._proton_transfer_score(
                int(transition.src[0]),
                int(transition.dst[0]),
            ).total
        if kind == "H-/LP+" and len(transition.src) == 1 and len(transition.dst) == 1:
            # Reverse proton movement: prefer loss from acidic sites.
            return self._proton_transfer_score(
                int(transition.dst[0]),
                int(transition.src[0]),
            ).total
        return 0.0
