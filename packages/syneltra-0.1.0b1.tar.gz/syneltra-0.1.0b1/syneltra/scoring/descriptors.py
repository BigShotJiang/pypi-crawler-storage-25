"""Reusable graph-local descriptor helpers for electronic scoring."""

from __future__ import annotations

from functools import lru_cache
from typing import Dict, Optional, Tuple

import networkx as nx

from .common import (
    BASE_HARDNESS,
    BASE_SOFTNESS,
    ELECTRONEGATIVITY,
    clamp,
    norm_element,
    scalar_bool,
    scalar_numeric,
)


class GraphDescriptorMixin:
    """Mixin providing graph attribute and local chemistry descriptors.

    Subclasses are expected to define ``self.graph`` as a :class:`networkx.Graph`.
    """

    graph: nx.Graph

    @staticmethod
    def _norm_element(value: object) -> str:
        return norm_element(value)

    def _element(self, atom: int) -> str:
        return self._norm_element(self.graph.nodes[int(atom)].get("element", ""))

    def _formal_charge(self, atom: int) -> float:
        return scalar_numeric(self.graph.nodes[int(atom)].get("charge", 0.0))

    def _partial_charge(self, atom: int) -> float:
        return scalar_numeric(self.graph.nodes[int(atom)].get("partial_charge", 0.0))

    def _lone_pairs(self, atom: int) -> float:
        return scalar_numeric(self.graph.nodes[int(atom)].get("lone_pairs", 0.0))

    def _hybridization(self, atom: int) -> str:
        return self._norm_element(self.graph.nodes[int(atom)].get("hybridization", ""))

    def _aromatic(self, atom: int) -> bool:
        return scalar_bool(self.graph.nodes[int(atom)].get("aromatic", False))

    def _has_edge(self, a: int, b: int) -> bool:
        return self.graph.has_edge(int(a), int(b))

    def _bond_order(self, a: int, b: int) -> float:
        if not self._has_edge(a, b):
            return 0.0
        return scalar_numeric(self.graph.edges[int(a), int(b)].get("order", 0.0))

    def _edge_data(self, a: int, b: int) -> Dict[str, object]:
        if not self._has_edge(a, b):
            return {}
        return dict(self.graph.edges[int(a), int(b)])

    def _is_hetero(self, atom: int) -> bool:
        return self._element(atom) in {"N", "O", "S", "P", "F", "CL", "BR", "I"}

    def _is_halogen(self, atom: int) -> bool:
        return self._element(atom) in {"F", "CL", "BR", "I"}

    def _is_pi_edge(self, a: int, b: int) -> bool:
        if not self._has_edge(a, b):
            return False
        edge = self._edge_data(a, b)
        order = scalar_numeric(edge.get("order", 0.0))
        if order >= 2.0 or abs(order - 1.5) < 1e-8:
            return True
        if bool(edge.get("conjugated", False)):
            return True
        return self._norm_element(edge.get("bond_type", "")) in {
            "DOUBLE",
            "TRIPLE",
            "AROMATIC",
        }

    def _incident_conjugated(self, atom: int) -> bool:
        atom = int(atom)
        if atom not in self.graph:
            return False
        for nbr in self.graph.neighbors(atom):
            if self._is_pi_edge(atom, int(nbr)):
                return True
        return False

    def _conjugated_neighbors(self, atom: int) -> Tuple[int, ...]:
        atom = int(atom)
        if atom not in self.graph:
            return tuple()
        return tuple(sorted(int(nbr) for nbr in self.graph.neighbors(atom) if self._is_pi_edge(atom, int(nbr))))

    def _is_resonance_stabilized_site(self, atom: int) -> bool:
        """Return whether charge/radical character at atom can delocalize."""

        atom = int(atom)
        if atom not in self.graph:
            return False
        if self._aromatic(atom) or self._incident_conjugated(atom):
            return True
        for nbr in self.graph.neighbors(atom):
            nbr = int(nbr)
            if self._is_pi_edge(atom, nbr):
                return True
            if self._element(nbr) in {"O", "N", "S", "P"} and self._bond_order(atom, nbr) >= 1.0:
                return True
        return False

    def _is_carbonyl_carbon(self, atom: int) -> bool:
        atom = int(atom)
        if atom not in self.graph or self._element(atom) != "C":
            return False
        for nbr in self.graph.neighbors(atom):
            nbr = int(nbr)
            if self._element(nbr) in {"O", "N", "S"} and self._bond_order(atom, nbr) >= 2.0:
                return True
        return False

    def _has_leaving_group_neighbor(self, atom: int) -> bool:
        atom = int(atom)
        if atom not in self.graph:
            return False
        for nbr in self.graph.neighbors(atom):
            nbr = int(nbr)
            if self._is_halogen(nbr):
                return True
            # Protonated heteroatom (OH2+, NR3+, SR2+) departs as neutral molecule
            if self._is_hetero(nbr) and self._formal_charge(nbr) > 0:
                return True
        return False

    def _electronegativity(self, atom: int) -> float:
        return ELECTRONEGATIVITY.get(self._element(atom), 2.55)

    def _atom_hardness(self, atom: int) -> float:
        atom = int(atom)
        elem = self._element(atom)
        hard = BASE_HARDNESS.get(elem, 0.50)
        charge = self._formal_charge(atom)
        hyb = self._hybridization(atom)

        hard += 0.12 * max(0.0, charge)
        hard -= 0.10 * max(0.0, -charge)
        if hyb == "SP":
            hard += 0.10
        elif hyb == "SP2":
            hard += 0.04
        elif hyb == "SP3":
            hard -= 0.02
        if self._aromatic(atom) or self._incident_conjugated(atom):
            hard -= 0.06
        return clamp(hard, 0.05, 1.05)

    def _atom_softness(self, atom: int) -> float:
        atom = int(atom)
        elem = self._element(atom)
        soft = BASE_SOFTNESS.get(elem, 0.45)
        charge = self._formal_charge(atom)
        soft += 0.12 * max(0.0, -charge)
        soft -= 0.08 * max(0.0, charge)
        if self._aromatic(atom) or self._incident_conjugated(atom):
            soft += 0.08
        return clamp(soft, 0.05, 1.10)

    def _edge_hardness(self, edge: Tuple[int, int]) -> float:
        a, b = int(edge[0]), int(edge[1])
        return 0.5 * (self._atom_hardness(a) + self._atom_hardness(b))

    def _edge_softness(self, edge: Tuple[int, int]) -> float:
        a, b = int(edge[0]), int(edge[1])
        soft = 0.5 * (self._atom_softness(a) + self._atom_softness(b))
        if self._is_pi_edge(a, b):
            soft += 0.10
        return clamp(soft, 0.05, 1.10)

    def _pi_nodes(self) -> Tuple[int, ...]:
        nodes = set()
        for a, b in self.graph.edges():
            a = int(a)
            b = int(b)
            if self._is_pi_edge(a, b):
                nodes.add(a)
                nodes.add(b)
        return tuple(sorted(nodes))

    @lru_cache(maxsize=None)
    def _pi_components(self) -> Tuple[Tuple[int, ...], ...]:
        pi_graph = nx.Graph()
        for a, b in self.graph.edges():
            a = int(a)
            b = int(b)
            if self._is_pi_edge(a, b):
                pi_graph.add_edge(a, b)
        if pi_graph.number_of_nodes() == 0:
            return tuple()
        return tuple(tuple(sorted(comp)) for comp in nx.connected_components(pi_graph))

    def _component_for_atom(self, atom: int) -> Optional[Tuple[int, ...]]:
        atom = int(atom)
        for comp in self._pi_components():
            if atom in comp:
                return comp
        return None
