"""HSAB compatibility heuristics for mechanistic pathway detection.

Enhanced with context-sensitive hard/soft classification and pi vs sigma
bond differentiation for better regioselectivity guidance.
"""

from __future__ import annotations

from typing import Tuple

from .common import clamp


class HSABScoringMixin:
    """Hard-soft acid-base compatibility for electron flow guidance.

    Scores hard-hard and soft-soft pairings. Incorporates pi/sigma context,
    formal charge effects, and regioselectivity via dual descriptor.
    """

    # Valid modes for HSAB scoring
    VALID_HSAB_MODES = {"fmo_hsab", "fmo_huckel", "consensus"}

    def _has_hsab(self) -> bool:
        return self.mode in self.VALID_HSAB_MODES

    def _hsab_pair_score(self, donor: int, acceptor: int) -> float:
        """Score hard-soft compatibility for lone-pair donors.

        Hard-hard pairing (N/O + carbocation) and soft-soft pairing (S + soft Lewis acid)
        are both favorable. Opposite pairs are penalized.
        """
        donor = int(donor)
        acceptor = int(acceptor)
        d_hard = self._atom_hardness(donor)
        a_hard = self._atom_hardness(acceptor)
        d_soft = self._atom_softness(donor)
        a_soft = self._atom_softness(acceptor)

        # HSAB matching: either hard-hard or soft-soft is favorable
        hard_match = 1.0 - abs(d_hard - a_hard)
        soft_match = 1.0 - abs(d_soft - a_soft)
        score = 10.0 * clamp(max(hard_match, soft_match), 0.0, 1.0)

        # Ionic pairing: opposite charges strongly favorable
        charge_product = self._formal_charge(donor) * self._formal_charge(acceptor)
        if charge_product < 0:
            score += 6.0  # Attractive
        elif charge_product > 0:
            score -= 6.0  # Repulsive

        # Soft-soft synergy: smooth product replaces hard threshold
        score += 4.0 * min(1.0, (d_soft * a_soft) / (0.68 * 0.60))

        # Hard-hard synergy: smooth product replaces hard threshold
        score += 3.0 * min(1.0, (d_hard * a_hard) / (0.68 * 0.68))

        # Carbonyl carbon is a hard acceptor; reduce from 3.5 to cut triple-stacking
        if self._is_carbonyl_carbon(acceptor):
            score += 2.0 * min(1.0, d_hard / 0.58)

        # Regioselectivity: use dual descriptor if available
        if hasattr(self, "_dual_descriptor"):
            dual_desc = self._dual_descriptor(acceptor)
            if dual_desc > 0.1:  # Electrophilic site
                score += 2.0 * dual_desc

        return score

    def _hsab_bond_attack_score(self, src_edge: Tuple[int, int], acceptor: int) -> float:
        """Score HSAB compatibility for pi-bond donors attacking an acceptor.

        Pi-bond donor softness matches acceptor softness. Carbonyls reward
        hard donors. Regioselectivity includes acceptor site preference.
        """
        a, b = int(src_edge[0]), int(src_edge[1])
        acceptor = int(acceptor)

        e_soft = self._edge_softness(src_edge)
        e_hard = self._edge_hardness(src_edge)
        a_soft = self._atom_softness(acceptor)
        a_hard = self._atom_hardness(acceptor)

        # HSAB matching for the pi-bond as a whole
        soft_match = 1.0 - abs(e_soft - a_soft)
        hard_match = 1.0 - abs(e_hard - a_hard)
        score = 9.0 * clamp(max(soft_match, hard_match), 0.0, 1.0)

        # Pi bonds are soft donors; reward soft acceptors
        if self._is_pi_edge(a, b) and a_soft > 0.50:
            score += 3.5

        # Carbonyl carbons are hard acceptors; reduced from 3.5 to cut triple-stacking
        if self._is_carbonyl_carbon(acceptor):
            score += 2.0

        # Regioselectivity bonus from LUMO character
        if hasattr(self, "_fukui_plus"):
            fukui_plus = self._fukui_plus(acceptor)
            score += 4.0 * fukui_plus

        return score

    def _hsab_cleavage_score(self, src_edge: Tuple[int, int], sink: int) -> float:
        """Score HSAB favorability for heterolytic cleavage of a pi-bond.

        Favors soft, negatively-charged leaving groups. Heteroatom sinks
        with good lone pairs are favorable.
        """
        a, b = int(src_edge[0]), int(src_edge[1])
        sink = int(sink)

        # Softness of the leaving group (sink): soft groups leave easily
        score = 10.0 * self._atom_softness(sink)

        # Halogens are excellent leaving groups (high softness)
        if self._is_halogen(sink):
            score += 5.0

        # Negative charge: anionic leaving groups (e.g., halide) are good
        if self._formal_charge(sink) < 0:
            score += 4.0

        # Pi bond cleavage producing charged sink (nucleofugal departure)
        if self._is_pi_edge(a, b) and self._is_hetero(sink):
            score += 2.5

        # Regioselectivity: Fukui f- (nucleophilicity) of the sink
        if hasattr(self, "_fukui_minus"):
            fukui_minus = self._fukui_minus(sink)
            score += 3.0 * fukui_minus

        return score
