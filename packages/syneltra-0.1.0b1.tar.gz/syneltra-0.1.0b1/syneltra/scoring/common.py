"""Shared numeric utilities and empirical chemistry tables for scoring.

The values here are heuristic descriptors used by the local mechanism ranker;
they are not quantum-chemical constants. Keeping them in one file makes it
straightforward to tune or replace the scale without touching scoring logic.

Interpretation
--------------
- BASE_HARDNESS:
    Larger means harder, less polarizable, more charge-localized.
    Useful for HSAB-like matching and hard nucleophile/electrophile scoring.

- BASE_SOFTNESS:
    Larger means softer, more polarizable, better for soft attack,
    leaving-group ability, and heavy-atom polarizable interactions.

- ELECTRONEGATIVITY:
    Pauling-like electronegativity values used only as relative descriptors.
"""

from __future__ import annotations

import math
from typing import Dict

# ---------------------------------------------------------------------------
# Heuristic HSAB-like hardness scale.
#
# Larger means harder; lower means softer / more polarizable.
#
# This is NOT a physical hardness table. It is intentionally normalized and
# chemistry-ranker-friendly. Values are chosen to preserve qualitative trends:
#
#   F > O > N > C
#   O/N harder than S/P
#   F > Cl > Br > I
#   small alkali/alkaline-earth elements harder than heavier analogues
#   late heavy transition metals are soft / polarizable
# ---------------------------------------------------------------------------

BASE_HARDNESS: Dict[str, float] = {
    # Period 1
    "H": 0.80,
    "HE": 0.95,
    # Period 2
    "LI": 0.42,
    "BE": 0.62,
    "B": 0.56,
    "C": 0.46,
    "N": 0.72,
    "O": 0.86,
    "F": 1.00,
    "NE": 0.96,
    # Period 3
    "NA": 0.32,
    "MG": 0.52,
    "AL": 0.42,
    "SI": 0.38,
    "P": 0.34,
    "S": 0.30,
    "CL": 0.24,
    "AR": 0.92,
    # Period 4
    "K": 0.26,
    "CA": 0.44,
    "SC": 0.38,
    "TI": 0.36,
    "V": 0.34,
    "CR": 0.32,
    "MN": 0.31,
    "FE": 0.30,
    "CO": 0.29,
    "NI": 0.28,
    "CU": 0.26,
    "ZN": 0.36,
    "GA": 0.34,
    "GE": 0.33,
    "AS": 0.31,
    "SE": 0.28,
    "BR": 0.20,
    "KR": 0.88,
    # Period 5
    "RB": 0.22,
    "SR": 0.38,
    "Y": 0.34,
    "ZR": 0.32,
    "NB": 0.30,
    "MO": 0.29,
    "TC": 0.28,
    "RU": 0.27,
    "RH": 0.26,
    "PD": 0.24,
    "AG": 0.21,
    "CD": 0.31,
    "IN": 0.30,
    "SN": 0.29,
    "SB": 0.27,
    "TE": 0.24,
    "I": 0.16,
    "XE": 0.84,
    # Period 6
    "CS": 0.18,
    "BA": 0.34,
    "LA": 0.31,
    "CE": 0.30,
    "PR": 0.30,
    "ND": 0.30,
    "SM": 0.29,
    "EU": 0.29,
    "GD": 0.29,
    "TB": 0.29,
    "DY": 0.29,
    "HO": 0.29,
    "ER": 0.29,
    "TM": 0.29,
    "YB": 0.28,
    "LU": 0.29,
    "HF": 0.31,
    "TA": 0.30,
    "W": 0.28,
    "RE": 0.27,
    "OS": 0.26,
    "IR": 0.25,
    "PT": 0.23,
    "AU": 0.19,
    "HG": 0.28,
    "TL": 0.26,
    "PB": 0.25,
    "BI": 0.23,
    "PO": 0.22,
    "AT": 0.14,
    "RN": 0.80,
}


# ---------------------------------------------------------------------------
# Heuristic softness / polarizability scale.
#
# Larger means softer / more polarizable.
#
# This intentionally gives high softness to heavy halides, sulfur, selenium,
# tellurium, and late heavy transition metals.
# ---------------------------------------------------------------------------

BASE_SOFTNESS: Dict[str, float] = {
    # Period 1
    "H": 0.20,
    "HE": 0.04,
    # Period 2
    "LI": 0.48,
    "BE": 0.34,
    "B": 0.40,
    "C": 0.48,
    "N": 0.34,
    "O": 0.26,
    "F": 0.10,
    "NE": 0.04,
    # Period 3
    "NA": 0.58,
    "MG": 0.42,
    "AL": 0.52,
    "SI": 0.58,
    "P": 0.66,
    "S": 0.72,
    "CL": 0.78,
    "AR": 0.08,
    # Period 4
    "K": 0.66,
    "CA": 0.50,
    "SC": 0.54,
    "TI": 0.56,
    "V": 0.58,
    "CR": 0.60,
    "MN": 0.61,
    "FE": 0.62,
    "CO": 0.63,
    "NI": 0.64,
    "CU": 0.68,
    "ZN": 0.56,
    "GA": 0.58,
    "GE": 0.60,
    "AS": 0.64,
    "SE": 0.76,
    "BR": 0.88,
    "KR": 0.12,
    # Period 5
    "RB": 0.72,
    "SR": 0.58,
    "Y": 0.60,
    "ZR": 0.62,
    "NB": 0.64,
    "MO": 0.65,
    "TC": 0.66,
    "RU": 0.68,
    "RH": 0.70,
    "PD": 0.76,
    "AG": 0.82,
    "CD": 0.66,
    "IN": 0.68,
    "SN": 0.70,
    "SB": 0.74,
    "TE": 0.82,
    "I": 1.00,
    "XE": 0.16,
    # Period 6
    "CS": 0.78,
    "BA": 0.64,
    "LA": 0.66,
    "CE": 0.67,
    "PR": 0.67,
    "ND": 0.67,
    "SM": 0.68,
    "EU": 0.68,
    "GD": 0.68,
    "TB": 0.68,
    "DY": 0.68,
    "HO": 0.68,
    "ER": 0.68,
    "TM": 0.68,
    "YB": 0.69,
    "LU": 0.68,
    "HF": 0.66,
    "TA": 0.67,
    "W": 0.70,
    "RE": 0.72,
    "OS": 0.74,
    "IR": 0.76,
    "PT": 0.82,
    "AU": 0.90,
    "HG": 0.74,
    "TL": 0.78,
    "PB": 0.80,
    "BI": 0.84,
    "PO": 0.86,
    "AT": 0.96,
    "RN": 0.20,
}


# ---------------------------------------------------------------------------
# Pauling-like electronegativity table.
#
# Values are used as relative descriptors, not as strict physical constants.
# Noble gases and some lanthanides have approximate or conventional values.
# ---------------------------------------------------------------------------

ELECTRONEGATIVITY: Dict[str, float] = {
    # Period 1
    "H": 2.20,
    "HE": 0.00,
    # Period 2
    "LI": 0.98,
    "BE": 1.57,
    "B": 2.04,
    "C": 2.55,
    "N": 3.04,
    "O": 3.44,
    "F": 3.98,
    "NE": 0.00,
    # Period 3
    "NA": 0.93,
    "MG": 1.31,
    "AL": 1.61,
    "SI": 1.90,
    "P": 2.19,
    "S": 2.58,
    "CL": 3.16,
    "AR": 0.00,
    # Period 4
    "K": 0.82,
    "CA": 1.00,
    "SC": 1.36,
    "TI": 1.54,
    "V": 1.63,
    "CR": 1.66,
    "MN": 1.55,
    "FE": 1.83,
    "CO": 1.88,
    "NI": 1.91,
    "CU": 1.90,
    "ZN": 1.65,
    "GA": 1.81,
    "GE": 2.01,
    "AS": 2.18,
    "SE": 2.55,
    "BR": 2.96,
    "KR": 3.00,
    # Period 5
    "RB": 0.82,
    "SR": 0.95,
    "Y": 1.22,
    "ZR": 1.33,
    "NB": 1.60,
    "MO": 2.16,
    "TC": 1.90,
    "RU": 2.20,
    "RH": 2.28,
    "PD": 2.20,
    "AG": 1.93,
    "CD": 1.69,
    "IN": 1.78,
    "SN": 1.96,
    "SB": 2.05,
    "TE": 2.10,
    "I": 2.66,
    "XE": 2.60,
    # Period 6
    "CS": 0.79,
    "BA": 0.89,
    "LA": 1.10,
    "CE": 1.12,
    "PR": 1.13,
    "ND": 1.14,
    "SM": 1.17,
    "EU": 1.20,
    "GD": 1.20,
    "TB": 1.20,
    "DY": 1.22,
    "HO": 1.23,
    "ER": 1.24,
    "TM": 1.25,
    "YB": 1.10,
    "LU": 1.27,
    "HF": 1.30,
    "TA": 1.50,
    "W": 2.36,
    "RE": 1.90,
    "OS": 2.20,
    "IR": 2.20,
    "PT": 2.28,
    "AU": 2.54,
    "HG": 2.00,
    "TL": 1.62,
    "PB": 2.33,
    "BI": 2.02,
    "PO": 2.00,
    "AT": 2.20,
    "RN": 0.00,
}


def scalar_numeric(value: object, default: float = 0.0) -> float:
    """Coerce graph attribute values to one finite float."""

    while isinstance(value, (tuple, list)):
        if not value:
            return float(default)
        value = value[0]

    try:
        value = float(value)
    except Exception:
        return float(default)

    return float(default) if math.isnan(value) else float(value)


def scalar_bool(value: object) -> bool:
    """Coerce scalar, tuple, or list graph attributes to bool."""

    while isinstance(value, (tuple, list)):
        if not value:
            return False
        value = value[0]

    return bool(value)


def clamp(value: float, low: float, high: float) -> float:
    """Clamp ``value`` to the inclusive interval ``[low, high]``."""

    return max(float(low), min(float(high), float(value)))


def bounded(value: float, scale: float) -> float:
    """Smoothly bound one score component without destroying local ordering."""

    if scale <= 0:
        return float(value)

    return float(scale) * math.tanh(float(value) / float(scale))


def norm_element(value: object) -> str:
    """Normalize element-like graph attributes to uppercase labels.

    Tuple/list values from ITS side-specific attributes are interpreted by
    taking the first element recursively.

    Examples
    --------
    >>> norm_element("Cl")
    'CL'
    >>> norm_element(("Br", "Br"))
    'BR'
    >>> norm_element(["se"])
    'SE'
    """

    while isinstance(value, (tuple, list)):
        if not value:
            value = ""
            break
        value = value[0]

    text = str(value or "").strip().upper()

    # Common aliases / pseudo-elements.
    aliases = {
        "D": "H",
        "T": "H",
        "CL": "CL",
        "BR": "BR",
    }

    return aliases.get(text, text)


def element_hardness(element: object, default: float = 0.50) -> float:
    """Return heuristic hardness for an element-like value."""

    return float(BASE_HARDNESS.get(norm_element(element), default))


def element_softness(element: object, default: float = 0.50) -> float:
    """Return heuristic softness for an element-like value."""

    return float(BASE_SOFTNESS.get(norm_element(element), default))


def element_en(element: object, default: float = 2.20) -> float:
    """Return Pauling-like electronegativity for an element-like value."""

    return float(ELECTRONEGATIVITY.get(norm_element(element), default))


# ---------------------------------------------------------------------------
# Empirical pKa reference values for common functional groups.
#
# Keys are (element, context_descriptor) where context describes the chemical
# environment. Values are pKa estimates (conjugate acid of the base).
#
# Used as a first-pass lookup in pKa scoring before falling back to
# calculated values. Improves accuracy for known patterns.
# ---------------------------------------------------------------------------

EMPIRICAL_PKA: Dict[str, float] = {
    # Oxygen: alcohols, phenols, carboxylic acids, ethers
    ("O", "carboxyl"): 4.3,  # -COOH
    ("O", "phenol"): 9.8,  # Ar-OH
    ("O", "phenoxide"): 3.5,  # Ar-O⁻ → ArOH acidity
    ("O", "alcohol"): 15.5,  # R-OH
    ("O", "enol"): 10.0,  # C=C-OH
    ("O", "ether_protonated"): -2.0,  # ROH₂⁺ (very acidic)
    # Nitrogen: amines, pyridines, imidazoles, amides
    ("N", "pyridinium"): 5.2,  # pyr⁺ (pyridine conjugate acid)
    ("N", "aniline"): 4.6,  # Ar-NH₃⁺ (aniline conjugate acid)
    ("N", "aliphatic_amine"): 10.6,  # R₃NH⁺
    ("N", "imidazole"): 6.0,  # imid-NH
    ("N", "indole"): 16.5,  # ind-NH (weak acid)
    ("N", "amide"): 15.0,  # RCONH (very weak acid)
    ("N", "sulfonamide"): 10.0,  # RSO₂NH (N is the acidic site)
    # Sulfur: thiols, sulfoxides, sulfones, sulfonamides
    ("S", "thiol_aliphatic"): 8.8,  # RSH
    ("S", "thiol_aromatic"): 6.5,  # ArSH
    ("S", "thiol_acidic"): 3.2,  # RSOH (carboxylic analog)
    ("S", "sulfoxide"): 8.0,  # R₂SO
    ("S", "sulfone"): 1.8,  # RSO₂H or RSO₂R
    ("S", "disulfide"): 8.5,  # RS-SR (cystine-like)
    # Carbon: sp³, sp², sp hybridized; aliphatic, aromatic, conjugated
    ("C", "sp3_acidic"): 48.0,  # sp³ C-H (alkane, essentially no acidity)
    ("C", "sp2_alkene"): 40.0,  # =CH₂ (weak acid)
    ("C", "sp_alkyne"): 25.0,  # ≡C-H (acetylene, weakly acidic)
    ("C", "benzylic"): 25.0,  # Ph-CH₂- (benzyl system)
    ("C", "allylic"): 30.0,  # C=C-CH₂- (allylic)
    ("C", "enol"): 12.0,  # C=C-OH (enol)
    ("C", "enolate"): 8.0,  # C=C-O⁻ (enolate carbanion)
    ("C", "malonyl"): 11.0,  # (COOH)₂CH (malononic acid)
    ("C", "acetyl"): 16.0,  # CH₃-CO- adjacent
    # Halogens: HF, HCl, HBr, HI behavior
    ("F", "neutral"): 3.2,  # HF (weakly acidic)
    ("F", "anion"): -1.0,  # F⁻ very weak base
    ("CL", "neutral"): -7.0,  # HCl (strong acid)
    ("CL", "anion"): -1.0,  # Cl⁻
    ("BR", "neutral"): -9.0,  # HBr
    ("BR", "anion"): -1.0,  # Br⁻
    ("I", "neutral"): -10.0,  # HI (strongest among hydrogen halides)
    ("I", "anion"): -1.0,  # I⁻
    # Phosphorus: phosphonic acids, phosphinates
    ("P", "phosphonic"): 2.2,  # (RO)₂PHOH
    ("P", "phosphinic"): 2.5,  # RP(O)(OH)₂
    # Boron: boronic acids
    ("B", "boronic"): 9.0,  # RB(OH)₂
}
