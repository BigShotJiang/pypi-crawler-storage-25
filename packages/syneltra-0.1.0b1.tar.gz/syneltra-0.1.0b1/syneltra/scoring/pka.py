"""Proton-transfer pKa proxy scoring."""

from __future__ import annotations

from .common import EMPIRICAL_PKA, clamp, element_en


class PkaScoringMixin:
    """Conjugate-acid pKa proxy for proton-transfer ranking.

    Two-tier strategy:
    1. Try empirical lookup for recognized functional groups (accurate)
    2. Estimate from first principles if no match (generalizable)

    Balances high accuracy on known patterns with graceful handling of unknowns.
    """

    def _pka_proxy(self, atom: int, *, protonated: bool) -> float:
        """Estimate pKa of conjugate acid when atom accepts a proton.

        First tries empirical lookup for detected functional group.
        Falls back to calculation from electronegativity + conjugation.
        """
        atom = int(atom)
        if atom not in self.graph:
            return 7.0

        elem = self._element(atom)

        # Special case: bare hydrogen
        if elem == "H":
            return -1.7

        # Tier 1: Try empirical lookup for detected functional group
        empirical = self._lookup_empirical_pka(atom, protonated)
        if empirical is not None:
            return empirical

        # Tier 2: Estimate from first principles
        pka = self._estimate_pka(atom, protonated)
        return clamp(pka, -10.0, 50.0)

    def _lookup_empirical_pka(self, atom: int, protonated: bool) -> float | None:
        """Look up empirical pKa for detected functional group.

        Returns pKa if found in EMPIRICAL_PKA table, None to fall back to estimation.
        """
        atom = int(atom)
        elem = self._element(atom)

        # Detect functional group context for this atom
        contexts = self._detect_functional_group(atom)

        # Try to find a match in empirical table (most specific first)
        for ctx in contexts:
            key = (elem, ctx)
            if key in EMPIRICAL_PKA:
                pka = EMPIRICAL_PKA[key]
                # Adjust for protonation state if relevant
                if protonated and "protonated" not in ctx and elem not in {"F", "CL", "BR", "I"}:
                    pka -= 1.5
                return pka

        return None

    def _detect_functional_group(self, atom: int) -> list[str]:
        """Detect functional group context (returns contexts to try in order).

        Delegates to element-specific detectors. Prioritizes more specific patterns.
        """
        atom = int(atom)
        elem = self._element(atom)

        if elem == "O":
            return self._detect_oxygen_context(atom)
        elif elem == "N":
            return self._detect_nitrogen_context(atom)
        elif elem == "S":
            return self._detect_sulfur_context(atom)
        elif elem == "C":
            return self._detect_carbon_context(atom)
        elif elem in {"F", "CL", "BR", "I"}:
            return self._detect_halogen_context(atom)
        else:
            return ["default_neutral"]

    def _detect_oxygen_context(self, atom: int) -> list[str]:
        """Detect functional group for oxygen."""
        contexts = []
        charge = self._formal_charge(atom)

        if self._carbonyl_adjacent(atom):
            contexts.append("carboxyl")
        if self._aromatic(atom):
            contexts.append("phenoxide" if charge < 0 else "phenol")
        if self._incident_conjugated(atom):
            contexts.append("enol")
        if charge < 0:
            contexts.append("oxide")
        contexts.append("alcohol")

        return contexts

    def _detect_nitrogen_context(self, atom: int) -> list[str]:
        """Detect functional group for nitrogen."""
        contexts = []

        if self._is_imidazole_like(atom):
            contexts.append("imidazole")
        if self._is_sulfonamide_n(atom):
            contexts.append("sulfonamide")
        if self._is_amide_n(atom):
            contexts.append("amide")
        if self._aromatic(atom):
            contexts.append("pyridinium")
        if self._has_aromatic_neighbor(atom):
            contexts.append("aniline")
        if self._incident_conjugated(atom):
            contexts.append("aromatic_basic")
        contexts.append("aliphatic_amine")

        return contexts

    def _detect_sulfur_context(self, atom: int) -> list[str]:
        """Detect functional group for sulfur."""
        contexts = []

        if self._is_sulfone(atom):
            contexts.append("sulfone")
        if self._is_sulfoxide(atom):
            contexts.append("sulfoxide")
        if self._carbonyl_adjacent(atom):
            contexts.append("thiol_acidic")
        if self._aromatic(atom):
            contexts.append("thiol_aromatic")
        contexts.append("thiol_aliphatic")

        return contexts

    def _detect_carbon_context(self, atom: int) -> list[str]:
        """Detect functional group for carbon."""
        contexts = []

        if self._is_benzylic(atom):
            contexts.append("benzylic")
        if self._is_allylic(atom):
            contexts.append("allylic")
        if self._incident_conjugated(atom) and self._carbonyl_adjacent(atom):
            contexts.append("enolate")
        if self._incident_conjugated(atom):
            contexts.append("sp2_alkene")
        if hasattr(self, "_hybridization") and self._hybridization(atom) == "sp":
            contexts.append("sp_alkyne")
        contexts.append("sp3_acidic")

        return contexts

    def _detect_halogen_context(self, atom: int) -> list[str]:
        """Detect functional group for halogens."""
        charge = self._formal_charge(atom)
        return ["anion" if charge < 0 else "neutral"]

    def _is_imidazole_like(self, atom: int) -> bool:
        """Check if N is aromatic with multiple aromatic neighbors."""
        if not self._aromatic(atom):
            return False
        aromatic_neighbors = sum(1 for nbr in self.graph.neighbors(int(atom)) if self._aromatic(int(nbr)))
        return aromatic_neighbors >= 2

    def _is_sulfonamide_n(self, atom: int) -> bool:
        """Check if N bonded to sulfone (RSO₂N)."""
        atom = int(atom)
        for nbr in self.graph.neighbors(atom):
            if self._is_sulfone(int(nbr)):
                return True
        return False

    def _is_amide_n(self, atom: int) -> bool:
        """Check if N bonded to carbonyl carbon."""
        atom = int(atom)
        for nbr in self.graph.neighbors(atom):
            if self._is_carbonyl_carbon(int(nbr)):
                return True
        return False

    def _has_aromatic_neighbor(self, atom: int) -> bool:
        """Check if atom has aromatic neighbor."""
        atom = int(atom)
        return any(self._aromatic(int(nbr)) for nbr in self.graph.neighbors(atom))

    def _is_sulfone(self, atom: int) -> bool:
        """Check if S has ≥2 double-bonded oxygens (S=O bonds)."""
        atom = int(atom)
        double_bonded_oxygens = sum(
            1
            for nbr in self.graph.neighbors(atom)
            if self._element(int(nbr)) == "O" and self._bond_order(atom, int(nbr)) >= 2.0
        )
        return double_bonded_oxygens >= 2

    def _is_sulfoxide(self, atom: int) -> bool:
        """Check if S has exactly 1 double-bonded oxygen (S=O)."""
        atom = int(atom)
        double_bonded_oxygens = sum(
            1
            for nbr in self.graph.neighbors(atom)
            if self._element(int(nbr)) == "O" and self._bond_order(atom, int(nbr)) >= 2.0
        )
        return double_bonded_oxygens == 1

    def _estimate_pka(self, atom: int, protonated: bool) -> float:
        """Estimate pKa from electronegativity + conjugation + hybridization."""
        pka = self._base_acidity(atom)
        pka -= self._conjugate_base_stabilization(atom)
        pka -= self._inductive_acidity_effect(atom)

        # Formal charge: negative charge resists deprotonation
        charge = self._formal_charge(atom)
        pka += 5.0 * charge

        # Protonation state: harder to deprotonate further
        if protonated:
            pka -= 2.0

        return pka

    def _base_acidity(self, atom: int) -> float:
        """Base pKa from electronegativity and hybridization.

        More electronegative atoms are more acidic (lower pKa).
        sp > sp2 > sp3 in acidity.
        """
        elem = self._element(atom)
        en = element_en(elem)

        # Scale electronegativity to pKa range
        # C baseline ~2.55, H ~2.20; O ~3.44, N ~3.04, S ~2.58
        base_pka = 25.0 - (en - 2.0) * 8.0

        # Adjust for hybridization if available
        if hasattr(self, "_hybridization"):
            hyb = self._hybridization(atom)
            if hyb == "SP":
                base_pka -= 8.0  # sp very acidic (acetylene-like)
            elif hyb == "SP2":
                base_pka -= 3.0  # sp2 moderately acidic
            # SP3 uses base value

        return base_pka

    def _conjugate_base_stabilization(self, atom: int) -> float:
        """pKa lowering from stabilization of the deprotonated conjugate base.

        Aromatic and conjugated anions are stabilized, making the acid more acidic.
        Carbonyl-adjacent atoms can stabilize negative charge via resonance.
        """
        stabilization = 0.0

        # Aromatic context: strong charge stabilization
        if self._aromatic(atom):
            stabilization += 5.5

        # Conjugation: delocalization of negative charge
        if self._incident_conjugated(atom):
            stabilization += 3.0
            # Longer conjugation chains provide more stabilization
            stabilization += min(2.0, 0.5 * self._max_conjugation_depth(atom))

        # Carbonyl-adjacent: resonance stabilization (like carboxylic acids)
        if self._carbonyl_adjacent(atom):
            stabilization += 4.0

        return min(12.0, stabilization)

    def _inductive_acidity_effect(self, atom: int) -> float:
        """pKa lowering from electron-withdrawing neighbors.

        Nearby highly electronegative atoms (O, N, F) withdraw electrons,
        making the conjugate base more stable → acid more acidic.
        """
        effect = 0.0

        for neighbor in self.graph.neighbors(int(atom)):
            neighbor = int(neighbor)
            if neighbor not in self.graph:
                continue

            elem_n = self._element(neighbor)
            en_n = element_en(elem_n)

            # Only count electron-withdrawing neighbors
            if en_n > 2.8:  # O, N, F, Cl, etc.
                en_diff = en_n - 2.55  # C baseline
                effect += 0.8 * en_diff

        return min(3.0, effect)

    def _carbonyl_adjacent(self, atom: int) -> bool:
        """Check if atom is bonded to a carbonyl carbon."""
        atom = int(atom)
        if atom not in self.graph:
            return False
        return any(
            self._element(int(nbr)) == "C" and self._is_carbonyl_carbon(int(nbr)) for nbr in self.graph.neighbors(atom)
        )

    def _proton_transfer_score(self, donor_atom: int, acceptor_atom: int):
        """Score B: + HA -> BH+ + A- by a pKa proxy.

        Positive when the product acid BH+ is weaker than HA:
        ``pKa(BH+) - pKa(HA) > 0``.
        """

        donor_atom = int(donor_atom)  # base that receives H
        acceptor_atom = int(acceptor_atom)  # acid/heavy atom losing H or H itself
        pka_product_acid = self._pka_proxy(donor_atom, protonated=True)
        pka_reactant_acid = self._pka_proxy(acceptor_atom, protonated=False)
        pka = clamp(pka_product_acid - pka_reactant_acid, -20.0, 20.0)
        fmo = 0.5 * self._estimate_lp_donor(donor_atom) if donor_atom in self.graph else 0.0
        hsab = (
            self._hsab_pair_score(donor_atom, acceptor_atom)
            if self._has_hsab() and acceptor_atom in self.graph
            else 0.0
        )
        return self._compose_score(
            fmo=fmo,
            huckel=0.0,
            hsab=hsab,
            resonance=self._resonance_site_score(donor_atom, role="donor"),
            pka=pka,
            phase=0.0,
            reason=f"proton transfer {donor_atom} <- H/{acceptor_atom}",
        )
