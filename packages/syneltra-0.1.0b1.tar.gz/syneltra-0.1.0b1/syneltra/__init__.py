"""SynEltra: endpoint-conditioned electron-flow mechanism search.

Public API lives here and in chemically meaningful subpackages:

- :mod:`syneltra.chemistry` for graph/ITS construction and endpoint states
- :mod:`syneltra.mechanism` for arrow primitives, constraints, and planning
- :mod:`syneltra.mechanism_search` for enumeration algorithms
- :mod:`syneltra.scoring` for chemical/electronic scoring functions
- :mod:`syneltra.ranker` for using scores to rank full trajectories
- :mod:`syneltra.visualization` for rendering mechanisms
"""

from .core.config import (
    BeamMode,
    BeamScoreMode,
    ElectronicMode,
    MechanismSearchConfig,
    SearchStrategy,
)
from .core.models import ExpansionContext, StateSnapshot, Trajectory, Transition

from .chemistry.context import BondCandidate
from .chemistry.endpoint import (
    build_endpoint_states,
    build_endpoint_states_from_graphs,
    build_endpoint_states_from_its,
    build_working_graph,
    extract_its_components,
)
from .chemistry.graph import (
    atom_element,
    ContextResonanceStateCodec,
    StateCodec,
    edge_order,
    materialize_full_graph,
    possible_edge_keys,
)
from .chemistry.io import (
    DEFAULT_EDGE_ATTRS,
    DEFAULT_NODE_ATTRS,
    ReactionGraphBundle,
    construct_its_from_graphs,
    endpoint_states_from_rsmi,
    print_reaction_graph_attributes,
    rsmi_to_its,
    rsmi_to_reaction_bundle,
    rsmi_to_reaction_graphs,
    rsmi_to_trajs,
)
from .chemistry.workspace import RCWorkspaceBuilder, WorkspaceSpec

from .constraints import (
    ArrowPlanConstraint,
    BaseConstraint,
    BondOnlyConstraint,
    ConstraintRegistry,
    ElectronicGuidanceConstraint,
    ElectronFlowConstraint,
    GenericContextGuidanceConstraint,
    HydrogenFlowConstraint,
    HydrogenTransientConstraint,
    InitialStepConstraint,
    ITSWalkConstraint,
    LocalInstabilityConstraint,
    PolarChemistryConstraint,
    RCBondAnchorConstraint,
    default_constraints,
)
from .mechanism.operators import (
    BaseOperator,
    BondToBondOperator,
    BondToLPOperator,
    HydrogenToBondOperator,
    LPToBondOperator,
)
from .mechanism.planner import (
    ArrowBundle,
    ArrowPlan,
    BondFlowPlan,
    BondFlowStep,
    ITSPlanner,
    ITSWalkPlanner,
)
from .mechanism.pruner import (
    FixedArrowValidityGate,
    GraphValidityOracle,
    RollingValidityPruner,
)
from .mechanism.vocabulary import OperatorVocabulary, default_vocabulary

from .search import BeamBranch, MechanismEnumerator

_EXAMPLE_EXPORTS = {
    "BenchmarkAttemptResult",
    "BenchmarkAttemptSpec",
    "BenchmarkCaseResult",
    "BenchmarkReport",
    "BenchmarkRunConfig",
    "ReactionCase",
    "get_case",
    "list_case_names",
    "report_success_fail_rate",
    "run_benchmark",
    "run_case",
}


def __getattr__(name: str):
    """Lazily expose example/benchmark helpers without loading case data."""
    if name in _EXAMPLE_EXPORTS:
        from . import example as _example

        return getattr(_example, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "atom_element",
    "ArrowBundle",
    "ArrowPlan",
    "ArrowPlanConstraint",
    "BaseConstraint",
    "BaseOperator",
    "BeamBranch",
    "BenchmarkAttemptResult",
    "BenchmarkAttemptSpec",
    "BenchmarkCaseResult",
    "BenchmarkReport",
    "BenchmarkRunConfig",
    "ReactionCase",
    "get_case",
    "list_case_names",
    "report_success_fail_rate",
    "run_benchmark",
    "run_case",
    "BeamMode",
    "BeamScoreMode",
    "BondCandidate",
    "BondFlowPlan",
    "BondFlowStep",
    "BondOnlyConstraint",
    "BondToBondOperator",
    "BondToLPOperator",
    "ConstraintRegistry",
    "ContextResonanceStateCodec",
    "DEFAULT_EDGE_ATTRS",
    "DEFAULT_NODE_ATTRS",
    "ElectronicGuidanceConstraint",
    "ElectronicMode",
    "ElectronFlowConstraint",
    "ExpansionContext",
    "FixedArrowValidityGate",
    "GenericContextGuidanceConstraint",
    "GraphValidityOracle",
    "HydrogenFlowConstraint",
    "HydrogenToBondOperator",
    "HydrogenTransientConstraint",
    "ITSPlanner",
    "ITSWalkConstraint",
    "ITSWalkPlanner",
    "InitialStepConstraint",
    "LPToBondOperator",
    "LocalInstabilityConstraint",
    "MechanismEnumerator",
    "MechanismSearchConfig",
    "OperatorVocabulary",
    "PolarChemistryConstraint",
    "RCBondAnchorConstraint",
    "RCWorkspaceBuilder",
    "ReactionGraphBundle",
    "RollingValidityPruner",
    "SearchStrategy",
    "StateCodec",
    "StateSnapshot",
    "Trajectory",
    "Transition",
    "WorkspaceSpec",
    "build_endpoint_states",
    "build_endpoint_states_from_graphs",
    "build_endpoint_states_from_its",
    "build_working_graph",
    "construct_its_from_graphs",
    "default_constraints",
    "default_vocabulary",
    "edge_order",
    "endpoint_states_from_rsmi",
    "extract_its_components",
    "materialize_full_graph",
    "possible_edge_keys",
    "print_reaction_graph_attributes",
    "rsmi_to_its",
    "rsmi_to_reaction_bundle",
    "rsmi_to_reaction_graphs",
    "rsmi_to_trajs",
]
