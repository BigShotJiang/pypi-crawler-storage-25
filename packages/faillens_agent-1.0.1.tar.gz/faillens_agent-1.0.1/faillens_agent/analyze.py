import json
import csv
import io
from typing import List, Dict, Any, Optional

from .detector import detect_issues
from .grouper import group_failures
from .severity import score_issues
from .ai_agent import explain_issues_batch


def run_pipeline(
    logs: List[Dict[str, Any]],
    auto_debug: bool = True,
) -> Dict[str, Any]:
    if not logs:
        return {
            "summary": {
                "total_requests": 0,
                "total_failures": 0,
                "error_rate": 0.0,
                "average_latency": 0.0,
                "critical_issues": 0,
                "most_failed_endpoint": "N/A",
            },
            "issues": [],
        }

    step = lambda msg: print(f"    - {msg}")

    print("  detect issues...")
    annotated = detect_issues(logs)
    step(f"{len(annotated)} annotations")

    print("  group failures...")
    grouped = group_failures(annotated)
    step(f"{len(grouped)} issue groups")

    print("  score severity...")
    scored = score_issues(grouped)
    step(f"severity assigned")

    print("  debug & explain...")
    if auto_debug:
        scored = explain_issues_batch(scored)
    else:
        for issue in scored:
            issue["ai_debug"] = None
    step(f"{len(scored)} issues explained")

    from collections import Counter

    total_requests = len(logs)
    app_types = {"app_exception", "db_error", "network_error", "data_error", "business_failure"}
    total_failures = sum(
        1
        for l in logs
        if l.get("status_code", 200) >= 400
        or any(
            t in _classify_simple(l)
            for t in app_types
        )
    )
    error_rate = round((total_failures / total_requests) * 100, 2) if total_requests else 0.0
    all_latencies = sorted([l.get("latency_ms", 0) for l in logs])
    average_latency = round(sum(all_latencies) / total_requests, 2) if total_requests else 0.0
    p95_global = _percentile(all_latencies, 0.95) if all_latencies else 0
    p99_global = _percentile(all_latencies, 0.99) if all_latencies else 0
    critical_issues = sum(1 for i in scored if i["severity"] == "Critical")
    high_issues = sum(1 for i in scored if i["severity"] == "High")
    total_users = len({l.get("user_id") or l.get("user") for l in logs if l.get("user_id") or l.get("user")})

    failed_endpoints = [
        l.get("endpoint", "unknown")
        for l in logs
        if l.get("status_code", 200) >= 400 or (l.get("error_message") or l.get("business_status", "") in ("failed", "error"))
    ]
    most_failed_endpoint = Counter(failed_endpoints).most_common(1)[0][0] if failed_endpoints else "N/A"

    return {
        "summary": {
            "total_requests": total_requests,
            "total_failures": total_failures,
            "error_rate": error_rate,
            "average_latency": average_latency,
            "p95_latency": round(p95_global, 2),
            "p99_latency": round(p99_global, 2),
            "critical_issues": critical_issues,
            "high_issues": high_issues,
            "most_failed_endpoint": most_failed_endpoint,
            "affected_users": total_users,
        },
        "issues": scored,
    }


def _classify_simple(log: Dict[str, Any]) -> List[str]:
    issues = []
    code = log.get("status_code", 200)
    if code >= 500:
        issues.append("server_error")
    elif code == 404:
        issues.append("broken_endpoint")
    elif code in (401, 403):
        issues.append("auth_issue")
    elif code in (400, 422, 408):
        issues.append("data_error")
    latency = log.get("latency_ms", 0)
    if latency > 2000:
        issues.append("latency_spike")
    error_msg = log.get("error_message") or ""
    if error_msg and ("exception" in error_msg.lower() or "error" in error_msg.lower()):
        issues.append("app_exception")
    return issues


def _percentile(sorted_latencies: List[float], p: float) -> float:
    if not sorted_latencies:
        return 0.0
    import math

    k = (len(sorted_latencies) - 1) * p
    f = math.floor(k)
    c = math.ceil(k)
    if f == c:
        return sorted_latencies[int(k)]
    return sorted_latencies[f] * (c - k) + sorted_latencies[c] * (k - f)


def load_logs(path: str) -> List[Dict[str, Any]]:
    ext = path.rsplit(".", 1)[-1].lower() if "." in path else ""

    if ext == "csv":
        return _load_csv(path)

    with open(path, "r") as f:
        data = json.load(f)

    if isinstance(data, list):
        logs = data
    elif isinstance(data, dict):
        logs = data.get("logs", data.get("entries", [data]))
        if isinstance(logs, dict):
            logs = [logs]
    else:
        raise ValueError(f"Unexpected JSON structure in {path}")

    return logs


def _load_csv(path: str) -> List[Dict[str, Any]]:
    TYPE_MAP = {
        "latency_ms": float,
        "latency": float,
        "status_code": int,
        "status": int,
        "occurrences": int,
    }
    rows = []
    with open(path, "r", newline="") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            return rows
        for row in reader:
            parsed = {}
            for key, val in row.items():
                if not key or key.strip() == "":
                    continue
                clean_key = key.strip().lower().replace(" ", "_")
                mapped = _CSV_KEY_MAP.get(clean_key, clean_key)
                typename = TYPE_MAP.get(mapped, str)
                try:
                    if val is None or val.strip() == "":
                        parsed[mapped] = None
                    elif typename is float:
                        parsed[mapped] = float(val)
                    elif typename is int:
                        parsed[mapped] = int(val)
                    else:
                        parsed[mapped] = val.strip()
                except (ValueError, TypeError):
                    parsed[mapped] = val.strip() if val else None
            rows.append(parsed)
    return rows


_CSV_KEY_MAP = {
    "timestamp": "timestamp",
    "time": "timestamp",
    "date": "timestamp",
    "method": "method",
    "http_method": "method",
    "endpoint": "endpoint",
    "path": "endpoint",
    "route": "endpoint",
    "url": "endpoint",
    "status_code": "status_code",
    "status": "status_code",
    "http_status": "status_code",
    "latency_ms": "latency_ms",
    "latency": "latency_ms",
    "duration": "latency_ms",
    "response_time": "latency_ms",
    "error_message": "error_message",
    "error": "error_message",
    "message": "error_message",
    "service": "service",
    "service_name": "service",
    "microservice": "service",
    "user_id": "user_id",
    "user": "user_id",
    "business_status": "business_status",
    "business_result": "business_status",
}
