import json
import sys
from pathlib import Path

import click

from .analyze import run_pipeline, load_logs
from .watcher import watch_directory
from .server import serve
from .ai_agent import explain_issue


@click.group()
@click.version_option(version="1.0.0", prog_name="faillens")
def main():
    """FailLens Local Agent - detect > group > score > debug > explain API failures."""


@main.command()
@click.argument("input", type=click.Path(exists=True))
@click.option("--no-debug", is_flag=True, help="Skip AI debug/explain step")
@click.option("--output", "-o", type=click.Path(), help="Save output to file")
@click.option("--pretty", is_flag=True, help="Pretty-print JSON output")
def analyze(input, no_debug, output, pretty):
    """Run the full pipeline on a log file.

    Pipeline: detect > group > score > debug > explain
    """
    path = Path(input)
    if not path.is_file():
        click.echo(f"Error: {input} is not a file", err=True)
        sys.exit(1)

    click.echo(f"Loading {path.name}...")
    try:
        logs = load_logs(str(path))
    except Exception as e:
        click.echo(f"Error loading file: {e}", err=True)
        sys.exit(1)

    if not logs:
        click.echo("No log entries found in file")
        sys.exit(0)

    click.echo(f"Loaded {len(logs)} log entr(ies)")
    click.echo("Running pipeline:")
    click.echo("  detect > group > score > debug > explain")

    result = run_pipeline(logs, auto_debug=not no_debug)

    summary = result.get("summary", {})
    issues = result.get("issues", [])

    click.echo("")
    click.echo("Summary:")
    click.echo(f"  Total requests : {summary.get('total_requests', 0)}")
    click.echo(f"  Total failures : {summary.get('total_failures', 0)}")
    click.echo(f"  Error rate     : {summary.get('error_rate', 0)}%")
    click.echo(f"  Avg latency    : {summary.get('average_latency', 0)}ms")
    click.echo(f"  Issues found   : {len(issues)}")
    click.echo(f"  Critical       : {summary.get('critical_issues', 0)}")
    click.echo(f"  High           : {summary.get('high_issues', 0)}")
    click.echo("")

    if issues:
        click.echo("Issues:")
        for i, issue in enumerate(issues, 1):
            sev = issue.get("severity", "?")
            ep = issue.get("endpoint", "?")
            occ = issue.get("occurrences", 0)
            it = issue.get("issue_type", "?")
            click.echo(f"  {i}. [{sev}] {ep} ({occ}x, {it})")

    if output:
        indent = 2 if pretty else None
        with open(output, "w") as f:
            json.dump(result, f, indent=indent)
        click.echo(f"\nSaved to {output}")
    elif pretty:
        click.echo("")
        click.echo(json.dumps(result, indent=2))


@main.command()
@click.argument("path", type=click.Path(exists=True))
@click.option("--poll", default=2.0, help="Poll interval in seconds")
def watch(path, poll):
    """Watch a directory for new log files and analyze them automatically."""
    watch_directory(path, poll_interval=poll)


@main.command()
@click.option("--host", default="127.0.0.1", help="Host to bind to")
@click.option("--port", default=8100, help="Port to listen on")
def serve(host, port):
    """Run a lightweight local API server (mini backend).

    Provides REST endpoints for the browser extension to send logs to.
    """
    serve(host=host, port=port)


@main.command()
@click.argument("input", type=click.Path(exists=True))
@click.option("--pretty", is_flag=True, help="Pretty-print JSON output")
def explain(input, pretty):
    """Generate AI root cause explanation for a single issue (JSON file)."""
    path = Path(input)
    if not path.is_file():
        click.echo(f"Error: {input} is not a file", err=True)
        sys.exit(1)

    with open(path) as f:
        issue = json.load(f)

    click.echo(f"Explaining issue: {issue.get('issue_type', '?')} @ {issue.get('endpoint', '?')}")
    result = explain_issue(issue)

    indent = 2 if pretty else None
    click.echo(json.dumps(result, indent=indent))


if __name__ == "__main__":
    main()
