import re
import math
from collections import Counter
from datetime import datetime
from typing import List, Dict, Any


ISSUE_TYPE_MAP = {
    "server_error": "Server Error",
    "broken_endpoint": "Broken Endpoint",
    "auth_issue": "Authentication Issue",
    "latency_spike": "Latency Spike",
    "recurring_failure": "Recurring Failure",
    "critical_api_issue": "Critical API Issue",
    "performance_degradation": "Performance Degradation",
    "app_exception": "Application Exception",
    "db_error": "Database Error",
    "network_error": "Network Error",
    "data_error": "Data Error",
    "business_failure": "Business Logic Failure",
}

ERROR_PATTERNS = [
    ("app_exception", re.compile(r"null\s*pointer|nullptr|typeerror|valueerror|keyerror|indexerror|attributeerror|assertionerror|exception", re.I)),
    ("app_exception", re.compile(r"stack\s*trace|uncaught\s+exception|unhandled\s+exception|segfault|core\s+dumped", re.I)),
    ("db_error", re.compile(r"database|connection\s+pool\s+exhaust|query\s+timeout|deadlock|constraint\s+violation|unique\s+constraint|foreign\s+key", re.I)),
    ("db_error", re.compile(r"sql\s+error|relation\s+.*not\s+exist|table\s+.*not\s+found|cannot\s+open\s+connection|connection\s+refused|too\s+many\s+connections", re.I)),
    ("network_error", re.compile(r"timeout|timed\s*out|unreachable|connection\s+reset|connection\s+refused|dns\s+error|dns\s+resolution", re.I)),
    ("network_error", re.compile(r"network\s+error|socket\s+error|broken\s+pipe|no\s+route\s+to\s+host|host\s+down", re.I)),
    ("data_error", re.compile(r"invalid\s+format|malformed|unexpected\s+token|parse\s+error|deserialization|validation\s+failed", re.I)),
    ("data_error", re.compile(r"missing\s+field|required\s+param|invalid\s+input|bad\s+request|unprocessable\s+entity", re.I)),
    ("data_error", re.compile(r"json\s+parse|json\s+decode|utf-8|encoding\s+error|decoding\s+error", re.I)),
    ("business_failure", re.compile(r"charge\s+authorization\s+failed|payment\s+declined|insufficient\s+funds|transaction\s+failed", re.I)),
    ("business_failure", re.compile(r"order\s+service\s+unavailable|service\s+unavailable", re.I)),
    ("auth_issue", re.compile(r"session\s+expired|rate\s+limit\s+exceeded|too\s+many\s+requests", re.I)),
    ("server_error", re.compile(r"downstream\s+.+\s+unavailable|upstream\s+.+\s+error", re.I)),
]


def classify_log(log: Dict[str, Any]) -> List[str]:
    issues = []
    code = log.get("status_code", 200)
    latency = log.get("latency_ms", 0)
    biz_status = (log.get("business_status") or "").lower().strip()

    if code >= 500:
        issues.append("server_error")
    elif code == 404:
        issues.append("broken_endpoint")
    elif code in (401, 403):
        issues.append("auth_issue")
    elif code in (400, 422, 408):
        issues.append("data_error")

    if latency > 2000:
        issues.append("latency_spike")

    error_msg = log.get("error_message") or ""
    for issue_type, pattern in ERROR_PATTERNS:
        if pattern.search(error_msg):
            if issue_type not in issues:
                issues.append(issue_type)

    if biz_status in ("failed", "error") and not any(t in issues for t in ("server_error", "broken_endpoint", "auth_issue", "data_error", "business_failure", "app_exception", "db_error", "network_error")):
        issues.append("business_failure")

    return issues


def detect_issues(logs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    if not logs:
        return []

    app_level_types = {"app_exception", "db_error", "network_error", "data_error", "business_failure"}

    endpoint_stats: Dict[str, Dict] = {}
    for log in logs:
        ep = log.get("endpoint", "unknown")
        if ep not in endpoint_stats:
            endpoint_stats[ep] = {"total": 0, "failures": 0, "latencies": [], "timestamps": []}
        stats = endpoint_stats[ep]
        stats["total"] += 1
        types = classify_log(log)
        is_failure = log.get("status_code", 200) >= 400 or any(t in types for t in app_level_types)
        if is_failure:
            stats["failures"] += 1
        stats["latencies"].append(log.get("latency_ms", 0))
        ts = log.get("timestamp", "")
        if ts:
            stats["timestamps"].append(ts)

    endpoint_avg_latency = {}
    endpoint_meta = {}
    for ep, stats in endpoint_stats.items():
        endpoint_avg_latency[ep] = sum(stats["latencies"]) / len(stats["latencies"]) if stats["latencies"] else 0
        tss = stats["timestamps"]
        total = stats["total"]
        failures = stats["failures"]

        if len(tss) >= 2:
            first = _parse_ts(tss[0])
            last = _parse_ts(tss[-1])
            span_min = max((last - first).total_seconds() / 60, 1) if first and last else 1
            rpm = total / span_min
            fpm = failures / span_min
        else:
            rpm = total
            fpm = failures

        error_rate_pct = (failures / total * 100) if total else 0
        endpoint_meta[ep] = {"rpm": rpm, "fpm": fpm, "error_rate_pct": error_rate_pct}

    total = len(logs)
    failures = sum(1 for l in logs if l.get("status_code", 200) >= 400 or any(t in classify_log(l) for t in app_level_types))
    overall_error_rate = (failures / total * 100) if total else 0

    _endpoint_failures_by_min: Dict[str, Counter] = {}
    for log in logs:
        ep = log.get("endpoint", "unknown")
        ts = log.get("timestamp", "")
        dt = _parse_ts(ts)
        if not dt:
            continue
        min_key = dt.strftime("%Y-%m-%d %H:%M")
        if ep not in _endpoint_failures_by_min:
            _endpoint_failures_by_min[ep] = Counter()
        types = classify_log(log)
        is_failure = log.get("status_code", 200) >= 400 or any(t in types for t in app_level_types)
        if ep in endpoint_meta and is_failure and endpoint_meta[ep]["fpm"] > 0:
            _endpoint_failures_by_min[ep][min_key] += 1

    burst_endpoints: Dict[str, float] = {}
    for ep, minute_counts in _endpoint_failures_by_min.items():
        if not minute_counts:
            continue
        avg_fpm = endpoint_meta[ep]["fpm"] if endpoint_meta[ep]["fpm"] > 0 else 0.1
        max_burst = max(minute_counts.values())
        if max_burst > avg_fpm * 2 and max_burst >= 2:
            burst_endpoints[ep] = max_burst / avg_fpm

    annotated = []
    for log in logs:
        types = classify_log(log)
        ep = log.get("endpoint", "unknown")
        stats = endpoint_stats[ep]

        has_app_error = any(t in types for t in app_level_types)
        is_http_failure = log.get("status_code", 200) >= 400

        if stats["failures"] >= 5 and (is_http_failure or has_app_error):
            if "recurring_failure" not in types:
                types.append("recurring_failure")

        if overall_error_rate > 30 and (is_http_failure or has_app_error):
            if "critical_api_issue" not in types:
                types.append("critical_api_issue")

        if endpoint_avg_latency.get(ep, 0) > 3000:
            if "performance_degradation" not in types:
                types.append("performance_degradation")

        if ep in burst_endpoints:
            if "recurring_failure" not in types:
                types.append("recurring_failure")

        for issue_type in types:
            enriched = {
                **log,
                "issue_type": ISSUE_TYPE_MAP[issue_type],
                "_rpm": round(endpoint_meta.get(ep, {}).get("rpm", 0), 2),
                "_fpm": round(endpoint_meta.get(ep, {}).get("fpm", 0), 2),
                "_endpoint_error_rate": round(endpoint_meta.get(ep, {}).get("error_rate_pct", 0), 2),
                "_burst_ratio": round(burst_endpoints.get(ep, 0), 1),
            }
            annotated.append(enriched)

        if not types:
            annotated.append({**log, "issue_type": None})

    return annotated


def _parse_ts(ts: str):
    if not ts:
        return None
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(ts, fmt)
        except ValueError:
            pass
    return None
