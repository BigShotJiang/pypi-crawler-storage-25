import os
import time
import json
from pathlib import Path
from typing import Callable, Set

from .analyze import run_pipeline, load_logs


def watch_directory(
    path: str,
    on_analysis: Callable = None,
    poll_interval: float = 2.0,
):
    watch_path = Path(path)
    if not watch_path.is_dir():
        print(f"[watcher] '{path}' is not a directory")
        return

    seen: Set[str] = set()

    for f in watch_path.iterdir():
        if f.suffix in (".json", ".log", ".csv"):
            seen.add(f.name)

    print(f"[watcher] Watching {watch_path} for new log files...")
    print(f"[watcher] Already tracked {len(seen)} file(s)")

    try:
        while True:
            current: Set[str] = set()
            for f in watch_path.iterdir():
                if f.suffix in (".json", ".log", ".csv"):
                    current.add(f.name)

            new_files = current - seen
            if new_files:
                for fname in sorted(new_files):
                    fpath = watch_path / fname
                    print(f"\n[watcher] New file detected: {fname}")
                    try:
                        logs = load_logs(str(fpath))
                        if not logs:
                            print(f"[watcher] No valid logs in {fname}, skipping")
                            continue
                        print(f"[watcher] Loaded {len(logs)} log entries from {fname}")
                        result = run_pipeline(logs, auto_debug=True)
                        issues = result.get("issues", [])
                        summary = result.get("summary", {})
                        print(
                            f"[watcher] Analysis complete: {summary.get('total_requests', 0)} requests, "
                            f"{summary.get('total_failures', 0)} failures, "
                            f"{summary.get('error_rate', 0)}% error rate, "
                            f"{len(issues)} issues found"
                        )

                        out_path = watch_path / f"{fname.stem}_analysis.json"
                        with open(out_path, "w") as out:
                            json.dump(result, out, indent=2)
                        print(f"[watcher] Results saved to {out_path.name}")

                        if on_analysis:
                            on_analysis(result)

                    except Exception as e:
                        print(f"[watcher] Error processing {fname}: {e}")

            seen = current
            time.sleep(poll_interval)

    except KeyboardInterrupt:
        print("\n[watcher] Stopped")
