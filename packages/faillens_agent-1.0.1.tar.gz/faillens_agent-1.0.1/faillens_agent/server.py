import json
import os
from pathlib import Path
from typing import Optional

import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from .analyze import run_pipeline, load_logs

app = FastAPI(title="FailLens Local Agent", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

_logs_cache = []
_analysis_cache = {"summary": {}, "issues": []}


class LogEntry(BaseModel):
    timestamp: str
    method: str
    endpoint: str
    status_code: int
    latency_ms: float
    error_message: Optional[str] = None
    business_status: Optional[str] = None
    service: str = "unknown"
    user_id: Optional[str] = None
    deployment_version: Optional[str] = None


class LogsBatch(BaseModel):
    logs: list[LogEntry]


@app.post("/logs")
def ingest_logs(batch: LogsBatch):
    global _logs_cache, _analysis_cache
    entries = [l.model_dump() for l in batch.logs]
    _logs_cache.extend(entries)
    _analysis_cache = run_pipeline(_logs_cache, auto_debug=True)
    return {"received": len(entries), "total": len(_logs_cache)}


@app.post("/logs/single")
def ingest_single(log: LogEntry):
    global _logs_cache, _analysis_cache
    entry = log.model_dump()
    _logs_cache.append(entry)
    _analysis_cache = run_pipeline(_logs_cache, auto_debug=True)
    return {"received": 1, "total": len(_logs_cache)}


@app.get("/analyze")
def get_analysis():
    return _analysis_cache


@app.get("/logs")
def get_logs():
    return _logs_cache[-200:]  # last 200


@app.get("/health")
def health():
    return {"status": "healthy", "total_logs": len(_logs_cache)}


@app.get("/")
def root():
    return {
        "name": "FailLens Local Agent",
        "version": "1.0.0",
        "status": "running",
        "total_logs": len(_logs_cache),
        "issues": len(_analysis_cache.get("issues", [])),
    }


@app.post("/load")
def load_file(path: str):
    global _logs_cache, _analysis_cache
    if not os.path.isfile(path):
        raise HTTPException(status_code=400, detail=f"File not found: {path}")
    try:
        logs = load_logs(path)
        _logs_cache = logs
        _analysis_cache = run_pipeline(_logs_cache, auto_debug=True)
        return {
            "loaded": len(_logs_cache),
            "issues": len(_analysis_cache.get("issues", [])),
            "summary": _analysis_cache.get("summary", {}),
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.delete("/logs")
def clear_logs():
    global _logs_cache, _analysis_cache
    _logs_cache = []
    _analysis_cache = {"summary": {}, "issues": []}
    return {"ok": True}


def serve(host: str = "127.0.0.1", port: int = 8100):
    print(f"[server] FailLens Local Agent running at http://{host}:{port}")
    print(f"[server] Ingest: POST /logs, Analyze: GET /analyze, Load: POST /load")
    print(f"[server] Press Ctrl+C to stop")
    uvicorn.run(app, host=host, port=port, log_level="info")
