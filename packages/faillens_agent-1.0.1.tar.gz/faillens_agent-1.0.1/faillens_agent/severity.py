from typing import List, Dict, Any


def assign_severity(issue: Dict[str, Any]) -> str:
    occurrences = issue.get("occurrences", 0)
    avg_latency = issue.get("average_latency", 0)
    p95 = issue.get("p95_latency", 0)
    status_code = issue.get("status_code", 0)
    duration = issue.get("incident_duration_min", 0)
    affected = issue.get("affected_users", 0)

    is_5xx = 500 <= status_code < 600

    if (occurrences > 20) or (p95 > 3000 and is_5xx) or (duration > 120 and occurrences > 10) or (affected > 50):
        return "Critical"
    if (occurrences > 10) or (p95 > 2000) or (duration > 60) or (affected > 20):
        return "High"
    if (occurrences > 5) or (duration > 30):
        return "Medium"
    return "Low"


def score_issues(issues: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    for issue in issues:
        issue["severity"] = assign_severity(issue)
    return issues
