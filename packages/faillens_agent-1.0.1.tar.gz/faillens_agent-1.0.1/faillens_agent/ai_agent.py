import os
import json
from typing import Dict, Any, List
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    from groq import Groq
    _groq_available = True
except ImportError:
    _groq_available = False


def _get_groq_client():
    api_key = os.getenv("GROQ_API_KEY", "").strip()
    if not api_key or not _groq_available:
        return None
    try:
        return Groq(api_key=api_key)
    except Exception:
        return None


_GROQ_CLIENT = None


def _get_groq_client_cached():
    global _GROQ_CLIENT
    if _GROQ_CLIENT is None:
        _GROQ_CLIENT = _get_groq_client()
    return _GROQ_CLIENT


_ROOT_CAUSE_MAP = {
    "Server Error": {
        "likely_root_cause": "An unhandled exception or internal server error is occurring in the service. This could be due to a database failure, unhandled edge case, or a bug introduced in a recent deployment.",
        "impact": "Users are receiving 5xx errors and cannot complete their requests. This directly degrades user experience and may cause data inconsistency.",
        "debugging_steps": [
            "Check the service logs for stack traces around the timestamps of failures.",
            "Verify database connectivity and query health.",
            "Review recent deployments or configuration changes that may have introduced the regression.",
            "Inspect memory and CPU usage on the affected service hosts.",
            "Check for third-party dependency failures (queues, caches, external APIs).",
        ],
        "recommended_fix": [
            "Roll back recent deployments if the issue correlates with a release.",
            "Add proper error handling and graceful degradation for downstream failures.",
            "Implement circuit breakers to prevent cascading failures.",
            "Increase logging verbosity to capture root exception details.",
        ],
        "prevention_tips": [
            "Set up automated canary deployments to catch issues before full rollout.",
            "Add health checks and readiness probes for all services.",
            "Implement comprehensive unit and integration tests.",
            "Use error tracking tools (Sentry, Datadog) for real-time alerting.",
        ],
    },
    "Broken Endpoint": {
        "likely_root_cause": "The requested endpoint does not exist or has been moved/renamed. This often happens after API versioning changes, endpoint renames, or when clients use outdated URLs.",
        "impact": "Clients receive 404 responses and their operations fail silently. This can affect user flows that depend on these resources.",
        "debugging_steps": [
            "Verify the endpoint still exists in the router/controller definitions.",
            "Check if the endpoint was recently renamed, versioned, or removed.",
            "Inspect client-side code for hardcoded or outdated URLs.",
            "Review API gateway routing rules for misconfigurations.",
            "Check for typos or casing issues in the endpoint path.",
        ],
        "recommended_fix": [
            "Add redirect rules for deprecated endpoints to their new paths.",
            "Document all breaking changes in API changelogs.",
            "Version your API properly (e.g., /v1/, /v2/) to avoid breaking existing clients.",
            "Return descriptive 404 bodies with documentation links.",
        ],
        "prevention_tips": [
            "Maintain a versioned API with backward compatibility guarantees.",
            "Use contract testing to detect endpoint changes before deployment.",
            "Automate API documentation generation (OpenAPI/Swagger).",
            "Monitor 404 rates as a key SLI metric.",
        ],
    },
    "Authentication Issue": {
        "likely_root_cause": "JWT tokens or API keys are invalid, expired, or missing. This may also indicate a misconfigured auth middleware or a token refresh failure on the client side.",
        "impact": "Authenticated users are being denied access, causing failed sessions and poor user experience. Repeated failures may indicate a systemic token refresh bug.",
        "debugging_steps": [
            "Verify the token signing secret/key has not rotated without updating clients.",
            "Check token expiry settings (exp claim) in JWT configuration.",
            "Inspect auth middleware for incorrect header parsing.",
            "Test the auth flow end-to-end in a staging environment.",
            "Check if the token refresh endpoint is functioning correctly.",
        ],
        "recommended_fix": [
            "Implement automatic token refresh on the client side before expiry.",
            "Add clear error messages to 401/403 responses to aid debugging.",
            "Review and update CORS and auth middleware configurations.",
            "Use short-lived access tokens with longer-lived refresh tokens.",
        ],
        "prevention_tips": [
            "Implement token rotation and refresh strategies proactively.",
            "Set up monitoring on auth failure rates with alerting thresholds.",
            "Use centralized identity providers (Auth0, Cognito) for reliability.",
            "Regularly audit token lifetimes and security configurations.",
        ],
    },
    "Latency Spike": {
        "likely_root_cause": "Response times are exceeding acceptable thresholds. Common causes include slow database queries, downstream API timeouts, resource contention, or infrastructure issues like CPU/memory pressure.",
        "impact": "Users experience slow load times and degraded UX. High latency can cascade into timeouts and increase error rates downstream.",
        "debugging_steps": [
            "Profile the slow endpoint to identify the bottleneck (DB query, external call, computation).",
            "Check database query execution plans for missing indexes.",
            "Review external API call timeouts and retry configurations.",
            "Monitor server resource utilization (CPU, memory, network I/O).",
            "Check for connection pool exhaustion in database or HTTP clients.",
        ],
        "recommended_fix": [
            "Add database indexes for frequently queried columns.",
            "Implement caching (Redis/Memcached) for expensive computations.",
            "Set strict timeouts on all external API calls.",
            "Scale horizontally or vertically if under resource pressure.",
        ],
        "prevention_tips": [
            "Define and enforce latency SLOs for all critical endpoints.",
            "Add APM tracing (OpenTelemetry, Jaeger) for distributed request tracking.",
            "Run load tests regularly to detect regressions before production.",
            "Implement async processing for non-critical operations.",
        ],
    },
    "Recurring Failure": {
        "likely_root_cause": "The same endpoint is failing repeatedly, suggesting a systematic issue rather than a transient one. This could be a persistent bug, a degraded dependency, or a misconfiguration.",
        "impact": "Recurring failures compound user frustration and may indicate a service is fundamentally broken for a subset of use cases. Increases support ticket volume.",
        "debugging_steps": [
            "Identify if failures are 100% consistent or intermittent for this endpoint.",
            "Check if failures correlate with specific user types, regions, or input patterns.",
            "Review the dependency graph of this endpoint for degraded services.",
            "Examine recent deployments to this service or its dependencies.",
            "Reproduce the failure in a local or staging environment.",
        ],
        "recommended_fix": [
            "Implement retry logic with exponential backoff for transient failures.",
            "Add circuit breakers to prevent cascading failures to upstream callers.",
            "Fix the underlying bug causing the systematic failure.",
            "Add fallback behavior or graceful degradation for this endpoint.",
        ],
        "prevention_tips": [
            "Set failure rate thresholds that trigger automatic alerts.",
            "Implement chaos engineering to test resilience proactively.",
            "Use feature flags to disable problematic endpoints without downtime.",
            "Maintain runbooks for common failure modes.",
        ],
    },
    "Performance Degradation": {
        "likely_root_cause": "The overall average latency for this endpoint has significantly exceeded normal baselines, indicating systematic performance degradation rather than isolated spikes.",
        "impact": "All users hitting this endpoint experience degraded performance. SLOs are likely breached, and cascading slowdowns may affect dependent services.",
        "debugging_steps": [
            "Compare current performance metrics with historical baselines.",
            "Use distributed tracing to identify which span is slowest.",
            "Check for database query plan regressions (statistics refresh, index changes).",
            "Verify infrastructure capacity and autoscaling health.",
            "Review recent code changes for O(n²) operations or missing caches.",
        ],
        "recommended_fix": [
            "Optimize the slowest database queries with EXPLAIN ANALYZE.",
            "Introduce or warm up caches for hot data paths.",
            "Scale the service tier to match current load.",
            "Refactor CPU-intensive synchronous operations to async jobs.",
        ],
        "prevention_tips": [
            "Define P50/P95/P99 latency SLOs and alert on breaches.",
            "Integrate performance tests in your CI/CD pipeline.",
            "Use continuous profiling in production (Pyroscope, Parca).",
            "Review and tune database connection pool settings regularly.",
        ],
    },
    "Business Logic Failure": {
        "likely_root_cause": "A business-level validation or processing failure occurred. The API returned normally but the business operation itself failed — e.g., payment declined, authorization denied, or a business rule was violated.",
        "impact": "Users see the operation as failed even though the API responded successfully. This can lead to confusion, retry loops, and revenue loss if payments are involved.",
        "debugging_steps": [
            "Check the business_status field and error_message in the log to identify the specific business rule that failed.",
            "Review the business logic in the service that processes this endpoint.",
            "Check if the failure correlates with specific user accounts, payment methods, or input patterns.",
            "Verify the downstream business system (payment processor, fraud detection) is functioning correctly.",
            "Examine recent business rule or configuration changes that may have introduced the failure.",
        ],
        "recommended_fix": [
            "Add clearer error codes and messages to distinguish business failures from technical errors.",
            "Implement proper error handling that returns appropriate HTTP 4xx codes for business failures instead of 200.",
            "Add monitoring on business_status to alert when failure rates exceed thresholds.",
            "Review and update business rules if they are incorrectly rejecting valid requests.",
        ],
        "prevention_tips": [
            "Standardize on HTTP 4xx/5xx codes for all business failures so monitoring tools can detect them.",
            "Set up business-level dashboards tracking approval rates, decline reasons, and failure trends.",
            "Implement canary testing for business rule changes before full rollout.",
            "Log structured business failure reasons for easier aggregation and analysis.",
        ],
    },
    "Application Exception": {
        "likely_root_cause": "An unhandled application-level exception occurred in the service code. This is typically caused by a bug, missing null check, incorrect type handling, or an edge case not covered by tests.",
        "impact": "The request fails with an internal error, potentially causing data inconsistency or partial state updates. Users may experience incomplete operations or crashes.",
        "debugging_steps": [
            "Examine the service logs for the full stack trace around the failure timestamp.",
            "Identify the exact line of code throwing the exception and trace the input data.",
            "Reproduce the issue locally with the same input to isolate the root cause.",
            "Check if this correlates with a recent code deployment or configuration change.",
            "Verify that all external dependencies (libraries, services) are on compatible versions.",
        ],
        "recommended_fix": [
            "Add proper null checks and input validation before processing data.",
            "Wrap the failing operation in a try-catch block with graceful error handling.",
            "Fix the underlying bug and add a regression test for the specific edge case.",
            "Consider using a structured error handling pattern (Either, Result) instead of exceptions.",
        ],
        "prevention_tips": [
            "Maintain comprehensive unit test coverage, especially for edge cases.",
            "Use static analysis tools to catch potential null pointer and type errors at compile time.",
            "Implement structured logging with stack traces to speed up debugging.",
            "Run integration tests in staging with production-like data volumes.",
        ],
    },
    "Database Error": {
        "likely_root_cause": "A database-related failure such as connection exhaustion, query timeout, deadlock, or constraint violation. This often indicates scaling issues, missing indexes, or transaction management problems.",
        "impact": "Operations that depend on the database fail, causing partial or complete service unavailability. Data writes may be lost, and read operations return stale or no data.",
        "debugging_steps": [
            "Check database connection pool metrics (active, idle, waiting connections).",
            "Review slow query logs and identify queries with missing indexes or full table scans.",
            "Examine database server resource usage (CPU, memory, disk I/O, connections).",
            "Check for locking and deadlock patterns in the database logs.",
            "Verify network latency between the application and database servers.",
        ],
        "recommended_fix": [
            "Increase the database connection pool size and set appropriate timeouts.",
            "Add database indexes for frequently queried columns and review query plans.",
            "Implement query optimization (pagination, selective columns, cached results).",
            "Set up connection pooling with proper min/max thresholds and health checks.",
        ],
        "prevention_tips": [
            "Monitor database connection pool usage and set up alerts at 80% capacity.",
            "Use database query analysis tools (pg_stat_statements, slow query log).",
            "Implement read replicas for read-heavy workloads to reduce primary load.",
            "Regularly review and tune database configurations based on usage patterns.",
        ],
    },
    "Network Error": {
        "likely_root_cause": "A network-level failure such as timeout, connection reset, DNS resolution failure, or unreachable host. This can be caused by firewall rules, load balancer misconfiguration, or downstream service outages.",
        "impact": "Requests fail to reach their destination or time out waiting for a response. This can cascade into broader service degradation if callers do not implement proper retry logic.",
        "debugging_steps": [
            "Verify network connectivity between the affected services using ping/traceroute.",
            "Check firewall rules, security groups, and network ACLs for blocked traffic.",
            "Review DNS resolution and ensure DNS records are correct and propagated.",
            "Examine load balancer health checks and target group membership.",
            "Check if the downstream service is actually running and accepting connections.",
        ],
        "recommended_fix": [
            "Implement retry logic with exponential backoff and jitter for network calls.",
            "Add circuit breakers to prevent cascading failures across services.",
            "Configure appropriate timeouts at each network layer (client, load balancer, server).",
            "Use a service mesh or API gateway with built-in resilience patterns.",
        ],
        "prevention_tips": [
            "Set up synthetic monitoring to detect network issues before users are affected.",
            "Use redundant network paths and multi-AZ deployment for high availability.",
            "Document and test incident response procedures for network partitions.",
            "Implement health check endpoints and readiness probes for all services.",
        ],
    },
    "Data Error": {
        "likely_root_cause": "Invalid, malformed, or unexpected data was received or processed. This includes JSON parse failures, validation errors, encoding issues, or schema mismatches between services.",
        "impact": "The affected request fails, and the client receives an error. If this happens on critical data ingestion paths, it can lead to data loss or processing delays.",
        "debugging_steps": [
            "Capture and log the raw input data that caused the parsing or validation failure.",
            "Verify the data schema matches between producer and consumer services.",
            "Check for recent API contract changes that may have introduced a mismatch.",
            "Validate data encoding (UTF-8, base64, etc.) matches what the service expects.",
            "Review the validation rules to ensure they match the actual data requirements.",
        ],
        "recommended_fix": [
            "Add comprehensive input validation at the service boundary (API gateway or controller).",
            "Implement schema versioning and backward-compatible contract evolution.",
            "Return clear, descriptive error messages that identify exactly which field failed.",
            "Add a dead-letter queue for failed messages so they can be replayed after fixing.",
        ],
        "prevention_tips": [
            "Use contract testing (Pact, Spring Cloud Contract) between services.",
            "Maintain shared API specification files (OpenAPI, AsyncAPI) as the source of truth.",
            "Add fuzz testing to discover unexpected input handling issues.",
            "Monitor data validation failure rates as a key service health metric.",
        ],
    },
    "Critical API Issue": {
        "likely_root_cause": "More than 30% of API calls are failing, indicating a critical system-wide issue. This could be a major outage, infrastructure failure, or a catastrophic bug affecting most requests.",
        "impact": "A significant portion of users cannot use the service. Revenue and user trust are directly at risk. Escalation is required immediately.",
        "debugging_steps": [
            "Check system-wide health dashboards for infrastructure anomalies.",
            "Review the deployment history for recent changes that correlate with the error spike.",
            "Verify database cluster health and replication status.",
            "Check network connectivity between services and to external dependencies.",
            "Engage the on-call team and escalate to incident management.",
        ],
        "recommended_fix": [
            "Initiate an incident response process immediately.",
            "Roll back the last deployment if it correlates with the spike.",
            "Failover to backup infrastructure if the primary is degraded.",
            "Enable maintenance mode and communicate status to users.",
        ],
        "prevention_tips": [
            "Implement progressive delivery (canary/blue-green) for all deployments.",
            "Set up PagerDuty or OpsGenie alerts for error rate thresholds.",
            "Run regular gamedays and tabletop exercises for incident response.",
            "Maintain a tested rollback procedure for every service.",
        ],
    },
}

_SEVERITY_REASONING_MAP = {
    "Critical": "This issue is classified as Critical due to a high occurrence count (>20) or extreme latency combined with 5xx errors. Immediate action is required to prevent user impact and potential data loss.",
    "High": "This issue is classified as High severity because it occurs frequently (>10 times) or causes significant latency (>2000ms). It should be addressed in the current sprint.",
    "Medium": "This issue is classified as Medium severity with moderate occurrence (>5 times). It should be prioritized in the next sprint to prevent escalation.",
    "Low": "This issue is classified as Low severity with limited occurrence. Monitor for escalation and address when bandwidth allows.",
}


_cache: Dict[str, Dict[str, Any]] = {}


def _cache_key(issue: Dict[str, Any]) -> str:
    return f"{issue.get('issue_type', '')}|{issue.get('endpoint', '')}|{issue.get('status_code', 0)}|{issue.get('service', '')}"


def _rule_based_explanation(issue: Dict[str, Any]) -> Dict[str, Any]:
    key = _cache_key(issue)
    if key in _cache:
        return _cache[key]

    issue_type = issue.get("issue_type", "Server Error")
    severity = issue.get("severity", "Low")

    base = _ROOT_CAUSE_MAP.get(issue_type, _ROOT_CAUSE_MAP["Server Error"])
    endpoint = issue.get("endpoint", "unknown endpoint")
    service = issue.get("service", "unknown service")
    occurrences = issue.get("occurrences", 0)
    avg_latency = issue.get("average_latency", 0)
    error_msg = issue.get("error_message") or "N/A"

    root_cause = (
        f"[{service}] {base['likely_root_cause']} "
        f"Observed {occurrences} occurrences on {endpoint} "
        f"with avg latency {avg_latency}ms. Last error: '{error_msg}'."
    )

    result = {
        "likely_root_cause": root_cause,
        "impact": base["impact"],
        "debugging_steps": base["debugging_steps"],
        "recommended_fix": base["recommended_fix"],
        "prevention_tips": base["prevention_tips"],
        "severity_reasoning": _SEVERITY_REASONING_MAP.get(severity, _SEVERITY_REASONING_MAP["Low"]),
    }

    result["_source"] = "rule"
    _cache[key] = result
    return result


GROQ_SYSTEM_PROMPT = (
    "You are an expert API debugging agent. "
    "Analyze the issue and return ONLY valid JSON with these keys: "
    "likely_root_cause, impact, debugging_steps, recommended_fix, prevention_tips, severity_reasoning."
)

GROQ_USER_PROMPT_TEMPLATE = """Issue:
- Endpoint: {endpoint}
- Method: {method}
- Status: {status_code}
- Error: {error_message}
- Service: {service}
- Occurrences: {occurrences}
- Avg Latency: {average_latency}ms
- Type: {issue_type}
- Severity: {severity}

Return JSON with: likely_root_cause (string), impact (string), debugging_steps (list), recommended_fix (list), prevention_tips (list), severity_reasoning (string)."""


def _groq_explanation(client, issue: Dict[str, Any]) -> Dict[str, Any]:
    prompt = GROQ_USER_PROMPT_TEMPLATE.format(
        endpoint=issue.get("endpoint", "unknown"),
        method=issue.get("method", "GET"),
        status_code=issue.get("status_code", 0),
        error_message=issue.get("error_message") or "N/A",
        service=issue.get("service", "unknown"),
        occurrences=issue.get("occurrences", 0),
        average_latency=issue.get("average_latency", 0),
        issue_type=issue.get("issue_type", "Unknown"),
        severity=issue.get("severity", "Low"),
    )

    response = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[
            {"role": "system", "content": GROQ_SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
        temperature=0.3,
        max_tokens=800,
    )

    raw = response.choices[0].message.content.strip()
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    result = json.loads(raw)
    result["_source"] = "groq"
    return result


def explain_issue(issue: Dict[str, Any]) -> Dict[str, Any]:
    client = _get_groq_client_cached()

    if client:
        try:
            return _groq_explanation(client, issue)
        except Exception as e:
            print(f"[ai_agent] Groq call failed ({e}), using rule-based.")

    return _rule_based_explanation(issue)


def explain_issues_batch(issues: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    total = len(issues)
    if total == 0:
        return issues

    print(f"[ai_agent] Starting AI explanations for {total} issues (parallel)...")

    def explain_wrapper(issue: Dict[str, Any]) -> Dict[str, Any]:
        try:
            issue["ai_debug"] = explain_issue(issue)
        except Exception as e:
            issue["ai_debug"] = {"error": f"Auto-debug failed: {str(e)}"}
        return issue

    done = 0
    with ThreadPoolExecutor(max_workers=5) as pool:
        futures = [pool.submit(explain_wrapper, issue) for issue in issues]
        for future in as_completed(futures):
            done += 1
            if done % 3 == 0 or done == total:
                print(f"[ai_agent] Progress: {done}/{total} issues explained")

    print(f"[ai_agent] All {total} issues explained.")
    return issues
