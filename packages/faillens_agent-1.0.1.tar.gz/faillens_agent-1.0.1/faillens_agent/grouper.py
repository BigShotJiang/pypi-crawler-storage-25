import math
from datetime import datetime
from typing import List, Dict, Any


def _percentile(sorted_latencies: List[float], p: float) -> float:
    if not sorted_latencies:
        return 0.0
    k = (len(sorted_latencies) - 1) * p
    f = math.floor(k)
    c = math.ceil(k)
    if f == c:
        return sorted_latencies[int(k)]
    return sorted_latencies[f] * (c - k) + sorted_latencies[c] * (k - f)


def _parse_ts(ts: str):
    if not ts:
        return None
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(ts, fmt)
        except ValueError:
            pass
    return None


def group_failures(annotated_logs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    groups: Dict[tuple, Dict[str, Any]] = {}

    for log in annotated_logs:
        if not log.get("issue_type"):
            continue

        key = (
            log.get("endpoint", "unknown"),
            log.get("status_code", 0),
            log.get("error_message") or "",
        )

        if key not in groups:
            groups[key] = {
                "endpoint": log.get("endpoint", "unknown"),
                "method": log.get("method", "GET"),
                "status_code": log.get("status_code", 0),
                "error_message": log.get("error_message"),
                "service": log.get("service", "unknown"),
                "occurrences": 0,
                "total_latency": 0.0,
                "latencies": [],
                "user_ids": set(),
                "first_seen": log.get("timestamp"),
                "last_seen": log.get("timestamp"),
                "issue_type": log.get("issue_type"),
            }

        g = groups[key]
        g["occurrences"] += 1
        lat = log.get("latency_ms", 0)
        g["total_latency"] += lat
        g["latencies"].append(lat)

        uid = log.get("user_id") or log.get("user")
        if uid:
            g["user_ids"].add(str(uid))

        ts = log.get("timestamp", "")
        if ts < g["first_seen"]:
            g["first_seen"] = ts
        if ts > g["last_seen"]:
            g["last_seen"] = ts

    result = []
    for g in groups.values():
        sorted_lat = sorted(g["latencies"])
        avg_latency = g["total_latency"] / g["occurrences"] if g["occurrences"] else 0
        p95 = _percentile(sorted_lat, 0.95)
        p99 = _percentile(sorted_lat, 0.99)

        first_dt = _parse_ts(g["first_seen"])
        last_dt = _parse_ts(g["last_seen"])
        duration_min = round((last_dt - first_dt).total_seconds() / 60, 1) if first_dt and last_dt else 0

        result.append({
            "endpoint": g["endpoint"],
            "method": g["method"],
            "status_code": g["status_code"],
            "error_message": g["error_message"],
            "service": g["service"],
            "occurrences": g["occurrences"],
            "average_latency": round(avg_latency, 2),
            "p95_latency": round(p95, 2),
            "p99_latency": round(p99, 2),
            "incident_duration_min": duration_min,
            "affected_users": len(g["user_ids"]),
            "first_seen": g["first_seen"],
            "last_seen": g["last_seen"],
            "issue_type": g["issue_type"],
            "severity": "",
        })

    result.sort(key=lambda x: x["occurrences"], reverse=True)
    return result
