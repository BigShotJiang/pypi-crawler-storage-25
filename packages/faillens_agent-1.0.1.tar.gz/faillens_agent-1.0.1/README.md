# FailLens Agent

Local AI debugging agent - detect, group, score, debug, and explain API failures.

## Install

```bash
pip install faillens-agent
```

For AI-powered explanations (optional):
```bash
pip install faillens-agent[ai]
export GROQ_API_KEY="gsk_your_key_here"
```

## Usage

```bash
# Analyze a log file
faillens analyze logs.json --pretty

# Watch a directory for new logs
faillens watch ./logs

# Run local API server
faillens serve

# Explain a single issue
faillens explain issue.json --pretty
```

## Pipeline

detect > group > score > debug > explain
