"""Utility functions."""

from collections.abc import Iterator
from datetime import datetime
from inspect import Signature
from types import NoneType, UnionType
from typing import Union, get_args, get_origin


def find_artifact_args(sig: Signature) -> Iterator[str]:
    """Find function arguments suitable for artifact substitutions.

    This function filters out any arguments that are annotated to accept
    ``str`` or ``tuple[str, datetime | str | int | None]``. Implementation
    built based on :cite:`74544539`.

    .. bibliography:: refs.bib

    Parameters
    ----------
    sig : Signature
        The signature of a function to search.

    Returns
    -------
    list[str]
        A tuple containing the arguments that can be substituted with
        an artifact at runtime.

    Examples
    --------
    This utility function is designed to help ``spacecadet`` avoid erroneously
    substituting function parameterization with artifacts. Suppose you had the
    following function:

    >>> def myprinter(features: list[str], model_name: str):
    ...     print(f"Model {model_name} has features: {', '.join(features)}")

    When we supply a value for ``model_name`` in the context of
    :py:class:`spacecadet.threading.CadetThread` with an attached repository or experiment,
    we don't want to try and load an artifact for ``model_name``. So, we use this function
    to search for parameters that are annotated with other types:

    >>> import inspect
    >>> sig = inspect.signature(myprinter)
    >>> list(find_artifact_args(sig))
    ['features']

    This function is also robust to tuples. Suppose our models had either a name or
    a number:

    >>> def myprinter(features: list[str], model_name: str | int):
    ...     print(f"Model {model_name!s} has features: {', '.join(features)}")
    >>> sig = inspect.signature(myprinter)
    >>> list(find_artifact_args(sig))
    ['features']

    Finally, and this is a longshot, suppose you have a function that accepts a tuple
    where the first argument is a string and the second argument can contain a datetime,
    string, integer, or a null value. This also characterizes a function argument we want
    to avoid replacing.

    >>> def myprinter(features: list[str], model_name: tuple[str, str]):
    ...     pass  # We've outgrown this example, haven't we...
    >>> sig = inspect.signature(myprinter)
    >>> list(find_artifact_args(sig))
    ['features']

    This corner case is also covered in the case of tuples:

    >>> def myprinter(features: list[str], model_name: tuple[str, str | int]):
    ...     pass
    >>> sig = inspect.signature(myprinter)
    >>> list(find_artifact_args(sig))
    ['features']
    """
    for name, param in sig.parameters.items():
        if param.annotation is str:
            continue
        if (origin_ := get_origin(param.annotation)) in (
            Union,
            UnionType,
        ) and str in get_args(param.annotation):
            continue
        if origin_ is tuple:
            args_ = get_args(param.annotation)
            if len(args_) == 2 and args_[0] is str:
                # We have a tuple where the first argument is a string,
                # check for the second argument
                if args_[1] in (datetime, str, int, NoneType):
                    continue
                if get_origin(args_[1]) in (Union, UnionType) and any(
                    type_ in get_args(args_[1])
                    for type_ in (datetime, str, int, NoneType)
                ):
                    continue

        yield name
