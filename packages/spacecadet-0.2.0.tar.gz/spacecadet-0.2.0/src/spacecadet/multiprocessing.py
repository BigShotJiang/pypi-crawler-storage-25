"""Process-based execution."""

import functools
import inspect
from collections.abc import Callable
from datetime import datetime
from multiprocessing import Process
from multiprocessing.sharedctypes import Synchronized
from typing import TypedDict

from spacecadet.protocols import HasArtifacts
from spacecadet.semaphore import ProcessSemaphore
from spacecadet.utils import find_artifact_args


class ProcessTracking(TypedDict):
    """Multiprocessing tracking structural type."""

    available_resources: Synchronized
    num_processes: int


class CadetProcess(Process):
    """Custom multiprocessing executor.

    This extension of :py:class:`multiprocessing.Process` allows users to overwrite
    supplied function arguments at runtime with artifacts from Lazyscribe. It also
    allows users to wait for and release multiple processes.
    """

    def options(
        self,
        num_processes: ProcessTracking | None = None,
        source: HasArtifacts | None = None,
    ) -> None:
        """Set optional functionality on the process.

        This functionality allows us to add multi-permit allocator as well as an
        artifact source.

        Parameters
        ----------
        num_processes : ProcessTracking, optional (default None)
            An optional dictionary specifying the number of available resources (as an
            instance of ``multiprocessing.Value``) and the number of required processes (as an
            integer).
        source : HasArtifacts, optional (default None)
            A Lazyscribe-style object that provides the ability to load artifacts
            from a filesystem. Common examples include :py:class:`lazyscribe.repository.Repository`,
            :py:class:`lazyscribe.experiment.Experiment`, and :py:class:`lazyscribe.test.Test`.
        """
        if num_processes is not None:
            self._process_options = num_processes
        if source is not None:
            self._source = source

    def run(self):
        """Run the specified function.

        The input arguments may be modified based on whether a ``source`` is added. This function
        parses the signature of the upstream function, looking for string arguments to parameters
        that are annotated with a non-string type :cite:`74544539`.

        .. bibliography:: refs.bib
        """
        # Acquire process permits
        allocator_: ProcessSemaphore
        if hasattr(self, "_process_options"):
            allocator_ = ProcessSemaphore(self._process_options["available_resources"])
            _required_processes = self._process_options["num_processes"]
        else:
            allocator_ = ProcessSemaphore()
            _required_processes = 1
        allocator_.acquire(_required_processes)

        if self._target is not None:  # ty: ignore[unresolved-attribute]
            sig_ = inspect.signature(self._target)  # ty: ignore[unresolved-attribute]
            bound_ = sig_.bind(*self._args, **self._kwargs)  # ty: ignore[unresolved-attribute]

            if hasattr(self, "_source"):
                for param in find_artifact_args(sig_):
                    value = bound_.arguments[param]
                    match value:
                        case str():
                            bound_.arguments[param] = self._source.load_artifact(
                                name=value
                            )
                        case (str(), datetime() | str() | int() | None):
                            bound_.arguments[param] = self._source.load_artifact(
                                name=value[0], version=value[1]
                            )

            self._target(*bound_.args, **bound_.kwargs)  # ty: ignore[unresolved-attribute]

        # Release processes
        allocator_.release(_required_processes)


def cadet(
    function: Callable[..., object] | None = None,
    /,
    *,
    num_processes: int = 1,
    source: HasArtifacts | None = None,
):
    """Wrap a function and return an instance of :py:class:`spacecadet.multiprocessing.CadetProcess`.

    Parameters
    ----------
    function : callable, optional (default None)
        The function to decorate. Note that this parameter is included in the signature
        of the decorator to allow the decorator to work with or without arguments :cite:`653368`.

        .. bibliography:: refs.bib
    num_processes : int, optional (default 1)
        Number of processes to reserve for the provided function.
    source : HasArtifacts, optional (default None)
        A source lazyscribe-like object that can provide objects at runtime. When
        :py:meth:`spacecadet.threading.CadetThread.start` is called, the objects will be loaded.
    """

    def _inner_deco(func: Callable[..., object]):
        @functools.wraps(func)
        def wrapped(*args, **kwargs):
            """We substitute the arguments here."""
            semaphore = ProcessSemaphore()
            process = CadetProcess(target=func, args=args, kwargs=kwargs)
            process.options(
                num_processes={
                    "available_resources": semaphore.available_resources,
                    "num_processes": num_processes,
                },
                source=source,
            )

            return process

        return wrapped

    if callable(function):
        return _inner_deco(function)

    return _inner_deco
