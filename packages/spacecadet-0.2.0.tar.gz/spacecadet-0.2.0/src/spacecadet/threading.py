"""Threading-based execution."""

import functools
import inspect
from collections.abc import Callable
from datetime import datetime
from threading import Thread

from spacecadet.protocols import HasArtifacts
from spacecadet.semaphore import ThreadedSemaphore
from spacecadet.utils import find_artifact_args


class CadetThread(Thread):
    """Custom multithreading executor.

    This extension of the threading class allows users to overwrite supplied function
    arguments at runtime with artifacts from Lazyscribe. It also allows users to wait
    for and release multiple threads.
    """

    def options(
        self,
        num_threads: int | None = None,
        source: HasArtifacts | None = None,
    ) -> None:
        """Set optional functionality on the thread.

        This function allows us to add multi-permit allocators as well as an
        artifact source.

        Parameters
        ----------
        num_threads : int, optional (default None)
            The number of threads to request and release upon completion.
        source : HasArtifacts
            A Lazyscribe-style object that provides the ability to load artifacts
            from a filesystem. Common examples include :py:class:`lazyscribe.repository.Repository`,
            :py:class:`lazyscribe.experiment.Experiment`, and :py:class:`lazyscribe.test.Test`.
        """
        if num_threads is not None:
            self._required_threads = num_threads
        if source is not None:
            self._source = source

    def run(self):
        """Run the specified function.

        The input arguments may be modified based on whether a ``source`` is added. This function
        parses the signature of the upstream function, looking for string arguments to parameters
        that are annotated with a non-string type :cite:`74544539`.

        .. bibliography:: refs.bib
        """
        # Acquire thread permits
        allocator_ = ThreadedSemaphore()  # Singleton instance
        allocator_.acquire(getattr(self, "_required_threads", 1))

        if self._target is not None:  # ty: ignore[unresolved-attribute]
            sig_ = inspect.signature(self._target)  # ty: ignore[unresolved-attribute]
            bound_ = sig_.bind(*self._args, **self._kwargs)  # ty: ignore[unresolved-attribute]

            if hasattr(self, "_source"):
                for param in find_artifact_args(sig_):
                    value = bound_.arguments[param]
                    match value:
                        case str():
                            bound_.arguments[param] = self._source.load_artifact(
                                name=value
                            )
                        case (str(), datetime() | str() | int() | None):
                            bound_.arguments[param] = self._source.load_artifact(
                                name=value[0], version=value[1]
                            )

            self._target(*bound_.args, **bound_.kwargs)  # ty: ignore[unresolved-attribute]

        # Release resources
        allocator_.release(getattr(self, "_required_threads", 1))


def cadet(
    function: Callable[..., object] | None = None,
    /,
    *,
    num_threads: int | None = None,
    source: HasArtifacts | None = None,
):
    """Wrap a function and return an instance of :py:class:`spacecadet.threading.CadetThread`.

    Parameters
    ----------
    function : callable, optional (default None)
        The function to decorate. Note that this parameter is included in the signature
        of the decorator to allow the decorator to work with or without arguments :cite:`653368`.

        .. bibliography:: refs.bib
    num_threads : int, optional (default None)
        Number of threads to reserve for the provided function.
    source : HasArtifacts, optional (default None)
        A source lazyscribe-like object that can provide objects at runtime. When
        :py:meth:`spacecadet.threading.CadetThread.start` is called, the objects will be loaded.
    """

    def _inner_deco(func: Callable[..., object]):
        @functools.wraps(func)
        def wrapped(*args, **kwargs):
            """We substitute the arguments here."""
            thread = CadetThread(target=func, args=args, kwargs=kwargs)
            thread.options(num_threads=num_threads, source=source)

            return thread

        return wrapped

    if callable(function):
        return _inner_deco(function)

    return _inner_deco
