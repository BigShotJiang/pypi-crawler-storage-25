"""Semaphore that allows for acquisition of multiple resources at once."""

import multiprocessing
import os
import threading
from multiprocessing.sharedctypes import Synchronized
from typing import ClassVar
from weakref import WeakValueDictionary, proxy


class ThreadSafeSingletonMeta(type):
    """Thread-safe singleton metaclass.

    This metaclass ensures that only one instance of the type exist.
    Implementation built by :cite:`singleton` and :cite:`43619748`.

    .. bibliography:: refs.bib
    """

    _instances: ClassVar[WeakValueDictionary] = WeakValueDictionary()
    _lock: threading.Lock = threading.Lock()

    def __call__(cls, *args, **kwargs):
        """Called during initialization of a class using this metaclass.

        This method ensures that there is only one instance of the particular
        class.
        """
        with cls._lock:
            if cls not in cls._instances:
                instance = super().__call__(*args, **kwargs)
                cls._instances[cls] = instance

        return cls._instances[cls]


class ThreadedSemaphore(metaclass=ThreadSafeSingletonMeta):
    """Wait for multiple threads to be available.

    This implementation was mostly written by :cite:`69366850`, with
    one notable extension. This class is a *singleton*. That means
    that there is only one semaphore object available at runtime.

    .. bibliography:: refs.bib

    Parameters
    ----------
    total_threads : int, optional (default None)
        The number of available threads. If not supplied, the class
        will look for the environment variable `SPACECADET_MAX_THREADS`.
        If the environment variable is not set, we will use the number of
        cores detected on the source machine (using :py:meth:`os.cpu_count`).
        If that method returns `None`, the total number of available threads
        will be set to 1.

    Examples
    --------
    Suppose you have a 4-core system. Let's acquire 2 threads:

    >>> counter = ThreadedSemaphore(4)
    >>> counter.acquire(2)
    >>> counter.locked()
    False

    Now, if we acquire 2 more resources and check the status of the counter we will
    find it locked:

    >>> counter.acquire(2)
    >>> counter.locked()
    True

    We have to release resources before we can use more:

    >>> counter.release(2)
    >>> counter.locked()
    False
    """

    def __init__(self, total_threads: int | None = None, /):
        """Init method."""
        match total_threads:
            case int():
                self._available_resources = total_threads
            case None:
                if (
                    user_set_threads_ := os.getenv("SPACECADET_MAX_THREADS")
                ) is not None:
                    self._available_resources = int(user_set_threads_)
                elif (sys_threads_ := os.cpu_count()) is not None:
                    self._available_resources = sys_threads_
                else:
                    self._available_resources = 1

        self._mutex = threading.Lock()
        self._condition = threading.Condition()

    def acquire(self, threads: int = 1, timeout: float = 60, /) -> None:
        """Acquire threads or wait until they are available.

        Parameters
        ----------
        threads : int, optional (default 1)
            The number of threads to acquire.
        timeout : float, optional (default 60)
            The number of seconds to wait.
        """
        with self._condition:
            self._condition.wait_for(lambda: not self.locked(threads), timeout=timeout)
            with self._mutex:
                self._available_resources -= threads

    def locked(self, threads: int = 1, /) -> bool:
        """Check whether there are available threads.

        Parameters
        ----------
        threads : int, optional (default 1)
            The number of threads.

        Returns
        -------
        bool
            Evaluates to ``False`` if :py:meth:`spacecadet.semaphore.ThreadedSemaphore.acquire`
            would return immediately.
        """
        return self._available_resources < threads

    def release(self, threads: int = 1, /) -> None:
        """Release the acquired resources.

        Parameters
        ----------
        threads : int, optional (default 1)
            The number of threads to release.
        """
        with self._condition:
            with self._mutex:
                self._available_resources += threads
            self._condition.notify_all()

    def __str__(self):
        """String representation of the allocator."""
        return f"Allocator: {self._available_resources} available threads"

    def __enter__(self):
        """Enter the context manager.

        We can use the context manager to ensure maximum thread usage in a block of code.
        Use of :py:meth:`weakref.proxy` based on :cite:`36002705`.
        """
        return proxy(self)

    def __exit__(self, *exc):
        """Exiting the context manager.

        On exit, we should be able to clear the semaphore object.
        """


class ProcessSemaphore(metaclass=ThreadSafeSingletonMeta):
    """Wait for multiple processes to be available.

    This implementation was mostly written by :cite:`69366850`. Importantly,
    this semaphore object uses :py:class:`multiprocessing.Value`. That means
    that out of the box this class is not compatible with pools. To use this
    semaphore, supply an instance to the target process directly.

    This class is a *singleton*. That means there is only one semaphore object
    available at runtime. However, singletons are not preserved in the
    multiprocessing context. This design is meant to ensure that the maximum
    number of processes available is consistent across the main process.

    .. bibliography:: refs.bib

    Parameters
    ----------
    total_processes : int | Synchronized[int], optional (default None)
        The number of available resources. If not supplied, the class will look
        for the environment variable `SPACECADET_MAX_PROCESSES`. If the environment
        variable is not set, we will use the number of cores detected on the source machine
        (using :py:meth:`os.cpu_count`). If that method returns `None`, the total number
        of available cores will be set to 1.

    Examples
    --------
    Suppose you have a 4-core system. Let's acquire 2 cores:

    >>> counter = ProcessSemaphore(4)
    >>> counter.acquire(2)
    >>> counter.locked()
    False

    Now, if we acquire 2 more resources and check the status of the counter we will
    find it locked:

    >>> counter.acquire(2)
    >>> counter.locked()
    True

    We have to release resources before we can use more:

    >>> counter.release(2)
    >>> counter.locked()
    False
    """

    def __init__(self, total_processes: int | Synchronized | None = None, /):
        """Init method."""
        self._available_resources: Synchronized
        match total_processes:
            case int():
                self._available_resources = multiprocessing.Value("i", total_processes)
            case Synchronized():
                self._available_resources = total_processes
            case None:
                if (
                    user_set_processes_ := os.getenv("SPACECADET_MAX_PROCESSES")
                ) is not None:
                    self._available_resources = multiprocessing.Value(
                        "i", int(user_set_processes_)
                    )
                elif (sys_cores_ := os.cpu_count()) is not None:
                    self._available_resources = multiprocessing.Value("i", sys_cores_)
                else:
                    self._available_resources = multiprocessing.Value("i", 1)

        self._condition = multiprocessing.Condition()

    @property
    def available_resources(self) -> Synchronized:
        """Return the current available resources.

        This property is typically accessed in order to share the value
        between processes.

        Returns
        -------
        Synchronized[int]
            The ``multiprocessing.Value`` value.
        """
        return self._available_resources

    def acquire(self, cores: int = 1, timeout: float = 60, /) -> None:
        """Acquire cores or wait until they are available.

        Parameters
        ----------
        cores : int, optional (default 1)
            The number of cores/threads to acquire.
        timeout : float, optional (default 60)
            The number of seconds to wait.
        """
        with self._condition:
            self._condition.wait_for(lambda: not self.locked(cores), timeout=timeout)
            with self._available_resources.get_lock():
                self._available_resources.value -= cores

    def locked(self, cores: int = 1, /) -> bool:
        """Check whether there are available resources.

        Parameters
        ----------
        cores : int, optional (default 1)
            The number of cores/threads.

        Returns
        -------
        bool
            Evaluates to ``False`` if :py:meth:`spacecadet.semaphore.MultiPermitSemaphore.aquire`
            would return immediately.
        """
        return self._available_resources.value < cores

    def release(self, cores: int = 1, /) -> None:
        """Release the acquired cores.

        Parameters
        ----------
        cores : int, optional (default 1)
            The number of cores to release.
        """
        with self._condition:
            with self._available_resources.get_lock():
                self._available_resources.value += cores
            self._condition.notify_all()

    def __str__(self):
        """String representation of the allocator."""
        return f"Allocator: {self._available_resources.value} available processes"

    def __enter__(self):
        """Enter the context manager.

        We can use the context manager to ensure maximum thread usage in a block of code.
        Use of :py:meth:`weakref.proxy` based on :cite:`36002705`.
        """
        return proxy(self)

    def __exit__(self, *exc):
        """Exiting the context manager.

        On exit, we should be able to clear the semaphore object.
        """
