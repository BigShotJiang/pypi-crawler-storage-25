"""Generic protocols for use across the codebase."""

from datetime import datetime
from typing import Any, Literal, Protocol


class HasArtifacts(Protocol):
    """A protocol that identifies any class that supports artifact loading."""

    def load_artifact(
        self,
        name: str,
        validate: bool = True,
        version: datetime | str | int | None = None,
        match: Literal["asof", "exact"] = "exact",
        **kwargs: Any,
    ) -> Any: ...
