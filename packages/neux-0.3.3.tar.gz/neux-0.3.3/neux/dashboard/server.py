"""Dashboard HTTP server — stdlib ``http.server`` only, no Flask/FastAPI.

Serves two things on a single port:

1. The static React build under ``neux/dashboard/app/dist/``
2. JSON endpoints under ``/api/*`` — see :mod:`neux.dashboard.api`

The JSON layer opens a fresh :class:`GraphEngine` per request so the server
never holds long-lived DB connections. That keeps hook invocations
(which also hit SQLite) from blocking on WAL checkpoints.
"""

from __future__ import annotations

import errno
import json
import re
import socket
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable
from urllib.parse import parse_qs, urlparse

from neux.dashboard import api
from neux.engine import GraphEngine

BUILD_DIR = Path(__file__).parent / "app" / "dist"

# (regex, handler) — handlers receive (engine, match, query, body)
Route = tuple[re.Pattern[str], Callable[..., Any], str]


def _build_routes() -> list[Route]:
    return [
        (re.compile(r"^/api/overview/?$"), _handle_overview, "GET"),
        (re.compile(r"^/api/graph/?$"), _handle_graph, "GET"),
        (re.compile(r"^/api/graph/impact/(?P<node_id>.+)$"), _handle_graph_impact, "GET"),
        (re.compile(r"^/api/patterns/?$"), _handle_patterns, "GET"),
        (re.compile(r"^/api/patterns/(?P<pattern_id>[^/]+)/confirm$"), _handle_confirm_pattern, "POST"),
        (re.compile(r"^/api/patterns/(?P<pattern_id>[^/]+)/discard$"), _handle_discard_pattern, "POST"),
        (re.compile(r"^/api/conventions/?$"), _handle_conventions, "GET"),
        (re.compile(r"^/api/conventions/(?P<convention_id>[^/]+)/confirm$"), _handle_confirm_convention, "POST"),
        (re.compile(r"^/api/conventions/(?P<convention_id>[^/]+)/discard$"), _handle_discard_convention, "POST"),
        (re.compile(r"^/api/inconsistencies/?$"), _handle_inconsistencies, "GET"),
        (re.compile(r"^/api/modules/?$"), _handle_modules, "GET"),
        (re.compile(r"^/api/modules/(?P<name>[^/]+)$"), _handle_module_detail, "GET"),
        (re.compile(r"^/api/sessions/?$"), _handle_sessions, "GET"),
        (re.compile(r"^/api/rules/?$"), _handle_add_rule, "POST"),
    ]


# ======================================================================
# Handler impls — return (status, payload)
# ======================================================================


def _handle_overview(engine, match, query, body):
    return 200, api.overview(engine)


def _handle_graph(engine, match, query, body):
    module_filter = query.get("module", [None])[0]
    return 200, api.graph(engine, module_filter=module_filter)


def _handle_graph_impact(engine, match, query, body):
    node_id = match.group("node_id")
    depth = int(query.get("depth", ["3"])[0])
    direction = query.get("direction", ["forward"])[0]
    return 200, api.graph_impact(engine, node_id=node_id, depth=depth, direction=direction)


def _handle_patterns(engine, match, query, body):
    status = query.get("status", [None])[0]
    return 200, api.patterns(engine, status=status)


def _handle_conventions(engine, match, query, body):
    status = query.get("status", [None])[0]
    return 200, api.conventions(engine, status=status)


def _handle_inconsistencies(engine, match, query, body):
    status = query.get("status", ["open"])[0]
    return 200, api.inconsistencies(engine, status=status)


def _handle_modules(engine, match, query, body):
    return 200, api.modules(engine)


def _handle_module_detail(engine, match, query, body):
    data = api.module_detail(engine, match.group("name"))
    if data is None:
        return 404, {"error": "module not found"}
    return 200, data


def _handle_sessions(engine, match, query, body):
    return 200, api.sessions(engine, project_root=str(engine.project_path))


def _handle_confirm_pattern(engine, match, query, body):
    return 200, api.confirm_pattern(engine, match.group("pattern_id"))


def _handle_discard_pattern(engine, match, query, body):
    return 200, api.discard_pattern(engine, match.group("pattern_id"))


def _handle_confirm_convention(engine, match, query, body):
    return 200, api.confirm_convention(engine, match.group("convention_id"))


def _handle_discard_convention(engine, match, query, body):
    return 200, api.discard_convention(engine, match.group("convention_id"))


def _handle_add_rule(engine, match, query, body):
    data = api.add_rule(engine, body or {})
    if "error" in data:
        return 400, data
    return 201, data


# ======================================================================
# Request handler
# ======================================================================


class _DashboardHandler(BaseHTTPRequestHandler):
    project_root: Path = Path.cwd()
    routes: list[Route] = []
    build_dir: Path = BUILD_DIR

    # Silence default logging noise
    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        return

    # ------------------------------------------------------------------

    def do_GET(self) -> None:  # noqa: N802
        self._dispatch("GET")

    def do_POST(self) -> None:  # noqa: N802
        self._dispatch("POST")

    def _dispatch(self, method: str) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)

        if path.startswith("/api/"):
            self._handle_api(method, path, query)
            return

        if method != "GET":
            self._send_json(405, {"error": "method not allowed"})
            return
        self._serve_static(path)

    # ------------------------------------------------------------------
    # API
    # ------------------------------------------------------------------

    def _handle_api(self, method: str, path: str, query: dict) -> None:
        body: dict | None = None
        if method == "POST":
            length = int(self.headers.get("Content-Length", "0") or 0)
            raw = self.rfile.read(length) if length else b""
            if raw:
                try:
                    body = json.loads(raw.decode("utf-8"))
                except json.JSONDecodeError:
                    self._send_json(400, {"error": "invalid JSON body"})
                    return

        for pattern, handler, expected_method in self.routes:
            match = pattern.match(path)
            if match is None:
                continue
            if expected_method != method:
                self._send_json(405, {"error": "method not allowed"})
                return
            try:
                engine = GraphEngine(self.project_root)
                try:
                    status, payload = handler(engine, match, query, body)
                finally:
                    engine.close()
            except Exception as exc:  # noqa: BLE001
                self._send_json(500, {"error": f"{type(exc).__name__}: {exc}"})
                return
            self._send_json(status, payload)
            return

        self._send_json(404, {"error": "not found", "path": path})

    def _send_json(self, status: int, payload: Any) -> None:
        body = json.dumps(payload, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    # ------------------------------------------------------------------
    # Static
    # ------------------------------------------------------------------

    def _serve_static(self, path: str) -> None:
        if not self.build_dir.exists():
            self._send_placeholder()
            return

        relative = path.lstrip("/")
        if not relative:
            relative = "index.html"
        candidate = (self.build_dir / relative).resolve()
        try:
            candidate.relative_to(self.build_dir.resolve())
        except ValueError:
            self._send_json(403, {"error": "forbidden"})
            return

        if candidate.is_dir():
            candidate = candidate / "index.html"
        if not candidate.is_file():
            # SPA fallback
            candidate = self.build_dir / "index.html"
            if not candidate.is_file():
                self._send_placeholder()
                return

        content_type = _content_type_for(candidate.suffix)
        data = candidate.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _send_placeholder(self) -> None:
        html = b"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>NEUX dashboard</title>
<style>body{background:#050508;color:#c9d1d9;font-family:system-ui,monospace;
padding:40px;line-height:1.6}h1{color:#00e5ff;letter-spacing:.08em}code{color:#a4ff00}</style>
</head><body>
<h1>NEUX DASHBOARD</h1>
<p>The React build is missing. Run:</p>
<pre><code>cd neux/dashboard/app
npm install
npm run build</code></pre>
<p>Then refresh this page. The JSON API is live at
<a style="color:#00e5ff" href="/api/overview">/api/overview</a>.</p>
</body></html>"""
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(html)))
        self.end_headers()
        self.wfile.write(html)


_MIME: dict[str, str] = {
    ".html": "text/html; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".mjs": "application/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".ico": "image/x-icon",
    ".woff": "font/woff",
    ".woff2": "font/woff2",
    ".ttf": "font/ttf",
    ".map": "application/json",
    ".txt": "text/plain; charset=utf-8",
}


def _content_type_for(suffix: str) -> str:
    return _MIME.get(suffix.lower(), "application/octet-stream")


# ======================================================================
# Public entrypoint
# ======================================================================


def _bind_server(handler_cls, preferred_port: int, max_attempts: int = 20) -> ThreadingHTTPServer:
    """Bind the dashboard to preferred_port, falling back to the next free
    port if it's taken. Lets multiple NEUX dashboards coexist on the same
    machine (one per project) without EADDRINUSE crashes."""
    last_err: OSError | None = None
    for offset in range(max_attempts):
        candidate = preferred_port + offset
        try:
            return ThreadingHTTPServer(("127.0.0.1", candidate), handler_cls)
        except OSError as exc:
            if exc.errno not in (errno.EADDRINUSE, errno.EACCES):
                raise
            last_err = exc
            continue
    raise OSError(
        f"No free port in range {preferred_port}-{preferred_port + max_attempts - 1}"
    ) from last_err


def serve(project_root: Path, port: int = 7777, open_browser: bool = True) -> None:
    """Run the dashboard server in the current thread until Ctrl-C."""

    class Handler(_DashboardHandler):
        pass

    Handler.project_root = Path(project_root).resolve()
    Handler.routes = _build_routes()

    httpd = _bind_server(Handler, preferred_port=port)
    bound_port = httpd.server_address[1]

    url = f"http://127.0.0.1:{bound_port}"
    if bound_port != port:
        print(f"[NEUX] port {port} busy → using {bound_port}")
    print(f"[NEUX] dashboard serving at {url}")
    from neux.dashboard.api import _read_project_name
    project_name = _read_project_name(Handler.project_root)
    print(f"[NEUX] project: {project_name} ({Handler.project_root})")
    print(f"[NEUX] build dir: {BUILD_DIR}")
    if not BUILD_DIR.exists():
        print("[NEUX] (React build missing — showing placeholder)")

    if open_browser:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[NEUX] shutting down")
    finally:
        httpd.server_close()
