"""Generator + CLI integration tests."""

from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

from neux.categorizer import TaskCategorizer
from neux.cli import app
from neux.engine import GraphEngine
from neux.generator.claude_md import generate_all
from neux.scanner import ProjectScanner

runner = CliRunner()


def test_categorizer_picks_style_change() -> None:
    cat = TaskCategorizer().categorize("cambiar el color del boton", "components/Button.tsx")
    assert cat.category == "style_change"


def test_categorizer_falls_back_to_general() -> None:
    cat = TaskCategorizer().categorize("", "")
    assert cat.category == "general"


def test_generator_writes_claude_md(mixed_project: Path) -> None:
    engine = GraphEngine(mixed_project)
    ProjectScanner(engine).scan_project(mixed_project)
    written = generate_all(mixed_project, engine)
    engine.close()
    assert (mixed_project / "CLAUDE.md").exists()
    assert "CLAUDE.md" in written
    assert (mixed_project / ".neux" / "modules").exists()


def test_cli_init_idempotent(mixed_project: Path) -> None:
    settings_path = mixed_project / ".claude" / "settings.json"

    result1 = runner.invoke(app, ["init", str(mixed_project)])
    assert result1.exit_code == 0, result1.output
    first = json.loads(settings_path.read_text())

    result2 = runner.invoke(app, ["init", str(mixed_project)])
    assert result2.exit_code == 0, result2.output
    second = json.loads(settings_path.read_text())

    # Idempotency: running init twice must not add or duplicate hook
    # entries. Since v0.3.2, `neux init` installs BOTH NEUX and ANVL
    # hooks — exact counts per event depend on which tool registers
    # which event — so we compare the full hook tree instead of asserting
    # a fixed count.
    assert first["hooks"] == second["hooks"]

    # Sanity: NEUX hook must be present on PreToolUse (the only required
    # event NEUX owns). ANVL hook must be present on at least one event.
    pretool_cmds = [
        h.get("command", "")
        for entry in first["hooks"].get("PreToolUse", [])
        for h in entry.get("hooks", [])
    ]
    assert any("neux" in c for c in pretool_cmds), pretool_cmds

    all_cmds = [
        h.get("command", "")
        for entries in first["hooks"].values()
        for entry in entries
        for h in entry.get("hooks", [])
    ]
    assert any("anvl" in c for c in all_cmds), all_cmds


def test_cli_status_runs(mixed_project: Path) -> None:
    runner.invoke(app, ["init", str(mixed_project)])
    result = runner.invoke(app, ["status", str(mixed_project)])
    assert result.exit_code == 0
    assert "NEUX STATUS" in result.output


def test_cli_impact_resolves_and_walks(mixed_project: Path) -> None:
    runner.invoke(app, ["init", str(mixed_project)])
    result = runner.invoke(app, ["impact", "list_users", str(mixed_project)])
    assert result.exit_code == 0


def test_cli_export_dumps_json(mixed_project: Path) -> None:
    runner.invoke(app, ["init", str(mixed_project)])
    result = runner.invoke(app, ["export", str(mixed_project)])
    assert result.exit_code == 0
    assert (mixed_project / ".neux" / "export.json").exists()
