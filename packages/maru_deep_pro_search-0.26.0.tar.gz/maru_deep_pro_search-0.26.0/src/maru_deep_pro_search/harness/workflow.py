"""Intent-aware workflow engine for session-level research guidance.

Works alongside ``harness/enforcer.py`` to provide *dynamic* workflow
recommendations based on query intent rather than static one-size-fits-all
enforcement rules.

The engine is advisory — it suggests tool sequences and quality thresholds
but does not override the enforcer's hard gates.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class WorkflowRule:
    """A workflow rule for a specific query intent.

    Attributes:
        intent: Canonical intent label (e.g. ``"security"``).
        pre_actions: Recommended tool sequence before code generation.
        max_staleness_min: Minutes before research is considered stale.
        require_fetch: Whether fetching page content is strongly recommended.
        min_quality: Minimum research quality letter grade (A/B/C/D).
        description: Human-readable explanation of the workflow.
    """

    intent: str
    pre_actions: list[str] = field(default_factory=list)
    max_staleness_min: int = 30
    require_fetch: bool = False
    min_quality: str = "C"
    description: str = ""


# ── Intent-to-workflow mapping ───────────────────────────────────────
# NOTE: pre_actions use conceptual labels (not MCP tool names). The enforcer
# translates these into actual MCP tool calls: "deep_research" → search(mode="deep"),
# "balanced_search" → search(mode="balanced"), "web_search" → search(),
# "parallel_search" → search × N, "fetch_top2" → fetch_bulk(urls[:2]).
# See harness/enforcer.py for the translation layer.

INTENT_WORKFLOWS: dict[str, WorkflowRule] = {
    "security": WorkflowRule(
        intent="security",
        pre_actions=["deep_research", "verify"],
        max_staleness_min=15,
        require_fetch=True,
        min_quality="B",
        description="Security queries require deep research with source verification and fresh data.",
    ),
    "howto": WorkflowRule(
        intent="howto",
        pre_actions=["balanced_search", "fetch_top2"],
        max_staleness_min=60,
        require_fetch=False,
        min_quality="C",
        description="How-to queries benefit from balanced search and optionally fetching top sources.",
    ),
    "comparison": WorkflowRule(
        intent="comparison",
        pre_actions=["parallel_search", "verify"],
        max_staleness_min=30,
        require_fetch=False,
        min_quality="C",
        description="Comparison queries need multiple viewpoints and cross-source verification.",
    ),
    "docs": WorkflowRule(
        intent="docs",
        pre_actions=["deep_research"],
        max_staleness_min=120,
        require_fetch=False,
        min_quality="C",
        description="Documentation lookups can use staler research (APIs change slowly).",
    ),
    "versioned": WorkflowRule(
        intent="versioned",
        pre_actions=["deep_research", "verify"],
        max_staleness_min=15,
        require_fetch=True,
        min_quality="B",
        description="Version-specific queries need fresh data and source verification.",
    ),
    "debug": WorkflowRule(
        intent="debug",
        pre_actions=["balanced_search"],
        max_staleness_min=30,
        require_fetch=False,
        min_quality="C",
        description="Debug queries rely on community sources (StackOverflow, GitHub issues).",
    ),
    "definition": WorkflowRule(
        intent="definition",
        pre_actions=["web_search"],
        max_staleness_min=120,
        require_fetch=False,
        min_quality="D",
        description="Definitions are stable; simple web search suffices.",
    ),
    "news": WorkflowRule(
        intent="news",
        pre_actions=["web_search"],
        max_staleness_min=10,
        require_fetch=True,
        min_quality="C",
        description="News queries need very fresh data; fetch top sources for details.",
    ),
    "trends": WorkflowRule(
        intent="trends",
        pre_actions=["deep_research"],
        max_staleness_min=30,
        require_fetch=False,
        min_quality="C",
        description="Trend analysis benefits from multi-source deep research.",
    ),
    "api_ref": WorkflowRule(
        intent="api_ref",
        pre_actions=["web_search"],
        max_staleness_min=60,
        require_fetch=False,
        min_quality="C",
        description="API references are stable; fast search with source fetching.",
    ),
    "korean_nlp": WorkflowRule(
        intent="korean_nlp",
        pre_actions=["deep_research"],
        max_staleness_min=60,
        require_fetch=False,
        min_quality="B",
        description="Korean NLP research needs Naver and academic sources.",
    ),
    "general": WorkflowRule(
        intent="general",
        pre_actions=["balanced_search"],
        max_staleness_min=30,
        require_fetch=False,
        min_quality="C",
        description="General research with balanced speed and quality.",
    ),
}

# Fast-track intents that can use quick web_search with lower thresholds
_FAST_TRACK_INTENTS = frozenset({"definition", "news"})


# ── Public API ─────────────────────────────────────────────────────────


def get_workflow(intent: str) -> WorkflowRule:
    """Return the workflow rule for a given intent, or the general default.

    Args:
        intent: Canonical intent label from ``IntentClassification.intent``.

    Returns:
        The matching ``WorkflowRule`` (falls back to ``"general"``).
    """
    return INTENT_WORKFLOWS.get(intent, INTENT_WORKFLOWS["general"])


def suggest_tool_sequence(intent: str) -> list[str]:
    """Return the recommended tool sequence for a given intent.

    Args:
        intent: Canonical intent label.

    Returns:
        Ordered list of tool names to execute before code generation.
    """
    return list(get_workflow(intent).pre_actions)


def max_staleness_for_intent(intent: str) -> int:
    """Return the maximum staleness (minutes) for research of a given intent.

    Args:
        intent: Canonical intent label.

    Returns:
        Minutes before research is considered stale.
    """
    return get_workflow(intent).max_staleness_min


def min_quality_for_intent(intent: str) -> str:
    """Return the minimum acceptable research quality for a given intent.

    Args:
        intent: Canonical intent label.

    Returns:
        Letter grade (A/B/C/D).
    """
    return get_workflow(intent).min_quality


def is_fast_track(intent: str) -> bool:
    """Return ``True`` if the intent can use fast/lightweight search.

    Args:
        intent: Canonical intent label.

    Returns:
        ``True`` for definition/news queries that don't need deep research.
    """
    return intent in _FAST_TRACK_INTENTS
