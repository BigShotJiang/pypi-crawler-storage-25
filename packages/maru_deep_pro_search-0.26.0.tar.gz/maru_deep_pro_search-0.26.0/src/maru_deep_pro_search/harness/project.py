"""Project-level harness initialization."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import yaml

from .persistence import KnowledgeStore

logger = logging.getLogger("maru_deep_pro_search.harness.project")


def _safe_write(path: Path, content: str) -> None:
    """Write content to path, refusing to overwrite symlinks."""
    if path.is_symlink():
        raise OSError(f"Refusing to write to symlink: {path}")
    path.write_text(content, encoding="utf-8")


DEFAULT_AGENTS_MD = """# Agent Instructions

> This project uses **maru-deep-pro-search** harness for research-first development.

## Rule Zero

**NEVER write code based solely on training data.**

Your training knowledge has a cutoff date. Libraries evolve. APIs change.
Call `search(query, mode="deep")` for technical research or `search(query)` for general questions.

## Tool Priority

1. `search` — Web search with multi-engine ranking (fast/balanced/deep modes)
2. `decompose` — Break complex queries into sub-queries
3. `fetch` — Read and refine specific web pages
4. `fetch_bulk` — Read multiple URLs concurrently
5. `verify` — Cross-verify facts across sources

## Knowledge Cache

This project has a local knowledge store at `.maru/knowledge.db`.
Previous research results are cached and reused when relevant.

## Research Checklist

Before writing ANY code:
- [ ] Called `search(query, mode="deep")` for technical/code decisions
- [ ] Verified library versions are current
- [ ] Checked for known security issues
- [ ] Confirmed API signatures match latest docs
- [ ] Cited sources with [1], [2] in your answer
"""

DEFAULT_GITIGNORE = """# Maru Harness
.maru/knowledge.db
.maru/knowledge.db-journal
.maru/receipts/
.maru/*.bak
"""


def init_project(
    path: Path | str = ".",
    create_agents_md: bool = True,
    create_gitignore: bool = True,
    create_harness_yaml: bool = True,
) -> dict[str, Any]:
    """Initialize project-local maru data (no per-agent dotfiles in the repo).

    Creates:
        .maru/knowledge.db   — local knowledge cache
        .maru/harness.yaml   — declarative harness spec (AHS), optional sync source
        AGENTS.md            — optional project contributor hints (if requested)
        .gitignore additions — exclude harness artifacts

    MCP registration and agent rules live in **user-global** paths only.
    Run ``maru-deep-pro-search setup`` (or ``setup --agents ...``) on each machine.

    Args:
        path: Project root directory.
        create_agents_md: Whether to create AGENTS.md when missing.
        create_gitignore: Whether to append harness entries to .gitignore.
        create_harness_yaml: Whether to create `.maru/harness.yaml`.

    Returns:
        Summary dict with created paths and status.
    """
    root = Path(path).resolve()
    maru_dir = root / ".maru"
    maru_dir.mkdir(parents=True, exist_ok=True)

    created: list[str] = []

    # 1. Knowledge store
    store = KnowledgeStore(db_path=maru_dir / "knowledge.db")
    store._connect()  # ensure schema exists
    created.append(str(maru_dir / "knowledge.db"))

    # 2. Harness Spec (.maru/harness.yaml)
    if create_harness_yaml:
        harness_yaml = maru_dir / "harness.yaml"
        if not harness_yaml.exists():
            from .spec import HarnessSpec

            spec = HarnessSpec.default()
            spec_dict = {
                "mcp_servers": {
                    "maru-deep-pro-search": {
                        "command": "python3",
                        "args": ["-m", "maru_deep_pro_search.server"],
                    }
                },
                "research_protocol": spec.research_protocol,
                "tool_priority": spec.tool_priority,
                "commands": [
                    {"name": c.name, "description": c.description, "prompt": c.prompt}
                    for c in spec.commands
                ],
                "conventions": spec.conventions,
                "knowledge_db_path": spec.knowledge_db_path,
            }
            yaml_text = (
                "# Agent Harness Specification (AHS) — maru-deep-pro-search\n"
                "# This file declaratively defines how AI agents should behave in this project.\n"
                "# The setup CLI translates this into agent-native config files.\n\n"
                + yaml.dump(
                    spec_dict, allow_unicode=True, default_flow_style=False, sort_keys=False
                )
            )
            _safe_write(harness_yaml, yaml_text)
            created.append(str(harness_yaml))

    # 3. AGENTS.md
    if create_agents_md:
        agents_md = root / "AGENTS.md"
        if not agents_md.exists():
            _safe_write(agents_md, DEFAULT_AGENTS_MD)
            created.append(str(agents_md))

    # 4. .gitignore
    if create_gitignore:
        gitignore = root / ".gitignore"
        if gitignore.exists():
            if gitignore.is_symlink():
                logger.warning("Refusing to modify symlinked .gitignore: %s", gitignore)
            else:
                content = gitignore.read_text(encoding="utf-8")
                if ".maru/knowledge.db" not in content:
                    with gitignore.open("a", encoding="utf-8") as f:
                        f.write("\n" + DEFAULT_GITIGNORE + "\n")
                    created.append(str(gitignore))
        else:
            _safe_write(gitignore, DEFAULT_GITIGNORE + "\n")
            created.append(str(gitignore))

    logger.info("Harness initialized at %s", root)
    return {
        "root": str(root),
        "created": created,
    }


class HarnessProject:
    """Accessor for a harness-enabled project."""

    def __init__(self, root: Path | str = ".") -> None:
        self.root = Path(root).resolve()
        self.maru_dir = self.root / ".maru"
        self._store: KnowledgeStore | None = None

    @property
    def store(self) -> KnowledgeStore:
        if self._store is None:
            self._store = KnowledgeStore(db_path=self.maru_dir / "knowledge.db")
        return self._store

    def is_initialized(self) -> bool:
        return (self.maru_dir / "knowledge.db").exists()
