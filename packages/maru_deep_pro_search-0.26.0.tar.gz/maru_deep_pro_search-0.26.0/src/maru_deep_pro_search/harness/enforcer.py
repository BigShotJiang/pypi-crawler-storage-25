"""Session-level enforcement engine — ensures research-before-action.

This is the technical enforcement layer that makes "research first"
a hard gate, not just a suggestion. Every MCP session is tracked,
and tools that depend on research are blocked until deep_research
has been successfully completed.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any

from ..config import DEFAULT_CONFIG
from ..exceptions import MaruSearchError
from .constants import (
    FRESH_RESEARCH_REQUIRED_TOOLS,
    RESEARCH_EXEMPT_META_TOOLS,
    RESEARCH_PRODUCING_TOOLS,
)
from .drift import (
    WorkspaceSnapshot,
    compare_snapshots_tiered,
    extract_error_signature,
    format_drift_warning,
    format_soft_drift_note,
    snapshot_workspace,
    suggest_research_queries,
)


class ResearchRequiredError(MaruSearchError):
    """Raised when a dependent tool is called before fresh research."""

    def __init__(self, tool_name: str) -> None:
        super().__init__(
            f"[BLOCKED] '{tool_name}' requires fresh research in this session. "
            "Run answer(query=...) for general questions or deep_research(query=...) "
            "for coding/security work first.",
            retryable=False,
        )


class CodeGenerationBlockedError(MaruSearchError):
    """Raised when code generation is attempted without research validation."""

    def __init__(self, reason: str) -> None:
        super().__init__(
            f"[BLOCKED] Code generation blocked: {reason} "
            "Run deep_research(query=...) for coding/security work and use "
            "generate_code(research_id=...) with valid citations from the research result.",
            retryable=False,
        )


@dataclass
class SessionState:
    """Mutable state tracked per MCP session."""

    session_id: str
    created_at: float = field(default_factory=time.time)
    research_done: bool = False
    research_result: str = ""
    research_query: str = ""
    research_timestamp: float = 0.0
    research_id: str = ""
    tools_called: list[str] = field(default_factory=list)
    citations_found: list[str] = field(default_factory=list)
    code_generated: bool = False
    workspace_snapshot: WorkspaceSnapshot = field(
        default_factory=lambda: WorkspaceSnapshot(root="")
    )
    research_error_signature: str = ""
    last_error_signature: str = ""

    def record_tool(self, name: str, result: str = "") -> None:
        self.tools_called.append(name)
        sig = extract_error_signature(result)
        if sig:
            self.last_error_signature = sig

    def mark_research(self, query: str, result: str) -> None:
        self.research_done = True
        self.research_query = query
        self.research_result = result
        self.research_timestamp = time.time()
        extracted = self._extract_research_id(result)
        self.research_id = extracted or self._generate_research_id()
        self._extract_citations(result)
        self.workspace_snapshot = snapshot_workspace()
        self.research_error_signature = self.last_error_signature

    def append_research_context(self, query: str, result: str) -> None:
        """Merge a fetched/read result into existing research without changing its ID."""
        if not self.research_done:
            self.mark_research(query, result)
            return

        combined = "\n\n".join(
            (
                self.research_result,
                "---",
                f"## Additional Research Context: {query}",
                result,
            )
        )
        cap = DEFAULT_CONFIG.research_context_max_chars
        marker = "\n\n_[research context truncated]_"
        if len(combined) > cap:
            keep = max(0, cap - len(marker))
            combined = (combined[:keep] + marker)[:cap]
        self.research_result = combined
        self.research_timestamp = time.time()

        import re

        for citation in re.findall(r"(?<!\w)\[(\d+)\](?!\w)", result):
            if citation not in self.citations_found:
                self.citations_found.append(citation)

        self.workspace_snapshot = snapshot_workspace()
        self.research_error_signature = self.last_error_signature

    @staticmethod
    def _extract_research_id(text: str) -> str:
        import re

        match = re.search(r"_research_id:\s*(RSCH-[A-F0-9]+)_", text, re.I)
        return match.group(1).upper() if match else ""

    @staticmethod
    def _generate_research_id() -> str:
        import uuid

        return f"RSCH-{uuid.uuid4().hex[:12].upper()}"

    def _extract_citations(self, text: str) -> None:
        import re

        self.citations_found = re.findall(r"(?<!\w)\[(\d+)\](?!\w)", text)

    @property
    def research_age_seconds(self) -> float:
        if not self.research_timestamp:
            return float("inf")
        return time.time() - self.research_timestamp

    @property
    def is_fresh(self) -> bool:
        """Research is considered stale after 30 minutes."""
        return self.research_age_seconds < 1800


class SessionEnforcer:
    """Tracks every MCP session and enforces research-before-action policies."""

    RESEARCH_PRODUCING_TOOLS: set[str] = set(RESEARCH_PRODUCING_TOOLS)
    RESEARCH_EXEMPT_TOOLS: set[str] = set(RESEARCH_EXEMPT_META_TOOLS) | RESEARCH_PRODUCING_TOOLS
    FRESH_RESEARCH_REQUIRED_TOOLS: set[str] = set(FRESH_RESEARCH_REQUIRED_TOOLS)

    # Mid-task enforcement: warn after N non-research tools without fresh research
    MAX_TOOLS_WITHOUT_RESEARCH: int = 5

    def __init__(self) -> None:
        self._sessions: dict[str, SessionState] = {}
        self._lock = asyncio.Lock()
        self._prune_counter = 0

    def get_or_create(self, session_id: str) -> SessionState:
        self._prune_counter += 1
        # Lazy prune every 100 calls to prevent unbounded session growth
        if self._prune_counter % 100 == 0 and len(self._sessions) > 500:
            import time as _time

            now = _time.monotonic()
            stale = [sid for sid, s in self._sessions.items() if now - s.created_at > 3600]
            for sid in stale[: len(stale) // 2]:  # Prune half of stale sessions
                del self._sessions[sid]
        if session_id not in self._sessions:
            self._sessions[session_id] = SessionState(session_id=session_id)
        return self._sessions[session_id]

    async def mark_research_done(self, session_id: str, query: str, result: str) -> SessionState:
        async with self._lock:
            state = self.get_or_create(session_id)
            state.mark_research(query, result)
            # Also update filesystem markers so client-side hooks can check it
            self._touch_research_marker()
            self._write_session_research_marker(query, state.research_id)
            return state

    async def append_research_context(
        self, session_id: str, query: str, result: str
    ) -> SessionState:
        async with self._lock:
            state = self.get_or_create(session_id)
            state.append_research_context(query, result)
            self._touch_research_marker()
            self._write_session_research_marker(state.research_query, state.research_id)
            return state

    @staticmethod
    def _touch_research_marker() -> None:
        """Update the filesystem marker used by client-side hooks."""
        import pathlib

        marker = pathlib.Path.home() / ".maru" / "last_research"
        marker.parent.mkdir(parents=True, exist_ok=True)
        marker.touch()

    @staticmethod
    def _write_session_research_marker(query: str, research_id: str) -> None:
        """Write a structured session research marker for client-side hooks.

        Aider, Cursor, and other adapters read this file to verify
        research was completed before allowing edits.
        """
        import json
        import pathlib
        from datetime import datetime, timezone

        marker = pathlib.Path.home() / ".maru" / "session_research.json"
        marker.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "completed_at": datetime.now(timezone.utc).isoformat(),
            "research_id": research_id,
            "query": query,
        }
        marker.write_text(json.dumps(data, indent=2))

    async def check_research(self, session_id: str, tool_name: str) -> SessionState:
        """Verify that research was done before allowing a dependent tool.

        Raises ResearchRequiredError if research has not been completed.
        """
        state = self.get_or_create(session_id)

        if tool_name in self.RESEARCH_EXEMPT_TOOLS:
            return state

        if tool_name in self.FRESH_RESEARCH_REQUIRED_TOOLS:
            if not state.research_done:
                raise ResearchRequiredError(tool_name)
            if not state.is_fresh:
                raise ResearchRequiredError(
                    f"{tool_name} (research expired after 30min — run answer or deep_research again)"
                )
            return state

        if not state.research_done:
            raise ResearchRequiredError(tool_name)

        return state

    def should_research(self, session_id: str, tool_name: str) -> str | None:
        """Return a warning if the agent should re-research before continuing.

        Returns None if no warning is needed, or a markdown string with the warning.
        """
        state = self.get_or_create(session_id)

        if tool_name in self.RESEARCH_EXEMPT_TOOLS:
            return None

        if not state.research_done:
            return None  # check_research will block anyway

        non_research_tools = [t for t in state.tools_called if t not in self.RESEARCH_EXEMPT_TOOLS]

        tiered = (
            compare_snapshots_tiered(state.workspace_snapshot)
            if state.workspace_snapshot.files
            else compare_snapshots_tiered(WorkspaceSnapshot(root=state.workspace_snapshot.root))
        )
        hard_reasons = list(tiered.hard)
        soft_reasons = list(tiered.soft)

        error_drift = bool(
            state.last_error_signature
            and state.research_error_signature != state.last_error_signature
        )

        if hard_reasons or error_drift:
            error_line = "recent tool error" if error_drift else ""
            return format_drift_warning(
                hard_reasons,
                suggest_research_queries(hard_reasons, state.research_query, error_line),
                soft_reasons=soft_reasons,
                error_drift=error_drift,
            )

        if soft_reasons:
            return format_soft_drift_note(soft_reasons)

        if len(non_research_tools) >= self.MAX_TOOLS_WITHOUT_RESEARCH:
            return (
                f"\n\n🟡 **Mid-task warning**: You have called {len(non_research_tools)} tools "
                "since your last research. Consider `answer()` or `deep_research()` to refresh "
                "your knowledge before continuing."
            )

        if state.research_age_seconds > 900 and len(non_research_tools) >= 2:
            return (
                "\n\n🟡 **Research aging**: Last research was "
                f"{int(state.research_age_seconds // 60)}+ minutes ago. "
                "Consider `answer()` or `deep_research()` if you changed direction or dependencies."
            )

        return None

    def drift_summary(self, session_id: str) -> dict[str, Any]:
        """Read-only drift report for drift_status tool."""
        state = self.get_or_create(session_id)
        current = snapshot_workspace()
        empty_baseline = WorkspaceSnapshot(root=current.root)
        tiered = (
            compare_snapshots_tiered(state.workspace_snapshot, current)
            if state.workspace_snapshot.files
            else compare_snapshots_tiered(empty_baseline, empty_baseline)
        )
        hard_reasons = list(tiered.hard)
        soft_reasons = list(tiered.soft)
        error_changed = bool(
            state.last_error_signature
            and state.research_error_signature != state.last_error_signature
        )
        return {
            "research_done": state.research_done,
            "research_id": state.research_id,
            "research_query": state.research_query,
            "research_age_seconds": state.research_age_seconds,
            "workspace_root": current.root,
            "manifest_files_tracked": list(current.files.keys()),
            "drift_detected": bool(hard_reasons) or error_changed,
            "soft_drift_detected": bool(soft_reasons),
            "manifest_changes": hard_reasons + soft_reasons,
            "soft_manifest_changes": soft_reasons,
            "hard_manifest_changes": hard_reasons,
            "error_signature_changed": error_changed,
            "suggested_queries": suggest_research_queries(hard_reasons, state.research_query),
            "baseline_fingerprint": state.workspace_snapshot.fingerprint()
            if state.workspace_snapshot.files
            else "",
            "current_fingerprint": current.fingerprint(),
        }

    async def validate_code_generation(
        self,
        session_id: str,
        research_id: str,
        proposed_code: str,
    ) -> dict[str, Any]:
        """Validate that code generation is backed by actual research.

        1. research_id must match the completed session's research_id.
        2. proposed_code must contain at least one citation [N] from research.
        3. Returns validation report with pass/fail and details.
        """
        state = self.get_or_create(session_id)

        if not state.research_done:
            raise CodeGenerationBlockedError("no research has been performed in this session.")

        if not state.is_fresh:
            raise CodeGenerationBlockedError(
                "research is stale (>30min). Re-run answer or deep_research."
            )

        if research_id != state.research_id:
            raise CodeGenerationBlockedError(
                f"research_id mismatch. Expected '{state.research_id}', got '{research_id}'. "
                "Use the research_id returned by answer() or deep_research()."
            )

        # Check for citations in proposed code
        import re

        code_citations = set(re.findall(r"(?<!\w)\[(\d+)\](?!\w)", proposed_code))
        research_citations = set(state.citations_found)

        missing = code_citations - research_citations
        unmatched = research_citations - code_citations

        validation = {
            "passed": len(code_citations) > 0 and not missing,
            "code_citations": sorted(code_citations),
            "research_citations": sorted(research_citations),
            "missing_citations": sorted(missing),
            "unused_citations": sorted(unmatched),
            "research_query": state.research_query,
            "research_age_seconds": state.research_age_seconds,
            "research_id": state.research_id,
        }
        return validation

    async def session_summary(self, session_id: str) -> dict[str, Any]:
        state = self.get_or_create(session_id)
        return {
            "session_id": state.session_id,
            "research_done": state.research_done,
            "research_query": state.research_query,
            "research_age_seconds": state.research_age_seconds,
            "is_fresh": state.is_fresh,
            "research_id": state.research_id,
            "tools_called": state.tools_called,
            "citations_found": state.citations_found,
            "code_generated": state.code_generated,
        }

    async def prune_stale_sessions(self, max_age_seconds: float = 3600) -> int:
        """Remove sessions older than max_age_seconds. Returns count removed."""
        now = time.time()
        async with self._lock:
            stale = [
                sid for sid, s in self._sessions.items() if now - s.created_at > max_age_seconds
            ]
            for sid in stale:
                del self._sessions[sid]
            return len(stale)


# Global singleton enforcer instance
_enforcer: SessionEnforcer | None = None


def get_enforcer() -> SessionEnforcer:
    global _enforcer
    if _enforcer is None:
        _enforcer = SessionEnforcer()
    return _enforcer
