"""Atomic search tool with mode-layered pipeline and output compression.

Supports three search modes (*fast*, *balanced*, *deep*) that trade speed
for depth by toggling pipeline stages: semantic ranking, snippet refinement,
fuzzy deduplication, and output verbosity.
"""

from __future__ import annotations

import asyncio
import logging
import os as _os
from typing import Any

from ..config import DEFAULT_CONFIG
from ..engines.base import SearchResult
from ..engines.registry import SearchEngineRegistry
from ..exceptions import NetworkError
from ..extraction.content import estimate_token_count
from ..research.ranker import RankedResult, merge_results
from ..utils.cache import cache_key, get_search_cache
from ..utils.locale_harness import optimize_for_engine
from ..utils.url import is_authority_domain, normalize_url

logger = logging.getLogger(__name__)

# Module-level semaphore to limit concurrent search requests
_search_semaphore = asyncio.Semaphore(4)

# Lazy refiner import — graceful degradation if llama-cpp is unavailable
try:
    from ..refiner.engine import RefinerEngine

    _REFINER_AVAILABLE = True
except ImportError:  # pragma: no cover
    _REFINER_AVAILABLE = False
    RefinerEngine = None  # type: ignore[misc,assignment]
    logger.debug("RefinerEngine unavailable; search will return raw snippets")


# ── mode configuration ────────────────────────────────────────────────

MODE_CONFIG: dict[str, dict[str, Any]] = {
    "fast": {
        "engines": 1,  # single fastest engine
        "serp_timeout": 12.0,
        "semantic_topk": 0,  # skip semantic scoring
        "refiner": False,  # skip snippet refinement
        "dedup_mode": "url_only",  # skip fuzzy dedup (pass-through)
        "rrf": False,  # RRF pointless with single engine
        "output_style": "compact",  # minimal lines per result
    },
    "balanced": {
        "engines": 2,  # top-2 recommended
        "serp_timeout": 20.0,
        "semantic_topk": 20,  # score only top 20
        "refiner": "light",  # quick refinement (64 tok)
        "dedup_mode": "jaccard",  # Jaccard only (skip semantic dedup)
        "rrf": True,
        "output_style": "standard",
    },
    "deep": {
        "engines": 3,  # top-3 recommended
        "serp_timeout": 30.0,
        "semantic_topk": 30,  # score top 30
        "refiner": "full",  # full refinement (128 tok)
        "dedup_mode": "full",  # Jaccard + semantic
        "rrf": True,
        "output_style": "verbose",
    },
}

# Per-mode max_results defaults (configurable via env)
_MODE_MAX_RESULTS: dict[str, int] = {
    "fast": int(_os.getenv("MARU_FAST_MAX_RESULTS", "6")),
    "balanced": int(_os.getenv("MARU_BALANCED_MAX_RESULTS", "10")),
    "deep": int(_os.getenv("MARU_DEEP_MAX_RESULTS", "15")),
}


def _get_refiner() -> Any | None:
    """Return the singleton RefinerEngine instance, or None if unavailable."""
    if not _REFINER_AVAILABLE or RefinerEngine is None:
        return None
    try:
        return RefinerEngine.get_instance()
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to initialise RefinerEngine: %s", exc)
        return None


async def _search_one(
    engine_name: str,
    query: str,
    max_results: int,
    allow_fallback: bool = True,
    timeout: float | None = None,
) -> tuple[str, list[SearchResult]]:
    """Execute a single search and return (engine_name, results).

    Handles per-engine timeouts and optional fallback when the engine
    reports a suggested alternative.
    """
    serp_timeout = timeout if timeout is not None else DEFAULT_CONFIG.serp_timeout_seconds
    async with _search_semaphore:
        try:
            search_engine = SearchEngineRegistry.create(engine_name)
            optimized_query = optimize_for_engine(query, engine_name)
            results = await asyncio.wait_for(
                search_engine.search(optimized_query, max_results=max_results),
                timeout=serp_timeout,
            )
            return engine_name, results
        except asyncio.TimeoutError:
            logger.warning(
                "Search '%s' on %s timed out after %.0fs",
                query[:40],
                engine_name,
                serp_timeout,
            )
            return engine_name, []
        except NetworkError as exc:
            logger.warning("Search '%s' on %s failed: %s", query[:40], engine_name, exc)
            fallback = getattr(exc, "suggested_engine", None)
            if fallback and fallback != engine_name and allow_fallback:
                logger.info("Engine fallback: %s -> %s", engine_name, fallback)
                return await _search_one(
                    fallback, query, max_results, allow_fallback=False, timeout=serp_timeout
                )
            return engine_name, []
        except Exception as exc:  # noqa: BLE001
            logger.warning("Search '%s' on %s failed: %s", query[:40], engine_name, exc)
            return engine_name, []


# ── output formatters ─────────────────────────────────────────────────


def _format_output(
    mc: dict[str, Any],
    query: str,
    ranked: list[RankedResult],
    mr: int,
    offset: int,
    max_score: float,
    engine_names: list[str],
    refined_snippets: dict[str, str],
) -> str:
    """Dispatch to the right formatter based on mode config."""
    style = mc["output_style"]
    if style == "compact":
        return _format_compact(query, ranked, mr, offset, max_score, engine_names)
    elif style == "standard":
        return _format_standard(
            query, ranked, mr, offset, max_score, engine_names, refined_snippets
        )
    else:  # verbose
        return _format_verbose(query, ranked, mr, offset, max_score, engine_names, refined_snippets)


def _format_compact(
    query: str,
    ranked: list[RankedResult],
    max_results: int,
    offset: int,
    max_score: float,
    engine_names: list[str],
) -> str:
    """Minimal output: 2 lines per result (title + snippet)."""
    lines: list[str] = []
    used_engine = ",".join(engine_names)
    total = len(ranked)
    end = offset + max_results
    page_hint = f" (showing {offset + 1}-{min(end, total)})" if offset else ""
    lines.append(f'Search: "{query}" | {total} results{page_hint} | engine: {used_engine}')
    lines.append("")

    for rr in ranked[offset:end]:
        sr = rr.result
        relevance = min(rr.final_score / max_score, 1.0)
        relevance = max(relevance, 0.0)
        can_fetch = "no" if sr.access_risk == "blocked_likely" else "yes"

        title_line = (
            f"[{rr.citation_id}] {sr.title} (relevance: {relevance:.2f}, can_fetch: {can_fetch})"
        )
        lines.append(title_line)
        if sr.snippet:
            lines.append(sr.snippet[:200])
        lines.append("")

    has_more = end < total
    lines.append(f"_has_more: {has_more}_")
    return "\n".join(lines)


def _format_standard(
    query: str,
    ranked: list[RankedResult],
    max_results: int,
    offset: int,
    max_score: float,
    engine_names: list[str],
    refined_snippets: dict[str, str],
) -> str:
    """Balanced output: title + url + snippet, conditional badges."""
    lines: list[str] = []
    used_engine = ",".join(engine_names)
    total = len(ranked)
    end = offset + max_results
    page_hint = f" (showing {offset + 1}-{min(end, total)})" if offset else ""
    lines.append(f'Search: "{query}" | {total} results{page_hint} | engine: {used_engine}')
    lines.append("")

    for rr in ranked[offset:end]:
        sr = rr.result
        norm_url = normalize_url(sr.url)
        relevance = min(rr.final_score / max_score, 1.0)
        relevance = max(relevance, 0.0)

        # Conditional badges (only when non-default)
        badges: list[str] = []
        if sr.is_primary:
            badges.append("\U0001f4ccprimary")
        if is_authority_domain(sr.url):
            badges.append("\U0001f512authority")
        badge_str = " ".join(badges)

        title_line = f"[{rr.citation_id}] {sr.title} (relevance: {relevance:.2f})"
        if badge_str:
            title_line += f" {badge_str}"
        lines.append(title_line)

        lines.append(f"URL: {sr.url}")

        snippet_text = refined_snippets.get(norm_url, sr.snippet or "")
        if snippet_text:
            lines.append(snippet_text)
        lines.append("")

    has_more = end < total
    lines.append(f"_has_more: {has_more}_")
    return "\n".join(lines)


def _format_verbose(
    query: str,
    ranked: list[RankedResult],
    max_results: int,
    offset: int,
    max_score: float,
    engine_names: list[str],
    refined_snippets: dict[str, str],
) -> str:
    """Full metadata output with all badges, type labels, and token estimates."""
    lines: list[str] = []
    used_engine = ",".join(engine_names)
    total = len(ranked)
    end = offset + max_results
    has_more = end < total
    page_hint = f" (showing {offset + 1}-{min(end, total)})" if offset else ""

    lines.append(f'Search: "{query}" | {total} results{page_hint} | engine: {used_engine}')
    lines.append("")

    for rr in ranked[offset:end]:
        sr = rr.result
        norm_url = normalize_url(sr.url)

        relevance = min(rr.final_score / max_score, 1.0)
        relevance = max(relevance, 0.0)

        primary_badge = "\U0001f4ccprimary" if sr.is_primary else ""
        authority_badge = "\U0001f512authority" if is_authority_domain(sr.url) else ""
        type_label = sr.likely_content_type.value

        can_fetch = "no" if sr.access_risk == "blocked_likely" else "yes"
        snippet_text = refined_snippets.get(norm_url, sr.snippet or "")
        tokens = estimate_token_count(snippet_text)

        badges = " ".join(b for b in [primary_badge, authority_badge] if b)
        title_line = f"[{rr.citation_id}] {sr.title} (relevance: {relevance:.2f})"
        if badges:
            title_line += f" {badges}"
        title_line += f" {type_label}"
        lines.append(title_line)

        lines.append(f"URL: {sr.url}")
        lines.append(
            f"_relevance: {relevance:.2f} | type: {type_label} | "
            f"primary: {sr.is_primary} | authority: {is_authority_domain(sr.url)} | "
            f"can_fetch: {can_fetch} | estimated_tokens: {tokens}_"
        )
        if snippet_text:
            lines.append(snippet_text)
        lines.append("")

    lines.append("---")
    lines.append(f"_has_more: {has_more}_")
    return "\n".join(lines)


# ── main tool ─────────────────────────────────────────────────────────


async def tool_search(
    query: str,
    engine: str = "auto",
    max_results: int = 10,
    mode: str = "balanced",
    source_scope: str = "auto",
    offset: int = 0,
) -> str:
    """Search the web and return structured, token-efficient results.

    Uses the engine registry to perform searches, the research ranker to
    score and deduplicate results, and an optional local refiner to clean
    snippets before presenting them to the host LLM.

    Args:
        query: Search query string.
        engine: Engine name or ``"auto"`` to let the registry pick the best
            combination based on the query locale and intent.
        max_results: Maximum number of results to return.  Bounded by the
            per-mode default if the requested value exceeds it.
        mode: Pipeline depth — ``"fast"`` (1 engine, no semantic/refiner),
            ``"balanced"`` (2 engines, light refinement), or ``"deep"``
            (3+ engines, full pipeline).
        source_scope: Domain preference — ``"academic"`` (research papers),
            ``"discussions"`` (forums/community), ``"docs"`` (official docs),
            ``"news"``, or ``"auto"`` (intent-based).
        offset: Skip first N results for pagination.  Use with ``_has_more``
            to request subsequent pages (e.g. offset=10 for page 2).

    Returns:
        Token-efficient markdown with ranked search results.
    """
    if not query or not query.strip():
        return "Error: empty query."

    query = query.strip()

    # ── validate & clamp mode ──────────────────────────────────────
    mode = mode if mode in MODE_CONFIG else "balanced"
    mc = MODE_CONFIG[mode]
    mr = min(max_results, _MODE_MAX_RESULTS.get(mode, 10))
    if max_results > mr:
        logger.info("max_results clamped from %d to %d (mode=%s)", max_results, mr, mode)
    if offset < 0:
        offset = 0

    # ── cache key ──────────────────────────────────────────────────
    sc = get_search_cache()
    sk = cache_key("search", query, engine, mode, source_scope, str(mr))

    # Check cache for pagination reuse (offset > 0 skips re-search)
    cached = sc.get(sk)
    if cached is not None:
        cached_ranked, cached_score, cached_engines, cached_refined = cached
        logger.debug("Search cache hit for %r (offset=%d)", query[:40], offset)
        return _format_output(
            mc, query, cached_ranked, mr, offset, cached_score, cached_engines, cached_refined
        )

    # ── resolve source_scope + ranking_weights from intent ─────────
    scope = source_scope
    ranking_weights: dict[str, float] = {}
    if query:
        from ..research.intent import classify_intent  # noqa: PLC0415

        ic = classify_intent(query)
        if scope == "auto":
            scope = ic.source_scope
        ranking_weights = dict(ic.ranking_weights)

    # ── engine selection ───────────────────────────────────────────
    if engine == "auto":
        engine_names = SearchEngineRegistry.recommend_engines(query)[: mc["engines"]]
        if not engine_names:
            engine_names = [DEFAULT_CONFIG.default_engine]
    else:
        if not SearchEngineRegistry.is_registered(engine):
            engine_names = [DEFAULT_CONFIG.default_engine]
        else:
            engine_names = [engine]

    # ── parallel search ────────────────────────────────────────────
    search_tasks = [
        asyncio.create_task(_search_one(name, query, mr, timeout=mc["serp_timeout"]))
        for name in engine_names
    ]

    engine_results: dict[str, list[SearchResult]] = {}
    search_runs: list[tuple[str, list[SearchResult]]] = []
    search_errors: list[str] = []

    all_results = await asyncio.gather(*search_tasks, return_exceptions=True)
    for i, res in enumerate(all_results):
        if isinstance(res, BaseException):
            err_msg = f"{engine_names[i]}: {res}"
            logger.warning("Search task failed: %s", err_msg)
            search_errors.append(err_msg)
            continue
        eng_name, rlist = res
        engine_results.setdefault(eng_name, []).extend(rlist)
        search_runs.append((eng_name, rlist))

    if not any(engine_results.values()):
        error_detail = f" (_errors: {'; '.join(search_errors)})" if search_errors else ""
        return f"No results found for: {query}{error_detail}"

    # ── mode-aware dedup & ranking ─────────────────────────────────
    if mc["dedup_mode"] == "url_only":
        # Fast path: only URL dedup (skip fuzzy dedup entirely)
        url_merged: dict[str, SearchResult] = {}
        for eng_name, rlist in engine_results.items():
            for r in rlist:
                norm = normalize_url(r.url)
                if norm not in url_merged:
                    url_merged[norm] = r
                if r.engines_found is None:
                    r.engines_found = []
                if eng_name not in r.engines_found:
                    r.engines_found = list(r.engines_found) + [eng_name]
        # Rank with BM25+metadata only (no semantic, no RRF if disabled)
        ranked = merge_results(
            {eng: engine_results.get(eng, []) for eng in engine_names},
            query,
            search_runs=search_runs if mc["rrf"] else None,
            semantic_topk=mc["semantic_topk"],
            source_scope=scope,
            ranking_weights=ranking_weights if ranking_weights else None,
            dedup_mode=mc["dedup_mode"],
        )
    else:
        # Full hybrid dedup + ranking
        ranked = merge_results(
            engine_results,
            query,
            search_runs=search_runs if mc["rrf"] else None,
            semantic_topk=mc["semantic_topk"],
            source_scope=scope,
            ranking_weights=ranking_weights if ranking_weights else None,
            dedup_mode=mc["dedup_mode"],
        )

    if not ranked:
        return f"No results found for: {query}"

    # Normalise relevance scores to 0–1
    max_score = max((rr.final_score for rr in ranked), default=1.0)
    if max_score <= 0:
        max_score = 1.0

    # ── refiner (mode-aware) ───────────────────────────────────────
    refined_snippets: dict[str, str] = {}
    if mc["refiner"]:
        refiner = _get_refiner()
        if refiner is not None:
            for rr in ranked[:mr]:
                try:
                    refined = await refiner.refine_snippet(
                        text=rr.result.snippet or "",
                        query=query,
                    )
                    original = rr.result.snippet or ""
                    if refined and refined.strip() and refined.strip() != original.strip():
                        refined_snippets[normalize_url(rr.result.url)] = refined
                except Exception as exc:  # noqa: BLE001
                    logger.debug("Snippet refinement failed: %s", exc)

    # ── cache results for pagination reuse ────────────────────────
    sc.set(sk, (ranked, max_score, engine_names, refined_snippets))

    # ── format output ──────────────────────────────────────────────
    return _format_output(mc, query, ranked, mr, offset, max_score, engine_names, refined_snippets)
