"""Content extraction utilities for LLM-optimized output."""

from __future__ import annotations

import re


def truncate_for_llm(text: str, max_tokens: int = 2500) -> str:
    """Truncate text to approximate token limit, respecting boundaries.

    Tries to cut at paragraph, then sentence, then word boundaries.
    Approximates 1 token ≈ 4 characters.
    """
    if not text:
        return ""

    max_chars = max_tokens * 4
    if len(text) <= max_chars:
        return text

    # Try paragraph boundary
    truncated = text[:max_chars]
    last_para = truncated.rfind("\n\n")
    if last_para > max_chars * 0.7:
        return text[:last_para].strip() + "\n\n...[truncated]"

    # Try sentence boundary
    last_sentence = truncated.rfind(". ")
    if last_sentence > max_chars * 0.7:
        return text[: last_sentence + 1].strip() + "\n\n...[truncated]"

    # Try word boundary
    last_space = truncated.rfind(" ")
    if last_space > max_chars * 0.8:
        return text[:last_space].strip() + " ...[truncated]"

    return text[:max_chars].strip() + "...[truncated]"


def truncate_for_llm_structure_aware(
    text: str, max_tokens: int = 2500, preserve_code: bool = True
) -> str:
    """Structure-aware truncation that preserves headings, code blocks, and key sections.

    Unlike ``truncate_for_llm`` which simply chops at boundaries, this function:
    1. Extracts and preserves all code blocks (for dev queries they carry the most signal).
    2. Keeps the first 3 paragraphs (intro/context) and last paragraph (conclusion).
    3. Thins the middle proportionally to fit the token budget.

    Args:
        text: Raw markdown text.
        max_tokens: Maximum approximate tokens in the output.
        preserve_code: When ``True`` (default), code blocks are always preserved.

    Returns:
        Truncated markdown string with structural integrity maintained.
    """
    if not text:
        return ""
    if estimate_token_count(text) <= max_tokens:
        return text

    # ── extract code blocks ────────────────────────────────────────
    code_pattern = re.compile(r"```(?:\w+)?\n.*?```", re.DOTALL)
    code_blocks: list[str] = []
    text_no_code = text

    if preserve_code:
        code_blocks = code_pattern.findall(text)
        text_no_code = code_pattern.sub("", text)

    # ── split into sections by headings ────────────────────────────
    heading_pattern = re.compile(r"^(#{1,6}\s+.+)$", re.MULTILINE)
    sections = heading_pattern.split(text_no_code)

    # ── heading budget ────────────────────────────────────────────
    heading_budget = 0
    heading_lines: list[str] = []
    for part in sections:
        if heading_pattern.match(part):
            heading_lines.append(part)
            heading_budget += estimate_token_count(part)

    # ── body budget ────────────────────────────────────────────────
    code_budget = sum(estimate_token_count(cb) for cb in code_blocks)
    body_max_tokens = max_tokens - heading_budget - code_budget
    if body_max_tokens < 50:
        # Extreme budget: just return headings + code blocks only
        result = "\n".join(heading_lines + code_blocks)
        if estimate_token_count(result) > max_tokens:
            # Rough char budget (~4 chars/token); break at word boundary
            budget = max_tokens * 4
            truncated = result[:budget]
            last_space = truncated.rfind(" ")
            if last_space > budget * 0.8:
                truncated = truncated[:last_space]
            result = truncated + "\n...[truncated]"
        return result

    body = "\n".join(part for part in sections if not heading_pattern.match(part))
    paragraphs = [p.strip() for p in body.split("\n\n") if p.strip()]

    if len(paragraphs) <= 5:
        # Short enough — use simple truncation
        return truncate_for_llm(text, max_tokens)

    # ── preserve first 3 + last 1, thin the middle ────────────────
    intro = paragraphs[:3]
    conclusion = paragraphs[-1:]
    middle = paragraphs[3:-1]

    # Compute available budget for middle
    intro_tokens = sum(estimate_token_count(p) for p in intro)
    conclusion_tokens = sum(estimate_token_count(p) for p in conclusion)
    middle_budget = body_max_tokens - intro_tokens - conclusion_tokens

    # Thin middle: take proportional slice
    thinned_middle: list[str] = []
    if middle_budget > 0 and middle:
        total_middle = sum(estimate_token_count(p) for p in middle)
        if total_middle > 0:
            # Take paragraphs until budget exhausted
            spent = 0
            for p in middle:
                pt = estimate_token_count(p)
                if spent + pt > middle_budget:
                    # Take a truncated version of this paragraph
                    available = middle_budget - spent
                    if available > 20:
                        thinned_middle.append(truncate_for_llm(p, available))
                    break
                thinned_middle.append(p)
                spent += pt

    # ── reassemble ─────────────────────────────────────────────────
    parts = heading_lines + intro + thinned_middle + conclusion + code_blocks
    result = "\n\n".join(p for p in parts if p)
    if estimate_token_count(result) > max_tokens:
        result = truncate_for_llm(result, max_tokens)
    return result


def extract_code_blocks(markdown: str) -> list[dict]:
    """Extract code blocks from markdown."""
    blocks = []
    pattern = re.compile(r"```(\w+)?\n(.*?)```", re.DOTALL)
    for match in pattern.finditer(markdown):
        blocks.append(
            {
                "language": match.group(1) or "text",
                "code": match.group(2).strip(),
            }
        )
    return blocks


def extract_headings(markdown: str) -> list[dict]:
    """Extract headings from markdown."""
    headings = []
    for line in markdown.split("\n"):
        match = re.match(r"^(#{1,6})\s+(.+)$", line)
        if match:
            headings.append(
                {
                    "level": len(match.group(1)),
                    "text": match.group(2).strip(),
                }
            )
    return headings


def estimate_token_count(text: str) -> int:
    """Estimate token count (very rough: ~4 chars per token)."""
    return len(text) // 4
