"""Qwen Code adapter.

Qwen Code is an open-source AI coding agent (https://github.com/QwenLM/qwen-code).
This adapter registers the maru MCP server and deploys skill files.
"""

from __future__ import annotations

import shutil
from pathlib import Path

from ..backup import backup_file, read_json_safe, restore_file, sorted_backup_paths, write_json_safe
from .base import AgentAdapter, get_mcp_server_command_list


class QwenCodeAdapter(AgentAdapter):
    name = "qwen_code"
    display_name = "Qwen Code"

    def detect(self) -> bool:
        return shutil.which("qwen") is not None or Path.home().joinpath(".qwen").exists()

    def _config_path(self, scope: str) -> Path:
        if scope == "project":
            return Path(".qwen") / "settings.json"
        return Path.home() / ".qwen" / "settings.json"

    def _skills_dir(self, scope: str) -> Path | None:
        if scope == "project":
            return Path(".qwen") / "agents"
        return Path.home() / ".qwen" / "agents"

    skills_format = "flat"

    def backup(self) -> list[Path]:
        path = self._config_path("user")
        b = backup_file(path)
        return [b] if b else []

    def restore(self) -> bool:
        path = self._config_path("user")
        backups = sorted_backup_paths(path)
        if backups:
            return restore_file(path, backups[0])
        return False

    def install_mcp(self, scope: str = "user") -> bool:
        path = self._config_path(scope)
        config = read_json_safe(path)
        if "mcpServers" not in config:
            config["mcpServers"] = {}

        config["mcpServers"]["maru-deep-pro-search"] = {
            "command": get_mcp_server_command_list()[0],
            "args": get_mcp_server_command_list()[1:],
            "timeout": 15000,
        }
        write_json_safe(path, config)
        return True

    def inject_rules(self, scope: str = "user") -> bool:
        # Qwen Code uses agent markdown files with YAML frontmatter under
        # ~/.qwen/agents/ or .qwen/agents/.  Rules are delivered as SKILL.md
        # via install_skills(); no JSON config keys are needed.
        return True

    def install_skills(self, scope: str = "user") -> bool:
        """Deploy SKILL.md files to Qwen Code's agents directory."""
        skills_src = self._get_skills_source_dir()
        skills_dst = self._skills_dir(scope)
        if skills_dst is None:
            return False

        skills_dst.mkdir(parents=True, exist_ok=True)
        copied = 0
        for src_file in skills_src.glob("*.md"):
            dst_file = skills_dst / src_file.name
            try:
                content = src_file.read_text(encoding="utf-8")
                dst_file.write_text(content, encoding="utf-8")
                copied += 1
            except OSError:
                continue
        return copied > 0
