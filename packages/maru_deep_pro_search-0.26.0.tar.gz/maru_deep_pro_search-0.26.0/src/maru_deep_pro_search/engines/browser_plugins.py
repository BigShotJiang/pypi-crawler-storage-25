"""Browser plugin architecture for swappable browser engines.

Supports Playwright (default) and CloakBrowser (stealth) engines via
a uniform interface.  The active engine is selected via config or
falls back to Playwright when CloakBrowser is not installed.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any

logger = logging.getLogger(__name__)


class BrowserPlugin(ABC):
    """Abstract base for browser fetch plugins.

    Implementations must provide ``launch()``, ``goto()``,
    ``get_content()``, and ``close()`` methods.
    """

    @abstractmethod
    async def fetch(self, url: str, **kwargs: Any) -> str:
        """Fetch a URL and return extracted text/markdown.

        Args:
            url: Target URL.
            **kwargs: Engine-specific options (headless, humanize, etc.).

        Returns:
            Extracted page content.
        """

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable plugin name."""


class PlaywrightPlugin(BrowserPlugin):
    """Default Playwright-based fetch plugin.

    Uses the existing SearchEngineRegistry fetch infrastructure.
    """

    def __init__(self) -> None:
        from ..engines.registry import SearchEngineRegistry

        self._registry = SearchEngineRegistry

    @property
    def name(self) -> str:
        return "playwright"

    async def fetch(self, url: str, **kwargs: Any) -> str:
        """Fetch via Playwright engine."""
        engine_name = kwargs.get("engine", "duckduckgo_fetch")
        if engine_name not in self._registry.list_engines():
            engine_name = "duckduckgo_lite"

        engine = self._registry.create(engine_name)
        page = await engine.fetch(url, stealth=kwargs.get("stealth", False))

        # Return markdown or plain text
        return page.markdown or page.text or ""


class CloakBrowserPlugin(BrowserPlugin):
    """CloakBrowser stealth plugin.

    Requires ``cloakbrowser`` to be installed separately::

        pip install cloakbrowser

    Falls back to Playwright with a warning when unavailable.
    """

    def __init__(self) -> None:
        self._cloak: Any | None = None
        self._browser: Any | None = None
        self._playwright_fallback = PlaywrightPlugin()

    @property
    def name(self) -> str:
        return "cloakbrowser"

    def _ensure_import(self) -> bool:
        """Lazy import cloakbrowser; return True if available."""
        if self._cloak is not None:
            return True
        try:
            import cloakbrowser  # type: ignore[import-not-found]

            self._cloak = cloakbrowser
            return True
        except ImportError:
            logger.warning("cloakbrowser not installed. Install: pip install cloakbrowser")
            return False

    async def fetch(self, url: str, **kwargs: Any) -> str:
        """Fetch via CloakBrowser with humanize + stealth.

        Falls back to Playwright if cloakbrowser is unavailable.
        """
        if not self._ensure_import():
            logger.info("Falling back to Playwright for %s", url)
            return await self._playwright_fallback.fetch(url, **kwargs)

        import asyncio

        # CloakBrowser uses sync API; run in thread pool
        loop = asyncio.get_running_loop()

        def _fetch_sync() -> str:
            browser = self._cloak.launch(  # type: ignore[union-attr]
                headless=kwargs.get("headless", True),
                humanize=kwargs.get("humanize", True),
            )
            try:
                page = browser.new_page()
                page.goto(url)
                # Extract content (CloakBrowser page has similar API to Playwright)
                content: str = page.content()
                return content
            finally:
                browser.close()

        try:
            return await loop.run_in_executor(None, _fetch_sync)
        except Exception as exc:  # noqa: BLE001
            logger.warning("CloakBrowser fetch failed for %s: %s", url, exc)
            logger.info("Falling back to Playwright")
            return await self._playwright_fallback.fetch(url, **kwargs)


# Plugin registry
_PLUGINS: dict[str, type[BrowserPlugin]] = {
    "playwright": PlaywrightPlugin,
    "cloakbrowser": CloakBrowserPlugin,
}


def get_browser_plugin(name: str | None = None) -> BrowserPlugin:
    """Return a browser plugin instance by name.

    Args:
        name: Plugin identifier ("playwright" or "cloakbrowser").
            When ``None``, reads from ``DEFAULT_CONFIG.browser_engine``.

    Returns:
        Instantiated browser plugin.
    """
    if name is None:
        from ..config import DEFAULT_CONFIG

        name = getattr(DEFAULT_CONFIG, "browser_engine", "playwright")

    name = name or "playwright"
    plugin_cls = _PLUGINS.get(name, PlaywrightPlugin)
    return plugin_cls()


def list_browser_plugins() -> list[str]:
    """Return available browser plugin names."""
    return list(_PLUGINS.keys())
