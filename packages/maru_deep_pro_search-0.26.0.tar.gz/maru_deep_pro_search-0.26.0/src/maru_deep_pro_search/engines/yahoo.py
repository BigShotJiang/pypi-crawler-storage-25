"""Yahoo Search engine implementation with direct HTML scraping."""

from __future__ import annotations

import asyncio
import logging
from urllib.parse import quote_plus

from scrapling import AsyncFetcher

from ..config import DEFAULT_CONFIG
from ..exceptions import NetworkError, ParseError
from ..utils.retry import with_retry
from ..utils.url import get_domain, resolve_canonical_url, resolve_redirect, should_skip_url
from .base import (
    DOCS_DOMAINS,
    SearchEngine,
    SearchResult,
    _first,
    _guess_content_type,
    guess_source_type_and_primary,
)

logger = logging.getLogger(__name__)

_SERP_SELECTORS = {
    "containers": [".algo"],
    "title": ["h3 span", "h3", ".title"],
    "url": [".compTitle a", "a[href]"],
    "snippet": [".compText p", ".compText span", ".compText"],
}


class YahooEngine(SearchEngine):
    """Yahoo Search engine with direct HTML scraping."""

    name = "yahoo"
    supports_stealth = False
    quality_tier = 2
    typical_latency_ms = 1200
    reliability_score = 0.85
    min_request_interval = 1.0

    def __init__(self):
        super().__init__()
        self._fetcher = AsyncFetcher()

    async def search(self, query: str, max_results: int = 10) -> list[SearchResult]:
        """Search Yahoo with retry and fallback selectors."""
        search_url = f"https://search.yahoo.com/search?p={quote_plus(query)}&n={max_results}"

        try:
            page = await with_retry(
                self._fetcher.get,
                search_url,
                max_attempts=DEFAULT_CONFIG.retry_attempts,
                retryable_exceptions=(NetworkError, asyncio.TimeoutError),
            )
        except Exception as exc:
            logger.error("Yahoo SERP scrape failed: %s", exc)
            raise NetworkError(f"Failed to fetch Yahoo SERP: {exc}", retryable=True) from exc

        results: list[SearchResult] = []
        seen: set[str] = set()

        containers = []
        for sel in _SERP_SELECTORS["containers"]:
            containers = page.css(sel)
            if containers:
                break

        for el in containers[: max_results * 2]:
            title_el = _first(el, _SERP_SELECTORS["title"])
            url_el = _first(el, _SERP_SELECTORS["url"])
            snippet_el = _first(el, _SERP_SELECTORS["snippet"])

            # Yahoo h3 span contains the actual title text
            title = title_el.get_all_text().replace("\n", " ").strip() if title_el else ""
            href = url_el.attrib.get("href", "") if url_el else ""
            snippet = snippet_el.get_all_text().replace("\n", " ").strip() if snippet_el else ""

            href = resolve_redirect(href, search_url)
            href = resolve_canonical_url(href)
            if not href or not title:
                continue
            if should_skip_url(href):
                continue

            norm = href.rstrip("/")
            if norm in seen:
                continue
            seen.add(norm)

            domain = get_domain(href)
            source_type, is_primary = guess_source_type_and_primary(href, snippet)
            results.append(
                SearchResult(
                    title=title,
                    url=href,
                    snippet=snippet,
                    position=len(results) + 1,
                    likely_content_type=_guess_content_type(href, snippet),
                    domain=domain,
                    url_suggests_docs=any(d in domain for d in DOCS_DOMAINS),
                    engine=self.name,
                    source_type=source_type,
                    is_primary=is_primary,
                )
            )
            if len(results) >= max_results:
                break

        if not results:
            raise ParseError(
                "No results found on Yahoo",
                retryable=True,
                suggested_engine="duckduckgo_lite",
            )

        return results
