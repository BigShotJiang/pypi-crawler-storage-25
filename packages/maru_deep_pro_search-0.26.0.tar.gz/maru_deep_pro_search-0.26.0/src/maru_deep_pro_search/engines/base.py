"""Abstract base classes and data models for search engines."""

from __future__ import annotations

import asyncio
import logging
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from functools import wraps
from urllib.parse import urlparse

from ..exceptions import NetworkError
from ..utils.rate_limiter import CircuitBreaker, RateLimiter

logger = logging.getLogger(__name__)


class ContentType(str, Enum):
    ARTICLE = "article"
    DOCUMENTATION = "docs"
    FORUM = "forum"
    CODE = "code"
    SPAM = "spam"
    UNKNOWN = "unknown"


class SourceType(str, Enum):
    """Classification of source origin for trust and citation quality."""

    OFFICIAL_DOCS = "official_docs"
    GITHUB_REPO = "github_repo"
    BLOG_REVIEW = "blog_review"
    TUTORIAL = "tutorial"
    ACADEMIC_PAPER = "academic_paper"
    FORUM = "forum"
    PACKAGE_REGISTRY = "package_registry"
    NEWS = "news"
    UNKNOWN = "unknown"


class ExtractionQuality(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    EMPTY = "empty"
    BLOCKED = "blocked"


@dataclass
class SearchResult:
    """A single search result from any engine."""

    title: str
    url: str
    snippet: str = ""
    position: int = 0
    likely_content_type: ContentType = ContentType.UNKNOWN
    source_type: SourceType = SourceType.UNKNOWN
    is_primary: bool = False
    domain: str = ""
    url_suggests_docs: bool = False
    engine: str = ""
    # Citation support
    citation_id: int = 0
    # Cross-engine metadata
    engines_found: list[str] = field(default_factory=list)
    cross_engine_score: float = 0.0
    query_coverage: float = 0.0
    access_risk: str = "open"
    access_reasons: list[str] = field(default_factory=list)
    noise_penalty: float = 0.0


@dataclass
class PageContent:
    """Extracted content from a fetched page."""

    url: str
    final_url: str = ""
    title: str = ""
    text: str = ""
    markdown: str = ""
    html: str = ""

    quality: ExtractionQuality = ExtractionQuality.EMPTY
    content_type: ContentType = ContentType.UNKNOWN
    content_length: int = 0
    heading_count: int = 0
    code_block_count: int = 0
    extraction_method: str = ""
    duplicate_ratio: float = 0.0

    internal_links: list[dict] = field(default_factory=list)
    external_links: list[dict] = field(default_factory=list)
    needs_stealth: bool = False
    access_risk: str = "open"
    access_reasons: list[str] = field(default_factory=list)
    fetch_duration_ms: float = 0.0
    error_message: str = ""

    published_date: str = ""
    last_updated: str = ""
    crawled_at: str = ""
    code_languages: list[str] = field(default_factory=list)
    api_signatures: list[dict] = field(default_factory=list)
    package_refs: list[dict] = field(default_factory=list)
    code_to_text_ratio: float = 0.0
    freshness_days: int | None = None
    is_api_reference: bool = False
    is_tutorial: bool = False
    is_error_solution: bool = False

    # Source classification
    source_type: SourceType = SourceType.UNKNOWN
    is_primary: bool = False
    github_meta: dict | None = None

    # Citation support for answer synthesis
    citation_id: int = 0


class SearchEngine(ABC):
    """Abstract base for all search engines.

    Subclasses should set quality metadata to help the registry
    recommend optimal engine combinations.

    Rate limiting:
        ``min_request_interval`` enforces a minimum delay between
        consecutive successful requests. Set it per-engine based on
        how strict the target site's rate limits are.

    Circuit breaker:
        Automatically stops sending requests to an engine after
        repeated failures, recovering after a cooldown period.

    Note:
        The ``search()`` method is automatically wrapped at class
        creation time to inject cooldown and circuit-breaker logic.
        Subclasses implement ``_do_search()`` instead.
    """

    name: str = ""
    supports_stealth: bool = False

    # Quality metadata (used by SearchEngineRegistry.recommend_engines)
    quality_tier: int = 2  # 1=best, 2=good, 3=fallback/last-resort
    typical_latency_ms: int = 1200
    reliability_score: float = 0.9  # 0.0-1.0, higher is more reliable

    # Rate limiting: minimum seconds between requests to this engine
    min_request_interval: float = 0.0

    # Rate limiter: max requests per window (additional layer beyond cooldown)
    rate_limit_max_requests: int = 10
    rate_limit_window_seconds: float = 60.0

    def __init__(self) -> None:
        self._last_request_time: float = 0.0
        self._cooldown_lock = asyncio.Lock()
        self._circuit_breaker = CircuitBreaker(
            failure_threshold=3,
            recovery_seconds=60.0,
        )
        self._rate_limiter = RateLimiter(
            max_requests=self.rate_limit_max_requests,
            window_seconds=self.rate_limit_window_seconds,
        )

    async def _ensure_cooldown(self) -> None:
        """Wait until ``min_request_interval`` has elapsed since the last request."""
        if self.min_request_interval <= 0:
            return
        async with self._cooldown_lock:
            elapsed = time.monotonic() - self._last_request_time
            if elapsed < self.min_request_interval:
                delay = self.min_request_interval - elapsed
                logger.debug("[%s] Cooling down for %.2fs", self.name, delay)
                await asyncio.sleep(delay)
            self._last_request_time = time.monotonic()

    async def _check_circuit(self) -> bool:
        """Return True if the circuit breaker allows execution."""
        if not await self._circuit_breaker.can_execute():
            logger.warning("[%s] Circuit breaker is OPEN; skipping request", self.name)
            return False
        return True

    async def _record_success(self) -> None:
        """Record a successful request for circuit breaker tracking."""
        await self._circuit_breaker.record_success()

    async def _record_failure(self) -> None:
        """Record a failed request for circuit breaker tracking."""
        await self._circuit_breaker.record_failure()

    def __init_subclass__(cls, **kwargs):
        """Wrap subclass ``search()`` and ``fetch()`` with rate-limit + circuit-breaker logic."""
        super().__init_subclass__(**kwargs)
        original_search = cls.search

        @wraps(original_search)
        async def _wrapped_search(self, query: str, max_results: int = 10) -> list[SearchResult]:
            await self._rate_limiter.acquire()
            await self._ensure_cooldown()
            if not await self._check_circuit():
                raise NetworkError(
                    f"{self.name} circuit breaker is open",
                    retryable=False,
                    suggested_engine="duckduckgo_lite",
                )
            try:
                results = await original_search(self, query, max_results)
                await self._record_success()
                return results  # type: ignore[no-any-return]
            except Exception as exc:
                if isinstance(exc, (NetworkError, asyncio.TimeoutError)):
                    await self._record_failure()
                raise

        cls.search = _wrapped_search  # type: ignore[method-assign]

        original_fetch = cls.fetch

        @wraps(original_fetch)
        async def _wrapped_fetch(
            self, url: str, stealth: bool = False, timeout: float = 15.0
        ) -> PageContent:
            await self._rate_limiter.acquire()
            await self._ensure_cooldown()
            if not await self._check_circuit():
                return PageContent(
                    url=url,
                    error_message=f"{self.name} circuit breaker is open",
                    quality=ExtractionQuality.BLOCKED,
                    access_risk="temporarily_unavailable",
                    access_reasons=["circuit_breaker"],
                )
            try:
                result = await original_fetch(self, url, stealth, timeout)
                await self._record_success()
                return result  # type: ignore[no-any-return]
            except Exception as exc:
                if isinstance(exc, (NetworkError, asyncio.TimeoutError)):
                    await self._record_failure()
                raise

        cls.fetch = _wrapped_fetch  # type: ignore[method-assign]

    @abstractmethod
    async def search(self, query: str, max_results: int = 10) -> list[SearchResult]:
        """Search and return results."""
        ...

    async def fetch(self, url: str, stealth: bool = False, timeout: float = 15.0) -> PageContent:
        """Fetch and extract content from a URL.

        Default implementation delegates to DuckDuckGo for content extraction.
        Override in engines that have their own fetch implementation.
        """
        from .registry import SearchEngineRegistry

        engine = SearchEngineRegistry.create("duckduckgo")
        return await engine.fetch(url, stealth=stealth, timeout=timeout)


class BaseHtmlEngine(SearchEngine):
    """Template method engine for HTML-scraped search results.

    Subclasses only need to define:
    - ``_selectors``: dict with "containers", "title", "url", "snippet" keys
    - ``_build_search_url(query, max_results)``: returns the search URL
    - Optionally override ``_extract_result(el)`` for engine-specific parsing

    This eliminates ~80% of boilerplate across the 8 HTML-scraping engines.
    """

    _selectors: dict[str, list[str]] = {
        "containers": [],
        "title": [],
        "url": [],
        "snippet": [],
    }

    def _build_search_url(self, query: str, max_results: int) -> str:
        """Build the search URL for this engine. Override in subclasses."""
        raise NotImplementedError

    def _extract_result(self, element, position: int) -> SearchResult | None:
        """Parse a single SERP element into a SearchResult. Override for custom logic."""
        title_el = _first(element, self._selectors["title"])
        url_el = _first(element, self._selectors["url"])
        snippet_el = _first(element, self._selectors["snippet"])

        title = _text(title_el) or ""
        href = url_el.attrib.get("href", "") if url_el else ""
        snippet = _text(snippet_el) or ""

        if not href or not title:
            return None

        from ..utils.url import get_domain, should_skip_url

        if should_skip_url(href):
            return None

        domain = get_domain(href)
        source_type, is_primary = guess_source_type_and_primary(href, snippet)

        return SearchResult(
            title=title,
            url=href,
            snippet=snippet,
            position=position,
            likely_content_type=_guess_content_type(href, snippet),
            domain=domain,
            url_suggests_docs=any(d in domain for d in DOCS_DOMAINS),
            engine=self.name,
            source_type=source_type,
            is_primary=is_primary,
        )

    async def search(self, query: str, max_results: int = 10) -> list[SearchResult]:
        """Search using the template method pattern."""
        from ..config import DEFAULT_CONFIG
        from ..utils.retry import with_retry

        search_url = self._build_search_url(query, max_results)
        fetcher = getattr(self, "_fetcher", None)
        if fetcher is None:
            raise RuntimeError(f"{self.name} has no _fetcher; cannot search")

        try:
            page = await with_retry(
                fetcher.get,
                search_url,
                max_attempts=DEFAULT_CONFIG.retry_attempts,
                retryable_exceptions=(NetworkError, asyncio.TimeoutError),
            )
        except Exception as exc:
            logger.error("%s SERP scrape failed: %s", self.name, exc)
            raise NetworkError(f"Failed to fetch {self.name} SERP: {exc}", retryable=True) from exc

        results: list[SearchResult] = []
        seen: set[str] = set()

        containers = []
        for sel in self._selectors["containers"]:
            containers = page.css(sel)
            if containers:
                break

        for el in containers[: max_results * 3]:
            sr = self._extract_result(el, len(results) + 1)
            if sr is None:
                continue
            norm = sr.url.rstrip("/")
            if norm in seen:
                continue
            seen.add(norm)
            results.append(sr)
            if len(results) >= max_results:
                break

        if not results:
            from ..exceptions import ParseError

            raise ParseError(
                f"No results found on {self.name}",
                retryable=True,
                suggested_engine="duckduckgo_lite",
            )

        return results


# ── Shared extraction utilities ─────────────────────────────────────────────


def _first(el, selectors: list[str]):
    """Try multiple CSS selectors and return the first match."""
    for sel in selectors:
        results = el.css(sel)
        if results:
            return results[0]
    return None


def _text(el) -> str:
    """Safely extract text from a scrapling element.

    scrapling's ``TextHandler`` can return ``None`` for ``.text``
    on nested elements. This helper falls back to ``get_all_text()``.
    """
    if el is None:
        return ""
    if el.text is not None:
        return str(el.text).strip()
    return el.get_all_text().strip() if hasattr(el, "get_all_text") else ""


def _guess_content_type(url: str, snippet: str = "") -> ContentType:
    """Guess content type from URL and snippet text."""
    lower = (url + " " + snippet).lower()
    domain = urlparse(url).netloc.lower()

    # Korean-specific detection
    korean_indicators = [
        "velog.io",
        "tistory.com",
        "naver.com/blog",
        "brunch.co.kr",
        "okky.kr",
    ]
    if any(ind in domain for ind in korean_indicators):
        if "github.com" in domain:
            return ContentType.CODE
        return ContentType.ARTICLE

    if any(k in lower for k in ["github.com", "gitlab.com", "bitbucket.org"]):
        return ContentType.CODE
    if any(k in lower for k in ["stackoverflow.com", "stackexchange.com", "discourse", "forum"]):
        return ContentType.FORUM
    if any(
        k in lower
        for k in [".docs.", "docs.", "/docs/", "documentation", "reference", "api.", "/api/"]
    ):
        return ContentType.DOCUMENTATION
    if any(
        k in lower
        for k in [
            "medium.com",
            "dev.to",
            "blog.",
            "/blog/",
            "tistory.com",
            "velog.io",
            "brunch.co.kr",
        ]
    ):
        return ContentType.ARTICLE
    return ContentType.UNKNOWN


def guess_source_type_and_primary(url: str, snippet: str = "") -> tuple[SourceType, bool]:
    """Guess source type and whether it is a primary source.

    Returns (source_type, is_primary).
    """
    from ..utils.url import classify_source_type, is_primary_source

    st_str = classify_source_type(url, snippet)
    is_prim = is_primary_source(url, st_str)

    try:
        st = SourceType(st_str)
    except ValueError:
        st = SourceType.UNKNOWN

    return st, is_prim


# Shared documentation domain whitelist — used by all engines for
# url_suggests_docs classification.
DOCS_DOMAINS: frozenset[str] = frozenset(
    {
        "docs.python.org",
        "python.org",
        "developer.mozilla.org",
        "mdn.io",
        "react.dev",
        "nextjs.org",
        "nodejs.org",
        "deno.com",
        "go.dev",
        "pkg.go.dev",
        "doc.rust-lang.org",
        "docs.rs",
        "api.rubyonrails.org",
        "guides.rubyonrails.org",
        "learn.microsoft.com",
        "docs.microsoft.com",
        "postgresql.org/docs",
        "dev.mysql.com/doc",
        "kubernetes.io/docs",
        "helm.sh/docs",
        "terraform.io/docs",
        "fastapi.tiangolo.com",
        "flask.palletsprojects.com",
        "docs.djangoproject.com",
        "vuejs.org",
        "svelte.dev",
        "developers.google.com",
        "cloud.google.com",
    }
)
