"""Unified query intent classification for engine selection, ranking, and expansion.

Consolidates intent detection previously scattered across ``fetch_planner.py``
(4-type regex), ``expander.py`` (10+-type regex), and ``registry.py`` (locale
boosts).  When the local RefinerEngine is available, a zero-shot LLM classifier
is used for nuanced queries; the regex rules serve as a fast fallback.

Output is an ``IntentClassification`` dataclass — a single source of truth for
* all downstream consumers.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Intent classification result
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class IntentClassification:
    """Classification of a user query intent with downstream hints.

    Attributes:
        intent: Canonical intent label.
        confidence: 0.0--1.0 confidence estimate.
        suggested_engines: Engine names to prefer for this intent.
        source_scope: Guidance for source-type filtering.
        ranking_weights: Scalar overrides for the ranker's built-in weights.
    """

    intent: str
    confidence: float = 0.8
    suggested_engines: list[str] = field(default_factory=list)
    source_scope: str = "auto"
    ranking_weights: dict[str, float] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Intent-to-scope mapping
# ---------------------------------------------------------------------------

_INTENT_TO_SCOPE: dict[str, str] = {
    "security": "auto",  # security needs all sources
    "howto": "discussions",  # stackoverflow, github issues
    "comparison": "auto",
    "docs": "docs",
    "versioned": "auto",
    "debug": "discussions",
    "definition": "docs",
    "news": "news",
    "trends": "auto",
    "korean": "auto",
    "korean_nlp": "docs",
    "api_ref": "docs",
}

# ---------------------------------------------------------------------------
# Intent-to-engine boosts (additive to registry's base scores)
# ---------------------------------------------------------------------------

_INTENT_ENGINE_BOOSTS: dict[str, dict[str, float]] = {
    "security": {"bing": 2.0, "google": 0.5},
    "howto": {"duckduckgo_lite": 1.0, "startpage": 0.5},
    "comparison": {"duckduckgo_lite": 1.0, "bing": 1.0},
    "docs": {"bing": 1.5, "startpage": 1.0, "duckduckgo_lite": 0.5},
    "versioned": {"bing": 1.0, "google": 0.5},
    "debug": {"duckduckgo_lite": 1.0},
    "definition": {"duckduckgo_lite": 1.0},
    "news": {"google": 1.0, "bing": 1.0},
    "trends": {"duckduckgo_lite": 1.0},
    "korean": {"naver": 3.0},
    "korean_nlp": {"naver": 3.0, "google": 0.5},
    "api_ref": {"bing": 1.5, "startpage": 1.0},
}

# ---------------------------------------------------------------------------
# Intent-to-ranking-weight overrides
# ---------------------------------------------------------------------------

_INTENT_RANKING_WEIGHTS: dict[str, dict[str, float]] = {
    "security": {"authority": 3.0, "freshness": 2.0, "official": 2.5},
    "howto": {"tutorial": 2.0, "code_blocks": 1.5, "forum": 1.5},
    "comparison": {"cross_engine": 2.0, "diversity": 1.5},
    "docs": {"official_docs": 3.0, "api_ref": 2.0},
    "versioned": {"freshness": 2.5, "authority": 1.5},
    "debug": {"forum": 2.0, "tutorial": 1.0},
    "news": {"freshness": 3.0, "authority": 1.5},
}

# ---------------------------------------------------------------------------
# Refiner-based classification prompt
# ---------------------------------------------------------------------------

_INTENT_CLASSIFY_PROMPT = (
    "Classify this user query into exactly ONE intent category:\n"
    "Query: {query}\n\n"
    "Categories:\n"
    "- security: CVEs, vulnerabilities, exploits, security advisories\n"
    "- howto: installation, setup, configuration, tutorials, guides\n"
    "- comparison: vs, versus, compare, difference between, which is better\n"
    "- docs: official documentation, API references, spec lookups\n"
    "- versioned: version-specific releases, breaking changes, migration guides\n"
    "- debug: errors, bugs, troubleshooting, fixes, deprecation warnings\n"
    "- definition: what is X, meaning of, definitions, introductions\n"
    "- news: latest news, announcements, releases, updates\n"
    "- trends: technology trends, ecosystem overviews, state of X\n"
    "- api_ref: API method signatures, endpoint docs, parameter lists\n"
    "- korean: Korean-language general queries\n"
    "- korean_nlp: Korean NLP models, datasets, or research\n"
    "- general: none of the above\n\n"
    "Respond with ONLY the category label (one word)."
)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def classify_intent(query: str, use_refiner: bool = True) -> IntentClassification:
    """Classify query intent, optionally using the local RefinerEngine.

    Args:
        query: The search query to classify.
        use_refiner: When ``True`` (default) and the RefinerEngine is available,
            attempt zero-shot LLM classification first.  Falls back to regex.

    Returns:
        ``IntentClassification`` with intent, confidence, and downstream hints.
    """
    # ── LLM-based (optional) ────────────────────────────────────────
    if use_refiner:
        llm_result = _classify_with_refiner(query)
        if llm_result is not None:
            return llm_result

    # ── Regex-based (always available) ──────────────────────────────
    intent = _detect_intent(query)
    return _build_result(intent, query)


def _detect_intent(query: str) -> str:
    """Regex-based intent detection (fallback path).

    Consolidated from ``expander.py:_detect_intent()`` and
    ``fetch_planner.py:detect_query_intent()``.
    """
    # Short-circuit: short queries default to definition/general
    if len(query.strip()) < 8:
        return "general"

    lower = query.lower()

    def contains_marker(marker: str) -> bool:
        return re.search(rf"(?<![a-z0-9]){re.escape(marker)}(?![a-z0-9])", lower) is not None

    # ── Korean / locale ────────────────────────────────────────────
    has_korean = any("\uac00" <= char <= "\ud7a3" for char in query)
    korean_keywords = ["한국", "국내", "korean", "한글", "한국어"]
    korean_nlp_terms = [
        "텍스트",
        "감정",
        "분류",
        "카카오톡",
        "초경량",
        "형태소",
        "토픽",
        "요약",
        "nlp",
    ]
    korean_nlp_models = ["koelectra", "kcelectra", "kr-electra", "kobert", "nsmc"]
    if any(model in lower for model in korean_nlp_models) or (
        (has_korean or "korean" in lower) and any(term in lower for term in korean_nlp_terms)
    ):
        return "korean_nlp"
    if has_korean or any(kw in lower for kw in korean_keywords):
        return "korean"

    # ── Security ────────────────────────────────────────────────────
    if any(
        contains_marker(marker)
        for marker in [
            "cve",
            "ghsa",
            "vulnerability",
            "vulnerabilities",
            "security advisory",
            "exploit",
            "rce",
            "zero day",
            "zero-day",
        ]
    ):
        return "security"

    # ── How-To (before versioned so "how to install foo 1.2" stays procedural) ──
    if any(
        k in lower
        for k in [
            "how to ",
            "install ",
            "setup ",
            "configure ",
            "deploy ",
            "getting started",
            "tutorial",
            "guide",
            "learn ",
            "beginner",
            "quickstart",
            "step by step",
        ]
    ):
        return "howto"

    # ── Versioned / breaking-change ─────────────────────────────────
    if any(
        k in lower
        for k in [
            "breaking change",
            "breaking changes",
            "compatibility",
            "migration",
            "release notes",
            "changelog",
        ]
    ) or (
        re.search(r"\bv?\d+\.\d+(?:\.\d+)?\b", query)
        and any(
            k in lower for k in ("release", "version", "migration", "compatibility", "changelog")
        )
    ):
        return "versioned"

    # ── Comparison ──────────────────────────────────────────────────
    if any(
        k in lower
        for k in [
            " vs ",
            " versus ",
            "compare",
            "comparison",
            "difference between",
            "diff between",
            "which is better",
            "pros and cons",
            "advantages disadvantages",
        ]
    ):
        return "comparison"

    # ── API reference ───────────────────────────────────────────────
    if any(
        k in lower
        for k in [
            "api reference",
            "endpoint",
            "method signature",
            "function signature",
            "class definition",
            "module reference",
            "sdk documentation",
        ]
    ) or (re.search(r"\b[a-z_]+\.[a-z_]+\(", query)):
        return "api_ref"

    # ── Docs (weaker signal, checked after api_ref) ─────────────────
    if any(
        k in lower
        for k in [
            "documentation",
            "official docs",
            "docs for",
            "reference manual",
            "specification",
            "spec sheet",
        ]
    ):
        return "docs"

    # ── Debug / Problem ─────────────────────────────────────────────
    if any(
        k in lower
        for k in [
            "error",
            "fix",
            "deprecated",
            "removed",
            "alternative",
            "migrate",
            "troubleshoot",
            "issue",
            "problem",
            "bug",
            "solution",
            "workaround",
            "broken",
            "fail",
        ]
    ):
        return "debug"

    # ── Definition ──────────────────────────────────────────────────
    if any(
        k in lower
        for k in [
            "what is ",
            "meaning of",
            "define ",
            "definition",
            "explain ",
            "introduction to ",
            "overview of",
        ]
    ):
        return "definition"

    # ── News ────────────────────────────────────────────────────────
    if any(
        k in lower
        for k in [
            "latest",
            "news",
            "update",
            "release",
            "announcement",
            "just released",
            "new version",
        ]
    ):
        return "news"

    # ── Trends / Landscape (catch-all for broad tech queries) ───────
    if any(
        k in lower
        for k in [
            "trends",
            "trend",
            "stack",
            "ecosystem",
            "landscape",
            "technology",
            "frameworks",
            "tools",
            "popular",
            "most used",
            "adoption",
            "state of",
        ]
    ):
        return "trends"

    # ── Default ─────────────────────────────────────────────────────
    return "general"


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _classify_with_refiner(query: str) -> IntentClassification | None:
    """Attempt zero-shot LLM classification via the local RefinerEngine.

    Returns ``None`` if the refiner is unavailable or the output cannot
    be mapped to a known intent.
    """
    # TODO: This function always returns None in async contexts because
    # RefinerEngine.refine_content is async and cannot be safely called
    # from a sync function when the loop is already running. Consider
    # refactoring classify_intent to be fully async if LLM-based
    # classification is needed here.
    return None


def _build_result(
    intent: str,
    query: str = "",
    confidence: float = 0.8,
) -> IntentClassification:
    """Build a full ``IntentClassification`` from an intent label."""
    scope = _INTENT_TO_SCOPE.get(intent, "auto")
    engines = list((_INTENT_ENGINE_BOOSTS.get(intent, {})).keys())
    weights = dict(_INTENT_RANKING_WEIGHTS.get(intent, {}))
    return IntentClassification(
        intent=intent,
        confidence=confidence,
        suggested_engines=engines,
        source_scope=scope,
        ranking_weights=weights,
    )


# ---------------------------------------------------------------------------
# Convenience accessors
# ---------------------------------------------------------------------------


def intent_to_source_scope(intent: str) -> str:
    """Map an intent label to a source scope string."""
    return _INTENT_TO_SCOPE.get(intent, "auto")


def intent_to_engine_boosts(intent: str) -> dict[str, float]:
    """Return engine boost overrides for an intent."""
    return dict(_INTENT_ENGINE_BOOSTS.get(intent, {}))


def intent_to_ranking_weights(intent: str) -> dict[str, float]:
    """Return ranking weight overrides for an intent."""
    return dict(_INTENT_RANKING_WEIGHTS.get(intent, {}))
