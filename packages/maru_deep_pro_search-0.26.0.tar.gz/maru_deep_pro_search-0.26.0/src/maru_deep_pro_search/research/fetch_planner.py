"""Heuristic read planner — recommends URLs for the host LLM to fetch.

Uses the unified ``IntentClassification`` from ``research.intent`` to
drive source-type boosts and fetch priority.  No local LLM required.
"""

from __future__ import annotations

from dataclasses import dataclass
from urllib.parse import urlparse

from .deep import CitedSource
from .intent import classify_intent
from .signals import source_mentions_focus_alias

_TYPE_BOOST: dict[str, dict[str, float]] = {
    "security": {
        "official_docs": 3.0,
        "github_repo": 2.5,
        "package_registry": 2.0,
        "forum": 1.0,
        "blog_review": 0.5,
    },
    "howto": {
        "tutorial": 3.0,
        "official_docs": 2.5,
        "forum": 2.0,
        "github_repo": 1.5,
    },
    "comparison": {
        "official_docs": 2.5,
        "github_repo": 2.0,
        "blog_review": 1.5,
        "forum": 1.2,
    },
    "docs": {
        "official_docs": 4.0,
        "package_registry": 3.0,
        "github_repo": 2.0,
        "tutorial": 2.5,
        "blog_review": 0.8,
    },
    "versioned": {
        "official_docs": 3.0,
        "github_repo": 2.5,
        "package_registry": 2.0,
    },
    "debug": {
        "forum": 3.0,
        "github_repo": 2.5,
        "tutorial": 1.5,
        "official_docs": 1.5,
    },
    "news": {
        "official_docs": 2.5,
        "package_registry": 2.0,
        "github_repo": 2.0,
        "blog_review": 1.5,
    },
    "korean": {
        "official_docs": 2.5,
        "forum": 2.0,
        "github_repo": 2.0,
    },
    "korean_nlp": {
        "academic_paper": 3.0,
        "github_repo": 2.5,
        "official_docs": 2.0,
    },
    "general": {
        "official_docs": 2.5,
        "github_repo": 2.0,
        "academic_paper": 2.0,
        "package_registry": 2.0,
    },
}


@dataclass(frozen=True)
class PlannedRead:
    """A single URL the host should fetch via fetch_page / fetch_bulk."""

    citation_id: int
    url: str
    title: str
    reason: str
    score: float


def detect_query_intent(query: str) -> str:
    """Classify query intent (delegates to unified classifier).

    Preserved for backward compatibility.  New code should call
    ``classify_intent(query)`` directly.

    Args:
        query: The search query.

    Returns:
        Canonical intent label.
    """
    return classify_intent(query).intent


def _domain(url: str) -> str:
    try:
        return urlparse(url).netloc.lower().removeprefix("www.")
    except Exception:
        return ""


def _source_type_key(source_type: str) -> str:
    return source_type.replace("-", "_")


def _score_source(src: CitedSource, intent: str) -> float:
    boosts = _TYPE_BOOST.get(intent, _TYPE_BOOST["general"])
    score = src.relevance_score
    score += boosts.get(_source_type_key(src.source_type), 1.0)
    if src.is_primary:
        score += 2.0
    if src.authority_boost:
        score += 1.5
    if src.quality == "high":
        score += 1.0
    if len(src.engines_found) > 1:
        score += 0.8
    score += min(src.query_coverage * 2.0, 2.0)
    score -= min(src.noise_penalty, 3.0)
    if src.access_risk == "blocked_likely":
        score -= 4.0
    elif src.access_risk == "paywall_likely":
        score -= 1.2
    elif src.access_risk in ("paywall_possible", "dynamic_likely"):
        score -= 0.5
    # Intent-specific domain boosts
    _SECURITY_DOMAINS = {"nvd.nist", "github.com/advisories", "security"}
    _DEBUG_DOMAINS = {"stackoverflow.com", "github.com", "stackexchange.com"}
    if intent == "security" and any(x in src.url.lower() for x in _SECURITY_DOMAINS):
        score += 2.0
    if intent == "debug" and any(x in src.url.lower() for x in _DEBUG_DOMAINS):
        score += 1.5
    return score


def _reason_for(src: CitedSource, intent: str) -> str:
    parts: list[str] = []
    if src.is_primary:
        parts.append("primary source")
    if src.authority_boost:
        parts.append("authority domain")
    if len(src.engines_found) > 1:
        parts.append(f"confirmed by {len(src.engines_found)} engines")
    if src.source_type not in ("unknown", ""):
        parts.append(src.source_type.replace("-", " ").replace("_", " "))
    if src.query_coverage:
        parts.append(f"{src.query_coverage:.0%} query coverage")
    if src.access_risk != "open":
        parts.append(f"access risk: {src.access_risk}")
    if intent == "security" and "security" in src.url.lower():
        parts.append("security-related URL")
    if not parts:
        parts.append(f"top relevance ({src.relevance_score:.1f})")
    return "; ".join(parts[:3])


def plan_reads(
    query: str,
    sources: list[CitedSource],
    max_reads: int = 3,
) -> list[PlannedRead]:
    """Pick up to *max_reads* URLs for the host LLM to fetch (metadata-only)."""
    if not sources or max_reads <= 0:
        return []

    intent = detect_query_intent(query)
    query_has_focus_alias = source_mentions_focus_alias(query)
    # Pre-compute scores to avoid O(2N) calls
    score_cache = {id(s): _score_source(s, intent) for s in sources}
    ranked = sorted(sources, key=lambda s: score_cache[id(s)], reverse=True)
    viable = [
        s
        for s in ranked
        if s.query_coverage >= 0.25
        or (
            query_has_focus_alias
            and s.is_primary
            and source_mentions_focus_alias(f"{s.title} {s.url} {s.snippet}")
        )
        or len(s.engines_found) > 1
    ]
    if viable:
        ranked = viable
    elif ranked and max(score_cache[id(s)] for s in ranked) < 1.0:
        return []

    chosen: list[PlannedRead] = []
    domain_counts: dict[str, int] = {}
    type_counts: dict[str, int] = {}
    # Stricter per-domain limiting for precision-oriented intents
    _single_domain_intents = frozenset({"security", "docs", "comparison", "versioned", "api_ref"})
    max_per_domain = 1 if intent in _single_domain_intents else 2
    max_per_type = 2

    for src in ranked:
        if len(chosen) >= max_reads:
            break
        dom = _domain(src.url)
        stype = _source_type_key(src.source_type)
        if dom and domain_counts.get(dom, 0) >= max_per_domain:
            continue
        if stype and stype != "unknown" and type_counts.get(stype, 0) >= max_per_type:
            continue
        chosen.append(
            PlannedRead(
                citation_id=src.citation_id,
                url=src.url,
                title=src.title,
                reason=_reason_for(src, intent),
                score=round(score_cache[id(src)], 2),
            )
        )
        if dom:
            domain_counts[dom] = domain_counts.get(dom, 0) + 1
        if stype:
            type_counts[stype] = type_counts.get(stype, 0) + 1

    # Fill remaining slots if diversity constraints skipped too many.
    if len(chosen) < max_reads:
        picked_ids = {p.citation_id for p in chosen}
        for src in ranked:
            if len(chosen) >= max_reads:
                break
            if src.citation_id in picked_ids:
                continue
            chosen.append(
                PlannedRead(
                    citation_id=src.citation_id,
                    url=src.url,
                    title=src.title,
                    reason=_reason_for(src, intent),
                    score=round(score_cache[id(src)], 2),
                )
            )
    return chosen


def format_planned_reads(planned: list[PlannedRead]) -> str:
    """Markdown block for deep_research output (host consumes, no synthesis)."""
    if not planned:
        return ""

    lines = [
        "### Recommended Reads",
        "",
        "_Host: call `fetch_page` or `fetch_bulk` on these IDs first (metadata-ranked, no local LLM)._",
        "",
    ]
    for p in planned:
        lines.append(f"- **[{p.citation_id}]** {p.title}")
        lines.append(f"  - URL: {p.url}")
        lines.append(f"  - Why: {p.reason}")
    lines.append("")
    return "\n".join(lines)
