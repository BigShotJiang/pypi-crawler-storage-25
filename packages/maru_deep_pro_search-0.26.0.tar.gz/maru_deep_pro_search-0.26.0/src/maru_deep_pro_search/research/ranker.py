"""Intelligent ranking engine for multi-source search results.

Combines BM25 relevance scoring with metadata-based quality signals
to produce Perplexity-level result ranking."""

from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import dataclass
from typing import Any

from ..config import DEFAULT_CONFIG
from ..engines.base import ContentType, PageContent, SearchResult
from ..research.expander import extract_keywords
from ..utils.url import get_domain, is_authority_domain, normalize_url
from .signals import SourceSignals, source_signals

logger = logging.getLogger(__name__)

# Metadata scoring weights
_AUTHORITY_BOOST = 2.0
_FRESHNESS_BOOST = 1.5
_DOCS_TYPE_BOOST = 1.5
_ARTICLE_TYPE_BOOST = 1.0
_CODE_TYPE_BOOST = 0.8
_FORUM_TYPE_BOOST = 0.6
_CROSS_ENGINE_BOOST = 0.5
_SNIPPET_QUALITY_BOOST = 1.0
_POSITION_DECAY = 0.1
_RRF_K = 60

# BM25 instance cache — reuses indices for repeated queries with similar corpora.
# Keyed by a hash of (query, corpus-url-signature) for fast lookup.
_bm25_cache: dict[str, Any] = {}
_bm25_cache_max = 10


def _compute_bm25_scores(query: str, results: list[SearchResult]) -> dict[str, float]:
    """Compute BM25 scores for results against the query.

    Uses a small LRU cache to avoid re-indexing for repeated queries.
    """
    try:
        from rank_bm25 import BM25Okapi
    except ImportError:
        logger.debug("rank-bm25 not available, skipping BM25 scoring")
        return {normalize_url(r.url): 0.0 for r in results}

    if not results:
        return {}

    # Tokenize query and documents
    query_tokens = extract_keywords(query)
    if not query_tokens:
        query_tokens = query.lower().split()

    corpus = []
    url_map = {}
    for r in results:
        doc = f"{r.title} {r.snippet} {r.domain}".lower()
        tokens = extract_keywords(doc) or doc.split()
        corpus.append(tokens)
        url_map[normalize_url(r.url)] = len(corpus) - 1

    # Check cache (full 256-bit hash avoids birthday collision)
    cache_key = hashlib.sha256(
        (query + "".join(r.url.split("/")[2] for r in results[:5])).encode()
    ).hexdigest()
    if cache_key in _bm25_cache:
        bm25 = _bm25_cache[cache_key]
    else:
        try:
            bm25 = BM25Okapi(corpus)
        except Exception as exc:
            logger.error("BM25 scoring failed (ranking degraded to metadata-only): %s", exc)
            return {normalize_url(r.url): 0.0 for r in results}
        # Store in cache with simple LRU eviction
        if len(_bm25_cache) >= _bm25_cache_max:
            oldest = next(iter(_bm25_cache))
            del _bm25_cache[oldest]
        _bm25_cache[cache_key] = bm25

    try:
        scores = bm25.get_scores(query_tokens)
    except Exception as exc:
        logger.error("BM25 get_scores failed (ranking degraded): %s", exc)
        return {normalize_url(r.url): 0.0 for r in results}

    return {normalize_url(r.url): scores[url_map.get(normalize_url(r.url), 0)] for r in results}


# Source scope domain boosts — applied during metadata scoring when
# the user explicitly requests a source scope (academic, discussions, docs).
_SCOPE_DOMAIN_BOOSTS: dict[str, dict[str, float]] = {
    "academic": {
        "arxiv.org": 2.5,
        "semanticscholar.org": 2.0,
        "scholar.google.com": 2.0,
        "ieee.org": 2.5,
        "acm.org": 2.0,
        "usenix.org": 2.0,
        "paperswithcode.com": 2.0,
        "researchgate.net": 1.5,
    },
    "discussions": {
        "stackoverflow.com": 2.5,
        "stackexchange.com": 2.0,
        "github.com": 1.5,
        "reddit.com": 1.5,
        "discourse": 1.5,
    },
    "docs": {
        "readthedocs.io": 3.0,
        "devdocs.io": 2.5,
        "pkg.go.dev": 2.5,
        "doc.rust-lang.org": 2.5,
        "learn.microsoft.com": 2.5,
        "postgresql.org": 2.0,
        "react.dev": 2.0,
        "nextjs.org": 2.0,
        "nodejs.org": 2.0,
        "go.dev": 2.0,
    },
    "news": {
        "news.ycombinator.com": 1.5,
        "arstechnica.com": 1.5,
        "theverge.com": 1.0,
        "techcrunch.com": 1.0,
    },
}


@dataclass
class RankedResult:
    """A search result with comprehensive ranking metadata."""

    result: SearchResult
    bm25_score: float = 0.0
    metadata_score: float = 0.0
    semantic_score: float = 0.0
    final_score: float = 0.0
    citation_id: int = 0


# Inline authority/spam lists to avoid circular imports
_TIER1_DOMAINS = {
    "github.com",
    "gitlab.com",
    "stackoverflow.com",
    "docs.python.org",
    "developer.mozilla.org",
    "react.dev",
    "nextjs.org",
    "nodejs.org",
    "go.dev",
    "pkg.go.dev",
    "doc.rust-lang.org",
    "learn.microsoft.com",
    "postgresql.org",
    "kubernetes.io",
    "docs.djangoproject.com",
    "vuejs.org",
    "svelte.dev",
    "angular.io",
    "astro.build",
    "remix.run",
    "nuxt.com",
    "trpc.io",
    "prisma.io",
    "orm.drizzle.team",
    "turso.tech",
    "neon.tech",
    "planetscale.com",
    "vercel.com",
    "cloudflare.com",
    "workers.cloudflare.com",
    "aws.amazon.com",
    "openai.com",
    "platform.openai.com",
    "anthropic.com",
    "claude.ai",
    "docs.anthropic.com",
    "ai.google.dev",
    "arxiv.org",
    "semanticscholar.org",
    "scholar.google.com",
    "ieee.org",
    "acm.org",
    "usenix.org",
    "npmjs.com",
    "pypi.org",
    "crates.io",
    "huggingface.co",
    "paperswithcode.com",
}

_SPAM_DOMAINS_LOCAL = {
    "nucamp.co",
    "pillaiinfotech.com",
    "indiit.com",
    "cloudbuzz.ai",
    "acemindtech.com",
    "solutionsuggest.com",
    "geeksforgeeks.org",
    "tutorialspoint.com",
    "javatpoint.com",
    "w3schools.com",
    "simplilearn.com",
    "intellipaat.com",
    "edureka.co",
}


def _query_freshness_boost(query: str, result: SearchResult) -> float:
    """Boost when snippet/URL mentions a year explicitly requested in the query."""
    years = re.findall(r"20\d{2}", query)
    if not years:
        return 0.0
    haystack = f"{result.url} {result.snippet or ''}".lower()
    if any(year in haystack for year in years):
        return _FRESHNESS_BOOST * DEFAULT_CONFIG.freshness_weight
    return 0.0


def _compute_rrf_scores(
    engine_results: dict[str, list[SearchResult]],
    search_runs: list[tuple[str, list[SearchResult]]] | None = None,
) -> dict[str, float]:
    """Reciprocal rank fusion across independent SERP runs."""
    scores: dict[str, float] = {}
    runs = search_runs if search_runs is not None else list(engine_results.items())
    for _run_id, results in runs:
        for rank, result in enumerate(results, start=1):
            norm = normalize_url(result.url)
            scores[norm] = scores.get(norm, 0.0) + 1.0 / (_RRF_K + rank)
    return scores


def _score_metadata(
    result: SearchResult,
    query: str = "",
    signals: SourceSignals | None = None,
    source_scope: str = "auto",
    ranking_weights: dict[str, float] | None = None,
) -> float:
    """Score a result based on metadata quality signals.

    Args:
        result: The search result to score.
        query: Original query for freshness boosting.
        signals: Pre-computed source signals.
        source_scope: Explicit scope filter (academic/discussions/docs/news/auto).
            When not ``"auto"``, boosts domains matching the selected scope.
        ranking_weights: Optional intent-based weight overrides. Supported keys:
            ``authority``, ``freshness``, ``official``, ``tutorial``,
            ``forum``, ``code_blocks``, ``cross_engine``, ``api_ref``,
            ``official_docs``.
    """
    cfg = DEFAULT_CONFIG
    auth_w = cfg.authority_weight
    snippet_w = cfg.snippet_weight
    pos_w = cfg.position_weight
    rw = ranking_weights or {}
    score = 0.0
    domain = get_domain(result.url)

    # Authority boost — stronger for tier-1 domains, amplified by intent
    auth_mult = rw.get("authority", 1.0)
    official_mult = rw.get("official_docs", 1.0)
    if any(d in domain for d in _TIER1_DOMAINS):
        score += auth_w * 2.0 * auth_mult
    elif is_authority_domain(result.url):
        score += auth_w * auth_mult

    # Spam / SEO blog penalty
    if any(d in domain for d in _SPAM_DOMAINS_LOCAL):
        score -= 3.0
    # Medium penalty — most Medium posts are low-quality SEO content
    if "medium.com" in domain:
        score -= 1.5
    # Generic blog penalty
    if domain.startswith("blog.") or ".blog" in domain:
        score -= 0.5

    # Source-scope domain boosts (academic/discussions/docs/news)
    if source_scope != "auto" and source_scope in _SCOPE_DOMAIN_BOOSTS:
        scope_map = _SCOPE_DOMAIN_BOOSTS[source_scope]
        for scope_domain, boost in scope_map.items():
            if scope_domain in domain:
                score += boost
                break  # highest-priority match only

    # Content type preference (amplified by intent weights)
    tutorial_mult = rw.get("tutorial", 1.0)
    forum_mult = rw.get("forum", 1.0)
    if result.likely_content_type == ContentType.DOCUMENTATION:
        score += _DOCS_TYPE_BOOST * max(tutorial_mult, official_mult)
    elif result.likely_content_type == ContentType.ARTICLE:
        score += _ARTICLE_TYPE_BOOST
    elif result.likely_content_type == ContentType.CODE:
        score += _CODE_TYPE_BOOST * rw.get("code_blocks", 1.0)
    elif result.likely_content_type == ContentType.FORUM:
        score += _FORUM_TYPE_BOOST * forum_mult

    # URL suggests docs
    if result.url_suggests_docs:
        score += 1.0

    # Snippet quality (length heuristic)
    if result.snippet:
        score += min(len(result.snippet) / 500, 1.0) * _SNIPPET_QUALITY_BOOST * snippet_w

    # Position bonus with decay
    score += max(0, (10 - result.position) / 10) * (1 - result.position * _POSITION_DECAY) * pos_w

    # Cross-engine confirmation boost (amplified by comparison intent)
    cross_mult = rw.get("cross_engine", 1.0)
    if len(result.engines_found) > 1:
        score += _CROSS_ENGINE_BOOST * cross_mult * min(len(result.engines_found), 3)

    if query:
        freshness_mult = rw.get("freshness", 1.0)
        score += _query_freshness_boost(query, result) * freshness_mult
    if signals is not None:
        score += signals.proximity_boost
        score -= signals.noise_penalty
        if signals.access_risk == "paywall_likely":
            score -= 0.5
        elif signals.access_risk == "paywall_possible":
            score -= 0.25
        elif signals.access_risk == "blocked_likely":
            score -= 1.5
        elif signals.access_risk == "dynamic_likely":
            score -= 0.25
        if signals.query_coverage < 0.25 and not result.is_primary:
            score -= 0.8

    return max(-5.0, min(score, 5.0))  # Normalize to [-5, 5] range


def _normalize_text(text: str) -> set[str]:
    """Normalize text for fuzzy comparison."""
    if not text:
        return set()
    # Lowercase, remove punctuation, split into words
    cleaned = "".join(c if c.isalnum() or c.isspace() else " " for c in text.lower())
    return {w for w in cleaned.split() if len(w) > 2}


def _jaccard_similarity(a: str, b: str) -> float:
    """Compute Jaccard similarity between two texts."""
    set_a = _normalize_text(a)
    set_b = _normalize_text(b)
    if not set_a or not set_b:
        return 0.0
    intersection = set_a & set_b
    union = set_a | set_b
    return len(intersection) / len(union) if union else 0.0


def _fuzzy_dedupe(
    results: list[SearchResult], threshold: float = 0.72, use_semantic: bool = True
) -> list[SearchResult]:
    """Remove results with highly similar titles or snippets even if URLs differ.

    Hybrid Jaccard + semantic dedupe catches Medium mirrors, StackOverflow
    copy-paste blogs, aggregator sites, and paraphrased duplicates.
    """
    unique: list[SearchResult] = []

    semantic_sims: dict[tuple[int, int], float] = {}
    if use_semantic and len(results) > 1:
        from .semantic_ranker import SemanticRanker

        texts = [f"{r.title} {r.snippet[:200]}" for r in results]
        sim_matrix = SemanticRanker.sentence_similarity(texts)
        if sim_matrix:
            for i in range(len(results)):
                for j in range(i):
                    semantic_sims[(j, i)] = float(sim_matrix[i][j])

    unique_indices: list[int] = []
    for i, r in enumerate(results):
        is_dup = False
        for j, u in enumerate(unique):
            # Title similarity (high weight — same title = likely duplicate)
            title_sim = _jaccard_similarity(r.title, u.title)
            # Snippet similarity (check first 200 chars)
            snippet_sim = _jaccard_similarity(r.snippet[:200], u.snippet[:200])
            # Semantic similarity (catches paraphrased duplicates)
            # Use original result index, not position in unique list
            orig_j = unique_indices[j]
            sem_sim = semantic_sims.get((orig_j, i), 0.0)

            # Duplicates: Jaccard high OR semantic very high
            if title_sim > threshold or snippet_sim > threshold or sem_sim > 0.95:
                is_dup = True
                engines = sorted(set(u.engines_found) | set(r.engines_found))
                r_better = (
                    (r.is_primary and not u.is_primary)
                    or (r.url_suggests_docs and not u.url_suggests_docs)
                    or (
                        r.is_primary == u.is_primary
                        and r.url_suggests_docs == u.url_suggests_docs
                        and len(r.snippet) > len(u.snippet) * 1.5
                    )
                )
                if r_better:
                    # Copy to avoid mutating original results held by callers
                    import copy

                    rr = copy.copy(r)
                    rr.engines_found = engines
                    unique[j] = rr
                    unique_indices[j] = i
                else:
                    u.engines_found = engines
                break

        if not is_dup:
            unique.append(r)
            unique_indices.append(i)

    logger.debug("Hybrid dedupe: %d -> %d results", len(results), len(unique))
    return unique


def merge_results(
    engine_results: dict[str, list[SearchResult]],
    query: str,
    search_runs: list[tuple[str, list[SearchResult]]] | None = None,
    semantic_topk: int = 30,
    source_scope: str = "auto",
    ranking_weights: dict[str, float] | None = None,
    dedup_mode: str = "full",
) -> list[RankedResult]:
    """Merge results from multiple engines, deduplicate, and rank.

    Args:
        engine_results: Dict mapping engine name -> list of SearchResult.
        query: Original query for BM25 scoring.
        search_runs: Optional per-run result lists for RRF scoring.
        semantic_topk: Only compute semantic similarity for the top *N*
            results (by BM25+metadata pre-score).
        source_scope: Domain boost scope (academic/discussions/docs/news/auto).
        ranking_weights: Optional intent-based weight overrides (authority,
            freshness, official_docs, tutorial, forum, code_blocks,
            cross_engine, api_ref).
        dedup_mode: Dedup strategy — ``"full"`` (Jaccard + semantic),
            ``"jaccard"`` (Jaccard only), or ``"url_only"`` (skip fuzzy dedup).

    Returns:
        List of RankedResult sorted by final_score descending.
    """
    # Phase 1: URL-level deduplicate and track which engines found each URL
    url_to_result: dict[str, SearchResult] = {}
    url_to_engines: dict[str, set[str]] = {}

    for engine_name, results in engine_results.items():
        for r in results:
            norm = normalize_url(r.url)
            if norm not in url_to_result:
                url_to_result[norm] = r
                url_to_engines[norm] = set()
            url_to_engines[norm].add(engine_name)

    # Update results with cross-engine metadata
    merged: list[SearchResult] = []
    for norm, r in url_to_result.items():
        r.engines_found = sorted(url_to_engines.get(norm, set()))
        merged.append(r)

    # Phase 2: Fuzzy dedupe — catch same content on different URLs
    if dedup_mode != "url_only":
        merged = _fuzzy_dedupe(merged, use_semantic=(dedup_mode == "full"))

    # Phase 2b: Auto-classify source type for results missing it
    signals_by_url: dict[str, SourceSignals] = {}
    for r in merged:
        if r.source_type.value == "unknown" or not r.is_primary:
            from ..engines.base import guess_source_type_and_primary

            st, prim = guess_source_type_and_primary(r.url, r.snippet)
            r.source_type = st
            r.is_primary = prim
        norm_url = normalize_url(r.url)
        signals = source_signals(query, r.title, r.snippet, r.url)
        signals_by_url[norm_url] = signals
        r.query_coverage = signals.query_coverage
        r.access_risk = signals.access_risk
        r.access_reasons = signals.access_reasons
        r.noise_penalty = signals.noise_penalty

    # Phase 3: Compute BM25 scores
    bm25_scores = _compute_bm25_scores(query, merged)
    rrf_scores = _compute_rrf_scores(engine_results, search_runs)

    # Phase 3b: Pre-score (BM25 + metadata) to select semantic top-K
    # This avoids computing embeddings for low-quality tail results.
    pre_scored: list[tuple[float, str, SearchResult]] = []
    for r in merged:
        norm_url = normalize_url(r.url)
        bm25 = bm25_scores.get(norm_url, 0.0)
        signals = signals_by_url[norm_url]
        meta = _score_metadata(r, query, signals, source_scope, ranking_weights)
        normalized_bm25 = min(bm25 / 5.0, 5.0) if bm25 > 0 else 0.0
        pre_scored.append((normalized_bm25 + meta, norm_url, r))

    pre_scored.sort(key=lambda x: x[0], reverse=True)

    # Phase 3c: Semantic scores — only for top semantic_topk results
    from .semantic_ranker import SemanticRanker  # noqa: PLC0415

    semantic_scores: dict[str, float] = {}
    if semantic_topk > 0 and pre_scored:
        top_for_semantic = [item[2] for item in pre_scored[:semantic_topk]]
        sims = SemanticRanker.score_results(query, top_for_semantic)
        for r, sim in zip(top_for_semantic, sims, strict=False):
            semantic_scores[normalize_url(r.url)] = float(sim)
    # Results beyond semantic_topk get semantic_score = 0

    # Phase 4: Build ranked results with full scores
    ranked: list[RankedResult] = []
    for _prescore, norm_url, r in pre_scored:
        bm25 = bm25_scores.get(norm_url, 0.0)
        signals = signals_by_url[norm_url]
        meta = _score_metadata(r, query, signals, source_scope, ranking_weights)
        semantic = semantic_scores.get(norm_url, 0.0)
        rrf = rrf_scores.get(norm_url, 0.0)
        # Normalize BM25 to be comparable with metadata score
        # (BM25 scores can be 0-30+, we compress to 0-5 range)
        normalized_bm25 = min(bm25 / 5.0, 5.0) if bm25 > 0 else 0.0
        # RRF typically 0-0.15 per engine; scale to ~0-3
        rrf_component = min(rrf * 20.0, 3.0)
        # Semantic similarity is [0,1]; scale to [0,2] to match BM25 weight
        final = normalized_bm25 + meta + semantic * 2.0 + rrf_component

        ranked.append(
            RankedResult(
                result=r,
                bm25_score=normalized_bm25,
                metadata_score=meta,
                semantic_score=semantic,
                final_score=final,
            )
        )

    # Sort by final score descending
    ranked.sort(key=lambda x: x.final_score, reverse=True)

    # Assign citation IDs
    for i, rr in enumerate(ranked, 1):
        rr.citation_id = i
        rr.result.citation_id = i

    logger.debug(
        "Merged %d results from %d engines, top score: %.2f",
        len(ranked),
        len(engine_results),
        ranked[0].final_score if ranked else 0,
    )

    return ranked


def rank_pages(pages: list[PageContent], query: str) -> list[PageContent]:
    """Rank fetched pages by quality and relevance.

    Args:
        pages: List of fetched PageContent.
        query: Original query.

    Returns:
        Pages sorted by combined quality+relevance score.
    """
    query_keywords = set(extract_keywords(query))

    from .semantic_ranker import SemanticRanker

    semantic_scores: dict[str, float] = {}
    if pages:
        texts = [f"{p.title} {p.text[:300]}" for p in pages]
        sims = SemanticRanker.query_sentence_similarity_batch(query, texts)
        for p, sim in zip(pages, sims, strict=False):
            semantic_scores[normalize_url(p.url)] = sim

    scored_pages: list[tuple[PageContent, float]] = []
    for p in pages:
        score = 0.0

        # Quality score
        if p.quality.value == "high":
            score += 3.0
        elif p.quality.value == "medium":
            score += 1.5
        elif p.quality.value == "low":
            score += 0.5

        # Authority
        if is_authority_domain(p.url):
            score += 2.0

        # Keyword overlap in title/content
        text = f"{p.title} {p.text[:500]}".lower()
        overlap = sum(1 for kw in query_keywords if kw in text)
        score += overlap * 0.5

        # Semantic relevance
        semantic = semantic_scores.get(normalize_url(p.url), 0.0)
        score += semantic * 2.0

        # Content type preference
        if p.content_type == ContentType.DOCUMENTATION:
            score += 1.0
        elif p.content_type == ContentType.ARTICLE:
            score += 0.5

        # Freshness
        if p.freshness_days is not None and p.freshness_days < 30:
            score += 1.0
        elif p.freshness_days is not None and p.freshness_days < 90:
            score += 0.5

        # Code richness (for dev queries)
        if p.code_to_text_ratio > 0.2:
            score += 0.5

        scored_pages.append((p, score))

    scored_pages.sort(key=lambda x: x[1], reverse=True)
    return [p for p, _ in scored_pages]
