"""Shared local embedding model for ranking, knowledge store, and security.

Default: ``ibm-granite/granite-embedding-97m-multilingual-r2`` — 97M params, Apache 2.0,
~60.3 MTEB multilingual retrieval (IBM R2 report vs ~50.9 for multilingual-e5-small).
Override with ``MARU_EMBEDDING_MODEL`` (e.g. ``intfloat/multilingual-e5-small``).

E5-family models use ``query:`` / ``passage:`` prefixes; Granite needs no task prefix.
"""

from __future__ import annotations

import functools
import logging
import os
from pathlib import Path
from threading import Lock
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_EMBEDDING_MODEL = "ibm-granite/granite-embedding-97m-multilingual-r2"
EMBEDDING_GITHUB_RELEASE = (
    "https://github.com/claudianus/maru-deep-pro-search/releases/download/embeddings-v1"
)

_ENCODER: Any = None
_CACHE_LOCK = Lock()
_PASSAGE_CACHE: dict[str, Any] = {}  # LRU-ish: evicts oldest when > max_size
_PASSAGE_CACHE_MAX_SIZE = 2000
_PASSAGE_CACHE_ACCESS: dict[str, int] = {}  # monotonic access counter for FIFO eviction
_PASSAGE_CACHE_GEN = 0


class EmbeddingUnavailableError(RuntimeError):
    """Raised when sentence-transformers is missing or the model fails to load."""


def embedding_model_name() -> str:
    """Resolved Hugging Face model id for the active embedding backend."""
    raw = os.getenv("MARU_EMBEDDING_MODEL", DEFAULT_EMBEDDING_MODEL).strip()
    return raw or DEFAULT_EMBEDDING_MODEL


def _uses_e5_prefix(model_name: str) -> bool:
    return "e5" in model_name.lower()


def format_query(text: str) -> str:
    """Prefix text for query-side embedding (E5 convention)."""
    if _uses_e5_prefix(embedding_model_name()) and not text.lower().startswith("query:"):
        return f"query: {text}"
    return text


def format_passage(text: str) -> str:
    """Prefix text for document-side embedding (E5 convention)."""
    if _uses_e5_prefix(embedding_model_name()) and not text.lower().startswith("passage:"):
        return f"passage: {text}"
    return text


def _embedding_cache_dir(model_name: str) -> Path:
    """Return the local cache directory for an embedding model."""
    safe_name = model_name.replace("/", "_").replace(":", "_")
    return Path.home() / ".cache" / "maru" / "embeddings" / safe_name


def _download_embedding_from_github(model_name: str) -> Path | None:
    """Download embedding model files from GitHub Release mirror.

    Returns the local model directory if successful, ``None`` otherwise.
    """
    try:
        import httpx
    except ImportError:
        logger.debug("httpx not available for GitHub embedding download")
        return None

    safe_name = model_name.replace("/", "_").replace(":", "_")
    base_url = f"{EMBEDDING_GITHUB_RELEASE}/{safe_name}"
    cache_dir = _embedding_cache_dir(model_name)
    cache_dir.mkdir(parents=True, exist_ok=True)

    # Files required by sentence-transformers
    required_files = [
        "config.json",
        "tokenizer_config.json",
        "tokenizer.json",
        "model.safetensors",
        "special_tokens_map.json",
        "modules.json",
        "config_sentence_transformers.json",
    ]

    all_ok = True
    for filename in required_files:
        dest = cache_dir / filename
        if dest.exists() and dest.stat().st_size > 0:
            continue

        # Try single file first, then split chunks
        urls = [f"{base_url}/{filename}"]
        if filename == "model.safetensors":
            # Large file may be split into chunks
            urls.insert(0, f"{base_url}/{filename}.part-000")

        downloaded = False
        for url in urls:
            try:
                if url.endswith(".part-000"):
                    # Split download: collect all chunks and merge
                    chunks: list[Path] = []
                    idx = 0
                    while True:
                        chunk_url = f"{base_url}/{filename}.part-{idx:03d}"
                        chunk_path = cache_dir / f"{filename}.part-{idx:03d}"
                        try:
                            r = httpx.head(chunk_url, follow_redirects=True, timeout=10.0)
                            if r.status_code == 404:
                                break
                            if r.status_code != 200:
                                break
                        except Exception:
                            break
                        with httpx.stream(
                            "GET", chunk_url, follow_redirects=True, timeout=300.0
                        ) as res:
                            res.raise_for_status()
                            with chunk_path.open("wb") as f:
                                for chunk in res.iter_bytes(chunk_size=8192):
                                    f.write(chunk)
                        chunks.append(chunk_path)
                        idx += 1
                    if chunks:
                        with dest.open("wb") as out_f:
                            for chunk_path in chunks:
                                with chunk_path.open("rb") as in_f:
                                    out_f.write(in_f.read())
                                chunk_path.unlink()
                        downloaded = True
                else:
                    # Single file download
                    with httpx.stream("GET", url, follow_redirects=True, timeout=300.0) as res:
                        res.raise_for_status()
                        with dest.open("wb") as f:
                            for chunk in res.iter_bytes(chunk_size=8192):
                                f.write(chunk)
                    downloaded = True

                if downloaded:
                    break
            except Exception as exc:
                logger.debug("Failed to download %s from %s: %s", filename, url, exc)
                continue

        if not downloaded:
            all_ok = False
            break

    if all_ok:
        return cache_dir
    return None


def get_encoder() -> Any:
    """Return a cached ``SentenceTransformer`` (loads on first use)."""
    global _ENCODER
    if _ENCODER is not None:
        return _ENCODER
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError as exc:
        raise EmbeddingUnavailableError(
            "sentence-transformers is required for maru-deep-pro-search. "
            "Install with: pip install maru-deep-pro-search"
        ) from exc
    model = embedding_model_name()
    logger.info("Loading embedding model %s...", model)

    # Determine best device: prefer GPU (Metal/CUDA) over CPU
    _DEVICE = "cpu"
    try:
        import torch

        if torch.cuda.is_available():
            _DEVICE = "cuda"
        elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            _DEVICE = "mps"
    except ImportError:
        pass

    # 1. Try local GitHub mirror cache first
    cache_dir = _embedding_cache_dir(model)
    if (cache_dir / "config.json").exists():
        try:
            _ENCODER = SentenceTransformer(str(cache_dir), device=_DEVICE)
            logger.info("Embedding model ready from local cache (%s, device=%s)", model, _DEVICE)
            return _ENCODER
        except Exception:
            logger.debug("Local cache load failed, trying GitHub mirror")

    # 2. Try downloading from GitHub Release mirror
    local_path = _download_embedding_from_github(model)
    if local_path is not None:
        try:
            _ENCODER = SentenceTransformer(str(local_path), device=_DEVICE)
            logger.info("Embedding model ready from GitHub mirror (%s)", model)
            return _ENCODER
        except Exception as exc:
            logger.warning("GitHub mirror load failed: %s", exc)

    # 3. Fallback to HuggingFace Hub (sentence-transformers built-in)
    try:
        _ENCODER = SentenceTransformer(model, device=_DEVICE)
    except Exception as exc:
        raise EmbeddingUnavailableError(f"Failed to load embedding model {model!r}: {exc}") from exc
    logger.info("Embedding model ready from HuggingFace Hub (%s)", model)
    return _ENCODER


@functools.lru_cache(maxsize=256)
def _encode_queries_tuple(texts: tuple[str, ...]) -> Any:
    """Encode query strings with an LRU cache (batch-level)."""
    encoder = get_encoder()
    prefix_texts = [format_query(t) for t in texts]
    return encoder.encode(prefix_texts, convert_to_tensor=False, show_progress_bar=False)


def encode_queries(texts: list[str]) -> Any:
    """Encode query strings (with model-specific prefixes).

    Uses ``encode_queries_cached`` internally for automatic deduplication
    across multiple ranking calls within the same search session.
    """
    return _encode_queries_tuple(tuple(texts))


@functools.lru_cache(maxsize=256)
def _encode_passages_tuple(texts: tuple[str, ...]) -> Any:
    """Encode document/passage strings with an LRU cache (batch-level)."""
    encoder = get_encoder()
    prefix_texts = [format_passage(t) for t in texts]
    return encoder.encode(prefix_texts, convert_to_tensor=False, show_progress_bar=False)


def encode_passages(texts: list[str]) -> Any:
    """Encode document/passage strings (with model-specific prefixes).

    Uses an internal LRU cache so that passages already encoded during
    deduplication can be reused during ranking — eliminating redundant
    embedding computation (common in the dedup → rank pipeline).
    """
    return _encode_passages_tuple(tuple(texts))


def encode_queries_cached(texts: list[str]) -> Any:
    """Encode query strings with a small LRU cache.

    Same-query lookups are common in multi-engine search (each engine
    triggers a separate SemanticRanker.score_results call with the
    same query).  Caching avoids re-encoding the same query repeatedly.
    """
    return _encode_queries_tuple(tuple(texts))


def warmup_embeddings() -> str:
    """Download (if needed), load, and run a probe encode to avoid first-search cold start.

    Returns:
        The model id that was warmed up.
    """
    model = embedding_model_name()
    logger.info("Warming up embedding model %s", model)
    encode_queries(["embedding warmup probe"])
    encode_passages(["embedding warmup passage"])
    logger.info("Embedding model warm (%s)", model)
    return model
