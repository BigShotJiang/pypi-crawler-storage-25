import argparse
import sys
import textwrap
import shutil

from clichatty.ui import UI
from clichatty.sms import SMS, SMSCreateError, SMSSendError, SMSDeleteError
from clichatty.db import DB


def main():
    if len(sys.argv) == 1:
        UI()
    else:
        ap = argparse.ArgumentParser(description='''
                Terminal interface to the phone's modem, integrating with the
                chatty database. Run without arguments for the curses
                interface''')
        ap.add_argument('-m', '--message')
        ap.add_argument('-a', '--alias')
        ap.add_argument('-t', '--tail', nargs='?', type=int, const=10)
        ap.add_argument('-2', '--tfa', nargs='?', type=int, const=1)
        args = ap.parse_args()

        if args.message and args.alias:
            with DB() as db:
                threads = db.get_threads()
            for thread_id, thread_alias, thread_name in threads:
                if args.alias == thread_alias:
                    try:
                        sms = SMS(thread_name, args.message)
                    except SMSCreateError as e:
                        print(e, file=sys.stderr)
                        return 1

                    try:
                        sms.send()
                        with DB() as db:
                            db.insert_message(thread_id, args.message)
                            msgs = db.get_thread(thread_id)
                    except (SMSSendError, SMSDeleteError) as e:
                        print(e, file=sys.stderr)
                        return 1
        elif args.alias and args.tail:
            termw = shutil.get_terminal_size().columns
            with DB() as db:
                threads = db.get_threads()
            for thread_id, thread_alias, thread_name in threads:
                if args.alias == thread_alias:
                    with DB() as db:
                        msgs = db.get_thread(
                            thread_id, last_n_messages=args.tail)
                    if msgs:
                        for m in msgs[::-1]:
                            datetime = m[2]
                            dtl = len(datetime)
                            wrapw = termw - dtl - 6
                            body = m[3].split('\n')
                            body_wrapped = []
                            for l in body:
                                body_wrapped += textwrap.wrap(l, width=wrapw)
                            for i, l in enumerate(body_wrapped):
                                if i == 0:
                                    print(datetime, '  ', l)
                                else:
                                    print(' ' * dtl, '  ', l)

        elif args.tfa:
            with DB() as db:
                matches = db.get_tfa(args.tfa)
            for m in matches:
                print(m)

if __name__ == "__main__":
    main()
