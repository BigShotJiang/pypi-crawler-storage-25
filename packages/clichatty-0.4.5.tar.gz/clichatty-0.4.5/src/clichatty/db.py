import pathlib
import sqlite3
import uuid
import shutil


class DB:
    def __init__(self):
        self.path = pathlib.Path.home() / '.purple/chatty/db/chatty-history.db'

        self.con = sqlite3.connect(self.path, timeout=30)
        self.cur = self.con.cursor()


    def __enter__(self):
        return self


    def __exit__(self, exc_type, exc_val, exc_tb):
        self.con.close()

        
    def get_last_msg_id(self, thread_id):
        self.cur.execute(
            '''select id from messages where thread_id = (?) 
               order by time desc limit 1''', (thread_id,))
        row = self.cur.fetchone()
        return int(row[0]) if row else 0


    def get_threads(self):
        self.cur.execute('''select
                  t.id,
                  coalesce(nullif(t.alias, ''), u.alias) as alias,
                  t.name
              from threads t
              left join users u on t.name = u.username
              left join (
                  select thread_id, max(time) as last_time
                  from messages
                  group by thread_id
            ) m on m.thread_id = t.id
            order by m.last_time desc''')
        return self.cur.fetchall()


    def insert_message(self, thread_id, msg):
        self.cur.execute('''insert into "messages" (
            uid, thread_id, sender_id, user_alias, body, body_type,
            direction, time, status, encrypted, preview_id, subject
            ) values (
              (?),
              (?),
              1, NULL, (?), 1, -1,
              strftime('%s', 'now'), 3, 0, NULL, NULL)''',
            (str(uuid.uuid4()), thread_id, msg)) 
        self.con.commit()


    def get_thread(self, thread_id, last_msg_id=0, last_n_messages=None):
        if last_n_messages and last_msg_id == 0:
            append = f'desc limit {last_n_messages}'
        else:
            append = 'asc'

        self.cur.execute(f''' 
        with last_messages as (
            select messages.sender_id as sid, messages.time, messages.body
            from messages
            join threads on messages.thread_id = threads.id
            where threads.id = (?) and messages.id > (?)
            order by messages.time desc
        )
        select sid, (select alias from users where id = sid), 
        datetime(time, 'unixepoch', 'localtime'), body
        from last_messages
        order by time {append}''', (thread_id, last_msg_id))

        # [(sender_id, sender_alias, datetime, message), ...]
        return self.cur.fetchall()

    
    def get_tfa(self, n):
        self.cur.execute("""
            select body from messages 
            where body like '%DUO:%' 
            order by id desc
            limit ?""", (n,))
        matches = [i[0][-7:] for i in self.cur.fetchall()]
        return matches
