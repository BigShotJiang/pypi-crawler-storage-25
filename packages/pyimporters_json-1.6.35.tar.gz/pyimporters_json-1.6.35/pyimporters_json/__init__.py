"""Sherpa JSON knowledge import plugin"""

__version__ = "1.6.35"
