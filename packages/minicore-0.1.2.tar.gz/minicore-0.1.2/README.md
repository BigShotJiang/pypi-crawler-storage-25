# minicore

`minicore`是定势能源数据组件`ncore`的简化版。

## 用法

### 配置

#### 环境变量

```
MINICORE_CONFIG_FILE=""  # 可选
```

#### config相关

配置类型目前可选用`file`，此时使用一个Python文件来提供配置参数。配置文件的查找顺序为：

* `$MINICORE_CONFIG_FILE` （如提供该环境变量）
* `./minicore_config.py`
* `$HOME/.minicore/minicore_config.py`

配置文件示例可见`examples/minicore_config.py`, 详解见下文。

### 核心枢纽：NCore单例对象

```python
from minicore import NCore

nc = NCore()
```

`minicore`系统的核心枢纽类型`NCore`是一个单例类型，也就是在一个程序中无论写多少次初始化过程`NCore()`，返回的都是同一个对象，实质的初始化过程也只在第一次过程中发生，不会造成额外开销。所以通过上面的方式, 可以在任何需要用到它的地方来现场生成该对象。

如果没有提供正确的配置文件，会抛出`MiniCoreBadConfig`异常。

### 获取数据类型（DataType）

```python
nc.ls_types()  # 打印出可用的数据类型 
SomeType = nc.get_type(TYPE_NAME) 
```

### 生成Data对象，并获取数据结果

```python
data = SomeType(**para)
result = data.result
```

### 快捷方式

```python
from minicore import D

data = D(type_name, **para)
result = data.result
```

## 配置文件详解

配置文件示例可见`examples/minicore_config.py`

### SOURCE 数据源

`SOURCE`配置项是一个列表，可以包含一或多个数据源。

```python
SOURCE = [
    {
        "name": "SourceName",  # 数据源名称
        "base_url": "http://some.com/ncore/",  # 数据服务基础url路径
        "auth": {
            "type": "token",
            "token": "SomeToken",
        },  # 身份认证参数
    }
]
```

其中，身份认证参数目前支持以下形式:

#### auth type="token"
```python
{
    "type": "token",
    "token": "SomeToken"
}
```

### TMP_DIR 临时文件目录

MiniCore临时文件目录的根路径
