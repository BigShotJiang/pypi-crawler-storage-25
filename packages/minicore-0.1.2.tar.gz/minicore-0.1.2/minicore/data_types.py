__all__ = [
    'DataLike',
    'Data', 'D',
    'DataPipe',
    'NullResult', 'NullDeps',
]

from collections import OrderedDict
from urllib.parse import urljoin, urlencode
from .exceptions import *


class NullResult:
    pass


class NullDeps:
    pass


class DataLike:
    # required attrs:
    # * type_name
    # * para
    # * schema
    # props:
    # * type
    # * obj
    # * result

    @staticmethod
    def _clean_para(para):
        cleaned = {}
        for key, value in para.items():
            if isinstance(value, DataLike):
                value = value.json()
            cleaned[key] = value
        return cleaned

    @property
    def type(self):
        return self.__class__

    @property
    def obj(self):
        return self

    def apply(self, **extra):
        """
        根据补全的extra参数生成数据对象
        :param extra: 补全的参数
        :return: 数据对象
        """
        return self.type(**self.para, **extra)

    @property
    def uri(self):
        """字符串形式的数据条目名"""
        return urljoin(self.type_name, '?' + urlencode(sorted(self.para.items())))

    @property
    def uri_md5(self):
        """数据条目名的md5值，用于临时文件名等场合"""
        from .utils import str2md5

        return str2md5(self.uri)

    def json(self):
        return {
            "type_name": self.type_name,
            **self.para
        }

    def __or__(self, other):
        """operation pipeline"""
        if isinstance(other, DataLike):
            return other.apply(input=self)
        elif isinstance(other, str):
            return D(other, input=self)
        else:
            raise NotImplementedError('Cannot pipeline data to {}'.format(other.__class__))


class Data(DataLike):
    """
    ncore体系各数据类型的基类。

    子类型继承时，应当覆盖下列属性和方法：

    属性:
        type_name: 类型名
        schema: 类型规格字典，其中特别重要的是结果的规格（schema的result字段）

    方法:
        generate(): 生成数据结果的具体逻辑。该方法的返回值即数据结果。
    """

    type_name = 'UnnamedDataType'
    type_desc = ''
    type_info = {}

    # schema以后如果升级为专用的class, 记得要使之可以序列化, 以支持远程.
    schema = {}

    _result = NullResult()
    _deps = NullDeps()

    def __init__(self, **para):
        """
        :param para: 本数据条目的参数
        """
        self.para = self._clean_para(para)

    def calc_deps(self):
        """
        计算本数据所依赖的数据条目
        :return: 依赖数据项, dict形式（未来可能升级为专用的Deps类）
        """
        return {}

    @property
    def deps(self):
        """
        依赖的数据条目，dict形式（见calc_deps()方法说明）
        """
        if isinstance(self._deps, NullDeps):
            self._deps = self.calc_deps()
        return self._deps

    def generate(self, **kwargs):
        """
        结果生成逻辑
        :param kwargs:
        :return: 数据结果，可为单个数据单元（如numpy数组，pandas DataFrame等），也可为dict形式的复合结果。
        """
        raise NotImplementedError

    @property
    def result(self):
        """数据结果"""
        if isinstance(self._result, NullResult):
            self._result = self.generate()
        return self._result

    def __repr__(self):
        return '<{}>'.format(self.uri)

    @classmethod
    def get_para_schema(cls):
        para_schema = cls.schema.get('para', {})
        if isinstance(para_schema, (list, tuple)):
            para_schema = OrderedDict([(para_key, {}) for para_key in para_schema])
        return para_schema

    @classmethod
    def get_result_schema(cls):
        result_schema = cls.schema.get('result', {})
        if isinstance(result_schema, str):
            result_schema = {"type": result_schema}
        return result_schema

    @classmethod
    def help(cls, display=True):
        texts = []
        if cls.type_desc:
            texts.append(cls.type_desc)

        para_schema = cls.get_para_schema()
        if para_schema:
            texts.append('Para:')

            for para_key, para_info in para_schema.items():
                texts.append(f'\t{para_key}:')
                para_type = para_info.get('type')
                if para_type:
                    texts.append(f'\t\ttype: {para_type}')
                para_desc = para_info.get('desc')
                if para_desc:
                    texts.append(f'\t\tdesc: {para_desc}')

        result_schema = cls.get_result_schema()
        if result_schema:
            texts.append('Result:')
            result_type = result_schema.get('type')
            if result_type:
                texts.append(f'\ttype: {result_type}')
            result_desc = result_schema.get('desc')
            if result_desc:
                texts.append(f'\tdesc: {result_desc}')

        if display:
            for text in texts:
                print(text)
        else:
            full_text = '\n'.join(texts)
            return full_text

    @classmethod
    def para_values(cls, key=None, **kwargs):
        if key is None:
            result = OrderedDict()
            for key in cls.schema.get('para', {}).keys():
                result[key] = cls.para_values(key, **kwargs)
            return result
        else:
            sub_func = getattr(cls, f'para_values_of_{key}', None)
            if callable(sub_func):
                return sub_func(**kwargs)
            else:
                return None


class D(DataLike):
    """通用的数据对象包装。
    其para可以是部分定义的，之后可通过.apply(**extra)方法生成完成的数据对象，或通过.get_result(**extra)方法直接获取结果。
    或者是作为取数据的快捷方式，其中有一个.obj属性，代表以自身参数构建的数据对象; 另有一个.result属性，即该数据对象的结果。
    """
    _obj = None
    _type = None

    def __init__(self, type_name, **para):
        """
        :param type_name: 数据类型名
        :param para: 先行提供的部分参数
        """
        self.type_name = type_name
        self.para = self._clean_para(para)

    @property
    def schema(self):
        return self.type.schema

    @property
    def type_desc(self):
        return self.type.type_desc

    @property
    def type_info(self):
        return self.type.type_info

    @property
    def type(self):
        """数据类型"""
        if self._type is None:
            from ._MINICORE import NCore
            nc = NCore()
            self._type = nc.get_type(self.type_name)
        return self._type

    def vary(self, delete_paras=None, **extra):
        """
        改变部分para以生成一个新的D对象
        :param delete_paras: list of para names to be deleted
        :param extra: 新的参数
        :return: 改变后的D对象
        """
        updated_para = {**self.para, **extra}
        if delete_paras:
            for p in delete_paras:
                updated_para.pop(p, None)
        return D(self.type_name, **updated_para)

    @property
    def obj(self):
        """以自身所有的para构建出的数据对象"""
        if self._obj is None:
            self._obj = self.apply()
        return self._obj

    @property
    def result(self):
        """以自身所有的para构建出的数据对象的结果"""
        return self.obj.result

    def get_result(self, **extra):
        """
        根据补全的extra参数直接获取数据结果
        :param extra: 补全的参数
        :return: 数据结果
        """
        return self.apply(**extra).result

    def __repr__(self):
        return 'D<{}> with para: {}'.format(self.type_name, self.para)

    @property
    def uri(self):
        """字符串形式的数据条目名"""
        return self.obj.uri

    def get_para_schema(self):
        return self.type.get_para_schema()

    def get_result_schema(self):
        return self.type.get_result_schema()

    def help(self, display=True):
        return self.type.help(display=display)

    def para_values(self, key=None, **kwargs):
        return self.type.para_values(key=key, **kwargs)


class DataPipe(Data):
    """DataType that acts as a pipe, which takes another DataLike object as input, and produces some output."""

    def calc_deps(self):
        return {
            'input': D(**self.para['input'])
        }
