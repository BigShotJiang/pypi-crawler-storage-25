__all__ = [
    'make_auth_obj',
    'NoAuth', 'TokenAuth'
]

from requests.auth import AuthBase


class NoAuth(AuthBase):
    def __call__(self, r):
        return r


class TokenAuth(AuthBase):
    def __init__(self, token):
        self.token = token

    def __call__(self, r):
        r.headers['Authorization'] = 'Token {}'.format(self.token)
        return r


def make_auth_obj(para):
    if not para:
        return NoAuth()

    type = para['type']
    if type == 'token':
        return TokenAuth(token=para['token'])
    else:
        raise NotImplementedError(f"NCore auth type {type} not implemented!")
