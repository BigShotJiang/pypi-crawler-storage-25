__all__ = ['parse_data_response']


from .definitions import ResultTypes
from .serializers import *


_SCHEMA_SERIALIZER_CLASSES = {
    ResultTypes.JSON: JsonSerializer,
    ResultTypes.Str: JsonSerializer,
    ResultTypes.Int: JsonSerializer,
    ResultTypes.Float: FloatSerializer,
    ResultTypes.Bool: JsonSerializer,
    ResultTypes.List: JsonSerializer,
    ResultTypes.NumpyArray: NumpyArraySerializer,
    ResultTypes.DataFrame: DataFrameSerializer,
}


def parse_data_response(response, schema):
    """
    :param response:
    :param schema:

    """
    # default result schema is 'JSON'
    if not schema:
        result_schema = 'JSON'
    else:
        result_schema = schema.get('result', 'JSON')

    serializer_class = _SCHEMA_SERIALIZER_CLASSES[result_schema]
    return serializer_class.from_response(response)
