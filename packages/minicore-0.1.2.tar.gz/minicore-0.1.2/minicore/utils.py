__all__ = ['str2md5']

import hashlib


def str2md5(s):
    """
    计算字符串的md5值
    :param s: 字符串
    :returns: md5值
    """
    hash_object = hashlib.md5(s.encode('utf-8'))
    return hash_object.hexdigest()
