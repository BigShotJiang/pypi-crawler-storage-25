__all__ = ['Source']

import importlib
from urllib.parse import urljoin
from collections import OrderedDict
import requests

from .exceptions import *
from .data_types import Data
from .auth import make_auth_obj
from .schema_utils import parse_data_response


class Source:
    _loaded = False

    def __init__(self, name, base_url, auth=None, **kwargs):
        self.name = name
        self.available = False
        self._types = OrderedDict()

        if not base_url.endswith('/'):
            base_url = base_url + '/'

        self.base_url = base_url
        self.auth = make_auth_obj(auth)

    def ls_types(self):
        print("{}::".format(self.name))
        for type_name, _ in self.iter_types():
            print(f"\t{type_name}")

    def iter_types(self):
        self.ensure_loaded()
        return self._types.items()

    def __contains__(self, item):
        return item in self._types

    def __getitem__(self, item):
        return self.get_type(item)

    def get_type(self, name):
        """获取数据类型"""
        self.ensure_loaded()
        return self._types[name]

    def ensure_loaded(self):
        if not self._loaded:
            self.load_types()

    def load_types(self):
        """加载远端的数据类型"""
        try:
            api_url = urljoin(self.base_url, 'data_type/')
            r = requests.get(api_url, auth=self.auth)
            r.raise_for_status()
            for item in r.json():
                if item['enabled']:
                    self._types[item['type_name']] = self.get_remote_type(info=item)
            self.available = True
        except Exception as e:
            print(e)
            self.available = False
        finally:
            self._loaded = True

    def retrieve_result(self, type_name, para):
        """从远端获取数据结果"""
        api_url = urljoin(self.base_url, f'data/{type_name}/')
        r = requests.post(api_url, json=para, auth=self.auth)
        self.raise_for_status(r)
        data_type = self.get_type(type_name)
        result = parse_data_response(r, schema=data_type.schema)
        return result

    def retrieve_para_values(self, type_name, key=None, **kwargs):
        try:
            api_url = urljoin(self.base_url, f'data_type/{type_name}/para_values/')
            r = requests.post(api_url, json={'key': key, **kwargs}, auth=self.auth)
            self.raise_for_status(r)
            if key is None:
                return {k: self.parse_para_values(v) for k, v in r.json().items()}
            else:
                return self.parse_para_values(r.json())
        except Exception as e:
            print(e)
            return None

    def parse_para_values(self, data):
        if not isinstance(data, dict):
            return None

        values_type = data.get('type')
        if values_type == 'list':
            return data['values']

        return None

    def get_remote_type(self, info):
        """根据远端给出的信息，生成本地对应的代理数据类型"""

        class RemoteDataType(Data):
            type_name = info['type_name']
            type_desc = info.get('type_desc', '')
            type_info = info.get('type_info', {})
            schema = info['schema']

            _source = self

            def generate(self, **kwargs):
                return self._source.retrieve_result(self.type_name, para=self.para)

            @classmethod
            def para_values(cls, key=None, **kwargs):
                return cls._source.retrieve_para_values(cls.type_name, key=key, **kwargs)

        return RemoteDataType

    def raise_for_status(self, response):
        if response.status_code >= 400:
            reason = response.json()
            raise FailedToGetDataResult(reason)

    def __repr__(self):
        return "<{} {}>".format(self.__class__.__name__, self.name)
