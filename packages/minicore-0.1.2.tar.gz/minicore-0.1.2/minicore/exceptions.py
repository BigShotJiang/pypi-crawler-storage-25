class MiniCoreBadConfig(Exception): pass
class FailedToGetDataResult(Exception): pass
