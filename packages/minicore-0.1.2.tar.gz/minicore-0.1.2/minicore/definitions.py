__all__ = [
    'ResultTypes',
]

class ResultTypes:
    """可用的结果类型的枚举"""
    JSON = 'JSON'
    Str = 'str'
    Int = 'int'
    Float = 'float'
    Bool = 'bool'
    List = 'list'
    NumpyArray = 'NumpyArray'
    DataFrame = 'DataFrame'
