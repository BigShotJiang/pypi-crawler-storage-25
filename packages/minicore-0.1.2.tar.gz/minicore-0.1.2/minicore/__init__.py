from ._MINICORE import NCore
from .data_types import Data, D

__version__ = '0.1.2'
