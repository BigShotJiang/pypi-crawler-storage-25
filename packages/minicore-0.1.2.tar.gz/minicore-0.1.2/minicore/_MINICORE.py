# This file won't be used directly as it is imported in __init__.py.
# Use "from minicore import NCore" instead.

__all__ = ['NCore']

import os
import concurrent.futures as f
from .config import MiniCoreConfig

from collections import OrderedDict
from .sources import Source


class NCore:
    _instance = None
    _inited = False
    _sources_loaded = False

    # Singleton
    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if self._inited:
            return

        self._load()
        self._inited = True

    def load_config(self) -> MiniCoreConfig:
        config = MiniCoreConfig.from_file()
        if not os.path.exists(config.TMP_DIR):
            os.makedirs(config.TMP_DIR, exist_ok=True)

        return config

    def reload(self):
        self._sources_loaded = False
        self._load()

    def _load(self):
        from .sources import Source

        self.config = self.load_config()
        self.sources = [Source(**item) for item in self.config.SOURCES]

    def ls_types(self):
        self._ensure_types_loaded()
        for source in self.sources:
            source.ls_types()

    def get_type(self, name):
        """
        获取指定的数据类型
        :param name: 类型名
        :returns: 数据类型，或抛出KeyError异常
        """
        self._ensure_types_loaded()
        namespace, _name = self._parse_namespaced_name(name)
        for source in self.sources:
            if (not source.available) or (namespace and source.name != namespace):
                continue

            try:
                return source.get_type(_name)
            except Exception as e:
                continue

        raise KeyError(f"Type name {name} not found in NCore.")

    def _ensure_types_loaded(self):
        if not self._sources_loaded:
            def _load_source(s):
                s.ensure_loaded()

            with f.ThreadPoolExecutor(max_workers=len(self.sources)) as executor:
                for source in self.sources:
                    executor.submit(_load_source, source)
            self._sources_loaded = True

    def _parse_namespaced_name(self, name):
        tokens = name.split('::')
        if len(tokens) == 1:
            return None, name
        elif len(tokens) == 2:
            return tokens[0], tokens[1]
        else:
            raise ValueError(f"Bad ncore type name: {name}")

    def help(self, item=None):
        if isinstance(item, str):
            try:
                data_type = self.get_type(item)
                data_type.help()
            except Exception as e:
                pass

    def __repr__(self):
        return "<NCore>"
