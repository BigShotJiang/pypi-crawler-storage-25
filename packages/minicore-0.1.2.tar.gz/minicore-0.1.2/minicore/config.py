__all__ = ['MiniCoreConfig']

import os
import sys
import importlib

from .exceptions import *

CONFIG_MODULE = 'minicore_config'
LOCAL_CONFIG_FILE = 'minicore_config.py'
USER_CONFIG_FILE = os.path.expanduser('~/.minicore/minicore_config.py')


class MiniCoreConfig:
    SOURCES = []
    TMP_DIR = '/tmp/minicore'

    @classmethod
    def from_file(cls):
        CONFIG_FILE = os.getenv('MINICORE_CONFIG_FILE', None)
        if CONFIG_FILE:
            if os.path.exists(CONFIG_FILE) and CONFIG_FILE.endswith('.py'):
                try:
                    sys.path.append(os.path.dirname(CONFIG_FILE))
                    mod_name = os.path.splitext(os.path.basename(CONFIG_FILE))[0]  # 获取无目录、无后缀的配置文件名
                    config_mod = importlib.import_module(mod_name)
                except ImportError:
                    raise MiniCoreBadConfig(CONFIG_FILE)
            else:
                raise MiniCoreBadConfig(CONFIG_FILE)
        else:
            if os.path.exists(LOCAL_CONFIG_FILE):
                try:
                    config_mod = importlib.import_module(CONFIG_MODULE)
                except ImportError:
                    raise MiniCoreBadConfig(LOCAL_CONFIG_FILE)
            elif os.path.exists(USER_CONFIG_FILE):
                try:
                    sys.path.append(os.path.dirname(USER_CONFIG_FILE))
                    config_mod = importlib.import_module(CONFIG_MODULE)
                except ImportError:
                    raise MiniCoreBadConfig(USER_CONFIG_FILE)
            else:
                raise MiniCoreBadConfig("No minicore config file provided!")

        config_obj = cls()
        for key in dir(config_mod):
            if key.isupper():
                setattr(config_obj, key, getattr(config_mod, key))
        return config_obj

