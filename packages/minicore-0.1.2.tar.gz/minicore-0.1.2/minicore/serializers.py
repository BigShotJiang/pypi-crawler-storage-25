__all__ = [
    'BaseSerializer', 'BaseDataFileSerializer',
    'NumpyArraySerializer', 'DataFrameSerializer',
    'JsonSerializer', 'FloatSerializer',
]

import os
import re
import json
import numpy as np
import pandas as pd


class BaseSerializer:
    def __init__(self, result):
        self.result = result

    @classmethod
    def load(cls, dumped):
        raise NotImplementedError

    @classmethod
    def from_response(cls, response):
        raise NotImplementedError


class BaseDataFileSerializer(BaseSerializer):
    @classmethod
    def from_response(cls, response):
        from ._MINICORE import NCore
        nc = NCore()

        fname = re.findall('filename=(.+)', response.headers['Content-Disposition'])[0]
        fname = fname.strip('"')

        tmp_full_fname = os.path.join(nc.config.TMP_DIR, fname)
        with open(tmp_full_fname, 'wb') as file:
            file.write(response.content)

        result = cls.load(tmp_full_fname)
        os.remove(tmp_full_fname)
        return result


class NumpyArraySerializer(BaseDataFileSerializer):
    file_type = 'binary'

    @classmethod
    def load(cls, path):
        return np.load(path)


class DataFrameSerializer(BaseDataFileSerializer):
    @classmethod
    def load(cls, path):
        return pd.read_parquet(path, engine='fastparquet')


class JsonSerializer(BaseSerializer):
    @classmethod
    def load(cls, dumped):
        return json.loads(dumped)

    @classmethod
    def from_response(cls, response):
        return response.json()


class FloatSerializer(JsonSerializer):
    SPECIAL_NUMS = {
        'NAN': np.nan,
        'INF': np.inf,
        '-INF': -np.inf,
    }

    @classmethod
    def load(cls, dumped):
        data = json.loads(dumped)
        if isinstance(data, str):
            data = data.upper()
            return cls.SPECIAL_NUMS[data]
        else:
            return data

    @classmethod
    def from_response(cls, response):
        return cls.load(response.content)
