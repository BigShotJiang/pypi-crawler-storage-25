# AnyFS

AnyFS is an agent-native persistence, publishing, fork, and collaboration layer.

This repository is a monorepo containing:

- `apps/cli`: Typer-based CLI
- `apps/api`: FastAPI service
- `apps/web`: Next.js browsing UI
- `apps/storage-gateway`: Blob storage gateway
- `packages/*`: shared Python and TypeScript packages

## Quick start

1. Install Python 3.10+, Node 22+, and `pnpm`.
2. Install Python dependencies per app/package with `uv sync`.
3. Install JavaScript dependencies with `pnpm install`.
4. Run the CLI with `uv run --project apps/cli anyfs --help`.
5. Run the API with `uv run --project apps/api uvicorn anyfs_api.main:app --reload`.
6. Run the storage gateway with `pnpm --filter @anyfs/storage-gateway dev`.
7. Run the web app with `pnpm --filter @anyfs/web dev`.
