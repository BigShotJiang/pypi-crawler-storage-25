from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Annotated, Any, Literal, Union

from pydantic import Field

from .models import AnyFSModel, utc_now


class TranscriptEventKind(str, Enum):
    USER_MESSAGE = "user_message"
    ASSISTANT_TEXT = "assistant_text"
    THINKING = "thinking"
    FILE_READ = "file_read"
    FILE_EDIT = "file_edit"
    FILE_WRITE = "file_write"
    SHELL_COMMAND = "shell_command"
    CODE_SEARCH = "code_search"
    ERROR = "error"
    FILE_SNAPSHOT = "file_snapshot"


# ── Session metadata ─────────────────────────────────────────────

class TranscriptSessionMeta(AnyFSModel):
    model_config = {"extra": "allow"}

    id: str
    agent: str
    model: str | None = None
    cwd: str | None = None
    git_branch: str | None = None
    started_at: datetime = Field(default_factory=utc_now)
    ended_at: datetime | None = None
    version: str | None = None


# ── Event types ──────────────────────────────────────────────────

class UserMessageEvent(AnyFSModel):
    model_config = {"extra": "allow"}

    kind: Literal["user_message"] = "user_message"
    ts: datetime
    text: str
    meta: dict[str, Any] = Field(default_factory=dict)


class AssistantTextEvent(AnyFSModel):
    model_config = {"extra": "allow"}

    kind: Literal["assistant_text"] = "assistant_text"
    ts: datetime
    text: str
    meta: dict[str, Any] = Field(default_factory=dict)


class ThinkingEvent(AnyFSModel):
    model_config = {"extra": "allow"}

    kind: Literal["thinking"] = "thinking"
    ts: datetime
    text: str = ""
    meta: dict[str, Any] = Field(default_factory=dict)


class FileReadEvent(AnyFSModel):
    model_config = {"extra": "allow"}

    kind: Literal["file_read"] = "file_read"
    ts: datetime
    path: str
    lines: str | None = None
    content_preview: str | None = None
    meta: dict[str, Any] = Field(default_factory=dict)


class FileEditEvent(AnyFSModel):
    model_config = {"extra": "allow"}

    kind: Literal["file_edit"] = "file_edit"
    ts: datetime
    path: str
    diff: str | None = None
    meta: dict[str, Any] = Field(default_factory=dict)


class FileWriteEvent(AnyFSModel):
    model_config = {"extra": "allow"}

    kind: Literal["file_write"] = "file_write"
    ts: datetime
    path: str
    content_preview: str | None = None
    meta: dict[str, Any] = Field(default_factory=dict)


class ShellCommandEvent(AnyFSModel):
    model_config = {"extra": "allow"}

    kind: Literal["shell_command"] = "shell_command"
    ts: datetime
    command: str
    exit_code: int | None = None
    output_preview: str | None = None
    meta: dict[str, Any] = Field(default_factory=dict)


class CodeSearchEvent(AnyFSModel):
    model_config = {"extra": "allow"}

    kind: Literal["code_search"] = "code_search"
    ts: datetime
    tool_name: str
    query: str
    result_count: int | None = None
    result_preview: str | None = None
    meta: dict[str, Any] = Field(default_factory=dict)


class ErrorEvent(AnyFSModel):
    model_config = {"extra": "allow"}

    kind: Literal["error"] = "error"
    ts: datetime
    message: str
    code: str | None = None
    meta: dict[str, Any] = Field(default_factory=dict)


class FileSnapshotEvent(AnyFSModel):
    model_config = {"extra": "allow"}

    kind: Literal["file_snapshot"] = "file_snapshot"
    ts: datetime
    paths: list[str] = Field(default_factory=list)
    meta: dict[str, Any] = Field(default_factory=dict)


# ── Discriminated union ──────────────────────────────────────────

CanonicalEvent = Annotated[
    Union[
        UserMessageEvent,
        AssistantTextEvent,
        ThinkingEvent,
        FileReadEvent,
        FileEditEvent,
        FileWriteEvent,
        ShellCommandEvent,
        CodeSearchEvent,
        ErrorEvent,
        FileSnapshotEvent,
    ],
    Field(discriminator="kind"),
]


# ── Top-level container ──────────────────────────────────────────

class CanonicalTranscript(AnyFSModel):
    model_config = {"extra": "allow"}

    schema_version: str = "1"
    session: TranscriptSessionMeta
    events: list[CanonicalEvent] = Field(default_factory=list)
    subagents: list[CanonicalTranscript] = Field(default_factory=list)
