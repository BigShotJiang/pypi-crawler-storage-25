from __future__ import annotations

from anyfs_schemas import LineageRecord


def make_lineage_record(parent_package_id: str, child_package_id: str) -> LineageRecord:
    return LineageRecord(parent_package_id=parent_package_id, child_package_id=child_package_id)

