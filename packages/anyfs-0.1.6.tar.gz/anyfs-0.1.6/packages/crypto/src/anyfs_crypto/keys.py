from __future__ import annotations

import base64
import hashlib
import json
import os
import time
import uuid
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.serialization import Encoding, NoEncryption, PrivateFormat, PublicFormat

from anyfs_schemas import utc_now_iso


# ── Base58 (for did:key encoding) ──────────────────────────────

_B58_ALPHABET = b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"


def _b58encode(data: bytes) -> str:
    n = int.from_bytes(data, "big")
    result = bytearray()
    while n > 0:
        n, r = divmod(n, 58)
        result.append(_B58_ALPHABET[r])
    for byte in data:
        if byte == 0:
            result.append(_B58_ALPHABET[0])
        else:
            break
    return bytes(reversed(result)).decode("ascii")


def _b58decode(s: str) -> bytes:
    n = 0
    for char in s.encode("ascii"):
        n = n * 58 + _B58_ALPHABET.index(char)
    pad = len(s) - len(s.lstrip("1"))
    result = n.to_bytes((n.bit_length() + 7) // 8, "big") if n else b""
    return b"\x00" * pad + result


# ── Ed25519 Agent Identity ─────────────────────────────────────

_ED25519_MULTICODEC_PREFIX = bytes([0xED, 0x01])


def generate_agent_keypair() -> dict[str, str]:
    """Generate an Ed25519 key pair. Returns {did, public_key, private_key} as base64 strings."""
    private = Ed25519PrivateKey.generate()
    pub_raw = private.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
    priv_raw = private.private_bytes(Encoding.Raw, PrivateFormat.Raw, NoEncryption())
    did = _public_key_bytes_to_did(pub_raw)
    return {
        "did": did,
        "public_key": _b64(pub_raw),
        "private_key": _b64(priv_raw),
    }


def _public_key_bytes_to_did(pub_raw: bytes) -> str:
    multicodec = _ED25519_MULTICODEC_PREFIX + pub_raw
    return f"did:key:z{_b58encode(multicodec)}"


def did_to_public_key_bytes(did: str) -> bytes:
    """Extract raw 32-byte Ed25519 public key from a did:key string."""
    if not did.startswith("did:key:z"):
        raise ValueError(f"invalid did:key format: {did}")
    decoded = _b58decode(did[len("did:key:z"):])
    if decoded[:2] != _ED25519_MULTICODEC_PREFIX:
        raise ValueError("not an Ed25519 did:key")
    return decoded[2:]


def sign_challenge(private_key_b64: str, challenge: str) -> str:
    """Sign a challenge string with an Ed25519 private key. Returns base64 signature."""
    priv_raw = _unb64(private_key_b64)
    private = Ed25519PrivateKey.from_private_bytes(priv_raw)
    sig = private.sign(challenge.encode("utf-8"))
    return _b64(sig)


def verify_challenge(did: str, challenge: str, signature_b64: str) -> bool:
    """Verify an Ed25519 signature against a did:key. Returns True if valid."""
    try:
        pub_raw = did_to_public_key_bytes(did)
        public = Ed25519PublicKey.from_public_bytes(pub_raw)
        public.verify(_unb64(signature_b64), challenge.encode("utf-8"))
        return True
    except Exception:
        return False


def create_auth_header(did: str, private_key_b64: str) -> str:
    """Create a Signature auth header: 'Signature <did>|<timestamp>|<signature>'."""
    ts = str(int(time.time()))
    challenge = f"{ts}:{did}"
    sig = sign_challenge(private_key_b64, challenge)
    return f"Signature {did}|{ts}|{sig}"


def verify_auth_header(header: str, max_age_seconds: int = 300) -> str | None:
    """Verify a Signature auth header. Returns the DID if valid, None otherwise."""
    if not header.startswith("Signature "):
        return None
    parts = header[len("Signature "):].split("|", 2)
    if len(parts) != 3:
        return None
    did, ts, sig = parts[0], parts[1], parts[2]
    # Check timestamp freshness
    try:
        age = abs(int(time.time()) - int(ts))
        if age > max_age_seconds:
            return None
    except ValueError:
        return None
    challenge = f"{ts}:{did}"
    if verify_challenge(did, challenge, sig):
        return did
    return None


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode("utf-8")


def _unb64(data: str) -> bytes:
    return base64.b64decode(data.encode("utf-8"))


def _derive_wrap_key(user_id: str, device_id: str) -> bytes:
    return hashlib.sha256(f"{user_id}:{device_id}".encode("utf-8")).digest()


def _encrypt_with_key(key: bytes, plaintext: bytes, aad: bytes | None = None) -> dict[str, str]:
    aes = AESGCM(key)
    nonce = os.urandom(12)
    ciphertext = aes.encrypt(nonce, plaintext, aad)
    return {"nonce": _b64(nonce), "ciphertext": _b64(ciphertext)}


def _decrypt_with_key(key: bytes, nonce: str, ciphertext: str, aad: bytes | None = None) -> bytes:
    aes = AESGCM(key)
    return aes.decrypt(_unb64(nonce), _unb64(ciphertext), aad)


def create_root_key_bundle(user_id: str, device_id: str) -> dict[str, Any]:
    root_key = os.urandom(32)
    wrap_key = _derive_wrap_key(user_id, device_id)
    wrapped = _encrypt_with_key(wrap_key, root_key, user_id.encode("utf-8"))
    return {
        "alg": "AES256-GCM",
        "created_at": utc_now_iso(),
        "wrapped_for": {"user_id": user_id, "device_id": device_id},
        **wrapped,
    }


def unwrap_root_key(bundle: dict[str, Any], user_id: str, device_id: str) -> bytes:
    wrap_key = _derive_wrap_key(user_id, device_id)
    return _decrypt_with_key(wrap_key, bundle["nonce"], bundle["ciphertext"], user_id.encode("utf-8"))


def ensure_root_key(global_root: Path, identity: dict[str, Any]) -> Path:
    root_key_path = global_root / "keys" / "rootkey.enc"
    if not root_key_path.exists():
        root_key_path.write_text(
            json.dumps(create_root_key_bundle(identity["user_id"], identity["device_id"]), indent=2),
            encoding="utf-8",
        )
    return root_key_path


def load_root_key(global_root: Path, identity: dict[str, Any]) -> bytes:
    bundle = json.loads((global_root / "keys" / "rootkey.enc").read_text(encoding="utf-8"))
    return unwrap_root_key(bundle, identity["user_id"], identity["device_id"])


def encrypt_json_payload(root_key: bytes, payload: Any, namespace: str) -> dict[str, Any]:
    dek = os.urandom(32)
    wrapped_dek = _encrypt_with_key(root_key, dek, namespace.encode("utf-8"))
    encrypted_payload = _encrypt_with_key(dek, json.dumps(payload, indent=2, default=str).encode("utf-8"))
    return {
        "envelope_id": f"env_{uuid.uuid4().hex[:12]}",
        "alg": "AES256-GCM",
        "namespace": namespace,
        "wrapped_dek": wrapped_dek,
        "payload": encrypted_payload,
    }


def decrypt_json_payload(root_key: bytes, envelope: dict[str, Any]) -> Any:
    wrapped_dek = envelope["wrapped_dek"]
    dek = _decrypt_with_key(root_key, wrapped_dek["nonce"], wrapped_dek["ciphertext"], envelope["namespace"].encode("utf-8"))
    payload = envelope["payload"]
    plaintext = _decrypt_with_key(dek, payload["nonce"], payload["ciphertext"])
    return json.loads(plaintext.decode("utf-8"))


def rewrap_dek_for_share(root_key: bytes, envelope: dict[str, Any], share_password: str) -> dict[str, Any]:
    """Re-wrap a single envelope's DEK with a share password instead of root key.

    The recipient can decrypt this file using only the share password,
    without needing the original root key. Other files remain protected.
    """
    # Unwrap DEK using original root key
    wrapped_dek = envelope["wrapped_dek"]
    dek = _decrypt_with_key(
        root_key, wrapped_dek["nonce"], wrapped_dek["ciphertext"],
        envelope["namespace"].encode("utf-8"),
    )
    # Derive a share key from password + namespace (so each share is unique)
    share_key = hashlib.sha256(
        f"{share_password}:{envelope['namespace']}".encode("utf-8")
    ).digest()
    # Re-wrap DEK with share key
    share_wrapped_dek = _encrypt_with_key(
        share_key, dek, envelope["namespace"].encode("utf-8"),
    )
    return {
        "envelope_id": envelope["envelope_id"],
        "alg": "AES256-GCM",
        "namespace": envelope["namespace"],
        "wrapped_dek": share_wrapped_dek,
        "payload": envelope["payload"],
        "share_mode": "password",
    }


def decrypt_shared_payload(share_password: str, envelope: dict[str, Any]) -> Any:
    """Decrypt a file that was shared with a password. No root key needed."""
    share_key = hashlib.sha256(
        f"{share_password}:{envelope['namespace']}".encode("utf-8")
    ).digest()
    wrapped_dek = envelope["wrapped_dek"]
    dek = _decrypt_with_key(
        share_key, wrapped_dek["nonce"], wrapped_dek["ciphertext"],
        envelope["namespace"].encode("utf-8"),
    )
    payload = envelope["payload"]
    plaintext = _decrypt_with_key(dek, payload["nonce"], payload["ciphertext"])
    return json.loads(plaintext.decode("utf-8"))


def export_recovery_bundle(global_root: Path, identity: dict[str, Any], output_path: Path | None = None) -> Path:
    output_path = output_path or global_root / "keys" / "recovery.anyfs"
    payload = {
        "bundle_version": "v1",
        "identity": identity,
        "rootkey_bundle": json.loads((global_root / "keys" / "rootkey.enc").read_text(encoding="utf-8")),
        "created_at": utc_now_iso(),
    }
    output_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return output_path


def import_recovery_bundle(global_root: Path, recovery_path: Path) -> dict[str, Any]:
    payload = json.loads(recovery_path.read_text(encoding="utf-8"))
    (global_root / "keys").mkdir(parents=True, exist_ok=True)
    (global_root / "keys" / "rootkey.enc").write_text(
        json.dumps(payload["rootkey_bundle"], indent=2),
        encoding="utf-8",
    )
    (global_root / "keys" / "recovery.anyfs").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return payload

