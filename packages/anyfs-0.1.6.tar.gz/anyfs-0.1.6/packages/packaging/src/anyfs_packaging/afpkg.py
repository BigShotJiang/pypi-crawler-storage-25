from __future__ import annotations

import json
import zipfile
from pathlib import Path
from typing import Any


def build_afpkg(
    output_path: Path,
    manifest: dict[str, Any],
    public_entries: dict[str, bytes],
    private_entries: dict[str, dict[str, Any]],
    lineage: dict[str, Any],
    policy: dict[str, Any],
) -> Path:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("afpkg/manifest.json", json.dumps(manifest, indent=2, default=str))
        archive.writestr("afpkg/lineage.json", json.dumps(lineage, indent=2, default=str))
        archive.writestr("afpkg/policy.json", json.dumps(policy, indent=2, default=str))
        for rel_path, payload in public_entries.items():
            archive.writestr(f"afpkg/public/{rel_path}", payload)
        for rel_path, envelope in private_entries.items():
            archive.writestr(
                f"afpkg/private/{rel_path}",
                json.dumps(envelope, indent=2, default=str),
            )
    return output_path


def extract_afpkg(archive_path: Path, output_dir: Path) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive_path, "r") as archive:
        archive.extractall(output_dir)
    return output_dir
