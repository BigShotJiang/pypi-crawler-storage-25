from __future__ import annotations

import json
from pathlib import Path

from anyfs_schemas import CanonicalTranscript

from .registry import detect_parser, get_parser, register_parser
from .renderers.chat import render_chat
from .renderers.markdown import render_markdown


def parse_transcript(path: str | Path, agent_type: str | None = None) -> CanonicalTranscript:
    """Parse a transcript file into canonical format.

    If agent_type is given, uses the corresponding parser.
    Otherwise, auto-detects based on file format.
    """
    transcripts = load_transcripts(path, agent_type=agent_type)
    if len(transcripts) != 1:
        raise ValueError(
            f"expected exactly one transcript in {Path(path)}, found {len(transcripts)}. "
            "Use load_transcripts() for multi-session process bundles."
        )
    return transcripts[0]


def load_transcripts(path: str | Path, agent_type: str | None = None) -> list[CanonicalTranscript]:
    """Load one or more transcripts from raw client files or canonical JSON bundles."""
    path = Path(path)
    canonical = _load_canonical_transcripts(path)
    if canonical:
        return canonical

    if agent_type:
        parser = get_parser(agent_type)
        if parser is None:
            raise ValueError(f"no parser registered for agent type: {agent_type}")
    else:
        parser = detect_parser(path)
        if parser is None:
            raise ValueError(f"could not detect transcript format for: {path}")

    return [parser.parse(path)]


def export_transcript(
    transcript: CanonicalTranscript,
    target_agent: str,
    workspace: str,
) -> dict[str, str]:
    """Export a canonical transcript as a native session file for the target client.

    The generated file can be loaded by the target client as a real previous session,
    enabling true session resume with full tool call history.

    Supported targets: claude-code, codex-cli, gemini-cli, hermes, nanobot, openclaw, opencode
    Returns dict with paths of files written.
    """
    if target_agent == "claude-code":
        from .exporters.claude_code import export_claude_code
        return export_claude_code(transcript, workspace)
    elif target_agent == "codex-cli":
        from .exporters.codex_cli import export_codex_cli
        return export_codex_cli(transcript, workspace)
    elif target_agent == "gemini-cli":
        from .exporters.gemini_cli import export_gemini_cli
        return export_gemini_cli(transcript, workspace)
    elif target_agent == "hermes":
        from .exporters.hermes import export_hermes
        return export_hermes(transcript, workspace)
    elif target_agent == "nanobot":
        from .exporters.nanobot import export_nanobot
        return export_nanobot(transcript, workspace)
    elif target_agent == "openclaw":
        from .exporters.openclaw import export_openclaw
        return export_openclaw(transcript, workspace)
    elif target_agent == "opencode":
        from .exporters.opencode import export_opencode
        return export_opencode(transcript, workspace)
    else:
        raise ValueError(
            f"native export not yet supported for: {target_agent}. "
            "Supported: claude-code, codex-cli, gemini-cli, hermes, nanobot, openclaw, opencode"
        )


def inject_transcript(
    transcript: CanonicalTranscript,
    target_agent: str,
    workspace: str,
) -> dict[str, str]:
    """Inject a canonical transcript into a target client's context system.

    This enables resuming a session from one agent in another agent.
    For example: parse a Claude Code transcript → inject into Codex → resume in Codex.

    Supported targets: claude-code, codex-cli, gemini-cli, cursor
    Returns dict of files written.
    """
    if target_agent == "claude-code":
        from .injectors.claude_code import inject_claude_code
        return inject_claude_code(transcript, workspace)
    elif target_agent == "codex-cli":
        from .injectors.codex_cli import inject_codex_cli
        return inject_codex_cli(transcript, workspace)
    elif target_agent == "gemini-cli":
        from .injectors.gemini_cli import inject_gemini_cli
        return inject_gemini_cli(transcript, workspace)
    elif target_agent == "cursor":
        from .injectors.cursor import inject_cursor
        return inject_cursor(transcript, workspace)
    else:
        raise ValueError(
            f"unsupported target agent: {target_agent}. "
            "Supported: claude-code, codex-cli, gemini-cli, cursor"
        )


__all__ = [
    "parse_transcript",
    "load_transcripts",
    "render_markdown",
    "render_chat",
    "export_transcript",
    "inject_transcript",
    "register_parser",
    "get_parser",
    "detect_parser",
]


def _load_canonical_transcripts(path: Path) -> list[CanonicalTranscript]:
    if not path.is_file() or path.suffix != ".json":
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return []

    if isinstance(data, dict) and _looks_like_canonical_transcript(data):
        return [CanonicalTranscript.model_validate(data)]

    if not isinstance(data, list):
        return []

    transcripts: list[CanonicalTranscript] = []
    for item in data:
        if not isinstance(item, dict):
            continue
        if _looks_like_canonical_transcript(item):
            transcripts.append(CanonicalTranscript.model_validate(item))
            continue
        nested = item.get("canonical_transcript")
        if isinstance(nested, dict) and _looks_like_canonical_transcript(nested):
            transcripts.append(CanonicalTranscript.model_validate(nested))

    return transcripts


def _looks_like_canonical_transcript(payload: dict[str, object]) -> bool:
    session = payload.get("session")
    events = payload.get("events")
    return (
        isinstance(session, dict)
        and "id" in session
        and "agent" in session
        and isinstance(events, list)
    )
