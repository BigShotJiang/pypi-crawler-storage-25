"""Export a CanonicalTranscript to OpenClaw's native session store + transcript."""
from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from anyfs_schemas import (
    AssistantTextEvent,
    CanonicalTranscript,
    CodeSearchEvent,
    ErrorEvent,
    FileEditEvent,
    FileReadEvent,
    FileWriteEvent,
    ShellCommandEvent,
    ThinkingEvent,
    UserMessageEvent,
)

_DEFAULT_OPENCLAW_HOME = ".openclaw"


def export_openclaw(
    transcript: CanonicalTranscript,
    workspace: str,
) -> dict[str, str]:
    """Export a canonical transcript as an OpenClaw native session."""
    workspace_path = Path(workspace).resolve()
    root = Path(os.environ.get("OPENCLAW_HOME", Path.home() / _DEFAULT_OPENCLAW_HOME)).expanduser()
    agent_id, agent_root = _resolve_agent_root(root)

    sessions_dir = agent_root / "sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)
    store_path = sessions_dir / "sessions.json"

    session_id = str(uuid.uuid4())
    session_key = f"agent:{agent_id}:resume:{session_id}"
    now_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
    started_at = transcript.session.started_at or datetime.now(timezone.utc)

    session_file = sessions_dir / f"{session_id}.jsonl"
    lines = [
        json.dumps(
            {
                "type": "session",
                "version": 3,
                "id": session_id,
                "timestamp": started_at.isoformat(),
                "cwd": str(workspace_path),
            },
            default=str,
        )
    ]
    lines.extend(_build_transcript_entries(transcript))
    session_file.write_text("\n".join(lines) + "\n", encoding="utf-8")

    store = _load_json(store_path)
    store[session_key] = {
        "sessionId": session_id,
        "updatedAt": now_ms,
        "sessionFile": str(session_file),
        "displayName": f"resumed-from-{transcript.session.agent}",
        "label": f"resumed-from-{transcript.session.agent}",
        "chatType": "direct",
        "model": transcript.session.model,
        "modelProvider": _infer_model_provider(transcript.session.model),
        "lastChannel": "openclaw",
        "lastTo": session_key,
        "deliveryContext": {
            "channel": "openclaw",
            "to": session_key,
        },
    }
    store_path.write_text(json.dumps(store, indent=2), encoding="utf-8")

    return {
        "session_store": str(store_path),
        "transcript": str(session_file),
        "session_id": session_id,
        "session_key": session_key,
        "agent_id": agent_id,
        "resume_hint": f'openclaw agent --session-id {session_id} --message "<your prompt>"',
    }


def _build_transcript_entries(transcript: CanonicalTranscript) -> list[str]:
    lines: list[str] = []
    parent_id: str | None = None
    assistant_lines: list[str] = []
    assistant_ts: str | None = None

    def flush_assistant() -> None:
        nonlocal parent_id, assistant_lines, assistant_ts
        if not assistant_lines:
            return
        message_id = str(uuid.uuid4())
        lines.append(
            json.dumps(
                {
                    "type": "message",
                    "id": message_id,
                    "parentId": parent_id,
                    "timestamp": assistant_ts,
                    "message": {
                        "role": "assistant",
                        "content": [{"type": "text", "text": "\n\n".join(assistant_lines)}],
                        "api": "openai-responses",
                        "provider": "openclaw",
                        "model": "anyfs-resume",
                        "usage": {
                            "input": 0,
                            "output": 0,
                            "cacheRead": 0,
                            "cacheWrite": 0,
                            "totalTokens": 0,
                            "cost": {"input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0, "total": 0},
                        },
                        "stopReason": "stop",
                        "timestamp": _ts_ms(assistant_ts),
                    },
                },
                default=str,
            )
        )
        parent_id = message_id
        assistant_lines = []
        assistant_ts = None

    for event in transcript.events:
        ts = (getattr(event, "ts", None) or transcript.session.started_at or datetime.now(timezone.utc)).isoformat()

        if isinstance(event, UserMessageEvent):
            flush_assistant()
            message_id = str(uuid.uuid4())
            lines.append(
                json.dumps(
                    {
                        "type": "message",
                        "id": message_id,
                        "parentId": parent_id,
                        "timestamp": ts,
                        "message": {
                            "role": "user",
                            "content": [{"type": "text", "text": event.text}],
                            "timestamp": _ts_ms(ts),
                        },
                    },
                    default=str,
                )
            )
            parent_id = message_id
            continue

        if assistant_ts is None:
            assistant_ts = ts

        if isinstance(event, AssistantTextEvent):
            if event.text:
                assistant_lines.append(event.text)
        elif isinstance(event, ThinkingEvent):
            if event.text:
                assistant_lines.append(f"[Thinking]\n{event.text}")
        elif isinstance(event, ShellCommandEvent):
            block = [f"[Tool: shell] {event.command}"]
            if event.output_preview:
                block.append(event.output_preview)
            assistant_lines.append("\n".join(block))
        elif isinstance(event, FileReadEvent):
            block = [f"[Tool: read_file] {event.path}"]
            if event.content_preview:
                block.append(event.content_preview)
            assistant_lines.append("\n".join(block))
        elif isinstance(event, FileEditEvent):
            block = [f"[Tool: edit_file] {event.path}"]
            if event.diff:
                block.append(event.diff)
            assistant_lines.append("\n".join(block))
        elif isinstance(event, FileWriteEvent):
            block = [f"[Tool: write_file] {event.path}"]
            if event.content_preview:
                block.append(event.content_preview)
            assistant_lines.append("\n".join(block))
        elif isinstance(event, CodeSearchEvent):
            block = [f"[Tool: search] {event.query}"]
            if event.result_preview:
                block.append(event.result_preview)
            assistant_lines.append("\n".join(block))
        elif isinstance(event, ErrorEvent):
            assistant_lines.append(f"[Error] {event.message}")
        else:
            assistant_lines.append(f"[{event.kind}]")

    flush_assistant()
    return lines


def _load_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def _resolve_agent_root(root: Path) -> tuple[str, Path]:
    agents_dir = root / "agents"
    configured = os.environ.get("ANYFS_OPENCLAW_AGENT_ID")
    if configured:
        agents_dir.mkdir(parents=True, exist_ok=True)
        candidate = agents_dir / configured
        candidate.mkdir(parents=True, exist_ok=True)
        return configured, candidate

    if not agents_dir.exists():
        default_agent = agents_dir / "main"
        default_agent.mkdir(parents=True, exist_ok=True)
        return "main", default_agent

    candidates = sorted(
        path for path in agents_dir.iterdir() if path.is_dir()
    )
    if not candidates:
        default_agent = agents_dir / "main"
        default_agent.mkdir(parents=True, exist_ok=True)
        return "main", default_agent
    if len(candidates) > 1:
        raise ValueError(
            "Multiple OpenClaw agents found. Set ANYFS_OPENCLAW_AGENT_ID to choose one explicitly."
        )
    return candidates[0].name, candidates[0]


def _ts_ms(value: str | None) -> int:
    if not value:
        return int(datetime.now(timezone.utc).timestamp() * 1000)
    return int(datetime.fromisoformat(value).timestamp() * 1000)


def _infer_model_provider(model: str | None) -> str | None:
    if not model:
        return None
    text = model.lower()
    if "gpt" in text or "o1" in text or "o3" in text:
        return "openai"
    if "claude" in text:
        return "anthropic"
    if "gemini" in text:
        return "google"
    return None
