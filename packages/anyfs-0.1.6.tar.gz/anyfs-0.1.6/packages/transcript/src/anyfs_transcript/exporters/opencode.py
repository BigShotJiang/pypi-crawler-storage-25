"""Export a CanonicalTranscript to OpenCode's native importable session JSON."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from anyfs_schemas import (
    AssistantTextEvent,
    CanonicalTranscript,
    CodeSearchEvent,
    ErrorEvent,
    FileEditEvent,
    FileReadEvent,
    FileSnapshotEvent,
    FileWriteEvent,
    ShellCommandEvent,
    ThinkingEvent,
    UserMessageEvent,
)

_DEFAULT_AGENT_NAME = "build"
_DEFAULT_EXPORT_ROOT = ".anyfs/exports/opencode"


@dataclass
class _PendingPart:
    kind: str
    payload: dict[str, Any]


@dataclass
class _AssistantAccumulator:
    created_ms: int
    parts: list[_PendingPart] = field(default_factory=list)

    def has_content(self) -> bool:
        return bool(self.parts)


def export_opencode(
    transcript: CanonicalTranscript,
    workspace: str,
) -> dict[str, str]:
    """Export a canonical transcript as an OpenCode native session.

    OpenCode's official native import surface is `opencode import <file>`, so this
    exporter writes the official session export JSON shape and then imports it
    into the local OpenCode session store.
    """
    workspace_path = Path(workspace).resolve()
    started_at = transcript.session.started_at or _latest_event_ts(transcript) or datetime.now(timezone.utc)
    session_id = _make_id("ses", _ts_ms(started_at))

    export_dir = Path.home() / _DEFAULT_EXPORT_ROOT
    export_dir.mkdir(parents=True, exist_ok=True)
    export_path = export_dir / f"{session_id}.json"

    target_provider_id, target_model_id = _resolve_target_model(workspace_path, transcript.session.model)
    export_payload = _build_export_payload(
        transcript,
        workspace_path,
        session_id,
        started_at,
        provider_id=target_provider_id,
        model_id=target_model_id,
    )
    export_path.write_text(json.dumps(export_payload, indent=2), encoding="utf-8")

    import_result = _import_into_opencode(export_path, workspace_path)

    if import_result["imported"]:
        resume_hint = f"opencode --session {session_id}"
    else:
        resume_hint = f"opencode import {export_path} && opencode --session {session_id}"

    return {
        "session_export": str(export_path),
        "session_id": session_id,
        "import_hint": f"opencode import {export_path}",
        "resume_hint": resume_hint,
        "imported": import_result["imported"],
    }


def _build_export_payload(
    transcript: CanonicalTranscript,
    workspace_path: Path,
    session_id: str,
    started_at: datetime,
    provider_id: str,
    model_id: str,
) -> dict[str, Any]:
    updated_ms = _ts_ms(transcript.session.ended_at or _latest_event_ts(transcript) or started_at)

    messages = _build_messages(
        transcript=transcript,
        session_id=session_id,
        workspace_path=workspace_path,
        provider_id=provider_id,
        model_id=model_id,
    )
    return {
        "info": {
            "id": session_id,
            "slug": _slugify(f"resumed-{transcript.session.agent}-{transcript.session.id[:8]}"),
            "projectID": "global",
            "directory": str(workspace_path),
            "title": f"Resumed from {transcript.session.agent}",
            "version": transcript.session.version or "anyfs-resume",
            "time": {
                "created": _ts_ms(started_at),
                "updated": updated_ms,
            },
        },
        "messages": messages,
    }


def _build_messages(
    transcript: CanonicalTranscript,
    session_id: str,
    workspace_path: Path,
    provider_id: str,
    model_id: str,
) -> list[dict[str, Any]]:
    messages: list[dict[str, Any]] = []
    assistant: _AssistantAccumulator | None = None
    current_user_id: str | None = None
    current_user_ms: int | None = None

    def ensure_user(ts_ms: int, text: str = "[Imported prior context]") -> str:
        nonlocal current_user_id, current_user_ms
        if current_user_id is not None:
            return current_user_id
        current_user_id = _make_id("msg", ts_ms)
        current_user_ms = ts_ms
        messages.append(
            {
                "info": {
                    "id": current_user_id,
                    "sessionID": session_id,
                    "role": "user",
                    "time": {"created": ts_ms},
                    "agent": _DEFAULT_AGENT_NAME,
                    "model": {
                        "providerID": provider_id,
                        "modelID": model_id,
                    },
                },
                "parts": [
                    {
                        "id": _make_id("prt", ts_ms),
                        "sessionID": session_id,
                        "messageID": current_user_id,
                        "type": "text",
                        "text": text,
                        "synthetic": True,
                        "time": {"start": ts_ms, "end": ts_ms},
                    }
                ],
            }
        )
        return current_user_id

    def flush_assistant() -> None:
        nonlocal assistant
        if assistant is None or not assistant.has_content():
            assistant = None
            return
        parent_id = ensure_user(assistant.created_ms)
        message_id = _make_id("msg", assistant.created_ms)
        parts = []
        for index, pending in enumerate(assistant.parts, start=1):
            payload = {
                **pending.payload,
                "id": _make_id("prt", assistant.created_ms + index),
                "sessionID": session_id,
                "messageID": message_id,
            }
            parts.append(payload)
        messages.append(
            {
                "info": {
                    "id": message_id,
                    "sessionID": session_id,
                    "role": "assistant",
                    "time": {
                        "created": assistant.created_ms,
                        "completed": assistant.created_ms,
                    },
                    "parentID": parent_id,
                    "modelID": model_id,
                    "providerID": provider_id,
                    "mode": "default",
                    "agent": _DEFAULT_AGENT_NAME,
                    "path": {
                        "cwd": str(workspace_path),
                        "root": str(workspace_path),
                    },
                    "cost": 0,
                    "tokens": {
                        "input": 0,
                        "output": 0,
                        "reasoning": 0,
                        "cache": {
                            "read": 0,
                            "write": 0,
                        },
                    },
                    "finish": "stop",
                },
                "parts": parts,
            }
        )
        assistant = None

    def ensure_assistant(ts_ms: int) -> _AssistantAccumulator:
        nonlocal assistant
        if assistant is None:
            assistant = _AssistantAccumulator(created_ms=ts_ms)
        return assistant

    for event in transcript.events:
        ts_ms = _ts_ms(getattr(event, "ts", None) or transcript.session.started_at or datetime.now(timezone.utc))

        if isinstance(event, UserMessageEvent):
            flush_assistant()
            current_user_id = _make_id("msg", ts_ms)
            current_user_ms = ts_ms
            messages.append(
                {
                    "info": {
                        "id": current_user_id,
                        "sessionID": session_id,
                        "role": "user",
                        "time": {"created": ts_ms},
                        "agent": _DEFAULT_AGENT_NAME,
                        "model": {
                            "providerID": provider_id,
                            "modelID": model_id,
                        },
                    },
                    "parts": [
                        {
                            "id": _make_id("prt", ts_ms),
                            "sessionID": session_id,
                            "messageID": current_user_id,
                            "type": "text",
                            "text": event.text,
                            "time": {"start": ts_ms, "end": ts_ms},
                        }
                    ],
                }
            )
            continue

        bucket = ensure_assistant(ts_ms)

        if isinstance(event, AssistantTextEvent):
            if event.text:
                bucket.parts.append(
                    _PendingPart(
                        "text",
                        {
                            "type": "text",
                            "text": event.text,
                            "time": {"start": ts_ms, "end": ts_ms},
                        },
                    )
                )
            continue

        if isinstance(event, ThinkingEvent):
            if event.text:
                bucket.parts.append(
                    _PendingPart(
                        "reasoning",
                        {
                            "type": "reasoning",
                            "text": event.text,
                            "time": {"start": ts_ms, "end": ts_ms},
                        },
                    )
                )
            continue

        if isinstance(event, ShellCommandEvent):
            bucket.parts.append(
                _PendingPart(
                    "tool",
                    _tool_part(
                        ts_ms=ts_ms,
                        tool="bash",
                        call_id=_make_id("tool", ts_ms),
                        input_payload={"command": event.command},
                        output=event.output_preview or "",
                        title=event.command,
                        error=None if event.exit_code in (None, 0) else f"Command exited with {event.exit_code}",
                    ),
                )
            )
            continue

        if isinstance(event, FileReadEvent):
            bucket.parts.append(
                _PendingPart(
                    "tool",
                    _tool_part(
                        ts_ms=ts_ms,
                        tool="read",
                        call_id=_make_id("tool", ts_ms),
                        input_payload={"filePath": event.path},
                        output=event.content_preview or "",
                        title=f"Read {event.path}",
                    ),
                )
            )
            continue

        if isinstance(event, FileEditEvent):
            bucket.parts.append(
                _PendingPart(
                    "tool",
                    _tool_part(
                        ts_ms=ts_ms,
                        tool="edit",
                        call_id=_make_id("tool", ts_ms),
                        input_payload={"filePath": event.path, "diff": event.diff or ""},
                        output=event.diff or "ok",
                        title=f"Edit {event.path}",
                    ),
                )
            )
            continue

        if isinstance(event, FileWriteEvent):
            bucket.parts.append(
                _PendingPart(
                    "tool",
                    _tool_part(
                        ts_ms=ts_ms,
                        tool="write",
                        call_id=_make_id("tool", ts_ms),
                        input_payload={"filePath": event.path},
                        output=event.content_preview or "ok",
                        title=f"Write {event.path}",
                    ),
                )
            )
            continue

        if isinstance(event, CodeSearchEvent):
            bucket.parts.append(
                _PendingPart(
                    "tool",
                    _tool_part(
                        ts_ms=ts_ms,
                        tool="codesearch",
                        call_id=_make_id("tool", ts_ms),
                        input_payload={"query": event.query},
                        output=event.result_preview or "",
                        title=f"Search {event.query}",
                    ),
                )
            )
            continue

        if isinstance(event, ErrorEvent):
            bucket.parts.append(
                _PendingPart(
                    "text",
                    {
                        "type": "text",
                        "text": f"[Error] {event.message}",
                        "time": {"start": ts_ms, "end": ts_ms},
                    },
                )
            )
            continue

        if isinstance(event, FileSnapshotEvent):
            label = ", ".join(event.paths[:5]) if event.paths else "workspace"
            bucket.parts.append(
                _PendingPart(
                    "text",
                    {
                        "type": "text",
                        "text": f"[Snapshot] {label}",
                        "time": {"start": ts_ms, "end": ts_ms},
                    },
                )
            )
            continue

        bucket.parts.append(
            _PendingPart(
                "text",
                {
                    "type": "text",
                    "text": f"[{event.kind}]",
                    "time": {"start": ts_ms, "end": ts_ms},
                },
            )
        )

    flush_assistant()

    if current_user_id is not None and current_user_ms is not None and not any(
        item["info"]["role"] == "assistant" and item["info"]["parentID"] == current_user_id for item in messages
    ):
        assistant_id = _make_id("msg", current_user_ms + 1)
        messages.append(
            {
                "info": {
                    "id": assistant_id,
                    "sessionID": session_id,
                    "role": "assistant",
                    "time": {
                        "created": current_user_ms + 1,
                        "completed": current_user_ms + 1,
                    },
                    "parentID": current_user_id,
                    "modelID": model_id,
                    "providerID": provider_id,
                    "mode": "default",
                    "agent": _DEFAULT_AGENT_NAME,
                    "path": {
                        "cwd": str(workspace_path),
                        "root": str(workspace_path),
                    },
                    "cost": 0,
                    "tokens": {
                        "input": 0,
                        "output": 0,
                        "reasoning": 0,
                        "cache": {
                            "read": 0,
                            "write": 0,
                        },
                    },
                    "finish": "stop",
                },
                "parts": [
                    {
                        "id": _make_id("prt", current_user_ms + 2),
                        "sessionID": session_id,
                        "messageID": assistant_id,
                        "type": "text",
                        "text": "[Imported context ready]",
                        "synthetic": True,
                        "time": {"start": current_user_ms + 1, "end": current_user_ms + 1},
                    }
                ],
            }
        )

    return messages


def _tool_part(
    *,
    ts_ms: int,
    tool: str,
    call_id: str,
    input_payload: dict[str, Any],
    output: str,
    title: str,
    error: str | None = None,
) -> dict[str, Any]:
    if error:
        return {
            "type": "tool",
            "callID": call_id,
            "tool": tool,
            "state": {
                "status": "error",
                "input": input_payload,
                "error": error,
                "time": {"start": ts_ms, "end": ts_ms},
            },
        }
    return {
        "type": "tool",
        "callID": call_id,
        "tool": tool,
        "state": {
            "status": "completed",
            "input": input_payload,
            "output": output,
            "title": title,
            "metadata": {},
            "time": {"start": ts_ms, "end": ts_ms},
        },
    }


def _import_into_opencode(export_path: Path, workspace_path: Path) -> dict[str, bool]:
    binary = _resolve_opencode_binary()
    if not binary:
        return {"imported": False}

    result = subprocess.run(
        [binary, "import", str(export_path)],
        cwd=str(workspace_path),
        text=True,
        capture_output=True,
        check=False,
        env=os.environ.copy(),
    )
    if result.returncode == 0:
        return {"imported": True}

    stderr = (result.stderr or "").strip()
    stdout = (result.stdout or "").strip()
    detail = stderr or stdout or f"exit code {result.returncode}"
    raise ValueError(f"failed to import session into OpenCode: {detail}")


def _resolve_opencode_binary() -> str | None:
    explicit = os.environ.get("OPENCODE_BIN")
    if explicit:
        return explicit

    discovered = shutil.which("opencode")
    if discovered:
        return discovered

    home = Path.home()
    candidates = sorted(home.glob(".local/node-*/bin/opencode"), reverse=True)
    candidates.extend(
        [
            home / ".npm-global" / "bin" / "opencode",
            home / ".local" / "bin" / "opencode",
        ]
    )
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate)
    return None


def _resolve_target_model(workspace_path: Path, fallback: str | None) -> tuple[str, str]:
    explicit = os.environ.get("ANYFS_OPENCODE_MODEL") or os.environ.get("OPENCODE_MODEL")
    if explicit and "/" in explicit:
        return tuple(explicit.split("/", 1))  # type: ignore[return-value]

    for config_path in _candidate_config_paths(workspace_path):
        try:
            data = json.loads(config_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        model = data.get("model")
        if isinstance(model, str) and "/" in model:
            return tuple(model.split("/", 1))  # type: ignore[return-value]

    return _infer_model(fallback)


def _candidate_config_paths(workspace_path: Path) -> list[Path]:
    return [
        workspace_path / "opencode.json",
        workspace_path / ".opencode" / "opencode.json",
        Path.home() / ".config" / "opencode" / "opencode.json",
    ]


def _infer_model(model: str | None) -> tuple[str, str]:
    if model and "/" in model:
        provider_id, model_id = model.split("/", 1)
        return provider_id, model_id
    if not model:
        return "openai", "gpt-4.1"
    lowered = model.lower()
    if "claude" in lowered:
        return "anthropic", model
    if "gemini" in lowered:
        return "google", model
    return "openai", model


def _make_id(prefix: str, ts_ms: int) -> str:
    timestamp = max(ts_ms, 0).to_bytes(6, byteorder="big", signed=False).hex()
    suffix = os.urandom(8).hex()
    return f"{prefix}_{timestamp}{suffix}"


def _slugify(text: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return slug or "resumed-session"


def _latest_event_ts(transcript: CanonicalTranscript) -> datetime | None:
    if not transcript.events:
        return None
    return max(
        (getattr(event, "ts", None) or transcript.session.started_at or datetime.now(timezone.utc) for event in transcript.events),
        default=None,
    )


def _ts_ms(value: datetime) -> int:
    return int(value.timestamp() * 1000)
