"""Export a CanonicalTranscript to Nanobot's native session JSONL."""
from __future__ import annotations

import json
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from anyfs_schemas import (
    AssistantTextEvent,
    CanonicalTranscript,
    CodeSearchEvent,
    ErrorEvent,
    FileEditEvent,
    FileReadEvent,
    FileWriteEvent,
    ShellCommandEvent,
    ThinkingEvent,
    UserMessageEvent,
)

_UNSAFE_FILENAME = re.compile(r'[<>:"/\\\\|?*]')


def export_nanobot(
    transcript: CanonicalTranscript,
    workspace: str,
) -> dict[str, str]:
    """Export a canonical transcript as a Nanobot native workspace session."""
    workspace_path = Path(workspace).resolve()
    sessions_dir = workspace_path / "sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)

    started_at = transcript.session.started_at or _latest_event_ts(transcript) or datetime.now(timezone.utc)
    updated_at = transcript.session.ended_at or _latest_event_ts(transcript) or started_at
    session_key = f"cli:anyfs-resume:{transcript.session.id[:8]}:{uuid.uuid4().hex[:6]}"
    transcript_path = sessions_dir / f"{_safe_filename(session_key.replace(':', '_'))}.jsonl"

    messages = _build_messages(transcript)
    metadata = {
        "_type": "metadata",
        "key": session_key,
        "created_at": started_at.isoformat(),
        "updated_at": updated_at.isoformat(),
        "metadata": {
            "source_agent": transcript.session.agent,
            "source_session_id": transcript.session.id,
            "source_model": transcript.session.model,
            "resume_title": f"Resumed from {transcript.session.agent}",
        },
        "last_consolidated": 0,
    }

    lines = [json.dumps(metadata, ensure_ascii=False)]
    lines.extend(json.dumps(message, ensure_ascii=False) for message in messages)
    transcript_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    return {
        "transcript": str(transcript_path),
        "session_id": session_key,
        "session_key": session_key,
        "resume_hint": f'nanobot agent --session {session_key} --workspace {workspace_path} --message "<your prompt>"',
    }


def _build_messages(transcript: CanonicalTranscript) -> list[dict[str, Any]]:
    messages: list[dict[str, Any]] = []
    assistant_text: list[str] = []
    assistant_reasoning: list[str] = []

    def flush_assistant(ts: str | None) -> None:
        nonlocal assistant_text, assistant_reasoning
        if not assistant_text and not assistant_reasoning:
            return
        payload: dict[str, Any] = {
            "role": "assistant",
            "content": "\n\n".join(part for part in assistant_text if part).strip() or "",
            "timestamp": ts or datetime.now(timezone.utc).isoformat(),
        }
        if assistant_reasoning:
            payload["reasoning_content"] = "\n\n".join(part for part in assistant_reasoning if part).strip()
        messages.append(payload)
        assistant_text = []
        assistant_reasoning = []

    for event in transcript.events:
        ts = (getattr(event, "ts", None) or transcript.session.started_at or datetime.now(timezone.utc)).isoformat()
        if isinstance(event, UserMessageEvent):
            flush_assistant(ts)
            messages.append({"role": "user", "content": event.text, "timestamp": ts})
            continue
        if isinstance(event, AssistantTextEvent):
            if event.text:
                assistant_text.append(event.text)
            continue
        if isinstance(event, ThinkingEvent):
            if event.text:
                assistant_reasoning.append(event.text)
            continue

        flush_assistant(ts)
        messages.extend(_tool_messages_for_event(event, ts))

    flush_assistant((transcript.session.ended_at or transcript.session.started_at or datetime.now(timezone.utc)).isoformat())
    return messages


def _tool_messages_for_event(event: Any, ts: str) -> list[dict[str, Any]]:
    call_id = f"call_{uuid.uuid4().hex[:24]}"
    if isinstance(event, ShellCommandEvent):
        return _tool_turn(call_id, "exec", {"command": event.command}, event.output_preview or "", ts)
    if isinstance(event, FileReadEvent):
        return _tool_turn(call_id, "read_file", {"path": event.path}, event.content_preview or "", ts)
    if isinstance(event, FileEditEvent):
        return _tool_turn(call_id, "edit_file", {"path": event.path, "diff": event.diff or ""}, event.diff or "ok", ts)
    if isinstance(event, FileWriteEvent):
        return _tool_turn(call_id, "write_file", {"path": event.path}, event.content_preview or "ok", ts)
    if isinstance(event, CodeSearchEvent):
        return _tool_turn(call_id, "search", {"query": event.query}, event.result_preview or "", ts)
    if isinstance(event, ErrorEvent):
        return [{"role": "assistant", "content": f"[Error] {event.message}", "timestamp": ts}]
    return [{"role": "assistant", "content": f"[{getattr(event, 'kind', 'event')}]", "timestamp": ts}]


def _tool_turn(call_id: str, name: str, args: dict[str, Any], result: str, ts: str) -> list[dict[str, Any]]:
    return [
        {
            "role": "assistant",
            "content": "",
            "tool_calls": [
                {
                    "id": call_id,
                    "type": "function",
                    "function": {
                        "name": name,
                        "arguments": json.dumps(args, ensure_ascii=False),
                    },
                }
            ],
            "timestamp": ts,
        },
        {
            "role": "tool",
            "tool_call_id": call_id,
            "name": name,
            "content": result,
            "timestamp": ts,
        },
    ]


def _latest_event_ts(transcript: CanonicalTranscript) -> datetime | None:
    if not transcript.events:
        return None
    timestamps = [event.ts for event in transcript.events if getattr(event, "ts", None)]
    return max(timestamps) if timestamps else None


def _safe_filename(name: str) -> str:
    return _UNSAFE_FILENAME.sub("_", name).strip()
