"""Export a CanonicalTranscript to Codex CLI's native JSONL format."""
from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path

from anyfs_schemas import (
    AssistantTextEvent,
    CanonicalTranscript,
    CodeSearchEvent,
    FileEditEvent,
    FileReadEvent,
    FileWriteEvent,
    ShellCommandEvent,
    ThinkingEvent,
    UserMessageEvent,
)


def export_codex_cli(
    transcript: CanonicalTranscript,
    workspace: str,
) -> dict[str, str]:
    """Export a canonical transcript as a Codex CLI native JSONL session.

    Creates the rollout .jsonl file in ~/.codex/sessions/ so Codex can
    see it as a previous session.

    Returns dict with paths of files written.
    """
    workspace_path = Path(workspace).resolve()
    now = datetime.now(timezone.utc)
    session_id = str(uuid.uuid4())

    lines: list[str] = []

    # Session meta (first line)
    lines.append(json.dumps({
        "type": "session_meta",
        "timestamp": now.isoformat(),
        "payload": {
            "id": session_id,
            "timestamp": now.isoformat(),
            "cwd": str(workspace_path),
            "originator": "anyfs_resume",
            "cli_version": "0.80.0",
            "model_provider": transcript.session.model or "unknown",
            "git": {
                "branch": transcript.session.git_branch or "main",
            },
            "instructions": f"Resumed from {transcript.session.agent} session",
        },
    }, default=str))

    for event in transcript.events:
        ts = event.ts.isoformat() if event.ts else now.isoformat()

        if isinstance(event, UserMessageEvent):
            lines.append(json.dumps({
                "type": "response_item",
                "timestamp": ts,
                "payload": {
                    "type": "message",
                    "role": "user",
                    "content": [{"type": "input_text", "text": event.text}],
                },
            }, default=str))

        elif isinstance(event, AssistantTextEvent):
            lines.append(json.dumps({
                "type": "response_item",
                "timestamp": ts,
                "payload": {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": event.text}],
                },
            }, default=str))

        elif isinstance(event, ThinkingEvent):
            lines.append(json.dumps({
                "type": "response_item",
                "timestamp": ts,
                "payload": {
                    "type": "reasoning",
                    "summary": [],
                    "content": event.text or None,
                    "encrypted_content": None,
                },
            }, default=str))

        elif isinstance(event, ShellCommandEvent):
            call_id = f"call_{uuid.uuid4().hex[:24]}"
            lines.append(json.dumps({
                "type": "response_item",
                "timestamp": ts,
                "payload": {
                    "type": "function_call",
                    "name": "shell",
                    "arguments": json.dumps({"command": event.command}),
                    "call_id": call_id,
                },
            }, default=str))
            if event.output_preview:
                lines.append(json.dumps({
                    "type": "response_item",
                    "timestamp": ts,
                    "payload": {
                        "type": "function_call_output",
                        "call_id": call_id,
                        "output": event.output_preview,
                    },
                }, default=str))

        elif isinstance(event, FileReadEvent):
            call_id = f"call_{uuid.uuid4().hex[:24]}"
            lines.append(json.dumps({
                "type": "response_item",
                "timestamp": ts,
                "payload": {
                    "type": "function_call",
                    "name": "read_file",
                    "arguments": json.dumps({"path": event.path}),
                    "call_id": call_id,
                },
            }, default=str))
            if event.content_preview:
                lines.append(json.dumps({
                    "type": "response_item",
                    "timestamp": ts,
                    "payload": {
                        "type": "function_call_output",
                        "call_id": call_id,
                        "output": event.content_preview,
                    },
                }, default=str))

        elif isinstance(event, FileEditEvent):
            call_id = f"call_{uuid.uuid4().hex[:24]}"
            lines.append(json.dumps({
                "type": "response_item",
                "timestamp": ts,
                "payload": {
                    "type": "function_call",
                    "name": "edit_file",
                    "arguments": json.dumps({"path": event.path, "diff": event.diff or ""}),
                    "call_id": call_id,
                },
            }, default=str))
            lines.append(json.dumps({
                "type": "response_item",
                "timestamp": ts,
                "payload": {
                    "type": "function_call_output",
                    "call_id": call_id,
                    "output": "ok",
                },
            }, default=str))

        elif isinstance(event, FileWriteEvent):
            call_id = f"call_{uuid.uuid4().hex[:24]}"
            lines.append(json.dumps({
                "type": "response_item",
                "timestamp": ts,
                "payload": {
                    "type": "function_call",
                    "name": "write_file",
                    "arguments": json.dumps({"path": event.path}),
                    "call_id": call_id,
                },
            }, default=str))
            lines.append(json.dumps({
                "type": "response_item",
                "timestamp": ts,
                "payload": {
                    "type": "function_call_output",
                    "call_id": call_id,
                    "output": "ok",
                },
            }, default=str))

        elif isinstance(event, CodeSearchEvent):
            call_id = f"call_{uuid.uuid4().hex[:24]}"
            lines.append(json.dumps({
                "type": "response_item",
                "timestamp": ts,
                "payload": {
                    "type": "function_call",
                    "name": "search",
                    "arguments": json.dumps({"query": event.query}),
                    "call_id": call_id,
                },
            }, default=str))
            if event.result_preview:
                lines.append(json.dumps({
                    "type": "response_item",
                    "timestamp": ts,
                    "payload": {
                        "type": "function_call_output",
                        "call_id": call_id,
                        "output": event.result_preview,
                    },
                }, default=str))

    # Write to Codex sessions directory
    sessions_dir = Path.home() / ".codex" / "sessions" / now.strftime("%Y") / now.strftime("%m") / now.strftime("%d")
    sessions_dir.mkdir(parents=True, exist_ok=True)
    filename = f"rollout-{now.strftime('%Y-%m-%dT%H-%M-%S')}-{session_id}.jsonl"
    jsonl_path = sessions_dir / filename
    jsonl_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    return {
        "transcript": str(jsonl_path),
        "session_id": session_id,
        "resume_hint": f"codex resume {session_id}",
    }
