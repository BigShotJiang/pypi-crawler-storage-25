from __future__ import annotations

from pathlib import Path

from .parsers.base import TranscriptParser


_PARSERS: dict[str, TranscriptParser] = {}


def register_parser(parser: TranscriptParser) -> None:
    _PARSERS[parser.agent_type] = parser


def get_parser(agent_type: str) -> TranscriptParser | None:
    return _PARSERS.get(agent_type)


def detect_parser(path: Path) -> TranscriptParser | None:
    """Auto-detect the right parser for a transcript file."""
    for parser in _PARSERS.values():
        if parser.can_parse(path):
            return parser
    return None


def _register_builtins() -> None:
    from .parsers.claude_code import ClaudeCodeParser
    register_parser(ClaudeCodeParser())

    try:
        from .parsers.gemini_cli import GeminiCLIParser
        register_parser(GeminiCLIParser())
    except ImportError:
        pass

    try:
        from .parsers.codex_cli import CodexCLIParser
        register_parser(CodexCLIParser())
    except ImportError:
        pass

    try:
        from .parsers.openclaw import OpenClawParser
        register_parser(OpenClawParser())
    except ImportError:
        pass

    try:
        from .parsers.hermes import HermesParser
        register_parser(HermesParser())
    except ImportError:
        pass

    try:
        from .parsers.nanobot import NanobotParser
        register_parser(NanobotParser())
    except ImportError:
        pass

    try:
        from .parsers.opencode import OpenCodeParser
        register_parser(OpenCodeParser())
    except ImportError:
        pass


_register_builtins()
