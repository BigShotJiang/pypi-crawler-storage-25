"""Inject session context into Gemini CLI's instruction system."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from anyfs_schemas import CanonicalTranscript

from .context import render_resume_context


def inject_gemini_cli(
    transcript: CanonicalTranscript,
    workspace: str,
) -> dict[str, str]:
    """Inject a canonical transcript as Gemini CLI project instructions.

    Gemini CLI reads GEMINI.md from the workspace root as project context.

    Returns dict of files written.
    """
    workspace_path = Path(workspace).resolve()
    context = render_resume_context(transcript)
    source = transcript.session.agent
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    gemini_md = workspace_path / "GEMINI.md"
    section = f"""
---

## Resumed Session Context (from {source}, {ts})

{context}
"""

    if gemini_md.exists():
        existing = gemini_md.read_text(encoding="utf-8")
        if "Resumed Session Context" not in existing:
            gemini_md.write_text(existing + section, encoding="utf-8")
    else:
        gemini_md.write_text(f"# Project Instructions\n{section}", encoding="utf-8")

    return {"gemini_md": str(gemini_md)}
