"""Compress a CanonicalTranscript into a concise context block for session resume."""
from __future__ import annotations

from anyfs_schemas import (
    AssistantTextEvent,
    CanonicalTranscript,
    CodeSearchEvent,
    ErrorEvent,
    FileEditEvent,
    FileReadEvent,
    FileWriteEvent,
    ShellCommandEvent,
    ThinkingEvent,
    UserMessageEvent,
)


def render_resume_context(transcript: CanonicalTranscript, max_chars: int = 8000) -> str:
    """Render a transcript into a concise context summary for injecting into another client.

    Unlike full markdown rendering, this focuses on:
    - What the user asked for
    - Key decisions made
    - Files touched (read/edited/created)
    - Commands run and outcomes
    - Final state / what was accomplished

    Stays under max_chars to fit in context windows.
    """
    parts: list[str] = []
    s = transcript.session

    parts.append(f"# Previous Session Context")
    parts.append(f"Source: {s.agent} | Model: {s.model or 'unknown'} | Branch: {s.git_branch or 'unknown'}")
    if s.cwd:
        parts.append(f"Working directory: {s.cwd}")
    parts.append("")

    # Collect structured summaries
    user_requests: list[str] = []
    decisions: list[str] = []
    files_read: list[str] = []
    files_modified: list[str] = []
    files_created: list[str] = []
    commands: list[str] = []
    errors: list[str] = []

    for event in transcript.events:
        if isinstance(event, UserMessageEvent):
            # Only include substantive user requests (skip tool results, short acks)
            if len(event.text) > 10 and not event.text.startswith("["):
                user_requests.append(event.text)

        elif isinstance(event, AssistantTextEvent):
            # Capture key decision statements (longer texts are usually explanations)
            if 20 < len(event.text) < 500 and not event.meta.get("agent_delegation"):
                decisions.append(event.text)

        elif isinstance(event, FileReadEvent):
            if event.path and event.path not in files_read:
                files_read.append(event.path)

        elif isinstance(event, FileEditEvent):
            if event.path and event.path not in files_modified:
                files_modified.append(event.path)

        elif isinstance(event, FileWriteEvent):
            if event.path and event.path not in files_created:
                files_created.append(event.path)

        elif isinstance(event, ShellCommandEvent):
            status = "ok" if event.exit_code in (None, 0) else f"exit {event.exit_code}"
            commands.append(f"`{event.command}` ({status})")

        elif isinstance(event, ErrorEvent):
            errors.append(event.message[:200])

    # Build summary sections
    if user_requests:
        parts.append("## User Requests")
        for i, req in enumerate(user_requests[:10]):
            parts.append(f"{i+1}. {_truncate(req, 300)}")
        parts.append("")

    if decisions:
        parts.append("## Key Decisions & Explanations")
        # Take last N decisions (most recent = most relevant)
        for d in decisions[-8:]:
            parts.append(f"- {_truncate(d, 300)}")
        parts.append("")

    if files_created:
        parts.append("## Files Created")
        for f in files_created[:20]:
            parts.append(f"- `{f}`")
        parts.append("")

    if files_modified:
        parts.append("## Files Modified")
        for f in files_modified[:20]:
            parts.append(f"- `{f}`")
        parts.append("")

    if files_read:
        parts.append("## Files Read")
        for f in files_read[:20]:
            parts.append(f"- `{f}`")
        parts.append("")

    if commands:
        parts.append("## Commands Run")
        for c in commands[-15:]:
            parts.append(f"- {c}")
        parts.append("")

    if errors:
        parts.append("## Errors Encountered")
        for e in errors[:5]:
            parts.append(f"- {e}")
        parts.append("")

    result = "\n".join(parts)

    # Truncate if needed
    if len(result) > max_chars:
        result = result[:max_chars - 50] + "\n\n... (truncated, see full transcript for details)"

    return result


def _truncate(text: str, limit: int) -> str:
    text = text.replace("\n", " ").strip()
    if len(text) <= limit:
        return text
    return text[:limit] + "..."
