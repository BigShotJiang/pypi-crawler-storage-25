"""Inject session context into Cursor's rules system."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from anyfs_schemas import CanonicalTranscript

from .context import render_resume_context


def inject_cursor(
    transcript: CanonicalTranscript,
    workspace: str,
) -> dict[str, str]:
    """Inject a canonical transcript as Cursor project rules.

    Cursor reads .cursor/rules/*.mdc from the workspace for project context.

    Returns dict of files written.
    """
    workspace_path = Path(workspace).resolve()
    context = render_resume_context(transcript)
    source = transcript.session.agent
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    rules_dir = workspace_path / ".cursor" / "rules"
    rules_dir.mkdir(parents=True, exist_ok=True)

    rule_file = rules_dir / "resumed-session.mdc"
    content = f"""---
description: Context from a previous {source} session for continuity
globs:
alwaysApply: true
---

{context}
"""
    rule_file.write_text(content, encoding="utf-8")

    return {"cursor_rule": str(rule_file)}
