"""Inject session context into Codex CLI's instruction system."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from anyfs_schemas import CanonicalTranscript

from .context import render_resume_context


def inject_codex_cli(
    transcript: CanonicalTranscript,
    workspace: str,
) -> dict[str, str]:
    """Inject a canonical transcript as Codex CLI instructions.

    Codex reads AGENTS.md from the workspace root as project instructions.
    Appends a session context section to AGENTS.md.

    Returns dict of files written.
    """
    workspace_path = Path(workspace).resolve()
    context = render_resume_context(transcript)
    source = transcript.session.agent
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    agents_md = workspace_path / "AGENTS.md"
    section = f"""
---

## Resumed Session Context (from {source}, {ts})

{context}
"""

    if agents_md.exists():
        existing = agents_md.read_text(encoding="utf-8")
        if "Resumed Session Context" not in existing:
            agents_md.write_text(existing + section, encoding="utf-8")
    else:
        agents_md.write_text(f"# Project Instructions\n{section}", encoding="utf-8")

    return {"agents_md": str(agents_md)}
