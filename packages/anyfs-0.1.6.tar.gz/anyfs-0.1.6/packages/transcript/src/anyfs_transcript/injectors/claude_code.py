"""Inject session context into Claude Code's memory system."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from anyfs_schemas import CanonicalTranscript

from .context import render_resume_context


def inject_claude_code(
    transcript: CanonicalTranscript,
    workspace: str,
) -> dict[str, str]:
    """Inject a canonical transcript as Claude Code memory so the session can be resumed.

    Writes to ~/.claude/projects/<encoded-workspace>/memory/ as a memory file
    that Claude Code will automatically load in future conversations.

    Returns dict of files written.
    """
    workspace_path = Path(workspace).resolve()
    encoded = str(workspace_path).replace("/", "-")
    memory_dir = Path.home() / ".claude" / "projects" / encoded / "memory"
    memory_dir.mkdir(parents=True, exist_ok=True)

    context = render_resume_context(transcript)
    source = transcript.session.agent
    ts = datetime.now(timezone.utc).strftime("%Y%m%d")

    # Write as a memory file with frontmatter
    filename = f"resumed_from_{source}_{ts}.md"
    memory_file = memory_dir / filename
    content = f"""---
name: resumed-session-{source}
description: Context from a {source} session to continue work in Claude Code
type: project
---

{context}
"""
    memory_file.write_text(content, encoding="utf-8")

    # Also update MEMORY.md index if it exists
    memory_index = memory_dir / "MEMORY.md"
    index_line = f"- [Resumed from {source}]({filename}) — session context imported for continuity\n"
    if memory_index.exists():
        existing = memory_index.read_text(encoding="utf-8")
        if filename not in existing:
            memory_index.write_text(existing + index_line, encoding="utf-8")
    else:
        memory_index.write_text(index_line, encoding="utf-8")

    return {
        "memory_file": str(memory_file),
        "memory_index": str(memory_index),
    }
