from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from anyfs_schemas import (
    AssistantTextEvent,
    CanonicalTranscript,
    CodeSearchEvent,
    FileEditEvent,
    FileReadEvent,
    FileWriteEvent,
    ShellCommandEvent,
    ThinkingEvent,
    TranscriptSessionMeta,
    UserMessageEvent,
)

_PREVIEW_LIMIT = 500


class NanobotParser:
    agent_type = "nanobot"

    def can_parse(self, path: Path) -> bool:
        if not path.is_file() or path.suffix != ".jsonl":
            return False
        try:
            first_line = path.read_text(encoding="utf-8").split("\n", 1)[0]
            payload = json.loads(first_line)
        except (OSError, json.JSONDecodeError):
            return False
        return payload.get("_type") == "metadata" and "key" in payload

    def parse(self, path: Path) -> CanonicalTranscript:
        lines = []
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                lines.append(json.loads(line))
            except json.JSONDecodeError:
                continue

        metadata = lines[0] if lines and isinstance(lines[0], dict) and lines[0].get("_type") == "metadata" else {}
        messages = [line for line in lines[1:] if isinstance(line, dict)]
        session_key = metadata.get("key", path.stem)
        workspace = path.parent.parent if path.parent.name == "sessions" else None
        session = TranscriptSessionMeta(
            id=session_key,
            agent="nanobot",
            cwd=str(workspace) if workspace else None,
            started_at=_parse_ts(metadata.get("created_at")) if metadata else datetime.now(timezone.utc),
            ended_at=_parse_ts(metadata.get("updated_at")) if metadata else None,
        )
        return CanonicalTranscript(session=session, events=_messages_to_events(messages))


def _messages_to_events(messages: list[dict[str, Any]]) -> list[Any]:
    events: list[Any] = []
    pending_calls: dict[str, Any] = {}
    for message in messages:
        role = message.get("role")
        ts = _parse_ts(message.get("timestamp"))
        if role == "user":
            text = _extract_text(message.get("content"))
            if text:
                events.append(UserMessageEvent(ts=ts, text=text))
            continue
        if role == "assistant":
            reasoning = str(message.get("reasoning_content", "")).strip()
            if reasoning:
                events.append(ThinkingEvent(ts=ts, text=reasoning))
            text = _extract_text(message.get("content"))
            if text:
                events.append(AssistantTextEvent(ts=ts, text=text))
            for call in message.get("tool_calls") or []:
                event = _tool_event_from_call(call, ts)
                if event is None:
                    continue
                call_id = call.get("id")
                if call_id:
                    pending_calls[str(call_id)] = event
                events.append(event)
            continue
        if role == "tool":
            call_id = str(message.get("tool_call_id") or "")
            preview = _truncate(_extract_text(message.get("content")))
            event = pending_calls.pop(call_id, None)
            if isinstance(event, ShellCommandEvent):
                event.output_preview = preview
            elif isinstance(event, FileReadEvent):
                event.content_preview = preview
            elif isinstance(event, FileEditEvent):
                event.diff = preview
            elif isinstance(event, FileWriteEvent):
                event.content_preview = preview
            elif isinstance(event, CodeSearchEvent):
                event.result_preview = preview
    return events


def _tool_event_from_call(call: dict[str, Any], ts: datetime) -> Any:
    function = call.get("function") or {}
    name = str(function.get("name") or call.get("name") or "").lower()
    arguments = function.get("arguments") or {}
    if isinstance(arguments, str):
        try:
            arguments = json.loads(arguments)
        except json.JSONDecodeError:
            arguments = {"raw": arguments}

    if name in {"exec", "shell", "bash"}:
        return ShellCommandEvent(ts=ts, command=arguments.get("command", "") or str(arguments))
    if name in {"read", "read_file"}:
        return FileReadEvent(ts=ts, path=arguments.get("path", "") or arguments.get("file_path", ""))
    if name in {"edit", "edit_file"}:
        return FileEditEvent(ts=ts, path=arguments.get("path", "") or arguments.get("file_path", ""), diff=arguments.get("diff"))
    if name in {"write", "write_file"}:
        return FileWriteEvent(ts=ts, path=arguments.get("path", "") or arguments.get("file_path", ""))
    if name in {"search", "grep", "glob", "codesearch"}:
        return CodeSearchEvent(ts=ts, tool_name=name, query=arguments.get("query", "") or str(arguments))
    return AssistantTextEvent(ts=ts, text=f"[Tool: {name}] {json.dumps(arguments, ensure_ascii=False)}")


def _extract_text(content: Any) -> str:
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                text = item.get("text")
                if isinstance(text, str):
                    parts.append(text)
        return "\n".join(part for part in parts if part).strip()
    return ""


def _parse_ts(raw: Any) -> datetime:
    if raw is None:
        return datetime.now(timezone.utc)
    if isinstance(raw, str):
        try:
            return datetime.fromisoformat(raw)
        except ValueError:
            return datetime.now(timezone.utc)
    if isinstance(raw, (int, float)):
        return datetime.fromtimestamp(raw, tz=timezone.utc)
    return datetime.now(timezone.utc)


def _truncate(text: str, limit: int = _PREVIEW_LIMIT) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + "..."
