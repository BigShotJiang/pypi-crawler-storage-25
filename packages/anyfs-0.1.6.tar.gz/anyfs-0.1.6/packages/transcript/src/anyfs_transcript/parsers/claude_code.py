from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from anyfs_schemas import (
    AssistantTextEvent,
    CanonicalTranscript,
    CodeSearchEvent,
    ErrorEvent,
    FileEditEvent,
    FileReadEvent,
    FileSnapshotEvent,
    FileWriteEvent,
    ShellCommandEvent,
    ThinkingEvent,
    TranscriptSessionMeta,
    UserMessageEvent,
)

# Tool name → canonical event kind mapping
_TOOL_MAP: dict[str, str] = {
    "Bash": "shell_command",
    "Read": "file_read",
    "Edit": "file_edit",
    "Write": "file_write",
    "Grep": "code_search",
    "Glob": "code_search",
    "WebSearch": "code_search",
    "WebFetch": "code_search",
}

_PREVIEW_LIMIT = 500


class ClaudeCodeParser:
    agent_type = "claude-code"

    def can_parse(self, path: Path) -> bool:
        if path.suffix != ".jsonl" or not path.is_file():
            return False
        try:
            first_line = path.read_text(encoding="utf-8").split("\n", 1)[0]
            entry = json.loads(first_line)
        except (OSError, json.JSONDecodeError):
            return False
        return entry.get("type") in {"system", "user", "assistant", "file-history-snapshot"}

    def parse(self, path: Path) -> CanonicalTranscript:
        lines = path.read_text(encoding="utf-8").splitlines()
        entries = []
        for line in lines:
            if not line.strip():
                continue
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                continue

        session = self._extract_session(entries, path)
        events = self._extract_events(entries)
        subagents = self._parse_subagents(path)

        return CanonicalTranscript(
            session=session,
            events=events,
            subagents=subagents,
        )

    def _extract_session(self, entries: list[dict], path: Path) -> TranscriptSessionMeta:
        session_id = path.stem
        cwd = None
        git_branch = None
        version = None
        started_at = datetime.now(timezone.utc)
        model = None

        for entry in entries:
            if entry.get("type") == "system":
                cwd = cwd or entry.get("cwd")
                git_branch = git_branch or entry.get("gitBranch")
                version = version or entry.get("version")
                session_id = entry.get("sessionId", session_id)
                ts = entry.get("timestamp")
                if ts:
                    try:
                        started_at = datetime.fromisoformat(ts)
                    except (ValueError, TypeError):
                        pass
                break

        # Find model from first assistant message
        for entry in entries:
            if entry.get("type") == "assistant":
                msg = _parse_message(entry)
                if msg:
                    model = msg.get("model")
                    if model:
                        break

        return TranscriptSessionMeta(
            id=session_id,
            agent="claude-code",
            model=model,
            cwd=cwd,
            git_branch=git_branch,
            started_at=started_at,
            version=version,
        )

    def _extract_events(self, entries: list[dict]) -> list:
        events: list = []
        # Map tool_use_id → pending event for enrichment from tool_result
        pending_tools: dict[str, Any] = {}

        for entry in entries:
            entry_type = entry.get("type", "")
            ts = _parse_ts(entry.get("timestamp"))

            if entry_type == "user":
                self._handle_user(entry, ts, events, pending_tools)
            elif entry_type == "assistant":
                self._handle_assistant(entry, ts, events, pending_tools)
            elif entry_type == "file-history-snapshot":
                self._handle_snapshot(entry, ts, events)

        return events

    def _handle_user(self, entry: dict, ts: datetime, events: list, pending_tools: dict) -> None:
        msg = _parse_message(entry)
        if not msg:
            return

        content = msg.get("content", "")

        # Simple text user message
        if isinstance(content, str) and content.strip():
            events.append(UserMessageEvent(ts=ts, text=content.strip()))
            return

        if not isinstance(content, list):
            return

        for block in content:
            if not isinstance(block, dict):
                continue
            block_type = block.get("type", "")

            if block_type == "text":
                text = block.get("text", "").strip()
                if text:
                    events.append(UserMessageEvent(ts=ts, text=text))

            elif block_type == "tool_result":
                tool_use_id = block.get("tool_use_id", "")
                result_content = block.get("content", "")
                if isinstance(result_content, list):
                    result_content = "\n".join(
                        p.get("text", "") for p in result_content
                        if isinstance(p, dict) and p.get("type") == "text"
                    )
                # Enrich pending tool event with result
                tool_result = entry.get("toolUseResult", {})
                self._enrich_tool_event(
                    pending_tools, tool_use_id, str(result_content), tool_result,
                )

    def _handle_assistant(self, entry: dict, ts: datetime, events: list, pending_tools: dict) -> None:
        msg = _parse_message(entry)
        if not msg:
            return

        content = msg.get("content", "")
        uuid = entry.get("uuid")

        if isinstance(content, str) and content.strip():
            events.append(AssistantTextEvent(
                ts=ts, text=content.strip(),
                meta={"uuid": uuid} if uuid else {},
            ))
            return

        if not isinstance(content, list):
            return

        for block in content:
            if not isinstance(block, dict):
                continue
            block_type = block.get("type", "")

            if block_type == "text":
                text = block.get("text", "").strip()
                if text:
                    events.append(AssistantTextEvent(
                        ts=ts, text=text,
                        meta={"uuid": uuid} if uuid else {},
                    ))

            elif block_type == "thinking":
                text = block.get("thinking", "") or block.get("text", "")
                events.append(ThinkingEvent(
                    ts=ts, text=_truncate(str(text)),
                ))

            elif block_type == "tool_use":
                tool_event = self._make_tool_event(block, ts, uuid)
                if tool_event:
                    tool_id = block.get("id", "")
                    if tool_id:
                        pending_tools[tool_id] = tool_event
                    events.append(tool_event)

    def _handle_snapshot(self, entry: dict, ts: datetime, events: list) -> None:
        snapshot = entry.get("snapshot", {})
        backups = snapshot.get("trackedFileBackups", {})
        if backups:
            events.append(FileSnapshotEvent(
                ts=ts or datetime.now(timezone.utc),
                paths=list(backups.keys()),
            ))

    def _make_tool_event(self, block: dict, ts: datetime, uuid: str | None) -> Any:
        name = block.get("name", "")
        inp = block.get("input", {})
        tool_id = block.get("id", "")
        base_meta = {"tool_use_id": tool_id}
        if uuid:
            base_meta["uuid"] = uuid

        if name == "Bash":
            return ShellCommandEvent(
                ts=ts,
                command=inp.get("command", ""),
                meta=base_meta,
            )
        elif name == "Read":
            lines = None
            if inp.get("offset") or inp.get("limit"):
                offset = inp.get("offset", 1)
                limit = inp.get("limit")
                lines = f"{offset}-{offset + limit - 1}" if limit else f"{offset}-"
            return FileReadEvent(
                ts=ts,
                path=inp.get("file_path", ""),
                lines=lines,
                meta=base_meta,
            )
        elif name == "Edit":
            old = inp.get("old_string", "")
            new = inp.get("new_string", "")
            diff = None
            if old or new:
                diff = f"-{_truncate(old, 200)}\n+{_truncate(new, 200)}"
            return FileEditEvent(
                ts=ts,
                path=inp.get("file_path", ""),
                diff=diff,
                meta=base_meta,
            )
        elif name == "Write":
            content = inp.get("content", "")
            return FileWriteEvent(
                ts=ts,
                path=inp.get("file_path", ""),
                content_preview=_truncate(content),
                meta=base_meta,
            )
        elif name in ("Grep", "Glob", "WebSearch", "WebFetch"):
            query = inp.get("pattern", "") or inp.get("query", "") or inp.get("url", "")
            return CodeSearchEvent(
                ts=ts,
                tool_name=name,
                query=query,
                meta=base_meta,
            )
        elif name == "Agent":
            return AssistantTextEvent(
                ts=ts,
                text=f"[Delegated to {inp.get('subagent_type', 'agent')}: {inp.get('description', '')}]",
                meta={**base_meta, "agent_delegation": True},
            )
        return None

    def _enrich_tool_event(
        self, pending_tools: dict, tool_use_id: str, content: str, tool_result: dict,
    ) -> None:
        event = pending_tools.pop(tool_use_id, None)
        if event is None:
            return

        preview = _truncate(content)

        if isinstance(event, ShellCommandEvent):
            event.output_preview = preview
            # Try to extract exit code from toolUseResult
            if isinstance(tool_result, dict):
                stderr = tool_result.get("stderr", "")
                if stderr:
                    event.meta["stderr"] = _truncate(stderr, 200)
        elif isinstance(event, FileReadEvent):
            event.content_preview = preview
            if isinstance(tool_result, dict) and "file" in tool_result:
                f = tool_result["file"]
                event.lines = f"{f.get('startLine', 1)}-{f.get('startLine', 1) + f.get('numLines', 0) - 1}"
        elif isinstance(event, CodeSearchEvent):
            event.result_preview = preview
            # Count matches heuristically
            if content:
                event.result_count = content.count("\n") + 1

    def _parse_subagents(self, transcript_path: Path) -> list[CanonicalTranscript]:
        subagent_dir = transcript_path.parent / transcript_path.stem / "subagents"
        if not subagent_dir.exists():
            return []

        results = []
        for jsonl in sorted(subagent_dir.glob("*.jsonl")):
            sub = self.parse(jsonl)
            # Enrich with meta.json if present
            meta_path = jsonl.with_suffix(".meta.json")
            if meta_path.exists():
                try:
                    meta = json.loads(meta_path.read_text(encoding="utf-8"))
                    sub.session.meta = {  # type: ignore[attr-defined]
                        "agent_type": meta.get("agentType"),
                        "description": meta.get("description"),
                    }
                except (json.JSONDecodeError, OSError):
                    pass
            results.append(sub)
        return results


# ── Helpers ──────────────────────────────────────────────────────

def _parse_message(entry: dict) -> dict | None:
    msg = entry.get("message")
    if msg is None:
        return None
    if isinstance(msg, str):
        try:
            return json.loads(msg)
        except json.JSONDecodeError:
            return None
    return msg


def _parse_ts(raw: Any) -> datetime:
    if raw is None:
        return datetime.now(timezone.utc)
    if isinstance(raw, (int, float)):
        return datetime.fromtimestamp(raw / 1000, tz=timezone.utc)
    if isinstance(raw, str):
        try:
            return datetime.fromisoformat(raw)
        except ValueError:
            pass
    return datetime.now(timezone.utc)


def _truncate(text: str, limit: int = _PREVIEW_LIMIT) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + "..."
