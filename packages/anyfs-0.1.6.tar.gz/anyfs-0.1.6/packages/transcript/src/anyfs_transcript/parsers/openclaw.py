from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from anyfs_schemas import (
    AssistantTextEvent,
    CanonicalTranscript,
    CodeSearchEvent,
    ErrorEvent,
    FileEditEvent,
    FileReadEvent,
    FileWriteEvent,
    ShellCommandEvent,
    ThinkingEvent,
    TranscriptSessionMeta,
    UserMessageEvent,
)

_PREVIEW_LIMIT = 500


class OpenClawParser:
    agent_type = "openclaw"

    def can_parse(self, path: Path) -> bool:
        if not path.is_file() or path.suffix != ".jsonl":
            return False
        try:
            first_line = path.read_text(encoding="utf-8").split("\n", 1)[0]
            entry = json.loads(first_line)
        except (OSError, json.JSONDecodeError):
            return False
        return entry.get("type") == "session" and "cwd" in entry

    def parse(self, path: Path) -> CanonicalTranscript:
        entries: list[dict[str, Any]] = []
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                continue

        session = self._extract_session(entries, path)
        events = self._extract_events(entries)
        return CanonicalTranscript(session=session, events=events)

    def _extract_session(self, entries: list[dict[str, Any]], path: Path) -> TranscriptSessionMeta:
        session_id = path.stem
        cwd = None
        started_at = datetime.now(timezone.utc)
        ended_at = None
        model = None

        if entries:
            header = entries[0]
            session_id = header.get("id", session_id)
            cwd = header.get("cwd")
            started_at = _parse_ts(header.get("timestamp"))

        for entry in entries:
            if entry.get("type") != "message":
                continue
            ended_at = _parse_ts(entry.get("timestamp"))
            message = entry.get("message", {})
            if message.get("role") != "assistant":
                continue
            model = message.get("model") or model
            if model:
                break

        return TranscriptSessionMeta(
            id=session_id,
            agent="openclaw",
            model=model,
            cwd=cwd,
            started_at=started_at,
            ended_at=ended_at,
        )

    def _extract_events(self, entries: list[dict[str, Any]]) -> list[Any]:
        events: list[Any] = []
        for entry in entries:
            if entry.get("type") != "message":
                continue

            message = entry.get("message", {})
            role = message.get("role", "")
            ts = _parse_ts(entry.get("timestamp") or message.get("timestamp"))
            content = message.get("content", [])

            for block in content:
                if not isinstance(block, dict):
                    continue
                if block.get("type") != "text":
                    continue
                text = str(block.get("text", "")).strip()
                if not text:
                    continue

                if role == "user":
                    events.append(UserMessageEvent(ts=ts, text=text))
                    continue

                events.extend(_parse_assistant_block(text, ts))

        return events


def _parse_assistant_block(text: str, ts: datetime) -> list[Any]:
    if any(marker in text for marker in ("[Thinking]", "[Tool:", "[Error]")) and "\n\n" in text:
        events: list[Any] = []
        for chunk in (part.strip() for part in text.split("\n\n")):
            if not chunk:
                continue
            events.extend(_parse_assistant_block(chunk, ts))
        return events

    if text.startswith("[Thinking]\n"):
        return [ThinkingEvent(ts=ts, text=text.removeprefix("[Thinking]\n").strip())]
    if text.startswith("[Error] "):
        return [ErrorEvent(ts=ts, message=text.removeprefix("[Error] ").strip())]

    if not text.startswith("[Tool:"):
        return [AssistantTextEvent(ts=ts, text=text)]
    lines = [line for line in text.splitlines() if line.strip()]
    first_line = lines[0] if lines else text
    tool_tag, _, tool_remainder = first_line.partition("]")
    tool_name = tool_tag.removeprefix("[Tool:").strip().lower()
    remainder = tool_remainder.strip()
    body = "\n".join(lines[1:]).strip() or None

    if tool_name == "shell":
        command = first_line.split("]", 1)[-1].strip()
        return [ShellCommandEvent(ts=ts, command=command or remainder, output_preview=_truncate(body) if body else None)]
    if tool_name == "read_file":
        path = first_line.split("]", 1)[-1].strip()
        return [FileReadEvent(ts=ts, path=path, content_preview=_truncate(body) if body else None)]
    if tool_name == "edit_file":
        path = first_line.split("]", 1)[-1].strip()
        return [FileEditEvent(ts=ts, path=path, diff=_truncate(body) if body else None)]
    if tool_name == "write_file":
        path = first_line.split("]", 1)[-1].strip()
        return [FileWriteEvent(ts=ts, path=path, content_preview=_truncate(body) if body else None)]
    if tool_name == "search":
        query = first_line.split("]", 1)[-1].strip()
        return [CodeSearchEvent(ts=ts, tool_name="search", query=query, result_preview=_truncate(body) if body else None)]

    return [AssistantTextEvent(ts=ts, text=text, meta={"tool_name": tool_name})]


def _parse_ts(raw: Any) -> datetime:
    if raw is None:
        return datetime.now(timezone.utc)
    if isinstance(raw, str):
        try:
            return datetime.fromisoformat(raw)
        except ValueError:
            pass
    if isinstance(raw, (int, float)):
        return datetime.fromtimestamp(raw / 1000, tz=timezone.utc)
    return datetime.now(timezone.utc)


def _truncate(text: str | None, limit: int = _PREVIEW_LIMIT) -> str | None:
    if text is None:
        return None
    if len(text) <= limit:
        return text
    return text[:limit] + "..."
