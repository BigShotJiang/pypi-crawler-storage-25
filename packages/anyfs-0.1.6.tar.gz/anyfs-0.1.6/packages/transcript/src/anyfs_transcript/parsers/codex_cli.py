from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from anyfs_schemas import (
    AssistantTextEvent,
    CanonicalTranscript,
    CodeSearchEvent,
    ErrorEvent,
    FileEditEvent,
    FileReadEvent,
    FileWriteEvent,
    ShellCommandEvent,
    ThinkingEvent,
    TranscriptSessionMeta,
    UserMessageEvent,
)

_PREVIEW_LIMIT = 500


class CodexCLIParser:
    agent_type = "codex-cli"

    def can_parse(self, path: Path) -> bool:
        if not path.is_file() or path.suffix != ".jsonl":
            return False
        # Peek at first line to check for Codex-style entries
        try:
            first_line = path.read_text(encoding="utf-8").split("\n", 1)[0]
            entry = json.loads(first_line)
            return entry.get("type") in (
                "session_meta", "response_item", "function_call",
                "function_call_output", "token_count", "reasoning",
            )
        except (json.JSONDecodeError, OSError, KeyError):
            return False

    def parse(self, path: Path) -> CanonicalTranscript:
        entries = []
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                continue

        session = self._extract_session(entries, path)
        events = self._extract_events(entries)
        return CanonicalTranscript(session=session, events=events)

    def _extract_session(self, entries: list[dict], path: Path) -> TranscriptSessionMeta:
        session_id = path.stem
        cwd = None
        model = None
        started_at = datetime.now(timezone.utc)

        for entry in entries:
            if entry.get("type") == "session_meta":
                payload = entry.get("payload", {})
                session_id = payload.get("id", session_id)
                cwd = payload.get("cwd")
                model = payload.get("model_provider")
                ts = entry.get("timestamp")
                if ts:
                    try:
                        started_at = datetime.fromisoformat(ts)
                    except (ValueError, TypeError):
                        pass
                break

        return TranscriptSessionMeta(
            id=session_id,
            agent="codex-cli",
            model=model,
            cwd=cwd,
            started_at=started_at,
        )

    def _extract_events(self, entries: list[dict]) -> list:
        events: list = []
        # Track pending function calls for enrichment
        pending_calls: dict[str, Any] = {}

        for entry in entries:
            entry_type = entry.get("type", "")
            ts = _parse_ts(entry.get("timestamp"))
            payload = entry.get("payload", {})

            if entry_type == "response_item":
                self._handle_response_item(payload, ts, events)
            elif entry_type == "event_msg":
                self._handle_event_msg(payload, ts, events)
            elif entry_type == "function_call":
                self._handle_function_call(payload, ts, events, pending_calls)
            elif entry_type == "function_call_output":
                self._handle_function_output(payload, ts, events, pending_calls)
            elif entry_type == "reasoning":
                text = payload.get("text", "") or payload.get("content", "") or str(payload)
                events.append(ThinkingEvent(ts=ts, text=_truncate(str(text))))
            elif entry_type == "input_text":
                text = payload.get("text", "") or str(payload)
                if isinstance(text, str) and text.strip():
                    events.append(UserMessageEvent(ts=ts, text=text.strip()))

        return events

    def _handle_response_item(self, payload: dict, ts: datetime, events: list) -> None:
        role = payload.get("role", "")
        content = payload.get("content", "")

        if isinstance(content, list):
            for block in content:
                if not isinstance(block, dict):
                    continue
                block_type = block.get("type", "")
                text = block.get("text", "").strip()
                if not text:
                    continue

                if block_type in ("input_text",):
                    # Skip system instructions / environment context
                    if text.startswith("<environment_context>") or text.startswith("# AGENTS.md"):
                        continue
                    if role in ("user", "developer"):
                        events.append(UserMessageEvent(ts=ts, text=text))
                elif block_type in ("output_text", "text"):
                    events.append(AssistantTextEvent(ts=ts, text=text))
            return

        if isinstance(content, str) and content.strip():
            if role in ("user", "developer"):
                events.append(UserMessageEvent(ts=ts, text=content.strip()))
            elif role == "assistant":
                events.append(AssistantTextEvent(ts=ts, text=content.strip()))

    def _handle_event_msg(self, payload: dict, ts: datetime, events: list) -> None:
        if not isinstance(payload, dict):
            return
        msg_type = payload.get("type", "")
        if msg_type == "text":
            text = payload.get("text", "").strip()
            if text:
                events.append(AssistantTextEvent(ts=ts, text=text))
        elif msg_type == "command":
            cmd = payload.get("command", "") or payload.get("message", "")
            if cmd:
                events.append(ShellCommandEvent(ts=ts, command=str(cmd)))

    def _handle_function_call(self, payload: dict, ts: datetime, events: list, pending_calls: dict) -> None:
        name = payload.get("name", "")
        args = payload.get("arguments", {})
        call_id = payload.get("id", "") or payload.get("call_id", "")

        if isinstance(args, str):
            try:
                args = json.loads(args)
            except json.JSONDecodeError:
                args = {"raw": args}

        event = _make_tool_event(name, args, ts)
        if event:
            if call_id:
                pending_calls[call_id] = event
            events.append(event)

    def _handle_function_output(self, payload: dict, ts: datetime, events: list, pending_calls: dict) -> None:
        call_id = payload.get("call_id", "") or payload.get("id", "")
        output = payload.get("output", "")
        if isinstance(output, dict):
            output = json.dumps(output, default=str)

        event = pending_calls.pop(call_id, None)
        if event is None:
            return

        preview = _truncate(str(output))
        if isinstance(event, ShellCommandEvent):
            event.output_preview = preview
        elif isinstance(event, FileReadEvent):
            event.content_preview = preview
        elif isinstance(event, CodeSearchEvent):
            event.result_preview = preview


def _make_tool_event(name: str, args: dict, ts: datetime) -> Any:
    name_lower = name.lower()

    if any(k in name_lower for k in ("shell", "bash", "exec", "command", "run")):
        return ShellCommandEvent(
            ts=ts,
            command=args.get("command", "") or args.get("cmd", "") or str(args),
        )
    elif any(k in name_lower for k in ("read", "cat", "view")):
        return FileReadEvent(
            ts=ts,
            path=args.get("path", "") or args.get("file_path", "") or args.get("file", ""),
        )
    elif any(k in name_lower for k in ("edit", "patch", "modify")):
        return FileEditEvent(
            ts=ts,
            path=args.get("path", "") or args.get("file_path", "") or args.get("file", ""),
        )
    elif any(k in name_lower for k in ("write", "create")):
        return FileWriteEvent(
            ts=ts,
            path=args.get("path", "") or args.get("file_path", "") or args.get("file", ""),
        )
    elif any(k in name_lower for k in ("search", "grep", "find", "glob")):
        return CodeSearchEvent(
            ts=ts,
            tool_name=name,
            query=args.get("query", "") or args.get("pattern", "") or str(args),
        )

    # Fallback: represent as assistant text
    return AssistantTextEvent(
        ts=ts,
        text=f"[Tool: {name}] {json.dumps(args, default=str)[:200]}",
        meta={"tool_name": name, "args": args},
    )


def _parse_ts(raw: Any) -> datetime:
    if raw is None:
        return datetime.now(timezone.utc)
    if isinstance(raw, str):
        try:
            return datetime.fromisoformat(raw)
        except ValueError:
            pass
    if isinstance(raw, (int, float)):
        return datetime.fromtimestamp(raw / 1000, tz=timezone.utc)
    return datetime.now(timezone.utc)


def _truncate(text: str, limit: int = _PREVIEW_LIMIT) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + "..."
