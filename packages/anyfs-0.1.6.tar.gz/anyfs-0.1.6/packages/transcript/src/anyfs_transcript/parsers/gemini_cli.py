from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from anyfs_schemas import (
    AssistantTextEvent,
    CanonicalTranscript,
    CodeSearchEvent,
    ErrorEvent,
    FileEditEvent,
    FileReadEvent,
    FileWriteEvent,
    ShellCommandEvent,
    ThinkingEvent,
    TranscriptSessionMeta,
    UserMessageEvent,
)

_PREVIEW_LIMIT = 500

# Gemini tool name → canonical kind mapping
_TOOL_MAP: dict[str, str] = {
    "read_file": "file_read",
    "readFile": "file_read",
    "edit_file": "file_edit",
    "editFile": "file_edit",
    "write_file": "file_write",
    "writeFile": "file_write",
    "run_command": "shell_command",
    "runCommand": "shell_command",
    "shell": "shell_command",
    "search": "code_search",
    "grep": "code_search",
    "glob": "code_search",
    "find_files": "code_search",
    "findFiles": "code_search",
    "web_search": "code_search",
}


class GeminiCLIParser:
    agent_type = "gemini-cli"

    def can_parse(self, path: Path) -> bool:
        if not path.is_file():
            return False
        if path.suffix != ".json":
            return False
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return (
                isinstance(data, dict)
                and isinstance(data.get("messages"), list)
                and (
                    "sessionId" in data
                    or "projectHash" in data
                    or data.get("kind") == "main"
                )
            )
        except (json.JSONDecodeError, OSError):
            return False

    def parse(self, path: Path) -> CanonicalTranscript:
        data = json.loads(path.read_text(encoding="utf-8"))
        session = self._extract_session(data, path)
        events = self._extract_events(data.get("messages", []))
        return CanonicalTranscript(session=session, events=events)

    def _extract_session(self, data: dict, path: Path) -> TranscriptSessionMeta:
        started_at = datetime.now(timezone.utc)
        if data.get("startTime"):
            try:
                started_at = datetime.fromisoformat(data["startTime"])
            except (ValueError, TypeError):
                pass

        ended_at = None
        if data.get("lastUpdated"):
            try:
                ended_at = datetime.fromisoformat(data["lastUpdated"])
            except (ValueError, TypeError):
                pass

        model = None
        for msg in data.get("messages", []):
            if msg.get("model"):
                model = msg["model"]
                break

        return TranscriptSessionMeta(
            id=data.get("sessionId", path.stem),
            agent="gemini-cli",
            model=model,
            started_at=started_at,
            ended_at=ended_at,
        )

    def _extract_events(self, messages: list[dict]) -> list:
        events: list = []
        for msg in messages:
            ts = _parse_ts(msg.get("timestamp"))
            msg_type = msg.get("type", "")

            if msg_type == "user":
                text = _extract_text(msg.get("content"))
                if text:
                    events.append(UserMessageEvent(ts=ts, text=text))

            elif msg_type in ("gemini", "model", "assistant"):
                # Text content
                text = _extract_text(msg.get("content"))
                if text:
                    events.append(AssistantTextEvent(ts=ts, text=text))

                # Thoughts
                for thought in msg.get("thoughts", []):
                    subject = thought.get("subject", "")
                    desc = thought.get("description", "")
                    events.append(ThinkingEvent(
                        ts=_parse_ts(thought.get("timestamp")) or ts,
                        text=f"{subject}: {desc}" if subject else desc,
                    ))

                # Tool calls (inline in Gemini format)
                for tc in msg.get("toolCalls", []):
                    tool_event = self._make_tool_event(tc, ts)
                    if tool_event:
                        events.append(tool_event)

        return events

    def _make_tool_event(self, tc: dict, ts: datetime) -> Any:
        name = tc.get("name", "")
        args = tc.get("args", {})
        result = tc.get("result", "")
        status = tc.get("status", "")
        tc_ts = _parse_ts(tc.get("timestamp")) or ts

        if isinstance(result, list):
            result = "\n".join(str(r) for r in result)
        elif not isinstance(result, str):
            result = json.dumps(result, default=str)

        kind = _TOOL_MAP.get(name, "")
        preview = _truncate(str(result))

        if status == "error":
            return ErrorEvent(ts=tc_ts, message=preview, meta={"tool_name": name})

        if kind == "shell_command":
            return ShellCommandEvent(
                ts=tc_ts,
                command=args.get("command", "") or args.get("cmd", "") or str(args),
                output_preview=preview,
                meta={"tool_call_id": tc.get("id")},
            )
        elif kind == "file_read":
            return FileReadEvent(
                ts=tc_ts,
                path=args.get("path", "") or args.get("file_path", "") or args.get("filePath", ""),
                content_preview=preview,
            )
        elif kind == "file_edit":
            return FileEditEvent(
                ts=tc_ts,
                path=args.get("path", "") or args.get("file_path", "") or args.get("filePath", ""),
                diff=preview,
            )
        elif kind == "file_write":
            return FileWriteEvent(
                ts=tc_ts,
                path=args.get("path", "") or args.get("file_path", "") or args.get("filePath", ""),
                content_preview=preview,
            )
        elif kind == "code_search":
            return CodeSearchEvent(
                ts=tc_ts,
                tool_name=name,
                query=args.get("query", "") or args.get("pattern", "") or str(args),
                result_preview=preview,
            )

        # Unknown tool → assistant text
        return AssistantTextEvent(
            ts=tc_ts,
            text=f"[Tool: {name}] {preview}",
            meta={"tool_name": name, "args": args},
        )


def _extract_text(content: Any) -> str:
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        parts = []
        for item in content:
            if isinstance(item, dict):
                parts.append(item.get("text", ""))
            elif isinstance(item, str):
                parts.append(item)
        return "\n".join(p for p in parts if p).strip()
    return ""


def _parse_ts(raw: Any) -> datetime:
    if raw is None:
        return datetime.now(timezone.utc)
    if isinstance(raw, str):
        try:
            return datetime.fromisoformat(raw)
        except ValueError:
            pass
    if isinstance(raw, (int, float)):
        return datetime.fromtimestamp(raw / 1000, tz=timezone.utc)
    return datetime.now(timezone.utc)


def _truncate(text: str, limit: int = _PREVIEW_LIMIT) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + "..."
