from __future__ import annotations

from pathlib import Path
from typing import Protocol

from anyfs_schemas import CanonicalTranscript


class TranscriptParser(Protocol):
    """Protocol for client-specific transcript parsers."""

    agent_type: str

    def can_parse(self, path: Path) -> bool:
        """Return True if this parser can handle the file at the given path."""
        ...

    def parse(self, path: Path) -> CanonicalTranscript:
        """Parse a raw transcript file into canonical form."""
        ...
