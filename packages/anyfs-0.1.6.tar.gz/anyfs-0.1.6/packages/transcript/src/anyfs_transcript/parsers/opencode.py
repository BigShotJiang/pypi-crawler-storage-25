from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from anyfs_schemas import (
    AssistantTextEvent,
    CanonicalTranscript,
    CodeSearchEvent,
    ErrorEvent,
    FileEditEvent,
    FileReadEvent,
    FileWriteEvent,
    ShellCommandEvent,
    ThinkingEvent,
    TranscriptSessionMeta,
    UserMessageEvent,
)

_PREVIEW_LIMIT = 500
_EXIT_CODE_RE = re.compile(r"(\d+)")


class OpenCodeParser:
    agent_type = "opencode"

    def can_parse(self, path: Path) -> bool:
        if not path.is_file() or path.suffix != ".json":
            return False
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return False
        return (
            isinstance(data, dict)
            and isinstance(data.get("info"), dict)
            and isinstance(data.get("messages"), list)
            and "id" in data["info"]
        )

    def parse(self, path: Path) -> CanonicalTranscript:
        data = json.loads(path.read_text(encoding="utf-8"))
        session = self._extract_session(data, path)
        events = self._extract_events(data.get("messages", []))
        return CanonicalTranscript(session=session, events=events)

    def _extract_session(self, data: dict[str, Any], path: Path) -> TranscriptSessionMeta:
        info = data.get("info", {})
        time_info = info.get("time", {})
        created = _parse_ts_ms(time_info.get("created"))
        updated = _parse_ts_ms(time_info.get("updated"))
        model = None

        for message in data.get("messages", []):
            message_info = message.get("info", {})
            role = message_info.get("role")
            if role == "assistant":
                provider_id = message_info.get("providerID")
                model_id = message_info.get("modelID")
                if provider_id and model_id:
                    model = f"{provider_id}/{model_id}"
                    break
            model_info = message_info.get("model")
            if isinstance(model_info, dict):
                provider_id = model_info.get("providerID")
                model_id = model_info.get("modelID")
                if provider_id and model_id:
                    model = f"{provider_id}/{model_id}"
                    break

        return TranscriptSessionMeta(
            id=info.get("id", path.stem),
            agent="opencode",
            model=model,
            cwd=info.get("directory"),
            started_at=created,
            ended_at=updated,
            version=info.get("version"),
        )

    def _extract_events(self, messages: list[dict[str, Any]]) -> list[Any]:
        events: list[Any] = []
        for message in messages:
            info = message.get("info", {})
            role = info.get("role", "")
            ts = _parse_ts_ms(info.get("time", {}).get("created"))
            parts = message.get("parts", [])

            for part in parts:
                if not isinstance(part, dict):
                    continue
                part_type = part.get("type")
                if role == "user":
                    if part_type == "text":
                        text = str(part.get("text", "")).strip()
                        if text:
                            events.append(UserMessageEvent(ts=ts, text=text, meta={"synthetic": bool(part.get("synthetic"))}))
                    continue

                events.extend(_parse_assistant_part(part, ts))

        return events


def _parse_assistant_part(part: dict[str, Any], ts: datetime) -> list[Any]:
    part_type = part.get("type", "")
    if part_type == "text":
        text = str(part.get("text", "")).strip()
        return [AssistantTextEvent(ts=ts, text=text, meta={"synthetic": bool(part.get("synthetic"))})] if text else []
    if part_type == "reasoning":
        text = str(part.get("text", "")).strip()
        return [ThinkingEvent(ts=ts, text=text)] if text else []
    if part_type != "tool":
        return []

    tool = str(part.get("tool", "")).strip().lower()
    state = part.get("state", {})
    status = state.get("status")
    input_payload = state.get("input", {}) if isinstance(state.get("input"), dict) else {}
    output = state.get("output", "")
    error = state.get("error")
    output_text = _stringify(output)

    if status == "error":
        message = str(error or f"{tool} failed").strip()
        if tool == "bash":
            command = input_payload.get("command", "") or str(input_payload)
            exit_code = _parse_exit_code(message)
            return [ShellCommandEvent(ts=ts, command=command, exit_code=exit_code, output_preview=message)]
        return [ErrorEvent(ts=ts, message=message, meta={"tool": tool, "input": input_payload})]

    if tool == "bash":
        command = input_payload.get("command", "") or str(input_payload)
        return [ShellCommandEvent(ts=ts, command=command, output_preview=_truncate(output_text))]
    if tool == "read":
        return [FileReadEvent(ts=ts, path=_path_from_input(input_payload), content_preview=_truncate(output_text))]
    if tool == "edit":
        diff = input_payload.get("diff") or output_text
        return [FileEditEvent(ts=ts, path=_path_from_input(input_payload), diff=_truncate(str(diff)))]
    if tool == "write":
        return [FileWriteEvent(ts=ts, path=_path_from_input(input_payload), content_preview=_truncate(output_text))]
    if tool == "codesearch":
        query = input_payload.get("query", "") or str(input_payload)
        return [CodeSearchEvent(ts=ts, tool_name="codesearch", query=query, result_preview=_truncate(output_text))]

    summary = json.dumps({"tool": tool, "input": input_payload, "output": output}, ensure_ascii=False, default=str)
    return [AssistantTextEvent(ts=ts, text=f"[Tool: {tool}] {summary}")]


def _path_from_input(input_payload: dict[str, Any]) -> str:
    return str(
        input_payload.get("filePath")
        or input_payload.get("path")
        or input_payload.get("file")
        or ""
    )


def _stringify(value: Any) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        return "\n".join(_stringify(item) for item in value)
    return json.dumps(value, ensure_ascii=False, default=str)


def _parse_exit_code(message: str) -> int | None:
    match = _EXIT_CODE_RE.search(message)
    if not match:
        return None
    return int(match.group(1))


def _parse_ts_ms(raw: Any) -> datetime:
    if isinstance(raw, datetime):
        return raw
    if isinstance(raw, (int, float)):
        return datetime.fromtimestamp(raw / 1000, tz=timezone.utc)
    return datetime.now(timezone.utc)


def _truncate(text: str, limit: int = _PREVIEW_LIMIT) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + "..."
