from __future__ import annotations

from anyfs_schemas import (
    AssistantTextEvent,
    CanonicalTranscript,
    CodeSearchEvent,
    ErrorEvent,
    FileEditEvent,
    FileReadEvent,
    FileSnapshotEvent,
    FileWriteEvent,
    ShellCommandEvent,
    ThinkingEvent,
    UserMessageEvent,
)


def render_markdown(transcript: CanonicalTranscript) -> str:
    """Render a canonical transcript as human-readable markdown."""
    parts: list[str] = []

    # Header
    s = transcript.session
    header = f"# Session: {s.id}\n"
    meta_parts = []
    if s.agent:
        meta_parts.append(f"Agent: {s.agent}")
    if s.model:
        meta_parts.append(f"Model: {s.model}")
    if s.git_branch:
        meta_parts.append(f"Branch: {s.git_branch}")
    if meta_parts:
        header += " | ".join(meta_parts) + "\n"
    parts.append(header)

    # Events
    for event in transcript.events:
        rendered = _render_event(event)
        if rendered:
            parts.append(rendered)

    # Subagents
    for sub in transcript.subagents:
        desc = ""
        if hasattr(sub.session, "meta") and isinstance(sub.session.meta, dict):
            desc = sub.session.meta.get("description", "")
        parts.append(f"\n---\n### Sub-agent: {sub.session.agent} {desc}\n")
        parts.append(render_markdown(sub))

    return "\n".join(parts)


def _render_event(event) -> str | None:
    if isinstance(event, UserMessageEvent):
        return f"\n## User\n{event.text}"

    if isinstance(event, AssistantTextEvent):
        if event.meta.get("agent_delegation"):
            return f"\n> {event.text}"
        return f"\n## Assistant\n{event.text}"

    if isinstance(event, ThinkingEvent):
        if event.text:
            return f"\n> *Thinking: {event.text[:200]}{'...' if len(event.text) > 200 else ''}*"
        return None

    if isinstance(event, FileReadEvent):
        lines = f" (lines {event.lines})" if event.lines else ""
        return f"\n### Read `{event.path}`{lines}"

    if isinstance(event, FileEditEvent):
        diff_block = ""
        if event.diff:
            diff_block = f"\n```diff\n{event.diff}\n```"
        return f"\n### Edit `{event.path}`{diff_block}"

    if isinstance(event, FileWriteEvent):
        return f"\n### Write `{event.path}`"

    if isinstance(event, ShellCommandEvent):
        result = f"\n### Shell: `{event.command}`"
        if event.exit_code is not None:
            result += f" (exit {event.exit_code})"
        if event.output_preview:
            result += f"\n```\n{event.output_preview}\n```"
        return result

    if isinstance(event, CodeSearchEvent):
        count = f" ({event.result_count} matches)" if event.result_count else ""
        return f"\n### {event.tool_name}: `{event.query}`{count}"

    if isinstance(event, ErrorEvent):
        return f"\n### Error\n{event.message}"

    if isinstance(event, FileSnapshotEvent):
        return None  # Usually not interesting for human readers

    return None
