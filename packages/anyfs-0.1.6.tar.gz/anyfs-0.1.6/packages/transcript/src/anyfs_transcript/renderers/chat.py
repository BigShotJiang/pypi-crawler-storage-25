from __future__ import annotations

from anyfs_schemas import (
    AssistantTextEvent,
    CanonicalTranscript,
    CodeSearchEvent,
    FileEditEvent,
    FileReadEvent,
    FileWriteEvent,
    ShellCommandEvent,
    UserMessageEvent,
)


def render_chat(transcript: CanonicalTranscript) -> list[dict[str, str]]:
    """Render a canonical transcript as a simplified chat message list.

    Returns a list of {"role": "user"|"assistant", "content": "..."} dicts,
    suitable for feeding into another LLM or chat UI.
    """
    messages: list[dict[str, str]] = []
    current_assistant_parts: list[str] = []

    def flush_assistant() -> None:
        if current_assistant_parts:
            messages.append({
                "role": "assistant",
                "content": "\n".join(current_assistant_parts),
            })
            current_assistant_parts.clear()

    for event in transcript.events:
        if isinstance(event, UserMessageEvent):
            flush_assistant()
            messages.append({"role": "user", "content": event.text})

        elif isinstance(event, AssistantTextEvent):
            current_assistant_parts.append(event.text)

        elif isinstance(event, FileReadEvent):
            current_assistant_parts.append(f"[Read {event.path}]")

        elif isinstance(event, FileEditEvent):
            current_assistant_parts.append(f"[Edited {event.path}]")

        elif isinstance(event, FileWriteEvent):
            current_assistant_parts.append(f"[Created {event.path}]")

        elif isinstance(event, ShellCommandEvent):
            line = f"[Ran: {event.command}]"
            if event.exit_code is not None and event.exit_code != 0:
                line += f" (failed, exit {event.exit_code})"
            current_assistant_parts.append(line)

        elif isinstance(event, CodeSearchEvent):
            current_assistant_parts.append(f"[Searched: {event.query}]")

    flush_assistant()
    return messages
