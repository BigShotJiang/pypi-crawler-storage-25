from __future__ import annotations

import json
import os
from pathlib import Path

from anyfs_adapters_core import AgentAdapter, append_unique, collect_text_files, read_text_file
from anyfs_schemas import AgentType, CaptureResult, CodeRef, Namespace, WorkspaceBinding, WorkspaceOverlay
from anyfs_transcript import parse_transcript, render_markdown

_DEFAULT_CODEX_HOME = ".codex"
_CODEX_EXCLUDED_CONTEXT_FILES = {"config.toml"}


def _codex_home() -> Path:
    return Path.home() / _DEFAULT_CODEX_HOME


def _session_matches_workspace(path: Path, workspace_path: Path) -> bool:
    try:
        first_line = path.read_text(encoding="utf-8").split("\n", 1)[0]
        payload = json.loads(first_line)
    except (OSError, json.JSONDecodeError):
        return False
    if payload.get("type") != "session_meta":
        return False
    meta = payload.get("payload", {})
    cwd = meta.get("cwd")
    return isinstance(cwd, str) and Path(cwd).resolve() == workspace_path


def _session_id(path: Path) -> str | None:
    try:
        first_line = path.read_text(encoding="utf-8").split("\n", 1)[0]
        payload = json.loads(first_line)
    except (OSError, json.JSONDecodeError):
        return None
    if payload.get("type") != "session_meta":
        return None
    meta = payload.get("payload", {})
    session_id = meta.get("id")
    return session_id if isinstance(session_id, str) and session_id else None


def _current_codex_session_id() -> str | None:
    for env_name in ("ANYFS_CODEX_SESSION_ID", "ANYFS_CURRENT_PROCESS_ID", "CODEX_THREAD_ID"):
        value = os.environ.get(env_name)
        if value:
            return value.strip()
    return None


def _codex_process_files(workspace_path: Path, process_scope: str = "current") -> list[Path]:
    sessions_root = _codex_home() / "sessions"
    if not sessions_root.exists():
        return []
    matches = [
        path
        for path in sessions_root.rglob("*.jsonl")
        if path.is_file() and _session_matches_workspace(path, workspace_path)
    ]
    if process_scope != "all":
        current_session_id = _current_codex_session_id()
        if current_session_id:
            exact_matches = [path for path in matches if _session_id(path) == current_session_id]
            if exact_matches:
                return exact_matches[:1]
    matches = sorted(matches, key=lambda item: item.stat().st_mtime, reverse=True)
    if process_scope == "all":
        return matches[:20]
    return matches[:1]


def _codex_skill_files(workspace_path: Path) -> list[Path]:
    codex_home = _codex_home()
    candidates: list[Path] = []
    append_unique(candidates, codex_home / "AGENTS.md")
    for root in (
        codex_home / "skills",
        codex_home / "plugins",
        codex_home / "prompts",
        codex_home / "rules",
        codex_home / "memories",
        workspace_path / ".codex",
    ):
        for path in collect_text_files(root, max_files=120, exclude_names=_CODEX_EXCLUDED_CONTEXT_FILES):
            append_unique(candidates, path)
    append_unique(candidates, workspace_path / "AGENTS.md")
    return candidates[:200]


class CodexCLIAdapter(AgentAdapter):
    agent_type = AgentType.CODEX_CLI

    def __init__(self, process_scope: str = "current") -> None:
        self.process_scope = process_scope if process_scope in {"current", "all"} else "current"

    def discover(self, workspace: str) -> list[Path]:
        workspace_path = Path(workspace).resolve()
        candidates: list[Path] = []
        for path in _codex_process_files(workspace_path, self.process_scope):
            append_unique(candidates, path)
        for path in _codex_skill_files(workspace_path):
            append_unique(candidates, path)
        return candidates[:200]

    def extract(self, workspace: str) -> list[dict]:
        workspace_path = Path(workspace).resolve()
        codex_home = _codex_home()
        records = []
        for path in self.discover(workspace):
            if path.suffix == ".jsonl" and "sessions" in path.parts:
                try:
                    canonical = parse_transcript(path, agent_type="codex-cli")
                    records.append(
                        {
                            "path": str(path),
                            "relative_path": f"process/codex/{path.relative_to(codex_home)}",
                            "namespace": "process",
                            "content": render_markdown(canonical),
                            "canonical_transcript": canonical.model_dump(mode="json"),
                        }
                    )
                    continue
                except Exception:
                    pass

            namespace = "skills"
            if codex_home / "memories" in path.parents:
                namespace = "memory"

            if path.is_relative_to(codex_home):
                relative = f"{namespace}/codex/global/{path.relative_to(codex_home)}"
            else:
                relative = str(path.relative_to(workspace_path))

            records.append(
                {
                    "path": str(path),
                    "relative_path": relative,
                    "namespace": namespace,
                    "content": read_text_file(path),
                }
            )
        return records

    def normalize(self, raw: list[dict]) -> dict[str, list[dict]]:
        normalized: dict[str, list[dict]] = {}
        for record in raw:
            normalized.setdefault(record["namespace"], []).append(record)
        return normalized

    def bundle(self, normalized: dict[str, list[dict]], policy: dict | None = None) -> CaptureResult:
        trajectory = {ns: items for ns, items in normalized.items() if ns != "artifacts"}
        components = [Namespace(ns) for ns in trajectory.keys()]
        return CaptureResult(
            agent_id="pending",
            agent_type=self.agent_type,
            workspace="",
            code_ref=CodeRef(),
            workspace_overlay=WorkspaceOverlay(mode="none", binding=WorkspaceBinding(cwd="")),
            trajectory=trajectory,
            artifacts=normalized.get("artifacts", []),
            trajectory_components=components,
            captured_namespaces=list(normalized.keys()),
            payloads=normalized,
            warnings=[] if normalized else ["no Codex CLI files were discovered"],
        )
