from __future__ import annotations

from pathlib import Path
from typing import Protocol

from anyfs_schemas import AgentType, CaptureResult, Namespace


class AgentAdapter(Protocol):
    agent_type: AgentType

    def discover(self, workspace: str) -> list[Path]:
        ...

    def extract(self, workspace: str) -> list[dict]:
        ...

    def normalize(self, raw: list[dict]) -> dict[str, list[dict]]:
        ...

    def bundle(self, normalized: dict[str, list[dict]], policy: dict | None = None) -> CaptureResult:
        ...


def classify_by_path(path: Path) -> Namespace:
    full_path = str(path).lower()
    name = path.name.lower()
    if "soul" in full_path:
        return Namespace.SOUL
    if "user" in full_path or "profile" in full_path:
        return Namespace.USER
    if "memory" in full_path or "session" in full_path:
        return Namespace.MEMORY
    if "skill" in full_path or "instruction" in full_path or "prompt" in full_path or name == "claude.md":
        return Namespace.SKILLS
    if "process" in full_path or "log" in full_path or "trace" in full_path:
        return Namespace.PROCESS
    return Namespace.ARTIFACTS


def read_text_file(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return path.read_text(encoding="utf-8", errors="replace")


_TEXT_SUFFIXES = {
    ".md",
    ".txt",
    ".json",
    ".jsonl",
    ".yaml",
    ".yml",
    ".toml",
    ".conf",
    ".cfg",
    ".ini",
    ".sh",
    ".py",
    ".js",
    ".ts",
}
_TEXT_NAMES = {
    "agents.md",
    "claude.md",
    "gemini.md",
    "tools.md",
    "bootstrap.md",
    "heartbeat.md",
    "identity.md",
    "user.md",
    "soul.md",
    "skill.md",
    "readme.md",
    "license.txt",
    "package.json",
    "plugin.json",
    ".app.json",
    ".project_root",
    "config.toml",
    "settings.json",
    ".claude.json",
    "openclaw.json",
    "opencode.json",
}
_IGNORED_DIR_NAMES = {
    ".git",
    "__pycache__",
    "node_modules",
    ".venv",
    "venv",
    "dist",
    "build",
    ".next",
    ".cache",
}


def append_unique(candidates: list[Path], path: Path) -> None:
    if path.is_file() and path not in candidates:
        candidates.append(path)


def is_text_state_file(path: Path) -> bool:
    name = path.name.lower()
    return path.suffix.lower() in _TEXT_SUFFIXES or name in _TEXT_NAMES


def collect_text_files(root: Path, *, max_files: int = 200, exclude_names: set[str] | None = None) -> list[Path]:
    if not root.exists():
        return []
    excluded = {name.lower() for name in (exclude_names or set())}
    candidates: list[Path] = []
    for path in sorted(root.rglob("*")):
        if any(part in _IGNORED_DIR_NAMES for part in path.parts):
            continue
        if path.is_file() and is_text_state_file(path) and path.name.lower() not in excluded:
            candidates.append(path)
            if len(candidates) >= max_files:
                break
    return candidates
