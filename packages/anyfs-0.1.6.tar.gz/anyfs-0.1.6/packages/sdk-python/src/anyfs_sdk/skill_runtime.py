from __future__ import annotations

from typing import Any

from anyfs_schemas import SkillAction

from .service import AnyFSService


def run_skill_action(action: str, payload: dict[str, Any], service: AnyFSService | None = None) -> dict[str, Any]:
    service = service or AnyFSService()
    if action == SkillAction.INIT.value:
        return service.init()
    if action == SkillAction.AUTH_LOGIN.value:
        return service.auth_login(payload["email"], payload["password"])
    if action == SkillAction.AGENT_CREATE_REMOTE.value:
        return service.agent_create_remote(payload["workspace"], payload.get("agent_type"))
    if action == SkillAction.AGENT_STATUS.value:
        return service.agent_status(payload["workspace"], payload.get("agent_type"))
    if action == SkillAction.AGENT_BIND.value:
        return service.agent_bind(payload["workspace"], payload["email"], payload["password"], payload.get("agent_type"))
    if action == SkillAction.REGISTER_AGENT.value:
        return service.register_agent(payload["agent_type"], payload["workspace"], payload.get("display_name"))
    if action == SkillAction.CAPTURE.value:
        return service.capture(payload["agent_type"], payload["workspace"])
    if action == SkillAction.SNAPSHOT_CREATE.value:
        return service.snapshot_create(payload["workspace"])
    if action == SkillAction.SNAPSHOT_LIST.value:
        return {"items": service.snapshot_list(payload["workspace"])}
    if action == SkillAction.RESTORE.value:
        return service.restore(payload["workspace"], payload.get("snapshot", "latest"))
    if action == SkillAction.BACKUP_CREATE.value:
        return service.backup_create(payload["workspace"], payload.get("snapshot", "latest"), payload.get("namespaces"))
    if action == SkillAction.SHARE_LINK.value:
        return service.share_memory(payload["workspace"], payload.get("snapshot", "latest"), payload.get("namespaces"))
    if action == SkillAction.PACK.value:
        return service.pack(payload["workspace"], payload["snapshot_id"], payload.get("output_path"))
    if action == SkillAction.PUBLISH.value:
        return service.publish(payload["workspace"], payload["archive_path"])
    if action == SkillAction.BUY.value:
        return service.buy(
            payload["workspace"],
            payload["package_id"],
            payload["child_display_name"],
            output_dir=payload.get("output_dir"),
            resume_target=payload.get("resume_target"),
        )
    if action == SkillAction.RELEASE_CREATE.value:
        return service.release_create(payload["workspace"], payload["package_id"], payload["version"])
    if action == SkillAction.FORK.value:
        return service.fork(payload["workspace"], payload["package_id"], payload["child_display_name"])
    if action == SkillAction.LINEAGE_SHOW.value:
        return service.lineage_show(payload["workspace"], payload["package_id"])
    if action == SkillAction.MIGRATE.value:
        return service.migrate_context(
            payload["source_agent"],
            payload["target_agent"],
            payload["workspace"],
            target_workspace=payload.get("target_workspace"),
            overwrite=payload.get("overwrite", False),
            dry_run=payload.get("dry_run", False),
        )
    raise ValueError(f"unsupported skill action: {action}")
