from __future__ import annotations

import os
import json
from datetime import datetime
from pathlib import Path

from anyfs_adapters_core import AgentAdapter, append_unique, collect_text_files, read_text_file
from anyfs_schemas import AgentType, CaptureResult, CodeRef, Namespace, WorkspaceBinding, WorkspaceOverlay
from anyfs_transcript import parse_transcript, render_markdown

_DEFAULT_GEMINI_HOME = ".gemini"
_GEMINI_EXCLUDED_CONTEXT_FILES = {"projects.json"}


def _gemini_home() -> Path:
    cli_home = os.environ.get("GEMINI_CLI_HOME")
    if cli_home:
        return Path(cli_home).expanduser() / _DEFAULT_GEMINI_HOME
    legacy_home = os.environ.get("GEMINI_HOME")
    if legacy_home:
        return Path(legacy_home).expanduser()
    return Path.home() / _DEFAULT_GEMINI_HOME


def _project_matches_workspace(project_root_file: Path, workspace_path: Path) -> bool:
    try:
        project_root = project_root_file.read_text(encoding="utf-8").strip()
    except OSError:
        return False
    return bool(project_root) and Path(project_root).resolve() == workspace_path


def _current_gemini_session_id() -> str | None:
    for env_name in ("ANYFS_GEMINI_SESSION_ID", "ANYFS_CURRENT_PROCESS_ID"):
        value = os.environ.get(env_name)
        if value:
            return value.strip()
    return None


def _gemini_session_sort_key(path: Path) -> tuple[float, float]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        try:
            return (0.0, path.stat().st_mtime)
        except OSError:
            return (0.0, 0.0)

    for field in ("lastUpdated", "startTime"):
        raw = payload.get(field)
        if isinstance(raw, str):
            try:
                return (datetime.fromisoformat(raw.replace("Z", "+00:00")).timestamp(), path.stat().st_mtime)
            except ValueError:
                continue
    try:
        return (0.0, path.stat().st_mtime)
    except OSError:
        return (0.0, 0.0)


def _gemini_session_id(path: Path) -> str | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    session_id = payload.get("sessionId")
    return session_id if isinstance(session_id, str) and session_id else None


def _gemini_process_files(workspace_path: Path, process_scope: str = "current") -> list[Path]:
    tmp_root = _gemini_home() / "tmp"
    if not tmp_root.exists():
        return []
    matches: list[Path] = []
    for project_dir in sorted(tmp_root.iterdir()):
        if not project_dir.is_dir():
            continue
        marker = project_dir / ".project_root"
        if not marker.is_file() or not _project_matches_workspace(marker, workspace_path):
            continue
        chats_dir = project_dir / "chats"
        chats = sorted(chats_dir.glob("*.json"), key=_gemini_session_sort_key, reverse=True)
        if process_scope != "all":
            current_session_id = _current_gemini_session_id()
            if current_session_id:
                exact_matches = [
                    path
                    for path in chats
                    if _gemini_session_id(path) == current_session_id or current_session_id[:8] in path.name
                ]
                chats = exact_matches[:1] if exact_matches else chats[:1]
            else:
                chats = chats[:1]
        else:
            chats = chats[:20]
        for chat in chats:
            append_unique(matches, chat)
    return matches[:20] if process_scope == "all" else matches[:1]


def _gemini_skill_files(workspace_path: Path) -> list[Path]:
    gemini_home = _gemini_home()
    candidates: list[Path] = []
    append_unique(candidates, workspace_path / "GEMINI.md")
    for root in (
        workspace_path / ".gemini",
        gemini_home / "skills",
        gemini_home / "antigravity" / "global_skills",
    ):
        for path in collect_text_files(root, max_files=120, exclude_names=_GEMINI_EXCLUDED_CONTEXT_FILES):
            append_unique(candidates, path)
    return candidates[:200]


class GeminiCLIAdapter(AgentAdapter):
    agent_type = AgentType.GEMINI_CLI

    def __init__(self, process_scope: str = "current") -> None:
        self.process_scope = process_scope if process_scope in {"current", "all"} else "current"

    def discover(self, workspace: str) -> list[Path]:
        workspace_path = Path(workspace).resolve()
        candidates: list[Path] = []
        for path in _gemini_process_files(workspace_path, self.process_scope):
            append_unique(candidates, path)
        for path in _gemini_skill_files(workspace_path):
            append_unique(candidates, path)
        return candidates[:200]

    def extract(self, workspace: str) -> list[dict]:
        workspace_path = Path(workspace).resolve()
        gemini_home = _gemini_home()
        records = []
        for path in self.discover(workspace):
            if path.suffix == ".json" and "chats" in path.parts:
                try:
                    canonical = parse_transcript(path, agent_type="gemini-cli")
                    project_dir = path.parent.parent
                    records.append(
                        {
                            "path": str(path),
                            "relative_path": f"process/gemini/{project_dir.name}/{path.name}",
                            "namespace": "process",
                            "content": render_markdown(canonical),
                            "canonical_transcript": canonical.model_dump(mode="json"),
                        }
                    )
                    continue
                except Exception:
                    pass

            relative = str(path.relative_to(workspace_path)) if path.is_relative_to(workspace_path) else f"skills/gemini/global/{path.relative_to(gemini_home)}"
            records.append(
                {
                    "path": str(path),
                    "relative_path": relative,
                    "namespace": "skills",
                    "content": read_text_file(path),
                }
            )
        return records

    def normalize(self, raw: list[dict]) -> dict[str, list[dict]]:
        normalized: dict[str, list[dict]] = {}
        for record in raw:
            normalized.setdefault(record["namespace"], []).append(record)
        return normalized

    def bundle(self, normalized: dict[str, list[dict]], policy: dict | None = None) -> CaptureResult:
        trajectory = {ns: items for ns, items in normalized.items() if ns != "artifacts"}
        components = [Namespace(ns) for ns in trajectory.keys()]
        return CaptureResult(
            agent_id="pending",
            agent_type=self.agent_type,
            workspace="",
            code_ref=CodeRef(),
            workspace_overlay=WorkspaceOverlay(mode="none", binding=WorkspaceBinding(cwd="")),
            trajectory=trajectory,
            artifacts=normalized.get("artifacts", []),
            trajectory_components=components,
            captured_namespaces=list(normalized.keys()),
            payloads=normalized,
            warnings=[] if normalized else ["no Gemini CLI files were discovered"],
        )
