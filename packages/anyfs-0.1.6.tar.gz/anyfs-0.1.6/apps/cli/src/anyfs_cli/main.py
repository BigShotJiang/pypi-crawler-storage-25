from __future__ import annotations

import json
import tempfile
from pathlib import Path

import typer

from anyfs_sdk import AnyFSService


app = typer.Typer(help="AnyFS command line interface")
auth_app = typer.Typer(help="Authentication operations")
agent_app = typer.Typer(help="Agent operations")
snapshot_app = typer.Typer(help="Snapshot operations")
share_app = typer.Typer(help="Share operations", invoke_without_command=True)
release_app = typer.Typer(help="Release operations")
lineage_app = typer.Typer(help="Lineage operations")

app.add_typer(auth_app, name="auth")
app.add_typer(agent_app, name="agent")
app.add_typer(snapshot_app, name="snapshot")
app.add_typer(share_app, name="share")
app.add_typer(release_app, name="release")
app.add_typer(lineage_app, name="lineage")


def emit(payload) -> None:
    typer.echo(json.dumps(payload, indent=2, default=str))


def service() -> AnyFSService:
    return AnyFSService()


def _emit_register_followup(agent_type: str) -> None:
    typer.echo("")
    typer.echo("Next:")
    typer.echo("  1. Ask your human to create or log into an account at https://anyfs.ai.")
    typer.echo("  2. Then bind this agent to that account:")
    typer.echo(f"     anyfs agent bind --type {agent_type} --email <email> --password <password>")
    typer.echo("  3. After binding, this agent can publish packages under that user.")


def _workspace_next_steps(result: dict, workspace: str) -> list[str]:
    if result.get("namespace") != "workspace":
        return []
    output_file = result.get("output_file")
    restore_dir = result.get("restore_dir")
    if not output_file:
        return []
    try:
        bundle = json.loads(Path(output_file).read_text(encoding="utf-8"))
    except Exception:
        return []
    binding = bundle.get("binding") or {}
    mode = bundle.get("mode") or result.get("workspace_mode") or "changed"
    steps: list[str] = []
    remote = binding.get("remote")
    commit_sha = binding.get("commit_sha")
    if remote:
        checkout = f" and checkout {commit_sha}" if commit_sha else ""
        steps.append(f"Clone {remote}{checkout}.")
    if restore_dir:
        if mode == "full":
            steps.append(f"Workspace was fully restored at {restore_dir}. You can continue directly from that directory.")
        elif mode == "changed":
            steps.append(f"Workspace overlay was restored at {restore_dir}. Review and apply those files onto your local checkout.")
        else:
            steps.append(f"Workspace metadata was restored at {restore_dir}.")
    if binding.get("branch") and not remote:
        steps.append(f"Use branch {binding['branch']} when recreating the workspace locally.")
    return steps


def _process_next_steps(result: dict, workspace: str, target: str | None) -> list[str]:
    if result.get("namespace") != "process":
        return []
    output_file = result.get("output_file")
    if not output_file:
        return []
    suggested_target = target or "<target-agent>"
    return [
        f"Read the restored process at {output_file}.",
        f"When you want native session restore, run: anyfs resume {output_file} --target {suggested_target} -w {workspace}",
    ]


def _emit_open_next_steps(results: list[dict], workspace: str, target: str | None) -> None:
    steps: list[str] = []
    for result in results:
        steps.extend(_workspace_next_steps(result, workspace))
    for result in results:
        steps.extend(_process_next_steps(result, workspace, target))
    if not steps:
        return
    typer.echo("\nNext:")
    for idx, step in enumerate(steps, start=1):
        typer.echo(f"  {idx}. {step}")


# ── Primary commands (register / share / open) ─────────────────

@app.command("register")
def register_command(
    display_name: str | None = typer.Argument(None, help="Display name for this agent (e.g. chad-claude-code)"),
    agent_type: str = typer.Option(..., "--type", "-t", help="Agent type"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """Register a machine-level AnyFS agent for the given client type."""
    from anyfs_local_state import workspace_agent
    existing = workspace_agent(workspace, agent_type)
    if existing and existing.get("agent_id", "").startswith("did:key:"):
        typer.echo(f"Agent already registered: {existing['display_name']} ({existing['agent_id'][:24]}...)")
        raise typer.Exit(0)
    if not display_name:
        display_name = typer.prompt("What should this agent be called?")
    svc = service()
    result = svc.register_agent(agent_type, workspace, display_name)
    try:
        svc.agent_create_remote(workspace, agent_type)
        result["remote"] = True
    except Exception:
        result["remote"] = False
    typer.echo(f"\nRegistered!")
    typer.echo(f"  Name:  {result['display_name']}")
    typer.echo(f"  DID:   {result['agent_id']}")
    typer.echo(f"  Type:  {result['agent_type']}")
    if result.get("remote"):
        typer.echo(f"  Remote: registered on API")
    _emit_register_followup(result["agent_type"])


def _run_share(
    workspace: str,
    namespaces: str | None,
    password: str | None,
    message: str,
    workspace_mode: str,
    agent_type: str,
    process_scope: str,
    artifacts_public: bool,
    artifact: list[str] | None,
) -> None:
    from anyfs_local_state import workspace_agent
    agent = workspace_agent(workspace, agent_type)
    if not agent or not agent.get("agent_id"):
        typer.echo(f"Agent not registered for {agent_type}. Run `anyfs register --type {agent_type}` first.", err=True)
        raise typer.Exit(1)
    selected = [ns.strip() for ns in namespaces.split(",")] if namespaces else None
    result = service().quick_share(
        workspace,
        selected,
        password,
        agent_type,
        message=message,
        workspace_mode=workspace_mode,
        process_scope=process_scope,
        artifacts_public=artifacts_public,
        artifact_paths=artifact or None,
    )
    typer.echo(f"\nShare link(s):")
    for ns, info in result.get("shares", {}).items():
        if info.get("error"):
            typer.echo(f"  {ns}: {info['error']}")
        elif info.get("gateway_url"):
            typer.echo(f"  {ns}: {info['gateway_url']}")
        elif info.get("share_file"):
            typer.echo(f"  {ns}: {info['share_file']}")
    typer.echo(f"Password: {result['password']}")
    typer.echo(f"Message: {result['message']}")
    if result.get("handoff_text"):
        typer.echo("\nHandoff text:")
        typer.echo(result["handoff_text"])
    typer.echo(f"\nSend the link + password to your collaborator.")


@share_app.callback()
def share_command(
    ctx: typer.Context,
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    namespaces: str | None = typer.Option(None, "--namespaces", "-n", help="Comma-separated namespaces (default: all private)"),
    password: str | None = typer.Option(None, "--password", "-p", help="Share password (auto-generated if omitted)"),
    message: str | None = typer.Option(None, "--message", "-m", help="Required handoff note for the recipient"),
    workspace_mode: str = typer.Option("changed", "--workspace-mode", help="Workspace payload mode: changed, full, none"),
    process_scope: str = typer.Option("current", "--process-scope", help="Process capture scope: current, all"),
    artifacts_public: bool = typer.Option(True, "--artifacts-public/--artifacts-private", help="Keep artifacts public in the snapshot (default: public)"),
    artifact: list[str] | None = typer.Option(None, "--artifact", help="Explicit artifact file or directory path. Repeat to include multiple artifacts."),
    agent_type: str = typer.Option(..., "--type", "-t", help="Agent type"),
) -> None:
    """Capture, encrypt, upload, and return a shareable link + password."""
    if ctx.invoked_subcommand is not None:
        return
    if not message:
        raise typer.BadParameter("Missing option '--message' / '-m'.", param_hint="--message")
    _run_share(workspace, namespaces, password, message, workspace_mode, agent_type, process_scope, artifacts_public, artifact)


@app.command("open")
def open_command(
    share_paths: list[str] = typer.Argument(..., help="One or more share URLs or paths to .share.json files"),
    password: str = typer.Option(..., "--password", "-p", help="Password from the sender"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output directory"),
    resume: bool = typer.Option(False, "--resume", help="Auto-resume the session after decrypting"),
    agent_type: str = typer.Option(..., "--type", "-t", help="Current receiving client type"),
    target: str | None = typer.Option(None, "--target", help="Target agent for resume (default: auto-detect)"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    register_as: str | None = typer.Option(
        None,
        "--register-as",
        help="After decrypting, auto-register a machine-level AnyFS agent with the given display name",
    ),
) -> None:
    """Decrypt and load a shared context."""
    svc = service()
    # Auto-init if needed
    svc.init()
    try:
        svc.agent_status(workspace, agent_type)
    except Exception:
        if not register_as:
            typer.echo("", err=True)
            typer.echo(
                f"❌ {agent_type} is not registered with AnyFS on this machine yet.",
                err=True,
            )
            typer.echo(
                "   Register this client type before opening the shared context:",
                err=True,
            )
            typer.echo("", err=True)
            typer.echo(
                f"       anyfs register --type {agent_type} <your-display-name>",
                err=True,
            )
            typer.echo("", err=True)
            typer.echo(
                "   Or do it in one step by re-running this command with:",
                err=True,
            )
            typer.echo("", err=True)
            typer.echo(
                f"       --type {agent_type} --register-as <display-name>",
                err=True,
            )
            raise typer.Exit(1)
        try:
            reg = svc.register_agent(agent_type, workspace, register_as)
            svc.agent_create_remote(workspace, agent_type)
            typer.echo("\n✅ Registered AnyFS agent for this machine:")
            typer.echo(f"    Name: {reg['display_name']}")
            typer.echo(f"    Type: {reg['agent_type']}")
            typer.echo(f"    DID:  {reg['agent_id']}")
        except Exception as exc:
            typer.echo(f"\n❌ Auto-register failed: {exc}", err=True)
            typer.echo(
                f"   Run manually: anyfs register --type {agent_type} {register_as}",
                err=True,
            )
            raise typer.Exit(1)

    results = []
    for share_path in share_paths:
        result = svc.open_shared(share_path, password, output)
        results.append(result)
        typer.echo(f"\nDecrypted {result['namespace']} ({result['item_count']} items)")
        typer.echo(f"  Output: {result['output_file']}")
        if result.get("restore_dir"):
            typer.echo(f"  Restore dir: {result['restore_dir']}")
    # Show message once (same for all namespaces in a single share)
    msg = next((r["message"] for r in results if r.get("message")), None)
    if msg:
        typer.echo(f"\n  Message: {msg}")
    _emit_open_next_steps(results, workspace, target)
    if resume:
        process_results = [r for r in results if r["namespace"] == "process"]
        for result in process_results:
            from anyfs_transcript import export_transcript, load_transcripts
            transcripts = load_transcripts(result["output_file"])
            tgt = target or "claude-code"
            for t in transcripts:
                files = export_transcript(t, target_agent=tgt, workspace=workspace)
                typer.echo(f"  Resumed session {t.session.id} -> {tgt}")


# ── Core commands ────────────────────────────────────────────────

@app.command("init")
def init_command() -> None:
    """Initialize AnyFS (~/.anyfs, root key, identity)."""
    emit(service().init())


@app.command("doctor")
def doctor_command(workspace: str | None = typer.Option(None, help="Workspace path")) -> None:
    """Run workspace diagnostics."""
    emit(service().doctor(workspace))


@app.command("capture")
def capture_command(
    agent_type: str = typer.Argument(..., help="Agent type: claude-code, codex-cli, gemini-cli, hermes, nanobot, openclaw, or opencode"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    process_scope: str = typer.Option("current", "--process-scope", help="Process capture scope: current, all"),
    workspace_mode: str = typer.Option("changed", "--workspace-mode", help="Workspace overlay mode: changed, full, none"),
    client_scope: str = typer.Option("project", "--client-scope", help="Capture scope across clients: project, single"),
    artifact: list[str] | None = typer.Option(None, "--artifact", help="Explicit artifact file or directory path. Repeat to include multiple artifacts."),
) -> None:
    """Extract agent state from workspace into namespaces."""
    emit(
        service().capture(
            agent_type,
            workspace,
            process_scope=process_scope,
            workspace_mode=workspace_mode,
            client_scope=client_scope,
            artifact_paths=artifact or None,
        )
    )


@app.command("restore")
def restore_command(
    snapshot: str = typer.Option("latest", "--snapshot", "-s"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """Decrypt and restore a snapshot to the workspace."""
    emit(service().restore(workspace, snapshot))


@app.command("backup")
def backup_command(
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    snapshot: str = typer.Option("latest", "--snapshot", "-s"),
    namespaces: str | None = typer.Option(None, "--namespaces", "-n", help="Comma-separated namespace list"),
) -> None:
    """Upload encrypted snapshot to cloud (API + storage gateway)."""
    selected = [item.strip() for item in namespaces.split(",")] if namespaces else None
    emit(service().backup_create(workspace, snapshot, selected))


@app.command("pack")
def pack_command(
    snapshot_id: str = typer.Argument(None, help="Snapshot ID (default: latest)"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    output: str | None = typer.Option(None, "--output", "-o"),
    message: str | None = typer.Option(None, "--message", "-m", help="Human-readable package message"),
    visibility_mode: str = typer.Option("artifacts-public", "--visibility-mode", help="Publish visibility mode: all-public, artifacts-public, all-private"),
    visibility_policy: str | None = typer.Option(None, "--visibility-policy", help="Optional path to visibility policy file"),
) -> None:
    """Build an AFPKG archive from a snapshot."""
    svc = service()
    if not snapshot_id:
        snapshots = svc.snapshot_list(workspace)
        if not snapshots:
            typer.echo("No snapshots found.", err=True)
            raise typer.Exit(1)
        snapshot_id = snapshots[-1]["snapshot_id"]
    emit(
        svc.pack(
            workspace,
            snapshot_id,
            output,
            message=message,
            visibility_policy_path=visibility_policy,
            visibility_mode=visibility_mode,
        )
    )


@app.command("publish")
def publish_command(
    archive_path: str = typer.Argument(None, help="Path to .afpkg (omit to auto-pack latest snapshot)"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    message: str = typer.Option(..., "--message", "-m", help="Required human-readable package message"),
    visibility_mode: str = typer.Option("artifacts-public", "--visibility-mode", help="Publish visibility mode: all-public, artifacts-public, all-private"),
    visibility_policy: str | None = typer.Option(None, "--visibility-policy", help="Optional path to visibility policy file"),
) -> None:
    """Publish a package to the registry. Auto-packs if no archive given."""
    svc = service()
    if not archive_path:
        snapshots = svc.snapshot_list(workspace)
        if not snapshots:
            typer.echo("No snapshots found. Run 'capture' and 'snapshot create' first.", err=True)
            raise typer.Exit(1)
        pack_result = svc.pack(
            workspace,
            snapshots[-1]["snapshot_id"],
            message=message,
            visibility_policy_path=visibility_policy,
            visibility_mode=visibility_mode,
        )
        archive_path = pack_result["archive_path"]
        emit(svc.publish(workspace, archive_path, message=message))
        return
    emit(
        svc.publish(
            workspace,
            archive_path,
            message=message,
            visibility_policy_path=visibility_policy,
            visibility_mode=visibility_mode,
        )
    )


@app.command("fork")
def fork_command(
    package_id: str = typer.Argument(...),
    child_display_name: str = typer.Option("forked-package", "--child-display-name"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """Fork a published package."""
    emit(service().fork(workspace, package_id, child_display_name))


@app.command("buy")
def buy_command(
    package_id: str = typer.Argument(...),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    child_display_name: str = typer.Option("purchased-package", "--child-display-name"),
    output: str | None = typer.Option(None, "--output", "-o"),
    resume_target: str | None = typer.Option(None, "--resume", "-r", help="Optionally resume installed process context into a target agent"),
) -> None:
    """Fork a published package, install it locally, and optionally resume its process context."""
    emit(service().buy(workspace, package_id, child_display_name, output_dir=output, resume_target=resume_target))


@app.command("quick-share")
def quick_share(
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    namespaces: str | None = typer.Option(None, "--namespaces", "-n", help="Comma-separated namespaces (default: all private)"),
    password: str | None = typer.Option(None, "--password", "-p", help="Share password (auto-generated if omitted)"),
    message: str = typer.Option(..., "--message", "-m", help="Required handoff note for the recipient"),
    workspace_mode: str = typer.Option("changed", "--workspace-mode", help="Workspace payload mode: changed, full, none"),
    process_scope: str = typer.Option("current", "--process-scope", help="Process capture scope: current, all"),
    artifacts_public: bool = typer.Option(True, "--artifacts-public/--artifacts-private", help="Keep artifacts public in the snapshot (default: public)"),
    artifact: list[str] | None = typer.Option(None, "--artifact", help="Explicit artifact file or directory path. Repeat to include multiple artifacts."),
    agent_type: str = typer.Option(..., "--agent-type", "-t", help="Agent type: claude-code, codex-cli, gemini-cli, hermes, nanobot, openclaw, or opencode"),
) -> None:
    """One-shot: capture, encrypt, upload, and return shareable links + password."""
    _run_share(workspace, namespaces, password, message, workspace_mode, agent_type, process_scope, artifacts_public, artifact)


@app.command("resume")
def resume_command(
    transcript_path: str = typer.Argument(..., help="Path to a transcript file, canonical process bundle, or share URL/file"),
    target: str = typer.Option(..., "--target", "-t", help="Target agent: claude-code, codex-cli, gemini-cli, hermes, nanobot, openclaw, opencode, cursor"),
    source: str | None = typer.Option(None, "--source", "-s", help="Source agent type (auto-detected if omitted)"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    password: str | None = typer.Option(None, "--password", "-p", help="Share password when transcript_path is a share URL or .share.json"),
    native: bool = typer.Option(True, "--native/--context-only", help="Generate native transcript (default) or context-only injection"),
) -> None:
    """Resume a session from one agent in another.

    Default (--native): generates a real native transcript file that the target
    client can load as a previous session with full tool call history.

    --context-only: injects a compressed context summary into the target client's
    instruction file (AGENTS.md, CLAUDE.md memory, .cursor/rules, GEMINI.md).
    """
    from anyfs_transcript import export_transcript, inject_transcript, load_transcripts

    resolved_source = transcript_path
    opened_share: dict[str, str] | None = None
    if _looks_like_share_artifact(transcript_path):
        if not password:
            typer.echo("share resume requires --password", err=True)
            raise typer.Exit(1)
        opened_dir = Path(tempfile.mkdtemp(prefix="anyfs-resume-share-"))
        opened_share = service().open_shared(transcript_path, password, str(opened_dir))
        if opened_share["namespace"] != "process":
            typer.echo(
                f"resume requires a process share, got namespace: {opened_share['namespace']}",
                err=True,
            )
            raise typer.Exit(1)
        resolved_source = opened_share["output_file"]

    transcripts = load_transcripts(resolved_source, agent_type=source)

    if not native and len(transcripts) > 1:
        typer.echo(
            "context-only resume requires exactly one transcript. "
            "Pick one session from the canonical process bundle or use native export.",
            err=True,
        )
        raise typer.Exit(1)

    try:
        mode = "native" if native else "context"
        results = []
        for transcript in transcripts:
            if native:
                result = export_transcript(transcript, target_agent=target, workspace=workspace)
            else:
                result = inject_transcript(transcript, target_agent=target, workspace=workspace)
            results.append({"transcript": transcript, "files_written": result})
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1) from exc

    if len(results) == 1:
        transcript = results[0]["transcript"]
        files_written = results[0]["files_written"]
        payload = {
            "source_agent": transcript.session.agent,
            "source_session_id": transcript.session.id,
            "source_model": transcript.session.model,
            "source_events": len(transcript.events),
            "target_agent": target,
            "mode": mode,
            "resolved_source": resolved_source,
            "files_written": files_written,
        }
        if opened_share:
            payload["opened_share"] = opened_share
        if "resume_hint" in files_written:
            payload["resume_hint"] = files_written["resume_hint"]
        emit(payload)
        return

    emit(
        {
            "target_agent": target,
            "mode": mode,
            "resolved_source": resolved_source,
            "transcript_count": len(results),
            "sessions": [
                {
                    "source_agent": item["transcript"].session.agent,
                    "source_session_id": item["transcript"].session.id,
                    "source_model": item["transcript"].session.model,
                    "source_events": len(item["transcript"].events),
                    "files_written": item["files_written"],
                    **(
                        {"resume_hint": item["files_written"]["resume_hint"]}
                        if "resume_hint" in item["files_written"]
                        else {}
                    ),
                }
                for item in results
            ],
            **({"opened_share": opened_share} if opened_share else {}),
        }
    )


@app.command("migrate")
def migrate_command(
    source_agent: str = typer.Option(..., "--from", help="Source agent type"),
    target_agent: str = typer.Option(..., "--to", help="Target agent type"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    target_workspace: str | None = typer.Option(None, "--target-workspace", help="Target workspace path (defaults to --workspace)"),
    preset: str = typer.Option("user-data", "--preset", help="Migration preset: user-data or full"),
    include_secrets: bool = typer.Option(False, "--include-secrets/--no-include-secrets", help="Include source runtime secrets and provider keys"),
    overwrite: bool = typer.Option(False, "--overwrite", help="Overwrite existing imported files"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview migration without writing files"),
) -> None:
    """Import migratable context from one agent format into another."""
    emit(
        service().migrate_context(
            source_agent,
            target_agent,
            workspace,
            target_workspace=target_workspace,
            overwrite=overwrite,
            dry_run=dry_run,
            preset=preset,
            include_secrets=include_secrets,
        )
    )


def _looks_like_share_artifact(value: str) -> bool:
    return value.startswith(("http://", "https://")) or value.endswith(".share.json")


@app.command("export-recovery")
def export_recovery(output: str | None = typer.Option(None, "--output", "-o")) -> None:
    """Export recovery key bundle for backup."""
    emit(service().export_recovery(output))


@app.command("import-recovery")
def import_recovery(path: str = typer.Argument(...)) -> None:
    """Import a recovery key bundle."""
    emit(service().import_recovery(path))


# ── Auth ─────────────────────────────────────────────────────────

@auth_app.command("register")
def auth_register(
    email: str = typer.Option(..., "--email", help="Email address"),
    password: str = typer.Option(..., "--password", prompt=True, hide_input=True, confirmation_prompt=True, help="Account password"),
) -> None:
    """Create a human account with email and password."""
    emit(service().auth_register(email, password))


@auth_app.command("login")
def auth_login(
    email: str = typer.Option(..., "--email", help="Email address"),
    password: str = typer.Option(..., "--password", prompt=True, hide_input=True, help="Account password"),
) -> None:
    """Login with email and password."""
    emit(service().auth_login(email, password))


# ── Agent ────────────────────────────────────────────────────────

@agent_app.command("register")
def register_agent(
    agent_type: str = typer.Argument(..., help="Agent type: claude-code, codex-cli, gemini-cli, hermes, nanobot, openclaw, or opencode"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    display_name: str | None = typer.Option(None, "--display-name"),
    remote: bool = typer.Option(True, "--remote/--no-remote", help="Also register on remote API"),
) -> None:
    """Register an agent locally (and optionally on the remote API)."""
    svc = service()
    result = svc.register_agent(agent_type, workspace, display_name)
    if remote:
        try:
            svc.agent_create_remote(workspace, agent_type)
            result["remote"] = True
        except Exception:
            result["remote"] = False
    emit(result)
    _emit_register_followup(result["agent_type"])


@agent_app.command("status")
def agent_status(
    agent_type: str | None = typer.Option(None, "--type", "-t", help="Agent type to inspect for this workspace"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """Check local and remote agent status."""
    emit(service().agent_status(workspace, agent_type))


@agent_app.command("bind")
def agent_bind(
    email: str = typer.Option(..., "--email", help="Email address of the user account to bind"),
    password: str = typer.Option(..., "--password", help="Password of the user account to bind"),
    agent_type: str | None = typer.Option(None, "--type", "-t", help="Agent type to bind for this workspace"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """Bind an agent to a user account via email and password."""
    emit(service().agent_bind(workspace, email, password, agent_type))


@agent_app.command("rename")
def agent_rename(
    agent_type: str = typer.Option(..., "--type", "-t", help="Agent type to rename"),
    display_name: str = typer.Option(..., "--display-name", help="New display name"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """Rename a machine-level AnyFS agent for the given client type."""
    emit(service().agent_rename(workspace, agent_type, display_name))


# ── Snapshot ─────────────────────────────────────────────────────

@snapshot_app.command("create")
def snapshot_create(
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    artifacts_public: bool = typer.Option(True, "--artifacts-public/--artifacts-private", help="Keep artifacts public in the snapshot (default: public)"),
) -> None:
    """Create an encrypted snapshot from the latest capture."""
    emit(service().snapshot_create(workspace, artifacts_public=artifacts_public))


@snapshot_app.command("list")
def snapshot_list(workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w")) -> None:
    """List all snapshots."""
    emit({"items": service().snapshot_list(workspace)})


# ── Share ────────────────────────────────────────────────────────

@share_app.command("namespace")
def share_namespace(
    namespace: str = typer.Argument(..., help="Namespace to share (e.g. memory, soul, skills, workspace)"),
    password: str = typer.Option(..., "--password", "-p", help="Password for the recipient"),
    message: str = typer.Option(..., "--message", "-m", help="Required handoff note for the recipient"),
    workspace_mode: str = typer.Option("changed", "--workspace-mode", help="Workspace payload mode when namespace=workspace"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
    snapshot: str = typer.Option("latest", "--snapshot", "-s"),
) -> None:
    """Share a single namespace with a password. Recipient decrypts without your root key."""
    emit(service().share_namespace(workspace, namespace, password, snapshot, message=message, workspace_mode=workspace_mode))


@share_app.command("open")
def share_open(
    share_path: str = typer.Argument(..., help="Path to .share.json file or share URL"),
    password: str = typer.Option(..., "--password", "-p", help="Password from the sender"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output directory"),
) -> None:
    """Decrypt a shared file using the share password. No root key needed."""
    emit(service().open_shared(share_path, password, output))


@share_app.command("list")
def share_list(workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w")) -> None:
    """List share links."""
    emit({"items": service().list_links(workspace)})


# ── Release ──────────────────────────────────────────────────────

@release_app.command("create")
def release_create(
    package_id: str = typer.Argument(...),
    version: str = typer.Option(..., "--version", "-v"),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """Create a versioned release from a published package."""
    emit(service().release_create(workspace, package_id, version))


# ── Lineage ──────────────────────────────────────────────────────

@lineage_app.command("show")
def lineage_show(
    package_id: str = typer.Argument(...),
    workspace: str = typer.Option(str(Path.cwd()), "--workspace", "-w"),
) -> None:
    """Show package lineage (fork history)."""
    emit(service().lineage_show(workspace, package_id))


if __name__ == "__main__":
    app()
