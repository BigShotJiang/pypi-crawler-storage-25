"""Unit tests for anyfs_schemas package."""
from __future__ import annotations

from datetime import datetime, timezone

import pytest
from pydantic import ValidationError

from anyfs_schemas import (
    AgentAuthMode,
    AgentBinding,
    AgentBindingStatus,
    AgentBindRequest,
    AgentBindResponse,
    AgentRenameRequest,
    AgentCredential,
    AgentRecord,
    AgentRecordLite,
    AgentAuthRegisterRequest,
    AgentAuthRegisterResponse,
    AgentStatusResponse,
    AgentType,
    AnyFSModel,
    APIAck,
    ArtifactRecord,
    ArtifactsSummary,
    AuthLoginRequest,
    AuthLoginResponse,
    AuthRegisterRequest,
    AuthRegisterResponse,
    AuthStatus,
    BackupCreateRequest,
    BackupRecord,
    CaptureResult,
    CodeRef,
    CodeRefProvider,
    DelegationRequest,
    DelegationResponse,
    DoctorReport,
    ForkRequest,
    ForkResponse,
    LineageRecord,
    LinkCreateRequest,
    LinkRecord,
    MeResponse,
    Namespace,
    PackageCreateRequest,
    PackageManifest,
    PackageRecord,
    PublishResult,
    ReleaseRecord,
    RecoveryRecord,
    ShareLinkResult,
    SkillAction,
    SkillActionSpec,
    SnapshotManifest,
    SnapshotRecord,
    SnapshotRecordLite,
    StorageCommitRequest,
    StorageCommitResponse,
    UserRecord,
    Visibility,
    WorkspaceBinding,
    WorkspaceOverlay,
    WorkspaceOverlaySummary,
    TrajectorySummary,
    utc_now,
    utc_now_iso,
)


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------

class TestUtcNow:
    def test_returns_datetime(self):
        result = utc_now()
        assert isinstance(result, datetime)

    def test_is_utc(self):
        result = utc_now()
        assert result.tzinfo == timezone.utc

    def test_utc_now_iso_returns_string(self):
        result = utc_now_iso()
        assert isinstance(result, str)
        # Should be parseable back to datetime
        datetime.fromisoformat(result)


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class TestAgentType:
    def test_values(self):
        assert AgentType.HERMES == "hermes"
        assert AgentType.NANOBOT == "nanobot"
        assert AgentType.OPENCLAW == "openclaw"
        assert AgentType.CLAUDE_CODE == "claude-code"

    def test_is_string_enum(self):
        assert isinstance(AgentType.OPENCLAW, str)

    def test_all_members(self):
        assert {member.value for member in AgentType} == {
            "hermes",
            "nanobot",
            "openclaw",
            "opencode",
            "claude-code",
            "gemini-cli",
            "codex-cli",
            "cursor",
        }


class TestNamespace:
    def test_values(self):
        assert Namespace.SOUL == "soul"
        assert Namespace.USER == "user"
        assert Namespace.MEMORY == "memory"
        assert Namespace.SKILLS == "skills"
        assert Namespace.PROCESS == "process"
        assert Namespace.ARTIFACTS == "artifacts"
        assert Namespace.WORKSPACE_OVERLAY == "workspace_overlay"

    def test_all_members(self):
        assert len(Namespace) == 7


class TestVisibility:
    def test_values(self):
        assert Visibility.PUBLIC == "public"
        assert Visibility.PRIVATE == "private"


class TestCodeRefProvider:
    def test_values(self):
        assert CodeRefProvider.GITHUB == "github"
        assert CodeRefProvider.GIT == "git"
        assert CodeRefProvider.NONE == "none"


class TestAgentAuthMode:
    def test_values(self):
        assert AgentAuthMode.STANDALONE == "standalone"
        assert AgentAuthMode.BOUND == "bound"


class TestAgentBindingStatus:
    def test_values(self):
        assert AgentBindingStatus.UNCLAIMED == "unclaimed"
        assert AgentBindingStatus.CLAIMED == "claimed"
        assert AgentBindingStatus.REVOKED == "revoked"


class TestAgentRenameRequest:
    def test_accepts_display_name(self):
        payload = AgentRenameRequest(display_name="Claude-Opus")
        assert payload.display_name == "Claude-Opus"

    def test_rejects_empty_name(self):
        with pytest.raises(ValidationError):
            AgentRenameRequest(display_name="")


class TestSkillAction:
    def test_init(self):
        assert SkillAction.INIT == "anyfs.init"

    def test_all_members(self):
        assert len(SkillAction) == 19

    def test_sample_values(self):
        assert SkillAction.AUTH_LOGIN == "anyfs.auth_login"
        assert SkillAction.BUY == "anyfs.buy"
        assert SkillAction.CAPTURE == "anyfs.capture"
        assert SkillAction.FORK == "anyfs.fork"
        assert SkillAction.LINEAGE_SHOW == "anyfs.lineage_show"
        assert SkillAction.MIGRATE == "anyfs.migrate"


# ---------------------------------------------------------------------------
# Base model
# ---------------------------------------------------------------------------

class TestAnyFSModel:
    def test_extra_forbid(self):
        with pytest.raises(ValidationError):
            UserRecord(user_id="u1", email="a@b.com", unknown_field="x")

    def test_populate_by_name(self):
        assert AnyFSModel.model_config["populate_by_name"] is True

    def test_use_enum_values(self):
        assert AnyFSModel.model_config["use_enum_values"] is True


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

class TestUserRecord:
    def test_create(self):
        u = UserRecord(user_id="u1", email="test@example.com")
        assert u.user_id == "u1"
        assert u.email == "test@example.com"
        assert isinstance(u.created_at, datetime)

    def test_custom_created_at(self):
        dt = datetime(2024, 1, 1, tzinfo=timezone.utc)
        u = UserRecord(user_id="u1", email="a@b.com", created_at=dt)
        assert u.created_at == dt


class TestAgentRecord:
    def test_create(self):
        r = AgentRecord(
            agent_id="agt_1", owner_user_id="u1",
            agent_type=AgentType.OPENCLAW, display_name="test"
        )
        assert r.agent_id == "agt_1"
        assert r.agent_type == "openclaw"
        assert r.head_snapshot_id is None

    def test_with_snapshot(self):
        r = AgentRecord(
            agent_id="agt_1", owner_user_id="u1",
            agent_type="claude-code", display_name="test",
            head_snapshot_id="snp_abc"
        )
        assert r.head_snapshot_id == "snp_abc"


class TestAgentRecordLite:
    def test_defaults(self):
        r = AgentRecordLite(
            agent_id="agt_1", agent_type=AgentType.OPENCLAW,
            display_name="test"
        )
        assert r.owner_user_id is None
        assert r.auth_mode == "standalone"
        assert r.status == "unclaimed"

    def test_custom_values(self):
        r = AgentRecordLite(
            agent_id="agt_1", owner_user_id="u1",
            agent_type=AgentType.CLAUDE_CODE, display_name="test",
            auth_mode=AgentAuthMode.BOUND,
            status=AgentBindingStatus.CLAIMED
        )
        assert r.auth_mode == "bound"
        assert r.status == "claimed"


class TestAgentCredential:
    def test_create(self):
        c = AgentCredential(agent_id="agt_1", token_hash="abc123")
        assert c.revoked_at is None

    def test_revoked(self):
        dt = utc_now()
        c = AgentCredential(agent_id="agt_1", token_hash="abc123", revoked_at=dt)
        assert c.revoked_at == dt


class TestAgentBinding:
    def test_create(self):
        b = AgentBinding(binding_id="b1", agent_id="agt_1", user_id="u1")
        assert b.status == "claimed"


class TestArtifactRecord:
    def test_create(self):
        a = ArtifactRecord(
            artifact_id="a1", snapshot_id="s1", type="text",
            visibility=Visibility.PUBLIC, cid="cid1", title="Test"
        )
        assert a.visibility == "public"


class TestSnapshotRecord:
    def test_create(self):
        s = SnapshotRecord(
            snapshot_id="snp_1", agent_id="agt_1",
            namespace=[Namespace.SOUL, Namespace.MEMORY],
            manifest_cid="cid1", payload_cid="cid2"
        )
        assert s.encrypted is True
        assert s.parent_snapshot_id is None
        assert len(s.namespace) == 2


class TestSnapshotRecordLite:
    def test_create(self):
        s = SnapshotRecordLite(
            snapshot_id="snp_1", agent_id="agt_1",
            manifest_cid="cid1", payload_cid="cid2",
            namespace_summary=[Namespace.SOUL], origin="local"
        )
        assert s.encrypted is True
        assert s.owner_user_id is None


class TestPackageRecord:
    def test_create(self):
        p = PackageRecord(
            package_id="pkg_1", source_snapshot_id="snp_1",
            manifest_cid="cid1",
            code_ref=CodeRef(provider=CodeRefProvider.GITHUB, repo_url="https://github.com/acme/repo", commit_sha="abc123"),
            workspace_overlay=WorkspaceOverlaySummary(
                mode="changed",
                binding=WorkspaceBinding(cwd="/tmp/ws"),
                file_count=1,
            ),
            trajectory=TrajectorySummary(components=[Namespace.PROCESS], counts={"process": 1}),
            artifacts=ArtifactsSummary(visibility=Visibility.PUBLIC, count=1, index=[{"path": "artifacts/demo.md"}]),
            fork_policy="free"
        )
        assert p.code_ref.provider == "github"
        assert p.trajectory.counts["process"] == 1
        assert p.artifacts.count == 1


class TestReleaseRecord:
    def test_create(self):
        r = ReleaseRecord(release_id="rel_1", package_id="pkg_1", version="v1.0.0")
        assert r.version == "v1.0.0"


class TestLineageRecord:
    def test_create(self):
        lr = LineageRecord(parent_package_id="pkg_1", child_package_id="pkg_2")
        assert isinstance(lr.created_at, datetime)


class TestBackupRecord:
    def test_create(self):
        b = BackupRecord(
            backup_id="bk_1", agent_id="agt_1", snapshot_id="snp_1",
            namespaces=[Namespace.MEMORY], manifest_cid="cid1",
            payload_cid="cid2", restore_hint="latest"
        )
        assert b.remote_url is None
        assert b.created_by_agent_id is None


class TestLinkRecord:
    def test_defaults(self):
        link = LinkRecord(
            link_id="lnk_1", agent_id="agt_1", snapshot_id="snp_1",
            namespaces=[Namespace.MEMORY], url="http://example.com"
        )
        assert link.visibility == "private"
        assert link.access_mode == "analysis"


class TestRecoveryRecord:
    def test_defaults(self):
        r = RecoveryRecord(recovery_id="rec_1", agent_id="agt_1", device_id="dev_1")
        assert r.bundle_version == "v1"


class TestCaptureResult:
    def test_create(self):
        cr = CaptureResult(
            agent_id="agt_1", agent_type=AgentType.OPENCLAW,
            workspace="/tmp/ws",
            code_ref=CodeRef(provider=CodeRefProvider.NONE),
            workspace_overlay=WorkspaceOverlay(mode="none", binding=WorkspaceBinding(cwd="/tmp/ws")),
            trajectory={"soul": [{"content": "data"}]},
            trajectory_components=[Namespace.SOUL],
            captured_namespaces=[Namespace.SOUL],
            payloads={"soul": [{"content": "data"}]}
        )
        assert cr.ok is True
        assert cr.warnings == []
        assert cr.trajectory["soul"][0]["content"] == "data"

    def test_with_warnings(self):
        cr = CaptureResult(
            agent_id="agt_1", agent_type=AgentType.OPENCLAW,
            workspace="",
            code_ref=CodeRef(provider=CodeRefProvider.NONE),
            workspace_overlay=WorkspaceOverlay(mode="none", binding=WorkspaceBinding(cwd="")),
            trajectory={},
            captured_namespaces=[],
            payloads={}, warnings=["no files"]
        )
        assert len(cr.warnings) == 1


class TestSnapshotManifest:
    def test_create(self):
        m = SnapshotManifest(
            snapshot_id="snp_1", agent_id="agt_1", workspace="/tmp",
            code_ref=CodeRef(provider=CodeRefProvider.NONE),
            workspace_overlay=WorkspaceOverlaySummary(
                mode="changed",
                binding=WorkspaceBinding(cwd="/tmp"),
                file_count=1,
            ),
            trajectory=TrajectorySummary(components=[Namespace.SOUL], counts={"soul": 1}),
            artifacts=ArtifactsSummary(visibility=Visibility.PRIVATE, count=0, index=[]),
            restore_metadata={}
        )
        assert m.snapshot_id == "snp_1"


class TestPackageManifest:
    def test_create(self):
        m = PackageManifest(
            name="test-pkg", description="A test package",
            agent_type=AgentType.OPENCLAW, version="v1.0.0",
            code_ref=CodeRef(provider=CodeRefProvider.GITHUB, repo_url="https://github.com/acme/repo"),
            workspace_overlay=WorkspaceOverlaySummary(
                mode="changed",
                binding=WorkspaceBinding(cwd="/tmp/ws"),
                file_count=1,
            ),
            trajectory=TrajectorySummary(components=[Namespace.PROCESS], counts={"process": 1}),
            artifacts=ArtifactsSummary(visibility=Visibility.PUBLIC, count=1, index=[]),
        )
        assert m.tags == []


class TestSkillActionSpec:
    def test_create(self):
        s = SkillActionSpec(
            action=SkillAction.INIT,
            input_schema={"type": "object"},
            output_schema={"type": "object"},
            error_codes=["INIT_FAILED"],
            side_effect="Create ~/.anyfs",
            requires_workspace=False,
            requires_init=False
        )
        assert s.action == "anyfs.init"


class TestDoctorReport:
    def test_healthy(self):
        d = DoctorReport(ok=True, checks={"a": True})
        assert d.ok is True
        assert d.warnings == []

    def test_unhealthy(self):
        d = DoctorReport(ok=False, checks={"a": False}, warnings=["missing"])
        assert d.ok is False


# ---------------------------------------------------------------------------
# API Request/Response models
# ---------------------------------------------------------------------------

class TestAuthLoginRequest:
    def test_create(self):
        r = AuthLoginRequest(email="test@example.com", password="hunter2password")
        assert r.email == "test@example.com"
        assert r.password == "hunter2password"


class TestAuthRegisterRequest:
    def test_create(self):
        r = AuthRegisterRequest(email="test@example.com", password="hunter2password")
        assert r.email == "test@example.com"


class TestAuthLoginResponse:
    def test_create(self):
        r = AuthLoginResponse(token="tok_abc", user=UserRecord(user_id="u1", email="test@example.com"))
        assert r.ok is True
        assert isinstance(r.expires_at, datetime)
        assert r.user.email == "test@example.com"


class TestAuthRegisterResponse:
    def test_create(self):
        r = AuthRegisterResponse(token="tok_abc", user=UserRecord(user_id="u1", email="test@example.com"))
        assert r.ok is True
        assert isinstance(r.expires_at, datetime)


class TestMeResponse:
    def test_create(self):
        user = UserRecord(user_id="u1", email="a@b.com")
        r = MeResponse(user=user)
        assert r.ok is True
        assert r.user.user_id == "u1"


class TestDelegationRequest:
    def test_create(self):
        r = DelegationRequest(agent_did="did:123", scope="read")
        assert r.scope == "read"


class TestDelegationResponse:
    def test_create(self):
        r = DelegationResponse(proof="proof_data", scope="read")
        assert r.ok is True
        assert isinstance(r.expires_at, datetime)


class TestStorageCommitRequest:
    def test_create(self):
        r = StorageCommitRequest(resource_type="snapshot", resource_id="s1", cid="cid1")
        assert r.metadata == {}


class TestStorageCommitResponse:
    def test_create(self):
        r = StorageCommitResponse(commit_id="c1", cid="cid1")
        assert r.ok is True


class TestAuthStatus:
    def test_create(self):
        r = AuthStatus(email="a@b.com", token="tok")
        assert r.ok is True


class TestAgentAuthRegisterRequest:
    def test_create(self):
        r = AgentAuthRegisterRequest(
            agent_id="agt_1", agent_type=AgentType.OPENCLAW,
            display_name="test"
        )
        assert r.agent_type == "openclaw"


class TestAgentAuthRegisterResponse:
    def test_create(self):
        agent = AgentRecordLite(
            agent_id="agt_1", agent_type=AgentType.OPENCLAW,
            display_name="test"
        )
        r = AgentAuthRegisterResponse(agent=agent)
        assert r.ok is True


class TestAgentStatusResponse:
    def test_no_binding(self):
        agent = AgentRecordLite(
            agent_id="agt_1", agent_type=AgentType.OPENCLAW,
            display_name="test"
        )
        r = AgentStatusResponse(agent=agent)
        assert r.binding is None


class TestAgentBindRequest:
    def test_create(self):
        r = AgentBindRequest(email="person@example.com", password="hunter2password")
        assert r.email == "person@example.com"
        assert r.password == "hunter2password"

    def test_password_required(self):
        with pytest.raises(ValidationError):
            AgentBindRequest(email="person@example.com")


class TestAgentBindResponse:
    def test_create(self):
        agent = AgentRecordLite(
            agent_id="agt_1", agent_type=AgentType.OPENCLAW,
            display_name="test"
        )
        binding = AgentBinding(binding_id="b1", agent_id="agt_1", user_id="u1")
        r = AgentBindResponse(agent=agent, binding=binding)
        assert r.ok is True


class TestPublishResult:
    def test_create(self):
        r = PublishResult(package_id="pkg_1", cid="cid1", path="/tmp/pkg.afpkg")
        assert r.ok is True


class TestShareLinkResult:
    def test_create(self):
        r = ShareLinkResult(link_id="lnk_1", url="http://example.com", remote_ref="ref1")
        assert r.expires_at is None


class TestForkRequest:
    def test_defaults(self):
        r = ForkRequest(package_id="pkg_1", child_display_name="child")
        assert r.fork_policy == "free"


class TestForkResponse:
    def test_create(self):
        pkg = PackageRecord(
            package_id="pkg_2", source_snapshot_id="snp_1",
            manifest_cid="cid1",
            code_ref=CodeRef(provider=CodeRefProvider.NONE),
            trajectory=TrajectorySummary(),
            artifacts=ArtifactsSummary(),
            fork_policy="free"
        )
        lineage = LineageRecord(parent_package_id="pkg_1", child_package_id="pkg_2")
        r = ForkResponse(child_package=pkg, lineage=lineage)
        assert r.ok is True


class TestAPIAck:
    def test_create(self):
        r = APIAck(message="done")
        assert r.ok is True
        assert r.message == "done"


class TestBackupCreateRequest:
    def test_create(self):
        agent = AgentRecordLite(agent_id="agt_1", agent_type=AgentType.OPENCLAW, display_name="t")
        snapshot = SnapshotRecordLite(
            snapshot_id="snp_1", agent_id="agt_1",
            manifest_cid="c1", payload_cid="c2",
            namespace_summary=[Namespace.SOUL], origin="local"
        )
        backup = BackupRecord(
            backup_id="bk_1", agent_id="agt_1", snapshot_id="snp_1",
            namespaces=[Namespace.SOUL], manifest_cid="c1",
            payload_cid="c2", restore_hint="latest"
        )
        r = BackupCreateRequest(agent=agent, snapshot=snapshot, backup=backup)
        assert r.backup.backup_id == "bk_1"


class TestLinkCreateRequest:
    def test_create(self):
        agent = AgentRecordLite(agent_id="agt_1", agent_type=AgentType.OPENCLAW, display_name="t")
        snapshot = SnapshotRecordLite(
            snapshot_id="snp_1", agent_id="agt_1",
            manifest_cid="c1", payload_cid="c2",
            namespace_summary=[Namespace.SOUL], origin="local"
        )
        link = LinkRecord(
            link_id="lnk_1", agent_id="agt_1", snapshot_id="snp_1",
            namespaces=[Namespace.SOUL], url="http://example.com"
        )
        r = LinkCreateRequest(agent=agent, snapshot=snapshot, link=link)
        assert r.link.link_id == "lnk_1"


class TestPackageCreateRequest:
    def test_create(self):
        agent = AgentRecordLite(agent_id="agt_1", agent_type=AgentType.OPENCLAW, display_name="t")
        snapshot = SnapshotRecordLite(
            snapshot_id="snp_1", agent_id="agt_1",
            manifest_cid="c1", payload_cid="c2",
            namespace_summary=[Namespace.SOUL], origin="local"
        )
        package = PackageRecord(
            package_id="pkg_1", source_snapshot_id="snp_1",
            manifest_cid="c1",
            code_ref=CodeRef(provider=CodeRefProvider.NONE),
            trajectory=TrajectorySummary(),
            artifacts=ArtifactsSummary(),
            fork_policy="free"
        )
        r = PackageCreateRequest(agent=agent, snapshot=snapshot, package=package)
        assert r.package.package_id == "pkg_1"
