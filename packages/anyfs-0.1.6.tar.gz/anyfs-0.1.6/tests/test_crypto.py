"""Unit tests for anyfs_crypto package."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from anyfs_crypto import (
    create_root_key_bundle,
    decrypt_json_payload,
    encrypt_json_payload,
    ensure_root_key,
    export_recovery_bundle,
    import_recovery_bundle,
    load_root_key,
    unwrap_root_key,
)
from anyfs_crypto.keys import _b64, _unb64, _derive_wrap_key, _encrypt_with_key, _decrypt_with_key


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

class TestBase64Helpers:
    def test_roundtrip(self):
        data = b"hello world"
        assert _unb64(_b64(data)) == data

    def test_empty(self):
        assert _unb64(_b64(b"")) == b""

    def test_binary_data(self):
        data = bytes(range(256))
        assert _unb64(_b64(data)) == data


class TestDeriveWrapKey:
    def test_returns_32_bytes(self):
        key = _derive_wrap_key("user1", "device1")
        assert len(key) == 32

    def test_deterministic(self):
        k1 = _derive_wrap_key("user1", "device1")
        k2 = _derive_wrap_key("user1", "device1")
        assert k1 == k2

    def test_different_inputs(self):
        k1 = _derive_wrap_key("user1", "device1")
        k2 = _derive_wrap_key("user2", "device1")
        k3 = _derive_wrap_key("user1", "device2")
        assert k1 != k2
        assert k1 != k3


class TestEncryptDecryptWithKey:
    def test_roundtrip(self):
        import os
        key = os.urandom(32)
        plaintext = b"secret data"
        encrypted = _encrypt_with_key(key, plaintext)
        decrypted = _decrypt_with_key(key, encrypted["nonce"], encrypted["ciphertext"])
        assert decrypted == plaintext

    def test_with_aad(self):
        import os
        key = os.urandom(32)
        plaintext = b"secret data"
        aad = b"additional data"
        encrypted = _encrypt_with_key(key, plaintext, aad)
        decrypted = _decrypt_with_key(key, encrypted["nonce"], encrypted["ciphertext"], aad)
        assert decrypted == plaintext

    def test_wrong_key_fails(self):
        import os
        key1 = os.urandom(32)
        key2 = os.urandom(32)
        encrypted = _encrypt_with_key(key1, b"secret")
        with pytest.raises(Exception):
            _decrypt_with_key(key2, encrypted["nonce"], encrypted["ciphertext"])

    def test_wrong_aad_fails(self):
        import os
        key = os.urandom(32)
        encrypted = _encrypt_with_key(key, b"secret", b"correct_aad")
        with pytest.raises(Exception):
            _decrypt_with_key(key, encrypted["nonce"], encrypted["ciphertext"], b"wrong_aad")


# ---------------------------------------------------------------------------
# Root key bundle
# ---------------------------------------------------------------------------

class TestCreateRootKeyBundle:
    def test_structure(self):
        bundle = create_root_key_bundle("user1", "device1")
        assert bundle["alg"] == "AES256-GCM"
        assert "created_at" in bundle
        assert bundle["wrapped_for"]["user_id"] == "user1"
        assert bundle["wrapped_for"]["device_id"] == "device1"
        assert "nonce" in bundle
        assert "ciphertext" in bundle

    def test_different_bundles_each_call(self):
        b1 = create_root_key_bundle("user1", "device1")
        b2 = create_root_key_bundle("user1", "device1")
        # Different nonces and ciphertexts each time (new random root key)
        assert b1["nonce"] != b2["nonce"] or b1["ciphertext"] != b2["ciphertext"]


class TestUnwrapRootKey:
    def test_roundtrip(self):
        bundle = create_root_key_bundle("user1", "device1")
        root_key = unwrap_root_key(bundle, "user1", "device1")
        assert isinstance(root_key, bytes)
        assert len(root_key) == 32

    def test_wrong_user_fails(self):
        bundle = create_root_key_bundle("user1", "device1")
        with pytest.raises(Exception):
            unwrap_root_key(bundle, "wrong_user", "device1")

    def test_wrong_device_fails(self):
        bundle = create_root_key_bundle("user1", "device1")
        with pytest.raises(Exception):
            unwrap_root_key(bundle, "user1", "wrong_device")

    def test_consistent_key(self):
        bundle = create_root_key_bundle("user1", "device1")
        k1 = unwrap_root_key(bundle, "user1", "device1")
        k2 = unwrap_root_key(bundle, "user1", "device1")
        assert k1 == k2


# ---------------------------------------------------------------------------
# Filesystem root key operations
# ---------------------------------------------------------------------------

class TestEnsureRootKey:
    def test_creates_key_file(self, tmp_path):
        identity = {"user_id": "usr_test", "device_id": "dev_test"}
        (tmp_path / "keys").mkdir()
        path = ensure_root_key(tmp_path, identity)
        assert path.exists()
        assert path == tmp_path / "keys" / "rootkey.enc"
        bundle = json.loads(path.read_text(encoding="utf-8"))
        assert bundle["alg"] == "AES256-GCM"

    def test_idempotent(self, tmp_path):
        identity = {"user_id": "usr_test", "device_id": "dev_test"}
        (tmp_path / "keys").mkdir()
        path1 = ensure_root_key(tmp_path, identity)
        content1 = path1.read_text(encoding="utf-8")
        path2 = ensure_root_key(tmp_path, identity)
        content2 = path2.read_text(encoding="utf-8")
        assert content1 == content2


class TestLoadRootKey:
    def test_load(self, tmp_path):
        identity = {"user_id": "usr_test", "device_id": "dev_test"}
        (tmp_path / "keys").mkdir()
        ensure_root_key(tmp_path, identity)
        key = load_root_key(tmp_path, identity)
        assert isinstance(key, bytes)
        assert len(key) == 32

    def test_load_consistent(self, tmp_path):
        identity = {"user_id": "usr_test", "device_id": "dev_test"}
        (tmp_path / "keys").mkdir()
        ensure_root_key(tmp_path, identity)
        k1 = load_root_key(tmp_path, identity)
        k2 = load_root_key(tmp_path, identity)
        assert k1 == k2


# ---------------------------------------------------------------------------
# JSON payload encryption
# ---------------------------------------------------------------------------

class TestEncryptDecryptJsonPayload:
    def test_roundtrip_dict(self):
        import os
        root_key = os.urandom(32)
        payload = {"key": "value", "nested": {"a": 1}}
        envelope = encrypt_json_payload(root_key, payload, "memory")
        result = decrypt_json_payload(root_key, envelope)
        assert result == payload

    def test_roundtrip_list(self):
        import os
        root_key = os.urandom(32)
        payload = [1, 2, 3, "hello"]
        envelope = encrypt_json_payload(root_key, payload, "soul")
        result = decrypt_json_payload(root_key, envelope)
        assert result == payload

    def test_roundtrip_string(self):
        import os
        root_key = os.urandom(32)
        payload = "just a string"
        envelope = encrypt_json_payload(root_key, payload, "skills")
        result = decrypt_json_payload(root_key, envelope)
        assert result == payload

    def test_envelope_structure(self):
        import os
        root_key = os.urandom(32)
        envelope = encrypt_json_payload(root_key, {"data": True}, "memory")
        assert envelope["envelope_id"].startswith("env_")
        assert envelope["alg"] == "AES256-GCM"
        assert envelope["namespace"] == "memory"
        assert "wrapped_dek" in envelope
        assert "payload" in envelope

    def test_wrong_root_key_fails(self):
        import os
        root_key1 = os.urandom(32)
        root_key2 = os.urandom(32)
        envelope = encrypt_json_payload(root_key1, {"secret": True}, "memory")
        with pytest.raises(Exception):
            decrypt_json_payload(root_key2, envelope)

    def test_different_namespaces_different_envelopes(self):
        import os
        root_key = os.urandom(32)
        payload = {"data": "same"}
        e1 = encrypt_json_payload(root_key, payload, "memory")
        e2 = encrypt_json_payload(root_key, payload, "soul")
        assert e1["namespace"] != e2["namespace"]


# ---------------------------------------------------------------------------
# Recovery bundle
# ---------------------------------------------------------------------------

class TestRecoveryBundle:
    def _setup_global(self, tmp_path):
        identity = {"user_id": "usr_test", "device_id": "dev_test"}
        keys_dir = tmp_path / "keys"
        keys_dir.mkdir(parents=True)
        ensure_root_key(tmp_path, identity)
        return identity

    def test_export_creates_file(self, tmp_path):
        identity = self._setup_global(tmp_path)
        path = export_recovery_bundle(tmp_path, identity)
        assert path.exists()
        assert path == tmp_path / "keys" / "recovery.anyfs"

    def test_export_custom_path(self, tmp_path):
        identity = self._setup_global(tmp_path)
        custom_path = tmp_path / "custom_recovery.json"
        path = export_recovery_bundle(tmp_path, identity, custom_path)
        assert path == custom_path
        assert custom_path.exists()

    def test_export_content(self, tmp_path):
        identity = self._setup_global(tmp_path)
        path = export_recovery_bundle(tmp_path, identity)
        payload = json.loads(path.read_text(encoding="utf-8"))
        assert payload["bundle_version"] == "v1"
        assert payload["identity"] == identity
        assert "rootkey_bundle" in payload
        assert "created_at" in payload

    def test_import_restores_key(self, tmp_path):
        identity = self._setup_global(tmp_path)
        original_key = load_root_key(tmp_path, identity)
        recovery_path = export_recovery_bundle(tmp_path, identity)

        # Import to a new location
        new_root = tmp_path / "new_global"
        new_root.mkdir()
        payload = import_recovery_bundle(new_root, recovery_path)
        assert payload["bundle_version"] == "v1"

        # Verify restored key matches
        restored_key = load_root_key(new_root, identity)
        assert restored_key == original_key

    def test_import_creates_files(self, tmp_path):
        identity = self._setup_global(tmp_path)
        recovery_path = export_recovery_bundle(tmp_path, identity)

        new_root = tmp_path / "new_global"
        new_root.mkdir()
        import_recovery_bundle(new_root, recovery_path)
        assert (new_root / "keys" / "rootkey.enc").exists()
        assert (new_root / "keys" / "recovery.anyfs").exists()
