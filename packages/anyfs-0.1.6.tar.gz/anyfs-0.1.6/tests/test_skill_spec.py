"""Unit tests for anyfs_skill_spec package."""
from __future__ import annotations

import pytest

from anyfs_skill_spec import ACTION_SPECS, get_action_spec
from anyfs_schemas import SkillAction, SkillActionSpec


# ---------------------------------------------------------------------------
# ACTION_SPECS dictionary
# ---------------------------------------------------------------------------

class TestActionSpecs:
    def test_all_skill_actions_covered(self):
        for action in SkillAction:
            assert action.value in ACTION_SPECS, f"Missing spec for {action.value}"

    def test_count(self):
        assert len(ACTION_SPECS) == 19

    def test_all_values_are_spec_instances(self):
        for key, spec in ACTION_SPECS.items():
            assert isinstance(spec, SkillActionSpec)

    def test_keys_match_action_values(self):
        for key, spec in ACTION_SPECS.items():
            assert key == spec.action


# ---------------------------------------------------------------------------
# Individual action specs
# ---------------------------------------------------------------------------

class TestInitSpec:
    def test_action(self):
        spec = ACTION_SPECS["anyfs.init"]
        assert spec.action == "anyfs.init"

    def test_no_workspace_required(self):
        spec = ACTION_SPECS["anyfs.init"]
        assert spec.requires_workspace is False

    def test_no_init_required(self):
        spec = ACTION_SPECS["anyfs.init"]
        assert spec.requires_init is False

    def test_error_codes(self):
        spec = ACTION_SPECS["anyfs.init"]
        assert "INIT_FAILED" in spec.error_codes


class TestAuthLoginSpec:
    def test_requires_init(self):
        spec = ACTION_SPECS["anyfs.auth_login"]
        assert spec.requires_init is True

    def test_no_workspace(self):
        spec = ACTION_SPECS["anyfs.auth_login"]
        assert spec.requires_workspace is False

    def test_input_requires_email(self):
        spec = ACTION_SPECS["anyfs.auth_login"]
        assert "email" in spec.input_schema.get("required", [])
        assert "password" in spec.input_schema.get("required", [])


class TestCaptureSpec:
    def test_requires_workspace(self):
        spec = ACTION_SPECS["anyfs.capture"]
        assert spec.requires_workspace is True

    def test_requires_init(self):
        spec = ACTION_SPECS["anyfs.capture"]
        assert spec.requires_init is True

    def test_input_requires_agent_type_and_workspace(self):
        spec = ACTION_SPECS["anyfs.capture"]
        required = spec.input_schema.get("required", [])
        assert "agent_type" in required
        assert "workspace" in required


class TestSnapshotCreateSpec:
    def test_requires_workspace(self):
        spec = ACTION_SPECS["anyfs.snapshot_create"]
        assert spec.requires_workspace is True

    def test_error_codes(self):
        spec = ACTION_SPECS["anyfs.snapshot_create"]
        assert "SNAPSHOT_CREATE_FAILED" in spec.error_codes


class TestRestoreSpec:
    def test_input_requires_snapshot(self):
        spec = ACTION_SPECS["anyfs.restore"]
        required = spec.input_schema.get("required", [])
        assert "workspace" in required
        assert "snapshot" in required


class TestPackSpec:
    def test_input_requires_snapshot_id(self):
        spec = ACTION_SPECS["anyfs.pack"]
        required = spec.input_schema.get("required", [])
        assert "snapshot_id" in required


class TestPublishSpec:
    def test_input_requires_archive_path(self):
        spec = ACTION_SPECS["anyfs.publish"]
        required = spec.input_schema.get("required", [])
        assert "archive_path" in required


class TestReleaseCreateSpec:
    def test_input_requires_version(self):
        spec = ACTION_SPECS["anyfs.release_create"]
        required = spec.input_schema.get("required", [])
        assert "version" in required
        assert "package_id" in required


class TestForkSpec:
    def test_input_requires_fields(self):
        spec = ACTION_SPECS["anyfs.fork"]
        required = spec.input_schema.get("required", [])
        assert "package_id" in required
        assert "child_display_name" in required


class TestLineageShowSpec:
    def test_input_requires_package_id(self):
        spec = ACTION_SPECS["anyfs.lineage_show"]
        required = spec.input_schema.get("required", [])
        assert "package_id" in required


class TestWorkspaceRequirements:
    """Verify workspace/init requirements are correct across all actions."""

    def test_init_needs_neither(self):
        spec = ACTION_SPECS["anyfs.init"]
        assert spec.requires_workspace is False
        assert spec.requires_init is False

    def test_auth_login_needs_init_only(self):
        spec = ACTION_SPECS["anyfs.auth_login"]
        assert spec.requires_workspace is False
        assert spec.requires_init is True

    def test_workspace_actions_need_both(self):
        workspace_actions = [
            "anyfs.register_agent", "anyfs.capture", "anyfs.snapshot_create",
            "anyfs.snapshot_list", "anyfs.restore", "anyfs.backup_create",
            "anyfs.share_link", "anyfs.pack", "anyfs.publish",
            "anyfs.release_create", "anyfs.fork", "anyfs.lineage_show",
            "anyfs.agent_create_remote", "anyfs.agent_status", "anyfs.agent_bind",
        ]
        for action_name in workspace_actions:
            spec = ACTION_SPECS[action_name]
            assert spec.requires_workspace is True, f"{action_name} should require workspace"
            assert spec.requires_init is True, f"{action_name} should require init"


class TestAgentBindSpec:
    def test_input_requires_email_and_password(self):
        spec = ACTION_SPECS["anyfs.agent_bind"]
        required = spec.input_schema.get("required", [])
        assert "email" in required
        assert "password" in required


# ---------------------------------------------------------------------------
# get_action_spec
# ---------------------------------------------------------------------------

class TestGetActionSpec:
    def test_returns_spec(self):
        spec = get_action_spec("anyfs.init")
        assert isinstance(spec, SkillActionSpec)
        assert spec.action == "anyfs.init"

    def test_all_actions(self):
        for action in SkillAction:
            spec = get_action_spec(action.value)
            assert spec.action == action.value

    def test_unknown_raises_key_error(self):
        with pytest.raises(KeyError):
            get_action_spec("anyfs.nonexistent")

    def test_empty_raises_key_error(self):
        with pytest.raises(KeyError):
            get_action_spec("")

    def test_side_effect_not_empty(self):
        for action_name, spec in ACTION_SPECS.items():
            assert spec.side_effect, f"{action_name} should have a side_effect description"

    def test_error_codes_not_empty(self):
        for action_name, spec in ACTION_SPECS.items():
            assert len(spec.error_codes) > 0, f"{action_name} should have error codes"
