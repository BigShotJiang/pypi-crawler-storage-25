"""Unit tests for anyfs_packaging package."""
from __future__ import annotations

import json
import zipfile
from pathlib import Path

import pytest

from anyfs_packaging import build_afpkg, extract_afpkg


class TestBuildAfpkg:
    def test_creates_archive(self, tmp_path):
        output = tmp_path / "test.afpkg"
        result = build_afpkg(
            output_path=output,
            manifest={"name": "test-pkg", "version": "v1.0"},
            public_entries={"artifacts/readme.md": b"# Hello"},
            private_entries={"trajectory/soul.json": {"encrypted": True}},
            lineage={"parent": "pkg_1"},
            policy={"fork_policy": "free"},
        )
        assert result == output
        assert output.exists()

    def test_valid_zip(self, tmp_path):
        output = tmp_path / "test.afpkg"
        build_afpkg(
            output_path=output,
            manifest={"name": "test"},
            public_entries={},
            private_entries={},
            lineage={},
            policy={},
        )
        assert zipfile.is_zipfile(output)

    def test_archive_contents(self, tmp_path):
        output = tmp_path / "test.afpkg"
        build_afpkg(
            output_path=output,
            manifest={"name": "test-pkg"},
            public_entries={"artifacts/doc.md": b"# Doc", "artifacts/sub/file.txt": b"data"},
            private_entries={"trajectory/soul.json": {"envelope": "data"}},
            lineage={"parent": None},
            policy={"fork_policy": "free"},
        )
        with zipfile.ZipFile(output, "r") as zf:
            names = zf.namelist()
            assert "afpkg/manifest.json" in names
            assert "afpkg/lineage.json" in names
            assert "afpkg/policy.json" in names
            assert "afpkg/public/artifacts/doc.md" in names
            assert "afpkg/public/artifacts/sub/file.txt" in names
            assert "afpkg/private/trajectory/soul.json" in names

    def test_manifest_content(self, tmp_path):
        output = tmp_path / "test.afpkg"
        manifest = {"name": "my-package", "version": "v2.0", "tags": ["test"]}
        build_afpkg(
            output_path=output,
            manifest=manifest,
            public_entries={},
            private_entries={},
            lineage={},
            policy={},
        )
        with zipfile.ZipFile(output, "r") as zf:
            content = json.loads(zf.read("afpkg/manifest.json"))
            assert content == manifest

    def test_artifact_content(self, tmp_path):
        output = tmp_path / "test.afpkg"
        build_afpkg(
            output_path=output,
            manifest={},
            public_entries={"artifacts/hello.txt": b"Hello World"},
            private_entries={},
            lineage={},
            policy={},
        )
        with zipfile.ZipFile(output, "r") as zf:
            assert zf.read("afpkg/public/artifacts/hello.txt") == b"Hello World"

    def test_private_payload_content(self, tmp_path):
        output = tmp_path / "test.afpkg"
        payload = {"envelope_id": "env_1", "alg": "AES256-GCM", "data": "encrypted"}
        build_afpkg(
            output_path=output,
            manifest={},
            public_entries={},
            private_entries={"trajectory/memory.json": payload},
            lineage={},
            policy={},
        )
        with zipfile.ZipFile(output, "r") as zf:
            content = json.loads(zf.read("afpkg/private/trajectory/memory.json"))
            assert content == payload

    def test_creates_parent_dirs(self, tmp_path):
        output = tmp_path / "a" / "b" / "test.afpkg"
        build_afpkg(
            output_path=output,
            manifest={},
            public_entries={},
            private_entries={},
            lineage={},
            policy={},
        )
        assert output.exists()

    def test_empty_artifacts_and_payloads(self, tmp_path):
        output = tmp_path / "empty.afpkg"
        build_afpkg(
            output_path=output,
            manifest={"name": "empty"},
            public_entries={},
            private_entries={},
            lineage={},
            policy={},
        )
        with zipfile.ZipFile(output, "r") as zf:
            names = zf.namelist()
            assert "afpkg/manifest.json" in names
            assert not any(n.startswith("afpkg/public/") for n in names if n != "afpkg/public/")
            assert not any(n.startswith("afpkg/private/") for n in names if n != "afpkg/private/")


class TestExtractAfpkg:
    def test_extracts_archive(self, tmp_path):
        archive = tmp_path / "test.afpkg"
        build_afpkg(
            output_path=archive,
            manifest={"name": "extract-test"},
            public_entries={"artifacts/readme.md": b"# Test"},
            private_entries={"trajectory/data.json": {"encrypted": True}},
            lineage={"parent": None},
            policy={"fork_policy": "free"},
        )
        output_dir = tmp_path / "extracted"
        result = extract_afpkg(archive, output_dir)
        assert result == output_dir
        assert output_dir.exists()

    def test_extracted_structure(self, tmp_path):
        archive = tmp_path / "test.afpkg"
        build_afpkg(
            output_path=archive,
            manifest={"name": "test"},
            public_entries={"artifacts/doc.md": b"content"},
            private_entries={"trajectory/soul.json": {"data": "encrypted"}},
            lineage={},
            policy={},
        )
        output_dir = tmp_path / "extracted"
        extract_afpkg(archive, output_dir)

        assert (output_dir / "afpkg" / "manifest.json").exists()
        assert (output_dir / "afpkg" / "lineage.json").exists()
        assert (output_dir / "afpkg" / "policy.json").exists()
        assert (output_dir / "afpkg" / "public" / "artifacts" / "doc.md").exists()
        assert (output_dir / "afpkg" / "private" / "trajectory" / "soul.json").exists()

    def test_extracted_content(self, tmp_path):
        archive = tmp_path / "test.afpkg"
        manifest = {"name": "roundtrip", "version": "v1"}
        build_afpkg(
            output_path=archive,
            manifest=manifest,
            public_entries={"artifacts/hello.txt": b"Hello"},
            private_entries={},
            lineage={},
            policy={},
        )
        output_dir = tmp_path / "extracted"
        extract_afpkg(archive, output_dir)

        extracted_manifest = json.loads(
            (output_dir / "afpkg" / "manifest.json").read_text(encoding="utf-8")
        )
        assert extracted_manifest == manifest
        assert (output_dir / "afpkg" / "public" / "artifacts" / "hello.txt").read_bytes() == b"Hello"

    def test_creates_output_dir(self, tmp_path):
        archive = tmp_path / "test.afpkg"
        build_afpkg(
            output_path=archive,
            manifest={},
            public_entries={},
            private_entries={},
            lineage={},
            policy={},
        )
        output_dir = tmp_path / "nested" / "output"
        extract_afpkg(archive, output_dir)
        assert output_dir.exists()
