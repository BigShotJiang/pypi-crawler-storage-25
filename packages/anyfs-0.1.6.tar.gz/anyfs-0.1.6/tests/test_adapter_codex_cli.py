from __future__ import annotations

import json
import os
from pathlib import Path

from anyfs_adapter_codex_cli import CodexCLIAdapter
from anyfs_schemas import AgentType, CaptureResult


def _write_file(root: Path, rel: str, content: str) -> Path:
    path = root / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path


def _write_codex_session(home: Path, workspace: Path, session_id: str = "sid-1") -> Path:
    session_path = home / ".codex" / "sessions" / "2026" / "04" / "09" / f"rollout-{session_id}.jsonl"
    session_path.parent.mkdir(parents=True, exist_ok=True)
    session_path.write_text(
        "\n".join(
            [
                json.dumps(
                    {
                        "type": "session_meta",
                        "timestamp": "2026-04-09T12:00:00+00:00",
                        "payload": {"id": session_id, "cwd": str(workspace.resolve()), "model_provider": "gpt-5.4"},
                    }
                ),
                json.dumps(
                    {
                        "type": "response_item",
                        "timestamp": "2026-04-09T12:00:00+00:00",
                        "payload": {"type": "message", "role": "user", "content": [{"type": "input_text", "text": "Check plugins"}]},
                    }
                ),
                json.dumps(
                    {
                        "type": "response_item",
                        "timestamp": "2026-04-09T12:00:01+00:00",
                        "payload": {"type": "reasoning", "content": "Reviewing Codex session state"},
                    }
                ),
                json.dumps(
                    {
                        "type": "response_item",
                        "timestamp": "2026-04-09T12:00:02+00:00",
                        "payload": {"type": "message", "role": "assistant", "content": [{"type": "output_text", "text": "Loaded successfully."}]},
                    }
                ),
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    return session_path


def test_codex_adapter_extracts_process_and_skills(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    home = tmp_path / "home"
    _write_codex_session(home, workspace)
    _write_file(home, ".codex/AGENTS.md", "# Global agents")
    _write_file(home, ".codex/config.toml", "model = 'gpt-5.4'")
    _write_file(home, ".codex/skills/demo/SKILL.md", "# Demo skill")
    _write_file(home, ".codex/plugins/cache/demo/plugin/.codex-plugin/plugin.json", '{"name":"demo"}')
    _write_file(workspace, "AGENTS.md", "# Workspace agents")
    monkeypatch.setenv("HOME", str(home))

    adapter = CodexCLIAdapter()
    files = adapter.discover(str(workspace))
    assert any(path.name == "AGENTS.md" and ".codex" in str(path) for path in files)
    assert any(path.name == "plugin.json" for path in files)
    assert any(path.suffix == ".jsonl" for path in files)

    records = adapter.extract(str(workspace))
    assert any(item["namespace"] == "process" for item in records)
    assert any(item["namespace"] == "skills" for item in records)
    assert any(item["relative_path"].startswith("skills/codex/global/plugins") for item in records)
    assert all(not item["path"].endswith(".codex/config.toml") for item in records)
    process = next(item for item in records if item["namespace"] == "process")
    assert process["canonical_transcript"]["session"]["agent"] == "codex-cli"
    assert "Check plugins" in process["content"]


def test_codex_adapter_defaults_to_current_session_only(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    home = tmp_path / "home"
    older = _write_codex_session(home, workspace, session_id="sid-older")
    newer = _write_codex_session(home, workspace, session_id="sid-newer")
    os.utime(older, (1, 1))
    os.utime(newer, (2, 2))
    monkeypatch.setenv("HOME", str(home))

    adapter = CodexCLIAdapter()
    records = [item for item in adapter.extract(str(workspace)) if item["namespace"] == "process"]
    assert len(records) == 1
    assert records[0]["path"] == str(newer)


def test_codex_adapter_prefers_exact_current_thread_id(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    home = tmp_path / "home"
    older = _write_codex_session(home, workspace, session_id="sid-older")
    newer = _write_codex_session(home, workspace, session_id="sid-newer")
    os.utime(older, (2, 2))
    os.utime(newer, (3, 3))
    monkeypatch.setenv("HOME", str(home))
    monkeypatch.setenv("CODEX_THREAD_ID", "sid-older")

    adapter = CodexCLIAdapter()
    records = [item for item in adapter.extract(str(workspace)) if item["namespace"] == "process"]
    assert len(records) == 1
    assert records[0]["path"] == str(older)


def test_codex_adapter_can_capture_all_sessions(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    home = tmp_path / "home"
    _write_codex_session(home, workspace, session_id="sid-1")
    _write_codex_session(home, workspace, session_id="sid-2")
    monkeypatch.setenv("HOME", str(home))

    adapter = CodexCLIAdapter(process_scope="all")
    records = [item for item in adapter.extract(str(workspace)) if item["namespace"] == "process"]
    assert len(records) == 2


def test_codex_adapter_bundle():
    adapter = CodexCLIAdapter()
    result = adapter.bundle({"process": [{"content": "session"}], "skills": [{"content": "skill"}]})
    assert isinstance(result, CaptureResult)
    assert result.agent_type == AgentType.CODEX_CLI
    assert set(result.captured_namespaces) == {"process", "skills"}
