from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from anyfs_adapter_hermes import HermesAdapter
from anyfs_schemas import AgentType, CaptureResult


def _write_file(root: Path, rel: str, content: str) -> Path:
    path = root / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path


def _write_hermes_session(hermes_home: Path, session_id: str, prompt: str) -> Path:
    sessions_dir = hermes_home / "sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)
    path = sessions_dir / f"{session_id}.jsonl"
    path.write_text(
        "\n".join(
            [
                json.dumps({"role": "user", "content": prompt, "timestamp": "2026-04-09T12:00:00+00:00"}),
                json.dumps({"role": "assistant", "content": "Working on it.", "timestamp": "2026-04-09T12:00:01+00:00"}),
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    return path


def _write_hermes_state_db(hermes_home: Path, session_ids: list[str]) -> None:
    db_path = hermes_home / "state.db"
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.execute(
        """
        CREATE TABLE sessions (
            id TEXT PRIMARY KEY,
            source TEXT NOT NULL,
            started_at REAL NOT NULL,
            title TEXT
        )
        """
    )
    for index, session_id in enumerate(session_ids, start=1):
        conn.execute(
            "INSERT INTO sessions (id, source, started_at, title) VALUES (?, 'cli', ?, ?)",
            (session_id, float(index), session_id),
        )
    conn.commit()
    conn.close()


def test_hermes_adapter_discovers_and_extracts_personal_agent_state(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    hermes_home = tmp_path / "hermes-home"

    _write_file(workspace, "AGENTS.md", "# project instructions")
    _write_file(hermes_home, "SOUL.md", "# soul")
    _write_file(hermes_home, "memories/USER.md", "# user profile")
    _write_file(hermes_home, "memories/MEMORY.md", "# durable memory")
    _write_file(hermes_home, "skills/demo/SKILL.md", "# skill")
    _write_file(hermes_home, "config.yaml", "model: test")
    session_path = _write_hermes_session(hermes_home, "20260409_120000_demo", "Resume from here")
    _write_hermes_state_db(hermes_home, ["20260409_120000_demo"])
    monkeypatch.setenv("HERMES_HOME", str(hermes_home))

    adapter = HermesAdapter()
    files = adapter.discover(str(workspace))
    assert all(path.name != "config.yaml" for path in files)
    assert any(path.name == "SOUL.md" for path in files)
    assert any(path.name == "SKILL.md" for path in files)
    assert session_path in files

    records = adapter.extract(str(workspace))
    namespaces = {item["namespace"] for item in records}
    assert {"soul", "user", "memory", "skills", "process"} <= namespaces
    assert any(item["relative_path"].startswith("skills/hermes/global/skills") for item in records)
    assert all(not item["path"].endswith("config.yaml") for item in records)
    process = next(item for item in records if item["namespace"] == "process")
    assert process["canonical_transcript"]["session"]["agent"] == "hermes"
    assert "Resume from here" in process["content"]


def test_hermes_adapter_prefers_exact_current_session_id(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    hermes_home = tmp_path / "hermes-home"
    older = _write_hermes_session(hermes_home, "20260409_050010_old", "Old session")
    newer = _write_hermes_session(hermes_home, "20260409_120000_new", "New session")
    _write_hermes_state_db(hermes_home, ["20260409_120000_new", "20260409_050010_old"])
    monkeypatch.setenv("HERMES_HOME", str(hermes_home))
    monkeypatch.setenv("ANYFS_HERMES_SESSION_ID", "20260409_050010_old")

    adapter = HermesAdapter()
    process_records = [item for item in adapter.extract(str(workspace)) if item["namespace"] == "process"]
    assert len(process_records) == 1
    assert process_records[0]["path"] == str(older)
    assert process_records[0]["path"] != str(newer)


def test_hermes_adapter_can_capture_all_sessions(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    hermes_home = tmp_path / "hermes-home"
    _write_hermes_session(hermes_home, "20260409_050010_old", "Old session")
    _write_hermes_session(hermes_home, "20260409_120000_new", "New session")
    _write_hermes_state_db(hermes_home, ["20260409_120000_new", "20260409_050010_old"])
    monkeypatch.setenv("HERMES_HOME", str(hermes_home))

    adapter = HermesAdapter(process_scope="all")
    process_records = [item for item in adapter.extract(str(workspace)) if item["namespace"] == "process"]
    assert len(process_records) == 2


def test_hermes_adapter_bundle_and_agent_type():
    adapter = HermesAdapter()
    normalized = {"soul": [{"content": "persona"}], "skills": [{"content": "guidance"}]}
    result = adapter.bundle(normalized)
    assert isinstance(result, CaptureResult)
    assert result.agent_type == AgentType.HERMES
    assert set(result.captured_namespaces) == {"soul", "skills"}
