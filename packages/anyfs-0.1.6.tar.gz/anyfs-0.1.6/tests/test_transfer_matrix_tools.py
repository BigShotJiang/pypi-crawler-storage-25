from __future__ import annotations

import json
import os
import subprocess
import sys
import importlib.util
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "scripts" / "run_transfer_matrix.py"
VERIFIER = ROOT / "scripts" / "verify-transfer-case.py"
SPEC = importlib.util.spec_from_file_location("run_transfer_matrix", RUNNER)
assert SPEC and SPEC.loader
RUNNER_MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = RUNNER_MODULE
SPEC.loader.exec_module(RUNNER_MODULE)
CommandResult = RUNNER_MODULE.CommandResult
extract_codex_text_from_lines = RUNNER_MODULE.extract_codex_text_from_lines
normalize_output = RUNNER_MODULE.normalize_output
command_for_target = RUNNER_MODULE.command_for_target


def test_transfer_matrix_list_json_contains_expected_cases() -> None:
    result = subprocess.run(
        [sys.executable, str(RUNNER), "list", "--format", "json"],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    payload = json.loads(result.stdout)
    assert len(payload) == 28
    assert {case["id"] for case in payload} >= {
        "golden-claude-to-codex",
        "bundle-process-to-opencode",
        "reshare-claude-gemini-opencode",
        "roundtrip-openclaw-to-codex",
        "roundtrip-opencode-to-openclaw",
    }


def test_transfer_matrix_run_manual_mode_emits_resume_instructions(tmp_path: Path) -> None:
    fake_anyfs = tmp_path / "fake-anyfs"
    fake_anyfs.write_text(
        "\n".join(
            [
                "#!/usr/bin/env python3",
                "import json, pathlib, sys",
                "argv = sys.argv[1:]",
                "if argv and argv[0] == 'resume':",
                "    print(json.dumps({",
                "        'mode': 'native',",
                "        'target_agent': argv[argv.index('--target') + 1],",
                "        'files_written': {'session_id': 'sid-1'},",
                "        'resume_hint': 'codex resume sid-1'",
                "    }))",
                "    raise SystemExit(0)",
                "if argv[:2] == ['share', 'open']:",
                "    out = pathlib.Path(argv[argv.index('--output') + 1])",
                "    out.mkdir(parents=True, exist_ok=True)",
                "    (out / 'process.json').write_text('{}', encoding='utf-8')",
                "    print(json.dumps({'process': str(out / 'process.json')}))",
                "    raise SystemExit(0)",
                "raise SystemExit(1)",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    fake_anyfs.chmod(0o755)

    artifact = tmp_path / "process.json"
    artifact.write_text("{}", encoding="utf-8")
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    output_dir = tmp_path / "out"

    env = os.environ.copy()
    env["ANYFS_CMD"] = str(fake_anyfs)

    result = subprocess.run(
        [
            sys.executable,
            str(RUNNER),
            "run",
            "--case",
            "golden-claude-to-codex",
            "--artifact",
            str(artifact),
            "--workspace",
            str(workspace),
            "--output-dir",
            str(output_dir),
            "--manual",
        ],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
        env=env,
    )

    assert result.returncode == 0, result.stderr
    payload = json.loads(result.stdout)
    report = payload["reports"][0]
    assert report["status"] == "manual"
    assert report["probe_mode"] == "skipped"
    assert str(artifact) in report["manual_instructions"][3]
    assert report["selected_sessions"][0]["files_written"]["session_id"] == "sid-1"


def test_verify_transfer_case_supports_exact_contains_and_contains_all(tmp_path: Path) -> None:
    fixture_path = tmp_path / "fixture.json"
    answers_path = tmp_path / "answers.json"
    fixture_path.write_text(
        json.dumps(
            {
                "fixture_id": "demo",
                "expected": {
                    "last_user_message": {"mode": "exact", "value": "push一下"},
                    "work_summary": {"mode": "contains", "value": "storage gateway"},
                    "files_touched": {"mode": "contains_all", "values": ["main.py", "opencode.py"]},
                },
            },
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )
    answers_path.write_text(
        json.dumps(
            {
                "last_user_message": " push一下 ",
                "work_summary": "这次把 storage gateway 切到 GCS 并验证了上传。",
                "files_touched": "主要修改了 main.py, opencode.py 和 tests/test_transcript_resume.py",
            },
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    result = subprocess.run(
        [
            sys.executable,
            str(VERIFIER),
            "--fixture",
            str(fixture_path),
            "--answers",
            str(answers_path),
        ],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    payload = json.loads(result.stdout)
    assert payload["passed"] is True
    assert payload["verdicts"]["last_user_message"]["passed"] is True
    assert payload["verdicts"]["work_summary"]["passed"] is True
    assert payload["verdicts"]["files_touched"]["missing"] == []


def test_extract_codex_text_from_lines_prefers_final_assistant_output() -> None:
    lines = [
        json.dumps(
            {
                "type": "response_item",
                "payload": {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "intermediate"}],
                    "phase": "tool_call",
                },
            }
        ),
        json.dumps(
            {
                "type": "response_item",
                "payload": {
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "final answer"}],
                    "phase": "final_answer",
                },
            }
        ),
    ]

    assert extract_codex_text_from_lines(lines) == "final answer"


def test_normalize_output_for_codex_ignores_stderr_noise() -> None:
    result = CommandResult(
        argv=["codex"],
        returncode=124,
        stdout="assistant answer",
        stderr="terminal noise",
    )

    assert normalize_output("codex-cli", result) == "assistant answer"


def test_command_for_target_supports_claude_code() -> None:
    assert command_for_target("claude-code", "sid-1", "hello") == [
        "claude",
        "-p",
        "-r",
        "sid-1",
        "--output-format",
        "json",
        "hello",
    ]


def test_normalize_output_for_claude_result_json_uses_result_field() -> None:
    result = CommandResult(
        argv=["claude"],
        returncode=0,
        stdout=json.dumps({"type": "result", "result": "历史总结"}),
        stderr="",
    )

    assert normalize_output("claude-code", result) == "历史总结"
