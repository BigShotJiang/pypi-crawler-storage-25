"""Unit tests for anyfs_local_state package."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from anyfs_local_state import (
    append_backup,
    append_lineage,
    append_link,
    append_list_item,
    append_package,
    append_release,
    append_snapshot,
    default_global_root,
    default_workspace_root,
    doctor,
    ensure_dir,
    initialize_global_state,
    initialize_workspace_state,
    latest_capture,
    latest_snapshot_id,
    lineage_for_package,
    list_backups,
    list_links,
    list_packages,
    list_releases,
    list_snapshots,
    read_agent_remote_state,
    read_config,
    read_json,
    read_manifest,
    record_capture,
    rename_agent,
    register_agent,
    upsert_list_item,
    workspace_agent_by_id,
    workspace_agent_private_key,
    workspace_agent,
    write_agent_remote_state,
    write_config,
    write_json,
    write_manifest,
)


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------

class TestEnsureDir:
    def test_creates_nested(self, tmp_path):
        target = tmp_path / "a" / "b" / "c"
        result = ensure_dir(target)
        assert result == target
        assert target.is_dir()

    def test_idempotent(self, tmp_path):
        target = tmp_path / "existing"
        target.mkdir()
        result = ensure_dir(target)
        assert result == target


class TestReadJson:
    def test_reads_file(self, tmp_path):
        p = tmp_path / "data.json"
        p.write_text('{"key": "value"}', encoding="utf-8")
        assert read_json(p) == {"key": "value"}

    def test_missing_file_default_none(self, tmp_path):
        assert read_json(tmp_path / "missing.json") == {}

    def test_missing_file_custom_default(self, tmp_path):
        assert read_json(tmp_path / "missing.json", []) == []


class TestWriteJson:
    def test_writes_file(self, tmp_path):
        p = tmp_path / "out.json"
        write_json(p, {"hello": "world"})
        assert json.loads(p.read_text(encoding="utf-8")) == {"hello": "world"}

    def test_creates_parent_dirs(self, tmp_path):
        p = tmp_path / "a" / "b" / "out.json"
        write_json(p, {"nested": True})
        assert p.exists()


class TestAppendListItem:
    def test_appends(self, tmp_path):
        p = tmp_path / "list.json"
        write_json(p, {"items": []})
        append_list_item(p, {"id": "1"})
        append_list_item(p, {"id": "2"})
        data = read_json(p)
        assert len(data["items"]) == 2
        assert data["items"][0]["id"] == "1"

    def test_creates_items_key(self, tmp_path):
        p = tmp_path / "list.json"
        append_list_item(p, {"id": "1"})
        data = read_json(p)
        assert "items" in data


class TestUpsertListItem:
    def test_inserts_new(self, tmp_path):
        p = tmp_path / "list.json"
        write_json(p, {"items": []})
        upsert_list_item(p, {"id": "1", "name": "first"}, "id")
        data = read_json(p)
        assert len(data["items"]) == 1

    def test_updates_existing(self, tmp_path):
        p = tmp_path / "list.json"
        write_json(p, {"items": [{"id": "1", "name": "first"}]})
        upsert_list_item(p, {"id": "1", "name": "updated"}, "id")
        data = read_json(p)
        assert len(data["items"]) == 1
        assert data["items"][0]["name"] == "updated"

    def test_appends_if_not_found(self, tmp_path):
        p = tmp_path / "list.json"
        write_json(p, {"items": [{"id": "1"}]})
        upsert_list_item(p, {"id": "2"}, "id")
        data = read_json(p)
        assert len(data["items"]) == 2


# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------

class TestDefaultGlobalRoot:
    def test_default(self):
        root = default_global_root()
        assert root == (Path.home() / ".anyfs").resolve()

    def test_custom(self, tmp_path):
        root = default_global_root(tmp_path / "custom")
        assert root == (tmp_path / "custom").resolve()


class TestDefaultWorkspaceRoot:
    def test_returns_dotanyfs(self, tmp_path):
        root = default_workspace_root(tmp_path / "myproject")
        assert root == (tmp_path / "myproject").resolve() / ".anyfs"


# ---------------------------------------------------------------------------
# Global state initialization
# ---------------------------------------------------------------------------

class TestInitializeGlobalState:
    def test_creates_structure(self, tmp_path):
        result = initialize_global_state(tmp_path / "global")
        global_root = Path(result["global_root"])
        assert global_root.exists()
        assert (global_root / "keys").is_dir()
        assert (global_root / "db").is_dir()
        assert (global_root / "agents").is_dir()
        assert (global_root / "cache").is_dir()
        assert (global_root / "logs").is_dir()
        assert (global_root / "adapters").is_dir()

    def test_creates_identity(self, tmp_path):
        result = initialize_global_state(tmp_path / "global")
        identity = result["identity"]
        assert identity["user_id"].startswith("usr_")
        assert identity["device_id"].startswith("dev_")
        assert "created_at" in identity

    def test_creates_config(self, tmp_path):
        result = initialize_global_state(tmp_path / "global")
        config = read_json(Path(result["global_root"]) / "config.json")
        assert config["version"] == 1
        assert config["auth_token"] is None

    def test_creates_registry(self, tmp_path):
        result = initialize_global_state(tmp_path / "global")
        registry = read_json(Path(result["global_root"]) / "agents" / "registry.json")
        assert registry["agents"] == []

    def test_creates_sqlite(self, tmp_path):
        result = initialize_global_state(tmp_path / "global")
        assert (Path(result["global_root"]) / "db" / "local.db").exists()

    def test_creates_adapters_config(self, tmp_path):
        result = initialize_global_state(tmp_path / "global")
        content = (Path(result["global_root"]) / "adapters" / "config.yaml").read_text(encoding="utf-8")
        assert "default_adapter" in content

    def test_idempotent(self, tmp_path):
        r1 = initialize_global_state(tmp_path / "global")
        r2 = initialize_global_state(tmp_path / "global")
        assert r1["identity"] == r2["identity"]


# ---------------------------------------------------------------------------
# Workspace state initialization
# ---------------------------------------------------------------------------

class TestInitializeWorkspaceState:
    def test_creates_structure(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        result = initialize_workspace_state(ws)
        state_root = Path(result["workspace_root"])
        assert state_root.exists()
        assert (state_root / "state").is_dir()
        assert (state_root / "manifests").is_dir()
        assert (state_root / "staging").is_dir()
        assert (state_root / "exports").is_dir()
        assert (state_root / "logs").is_dir()

    def test_creates_workspace_json(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        result = initialize_workspace_state(ws, "openclaw")
        ws_json = read_json(Path(result["workspace_root"]) / "workspace.json")
        assert ws_json["default_adapter"] == "openclaw"

    def test_creates_state_files(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        result = initialize_workspace_state(ws)
        state_root = Path(result["workspace_root"])
        for name in ["capture.json", "snapshots.json", "backups.json", "links.json", "packages.json", "releases.json", "lineage.json"]:
            assert (state_root / "state" / name).exists()

    def test_creates_policy_yaml(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_workspace_state(ws)
        policy = (ws / ".anyfs" / "policy.yaml").read_text(encoding="utf-8")
        assert "fork_policy" in policy

    def test_default_adapter_auto(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        result = initialize_workspace_state(ws)
        assert result["default_adapter"] == "auto"

    def test_idempotent(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        r1 = initialize_workspace_state(ws, "openclaw")
        r2 = initialize_workspace_state(ws, "openclaw")
        assert r1["workspace_root"] == r2["workspace_root"]


# ---------------------------------------------------------------------------
# Agent registration
# ---------------------------------------------------------------------------

class TestRegisterAgent:
    def test_creates_agent(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        record = register_agent(tmp_path / "global", ws, "openclaw")
        assert record["agent_id"].startswith("did:key:")
        assert record["agent_type"] == "openclaw"

    def test_writes_global_agent_json(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        register_agent(tmp_path / "global", ws, "claude-code", "my-agent")
        agent = read_json(tmp_path / "global" / "agents" / "claude-code.json")
        assert agent["display_name"] == "my-agent"
        assert agent["agent_type"] == "claude-code"

    def test_updates_global_registry(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        register_agent(tmp_path / "global", ws, "openclaw")
        registry = read_json(tmp_path / "global" / "agents" / "registry.json")
        assert len(registry["agents"]) == 1

    def test_default_display_name(self, tmp_path):
        ws = tmp_path / "myproject"
        ws.mkdir()
        record = register_agent(tmp_path / "global", ws, "openclaw")
        assert "openclaw-myproject" == record["display_name"]

    def test_reuses_same_agent_type(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        first = register_agent(tmp_path / "global", ws, "openclaw", "first")
        second = register_agent(tmp_path / "global", ws, "openclaw", "second")
        registry = read_json(tmp_path / "global" / "agents" / "registry.json")
        assert len(registry["agents"]) == 1
        assert registry["agents"][0]["display_name"] == "first"
        assert first["agent_id"] == second["agent_id"]

    def test_rename_updates_global_agent_and_registry(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        register_agent(tmp_path / "global", ws, "claude-code", "first")
        renamed = rename_agent(tmp_path / "global", ws, "claude-code", "second")
        assert renamed["display_name"] == "second"
        agent = read_json(tmp_path / "global" / "agents" / "claude-code.json")
        assert agent["display_name"] == "second"
        registry = read_json(tmp_path / "global" / "agents" / "registry.json")
        assert registry["agents"][0]["display_name"] == "second"


# ---------------------------------------------------------------------------
# Config read/write
# ---------------------------------------------------------------------------

class TestConfigReadWrite:
    def test_read_after_init(self, tmp_path):
        initialize_global_state(tmp_path / "global")
        config = read_config(tmp_path / "global")
        assert config["version"] == 1

    def test_write_and_read(self, tmp_path):
        initialize_global_state(tmp_path / "global")
        write_config(tmp_path / "global", {"version": 1, "auth_email": "test@example.com"})
        config = read_config(tmp_path / "global")
        assert config["auth_email"] == "test@example.com"


# ---------------------------------------------------------------------------
# Agent remote state
# ---------------------------------------------------------------------------

class TestAgentRemoteState:
    def test_read_empty(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_workspace_state(ws)
        state = read_agent_remote_state(ws, "openclaw", tmp_path / "global")
        assert state == {}

    def test_write_and_read(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_workspace_state(ws)
        write_agent_remote_state(ws, {"agent_id": "agt_1", "status": "active"}, "openclaw", tmp_path / "global")
        state = read_agent_remote_state(ws, "openclaw", tmp_path / "global")
        assert state["agent_id"] == "agt_1"


# ---------------------------------------------------------------------------
# Capture state
# ---------------------------------------------------------------------------

class TestCaptureState:
    def test_record_and_latest(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_workspace_state(ws)
        capture = {"agent_type": "openclaw", "namespaces": ["soul"]}
        record_capture(ws, capture)
        result = latest_capture(ws)
        assert result == capture

    def test_latest_empty(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_workspace_state(ws)
        assert latest_capture(ws) == {}


# ---------------------------------------------------------------------------
# Snapshots
# ---------------------------------------------------------------------------

class TestSnapshots:
    def test_append_and_list(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_workspace_state(ws)
        append_snapshot(ws, {"snapshot_id": "snp_1", "data": "test"})
        snaps = list_snapshots(ws)
        assert len(snaps) == 1
        assert snaps[0]["snapshot_id"] == "snp_1"

    def test_latest_snapshot_id(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_workspace_state(ws)
        assert latest_snapshot_id(ws) is None
        append_snapshot(ws, {"snapshot_id": "snp_1"})
        assert latest_snapshot_id(ws) == "snp_1"
        append_snapshot(ws, {"snapshot_id": "snp_2"})
        assert latest_snapshot_id(ws) == "snp_2"

    def test_upsert_same_id(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_workspace_state(ws)
        append_snapshot(ws, {"snapshot_id": "snp_1", "version": 1})
        append_snapshot(ws, {"snapshot_id": "snp_1", "version": 2})
        snaps = list_snapshots(ws)
        assert len(snaps) == 1
        assert snaps[0]["version"] == 2


# ---------------------------------------------------------------------------
# Manifests
# ---------------------------------------------------------------------------

class TestManifests:
    def test_write_and_read(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_workspace_state(ws)
        manifest = {"snapshot_id": "snp_1", "namespaces": ["soul"]}
        path = write_manifest(ws, "snp_1", manifest)
        assert path.exists()
        result = read_manifest(ws, "snp_1")
        assert result == manifest

    def test_read_missing(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_workspace_state(ws)
        assert read_manifest(ws, "nonexistent") == {}


# ---------------------------------------------------------------------------
# Packages
# ---------------------------------------------------------------------------

class TestPackages:
    def test_append_and_list(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_workspace_state(ws)
        append_package(ws, {"package_id": "pkg_1", "name": "test"})
        pkgs = list_packages(ws)
        assert len(pkgs) == 1

    def test_upsert_same_id(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_workspace_state(ws)
        append_package(ws, {"package_id": "pkg_1", "version": 1})
        append_package(ws, {"package_id": "pkg_1", "version": 2})
        pkgs = list_packages(ws)
        assert len(pkgs) == 1
        assert pkgs[0]["version"] == 2


# ---------------------------------------------------------------------------
# Releases
# ---------------------------------------------------------------------------

class TestReleases:
    def test_append_and_list(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_workspace_state(ws)
        append_release(ws, {"release_id": "rel_1", "version": "v1.0"})
        rels = list_releases(ws)
        assert len(rels) == 1
        assert rels[0]["version"] == "v1.0"


# ---------------------------------------------------------------------------
# Lineage
# ---------------------------------------------------------------------------

class TestLineage:
    def test_append_and_query(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_workspace_state(ws)
        append_lineage(ws, {"parent_package_id": "pkg_1", "child_package_id": "pkg_2"})
        append_lineage(ws, {"parent_package_id": "pkg_1", "child_package_id": "pkg_3"})
        append_lineage(ws, {"parent_package_id": "pkg_4", "child_package_id": "pkg_5"})

        result = lineage_for_package(ws, "pkg_1")
        assert len(result) == 2

    def test_query_child(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_workspace_state(ws)
        append_lineage(ws, {"parent_package_id": "pkg_1", "child_package_id": "pkg_2"})
        result = lineage_for_package(ws, "pkg_2")
        assert len(result) == 1

    def test_query_no_match(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_workspace_state(ws)
        assert lineage_for_package(ws, "nonexistent") == []


# ---------------------------------------------------------------------------
# Backups
# ---------------------------------------------------------------------------

class TestBackups:
    def test_append_and_list(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_workspace_state(ws)
        append_backup(ws, {"backup_id": "bk_1", "snapshot_id": "snp_1"})
        backups = list_backups(ws)
        assert len(backups) == 1

    def test_upsert(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_workspace_state(ws)
        append_backup(ws, {"backup_id": "bk_1", "status": "pending"})
        append_backup(ws, {"backup_id": "bk_1", "status": "completed"})
        backups = list_backups(ws)
        assert len(backups) == 1
        assert backups[0]["status"] == "completed"


# ---------------------------------------------------------------------------
# Links
# ---------------------------------------------------------------------------

class TestLinks:
    def test_append_and_list(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_workspace_state(ws)
        append_link(ws, {"link_id": "lnk_1", "url": "http://example.com"})
        links = list_links(ws)
        assert len(links) == 1

    def test_upsert(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_workspace_state(ws)
        append_link(ws, {"link_id": "lnk_1", "active": True})
        append_link(ws, {"link_id": "lnk_1", "active": False})
        links = list_links(ws)
        assert len(links) == 1
        assert links[0]["active"] is False


# ---------------------------------------------------------------------------
# Workspace agent
# ---------------------------------------------------------------------------

class TestWorkspaceAgent:
    def test_empty(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_workspace_state(ws)
        assert workspace_agent(ws) == {}

    def test_after_register(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        global_root = tmp_path / "global"
        register_agent(global_root, ws, "openclaw")
        agent = workspace_agent(ws, global_root=global_root)
        assert agent["agent_id"].startswith("did:key:")

    def test_can_register_multiple_agent_types_per_workspace(self, tmp_path):
        ws = tmp_path / "project"
        ws.mkdir()
        global_root = tmp_path / "global"
        codex = register_agent(global_root, ws, "codex-cli")
        claude = register_agent(global_root, ws, "claude-code")
        assert workspace_agent(ws, "codex-cli", global_root)["agent_id"] == codex["agent_id"]
        assert workspace_agent(ws, "claude-code", global_root)["agent_id"] == claude["agent_id"]
        assert workspace_agent_by_id(ws, codex["agent_id"], global_root)["agent_type"] == "codex-cli"
        assert workspace_agent_private_key(ws, "claude-code", global_root)


# ---------------------------------------------------------------------------
# Doctor
# ---------------------------------------------------------------------------

class TestDoctor:
    def test_healthy_global_only(self, tmp_path):
        global_root = tmp_path / "global"
        initialize_global_state(global_root)
        # Create rootkey.enc for full health
        from anyfs_crypto import ensure_root_key
        identity = read_json(global_root / "identity.json")
        ensure_root_key(global_root, identity)

        report = doctor(global_root)
        assert report.ok is True
        assert report.checks["global_root_exists"] is True
        assert report.checks["identity_exists"] is True
        assert report.checks["root_key_exists"] is True

    def test_healthy_with_workspace(self, tmp_path):
        global_root = tmp_path / "global"
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_global_state(global_root)
        from anyfs_crypto import ensure_root_key
        identity = read_json(global_root / "identity.json")
        ensure_root_key(global_root, identity)
        register_agent(global_root, ws, "openclaw")
        record_capture(ws, {"test": True})

        report = doctor(global_root, ws)
        assert report.ok is True
        assert report.checks["workspace_root_exists"] is True
        assert report.checks["registered_agent_exists"] is True
        assert report.checks["capture_state_exists"] is True

    def test_unhealthy_missing_global(self, tmp_path):
        report = doctor(tmp_path / "nonexistent")
        assert report.ok is False

    def test_warning_when_no_registered_agent(self, tmp_path):
        global_root = tmp_path / "global"
        ws = tmp_path / "project"
        ws.mkdir()
        initialize_global_state(global_root)
        from anyfs_crypto import ensure_root_key
        identity = read_json(global_root / "identity.json")
        ensure_root_key(global_root, identity)
        initialize_workspace_state(ws)

        report = doctor(global_root, ws)
        assert "no AnyFS agent is registered on this machine" in report.warnings
