"""Unit tests for anyfs_lineage package."""
from __future__ import annotations

from datetime import datetime, timezone

from anyfs_lineage import make_lineage_record
from anyfs_schemas import LineageRecord


class TestMakeLineageRecord:
    def test_creates_record(self):
        record = make_lineage_record("pkg_parent", "pkg_child")
        assert isinstance(record, LineageRecord)
        assert record.parent_package_id == "pkg_parent"
        assert record.child_package_id == "pkg_child"

    def test_has_created_at(self):
        record = make_lineage_record("pkg_1", "pkg_2")
        assert isinstance(record.created_at, datetime)
        assert record.created_at.tzinfo == timezone.utc

    def test_different_records(self):
        r1 = make_lineage_record("pkg_a", "pkg_b")
        r2 = make_lineage_record("pkg_c", "pkg_d")
        assert r1.parent_package_id != r2.parent_package_id
        assert r1.child_package_id != r2.child_package_id

    def test_model_dump(self):
        record = make_lineage_record("pkg_1", "pkg_2")
        data = record.model_dump()
        assert data["parent_package_id"] == "pkg_1"
        assert data["child_package_id"] == "pkg_2"
        assert "created_at" in data
