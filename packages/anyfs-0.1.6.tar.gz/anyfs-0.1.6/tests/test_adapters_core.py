"""Unit tests for anyfs_adapters_core package."""
from __future__ import annotations

from pathlib import Path

import pytest

from anyfs_adapters_core import classify_by_path, read_text_file, AgentAdapter
from anyfs_schemas import Namespace


# ---------------------------------------------------------------------------
# classify_by_path
# ---------------------------------------------------------------------------

class TestClassifyByPath:
    def test_soul(self):
        assert classify_by_path(Path("state/soul.json")) == Namespace.SOUL
        assert classify_by_path(Path("data/my_soul_config.yaml")) == Namespace.SOUL

    def test_user(self):
        assert classify_by_path(Path("user/preferences.json")) == Namespace.USER
        assert classify_by_path(Path("data/profile.json")) == Namespace.USER

    def test_memory(self):
        assert classify_by_path(Path("memory/notes.md")) == Namespace.MEMORY
        assert classify_by_path(Path("data/session.json")) == Namespace.MEMORY

    def test_skills(self):
        assert classify_by_path(Path("skills/coding.md")) == Namespace.SKILLS
        assert classify_by_path(Path("data/instruction.txt")) == Namespace.SKILLS
        assert classify_by_path(Path("prompts/system.md")) == Namespace.SKILLS

    def test_skills_claude_md(self):
        assert classify_by_path(Path("claude.md")) == Namespace.SKILLS
        assert classify_by_path(Path("project/claude.md")) == Namespace.SKILLS

    def test_process(self):
        assert classify_by_path(Path("process/steps.json")) == Namespace.PROCESS
        assert classify_by_path(Path("logs/app.log")) == Namespace.PROCESS
        assert classify_by_path(Path("data/trace.json")) == Namespace.PROCESS

    def test_artifacts_fallback(self):
        assert classify_by_path(Path("output/report.pdf")) == Namespace.ARTIFACTS
        assert classify_by_path(Path("data/results.csv")) == Namespace.ARTIFACTS
        assert classify_by_path(Path("README.md")) == Namespace.ARTIFACTS

    def test_case_insensitive(self):
        assert classify_by_path(Path("STATE/SOUL.json")) == Namespace.SOUL
        assert classify_by_path(Path("Memory/NOTES.md")) == Namespace.MEMORY

    def test_nested_paths(self):
        assert classify_by_path(Path("deep/nested/soul/config.json")) == Namespace.SOUL
        assert classify_by_path(Path("a/b/c/memory/d/file.txt")) == Namespace.MEMORY


# ---------------------------------------------------------------------------
# read_text_file
# ---------------------------------------------------------------------------

class TestReadTextFile:
    def test_reads_utf8(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("hello world", encoding="utf-8")
        assert read_text_file(f) == "hello world"

    def test_reads_unicode(self, tmp_path):
        f = tmp_path / "unicode.txt"
        f.write_text("Hello 世界 🌍", encoding="utf-8")
        assert read_text_file(f) == "Hello 世界 🌍"

    def test_reads_binary_with_fallback(self, tmp_path):
        f = tmp_path / "binary.txt"
        # Write some bytes that aren't valid UTF-8
        f.write_bytes(b"hello \xff\xfe world")
        result = read_text_file(f)
        assert "hello" in result
        assert "world" in result

    def test_empty_file(self, tmp_path):
        f = tmp_path / "empty.txt"
        f.write_text("", encoding="utf-8")
        assert read_text_file(f) == ""

    def test_multiline(self, tmp_path):
        f = tmp_path / "multi.txt"
        content = "line1\nline2\nline3"
        f.write_text(content, encoding="utf-8")
        assert read_text_file(f) == content


# ---------------------------------------------------------------------------
# AgentAdapter protocol
# ---------------------------------------------------------------------------

class TestAgentAdapterProtocol:
    def test_protocol_attributes(self):
        # Verify protocol defines expected methods
        assert hasattr(AgentAdapter, "discover")
        assert hasattr(AgentAdapter, "extract")
        assert hasattr(AgentAdapter, "normalize")
        assert hasattr(AgentAdapter, "bundle")
