def main():
    print("""
================================================================================
                    PYTORCH SYNTAX & DEBUGGING GUIDE
================================================================================

------------------------- 1. ESSENTIAL SYNTAX -------------------------

[ DEVICE MANAGEMENT ]
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
# For Mac M1/M2/M3:
device = torch.device('mps' if torch.backends.mps.is_available() else 'cpu')
model.to(device)
data = data.to(device)

[ TENSOR BASICS ]
x = torch.tensor([1, 2, 3], dtype=torch.float32)
x.shape          # Get dimensions
x.size()         # Same as .shape
x.view(1, -1)    # Reshape (similar to numpy.reshape)
x.squeeze()      # Remove dimensions of size 1
x.unsqueeze(0)   # Add dimension of size 1 at index 0

[ THE TRAINING LOOP ]
optimizer.zero_grad()   # 1. Clear old gradients
outputs = model(inputs) # 2. Forward pass
loss = criterion(outputs, targets) # 3. Compute loss
loss.backward()         # 4. Backpropagation
optimizer.step()        # 5. Update weights

------------------------- 2. DEBUGGING TIPS -------------------------

[ TIP #1: SHAPE MISMATCH ]
# Most common error! Print shapes before every major operation:
print(f"Input shape: {x.shape}")
out = model(x)
print(f"Output shape: {out.shape}")

[ TIP #2: DEVICE ERRORS ]
# Error: "Expected all tensors to be on the same device"
# Fix: Ensure BOTH the model and the input tensor are on 'device'.
print(next(model.parameters()).device) # Check model device
print(my_tensor.device)                # Check tensor device

[ TIP #3: GRADIENT VANISHING/EXPLODING ]
# If Loss = NaN:
# 1. Lower the Learning Rate.
# 2. Check for division by zero in custom loss.
# 3. Use Gradient Clipping:
torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)

[ TIP #4: MEMORY LEAKS ]
# During evaluation/inference, ALWAYS use torch.no_grad():
with torch.no_grad():
    model.eval()
    outputs = model(val_inputs)

[ TIP #5: DATA LEAKAGE ]
# Ensure you aren't calling 'scaler.fit()' on your test data.
# ONLY 'fit' on train, then 'transform' on test.

------------------------- 3. USEFUL SNIPPETS -------------------------

# Count trainable parameters:
params = sum(p.numel() for p in model.parameters() if p.requires_grad)
print(f"Total Parameters: {params:,}")

# Check if model is in training mode:
print(f"Is training: {model.training}")
""")

if __name__ == '__main__':
    main()
