def main():
    print("""import torch
import torch.nn as nn
import torch.optim as optim

class ConfigurableMLP(nn.Module):
    \"\"\"
    A generalized Multi-Layer Perceptron that can be configured with 
    arbitrary layer sizes, activations, and dropout rates.
    \"\"\"
    def __init__(self, input_size, hidden_layers, output_size, dropout_rate=0.0, activation=nn.ReLU()):
        super(ConfigurableMLP, self).__init__()
        
        layers = []
        in_dim = input_size
        
        for h_dim in hidden_layers:
            layers.append(nn.Linear(in_dim, h_dim))
            layers.append(activation)
            if dropout_rate > 0:
                layers.append(nn.Dropout(dropout_rate))
            in_dim = h_dim
            
        layers.append(nn.Linear(in_dim, output_size))
        self.model = nn.Sequential(*layers)
        
    def forward(self, x):
        return self.model(x)

def train_model(model, train_loader, criterion, optimizer, device, epochs=10):
    \"\"\"Generalized training loop.\"\"\"
    model.to(device)
    for epoch in range(epochs):
        model.train()
        running_loss = 0.0
        for inputs, targets in train_loader:
            inputs, targets = inputs.to(device), targets.to(device)
            
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()
            
            running_loss += loss.item()
        print(f"Epoch {epoch+1}/{epochs}, Loss: {running_loss/len(train_loader):.4f}")

if __name__ == '__main__':
    print(\"Configuration for a 2-hidden layer MLP (64, 32 units) with Dropout:\")
    model = ConfigurableMLP(input_size=10, hidden_layers=[64, 32], output_size=1, dropout_rate=0.2)
    print(model)""")

if __name__ == '__main__':
    main()
