def main():
    index_text = """
================================================================================
                         DEEP LEARNING EXPERIMENTS INDEX
================================================================================

--------------------------- SPECIFIC EXPERIMENTS ---------------------------
(Based on individual datasets and notebooks)

1.  MLP (NumPy) Binary Classification    : mlp_numpy_binary_classification.py
2.  MLP (PyTorch) Binary Classification  : mlp_pytorch_binary_classification.py
3.  NN Backprop (MNIST)                  : nn_mnist_backpropagation.py
4.  Regularization (Dropout, L2)         : regularization_dropout_l2.py
5.  CNN Image Classification             : cnn_pytorch_image_classification.py
6.  ResNet Finetuning                    : resnet_finetuning.py
7.  RNN Sentiment Analysis               : rnn_sentiment_analysis.py
8.  LSTM Time-Series Forecasting         : lstm_timeseries_forecasting.py
9.  Attention-based Transformer          : attention_transformer_nlp.py
10. VAE Synthetic Data                   : vae_synthetic_data.py
11. GAN Synthetic Images                 : gan_synthetic_images.py
12. Transfer Learning (MobileNet)        : transfer_learning_mobilenet.py

---------------------------- GENERALIZED MODELS ----------------------------
(Flexible frameworks for any dataset)

13. Generalized MLP Framework            : generalized_mlp_framework.py
14. Generalized Sequence Framework       : generalized_sequence_framework.py
    (Supports RNN, LSTM, GRU)
15. Generalized Transfer Learning Wrapper : generalized_transfer_learning_wrapper.py
    (Supports any torchvision model)

----------------------- GUIDES & DEBUGGING TOOLS -----------------------

16. PyTorch Syntax & Debugging Guide     : pytorch_debugging_guide.py
17. Activation/Loss Comparison           : activation_loss_comparison.py
18. CNN Evaluation                       : cnn_evaluation.py

================================================================================
"""
    print(index_text)

if __name__ == '__main__':
    main()
