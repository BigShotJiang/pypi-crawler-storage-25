def main():
    print("""import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
import numpy as np

# 1. Hyperparameters
batch_size = 64
lr = 0.0002
latent_dim = 100
epochs = 50
device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")

# 2. Data Preparation (MNIST)
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.5,), (0.5,))
])

train_dataset = datasets.MNIST(root='./data', train=True, transform=transform, download=True)
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)

# 3. Define Generator
class Generator(nn.Module):
    def __init__(self):
        super(Generator, self).__init__()
        self.main = nn.Sequential(
            nn.Linear(latent_dim, 256),
            nn.LeakyReLU(0.2),
            nn.Linear(256, 512),
            nn.LeakyReLU(0.2),
            nn.Linear(512, 1024),
            nn.LeakyReLU(0.2),
            nn.Linear(1024, 784),
            nn.Tanh()
        )

    def forward(self, x):
        return self.main(x).view(-1, 1, 28, 28)

# 4. Define Discriminator
class Discriminator(nn.Module):
    def __init__(self):
        super(Discriminator, self).__init__()
        self.main = nn.Sequential(
            nn.Linear(784, 512),
            nn.LeakyReLU(0.2),
            nn.Linear(512, 256),
            nn.LeakyReLU(0.2),
            nn.Linear(256, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        x = x.view(-1, 784)
        return self.main(x)

netG = Generator().to(device)
netD = Discriminator().to(device)

criterion = nn.BCELoss()
optimizerG = optim.Adam(netG.parameters(), lr=lr)
optimizerD = optim.Adam(netD.parameters(), lr=lr)

# 5. Training Loop
for epoch in range(epochs):
    for i, (real_imgs, _) in enumerate(train_loader):
        # --- Train Discriminator ---
        netD.zero_grad()
        real_imgs = real_imgs.to(device)
        batch_size_curr = real_imgs.size(0)
        
        # Real labels
        label = torch.full((batch_size_curr, 1), 1.0, device=device)
        output = netD(real_imgs)
        errD_real = criterion(output, label)
        errD_real.backward()
        
        # Fake labels
        noise = torch.randn(batch_size_curr, latent_dim, device=device)
        fake_imgs = netG(noise)
        label.fill_(0.0)
        output = netD(fake_imgs.detach())
        errD_fake = criterion(output, label)
        errD_fake.backward()
        optimizerD.step()
        
        # --- Train Generator ---
        netG.zero_grad()
        label.fill_(1.0) # Generator wants discriminator to think fake is real
        output = netD(fake_imgs)
        errG = criterion(output, label)
        errG.backward()
        optimizerG.step()
        
    print(f'Epoch [{epoch+1}/{epochs}] Loss D: {errD_real+errD_fake:.4f}, Loss G: {errG:.4f}')

# 6. Generate and Visualize Images
with torch.no_grad():
    noise = torch.randn(16, latent_dim, device=device)
    fake_imgs = netG(noise).cpu().detach()
    
    plt.figure(figsize=(8,8))
    for i in range(16):
        plt.subplot(4, 4, i+1)
        plt.imshow(fake_imgs[i][0], cmap='gray')
        plt.axis('off')
    plt.show()""")

if __name__ == '__main__':
    main()
