def main():
    print("""import torch
import torch.nn as nn

class SequenceModel(nn.Module):
    \"\"\"
    A generalized sequence model that supports RNN, LSTM, and GRU architectures.
    \"\"\"
    def __init__(self, model_type, vocab_size, embed_dim, hidden_dim, output_dim, num_layers=1, bidirectional=False):
        super(SequenceModel, self).__init__()
        
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        
        # Choose architecture
        if model_type.upper() == 'RNN':
            self.rnn = nn.RNN(embed_dim, hidden_dim, num_layers, batch_first=True, bidirectional=bidirectional)
        elif model_type.upper() == 'LSTM':
            self.rnn = nn.LSTM(embed_dim, hidden_dim, num_layers, batch_first=True, bidirectional=bidirectional)
        elif model_type.upper() == 'GRU':
            self.rnn = nn.GRU(embed_dim, hidden_dim, num_layers, batch_first=True, bidirectional=bidirectional)
        else:
            raise ValueError("model_type must be 'RNN', 'LSTM', or 'GRU'")
            
        multiplier = 2 if bidirectional else 1
        self.fc = nn.Linear(hidden_dim * multiplier, output_dim)
        
    def forward(self, x):
        # x shape: (batch, seq_len)
        embedded = self.embedding(x)
        
        # rnn_out shape: (batch, seq_len, hidden_dim * num_directions)
        out, _ = self.rnn(embedded)
        
        # Take the last hidden state for classification
        last_hidden = out[:, -1, :]
        return self.fc(last_hidden)

if __name__ == '__main__':
    print(\"Creating a Bidirectional GRU model:\")
    model = SequenceModel(model_type='GRU', vocab_size=5000, embed_dim=128, hidden_dim=256, output_dim=1, bidirectional=True)
    print(model)""")

if __name__ == '__main__':
    main()
