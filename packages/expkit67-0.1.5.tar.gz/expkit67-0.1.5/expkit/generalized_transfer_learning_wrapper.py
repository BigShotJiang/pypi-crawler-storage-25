def main():
    print("""import torch
import torch.nn as nn
import torchvision.models as models

class TransferLearningWrapper(nn.Module):
    \"\"\"
    Generalized wrapper to perform transfer learning on any Torchvision model.
    \"\"\"
    def __init__(self, model_name='resnet18', num_classes=2, freeze_features=True):
        super(TransferLearningWrapper, self).__init__()
        
        # Load base model
        if hasattr(models, model_name):
            self.base_model = getattr(models, model_name)(weights='DEFAULT')
        else:
            raise ValueError(f"Model {model_name} not found in torchvision.models")
            
        # Freeze parameters if requested
        if freeze_features:
            for param in self.base_model.parameters():
                param.requires_grad = False
                
        # Handle different architectures for head replacement
        if hasattr(self.base_model, 'fc'): # ResNet, etc.
            in_features = self.base_model.fc.in_features
            self.base_model.fc = nn.Linear(in_features, num_classes)
        elif hasattr(self.base_model, 'classifier'): # MobileNet, VGG, etc.
            if isinstance(self.base_model.classifier, nn.Sequential):
                in_features = self.base_model.classifier[-1].in_features
                self.base_model.classifier[-1] = nn.Linear(in_features, num_classes)
            else:
                in_features = self.base_model.classifier.in_features
                self.base_model.classifier = nn.Linear(in_features, num_classes)
                
    def forward(self, x):
        return self.base_model(x)

if __name__ == '__main__':
    print(\"Loading ResNet18 for a 5-class classification task:\")
    model = TransferLearningWrapper(model_name='resnet18', num_classes=5)
    print(model)
    
    print(\"\\nLoading MobileNetV2 for a 10-class task:\")
    model_v2 = TransferLearningWrapper(model_name='mobilenet_v2', num_classes=10)
    print(model_v2.base_model.classifier)""")

if __name__ == '__main__':
    main()
