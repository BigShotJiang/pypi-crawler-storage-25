def main():
    print("""import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader

from datasets import load_dataset

dataset = load_dataset("imdb", cache_dir="./data")
train_data = dataset["train"]
test_data = dataset["test"]

from transformers import AutoTokenizer
tokeniser = AutoTokenizer.from_pretrained("bert-base-uncased")

def tokenize(example):
    return tokeniser(
        example["text"],
        padding="max_length",
        truncation=True,
        max_length=200
    )

train_data = train_data.map(tokenize,batched=True)

test_data = test_data.map(tokenize,batched=True)

train_data.set_format(type="torch",columns=["input_ids","attention_mask","label"])
test_data.set_format(type="torch", columns=["input_ids", "attention_mask", "label"])

from torch.utils.data import DataLoader

train_loader = DataLoader(train_data,batch_size=64,shuffle=True)
test_loader = DataLoader(test_data, batch_size=64)

import torch
import torch.nn as nn

print("\\n[INFO] Initializing model...")

class LSTMModel(nn.Module):
    def __init__(self, vocab_size, embed_dim, hidden_dim):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        self.lstm = nn.LSTM(embed_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, 1)

    def forward(self, input_ids):
        x = self.embedding(input_ids)
        _, (hidden, _) = self.lstm(x)
        out = self.fc(hidden[-1])
        return out.squeeze()



device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")
print(device)

model = LSTMModel(tokeniser.vocab_size,128,128).to(device)
criterion = nn.BCEWithLogitsLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

model

train_losses = []
test_accuracies = []

def train(model, loader):
    model.train()
    total_loss = 0

    print("\\n[TRAIN] Starting training epoch...")

    for i, batch in enumerate(loader):
        input_ids = batch["input_ids"].to(device)
        labels = batch["label"].float().to(device)

        optimizer.zero_grad()
        outputs = model(input_ids)

        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

        if i % 100 == 0:
            print(f"[TRAIN] Batch {i}/{len(loader)} | Loss: {loss.item():.4f}")

    avg_loss = total_loss / len(loader)
    print(f"[TRAIN] Epoch complete | Avg Loss: {avg_loss:.4f}")

    return avg_loss

def evaluate(model, loader):
    model.eval()
    correct = 0
    total = 0

    print("\\n[EVAL] Evaluating model...")

    with torch.no_grad():
        for i, batch in enumerate(loader):
            input_ids = batch["input_ids"].to(device)
            labels = batch["label"].to(device)

            outputs = model(input_ids)
            preds = (torch.sigmoid(outputs) >= 0.5).long()

            correct += (preds == labels).sum().item()
            total += labels.size(0)

            if i % 100 == 0:
                print(f"[EVAL] Processed {i}/{len(loader)} batches")

    acc = correct / total
    print(f"[EVAL] Accuracy: {acc:.4f}")

    return acc

EPOCHS = 10

print("\\n[INFO] Starting training process...")

for epoch in range(EPOCHS):
    print(f"\\n========== Epoch {epoch+1}/{EPOCHS} ==========")

    loss = train(model, train_loader)
    acc = evaluate(model, test_loader)

    train_losses.append(loss)
    test_accuracies.append(acc)

    print(f"[RESULT] Epoch {epoch+1} | Loss: {loss:.4f} | Accuracy: {acc:.4f}")

import matplotlib.pyplot as plt

plt.figure()
plt.plot(train_losses)
plt.title("Training Loss vs Epochs")
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.show()

plt.figure()
plt.plot(test_accuracies)
plt.title("Test Accuracy vs Epochs")
plt.xlabel("Epoch")
plt.ylabel("Accuracy")
plt.show()

def predict(text):
    inputs = tokeniser(
        text,
        return_tensors="pt",
        truncation=True,
        padding=True,
        max_length=200
    )
    
    input_ids = inputs["input_ids"].to(device)

    with torch.no_grad():
        output = model(input_ids)
        prob = torch.sigmoid(output).item()

    sentiment = "Positive" if prob >= 0.5 else "Negative"
    return sentiment, prob

import random

def show_examples(dataset, n=10):
    print("\\n[EXAMPLES]")
    for i in random.sample(range(len(dataset)), n):
        text = dataset[i]["text"]
        true_label = dataset[i]["label"]

        pred_label, prob = predict(text)

        print("\\n-----------------------------")
        print(f"Text: {text[:200]}...")
        print(f"True: {'Positive' if true_label==1 else 'Negative'}")
        print(f"Pred: {pred_label} ({prob:.3f})")

show_examples(dataset["test"], 5)""")

if __name__ == '__main__':
    main()
