def main():
    print("""import torch

import kagglehub

path = kagglehub.dataset_download("jacksoncrow/stock-market-dataset")


print("Path to dataset files:", path)

import os

print(os.listdir(path))
print(len(os.listdir(path)))

path

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


import pandas as pd

file_path = path + "/stocks/AAPL.csv"   # change filename based on output above
df = pd.read_csv(file_path)
df = df.sort_values('Date')
df.head()

data = df[['Close']].values

split = int(0.8 * len(data))

train_data = data[:split]
test_data = data[split:]

from sklearn.preprocessing import MinMaxScaler

scaler = MinMaxScaler()

train_scaled = scaler.fit_transform(train_data)
test_scaled = scaler.transform(test_data)

import numpy as np
def create_sequences(data, seq_length=100):
    X, y = [], []
    for i in range(len(data) - seq_length):
        X.append(data[i:i+seq_length])
        y.append(data[i+seq_length])
    return np.array(X), np.array(y)

X_train, y_train = create_sequences(train_scaled)
X_test, y_test = create_sequences(test_scaled)

import torch

X_train = torch.tensor(X_train, dtype=torch.float32).to(device)
y_train = torch.tensor(y_train, dtype=torch.float32).to(device)

X_test = torch.tensor(X_test, dtype=torch.float32).to(device)
y_test = torch.tensor(y_test, dtype=torch.float32).to(device)

import torch.nn as nn

class LSTMModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.lstm = nn.LSTM(
            input_size=1,
            hidden_size=128,
            num_layers=2,
            dropout=0.2,
            batch_first=True
        )
        self.fc = nn.Linear(128, 1)

    def forward(self, x):
        out, _ = self.lstm(x)
        out = out[:, -1, :]
        return self.fc(out)

model = LSTMModel().to(device)

criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

epochs = 500
for epoch in range(epochs):
    model.train()
    
    outputs = model(X_train)
    loss = criterion(outputs, y_train)
    
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    
    print(f"Epoch {epoch+1}, Loss: {loss.item():.6f}")

model.eval()

with torch.no_grad():
    predictions = model(X_test).cpu().numpy()
predictions = scaler.inverse_transform(predictions)
y_test_actual = scaler.inverse_transform(y_test.cpu().numpy())

import matplotlib.pyplot as plt

plt.plot(y_test_actual, label="Actual")
plt.plot(predictions, label="Predicted")
plt.legend()
plt.show()

import numpy as np
from sklearn.metrics import mean_squared_error, mean_absolute_error

rmse = np.sqrt(mean_squared_error(y_test_actual, predictions))
mae = mean_absolute_error(y_test_actual, predictions)

print(f"RMSE: {rmse}")
print(f"MAE: {mae}")

print("Pred sample:", predictions[:5])
print("Actual sample:", y_test_actual[:5])""")

if __name__ == '__main__':
    main()
