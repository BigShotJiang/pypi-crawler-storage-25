"""DDL SQL resources."""
