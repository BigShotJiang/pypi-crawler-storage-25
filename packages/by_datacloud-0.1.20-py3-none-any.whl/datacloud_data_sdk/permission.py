"""Third-party data permission protocol and enforcement helpers."""

from __future__ import annotations

import hashlib
import logging
import re
import time
from collections.abc import Awaitable
from dataclasses import dataclass, field
from typing import Any, Literal, Protocol, cast, runtime_checkable

from datacloud_data_sdk.context import RequestContext, get_current_context
from datacloud_data_sdk.exceptions import PermissionDeniedError, PermissionNotConfiguredError

logger = logging.getLogger(__name__)

PermissionMode = Literal["enforce", "disabled"]
ScopeType = Literal["object", "view", "action", "function"]
Operation = Literal[
    "describe",
    "query",
    "analyze",
    "lookup",
    "search",
    "api_call",
    "script",
    "tool_list",
]
FieldEffect = Literal["allow", "deny", "mask"]
ParamEffect = Literal["allow", "deny", "readonly", "fixed_value"]
MaskType = Literal["null", "fixed", "partial", "hash"]
PredicateOp = Literal[
    "and",
    "or",
    "not",
    "eq",
    "ne",
    "gt",
    "gte",
    "lt",
    "lte",
    "in",
    "between",
    "like",
    "is_null",
]


@dataclass(frozen=True)
class PermissionIdentity:
    """Request identity passed to external permission providers."""

    tenant_id: str = ""
    user_id: str = ""
    system_code: str = ""
    session_id: str = ""
    token: str = field(default="", repr=False)


@dataclass(frozen=True)
class FieldPermissionRule:
    """Column-level permission rule."""

    field_code: str
    effect: FieldEffect = "allow"
    mask_type: MaskType = "null"
    mask_value: Any = None


@dataclass(frozen=True)
class ParamPermissionRule:
    """Action input parameter permission rule."""

    param_code: str
    effect: ParamEffect = "allow"
    location: Literal["path", "query", "headers", "body"] | None = None
    physical_key: str | None = None
    fixed_value: Any = None
    allowed_values: tuple[Any, ...] | None = None
    value_range: tuple[float | None, float | None] | None = None
    regex: str | None = None
    max_items: int | None = None


@dataclass(frozen=True)
class RowPredicate:
    """Abstract row predicate AST returned by permission providers."""

    op: PredicateOp
    field: str | None = None
    value: Any = None
    children: tuple[RowPredicate, ...] = ()


@dataclass(frozen=True)
class PermissionRequest:
    """Base permission request delivered to third-party providers."""

    identity: PermissionIdentity
    scope_type: ScopeType
    scope_code: str
    operation: Operation
    action_code: str = ""
    fields: tuple[str, ...] = ()
    params: dict[str, Any] = field(default_factory=dict)
    filters: Any = None
    api_locations: dict[str, tuple[str, str]] = field(default_factory=dict)
    plan_context: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ActionPermissionRequest(PermissionRequest):
    """Action authorization request."""


@dataclass(frozen=True)
class FieldPermissionRequest(PermissionRequest):
    """Field authorization request."""


@dataclass(frozen=True)
class RowPermissionRequest(PermissionRequest):
    """Row authorization request."""


@dataclass(frozen=True)
class ParamPermissionRequest(PermissionRequest):
    """Parameter authorization request."""


@dataclass(frozen=True)
class ToolPermissionRequest(PermissionRequest):
    """Tool-list authorization request."""

    tools: tuple[str, ...] = ()


@dataclass(frozen=True)
class PermissionDecision:
    """Base permission decision."""

    allowed: bool = True
    reason_code: str = "ok"
    message: str = ""
    obligations: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ActionDecision(PermissionDecision):
    """Action permission decision."""


@dataclass(frozen=True)
class FieldDecision(PermissionDecision):
    """Field permission decision."""

    field_rules: tuple[FieldPermissionRule, ...] = ()


@dataclass(frozen=True)
class RowDecision(PermissionDecision):
    """Row permission decision."""

    row_rules: tuple[RowPredicate, ...] = ()


@dataclass(frozen=True)
class ParamDecision(PermissionDecision):
    """Parameter permission decision."""

    param_rules: tuple[ParamPermissionRule, ...] = ()


@dataclass(frozen=True)
class ToolDecision(PermissionDecision):
    """Tool-list permission decision."""

    allowed_tools: tuple[str, ...] = ()


@runtime_checkable
class PermissionProvider(Protocol):
    """Protocol implemented by third-party permission systems."""

    async def authorize_action(self, request: ActionPermissionRequest) -> ActionDecision: ...

    async def authorize_fields(self, request: FieldPermissionRequest) -> FieldDecision: ...

    async def authorize_rows(self, request: RowPermissionRequest) -> RowDecision: ...

    async def authorize_params(self, request: ParamPermissionRequest) -> ParamDecision: ...

    async def filter_tools(self, request: ToolPermissionRequest) -> ToolDecision: ...


def is_permission_enabled(loader: Any) -> bool:
    """Return whether permission enforcement is enabled for a loader."""
    config = getattr(loader, "_config", None)
    return bool(config and getattr(config, "permission_mode", "disabled") != "disabled")


def get_permission_provider(loader: Any) -> PermissionProvider | None:
    """Return the configured permission provider, validating fail-closed mode."""
    config = getattr(loader, "_config", None)
    if config is None or getattr(config, "permission_mode", "disabled") == "disabled":
        return None
    provider = getattr(config, "permission_provider", None)
    if provider is None:
        raise PermissionNotConfiguredError()
    return cast(PermissionProvider, provider)


def get_identity() -> PermissionIdentity:
    """Build permission identity from the current invocation context."""
    try:
        ctx = get_current_context()
    except Exception:
        ctx = RequestContext()
    return PermissionIdentity(
        tenant_id=ctx.tenant_id,
        user_id=ctx.user_id,
        system_code=ctx.system_code,
        session_id=ctx.session_id,
        token=ctx.token,
    )


async def authorize_action(
    loader: Any,
    *,
    scope_type: ScopeType,
    scope_code: str,
    operation: Operation,
    action_code: str = "",
    params: dict[str, Any] | None = None,
) -> ActionDecision:
    """Authorize action execution or visibility."""
    provider = get_permission_provider(loader)
    if provider is None:
        return ActionDecision()
    request = ActionPermissionRequest(
        identity=get_identity(),
        scope_type=scope_type,
        scope_code=scope_code,
        operation=operation,
        action_code=action_code,
        params=params or {},
    )
    decision = await _timed_call("authorize_action", provider.authorize_action(request))
    _ensure_allowed(decision, resource=action_code or scope_code)
    return decision


async def authorize_params(
    loader: Any,
    *,
    scope_type: ScopeType,
    scope_code: str,
    operation: Operation,
    action_code: str,
    params: dict[str, Any],
    api_locations: dict[str, tuple[str, str]] | None = None,
) -> dict[str, Any]:
    """Authorize and rewrite action parameters."""
    provider = get_permission_provider(loader)
    if provider is None:
        return params
    request = ParamPermissionRequest(
        identity=get_identity(),
        scope_type=scope_type,
        scope_code=scope_code,
        operation=operation,
        action_code=action_code,
        params=dict(params),
        api_locations=api_locations or {},
    )
    decision = await _timed_call("authorize_params", provider.authorize_params(request))
    _ensure_allowed(decision, resource=action_code)
    return apply_param_rules(params, decision.param_rules)


async def authorize_rows(
    loader: Any,
    *,
    scope_type: ScopeType,
    scope_code: str,
    operation: Operation,
    action_code: str = "",
    filters: Any = None,
) -> tuple[RowPredicate, ...]:
    """Authorize row access and return provider predicates."""
    provider = get_permission_provider(loader)
    if provider is None:
        return ()
    request = RowPermissionRequest(
        identity=get_identity(),
        scope_type=scope_type,
        scope_code=scope_code,
        operation=operation,
        action_code=action_code,
        filters=filters,
    )
    decision = await _timed_call("authorize_rows", provider.authorize_rows(request))
    _ensure_allowed(decision, resource=scope_code)
    return decision.row_rules


async def authorize_fields(
    loader: Any,
    *,
    scope_type: ScopeType,
    scope_code: str,
    operation: Operation,
    fields: list[str],
    action_code: str = "",
) -> FieldDecision:
    """Authorize field access."""
    provider = get_permission_provider(loader)
    if provider is None:
        return FieldDecision()
    request = FieldPermissionRequest(
        identity=get_identity(),
        scope_type=scope_type,
        scope_code=scope_code,
        operation=operation,
        action_code=action_code,
        fields=tuple(fields),
    )
    decision = await _timed_call("authorize_fields", provider.authorize_fields(request))
    _ensure_allowed(decision, resource=scope_code)
    return decision


def apply_field_rules_to_records(
    records: list[dict[str, Any]],
    field_rules: tuple[FieldPermissionRule, ...],
) -> list[dict[str, Any]]:
    """Apply deny/mask field rules to result records."""
    if not field_rules:
        return records
    rule_map = _effective_field_rules(field_rules)
    sanitized: list[dict[str, Any]] = []
    for record in records:
        next_record = dict(record)
        for field_code, rule in rule_map.items():
            if rule.effect == "deny":
                next_record.pop(field_code, None)
            elif rule.effect == "mask" and field_code in next_record:
                next_record[field_code] = _mask_value(next_record[field_code], rule)
        sanitized.append(next_record)
    return sanitized


def apply_field_rules_to_meta(
    meta: dict[str, Any],
    field_rules: tuple[FieldPermissionRule, ...],
) -> dict[str, Any]:
    """Remove denied fields from metadata columns."""
    if not field_rules:
        return meta
    denied = {rule.field_code for rule in field_rules if rule.effect == "deny"}
    if not denied:
        return meta
    next_meta = dict(meta)
    columns = next_meta.get("columns")
    if isinstance(columns, list):
        next_meta["columns"] = [col for col in columns if _column_name(col) not in denied]
    return next_meta


def apply_param_rules(
    params: dict[str, Any],
    param_rules: tuple[ParamPermissionRule, ...],
) -> dict[str, Any]:
    """Validate and rewrite parameters according to provider rules."""
    if not param_rules:
        return params
    next_params = dict(params)
    for rule in param_rules:
        present = rule.param_code in next_params
        value = next_params.get(rule.param_code)
        if rule.effect == "deny" and present:
            raise PermissionDeniedError(rule.param_code, "param_denied", "Parameter is denied")
        if rule.effect == "readonly" and present:
            raise PermissionDeniedError(rule.param_code, "param_readonly", "Parameter is readonly")
        if rule.effect == "fixed_value":
            next_params[rule.param_code] = rule.fixed_value
            value = rule.fixed_value
            present = True
        if not present:
            continue
        _validate_param_value(rule, value)
    return next_params


def filter_denied_fields_from_params(
    params: dict[str, Any],
    denied_fields: set[str],
) -> dict[str, Any]:
    """Remove denied field references from common virtual-action parameters."""
    if not denied_fields:
        return params
    next_params = dict(params)
    for key in ("select", "group_by"):
        values = next_params.get(key)
        if isinstance(values, list):
            next_params[key] = [value for value in values if value not in denied_fields]
    for key in ("filters", "order_by", "dimensions", "metrics"):
        values = next_params.get(key)
        if isinstance(values, list):
            next_params[key] = [
                item
                for item in values
                if not isinstance(item, dict) or item.get("field") not in denied_fields
            ]
    filters = next_params.get("filters")
    if isinstance(filters, dict):
        next_params["filters"] = {
            field_code: spec
            for field_code, spec in filters.items()
            if field_code not in denied_fields
        }
    return next_params


def predicates_to_filter_dict(predicates: tuple[RowPredicate, ...]) -> dict[str, Any]:
    """Convert simple row predicates to DynamicQueryExecutor filter dict."""
    filters: dict[str, Any] = {}
    for predicate in predicates:
        _append_filter_dict(filters, predicate)
    return filters


def predicates_to_filter_list(predicates: tuple[RowPredicate, ...]) -> list[dict[str, Any]]:
    """Convert simple row predicates to virtual-action filter list."""
    filters: list[dict[str, Any]] = []
    for predicate in predicates:
        _append_filter_list(filters, predicate)
    return filters


def filter_records_by_predicates(
    records: list[dict[str, Any]], predicates: tuple[RowPredicate, ...]
) -> list[dict[str, Any]]:
    """Apply row predicates in memory for API/script result filtering."""
    if not predicates:
        return records
    return [
        record for record in records if all(_eval_predicate(record, item) for item in predicates)
    ]


def merge_filter_dict(filters: Any, permission_filters: dict[str, Any]) -> Any:
    """Merge permission filters into dict-based user filters."""
    if not permission_filters:
        return filters
    if not isinstance(filters, dict):
        filters = {}
    return {**filters, **permission_filters}


def merge_filter_list(filters: Any, permission_filters: list[dict[str, Any]]) -> Any:
    """Merge permission filters into list-based virtual-action filters."""
    if not permission_filters:
        return filters
    if not isinstance(filters, list):
        filters = []
    return [*filters, *permission_filters]


async def _timed_call[T: PermissionDecision](name: str, awaitable: Awaitable[T]) -> T:
    started_at = time.perf_counter()
    decision = await awaitable
    elapsed_ms = (time.perf_counter() - started_at) * 1000
    logger.info(
        "permission.%s allowed=%s reason=%s elapsed_ms=%.2f",
        name,
        getattr(decision, "allowed", None),
        getattr(decision, "reason_code", ""),
        elapsed_ms,
    )
    return decision


def _ensure_allowed(decision: PermissionDecision, *, resource: str) -> None:
    if decision.allowed:
        return
    raise PermissionDeniedError(resource, decision.reason_code, decision.message)


def _effective_field_rules(
    field_rules: tuple[FieldPermissionRule, ...],
) -> dict[str, FieldPermissionRule]:
    priority = {"allow": 0, "mask": 1, "deny": 2}
    effective: dict[str, FieldPermissionRule] = {}
    for rule in field_rules:
        current = effective.get(rule.field_code)
        if current is None or priority[rule.effect] > priority[current.effect]:
            effective[rule.field_code] = rule
    return effective


def _mask_value(value: Any, rule: FieldPermissionRule) -> Any:
    if rule.mask_type == "null":
        return None
    if rule.mask_type == "fixed":
        return rule.mask_value if rule.mask_value is not None else "***"
    if rule.mask_type == "hash":
        return hashlib.sha256(str(value).encode("utf-8")).hexdigest()
    if rule.mask_type == "partial":
        text = str(value)
        if len(text) <= 2:
            return "*" * len(text)
        return f"{text[0]}{'*' * (len(text) - 2)}{text[-1]}"
    return None


def _column_name(column: Any) -> str | None:
    if isinstance(column, str):
        return column
    if isinstance(column, dict):
        name = column.get("name")
        return str(name) if name is not None else None
    return None


def _validate_param_value(rule: ParamPermissionRule, value: Any) -> None:
    if rule.allowed_values is not None and value not in rule.allowed_values:
        raise PermissionDeniedError(rule.param_code, "param_value_not_allowed")
    if rule.value_range is not None and isinstance(value, int | float):
        min_value, max_value = rule.value_range
        if min_value is not None and value < min_value:
            raise PermissionDeniedError(rule.param_code, "param_value_too_small")
        if max_value is not None and value > max_value:
            raise PermissionDeniedError(rule.param_code, "param_value_too_large")
    if rule.regex is not None and not re.fullmatch(rule.regex, str(value)):
        raise PermissionDeniedError(rule.param_code, "param_value_regex_mismatch")
    if (
        rule.max_items is not None
        and isinstance(value, list | tuple | set)
        and len(value) > rule.max_items
    ):
        raise PermissionDeniedError(rule.param_code, "param_too_many_items")


def _append_filter_dict(filters: dict[str, Any], predicate: RowPredicate) -> None:
    if predicate.op == "and":
        for child in predicate.children:
            _append_filter_dict(filters, child)
        return
    if predicate.op in {"or", "not"}:
        raise PermissionDeniedError("row_rules", "unsupported_row_predicate")
    if not predicate.field:
        return
    filters[predicate.field] = {"op": _normalize_filter_op(predicate.op), "value": predicate.value}


def _append_filter_list(filters: list[dict[str, Any]], predicate: RowPredicate) -> None:
    if predicate.op == "and":
        for child in predicate.children:
            _append_filter_list(filters, child)
        return
    if predicate.op in {"or", "not"}:
        raise PermissionDeniedError("row_rules", "unsupported_row_predicate")
    if not predicate.field:
        return
    item = {"field": predicate.field, "op": _normalize_filter_op(predicate.op)}
    if predicate.op != "is_null":
        item["value"] = predicate.value
    filters.append(item)


def _normalize_filter_op(op: PredicateOp) -> str:
    return "neq" if op == "ne" else op


def _eval_predicate(record: dict[str, Any], predicate: RowPredicate) -> bool:
    if predicate.op == "and":
        return all(_eval_predicate(record, child) for child in predicate.children)
    if predicate.op == "or":
        return any(_eval_predicate(record, child) for child in predicate.children)
    if predicate.op == "not":
        return not any(_eval_predicate(record, child) for child in predicate.children)
    if not predicate.field:
        return True
    left = record.get(predicate.field)
    right = predicate.value
    if predicate.op == "eq":
        return bool(left == right)
    if predicate.op == "ne":
        return bool(left != right)
    if predicate.op == "gt":
        return bool(left is not None and right is not None and left > right)
    if predicate.op == "gte":
        return bool(left is not None and right is not None and left >= right)
    if predicate.op == "lt":
        return bool(left is not None and right is not None and left < right)
    if predicate.op == "lte":
        return bool(left is not None and right is not None and left <= right)
    if predicate.op == "in":
        return isinstance(right, list | tuple | set) and left in right
    if predicate.op == "between":
        return isinstance(right, list | tuple) and len(right) == 2 and right[0] <= left <= right[1]
    if predicate.op == "like":
        return str(right).replace("%", "") in str(left)
    if predicate.op == "is_null":
        return left is None
    return True
