"""SQL 查询结果术语值转换兼容导出。"""

from __future__ import annotations

from datacloud_data_sdk.result_term_converter import ResultTermConverter, TermResultField

__all__ = ["ResultTermConverter", "TermResultField"]
