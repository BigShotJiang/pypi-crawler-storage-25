# HasResourcePermission

This condition is true if the the a request is made to a resource that a user has access permission to. 

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**condition_type** | **str** | The discriminator for the condition | 
**resource_types** | [**[ResourceTypeEnum], none_type**](ResourceTypeEnum.md) | Apply the resource permission check to the specific resource(s) in the array. If this property is not set, then all resources are checked.  | 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


