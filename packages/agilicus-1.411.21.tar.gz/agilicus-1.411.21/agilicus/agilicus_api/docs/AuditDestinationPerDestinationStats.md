# AuditDestinationPerDestinationStats

Statistics for a specific audit destination. 

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**destination_summary_stats** | [**AuditDestinationSummaryStats**](AuditDestinationSummaryStats.md) |  | [optional] 
**destination_detailed_stats** | [**AuditDestinationDetailedStats**](AuditDestinationDetailedStats.md) |  | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


