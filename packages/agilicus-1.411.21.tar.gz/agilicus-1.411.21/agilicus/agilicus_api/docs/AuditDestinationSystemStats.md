# AuditDestinationSystemStats

Audit destination statistics global to an instance. A given instance will generate audit records in response to events. Those record are sent to the configured destinations. This captures statistics related to the actual generated events, independent of the configured destinations. 

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_events** | **int** | The number of events which were processed (e.g. generated and routed) | [optional] 
**per_type_events** | **{str: (int,)}** | Number of events processed, broken down by type | [optional] 
**total_dropped** | **int** | Sum of all events which were dropped within the system (e.g. due to congestion) | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


