# AuditDestinationDetailedStats

Detailed statistics for an audit destination. Note that a given event will be routed and sent to multiple destinations based on configuration and filters. per_type_processed counts the number of actual events. per_type_sent counts the number of events sent out to a destination. If these stats are for a specific destination, per_type_processed will not be populated. 

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**per_type_sent** | **{str: (int,)}** | Number of events sent, broken down by type | [optional] 
**last_sent_time** | **datetime** | The last time an event was successfully sent to this destination | [optional] 
**drop_authorization** | **int** | Number of events that failed authorization | [optional] 
**drop_build_authorization** | **int** | Number of events that failed to build authorization | [optional] 
**drop_invalid_format** | **int** | Number of events that failed to convert into the destination format | [optional] 
**drop_congestion** | **int** | Number of events dropped due to congestion | [optional] 
**drop_timeout** | **int** | Number of events dropped due to timeout | [optional] 
**drop_rejected** | **int** | Number of events rejected by the destination | [optional] 
**drop_down** | **int** | Number of events where the destination was down or unreachable | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


