# AuditDestinationSummaryStats

Summary statistics for audit destinations. If these stats are for a specific destination, total_processed and total_dropp not be populated. 

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total_dropped** | **int** | Sum of all per-destination events which dropped | [optional] 
**total_sent** | **int** | Sum of all per-destination events which were sent | [optional] 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


