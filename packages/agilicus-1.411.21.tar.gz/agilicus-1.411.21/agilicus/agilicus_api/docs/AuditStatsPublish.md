# AuditStatsPublish

Published audit destination statistics for a component of the system. 

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**audit_totals** | [**AuditDestinationCommonStats**](AuditDestinationCommonStats.md) |  | 
**audit_destination_stats** | [**[AuditDestinationStatsPublish]**](AuditDestinationStatsPublish.md) | The stats for all audit destinations of a component in the system.  | 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


