# Tribulnation Bitstamp SDK

> An SDK to connect Bitstamp with the Tribulnation ecosystem.

🚧 Under construction.