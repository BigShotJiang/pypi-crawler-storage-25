"""
### Tribulnation Bitstamp
> An SDK to connect Bitstamp with the Tribulnation ecosystem.

- Details
"""