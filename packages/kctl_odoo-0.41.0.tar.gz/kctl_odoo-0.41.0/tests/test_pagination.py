from unittest.mock import MagicMock

import pytest

from kctl_odoo.core.pagination import MAX_SAFE_FETCH, safe_search_read


def test_safe_search_read_returns_results():
    client = MagicMock()
    client.search_count.return_value = 3
    client.search_read.return_value = [{"id": 1}, {"id": 2}, {"id": 3}]
    result = safe_search_read(client, "res.partner", [], ["name"])
    assert len(result) == 3


def test_safe_search_read_rejects_over_max():
    client = MagicMock()
    client.search_count.return_value = MAX_SAFE_FETCH + 1
    with pytest.raises(ValueError, match="would return"):
        # limit=0 means fetch all -- effective_limit = total = MAX_SAFE_FETCH + 1 > max_records
        safe_search_read(client, "res.partner", [], ["name"], limit=0)


def test_safe_search_read_empty_result():
    client = MagicMock()
    client.search_count.return_value = 0
    result = safe_search_read(client, "res.partner", [], ["name"])
    assert result == []


def test_safe_search_read_paginates():
    client = MagicMock()
    client.search_count.return_value = 2500
    client.search_read.side_effect = [
        [{"id": i} for i in range(1000)],
        [{"id": i} for i in range(1000, 2000)],
        [{"id": i} for i in range(2000, 2500)],
    ]
    result = safe_search_read(client, "res.partner", [], ["name"], limit=2500, chunk_size=1000)
    assert len(result) == 2500


def test_safe_search_read_progress_callback():
    client = MagicMock()
    client.search_count.return_value = 100
    client.search_read.return_value = [{"id": i} for i in range(100)]
    calls = []
    safe_search_read(client, "m", [], ["name"], limit=100, progress_callback=lambda d, t: calls.append((d, t)))
    assert len(calls) >= 1
