"""Tests for model and field name constants."""

from __future__ import annotations


def test_model_constants_are_strings():
    from kctl_odoo.core.models import Model

    for attr in dir(Model):
        if attr.startswith("_"):
            continue
        value = getattr(Model, attr)
        assert isinstance(value, str), f"Model.{attr} should be str, got {type(value)}"
        assert "." in value, f"Model.{attr} = {value!r} doesn't look like an Odoo model name"


def test_field_constants_are_strings():
    from kctl_odoo.core.field_names import F

    for attr in dir(F):
        if attr.startswith("_"):
            continue
        value = getattr(F, attr)
        assert isinstance(value, str), f"F.{attr} should be str, got {type(value)}"


def test_no_duplicate_model_values():
    from kctl_odoo.core.models import Model

    values = [getattr(Model, a) for a in dir(Model) if not a.startswith("_")]
    assert len(values) == len(set(values)), "Duplicate model constant values found"
