"""--explain dry-run tests for kctl-odoo destructive write commands.

Each test invokes a high-impact write command with ``--explain`` and asserts:
  * exit code 0
  * ``[explain]`` token in output
  * the underlying OdooClient method is never called

The decorator (`kctl_lib.dry_run.with_dry_run`) raises ``typer.Exit(0)``
before the wrapped function body executes, so the client is never reached.
We still attach a MagicMock to ``AppContext._client`` defensively to detect
any regression that would let the body run.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, PropertyMock, patch

import pytest
from typer.testing import CliRunner

from kctl_odoo.cli import app
from kctl_odoo.core.callbacks import AppContext


@pytest.fixture(autouse=True)
def _patch_client(mock_client: MagicMock):
    """Force AppContext.client to return a MagicMock so any accidental
    invocation is detectable (rather than triggering real auth)."""
    with patch.object(AppContext, "client", new_callable=PropertyMock, return_value=mock_client):
        yield


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


def test_databases_create_explain_no_api_call(runner: CliRunner, mock_client: MagicMock) -> None:
    result = runner.invoke(app, ["databases", "create", "test_db", "--explain"])
    assert result.exit_code == 0, result.output
    assert "[explain]" in result.output
    assert "test_db" in result.output
    mock_client.db_create.assert_not_called()


def test_databases_drop_explain_no_api_call(runner: CliRunner, mock_client: MagicMock) -> None:
    result = runner.invoke(app, ["databases", "drop", "old_db", "--force", "--explain"])
    assert result.exit_code == 0, result.output
    assert "[explain]" in result.output
    assert "old_db" in result.output
    mock_client.db_drop.assert_not_called()


def test_backup_restore_explain_no_api_call(runner: CliRunner, mock_client: MagicMock, tmp_path: Path) -> None:
    # File need not exist -- decorator exits before the file check runs.
    fake = tmp_path / "fake_backup.zip"
    result = runner.invoke(
        app,
        ["backup", "restore", str(fake), "--database", "restored_db", "--force", "--explain"],
    )
    assert result.exit_code == 0, result.output
    assert "[explain]" in result.output
    assert "restored_db" in result.output
    mock_client.db_restore.assert_not_called()


def test_modules_upgrade_explain_no_api_call(runner: CliRunner, mock_client: MagicMock) -> None:
    result = runner.invoke(app, ["modules", "upgrade", "sale,account", "--explain"])
    assert result.exit_code == 0, result.output
    assert "[explain]" in result.output
    assert "sale,account" in result.output
    mock_client.execute_kw.assert_not_called()


def test_users_create_explain_no_api_call(runner: CliRunner, mock_client: MagicMock) -> None:
    result = runner.invoke(
        app,
        ["users", "create", "jdoe", "--name", "Jane Doe", "--email", "jane@example.com", "--explain"],
    )
    assert result.exit_code == 0, result.output
    assert "[explain]" in result.output
    assert "jdoe" in result.output
    mock_client.create.assert_not_called()
