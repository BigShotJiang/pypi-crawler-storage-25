from kctl_odoo.core.progress import cli_progress


def test_cli_progress_context_manager():
    with cli_progress("Testing") as progress:
        task = progress.add_task("Testing", total=3)
        for _ in range(3):
            progress.update(task, advance=1)
