from kctl_odoo.core.error_hints import get_hint
from kctl_odoo.core.exceptions import AuthenticationError, ConfigError, RPCError


def test_auth_error_hint():
    assert "config init" in get_hint(AuthenticationError("denied"))


def test_config_error_hint():
    assert "config" in get_hint(ConfigError("no profile found"))


def test_rpc_access_denied_hint():
    hint = get_hint(RPCError({"message": "access denied"}))
    assert "expired" in hint or "key" in hint


def test_unknown_error_no_hint():
    assert get_hint(ValueError("something")) is None
