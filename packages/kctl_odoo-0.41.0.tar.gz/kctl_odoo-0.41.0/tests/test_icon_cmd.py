"""Tests for scaffold icon command."""

from __future__ import annotations

from pathlib import Path

import pytest

from kctl_odoo.commands.icon_cmd import (
    _COLORS,
    _ICONS,
    generate_svg,
    resolve_colors,
)


class TestResolveColors:
    def test_preset_name(self) -> None:
        top, bottom = resolve_colors("purple")
        assert top == "#875A7B"
        assert bottom == "#68465F"

    def test_all_presets_valid(self) -> None:
        for name in _COLORS:
            top, bottom = resolve_colors(name)
            assert top.startswith("#")
            assert bottom.startswith("#")
            assert len(top) == 7
            assert len(bottom) == 7

    def test_custom_hex_6(self) -> None:
        top, bottom = resolve_colors("#FF5733")
        assert top == "#FF5733"
        assert bottom.startswith("#")
        assert bottom != top

    def test_custom_hex_3(self) -> None:
        top, bottom = resolve_colors("#F00")
        assert top == "#FF0000"

    def test_custom_hex_no_hash(self) -> None:
        top, bottom = resolve_colors("FF5733")
        assert top == "#FF5733"

    def test_invalid_color(self) -> None:
        with pytest.raises(ValueError, match="Invalid"):
            resolve_colors("notacolor")

    def test_invalid_hex(self) -> None:
        with pytest.raises(ValueError, match="Invalid"):
            resolve_colors("#GGGGGG")


class TestGenerateSvg:
    def test_basic_svg_structure(self) -> None:
        svg = generate_svg("#875A7B", "#68465F", icon_paths=["M 50 50 L 60 60 Z"])
        assert svg.startswith("<svg")
        assert "viewBox" in svg
        assert "</svg>" in svg
        assert "linearGradient" in svg
        assert "#875A7B" in svg
        assert "#68465F" in svg
        assert 'fill="#fff"' in svg

    def test_rounded_rect_default(self) -> None:
        svg = generate_svg("#000", "#111", icon_paths=["M 0 0 Z"])
        assert 'rx="14"' in svg

    def test_circle_shape(self) -> None:
        svg = generate_svg("#000", "#111", icon_paths=["M 0 0 Z"], shape="circle")
        assert "<circle" in svg
        assert "rx=" not in svg

    def test_squircle_shape(self) -> None:
        svg = generate_svg("#000", "#111", icon_paths=["M 0 0 Z"], shape="squircle")
        assert 'rx="22"' in svg

    def test_no_gradient(self) -> None:
        svg = generate_svg("#875A7B", "#68465F", icon_paths=["M 0 0 Z"], use_gradient=False)
        assert "linearGradient" not in svg
        assert 'fill="#875A7B"' in svg

    def test_text_icon(self) -> None:
        svg = generate_svg("#000", "#111", text="HR")
        assert "<text" in svg
        assert "HR" in svg
        assert 'font-size="36"' in svg

    def test_text_single_char(self) -> None:
        svg = generate_svg("#000", "#111", text="$")
        assert 'font-size="42"' in svg

    def test_text_three_chars(self) -> None:
        svg = generate_svg("#000", "#111", text="API")
        assert 'font-size="28"' in svg

    def test_text_four_chars(self) -> None:
        svg = generate_svg("#000", "#111", text="ACME")
        assert 'font-size="22"' in svg

    def test_text_xml_escape(self) -> None:
        svg = generate_svg("#000", "#111", text="<>")
        assert "&lt;" in svg
        assert "&gt;" in svg

    def test_fill_rule_evenodd(self) -> None:
        svg = generate_svg("#000", "#111", icon_paths=["M 0 0 Z"], fill_rule="evenodd")
        assert 'fill-rule="evenodd"' in svg

    def test_multiple_paths(self) -> None:
        paths = ["M 30 70 L 30 48 Z", "M 43 70 L 43 33 Z", "M 56 70 L 56 55 Z"]
        svg = generate_svg("#000", "#111", icon_paths=paths)
        assert svg.count("<path") == 3


class TestIconCatalog:
    def test_all_icons_have_required_fields(self) -> None:
        for name, data in _ICONS.items():
            assert "desc" in data, f"Icon {name} missing 'desc'"
            assert "paths" in data, f"Icon {name} missing 'paths'"
            paths = data["paths"]
            assert isinstance(paths, list), f"Icon {name} paths not a list"
            assert len(paths) > 0, f"Icon {name} has empty paths"

    def test_all_icons_generate_valid_svg(self) -> None:
        for name, data in _ICONS.items():
            paths = list(data["paths"])  # type: ignore[arg-type]
            fill_rule = str(data["fill_rule"]) if "fill_rule" in data else None
            svg = generate_svg("#875A7B", "#68465F", icon_paths=paths, fill_rule=fill_rule)
            assert "<svg" in svg, f"Icon {name} failed to generate"
            assert "</svg>" in svg, f"Icon {name} missing closing tag"

    def test_known_icons_exist(self) -> None:
        expected = {
            "chart",
            "star",
            "heart",
            "check",
            "mail",
            "lightning",
            "shield",
            "gear",
            "bell",
            "people",
            "chat",
            "cart",
        }
        assert expected.issubset(set(_ICONS.keys()))

    def test_icon_count(self) -> None:
        assert len(_ICONS) >= 25


class TestIconCommand:
    """Tests for the icon CLI command using tmp directories."""

    def test_icon_creates_file(self, tmp_path: Path) -> None:
        mod_dir = tmp_path / "my_module"
        mod_dir.mkdir()

        from kctl_odoo.commands.icon_cmd import icon

        try:
            icon(
                module_dir=str(mod_dir),
                symbol="chart",
                color="teal",
                text=None,
                shape="rounded-rect",
                no_gradient=False,
                list_icons=False,
                list_colors=False,
                overwrite=False,
            )
        except SystemExit:
            pass

        icon_file = mod_dir / "static" / "description" / "icon.svg"
        assert icon_file.exists()
        content = icon_file.read_text()
        assert "<svg" in content
        assert "#00A09D" in content

    def test_icon_skip_existing(self, tmp_path: Path) -> None:
        mod_dir = tmp_path / "my_module"
        icon_dir = mod_dir / "static" / "description"
        icon_dir.mkdir(parents=True)
        icon_file = icon_dir / "icon.svg"
        icon_file.write_text("existing")

        from kctl_odoo.commands.icon_cmd import icon

        try:
            icon(
                module_dir=str(mod_dir),
                symbol="star",
                color="purple",
                text=None,
                shape="rounded-rect",
                no_gradient=False,
                list_icons=False,
                list_colors=False,
                overwrite=False,
            )
        except SystemExit:
            pass

        assert icon_file.read_text() == "existing"

    def test_icon_overwrite(self, tmp_path: Path) -> None:
        mod_dir = tmp_path / "my_module"
        icon_dir = mod_dir / "static" / "description"
        icon_dir.mkdir(parents=True)
        icon_file = icon_dir / "icon.svg"
        icon_file.write_text("old")

        from kctl_odoo.commands.icon_cmd import icon

        try:
            icon(
                module_dir=str(mod_dir),
                symbol="heart",
                color="red",
                text=None,
                shape="rounded-rect",
                no_gradient=False,
                list_icons=False,
                list_colors=False,
                overwrite=True,
            )
        except SystemExit:
            pass

        assert "<svg" in icon_file.read_text()

    def test_text_icon(self, tmp_path: Path) -> None:
        mod_dir = tmp_path / "my_module"
        mod_dir.mkdir()

        from kctl_odoo.commands.icon_cmd import icon

        try:
            icon(
                module_dir=str(mod_dir),
                symbol=None,
                text="HR",
                color="blue",
                shape="rounded-rect",
                no_gradient=False,
                list_icons=False,
                list_colors=False,
                overwrite=False,
            )
        except SystemExit:
            pass

        icon_file = mod_dir / "static" / "description" / "icon.svg"
        assert icon_file.exists()
        content = icon_file.read_text()
        assert "HR" in content
        assert "<text" in content
