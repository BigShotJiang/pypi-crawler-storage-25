"""Regression tests for explicit profile usage in config commands."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest
import yaml
from kctl_lib.exceptions import ConfigError

from kctl_odoo.core.output import Output


def _write_config(config_file: Path) -> None:
    config_file.write_text(
        yaml.dump(
            {
                "default_profile": "default",
                "profiles": {
                    "real-one": {
                        "odoo": {
                            "url": "https://odoo.example",
                            "database": "db",
                            "username": "admin",
                            "api_key": "key",
                        }
                    },
                    "other": {"postgres": {"host": "db.example"}},
                },
            }
        )
    )


def _make_ctx(*, json_mode: bool = False, profile: str | None = None) -> MagicMock:
    actx = MagicMock()
    actx.json_mode = json_mode
    actx.output = Output(json_mode=json_mode)
    actx.profile = profile
    actx.url_override = None
    actx.api_key_override = None
    actx.database_override = None
    actx.username_override = None
    ctx = MagicMock()
    ctx.obj = actx
    return ctx


@pytest.fixture
def isolated_config(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    config_file = tmp_path / "config.yaml"
    _write_config(config_file)

    import kctl_odoo.commands.config_cmd as cmd_mod
    import kctl_odoo.core.config as config_mod

    monkeypatch.setattr(config_mod, "CONFIG_FILE", config_file)
    monkeypatch.setattr(config_mod, "CONFIG_DIR", tmp_path)
    monkeypatch.setattr(cmd_mod, "CONFIG_FILE", config_file)
    monkeypatch.setattr(cmd_mod, "_test_connection", lambda *_args: (True, "18.0"))
    monkeypatch.delenv("KCTL_ODOO_PROFILE", raising=False)
    return config_file


def test_config_list_does_not_require_default_profile(isolated_config: Path, capsys: pytest.CaptureFixture[str]) -> None:
    from kctl_odoo.commands.config_cmd import profiles

    profiles(_make_ctx(json_mode=True))

    data = json.loads(capsys.readouterr().out)
    real_one = next(item for item in data if item["name"] == "real-one")
    assert real_one["connected"] is True
    assert real_one["selected"] is False
    assert "default" not in real_one


def test_config_current_requires_explicit_profile(isolated_config: Path) -> None:
    from kctl_odoo.commands.config_cmd import current

    with pytest.raises(ConfigError) as excinfo:
        current(_make_ctx())

    msg = str(excinfo.value)
    assert "No profile specified" in msg
    assert "--profile/-p" in msg
    assert "KCTL_ODOO_PROFILE" in msg


def test_config_use_prints_explicit_usage_without_writing_default(
    isolated_config: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    from kctl_odoo.commands.config_cmd import use

    use(_make_ctx(), "real-one")

    data = yaml.safe_load(isolated_config.read_text())
    assert data["default_profile"] == "default"

    output = capsys.readouterr().out
    assert "--profile real-one" in output
    assert "KCTL_ODOO_PROFILE=real-one" in output
