"""Tests that core modules use specific exception types, not bare Exception."""

from __future__ import annotations

import ast
from pathlib import Path

CORE_DIR = Path(__file__).parent.parent / "src" / "kctl_odoo" / "core"


def _find_broad_except(filepath: Path) -> list[int]:
    tree = ast.parse(filepath.read_text())
    lines = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Try):
            for handler in node.handlers:
                if isinstance(handler.type, ast.Name) and handler.type.id == "Exception":
                    lines.append(handler.lineno)
                if handler.type is None:
                    lines.append(handler.lineno)
    return lines


def test_no_broad_exceptions_in_core():
    violations = {}
    for py_file in sorted(CORE_DIR.rglob("*.py")):
        lines = _find_broad_except(py_file)
        if lines:
            violations[str(py_file)] = lines
    assert violations == {}, f"Broad `except Exception` found in core/:\n{violations}"
