"""Negative tests for RPC error handling."""

from __future__ import annotations

from unittest.mock import MagicMock

from kctl_odoo.core.exceptions import APIError, RPCError


def test_api_error_from_500_response():
    resp = MagicMock()
    resp.status_code = 500
    resp.json.return_value = {"error": {"message": "Internal Server Error"}}
    resp.text = "Internal Server Error"
    err = APIError(response=resp)
    assert err.status_code == 500
    assert "Internal Server Error" in str(err)


def test_api_error_from_invalid_json():
    resp = MagicMock()
    resp.status_code = 502
    resp.json.side_effect = ValueError("Invalid JSON")
    resp.text = "<html>Bad Gateway</html>"
    err = APIError(response=resp)
    assert "Bad Gateway" in err.detail


def test_rpc_error_preserves_debug_info():
    err = RPCError({"message": "AccessError", "data": {"message": "Record not found", "debug": "traceback..."}})
    assert "AccessError" in str(err)
    assert "Record not found" in str(err)


def test_rpc_error_empty_data():
    err = RPCError({"message": "Unknown error"})
    assert "Unknown error" in str(err)


def test_rpc_error_no_message():
    err = RPCError({})
    assert str(err) is not None  # Should not crash


def test_api_error_without_response():
    err = APIError(detail="manual error")
    assert err.status_code == 0
    assert "manual error" in str(err)


def test_api_error_from_401():
    resp = MagicMock()
    resp.status_code = 401
    resp.json.return_value = {"error": {"message": "Session expired"}}
    resp.text = ""
    err = APIError(response=resp)
    assert err.status_code == 401


def test_api_error_detail_falls_back_to_data_message():
    """When error.message is empty, APIError falls back to error.data.message."""
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = {"error": {"message": "", "data": {"message": "Nested detail"}}}
    resp.text = ""
    err = APIError(response=resp)
    assert "Nested detail" in err.detail


def test_api_error_detail_falls_back_to_body_string():
    """When neither message field exists, APIError uses the full body string."""
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = {"error": {}}
    resp.text = ""
    err = APIError(response=resp)
    # detail should be the str representation of the body, not crash
    assert err.detail is not None


def test_rpc_error_debug_field_preferred_over_data_message():
    """RPCError prefers data.message over data.debug when both are present."""
    err = RPCError(
        {
            "message": "OdooError",
            "data": {"message": "Human readable", "debug": "Stack trace here"},
        }
    )
    # detail should contain the message (not the debug trace) since message wins
    assert "Human readable" in err.detail


def test_rpc_error_only_debug_field():
    """RPCError uses data.debug when data.message is absent."""
    err = RPCError({"message": "OdooError", "data": {"debug": "Stack trace only"}})
    assert "Stack trace only" in err.detail


def test_api_error_inherits_from_kctl_error():
    """APIError is a KctlError subclass for consistent exception handling."""
    from kctl_lib.exceptions import KctlError

    resp = MagicMock()
    resp.status_code = 403
    resp.json.return_value = {"error": {"message": "Forbidden"}}
    resp.text = ""
    err = APIError(response=resp)
    assert isinstance(err, KctlError)


def test_rpc_error_inherits_from_kctl_error():
    """RPCError is a KctlError subclass for consistent exception handling."""
    from kctl_lib.exceptions import KctlError

    err = RPCError({"message": "AccessError"})
    assert isinstance(err, KctlError)
