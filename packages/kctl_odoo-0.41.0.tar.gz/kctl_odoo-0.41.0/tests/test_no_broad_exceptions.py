"""Regression test: no broad `except Exception` or bare `except:` in commands/.

Exceptions:
- diagnose.py: 10 intentional section-level handlers marked with # noqa: BLE001

This test uses AST parsing so it catches the actual exception type regardless
of any inline ``# noqa`` comments.
"""

from __future__ import annotations

import ast
from pathlib import Path

COMMANDS_DIR = Path(__file__).parent.parent / "src" / "kctl_odoo" / "commands"

# Files with intentional broad handlers (verified and marked with # noqa: BLE001)
EXEMPT_FILES = {"diagnose.py"}


def _collect_violations(py_file: Path) -> list[tuple[int, str]]:
    """Return list of (lineno, description) for broad exception handlers."""
    violations: list[tuple[int, str]] = []
    try:
        src = py_file.read_text(encoding="utf-8")
        tree = ast.parse(src, filename=str(py_file))
    except SyntaxError:
        return violations

    for node in ast.walk(tree):
        if not isinstance(node, ast.ExceptHandler):
            continue
        if node.type is None:
            violations.append((node.lineno, "bare except:"))
        elif isinstance(node.type, ast.Name) and node.type.id == "Exception":
            violations.append((node.lineno, "except Exception"))
        elif isinstance(node.type, ast.Attribute) and node.type.attr == "Exception":
            violations.append((node.lineno, "except builtins.Exception"))

    return violations


def test_no_broad_exceptions_in_commands() -> None:
    """All command files must use specific exception types."""
    assert COMMANDS_DIR.is_dir(), f"Commands directory not found: {COMMANDS_DIR}"

    all_violations: list[str] = []

    for py_file in sorted(COMMANDS_DIR.rglob("*.py")):
        if "__pycache__" in str(py_file):
            continue
        if py_file.name in EXEMPT_FILES:
            continue

        violations = _collect_violations(py_file)
        for lineno, description in violations:
            rel = py_file.relative_to(COMMANDS_DIR.parent.parent.parent)
            all_violations.append(f"  {rel}:{lineno}: {description}")

    assert not all_violations, (
        f"Found {len(all_violations)} broad exception handler(s) in commands/.\n"
        "Replace with specific exception types (RPCError, ConnectionError, OSError, etc.):\n"
        + "\n".join(all_violations)
    )
