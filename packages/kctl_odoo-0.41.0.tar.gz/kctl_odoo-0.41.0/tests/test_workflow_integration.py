"""Integration tests for workflow commands."""

from __future__ import annotations

from unittest.mock import MagicMock

import click
import pytest
import typer

from kctl_odoo.commands.workflow_cmd import workflow_list, workflow_run
from kctl_odoo.core.output import Output


def _make_actx(client: MagicMock | None = None) -> MagicMock:
    actx = MagicMock()
    actx.json_mode = False
    actx.output = Output(json_mode=False)
    actx.client = client or MagicMock()
    actx.profile = None
    return actx


def _make_ctx(actx: MagicMock) -> MagicMock:
    ctx = MagicMock(spec=typer.Context)
    ctx.obj = actx
    return ctx


# ---------------------------------------------------------------------------
# workflow list
# ---------------------------------------------------------------------------


class TestWorkflowList:
    def test_list_contains_deploy_safe(self, capsys: pytest.CaptureFixture[str]) -> None:
        actx = _make_actx()
        ctx = _make_ctx(actx)
        workflow_list(ctx)
        out = capsys.readouterr().out
        assert "deploy-safe" in out

    def test_list_contains_maintenance_window(self, capsys: pytest.CaptureFixture[str]) -> None:
        actx = _make_actx()
        ctx = _make_ctx(actx)
        workflow_list(ctx)
        out = capsys.readouterr().out
        assert "maintenance-window" in out

    def test_list_json_mode(self, capsys: pytest.CaptureFixture[str]) -> None:
        import json

        actx = _make_actx()
        actx.json_mode = True
        actx.output = Output(json_mode=True)
        ctx = _make_ctx(actx)
        workflow_list(ctx)
        data = json.loads(capsys.readouterr().out)
        names = [row["name"] for row in data]
        assert "deploy-safe" in names
        assert "maintenance-window" in names
        assert "data-quality-sweep" in names


# ---------------------------------------------------------------------------
# workflow run --dry-run
# ---------------------------------------------------------------------------


class TestWorkflowRunDryRun:
    def test_dry_run_deploy_safe(self, capsys: pytest.CaptureFixture[str]) -> None:
        actx = _make_actx()
        ctx = _make_ctx(actx)
        workflow_run(ctx, name="deploy-safe", dry_run=True, force=True)
        out = capsys.readouterr().out
        assert "health-check" in out

    def test_dry_run_maintenance_window_shows_all_steps(self, capsys: pytest.CaptureFixture[str]) -> None:
        actx = _make_actx()
        ctx = _make_ctx(actx)
        workflow_run(ctx, name="maintenance-window", dry_run=True, force=True)
        out = capsys.readouterr().out
        assert "disable-crons" in out
        assert "enable-crons" in out

    def test_dry_run_json_mode(self, capsys: pytest.CaptureFixture[str]) -> None:
        import json

        actx = _make_actx()
        actx.json_mode = True
        actx.output = Output(json_mode=True)
        ctx = _make_ctx(actx)
        workflow_run(ctx, name="deploy-safe", dry_run=True, force=True)
        data = json.loads(capsys.readouterr().out)
        assert isinstance(data, list)
        assert any(step["name"] == "health-check" for step in data)


# ---------------------------------------------------------------------------
# workflow run -- unknown workflow
# ---------------------------------------------------------------------------


class TestWorkflowRunUnknown:
    def test_unknown_workflow_exits_nonzero(self) -> None:
        actx = _make_actx()
        ctx = _make_ctx(actx)
        # typer.Exit raises click.exceptions.Exit, not SystemExit, when called directly
        with pytest.raises(click.exceptions.Exit) as exc_info:
            workflow_run(ctx, name="nonexistent-workflow", dry_run=False, force=True)
        assert exc_info.value.exit_code != 0

    def test_unknown_workflow_error_message(self, capsys: pytest.CaptureFixture[str]) -> None:
        actx = _make_actx()
        ctx = _make_ctx(actx)
        with pytest.raises(click.exceptions.Exit):
            workflow_run(ctx, name="bogus", dry_run=False, force=True)
        # Error should mention the unknown name
        out = capsys.readouterr().out
        assert "bogus" in out or "Unknown" in out

    def test_unknown_workflow_dry_run_also_exits(self) -> None:
        actx = _make_actx()
        ctx = _make_ctx(actx)
        with pytest.raises(click.exceptions.Exit) as exc_info:
            workflow_run(ctx, name="does-not-exist", dry_run=True, force=True)
        assert exc_info.value.exit_code != 0


# ---------------------------------------------------------------------------
# workflow run -- live execution with mocked client
# ---------------------------------------------------------------------------


class TestWorkflowRunLive:
    def test_deploy_safe_succeeds_with_mock_client(self, capsys: pytest.CaptureFixture[str]) -> None:
        client = MagicMock()
        client.execute_kw.return_value = {"server_version": "18.0"}
        actx = _make_actx(client=client)
        ctx = _make_ctx(actx)
        # force=True skips the confirmation prompt
        workflow_run(ctx, name="deploy-safe", dry_run=False, force=True)
        out = capsys.readouterr().out
        assert "deploy-safe" in out

    def test_workflow_run_outputs_step_results(self, capsys: pytest.CaptureFixture[str]) -> None:
        client = MagicMock()
        client.execute_kw.return_value = {"server_version": "18.0"}
        actx = _make_actx(client=client)
        ctx = _make_ctx(actx)
        workflow_run(ctx, name="deploy-safe", dry_run=False, force=True)
        out = capsys.readouterr().out
        assert "health-check" in out
