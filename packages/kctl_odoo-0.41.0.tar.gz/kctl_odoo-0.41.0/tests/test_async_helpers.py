"""Tests for async_command decorator in kctl_odoo.core.async_helpers."""

from __future__ import annotations

import asyncio

from kctl_odoo.core.async_helpers import async_command


def test_async_command_runs_coroutine() -> None:
    """Decorated async function returns its result synchronously."""

    @async_command
    async def fetch() -> str:
        return "hello"

    result = fetch()
    assert result == "hello"


def test_async_command_preserves_name() -> None:
    """__name__ (and other wraps metadata) is preserved by the decorator."""

    @async_command
    async def my_special_command() -> None:
        pass

    assert my_special_command.__name__ == "my_special_command"


def test_async_command_with_args() -> None:
    """Positional and keyword arguments are passed through correctly."""

    @async_command
    async def add(a: int, b: int = 0) -> int:
        return a + b

    assert add(3, b=4) == 7
    assert add(10) == 10


def test_async_gather_pattern() -> None:
    """asyncio.gather works correctly inside a decorated function."""

    async def fetch_value(n: int) -> int:
        await asyncio.sleep(0)  # yield to event loop
        return n * 2

    @async_command
    async def run_gather() -> list[int]:
        return list(await asyncio.gather(fetch_value(1), fetch_value(2), fetch_value(3)))

    result = run_gather()
    assert result == [2, 4, 6]
