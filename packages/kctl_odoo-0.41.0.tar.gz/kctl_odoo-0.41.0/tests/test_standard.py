"""Standard CLI smoke/config/completions tests for kctl-odoo.

kctl-odoo has 100+ command groups; this test exercises a representative
subset focused on the well-known business-process groups.
"""

from __future__ import annotations

import pytest
from typer.testing import CliRunner

from kctl_odoo.cli import app

runner = CliRunner()


@pytest.fixture(autouse=True)
def _isolate(tmp_path, monkeypatch):
    config_dir = tmp_path / "config"
    config_dir.mkdir()
    config_file = config_dir / "config.yaml"
    monkeypatch.setattr("kctl_lib.config.CONFIG_DIR", config_dir, raising=False)
    monkeypatch.setattr("kctl_lib.config.CONFIG_FILE", config_file, raising=False)


class TestVersion:
    def test_version_long(self) -> None:
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0


class TestHelp:
    def test_top_level_help(self) -> None:
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "Usage:" in result.output

    @pytest.mark.parametrize(
        "group",
        [
            "accounting",
            "addons",
            "audit",
            "backup",
            "companies",
            "config",
            "crm",
            "databases",
            "deploy",
            "dev",
            "doctor",
            "fleet",
            "hr",
            "intercompany",
            "inventory",
            "jobs",
            "kpi",
            "mail",
            "manifest",
            "modules",
            "monitor",
            "partners",
            "performance",
            "pos",
            "products",
            "project",
            "purchasing",
            "report",
            "sales",
            "security",
            "server",
            "shell",
            "test",
            "users",
            "views",
        ],
    )
    def test_group_help(self, group: str) -> None:
        result = runner.invoke(app, [group, "--help"])
        assert result.exit_code == 0, result.output


class TestConfigSubcommands:
    def test_config_help(self) -> None:
        result = runner.invoke(app, ["config", "--help"])
        assert result.exit_code == 0

    def test_config_show(self) -> None:
        result = runner.invoke(app, ["config", "show"])
        assert result.exit_code in (0, 1, 2)


class TestCompletions:
    @pytest.mark.parametrize("shell", ["bash", "zsh", "fish"])
    def test_completions(self, shell: str) -> None:
        result = runner.invoke(app, ["completions", shell])
        assert result.exit_code == 0, result.output
