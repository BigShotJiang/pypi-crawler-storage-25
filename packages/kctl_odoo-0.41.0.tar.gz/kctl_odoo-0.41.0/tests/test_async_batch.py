"""Async stress tests for concurrent RPC operations."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock

import pytest


def test_async_gather_10_concurrent():
    """Ten concurrent calls all return the expected value."""

    async def run():
        client = AsyncMock()
        client.search_count = AsyncMock(return_value=42)
        results = await asyncio.gather(*(client.search_count("res.partner", []) for _ in range(10)))
        return results

    results = asyncio.run(run())
    assert len(results) == 10
    assert all(r == 42 for r in results)


def test_async_semaphore_limits_concurrency():
    """Semaphore correctly caps the number of simultaneous coroutines."""
    max_concurrent = 3

    async def run():
        active = 0
        peak = 0
        sem = asyncio.Semaphore(max_concurrent)

        async def bounded_call():
            nonlocal active, peak
            async with sem:
                active += 1
                peak = max(peak, active)
                await asyncio.sleep(0.01)
                active -= 1
                return True

        results = await asyncio.gather(*(bounded_call() for _ in range(20)))
        return results, peak

    results, peak = asyncio.run(run())
    assert len(results) == 20
    assert peak <= max_concurrent


def test_async_timeout_handling():
    """asyncio.wait_for raises TimeoutError when the coroutine takes too long."""

    async def run():
        async def slow_call():
            await asyncio.sleep(10)

        with pytest.raises(asyncio.TimeoutError):
            await asyncio.wait_for(slow_call(), timeout=0.05)

    asyncio.run(run())


def test_async_gather_partial_failure():
    """One failing task in gather raises and propagates the exception."""

    async def run():
        async def ok():
            return "ok"

        async def fail():
            raise ValueError("boom")

        with pytest.raises(ValueError, match="boom"):
            await asyncio.gather(ok(), fail(), ok())

    asyncio.run(run())


def test_async_gather_return_exceptions():
    """With return_exceptions=True, failures are returned as values alongside successes."""

    async def run():
        async def ok():
            return "ok"

        async def fail():
            raise ValueError("boom")

        return await asyncio.gather(ok(), fail(), ok(), return_exceptions=True)

    results = asyncio.run(run())
    assert results[0] == "ok"
    assert isinstance(results[1], ValueError)
    assert results[2] == "ok"


def test_async_gather_empty():
    """Gathering zero coroutines returns an empty list."""

    async def run():
        return await asyncio.gather()

    assert asyncio.run(run()) == []


def test_async_semaphore_zero_delay():
    """Semaphore works correctly even without any async sleep (CPU-bound simulation)."""
    max_concurrent = 5

    async def run():
        sem = asyncio.Semaphore(max_concurrent)
        counter = 0

        async def bounded_increment():
            nonlocal counter
            async with sem:
                counter += 1
                await asyncio.sleep(0)
                return counter

        results = await asyncio.gather(*(bounded_increment() for _ in range(50)))
        return results

    results = asyncio.run(run())
    assert len(results) == 50
    assert all(isinstance(r, int) for r in results)
