"""Tests for kctl_odoo.core.cache.RPCCache."""

from __future__ import annotations

from unittest.mock import patch

from kctl_odoo.core.cache import RPCCache


def test_cache_miss_returns_none() -> None:
    """get on an empty cache returns None."""
    cache = RPCCache()
    result = cache.get("res.partner", "search_read", ([],), {})
    assert result is None


def test_cache_put_and_get() -> None:
    """put then get returns the same value."""
    cache = RPCCache()
    value = [{"id": 1, "name": "Test"}]
    cache.put("res.partner", "search_read", ([],), {}, value)
    result = cache.get("res.partner", "search_read", ([],), {})
    assert result == value


def test_cache_lru_eviction() -> None:
    """With max_size=2, adding a third entry evicts the least-recently-used first entry."""
    cache = RPCCache(max_size=2)
    cache.put("model.a", "search_read", ([],), {}, [1])
    cache.put("model.b", "search_read", ([],), {}, [2])
    # Access model.a to make it recently used
    cache.get("model.a", "search_read", ([],), {})
    # Add third entry — model.b (LRU) should be evicted
    cache.put("model.c", "search_read", ([],), {}, [3])

    assert cache.get("model.a", "search_read", ([],), {}) == [1]
    assert cache.get("model.b", "search_read", ([],), {}) is None
    assert cache.get("model.c", "search_read", ([],), {}) == [3]


def test_cache_invalidate_model() -> None:
    """invalidate_model removes entries for that model but keeps others."""
    cache = RPCCache()
    cache.put("res.partner", "search_read", ([],), {}, [{"id": 1}])
    cache.put("sale.order", "search_read", ([],), {}, [{"id": 2}])

    cache.invalidate_model("res.partner")

    assert cache.get("res.partner", "search_read", ([],), {}) is None
    assert cache.get("sale.order", "search_read", ([],), {}) == [{"id": 2}]


def test_cache_clear() -> None:
    """clear empties the store, write_models set, and counters."""
    cache = RPCCache()
    cache.put("res.partner", "search_read", ([],), {}, [1])
    cache.get("res.partner", "search_read", ([],), {})  # hit
    cache.get("sale.order", "search_read", ([],), {})  # miss
    cache.invalidate_model("res.partner")

    cache.clear()

    assert cache.stats() == {"hits": 0, "misses": 0, "size": 0}
    # After clear, previously invalidated model can be cached again
    cache.put("res.partner", "search_read", ([],), {}, [99])
    assert cache.get("res.partner", "search_read", ([],), {}) == [99]


def test_cache_stats() -> None:
    """hits/misses/size are tracked correctly."""
    cache = RPCCache()
    cache.get("res.partner", "search_read", ([],), {})  # miss
    cache.put("res.partner", "search_read", ([],), {}, [1])
    cache.get("res.partner", "search_read", ([],), {})  # hit
    cache.get("res.partner", "search_read", ([],), {})  # hit

    stats = cache.stats()
    assert stats["hits"] == 2
    assert stats["misses"] == 1
    assert stats["size"] == 1


def test_cache_skips_recently_written_models() -> None:
    """After invalidate, put for that model is a no-op."""
    cache = RPCCache()
    cache.put("res.partner", "search_read", ([],), {}, [{"id": 1}])
    cache.invalidate_model("res.partner")

    # Attempt to re-cache after invalidation — should be ignored
    cache.put("res.partner", "search_read", ([],), {}, [{"id": 2}])
    assert cache.get("res.partner", "search_read", ([],), {}) is None


def test_different_domains_different_keys() -> None:
    """Same model + method but different args produce different cache entries."""
    cache = RPCCache()
    domain_a = ([("active", "=", True)],)
    domain_b = ([("active", "=", False)],)

    cache.put("res.partner", "search_read", domain_a, {}, [{"id": 1}])
    cache.put("res.partner", "search_read", domain_b, {}, [{"id": 2}])

    assert cache.get("res.partner", "search_read", domain_a, {}) == [{"id": 1}]
    assert cache.get("res.partner", "search_read", domain_b, {}) == [{"id": 2}]


def test_cache_ttl_expiry() -> None:
    """An entry is not returned after its TTL has elapsed."""
    cache = RPCCache(default_ttl=10)

    # Fake monotonic clock: entry is stored at t=0, expires at t=10
    with patch("kctl_odoo.core.cache.time.monotonic", return_value=0.0):
        cache.put("res.partner", "search_read", ([],), {}, [{"id": 1}])

    # At t=5 the entry should still be valid
    with patch("kctl_odoo.core.cache.time.monotonic", return_value=5.0):
        assert cache.get("res.partner", "search_read", ([],), {}) == [{"id": 1}]

    # At t=11 the entry has expired
    with patch("kctl_odoo.core.cache.time.monotonic", return_value=11.0):
        assert cache.get("res.partner", "search_read", ([],), {}) is None
