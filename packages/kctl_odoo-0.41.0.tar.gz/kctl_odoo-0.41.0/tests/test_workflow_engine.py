"""Tests for the workflow orchestration engine."""

import asyncio
from unittest.mock import MagicMock

from kctl_odoo.core.workflow import StepStatus, Workflow, WorkflowStep


def test_workflow_all_succeed():
    async def ok(ctx):
        return "ok"

    wf = Workflow("test", [WorkflowStep("s1", ok), WorkflowStep("s2", ok)])
    result = asyncio.run(wf.run(MagicMock()))
    assert result.success
    assert all(s.status == StepStatus.SUCCESS for s in result.steps)


def test_workflow_abort_on_failure():
    async def fail(ctx):
        raise RuntimeError("boom")

    async def ok(ctx):
        return "ok"

    wf = Workflow(
        "test",
        [
            WorkflowStep("s1", fail, on_failure="abort", retries=0),
            WorkflowStep("s2", ok),
        ],
    )
    result = asyncio.run(wf.run(MagicMock()))
    assert not result.success
    assert result.steps[0].status == StepStatus.FAILED
    assert result.steps[1].status == StepStatus.PENDING


def test_workflow_skip_on_failure():
    async def fail(ctx):
        raise RuntimeError("boom")

    async def ok(ctx):
        return "ok"

    wf = Workflow(
        "test",
        [
            WorkflowStep("s1", fail, on_failure="skip", retries=0),
            WorkflowStep("s2", ok),
        ],
    )
    result = asyncio.run(wf.run(MagicMock()))
    assert result.success
    assert result.steps[0].status == StepStatus.SKIPPED
    assert result.steps[1].status == StepStatus.SUCCESS


def test_workflow_retry_then_succeed():
    count = 0

    async def flaky(ctx):
        nonlocal count
        count += 1
        if count < 3:
            raise RuntimeError("transient")
        return "ok"

    wf = Workflow("test", [WorkflowStep("s1", flaky, retries=3, retry_delay=0)])
    result = asyncio.run(wf.run(MagicMock()))
    assert result.success
    assert count == 3


def test_workflow_dry_run():
    async def ok(ctx):
        return "ok"

    wf = Workflow("test", [WorkflowStep("s1", ok)])
    preview = wf.dry_run()
    assert len(preview) == 1
    assert preview[0]["name"] == "s1"


def test_workflow_duration_tracked():
    async def ok(ctx):
        return "ok"

    wf = Workflow("test", [WorkflowStep("s1", ok)])
    result = asyncio.run(wf.run(MagicMock()))
    assert result.duration_seconds >= 0
