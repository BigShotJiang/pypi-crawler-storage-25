"""Tests for feature availability guards."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest
import typer

from kctl_odoo.core.feature_flags import _model_cache, model_available, requires_model


@pytest.fixture(autouse=True)
def clear_cache():
    _model_cache.clear()
    yield
    _model_cache.clear()


def test_model_available_returns_true_when_exists():
    client = MagicMock()
    client.execute_kw.return_value = 1
    assert model_available(client, "res.partner") is True
    client.execute_kw.assert_called_once()


def test_model_available_returns_false_on_rpc_error():
    from kctl_odoo.core.exceptions import RPCError

    client = MagicMock()
    client.execute_kw.side_effect = RPCError({"message": "not found"})
    assert model_available(client, "fake.model") is False


def test_model_available_caches_result():
    client = MagicMock()
    client.execute_kw.return_value = 1
    model_available(client, "res.partner")
    model_available(client, "res.partner")
    assert client.execute_kw.call_count == 1


def test_requires_model_skips_when_missing():
    import click

    from kctl_odoo.core.exceptions import RPCError

    mock_client = MagicMock()
    mock_client.execute_kw.side_effect = RPCError({"message": "not found"})

    mock_output = MagicMock()
    mock_ctx = MagicMock()
    mock_ctx.obj.client = mock_client
    mock_ctx.obj.output = mock_output

    @requires_model("fake.model")
    def my_command(ctx: typer.Context):
        pass

    with pytest.raises((SystemExit, click.exceptions.Exit)):
        my_command(mock_ctx)
    mock_output.warn.assert_called_once()


def test_requires_model_proceeds_when_available():
    mock_client = MagicMock()
    mock_client.execute_kw.return_value = 1
    mock_ctx = MagicMock()
    mock_ctx.obj.client = mock_client

    called = False

    @requires_model("res.partner")
    def my_command(ctx: typer.Context):
        nonlocal called
        called = True

    my_command(mock_ctx)
    assert called
