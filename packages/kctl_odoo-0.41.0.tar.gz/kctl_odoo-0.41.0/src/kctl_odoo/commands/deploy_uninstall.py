"""Deploy uninstall — bulk-uninstall modules via init container.

Same pattern as deploy_upgrade: set env → redeploy → wait → verify → clean env.
The init container runs odoo shell with button_immediate_uninstall(), then odoo -u all.
"""

from __future__ import annotations

import http.client
import json
import time
import urllib.parse
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

console = Console()


def _dokploy_config(profile: str) -> tuple[str, str]:
    import yaml

    config_path = Path.home() / ".config" / "kodemeio" / "config.yaml"
    if not config_path.exists():
        console.print(f"[red]Config not found: {config_path}[/red]")
        raise typer.Exit(1)

    cfg = yaml.safe_load(config_path.read_text())
    prof = cfg.get("profiles", {}).get(profile, {})
    dokploy = prof.get("dokploy", {})
    url = dokploy.get("url", "")
    api_key = dokploy.get("api_key", "")

    if not url or not api_key:
        console.print(f"[red]No dokploy config in profile '{profile}'.[/red]")
        raise typer.Exit(1)

    return url.rstrip("/"), api_key


def _dokploy_request(
    base_url: str,
    api_key: str,
    path: str,
    *,
    method: str = "GET",
    data: dict | None = None,
    query: str = "",
) -> tuple[int, dict]:
    parsed = urllib.parse.urlparse(base_url)
    full_path = f"/api/{path}"
    if query:
        full_path += f"?{query}"

    if parsed.scheme == "https":
        conn = http.client.HTTPSConnection(parsed.hostname, parsed.port or 443, timeout=30)
    else:
        conn = http.client.HTTPConnection(parsed.hostname, parsed.port or 80, timeout=30)

    headers = {"x-api-key": api_key, "Content-Type": "application/json"}
    body = json.dumps(data) if data else None

    try:
        conn.request(method, full_path, body=body, headers=headers)
        resp = conn.getresponse()
        resp_body = resp.read().decode()
        return resp.status, json.loads(resp_body) if resp_body else {}
    except (OSError, json.JSONDecodeError) as e:
        console.print(f"[red]Dokploy API error: {e}[/red]")
        raise typer.Exit(1) from e
    finally:
        conn.close()


def _get_env(url: str, api_key: str, compose_id: str) -> str:
    status, data = _dokploy_request(url, api_key, "compose.one", query=f"composeId={compose_id}")
    if status != 200:
        console.print(f"[red]Failed to get compose env: HTTP {status}[/red]")
        raise typer.Exit(1)
    return data.get("env", "")


def _set_env(url: str, api_key: str, compose_id: str, env_content: str) -> None:
    status, data = _dokploy_request(
        url, api_key, "compose.update", method="POST", data={"composeId": compose_id, "env": env_content}
    )
    if status != 200:
        console.print(f"[red]Failed to update env: HTTP {status} — {data}[/red]")
        raise typer.Exit(1)


def _redeploy(url: str, api_key: str, compose_id: str) -> None:
    status, data = _dokploy_request(url, api_key, "compose.redeploy", method="POST", data={"composeId": compose_id})
    if status != 200:
        console.print(f"[red]Failed to trigger redeploy: HTTP {status} — {data}[/red]")
        raise typer.Exit(1)


def _resolve_profile_diff(profile_name: str) -> str:
    """Resolve modules to uninstall by diffing installed (profile-erp) vs target profile."""

    install_dir = None
    cur = Path.cwd()
    for _ in range(10):
        candidate = cur / "install"
        if candidate.is_dir() and (candidate / "profile-erp.yaml").exists():
            install_dir = candidate
            break
        cur = cur.parent
    if not install_dir:
        console.print("[red]Cannot find install/ directory with profile YAMLs[/red]")
        raise typer.Exit(1)

    from kctl_odoo.core.bundles import load_profile, resolve_profile_modules

    erp_profile = load_profile(install_dir / "profile-erp.yaml")
    erp_modules = set(resolve_profile_modules(erp_profile, install_dir))

    target_profile = load_profile(install_dir / f"profile-{profile_name}.yaml")
    target_modules = set(resolve_profile_modules(target_profile, install_dir))

    to_uninstall = sorted(erp_modules - target_modules)
    if not to_uninstall:
        console.print(f"[yellow]No modules to uninstall (profile-erp ⊆ profile-{profile_name})[/yellow]")
        raise typer.Exit(0)

    return ",".join(to_uninstall)


def uninstall(
    compose_id: Annotated[str, typer.Argument(help="Dokploy compose ID")],
    modules: Annotated[
        str | None,
        typer.Option("--modules", "-m", help="Modules to uninstall (comma-separated)"),
    ] = None,
    profile: Annotated[
        str | None,
        typer.Option("--profile", help="Target profile — auto-computes diff vs profile-erp (e.g. erp-light)"),
    ] = None,
    dokploy_profile: Annotated[
        str, typer.Option("--dokploy-profile", "-dp", help="Dokploy config profile name (required)")
    ] = ...,
    wait: Annotated[int, typer.Option("--wait", "-w", help="Seconds to wait for health")] = 600,
    health_url: Annotated[
        str | None,
        typer.Option("--health-url", help="URL to check after redeploy"),
    ] = None,
    skip_cleanup: Annotated[bool, typer.Option("--skip-cleanup", help="Don't remove env vars after deploy")] = False,
) -> None:
    """Uninstall modules on a Dokploy-hosted Odoo instance via init container.

    Sets ODOO_RUN_UNINSTALL env vars, triggers a redeploy (init container
    runs button_immediate_uninstall + odoo -u all), waits for health,
    then cleans up env vars.

    Examples:
      kctl-odoo deploy uninstall <compose_id> -m stock_management,bank_management -dp idtpp
      kctl-odoo deploy uninstall <compose_id> --profile erp-light -dp idtpp
    """
    if not modules and not profile:
        console.print("[red]Provide --modules or --profile[/red]")
        raise typer.Exit(1)

    if profile and not modules:
        modules = _resolve_profile_diff(profile)

    mod_count = len(modules.split(","))
    url, api_key = _dokploy_config(dokploy_profile)

    console.print("[bold]Deploy Uninstall[/bold]")
    console.print(f"  Compose: {compose_id}")
    console.print(f"  Modules: {mod_count} modules")
    console.print(f"  Dokploy: {url}")
    if profile:
        console.print(f"  Profile: {profile} (auto-diff vs erp)")
    console.print()

    # Step 1: Set env vars
    console.print("[cyan]Step 1/5:[/cyan] Setting ODOO_RUN_UNINSTALL env vars...")
    current_env = _get_env(url, api_key, compose_id)
    clean_env = "\n".join(
        line
        for line in current_env.split("\n")
        if not line.startswith("ODOO_RUN_UNINSTALL=") and not line.startswith("ODOO_RUN_UNINSTALL_MODULES=")
    )
    new_env = f"{clean_env}\nODOO_RUN_UNINSTALL=true\nODOO_RUN_UNINSTALL_MODULES={modules}"
    _set_env(url, api_key, compose_id, new_env)
    console.print(f"  Set ODOO_RUN_UNINSTALL_MODULES ({mod_count} modules)")

    # Step 2: Trigger redeploy
    console.print("[cyan]Step 2/5:[/cyan] Triggering redeploy...")
    _redeploy(url, api_key, compose_id)
    console.print("  Redeploy triggered")

    # Step 3+4: Poll health
    if health_url:
        console.print(f"[cyan]Step 3/5:[/cyan] Polling health for up to {wait}s...")
        console.print(f"  URL: {health_url}")
        healthy = False
        elapsed = 0
        interval = 15
        while elapsed < wait:
            time.sleep(interval)
            elapsed += interval
            try:
                parsed = urllib.parse.urlparse(health_url)
                if parsed.scheme == "https":
                    conn = http.client.HTTPSConnection(parsed.hostname, parsed.port or 443, timeout=10)
                else:
                    conn = http.client.HTTPConnection(parsed.hostname, parsed.port or 80, timeout=10)
                conn.request("GET", parsed.path or "/")
                resp = conn.getresponse()
                code = resp.status
                conn.close()
            except OSError:
                code = 0

            mins = elapsed // 60
            secs = elapsed % 60
            if code == 200:
                console.print(f"  [green]Healthy after {mins}m{secs}s[/green]")
                healthy = True
                break
            console.print(f"  {mins}m{secs}s — HTTP {code}")

        if not healthy:
            console.print(f"[red]Health check failed after {wait}s[/red]")
            console.print("[yellow]Env vars NOT cleaned up — investigate manually[/yellow]")
            raise typer.Exit(1)
    else:
        console.print(f"[cyan]Step 3/5:[/cyan] No --health-url, waiting {wait}s...")
        time.sleep(wait)

    # Step 5: Clean up env vars
    if skip_cleanup:
        console.print("[cyan]Step 5/5:[/cyan] --skip-cleanup set, leaving env vars")
    else:
        console.print("[cyan]Step 5/5:[/cyan] Cleaning up ODOO_RUN_UNINSTALL env vars...")
        final_env = "\n".join(
            line
            for line in new_env.split("\n")
            if not line.startswith("ODOO_RUN_UNINSTALL=") and not line.startswith("ODOO_RUN_UNINSTALL_MODULES=")
        )
        _set_env(url, api_key, compose_id, final_env)
        console.print("  Env vars removed")

    console.print()
    console.print("[bold green]Deploy uninstall complete![/bold green]")
