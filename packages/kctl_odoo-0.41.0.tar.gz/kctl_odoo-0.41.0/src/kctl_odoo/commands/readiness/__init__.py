"""Readiness sub-package: production readiness audit for Odoo 18."""

from __future__ import annotations

from .commands import app as _commands_app

app = _commands_app

__all__ = ["app"]
