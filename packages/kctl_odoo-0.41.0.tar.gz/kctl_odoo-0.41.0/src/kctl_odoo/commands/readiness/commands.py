"""Production readiness audit Typer command."""

from __future__ import annotations

from datetime import date
from pathlib import Path
from typing import Annotated

import typer

from kctl_odoo.core.callbacks import AppContext
from kctl_odoo.core.exceptions import ConnectionError, RPCError

from ._data import (
    XmlRpcClient,
    _bump_timeout,
    _ClientShim,
    _load_profile,
    _pull_company_data,
    _pull_global_data,
)
from ._excel import _write_excel
from ._validation import _check_company

app = typer.Typer(help="Production readiness audit.")

# ---------------------------------------------------------------------------
# Main typer command
# ---------------------------------------------------------------------------


@app.command("readiness-check")
def readiness_check(
    ctx: typer.Context,
    output: Annotated[
        Path | None,
        typer.Option("-o", "--output", help="Output Excel path (default: readiness_<db>_<date>.xlsx)"),
    ] = None,
    company_id: Annotated[
        int,
        typer.Option("--company-id", help="Limit to one company id (default: all)"),
    ] = 0,
    reference: Annotated[
        str | None,
        typer.Option("--reference", help="Reference profile name (e.g. idtpp-mac-odoo-erp)"),
    ] = None,
    reference_company_id: Annotated[
        int,
        typer.Option(
            "--reference-company-id",
            help="Reference company id to use as the gold standard (default: first company on reference)",
        ),
    ] = 0,
    include_reference: Annotated[
        bool,
        typer.Option(
            "--include-reference/--no-include-reference",
            help="Include the reference company itself in the target list — audits the gold-standard template's own completeness.",
        ),
    ] = True,
    per_company: Annotated[
        bool,
        typer.Option(
            "--per-company",
            help="Write one Excel file per company instead of a single consolidated workbook.",
        ),
    ] = False,
) -> None:
    """Generate a multi-sheet production readiness audit Excel.

    Without ``--reference``, runs existence-only checks against the target
    instance. With ``--reference``, also pulls config from a second profile
    (e.g. an Import-trade template) and compares each target company against it.
    """
    actx: AppContext = ctx.obj
    _bump_timeout(actx, seconds=600.0)
    target_inner = actx.client
    out = actx.output

    try:
        from openpyxl import Workbook  # noqa: F401
    except ImportError:
        out.error("openpyxl not installed. Run: pip install openpyxl")
        raise typer.Exit(1)

    target_client = _ClientShim(target_inner)
    target_label = f"{getattr(actx, 'profile', 'target')} ({target_client.database})"

    # Reference setup
    ref_client: _ClientShim | None = None
    reference_label: str | None = None
    if reference:
        # External reference profile (e.g., a different deployment used as gold standard)
        try:
            ref_profile = _load_profile(reference)
            xrpc = XmlRpcClient(ref_profile)
            ref_client = _ClientShim(xrpc)
            reference_label = f"{reference} ({ref_profile['database']})"
            out.info(f"Reference: {reference_label}")
        except (ConnectionError, RPCError, KeyError, ValueError) as exc:
            out.error(f"Failed to load reference profile '{reference}': {exc}")
            raise typer.Exit(1) from exc
    elif reference_company_id:
        # Same-DB reference: use a company in the target instance as the template
        ref_client = target_client
        reference_label = f"same-DB (company id={reference_company_id})"
        out.info(f"Reference: {reference_label}")

    # Target companies
    domain = [("id", "=", company_id)] if company_id else []
    # By default the gold-standard template IS included as a target so its
    # own completeness is audited. Pass --no-include-reference to revert
    # to the previous behaviour where the reference is excluded.
    if not reference and reference_company_id and not company_id and not include_reference:
        domain = [("id", "!=", reference_company_id)]
    companies = target_client.search_read("res.company", domain, fields=["id", "name"], order="id")
    if not companies:
        out.error("No companies found on target")
        raise typer.Exit(1)
    out.info(f"Target: {target_label} ({len(companies)} company/companies)")

    # Pull reference data once (one company = the gold standard)
    ref_company_data: dict | None = None
    ref_global: dict | None = None
    if ref_client:
        ref_companies = ref_client.search_read("res.company", [], fields=["id", "name"], order="id")
        if not ref_companies:
            out.error("Reference instance has no companies")
            raise typer.Exit(1)
        chosen = None
        if reference_company_id:
            chosen = next((c for c in ref_companies if c["id"] == reference_company_id), None)
            if not chosen:
                out.error(f"Reference company id {reference_company_id} not found")
                raise typer.Exit(1)
        else:
            chosen = ref_companies[0]
        out.info(f"  Reference company: {chosen['name']} (id={chosen['id']})")
        ref_company_data = _pull_company_data(ref_client, chosen["id"], chosen["name"])
        ref_global = _pull_global_data(ref_client)

    # Pull target global once
    target_global = _pull_global_data(target_client)

    # Per-company pull + check
    company_results: list[tuple[str, dict[str, list[dict]]]] = []
    for co in companies:
        out.info(f"  Auditing {co['name']}...")
        try:
            tdata = _pull_company_data(target_client, co["id"], co["name"])
            sheets = _check_company(tdata, ref_company_data, co["name"])
            company_results.append((co["name"], sheets))
        except (RPCError, ConnectionError, KeyError, ValueError) as exc:
            out.error(f"  {co['name']}: {exc}")

    # Default output path
    if not output:
        db = target_client.database or "odoo"
        output = Path(f"readiness_{db}_{date.today().isoformat()}.xlsx")

    if per_company:
        # One Excel per company. The supplied --output path becomes a
        # directory if it exists; otherwise it is treated as a stem
        # (path/to/readiness → path/to/readiness_<slug>.xlsx).
        if output.is_dir():
            out_dir = output
            stem = "readiness"
        else:
            out_dir = output.parent if str(output.parent) else Path(".")
            stem = output.stem
        out_dir.mkdir(parents=True, exist_ok=True)
        written: list[Path] = []
        for company_name, sheets in company_results:
            slug = "".join(ch if ch.isalnum() else "_" for ch in company_name).strip("_")[:60] or "company"
            out_file = out_dir / f"{stem}_{slug}.xlsx"
            _write_excel(
                [(company_name, sheets)],
                target_global,
                ref_global,
                out_file,
                target_label=target_label,
                reference_label=reference_label,
            )
            written.append(out_file)
        out.info(f"\nWrote {len(written)} per-company report(s) to {out_dir}")
        for p in written:
            out.info(f"  {p}")
    else:
        _write_excel(
            company_results,
            target_global,
            ref_global,
            output,
            target_label=target_label,
            reference_label=reference_label,
        )
        out.info(f"\nReport written to {output}")

    # Console summary
    for company_name, sheets in company_results:
        all_rows = [r for rows in sheets.values() for r in rows if r.get("Status") in ("PASS", "WARN", "FAIL")]
        fails = sum(1 for r in all_rows if r["Status"] == "FAIL")
        warns = sum(1 for r in all_rows if r["Status"] == "WARN")
        passes = sum(1 for r in all_rows if r["Status"] == "PASS")
        status = "READY" if fails == 0 else "NOT READY"
        out.info(f"  {company_name}: {status}  ({passes} pass / {fails} fail / {warns} warn)")
