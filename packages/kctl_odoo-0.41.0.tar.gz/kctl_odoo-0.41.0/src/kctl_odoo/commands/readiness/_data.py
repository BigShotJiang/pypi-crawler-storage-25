"""Data helpers and pull functions for production readiness audit."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from kctl_odoo.core.callbacks import AppContext
from kctl_odoo.core.exceptions import ConnectionError, RPCError

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

ACCOUNT_TYPES = [
    "asset_cash",
    "asset_receivable",
    "asset_current",
    "asset_non_current",
    "asset_prepayments",
    "asset_fixed",
    "liability_payable",
    "liability_credit_card",
    "liability_current",
    "liability_non_current",
    "equity",
    "equity_unaffected",
    "income",
    "income_other",
    "expense",
    "expense_direct_cost",
    "expense_depreciation",
    "off_balance",
]

CRITICAL_ACCOUNT_TYPES = {
    "asset_cash",
    "asset_receivable",
    "liability_payable",
    "income",
    "expense_direct_cost",
    "equity",
}

REQUIRED_MODULES = ["account", "stock", "mail"]
OPTIONAL_MODULES = [
    "l10n_id",
    "accurate_integration",
    "purchase",
    "sale",
    "point_of_sale",
    "hr",
    "project",
    "report_layout",
    "report_base",
    "report_finance",
]
TRACKED_MODULES = REQUIRED_MODULES + OPTIONAL_MODULES

CURRENCIES = ["IDR", "USD", "CNY", "THB"]

CRITICAL_PARAMS = {
    "web.base.url",
    "mail.catchall.domain",
    "mail.bounce.alias",
    "database.uuid",
    "report.url",
    "account.use_anglo_saxon",
    "accurate.signature_secret",
}

COMPANY_FIELDS = [
    "id",
    "name",
    "currency_id",
    "account_fiscal_country_id",
    "account_sale_tax_id",
    "account_purchase_tax_id",
    "income_currency_exchange_account_id",
    "expense_currency_exchange_account_id",
    "transfer_account_id",
    "anglo_saxon_accounting",
    "fiscalyear_lock_date",
    "tax_lock_date",
    "account_journal_suspense_account_id",
    # Note: account_journal_payment_debit/credit_account_id are NOT
    # on res.company in Odoo 18 — they're chart-template refs, set
    # per-journal via account.payment.method.line. Reading the entire
    # field list as one search_read fails the WHOLE call if any field
    # is invalid, hence the careful inclusion list.
    "default_cash_difference_income_account_id",
    "default_cash_difference_expense_account_id",
    "po_lock",
    "po_double_validation",
    "po_double_validation_amount",
    "po_lead",
    "quotation_validity_days",
    "portal_confirmation_sign",
    "portal_confirmation_pay",
]


# ---------------------------------------------------------------------------
# Profile + RPC helpers
# ---------------------------------------------------------------------------


def _load_profile(profile_name: str) -> dict:
    cfg_path = Path.home() / ".config" / "kodemeio" / "config.yaml"
    if not cfg_path.exists():
        raise FileNotFoundError(f"Config file not found: {cfg_path}")
    cfg = yaml.safe_load(cfg_path.read_text()) or {}
    profiles = cfg.get("profiles", {})
    p = (profiles.get(profile_name) or {}).get("odoo") or {}
    if not p:
        raise ValueError(f"Profile '{profile_name}' not found or has no 'odoo' section in {cfg_path}")
    missing = [k for k in ("url", "database", "username", "api_key") if not p.get(k)]
    if missing:
        raise ValueError(f"Profile '{profile_name}' is missing required fields: {', '.join(missing)}")
    return {
        "url": p["url"],
        "database": p["database"],
        "username": p["username"],
        "api_key": p["api_key"],
    }


class XmlRpcClient:
    """Thin xmlrpc wrapper exposing search_read/search_count/read."""

    def __init__(self, profile: dict, *, timeout: float = 600.0):
        import xmlrpc.client

        url = profile["url"].rstrip("/")
        self.url = url
        self.database = profile["database"]
        self._pw = profile["api_key"]
        # xmlrpc transport timeout is socket-level; expose for use_builtin_types
        common = xmlrpc.client.ServerProxy(f"{url}/xmlrpc/2/common", allow_none=True, use_builtin_types=True)
        uid = common.authenticate(self.database, profile["username"], self._pw, {})
        if not uid:
            raise RuntimeError(f"Authentication failed for db={self.database} user={profile['username']}")
        self.uid = uid
        self._models = xmlrpc.client.ServerProxy(f"{url}/xmlrpc/2/object", allow_none=True, use_builtin_types=True)

    def execute(self, model: str, method: str, *args, **kwargs):
        return self._models.execute_kw(self.database, self.uid, self._pw, model, method, list(args), kwargs)

    def search_read(
        self,
        model: str,
        domain: list | None = None,
        fields: list | None = None,
        limit: int = 0,
        order: str | None = None,
    ) -> list[dict]:
        kw: dict[str, Any] = {}
        if fields:
            kw["fields"] = fields
        if limit:
            kw["limit"] = limit
        if order:
            kw["order"] = order
        return self.execute(model, "search_read", domain or [], **kw)

    def search_count(self, model: str, domain: list | None = None) -> int:
        return self.execute(model, "search_count", domain or [])

    def read(self, model: str, ids: list[int], fields: list | None = None) -> list[dict]:
        kw: dict[str, Any] = {}
        if fields:
            kw["fields"] = fields
        return self.execute(model, "read", ids, **kw)


def _bump_timeout(actx: AppContext, seconds: float = 600.0) -> None:
    try:
        import httpx

        actx.client._client.timeout = httpx.Timeout(seconds)
    except (AttributeError, TypeError):
        pass


def _safe(value: Any, default: str = "") -> str:
    if value is False or value is None:
        return default
    if isinstance(value, list) and len(value) == 2:
        return str(value[1])
    return str(value)


def _safe_id(value: Any) -> int | None:
    if isinstance(value, list) and len(value) >= 1:
        return value[0]
    if isinstance(value, int):
        return value
    return None


def _mask(value: str) -> str:
    if not value:
        return ""
    s = str(value)
    if len(s) <= 8:
        return "****"
    return f"{s[:4]}****{s[-4:]}"


def _truncate(value: Any, length: int = 100) -> str:
    if value in (False, None):
        return ""
    s = str(value)
    return s if len(s) <= length else s[: length - 3] + "..."


# ---------------------------------------------------------------------------
# Data pulls
# ---------------------------------------------------------------------------


class _ClientShim:
    """Adapter exposing the same minimal API on AppContext.client and XmlRpcClient.

    The platform's AppContext.client implements search_read(model, domain, fields=...)
    so we just pass through. XmlRpcClient also matches.
    """

    def __init__(self, inner: Any):
        self._inner = inner

    @property
    def database(self) -> str:
        if hasattr(self._inner, "database"):
            db = self._inner.database
            return db() if callable(db) else db
        return ""

    def search_read(self, model, domain=None, fields=None, limit=0, order=None, **extra):
        kwargs: dict[str, Any] = {}
        if fields is not None:
            kwargs["fields"] = fields
        if limit:
            kwargs["limit"] = limit
        if order:
            kwargs["order"] = order
        ctx = extra.pop("context", None)
        if ctx and hasattr(self._inner, "execute_kw"):
            return self._inner.execute_kw(model, "search_read", [domain or []], {**kwargs, "context": ctx})
        kwargs.update(extra)
        return self._inner.search_read(model, domain or [], **kwargs)

    def search_count(self, model, domain=None):
        return self._inner.search_count(model, domain or [])


def _try(fn, default=None):
    try:
        return fn()
    except (RPCError, ConnectionError, KeyError, TypeError, ValueError):
        return default


# ---------------------------------------------------------------------------
# Configuration coverage: all menu items audited per company
# Tuple: (menu_path, item_label, model, scope, domain_template)
#   scope: "global" or "company"
#   domain_template: list of tuples (filled per company), e.g.
#                    [("company_id", "=", "<co_id>")] or [] for global
# ---------------------------------------------------------------------------
CONFIG_COVERAGE_ITEMS: list[tuple[str, str, str, str, list]] = [
    # --- Accounting Configuration ---
    ("Accounting", "Payment Terms", "account.payment.term", "company", []),
    ("Accounting", "Incoterms", "account.incoterms", "global", []),
    ("Accounting", "Bank Accounts (res.partner.bank)", "res.partner.bank", "company", []),
    ("Accounting", "Reconciliation Models", "account.reconcile.model", "company", []),
    ("Accounting", "Currencies", "res.currency", "global", []),
    ("Accounting", "Currency Rate Providers", "res.currency.rate.provider", "company", []),
    ("Accounting", "Account Tags", "account.account.tag", "global", []),
    ("Accounting", "Account Groups", "account.group", "company", []),
    ("Accounting", "Payment Providers", "payment.provider", "global", []),
    ("Accounting", "Payment Methods", "account.payment.method", "global", []),
    ("Accounting", "Payment Tokens", "payment.token", "company", []),
    # --- Purchase Configuration ---
    ("Purchase", "Vendor Pricelists (supplierinfo)", "product.supplierinfo", "company", []),
    ("Purchase", "Product Tags", "product.tag", "global", []),
    # --- Sales Configuration ---
    ("Sales", "Product Groups", "product.group", "global", []),
    ("Sales", "Product Attributes", "product.attribute", "global", []),
    ("Sales", "Sales Teams", "crm.team", "company", []),
    ("Sales", "Delivery Methods", "delivery.carrier", "company", []),
    ("Sales", "Sales Order Tags", "crm.tag", "global", []),
    ("Sales", "Sales Order Types", "sale.order.type", "global", []),
    ("Sales", "Combo Choices", "product.combo", "global", []),
    # --- Inventory Configuration ---
    ("Inventory", "Storage Categories", "stock.storage.category", "company", []),
    ("Inventory", "Putaway Rules", "stock.putaway.rule", "company", []),
    ("Inventory", "Docks", "stock.dock", "company", []),
    ("Inventory", "Barcode Nomenclatures", "barcode.nomenclature", "global", []),
    ("Inventory", "Cycle Count Rules", "stock.cycle.count.rule", "company", []),
    ("Inventory", "Scrap Reason Codes", "stock.scrap.reason", "global", []),
    ("Inventory", "Printer Profiles", "printer.profile", "global", []),
    ("Inventory", "Printer Rules", "printer.rule", "global", []),
    # --- Products Configuration ---
    ("Products", "Product Tags", "product.tag", "global", []),
    ("Products", "Units of Measure", "uom.uom", "global", []),
    ("Products", "UoM Categories", "uom.category", "global", []),
    # --- Report Layout ---
    ("Reports", "Report Formats", "report.format", "company", []),
    ("Reports", "Paper Formats", "report.paperformat", "global", []),
    # --- Report Management ---
    ("Reports", "Report Types", "report.type.registry", "global", []),
    ("Reports", "Report Templates", "report.template", "global", []),
    ("Reports", "Scheduled Reports", "report.schedule", "company", []),
    ("Reports", "Custom Queries", "report.custom.query", "company", []),
    ("Reports", "Report Instances", "report.instance", "company", []),
    # --- Tax (Indonesian) ---
    # Indonesian tax data — backed by `tax_management` private module models
    # (kodemeio uses tax.* prefix, not l10n_id.*). HR-only tables (PTKP /
    # TER / Progressive PPh21) are intentionally excluded from the ERP
    # readiness audit — they only fire when payroll_management is installed,
    # which lives on the separate HRMS instance.
    ("Tax (Indonesia)", "Kurs Pajak", "tax.kurs.pajak", "global", []),
    ("Tax (Indonesia)", "PPnBM Config", "tax.ppnbm.config", "global", []),
    ("Tax (Indonesia)", "PPh 23 Withholding", "pph23.withholding", "company", []),
    ("Tax (Indonesia)", "PPh 4(2) Withholding", "pph4.2.withholding", "company", []),
    ("Tax (Indonesia)", "PPh 26 Withholding", "pph26.withholding", "company", []),
    ("Tax (Indonesia)", "Bupot Non-Resident", "bupot.non.resident", "company", []),
    ("Tax (Indonesia)", "Bupot Unifikasi", "bupot.unifikasi", "company", []),
    ("Tax (Indonesia)", "Materai", "tax.materai", "global", []),
    ("Tax (Indonesia)", "Faktur Pajak Group", "faktur.pajak.group", "global", []),
    ("Tax (Indonesia)", "Tax Reconciliation", "tax.reconciliation", "company", []),
    ("Tax (Indonesia)", "Fiscal Correction", "tax.fiscal.correction", "company", []),
    ("Tax (Indonesia)", "Faktur Output", "l10n_id_efaktur.document", "company", []),
    # --- Contacts ---
    ("Contacts", "Contact Tags", "res.partner.category", "global", []),
    ("Contacts", "Contact Titles", "res.partner.title", "global", []),
    ("Contacts", "Industries", "res.partner.industry", "global", []),
    ("Contacts", "Banks (res.bank)", "res.bank", "global", []),
    ("Contacts", "Partner ID Categories", "l10n_latam.identification.type", "global", []),
    # --- System / Technical ---
    ("System", "Date Ranges", "date.range", "company", []),
    ("System", "Date Range Types", "date.range.type", "global", []),
    ("System", "Activity Types", "mail.activity.type", "global", []),
    ("System", "Email Blacklist", "mail.blacklist", "global", []),
    ("System", "Languages", "res.lang", "global", []),
    ("System", "Companies", "res.company", "global", []),
    ("System", "Cron Jobs", "ir.cron", "global", []),
    ("System", "Server Actions", "ir.actions.server", "global", []),
    ("System", "Automated Actions", "base.automation", "global", []),
    ("System", "Modules Installed", "ir.module.module", "global", [("state", "=", "installed")]),
]


def _pull_config_coverage(client: _ClientShim, company_id: int) -> list[dict]:
    """Pull counts for every CONFIG_COVERAGE_ITEMS entry, scoped per company.

    Returns list of dicts: {menu, item, model, scope, count, available, error}.
    Uses _try() to gracefully handle missing models.
    """
    rows: list[dict] = []
    seen_global: set[str] = set()
    for menu, item, model, scope, base_domain in CONFIG_COVERAGE_ITEMS:
        # Build domain
        if scope == "company":
            domain = list(base_domain) + [("company_id", "in", [company_id, False])]
        else:
            if model in seen_global:
                # Avoid duplicate global counts when called per company
                pass
            domain = list(base_domain)

        result: dict = {
            "Menu": menu,
            "Item": item,
            "Model": model,
            "Scope": scope,
            "Count": 0,
            "Available": False,
            "Error": "",
        }
        try:
            count = client.search_count(model, domain)
            result["Count"] = count if count is not None else 0
            result["Available"] = True
        except (RPCError, ConnectionError) as exc:
            msg = str(exc)
            # Detect "model does not exist" vs other errors
            if "does not exist" in msg.lower() or "Object" in msg and "doesn't exist" in msg:
                result["Error"] = "MODULE_NOT_INSTALLED"
            else:
                # Try without company_id constraint as fallback (model may not be company-scoped)
                if scope == "company":
                    try:
                        count = client.search_count(model, list(base_domain))
                        result["Count"] = count if count is not None else 0
                        result["Available"] = True
                        result["Scope"] = "global (fallback)"
                    except (RPCError, ConnectionError) as exc2:
                        result["Error"] = str(exc2)[:120]
                else:
                    result["Error"] = msg[:120]
        rows.append(result)
    return rows


def _pull_company_data(client: _ClientShim, company_id: int, company_name: str) -> dict:
    """Pull every piece of configuration we audit, scoped to one company.

    Returns a dict that both target and reference share the shape of, so the
    comparison logic can be symmetric.
    """
    data: dict[str, Any] = {
        "company_id": company_id,
        "company_name": company_name,
    }

    # Company settings
    co = _try(
        lambda: client.search_read(
            "res.company",
            [("id", "=", company_id)],
            fields=COMPANY_FIELDS + ["logo"],
            context={
                "allowed_company_ids": [company_id],
                "company_id": company_id,
                "default_company_id": company_id,
            },
        ),
        default=[],
    )
    data["company"] = co[0] if co else {}

    # Accounts: full listing for this company. Odoo 18 stores `code` as a
    # company-scoped computed field over the `code_store` JSONB; without
    # `allowed_company_ids` in context, `code` reads as False. The shim's
    # search_read forwards context kwargs through to execute_kw.
    accounts_ctx = {
        "context": {
            "allowed_company_ids": [company_id],
            "company_id": company_id,
            "default_company_id": company_id,
        }
    }
    accounts = _try(
        lambda: client.search_read(
            "account.account",
            [("company_ids", "in", company_id)],
            fields=["id", "code", "name", "account_type", "deprecated"],
            order="code",
            **accounts_ctx,
        ),
        default=[],
    )
    if not accounts or all(not a.get("code") for a in accounts):
        # Fallback path for shim variants that don't forward context: read raw
        # JSONB and pluck the per-company code.
        raw = _try(
            lambda: client.search_read(
                "account.account",
                [("company_ids", "in", company_id)],
                fields=["id", "code_store", "name", "account_type", "deprecated"],
                order="id",
            ),
            default=[],
        )
        for a in raw:
            store = a.get("code_store") or {}
            if isinstance(store, dict):
                a["code"] = store.get(str(company_id)) or store.get(company_id) or ""
            else:
                a["code"] = ""
            a.pop("code_store", None)
        accounts = raw
    data["accounts"] = accounts

    # Account ext-ids (ir.model.data) for accounts in this company
    ext_ids: dict[int, str] = {}
    if accounts:
        acc_ids = [a["id"] for a in accounts]
        # batch in chunks of 500 to avoid huge domains
        for i in range(0, len(acc_ids), 500):
            chunk = acc_ids[i : i + 500]
            rows = (
                _try(
                    lambda c=chunk: client.search_read(
                        "ir.model.data",
                        [("model", "=", "account.account"), ("res_id", "in", c)],
                        fields=["res_id", "module", "name"],
                    ),
                    default=[],
                )
                or []
            )
            for r in rows:
                ext_ids[r["res_id"]] = f"{r['module']}.{r['name']}"
    data["account_ext_ids"] = ext_ids

    # Journals (full)
    data["journals"] = _try(
        lambda: client.search_read(
            "account.journal",
            [("company_id", "=", company_id)],
            fields=[
                "id",
                "name",
                "code",
                "type",
                "default_account_id",
                "suspense_account_id",
                "currency_id",
                "active",
            ],
            order="type, code",
        ),
        default=[],
    )

    # Taxes (full)
    taxes = _try(
        lambda: client.search_read(
            "account.tax",
            [("company_id", "=", company_id)],
            fields=[
                "id",
                "name",
                "type_tax_use",
                "amount",
                "amount_type",
                "tax_group_id",
                "active",
            ],
            order="type_tax_use, name",
        ),
        default=[],
    )
    data["taxes"] = taxes

    # Tax repartition lines (so we can map tax -> GL accounts)
    tax_accounts: dict[int, list[str]] = {}
    if taxes:
        rep = (
            _try(
                lambda: client.search_read(
                    "account.tax.repartition.line",
                    [("company_id", "=", company_id), ("tax_id", "in", [t["id"] for t in taxes])],
                    fields=["tax_id", "account_id", "repartition_type", "factor_percent"],
                ),
                default=[],
            )
            or []
        )
        for r in rep:
            tid = _safe_id(r.get("tax_id"))
            acc = _safe(r.get("account_id"))
            if tid and acc:
                tax_accounts.setdefault(tid, []).append(acc)
    data["tax_accounts"] = tax_accounts

    # Tax groups
    data["tax_groups"] = _try(
        lambda: client.search_read(
            "account.tax.group",
            [],
            fields=[
                "id",
                "name",
                "tax_payable_account_id",
                "tax_receivable_account_id",
                "advance_tax_payment_account_id",
            ],
            order="name",
        ),
        default=[],
    )

    # Fiscal positions
    data["fiscal_positions"] = _try(
        lambda: client.search_read(
            "account.fiscal.position",
            [("company_id", "=", company_id)],
            fields=[
                "id",
                "name",
                "country_id",
                "auto_apply",
                "account_ids",
                "tax_ids",
            ],
            order="name",
        ),
        default=[],
    )

    # Payment terms — global (shared across companies). Useful Indonesian set:
    # Tunai (COD), TOP 7/14/30/45/60 Hari, DP 50%/100%, Pembayaran Tunai, etc.
    data["payment_terms"] = _try(
        lambda: client.search_read(
            "account.payment.term",
            [],
            fields=["id", "name", "active", "note", "early_discount"],
            order="name",
        ),
        default=[],
    )

    # Product categories (NOT company-scoped — shared)
    data["categories"] = _try(
        lambda: client.search_read(
            "product.category",
            [],
            fields=[
                "id",
                "name",
                "property_cost_method",
                "property_valuation",
                "property_account_income_categ_id",
                "property_account_expense_categ_id",
                "property_stock_account_input_categ_id",
                "property_stock_account_output_categ_id",
                "property_stock_valuation_account_id",
                "property_stock_journal",
            ],
            order="name",
        ),
        default=[],
    )

    # Warehouses
    data["warehouses"] = _try(
        lambda: client.search_read(
            "stock.warehouse",
            [("company_id", "=", company_id)],
            fields=[
                "id",
                "name",
                "code",
                "lot_stock_id",
                "reception_steps",
                "delivery_steps",
                "active",
            ],
            order="code",
        ),
        default=[],
    )

    # Operation types
    data["picking_types"] = _try(
        lambda: client.search_read(
            "stock.picking.type",
            [("company_id", "=", company_id)],
            fields=[
                "id",
                "name",
                "sequence_code",
                "code",
                "warehouse_id",
                "default_location_src_id",
                "default_location_dest_id",
            ],
            order="warehouse_id, sequence_code",
        ),
        default=[],
    )

    # Stock locations
    data["locations"] = _try(
        lambda: client.search_read(
            "stock.location",
            [("company_id", "=", company_id)],
            fields=["id", "name", "complete_name", "usage", "active"],
            order="usage, complete_name",
        ),
        default=[],
    )

    # Stock summary
    data["stock_summary"] = {
        "quants": _try(lambda: client.search_count("stock.quant", [("company_id", "=", company_id)]), default=0),
        "products_with_stock": _try(
            lambda: len(
                {
                    _safe_id(q["product_id"])
                    for q in client.search_read(
                        "stock.quant",
                        [("company_id", "=", company_id), ("quantity", ">", 0)],
                        fields=["product_id"],
                        limit=20000,
                    )
                    if _safe_id(q.get("product_id"))
                }
            ),
            default=0,
        ),
        "svl_count": _try(
            lambda: client.search_count("stock.valuation.layer", [("company_id", "=", company_id)]), default=0
        ),
    }

    # Operating units
    ou_data: list = _try(
        lambda: client.search_read(
            "operating.unit",
            [("company_id", "=", company_id)],
            fields=["id", "code", "name", "partner_id", "active"],
            order="code",
        ),
        default=None,
    )
    data["operating_units"] = ou_data if ou_data is not None else "MODULE_NOT_INSTALLED"

    # User counts per OU
    ou_user_counts: dict[int, int] = {}
    if isinstance(ou_data, list) and ou_data:
        for ou in ou_data:
            cnt = _try(
                lambda oid=ou["id"]: client.search_count(
                    "res.users", [("default_operating_unit_id", "=", oid), ("active", "=", True)]
                ),
                default=0,
            )
            ou_user_counts[ou["id"]] = cnt
    data["ou_user_counts"] = ou_user_counts

    # Report formats (report_layout module). `logo` is not a field on
    # report.format in Odoo 18 — the show-logo flag is `show_logo`.
    rfmt = _try(
        lambda: client.search_read(
            "report.format",
            [("company_id", "=", company_id)],
            fields=[
                "id",
                "report_type",
                "name",
                "is_default",
                "active",
                "show_logo",
                "theme_preset",
                "band_ids",
                "signature_line_ids",
            ],
            order="report_type, name",
        ),
        default=None,
    )
    data["report_formats"] = rfmt if rfmt is not None else "MODULE_NOT_INSTALLED"

    # Report management instances (report_finance)
    rinst = _try(
        lambda: client.search_read(
            "report.instance",
            [("company_id", "=", company_id)],
            fields=["id", "name", "template_id", "report_type"],
            order="name",
        ),
        default=None,
    )
    data["report_instances"] = rinst if rinst is not None else "MODULE_NOT_INSTALLED"

    # Report types registry (global)
    rtypes = _try(
        lambda: client.search_read(
            "report.type.registry",
            [],
            fields=["id", "name", "code", "category", "handler_model"],
            order="category, name",
        ),
        default=None,
    )
    data["report_types"] = rtypes if rtypes is not None else "MODULE_NOT_INSTALLED"

    # Sequences (per-company) — include prefix/suffix so the audit shows the
    # actual numbering pattern (e.g. "INV/%(year)s/%(month)s/") not just padding
    data["sequences"] = _try(
        lambda: client.search_read(
            "ir.sequence",
            ["|", ("company_id", "=", company_id), ("company_id", "=", False)],
            fields=[
                "id",
                "code",
                "name",
                "prefix",
                "suffix",
                "number_next",
                "padding",
                "implementation",
                "use_date_range",
                "active",
            ],
            order="code",
        ),
        default=[],
    )

    # NOTE: ir.property was removed from Odoo 18 — company-dependent values
    # are now stored directly on company_dependent fields (JSONB columns).
    # Keeping the key so downstream code can detect the absence cleanly.
    data["properties"] = []

    # Configuration coverage — every menu item enumerated below
    data["config_coverage"] = _pull_config_coverage(client, company_id)

    # Master data quality — sample products, partners, categories, journals
    # for per-record field validation
    data["products_sample"] = _try(
        lambda: client.search_read(
            "product.template",
            [("active", "=", True)],
            fields=[
                "id",
                "name",
                "default_code",
                "barcode",
                "type",
                "categ_id",
                "uom_id",
                "uom_po_id",
                "list_price",
                "standard_price",
                "taxes_id",
                "supplier_taxes_id",
                "property_account_income_id",
                "property_account_expense_id",
                "company_id",
            ],
            limit=2000,
        ),
        default=[],
    )

    data["partners_sample"] = _try(
        lambda: client.search_read(
            "res.partner",
            ["|", ("customer_rank", ">", 0), ("supplier_rank", ">", 0)],
            fields=[
                "id",
                "name",
                "is_company",
                "customer_rank",
                "supplier_rank",
                "vat",
                "email",
                "phone",
                "mobile",
                "country_id",
                "state_id",
                "property_account_receivable_id",
                "property_account_payable_id",
                "property_payment_term_id",
                "property_supplier_payment_term_id",
                "property_account_position_id",
                "bank_ids",
                "company_id",
            ],
            limit=3000,
        ),
        default=[],
    )

    # All product categories with full property fields
    data["categories_full"] = _try(
        lambda: client.search_read(
            "product.category",
            [],
            fields=[
                "id",
                "name",
                "property_cost_method",
                "property_valuation",
                "property_account_income_categ_id",
                "property_account_expense_categ_id",
                "property_stock_account_input_categ_id",
                "property_stock_account_output_categ_id",
                "property_stock_valuation_account_id",
                "property_stock_journal",
            ],
            order="name",
        ),
        default=[],
    )

    # Bank journals — must have bank_account_id linked (real bank journals only;
    # payment-provider journals like iPaymu/Midtrans are virtual)
    data["bank_journals_detail"] = _try(
        lambda: client.search_read(
            "account.journal",
            [("company_id", "=", company_id), ("type", "in", ["bank", "cash"])],
            fields=[
                "id",
                "code",
                "name",
                "type",
                "bank_account_id",
                "default_account_id",
                "suspense_account_id",
                "currency_id",
                "inbound_payment_method_line_ids",
                "outbound_payment_method_line_ids",
            ],
        ),
        default=[],
    )

    # Payment-provider journal IDs (iPaymu, Midtrans, Xendit etc.) — these are
    # virtual bank journals tied to a payment gateway and do not need a real
    # bank_account_id, so the Bank Journal Quality check excludes them.
    data["payment_provider_journal_ids"] = set(
        _try(
            lambda: [
                p["journal_id"][0]
                for p in client.search_read(
                    "payment.provider",
                    [("journal_id", "!=", False)],
                    fields=["journal_id"],
                )
                if p.get("journal_id")
            ],
            default=[],
        )
    )

    # Report types from registry (financial reports must exist)
    data["report_types_full"] = _try(
        lambda: client.search_read(
            "report.type.registry",
            [],
            fields=["id", "name", "category", "code", "handler_model"],
            order="category, name",
        ),
        default=[],
    )

    # Report templates linked to types — `report_type` is a selection char that
    # mirrors the registry's `code`, so we can still join on that key downstream.
    data["report_templates_full"] = _try(
        lambda: client.search_read(
            "report.template",
            [],
            fields=["id", "name", "report_type", "report_type_id", "active"],
            order="name",
        ),
        default=[],
    )

    return data


def _pull_global_data(client: _ClientShim) -> dict:
    """Pull data not scoped to a single company (modules, currencies, params, mail)."""
    data: dict[str, Any] = {}

    # Modules — pull every installed module so the audit is complete, plus
    # the curated TRACKED_MODULES even when not installed (so we flag gaps).
    data["modules"] = _try(
        lambda: client.search_read(
            "ir.module.module",
            ["|", ("state", "=", "installed"), ("name", "in", TRACKED_MODULES)],
            fields=["name", "state", "installed_version", "shortdesc"],
            order="name",
        ),
        default=[],
    )

    # Currencies
    data["currencies"] = _try(
        lambda: client.search_read(
            "res.currency",
            [("name", "in", CURRENCIES)],
            fields=["name", "active", "rate", "rounding", "symbol"],
            order="name",
        ),
        default=[],
    )

    # Mail servers
    data["mail_servers"] = _try(
        lambda: client.search_read(
            "ir.mail_server",
            [],
            fields=["id", "name", "smtp_host", "smtp_port", "smtp_encryption", "active"],
            order="sequence, id",
        ),
        default=[],
    )

    # ir.config_parameter (filter to a sane size)
    params = _try(
        lambda: client.search_read(
            "ir.config_parameter",
            [],
            fields=["key", "value"],
            order="key",
            limit=2000,
        ),
        default=[],
    )
    data["config_params"] = params

    return data
