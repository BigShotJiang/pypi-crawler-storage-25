"""Excel export for production readiness audit."""

from __future__ import annotations

from datetime import date
from pathlib import Path

from ._data import (
    CRITICAL_PARAMS,
    CURRENCIES,
    REQUIRED_MODULES,
    TRACKED_MODULES,
    _mask,
    _truncate,
)

# ---------------------------------------------------------------------------
# Excel writer
# ---------------------------------------------------------------------------


SHEET_ORDER = [
    "Summary",
    "Top Issues",
    "Config Coverage",
    "Financial Reports Setup",
    "Product Quality",
    "Partner Quality",
    "Category Quality",
    "Bank Journal Quality",
    "Company Settings",
    "CoA - Account Listing",
    "Account Types Coverage",
    "Journals",
    "Taxes",
    "Tax Groups",
    "Fiscal Positions",
    "Payment Terms",
    "Product Categories",
    "Warehouses + Op Types",
    "Stock Locations",
    "Operating Units",
    "Report Layouts",
    "Report Management",
    "ir.config_parameter",
    "ir.property",
    "Modules + Currencies",
    "Sequences",
]


def _write_excel(
    company_results: list[tuple[str, dict[str, list[dict]]]],
    target_global: dict,
    ref_global: dict | None,
    output: Path,
    target_label: str,
    reference_label: str | None,
) -> None:
    """Write the multi-sheet workbook."""
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    hdr_font = Font(bold=True, color="FFFFFF", size=11)
    hdr_fill = PatternFill("solid", fgColor="2F5496")
    pass_fill = PatternFill("solid", fgColor="C6EFCE")
    warn_fill = PatternFill("solid", fgColor="FFEB9C")
    fail_fill = PatternFill("solid", fgColor="FFC7CE")
    info_fill = PatternFill("solid", fgColor="DDEBF7")
    border = Border(
        left=Side(style="thin", color="D9D9D9"),
        right=Side(style="thin", color="D9D9D9"),
        top=Side(style="thin", color="D9D9D9"),
        bottom=Side(style="thin", color="D9D9D9"),
    )

    def status_fill(s: str):
        return {
            "PASS": pass_fill,
            "WARN": warn_fill,
            "FAIL": fail_fill,
            "INFO": info_fill,
            "N/A": info_fill,
        }.get(s)

    def write_table(ws, headers: list[str], rows: list[dict], widths: dict[str, int] | None = None):
        # Header row
        for col, h in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=h)
            cell.font = hdr_font
            cell.fill = hdr_fill
            cell.alignment = Alignment(horizontal="center", wrap_text=True)
            cell.border = border
        # Default widths
        for col, h in enumerate(headers, 1):
            w = (widths or {}).get(h)
            if w is None:
                if h in ("Status", "Active", "Has Ext-ID", "Is Default", "Has Logo", "Auto Apply"):
                    w = 12
                elif h in ("Code", "Type", "Type Use", "Amount", "Padding", "Number Next"):
                    w = 14
                elif h in ("Note", "Vs Reference", "Reference Value"):
                    w = 50
                elif h == "Name" or h == "Setting" or h == "Field" or h == "OU Name":
                    w = 35
                elif h == "Company":
                    w = 32
                else:
                    w = 22
            ws.column_dimensions[get_column_letter(col)].width = w

        for r_idx, row in enumerate(rows, 2):
            for c_idx, h in enumerate(headers, 1):
                val = row.get(h, "")
                cell = ws.cell(row=r_idx, column=c_idx, value=val if val != "" else None)
                cell.font = Font(size=10)
                cell.border = border
                if h == "Status":
                    fill = status_fill(str(val))
                    if fill:
                        cell.fill = fill
                    cell.font = Font(size=10, bold=True)
                    cell.alignment = Alignment(horizontal="center")

        ws.freeze_panes = "A2"
        if rows:
            ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{len(rows) + 1}"

    # ── Sheet 1: Summary ──────────────────────────────────────────────
    ws = wb.active
    ws.title = "Summary"
    sections = [
        "Company Settings",
        "CoA - Account Listing",
        "Account Types Coverage",
        "Journals",
        "Taxes",
        "Tax Groups",
        "Fiscal Positions",
        "Payment Terms",
        "Product Categories",
        "Warehouses + Op Types",
        "Stock Locations",
        "Operating Units",
        "Report Layouts",
    ]
    headers = ["Company"] + sections + ["Total Pass", "Total Fail", "Total Warn", "Ready?"]
    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=h)
        cell.font = hdr_font
        cell.fill = hdr_fill
        cell.alignment = Alignment(horizontal="center", wrap_text=True)
        cell.border = border
    ws.column_dimensions["A"].width = 35
    for col in range(2, 2 + len(sections)):
        ws.column_dimensions[get_column_letter(col)].width = 13
    ws.column_dimensions[get_column_letter(2 + len(sections))].width = 12
    ws.column_dimensions[get_column_letter(3 + len(sections))].width = 12
    ws.column_dimensions[get_column_letter(4 + len(sections))].width = 12
    ws.column_dimensions[get_column_letter(5 + len(sections))].width = 13

    row = 2
    for company_name, sheets in company_results:
        ws.cell(row=row, column=1, value=company_name).font = Font(size=10, bold=True)
        total_pass = total_fail = total_warn = 0
        for col_off, sec in enumerate(sections):
            checks = sheets.get(sec, [])
            counted = [c for c in checks if c.get("Status") in ("PASS", "WARN", "FAIL")]
            passes = sum(1 for c in counted if c["Status"] == "PASS")
            fails = sum(1 for c in counted if c["Status"] == "FAIL")
            warns = sum(1 for c in counted if c["Status"] == "WARN")
            total_pass += passes
            total_fail += fails
            total_warn += warns
            cell = ws.cell(row=row, column=2 + col_off, value=f"{passes}/{len(counted)}")
            cell.alignment = Alignment(horizontal="center")
            cell.border = border
            if fails > 0:
                cell.fill = fail_fill
            elif warns > 0:
                cell.fill = warn_fill
            elif passes > 0:
                cell.fill = pass_fill
            else:
                cell.fill = info_fill
        ws.cell(row=row, column=2 + len(sections), value=total_pass).font = Font(bold=True)
        ws.cell(row=row, column=3 + len(sections), value=total_fail).font = Font(bold=True)
        ws.cell(row=row, column=4 + len(sections), value=total_warn).font = Font(bold=True)
        ready = "READY" if total_fail == 0 else "NOT READY"
        ready_cell = ws.cell(row=row, column=5 + len(sections), value=ready)
        ready_cell.font = Font(bold=True)
        ready_cell.fill = pass_fill if total_fail == 0 else fail_fill
        ready_cell.alignment = Alignment(horizontal="center")
        for col in range(1, len(headers) + 1):
            ws.cell(row=row, column=col).border = border
        row += 1
    ws.freeze_panes = "B2"
    if company_results:
        ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{len(company_results) + 1}"

    # Add header banner row at top describing target/reference
    ws_meta = wb.create_sheet("README", 0)
    wb.move_sheet("README", offset=-wb.index(ws_meta))
    ws_meta.column_dimensions["A"].width = 24
    ws_meta.column_dimensions["B"].width = 60
    meta_rows = [
        ("Generated", date.today().isoformat()),
        ("Target", target_label),
        ("Reference", reference_label or "(none — existence-only check)"),
        ("# Companies", str(len(company_results))),
        ("Sheets", ", ".join(SHEET_ORDER)),
    ]
    for r, (k, v) in enumerate(meta_rows, 1):
        c1 = ws_meta.cell(row=r, column=1, value=k)
        c1.font = Font(bold=True)
        c1.fill = hdr_fill
        c1.font = hdr_font
        ws_meta.cell(row=r, column=2, value=v).font = Font(size=10)

    # ── Detail sheets driven by per-company checks ──────────────────────
    detail_sections: list[tuple[str, list[str]]] = [
        ("Company Settings", ["Company", "Setting", "Value", "Reference Value", "Status", "Note"]),
        (
            "CoA - Account Listing",
            ["Company", "Code", "Name", "Type", "Has Ext-ID", "Ext-ID", "Deprecated", "Status", "Vs Reference"],
        ),
        (
            "Account Types Coverage",
            ["Company", "Account Type", "Target Count", "Reference Count", "Status", "Note"],
        ),
        (
            "Journals",
            [
                "Company",
                "Code",
                "Type",
                "Name",
                "Default Account",
                "Suspense Account",
                "Currency",
                "Active",
                "Status",
                "Note",
                "Vs Reference",
            ],
        ),
        (
            "Taxes",
            [
                "Company",
                "Name",
                "Type Use",
                "Amount",
                "Amount Type",
                "Tax Group",
                "GL Account(s)",
                "Active",
                "Status",
                "Note",
                "Vs Reference",
            ],
        ),
        (
            "Tax Groups",
            [
                "Company",
                "Group Name",
                "Payable Account",
                "Receivable Account",
                "Advance Account",
                "Used By Active Tax",
                "Status",
                "Note",
                "Vs Reference",
            ],
        ),
        (
            "Fiscal Positions",
            [
                "Company",
                "Name",
                "Country",
                "Auto Apply",
                "# Account Mappings",
                "# Tax Mappings",
                "Status",
                "Vs Reference",
            ],
        ),
        (
            "Payment Terms",
            [
                "Company",
                "Term ID",
                "Name",
                "Active",
                "Early Discount",
                "Status",
                "Vs Reference",
            ],
        ),
        (
            "Product Categories",
            [
                "Company",
                "Name",
                "Cost Method",
                "Valuation",
                "Income",
                "Expense",
                "Stock Input",
                "Stock Output",
                "Stock Valuation",
                "Stock Journal",
                "Status",
                "Note",
            ],
        ),
        (
            "Warehouses + Op Types",
            [
                "Company",
                "Section",
                "Code",
                "Name",
                "Stock Loc / Source",
                "Reception Steps / Dest",
                "Delivery Steps / Type",
                "Active",
                "Status",
            ],
        ),
        ("Stock Locations", ["Company", "Location Type", "Count", "Note", "Status"]),
        (
            "Operating Units",
            ["Company", "Code", "OU Name", "Partner", "# Users Assigned", "Active", "Status"],
        ),
        (
            "Report Layouts",
            [
                "Company",
                "Report Type",
                "Format Name",
                "Is Default",
                "# Bands",
                "# Signature Lines",
                "Has Logo",
                "Theme Preset",
                "Status",
                "Note",
            ],
        ),
        (
            "Report Management",
            ["Company", "Section", "Name", "Template", "Report Type / Handler", "Status"],
        ),
        (
            "Sequences",
            [
                "Company",
                "Code",
                "Name",
                "Prefix",
                "Suffix",
                "Sample Number",
                "Number Next",
                "Padding",
                "Date Range",
                "Implementation",
                "Active",
                "Status",
            ],
        ),
        ("ir.property", ["Company", "Field", "Label", "Value", "Reference Value", "Status"]),
        (
            "Config Coverage",
            [
                "Company",
                "Menu",
                "Item",
                "Model",
                "Scope",
                "Target Count",
                "Reference Count",
                "Status",
                "Note",
            ],
        ),
        (
            "Financial Reports Setup",
            [
                "Company",
                "Category",
                "Report",
                "Handler",
                "Has report.type",
                "Has report.template",
                "Type Name",
                "Template Name",
                "Status",
                "Note",
            ],
        ),
        (
            "Product Quality",
            [
                "Company",
                "Product ID",
                "Name",
                "Code",
                "Type",
                "Severity",
                "Category",
                "Missing Fields",
                "Fix",
                "Status",
                "Issue Count",
            ],
        ),
        (
            "Partner Quality",
            [
                "Company",
                "Partner ID",
                "Name",
                "Type",
                "Severity",
                "VAT",
                "Email",
                "Missing Fields",
                "Fix",
                "Status",
                "Issue Count",
            ],
        ),
        (
            "Category Quality",
            [
                "Company",
                "Category ID",
                "Name",
                "Cost Method",
                "Valuation",
                "Income Account",
                "Expense Account",
                "Stock Input",
                "Stock Output",
                "Stock Valuation",
                "Stock Journal",
                "Missing Fields",
                "Status",
            ],
        ),
        (
            "Bank Journal Quality",
            [
                "Company",
                "Journal ID",
                "Code",
                "Name",
                "Type",
                "Bank Account",
                "Default Account",
                "Suspense Account",
                "Currency",
                "Missing Fields",
                "Status",
            ],
        ),
        (
            "Top Issues",
            ["Company", "Severity", "Sheet", "Item", "Issue", "Fix", "Status"],
        ),
    ]

    for title, hdrs in detail_sections:
        ws = wb.create_sheet(title)
        all_rows: list[dict] = []
        for company_name, sheets in company_results:
            all_rows.extend(sheets.get(title, []))
        write_table(ws, hdrs, all_rows)

    # ── ir.config_parameter (global) ────────────────────────────────────
    ws = wb.create_sheet("ir.config_parameter")
    headers = ["Key", "Value", "Reference Value", "Status", "Note"]
    rows: list[dict] = []
    target_params = {p["key"]: p["value"] for p in (target_global.get("config_params") or [])}
    ref_params = {p["key"]: p["value"] for p in ((ref_global or {}).get("config_params") or [])}
    all_keys = sorted(set(target_params) | set(ref_params))
    for key in all_keys:
        tval = target_params.get(key, "")
        rval = ref_params.get(key, "")
        is_critical = key in CRITICAL_PARAMS
        is_secret = any(s in key.lower() for s in ("secret", "password", "token", "api_key"))
        tdisplay = _mask(tval) if is_secret else _truncate(tval, 100)
        rdisplay = _mask(rval) if is_secret else _truncate(rval, 100)
        if is_critical and not tval:
            status = "FAIL"
            note = "Critical parameter missing"
        elif is_critical:
            status = "PASS"
            note = "Critical parameter"
        else:
            status = "INFO"
            note = ""
        rows.append(
            {
                "Key": key,
                "Value": tdisplay,
                "Reference Value": rdisplay if ref_global else "",
                "Status": status,
                "Note": note,
            }
        )
    write_table(ws, headers, rows, widths={"Key": 50, "Value": 50, "Reference Value": 50, "Note": 40})

    # ── Modules + Currencies + Mail (global) ────────────────────────────
    ws = wb.create_sheet("Modules + Currencies")
    headers = ["Section", "Item", "Target State / Active", "Reference", "Status", "Note"]
    rows = []
    target_modules = {m["name"]: m for m in (target_global.get("modules") or [])}
    ref_modules = {m["name"]: m for m in ((ref_global or {}).get("modules") or [])}
    # Render: every installed module on target, plus any tracked-but-missing
    # ones so config gaps still surface.
    all_module_names = sorted(set(target_modules.keys()) | set(TRACKED_MODULES))
    for mod in all_module_names:
        tm = target_modules.get(mod, {})
        rm = ref_modules.get(mod, {})
        tstate = tm.get("state", "not found")
        rstate = rm.get("state", "not found") if ref_global else "-"
        if mod in REQUIRED_MODULES:
            status = "PASS" if tstate == "installed" else "FAIL"
        elif mod in TRACKED_MODULES:
            if tstate == "installed":
                status = "PASS"
            elif rstate == "installed":
                status = "WARN"
            else:
                status = "INFO"
        else:
            # Installed module not on the curated tracker — mark INFO.
            status = "PASS" if tstate == "installed" else "INFO"
        note = "Required" if mod in REQUIRED_MODULES else ("Tracked" if mod in TRACKED_MODULES else "")
        rows.append(
            {
                "Section": "Module",
                "Item": mod,
                "Target State / Active": f"{tstate} ({tm.get('installed_version', '')})" if tm else tstate,
                "Reference": rstate,
                "Status": status,
                "Note": note,
            }
        )

    # Currencies
    target_curr = {c["name"]: c for c in (target_global.get("currencies") or [])}
    ref_curr = {c["name"]: c for c in ((ref_global or {}).get("currencies") or [])}
    for ccode in CURRENCIES:
        t = target_curr.get(ccode, {})
        r = ref_curr.get(ccode, {})
        active = t.get("active")
        rate = t.get("rate", "")
        rows.append(
            {
                "Section": "Currency",
                "Item": ccode,
                "Target State / Active": f"active={active}, rate={rate}",
                "Reference": f"active={r.get('active')}, rate={r.get('rate', '')}" if ref_global else "-",
                "Status": "PASS" if active else "WARN",
                "Note": "",
            }
        )

    # Mail servers
    msrvs = target_global.get("mail_servers") or []
    rmsrvs = (ref_global or {}).get("mail_servers") or []
    if msrvs:
        for s in msrvs:
            rows.append(
                {
                    "Section": "Mail Server",
                    "Item": s.get("name") or "",
                    "Target State / Active": (
                        f"{s.get('smtp_host')}:{s.get('smtp_port')} ({s.get('smtp_encryption', '-')})"
                        f" {'active' if s.get('active') else 'inactive'}"
                    ),
                    "Reference": "",
                    "Status": "PASS" if s.get("active") else "WARN",
                    "Note": "",
                }
            )
    else:
        rows.append(
            {
                "Section": "Mail Server",
                "Item": "(none configured)",
                "Target State / Active": "",
                "Reference": f"{len(rmsrvs)} server(s) in reference" if ref_global else "-",
                "Status": "WARN",
                "Note": "No outgoing mail server configured",
            }
        )
    write_table(
        ws, headers, rows, widths={"Section": 14, "Item": 32, "Target State / Active": 50, "Reference": 30, "Note": 30}
    )

    # Reorder sheets to match SHEET_ORDER (README first, then ordered)
    desired = ["README"] + SHEET_ORDER
    for idx, name in enumerate(desired):
        if name in wb.sheetnames:
            sheet = wb[name]
            current = wb.index(sheet)
            offset = idx - current
            if offset:
                wb.move_sheet(sheet, offset=offset)

    wb.save(str(output))
