"""Health check and database statistics commands."""

from __future__ import annotations

from datetime import UTC

import typer

from kctl_odoo.core.callbacks import AppContext
from kctl_odoo.core.exceptions import ConnectionError, RPCError

app = typer.Typer(help="Health checks and database statistics.")


@app.command("autovacuum")
def autovacuum(ctx: typer.Context) -> None:
    """Trigger Odoo's built-in autovacuum (ir.autovacuum).

    Cleans up:
    - Expired transient records (wizards)
    - Orphan filestore entries
    - Old bus.bus notifications
    - Expired sessions (if session_db is used)
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    # Find the autovacuum cron and trigger it
    out.info("Looking for AutoVacuum scheduled action...")
    crons = c.search_read(
        "ir.cron",
        domain=[("name", "ilike", "autovacuum")],
        fields=["id", "name"],
        limit=1,
    )
    if not crons:
        # Fallback: search by model
        crons = c.search_read(
            "ir.cron",
            domain=[("model_id.model", "=", "ir.autovacuum")],
            fields=["id", "name"],
            limit=1,
        )
    if not crons:
        out.error("AutoVacuum cron not found. Run: kctl-odoo cron list | grep -i vacuum")
        raise typer.Exit(1)

    cron_id = crons[0]["id"]
    out.info(f"Triggering '{crons[0]['name']}' (ID {cron_id})...")
    try:
        c.execute_kw("ir.cron", "method_direct_trigger", [[cron_id]])
        out.success("Autovacuum completed — transient records, orphan files, and expired data cleaned.")
    except (RPCError, ConnectionError) as e:
        out.error(f"Autovacuum trigger failed: {e}")
        raise typer.Exit(1) from e


@app.command("db-stats")
def db_stats(ctx: typer.Context) -> None:
    """Show database size and growth indicators.

    Reports record counts for the largest tables, attachment storage,
    and key growth metrics useful for capacity planning.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    def _count(model: str) -> int:
        try:
            return c.search_count(model, [])
        except (RPCError, ConnectionError):
            return -1

    # Key tables that grow over time
    tables = [
        ("res.partner", "Partners / Contacts"),
        ("product.template", "Product Templates"),
        ("product.product", "Product Variants"),
        ("sale.order", "Sale Orders"),
        ("purchase.order", "Purchase Orders"),
        ("account.move", "Journal Entries"),
        ("account.move.line", "Journal Items"),
        ("stock.picking", "Stock Transfers"),
        ("stock.move", "Stock Moves"),
        ("stock.move.line", "Stock Move Lines"),
        ("mail.message", "Messages"),
        ("mail.mail", "Emails"),
        ("ir.attachment", "Attachments"),
        ("ir.logging", "Log Entries"),
        ("bus.bus", "Bus Notifications"),
    ]

    rows = []
    json_data = []
    for model, label in tables:
        count = _count(model)
        if count < 0:
            rows.append([label, model, "[dim]N/A[/dim]"])
        else:
            rows.append([label, model, f"{count:,}"])
        json_data.append({"label": label, "model": model, "count": count})

    out.table(
        "Database Size Indicators",
        [("Table", "cyan"), ("Model", "dim"), ("Records", "green")],
        rows,
        json_data,
    )

    # Summary
    total_records = sum(d["count"] for d in json_data if d["count"] > 0)
    out.info(f"Total tracked records: {total_records:,}")

    # Large table warnings
    for d in json_data:
        if d["count"] > 100000:
            out.warn(f"{d['label']} has {d['count']:,} records — consider archiving old data")


@app.command("health-report")
def health_report(ctx: typer.Context) -> None:
    """Generate a comprehensive daily health report.

    Combines: server status, module health, mail queue, cron status,
    storage usage, session activity, and data integrity into one report.
    Use this for daily/weekly operational reviews.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    from datetime import datetime, timedelta

    now = datetime.now(tz=UTC)
    sections = []
    json_data: dict = {}

    # 1. Server
    ok, version = c.check_health()
    sections.append(
        (
            "Server",
            [
                ("Status", "[green]Healthy[/green]" if ok else "[red]Unhealthy[/red]"),
                ("Version", version),
                ("Database", c.database),
            ],
        )
    )
    json_data["server"] = {"healthy": ok, "version": version, "database": c.database}

    # 2. Modules
    installed = c.search_count("ir.module.module", [("state", "=", "installed")])
    stuck = c.search_count("ir.module.module", [("state", "in", ["to install", "to upgrade", "to remove"])])
    sections.append(
        (
            "Modules",
            [
                ("Installed", str(installed)),
                ("Stuck", f"[red]{stuck}[/red]" if stuck else "[green]0[/green]"),
            ],
        )
    )
    json_data["modules"] = {"installed": installed, "stuck": stuck}

    # 3. Mail
    try:
        mail_out = c.search_count("mail.mail", [("state", "=", "outgoing")])
        mail_err = c.search_count("mail.mail", [("state", "=", "exception")])
        sections.append(
            (
                "Mail Queue",
                [
                    ("Outgoing", str(mail_out)),
                    ("Failed", f"[red]{mail_err}[/red]" if mail_err else "[green]0[/green]"),
                ],
            )
        )
        json_data["mail"] = {"outgoing": mail_out, "failed": mail_err}
    except (RPCError, ConnectionError):
        pass

    # 4. Cron
    crons = c.search_read("ir.cron", domain=[("active", "=", True)], fields=["nextcall"], limit=200)
    overdue = 0
    for cr in crons:
        nc = cr.get("nextcall")
        if nc:
            try:
                next_dt = datetime.strptime(str(nc)[:19], "%Y-%m-%d %H:%M:%S").replace(tzinfo=UTC)
                if next_dt < now - timedelta(hours=2):
                    overdue += 1
            except (ValueError, TypeError):
                pass
    sections.append(
        (
            "Cron Jobs",
            [
                ("Active", str(len(crons))),
                ("Overdue", f"[red]{overdue}[/red]" if overdue else "[green]0[/green]"),
            ],
        )
    )
    json_data["cron"] = {"active": len(crons), "overdue": overdue}

    # 5. Users
    active_users = c.search_count("res.users", [("active", "=", True), ("share", "=", False)])
    sections.append(("Users", [("Active internal", str(active_users))]))
    json_data["users"] = {"active_internal": active_users}

    # 6. Storage
    try:
        attachments = c.search_count("ir.attachment", [])
        sections.append(("Storage", [("Attachments", f"{attachments:,}")]))
        json_data["storage"] = {"attachments": attachments}
    except (RPCError, ConnectionError):
        pass

    # 7. Queue Jobs
    try:
        failed_jobs = c.search_count("queue.job", [("state", "=", "failed")])
        pending_jobs = c.search_count("queue.job", [("state", "in", ["pending", "enqueued"])])
        sections.append(
            (
                "Queue Jobs",
                [
                    ("Pending", str(pending_jobs)),
                    ("Failed", f"[red]{failed_jobs}[/red]" if failed_jobs else "[green]0[/green]"),
                ],
            )
        )
        json_data["queue_jobs"] = {"pending": pending_jobs, "failed": failed_jobs}
    except (RPCError, ConnectionError):
        pass

    # Overall status
    mail_err_count = json_data.get("mail", {}).get("failed", 0)
    failed_job_count = json_data.get("queue_jobs", {}).get("failed", 0)
    problems = stuck + mail_err_count + overdue + failed_job_count
    overall = "[green]HEALTHY[/green]" if problems == 0 else f"[yellow]{problems} issues[/yellow]"
    sections.insert(0, ("Overall", [("Status", overall), ("Timestamp", now.strftime("%Y-%m-%d %H:%M UTC"))]))

    out.detail(f"Daily Health Report — {c.database}", sections, json_data)
