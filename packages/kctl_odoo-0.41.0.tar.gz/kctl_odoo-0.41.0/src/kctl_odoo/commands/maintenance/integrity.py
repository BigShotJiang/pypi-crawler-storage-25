"""Data integrity check command."""

from __future__ import annotations

from datetime import UTC
from typing import Annotated

import typer

from kctl_odoo.core.biz_helpers import model_available
from kctl_odoo.core.callbacks import AppContext
from kctl_odoo.core.exceptions import ConnectionError, RPCError

app = typer.Typer(help="Data integrity checks.")


@app.command("check-data")
def check_data(
    ctx: typer.Context,
    category: Annotated[
        str | None,
        typer.Option(
            "--category",
            "-c",
            help="Filter: master, operations, finance, inventory, hr, manufacturing, cross-module, all",
        ),
    ] = None,
) -> None:
    """Comprehensive data integrity checks across 7 categories.

    Categories:
    - master: partner dupes, products without category, missing configs
    - operations: stale draft SO/PO, stuck transfers, orders without lines
    - finance: unreconciled items, overdue AR/AP, unposted journal entries
    - inventory: negative stock, zero-cost products, orphan stock moves
    - hr: employees without dept/contract, expired contracts, zero allocations
    - manufacturing: BOMs without components, stuck MOs
    - cross-module: SO/PO without delivery/invoice, order-to-cash gaps
    - all (default): run everything
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    from datetime import datetime, timedelta

    now = datetime.now(tz=UTC)
    cutoff_30d = (now - timedelta(days=30)).strftime("%Y-%m-%d")
    cutoff_90d = (now - timedelta(days=90)).strftime("%Y-%m-%d")
    cutoff_180d = (now - timedelta(days=180)).strftime("%Y-%m-%d")
    today = now.strftime("%Y-%m-%d")
    fourteen_days_ago = (now - timedelta(days=14)).strftime("%Y-%m-%d %H:%M:%S")
    thirty_days_ago = (now - timedelta(days=30)).strftime("%Y-%m-%d %H:%M:%S")
    sixty_days_ago = (now - timedelta(days=60)).strftime("%Y-%m-%d %H:%M:%S")
    ninety_days_ago = (now - timedelta(days=90)).strftime("%Y-%m-%d %H:%M:%S")

    rows: list[list[str]] = []
    json_data: list[dict] = []
    total_issues = 0
    cat = (category or "all").lower()
    # Normalize category aliases
    _cat_aliases = {"manufacturing": "mfg", "cross-module": "cross", "cross_module": "cross"}
    cat = _cat_aliases.get(cat, cat)

    def _check(check_cat: str, name: str, model: str, domain: list, description: str) -> None:
        nonlocal total_issues
        if cat != "all" and cat != check_cat:
            return
        try:
            count = c.search_count(model, domain)
            ok = count == 0
            if not ok:
                total_issues += count
            status = "[green]OK[/green]" if ok else f"[red]{count}[/red]"
            rows.append([check_cat.upper(), name, status, description if not ok else ""])
            json_data.append({"category": check_cat, "check": name, "count": count, "ok": ok})
        except (RPCError, ConnectionError):
            rows.append([check_cat.upper(), name, "[dim]skip[/dim]", "Module not installed"])
            json_data.append({"category": check_cat, "check": name, "count": -1, "ok": True})

    def _check_custom(check_cat: str, name: str, ok: bool, count: int, detail: str) -> None:
        nonlocal total_issues
        if cat != "all" and cat != check_cat:
            return
        if not ok:
            total_issues += count
        status = "[green]OK[/green]" if ok else f"[red]{count}[/red]"
        rows.append([check_cat.upper(), name, status, detail if not ok else ""])
        json_data.append({"category": check_cat, "check": name, "count": count, "ok": ok})

    # =====================================================================
    # MASTER DATA CHECKS
    # =====================================================================

    # Duplicate partner emails
    if cat in ("all", "master"):
        try:
            partners = c.search_read("res.partner", domain=[("email", "!=", False)], fields=["email"], limit=10000)
            emails: dict[str, int] = {}
            for p in partners:
                email = (p.get("email") or "").strip().lower()
                if email:
                    emails[email] = emails.get(email, 0) + 1
            dupes = sum(1 for v in emails.values() if v > 1)
            _check_custom(
                "master", "Duplicate partner emails", dupes == 0, dupes, f"{dupes} emails on multiple partners"
            )
        except (RPCError, ConnectionError):
            pass

    # Duplicate partner VAT numbers
    if cat in ("all", "master"):
        try:
            vat_partners = c.search_read("res.partner", domain=[("vat", "!=", False)], fields=["vat"], limit=10000)
            vats: dict[str, int] = {}
            for p in vat_partners:
                vat = (p.get("vat") or "").strip().upper()
                if vat:
                    vats[vat] = vats.get(vat, 0) + 1
            vat_dupes = sum(1 for v in vats.values() if v > 1)
            _check_custom(
                "master", "Duplicate partner VAT/TIN", vat_dupes == 0, vat_dupes, f"{vat_dupes} VAT numbers duplicated"
            )
        except (RPCError, ConnectionError):
            pass

    _check(
        "master", "Partners without name", "res.partner", [("name", "in", [False, ""])], "Every partner needs a name"
    )
    _check(
        "master",
        "Products without category",
        "product.template",
        [("categ_id", "=", False)],
        "Assign categories for reporting",
    )
    _check(
        "master",
        "Products without internal ref",
        "product.template",
        [("default_code", "in", [False, ""]), ("sale_ok", "=", True)],
        "Saleable products should have internal reference",
    )
    _check(
        "master",
        "Products with zero cost",
        "product.template",
        [("standard_price", "<=", 0), ("type", "!=", "service")],
        "Storable/consumable products need a cost",
    )
    _check(
        "master",
        "Partners without country",
        "res.partner",
        [("country_id", "=", False), ("is_company", "=", True)],
        "Companies should have a country set",
    )

    # --- Partner data quality (extended) ---
    _check(
        "master",
        "Partners without phone or email",
        "res.partner",
        [("phone", "in", [False, ""]), ("email", "in", [False, ""]), ("is_company", "=", True), ("active", "=", True)],
        "Companies should have at least phone or email for contact",
    )
    _check(
        "master",
        "Partners without address",
        "res.partner",
        [
            ("street", "in", [False, ""]),
            ("city", "in", [False, ""]),
            ("is_company", "=", True),
            ("customer_rank", ">", 0),
        ],
        "Customers need address for delivery and invoicing",
    )
    if cat in ("all", "master"):
        try:
            # Duplicate partner names (same company name)
            name_partners = c.search_read(
                "res.partner",
                domain=[("is_company", "=", True), ("active", "=", True)],
                fields=["name"],
                limit=10000,
            )
            names: dict[str, int] = {}
            for p in name_partners:
                name = (p.get("name") or "").strip().lower()
                if name and len(name) > 3:
                    names[name] = names.get(name, 0) + 1
            name_dupes = sum(1 for v in names.values() if v > 1)
            _check_custom(
                "master",
                "Duplicate company names",
                name_dupes == 0,
                name_dupes,
                f"{name_dupes} company names appear more than once — possible duplicates",
            )
        except (RPCError, ConnectionError):
            pass

    _check(
        "master",
        "Inactive partners with open invoices",
        "res.partner",
        [("active", "=", False), ("credit", ">", 0)],
        "Archived partners still have outstanding receivables",
    )

    # --- Product data quality (extended) ---
    _check(
        "master",
        "Products without UoM",
        "product.template",
        [("uom_id", "=", False)],
        "Every product must have a unit of measure",
    )
    _check(
        "master",
        "Products without sales price",
        "product.template",
        [("list_price", "<=", 0), ("sale_ok", "=", True)],
        "Saleable products should have a price >0",
    )
    _check(
        "master",
        "Archived products with open SO lines",
        "product.product",
        [("active", "=", False), ("sales_count", ">", 0)],
        "Archived products still referenced in active sales — may cause errors",
    )

    # --- Accounting master data ---
    if cat in ("all", "master"):
        try:
            # Accounts without code
            no_code_accounts = c.search_count("account.account", [("code", "in", [False, ""])])
            _check_custom(
                "master",
                "Accounts without code",
                no_code_accounts == 0,
                no_code_accounts,
                f"{no_code_accounts} chart of accounts entries have no code",
            )
        except (RPCError, ConnectionError):
            pass

        try:
            # Journals without sequence
            no_seq_journals = c.search_count("account.journal", [("sequence_id", "=", False)])
            _check_custom(
                "master",
                "Journals without sequence",
                no_seq_journals == 0,
                no_seq_journals,
                f"{no_seq_journals} journals have no sequence — invoice numbering will fail",
            )
        except (RPCError, ConnectionError):
            pass

        try:
            # Tax groups: check if both sale and purchase tax exist
            sale_taxes = c.search_count("account.tax", [("type_tax_use", "=", "sale"), ("active", "=", True)])
            purchase_taxes = c.search_count("account.tax", [("type_tax_use", "=", "purchase"), ("active", "=", True)])
            has_both = sale_taxes > 0 and purchase_taxes > 0
            _check_custom(
                "master",
                "Sale and purchase taxes configured",
                has_both,
                0 if has_both else 1,
                f"Sale taxes: {sale_taxes}, Purchase taxes: {purchase_taxes}" + (" — OK" if has_both else " — MISSING"),
            )
        except (RPCError, ConnectionError):
            pass

    # --- Warehouse/location master data ---
    _check(
        "master",
        "Warehouses without stock location",
        "stock.warehouse",
        [("lot_stock_id", "=", False)],
        "Warehouses must have a stock location for operations",
    )

    # --- Indonesian-specific ---
    if cat in ("all", "master"):
        try:
            # Partners (companies) without NPWP/tax ID
            customers_no_vat = c.search_count(
                "res.partner",
                [
                    ("vat", "in", [False, ""]),
                    ("is_company", "=", True),
                    ("customer_rank", ">", 0),
                    ("active", "=", True),
                ],
            )
            _check_custom(
                "master",
                "Customers without NPWP/Tax ID",
                customers_no_vat == 0,
                customers_no_vat,
                f"{customers_no_vat} active customer companies have no VAT/NPWP — required for Faktur Pajak",
            )
        except (RPCError, ConnectionError):
            pass

    # Users without timezone set (should be Asia/Jakarta for Indonesian companies)
    if cat in ("all", "master"):
        try:
            no_tz = c.search_count(
                "res.users",
                [("active", "=", True), ("share", "=", False), "|", ("tz", "=", False), ("tz", "!=", "Asia/Jakarta")],
            )
            _check_custom(
                "master",
                "Users without Asia/Jakarta timezone",
                no_tz == 0,
                no_tz,
                f"{no_tz} internal users do not have tz=Asia/Jakarta — causes wrong timestamps in attendance/payroll",
            )
        except (RPCError, ConnectionError):
            pass

    # =====================================================================
    # OPERATIONS CHECKS
    # =====================================================================

    _check(
        "operations",
        "Stale draft quotations (>90d)",
        "sale.order",
        [("state", "=", "draft"), ("create_date", "<", cutoff_90d)],
        "Old drafts should be confirmed or deleted",
    )
    _check(
        "operations",
        "Stale draft POs (>90d)",
        "purchase.order",
        [("state", "=", "draft"), ("create_date", "<", cutoff_90d)],
        "Old draft POs should be confirmed or deleted",
    )
    _check(
        "operations",
        "Sale orders without lines",
        "sale.order",
        [("order_line", "=", False), ("state", "!=", "cancel")],
        "Orders with no lines are incomplete",
    )
    _check(
        "operations",
        "POs without lines",
        "purchase.order",
        [("order_line", "=", False), ("state", "!=", "cancel")],
        "POs with no lines are incomplete",
    )
    _check(
        "operations",
        "Stuck transfers (>30d)",
        "stock.picking",
        [("state", "in", ["waiting", "confirmed"]), ("create_date", "<", cutoff_30d)],
        "Transfers stuck for >30 days",
    )
    _check(
        "operations",
        "Late deliveries (>30d assigned)",
        "stock.picking",
        [("state", "=", "assigned"), ("scheduled_date", "<", cutoff_30d)],
        "Ready but not shipped for >30 days",
    )

    # =====================================================================
    # FINANCE CHECKS
    # =====================================================================

    _check(
        "finance",
        "Draft invoices >90d",
        "account.move",
        [("state", "=", "draft"), ("move_type", "in", ["out_invoice", "in_invoice"]), ("create_date", "<", cutoff_90d)],
        "Post or delete stale draft invoices",
    )
    _check(
        "finance",
        "Draft bills >90d",
        "account.move",
        [("state", "=", "draft"), ("move_type", "in", ["in_invoice", "in_refund"]), ("create_date", "<", cutoff_90d)],
        "Post or delete stale draft bills",
    )
    _check(
        "finance",
        "Unreconciled items >90d",
        "account.move.line",
        [("reconciled", "=", False), ("account_id.reconcile", "=", True), ("date", "<", cutoff_90d)],
        "Investigate old unreconciled items",
    )
    _check(
        "finance",
        "Unreconciled items >180d",
        "account.move.line",
        [("reconciled", "=", False), ("account_id.reconcile", "=", True), ("date", "<", cutoff_180d)],
        "Critical: very old unreconciled items",
    )

    # Overdue customer invoices
    _check(
        "finance",
        "Overdue customer invoices",
        "account.move",
        [
            ("move_type", "=", "out_invoice"),
            ("state", "=", "posted"),
            ("payment_state", "in", ["not_paid", "partial"]),
            ("invoice_date_due", "<", cutoff_30d),
        ],
        "Customer invoices past due >30 days",
    )

    # Overdue vendor bills
    _check(
        "finance",
        "Overdue vendor bills",
        "account.move",
        [
            ("move_type", "=", "in_invoice"),
            ("state", "=", "posted"),
            ("payment_state", "in", ["not_paid", "partial"]),
            ("invoice_date_due", "<", cutoff_30d),
        ],
        "Vendor bills past due >30 days",
    )

    # Unposted journal entries >30 days
    _check(
        "finance",
        "Unposted entries >30d",
        "account.move",
        [("state", "=", "draft"), ("move_type", "=", "entry"), ("create_date", "<", cutoff_30d)],
        "Journal entries sitting in draft >30 days",
    )

    # Invoices without tax lines
    if cat in ("all", "finance"):
        try:
            no_tax_invoices = c.search_count(
                "account.move",
                [
                    ("state", "=", "posted"),
                    ("move_type", "in", ["out_invoice", "in_invoice"]),
                    ("amount_tax", "=", 0),
                    ("amount_untaxed", ">", 0),
                ],
            )
            _check_custom(
                "finance",
                "Posted invoices without tax",
                no_tax_invoices == 0,
                no_tax_invoices,
                f"{no_tax_invoices} posted invoices have zero tax — verify tax configuration",
            )
        except (RPCError, ConnectionError):
            pass

    # Suspense account balance (should be zero)
    if cat in ("all", "finance"):
        try:
            suspense_accounts = c.search_read(
                "account.account", [("name", "ilike", "suspense")], fields=["id", "name"], limit=5
            )
            for sa in suspense_accounts:
                lines = c.search_read(
                    "account.move.line",
                    [("account_id", "=", sa["id"]), ("parent_state", "=", "posted")],
                    fields=["debit", "credit"],
                    limit=0,
                )
                balance = sum(line.get("debit", 0) - line.get("credit", 0) for line in lines)
                ok = abs(balance) < 0.01
                _check_custom(
                    "finance",
                    f"Suspense '{sa['name']}' balance",
                    ok,
                    1 if not ok else 0,
                    f"Balance: {balance:,.2f} — should be zero",
                )
        except (RPCError, ConnectionError):
            pass

    # Bank reconciliation — unreconciled bank statement lines
    if cat in ("all", "finance"):
        try:
            unreconciled_bank = c.search_count("account.bank.statement.line", [("is_reconciled", "=", False)])
            _check_custom(
                "finance",
                "Unreconciled bank statement lines",
                unreconciled_bank == 0,
                unreconciled_bank,
                f"{unreconciled_bank} bank lines not reconciled",
            )
        except (RPCError, ConnectionError):
            pass

    # Lock date check
    if cat in ("all", "finance"):
        try:
            companies = c.search_read(
                "res.company", [], fields=["name", "fiscalyear_lock_date", "period_lock_date"], limit=5
            )
            for comp in companies:
                fy_lock = comp.get("fiscalyear_lock_date")
                period_lock = comp.get("period_lock_date")
                if not fy_lock and not period_lock:
                    _check_custom(
                        "finance",
                        f"Lock dates ({comp['name']})",
                        False,
                        1,
                        "No lock dates set — previous periods are editable",
                    )
                else:
                    info = []
                    if period_lock:
                        info.append(f"period: {period_lock}")
                    if fy_lock:
                        info.append(f"fiscal year: {fy_lock}")
                    _check_custom("finance", f"Lock dates ({comp['name']})", True, 0, ", ".join(info))
        except (RPCError, ConnectionError):
            pass

    # --- Extended finance checks ---

    # Journals without default accounts
    if cat in ("all", "finance"):
        try:
            journals = c.search_read(
                "account.journal",
                [("type", "in", ["sale", "purchase", "bank", "cash"])],
                fields=["name", "type", "default_account_id"],
                limit=50,
            )
            no_default = [j for j in journals if not j.get("default_account_id")]
            _check_custom(
                "finance",
                "Journals without default account",
                len(no_default) == 0,
                len(no_default),
                f"{len(no_default)} journal(s) missing default account: {', '.join(j['name'] for j in no_default[:3])}"
                if no_default
                else "",
            )
        except (RPCError, ConnectionError):
            pass

    # Tax rate validation — compare invoice tax vs expected rate
    if cat in ("all", "finance"):
        try:
            # Find invoices where tax amount doesn't match expected rate × base
            taxes = c.search_read(
                "account.tax",
                [("active", "=", True), ("type_tax_use", "=", "sale")],
                fields=["name", "amount"],
                limit=10,
            )
            if taxes:
                expected_rate = taxes[0].get("amount", 0) / 100 if taxes[0].get("amount") else 0
                if expected_rate > 0:
                    # Sample recent invoices and check tax math
                    recent_inv = c.search_read(
                        "account.move",
                        [
                            ("state", "=", "posted"),
                            ("move_type", "=", "out_invoice"),
                            ("amount_tax", ">", 0),
                            ("amount_untaxed", ">", 0),
                        ],
                        fields=["name", "amount_untaxed", "amount_tax"],
                        limit=50,
                    )
                    mismatched = 0
                    for inv in recent_inv:
                        base = inv.get("amount_untaxed", 0)
                        tax = inv.get("amount_tax", 0)
                        if base > 0:
                            actual_rate = tax / base
                            # Allow 5% tolerance for rounding and mixed-rate invoices
                            if abs(actual_rate - expected_rate) > expected_rate * 0.5:
                                mismatched += 1
                    _check_custom(
                        "finance",
                        "Tax rate consistency",
                        mismatched == 0,
                        mismatched,
                        f"{mismatched} invoices with tax rate significantly different from standard {taxes[0]['amount']}%",
                    )
        except (RPCError, ConnectionError):
            pass

    # Trial balance sanity — debit should equal credit
    if cat in ("all", "finance"):
        try:
            all_lines = c.search_read(
                "account.move.line",
                [("parent_state", "=", "posted")],
                fields=["debit", "credit"],
                limit=0,
            )
            total_debit = sum(l.get("debit", 0) for l in all_lines)
            total_credit = sum(l.get("credit", 0) for l in all_lines)
            diff = abs(total_debit - total_credit)
            ok = diff < 0.01
            _check_custom(
                "finance",
                "Trial balance (debit = credit)",
                ok,
                1 if not ok else 0,
                f"Debit: {total_debit:,.2f}, Credit: {total_credit:,.2f}, Diff: {diff:,.2f}",
            )
        except (RPCError, ConnectionError):
            pass

    # Duplicate invoice numbers
    if cat in ("all", "finance"):
        try:
            invoices = c.search_read(
                "account.move",
                [("state", "=", "posted"), ("move_type", "in", ["out_invoice", "in_invoice"]), ("name", "!=", "/")],
                fields=["name"],
                limit=10000,
            )
            inv_names: dict[str, int] = {}
            for inv in invoices:
                name = (inv.get("name") or "").strip()
                if name:
                    inv_names[name] = inv_names.get(name, 0) + 1
            dup_invoices = sum(1 for v in inv_names.values() if v > 1)
            _check_custom(
                "finance",
                "Duplicate invoice numbers",
                dup_invoices == 0,
                dup_invoices,
                f"{dup_invoices} invoice numbers appear more than once — data integrity risk",
            )
        except (RPCError, ConnectionError):
            pass

    # Invoices with negative amounts (unusual)
    _check(
        "finance",
        "Invoices with negative total",
        "account.move",
        [("state", "=", "posted"), ("move_type", "in", ["out_invoice", "in_invoice"]), ("amount_total", "<", 0)],
        "Posted invoices with negative total — should be credit notes instead",
    )

    # Payments in wrong state
    if cat in ("all", "finance"):
        try:
            draft_payments_old = c.search_count(
                "account.payment",
                [("state", "=", "draft"), ("create_date", "<", cutoff_30d)],
            )
            _check_custom(
                "finance",
                "Draft payments >30d",
                draft_payments_old == 0,
                draft_payments_old,
                f"{draft_payments_old} payment records in draft >30 days — post or cancel",
            )
        except (RPCError, ConnectionError):
            pass

    # Journals with entries in wrong period (after lock date)
    if cat in ("all", "finance"):
        try:
            companies = c.search_read("res.company", [], fields=["period_lock_date"], limit=1)
            if companies and companies[0].get("period_lock_date"):
                lock_date = companies[0]["period_lock_date"]
                entries_before_lock = c.search_count(
                    "account.move",
                    [("state", "=", "draft"), ("date", "<=", lock_date)],
                )
                _check_custom(
                    "finance",
                    "Draft entries before lock date",
                    entries_before_lock == 0,
                    entries_before_lock,
                    f"{entries_before_lock} draft entries dated on/before lock date {lock_date} — will fail when posting",
                )
        except (RPCError, ConnectionError):
            pass

    # Receivable/payable balance sanity
    if cat in ("all", "finance"):
        try:
            # AR balance
            ar_lines = c.search_read(
                "account.move.line",
                [("account_id.account_type", "=", "asset_receivable"), ("parent_state", "=", "posted")],
                fields=["debit", "credit"],
                limit=0,
            )
            ar_balance = sum(l.get("debit", 0) - l.get("credit", 0) for l in ar_lines)
            _check_custom("finance", "AR balance", True, 0, f"Total receivables: {ar_balance:,.2f}")

            # AP balance
            ap_lines = c.search_read(
                "account.move.line",
                [("account_id.account_type", "=", "liability_payable"), ("parent_state", "=", "posted")],
                fields=["debit", "credit"],
                limit=0,
            )
            ap_balance = sum(l.get("debit", 0) - l.get("credit", 0) for l in ap_lines)
            _check_custom("finance", "AP balance", True, 0, f"Total payables: {ap_balance:,.2f}")
        except (RPCError, ConnectionError):
            pass

    # Mismatched currency on invoices
    if cat in ("all", "finance"):
        try:
            # Invoices where currency differs from company currency but no exchange rate
            multi_curr = c.search_count(
                "account.move",
                [
                    ("state", "=", "posted"),
                    ("move_type", "in", ["out_invoice", "in_invoice"]),
                    ("currency_id", "!=", False),
                ],
            )
            if multi_curr > 0:
                _check_custom(
                    "finance",
                    "Multi-currency invoices",
                    True,
                    0,
                    f"{multi_curr} invoices in foreign currency — verify exchange rates are current",
                )
        except (RPCError, ConnectionError):
            pass

    # Indonesian specific: PPN vs invoice tax check
    if cat in ("all", "finance"):
        try:
            # Invoices with tax amount but no tax line detail
            tax_accounts = c.search_read(
                "account.account",
                ["|", ("name", "ilike", "tax"), ("name", "ilike", "ppn")],
                fields=["id"],
                limit=10,
            )
            if tax_accounts:
                tax_account_ids = [a["id"] for a in tax_accounts]
                tax_entries = c.search_count(
                    "account.move.line",
                    [
                        ("account_id", "in", tax_account_ids),
                        ("parent_state", "=", "posted"),
                        ("date", ">=", today[:7] + "-01"),
                    ],
                )
                _check_custom(
                    "finance",
                    "Tax entries this month",
                    True,
                    0,
                    f"{tax_entries} tax journal items this month — verify against SPT Masa",
                )
        except (RPCError, ConnectionError):
            pass

    # =====================================================================
    # INVENTORY CHECKS
    # =====================================================================

    _check(
        "inventory",
        "Negative stock quantities",
        "stock.quant",
        [("quantity", "<", 0), ("location_id.usage", "=", "internal")],
        "Negative stock indicates data issues",
    )
    _check(
        "inventory",
        "Products with zero cost (storable)",
        "product.product",
        [("standard_price", "<=", 0), ("type", "=", "consu")],
        "Storable products need cost for valuation",
    )

    # Orphan stock moves
    _check(
        "inventory",
        "Stock moves without picking >30d",
        "stock.move",
        [("picking_id", "=", False), ("state", "not in", ["done", "cancel"]), ("create_date", "<", cutoff_30d)],
        "Orphan stock moves should be investigated",
    )

    # Unreserved confirmed pickings (can't ship)
    _check(
        "inventory",
        "Confirmed picks without reservation",
        "stock.picking",
        [("state", "=", "confirmed"), ("create_date", "<", cutoff_30d)],
        "Confirmed but unreserved >30d — check availability or cancel",
    )

    # Stock in transit >7 days
    if cat in ("all", "inventory"):
        try:
            cutoff_7d = (now - timedelta(days=7)).strftime("%Y-%m-%d")
            transit_count = c.search_count(
                "stock.picking",
                [
                    ("state", "=", "assigned"),
                    ("picking_type_code", "=", "internal"),
                    ("scheduled_date", "<", cutoff_7d),
                ],
            )
            _check_custom(
                "inventory",
                "Internal transfers in transit >7d",
                transit_count == 0,
                transit_count,
                f"{transit_count} inter-warehouse transfers stuck >7 days",
            )
        except (RPCError, ConnectionError):
            pass

    # Inventory valuation vs GL (stock account balance check)
    if cat in ("all", "inventory"):
        try:
            # Get stock valuation from stock.valuation.layer
            layers = c.search_read("stock.valuation.layer", [("company_id", "!=", False)], fields=["value"], limit=0)
            layer_total = sum(line.get("value", 0) for line in layers)

            # Get GL stock account balance
            stock_accounts = c.search_read(
                "account.account",
                [("account_type", "=", "asset_current"), ("name", "ilike", "stock valuation")],
                fields=["id"],
                limit=5,
            )
            gl_total = 0.0
            for sa in stock_accounts:
                gl_lines = c.search_read(
                    "account.move.line",
                    [("account_id", "=", sa["id"]), ("parent_state", "=", "posted")],
                    fields=["debit", "credit"],
                    limit=0,
                )
                gl_total += sum(line.get("debit", 0) - line.get("credit", 0) for line in gl_lines)

            diff = abs(layer_total - gl_total)
            ok = diff < 1.0
            _check_custom(
                "inventory",
                "Valuation vs GL match",
                ok,
                1 if not ok else 0,
                f"Layers: {layer_total:,.2f}, GL: {gl_total:,.2f}, Diff: {diff:,.2f}",
            )
        except (RPCError, ConnectionError):
            pass

    # Products with negative forecast (virtual stock)
    if cat in ("all", "inventory"):
        try:
            negative_forecast = c.search_count(
                "product.product",
                [
                    ("virtual_available", "<", 0),
                    ("type", "!=", "service"),
                ],
            )
            _check_custom(
                "inventory",
                "Products with negative forecast",
                negative_forecast == 0,
                negative_forecast,
                f"{negative_forecast} products oversold (virtual stock < 0)",
            )
        except (RPCError, ConnectionError):
            pass

    # Expired lots (if lot tracking used)
    if cat in ("all", "inventory"):
        try:
            today_str = now.strftime("%Y-%m-%d")
            expired_lots = c.search_count(
                "stock.lot",
                [
                    ("expiration_date", "<", today_str),
                    ("product_qty", ">", 0),
                ],
            )
            _check_custom(
                "inventory",
                "Expired lots with stock",
                expired_lots == 0,
                expired_lots,
                f"{expired_lots} expired lots still have stock on hand",
            )
        except (RPCError, ConnectionError):
            pass

    # Storable products without replenishment route
    if cat in ("all", "inventory"):
        try:
            no_route = c.search_count(
                "product.template",
                [
                    ("type", "!=", "service"),
                    ("route_ids", "=", False),
                    ("sale_ok", "=", True),
                ],
            )
            _check_custom(
                "inventory",
                "Storable products without routes",
                no_route < 5,
                no_route,
                f"{no_route} saleable storable products have no replenishment route",
            )
        except (RPCError, ConnectionError):
            pass

    # --- Extended inventory/product checks ---

    # Product type vs route consistency
    if cat in ("all", "inventory"):
        try:
            # Storable products set to 'Buy' but no vendor
            buy_no_vendor = c.search_count(
                "product.template",
                [
                    ("type", "!=", "service"),
                    ("sale_ok", "=", True),
                    ("purchase_ok", "=", True),
                    ("seller_ids", "=", False),
                ],
            )
            _check_custom(
                "inventory",
                "Purchasable products without vendor",
                buy_no_vendor == 0,
                buy_no_vendor,
                f"{buy_no_vendor} purchasable products have no vendor defined — replenishment will fail",
            )
        except (RPCError, ConnectionError):
            pass

    # Warehouse route validation
    if cat in ("all", "inventory"):
        try:
            warehouses = c.search_read(
                "stock.warehouse",
                [],
                fields=["name", "reception_route_id", "delivery_route_id"],
                limit=20,
            )
            no_reception = [w for w in warehouses if not w.get("reception_route_id")]
            no_delivery = [w for w in warehouses if not w.get("delivery_route_id")]
            if no_reception:
                _check_custom(
                    "inventory",
                    "Warehouses without reception route",
                    False,
                    len(no_reception),
                    f"{len(no_reception)} warehouse(s) missing reception route: {', '.join(w['name'] for w in no_reception[:3])}",
                )
            if no_delivery:
                _check_custom(
                    "inventory",
                    "Warehouses without delivery route",
                    False,
                    len(no_delivery),
                    f"{len(no_delivery)} warehouse(s) missing delivery route: {', '.join(w['name'] for w in no_delivery[:3])}",
                )
        except (RPCError, ConnectionError):
            pass

    # UoM category consistency
    if cat in ("all", "master"):
        try:
            # Find products where purchase UoM category differs from default UoM category
            products_uom = c.search_read(
                "product.template",
                [("uom_id", "!=", False), ("uom_po_id", "!=", False)],
                fields=["name", "uom_id", "uom_po_id"],
                limit=1000,
            )
            # Get UoM details for category check
            uom_ids = set()
            for p in products_uom:
                if p.get("uom_id"):
                    uom_ids.add(p["uom_id"][0] if isinstance(p["uom_id"], list) else p["uom_id"])
                if p.get("uom_po_id"):
                    uom_ids.add(p["uom_po_id"][0] if isinstance(p["uom_po_id"], list) else p["uom_po_id"])
            if uom_ids:
                uoms = c.search_read(
                    "uom.uom",
                    [("id", "in", list(uom_ids))],
                    fields=["id", "category_id"],
                    limit=500,
                )
                uom_cat = {
                    u["id"]: (u["category_id"][0] if isinstance(u.get("category_id"), list) else u.get("category_id"))
                    for u in uoms
                }

                mismatch = 0
                for p in products_uom:
                    sale_uom = p["uom_id"][0] if isinstance(p.get("uom_id"), list) else p.get("uom_id")
                    po_uom = p["uom_po_id"][0] if isinstance(p.get("uom_po_id"), list) else p.get("uom_po_id")
                    if sale_uom and po_uom and uom_cat.get(sale_uom) != uom_cat.get(po_uom):
                        mismatch += 1
                _check_custom(
                    "master",
                    "UoM category mismatch (sale vs purchase)",
                    mismatch == 0,
                    mismatch,
                    f"{mismatch} products have different UoM categories for sale and purchase — conversion will fail",
                )
        except (RPCError, ConnectionError):
            pass

    # =====================================================================
    # HR CHECKS (20 checks)
    # =====================================================================

    if cat in ("all", "hr"):
        if not model_available(c, "hr.employee"):
            if cat == "hr":
                out.warn("HR module (hr) is not installed — HR checks skipped")
                out.info("Install HR modules: kctl-odoo local install hr_contract,hr_holidays,hr_attendance")
        else:
            _hr_available = True

    if cat in ("all", "hr") and model_available(c, "hr.employee"):
        # ------ EMPLOYEE MASTER DATA (6 checks) ------

        try:
            no_dept = c.search_count("hr.employee", [("department_id", "=", False), ("active", "=", True)])
            _check_custom(
                "hr",
                "Employees without department",
                no_dept == 0,
                no_dept,
                f"{no_dept} active employees have no department assigned",
            )
        except (RPCError, ConnectionError):
            pass

        try:
            no_job = c.search_count("hr.employee", [("job_id", "=", False), ("active", "=", True)])
            _check_custom(
                "hr",
                "Employees without job position",
                no_job == 0,
                no_job,
                f"{no_job} active employees have no job position",
            )
        except (RPCError, ConnectionError):
            pass

        try:
            no_manager = c.search_count("hr.employee", [("parent_id", "=", False), ("active", "=", True)])
            # Subtract 1 for top-level (CEO)
            no_manager = max(0, no_manager - 1)
            _check_custom(
                "hr",
                "Employees without manager (excl. CEO)",
                no_manager == 0,
                no_manager,
                f"{no_manager} active employees have no manager assigned",
            )
        except (RPCError, ConnectionError):
            pass

        try:
            no_work_email = c.search_count("hr.employee", [("work_email", "=", False), ("active", "=", True)])
            _check_custom(
                "hr",
                "Employees without work email",
                no_work_email == 0,
                no_work_email,
                f"{no_work_email} active employees have no work email",
            )
        except (RPCError, ConnectionError):
            pass

        try:
            no_user = c.search_count("hr.employee", [("user_id", "=", False), ("active", "=", True)])
            _check_custom(
                "hr",
                "Employees without linked user",
                no_user == 0,
                no_user,
                f"{no_user} active employees have no linked Odoo user (cannot self-service)",
            )
        except (RPCError, ConnectionError):
            pass

        try:
            no_company = c.search_count("hr.employee", [("company_id", "=", False), ("active", "=", True)])
            _check_custom(
                "hr",
                "Employees without company",
                no_company == 0,
                no_company,
                f"{no_company} active employees have no company assigned",
            )
        except (RPCError, ConnectionError):
            pass

        # ------ CONTRACTS (4 checks) ------

        if model_available(c, "hr.contract"):
            try:
                expired = c.search_count("hr.contract", [("state", "=", "open"), ("date_end", "<", today)])
                _check_custom(
                    "hr",
                    "Expired contracts still open",
                    expired == 0,
                    expired,
                    f"{expired} contracts expired but still in 'open' state",
                )
            except (RPCError, ConnectionError):
                pass

            try:
                no_contract = c.search_count("hr.employee", [("contract_id", "=", False), ("active", "=", True)])
                _check_custom(
                    "hr",
                    "Employees without active contract",
                    no_contract == 0,
                    no_contract,
                    f"{no_contract} active employees have no current contract",
                )
            except (RPCError, ConnectionError):
                pass

            try:
                from datetime import timedelta

                soon = (datetime.strptime(today, "%Y-%m-%d") + timedelta(days=30)).strftime("%Y-%m-%d")
                expiring = c.search_count(
                    "hr.contract", [("state", "=", "open"), ("date_end", ">=", today), ("date_end", "<=", soon)]
                )
                _check_custom(
                    "hr",
                    "Contracts expiring within 30 days",
                    expiring == 0,
                    expiring,
                    f"{expiring} contracts expire within 30 days — review for renewal",
                )
            except (RPCError, ConnectionError):
                pass

            try:
                no_wage = c.search_count("hr.contract", [("state", "=", "open"), ("wage", "<=", 0)])
                _check_custom(
                    "hr",
                    "Active contracts with zero wage",
                    no_wage == 0,
                    no_wage,
                    f"{no_wage} open contracts have zero or negative wage",
                )
            except (RPCError, ConnectionError):
                pass

        # ------ LEAVE / ATTENDANCE (4 checks) ------

        if model_available(c, "hr.leave.allocation"):
            try:
                zero_alloc = c.search_count(
                    "hr.leave.allocation", [("number_of_days", "<=", 0), ("state", "=", "validate")]
                )
                _check_custom(
                    "hr",
                    "Leave allocations at zero",
                    zero_alloc == 0,
                    zero_alloc,
                    f"{zero_alloc} approved allocations with zero or negative days",
                )
            except (RPCError, ConnectionError):
                pass

        if model_available(c, "hr.leave"):
            try:
                stale_draft = c.search_count("hr.leave", [("state", "=", "draft")])
                _check_custom(
                    "hr",
                    "Stale draft leave requests",
                    stale_draft <= 5,
                    stale_draft,
                    f"{stale_draft} leave requests still in draft — remind employees to submit",
                )
            except (RPCError, ConnectionError):
                pass

            try:
                pending = c.search_count("hr.leave", [("state", "=", "confirm")])
                _check_custom(
                    "hr",
                    "Leave requests awaiting approval",
                    pending <= 10,
                    pending,
                    f"{pending} submitted leave requests awaiting manager approval",
                )
            except (RPCError, ConnectionError):
                pass

        if model_available(c, "hr.attendance"):
            try:
                # Attendance records with check_in but no check_out (and older than today)
                open_attendance = c.search_count(
                    "hr.attendance",
                    [
                        ("check_out", "=", False),
                        ("check_in", "<", today),
                    ],
                )
                _check_custom(
                    "hr",
                    "Open attendance records (no check-out)",
                    open_attendance == 0,
                    open_attendance,
                    f"{open_attendance} attendance records from before today with no check-out",
                )
            except (RPCError, ConnectionError):
                pass

        # ------ EXPENSES (2 checks) ------

        if model_available(c, "hr.expense.sheet"):
            try:
                from datetime import timedelta

                d30 = (datetime.strptime(today, "%Y-%m-%d") - timedelta(days=30)).strftime("%Y-%m-%d")
                stale_expenses = c.search_count(
                    "hr.expense.sheet", [("state", "=", "draft"), ("create_date", "<", d30)]
                )
                _check_custom(
                    "hr",
                    "Stale draft expense reports (>30d)",
                    stale_expenses == 0,
                    stale_expenses,
                    f"{stale_expenses} expense reports in draft for over 30 days",
                )
            except (RPCError, ConnectionError):
                pass

            try:
                approved_not_paid = c.search_count(
                    "hr.expense.sheet", [("state", "=", "approve"), ("create_date", "<", d30)]
                )
                _check_custom(
                    "hr",
                    "Approved expenses not reimbursed >30d",
                    approved_not_paid == 0,
                    approved_not_paid,
                    f"{approved_not_paid} expense sheets approved but not paid >30 days",
                )
            except (RPCError, ConnectionError):
                pass

        # ------ ORGANIZATIONAL (4 checks) ------

        if model_available(c, "hr.department"):
            try:
                empty_dept = c.search_read(
                    "hr.department", [("active", "=", True)], fields=["id", "name", "member_ids"], limit=0
                )
                empty_count = sum(1 for d in empty_dept if not d.get("member_ids"))
                _check_custom(
                    "hr",
                    "Empty departments (no employees)",
                    empty_count == 0,
                    empty_count,
                    f"{empty_count} active departments have zero employees",
                )
            except (RPCError, ConnectionError):
                pass

        try:
            # Duplicate employees (same work_email)
            all_emps = c.search_read(
                "hr.employee", [("active", "=", True), ("work_email", "!=", False)], fields=["work_email"], limit=0
            )
            emails = [e["work_email"] for e in all_emps if e.get("work_email")]
            dupes = len(emails) - len(set(emails))
            _check_custom(
                "hr",
                "Duplicate employee work emails",
                dupes == 0,
                dupes,
                f"{dupes} duplicate work email addresses across employees",
            )
        except (RPCError, ConnectionError):
            pass

        try:
            # Inactive employees still linked to active user
            inactive_with_user = c.search_count("hr.employee", [("active", "=", False), ("user_id", "!=", False)])
            _check_custom(
                "hr",
                "Archived employees with active user link",
                inactive_with_user == 0,
                inactive_with_user,
                f"{inactive_with_user} archived employees still linked to a user account",
            )
        except (RPCError, ConnectionError):
            pass

        try:
            # Employees with departure date but still active
            active_departed = c.search_count("hr.employee", [("active", "=", True), ("departure_date", "!=", False)])
            _check_custom(
                "hr",
                "Active employees with departure date",
                active_departed == 0,
                active_departed,
                f"{active_departed} employees marked active but have a departure date set",
            )
        except (RPCError, ConnectionError):
            pass

        # ------ INDONESIA: BPJS COMPLIANCE (5 checks) ------

        # Check if payroll_management is installed (has Indonesian fields)
        _has_payroll = model_available(c, "payroll.bpjs.config")
        _has_id_fields = False
        if _has_payroll:
            try:
                test_fields = c.fields_get("hr.employee")
                _has_id_fields = "npwp" in test_fields
            except (RPCError, ConnectionError):
                pass
        elif cat == "hr":
            out.info("payroll_management not installed — Indonesian compliance checks (BPJS, PPh 21, UMR) skipped")

        if _has_id_fields:
            try:
                no_npwp = c.search_count("hr.employee", [("active", "=", True), ("npwp", "=", False)])
                _check_custom(
                    "hr",
                    "Employees without NPWP (tax ID)",
                    no_npwp == 0,
                    no_npwp,
                    f"{no_npwp} active employees have no NPWP — required for PPh 21 tax calculation",
                )
            except (RPCError, ConnectionError):
                pass

            try:
                no_nik = c.search_count("hr.employee", [("active", "=", True), ("nik_ktp", "=", False)])
                _check_custom(
                    "hr",
                    "Employees without NIK/KTP",
                    no_nik == 0,
                    no_nik,
                    f"{no_nik} active employees have no NIK (KTP) — required for BPJS and tax reporting",
                )
            except (RPCError, ConnectionError):
                pass

            try:
                no_bpjs_kes = c.search_count("hr.employee", [("active", "=", True), ("bpjs_kes_number", "=", False)])
                _check_custom(
                    "hr",
                    "Employees without BPJS Kesehatan no.",
                    no_bpjs_kes == 0,
                    no_bpjs_kes,
                    f"{no_bpjs_kes} active employees have no BPJS Kesehatan number — health insurance mandatory",
                )
            except (RPCError, ConnectionError):
                pass

            try:
                no_bpjs_tk = c.search_count("hr.employee", [("active", "=", True), ("bpjs_tk_number", "=", False)])
                _check_custom(
                    "hr",
                    "Employees without BPJS Ketenagakerjaan no.",
                    no_bpjs_tk == 0,
                    no_bpjs_tk,
                    f"{no_bpjs_tk} active employees have no BPJS TK number — employment insurance mandatory",
                )
            except (RPCError, ConnectionError):
                pass

            try:
                no_bank = c.search_count("hr.employee", [("active", "=", True), ("bank_account_number", "=", False)])
                _check_custom(
                    "hr",
                    "Employees without bank account",
                    no_bank == 0,
                    no_bank,
                    f"{no_bank} active employees have no bank account — required for salary disbursement",
                )
            except (RPCError, ConnectionError):
                pass

        # ------ INDONESIA: PPh 21 / TAX (4 checks) ------

        if _has_payroll:
            try:
                no_ptkp = c.search_count("hr.employee", [("active", "=", True), ("ptkp_status", "=", False)])
                _check_custom(
                    "hr",
                    "Employees without PTKP status",
                    no_ptkp == 0,
                    no_ptkp,
                    f"{no_ptkp} active employees have no PTKP status — PPh 21 calculation will be incorrect",
                )
            except (RPCError, ConnectionError):
                pass

            if model_available(c, "payroll.pph21.ter.config"):
                try:
                    current_year = today[:4]
                    ter_config = c.search_count(
                        "payroll.pph21.ter.config", [("year", "=", current_year), ("active", "=", True)]
                    )
                    _check_custom(
                        "hr",
                        f"PPh 21 TER config for {current_year}",
                        ter_config > 0,
                        0 if ter_config > 0 else 1,
                        f"No active PPh 21 TER rate table for {current_year} — payslips cannot compute tax"
                        if ter_config == 0
                        else f"TER config active for {current_year}",
                    )
                except (RPCError, ConnectionError):
                    pass

            if model_available(c, "payroll.pph21.ptkp.config"):
                try:
                    current_year = today[:4]
                    ptkp_config = c.search_count(
                        "payroll.pph21.ptkp.config", [("year", "=", current_year), ("active", "=", True)]
                    )
                    _check_custom(
                        "hr",
                        f"PTKP config for {current_year}",
                        ptkp_config > 0,
                        0 if ptkp_config > 0 else 1,
                        f"No active PTKP table for {current_year} — tax-free threshold unknown"
                        if ptkp_config == 0
                        else f"PTKP config active for {current_year}",
                    )
                except (RPCError, ConnectionError):
                    pass

            try:
                bpjs_config = c.search_count("payroll.bpjs.config", [("year", "=", today[:4])])
                _check_custom(
                    "hr",
                    f"BPJS rate config for {today[:4]}",
                    bpjs_config > 0,
                    0 if bpjs_config > 0 else 1,
                    f"No BPJS rate configuration for {today[:4]} — BPJS deductions cannot be calculated"
                    if bpjs_config == 0
                    else f"BPJS config active for {today[:4]}",
                )
            except (RPCError, ConnectionError):
                pass

        # ------ INDONESIA: CONTRACT COMPLIANCE (3 checks) ------

        if _has_payroll and model_available(c, "hr.contract"):
            try:
                # Contracts marked BPJS Kes registered but no number
                bpjs_kes_no_num = c.search_count(
                    "hr.contract",
                    [("state", "=", "open"), ("bpjs_kes_registered", "=", True), ("bpjs_kes_number", "=", False)],
                )
                _check_custom(
                    "hr",
                    "Contracts BPJS Kes registered but no number",
                    bpjs_kes_no_num == 0,
                    bpjs_kes_no_num,
                    f"{bpjs_kes_no_num} contracts marked BPJS Kes registered but have no number",
                )
            except (RPCError, ConnectionError):
                pass

            try:
                bpjs_tk_no_num = c.search_count(
                    "hr.contract",
                    [("state", "=", "open"), ("bpjs_tk_registered", "=", True), ("bpjs_tk_number", "=", False)],
                )
                _check_custom(
                    "hr",
                    "Contracts BPJS TK registered but no number",
                    bpjs_tk_no_num == 0,
                    bpjs_tk_no_num,
                    f"{bpjs_tk_no_num} contracts marked BPJS TK registered but have no number",
                )
            except (RPCError, ConnectionError):
                pass

            try:
                no_struct = c.search_count("hr.contract", [("state", "=", "open"), ("struct_id", "=", False)])
                _check_custom(
                    "hr",
                    "Active contracts without salary structure",
                    no_struct == 0,
                    no_struct,
                    f"{no_struct} open contracts have no salary structure — payslips cannot be generated",
                )
            except (RPCError, ConnectionError):
                pass

        if model_available(c, "payroll.umr.config"):
            try:
                current_year = today[:4]
                umr_config = c.search_count("payroll.umr.config", [("year", "=", current_year)])
                _check_custom(
                    "hr",
                    f"UMR (minimum wage) config for {current_year}",
                    umr_config > 0,
                    0 if umr_config > 0 else 1,
                    f"No UMR configuration for {current_year} — minimum wage validation disabled"
                    if umr_config == 0
                    else f"UMR config active for {current_year}",
                )
            except (RPCError, ConnectionError):
                pass

    # =====================================================================
    # MANUFACTURING CHECKS
    # =====================================================================

    if cat in ("all", "mfg") and not model_available(c, "mrp.production") and cat == "mfg":
        out.warn("MRP module (mrp) is not installed — manufacturing checks skipped")

    if cat in ("all", "mfg") and model_available(c, "mrp.production"):
        try:
            bom_no_lines = c.search_count("mrp.bom", [("bom_line_ids", "=", False)])
            _check_custom(
                "mfg",
                "BOMs without components",
                bom_no_lines == 0,
                bom_no_lines,
                f"{bom_no_lines} BOMs have no component lines — cannot produce",
            )
        except (RPCError, ConnectionError):
            pass

        try:
            mo_stuck_confirmed = c.search_count(
                "mrp.production", [("state", "=", "confirmed"), ("create_date", "<", thirty_days_ago)]
            )
            _check_custom(
                "mfg",
                "MOs stuck >30d (confirmed)",
                mo_stuck_confirmed == 0,
                mo_stuck_confirmed,
                f"{mo_stuck_confirmed} confirmed MOs not started for >30 days",
            )
        except (RPCError, ConnectionError):
            pass

        try:
            mo_stuck_progress = c.search_count(
                "mrp.production", [("state", "=", "progress"), ("create_date", "<", thirty_days_ago)]
            )
            _check_custom(
                "mfg",
                "MOs stuck >30d (progress)",
                mo_stuck_progress == 0,
                mo_stuck_progress,
                f"{mo_stuck_progress} MOs in progress for >30 days",
            )
        except (RPCError, ConnectionError):
            pass

        try:
            mo_draft_old = c.search_count(
                "mrp.production", [("state", "=", "draft"), ("create_date", "<", thirty_days_ago)]
            )
            _check_custom(
                "mfg",
                "Draft MOs >30d",
                mo_draft_old == 0,
                mo_draft_old,
                f"{mo_draft_old} draft MOs older than 30 days — confirm or cancel",
            )
        except (RPCError, ConnectionError):
            pass

    # =====================================================================
    # CROSS-MODULE CHECKS
    # =====================================================================

    if cat in ("all", "cross"):
        try:
            so_no_delivery = c.search_count(
                "sale.order",
                [("state", "=", "sale"), ("delivery_count", "=", 0), ("create_date", "<", thirty_days_ago)],
            )
            _check_custom(
                "cross",
                "SO confirmed but no delivery",
                so_no_delivery == 0,
                so_no_delivery,
                f"{so_no_delivery} confirmed SOs >30d with no delivery created",
            )
        except (RPCError, ConnectionError):
            pass

        try:
            so_no_invoice = c.search_count(
                "sale.order",
                [("state", "=", "sale"), ("invoice_count", "=", 0), ("create_date", "<", thirty_days_ago)],
            )
            _check_custom(
                "cross",
                "SO confirmed but no invoice",
                so_no_invoice == 0,
                so_no_invoice,
                f"{so_no_invoice} confirmed SOs >30d with no invoice created",
            )
        except (RPCError, ConnectionError):
            pass

        if model_available(c, "purchase.order"):
            try:
                po_no_receipt = c.search_count(
                    "purchase.order",
                    [("state", "=", "purchase"), ("receipt_count", "=", 0), ("create_date", "<", thirty_days_ago)],
                )
                _check_custom(
                    "cross",
                    "PO confirmed but no receipt",
                    po_no_receipt == 0,
                    po_no_receipt,
                    f"{po_no_receipt} confirmed POs >30d with no goods receipt",
                )
            except (RPCError, ConnectionError):
                pass

        try:
            inv_no_so = c.search_count(
                "account.move",
                [("move_type", "=", "out_invoice"), ("state", "=", "posted"), ("invoice_origin", "=", False)],
            )
            _check_custom(
                "cross",
                "Posted invoices without SO link",
                inv_no_so == 0,
                inv_no_so,
                f"{inv_no_so} posted customer invoices not linked to any SO",
            )
        except (RPCError, ConnectionError):
            pass

        try:
            so_delivered_not_invoiced = c.search_count(
                "sale.order", [("state", "=", "sale"), ("invoice_status", "=", "to invoice")]
            )
            _check_custom(
                "cross",
                "Delivered but not invoiced",
                so_delivered_not_invoiced == 0,
                so_delivered_not_invoiced,
                f"{so_delivered_not_invoiced} SOs fully delivered but not yet invoiced",
            )
        except (RPCError, ConnectionError):
            pass

        if model_available(c, "purchase.order"):
            try:
                po_received_not_billed = c.search_count(
                    "purchase.order", [("state", "=", "purchase"), ("invoice_status", "=", "to invoice")]
                )
                _check_custom(
                    "cross",
                    "Received but not billed",
                    po_received_not_billed == 0,
                    po_received_not_billed,
                    f"{po_received_not_billed} POs fully received but not yet billed",
                )
            except (RPCError, ConnectionError):
                pass

        # --- Order-to-Cash workflow gaps ---
        try:
            # Partial deliveries not completed >14d
            partial_delivery = c.search_count(
                "stock.picking",
                [
                    ("picking_type_code", "=", "outgoing"),
                    ("state", "=", "assigned"),
                    ("scheduled_date", "<", fourteen_days_ago),
                ],
            )
            _check_custom(
                "cross",
                "Partial deliveries pending >14d",
                partial_delivery == 0,
                partial_delivery,
                f"{partial_delivery} outgoing deliveries ready but not validated >14 days",
            )
        except (RPCError, ConnectionError):
            pass

        try:
            # Credit notes without original invoice reference
            cn_no_ref = c.search_count(
                "account.move",
                [("move_type", "=", "out_refund"), ("state", "=", "posted"), ("invoice_origin", "=", False)],
            )
            _check_custom(
                "cross",
                "Credit notes without origin",
                cn_no_ref == 0,
                cn_no_ref,
                f"{cn_no_ref} posted credit notes not linked to original invoice",
            )
        except (RPCError, ConnectionError):
            pass

        try:
            # Payments without invoice reconciliation
            unreconciled_payments = c.search_count(
                "account.payment",
                [("state", "=", "posted"), ("is_reconciled", "=", False), ("date", "<", thirty_days_ago[:10])],
            )
            _check_custom(
                "cross",
                "Payments not reconciled >30d",
                unreconciled_payments == 0,
                unreconciled_payments,
                f"{unreconciled_payments} posted payments >30d not reconciled to invoices",
            )
        except (RPCError, ConnectionError):
            pass

        # --- Procure-to-Pay workflow gaps ---
        if model_available(c, "purchase.order"):
            try:
                # PO confirmed but vendor bill amount mismatch
                po_done = c.search_read(
                    "purchase.order",
                    [("state", "=", "purchase"), ("invoice_status", "=", "invoiced")],
                    fields=["amount_total", "name"],
                    limit=500,
                )
                # Just count — detailed mismatch requires line-level comparison
                _check_custom(
                    "cross",
                    "POs fully billed (verified count)",
                    True,
                    len(po_done),
                    f"{len(po_done)} POs fully invoiced — spot check amounts if needed",
                )
            except (RPCError, ConnectionError):
                pass

            try:
                # Draft POs >60 days — should be confirmed or cancelled
                stale_draft_po = c.search_count(
                    "purchase.order",
                    [("state", "=", "draft"), ("create_date", "<", sixty_days_ago)],
                )
                _check_custom(
                    "cross",
                    "Draft POs >60d (stale RFQs)",
                    stale_draft_po == 0,
                    stale_draft_po,
                    f"{stale_draft_po} RFQs in draft >60 days — confirm or cancel",
                )
            except (RPCError, ConnectionError):
                pass

        # --- Inventory-to-Accounting gaps ---
        try:
            # Pickings done but no accounting entry (stock valuation gap)
            done_picks_no_move = c.search_count(
                "stock.picking",
                [
                    ("state", "=", "done"),
                    ("picking_type_code", "in", ["incoming", "outgoing"]),
                    ("date_done", "<", thirty_days_ago),
                ],
            )
            # This is informational — stock moves create journal entries automatically
            if done_picks_no_move > 0:
                _check_custom(
                    "cross",
                    "Completed picks >30d (reconcile stock vs GL)",
                    True,
                    done_picks_no_move,
                    f"{done_picks_no_move} completed picks >30d — verify stock valuation matches GL",
                )
        except (RPCError, ConnectionError):
            pass

        # --- HR-to-Finance gaps ---
        if model_available(c, "hr.expense.sheet"):
            try:
                # Approved expenses not reimbursed >30d
                approved_not_paid = c.search_count(
                    "hr.expense.sheet",
                    [("state", "=", "approve"), ("create_date", "<", thirty_days_ago)],
                )
                _check_custom(
                    "cross",
                    "Approved expenses not paid >30d",
                    approved_not_paid == 0,
                    approved_not_paid,
                    f"{approved_not_paid} expense sheets approved >30d but not reimbursed",
                )
            except (RPCError, ConnectionError):
                pass

        # --- Manufacturing-to-Inventory gaps ---
        if model_available(c, "mrp.production"):
            try:
                # MOs done but no stock move (should have consumed components)
                mo_done = c.search_count(
                    "mrp.production",
                    [("state", "=", "done"), ("date_start", "<", thirty_days_ago)],
                )
                if mo_done > 0:
                    _check_custom(
                        "cross",
                        "Completed MOs >30d (verify component consumption)",
                        True,
                        mo_done,
                        f"{mo_done} completed MOs >30d — verify component stock was consumed",
                    )
            except (RPCError, ConnectionError):
                pass

        # --- Sales-to-CRM gaps ---
        if model_available(c, "crm.lead"):
            try:
                # Won opportunities without SO
                won_no_so = c.search_count(
                    "crm.lead",
                    [("stage_id.is_won", "=", True), ("order_ids", "=", False), ("type", "=", "opportunity")],
                )
                _check_custom(
                    "cross",
                    "Won opportunities without SO",
                    won_no_so == 0,
                    won_no_so,
                    f"{won_no_so} won opportunities with no linked sale order",
                )
            except (RPCError, ConnectionError):
                pass

        # --- Payment-to-Invoice gaps ---
        try:
            # Invoices paid but amount_residual != 0 (partial payment or rounding issue)
            paid_with_residual = c.search_count(
                "account.move",
                [
                    ("move_type", "in", ["out_invoice", "in_invoice"]),
                    ("payment_state", "=", "paid"),
                    ("amount_residual", "!=", 0),
                ],
            )
            _check_custom(
                "cross",
                "Paid invoices with residual balance",
                paid_with_residual == 0,
                paid_with_residual,
                f"{paid_with_residual} invoices marked 'paid' but still have residual amount",
            )
        except (RPCError, ConnectionError):
            pass

        # --- Aging analysis ---
        try:
            # Overdue AR >90 days
            overdue_ar_90 = c.search_count(
                "account.move",
                [
                    ("move_type", "=", "out_invoice"),
                    ("state", "=", "posted"),
                    ("payment_state", "!=", "paid"),
                    ("invoice_date_due", "<", ninety_days_ago[:10]),
                ],
            )
            _check_custom(
                "cross",
                "Overdue AR >90 days",
                overdue_ar_90 == 0,
                overdue_ar_90,
                f"{overdue_ar_90} customer invoices overdue >90 days — escalate collection",
            )
        except (RPCError, ConnectionError):
            pass

        try:
            # Overdue AP >90 days
            overdue_ap_90 = c.search_count(
                "account.move",
                [
                    ("move_type", "=", "in_invoice"),
                    ("state", "=", "posted"),
                    ("payment_state", "!=", "paid"),
                    ("invoice_date_due", "<", ninety_days_ago[:10]),
                ],
            )
            _check_custom(
                "cross",
                "Overdue AP >90 days",
                overdue_ap_90 == 0,
                overdue_ap_90,
                f"{overdue_ap_90} vendor bills overdue >90 days — check vendor relationships",
            )
        except (RPCError, ConnectionError):
            pass

    # =====================================================================
    # SUMMARY
    # =====================================================================

    check_count = len(rows)
    title = f"Data Integrity ({check_count} checks)"
    if total_issues:
        title += f" — [yellow]{total_issues} issues[/yellow]"
    else:
        title += " — [green]all clean[/green]"

    out.table(
        title,
        [("Cat", "dim"), ("Check", "cyan"), ("Status", ""), ("Detail", "dim")],
        rows,
        json_data,
    )
