"""Period-close validation commands."""

from __future__ import annotations

from datetime import UTC
from typing import Annotated

import typer

from kctl_odoo.core.callbacks import AppContext
from kctl_odoo.core.exceptions import ConnectionError, RPCError

app = typer.Typer(help="Period-close and financial statement validation.")


@app.command("monthly-close")
def monthly_close(
    ctx: typer.Context,
    period_end: Annotated[
        str | None, typer.Option("--date", "-d", help="Period end date (YYYY-MM-DD, default: last month end)")
    ] = None,
) -> None:
    """Combined monthly close validation (accounting + inventory).

    Runs both accounting-close and inventory-close checks, then presents
    a unified summary with total blocking issues across both areas.

    Examples:
        kctl-odoo maintenance monthly-close
        kctl-odoo maintenance monthly-close --date 2025-12-31
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    from datetime import date, datetime, timedelta

    now = datetime.now(tz=UTC)

    if period_end:
        close_date = period_end
    else:
        first_of_month = date(now.year, now.month, 1)
        last_month_end = first_of_month - timedelta(days=1)
        close_date = str(last_month_end)

    rows: list[list[str]] = []
    json_data: list[dict] = []
    acct_issues = 0
    inv_issues = 0

    def _add(area: str, name: str, ok: bool, detail: str) -> None:
        nonlocal acct_issues, inv_issues
        if not ok:
            if area == "ACCT":
                acct_issues += 1
            else:
                inv_issues += 1
        status = "[green]PASS[/green]" if ok else "[red]FAIL[/red]"
        rows.append([area, name, status, detail])
        json_data.append({"area": area, "check": name, "passed": ok, "detail": detail})

    out.info(f"Monthly close validation for period ending: {close_date}")

    # =====================================================================
    # ACCOUNTING CHECKS
    # =====================================================================

    # 1. Trial Balance
    try:
        posted_lines = c.search_read(
            "account.move.line",
            [("parent_state", "=", "posted"), ("date", "<=", close_date)],
            fields=["debit", "credit"],
            limit=0,
        )
        total_debit = sum(line.get("debit", 0) for line in posted_lines)
        total_credit = sum(line.get("credit", 0) for line in posted_lines)
        diff = abs(total_debit - total_credit)
        _add("ACCT", "Trial balance (debit = credit)", diff < 0.01, f"Diff: {diff:,.2f}")
    except (RPCError, ConnectionError) as e:
        _add("ACCT", "Trial balance", False, f"Check failed: {e}")

    # 2. Unposted entries in period
    try:
        draft_in_period = c.search_count("account.move", [("state", "=", "draft"), ("date", "<=", close_date)])
        _add("ACCT", "No unposted entries", draft_in_period == 0, f"{draft_in_period} draft entries in period")
    except (RPCError, ConnectionError) as e:
        _add("ACCT", "Unposted entries", False, str(e))

    # 3. Draft invoices
    try:
        draft_invoices = c.search_count(
            "account.move",
            [
                ("state", "=", "draft"),
                ("move_type", "in", ["out_invoice", "in_invoice", "out_refund", "in_refund"]),
                ("invoice_date", "<=", close_date),
            ],
        )
        _add("ACCT", "No draft invoices/bills", draft_invoices == 0, f"{draft_invoices} draft invoices in period")
    except (RPCError, ConnectionError) as e:
        _add("ACCT", "Draft invoices", False, str(e))

    # 4. Bank reconciliation
    try:
        unreconciled_bank = c.search_count(
            "account.bank.statement.line",
            [("is_reconciled", "=", False), ("date", "<=", close_date)],
        )
        _add("ACCT", "Bank reconciled", unreconciled_bank == 0, f"{unreconciled_bank} unreconciled bank lines")
    except (RPCError, ConnectionError):
        _add("ACCT", "Bank reconciliation", True, "Skipped — module not active")

    # 5. Suspense accounts
    try:
        suspense = c.search_read("account.account", [("name", "ilike", "suspense")], fields=["id", "name"], limit=5)
        suspense_ok = True
        for sa in suspense:
            lines = c.search_read(
                "account.move.line",
                [("account_id", "=", sa["id"]), ("parent_state", "=", "posted"), ("date", "<=", close_date)],
                fields=["debit", "credit"],
                limit=0,
            )
            bal = sum(line.get("debit", 0) - line.get("credit", 0) for line in lines)
            if abs(bal) > 0.01:
                suspense_ok = False
        if suspense:
            _add("ACCT", "Suspense accounts at zero", suspense_ok, f"{len(suspense)} suspense accounts checked")
    except (RPCError, ConnectionError):
        pass

    # 6. Lock dates
    try:
        companies = c.search_read(
            "res.company", [], fields=["name", "period_lock_date", "fiscalyear_lock_date"], limit=5
        )
        for comp in companies:
            has_lock = bool(comp.get("period_lock_date") or comp.get("fiscalyear_lock_date"))
            _add(
                "ACCT",
                f"Lock dates ({comp['name']})",
                has_lock,
                f"Period: {comp.get('period_lock_date') or 'not set'},"
                f" FY: {comp.get('fiscalyear_lock_date') or 'not set'}",
            )
    except (RPCError, ConnectionError):
        pass

    # =====================================================================
    # INVENTORY CHECKS
    # =====================================================================

    # 1. Negative stock
    try:
        negative = c.search_count("stock.quant", [("quantity", "<", 0), ("location_id.usage", "=", "internal")])
        _add("INV", "No negative stock", negative == 0, f"{negative} products with negative quantities")
    except (RPCError, ConnectionError) as e:
        _add("INV", "Negative stock", False, str(e))

    # 2. Stuck transfers
    try:
        cutoff_7d = (now - timedelta(days=7)).strftime("%Y-%m-%d")
        stuck = c.search_count(
            "stock.picking",
            [("state", "in", ["waiting", "confirmed"]), ("scheduled_date", "<", cutoff_7d)],
        )
        _add("INV", "No stuck transfers (>7d)", stuck == 0, f"{stuck} transfers stuck >7 days")
    except (RPCError, ConnectionError) as e:
        _add("INV", "Stuck transfers", False, str(e))

    # 3. Unprocessed deliveries
    try:
        unshipped = c.search_count(
            "stock.picking",
            [
                ("state", "=", "assigned"),
                ("picking_type_code", "=", "outgoing"),
                ("scheduled_date", "<=", close_date),
            ],
        )
        _add("INV", "All deliveries processed", unshipped == 0, f"{unshipped} ready deliveries not shipped")
    except (RPCError, ConnectionError) as e:
        _add("INV", "Deliveries", False, str(e))

    # 4. Orphan stock moves
    try:
        orphan_moves = c.search_count(
            "stock.move",
            [("picking_id", "=", False), ("state", "not in", ["done", "cancel"]), ("date", "<=", close_date)],
        )
        _add("INV", "No orphan stock moves", orphan_moves == 0, f"{orphan_moves} moves without picking")
    except (RPCError, ConnectionError) as e:
        _add("INV", "Orphan moves", False, str(e))

    # 5. Valuation vs GL
    try:
        layers = c.search_read("stock.valuation.layer", [("company_id", "!=", False)], fields=["value"], limit=0)
        layer_total = sum(line.get("value", 0) for line in layers)
        stock_accounts = c.search_read(
            "account.account",
            [("account_type", "=", "asset_current"), ("name", "ilike", "stock valuation")],
            fields=["id"],
            limit=5,
        )
        gl_total = 0.0
        for sa in stock_accounts:
            gl_lines = c.search_read(
                "account.move.line",
                [("account_id", "=", sa["id"]), ("parent_state", "=", "posted")],
                fields=["debit", "credit"],
                limit=0,
            )
            gl_total += sum(line.get("debit", 0) - line.get("credit", 0) for line in gl_lines)
        diff = abs(layer_total - gl_total)
        _add("INV", "Valuation matches GL", diff < 1.0, f"Diff: {diff:,.2f}")
    except (RPCError, ConnectionError):
        _add("INV", "Valuation vs GL", True, "Skipped — not available")

    # 6. Expired lots
    try:
        today_str = now.strftime("%Y-%m-%d")
        expired = c.search_count("stock.lot", [("expiration_date", "<", today_str), ("product_qty", ">", 0)])
        _add("INV", "No expired lots with stock", expired == 0, f"{expired} expired lots with stock")
    except (RPCError, ConnectionError):
        _add("INV", "Expired lots", True, "Skipped — lot tracking not active")

    # =====================================================================
    # SUMMARY
    # =====================================================================

    total_issues = acct_issues + inv_issues
    acct_total = sum(1 for d in json_data if d["area"] == "ACCT")
    inv_total = sum(1 for d in json_data if d["area"] == "INV")
    acct_passed = sum(1 for d in json_data if d["area"] == "ACCT" and d["passed"])
    inv_passed = sum(1 for d in json_data if d["area"] == "INV" and d["passed"])

    title = f"Monthly Close — {close_date}"
    if total_issues:
        title += f" — [red]{total_issues} blocking[/red]"
        title += f" (acct: {acct_passed}/{acct_total}, inv: {inv_passed}/{inv_total})"
    else:
        title += f" — [green]ready to close[/green] ({acct_passed + inv_passed}/{acct_total + inv_total} passed)"

    out.table(
        title,
        [("Area", "dim"), ("Check", "cyan"), ("Status", ""), ("Detail", "dim")],
        rows,
        json_data,
    )

    if total_issues:
        if acct_issues:
            out.warn(f"Accounting: {acct_issues} blocking issue(s)")
        if inv_issues:
            out.warn(f"Inventory: {inv_issues} blocking issue(s)")
        out.warn(f"Fix {total_issues} total issues before closing period {close_date}")
    else:
        out.success(f"All checks passed — period {close_date} is ready to close")
        out.info(f"Set lock date via: kctl-odoo master-data setting-set period_lock_date {close_date}")


@app.command("check-financial-statements")
def check_financial_statements(
    ctx: typer.Context,
    date: Annotated[str | None, typer.Option("--date", help="As-of date (YYYY-MM-DD, default: today)")] = None,
    period_start: Annotated[str | None, typer.Option("--period-start", help="Period start (YYYY-MM-DD)")] = None,
) -> None:
    """Financial statement integrity checks for P&L, Balance Sheet, and Cash Flow.

    Runs 12 checks that auditors verify before signing off:
    - Balance sheet equation (Assets = Liabilities + Equity)
    - AR/AP sub-ledger vs GL reconciliation
    - Revenue vs confirmed SO comparison
    - COGS vs inventory valuation change
    - Stale prepaid/accrued balances
    - Bank balance vs GL
    - Large manual journal entries (audit risk)
    - Revenue cut-off (entries after period end)

    Examples:
        kctl-odoo maintenance check-financial-statements
        kctl-odoo maintenance check-financial-statements --date 2026-03-31
        kctl-odoo maintenance check-financial-statements --date 2026-03-31 --period-start 2026-01-01
    """
    from datetime import datetime

    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    now = datetime.now(tz=UTC)
    as_of = date or now.strftime("%Y-%m-%d")
    p_start = period_start or as_of[:7] + "-01"  # First day of the as-of month

    rows: list[list[str]] = []
    json_data: list[dict] = []
    total_issues = 0

    def _add(name: str, ok: bool, count: int, detail: str) -> None:
        nonlocal total_issues
        if not ok:
            total_issues += count
        status = "[green]OK[/green]" if ok else f"[red]{count}[/red]"
        rows.append([name, status, detail if not ok else detail])
        json_data.append({"check": name, "ok": ok, "count": count, "detail": detail})

    out.info(f"Financial statement checks as of {as_of} (period from {p_start})")

    # =====================================================================
    # 1. BALANCE SHEET EQUATION: Assets = Liabilities + Equity
    # =====================================================================
    try:
        # Get account types and balances
        asset_types = [
            "asset_receivable",
            "asset_cash",
            "asset_current",
            "asset_non_current",
            "asset_prepayments",
            "asset_fixed",
        ]
        liability_types = ["liability_payable", "liability_current", "liability_non_current"]
        equity_types = ["equity", "equity_unaffected"]

        total_assets = 0
        total_liabilities = 0
        total_equity = 0

        for acc_type in asset_types:
            try:
                lines = c.search_read(
                    "account.move.line",
                    [
                        ("account_id.account_type", "=", acc_type),
                        ("parent_state", "=", "posted"),
                        ("date", "<=", as_of),
                    ],
                    fields=["debit", "credit"],
                    limit=0,
                )
                total_assets += sum(l.get("debit", 0) - l.get("credit", 0) for l in lines)
            except (RPCError, ConnectionError):
                pass

        for acc_type in liability_types:
            try:
                lines = c.search_read(
                    "account.move.line",
                    [
                        ("account_id.account_type", "=", acc_type),
                        ("parent_state", "=", "posted"),
                        ("date", "<=", as_of),
                    ],
                    fields=["debit", "credit"],
                    limit=0,
                )
                total_liabilities += sum(l.get("credit", 0) - l.get("debit", 0) for l in lines)
            except (RPCError, ConnectionError):
                pass

        for acc_type in equity_types:
            try:
                lines = c.search_read(
                    "account.move.line",
                    [
                        ("account_id.account_type", "=", acc_type),
                        ("parent_state", "=", "posted"),
                        ("date", "<=", as_of),
                    ],
                    fields=["debit", "credit"],
                    limit=0,
                )
                total_equity += sum(l.get("credit", 0) - l.get("debit", 0) for l in lines)
            except (RPCError, ConnectionError):
                pass

        # Add income/expense to equity (current year P&L)
        for acc_type in ["income", "income_other"]:
            try:
                lines = c.search_read(
                    "account.move.line",
                    [
                        ("account_id.account_type", "=", acc_type),
                        ("parent_state", "=", "posted"),
                        ("date", "<=", as_of),
                    ],
                    fields=["debit", "credit"],
                    limit=0,
                )
                total_equity += sum(l.get("credit", 0) - l.get("debit", 0) for l in lines)
            except (RPCError, ConnectionError):
                pass
        for acc_type in ["expense", "expense_depreciation", "expense_direct_cost"]:
            try:
                lines = c.search_read(
                    "account.move.line",
                    [
                        ("account_id.account_type", "=", acc_type),
                        ("parent_state", "=", "posted"),
                        ("date", "<=", as_of),
                    ],
                    fields=["debit", "credit"],
                    limit=0,
                )
                total_equity -= sum(l.get("debit", 0) - l.get("credit", 0) for l in lines)
            except (RPCError, ConnectionError):
                pass

        diff = abs(total_assets - total_liabilities - total_equity)
        ok = diff < 1.0  # Allow 1 rounding tolerance
        _add(
            "BS equation (A = L + E)",
            ok,
            1 if not ok else 0,
            f"Assets: {total_assets:,.2f}, Liabilities: {total_liabilities:,.2f}, Equity: {total_equity:,.2f}, Diff: {diff:,.2f}",
        )
    except (RPCError, ConnectionError) as e:
        _add("BS equation (A = L + E)", False, 1, f"Error: {e}")

    # =====================================================================
    # 2. AR SUB-LEDGER vs GL
    # =====================================================================
    try:
        # GL AR balance
        ar_gl_lines = c.search_read(
            "account.move.line",
            [
                ("account_id.account_type", "=", "asset_receivable"),
                ("parent_state", "=", "posted"),
                ("date", "<=", as_of),
            ],
            fields=["debit", "credit"],
            limit=0,
        )
        ar_gl = sum(l.get("debit", 0) - l.get("credit", 0) for l in ar_gl_lines)

        # Sub-ledger: sum of open invoice amount_residual
        open_invoices = c.search_read(
            "account.move",
            [
                ("move_type", "=", "out_invoice"),
                ("state", "=", "posted"),
                ("payment_state", "in", ["not_paid", "partial"]),
                ("invoice_date", "<=", as_of),
            ],
            fields=["amount_residual"],
            limit=0,
        )
        ar_sub = sum(inv.get("amount_residual", 0) for inv in open_invoices)

        ar_diff = abs(ar_gl - ar_sub)
        ok = ar_diff < 100  # Some tolerance for timing
        _add(
            "AR: GL vs sub-ledger",
            ok,
            1 if not ok else 0,
            f"GL: {ar_gl:,.2f}, Open invoices: {ar_sub:,.2f}, Diff: {ar_diff:,.2f}",
        )
    except (RPCError, ConnectionError):
        _add("AR: GL vs sub-ledger", True, 0, "Could not compare")

    # =====================================================================
    # 3. AP SUB-LEDGER vs GL
    # =====================================================================
    try:
        ap_gl_lines = c.search_read(
            "account.move.line",
            [
                ("account_id.account_type", "=", "liability_payable"),
                ("parent_state", "=", "posted"),
                ("date", "<=", as_of),
            ],
            fields=["debit", "credit"],
            limit=0,
        )
        ap_gl = sum(l.get("credit", 0) - l.get("debit", 0) for l in ap_gl_lines)

        open_bills = c.search_read(
            "account.move",
            [
                ("move_type", "=", "in_invoice"),
                ("state", "=", "posted"),
                ("payment_state", "in", ["not_paid", "partial"]),
                ("invoice_date", "<=", as_of),
            ],
            fields=["amount_residual"],
            limit=0,
        )
        ap_sub = sum(bill.get("amount_residual", 0) for bill in open_bills)

        ap_diff = abs(ap_gl - ap_sub)
        ok = ap_diff < 100
        _add(
            "AP: GL vs sub-ledger",
            ok,
            1 if not ok else 0,
            f"GL: {ap_gl:,.2f}, Open bills: {ap_sub:,.2f}, Diff: {ap_diff:,.2f}",
        )
    except (RPCError, ConnectionError):
        _add("AP: GL vs sub-ledger", True, 0, "Could not compare")

    # =====================================================================
    # 4. REVENUE vs CONFIRMED SO
    # =====================================================================
    try:
        # Revenue from GL (income accounts in period)
        revenue_lines = c.search_read(
            "account.move.line",
            [
                ("account_id.account_type", "in", ["income", "income_other"]),
                ("parent_state", "=", "posted"),
                ("date", ">=", p_start),
                ("date", "<=", as_of),
            ],
            fields=["credit", "debit"],
            limit=0,
        )
        gl_revenue = sum(l.get("credit", 0) - l.get("debit", 0) for l in revenue_lines)

        # SO confirmed in period
        so_revenue = c.search_read(
            "sale.order",
            [("state", "=", "sale"), ("date_order", ">=", p_start), ("date_order", "<=", as_of)],
            fields=["amount_untaxed"],
            limit=0,
        )
        so_total = sum(s.get("amount_untaxed", 0) for s in so_revenue)

        rev_diff = abs(gl_revenue - so_total)
        pct_diff = (rev_diff / max(gl_revenue, 1)) * 100
        ok = pct_diff < 20  # 20% tolerance (timing, credit notes, etc.)
        _add(
            "Revenue: GL vs SO",
            ok,
            1 if not ok else 0,
            f"GL revenue: {gl_revenue:,.2f}, SO total: {so_total:,.2f}, Diff: {pct_diff:.1f}%",
        )
    except (RPCError, ConnectionError):
        _add("Revenue: GL vs SO", True, 0, "Could not compare")

    # =====================================================================
    # 5. COGS vs INVENTORY VALUATION CHANGE
    # =====================================================================
    try:
        cogs_lines = c.search_read(
            "account.move.line",
            [
                ("account_id.account_type", "=", "expense_direct_cost"),
                ("parent_state", "=", "posted"),
                ("date", ">=", p_start),
                ("date", "<=", as_of),
            ],
            fields=["debit", "credit"],
            limit=0,
        )
        gl_cogs = sum(l.get("debit", 0) - l.get("credit", 0) for l in cogs_lines)
        _add("COGS recorded in period", True, 0, f"COGS: {gl_cogs:,.2f}")
    except (RPCError, ConnectionError):
        _add("COGS recorded in period", True, 0, "Could not calculate")

    # =====================================================================
    # 6. STALE PREPAID BALANCES
    # =====================================================================
    try:
        prepaid_lines = c.search_read(
            "account.move.line",
            [
                ("account_id.account_type", "=", "asset_prepayments"),
                ("parent_state", "=", "posted"),
                ("date", "<=", as_of),
            ],
            fields=["debit", "credit"],
            limit=0,
        )
        prepaid_balance = sum(l.get("debit", 0) - l.get("credit", 0) for l in prepaid_lines)
        ok = prepaid_balance >= 0
        _add(
            "Prepaid balance",
            ok,
            1 if not ok else 0,
            f"Prepaid/advance balance: {prepaid_balance:,.2f}" + (" — negative balance is unusual" if not ok else ""),
        )
    except (RPCError, ConnectionError):
        _add("Prepaid balance", True, 0, "Could not calculate")

    # =====================================================================
    # 7. BANK BALANCE vs GL
    # =====================================================================
    try:
        bank_journals = c.search_read(
            "account.journal",
            [("type", "=", "bank")],
            fields=["name", "default_account_id"],
            limit=10,
        )
        for bj in bank_journals:
            acc_id = bj["default_account_id"]
            if isinstance(acc_id, list):
                acc_id = acc_id[0]
            if not acc_id:
                continue
            bank_lines = c.search_read(
                "account.move.line",
                [("account_id", "=", acc_id), ("parent_state", "=", "posted"), ("date", "<=", as_of)],
                fields=["debit", "credit"],
                limit=0,
            )
            bank_gl = sum(l.get("debit", 0) - l.get("credit", 0) for l in bank_lines)
            _add(f"Bank GL: {bj['name']}", True, 0, f"Balance: {bank_gl:,.2f}")
    except (RPCError, ConnectionError):
        _add("Bank GL balances", True, 0, "Could not calculate")

    # =====================================================================
    # 8. LARGE MANUAL JOURNAL ENTRIES (audit risk)
    # =====================================================================
    try:
        # Manual entries > threshold in period
        threshold = 50_000_000  # 50 million IDR
        large_entries = c.search_count(
            "account.move",
            [
                ("move_type", "=", "entry"),
                ("state", "=", "posted"),
                ("date", ">=", p_start),
                ("date", "<=", as_of),
                ("amount_total", ">", threshold),
            ],
        )
        _add(
            "Large manual entries (>50M)",
            large_entries == 0,
            large_entries,
            f"{large_entries} manual journal entries above {threshold:,.0f} — review for appropriateness",
        )
    except (RPCError, ConnectionError):
        _add("Large manual entries", True, 0, "Could not check")

    # =====================================================================
    # 9. REVENUE CUT-OFF
    # =====================================================================
    try:
        # Revenue entries after period end (next month entries dated in this period)
        as_of[:8] + "01"  # crude — just informational
        revenue_after = c.search_count(
            "account.move",
            [
                ("move_type", "=", "out_invoice"),
                ("state", "=", "posted"),
                ("invoice_date", ">", as_of),
                ("create_date", "<=", as_of + " 23:59:59"),
            ],
        )
        _add(
            "Revenue cut-off",
            revenue_after == 0,
            revenue_after,
            f"{revenue_after} invoices dated after {as_of} but created on/before — potential cut-off issue",
        )
    except (RPCError, ConnectionError):
        _add("Revenue cut-off", True, 0, "Could not check")

    # =====================================================================
    # 10. CASH POSITION SUMMARY
    # =====================================================================
    try:
        cash_types = ["asset_cash"]
        cash_lines = c.search_read(
            "account.move.line",
            [("account_id.account_type", "in", cash_types), ("parent_state", "=", "posted"), ("date", "<=", as_of)],
            fields=["debit", "credit"],
            limit=0,
        )
        cash_balance = sum(l.get("debit", 0) - l.get("credit", 0) for l in cash_lines)
        ok = cash_balance >= 0
        _add(
            "Cash position",
            ok,
            1 if not ok else 0,
            f"Total cash/bank: {cash_balance:,.2f}" + (" — NEGATIVE cash balance!" if not ok else ""),
        )
    except (RPCError, ConnectionError):
        _add("Cash position", True, 0, "Could not calculate")

    # =====================================================================
    # 11. UNEARNED REVENUE / DEFERRED INCOME
    # =====================================================================
    try:
        deferred_lines = c.search_read(
            "account.move.line",
            [
                ("account_id.account_type", "=", "liability_current"),
                ("account_id.name", "ilike", "deferred"),
                ("parent_state", "=", "posted"),
                ("date", "<=", as_of),
            ],
            fields=["debit", "credit"],
            limit=0,
        )
        if deferred_lines:
            deferred_balance = sum(l.get("credit", 0) - l.get("debit", 0) for l in deferred_lines)
            _add("Deferred revenue", True, 0, f"Balance: {deferred_balance:,.2f} — verify amortization schedule")
    except (RPCError, ConnectionError):
        pass

    # =====================================================================
    # 12. P&L SUMMARY FOR PERIOD
    # =====================================================================
    try:
        # Total revenue
        rev_lines = c.search_read(
            "account.move.line",
            [
                ("account_id.account_type", "in", ["income", "income_other"]),
                ("parent_state", "=", "posted"),
                ("date", ">=", p_start),
                ("date", "<=", as_of),
            ],
            fields=["credit", "debit"],
            limit=0,
        )
        period_revenue = sum(l.get("credit", 0) - l.get("debit", 0) for l in rev_lines)

        # Total expenses
        exp_lines = c.search_read(
            "account.move.line",
            [
                ("account_id.account_type", "in", ["expense", "expense_depreciation", "expense_direct_cost"]),
                ("parent_state", "=", "posted"),
                ("date", ">=", p_start),
                ("date", "<=", as_of),
            ],
            fields=["debit", "credit"],
            limit=0,
        )
        period_expenses = sum(l.get("debit", 0) - l.get("credit", 0) for l in exp_lines)

        net_income = period_revenue - period_expenses
        margin = (net_income / period_revenue * 100) if period_revenue > 0 else 0
        _add(
            "P&L summary",
            True,
            0,
            f"Revenue: {period_revenue:,.2f}, Expenses: {period_expenses:,.2f}, Net: {net_income:,.2f} ({margin:.1f}%)",
        )
    except (RPCError, ConnectionError):
        _add("P&L summary", True, 0, "Could not calculate")

    # =====================================================================
    # DISPLAY
    # =====================================================================
    issue_count = sum(1 for r in rows if "[red]" in r[1])
    title = f"Financial Statement Checks — {as_of}"
    if issue_count > 0:
        title += f" — {issue_count} issue(s)"

    out.table(
        title,
        [("Check", ""), ("Status", ""), ("Detail", "")],
        rows,
        data_for_json=json_data,
    )

    if issue_count > 0:
        out.warn(f"{issue_count} issue(s) found — review before finalizing financial statements")
    else:
        out.success("All financial statement checks passed")
