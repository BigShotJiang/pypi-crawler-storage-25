"""Maintenance sub-package: health checks, data integrity, and period-close."""

from __future__ import annotations

import typer

from .auto import app as _auto_app
from .cleanup import app as _cleanup_app
from .health import app as _health_app
from .integrity import app as _integrity_app
from .integrity import check_data
from .period_close import app as _period_close_app

app = typer.Typer(help="Database maintenance, health checks, and period-close validation.")

for _sub in [_health_app, _integrity_app, _period_close_app, _auto_app, _cleanup_app]:
    for _cmd in _sub.registered_commands:
        app.registered_commands.append(_cmd)

__all__ = ["app", "check_data"]
