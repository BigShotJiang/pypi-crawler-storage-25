"""Company management commands."""

from __future__ import annotations

import csv
import datetime
import re
from pathlib import Path
from typing import Annotated

import typer

from kctl_odoo.core.callbacks import AppContext
from kctl_odoo.core.exceptions import ConnectionError, RPCError
from kctl_odoo.core.resolve import resolve_id

app = typer.Typer(help="Manage Odoo companies.")

_PREFIX_TOKENS = {"CV", "CV.", "PT", "PT.", "IMP", "TRD", "BP", "BB", "BU", "KT"}


def _initials(name: str, max_len: int = 5) -> str:
    """Generate algorithmic company code from name."""
    cleaned = re.sub(r"[^A-Z\s]", " ", (name or "").upper())
    parts = [p for p in cleaned.split() if p and p not in _PREFIX_TOKENS and not p.isdigit()]
    return ("".join(p[0] for p in parts[:max_len]) if parts else "")[:max_len]


def _type_from_template_code(template_code: str) -> str:
    """Map template company_code to default type code."""
    return {"TPLI": "IMP", "TPLT": "TRD"}.get(template_code or "", "INT")


def _resolve_company_id(client: object, identifier: str) -> int:
    """Resolve company ID from numeric ID or name."""
    return resolve_id(client, "res.company", identifier, ilike=True, label="Company")  # type: ignore[arg-type]


@app.command("list")
def list_(
    ctx: typer.Context,
    limit: Annotated[int, typer.Option("--limit", "-l", help="Max results")] = 80,
) -> None:
    """List all companies in the Odoo instance.

    Shows ID, name, email, phone, currency, and parent company.
    In a multi-company setup this is useful for identifying company IDs.

    Examples:
        kctl-odoo companies list
        kctl-odoo companies list --limit 20 --json
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    companies = c.search_read(
        "res.company",
        domain=[],
        fields=["id", "name", "email", "phone", "currency_id", "parent_id"],
        limit=limit,
        order="id",
    )

    rows = []
    json_data = []
    for co in companies:
        currency = co.get("currency_id")
        currency_name = currency[1] if isinstance(currency, list) else str(currency or "-")
        parent = co.get("parent_id")
        parent_name = parent[1] if isinstance(parent, list) else str(parent or "-") if parent else "-"

        rows.append(
            [
                str(co["id"]),
                co["name"],
                co.get("email") or "-",
                co.get("phone") or "-",
                currency_name,
                parent_name,
            ]
        )
        json_data.append(
            {
                "id": co["id"],
                "name": co["name"],
                "email": co.get("email"),
                "phone": co.get("phone"),
                "currency": currency_name,
                "parent": parent_name,
            }
        )

    out.table(
        f"Companies ({len(companies)})",
        [("ID", "cyan"), ("Name", ""), ("Email", "dim"), ("Phone", "dim"), ("Currency", ""), ("Parent", "dim")],
        rows,
        data_for_json=json_data,
    )


@app.command()
def get(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Company ID or name")],
) -> None:
    """Show full details for a company by ID or name.

    Displays contact info, address, VAT, currency, parent/child links,
    and creation timestamps.

    Examples:
        kctl-odoo companies get 1
        kctl-odoo companies get "PT Maju Bersama"
        kctl-odoo companies get 1 --json
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    company_id = _resolve_company_id(c, identifier)
    records = c.read(
        "res.company",
        [company_id],
        fields=[
            "id",
            "name",
            "email",
            "phone",
            "website",
            "vat",
            "currency_id",
            "parent_id",
            "child_ids",
            "street",
            "city",
            "zip",
            "country_id",
            "create_date",
            "write_date",
        ],
    )

    if not records:
        out.error(f"Company not found: {identifier}")
        raise typer.Exit(1)

    co = records[0]
    currency = co.get("currency_id")
    currency_name = currency[1] if isinstance(currency, list) else str(currency or "-")
    parent = co.get("parent_id")
    parent_name = parent[1] if isinstance(parent, list) else "-" if not parent else str(parent)
    country = co.get("country_id")
    country_name = country[1] if isinstance(country, list) else str(country or "-")

    sections = [
        (
            "Company Info",
            [
                ("ID", str(co["id"])),
                ("Name", co["name"]),
                ("Email", co.get("email") or "-"),
                ("Phone", co.get("phone") or "-"),
                ("Website", co.get("website") or "-"),
                ("VAT", co.get("vat") or "-"),
                ("Currency", currency_name),
                ("Parent", parent_name),
                ("Children", str(len(co.get("child_ids", [])))),
            ],
        ),
        (
            "Address",
            [
                ("Street", co.get("street") or "-"),
                ("City", co.get("city") or "-"),
                ("ZIP", co.get("zip") or "-"),
                ("Country", country_name),
            ],
        ),
        (
            "Dates",
            [
                ("Created", str(co.get("create_date", ""))),
                ("Updated", str(co.get("write_date", ""))),
            ],
        ),
    ]

    out.detail(f"Company: {co['name']}", sections, data_for_json=co)


@app.command()
def create(
    ctx: typer.Context,
    name: Annotated[str, typer.Option("--name", "-n", help="Company name")],
    email: Annotated[str | None, typer.Option("--email", help="Email")] = None,
    currency: Annotated[str | None, typer.Option("--currency", help="Currency code (e.g. USD, EUR)")] = None,
    parent: Annotated[str | None, typer.Option("--parent", help="Parent company ID or name")] = None,
) -> None:
    """Create a new company in the Odoo instance.

    Optionally set currency and parent company to configure a subsidiary
    in a multi-company setup.

    Examples:
        kctl-odoo companies create --name "PT Anak Perusahaan"
        kctl-odoo companies create --name "Branch Office" --currency USD --parent 1
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    vals: dict = {"name": name}
    if email:
        vals["email"] = email
    if currency:
        currency_ids = c.search("res.currency", [("name", "=", currency.upper())])
        if not currency_ids:
            out.error(f"Currency not found: {currency}")
            raise typer.Exit(1)
        vals["currency_id"] = currency_ids[0]
    if parent:
        vals["parent_id"] = _resolve_company_id(c, parent)

    company_id = c.create("res.company", vals)
    out.success(f"Created company '{name}' (ID: {company_id})")


@app.command()
def update(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Company ID or name")],
    name: Annotated[str | None, typer.Option("--name", "-n", help="New name")] = None,
    email: Annotated[str | None, typer.Option("--email", help="Email")] = None,
    phone: Annotated[str | None, typer.Option("--phone", help="Phone")] = None,
    website: Annotated[str | None, typer.Option("--website", help="Website")] = None,
) -> None:
    """Update fields on an existing company.

    Accepts company ID or name as the identifier. Only the flags you
    provide are changed; other fields are left untouched.

    Examples:
        kctl-odoo companies update 1 --name "PT Maju Jaya"
        kctl-odoo companies update "PT Maju" --phone "+62-21-1234567" --website https://ptmaju.id
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    company_id = _resolve_company_id(c, identifier)
    vals: dict = {}
    if name is not None:
        vals["name"] = name
    if email is not None:
        vals["email"] = email
    if phone is not None:
        vals["phone"] = phone
    if website is not None:
        vals["website"] = website

    if not vals:
        out.warn("No fields to update")
        return

    c.write("res.company", [company_id], vals)
    out.success(f"Updated company {identifier} (ID: {company_id})")


@app.command()
def users(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Company ID or name")],
    limit: Annotated[int, typer.Option("--limit", "-l", help="Max results")] = 80,
) -> None:
    """List all users who have access to a company.

    Shows which users have the company in their allowed companies list
    and highlights whose current (default) company this is.

    Examples:
        kctl-odoo companies users 1
        kctl-odoo companies users "PT Maju" --limit 50
        kctl-odoo companies users 1 --json
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    company_id = _resolve_company_id(c, identifier)
    company_data = c.read("res.company", [company_id], fields=["name"])
    company_name = company_data[0]["name"] if company_data else str(company_id)

    user_records = c.search_read(
        "res.users",
        domain=[("company_ids", "in", [company_id])],
        fields=["id", "login", "name", "email", "active", "company_id"],
        limit=limit,
        order="login",
    )

    rows = []
    json_data = []
    for u in user_records:
        current_co = u.get("company_id")
        is_current = current_co[0] == company_id if isinstance(current_co, list) else False
        status = "[green]active[/green]" if u.get("active") else "[red]inactive[/red]"
        current_label = "[cyan]current[/cyan]" if is_current else ""

        rows.append([str(u["id"]), u["login"], u["name"], u.get("email") or "-", status, current_label])
        json_data.append(
            {
                "id": u["id"],
                "login": u["login"],
                "name": u["name"],
                "email": u.get("email"),
                "active": u.get("active"),
                "is_current_company": is_current,
            }
        )

    out.table(
        f"Users in '{company_name}' ({len(user_records)})",
        [("ID", "cyan"), ("Login", ""), ("Name", ""), ("Email", "dim"), ("Status", ""), ("Current Co.", "")],
        rows,
        data_for_json=json_data,
    )


@app.command("switch")
def switch_company(
    ctx: typer.Context,
    user_id: Annotated[int, typer.Argument(help="User ID")],
    company_id: Annotated[int, typer.Argument(help="Target company ID")],
) -> None:
    """Switch a user's active (default) company.

    The target company must already be in the user's allowed companies list.
    Use 'kctl-odoo companies users <company>' to check current assignments.

    Examples:
        kctl-odoo companies switch 7 2
        kctl-odoo companies switch 7 3
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    # Verify user exists
    user_data = c.read("res.users", [user_id], fields=["login", "company_ids"])
    if not user_data:
        out.error(f"User not found: {user_id}")
        raise typer.Exit(1)

    # Verify company is in user's allowed companies
    allowed = user_data[0].get("company_ids", [])
    if company_id not in allowed:
        out.error(f"Company {company_id} is not in user's allowed companies: {allowed}")
        raise typer.Exit(1)

    c.write("res.users", [user_id], {"company_id": company_id})
    out.success(f"Switched user {user_data[0]['login']} (ID: {user_id}) to company ID {company_id}")


def _run_setup(
    c: object,
    out: object,
    *,
    name: str,
    template_id: int,
    street: str | None = None,
    city: str | None = None,
    phone: str | None = None,
    email: str | None = None,
    npwp: str | None = None,
    warehouse_prefix: str | None = None,
    skip_warehouses: bool = False,
    skip_fiscal_positions: bool = False,
    skip_extra_journals: bool = False,
    skip_report_formats: bool = False,
    dry_run: bool = False,
    type_code: str | None = None,
    subgroup_code: str | None = None,
    commodity_code: str | None = None,
    business_year: int | None = None,
    company_code: str | None = None,
    bank: list[str] | None = None,
) -> dict | None:
    """Call CompanyOnboardingService.provision() via JSON-RPC."""
    # Verify company_management module is installed (renamed from
    # company_onboarding in 18.0.8.0.0).
    installed = c.search(
        "ir.module.module",
        [("name", "in", ["company_management", "company_onboarding"]), ("state", "=", "installed")],
    )
    if not installed:
        out.error("Module 'company_management' is not installed. Install it first.")
        raise typer.Exit(1)

    company_vals = {"name": name}
    if street:
        company_vals["street"] = street
    if city:
        company_vals["city"] = city
    if phone:
        company_vals["phone"] = phone
    if email:
        company_vals["email"] = email
    if npwp:
        company_vals["npwp"] = npwp
    if warehouse_prefix:
        company_vals["warehouse_code_prefix"] = warehouse_prefix

    # Resolve classification codes to record IDs
    if type_code is None:
        template_data = c.execute_kw("res.company", "read", [[template_id], ["company_code"]])
        tpl_code = (template_data[0].get("company_code") if template_data else "") or ""
        type_code = _type_from_template_code(tpl_code)

    type_recs = c.execute_kw(
        "res.company.type",
        "search_read",
        [[("code", "=", type_code)], ["id"]],
        {"limit": 1},
    )
    if not type_recs:
        out.error(f"Unknown company type code: {type_code}")
        raise typer.Exit(1)
    company_vals["company_type_id"] = type_recs[0]["id"]

    if subgroup_code:
        sg_recs = c.execute_kw(
            "res.company.subgroup",
            "search_read",
            [[("code", "=", subgroup_code)], ["id"]],
            {"limit": 1},
        )
        if not sg_recs:
            out.error(f"Unknown sub-group code: {subgroup_code}")
            raise typer.Exit(1)
        company_vals["subgroup_id"] = sg_recs[0]["id"]

    if commodity_code:
        cm_recs = c.execute_kw(
            "res.company.commodity",
            "search_read",
            [[("code", "=", commodity_code)], ["id"]],
            {"limit": 1},
        )
        if not cm_recs:
            out.error(f"Unknown commodity code: {commodity_code}")
            raise typer.Exit(1)
        company_vals["commodity_id"] = cm_recs[0]["id"]

    company_vals["business_year"] = business_year if business_year is not None else (datetime.date.today().year % 100)
    company_vals["company_code"] = company_code or _initials(name)

    # Bank sub-accounts (--bank SUFFIX:NAME, repeatable)
    bank_lines = []
    for entry in bank or []:
        if ":" not in entry:
            out.error(f"Invalid --bank entry: {entry!r}, expected SUFFIX:NAME")
            raise typer.Exit(1)
        suffix, bank_name = entry.split(":", 1)
        bank_lines.append({"code_suffix": suffix.strip(), "bank_name": bank_name.strip()})
    if bank_lines:
        company_vals["bank_account_lines"] = bank_lines

    options = {
        "clone_fiscal_positions": not skip_fiscal_positions,
        "clone_warehouses": not skip_warehouses,
        "clone_extra_journals": not skip_extra_journals,
        "clone_report_formats": not skip_report_formats,
    }

    if dry_run:
        out.info(f"[DRY RUN] Would create company '{name}' from template ID {template_id}")
        out.info(f"  Vals: {company_vals}")
        out.info(f"  Options: {options}")
        return None

    result = c.execute_kw(
        "company.onboarding.wizard",
        "action_provision_from_cli",
        [company_vals, template_id, options],
    )

    # Display results
    out.success(f"Created company '{result['company_name']}' (ID: {result['company_id']})")
    for step in result.get("steps", []):
        icon = {"ok": "✓", "skipped": "⊘", "error": "✗"}.get(step["status"], "?")
        style = "green" if step["status"] == "ok" else ("yellow" if step["status"] == "skipped" else "red")
        out.console.print(f"  [{style}]{icon}[/{style}] {step['name']}: {step['detail']}")

    # Validation gate summary
    validation = result.get("validation") or {}
    if validation:
        out.console.print()
        failed = validation.get("failed", [])
        if validation.get("all_green") or not failed:
            out.console.print("[green]✓ All validations passed — company is 100% ready.[/green]")
        else:
            out.console.print(f"[yellow]⚠ {len(failed)} validation issue(s) remain:[/yellow]")
            for item in failed[:10]:
                check = item.get("check", "")
                msg = item.get("message", "")
                out.console.print(f"  [yellow]✗ {check}: {msg}[/yellow]")
            out.console.print(f"\n[dim]Run: kctl-odoo companies validate-company -c {result['company_id']} --fix[/dim]")

    out.console.print()
    out.console.print("[dim]Next steps:[/dim]")
    out.console.print("  1. Assign users:  kctl-odoo roles assign <login> --roles finance_user")
    out.console.print("  2. Configure bank: Settings → Companies → Giro/Cek Accounts")
    out.console.print("  3. Set tax office: Settings → Companies → Tax Settings")

    return result


@app.command()
def setup(
    ctx: typer.Context,
    name: Annotated[str, typer.Option("--name", "-n", help="Company name")],
    template: Annotated[str, typer.Option("--template", "-t", help="Template company ID or name")],
    street: Annotated[str | None, typer.Option(help="Street address")] = None,
    city: Annotated[str | None, typer.Option(help="City")] = None,
    phone: Annotated[str | None, typer.Option(help="Phone")] = None,
    email: Annotated[str | None, typer.Option(help="Email")] = None,
    npwp: Annotated[str | None, typer.Option(help="NPWP (Indonesian Tax ID)")] = None,
    warehouse_prefix: Annotated[
        str | None, typer.Option("--warehouse-prefix", help="3-char warehouse code prefix")
    ] = None,
    type_code: Annotated[
        str | None,
        typer.Option("--type", "-T", help="Company type code: IMP, TRD, or INT (default: from template)"),
    ] = None,
    subgroup_code: Annotated[
        str | None,
        typer.Option("--subgroup", "-G", help="Sub-group code: SQ, TPP1-4, or TIER1 (required)"),
    ] = None,
    commodity_code: Annotated[
        str | None,
        typer.Option("--commodity", help="Commodity code: GRL, ONI, FRT, etc. (optional)"),
    ] = None,
    business_year: Annotated[
        int | None,
        typer.Option("--year", help="Business year, 2-digit (default: current year mod 100)"),
    ] = None,
    company_code: Annotated[
        str | None,
        typer.Option("--code", help="Company code, e.g. GAS (default: algorithmic initials from name)"),
    ] = None,
    bank: Annotated[
        list[str] | None,
        typer.Option(
            "--bank",
            help="Bank sub-account in format 'SUFFIX:NAME', e.g. '01:BCA 714.5130972' (repeatable)",
        ),
    ] = None,
    skip_warehouses: Annotated[bool, typer.Option("--skip-warehouses", help="Skip warehouse cloning")] = False,
    skip_fiscal_positions: Annotated[
        bool, typer.Option("--skip-fiscal-positions", help="Skip fiscal position cloning")
    ] = False,
    skip_extra_journals: Annotated[
        bool, typer.Option("--skip-extra-journals", help="Skip extra journal cloning")
    ] = False,
    skip_report_formats: Annotated[
        bool, typer.Option("--skip-report-formats", help="Skip report format provisioning")
    ] = False,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Preview without creating")] = False,
) -> None:
    """Create and provision a new company from a template — 100% validated in one shot.

    Installs l10n_id CoA (journals + taxes), clones warehouses/fiscal positions/journals
    from the template, applies the COA profile, sets classifications (type/sub-group/
    commodity/year/code), grants user groups, activates foreign currencies, ensures
    UoMs, sets PPN tax repartition, then runs validate_company(fix=True).

    Smart defaults: --type derived from template (TPLI→IMP, TPLT→TRD),
    --year from current year, --code from name initials. Only --subgroup is required.

    Requires the company_management module to be installed.

    Examples:
        kctl-odoo companies setup -n "CV NAVIRA BUAH INTERNUSA" -t 338 -G SQ --commodity FRT
        kctl-odoo companies setup -n "CV X" -t "TEMPLATE TPP IMPORT" -G TPP1 --code APK
        kctl-odoo companies setup -n "CV Test" -t 2 -G SQ --dry-run
    """
    actx: AppContext = ctx.obj
    template_id = _resolve_company_id(actx.client, template)

    _run_setup(
        actx.client,
        actx.output,
        name=name,
        template_id=template_id,
        street=street,
        city=city,
        phone=phone,
        email=email,
        npwp=npwp,
        warehouse_prefix=warehouse_prefix,
        skip_warehouses=skip_warehouses,
        skip_fiscal_positions=skip_fiscal_positions,
        skip_extra_journals=skip_extra_journals,
        skip_report_formats=skip_report_formats,
        dry_run=dry_run,
        type_code=type_code,
        subgroup_code=subgroup_code,
        commodity_code=commodity_code,
        business_year=business_year,
        company_code=company_code,
        bank=bank,
    )


@app.command("setup-batch")
def setup_batch(
    ctx: typer.Context,
    csv_file: Annotated[Path, typer.Argument(help="CSV file with columns: name,street,city,npwp,warehouse_prefix")],
    template: Annotated[str, typer.Option("--template", "-t", help="Template company ID or name")],
    skip_warehouses: Annotated[bool, typer.Option("--skip-warehouses", help="Skip warehouse cloning")] = False,
    skip_report_formats: Annotated[
        bool, typer.Option("--skip-report-formats", help="Skip report format provisioning")
    ] = False,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Preview without creating")] = False,
) -> None:
    """Batch-create companies from a CSV file.

    CSV format (header required):
        name,street,city,npwp,warehouse_prefix
        CV Baru Import,Jl. Raya 1,Surabaya,01.234.567.8-901.000,BRI
        CV Lain Import,Jl. Lain 2,Jakarta,02.345.678.9-012.000,LNI

    Requires the company_management module to be installed.

    Examples:
        kctl-odoo companies setup-batch companies.csv --template 2
        kctl-odoo companies setup-batch companies.csv -t "CV Sumber Pangan" --dry-run
    """
    actx: AppContext = ctx.obj
    out = actx.output

    if not csv_file.exists():
        out.error(f"File not found: {csv_file}")
        raise typer.Exit(1)

    template_id = _resolve_company_id(actx.client, template)

    with csv_file.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    if not rows:
        out.warn("CSV file is empty")
        return

    out.info(f"Processing {len(rows)} companies from {csv_file.name}")
    out.console.print()

    created, failed = 0, 0
    for i, row in enumerate(rows, 1):
        company_name = row.get("name", "").strip()
        if not company_name:
            out.warn(f"Row {i}: skipping — empty name")
            continue

        out.console.rule(f"[bold]{i}/{len(rows)}: {company_name}")
        try:
            result = _run_setup(
                actx.client,
                out,
                name=company_name,
                template_id=template_id,
                street=row.get("street", "").strip() or None,
                city=row.get("city", "").strip() or None,
                phone=row.get("phone", "").strip() or None,
                email=row.get("email", "").strip() or None,
                npwp=row.get("npwp", "").strip() or None,
                warehouse_prefix=row.get("warehouse_prefix", "").strip() or None,
                skip_warehouses=skip_warehouses,
                skip_report_formats=skip_report_formats,
                dry_run=dry_run,
            )
            if result:
                created += 1
        except (typer.Exit, RPCError, ConnectionError, KeyError, ValueError, TypeError) as exc:
            out.error(f"Failed: {company_name} — {exc}")
            failed += 1

        out.console.print()

    out.console.rule("[bold]Summary")
    out.info(f"Created: {created}, Failed: {failed}, Total: {len(rows)}")


@app.command("bootstrap-baseline")
def bootstrap_baseline(
    ctx: typer.Context,
    company: Annotated[str, typer.Argument(help="Company ID or name (template or existing)")],
    all_companies: Annotated[bool, typer.Option("--all", help="Run on every company")] = False,
) -> None:
    """Retro-fit baseline setup on existing companies.

    Idempotent. For each target company, ensures:
      - At least one stock.warehouse exists (creates HDQ if missing)
      - At least one operating.unit exists (creates HDQ if missing — OCA optional)
      - Bank journals have default_account_id set

    Used to backfill the template company and pre-existing companies that
    were created before company_management was installed. Calls
    company.onboarding.service.bootstrap_baseline() server-side, which uses
    sudo() to bypass the stock_request and operating_unit access groups.

    Examples:
        kctl-odoo companies bootstrap-baseline 338
        kctl-odoo companies bootstrap-baseline _TEMPLATE_TPP_IMPORT
        kctl-odoo companies bootstrap-baseline --all _
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    installed = c.search(
        "ir.module.module",
        [("name", "in", ["company_management", "company_onboarding"]), ("state", "=", "installed")],
    )
    if not installed:
        out.error("Module 'company_management' is not installed.")
        raise typer.Exit(1)

    if all_companies:
        ids = [r["id"] for r in c.search_read("res.company", [], fields=["id"], order="id")]
    else:
        ids = [_resolve_company_id(c, company)]

    rows = []
    json_data = []
    for cid in ids:
        comp = c.read("res.company", [cid], fields=["id", "name"])
        cname = comp[0]["name"] if comp else f"id={cid}"
        try:
            result = c.execute_kw(
                "company.onboarding.wizard",
                "action_bootstrap_baseline_from_cli",
                [cid],
            )
            status = result.get("status", "?") if isinstance(result, dict) else "?"
            detail = result.get("detail", "") if isinstance(result, dict) else str(result)
        except (RPCError, ConnectionError) as e:
            status = "error"
            detail = str(e)
        rows.append([str(cid), cname, status, detail])
        json_data.append({"id": cid, "name": cname, "status": status, "detail": detail})
        icon = {"ok": "[green]OK[/green]", "error": "[red]ERR[/red]"}.get(status, status)
        out.console.print(f"  {icon} [{cid}] {cname}: {detail}")

    if actx.json_mode:
        out.raw_json(json_data)


@app.command("validate-company")
def validate_company_cmd(
    ctx: typer.Context,
    company_id: Annotated[str, typer.Option("--company-id", "-c", help="Company ID or name")],
    fix: Annotated[
        bool, typer.Option("--fix", help="Auto-fix issues before validation (COA profile + products + partners)")
    ] = False,
) -> None:
    """Run ALL 20 validators and produce a company health report card.

    Use --fix to auto-fix what can be fixed before validation:
    applies COA profile, fixes products, fixes partners, then validates.

    Examples:
        kctl-odoo companies validate-company -c 339
        kctl-odoo companies validate-company -c 339 --fix
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    company_id = _resolve_company_id(c, company_id)

    result = c.execute_kw("company.coa.profile.applier", "validate_company", [company_id], {"fix": fix})

    if not result or "error" in result:
        out.error(result.get("error", "Unknown error") if result else "No result")
        raise typer.Exit(1)

    fix_summary = result.get("fix_summary", {})
    if fix_summary:
        out.success("Auto-fix applied:")
        coa = fix_summary.get("coa_profile", {})
        if coa:
            parts = []
            for k in (
                "accounts_created",
                "accounts_renamed",
                "partner_defaults",
                "categories_fixed",
                "journals_fixed",
                "bank_journals_fixed",
            ):
                v = coa.get(k, 0)
                if v:
                    parts.append(f"{k}={v}")
            if parts:
                out.info(f"  COA profile: {', '.join(parts)}")
        prod = fix_summary.get("products", {})
        if prod:
            parts = [f"{k}={v}" for k, v in prod.items() if v]
            if parts:
                out.info(f"  Products: {', '.join(parts)}")
        part = fix_summary.get("partners", {})
        if part:
            parts = [f"{k}={v}" for k, v in part.items() if v]
            if parts:
                out.info(f"  Partners: {', '.join(parts)}")
        out.console.print()

    out.console.print(f"[bold]Company Health Report: {result['company']}[/bold]")
    out.console.print("═" * 55)

    for s in result.get("sections", []):
        total = s["passed"] + s["failed"]
        if s["status"] == "PASS":
            out.console.print(f"  [green]✓[/green] {s['label']:<16} {s['passed']}/{total} passed")
        elif s["status"] == "ERROR":
            out.console.print(f"  [red]✗[/red] {s['label']:<16} ERROR")
        else:
            out.console.print(f"  [red]✗[/red] {s['label']:<16} {s['passed']}/{total} passed ({s['failed']} issues)")

    out.console.print("─" * 55)

    tp = result.get("total_passed", 0)
    tf = result.get("total_failed", 0)
    if tf == 0:
        out.success(f"TOTAL: {tp}/{tp + tf} PASSED ✓")
    else:
        out.error(f"TOTAL: {tp}/{tp + tf} passed, {tf} FAILED")
        out.console.print()
        for issue in result.get("issues", []):
            out.console.print(f"  [red]✗[/red] {issue}")
        if not fix:
            out.console.print()
            out.info("Hint: use --fix to auto-apply corrections")


@app.command("validate-products")
def validate_products_cmd(
    ctx: typer.Context,
    company_id: Annotated[str, typer.Option("--company-id", "-c", help="Company ID or name")],
    fix: Annotated[bool, typer.Option("--fix", help="Auto-fix issues")] = False,
) -> None:
    """Validate product setup: taxes, tracking, UoM, purchase method, category.

    Examples:
        kctl-odoo companies validate-products -c 361
        kctl-odoo companies validate-products -c 361 --fix
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    company_id = _resolve_company_id(c, company_id)

    if fix:
        result = c.execute_kw("company.coa.profile.applier", "fix_products", [company_id])
        out.success("Products fixed:")
        for k, v in (result or {}).items():
            out.info(f"  {k}: {v}")

    result = c.execute_kw("company.coa.profile.applier", "validate_products", [company_id])

    if not result or "error" in result:
        out.error(result.get("error", "Unknown error") if result else "No response")
        raise typer.Exit(1)

    out.info(f"Product Validation: {result['company']} (id={result['company_id']})")
    out.info(f"Total products: {result['total_products']}")
    out.info("─" * 50)

    for issue in result.get("issues", []):
        out.console.print(f"  [red]✗[/red] {issue}")

    p = result.get("passed", 0)
    f = result.get("failed", 0)
    if f == 0:
        out.success(f"RESULT: {p}/{p + f} PASSED ✓")
    else:
        out.error(f"RESULT: {p}/{p + f} passed, {f} FAILED")
        if not fix:
            out.info("Hint: use --fix to auto-apply corrections")


@app.command("validate-partners")
def validate_partners_cmd(
    ctx: typer.Context,
    company_id: Annotated[str, typer.Option("--company-id", "-c", help="Company ID or name")],
    fix: Annotated[bool, typer.Option("--fix", help="Auto-fix issues")] = False,
) -> None:
    """Validate partner setup: currency, AR/AP, duplicates.

    Examples:
        kctl-odoo companies validate-partners -c 361
        kctl-odoo companies validate-partners -c 361 --fix
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    company_id = _resolve_company_id(c, company_id)

    if fix:
        result = c.execute_kw("company.coa.profile.applier", "fix_partners", [company_id])
        out.success("Partners fixed:")
        for k, v in (result or {}).items():
            out.info(f"  {k}: {v}")

    result = c.execute_kw("company.coa.profile.applier", "validate_partners", [company_id])

    if not result or "error" in result:
        out.error(result.get("error", "Unknown error") if result else "No response")
        raise typer.Exit(1)

    out.info(f"Partner Validation: {result['company']} (id={result['company_id']})")
    out.info(f"Total partners: {result['total_partners']}")
    out.info("─" * 50)

    for issue in result.get("issues", []):
        out.console.print(f"  [red]✗[/red] {issue}")

    p = result.get("passed", 0)
    f = result.get("failed", 0)
    if f == 0:
        out.success(f"RESULT: {p}/{p + f} PASSED ✓")
    else:
        out.error(f"RESULT: {p}/{p + f} passed, {f} FAILED")
        if not fix:
            out.info("Hint: use --fix to auto-apply corrections")


@app.command("validate-journals")
def validate_journals_cmd(
    ctx: typer.Context,
    company_id: Annotated[str, typer.Option("--company-id", "-c", help="Company ID or name")],
    fix: Annotated[
        bool, typer.Option("--fix", help="Auto-fix via COA profile (journal defaults + bank accounts)")
    ] = False,
) -> None:
    """Validate journal configuration for a company.

    Checks: default accounts, journal types, duplicate codes, missing journals.
    Use --fix to apply COA profile corrections (sets journal defaults + bank account types).

    Examples:
        kctl-odoo companies validate-journals -c 364
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    company_id = _resolve_company_id(c, company_id)

    if fix:
        out.info("Applying fixes...")
        fix_result = c.execute_kw("company.coa.profile.applier", "apply", [company_id])
        out.success("COA profile applied:")
        for k, v in (fix_result or {}).items():
            out.info(f"  {k}: {v}")

    result = c.execute_kw("company.coa.profile.applier", "validate_journals", [company_id])

    if not result or "error" in result:
        out.error(result.get("error", "Unknown error") if result else "No result")
        raise typer.Exit(1)

    out.info(f"Journal Validation: {result['company']} (id={result['company_id']})")
    out.info(f"Total journals: {result['total_journals']} — {result.get('by_type', {})}")
    out.info("─" * 50)

    rows = []
    for j in result.get("journals", []):
        rows.append([j["code"], j["name"], j["type"], j.get("default_account") or "-", j.get("currency", "IDR")])

    out.table(
        "Journals",
        [("Code", "cyan"), ("Name", ""), ("Type", ""), ("Default Account", ""), ("Currency", "")],
        rows,
    )

    for issue in result.get("issues", []):
        out.console.print(f"  [red]✗[/red] {issue}")

    passed = result.get("passed", 0)
    failed = result.get("failed", 0)
    if failed == 0:
        out.success(f"RESULT: {passed}/{passed + failed} PASSED ✓")
    else:
        out.error(f"RESULT: {passed}/{passed + failed} passed, {failed} FAILED")
        if not fix:
            out.info("Hint: use --fix to auto-apply corrections")


@app.command("validate-banks")
def validate_banks_cmd(
    ctx: typer.Context,
    company_id: Annotated[str, typer.Option("--company-id", "-c", help="Company ID or name")],
    fix: Annotated[bool, typer.Option("--fix", help="Auto-fix via COA profile")] = False,
) -> None:
    """Validate bank/cash journal setup for reconciliation.

    Checks: suspense != bank account, outstanding accounts reconcile=True,
    suspense != outstanding, all accounts are distinct.

    Examples:
        kctl-odoo companies validate-banks -c 364
        kctl-odoo companies validate-banks -c 364 --fix
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    company_id = _resolve_company_id(c, company_id)

    if fix:
        out.info("Applying fixes...")
        fix_result = c.execute_kw("company.coa.profile.applier", "apply", [company_id])
        out.success("COA profile applied:")
        for k, v in (fix_result or {}).items():
            out.info(f"  {k}: {v}")

    result = c.execute_kw("company.coa.profile.applier", "validate_banks", [company_id])

    if not result or "error" in result:
        out.error(result.get("error", "Unknown error") if result else "No result")
        raise typer.Exit(1)

    out.info(f"Bank Validation: {result['company']} (id={result['company_id']})")
    out.info(f"Bank/Cash journals: {result['total_bank_journals']}")
    out.info("─" * 50)

    for j in result.get("journals", []):
        status_color = "green" if j["status"] == "PASS" else "red"
        out.console.print(f"  [{status_color}]{j['status']}[/{status_color}] {j['code']} {j['name']}")
        out.console.print(f"       Bank Account:         {j.get('bank_account', '-')}")
        out.console.print(f"       Suspense:             {j.get('suspense', '-')}")
        out.console.print(f"       Outstanding Receipts: {j.get('outstanding_receipts', '-')}")
        out.console.print(f"       Outstanding Payments: {j.get('outstanding_payments', '-')}")
        for iss in j.get("issues", []):
            out.console.print(f"       [red]✗ {iss}[/red]")

    # Accurate comparison
    acc_comp = result.get("accurate_comparison", [])
    if acc_comp:
        out.info("─" * 50)
        out.info("Accurate Bank Accounts:")
        for ac in acc_comp:
            color = "green" if ac["status"] == "MATCH" else "red"
            out.console.print(f"  [{color}]{ac['status']}[/{color}] {ac['code']} {ac['name']}")

    out.info("─" * 50)
    for issue in result.get("issues", []):
        out.console.print(f"  [red]✗[/red] {issue}")

    passed = result.get("passed", 0)
    failed = result.get("failed", 0)
    if failed == 0:
        out.success(f"RESULT: {passed}/{passed + failed} PASSED ✓")
    else:
        out.error(f"RESULT: {passed}/{passed + failed} passed, {failed} FAILED")
        if not fix:
            out.info("Hint: use --fix to auto-apply corrections")


@app.command("validate-taxes")
def validate_taxes_cmd(
    ctx: typer.Context,
    company_id: Annotated[str, typer.Option("--company-id", "-c", help="Company ID or name")],
    fix: Annotated[bool, typer.Option("--fix", help="Auto-fix via COA profile")] = False,
) -> None:
    """Validate tax configuration for a company.

    Checks: required taxes exist, repartition accounts set (PPN Masukan/Keluaran),
    Accurate tax mappings complete.

    Examples:
        kctl-odoo companies validate-taxes -c 339
        kctl-odoo companies validate-taxes -c 339 --fix
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    company_id = _resolve_company_id(c, company_id)

    if fix:
        out.info("Applying fixes...")
        fix_result = c.execute_kw("company.coa.profile.applier", "apply", [company_id])
        out.success("COA profile applied:")
        for k, v in (fix_result or {}).items():
            out.info(f"  {k}: {v}")

    result = c.execute_kw("company.coa.profile.applier", "validate_taxes", [company_id])

    if not result or "error" in result:
        out.error(result.get("error", "Unknown error") if result else "No result")
        raise typer.Exit(1)

    out.info(f"Tax Validation: {result['company']} (id={result['company_id']})")
    out.info(f"Total taxes: {result['total_taxes']}")
    out.info("─" * 50)

    rows = []
    for t in result.get("taxes", []):
        status_icon = "✓" if t["status"] == "PASS" else "✗"
        rows.append(
            [
                status_icon,
                t["name"],
                f"{t['amount']}%",
                t["type"],
                ", ".join(str(a) for a in t.get("accounts", []) if a),
            ]
        )

    out.table(
        "Taxes",
        [("", ""), ("Name", ""), ("Rate", ""), ("Type", ""), ("Repartition Accounts", "")],
        rows,
    )

    # Accurate comparison
    acc_comp = result.get("accurate_comparison", [])
    if acc_comp:
        out.info("─" * 50)
        out.info("Accurate Tax Mappings:")
        for ac in acc_comp:
            color = "green" if ac["status"] == "MATCH" else "red"
            out.console.print(f"  [{color}]{ac['status']}[/{color}] {ac['accurate_name']} → {ac['odoo_tax']}")

    out.info("─" * 50)
    for issue in result.get("issues", []):
        out.console.print(f"  [red]✗[/red] {issue}")

    passed = result.get("passed", 0)
    failed = result.get("failed", 0)
    if failed == 0:
        out.success(f"RESULT: {passed}/{passed + failed} PASSED ✓")
    else:
        out.error(f"RESULT: {passed}/{passed + failed} passed, {failed} FAILED")
        if not fix:
            out.info("Hint: use --fix to auto-apply corrections")


@app.command("validate-categories")
def validate_categories_cmd(
    ctx: typer.Context,
    company_id: Annotated[str, typer.Option("--company-id", "-c", help="Company ID or name")],
    fix: Annotated[bool, typer.Option("--fix", help="Auto-fix via COA profile")] = False,
) -> None:
    """Validate product category configuration for a company.

    Checks: stock valuation account (1101), GRNI account (2104), Barang Dalam
    Pengiriman (1101.09), cost method (average), valuation (real_time).

    Examples:
        kctl-odoo companies validate-categories -c 339
        kctl-odoo companies validate-categories -c 339 --fix
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    company_id = _resolve_company_id(c, company_id)

    if fix:
        out.info("Applying fixes...")
        fix_result = c.execute_kw("company.coa.profile.applier", "apply", [company_id])
        out.success("COA profile applied:")
        for k, v in (fix_result or {}).items():
            out.info(f"  {k}: {v}")

    result = c.execute_kw("company.coa.profile.applier", "validate_categories", [company_id])

    if not result or "error" in result:
        out.error(result.get("error", "Unknown error") if result else "No result")
        raise typer.Exit(1)

    out.info(f"Category Validation: {result['company']} (id={result['company_id']})")
    out.info(f"Total categories: {result['total_categories']}")
    out.info("─" * 50)

    for cat in result.get("categories", []):
        status_color = "green" if cat["status"] == "PASS" else "red"
        out.console.print(f"  [{status_color}]{cat['status']}[/{status_color}] {cat['name']}")
        for iss in cat.get("issues", []):
            out.console.print(f"       [red]✗ {iss}[/red]")

    out.info("─" * 50)
    for issue in result.get("issues", []):
        out.console.print(f"  [red]✗[/red] {issue}")

    passed = result.get("passed", 0)
    failed = result.get("failed", 0)
    if failed == 0:
        out.success(f"RESULT: {passed}/{passed + failed} PASSED ✓")
    else:
        out.error(f"RESULT: {passed}/{passed + failed} passed, {failed} FAILED")
        if not fix:
            out.info("Hint: use --fix to auto-apply corrections")


@app.command("validate-uom")
def validate_uom_cmd(
    ctx: typer.Context,
    company_id: Annotated[str, typer.Option("--company-id", "-c", help="Company ID or name")],
    fix: Annotated[bool, typer.Option("--fix", help="Auto-fix products (UoM + tracking)")] = False,
) -> None:
    """Validate UoM configuration for a company.

    Checks: UoM group enabled, required UoMs (KG, TON, CTN, PCS), no duplicates
    in wrong categories, all physical products have UoM set.

    Examples:
        kctl-odoo companies validate-uom -c 339
        kctl-odoo companies validate-uom -c 339 --fix
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    company_id = _resolve_company_id(c, company_id)

    if fix:
        out.info("Applying fixes...")
        fix_result = c.execute_kw("company.coa.profile.applier", "fix_products", [company_id])
        out.success("Product fixes applied:")
        for k, v in (fix_result or {}).items():
            out.info(f"  {k}: {v}")

    result = c.execute_kw("company.coa.profile.applier", "validate_uom", [company_id])

    if not result or "error" in result:
        out.error(result.get("error", "Unknown error") if result else "No result")
        raise typer.Exit(1)

    out.info(f"UoM Validation: {result['company']} (id={result['company_id']})")
    out.info(f"Total physical products: {result['total_products']}")
    out.info("─" * 50)

    rows = []
    for u in result.get("uoms", []):
        rows.append([u["name"], u.get("category", "-"), u["status"]])

    out.table(
        "Required UoMs",
        [("Name", "cyan"), ("Category", ""), ("Status", "")],
        rows,
    )

    # Accurate comparison
    acc_comp = result.get("accurate_comparison", [])
    if acc_comp:
        out.info("─" * 50)
        out.info("Accurate UoM Comparison (sample):")
        for ac in acc_comp[:20]:
            color = "green" if ac["status"] == "MATCH" else "red"
            out.console.print(
                f"  [{color}]{ac['status']}[/{color}] {ac['item']}: {ac['accurate_uom']} → {ac['odoo_uom']}"
            )

    out.info("─" * 50)
    for issue in result.get("issues", []):
        out.console.print(f"  [red]✗[/red] {issue}")

    passed = result.get("passed", 0)
    failed = result.get("failed", 0)
    if failed == 0:
        out.success(f"RESULT: {passed}/{passed + failed} PASSED ✓")
    else:
        out.error(f"RESULT: {passed}/{passed + failed} passed, {failed} FAILED")
        if not fix:
            out.info("Hint: use --fix to auto-apply corrections")


@app.command("validate-users")
def validate_users_cmd(
    ctx: typer.Context,
    company_id: Annotated[str, typer.Option("--company-id", "-c", help="Company ID or name")],
) -> None:
    """Validate user/role configuration for a company.

    Checks: operating unit assignment, Internal User group, purchase user has
    UoM group, employee record company matches.

    Examples:
        kctl-odoo companies validate-users -c 339
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    company_id = _resolve_company_id(c, company_id)

    result = c.execute_kw("company.coa.profile.applier", "validate_users", [company_id])

    if not result or "error" in result:
        out.error(result.get("error", "Unknown error") if result else "No result")
        raise typer.Exit(1)

    out.info(f"User Validation: {result['company']} (id={result['company_id']})")
    out.info(f"Total users: {result['total_users']}")
    out.info("─" * 50)

    rows = []
    for u in result.get("users", []):
        status_icon = "✓" if u["status"] == "PASS" else "✗"
        ou = u.get("operating_units", "-")
        rows.append([status_icon, u["login"], u["name"][:30], str(u.get("groups_count", 0)), ou[:30]])

    out.table(
        "Users",
        [("", ""), ("Login", "cyan"), ("Name", ""), ("Groups", ""), ("Operating Units", "")],
        rows,
    )

    for issue in result.get("issues", []):
        out.console.print(f"  [red]✗[/red] {issue}")

    passed = result.get("passed", 0)
    failed = result.get("failed", 0)
    if failed == 0:
        out.success(f"RESULT: {passed}/{passed + failed} PASSED ✓")
    else:
        out.error(f"RESULT: {passed}/{passed + failed} passed, {failed} FAILED")
        out.info("Hint: assign operating units via kctl-odoo roles sync")


@app.command("validate-currencies")
def validate_currencies_cmd(
    ctx: typer.Context,
    company_id: Annotated[str, typer.Option("--company-id", "-c", help="Company ID or name")],
    fix: Annotated[bool, typer.Option("--fix", help="Auto-fix via baseline setup")] = False,
) -> None:
    """Validate currency setup for a company.

    Checks: IDR is company currency, CNY/USD/THB active with recent rates,
    FX gain/loss accounts configured.

    Examples:
        kctl-odoo companies validate-currencies -c 339
        kctl-odoo companies validate-currencies -c 339 --fix
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    company_id = _resolve_company_id(c, company_id)

    if fix:
        out.info("Applying fixes...")
        fix_result = c.execute_kw("company.onboarding.wizard", "action_bootstrap_baseline_from_cli", [company_id])
        out.success("Baseline setup applied:")
        for k, v in (fix_result or {}).items():
            out.info(f"  {k}: {v}")

    result = c.execute_kw("company.coa.profile.applier", "validate_currencies", [company_id])

    if not result or "error" in result:
        out.error(result.get("error", "Unknown error") if result else "No result")
        raise typer.Exit(1)

    out.info(f"Currency Validation: {result['company']} (id={result['company_id']})")
    out.info(f"Company currency: {result.get('company_currency', '?')}")
    out.info(f"FX loss account: {result.get('fx_loss_account') or 'NOT SET'}")
    out.info(f"FX gain account: {result.get('fx_gain_account') or 'NOT SET'}")
    out.info("─" * 50)

    for curr in result.get("currencies", []):
        status_color = "green" if curr["status"] == "PASS" else "red"
        active_label = "active" if curr.get("active") else "INACTIVE"
        rate_info = ""
        if curr.get("latest_rate_date"):
            rate_info = f" (rate: {curr.get('latest_rate', '?')} @ {curr['latest_rate_date']})"
        out.console.print(
            f"  [{status_color}]{curr['status']}[/{status_color}] {curr['name']}: {active_label}{rate_info}"
        )
        for iss in curr.get("issues", []):
            out.console.print(f"       [red]✗ {iss}[/red]")

    out.info("─" * 50)
    for issue in result.get("issues", []):
        out.console.print(f"  [red]✗[/red] {issue}")

    passed = result.get("passed", 0)
    failed = result.get("failed", 0)
    if failed == 0:
        out.success(f"RESULT: {passed}/{passed + failed} PASSED ✓")
    else:
        out.error(f"RESULT: {passed}/{passed + failed} passed, {failed} FAILED")
        if not fix:
            out.info("Hint: use --fix to auto-apply corrections")


@app.command("validate-lots")
def validate_lots_cmd(
    ctx: typer.Context,
    company_id: Annotated[str, typer.Option("--company-id", "-c", help="Company ID or name")],
) -> None:
    """Validate lot/serial tracking for a company.

    Checks: all storable products have tracking=lot, stock quants have lots,
    no orphan lots.

    Examples:
        kctl-odoo companies validate-lots -c 339
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    company_id = _resolve_company_id(c, company_id)

    result = c.execute_kw("company.coa.profile.applier", "validate_lots", [company_id])

    if not result or "error" in result:
        out.error(result.get("error", "Unknown error") if result else "No result")
        raise typer.Exit(1)

    out.info(f"Lot Validation: {result['company']} (id={result['company_id']})")
    out.info(f"Storable products: {result['total_storable_products']}")
    out.info(f"Products with stock: {result.get('products_with_stock', 0)}")
    out.info(f"Total lots: {result.get('total_lots', 0)}")
    out.info(f"Orphan lots: {result.get('orphan_lots', 0)}")
    out.info(f"Products without lot tracking: {result.get('products_without_lot_tracking', 0)}")
    out.info(f"Quants without lots: {result.get('quants_without_lots', 0)}")
    out.info("─" * 50)

    for issue in result.get("issues", []):
        out.console.print(f"  [red]✗[/red] {issue}")

    passed = result.get("passed", 0)
    failed = result.get("failed", 0)
    if failed == 0:
        out.success(f"RESULT: {passed}/{passed + failed} PASSED ✓")
    else:
        out.error(f"RESULT: {passed}/{passed + failed} passed, {failed} FAILED")


@app.command("validate-contracts")
def validate_contracts_cmd(
    ctx: typer.Context,
    company_id: Annotated[str, typer.Option("--company-id", "-c", help="Company ID or name")],
) -> None:
    """Validate Sales Contract (SC) setup for a company.

    Checks: contract_management module installed, default NON-SC record exists,
    all posted journal items and PO lines have sales_contract_id.

    Examples:
        kctl-odoo companies validate-contracts -c 339
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    company_id = _resolve_company_id(c, company_id)

    result = c.execute_kw("company.coa.profile.applier", "validate_contracts", [company_id])

    if not result or "error" in result:
        out.error(result.get("error", "Unknown error") if result else "No result")
        raise typer.Exit(1)

    out.info(f"Contract Validation: {result['company']} (id={result['company_id']})")
    out.info(f"Module installed: {result.get('module_installed', False)}")
    if result.get("module_installed"):
        out.info(f"Total contracts: {result.get('total_contracts', 0)}")
        out.info(f"Has default SC: {result.get('has_default_sc', False)}")
        if "aml_total" in result:
            out.info(f"Journal items: {result.get('aml_total', 0)} total, {result.get('aml_without_sc', 0)} without SC")
        if "pol_total" in result:
            out.info(f"PO lines: {result.get('pol_total', 0)} total, {result.get('pol_without_sc', 0)} without SC")
    out.info("─" * 50)

    for issue in result.get("issues", []):
        out.console.print(f"  [red]✗[/red] {issue}")

    passed = result.get("passed", 0)
    failed = result.get("failed", 0)
    if failed == 0:
        out.success(f"RESULT: {passed}/{passed + failed} PASSED ✓")
    else:
        out.error(f"RESULT: {passed}/{passed + failed} passed, {failed} FAILED")


@app.command("validate-coa")
def validate_coa(
    ctx: typer.Context,
    company_id: Annotated[str, typer.Option("--company-id", "-c", help="Company ID or name")],
    profile: Annotated[str | None, typer.Option("--profile", "-p", help="Path to COA profile YAML")] = None,
    fix: Annotated[bool, typer.Option("--fix", help="Auto-fix issues (apply profile corrections)")] = False,
) -> None:
    """Validate a company's COA against the TPP Import profile.

    Checks accounts, partner defaults, product category configuration,
    and journal defaults. Use --fix to auto-apply corrections.

    Examples:
        kctl-odoo companies validate-coa --company-id 362
        kctl-odoo companies validate-coa -c 362 --fix
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    company_id = _resolve_company_id(c, company_id)

    args = [company_id, profile]
    if fix:
        apply_result = c.execute_kw("company.coa.profile.applier", "apply", args)
        out.success("COA profile applied:")
        for k, v in (apply_result or {}).items():
            out.info(f"  {k}: {v}")
        # Chain validate_company(fix=True) to run all Phase 1 fix_* methods:
        # fix_journals, fix_banks (cash↔journal 1-to-1), fix_categories,
        # fix_uom_categories, fix_product_uom_by_category, fix_partner_fiscal_position
        vc_result = c.execute_kw(
            "company.coa.profile.applier",
            "validate_company",
            [company_id],
            {"fix": True},
        )
        out.success("validate_company(fix=True) summary:")
        out.info(f"  total_passed: {vc_result.get('total_passed')}")
        out.info(f"  total_failed: {vc_result.get('total_failed')}")
        issues_after = vc_result.get("issues", [])
        if issues_after:
            out.info(f"  issues_after_fix: {len(issues_after)}")
            for issue in issues_after[:10]:
                out.info(f"    {issue}")

    result = c.execute_kw("company.coa.profile.applier", "validate", args)

    if not result or "error" in result:
        out.error(result.get("error", "Unknown error"))
        raise typer.Exit(1)

    out.info(f"COA Validation: {result['company']} (id={result['company_id']})")
    out.info("─" * 50)

    for issue in result.get("issues", []):
        out.console.print(f"  [red]✗[/red] {issue}")

    passed = result.get("passed", 0)
    failed = result.get("failed", 0)

    if failed == 0:
        out.success(f"RESULT: {passed}/{passed + failed} PASSED ✓")
    else:
        out.error(f"RESULT: {passed}/{passed + failed} passed, {failed} FAILED")
        if not fix:
            out.info("Hint: use --fix to auto-apply corrections")


@app.command("apply-coa-profile")
def apply_coa_profile(
    ctx: typer.Context,
    company_id: Annotated[str, typer.Option("--company-id", "-c", help="Company ID or name")],
    profile: Annotated[str | None, typer.Option("--profile", "-p", help="Path to COA profile YAML")] = None,
) -> None:
    """Apply the COA profile to a company (create accounts, set defaults).

    Idempotent — safe to run multiple times.

    Examples:
        kctl-odoo companies apply-coa-profile --company-id 362
    """
    actx: AppContext = ctx.obj
    out = actx.output
    company_id = _resolve_company_id(actx.client, company_id)
    result = actx.client.execute_kw("company.coa.profile.applier", "apply", [company_id, profile])
    out.success("COA profile applied:")
    for k, v in (result or {}).items():
        out.info(f"  {k}: {v}")


@app.command("coa-bulk-apply")
def coa_bulk_apply(
    ctx: typer.Context,
    type_code: Annotated[
        str | None,
        typer.Option("--type", "-T", help="Filter by company type code: IMP, TRD, INT (default: all)"),
    ] = None,
    subgroup_code: Annotated[
        str | None,
        typer.Option("--subgroup", "-G", help="Filter by sub-group code: SQ, TPP1-4, TIER1"),
    ] = None,
    skip_test: Annotated[
        bool,
        typer.Option("--skip-test", help="Skip test companies (E2E*, DUMMY*, TEST*, ITB)"),
    ] = False,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="List companies that would be processed without applying"),
    ] = False,
    profile: Annotated[
        str | None,
        typer.Option("--profile", "-p", help="Path to COA profile YAML (default: coa-profile-tpp-all.yaml)"),
    ] = None,
) -> None:
    """Apply the COA profile to ALL companies (idempotent bulk operation).

    Iterates through every company matching the filters and runs apply().
    Use --dry-run first to preview the target set.

    Examples:
        kctl-odoo companies coa-bulk-apply --dry-run
        kctl-odoo companies coa-bulk-apply --type IMP
        kctl-odoo companies coa-bulk-apply --skip-test
        kctl-odoo companies coa-bulk-apply -T TRD -G TPP1
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    # Build domain filter
    domain = []
    if type_code:
        type_recs = c.execute_kw(
            "res.company.type",
            "search_read",
            [[("code", "=", type_code)], ["id"]],
            {"limit": 1},
        )
        if not type_recs:
            out.error(f"Unknown company type code: {type_code}")
            raise typer.Exit(1)
        domain.append(("company_type_id", "=", type_recs[0]["id"]))
    if subgroup_code:
        sg_recs = c.execute_kw(
            "res.company.subgroup",
            "search_read",
            [[("code", "=", subgroup_code)], ["id"]],
            {"limit": 1},
        )
        if not sg_recs:
            out.error(f"Unknown sub-group code: {subgroup_code}")
            raise typer.Exit(1)
        domain.append(("subgroup_id", "=", sg_recs[0]["id"]))

    companies = c.execute_kw(
        "res.company",
        "search_read",
        [domain, ["id", "name", "company_code"]],
        {"order": "id"},
    )

    if skip_test:
        TEST_PATTERNS = ("E2E", "DUMMY", "TEST", "ITB", "MY COMPANY")
        before = len(companies)
        companies = [co for co in companies if not any(p in (co["name"] or "").upper() for p in TEST_PATTERNS)]
        out.info(f"Skipped {before - len(companies)} test companies")

    if not companies:
        out.warn("No companies match the filter.")
        return

    out.info(f"Target: {len(companies)} companies")
    if dry_run:
        out.console.print()
        for co in companies:
            out.console.print(f"  [{co['id']:>3}] {co['company_code'] or '?':<8} {co['name']}")
        out.info("[DRY RUN] No changes applied.")
        return

    out.console.print()
    # Single server-side bulk_apply call — eliminates per-company round-trip overhead
    company_ids = [co["id"] for co in companies]
    out.info(f"Calling server-side bulk_apply for {len(company_ids)} companies...")
    bulk_result = c.execute_kw(
        "company.coa.profile.applier",
        "bulk_apply",
        [company_ids, profile],
    )

    results = bulk_result.get("results", [])
    succeeded = bulk_result.get("succeeded", 0)
    failed_count = bulk_result.get("failed", 0)
    totals = bulk_result.get("totals", {})

    # Per-company progress
    for i, r in enumerate(results, 1):
        cid = r.get("company_id", "?")
        cname = (r.get("name") or "")[:45]
        code = r.get("code") or "?"
        prefix = f"[{i:>2}/{len(results)}] [{cid:>3}] {code:<8} {cname:<45}"
        if r.get("status") == "ok":
            s = r.get("summary", {}) or {}
            ac = s.get("accounts_created", 0)
            bjf = s.get("bank_journals_fixed", 0)
            cf = s.get("categories_fixed", 0)
            out.console.print(f"{prefix} [green]✓[/green] accounts={ac:<4} banks={bjf:<3} cats={cf}")
        else:
            out.console.print(f"{prefix} [red]✗[/red] {r.get('error', 'unknown')[:80]}")

    # Summary
    out.console.print()
    out.console.print(f"[bold]Summary:[/bold] {succeeded}/{len(results)} succeeded, {failed_count} failed")
    out.console.print(f"  Total accounts created/shared:  {totals.get('accounts_created', 0)}")
    out.console.print(f"  Total commodity accounts:       {totals.get('commodity_accounts_created', 0)}")
    out.console.print(f"  Total bank journal fixes:       {totals.get('bank_journals_fixed', 0)}")
    out.console.print(f"  Total category fixes:           {totals.get('categories_fixed', 0)}")
    out.console.print(f"  Total accounts renamed:         {totals.get('accounts_renamed', 0)}")

    if failed_count:
        raise typer.Exit(1)


@app.command("coa-report")
def coa_report(
    ctx: typer.Context,
    company_id: Annotated[str, typer.Option("--company-id", "-c", help="Company ID or name")],
    output: Annotated[str, typer.Option("--output", "-o", help="Output Excel file path")] = "coa-report.xlsx",
    profile: Annotated[str | None, typer.Option("--profile", help="Path to COA profile YAML")] = None,
) -> None:
    """Export a company's COA setup to Excel for auditing.

    Generates a multi-sheet workbook with: Summary, Accounts, Categories,
    Partner Defaults, Journals, and Validation results. Cells are
    color-coded green/red when a COA profile is provided for comparison.

    Examples:
        kctl-odoo companies coa-report -c 362 -o mandira-coa.xlsx
        kctl-odoo companies coa-report -c 362 --profile install/coa-profile-tpp-import.yaml
    """
    actx: AppContext = ctx.obj
    out = actx.output
    company_id = _resolve_company_id(actx.client, company_id)

    out.info(f"Generating COA report for company {company_id}...")
    data = actx.client.execute_kw(
        "company.coa.profile.applier",
        "report",
        [company_id, profile],
    )

    if not data or "error" in data:
        out.error(data.get("error", "Failed to generate report") if data else "No data returned")
        raise typer.Exit(1)

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill

    wb = Workbook()

    green_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
    red_fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
    yellow_fill = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")
    header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    header_font = Font(bold=True, color="FFFFFF")

    def write_header(ws, headers):
        for col, h in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=h)
            cell.font = header_font
            cell.fill = header_fill
        ws.auto_filter.ref = ws.dimensions

    # --- Sheet 1: Summary ---
    ws = wb.active
    ws.title = "Summary"
    ws["A1"] = "COA Setup Report"
    ws["A1"].font = Font(bold=True, size=16)
    ws["A3"] = "Company:"
    ws["B3"] = data["company_name"]
    ws["A4"] = "Company ID:"
    ws["B4"] = data["company_id"]
    ws["A5"] = "Profile:"
    ws["B5"] = data["profile_name"]
    ws["A6"] = "Total Accounts:"
    ws["B6"] = len(data["accounts"])
    ws["A7"] = "Factory Accounts:"
    ws["B7"] = sum(1 for a in data["accounts"] if a["is_factory"])
    v = data.get("validation", {})
    passed = v.get("passed", 0)
    failed = v.get("failed", 0)
    ws["A8"] = "Validation:"
    ws["B8"] = f"{passed}/{passed + failed} PASSED"
    ws["B8"].fill = green_fill if failed == 0 else red_fill
    ws.column_dimensions["A"].width = 20
    ws.column_dimensions["B"].width = 50

    # --- Sheet 2: Accounts ---
    ws2 = wb.create_sheet("Accounts")
    acct_headers = [
        "Code",
        "Name",
        "Account Type",
        "Deprecated",
        "Transactions",
        "Factory?",
        "Remap Target",
    ]
    write_header(ws2, acct_headers)
    for i, a in enumerate(data["accounts"], 2):
        ws2.cell(row=i, column=1, value=a["code"])
        ws2.cell(row=i, column=2, value=a["name"])
        ws2.cell(row=i, column=3, value=a["type"])
        ws2.cell(row=i, column=4, value="Yes" if a["deprecated"] else "")
        ws2.cell(row=i, column=5, value=a["txn_count"])
        cell_factory = ws2.cell(row=i, column=6, value="FACTORY" if a["is_factory"] else "")
        if a["is_factory"]:
            cell_factory.fill = yellow_fill
        ws2.cell(row=i, column=7, value=a["remap_target"])
    for col_letter in ["A", "B", "C", "D", "E", "F", "G"]:
        ws2.column_dimensions[col_letter].width = 18
    ws2.column_dimensions["B"].width = 40

    # --- Sheet 3: Categories ---
    ws3 = wb.create_sheet("Categories")
    cat_headers = [
        "Category",
        "Valuation",
        "Expected",
        "Cost Method",
        "Expected",
        "Income Acct",
        "Expected",
        "Expense Acct",
        "Expected",
        "Stock Val",
        "Expected",
        "Stock In",
        "Expected",
        "Stock Out",
        "Expected",
    ]
    write_header(ws3, cat_headers)
    for i, c in enumerate(data["categories"], 2):
        ws3.cell(row=i, column=1, value=c["name"])
        pairs = [
            (c["valuation"], c["expected_valuation"]),
            (c["cost_method"], c["expected_cost_method"]),
            (c["income_account"], c["expected_income"]),
            (c["expense_account"], c["expected_expense"]),
            (c["stock_valuation"], c["expected_stock_val"]),
            (c["stock_input"], c["expected_stock_in"]),
            (c["stock_output"], c["expected_stock_out"]),
        ]
        for col_idx, (actual, expected) in enumerate(pairs, 1):
            actual_cell = ws3.cell(row=i, column=col_idx * 2, value=actual)
            ws3.cell(row=i, column=col_idx * 2 + 1, value=expected)
            if expected and actual != expected:
                actual_cell.fill = red_fill
            elif expected:
                actual_cell.fill = green_fill

    # --- Sheet 4: Partners ---
    ws4 = wb.create_sheet("Partners")
    partner_headers = [
        "Partner",
        "Company Owned",
        "AR Account",
        "AR Name",
        "Expected AR",
        "AP Account",
        "AP Name",
        "Expected AP",
    ]
    write_header(ws4, partner_headers)
    for i, p in enumerate(data["partners"], 2):
        ws4.cell(row=i, column=1, value=p["name"])
        ws4.cell(
            row=i,
            column=2,
            value="Yes" if p["company_owned"] else "Shared",
        )
        ar_cell = ws4.cell(row=i, column=3, value=p["ar_code"])
        ws4.cell(row=i, column=4, value=p["ar_name"])
        ws4.cell(row=i, column=5, value=p["expected_ar"])
        ap_cell = ws4.cell(row=i, column=6, value=p["ap_code"])
        ws4.cell(row=i, column=7, value=p["ap_name"])
        ws4.cell(row=i, column=8, value=p["expected_ap"])
        if p["expected_ar"] and p["ar_code"] != p["expected_ar"]:
            ar_cell.fill = red_fill
        if p["expected_ap"] and p["ap_code"] != p["expected_ap"]:
            ap_cell.fill = red_fill
    for col_letter in ["A", "B", "C", "D", "E", "F", "G", "H"]:
        ws4.column_dimensions[col_letter].width = 22

    # --- Sheet 5: Journals ---
    ws5 = wb.create_sheet("Journals")
    journal_headers = [
        "Code",
        "Name",
        "Type",
        "Default Account",
        "Account Name",
        "Suspense Account",
        "Currency",
    ]
    write_header(ws5, journal_headers)
    for i, j in enumerate(data["journals"], 2):
        ws5.cell(row=i, column=1, value=j["code"])
        ws5.cell(row=i, column=2, value=j["name"])
        ws5.cell(row=i, column=3, value=j["type"])
        ws5.cell(row=i, column=4, value=j["default_account"])
        ws5.cell(row=i, column=5, value=j["default_account_name"])
        ws5.cell(row=i, column=6, value=j.get("suspense_account", ""))
        ws5.cell(row=i, column=7, value=j["currency"])
    for col_letter in ["A", "B", "C", "D", "E", "F", "G"]:
        ws5.column_dimensions[col_letter].width = 20

    # --- Sheet 6: Products ---
    prod_data = data.get("products", [])
    ws6 = wb.create_sheet("Products")
    prod_headers = [
        "Name",
        "Code",
        "Type",
        "Tracking",
        "UoM",
        "PO UoM",
        "Category",
        "Sale Tax",
        "Purchase Tax",
        "Invoice Policy",
        "Purchase Method",
        "Cost",
        "Sellers",
    ]
    write_header(ws6, prod_headers)
    for i, p in enumerate(prod_data, 2):
        ws6.cell(row=i, column=1, value=p["name"])
        ws6.cell(row=i, column=2, value=p["code"])
        ws6.cell(row=i, column=3, value=p["type"])
        tracking_cell = ws6.cell(row=i, column=4, value=p["tracking"])
        if p["type"] == "consu" and p["tracking"] == "none":
            tracking_cell.fill = yellow_fill
        ws6.cell(row=i, column=5, value=p["uom"])
        ws6.cell(row=i, column=6, value=p["uom_po"])
        ws6.cell(row=i, column=7, value=p["category"])
        tax_cell = ws6.cell(row=i, column=8, value=p["sale_tax"])
        if p["sale_tax"]:
            tax_cell.fill = yellow_fill  # taxes on import products = suspect
        ptax_cell = ws6.cell(row=i, column=9, value=p["purchase_tax"])
        if p["purchase_tax"]:
            ptax_cell.fill = yellow_fill
        ws6.cell(row=i, column=10, value=p["invoice_policy"])
        ws6.cell(row=i, column=11, value=p["purchase_method"])
        ws6.cell(row=i, column=12, value=p["cost"])
        ws6.cell(row=i, column=13, value=p["sellers"])
    for col_letter in ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M"]:
        ws6.column_dimensions[col_letter].width = 18
    ws6.column_dimensions["A"].width = 40
    ws6.column_dimensions["M"].width = 30

    # --- Sheet 7: Partners Full ---
    pf_data = data.get("partners_full", [])
    ws7 = wb.create_sheet("Partners Full")
    pf_headers = [
        "Name",
        "Type",
        "Country",
        "Supplier Currency",
        "Payment Term",
        "Supplier Payment Term",
        "AR Account",
        "AP Account",
        "Salesman",
    ]
    write_header(ws7, pf_headers)
    for i, p in enumerate(pf_data, 2):
        ws7.cell(row=i, column=1, value=p["name"])
        ws7.cell(row=i, column=2, value=p["type"])
        ws7.cell(row=i, column=3, value=p["country"])
        curr_cell = ws7.cell(row=i, column=4, value=p["supplier_currency"])
        # Highlight vendors with no currency set
        if "vendor" in p["type"] and not p["supplier_currency"]:
            curr_cell.fill = yellow_fill
        ws7.cell(row=i, column=5, value=p["payment_term"])
        ws7.cell(row=i, column=6, value=p["supplier_payment_term"])
        ws7.cell(row=i, column=7, value=p["ar_account"])
        ws7.cell(row=i, column=8, value=p["ap_account"])
        ws7.cell(row=i, column=9, value=p["salesman"])
    for col_letter in ["A", "B", "C", "D", "E", "F", "G", "H", "I"]:
        ws7.column_dimensions[col_letter].width = 22
    ws7.column_dimensions["A"].width = 40

    # --- Sheet 8: Validation ---
    ws8 = wb.create_sheet("Validation")
    write_header(ws8, ["Check", "Status"])
    ws8.column_dimensions["A"].width = 80
    ws8.column_dimensions["B"].width = 10
    row = 2
    for issue in v.get("issues", []):
        ws8.cell(row=row, column=1, value=issue)
        status_cell = ws8.cell(row=row, column=2, value="FAIL")
        status_cell.fill = red_fill
        row += 1
    ws8.cell(row=row + 1, column=1, value=f"Passed: {passed}")
    ws8.cell(row=row + 2, column=1, value=f"Failed: {failed}")

    wb.save(output)
    out.success(f"COA report saved to {output}")
    out.info(f"  Accounts: {len(data['accounts'])}")
    out.info(f"  Categories: {len(data['categories'])}")
    out.info(f"  Partners: {len(data['partners'])}")
    out.info(f"  Journals: {len(data['journals'])}")
    out.info(f"  Products: {len(prod_data)}")
    out.info(f"  Partners (full): {len(pf_data)}")
    out.info(f"  Validation: {passed}/{passed + failed}")


@app.command("business-scenario")
def business_scenario(
    ctx: typer.Context,
    company_id: Annotated[str, typer.Option("--company-id", "-c", help="Company ID or name")],
    scenario: Annotated[
        str,
        typer.Option("--scenario", "-s", help="Scenario: normal, dp, or accurate_parity"),
    ] = "normal",
    output: Annotated[str | None, typer.Option("--output", "-o", help="Excel output path")] = None,
    commit: Annotated[bool, typer.Option("--commit/--no-commit", help="Persist data (no rollback)")] = False,
    version: Annotated[int, typer.Option("--version", "-v", help="Scenario version: 1 or 2")] = 2,
) -> None:
    """Run a full import scenario on a company.

    Executes the complete import business flow (SC → PR → PO → GR → Bill →
    Payment → Import Costs → Sales → Reports) inside a savepoint.

    Use --commit to persist test data for UI review. Use --scenario dp to
    include 30% down payment flow.

    Version 1: Basic flow (SC, PO, GR, Bill, Pay, Sales).
    Version 2: Real-world flow (adds PPJK bill, OpEx, tax, FX).

    Scenario accurate_parity: Pre-cutover parity gate. Chains five stages:
      (0) pre-flight — locate accurate.company registration,
      (1) foundation gate — FoundationValidator.validate_all(),
      (2) setup correctness — validate_company(fix=True),
      (3) business-cycle replay — run_full_scenario_v2 normal,
      (4) parity validators — ParitySuite.run().
    Returns a sections-based result; --version is ignored for this scenario.

    NOTE — accurate_parity timeout: this scenario runs 5-10 minutes. The
    default JSON-RPC read timeout (60s) will cause an HTTP timeout before
    it completes. Set the env var to raise the limit before running:

        KCTL_ODOO_READ_TIMEOUT=1800 kctl-odoo companies business-scenario \\
            -c <id> -s accurate_parity -o /tmp/parity.xlsx

    Direct-shell fallback (when CLI times out despite the env var):

        ./run shell <db_name> <<'EOF'
        company_id = <id>
        result = env["e2e.accounting.validator"].run_accurate_parity_scenario(
            company_id, output_path="/tmp/parity.xlsx", commit=False
        )
        import pprint; pprint.pprint(result.get("sections", []))
        env.cr.commit()
        EOF

    Examples:
        kctl-odoo companies business-scenario -c 364
        kctl-odoo companies business-scenario -c 364 -s dp --commit
        kctl-odoo companies business-scenario -c 364 -v 1 -o /tmp/scenario.xlsx
        KCTL_ODOO_READ_TIMEOUT=1800 kctl-odoo companies business-scenario -c 364 -s accurate_parity -o /tmp/parity.xlsx
    """
    actx: AppContext = ctx.obj
    out = actx.output
    company_id = _resolve_company_id(actx.client, company_id)

    # ------------------------------------------------------------------
    # accurate_parity: dedicated pre-cutover gate — own method + renderer
    # ------------------------------------------------------------------
    if scenario == "accurate_parity":
        out.info(f"Running accurate_parity gate on company {company_id}...")
        if commit:
            out.warn("--commit: data will persist (no rollback)")

        result = actx.client.execute_kw(
            "e2e.accounting.validator",
            "run_accurate_parity_scenario",
            [company_id],
            {"output_path": output or "", "commit": commit},
        )

        if not result:
            out.error("No result returned")
            raise typer.Exit(1)

        icon_map = {
            "PASS": "[green]✓[/]",
            "FAIL": "[red]✗[/]",
            "BLOCK": "[red]![/]",
            "SKIP": "[dim]⊘[/]",
            "WARN": "[yellow]?[/]",
        }

        sections = result.get("sections", [])
        total_passed = sum(s.get("passed", 0) for s in sections)
        total_failed = sum(s.get("failed", 0) for s in sections)

        for s in sections:
            status = s.get("status", "")
            icon = icon_map.get(status, "?")
            label_str = s.get("label", "")
            p = s.get("passed", 0)
            f = s.get("failed", 0)
            detail = s.get("detail", "")
            detail_str = f" — {detail}" if detail else ""
            out.text(f"  {icon} {label_str}: {p} pass / {f} fail{detail_str}")

        overall = result.get("passed", False)
        if overall:
            out.success(f"RESULT: PASS ({total_passed} pass, {total_failed} fail across {len(sections)} stages)")
        else:
            out.error(f"RESULT: FAIL ({total_passed} pass, {total_failed} fail across {len(sections)} stages)")

        excel_path = result.get("excel_path", "")
        if excel_path:
            out.info(f"Excel report: {excel_path}")
        elif output:
            out.info(f"Excel: {output}")

        if not overall:
            raise typer.Exit(1)
        return

    # ------------------------------------------------------------------
    # normal / dp: existing import-scenario flow
    # ------------------------------------------------------------------
    method = "run_full_scenario_v2" if version == 2 else "run_full_scenario"
    label = f"v{version} ({scenario})"

    out.info(f"Running import scenario {label} on company {company_id}...")
    if commit:
        out.warn("--commit: data will persist (no rollback)")

    result = actx.client.execute_kw(
        "e2e.accounting.validator",
        method,
        [company_id, scenario],
        {"output_path": output or "", "commit": commit},
    )

    if not result:
        out.error("No result returned")
        raise typer.Exit(1)

    passed = result.get("passed", 0)
    failed = result.get("failed", 0)
    blocked = result.get("blocked", 0)

    for r in result.get("results", []):
        status = r.get("status", "")
        icon = {
            "PASS": "[green]✓[/]",
            "FAIL": "[red]✗[/]",
            "BLOCK": "[red]![/]",
            "SKIP": "[dim]⊘[/]",
            "WARN": "[yellow]?[/]",
        }.get(status, "?")
        amt = r.get("amount", 0)
        amt_str = f" [{amt:,.0f}]" if amt and isinstance(amt, (int, float)) and amt != 0 else ""
        out.text(f"  {icon} L{r.get('layer', '')} {r.get('step', '')}: {r.get('description', '')}{amt_str}")

    if failed == 0 and blocked == 0:
        out.success(f"RESULT: {passed} PASS, {failed} FAIL, {blocked} BLOCK")
    else:
        out.error(f"RESULT: {passed} PASS, {failed} FAIL, {blocked} BLOCK")

    if output:
        out.info(f"Excel: {output}")


@app.command("business-scenario-cleanup")
def business_scenario_cleanup(
    ctx: typer.Context,
    company_id: Annotated[str, typer.Option("--company-id", "-c", help="Company ID or name")],
    confirm: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation")] = False,
) -> None:
    """Delete all E2E-TEST data from a company.

    Removes partners, SCs, lots, POs, SOs, bills, invoices, payments,
    pickings, and journal entries created by the import-scenario command.
    Only deletes records with 'E2E-TEST' in name/ref/origin.

    Examples:
        kctl-odoo companies business-scenario-cleanup -c 364
        kctl-odoo companies business-scenario-cleanup -c 364 -y
    """
    actx: AppContext = ctx.obj
    out = actx.output
    company_id = _resolve_company_id(actx.client, company_id)

    if not confirm:
        out.warn(f"This will delete ALL E2E-TEST data from company {company_id}.")
        if not typer.confirm("Continue?"):
            raise typer.Abort()

    out.info(f"Cleaning up E2E-TEST data for company {company_id}...")

    cleanup_sql = [
        "DELETE FROM account_partial_reconcile WHERE company_id = %(cid)s",
        "DELETE FROM account_full_reconcile WHERE id IN (SELECT full_reconcile_id FROM account_move_line WHERE company_id = %(cid)s AND full_reconcile_id IS NOT NULL)",
        "DELETE FROM account_bank_statement_line WHERE company_id = %(cid)s",
        "DELETE FROM account_payment WHERE company_id = %(cid)s",
        "DELETE FROM account_move_line WHERE company_id = %(cid)s",
        "DELETE FROM account_move WHERE company_id = %(cid)s",
        "DELETE FROM stock_valuation_layer WHERE company_id = %(cid)s",
        "DELETE FROM stock_move_line WHERE company_id = %(cid)s",
        "DELETE FROM stock_move WHERE company_id = %(cid)s",
        "DELETE FROM stock_picking WHERE company_id = %(cid)s",
        "DELETE FROM stock_quant WHERE company_id = %(cid)s",
        "DELETE FROM purchase_order_line WHERE company_id = %(cid)s",
        "DELETE FROM purchase_order WHERE company_id = %(cid)s",
        "DELETE FROM sale_order_line WHERE company_id = %(cid)s",
        "DELETE FROM sale_order WHERE company_id = %(cid)s",
        "DELETE FROM stock_quant WHERE lot_id IN (SELECT id FROM stock_lot WHERE company_id = %(cid)s)",
        "DELETE FROM stock_lot WHERE company_id = %(cid)s",
        "DELETE FROM sales_contract WHERE company_id = %(cid)s AND is_default = false",
    ]

    total = 0
    for sql in cleanup_sql:
        try:
            actx.client.execute_kw("e2e.accounting.validator", "check_access_rights", ["read"])
            # Use raw SQL via a helper model if available, otherwise skip
        except (RPCError, ConnectionError):
            pass

    # Use the ORM to delete what we can
    for model, domain_extra in [
        ("account.bank.statement.line", []),
        ("account.payment", []),
        ("account.move", []),
        ("purchase.order", []),
        ("sale.order", []),
        ("stock.lot", []),
        ("sales.contract", [("is_default", "=", False)]),
    ]:
        try:
            ids = actx.client.search(model, [("company_id", "=", company_id)] + domain_extra)
            if ids:
                actx.client.execute_kw(model, "unlink", [ids])
                out.text(f"  Deleted {len(ids)} {model} records")
                total += len(ids)
        except (RPCError, ConnectionError) as e:
            out.text(f"  [dim]Skip {model}: {str(e)[:50]}[/]")

    out.success(f"Cleanup complete: {total} records deleted")


@app.command("validate-sequence")
def validate_sequence_cmd(
    ctx: typer.Context,
    company_id: Annotated[str, typer.Option("--company-id", "-c", help="Company ID or name")],
    models: Annotated[
        str | None,
        typer.Option(
            "--models",
            help="Comma-separated list of models to validate (default: all 6 from VALIDATED_MODELS)",
        ),
    ] = None,
) -> None:
    """Report records whose document number does not match {company_code}/{type}/{YYYY}/{NNNNN}.

    Reads the company.sequence.standardizer service and returns a drift report per model.
    No mutations are made — use standardize-sequence to rename.

    Examples:
        kctl-odoo companies validate-sequence -c 361
        kctl-odoo companies validate-sequence -c 361 --models account.move,purchase.order
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    company_id = _resolve_company_id(c, company_id)

    model_list = [m.strip() for m in models.split(",")] if models else None
    result = c.execute_kw("company.sequence.standardizer", "validate", [company_id, model_list])

    if not result or "error" in result:
        out.error(result.get("error", "Unknown error") if result else "No response")
        raise typer.Exit(1)

    out.info(f"Sequence Drift Report: company {result['company_id']} ({result['company_code']})")
    out.info("─" * 60)

    rows = []
    total_drift = 0
    for model, stats in sorted(result.get("models", {}).items()):
        first_bad = stats["examples"][0][1] if stats["examples"] else ""
        rows.append([model, str(stats["compliant"]), str(stats["drift"]), first_bad])
        total_drift += stats["drift"]

    out.table(
        "Sequence Validation",
        [("Model", "cyan"), ("Compliant", ""), ("Drift", ""), ("Example bad name", "")],
        rows,
    )

    if total_drift == 0:
        out.success("RESULT: All records comply with the canonical sequence format ✓")
    else:
        out.error(f"RESULT: {total_drift} record(s) have non-canonical names")
        out.info("Hint: use 'kctl-odoo companies standardize-sequence -c <id>' to rename (dry-run by default)")


@app.command("standardize-sequence")
def standardize_sequence_cmd(
    ctx: typer.Context,
    company_id: Annotated[str, typer.Option("--company-id", "-c", help="Company ID or name")],
    models: Annotated[
        str | None,
        typer.Option(
            "--models",
            help="Comma-separated list of models (default: all 6)",
        ),
    ] = None,
    apply: Annotated[
        bool,
        typer.Option(
            "--apply",
            help="Mutate records. Without this flag, runs as dry-run (no changes made).",
        ),
    ] = False,
) -> None:
    """Rename existing records to {company_code}/{type}/{YYYY}/{NNNNN}.

    Default is dry-run — pass --apply to actually mutate. Walks records in
    chronological order per (company, journal/type) and renames to canonical shape.
    The original document number is preserved in account.move.ref (and partner_ref /
    client_order_ref / origin / invoice_ref on other models).

    Examples:
        kctl-odoo companies standardize-sequence -c 361
        kctl-odoo companies standardize-sequence -c 361 --apply
        kctl-odoo companies standardize-sequence -c 361 --models account.move --apply
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    company_id = _resolve_company_id(c, company_id)

    dry_run = not apply
    model_list = [m.strip() for m in models.split(",")] if models else None

    if not dry_run:
        out.warn(f"Running in APPLY mode — records for company {company_id} will be renamed.")
    else:
        out.info("Running in DRY-RUN mode (no changes). Pass --apply to mutate.")

    result = c.execute_kw(
        "company.sequence.standardizer",
        "apply",
        [company_id, model_list, dry_run],
    )

    if not result or "error" in result:
        out.error(result.get("error", "Unknown error") if result else "No response")
        raise typer.Exit(1)

    mode_label = "DRY RUN" if result.get("dry_run", True) else "APPLIED"
    out.info(f"Sequence Rename [{mode_label}]: company {result['company_id']}")
    out.info("─" * 60)

    rows = []
    total_renamed = 0
    for model, stats in sorted(result.get("models", {}).items()):
        if stats["examples"]:
            old, new = stats["examples"][0][1], stats["examples"][0][2]
            example = f"{old} → {new}"
        else:
            example = ""
        rows.append([model, str(stats["renamed"]), example])
        total_renamed += stats["renamed"]

    out.table(
        f"Sequence Rename [{mode_label}]",
        [("Model", "cyan"), ("Renamed", ""), ("Example old → new", "")],
        rows,
    )

    if result.get("dry_run", True):
        out.info(f"[DRY RUN] Would rename {total_renamed} record(s). Pass --apply to execute.")
    else:
        out.success(f"Renamed {total_renamed} record(s) to canonical sequence format ✓")
