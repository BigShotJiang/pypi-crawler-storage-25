"""Odoo 18 standard SVG icon generator for module icons."""

from __future__ import annotations

import xml.sax.saxutils
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console
from rich.table import Table

console = Console()

# ─── Color presets — gradient pairs matching Odoo 18 enterprise icons ────

_COLORS: dict[str, tuple[str, str]] = {
    "purple": ("#875A7B", "#68465F"),
    "teal": ("#00A09D", "#007A77"),
    "blue": ("#4E6EA5", "#3B547D"),
    "green": ("#5EB358", "#4A8F46"),
    "orange": ("#F0A30A", "#D49209"),
    "red": ("#E8525B", "#C44549"),
    "dark-blue": ("#455A64", "#374850"),
    "yellow": ("#EFBE2D", "#D9A825"),
    "indigo": ("#3F51B5", "#303F9F"),
    "pink": ("#E91E63", "#C2185B"),
    "cyan": ("#00BCD4", "#0097A7"),
    "lime": ("#8BC34A", "#689F38"),
    "brown": ("#795548", "#5D4037"),
    "grey": ("#607D8B", "#455A64"),
    "deep-purple": ("#673AB7", "#512DA8"),
    "amber": ("#FFC107", "#FF8F00"),
}

# ─── Built-in SVG icon paths (designed for 100×100 viewBox, white fill) ──

_ICONS: dict[str, dict[str, object]] = {
    "chart": {
        "desc": "Bar chart (reports/analytics)",
        "paths": [
            "M 30 70 L 30 48 L 40 48 L 40 70 Z",
            "M 43 70 L 43 33 L 53 33 L 53 70 Z",
            "M 56 70 L 56 55 L 66 55 L 66 70 Z",
        ],
    },
    "star": {
        "desc": "Five-pointed star (favorites/quality)",
        "paths": [
            "M 50 23 L 56 40 L 74 40 L 60 51 L 65 68 L 50 58 L 35 68 L 40 51 L 26 40 L 44 40 Z",
        ],
    },
    "heart": {
        "desc": "Heart (CRM/relationships)",
        "paths": [
            "M 50 70 C 50 70 22 56 22 40 C 22 30 30 26 38 26 "
            "C 44 26 50 32 50 38 C 50 32 56 26 62 26 "
            "C 70 26 78 30 78 40 C 78 56 50 70 50 70 Z",
        ],
    },
    "check": {
        "desc": "Checkmark (approvals/validation)",
        "paths": [
            "M 30 50 L 44 65 L 70 35 L 65 30 L 44 55 L 35 45 Z",
        ],
    },
    "mail": {
        "desc": "Envelope (messaging/email)",
        "paths": [
            "M 26 36 L 50 55 L 74 36 L 74 68 L 26 68 Z",
        ],
    },
    "lightning": {
        "desc": "Lightning bolt (automation/power)",
        "paths": [
            "M 56 24 L 38 52 L 50 52 L 44 76 L 62 44 L 50 44 Z",
        ],
    },
    "shield": {
        "desc": "Shield (security/compliance)",
        "paths": [
            "M 50 24 L 73 35 L 73 52 C 73 67 50 78 50 78 C 50 78 27 67 27 52 L 27 35 Z",
        ],
    },
    "arrow-up": {
        "desc": "Upward arrow (upload/import)",
        "paths": [
            "M 50 25 L 70 48 L 56 48 L 56 75 L 44 75 L 44 48 L 30 48 Z",
        ],
    },
    "plus": {
        "desc": "Plus sign (add/create)",
        "paths": [
            "M 44 28 L 56 28 L 56 44 L 72 44 L 72 56 L 56 56 L 56 72 L 44 72 L 44 56 L 28 56 L 28 44 L 44 44 Z",
        ],
    },
    "home": {
        "desc": "House (home/dashboard)",
        "paths": [
            "M 50 24 L 80 50 L 72 50 L 72 76 L 56 76 L 56 56 L 44 56 L 44 76 L 28 76 L 28 50 L 20 50 Z",
        ],
    },
    "bookmark": {
        "desc": "Bookmark (favorites/saved)",
        "paths": [
            "M 32 24 L 68 24 L 68 76 L 50 62 L 32 76 Z",
        ],
    },
    "diamond": {
        "desc": "Diamond (premium/value)",
        "paths": [
            "M 50 24 L 76 50 L 50 76 L 24 50 Z",
        ],
    },
    "flag": {
        "desc": "Flag (milestones/events)",
        "paths": [
            "M 30 24 L 34 24 L 34 76 L 30 76 Z",
            "M 34 26 L 70 26 L 62 40 L 70 54 L 34 54 Z",
        ],
    },
    "trending": {
        "desc": "Trending up (growth/analytics)",
        "paths": [
            "M 56 26 L 74 26 L 74 44 L 70 44 L 70 34 L 34 70 L 30 66 L 66 30 L 56 30 Z",
        ],
    },
    "gear": {
        "desc": "Gear cog (settings/config)",
        "paths": [
            "M 50 26 L 57 33 L 67 33 L 67 43 L 74 50 L 67 57 "
            "L 67 67 L 57 67 L 50 74 L 43 67 L 33 67 L 33 57 "
            "L 26 50 L 33 43 L 33 33 L 43 33 Z "
            "M 50 40 A 10 10 0 1 1 50 60 A 10 10 0 1 1 50 40 Z",
        ],
        "fill_rule": "evenodd",
    },
    "bell": {
        "desc": "Bell (notifications/alerts)",
        "paths": [
            "M 50 24 C 50 24 50 28 50 30 C 38 31 30 40 30 50 "
            "L 30 60 L 26 64 L 74 64 L 70 60 L 70 50 "
            "C 70 40 62 31 50 30 Z",
            "M 44 67 C 44 74 56 74 56 67 Z",
        ],
    },
    "grid": {
        "desc": "Grid (apps/menu)",
        "paths": [
            "M 27 27 L 39 27 L 39 39 L 27 39 Z",
            "M 43 27 L 55 27 L 55 39 L 43 39 Z",
            "M 59 27 L 71 27 L 71 39 L 59 39 Z",
            "M 27 43 L 39 43 L 39 55 L 27 55 Z",
            "M 43 43 L 55 43 L 55 55 L 43 55 Z",
            "M 59 43 L 71 43 L 71 55 L 59 55 Z",
            "M 27 59 L 39 59 L 39 71 L 27 71 Z",
            "M 43 59 L 55 59 L 55 71 L 43 71 Z",
            "M 59 59 L 71 59 L 71 71 L 59 71 Z",
        ],
    },
    "people": {
        "desc": "Person (HR/contacts/users)",
        "paths": [
            "M 50 26 A 12 12 0 1 0 50 50 A 12 12 0 1 0 50 26 Z",
            "M 26 76 Q 26 56 50 56 Q 74 56 74 76 Z",
        ],
    },
    "chat": {
        "desc": "Chat bubble (discuss/messaging)",
        "paths": [
            "M 28 28 Q 28 24 32 24 L 68 24 Q 72 24 72 28 "
            "L 72 56 Q 72 60 68 60 L 44 60 L 34 74 L 34 60 "
            "L 32 60 Q 28 60 28 56 Z",
        ],
    },
    "cart": {
        "desc": "Shopping cart (e-commerce/sales)",
        "paths": [
            "M 28 30 L 36 30 L 42 56 L 68 56 L 74 34 L 38 34 Z",
            "M 46 62 A 5 5 0 1 0 46 72 A 5 5 0 1 0 46 62 Z",
            "M 62 62 A 5 5 0 1 0 62 72 A 5 5 0 1 0 62 62 Z",
        ],
    },
    "lock": {
        "desc": "Padlock (security/access)",
        "paths": [
            "M 37 48 L 37 38 C 37 28 63 28 63 38 L 63 48 L 58 48 L 58 38 C 58 32 42 32 42 38 L 42 48 Z",
            "M 32 48 L 68 48 L 68 74 L 32 74 Z",
        ],
    },
    "file": {
        "desc": "Document (files/reports)",
        "paths": [
            "M 32 22 L 58 22 L 70 34 L 70 78 L 32 78 Z",
        ],
    },
    "search": {
        "desc": "Magnifying glass (search/find)",
        "paths": [
            "M 43 26 A 17 17 0 1 0 43 60 A 17 17 0 1 0 43 26 Z M 43 33 A 10 10 0 1 1 43 53 A 10 10 0 1 1 43 33 Z",
            "M 56 56 L 74 74 L 70 74 L 54 58 Z",
        ],
        "fill_rule": "evenodd",
    },
    "leaf": {
        "desc": "Leaf (eco/sustainability)",
        "paths": [
            "M 30 72 C 26 45 45 24 72 28 C 50 48 42 62 30 72 Z",
        ],
    },
    "cube": {
        "desc": "3D cube (inventory/products)",
        "paths": [
            "M 50 25 L 74 38 L 50 50 L 26 38 Z",
            "M 26 40 L 49 52 L 49 75 L 26 63 Z",
            "M 74 40 L 51 52 L 51 75 L 74 63 Z",
        ],
    },
}

_VALID_SHAPES = ("rounded-rect", "circle", "squircle")


# ─── SVG generation helpers ─────────────────────────────────────────────


def _darken_hex(hex_color: str, factor: float = 0.78) -> str:
    """Darken a hex color by a factor."""
    h = hex_color.lstrip("#")
    r = int(int(h[0:2], 16) * factor)
    g = int(int(h[2:4], 16) * factor)
    b = int(int(h[4:6], 16) * factor)
    return f"#{r:02x}{g:02x}{b:02x}"


def resolve_colors(color: str) -> tuple[str, str]:
    """Resolve color name or hex to (top, bottom) gradient pair."""
    if color in _COLORS:
        return _COLORS[color]
    h = color.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    if len(h) != 6:
        msg = f"Invalid color: {color}"
        raise ValueError(msg)
    try:
        int(h, 16)
    except ValueError:
        msg = f"Invalid hex color: {color}"
        raise ValueError(msg) from None
    top = f"#{h}"
    return (top, _darken_hex(top))


def generate_svg(
    color_top: str,
    color_bottom: str,
    *,
    icon_paths: list[str] | None = None,
    fill_rule: str | None = None,
    shape: str = "rounded-rect",
    use_gradient: bool = True,
    text: str | None = None,
) -> str:
    """Generate Odoo 18 module icon SVG content."""
    parts: list[str] = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">']

    if use_gradient:
        parts.append("  <defs>")
        parts.append('    <linearGradient id="bg" x1="0" y1="0" x2="0" y2="1">')
        parts.append(f'      <stop offset="0" stop-color="{color_top}"/>')
        parts.append(f'      <stop offset="1" stop-color="{color_bottom}"/>')
        parts.append("    </linearGradient>")
        parts.append("  </defs>")
        fill = "url(#bg)"
    else:
        fill = color_top

    if shape == "circle":
        parts.append(f'  <circle cx="50" cy="50" r="50" fill="{fill}"/>')
    elif shape == "squircle":
        parts.append(f'  <rect width="100" height="100" rx="22" fill="{fill}"/>')
    else:
        parts.append(f'  <rect width="100" height="100" rx="14" fill="{fill}"/>')

    if text:
        font_sizes = {1: 42, 2: 36, 3: 28, 4: 22}
        font_size = font_sizes.get(len(text), 18)
        escaped = xml.sax.saxutils.escape(text)
        parts.append(
            f'  <text x="50" y="50" text-anchor="middle" dy="0.35em" '
            f'font-family="Arial, Helvetica, sans-serif" '
            f'font-size="{font_size}" font-weight="bold" fill="#fff">'
            f"{escaped}</text>"
        )
    elif icon_paths:
        fr_attr = f' fill-rule="{fill_rule}"' if fill_rule else ""
        parts.append(f'  <g fill="#fff"{fr_attr}>')
        for p in icon_paths:
            parts.append(f'    <path d="{p}"/>')
        parts.append("  </g>")

    parts.append("</svg>")
    return "\n".join(parts) + "\n"


# ─── Command function (registered by generate.py) ───────────────────────


def icon(
    module_dir: Annotated[
        str | None,
        typer.Argument(help="Module directory name or path"),
    ] = None,
    symbol: Annotated[
        str | None,
        typer.Option("--symbol", "-s", help="Built-in icon name (use --list-icons to see all)"),
    ] = None,
    text: Annotated[
        str | None,
        typer.Option("--text", "-t", help="Custom text for icon (1-4 chars, e.g. 'HR', '$')"),
    ] = None,
    color: Annotated[
        str,
        typer.Option("--color", "-c", help="Color preset or hex code (e.g. teal, '#FF5733')"),
    ] = "purple",
    shape: Annotated[
        str,
        typer.Option("--shape", help="Background: rounded-rect, circle, squircle"),
    ] = "rounded-rect",
    no_gradient: Annotated[
        bool,
        typer.Option("--no-gradient", help="Use solid color instead of gradient"),
    ] = False,
    list_icons: Annotated[
        bool,
        typer.Option("--list-icons", help="List available built-in icon symbols"),
    ] = False,
    list_colors: Annotated[
        bool,
        typer.Option("--list-colors", help="List available color presets"),
    ] = False,
    overwrite: Annotated[
        bool,
        typer.Option("--overwrite", help="Overwrite existing icon"),
    ] = False,
) -> None:
    """Generate an Odoo 18 standard SVG icon for a module.

    Creates static/description/icon.svg with proper Odoo 18 styling:
    rounded-rect background with gradient + white icon symbol.

    Examples:
        kctl-odoo scaffold icon my_module --symbol chart --color teal
        kctl-odoo scaffold icon my_module --text "HR" --color red
        kctl-odoo scaffold icon my_module --symbol star --color "#FF5733"
        kctl-odoo scaffold icon my_module --symbol shield --shape circle
        kctl-odoo scaffold icon --list-icons
        kctl-odoo scaffold icon --list-colors
    """
    if list_icons:
        tbl = Table(title="Built-in Icons", show_header=True)
        tbl.add_column("Symbol", style="cyan")
        tbl.add_column("Description")
        for name, info in sorted(_ICONS.items()):
            tbl.add_row(name, str(info["desc"]))
        console.print(tbl)
        console.print(f"\n[dim]{len(_ICONS)} icons available. Use --symbol <name> to select.[/dim]")
        return

    if list_colors:
        tbl = Table(title="Color Presets", show_header=True)
        tbl.add_column("Name", style="cyan")
        tbl.add_column("Top")
        tbl.add_column("Bottom")
        for name, (top, bottom) in sorted(_COLORS.items()):
            tbl.add_row(name, top, bottom)
        console.print(tbl)
        console.print("\n[dim]Custom hex also supported: --color '#FF5733' (auto-generates gradient)[/dim]")
        return

    if not module_dir:
        console.print("[red]ERROR[/red] Module directory is required (unless using --list-icons or --list-colors)")
        raise typer.Exit(1)

    if not symbol and not text:
        console.print("[red]ERROR[/red] Specify --symbol or --text")
        console.print("  Use --list-icons to see available symbols")
        console.print("  Or use --text for custom text (e.g. --text 'HR')")
        raise typer.Exit(1)

    if symbol and symbol not in _ICONS:
        console.print(f"[red]ERROR[/red] Unknown symbol: {symbol}")
        console.print(f"  Available: {', '.join(sorted(_ICONS.keys()))}")
        raise typer.Exit(1)

    if shape not in _VALID_SHAPES:
        console.print(f"[red]ERROR[/red] Invalid shape: {shape}")
        console.print(f"  Choose: {', '.join(_VALID_SHAPES)}")
        raise typer.Exit(1)

    if text and len(text) > 4:
        console.print("[red]ERROR[/red] Text must be 1-4 characters")
        raise typer.Exit(1)

    try:
        color_top, color_bottom = resolve_colors(color)
    except ValueError:
        console.print(f"[red]ERROR[/red] Invalid color: {color}")
        console.print(f"  Presets: {', '.join(sorted(_COLORS.keys()))}")
        console.print("  Or hex: --color '#FF5733'")
        raise typer.Exit(1)

    mod_path = Path(module_dir)
    if not mod_path.is_absolute():
        try:
            from kctl_odoo.core.utils import find_project_root

            mod_path = find_project_root() / "src" / "private" / mod_path
        except (OSError, ImportError):
            mod_path = Path.cwd() / module_dir
    if not mod_path.is_dir():
        console.print(f"[red]ERROR[/red] Module directory not found: {mod_path}")
        raise typer.Exit(1)

    icon_paths_data: list[str] | None = None
    fill_rule: str | None = None
    if symbol:
        icon_data = _ICONS[symbol]
        icon_paths_data = list(icon_data["paths"])  # type: ignore[arg-type]
        fill_rule = str(icon_data["fill_rule"]) if "fill_rule" in icon_data else None

    svg_content = generate_svg(
        color_top,
        color_bottom,
        icon_paths=icon_paths_data,
        fill_rule=fill_rule,
        shape=shape,
        use_gradient=not no_gradient,
        text=text,
    )

    icon_dir = mod_path / "static" / "description"
    icon_dir.mkdir(parents=True, exist_ok=True)
    icon_file = icon_dir / "icon.svg"

    if icon_file.exists() and not overwrite:
        console.print(f"[yellow]SKIP[/yellow] {icon_file} (already exists, use --overwrite)")
        return

    icon_file.write_text(svg_content, encoding="utf-8")
    console.print(f"[green]CREATE[/green] {icon_file}")

    desc = f"symbol={symbol}" if symbol else f"text='{text}'"
    console.print(f"\n[green]Icon generated:[/green] {desc}, color={color}, shape={shape}")
