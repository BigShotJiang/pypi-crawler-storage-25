"""Workflow orchestration commands."""

from __future__ import annotations

import asyncio
from typing import Annotated

import typer

from kctl_odoo.core.callbacks import AppContext
from kctl_odoo.core.workflow import StepStatus, Workflow, WorkflowStep

app = typer.Typer(help="Run multi-step workflows with retry and rollback.")


def _get_builtin_workflows() -> dict[str, Workflow]:
    async def health_check(ctx):
        c = ctx.client
        version = c.execute_kw("common", "version", [])
        return {"status": "ok", "version": version}

    async def cron_disable(ctx):
        c = ctx.client
        cron_ids = c.search("ir.cron", [("active", "=", True)])
        if cron_ids:
            c.write("ir.cron", cron_ids, {"active": False})
        return {"disabled": len(cron_ids)}

    async def cron_enable(ctx):
        c = ctx.client
        cron_ids = c.search("ir.cron", [("active", "=", False)])
        if cron_ids:
            c.write("ir.cron", cron_ids, {"active": True})
        return {"enabled": len(cron_ids)}

    return {
        "deploy-safe": Workflow(
            "deploy-safe",
            [
                WorkflowStep(name="health-check", action=health_check),
            ],
        ),
        "maintenance-window": Workflow(
            "maintenance-window",
            [
                WorkflowStep(name="disable-crons", action=cron_disable),
                WorkflowStep(name="health-check", action=health_check),
                WorkflowStep(name="enable-crons", action=cron_enable),
            ],
        ),
        "data-quality-sweep": Workflow(
            "data-quality-sweep",
            [
                WorkflowStep(name="health-check", action=health_check, on_failure="skip", retries=0),
            ],
        ),
    }


@app.command("list")
def workflow_list(ctx: typer.Context) -> None:
    """List available workflows.

    Displays all built-in workflow definitions with their step names and
    step count. Use this to discover workflows before running them with
    'kctl-odoo workflow run'.

    Examples:
        kctl-odoo workflow list
        kctl-odoo workflow list --json
    """
    actx: AppContext = ctx.obj
    out = actx.output
    workflows = _get_builtin_workflows()
    table_rows = []
    json_data = []
    for wf_name, wf in sorted(workflows.items()):
        steps_str = " -> ".join(s.name for s in wf.steps)
        table_rows.append([wf_name, str(len(wf.steps)), steps_str])
        json_data.append({"name": wf_name, "steps": steps_str, "step_count": len(wf.steps)})
    out.table(
        "Available Workflows",
        [("Name", "cyan"), ("Steps", ""), ("Step Names", "dim")],
        table_rows,
        data_for_json=json_data,
    )


@app.command("run")
def workflow_run(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Workflow name")],
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Preview steps without executing")] = False,
    force: Annotated[bool, typer.Option("--force", help="Skip confirmation")] = False,
) -> None:
    """Execute a workflow.

    Runs each step sequentially with retry and failure-handling as defined
    in the workflow. Use --dry-run to preview steps without executing, or
    --force to skip the confirmation prompt in automation contexts.

    Examples:
        kctl-odoo workflow run deploy-safe
        kctl-odoo workflow run maintenance-window --dry-run
        kctl-odoo workflow run maintenance-window --force
    """
    actx: AppContext = ctx.obj
    out = actx.output
    workflows = _get_builtin_workflows()

    if name not in workflows:
        out.error(f"Unknown workflow: {name}. Use 'workflow list' to see available workflows.")
        raise typer.Exit(1)

    wf = workflows[name]

    if dry_run:
        preview = wf.dry_run()
        dry_rows = [[s["name"], s["on_failure"], str(s["retries"])] for s in preview]
        out.table(
            f"Workflow: {name} (dry run)",
            [("Step", "cyan"), ("On Failure", ""), ("Retries", "")],
            dry_rows,
            data_for_json=preview,
        )
        return

    if not force:
        steps_preview = " -> ".join(s.name for s in wf.steps)
        if not typer.confirm(f"Run workflow '{name}' ({steps_preview})?"):
            raise typer.Exit(0)

    out.info(f"Running workflow: {name}")
    result = asyncio.run(wf.run(actx))

    for step in result.steps:
        icon = "✓" if step.status == StepStatus.SUCCESS else "✗" if step.status == StepStatus.FAILED else "-"
        color = (
            "green" if step.status == StepStatus.SUCCESS else "red" if step.status == StepStatus.FAILED else "yellow"
        )
        out.info(f"  [{color}]{icon}[/{color}] {step.name}: {step.status.value}")
        if step.error:
            out.info(f"    Error: {step.error}")

    if result.success:
        out.success(f"Workflow '{name}' completed in {result.duration_seconds:.1f}s")
    else:
        out.error(f"Workflow '{name}' failed after {result.duration_seconds:.1f}s")
        raise typer.Exit(1)


@app.command("status")
def workflow_status(ctx: typer.Context) -> None:
    """Show last workflow run result.

    Displays the result of the most recently executed workflow. If no
    workflow has been run in this session, a message is shown directing
    you to run a workflow first.

    Examples:
        kctl-odoo workflow status
    """
    actx: AppContext = ctx.obj
    actx.output.info("No workflow history yet. Run a workflow first with: kctl-odoo workflow run <name>")
