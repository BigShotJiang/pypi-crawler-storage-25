"""Analysis commands for Odoo dev tools."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from kctl_odoo.core.callbacks import AppContext
from kctl_odoo.core.exceptions import RPCError
from kctl_odoo.core.utils import module_state_color

app = typer.Typer()


@app.command("regenerate-assets")
def assets_regenerate(
    ctx: typer.Context,
    force: Annotated[bool, typer.Option("--force", help="Skip confirmation")] = False,
) -> None:
    """Regenerate web assets by clearing asset attachments."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    # Find asset attachments
    domain = [
        "|",
        ("url", "like", "/web/assets"),
        ("name", "like", "web_editor."),
    ]
    asset_ids = c.search("ir.attachment", domain)

    if not asset_ids:
        out.info("No asset attachments found to clear.")
        if actx.json_mode:
            out.raw_json({"cleared": 0})
        return

    out.info(f"Found {len(asset_ids)} asset attachment(s) to clear.")

    if not force and not typer.confirm(
        f"Delete {len(asset_ids)} asset attachments? Assets will regenerate on next page load."
    ):
        raise typer.Exit(0)

    # Delete in batches
    batch_size = 500
    deleted = 0
    for i in range(0, len(asset_ids), batch_size):
        batch = asset_ids[i : i + batch_size]
        c.unlink("ir.attachment", batch)
        deleted += len(batch)

    out.success(f"Cleared {deleted} asset attachments. Assets will regenerate on next page load.")
    if actx.json_mode:
        out.raw_json({"cleared": deleted})


@app.command("deps-tree")
def deps_tree(
    ctx: typer.Context,
    module: Annotated[str, typer.Argument(help="Module technical name")],
) -> None:
    """Show dependency tree for a module."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    # Verify the module exists
    modules = c.search_read(
        "ir.module.module",
        domain=[("name", "=", module)],
        fields=["id", "name", "state", "shortdesc"],
    )
    if not modules:
        out.error(f"Module not found: {module}")
        raise typer.Exit(1)

    mod = modules[0]

    # Batch-fetch all modules and their dependencies to avoid N+1 queries
    all_modules = c.search_read(
        "ir.module.module",
        domain=[],
        fields=["id", "name", "state"],
        limit=0,
    )
    mod_by_name: dict[str, dict] = {m["name"]: m for m in all_modules}
    {m["id"]: m for m in all_modules}

    all_deps = c.search_read(
        "ir.module.module.dependency",
        domain=[],
        fields=["module_id", "name"],
        limit=0,
    )
    # Group dependencies by parent module ID
    deps_by_mod_id: dict[int, list[str]] = {}
    for dep in all_deps:
        parent_id = dep["module_id"][0] if isinstance(dep["module_id"], list) else dep["module_id"]
        dep_name = dep.get("name", "")
        if dep_name:
            deps_by_mod_id.setdefault(parent_id, []).append(dep_name)

    visited: set[str] = set()

    def _build_dep_tree(mod_name: str) -> dict:
        """Build dependency tree from pre-fetched data."""
        if mod_name in visited:
            return {"name": mod_name, "info": "circular", "children": []}
        visited.add(mod_name)

        mod_data = mod_by_name.get(mod_name)
        state = mod_data["state"] if mod_data else "unknown"
        mod_id = mod_data["id"] if mod_data else None

        children: list[dict] = []
        if mod_id is not None:
            for dep_name in sorted(deps_by_mod_id.get(mod_id, [])):
                children.append(_build_dep_tree(dep_name))

        return {"name": mod_name, "info": state, "children": children}

    tree_data = _build_dep_tree(module)

    root_info = f"{mod.get('shortdesc', '')} [{mod.get('state', '')}]"
    tree_data["info"] = root_info

    out.tree(
        f"Dependencies: {module}",
        [tree_data],
        data_for_json=[tree_data],
    )


@app.command("deps-reverse")
def deps_reverse(
    ctx: typer.Context,
    module: Annotated[str, typer.Argument(help="Module technical name")],
) -> None:
    """Show what modules depend on this module (reverse dependencies)."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    # Verify the module exists
    modules = c.search_read(
        "ir.module.module",
        domain=[("name", "=", module)],
        fields=["id", "name", "state"],
    )
    if not modules:
        out.error(f"Module not found: {module}")
        raise typer.Exit(1)

    # Find all dependency records pointing to this module
    deps = c.search_read(
        "ir.module.module.dependency",
        domain=[("name", "=", module)],
        fields=["module_id"],
    )

    if not deps:
        out.info(f"No modules depend on '{module}'.")
        if actx.json_mode:
            out.raw_json({"module": module, "reverse_deps": []})
        return

    # Get the parent module details
    parent_ids = [d["module_id"][0] for d in deps if isinstance(d.get("module_id"), list)]
    if not parent_ids:
        out.info(f"No modules depend on '{module}'.")
        if actx.json_mode:
            out.raw_json({"module": module, "reverse_deps": []})
        return

    parents = c.read(
        "ir.module.module",
        parent_ids,
        fields=["name", "shortdesc", "state"],
    )

    rows = []
    json_data = []
    for p in parents:
        state_display = module_state_color(p.get("state", ""))
        rows.append(
            [
                p.get("name", ""),
                p.get("shortdesc", "") or "-",
                state_display,
            ]
        )
        json_data.append(
            {
                "name": p.get("name"),
                "summary": p.get("shortdesc"),
                "state": p.get("state"),
            }
        )

    out.table(
        f"Reverse Dependencies of '{module}' ({len(parents)})",
        [("Module", ""), ("Summary", ""), ("State", "")],
        rows,
        data_for_json=json_data,
    )


@app.command()
def cloc(
    ctx: typer.Context,
    module: Annotated[str | None, typer.Option("--module", "-m", help="Filter by module name")] = None,
) -> None:
    """Show lines of code information for installed modules."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    domain: list = [("state", "=", "installed")]
    if module:
        domain.append(("name", "=", module))

    modules = c.search_read(
        "ir.module.module",
        domain=domain,
        fields=["id", "name", "shortdesc", "state", "installed_version", "author"],
        order="name",
    )

    if not modules:
        out.info("No matching installed modules found.")
        if actx.json_mode:
            out.raw_json([])
        return

    # Try to get cloc data from ir.module.module if available
    rows = []
    json_data = []
    for m in modules:
        rows.append(
            [
                str(m["id"]),
                m.get("name", ""),
                m.get("shortdesc", "") or "-",
                m.get("installed_version", "") or "-",
                m.get("author", "") or "-",
            ]
        )
        json_data.append(
            {
                "id": m["id"],
                "name": m.get("name"),
                "summary": m.get("shortdesc"),
                "version": m.get("installed_version"),
                "author": m.get("author"),
            }
        )

    out.table(
        f"Installed Modules ({len(modules)})",
        [("ID", "cyan"), ("Name", ""), ("Summary", ""), ("Version", "dim"), ("Author", "dim")],
        rows,
        data_for_json=json_data,
    )


@app.command("watch")
def watch_module(
    ctx: typer.Context,
    module: Annotated[str, typer.Argument(help="Module technical name to watch")],
    service: Annotated[str, typer.Option("--service", help="Docker service name")] = "odoo",
    interval: Annotated[int, typer.Option("--interval", help="Poll interval in seconds")] = 2,
) -> None:
    """Watch Python/XML files and auto-upgrade module on change.

    Monitors src/private/<module>/ for file changes and triggers
    module upgrade via Odoo JSON-RPC when changes are detected.
    """
    import hashlib
    import time as _time

    from kctl_odoo.core.exceptions import RPCError
    from kctl_odoo.core.utils import find_project_root

    actx: AppContext = ctx.obj
    out = actx.output

    mod_dir = find_project_root() / "src" / "private" / module
    if not mod_dir.is_dir():
        out.error(f"Module directory not found: {mod_dir}")
        raise typer.Exit(1)

    out.info(f"Watching {mod_dir} (interval={interval}s) — Ctrl+C to stop")

    def _hash_dir(d: Path) -> str:
        h = hashlib.md5()
        for f in sorted(d.rglob("*")):
            if f.is_file() and "__pycache__" not in str(f):
                h.update(f.name.encode())
                h.update(f.read_bytes())
        return h.hexdigest()

    last_hash = _hash_dir(mod_dir)

    try:
        c = actx.client
        while True:
            _time.sleep(interval)
            current_hash = _hash_dir(mod_dir)
            if current_hash != last_hash:
                last_hash = current_hash
                out.info(f"Change detected — upgrading {module}...")
                try:
                    mod_ids = c.search("ir.module.module", [("name", "=", module), ("state", "=", "installed")])
                    if mod_ids:
                        c.execute_kw("ir.module.module", "button_immediate_upgrade", [mod_ids])
                        out.info(f"Module {module} upgraded successfully.")
                    else:
                        out.info(f"Module {module} not installed — skipping upgrade.")
                except RPCError as e:
                    out.error(f"Upgrade failed: {e.detail}")
    except KeyboardInterrupt:
        out.info("Stopped watching.")


@app.command("profile")
def profile_process(ctx: typer.Context) -> None:
    """Show CPU and memory stats of the running Odoo process via JSON-RPC."""
    import time as _time

    from kctl_odoo.core.exceptions import RPCError

    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    try:
        start = _time.monotonic()
        # Use server info as a lightweight probe
        info = c.server_version()
        elapsed = round((_time.monotonic() - start) * 1000)

        out.info(f"Odoo server version: {info}")
        out.info(f"RPC latency: {elapsed}ms")
        out.info("")
        out.info("For process-level CPU/memory stats, use:")
        out.info("  docker compose stats --no-stream odoo")
        out.info("  docker compose top odoo")

    except (RPCError, AttributeError):
        # Fallback: use docker stats
        import subprocess

        try:
            result = subprocess.run(
                [
                    "docker",
                    "compose",
                    "stats",
                    "--no-stream",
                    "--format",
                    "table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}\t{{.NetIO}}\t{{.BlockIO}}",
                ],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                typer.echo(result.stdout)
            else:
                out.error("Could not get stats. Is Docker running?")
        except (FileNotFoundError, subprocess.TimeoutExpired):
            out.error("docker not found. Run: docker compose stats --no-stream")


@app.command("routes")
def list_routes(ctx: typer.Context) -> None:
    """List HTTP routes and JSON-RPC endpoints registered in Odoo."""
    from kctl_odoo.core.exceptions import RPCError

    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    try:
        # Query ir.http routes via search_read
        routes = c.search_read(
            "ir.http",
            domain=[],
            fields=["id", "name", "model", "method"],
            limit=200,
        )

        if routes:
            rows = []
            for r in routes:
                rows.append([str(r.get("id")), r.get("name", ""), r.get("model", ""), r.get("method", "")])
            out.table(
                f"HTTP Routes ({len(routes)})",
                [("ID", "cyan"), ("Name", ""), ("Model", ""), ("Method", "dim")],
                rows,
            )
        else:
            out.info("No routes found via ir.http. Routes are defined in Python controllers.")
            out.info("Check: src/private/*/controllers/ and src/private/*/services/")

    except RPCError:
        out.info("Could not query ir.http routes directly.")
        out.info("JSON-RPC endpoint: POST /web/dataset/call_kw")
        out.info("FastAPI endpoints: GET /{module}/api/openapi.json")
        out.info("Use: kctl-odoo fastapi endpoints <app> to list FastAPI routes.")


@app.command("model-info")
def model_info(
    ctx: typer.Context,
    model_name: Annotated[str, typer.Argument(help="Model name (e.g. res.partner)")],
) -> None:
    """Show detailed field information for an Odoo model."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    try:
        fields = c.fields_get(
            model_name,
            attributes=["string", "type", "required", "readonly", "help", "relation", "selection", "store"],
        )
    except RPCError as e:
        out.error(f"Could not get fields for model '{model_name}': {e.detail}")
        raise typer.Exit(1) from e

    if not fields:
        out.info(f"No fields found for model '{model_name}'.")
        if actx.json_mode:
            out.raw_json({})
        return

    rows = []
    json_data = []
    for field_name, attrs in sorted(fields.items()):
        field_type = attrs.get("type", "")
        string = attrs.get("string", "")
        required = "yes" if attrs.get("required") else ""
        readonly = "yes" if attrs.get("readonly") else ""
        stored = "yes" if attrs.get("store") else "no"
        relation = attrs.get("relation", "") or ""
        help_text = (attrs.get("help") or "")[:40]

        type_display = field_type
        if relation:
            type_display = f"{field_type} -> {relation}"
        if attrs.get("selection"):
            options = ", ".join(s[0] for s in attrs["selection"][:5])
            if len(attrs["selection"]) > 5:
                options += "..."
            type_display = f"{field_type} [{options}]"

        rows.append(
            [
                field_name,
                string,
                type_display,
                "[red]yes[/red]" if required else "",
                "[dim]yes[/dim]" if readonly else "",
                stored,
                help_text,
            ]
        )
        json_data.append(
            {
                "name": field_name,
                "string": string,
                "type": field_type,
                "required": attrs.get("required", False),
                "readonly": attrs.get("readonly", False),
                "store": attrs.get("store", True),
                "relation": relation or None,
                "help": attrs.get("help"),
                "selection": attrs.get("selection"),
            }
        )

    out.table(
        f"Model: {model_name} ({len(fields)} fields)",
        [
            ("Field", "cyan"),
            ("Label", ""),
            ("Type", ""),
            ("Required", ""),
            ("Readonly", ""),
            ("Stored", "dim"),
            ("Help", "dim"),
        ],
        rows,
        data_for_json=json_data,
    )


@app.command("find-overrides")
def find_overrides(
    ctx: typer.Context,
    model: Annotated[str, typer.Argument(help="Model name to search for overrides (e.g. res.partner)")],
) -> None:
    """List all modules that inherit/extend a model."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    # Search for modules that declare _inherit or _name for this model
    # ir.model tracks all registered models; we look at module membership via ir.model.data
    try:
        # Find the model record
        model_records = c.search_read(
            "ir.model",
            domain=[("model", "=", model)],
            fields=["id", "name", "model", "modules"],
        )
    except RPCError as e:
        out.error(f"Could not query ir.model: {e.detail}")
        raise typer.Exit(1) from e

    if not model_records:
        out.error(f"Model not found: {model}")
        raise typer.Exit(1)

    model_rec = model_records[0]
    modules_str = model_rec.get("modules") or ""
    # Odoo stores comma-separated module names in the 'modules' field
    module_list = [m.strip() for m in modules_str.split(",") if m.strip()]

    if not module_list:
        out.info(f"No module overrides found for '{model}'.")
        if actx.json_mode:
            out.raw_json({"model": model, "modules": []})
        return

    # Get state info for each module
    mod_records = c.search_read(
        "ir.module.module",
        domain=[("name", "in", module_list)],
        fields=["name", "state", "shortdesc"],
        order="name",
    )
    mod_by_name = {m["name"]: m for m in mod_records}

    rows = []
    json_data = []
    for mod_name in sorted(module_list):
        mod = mod_by_name.get(mod_name, {})
        state = mod.get("state", "unknown")
        summary = mod.get("shortdesc") or "-"
        rows.append([mod_name, summary, state])
        json_data.append({"module": mod_name, "summary": summary, "state": state})

    out.table(
        f"Modules overriding '{model}' ({len(module_list)})",
        [("Module", "cyan"), ("Summary", ""), ("State", "dim")],
        rows,
        data_for_json=json_data,
    )


@app.command("unused-xml-ids")
def unused_xml_ids(
    ctx: typer.Context,
    module: Annotated[str | None, typer.Option("--module", "-m", help="Filter by module name")] = None,
    limit: Annotated[int, typer.Option("--limit", "-l", help="Max results")] = 50,
) -> None:
    """Find XML IDs defined but potentially unreferenced."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    domain: list = []
    if module:
        domain.append(("module", "=", module))

    # Get XML IDs (ir.model.data) for the given module
    xml_ids = c.search_read(
        "ir.model.data",
        domain=domain,
        fields=["id", "name", "module", "model", "res_id"],
        limit=limit,
        order="module, model, name",
    )

    if not xml_ids:
        label = f"module '{module}'" if module else "any module"
        out.info(f"No XML IDs found for {label}.")
        if actx.json_mode:
            out.raw_json([])
        return

    # Check which XML IDs are referenced as noupdate=True (likely installed data, not menu/action)
    # We report all found XML IDs as a catalog — identifying truly "unused" ones requires
    # static analysis of XML files (not possible via RPC alone). We flag noupdate=False records
    # as potentially auto-generated and thus more likely unused.
    try:
        noupdate_ids = c.search_read(
            "ir.model.data",
            domain=domain + [("noupdate", "=", False)],
            fields=["name", "module"],
            limit=limit,
        )
        noupdate_set = {(r["module"], r["name"]) for r in noupdate_ids}
    except RPCError:
        noupdate_set = set()

    rows = []
    json_data = []
    for xid in xml_ids:
        full_id = f"{xid['module']}.{xid['name']}"
        key = (xid["module"], xid["name"])
        updatable = "yes" if key in noupdate_set else "no"
        rows.append(
            [
                full_id,
                xid.get("model") or "-",
                str(xid.get("res_id") or 0),
                updatable,
            ]
        )
        json_data.append(
            {
                "xml_id": full_id,
                "model": xid.get("model"),
                "res_id": xid.get("res_id"),
                "noupdate": key not in noupdate_set,
            }
        )

    label = f"module '{module}'" if module else "all modules"
    out.table(
        f"XML IDs for {label} ({len(xml_ids)} shown)",
        [
            ("XML ID", "cyan"),
            ("Model", ""),
            ("Res ID", "dim"),
            ("Auto-update", "dim"),
        ],
        rows,
        data_for_json=json_data,
    )
    out.info(
        "Note: 'Auto-update=yes' records can be overwritten by module updates."
        " Use static analysis to find truly unused IDs."
    )


@app.command("check-translations")
def check_translations(
    ctx: typer.Context,
    module: Annotated[str, typer.Argument(help="Module technical name")],
    lang: Annotated[str, typer.Option("--lang", help="Language code (e.g. id, fr)")] = "id",
) -> None:
    """Validate PO file placeholder consistency."""
    import re as _re

    from kctl_odoo.core.utils import find_project_root

    actx: AppContext = ctx.obj
    out = actx.output

    # Locate PO file in private modules
    project_root = find_project_root()
    po_candidates = [
        project_root / "src" / "private" / module / "i18n" / f"{lang}.po",
        project_root / "src" / "external" / module / "i18n" / f"{lang}.po",
    ]
    po_path: Path | None = None
    for candidate in po_candidates:
        if candidate.exists():
            po_path = candidate
            break

    if po_path is None:
        out.error(f"PO file not found for module '{module}', lang '{lang}'.")
        out.info(f"Looked in: {[str(c) for c in po_candidates]}")
        raise typer.Exit(1)

    po_text = po_path.read_text(encoding="utf-8")

    # Parse msgid/msgstr pairs
    PLACEHOLDER_RE = _re.compile(r"%(?:\(\w+\))?[sdifr%]|{[\w:,!.]*}")

    entries = []
    current_id: str | None = None
    current_str: str | None = None
    in_msgid = False
    in_msgstr = False

    for line in po_text.splitlines():
        if line.startswith("msgid "):
            if current_id is not None and current_str is not None:
                entries.append((current_id, current_str))
            current_id = line[7:-1]  # strip 'msgid "' and trailing '"'
            current_str = None
            in_msgid = True
            in_msgstr = False
        elif line.startswith("msgstr "):
            current_str = line[8:-1]
            in_msgid = False
            in_msgstr = True
        elif line.startswith('"') and in_msgid and current_id is not None:
            current_id += line[1:-1]
        elif line.startswith('"') and in_msgstr and current_str is not None:
            current_str += line[1:-1]
        elif not line.strip():
            in_msgid = in_msgstr = False

    if current_id is not None and current_str is not None:
        entries.append((current_id, current_str))

    mismatches = []
    for msgid, msgstr in entries:
        if not msgid or not msgstr:
            continue
        id_placeholders = sorted(PLACEHOLDER_RE.findall(msgid))
        str_placeholders = sorted(PLACEHOLDER_RE.findall(msgstr))
        if id_placeholders != str_placeholders:
            mismatches.append(
                {
                    "msgid": msgid[:80],
                    "msgid_placeholders": id_placeholders,
                    "msgstr_placeholders": str_placeholders,
                }
            )

    if not mismatches:
        out.success(f"PO file OK: {po_path} ({len(entries)} entries, no placeholder mismatches)")
        if actx.json_mode:
            out.raw_json({"file": str(po_path), "entries": len(entries), "mismatches": 0})
        return

    rows = []
    for m in mismatches:
        rows.append(
            [
                m["msgid"][:60],
                ", ".join(m["msgid_placeholders"]) or "(none)",
                ", ".join(m["msgstr_placeholders"]) or "(none)",
            ]
        )

    out.table(
        f"Placeholder Mismatches in {po_path.name} ({len(mismatches)} found)",
        [
            ("msgid (truncated)", ""),
            ("Source placeholders", "cyan"),
            ("Translation placeholders", "yellow"),
        ],
        rows,
        data_for_json=mismatches,
    )
    out.warn(f"Found {len(mismatches)} placeholder mismatch(es) in {po_path}")
