"""Development tools for Odoo — split into focused sub-modules."""

from __future__ import annotations

import typer

from .analysis import app as _analysis_app
from .analysis import (
    assets_regenerate,
    check_translations,
    cloc,
    deps_reverse,
    deps_tree,
    find_overrides,
    list_routes,
    model_info,
    profile_process,
    unused_xml_ids,
    watch_module,
)
from .audit import app as _audit_app
from .audit import (
    audit,
    audit_api,
    audit_blocking,
    audit_compute,
    audit_fix,
    audit_logic,
    audit_ou,
    audit_prompt,
    audit_ui,
    audit_views,
    check_log_level,
)
from .codegen import app as _codegen_app
from .codegen import clear_field_cache_cmd, generate_cmd, model_fields_cmd
from .dev_mode import app as _dev_mode_app
from .quality import app as _quality_app
from .quality import check_conventions, coverage_report, module_health, release_check
from .translations import app as _translations_app
from .translations import translate_export, translate_import, translate_languages

app = typer.Typer(help="Development tools for Odoo.")

# Merge all registered commands into this app
for _sub in [_translations_app, _analysis_app, _quality_app, _codegen_app, _audit_app, _dev_mode_app]:
    for _cmd in _sub.registered_commands:
        app.registered_commands.append(_cmd)
    for _grp in _sub.registered_groups:
        app.registered_groups.append(_grp)

__all__ = [
    "app",
    "translate_export",
    "translate_import",
    "translate_languages",
    "assets_regenerate",
    "check_translations",
    "cloc",
    "deps_reverse",
    "deps_tree",
    "find_overrides",
    "list_routes",
    "model_info",
    "profile_process",
    "unused_xml_ids",
    "watch_module",
    "module_health",
    "check_conventions",
    "coverage_report",
    "release_check",
    "generate_cmd",
    "model_fields_cmd",
    "clear_field_cache_cmd",
    "audit",
    "audit_fix",
    "audit_prompt",
    "audit_views",
    "audit_compute",
    "audit_blocking",
    "check_log_level",
    "audit_api",
    "audit_logic",
    "audit_ou",
    "audit_ui",
]
