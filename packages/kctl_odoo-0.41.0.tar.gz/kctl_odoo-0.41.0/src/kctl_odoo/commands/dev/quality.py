"""Quality check commands for Odoo dev tools."""

from __future__ import annotations

from pathlib import Path

import typer

from kctl_odoo.core.callbacks import AppContext

app = typer.Typer()


@app.command("module-health")
def module_health(ctx: typer.Context, module: str) -> None:
    """Comprehensive health check for a single private module.

    Runs all quality checks and produces a scorecard:
    - Manifest: valid, version format, description, depends
    - Security: ir.model.access.csv coverage for all models
    - Tests: test files exist, test count
    - Docs: CLAUDE.md exists
    - Python: no f-string SQL, no N+1 patterns
    - XML: no deprecated attributes
    - Fields: namespace convention compliance
    - FastAPI: router count, schema count (if applicable)

    Examples:
        kctl-odoo dev module-health sfa_management
        kctl-odoo dev module-health base_management --json
    """
    import ast
    import re

    actx: AppContext = ctx.obj
    out = actx.output

    private_dir = Path.cwd() / "src" / "private"
    mod_dir = private_dir / module

    if not mod_dir.exists() or not (mod_dir / "__manifest__.py").exists():
        out.error(f"Module not found: {module}")
        raise typer.Exit(1)

    scores = {}
    total = 0
    passed = 0

    # 1. Manifest check
    manifest_file = mod_dir / "__manifest__.py"
    try:
        manifest = ast.literal_eval(manifest_file.read_text())
        has_version = bool(manifest.get("version"))
        has_description = bool(manifest.get("description"))
        has_depends = bool(manifest.get("depends"))
        installable = manifest.get("installable", True)
        manifest_ok = all([has_version, has_description, has_depends, installable])
    except (OSError, ValueError, SyntaxError):
        manifest_ok = False
    scores["Manifest"] = "PASS" if manifest_ok else "FAIL"
    total += 1
    passed += 1 if manifest_ok else 0

    # 2. Security check
    csv_path = mod_dir / "security" / "ir.model.access.csv"
    has_security = csv_path.exists() and csv_path.stat().st_size > 50
    scores["Security (ACL)"] = "PASS" if has_security else "FAIL"
    total += 1
    passed += 1 if has_security else 0

    # 3. Tests check
    tests_dir = mod_dir / "tests"
    test_files = list(tests_dir.glob("test_*.py")) if tests_dir.exists() else []
    test_count = 0
    for tf in test_files:
        test_count += len(re.findall(r"def test_", tf.read_text()))
    has_tests = len(test_files) > 0
    scores[f"Tests ({test_count} tests in {len(test_files)} files)"] = "PASS" if has_tests else "FAIL"
    total += 1
    passed += 1 if has_tests else 0

    # 4. CLAUDE.md check
    has_claude_md = (mod_dir / "CLAUDE.md").exists()
    scores["Documentation (CLAUDE.md)"] = "PASS" if has_claude_md else "FAIL"
    total += 1
    passed += 1 if has_claude_md else 0

    # 5. Python quality (f-string SQL)
    py_issues = 0
    models_dir = mod_dir / "models"
    services_dir = mod_dir / "services"
    for search_dir in [models_dir, services_dir]:
        if search_dir.exists():
            for py_file in search_dir.rglob("*.py"):
                if "__pycache__" in str(py_file):
                    continue
                content = py_file.read_text(errors="ignore")
                for line in content.splitlines():
                    if ("f'" in line or 'f"' in line) and any(
                        kw in line.lower() for kw in ["select ", "insert ", "update ", "delete ", "create table"]
                    ):
                        py_issues += 1
    py_ok = py_issues == 0
    scores[f"Python quality ({py_issues} SQL f-strings)"] = "PASS" if py_ok else "WARN"
    total += 1
    passed += 1 if py_ok else 0

    # 6. XML views check
    xml_issues = 0
    views_dir = mod_dir / "views"
    if views_dir.exists():
        for xml_file in views_dir.rglob("*.xml"):
            content = xml_file.read_text(errors="ignore")
            if "states=" in content or "<tree" in content:
                xml_issues += 1
    xml_ok = xml_issues == 0
    scores[f"XML views ({xml_issues} deprecated patterns)"] = "PASS" if xml_ok else "WARN"
    total += 1
    passed += 1 if xml_ok else 0

    # 7. FastAPI check (if applicable)
    controllers_dir = mod_dir / "controllers"
    routers = list(controllers_dir.glob("*_router.py")) if controllers_dir.exists() else []
    schemas_dir = mod_dir / "schemas"
    schemas = list(schemas_dir.glob("*_schema.py")) if schemas_dir.exists() else []
    if routers or schemas:
        scores[f"FastAPI ({len(routers)} routers, {len(schemas)} schemas)"] = "INFO"

    # Display scorecard
    pct = round(passed / total * 100) if total > 0 else 0
    rows = [[check, status] for check, status in scores.items()]

    out.table(
        f"Module Health: {module} — {pct}% ({passed}/{total})",
        [("Check", ""), ("Status", "")],
        rows,
    )


@app.command("check-conventions")
def check_conventions(ctx: typer.Context, module: str | None = None) -> None:
    """Check Kodemeio coding conventions across private modules.

    Validates:
    - Field namespace prefixes on inherited models
    - CLAUDE.md exists
    - Tests directory exists with at least one test
    - security/ir.model.access.csv exists
    - __manifest__.py has required keys

    Examples:
        kctl-odoo dev check-conventions
        kctl-odoo dev check-conventions sfa_management
    """
    actx: AppContext = ctx.obj
    out = actx.output

    private_dir = Path.cwd() / "src" / "private"
    if module:
        modules = [module]
    else:
        modules = sorted([d.name for d in private_dir.iterdir() if d.is_dir() and (d / "__manifest__.py").exists()])

    issues = []
    for mod_name in modules:
        mod_dir = private_dir / mod_name

        # Check CLAUDE.md
        if not (mod_dir / "CLAUDE.md").exists():
            issues.append([mod_name, "CLAUDE.md missing", "FAIL"])

        # Check tests/
        tests_dir = mod_dir / "tests"
        if not tests_dir.exists() or not list(tests_dir.glob("test_*.py")):
            issues.append([mod_name, "No test files in tests/", "FAIL"])

        # Check security
        csv_path = mod_dir / "security" / "ir.model.access.csv"
        if not csv_path.exists():
            issues.append([mod_name, "security/ir.model.access.csv missing", "FAIL"])

    if not issues:
        out.success(f"All {len(modules)} modules pass convention checks.")
    else:
        out.table(
            f"Convention Issues ({len(issues)})",
            [("Module", ""), ("Issue", ""), ("Severity", "")],
            issues,
        )
        raise typer.Exit(1)


@app.command("coverage-report")
def coverage_report(ctx: typer.Context) -> None:
    """Show test coverage summary across all private modules.

    Lists each module with:
    - Number of test files
    - Number of test functions
    - Whether tests exist at all

    Examples:
        kctl-odoo dev coverage-report
        kctl-odoo dev coverage-report --json
    """
    import re

    actx: AppContext = ctx.obj
    out = actx.output

    private_dir = Path.cwd() / "src" / "private"
    modules = sorted([d.name for d in private_dir.iterdir() if d.is_dir() and (d / "__manifest__.py").exists()])

    rows = []
    total_files = 0
    total_tests = 0
    modules_with_tests = 0

    for mod_name in modules:
        tests_dir = private_dir / mod_name / "tests"
        if tests_dir.exists():
            test_files = list(tests_dir.glob("test_*.py"))
            file_count = len(test_files)
            test_count = 0
            for tf in test_files:
                test_count += len(re.findall(r"def test_", tf.read_text(errors="ignore")))
            total_files += file_count
            total_tests += test_count
            if file_count > 0:
                modules_with_tests += 1
            status = "OK" if file_count > 0 else "NONE"
        else:
            file_count = 0
            test_count = 0
            status = "NONE"

        rows.append([mod_name, str(file_count), str(test_count), status])

    out.table(
        f"Test Coverage — {modules_with_tests}/{len(modules)} modules have tests, {total_tests} total test functions",
        [("Module", ""), ("Files", ""), ("Tests", ""), ("Status", "")],
        rows,
    )


@app.command("release-check")
def release_check(ctx: typer.Context, module: str) -> None:
    """Pre-release validation for a module before version bump.

    Checks everything needed before releasing a module:
    1. Manifest is valid with correct version format
    2. All models have security rules
    3. Tests exist and module has CLAUDE.md
    4. No TODO/FIXME/HACK in Python code
    5. No deprecated XML patterns
    6. Changelog entry exists

    Examples:
        kctl-odoo dev release-check sfa_management
    """
    import ast
    import re

    actx: AppContext = ctx.obj
    out = actx.output

    private_dir = Path.cwd() / "src" / "private"
    mod_dir = private_dir / module

    if not mod_dir.exists():
        out.error(f"Module not found: {module}")
        raise typer.Exit(1)

    checks = []
    all_pass = True

    # 1. Manifest
    try:
        manifest = ast.literal_eval((mod_dir / "__manifest__.py").read_text())
        version = manifest.get("version", "")
        if re.match(r"^18\.0\.\d+\.\d+\.\d+$", version):
            checks.append(["Manifest version", version, "PASS"])
        else:
            checks.append(["Manifest version", f"Invalid: {version}", "FAIL"])
            all_pass = False
    except (OSError, ValueError, SyntaxError) as e:
        checks.append(["Manifest", str(e)[:60], "FAIL"])
        all_pass = False

    # 2. Security
    csv_path = mod_dir / "security" / "ir.model.access.csv"
    if csv_path.exists() and csv_path.stat().st_size > 50:
        checks.append(["Security (ACL)", "ir.model.access.csv exists", "PASS"])
    else:
        checks.append(["Security (ACL)", "Missing or empty", "FAIL"])
        all_pass = False

    # 3. Tests
    tests_dir = mod_dir / "tests"
    test_files = list(tests_dir.glob("test_*.py")) if tests_dir.exists() else []
    if test_files:
        checks.append(["Tests", f"{len(test_files)} test file(s)", "PASS"])
    else:
        checks.append(["Tests", "No test files", "FAIL"])
        all_pass = False

    # 4. CLAUDE.md
    if (mod_dir / "CLAUDE.md").exists():
        checks.append(["Documentation", "CLAUDE.md exists", "PASS"])
    else:
        checks.append(["Documentation", "CLAUDE.md missing", "FAIL"])
        all_pass = False

    # 5. TODO/FIXME/HACK scan
    todo_count = 0
    for py_file in mod_dir.rglob("*.py"):
        if "__pycache__" in str(py_file):
            continue
        content = py_file.read_text(errors="ignore")
        todo_count += len(re.findall(r"#\s*(TODO|FIXME|HACK|XXX)\b", content, re.IGNORECASE))
    if todo_count == 0:
        checks.append(["Code TODOs", "None found", "PASS"])
    else:
        checks.append(["Code TODOs", f"{todo_count} TODO/FIXME/HACK found", "WARN"])

    # 6. Changelog
    changelog = mod_dir / "CHANGELOG.md"
    if changelog.exists():
        checks.append(["Changelog", "CHANGELOG.md exists", "PASS"])
    else:
        checks.append(["Changelog", "CHANGELOG.md missing", "WARN"])

    status = "READY" if all_pass else "NOT READY"
    out.table(
        f"Release Check: {module} — {status}",
        [("Check", ""), ("Detail", ""), ("Status", "")],
        checks,
    )

    if not all_pass:
        raise typer.Exit(1)
