"""Translation commands for Odoo dev tools."""

from __future__ import annotations

import base64
from pathlib import Path
from typing import Annotated

import typer

from kctl_odoo.core.callbacks import AppContext
from kctl_odoo.core.exceptions import RPCError

app = typer.Typer()


@app.command("export-translations")
def translate_export(
    ctx: typer.Context,
    module: Annotated[str, typer.Argument(help="Module technical name to export translations for")],
    lang: Annotated[str, typer.Option("--lang", help="Language code (e.g. fr_FR, de_DE)")] = "en_US",
    fmt: Annotated[str, typer.Option("--format", "-f", help="Export format: po or csv")] = "po",
    output: Annotated[str | None, typer.Option("--output", "-o", help="Output file path")] = None,
) -> None:
    """Export translations for a module using the base.language.export wizard."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    if fmt not in ("po", "csv"):
        out.error("Format must be 'po' or 'csv'.")
        raise typer.Exit(1)

    # Verify the module exists
    mod_ids = c.search("ir.module.module", [("name", "=", module)])
    if not mod_ids:
        out.error(f"Module not found: {module}")
        raise typer.Exit(1)

    # Create the export wizard
    wizard_vals = {
        "lang": lang,
        "format": fmt,
        "modules": [(6, 0, mod_ids)],
    }
    try:
        wizard_id = c.create("base.language.export", wizard_vals)
    except RPCError as e:
        out.error(f"Failed to create export wizard: {e.detail}")
        raise typer.Exit(1) from e

    # Trigger the export action
    try:
        c.execute_kw("base.language.export", "act_getfile", [[wizard_id]])
    except RPCError as e:
        out.error(f"Failed to export translations: {e.detail}")
        raise typer.Exit(1) from e

    # Read the generated file data
    wizard_data = c.read("base.language.export", [wizard_id], ["data", "name"])
    if not wizard_data or not wizard_data[0].get("data"):
        out.error("No translation data returned by the wizard.")
        raise typer.Exit(1)

    file_data = base64.b64decode(wizard_data[0]["data"])
    file_name = wizard_data[0].get("name") or f"{module}.{fmt}"

    output_path = Path(output) if output else Path(file_name)
    output_path.write_bytes(file_data)

    out.success(f"Exported translations to {output_path} ({len(file_data)} bytes)")
    if actx.json_mode:
        out.raw_json(
            {
                "module": module,
                "lang": lang,
                "format": fmt,
                "file": str(output_path),
                "size": len(file_data),
            }
        )


@app.command("import-translations")
def translate_import(
    ctx: typer.Context,
    file: Annotated[str, typer.Argument(help="Path to PO or CSV translation file")],
    lang: Annotated[str, typer.Option("--lang", help="Language code (e.g. fr_FR)")] = "",
    overwrite: Annotated[bool, typer.Option("--overwrite", help="Overwrite existing translations")] = False,
) -> None:
    """Import translations from a PO or CSV file."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    file_path = Path(file)
    if not file_path.exists():
        out.error(f"File not found: {file}")
        raise typer.Exit(1)

    suffix = file_path.suffix.lower()
    if suffix == ".po":
        file_type = "po"
    elif suffix == ".csv":
        file_type = "csv"
    else:
        out.error("File must be .po or .csv format.")
        raise typer.Exit(1)

    if not lang:
        out.error("--lang is required (e.g. --lang fr_FR).")
        raise typer.Exit(1)

    file_content = base64.b64encode(file_path.read_bytes()).decode("ascii")

    wizard_vals = {
        "name": file_path.name,
        "code": lang,
        "data": file_content,
        "filename": file_path.name,
        "overwrite": overwrite,
    }
    try:
        wizard_id = c.create("base.language.import", wizard_vals)
        c.execute_kw("base.language.import", "import_lang", [[wizard_id]])
    except RPCError as e:
        out.error(f"Failed to import translations: {e.detail}")
        raise typer.Exit(1) from e

    out.success(f"Imported translations from {file_path.name} for language {lang}")
    if actx.json_mode:
        out.raw_json(
            {
                "file": str(file_path),
                "lang": lang,
                "format": file_type,
                "overwrite": overwrite,
            }
        )


@app.command("languages")
def translate_languages(ctx: typer.Context) -> None:
    """List installed and available languages."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    # Get installed languages
    installed = c.search_read(
        "res.lang",
        domain=[("active", "=", True)],
        fields=["id", "name", "code", "iso_code", "direction"],
        order="name",
    )

    rows = []
    json_data = []
    for lang in installed:
        direction = lang.get("direction", "ltr")
        rows.append(
            [
                str(lang["id"]),
                lang.get("name", ""),
                lang.get("code", ""),
                lang.get("iso_code", "") or "-",
                direction,
                "[green]installed[/green]",
            ]
        )
        json_data.append(
            {
                "id": lang["id"],
                "name": lang.get("name"),
                "code": lang.get("code"),
                "iso_code": lang.get("iso_code"),
                "direction": direction,
                "status": "installed",
            }
        )

    out.table(
        f"Languages ({len(installed)} installed)",
        [("ID", "cyan"), ("Name", ""), ("Code", ""), ("ISO Code", "dim"), ("Direction", "dim"), ("Status", "")],
        rows,
        data_for_json=json_data,
    )
