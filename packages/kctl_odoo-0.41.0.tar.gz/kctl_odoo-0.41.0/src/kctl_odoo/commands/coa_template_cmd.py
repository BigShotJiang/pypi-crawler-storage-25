"""COA Template catalog commands.

Manage the canonical chart-of-accounts template (company.coa.template.line)
that drives per-tenant account.account generation. See
docs/superpowers/specs/2026-05-21-coa-template-multi-tenant-design.md.

Commands:
    list        Browse template lines with filters
    create      Create one template line (CLI args)
    seed        Inventory an accurate.company's JV cache and bulk-create lines
    export      Export the catalog to Excel
    import      Bulk-import template lines from Excel
    delete      Delete a template line by code
    stats       Counts per account_type, commodity, kind
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

from kctl_odoo.core.callbacks import AppContext
from kctl_odoo.core.exceptions import ConnectionError, RPCError

app = typer.Typer(help="Canonical COA template catalog (company.coa.template.line).")


# ─── Accurate → Odoo type mapping (shared with seed) ───
_ACC_TO_ODOO = {
    "CASH_BANK": "asset_cash",
    "ACCOUNT_RECEIVABLE": "asset_receivable",
    "INVENTORY": "asset_current",
    "FIXED_ASSET": "asset_fixed",
    "OTHER_CURRENT_ASSET": "asset_current",
    "OTHER_ASSET": "asset_non_current",
    "ACCOUNT_PAYABLE": "liability_payable",
    "OTHER_CURRENT_LIABILITY": "liability_current",
    "LONG_TERM_LIABILITY": "liability_non_current",
    "EQUITY": "equity",
    "REVENUE": "income",
    "COGS": "expense_direct_cost",
    "EXPENSE": "expense",
    "OTHER_INCOME": "income_other",
    "OTHER_EXPENSE": "expense",
}

_COMMODITY_KEYWORDS = {
    "Garlic": ["bawang putih"],
    "Onion": ["bawang merah", "bawang bombay"],
    "Chili": ["cabe", "cabai"],
    "Peanut": ["kacang"],
    "Mung Bean": ["kacang hijau"],
    "Wheat": ["gandum"],
}


def _kind_from_type(odoo_type: str, name: str) -> str:
    n = (name or "").lower()
    if odoo_type == "income":
        return "sales"
    if odoo_type == "expense_direct_cost":
        return "cogs"
    if odoo_type == "asset_current" and "persed" in n:
        return "inventory"
    if odoo_type == "expense":
        return "opex"
    if odoo_type == "asset_cash":
        return "bank"
    if odoo_type == "asset_receivable":
        return "ar"
    if odoo_type == "liability_payable":
        return "ap"
    if odoo_type == "equity":
        return "equity"
    return "other"


def _guess_commodity_name(name: str) -> str | None:
    nm = (name or "").lower()
    for commodity, keys in _COMMODITY_KEYWORDS.items():
        for k in keys:
            if k in nm:
                return commodity
    return None


def _commodity_id(c, commodity_name: str | None) -> int | bool:
    if not commodity_name:
        return False
    rec = c.search_read(
        "res.company.commodity",
        domain=[("name", "=", commodity_name)],
        fields=["id"],
        limit=1,
    )
    return rec[0]["id"] if rec else False


# ────────────────────────────────────────────────────────────────────────
# list
# ────────────────────────────────────────────────────────────────────────


@app.command("list")
def list_(
    ctx: typer.Context,
    code: Annotated[str | None, typer.Option("--code", help="Filter by code (ilike)")] = None,
    name: Annotated[str | None, typer.Option("--name", help="Filter by name (ilike)")] = None,
    account_type: Annotated[str | None, typer.Option("--type", help="Filter by account_type")] = None,
    commodity: Annotated[str | None, typer.Option("--commodity", help="Filter by commodity name")] = None,
    kind: Annotated[str | None, typer.Option("--kind", help="Filter by kind")] = None,
    inactive: Annotated[bool, typer.Option("--inactive", help="Include inactive lines")] = False,
    limit: Annotated[int, typer.Option("--limit", "-l")] = 200,
) -> None:
    """List template lines with optional filters."""
    actx: AppContext = ctx.obj
    out, c = actx.output, actx.client
    domain = []
    if code:
        domain.append(("code", "ilike", code))
    if name:
        domain.append(("name", "ilike", name))
    if account_type:
        domain.append(("account_type", "=", account_type))
    if kind:
        domain.append(("kind", "=", kind))
    if commodity:
        commodity_rec = c.search("res.company.commodity", [("name", "=", commodity)], limit=1)
        if commodity_rec:
            domain.append(("commodity_id", "=", commodity_rec[0]))
        else:
            out.error(f"Commodity not found: {commodity}")
            raise typer.Exit(1)
    if not inactive:
        domain.append(("is_active", "=", True))

    rows = c.search_read(
        "company.coa.template.line",
        domain=domain,
        fields=[
            "code",
            "name_id",
            "name_en",
            "account_type",
            "kind",
            "commodity_id",
            "is_active",
            "instance_count",
        ],
        order="code",
        limit=limit,
    )
    if not rows:
        out.info("No template lines match the filters.")
        return

    table_rows = []
    for r in rows:
        commodity_name = r["commodity_id"][1] if r["commodity_id"] else "-"
        table_rows.append(
            [
                r["code"],
                r.get("name_id") or "-",
                r.get("name_en") or "-",
                r["account_type"],
                r["kind"],
                commodity_name,
                str(r["instance_count"]),
                "✓" if r["is_active"] else "✗",
            ]
        )
    out.table(
        f"COA Template ({len(rows)} lines)",
        [
            ("Code", ""),
            ("Name", ""),
            ("Description EN", "dim"),
            ("Account Type", "dim"),
            ("Kind", "dim"),
            ("Commodity", "dim"),
            ("Inst.", "dim"),
            ("Active", ""),
        ],
        table_rows,
        data_for_json=rows,
    )


# ────────────────────────────────────────────────────────────────────────
# create
# ────────────────────────────────────────────────────────────────────────


@app.command("create")
def create(
    ctx: typer.Context,
    code: Annotated[str, typer.Option("--code", help="Canonical account code, e.g. 5000.01")],
    name_id: Annotated[str, typer.Option("--name-id", help="Canonical Indonesian name")],
    account_type: Annotated[str, typer.Option("--type", help="Odoo account_type, e.g. expense")],
    name_en: Annotated[str, typer.Option("--name-en", help="Canonical English name")] = "",
    commodity: Annotated[str, typer.Option("--commodity", help="Commodity name")] = "",
    kind: Annotated[str, typer.Option("--kind", help="Functional kind (sales/cogs/opex/...)")] = "other",
    notes: Annotated[str, typer.Option("--notes", help="Operator notes")] = "",
) -> None:
    """Create one template line."""
    actx: AppContext = ctx.obj
    out, c = actx.output, actx.client
    vals = {
        "code": code,
        "name_id": name_id,
        "name_en": name_en,
        "account_type": account_type,
        "kind": kind,
        "notes": notes,
        "is_active": True,
        "commodity_id": _commodity_id(c, commodity) if commodity else False,
    }
    try:
        new_ids = c.execute_kw("company.coa.template.line", "create", [vals])
    except (ConnectionError, RPCError, ValueError) as exc:
        out.error(f"Create failed: {exc}")
        raise typer.Exit(1)
    out.success(f"Created template line id={new_ids} code={code}")


# ────────────────────────────────────────────────────────────────────────
# seed
# ────────────────────────────────────────────────────────────────────────


@app.command("seed")
def seed(
    ctx: typer.Context,
    slug: Annotated[str, typer.Argument(help="Accurate company slug")],
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Preview only, no writes")] = False,
) -> None:
    """Inventory an accurate.company's JV cache → bulk-create template lines.

    Idempotent: skips template lines whose code already exists.
    Heuristics:
    - account_type derived from Accurate accountType
    - commodity_id auto-detected from name (Bawang Putih → Garlic, etc.)
    - kind derived from account_type + name pattern
    - code defaults to Accurate's `no` (operator can adjust later)
    """
    actx: AppContext = ctx.obj
    out, c = actx.output, actx.client

    cos = c.search_read(
        "accurate.company",
        domain=[("slug", "=", slug)],
        fields=["id", "slug"],
        limit=1,
    )
    if not cos:
        out.error(f"Accurate company not found: {slug}")
        raise typer.Exit(1)
    acc_id = cos[0]["id"]

    out.info(f"Inventorying JV cache for {slug} (acc.company id={acc_id})...")
    jvs = c.search_read(
        "accurate.journal.voucher",
        domain=[("company_id", "=", acc_id)],
        fields=["accurate_id", "detail"],
    )
    out.info(f"Cached JVs: {len(jvs)}")

    seen: dict[int, dict] = {}
    for jv in jvs:
        d = jv.get("detail") or {}
        if isinstance(d, str) and d.strip():
            try:
                d = json.loads(d)
            except json.JSONDecodeError:
                continue
        if not isinstance(d, dict):
            continue
        for line in d.get("detailJournalVoucher", []) or []:
            gl = line.get("glAccount") or {}
            if not isinstance(gl, dict):
                continue
            gid = gl.get("id")
            no = gl.get("no")
            if not gid or not no or gid in seen:
                continue
            seen[gid] = {
                "no": no,
                "name": gl.get("name") or "",
                "accurate_type": gl.get("accountType") or "",
            }
    out.info(f"Distinct Accurate gl accounts: {len(seen)}")

    # Existing template codes
    existing = set()
    for r in c.search_read("company.coa.template.line", domain=[], fields=["code"], limit=100000):
        existing.add(r["code"])

    plan = []
    for gid, info in sorted(seen.items(), key=lambda x: (x[1]["accurate_type"], x[1]["no"])):
        if info["no"] in existing:
            continue
        odoo_type = _ACC_TO_ODOO.get(info["accurate_type"], "asset_current")
        commodity_name = _guess_commodity_name(info["name"])
        kind = _kind_from_type(odoo_type, info["name"])
        plan.append(
            {
                "code": info["no"],
                "name_id": info["name"],
                "name_en": "",
                "account_type": odoo_type,
                "kind": kind,
                "commodity_id": _commodity_id(c, commodity_name),
                "_commodity_name": commodity_name or "-",
                "_accurate_gl_id": gid,
                "_accurate_type": info["accurate_type"],
                "is_active": True,
                "notes": f"Seeded from {slug} Accurate gl_id={gid} type={info['accurate_type']}",
            }
        )

    if not plan:
        out.success(f"All {len(seen)} Accurate gl accounts already covered. Nothing to create.")
        return

    table_rows = []
    for p in plan:
        table_rows.append(
            [
                p["code"],
                p["name_id"][:40],
                p["account_type"],
                p["kind"],
                p["_commodity_name"],
                str(p["_accurate_gl_id"]),
            ]
        )
    out.table(
        f"Would create {len(plan)} template lines" + (" (DRY-RUN)" if dry_run else ""),
        [
            ("Code", ""),
            ("Name", ""),
            ("Account Type", "dim"),
            ("Kind", "dim"),
            ("Commodity", "dim"),
            ("Acc GL ID", "dim"),
        ],
        table_rows,
    )
    if dry_run:
        out.info("Dry-run only. Re-run without --dry-run to create.")
        return

    create_vals = [{k: v for k, v in p.items() if not k.startswith("_")} for p in plan]
    new_ids = c.execute_kw("company.coa.template.line", "create", [create_vals])
    out.success(f"Created {len(new_ids) if isinstance(new_ids, list) else 1} template lines.")


# ────────────────────────────────────────────────────────────────────────
# export / import
# ────────────────────────────────────────────────────────────────────────


@app.command("export")
def export(
    ctx: typer.Context,
    output: Annotated[Path, typer.Option("-o", "--output", help="Output Excel path")] = Path("coa_template.xlsx"),
) -> None:
    """Export the full catalog to Excel for offline review/editing."""
    actx: AppContext = ctx.obj
    out, c = actx.output, actx.client
    try:
        import openpyxl
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.utils import get_column_letter
    except ImportError:
        out.error("openpyxl is required for export. Install: uv pip install openpyxl")
        raise typer.Exit(1)

    rows = c.search_read(
        "company.coa.template.line",
        domain=[],
        fields=[
            "code",
            "name_id",
            "name_en",
            "account_type",
            "is_reconcile",
            "line_type",
            "kind",
            "commodity_id",
            "is_active",
            "notes",
            "instance_count",
        ],
        order="code",
    )

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "COA Template"
    hdr = [
        "code",
        "name_id",
        "name_en",
        "account_type",
        "is_reconcile",
        "line_type",
        "kind",
        "commodity",
        "is_active",
        "notes",
        "instance_count",
    ]
    for col, h in enumerate(hdr, 1):
        c_ = ws.cell(row=1, column=col, value=h)
        c_.font = Font(bold=True, color="FFFFFF")
        c_.fill = PatternFill("solid", fgColor="2F5496")
        c_.alignment = Alignment(horizontal="center")
    for r in rows:
        ws.append(
            [
                r["code"],
                r.get("name_id") or "",
                r.get("name_en") or "",
                r["account_type"],
                "TRUE" if r.get("is_reconcile") else "FALSE",
                r.get("line_type") or "",
                r["kind"],
                (r["commodity_id"][1] if r["commodity_id"] else ""),
                "TRUE" if r["is_active"] else "FALSE",
                r.get("notes") or "",
                r["instance_count"],
            ]
        )
    widths = [14, 40, 40, 22, 14, 12, 14, 10, 30, 8]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(hdr))}{len(rows) + 1}"

    wb.save(str(output))
    out.success(f"Exported {len(rows)} lines → {output}")


@app.command("import")
def import_(
    ctx: typer.Context,
    input_path: Annotated[Path, typer.Option("-i", "--input", help="Input Excel path")],
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Preview without writes")] = False,
    upsert: Annotated[bool, typer.Option("--upsert", help="Update existing codes; else skip")] = False,
) -> None:
    """Bulk-import template lines from an Excel file.

    Excel must have columns matching `export` output (code, name_id,
    name_en, account_type, line_type, kind, commodity, is_active, notes).
    """
    actx: AppContext = ctx.obj
    out, c = actx.output, actx.client
    try:
        import openpyxl
    except ImportError:
        out.error("openpyxl required.")
        raise typer.Exit(1)

    if not input_path.exists():
        out.error(f"File not found: {input_path}")
        raise typer.Exit(1)

    wb = openpyxl.load_workbook(str(input_path))
    ws = wb.active
    header = [cell.value for cell in ws[1]]
    idx = {h: header.index(h) for h in header if h}
    required = {"code", "name_id", "account_type"}
    missing = required - set(idx.keys())
    if missing:
        out.error(f"Excel missing required columns: {missing}")
        raise typer.Exit(1)

    def _g(row, col):
        return row[idx[col]] if col in idx else None

    rows = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not _g(row, "code"):
            continue
        rows.append(
            {
                "code": str(_g(row, "code")).strip(),
                "name_id": str(_g(row, "name_id") or "").strip(),
                "name_en": str(_g(row, "name_en") or "").strip(),
                "account_type": str(_g(row, "account_type") or "").strip(),
                "line_type": str(_g(row, "line_type") or "leaf").strip(),
                "kind": str(_g(row, "kind") or "other").strip(),
                "commodity": str(_g(row, "commodity") or "").strip(),
                "is_active": (str(_g(row, "is_active") or "TRUE").strip().upper() != "FALSE"),
                "notes": str(_g(row, "notes") or "").strip(),
            }
        )

    existing = {
        r["code"]: r["id"]
        for r in c.search_read("company.coa.template.line", domain=[], fields=["id", "code"], limit=100000)
    }

    to_create, to_update, skipped = [], [], 0
    for r in rows:
        vals = {
            "code": r["code"],
            "name_id": r["name_id"],
            "name_en": r["name_en"],
            "account_type": r["account_type"],
            "line_type": r["line_type"],
            "kind": r["kind"],
            "commodity_id": _commodity_id(c, r["commodity"]) if r["commodity"] else False,
            "is_active": bool(r["is_active"]),
            "notes": r["notes"],
        }
        if r["code"] in existing:
            if upsert:
                to_update.append((existing[r["code"]], vals))
            else:
                skipped += 1
        else:
            to_create.append(vals)

    out.info(
        f"Plan: create={len(to_create)}  update={len(to_update)}  skipped={skipped}" + (" (DRY-RUN)" if dry_run else "")
    )
    if dry_run:
        return

    created = 0
    if to_create:
        new_ids = c.execute_kw("company.coa.template.line", "create", [to_create])
        created = len(new_ids) if isinstance(new_ids, list) else 1
    updated = 0
    for tid, vals in to_update:
        c.execute_kw("company.coa.template.line", "write", [[tid], vals])
        updated += 1
    out.success(f"Created {created}, updated {updated}, skipped {skipped}.")


# ────────────────────────────────────────────────────────────────────────
# delete + stats
# ────────────────────────────────────────────────────────────────────────


@app.command("delete")
def delete(
    ctx: typer.Context,
    code: Annotated[str, typer.Argument(help="Template line code to delete")],
    force: Annotated[bool, typer.Option("--force", help="Skip confirmation")] = False,
) -> None:
    """Delete a template line by code."""
    actx: AppContext = ctx.obj
    out, c = actx.output, actx.client
    found = c.search("company.coa.template.line", [("code", "=", code)], limit=1)
    if not found:
        out.error(f"No template line with code={code}")
        raise typer.Exit(1)
    if not force:
        typer.confirm(f"Delete template line {code}?", abort=True)
    c.execute_kw("company.coa.template.line", "unlink", [found])
    out.success(f"Deleted code={code}")


@app.command("stats")
def stats(ctx: typer.Context) -> None:
    """Summarise the catalog by account_type, kind, and commodity."""
    actx: AppContext = ctx.obj
    out, c = actx.output, actx.client
    rows = c.search_read(
        "company.coa.template.line",
        domain=[],
        fields=["account_type", "kind", "commodity_id", "is_active"],
        limit=100000,
    )
    from collections import Counter

    types_ = Counter(r["account_type"] for r in rows)
    kinds_ = Counter(r["kind"] for r in rows)
    commodities = Counter((r["commodity_id"][1] if r["commodity_id"] else "(generic)") for r in rows)
    inactive = sum(1 for r in rows if not r["is_active"])

    out.kv("Total lines", str(len(rows)))
    out.kv("Active", str(len(rows) - inactive))
    out.kv("Inactive", str(inactive))
    out.info("")
    out.table(
        "By Account Type",
        [("Type", ""), ("Count", "")],
        sorted([[k, str(v)] for k, v in types_.items()], key=lambda r: -int(r[1])),
    )
    out.table(
        "By Kind",
        [("Kind", ""), ("Count", "")],
        sorted([[k, str(v)] for k, v in kinds_.items()], key=lambda r: -int(r[1])),
    )
    out.table(
        "By Commodity",
        [("Commodity", ""), ("Count", "")],
        sorted([[k, str(v)] for k, v in commodities.items()], key=lambda r: -int(r[1])),
    )


# ────────────────────────────────────────────────────────────────────────
# import-coa-r — bulk import from the canonical Excel format
# ────────────────────────────────────────────────────────────────────────


# Map the ACCURATE ACCOUNT TYPE column from COA_R Excel → Odoo account_type
_COA_R_TYPE_MAP = {
    "CASH & BANK": "asset_cash",
    "ACCOUNT RECEIVABLE": "asset_receivable",
    "CURRENT ASSETS": "asset_current",
    "OTHER CURRENT ASSETS": "asset_current",
    "FIXED ASSETS": "asset_fixed",
    "ACCUMULATION DEPR.": "asset_fixed",
    "OTHER ASSETS": "asset_non_current",
    "ACCOUNT PAYABLE": "liability_payable",
    "CURRENT LIABILITIES": "liability_current",
    "OTHER CURRENT LIABILITIES": "liability_current",
    "LONG TERM LIABILITIES": "liability_non_current",
    "EQUITY": "equity",
    "REVENUE": "income",
    "SALES": "income",
    "OTHER INCOME": "income_other",
    "COGS": "expense_direct_cost",
    "EXPENSE": "expense",
    "OPERATING EXPENSE": "expense",
    "OTHER EXPENSE": "expense",
    "DEPRECIATION EXPENSE": "expense_depreciation",
}

# Mapping from the "TPP Chart of Accounts" sheet's `Tipe` column (Bahasa)
# to Odoo's account_type enum. Used by `import-tpp-all`.
_TPP_TIPE_MAP = {
    "Kas & Bank": "asset_cash",
    "Piutang": "asset_receivable",
    "Aktiva Lancar": "asset_current",
    "Aktiva Tetap": "asset_fixed",
    "Akumulasi Penyusutan": "asset_fixed",
    "Hutang Usaha": "liability_payable",
    "Liabilitas Jangka Pendek": "liability_current",
    "Liabilitas Jangka Panjang": "liability_non_current",
    "Modal": "equity",
    "Pendapatan": "income",
    "Pendapatan Lainnya": "income_other",
    "Beban": "expense",
    "Beban Pokok Penjualan": "expense_direct_cost",
    "Penyusutan & Amortisasi": "expense_depreciation",
}

# Variant column (e.g. "GRL — Garlic (Bawang Putih)") → res.company.commodity.code
_TPP_VARIANT_TO_COMMODITY_CODE = {
    "GRL": "GRL",
    "ONI": "ONI",
    "CHI": "CHI",
    "PNT": "PNT",
    "MNG": "MNG",
    "WHT": "WHT",
    "FRT": "FRT",
    "MIX": "MIX",
}


_COA_R_NOTES_LINE_TYPE = {
    "HEADER": "header",
    "SUB HEADER": "sub_header",
    "SUB SUB HEADER": "sub_sub_header",
    "": "leaf",
    None: "leaf",
}


def _pad_code_to_strict(code: str) -> str:
    """Strict 4.2.2.3 enforcement: pad each segment to its target width.

    Accepts inputs like '1301.02.01.01' (Excel) or '1301.02.01.001' and
    normalises to '1301.02.01.001' (leaf padded to 3 digits)."""
    code = code.replace(" ", "").strip()
    parts = code.split(".")
    widths = [4, 2, 2, 3]
    out_parts = []
    for i, p in enumerate(parts):
        if i >= len(widths):
            return code  # too deep, leave as-is and let validator complain
        target_w = widths[i]
        if p.isdigit():
            out_parts.append(p.zfill(target_w) if i < 3 else p.zfill(target_w))
        else:
            return code
    return ".".join(out_parts)


@app.command("import-coa-r")
def import_coa_r(
    ctx: typer.Context,
    input_path: Annotated[Path, typer.Option("-i", "--input", help="Excel file with a COA_R sheet")],
    wipe: Annotated[bool, typer.Option("--wipe", help="Delete all existing template lines first")] = False,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Preview without writes")] = False,
    skip_duplicates: Annotated[
        bool, typer.Option("--skip-duplicates", help="Keep first occurrence of duplicate codes")
    ] = False,
) -> None:
    """Bulk-import the canonical COA_R sheet (4.2.2.3 hierarchy).

    Reads columns: COA NO., COA NAME, ACCOUNT TYPE, NOTES.
    Auto-derives line_type from NOTES (HEADER/SUB HEADER/SUB SUB HEADER/empty=leaf).
    Pads leaf codes to 3 digits (1301.02.01.01 → 1301.02.01.001) per strict format.
    """
    actx: AppContext = ctx.obj
    out, c = actx.output, actx.client
    try:
        import openpyxl
    except ImportError:
        out.error("openpyxl required.")
        raise typer.Exit(1)
    if not input_path.exists():
        out.error(f"File not found: {input_path}")
        raise typer.Exit(1)

    wb = openpyxl.load_workbook(str(input_path), data_only=True)
    if "COA_R" not in wb.sheetnames:
        out.error(f"Sheet COA_R not found in {input_path}")
        raise typer.Exit(1)
    ws = wb["COA_R"]

    # Per-parent leaf sequencer (used to extend short-depth leaves to depth-4)
    from collections import defaultdict

    parent_seq: dict[str, int] = defaultdict(int)

    def _extend_leaf_to_depth4(code: str) -> str:
        """Pad a leaf to depth 4 by appending .00.001 / .001 with sequencing."""
        parts = code.split(".")
        depth = len(parts)
        if depth == 4:
            return code
        if depth == 3:
            parent_seq[code] += 1
            return f"{code}.{parent_seq[code]:03d}"
        if depth == 2:
            parent = f"{code}.00"
            parent_seq[parent] += 1
            return f"{code}.00.{parent_seq[parent]:03d}"
        if depth == 1:
            parent = f"{code}.00.00"
            parent_seq[parent] += 1
            return f"{code}.00.00.{parent_seq[parent]:03d}"
        return code

    rows = []
    for r in range(2, ws.max_row + 1):
        code_raw = ws.cell(row=r, column=1).value
        name = ws.cell(row=r, column=2).value
        atype = ws.cell(row=r, column=3).value
        notes = ws.cell(row=r, column=4).value
        if code_raw is None:
            continue
        code = _pad_code_to_strict(str(code_raw))
        if not name:
            out.warn(f"Row {r}: code={code_raw} has no name; skipping")
            continue
        odoo_type = _COA_R_TYPE_MAP.get((atype or "").strip().upper())
        if not odoo_type:
            out.warn(f"Row {r}: code={code} unknown ACCOUNT TYPE '{atype}'; defaulting to asset_current")
            odoo_type = "asset_current"
        line_type = _COA_R_NOTES_LINE_TYPE.get((notes or "").strip() if notes else "", "leaf")
        depth = len(code.split("."))
        # Heuristic: depth 1 = header, depth 4 = leaf, others = sub
        if not notes and depth == 4:
            line_type = "leaf"
        elif not notes and depth == 1:
            line_type = "header"
        # STRICT: a leaf MUST be depth 4 (xxxx.xx.xx.xxx). Pad short leaves.
        if line_type == "leaf" and depth < 4:
            code = _extend_leaf_to_depth4(code)
        kind = "other"
        if odoo_type == "income":
            kind = "sales"
        elif odoo_type == "expense_direct_cost":
            kind = "cogs"
        elif odoo_type == "asset_current" and "persed" in (name or "").lower():
            kind = "inventory"
        elif odoo_type == "expense":
            kind = "opex"
        elif odoo_type == "asset_cash":
            kind = "bank"
        elif odoo_type == "asset_receivable":
            kind = "ar"
        elif odoo_type == "liability_payable":
            kind = "ap"
        elif odoo_type == "equity":
            kind = "equity"
        rows.append(
            {
                "code": code,
                "name_id": str(name).strip(),
                "name_en": "",
                "account_type": odoo_type,
                "line_type": line_type,
                "kind": kind,
                "is_active": True,
                "notes": f"COA_R import (NOTES='{notes or ''}'; original code='{code_raw}'; ACCOUNT TYPE='{atype}')",
            }
        )

    out.info(f"Parsed {len(rows)} rows from COA_R")
    out.info(
        "  line_type breakdown: "
        + ", ".join(
            f"{lt}={sum(1 for r in rows if r['line_type'] == lt)}"
            for lt in ["header", "sub_header", "sub_sub_header", "leaf"]
        )
    )

    # Dedup within Excel rows (source has duplicates: same padded code, different concept)
    by_code = {}
    duplicates = {}
    for r in rows:
        if r["code"] in by_code:
            duplicates.setdefault(r["code"], [by_code[r["code"]]]).append(r)
        else:
            by_code[r["code"]] = r
    if duplicates:
        out.warn(f"  Found {len(duplicates)} duplicate code(s) in source Excel:")
        for code, dup_rows in list(duplicates.items())[:15]:
            out.warn(f"    {code}:")
            for d in dup_rows:
                out.warn(f"      - '{d['name_id']}'")
        if not skip_duplicates:
            out.error(
                "Refusing to import. Resolve duplicates in Excel or pass --skip-duplicates (keeps first occurrence)."
            )
            raise typer.Exit(1)
        out.warn("  --skip-duplicates set: keeping first occurrence of each duplicated code.")
        rows = list(by_code.values())
        out.info(f"  Deduplicated to {len(rows)} unique-code rows")

    existing = c.search("company.coa.template.line", [], limit=10000)
    if wipe and existing:
        out.warn(f"--wipe set: would delete {len(existing)} existing template lines first")
    elif existing:
        existing_codes = {r["code"] for r in c.search_read("company.coa.template.line", [], ["code"], limit=10000)}
        rows_to_create = [r for r in rows if r["code"] not in existing_codes]
        rows_to_update = [r for r in rows if r["code"] in existing_codes]
        out.info(f"  would create: {len(rows_to_create)} new")
        out.info(f"  would update: {len(rows_to_update)} existing (use --wipe to replace)")
        if not rows_to_create and not rows_to_update:
            out.success("Nothing to do.")
            return

    if dry_run:
        out.info("Dry-run only. Re-run without --dry-run to apply.")
        return

    if wipe and existing:
        c.execute_kw("company.coa.template.line", "unlink", [existing])
        out.success(f"Deleted {len(existing)} existing lines")

    if rows:
        # Re-check existing after possible wipe
        existing_codes2 = set()
        if not wipe:
            existing_codes2 = {r["code"] for r in c.search_read("company.coa.template.line", [], ["code"], limit=10000)}
        to_create = [r for r in rows if r["code"] not in existing_codes2]
        new_ids = c.execute_kw("company.coa.template.line", "create", [to_create]) if to_create else []
        out.success(
            f"Created {len(new_ids) if isinstance(new_ids, list) else (1 if new_ids else 0)} template lines from COA_R"
        )


# ────────────────────────────────────────────────────────────────────────
# import-tpp-all — full universal + commodity COA from "TPP Chart of Accounts"
# ────────────────────────────────────────────────────────────────────────


@app.command("import-tpp-all")
def import_tpp_all(
    ctx: typer.Context,
    input_path: Annotated[
        Path,
        typer.Option("-i", "--input", help="Excel file with a 'TPP Chart of Accounts' sheet"),
    ],
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Preview without writes")] = False,
    upsert: Annotated[bool, typer.Option("--upsert", help="Update existing codes (default: skip)")] = False,
    sheet: Annotated[str, typer.Option("--sheet", help="Sheet name")] = "TPP Chart of Accounts",
) -> None:
    """Bulk-import the canonical TPP COA (universal + commodity variants).

    Excel columns (row 4 header): Kode, Nama Akun, Tipe, Bagian, Variant,
    Import, Trade, Catatan. Skips rows whose code is malformed (e.g.
    '1000.03.NN' placeholders or trailing comment rows).

    Mapping:
      Kode    → code (auto-padded leaves to xxxx.xx.xx.xxx)
      Nama Akun → name_id (Bahasa)
      Tipe    → account_type (Beban → expense, Piutang → asset_receivable, etc.)
      Variant → commodity_id (GRL → Garlic, FRT → Fruit, etc.)
      Catatan → notes
    """
    actx: AppContext = ctx.obj
    out, c = actx.output, actx.client
    try:
        import openpyxl
    except ImportError:
        out.error("openpyxl required.")
        raise typer.Exit(1)
    if not input_path.exists():
        out.error(f"File not found: {input_path}")
        raise typer.Exit(1)

    wb = openpyxl.load_workbook(str(input_path), data_only=True)
    if sheet not in wb.sheetnames:
        out.error(f"Sheet '{sheet}' not found in {input_path}. Sheets: {wb.sheetnames}")
        raise typer.Exit(1)
    ws = wb[sheet]

    # Pre-resolve commodity codes → ids
    commodity_id_by_code = {
        r["code"]: r["id"] for r in c.search_read("res.company.commodity", domain=[], fields=["id", "code"], limit=1000)
    }

    import re
    from collections import defaultdict

    parent_seq: dict[str, int] = defaultdict(int)
    code_pat = re.compile(r"^\d+(?:\.\d+){0,3}$")

    def _pad_leaf(code: str) -> str:
        parts = code.split(".")
        d = len(parts)
        if d == 4:
            return code
        if d == 3:
            parent_seq[code] += 1
            return f"{code}.{parent_seq[code]:03d}"
        if d == 2:
            parent = f"{code}.00"
            parent_seq[parent] += 1
            return f"{code}.00.{parent_seq[parent]:03d}"
        if d == 1:
            parent = f"{code}.00.00"
            parent_seq[parent] += 1
            return f"{code}.00.00.{parent_seq[parent]:03d}"
        return code

    def _pad_segments(code: str) -> str:
        """Pad each segment to its target width: 4.2.2.3."""
        parts = code.split(".")
        widths = [4, 2, 2, 3]
        out_parts = []
        for i, p in enumerate(parts):
            if i >= len(widths) or not p.isdigit():
                return code
            out_parts.append(p.zfill(widths[i]))
        return ".".join(out_parts)

    # First pass: collect rows and determine which codes are PARENTS
    # (i.e. have at least one row whose code starts with code + ".")
    parsed_rows = []
    for r in range(5, ws.max_row + 1):
        code_raw = ws.cell(row=r, column=1).value
        if code_raw is None:
            continue
        code = str(code_raw).strip().replace(" ", "")
        if not code_pat.match(code):
            continue  # malformed (NN placeholder or comment line)
        parsed_rows.append(
            {
                "_row": r,
                "raw_code": code,
                "name_id": (ws.cell(row=r, column=2).value or "").strip(),
                "tipe": (ws.cell(row=r, column=3).value or "").strip(),
                "bagian": (ws.cell(row=r, column=4).value or "").strip(),
                "variant": (ws.cell(row=r, column=5).value or "").strip(),
                "notes": (ws.cell(row=r, column=8).value or "").strip() if ws.cell(row=r, column=8).value else "",
            }
        )

    all_raw_codes = {r["raw_code"] for r in parsed_rows}

    # A row is a HEADER if any other row's code starts with "rawcode."
    def has_children(code: str) -> bool:
        return any(other != code and other.startswith(code + ".") for other in all_raw_codes)

    # Build final rows with line_type + final padded code
    rows = []
    for pr in parsed_rows:
        raw = pr["raw_code"]
        depth = len(raw.split("."))
        if has_children(raw):
            # Header/Sub-header — keep code as-is, set line_type by depth
            line_type = {1: "header", 2: "sub_header", 3: "sub_sub_header"}.get(depth, "leaf")
            code = _pad_segments(raw)
        else:
            # Leaf — pad to depth 4
            line_type = "leaf"
            code = _pad_segments(_pad_leaf(raw))
        odoo_type = _TPP_TIPE_MAP.get(pr["tipe"]) or "asset_current"
        # Extract commodity code from "GRL — Garlic (Bawang Putih)" → "GRL"
        commodity_id = False
        if pr["variant"]:
            m = re.match(r"^([A-Z]{2,4})\s*—", pr["variant"])
            if m:
                commodity_id = commodity_id_by_code.get(m.group(1), False)
        # Kind derived from account_type
        kind = "other"
        if odoo_type == "income":
            kind = "sales"
        elif odoo_type == "expense_direct_cost":
            kind = "cogs"
        elif odoo_type == "expense":
            kind = "opex"
        elif odoo_type == "asset_cash":
            kind = "bank"
        elif odoo_type == "asset_receivable":
            kind = "ar"
        elif odoo_type == "liability_payable":
            kind = "ap"
        elif odoo_type == "equity":
            kind = "equity"
        rows.append(
            {
                "code": code,
                "name_id": pr["name_id"] or "(unnamed)",
                "name_en": "",
                "account_type": odoo_type,
                "line_type": line_type,
                "kind": kind,
                "commodity_id": commodity_id,
                "is_active": True,
                "notes": (
                    f"TPP-all import (raw_code='{pr['raw_code']}'; tipe='{pr['tipe']}'; "
                    f"bagian='{pr['bagian']}'; variant='{pr['variant']}'; "
                    f"catatan='{pr['notes']}')"
                ),
            }
        )

    out.info(f"Parsed {len(rows)} valid rows from '{sheet}'")
    out.info(
        "  line_type breakdown: "
        + ", ".join(
            f"{lt}={sum(1 for r in rows if r['line_type'] == lt)}"
            for lt in ["header", "sub_header", "sub_sub_header", "leaf"]
        )
    )
    out.info(
        "  account_type breakdown: "
        + ", ".join(
            f"{at}={sum(1 for r in rows if r['account_type'] == at)}"
            for at in sorted({r["account_type"] for r in rows})
        )
    )

    # Pre-filter: skip rows whose padded code violates strict 4.2.2.3
    strict_pat = re.compile(r"^\d{4}(\.\d{2}(\.\d{2}(\.\d{3})?)?)?$")
    valid_rows, skipped = [], []
    for r in rows:
        if strict_pat.match(r["code"]):
            valid_rows.append(r)
        else:
            skipped.append(r)
    if skipped:
        out.warn(f"  {len(skipped)} rows skipped (code violates strict xxxx[.xx[.xx[.xxx]]]):")
        for sv in skipped[:20]:
            out.warn(f"    {sv['code']:<22} {sv['name_id'][:50]}")
    rows = valid_rows

    existing_codes = {r["code"] for r in c.search_read("company.coa.template.line", [], ["code"], limit=10000)}
    to_create = [r for r in rows if r["code"] not in existing_codes]
    to_update = [r for r in rows if r["code"] in existing_codes]

    out.info(f"  to_create: {len(to_create)}  to_update: {len(to_update)} (skipped unless --upsert)")
    if dry_run:
        out.info("Dry-run only. Re-run without --dry-run to apply.")
        if to_create[:5]:
            out.info("First 5 to-create:")
            for r in to_create[:5]:
                out.info(f"  {r['code']:<14} {r['account_type']:<22} {r['name_id'][:40]}")
        return

    created = 0
    if to_create:
        new_ids = c.execute_kw("company.coa.template.line", "create", [to_create])
        created = len(new_ids) if isinstance(new_ids, list) else 1
    updated = 0
    if upsert and to_update:
        # Pull current ids by code
        id_by_code = {
            r["code"]: r["id"]
            for r in c.search_read(
                "company.coa.template.line",
                [("code", "in", [r["code"] for r in to_update])],
                ["id", "code"],
                limit=10000,
            )
        }
        for r in to_update:
            tid = id_by_code.get(r["code"])
            if not tid:
                continue
            vals = {k: v for k, v in r.items() if k != "code"}
            c.execute_kw("company.coa.template.line", "write", [[tid], vals])
            updated += 1
    out.success(f"Created {created}, updated {updated}.")
