"""Built-in Odoo ir.actions.report commands: list, render, templates, generate."""

from __future__ import annotations

import base64
from pathlib import Path
from typing import Annotated

import typer

from kctl_odoo.core.callbacks import AppContext
from kctl_odoo.core.exceptions import RPCError

app = typer.Typer(help="Manage Odoo reports and generate diagnostic reports.")

# Report types → diagnose section mappings (used by generate command)
REPORT_TYPES: dict[str, list[str] | None] = {
    "health": ["server_health", "configuration", "mail", "storage", "dr"],
    "finance": ["financial_health", "data_integrity", "kpis"],
    "security": ["security"],
    "inventory": ["inventory_health", "data_integrity", "kpis"],
    "operations": ["kpis", "mail", "data_integrity"],
    "full": None,  # all sections
}


@app.command("list")
def list_(
    ctx: typer.Context,
    model: Annotated[str | None, typer.Option("--model", "-m", help="Filter by model name")] = None,
    limit: Annotated[int, typer.Option("--limit", "-l", help="Max results")] = 50,
) -> None:
    """List available reports."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    domain: list = []
    if model:
        domain.append(("model", "=", model))

    reports = c.search_read(
        "ir.actions.report",
        domain=domain,
        fields=["id", "name", "report_name", "model", "report_type", "print_report_name", "binding_model_id"],
        limit=limit,
        order="model, name",
    )

    if not reports:
        out.info("No reports found.")
        if actx.json_mode:
            out.raw_json([])
        return

    rows = []
    json_data = []
    for r in reports:
        report_type = r.get("report_type", "")
        type_display = {
            "qweb-pdf": "[green]PDF[/green]",
            "qweb-html": "[cyan]HTML[/cyan]",
            "qweb-text": "[dim]Text[/dim]",
        }.get(report_type, report_type)

        binding = r.get("binding_model_id")
        binding_display = binding[1] if isinstance(binding, list) else ""

        rows.append(
            [
                str(r["id"]),
                (r.get("name") or "")[:35],
                r.get("report_name", ""),
                r.get("model", ""),
                type_display,
                (r.get("print_report_name") or "")[:30],
            ]
        )
        json_data.append(
            {
                "id": r["id"],
                "name": r.get("name"),
                "report_name": r.get("report_name"),
                "model": r.get("model"),
                "report_type": report_type,
                "print_report_name": r.get("print_report_name"),
                "binding_model": binding_display or None,
            }
        )

    out.table(
        f"Reports ({len(reports)})",
        [
            ("ID", "cyan"),
            ("Name", ""),
            ("Report Name", ""),
            ("Model", ""),
            ("Type", ""),
            ("Print Name", "dim"),
        ],
        rows,
        data_for_json=json_data,
    )


@app.command()
def render(
    ctx: typer.Context,
    report_name: Annotated[str, typer.Argument(help="Report technical name (e.g. account.report_invoice)")],
    record_ids: Annotated[str, typer.Argument(help="Comma-separated record IDs")],
    fmt: Annotated[str, typer.Option("--format", "-f", help="Output format: pdf or html")] = "pdf",
    output: Annotated[str | None, typer.Option("--output", "-o", help="Output file path")] = None,
) -> None:
    """Render a report for given record IDs and save to file."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    if fmt not in ("pdf", "html"):
        out.error("Format must be 'pdf' or 'html'.")
        raise typer.Exit(1)

    ids = [int(i.strip()) for i in record_ids.split(",")]

    # Find the report action to get the model
    reports = c.search_read(
        "ir.actions.report",
        domain=[("report_name", "=", report_name)],
        fields=["id", "name", "model", "report_type"],
    )
    if not reports:
        out.error(f"Report not found: {report_name}")
        raise typer.Exit(1)

    report_info = reports[0]

    # Use _render first (Odoo 17+), fall back to specific method for older versions
    fallback_method = "render_qweb_pdf" if fmt == "pdf" else "render_qweb_html"
    try:
        result = c.execute_kw(
            "ir.actions.report",
            "_render",
            [[report_info["id"]], report_name, ids],
        )
    except RPCError:
        # Fallback: try the specific render method on the report model
        try:
            result = c.execute_kw(
                "ir.actions.report",
                fallback_method,
                [[report_info["id"]], ids],
            )
        except RPCError as e2:
            out.error(f"Failed to render report: {e2.detail}")
            raise typer.Exit(1) from e2

    # Result is typically [base64_content, report_type] or just base64 content
    if isinstance(result, list) and len(result) >= 1:
        content = result[0]
    elif isinstance(result, str):
        content = result
    else:
        out.error("Unexpected response format from report rendering.")
        raise typer.Exit(1)

    # Decode if base64 encoded
    if isinstance(content, str):
        try:
            file_data = base64.b64decode(content)
        except ValueError:
            # Might be raw content (binascii.Error is a subclass of ValueError)
            file_data = content.encode("utf-8")
    elif isinstance(content, bytes):
        file_data = content
    else:
        out.error("Could not decode report content.")
        raise typer.Exit(1)

    ext = "pdf" if fmt == "pdf" else "html"
    if output:
        output_path = Path(output)
    else:
        safe_name = report_name.replace(".", "_")
        output_path = Path(f"{safe_name}_{'-'.join(str(i) for i in ids)}.{ext}")

    output_path.write_bytes(file_data)
    out.success(f"Report saved to {output_path} ({len(file_data)} bytes)")
    if actx.json_mode:
        out.raw_json(
            {
                "report_name": report_name,
                "record_ids": ids,
                "format": fmt,
                "file": str(output_path),
                "size": len(file_data),
            }
        )


@app.command()
def templates(
    ctx: typer.Context,
    model: Annotated[str | None, typer.Option("--model", "-m", help="Filter by related model")] = None,
    limit: Annotated[int, typer.Option("--limit", "-l", help="Max results")] = 50,
) -> None:
    """List QWeb report templates."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    domain: list = [("type", "=", "qweb")]
    if model:
        domain.append(("model", "=", model))

    views = c.search_read(
        "ir.ui.view",
        domain=domain,
        fields=["id", "name", "key", "model", "active", "priority"],
        limit=limit,
        order="model, name",
    )

    if not views:
        out.info("No QWeb templates found.")
        if actx.json_mode:
            out.raw_json([])
        return

    rows = []
    json_data = []
    for v in views:
        status = "[green]active[/green]" if v.get("active") else "[dim]inactive[/dim]"
        rows.append(
            [
                str(v["id"]),
                (v.get("name") or "")[:35],
                v.get("key", "") or "-",
                v.get("model", "") or "-",
                str(v.get("priority", "")),
                status,
            ]
        )
        json_data.append(
            {
                "id": v["id"],
                "name": v.get("name"),
                "key": v.get("key"),
                "model": v.get("model"),
                "priority": v.get("priority"),
                "active": v.get("active"),
            }
        )

    out.table(
        f"QWeb Templates ({len(views)})",
        [("ID", "cyan"), ("Name", ""), ("Key", ""), ("Model", ""), ("Priority", "dim"), ("Status", "")],
        rows,
        data_for_json=json_data,
    )


@app.command("generate")
def generate(
    ctx: typer.Context,
    report_type: Annotated[
        str, typer.Argument(help="Report type: health, finance, security, inventory, operations, full")
    ],
    output: Annotated[str | None, typer.Option("--output", "-o", help="Write to file (.md, .json, .html)")] = None,
    quick: Annotated[bool, typer.Option("--quick", help="Skip slow checks")] = False,
) -> None:
    """Generate a focused diagnostic report by domain.

    Maps business-friendly report names to diagnose sections.

    Examples:
        kctl-odoo report generate health
        kctl-odoo report generate finance --output finance-march.md
        kctl-odoo report generate security --output security.html
        kctl-odoo report generate full --output audit.json
        kctl-odoo report generate inventory --quick
    """
    if report_type not in REPORT_TYPES:
        valid = ", ".join(REPORT_TYPES.keys())
        typer.echo(f"Unknown report type '{report_type}'. Valid: {valid}", err=True)
        raise typer.Exit(1)

    sections = REPORT_TYPES[report_type]
    section_arg = ",".join(sections) if sections else None

    # Import and delegate to diagnose engine
    from kctl_odoo.commands.diagnose import run_diagnose_core

    run_diagnose_core(ctx, output=output, quick=quick, section_filter=section_arg)
