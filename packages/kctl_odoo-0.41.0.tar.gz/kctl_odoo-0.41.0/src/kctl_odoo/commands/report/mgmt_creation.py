"""Report creation and management commands: create, add-line, remove-line,
preview, convert-status, convert, benchmark."""

from __future__ import annotations

import contextlib
from datetime import date
from typing import Annotated

import typer

from kctl_odoo.core.callbacks import AppContext
from kctl_odoo.core.exceptions import RPCError

from .mgmt_framework import (
    _check_report_base,
    _default_date_range,
    _fiscal_year_start,
    _resolve_type_code,
)

app = typer.Typer(help="Report creation and management commands.")


def _find_template_by_code(c, out, report_code: str):
    """Return the first report.template with the given code, or exit."""
    try:
        records = c.search_read(
            "report.template",
            domain=[("code", "=", report_code)],
            fields=["id", "name", "code", "report_type"],
            limit=1,
        )
    except RPCError as e:
        out.error(f"Template lookup failed: {e.detail}")
        raise typer.Exit(1) from e
    if not records:
        out.error(f"No report template found with code '{report_code}'.")
        raise typer.Exit(1)
    return records[0]


@app.command("create")
def report_create(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Display name for the new report")],
    category: Annotated[
        str, typer.Option("--category", "-c", help="Report category: custom, financial, aging, management")
    ] = "custom",
    date_mode: Annotated[str, typer.Option("--date-mode", help="Date mode: period, cumulative, as_of")] = "period",
    column_template: Annotated[
        str, typer.Option("--column-template", help="Column template: standard, trial_balance, aging_buckets")
    ] = "standard",
    code: Annotated[str | None, typer.Option("--code", help="Override auto-generated code slug")] = None,
    force: Annotated[bool, typer.Option("--force", "-y", help="Skip confirmation")] = False,
) -> None:
    """Create a new report type with an empty template via the creation wizard.

    A report.type.registry entry and a linked report.template are created in one
    step. Lines can be added afterwards with 'report add-line'.

    Examples:
        kctl-odoo report create "Management P&L" --category financial
        kctl-odoo report create "Partner Summary" --code partner_summary --category custom
        kctl-odoo report create "AR Aging Custom" --category aging --date-mode as_of
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    if not _check_report_base(c, out):
        return

    if category not in ("custom", "financial", "aging", "management"):
        out.error("Category must be one of: custom, financial, aging, management")
        raise typer.Exit(1)

    if date_mode not in ("period", "cumulative", "as_of"):
        out.error("date-mode must be one of: period, cumulative, as_of")
        raise typer.Exit(1)

    # Build wizard vals — the wizard auto-generates code from name when omitted
    wizard_vals: dict = {
        "name": name,
        "category": category,
        "date_mode": date_mode,
        "column_template": column_template,
        "start_from": "blank",
    }
    if code:
        wizard_vals["code"] = code

    if not force:
        out.info(f"Create report: '{name}' (category={category}, date_mode={date_mode})")
        if not typer.confirm("Proceed?"):
            raise typer.Exit(0)

    try:
        wizard_id = c.execute_kw("report.creation.wizard", "create", [wizard_vals])
        result = c.execute_kw("report.creation.wizard", "action_create_report", [[wizard_id]])
    except RPCError as e:
        out.error(f"Failed to create report: {e.detail}")
        raise typer.Exit(1) from e

    template_id = result.get("res_id") if isinstance(result, dict) else None
    if not template_id:
        out.error("Wizard completed but no template ID returned.")
        raise typer.Exit(1)

    # Read back the created template
    try:
        tpl_records = c.search_read(
            "report.template",
            domain=[("id", "=", template_id)],
            fields=["id", "name", "code", "report_type"],
            limit=1,
        )
    except RPCError:
        tpl_records = []

    tpl = tpl_records[0] if tpl_records else {"id": template_id, "name": name, "code": code or ""}

    out.success(f"Report created: '{tpl.get('name')}' (template id={tpl['id']}, code={tpl.get('code', '')})")
    out.info("Add lines with: kctl-odoo report add-line " + str(tpl.get("code", "")))

    if actx.json_mode:
        out.raw_json(
            {
                "template_id": tpl["id"],
                "name": tpl.get("name"),
                "code": tpl.get("code"),
                "report_type": tpl.get("report_type"),
                "category": category,
                "date_mode": date_mode,
            }
        )


@app.command("add-line")
def report_add_line(
    ctx: typer.Context,
    report_code: Annotated[str, typer.Argument(help="Report template code (e.g. my_custom_report)")],
    name: Annotated[str, typer.Option("--name", "-n", help="Line display name")],
    line_type: Annotated[
        str, typer.Option("--type", "-t", help="Line type: detail, formula, title, blank, subtotal, total")
    ] = "detail",
    code: Annotated[str | None, typer.Option("--code", help="Line code (used in formula references)")] = None,
    expression: Annotated[str | None, typer.Option("--expr", help="AEP expression, e.g. bal[4010:4100]")] = None,
    formula: Annotated[str | None, typer.Option("--formula", help="Formula referencing other line codes")] = None,
    sign: Annotated[int, typer.Option("--sign", help="Sign multiplier: 1 or -1")] = 1,
    model: Annotated[str | None, typer.Option("--model", help="ORM model name for ORM-query lines")] = None,
    domain: Annotated[str | None, typer.Option("--domain", help="ORM domain string for ORM-query lines")] = None,
    measure: Annotated[str | None, typer.Option("--measure", help="ORM measure field name")] = None,
    aggregator: Annotated[str, typer.Option("--aggregator", help="ORM aggregator: sum, avg, count, min, max")] = "sum",
    sequence: Annotated[int, typer.Option("--sequence", "-s", help="Sequence position (lower = first)")] = 10,
) -> None:
    """Add a template line to an existing report.

    Lines are the rows of the report. detail lines pull data from GL or ORM;
    formula lines compute values from other line codes; title/blank lines are
    structural separators.

    Examples:
        kctl-odoo report add-line my_report --name "Revenue" --expr "bal[4010:4100]"
        kctl-odoo report add-line my_report --name "COGS" --code cogs --expr "bal[5010:5900]" --sign -1
        kctl-odoo report add-line my_report --name "Gross Profit" --type formula --formula "revenue - cogs"
        kctl-odoo report add-line my_report --name "Partners" --model res.partner --domain "[('active','=',True)]" --measure id --aggregator count
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    if not _check_report_base(c, out):
        return

    tpl = _find_template_by_code(c, out, report_code)

    # Build line vals
    line_vals: dict = {
        "template_id": tpl["id"],
        "name": name,
        "line_type": line_type,
        "sign": sign,
        "sequence": sequence,
    }
    if code:
        line_vals["code"] = code
    if expression:
        line_vals["expression"] = expression
    if formula:
        line_vals["formula"] = formula
    if aggregator != "sum":
        line_vals["orm_aggregator"] = aggregator
    else:
        line_vals["orm_aggregator"] = aggregator

    # ORM query fields
    if model:
        try:
            model_records = c.search_read(
                "ir.model",
                domain=[("model", "=", model)],
                fields=["id", "model"],
                limit=1,
            )
        except RPCError as e:
            out.error(f"Failed to look up model '{model}': {e.detail}")
            raise typer.Exit(1) from e
        if not model_records:
            out.error(f"Model '{model}' not found in ir.model.")
            raise typer.Exit(1)
        line_vals["orm_model_id"] = model_records[0]["id"]
        if domain:
            line_vals["orm_domain"] = domain
        if measure:
            line_vals["orm_measure"] = measure

    try:
        line_id = c.execute_kw("report.template.line", "create", [line_vals])
    except RPCError as e:
        out.error(f"Failed to create line: {e.detail}")
        raise typer.Exit(1) from e

    out.success(f"Line '{name}' added to report '{report_code}' (line id={line_id})")

    if actx.json_mode:
        out.raw_json(
            {
                "line_id": line_id,
                "template_id": tpl["id"],
                "template_code": report_code,
                "name": name,
                "line_type": line_type,
                "code": code,
                "expression": expression,
                "formula": formula,
                "sign": sign,
                "sequence": sequence,
            }
        )


@app.command("remove-line")
def report_remove_line(
    ctx: typer.Context,
    report_code: Annotated[str, typer.Argument(help="Report template code")],
    line_code: Annotated[str, typer.Argument(help="Line code to remove")],
    force: Annotated[bool, typer.Option("--force", "-y", help="Skip confirmation")] = False,
) -> None:
    """Remove a template line from a report by its code.

    Examples:
        kctl-odoo report remove-line my_report revenue
        kctl-odoo report remove-line my_report net_income -y
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    if not _check_report_base(c, out):
        return

    tpl = _find_template_by_code(c, out, report_code)

    try:
        lines = c.search_read(
            "report.template.line",
            domain=[("template_id", "=", tpl["id"]), ("code", "=", line_code)],
            fields=["id", "name", "code", "line_type"],
            limit=1,
        )
    except RPCError as e:
        out.error(f"Failed to look up line: {e.detail}")
        raise typer.Exit(1) from e

    if not lines:
        out.error(f"No line with code '{line_code}' found in report '{report_code}'.")
        raise typer.Exit(1)

    line = lines[0]

    if not force:
        out.info(f"Remove line '{line.get('name')}' (code={line_code}) from report '{report_code}'?")
        if not typer.confirm("Proceed?"):
            raise typer.Exit(0)

    try:
        c.execute_kw("report.template.line", "unlink", [[line["id"]]])
    except RPCError as e:
        out.error(f"Failed to remove line: {e.detail}")
        raise typer.Exit(1) from e

    out.success(f"Line '{line_code}' removed from report '{report_code}'.")

    if actx.json_mode:
        out.raw_json(
            {
                "removed": True,
                "line_id": line["id"],
                "line_code": line_code,
                "template_code": report_code,
            }
        )


@app.command("preview")
def report_preview(
    ctx: typer.Context,
    report_code: Annotated[str, typer.Argument(help="Report template code (e.g. my_custom_report)")],
    date_from: Annotated[str | None, typer.Option("--date-from", help="Start date (YYYY-MM-DD)")] = None,
    date_to: Annotated[str | None, typer.Option("--date-to", help="End date (YYYY-MM-DD)")] = None,
    company: Annotated[str | None, typer.Option("--company", help="Company name or ID")] = None,
    show_zero: Annotated[bool, typer.Option("--show-zero", help="Show zero-balance lines")] = False,
) -> None:
    """Preview a report's output as a text table.

    Runs the report engine against the specified date range and prints the
    result to the terminal. Useful for quick sanity-checks after adding or
    changing template lines.

    Examples:
        kctl-odoo report preview my_custom_report
        kctl-odoo report preview my_custom_report --date-from 2026-01-01 --date-to 2026-03-31
        kctl-odoo report preview my_custom_report --company 42 --show-zero
        kctl-odoo report preview my_custom_report --json
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    if not _check_report_base(c, out):
        return

    tpl = _find_template_by_code(c, out, report_code)

    # Resolve company
    co_id: int = 1
    if company:
        if company.isdigit():
            co_id = int(company)
        else:
            cos = c.search_read("res.company", [("name", "ilike", company)], ["id"], limit=1)
            if not cos:
                out.error(f"Company not found: {company}")
                raise typer.Exit(1)
            co_id = cos[0]["id"]
    else:
        try:
            cos = c.search_read("res.company", [("active", "=", True)], ["id"], limit=1, order="id")
            if cos:
                co_id = cos[0]["id"]
        except RPCError:
            pass

    # Resolve dates
    if date_from and date_to:
        resolved_from, resolved_to = date_from, date_to
    elif date_from:
        resolved_from, resolved_to = date_from, date.today().isoformat()
    elif date_to:
        resolved_from = _fiscal_year_start(date_to)
        resolved_to = date_to
    else:
        resolved_from, resolved_to = _default_date_range()

    try:
        rd = c.execute_kw(
            "report.report_base.engine",
            "compute_report_data",
            [
                [],
                {
                    "template_id": tpl["id"],
                    "date_from": resolved_from,
                    "date_to": resolved_to,
                    "company_id": co_id,
                    "company_ids": [],
                    "target_move": "posted",
                    "divider": 1,
                    "show_variance": False,
                    "show_percentage": False,
                    "monthly_breakdown": False,
                    "expanded_line_ids": [],
                    "page_offset": 0,
                    "page_limit": 0,
                },
            ],
            {"context": {"allowed_company_ids": [co_id]}},
        )
    except RPCError as e:
        out.error(f"Engine compute_report_data failed: {e.detail}")
        raise typer.Exit(1) from e

    # Flatten rows from tables or legacy lines list
    rows: list[dict] = []
    for t in rd.get("tables") or []:
        rows.extend(t.get("rows") or [])
    if not rows:
        rows = rd.get("lines") or []

    # Detect column layout from engine response
    columns = rd.get("columns") or []
    col_keys = [col["key"] for col in columns if col.get("key") != "name"]
    is_tb = any(k.startswith("tb_") for k in col_keys)

    output_rows: list[dict] = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        v = r.get("values") or {}
        amt = float(v.get("actual") or v.get("amount") or 0.0)
        kind = r.get("kind") or r.get("line_type") or ""
        if not show_zero and not amt and kind not in ("header", "spacer"):
            if not is_tb or not any(v.get(k) for k in ("tb_initial", "tb_ending")):
                continue
        label = r.get("label") or r.get("name") or ""
        level = r.get("level", 0)
        indent = "  " * level
        row_out: dict = {
            "label": f"{indent}{label}",
            "kind": kind,
            "actual": amt,
            "code": r.get("code"),
        }
        if is_tb:
            row_out["tb_initial"] = float(v.get("tb_initial") or 0.0)
            row_out["tb_debit"] = float(v.get("tb_debit") or 0.0)
            row_out["tb_credit"] = float(v.get("tb_credit") or 0.0)
            row_out["tb_ending"] = float(v.get("tb_ending") or 0.0)
        output_rows.append(row_out)

    if actx.json_mode:
        out.raw_json(
            {
                "template_code": report_code,
                "template_id": tpl["id"],
                "company_id": co_id,
                "date_from": resolved_from,
                "date_to": resolved_to,
                "rows": output_rows,
            }
        )
        return

    out.info(f"{tpl['name']}  —  company {co_id}  —  {resolved_from} to {resolved_to}\n")

    if is_tb:
        hdr = f"{'Line':<40s} {'Initial':>16s} {'Debit':>16s} {'Credit':>16s} {'Period':>16s} {'Ending':>16s}"
        out.info(hdr)
        out.info("─" * 122)
        for r in output_rows:
            kind = r["kind"]
            label = r["label"]
            if kind in ("header", "spacer"):
                out.info(f"\033[1m{label}\033[0m")
            elif kind in ("total", "subtotal"):
                out.info(
                    f"\033[1m{label:<40s} {r['tb_initial']:>16,.2f} {r['tb_debit']:>16,.2f}"
                    f" {r['tb_credit']:>16,.2f} {r['actual']:>16,.2f} {r['tb_ending']:>16,.2f}\033[0m"
                )
            else:
                out.info(
                    f"{label:<40s} {r['tb_initial']:>16,.2f} {r['tb_debit']:>16,.2f}"
                    f" {r['tb_credit']:>16,.2f} {r['actual']:>16,.2f} {r['tb_ending']:>16,.2f}"
                )
        out.info("─" * 122)
    else:
        out.info(f"{'Line':<55s} {'Amount':>20s}")
        out.info("─" * 76)
        for r in output_rows:
            kind = r["kind"]
            label = r["label"]
            amt = r["actual"]
            if kind in ("header", "spacer"):
                out.info(f"\033[1m{label}\033[0m")
            elif kind in ("total", "subtotal"):
                out.info(f"\033[1m{label:<55s} {amt:>20,.2f}\033[0m")
            else:
                out.info(f"{label:<55s} {amt:>20,.2f}")
        out.info("─" * 76)

    out.info(f"  {len(output_rows)} lines")


@app.command("convert-status")
def convert_status(ctx: typer.Context) -> None:
    """Show conversion status of all report types (universal vs specialized handler)."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    if not _check_report_base(c, out):
        return

    try:
        statuses = c.execute_kw("report.handler.universal", "conversion_status", [])
    except RPCError as e:
        out.error(f"Failed to fetch conversion status: {e.detail}")
        raise typer.Exit(1) from e

    if not statuses:
        out.info("No report types found.")
        if actx.json_mode:
            out.raw_json([])
        return

    rows = []
    json_data = []
    universal_count = 0
    specialized_count = 0

    for s in statuses:
        is_universal = s.get("is_universal", False)
        handler = s.get("handler", s.get("handler_model", ""))
        if is_universal:
            universal_count += 1
            handler_display = "[green]universal[/green]"
        else:
            specialized_count += 1
            handler_display = f"[yellow]{handler}[/yellow]"

        rows.append(
            [
                s.get("code", ""),
                (s.get("name") or "")[:45],
                handler_display,
                "[green]yes[/green]" if is_universal else "[dim]no[/dim]",
            ]
        )
        json_data.append(
            {
                "code": s.get("code"),
                "name": s.get("name"),
                "handler": handler,
                "is_universal": is_universal,
            }
        )

    out.table(
        f"Report Type Conversion Status ({len(statuses)} types)",
        [
            ("Code", "cyan"),
            ("Name", ""),
            ("Handler", ""),
            ("Universal", ""),
        ],
        rows,
        data_for_json=json_data,
    )

    if not actx.json_mode:
        out.info(f"\nSummary: {universal_count} universal, {specialized_count} specialized")


@app.command("convert")
def convert_report(
    ctx: typer.Context,
    report_code: str = typer.Argument(help="Report type code to convert"),
    force: bool = typer.Option(False, "--force", help="Skip parity check and convert directly"),
) -> None:
    """Convert a report type to use the universal handler.

    Without --force, runs validate-conversion first and aborts if parity fails.
    Use --force to bypass the parity check and convert immediately.

    Examples:
        kctl-odoo report convert profit_loss
        kctl-odoo report convert custom_summary --force
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    if not _check_report_base(c, out):
        return

    report_code = _resolve_type_code(report_code)

    # Look up the registry entry
    try:
        reg_records = c.search_read(
            "report.type.registry",
            domain=[("code", "=", report_code)],
            fields=["id", "name", "code", "handler_model"],
            limit=1,
        )
    except RPCError as e:
        out.error(f"Failed to query report type registry: {e.detail}")
        raise typer.Exit(1) from e

    if not reg_records:
        out.error(f"Report type not found: {report_code}")
        raise typer.Exit(1)

    reg = reg_records[0]
    current_handler = reg.get("handler_model", "")

    if current_handler == "report.handler.universal":
        out.info(f"Report type '{report_code}' already uses the universal handler.")
        if actx.json_mode:
            out.raw_json({"code": report_code, "converted": False, "reason": "already_universal"})
        return

    # Parity check unless --force
    if not force:
        out.info(f"Running parity check for '{report_code}' before conversion...")
        try:
            parity_result = c.execute_kw(
                "report.handler.universal",
                "validate_conversion",
                [[], report_code],
            )
        except RPCError as e:
            out.error(f"Parity check failed with RPC error: {e.detail}")
            out.info("Use --force to skip the parity check.")
            raise typer.Exit(1) from e

        if isinstance(parity_result, dict):
            passed = parity_result.get("passed", parity_result.get("ok", False))
            message = parity_result.get("message", parity_result.get("detail", ""))
        else:
            passed = bool(parity_result)
            message = ""

        if not passed:
            out.error(f"Parity check failed for '{report_code}'.")
            if message:
                out.info(f"  {message}")
            out.info("Fix the parity issues or use --force to skip the check.")
            raise typer.Exit(1)

        out.success("Parity check passed.")

    # Perform the conversion
    try:
        c.execute_kw(
            "report.type.registry",
            "write",
            [[reg["id"]], {"handler_model": "report.handler.universal"}],
        )
    except RPCError as e:
        out.error(f"Failed to update handler: {e.detail}")
        raise typer.Exit(1) from e

    out.success(
        f"Report type '{report_code}' converted to universal handler" + (" (parity skipped)" if force else "") + "."
    )

    if actx.json_mode:
        out.raw_json(
            {
                "code": report_code,
                "registry_id": reg["id"],
                "converted": True,
                "force": force,
                "previous_handler": current_handler,
                "new_handler": "report.handler.universal",
            }
        )


@app.command("benchmark")
def benchmark_report(
    ctx: typer.Context,
    report_code: str = typer.Argument(help="Report type code or template code to benchmark"),
    iterations: int = typer.Option(5, "--iterations", "-n", help="Number of iterations"),
    date_from: str = typer.Option(None, "--date-from", help="Start date YYYY-MM-DD"),
    date_to: str = typer.Option(None, "--date-to", help="End date YYYY-MM-DD"),
    company: str = typer.Option(None, "--company", help="Company name or ID"),
) -> None:
    """Benchmark report generation time over multiple iterations.

    Runs compute_report_data N times and displays avg/min/max duration.
    Useful for measuring the performance impact of schema or engine changes.

    Examples:
        kctl-odoo report benchmark profit_loss
        kctl-odoo report benchmark my_custom --iterations 10
        kctl-odoo report benchmark trial_balance --date-from 2026-01-01 --date-to 2026-03-31 -n 3
    """
    import time

    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    if not _check_report_base(c, out):
        return

    report_code = _resolve_type_code(report_code)
    tpl = _find_template_by_code(c, out, report_code)

    # Resolve company
    co_id: int = 1
    if company:
        if company.isdigit():
            co_id = int(company)
        else:
            cos = c.search_read("res.company", [("name", "ilike", company)], ["id"], limit=1)
            if not cos:
                out.error(f"Company not found: {company}")
                raise typer.Exit(1)
            co_id = cos[0]["id"]
    else:
        with contextlib.suppress(RPCError):
            cos = c.search_read("res.company", [("active", "=", True)], ["id"], limit=1, order="id")
            if cos:
                co_id = cos[0]["id"]

    # Resolve dates
    if date_from and date_to:
        resolved_from, resolved_to = date_from, date_to
    elif date_from:
        resolved_from, resolved_to = date_from, date.today().isoformat()
    elif date_to:
        resolved_from = _fiscal_year_start(date_to)
        resolved_to = date_to
    else:
        resolved_from, resolved_to = _default_date_range()

    params = {
        "template_id": tpl["id"],
        "date_from": resolved_from,
        "date_to": resolved_to,
        "company_id": co_id,
        "company_ids": [],
        "target_move": "posted",
        "divider": 1,
        "show_variance": False,
        "show_percentage": False,
        "monthly_breakdown": False,
        "expanded_line_ids": [],
        "page_offset": 0,
        "page_limit": 0,
    }

    out.info(
        f"Benchmarking '{report_code}' — {iterations} iterations  [{resolved_from} → {resolved_to}, company={co_id}]"
    )

    durations: list[float] = []
    for i in range(1, iterations + 1):
        t_start = time.perf_counter()
        try:
            c.execute_kw(
                "report.report_base.engine",
                "compute_report_data",
                [[], params],
                {"context": {"allowed_company_ids": [co_id]}},
            )
        except RPCError as e:
            out.error(f"Iteration {i} failed: {e.detail}")
            raise typer.Exit(1) from e
        elapsed = time.perf_counter() - t_start
        durations.append(elapsed)
        out.info(f"  [{i}/{iterations}]  {elapsed:.3f}s")

    avg_ms = (sum(durations) / len(durations)) * 1000
    min_ms = min(durations) * 1000
    max_ms = max(durations) * 1000

    out.info("")
    out.success(
        f"Results — avg: {avg_ms:.1f}ms  min: {min_ms:.1f}ms  max: {max_ms:.1f}ms  (over {iterations} iterations)"
    )

    if actx.json_mode:
        out.raw_json(
            {
                "report_code": report_code,
                "template_id": tpl["id"],
                "company_id": co_id,
                "date_from": resolved_from,
                "date_to": resolved_to,
                "iterations": iterations,
                "durations_sec": [round(d, 4) for d in durations],
                "avg_ms": round(avg_ms, 2),
                "min_ms": round(min_ms, 2),
                "max_ms": round(max_ms, 2),
            }
        )
