"""Intercompany automation operations."""

from __future__ import annotations

from typing import Annotated

import typer

from kctl_odoo.core.callbacks import AppContext

app = typer.Typer(help="Same-DB intercompany automation: status, retry, config.")

_PICKING_FIELDS = [
    "id",
    "name",
    "company_id",
    "ic_target_company_id",
    "ic_target_po_id",
    "ic_sync_state",
    "ic_sync_message",
    "ic_synced_at",
]

# ic.config defaults to active=False on install (explicit opt-in). The model
# has the active field, so Odoo's default search filters out inactive rows —
# which would hide every just-seeded row from us. We pass active_test=False
# to every ic.config search/read so the CLI shows the truth.
_IC_CONFIG_CTX = {"active_test": False}


def _ic_config_search_read(client, domain, fields, order=""):
    kwargs = {"fields": fields, "context": _IC_CONFIG_CTX}
    if order:
        kwargs["order"] = order
    return client.execute_kw("ic.config", "search_read", [domain], kwargs)


def _ic_config_search(client, domain, limit=0):
    kwargs = {"context": _IC_CONFIG_CTX}
    if limit:
        kwargs["limit"] = limit
    return client.execute_kw("ic.config", "search", [domain], kwargs)


@app.command("status")
def status(ctx: typer.Context) -> None:
    """Show ic.config summary + stuck-picking counts."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    configs = _ic_config_search_read(
        c,
        domain=[],
        fields=["id", "company_id", "active", "notify_user_id"],
        order="company_id",
    )
    counts: dict[str, int] = {state: 0 for state in ("pending", "error", "done", "not_applicable", "skipped")}
    by_state = c.read_group(
        "stock.picking",
        domain=[("ic_sync_state", "!=", False)],
        fields=["ic_sync_state"],
        groupby=["ic_sync_state"],
    )
    for row in by_state:
        state_val = row.get("ic_sync_state")
        if state_val and state_val in counts:
            counts[state_val] = row.get("ic_sync_state_count", 0)

    out.table(
        f"ic.config ({len(configs)})",
        [("ID", "cyan"), ("Company", ""), ("Active", ""), ("Notify User", "dim")],
        [
            [
                str(r["id"]),
                (r.get("company_id") or [None, "-"])[1],
                "[green]yes[/green]" if r.get("active") else "[dim]no[/dim]",
                (r.get("notify_user_id") or [None, "-"])[1],
            ]
            for r in configs
        ],
    )
    out.table(
        "Sync state counts",
        [("State", ""), ("Count", "cyan")],
        [[k, str(v)] for k, v in counts.items()],
    )


@app.command("pending")
def pending(
    ctx: typer.Context,
    company: Annotated[str | None, typer.Option("--company")] = None,
    limit: Annotated[int, typer.Option("--limit", "-l")] = 50,
) -> None:
    """List pickings stuck in ic_sync_state=pending."""
    _list_by_state(ctx, "pending", company, limit)


@app.command("errors")
def errors(
    ctx: typer.Context,
    company: Annotated[str | None, typer.Option("--company")] = None,
    limit: Annotated[int, typer.Option("--limit", "-l")] = 50,
) -> None:
    """List pickings stuck in ic_sync_state=error with messages."""
    _list_by_state(ctx, "error", company, limit)


@app.command("retry")
def retry(
    ctx: typer.Context,
    picking_ids: Annotated[str, typer.Argument(help="Comma-separated picking IDs")],
) -> None:
    """Force re-enqueue for the given picking IDs."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    ids = [int(x) for x in picking_ids.split(",") if x.strip()]
    for pid in ids:
        c.execute_kw("stock.picking", "write", [[pid], {"ic_sync_state": "pending"}])
        c.execute_kw("stock.picking", "_ic_create_draft_po", [[pid]])
    out.success(f"Re-enqueued {len(ids)} picking(s)")


@app.command("retry-all-errors")
def retry_all_errors(ctx: typer.Context) -> None:
    """Bulk re-enqueue all pickings in ic_sync_state=error."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    ids = c.search("stock.picking", [("ic_sync_state", "=", "error")])
    for pid in ids:
        c.execute_kw("stock.picking", "write", [[pid], {"ic_sync_state": "pending"}])
        c.execute_kw("stock.picking", "_ic_create_draft_po", [[pid]])
    out.success(f"Re-enqueued {len(ids)} picking(s)")


@app.command("dry-run")
def dry_run(
    ctx: typer.Context,
    picking_id: Annotated[int, typer.Argument()],
) -> None:
    """Preview the PO payload for a picking without committing."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    pick = c.search_read(
        "stock.picking",
        domain=[("id", "=", picking_id)],
        fields=["id", "name", "company_id", "sale_id", "partner_id", "state"],
        limit=1,
    )
    if not pick:
        out.error(f"Picking {picking_id} not found")
        raise typer.Exit(code=1)
    p = pick[0]
    out.table(
        f"Picking {picking_id}",
        [("Field", "dim"), ("Value", "")],
        [
            ["id", str(p.get("id", ""))],
            ["name", str(p.get("name", ""))],
            ["company_id", str((p.get("company_id") or [None, "-"])[1])],
            ["sale_id", str((p.get("sale_id") or [None, "-"])[1])],
            ["partner_id", str((p.get("partner_id") or [None, "-"])[1])],
            ["state", str(p.get("state", ""))],
        ],
    )
    out.info("Run `kctl-odoo intercompany retry <id>` to actually create the PO.")


@app.command("config-show")
def config_show(
    ctx: typer.Context,
    company: Annotated[str | None, typer.Option("--company")] = None,
) -> None:
    """Show ic.config rows."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    domain = []
    if company:
        domain = [("company_id.name", "ilike", company)]
    configs = _ic_config_search_read(
        c,
        domain=domain,
        fields=[
            "id",
            "company_id",
            "active",
            "default_po_user_id",
            "notify_user_id",
            "auto_create_missing_supplier_info",
            "target_company_ids",
            "picking_type_ids",
        ],
        order="company_id",
    )
    if actx.json_mode:
        out.raw_json(configs)
        return
    out.table(
        f"ic.config ({len(configs)})",
        [
            ("ID", "cyan"),
            ("Company", ""),
            ("Active", ""),
            ("PO User", "dim"),
            ("Notify User", "dim"),
            ("Auto Supplier", ""),
        ],
        [
            [
                str(r["id"]),
                (r.get("company_id") or [None, "-"])[1],
                "[green]yes[/green]" if r.get("active") else "[dim]no[/dim]",
                (r.get("default_po_user_id") or [None, "-"])[1],
                (r.get("notify_user_id") or [None, "-"])[1],
                "[green]yes[/green]" if r.get("auto_create_missing_supplier_info") else "[dim]no[/dim]",
            ]
            for r in configs
        ],
    )


@app.command("config-set")
def config_set(
    ctx: typer.Context,
    company: Annotated[str, typer.Argument()],
    target_companies: Annotated[str | None, typer.Option("--target-companies")] = None,
    default_po_user: Annotated[str | None, typer.Option("--default-po-user")] = None,
    notify_user: Annotated[str | None, typer.Option("--notify-user")] = None,
    active: Annotated[bool | None, typer.Option("--active/--inactive")] = None,
) -> None:
    """Update an ic.config row."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    cmps = c.search("res.company", [("name", "ilike", company)])
    if not cmps:
        out.error(f"No company matching {company!r}")
        raise typer.Exit(code=1)
    if len(cmps) > 1:
        out.error(f"Ambiguous company {company!r}: ids={cmps}")
        raise typer.Exit(code=1)
    config = _ic_config_search_read(
        c,
        domain=[("company_id", "=", cmps[0])],
        fields=["id"],
    )
    if not config:
        out.error(f"No ic.config row for company id {cmps[0]}")
        raise typer.Exit(code=1)
    config = config[:1]
    vals: dict = {}
    if active is not None:
        vals["active"] = active
    if default_po_user:
        uids = c.search("res.users", [("login", "=", default_po_user)])
        if uids:
            vals["default_po_user_id"] = uids[0]
        else:
            out.warn(f"User login {default_po_user!r} not found — skipping default_po_user_id")
    if notify_user:
        uids = c.search("res.users", [("login", "=", notify_user)])
        if uids:
            vals["notify_user_id"] = uids[0]
        else:
            out.warn(f"User login {notify_user!r} not found — skipping notify_user_id")
    if target_companies:
        names = [x.strip() for x in target_companies.split(",")]
        tids = c.search("res.company", [("name", "in", names)])
        vals["target_company_ids"] = [(6, 0, tids)]
    if vals:
        c.write("ic.config", [config[0]["id"]], vals)
        out.success(f"Updated ic.config {config[0]['id']}")
    else:
        out.info("Nothing to update")


def _list_by_state(
    ctx: typer.Context,
    state: str,
    company: str | None,
    limit: int,
) -> None:
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    domain: list = [("ic_sync_state", "=", state)]
    if company:
        domain.append(("company_id.name", "ilike", company))
    rows_data = c.search_read(
        "stock.picking",
        domain=domain,
        fields=_PICKING_FIELDS,
        order="write_date desc",
        limit=limit,
    )
    out.table(
        f"Pickings with ic_sync_state={state} ({len(rows_data)})",
        [
            ("ID", "cyan"),
            ("Picking", ""),
            ("Source Co", ""),
            ("Target Co", ""),
            ("Target PO", "dim"),
            ("Message", "dim"),
        ],
        [
            [
                str(r["id"]),
                r.get("name", ""),
                (r.get("company_id") or [None, "-"])[1],
                (r.get("ic_target_company_id") or [None, "-"])[1],
                (r.get("ic_target_po_id") or [None, "-"])[1],
                (r.get("ic_sync_message") or "")[:80],
            ]
            for r in rows_data
        ],
    )
