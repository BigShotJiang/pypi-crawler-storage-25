"""Accurate stock migration commands.

kctl-odoo accurate stock init <slug>          # Tier 1: stock.quant snapshot (Phase 7)
kctl-odoo accurate stock validate-gr <slug>   # Tier 2: RI -> PO linking (Phase 9b)
kctl-odoo accurate stock validate-do <slug>   # Tier 2: DO -> SO linking (Phase 9c)
kctl-odoo accurate stock validate-adj <slug>  # Tier 2: IA standalone pickings (Phase 9d)
kctl-odoo accurate stock validate <slug>      # Tier 3: parity check vs Accurate
"""

from __future__ import annotations

from typing import Annotated

import typer

from kctl_odoo.core.callbacks import AppContext

from ._helpers import _bump_client_timeout, _company_kwargs, _resolve_accurate_company

app = typer.Typer(help="Stock migration commands (snapshot, GR linking, parity).")


@app.command("init")
def init_stock_onhand(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    force: Annotated[bool, typer.Option("--force", help="Re-run even if stock.quant exists")] = False,
    timeout: Annotated[int, typer.Option("--timeout", help="RPC timeout seconds")] = 1800,
) -> None:
    """Initialize stock.quant from Accurate item quantityOnHand."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=float(timeout))

    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Initializing stock for {rec['slug']} (force={force})...")
    result = c.execute_kw(
        "accurate.company",
        "action_init_stock_onhand",
        [[rec["id"]]],
        {**_company_kwargs(rec), "force": force},
    )
    if result.get("skipped"):
        out.warn(f"Skipped: {result.get('reason')} (existing quants: {result.get('existing_quants', 0)})")
        out.warn("Use --force to re-run.")
        raise typer.Exit(0)
    out.success(
        f"Stock init complete: "
        f"{result.get('products_initialized', 0)} products, "
        f"{result.get('quants_created', 0)} quants, "
        f"value Rp {result.get('total_inventory_value', 0):,.2f}"
    )
    if result.get("errors"):
        out.warn(f"{len(result['errors'])} errors (first 10):")
        for e in result["errors"]:
            out.warn(f"  - item {e.get('item_id')}: {e.get('error', '')[:120]}")


@app.command("validate-gr")
def validate_gr(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    timeout: Annotated[int, typer.Option("--timeout", help="RPC timeout seconds")] = 3600,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Report only, no writes")] = False,
) -> None:
    """Phase 9b: Link Accurate receive-items to existing Odoo POs.

    Creates stock.move.line with lot/serial numbers via SQL (no
    accounting impact — JV already imported via Phase 2).
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=float(timeout))

    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Validating GRs for {rec['slug']} (dry_run={dry_run})...")
    result = c.execute_kw(
        "accurate.company",
        "action_validate_gr",
        [[rec["id"]]],
        {**_company_kwargs(rec), "dry_run": dry_run},
    )
    out.success(
        f"GR validation: "
        f"{result.get('receive_items_processed', 0)} RIs, "
        f"{result.get('move_lines_created', 0)} move lines, "
        f"{result.get('lots_assigned', 0)} lots, "
        f"{result.get('pickings_validated', 0)} pickings"
    )
    if result.get("errors"):
        out.warn(f"{len(result['errors'])} errors (first 10):")
        for e in result["errors"][:10]:
            out.warn(f"  - {e}")


@app.command("validate-do")
def validate_do(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    timeout: Annotated[int, typer.Option("--timeout", help="RPC timeout seconds")] = 3600,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Report only, no writes")] = False,
) -> None:
    """Phase 9c: Link Accurate delivery-orders to existing Odoo SO pickings.

    Mirrors validate-gr but for outgoing pickings — creates
    stock.move.line on SO's auto-generated outbound picking via SQL.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=float(timeout))

    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Validating DOs for {rec['slug']} (dry_run={dry_run})...")
    result = c.execute_kw(
        "accurate.company",
        "action_validate_do",
        [[rec["id"]]],
        {**_company_kwargs(rec), "dry_run": dry_run},
    )
    out.success(
        f"DO validation: "
        f"{result.get('delivery_orders_processed', 0)} DOs, "
        f"{result.get('move_lines_created', 0)} move lines, "
        f"{result.get('lots_assigned', 0)} lots, "
        f"{result.get('pickings_validated', 0)} pickings"
    )
    if result.get("errors"):
        out.warn(f"{len(result['errors'])} errors (first 10):")
        for e in result["errors"][:10]:
            out.warn(f"  - {e}")


@app.command("validate-adj")
def validate_adj(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    timeout: Annotated[int, typer.Option("--timeout", help="RPC timeout seconds")] = 3600,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Report only, no writes")] = False,
) -> None:
    """Phase 9d: Create standalone internal pickings from Accurate item-adjustments.

    Each Accurate IA becomes one internal stock.picking with
    source/destination locations based on adjustment sign (positive
    qty = increase = Adjustment loc -> Stock; negative = decrease).
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=float(timeout))

    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Processing adjustments for {rec['slug']} (dry_run={dry_run})...")
    result = c.execute_kw(
        "accurate.company",
        "action_validate_adj",
        [[rec["id"]]],
        {**_company_kwargs(rec), "dry_run": dry_run},
    )
    out.success(
        f"Adjustment processing: "
        f"{result.get('adjustments_processed', 0)} IAs, "
        f"{result.get('pickings_created', 0)} pickings, "
        f"{result.get('moves_created', 0)} moves"
    )
    if result.get("errors"):
        out.warn(f"{len(result['errors'])} errors:")
        for e in result["errors"][:10]:
            out.warn(f"  - {e}")


@app.command("validate")
def validate_stock_parity(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    timeout: Annotated[int, typer.Option("--timeout", help="RPC timeout seconds")] = 1800,
) -> None:
    """Compare Accurate quantityOnHand vs Odoo stock.quant per product.

    Reports variance > 0.0001 as mismatches.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=float(timeout))

    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Comparing stock for {rec['slug']}...")
    result = c.execute_kw(
        "accurate.company",
        "action_validate_stock_parity",
        [[rec["id"]]],
        _company_kwargs(rec),
    )
    n_match = result.get("matches", 0)
    n_diff = len(result.get("variances", []))
    total = n_match + n_diff
    if result.get("passed"):
        out.success(f"Stock parity PASSED: {n_match}/{total} products match")
    else:
        out.warn(f"Stock parity FAILED: {n_match}/{total} products match, {n_diff} variances")
        for v in result.get("variances", [])[:20]:
            out.warn(
                f"  - {v.get('product_code')}: "
                f"Accurate={v.get('accurate_qty')} vs Odoo={v.get('odoo_qty')} "
                f"diff={v.get('diff'):.4f}"
            )
        raise typer.Exit(1)
