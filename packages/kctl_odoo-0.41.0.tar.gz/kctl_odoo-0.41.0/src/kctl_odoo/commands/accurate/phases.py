"""Accurate migration phase commands and pipeline operations.

All commands that execute migration steps: preflight, setup, cutover,
foundation, transactions, verify, sign-off, go-live, attachments,
migrate (sequential), wipe, gap-sync, post-drafts, reconcile,
parity-batch, full-remediate, coa-cleanup, ar-ap-reversal, daily-sync.
"""

from __future__ import annotations

import json
from typing import Annotated

import typer

from kctl_odoo.core.callbacks import AppContext
from kctl_odoo.core.exceptions import ConnectionError, RPCError

from ._helpers import (
    _bump_client_timeout,
    _company_kwargs,
    _resolve_accurate_company,
    _run_via_docker_exec,
)

app = typer.Typer(help="Accurate migration phase commands.")


# --- phases ------------------------------------------------------------


@app.command("preflight")
def preflight(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
) -> None:
    """Run Phase 1 Preflight checks."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Running preflight for {rec['slug']}...")
    report = c.execute_kw("accurate.company", "action_run_preflight", [[rec["id"]]], _company_kwargs(rec))

    # report is either the return dict or None (if write-only model method)
    # action_run_preflight returns the report dict per our implementation
    if not isinstance(report, dict):
        # Refresh to read the persisted summary
        updated = c.search_read(
            "accurate.company.phase",
            domain=[
                ("company_id", "=", rec["id"]),
                ("phase_code", "=", "preflight"),
            ],
            fields=["state", "summary_json"],
            order="create_date desc",
            limit=1,
        )
        if updated and updated[0].get("summary_json"):
            report = json.loads(updated[0]["summary_json"])
        else:
            report = {"checks": [], "all_blockers_passed": False}

    rows = []
    for chk in report.get("checks", []):
        rows.append(
            [
                chk["name"],
                "✓" if chk["passed"] else "✗",
                chk["severity"],
                (chk.get("message") or "")[:80],
            ]
        )
    out.table(
        "Preflight Results",
        [("Check", ""), ("Result", ""), ("Severity", "dim"), ("Message", "dim")],
        rows,
    )
    if not report.get("all_blockers_passed"):
        out.error("Preflight BLOCKED — resolve issues and re-run.")
        raise typer.Exit(1)
    out.success("Preflight PASSED — ready for Setup phase.")


@app.command("setup")
def setup(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    coa_template: Annotated[
        str,
        typer.Option(
            "--coa-template",
            help="Odoo CoA template XML ID to install",
        ),
    ] = "l10n_id.l10n_id_chart_template_amd",
) -> None:
    """Run Phase 2 Setup — install CoA + resolve PPh accounts."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Running setup for {rec['slug']} (CoA: {coa_template})...")
    summary = c.execute_kw(
        "accurate.company",
        "action_run_setup",
        [[rec["id"]]],
        {"coa_template_xmlid": coa_template},
    )
    out.success("Setup PASSED.")
    for k, v in [
        ("CoA Installed", str(summary.get("coa_installed", "-"))),
        ("Mapping Rows Seeded", str(summary.get("mapping_rows_seeded", 0))),
    ]:
        out.kv(k, v)
    pph = summary.get("pph_accounts") or {}
    if pph:
        rows = []
        for field_name, val in pph.items():
            if val:
                rows.append([field_name, val.get("code", "-"), val.get("name", "-")])
            else:
                rows.append([field_name, "-", "NOT FOUND"])
        out.table(
            "PPh Accounts Resolved",
            [("Type", ""), ("Code", ""), ("Name", "dim")],
            rows,
        )


@app.command("phases")
def phases(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    phase: Annotated[
        str | None,
        typer.Option("--phase", help="Filter by phase_code"),
    ] = None,
    state: Annotated[
        str | None,
        typer.Option("--state", help="Filter by state"),
    ] = None,
) -> None:
    """Show phase execution history for one Accurate company."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    rec = _resolve_accurate_company(c, identifier)
    domain = [("company_id", "=", rec["id"])]
    if phase:
        domain.append(("phase_code", "=", phase))
    if state:
        domain.append(("state", "=", state))
    phases_ = c.search_read(
        "accurate.company.phase",
        domain=domain,
        fields=[
            "phase_code",
            "state",
            "started_at",
            "completed_at",
            "duration_s",
            "triggered_by",
            "error_log",
        ],
        order="create_date desc",
        limit=50,
    )
    rows = []
    for p in phases_:
        rows.append(
            [
                p["phase_code"],
                p["state"],
                str(p.get("started_at") or "-"),
                f"{p.get('duration_s', 0):.1f}s",
                (p.get("error_log") or "")[:50],
            ]
        )
    out.table(
        f"Phase History — {rec['slug']} ({len(phases_)})",
        [("Phase", ""), ("State", ""), ("Started", "dim"), ("Dur", "dim"), ("Error", "dim")],
        rows,
        data_for_json=phases_,
    )


# --- cutover ------------------------------------------------------------


@app.command("cutover")
def cutover(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID")],
    cutover_date: Annotated[str, typer.Option("--date", help="YYYY-MM-DD")],
    mode: Annotated[str, typer.Option("--mode")] = "cutover",
) -> None:
    """Phase 3 Cutover Config — commits the cutover date + mode."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Configuring cutover for {rec['slug']} — date={cutover_date} mode={mode}")
    summary = c.execute_kw(
        "accurate.company",
        "action_run_cutover_config",
        [[rec["id"]]],
        {"cutover_date": cutover_date, "mode": mode},
    )
    out.success("Cutover config committed.")
    for k, v in [
        ("Cutover Date", summary.get("cutover_date", "-")),
        ("Current FY Start", summary.get("current_fy_start", "-")),
        ("Mode", summary.get("mode", "-")),
    ]:
        out.kv(k, v)


# --- foundation --------------------------------------------------------


@app.command("foundation")
def foundation(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID")],
    timeout: Annotated[int, typer.Option("--timeout", help="Timeout in seconds")] = 1800,
) -> None:
    """Foundation Sync — master data import with self-healing.

    Calls ``accurate.company.cli_foundation_safe`` which wraps the foundation
    phase in a HealRetry envelope:

    - validation-fixable failures trigger ``validate_company(fix=True)`` + retry
    - transient failures back off + retry
    - quarantine failures flip the company to ``state='needs_review'``

    Exit codes:
      * ``0`` on success OR quarantine (quarantine is normal automated behaviour)
      * ``2`` on truly unexpected errors (RPC down, config missing)
    """
    import traceback

    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Running Foundation sync for {rec['slug']}...")

    is_local = hasattr(actx, "local") and actx.local is not None
    try:
        if is_local:
            result = _run_via_docker_exec(
                actx,
                out,
                "cli_foundation_safe",
                rec["id"],
                kwargs={"domain": [("id", "=", rec["id"])]},
                timeout=timeout,
            )
        else:
            _bump_client_timeout(actx, seconds=float(timeout))
            result = c.execute_kw(
                "accurate.company",
                "cli_foundation_safe",
                [[("id", "=", rec["id"])]],
                _company_kwargs(rec),
            )
    except (ConnectionError, OSError, RPCError, TimeoutError, ValueError) as exc:
        typer.secho(f"✗ {rec['slug']}: ERROR — {exc}", fg=typer.colors.RED, err=True)
        traceback.print_exc()
        raise typer.Exit(2) from exc

    if not isinstance(result, dict):
        typer.secho(
            f"✗ {rec['slug']}: ERROR — unexpected RPC return: {result!r}",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(2)

    state = result.get("state")
    if state == "needs_review" or result.get("quarantined"):
        classification = result.get("classification") or "unknown"
        typer.secho(
            f"⊘ {rec['slug']}: quarantined ({classification}) — "
            "review at Odoo → Accurate → Companies (filter state=Needs Review)",
            fg=typer.colors.YELLOW,
        )
        return  # exit 0 — quarantine is normal automated behaviour

    typer.secho(f"✓ {rec['slug']}: foundation complete", fg=typer.colors.GREEN)


@app.command("foundation-report")
def foundation_report(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID")],
) -> None:
    """Show master data completeness report for a company."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Foundation report for {rec['slug']}...")

    result = c.execute_kw("accurate.company", "action_validate_foundation_gate", [[rec["id"]]])

    rows = []
    for domain in result.get("domains", []):
        status = "PASS" if domain["passed"] else "FAIL"
        rows.append([domain["name"], status, domain.get("detail", "")])

    out.table(
        f"Foundation Gate ({result.get('failed_count', '?')} failures)",
        [("Domain", ""), ("Status", ""), ("Detail", "")],
        rows,
        data_for_json=result,
    )

    if result.get("passed"):
        out.success("Foundation gate PASSED — ready for migration.")
    else:
        out.error("Foundation gate FAILED — fix issues before migration.")
        raise typer.Exit(1)


# --- sync-sc -----------------------------------------------------------


@app.command("sync-sc")
def sync_sc(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID")],
) -> None:
    """Sync Accurate projects → accurate_sales_contract_mapping (backfill).

    Backfills mapping rows for SCs that were created in prior migration runs
    before the mapping write landed. Safe to re-run — idempotent.

    Examples:
        kctl-odoo accurate sync-sc cv-terra-buah-internusa
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Syncing SC mappings for {rec['slug']}...")

    result = c.execute_kw(
        "accurate.company",
        "cli_sync_sales_contracts",
        [[("id", "=", rec["id"])]],
    )

    if not isinstance(result, dict) or result.get("error"):
        typer.secho(
            f"✗ {rec['slug']}: ERROR — {result}",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(2)

    slug = result.get("slug", rec["slug"])
    sc_map_size = result.get("sc_map_size", 0)
    typer.secho(
        f"✓ {slug}: SC mapping sync complete — {sc_map_size} project(s) in sc_map",
        fg=typer.colors.GREEN,
    )


# --- transactions ------------------------------------------------------


@app.command("transactions")
def transactions(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID")],
    phase: Annotated[str, typer.Option("--phase", help="prior|current|both|waves")] = "waves",
    sync: Annotated[
        bool,
        typer.Option(
            "--sync/--async",
            help=(
                "--sync runs the import inline (blocking, results known on "
                "return — good for CI and small tenants). --async enqueues "
                "via queue_job (default; background with OCA queue worker)."
            ),
        ),
    ] = False,
    skip_bs_opening: Annotated[
        bool,
        typer.Option(
            "--skip-bs-opening/--with-bs-opening",
            help="Skip Wave 0 (opening BS JE) for companies that started in the current FY.",
        ),
    ] = True,
    timeout: Annotated[
        int,
        typer.Option(
            "--timeout",
            help=("HTTP client timeout in seconds. Default 900 (15 min). Raise for very large tenants."),
        ),
    ] = 900,
) -> None:
    """Import transactions from Accurate.

    Default mode (--phase waves) uses the wave-based pipeline:
    invoices → payments → bank → JVs, with pre-flight gates,
    auto-reconciliation, and 12-check validation.

    Legacy modes (prior/current/both) call the old phase methods.

    Examples::

        kctl-odoo accurate transactions mandira-copy-frozen
        kctl-odoo accurate transactions mandira-copy-frozen --phase waves --sync
        kctl-odoo accurate transactions my-company --with-bs-opening
    """
    import httpx

    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    c._client.timeout = httpx.Timeout(timeout)
    rec = _resolve_accurate_company(c, identifier)

    if phase == "waves":
        out.info(f"Running wave-based import for {rec['slug']} (timeout={timeout}s)...")
        result = c.execute_kw(
            "accurate.company",
            "action_import_transactions",
            [[rec["id"]]],
            {"skip_bs_opening": skip_bs_opening, "skip_optional": True},
        )
        if isinstance(result, dict):
            validation = result.get("validation", {})
            waves = result.get("waves", [])
            total_moves = sum(w.get("posted", 0) for w in waves)
            tb = next((c for c in validation.get("checks", []) if c["name"] == "tb_parity"), {})
            status = "PASSED ✓" if validation.get("passed") else "FAILED ✗"
            out.success(f"Import complete: {total_moves} moves posted")
            out.info(f"TB: {tb.get('value', '?')}")
            out.info(f"Validation: {status}")
            if not validation.get("passed"):
                for check in validation.get("checks", []):
                    if not check["passed"]:
                        out.warn(f"  ✗ {check['name']}: {check['detail'][:60]}")
        else:
            out.success("Import complete.")
        return

    # Legacy modes
    if phase in ("prior", "both"):
        out.info(f"Running Transactions — Prior-FY Opens ({'sync' if sync else 'async'}, timeout={timeout}s)...")
        c.execute_kw(
            "accurate.company",
            "action_run_transactions_prior",
            [[rec["id"]]],
            {"context": {"accurate_sync_inline": sync}},
        )
        out.success("Prior-FY opens imported.")
    if phase in ("current", "both"):
        out.info(f"Running Transactions — Current FY ({'sync' if sync else 'async'}, timeout={timeout}s)...")
        c.execute_kw(
            "accurate.company",
            "action_run_transactions_current",
            [[rec["id"]]],
            {"context": {"accurate_sync_inline": sync}},
        )
        out.success("Current-FY transactions imported.")


# --- verify / sign-off / go-live ---------------------------------------


@app.command("verify")
def verify(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID")],
) -> None:
    """Phase 7 Verification — generates parity report."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Generating verification report for {rec['slug']}...")
    report_id = c.execute_kw("accurate.company", "action_run_verification", [[rec["id"]]], _company_kwargs(rec))
    # Read report back
    if isinstance(report_id, dict):
        report_id = report_id.get("id")
    elif hasattr(report_id, "id"):
        report_id = report_id.id
    if not isinstance(report_id, int):
        # The method returns the report record — some RPC flavours return {}
        rep = c.search_read(
            "accurate.verification.report",
            domain=[("company_id", "=", rec["id"])],
            fields=["id", "all_passed"],
            limit=1,
            order="create_date desc",
        )
        if not rep:
            out.error("No verification report found.")
            raise typer.Exit(1)
        report_id = rep[0]["id"]
    lines = c.search_read(
        "accurate.verification.line",
        domain=[("report_id", "=", report_id)],
        fields=["check_name", "scope", "accurate_value", "odoo_value", "delta", "passed", "message"],
        order="sequence,id",
    )
    rows = [
        [
            l["check_name"],
            l.get("scope") or "-",
            l.get("accurate_value") or "-",
            l.get("odoo_value") or "-",
            l.get("delta") or "-",
            "✓" if l["passed"] else "✗",
            (l.get("message") or "")[:60],
        ]
        for l in lines
    ]
    out.table(
        f"Verification Report ({len(lines)} checks)",
        [("Check", ""), ("Scope", ""), ("Accurate", ""), ("Odoo", ""), ("Delta", ""), ("Pass", ""), ("Message", "dim")],
        rows,
    )
    failed = [l for l in lines if not l["passed"]]
    if failed:
        out.error(f"{len(failed)} checks FAILED — resolve before sign-off.")
        raise typer.Exit(1)
    out.success("All checks PASSED.")


@app.command("sign-off")
def sign_off(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID")],
    confirm: Annotated[bool, typer.Option("--confirm")] = False,
) -> None:
    """Sign off verification — required before go-live."""
    if not confirm:
        raise typer.BadParameter("Add --confirm to proceed (destructive gate).")
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    rec = _resolve_accurate_company(c, identifier)
    c.execute_kw("accurate.company", "action_sign_off_verification", [[rec["id"]]], _company_kwargs(rec))
    out.success(f"Verification signed off for {rec['slug']} by {actx.username_override or 'current user'}.")


@app.command("go-live")
def go_live(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID")],
) -> None:
    """Phase 8 Go-Live — enable cron sync, state=live."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    rec = _resolve_accurate_company(c, identifier)
    c.execute_kw("accurate.company", "action_run_go_live", [[rec["id"]]], _company_kwargs(rec))
    out.success(f"{rec['slug']} is LIVE — incremental cron sync enabled.")


@app.command("attachments")
def attachments(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID")],
) -> None:
    """Phase 9 Attachments — migrate Accurate attachments to ir.attachment.

    Optional phase. Requires accurate.company.attachments_enabled=True.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Running attachments phase for {rec['slug']}...")
    try:
        summary = c.execute_kw(
            "accurate.company",
            "action_run_attachments",
            [[rec["id"]]],
        )
    except (RPCError, ConnectionError) as exc:
        out.error(f"Attachments failed: {exc}")
        raise typer.Exit(1) from exc
    if summary and summary.get("skipped"):
        out.warn("Attachments phase skipped — attachments_enabled=False.")
    else:
        out.success("Attachments phase complete.")
        if isinstance(summary, dict):
            for k, v in [
                ("Migrated", str(summary.get("migrated_count", 0))),
                ("Skipped", str(summary.get("skipped_count", 0))),
            ]:
                out.kv(k, v)


# --- migrate convenience -----------------------------------------------


@app.command("migrate")
def migrate(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID")],
    dry_run: Annotated[bool, typer.Option("--dry-run/--execute")] = True,
    wipe: Annotated[bool, typer.Option("--wipe", help="Wipe existing data before sync")] = False,
    skip_orders: Annotated[
        bool, typer.Option("--skip-orders/--with-orders", help="Skip PO/SO/stock import (Phase 7-9)")
    ] = False,
    force_fetch: Annotated[
        bool, typer.Option("--force-fetch", help="Bypass JV detail cache, always fetch from API")
    ] = False,
    timeout: Annotated[int, typer.Option("--timeout", help="RPC timeout in seconds")] = 3600,
) -> None:
    """Full CPR migration: foundation + create-post-retype + validation.

    Runs the battle-tested CPR pipeline (action_migrate_cpr) which produces
    the detailed Migration Report visible in the UI.

    Use --skip-orders for fast mode (~6 min vs ~22 min). Orders can be
    imported later with --with-orders.

    Examples::

        kctl-odoo accurate migrate terra-buah                    # dry-run
        kctl-odoo accurate migrate terra-buah --execute          # run
        kctl-odoo accurate migrate terra-buah --execute --wipe   # fresh start
        kctl-odoo accurate migrate terra-buah --execute --wipe --skip-orders  # fast
    """
    import traceback

    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=float(timeout))

    rec = _resolve_accurate_company(c, identifier)
    mode = "DRY-RUN" if dry_run else "EXECUTE"
    out.info(f"CPR Migration for {rec['slug']} [{mode}]{'  --wipe' if wipe else ''}")

    # Note: force_fetch is not currently plumbed through cli_migrate_safe; it
    # is preserved as a CLI flag for forward-compat with action_migrate_cpr.
    safe_kwargs = {
        "domain": [("id", "=", rec["id"])],
        "execute": not dry_run,
        "wipe": wipe,
        "skip_orders": skip_orders,
    }

    is_local = hasattr(actx, "local") and actx.local is not None
    try:
        if is_local and not dry_run:
            result = _run_via_docker_exec(
                actx,
                out,
                "cli_migrate_safe",
                rec["id"],
                kwargs=safe_kwargs,
                timeout=timeout,
            )
        else:
            result = c.execute_kw(
                "accurate.company",
                "cli_migrate_safe",
                [safe_kwargs["domain"]],
                {
                    **_company_kwargs(rec),
                    "execute": safe_kwargs["execute"],
                    "wipe": safe_kwargs["wipe"],
                    "skip_orders": safe_kwargs["skip_orders"],
                },
            )
    except (ConnectionError, OSError, RPCError, TimeoutError, ValueError) as exc:
        typer.secho(f"✗ {rec['slug']}: ERROR — {exc}", fg=typer.colors.RED, err=True)
        traceback.print_exc()
        raise typer.Exit(2) from exc

    if not isinstance(result, dict):
        typer.secho(
            f"✗ {rec['slug']}: ERROR — unexpected RPC return: {result!r}",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(2)

    state = result.get("state")
    if state == "needs_review" or result.get("quarantined"):
        classification = result.get("classification") or "unknown"
        typer.secho(
            f"⊘ {rec['slug']}: quarantined ({classification}) — "
            "review at Odoo → Accurate → Companies (filter state=Needs Review)",
            fg=typer.colors.YELLOW,
        )
        return  # exit 0 — quarantine is normal automated behaviour

    if dry_run:
        typer.secho(
            f"✓ {rec['slug']}: dry-run complete — re-run with --execute to write.",
            fg=typer.colors.GREEN,
        )
    else:
        typer.secho(
            f"✓ {rec['slug']}: migration complete — see Migration Logs in UI for full report.",
            fg=typer.colors.GREEN,
        )


# --- clean-slate wipe (18.0.15.2.0) ------------------------------------


@app.command("wipe")
def wipe(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID, or 'all'")],
    dry_run: Annotated[
        bool, typer.Option("--dry-run/--execute", help="Preview only (default); use --execute to actually delete")
    ] = True,
    confirm: Annotated[bool, typer.Option("--confirm", help="Required with --execute to proceed")] = False,
) -> None:
    """Wipe migrated transactions while preserving all masters/config.

    Idempotent SQL-based cleanup for clean-slate remigration. Preserves:
    accurate.company config, mappings, parity history, foundation ext-ids
    (customer/vendor/item/glaccount/currency/unit/tax/...), CoA accounts,
    partners, products. Deletes: every account.move tagged with
    x_accurate_migration_source, its lines, partial/full reconciles,
    payment ext-ids, and transaction-module ir.model.data.

    Pass ``all`` as identifier to wipe every accurate.company on this DB.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    if not dry_run and not confirm:
        raise typer.BadParameter("Add --confirm to proceed with --execute (destructive).")

    if identifier == "all":
        targets = c.search_read("accurate.company", domain=[], fields=["id", "slug"], order="id")
    else:
        rec = _resolve_accurate_company(c, identifier)
        targets = [{"id": rec["id"], "slug": rec["slug"]}]

    totals = {"moves": 0, "move_lines": 0, "partial_reconcile": 0, "account_payment": 0, "ir_model_data": 0}
    rows = []
    for t in targets:
        res = c.execute_kw(
            "accurate.company",
            "action_wipe_migrated_transactions",
            [[t["id"]]],
            {"dry_run": dry_run},
        )
        rows.append(
            [
                t["slug"],
                str(res["moves"]),
                str(res["move_lines"]),
                str(res["partial_reconcile"]),
                str(res["account_payment"]),
                str(res["ir_model_data"]),
                f"{res.get('elapsed_seconds', 0)}s" if not dry_run else "-",
            ]
        )
        for k in totals:
            totals[k] += res[k]
    header = "Wipe DRY-RUN preview" if dry_run else "Wipe EXECUTED"
    out.table(
        f"{header} ({len(targets)} tenant{'s' if len(targets) != 1 else ''})",
        [("Tenant", ""), ("Moves", ""), ("Lines", ""), ("Recon", ""), ("Pays", ""), ("IMD", ""), ("Elapsed", "dim")],
        rows,
    )
    out.kv("Total moves", str(totals["moves"]))
    out.kv("Total ext-ids", str(totals["ir_model_data"]))
    if dry_run:
        out.warn("DRY-RUN — nothing deleted. Add --execute --confirm to run.")
    else:
        out.success(f"Wiped {totals['moves']} moves across {len(targets)} tenant(s).")


@app.command("wipe-validate")
def wipe_validate(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID, or 'all'")],
) -> None:
    """Validate a post-wipe tenant — confirm transactions are truly clean.

    Checks: no migrated moves remain, no transaction-module ext-ids
    remain, no orphan move-lines, no orphan partial_reconcile, no
    orphan account.payment. Also reports foundation + config
    preservation counts (positive proof masters survived).

    Exits non-zero if ANY check flags an issue.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    if identifier == "all":
        targets = c.search_read("accurate.company", domain=[], fields=["id", "slug"], order="id")
    else:
        rec = _resolve_accurate_company(c, identifier)
        targets = [{"id": rec["id"], "slug": rec["slug"]}]

    any_dirty = False
    for t in targets:
        res = c.execute_kw("accurate.company", "action_validate_wipe_clean", [[t["id"]]])
        status = "✓ CLEAN" if res["clean"] else "✗ DIRTY"
        out.kv(t["slug"], status)
        if not res["clean"]:
            any_dirty = True
            for issue in res["issues"]:
                out.error(f"  - {issue}")
        fp = res["foundation_preserved"]
        out.kv(
            "  foundation",
            f"customers={fp.get('customer', 0)} vendors={fp.get('vendor', 0)} items={fp.get('item', 0)} glaccounts={fp.get('glaccount', 0)} taxes={fp.get('tax', 0)}",
        )
        cp = res["config_preserved"]
        out.kv(
            "  config",
            f"company={cp.get('accurate.company', 0)} account_mapping={cp.get('accurate.account.mapping', 0)} parity_reports={cp.get('accurate.parity.report', 0)}",
        )
    if any_dirty:
        out.error("One or more tenants FAILED validation.")
        raise typer.Exit(1)
    out.success("All tenants validated clean.")


@app.command("post-drafts")
def post_drafts(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID, or 'all'")],
    dry_run: Annotated[bool, typer.Option("--dry-run/--execute")] = True,
) -> None:
    """Post every draft account.move/payment tagged by the migration.

    Wraps ``accurate.company.action_post_draft_imports``.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx)

    if identifier == "all":
        targets = c.search_read("accurate.company", domain=[], fields=["id", "slug"], order="id")
    else:
        rec = _resolve_accurate_company(c, identifier)
        targets = [{"id": rec["id"], "slug": rec["slug"]}]

    for t in targets:
        res = c.execute_kw(
            "accurate.company",
            "action_post_draft_imports",
            [[t["id"]]],
            {"dry_run": dry_run},
        )
        out.kv(
            t["slug"],
            f"candidates={res['move_candidates']} posted={res['moves_posted']} "
            f"failed={len(res['moves_failed'])} payments_posted={res['payments_posted']}",
        )
        for f in res.get("moves_failed", [])[:5]:
            out.warn(f"  FAIL {f.get('move_id')}: {(f.get('error', '') or '')[:150]}")


@app.command("reconcile")
def reconcile(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID, or 'all'")],
    dry_run: Annotated[bool, typer.Option("--dry-run/--execute")] = True,
) -> None:
    """Reconcile AR/AP lines across migrated payment + invoice moves.

    Wraps ``accurate.company.action_reconcile_migrated_move_lines``.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx)

    if identifier == "all":
        targets = c.search_read("accurate.company", domain=[], fields=["id", "slug"], order="id")
    else:
        rec = _resolve_accurate_company(c, identifier)
        targets = [{"id": rec["id"], "slug": rec["slug"]}]

    for t in targets:
        res = c.execute_kw(
            "accurate.company",
            "action_reconcile_migrated_move_lines",
            [[t["id"]]],
            {"dry_run": dry_run},
        )
        out.kv(
            t["slug"],
            f"groups={res.get('groups_found', 0)} reconciled={res.get('groups_reconciled', 0)} "
            f"skipped={len(res.get('groups_skipped') or [])}",
        )


@app.command("parity-batch")
def parity_batch(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID, or 'all'")],
    as_of: Annotated[str, typer.Option("--as-of", help="YYYY-MM-DD")] = "2026-03-31",
) -> None:
    """Run the 12-check parity framework and print BS/PL/TB delta.

    Wraps ``accurate.company.action_run_parity``. Writes a new
    ``accurate.parity.report``. Exits non-zero if any key check fails.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx)

    if identifier == "all":
        targets = c.search_read("accurate.company", domain=[], fields=["id", "slug"], order="id")
    else:
        rec = _resolve_accurate_company(c, identifier)
        targets = [{"id": rec["id"], "slug": rec["slug"]}]

    any_fail = False
    for t in targets:
        c.execute_kw(
            "accurate.company",
            "action_run_parity",
            [[t["id"]]],
            {"as_of": as_of},
        )
        reps = c.search_read(
            "accurate.parity.report",
            domain=[("company_id", "=", t["id"])],
            fields=["id"],
            order="id desc",
            limit=1,
        )
        if not reps:
            out.error(f"{t['slug']}: no parity report emitted")
            any_fail = True
            continue
        rep_id = reps[0]["id"]
        lines = c.search_read(
            "accurate.parity.line",
            domain=[
                ("report_id", "=", rep_id),
                ("check_name", "in", ("trial_balance", "bs", "pnl", "ar_aging", "ap_aging")),
            ],
            fields=["check_name", "accurate_total", "odoo_total", "passed"],
        )
        rows = []
        for ln in lines:
            A = ln.get("accurate_total") or 0
            O = ln.get("odoo_total") or 0
            ratio = f"{(O / A):.2f}x" if A else "n/a"
            rows.append(
                [
                    ln["check_name"],
                    f"{A:,.0f}",
                    f"{O:,.0f}",
                    f"{O - A:+,.0f}",
                    ratio,
                    "✓" if ln["passed"] else "✗",
                ]
            )
            if not ln["passed"]:
                any_fail = True
        out.table(
            f"{t['slug']} parity (as_of={as_of}, report={rep_id})",
            [("Check", ""), ("Accurate", ""), ("Odoo", ""), ("Δ", ""), ("Ratio", ""), ("Pass", "")],
            rows,
        )

    if any_fail:
        raise typer.Exit(1)


# --- coa-cleanup -------------------------------------------------------


@app.command("coa-cleanup")
def coa_cleanup(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID, or 'all' for every live company")],
    confirm: Annotated[bool, typer.Option("--confirm", help="Required to proceed (write SQL)")] = False,
) -> None:
    """Migrate factory l10n_id CoA → Accurate CoA per company.

    After Accurate import, both CoAs coexist on the company:
    - Factory: 11210010 Account Receivable, 21100010 Trade Receivable, ...
    - Accurate: 1100.01 Piutang Dagang IDR, 2000.09 Hutang Dagang IDR, ...

    Transactions booked through Odoo defaults can land on factory accounts.
    This command re-points all move lines + property defaults onto Accurate
    accounts, then removes the factory accounts from the company. Result:
    only Accurate-style codes remain, AR/AP balances match Accurate exactly.

    Idempotent — safe to re-run.
    """
    if not confirm:
        raise typer.BadParameter("Add --confirm to proceed (modifies account_move_line + ir_property + journals).")

    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=1800.0)

    if identifier == "all":
        targets = c.search_read(
            "accurate.company",
            domain=[("state", "in", ("in_progress", "live"))],
            fields=["id", "slug"],
            order="id",
        )
    else:
        rec = _resolve_accurate_company(c, identifier)
        targets = [{"id": rec["id"], "slug": rec["slug"]}]

    rows = []
    for t in targets:
        out.info(f"=== {t['slug']} ===")
        try:
            r = c.execute_kw(
                "accurate.company",
                "action_cleanup_factory_coa",
                [[t["id"]]],
            )
        except (RPCError, ConnectionError, KeyError, ValueError) as exc:
            out.error(f"  FAILED: {exc}")
            rows.append([t["slug"], "FAIL", str(exc)[:60]])
            continue

        out.kv("  factories_found", str(r.get("factories_found", 0)))
        out.kv("  moved_lines", str(r.get("moved_lines", 0)))
        out.kv("  factories_removed", str(r.get("factories_removed", 0)))
        out.kv("  remaining_factory", str(r.get("remaining_factory", 0)))
        out.kv("  remaining_dotted", str(r.get("remaining_dotted", 0)))
        ar = r.get("ar_balance", 0)
        ap = r.get("ap_balance", 0)
        out.kv("  AR", f"{ar:+,.0f}")
        out.kv("  AP", f"{ap:+,.0f}")
        rows.append(
            [
                t["slug"],
                str(r.get("factories_found", 0)),
                str(r.get("factories_removed", 0)),
                str(r.get("moved_lines", 0)),
                str(r.get("remaining_factory", 0)),
                f"{ar:+,.0f}",
                f"{ap:+,.0f}",
            ]
        )

    if len(rows) > 1:
        out.table(
            ["slug", "found", "removed", "moved", "remain", "AR", "AP"],
            rows,
        )


@app.command("ar-ap-reversal")
def ar_ap_reversal(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID, or 'all'")],
    confirm: Annotated[bool, typer.Option("--confirm", help="Required to proceed")] = False,
) -> None:
    """Post the AR/AP reversal JE to neutralise bulk opening AR/AP.

    The opening JE bulk-imports AR/AP from Accurate's TB at cutover.
    When outstanding-equivalent invoices are also imported (via
    `outstanding_open_items` OR `gap_sync` source) the AR/AP is
    doubled. This command posts a reversal JE that zeroes the
    bulk AR/AP so the individual outstanding invoices remain the
    only AR/AP balance.

    Idempotent — skips when a reversal JE already exists.
    """
    if not confirm:
        raise typer.BadParameter("Add --confirm to proceed (posts a JE).")

    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=900.0)

    if identifier == "all":
        targets = c.search_read(
            "accurate.company",
            domain=[("state", "in", ("in_progress", "live"))],
            fields=["id", "slug"],
            order="id",
        )
    else:
        rec = _resolve_accurate_company(c, identifier)
        targets = [{"id": rec["id"], "slug": rec["slug"]}]

    for t in targets:
        out.info(f"=== {t['slug']} ===")
        try:
            r = c.execute_kw(
                "accurate.company",
                "action_run_ar_ap_reversal",
                [[t["id"]]],
            )
        except (RPCError, ConnectionError, KeyError, ValueError) as exc:
            out.error(f"  FAILED: {exc}")
            continue

        if r.get("skipped"):
            out.kv("  status", f"skipped ({r.get('reason')})")
            if r.get("move_id"):
                out.kv("  existing", f"id={r['move_id']} name={r.get('move_name')}")
        else:
            out.kv("  posted", f"id={r.get('move_id')} name={r.get('move_name')}")
            out.kv("  reversed", f"{r.get('total_reversed', 0):+,.0f}")
            out.kv("  lines", str(r.get("lines_count", 0)))


# --- daily-sync --------------------------------------------------------


@app.command("daily-sync")
def daily_sync(
    ctx: typer.Context,
    slug: Annotated[str, typer.Argument(help="Company slug")],
) -> None:
    """Run incremental delta sync for a company.

    Fetches records modified since last sync. Creates new, updates modified,
    logs cancelled. Safe to run repeatedly.

    Examples:
        kctl-odoo accurate daily-sync 26-bb-cv-sentra-agro-nusantara
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    company_ids = c.search("accurate.company", [("slug", "=", slug)])
    if not company_ids:
        out.error(f"Company not found: {slug}")
        raise typer.Exit(1)

    result = c.execute_kw("accurate.company", "action_daily_sync", [company_ids])

    out.info(f"Delta sync: {slug}")
    out.info(f"  Created:   {result.get('created', 0)}")
    out.info(f"  Updated:   {result.get('updated', 0)}")
    out.info(f"  Cancelled: {result.get('cancelled', 0)}")
    out.info(f"  Errors:    {result.get('errors', 0)}")

    if result.get("errors", 0) == 0:
        out.success("Delta sync complete")
    else:
        out.error(f"Delta sync completed with {result['errors']} errors")


# --- business-validation ------------------------------------------------


@app.command("business-validation")
def business_validation(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Slug or ID")],
) -> None:
    """Run company health check + business scenario validation.

    Part A: All 12 company validators (COA, journals, banks, etc.)
    Part B: Full business scenario (SC→PO→GR→Bill→Pay→Sales) in savepoint

    Results logged to Migration Logs (Accurate > Migration > Migration Logs).

    Examples::

        kctl-odoo accurate business-validation 26-bb-cv-sentra-agro-nusantara
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=600.0)

    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Running business validation for {rec['slug']}...")

    result = c.execute_kw(
        "accurate.company",
        "action_run_business_validation",
        [[rec["id"]]],
    )

    if result.get("passed"):
        out.success(
            f"Business validation PASSED — health: {result.get('health_total', 0)} checks, scenario: {result.get('scenario_passed', 0)} pass"
        )
    else:
        out.error(
            f"Business validation ISSUES — health: {result.get('health_total', 0)} checks, scenario: {result.get('scenario_passed', 0)} pass"
        )
    out.info("See full report in: Accurate > Migration > Migration Logs")


# --- Standalone per-phase actions (2026-05-19 decomposition) ----------
# Each phase callable independently for ~30s iteration vs ~8min monolith.
# Backed by accurate.company.action_phase_X methods. See plan:
# docs/superpowers/plans/2026-05-19-cpr-phase-decomposition.md


@app.command("phase-stock-init")
def phase_stock_init(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Skip writes")] = False,
    timeout: Annotated[int, typer.Option("--timeout", help="RPC timeout seconds")] = 1800,
) -> None:
    """Phase 7 standalone: stock.quant + SVL from Accurate items.

    Preflight: phase1 (master data) + phase2 (JV import) must be done.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=float(timeout))
    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Running Phase 7 stock init for {rec['slug']} (dry_run={dry_run})...")
    result = c.execute_kw(
        "accurate.company",
        "action_phase_stock_init",
        [[rec["id"]]],
        {**_company_kwargs(rec), "dry_run": dry_run},
    )
    if result.get("ok"):
        out.success(
            f"Phase 7 OK — {result.get('quants_created', 0)} quants, {result.get('svl_created', 0)} SVL records"
        )
    else:
        out.error(f"Phase 7 FAILED — {result.get('errors', [])}")
        raise typer.Exit(1)


@app.command("phase-orders")
def phase_orders(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Skip writes")] = False,
    timeout: Annotated[int, typer.Option("--timeout", help="RPC timeout seconds")] = 3600,
) -> None:
    """Phase 9 standalone: import PO + SO from Accurate.

    Preflight: phase1 + phase2 done. Per-record savepoint isolation
    keeps one bad PO/SO from poisoning the whole phase transaction.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=float(timeout))
    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Running Phase 9 orders import for {rec['slug']} (dry_run={dry_run})...")
    result = c.execute_kw(
        "accurate.company",
        "action_phase_orders",
        [[rec["id"]]],
        {**_company_kwargs(rec), "dry_run": dry_run},
    )
    if result.get("ok"):
        out.success(
            f"Phase 9 OK — {result.get('po_created', 0)} PO + "
            f"{result.get('so_created', 0)} SO, "
            f"{result.get('po_bill_links', 0)} bill-line links"
        )
    else:
        out.error(f"Phase 9 FAILED — {result.get('errors', [])}")
        raise typer.Exit(1)


@app.command("phase-purchase-orders")
def phase_purchase_orders(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Skip writes")] = False,
    timeout: Annotated[int, typer.Option("--timeout", help="RPC timeout seconds")] = 3600,
) -> None:
    """Phase 9 PO-only: import purchase orders from Accurate.

    Memory-friendlier than `phase-orders` for big tenants. Pair with
    `phase-sales-orders` to cover SO in a separate call.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=float(timeout))
    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Running Phase 9 PO import for {rec['slug']} (dry_run={dry_run})...")
    result = c.execute_kw(
        "accurate.company",
        "action_phase_purchase_orders",
        [[rec["id"]]],
        {**_company_kwargs(rec), "dry_run": dry_run},
    )
    if result.get("ok"):
        out.success(
            f"Phase 9 (PO) OK — {result.get('po_created', 0)} PO, {result.get('po_bill_links', 0)} bill-line links"
        )
    else:
        out.error(f"Phase 9 (PO) FAILED — {result.get('errors', [])}")
        raise typer.Exit(1)


@app.command("phase-sales-orders")
def phase_sales_orders(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Skip writes")] = False,
    timeout: Annotated[int, typer.Option("--timeout", help="RPC timeout seconds")] = 3600,
) -> None:
    """Phase 9 SO-only: import sales orders from Accurate.

    Skips the bill-line → PO-line UPDATE (only relevant when POs were created).
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=float(timeout))
    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Running Phase 9 SO import for {rec['slug']} (dry_run={dry_run})...")
    result = c.execute_kw(
        "accurate.company",
        "action_phase_sales_orders",
        [[rec["id"]]],
        {**_company_kwargs(rec), "dry_run": dry_run},
    )
    if result.get("ok"):
        out.success(f"Phase 9 (SO) OK — {result.get('so_created', 0)} SO")
    else:
        out.error(f"Phase 9 (SO) FAILED — {result.get('errors', [])}")
        raise typer.Exit(1)


@app.command("phase-bank")
def phase_bank(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Skip writes")] = False,
    timeout: Annotated[int, typer.Option("--timeout", help="RPC timeout seconds")] = 600,
) -> None:
    """Phase 8 standalone: create bank statement lines from JV-imported moves."""
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=float(timeout))
    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Running Phase 8 bank for {rec['slug']} (dry_run={dry_run})...")
    result = c.execute_kw(
        "accurate.company",
        "action_phase_bank",
        [[rec["id"]]],
        {**_company_kwargs(rec), "dry_run": dry_run},
    )
    if result.get("ok"):
        out.success(f"Phase 8 OK — {result.get('bank_statement_lines', 0)} statement lines")
    else:
        out.error(f"Phase 8 FAILED — {result.get('errors', [])}")
        raise typer.Exit(1)


@app.command("phase-bootstrap")
def phase_bootstrap(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Skip writes")] = False,
    timeout: Annotated[int, typer.Option("--timeout", help="RPC timeout seconds")] = 600,
) -> None:
    """Phase 0 standalone: bootstrap a new company (self-healing setup).

    Runs _bootstrap_new_company: stale mapping cleanup, account dedup +
    code_store, defaults configuration, company settings cleanup, bank
    journal auto-create, tax/CoA mapping auto-approve. Idempotent.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=float(timeout))
    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Running Phase 0 bootstrap for {rec['slug']} (dry_run={dry_run})...")
    result = c.execute_kw(
        "accurate.company",
        "action_phase_bootstrap",
        [[rec["id"]]],
        {**_company_kwargs(rec), "dry_run": dry_run},
    )
    if result.get("ok"):
        out.success(
            f"Phase 0 OK — accounts_deduped={result.get('accounts_deduped', 0)} "
            f"bank_journals_created={result.get('bank_journals_created', 0)} "
            f"mappings_approved={result.get('mappings_approved', 0)}"
        )
    else:
        out.error(f"Phase 0 FAILED — {result.get('errors', [])}")
        raise typer.Exit(1)


@app.command("phase-master-data")
def phase_master_data(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Skip writes")] = False,
    force_fetch: Annotated[
        bool, typer.Option("--force-fetch", help="Bypass JV detail cache, always fetch from API")
    ] = False,
    timeout: Annotated[int, typer.Option("--timeout", help="RPC timeout seconds")] = 1800,
) -> None:
    """Phase 1 standalone: master data fetch + 21 validation checks.

    Runs JV list fetch, parallel JV detail prefetch (10 workers), account
    validation, then 21-check 2-tier validation (Tier 1 blocking, Tier 2
    warnings). Use --force-fetch to bypass the JV detail cache.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=float(timeout))
    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Running Phase 1 master data for {rec['slug']} (dry_run={dry_run})...")
    result = c.execute_kw(
        "accurate.company",
        "action_phase_master_data",
        [[rec["id"]]],
        {**_company_kwargs(rec), "dry_run": dry_run, "force_fetch": force_fetch},
    )
    if result.get("ok"):
        out.success(
            f"Phase 1 OK — jv_count={result.get('jv_count', 0)} "
            f"passed_checks={result.get('passed_checks', 0)}/{result.get('total_checks', 0)}"
        )
    else:
        out.error(f"Phase 1 FAILED — {result.get('errors', [])}")
        raise typer.Exit(1)


@app.command("phase-jvs")
def phase_jvs(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Skip writes")] = False,
    force_fetch: Annotated[
        bool, typer.Option("--force-fetch", help="Bypass JV detail cache, always fetch from API")
    ] = False,
    timeout: Annotated[int, typer.Option("--timeout", help="RPC timeout seconds")] = 3600,
) -> None:
    """Phase 2 standalone: create + post account.move from cached JV details.

    Creates account.move records from Phase 1 cached JV details, posts in
    batches of 200, runs code_store repair (sets Accurate codes from JV GL
    lines), then retries any drafts that failed pre-repair.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=float(timeout))
    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Running Phase 2 JV import for {rec['slug']} (dry_run={dry_run})...")
    result = c.execute_kw(
        "accurate.company",
        "action_phase_import_jvs",
        [[rec["id"]]],
        {**_company_kwargs(rec), "dry_run": dry_run, "force_fetch": force_fetch},
    )
    if result.get("ok"):
        out.success(
            f"Phase 2 OK — created={result.get('created', 0)} "
            f"posted={result.get('posted', 0)} "
            f"skipped={result.get('skipped', 0)} "
            f"errors={result.get('errors_count', 0)}"
        )
    else:
        out.error(f"Phase 2 FAILED — {result.get('errors', [])}")
        raise typer.Exit(1)


@app.command("phase-retype")
def phase_retype(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Skip writes")] = False,
    timeout: Annotated[int, typer.Option("--timeout", help="RPC timeout seconds")] = 1800,
) -> None:
    """Phase 3 standalone: SQL retype SI→out_invoice / PI→in_invoice + enrich.

    SQL-level move_type retype, move_name sync on lines after retype, then
    parallel SI/PI prefetch (10 workers) with per-product detail + rounding
    adjustment, plus deferred FX handling.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=float(timeout))
    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Running Phase 3 retype for {rec['slug']} (dry_run={dry_run})...")
    result = c.execute_kw(
        "accurate.company",
        "action_phase_retype",
        [[rec["id"]]],
        {**_company_kwargs(rec), "dry_run": dry_run},
    )
    if result.get("ok"):
        out.success(
            f"Phase 3 OK — retyped={result.get('retyped', 0)} "
            f"enriched={result.get('enriched', 0)} "
            f"fx_applied={result.get('fx_applied', 0)}"
        )
    else:
        out.error(f"Phase 3 FAILED — {result.get('errors', [])}")
        raise typer.Exit(1)


@app.command("phase-payments")
def phase_payments(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Skip writes")] = False,
    timeout: Annotated[int, typer.Option("--timeout", help="RPC timeout seconds")] = 600,
) -> None:
    """Phase 5 standalone: create account.payment from classified JVs.

    Classifies migrated JVs by transaction type and emits account.payment
    records (sales-receipt, purchase-payment, bank-receipt, bank-disbursement).
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=float(timeout))
    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Running Phase 5 payments for {rec['slug']} (dry_run={dry_run})...")
    result = c.execute_kw(
        "accurate.company",
        "action_phase_payments",
        [[rec["id"]]],
        {**_company_kwargs(rec), "dry_run": dry_run},
    )
    if result.get("ok"):
        out.success(
            f"Phase 5 OK — payments_created={result.get('payments_created', 0)} skipped={result.get('skipped', 0)}"
        )
    else:
        out.error(f"Phase 5 FAILED — {result.get('errors', [])}")
        raise typer.Exit(1)


@app.command("phase-reconcile")
def phase_reconcile(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Skip writes")] = False,
    timeout: Annotated[int, typer.Option("--timeout", help="RPC timeout seconds")] = 600,
) -> None:
    """Phase 6 standalone: match AR/AP partials across migrated lines.

    Reconciles partial AR/AP across migrated payment + invoice moves.
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=float(timeout))
    rec = _resolve_accurate_company(c, identifier)
    out.info(f"Running Phase 6 reconcile for {rec['slug']} (dry_run={dry_run})...")
    result = c.execute_kw(
        "accurate.company",
        "action_phase_reconcile",
        [[rec["id"]]],
        {**_company_kwargs(rec), "dry_run": dry_run},
    )
    if result.get("ok"):
        out.success(
            f"Phase 6 OK — groups_found={result.get('groups_found', 0)} "
            f"groups_reconciled={result.get('groups_reconciled', 0)}"
        )
    else:
        out.error(f"Phase 6 FAILED — {result.get('errors', [])}")
        raise typer.Exit(1)


# --- Orphan-move audit & purge -----------------------------------------
# Single-source-of-truth enforcement: account.move with migrate.* ext-id
# whose accurate_id has dropped out of the JV cache (e.g. voided in
# Accurate). audit reports, purge reconciles by probing Accurate API.


@app.command("audit-orphans")
def audit_orphans(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    show_all: Annotated[bool, typer.Option("--show-all", help="Print every orphan row")] = False,
) -> None:
    """Report account.move records whose accurate_id is missing from JV cache.

    Pure read. Use this to understand drift before running purge-orphans.

    Examples:
        kctl-odoo accurate audit-orphans cv-mandira-buah-nusaprima
        kctl-odoo accurate audit-orphans cv-mandira-buah-nusaprima --show-all
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=300.0)
    rec = _resolve_accurate_company(c, identifier)
    result = c.execute_kw("accurate.company", "audit_orphan_moves", [[rec["id"]]])
    out.info(f"Company:    {result['company']} ({result['slug']})")
    out.info(f"JV cache:   {result['cache_count']}")
    out.info(f"ext-ids:    {result['ext_id_count']}")
    out.info(f"orphans:    {result['orphan_count']}")
    if result["orphan_count"] == 0:
        out.success("No orphans — Odoo moves match JV cache 1:1.")
        return
    orphans = result["orphans"]
    show = orphans if show_all else orphans[:20]
    out.warning(f"Orphan moves (Odoo has, cache doesn't) — showing {len(show)} of {len(orphans)}:")
    for o in show:
        out.info(
            f"  aid={o['accurate_id']:>6}  move={o.get('move_id'):>7}  "
            f"name={o.get('name') or '?':<20}  state={o.get('state') or '?':<10}  "
            f"date={o.get('date') or '?':<11}  total={o.get('amount_total') or 0}"
        )
    if not show_all and len(orphans) > len(show):
        out.info(f"  ... ({len(orphans) - len(show)} more — pass --show-all)")
    out.info("")
    out.info("Next: kctl-odoo accurate purge-orphans <slug>           # dry-run")
    out.info("      kctl-odoo accurate purge-orphans <slug> --execute # destructive")


@app.command("purge-orphans")
def purge_orphans(
    ctx: typer.Context,
    identifier: Annotated[str, typer.Argument(help="Accurate company slug or ID")],
    execute: Annotated[bool, typer.Option("--execute", help="Actually delete (default: dry-run)")] = False,
    show_all: Annotated[bool, typer.Option("--show-all", help="Print every classified row")] = False,
) -> None:
    """Reconcile orphan moves by probing Accurate API per id.

    Pipeline: audit → probe each orphan's accurate_id via
    /journal-voucher/detail.do → classify into:

    - purgeable: API says deleted=true OR 404. Safe to delete.
    - cache_gap: API still has it (cache fetch missed it — bug).
                 Will NOT be deleted; warning logged.
    - probe_error: transient API failure; will retry next run.

    With --execute, purgeable moves are reset_to_draft + unlinked.
    Moves with reconciled lines are skipped.

    Examples:
        kctl-odoo accurate purge-orphans cv-mandira-buah-nusaprima           # dry-run
        kctl-odoo accurate purge-orphans cv-mandira-buah-nusaprima --execute # delete
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client
    _bump_client_timeout(actx, seconds=1800.0)
    rec = _resolve_accurate_company(c, identifier)
    label = "EXECUTE" if execute else "DRY-RUN"
    out.info(f"Purging orphans for {rec['slug']} [{label}]...")
    result = c.execute_kw(
        "accurate.company",
        "purge_orphan_moves",
        [[rec["id"]]],
        {"dry_run": not execute},
    )
    out.info(f"Company:           {result['company']} ({result['slug']})")
    out.info(f"audited:           {result['audited']}")
    out.info(f"purgeable:         {result['purgeable']}  (API confirms deleted/missing)")
    if result["cache_gap"]:
        out.error(f"cache_gap:         {result['cache_gap']}  (API STILL HAS — cache fetch bug; NOT deleting)")
    if result["probe_error"]:
        out.warning(f"probe_error:       {result['probe_error']}  (transient; retry next run)")
    out.info(f"purged:            {result['purged']}")
    if result["skipped_reconciled"]:
        out.warning(f"skipped_reconciled:{result['skipped_reconciled']}  (had reconciled lines; manual reset needed)")
    if result["errors"]:
        out.error(f"errors:            {len(result['errors'])}")
        for e in result["errors"][:10]:
            out.error(f"  {e}")
    if show_all and result.get("details"):
        out.info("")
        out.info("--- Detail ---")
        for d in result["details"]:
            out.info(
                f"  aid={d['accurate_id']:>6}  api_exists={d.get('api_exists')}  "
                f"api_deleted={d.get('api_deleted')}  api_number={d.get('api_number') or '?':<25}  "
                f"odoo_name={d.get('name') or '?':<20}"
            )
    if not execute:
        out.info("")
        out.info("Dry-run only. Add --execute to delete the 'purgeable' set.")
    elif result["purged"]:
        out.success(f"Purged {result['purged']} orphan moves.")
    else:
        out.success("Nothing to purge.")
