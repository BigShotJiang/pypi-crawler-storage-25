"""Cancel wrong Odoo entries and create JV-driven replacements with exact Accurate amounts.

Given a :class:`JVComparison` (from :mod:`jv_comparator`) whose ``status`` is
``"mismatch"``, this module:

1. Finds bills/invoices reconciled to the old move (via ``account.payment``).
2. Cancels the old move (or its payment, if one exists).
3. Creates a new ``account.move`` of type ``entry`` with exact Accurate GL lines.
4. Posts the new entry.
5. Reconciles the payable/receivable line(s) on the new entry with the original
   bills so the AP/AR balance stays correct.

Usage::

    from jv_fixer import fix_mismatch, FixResult

    result: FixResult = fix_mismatch(client, odoo_company, comparison)
    if result.success:
        print(f"Fixed {result.jv_number}: old={result.old_move_id} → new={result.new_move_id}")
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from ._helpers import (
    accurate_date_to_odoo,
    resolve_account_by_code,
    resolve_account_by_name,
    resolve_partner_by_ref,
)

if TYPE_CHECKING:
    from kctl_odoo.core.client import OdooClient

    from .jv_comparator import JVComparison, NormalizedLine

from kctl_odoo.core.exceptions import ConnectionError, RPCError

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------


@dataclass
class FixResult:
    """Outcome of a single fix attempt."""

    jv_number: str
    old_move_id: int | None
    new_move_id: int | None
    success: bool
    message: str
    reconciled_bill_ids: list[int] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def fix_mismatch(
    client: OdooClient,
    odoo_company: int,
    comparison: JVComparison,
) -> FixResult:
    """Cancel the old Odoo entry and create a JV-driven replacement.

    Parameters
    ----------
    client:
        Odoo JSON-RPC client.
    odoo_company:
        ``res.company`` ID in Odoo.
    comparison:
        A :class:`JVComparison` from :mod:`jv_comparator` that has
        ``status == "mismatch"`` and a valid ``odoo_move_id``.

    Returns
    -------
    FixResult
        Describes what happened — check ``.success`` before assuming the fix
        landed.
    """
    jv_number = comparison.jv_number
    old_move_id = comparison.odoo_move_id

    if old_move_id is None:
        return FixResult(
            jv_number=jv_number,
            old_move_id=None,
            new_move_id=None,
            success=False,
            message="No Odoo move to fix (odoo_move_id is None)",
        )

    acc_lines = comparison.accurate_lines
    if not acc_lines:
        return FixResult(
            jv_number=jv_number,
            old_move_id=old_move_id,
            new_move_id=None,
            success=False,
            message="No Accurate lines on comparison — nothing to recreate",
        )

    # Bills and invoices must NOT be replaced — their invoice lines come
    # from detailItem/detailExpense and are correct.  Only payments and
    # standalone JV entries should be replaced with exact Accurate GL lines.
    move_data = client.search_read(
        "account.move",
        [["id", "=", old_move_id]],
        fields=["move_type"],
        limit=1,
    )
    if move_data and move_data[0].get("move_type") in (
        "in_invoice",
        "out_invoice",
        "in_refund",
        "out_refund",
    ):
        return FixResult(
            jv_number=jv_number,
            old_move_id=old_move_id,
            new_move_id=None,
            success=False,
            message=f"Skipped — move is {move_data[0]['move_type']} (bills/invoices are not replaced)",
        )

    try:
        # Step 1: discover reconciled bills/invoices before we cancel anything
        bill_ids, pr_account_ids = _find_reconciled_bills(client, old_move_id)

        # Step 2: cancel the old entry (or its payment)
        _cancel_move(client, old_move_id)

        # Step 3: create the replacement JV with exact Accurate GL lines
        # Read the raw Accurate detail dict from the comparison to get
        # vendor/customer and date information.
        detail = getattr(comparison, "accurate_detail", None) or {}
        new_move_id = _create_jv_entry(
            client,
            odoo_company,
            detail,
            acc_lines,
        )
        if new_move_id is None:
            return FixResult(
                jv_number=jv_number,
                old_move_id=old_move_id,
                new_move_id=None,
                success=False,
                message="Failed to create replacement JV — unresolved account(s)",
            )

        # Step 4: post the new entry
        client.execute_kw("account.move", "action_post", [[new_move_id]])

        # Step 5: reconcile AP/AR with the original bills
        reconciled: list[int] = []
        if bill_ids and pr_account_ids:
            reconciled = _reconcile_with_bills(client, new_move_id, bill_ids, pr_account_ids)

        logger.info(
            "Fixed %s: old_move=%d → new_move=%d, reconciled bills=%s",
            jv_number,
            old_move_id,
            new_move_id,
            reconciled,
        )

        return FixResult(
            jv_number=jv_number,
            old_move_id=old_move_id,
            new_move_id=new_move_id,
            success=True,
            message=f"Replaced move {old_move_id} with {new_move_id}",
            reconciled_bill_ids=reconciled,
        )

    except (RPCError, ConnectionError, KeyError, ValueError, TypeError) as exc:
        logger.exception("Error fixing %s (move_id=%s)", jv_number, old_move_id)
        return FixResult(
            jv_number=jv_number,
            old_move_id=old_move_id,
            new_move_id=None,
            success=False,
            message=f"Error: {exc}",
        )


# ---------------------------------------------------------------------------
# Step 1: find reconciled bills / invoices
# ---------------------------------------------------------------------------


def _find_reconciled_bills(
    client: OdooClient,
    move_id: int,
) -> tuple[list[int], list[int]]:
    """Find bills/invoices reconciled to the move via its payment.

    Checks if ``move_id`` is the backing move for an ``account.payment``.
    If so, reads ``reconciled_bill_ids`` and ``reconciled_invoice_ids``.
    Also collects the payable/receivable account IDs present on the move's
    lines so we know which accounts to reconcile later.

    Returns
    -------
    tuple[list[int], list[int]]
        ``(bill_or_invoice_ids, payable_receivable_account_ids)``
    """
    bill_ids: list[int] = []
    pr_account_ids: list[int] = []

    # Check if there is a payment linked to this move
    payments = client.search_read(
        "account.payment",
        [["move_id", "=", move_id]],
        fields=["id", "reconciled_bill_ids", "reconciled_invoice_ids"],
        limit=1,
    )

    if payments:
        pay = payments[0]
        raw_bills = pay.get("reconciled_bill_ids") or []
        raw_invoices = pay.get("reconciled_invoice_ids") or []
        # These fields return lists of IDs in Odoo's JSON-RPC
        bill_ids = list(raw_bills) + list(raw_invoices)

    # Collect payable/receivable account IDs from the move's lines
    move_lines = client.search_read(
        "account.move.line",
        [["move_id", "=", move_id]],
        fields=["account_id", "account_type"],
    )
    for ml in move_lines:
        acct_type = ml.get("account_type", "")
        if acct_type in ("liability_payable", "asset_receivable"):
            raw_acct = ml.get("account_id")
            acct_id: int | None = None
            if isinstance(raw_acct, (list, tuple)):
                acct_id = raw_acct[0]
            elif isinstance(raw_acct, int) and raw_acct:
                acct_id = raw_acct
            if acct_id and acct_id not in pr_account_ids:
                pr_account_ids.append(acct_id)

    return bill_ids, pr_account_ids


# ---------------------------------------------------------------------------
# Step 2: cancel the old move
# ---------------------------------------------------------------------------


def _cancel_move(client: OdooClient, move_id: int) -> None:
    """Cancel the Odoo move (or its payment if one exists).

    If the move has an ``account.payment`` (i.e. it is a payment's backing
    journal entry), we must cancel via the payment to avoid orphan records:
    ``action_draft`` → ``action_cancel`` on the payment.

    Otherwise we cancel the move directly: ``button_draft`` → ``action_cancel``.
    """
    # Check if the move is the backing move for a payment
    payment_ids = client.search(
        "account.payment",
        [["move_id", "=", move_id]],
        limit=1,
    )

    if payment_ids:
        # Cancel via payment — this also handles the move
        payment_id = payment_ids[0]

        # Read payment state to decide path
        pay_data = client.search_read(
            "account.payment",
            [["id", "=", payment_id]],
            fields=["state"],
            limit=1,
        )
        pay_state = pay_data[0]["state"] if pay_data else "posted"

        if pay_state == "posted":
            client.execute_kw("account.payment", "action_draft", [[payment_id]])
        if pay_state != "cancel":
            client.execute_kw("account.payment", "action_cancel", [[payment_id]])

        logger.info("Cancelled payment %d (move %d)", payment_id, move_id)
    else:
        # Cancel the move directly
        move_data = client.search_read(
            "account.move",
            [["id", "=", move_id]],
            fields=["state"],
            limit=1,
        )
        move_state = move_data[0]["state"] if move_data else "posted"

        if move_state == "cancel":
            logger.info("Move %d already cancelled — skipping", move_id)
            return
        if move_state == "posted":
            client.execute_kw("account.move", "button_draft", [[move_id]])
        client.execute_kw("account.move", "button_cancel", [[move_id]])

        logger.info("Cancelled move %d", move_id)


# ---------------------------------------------------------------------------
# Step 3: create the replacement JV entry
# ---------------------------------------------------------------------------


def _resolve_journal_from_lines(
    client: OdooClient,
    odoo_company: int,
    lines: list[NormalizedLine],
) -> int | None:
    """Find the journal whose ``default_account_id`` matches a bank/cash account in the lines.

    Scans the normalized lines for any account with ``account_type == 'asset_cash'``
    (bank or cash accounts), then looks for an ``account.journal`` whose
    ``default_account_id`` matches.  Returns the first match or ``None``.
    """
    # Collect account IDs from lines that we can check
    account_ids = [ln.account_id for ln in lines if ln.account_id]
    if not account_ids:
        return None

    # Find which of these accounts are bank/cash type
    cash_accounts = client.search_read(
        "account.account",
        [["id", "in", account_ids], ["account_type", "=", "asset_cash"]],
        fields=["id"],
    )
    if not cash_accounts:
        return None

    cash_account_ids = [a["id"] for a in cash_accounts]

    # Find a journal whose default_account_id is one of these
    for cash_id in cash_account_ids:
        journal_ids = client.search(
            "account.journal",
            [
                ["company_id", "=", odoo_company],
                ["default_account_id", "=", cash_id],
            ],
            limit=1,
        )
        if journal_ids:
            return journal_ids[0]

    return None


def _create_jv_entry(
    client: OdooClient,
    odoo_company: int,
    detail: dict[str, Any],
    acc_lines: list[NormalizedLine],
) -> int | None:
    """Create an ``account.move`` (type=entry) with exact Accurate GL lines.

    Parameters
    ----------
    client:
        Odoo JSON-RPC client.
    odoo_company:
        ``res.company`` ID.
    detail:
        The raw Accurate detail dict — used for date, ref, vendor/customer.
    acc_lines:
        Normalized lines from :mod:`jv_comparator`.

    Returns
    -------
    int | None
        The new ``account.move`` ID, or ``None`` if any account could not be
        resolved (we refuse to create a partial entry).
    """
    # --- Resolve partner from Accurate vendor / customer ---
    partner_id: int | None = None
    vendor_data = detail.get("vendor") or {}
    customer_data = detail.get("customer") or {}

    vendor_ref: str = str(vendor_data.get("vendorNo", "") or "").strip()
    customer_ref: str = str(customer_data.get("customerNo", "") or "").strip()

    if vendor_ref:
        partner_id = resolve_partner_by_ref(client, odoo_company, vendor_ref)
    elif customer_ref:
        partner_id = resolve_partner_by_ref(client, odoo_company, customer_ref)

    # --- Date ---
    date_raw: str = str(detail.get("transDate", "") or detail.get("date", "") or "").strip()
    date_odoo: str = accurate_date_to_odoo(date_raw) if date_raw else ""

    # --- Ref ---
    jv_number: str = str(detail.get("number", "") or "").strip()
    trans_number: str = str(detail.get("transNumber", "") or "").strip()
    ref = jv_number or trans_number

    # --- Journal: prefer bank/cash journal from lines, fall back to MISC ---
    journal_id = _resolve_journal_from_lines(client, odoo_company, acc_lines)
    if journal_id is None:
        misc_ids = client.search(
            "account.journal",
            [["company_id", "=", odoo_company], ["type", "=", "general"]],
            limit=1,
        )
        journal_id = misc_ids[0] if misc_ids else None

    if journal_id is None:
        logger.error("No journal found for company %d — cannot create JV", odoo_company)
        return None

    # --- Identify payable/receivable accounts to assign partner ---
    pr_account_ids: set[int] = set()
    for ln in acc_lines:
        if ln.account_id:
            pr_account_ids.add(ln.account_id)

    # Read account types to know which lines are payable/receivable
    pr_type_map: dict[int, str] = {}
    if pr_account_ids:
        acct_records = client.search_read(
            "account.account",
            [["id", "in", list(pr_account_ids)]],
            fields=["id", "account_type"],
        )
        for rec in acct_records:
            pr_type_map[rec["id"]] = rec.get("account_type", "")

    # --- Build move lines ---
    line_vals: list[Any] = []
    for ln in acc_lines:
        if ln.account_id is None:
            # Try resolving by code or name as a last resort
            resolved = None
            if ln.account_code:
                resolved = resolve_account_by_code(client, odoo_company, ln.account_code)
            if resolved is None and ln.account_name:
                resolved = resolve_account_by_name(client, odoo_company, ln.account_name)
            if resolved is None:
                logger.error(
                    "Cannot resolve account %s (%s) — aborting JV creation",
                    ln.account_code,
                    ln.account_name,
                )
                return None
            account_id = resolved
        else:
            account_id = ln.account_id

        line_dict: dict[str, Any] = {
            "account_id": account_id,
            "debit": ln.debit,
            "credit": ln.credit,
            "name": ln.label or ln.account_name or "Line",
        }

        # Partner only on payable/receivable lines
        acct_type = pr_type_map.get(account_id, "")
        if partner_id and acct_type in ("liability_payable", "asset_receivable"):
            line_dict["partner_id"] = partner_id

        # Multi-currency: use the NormalizedLine's currency info
        if ln.currency_id and ln.amount_currency:
            line_dict["currency_id"] = ln.currency_id
            line_dict["amount_currency"] = ln.amount_currency

        line_vals.append((0, 0, line_dict))

    if not line_vals:
        logger.error("No lines to create for JV %s", ref)
        return None

    # --- Create the move ---
    move_vals: dict[str, Any] = {
        "move_type": "entry",
        "journal_id": journal_id,
        "company_id": odoo_company,
        "line_ids": line_vals,
    }
    if ref:
        move_vals["ref"] = ref
    if date_odoo:
        move_vals["date"] = date_odoo

    new_move_id: int = client.create("account.move", move_vals)
    logger.info("Created replacement JV move_id=%d ref=%s", new_move_id, ref)
    return new_move_id


# ---------------------------------------------------------------------------
# Step 5: reconcile AP/AR with original bills
# ---------------------------------------------------------------------------


def _reconcile_with_bills(
    client: OdooClient,
    new_move_id: int,
    bill_ids: list[int],
    pr_account_ids: list[int],
) -> list[int]:
    """Reconcile payable/receivable lines on the new entry with the bills.

    Finds unreconciled payable/receivable lines on the new entry and matches
    them to unreconciled lines on the bills by ``account_id``.  Uses
    ``account.move.line.reconcile()`` for each matching pair.

    Parameters
    ----------
    client:
        Odoo JSON-RPC client.
    new_move_id:
        The newly created replacement ``account.move`` ID.
    bill_ids:
        List of ``account.move`` IDs (bills/invoices) that were reconciled
        to the old move.
    pr_account_ids:
        Payable/receivable account IDs to filter lines for reconciliation.

    Returns
    -------
    list[int]
        Bill IDs that were successfully reconciled.
    """
    if not bill_ids or not pr_account_ids:
        return []

    # Read unreconciled payable/receivable lines on the new entry
    new_pr_lines = client.search_read(
        "account.move.line",
        [
            ["move_id", "=", new_move_id],
            ["account_id", "in", pr_account_ids],
            ["reconciled", "=", False],
        ],
        fields=["id", "account_id"],
    )
    if not new_pr_lines:
        logger.info("No unreconciled PR lines on new move %d", new_move_id)
        return []

    # Build a map: account_id → list of new line IDs
    new_lines_by_account: dict[int, list[int]] = {}
    for nl in new_pr_lines:
        raw_acct = nl.get("account_id")
        acct_id: int
        if isinstance(raw_acct, (list, tuple)):
            acct_id = raw_acct[0]
        else:
            acct_id = raw_acct
        new_lines_by_account.setdefault(acct_id, []).append(nl["id"])

    reconciled_bills: list[int] = []

    for bill_id in bill_ids:
        # Read unreconciled payable/receivable lines on the bill
        bill_pr_lines = client.search_read(
            "account.move.line",
            [
                ["move_id", "=", bill_id],
                ["account_id", "in", pr_account_ids],
                ["reconciled", "=", False],
            ],
            fields=["id", "account_id"],
        )
        if not bill_pr_lines:
            continue

        for bl in bill_pr_lines:
            raw_acct = bl.get("account_id")
            bill_acct_id: int
            if isinstance(raw_acct, (list, tuple)):
                bill_acct_id = raw_acct[0]
            else:
                bill_acct_id = raw_acct

            new_line_ids = new_lines_by_account.get(bill_acct_id, [])
            if not new_line_ids:
                continue

            # Pick the first available new line for this account
            new_line_id = new_line_ids[0]
            try:
                client.execute_kw(
                    "account.move.line",
                    "reconcile",
                    [[new_line_id, bl["id"]]],
                )
                # Remove used line so we don't double-reconcile
                new_line_ids.pop(0)
                if bill_id not in reconciled_bills:
                    reconciled_bills.append(bill_id)
                logger.info(
                    "Reconciled new line %d with bill line %d (account %d)",
                    new_line_id,
                    bl["id"],
                    bill_acct_id,
                )
            except (RPCError, ConnectionError, KeyError, ValueError, TypeError) as exc:
                logger.warning(
                    "Failed to reconcile lines %d + %d: %s",
                    new_line_id,
                    bl["id"],
                    exc,
                )

    return reconciled_bills
