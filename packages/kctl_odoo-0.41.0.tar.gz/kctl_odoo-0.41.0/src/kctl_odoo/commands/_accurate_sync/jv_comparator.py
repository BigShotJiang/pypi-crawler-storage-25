"""Normalize + diff engine for Accurate JV ↔ Odoo journal entry validation.

Converts Accurate ``detailJournalVoucher`` lines and Odoo ``account.move.line``
records into a common :class:`NormalizedLine` format, then diffs them to produce
a :class:`JVComparison` report per journal entry.

Usage (orchestrator)::

    comparisons = run_validation(client, acc_client, odoo_company, jv_filter, type_filter)
    for comp in comparisons:
        if comp.discrepancies:
            print(comp.jv_number, comp.discrepancies)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any

from ._helpers import (
    resolve_account_by_code,
    resolve_account_by_name,
    resolve_currency_by_code,
)

if TYPE_CHECKING:
    from kctl_odoo.core.client import OdooClient

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

AMOUNT_TOLERANCE: float = 1.0  # Rp 1 rounding tolerance for IDR
FX_TOLERANCE: float = 0.01  # foreign-amount tolerance

# Accurate transactionType codes keyed by user-friendly filter name.
TYPE_FILTER_MAP: dict[str, str] = {
    "bill": "PI",
    "payment": "PP",
    "sales": "SI",
    "receipt": "SR",
    "jv": "JV",
    "transfer": "BT",
}


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------


class Severity(Enum):
    """Severity level for a validation discrepancy."""

    INFO = "info"
    WARNING = "warning"
    ERROR = "error"


@dataclass
class NormalizedLine:
    """Common representation of a single GL line (Accurate or Odoo).

    ``account_id`` is the Odoo account.account ID (``None`` when unresolvable).
    ``account_code`` and ``account_name`` are kept for human-readable output.
    ``currency_id`` and ``amount_currency`` are non-``None`` for multi-currency
    lines.
    """

    account_id: int | None
    account_code: str
    account_name: str
    debit: float
    credit: float
    currency_id: int | None = None
    amount_currency: float = 0.0
    label: str = ""


@dataclass
class Discrepancy:
    """A single diff item between the Accurate and Odoo sides of a JV."""

    kind: str  # MISSING_LINE, EXTRA_LINE, WRONG_AMOUNT, WRONG_ACCOUNT, AMOUNT_ROUNDING
    severity: Severity
    message: str
    accurate_line: NormalizedLine | None = None
    odoo_line: NormalizedLine | None = None


@dataclass
class JVComparison:
    """Full comparison result for one Accurate JV ↔ Odoo account.move pair."""

    jv_number: str
    trans_number: str
    odoo_move_id: int | None
    accurate_lines: list[NormalizedLine] = field(default_factory=list)
    odoo_lines: list[NormalizedLine] = field(default_factory=list)
    discrepancies: list[Discrepancy] = field(default_factory=list)
    status: str = "ok"  # ok | mismatch | missing

    @property
    def is_ok(self) -> bool:
        return not self.discrepancies


# ---------------------------------------------------------------------------
# Normalization: Accurate → NormalizedLine
# ---------------------------------------------------------------------------


def normalize_accurate_lines(
    jv_detail: list[dict[str, Any]],
    client: OdooClient,
    odoo_company: int,
) -> list[NormalizedLine]:
    """Convert Accurate ``detailJournalVoucher`` entries to :class:`NormalizedLine`.

    Each Accurate line carries ``accountNoRef`` (GL code) and ``accountNameRef``
    (GL name).  We resolve them to an Odoo ``account.account`` ID using helpers
    from ``_helpers.py``.

    Multi-currency is detected via ``glAccount.currencyCode`` and
    ``foreignAmount`` fields on individual lines.
    """
    result: list[NormalizedLine] = []
    for line in jv_detail:
        acct_code: str = str(line.get("accountNoRef", "") or "").strip()
        acct_name: str = str(line.get("accountNameRef", "") or "").strip()

        # Resolve account in Odoo — prefer code, fall back to name
        account_id: int | None = None
        if acct_code:
            account_id = resolve_account_by_code(client, odoo_company, acct_code)
        if account_id is None and acct_name:
            account_id = resolve_account_by_name(client, odoo_company, acct_name)

        # Debit / Credit
        debit: float = float(line.get("debitAmount", 0.0) or 0.0)
        credit: float = float(line.get("creditAmount", 0.0) or 0.0)
        if debit == 0.0 and credit == 0.0:
            amount = float(line.get("amount", 0.0) or 0.0)
            side: str = str(line.get("amountType", "DEBIT")).upper()
            if side == "DEBIT":
                debit = amount
            else:
                credit = amount

        # Multi-currency
        currency_id: int | None = None
        amount_currency: float = 0.0
        gl_account = line.get("glAccount") or {}
        currency_code: str = str(gl_account.get("currencyCode", "") or "").strip()
        if currency_code and currency_code.upper() != "IDR":
            currency_id = resolve_currency_by_code(client, currency_code)
            amount_currency = float(line.get("foreignAmount", 0.0) or 0.0)

        label: str = str(line.get("memo", "") or "").strip() or acct_name

        result.append(
            NormalizedLine(
                account_id=account_id,
                account_code=acct_code,
                account_name=acct_name,
                debit=debit,
                credit=credit,
                currency_id=currency_id,
                amount_currency=amount_currency,
                label=label,
            )
        )
    return result


# ---------------------------------------------------------------------------
# Normalization: Odoo → NormalizedLine
# ---------------------------------------------------------------------------


def normalize_odoo_lines(
    client: OdooClient,
    move_id: int,
) -> list[NormalizedLine]:
    """Read ``account.move.line`` records for *move_id* and normalize them.

    We first try to read only ``display_type='product'`` lines (the explicit
    GL lines).  If none exist (e.g. pure journal entries), we fall back to all
    lines excluding section/note display types.
    """
    fields = [
        "account_id",
        "debit",
        "credit",
        "name",
        "currency_id",
        "amount_currency",
    ]

    lines = client.search_read(
        "account.move.line",
        [["move_id", "=", move_id], ["display_type", "=", "product"]],
        fields=fields,
    )

    if not lines:
        lines = client.search_read(
            "account.move.line",
            [
                ["move_id", "=", move_id],
                ["display_type", "not in", ["line_section", "line_note"]],
            ],
            fields=fields,
        )

    result: list[NormalizedLine] = []
    for ln in lines:
        # account_id can be [id, "name"] or just int
        raw_acct = ln.get("account_id")
        if isinstance(raw_acct, (list, tuple)):
            acct_id = raw_acct[0]
            acct_display = str(raw_acct[1]) if len(raw_acct) > 1 else ""
        else:
            acct_id = raw_acct
            acct_display = ""

        # Extract code from the display name "1234 Account Name" if present
        acct_code = ""
        acct_name = acct_display
        if acct_display and " " in acct_display:
            parts = acct_display.split(" ", 1)
            if parts[0].isdigit():
                acct_code = parts[0]
                acct_name = parts[1]

        # Currency
        raw_curr = ln.get("currency_id")
        currency_id: int | None = None
        if isinstance(raw_curr, (list, tuple)):
            currency_id = raw_curr[0]
        elif isinstance(raw_curr, int) and raw_curr:
            currency_id = raw_curr

        result.append(
            NormalizedLine(
                account_id=acct_id,
                account_code=acct_code,
                account_name=acct_name,
                debit=float(ln.get("debit", 0.0) or 0.0),
                credit=float(ln.get("credit", 0.0) or 0.0),
                currency_id=currency_id,
                amount_currency=float(ln.get("amount_currency", 0.0) or 0.0),
                label=str(ln.get("name", "") or ""),
            )
        )
    return result


# ---------------------------------------------------------------------------
# Comparison engine
# ---------------------------------------------------------------------------


def _match_score(acc_line: NormalizedLine, odoo_line: NormalizedLine) -> int:
    """Score how well two normalized lines match.  Higher is better."""
    score = 0
    if acc_line.account_id and odoo_line.account_id and acc_line.account_id == odoo_line.account_id:
        score += 10
    if (
        abs(acc_line.debit - odoo_line.debit) <= AMOUNT_TOLERANCE
        and abs(acc_line.credit - odoo_line.credit) <= AMOUNT_TOLERANCE
    ):
        score += 5
    return score


def compare_lines(
    accurate: list[NormalizedLine],
    odoo: list[NormalizedLine],
) -> list[Discrepancy]:
    """Diff two sets of normalized lines.

    Matching strategy: greedy best-score match.  For each Accurate line pick the
    best-scoring unmatched Odoo line (account_id match = +10, amount match = +5).

    Reports:
    - ``MISSING_LINE`` — Accurate line has no Odoo counterpart.
    - ``EXTRA_LINE``   — Odoo line not matched to any Accurate line.
    - ``WRONG_ACCOUNT``— Matched by amount but account differs.
    - ``WRONG_AMOUNT`` — Matched by account but amount differs beyond tolerance.
    - ``AMOUNT_ROUNDING`` — Amount differs within ``AMOUNT_TOLERANCE`` (info only).
    """
    discrepancies: list[Discrepancy] = []
    odoo_used: list[bool] = [False] * len(odoo)

    for acc_line in accurate:
        best_idx: int | None = None
        best_score: int = 0

        for j, odoo_line in enumerate(odoo):
            if odoo_used[j]:
                continue
            score = _match_score(acc_line, odoo_line)
            if score > best_score:
                best_score = score
                best_idx = j

        if best_idx is None:
            # No match at all
            discrepancies.append(
                Discrepancy(
                    kind="MISSING_LINE",
                    severity=Severity.ERROR,
                    message=(
                        f"Accurate line {acc_line.account_code} "
                        f"({acc_line.account_name}) "
                        f"D={acc_line.debit:.2f}/C={acc_line.credit:.2f} "
                        f"has no matching Odoo line"
                    ),
                    accurate_line=acc_line,
                )
            )
            continue

        odoo_used[best_idx] = True
        matched_odoo = odoo[best_idx]

        # Check account
        if acc_line.account_id and matched_odoo.account_id and acc_line.account_id != matched_odoo.account_id:
            discrepancies.append(
                Discrepancy(
                    kind="WRONG_ACCOUNT",
                    severity=Severity.ERROR,
                    message=(
                        f"Account mismatch: Accurate {acc_line.account_code} "
                        f"({acc_line.account_name}) vs Odoo {matched_odoo.account_code} "
                        f"({matched_odoo.account_name})"
                    ),
                    accurate_line=acc_line,
                    odoo_line=matched_odoo,
                )
            )

        # Check amounts
        d_diff = abs(acc_line.debit - matched_odoo.debit)
        c_diff = abs(acc_line.credit - matched_odoo.credit)

        if d_diff > AMOUNT_TOLERANCE or c_diff > AMOUNT_TOLERANCE:
            discrepancies.append(
                Discrepancy(
                    kind="WRONG_AMOUNT",
                    severity=Severity.ERROR,
                    message=(
                        f"Amount mismatch on {acc_line.account_code}: "
                        f"Accurate D={acc_line.debit:.2f}/C={acc_line.credit:.2f} vs "
                        f"Odoo D={matched_odoo.debit:.2f}/C={matched_odoo.credit:.2f}"
                    ),
                    accurate_line=acc_line,
                    odoo_line=matched_odoo,
                )
            )
        elif d_diff > 0 or c_diff > 0:
            # Within tolerance but not exact — informational rounding note
            discrepancies.append(
                Discrepancy(
                    kind="AMOUNT_ROUNDING",
                    severity=Severity.INFO,
                    message=(
                        f"Rounding diff on {acc_line.account_code}: debit delta={d_diff:.2f}, credit delta={c_diff:.2f}"
                    ),
                    accurate_line=acc_line,
                    odoo_line=matched_odoo,
                )
            )

        # Check foreign amount for multi-currency lines
        if acc_line.currency_id and matched_odoo.currency_id:
            fx_diff = abs(acc_line.amount_currency - matched_odoo.amount_currency)
            if fx_diff > FX_TOLERANCE:
                discrepancies.append(
                    Discrepancy(
                        kind="WRONG_AMOUNT",
                        severity=Severity.WARNING,
                        message=(
                            f"Foreign amount mismatch on {acc_line.account_code}: "
                            f"Accurate={acc_line.amount_currency:.2f} vs "
                            f"Odoo={matched_odoo.amount_currency:.2f}"
                        ),
                        accurate_line=acc_line,
                        odoo_line=matched_odoo,
                    )
                )

    # Any unmatched Odoo lines are extra
    for j, used in enumerate(odoo_used):
        if not used:
            extra = odoo[j]
            discrepancies.append(
                Discrepancy(
                    kind="EXTRA_LINE",
                    severity=Severity.WARNING,
                    message=(
                        f"Odoo line {extra.account_code} ({extra.account_name}) "
                        f"D={extra.debit:.2f}/C={extra.credit:.2f} "
                        f"has no matching Accurate line"
                    ),
                    odoo_line=extra,
                )
            )

    return discrepancies


# ---------------------------------------------------------------------------
# Odoo move lookup
# ---------------------------------------------------------------------------


def _find_odoo_move(
    client: OdooClient,
    odoo_company: int,
    jv_number: str,
    trans_number: str,
) -> int | None:
    """Find the Odoo ``account.move`` that corresponds to an Accurate JV.

    Search strategy:
    1. ``ref`` exact match on ``jv_number`` (the JV document number).
    2. ``ref`` ilike on ``trans_number`` (the linked business document number).
    3. ``name`` ilike on ``trans_number``.
    """
    # Primary: ref = jv_number
    move_ids = client.search(
        "account.move",
        [["ref", "=", jv_number], ["company_id", "=", odoo_company]],
        limit=1,
    )
    if move_ids:
        return move_ids[0]

    if not trans_number:
        return None

    # Fallback: ref/name contains transNumber
    for search_field in ("ref", "name"):
        move_ids = client.search(
            "account.move",
            [
                [search_field, "ilike", trans_number],
                ["company_id", "=", odoo_company],
                [
                    "move_type",
                    "in",
                    ["entry", "in_invoice", "out_invoice", "in_refund", "out_refund"],
                ],
            ],
            limit=1,
        )
        if move_ids:
            return move_ids[0]

    return None


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------


def run_validation(
    client: OdooClient,
    acc_client: Any,
    odoo_company: int,
    jv_filter: str | None = None,
    type_filter: str | None = None,
) -> list[JVComparison]:
    """Fetch Accurate JVs, match to Odoo moves, compare, return results.

    Parameters
    ----------
    client:
        Odoo JSON-RPC client.
    acc_client:
        ``AccurateClient`` instance (from ``accurate_sdk``).
    odoo_company:
        ``res.company`` ID in Odoo.
    jv_filter:
        Optional JV number prefix/substring filter (applied client-side after
        fetching the full list).
    type_filter:
        Comma-separated user-friendly type names (``bill,payment,jv,...``).
        Mapped to Accurate ``transactionType`` codes via :data:`TYPE_FILTER_MAP`.
    """
    # Resolve type filter → set of Accurate codes
    allowed_types: set[str] | None = None
    if type_filter:
        allowed_types = set()
        for t in type_filter.split(","):
            t = t.strip().lower()
            code = TYPE_FILTER_MAP.get(t)
            if code:
                allowed_types.add(code)
            else:
                # Allow passing raw codes as well (e.g. "PI,PP")
                allowed_types.add(t.upper())

    # Fetch all JVs from Accurate
    logger.info("Fetching journal voucher list from Accurate...")
    raw_list: list[dict[str, Any]] = acc_client.list_all(
        "/accurate/api/journal-voucher/list.do",
        params={"fields": "id,number,transactionType,transNumber"},
    )
    if not raw_list:
        logger.info("No journal vouchers found in Accurate.")
        return []

    # Client-side filters
    candidates: list[dict[str, Any]] = []
    for r in raw_list:
        if not isinstance(r.get("id"), int):
            continue
        jv_num = str(r.get("number", "") or "").strip()
        txn_type = str(r.get("transactionType", "") or "").strip().upper()

        if jv_filter and jv_filter.upper() not in jv_num.upper():
            continue
        if allowed_types and txn_type not in allowed_types:
            continue
        candidates.append(r)

    if not candidates:
        logger.info("No journal vouchers match the applied filters.")
        return []

    # Fetch full details
    logger.info("Fetching details for %d journal vouchers...", len(candidates))
    acc_ids = [r["id"] for r in candidates]
    details: list[dict[str, Any]] = acc_client.detail_many(
        "/accurate/api/journal-voucher/detail.do",
        acc_ids,
    )

    # Build comparison for each JV
    comparisons: list[JVComparison] = []
    for detail in details:
        if detail.get("__error__"):
            logger.warning("Error fetching JV id=%s: %s", detail.get("id"), detail["__error__"])
            continue

        jv_number: str = str(detail.get("number", "")).strip()
        trans_number: str = str(detail.get("transNumber", "") or "").strip()

        if not jv_number:
            continue

        jv_lines = detail.get("detailJournalVoucher") or []
        if not jv_lines:
            comparisons.append(
                JVComparison(
                    jv_number=jv_number,
                    trans_number=trans_number,
                    odoo_move_id=None,
                    status="missing",
                    discrepancies=[
                        Discrepancy(
                            kind="MISSING_LINE",
                            severity=Severity.INFO,
                            message="No detailJournalVoucher lines on Accurate side",
                        )
                    ],
                )
            )
            continue

        # Normalize Accurate side
        acc_normalized = normalize_accurate_lines(jv_lines, client, odoo_company)

        # Find corresponding Odoo move
        move_id = _find_odoo_move(client, odoo_company, jv_number, trans_number)

        if move_id is None:
            comparisons.append(
                JVComparison(
                    jv_number=jv_number,
                    trans_number=trans_number,
                    odoo_move_id=None,
                    accurate_lines=acc_normalized,
                    status="missing",
                    discrepancies=[
                        Discrepancy(
                            kind="MISSING_LINE",
                            severity=Severity.ERROR,
                            message=f"No matching account.move found in Odoo for JV {jv_number!r} / trans {trans_number!r}",
                        )
                    ],
                )
            )
            continue

        # Normalize Odoo side
        odoo_normalized = normalize_odoo_lines(client, move_id)

        # Compare
        discs = compare_lines(acc_normalized, odoo_normalized)
        status = "ok" if not discs else "mismatch"

        comparisons.append(
            JVComparison(
                jv_number=jv_number,
                trans_number=trans_number,
                odoo_move_id=move_id,
                accurate_lines=acc_normalized,
                odoo_lines=odoo_normalized,
                discrepancies=discs,
                status=status,
            )
        )

    return comparisons
