"""sync-status: comparison report between Accurate and Odoo record counts.

For each entity type, fetches the count from Accurate Online and the count
from the Odoo instance, then displays a table with Missing and Match%.
"""

from __future__ import annotations

from typing import Annotated, Any

import httpx
import typer

from kctl_odoo.core.callbacks import AppContext
from kctl_odoo.core.exceptions import ConnectionError, RPCError

from ._helpers import create_accurate_client

# ---------------------------------------------------------------------------
# Command
# ---------------------------------------------------------------------------


def sync_status(
    ctx: typer.Context,
    profile: Annotated[str, typer.Argument(help="kctl-accurate profile name (e.g. terra-buah-internusa)")],
    odoo_company: Annotated[int, typer.Option("--odoo-company", "-c", help="Odoo res.company ID")],
) -> None:
    """Show a comparison report of Accurate vs Odoo record counts.

    Fetches counts for each entity type from both systems and displays:
      Entity, Accurate count, Odoo count, Missing, Match%.

    Master data:
      - GL Accounts vs account.account
      - Item Categories vs product.category
      - Items vs product.template
      - Vendors vs res.partner (supplier)
      - Customers vs res.partner (customer)
      - Payment Terms vs account.payment.term
      - Warehouses vs stock.warehouse
      - Taxes vs account.tax
      - Currencies vs res.currency (active)

    Transactions:
      - Purchase Requests vs purchase.request
      - Purchase Orders vs purchase.order
      - Purchase Invoices vs account.move (in_invoice)
      - Purchase Payments vs account.payment (outbound)
      - Receive Items (Accurate count only)
      - Sales Invoices vs account.move (out_invoice)
      - Sales Receipts vs account.payment (inbound)
      - Journal Vouchers vs account.move (entry)
      - Bank Transfers vs account.move (entry)
      - Other Payments vs account.move (entry)
      - Other Deposits vs account.move (entry)
      - Expenses vs account.move (entry)
      - Sales Orders vs sale.order
      - Sales Returns vs account.move (out_refund)
      - Purchase Returns vs account.move (in_refund)
      - Item Adjustments (Accurate count only)
      - Item Transfers (Accurate count only)
    """
    actx: AppContext = ctx.obj
    out = actx.output
    c = actx.client

    # Extend timeout for large Accurate list calls
    try:
        c._client.timeout = httpx.Timeout(1800.0)
    except (AttributeError, TypeError):
        pass

    out.header(f"sync-status: profile={profile!r}  odoo_company={odoo_company}")

    acc_client = create_accurate_client(profile)

    rows: list[list[str]] = []

    # -------------------------------------------------------------------
    # Helper: count Accurate list endpoint
    # -------------------------------------------------------------------
    def acc_count(endpoint: str, params: dict[str, Any] | None = None) -> int:
        try:
            records = acc_client.list_all(endpoint, params={"fields": "id", **(params or {})})
            return len(records) if records else 0
        except (httpx.HTTPError, OSError, KeyError, ValueError) as exc:
            out.error(f"  Error counting {endpoint}: {exc}")
            return -1

    # -------------------------------------------------------------------
    # Helper: count Odoo model
    # -------------------------------------------------------------------
    def odoo_count(model: str, domain: list[Any]) -> int:
        try:
            return c.search_count(model, domain)
        except (RPCError, ConnectionError, KeyError, ValueError) as exc:
            out.error(f"  Error counting {model}: {exc}")
            return -1

    # -------------------------------------------------------------------
    # Helper: build a table row
    # -------------------------------------------------------------------
    def make_row(entity: str, acc: int, odoo: int) -> list[str]:
        if acc < 0 or odoo < 0:
            return [entity, str(acc), str(odoo), "?", "?"]
        missing = max(0, acc - odoo)
        if acc == 0:
            match_pct = "100%" if odoo == 0 else "N/A"
        else:
            match_pct = f"{min(100.0, odoo / acc * 100):.1f}%"
        return [entity, str(acc), str(odoo), str(missing), match_pct]

    # ===================================================================
    # MASTER DATA
    # ===================================================================

    # -------------------------------------------------------------------
    # 1. GL Accounts vs account.account
    # -------------------------------------------------------------------
    out.info("Counting: GL Accounts...")
    acc_accounts = acc_count("/accurate/api/gl-account/list.do")
    odoo_accounts = odoo_count(
        "account.account",
        [("company_id", "=", odoo_company)],
    )
    rows.append(make_row("GL Accounts → account.account", acc_accounts, odoo_accounts))

    # -------------------------------------------------------------------
    # 2. Item Categories vs product.category
    # -------------------------------------------------------------------
    out.info("Counting: Item Categories...")
    acc_cats = acc_count("/accurate/api/item-category/list.do")
    odoo_cats = odoo_count("product.category", [])
    rows.append(make_row("Item Categories → product.category", acc_cats, odoo_cats))

    # -------------------------------------------------------------------
    # 3. Items vs product.template
    # -------------------------------------------------------------------
    out.info("Counting: Items...")
    acc_items = acc_count("/accurate/api/item/list.do")
    odoo_items = odoo_count(
        "product.template",
        ["|", ("company_id", "=", odoo_company), ("company_id", "=", False)],
    )
    rows.append(make_row("Items → product.template", acc_items, odoo_items))

    # -------------------------------------------------------------------
    # 4. Vendors vs res.partner (supplier)
    # -------------------------------------------------------------------
    out.info("Counting: Vendors...")
    acc_vendors = acc_count("/accurate/api/vendor/list.do")
    odoo_vendors = odoo_count(
        "res.partner",
        [
            "|",
            ("company_id", "=", odoo_company),
            ("company_id", "=", False),
            ("supplier_rank", ">", 0),
        ],
    )
    rows.append(make_row("Vendors → res.partner (supplier)", acc_vendors, odoo_vendors))

    # -------------------------------------------------------------------
    # 5. Customers vs res.partner (customer)
    # -------------------------------------------------------------------
    out.info("Counting: Customers...")
    acc_customers = acc_count("/accurate/api/customer/list.do")
    odoo_customers = odoo_count(
        "res.partner",
        [
            "|",
            ("company_id", "=", odoo_company),
            ("company_id", "=", False),
            ("customer_rank", ">", 0),
        ],
    )
    rows.append(make_row("Customers → res.partner (customer)", acc_customers, odoo_customers))

    # -------------------------------------------------------------------
    # 6. Payment Terms vs account.payment.term
    # -------------------------------------------------------------------
    out.info("Counting: Payment Terms...")
    acc_terms = acc_count("/accurate/api/term/list.do")
    odoo_terms = odoo_count(
        "account.payment.term",
        ["|", ("company_id", "=", odoo_company), ("company_id", "=", False)],
    )
    rows.append(make_row("Payment Terms → account.payment.term", acc_terms, odoo_terms))

    # -------------------------------------------------------------------
    # 7. Warehouses vs stock.warehouse
    # -------------------------------------------------------------------
    out.info("Counting: Warehouses...")
    acc_warehouses = acc_count("/accurate/api/warehouse/list.do")
    odoo_warehouses = odoo_count("stock.warehouse", [("company_id", "=", odoo_company)])
    rows.append(make_row("Warehouses → stock.warehouse", acc_warehouses, odoo_warehouses))

    # -------------------------------------------------------------------
    # 8. Taxes vs account.tax
    # -------------------------------------------------------------------
    out.info("Counting: Taxes...")
    acc_taxes = acc_count("/accurate/api/tax/list.do")
    odoo_taxes = odoo_count("account.tax", [("company_id", "=", odoo_company)])
    rows.append(make_row("Taxes → account.tax", acc_taxes, odoo_taxes))

    # -------------------------------------------------------------------
    # 9. Currencies vs res.currency (active)
    # -------------------------------------------------------------------
    out.info("Counting: Currencies...")
    acc_currencies = acc_count("/accurate/api/currency/list.do")
    odoo_currencies = odoo_count("res.currency", [("active", "=", True)])
    rows.append(make_row("Currencies → res.currency (active)", acc_currencies, odoo_currencies))

    # ===================================================================
    # TRANSACTIONS
    # ===================================================================

    # -------------------------------------------------------------------
    # 10. Purchase Requests vs purchase.request
    # -------------------------------------------------------------------
    out.info("Counting: Purchase Requests...")
    acc_prs = acc_count("/accurate/api/purchase-requisition/list.do")
    odoo_prs = odoo_count("purchase.request", [("company_id", "=", odoo_company)])
    rows.append(make_row("Purchase Requests → purchase.request", acc_prs, odoo_prs))

    # -------------------------------------------------------------------
    # 11. Purchase Orders vs purchase.order
    # -------------------------------------------------------------------
    out.info("Counting: Purchase Orders...")
    acc_pos = acc_count("/accurate/api/purchase-order/list.do")
    odoo_pos = odoo_count(
        "purchase.order",
        [("company_id", "=", odoo_company)],
    )
    rows.append(make_row("POs → purchase.order", acc_pos, odoo_pos))

    # -------------------------------------------------------------------
    # 12. Purchase Invoices vs account.move (in_invoice)
    # -------------------------------------------------------------------
    out.info("Counting: Purchase Invoices...")
    acc_bills = acc_count("/accurate/api/purchase-invoice/list.do")
    odoo_bills = odoo_count(
        "account.move",
        [("company_id", "=", odoo_company), ("move_type", "=", "in_invoice")],
    )
    rows.append(make_row("Bills → account.move (in_invoice)", acc_bills, odoo_bills))

    # -------------------------------------------------------------------
    # 13. Purchase Payments vs account.payment (outbound)
    # -------------------------------------------------------------------
    out.info("Counting: Purchase Payments...")
    acc_ppays = acc_count("/accurate/api/purchase-payment/list.do")
    odoo_ppays = odoo_count(
        "account.payment",
        [("company_id", "=", odoo_company), ("payment_type", "=", "outbound")],
    )
    rows.append(make_row("Purchase Payments → account.payment", acc_ppays, odoo_ppays))

    # -------------------------------------------------------------------
    # 14. Receive Items (Accurate count only — stock.picking creation deferred)
    # -------------------------------------------------------------------
    out.info("Counting: Receive Items...")
    acc_receive = acc_count("/accurate/api/receive-item/list.do")
    rows.append(make_row("Receive Items (deferred)", acc_receive, 0))

    # -------------------------------------------------------------------
    # 15. Sales Invoices vs account.move (out_invoice)
    # -------------------------------------------------------------------
    out.info("Counting: Sales Invoices...")
    acc_sinv = acc_count("/accurate/api/sales-invoice/list.do")
    odoo_sinv = odoo_count(
        "account.move",
        [("company_id", "=", odoo_company), ("move_type", "=", "out_invoice")],
    )
    rows.append(make_row("Sales Invoices → account.move (out_invoice)", acc_sinv, odoo_sinv))

    # -------------------------------------------------------------------
    # 16. Sales Receipts vs account.payment (inbound)
    # -------------------------------------------------------------------
    out.info("Counting: Sales Receipts...")
    acc_sreceipts = acc_count("/accurate/api/sales-receipt/list.do")
    odoo_sreceipts = odoo_count(
        "account.payment",
        [("company_id", "=", odoo_company), ("payment_type", "=", "inbound")],
    )
    rows.append(make_row("Sales Receipts → account.payment (inbound)", acc_sreceipts, odoo_sreceipts))

    # -------------------------------------------------------------------
    # 17. Journal Vouchers vs account.move (entry, ref like JV-)
    # -------------------------------------------------------------------
    out.info("Counting: Journal Vouchers...")
    acc_jvs = acc_count("/accurate/api/journal-voucher/list.do")
    odoo_jvs = odoo_count(
        "account.move",
        [("company_id", "=", odoo_company), ("move_type", "=", "entry")],
    )
    rows.append(make_row("Journal Vouchers → account.move (entry)", acc_jvs, odoo_jvs))

    # -------------------------------------------------------------------
    # 18. Bank Transfers (Accurate count; Odoo shares entry count above)
    # -------------------------------------------------------------------
    out.info("Counting: Bank Transfers...")
    acc_bts = acc_count("/accurate/api/bank-transfer/list.do")
    rows.append(make_row("Bank Transfers (see entry count above)", acc_bts, 0))

    # -------------------------------------------------------------------
    # 19. Other Payments
    # -------------------------------------------------------------------
    out.info("Counting: Other Payments...")
    acc_ops = acc_count("/accurate/api/other-payment/list.do")
    rows.append(make_row("Other Payments (see entry count above)", acc_ops, 0))

    # -------------------------------------------------------------------
    # 20. Other Deposits
    # -------------------------------------------------------------------
    out.info("Counting: Other Deposits...")
    acc_ods = acc_count("/accurate/api/other-deposit/list.do")
    rows.append(make_row("Other Deposits (see entry count above)", acc_ods, 0))

    # -------------------------------------------------------------------
    # 21. Expenses
    # -------------------------------------------------------------------
    out.info("Counting: Expenses...")
    acc_exps = acc_count("/accurate/api/expense/list.do")
    rows.append(make_row("Expenses (see entry count above)", acc_exps, 0))

    # -------------------------------------------------------------------
    # 22. Sales Orders vs sale.order
    # -------------------------------------------------------------------
    out.info("Counting: Sales Orders...")
    acc_sos = acc_count("/accurate/api/sales-order/list.do")
    odoo_sos = odoo_count("sale.order", [("company_id", "=", odoo_company)])
    rows.append(make_row("Sales Orders → sale.order", acc_sos, odoo_sos))

    # -------------------------------------------------------------------
    # 23. Sales Returns vs account.move (out_refund)
    # -------------------------------------------------------------------
    out.info("Counting: Sales Returns...")
    acc_srets = acc_count("/accurate/api/sales-return/list.do")
    odoo_srets = odoo_count(
        "account.move",
        [("company_id", "=", odoo_company), ("move_type", "=", "out_refund")],
    )
    rows.append(make_row("Sales Returns → account.move (out_refund)", acc_srets, odoo_srets))

    # -------------------------------------------------------------------
    # 24. Purchase Returns vs account.move (in_refund)
    # -------------------------------------------------------------------
    out.info("Counting: Purchase Returns...")
    acc_prets = acc_count("/accurate/api/purchase-return/list.do")
    odoo_prets = odoo_count(
        "account.move",
        [("company_id", "=", odoo_company), ("move_type", "=", "in_refund")],
    )
    rows.append(make_row("Purchase Returns → account.move (in_refund)", acc_prets, odoo_prets))

    # -------------------------------------------------------------------
    # 25. Item Adjustments (Accurate count only — deferred)
    # -------------------------------------------------------------------
    out.info("Counting: Item Adjustments...")
    acc_iadj = acc_count("/accurate/api/item-adjustment/list.do")
    rows.append(make_row("Item Adjustments (deferred)", acc_iadj, 0))

    # -------------------------------------------------------------------
    # 26. Item Transfers (Accurate count only — deferred)
    # -------------------------------------------------------------------
    out.info("Counting: Item Transfers...")
    acc_itr = acc_count("/accurate/api/item-transfer/list.do")
    rows.append(make_row("Item Transfers (deferred)", acc_itr, 0))

    # -------------------------------------------------------------------
    # Summary table
    # -------------------------------------------------------------------
    out.table(
        "sync-status: Accurate vs Odoo",
        [
            ("Entity", ""),
            ("Accurate", "cyan"),
            ("Odoo", "blue"),
            ("Missing", "yellow"),
            ("Match%", "green"),
        ],
        rows,
    )
