"""Accurate → Odoo diagnostic and repair commands.

Usage examples:
    kctl-odoo accurate sync status terra-buah -c 340
    kctl-odoo accurate validate-journals terra-buah -c 340
"""

import typer

from kctl_odoo.commands._accurate_sync.status import sync_status
from kctl_odoo.commands._accurate_sync.validate_journals import validate_journals_cmd

app = typer.Typer(help="Accurate sync diagnostics.")

app.command("status")(sync_status)
app.command("validate-journals", help="Validate Odoo journals against Accurate JVs — report + fix")(
    validate_journals_cmd
)
