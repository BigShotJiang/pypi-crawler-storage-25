"""Standalone validate-journals command — report + optional fix.

Compares Odoo journal entries against Accurate JVs using the
:mod:`jv_comparator` diff engine, prints a human-readable report, and
optionally applies fixes via :mod:`jv_fixer`.

Usage examples::

    kctl-odoo accurate validate-journals terra-buah -c 340
    kctl-odoo accurate validate-journals terra-buah -c 340 --type bill,payment
    kctl-odoo accurate validate-journals terra-buah -c 340 --jv JV-2026
    kctl-odoo accurate validate-journals terra-buah -c 340 --fix --confirm
    kctl-odoo accurate validate-journals terra-buah -c 340 -o report.txt
"""

from __future__ import annotations

from typing import Annotated

import typer

from kctl_odoo.core.callbacks import AppContext

from ._helpers import create_accurate_client
from .jv_comparator import JVComparison, run_validation
from .jv_fixer import FixResult, fix_mismatch


def validate_journals_cmd(
    ctx: typer.Context,
    profile: Annotated[str, typer.Argument(help="kctl-accurate profile name")],
    odoo_company: Annotated[int, typer.Option("--odoo-company", "-c", help="Odoo res.company ID")],
    fix: Annotated[bool, typer.Option("--fix", help="Apply fixes to mismatched entries")] = False,
    confirm: Annotated[bool, typer.Option("--confirm", help="Confirm destructive fix operations")] = False,
    type_filter: Annotated[
        str | None,
        typer.Option("--type", "-t", help="Filter by transaction type (bill,payment,jv,sales,receipt,transfer)"),
    ] = None,
    jv_filter: Annotated[
        str | None,
        typer.Option("--jv", help="Filter by JV number substring"),
    ] = None,
    output: Annotated[
        str | None,
        typer.Option("--output", "-o", help="Save report to file"),
    ] = None,
) -> None:
    """Validate Odoo journal entries against Accurate JVs.

    Fetches all journal vouchers from Accurate, finds matching Odoo
    account.move records, and compares GL lines (accounts + amounts).
    Prints a report showing MATCH / MISMATCH / NOT_IN_ODOO status for
    each entry.

    Use ``--fix --confirm`` to cancel mismatched Odoo entries and
    recreate them with exact Accurate GL lines.
    """
    app_ctx: AppContext = ctx.obj
    c = app_ctx.client
    out = app_ctx.output

    if fix and not confirm:
        out.error("--fix requires --confirm to prevent accidental changes.")
        raise typer.Exit(1)

    # Build Accurate client
    acc_client = create_accurate_client(profile)

    # Run validation
    out.info(f"Validating journals for company {odoo_company} (profile={profile!r})...")
    results: list[JVComparison] = run_validation(c, acc_client, odoo_company, jv_filter, type_filter)

    if not results:
        out.info("No journal vouchers found to validate.")
        raise typer.Exit(0)

    # Categorize results
    matches: list[JVComparison] = []
    mismatches: list[JVComparison] = []
    not_in_odoo: list[JVComparison] = []

    for r in results:
        if r.status == "ok":
            matches.append(r)
        elif r.status == "mismatch":
            mismatches.append(r)
        elif r.status == "missing":
            not_in_odoo.append(r)
        else:
            not_in_odoo.append(r)

    # Build report lines
    report_lines: list[str] = []
    report_lines.append("=" * 72)
    report_lines.append("  Journal Validation Report")
    report_lines.append(f"  Profile: {profile}  Company: {odoo_company}")
    if type_filter:
        report_lines.append(f"  Type filter: {type_filter}")
    if jv_filter:
        report_lines.append(f"  JV filter: {jv_filter}")
    report_lines.append("=" * 72)
    report_lines.append("")
    report_lines.append(f"  MATCH:        {len(matches)}")
    report_lines.append(f"  MISMATCH:     {len(mismatches)}")
    report_lines.append(f"  NOT IN ODOO:  {len(not_in_odoo)}")
    report_lines.append(f"  TOTAL:        {len(results)}")
    report_lines.append("")

    # Detail mismatches
    if mismatches:
        report_lines.append("-" * 72)
        report_lines.append("  MISMATCHES")
        report_lines.append("-" * 72)
        for r in mismatches:
            move_label = f"move_id={r.odoo_move_id}" if r.odoo_move_id else "no move"
            report_lines.append(f"  {r.jv_number} ({move_label}):")
            for d in r.discrepancies:
                report_lines.append(f"    [{d.severity.value.upper()}] {d.kind}: {d.message}")
        report_lines.append("")

    # Detail not-in-odoo
    if not_in_odoo:
        report_lines.append("-" * 72)
        report_lines.append("  NOT IN ODOO")
        report_lines.append("-" * 72)
        for r in not_in_odoo:
            trans = f" (trans={r.trans_number})" if r.trans_number else ""
            report_lines.append(f"  {r.jv_number}{trans}")
        report_lines.append("")

    # Print report
    full_report = "\n".join(report_lines)
    out.info(full_report)

    # Save to file if requested
    if output:
        with open(output, "w") as f:
            f.write(full_report + "\n")
        out.info(f"Report saved to {output}")

    # If not --fix, show summary and exit
    if not fix:
        if mismatches:
            out.warn(f"{len(mismatches)} entries need fixes. Run with --fix --confirm to apply corrections.")
        else:
            out.success("All entries match. No fixes needed.")
        return

    # Apply fixes
    if not mismatches:
        out.success("No mismatches to fix.")
        return

    out.info(f"\nApplying fixes to {len(mismatches)} mismatched entries...")
    fixed = 0
    errors = 0

    for r in mismatches:
        result: FixResult = fix_mismatch(c, odoo_company, r)
        if result.success:
            fixed += 1
            out.info(f"  Fixed: {result.jv_number} — {result.message}")
        else:
            errors += 1
            out.error(f"  Failed: {result.jv_number} — {result.message}")

    out.info(f"\nFix results: fixed={fixed}  errors={errors}")

    # Post-fix: re-run validation to verify
    if fixed > 0:
        out.info("\nRe-running validation to verify fixes...")
        post_results = run_validation(c, acc_client, odoo_company, jv_filter, type_filter)
        post_mismatches = [r for r in post_results if r.status == "mismatch"]
        if not post_mismatches:
            out.success("100% match achieved after fixes.")
        else:
            out.warn(f"{len(post_mismatches)} mismatches remain after fixes. Manual review may be needed.")
