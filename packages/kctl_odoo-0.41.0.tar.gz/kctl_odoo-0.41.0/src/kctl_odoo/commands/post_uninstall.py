"""Post-uninstall health checks for local databases.

Detects stale views, missing columns, orphan comodels, and broken
get_views calls after module uninstall — before users hit them in
the browser.
"""

from __future__ import annotations

import json
import subprocess
import textwrap
from typing import Annotated

import typer
from rich.console import Console
from rich.table import Table

from kctl_odoo.core.local import LocalClient

app = typer.Typer(help="Post-uninstall health checks.")

console = Console()

_CHECK_SCRIPT = textwrap.dedent(r'''
import json, sys

results = []

def add(name, status, detail, items=None):
    results.append({"name": name, "status": status, "detail": detail, "items": items or []})

# ── 1. Missing columns ──
missing_cols = []
for model_name, Model in env.items():
    if not hasattr(Model, "_fields") or not hasattr(Model, "_table") or Model._abstract or not Model._auto:
        continue
    table = Model._table
    env.cr.execute("SAVEPOINT sp_col")
    try:
        env.cr.execute(
            "SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name=%s",
            [table],
        )
        db_cols = {r[0] for r in env.cr.fetchall()}
        if not db_cols:
            env.cr.execute("RELEASE SAVEPOINT sp_col")
            continue
        for fname, field in Model._fields.items():
            if not field.store or field.column_type is None:
                continue
            if fname not in db_cols and fname != "id":
                missing_cols.append({"model": model_name, "field": fname, "table": table})
        env.cr.execute("RELEASE SAVEPOINT sp_col")
    except Exception:
        env.cr.execute("ROLLBACK TO SAVEPOINT sp_col")

if missing_cols:
    add("Missing columns", "FAIL", f"{len(missing_cols)} fields have no DB column", missing_cols)
else:
    add("Missing columns", "PASS", "All stored fields have columns")

# ── 2. Orphan comodels ──
orphan_comodels = []
for model_name, Model in env.items():
    if not hasattr(Model, "_fields"):
        continue
    for fname, field in Model._fields.items():
        if hasattr(field, "comodel_name") and field.comodel_name and field.store:
            if field.comodel_name not in env:
                orphan_comodels.append({"model": model_name, "field": fname, "comodel": field.comodel_name})

if orphan_comodels:
    add("Orphan comodels", "FAIL", f"{len(orphan_comodels)} fields reference missing models", orphan_comodels)
else:
    add("Orphan comodels", "PASS", "All comodel references valid")

# ── 3. Stale views (only from modules that were recently uninstalled) ──
stale_views = []
env.cr.execute("""
    SELECT d.module || '.' || d.name AS xmlid, v.model, v.arch_db, v.id
    FROM ir_ui_view v
    JOIN ir_model_data d ON d.res_id = v.id AND d.model = 'ir.ui.view'
    JOIN ir_module_module m ON m.name = d.module
    WHERE m.state = 'installed'
      AND v.model IS NOT NULL AND v.model != ''
""")
import xml.etree.ElementTree as ET

for xmlid, model_name, arch_db, vid in env.cr.fetchall():
    if model_name not in env:
        continue
    model_fields = set(env[model_name]._fields.keys())
    if isinstance(arch_db, dict):
        arch_db = arch_db.get("en_US") or next(iter(arch_db.values()), "")
    try:
        root = ET.fromstring("<wrap>" + (arch_db or "") + "</wrap>")
    except ET.ParseError:
        continue
    for fnode in root.iter("field"):
        fname = fnode.get("name")
        if not fname or "." in fname:
            continue
        if fname not in model_fields:
            stale_views.append({"view": xmlid, "model": model_name, "field": fname})
            break

if stale_views:
    add("Stale views", "WARN", f"{len(stale_views)} views reference fields missing from _fields (may be false positives)", stale_views)
else:
    add("Stale views", "PASS", "No stale field references in installed module views")

# ── 4. Broken get_views ──
env.cr.execute("SELECT DISTINCT model FROM ir_ui_view WHERE model IS NOT NULL AND model != ''")
view_models = [r[0] for r in env.cr.fetchall()]
broken_views = []
checked = 0
for m in sorted(set(view_models)):
    if m not in env:
        continue
    checked += 1
    try:
        env.cr.execute("SAVEPOINT sp_gv")
        env[m].get_views([(False, "list"), (False, "form")])
        env.cr.execute("RELEASE SAVEPOINT sp_gv")
    except Exception as e:
        err = str(e).split("\n")[0][:120]
        if "InFailedSql" not in err:
            broken_views.append({"model": m, "error": err})
        env.cr.execute("ROLLBACK TO SAVEPOINT sp_gv")

if broken_views:
    add("Broken get_views", "FAIL", f"{len(broken_views)}/{checked} models fail", broken_views)
else:
    add("Broken get_views", "PASS", f"{checked} models checked")

# ── 5. Orphan ir_model_data ──
env.cr.execute("""
    SELECT d.module, d.name, d.model, d.res_id
    FROM ir_model_data d
    JOIN ir_module_module m ON m.name = d.module
    WHERE m.state = 'uninstalled'
      AND d.model = 'ir.ui.view'
      AND NOT EXISTS (SELECT 1 FROM ir_ui_view v WHERE v.id = d.res_id)
    LIMIT 50
""")
orphan_data = [{"module": r[0], "xmlid": f"{r[0]}.{r[1]}", "model": r[2]} for r in env.cr.fetchall()]
if orphan_data:
    add("Orphan model data", "FAIL", f"{len(orphan_data)} stale ir.model.data records", orphan_data)
else:
    add("Orphan model data", "PASS", "No orphan records")

# ── 6. Report wizard lifecycle ──
report_errors = []
for t in env["report.template"].search([], limit=10):
    try:
        env.cr.execute("SAVEPOINT sp_rw")
        wiz = env["report.wizard"].create({"template_id": t.id})
        wiz._validate_before_export()
        wiz._prepare_report_data()
        env.cr.execute("RELEASE SAVEPOINT sp_rw")
    except Exception as e:
        err = str(e).split("\n")[0][:100]
        if "no report lines" not in err.lower():
            report_errors.append({"template": t.name, "error": err})
        env.cr.execute("ROLLBACK TO SAVEPOINT sp_rw")

if report_errors:
    add("Report lifecycle", "FAIL", f"{len(report_errors)} templates crash", report_errors)
else:
    tcount = env["report.template"].search_count([])
    add("Report lifecycle", "PASS", f"{min(tcount, 10)} templates tested")

print("__JSON_START__")
print(json.dumps(results))
print("__JSON_END__")
''')

_FIX_SCRIPT = textwrap.dedent(r"""
import json, sys

fixes = []

# Fix 1: Add missing columns
for model_name, Model in env.items():
    if not hasattr(Model, "_fields") or not hasattr(Model, "_table") or Model._abstract or not Model._auto:
        continue
    table = Model._table
    env.cr.execute("SAVEPOINT sp_fix")
    try:
        env.cr.execute(
            "SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name=%s",
            [table],
        )
        db_cols = {r[0] for r in env.cr.fetchall()}
        if not db_cols:
            env.cr.execute("RELEASE SAVEPOINT sp_fix")
            continue
        for fname, field in Model._fields.items():
            if not field.store or field.column_type is None:
                continue
            if fname not in db_cols and fname != "id":
                col_type = field.column_type[0]
                env.cr.execute(f'ALTER TABLE "{table}" ADD COLUMN "{fname}" {col_type}')
                fixes.append(f"Added column {table}.{fname} ({col_type})")
        env.cr.execute("RELEASE SAVEPOINT sp_fix")
    except Exception:
        env.cr.execute("ROLLBACK TO SAVEPOINT sp_fix")

# Stale views are WARN-only — not auto-fixed (may cascade-delete child views)

env.cr.commit()
print("__JSON_START__")
print(json.dumps(fixes))
print("__JSON_END__")
""")


def _run_odoo_script(database: str, script: str) -> str:
    client = LocalClient()
    cmd = client._compose_cmd() + [
        "exec",
        "-T",
        client._service,
        "odoo",
        "shell",
        "-d",
        database,
        "--no-http",
        "-c",
        "/etc/odoo/odoo.conf",
    ]
    result = subprocess.run(
        cmd,
        input=script,
        capture_output=True,
        text=True,
        cwd=str(client._project_dir),
        timeout=300,
    )
    output = result.stdout + result.stderr
    start = output.find("__JSON_START__")
    end = output.find("__JSON_END__")
    if start == -1 or end == -1:
        console.print("[red]Script failed — no JSON output.[/red]")
        console.print(output[-500:])
        raise typer.Exit(1)
    return output[start + len("__JSON_START__") : end].strip()


@app.command("post-uninstall")
def post_uninstall(
    database: Annotated[str, typer.Argument(help="Database name to check")],
    fix: Annotated[bool, typer.Option("--fix", help="Auto-fix: add missing columns, delete stale views")] = False,
) -> None:
    """Run post-uninstall health checks on a local database.

    Detects stale views, missing columns, orphan comodels, and broken
    views that would crash in the browser after module uninstall.

    Examples:
        kctl-odoo local post-uninstall mac_odoo_erp_clean
        kctl-odoo local post-uninstall mac_odoo_erp_clean --fix
    """
    console.print(f"\n[bold]Post-Uninstall Health Check — {database}[/bold]\n")

    raw = _run_odoo_script(database, _CHECK_SCRIPT)
    checks: list[dict] = json.loads(raw)

    table = Table(show_header=True)
    table.add_column("Check", style="bold", width=20)
    table.add_column("Status", width=6, justify="center")
    table.add_column("Details", width=55)

    has_failures = False
    for c in checks:
        if c["status"] == "PASS":
            status_style = "[green]PASS[/green]"
        elif c["status"] == "WARN":
            status_style = "[yellow]WARN[/yellow]"
        else:
            status_style = "[red]FAIL[/red]"
            has_failures = True
        table.add_row(c["name"], status_style, c["detail"])

    console.print(table)

    for c in checks:
        if c["status"] in ("FAIL", "WARN") and c["items"]:
            color = "red" if c["status"] == "FAIL" else "yellow"
            console.print(f"\n[{color} bold]{c['name']}:[/{color} bold]")
            for item in c["items"][:15]:
                if "field" in item and "model" in item:
                    console.print(
                        f"  {item['model']}.{item['field']}"
                        + (f" → {item.get('comodel', '')}" if item.get("comodel") else "")
                    )
                elif "view" in item:
                    console.print(f"  {item['view']} → {item['model']}.{item['field']}")
                elif "error" in item:
                    console.print(f"  {item.get('model', item.get('template', ''))}: {item['error'][:80]}")
            if len(c["items"]) > 15:
                console.print(f"  ... and {len(c['items']) - 15} more")

    if has_failures and not fix:
        console.print("\n[yellow]Run with --fix to auto-repair:[/yellow]")
        console.print(f"  kctl-odoo local post-uninstall {database} --fix\n")
        raise typer.Exit(1)

    if has_failures and fix:
        console.print("\n[cyan]Applying fixes...[/cyan]")
        raw = _run_odoo_script(database, _FIX_SCRIPT)
        fixes: list[str] = json.loads(raw)
        for f in fixes:
            console.print(f"  [green]✓[/green] {f}")
        if fixes:
            console.print(f"\n[green]{len(fixes)} fixes applied.[/green]")
            console.print(f"[yellow]Run 'kctl-odoo local post-uninstall {database}' again to verify.[/yellow]")
        else:
            console.print("  [yellow]No auto-fixable issues found.[/yellow]")
        raise typer.Exit(0)

    if not has_failures:
        console.print("\n[green bold]All checks passed — database is healthy.[/green bold]\n")
