"""Feature availability guards for optional Odoo modules."""

from __future__ import annotations

import functools
from collections.abc import Callable
from typing import Any

import typer

from kctl_odoo.core.exceptions import RPCError

_model_cache: dict[str, bool] = {}


def model_available(client: Any, model_name: str) -> bool:
    """Check if an Odoo model exists on the connected instance."""
    if model_name in _model_cache:
        return _model_cache[model_name]
    try:
        count = client.execute_kw("ir.model", "search_count", [[["model", "=", model_name]]])
        _model_cache[model_name] = count > 0
    except RPCError:
        _model_cache[model_name] = False
    return _model_cache[model_name]


def requires_model(*models: str) -> Callable:
    """Decorator: skip command gracefully if required Odoo models are not installed."""

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(ctx: typer.Context, *args: Any, **kwargs: Any) -> Any:
            actx = ctx.obj
            for model in models:
                if not model_available(actx.client, model):
                    actx.output.warn(
                        f"Skipping: model '{model}' not available. Install the required Odoo module first."
                    )
                    raise typer.Exit(0)
            return func(ctx, *args, **kwargs)

        return wrapper

    return decorator
