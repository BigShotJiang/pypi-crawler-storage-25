"""Async command helpers for Typer CLI."""

from __future__ import annotations

import asyncio
import functools
from collections.abc import Callable
from typing import Any


def async_command(func: Callable[..., Any]) -> Callable[..., Any]:
    """Wrap an async function for synchronous Typer execution.

    Usage:
        @app.command()
        @async_command
        async def my_cmd(ctx: typer.Context):
            data = await asyncio.gather(fetch_a(), fetch_b())
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        return asyncio.run(func(*args, **kwargs))

    return wrapper
