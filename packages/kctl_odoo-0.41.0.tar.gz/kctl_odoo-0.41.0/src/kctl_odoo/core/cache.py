"""LRU + TTL cache for read-only JSON-RPC responses."""

from __future__ import annotations

import hashlib
import json
import time
from collections import OrderedDict
from dataclasses import dataclass
from typing import Any


@dataclass
class _CacheEntry:
    value: Any
    expires_at: float


class RPCCache:
    """Per-session in-memory cache for Odoo RPC read operations."""

    def __init__(self, max_size: int = 500, default_ttl: int = 60) -> None:
        self._store: OrderedDict[str, _CacheEntry] = OrderedDict()
        self._max_size = max_size
        self._default_ttl = default_ttl
        self._write_models: set[str] = set()
        self._hits = 0
        self._misses = 0

    def _make_key(self, model: str, method: str, args: tuple, kwargs: dict) -> str:
        raw = json.dumps(
            {"m": model, "method": method, "a": args, "kw": kwargs},
            sort_keys=True,
            default=str,
        )
        return f"{model}:{hashlib.sha256(raw.encode()).hexdigest()[:16]}"

    def get(self, model: str, method: str, args: tuple, kwargs: dict) -> Any | None:
        key = self._make_key(model, method, args, kwargs)
        entry = self._store.get(key)
        if entry and entry.expires_at > time.monotonic():
            self._store.move_to_end(key)
            self._hits += 1
            return entry.value
        if entry:
            del self._store[key]
        self._misses += 1
        return None

    def put(self, model: str, method: str, args: tuple, kwargs: dict, value: Any, ttl: int | None = None) -> None:
        if model in self._write_models:
            return
        key = self._make_key(model, method, args, kwargs)
        self._store[key] = _CacheEntry(value=value, expires_at=time.monotonic() + (ttl or self._default_ttl))
        self._store.move_to_end(key)
        if len(self._store) > self._max_size:
            self._store.popitem(last=False)

    def invalidate_model(self, model: str) -> None:
        self._write_models.add(model)
        keys_to_remove = [k for k in self._store if k.startswith(f"{model}:")]
        for k in keys_to_remove:
            del self._store[k]

    def clear(self) -> None:
        self._store.clear()
        self._write_models.clear()
        self._hits = 0
        self._misses = 0

    def stats(self) -> dict[str, int]:
        return {"hits": self._hits, "misses": self._misses, "size": len(self._store)}
