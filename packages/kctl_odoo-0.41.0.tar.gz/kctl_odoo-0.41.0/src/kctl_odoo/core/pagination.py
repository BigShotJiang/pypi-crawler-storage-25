"""Safe pagination helpers for Odoo RPC queries."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

MAX_SAFE_FETCH = 10_000
DEFAULT_CHUNK_SIZE = 1_000


def safe_search_read(
    client: Any,
    model: str,
    domain: list,
    fields: list[str],
    limit: int = 100,
    offset: int = 0,
    order: str | None = None,
    max_records: int = MAX_SAFE_FETCH,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    progress_callback: Callable[[int, int], None] | None = None,
) -> list[dict]:
    """Paginated search_read with memory guard and progress feedback."""
    total = client.search_count(model, domain)
    if total == 0:
        return []

    effective_limit = min(total, limit) if limit > 0 else total
    if effective_limit > max_records:
        raise ValueError(
            f"Query on {model} would return {effective_limit} records "
            f"(max {max_records}). Use --limit or narrow the domain filter."
        )

    results: list[dict] = []
    current_offset = offset
    remaining = effective_limit

    while remaining > 0:
        batch_size = min(chunk_size, remaining)
        batch = client.search_read(model, domain, fields=fields, limit=batch_size, offset=current_offset, order=order)
        if not batch:
            break
        results.extend(batch)
        current_offset += len(batch)
        remaining -= len(batch)
        if progress_callback:
            progress_callback(len(results), effective_limit)

    return results
