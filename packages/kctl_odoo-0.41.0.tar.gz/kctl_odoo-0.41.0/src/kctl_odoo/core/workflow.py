"""Workflow orchestration engine for multi-step CLI operations."""

from __future__ import annotations

import asyncio
import time
from collections.abc import Callable, Coroutine
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Literal

from kctl_odoo.core.exceptions import CommandError, ConnectionError, KctlError, RPCError

RECOVERABLE_WORKFLOW_ERRORS = (KctlError, RPCError, ConnectionError, CommandError, RuntimeError)


class StepStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class WorkflowStep:
    name: str
    action: Callable[..., Coroutine[Any, Any, Any]]
    on_failure: Literal["abort", "skip", "retry"] = "abort"
    retries: int = 3
    retry_delay: float = 5.0
    status: StepStatus = field(default=StepStatus.PENDING)
    result: Any = field(default=None)
    error: str | None = field(default=None)


@dataclass
class WorkflowResult:
    name: str
    steps: list[WorkflowStep]
    success: bool
    duration_seconds: float


class Workflow:
    def __init__(self, name: str, steps: list[WorkflowStep]) -> None:
        self.name = name
        self.steps = steps

    async def run(self, ctx: Any) -> WorkflowResult:
        start = time.monotonic()
        for step in self.steps:
            step.status = StepStatus.RUNNING
            attempts = 0
            while attempts <= step.retries:
                try:
                    step.result = await step.action(ctx)
                    step.status = StepStatus.SUCCESS
                    break
                except RECOVERABLE_WORKFLOW_ERRORS as e:
                    attempts += 1
                    step.error = str(e)
                    if attempts > step.retries:
                        step.status = StepStatus.FAILED
                        if step.on_failure == "abort":
                            return WorkflowResult(self.name, self.steps, False, time.monotonic() - start)
                        if step.on_failure == "skip":
                            step.status = StepStatus.SKIPPED
                            break
                    elif step.retry_delay > 0:
                        await asyncio.sleep(step.retry_delay)

        success = all(s.status in (StepStatus.SUCCESS, StepStatus.SKIPPED) for s in self.steps)
        return WorkflowResult(self.name, self.steps, success, time.monotonic() - start)

    def dry_run(self) -> list[dict[str, Any]]:
        return [{"name": s.name, "on_failure": s.on_failure, "retries": s.retries} for s in self.steps]
