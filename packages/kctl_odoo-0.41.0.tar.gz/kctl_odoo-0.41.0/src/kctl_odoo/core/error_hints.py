"""Actionable error hints for common CLI failures."""

from __future__ import annotations

import re

from kctl_odoo.core.exceptions import (
    AuthenticationError,
    ConfigError,
    RPCError,
)
from kctl_odoo.core.exceptions import (
    ConnectionError as KctlConnectionError,
)

_HINTS: list[tuple[type, str | None, str]] = [
    (AuthenticationError, None, "Try: kctl-odoo config init (reconfigure credentials)"),
    (KctlConnectionError, None, "Check: is the Odoo server running? Try: kctl-odoo doctor check"),
    (RPCError, r"access.denied", "Your API key may have expired. Try: kctl-odoo config rotate-key"),
    (RPCError, r"not allowed", "Your user lacks access rights. Ask an admin to grant the required group."),
    (ConfigError, r"profile", "No profile set. Try: kctl-odoo config init or use -p <profile>"),
    (ConfigError, None, "Try: kctl-odoo config show to verify your configuration"),
]


def get_hint(error: Exception) -> str | None:
    """Return an actionable hint for a known error type, or None."""
    for exc_type, pattern, hint in _HINTS:
        if isinstance(error, exc_type):
            if pattern is None or re.search(pattern, str(error), re.IGNORECASE):
                return hint
    return None
