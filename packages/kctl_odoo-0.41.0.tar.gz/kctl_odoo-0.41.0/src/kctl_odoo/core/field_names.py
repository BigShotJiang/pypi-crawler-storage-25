"""Centralized Odoo field name constants.

Usage:
    from kctl_odoo.core.field_names import F
    data = client.search_read(model, [], fields=[F.NAME, F.STATE])
"""

from __future__ import annotations


class F:
    ID = "id"
    NAME = "name"
    DISPLAY_NAME = "display_name"
    ACTIVE = "active"
    STATE = "state"
    SEQUENCE = "sequence"
    CREATE_DATE = "create_date"
    WRITE_DATE = "write_date"
    CREATE_UID = "create_uid"
    WRITE_UID = "write_uid"
    COMPANY_ID = "company_id"
    PARTNER_ID = "partner_id"
    USER_ID = "user_id"
    PARENT_ID = "parent_id"
    CURRENCY_ID = "currency_id"
    MOVE_TYPE = "move_type"
    JOURNAL_ID = "journal_id"
    ACCOUNT_ID = "account_id"
    AMOUNT_TOTAL = "amount_total"
    AMOUNT_UNTAXED = "amount_untaxed"
    AMOUNT_TAX = "amount_tax"
    AMOUNT_RESIDUAL = "amount_residual"
    DATE = "date"
    INVOICE_DATE = "invoice_date"
    INSTALLED = "installed"
    SHORTDESC = "shortdesc"
    DEPENDENCIES_ID = "dependencies_id"
    MODEL = "model"
    MODULE = "module"
    REF = "ref"
