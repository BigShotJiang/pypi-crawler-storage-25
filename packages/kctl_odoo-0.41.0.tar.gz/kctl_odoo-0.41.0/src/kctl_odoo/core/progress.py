"""Rich progress bar helper for bulk CLI operations."""

from __future__ import annotations

from collections.abc import Generator
from contextlib import contextmanager

from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn, TimeRemainingColumn


@contextmanager
def cli_progress(description: str = "Processing") -> Generator[Progress, None, None]:
    """Rich progress bar context manager for bulk operations."""
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("{task.completed}/{task.total}"),
        TimeRemainingColumn(),
    ) as progress:
        yield progress
