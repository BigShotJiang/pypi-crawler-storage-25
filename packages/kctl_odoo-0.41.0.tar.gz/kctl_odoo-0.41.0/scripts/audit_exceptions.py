"""AST-based audit of every `except Exception` block in kctl_odoo source.

Classifies each handler by the primary call pattern inside the corresponding
try-block and emits a JSON manifest to stdout. A human-readable summary goes
to stderr.

Usage (from packages/kctl-odoo/):
    python scripts/audit_exceptions.py > scripts/exception_manifest.json
"""

from __future__ import annotations

import ast
import json
import sys
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

SRC_ROOT = Path(__file__).parent.parent / "src" / "kctl_odoo"

# RPC method names recognised as Odoo JSON-RPC calls
RPC_METHODS = {
    "search_read",
    "search",
    "read",
    "create",
    "write",
    "unlink",
    "execute_kw",
    "call_wizard",
    "search_count",
    "fields_get",
    "authenticate",
    "name_search",
}

# Category → suggested replacement exception types
CATEGORY_SUGGESTIONS: dict[str, str] = {
    "rpc_call": "RPCError, ConnectionError",
    "datetime_parse": "ValueError, TypeError",
    "numeric_conversion": "ValueError, TypeError",
    "file_io": "OSError",
    "json_parse": "json.JSONDecodeError, ValueError",
    "subprocess": "CommandError, OSError",
    "dict_key_access": "KeyError, TypeError",
    "unknown": "MANUAL_REVIEW",
}

# ---------------------------------------------------------------------------
# AST helpers
# ---------------------------------------------------------------------------


def iter_calls(node: ast.AST) -> list[ast.Call]:
    """Return all ast.Call nodes reachable from *node*."""
    return [n for n in ast.walk(node) if isinstance(n, ast.Call)]


def call_func_name(call: ast.Call) -> str:
    """Best-effort string representation of the callable being invoked."""
    func = call.func
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        return func.attr
    return ""


def has_attribute_call(calls: list[ast.Call], names: set[str]) -> bool:
    return any(call_func_name(c) in names for c in calls)


def has_name_call(calls: list[ast.Call], names: set[str]) -> bool:
    """True if any call's *full* path contains one of *names*."""
    return any(call_func_name(c) in names for c in calls)


def first_string_arg(call: ast.Call) -> str:
    """Return the first positional string argument of a call, or ''."""
    if call.args and isinstance(call.args[0], ast.Constant) and isinstance(call.args[0].value, str):
        return call.args[0].value
    return ""


# ---------------------------------------------------------------------------
# Classification logic
# ---------------------------------------------------------------------------


def classify(try_node: ast.Try) -> str:
    """Determine the category for a try-block based on its body calls."""
    body_nodes = try_node.body
    calls: list[ast.Call] = []
    for stmt in body_nodes:
        calls.extend(iter_calls(stmt))

    func_names = {call_func_name(c) for c in calls}

    # ---- RPC call ----
    if func_names & RPC_METHODS:
        return "rpc_call"

    # Also detect chained attribute calls like c.search_read(...)
    for c in calls:
        if isinstance(c.func, ast.Attribute) and c.func.attr in RPC_METHODS:
            return "rpc_call"

    # ---- datetime / date parsing ----
    datetime_funcs = {"strptime", "fromisoformat", "fromtimestamp", "combine"}
    datetime_modules = {"datetime", "date", "time"}
    for c in calls:
        name = call_func_name(c)
        if name in datetime_funcs:
            return "datetime_parse"
        # datetime.strptime / datetime.datetime.strptime
        if isinstance(c.func, ast.Attribute) and c.func.attr in datetime_funcs:
            return "datetime_parse"
        # dateutil.parser.parse, arrow.get, pendulum.parse, etc.
        if name in {"parse"} and isinstance(c.func, ast.Attribute):
            owner = c.func.value
            if isinstance(owner, ast.Attribute) and owner.attr in {"parser"}:
                return "datetime_parse"
        if name in datetime_modules and isinstance(c.func, ast.Name):
            return "datetime_parse"

    # ---- numeric conversion ----
    numeric_funcs = {"int", "float", "Decimal", "frompydecimal", "fromstring"}
    for c in calls:
        name = call_func_name(c)
        if name in numeric_funcs and isinstance(c.func, ast.Name):
            return "numeric_conversion"

    # ---- file I/O ----
    for c in calls:
        name = call_func_name(c)
        if name in {"open"}:
            return "file_io"
        if name in {
            "read_text",
            "write_text",
            "read_bytes",
            "write_bytes",
            "mkdir",
            "unlink",
            "rename",
            "copy",
            "move",
        }:
            return "file_io"
        if isinstance(c.func, ast.Attribute) and c.func.attr in {
            "open",
            "read_text",
            "write_text",
            "read_bytes",
            "write_bytes",
        }:
            return "file_io"

    # ---- JSON parsing ----
    for c in calls:
        name = call_func_name(c)
        if name in {"loads", "load", "dumps", "dump"} and isinstance(c.func, ast.Attribute):
            owner = c.func.value
            if isinstance(owner, ast.Name) and owner.id == "json":
                return "json_parse"
        # response.json() — common pattern
        if name == "json" and isinstance(c.func, ast.Attribute):
            return "json_parse"

    # ---- subprocess ----
    subprocess_funcs = {"run", "check_output", "check_call", "Popen", "call", "run_quiet"}
    subprocess_modules = {"subprocess"}
    for c in calls:
        name = call_func_name(c)
        if name in {"run_quiet", "run_command", "ssh_run", "scp_download", "scp_upload"}:
            return "subprocess"
        if isinstance(c.func, ast.Attribute) and c.func.attr in subprocess_funcs:
            owner = c.func.value
            if isinstance(owner, ast.Name) and owner.id in subprocess_modules:
                return "subprocess"
        if isinstance(c.func, ast.Name) and name in subprocess_funcs:
            return "subprocess"

    # ---- dict key access (subscript) ----
    for stmt in body_nodes:
        for node in ast.walk(stmt):
            if isinstance(node, ast.Subscript) and isinstance(node.slice, (ast.Constant, ast.Name)):
                # Only flag if the subscript target looks like a dict (Name or Attribute)
                if isinstance(node.value, (ast.Name, ast.Attribute, ast.Call)):
                    return "dict_key_access"

    return "unknown"


# ---------------------------------------------------------------------------
# Main visitor
# ---------------------------------------------------------------------------


class ExceptionAuditor(ast.NodeVisitor):
    """Walk each module and collect all `except Exception` handlers."""

    def __init__(self, filepath: Path, src_root: Path) -> None:
        self.filepath = filepath
        self.src_root = src_root
        self.rel_path = str(filepath.relative_to(src_root))
        self.findings: list[dict[str, Any]] = []

    def visit_Try(self, node: ast.Try) -> None:  # noqa: N802
        for handler in node.handlers:
            if self._is_bare_exception(handler):
                category = classify(node)
                handler_src = self._handler_snippet(handler)
                self.findings.append(
                    {
                        "file": self.rel_path,
                        "line": handler.lineno,
                        "category": category,
                        "suggestion": CATEGORY_SUGGESTIONS[category],
                        "handler_type": self._handler_type_str(handler),
                        "handler_snippet": handler_src,
                    }
                )
        self.generic_visit(node)

    @staticmethod
    def _is_bare_exception(handler: ast.ExceptHandler) -> bool:
        """True when handler catches Exception (bare or aliased)."""
        if handler.type is None:
            # bare `except:` — not `except Exception`
            return False
        t = handler.type
        if isinstance(t, ast.Name) and t.id == "Exception":
            return True
        # Tuple: except (Exception, ...) — only flag if Exception is in there
        if isinstance(t, ast.Tuple):
            return any(isinstance(elt, ast.Name) and elt.id == "Exception" for elt in t.elts)
        return False

    @staticmethod
    def _handler_type_str(handler: ast.ExceptHandler) -> str:
        if handler.type is None:
            return "bare"
        if isinstance(handler.type, ast.Name):
            base = handler.type.id
        elif isinstance(handler.type, ast.Tuple):
            base = "(" + ", ".join(elt.id if isinstance(elt, ast.Name) else "?" for elt in handler.type.elts) + ")"
        else:
            base = "?"
        if handler.name:
            return f"{base} as {handler.name}"
        return base

    def _handler_snippet(self, handler: ast.ExceptHandler) -> str:
        """Return a short textual description of the handler body."""
        body_types = [type(s).__name__ for s in handler.body[:3]]
        return ", ".join(body_types)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def audit_src(src_root: Path) -> list[dict[str, Any]]:
    all_findings: list[dict[str, Any]] = []
    py_files = sorted(src_root.rglob("*.py"))

    for pyfile in py_files:
        # Skip __pycache__ / compiled artefacts
        if "__pycache__" in pyfile.parts:
            continue
        try:
            source = pyfile.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(pyfile))
        except SyntaxError as exc:
            print(f"WARNING: could not parse {pyfile}: {exc}", file=sys.stderr)
            continue

        auditor = ExceptionAuditor(pyfile, src_root)
        auditor.visit(tree)
        all_findings.extend(auditor.findings)

    return all_findings


def main() -> None:
    findings = audit_src(SRC_ROOT)

    # ---- Build summary stats ----
    total = len(findings)
    by_category: dict[str, int] = {}
    by_file: dict[str, int] = {}
    for f in findings:
        by_category[f["category"]] = by_category.get(f["category"], 0) + 1
        by_file[f["file"]] = by_file.get(f["file"], 0) + 1

    top_files = sorted(by_file.items(), key=lambda x: x[1], reverse=True)[:10]

    manifest = {
        "meta": {
            "total": total,
            "src_root": str(SRC_ROOT),
            "by_category": by_category,
            "category_suggestions": CATEGORY_SUGGESTIONS,
            "top_files_by_count": [{"file": f, "count": c} for f, c in top_files],
        },
        "findings": findings,
    }

    # JSON to stdout
    json.dump(manifest, sys.stdout, indent=2)
    sys.stdout.write("\n")

    # Summary to stderr
    print("\n=== Exception Audit Summary ===", file=sys.stderr)
    print(f"Total `except Exception` sites found: {total}", file=sys.stderr)
    print(f"Files scanned: {len(list(SRC_ROOT.rglob('*.py')))}", file=sys.stderr)
    print("\nBy category:", file=sys.stderr)
    for cat, count in sorted(by_category.items(), key=lambda x: x[1], reverse=True):
        suggestion = CATEGORY_SUGGESTIONS[cat]
        print(f"  {cat:<22} {count:>4}   → {suggestion}", file=sys.stderr)
    print("\nTop files by exception count:", file=sys.stderr)
    for fname, count in top_files:
        print(f"  {count:>4}  {fname}", file=sys.stderr)
    print(f"\nManifest written to stdout ({total} entries).", file=sys.stderr)


if __name__ == "__main__":
    main()
