# Changelog

All notable changes to Adrift are documented here.

This project follows [Semantic Versioning](https://semver.org/spec/v2.0.0.html) and the [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) format.

## [Unreleased]

## [0.1.0] - 2026-05-18

First public release. Everything below built and dogfooded against this repo's own PRs before launch.

### Reviewer

- **Agentic LLM reviewer** with Anthropic-native `tool_use` (no LangChain). The agent decides what to investigate per PR using a small tool set:
  - `search_decisions(query, k, tier?)` — semantic search over the decision store.
  - `query_impact_zone(paths, hops)` — structural impact via [GitNexus](https://github.com/abhigyanpatwari/GitNexus) MCP.
  - `read_file_context(path, line_start?, line_end?)` — read actual file content so the agent doesn't infer "X is removed" from a diff that only shows additions.
  - `report_finding(...)` — accumulator for confirmed regressions.
- **Pipeline reviewer** (retrieval → judge) as a fallback when there's no decision store yet.
- **Author intent as first-class context.** PR title + description are injected as an "AUTHOR'S STATED INTENT" section above the diff; the system prompt instructs the agent to weigh this heavily before firing a finding.
- **Conservative by default.** Min confidence floor (default 0.6 for findings, 0.7 for classifier). False positives erode reviewer trust faster than missed regressions.
- **Two-tier severity rendering.** HIGH findings render up front; MEDIUM/LOW collapse behind a `<details>` block so reviewers see a clean comment first.
- **Skip review on trivial PRs.** Docs/CHANGELOG/lockfile-only diffs return a short "skipped" comment without burning an LLM round-trip.

### Decision store

- **SQLite + [sqlite-vec](https://github.com/asg017/sqlite-vec)** for the local persistent store. Single file under `.adrift/decisions.db`. Zero infra.
- **fastembed** (BAAI/bge-small-en-v1.5) for local embeddings. No API calls for vector encoding.
- **Three decision tiers** with weighted retrieval: `EXPLICIT` (ADRs, `@decision:` annotations, `CLAUDE.md`), `MINED` (classifier-filtered prose), and `INFERRED` (reserved for future pattern-based extraction).
- **Recency decay** on retrieval — decision weight multiplied by `exp(-age_days · ln2 / half_life_days)`, default half-life 365 days. Old decisions fade unless reinforced.
- **Supersession** — `accept` reinforces weight, `override` creates a new EXPLICIT decision and marks the original superseded, `dismiss` demotes weight, `flag` adds a new MINED decision.

### Sources & mining

- **`ADRSource`** reads markdown decision records from `docs/adr/` and `decisions/`.
- **`AnnotationSource`** scans the repo for `@decision:` code comments in `#`, `//`, `--` syntaxes.
- **`MarkdownSource`** treats top-level `CLAUDE.md` / `AGENTS.md` as EXPLICIT decisions — these files exist precisely to encode rules an agent should respect.
- **`MarkdownMiner`** walks every `.md` in the repo (skipping `node_modules/`, `.venv/`, `.gitnexus/`, ADR dirs, etc.), section-splits by H2, and routes each section through the classifier.
- **`PRBundleMiner`** per merged PR aggregates description + commit messages + review-line comments + issue comments into one classification candidate. Captures the *why* (review counterarguments, commit rationale) — not just the *what*. Bot-authored comments filtered to prevent feedback loops.
- **Strict-precision classifier** with **verbatim-quote requirement.** Decisions extracted from mined content must come with character-for-character quotes from the source body; quotes that don't match are silently dropped before storage. Prevents the classifier from inventing constraints the author never wrote.

### CLI

- `adrift review <pr-url>` — review a PR. `--mode agentic` (default) or `--mode pipeline`. `--dry-run` prints without posting.
- `adrift index <repo-url>` — bootstrap the decision store from a repo's ADRs + markdown + last 100 PRs.
- `adrift index-pr <pr-url>` — incremental update from one PR. Used as a post-review CI step.
- `adrift learn <pr-url>` — apply `/adrift accept|override|dismiss|flag` slash commands from PR comments.

### CI

- **Drop-in GitHub Action workflows** in [`examples/workflows/`](examples/workflows/). One workflow file + one secret = automatic review on every PR.
- **Self-bootstrapping.** First PR after install mines the repo's history (~30–60s, ~$0.30 one-time); subsequent PRs reuse the cached decision store.
- **Per-PR incremental learning.** Each merged PR's description is folded into the store via `index-pr`, so the store grows monotonically without a separate batch job.
- **Self-bootstrapping learn workflow.** Slash-command replies on `issue_comment` events trigger feedback application; the workflow auto-bootstraps when it can't restore a cache (caches are branch-scoped, so the default-branch learn run might not see a PR-branch cache).

### Code-graph integration

- **[GitNexus](https://github.com/abhigyanpatwari/GitNexus) MCP** as the structural-signal backend. Enabled by default; if the binary isn't on PATH, a one-line warning is logged and the reviewer runs without it.
- **`SyncGitNexusClient`** runs the MCP session inside a single long-running task on a background-thread event loop (the pattern that survives anyio's cancel-scope task-identity constraint).
- **`_verify_tools` on connect** asserts the expected GitNexus tool name exists. A future GitNexus rename will fail loud rather than silently producing empty results.

### Distribution

- **PyPI:** `pip install adrift-pr` (the package name is `adrift-pr` because `adrift` was already taken by an abandoned 2025 placeholder; the CLI command, Python import path, and GitHub repo name all stay `adrift`).
- **Docker image:** `ghcr.io/mohamad-zubi/adrift:0.1.0` — Python + Node + GitNexus + Adrift all baked in. Useful for CI steps and one-off runs.
- **OIDC trusted publishing** to PyPI on tag push (`v*`). No API tokens in repo secrets.

### Tech stack

| Concern | Choice |
|---|---|
| Language | Python 3.11+ |
| Package mgmt | uv (or pip) |
| CLI | Typer |
| LLM client | litellm (multi-provider: Anthropic, OpenAI, OpenRouter, Bedrock) |
| Embeddings | fastembed (local) |
| Vector store | sqlite-vec (embedded) |
| Persistent store | SQLite |
| Code graph | GitNexus via MCP (optional) |
| GitHub API | PyGithub |
| Config | YAML + Pydantic |
| Tests | pytest |
| Lint/format | ruff |
| License | MIT |

Tests: 261 passing, fast (~2s), offline.
