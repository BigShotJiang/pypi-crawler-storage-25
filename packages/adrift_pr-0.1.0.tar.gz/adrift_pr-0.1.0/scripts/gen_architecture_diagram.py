"""Generates ``assets/architecture.excalidraw``.

A hand-drawn system diagram with three zones:

  1. Top: title + the two-case review sequence on GitHub CI
     - Case 1: first run on a fresh repo (cache miss → bootstrap)
     - Case 2: subsequent run (cache hit, fast path)

  2. Middle: per-PR data flow inside ``adrift review``

  3. Bottom: how the tool is built (tech stack)

Icons are NOT emojis — every place an icon should appear is a square
labeled with the logo name. To finish the diagram, open it in
https://excalidraw.com (File → Open), then drop in icons from these
Excalidraw libraries (Library panel → Browse libraries):

  - github           https://libraries.excalidraw.com/?#github-Vc28InpZ
  - tech-logos       https://libraries.excalidraw.com/?#technology-logos
  - data-engineering https://libraries.excalidraw.com/?#data-engineering

Replace each labeled square (drag the library icon over the box, then
delete the placeholder). Export to PNG (File → Export → PNG, scale 2x).
"""

from __future__ import annotations

import json
import secrets
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


def _eid() -> str:
    return secrets.token_hex(8)


def _seed() -> int:
    return secrets.randbelow(2**31)


def _base(**kw: Any) -> dict[str, Any]:
    d: dict[str, Any] = {
        "id": _eid(),
        "type": "rectangle",
        "x": 0,
        "y": 0,
        "width": 100,
        "height": 50,
        "angle": 0,
        "strokeColor": "#1e1e1e",
        "backgroundColor": "transparent",
        "fillStyle": "solid",
        "strokeWidth": 2,
        "strokeStyle": "solid",
        "roughness": 1,
        "opacity": 100,
        "groupIds": [],
        "frameId": None,
        "roundness": None,
        "seed": _seed(),
        "version": 1,
        "versionNonce": _seed(),
        "isDeleted": False,
        "boundElements": [],
        "updated": 1,
        "link": None,
        "locked": False,
    }
    d.update(kw)
    return d


def rect(
    x: int,
    y: int,
    w: int,
    h: int,
    *,
    stroke: str = "#1e1e1e",
    bg: str = "transparent",
    fill: str = "solid",
    stroke_style: str = "solid",
    rounded: bool = False,
    width: int = 2,
) -> dict[str, Any]:
    el = _base(
        type="rectangle",
        x=x,
        y=y,
        width=w,
        height=h,
        strokeColor=stroke,
        backgroundColor=bg,
        fillStyle=fill,
        strokeStyle=stroke_style,
        strokeWidth=width,
    )
    if rounded:
        el["roundness"] = {"type": 3}
    return el


def diamond(
    x: int,
    y: int,
    w: int,
    h: int,
    *,
    stroke: str = "#1e1e1e",
    bg: str = "transparent",
    fill: str = "solid",
    width: int = 2,
) -> dict[str, Any]:
    return _base(
        type="diamond",
        x=x,
        y=y,
        width=w,
        height=h,
        strokeColor=stroke,
        backgroundColor=bg,
        fillStyle=fill,
        strokeWidth=width,
    )


def ellipse(
    x: int,
    y: int,
    w: int,
    h: int,
    *,
    stroke: str = "#1e1e1e",
    bg: str = "transparent",
    fill: str = "solid",
    width: int = 2,
) -> dict[str, Any]:
    return _base(
        type="ellipse",
        x=x,
        y=y,
        width=w,
        height=h,
        strokeColor=stroke,
        backgroundColor=bg,
        fillStyle=fill,
        strokeWidth=width,
    )


def text(
    x: int,
    y: int,
    w: int,
    h: int,
    body: str,
    *,
    size: int = 20,
    align: str = "center",
    color: str = "#1e1e1e",
    family: int = 5,  # 5 = Excalifont (hand-drawn)
) -> dict[str, Any]:
    el = _base(
        type="text",
        x=x,
        y=y,
        width=w,
        height=h,
        strokeColor=color,
        fillStyle="solid",
        text=body,
        fontSize=size,
        fontFamily=family,
        textAlign=align,
        verticalAlign="middle",
        baseline=int(size * 0.75),
        containerId=None,
        originalText=body,
        lineHeight=1.25,
        autoResize=True,
    )
    return el


def arrow(
    x1: int,
    y1: int,
    x2: int,
    y2: int,
    *,
    stroke: str = "#1e1e1e",
    style: str = "solid",
    width: int = 2,
    label: str = "",
) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = [
        _base(
            type="arrow",
            x=x1,
            y=y1,
            width=x2 - x1,
            height=y2 - y1,
            strokeColor=stroke,
            strokeStyle=style,
            strokeWidth=width,
            startBinding=None,
            endBinding=None,
            lastCommittedPoint=None,
            startArrowhead=None,
            endArrowhead="arrow",
            points=[[0, 0], [x2 - x1, y2 - y1]],
            elbowed=False,
        )
    ]
    if label:
        mx = (x1 + x2) // 2
        my = (y1 + y2) // 2 - 14
        out.append(
            text(mx - len(label) * 4, my, len(label) * 8 + 20, 22, label, size=14, color=stroke)
        )
    return out


def icon_box(
    x: int, y: int, size: int, label: str, *, stroke: str = "#1e1e1e", bg: str = "#fff"
) -> list[dict[str, Any]]:
    """A placeholder square with a faint icon-name label. Drop in a library
    icon to replace.
    """
    return [
        rect(x, y, size, size, stroke=stroke, bg=bg, rounded=True, stroke_style="dashed", width=1),
        text(x + 2, y + size // 2 - 10, size - 4, 20, label, size=11, color="#868e96"),
    ]


# Palette
INK = "#1e1e1e"
RED = "#e03131"
RED_BG = "#ffc9c9"
BLUE = "#1971c2"
BLUE_BG = "#a5d8ff"
GREEN = "#2f9e44"
GREEN_BG = "#b2f2bb"
YELLOW_BG = "#ffec99"
GRAY = "#868e96"
PURPLE = "#7048e8"
PURPLE_BG = "#d0bfff"


@dataclass
class Layout:
    elements: list[dict[str, Any]] = field(default_factory=list)

    def add(self, *els: Any) -> None:
        for e in els:
            if isinstance(e, list):
                self.elements.extend(e)
            else:
                self.elements.append(e)


L = Layout()


# ─── HEADER ────────────────────────────────────────────────────────────────

L.add(
    text(60, 30, 1100, 56, "Adrift  ·  how a PR gets reviewed", size=44, align="left"),
    text(
        60,
        92,
        1100,
        28,
        "open-source review for design-intent regressions on every PR  ·  one secret, one workflow",
        size=18,
        align="left",
        color=GRAY,
    ),
)


# ─── SEQUENCE (TWO CASES) ──────────────────────────────────────────────────

SEQ_TOP = 160

# Section header
L.add(
    text(60, SEQ_TOP, 1200, 36, "On every PR", size=26, align="left", color=INK),
    text(
        60,
        SEQ_TOP + 38,
        1200,
        24,
        "the GitHub Action takes one of two paths depending on whether the decision store is cached",
        size=15,
        align="left",
        color=GRAY,
    ),
)

# Two columns
COL1_X = 80
COL2_X = 760
COL_W = 580
COL_TOP = SEQ_TOP + 95

# Column 1 header — CASE 1 (cold)
L.add(
    rect(COL1_X, COL_TOP, COL_W, 60, stroke=RED, bg=RED_BG, fill="hachure", rounded=True, width=2),
    text(
        COL1_X + 24,
        COL_TOP + 10,
        COL_W - 48,
        28,
        "CASE 1  ·  first run on this repo",
        size=20,
        align="left",
        color=RED,
    ),
    text(
        COL1_X + 24,
        COL_TOP + 36,
        COL_W - 48,
        20,
        "cache miss  →  bootstrap fires once",
        size=14,
        align="left",
        color=GRAY,
    ),
)

# Column 2 header — CASE 2 (warm)
L.add(
    rect(
        COL2_X, COL_TOP, COL_W, 60, stroke=GREEN, bg=GREEN_BG, fill="hachure", rounded=True, width=2
    ),
    text(
        COL2_X + 24,
        COL_TOP + 10,
        COL_W - 48,
        28,
        "CASE 2  ·  every subsequent run",
        size=20,
        align="left",
        color=GREEN,
    ),
    text(
        COL2_X + 24,
        COL_TOP + 36,
        COL_W - 48,
        20,
        "cache hit  →  fast path",
        size=14,
        align="left",
        color=GRAY,
    ),
)


# Helper to draw a step in a sequence column. Returns the y of the bottom.
def step(
    col_x: int,
    y: int,
    label: str,
    sub: str = "",
    *,
    bg: str = "#fff",
    stroke: str = INK,
    width: int = 2,
) -> int:
    h = 56 if sub else 40
    L.add(
        rect(col_x, y, COL_W, h, stroke=stroke, bg=bg, rounded=True, width=width),
        text(col_x + 16, y + 8, COL_W - 32, 28, label, size=17, align="left"),
    )
    if sub:
        L.add(text(col_x + 16, y + 32, COL_W - 32, 20, sub, size=13, align="left", color=GRAY))
    return y + h


def vsep(col_x: int, y: int, h: int = 16) -> int:
    L.add(arrow(col_x + COL_W // 2, y, col_x + COL_W // 2, y + h, stroke=GRAY, width=1))
    return y + h


# Sequence body
seq_y = COL_TOP + 80

# Step: PR opens (shared)
for col_x in (COL1_X, COL2_X):
    y = step(
        col_x, seq_y, "Pull request opens", "opened / synchronize / reopened", bg="#fff", stroke=INK
    )
    vsep(col_x, y)
seq_y = y + 16


# Step: Setup
for col_x in (COL1_X, COL2_X):
    y = step(
        col_x,
        seq_y,
        "Setup runner",
        "Python · Node · pip install adrift-pr · npm install -g gitnexus",
        bg="#fff",
    )
    vsep(col_x, y)
seq_y = y + 16


# Step: gitnexus analyze
for col_x in (COL1_X, COL2_X):
    y = step(
        col_x,
        seq_y,
        "gitnexus analyze .  (~3s)",
        "build code graph for impact-zone queries",
        bg="#fff",
    )
    vsep(col_x, y)
seq_y = y + 16


# Step: cache restore — diamond decision
diamond_h = 70
for col_x in (COL1_X, COL2_X):
    L.add(
        rect(
            col_x,
            seq_y,
            COL_W,
            diamond_h,
            stroke=PURPLE,
            bg=PURPLE_BG,
            fill="hachure",
            rounded=True,
        ),
        text(
            col_x + 16, seq_y + 10, COL_W - 32, 26, "actions/cache/restore", size=16, align="left"
        ),
        text(
            col_x + 16,
            seq_y + 36,
            COL_W - 32,
            22,
            "key: adrift-store-<repo>-<run-id>",
            size=12,
            align="left",
            color=GRAY,
        ),
    )

# Verdict labels for each branch
L.add(
    text(
        COL1_X + COL_W - 110,
        seq_y + diamond_h - 28,
        110,
        22,
        "→  MISS",
        size=15,
        align="right",
        color=RED,
    ),
    text(
        COL2_X + COL_W - 100,
        seq_y + diamond_h - 28,
        110,
        22,
        "→  HIT  ✓",
        size=15,
        align="right",
        color=GREEN,
    ),
)
for col_x in (COL1_X, COL2_X):
    vsep(col_x, seq_y + diamond_h)
seq_y = seq_y + diamond_h + 16


# Step: Bootstrap (Case 1 only) vs. skip (Case 2)
# Case 1: full bootstrap
y_case1 = step(
    COL1_X,
    seq_y,
    "Bootstrap  ·  adrift index <repo>",
    "ADRs · @decision · CLAUDE.md · markdown · PR bundles  →  classifier  →  store",
    bg=RED_BG,
    stroke=RED,
)
L.add(
    text(
        COL1_X + COL_W - 220,
        y_case1 - 18,
        220,
        18,
        "one-time  ·  ~30–60s  ·  ~$0.30",
        size=12,
        align="right",
        color=RED,
    )
)
vsep(COL1_X, y_case1)

# Case 2: skip
y_case2 = step(
    COL2_X,
    seq_y,
    "(bootstrap step skipped)",
    "decision store restored from cache",
    bg=GREEN_BG,
    stroke=GREEN,
)
vsep(COL2_X, y_case2)
seq_y = max(y_case1, y_case2) + 16


# Step: adrift review (shared)
for col_x in (COL1_X, COL2_X):
    y = step(
        col_x,
        seq_y,
        "adrift review <pr-url>",
        "agentic LLM loop · search_decisions · query_impact_zone · report_finding",
        bg=BLUE_BG,
        stroke=BLUE,
    )
    vsep(col_x, y)
seq_y = y + 16


# Step: post comment
for col_x in (COL1_X, COL2_X):
    y = step(
        col_x,
        seq_y,
        "Post / update PR comment",
        "markdown findings · hidden markers for /adrift slash commands",
        bg="#fff",
    )
    vsep(col_x, y)
seq_y = y + 16


# Step: index-pr (shared)
for col_x in (COL1_X, COL2_X):
    y = step(
        col_x,
        seq_y,
        "adrift index-pr <pr-url>",
        "mine THIS PR's bundle  →  add to store if decision-bearing",
        bg=YELLOW_BG,
    )
    vsep(col_x, y)
seq_y = y + 16


# Step: cache save
for col_x in (COL1_X, COL2_X):
    y = step(
        col_x,
        seq_y,
        "actions/cache/save",
        "write store back to a fresh cache entry",
        bg=PURPLE_BG,
        stroke=PURPLE,
    )
seq_y = y + 14

# Totals
L.add(
    text(
        COL1_X + 16,
        seq_y,
        COL_W - 32,
        24,
        "total:  ~90–120 s  ·  $0.20 – $1.30  (one time)",
        size=15,
        align="left",
        color=RED,
    ),
    text(
        COL2_X + 16,
        seq_y,
        COL_W - 32,
        24,
        "total:  ~60–90 s  ·  $0.05 – $0.30  (every PR)",
        size=15,
        align="left",
        color=GREEN,
    ),
)


# ─── INSIDE adrift review ──────────────────────────────────────────────────

INNER_TOP = seq_y + 80

L.add(
    text(60, INNER_TOP, 1300, 36, "Inside  adrift review", size=26, align="left"),
    text(
        60,
        INNER_TOP + 38,
        1300,
        24,
        "agentic mode — the LLM decides which tool to call next, conservatively",
        size=15,
        align="left",
        color=GRAY,
    ),
)

INNER_Y = INNER_TOP + 90

# Inputs
IN_X = 80
L.add(
    rect(
        IN_X, INNER_Y, 220, 80, stroke=RED, bg="#fff", stroke_style="dashed", rounded=True, width=2
    ),
    text(IN_X + 16, INNER_Y + 10, 200, 26, "Inputs", size=18, align="left"),
    text(IN_X + 16, INNER_Y + 38, 200, 22, "·  PR diff (GitHub API)", size=13, align="left"),
    text(IN_X + 16, INNER_Y + 56, 200, 22, "·  decision store", size=13, align="left"),
)

# Agent box
AG_X = 380
AG_W = 460
AG_H = 280
L.add(
    rect(
        AG_X,
        INNER_Y - 10,
        AG_W,
        AG_H,
        stroke=INK,
        bg=BLUE_BG,
        fill="hachure",
        rounded=True,
        width=3,
    ),
)

# Agent header with icon placeholder
L.add(
    icon_box(AG_X + 18, INNER_Y + 4, 44, "claude"),
    text(AG_X + 76, INNER_Y + 14, AG_W - 90, 28, "Agentic reviewer", size=22, align="left"),
    text(
        AG_X + 76,
        INNER_Y + 44,
        AG_W - 90,
        22,
        "litellm  ·  Anthropic-native tool_use loop",
        size=13,
        align="left",
        color=GRAY,
    ),
)

# Three tools
TOOL_X = AG_X + 20
tool_y = INNER_Y + 90
tools = [
    ("search_decisions(query, k)", "→  DecisionStore", BLUE, "db"),
    ("query_impact_zone(paths)", "→  GitNexus MCP (code graph)", GREEN, "graph"),
    ("report_finding(...)", "→  accumulated findings", PURPLE, "flag"),
]
for tname, tdest, tcolor, ticon in tools:
    L.add(
        rect(TOOL_X, tool_y, AG_W - 40, 50, stroke=tcolor, bg="#fff", rounded=True, width=1),
        icon_box(TOOL_X + 8, tool_y + 8, 34, ticon),
        text(
            TOOL_X + 50,
            tool_y + 6,
            AG_W - 100,
            24,
            tname,
            size=16,
            align="left",
            color=INK,
            family=3,
        ),
        text(
            TOOL_X + 50,
            tool_y + 28,
            AG_W - 100,
            20,
            tdest,
            size=12,
            align="left",
            color=GRAY,
            family=3,
        ),
    )
    tool_y += 60


# Right side: targets that the tools hit
TGT_X = AG_X + AG_W + 60

# DecisionStore
L.add(
    rect(TGT_X, INNER_Y, 280, 110, stroke=RED, bg=RED_BG, fill="hachure", rounded=True, width=2),
    icon_box(TGT_X + 16, INNER_Y + 16, 40, "sqlite"),
    text(TGT_X + 68, INNER_Y + 20, 220, 28, "Decision Store", size=18, align="left"),
    text(
        TGT_X + 68, INNER_Y + 48, 220, 22, "SQLite + sqlite-vec", size=12, align="left", color=GRAY
    ),
    text(
        TGT_X + 68,
        INNER_Y + 68,
        220,
        22,
        "fastembed BGE local emb.",
        size=12,
        align="left",
        color=GRAY,
    ),
    text(
        TGT_X + 68,
        INNER_Y + 86,
        220,
        22,
        "EXPLICIT  ·  MINED  ·  decay",
        size=12,
        align="left",
        color=GRAY,
    ),
)

# GitNexus
L.add(
    rect(
        TGT_X,
        INNER_Y + 130,
        280,
        100,
        stroke=GREEN,
        bg=GREEN_BG,
        fill="hachure",
        rounded=True,
        width=2,
    ),
    icon_box(TGT_X + 16, INNER_Y + 146, 40, "graph"),
    text(TGT_X + 68, INNER_Y + 150, 220, 28, "GitNexus MCP", size=18, align="left"),
    text(
        TGT_X + 68,
        INNER_Y + 178,
        220,
        22,
        "node 20  ·  npm install -g",
        size=12,
        align="left",
        color=GRAY,
    ),
    text(
        TGT_X + 68,
        INNER_Y + 196,
        220,
        22,
        "impact + callers, hop budget",
        size=12,
        align="left",
        color=GRAY,
    ),
)

# Outputs box
L.add(
    rect(
        TGT_X,
        INNER_Y + 250,
        280,
        70,
        stroke=INK,
        bg=YELLOW_BG,
        fill="hachure",
        rounded=True,
        width=2,
    ),
    icon_box(TGT_X + 16, INNER_Y + 264, 40, "comment"),
    text(TGT_X + 68, INNER_Y + 264, 220, 26, "PR comment", size=18, align="left"),
    text(
        TGT_X + 68,
        INNER_Y + 290,
        220,
        22,
        "markdown · finding markers",
        size=12,
        align="left",
        color=GRAY,
    ),
)

# Arrows: Inputs → Agent
L.add(arrow(IN_X + 220 + 8, INNER_Y + 40, AG_X - 8, INNER_Y + 130, stroke=INK))

# Arrows: each tool → target
L.add(
    arrow(AG_X + AG_W - 22, INNER_Y + 90 + 25, TGT_X - 8, INNER_Y + 55, stroke=BLUE, style="dashed")
)
L.add(
    arrow(
        AG_X + AG_W - 22, INNER_Y + 90 + 85, TGT_X - 8, INNER_Y + 180, stroke=GREEN, style="dashed"
    )
)
L.add(
    arrow(
        AG_X + AG_W - 22,
        INNER_Y + 90 + 145,
        TGT_X - 8,
        INNER_Y + 285,
        stroke=PURPLE,
        style="dashed",
    )
)


# ─── BUILT WITH (tech stack) ───────────────────────────────────────────────

TS_TOP = INNER_TOP + 480

L.add(
    text(60, TS_TOP, 1300, 36, "Built with", size=26, align="left"),
    text(
        60,
        TS_TOP + 38,
        1300,
        24,
        "every dependency is open-source · no vendored services",
        size=15,
        align="left",
        color=GRAY,
    ),
)


# Tech-stack tiles
TS_Y = TS_TOP + 90
TILE_W = 200
TILE_H = 110
TILE_GAP = 30


def tile(
    col: int, row: int, icon_name: str, name: str, sub: str, color: str = INK
) -> list[dict[str, Any]]:
    x = 80 + col * (TILE_W + TILE_GAP)
    y = TS_Y + row * (TILE_H + TILE_GAP)
    return [
        rect(x, y, TILE_W, TILE_H, stroke=color, bg="#fff", rounded=True, width=1),
        *icon_box(x + 14, y + 12, 44, icon_name, stroke=color),
        text(x + 70, y + 16, TILE_W - 80, 26, name, size=15, align="left"),
        text(x + 70, y + 42, TILE_W - 80, 20, sub, size=11, align="left", color=GRAY),
        text(x + 14, y + 70, TILE_W - 28, 36, "", size=11, align="left"),
    ]


stack = [
    # (col, row, icon, name, sub, color)
    (0, 0, "python", "Python 3.11+", "Typer CLI, pydantic"),
    (1, 0, "litellm", "litellm", "anthropic · openrouter · openai"),
    (2, 0, "claude", "Claude", "judge: Sonnet  ·  classify: Haiku"),
    (3, 0, "sqlite", "SQLite + sqlite-vec", "embedded vector store"),
    (4, 0, "fastembed", "fastembed", "BGE-small  ·  local · no API"),
    (5, 0, "github", "PyGithub", "diff fetch · PR comment post"),
    (0, 1, "mcp", "MCP protocol", "anthropic Model Context Protocol"),
    (1, 1, "node", "Node 20", "host for GitNexus"),
    (2, 1, "gitnexus", "GitNexus", "code-graph backend (optional)"),
    (3, 1, "pytest", "pytest", "236 tests · fast · offline"),
    (4, 1, "ruff", "ruff", "lint + format"),
    (5, 1, "actions", "GitHub Actions", "review · learn · release"),
]
for col, row, icon_name, name, sub in stack:
    L.add(tile(col, row, icon_name, name, sub))


# Cap rows: only 6 columns supported in current layout (width=1380). Reduce or wrap if needed.
# The current diagram targets ~1380 px wide.


# ─── FOOTER ────────────────────────────────────────────────────────────────

FOOT_Y = TS_Y + 2 * (TILE_H + TILE_GAP) + 20
L.add(
    text(
        60,
        FOOT_Y,
        1300,
        28,
        "github.com/MOHAMAD-ZUBI/Adrift  ·  pip install adrift-pr  ·  one secret in repo, every PR reviewed",
        size=16,
        align="left",
        color=GRAY,
    ),
)


# ─── Serialize ─────────────────────────────────────────────────────────────

payload: dict[str, Any] = {
    "type": "excalidraw",
    "version": 2,
    "source": "https://github.com/MOHAMAD-ZUBI/Adrift",
    "elements": L.elements,
    "appState": {
        "gridSize": 20,
        "gridStep": 5,
        "gridModeEnabled": False,
        "viewBackgroundColor": "#ffffff",
    },
    "files": {},
}


OUT = Path(__file__).resolve().parent.parent / "assets" / "architecture.excalidraw"
OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(json.dumps(payload, indent=2))
print(f"Wrote {OUT}  ({len(L.elements)} elements)")
