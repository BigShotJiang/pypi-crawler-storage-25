"""High-level indexing pipeline.

Coordinates intent sources, miners, the classifier, and the decision store
into a single ``index_repo`` operation. Kept module-level (rather than in
``cli.py``) so it can be invoked from tests or future programmatic callers.
"""

from __future__ import annotations

import logging
from collections.abc import Iterable
from dataclasses import dataclass

from adrift.mining.base import Miner
from adrift.mining.classifier import DecisionClassifier
from adrift.sources.base import IntentSource
from adrift.store.decision_store import DecisionStore

log = logging.getLogger(__name__)


@dataclass
class IndexReport:
    """Summary of an indexing run."""

    explicit_decisions: int = 0
    candidates_considered: int = 0
    candidates_accepted: int = 0
    candidates_rejected: int = 0
    errors: int = 0

    @property
    def total(self) -> int:
        return self.explicit_decisions + self.candidates_accepted


def index_repo(
    *,
    sources: Iterable[IntentSource],
    miners: Iterable[Miner],
    classifier: DecisionClassifier,
    store: DecisionStore,
) -> IndexReport:
    """Run all sources and miners; persist every decision (and classified
    candidate) to the store. Idempotent — re-runs upsert.
    """
    report = IndexReport()

    for source in sources:
        try:
            for decision in source.fetch():
                store.upsert(decision)
                report.explicit_decisions += 1
        except Exception:
            log.warning("Source %s failed", getattr(source, "name", source), exc_info=True)
            report.errors += 1

    for miner in miners:
        try:
            for candidate in miner.mine():
                report.candidates_considered += 1
                decision = classifier.classify(candidate)
                if decision is None:
                    report.candidates_rejected += 1
                    continue
                store.upsert(decision)
                report.candidates_accepted += 1
        except Exception:
            log.warning("Miner %s failed", getattr(miner, "name", miner), exc_info=True)
            report.errors += 1

    log.info(
        "Indexing complete: %d explicit, %d mined (%d/%d candidates accepted), %d errors",
        report.explicit_decisions,
        report.candidates_accepted,
        report.candidates_accepted,
        report.candidates_considered,
        report.errors,
    )
    return report
