"""Command-line entry point.

Subcommands:
    adrift review <pr-url>   [--dry-run] [--config PATH]
    adrift index  <repo-url>            [--config PATH]
    adrift learn  <pr-url>              [--config PATH]
"""

from __future__ import annotations

import logging
import os
import re
import sys
from contextlib import ExitStack
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console
from rich.logging import RichHandler

from adrift import __version__
from adrift.agentic import AgenticReviewer
from adrift.config import Config
from adrift.embedding import Embedder
from adrift.feedback import parse_comment
from adrift.feedback.processor import ApplyReport, FeedbackProcessor
from adrift.github_client import GitHubClient
from adrift.graph import SyncGitNexusClient
from adrift.indexing import index_repo
from adrift.llm import LLMClient
from adrift.mining import DecisionClassifier, MarkdownMiner, PRBundleMiner, RepoRef
from adrift.reporting import format_pr_comment, is_adrift_comment, parse_finding_markers
from adrift.retrieval import HybridRetriever, RetrieverProtocol, StructuralRetriever
from adrift.reviewer import Reviewer
from adrift.sources.adr import ADRSource
from adrift.sources.annotations import AnnotationSource
from adrift.sources.markdown import MarkdownSource
from adrift.store import DecisionStore

app = typer.Typer(
    name="adrift",
    help="Detect design-intent regressions in pull requests.",
    no_args_is_help=True,
    add_completion=False,
)

console = Console()
err_console = Console(stderr=True)


# ---------------------------------------------------------------------------
# Top-level callback
# ---------------------------------------------------------------------------


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: Annotated[bool, typer.Option("--version", help="Show version and exit.")] = False,
) -> None:
    if version:
        console.print(f"adrift {__version__}")
        raise typer.Exit()
    if ctx.invoked_subcommand is None:
        console.print(ctx.get_help())
        raise typer.Exit()


# ---------------------------------------------------------------------------
# review — Phase 1-3 reviewer
# ---------------------------------------------------------------------------


@app.command()
def review(
    pr_url: Annotated[str, typer.Argument(help="GitHub PR URL.")],
    config_path: Annotated[
        Path | None,
        typer.Option(
            "--config",
            "-c",
            help="Path to a YAML config file. Defaults to .adrift.yml in CWD.",
            exists=True,
            dir_okay=False,
            readable=True,
        ),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Print findings instead of posting a PR comment."),
    ] = False,
    mode: Annotated[
        str,
        typer.Option(
            "--mode",
            help="Reviewer mode: 'agentic' (default, LLM tool_use loop) or 'pipeline'.",
        ),
    ] = "agentic",
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Verbose logging.")] = False,
) -> None:
    """Review a pull request for design-intent regressions."""
    _setup_logging(verbose)
    log = logging.getLogger(__name__)

    if mode not in ("pipeline", "agentic"):
        err_console.print(
            f"[red]--mode must be one of 'agentic' or 'pipeline' (got {mode!r})[/red]"
        )
        raise typer.Exit(code=2)

    config = Config.load(config_path)
    gh_token = _require_env("GITHUB_TOKEN")
    _require_env("ANTHROPIC_API_KEY", "OPENAI_API_KEY", "OPENROUTER_API_KEY")

    try:
        pr_ref = GitHubClient.parse_pr_url(pr_url)
    except ValueError as e:
        err_console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=2) from e

    console.print(f"[bold]Reviewing[/bold] [cyan]{pr_ref}[/cyan]")
    repo_root = _detect_repo_root()

    with ExitStack() as stack:
        decisions, has_embeddings = _load_decisions(stack, config, repo_root)
        if not decisions:
            console.print("[yellow]No decisions available; nothing to review against.[/yellow]")
            sys.exit(0)
        console.print(f"Loaded [bold]{len(decisions)}[/bold] decision(s)")

        gh = GitHubClient(gh_token)
        diff = gh.fetch_diff(pr_ref)
        console.print(
            f"Diff: [bold]{len(diff.files)}[/bold] file(s), {diff.total_changes} change(s)"
        )

        # Trivial PRs (docs-only, version-bump-only, etc.) can't contain a
        # design-intent regression by definition. Skip the LLM round-trip
        # and post a short "skipped" comment so the reviewer sees we ran.
        if _is_trivial_diff(diff):
            console.print("[dim]Diff is markdown/version-only; skipping review.[/dim]")
            body = (
                "<!-- adrift-comment v1 -->\n"
                "## 🛡️ Adrift\n\n"
                "Skipped — this PR only touches documentation, changelog, or "
                "version metadata. Adrift only reviews changes that can contain "
                "design-intent regressions.\n"
            )
            if dry_run:
                console.print(body)
                return
            existing_id = _find_adrift_comment_id(gh, pr_ref)
            if existing_id is not None:
                gh.update_comment(pr_ref, existing_id, body)
            else:
                gh.post_comment(pr_ref, body)
            console.print(f"[green]✓ Posted skip comment on {pr_ref}[/green]")
            return

        llm = LLMClient(model=config.judge_model, max_tokens=4096)

        # If the user asked for agentic but there's no populated decision
        # store (the agent's primary tool needs one), fall back to pipeline
        # so first-time users on a fresh repo still get a working review.
        effective_mode = mode
        store_path = repo_root / config.store.path
        if mode == "agentic" and not store_path.exists():
            console.print(
                "[yellow]Agentic mode requested but no decision store at "
                f"{store_path}; falling back to pipeline mode. Run "
                "`adrift index` to enable agentic on the next run.[/yellow]"
            )
            effective_mode = "pipeline"

        if effective_mode == "agentic":
            console.print("[dim]Reviewer mode: [bold]agentic[/bold] (LLM tool_use loop)[/dim]")
            try:
                pr_title, pr_body = gh.fetch_pr_metadata(pr_ref)
            except RuntimeError as e:
                log.warning("Failed to fetch PR metadata; reviewing without author intent: %s", e)
                pr_title, pr_body = None, None
            findings = _run_agentic_review(
                stack=stack,
                config=config,
                repo_root=repo_root,
                llm=llm,
                diff=diff,
                pr_title=pr_title,
                pr_description=pr_body,
            )
        else:
            if mode == "agentic":
                log.debug("agentic requested, running pipeline as fallback")
            else:
                console.print("[dim]Reviewer mode: [bold]pipeline[/bold][/dim]")
            retriever = _build_retriever(stack, config, has_embeddings)
            reviewer = Reviewer(
                llm=llm,
                retriever=retriever,
                min_confidence=config.min_confidence,
                max_findings=config.max_findings_per_pr,
            )
            findings = reviewer.review(diff, decisions)

    body = format_pr_comment(findings)
    console.print()
    console.print(body)
    console.print()

    if dry_run:
        console.print("[yellow](dry-run; comment not posted)[/yellow]")
        return

    # Always post — even clean PRs get a visible "no regressions" confirmation,
    # matching the CodeRabbit/Cubic UX. Update the existing Adrift comment if
    # one is already on the PR (e.g. from a prior push to the same branch)
    # so we don't spam the conversation on every `synchronize`.
    existing_id = _find_adrift_comment_id(gh, pr_ref)
    if existing_id is not None:
        gh.update_comment(pr_ref, existing_id, body)
        console.print(f"[green]✓ Updated review comment on {pr_ref}[/green]")
    else:
        gh.post_comment(pr_ref, body)
        console.print(f"[green]✓ Posted review comment on {pr_ref}[/green]")


# ---------------------------------------------------------------------------
# index — Phase 3 backfill / mining
# ---------------------------------------------------------------------------


_REPO_URL_RE = re.compile(r"^https?://github\.com/(?P<owner>[^/]+)/(?P<repo>[^/]+?)(?:\.git)?/?$")


@app.command()
def index(
    repo_url: Annotated[
        str, typer.Argument(help="GitHub repo URL, e.g. https://github.com/owner/repo")
    ],
    config_path: Annotated[
        Path | None,
        typer.Option(
            "--config",
            "-c",
            help="Path to YAML config.",
            exists=True,
            dir_okay=False,
            readable=True,
        ),
    ] = None,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Verbose logging.")] = False,
) -> None:
    """Backfill the decision store from a repo's ADRs + PR history.

    Reads ADRs from the local checkout, then walks the GitHub PR history,
    classifies each PR description as decision-bearing or not, and persists
    accepted decisions to the local store (default: ``.adrift/decisions.db``).
    """
    _setup_logging(verbose)
    log = logging.getLogger(__name__)

    config = Config.load(config_path)
    gh_token = _require_env("GITHUB_TOKEN")
    _require_env("ANTHROPIC_API_KEY", "OPENAI_API_KEY", "OPENROUTER_API_KEY")

    m = _REPO_URL_RE.match(repo_url.strip())
    if not m:
        err_console.print(f"[red]Not a GitHub repo URL: {repo_url!r}[/red]")
        raise typer.Exit(code=2)
    repo_ref = RepoRef(owner=m["owner"], repo=m["repo"])

    repo_root = _detect_repo_root()
    store_path = repo_root / config.store.path

    console.print(f"[bold]Indexing[/bold] [cyan]{repo_ref.full_name()}[/cyan] → {store_path}")
    log.info("Embedding model: %s", config.store.embedding_model)

    embedder = Embedder(model_name=config.store.embedding_model)
    classify_llm = LLMClient(model=config.classify_model, max_tokens=512)
    classifier = DecisionClassifier(
        llm=classify_llm,
        min_confidence=config.mining.classify_min_confidence,
    )

    adr_paths = [repo_root / p for p in config.adr_paths]
    sources = [
        ADRSource(paths=adr_paths),
        AnnotationSource(roots=[repo_root]),
        MarkdownSource(root=repo_root),
    ]

    miners: list = [MarkdownMiner(root=repo_root)]
    if config.mining.enabled:
        miners.append(
            PRBundleMiner(
                token=gh_token,
                repo=repo_ref,
                limit=config.mining.pr_limit,
                state=config.mining.pr_state,
                min_bundle_chars=config.mining.min_pr_body_chars,
            )
        )

    with DecisionStore(store_path, embedder) as store:
        report = index_repo(
            sources=sources,
            miners=miners,
            classifier=classifier,
            store=store,
        )

    console.print()
    console.print(f"[green]✓[/green] Indexed [bold]{report.total}[/bold] decision(s)")
    console.print(
        f"   {report.explicit_decisions} from explicit sources (ADRs / @decision / CLAUDE.md)"
    )
    console.print(
        f"   {report.candidates_accepted} from mined sources (markdown + PR bundles) "
        f"— {report.candidates_accepted}/{report.candidates_considered} candidates accepted"
    )
    if report.errors:
        console.print(f"[yellow]   {report.errors} source/miner error(s)[/yellow]")


# ---------------------------------------------------------------------------
# index-pr — incremental indexing for one PR (per-PR learning in CI)
# ---------------------------------------------------------------------------


@app.command(name="index-pr")
def index_pr(
    pr_url: Annotated[str, typer.Argument(help="GitHub PR URL.")],
    config_path: Annotated[
        Path | None,
        typer.Option(
            "--config",
            "-c",
            help="Path to YAML config.",
            exists=True,
            dir_okay=False,
            readable=True,
        ),
    ] = None,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Verbose logging.")] = False,
) -> None:
    """Index a single PR's description into the decision store.

    Used as a post-review step in the GitHub Action so each new PR
    incrementally adds to the store instead of relying on a nightly batch
    job. Reads only the PR's title + body via the GitHub API, runs the
    same strict-precision classifier used by ``adrift index``, and upserts
    the result if accepted. No-op (logs and exits cleanly) when:

    - the PR body is too short to be a useful candidate,
    - the classifier rejects it as not a decision,
    - or the store doesn't exist yet (run ``adrift index`` first to bootstrap).
    """
    _setup_logging(verbose)
    log = logging.getLogger(__name__)

    config = Config.load(config_path)
    gh_token = _require_env("GITHUB_TOKEN")
    _require_env("ANTHROPIC_API_KEY", "OPENAI_API_KEY", "OPENROUTER_API_KEY")

    try:
        pr_ref = GitHubClient.parse_pr_url(pr_url)
    except ValueError as e:
        err_console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=2) from e

    repo_root = _detect_repo_root()
    store_path = repo_root / config.store.path
    if not store_path.exists():
        console.print(
            f"[yellow]No decision store at {store_path}; nothing to incrementally update. "
            "Run `adrift index` once to bootstrap.[/yellow]"
        )
        return

    console.print(f"[bold]Indexing PR[/bold] [cyan]{pr_ref}[/cyan] → {store_path}")

    embedder = Embedder(model_name=config.store.embedding_model)
    classify_llm = LLMClient(model=config.classify_model, max_tokens=512)
    classifier = DecisionClassifier(
        llm=classify_llm, min_confidence=config.mining.classify_min_confidence
    )
    miner = PRBundleMiner(
        token=gh_token,
        repo=RepoRef(owner=pr_ref.owner, repo=pr_ref.repo),
        min_bundle_chars=config.mining.min_pr_body_chars,
    )

    candidate = miner.mine_one(pr_ref.number)
    if candidate is None:
        console.print(
            f"[dim]PR {pr_ref} skipped: bundle too thin for a meaningful candidate.[/dim]"
        )
        return

    log.info("Classifying %s", candidate.source)
    decision = classifier.classify(candidate)
    if decision is None:
        console.print(f"[dim]PR {pr_ref} classified as non-decision; store unchanged.[/dim]")
        return

    with DecisionStore(store_path, embedder) as store:
        store.upsert(decision)

    console.print(
        f"[green]✓[/green] Added 1 decision to store: "
        f"[bold]{decision.title[:80]}[/bold] (weight={decision.weight:.2f})"
    )


# ---------------------------------------------------------------------------
# learn — Phase 4 feedback ingestion
# ---------------------------------------------------------------------------


@app.command()
def learn(
    pr_url: Annotated[str, typer.Argument(help="GitHub PR URL.")],
    config_path: Annotated[
        Path | None,
        typer.Option(
            "--config",
            "-c",
            help="Path to YAML config.",
            exists=True,
            dir_okay=False,
            readable=True,
        ),
    ] = None,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="Verbose logging.")] = False,
) -> None:
    """Read reviewer feedback from a PR and update the local decision store.

    Scans the PR's issue comments for ``/adrift accept|override|dismiss|flag``
    slash commands and applies them: reinforcing decisions, recording overrides
    as supersessions, and creating new decisions from manual flags.

    Intended to run on each PR after the review comment has been posted —
    ideally triggered automatically by a GitHub Action on ``issue_comment``
    events.
    """
    _setup_logging(verbose)
    log = logging.getLogger(__name__)

    config = Config.load(config_path)
    gh_token = _require_env("GITHUB_TOKEN")

    try:
        pr_ref = GitHubClient.parse_pr_url(pr_url)
    except ValueError as e:
        err_console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=2) from e

    console.print(f"[bold]Learning from[/bold] [cyan]{pr_ref}[/cyan]")

    repo_root = _detect_repo_root()
    store_path = repo_root / config.store.path
    if not store_path.exists():
        err_console.print(
            f"[red]No decision store at {store_path}. Run `adrift index` first.[/red]"
        )
        raise typer.Exit(code=2)

    gh = GitHubClient(gh_token)
    comments = gh.list_issue_comments(pr_ref)
    log.info("Fetched %d comment(s) on %s", len(comments), pr_ref)

    # Build {finding_number: decision_id} from the most recent Adrift comment.
    finding_to_decision = _latest_finding_map(comments)
    if not finding_to_decision:
        console.print(
            "[yellow]No prior Adrift review comment found on this PR; "
            "/adrift accept|override|dismiss N commands cannot be resolved. "
            "Only /adrift flag commands will be processed.[/yellow]"
        )

    # Collect commands from comments other than our bot comments.
    all_commands = []
    for c in comments:
        if is_adrift_comment(c.body):
            continue
        for cmd in parse_comment(c.body):
            all_commands.append((cmd, c.author))

    if not all_commands:
        console.print("No /adrift slash commands found. Nothing to learn.")
        return

    console.print(f"Found [bold]{len(all_commands)}[/bold] feedback command(s)")

    embedder = Embedder(model_name=config.store.embedding_model)
    total = ApplyReport()
    with DecisionStore(store_path, embedder) as store:
        processor = FeedbackProcessor(store)
        # Group commands by reviewer so each feedback record carries its author.
        from collections import defaultdict

        by_author: dict[str, list] = defaultdict(list)
        for cmd, author in all_commands:
            by_author[author].append(cmd)

        for author, cmds in by_author.items():
            report = processor.apply(
                cmds,
                finding_to_decision=finding_to_decision,
                source_pr=pr_url,
                reviewer=author,
            )
            total.accepted += report.accepted
            total.overridden += report.overridden
            total.dismissed += report.dismissed
            total.flagged += report.flagged
            total.skipped += report.skipped

    console.print()
    console.print(f"[green]✓[/green] Applied [bold]{total.total}[/bold] signal(s):")
    console.print(f"   accepted:   {total.accepted}")
    console.print(f"   overridden: {total.overridden}")
    console.print(f"   dismissed:  {total.dismissed}")
    console.print(f"   flagged:    {total.flagged}")
    if total.skipped:
        console.print(f"[yellow]   skipped:    {total.skipped}[/yellow]")


def _latest_finding_map(comments) -> dict[int, str]:
    """Return finding markers from the most recent Adrift comment on the PR."""
    for c in reversed(comments):
        if is_adrift_comment(c.body):
            return parse_finding_markers(c.body)
    return {}


def _find_adrift_comment_id(gh: GitHubClient, pr_ref) -> int | None:
    """Return the id of the most-recent Adrift-authored comment on the PR.

    Used to update the existing comment on subsequent runs instead of posting
    a new one for every push.
    """
    try:
        comments = gh.list_issue_comments(pr_ref)
    except RuntimeError:
        # Can't list comments (auth/permissions) — fall back to posting new.
        return None
    for c in reversed(comments):
        if is_adrift_comment(c.body):
            return c.id
    return None


def _run_agentic_review(
    *,
    stack: ExitStack,
    config: Config,
    repo_root: Path,
    llm: LLMClient,
    diff,
    pr_title: str | None = None,
    pr_description: str | None = None,
) -> list:
    """Run the Phase 5 agentic reviewer.

    Requires a decision store (the agent's primary tool is ``search_decisions``).
    Optionally wires in GitNexus if configured for structural impact queries.
    The PR title + description are passed through to the agent so it can
    weigh the author's stated intent.
    """
    store_path = repo_root / config.store.path
    if not store_path.exists():
        err_console.print(
            "[red]--mode agentic requires a populated decision store.[/red] "
            f"Run `adrift index` first to create {store_path}."
        )
        raise typer.Exit(code=2)

    embedder = Embedder(model_name=config.store.embedding_model)
    store = stack.enter_context(DecisionStore(store_path, embedder))
    graph = _maybe_open_gitnexus(stack, config)

    reviewer = AgenticReviewer(
        llm=llm,
        store=store,
        graph=graph,
        repo_root=repo_root,
        min_confidence=config.min_confidence,
        max_findings=config.max_findings_per_pr,
    )
    return reviewer.review(diff, pr_title=pr_title, pr_description=pr_description)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


# Path patterns whose changes are by-definition not design-intent regressions.
# Used to skip review work on docs / changelog / lockfile-only PRs.
_TRIVIAL_PATH_SUFFIXES = (
    ".md",
    ".mdx",
    ".rst",
    ".txt",
)
_TRIVIAL_PATH_NAMES = frozenset(
    {
        "CHANGELOG",
        "CHANGELOG.md",
        "RELEASES.md",
        "LICENSE",
        ".gitignore",
        ".gitattributes",
        ".editorconfig",
        ".prettierrc",
        ".prettierrc.json",
        "uv.lock",
        "package-lock.json",
        "yarn.lock",
        "poetry.lock",
        "Pipfile.lock",
        "Cargo.lock",
    }
)


def _is_trivial_path(path: str) -> bool:
    name = path.rsplit("/", 1)[-1]
    if name in _TRIVIAL_PATH_NAMES:
        return True
    lower = path.lower()
    if lower.endswith(_TRIVIAL_PATH_SUFFIXES):
        return True
    # GitHub issue/PR templates and editor config.
    return path.startswith(".github/ISSUE_TEMPLATE/") or path.startswith(
        ".github/PULL_REQUEST_TEMPLATE"
    )


def _is_trivial_diff(diff) -> bool:
    """True iff every changed file is documentation, changelog, or lockfile.

    Empty diffs aren't trivial — they're empty, which the reviewer handles
    separately.
    """
    if not diff.files:
        return False
    return all(_is_trivial_path(f.path) for f in diff.files)


def _setup_logging(verbose: bool) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(message)s",
        datefmt="[%X]",
        handlers=[
            RichHandler(
                console=err_console,
                rich_tracebacks=verbose,
                show_path=verbose,
                show_time=False,
            )
        ],
    )
    if not verbose:
        for noisy in ("litellm", "httpx", "urllib3", "github", "fastembed"):
            logging.getLogger(noisy).setLevel(logging.WARNING)


def _require_env(*names: str) -> str:
    for name in names:
        value = os.environ.get(name)
        if value:
            return value
    err_console.print(
        f"[red]Missing required environment variable:[/red] one of {', '.join(names)}"
    )
    raise typer.Exit(code=2)


def _detect_repo_root() -> Path:
    cwd = Path.cwd().resolve()
    for candidate in [cwd, *cwd.parents]:
        if (candidate / ".git").exists():
            return candidate
    return cwd


def _load_decisions(stack: ExitStack, config: Config, repo_root: Path) -> tuple[list, bool]:
    """Return (decisions, has_embeddings).

    Prefers the decision store when present (Phase 3 path: store contains
    both ADRs and mined decisions, with embeddings). Falls back to reading
    ADRs from disk (Phase 1 path).
    """
    store_path = repo_root / config.store.path
    if store_path.exists():
        try:
            embedder = Embedder(model_name=config.store.embedding_model)
            store = stack.enter_context(DecisionStore(store_path, embedder))
            decisions = store.all(with_embeddings=True)
            if decisions:
                console.print(f"[dim]Loaded from store at {store_path}[/dim]")
                return decisions, True
        except Exception as e:
            err_console.print(
                f"[yellow]Failed to open decision store ({e}); falling back to ADRs on disk[/yellow]"
            )

    adr_paths = [repo_root / p for p in config.adr_paths]
    decisions = ADRSource(paths=adr_paths).fetch()
    return decisions, False


def _build_retriever(
    stack: ExitStack, config: Config, has_embeddings: bool
) -> RetrieverProtocol | None:
    """Build the retriever appropriate for what's available.

    Decision matrix:
      - Embeddings AND GitNexus → HybridRetriever (best precision)
      - Embeddings only         → HybridRetriever with no graph
      - GitNexus only           → StructuralRetriever (Phase 2 behavior)
      - Neither                 → None (Phase 1 behavior: judge all)
    """
    graph = _maybe_open_gitnexus(stack, config)

    if has_embeddings:
        embedder = Embedder(model_name=config.store.embedding_model)
        return HybridRetriever(
            graph=graph,
            embedder=embedder,
            structural_weight=config.retriever.structural_weight,
            embedding_weight=config.retriever.embedding_weight,
            tier_weight=config.retriever.tier_weight,
            min_score=config.retriever.min_score,
            top_k=config.retriever.top_k,
        )

    if graph is not None:
        return StructuralRetriever(graph=graph, min_score=config.min_retrieval_score)

    return None


def _maybe_open_gitnexus(stack: ExitStack, config: Config) -> SyncGitNexusClient | None:
    if not config.gitnexus.enabled:
        return None
    try:
        client = stack.enter_context(
            SyncGitNexusClient(config.gitnexus.command, config.gitnexus.args)
        )
        console.print("[green]✓[/green] GitNexus MCP connected")
        return client
    except FileNotFoundError:
        err_console.print(
            f"[yellow]GitNexus binary not found ({config.gitnexus.command}); "
            "running without structural retrieval[/yellow]"
        )
    except Exception as e:
        err_console.print(
            f"[yellow]GitNexus failed to start ({e}); running without structural retrieval[/yellow]"
        )
    return None


if __name__ == "__main__":
    app()
