"""Thin wrapper around litellm for multi-provider LLM access.

Kept narrow so the rest of the codebase doesn't import litellm directly —
makes it easy to swap providers or mock in tests.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from litellm import completion

log = logging.getLogger(__name__)


@dataclass
class LLMResponse:
    content: str
    model: str
    input_tokens: int = 0
    output_tokens: int = 0


@dataclass
class ToolCallRequest:
    """A single tool call the LLM is requesting (Phase 5 agentic mode)."""

    id: str
    name: str
    arguments_json: str  # raw JSON string; caller parses


@dataclass
class LLMToolResponse:
    """Result of an LLM round that may include tool-call requests.

    ``tool_calls`` is empty when the LLM decided to finalize without calling
    any tools — the agent loop terminates on that signal.
    """

    content: str
    tool_calls: list[ToolCallRequest]
    model: str
    input_tokens: int = 0
    output_tokens: int = 0


class LLMClient:
    """Single-shot completion client. Phase 5 adds a tool-use round-trip path
    used by the agentic reviewer; the simple ``complete`` path is unchanged.
    """

    def __init__(self, model: str, *, temperature: float = 0.0, max_tokens: int = 1024):
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens

    def complete(self, prompt: str, *, system: str | None = None) -> LLMResponse:
        """Run a single completion. Raises on transport errors; caller decides what to do."""
        messages: list[dict[str, Any]] = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        log.debug("LLM call: model=%s prompt_chars=%d", self.model, len(prompt))
        response = completion(
            model=self.model,
            messages=messages,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
        )

        choice = response.choices[0]  # type: ignore[union-attr]
        content = (choice.message.content or "").strip()
        usage = getattr(response, "usage", None)
        return LLMResponse(
            content=content,
            model=self.model,
            input_tokens=getattr(usage, "prompt_tokens", 0) if usage else 0,
            output_tokens=getattr(usage, "completion_tokens", 0) if usage else 0,
        )

    def complete_with_tools(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]],
        *,
        system: str | None = None,
        max_tokens: int | None = None,
    ) -> LLMToolResponse:
        """Run one LLM round with tools available.

        The caller owns the message history; this method just runs one turn
        and parses the response into ``LLMToolResponse``. Used inside the
        agentic loop, which iterates by calling this method repeatedly until
        the LLM stops requesting tool calls.
        """
        full_messages: list[dict[str, Any]] = []
        if system:
            full_messages.append({"role": "system", "content": system})
        full_messages.extend(messages)

        log.debug(
            "LLM tool-call round: model=%s msgs=%d tools=%d",
            self.model,
            len(full_messages),
            len(tools),
        )
        response = completion(
            model=self.model,
            messages=full_messages,
            tools=tools,
            temperature=self.temperature,
            max_tokens=max_tokens or self.max_tokens,
        )

        choice = response.choices[0]  # type: ignore[union-attr]
        message = choice.message
        content = (getattr(message, "content", None) or "").strip()
        raw_tool_calls = getattr(message, "tool_calls", None) or []

        tool_calls = [
            ToolCallRequest(
                id=tc.id,
                name=tc.function.name,
                arguments_json=tc.function.arguments or "{}",
            )
            for tc in raw_tool_calls
        ]

        usage = getattr(response, "usage", None)
        return LLMToolResponse(
            content=content,
            tool_calls=tool_calls,
            model=self.model,
            input_tokens=getattr(usage, "prompt_tokens", 0) if usage else 0,
            output_tokens=getattr(usage, "completion_tokens", 0) if usage else 0,
        )
