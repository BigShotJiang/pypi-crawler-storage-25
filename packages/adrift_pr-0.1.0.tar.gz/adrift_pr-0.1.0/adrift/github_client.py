"""GitHub API access for fetching PR diffs, posting comments, and reading
back reviewer feedback on previous comments."""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from datetime import datetime

from github import Auth, Github
from github.GithubException import GithubException

from adrift.models import Diff, DiffFile

log = logging.getLogger(__name__)


_PR_URL_RE = re.compile(
    r"^https?://github\.com/(?P<owner>[^/]+)/(?P<repo>[^/]+)/pull/(?P<number>\d+)"
)


@dataclass(frozen=True)
class PullRequestRef:
    owner: str
    repo: str
    number: int

    def full_name(self) -> str:
        return f"{self.owner}/{self.repo}"

    def url(self) -> str:
        return f"https://github.com/{self.full_name()}/pull/{self.number}"

    def __str__(self) -> str:
        return f"{self.full_name()}#{self.number}"


@dataclass(frozen=True)
class IssueComment:
    """A single issue comment on a PR. Phase 4 ``learn`` reads these."""

    id: int
    body: str
    author: str
    created_at: datetime


class GitHubClient:
    """Fetches PR diffs, posts review comments, reads back reviewer comments."""

    def __init__(self, token: str):
        if not token:
            raise ValueError("GitHub token is required")
        self._gh = Github(auth=Auth.Token(token))

    @staticmethod
    def parse_pr_url(url: str) -> PullRequestRef:
        m = _PR_URL_RE.match(url.strip())
        if not m:
            raise ValueError(f"Not a GitHub PR URL: {url!r}")
        return PullRequestRef(
            owner=m["owner"],
            repo=m["repo"],
            number=int(m["number"]),
        )

    def fetch_diff(self, ref: PullRequestRef) -> Diff:
        try:
            repo = self._gh.get_repo(ref.full_name())
            pr = repo.get_pull(ref.number)
        except GithubException as e:
            raise RuntimeError(f"Failed to fetch PR {ref}: {e}") from e

        files: list[DiffFile] = []
        for f in pr.get_files():
            files.append(
                DiffFile(
                    path=f.filename,
                    additions=f.additions,
                    deletions=f.deletions,
                    patch=f.patch or "",
                )
            )
        log.info("Fetched diff for %s: %d files", ref, len(files))
        return Diff(files=files)

    def fetch_pr_metadata(self, ref: PullRequestRef) -> tuple[str, str]:
        """Return ``(title, body)`` for a PR. Body may be empty.

        Used by the agentic reviewer to weigh the author's stated intent
        when deciding whether a diff is a regression or an explicit
        decision the author is making.
        """
        try:
            repo = self._gh.get_repo(ref.full_name())
            pr = repo.get_pull(ref.number)
        except GithubException as e:
            raise RuntimeError(f"Failed to fetch PR metadata for {ref}: {e}") from e
        return (pr.title or "", pr.body or "")

    def post_comment(self, ref: PullRequestRef, body: str) -> None:
        try:
            repo = self._gh.get_repo(ref.full_name())
            pr = repo.get_pull(ref.number)
            pr.create_issue_comment(body)
        except GithubException as e:
            raise RuntimeError(f"Failed to post comment on {ref}: {e}") from e
        log.info("Posted review comment on %s", ref)

    def list_issue_comments(self, ref: PullRequestRef) -> list[IssueComment]:
        """Return all issue comments on the PR, oldest first."""
        try:
            repo = self._gh.get_repo(ref.full_name())
            issue = repo.get_issue(ref.number)
            raw_comments = list(issue.get_comments())
        except GithubException as e:
            raise RuntimeError(f"Failed to list comments on {ref}: {e}") from e

        comments: list[IssueComment] = []
        for c in raw_comments:
            comments.append(
                IssueComment(
                    id=c.id,
                    body=c.body or "",
                    author=(c.user.login if c.user else "unknown"),
                    created_at=c.created_at,
                )
            )
        return comments

    def update_comment(self, ref: PullRequestRef, comment_id: int, body: str) -> None:
        """Edit an existing issue comment by id.

        Used by the reviewer to keep one comment per PR up-to-date across
        ``synchronize`` events, instead of posting a new comment per push.
        """
        try:
            repo = self._gh.get_repo(ref.full_name())
            issue = repo.get_issue(ref.number)
            comment = issue.get_comment(comment_id)
            comment.edit(body)
        except GithubException as e:
            raise RuntimeError(f"Failed to update comment {comment_id} on {ref}: {e}") from e
        log.info("Updated existing Adrift comment %d on %s", comment_id, ref)
