"""Parse ``/adrift <verb>`` slash commands out of free-form PR comment text.

Recognized forms (case-insensitive, leading whitespace allowed):

    /adrift accept N
    /adrift override N <reason>
    /adrift dismiss N
    /adrift flag <description of missed regression>

``N`` is the 1-based finding number from the bot's previous PR comment.
``<reason>`` and ``<description>`` run to end-of-line (or end-of-message).

Multiple commands per comment are supported (one per line). Anything else
is ignored — comments can mix prose with commands freely.
"""

from __future__ import annotations

import re

from adrift.feedback.models import FeedbackSignal, ParsedCommand

# Matches ``/adrift <verb>`` plus optional arguments to end-of-line.
# Verbs: accept, override, dismiss, flag.
_COMMAND_RE = re.compile(
    r"""
    ^\s*                              # optional leading whitespace
    /adrift                           # slash command prefix
    \s+
    (?P<verb>accept|override|dismiss|flag)
    \b
    (?:\s+(?P<rest>.*?))?             # optional rest of the line
    \s*$
    """,
    re.IGNORECASE | re.VERBOSE | re.MULTILINE,
)

_LEADING_NUMBER_RE = re.compile(r"^\s*#?\s*(?P<n>\d+)\b\s*(?P<rest>.*)$", re.DOTALL)


def parse_comment(text: str) -> list[ParsedCommand]:
    """Extract every ``/adrift ...`` command from a comment body. Order preserved."""
    commands: list[ParsedCommand] = []
    if not text:
        return commands

    for match in _COMMAND_RE.finditer(text):
        verb = match.group("verb").lower()
        rest = (match.group("rest") or "").strip()
        signal = FeedbackSignal(verb)

        if signal is FeedbackSignal.FLAG:
            # FLAG takes a free-form body, no finding number.
            commands.append(ParsedCommand(signal=signal, body=rest))
            continue

        # ACCEPT / OVERRIDE / DISMISS take a finding number then optional reason.
        num_match = _LEADING_NUMBER_RE.match(rest)
        if not num_match:
            # No finding number — skip; we don't apply commands to "all findings"
            # implicitly (too easy to misuse).
            continue
        finding_number = int(num_match.group("n"))
        reason = num_match.group("rest").strip()
        commands.append(ParsedCommand(signal=signal, finding_number=finding_number, reason=reason))

    return commands
