"""Data models for the Phase 4 feedback loop."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel, Field


class FeedbackSignal(StrEnum):
    """The kind of signal a reviewer expressed on a finding or a PR."""

    ACCEPT = "accept"  # finding was correct; reinforce the decision behind it
    OVERRIDE = "override"  # finding was wrong; supersede the decision with a new one
    FLAG = "flag"  # missed regression; create a brand-new decision
    DISMISS = "dismiss"  # finding was wrong but no replacement; demote silently


class ParsedCommand(BaseModel):
    """A single ``/adrift <verb> ...`` invocation extracted from comment text."""

    signal: FeedbackSignal
    finding_number: int | None = None  # 1-based, references the comment's findings list
    reason: str = ""  # for OVERRIDE: the new design rationale
    body: str = ""  # for FLAG: the missed-regression description


class Feedback(BaseModel):
    """A persisted feedback record (Phase 4 ``decision_feedback`` table)."""

    id: str
    decision_id: str | None = None  # NULL only for FLAG before classifier promotes it
    finding_id: str | None = None
    signal: FeedbackSignal
    reason: str = ""
    source_pr: str
    reviewer: str = ""
    created_at: datetime = Field(default_factory=datetime.now)
