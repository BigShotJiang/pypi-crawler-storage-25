"""Apply ``ParsedCommand`` feedback to the decision store.

Each command translates to specific store mutations:

- ACCEPT   → ``store.adjust_weight(+0.1)`` on the decision, record feedback
- OVERRIDE → create a new EXPLICIT decision with the reviewer's rationale,
             mark the original superseded_by the new one, record feedback
- DISMISS  → ``store.adjust_weight(-0.2)`` (no replacement), record feedback
- FLAG     → create a new MINED decision from the body, record feedback
"""

from __future__ import annotations

import hashlib
import logging
import uuid
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime

from adrift.feedback.models import Feedback, FeedbackSignal, ParsedCommand
from adrift.models import Decision, DecisionTier
from adrift.store.decision_store import DecisionStore

log = logging.getLogger(__name__)


# Weight deltas. Picked conservatively so a single signal doesn't flip a
# decision's standing on its own — accumulated feedback is what shifts things.
ACCEPT_DELTA = 0.1
DISMISS_DELTA = -0.2


@dataclass
class ApplyReport:
    accepted: int = 0
    overridden: int = 0
    dismissed: int = 0
    flagged: int = 0
    skipped: int = 0  # commands that referenced unknown findings, etc.

    @property
    def total(self) -> int:
        return self.accepted + self.overridden + self.dismissed + self.flagged


class FeedbackProcessor:
    """Coordinates parsed feedback commands → store mutations.

    The caller supplies a mapping from ``finding_number`` (1-based) to the
    decision_id behind that finding. The processor uses this to resolve
    ACCEPT / OVERRIDE / DISMISS targets.
    """

    def __init__(self, store: DecisionStore):
        self.store = store

    def apply(
        self,
        commands: list[ParsedCommand],
        *,
        finding_to_decision: Mapping[int, str],
        source_pr: str,
        reviewer: str = "",
    ) -> ApplyReport:
        report = ApplyReport()
        for cmd in commands:
            try:
                applied = self._apply_one(
                    cmd,
                    finding_to_decision=finding_to_decision,
                    source_pr=source_pr,
                    reviewer=reviewer,
                )
            except Exception:
                log.warning("Failed to apply feedback command %s", cmd, exc_info=True)
                report.skipped += 1
                continue
            if applied is None:
                report.skipped += 1
            elif applied is FeedbackSignal.ACCEPT:
                report.accepted += 1
            elif applied is FeedbackSignal.OVERRIDE:
                report.overridden += 1
            elif applied is FeedbackSignal.DISMISS:
                report.dismissed += 1
            elif applied is FeedbackSignal.FLAG:
                report.flagged += 1
        return report

    # --- internals ----------------------------------------------------------

    def _apply_one(
        self,
        cmd: ParsedCommand,
        *,
        finding_to_decision: Mapping[int, str],
        source_pr: str,
        reviewer: str,
    ) -> FeedbackSignal | None:
        if cmd.signal is FeedbackSignal.FLAG:
            return self._apply_flag(cmd, source_pr=source_pr, reviewer=reviewer)

        # The other three need a finding → decision lookup.
        if cmd.finding_number is None:
            log.info("Skipping %s: no finding number", cmd.signal.value)
            return None
        decision_id = finding_to_decision.get(cmd.finding_number)
        if decision_id is None:
            log.info(
                "Skipping %s #%d: no such finding in this PR's review",
                cmd.signal.value,
                cmd.finding_number,
            )
            return None
        finding_id = _finding_id(source_pr, decision_id, cmd.finding_number)

        if cmd.signal is FeedbackSignal.ACCEPT:
            self.store.adjust_weight(decision_id, ACCEPT_DELTA)
        elif cmd.signal is FeedbackSignal.DISMISS:
            self.store.adjust_weight(decision_id, DISMISS_DELTA)
        elif cmd.signal is FeedbackSignal.OVERRIDE:
            new_decision = self._build_override_decision(
                old_decision_id=decision_id, reason=cmd.reason, source_pr=source_pr
            )
            self.store.supersede(old_decision_id=decision_id, new_decision=new_decision)

        self.store.add_feedback(
            Feedback(
                id=str(uuid.uuid4()),
                decision_id=decision_id,
                finding_id=finding_id,
                signal=cmd.signal,
                reason=cmd.reason,
                source_pr=source_pr,
                reviewer=reviewer,
                created_at=datetime.now(),
            )
        )
        return cmd.signal

    def _apply_flag(
        self,
        cmd: ParsedCommand,
        *,
        source_pr: str,
        reviewer: str,
    ) -> FeedbackSignal | None:
        body = cmd.body.strip()
        if len(body) < 20:
            log.info("Skipping FLAG: body too short to be a useful decision")
            return None
        new_decision = Decision(
            id=f"flagged-{_short_hash(body)}",
            title=_title_from_body(body),
            body=body,
            source=f"{source_pr}#flag-by-{reviewer or 'anon'}",
            tier=DecisionTier.MINED,
            created_at=datetime.now(),
            weight=1.0,
        )
        self.store.upsert(new_decision)
        self.store.add_feedback(
            Feedback(
                id=str(uuid.uuid4()),
                decision_id=new_decision.id,
                finding_id=None,
                signal=FeedbackSignal.FLAG,
                reason=body,
                source_pr=source_pr,
                reviewer=reviewer,
                created_at=datetime.now(),
            )
        )
        return FeedbackSignal.FLAG

    def _build_override_decision(
        self,
        *,
        old_decision_id: str,
        reason: str,
        source_pr: str,
    ) -> Decision:
        old = self.store.get(old_decision_id)
        title = f"Override of {old.title}" if old is not None else f"Override of {old_decision_id}"
        if old is not None:
            body = (
                f"{reason}\n\n---\n\n"
                f"Supersedes prior decision: {old.title}\n"
                f"Original body:\n\n{old.body}"
            )
        else:
            body = reason
        return Decision(
            id=f"override-{_short_hash(f'{old_decision_id}|{reason}')}",
            title=title[:200] or f"Override of {old_decision_id}",
            body=body,
            source=f"{source_pr}#override",
            tier=DecisionTier.EXPLICIT,
            created_at=datetime.now(),
            weight=1.0,
        )


def _short_hash(text: str) -> str:
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:12]


def _finding_id(source_pr: str, decision_id: str, finding_number: int) -> str:
    raw = f"{source_pr}|{decision_id}|{finding_number}"
    return _short_hash(raw)


def _title_from_body(body: str) -> str:
    first_line = body.strip().splitlines()[0]
    return first_line[:120]
