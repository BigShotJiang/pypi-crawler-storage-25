"""Phase 4 — reviewer feedback loop.

Public surface:

- ``Feedback`` / ``FeedbackSignal`` — what the reviewer expressed (no store
  dependency; safe to import widely).
- ``parse_comment(text)`` → list[``ParsedCommand``] — extract slash commands
  (``/adrift accept``, ``/adrift override``, ``/adrift flag``) from a PR comment.

``FeedbackProcessor`` lives in ``adrift.feedback.processor`` and is imported
directly by the CLI. It's intentionally NOT re-exported here, because doing
so creates an import cycle: the processor imports ``DecisionStore``, and
the store imports ``Feedback`` from this package. Eagerly importing the
processor would make ``import adrift.feedback`` pull in the store, which
in turn re-enters this module.
"""

from adrift.feedback.models import Feedback, FeedbackSignal, ParsedCommand
from adrift.feedback.parser import parse_comment

__all__ = [
    "Feedback",
    "FeedbackSignal",
    "ParsedCommand",
    "parse_comment",
]
