"""Core data models shared across the system."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel, Field


class DecisionTier(StrEnum):
    """Trust tier of a decision, used for retrieval weighting."""

    EXPLICIT = "explicit"  # ADRs, @decision annotations
    MINED = "mined"  # filtered from PR descriptions, commits, review comments
    INFERRED = "inferred"  # patterns extracted from code structure


class Decision(BaseModel):
    """A design decision that the codebase encodes.

    The body is the full source text; downstream consumers (the LLM judge,
    the embedder) decide how to use it.
    """

    id: str
    title: str
    body: str
    source: str  # e.g. "docs/adr/0042-use-postgres.md"
    tier: DecisionTier = DecisionTier.EXPLICIT
    created_at: datetime
    superseded_by: str | None = None
    weight: float = 1.0
    # Populated by the indexer when a vector store is in use; None for ADRs
    # loaded ad-hoc at review time without embedding.
    embedding: list[float] | None = None


class CandidateDecision(BaseModel):
    """A piece of mined content (PR description, commit message, ...) that may or
    may not encode a decision. The Classifier promotes promising ones to
    full ``Decision`` objects."""

    title: str
    body: str
    source: str
    created_at: datetime


class DiffFile(BaseModel):
    """A single file's portion of a pull request diff."""

    path: str
    additions: int
    deletions: int
    patch: str  # unified diff text; may be empty for binary or very large files


class Diff(BaseModel):
    """The full diff of a pull request."""

    files: list[DiffFile] = Field(default_factory=list)

    @property
    def total_changes(self) -> int:
        return sum(f.additions + f.deletions for f in self.files)


class Severity(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class Finding(BaseModel):
    """A single regression finding to surface in the PR comment.

    ``finding_number`` is 1-based within a single review run and is used to
    address the finding in reviewer slash commands (``/adrift accept N``,
    ``/adrift override N <reason>``). It's set by the reporter at render time.
    """

    decision_id: str
    decision_title: str
    decision_source: str
    severity: Severity = Severity.MEDIUM
    confidence: float = Field(ge=0.0, le=1.0)
    explanation: str
    quoted_diff: str = ""
    quoted_decision: str = ""
    finding_number: int | None = None
