"""ADR source — reads markdown decision records from one or more directories.

Convention: each ADR is a markdown file whose first H1 (`# ...`) is the title.
If no H1 is present, the filename stem is used.
"""

from __future__ import annotations

import hashlib
import logging
from datetime import datetime
from pathlib import Path

from adrift.models import Decision, DecisionTier

log = logging.getLogger(__name__)


class ADRSource:
    name = "adr"

    def __init__(self, paths: list[Path]):
        self.paths = [Path(p) for p in paths]

    def fetch(self) -> list[Decision]:
        decisions: list[Decision] = []
        for base in self.paths:
            if not base.exists():
                log.debug("ADR path %s does not exist; skipping", base)
                continue
            if not base.is_dir():
                log.warning("ADR path %s is not a directory; skipping", base)
                continue
            for md in sorted(base.rglob("*.md")):
                try:
                    decisions.append(self._parse(md))
                except Exception:
                    log.warning("Failed to parse ADR %s", md, exc_info=True)
        log.info("ADRSource: loaded %d decisions from %d path(s)", len(decisions), len(self.paths))
        return decisions

    @staticmethod
    def _parse(path: Path) -> Decision:
        text = path.read_text(encoding="utf-8")
        title = _extract_title(text) or path.stem
        return Decision(
            id=_stable_id(str(path)),
            title=title,
            body=text,
            source=str(path),
            tier=DecisionTier.EXPLICIT,
            created_at=datetime.fromtimestamp(path.stat().st_mtime),
        )


def _extract_title(text: str) -> str | None:
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("# "):
            return stripped[2:].strip()
    return None


def _stable_id(source: str) -> str:
    return hashlib.sha1(source.encode("utf-8")).hexdigest()[:12]
