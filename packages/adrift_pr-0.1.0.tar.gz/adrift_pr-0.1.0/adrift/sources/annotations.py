"""AnnotationSource — discovers ``@decision:`` annotations in source code.

A code-level alternative to ADR markdown files: developers can document a
load-bearing design choice right next to the code that implements it, and
Adrift will pick it up automatically as an EXPLICIT-tier decision.

Recognized form (in any single-line comment style — ``#``, ``//``, ``--``):

    # @decision: <one-line title>
    #   <continuation line>
    #   <another continuation line>

The title is the rest of the line after ``@decision:``. Continuation lines
are subsequent comment lines that begin with whitespace before the comment
marker — they're concatenated into the body. The first non-comment line
ends the annotation.

Example:

    # @decision: Use the repository pattern for all DB access.
    #   Reason: lets us swap persistence later without touching business logic.
    #   Constraint: no module outside `repositories/` may import from the ORM.
    def get_user(user_id: str) -> User:
        return user_repository.find(user_id)
"""

from __future__ import annotations

import hashlib
import logging
import re
from collections.abc import Iterable
from datetime import datetime
from pathlib import Path

from adrift.models import Decision, DecisionTier

log = logging.getLogger(__name__)

# Files we scan by default. Languages are detected by extension; the comment
# regex below is permissive enough that adding a language is just adding an
# extension here.
DEFAULT_EXTENSIONS = (".py", ".ts", ".tsx", ".js", ".jsx", ".go", ".rs", ".java", ".rb")

# Directories to skip even when they're inside one of the configured roots.
SKIP_DIR_NAMES = frozenset(
    {
        ".git",
        ".venv",
        "venv",
        "node_modules",
        "__pycache__",
        ".mypy_cache",
        ".ruff_cache",
        ".pytest_cache",
        "dist",
        "build",
        "target",
    }
)

# `# @decision: title here` or `// @decision: title here` etc.
# Captures the comment-marker chars and the title.
_DECISION_START_RE = re.compile(
    r"""
    ^\s*                                    # leading whitespace
    (?P<marker>\#|//|--)                    # one of: # / // / --
    \s*@decision:\s*                        # the annotation
    (?P<title>.+?)                          # title (rest of line)
    \s*$
    """,
    re.VERBOSE,
)


# Continuation comment lines: same comment marker, at least two leading spaces
# of indent (relative to the marker), no @decision: prefix on this line.
def _continuation_re(marker: str) -> re.Pattern[str]:
    escaped = re.escape(marker)
    return re.compile(rf"^\s*{escaped}\s+(?P<text>\S.*?)\s*$")


class AnnotationSource:
    name = "annotations"

    def __init__(
        self,
        roots: Iterable[Path],
        *,
        extensions: tuple[str, ...] = DEFAULT_EXTENSIONS,
    ):
        self.roots = [Path(r) for r in roots]
        self.extensions = tuple(e.lower() for e in extensions)

    def fetch(self) -> list[Decision]:
        decisions: list[Decision] = []
        for root in self.roots:
            if not root.exists():
                log.debug("AnnotationSource: root %s does not exist; skipping", root)
                continue
            for path in self._walk(root):
                try:
                    decisions.extend(self._parse_file(path))
                except Exception:
                    log.warning("AnnotationSource: failed to parse %s", path, exc_info=True)
        log.info(
            "AnnotationSource: collected %d @decision annotation(s) from %d root(s)",
            len(decisions),
            len(self.roots),
        )
        return decisions

    def _walk(self, root: Path) -> Iterable[Path]:
        if root.is_file():
            if root.suffix.lower() in self.extensions:
                yield root
            return
        for path in root.rglob("*"):
            if not path.is_file():
                continue
            if path.suffix.lower() not in self.extensions:
                continue
            # Skip anything under an ignored directory.
            if any(part in SKIP_DIR_NAMES for part in path.parts):
                continue
            yield path

    def _parse_file(self, path: Path) -> list[Decision]:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return []
        lines = text.splitlines()
        decisions: list[Decision] = []
        i = 0
        n = len(lines)
        while i < n:
            m = _DECISION_START_RE.match(lines[i])
            if not m:
                i += 1
                continue
            start_line = i + 1  # 1-based for human-friendly source citation
            title = m.group("title").strip()
            cont_re = _continuation_re(m.group("marker"))
            body_lines: list[str] = []
            i += 1
            while i < n:
                cm = cont_re.match(lines[i])
                if not cm:
                    break
                body_lines.append(cm.group("text").strip())
                i += 1
            body = (
                f"@decision: {title}\n\n" + "\n".join(body_lines)
                if body_lines
                else f"@decision: {title}"
            )
            source = f"{path}:{start_line}"
            decisions.append(
                Decision(
                    id=_annotation_id(source, body),
                    title=title[:200],
                    body=body,
                    source=source,
                    tier=DecisionTier.EXPLICIT,
                    created_at=_file_mtime(path),
                )
            )
        return decisions


def _file_mtime(path: Path) -> datetime:
    try:
        return datetime.fromtimestamp(path.stat().st_mtime)
    except OSError:
        return datetime.now()


def _annotation_id(source: str, body: str) -> str:
    h = hashlib.sha1(f"{source}\n{body}".encode()).hexdigest()[:12]
    return f"annot-{h}"
