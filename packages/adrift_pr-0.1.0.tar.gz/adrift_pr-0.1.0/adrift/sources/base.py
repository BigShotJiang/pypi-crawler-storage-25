"""The IntentSource protocol — implementers feed decisions into the system."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from adrift.models import Decision


@runtime_checkable
class IntentSource(Protocol):
    """A source of design decisions / intent.

    Any class with a ``name`` attribute and a ``fetch()`` method qualifies.
    Phase 5 will surface this protocol as a plugin entry point so contributors
    can ship sources for Linear, Notion, Slack, etc.
    """

    name: str

    def fetch(self) -> list[Decision]: ...
