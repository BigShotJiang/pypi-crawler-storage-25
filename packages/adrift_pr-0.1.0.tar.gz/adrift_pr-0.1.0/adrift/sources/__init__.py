"""Intent sources — places where design decisions live.

Ships:
- ``ADRSource``  — markdown decision records under ``docs/adr/`` etc.
- ``AnnotationSource`` — ``@decision:`` comments in source code (Phase 5).

The ``IntentSource`` protocol is defined so future sources (Linear, Notion,
Slack, ...) implement a stable contract.
"""

from adrift.sources.adr import ADRSource
from adrift.sources.annotations import AnnotationSource
from adrift.sources.base import IntentSource

__all__ = ["ADRSource", "AnnotationSource", "IntentSource"]
