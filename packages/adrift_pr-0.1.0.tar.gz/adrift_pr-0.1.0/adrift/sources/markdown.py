"""MarkdownSource — treats top-level ``CLAUDE.md`` and ``AGENTS.md`` as EXPLICIT
decisions.

These files exist precisely to encode rules an AI agent should respect when
working in the repo ("never call X without first running Y", "auth/ is
sandboxed", etc.). That's a higher-quality decision signal than most
documentation. We pick them up automatically as ``EXPLICIT``-tier alongside
``docs/adr/`` and ``@decision:`` annotations.

Everything else markdown — README sections, CHANGELOG entries, ``docs/*.md``,
arbitrary subdirectory ``.md`` — goes through ``MarkdownMiner`` instead, which
section-splits and routes each chunk through the classifier.
"""

from __future__ import annotations

import hashlib
import logging
from datetime import datetime
from pathlib import Path

from adrift.models import Decision, DecisionTier

log = logging.getLogger(__name__)


# Filenames treated as authored agent-rule documents.
EXPLICIT_FILENAMES = ("CLAUDE.md", "AGENTS.md")

# Minimum body length before we treat a file as having any real content.
_MIN_CHARS = 80


class MarkdownSource:
    """Yields EXPLICIT decisions from ``CLAUDE.md`` / ``AGENTS.md`` at repo root."""

    name = "markdown_explicit"

    def __init__(self, root: Path):
        self.root = Path(root)

    def fetch(self) -> list[Decision]:
        decisions: list[Decision] = []
        if not self.root.is_dir():
            log.debug("MarkdownSource root %s is not a directory; skipping", self.root)
            return decisions
        for name in EXPLICIT_FILENAMES:
            path = self.root / name
            if not path.is_file():
                continue
            try:
                text = path.read_text(encoding="utf-8").strip()
            except OSError:
                log.warning("MarkdownSource: failed to read %s", path, exc_info=True)
                continue
            if len(text) < _MIN_CHARS:
                log.debug("MarkdownSource: %s too short (%d chars); skipping", path, len(text))
                continue
            title = _extract_h1(text) or path.stem
            try:
                created_at = datetime.fromtimestamp(path.stat().st_mtime)
            except OSError:
                created_at = datetime.now()
            decisions.append(
                Decision(
                    id=_stable_id(str(path.relative_to(self.root))),
                    title=title,
                    body=text,
                    source=str(path.relative_to(self.root)),
                    tier=DecisionTier.EXPLICIT,
                    created_at=created_at,
                )
            )
            log.info("MarkdownSource: loaded %s (%d chars)", path.name, len(text))
        return decisions


def _extract_h1(text: str) -> str | None:
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("# ") and not stripped.startswith("## "):
            return stripped[2:].strip() or None
    return None


def _stable_id(key: str) -> str:
    return "md-explicit-" + hashlib.sha1(key.encode("utf-8")).hexdigest()[:12]
