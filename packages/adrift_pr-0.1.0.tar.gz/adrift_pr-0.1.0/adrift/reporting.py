"""Formatting findings for the PR comment and for local terminal output.

The rendered comment carries two kinds of machine-readable markers, both as
hidden HTML comments invisible to readers but parseable by the ``learn``
command:

- ``<!-- adrift-comment v1 -->`` at the top — tags this comment as ours so
  ``learn`` can find it among many on a PR.
- ``<!-- adrift-finding number=N decision=ID -->`` before each finding header
  — lets slash commands like ``/adrift accept 3`` resolve to the right decision.
"""

from __future__ import annotations

import re

from adrift.models import Finding, Severity

COMMENT_TAG = "<!-- adrift-comment v1 -->"
COMMENT_HEADER = f"{COMMENT_TAG}\n## 🛡️ Adrift"
COMMENT_FOOTER = (
    "---\n"
    "*Posted by [adrift](https://github.com/MOHAMAD-ZUBI/Adrift). "
    "Reply with `/adrift accept N`, `/adrift override N <reason>`, "
    "`/adrift dismiss N`, or `/adrift flag <missed-regression>` to teach future reviews.*"
)


def format_pr_comment(findings: list[Finding]) -> str:
    """Render findings as a Markdown comment suitable for GitHub PR threads.

    Sets each ``finding.finding_number`` to its 1-based index so the rendered
    numbering matches the slash-command grammar.

    HIGH-severity findings render up front. MEDIUM/LOW findings render below
    a collapsed ``<details>`` block so reviewers see a clean comment first
    and dig into the soft signals only if they want. This addresses dogfood
    fatigue: when every finding is visually equal, reviewers learn to
    ignore the whole comment.
    """
    if not findings:
        return (
            f"{COMMENT_HEADER}\n\n"
            "No design-intent regressions detected against the configured decisions.\n\n"
            f"{COMMENT_FOOTER}"
        )

    # Assign 1-based finding numbers up-front so slash commands resolve
    # consistently regardless of which severity bucket a finding lands in.
    for i, f in enumerate(findings, 1):
        f.finding_number = i

    high = [f for f in findings if f.severity == Severity.HIGH]
    soft = [f for f in findings if f.severity != Severity.HIGH]

    lines: list[str] = [COMMENT_HEADER, ""]
    if high:
        lines.append(
            f"Found **{len(high)}** likely design-intent regression{'s' if len(high) != 1 else ''}."
        )
    else:
        lines.append(
            f"No high-confidence regressions. **{len(soft)}** potential tension"
            f"{'s' if len(soft) != 1 else ''} worth a glance — collapsed below."
        )
    lines.append("")

    for f in high:
        lines.extend(_render_finding(f))

    if soft:
        lines.append("")
        lines.append(
            f"<details><summary>"
            f"{len(soft)} lower-severity finding{'s' if len(soft) != 1 else ''} — click to expand"
            f"</summary>\n"
        )
        for f in soft:
            lines.extend(_render_finding(f))
        lines.append("</details>\n")

    lines.append(COMMENT_FOOTER)
    return "\n".join(lines)


def _render_finding(f: Finding) -> list[str]:
    return [
        _finding_marker(f.finding_number or 0, f.decision_id),
        f"### {f.finding_number}. {f.decision_title}",
        (
            f"*Source: `{f.decision_source}` · "
            f"Confidence: {f.confidence:.0%} · "
            f"Severity: {f.severity.value}*\n"
        ),
        f.explanation if f.explanation else "",
        *(
            ("\n**From the decision:**", _quote_block(f.quoted_decision))
            if f.quoted_decision
            else ()
        ),
        *(("\n**In this diff:**", f"```\n{f.quoted_diff}\n```") if f.quoted_diff else ()),
        "",
    ]


def is_adrift_comment(body: str) -> bool:
    """Quick check for whether a PR comment was posted by us."""
    return COMMENT_TAG in (body or "")


_FINDING_MARKER_RE = re.compile(
    r"<!--\s*adrift-finding\s+number=(?P<n>\d+)\s+decision=(?P<id>[^\s>]+)\s*-->"
)


def parse_finding_markers(body: str) -> dict[int, str]:
    """Extract ``{finding_number: decision_id}`` from a previously-posted comment.

    Used by ``adrift learn`` to map ``/adrift accept N`` back to the decision
    id behind finding N.
    """
    return {int(m.group("n")): m.group("id") for m in _FINDING_MARKER_RE.finditer(body or "")}


def _finding_marker(number: int, decision_id: str) -> str:
    return f"<!-- adrift-finding number={number} decision={decision_id} -->"


def _quote_block(text: str) -> str:
    return "\n".join(f"> {line}" for line in text.strip().splitlines())
