"""ReadFileContextTool — reads full file content around a diff hunk.

The agent normally only sees the patch (``+``/``-`` lines). That's enough
for many findings but disastrous for the "is this thing actually
*removed* or just *not in the diff*?" question. Most early dogfood false
positives traced to context blindness: the agent inferred that a step
or rule had been removed because it wasn't in the diff — when in fact
it was still in the file, just untouched.

Letting the agent fetch the surrounding file content removes that
guess. The agent should call this *before* asserting "X was removed"
or "Y is missing."
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, ClassVar

from adrift.tools.base import ToolResult

log = logging.getLogger(__name__)

# Hard caps to keep responses inside the LLM context budget.
_MAX_FILE_CHARS = 8000
_DEFAULT_CONTEXT_LINES = 60
_MAX_REQUESTED_LINES = 400


class ReadFileContextTool:
    """Reads a file (or a line range) from the local checkout."""

    name: ClassVar[str] = "read_file_context"
    description: ClassVar[str] = (
        "Read the actual contents of a file from the repo (not just the diff). "
        "Use this before asserting that something has been removed or is missing "
        "— the diff only shows changed lines, not the surrounding file. If you "
        "see `+ new_thing` and want to claim `old_thing` was removed, fetch the "
        "file first and verify `old_thing` is genuinely absent. Pass an optional "
        "line range to get just the relevant slice (cheaper). Default returns "
        "the whole file capped at 8000 characters."
    )
    input_schema: ClassVar[dict[str, Any]] = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Repo-relative file path (e.g., 'adrift/cli.py').",
            },
            "line_start": {
                "type": "integer",
                "description": "Optional 1-based start line (inclusive).",
                "minimum": 1,
            },
            "line_end": {
                "type": "integer",
                "description": "Optional 1-based end line (inclusive).",
                "minimum": 1,
            },
        },
        "required": ["path"],
    }

    def __init__(self, repo_root: Path):
        self.repo_root = Path(repo_root).resolve()

    def invoke(
        self,
        path: str,
        line_start: int | None = None,
        line_end: int | None = None,
    ) -> ToolResult:
        log.info("read_file_context: path=%s lines=%s-%s", path, line_start, line_end)
        try:
            target = (self.repo_root / path).resolve()
        except (OSError, ValueError) as e:
            return ToolResult(data={}, summary=f"invalid path {path!r}", error=str(e))

        # Refuse to escape the repo root. Prevents the agent from reading
        # arbitrary files on the runner ("../../../etc/passwd" style paths).
        try:
            target.relative_to(self.repo_root)
        except ValueError:
            return ToolResult(
                data={},
                summary=f"path {path!r} is outside the repo root",
                error="path escapes repo root",
            )

        if not target.is_file():
            return ToolResult(
                data={"path": path, "exists": False},
                summary=f"{path} does not exist",
                error=None,
            )

        try:
            text = target.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            return ToolResult(
                data={"path": path, "exists": True, "binary": True},
                summary=f"{path} is binary; not readable as text",
                error=None,
            )
        except OSError as e:
            return ToolResult(data={}, summary=f"failed to read {path}", error=str(e))

        lines = text.splitlines()
        total_lines = len(lines)

        slice_start = (line_start - 1) if line_start else 0
        slice_end = line_end if line_end else total_lines
        slice_start = max(0, slice_start)
        slice_end = min(total_lines, slice_end)
        if slice_start >= slice_end:
            return ToolResult(
                data={"path": path, "exists": True, "lines_total": total_lines, "content": ""},
                summary=f"{path}: empty range {line_start}-{line_end}",
            )

        # Cap the requested span. If the agent asks for 5000 lines, give it
        # the first MAX_REQUESTED and tell it to narrow.
        capped = False
        if slice_end - slice_start > _MAX_REQUESTED_LINES:
            slice_end = slice_start + _MAX_REQUESTED_LINES
            capped = True

        body_lines = lines[slice_start:slice_end]
        # Prefix every line with its 1-based line number for the agent's benefit.
        numbered = "\n".join(f"{i + slice_start + 1}\t{ln}" for i, ln in enumerate(body_lines))

        truncated_chars = False
        if len(numbered) > _MAX_FILE_CHARS:
            numbered = numbered[:_MAX_FILE_CHARS].rstrip() + "\n... [truncated]"
            truncated_chars = True

        summary = (
            f"{path}: {slice_end - slice_start} line(s) "
            f"({slice_start + 1}-{slice_end} of {total_lines})"
        )
        if capped:
            summary += " — capped at 400 lines; narrow the range for more"
        elif truncated_chars:
            summary += " — character cap hit; narrow the range for more"

        return ToolResult(
            data={
                "path": path,
                "exists": True,
                "lines_total": total_lines,
                "line_start": slice_start + 1,
                "line_end": slice_end,
                "content": numbered,
                "truncated": capped or truncated_chars,
            },
            summary=summary,
        )
