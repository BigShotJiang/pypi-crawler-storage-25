"""ImpactZoneTool — exposes a ``GraphClient`` as a ``Tool``.

Used in Phase 2 by the ``Retriever`` to narrow decisions structurally.
In Phase 5, the same class is registered as an Anthropic tool_use definition
for the agentic reviewer (no code changes required).
"""

from __future__ import annotations

import logging
from typing import Any, ClassVar

from adrift.graph.base import GraphClient
from adrift.tools.base import ToolResult

log = logging.getLogger(__name__)


class ImpactZoneTool:
    name: ClassVar[str] = "query_impact_zone"
    description: ClassVar[str] = (
        "Given file paths changed in a diff, return the set of affected code "
        "nodes and their immediate call-graph neighbors. Use this to understand "
        "the structural impact of a change before reasoning about contradictions."
    )
    input_schema: ClassVar[dict[str, Any]] = {
        "type": "object",
        "properties": {
            "paths": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Repo-relative file paths from the diff.",
            },
            "hops": {
                "type": "integer",
                "description": "Graph hops to include as neighbors (0 to 3).",
                "default": 1,
                "minimum": 0,
                "maximum": 3,
            },
        },
        "required": ["paths"],
    }

    def __init__(self, graph: GraphClient):
        self._graph = graph

    def invoke(self, paths: list[str], hops: int = 1) -> ToolResult:
        log.info("query_impact_zone: paths=%s hops=%d", paths, hops)
        try:
            zone = self._graph.impact_zone(paths=paths, hops=hops)
        except Exception as e:
            log.warning("ImpactZoneTool: graph call failed: %s", e)
            return ToolResult(data={}, summary="impact zone query failed", error=str(e))

        log.info(
            "query_impact_zone returned %d changed + %d neighbor node(s) across %d file(s)",
            len(zone.changed),
            len(zone.neighbors),
            len(zone.all_files()),
        )
        return ToolResult(
            data={
                "changed": [n.model_dump() for n in zone.changed],
                "neighbors": [n.model_dump() for n in zone.neighbors],
                "file_count": len(zone.all_files()),
            },
            summary=(
                f"{len(zone.changed)} changed + {len(zone.neighbors)} neighbor node(s) "
                f"across {len(zone.all_files())} file(s)"
            ),
        )
