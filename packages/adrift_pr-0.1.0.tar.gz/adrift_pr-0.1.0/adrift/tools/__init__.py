"""Tool abstractions — capabilities the system invokes directly today and may
expose to an LLM as ``tool_use`` definitions in later phases.

The protocol is intentionally minimal: a ``name``, ``description``,
``input_schema``, and a sync ``invoke`` method. Anthropic's native tool_use
API consumes those same four fields directly, so the same Tool implementations
power both the pipeline (Phase 2) and the agentic reviewer (Phase 5+) without
any framework dependency.
"""

from adrift.tools.base import Tool, ToolResult
from adrift.tools.impact_zone import ImpactZoneTool
from adrift.tools.read_file_context import ReadFileContextTool
from adrift.tools.report_finding import ReportFindingTool
from adrift.tools.search_decisions import SearchDecisionsTool

__all__ = [
    "ImpactZoneTool",
    "ReadFileContextTool",
    "ReportFindingTool",
    "SearchDecisionsTool",
    "Tool",
    "ToolResult",
]
