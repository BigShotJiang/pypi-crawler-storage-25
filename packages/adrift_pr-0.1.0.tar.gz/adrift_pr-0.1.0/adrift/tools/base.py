"""Tool protocol — the seam between pipeline-mode and agentic-mode invocation."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel, Field


class ToolResult(BaseModel):
    """Structured outcome of invoking a tool.

    Attributes:
        data: Machine-readable payload (JSON-serializable for tool_use feedback).
        summary: One-line, human/LLM-readable description of what happened.
        error: Non-None when invocation failed gracefully; ``succeeded`` becomes False.
    """

    data: dict[str, Any] = Field(default_factory=dict)
    summary: str = ""
    error: str | None = None

    @property
    def succeeded(self) -> bool:
        return self.error is None


@runtime_checkable
class Tool(Protocol):
    """A capability invokable directly by the pipeline or exposed to an LLM.

    Pipeline mode::

        result = tool.invoke(**kwargs)
        consume(result.data)

    Agentic mode (Phase 5+)::

        # tool.name, tool.description, tool.input_schema feed an Anthropic
        # tool_use definition. The agent loop calls tool.invoke(**kwargs) when
        # the LLM emits a matching tool_use block.
    """

    name: str
    description: str
    input_schema: dict[str, Any]

    def invoke(self, **kwargs: Any) -> ToolResult: ...
