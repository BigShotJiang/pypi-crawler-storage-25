"""ReportFindingTool — how the agentic reviewer emits findings.

Unlike ``ImpactZoneTool`` or ``SearchDecisionsTool``, this tool has no
external side effect: its ``invoke`` just accumulates a ``Finding`` on its
own state. The agent loop reads ``.findings`` after the LLM stops calling
tools to assemble the final review.

This shape lets the same ``Tool`` protocol cover both side-effectful tools
(graph queries, store lookups) and structured-output tools (finding reports).
"""

from __future__ import annotations

import logging
from typing import Any, ClassVar

from pydantic import ValidationError

from adrift.models import Finding, Severity
from adrift.tools.base import ToolResult

log = logging.getLogger(__name__)


class ReportFindingTool:
    name: ClassVar[str] = "report_finding"
    description: ClassVar[str] = (
        "Record a confirmed design-intent regression. Call this once per distinct "
        "finding after you have established (via search_decisions) that a documented "
        "decision exists and (via reading the diff) that it is being contradicted. "
        "Only call when confidence is high — false positives erode reviewer trust."
    )
    input_schema: ClassVar[dict[str, Any]] = {
        "type": "object",
        "properties": {
            "decision_id": {
                "type": "string",
                "description": "The id of the decision being contradicted (from search_decisions).",
            },
            "decision_title": {
                "type": "string",
                "description": "The decision's title (from search_decisions).",
            },
            "decision_source": {
                "type": "string",
                "description": "Path or URL where the decision is documented.",
            },
            "confidence": {
                "type": "number",
                "minimum": 0.0,
                "maximum": 1.0,
                "description": "Subjective confidence that this is a real contradiction.",
            },
            "explanation": {
                "type": "string",
                "description": "Under 150 words; why the diff contradicts the decision.",
            },
            "quoted_diff": {
                "type": "string",
                "description": "The specific diff snippet that violates the decision.",
            },
            "quoted_decision": {
                "type": "string",
                "description": "The specific sentence(s) from the decision being contradicted.",
            },
            "severity": {
                "type": "string",
                "enum": ["low", "medium", "high"],
                "description": "Severity rating. Default medium.",
            },
        },
        "required": [
            "decision_id",
            "decision_title",
            "decision_source",
            "confidence",
            "explanation",
        ],
    }

    def __init__(self) -> None:
        self.findings: list[Finding] = []

    def invoke(self, **kwargs: Any) -> ToolResult:
        severity_str = kwargs.pop("severity", "medium")
        try:
            severity = Severity(severity_str)
        except ValueError:
            severity = Severity.MEDIUM

        try:
            finding = Finding(severity=severity, **kwargs)
        except ValidationError as e:
            log.warning("ReportFindingTool: invalid payload from LLM: %s", e)
            return ToolResult(
                data={},
                summary="rejected — invalid finding payload",
                error=str(e),
            )

        self.findings.append(finding)
        return ToolResult(
            data={
                "accepted": True,
                "finding_count_so_far": len(self.findings),
            },
            summary=f"recorded finding #{len(self.findings)} ({finding.decision_title})",
        )
