"""SearchDecisionsTool — semantic search over the decision store.

Used in Phase 3 by the hybrid retriever. Phase 5's agentic reviewer will
expose this same tool to the LLM so it can search decisions on demand
(``"find decisions related to authentication"``).
"""

from __future__ import annotations

import logging
from typing import Any, ClassVar

from adrift.store.decision_store import DecisionStore
from adrift.tools.base import ToolResult

log = logging.getLogger(__name__)


class SearchDecisionsTool:
    name: ClassVar[str] = "search_decisions"
    description: ClassVar[str] = (
        "Search the local decision store for design decisions related to a query. "
        "Returns the top-K most similar decisions by semantic similarity, each "
        "with title, source, and a distance score (smaller is more similar)."
    )
    input_schema: ClassVar[dict[str, Any]] = {
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Natural-language query describing the topic of interest.",
            },
            "k": {
                "type": "integer",
                "description": "Maximum number of results to return.",
                "default": 10,
                "minimum": 1,
                "maximum": 50,
            },
            "tier": {
                "type": "string",
                "enum": ["explicit", "mined", "inferred"],
                "description": "Optional filter by trust tier.",
            },
        },
        "required": ["query"],
    }

    def __init__(self, store: DecisionStore):
        self._store = store

    def invoke(self, query: str, k: int = 10, tier: str | None = None) -> ToolResult:
        from adrift.models import DecisionTier

        tier_filter: DecisionTier | None
        try:
            tier_filter = DecisionTier(tier) if tier else None
        except ValueError:
            return ToolResult(
                data={},
                summary=f"invalid tier {tier!r}",
                error=f"tier must be one of explicit/mined/inferred (got {tier!r})",
            )

        try:
            results = self._store.search_similar(query, k=k, tier=tier_filter)
        except Exception as e:
            log.warning("SearchDecisionsTool failed: %s", e)
            return ToolResult(data={}, summary="decision search failed", error=str(e))

        return ToolResult(
            data={
                "results": [
                    {
                        "id": d.id,
                        "title": d.title,
                        "source": d.source,
                        "tier": d.tier.value,
                        # Phase 5: include a truncated body so the agentic
                        # reviewer can judge contradictions without a separate
                        # get_decision call per result.
                        "body": _truncate_body(d.body),
                        "distance": distance,
                    }
                    for d, distance in results
                ],
            },
            summary=f"{len(results)} decision(s) matched query (top distance: {results[0][1]:.3f})"
            if results
            else "no decisions matched query",
        )


# Body length cap when surfacing decisions to an LLM. Tuned so the agent can
# see enough to judge contradictions while keeping multi-result responses
# under the model's effective context budget.
_BODY_MAX_CHARS = 1200


def _truncate_body(body: str) -> str:
    if len(body) <= _BODY_MAX_CHARS:
        return body
    return body[:_BODY_MAX_CHARS] + "\n... [truncated]"
