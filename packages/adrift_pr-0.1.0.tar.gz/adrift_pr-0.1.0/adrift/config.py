"""Configuration loading.

Configuration cascades: defaults → file (.adrift.yml) → CLI flags.
Phase 1 keeps the surface minimal; future phases will extend `Config`.
"""

from __future__ import annotations

import logging
from pathlib import Path

import yaml
from pydantic import BaseModel, Field

log = logging.getLogger(__name__)

DEFAULT_CONFIG_NAMES = (".adrift.yml", ".adrift.yaml")


class GitNexusConfig(BaseModel):
    """Configuration for the GitNexus MCP backend.

    Enabled by default. Adrift tries to spawn ``gitnexus mcp`` as a
    subprocess to get the code-graph signal (structural impact zone for
    diffs; cross-call awareness for the agentic reviewer).

    If the ``gitnexus`` binary isn't on PATH (install with
    ``npm install -g gitnexus``), the CLI logs a one-line warning and
    falls back to non-graph mode — the review still works, it just
    doesn't get structural context.
    """

    enabled: bool = True
    command: str = "gitnexus"
    args: list[str] = Field(default_factory=lambda: ["mcp"])

    # Hop budget for impact-zone neighbor expansion.
    hops: int = Field(default=1, ge=0, le=3)


class MiningConfig(BaseModel):
    """Configuration for mining decisions from PR/commit history (Phase 3)."""

    enabled: bool = True
    pr_limit: int = Field(default=100, ge=1)
    pr_state: str = "closed"  # "open" | "closed" | "all"
    min_pr_body_chars: int = 80
    classify_min_confidence: float = Field(default=0.7, ge=0.0, le=1.0)


class StoreConfig(BaseModel):
    """Where the persistent decision store lives (Phase 3)."""

    # Relative to repo root.
    path: str = ".adrift/decisions.db"
    embedding_model: str = "BAAI/bge-small-en-v1.5"


class RetrieverConfig(BaseModel):
    """Hybrid retriever weights and thresholds (Phase 3)."""

    structural_weight: float = 0.5
    embedding_weight: float = 0.5
    tier_weight: float = 0.1
    min_score: float = 0.25
    top_k: int = 25


class Config(BaseModel):
    adr_paths: list[str] = Field(default_factory=lambda: ["docs/adr", "decisions"])
    max_findings_per_pr: int = 3
    min_confidence: float = Field(default=0.6, ge=0.0, le=1.0)

    # Score threshold below which the structural retriever drops a decision.
    min_retrieval_score: float = Field(default=0.25, ge=0.0)

    # LLM models — defaults bias toward Claude; litellm dispatches by name.
    judge_model: str = "claude-sonnet-4-6"
    classify_model: str = "claude-haiku-4-5-20251001"

    gitnexus: GitNexusConfig = Field(default_factory=GitNexusConfig)
    mining: MiningConfig = Field(default_factory=MiningConfig)
    store: StoreConfig = Field(default_factory=StoreConfig)
    retriever: RetrieverConfig = Field(default_factory=RetrieverConfig)

    @classmethod
    def load(cls, path: Path | None = None) -> Config:
        """Load config from the given path, or auto-discover in CWD.

        Returns defaults if no file is found.
        """
        candidate = path or _discover()
        if candidate is None:
            log.debug("No config file found; using defaults")
            return cls()
        log.debug("Loading config from %s", candidate)
        try:
            data = yaml.safe_load(candidate.read_text()) or {}
        except yaml.YAMLError as e:
            raise ValueError(f"Invalid YAML in {candidate}: {e}") from e
        if not isinstance(data, dict):
            raise ValueError(f"Config file {candidate} must contain a YAML mapping")
        return cls(**data)


def _discover() -> Path | None:
    for name in DEFAULT_CONFIG_NAMES:
        p = Path.cwd() / name
        if p.exists():
            return p
    return None
