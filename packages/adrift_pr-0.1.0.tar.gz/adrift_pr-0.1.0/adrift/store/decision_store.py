"""DecisionStore — durable per-repo storage for decisions + embeddings.

Backed by SQLite with the sqlite-vec extension for vector search. One file,
no external dependencies, portable between machines.

Layout (typically): ``<repo_root>/.adrift/decisions.db``
"""

from __future__ import annotations

import hashlib
import logging
import sqlite3
import struct
import time
from datetime import datetime
from pathlib import Path
from typing import Any

import sqlite_vec

from adrift.embedding.embedder import Embedder
from adrift.feedback.models import Feedback, FeedbackSignal
from adrift.models import Decision, DecisionTier
from adrift.store.schema import (
    FEEDBACK_SCHEMA_SQL,
    SCHEMA_SQL,
    SCHEMA_VERSION,
    VEC_TABLE_SQL,
)

log = logging.getLogger(__name__)


class DecisionStore:
    """SQLite-backed store with vector search via sqlite-vec.

    Use as a context manager so the underlying connection is closed cleanly::

        with DecisionStore(path, embedder) as store:
            store.upsert(decision)
            results = store.search_similar(query_text, k=10)
    """

    def __init__(self, path: Path, embedder: Embedder):
        self.path = path
        self.embedder = embedder
        self._conn: sqlite3.Connection | None = None

    def __enter__(self) -> DecisionStore:
        self.open()
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    def open(self) -> None:
        if self._conn is not None:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self.path)
        conn.enable_load_extension(True)
        sqlite_vec.load(conn)
        conn.enable_load_extension(False)
        conn.row_factory = sqlite3.Row
        conn.executescript(SCHEMA_SQL)
        conn.executescript(FEEDBACK_SCHEMA_SQL)
        conn.execute(VEC_TABLE_SQL.format(dim=self.embedder.dim))
        self._check_or_set_version(conn)
        conn.commit()
        self._conn = conn
        log.debug("Opened decision store at %s (dim=%d)", self.path, self.embedder.dim)

    def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    # --- Mutations ----------------------------------------------------------

    def upsert(self, decision: Decision) -> None:
        """Insert or update a decision and its embedding.

        Embedding is recomputed only when content changes (tracked by hash).
        """
        conn = self._require_conn()
        content_hash = _hash(decision.body)
        existing = conn.execute(
            "SELECT content_hash FROM decisions WHERE id = ?", (decision.id,)
        ).fetchone()

        conn.execute(
            """
            INSERT INTO decisions (id, title, body, source, tier, created_at,
                                   superseded_by, weight, indexed_at, content_hash)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                title=excluded.title, body=excluded.body, source=excluded.source,
                tier=excluded.tier, created_at=excluded.created_at,
                superseded_by=excluded.superseded_by, weight=excluded.weight,
                indexed_at=excluded.indexed_at, content_hash=excluded.content_hash
            """,
            (
                decision.id,
                decision.title,
                decision.body,
                decision.source,
                decision.tier.value,
                int(decision.created_at.timestamp()),
                decision.superseded_by,
                decision.weight,
                int(time.time()),
                content_hash,
            ),
        )

        # Recompute the embedding only when content changes (or it's new).
        if existing is None or existing["content_hash"] != content_hash:
            vec = decision.embedding or self.embedder.embed(_embed_text(decision))
            self._upsert_vec(decision.id, vec)
        conn.commit()

    def delete(self, decision_id: str) -> None:
        conn = self._require_conn()
        conn.execute("DELETE FROM decisions WHERE id = ?", (decision_id,))
        conn.execute("DELETE FROM decision_vecs WHERE decision_id = ?", (decision_id,))
        conn.commit()

    # --- Queries ------------------------------------------------------------

    def get(self, decision_id: str) -> Decision | None:
        conn = self._require_conn()
        row = conn.execute("SELECT * FROM decisions WHERE id = ?", (decision_id,)).fetchone()
        if row is None:
            return None
        return _row_to_decision(row, embedding=self._get_embedding(decision_id))

    def all(
        self,
        *,
        with_embeddings: bool = True,
        include_superseded: bool = False,
    ) -> list[Decision]:
        """Return all decisions.

        ``include_superseded=False`` (default) skips decisions whose
        ``superseded_by`` points to another decision — they're considered
        retired by Phase 4 feedback. Set True to inspect history.
        """
        conn = self._require_conn()
        sql = "SELECT * FROM decisions"
        if not include_superseded:
            sql += " WHERE superseded_by IS NULL"
        rows = conn.execute(sql).fetchall()
        decisions = []
        for row in rows:
            emb = self._get_embedding(row["id"]) if with_embeddings else None
            decisions.append(_row_to_decision(row, embedding=emb))
        return decisions

    def count(self, *, include_superseded: bool = False) -> int:
        conn = self._require_conn()
        sql = "SELECT COUNT(*) AS c FROM decisions"
        if not include_superseded:
            sql += " WHERE superseded_by IS NULL"
        row = conn.execute(sql).fetchone()
        return int(row["c"])

    def search_similar(
        self,
        query: str | list[float],
        k: int = 10,
        *,
        tier: DecisionTier | None = None,
        include_superseded: bool = False,
    ) -> list[tuple[Decision, float]]:
        """Return the k most similar decisions, paired with cosine distance.

        Smaller distance = more similar (sqlite-vec uses L2 by default;
        for unit-norm bge embeddings this is monotonic with 1 - cosine).

        Superseded decisions are filtered post-search by default — sqlite-vec
        doesn't support WHERE clauses on metadata columns inside the MATCH
        query, so we over-fetch slightly and filter in Python.
        """
        conn = self._require_conn()
        query_vec = self.embedder.embed(query) if isinstance(query, str) else query
        rows = conn.execute(
            """
            SELECT v.decision_id AS id, v.distance AS distance
            FROM decision_vecs AS v
            WHERE v.embedding MATCH ?
              AND k = ?
            ORDER BY v.distance
            """,
            (sqlite_vec.serialize_float32(query_vec), k * 2),  # over-fetch
        ).fetchall()

        results: list[tuple[Decision, float]] = []
        for row in rows:
            decision = self.get(row["id"])
            if decision is None:
                continue
            if not include_superseded and decision.superseded_by is not None:
                continue
            if tier is not None and decision.tier != tier:
                continue
            results.append((decision, float(row["distance"])))
            if len(results) >= k:
                break
        return results

    # --- Feedback (Phase 4) -------------------------------------------------

    def add_feedback(self, feedback: Feedback) -> None:
        """Record a feedback signal. Idempotent on ``feedback.id``."""
        conn = self._require_conn()
        conn.execute(
            """
            INSERT INTO decision_feedback
              (id, decision_id, finding_id, signal, reason, source_pr, reviewer, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                decision_id=excluded.decision_id,
                finding_id=excluded.finding_id,
                signal=excluded.signal,
                reason=excluded.reason,
                source_pr=excluded.source_pr,
                reviewer=excluded.reviewer,
                created_at=excluded.created_at
            """,
            (
                feedback.id,
                feedback.decision_id,
                feedback.finding_id,
                feedback.signal.value,
                feedback.reason,
                feedback.source_pr,
                feedback.reviewer,
                int(feedback.created_at.timestamp()),
            ),
        )
        conn.commit()

    def feedback_for_decision(self, decision_id: str) -> list[Feedback]:
        conn = self._require_conn()
        rows = conn.execute(
            "SELECT * FROM decision_feedback WHERE decision_id = ? ORDER BY created_at",
            (decision_id,),
        ).fetchall()
        return [_row_to_feedback(r) for r in rows]

    def feedback_count(self) -> int:
        conn = self._require_conn()
        row = conn.execute("SELECT COUNT(*) AS c FROM decision_feedback").fetchone()
        return int(row["c"])

    def supersede(
        self,
        *,
        old_decision_id: str,
        new_decision: Decision,
    ) -> None:
        """Mark ``old_decision_id`` as superseded by ``new_decision``.

        The new decision is upserted first, then the supersession edge is set.
        Idempotent: re-running with the same pair is a no-op.
        """
        self.upsert(new_decision)
        conn = self._require_conn()
        conn.execute(
            "UPDATE decisions SET superseded_by = ? WHERE id = ?",
            (new_decision.id, old_decision_id),
        )
        conn.commit()

    def adjust_weight(self, decision_id: str, delta: float) -> None:
        """Add ``delta`` to a decision's weight, clamped to [0.0, 2.0]."""
        conn = self._require_conn()
        conn.execute(
            """
            UPDATE decisions
               SET weight = MAX(0.0, MIN(2.0, weight + ?))
             WHERE id = ?
            """,
            (delta, decision_id),
        )
        conn.commit()

    # --- Helpers ------------------------------------------------------------

    def _require_conn(self) -> sqlite3.Connection:
        if self._conn is None:
            raise RuntimeError("DecisionStore is not open")
        return self._conn

    def _upsert_vec(self, decision_id: str, embedding: list[float]) -> None:
        conn = self._require_conn()
        conn.execute("DELETE FROM decision_vecs WHERE decision_id = ?", (decision_id,))
        conn.execute(
            "INSERT INTO decision_vecs (decision_id, embedding) VALUES (?, ?)",
            (decision_id, sqlite_vec.serialize_float32(embedding)),
        )

    def _get_embedding(self, decision_id: str) -> list[float] | None:
        conn = self._require_conn()
        row = conn.execute(
            "SELECT embedding FROM decision_vecs WHERE decision_id = ?", (decision_id,)
        ).fetchone()
        if row is None:
            return None
        return _deserialize_float32(row["embedding"])

    def _check_or_set_version(self, conn: sqlite3.Connection) -> None:
        row = conn.execute("SELECT value FROM meta WHERE key = 'schema_version'").fetchone()
        if row is None:
            conn.execute(
                "INSERT INTO meta (key, value) VALUES ('schema_version', ?)",
                (str(SCHEMA_VERSION),),
            )
            return
        current = int(row["value"])
        if current == SCHEMA_VERSION:
            return
        if current < SCHEMA_VERSION:
            log.info("Migrating decision store: v%d → v%d", current, SCHEMA_VERSION)
            # v1 → v2: the feedback table is created in ``open()`` already via
            # FEEDBACK_SCHEMA_SQL; nothing else to migrate. Bump the marker.
            conn.execute(
                "UPDATE meta SET value = ? WHERE key = 'schema_version'",
                (str(SCHEMA_VERSION),),
            )
            return
        raise RuntimeError(
            f"Decision store schema is v{current} but code expects v{SCHEMA_VERSION}. "
            f"The store is newer than this version of Adrift; please upgrade."
        )


def _deserialize_float32(data: bytes) -> list[float]:
    """Inverse of ``sqlite_vec.serialize_float32`` — bytes → list[float]."""
    if not data:
        return []
    count = len(data) // 4
    return list(struct.unpack(f"{count}f", data))


def _row_to_decision(row: sqlite3.Row, *, embedding: list[float] | None) -> Decision:
    return Decision(
        id=row["id"],
        title=row["title"],
        body=row["body"],
        source=row["source"],
        tier=DecisionTier(row["tier"]),
        created_at=datetime.fromtimestamp(row["created_at"]),
        superseded_by=row["superseded_by"],
        weight=row["weight"],
        embedding=embedding,
    )


def _row_to_feedback(row: sqlite3.Row) -> Feedback:
    return Feedback(
        id=row["id"],
        decision_id=row["decision_id"],
        finding_id=row["finding_id"],
        signal=FeedbackSignal(row["signal"]),
        reason=row["reason"],
        source_pr=row["source_pr"],
        reviewer=row["reviewer"],
        created_at=datetime.fromtimestamp(row["created_at"]),
    )


def _hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def _embed_text(decision: Decision) -> str:
    """Text used to compute a decision's embedding. Title weighted by repetition."""
    return f"{decision.title}\n{decision.title}\n{decision.body}"
