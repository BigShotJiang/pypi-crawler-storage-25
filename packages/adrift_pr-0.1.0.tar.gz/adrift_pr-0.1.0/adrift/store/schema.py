"""DDL for the local decision store.

Schema version bumps require a migration. v1 → v2 adds the feedback table
and is applied in-place (no rebuild) since it's purely additive.
"""

from __future__ import annotations

SCHEMA_VERSION = 2

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS decisions (
    id            TEXT PRIMARY KEY,
    title         TEXT NOT NULL,
    body          TEXT NOT NULL,
    source        TEXT NOT NULL,
    tier          TEXT NOT NULL,
    created_at    INTEGER NOT NULL,
    superseded_by TEXT,
    weight        REAL NOT NULL DEFAULT 1.0,
    indexed_at    INTEGER NOT NULL,
    content_hash  TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_decisions_source     ON decisions(source);
CREATE INDEX IF NOT EXISTS idx_decisions_tier       ON decisions(tier);
CREATE INDEX IF NOT EXISTS idx_decisions_hash       ON decisions(content_hash);
CREATE INDEX IF NOT EXISTS idx_decisions_superseded ON decisions(superseded_by);
"""

# Phase 4: feedback table. Created/migrated separately so v1 stores upgrade
# in place without rebuild.
FEEDBACK_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS decision_feedback (
    id            TEXT PRIMARY KEY,
    decision_id   TEXT,                -- NULL only for FLAG (new decision created)
    finding_id    TEXT,                -- references the original finding's id; may be NULL
    signal        TEXT NOT NULL,       -- 'accept' | 'override' | 'flag' | 'dismiss'
    reason        TEXT NOT NULL DEFAULT '',
    source_pr     TEXT NOT NULL,
    reviewer      TEXT NOT NULL DEFAULT '',
    created_at    INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_feedback_decision   ON decision_feedback(decision_id);
CREATE INDEX IF NOT EXISTS idx_feedback_finding    ON decision_feedback(finding_id);
CREATE INDEX IF NOT EXISTS idx_feedback_source_pr  ON decision_feedback(source_pr);
"""

# The vec table is created separately so we can pass the embedding dimension
# at runtime (set by the active Embedder).
VEC_TABLE_SQL = (
    "CREATE VIRTUAL TABLE IF NOT EXISTS decision_vecs USING vec0("
    "decision_id TEXT PRIMARY KEY, "
    "embedding FLOAT[{dim}])"
)
