"""Adrift — detects design-intent regressions in pull requests."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("adrift-pr")
except PackageNotFoundError:  # editable install before metadata is generated
    __version__ = "0.0.0+local"
