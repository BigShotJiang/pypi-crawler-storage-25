"""Generic tool-use agent loop.

Runs an LLM round-trip until either:

1. The model produces a response with no tool calls (it's done), or
2. ``max_iterations`` rounds have completed (safety net).

Each tool call is dispatched to the matching ``Tool`` and its result is
fed back to the model on the next turn. The loop is provider-agnostic
because the underlying ``LLMClient.complete_with_tools`` is normalized
to OpenAI-style tool_calls by litellm.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from typing import Any

from adrift.llm import LLMClient
from adrift.tools.base import Tool

log = logging.getLogger(__name__)


@dataclass
class AgentLoopResult:
    """Final state after the loop terminates."""

    final_text: str = ""
    iterations: int = 0
    tool_calls_made: int = 0
    tool_calls_by_name: dict[str, int] = field(default_factory=dict)
    terminated_by_max_iter: bool = False
    total_input_tokens: int = 0
    total_output_tokens: int = 0


class AgentLoop:
    def __init__(
        self,
        llm: LLMClient,
        tools: list[Tool],
        *,
        system: str | None = None,
        max_iterations: int = 10,
    ):
        if not tools:
            raise ValueError("AgentLoop requires at least one tool")
        self.llm = llm
        self.system = system
        self.max_iterations = max_iterations
        self._tools: dict[str, Tool] = {t.name: t for t in tools}
        self._tool_specs: list[dict[str, Any]] = [_to_openai_tool(t) for t in tools]

    def run(self, initial_user_message: str) -> AgentLoopResult:
        """Run the loop from the given user message until termination."""
        result = AgentLoopResult()
        messages: list[dict[str, Any]] = [{"role": "user", "content": initial_user_message}]

        for i in range(self.max_iterations):
            result.iterations = i + 1
            response = self.llm.complete_with_tools(
                messages=messages,
                tools=self._tool_specs,
                system=self.system,
            )
            result.total_input_tokens += response.input_tokens
            result.total_output_tokens += response.output_tokens

            assistant_message: dict[str, Any] = {
                "role": "assistant",
                "content": response.content,
            }
            if response.tool_calls:
                assistant_message["tool_calls"] = [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {"name": tc.name, "arguments": tc.arguments_json},
                    }
                    for tc in response.tool_calls
                ]
            messages.append(assistant_message)

            if not response.tool_calls:
                # Model decided it's done.
                result.final_text = response.content
                log.info(
                    "AgentLoop done in %d iter(s), %d tool call(s) total",
                    result.iterations,
                    result.tool_calls_made,
                )
                return result

            # Dispatch each tool call.
            for tc in response.tool_calls:
                result.tool_calls_made += 1
                result.tool_calls_by_name[tc.name] = result.tool_calls_by_name.get(tc.name, 0) + 1
                tool_result_payload = self._dispatch(tc.name, tc.arguments_json)
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": json.dumps(tool_result_payload),
                    }
                )

        result.terminated_by_max_iter = True
        log.warning(
            "AgentLoop exhausted max_iterations=%d (made %d tool call(s))",
            self.max_iterations,
            result.tool_calls_made,
        )
        return result

    def _dispatch(self, name: str, arguments_json: str) -> dict[str, Any]:
        """Run a single tool call. Returns a JSON-serializable payload."""
        tool = self._tools.get(name)
        if tool is None:
            log.warning("AgentLoop: unknown tool requested: %s", name)
            return {"error": f"unknown tool {name!r}"}

        try:
            arguments = json.loads(arguments_json) if arguments_json else {}
        except json.JSONDecodeError as e:
            log.warning("AgentLoop: bad JSON arguments for %s: %s", name, e)
            return {"error": f"invalid arguments: {e}"}

        try:
            tool_result = tool.invoke(**arguments)
        except Exception as e:
            log.warning("AgentLoop: tool %s raised: %s", name, e, exc_info=True)
            return {"error": str(e)}

        payload: dict[str, Any] = {"summary": tool_result.summary}
        if tool_result.error is not None:
            payload["error"] = tool_result.error
        else:
            payload["data"] = tool_result.data
        return payload


def _to_openai_tool(tool: Tool) -> dict[str, Any]:
    """Convert a ``Tool`` to the OpenAI/litellm tool-spec format."""
    return {
        "type": "function",
        "function": {
            "name": tool.name,
            "description": tool.description,
            "parameters": tool.input_schema,
        },
    }
