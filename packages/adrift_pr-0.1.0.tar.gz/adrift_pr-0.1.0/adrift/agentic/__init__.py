"""Phase 5 — agentic reviewer.

Instead of the pipeline reviewer's "retrieve K, judge each one" approach,
this layer hands the LLM a set of ``Tool`` instances and lets it decide
what to investigate. The same ``ImpactZoneTool`` / ``SearchDecisionsTool``
that the pipeline uses internally become agent tools, with no LangChain
or framework dependency — just Anthropic native ``tool_use`` semantics
exposed through litellm.
"""

from adrift.agentic.agent_loop import AgentLoop, AgentLoopResult
from adrift.agentic.reviewer import AgenticReviewer

__all__ = ["AgentLoop", "AgentLoopResult", "AgenticReviewer"]
