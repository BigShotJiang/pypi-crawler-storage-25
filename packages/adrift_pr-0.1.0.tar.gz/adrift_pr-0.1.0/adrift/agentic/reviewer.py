"""AgenticReviewer — the Phase 5 alternative to the pipeline reviewer.

Same input/output as ``adrift.reviewer.Reviewer`` (``review(diff) -> [Finding]``)
so the rest of the CLI doesn't care which one is wired in. Internally it
runs an LLM agent loop with tools and lets the model decide what to look up.
"""

from __future__ import annotations

import logging
from pathlib import Path

from adrift.agentic.agent_loop import AgentLoop
from adrift.agentic.prompts import AGENTIC_SYSTEM, AGENTIC_USER_PREFIX
from adrift.graph.base import GraphClient
from adrift.llm import LLMClient
from adrift.models import Diff, Finding
from adrift.store.decision_store import DecisionStore
from adrift.tools.base import Tool
from adrift.tools.impact_zone import ImpactZoneTool
from adrift.tools.read_file_context import ReadFileContextTool
from adrift.tools.report_finding import ReportFindingTool
from adrift.tools.search_decisions import SearchDecisionsTool

log = logging.getLogger(__name__)

# Diff truncation budget when handing to the agent. The agent then uses tools
# to dig further (search_decisions, query_impact_zone), so the prompt itself
# doesn't need to carry every line.
MAX_DIFF_CHARS = 20_000


class AgenticReviewer:
    """LLM-driven reviewer using native tool_use.

    Requires a ``DecisionStore`` (so ``search_decisions`` has something to
    search). ``GraphClient`` is optional — if absent, ``query_impact_zone``
    isn't offered and the agent works with semantic retrieval only.
    """

    def __init__(
        self,
        llm: LLMClient,
        store: DecisionStore,
        *,
        graph: GraphClient | None = None,
        repo_root: Path | None = None,
        min_confidence: float = 0.6,
        max_findings: int = 3,
        max_iterations: int = 10,
    ):
        self.llm = llm
        self.store = store
        self.graph = graph
        self.repo_root = Path(repo_root) if repo_root else None
        self.min_confidence = min_confidence
        self.max_findings = max_findings
        self.max_iterations = max_iterations

    def review(
        self,
        diff: Diff,
        *,
        pr_title: str | None = None,
        pr_description: str | None = None,
    ) -> list[Finding]:
        if not diff.files:
            log.info("AgenticReviewer: empty diff; nothing to review")
            return []

        report_tool = ReportFindingTool()
        tools: list[Tool] = [
            SearchDecisionsTool(self.store),
            report_tool,
        ]
        if self.graph is not None:
            tools.append(ImpactZoneTool(self.graph))
        if self.repo_root is not None:
            tools.append(ReadFileContextTool(self.repo_root))

        loop = AgentLoop(
            llm=self.llm,
            tools=tools,
            system=AGENTIC_SYSTEM,
            max_iterations=self.max_iterations,
        )
        sections = [AGENTIC_USER_PREFIX.rstrip()]
        ctx = _format_pr_context(pr_title, pr_description)
        if ctx:
            sections.append(ctx)
        sections.append("## DIFF\n\n" + _format_diff(diff))
        user_msg = "\n\n".join(sections)
        result = loop.run(user_msg)

        log.info(
            "AgenticReviewer: %d iter(s), %d tool call(s), %d raw finding(s), "
            "%d input + %d output tokens",
            result.iterations,
            result.tool_calls_made,
            len(report_tool.findings),
            result.total_input_tokens,
            result.total_output_tokens,
        )

        # Apply post-hoc filters — the same min_confidence + max_findings
        # rules the pipeline reviewer enforces, so the model can't bypass
        # the configured precision floor.
        findings = [f for f in report_tool.findings if f.confidence >= self.min_confidence]
        findings.sort(key=lambda f: f.confidence, reverse=True)
        return findings[: self.max_findings]


def _format_diff(diff: Diff) -> str:
    parts: list[str] = []
    chars_used = 0
    for f in diff.files:
        block = f"### `{f.path}` (+{f.additions} -{f.deletions})\n```diff\n{f.patch}\n```"
        if chars_used + len(block) > MAX_DIFF_CHARS:
            parts.append(
                f"\n... [{len(diff.files) - len(parts)} more file(s) truncated for context budget]"
            )
            break
        parts.append(block)
        chars_used += len(block)
    return "\n\n".join(parts)


_PR_DESCRIPTION_BUDGET = 4000


def _format_pr_context(title: str | None, body: str | None) -> str:
    """Render the author's stated intent so the agent can weigh it heavily.

    A PR description that already explains a change is the strongest signal
    against firing a "regression" finding for that same change.
    """
    if not title and not body:
        return ""
    out = ["## AUTHOR'S STATED INTENT (current PR)\n"]
    if title:
        out.append(f"**Title:** {title}\n")
    if body:
        clipped = body.strip()
        if len(clipped) > _PR_DESCRIPTION_BUDGET:
            clipped = clipped[:_PR_DESCRIPTION_BUDGET].rstrip() + "\n... [truncated]"
        out.append("**Description:**\n")
        out.append(clipped)
    out.append(
        "\n\n_Weigh this heavily: if the author explicitly documents the change "
        "or its rationale below, the change is intentional, not a regression. "
        "Only flag if you find a distinct decision elsewhere that contradicts the diff._"
    )
    return "\n".join(out)
