"""Async MCP client for GitNexus.

We call GitNexus's real tool surface (verified against the running binary):

- ``impact(target_uid="File:<repo-relative-path>")`` — returns ``{target,
  impactedCount, risk, byDepth: {1: [...], 2: [...]}, ...}``. We aggregate
  across the diff's changed paths and trim by ``hops`` (== max byDepth key
  to include).

The earlier code called ``impact_zone`` / ``search_nodes`` — names that
don't exist on the GitNexus MCP server. The server returned
``isError=True`` and our parser swallowed it, yielding empty
``ImpactZone`` objects forever. Now we check ``isError`` on every call
and verify the expected tool exists at connection time so future renames
fail loud.
"""

from __future__ import annotations

import json
import logging
from contextlib import AsyncExitStack
from typing import Any

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

from adrift.graph.base import GraphNode, ImpactZone

log = logging.getLogger(__name__)


TOOL_IMPACT = "impact"


class GitNexusMCPClient:
    """Async MCP client wrapping a GitNexus server.

    Use as an async context manager::

        async with GitNexusMCPClient("gitnexus", ["mcp"]) as client:
            zone = await client.impact_zone(["src/foo.py"])
    """

    def __init__(self, command: str, args: list[str] | None = None):
        self.command = command
        self.args = args or []
        self._stack: AsyncExitStack | None = None
        self._session: ClientSession | None = None

    async def __aenter__(self) -> GitNexusMCPClient:
        stack = AsyncExitStack()
        try:
            params = StdioServerParameters(command=self.command, args=self.args)
            read, write = await stack.enter_async_context(stdio_client(params))
            session = await stack.enter_async_context(ClientSession(read, write))
            await session.initialize()
            self._session = session
            self._stack = stack
            await self._verify_tools(session)
            log.info("Connected to GitNexus MCP at `%s %s`", self.command, " ".join(self.args))
        except Exception:
            await stack.aclose()
            raise
        return self

    async def __aexit__(self, *exc: Any) -> None:
        if self._stack is not None:
            await self._stack.aclose()
        self._stack = None
        self._session = None

    async def list_tools(self) -> list[str]:
        session = self._require_session()
        result = await session.list_tools()
        return [t.name for t in result.tools]

    async def impact_zone(self, paths: list[str], hops: int = 1) -> ImpactZone:
        """Aggregate ``impact`` results for each changed file.

        We pass ``target_uid="File:<path>"`` (GitNexus's canonical file-node
        identifier) per path. Each response carries a ``target`` (the file
        node, kept as a "changed" node) and a ``byDepth`` map of neighbors.
        We include neighbors up to ``hops`` levels deep, deduped across paths.
        """
        session = self._require_session()
        changed: list[GraphNode] = []
        neighbors: list[GraphNode] = []
        seen_changed: set[str] = set()
        seen_neighbors: set[str] = set()

        for path in paths:
            try:
                result = await session.call_tool(TOOL_IMPACT, {"target_uid": f"File:{path}"})
            except Exception as e:
                log.warning("GitNexus impact() call failed for %s: %s", path, e)
                continue
            if getattr(result, "isError", False):
                log.warning(
                    "GitNexus impact(target_uid=File:%s) returned isError; skipping (content: %s)",
                    path,
                    _first_text(result.content)[:200],
                )
                continue
            payload = _extract_json(result.content)
            if not isinstance(payload, dict):
                continue
            if isinstance(payload.get("error"), str):
                # GitNexus returns 200/no-isError but a body like
                # {"error": "Target ... not found"} when a path isn't in the
                # graph yet. Skip without polluting the result.
                log.debug("GitNexus impact for %s: %s", path, payload["error"])
                continue
            target_node = _node_from_target(payload.get("target"))
            if target_node and target_node.id not in seen_changed:
                changed.append(target_node)
                seen_changed.add(target_node.id)
            for depth_key, items in (payload.get("byDepth") or {}).items():
                try:
                    depth = int(depth_key)
                except (TypeError, ValueError):
                    continue
                if depth > hops:
                    continue
                for item in items or []:
                    node = _node_from_neighbor(item)
                    if node and node.id and node.id not in seen_neighbors:
                        neighbors.append(node)
                        seen_neighbors.add(node.id)

        return ImpactZone(changed=changed, neighbors=neighbors)

    def _require_session(self) -> ClientSession:
        if self._session is None:
            raise RuntimeError(
                "GitNexusMCPClient is not connected; use it as an async context manager"
            )
        return self._session

    async def _verify_tools(self, session: ClientSession) -> None:
        """Fail loud at connect time if the tool we depend on is missing.

        Without this, a renamed/removed tool on the server would silently
        produce empty impact zones forever (the bug that hid the entire
        Phase 2 integration being non-functional through 0.1.x).
        """
        result = await session.list_tools()
        names = {t.name for t in result.tools}
        if TOOL_IMPACT not in names:
            raise RuntimeError(
                f"GitNexus MCP server is missing required tool {TOOL_IMPACT!r}. "
                f"Available tools: {sorted(names)}. Is your gitnexus version "
                f"compatible with this adrift release?"
            )


def _node_from_target(target: Any) -> GraphNode | None:
    """Build a GraphNode from GitNexus's ``target`` block.

    Shape: ``{"id": "File:adrift/cli.py", "name": "cli.py",
              "type": "" | "Class" | "Function" | ..., "filePath": "adrift/cli.py"}``
    """
    if not isinstance(target, dict):
        return None
    node_id = target.get("id")
    if not isinstance(node_id, str) or not node_id:
        return None
    try:
        return GraphNode(
            id=node_id,
            type=(target.get("type") or "file").lower() or "file",
            name=target.get("name") or "",
            file_path=target.get("filePath") or "",
        )
    except Exception:
        log.debug("Skipping malformed target payload: %r", target)
        return None


def _node_from_neighbor(item: Any) -> GraphNode | None:
    """Build a GraphNode from a ``byDepth`` entry.

    Shape: ``{"depth": 1, "id": "File:adrift/models.py", "name": "models.py",
              "filePath": "adrift/models.py", "relationType": "IMPORTS",
              "confidence": 1.0}``
    """
    if not isinstance(item, dict):
        return None
    node_id = item.get("id")
    if not isinstance(node_id, str) or not node_id:
        return None
    kind = node_id.split(":", 1)[0].lower() if ":" in node_id else "node"
    try:
        return GraphNode(
            id=node_id,
            type=kind,
            name=item.get("name") or "",
            file_path=item.get("filePath") or "",
        )
    except Exception:
        log.debug("Skipping malformed neighbor payload: %r", item)
        return None


def _first_text(content: Any) -> str:
    if isinstance(content, list):
        for item in content:
            text = _block_text(item)
            if text is not None:
                return text
    return ""


def _extract_json(content: Any) -> Any:
    """Pull a JSON payload out of an MCP tool response.

    MCP tool results commonly arrive as a list of content blocks (TextContent,
    ImageContent, ...). We look at every text block for valid JSON. GitNexus
    sometimes appends prose (``---\n**Next:** ...``) after the JSON object;
    we tolerate that by extracting up to the matching closing brace.
    """
    if isinstance(content, list):
        for item in content:
            text = _block_text(item)
            if text is None:
                continue
            parsed = _parse_json_prefix(text)
            if parsed is not None:
                return parsed
        return {}
    if isinstance(content, dict):
        return content
    if isinstance(content, str):
        return _parse_json_prefix(content) or {}
    return {}


def _parse_json_prefix(text: str) -> Any:
    """Try ``json.loads`` whole-string first, then a balanced-braces prefix.

    GitNexus tool responses are JSON followed by a markdown ``---\n**Next:**``
    hint, which makes whole-string parsing fail. We find the JSON object/array
    by scanning for balanced braces from the first ``{`` or ``[``.
    """
    text = text.strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    # Find balanced object or array prefix.
    start = -1
    open_ch = ""
    close_ch = ""
    for i, ch in enumerate(text):
        if ch in "{[":
            start = i
            open_ch = ch
            close_ch = "}" if ch == "{" else "]"
            break
    if start < 0:
        return None
    depth = 0
    in_str = False
    esc = False
    for i in range(start, len(text)):
        ch = text[i]
        if esc:
            esc = False
            continue
        if ch == "\\" and in_str:
            esc = True
            continue
        if ch == '"':
            in_str = not in_str
            continue
        if in_str:
            continue
        if ch == open_ch:
            depth += 1
        elif ch == close_ch:
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(text[start : i + 1])
                except json.JSONDecodeError:
                    return None
    return None


def _block_text(block: Any) -> str | None:
    if isinstance(block, dict):
        text = block.get("text")
        return text if isinstance(text, str) else None
    text = getattr(block, "text", None)
    return text if isinstance(text, str) else None
