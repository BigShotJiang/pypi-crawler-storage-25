"""Graph protocol and shared models.

``GraphClient`` is the abstraction over any code-knowledge-graph backend.
Phase 2 ships only the GitNexus implementation; future backends (SCIP,
stack-graphs, custom indexers) implement the same protocol.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from pydantic import BaseModel, Field


class GraphNode(BaseModel):
    """A node in the code knowledge graph."""

    id: str
    type: str  # "function" | "class" | "method" | "file" | "module" | other
    name: str
    file_path: str
    language: str | None = None

    def short_label(self) -> str:
        return f"{self.type}:{self.name}@{self.file_path}"


class ImpactZone(BaseModel):
    """The set of nodes touched by a diff plus their immediate neighborhood.

    `changed` are nodes directly modified by the diff. `neighbors` are the
    callers/callees / importers reachable within the configured hop budget.
    """

    changed: list[GraphNode] = Field(default_factory=list)
    neighbors: list[GraphNode] = Field(default_factory=list)

    def all_nodes(self) -> list[GraphNode]:
        return [*self.changed, *self.neighbors]

    def all_files(self) -> set[str]:
        return {n.file_path for n in self.all_nodes()}

    def __bool__(self) -> bool:
        return bool(self.changed or self.neighbors)


@runtime_checkable
class GraphClient(Protocol):
    """Code-graph backend abstraction.

    Implementations are responsible for translating into whatever backend
    protocol they use (MCP, gRPC, in-process). The pipeline only depends
    on this surface.
    """

    def impact_zone(self, paths: list[str], hops: int = 1) -> ImpactZone: ...
