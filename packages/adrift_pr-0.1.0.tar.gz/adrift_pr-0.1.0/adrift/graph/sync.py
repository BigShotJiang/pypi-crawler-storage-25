"""Sync facade for the async ``GitNexusMCPClient``.

The MCP SDK's ``stdio_client`` uses ``anyio.create_task_group()`` with a
cancel scope. anyio records which asyncio task entered the cancel scope and
rejects any other task from exiting it — surfacing as::

    RuntimeError: Attempted to exit cancel scope in a different task than
    it was entered in.

A single event loop is not enough: every ``asyncio.run_coroutine_threadsafe``
schedules its coroutine as a *new* task inside the loop, so the open call,
each tool query, and the close call would all run in different tasks.

The pattern that actually works: one long-running "session task" in a
background-thread event loop. The session task enters the MCP session,
then drains a queue of (callable, future) commands one at a time, awaiting
each. The async context is entered, used, and exited inside that single
task, so anyio's cancel scope sees consistent task identity. Sync methods
push commands onto the queue and block on their future.
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import contextlib
import logging
import threading
from collections.abc import Awaitable, Callable
from typing import Any

from adrift.graph.base import ImpactZone
from adrift.graph.mcp_client import GitNexusMCPClient

log = logging.getLogger(__name__)


# Sentinel that tells the session task to exit the async context and finish.
_SHUTDOWN = object()


class SyncGitNexusClient:
    """Synchronous facade over ``GitNexusMCPClient``.

    Use as a regular context manager::

        with SyncGitNexusClient("gitnexus", ["mcp"]) as client:
            zone = client.impact_zone(["src/foo.py"])
    """

    _LOOP_STARTUP_TIMEOUT = 10.0
    _ENTER_TIMEOUT = 30.0
    _CALL_TIMEOUT = 60.0
    _SHUTDOWN_TIMEOUT = 10.0

    def __init__(self, command: str, args: list[str] | None = None):
        self._async = GitNexusMCPClient(command, args)
        self._loop: asyncio.AbstractEventLoop | None = None
        self._thread: threading.Thread | None = None
        self._loop_ready = threading.Event()
        self._enter_done = threading.Event()
        self._enter_error: BaseException | None = None
        self._command_queue: asyncio.Queue | None = None
        self._session_future: concurrent.futures.Future | None = None

    # --- Context-manager surface --------------------------------------------

    def __enter__(self) -> SyncGitNexusClient:
        self._start_loop_thread()
        # Schedule the single long-running task that owns the MCP session.
        assert self._loop is not None
        self._session_future = asyncio.run_coroutine_threadsafe(self._session_task(), self._loop)
        # Wait until the session task signals it has entered the async context
        # (or failed trying).
        if not self._enter_done.wait(timeout=self._ENTER_TIMEOUT):
            self._stop_loop_thread()
            raise RuntimeError("GitNexus MCP session did not start within timeout")
        if self._enter_error is not None:
            err = self._enter_error
            self._stop_loop_thread()
            raise err
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        if self._session_future is None:
            return
        if self._command_queue is not None and self._loop is not None:
            # Tell the session task to leave its main loop and exit the async
            # context. We schedule the put() into the loop because asyncio
            # queues are not thread-safe.
            with contextlib.suppress(Exception):
                asyncio.run_coroutine_threadsafe(
                    self._command_queue.put(_SHUTDOWN), self._loop
                ).result(timeout=5.0)
        # Wait for the session task to finish (it will close the MCP session
        # cleanly on its way out via the ``async with self._async`` block).
        with contextlib.suppress(Exception):
            self._session_future.result(timeout=self._SHUTDOWN_TIMEOUT)
        self._stop_loop_thread()

    # --- Sync mirror of the async API ---------------------------------------

    def list_tools(self) -> list[str]:
        return self._submit(lambda: self._async.list_tools())

    def impact_zone(self, paths: list[str], hops: int = 1) -> ImpactZone:
        return self._submit(lambda: self._async.impact_zone(paths, hops))

    # --- Internals ----------------------------------------------------------

    async def _session_task(self) -> None:
        """The single async task that owns the MCP session for its lifetime."""
        self._command_queue = asyncio.Queue()
        try:
            async with self._async:
                # Entered successfully. Unblock the main thread's __enter__.
                self._enter_done.set()
                while True:
                    item = await self._command_queue.get()
                    if item is _SHUTDOWN:
                        return
                    factory, fut = item
                    try:
                        result = await factory()
                        fut.set_result(result)
                    except BaseException as e:
                        fut.set_exception(e)
        except BaseException as e:
            # Failure before we entered the context: report it back to __enter__.
            if not self._enter_done.is_set():
                self._enter_error = e
                self._enter_done.set()
                return
            # Failure after entry: re-raise so the wrapping future captures it.
            raise

    def _submit(self, factory: Callable[[], Awaitable[Any]]) -> Any:
        if self._loop is None or self._command_queue is None:
            raise RuntimeError("SyncGitNexusClient is not entered")
        fut: concurrent.futures.Future = concurrent.futures.Future()
        # Push the command onto the asyncio queue (from outside the loop's
        # thread, which requires the threadsafe scheduling helper).
        try:
            asyncio.run_coroutine_threadsafe(
                self._command_queue.put((factory, fut)), self._loop
            ).result(timeout=5.0)
        except Exception as e:
            raise RuntimeError(f"failed to enqueue MCP call: {e}") from e

        try:
            return fut.result(timeout=self._CALL_TIMEOUT)
        except concurrent.futures.TimeoutError as e:
            fut.cancel()
            raise RuntimeError(f"GitNexus call did not return within {self._CALL_TIMEOUT}s") from e

    # --- Loop lifecycle -----------------------------------------------------

    def _start_loop_thread(self) -> None:
        def _run() -> None:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            self._loop = loop
            self._loop_ready.set()
            try:
                loop.run_forever()
            finally:
                loop.close()

        self._thread = threading.Thread(target=_run, name="adrift-gitnexus-mcp", daemon=True)
        self._thread.start()
        if not self._loop_ready.wait(timeout=self._LOOP_STARTUP_TIMEOUT):
            raise RuntimeError("background event loop failed to start")
        log.debug("SyncGitNexusClient: background event loop ready")

    def _stop_loop_thread(self) -> None:
        loop = self._loop
        thread = self._thread
        self._loop = None
        self._thread = None
        self._loop_ready.clear()
        self._enter_done.clear()
        self._enter_error = None
        self._command_queue = None
        self._session_future = None
        if loop is None or thread is None:
            return
        with contextlib.suppress(RuntimeError):
            loop.call_soon_threadsafe(loop.stop)
        thread.join(timeout=5.0)
        if thread.is_alive():
            log.warning("background event loop thread did not exit cleanly")
