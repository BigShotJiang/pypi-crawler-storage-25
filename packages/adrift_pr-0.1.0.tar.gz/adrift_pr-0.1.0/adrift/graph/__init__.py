"""Code graph layer — currently backed by GitNexus over MCP.

Public surface:
- ``GraphClient`` (Protocol): abstract code-graph backend.
- ``ImpactZone`` / ``GraphNode`` (models): what every backend returns.
- ``SyncGitNexusClient``: sync facade over the async MCP client; what the
  CLI and pipeline actually instantiate.
"""

from adrift.graph.base import GraphClient, GraphNode, ImpactZone
from adrift.graph.sync import SyncGitNexusClient

__all__ = ["GraphClient", "GraphNode", "ImpactZone", "SyncGitNexusClient"]
