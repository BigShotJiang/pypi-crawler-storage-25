"""MarkdownMiner — walks every ``.md`` file in the repo, section-splits by H2,
and yields each section as a candidate for the classifier.

We over-emit on purpose: README's "Why this exists" is decision-bearing,
CHANGELOG's per-version blocks often capture deliberate trade-offs, and
``docs/**/*.md`` is full of architectural prose. The classifier (biased
strongly toward NO) decides which sections become MINED decisions.

``CLAUDE.md`` and ``AGENTS.md`` are handled separately by ``MarkdownSource``
(EXPLICIT tier); we skip them here to avoid double-indexing. ``docs/adr/`` and
``decisions/`` are handled by ``ADRSource`` and similarly skipped.
"""

from __future__ import annotations

import logging
import re
from collections.abc import Iterable, Iterator
from datetime import datetime
from pathlib import Path

from adrift.models import CandidateDecision
from adrift.sources.markdown import EXPLICIT_FILENAMES

log = logging.getLogger(__name__)


# Directories to skip wholesale, regardless of depth.
SKIP_DIR_NAMES = frozenset(
    {
        ".git",
        ".venv",
        "venv",
        "env",
        "node_modules",
        "__pycache__",
        ".mypy_cache",
        ".ruff_cache",
        ".pytest_cache",
        "dist",
        "build",
        "target",
        "site-packages",
        "vendor",
        ".gitnexus",
        ".adrift",
        ".claude",
        ".github",  # workflow YAML is not markdown; any docs we put there aren't decision content
    }
)

# Path-prefix patterns (relative to repo root) already handled by ADRSource.
ADR_PREFIXES = ("docs/adr/", "decisions/", "docs/decisions/")

# Minimum char count for a section to be a candidate. Smaller than PR floor
# because markdown sections are typically prose-dense.
_DEFAULT_MIN_SECTION_CHARS = 120

# H2 (## ...) is the primary split boundary. We deliberately don't split on
# H3+ — that fragments cohesive sections.
_H2_RE = re.compile(r"^##\s+(?P<title>.+?)\s*$")
_H1_RE = re.compile(r"^#\s+(?P<title>.+?)\s*$")


class MarkdownMiner:
    """Yields one CandidateDecision per H2 section across all .md files."""

    name = "markdown"

    def __init__(
        self,
        root: Path,
        *,
        min_section_chars: int = _DEFAULT_MIN_SECTION_CHARS,
        extra_skip_prefixes: Iterable[str] = (),
    ):
        self.root = Path(root)
        self.min_section_chars = min_section_chars
        self._skip_prefixes = tuple(ADR_PREFIXES) + tuple(extra_skip_prefixes)

    def mine(self) -> Iterator[CandidateDecision]:
        if not self.root.is_dir():
            log.debug("MarkdownMiner root %s missing; skipping", self.root)
            return
        scanned = 0
        emitted = 0
        for path in _walk_markdown(self.root):
            scanned += 1
            for candidate in self._candidates_from_file(path):
                emitted += 1
                yield candidate
        log.info("MarkdownMiner: scanned %d file(s), emitted %d section(s)", scanned, emitted)

    def _candidates_from_file(self, path: Path) -> Iterator[CandidateDecision]:
        rel = path.relative_to(self.root)
        rel_str = str(rel).replace("\\", "/")
        if rel.name in EXPLICIT_FILENAMES:
            return  # handled by MarkdownSource (EXPLICIT tier)
        if any(rel_str.startswith(p) for p in self._skip_prefixes):
            return  # handled by ADRSource

        try:
            text = path.read_text(encoding="utf-8")
        except OSError:
            log.warning("MarkdownMiner: failed to read %s", path, exc_info=True)
            return

        try:
            created_at = datetime.fromtimestamp(path.stat().st_mtime)
        except OSError:
            created_at = datetime.now()

        for section_title, section_body in _split_into_sections(text):
            stripped = section_body.strip()
            if len(stripped) < self.min_section_chars:
                continue
            title = section_title or _file_fallback_title(path) or rel.stem
            # Source identifies file + section so feedback / supersession is precise.
            source = f"{rel_str}#{_slug(section_title)}" if section_title else rel_str
            yield CandidateDecision(
                title=_truncate_title(title),
                body=stripped,
                source=source,
                created_at=created_at,
            )


def _walk_markdown(root: Path) -> Iterator[Path]:
    """Yield every .md / .MD file under ``root`` skipping ignored directories."""
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        if path.suffix.lower() != ".md":
            continue
        # Reject if any path component is on the skip list.
        if any(part in SKIP_DIR_NAMES for part in path.relative_to(root).parts[:-1]):
            continue
        yield path


def _split_into_sections(text: str) -> Iterator[tuple[str | None, str]]:
    """Yield ``(section_title, section_body)`` pairs split on H2 boundaries.

    Content before the first H2 (often the H1 title + intro) is yielded as
    ``(None, body)`` so files with no H2 still surface as a single candidate.
    """
    lines = text.splitlines()
    buf: list[str] = []
    current_title: str | None = None
    for line in lines:
        m = _H2_RE.match(line)
        if m:
            if buf:
                yield current_title, "\n".join(buf).strip()
            current_title = m["title"].strip()
            buf = []
            continue
        buf.append(line)
    if buf:
        yield current_title, "\n".join(buf).strip()


def _file_fallback_title(path: Path) -> str | None:
    """Use the H1 of the file as the title for the lead (pre-H2) section."""
    try:
        with path.open("r", encoding="utf-8") as f:
            for line in f:
                m = _H1_RE.match(line)
                if m:
                    return m["title"].strip()
    except OSError:
        return None
    return None


_SLUG_RE = re.compile(r"[^a-z0-9]+")


def _slug(title: str | None) -> str:
    if not title:
        return ""
    return _SLUG_RE.sub("-", title.lower()).strip("-")[:60]


def _truncate_title(title: str, limit: int = 120) -> str:
    return title if len(title) <= limit else title[: limit - 1].rstrip() + "…"
