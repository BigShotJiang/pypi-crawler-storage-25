"""PRBundleMiner — emits one candidate per merged PR, bundling everything that
PR encodes about the team's intent.

A pull request is the natural unit of a deliberate change. The PR
description states the goal. The review comments encode the deliberation
("why not X?" → "because Y"). The commit messages capture the
implementation rationale and any in-flight reversals. Bundling all three
into one candidate gives the classifier the whole story — and gives the
mined decision body real "why" content, not just "what".

This replaces ``PRDescriptionMiner`` (which only used title + body).
"""

from __future__ import annotations

import logging
from collections.abc import Iterator
from dataclasses import dataclass

from github import Auth, Github
from github.GithubException import GithubException

from adrift.models import CandidateDecision

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class RepoRef:
    owner: str
    repo: str

    def full_name(self) -> str:
        return f"{self.owner}/{self.repo}"


# Each comment / commit message contributes to the bundle. We cap the total
# size so a huge PR doesn't blow up classifier context.
_MAX_BUNDLE_CHARS = 8000
_MAX_PER_SECTION_CHARS = 3000


class PRBundleMiner:
    """For each PR, build a single bundled candidate.

    Bundle layout (Markdown, what the classifier sees)::

        PR #N: <title>

        ## Description
        <body>

        ## Commits
        - <subject 1>
          <continuation>
        - <subject 2>

        ## Review discussion
        <author 1>: <comment>
        <author 2>: <comment>
    """

    name = "pr_bundles"

    def __init__(
        self,
        token: str,
        repo: RepoRef,
        *,
        limit: int = 100,
        state: str = "closed",
        min_bundle_chars: int = 80,
        include_review_comments: bool = True,
        include_issue_comments: bool = True,
        include_commits: bool = True,
    ):
        if not token:
            raise ValueError("GitHub token is required")
        self._gh = Github(auth=Auth.Token(token))
        self.repo = repo
        self.limit = limit
        self.state = state
        self.min_bundle_chars = min_bundle_chars
        self.include_review_comments = include_review_comments
        self.include_issue_comments = include_issue_comments
        self.include_commits = include_commits

    # --- Public API -----------------------------------------------------

    def mine(self) -> Iterator[CandidateDecision]:
        try:
            repo = self._gh.get_repo(self.repo.full_name())
        except GithubException as e:
            raise RuntimeError(f"Failed to access repo {self.repo.full_name()}: {e}") from e

        prs = repo.get_pulls(state=self.state, sort="updated", direction="desc")
        seen = 0
        emitted = 0
        for pr in prs:
            if seen >= self.limit:
                break
            seen += 1
            candidate = self._candidate_from_pr(pr)
            if candidate is None:
                continue
            emitted += 1
            yield candidate
        log.info(
            "PRBundleMiner: scanned %d PR(s), emitted %d candidate bundle(s) from %s",
            seen,
            emitted,
            self.repo.full_name(),
        )

    def mine_one(self, pr_number: int) -> CandidateDecision | None:
        """Mine a single PR by number — used by the per-PR incremental step in CI."""
        try:
            repo = self._gh.get_repo(self.repo.full_name())
            pr = repo.get_pull(pr_number)
        except GithubException as e:
            raise RuntimeError(
                f"Failed to fetch PR {self.repo.full_name()}#{pr_number}: {e}"
            ) from e
        candidate = self._candidate_from_pr(pr)
        if candidate is None:
            log.info(
                "PRBundleMiner.mine_one: %s#%d bundle too thin; skipping",
                self.repo.full_name(),
                pr_number,
            )
        else:
            log.info(
                "PRBundleMiner.mine_one: emitted bundle for %s#%d (%d chars)",
                self.repo.full_name(),
                pr_number,
                len(candidate.body),
            )
        return candidate

    # --- Internal -------------------------------------------------------

    def _candidate_from_pr(self, pr) -> CandidateDecision | None:
        title = pr.title or f"PR #{pr.number}"
        description = (pr.body or "").strip()

        commit_lines: list[str] = []
        if self.include_commits:
            try:
                commits = list(pr.get_commits())
            except GithubException as e:
                log.warning("PRBundleMiner: failed to list commits on PR #%d: %s", pr.number, e)
                commits = []
            for c in commits:
                commit_msg = (c.commit.message or "").strip()
                if not commit_msg:
                    continue
                commit_lines.append(_format_commit(commit_msg))

        review_lines: list[str] = []
        if self.include_review_comments:
            try:
                for rc in pr.get_review_comments():
                    body = (rc.body or "").strip()
                    if not body:
                        continue
                    author = rc.user.login if rc.user else "unknown"
                    review_lines.append(f"{author}: {body}")
            except GithubException as e:
                log.warning(
                    "PRBundleMiner: failed to list review comments on PR #%d: %s", pr.number, e
                )
        if self.include_issue_comments:
            try:
                for ic in pr.get_issue_comments():
                    body = (ic.body or "").strip()
                    if not body or body.startswith("<!-- adrift"):  # skip our own bot comments
                        continue
                    author = ic.user.login if ic.user else "unknown"
                    review_lines.append(f"{author}: {body}")
            except GithubException as e:
                log.warning(
                    "PRBundleMiner: failed to list issue comments on PR #%d: %s", pr.number, e
                )

        body = _format_bundle(
            pr.number,
            title,
            description,
            commit_lines,
            review_lines,
        )
        if len(body.strip()) < self.min_bundle_chars:
            return None
        return CandidateDecision(
            title=title,
            body=body,
            source=f"github://{self.repo.full_name()}/pull/{pr.number}",
            created_at=pr.created_at,
        )


# --- Formatting -----------------------------------------------------------


def _format_bundle(
    number: int,
    title: str,
    description: str,
    commit_lines: list[str],
    review_lines: list[str],
) -> str:
    parts: list[str] = [f"PR #{number}: {title}", ""]
    if description:
        parts.append("## Description")
        parts.append(_clip(description, _MAX_PER_SECTION_CHARS))
        parts.append("")
    if commit_lines:
        parts.append("## Commits")
        parts.append(_clip("\n".join(commit_lines), _MAX_PER_SECTION_CHARS))
        parts.append("")
    if review_lines:
        parts.append("## Review discussion")
        parts.append(_clip("\n\n".join(review_lines), _MAX_PER_SECTION_CHARS))
        parts.append("")
    return _clip("\n".join(parts).rstrip(), _MAX_BUNDLE_CHARS)


def _format_commit(message: str) -> str:
    """Render a commit message as a bullet, indenting continuation lines."""
    lines = message.splitlines()
    if not lines:
        return ""
    subject = lines[0].strip()
    rest = [ln.rstrip() for ln in lines[1:] if ln.strip()]
    if not rest:
        return f"- {subject}"
    return "- " + subject + "\n" + "\n".join("  " + ln for ln in rest)


def _clip(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    return text[: limit - 1].rstrip() + "…"
