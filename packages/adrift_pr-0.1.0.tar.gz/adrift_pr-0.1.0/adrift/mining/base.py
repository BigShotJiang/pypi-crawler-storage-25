"""Miner protocol — any source that yields candidate decisions.

Miners produce raw candidates (PR descriptions, commit messages, review
comments). A separate ``DecisionClassifier`` decides which of those candidates
are actually decision-bearing and worth persisting.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Protocol, runtime_checkable

from adrift.models import CandidateDecision


@runtime_checkable
class Miner(Protocol):
    """Yields candidate decisions for downstream classification."""

    name: str

    def mine(self) -> Iterator[CandidateDecision]: ...
