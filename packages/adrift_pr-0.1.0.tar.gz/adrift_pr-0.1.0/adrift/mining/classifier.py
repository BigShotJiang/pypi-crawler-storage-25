"""DecisionClassifier — LLM-driven, strict-precision filter on candidate decisions.

Bias is intentionally heavy toward "not a decision." A poisoned decision
store causes false positives that compound into reviewer fatigue, which
makes the feedback loop in Phase 4 useless. Better to miss real decisions
than to admit non-decisions.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re

from adrift.llm import LLMClient
from adrift.models import CandidateDecision, Decision, DecisionTier
from adrift.prompts import CLASSIFY_SYSTEM, CLASSIFY_USER

log = logging.getLogger(__name__)


class DecisionClassifier:
    """Classifies a ``CandidateDecision`` as a real decision (or not)."""

    def __init__(self, llm: LLMClient, *, min_confidence: float = 0.7):
        self.llm = llm
        self.min_confidence = min_confidence

    def classify(self, candidate: CandidateDecision) -> Decision | None:
        prompt = CLASSIFY_USER.format(
            source=candidate.source,
            title=candidate.title,
            body=_truncate(candidate.body, 4000),
        )
        try:
            response = self.llm.complete(prompt, system=CLASSIFY_SYSTEM)
        except Exception:
            log.warning("Classifier LLM call failed for %s", candidate.source, exc_info=True)
            return None

        data = _parse_json(response.content)
        if not data.get("is_decision"):
            return None

        try:
            confidence = float(data.get("confidence", 0.0))
        except (TypeError, ValueError):
            return None
        if confidence < self.min_confidence:
            log.debug(
                "Classifier: dropping %s (confidence %.2f below threshold %.2f)",
                candidate.source,
                confidence,
                self.min_confidence,
            )
            return None

        title = str(data.get("title", "") or candidate.title).strip()[:200]
        quotes = _coerce_quotes(data.get("verbatim_quotes"), candidate.body)
        claim_type = str(data.get("claim_type", "")).strip()[:40]
        scope_paths = _coerce_scope_paths(data.get("scope_paths"))

        # Body for storage. The classifier's verbatim quotes come first
        # because the agentic reviewer (which sees these decisions during
        # search_decisions calls) needs to quote them character-for-character
        # in any finding. Paraphrases caused real false positives before
        # this refactor.
        composed_body = _compose_body(
            quotes=quotes,
            claim_type=claim_type,
            scope_paths=scope_paths,
            original=candidate.body,
        )

        return Decision(
            id=_stable_id(candidate.source, candidate.body),
            title=title or candidate.title[:200],
            body=composed_body,
            source=candidate.source,
            tier=DecisionTier.MINED,
            created_at=candidate.created_at,
            weight=confidence,  # carry classifier confidence as weight
        )


_JSON_FENCE_RE = re.compile(r"^```(?:json)?\s*(.*?)\s*```$", re.DOTALL)


def _parse_json(raw: str) -> dict[str, object]:
    s = raw.strip()
    if not s:
        return {}
    m = _JSON_FENCE_RE.match(s)
    if m:
        s = m.group(1).strip()
    if not s.startswith("{"):
        start = s.find("{")
        if start == -1:
            return {}
        s = s[start:]
    try:
        result = json.loads(s)
    except json.JSONDecodeError as e:
        log.warning("Failed to decode classifier JSON: %s", e)
        return {}
    return result if isinstance(result, dict) else {}


def _truncate(text: str, max_chars: int) -> str:
    return text if len(text) <= max_chars else text[:max_chars] + "\n... [truncated]"


def _stable_id(source: str, body: str) -> str:
    """ID stable across reclassifications: ``mined-<sha1[:12]>``."""
    h = hashlib.sha1(f"{source}\n{body}".encode()).hexdigest()[:12]
    return f"mined-{h}"


def _coerce_quotes(raw: object, source_body: str) -> list[str]:
    """Validate ``verbatim_quotes`` from the classifier response.

    Every quote MUST appear verbatim (case-insensitive, whitespace-normalized)
    in the source body. Anything that doesn't is silently dropped — the
    classifier hallucinated it. This is the front-line defense against
    paraphrased "decisions" the bot will later defend as if the author wrote
    them.
    """
    if not isinstance(raw, list):
        return []
    normalized_source = " ".join(source_body.split()).lower()
    accepted: list[str] = []
    for item in raw:
        if not isinstance(item, str):
            continue
        quote = item.strip()
        if not quote or len(quote) > 600:
            continue
        normalized_quote = " ".join(quote.split()).lower()
        if normalized_quote in normalized_source:
            accepted.append(quote)
        else:
            log.debug("Dropping non-verbatim quote: %r", quote[:80])
    return accepted[:3]  # cap; if the classifier offers 10 quotes something is off


def _coerce_scope_paths(raw: object) -> list[str]:
    if not isinstance(raw, list):
        return []
    return [p.strip() for p in raw if isinstance(p, str) and p.strip()][:10]


def _compose_body(
    *,
    quotes: list[str],
    claim_type: str,
    scope_paths: list[str],
    original: str,
) -> str:
    """Render the decision body. Verbatim quotes lead so downstream consumers
    (the LLM judge, the agentic reviewer's search results) see ground truth
    before any inferred metadata.
    """
    parts: list[str] = []
    if quotes:
        parts.append("**Verbatim from the source:**")
        for q in quotes:
            parts.append(f"> {q}")
        parts.append("")
    meta_bits = []
    if claim_type:
        meta_bits.append(f"claim_type: {claim_type}")
    if scope_paths:
        meta_bits.append(f"scope_paths: {', '.join(scope_paths)}")
    if meta_bits:
        parts.append("_" + " · ".join(meta_bits) + "_")
        parts.append("")
    parts.append("---")
    parts.append("")
    parts.append(original)
    return "\n".join(parts)
