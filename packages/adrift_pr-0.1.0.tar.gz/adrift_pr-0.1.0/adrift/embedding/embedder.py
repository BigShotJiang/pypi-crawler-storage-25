"""Embedder — thin wrapper around fastembed.

Model is loaded lazily on first ``embed`` / ``embed_batch`` / ``dim`` call.
fastembed downloads the model to a local cache on first use (~80 MB for the
default ``bge-small-en-v1.5``); subsequent runs hit the cache.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fastembed import TextEmbedding

log = logging.getLogger(__name__)

DEFAULT_MODEL = "BAAI/bge-small-en-v1.5"
DEFAULT_DIM = 384  # dimension of the default model output


class Embedder:
    """Encode text to dense vectors. Returns plain Python lists (JSON-safe).

    Designed so the heavy import (``fastembed`` → onnxruntime) only happens
    when an embedding is actually requested. Callers that only construct the
    Embedder without using it pay no cost.
    """

    def __init__(self, model_name: str = DEFAULT_MODEL):
        self.model_name = model_name
        self._model: TextEmbedding | None = None
        self._dim: int | None = None

    @property
    def model(self) -> TextEmbedding:
        if self._model is None:
            from fastembed import TextEmbedding

            log.info("Loading embedding model %s (first run downloads ~80MB)", self.model_name)
            self._model = TextEmbedding(model_name=self.model_name)
        return self._model

    @property
    def dim(self) -> int:
        if self._dim is None:
            sample = next(iter(self.model.embed(["dim-probe"])))
            self._dim = len(sample)
        return self._dim

    def embed(self, text: str) -> list[float]:
        result = next(iter(self.model.embed([text])))
        return _to_floats(result)

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        return [_to_floats(r) for r in self.model.embed(texts)]


def _to_floats(arr: object) -> list[float]:
    """Coerce a numpy array or sequence to ``list[float]``."""
    if hasattr(arr, "tolist"):
        return list(arr.tolist())  # type: ignore[attr-defined]
    return [float(x) for x in arr]  # type: ignore[union-attr]


def cosine_similarity(a: list[float], b: list[float]) -> float:
    """Compute cosine similarity between two equal-length vectors.

    bge embeddings are L2-normalized by the model, so dot-product == cosine;
    we still divide defensively in case the embedder isn't normalized.
    """
    if len(a) != len(b):
        raise ValueError(f"vector length mismatch: {len(a)} != {len(b)}")
    dot = sum(x * y for x, y in zip(a, b, strict=True))
    na = sum(x * x for x in a) ** 0.5
    nb = sum(x * x for x in b) ** 0.5
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)
