"""Local text embedding for the decision store and retrieval."""

from adrift.embedding.embedder import Embedder

__all__ = ["Embedder"]
