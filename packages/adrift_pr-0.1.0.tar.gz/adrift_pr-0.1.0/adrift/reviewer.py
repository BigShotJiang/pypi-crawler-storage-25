"""The review agent.

Phase 1 does the simplest possible thing: for each decision, ask the LLM if
the diff contradicts it. Filter by confidence threshold, cap by max findings.

Future phases inject a retriever between decisions and the judge — only
decisions relevant to the diff's impact zone get judged. The interface here
is structured to make that swap small.
"""

from __future__ import annotations

import json
import logging
import re

from adrift.llm import LLMClient
from adrift.models import Decision, Diff, Finding, Severity
from adrift.prompts import JUDGE_SYSTEM, JUDGE_USER
from adrift.retrieval.retriever import RetrieverProtocol

log = logging.getLogger(__name__)


# Truncate per-file patches to keep prompts within sensible bounds. Phase 2
# will replace this with structural diff scoping via GitNexus.
MAX_PATCH_CHARS = 4000


class Reviewer:
    def __init__(
        self,
        llm: LLMClient,
        *,
        retriever: RetrieverProtocol | None = None,
        min_confidence: float = 0.6,
        max_findings: int = 3,
    ):
        self.llm = llm
        self.retriever = retriever
        self.min_confidence = min_confidence
        self.max_findings = max_findings

    def review(self, diff: Diff, decisions: list[Decision]) -> list[Finding]:
        """Judge each decision against the diff. Returns sorted, capped findings.

        If a retriever is configured, decisions are filtered to only the
        structurally relevant ones before invoking the LLM. This is the dominant
        precision lever — judging fewer, more relevant decisions kills false
        positives.
        """
        if not decisions:
            log.info("No decisions to review against")
            return []
        if not diff.files:
            log.info("Diff is empty; nothing to review")
            return []

        if self.retriever is not None:
            decisions = self.retriever.retrieve(decisions, diff)
            if not decisions:
                log.info("Retriever filtered out all decisions; nothing to judge")
                return []

        diff_text = _format_diff(diff)
        candidate_findings: list[Finding] = []

        for decision in decisions:
            try:
                finding = self._judge_one(decision, diff_text)
            except Exception:
                log.exception("Judgment failed for decision %s", decision.id)
                continue
            if finding is not None:
                candidate_findings.append(finding)

        candidate_findings.sort(key=lambda f: f.confidence, reverse=True)
        kept = candidate_findings[: self.max_findings]
        log.info(
            "Reviewer: %d decisions judged, %d findings above threshold, %d kept",
            len(decisions),
            len(candidate_findings),
            len(kept),
        )
        return kept

    def _judge_one(self, decision: Decision, diff_text: str) -> Finding | None:
        prompt = JUDGE_USER.format(
            source=decision.source,
            title=decision.title,
            body=decision.body,
            diff=diff_text,
        )
        response = self.llm.complete(prompt, system=JUDGE_SYSTEM)
        data = _parse_json_response(response.content)
        if not data:
            log.warning("Empty or unparseable LLM response for decision %s", decision.id)
            return None
        if not data.get("conflicts"):
            return None

        try:
            confidence = float(data.get("confidence", 0.0))
        except (TypeError, ValueError):
            log.warning("Bad confidence value from LLM for decision %s", decision.id)
            return None

        if confidence < self.min_confidence:
            log.debug(
                "Dropping finding for %s: confidence %.2f below threshold %.2f",
                decision.id,
                confidence,
                self.min_confidence,
            )
            return None

        return Finding(
            decision_id=decision.id,
            decision_title=decision.title,
            decision_source=decision.source,
            severity=Severity.MEDIUM,
            confidence=max(0.0, min(1.0, confidence)),
            explanation=str(data.get("explanation", "")).strip(),
            quoted_diff=str(data.get("quoted_diff", "")).strip(),
            quoted_decision=str(data.get("quoted_decision", "")).strip(),
        )


def _format_diff(diff: Diff) -> str:
    parts: list[str] = []
    for f in diff.files:
        patch = f.patch
        if len(patch) > MAX_PATCH_CHARS:
            patch = patch[:MAX_PATCH_CHARS] + "\n... [truncated]"
        parts.append(f"### `{f.path}` (+{f.additions} -{f.deletions})\n```diff\n{patch}\n```")
    return "\n\n".join(parts)


_JSON_FENCE_RE = re.compile(r"^```(?:json)?\s*(.*?)\s*```$", re.DOTALL)


def _parse_json_response(raw: str) -> dict[str, object]:
    """Pull a JSON object out of an LLM response, even if it's fenced or padded."""
    s = raw.strip()
    if not s:
        return {}

    m = _JSON_FENCE_RE.match(s)
    if m:
        s = m.group(1).strip()

    # Sometimes the model prefixes prose before the JSON; find the first `{`.
    if not s.startswith("{"):
        start = s.find("{")
        if start == -1:
            return {}
        s = s[start:]

    try:
        result = json.loads(s)
    except json.JSONDecodeError as e:
        log.warning("Failed to decode JSON from LLM: %s; raw=%s", e, raw[:200])
        return {}
    return result if isinstance(result, dict) else {}
