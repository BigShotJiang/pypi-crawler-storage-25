"""Retrieval layer — narrows the decision set before LLM judgment."""

from adrift.retrieval.retriever import (
    EmbeddingRetriever,
    HybridRetriever,
    Retriever,
    RetrieverProtocol,
    StructuralRetriever,
)

__all__ = [
    "EmbeddingRetriever",
    "HybridRetriever",
    "Retriever",
    "RetrieverProtocol",
    "StructuralRetriever",
]
