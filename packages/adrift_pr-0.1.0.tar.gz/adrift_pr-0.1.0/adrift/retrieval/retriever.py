"""Retriever — narrows the decision set for a diff.

Three retrievers ship today, all implementing the same ``retrieve(decisions, diff)``
interface so the ``Reviewer`` can use any of them transparently:

- ``StructuralRetriever``: Phase 2. Filters by impact-zone overlap.
- ``EmbeddingRetriever``: Phase 3. Filters by semantic similarity to the diff.
- ``HybridRetriever``: Phase 3. Combines both signals with tier weighting.

The naming convention ``Retriever`` (no qualifier) is an alias for the
recommended hybrid. Callers that want a specific backend reach in directly.
"""

from __future__ import annotations

import logging
import math
import re
from datetime import datetime
from typing import ClassVar, Protocol, runtime_checkable

from adrift.embedding.embedder import Embedder, cosine_similarity
from adrift.graph.base import GraphClient, ImpactZone
from adrift.models import Decision, DecisionTier, Diff

log = logging.getLogger(__name__)


@runtime_checkable
class RetrieverProtocol(Protocol):
    """Common shape every retriever implements."""

    def retrieve(self, decisions: list[Decision], diff: Diff) -> list[Decision]: ...


# --- Structural (Phase 2) -----------------------------------------------------

# Splits on non-alphanumeric (including underscores) so snake_case identifiers
# break into their parts: "validate_token" → ["validate", "token"].
_WORD_RE = re.compile(r"[A-Za-z0-9]+")


class StructuralRetriever:
    """Filter/rank decisions by overlap with the diff's impact zone."""

    def __init__(self, graph: GraphClient | None = None, *, min_score: float = 0.25):
        self.graph = graph
        self.min_score = min_score

    def retrieve(self, decisions: list[Decision], diff: Diff) -> list[Decision]:
        if not decisions:
            return []
        if self.graph is None:
            log.debug("StructuralRetriever: no graph; passing %d decisions", len(decisions))
            return decisions
        if not diff.files:
            return []
        try:
            zone = self.graph.impact_zone(paths=[f.path for f in diff.files])
        except Exception:
            log.warning("impact_zone failed; passing decisions through", exc_info=True)
            return decisions
        if not zone:
            return decisions

        scored: list[tuple[float, Decision]] = [
            (s, d) for d in decisions if (s := _score_structural(d, zone)) >= self.min_score
        ]
        scored.sort(key=lambda x: x[0], reverse=True)
        return [d for _, d in scored]


def _score_structural(decision: Decision, zone: ImpactZone) -> float:
    body_lower = decision.body.lower()
    body_tokens = set(_WORD_RE.findall(body_lower))
    score = 0.0
    for node in zone.all_nodes():
        name_lower = node.name.lower()
        path_lower = node.file_path.lower()
        if name_lower and name_lower in body_lower:
            score += 1.0
        elif path_lower and path_lower in body_lower:
            score += 0.5
        elif name_lower:
            name_tokens = _WORD_RE.findall(name_lower)
            if name_tokens and any(t in body_tokens for t in name_tokens):
                score += 0.25
    return score


# --- Embedding (Phase 3) ------------------------------------------------------


class EmbeddingRetriever:
    """Filter/rank decisions by semantic similarity to the diff.

    Decisions need ``embedding`` populated (the store handles this on load).
    Decisions without an embedding are skipped silently — they remain visible
    via other retrievers if combined.
    """

    def __init__(self, embedder: Embedder, *, min_similarity: float = 0.3):
        self.embedder = embedder
        self.min_similarity = min_similarity

    def retrieve(self, decisions: list[Decision], diff: Diff) -> list[Decision]:
        if not decisions or not diff.files:
            return []
        query = _diff_to_query(diff)
        query_vec = self.embedder.embed(query)
        scored: list[tuple[float, Decision]] = []
        for d in decisions:
            if d.embedding is None:
                continue
            sim = cosine_similarity(query_vec, d.embedding)
            if sim >= self.min_similarity:
                scored.append((sim, d))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [d for _, d in scored]


# --- Hybrid (recommended Phase 3) --------------------------------------------


class HybridRetriever:
    """Combine structural and embedding signals plus tier weighting.

    Final score per decision::

        score = structural_weight * structural_score
              + embedding_weight  * embedding_similarity
              + tier_weight       * tier_multiplier

    Decisions are returned sorted by descending score, with anything below
    ``min_score`` dropped.
    """

    DEFAULT_TIER_MULTIPLIERS: ClassVar[dict[DecisionTier, float]] = {
        DecisionTier.EXPLICIT: 1.0,
        DecisionTier.MINED: 0.7,
        DecisionTier.INFERRED: 0.4,
    }

    def __init__(
        self,
        *,
        graph: GraphClient | None = None,
        embedder: Embedder | None = None,
        structural_weight: float = 0.5,
        embedding_weight: float = 0.5,
        tier_weight: float = 0.1,
        min_score: float = 0.25,
        top_k: int = 25,
        # Phase 4: recency decay. Decision weight is multiplied by
        # exp(-age_days / half_life_days). 0 disables decay.
        half_life_days: float = 365.0,
    ):
        self.graph = graph
        self.embedder = embedder
        self.structural_weight = structural_weight
        self.embedding_weight = embedding_weight
        self.tier_weight = tier_weight
        self.min_score = min_score
        self.top_k = top_k
        self.half_life_days = half_life_days

    def retrieve(self, decisions: list[Decision], diff: Diff) -> list[Decision]:
        if not decisions:
            return []
        if not diff.files:
            return decisions

        zone = self._safe_impact_zone(diff)
        query_vec = self._safe_query_embedding(diff)
        now = datetime.now()

        scored: list[tuple[float, Decision]] = []
        for d in decisions:
            struct = _score_structural(d, zone) if zone else 0.0
            embed = (
                cosine_similarity(query_vec, d.embedding)
                if query_vec is not None and d.embedding is not None
                else 0.0
            )
            tier_mult = self.DEFAULT_TIER_MULTIPLIERS.get(d.tier, 0.5)
            decayed_weight = d.weight * _recency_factor(d.created_at, now, self.half_life_days)
            combined = (
                self.structural_weight * struct
                + self.embedding_weight * embed
                + self.tier_weight * tier_mult * decayed_weight
            )
            if combined >= self.min_score:
                scored.append((combined, d))

        scored.sort(key=lambda x: x[0], reverse=True)
        kept = [d for _, d in scored[: self.top_k]]
        log.info(
            "HybridRetriever: %d → %d decisions (structural=%s, embedding=%s, decay=%s)",
            len(decisions),
            len(kept),
            "on" if zone else "off",
            "on" if query_vec is not None else "off",
            "off" if self.half_life_days <= 0 else f"half-life={self.half_life_days}d",
        )
        return kept

    def _safe_impact_zone(self, diff: Diff) -> ImpactZone | None:
        if self.graph is None:
            return None
        try:
            zone = self.graph.impact_zone(paths=[f.path for f in diff.files])
        except Exception:
            log.warning("HybridRetriever: impact_zone failed", exc_info=True)
            return None
        return zone if zone else None

    def _safe_query_embedding(self, diff: Diff) -> list[float] | None:
        if self.embedder is None:
            return None
        try:
            return self.embedder.embed(_diff_to_query(diff))
        except Exception:
            log.warning("HybridRetriever: query embedding failed", exc_info=True)
            return None


def _diff_to_query(diff: Diff) -> str:
    """Build a short textual representation of a diff for embedding."""
    parts: list[str] = []
    for f in diff.files[:20]:  # cap at 20 files to keep query manageable
        parts.append(f.path)
        if f.patch:
            # First few changed lines per file — enough to capture semantic intent
            head = "\n".join(f.patch.splitlines()[:30])
            parts.append(head)
    return "\n\n".join(parts)


def _recency_factor(created_at: datetime, now: datetime, half_life_days: float) -> float:
    """Exponential decay: factor in [0, 1] based on age vs half-life.

    A decision exactly ``half_life_days`` old has factor 0.5. A brand-new
    decision has factor ~1.0. Returns 1.0 (no decay) when ``half_life_days <= 0``.
    """
    if half_life_days <= 0:
        return 1.0
    age = max(0.0, (now - created_at).total_seconds() / 86400.0)
    return math.exp(-age * math.log(2) / half_life_days)


# Backward-compatible alias: ``Retriever`` continues to mean the simple
# structural retriever for callers that imported it pre-Phase-3.
Retriever = StructuralRetriever
