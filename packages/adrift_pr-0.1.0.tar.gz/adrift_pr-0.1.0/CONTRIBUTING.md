# Contributing

Thanks for considering a contribution. Adrift aims to stay small, focused, and honest — the same principles apply to contributions.

## Project goals (one-line each)

1. Detect design-intent regressions that other PR reviewers miss.
2. Stay framework-light: native LLM APIs over `tool_use` wrappers, plain SQLite over orchestration platforms.
3. Be useful in 5 minutes on any repo, not 5 hours on a custom one.

## Quick development setup

Requirements: Python 3.11+, [`uv`](https://github.com/astral-sh/uv) (or pip).

```bash
git clone https://github.com/<owner>/adrift
cd adrift

uv venv
uv pip install -e ".[dev]"
# or, without uv:
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
```

Run the full check before opening a PR:

```bash
pytest        # should be 136+ passing, no skips
ruff check .  # should report "All checks passed!"
```

The tests are designed to be fast (~2 seconds total) and offline — no real LLM calls, no real GitHub, no model downloads. If a test you wrote needs the network, mark it `@pytest.mark.integration` so it's opt-in.

## Coding conventions

- **Type hints everywhere.** This is a Python 3.11+ project; use `X | None` instead of `Optional[X]` and `list[X]` instead of `List[X]`.
- **Pydantic for data crossing module boundaries.** Plain dataclasses or frozen dataclasses for internal value objects.
- **Protocols over inheritance** for extension points (`IntentSource`, `GraphClient`, `Tool`, `Miner`). New backends implement the protocol; we never subclass.
- **Errors at boundaries, not internals.** External calls (GitHub, LLM, MCP) should fail gracefully and degrade — never crash the run because of one bad PR description.
- **One screen per file when possible.** If a module is over ~300 lines, it's probably trying to do two things.
- **ruff for lint + format.** Run `ruff check . --fix` and `ruff format .` before committing.

## Architecture: extension points

The cleanest way to contribute is via the protocols. None of these require touching the core.

### Adding an `IntentSource`

A source produces `Decision` objects from somewhere — ADRs, Linear tickets, Notion pages, whatever. See [`adrift/sources/adr.py`](adrift/sources/adr.py) for a minimal example.

```python
from adrift.models import Decision

class MyNotionSource:
    name = "notion"

    def __init__(self, token: str, database_id: str):
        ...

    def fetch(self) -> list[Decision]:
        # Pull from Notion, convert to Decision objects, return them.
        ...
```

The class just needs a `name` and a `fetch()` method — Python's structural typing handles the rest.

### Adding a `Miner`

A miner produces `CandidateDecision` objects (raw content); the classifier promotes the ones that look like real decisions. See [`adrift/mining/pr_descriptions.py`](adrift/mining/pr_descriptions.py) for the reference implementation.

### Adding a `Tool`

A `Tool` is a capability invokable both by the pipeline and (in Phase 5) by an agentic LLM via Anthropic's native `tool_use`. See [`adrift/tools/impact_zone.py`](adrift/tools/impact_zone.py) for the pattern.

Required: `name`, `description`, `input_schema` (JSONSchema), and an `invoke(**kwargs) -> ToolResult` method.

### Adding a `Retriever`

A retriever filters/ranks decisions for a given diff. Implements `RetrieverProtocol` (`def retrieve(decisions, diff) -> list[Decision]`). See [`adrift/retrieval/retriever.py`](adrift/retrieval/retriever.py).

## Testing conventions

- **Mock external dependencies.** Tests never hit GitHub, real LLMs, or download models. Use `pytest-mock` or `unittest.mock.MagicMock`.
- **Use the `fake_embedder` fixture** (in [`tests/conftest.py`](tests/conftest.py)) for anything that touches embeddings — it's deterministic, 16-dim, and doesn't load fastembed.
- **Use `tmp_path`** for anything that writes files (SQLite stores, ADR fixtures).
- **Name test functions descriptively.** `test_retriever_falls_back_when_graph_unavailable` beats `test_retriever_fallback`.
- **Each test should fail for one reason.** If you find yourself with multiple unrelated asserts, split the test.

## Commit conventions

Write commit messages in imperative present tense ("Add X" not "Added X" or "Adds X"). One-line summary + optional body.

Reasonable prefixes (not enforced, but helpful):

- `feat:` new capability
- `fix:` bug fix
- `refactor:` code restructuring with no behavior change
- `docs:` documentation only
- `test:` test changes only
- `chore:` dependency bumps, CI tweaks

Example:

```
feat: add CommitMessageMiner

Walks git log for the last N commits, emits messages with sufficient
length as CandidateDecisions. Complements PRDescriptionMiner for
repos with thin PR descriptions.
```

## Pull request process

1. Fork, branch, write code + tests.
2. Run `pytest` and `ruff check .` — both must pass.
3. Open a PR with a description that explains *why*, not just *what*.
4. If your change affects user-facing behavior, update [README.md](README.md) and [CHANGELOG.md](CHANGELOG.md).
5. Be patient with review feedback — we'd rather get the design right than ship fast.

## Reporting issues

Open a GitHub issue with:
- What you were trying to do.
- What happened (with `--verbose` output if possible).
- What you expected to happen.
- Your environment (OS, Python version, LLM provider).

For security issues, do not open a public issue — email the maintainers (address in [LICENSE](LICENSE)).

## License

By contributing, you agree your contributions are licensed under the [MIT License](LICENSE).
