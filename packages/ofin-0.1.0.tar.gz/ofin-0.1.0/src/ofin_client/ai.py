from __future__ import annotations

from typing import Any


def tool_schemas() -> list[dict[str, Any]]:
    """Return lightweight AI tool schemas for the hosted ofin API."""

    return [
        {
            "name": "ofin_search",
            "description": "Search OTCMarkets securities by symbol or issuer query.",
            "parameters": {
                "type": "object",
                "required": ["query"],
                "properties": {
                    "query": {"type": "string"},
                    "rows": {"type": "integer", "minimum": 1, "maximum": 100},
                    "start": {"type": "integer", "minimum": 0},
                },
            },
        },
        {
            "name": "ofin_financials",
            "description": "Fetch OTCMarkets income statement, balance sheet, or cash-flow data for a symbol.",
            "parameters": {
                "type": "object",
                "required": ["symbol"],
                "properties": {
                    "symbol": {"type": "string"},
                    "statement": {
                        "type": "string",
                        "enum": ["income-statement", "balance-sheet", "cash-flow"],
                        "default": "income-statement",
                    },
                    "duration": {"type": "string"},
                    "page_size": {"type": "integer", "minimum": 1, "maximum": 500},
                },
            },
        },
        {
            "name": "ofin_filings",
            "description": "Fetch OTC disclosure or SEC filing metadata for a symbol.",
            "parameters": {
                "type": "object",
                "properties": {
                    "symbol": {"type": "string"},
                    "external": {"type": "boolean"},
                    "page": {"type": "integer", "minimum": 1},
                    "page_size": {"type": "integer", "minimum": 1, "maximum": 500},
                },
            },
        },
        {
            "name": "ofin_news",
            "description": "Fetch OTCMarkets company news metadata or a news item by id.",
            "parameters": {
                "type": "object",
                "properties": {
                    "symbol": {"type": "string"},
                    "news_id": {"type": "string"},
                    "external": {"type": "boolean"},
                    "page": {"type": "integer", "minimum": 1},
                    "page_size": {"type": "integer", "minimum": 1, "maximum": 500},
                },
            },
        },
        {
            "name": "ofin_market",
            "description": "Fetch OTC market totals, snapshots, active issues, advancers, decliners, or overnight views.",
            "parameters": {
                "type": "object",
                "properties": {
                    "view": {
                        "type": "string",
                        "enum": ["totals", "snapshot", "active", "advancers", "decliners", "overnight"],
                        "default": "totals",
                    },
                    "session": {"type": "string", "enum": ["current", "closing"], "default": "current"},
                    "overnight_view": {
                        "type": "string",
                        "enum": ["active", "advancers", "decliners", "snapshot"],
                        "default": "snapshot",
                    },
                    "tier_group": {"type": "string"},
                },
            },
        },
        {
            "name": "ofin_reg_sho",
            "description": "Fetch OTCMarkets Reg SHO dates or Reg SHO list rows.",
            "parameters": {
                "type": "object",
                "properties": {
                    "dates_only": {"type": "boolean"},
                    "symbol": {"type": "string"},
                    "position_date": {"type": "string"},
                    "page": {"type": "integer", "minimum": 1},
                    "page_size": {"type": "integer", "minimum": 1, "maximum": 500},
                },
            },
        },
        {
            "name": "ofin_compliance",
            "description": "Fetch OTCMarkets compliance datasets such as caveat emptor, promotions, reverse splits, suspensions, shell-status changes, company-name changes, or grace-period records.",
            "parameters": {
                "type": "object",
                "required": ["kind"],
                "properties": {
                    "kind": {
                        "type": "string",
                        "enum": [
                            "caveat-emptor",
                            "company-name-changes",
                            "grace-period",
                            "promotions",
                            "reverse-splits",
                            "shell-status-changes",
                            "suspensions-revocations",
                        ],
                    },
                    "page": {"type": "integer", "minimum": 1},
                    "page_size": {"type": "integer", "minimum": 1, "maximum": 500},
                },
            },
        },
    ]
