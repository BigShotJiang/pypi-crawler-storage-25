from __future__ import annotations

import json
import os
import ssl
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any, Mapping

DEFAULT_BASE_URL = os.environ.get("OFIN_BASE_URL", "https://api.ofin.bluedoor.sh")
SDK_VERSION = "0.1.0"
_DEFAULT_SESSION: Any = None

_PARAM_ALIASES = {
    "page_size": "pageSize",
    "position_date": "positionDate",
    "tier_group": "tierGroup",
    "sort_on": "sortOn",
    "sort_dir": "sortDir",
}

_FINANCIAL_STATEMENTS = {"income-statement", "balance-sheet", "cash-flow"}
_MARKET_SESSIONS = {"current", "closing"}
_OVERNIGHT_VIEWS = {"active", "advancers", "decliners", "snapshot"}
_COMPLIANCE_ROUTES = {
    "caveat-emptor",
    "company-name-changes",
    "grace-period",
    "promotions",
    "reverse-splits",
    "shell-status-changes",
    "suspensions-revocations",
}


class OfinError(RuntimeError):
    """Base exception for ofin client errors."""


class OfinRateLimitError(OfinError):
    """Raised when ofin returns HTTP 429."""


@dataclass(frozen=True)
class _Response:
    status: int
    headers: Mapping[str, str]
    body: bytes


class Client:
    def __init__(
        self,
        *,
        base_url: str | None = None,
        contact: str | None = None,
        api_key: str | None = None,
        timeout: float = 10.0,
        session: Any = None,
    ) -> None:
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self.contact = contact or os.environ.get("OFIN_CONTACT")
        self.api_key = api_key or os.environ.get("OFIN_API_KEY")
        self.timeout = timeout
        self.session = session if session is not None else _curl_session()

    def health(self) -> dict[str, Any]:
        return self.get("/v1/health")

    def endpoints(self) -> dict[str, Any]:
        return self.get("/v1/endpoints")

    def openapi(self) -> dict[str, Any]:
        return self.get("/v1/openapi.json")

    def securities(
        self,
        *,
        page: int | None = None,
        page_size: int | None = None,
        country: str | None = None,
        **params: Any,
    ) -> dict[str, Any]:
        params = _with_params(params, page=page, page_size=page_size, country=country)
        return self.get("/v1/securities", params=params)

    def search(
        self,
        query: str,
        *,
        rows: int | None = None,
        start: int | None = None,
        **params: Any,
    ) -> dict[str, Any]:
        params = _with_params(params, q=_required_text(query, "query"), rows=rows, start=start)
        return self.get("/v1/securities/search", params=params)

    def dividends(self, symbol: str, *, page: int | None = None, page_size: int | None = None, **params: Any) -> dict[str, Any]:
        params = _with_params(params, page=page, page_size=page_size)
        return self.get(f"/v1/securities/{_quote_symbol(symbol)}/dividends", params=params)

    def splits(self, symbol: str, *, page: int | None = None, page_size: int | None = None, **params: Any) -> dict[str, Any]:
        params = _with_params(params, page=page, page_size=page_size)
        return self.get(f"/v1/securities/{_quote_symbol(symbol)}/splits", params=params)

    def financial_reports(self, symbol: str, **params: Any) -> dict[str, Any]:
        return self.get(f"/v1/securities/{_quote_symbol(symbol)}/financial-reports", params=params)

    def financials(
        self,
        symbol: str,
        statement: str = "income-statement",
        *,
        duration: str | None = None,
        page_size: int | None = None,
        **params: Any,
    ) -> dict[str, Any]:
        statement = _slug(statement, "statement", _FINANCIAL_STATEMENTS)
        params = _with_params(params, duration=duration, page_size=page_size)
        return self.get(f"/v1/securities/{_quote_symbol(symbol)}/financials/{statement}", params=params)

    def income_statement(self, symbol: str, **params: Any) -> dict[str, Any]:
        return self.financials(symbol, "income-statement", **params)

    def balance_sheet(self, symbol: str, **params: Any) -> dict[str, Any]:
        return self.financials(symbol, "balance-sheet", **params)

    def cash_flow(self, symbol: str, **params: Any) -> dict[str, Any]:
        return self.financials(symbol, "cash-flow", **params)

    def sec_filings(
        self,
        symbol: str | None = None,
        *,
        page: int | None = None,
        page_size: int | None = None,
        **params: Any,
    ) -> dict[str, Any]:
        if symbol is not None:
            return self.get(f"/v1/securities/{_quote_symbol(symbol)}/sec-filings", params=params)
        params = _with_params(params, page=page, page_size=page_size)
        return self.get("/v1/sec-filings", params=params)

    def security_sec_filings(self, symbol: str, **params: Any) -> dict[str, Any]:
        return self.get(f"/v1/securities/{_quote_symbol(symbol)}/sec-filings", params=params)

    def sec_filings_list(
        self,
        *,
        symbol: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
        **params: Any,
    ) -> dict[str, Any]:
        params = _with_params(params, symbol=_optional_symbol(symbol), page=page, page_size=page_size)
        return self.get("/v1/sec-filings", params=params)

    def sec_filings_external(
        self,
        *,
        symbol: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
        **params: Any,
    ) -> dict[str, Any]:
        params = _with_params(params, symbol=_optional_symbol(symbol), page=page, page_size=page_size)
        return self.get("/v1/sec-filings/external", params=params)

    def sec_filing_pdf(self, filing_id: str | int, **params: Any) -> bytes:
        return self.get_bytes(f"/v1/sec-filings/{_quote_token(filing_id, 'filing_id')}/pdf", params=params)

    def insiders_summary(self, symbol: str, **params: Any) -> dict[str, Any]:
        return self.get(f"/v1/securities/{_quote_symbol(symbol)}/insiders/summary", params=params)

    def insiders_otc(self, symbol: str, *, page: int | None = None, page_size: int | None = None, **params: Any) -> dict[str, Any]:
        params = _with_params(params, page=page, page_size=page_size)
        return self.get(f"/v1/securities/{_quote_symbol(symbol)}/insiders/otc", params=params)

    def insiders_external(self, symbol: str, *, page: int | None = None, page_size: int | None = None, **params: Any) -> dict[str, Any]:
        params = _with_params(params, page=page, page_size=page_size)
        return self.get(f"/v1/securities/{_quote_symbol(symbol)}/insiders/external", params=params)

    def news(
        self,
        symbol: str,
        *,
        page: int | None = None,
        page_size: int | None = None,
        sort_on: str | None = None,
        sort_dir: str | None = None,
        **params: Any,
    ) -> dict[str, Any]:
        params = _with_params(params, page=page, page_size=page_size, sort_on=sort_on, sort_dir=sort_dir)
        return self.get(f"/v1/securities/{_quote_symbol(symbol)}/news", params=params)

    def news_external(self, symbol: str, *, page: int | None = None, page_size: int | None = None, **params: Any) -> dict[str, Any]:
        params = _with_params(params, page=page, page_size=page_size)
        return self.get(f"/v1/securities/{_quote_symbol(symbol)}/news/external", params=params)

    def news_item(self, news_id: str | int, **params: Any) -> dict[str, Any]:
        return self.get(f"/v1/news/{_quote_token(news_id, 'news_id')}", params=params)

    def news_content(self, news_id: str | int, **params: Any) -> dict[str, Any]:
        return self.get(f"/v1/news/{_quote_token(news_id, 'news_id')}/content", params=params)

    def news_external_content(self, news_id: str | int, **params: Any) -> dict[str, Any]:
        return self.get(f"/v1/news/external/{_quote_token(news_id, 'news_id')}/content", params=params)

    def news_content_text(self, news_id: str | int, **params: Any) -> str:
        return _data_text(self.news_content(news_id, **params))

    def news_external_content_text(self, news_id: str | int, **params: Any) -> str:
        return _data_text(self.news_external_content(news_id, **params))

    def market_totals(self, *, tier_group: str | None = None, **params: Any) -> dict[str, Any]:
        params = _with_params(params, tier_group=tier_group)
        return self.get("/v1/markets/totals", params=params)

    def market_snapshot(self, session: str = "current", *, tier_group: str | None = None, **params: Any) -> dict[str, Any]:
        session = _slug(session, "session", _MARKET_SESSIONS)
        params = _with_params(params, tier_group=tier_group)
        return self.get(f"/v1/markets/snapshot/{session}", params=params)

    def market_active(self, session: str = "current", *, tier_group: str | None = None, **params: Any) -> dict[str, Any]:
        session = _slug(session, "session", _MARKET_SESSIONS)
        params = _with_params(params, tier_group=tier_group)
        return self.get(f"/v1/markets/active/{session}", params=params)

    def market_advancers(self, session: str = "current", *, tier_group: str | None = None, **params: Any) -> dict[str, Any]:
        session = _slug(session, "session", _MARKET_SESSIONS)
        params = _with_params(params, tier_group=tier_group)
        return self.get(f"/v1/markets/advancers/{session}", params=params)

    def market_decliners(self, session: str = "current", *, tier_group: str | None = None, **params: Any) -> dict[str, Any]:
        session = _slug(session, "session", _MARKET_SESSIONS)
        params = _with_params(params, tier_group=tier_group)
        return self.get(f"/v1/markets/decliners/{session}", params=params)

    def market_overnight(self, view: str = "snapshot", **params: Any) -> dict[str, Any]:
        view = _slug(view, "view", _OVERNIGHT_VIEWS)
        return self.get(f"/v1/markets/overnight/{view}", params=params)

    def reg_sho_dates(self, **params: Any) -> dict[str, Any]:
        return self.get("/v1/reg-sho/dates", params=params)

    def reg_sho(
        self,
        *,
        position_date: str | int | None = None,
        symbol: str | None = None,
        page: int | None = None,
        page_size: int | None = None,
        **params: Any,
    ) -> dict[str, Any]:
        params = _with_params(
            params,
            position_date=None if position_date is None else str(position_date),
            symbol=_optional_symbol(symbol),
            page=page,
            page_size=page_size,
        )
        return self.get("/v1/reg-sho", params=params)

    def compliance(
        self,
        kind: str,
        *,
        page: int | None = None,
        page_size: int | None = None,
        **params: Any,
    ) -> dict[str, Any]:
        kind = _slug(kind, "kind", _COMPLIANCE_ROUTES)
        params = _with_params(params, page=page, page_size=page_size)
        return self.get(f"/v1/compliance/{kind}", params=params)

    def caveat_emptor(self, **params: Any) -> dict[str, Any]:
        return self.compliance("caveat-emptor", **params)

    def company_name_changes(self, **params: Any) -> dict[str, Any]:
        return self.compliance("company-name-changes", **params)

    def grace_period(self, **params: Any) -> dict[str, Any]:
        return self.compliance("grace-period", **params)

    def promotions(self, **params: Any) -> dict[str, Any]:
        return self.compliance("promotions", **params)

    def reverse_splits(self, **params: Any) -> dict[str, Any]:
        return self.compliance("reverse-splits", **params)

    def shell_status_changes(self, **params: Any) -> dict[str, Any]:
        return self.compliance("shell-status-changes", **params)

    def suspensions_revocations(self, **params: Any) -> dict[str, Any]:
        return self.compliance("suspensions-revocations", **params)

    def get(
        self,
        path: str,
        *,
        params: Mapping[str, Any] | None = None,
        refresh: bool = False,
    ) -> dict[str, Any]:
        return self.request("GET", path, params=params, refresh=refresh)

    def get_bytes(
        self,
        path: str,
        *,
        params: Mapping[str, Any] | None = None,
        refresh: bool = False,
    ) -> bytes:
        return self.request("GET", path, params=params, refresh=refresh, response="bytes")

    def request(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, Any] | None = None,
        body: Any = None,
        refresh: bool = False,
        response: str = "json",
    ) -> Any:
        if body is not None:
            raise ValueError("ofin v1 client is read-only; request bodies are not supported")
        url = self._build_url(path, params=params, refresh=refresh)
        headers = {
            "accept": "application/json" if response == "json" else "application/pdf, application/octet-stream, */*",
            "user-agent": f"ofin-python/{SDK_VERSION}",
        }
        if self.contact:
            headers["x-ofin-contact"] = self.contact
        if self.api_key:
            headers["authorization"] = f"Bearer {self.api_key}"

        received = self._send(method.upper(), url, headers, None)
        if received.status == 429:
            raise OfinRateLimitError(_error_message(received))
        if received.status >= 400:
            raise OfinError(_error_message(received))
        if response == "bytes":
            return received.body
        try:
            data = json.loads(received.body.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise OfinError(f"invalid JSON response from ofin: {exc}") from exc
        if not isinstance(data, dict):
            raise OfinError("invalid JSON response from ofin: expected object")
        return data

    def _build_url(
        self,
        path: str,
        *,
        params: Mapping[str, Any] | None = None,
        refresh: bool = False,
    ) -> str:
        url = f"{self.base_url}{path if path.startswith('/') else '/' + path}"
        query: dict[str, Any] = {}
        if params:
            query.update(_normalize_params(params))
            if "refresh" in params:
                refresh = _truthy(params["refresh"])
        if refresh:
            query["refresh"] = "1"
        if query:
            url = f"{url}?{urllib.parse.urlencode(query, doseq=True)}"
        return url

    def _send(
        self,
        method: str,
        url: str,
        headers: Mapping[str, str],
        body: bytes | None,
    ) -> _Response:
        if self.session is not None:
            try:
                response = self.session.request(
                    method,
                    url,
                    headers=dict(headers),
                    data=body,
                    timeout=self.timeout,
                    impersonate="chrome",
                )
                return _Response(response.status_code, dict(response.headers), response.content)
            except TypeError:
                try:
                    response = self.session.request(
                        method,
                        url,
                        headers=dict(headers),
                        data=body,
                        timeout=self.timeout,
                    )
                    return _Response(response.status_code, dict(response.headers), response.content)
                except Exception as exc:
                    raise OfinError(f"could not reach ofin API: {exc}") from exc
            except Exception as exc:
                raise OfinError(f"could not reach ofin API: {exc}") from exc

        request = urllib.request.Request(url, data=body, headers=dict(headers), method=method)
        try:
            with urllib.request.urlopen(request, timeout=self.timeout, context=_ssl_context()) as response:
                return _Response(response.status, dict(response.headers), response.read())
        except urllib.error.HTTPError as exc:
            return _Response(exc.code, dict(exc.headers), exc.read())
        except urllib.error.URLError as exc:
            raise OfinError(f"could not reach ofin API: {exc}") from exc


OfinClient = Client


def search(query: str, **params: Any) -> dict[str, Any]:
    return Client().search(query, **params)


def financials(symbol: str, statement: str = "income-statement", **params: Any) -> dict[str, Any]:
    return Client().financials(symbol, statement, **params)


def news(symbol: str, **params: Any) -> dict[str, Any]:
    return Client().news(symbol, **params)


def _with_params(params: Mapping[str, Any], **updates: Any) -> dict[str, Any]:
    merged = dict(params)
    for key, value in updates.items():
        if value is not None:
            merged[key] = value
    return merged


def _normalize_params(params: Mapping[str, Any]) -> dict[str, Any]:
    normalized: dict[str, Any] = {}
    for key, value in params.items():
        if value is None or key == "refresh":
            continue
        normalized[_PARAM_ALIASES.get(key, key)] = value
    return normalized


def _slug(value: str, name: str, allowed: set[str]) -> str:
    clean = _required_text(value, name).strip().lower().replace("_", "-")
    if clean not in allowed:
        choices = ", ".join(sorted(allowed))
        raise ValueError(f"unsupported {name} {value!r}; expected one of: {choices}")
    return clean


def _optional_symbol(value: str | None) -> str | None:
    return None if value is None else _required_symbol(value)


def _required_symbol(value: str) -> str:
    return _required_text(value, "symbol").upper()


def _required_text(value: object, name: str) -> str:
    clean = str(value).strip()
    if not clean:
        raise ValueError(f"{name} must not be empty")
    return clean


def _quote_symbol(value: str) -> str:
    return urllib.parse.quote(_required_symbol(value), safe="")


def _quote_token(value: str | int, name: str) -> str:
    return urllib.parse.quote(_required_text(value, name), safe="")


def _data_text(payload: dict[str, Any]) -> str:
    data = payload.get("data")
    return data if isinstance(data, str) else json.dumps(data, sort_keys=True)


def _truthy(value: Any) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes", "y", "on"}


def _error_message(response: _Response) -> str:
    text = response.body.decode("utf-8", errors="replace")
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return f"ofin HTTP {response.status}: {text[:500]}"
    error = payload.get("error") or {}
    message = error.get("message") or payload.get("message") or text[:500]
    return f"ofin HTTP {response.status}: {message}"


def _ssl_context() -> ssl.SSLContext:
    try:
        import certifi  # type: ignore

        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


def _curl_session() -> Any:
    global _DEFAULT_SESSION
    if _DEFAULT_SESSION is not None:
        return _DEFAULT_SESSION
    try:
        from curl_cffi import requests  # type: ignore

        _DEFAULT_SESSION = requests.Session()
        return _DEFAULT_SESSION
    except Exception:
        return None
