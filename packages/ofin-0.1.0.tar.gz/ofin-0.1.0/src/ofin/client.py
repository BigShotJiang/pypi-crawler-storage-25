"""Compatibility exports for `from ofin.client import Client`."""

from ofin_client.client import *  # noqa: F403
