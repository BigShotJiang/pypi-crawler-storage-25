"""Unofficial client for the hosted ofin OTCMarkets data API."""

from ofin_client import (
    Client,
    OfinClient,
    OfinError,
    OfinRateLimitError,
    financials,
    news,
    search,
)

__all__ = [
    "Client",
    "OfinClient",
    "OfinError",
    "OfinRateLimitError",
    "financials",
    "news",
    "search",
]
__version__ = "0.1.0"
