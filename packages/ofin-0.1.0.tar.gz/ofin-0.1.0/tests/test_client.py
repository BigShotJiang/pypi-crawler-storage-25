from __future__ import annotations

import json
import unittest

from ofin import Client as PreferredClient
from ofin_client import Client, OfinClient, OfinRateLimitError
from ofin_client.ai import tool_schemas


class FakeResponse:
    def __init__(self, status_code: int = 200, payload: dict[str, object] | None = None, content: bytes | None = None) -> None:
        self.status_code = status_code
        self.headers: dict[str, str] = {}
        self.content = content if content is not None else json.dumps(payload or {"data": {"symbol": "MLMC"}}).encode()


class FakeSession:
    def __init__(self, response: FakeResponse | None = None) -> None:
        self.response = response or FakeResponse()
        self.calls: list[tuple[str, str, dict[str, str], bytes | None, float]] = []

    def request(
        self,
        method: str,
        url: str,
        *,
        headers: dict[str, str],
        data: bytes | None,
        timeout: float,
        **_: object,
    ) -> FakeResponse:
        self.calls.append((method, url, headers, data, timeout))
        return self.response


class OfinClientTest(unittest.TestCase):
    def test_alias_class_is_kept(self) -> None:
        self.assertIs(OfinClient, Client)
        self.assertIs(PreferredClient, Client)

    def test_search_encodes_query_contact_and_refresh(self) -> None:
        session = FakeSession()
        client = Client(session=session, timeout=3.0, contact="me@example.com")

        data = client.search("mlmc corp", rows=5, refresh=True)

        self.assertEqual(data, {"data": {"symbol": "MLMC"}})
        self.assertEqual(session.calls[0][1], "https://api.ofin.bluedoor.sh/v1/securities/search?q=mlmc+corp&rows=5&refresh=1")
        self.assertEqual(session.calls[0][0], "GET")
        self.assertEqual(session.calls[0][2]["x-ofin-contact"], "me@example.com")
        self.assertEqual(session.calls[0][4], 3.0)

    def test_financials_and_page_size_aliases(self) -> None:
        session = FakeSession()
        client = Client(session=session)

        client.financials("mlmc", statement="balance_sheet", duration="annual", page_size=25)

        self.assertEqual(
            session.calls[0][1],
            "https://api.ofin.bluedoor.sh/v1/securities/MLMC/financials/balance-sheet?duration=annual&pageSize=25",
        )

    def test_market_and_compliance_routes(self) -> None:
        session = FakeSession()
        client = Client(session=session)

        client.market_snapshot("closing", tier_group="Pink")
        client.market_overnight("advancers")
        client.promotions(page_size=10)

        self.assertEqual(session.calls[0][1], "https://api.ofin.bluedoor.sh/v1/markets/snapshot/closing?tierGroup=Pink")
        self.assertEqual(session.calls[1][1], "https://api.ofin.bluedoor.sh/v1/markets/overnight/advancers")
        self.assertEqual(session.calls[2][1], "https://api.ofin.bluedoor.sh/v1/compliance/promotions?pageSize=10")

    def test_sec_filing_pdf_returns_bytes(self) -> None:
        session = FakeSession(FakeResponse(content=b"%PDF-1.7"))
        client = Client(session=session)

        data = client.sec_filing_pdf("12345")

        self.assertEqual(data, b"%PDF-1.7")
        self.assertEqual(session.calls[0][1], "https://api.ofin.bluedoor.sh/v1/sec-filings/12345/pdf")
        self.assertEqual(session.calls[0][2]["accept"], "application/pdf, application/octet-stream, */*")

    def test_reg_sho_maps_pythonic_params(self) -> None:
        session = FakeSession()
        client = Client(session=session)

        client.reg_sho(position_date=20260505, symbol="mlmc", page=2, page_size=50)

        self.assertEqual(
            session.calls[0][1],
            "https://api.ofin.bluedoor.sh/v1/reg-sho?positionDate=20260505&symbol=MLMC&page=2&pageSize=50",
        )

    def test_rate_limit_raises_specific_error(self) -> None:
        session = FakeSession(FakeResponse(429, {"error": {"message": "too many"}}))
        client = Client(session=session)

        with self.assertRaises(OfinRateLimitError):
            client.search("MLMC")

    def test_tool_schemas_include_friendly_tools(self) -> None:
        schemas = tool_schemas()
        names = [schema["name"] for schema in schemas]

        self.assertIn("ofin_search", names)
        self.assertIn("ofin_financials", names)
        self.assertIn("ofin_reg_sho", names)
        self.assertNotIn("ofin_raw", names)

    def test_manifest_is_shipped(self) -> None:
        from ofin_client._manifest import ENDPOINTS, MANIFEST

        self.assertEqual(MANIFEST["endpoint_count"], 42)
        self.assertEqual(len(ENDPOINTS), 42)


if __name__ == "__main__":
    unittest.main()
