# ofin

Python SDK for the hosted ofin OTCMarkets financial data API.

The hosted API exposes CP3-confirmed OTCMarkets contracts behind a cached,
rate-limited REST surface. It is not affiliated with, endorsed by, or sponsored
by OTC Markets Group Inc.

## Install

```bash
pip install ofin
```

## Quick Start

```python
from ofin import Client

client = Client(contact="you@example.com")

results = client.search("MLMC")
issuer_list = client.securities(page_size=10)

income = client.financials("MLMC", statement="income-statement")
balance_sheet = client.balance_sheet("MLMC")
cash_flow = client.cash_flow("MLMC")

filings = client.sec_filings("MLMC")
reports = client.financial_reports("MLMC")
news = client.news("MLMC")
insiders = client.insiders_summary("MLMC")

totals = client.market_totals()
reg_sho = client.reg_sho(symbol="MLMC")
promotions = client.promotions()
```

Convenience wrappers are also available:

```python
import ofin

data = ofin.search("MLMC")
```

## Common Methods

- `Client.health()`, `Client.endpoints()`, and `Client.openapi()` expose
  service and discovery metadata.
- `Client.search()` and `Client.securities()` expose OTC issuer lookup and
  issuer list data.
- `Client.financials()`, `Client.income_statement()`, `Client.balance_sheet()`,
  and `Client.cash_flow()` expose company statements.
- `Client.financial_reports()`, `Client.sec_filings()`,
  `Client.sec_filings_external()`, and `Client.sec_filing_pdf()` expose OTC
  disclosure and SEC filing metadata or documents.
- `Client.news()`, `Client.news_external()`, `Client.news_item()`,
  `Client.news_content()`, and `Client.news_external_content()` expose company
  news metadata and article content.
- `Client.insiders_summary()`, `Client.insiders_otc()`, and
  `Client.insiders_external()` expose insider activity data.
- `Client.market_totals()`, `Client.market_snapshot()`, `Client.market_active()`,
  `Client.market_advancers()`, `Client.market_decliners()`, and
  `Client.market_overnight()` expose OTC market movers and summary data.
- `Client.reg_sho_dates()` and `Client.reg_sho()` expose Reg SHO lists.
- `Client.compliance()` plus the named helpers expose caveat emptor,
  promotions, reverse splits, suspensions/revocations, shell-status changes,
  company-name changes, and grace-period datasets.

Set `OFIN_BASE_URL`, `OFIN_CONTACT`, or `OFIN_API_KEY` in the environment to
configure the default client.

The hosted API and SDK expose friendly public routes only. Source endpoint IDs,
raw passthrough routes, origin URL templates, and internal validation routes are
not part of the production surface.
