#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ------------------------------------------------------------------------------
#
#   Copyright 2022-2026 Valory AG
#   Copyright 2018-2021 Fetch.AI Limited
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#
# ------------------------------------------------------------------------------
"""Setup script for the plug-in."""

from pathlib import Path

from setuptools import find_packages, setup  # type: ignore


def _read_long_description() -> str:
    """Read the plugin README as the PyPI long description."""
    return (Path(__file__).parent / "README.md").read_text(encoding="utf-8")


setup(
    name="open-aea-cli-benchmark",
    version="2.2.6",
    author="Valory AG",
    license="Apache-2.0",
    description="CLI extension for AEA framework benchmarking.",
    long_description=_read_long_description(),
    long_description_content_type="text/markdown",
    packages=find_packages(include=["aea_cli_benchmark*"]),
    package_data={"aea_cli_benchmark": ["py.typed"]},
    entry_points={"aea.cli": ["benchmark = aea_cli_benchmark.core:benchmark"]},
    python_requires=">=3.10,<3.15",
    install_requires=[
        "open-aea>=2.0.0, <3.0.0",
        "psutil>=5.7.0, <6.0.0",
        "click>=8.1.0,<8.4.0",
        "cosmpy>=0.11.0,<0.12",
    ],
    extras_require={
        # Optional: required only for the `tx-generate` benchmark case,
        # which spins up a dockerised fetchai ledger node. Pin kept in
        # sync with the other plugins (ledger-ethereum, ledger-fetchai).
        "tx-generate": ["docker==7.1.0"],
    },
    classifiers=[
        "Environment :: Console",
        "Environment :: Web Environment",
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: Apache Software License",
        "Natural Language :: English",
        "Operating System :: MacOS",
        "Operating System :: Microsoft",
        "Operating System :: Unix",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
        "Topic :: Communications",
        "Topic :: Internet",
        "Topic :: Software Development",
    ],
)
