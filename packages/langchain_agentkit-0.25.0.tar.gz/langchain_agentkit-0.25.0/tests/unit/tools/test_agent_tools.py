"""Tests for the unified Agent tool."""

from unittest.mock import AsyncMock, MagicMock

import pytest
from langchain_core.messages import AIMessage
from langchain_core.tools import ToolException
from langgraph.types import Command

from langchain_agentkit.extensions.agents.refs import Dynamic, Predefined
from langchain_agentkit.extensions.agents.tools import create_agent_tools
from langchain_agentkit.extensions.agents.tools.agent import (
    _agent_tool,
    _AgentDynamicInput,
    _AgentInput,
    _build_scoped_state,
    _delegate_dynamic,
    _delegate_predefined,
)

FAKE_TOOL_CALL_ID = "call_test123"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _FakeGraph:
    """Stub that looks like a raw StateGraph but does NOT satisfy AgentLike.

    MagicMock auto-satisfies any Protocol (including AgentLike) on some
    Python versions, causing _compile_or_resolve to skip compilation.
    This stub only exposes the attributes that a raw graph has.
    """

    def __init__(self, name: str, compiled: AsyncMock) -> None:
        self.name = name
        self.description = "Test agent"
        self.tools_inherit = False
        self.nodes: dict = {}
        self._compiled = compiled

    def compile(self, **kwargs):  # noqa: ANN003, ANN201, ARG002
        return self._compiled


def _make_mock_agent_graph(
    name: str,
    response_content: str = "agent response",
) -> _FakeGraph:
    """Create a fake agent graph that returns a canned response when compiled and invoked."""
    mock_compiled = AsyncMock()
    mock_compiled.ainvoke.return_value = {
        "messages": [AIMessage(content=response_content)],
        "sender": name,
    }
    return _FakeGraph(name, mock_compiled)


# ---------------------------------------------------------------------------
# _build_scoped_state
# ---------------------------------------------------------------------------


class TestBuildScopedState:
    def test_creates_state_with_human_message(self):
        state = _build_scoped_state("do something")

        assert len(state["messages"]) == 1
        assert state["messages"][0].content == "do something"

    def test_sets_sender_to_parent_by_default(self):
        state = _build_scoped_state("task")

        assert state["sender"] == "parent"

    def test_sets_custom_sender(self):
        state = _build_scoped_state("task", sender="lead")

        assert state["sender"] == "lead"


# ---------------------------------------------------------------------------
# Agent reference types
# ---------------------------------------------------------------------------


class TestAgentReferenceTypes:
    def test_predefined_has_id_field(self):
        ref = Predefined(id="researcher")

        assert ref.id == "researcher"
        assert ref.model_dump() == {"id": "researcher"}

    def test_dynamic_has_prompt_field(self):
        ref = Dynamic(prompt="You are a legal expert.")

        assert ref.prompt == "You are a legal expert."
        assert ref.model_dump() == {"prompt": "You are a legal expert."}


# ---------------------------------------------------------------------------
# Input schemas
# ---------------------------------------------------------------------------


class TestInputSchemas:
    def test_agent_input_only_accepts_predefined(self):
        schema = _AgentInput.model_json_schema()

        # Should not contain Dynamic/prompt variant
        schema_str = str(schema)
        assert "Predefined" in schema_str or "id" in schema_str
        assert "Dynamic" not in schema_str

    def test_agent_dynamic_input_accepts_both_variants(self):
        schema = _AgentDynamicInput.model_json_schema()

        schema_str = str(schema)
        assert "id" in schema_str
        assert "prompt" in schema_str


# ---------------------------------------------------------------------------
# _delegate_predefined
# ---------------------------------------------------------------------------


class TestDelegatePredefined:
    @pytest.mark.asyncio
    async def test_valid_agent_returns_command(self):
        """Default trace_hidden strategy emits subagent AIMessages + a terminal ToolMessage."""
        from langchain_core.messages import ToolMessage

        agent_graph = _make_mock_agent_graph("researcher", "research result")

        result = await _delegate_predefined(
            agent_id="researcher",
            message="find info",
            agents_by_name={"researcher": agent_graph},
            compiled_cache={},
            delegation_timeout=30.0,
            parent_tools_getter=None,
            tool_call_id=FAKE_TOOL_CALL_ID,
        )

        assert isinstance(result, Command)
        messages = result.update["messages"]
        # Terminal ToolMessage carries the tool_call_id pairing.
        tool_msg = next(m for m in messages if isinstance(m, ToolMessage))
        assert tool_msg.content == "research result"
        assert tool_msg.tool_call_id == FAKE_TOOL_CALL_ID

    @pytest.mark.asyncio
    async def test_unknown_agent_raises_tool_exception(self):
        with pytest.raises(ToolException, match="not found"):
            await _delegate_predefined(
                agent_id="nonexistent",
                message="do stuff",
                agents_by_name={"researcher": MagicMock()},
                compiled_cache={},
                delegation_timeout=30.0,
                parent_tools_getter=None,
                tool_call_id=FAKE_TOOL_CALL_ID,
            )

    @pytest.mark.asyncio
    async def test_lists_available_agents_in_error(self):
        try:
            await _delegate_predefined(
                agent_id="nonexistent",
                message="do stuff",
                agents_by_name={"alpha": MagicMock(), "beta": MagicMock()},
                compiled_cache={},
                delegation_timeout=30.0,
                parent_tools_getter=None,
                tool_call_id=FAKE_TOOL_CALL_ID,
            )
        except ToolException as exc:
            assert "not found" in str(exc)
            assert "nonexistent" in str(exc)

    @pytest.mark.asyncio
    async def test_caches_compiled_graph(self):
        agent_graph = _make_mock_agent_graph("researcher")
        cache: dict = {}

        await _delegate_predefined(
            agent_id="researcher",
            message="task",
            agents_by_name={"researcher": agent_graph},
            compiled_cache=cache,
            delegation_timeout=30.0,
            parent_tools_getter=None,
            tool_call_id=FAKE_TOOL_CALL_ID,
        )

        assert "researcher" in cache

    @pytest.mark.asyncio
    async def test_exception_returns_command_with_error(self):
        mock_compiled = AsyncMock()
        mock_compiled.ainvoke.side_effect = RuntimeError("boom")
        agent_graph = _FakeGraph("researcher", mock_compiled)

        result = await _delegate_predefined(
            agent_id="researcher",
            message="task",
            agents_by_name={"researcher": agent_graph},
            compiled_cache={},
            delegation_timeout=30.0,
            parent_tools_getter=None,
            tool_call_id=FAKE_TOOL_CALL_ID,
        )

        assert isinstance(result, Command)
        content = result.update["messages"][0].content
        assert "failed" in content
        assert "internal error" in content


# ---------------------------------------------------------------------------
# _delegate_dynamic
# ---------------------------------------------------------------------------


class TestDelegateDynamic:
    @pytest.mark.asyncio
    async def test_empty_prompt_raises_tool_exception(self):
        with pytest.raises(ToolException, match="prompt cannot be empty"):
            await _delegate_dynamic(
                prompt="",
                message="do something",
                delegation_timeout=30.0,
                parent_llm_getter=lambda: MagicMock(),
                tool_call_id=FAKE_TOOL_CALL_ID,
            )

    @pytest.mark.asyncio
    async def test_whitespace_prompt_raises(self):
        with pytest.raises(ToolException, match="prompt cannot be empty"):
            await _delegate_dynamic(
                prompt="   ",
                message="do something",
                delegation_timeout=30.0,
                parent_llm_getter=lambda: MagicMock(),
                tool_call_id=FAKE_TOOL_CALL_ID,
            )

    @pytest.mark.asyncio
    async def test_valid_prompt_returns_command(self):
        mock_llm = AsyncMock()
        mock_llm.ainvoke.return_value = AIMessage(content="analysis result")

        result = await _delegate_dynamic(
            prompt="You are a data analyst.",
            message="analyze this",
            delegation_timeout=30.0,
            parent_llm_getter=lambda: mock_llm,
            tool_call_id=FAKE_TOOL_CALL_ID,
        )

        assert isinstance(result, Command)
        assert result.update["messages"][0].content == "analysis result"

    @pytest.mark.asyncio
    async def test_none_llm_getter_raises(self):
        with pytest.raises(ToolException, match="parent LLM"):
            await _delegate_dynamic(
                prompt="You are an expert.",
                message="do something",
                delegation_timeout=30.0,
                parent_llm_getter=None,
                tool_call_id=FAKE_TOOL_CALL_ID,
            )


# ---------------------------------------------------------------------------
# _agent_tool (unified entry point)
# ---------------------------------------------------------------------------


class TestAgentTool:
    @pytest.mark.asyncio
    async def test_routes_predefined_agent_by_dict(self):
        agent_graph = _make_mock_agent_graph("researcher", "result")

        result = await _agent_tool(
            agent={"id": "researcher"},
            message="find info",
            state={"messages": []},
            tool_call_id=FAKE_TOOL_CALL_ID,
            agents_by_name={"researcher": agent_graph},
            compiled_cache={},
            delegation_timeout=30.0,
            parent_tools_getter=None,
            ephemeral=False,
            parent_llm_getter=None,
        )

        assert isinstance(result, Command)
        assert result.update["messages"][0].content == "result"

    @pytest.mark.asyncio
    async def test_routes_predefined_agent_by_model(self):
        agent_graph = _make_mock_agent_graph("researcher", "result")

        result = await _agent_tool(
            agent=Predefined(id="researcher"),
            message="find info",
            state={"messages": []},
            tool_call_id=FAKE_TOOL_CALL_ID,
            agents_by_name={"researcher": agent_graph},
            compiled_cache={},
            delegation_timeout=30.0,
            parent_tools_getter=None,
            ephemeral=False,
            parent_llm_getter=None,
        )

        assert isinstance(result, Command)
        assert result.update["messages"][0].content == "result"

    @pytest.mark.asyncio
    async def test_routes_dynamic_agent(self):
        mock_llm = AsyncMock()
        mock_llm.ainvoke.return_value = AIMessage(content="dynamic result")

        result = await _agent_tool(
            agent={"prompt": "You are an expert."},
            message="analyze this",
            state={"messages": []},
            tool_call_id=FAKE_TOOL_CALL_ID,
            agents_by_name={},
            compiled_cache={},
            delegation_timeout=30.0,
            parent_tools_getter=None,
            ephemeral=True,
            parent_llm_getter=lambda: mock_llm,
        )

        assert isinstance(result, Command)
        assert result.update["messages"][0].content == "dynamic result"

    @pytest.mark.asyncio
    async def test_dynamic_agent_when_ephemeral_disabled_raises(self):
        with pytest.raises(ToolException, match="not enabled"):
            await _agent_tool(
                agent={"prompt": "You are an expert."},
                message="analyze this",
                state={"messages": []},
                tool_call_id=FAKE_TOOL_CALL_ID,
                agents_by_name={},
                compiled_cache={},
                delegation_timeout=30.0,
                parent_tools_getter=None,
                ephemeral=False,
                parent_llm_getter=None,
            )

    @pytest.mark.asyncio
    async def test_invalid_agent_ref_raises(self):
        with pytest.raises(ToolException, match="Invalid agent reference"):
            await _agent_tool(
                agent={"unknown_field": "value"},
                message="do stuff",
                state={"messages": []},
                tool_call_id=FAKE_TOOL_CALL_ID,
                agents_by_name={},
                compiled_cache={},
                delegation_timeout=30.0,
                parent_tools_getter=None,
                ephemeral=False,
                parent_llm_getter=None,
            )


# ---------------------------------------------------------------------------
# create_agent_tools
# ---------------------------------------------------------------------------


class TestCreateAgentTools:
    def test_returns_single_agent_tool(self):
        tools = create_agent_tools(
            agents_by_name={"researcher": MagicMock()},
            compiled_cache={},
            delegation_timeout=30.0,
            parent_tools_getter=None,
            ephemeral=False,
            parent_llm_getter=None,
        )

        assert len(tools) == 1
        assert tools[0].name == "Agent"

    def test_returns_single_tool_with_ephemeral(self):
        tools = create_agent_tools(
            agents_by_name={"researcher": MagicMock()},
            compiled_cache={},
            delegation_timeout=30.0,
            parent_tools_getter=None,
            ephemeral=True,
            parent_llm_getter=lambda: MagicMock(),
        )

        assert len(tools) == 1
        assert tools[0].name == "Agent"

    def test_ephemeral_without_llm_getter_raises_value_error(self):
        with pytest.raises(ValueError, match="parent_llm_getter is required"):
            create_agent_tools(
                agents_by_name={"researcher": MagicMock()},
                compiled_cache={},
                delegation_timeout=30.0,
                parent_tools_getter=None,
                ephemeral=True,
                parent_llm_getter=None,
            )

    def test_tool_has_description(self):
        tools = create_agent_tools(
            agents_by_name={"researcher": MagicMock()},
            compiled_cache={},
            delegation_timeout=30.0,
            parent_tools_getter=None,
            ephemeral=False,
            parent_llm_getter=None,
        )

        assert tools[0].description

    def test_schema_without_ephemeral_uses_agent_input(self):
        tools = create_agent_tools(
            agents_by_name={"researcher": MagicMock()},
            compiled_cache={},
            delegation_timeout=30.0,
            parent_tools_getter=None,
            ephemeral=False,
            parent_llm_getter=None,
        )

        assert tools[0].args_schema is _AgentInput

    def test_schema_with_ephemeral_uses_dynamic_input(self):
        tools = create_agent_tools(
            agents_by_name={"researcher": MagicMock()},
            compiled_cache={},
            delegation_timeout=30.0,
            parent_tools_getter=None,
            ephemeral=True,
            parent_llm_getter=lambda: MagicMock(),
        )

        assert tools[0].args_schema is _AgentDynamicInput

    @pytest.mark.parametrize("ephemeral", [False, True])
    def test_coroutine_accepts_get_type_hints(self, ephemeral: bool):
        """Regression: LangGraph's ``ToolNode.__init__`` calls
        ``typing.get_type_hints`` on every tool's ``.coroutine``.

        A ``functools.partial`` fails that call with ``TypeError``, and a
        closure decorated with ``functools.wraps(_agent_tool)`` fails with
        ``NameError`` because ``_agent_tool``'s string annotations reference
        ``Callable``, which is only imported under ``TYPE_CHECKING``.

        The tool's async handler must therefore be a plain ``FunctionType``
        with annotations that resolve at runtime.
        """
        from typing import get_type_hints

        tools = create_agent_tools(
            agents_by_name={"researcher": MagicMock()},
            compiled_cache={},
            delegation_timeout=30.0,
            parent_tools_getter=None,
            ephemeral=ephemeral,
            parent_llm_getter=(lambda: MagicMock()) if ephemeral else None,
        )

        coroutine = tools[0].coroutine
        assert coroutine is not None
        # Must not raise: TypeError (partial rejected) or NameError
        # (unresolved forward refs copied via ``functools.wraps``).
        get_type_hints(coroutine, include_extras=True)

    @pytest.mark.parametrize("ephemeral", [False, True])
    def test_tool_is_accepted_by_langgraph_toolnode(self, ephemeral: bool):
        """Regression: the full path that originally blew up.

        ``ToolNode.__init__`` builds ``_injected_args`` for every tool it
        receives, which calls ``_get_all_injected_args`` → ``get_type_hints``
        on ``tool.coroutine``. This test guards against any agentkit tool
        wrapper that is incompatible with that introspection.
        """
        from langgraph.prebuilt import ToolNode

        tools = create_agent_tools(
            agents_by_name={"researcher": MagicMock()},
            compiled_cache={},
            delegation_timeout=30.0,
            parent_tools_getter=None,
            ephemeral=ephemeral,
            parent_llm_getter=(lambda: MagicMock()) if ephemeral else None,
        )

        node = ToolNode(tools)
        assert "Agent" in node._injected_args
