# tests/test_imports.py
def test_all_public_classes_importable():
    """All public classes should be importable from the top-level package."""
    from arcgis_item_graph import (
        ItemGraphCreator,
        ItemGraphUpdater,
        ItemGraphQuery,
        QueryResult,
        ItemGraphReporter,
        ItemGraphVisualizer,
    )
