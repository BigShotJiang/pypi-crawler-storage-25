# tests/test_updater.py
from unittest.mock import MagicMock, patch
from pathlib import Path
import pytest
from arcgis_item_graph.updater import ItemGraphUpdater
from tests.conftest import make_mock_node, make_mock_graph


def test_updater_raises_if_timestamp_missing(tmp_path):
    """get_last_timestamp() should raise FileNotFoundError when file absent."""
    updater = ItemGraphUpdater(
        gis=MagicMock(),
        gml_file=str(tmp_path / "graph.gml"),
        timestamp_file=str(tmp_path / "ts.txt"),
    )
    with pytest.raises(FileNotFoundError):
        updater.get_last_timestamp()


def test_updater_saves_and_reads_timestamp(tmp_path):
    """save_timestamp() then get_last_timestamp() should round-trip correctly."""
    ts_file = tmp_path / "ts.txt"
    updater = ItemGraphUpdater(
        gis=MagicMock(),
        gml_file=str(tmp_path / "graph.gml"),
        timestamp_file=str(ts_file),
    )
    updater.save_timestamp(1700000000000)
    assert updater.get_last_timestamp() == 1700000000000


def test_remove_deleted_items_removes_url_nodes(tmp_path):
    """URL-shaped node IDs (REST service references) should be removed; portal IDs kept."""
    url_orphan = MagicMock()
    url_orphan.id = "https://services.arcgis.com/org/ArcGIS/rest/services/Layer/FeatureServer/0"
    url_orphan.item = None

    portal_node = make_mock_node("abc123def456abc123def456abc123de")

    graph = make_mock_graph([url_orphan, portal_node])
    graph.remove_node = MagicMock()

    updater = ItemGraphUpdater(
        gis=MagicMock(),
        gml_file=str(tmp_path / "graph.gml"),
        timestamp_file=str(tmp_path / "ts.txt"),
    )
    removed = updater.remove_deleted_items(graph)

    assert removed == 1
    graph.remove_node.assert_called_once_with(url_orphan.id)


def test_get_current_timestamp_has_millisecond_precision(tmp_path):
    """Verify get_current_timestamp preserves sub-second precision.

    The buggy formula: int(t) * 1000  → always ends in 000 (second-aligned)
    The correct formula: int(t * 1000) → preserves ms digits
    """
    import datetime as _dt
    from unittest.mock import patch

    updater = ItemGraphUpdater(
        gis=MagicMock(),
        gml_file=str(tmp_path / "g.gml"),
        timestamp_file=str(tmp_path / "ts.txt"),
    )

    # Mock datetime.datetime.now() to return a time with 456ms
    fixed_time = _dt.datetime(2024, 4, 5, 12, 34, 56, 456000)  # .456 seconds

    with patch("arcgis_item_graph.updater.datetime") as mock_dt:
        mock_dt.datetime.now.return_value = fixed_time
        ts = updater.get_current_timestamp()

    # With the bug:   int(1712320496) * 1000 = 1712320496000  (% 1000 == 0)
    # With the fix:   int(1712320496.456 * 1000) = 1712320496456
    assert ts % 1000 != 0, (
        f"Timestamp {ts} appears second-aligned (ends in 000); "
        "check for int(t)*1000 vs int(t*1000) bug"
    )
    assert ts == int(fixed_time.timestamp() * 1000)


def test_get_modified_items_passes_max_items_to_search(tmp_path):
    """Verify modified-items search forwards max_items to content.search()."""
    mock_gis = MagicMock()
    mock_gis.content.search.return_value = []

    updater = ItemGraphUpdater(
        gis=mock_gis,
        gml_file=str(tmp_path / "g.gml"),
        timestamp_file=str(tmp_path / "ts.txt"),
        max_items=500,
    )
    updater.get_modified_items_with_retry(old_timestamp=1000, new_timestamp=2000)

    call_kwargs = mock_gis.content.search.call_args
    assert call_kwargs.kwargs.get("max_items") == 500, (
        "content.search() must be called with max_items to prevent silent truncation"
    )


def test_get_modified_items_warns_on_possible_truncation(tmp_path, caplog):
    """Verify a warning is logged when returned items == max_items (possible truncation)."""
    import logging

    mock_gis = MagicMock()
    # Return exactly max_items items → possible truncation
    mock_gis.content.search.return_value = [MagicMock()] * 5

    updater = ItemGraphUpdater(
        gis=mock_gis,
        gml_file=str(tmp_path / "g.gml"),
        timestamp_file=str(tmp_path / "ts.txt"),
        max_items=5,
    )

    with caplog.at_level(logging.WARNING, logger="arcgis_item_graph.updater"):
        updater.get_modified_items_with_retry(old_timestamp=1000, new_timestamp=2000)

    assert any("truncat" in r.message.lower() for r in caplog.records), (
        "Expected a truncation warning when result count equals max_items"
    )


def test_hydration_uses_thread_pool(tmp_path):
    """Verify _hydrate_graph_items_with_diagnostics uses concurrent fetching."""
    mock_gis = MagicMock()
    # Return a fresh MagicMock item for any ID
    mock_gis.content.get.side_effect = lambda item_id: MagicMock(title=f"Item {item_id}")

    updater = ItemGraphUpdater(
        gis=mock_gis,
        gml_file=str(tmp_path / "g.gml"),
        timestamp_file=str(tmp_path / "ts.txt"),
        hydration_workers=4,
    )

    # 8 nodes to hydrate
    nodes = [MagicMock(id=f"node{i}", item=None) for i in range(8)]
    mock_graph = MagicMock()

    # Should not raise; all 8 content.get() calls must be made
    updater._hydrate_graph_items_with_diagnostics(mock_graph, nodes)

    assert mock_gis.content.get.call_count == 8


def test_hydrate_diagnostics_sets_broken_reason_on_error():
    """broken_reason is set on the node when gis.content.get raises."""
    import types
    from arcgis_item_graph.updater import ItemGraphUpdater

    gis = MagicMock()
    gis.content.get.side_effect = Exception("unable to find iteminfo error code: 500")

    updater = ItemGraphUpdater.__new__(ItemGraphUpdater)
    updater.gis = gis
    updater.hydration_workers = 1

    node = types.SimpleNamespace(id="abc123def456abc1", item=None)
    graph = MagicMock()
    graph.remove_node = MagicMock()

    updater._hydrate_graph_items_with_diagnostics(graph, [node])

    assert node.broken_reason == "deleted"


def test_hydrate_diagnostics_sets_deprecated_on_success():
    """deprecated is set on the node when gis.content.get returns a deprecated item."""
    import types
    from arcgis_item_graph.updater import ItemGraphUpdater

    mock_item = MagicMock()
    mock_item.deprecated = True

    gis = MagicMock()
    gis.content.get.return_value = mock_item

    updater = ItemGraphUpdater.__new__(ItemGraphUpdater)
    updater.gis = gis
    updater.hydration_workers = 1

    node = types.SimpleNamespace(id="abc123def456abc1", item=None)
    graph = MagicMock()

    updater._hydrate_graph_items_with_diagnostics(graph, [node])

    assert node.item is mock_item
    assert node.deprecated is True


class TestHydrationFreeLoad:
    """load_old_graph_with_retry must NOT call _hydrate_graph_items_with_diagnostics."""

    def test_load_does_not_hydrate(self, tmp_path):
        from arcgis_item_graph.updater import ItemGraphUpdater
        from unittest.mock import MagicMock, patch

        gis = MagicMock()
        gml = tmp_path / "graph.gml"
        gml.write_text("")   # file must exist for the exists() check
        ts = tmp_path / "ts.txt"
        ts.write_text("1000000")

        with patch("arcgis_item_graph.updater.load_from_file") as mock_load:
            mock_graph = MagicMock()
            mock_graph.all_items.return_value = []
            mock_load.return_value = mock_graph

            updater = ItemGraphUpdater(
                gis=gis,
                gml_file=str(gml),
                timestamp_file=str(ts),
            )
            updater.load_old_graph_with_retry()

        # No individual content.get should be triggered by the load path
        gis.content.get.assert_not_called()


class TestRemoveDeletedItemsUrlOnly:
    """remove_deleted_items() removes URL-shaped nodes; keeps portal nodes."""

    def _make_url_node(self, url):
        node = MagicMock()
        node.id = url
        node.item = None
        return node

    def _make_portal_node(self, item_id):
        node = MagicMock()
        node.id = item_id
        node.item = None  # unhydrated — must NOT be removed
        return node

    def test_removes_arcgis_rest_url_node(self, tmp_path):
        from arcgis_item_graph.updater import ItemGraphUpdater
        from unittest.mock import MagicMock
        from tests.conftest import make_mock_graph

        gis = MagicMock()
        ts = tmp_path / "ts.txt"
        ts.write_text("1000000")
        updater = ItemGraphUpdater(gis=gis, gml_file=str(tmp_path / "g.gml"), timestamp_file=str(ts))

        url = "https://services.arcgis.com/org/ArcGIS/rest/services/Layer/FeatureServer/0"
        url_node = self._make_url_node(url)
        portal_node = self._make_portal_node("aabbccdd" * 4)

        graph = make_mock_graph([url_node, portal_node])
        graph.remove_node = MagicMock()

        removed = updater.remove_deleted_items(graph)

        assert removed == 1
        graph.remove_node.assert_called_once_with(url)

    def test_keeps_unhydrated_portal_nodes(self, tmp_path):
        from arcgis_item_graph.updater import ItemGraphUpdater
        from unittest.mock import MagicMock
        from tests.conftest import make_mock_graph

        gis = MagicMock()
        ts = tmp_path / "ts.txt"
        ts.write_text("1000000")
        updater = ItemGraphUpdater(gis=gis, gml_file=str(tmp_path / "g.gml"), timestamp_file=str(ts))

        portal_node = self._make_portal_node("aabbccdd" * 4)
        graph = make_mock_graph([portal_node])
        graph.remove_node = MagicMock()

        removed = updater.remove_deleted_items(graph)

        assert removed == 0
        graph.remove_node.assert_not_called()

    def test_removes_dead_portal_node_not_in_portal(self, tmp_path):
        """Portal nodes with broken_reason='not_found' that the portal can't find are pruned."""
        from arcgis_item_graph.updater import ItemGraphUpdater
        from unittest.mock import MagicMock, patch
        from tests.conftest import make_mock_graph

        gis = MagicMock()
        ts = tmp_path / "ts.txt"
        ts.write_text("1000000")
        updater = ItemGraphUpdater(gis=gis, gml_file=str(tmp_path / "g.gml"), timestamp_file=str(ts))

        dead_node = MagicMock()
        dead_node.id = "aabbccdd" * 4
        dead_node.broken_reason = "not_found"

        graph = make_mock_graph([dead_node])
        graph.remove_node = MagicMock()

        # Batch fetch returns nothing — portal truly doesn't have this item
        with patch("arcgis_item_graph.updater.batch_fetch_items", return_value={}):
            removed = updater.remove_deleted_items(graph)

        assert removed >= 1
        graph.remove_node.assert_any_call(dead_node.id)

    def test_keeps_portal_node_recovered_by_portal(self, tmp_path):
        """Portal nodes marked broken but found in portal are kept (was a false positive)."""
        from arcgis_item_graph.updater import ItemGraphUpdater
        from unittest.mock import MagicMock, patch
        from tests.conftest import make_mock_graph

        gis = MagicMock()
        ts = tmp_path / "ts.txt"
        ts.write_text("1000000")
        updater = ItemGraphUpdater(gis=gis, gml_file=str(tmp_path / "g.gml"), timestamp_file=str(ts))

        node = MagicMock()
        node.id = "aabbccdd" * 4
        node.broken_reason = "not_found"

        graph = make_mock_graph([node])
        graph.remove_node = MagicMock()

        # Portal DOES have this item — it was a false positive
        with patch("arcgis_item_graph.updater.batch_fetch_items",
                   return_value={node.id: MagicMock()}):
            removed = updater.remove_deleted_items(graph)

        graph.remove_node.assert_not_called()

    def test_keeps_portal_node_without_broken_reason(self, tmp_path):
        """Unhydrated portal nodes with no broken_reason are preserved (not falsely pruned)."""
        from arcgis_item_graph.updater import ItemGraphUpdater
        from unittest.mock import MagicMock, patch
        from tests.conftest import make_mock_graph

        gis = MagicMock()
        ts = tmp_path / "ts.txt"
        ts.write_text("1000000")
        updater = ItemGraphUpdater(gis=gis, gml_file=str(tmp_path / "g.gml"), timestamp_file=str(ts))

        unhydrated = MagicMock()
        unhydrated.id = "aabbccdd" * 4
        unhydrated.broken_reason = None   # explicitly no broken_reason

        graph = make_mock_graph([unhydrated])
        graph.remove_node = MagicMock()

        with patch("arcgis_item_graph.updater.batch_fetch_items", return_value={}):
            updater.remove_deleted_items(graph)

        graph.remove_node.assert_not_called()
