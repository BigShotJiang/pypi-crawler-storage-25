# tests/test_creator.py
from unittest.mock import MagicMock, patch, mock_open
import pytest
from arcgis_item_graph.creator import ItemGraphCreator


def test_creator_init_creates_directories(tmp_path):
    """Creator should create parent directories for gml and timestamp files."""
    gml = tmp_path / "subdir" / "graph.gml"
    ts = tmp_path / "subdir" / "ts.txt"
    creator = ItemGraphCreator(
        gis=MagicMock(),
        gml_file=str(gml),
        timestamp_file=str(ts)
    )
    assert gml.parent.exists()
    assert ts.parent.exists()


@patch("arcgis_item_graph.creator.create_dependency_graph")
def test_create_returns_success_dict(mock_cdg, tmp_path):
    """create() should return a dict with success=True and correct keys."""
    mock_gis = MagicMock()
    mock_gis.content.search.return_value = ["item1", "item2"]

    mock_graph = MagicMock()
    mock_graph.all_items.return_value = ["item1", "item2"]
    mock_graph.write_to_file = MagicMock()
    mock_cdg.return_value = mock_graph

    creator = ItemGraphCreator(
        gis=mock_gis,
        gml_file=str(tmp_path / "graph.gml"),
        timestamp_file=str(tmp_path / "ts.txt"),
        max_items=100
    )
    result = creator.create()

    assert result["success"] is True
    assert result["items_indexed"] == 2
    assert "gml_file" in result
    assert "timestamp" in result


@patch("arcgis_item_graph.creator.create_dependency_graph")
def test_create_returns_failure_dict_on_exception(mock_cdg, tmp_path):
    """create() should catch exceptions and return success=False."""
    mock_cdg.side_effect = RuntimeError("API error")
    mock_gis = MagicMock()
    mock_gis.content.search.return_value = []

    creator = ItemGraphCreator(
        gis=mock_gis,
        gml_file=str(tmp_path / "graph.gml"),
        timestamp_file=str(tmp_path / "ts.txt")
    )
    result = creator.create()

    assert result["success"] is False
    assert "error" in result
