"""
ItemGraphCreator — builds the initial organization-wide dependency graph.
Run once to create the GML file used by ItemGraphUpdater and ItemGraphQuery.
"""
import datetime
import logging
from pathlib import Path

from arcgis.apps.itemgraph import create_dependency_graph

logger = logging.getLogger(__name__)


class ItemGraphCreator:
    """
    Builds the initial organization-wide item dependency graph.

    WARNING: Can take a very long time for large organizations.

    Args:
        gis: ArcGIS GIS connection object
        gml_file: Path where the GML file will be saved
        timestamp_file: Path where the last-updated timestamp will be saved
        max_items: Maximum number of items to index (default: 10000)
    """

    def __init__(
        self,
        gis,
        gml_file: str,
        timestamp_file: str,
        max_items: int = 10000,
    ):
        self.gis = gis
        self.gml_file = Path(gml_file)
        self.timestamp_file = Path(timestamp_file)
        self.max_items = max_items

        self.gml_file.parent.mkdir(parents=True, exist_ok=True)
        self.timestamp_file.parent.mkdir(parents=True, exist_ok=True)

    def create(self) -> dict:
        """
        Create the initial dependency graph.

        Returns:
            dict with keys: success, duration, items_indexed, gml_file,
                            timestamp_file, timestamp  (or error on failure)
        """
        logger.info("=" * 70)
        logger.info("CREATING INITIAL ITEM GRAPH")
        logger.info("=" * 70)
        logger.warning(
            "This process can take a VERY long time for large organizations."
        )
        logger.info(f"Max items to index: {self.max_items}")

        start_time = datetime.datetime.now()

        try:
            logger.info(f"Step 1/3: Searching for items (max: {self.max_items})...")
            items = self.gis.content.search("", max_items=self.max_items)
            logger.info(f"Found {len(items)} items")

            logger.info("Step 2/3: Creating dependency graph...")
            graph = create_dependency_graph(self.gis, items)
            logger.info(f"Graph created with {len(graph.all_items())} items")

            logger.info("Step 3/3: Saving graph and timestamp...")
            graph.write_to_file(str(self.gml_file))

            timestamp = int(datetime.datetime.now().timestamp() * 1000)
            self.timestamp_file.write_text(str(timestamp))

            duration = (datetime.datetime.now() - start_time).total_seconds()
            logger.info("INITIAL GRAPH CREATION COMPLETED")
            logger.info(f"Duration: {duration:.2f}s | Items: {len(graph.all_items())}")

            return {
                "success": True,
                "duration": duration,
                "items_indexed": len(graph.all_items()),
                "gml_file": str(self.gml_file),
                "timestamp_file": str(self.timestamp_file),
                "timestamp": timestamp,
            }

        except Exception as e:
            logger.error(f"Failed to create initial graph: {e}", exc_info=True)
            return {"success": False, "error": str(e)}
