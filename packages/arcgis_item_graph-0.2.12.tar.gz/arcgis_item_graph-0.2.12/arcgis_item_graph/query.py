"""
ItemGraphQuery — multi-item dependency querying with hybrid GML/live-API loading.

Usage:
    q = ItemGraphQuery(gis=gis, gml_file="path/to/graph.gml")
    result = q.query(ids=["abc123", "def456"])
    result = q.query(search="owner:jsmith type:Dashboard")
    result = q.query(ids=["abc123"], search="type:Web Map")
"""
import logging
import threading
from collections import deque
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import networkx as nx
from arcgis.gis import GIS
from arcgis.apps.itemgraph import create_dependency_graph, load_from_file, ItemGraph
from arcgis_item_graph.utils import categorize_hydration_error, retry_with_backoff, batch_fetch_items

logger = logging.getLogger(__name__)


@dataclass
class QueryResult:
    """
    Result of an ItemGraphQuery.query() call.

    Attributes:
        nodes: All ItemNode objects in the sub-graph (queried + dependencies).
        graph: Filtered ItemGraph containing only nodes and edges in this result.
        queried_ids: Set of item IDs that were explicitly queried (not pulled in
                     as dependencies).
        portal_url: Base URL of the ArcGIS portal (e.g. https://www.arcgis.com).
                    Used to build direct item links in the HTML visualizer.
    """
    nodes: list
    graph: object          # ItemGraph
    queried_ids: set = field(default_factory=set)
    portal_url: Optional[str] = None

    def save_subgraph(self, path: str) -> None:
        """Save the filtered sub-graph to a GML file."""
        self.graph.write_to_file(str(path))
        logger.info(f"Sub-graph saved to: {path}")

    def to_dataframe(self):
        """Return a pandas DataFrame summarising the dependency relationships."""
        from arcgis_item_graph.reporter import ItemGraphReporter
        return ItemGraphReporter(self).to_dataframe()

    def to_csv(self, path: str) -> None:
        """Save the dependency report to a CSV file."""
        from arcgis_item_graph.reporter import ItemGraphReporter
        ItemGraphReporter(self).to_csv(path)

    def visualize(self, output_file: Optional[str] = None,
                  show_inline: bool = False) -> None:
        """
        Render an interactive HTML graph.

        Args:
            output_file: Path to save the HTML file. If None, uses a temp file
                         when show_inline=True.
            show_inline: Display the graph inline in a Jupyter notebook.
        """
        from arcgis_item_graph.visualizer import ItemGraphVisualizer
        ItemGraphVisualizer(self).render(
            output_file=output_file, show_inline=show_inline
        )


class ItemGraphQuery:
    """
    Queries an ArcGIS item dependency graph for multiple items simultaneously.

    Hybrid loading strategy:
      1. Loads the full org graph from a GML file on first query (fast).
      2. Items not found in the GML are fetched live via create_dependency_graph().
      3. Live results are merged into the in-memory graph for the session.

    Args:
        gis: ArcGIS GIS connection object.
        gml_file: Path to the GML file produced by ItemGraphCreator/ItemGraphUpdater.
    """

    def __init__(self, gis, gml_file: str, fetch_workers: int = 10,
                 hydration_workers: int = 10,
                 max_depth: Optional[int] = None):
        self.gis = gis
        self.gml_file = Path(gml_file)
        self.fetch_workers = fetch_workers
        self.hydration_workers = hydration_workers
        self.max_depth = max_depth
        self._graph: Optional[ItemGraph] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def query(
        self,
        ids: Optional[list] = None,
        search: Optional[str] = None,
    ) -> QueryResult:
        """
        Query dependency information for one or more items.

        Args:
            ids: List of ArcGIS item ID strings to query.
            search: Portal content search string (e.g. "owner:jsmith type:Dashboard").
                    All matching items are included in the query.

        Returns:
            QueryResult containing the sub-graph, nodes, and queried IDs.

        Raises:
            ValueError: If neither ids nor search is provided.
            FileNotFoundError: If the GML file does not exist.
        """
        if not ids and not search:
            raise ValueError("Provide at least one of: ids, search")

        self._ensure_graph_loaded()

        # Collect all item IDs to query
        queried_ids = set(ids or [])

        if search:
            found = self.gis.content.search(search)
            queried_ids.update(item.itemid for item in found)
            logger.info(f"Search '{search}' returned {len(found)} items")

        logger.info(f"Querying {len(queried_ids)} items from graph...")

        # Hybrid: resolve missing items via live API
        self._resolve_missing_items(queried_ids)

        # Recursive traversal in both directions (depth-limited if configured)
        visited_ids = self._traverse_recursive(queried_ids, max_depth=self.max_depth)
        depth_info = f", max_depth={self.max_depth}" if self.max_depth is not None else ""
        logger.info(
            f"Traversal complete: {len(visited_ids)} nodes "
            f"(from {len(queried_ids)} seed items{depth_info})"
        )

        # Build result
        result_nodes = [
            self._graph.get_node(nid)
            for nid in visited_ids
            if self._graph.get_node(nid) is not None
        ]
        subgraph = self._build_subgraph(visited_ids)

        # Hydrate result nodes with portal metadata (title, type, owner).
        # Only fetches for nodes missing item data — typically the small
        # result set, not the full graph.
        self._hydrate_result_nodes(result_nodes)

        return QueryResult(
            nodes=result_nodes,
            graph=subgraph,
            queried_ids=queried_ids,
            portal_url=self.gis.url if self.gis else None,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _ensure_graph_loaded(self) -> None:
        """Load the GML graph on first call (lazy load)."""
        if self._graph is not None:
            return
        if not self.gml_file.exists():
            raise FileNotFoundError(f"GML file not found: {self.gml_file}")
        logger.info(f"Loading graph from {self.gml_file}...")
        self._graph = load_from_file(
            str(self.gml_file), self.gis, include_items=False
        )
        logger.info(f"Loaded graph: {len(self._graph.all_items())} nodes")

    def _get_graph_ids(self) -> set:
        """Return the set of all item IDs currently in the in-memory graph."""
        return {node.id for node in self._graph.all_items()}

    def _resolve_missing_items(self, queried_ids: set) -> None:
        """
        For any queried IDs not in the GML graph, fetch them live and merge.

        Uses ThreadPoolExecutor to fetch missing items concurrently rather than
        serially. Modifies self._graph in place.
        """
        graph_ids = self._get_graph_ids()
        missing = queried_ids - graph_ids

        if not missing:
            return

        logger.info(
            f"{len(missing)} items not found in GML — fetching live from portal..."
        )

        def _fetch(item_id):
            try:
                return self.gis.content.get(item_id)
            except Exception as exc:
                logger.warning(f"Failed to fetch item {item_id}: {exc}")
                return None

        live_items = []
        with ThreadPoolExecutor(max_workers=self.fetch_workers) as executor:
            futures = {executor.submit(_fetch, item_id): item_id for item_id in missing}
            for future in as_completed(futures):
                item = future.result()
                if item is not None:
                    live_items.append(item)

        if not live_items:
            logger.warning("None of the missing items were found in the portal.")
            return

        logger.info(f"Building live sub-graph for {len(live_items)} items...")
        live_graph = create_dependency_graph(self.gis, live_items)

        merged = nx.compose(self._graph, live_graph)
        self._graph = ItemGraph(self.gis, digraph=merged)
        logger.info(
            f"Merged live graph. Total nodes: {len(self._graph.all_items())}"
        )

    def _traverse_recursive(self, seed_ids: set,
                             max_depth: Optional[int] = None) -> set:
        """
        BFS from seed_ids following edges in both directions.

        Uses collections.deque for O(1) popleft (list.pop(0) is O(n)).

        Follows:
          - contains()   → what each item depends on (outgoing)
          - required_by() → what depends on each item (incoming)

        Args:
            seed_ids: Starting item IDs (depth 0).
            max_depth: Maximum hops from any seed item. None = unlimited.

        Returns:
            Set of all item IDs reachable from seed_ids within max_depth.
        """
        visited: set = set()
        # Queue entries: (node_id, depth)
        queue: deque = deque((nid, 0) for nid in seed_ids)

        while queue:
            node_id, depth = queue.popleft()
            if node_id in visited:
                continue
            visited.add(node_id)

            # Don't expand neighbours beyond the depth limit
            if max_depth is not None and depth >= max_depth:
                continue

            node = self._graph.get_node(node_id)
            if node is None:
                continue

            try:
                for dep_id in node.contains("id"):
                    if dep_id not in visited:
                        queue.append((dep_id, depth + 1))
            except Exception as e:
                logger.debug(f"contains() error for {node_id}: {e}")

            try:
                for req_id in node.required_by("id"):
                    if req_id not in visited:
                        queue.append((req_id, depth + 1))
            except Exception as e:
                logger.debug(f"required_by() error for {node_id}: {e}")

        return visited

    def _build_subgraph(self, visited_ids: set) -> ItemGraph:
        """
        Build a new ItemGraph containing only the nodes in visited_ids
        and the edges between them.
        """
        # The underlying DiGraph uses item ID strings as node keys
        # (confirmed by ItemGraph.all_items('id') returning strings).
        # Filter to only nodes whose ID is in visited_ids.
        valid_keys = {
            node.id for node in self._graph.all_items()
            if node.id in visited_ids
        }
        nx_sub = nx.DiGraph(self._graph.subgraph(valid_keys))
        return ItemGraph(self.gis, digraph=nx_sub)

    def _hydrate_result_nodes(self, nodes: list) -> None:
        """
        Fetch portal metadata (title, type, owner) for result nodes missing item data.

        Two-pass approach:
          1. Fast: batch content.search() via batch_fetch_items (reduces API calls).
          2. Fallback: for nodes the batch missed, try content.get() directly —
             content.search() uses a search index that can miss items accessible
             via direct fetch (ungrouped items, indexing lag, collaboration items).

        Only marks a node broken if BOTH passes fail to find it.
        """
        needs_hydration = [
            n for n in nodes
            if n is not None
            and (n.item is None or n.item == "")
            and not (n.id.startswith("http://") or n.id.startswith("https://"))
        ]
        if not needs_hydration:
            return

        logger.info(
            "Hydrating %d result node(s) with portal metadata (batched)...",
            len(needs_hydration),
        )

        item_map = batch_fetch_items(
            self.gis,
            [n.id for n in needs_hydration],
            batch_size=50,
            workers=self.hydration_workers,
        )

        logger.info(
            "Batch fetch complete: %d/%d items found in portal",
            len(item_map),
            len(needs_hydration),
        )

        # ── Fallback: verify batch misses via direct content.get() ────────────────
        # content.search() can miss items that are accessible via direct fetch
        # (search-index lag, ungrouped items, distributed collaboration items).
        # Only mark a node broken if content.get() ALSO fails to find it.
        batch_misses = [n for n in needs_hydration if n.id not in item_map]
        if batch_misses:
            logger.info(
                "Verifying %d batch-missed item(s) via direct content.get()...",
                len(batch_misses),
            )
            for node in batch_misses:
                try:
                    item = self.gis.content.get(node.id)
                except Exception as exc:
                    logger.debug(
                        "content.get() error for %s: %s", node.id[:8], exc
                    )
                    item = None
                if item is not None:
                    item_map[node.id] = item
                    logger.info(
                        "  %s... recovered via direct fetch (batch search miss)",
                        node.id[:8],
                    )

        # ── Assign items or broken_reason for each node ───────────────────────────
        for node in needs_hydration:
            item = item_map.get(node.id)
            if item is None:
                logger.debug("  %s... → not found in portal (item=None)", node.id[:8])
                node.broken_reason = "not_found"
            else:
                try:
                    node.item = item
                    node.deprecated = bool(getattr(item, "deprecated", False))
                    logger.debug("  %s... → %s (%s)", node.id[:8], item.title, item.type)
                except Exception as exc:
                    error_category = categorize_hydration_error(str(exc), node.id)
                    logger.warning(
                        "[%s] Item stub returned but inaccessible for %s: %s",
                        error_category, node.id, exc,
                    )
                    node.item = None
                    node.broken_reason = error_category

    def _hydrate_single_node(self, node) -> None:
        """
        Fetch portal metadata for one node, with category-aware error handling.

        - Network errors: retried with exponential backoff (up to 3 attempts).
        - Permission / deleted / malformed: re-raised immediately (no retry).
        - None return (item inaccessible): logged at DEBUG, node left unhydrated.
        """
        def _is_network_error(exc: Exception) -> bool:
            return categorize_hydration_error(str(exc), node.id) == "network"

        try:
            item = retry_with_backoff(
                lambda: self.gis.content.get(node.id),
                max_attempts=3,
                initial_delay=1.0,
                label=node.id[:8],
                should_retry=_is_network_error,
            )
        except Exception as exc:
            error_category = categorize_hydration_error(str(exc), node.id)
            logger.warning(
                f"[{error_category}] Could not hydrate node {node.id}: {exc}"
            )
            node.broken_reason = error_category
            return

        if item is None:
            # Portal returned None — item deleted or caller has no access.
            logger.debug(f"  {node.id[:8]}... → not found in portal (item=None)")
            node.broken_reason = "not_found"
            return

        # The ArcGIS SDK uses lazy loading — accessing any property that isn't
        # in the stub dict triggers a live API call (_hydrate). Guard against
        # that call failing even though content.get() returned a stub.
        try:
            node.item = item
            node.deprecated = bool(getattr(item, "deprecated", False))
            logger.debug(
                f"  {node.id[:8]}... → {node.item.title} ({node.item.type})"
            )
        except Exception as exc:
            error_category = categorize_hydration_error(str(exc), node.id)
            logger.warning(
                f"[{error_category}] Item stub returned but inaccessible "
                f"for {node.id}: {exc}"
            )
            node.item = None
            node.broken_reason = error_category
