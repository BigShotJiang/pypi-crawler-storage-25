"""
ItemGraphReporter — generates tabular dependency reports from a QueryResult.
"""
import logging
from typing import TYPE_CHECKING

import pandas as pd

from arcgis_item_graph.utils import classify_node_id

if TYPE_CHECKING:
    from arcgis_item_graph.query import QueryResult

logger = logging.getLogger(__name__)

# Column order for the Dependency Edges sheet
_EDGE_COLS = [
    "source_id", "source_title", "source_type", "source_owner",
    "dep_id", "dep_id_type", "dep_title", "dep_type", "dep_owner", "dep_status",
]


class ItemGraphReporter:
    """
    Generates pandas DataFrames, CSV, and Excel reports from a QueryResult.

    Args:
        result: A QueryResult produced by ItemGraphQuery.query().
    """

    def __init__(self, result: "QueryResult"):
        self.result = result

    def to_dataframe(self) -> pd.DataFrame:
        """
        Build a DataFrame summarising each item in the query result.

        Columns:
            item_id, title, type, owner, status,
            contains_count, required_by_count,
            direct_dependencies, queried_item

        ``status`` is "healthy" when portal metadata was successfully fetched
        and "broken" when the item could not be hydrated (deleted, inaccessible,
        or otherwise unresolvable).
        """
        rows = []
        for node in self.result.nodes:
            try:
                contains_ids = node.contains("id")
            except Exception as e:
                logger.warning("node.contains() raised for node %s: %s", node.id, e)
                contains_ids = []

            try:
                required_by_ids = node.required_by("id")
            except Exception as e:
                logger.warning("node.required_by() raised for node %s: %s", node.id, e)
                required_by_ids = []

            title = owner = item_type = None
            hydrated = node.item is not None
            if node.item:
                title = getattr(node.item, "title", None)
                item_type = getattr(node.item, "type", None)
                owner = getattr(node.item, "owner", None)

            rows.append({
                "item_id": node.id,
                "id_type": classify_node_id(node.id),
                "title": title,
                "type": item_type,
                "owner": owner,
                "status": "healthy" if hydrated else "broken",
                "contains_count": len(contains_ids),
                "required_by_count": len(required_by_ids),
                "direct_dependencies": contains_ids,
                "queried_item": node.id in self.result.queried_ids,
                "broken_reason": getattr(node, "broken_reason", None)
                                 if isinstance(getattr(node, "broken_reason", None), (str, type(None)))
                                 else None,
                "deprecated":    getattr(node, "deprecated", None)
                                 if hydrated and isinstance(getattr(node, "deprecated", None), (bool, type(None)))
                                 else None,
            })

        df = pd.DataFrame(rows)
        logger.info(f"Report built: {len(df)} rows")
        return df

    def to_csv(self, path: str) -> None:
        """
        Save the dependency report to a CSV file.

        Args:
            path: File path for the CSV output.
        """
        df = self.to_dataframe()
        df.to_csv(path, index=False)
        logger.info(f"Report saved to: {path}")

    def to_excel(self, path: str) -> None:
        """
        Save the dependency report to an Excel workbook with three sheets.

        Calls to_dataframe() once and reuses the direct_dependencies column
        to build the edge sheet — avoids calling node.contains() twice per node.

        Sheets:
            All Items          — one row per node; includes status ("healthy" /
                                 "broken"), type, owner, and dependency counts.
                                 Use as a high-level inventory for migration planning.
            Dependency Edges   — one row per source→dependency relationship with
                                 resolved titles, types, and dep_status.  Suitable
                                 for direct use in a migration script to enumerate
                                 and validate every relationship.
            Broken Dependencies — filtered subset of Dependency Edges where
                                  dep_status == "broken".  These are relationships
                                  that will break after migration if not repaired.

        dep_status values:
            healthy        — dependency was found and metadata resolved
            broken         — dependency is in the result but could not be hydrated
                             (deleted item, permission error, or malformed ID)
            not_in_result  — dependency ID is referenced by an edge but was not
                             included in the query result (outside traversal scope)

        Args:
            path: File path for the .xlsx output.
        """
        df_items, df_edges, df_broken, df_external = self._build_excel_data()
        with pd.ExcelWriter(path, engine="openpyxl") as writer:
            df_items.to_excel(writer, sheet_name="All Items", index=False)
            df_edges.to_excel(writer, sheet_name="Dependency Edges", index=False)
            df_broken.to_excel(writer, sheet_name="Broken Dependencies", index=False)
            df_external.to_excel(writer, sheet_name="External References", index=False)
        logger.info(f"Excel report saved to: {path}")

    def to_excel_bytes(self) -> bytes:
        """Return the Excel workbook as raw bytes (same content as to_excel()).

        Used by the --serve dashboard's /export/excel endpoint to stream the
        workbook directly to the browser without writing a temporary file.
        """
        import io
        df_items, df_edges, df_broken, df_external = self._build_excel_data()
        buf = io.BytesIO()
        with pd.ExcelWriter(buf, engine="openpyxl") as writer:
            df_items.to_excel(writer, sheet_name="All Items", index=False)
            df_edges.to_excel(writer, sheet_name="Dependency Edges", index=False)
            df_broken.to_excel(writer, sheet_name="Broken Dependencies", index=False)
            df_external.to_excel(writer, sheet_name="External References", index=False)
        return buf.getvalue()

    def _build_excel_data(self):
        """Build the three DataFrames used by to_excel() and to_excel_bytes().

        Returns:
            Tuple of (df_items, df_edges, df_broken).
        """
        node_lookup = {n.id: n for n in self.result.nodes if n is not None}

        # ── Sheet 1: All Items ────────────────────────────────────────────────
        df_full = self.to_dataframe()
        df_items = df_full.drop(columns=["direct_dependencies"], errors="ignore")

        contains_map: dict = {
            row["item_id"]: (row["direct_dependencies"] or [])
            for _, row in df_full.iterrows()
        }

        # ── Sheet 2: Dependency Edges ─────────────────────────────────────────
        edge_rows = []
        for node in self.result.nodes:
            if node is None:
                continue

            src_title = src_type = src_owner = None
            if node.item:
                src_title = getattr(node.item, "title", None)
                src_type = getattr(node.item, "type", None)
                src_owner = getattr(node.item, "owner", None)

            for dep_id in contains_map.get(node.id, []):
                dep_node = node_lookup.get(dep_id)
                dep_title = dep_type = dep_owner = None
                if dep_node and dep_node.item:
                    dep_title = getattr(dep_node.item, "title", None)
                    dep_type = getattr(dep_node.item, "type", None)
                    dep_owner = getattr(dep_node.item, "owner", None)

                if dep_node is None:
                    dep_status = "not_in_result"
                elif dep_node.item is None:
                    dep_status = "broken"
                else:
                    dep_status = "healthy"

                edge_rows.append({
                    "source_id": node.id,
                    "source_title": src_title,
                    "source_type": src_type,
                    "source_owner": src_owner,
                    "dep_id": dep_id,
                    "dep_id_type": classify_node_id(dep_id),
                    "dep_title": dep_title,
                    "dep_type": dep_type,
                    "dep_owner": dep_owner,
                    "dep_status": dep_status,
                })

        df_edges = (
            pd.DataFrame(edge_rows)
            if edge_rows
            else pd.DataFrame(columns=_EDGE_COLS)
        )

        # ── Sheet 3: Broken Dependencies ──────────────────────────────────────
        df_broken = (
            df_edges[
                (df_edges["dep_status"] == "broken") &
                (df_edges["dep_id_type"] == "portal_id")
            ].copy()
            if not df_edges.empty
            else df_edges.copy()
        )

        # ── Sheet 4: External References ──────────────────────────────────────
        _EXT_COLS = ["url", "url_type", "referenced_by_count", "referenced_by_titles"]
        if not df_edges.empty and "dep_id_type" in df_edges.columns:
            url_edges = df_edges[df_edges["dep_id_type"] != "portal_id"]
            if not url_edges.empty:
                ext_rows = []
                for url, group in url_edges.groupby("dep_id"):
                    titles = [t for t in group["source_title"].dropna().unique()[:10]]
                    ext_rows.append({
                        "url": url,
                        "url_type": group["dep_id_type"].iloc[0],
                        "referenced_by_count": group["source_id"].nunique(),
                        "referenced_by_titles": ", ".join(str(t) for t in titles),
                    })
                df_external = (
                    pd.DataFrame(ext_rows)
                    .sort_values("referenced_by_count", ascending=False)
                    .reset_index(drop=True)
                )
            else:
                df_external = pd.DataFrame(columns=_EXT_COLS)
        else:
            df_external = pd.DataFrame(columns=_EXT_COLS)

        return df_items, df_edges, df_broken, df_external


# ---------------------------------------------------------------------------
# Module-level helper — build Excel from serialized graph data (no re-query)
# ---------------------------------------------------------------------------

def build_excel_from_graph_data(graph_data: dict) -> bytes:
    """Build a dependency_report.xlsx from the serialized graph data dict.

    Accepts the same JSON structure produced by ``ItemGraphVisualizer.serialize()``
    (the ``G`` object embedded in the HTML dashboard).  Does **not** contact the
    live ArcGIS API — converts whatever is already loaded in the browser.

    Sheets match those produced by ``ItemGraphReporter.to_excel_bytes()``:
        All Items          — one row per node
        Dependency Edges   — one row per forward edge with dep_status
        Broken Dependencies — subset where dep_status == "broken"

    Args:
        graph_data: Dict with keys ``nodes``, ``edges``, ``meta`` as serialised
                    by ``ItemGraphVisualizer.serialize()``.

    Returns:
        Raw bytes of the ``.xlsx`` workbook.
    """
    import io

    nodes: list = graph_data.get("nodes", [])
    edges: list = graph_data.get("edges", [])
    meta: dict = graph_data.get("meta", {})

    node_map = {n["id"]: n for n in nodes}
    queried_ids = set(meta.get("queried_ids", []))

    # Build contains/required_by counts from forward edges only
    contains_map: dict = {}
    required_by_map: dict = {}
    for e in edges:
        if e.get("direction") != "forward":
            continue
        (contains_map.setdefault(e["source"], [])).append(e["target"])
        (required_by_map.setdefault(e["target"], [])).append(e["source"])

    # ── Sheet 1: All Items ────────────────────────────────────────────────
    items_rows = []
    for n in nodes:
        items_rows.append({
            "item_id":           n["id"],
            "title":             n.get("title"),
            "type":              n.get("type"),
            "owner":             n.get("owner"),
            "status":            "healthy" if n.get("hydrated") else "broken",
            "contains_count":    len(contains_map.get(n["id"], [])),
            "required_by_count": len(required_by_map.get(n["id"], [])),
            "queried_item":      n["id"] in queried_ids,
            "broken_reason":     n.get("broken_reason"),
            "deprecated":        bool(n.get("deprecated", False)),
        })
    df_items = pd.DataFrame(items_rows) if items_rows else pd.DataFrame(columns=[
        "item_id", "title", "type", "owner", "status",
        "contains_count", "required_by_count", "queried_item", "broken_reason", "deprecated",
    ])

    # ── Sheet 2: Dependency Edges ─────────────────────────────────────────
    edge_rows = []
    for e in edges:
        if e.get("direction") != "forward":
            continue
        src = node_map.get(e["source"], {})
        dep = node_map.get(e["target"])
        if dep is None:
            dep_status = "not_in_result"
        elif not dep.get("hydrated"):
            dep_status = "broken"
        else:
            dep_status = "healthy"
        edge_rows.append({
            "source_id":    e["source"],
            "source_title": src.get("title"),
            "source_type":  src.get("type"),
            "source_owner": src.get("owner"),
            "dep_id":       e["target"],
            "dep_id_type":  classify_node_id(e["target"]),
            "dep_title":    dep.get("title") if dep else None,
            "dep_type":     dep.get("type")  if dep else None,
            "dep_owner":    dep.get("owner") if dep else None,
            "dep_status":   dep_status,
        })
    df_edges = (
        pd.DataFrame(edge_rows) if edge_rows
        else pd.DataFrame(columns=_EDGE_COLS)
    )

    # ── Sheet 3: Broken Dependencies ──────────────────────────────────────
    df_broken = (
        df_edges[
            (df_edges["dep_status"] == "broken") &
            (df_edges["dep_id_type"] == "portal_id")
        ].copy()
        if not df_edges.empty
        else df_edges.copy()
    )

    # ── Sheet 4: External References ──────────────────────────────────────
    _EXT_COLS = ["url", "url_type", "referenced_by_count", "referenced_by_titles"]
    if not df_edges.empty and "dep_id_type" in df_edges.columns:
        url_edges = df_edges[df_edges["dep_id_type"] != "portal_id"]
        if not url_edges.empty:
            ext_rows = []
            for url, group in url_edges.groupby("dep_id"):
                titles = [t for t in group["source_title"].dropna().unique()[:10]]
                ext_rows.append({
                    "url": url,
                    "url_type": group["dep_id_type"].iloc[0],
                    "referenced_by_count": group["source_id"].nunique(),
                    "referenced_by_titles": ", ".join(str(t) for t in titles),
                })
            df_external = (
                pd.DataFrame(ext_rows)
                .sort_values("referenced_by_count", ascending=False)
                .reset_index(drop=True)
            )
        else:
            df_external = pd.DataFrame(columns=_EXT_COLS)
    else:
        df_external = pd.DataFrame(columns=_EXT_COLS)

    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        df_items.to_excel(writer, sheet_name="All Items", index=False)
        df_edges.to_excel(writer, sheet_name="Dependency Edges", index=False)
        df_broken.to_excel(writer, sheet_name="Broken Dependencies", index=False)
        df_external.to_excel(writer, sheet_name="External References", index=False)
    logger.info("Excel built from graph data: %d nodes, %d edges", len(nodes), len(edge_rows))
    return buf.getvalue()
