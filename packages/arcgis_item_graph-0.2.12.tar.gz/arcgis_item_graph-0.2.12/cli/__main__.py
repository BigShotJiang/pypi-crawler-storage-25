"""cli/__main__.py — Enables `python -m cli` invocation."""
from cli.main import main

main()
