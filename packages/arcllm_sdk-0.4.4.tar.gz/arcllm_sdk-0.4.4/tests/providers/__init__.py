"""Tests for provider adapters."""
