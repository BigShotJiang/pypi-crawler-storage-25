"""
Cohere adapter for arcllm.

Cohere uses a different API format than OpenAI with:
- Different endpoint (/v2/chat for chat completions)
- Different message format
- Different tool calling format
"""

from __future__ import annotations

import time
from typing import Any, cast

import orjson

from arcllm.exceptions import (
    ArcLLMError,
    AuthenticationError,
    BudgetExceededError,
    InternalServerError,
    InvalidRequestError,
    ProviderAPIError,
    RateLimitError,
    ResponseParseError,
    ServiceUnavailableError,
    UnsupportedModelError,
)
from arcllm.providers.base import (
    COMMON_PARAMS,
    BaseAdapter,
    ProviderConfig,
    RequestData,
    register_provider,
)
from arcllm.types import (
    Choice,
    ChunkChoice,
    ChunkDelta,
    EmbeddingData,
    EmbeddingResponse,
    EmbeddingUsage,
    FunctionCall,
    Message,
    ModelResponse,
    RerankResponse,
    RerankResult,
    StreamChunk,
    ToolCall,
    Usage,
)

__all__ = ["CohereAdapter"]


class CohereAdapter(BaseAdapter):
    """Adapter for Cohere API."""

    provider_name = "cohere"

    supported_params = COMMON_PARAMS | {
        "preamble",
        "connectors",
        "documents",
        "citation_options",
        "safety_mode",
    }

    def __init__(self, config: ProviderConfig) -> None:
        super().__init__(config)
        self._api_base = config.api_base or "https://api.cohere.com/v2"

    def _build_headers(self) -> dict[str, str]:
        """Get request headers."""
        api_key = self._get_api_key("COHERE_API_KEY")
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        if self.config.extra_headers:
            headers.update(self.config.extra_headers)
        return headers

    def _convert_messages(
        self, messages: list[dict[str, Any]]
    ) -> tuple[str | None, list[dict[str, Any]]]:
        """Convert OpenAI messages to Cohere format."""
        system_message: str | None = None
        cohere_messages: list[dict[str, Any]] = []

        for msg in messages:
            role = msg.get("role", "")
            content = msg.get("content", "")

            if role == "system":
                if system_message:
                    system_message += "\n\n" + content
                else:
                    system_message = content
            elif role == "user":
                cohere_messages.append({"role": "user", "content": content})
            elif role == "assistant":
                cohere_msg: dict[str, Any] = {"role": "assistant"}
                if content:
                    cohere_msg["content"] = content

                # Handle tool calls
                if msg.get("tool_calls"):
                    tool_calls: list[dict[str, Any]] = []
                    for tc in msg["tool_calls"]:
                        func: dict[str, Any] = tc.get("function", {})
                        tool_calls.append(
                            {
                                "id": tc.get("id", ""),
                                "type": "function",
                                "function": {
                                    "name": func.get("name", ""),
                                    "arguments": func.get("arguments", "{}"),
                                },
                            }
                        )
                    cohere_msg["tool_calls"] = tool_calls

                cohere_messages.append(cohere_msg)
            elif role == "tool":
                cohere_messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": msg.get("tool_call_id", ""),
                        "content": content,
                    }
                )

        return system_message, cohere_messages

    def _convert_tools(self, tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Convert OpenAI tools to Cohere format."""
        cohere_tools: list[dict[str, Any]] = []

        for tool in tools:
            if tool.get("type") == "function":
                func = tool.get("function", {})
                cohere_tools.append(
                    {
                        "type": "function",
                        "function": {
                            "name": func.get("name", ""),
                            "description": func.get("description", ""),
                            "parameters": func.get("parameters", {}),
                        },
                    }
                )

        return cohere_tools

    def build_request(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        stream: bool = False,
        drop_params: bool = False,
        **kwargs: Any,
    ) -> RequestData:
        """Build Cohere chat request."""
        kwargs = self._check_params(model, drop_params, **kwargs)

        system_message, cohere_messages = self._convert_messages(messages)

        body: dict[str, Any] = {
            "model": model,
            "messages": cohere_messages,
            "stream": stream,
        }

        # Add system message as preamble
        if system_message:
            body["preamble"] = system_message

        # Add optional parameters
        if "temperature" in kwargs and kwargs["temperature"] is not None:
            body["temperature"] = kwargs["temperature"]
        if "top_p" in kwargs and kwargs["top_p"] is not None:
            body["p"] = kwargs["top_p"]
        if "max_tokens" in kwargs and kwargs["max_tokens"] is not None:
            body["max_tokens"] = kwargs["max_tokens"]
        if kwargs.get("stop"):
            stop_val: str | list[str] = kwargs["stop"]
            stops: list[str] = stop_val if isinstance(stop_val, list) else [stop_val]
            body["stop_sequences"] = stops
        if "seed" in kwargs and kwargs["seed"] is not None:
            body["seed"] = kwargs["seed"]
        if "frequency_penalty" in kwargs and kwargs["frequency_penalty"] is not None:
            body["frequency_penalty"] = kwargs["frequency_penalty"]
        if "presence_penalty" in kwargs and kwargs["presence_penalty"] is not None:
            body["presence_penalty"] = kwargs["presence_penalty"]

        # Cohere-specific params
        if "preamble" in kwargs:
            body["preamble"] = kwargs["preamble"]
        if "connectors" in kwargs:
            body["connectors"] = kwargs["connectors"]
        if "documents" in kwargs:
            body["documents"] = kwargs["documents"]
        if "safety_mode" in kwargs:
            body["safety_mode"] = kwargs["safety_mode"]

        # Handle tools
        if kwargs.get("tools"):
            body["tools"] = self._convert_tools(kwargs["tools"])

        # Handle response_format
        if kwargs.get("response_format"):
            rf = kwargs["response_format"]
            if rf.get("type") == "json_object":
                body["response_format"] = {"type": "json_object"}
            elif rf.get("type") == "json_schema" and "json_schema" in rf:
                body["response_format"] = {
                    "type": "json_object",
                    "schema": rf["json_schema"].get("schema", {}),
                }

        url = f"{self._api_base}/chat"
        body_bytes = orjson.dumps(body)

        return RequestData(
            method="POST",
            url=url,
            headers=self._get_headers(),
            body=body_bytes,
            timeout=self.config.timeout,
        )

    def parse_response(self, data: bytes, model: str) -> ModelResponse:
        """Parse Cohere chat response."""
        try:
            resp = orjson.loads(data)
        except (orjson.JSONDecodeError, UnicodeDecodeError) as e:
            raise ResponseParseError(
                f"Failed to parse response JSON: {e}",
                provider=self.provider_name,
                raw_data=data,
            ) from e

        return self._build_model_response(resp, model)

    def _build_model_response(self, resp: dict[str, Any], model: str) -> ModelResponse:
        """Build ModelResponse from Cohere response."""
        # Cache timestamp once for this response
        now = int(time.time())
        # Cohere v2 returns message directly
        message_data = resp.get("message", {})
        content_list = message_data.get("content", [])

        # Use list + join for efficient string building
        text_parts: list[str] = []
        tool_calls: list[ToolCall] = []

        for item in content_list:
            if item.get("type") == "text":
                text_parts.append(item.get("text", ""))
            elif item.get("type") == "tool_call":
                tc = item
                tool_calls.append(
                    ToolCall(
                        id=tc.get("id", ""),
                        type="function",
                        function=FunctionCall(
                            name=tc.get("name", ""),
                            arguments=orjson.dumps(tc.get("parameters", {})).decode(),
                        ),
                    )
                )

        # Also check for tool_calls at message level
        if message_data.get("tool_calls"):
            for tc in message_data["tool_calls"]:
                func = tc.get("function", {})
                tool_calls.append(
                    ToolCall(
                        id=tc.get("id", ""),
                        type="function",
                        function=FunctionCall(
                            name=func.get("name", ""),
                            arguments=func.get("arguments", "{}"),
                        ),
                    )
                )

        text_content = "".join(text_parts) if text_parts else None
        message = Message(
            role="assistant",
            content=text_content,
            tool_calls=tool_calls or None,
        )

        # Map finish reason
        finish_reason_map = {
            "COMPLETE": "stop",
            "MAX_TOKENS": "length",
            "STOP_SEQUENCE": "stop",
            "TOOL_CALL": "tool_calls",
        }
        finish_reason = finish_reason_map.get(resp.get("finish_reason", ""), "stop")

        choice = Choice(
            index=0,
            message=message,
            finish_reason=finish_reason,
        )

        # Parse usage
        usage_data = resp.get("usage", {})
        billed = usage_data.get("billed_units", {})
        tokens = usage_data.get("tokens", {})

        usage = Usage(
            prompt_tokens=tokens.get("input_tokens", 0) or billed.get("input_tokens", 0),
            completion_tokens=tokens.get("output_tokens", 0) or billed.get("output_tokens", 0),
            total_tokens=(tokens.get("input_tokens", 0) or 0)
            + (tokens.get("output_tokens", 0) or 0),
        )

        return ModelResponse(
            id=resp.get("id", ""),
            object="chat.completion",
            created=now,
            model=model,
            choices=[choice],
            usage=usage,
            model_extra={"usage": usage.model_dump()},
        )

    def parse_stream_event(self, data: str, model: str) -> StreamChunk | None:
        """Parse Cohere streaming event."""
        data = data.strip()
        if not data:
            return None

        try:
            event = orjson.loads(data)
        except orjson.JSONDecodeError:
            return None

        event_type = event.get("type", "")

        if event_type == "message-start":
            return StreamChunk(
                id=event.get("id", ""),
                model=model,
                choices=[
                    ChunkChoice(
                        index=0,
                        delta=ChunkDelta(role="assistant"),
                        finish_reason=None,
                    )
                ],
            )

        if event_type == "content-start":
            return None  # Skip content start markers

        if event_type == "content-delta":
            delta_data = event.get("delta", {})
            message = delta_data.get("message", {})
            content = message.get("content", {})
            text = content.get("text", "")

            return StreamChunk(
                id="",
                model=model,
                choices=[
                    ChunkChoice(
                        index=0,
                        delta=ChunkDelta(content=text),
                        finish_reason=None,
                    )
                ],
            )

        if event_type == "tool-call-start":
            delta_data = event.get("delta", {})
            tc = delta_data.get("tool_call", {})
            return StreamChunk(
                id="",
                model=model,
                choices=[
                    ChunkChoice(
                        index=0,
                        delta=ChunkDelta(
                            tool_calls=[
                                {
                                    "index": event.get("index", 0),
                                    "id": tc.get("id", ""),
                                    "type": "function",
                                    "function": {
                                        "name": tc.get("name", ""),
                                        "arguments": "",
                                    },
                                }
                            ]
                        ),
                        finish_reason=None,
                    )
                ],
            )

        if event_type == "tool-call-delta":
            delta_data = event.get("delta", {})
            tc = delta_data.get("tool_call", {})
            args = tc.get("parameters", "")

            return StreamChunk(
                id="",
                model=model,
                choices=[
                    ChunkChoice(
                        index=0,
                        delta=ChunkDelta(
                            tool_calls=[
                                {
                                    "index": event.get("index", 0),
                                    "function": {
                                        "arguments": args,
                                    },
                                }
                            ]
                        ),
                        finish_reason=None,
                    )
                ],
            )

        if event_type == "message-end":
            delta_data = event.get("delta", {})
            finish_reason_map = {
                "COMPLETE": "stop",
                "MAX_TOKENS": "length",
                "STOP_SEQUENCE": "stop",
                "TOOL_CALL": "tool_calls",
            }
            finish_reason = finish_reason_map.get(delta_data.get("finish_reason", ""), "stop")

            # Usage in final event
            usage = None
            usage_data = delta_data.get("usage", {})
            if usage_data:
                billed = usage_data.get("billed_units", {})
                tokens = usage_data.get("tokens", {})
                usage = Usage(
                    prompt_tokens=tokens.get("input_tokens", 0) or billed.get("input_tokens", 0),
                    completion_tokens=tokens.get("output_tokens", 0)
                    or billed.get("output_tokens", 0),
                    total_tokens=(tokens.get("input_tokens", 0) or 0)
                    + (tokens.get("output_tokens", 0) or 0),
                )

            return StreamChunk(
                id="",
                model=model,
                choices=[
                    ChunkChoice(
                        index=0,
                        delta=ChunkDelta(),
                        finish_reason=finish_reason,
                    )
                ],
                usage=usage,
            )

        return None

    def parse_error(
        self,
        status_code: int,
        data: bytes,
        request_id: str | None = None,
    ) -> ArcLLMError:
        """Parse Cohere error response."""
        try:
            error_data = orjson.loads(data)
            message = error_data.get("message", "Unknown error")
        except (orjson.JSONDecodeError, UnicodeDecodeError):
            message = data.decode("utf-8", errors="replace")

        common_kwargs: dict[str, Any] = {
            "provider": self.provider_name,
            "status_code": status_code,
            "request_id": request_id,
        }
        message_lower = (message or "").lower()

        if status_code == 401:
            return AuthenticationError(message, **common_kwargs)
        if status_code == 402:
            return BudgetExceededError(message, **common_kwargs)
        if status_code == 429:
            if any(token in message_lower for token in ("quota", "billing", "credit")):
                return BudgetExceededError(message, **common_kwargs)
            return RateLimitError(message, **common_kwargs)
        if status_code == 400:
            return InvalidRequestError(message, **common_kwargs)
        if status_code == 404:
            return UnsupportedModelError(message, **common_kwargs)
        if status_code == 503:
            return ServiceUnavailableError(message, **common_kwargs)
        if status_code >= 500:
            return InternalServerError(message, **common_kwargs)
        return ProviderAPIError(message, **common_kwargs)

    def build_embedding_request(
        self,
        *,
        model: str,
        input: list[str],
        **kwargs: Any,
    ) -> RequestData:
        """Build Cohere /v2/embed request.

        Cohere v2 returns embeddings keyed by dtype (``float``, ``int8`` …).
        We always request ``["float"]`` so callers get a uniform shape, and
        :meth:`parse_embedding_response` reads from ``embeddings.float``.
        """
        body: dict[str, Any] = {
            "model": model,
            "texts": input,
            "input_type": kwargs.get("input_type", "search_document"),
            "embedding_types": kwargs.get("embedding_types", ["float"]),
        }

        if "truncate" in kwargs:
            body["truncate"] = kwargs["truncate"]

        url = f"{self._api_base}/embed"
        body_bytes = orjson.dumps(body)

        return RequestData(
            method="POST",
            url=url,
            headers=self._get_headers(),
            body=body_bytes,
            timeout=self.config.timeout,
        )

    def parse_embedding_response(self, data: bytes, model: str) -> EmbeddingResponse:
        """Parse Cohere v2 ``/embed`` response.

        v2 returns ``{"embeddings": {"float": [[...], ...]}, "meta": {...}}``;
        we only request ``float`` (see :meth:`build_embedding_request`) so
        we always read from ``embeddings.float``. Falls back to v1's flat
        list if a custom ``api_base`` was pointed at the v1 endpoint.
        """
        try:
            resp = orjson.loads(data)
        except (orjson.JSONDecodeError, UnicodeDecodeError) as e:
            raise ResponseParseError(
                f"Failed to parse embedding response: {e}",
                provider=self.provider_name,
                raw_data=data,
            ) from e

        raw_embeddings = resp.get("embeddings")
        vectors: list[list[float]]
        if isinstance(raw_embeddings, dict):
            # v2 shape: {"float": [[...], ...], "int8": [[...], ...], ...}
            v2_dict = cast("dict[str, list[list[float]]]", raw_embeddings)
            vectors = v2_dict.get("float") or []
        elif isinstance(raw_embeddings, list):
            # v1 shape: list of vectors directly
            vectors = cast("list[list[float]]", raw_embeddings)
        else:
            vectors = []

        embeddings = [EmbeddingData(index=i, embedding=v) for i, v in enumerate(vectors)]

        meta = resp.get("meta", {})
        billed = meta.get("billed_units", {})

        return EmbeddingResponse(
            model=model,
            data=embeddings,
            usage=EmbeddingUsage(
                prompt_tokens=billed.get("input_tokens", 0),
                total_tokens=billed.get("input_tokens", 0),
            ),
        )

    # ------------------------------------------------------------------
    # Rerank surface
    # ------------------------------------------------------------------

    def build_rerank_request(
        self,
        *,
        model: str,
        query: str,
        documents: list[str],
        **kwargs: Any,
    ) -> RequestData:
        """Build a Cohere ``/v2/rerank`` request.

        Reference: https://docs.cohere.com/v2/reference/rerank
        """
        body: dict[str, Any] = {
            "model": model,
            "query": query,
            "documents": documents,
        }
        if "top_n" in kwargs and kwargs["top_n"] is not None:
            body["top_n"] = int(kwargs["top_n"])
        if "return_documents" in kwargs:
            body["return_documents"] = bool(kwargs["return_documents"])
        if "max_chunks_per_doc" in kwargs:
            body["max_chunks_per_doc"] = int(kwargs["max_chunks_per_doc"])

        # ``api_base`` already ends in ``/v2`` for the Cohere adapter; rerank
        # is exposed at the same /v2 root, so we just append ``/rerank``.
        url = f"{self._api_base.rstrip('/')}/rerank"
        return RequestData(
            method="POST",
            url=url,
            headers=self._get_headers(),
            body=orjson.dumps(body),
            timeout=self.config.timeout,
        )

    def parse_rerank_response(self, data: bytes, model: str) -> RerankResponse:
        """Parse Cohere rerank response into the unified arcllm shape."""
        try:
            resp = orjson.loads(data)
        except (orjson.JSONDecodeError, UnicodeDecodeError) as exc:
            raise ResponseParseError(
                f"Failed to parse rerank response: {exc}",
                provider=self.provider_name,
                raw_data=data,
            ) from exc

        results: list[RerankResult] = []
        raw_results = cast("list[Any]", resp.get("results") or [])
        for raw_item in raw_results:
            if not isinstance(raw_item, dict):
                continue
            item = cast("dict[str, Any]", raw_item)
            doc_field = item.get("document")
            doc_text: str | None = None
            if isinstance(doc_field, dict):
                doc_text = cast("dict[str, Any]", doc_field).get("text")
            elif isinstance(doc_field, str):
                doc_text = doc_field
            results.append(
                RerankResult(
                    index=int(item.get("index", 0)),
                    relevance_score=float(item.get("relevance_score", 0.0)),
                    document=doc_text,
                )
            )

        return RerankResponse(
            id=str(resp.get("id") or ""),
            model=model,
            results=results,
        )


# Register on import
register_provider("cohere", CohereAdapter)
