# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - 2026-04-08

### Added
- First public release of `sqlgraph`.
- `SQLAgent` with support for `train()`, `train_bulk()`, `train_from_file()`, `ask()`, `export_training()` and `import_training()`.
- LLM providers: `OpenAIProvider` and `GeminiProvider` with a common `BaseLLMProvider` interface.
- Session stores: `InMemorySessionStore` and `PostgresSessionStore`.
- RAG-based knowledge store via `pgvector` (`KnowledgeStore`, `SchemaRetriever`).
- SQL validation pipeline: syntactic validation via `sqlglot` + semantic validation via `EXPLAIN`.
- Automatic SQL correction loop (up to N configurable attempts).
- LangGraph multi-node pipeline (intent classifier → schema retriever → SQL generator → validator → corrector → formatter).
- CLI via `sqlgraph` command with subcommands: `train`, `ask`, `list`, `clear`, `export`, `import`.
- `CompositeProvider` for routing embedding and completion calls to different LLMs.
