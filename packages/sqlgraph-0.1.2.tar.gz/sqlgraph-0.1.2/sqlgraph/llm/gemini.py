"""Provider para modelos Gemini (Google)."""

from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings

from sqlgraph.exceptions import LLMError
from sqlgraph.llm.base import BaseLLMProvider
from sqlgraph.llm.openai import _to_langchain_messages


class GeminiProvider(BaseLLMProvider):
    """Provider para modelos do Google Gemini.

    Args:
        api_key: Chave de API do Google AI Studio.
        model: Modelo de linguagem (default: gemini-1.5-flash).
        embedding_model: Modelo de embeddings (default: text-embedding-004).
        temperature: Temperatura do modelo (default: 0).
    """

    EMBEDDING_DIMENSIONS = {
        "text-embedding-004": 768,
        "gemini-embedding-001": 768,
    }

    def __init__(
        self,
        api_key: str,
        model: str = "gemini-1.5-flash",
        embedding_model: str = "text-embedding-004",
        temperature: float = 0,
    ) -> None:
        self.api_key = api_key
        self.model = model
        self.embedding_model = embedding_model
        self.temperature = temperature

        self._llm = ChatGoogleGenerativeAI(
            google_api_key=api_key,
            model=model,
            temperature=temperature,
        )
        self._embeddings = GoogleGenerativeAIEmbeddings(
            google_api_key=api_key,
            model=embedding_model,
            output_dimensionality=768,
        )

    def complete(self, messages: list[dict], **kwargs) -> str:
        """Chama o modelo de completion do Gemini.

        Args:
            messages: Lista de mensagens no formato [{role, content}].
            **kwargs: Parâmetros extras não utilizados (mantém compatibilidade).

        Returns:
            Texto gerado pelo modelo.

        Raises:
            LLMError: Se a chamada à API falhar.
        """
        try:
            lc_messages = _to_langchain_messages(messages)
            result = self._llm.invoke(lc_messages)
            return result.content  # type: ignore[return-value]
        except Exception as exc:
            raise LLMError(f"Erro ao chamar Gemini completion: {exc}") from exc

    def embed(self, text: str) -> list[float]:
        """Gera embedding via Google Generative AI Embeddings.

        Args:
            text: Texto a ser transformado em vetor.

        Returns:
            Lista de floats com o embedding.

        Raises:
            LLMError: Se a chamada à API falhar.
        """
        try:
            return self._embeddings.embed_query(text)
        except Exception as exc:
            raise LLMError(f"Erro ao gerar embedding Gemini: {exc}") from exc

    @property
    def embedding_dimensions(self) -> int:
        """Retorna a dimensão do modelo de embedding configurado."""
        return self.EMBEDDING_DIMENSIONS.get(self.embedding_model, 768)
