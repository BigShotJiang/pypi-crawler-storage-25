"""Provider composto: usa providers distintos para completion e embedding."""

from sqlgraph.llm.base import BaseLLMProvider


class CompositeProvider(BaseLLMProvider):
    """Combina dois providers distintos para completion e embedding.

    Permite, por exemplo, usar Gemini para geração e OpenAI para embeddings.

    Args:
        completion: Provider responsável por complete().
        embedding: Provider responsável por embed().

    Exemplo:
        provider = CompositeProvider(
            completion=GeminiProvider(api_key="...", model="gemini-1.5-pro"),
            embedding=OpenAIProvider(api_key="...", embedding_model="text-embedding-3-small"),
        )
    """

    def __init__(
        self,
        completion: BaseLLMProvider,
        embedding: BaseLLMProvider,
    ) -> None:
        self._completion = completion
        self._embedding = embedding

    def complete(self, messages: list[dict], **kwargs) -> str:
        """Delega a chamada de completion para o provider de completion."""
        return self._completion.complete(messages, **kwargs)

    def embed(self, text: str) -> list[float]:
        """Delega a geração de embedding para o provider de embedding."""
        return self._embedding.embed(text)

    @property
    def embedding_dimensions(self) -> int:
        """Retorna a dimensão do provider de embedding configurado."""
        return self._embedding.embedding_dimensions
