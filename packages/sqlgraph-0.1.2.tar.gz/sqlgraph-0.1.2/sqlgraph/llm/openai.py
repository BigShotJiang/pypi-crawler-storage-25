"""Provider para modelos OpenAI (completion + embeddings)."""

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI, OpenAIEmbeddings

from sqlgraph.exceptions import LLMError
from sqlgraph.llm.base import BaseLLMProvider


class OpenAIProvider(BaseLLMProvider):
    """Provider para modelos da OpenAI.

    Args:
        api_key: Chave de API da OpenAI.
        model: Modelo de linguagem (default: gpt-4o-mini).
        embedding_model: Modelo de embeddings (default: text-embedding-3-small).
        temperature: Temperatura do modelo (default: 0).
    """

    EMBEDDING_DIMENSIONS = {
        "text-embedding-3-small": 1536,
        "text-embedding-3-large": 3072,
        "text-embedding-ada-002": 1536,
    }

    def __init__(
        self,
        api_key: str,
        model: str = "gpt-4o-mini",
        embedding_model: str = "text-embedding-3-small",
        temperature: float = 0,
    ) -> None:
        self.api_key = api_key
        self.model = model
        self.embedding_model = embedding_model
        self.temperature = temperature

        # Inicializa clientes LangChain com lazy import já resolvido
        self._llm = ChatOpenAI(
            api_key=api_key,
            model=model,
            temperature=temperature,
        )
        self._embeddings = OpenAIEmbeddings(
            api_key=api_key,
            model=embedding_model,
        )

    def complete(self, messages: list[dict], **kwargs) -> str:
        """Chama o modelo de completion da OpenAI.

        Args:
            messages: Lista de mensagens no formato [{role, content}].
            **kwargs: Parâmetros extras não utilizados (mantém compatibilidade).

        Returns:
            Texto gerado pelo modelo.

        Raises:
            LLMError: Se a chamada à API falhar.
        """
        try:
            lc_messages = _to_langchain_messages(messages)
            result = self._llm.invoke(lc_messages)
            return result.content  # type: ignore[return-value]
        except Exception as exc:
            raise LLMError(f"Erro ao chamar OpenAI completion: {exc}") from exc

    def embed(self, text: str) -> list[float]:
        """Gera embedding via OpenAI Embeddings API.

        Args:
            text: Texto a ser transformado em vetor.

        Returns:
            Lista de floats com o embedding.

        Raises:
            LLMError: Se a chamada à API falhar.
        """
        try:
            return self._embeddings.embed_query(text)
        except Exception as exc:
            raise LLMError(f"Erro ao gerar embedding OpenAI: {exc}") from exc

    @property
    def embedding_dimensions(self) -> int:
        """Retorna a dimensão do modelo de embedding configurado."""
        return self.EMBEDDING_DIMENSIONS.get(self.embedding_model, 1536)


def _to_langchain_messages(messages: list[dict]):
    """Converte dicts {role, content} para objetos de mensagem do LangChain."""
    result = []
    for msg in messages:
        role = msg.get("role", "user")
        content = msg.get("content", "")
        if role == "system":
            result.append(SystemMessage(content=content))
        elif role == "assistant":
            result.append(AIMessage(content=content))
        else:
            result.append(HumanMessage(content=content))
    return result
