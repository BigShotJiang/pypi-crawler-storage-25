"""Interface base para providers de LLM."""

from abc import ABC, abstractmethod


class BaseLLMProvider(ABC):
    """Interface que todo provider de LLM deve implementar.

    Separa explicitamente completion (geração de texto) de embedding,
    permitindo misturar providers via CompositeProvider.
    """

    @abstractmethod
    def complete(self, messages: list[dict], **kwargs) -> str:
        """Envia mensagens ao LLM e retorna o texto gerado.

        Args:
            messages: Lista de mensagens no formato [{role, content}].
            **kwargs: Parâmetros opcionais (temperatura, max_tokens, etc.).

        Returns:
            Texto gerado pelo LLM.
        """
        ...

    @abstractmethod
    def embed(self, text: str) -> list[float]:
        """Gera embedding vetorial de um texto.

        Args:
            text: Texto a ser transformado em vetor.

        Returns:
            Lista de floats representando o embedding.
        """
        ...

    @property
    @abstractmethod
    def embedding_dimensions(self) -> int:
        """Dimensão do vetor de embedding gerado por este provider."""
        ...
