"""Nós do grafo LangGraph — cada função é um nó do pipeline.

Usam closures (factory functions) para injetar dependências (LLM, DSN)
sem poluir o estado do LangGraph.
"""

import logging

import psycopg2
import sqlglot

from sqlgraph.graph.state import AgentState
from sqlgraph.knowledge.retriever import SchemaRetriever
from sqlgraph.llm.base import BaseLLMProvider

logger = logging.getLogger(__name__)


def make_intent_classifier(provider: BaseLLMProvider):
    """Instancia o nó de classificação de intenção."""

    def intent_classifier(state: AgentState) -> AgentState:
        prompt = [
            {
                "role": "system",
                "content": (
                    "Você é um classificador de intenção implacável.\n"
                    "Leia o input do usuário e classifique como EXATAMENTE UMA destas opções:\n"
                    "- 'sql': o usuário quer dados, métricas, coisas dependentes de banco\n"
                    "- 'chitchat': saudação, genéricas, agradecimentos\n"
                    "- 'ambiguous': frases incompletas, gírias indecifráveis\n\n"
                    "Responda APENAS com uma de (sql, chitchat, ambiguous)."
                ),
            },
            {"role": "user", "content": state["user_input"]},
        ]

        raw_response = provider.complete(prompt, temperature=0)
        intent = raw_response.strip().lower()

        # Fallback de segurança (caso o LLM alucine um pouco o formato)
        if "sql" in intent:
            intent = "sql"
        elif "chitchat" in intent:
            intent = "chitchat"
        else:
            intent = "ambiguous"

        return {**state, "intent": intent}

    return intent_classifier


def make_schema_retriever(retriever: SchemaRetriever):
    """Instancia o nó de recuperação de schema."""

    def schema_retriever(state: AgentState) -> AgentState:
        context = retriever.retrieve(state["user_input"])
        return {**state, "retrieved_schema": context}

    return schema_retriever


def make_sql_generator(provider: BaseLLMProvider):
    """Instancia o nó de geração de SQL."""

    def sql_generator(state: AgentState) -> AgentState:
        schema = state["retrieved_schema"]
        # History exclui o user_input atual para não duplicar, porem convertemos pro LLM
        history = state.get("messages", [])[:-1]

        system_rules = state.get("system_prompt")
        default_system = (
            "Você é um especialista em PostgreSQL.\n"
            "Use o contexto abaixo para gerar APENAS UMA QUERY SQL para a pergunta.\n"
            "Contexto do banco de dados:\n"
            f"{schema}\n\n"
            "Regras Inquebráveis:\n"
            "- NUNCA envolva o SQL com blocos markdown como ```sql\n"
            "- Retorne APENAS a string SQL limpa\n"
            "- Use aliases para tabelas, ex: SELECT t.id FROM tabela AS t\n"
            "- Não inclua ponto-e-vírgula (;) no final da query\n"
        )

        system_content = default_system
        if system_rules:
            system_content += f"\nRegras Específicas do Sistema:\n{system_rules}\n"

        prompt = [{"role": "system", "content": system_content}]

        # Injetando histórico no prompt do LLM
        for msg in history:
            role = "user" if msg.type == "human" else "assistant"
            prompt.append({"role": role, "content": msg.content})

        prompt.append({"role": "user", "content": state["user_input"]})

        raw_sql = provider.complete(prompt, temperature=0).strip()
        # Filtra formatação markdown vazada
        if raw_sql.startswith("```"):
            lines = raw_sql.split("\n")
            if len(lines) > 1:
                raw_sql = "\n".join(lines[1:])
            if raw_sql.endswith("```"):
                raw_sql = raw_sql[:-3]

        return {**state, "generated_sql": raw_sql.strip()}

    return sql_generator


def make_sql_validator(dsn: str, dialect: str = "postgres"):
    """Instancia o nó de validação de SQL, garantindo sintaxe e semântica."""

    def sql_validator(state: AgentState) -> AgentState:
        sql = state["generated_sql"]

        # 1. Validação Sintática (sqlglot fast pass)
        try:
            sqlglot.parse_one(sql, read=dialect)
        except sqlglot.errors.ParseError as e:
            return {
                **state,
                "validation_result": {"valid": False, "error": f"Erro de sintaxe SQL: {e}"},
            }

        # 2. Validação Semântica (psycopg2 EXPLAIN)
        try:
            with psycopg2.connect(dsn) as conn:
                with conn.cursor() as cur:
                    cur.execute(f"EXPLAIN {sql}")
        except psycopg2.Error as e:
            return {
                **state,
                "validation_result": {"valid": False, "error": f"Erro semântico no banco: {e}"},
            }

        # Tudo passou
        return {**state, "validation_result": {"valid": True, "error": None}}

    return sql_validator


def make_sql_corrector(provider: BaseLLMProvider, max_attempts: int = 2):
    """Instancia o nó de auto-correção de queries problemáticas."""

    def sql_corrector(state: AgentState) -> AgentState:
        attempts = state.get("correction_attempts", 0)

        if attempts >= max_attempts:
            return {
                **state,
                "generated_sql": "",
                "correction_attempts": attempts + 1,
                "validation_result": {"valid": True, "error": None},
                "final_response": (
                    "Infelizmente não consegui estruturar uma consulta válida para essa pergunta. "
                    "Poderia tentar formular de outra forma com mais detalhes?"
                ),
            }

        schema = state["retrieved_schema"]
        sql_errado = state["generated_sql"]
        erro_no_banco = state["validation_result"]["error"]

        prompt = [
            {
                "role": "system",
                "content": (
                    f"Você é um DBA consertando uma query PostgreSQL falha.\n"
                    f"Considere esse Schema disponível:\n{schema}\n\n"
                    f"Regra: Retorne APENAS O SQL CORRIGIDO direto."
                ),
            },
            {
                "role": "user",
                "content": (
                    f"A seguinte query falhou!\n"
                    f"Query Antiga: {sql_errado}\n"
                    f"Erro Recebido: {erro_no_banco}\n\n"
                    "Reescreva a query com a correção."
                ),
            },
        ]
        novo_sql = provider.complete(prompt, temperature=0).strip()
        sql_preview = novo_sql[:80] if novo_sql else "VAZIO"
        logger.debug("[corrector] attempts=%d sql=%r", attempts, sql_preview)

        if not novo_sql:
            return {**state, "validation_result": {"valid": True, "error": None}}
        if novo_sql.startswith("```"):
            lines = novo_sql.split("\n")
            novo_sql = "\n".join(lines[1:])
            if novo_sql.endswith("```"):
                novo_sql = novo_sql[:-3]

        return {**state, "generated_sql": novo_sql.strip(), "correction_attempts": attempts + 1}

    return sql_corrector


def make_chitchat_response(provider: BaseLLMProvider):
    """Instancia o nó de resposta para conversas aleatórias (chitchat)."""

    def chitchat_response(state: AgentState) -> AgentState:
        intent = state.get("intent", "ambiguous")
        if intent == "ambiguous":
            return {
                **state,
                "final_response": "Não consegui entender o que pediu. Pode detalhar melhor?",
            }

        prompt = [
            {
                "role": "system",
                "content": (
                    "Você é um assistente de banco de dados educado e conciso. "
                    "Responda a esta saudação ou pergunta geral de forma bem curta "
                    "orientando o usuário a perguntar sobre os dados."
                ),
            },
            {"role": "user", "content": state["user_input"]},
        ]
        response = provider.complete(prompt, temperature=0.7)
        return {**state, "final_response": response.strip()}

    return chitchat_response


def make_response_formatter(provider: BaseLLMProvider):
    """Instancia o nó responsável por dar o feedback do SQL executado."""

    def response_formatter(state: AgentState) -> AgentState:
        if not state.get("generated_sql"):
            return state

        sql = state["generated_sql"]
        prompt = [
            {
                "role": "system",
                "content": (
                    "Você explicará a query em UMA frase curta e amigável, "
                    "descrevendo filtros e agregações aplicados no relatório."
                ),
            },
            {"role": "user", "content": f"Explique o que esta query faz:\n{sql}"},
        ]

        explicacao = provider.complete(prompt, temperature=0.3)
        return {**state, "final_response": explicacao.strip()}

    return response_formatter
