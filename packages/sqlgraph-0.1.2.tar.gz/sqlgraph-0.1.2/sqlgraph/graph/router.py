"""Lógica de roteamento entre nós do grafo."""

from sqlgraph.graph.state import AgentState


def route_by_intent(state: AgentState) -> str:
    """Roteia pelo resultado da classificação de intenção.

    Returns:
        'sql' | 'chitchat' | 'ambiguous'
    """
    intent = state.get("intent", "ambiguous")
    if intent == "sql":
        return "sql"
    return "chitchat"


def route_by_validation(state: AgentState) -> str:
    """Roteia pelo resultado da validação do SQL.
    Para após 2 tentativas mesmo sem SQL válido.

    Returns:
        'valid' se o SQL passou ou se atingiu o limite de tentativas, 'invalid' caso contrário.
    """
    result = state.get("validation_result", {})
    attempts = state.get("correction_attempts", 0)

    if result.get("valid", False):
        return "valid"
    if attempts >= 2:
        return "valid"
    return "invalid"
