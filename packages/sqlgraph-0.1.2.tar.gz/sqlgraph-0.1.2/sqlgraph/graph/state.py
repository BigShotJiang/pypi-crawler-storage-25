"""Estado do grafo LangGraph — AgentState."""

from typing import Annotated

from langgraph.graph.message import add_messages
from typing_extensions import TypedDict


class AgentState(TypedDict):
    """Estado compartilhado entre os nós do grafo LangGraph.

    Cada nó lê e/ou escreve campos neste TypedDict.
    O campo `messages` usa add_messages para acumular o histórico.
    """

    messages: Annotated[list, add_messages]
    """Histórico completo da conversa (acumulado automaticamente)."""

    user_input: str
    """Input do usuário na rodada atual."""

    session_id: str
    """Identificador da sessão de conversa."""

    intent: str
    """Intenção classificada: 'sql' | 'chitchat' | 'ambiguous'."""

    retrieved_schema: str
    """Contexto recuperado do knowledge base (DDL + docs + exemplos)."""

    generated_sql: str
    """SQL gerado pelo sql_generator."""

    validation_result: dict
    """Resultado da validação: {'valid': bool, 'error': str | None}."""

    correction_attempts: int
    """Número de tentativas de correção automática do SQL."""

    final_response: str
    """Resposta final a ser retornada ao usuário."""

    system_prompt: str
    """System prompt customizado (opcional)."""
