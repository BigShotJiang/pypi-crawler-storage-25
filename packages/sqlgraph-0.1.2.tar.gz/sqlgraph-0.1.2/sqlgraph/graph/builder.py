"""Construção e compilação do grafo LangGraph."""

from langgraph.graph import END, StateGraph

from sqlgraph.graph.nodes import (
    make_chitchat_response,
    make_intent_classifier,
    make_response_formatter,
    make_schema_retriever,
    make_sql_corrector,
    make_sql_generator,
    make_sql_validator,
)
from sqlgraph.graph.router import route_by_intent, route_by_validation
from sqlgraph.graph.state import AgentState
from sqlgraph.knowledge.retriever import SchemaRetriever
from sqlgraph.llm.base import BaseLLMProvider


def build_graph(
    dsn: str,
    provider: BaseLLMProvider,
    dialect: str = "postgres",
    max_correction_attempts: int = 2,
):
    """Constrói e compila o grafo LangGraph do sqlgraph.

    Pipeline:
        intent_classifier
            ├── sql → schema_retriever → sql_generator → sql_validator
            │                                               ├── valid → response_formatter → END
            │                                               └── invalid → sql_corrector → (loop)
            └── chitchat/ambiguous → chitchat_response → END

    Returns:
        Grafo compilado pronto para invocar.
    """
    graph = StateGraph(AgentState)

    retriever = SchemaRetriever(dsn, provider)

    # Registra nós injetando as dependências
    graph.add_node("intent_classifier", make_intent_classifier(provider))
    graph.add_node("schema_retriever", make_schema_retriever(retriever))
    graph.add_node("sql_generator", make_sql_generator(provider))
    graph.add_node("sql_validator", make_sql_validator(dsn, dialect))
    graph.add_node("sql_corrector", make_sql_corrector(provider, max_correction_attempts))
    graph.add_node("chitchat_response", make_chitchat_response(provider))
    graph.add_node("response_formatter", make_response_formatter(provider))

    # Ponto de entrada
    graph.set_entry_point("intent_classifier")

    # Roteamento por intenção
    graph.add_conditional_edges(
        "intent_classifier",
        route_by_intent,
        {
            "sql": "schema_retriever",
            "chitchat": "chitchat_response",
        },
    )

    # Fluxo principal SQL
    graph.add_edge("schema_retriever", "sql_generator")
    graph.add_edge("sql_generator", "sql_validator")

    # Loop de correção
    graph.add_conditional_edges(
        "sql_validator",
        route_by_validation,
        {
            "valid": "response_formatter",
            "invalid": "sql_corrector",
        },
    )

    # sql_corrector → revalida após correção
    graph.add_edge("sql_corrector", "sql_validator")

    # Fins de fluxo
    graph.add_edge("response_formatter", END)
    graph.add_edge("chitchat_response", END)

    return graph.compile()
