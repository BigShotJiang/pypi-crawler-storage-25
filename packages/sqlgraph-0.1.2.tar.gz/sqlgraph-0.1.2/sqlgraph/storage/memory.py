"""Session store em memória (padrão do SQLAgent)."""

from sqlgraph.storage.base import BaseSessionStore


class InMemorySessionStore(BaseSessionStore):
    """Armazena histórico de sessões em memória (não persistente).

    Adequado para desenvolvimento e uso single-process.
    Para produção com múltiplos workers, use PostgresSessionStore.
    """

    def __init__(self) -> None:
        self._store: dict[str, list[dict]] = {}

    def get(self, session_id: str) -> list[dict]:
        """Recupera o histórico da sessão ou lista vazia se não existir."""
        return self._store.get(session_id, [])

    def save(self, session_id: str, messages: list[dict]) -> None:
        """Persiste o histórico da sessão em memória."""
        self._store[session_id] = messages

    def delete(self, session_id: str) -> None:
        """Remove a sessão do store em memória."""
        self._store.pop(session_id, None)
