"""Interface base para session stores."""

from abc import ABC, abstractmethod


class BaseSessionStore(ABC):
    """Interface para armazenamento de histórico de sessões.

    Implementações concretas: InMemorySessionStore, PostgresSessionStore.
    """

    @abstractmethod
    def get(self, session_id: str) -> list[dict]:
        """Recupera o histórico de mensagens de uma sessão.

        Args:
            session_id: Identificador único da sessão.

        Returns:
            Lista de mensagens no formato [{role, content}].
        """
        ...

    @abstractmethod
    def save(self, session_id: str, messages: list[dict]) -> None:
        """Persiste o histórico de mensagens de uma sessão.

        Args:
            session_id: Identificador único da sessão.
            messages: Lista completa de mensagens a persistir.
        """
        ...

    @abstractmethod
    def delete(self, session_id: str) -> None:
        """Remove uma sessão e seu histórico.

        Args:
            session_id: Identificador único da sessão.
        """
        ...
