"""Session store persistente via PostgreSQL."""

from sqlgraph.storage.base import BaseSessionStore


class PostgresSessionStore(BaseSessionStore):
    """Armazena histórico de sessões no PostgreSQL.

    Adequado para produção com múltiplos workers.
    Usa a tabela sqlgraph_sessions criada pela migration 001_initial.sql.

    Args:
        dsn: Connection string do PostgreSQL.
    """

    def __init__(self, dsn: str) -> None:
        self.dsn = dsn
        # TODO: inicializar pool de conexões psycopg2

    def get(self, session_id: str) -> list[dict]:
        """Recupera o histórico da sessão do PostgreSQL."""
        # TODO: SELECT messages FROM sqlgraph_sessions WHERE session_id = %s
        raise NotImplementedError

    def save(self, session_id: str, messages: list[dict]) -> None:
        """Upsert do histórico da sessão no PostgreSQL."""
        # TODO: INSERT ... ON CONFLICT (session_id) DO UPDATE SET messages = %s
        raise NotImplementedError

    def delete(self, session_id: str) -> None:
        """Remove a sessão do PostgreSQL."""
        # TODO: DELETE FROM sqlgraph_sessions WHERE session_id = %s
        raise NotImplementedError
