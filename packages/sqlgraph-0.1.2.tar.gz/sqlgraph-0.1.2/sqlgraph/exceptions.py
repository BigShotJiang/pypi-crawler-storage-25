"""Exceções customizadas do sqlgraph."""


class SQLGraphError(Exception):
    """Erro base do sqlgraph."""


class LLMError(SQLGraphError):
    """Erro ao chamar o LLM (completion ou embedding)."""


class ValidationError(SQLGraphError):
    """SQL gerado falhou na validação sintática ou semântica."""


class TrainingError(SQLGraphError):
    """Erro ao armazenar ou recuperar dados de training."""


class SessionError(SQLGraphError):
    """Erro ao gerenciar sessões de conversa."""


class ConfigurationError(SQLGraphError):
    """Configuração inválida do SQLAgent."""
