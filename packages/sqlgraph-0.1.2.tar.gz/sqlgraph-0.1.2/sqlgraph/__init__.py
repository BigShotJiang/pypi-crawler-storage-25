"""
sqlgraph — Geração de SQL com linguagem natural usando LangGraph + pgvector.

Uso básico:
    from sqlgraph import SQLAgent
    from sqlgraph.llm import OpenAIProvider

    agent = SQLAgent(dsn="postgresql://...", llm=OpenAIProvider(api_key="..."))
    response = agent.ask("Qual o total pago em 2023?")
    print(response.sql)
"""

from sqlgraph.agent import SQLAgent
from sqlgraph.models import Response, TrainingItem

__all__ = ["SQLAgent", "Response", "TrainingItem"]
__version__ = "0.1.0"
