"""SQLAgent — API pública principal do sqlgraph."""

import json
import uuid

import psycopg2
from langchain_core.messages import AIMessage, HumanMessage

from sqlgraph.exceptions import ConfigurationError
from sqlgraph.graph.builder import build_graph
from sqlgraph.knowledge.store import KnowledgeStore
from sqlgraph.llm.base import BaseLLMProvider
from sqlgraph.models import Response, TrainingItem
from sqlgraph.storage.base import BaseSessionStore
from sqlgraph.storage.memory import InMemorySessionStore


class SQLAgent:
    """Agente de geração de SQL com linguagem natural.

    Combina LangGraph + pgvector para oferecer geração de SQL com:
    - Training via DDL, documentação e exemplos de queries
    - Validação automática (sqlglot + EXPLAIN)
    - Loop de correção em caso de SQL inválido
    - Multi-turn real via session_id

    Args:
        dsn: Connection string do PostgreSQL.
        llm: Provider de LLM (OpenAIProvider, GeminiProvider ou customizado).
        session_store: Store de sessões (default: InMemorySessionStore).
        max_correction_attempts: Tentativas de correção automática (default: 2).
        validate_sql: Se True, valida o SQL antes de retornar (default: True).
        retrieval_limit: Chunks recuperados do knowledge base por query (default: 10).
        system_prompt: System prompt customizado (opcional).
        dialect: Dialeto SQL (default: 'postgres').

    Exemplo:
        agent = SQLAgent(
            dsn="postgresql://user:pass@localhost/db",
            llm=OpenAIProvider(api_key="sk-..."),
        )
        agent.train(ddl="CREATE TABLE pagamentos (...)")
        response = agent.ask("Qual o total pago em 2023?")
        print(response.sql)
    """

    def __init__(
        self,
        dsn: str,
        llm: BaseLLMProvider,
        session_store: BaseSessionStore | None = None,
        max_correction_attempts: int = 2,
        validate_sql: bool = True,
        retrieval_limit: int = 10,
        system_prompt: str | None = None,
        dialect: str = "postgres",
    ) -> None:
        if not dsn:
            raise ConfigurationError("dsn não pode ser vazio")
        if llm is None:
            raise ConfigurationError("llm é obrigatório")

        self.dsn = dsn
        self.llm = llm
        self.session_store = session_store or InMemorySessionStore()
        self.max_correction_attempts = max_correction_attempts
        self.validate_sql = validate_sql
        self.retrieval_limit = retrieval_limit
        self.system_prompt = system_prompt
        self.dialect = dialect

        self.knowledge = KnowledgeStore(dsn, llm)
        self.graph = build_graph(dsn, llm, dialect, max_correction_attempts)

    # -------------------------------------------------------------------------
    # Training
    # -------------------------------------------------------------------------

    def train(
        self,
        ddl: str | None = None,
        documentation: str | None = None,
        question: str | None = None,
        sql: str | None = None,
        metadata: dict | None = None,
    ) -> None:
        """Adiciona dados ao knowledge base.

        Aceita DDL, documentação de negócio ou par pergunta+SQL.

        Args:
            ddl: Definição de tabela (CREATE TABLE ...).
            documentation: Regras de negócio, sinônimos, contexto.
            question: Pergunta em linguagem natural (requer sql).
            sql: SQL correspondente (requer question).
            metadata: Metadados opcionais.
        """
        self.knowledge.train(ddl, documentation, question, sql, metadata)

    def train_bulk(self, items: list[dict]) -> None:
        """Adiciona múltiplos itens ao knowledge base de uma vez.

        Args:
            items: Lista de dicts, cada um com ddl, documentation ou question+sql.
        """
        for item in items:
            self.train(**item)

    def train_from_file(self, path: str) -> None:
        """Adiciona DDL de um arquivo .sql ao knowledge base.

        Args:
            path: Caminho para o arquivo .sql.
        """
        import re

        with open(path, encoding="utf-8") as f:
            content = f.read()

        pattern = r";(?=(?:[^\']*\'[^\']*\')*[^\']*$)"
        statements = [s.strip() for s in re.split(pattern, content) if s.strip()]
        for stmt in statements:
            if stmt.lower().startswith("create"):
                self.train(ddl=stmt)

    def list_training(self) -> list[TrainingItem]:
        """Lista todos os itens do knowledge base."""
        return self.knowledge.list_training()

    def remove_training(self, item_id: str) -> None:
        """Remove um item do knowledge base pelo UUID."""
        self.knowledge.remove_training(item_id)

    def clear_training(self) -> None:
        """Remove todos os itens do knowledge base."""
        self.knowledge.clear_training()

    def export_training(self, path: str) -> None:
        """Exporta o knowledge base para um arquivo JSON."""
        items = self.list_training()
        data = [{"type": i.type, "content": i.content} for i in items]
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def import_training(self, path: str) -> None:
        """Importa um knowledge base a partir de um arquivo JSON."""
        with open(path, encoding="utf-8") as f:
            data = json.load(f)

        for item in data:
            if item["type"] == "ddl":
                self.train(ddl=item["content"])
            elif item["type"] == "doc":
                self.train(documentation=item["content"])
            elif item["type"] == "query_example":
                # Divide question e sql embutidos
                parts = item["content"].split("\nSQL: ", 1)
                if len(parts) == 2:
                    q = parts[0].replace("Pergunta: ", "")
                    # query
                    self.train(question=q, sql=parts[1])
                else:
                    self.train(documentation=item["content"])

    # -------------------------------------------------------------------------
    # Consulta
    # -------------------------------------------------------------------------

    def ask(
        self,
        question: str,
        session_id: str | None = None,
        execute: bool = False,
        max_rows: int = 100,
        explain: bool = False,
    ) -> Response:
        """Responde a uma pergunta em linguagem natural com SQL.

        Args:
            question: Pergunta em linguagem natural.
            session_id: Identificador de sessão para multi-turn.
            execute: Se True, executa o SQL e retorna os dados.
            max_rows: Limite de linhas se execute=True.
            explain: Se True, inclui EXPLAIN ANALYZE no response.

        Returns:
            Response com sql, explanation, intent, valid e attempts.
        """
        session_id = session_id or str(uuid.uuid4())
        session_msgs = self.session_store.get(session_id)

        state = {
            "user_input": question,
            "messages": session_msgs,
            "session_id": session_id,
            "system_prompt": self.system_prompt,
            "retrieved_schema": "",
            "generated_sql": "",
            "intent": "",
            "validation_result": {},
            "correction_attempts": 0,
            "final_response": "",
        }

        # Invoca o LangGraph
        new_state = self.graph.invoke(state, config={"recursion_limit": 10})
        sql = new_state.get("generated_sql")
        intent = new_state.get("intent")
        explanation = new_state.get("final_response")
        valid = new_state.get("validation_result", {}).get("valid", False)
        attempts = new_state.get("correction_attempts", 0)

        # Salva o historico no session_store
        session_msgs.append(HumanMessage(content=question))
        session_msgs.append(AIMessage(content=explanation or "Aqui está a query."))
        self.session_store.save(session_id, session_msgs)

        data = None
        if execute and sql and valid and intent == "sql":
            try:
                with psycopg2.connect(self.dsn) as conn:
                    with conn.cursor() as cur:
                        aggr_sql = f"SELECT * FROM ({sql}) AS sub LIMIT {max_rows}"
                        cur.execute(aggr_sql)
                        cols = [desc[0] for desc in cur.description]
                        data = [dict(zip(cols, row)) for row in cur.fetchall()]
            except Exception as e:
                data = [{"error": str(e)}]

        if explain and sql and valid and intent == "sql":
            try:
                with psycopg2.connect(self.dsn) as conn:
                    with conn.cursor() as cur:
                        cur.execute(f"EXPLAIN ANALYZE {sql}")
                        explain_output = "\n".join([r[0] for r in cur.fetchall()])
                        explanation = f"{explanation}\n\nEXPLAIN:\n{explain_output}"
            except Exception:
                pass

        return Response(
            sql=sql,
            explanation=explanation,
            intent=intent,
            valid=valid,
            attempts=attempts,
            data=data,
        )
