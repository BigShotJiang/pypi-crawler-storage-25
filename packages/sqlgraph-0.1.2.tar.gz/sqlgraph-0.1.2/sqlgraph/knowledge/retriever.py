"""Retriever de schema — busca contexto relevante no knowledge base."""

import psycopg2

from sqlgraph.exceptions import TrainingError
from sqlgraph.llm.base import BaseLLMProvider


class SchemaRetriever:
    """Recupera DDL, documentação e exemplos similares do knowledge base.

    Usa similaridade de cosseno via pgvector para encontrar
    os chunks mais relevantes para a pergunta do usuário.

    Args:
        dsn: Connection string do PostgreSQL.
        provider: Provider de LLM para geração de embeddings.
        limit: Número máximo de chunks a recuperar por query.
    """

    def __init__(self, dsn: str, provider: BaseLLMProvider, limit: int = 10) -> None:
        self.dsn = dsn
        self.provider = provider
        self.limit = limit

    def retrieve(self, query: str) -> str:
        """Recupera contexto relevante para a query do usuário.

        Busca os chunks mais similares e os organiza em seções
        separadas por tipo (DDL, documentação, exemplos).

        Args:
            query: Pergunta do usuário em linguagem natural.

        Returns:
            String formatada com o contexto para o prompt SQL.
        """
        try:
            query_embedding = self.provider.embed(query)
        except Exception as exc:
            raise TrainingError(f"Falha ao gerar embedding da query: {exc}") from exc

        try:
            with psycopg2.connect(self.dsn) as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        """
                        SELECT type, content
                        FROM sqlgraph_knowledge
                        ORDER BY embedding <=> %s::vector
                        LIMIT %s;
                        """,
                        (query_embedding, self.limit),
                    )
                    rows = cur.fetchall()
        except psycopg2.Error as exc:
            raise TrainingError(f"Erro ao recuperar contexto do PostgreSQL: {exc}") from exc

        ddls = [r[1] for r in rows if r[0] == "ddl"]
        docs = [r[1] for r in rows if r[0] == "doc"]
        examples = [r[1] for r in rows if r[0] == "query_example"]

        return self._format_context(ddls, docs, examples)

    def _format_context(
        self,
        ddls: list[str],
        docs: list[str],
        examples: list[str],
    ) -> str:
        """Formata o contexto recuperado para o prompt SQL.

        Garante que seções vazias não apareçam.
        """
        sections = []
        if ddls:
            sections.append("## DDL Relevante\n" + "\n".join(ddls))
        if docs:
            sections.append("## Documentação de Negócio\n" + "\n".join(docs))
        if examples:
            sections.append("## Exemplos de Queries Similares\n" + "\n".join(examples))

        return "\n\n".join(sections)
