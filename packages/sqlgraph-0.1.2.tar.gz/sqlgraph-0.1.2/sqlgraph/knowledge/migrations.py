"""Runner de migrations SQL do sqlgraph.

Aplica automaticamente os arquivos .sql da pasta migrations/
na ordem numérica, ao inicializar o KnowledgeStore.
"""

from pathlib import Path

import psycopg2

# Diretório onde ficam os arquivos .sql de migration
MIGRATIONS_DIR = Path(__file__).parent / "migrations"


def run_migrations(dsn: str, embedding_dimensions: int) -> None:
    """Aplica as migrations pendentes e ajusta a dimensão do vetor.

    Executado automaticamente pelo KnowledgeStore no __init__.
    Idempotente — pode ser chamado múltiplas vezes sem side-effects.

    Args:
        dsn: Connection string do PostgreSQL.
        embedding_dimensions: Dimensão do vetor conforme o provider configurado.
    """
    with psycopg2.connect(dsn) as conn:
        conn.autocommit = True
        with conn.cursor() as cur:
            # Aplica cada arquivo .sql em ordem numérica
            sql_files = sorted(MIGRATIONS_DIR.glob("*.sql"))
            for sql_file in sql_files:
                sql = sql_file.read_text(encoding="utf-8")
                cur.execute(sql)

            # Ajusta a dimensão do vetor de embedding dinamicamente.
            # Se a coluna já tiver a dimensão correta, o ALTER TABLE é no-op.
            # Caso contrário, recria a coluna com a dimensão do provider atual.
            cur.execute(
                """
                SELECT atttypmod
                FROM pg_attribute
                WHERE attrelid = 'sqlgraph_knowledge'::regclass
                  AND attname = 'embedding'
                """,
            )
            row = cur.fetchone()
            # atttypmod para vector(N) é N; -1 significa sem dimensão definida
            current_dims = row[0] if row else -1

            if current_dims != embedding_dimensions:
                # Recria a coluna com a dimensão correta e recria o índice
                cur.execute(
                    f"""
                    ALTER TABLE sqlgraph_knowledge
                    DROP COLUMN IF EXISTS embedding;

                    ALTER TABLE sqlgraph_knowledge
                    ADD COLUMN embedding vector({embedding_dimensions});

                    DROP INDEX IF EXISTS sqlgraph_knowledge_embedding_idx;

                    CREATE INDEX sqlgraph_knowledge_embedding_idx
                        ON sqlgraph_knowledge
                        USING ivfflat (embedding vector_cosine_ops)
                        WITH (lists = 100);
                    """
                )
