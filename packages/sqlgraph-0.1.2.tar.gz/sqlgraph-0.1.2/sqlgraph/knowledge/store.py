"""Knowledge store — armazena e recupera dados de training no PostgreSQL."""

import json

import psycopg2

from sqlgraph.exceptions import TrainingError
from sqlgraph.knowledge.migrations import run_migrations
from sqlgraph.llm.base import BaseLLMProvider
from sqlgraph.models import TrainingItem


class KnowledgeStore:
    """Gerencia o knowledge base do sqlgraph no PostgreSQL.

    Responsável por armazenar e recuperar DDL, documentação
    e exemplos de queries via embeddings vetoriais.

    Args:
        dsn: Connection string do PostgreSQL.
        provider: Provider de LLM para geração de embeddings.
    """

    def __init__(self, dsn: str, provider: BaseLLMProvider) -> None:
        self.dsn = dsn
        self.provider = provider
        # Executa migrations e ajusta dimensão dinamicamente
        try:
            run_migrations(dsn, provider.embedding_dimensions)
        except Exception as exc:
            raise TrainingError(f"Falha ao inicializar migrations do banco: {exc}") from exc

    def train(
        self,
        ddl: str | None = None,
        documentation: str | None = None,
        question: str | None = None,
        sql: str | None = None,
        metadata: dict | None = None,
    ) -> None:
        """Armazena um item no knowledge base.

        Equivalente ao vanna.train(). Aceita DDL, documentação
        ou um par pergunta+SQL.

        Args:
            ddl: Definição DDL de uma tabela.
            documentation: Documentação de negócio, sinônimos, regras.
            question: Pergunta em linguagem natural (requer sql).
            sql: SQL correspondente à pergunta (requer question).
            metadata: Metadados opcionais (ex: {'source': 'manual'}).
        """
        if ddl:
            self._store_knowledge("ddl", ddl, metadata)

        if documentation:
            self._store_knowledge("doc", documentation, metadata)

        if question and sql:
            # Junta pergunta e query no mesmo bloco de texto para o payload no banco
            content = f"Pergunta: {question}\nSQL: {sql}"
            self._store_knowledge("query_example", content, metadata, embed_text=question)

        if not any([ddl, documentation, (question and sql)]):
            raise ValueError("Forneça 'ddl', 'documentation' ou um par 'question' + 'sql'.")

    def _store_knowledge(
        self,
        type_: str,
        content: str,
        metadata: dict | None = None,
        embed_text: str | None = None,
    ) -> str:
        """Gera embedding e persiste o item no banco.

        Returns:
            UUID do item criado.
        """
        try:
            # Se embed_text ornecido, usa ele para o vetor geométrico; senão usa o content.
            target_text = embed_text if embed_text is not None else content
            embedding = self.provider.embed(target_text)
        except Exception as exc:
            raise TrainingError(f"Falha ao gerar embedding: {exc}") from exc

        meta = json.dumps(metadata or {})

        try:
            with psycopg2.connect(self.dsn) as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        """
                        INSERT INTO sqlgraph_knowledge (type, content, metadata, embedding)
                        VALUES (%s, %s, %s, %s)
                        RETURNING id;
                        """,
                        (type_, content, meta, embedding),
                    )
                    row = cur.fetchone()
                    if row is None:
                        raise TrainingError("INSERT não retornou ID gerado.")
                    return str(row[0])
        except psycopg2.Error as exc:
            raise TrainingError(f"Erro ao salvar dado de training no PostgreSQL: {exc}") from exc

    def list_training(self) -> list[TrainingItem]:
        """Lista todos os itens do knowledge base.

        Returns:
            Lista de itens de treinamento.
        """
        try:
            with psycopg2.connect(self.dsn) as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        """
                        SELECT id, type, content, created_at
                        FROM sqlgraph_knowledge
                        ORDER BY created_at DESC;
                        """
                    )
                    rows = cur.fetchall()
                    return [
                        TrainingItem(
                            id=str(r[0]),
                            type=r[1],
                            content=r[2],
                            created_at=(
                                r[3].isoformat() if hasattr(r[3], "isoformat") else str(r[3])
                            ),
                        )
                        for r in rows
                    ]
        except psycopg2.Error as exc:
            raise TrainingError(f"Erro ao listar dados de training: {exc}") from exc

    def remove_training(self, item_id: str) -> None:
        """Remove um item específico do knowledge base pelo UUID."""
        try:
            with psycopg2.connect(self.dsn) as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "DELETE FROM sqlgraph_knowledge WHERE id = %s;",
                        (item_id,),
                    )
        except psycopg2.Error as exc:
            raise TrainingError(f"Erro ao remover dado de training: {exc}") from exc

    def clear_training(self) -> None:
        """Remove todos os itens do knowledge base."""
        try:
            with psycopg2.connect(self.dsn) as conn:
                with conn.cursor() as cur:
                    cur.execute("TRUNCATE TABLE sqlgraph_knowledge;")
        except psycopg2.Error as exc:
            raise TrainingError(f"Erro ao limpar knowledge base: {exc}") from exc
