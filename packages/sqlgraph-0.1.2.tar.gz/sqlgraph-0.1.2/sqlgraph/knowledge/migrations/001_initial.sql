-- Migration inicial: cria tabelas necessárias para o sqlgraph
-- Executada automaticamente pelo SQLAgent na primeira inicialização

-- Habilita a extensão pgvector (necessária para embeddings)
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Knowledge base: armazena DDL, documentação e exemplos de queries treinados
-- NOTA: a coluna `embedding` não tem dimensão fixa aqui.
-- A dimensão correta é adicionada via ALTER TABLE pelo runner de migration,
-- baseada em provider.embedding_dimensions (1536 OpenAI / 768 Gemini).
CREATE TABLE IF NOT EXISTS sqlgraph_knowledge (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    type        TEXT NOT NULL CHECK (type IN ('ddl', 'doc', 'query_example')),
    content     TEXT NOT NULL,
    metadata    JSONB NOT NULL DEFAULT '{}',
    embedding   vector,  -- dimensão definida dinamicamente pelo provider
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Índice para filtrar por tipo (ddl / doc / query_example)
CREATE INDEX IF NOT EXISTS sqlgraph_knowledge_type_idx
    ON sqlgraph_knowledge (type);

-- Sessões de conversa (usadas pelo PostgresSessionStore)
CREATE TABLE IF NOT EXISTS sqlgraph_sessions (
    session_id  TEXT PRIMARY KEY,
    messages    JSONB NOT NULL DEFAULT '[]',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Função para atualizar o updated_at automaticamente
CREATE OR REPLACE FUNCTION sqlgraph_update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER sqlgraph_sessions_updated_at
    BEFORE UPDATE ON sqlgraph_sessions
    FOR EACH ROW EXECUTE FUNCTION sqlgraph_update_updated_at();
