"""Modelos de dados públicos do sqlgraph."""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Response:
    """Resposta retornada pelo SQLAgent.ask()."""

    sql: str = ""
    """SQL gerado (vazio se a intenção não for SQL)."""

    explanation: str = ""
    """Explicação em linguagem natural do SQL gerado."""

    intent: str = ""
    """Intenção classificada: 'sql' | 'chitchat' | 'ambiguous'."""

    valid: bool = False
    """True se o SQL passou na validação sintática e semântica."""

    attempts: int = 0
    """Número de tentativas de geração/correção até chegar no SQL final."""

    data: list[dict[str, Any]] = field(default_factory=list)
    """Linhas retornadas se execute=True foi passado para ask()."""

    row_count: int = 0
    """Quantidade de linhas retornadas (apenas quando execute=True)."""

    error: str | None = None
    """Mensagem de erro caso o SQL não tenha sido gerado com sucesso."""


@dataclass
class TrainingItem:
    """Representa um item armazenado no knowledge base."""

    id: str = ""
    """UUID do item."""

    type: str = ""
    """Tipo: 'ddl' | 'doc' | 'query_example'."""

    content: str = ""
    """Conteúdo textual do item."""

    created_at: str = ""
    """Timestamp de criação (ISO 8601)."""


@dataclass
class ValidationResult:
    """Resultado da validação de um SQL gerado."""

    valid: bool = False
    """True se sintaxe e semântica estão corretas."""

    error: str | None = None
    """Descrição do erro caso valid=False."""
