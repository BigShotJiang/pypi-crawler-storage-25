"""CLI do sqlgraph — training, consulta e gestão do knowledge base.

Usage:
    sqlgraph train --dsn postgresql://... --file schema.sql
    sqlgraph ask   --dsn postgresql://... "Qual o total pago em 2023?"
    sqlgraph list  --dsn postgresql://...
    sqlgraph clear --dsn postgresql://...
    sqlgraph export --dsn postgresql://... --output backup.json
    sqlgraph import --dsn postgresql://... --input backup.json

Requires: pip install sqlgraph[cli]
"""

from __future__ import annotations

import json
import os
import sys

try:
    from typing import Annotated

    import typer
except ImportError:
    print(
        "error: sqlgraph[cli] is not installed.\n  pip install sqlgraph[cli]",
        file=sys.stderr,
    )
    sys.exit(1)

app = typer.Typer(
    name="sqlgraph",
    help="Natural language to SQL via LangGraph + pgvector.",
    add_completion=False,
    pretty_exceptions_show_locals=False,
)

DSN_OPTION = Annotated[
    str,
    typer.Option("--dsn", envvar="SQLGRAPH_DSN", help="PostgreSQL connection string."),
]

PROVIDER_OPTION = Annotated[
    str,
    typer.Option("--provider", envvar="SQLGRAPH_PROVIDER", help="LLM provider: openai or gemini."),
]

API_KEY_OPTION = Annotated[
    str | None,
    typer.Option("--api-key", envvar="SQLGRAPH_API_KEY", help="LLM provider API key."),
]


def _build_agent(dsn: str, provider: str = "openai", api_key: str | None = None):
    from sqlgraph.agent import SQLAgent
    from sqlgraph.llm.gemini import GeminiProvider
    from sqlgraph.llm.openai import OpenAIProvider

    if provider == "gemini":
        key = api_key or os.getenv("GOOGLE_API_KEY") or ""
        if not key:
            typer.echo("error: GOOGLE_API_KEY not set. Use --api-key or set the env var.", err=True)
            raise typer.Exit(1)
        llm = GeminiProvider(api_key=key)
    else:
        key = api_key or os.getenv("OPENAI_API_KEY") or ""
        if not key:
            typer.echo("error: OPENAI_API_KEY not set. Use --api-key or set the env var.", err=True)
            raise typer.Exit(1)
        llm = OpenAIProvider(api_key=key)

    return SQLAgent(dsn=dsn, llm=llm)


@app.command("train")
def cmd_train(
    dsn: DSN_OPTION = "",
    provider: PROVIDER_OPTION = "openai",
    api_key: API_KEY_OPTION = None,
    file: Annotated[
        str | None,
        typer.Option("--file", "-f", help=".sql file with DDL statements."),
    ] = None,
    ddl: Annotated[
        str | None,
        typer.Option("--ddl", help="Inline DDL (CREATE TABLE ...)."),
    ] = None,
    doc: Annotated[
        str | None,
        typer.Option("--doc", "-d", help="Business rule or documentation text."),
    ] = None,
    question: Annotated[
        str | None,
        typer.Option("--question", "-q", help="Natural language question (requires --sql)."),
    ] = None,
    sql: Annotated[
        str | None,
        typer.Option("--sql", "-s", help="SQL for the given question (requires --question)."),
    ] = None,
):
    """Add data to the knowledge base (DDL, documentation, or question/SQL pairs)."""
    if not dsn:
        typer.echo("error: --dsn is required (or set SQLGRAPH_DSN).", err=True)
        raise typer.Exit(1)

    agent = _build_agent(dsn, provider, api_key)

    if file:
        agent.train_from_file(file)
        typer.echo(f"trained: {file}")
    elif ddl:
        agent.train(ddl=ddl)
        typer.echo("trained: ddl")
    elif doc:
        agent.train(documentation=doc)
        typer.echo("trained: doc")
    elif question and sql:
        agent.train(question=question, sql=sql)
        typer.echo("trained: question/sql pair")
    else:
        typer.echo(
            "error: provide one of --file, --ddl, --doc, or --question + --sql.",
            err=True,
        )
        raise typer.Exit(1)


@app.command("ask")
def cmd_ask(
    question: Annotated[str, typer.Argument(help="Question in natural language.")],
    dsn: DSN_OPTION = "",
    provider: PROVIDER_OPTION = "openai",
    api_key: API_KEY_OPTION = None,
    execute: Annotated[
        bool,
        typer.Option("--execute/--no-execute", help="Execute the generated SQL and return rows."),
    ] = False,
    max_rows: Annotated[
        int,
        typer.Option("--max-rows", help="Row limit when --execute is set."),
    ] = 100,
    session_id: Annotated[
        str | None,
        typer.Option("--session-id", help="Session ID for multi-turn conversations."),
    ] = None,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Output as JSON."),
    ] = False,
):
    """Ask a question in natural language and get the generated SQL."""
    if not dsn:
        typer.echo("error: --dsn is required (or set SQLGRAPH_DSN).", err=True)
        raise typer.Exit(1)

    agent = _build_agent(dsn, provider, api_key)
    response = agent.ask(question, session_id=session_id, execute=execute, max_rows=max_rows)

    if json_output:
        import dataclasses

        typer.echo(json.dumps(dataclasses.asdict(response), indent=2, default=str))
        return

    typer.echo(f"intent: {response.intent}  attempts: {response.attempts}  valid: {response.valid}")

    if response.sql:
        typer.echo(f"\n{response.sql}\n")

    if response.explanation:
        typer.echo(response.explanation)

    if execute and response.data:
        typer.echo(f"\n{len(response.data)} row(s):")
        for row in response.data:
            typer.echo(f"  {row}")

    if not response.valid and response.error:
        typer.echo(f"error: {response.error}", err=True)


@app.command("list")
def cmd_list(
    dsn: DSN_OPTION = "",
    provider: PROVIDER_OPTION = "openai",
    api_key: API_KEY_OPTION = None,
    kind: Annotated[
        str | None,
        typer.Option("--type", "-t", help="Filter by type: ddl, doc, or query_example."),
    ] = None,
):
    """List all items in the knowledge base."""
    if not dsn:
        typer.echo("error: --dsn is required (or set SQLGRAPH_DSN).", err=True)
        raise typer.Exit(1)

    agent = _build_agent(dsn, provider, api_key)
    items = agent.list_training()

    if kind:
        items = [i for i in items if i.type == kind]

    if not items:
        typer.echo("knowledge base is empty.")
        return

    for item in items:
        preview = item.content[:80].replace("\n", " ")
        typer.echo(f"[{item.type}] {item.id[:8]}  {preview}")


@app.command("clear")
def cmd_clear(
    dsn: DSN_OPTION = "",
    provider: PROVIDER_OPTION = "openai",
    api_key: API_KEY_OPTION = None,
    yes: Annotated[
        bool,
        typer.Option("--yes", "-y", help="Skip confirmation prompt."),
    ] = False,
):
    """Remove all items from the knowledge base."""
    if not dsn:
        typer.echo("error: --dsn is required (or set SQLGRAPH_DSN).", err=True)
        raise typer.Exit(1)

    if not yes:
        typer.confirm("This will delete all training data. Continue?", abort=True)

    agent = _build_agent(dsn, provider, api_key)
    agent.clear_training()
    typer.echo("cleared.")


@app.command("export")
def cmd_export(
    dsn: DSN_OPTION = "",
    provider: PROVIDER_OPTION = "openai",
    api_key: API_KEY_OPTION = None,
    output: Annotated[
        str,
        typer.Option("--output", "-o", help="Output JSON file path."),
    ] = "sqlgraph_backup.json",
):
    """Export the knowledge base to a JSON file."""
    if not dsn:
        typer.echo("error: --dsn is required (or set SQLGRAPH_DSN).", err=True)
        raise typer.Exit(1)

    agent = _build_agent(dsn, provider, api_key)
    agent.export_training(output)
    typer.echo(f"exported to {output}")


@app.command("import")
def cmd_import(
    dsn: DSN_OPTION = "",
    provider: PROVIDER_OPTION = "openai",
    api_key: API_KEY_OPTION = None,
    input_file: Annotated[
        str,
        typer.Option("--input", "-i", help="JSON file to import."),
    ] = "sqlgraph_backup.json",
):
    """Import a knowledge base from a JSON file."""
    if not dsn:
        typer.echo("error: --dsn is required (or set SQLGRAPH_DSN).", err=True)
        raise typer.Exit(1)

    if not os.path.exists(input_file):
        typer.echo(f"error: file not found: {input_file}", err=True)
        raise typer.Exit(1)

    agent = _build_agent(dsn, provider, api_key)
    agent.import_training(input_file)
    typer.echo(f"imported from {input_file}")


if __name__ == "__main__":
    app()
