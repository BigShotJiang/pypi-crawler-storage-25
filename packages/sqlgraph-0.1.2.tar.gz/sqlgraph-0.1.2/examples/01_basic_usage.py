import os
from dotenv import load_dotenv

from sqlgraph import SQLAgent
from sqlgraph.llm import OpenAIProvider

# 1. Carrega variaveis de ambiente
load_dotenv()

# 2. Configurações de Conexão com o LLM e Banco (conforme seu vanna_db local)
dsn = "postgresql://vanna_user:vanna_pass@localhost:5432/vanna_db"

# A API KEY capturada do seu .env
provider = OpenAIProvider(api_key=os.getenv("OPENAI_API_KEY"), model="gpt-4o-mini")

# 3. Inicializaçao do Agente principal
print("=> Inicializando SQLAgent e disparando migrations no vanna_db...")
agent = SQLAgent(dsn=dsn, llm=provider, validate_sql=True, system_prompt="Você é um assistente inteligente especializado em SQL. Responda às perguntas gerando consultas SQL precisas e otimizadas. Use o conhecimento do schema e as regras de negócio para formular suas respostas. Se a pergunta for de chitchat, responda de forma amigável e útil, sem gerar SQL. Sempre explique seu raciocínio e a intenção por trás do SQL gerado.")

def main():
    print("\n--- TREINAMENTO (KNOWLEDGE BASE) ---")
    print("Ensinando o schema de 'clientes' ao agente e uma regra de negócio.")
    
    # Adicionando DDL
    agent.train(ddl="""
    CREATE TABLE IF NOT EXISTS clientes (
        id SERIAL PRIMARY KEY, 
        nome TEXT, 
        idade INT, 
        email TEXT
    );
    """)
    
    # Adicionando regra de negócio solta
    agent.train(documentation="As contas cujo email terminam em @gmail.com são consideradas as nossas contas GMAIL_VIP.")
    
    # Adicionando um exemplo
    agent.train(
        question="Quantos clientes tem mais de 30 anos?",
        sql="SELECT COUNT(*) FROM clientes WHERE idade > 30;"
    )
    print("Treinamento concluído e vetorizado no PostgreSQL (via pgvector)!")
    
    
    print("\n--- CONSULTAS ---")
    
    # Exemplo de Chitchat para testar a engine neural
    print("Q: Olá banco, tudo bem?")
    resp_chitchat = agent.ask("Olá banco, tudo bem?")
    print(f"[{resp_chitchat.intent}] A: {resp_chitchat.explanation}\n")
    
    # Exemplo SQL Complexo unindo schemas + doc
    print("Q: Qual o email dos clientes com contas GMAIL_VIP acima da idade de 18?")
    resp_sql = agent.ask("Qual o email dos clientes com contas GMAIL_VIP acima da idade de 18?", explain=True)
    
    print(f"[{resp_sql.intent}] SQL GERADO:\n{resp_sql.sql}\n")
    print(f"O SQL É VALIDO? {resp_sql.valid} (A validação simulou no banco)")
    print(f"EXPLICAÇÃO FINAL:\n{resp_sql.explanation}")
    

if __name__ == "__main__":
    main()
