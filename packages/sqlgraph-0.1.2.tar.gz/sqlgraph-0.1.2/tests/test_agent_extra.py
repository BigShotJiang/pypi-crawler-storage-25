import json
import os
import tempfile
from unittest.mock import MagicMock, patch

from sqlgraph.agent import SQLAgent
from sqlgraph.llm.base import BaseLLMProvider
from sqlgraph.models import Response, TrainingItem


class FakeLLM(BaseLLMProvider):
    embedding_dimensions = 100

    def embed(self, *args, **kwargs):
        return [0.0] * 100

    def complete(self, *args, **kwargs):
        return "sql"


@patch("sqlgraph.agent.build_graph")
@patch("sqlgraph.agent.KnowledgeStore")
def make_agent(mock_knowledge, mock_build, **kwargs):
    llm = FakeLLM()
    return SQLAgent("postgres://fake", llm, **kwargs), mock_knowledge, mock_build


@patch("sqlgraph.agent.build_graph")
@patch("sqlgraph.agent.KnowledgeStore")
def test_train_from_file(mock_knowledge, mock_build):
    llm = FakeLLM()
    agent = SQLAgent("postgres://fake", llm)

    sql_content = "CREATE TABLE a (id INT);\nCREATE TABLE b (name TEXT);"
    with tempfile.NamedTemporaryFile(mode="w", suffix=".sql", delete=False) as f:
        f.write(sql_content)
        tmp_path = f.name

    try:
        agent.train_from_file(tmp_path)
        calls = mock_knowledge.return_value.train.call_args_list
        assert len(calls) == 2
        assert "CREATE TABLE a" in calls[0][0][0]
        assert "CREATE TABLE b" in calls[1][0][0]
    finally:
        os.unlink(tmp_path)


@patch("sqlgraph.agent.build_graph")
@patch("sqlgraph.agent.KnowledgeStore")
def test_train_from_file_ignores_non_create(mock_knowledge, mock_build):
    llm = FakeLLM()
    agent = SQLAgent("postgres://fake", llm)

    sql_content = "INSERT INTO t VALUES (1);\nCREATE TABLE c (id INT);"
    with tempfile.NamedTemporaryFile(mode="w", suffix=".sql", delete=False) as f:
        f.write(sql_content)
        tmp_path = f.name

    try:
        agent.train_from_file(tmp_path)
        calls = mock_knowledge.return_value.train.call_args_list
        assert len(calls) == 1
        assert "CREATE TABLE c" in calls[0][0][0]
    finally:
        os.unlink(tmp_path)


@patch("sqlgraph.agent.build_graph")
@patch("sqlgraph.agent.KnowledgeStore")
def test_export_training(mock_knowledge, mock_build):
    mock_knowledge.return_value.list_training.return_value = [
        TrainingItem(id="1", type="ddl", content="CREATE TABLE t (id INT)", created_at=""),
        TrainingItem(id="2", type="doc", content="business rule", created_at=""),
    ]

    llm = FakeLLM()
    agent = SQLAgent("postgres://fake", llm)

    with tempfile.NamedTemporaryFile(mode="r", suffix=".json", delete=False) as f:
        tmp_path = f.name

    try:
        agent.export_training(tmp_path)
        with open(tmp_path) as f:
            data = json.load(f)
        assert len(data) == 2
        assert data[0]["type"] == "ddl"
        assert data[1]["type"] == "doc"
    finally:
        os.unlink(tmp_path)


@patch("sqlgraph.agent.build_graph")
@patch("sqlgraph.agent.KnowledgeStore")
def test_import_training_ddl_and_doc(mock_knowledge, mock_build):
    llm = FakeLLM()
    agent = SQLAgent("postgres://fake", llm)

    data = [
        {"type": "ddl", "content": "CREATE TABLE x (id INT)"},
        {"type": "doc", "content": "rule"},
    ]

    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(data, f)
        tmp_path = f.name

    try:
        agent.import_training(tmp_path)
        calls = mock_knowledge.return_value.train.call_args_list
        assert len(calls) == 2
    finally:
        os.unlink(tmp_path)


@patch("sqlgraph.agent.build_graph")
@patch("sqlgraph.agent.KnowledgeStore")
def test_import_training_query_example(mock_knowledge, mock_build):
    llm = FakeLLM()
    agent = SQLAgent("postgres://fake", llm)

    data = [
        {"type": "query_example", "content": "Question: total?\nSQL: SELECT SUM(x) FROM t"},
    ]

    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(data, f)
        tmp_path = f.name

    try:
        agent.import_training(tmp_path)
        calls = mock_knowledge.return_value.train.call_args_list
        assert len(calls) == 1
        assert any("SELECT SUM(x)" in str(c) for c in calls[0])
    finally:
        os.unlink(tmp_path)


@patch("sqlgraph.agent.psycopg2.connect")
@patch("sqlgraph.agent.build_graph")
@patch("sqlgraph.agent.KnowledgeStore")
def test_ask_execute_true(mock_knowledge, mock_build, mock_connect):
    mock_graph = MagicMock()
    mock_graph.invoke.return_value = {
        "generated_sql": "SELECT 1 AS num",
        "intent": "sql",
        "final_response": "Returns 1.",
        "validation_result": {"valid": True},
        "correction_attempts": 0,
    }
    mock_build.return_value = mock_graph

    mock_conn = MagicMock()
    mock_cursor = MagicMock()
    mock_connect.return_value.__enter__.return_value = mock_conn
    mock_conn.cursor.return_value.__enter__.return_value = mock_cursor
    mock_cursor.description = [("num",)]
    mock_cursor.fetchall.return_value = [(1,)]

    llm = FakeLLM()
    agent = SQLAgent("postgres://fake", llm)
    resp = agent.ask("Returns 1?", execute=True)

    assert resp.sql == "SELECT 1 AS num"
    assert resp.valid is True
    assert resp.data == [{"num": 1}]


@patch("sqlgraph.agent.build_graph")
@patch("sqlgraph.agent.KnowledgeStore")
def test_max_correction_attempts_propagated(mock_knowledge, mock_build):
    llm = FakeLLM()
    SQLAgent("postgres://fake", llm, max_correction_attempts=5)
    mock_build.assert_called_once_with("postgres://fake", llm, "postgres", 5)
