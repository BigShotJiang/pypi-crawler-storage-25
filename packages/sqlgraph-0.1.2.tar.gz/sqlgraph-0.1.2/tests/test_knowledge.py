import pytest
from unittest.mock import MagicMock, patch

from sqlgraph.exceptions import TrainingError
from sqlgraph.knowledge.retriever import SchemaRetriever
from sqlgraph.knowledge.store import KnowledgeStore


class FakeProvider:
    embedding_dimensions = 1536

    def embed(self, text):
        return [0.1] * 1536


@patch("sqlgraph.knowledge.store.run_migrations")
def test_knowledge_store_init(mock_run_migrations):
    provider = FakeProvider()
    KnowledgeStore("postgres://fake", provider)
    mock_run_migrations.assert_called_once_with("postgres://fake", 1536)


@patch("sqlgraph.knowledge.store.run_migrations", side_effect=Exception("DB OFF"))
def test_knowledge_store_init_fails(mock_run_migrations):
    with pytest.raises(TrainingError, match="Falha ao inicializar migrations"):
        KnowledgeStore("postgres://fake", FakeProvider())


@patch("sqlgraph.knowledge.store.run_migrations")
def test_train_invalid_arguments(mock_run_migrations):
    store = KnowledgeStore("postgres://fake", FakeProvider())

    with pytest.raises(ValueError, match="Forneça 'ddl', 'documentation'"):
        store.train()

    with pytest.raises(ValueError, match="Forneça 'ddl', 'documentation'"):
        store.train(question="Question?")

    with pytest.raises(ValueError, match="Forneça 'ddl', 'documentation'"):
        store.train(sql="SELECT 1")


@patch("sqlgraph.knowledge.store.run_migrations")
@patch("sqlgraph.knowledge.store.psycopg2.connect")
def test_train_success(mock_connect, mock_run_migrations):
    mock_conn = MagicMock()
    mock_cursor = MagicMock()
    mock_connect.return_value.__enter__.return_value = mock_conn
    mock_conn.cursor.return_value.__enter__.return_value = mock_cursor
    mock_cursor.fetchone.return_value = ("uuid-123",)

    store = KnowledgeStore("postgres://fake", FakeProvider())
    store.train(ddl="CREATE TABLE t (id INT)")

    call_args = mock_cursor.execute.call_args[0]
    sql = call_args[0]
    params = call_args[1]

    assert "INSERT INTO sqlgraph_knowledge" in sql
    assert params[0] == "ddl"
    assert params[1] == "CREATE TABLE t (id INT)"
    assert params[2] == "{}"
    assert len(params[3]) == 1536


@patch("sqlgraph.knowledge.retriever.psycopg2.connect")
def test_schema_retriever_formatting(mock_connect):
    mock_conn = MagicMock()
    mock_cursor = MagicMock()
    mock_connect.return_value.__enter__.return_value = mock_conn
    mock_conn.cursor.return_value.__enter__.return_value = mock_cursor

    mock_cursor.fetchall.return_value = [
        ("ddl", "CREATE TABLE a (id INT)"),
        ("doc", "rule 1"),
        ("query_example", "SQL example"),
    ]

    retriever = SchemaRetriever("postgres://fake", FakeProvider(), limit=3)
    context = retriever.retrieve("How?")

    call_args = mock_cursor.execute.call_args[0]
    sql = call_args[0]
    assert "embedding <=> %s::vector" in sql

    assert "## DDL Relevante" in context
    assert "CREATE TABLE a (id INT)" in context
    assert "## Documentação de Negócio" in context
    assert "rule 1" in context
    assert "## Exemplos de Queries Similares" in context
    assert "SQL example" in context


@patch("sqlgraph.knowledge.retriever.psycopg2.connect")
def test_schema_retriever_ignores_empty_sections(mock_connect):
    mock_conn = MagicMock()
    mock_cursor = MagicMock()
    mock_connect.return_value.__enter__.return_value = mock_conn
    mock_conn.cursor.return_value.__enter__.return_value = mock_cursor

    mock_cursor.fetchall.return_value = [
        ("ddl", "CREATE TABLE a (id INT)"),
    ]

    retriever = SchemaRetriever("postgres://fake", FakeProvider(), limit=3)
    context = retriever.retrieve("How?")

    assert "## DDL Relevante" in context
    assert "CREATE TABLE a (id INT)" in context
    assert "## Documentação de Negócio" not in context
    assert "## Exemplos de Queries Similares" not in context
