"""Testes para o InMemorySessionStore."""

from sqlgraph.storage.memory import InMemorySessionStore


def test_get_sessao_inexistente_retorna_lista_vazia():
    """get() deve retornar lista vazia para sessão não existente."""
    store = InMemorySessionStore()
    assert store.get("sessao-123") == []


def test_save_e_get():
    """save() deve persistir mensagens e get() deve recuperá-las."""
    store = InMemorySessionStore()
    messages = [{"role": "user", "content": "Olá"}]
    store.save("sessao-123", messages)
    assert store.get("sessao-123") == messages


def test_delete():
    """delete() deve remover a sessão do store."""
    store = InMemorySessionStore()
    store.save("sessao-123", [{"role": "user", "content": "teste"}])
    store.delete("sessao-123")
    assert store.get("sessao-123") == []


def test_delete_sessao_inexistente_nao_levanta():
    """delete() não deve levantar erro para sessão que não existe."""
    store = InMemorySessionStore()
    store.delete("sessao-nao-existe")  # não deve lançar exceção
