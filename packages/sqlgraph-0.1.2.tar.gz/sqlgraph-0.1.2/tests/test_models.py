"""Testes para os modelos de dados."""

from sqlgraph.models import Response, TrainingItem, ValidationResult


def test_response_defaults():
    """Response deve ter valores padrão sensatos."""
    r = Response()
    assert r.sql == ""
    assert r.valid is False
    assert r.attempts == 0
    assert r.data == []
    assert r.row_count == 0
    assert r.error is None


def test_training_item_defaults():
    """TrainingItem deve inicializar com campos vazios."""
    item = TrainingItem()
    assert item.id == ""
    assert item.type == ""
    assert item.content == ""


def test_validation_result_default_invalido():
    """ValidationResult deve ser inválido por padrão."""
    v = ValidationResult()
    assert v.valid is False
    assert v.error is None
