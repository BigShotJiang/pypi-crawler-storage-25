import pytest
from unittest.mock import MagicMock, patch

from sqlgraph.graph.nodes import (
    make_chitchat_response,
    make_intent_classifier,
    make_sql_generator,
    make_sql_validator,
)
from sqlgraph.graph.state import AgentState
from sqlgraph.llm.base import BaseLLMProvider


class FakeLLM(BaseLLMProvider):
    embedding_dimensions = 1536

    def __init__(self, response_text="sql"):
        self.response = response_text

    def complete(self, messages, **kwargs):
        return self.response

    def embed(self, text):
        return [0.0] * 1536


def test_intent_classifier_sql():
    provider = FakeLLM("sql")
    node = make_intent_classifier(provider)
    state = AgentState(
        user_input="Quantas vendas?",
        messages=[],
        session_id="1",
        intent="",
        retrieved_schema="",
        generated_sql="",
        validation_result={},
        correction_attempts=0,
        final_response="",
        system_prompt="",
    )
    new_state = node(state)
    assert new_state["intent"] == "sql"


def test_sql_generator():
    provider = FakeLLM("```sql\nSELECT * FROM tab;\n```")
    node = make_sql_generator(provider)
    state = AgentState(
        user_input="Tudo da tab",
        messages=[],
        session_id="1",
        intent="",
        retrieved_schema="CREATE TABLE tab (id INT);",
        generated_sql="",
        validation_result={},
        correction_attempts=0,
        final_response="",
        system_prompt="",
    )
    new_state = node(state)
    assert new_state["generated_sql"] == "SELECT * FROM tab;"


@patch("sqlgraph.graph.nodes.psycopg2.connect")
def test_sql_validator_success(mock_connect):
    mock_connect.return_value.__enter__.return_value = MagicMock()

    node = make_sql_validator("dsn_fake")
    state = AgentState(
        user_input="",
        messages=[],
        session_id="1",
        intent="",
        retrieved_schema="",
        generated_sql="SELECT 1 as teste FROM fake_table",
        validation_result={},
        correction_attempts=0,
        final_response="",
        system_prompt="",
    )
    new_state = node(state)
    assert new_state["validation_result"]["valid"] is True


def test_sql_validator_invalid_syntax():
    node = make_sql_validator("dsn_fake")
    state = AgentState(
        user_input="",
        messages=[],
        session_id="1",
        intent="",
        retrieved_schema="",
        generated_sql="SELECT * FROM tab WHERE",
        validation_result={},
        correction_attempts=0,
        final_response="",
        system_prompt="",
    )
    new_state = node(state)
    assert new_state["validation_result"]["valid"] is False
    assert "Erro de sintaxe" in new_state["validation_result"]["error"]


def test_chitchat_response():
    provider = FakeLLM("Olá! Como posso ajudar?")
    node = make_chitchat_response(provider)
    state = AgentState(
        user_input="Oi",
        messages=[],
        session_id="1",
        intent="chitchat",
        retrieved_schema="",
        generated_sql="",
        validation_result={},
        correction_attempts=0,
        final_response="",
        system_prompt="",
    )
    new_state = node(state)
    assert new_state["final_response"] == "Olá! Como posso ajudar?"
