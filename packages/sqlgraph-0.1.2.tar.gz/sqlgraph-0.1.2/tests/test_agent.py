import pytest
from unittest.mock import MagicMock, patch

from sqlgraph.agent import SQLAgent
from sqlgraph.exceptions import ConfigurationError
from sqlgraph.llm.base import BaseLLMProvider


class FakeLLM(BaseLLMProvider):
    embedding_dimensions = 100

    def embed(self, *args, **kwargs):
        return [0] * 100

    def complete(self, *args, **kwargs):
        return "sql"


def test_sqlagent_requires_dsn():
    with pytest.raises(ConfigurationError, match="dsn não pode ser vazio"):
        SQLAgent("", FakeLLM())


def test_sqlagent_requires_llm():
    with pytest.raises(ConfigurationError, match="llm é obrigatório"):
        SQLAgent("postgres://fake", None)


@patch("sqlgraph.agent.build_graph")
@patch("sqlgraph.agent.KnowledgeStore")
def test_sqlagent_init(mock_knowledge, mock_build):
    llm = FakeLLM()
    SQLAgent("postgres://fake", llm, dialect="mysql")

    mock_knowledge.assert_called_once_with("postgres://fake", llm)
    mock_build.assert_called_once_with("postgres://fake", llm, "mysql", 2)


@patch("sqlgraph.agent.build_graph")
@patch("sqlgraph.agent.KnowledgeStore")
def test_sqlagent_train(mock_knowledge, mock_build):
    llm = FakeLLM()
    agent = SQLAgent("postgres://fake", llm)

    agent.train(ddl="CREATE TABLE")
    mock_knowledge.return_value.train.assert_called_once_with(
        "CREATE TABLE", None, None, None, None
    )


@patch("sqlgraph.agent.uuid.uuid4")
@patch("sqlgraph.agent.build_graph")
@patch("sqlgraph.agent.KnowledgeStore")
def test_sqlagent_ask(mock_knowledge, mock_build, mock_uuid):
    mock_uuid.return_value = "new_session"

    mock_graph = MagicMock()
    mock_graph.invoke.return_value = {
        "generated_sql": "SELECT 1",
        "intent": "sql",
        "final_response": "Consulta simples",
        "validation_result": {"valid": True},
        "correction_attempts": 0,
    }
    mock_build.return_value = mock_graph

    llm = FakeLLM()
    agent = SQLAgent("postgres://fake", llm)
    resp = agent.ask("Qual a table?")

    assert resp.sql == "SELECT 1"
    assert resp.intent == "sql"
    assert resp.valid is True

    session_msgs = agent.session_store.get("new_session")
    assert len(session_msgs) == 2
    assert session_msgs[0].content == "Qual a table?"
    assert session_msgs[1].content == "Consulta simples"
