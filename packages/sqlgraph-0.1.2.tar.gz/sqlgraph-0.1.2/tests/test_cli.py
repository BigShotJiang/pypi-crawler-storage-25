"""Testes para CLI do sqlgraph."""

import json
import os
import tempfile

import pytest
from unittest.mock import patch, MagicMock
from typer.testing import CliRunner

from sqlgraph.cli import app
from sqlgraph.models import Response, TrainingItem


runner = CliRunner()


class FakeAgent:
    """SQLAgent fake para testes da CLI."""

    def __init__(self, *args, **kwargs):
        self.trained = []

    def train(self, ddl=None, documentation=None, question=None, sql=None, metadata=None):
        self.trained.append({"ddl": ddl, "doc": documentation, "question": question, "sql": sql})

    def train_bulk(self, items):
        for item in items:
            self.train(**item)

    def train_from_file(self, path):
        self.trained.append({"file": path})

    def list_training(self):
        return [
            TrainingItem(
                id="uuid-001", type="ddl", content="CREATE TABLE pagamentos (id INT)", created_at=""
            ),
            TrainingItem(
                id="uuid-002", type="doc", content="vl_pagamento é o valor em reais", created_at=""
            ),
        ]

    def clear_training(self):
        self.trained.clear()

    def export_training(self, path):
        with open(path, "w") as f:
            json.dump([], f)

    def import_training(self, path):
        pass

    def ask(self, question, session_id=None, execute=False, max_rows=100, **kwargs):
        return Response(
            sql="SELECT SUM(vl_pagamento) FROM pagamentos",
            explanation="Soma todos os pagamentos.",
            intent="sql",
            valid=True,
            attempts=1,
            data=[{"total": 9999}] if execute else [],
        )


@pytest.fixture(autouse=True)
def mock_build_agent(monkeypatch):
    """Substitui _build_agent por um que retorna o FakeAgent."""
    monkeypatch.setattr("sqlgraph.cli._build_agent", lambda *args, **kwargs: FakeAgent())


def test_cli_train_ddl():
    result = runner.invoke(
        app, ["train", "--dsn", "postgres://fake", "--ddl", "CREATE TABLE t (id INT)"]
    )
    assert result.exit_code == 0
    assert "trained: ddl" in result.output


def test_cli_train_doc():
    result = runner.invoke(app, ["train", "--dsn", "postgres://fake", "--doc", "regra de negócio"])
    assert result.exit_code == 0
    assert "trained: doc" in result.output


def test_cli_train_question_sql():
    result = runner.invoke(
        app,
        [
            "train",
            "--dsn",
            "postgres://fake",
            "--question",
            "Total?",
            "--sql",
            "SELECT SUM(x) FROM t",
        ],
    )
    assert result.exit_code == 0
    assert "trained: question/sql" in result.output


def test_cli_train_file():
    with tempfile.NamedTemporaryFile(suffix=".sql", mode="w", delete=False) as f:
        f.write("CREATE TABLE t (id INT);")
        tmp_path = f.name
    try:
        result = runner.invoke(app, ["train", "--dsn", "postgres://fake", "--file", tmp_path])
        assert result.exit_code == 0
        assert "trained:" in result.output
    finally:
        os.unlink(tmp_path)


def test_cli_train_sem_dsn():
    result = runner.invoke(app, ["train", "--ddl", "CREATE TABLE t (id INT)"])
    assert result.exit_code != 0
    assert "error:" in result.output


def test_cli_train_sem_dados():
    result = runner.invoke(app, ["train", "--dsn", "postgres://fake"])
    assert result.exit_code != 0
    assert "error: provide one of" in result.output


def test_cli_ask():
    result = runner.invoke(app, ["ask", "--dsn", "postgres://fake", "Qual o total pago?"])
    assert result.exit_code == 0
    assert "SELECT" in result.output
    assert "intent:" in result.output


def test_cli_ask_json():
    result = runner.invoke(app, ["ask", "--dsn", "postgres://fake", "--json", "Qual o total pago?"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["sql"] == "SELECT SUM(vl_pagamento) FROM pagamentos"
    assert data["valid"] is True


def test_cli_ask_execute():
    result = runner.invoke(app, ["ask", "--dsn", "postgres://fake", "--execute", "Total?"])
    assert result.exit_code == 0
    assert "9999" in result.output


def test_cli_list():
    result = runner.invoke(app, ["list", "--dsn", "postgres://fake"])
    assert result.exit_code == 0
    assert "ddl" in result.output
    assert "uuid-001" in result.output


def test_cli_list_filter_type():
    result = runner.invoke(app, ["list", "--dsn", "postgres://fake", "--type", "ddl"])
    assert result.exit_code == 0
    assert "uuid-001" in result.output
    assert "uuid-002" not in result.output


def test_cli_clear_com_confirmacao():
    result = runner.invoke(app, ["clear", "--dsn", "postgres://fake", "--yes"])
    assert result.exit_code == 0
    assert "cleared." in result.output


def test_cli_export():
    with tempfile.TemporaryDirectory() as tmp_dir:
        output_path = os.path.join(tmp_dir, "backup.json")
        result = runner.invoke(app, ["export", "--dsn", "postgres://fake", "--output", output_path])
        assert result.exit_code == 0
        assert "exported to" in result.output


def test_cli_import():
    with tempfile.NamedTemporaryFile(suffix=".json", mode="w", delete=False) as f:
        json.dump([], f)
        tmp_path = f.name
    try:
        result = runner.invoke(app, ["import", "--dsn", "postgres://fake", "--input", tmp_path])
        assert result.exit_code == 0
        assert "imported from" in result.output
    finally:
        os.unlink(tmp_path)


def test_cli_import_arquivo_inexistente():
    result = runner.invoke(
        app, ["import", "--dsn", "postgres://fake", "--input", "nao_existe.json"]
    )
    assert result.exit_code != 0
    assert "error:" in result.output
