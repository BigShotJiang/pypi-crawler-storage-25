import pytest

from sqlgraph.llm import BaseLLMProvider, CompositeProvider, GeminiProvider, OpenAIProvider


def test_openai_provider_embedding_dimensions_default():
    provider = OpenAIProvider(api_key="test-key")
    assert provider.embedding_dimensions == 1536


def test_openai_provider_embedding_dimensions_large():
    provider = OpenAIProvider(api_key="test-key", embedding_model="text-embedding-3-large")
    assert provider.embedding_dimensions == 3072


def test_gemini_provider_embedding_dimensions():
    provider = GeminiProvider(api_key="test-key")
    assert provider.embedding_dimensions == 768


class FakeProvider(BaseLLMProvider):
    def __init__(self, dims=1536):
        self._dims = dims

    def complete(self, messages, **kwargs):
        return "sql"

    def embed(self, text):
        return [0.0] * self._dims

    @property
    def embedding_dimensions(self):
        return self._dims


def test_composite_provider_embedding_delegation():
    completion_provider = FakeProvider(dims=1536)
    embedding_provider = FakeProvider(dims=768)
    composite = CompositeProvider(
        completion=completion_provider,
        embedding=embedding_provider,
    )
    assert composite.embedding_dimensions == 768
    assert composite.embed("test") == [0.0] * 768
    assert composite.complete([]) == "sql"
