# sqlgraph

> Uma lib Python open source que combina **LangGraph + pgvector** para geração de SQL através de linguagem natural.

[![CI](https://github.com/guilerme/sqlgraph/actions/workflows/ci.yml/badge.svg)](https://github.com/guilerme/sqlgraph/actions/workflows/ci.yml)
[![PyPI version](https://badge.fury.io/py/sqlgraph.svg)](https://badge.fury.io/py/sqlgraph)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

O `sqlgraph` é um pipeline **RAG (Retrieval-Augmented Generation)** focado em converter perguntas de negócio em consultas SQL corretas e validadas. Em vez de operar como um chatbot genérico, ele orquestra um agente corporativo que:

1. Classifica a intenção do usuário (SQL, chitchat, ambíguo).
2. Recupera o contexto relevante do schema via embeddings + `pgvector`.
3. Gera a query SQL usando um LLM.
4. Valida a sintaxe com `sqlglot` e a semântica com `EXPLAIN` diretamente no banco.
5. Corrige automaticamente queries inválidas antes de retornar.

---

## Pré-requisitos

- **Python 3.11+**
- **PostgreSQL** com a extensão **pgvector** instalada:
  ```sql
  -- Execute no seu banco PostgreSQL:
  CREATE EXTENSION IF NOT EXISTS vector;
  ```
  > Instalação do pgvector: [https://github.com/pgvector/pgvector](https://github.com/pgvector/pgvector)
- Uma **API key** da [OpenAI](https://platform.openai.com/) **ou** do [Google Gemini](https://ai.google.dev/).

---

## Instalação

```bash
pip install sqlgraph
```

Para usar o CLI de linha de comando:
```bash
pip install sqlgraph[cli]
```

---

## Início Rápido

```python
from sqlgraph import SQLAgent
from sqlgraph.llm import OpenAIProvider

# 1. Configura o agente
agent = SQLAgent(
    dsn="postgresql://user:pass@localhost/db",
    llm=OpenAIProvider(api_key="sk-..."),
)

# 2. Treina com o esquema e regras do seu banco
agent.train(ddl="CREATE TABLE pagamentos (id SERIAL, valor NUMERIC, data DATE)")
agent.train(documentation="O campo 'valor' representa o valor bruto em reais.")
agent.train(
    question="Qual o total pago em 2023?",
    sql="SELECT SUM(valor) FROM pagamentos WHERE EXTRACT(year FROM data) = 2023"
)

# 3. Faz perguntas em linguagem natural
response = agent.ask("Qual o total pago por mês em 2023?")
print(response.sql)         # A query gerada
print(response.explanation) # Explicação em texto
print(response.valid)       # True se passou na validação
```

---

## Configuração via Variáveis de Ambiente

```bash
export OPENAI_API_KEY="sk-..."
export SQLGRAPH_DSN="postgresql://user:pass@localhost/db"
```

---

## API de Referência

### `SQLAgent`

```python
agent = SQLAgent(
    dsn="postgresql://...",           # Connection string do PostgreSQL (obrigatório)
    llm=OpenAIProvider(...),          # Provider de LLM (obrigatório)
    session_store=None,               # Default: InMemorySessionStore()
    max_correction_attempts=2,        # Tentativas de auto-correção de queries inválidas
    validate_sql=True,                # Validar SQL com sqlglot + EXPLAIN
    retrieval_limit=10,               # Chunks recuperados por query do knowledge base
    system_prompt=None,               # System prompt customizado para o gerador de SQL
    dialect="postgres",               # Dialeto SQL (postgres, mysql, sqlite...)
)
```

#### Métodos de Treinamento

| Método | Descrição |
|---|---|
| `train(ddl=..., documentation=..., question=..., sql=...)` | Adiciona 1 item ao knowledge base |
| `train_bulk(items)` | Adiciona múltiplos itens de uma vez |
| `train_from_file("schema.sql")` | Ingere todos os `CREATE TABLE` de um arquivo |
| `list_training()` | Retorna todos os itens como `list[TrainingItem]` |
| `remove_training(item_id)` | Remove um item pelo UUID |
| `clear_training()` | Remove todos os itens |
| `export_training("backup.json")` | Exporta o knowledge base para JSON |
| `import_training("backup.json")` | Importa o knowledge base de um JSON |

#### `agent.ask()`

```python
response = agent.ask(
    question="Qual o total pago?",  # Pergunta em linguagem natural
    session_id="minha-sessao",      # ID de sessão para conversa multi-turn (opcional)
    execute=False,                  # Se True, executa o SQL e retorna os dados
    max_rows=100,                   # Limite de linhas quando execute=True
    explain=False,                  # Se True, inclui EXPLAIN ANALYZE na resposta
)
```

**`Response`:**
```
response.sql          # SQL gerado
response.explanation  # Explicação em linguagem natural
response.intent       # 'sql' | 'chitchat' | 'ambiguous'
response.valid        # True se passou na validação
response.attempts     # Número de tentativas até o SQL válido
response.data         # list[dict] com linhas (se execute=True)
response.error        # Mensagem de erro (se válido=False)
```

### Conversas Multi-Turn

```python
session_id = "sessao-usuario-123"
r1 = agent.ask("Liste os 5 maiores pagamentos.", session_id=session_id)
r2 = agent.ask("Agora filtre só os de 2024.", session_id=session_id)  # Contexto mantido!
```

### Providers de LLM

```python
from sqlgraph.llm import OpenAIProvider, GeminiProvider

# OpenAI
llm = OpenAIProvider(api_key="sk-...", model="gpt-4o")

# Google Gemini
llm = GeminiProvider(api_key="AIza...", model="gemini-2.0-flash")
```

### Session Store Persistente (PostgreSQL)

```python
from sqlgraph.storage import PostgresSessionStore

store = PostgresSessionStore(dsn="postgresql://...")
agent = SQLAgent(dsn="...", llm=llm, session_store=store)
```

---

## CLI

Configure as variáveis de ambiente e use o CLI direto do terminal:

```bash
# Ingerir um schema SQL
sqlgraph train --dsn postgresql://... --file schema.sql

# Adicionar uma regra de negócio
sqlgraph train --dsn postgresql://... --doc "vl_pagamento é o valor bruto em reais"

# Fazer uma pergunta
sqlgraph ask --dsn postgresql://... "Qual o total pago em 2023?"

# Executar a query no banco e ver os dados
sqlgraph ask --dsn postgresql://... --execute "Top 10 clientes por valor total"

# Listar o knowledge base
sqlgraph list --dsn postgresql://...

# Exportar/importar backup
sqlgraph export --dsn postgresql://... --output backup.json
sqlgraph import --dsn postgresql://... --input backup.json
```

---

## Exemplos

Veja exemplos completos na pasta [`examples/`](./examples/):

- [`01_basic_usage.py`](./examples/01_basic_usage.py): uso básico do `SQLAgent`.

---

## Documentação

Documentação completa será disponibilizada na Wiki em breve.

---

## Licença

MIT © 2026 SQLGraph Project
