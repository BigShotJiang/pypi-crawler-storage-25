"""Deprecated stub — redirects users to the new 'faultlines' package."""
import sys

def main():
    print(
        "\n"
        "  ╭─────────────────────────────────────────────────────────╮\n"
        "  │  'faultline' has been renamed to 'faultlines' (plural) │\n"
        "  │                                                         │\n"
        "  │  To upgrade:                                            │\n"
        "  │    pip uninstall faultline                               │\n"
        "  │    pip install faultlines                                │\n"
        "  │                                                         │\n"
        "  │  Then use:  faultlines analyze .                        │\n"
        "  │                                                         │\n"
        "  │  https://github.com/PashaSchool/faultlines              │\n"
        "  ╰─────────────────────────────────────────────────────────╯\n"
    )
    sys.exit(1)

if __name__ == "__main__":
    main()
