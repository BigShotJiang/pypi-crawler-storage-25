# faultline → faultlines

**This package has been renamed to [`faultlines`](https://pypi.org/project/faultlines/) (plural).**

```bash
pip uninstall faultline
pip install faultlines
faultlines analyze .
```

See [github.com/PashaSchool/faultlines](https://github.com/PashaSchool/faultlines) for docs.
