"""trusty-cage: Isolated Docker-based development environments for AI coding agents."""

__version__ = "0.6.0"
