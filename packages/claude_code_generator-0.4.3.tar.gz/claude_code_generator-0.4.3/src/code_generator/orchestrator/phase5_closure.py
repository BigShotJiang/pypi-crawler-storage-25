"""Phase 5 — Closure and cross-module review.

Runs Opus 4.7 to review the full codebase, close any straggling issues,
and optionally create new ``fix:`` issues.  After the session, re-fetches
open issues and returns a :class:`FixResult` so the orchestrator can
re-enter phases 3/4 for any newly-created fix issues.

Non-negotiable #8: model is hard-coded to ``claude-opus-4-7``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from code_generator import effort as _effort
from code_generator import gh, git_ops
from code_generator import state as _state
from code_generator.logging_setup import log_phase_usage, setup_phase_logger
from code_generator.orchestrator._comments import fetch_issue_comments
from code_generator.orchestrator._phase5_precommit import collect_lint_errors
from code_generator.prompts import format_comments, load_prompt, truncate_placeholder
from code_generator.runner import rate_limit
from code_generator.runner._telemetry import accumulate_telemetry
from code_generator.runner.mcp import build_mcp_servers, mcp_tool_wildcards
from code_generator.runner.options import make_agent_options, max_turns_kwargs
from code_generator.runner.sdk_runner import run_with_shared_client

if TYPE_CHECKING:
    import logging
    from pathlib import Path

    from code_generator.repo_info import RepoInfo
    from code_generator.runner.protocol import RunnerProtocol
    from code_generator.state import CycleState, IssueState, State


@dataclass
class FixResult:
    """Returned by :func:`run` to signal new fix issues to the orchestrator.

    Attributes:
        new_issues: List of IssueState objects for issues created during
            phase 5 (identified by the ``fix:`` title prefix).
    """

    new_issues: list[IssueState] = field(default_factory=list)


def _format_issue_section(number: int, title: str, comment_text: str) -> str:
    """Render a single issue as a markdown section with its comments.

    Args:
        number: Issue number.
        title: Issue title.
        comment_text: Pre-formatted comment markdown (may be empty).

    Returns:
        Markdown string with issue header and, when present, its comments.
    """
    header = f"### Issue #{number}: {title}"
    return f"{header}\n\n{comment_text}" if comment_text else header


def _find_issue_state(
    number: int,
    state: State,
    cycle: CycleState | None,
) -> IssueState | None:
    """Return the IssueState for *number* from state/cycle, or None if absent.

    Args:
        number: GitHub issue number to look up.
        state: Root state.
        cycle: Active cycle or ``None``.

    Returns:
        Matching :class:`~code_generator.state.IssueState` or ``None``.
    """
    issues = cycle.issues if cycle is not None else state.issues
    for issue in issues:
        if issue.number == number:
            return issue
    return None


def _fetch_open_issues_with_comments(
    repo: RepoInfo,
    milestone_title: str | None,
    logger: logging.Logger,
    *,
    state: State | None = None,
    cycle: CycleState | None = None,
    state_path: Path | None = None,
) -> str:
    """Pre-fetch open issues with comments for prompt injection.

    When *state* is provided, the cached ``IssueState.comments`` value is used
    for known issues instead of re-fetching from GitHub.  On a cache miss the
    live value is fetched, persisted to the matching ``IssueState``, and state
    is saved atomically before continuing.

    Args:
        repo: Repository to target.
        milestone_title: Milestone title to filter issues, or None for all.
        logger: Logger for warnings.
        state: Optional root state for comment cache lookup.
        cycle: Active cycle for multi-cycle mode (used only when *state* set).
        state_path: Absolute path to ``state.json`` (used only on cache miss).

    Returns:
        Formatted markdown string with all open issues and their comments,
        or an empty string when no issues exist or GhError is raised.
    """
    try:
        issues = gh.list_issues(
            repo, milestone=milestone_title, state="open", fields=["number", "title"]
        )
    except gh.GhError as exc:
        logger.warning("Phase 5: could not pre-fetch open issues: %s", exc)
        return ""

    if not issues:
        return ""

    sections = [
        _format_issue_section(
            raw["number"],
            raw.get("title", ""),
            _get_comment_text(
                raw["number"], repo, logger, state=state, cycle=cycle, state_path=state_path
            ),
        )
        for raw in issues
    ]
    return "\n\n---\n\n".join(sections)


def _get_comment_text(
    number: int,
    repo: RepoInfo,
    logger: logging.Logger,
    *,
    state: State | None,
    cycle: CycleState | None,
    state_path: Path | None,
) -> str:
    """Return comment text for *number*, using cache when available.

    Args:
        number: GitHub issue number.
        repo: Repository to target on cache miss.
        logger: Logger for warnings.
        state: Optional root state for cache lookup.
        cycle: Active cycle or ``None``.
        state_path: Path to ``state.json``; used only when persisting a miss.

    Returns:
        Formatted comment markdown section (may be ``""``).
    """
    if state is not None:
        issue_state = _find_issue_state(number, state, cycle)
        if issue_state is not None:
            from code_generator.orchestrator._comments import get_or_fetch_comments

            return get_or_fetch_comments(
                issue_state,
                repo,
                state,
                state_path,
                logger,  # type: ignore[arg-type]
            )

    raw_comments = fetch_issue_comments(repo, number, logger)
    return format_comments(raw_comments)


async def _run_closure(
    prompt: str,
    options: Any,
    *,
    runner_module: RunnerProtocol,
    shared_client: Any | None,
    state_path: Path,
    logger: logging.Logger,
) -> Any:
    """Dispatch the closure session to shared-client or fresh-runner path.

    Args:
        prompt: The prompt text to send.
        options: Agent options (model, tools, etc.).
        runner_module: Fresh-mode runner (used only when shared_client is None).
        shared_client: Open ClaudeSDKClient for shared-session mode, or None.
        state_path: Path to state.json for rate-limit persistence.
        logger: Phase logger.

    Returns:
        RunResult from whichever path was taken.
    """
    if shared_client is not None:
        return await run_with_shared_client(
            shared_client, prompt, options, logger=logger, state_path=state_path
        )
    return await rate_limit.main_loop(
        runner_module, prompt, options, state_path=state_path, logger=logger
    )


_DIFF_CAP_BYTES = 20 * 1024


def fetch_diff_since_base(
    base_commit: str | None,
    project_dir: Path,
    logger: logging.Logger,
) -> str:
    """Return a pre-fetched diff string between *base_commit* and HEAD.

    Args:
        base_commit: Base commit SHA to diff against, or ``None``.
        project_dir: Project root directory.
        logger: Logger for warnings.

    Returns:
        Formatted string with stat summary and full diff, or empty string when
        *base_commit* is ``None`` or a :class:`~code_generator.git_ops.GitError`
        is raised.
    """
    if base_commit is None:
        return ""
    try:
        stat = git_ops.git_diff(project_dir, base_commit, stat=True)
        full = git_ops.git_diff(project_dir, base_commit)
    except git_ops.GitError as exc:
        logger.warning("Phase 5: could not fetch diff since base commit: %s", exc)
        return ""
    original_bytes = len(full.encode())
    capped = truncate_placeholder(full, max_tokens=5000)
    if capped != full:
        logger.warning(
            "phase5: diff truncated from %d bytes to %d bytes",
            original_bytes,
            len(capped.encode()),
        )
    return f"{stat}\n---\n{capped}"


def _known_numbers(state: State, cycle: CycleState | None) -> set[int]:
    """Return the set of issue numbers already in state/cycle.

    Args:
        state: Root state.
        cycle: Active cycle or ``None``.

    Returns:
        Set of known issue numbers.
    """
    issues = cycle.issues if cycle is not None else state.issues
    return {i.number for i in issues}


async def run(
    state: State,
    cycle: CycleState | None,
    project_dir: Path,
    *,
    runner_module: RunnerProtocol,
    logger: logging.Logger | None = None,
    shared_client: Any = None,
    max_turns: int | None = None,
) -> FixResult:
    """Execute phase 5: overall review and closure.

    Args:
        state: Root state object (mutated in place).
        cycle: Active cycle (multi-cycle) or ``None`` (single mode).
        project_dir: Project root directory.
        runner_module: Runner module from ``get_runner()``.
        logger: Optional phase logger.
        shared_client: Open ``ClaudeSDKClient`` injected by the orchestrator
            in shared-session mode; ``None`` in fresh mode.  When set, the
            closure session is dispatched via ``run_with_shared_client()`` so
            the Phase 2 + Phase 3/4 cache prefix is preserved.  No
            ``soft_reset_context()`` call is made — Phase 5 runs once per
            cycle (not per issue).

    Returns:
        :class:`FixResult` listing any new fix issues discovered after the
        session.  An empty list means no re-entry into phases 3/4 is needed.
    """
    if logger is None:
        logger = setup_phase_logger("phase5", project_dir)

    state_path = project_dir / ".code-generator" / "state.json"
    milestone_title = cycle.milestone_title if cycle is not None else None
    base_commit = cycle.base_commit if cycle is not None else state.base_commit

    # repo is populated by preflight before any phase runs; tests mock gh so
    # passing None through is safe at the type level.
    repo = state.repo  # type: ignore[assignment]

    # --- Pre-commit gate (§15): run linters before any SDK call. ---
    lint_errors, is_clean = collect_lint_errors(project_dir, logger)

    if is_clean:
        logger.info("Phase 5: clean; skipping SDK session")
        target = cycle if cycle is not None else state
        from code_generator.runner.types import TokenUsage

        target.token_usage["phase5"] = TokenUsage()
        _state.save_state(state_path, state)
        return FixResult()

    open_issues_section = _fetch_open_issues_with_comments(
        repo, milestone_title, logger, state=state, cycle=cycle, state_path=state_path
    )
    diff_section = fetch_diff_since_base(base_commit, project_dir, logger)

    prompt = load_prompt(
        "prompt-phase-5-final-review.md",
        CYCLE_SCOPE=(
            cycle.scope
            if cycle is not None
            else "single-cycle — implement all features from requirements.md"
        ),
        MILESTONE_TITLE=milestone_title or "",
        OPEN_ISSUES_WITH_COMMENTS=open_issues_section,
        DIFF_SINCE_BASE=diff_section,
        LINT_ERRORS=lint_errors,
    )

    mcp_servers = build_mcp_servers(project_dir)
    mcp_tools = mcp_tool_wildcards(mcp_servers)

    effort_level = _effort.resolve_effort(phase=5, complexity="", issue_labels=[], retry_count=0)
    _effort.validate_effort(effort_level, "claude-opus-4-7")

    options = make_agent_options(
        model="claude-opus-4-7",
        effort=effort_level,
        allowed_tools=["Read", "Bash", "Glob", "Grep", "WebSearch", "WebFetch"] + mcp_tools,
        cwd=str(project_dir),
        mcp_servers=mcp_servers,
        **max_turns_kwargs(max_turns),
    )

    result = await _run_closure(
        prompt,
        options,
        runner_module=runner_module,
        shared_client=shared_client,
        state_path=state_path,
        logger=logger,
    )

    target = cycle if cycle is not None else state
    target.token_usage["phase5"] = result.usage
    if hasattr(target, "cache_telemetry"):
        accumulate_telemetry(target.cache_telemetry, result.usage, result.wall_seconds)
    _state.save_state(state_path, state)
    log_phase_usage(logger, 5, result.usage)

    # Re-fetch open issues to detect any new fix: issues.
    known = _known_numbers(state, cycle)

    try:
        open_issues = gh.list_issues(
            repo, milestone=milestone_title, state="open", fields=["number", "labels"]
        )
    except gh.GhError as exc:
        logger.warning("Phase 5: could not list issues after session: %s", exc)
        return FixResult()

    new_issue_states: list[_state.IssueState] = []
    for raw in open_issues:
        num = raw["number"]
        if num in known:
            continue
        # Only pick up new issues — they may be fix: issues created by the session.
        new_state = _state.IssueState(
            number=num,
            status="open",
            agent=gh.agent_from_labels(raw.get("labels", [])),
            labels=[lbl.get("name", "") for lbl in raw.get("labels", []) if lbl.get("name")],
        )
        new_issue_states.append(new_state)

    if new_issue_states:
        # Append order may be descending (gh.list_issues() default); no sort
        # needed here because _state.get_issues() enforces ascending order
        # defensively at every read site.
        if cycle is not None:
            cycle.issues.extend(new_issue_states)
        else:
            state.issues.extend(new_issue_states)
        _state.save_state(state_path, state)
        logger.info("Phase 5: %d new fix issues detected.", len(new_issue_states))

    return FixResult(new_issues=new_issue_states)
