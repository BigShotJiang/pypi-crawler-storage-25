"""generate command — orchestrate a full project generation pipeline."""

from __future__ import annotations

import logging
import time
from enum import Enum
from pathlib import Path
from typing import Annotated, Literal

import typer

from code_generator import env
from code_generator import preflight as preflight_module
from code_generator import state as state_module
from code_generator.commands._dispatch import dispatch_orchestrator
from code_generator.commands._validators import validate_max_turns


class SessionMode(str, Enum):
    """Valid values for the --session-mode CLI flag."""

    shared = "shared"
    fresh = "fresh"
    batch = "batch"


_logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Pause guard
# ---------------------------------------------------------------------------


def _check_paused(st: state_module.State) -> bool:
    """Return True and print a message when the state is paused for rate limit.

    Args:
        st: Root state to inspect.

    Returns:
        True when the state indicates an active rate-limit pause.
    """
    if st.paused_until is not None and st.paused_until > time.time():
        remaining_s = st.paused_until - time.time()
        remaining_m = remaining_s / 60
        typer.echo(
            f"Rate-limit pause active — {remaining_m:.1f} minutes remaining. "
            "Re-run after the reset window expires.",
            err=False,
        )
        return True
    return False


# ---------------------------------------------------------------------------
# Preflight helpers
# ---------------------------------------------------------------------------


def _run_preflight(project_dir: Path) -> preflight_module.RepoInfo:  # type: ignore[name-defined]
    """Call run_preflight and translate PreflightError into exit-2.

    Prints two copy-pastable lines to stderr on failure:
    - ``preflight failed: <reason>``
    - ``fix: <fix_command>``

    Args:
        project_dir: Root directory passed to run_preflight.

    Returns:
        Validated :class:`~code_generator.repo_info.RepoInfo` on success.

    Raises:
        typer.Exit: With code 2 when preflight fails.
    """
    try:
        return preflight_module.run_preflight(project_dir)
    except preflight_module.PreflightError as err:
        typer.echo(f"preflight failed: {err.reason}", err=True)
        typer.echo(f"fix: {err.fix_command}", err=True)
        raise typer.Exit(code=2) from err


def _persist_repo_info(
    st: state_module.State,
    repo_info: preflight_module.RepoInfo,  # type: ignore[name-defined]
    state_path: Path,
) -> None:
    """Write repo_info into state and persist atomically.

    Warns when the existing state.repo disagrees with the fresh preflight
    result (e.g. the operator moved the remote), then overwrites.

    Args:
        st: Root state to mutate in place.
        repo_info: Fresh RepoInfo returned by run_preflight.
        state_path: Destination for the atomic state write.
    """
    if st.repo is not None and st.repo != repo_info:
        _logger.warning(
            "preflight: state.repo %s disagrees with fresh result %s; overwriting",
            st.repo.full,
            repo_info.full,
        )
    st.repo = repo_info
    state_module.save_state(state_path, st)


# ---------------------------------------------------------------------------
# Typer command
# ---------------------------------------------------------------------------


def generate_command(
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run/--no-dry-run", help="Print what would happen without doing it."),
    ] = False,
    phase: Annotated[
        int | None,
        typer.Option("--phase", help="Run only a specific phase number."),
    ] = None,
    continue_: Annotated[
        bool,
        typer.Option("--continue/--no-continue", help="Resume a paused generation run."),
    ] = False,
    mode: Annotated[
        str,
        typer.Option("--mode", help="Generation mode: auto, single, or multi-cycle."),
    ] = "auto",
    cycle: Annotated[
        int | None,
        typer.Option("--cycle", help="Target a specific cycle (multi-cycle mode only)."),
    ] = None,
    session_mode: Annotated[
        SessionMode | None,
        typer.Option(
            "--session-mode",
            help=(
                "SDK session strategy: 'shared' reuses one client per cycle, "
                "'fresh' creates a new client per issue. [default: shared]"
            ),
            show_default=False,
            case_sensitive=False,
        ),
    ] = None,
    max_turns: Annotated[
        int | None,
        typer.Option(
            "--max-turns",
            help=(
                "Opt-in per-session turn cap for debugging or strict cost control. "
                "Omit for the default (no cap). Must be a positive integer."
            ),
            callback=validate_max_turns,
            show_default=False,
        ),
    ] = None,
) -> None:
    """Run the full code-generation pipeline."""
    env.assert_safe_environment()
    env.assert_single_workspace()

    if phase is not None and continue_:
        typer.echo(
            "ERROR: --phase and --continue are mutually exclusive.",
            err=True,
        )
        raise typer.Exit(code=2)

    if cycle is not None and mode not in ("multi-cycle",) and not continue_:
        typer.echo(
            "ERROR: --cycle is only valid with --mode multi-cycle or --continue.",
            err=True,
        )
        raise typer.Exit(code=2)

    project_dir = Path.cwd()
    cg_dir = project_dir / ".code-generator"

    if not cg_dir.exists():
        typer.echo(
            "ERROR: .code-generator/ not found. Run `code-generator init` first.",
            err=True,
        )
        raise typer.Exit(code=1)

    state_path = cg_dir / "state.json"

    # Preflight: validate GitHub connectivity before any state load or dispatch.
    # PreflightError is translated to exit 2 with copy-pastable fix instructions.
    repo_info = _run_preflight(project_dir)

    st = state_module.load_state(state_path)

    # Persist the fresh RepoInfo atomically; warns when it differs from stored value.
    _persist_repo_info(st, repo_info, state_path)

    # Rate-limit pause guard: inform user and exit cleanly.
    if _check_paused(st):
        raise typer.Exit(code=0)

    # Compute current requirements hash (absent when file does not yet exist).
    req_path = cg_dir / "requirements.md"
    current_hash = state_module.compute_requirements_hash(req_path) if req_path.exists() else None

    effective_session_mode: Literal["shared", "fresh", "batch"] = (  # type: ignore[assignment]
        session_mode.value if session_mode is not None else "shared"
    )
    session_mode_explicit = session_mode is not None

    try:
        dispatch_orchestrator(
            st,
            project_dir,
            dry_run=dry_run,
            phase=phase,
            continue_=continue_,
            mode=mode,
            cycle=cycle,
            state_path=state_path,
            requirements_hash=current_hash,
            session_mode=effective_session_mode,
            session_mode_explicit=session_mode_explicit,
            max_turns=max_turns,
        )
    except typer.Exit:
        raise
    except NotImplementedError as exc:
        typer.echo(f"ERROR: {exc}", err=True)
        raise typer.Exit(code=1) from exc
    except Exception as exc:  # noqa: BLE001
        from rich.console import Console
        from rich.traceback import Traceback

        Console(stderr=True).print(Traceback())
        raise typer.Exit(code=1) from exc
