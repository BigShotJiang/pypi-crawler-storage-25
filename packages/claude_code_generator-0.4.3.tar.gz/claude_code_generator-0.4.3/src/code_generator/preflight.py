"""GitHub environment preflight validation.

Validates the local environment can talk to the target GitHub host
before any cycle starts. On failure raises :class:`PreflightError`
with a ready-to-paste fix command; on success returns a validated
:class:`~code_generator.repo_info.RepoInfo`.

Single responsibility: environment validation.
No state.json mutation — callers own that (see issue #156).

Checks performed in order
-------------------------
(a) ``git remote get-url origin`` succeeds.
(b) URL parses via :func:`~code_generator.repo_info.parse_remote_url`.
(c) ``gh auth status --hostname <host>`` exits 0.
(d) ``gh repo view <owner/repo> --hostname <host>`` exits 0.
(e) ``gh api repos/<owner/repo>/labels --hostname <host>`` exits 0.
"""

from __future__ import annotations

import logging
import subprocess
import sys
from typing import TYPE_CHECKING

from code_generator.repo_info import RepoInfo, parse_remote_url

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

logger = logging.getLogger(__name__)

# Injected by tests via ``patch("code_generator.preflight._IS_WINDOWS", True)``.
# Windows note: gh credentials integrate with Windows Credential Manager and
# may behave differently. Checks that fail on Windows log a WARNING and are
# skipped rather than aborting the run.
_IS_WINDOWS: bool = sys.platform == "win32"


# ---------------------------------------------------------------------------
# Public exception
# ---------------------------------------------------------------------------


class PreflightError(Exception):
    """Raised when a preflight check fails.

    Attributes:
        reason: Short human-readable description of the failure.
        fix_command: A copy-paste ready command to resolve the issue.
    """

    def __init__(self, *, reason: str, fix_command: str) -> None:
        self.reason = reason
        self.fix_command = fix_command
        super().__init__(reason)


# ---------------------------------------------------------------------------
# Subprocess seams (patch these in tests)
# ---------------------------------------------------------------------------


def _run_gh(args: list[str], *, hostname: str) -> subprocess.CompletedProcess:  # type: ignore[type-arg]
    """Execute a gh command appending ``--hostname`` and return CompletedProcess.

    Single seam for all gh subprocess calls — tests patch this one function.
    Never uses ``shell=True``.

    Args:
        args: Full argv including the ``gh`` binary.
        hostname: Value for the ``--hostname`` flag.

    Returns:
        CompletedProcess with returncode, stdout, and stderr populated.
    """
    return subprocess.run(
        [*args, "--hostname", hostname],
        capture_output=True,
        text=True,
        check=False,
    )


def _get_origin_url(project_dir: Path) -> str:
    """Return the git remote origin URL for *project_dir*.

    Args:
        project_dir: Root directory of the git project.

    Returns:
        Stripped remote URL string.

    Raises:
        PreflightError: When ``git remote get-url origin`` exits non-zero.
    """
    result = subprocess.run(
        ["git", "remote", "get-url", "origin"],
        cwd=project_dir,
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise PreflightError(
            reason="No 'origin' remote found in this git repository.",
            fix_command="git remote add origin <url>",
        )
    return result.stdout.strip()


# ---------------------------------------------------------------------------
# Individual checks (SRP: one check per function, each < 10 lines)
# ---------------------------------------------------------------------------


def _check_auth(repo_info: RepoInfo) -> None:
    """Verify gh is authenticated for the target host.

    Args:
        repo_info: Parsed repository information supplying the hostname.

    Raises:
        PreflightError: When ``gh auth status`` exits non-zero.
    """
    result = _run_gh(["gh", "auth", "status"], hostname=repo_info.host)
    if result.returncode != 0:
        raise PreflightError(
            reason=f"Not authenticated to {repo_info.host}.",
            fix_command=f"gh auth login --hostname {repo_info.host}",
        )


def _check_repo(repo_info: RepoInfo) -> None:
    """Verify gh can access the repository.

    ``gh repo view`` does not accept ``--hostname``; the host is passed as part
    of the positional argument (``HOST/OWNER/REPO`` for enterprise,
    ``OWNER/REPO`` for github.com).

    Args:
        repo_info: Parsed repository information.

    Raises:
        PreflightError: When ``gh repo view`` exits non-zero.
    """
    if repo_info.host == "github.com":
        target = repo_info.full
    else:
        target = f"{repo_info.host}/{repo_info.full}"
    result = subprocess.run(
        ["gh", "repo", "view", target],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise PreflightError(
            reason=f"Cannot access repository {repo_info.full} on {repo_info.host}.",
            fix_command=f"gh repo view {target}",
        )


def _check_labels(repo_info: RepoInfo) -> None:
    """Verify gh can access the labels API for the repository.

    Args:
        repo_info: Parsed repository information.

    Raises:
        PreflightError: When ``gh api repos/.../labels`` exits non-zero.
    """
    result = _run_gh(
        ["gh", "api", f"repos/{repo_info.full}/labels"],
        hostname=repo_info.host,
    )
    if result.returncode != 0:
        raise PreflightError(
            reason=f"Cannot access labels API for {repo_info.full} on {repo_info.host}.",
            fix_command=f"gh api repos/{repo_info.full}/labels --hostname {repo_info.host}",
        )


# ---------------------------------------------------------------------------
# Windows-safe check runner
# ---------------------------------------------------------------------------


def _run_check_windows_safe(
    check_fn: Callable[[RepoInfo], None],
    repo_info: RepoInfo,
    check_name: str,
) -> None:
    """Run a check, logging WARNING and skipping on Windows instead of raising.

    On non-Windows systems exceptions propagate normally.

    # Windows note: credential manager integration may cause gh to behave
    # differently on Windows. Rather than hard-failing, we log a WARNING so
    # the operator can validate manually.

    Args:
        check_fn: Function taking a RepoInfo that may raise PreflightError.
        repo_info: Repository info forwarded to the check.
        check_name: Human-readable name used in the warning message.
    """
    try:
        check_fn(repo_info)
    except PreflightError:
        if _IS_WINDOWS:
            logger.warning(
                "Preflight check '%s' skipped on Windows — validate manually.",
                check_name,
            )
        else:
            raise


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def run_preflight(project_dir: Path) -> RepoInfo:
    """Validate the local environment can talk to the target GitHub host.

    Performs five checks in order (a–e, see module docstring).
    Returns a validated :class:`RepoInfo` on success.

    Args:
        project_dir: Root directory of the git project being generated.

    Returns:
        Parsed and validated :class:`RepoInfo` for the ``origin`` remote.

    Raises:
        PreflightError: When any check fails on a non-Windows system.
            Carries ``reason`` and ``fix_command`` for operator display.
    """
    # (a) origin remote exists
    origin_url = _get_origin_url(project_dir)

    # (b) URL parses to a RepoInfo
    try:
        repo_info = parse_remote_url(origin_url)
    except ValueError as exc:
        raise PreflightError(
            reason=f"Cannot parse git remote URL: {origin_url!r}",
            fix_command="git remote set-url origin <valid-url>",
        ) from exc

    # (c–e) gh checks — Windows-safe
    _run_check_windows_safe(_check_auth, repo_info, "gh auth status")
    _run_check_windows_safe(_check_repo, repo_info, "gh repo view")
    _run_check_windows_safe(_check_labels, repo_info, "gh api labels")

    return repo_info
