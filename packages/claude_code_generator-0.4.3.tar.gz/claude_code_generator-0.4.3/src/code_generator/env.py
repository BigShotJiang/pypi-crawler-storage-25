"""Environment safety module.

Strips dangerous environment variables before any Claude Code invocation
to guarantee zero API credit usage (Max subscription only).

Non-negotiable constraint #1: no API keys must reach the Claude CLI.
Non-negotiable cache invariant: all SDK sessions must resolve to a single
workspace — see Cache workspace invariants section in CLAUDE.md.
Reference: ITAL-IA/kb/run-deep-research.py build_agent_env().
"""

import logging
import os
import sys
from collections.abc import Callable

_logger = logging.getLogger(__name__)

# Module-level state tracking the INFO-log guard for the deferred-probe path.
_WS_STATE: dict[str, object] = {"warned": False}

DANGEROUS_VARS: tuple[str, ...] = (
    "ANTHROPIC_API_KEY",
    "ANTHROPIC_AUTH_TOKEN",
    "ANTHROPIC_BEDROCK_API_KEY",
    "ANTHROPIC_VERTEX_PROJECT_ID",
    "CLAUDE_CODE_USE_BEDROCK",
    "CLAUDE_CODE_USE_VERTEX",
)


def strip_dangerous_env() -> None:
    """Remove every dangerous variable from the current process environment."""
    for var in DANGEROUS_VARS:
        os.environ.pop(var, None)


def build_agent_env() -> dict[str, str]:
    """Return a sanitized copy of the environment suitable for subprocess.run(env=...).

    The returned dict contains every variable except those in DANGEROUS_VARS.
    The calling process's os.environ is not mutated.
    """
    return {k: v for k, v in os.environ.items() if k not in DANGEROUS_VARS}


def detect_sdk_version() -> str | None:
    """Return the installed ``claude_agent_sdk`` version string, or ``None``.

    Returns ``None`` when the package is not importable (subprocess-only
    environments) or when the ``__version__`` attribute is absent.

    Returns:
        Version string (e.g. ``"0.1.59"``) or ``None``.
    """
    try:
        import claude_agent_sdk  # type: ignore[import-untyped]

        return str(claude_agent_sdk.__version__)
    except (ImportError, AttributeError):
        return None


class WorkspaceMismatchError(RuntimeError):
    """Raised when multiple workspace identities are detected in one cycle.

    Cache-reuse assumptions in §§1-2 of CLAUDE.md hold only within a single
    workspace. Mixing credentials that resolve to different workspaces silently
    destroys cache coherence without any observable error from the SDK.
    """


def _probe_workspace_identity() -> frozenset[str] | None:
    """Return workspace identities from the SDK, or None if the probe is absent.

    Returns:
        A frozenset of identity strings when the SDK exposes the probe, or
        None when the SDK does not expose a workspace identity API.
    """
    try:
        import claude_agent_sdk  # type: ignore[import-untyped]

        identities = claude_agent_sdk.get_workspace_identities()
        return frozenset(identities)
    except (ImportError, AttributeError):
        return None


def assert_single_workspace(
    *,
    probe: Callable[[], frozenset[str] | None] | None = None,
    _state: dict[str, object] | None = None,
) -> None:
    """Assert that the active credentials resolve to a single workspace.

    Logs a one-time INFO message when the SDK does not expose a workspace probe
    (the deferred-probe path blessed by §14). Raises WorkspaceMismatchError
    when the probe detects more than one workspace identity.

    Args:
        probe: Optional injectable probe callable, defaults to _probe_workspace_identity.
        _state: Optional mutable state dict for testing; defaults to _WS_STATE.

    Raises:
        WorkspaceMismatchError: When multiple workspace identities are detected.
    """
    state = _state if _state is not None else _WS_STATE
    resolver = probe if probe is not None else _probe_workspace_identity
    identities = resolver()

    if identities is None:
        _log_deferred_probe_once(state)
        return

    if len(identities) > 1:
        listed = ", ".join(sorted(identities))
        raise WorkspaceMismatchError(
            f"Multiple workspace identities detected: {listed}. "
            "All SDK sessions must use a single workspace. "
            "Ensure only one Anthropic API key / OAuth account is active for this invocation."
        )


def _log_deferred_probe_once(state: dict[str, object]) -> None:
    """Emit the deferred-probe INFO log at most once per invocation."""
    if not state["warned"]:
        _logger.info("single-workspace assertion deferred — SDK does not expose workspace probe")
        state["warned"] = True


def assert_safe_environment() -> None:
    """Strip dangerous env vars from the current process, warning about each.

    The process environment is mutated in place so every downstream SDK and
    subprocess call inherits a clean environment — matching the pattern from
    ITAL-IA/kb/run-deep-research.py build_agent_env(). The user does not need
    to unset these variables in their shell.
    """
    offenders = [var for var in DANGEROUS_VARS if var in os.environ]
    if not offenders:
        return

    listed = ", ".join(offenders)
    print(
        f"Using Max subscription (ignoring {listed} for this process).",
        file=sys.stderr,
    )
    strip_dangerous_env()
