"""code-generator: orchestrator CLI for end-to-end project generation."""

__version__ = "0.4.3"
