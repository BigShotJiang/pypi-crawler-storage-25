"""Entry-point CLI for code-generator.

Exposes a Typer application with --version and subcommands:
init, status, generate, review.
"""

from typing import Annotated

import typer

import code_generator
from code_generator.commands.bench import bench_app
from code_generator.commands.generate import generate_command
from code_generator.commands.init import init_command
from code_generator.commands.optimize import optimize_command
from code_generator.commands.review import review_command
from code_generator.commands.status import status_command

app = typer.Typer(
    name="code-generator",
    help="Orchestrate Claude Code to generate whole projects from a requirements.md.",
    no_args_is_help=True,
)


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"code-generator {code_generator.__version__}")
        raise typer.Exit()


@app.callback()
def root(
    version: Annotated[
        bool | None,
        typer.Option(
            "--version",
            "-V",
            help="Show version and exit.",
            callback=_version_callback,
            is_eager=True,
        ),
    ] = None,
) -> None:
    """code-generator CLI root."""


app.add_typer(bench_app, name="bench")
app.command(name="init")(init_command)
app.command(name="status")(status_command)
app.command(name="generate")(generate_command)
app.command(name="optimize")(optimize_command)
app.command(name="review")(review_command)
