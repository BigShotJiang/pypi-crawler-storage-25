"""CI guard: rendered prompt prefixes must match committed snapshot fixtures.

Every cacheable phase prompt has a committed `.txt` fixture under
``tests/fixtures/prompt_prefix_snapshots/`` containing exactly the first 2048
bytes of the rendered prompt.  This test re-renders each prompt and asserts
byte-for-byte equality, so any accidental edit to the stable prefix fails CI
before it silently degrades the Anthropic cache hit rate.

Intentional prefix changes require running the regeneration script::

    python -m tests.regenerate_prompt_snapshots

which rewrites all fixture files atomically.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from code_generator.prompts import PLACEHOLDER_SPEC, load_prompt

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_PREFIX_BYTES = 2048
_FIXTURE_DIR = Path(__file__).parent / "fixtures" / "prompt_prefix_snapshots"

# ``prompt-optimize-requirements.md`` is a stateless one-shot outside the cycle
# cache envelope — excluded from snapshot coverage.
_EXCLUDED = frozenset({"prompt-optimize-requirements.md"})

# All cacheable prompt filenames (8 files).
_CACHEABLE_PROMPTS = sorted(PLACEHOLDER_SPEC.keys() - _EXCLUDED)

# ---------------------------------------------------------------------------
# Neutral placeholder values used for snapshot generation and verification.
# Values are intentionally short and stable — they must NOT appear in the
# first 2048 bytes of any prompt (all placeholders live in ## Volatile Context
# which starts after byte 2048).
# ---------------------------------------------------------------------------
PLACEHOLDER_SNAPSHOT_FIXTURES: dict[str, str] = {
    "REQUIREMENTS_PATH": ".code-generator/requirements.md",
    "MILESTONE_TITLE": "Cycle N — Title",
    "CYCLE_SCOPE": "scope",
    "COMPLETED_CYCLES": "none",
    "EXISTING_ISSUES": "none",
    "REPO_MAP": "",
    "ISSUE_NUMBER": "0",
    "PRIMARY_AGENT": "python-pro",
    "ISSUE_COMMENTS": "",
    "SKILLS": "solid-principles",
    "OPEN_ISSUES_WITH_COMMENTS": "",
    "DIFF_SINCE_BASE": "",
    "LINT_ERRORS": "",
    "MAX_RETRIES": "3",
    "CYCLE_NAME": "Cycle N — Title",
    "ISSUES_CLOSED": "#0",
    "STAGED_DIFF_STAT": "",
    "STAGED_FILES": "",
    "CREATE_ISSUES": "true",
    "SEVERITY_FILTER": "high",
}


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------


def _render_with_neutral_placeholders(prompt_filename: str) -> bytes:
    """Render *prompt_filename* with neutral placeholder values and UTF-8 encode.

    Args:
        prompt_filename: One of the registered cacheable prompt filenames.

    Returns:
        The full rendered prompt as UTF-8 bytes.
    """
    spec = PLACEHOLDER_SPEC[prompt_filename]
    kwargs = {name: PLACEHOLDER_SNAPSHOT_FIXTURES[name] for name in spec}
    return load_prompt(prompt_filename, **kwargs).encode("utf-8")


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestPromptPrefixSnapshots:
    """Byte-for-byte CI guard against accidental prefix mutations."""

    @pytest.mark.parametrize("filename", _CACHEABLE_PROMPTS)
    def test_fixture_file_exists(self, filename: str) -> None:
        """Each cacheable prompt must have a committed fixture file."""
        fixture_path = _FIXTURE_DIR / filename.replace(".md", ".txt")
        assert fixture_path.exists(), (
            f"Missing snapshot fixture: {fixture_path}\n"
            f"Run `python -m tests.regenerate_prompt_snapshots` to generate it."
        )

    @pytest.mark.parametrize("filename", _CACHEABLE_PROMPTS)
    def test_fixture_is_exactly_2048_bytes(self, filename: str) -> None:
        """Each fixture file must be exactly 2048 bytes."""
        fixture_path = _FIXTURE_DIR / filename.replace(".md", ".txt")
        if not fixture_path.exists():
            pytest.skip(f"Fixture not found: {fixture_path}")
        size = fixture_path.stat().st_size
        assert size == _PREFIX_BYTES, (
            f"{filename}: fixture is {size} bytes, expected {_PREFIX_BYTES}.\n"
            f"Run `python -m tests.regenerate_prompt_snapshots` to regenerate."
        )

    @pytest.mark.parametrize("filename", _CACHEABLE_PROMPTS)
    def test_rendered_prefix_matches_fixture(self, filename: str) -> None:
        """Rendered prompt[:2048] must match the committed fixture byte-for-byte."""
        fixture_path = _FIXTURE_DIR / filename.replace(".md", ".txt")
        if not fixture_path.exists():
            pytest.skip(f"Fixture not found: {fixture_path}")

        fixture_bytes = fixture_path.read_bytes()
        rendered_prefix = _render_with_neutral_placeholders(filename)[:_PREFIX_BYTES]

        assert rendered_prefix == fixture_bytes, (
            f"{filename}: rendered prefix does not match committed snapshot.\n"
            f"  First differing byte: {_first_diff_byte(rendered_prefix, fixture_bytes)}\n"
            f"  This means the stable cache prefix changed. If intentional, run:\n"
            f"    python -m tests.regenerate_prompt_snapshots"
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _first_diff_byte(a: bytes, b: bytes) -> int:
    """Return the index of the first byte where *a* and *b* differ."""
    for i, (x, y) in enumerate(zip(a, b, strict=False)):
        if x != y:
            return i
    return min(len(a), len(b))
