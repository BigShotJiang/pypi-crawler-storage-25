"""Tests for code_generator.effort — effort-level policy engine."""

from __future__ import annotations

import pathlib
import re

import pytest

from code_generator.effort import EffortLevel, InvalidEffortInput, resolve_effort, validate_effort

# ---------------------------------------------------------------------------
# Phase baseline mapping
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("phase", "expected"),
    [
        (0, EffortLevel.XHIGH),
        (1, EffortLevel.XHIGH),
        (2, EffortLevel.XHIGH),
        (5, EffortLevel.XHIGH),
        (3, EffortLevel.MEDIUM),
        (4, EffortLevel.MEDIUM),
        (7, EffortLevel.LOW),
    ],
)
def test_baseline_mapping(phase: int, expected: EffortLevel) -> None:
    """Each phase maps to the correct baseline effort level."""
    result = resolve_effort(phase=phase, complexity="low", issue_labels=[], retry_count=0)
    assert result == expected


# ---------------------------------------------------------------------------
# Phase 3/4 complexity:high bump
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("phase", [3, 4])
def test_implement_phase_bumps_to_high_with_complexity_label(phase: int) -> None:
    """Phase 3/4 escalates from medium to high when complexity:high label present."""
    result = resolve_effort(
        phase=phase,
        complexity="low",
        issue_labels=["complexity:high", "area:api"],
        retry_count=0,
    )
    assert result == EffortLevel.HIGH


@pytest.mark.parametrize("phase", [3, 4])
def test_implement_phase_stays_medium_without_complexity_label(phase: int) -> None:
    """Phase 3/4 stays medium when complexity:high label is absent."""
    result = resolve_effort(
        phase=phase,
        complexity="low",
        issue_labels=["area:api", "priority:high"],
        retry_count=0,
    )
    assert result == EffortLevel.MEDIUM


@pytest.mark.parametrize("phase", [3, 4])
def test_implement_phase_stays_medium_with_empty_labels(phase: int) -> None:
    """Phase 3/4 stays medium with no labels at all."""
    result = resolve_effort(phase=phase, complexity="low", issue_labels=[], retry_count=0)
    assert result == EffortLevel.MEDIUM


# ---------------------------------------------------------------------------
# Phase 6 retry escalation
# ---------------------------------------------------------------------------


def test_phase6_attempt0_returns_low() -> None:
    """Phase 6 returns low effort on first attempt (retry_count=0)."""
    assert (
        resolve_effort(phase=6, complexity="low", issue_labels=[], retry_count=0) == EffortLevel.LOW
    )


def test_phase6_attempt1_returns_medium() -> None:
    """Phase 6 returns medium effort on second attempt (retry_count=1)."""
    assert (
        resolve_effort(phase=6, complexity="low", issue_labels=[], retry_count=1)
        == EffortLevel.MEDIUM
    )


@pytest.mark.parametrize("retry_count", [2, 3, 10])
def test_phase6_attempt2plus_returns_high(retry_count: int) -> None:
    """Phase 6 returns high effort on third attempt and beyond."""
    assert (
        resolve_effort(phase=6, complexity="low", issue_labels=[], retry_count=retry_count)
        == EffortLevel.HIGH
    )


# ---------------------------------------------------------------------------
# effort_hint override
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("phase", "hint"),
    [
        (0, EffortLevel.MAX),
        (1, EffortLevel.LOW),
        (6, EffortLevel.MAX),
        (3, EffortLevel.HIGH),
    ],
)
def test_effort_hint_overrides_baseline(phase: int, hint: EffortLevel) -> None:
    """effort_hint always overrides the baseline regardless of phase or labels."""
    result = resolve_effort(
        phase=phase,
        complexity="low",
        issue_labels=["complexity:high"],
        retry_count=0,
        effort_hint=hint,
    )
    assert result == hint


def test_effort_hint_none_does_not_override() -> None:
    """effort_hint=None leaves the baseline in effect."""
    result = resolve_effort(
        phase=0, complexity="low", issue_labels=[], retry_count=0, effort_hint=None
    )
    assert result == EffortLevel.XHIGH


# ---------------------------------------------------------------------------
# EffortLevel string values
# ---------------------------------------------------------------------------


def test_effort_level_string_values() -> None:
    """EffortLevel string values match the Anthropic API expectations."""
    assert EffortLevel.LOW == "low"
    assert EffortLevel.MEDIUM == "medium"
    assert EffortLevel.HIGH == "high"
    assert EffortLevel.XHIGH == "xhigh"
    assert EffortLevel.MAX == "max"


# ---------------------------------------------------------------------------
# Unknown phase falls back gracefully
# ---------------------------------------------------------------------------


def test_unknown_phase_returns_none() -> None:
    """An unknown phase number returns None (use model default)."""
    result = resolve_effort(phase=99, complexity="low", issue_labels=[], retry_count=0)
    assert result is None


# ---------------------------------------------------------------------------
# validate_effort — max effort gated to Opus-only
# ---------------------------------------------------------------------------


def test_validate_effort_max_with_opus_passes() -> None:
    """max effort is allowed for claude-opus-4-7."""
    validate_effort("max", "claude-opus-4-7")  # must not raise


def test_validate_effort_xhigh_with_opus_passes() -> None:
    """xhigh effort is allowed for claude-opus-4-7 (introduced in 4.7)."""
    validate_effort("xhigh", "claude-opus-4-7")  # must not raise


@pytest.mark.parametrize("model", ["claude-sonnet-4-6", "claude-haiku-4-5"])
def test_validate_effort_max_with_non_opus_raises(model: str) -> None:
    """max effort raises ValueError for Sonnet and Haiku models."""
    with pytest.raises(ValueError, match="max"):
        validate_effort("max", model)


@pytest.mark.parametrize("model", ["claude-sonnet-4-6", "claude-haiku-4-5"])
def test_validate_effort_xhigh_with_non_opus_raises(model: str) -> None:
    """xhigh effort raises ValueError for Sonnet and Haiku models."""
    with pytest.raises(ValueError, match="xhigh"):
        validate_effort("xhigh", model)


@pytest.mark.parametrize(
    ("effort", "model"),
    [
        ("medium", "claude-sonnet-4-6"),
        ("high", "claude-sonnet-4-6"),
        ("low", "claude-haiku-4-5"),
        ("medium", "claude-opus-4-7"),
    ],
)
def test_validate_effort_non_max_always_passes(effort: str, model: str) -> None:
    """Any effort level other than max passes for any model."""
    validate_effort(effort, model)  # must not raise


@pytest.mark.parametrize("model", ["claude-opus-4-7", "claude-sonnet-4-6", "claude-haiku-4-5"])
def test_validate_effort_none_always_passes(model: str) -> None:
    """effort=None passes for any model (no-op)."""
    validate_effort(None, model)  # must not raise


# ---------------------------------------------------------------------------
# InvalidEffortInput guard — empty complexity in phases that depend on Phase 0
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("phase", [3, 4, 7])
def test_empty_complexity_raises_for_dependent_phases(phase: int) -> None:
    """resolve_effort raises InvalidEffortInput when complexity is empty, no hint, and
    phase is in {3, 4, 7} — these phases depend on Phase 0's complexity output."""
    with pytest.raises(InvalidEffortInput, match="complexity"):
        resolve_effort(phase=phase, complexity="", issue_labels=[], retry_count=0)


@pytest.mark.parametrize("phase", [0, 1, 2, 5, 6])
def test_empty_complexity_does_not_raise_for_independent_phases(phase: int) -> None:
    """resolve_effort does NOT raise for phases 0, 1, 2, 5, 6 even with empty complexity —
    these phases do not use Phase 0's complexity output."""
    resolve_effort(phase=phase, complexity="", issue_labels=[], retry_count=0)  # must not raise


@pytest.mark.parametrize("phase", [3, 4, 7])
def test_empty_complexity_with_retry_does_not_raise(phase: int) -> None:
    """resolve_effort does NOT raise when retry_count >= 1 — retries are allowed to proceed
    with the prior effort level, regardless of complexity."""
    resolve_effort(phase=phase, complexity="", issue_labels=[], retry_count=1)  # must not raise


@pytest.mark.parametrize("phase", [3, 4, 7])
def test_non_empty_complexity_does_not_raise(phase: int) -> None:
    """resolve_effort does NOT raise when complexity is a valid non-empty string."""
    resolve_effort(
        phase=phase, complexity="medium", issue_labels=[], retry_count=0
    )  # must not raise


@pytest.mark.parametrize("phase", [3, 4, 7])
def test_effort_hint_bypasses_empty_complexity_guard(phase: int) -> None:
    """resolve_effort does NOT raise when effort_hint is set — hint overrides everything,
    including the empty-complexity guard."""
    resolve_effort(
        phase=phase,
        complexity="",
        issue_labels=[],
        retry_count=0,
        effort_hint=EffortLevel.HIGH,
    )  # must not raise


# ---------------------------------------------------------------------------
# Codebase-wide invariant: every log line with model= must also have effort=
# ---------------------------------------------------------------------------

_LOG_CALL_RE = re.compile(r"\b(logger|_LOG)\.(info|warning|error|debug|critical)\(")
_SRC_ROOT = pathlib.Path(__file__).parent.parent / "src" / "code_generator"


def test_no_bare_model_log_lines() -> None:
    """Every log call in src/code_generator/ that contains 'model=' must also contain 'effort='.

    This is a regression guard for the invariant established in #103 and #104:
    any log line that exposes the model name must also expose the effort level
    so operators have full context when reading logs.
    """
    violations: list[str] = []

    for py_file in sorted(_SRC_ROOT.rglob("*.py")):
        source = py_file.read_text(encoding="utf-8")
        for lineno, line in enumerate(source.splitlines(), start=1):
            if not _LOG_CALL_RE.search(line):
                continue
            if "model=" not in line:
                continue
            if "effort=" not in line:
                rel = py_file.relative_to(_SRC_ROOT.parent.parent)
                violations.append(f"{rel}:{lineno}: {line.strip()}")

    assert violations == [], (
        "Found log lines with 'model=' but without 'effort=' — fix them or add effort= "
        "so operators have full context:\n" + "\n".join(violations)
    )
