"""Tests for prompt prefix stability.

First 2048 bytes of each phase prompt must be byte-identical across renders
that vary only the volatile placeholder values. This ensures Anthropic's
prompt cache can reuse the prefix across same-phase sessions.
"""

from __future__ import annotations

import pytest

from code_generator.prompts import load_prompt

# Byte length that must remain stable (Anthropic cache granularity)
_PREFIX_BYTES = 2048

# ---------------------------------------------------------------------------
# Fixture sets — three renders per prompt, each varying ALL volatile placeholders.
# ---------------------------------------------------------------------------
_FIXTURES: dict[str, list[dict[str, str]]] = {
    "prompt-phase-0-complexity.md": [
        {"REPO_MAP": ""},
        {"REPO_MAP": "src/app.py::MyClass\n"},
        {"REPO_MAP": "src/api.py::Router\nsrc/models.py::User\n"},
    ],
    "prompt-phase-1-planning.md": [
        {
            "REQUIREMENTS_PATH": "/project/a/requirements.md",
            "CYCLE_SCOPE": "database layer",
            "MILESTONE_TITLE": "Cycle 1 — Database",
            "COMPLETED_CYCLES": "none",
            "EXISTING_ISSUES": "none",
            "REPO_MAP": "",
        },
        {
            "REQUIREMENTS_PATH": "/project/b/other-req.md",
            "CYCLE_SCOPE": "API layer with authentication",
            "MILESTONE_TITLE": "Cycle 2 — API",
            "COMPLETED_CYCLES": "Cycle 1 — Database (commit abc123)",
            "EXISTING_ISSUES": "- #1: feat: create user schema\n- #2: feat: add migrations",
            "REPO_MAP": "src/app.py::MyClass\n",
        },
        {
            "REQUIREMENTS_PATH": "/very/long/path/to/requirements.md",
            "CYCLE_SCOPE": "frontend components, routing, signals",
            "MILESTONE_TITLE": "Cycle 3 — Frontend",
            "COMPLETED_CYCLES": "Cycle 1 — Database\nCycle 2 — API",
            "EXISTING_ISSUES": (
                "- #1: feat: create user schema\n"
                "- #2: feat: add migrations\n"
                "- #3: feat: add JWT auth"
            ),
            "REPO_MAP": "src/api.py::Router\nsrc/models.py::User\n",
        },
    ],
    "prompt-phase-2-issue-review.md": [
        {
            "ISSUE_NUMBER": "1",
            "PRIMARY_AGENT": "python-pro",
            "ISSUE_COMMENTS": "",
            "REPO_MAP": "",
        },
        {
            "ISSUE_NUMBER": "42",
            "PRIMARY_AGENT": "fastapi-expert-agent",
            "ISSUE_COMMENTS": (
                "## Pre-fetched Issue Comments\n\n**alice** (2024-01-01T00:00:00Z):\n> Review OK"
            ),
            "REPO_MAP": "src/app.py::MyClass\n",
        },
        {
            "ISSUE_NUMBER": "999",
            "PRIMARY_AGENT": "frontend-developer",
            "ISSUE_COMMENTS": (
                "## Pre-fetched Issue Comments\n\n"
                "**bob** (2024-06-15T10:30:00Z):\n> REVIEW: this issue is too large\n\n"
                "**carol** (2024-06-15T11:00:00Z):\n> Splitting into three sub-tasks as suggested."
            ),
            "REPO_MAP": "src/api.py::Router\nsrc/models.py::User\n",
        },
    ],
    "prompt-phase-3-implementation.md": [
        {
            "ISSUE_NUMBER": "7",
            "PRIMARY_AGENT": "python-pro",
            "SKILLS": "solid-principles,python-expert",
            "ISSUE_COMMENTS": "",
        },
        {
            "ISSUE_NUMBER": "100",
            "PRIMARY_AGENT": "fastapi-expert-agent",
            "SKILLS": "solid-principles",
            "ISSUE_COMMENTS": (
                "## Pre-fetched Issue Comments\n\n"
                "**reviewer** (2024-03-01T12:00:00Z):\n> Review OK: clear and testable."
            ),
        },
        {
            "ISSUE_NUMBER": "255",
            "PRIMARY_AGENT": "nestjs-expert",
            "SKILLS": "solid-principles,python-expert,skfolio",
            "ISSUE_COMMENTS": (
                "## Pre-fetched Issue Comments\n\n"
                "**alice** (2024-04-01T08:00:00Z):\n> First comment\n\n"
                "**bob** (2024-04-01T09:00:00Z):\n> Second comment with\n> multi-line\n> content"
            ),
        },
    ],
    "prompt-phase-5-final-review.md": [
        {
            "CYCLE_SCOPE": "the entire project",
            "MILESTONE_TITLE": "Cycle 1",
            "OPEN_ISSUES_WITH_COMMENTS": "none",
            "DIFF_SINCE_BASE": "",
            "LINT_ERRORS": "",
        },
        {
            "CYCLE_SCOPE": "database and API layers",
            "MILESTONE_TITLE": "Cycle 2 — API",
            "OPEN_ISSUES_WITH_COMMENTS": "### Issue #5: feat: add JWT auth\nComments: none",
            "DIFF_SINCE_BASE": "diff --git a/src/api.py b/src/api.py\n+++ new line",
            "LINT_ERRORS": "src/api.py:10:1 E501 line too long",
        },
        {
            "CYCLE_SCOPE": "frontend components",
            "MILESTONE_TITLE": "Cycle 3 — Frontend",
            "OPEN_ISSUES_WITH_COMMENTS": (
                "### Issue #10: feat: create login form\n"
                "Comments: Review OK\n\n"
                "### Issue #11: feat: add routing\n"
                "Comments: none"
            ),
            "DIFF_SINCE_BASE": (
                "diff --git a/src/app/login.component.ts b/src/app/login.component.ts\n"
            )
            * 30,
            "LINT_ERRORS": "",
        },
    ],
    "prompt-phase-6-test.md": [
        {"MAX_RETRIES": "1"},
        {"MAX_RETRIES": "3"},
        {"MAX_RETRIES": "10"},
    ],
    "prompt-phase-7-commit.md": [
        {
            "CYCLE_NAME": "Cycle 1 — Foundation",
            "ISSUES_CLOSED": "#1, #2, #3",
            "STAGED_DIFF_STAT": "src/foo.py | 5 +++++\n1 file changed",
            "STAGED_FILES": "src/foo.py",
        },
        {
            "CYCLE_NAME": "Cycle 2 — API Layer",
            "ISSUES_CLOSED": "#4, #5, #6, #7, #8, #9",
            "STAGED_DIFF_STAT": (
                "src/api/routes.py | 120 +++++++++++++++\n"
                "tests/test_routes.py | 80 +++++++++\n"
                "2 files changed"
            ),
            "STAGED_FILES": "src/api/routes.py\ntests/test_routes.py",
        },
        {
            "CYCLE_NAME": "Cycle 3 — Frontend",
            "ISSUES_CLOSED": "#10, #11",
            "STAGED_DIFF_STAT": "frontend/src/app/app.component.ts | 200 " + "+" * 200,
            "STAGED_FILES": ("frontend/src/app/app.component.ts\nfrontend/src/app/app.module.ts"),
        },
    ],
    "prompt-review.md": [
        {"CREATE_ISSUES": "false", "SEVERITY_FILTER": "low"},
        {"CREATE_ISSUES": "true", "SEVERITY_FILTER": "medium"},
        {"CREATE_ISSUES": "false", "SEVERITY_FILTER": "critical"},
    ],
}

_ALL_PROMPTS = sorted(_FIXTURES.keys())


class TestPromptPrefixStability:
    """First 2048 rendered bytes must be byte-identical across volatile-varied renders."""

    @pytest.mark.parametrize("filename", _ALL_PROMPTS)
    def test_first_2048_bytes_identical_across_three_renders(self, filename: str) -> None:
        """Rendered prefix[0:2048] must be the same for all three fixture sets."""
        fixtures = _FIXTURES[filename]
        prefixes = [load_prompt(filename, **f).encode("utf-8")[:_PREFIX_BYTES] for f in fixtures]
        assert prefixes[0] == prefixes[1], (
            f"{filename}: prefix differs between fixture[0] and fixture[1]\n"
            f"  first diff at byte {_first_diff_byte(prefixes[0], prefixes[1])}"
        )
        assert prefixes[1] == prefixes[2], (
            f"{filename}: prefix differs between fixture[1] and fixture[2]\n"
            f"  first diff at byte {_first_diff_byte(prefixes[1], prefixes[2])}"
        )

    @pytest.mark.parametrize("filename", _ALL_PROMPTS)
    def test_rendered_output_is_at_least_2048_bytes(self, filename: str) -> None:
        """Rendered prompt must be at least 2048 bytes so the stable prefix is non-trivial."""
        rendered = load_prompt(filename, **_FIXTURES[filename][0])
        byte_len = len(rendered.encode("utf-8"))
        assert byte_len >= _PREFIX_BYTES, (
            f"{filename}: rendered length {byte_len} < {_PREFIX_BYTES} bytes"
        )

    @pytest.mark.parametrize("filename", _ALL_PROMPTS)
    def test_volatile_context_section_present(self, filename: str) -> None:
        """Every prompt must contain a '## Volatile Context' section."""
        rendered = load_prompt(filename, **_FIXTURES[filename][0])
        assert "## Volatile Context" in rendered, (
            f"{filename}: '## Volatile Context' section not found in rendered output"
        )

    @pytest.mark.parametrize("filename", _ALL_PROMPTS)
    def test_volatile_context_section_is_at_the_end(self, filename: str) -> None:
        """The '## Volatile Context' *section* (last occurrence) must appear after byte 2048.

        Prompts may reference '## Volatile Context' inline in their instructions;
        the test uses rfind() to locate the actual trailing section heading.
        """
        rendered = load_prompt(filename, **_FIXTURES[filename][0])
        encoded = rendered.encode("utf-8")
        volatile_pos = encoded.rfind(b"## Volatile Context")
        assert volatile_pos >= _PREFIX_BYTES, (
            f"{filename}: '## Volatile Context' section starts at byte {volatile_pos}, "
            f"which is before the {_PREFIX_BYTES}-byte boundary"
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _first_diff_byte(a: bytes, b: bytes) -> int:
    """Return the index of the first byte where *a* and *b* differ."""
    for i, (x, y) in enumerate(zip(a, b, strict=False)):
        if x != y:
            return i
    return min(len(a), len(b))
