"""Tests for code_generator.orchestrator.phase2_review."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import pytest

from code_generator import state as _state
from code_generator.orchestrator import phase2_review
from code_generator.runner.retry import CircuitOpen
from code_generator.runner.sdk_runner import RunResult
from code_generator.runner.soft_reset import SoftResetResult
from code_generator.runner.types import TokenUsage

_DUMMY_RESET = SoftResetResult(boundary_prefix="", context_management={})

if TYPE_CHECKING:
    from pathlib import Path

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_run_result(text: str = "") -> RunResult:
    return RunResult(text=text, session_id=None, tokens_in=None, tokens_out=None)


def _make_state_with_issues(tmp_path: Path, numbers: list[int]) -> _state.State:
    from code_generator.repo_info import RepoInfo

    state_dir = tmp_path / ".code-generator"
    state_dir.mkdir(parents=True, exist_ok=True)
    st = _state.load_state(state_dir / "missing.json")
    st.repo = RepoInfo(host="github.com", owner="test-owner", name="test-repo")
    st.issues = [_state.IssueState(number=n, status="open", agent="python-pro") for n in numbers]
    _state.save_state(state_dir / "state.json", st)
    return st


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestPhase2Run:
    @pytest.mark.asyncio
    async def test_reviews_all_open_issues(self, tmp_path: Path) -> None:
        state = _make_state_with_issues(tmp_path, [1, 2, 3])
        call_count = 0

        async def fake_with_backoff(factory, *, breaker, **kw):
            nonlocal call_count
            call_count += 1
            await factory()

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert call_count == 3

    @pytest.mark.asyncio
    async def test_skips_closed_issues(self, tmp_path: Path) -> None:
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        st.issues = [
            _state.IssueState(number=1, status="closed", agent="python-pro"),
            _state.IssueState(number=2, status="open", agent="python-pro"),
        ]
        _state.save_state(state_dir / "state.json", st)

        call_count = 0

        async def fake_with_backoff(factory, *, breaker, **kw):
            nonlocal call_count
            call_count += 1
            await factory()

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                st,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert call_count == 1  # Only issue #2.

    @pytest.mark.asyncio
    async def test_circuit_open_adds_label_and_continues(self, tmp_path: Path) -> None:
        state = _make_state_with_issues(tmp_path, [1, 2])

        call_count = 0

        async def fake_with_backoff(factory, *, breaker, **kw):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise CircuitOpen("opened")
            await factory()

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        from code_generator.repo_info import RepoInfo

        state.repo = RepoInfo(host="github.com", owner="acme", name="proj")

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "add_label") as mock_add_label,
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        mock_add_label.assert_called_once_with(state.repo, 1, "needs-manual-review")
        assert call_count == 2  # Both issues attempted.

    @pytest.mark.asyncio
    async def test_uses_cycle_issues_in_multi_cycle(self, tmp_path: Path) -> None:
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        cycle = _state.CycleState(
            id=1,
            name="DB",
            milestone_number=1,
            milestone_title="M",
            status="open",
            phase=1,
            issues=[_state.IssueState(number=99, status="open", agent="python-pro")],
            commit_sha=None,
        )
        _state.save_state(state_dir / "state.json", st)

        reviewed = []

        async def fake_with_backoff(factory, *, breaker, **kw):
            await factory()

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            reviewed.append(prompt)
            return _make_run_result()

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                st,
                cycle,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(reviewed) == 1
        assert "99" in reviewed[0]

    @pytest.mark.asyncio
    async def test_options_use_opus_model(self, tmp_path: Path) -> None:
        state = _make_state_with_issues(tmp_path, [1])
        captured_options = []

        async def fake_with_backoff(factory, *, breaker, **kw):
            await factory()

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result()

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert captured_options[0].model == "claude-opus-4-7"

    @pytest.mark.asyncio
    async def test_add_label_gh_error_is_swallowed(self, tmp_path: Path) -> None:
        """GhError when adding needs-manual-review is logged but not raised."""
        from code_generator.gh import GhError

        state = _make_state_with_issues(tmp_path, [1])

        async def fake_with_backoff(factory, *, breaker, **kw):
            raise CircuitOpen("opened")

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "add_label", side_effect=GhError(1, "not found")),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            # Should not raise.
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

    @pytest.mark.asyncio
    async def test_comments_injected_into_prompt_when_present(self, tmp_path: Path) -> None:
        """When view_issue returns comments, the prompt must contain '## Pre-fetched Issue Comments'."""
        state = _make_state_with_issues(tmp_path, [1])
        captured_prompts: list[str] = []

        async def fake_with_backoff(factory, *, breaker, **kw):
            await factory()

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result()

        fake_issue_data = {
            "comments": [
                {
                    "author": {"login": "alice"},
                    "createdAt": "2026-01-01T00:00:00Z",
                    "body": "Nice comment",
                }
            ]
        }

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value=fake_issue_data),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_prompts) == 1
        assert "## Pre-fetched Issue Comments" in captured_prompts[0]
        assert "Nice comment" in captured_prompts[0]

    @pytest.mark.asyncio
    async def test_no_comments_does_not_inject_header(self, tmp_path: Path) -> None:
        """When view_issue returns no comments, prompt must not contain '## Pre-fetched Issue Comments'."""
        state = _make_state_with_issues(tmp_path, [1])
        captured_prompts: list[str] = []

        async def fake_with_backoff(factory, *, breaker, **kw):
            await factory()

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result()

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_prompts) == 1
        assert "## Pre-fetched Issue Comments" not in captured_prompts[0]

    @pytest.mark.asyncio
    async def test_gh_error_on_view_issue_falls_back_to_empty_comments(
        self, tmp_path: Path
    ) -> None:
        """GhError from view_issue is swallowed; prompt is built with empty comments."""
        from code_generator.gh import GhError

        state = _make_state_with_issues(tmp_path, [1])
        captured_prompts: list[str] = []

        async def fake_with_backoff(factory, *, breaker, **kw):
            await factory()

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_prompts.append(prompt)
            return _make_run_result()

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "view_issue", side_effect=GhError(1, "not found")),
        ):
            # Must not raise — GhError is swallowed with a warning.
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_prompts) == 1
        assert "## Pre-fetched Issue Comments" not in captured_prompts[0]

    @pytest.mark.asyncio
    async def test_each_issue_gets_fresh_circuit_breaker(self, tmp_path: Path) -> None:
        """Each issue must receive its own CircuitBreaker instance.

        Regression guard: moving ``breaker = CircuitBreaker(...)`` outside the
        ``for`` loop would share a single instance across all issues, leaking
        failure counts between them.  This test catches that regression by
        asserting that all captured breaker objects have distinct identities.
        """
        state = _make_state_with_issues(tmp_path, [1, 2, 3])
        captured_breakers: list[object] = []

        async def fake_with_backoff(factory, *, breaker, **kw):
            captured_breakers.append(breaker)
            await factory()

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_breakers) == 3, "Expected one breaker per issue"
        # All three breakers must be distinct objects — no shared instance.
        assert captured_breakers[0] is not captured_breakers[1]
        assert captured_breakers[1] is not captured_breakers[2]
        assert captured_breakers[0] is not captured_breakers[2]


class TestPhase2TokenAccumulation:
    """AC 11: Phase 2 logs per-issue and phase-complete token lines; persists totals."""

    @pytest.mark.asyncio
    async def test_three_issues_emit_per_issue_and_phase_complete_lines_with_correct_totals(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """3 open issues → 3 per-issue token lines + 1 phase-complete line; totals sum correctly."""
        state = _make_state_with_issues(tmp_path, [1, 2, 3])
        issue_usages = [
            TokenUsage(input=100, output=10, cache_read=50, cache_write=5),
            TokenUsage(input=200, output=20, cache_read=60, cache_write=6),
            TokenUsage(input=300, output=30, cache_read=70, cache_write=7),
        ]
        call_idx = 0

        async def fake_with_backoff(factory, *, breaker, **kw):
            return await factory()

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            nonlocal call_idx
            result = RunResult(text="", session_id=None, usage=issue_usages[call_idx])
            call_idx += 1
            return result

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
            caplog.at_level(logging.INFO),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        per_issue_msgs = [m for m in caplog.messages if "tokens: in=" in m]
        assert len(per_issue_msgs) == 3, f"Expected 3 per-issue lines, got: {per_issue_msgs}"

        complete_msgs = [m for m in caplog.messages if "2 complete:" in m]
        assert len(complete_msgs) == 1, f"Expected 1 phase-complete line, got: {complete_msgs}"

        expected_total = TokenUsage(input=600, output=60, cache_read=180, cache_write=18)
        assert state.token_usage.get("phase2") == expected_total

    @pytest.mark.asyncio
    async def test_zero_open_issues_emits_phase_complete_with_zero_totals(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """Zero open issues → no per-issue lines; phase-complete line emitted with zeros."""
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        st.issues = [_state.IssueState(number=1, status="closed", agent="python-pro")]
        _state.save_state(state_dir / "state.json", st)

        async def fake_with_backoff(factory, *, breaker, **kw):
            return await factory()

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return RunResult(text="", session_id=None, usage=TokenUsage())

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
            caplog.at_level(logging.INFO),
        ):
            await phase2_review.run(
                st,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        per_issue_msgs = [m for m in caplog.messages if "tokens: in=" in m]
        assert len(per_issue_msgs) == 0

        complete_msgs = [m for m in caplog.messages if "2 complete:" in m]
        assert len(complete_msgs) == 1

        assert st.token_usage.get("phase2") == TokenUsage()

    @pytest.mark.asyncio
    async def test_cycle_token_usage_persisted_in_multi_cycle(self, tmp_path: Path) -> None:
        """In multi-cycle mode, phase2 token_usage persists to cycle.token_usage, not state."""
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        cycle = _state.CycleState(
            id=1,
            name="DB",
            milestone_number=1,
            milestone_title="M",
            status="open",
            phase=1,
            issues=[_state.IssueState(number=5, status="open", agent="python-pro")],
            commit_sha=None,
        )
        _state.save_state(state_dir / "state.json", st)
        issue_usage = TokenUsage(input=50, output=5, cache_read=10, cache_write=1)

        async def fake_with_backoff(factory, *, breaker, **kw):
            return await factory()

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return RunResult(text="", session_id=None, usage=issue_usage)

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                st,
                cycle,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert cycle.token_usage.get("phase2") == issue_usage
        assert "phase2" not in st.token_usage

    @pytest.mark.asyncio
    async def test_skips_already_reviewed_issues(self, tmp_path: Path) -> None:
        """Issues with reviewed=True from a prior --continue run must be skipped."""
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        st.issues = [
            _state.IssueState(number=1, status="open", agent="python-pro", reviewed=True),
            _state.IssueState(number=2, status="open", agent="python-pro", reviewed=False),
            _state.IssueState(number=3, status="open", agent="python-pro", reviewed=True),
        ]
        _state.save_state(state_dir / "state.json", st)

        reviewed_numbers: list[int] = []

        async def fake_with_backoff(factory, *, breaker, **kw):
            await factory()

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
            patch.object(phase2_review, "load_prompt", side_effect=lambda *a, **k: "prompt"),
            patch(
                "code_generator.orchestrator.phase2_review.fetch_formatted_comments",
                side_effect=lambda repo, n, logger: reviewed_numbers.append(n) or "",
            ),
        ):
            await phase2_review.run(
                st,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        # Only issue #2 is actually reviewed; #1 and #3 are skipped.
        assert reviewed_numbers == [2]
        # Issue #2 is now marked reviewed; #1 and #3 stay reviewed.
        assert all(i.reviewed for i in st.issues)

    @pytest.mark.asyncio
    async def test_successful_review_persists_reviewed_flag(self, tmp_path: Path) -> None:
        """A successful Phase 2 review must persist reviewed=True to state.json."""
        state = _make_state_with_issues(tmp_path, [42])
        state_path = tmp_path / ".code-generator" / "state.json"

        async def fake_with_backoff(factory, *, breaker, **kw):
            await factory()

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        # Reloaded state must show reviewed=True so a subsequent --continue skips it.
        reloaded = _state.load_state(state_path)
        assert reloaded.issues[0].reviewed is True


# ---------------------------------------------------------------------------
# MCP wiring tests (issue #177)
# ---------------------------------------------------------------------------


class TestPhase2McpWiring:
    """Phase 2 must wire build_mcp_servers into make_agent_options (issue #177)."""

    _FAKE_MCP_SERVERS = {"codebase_memory": {"type": "stdio", "command": "/bin/cm"}}

    @pytest.mark.asyncio
    async def test_mcp_servers_in_options_when_build_returns_dict(self, tmp_path: Path) -> None:
        """When build_mcp_servers returns a dict, options.mcp_servers equals that dict
        and allowed_tools contains the mcp__codebase_memory__* wildcard entry."""
        state = _make_state_with_issues(tmp_path, [1])
        captured_options: list = []

        async def fake_with_backoff(factory, *, breaker, **kw):
            await factory()

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result()

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
            patch(
                "code_generator.orchestrator.phase2_review.build_mcp_servers",
                return_value=self._FAKE_MCP_SERVERS,
            ),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_options) == 1
        opts = captured_options[0]
        assert opts.mcp_servers == self._FAKE_MCP_SERVERS
        assert "mcp__codebase_memory__*" in opts.allowed_tools

    @pytest.mark.asyncio
    async def test_mcp_servers_none_when_build_returns_none(self, tmp_path: Path) -> None:
        """When build_mcp_servers returns None, options.mcp_servers is None and
        allowed_tools matches the pre-MCP baseline (no mcp__ entries)."""
        state = _make_state_with_issues(tmp_path, [1])
        captured_options: list = []

        async def fake_with_backoff(factory, *, breaker, **kw):
            await factory()

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            captured_options.append(options)
            return _make_run_result()

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
            patch(
                "code_generator.orchestrator.phase2_review.build_mcp_servers",
                return_value=None,
            ),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        assert len(captured_options) == 1
        opts = captured_options[0]
        assert opts.mcp_servers is None
        assert not any("mcp__" in t for t in opts.allowed_tools)

    @pytest.mark.asyncio
    async def test_build_mcp_servers_called_once_per_phase_run(self, tmp_path: Path) -> None:
        """build_mcp_servers must be called exactly once per phase run, not once per issue."""
        state = _make_state_with_issues(tmp_path, [1, 2, 3])

        async def fake_with_backoff(factory, *, breaker, **kw):
            await factory()

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
            patch(
                "code_generator.orchestrator.phase2_review.build_mcp_servers",
                return_value=None,
            ) as mock_build,
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        mock_build.assert_called_once_with(tmp_path)


# ---------------------------------------------------------------------------
# Comment caching tests (issue #179)
# ---------------------------------------------------------------------------


class TestPhase2CommentCaching:
    """Phase 2 must cache formatted comments in IssueState.comments after review (§9)."""

    @pytest.mark.asyncio
    async def test_fresh_issue_fetches_comments_and_persists_result(self, tmp_path: Path) -> None:
        """When issue.comments is None, fetch_formatted_comments is called and result persisted."""
        state = _make_state_with_issues(tmp_path, [1])
        state_path = tmp_path / ".code-generator" / "state.json"
        formatted = "## Pre-fetched Issue Comments\n\n**alice**: hello"

        async def fake_with_backoff(factory, *, breaker, **kw):
            await factory()

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch(
                "code_generator.orchestrator.phase2_review.fetch_formatted_comments",
                return_value=formatted,
            ) as mock_fetch,
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        # fetch was called exactly once for the fresh issue
        mock_fetch.assert_called_once()
        # the cached value is stored in the in-memory issue object
        assert state.issues[0].comments == formatted
        # and persisted to state.json
        reloaded = _state.load_state(state_path)
        assert reloaded.issues[0].comments == formatted

    @pytest.mark.asyncio
    async def test_cached_issue_skips_fetch(self, tmp_path: Path) -> None:
        """When issue.comments is already set, fetch_formatted_comments is NOT called."""
        state_dir = tmp_path / ".code-generator"
        state_dir.mkdir(parents=True, exist_ok=True)
        st = _state.load_state(state_dir / "missing.json")
        cached = "## Pre-fetched Issue Comments\n\n**bob**: already cached"
        st.issues = [
            _state.IssueState(number=1, status="open", agent="python-pro", comments=cached)
        ]
        _state.save_state(state_dir / "state.json", st)

        async def fake_with_backoff(factory, *, breaker, **kw):
            await factory()

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch(
                "code_generator.orchestrator.phase2_review.fetch_formatted_comments",
            ) as mock_fetch,
        ):
            await phase2_review.run(
                st,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
            )

        # fetch must NOT be called when comments are already cached
        mock_fetch.assert_not_called()
        # the cached value is unchanged
        assert st.issues[0].comments == cached


# ---------------------------------------------------------------------------
# Shared-client wiring tests (issue #183)
# ---------------------------------------------------------------------------


class TestPhase2SharedClient:
    """Phase 2 must route through run_with_shared_client + soft_reset_context
    when shared_client is provided (§183 acceptance criteria)."""

    @staticmethod
    def _make_fake_client() -> MagicMock:
        client = MagicMock()
        client.query = MagicMock(return_value=None)
        return client

    # ------------------------------------------------------------------
    # AC: shared-mode, 3 issues → 3 run_with_shared_client, 2 soft_reset,
    #     0 runner.run (rate_limit.main_loop never called)
    # ------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_shared_mode_3_issues_calls_run_with_shared_client_3_times(
        self, tmp_path: Path
    ) -> None:
        """shared_client + 3 issues → exactly 3 run_with_shared_client calls."""
        state = _make_state_with_issues(tmp_path, [10, 11, 12])
        client = self._make_fake_client()

        with (
            patch(
                "code_generator.orchestrator.phase2_review.run_with_shared_client",
                return_value=_make_run_result(),
            ) as mock_rwsc,
            patch(
                "code_generator.orchestrator.phase2_review.soft_reset_context",
                return_value=_DUMMY_RESET,
            ),
            patch.object(phase2_review.rate_limit, "main_loop"),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                shared_client=client,
            )

        assert mock_rwsc.call_count == 3

    @pytest.mark.asyncio
    async def test_shared_mode_3_issues_calls_soft_reset_2_times(self, tmp_path: Path) -> None:
        """shared_client + 3 issues → exactly 2 soft_reset_context calls
        (between issue 0→1 and 1→2, never before the first)."""
        state = _make_state_with_issues(tmp_path, [10, 11, 12])
        client = self._make_fake_client()

        with (
            patch(
                "code_generator.orchestrator.phase2_review.run_with_shared_client",
                return_value=_make_run_result(),
            ),
            patch(
                "code_generator.orchestrator.phase2_review.soft_reset_context",
                return_value=_DUMMY_RESET,
            ) as mock_reset,
            patch.object(phase2_review.rate_limit, "main_loop"),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                shared_client=client,
            )

        assert mock_reset.call_count == 2

    @pytest.mark.asyncio
    async def test_shared_mode_3_issues_never_calls_runner_run(self, tmp_path: Path) -> None:
        """shared_client + 3 issues → rate_limit.main_loop is never called."""
        state = _make_state_with_issues(tmp_path, [10, 11, 12])
        client = self._make_fake_client()

        with (
            patch(
                "code_generator.orchestrator.phase2_review.run_with_shared_client",
                return_value=_make_run_result(),
            ),
            patch(
                "code_generator.orchestrator.phase2_review.soft_reset_context",
                return_value=_DUMMY_RESET,
            ),
            patch.object(phase2_review.rate_limit, "main_loop") as mock_main_loop,
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                shared_client=client,
            )

        mock_main_loop.assert_not_called()

    # ------------------------------------------------------------------
    # AC: fresh-mode, 3 issues → 3 runner.run (main_loop), 0 run_with_shared_client,
    #     0 soft_reset_context
    # ------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_fresh_mode_3_issues_calls_main_loop_3_times(self, tmp_path: Path) -> None:
        """No shared_client + 3 issues → 3 rate_limit.main_loop calls."""
        state = _make_state_with_issues(tmp_path, [10, 11, 12])

        call_count = 0

        async def fake_with_backoff(factory, *, breaker, **kw):
            nonlocal call_count
            call_count += 1
            await factory()

        async def fake_main_loop(runner, prompt, options, *, state_path, logger, **kw):
            return _make_run_result()

        with (
            patch(
                "code_generator.orchestrator.phase2_review.run_with_shared_client",
            ) as mock_rwsc,
            patch(
                "code_generator.orchestrator.phase2_review.soft_reset_context",
            ) as mock_reset,
            patch.object(phase2_review.rate_limit, "main_loop", side_effect=fake_main_loop),
            patch.object(phase2_review.retry, "with_backoff", side_effect=fake_with_backoff),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                shared_client=None,
            )

        assert call_count == 3
        mock_rwsc.assert_not_called()
        mock_reset.assert_not_called()

    # ------------------------------------------------------------------
    # AC: 1-issue shared-mode → 1 run_with_shared_client, 0 soft_reset
    # ------------------------------------------------------------------

    @pytest.mark.asyncio
    async def test_shared_mode_1_issue_no_soft_reset(self, tmp_path: Path) -> None:
        """shared_client + 1 issue → 1 run_with_shared_client, 0 soft_reset_context."""
        state = _make_state_with_issues(tmp_path, [10])
        client = self._make_fake_client()

        with (
            patch(
                "code_generator.orchestrator.phase2_review.run_with_shared_client",
                return_value=_make_run_result(),
            ) as mock_rwsc,
            patch(
                "code_generator.orchestrator.phase2_review.soft_reset_context",
                return_value=_DUMMY_RESET,
            ) as mock_reset,
            patch.object(phase2_review.rate_limit, "main_loop"),
            patch.object(phase2_review.gh, "view_issue", return_value={"comments": []}),
        ):
            await phase2_review.run(
                state,
                None,
                tmp_path,
                runner_module=MagicMock(),
                logger=logging.getLogger("test"),
                shared_client=client,
            )

        assert mock_rwsc.call_count == 1
        mock_reset.assert_not_called()
