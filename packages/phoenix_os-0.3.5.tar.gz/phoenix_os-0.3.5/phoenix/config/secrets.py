"""Secure secret storage -- OS keychain via keyring library.

Uses the native OS secret store:
  macOS: Keychain
  Linux: Secret Service (GNOME Keyring / KDE Wallet)
  Windows: Windows Credential Locker

Falls back to encrypted file in ~/.phoenix/secrets if keyring unavailable.
"""

import json
import logging
import os
from pathlib import Path

log = logging.getLogger(__name__)

_SERVICE_NAME = "phoenix-os"
_PHOENIX_DIR = Path(os.environ.get("PHOENIX_DIR", Path.home() / ".phoenix"))
_FALLBACK_FILE = _PHOENIX_DIR / "secrets.json"


def _use_keyring() -> bool:
    """Check if keyring backend is available and functional."""
    try:
        import keyring

        backend = keyring.get_keyring()
        name = type(backend).__name__
        return not ("fail" in name.lower() or "null" in name.lower())
    except (ImportError, Exception):
        return False


def diagnose_backend() -> str:
    """Return a human-readable summary of the current secret backend. For logs / --doctor."""
    try:
        import keyring

        backend = keyring.get_keyring()
        return f"keyring backend: {type(backend).__name__}"
    except ImportError:
        return "keyring: not installed"
    except Exception as e:
        return f"keyring: error -- {type(e).__name__}: {e}"


def store_secret(key: str, value: str):
    """Store a secret securely."""
    if _use_keyring():
        import keyring

        keyring.set_password(_SERVICE_NAME, key, value)
        log.debug("Stored secret '%s' in OS keychain", key)
    else:
        _fallback_store(key, value)


def get_secret(key: str) -> str | None:
    """Retrieve a secret. Returns None if not found."""
    if _use_keyring():
        try:
            import keyring

            val = keyring.get_password(_SERVICE_NAME, key)
            return val
        except Exception:
            return _fallback_get(key)
    return _fallback_get(key)


def delete_secret(key: str):
    """Delete a stored secret."""
    if _use_keyring():
        try:
            import keyring

            keyring.delete_password(_SERVICE_NAME, key)
        except Exception:
            pass
    _fallback_delete(key)


def list_secrets() -> list[str]:
    """List all stored secret keys (not values)."""
    keys = []
    if _fallback_exists():
        data = _fallback_load()
        keys.extend(data.keys())
    return keys


def load_secrets_to_env():
    """Load all stored secrets into environment variables.

    Called at startup to make API keys available to the system.
    Resolution order, per key:
      1. If env var already set -> keep it (highest priority)
      2. Else try OS keychain via `keyring`
      3. Else try encrypted fallback file (~/.phoenix/secrets.json)

    On Windows, keyring may silently fail or return None even when keys were
    stored earlier in the same session. We log when that happens so users
    can diagnose via `phoenix --doctor` or the PHOENIX_LOG_LEVEL=INFO env var.
    """
    key_map = {
        "ANTHROPIC_API_KEY": "ANTHROPIC_API_KEY",
        "OPENAI_API_KEY": "OPENAI_API_KEY",
        "GROQ_API_KEY": "GROQ_API_KEY",
        "GEMINI_API_KEY": "GEMINI_API_KEY",
        "MISTRAL_API_KEY": "MISTRAL_API_KEY",
        "DEEPSEEK_API_KEY": "DEEPSEEK_API_KEY",
        "OPENROUTER_API_KEY": "OPENROUTER_API_KEY",
        "BRAVE_API_KEY": "BRAVE_API_KEY",
        "PICOVOICE_ACCESS_KEY": "PICOVOICE_ACCESS_KEY",
        "ELEVENLABS_API_KEY": "ELEVENLABS_API_KEY",
    }

    keyring_ok = _use_keyring()
    log.info("Secret backend: %s", diagnose_backend())

    loaded_from_keyring = 0
    loaded_from_fallback = 0
    missing: list[str] = []

    for secret_key, env_var in key_map.items():
        if os.environ.get(env_var):
            continue

        value = None
        if keyring_ok:
            try:
                import keyring

                value = keyring.get_password(_SERVICE_NAME, secret_key)
                if value:
                    loaded_from_keyring += 1
            except Exception as e:
                log.warning("keyring.get_password('%s') failed: %s", secret_key, e)

        if not value:
            value = _fallback_get(secret_key)
            if value:
                loaded_from_fallback += 1

        if value:
            os.environ[env_var] = value
        else:
            missing.append(env_var)

    log.info(
        "Secrets loaded: %d from keyring, %d from fallback file; %d missing",
        loaded_from_keyring,
        loaded_from_fallback,
        len(missing),
    )


# -- Fallback: encrypted file storage --


def _fallback_exists() -> bool:
    return _FALLBACK_FILE.exists()


def _fallback_load() -> dict:
    if not _FALLBACK_FILE.exists():
        return {}
    try:
        return json.loads(_FALLBACK_FILE.read_text())
    except Exception:
        return {}


def _fallback_save(data: dict):
    _PHOENIX_DIR.mkdir(parents=True, exist_ok=True)
    _FALLBACK_FILE.write_text(json.dumps(data, indent=2))
    os.chmod(_FALLBACK_FILE, 0o600)


def _fallback_store(key: str, value: str):
    data = _fallback_load()
    data[key] = value
    _fallback_save(data)
    log.debug("Stored secret '%s' in %s", key, _FALLBACK_FILE)


def _fallback_get(key: str) -> str | None:
    data = _fallback_load()
    return data.get(key)


def _fallback_delete(key: str):
    data = _fallback_load()
    if key in data:
        del data[key]
        _fallback_save(data)
