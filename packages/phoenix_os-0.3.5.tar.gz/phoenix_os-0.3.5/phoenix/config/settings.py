"""Phoenix configuration -- model resolution, logging, paths."""

import logging
import os
from pathlib import Path

try:
    from dotenv import load_dotenv

    _env_path = Path.cwd() / ".env"
    if _env_path.exists():
        load_dotenv(_env_path)
except ImportError:
    pass


PHOENIX_DIR = Path(os.environ.get("PHOENIX_DIR", Path.home() / ".phoenix"))

DEFAULT_MODEL = "anthropic:claude-sonnet-4-20250514"
MODEL = os.environ.get("PHOENIX_MODEL", DEFAULT_MODEL)

OLLAMA_CLOUD_API_KEY = os.environ.get("OLLAMA_CLOUD_API_KEY", "")
OLLAMA_CLOUD_BASE_URL = os.environ.get("OLLAMA_CLOUD_BASE_URL", "https://ollama.com/v1")

if MODEL.startswith("ollama:") and not OLLAMA_CLOUD_API_KEY:
    os.environ.setdefault("OLLAMA_BASE_URL", "http://localhost:11434/v1")


def get_model() -> str:
    return MODEL


def get_provider(model: str | None = None) -> str:
    m = model or MODEL
    return m.split(":")[0] if ":" in m else "unknown"


def get_model_name(model: str | None = None) -> str:
    m = model or MODEL
    return m.split(":", 1)[1] if ":" in m else m


def resolve_model(model: str | None = None):
    """Resolve a model string to a pydantic-ai compatible model.

    Handles:
      - ollama cloud: ollama:model with OLLAMA_CLOUD_API_KEY set
      - ollama local: ollama:model:tag (extra colon = local server)
      - native pydantic-ai: anthropic:model, openai:model, etc.
    """
    m = model or MODEL

    if m.startswith("ollama:") and OLLAMA_CLOUD_API_KEY:
        from pydantic_ai.models.openai import OpenAIChatModel
        from pydantic_ai.providers.openai import OpenAIProvider

        return OpenAIChatModel(
            model_name=get_model_name(m),
            provider=OpenAIProvider(
                base_url=OLLAMA_CLOUD_BASE_URL,
                api_key=OLLAMA_CLOUD_API_KEY,
            ),
        )

    if m.startswith("ollama:") and m.count(":") > 1:
        from pydantic_ai.models.openai import OpenAIChatModel
        from pydantic_ai.providers.openai import OpenAIProvider

        base_url = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434/v1")
        return OpenAIChatModel(
            model_name=get_model_name(m),
            provider=OpenAIProvider(base_url=base_url, api_key="ollama"),
        )

    return m


def set_model(model: str):
    global MODEL
    MODEL = model
    if model.startswith("ollama:") and not OLLAMA_CLOUD_API_KEY:
        os.environ.setdefault("OLLAMA_BASE_URL", "http://localhost:11434/v1")


def setup_logging():
    level = os.environ.get("PHOENIX_LOG_LEVEL", "WARNING").upper()
    logging.basicConfig(
        level=getattr(logging, level, logging.WARNING),
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
        datefmt="%H:%M:%S",
    )
    for name in ("httpx", "httpcore", "openai", "anthropic", "urllib3"):
        logging.getLogger(name).setLevel(logging.WARNING)
