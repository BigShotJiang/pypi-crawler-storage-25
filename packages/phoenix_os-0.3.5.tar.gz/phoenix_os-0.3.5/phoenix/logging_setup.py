"""File-based logging so Phoenix issues can be diagnosed after the fact.

stdout/stderr are owned by Textual at runtime -- log records routed there
disappear into the TUI. This module wires up a `RotatingFileHandler` to
`~/.phoenix/logs/phoenix.log` and exposes `configure_logging(verbose)` as
the single entry point from `phoenix/main.py`.

Users diagnose issues with:
    phoenix -v              # DEBUG level, full detail
    phoenix --logs          # prints log directory path + recent lines

Third-party libs (httpx, transformers, etc.) are clamped even in verbose
mode -- their DEBUG output is not useful for Phoenix's own debugging.
"""

import logging
import os
from logging.handlers import RotatingFileHandler
from pathlib import Path

LOG_DIR = Path(os.environ.get("PHOENIX_DIR", Path.home() / ".phoenix")) / "logs"
LOG_FILE = LOG_DIR / "phoenix.log"

_NOISY = (
    "httpx",
    "httpcore",
    "urllib3",
    "transformers",
    "sentence_transformers",
    "huggingface_hub",
    "asyncio",
    "markdown_it",
    "PIL",
    "filelock",
    "fsspec",
)

_configured = False


def configure_logging(verbose: bool = False) -> Path:
    """Wire up a rotating file handler as the single logging sink.

    Safe to call more than once -- subsequent calls just update levels.
    Returns the log file path so callers can surface it to users.
    """
    global _configured

    LOG_DIR.mkdir(parents=True, exist_ok=True)

    root = logging.getLogger()
    root.setLevel(logging.DEBUG if verbose else logging.INFO)

    if not _configured:
        # Clear anything basicConfig might have installed
        for h in list(root.handlers):
            root.removeHandler(h)

        handler = RotatingFileHandler(
            LOG_FILE,
            maxBytes=5 * 1024 * 1024,  # 5MB per file
            backupCount=3,  # phoenix.log + .1 .2 .3  -> 20MB cap
            encoding="utf-8",
        )
        handler.setFormatter(
            logging.Formatter(
                "%(asctime)s %(levelname)-8s %(name)s: %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )
        )
        root.addHandler(handler)
        _configured = True

    # Always clamp noisy libs -- even verbose users don't need httpx wire logs
    noise_level = logging.INFO if verbose else logging.WARNING
    for name in _NOISY:
        logging.getLogger(name).setLevel(noise_level)

    return LOG_FILE


def tail(n: int = 20) -> str:
    """Return the last N lines of the log as a string. For /logs slash command."""
    if not LOG_FILE.exists():
        return "(no log file yet)"
    try:
        with open(LOG_FILE, encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        return "".join(lines[-n:])
    except Exception as e:
        return f"(could not read log: {e})"
