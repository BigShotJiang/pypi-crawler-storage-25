"""Ambient intelligence configuration -- hardcoded defaults."""

from dataclasses import dataclass, field


@dataclass(frozen=True)
class AmbientConfig:
    sentinel_tick_seconds: float = 60.0
    priority_threshold: float = 1.5
    priority_decay: float = 0.95
    max_nudges_per_hour: int = 3
    batch_window_seconds: float = 120.0
    daily_token_budget: int = 5000
    emergency_reserve: int = 500

    cooldowns: dict[str, float] = field(
        default_factory=lambda: {
            "break_reminder": 3600,
            "battery_low": 300,
            "battery_critical": 60,
            "deadline_warning": 1800,
            "idle_detected": 1800,
            "long_session": 3600,
            "disk_warning": 86400,
            "overwork_warning": 3600,
            "late_night_alert": 3600,
        }
    )
