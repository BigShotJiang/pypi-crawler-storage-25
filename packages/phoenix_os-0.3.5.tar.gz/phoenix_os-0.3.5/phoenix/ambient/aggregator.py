"""Aggregator -- batches signals, manages priority gate and token budget."""

import logging
import time
from collections import deque

from .config import AmbientConfig
from .sentinel import Signal

log = logging.getLogger(__name__)


class TokenLedger:
    """Daily token budget tracker. Resets at midnight."""

    def __init__(self, daily_budget: int = 5000, reserve: int = 500):
        self.daily_budget = daily_budget
        self.reserve = reserve
        self._spent_today = 0
        self._day = time.localtime().tm_yday

    def can_spend(self, estimated_cost: int) -> bool:
        self._check_reset()
        available = self.daily_budget - self.reserve - self._spent_today
        return estimated_cost <= available

    def spend(self, tokens: int):
        self._check_reset()
        self._spent_today += tokens

    def remaining(self) -> int:
        self._check_reset()
        return max(0, self.daily_budget - self.reserve - self._spent_today)

    def _check_reset(self):
        today = time.localtime().tm_yday
        if today != self._day:
            self._spent_today = 0
            self._day = today


class Aggregator:
    """Batches signals, accumulates priority, gates nudge decisions."""

    def __init__(self, config: AmbientConfig):
        self.config = config
        self._pending: list[Signal] = []
        self._accumulated_priority: float = 0.0
        self._nudge_history: deque[float] = deque(maxlen=100)
        self.ledger = TokenLedger(config.daily_token_budget, config.emergency_reserve)

    def add_signal(self, signal: Signal):
        self._pending.append(signal)
        self._accumulated_priority += signal.priority

    def add_signals(self, signals: list[Signal]):
        for s in signals:
            self.add_signal(s)

    def should_fire(self) -> bool:
        """Check if accumulated signals warrant a nudge."""
        if not self._pending:
            return False

        # Priority threshold
        if self._accumulated_priority < self.config.priority_threshold:
            return False

        # Rate limit
        now = time.time()
        recent = sum(1 for t in self._nudge_history if now - t < 3600)
        if recent >= self.config.max_nudges_per_hour:
            return False

        # Token budget
        if not self.ledger.can_spend(150):
            return False

        # Batch window (let signals accumulate)
        if self._pending:
            oldest = min(s.timestamp for s in self._pending)
            if now - oldest < self.config.batch_window_seconds:
                return False

        return True

    def get_batch(self) -> list[Signal]:
        """Return current signals and reset accumulator."""
        batch = list(self._pending)
        self._pending.clear()
        self._accumulated_priority = 0.0
        return batch

    def record_nudge(self, tokens_used: int = 0):
        self._nudge_history.append(time.time())
        if tokens_used:
            self.ledger.spend(tokens_used)

    def decay(self):
        """Apply priority decay each cycle."""
        self._accumulated_priority *= self.config.priority_decay

    @property
    def pending_count(self) -> int:
        return len(self._pending)

    @property
    def accumulated_priority(self) -> float:
        return self._accumulated_priority
