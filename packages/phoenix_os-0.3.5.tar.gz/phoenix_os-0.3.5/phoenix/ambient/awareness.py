"""Awareness -- memory-backed behavioral intelligence.

Replaces autonomy.py + analytics.py + insights_db.py from original Phoenix.
All observations go into memory under namespace='ambient'.
"""

import logging

log = logging.getLogger(__name__)

_NAMESPACE = "ambient"


class AwarenessEngine:
    """Bridge between ambient and memory. Stores observations as memory facts."""

    def __init__(self, memory):
        self.memory = memory

    async def observe(self, event: str, details: str = ""):
        """Record an ambient observation as a memory fact."""
        if not self.memory:
            return
        content = f"{event}: {details}" if details else event
        try:
            await self.memory.post_turn(
                user_input=content,
                ai_output="",
                namespace=_NAMESPACE,
            )
        except Exception as e:
            log.debug("Awareness observe failed: %s", e)

    async def observe_nudge_response(self, nudge_text: str, was_ignored: bool):
        """Track whether Boss engaged with or ignored a nudge."""
        status = "ignored" if was_ignored else "engaged with"
        await self.observe(f"Boss {status} nudge", nudge_text[:100])

    async def observe_execution(self, responsibility_id: str, title: str, authority: str):
        """Record a responsibility execution."""
        await self.observe(
            f"Responsibility executed: {title}",
            f"id={responsibility_id}, authority={authority}",
        )

    async def get_patterns(self) -> str:
        """Recall behavioral patterns from memory for nudge engine context."""
        if not self.memory:
            return ""
        try:
            return await self.memory.recall_for_agent(
                task="behavioral patterns work habits preferences",
                agent_name=_NAMESPACE,
            )
        except Exception:
            return ""

    async def should_nudge(self, signal_type: str) -> float:
        """Memory-informed nudge confidence multiplier (0-1)."""
        if not self.memory:
            return 1.0
        try:
            await self.memory._ensure_initialized()
            memories = await self.memory._recall.recall(
                f"Boss response to {signal_type} nudges",
                namespace=_NAMESPACE,
                top_k=3,
            )
            ignore_count = sum(1 for m in memories if "ignored" in m.get("content", ""))
            if ignore_count >= 3:
                return 0.2
            return 1.0
        except Exception:
            return 1.0

    async def recommend_authority_change(self, resp_id: str) -> str | None:
        """Check if a responsibility should be escalated or downgraded."""
        if not self.memory:
            return None
        try:
            await self.memory._ensure_initialized()
            memories = await self.memory._recall.recall(
                f"effectiveness of {resp_id} responsibility execution",
                namespace=_NAMESPACE,
                top_k=10,
            )
            engaged = sum(1 for m in memories if "engaged" in m.get("content", ""))
            ignored = sum(1 for m in memories if "ignored" in m.get("content", ""))

            if engaged >= 5 and ignored <= 1:
                return "escalate"
            if ignored >= 4:
                return "downgrade"
            return None
        except Exception:
            return None
