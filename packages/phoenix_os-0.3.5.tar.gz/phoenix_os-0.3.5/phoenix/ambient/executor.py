"""Executor -- routes signals based on authority level."""

import logging
from dataclasses import dataclass

from .sentinel import Signal

log = logging.getLogger(__name__)

AUTONOMOUS = "autonomous"
PROACTIVE = "proactive"
ADVISORY = "advisory"
RESTRICTED = "restricted"


@dataclass
class Action:
    action_type: str
    message: str = ""
    should_nudge: bool = False
    signal: Signal | None = None


class Executor:
    """Routes signals based on their authority level."""

    def route(self, signal: Signal, authority: str = ADVISORY) -> Action:
        """Determine what action to take for a signal."""
        if authority == AUTONOMOUS:
            return Action(
                action_type="execute",
                message=f"[auto] {signal.signal_type}",
                should_nudge=False,
                signal=signal,
            )

        if authority == PROACTIVE:
            return Action(
                action_type="execute_and_inform",
                message=f"{signal.signal_type}",
                should_nudge=True,
                signal=signal,
            )

        if authority == ADVISORY:
            return Action(
                action_type="nudge",
                should_nudge=True,
                signal=signal,
            )

        # RESTRICTED
        return Action(
            action_type="log_only",
            should_nudge=False,
            signal=signal,
        )
