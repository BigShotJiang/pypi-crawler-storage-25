"""Nudge engine -- single LLM call to decide: speak or SKIP."""

import logging

from .sentinel import Signal

log = logging.getLogger(__name__)


def format_signals(signals: list[Signal]) -> str:
    """Format signals into a compact list for the LLM."""
    lines = []
    for s in signals:
        payload_str = ", ".join(f"{k}={v}" for k, v in s.payload.items())
        lines.append(f"- {s.signal_type}: {payload_str} (priority: {s.priority})")
    return "\n".join(lines)


class NudgeEngine:
    """Decides whether to nudge the user. One LLM call, ~100 tokens."""

    def __init__(self, model: str):
        self._model = model

    async def decide(
        self,
        signals: list[Signal],
        patterns: str = "",
    ) -> str | None:
        """Evaluate signals and return a nudge sentence, or None to skip.

        Returns:
            A single sentence to show the user, or None if not worth interrupting.
        """
        if not signals:
            return None

        signal_text = format_signals(signals)

        prompt = f"""Background signals right now:
{signal_text}

{f"What you know about Boss's patterns:{chr(10)}{patterns}{chr(10)}" if patterns else ""}
You are Phoenix's ambient layer. Based on these signals, should you say something to Boss?
Rules:
- Only speak if genuinely useful. Do not be annoying.
- If you speak, ONE sentence max. Warm but direct.
- If not worth interrupting, respond with exactly: SKIP

Your response (one sentence or SKIP):"""

        try:
            from pydantic_ai import Agent

            agent = Agent(
                self._model,
                instructions="You are a minimal ambient notification system. Be concise.",
            )
            result = await agent.run(prompt)
            output = str(result.output).strip()

            if "SKIP" in output.upper():
                log.debug("Nudge engine: SKIP")
                return None

            nudge = output.strip().split("\n")[0][:200]
            log.info("Nudge: %s", nudge)
            return nudge

        except Exception as e:
            log.warning("Nudge engine failed: %s", e)
            return None
