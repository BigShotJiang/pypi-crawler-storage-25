"""Sentinel -- pure Python system monitor. Zero LLM calls. Fires signals."""

import logging
import platform
import shutil
import subprocess
import time
from dataclasses import dataclass, field

from .config import AmbientConfig

log = logging.getLogger(__name__)


@dataclass
class Signal:
    signal_type: str
    priority: float
    payload: dict = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


class Sentinel:
    """Monitors system state and fires signals. Pure Python, zero tokens."""

    def __init__(self, config: AmbientConfig):
        self.config = config
        self._cooldowns: dict[str, float] = {}
        self._session_start: float = time.time()
        self._last_input_time: float = time.time()

    def check(self) -> list[Signal]:
        """Run all checks, return fired signals."""
        signals = []
        now = time.time()

        signals.extend(self._check_session_length(now))
        signals.extend(self._check_time_of_day(now))
        signals.extend(self._check_battery(now))
        signals.extend(self._check_disk(now))

        return signals

    def record_input(self):
        """Called when user sends input -- resets idle timer."""
        self._last_input_time = time.time()

    def _can_fire(self, signal_type: str) -> bool:
        now = time.time()
        cooldown = self.config.cooldowns.get(signal_type, 3600)
        last_fired = self._cooldowns.get(signal_type, 0)
        if now - last_fired < cooldown:
            return False
        self._cooldowns[signal_type] = now
        return True

    def _check_session_length(self, now: float) -> list[Signal]:
        signals = []
        session_minutes = (now - self._session_start) / 60

        if session_minutes >= 90 and self._can_fire("break_reminder"):
            signals.append(
                Signal(
                    signal_type="break_reminder",
                    priority=0.6,
                    payload={"session_minutes": round(session_minutes)},
                )
            )

        if session_minutes >= 480 and self._can_fire("overwork_warning"):
            signals.append(
                Signal(
                    signal_type="overwork_warning",
                    priority=0.85,
                    payload={"session_hours": round(session_minutes / 60, 1)},
                )
            )

        idle_minutes = (now - self._last_input_time) / 60
        if idle_minutes >= 30 and self._can_fire("idle_detected"):
            signals.append(
                Signal(
                    signal_type="idle_detected",
                    priority=0.3,
                    payload={"idle_minutes": round(idle_minutes)},
                )
            )

        return signals

    def _check_time_of_day(self, now: float) -> list[Signal]:
        signals = []
        hour = time.localtime(now).tm_hour

        if hour >= 23 and self._can_fire("late_night_alert"):
            signals.append(
                Signal(
                    signal_type="late_night_alert",
                    priority=0.7,
                    payload={"hour": hour},
                )
            )

        return signals

    def _check_battery(self, now: float) -> list[Signal]:
        if platform.system() != "Darwin":
            return []
        signals = []
        try:
            result = subprocess.run(
                ["pmset", "-g", "batt"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            output = result.stdout
            if "Battery" not in output:
                return []

            import re

            match = re.search(r"(\d+)%", output)
            if not match:
                return []
            pct = int(match.group(1))
            charging = "charging" in output.lower() or "ac power" in output.lower()

            if pct <= 10 and not charging and self._can_fire("battery_critical"):
                signals.append(
                    Signal(
                        signal_type="battery_critical",
                        priority=0.95,
                        payload={"battery_pct": pct, "charging": charging},
                    )
                )
            elif pct <= 30 and not charging and self._can_fire("battery_low"):
                signals.append(
                    Signal(
                        signal_type="battery_low",
                        priority=0.8,
                        payload={"battery_pct": pct, "charging": charging},
                    )
                )
        except Exception:
            pass
        return signals

    def _check_disk(self, now: float) -> list[Signal]:
        signals = []
        try:
            usage = shutil.disk_usage("/")
            pct_used = (usage.used / usage.total) * 100
            if pct_used >= 90 and self._can_fire("disk_warning"):
                signals.append(
                    Signal(
                        signal_type="disk_warning",
                        priority=0.5,
                        payload={"disk_pct": round(pct_used, 1)},
                    )
                )
        except Exception:
            pass
        return signals
