"""Ambient daemon -- background intelligence orchestrator."""

import asyncio
import logging

from .aggregator import Aggregator
from .awareness import AwarenessEngine
from .config import AmbientConfig
from .executor import Executor
from .nudge import NudgeEngine
from .responsibilities import ResponsibilityManager
from .sentinel import Sentinel, Signal

log = logging.getLogger(__name__)


class AmbientDaemon:
    """Runs alongside the chat loop. Zero tokens until something is worth saying."""

    def __init__(self, model: str, config: AmbientConfig | None = None, memory=None):
        self.config = config or AmbientConfig()
        self._model = model
        self._memory = memory
        self._enabled = True
        self._running = False

        self.sentinel = Sentinel(self.config)
        self.aggregator = Aggregator(self.config)
        self.executor = Executor()
        self.nudge_engine = NudgeEngine(model)
        self.responsibilities = ResponsibilityManager()
        self.awareness = AwarenessEngine(memory)

        self._notifications: list[str] = []

    async def run(self):
        """Main daemon loop. Runs sentinel checks on tick interval."""
        self._running = True
        log.info("Ambient daemon started (tick: %ss)", self.config.sentinel_tick_seconds)

        try:
            while self._running and self._enabled:
                await self._tick()
                await asyncio.sleep(self.config.sentinel_tick_seconds)
        except asyncio.CancelledError:
            pass
        finally:
            self._running = False
            log.info("Ambient daemon stopped")

    async def _tick(self):
        """One sentinel cycle: check -> aggregate -> maybe nudge."""
        # Sentinel checks (zero LLM)
        signals = self.sentinel.check()

        # Check responsibilities
        due_resps = self.responsibilities.get_due()
        for resp in due_resps:
            signals.append(
                Signal(
                    signal_type=f"responsibility_{resp.id}",
                    priority=resp.priority,
                    payload={"title": resp.title, "description": resp.description},
                )
            )
            self.responsibilities.mark_executed(resp.id)
            await self.awareness.observe_execution(resp.id, resp.title, resp.authority)

        if not signals:
            self.aggregator.decay()
            return

        # Feed to aggregator
        self.aggregator.add_signals(signals)

        # Check if gate should open
        if not self.aggregator.should_fire():
            return

        # Gate opened -- get batch and decide
        batch = self.aggregator.get_batch()

        # Memory-informed confidence
        for signal in batch:
            confidence = await self.awareness.should_nudge(signal.signal_type)
            signal.priority *= confidence

        # LLM decides: speak or SKIP
        patterns = await self.awareness.get_patterns()
        nudge_text = await self.nudge_engine.decide(batch, patterns)

        if nudge_text:
            self._notifications.append(f"  Phoenix: {nudge_text}")
            self.aggregator.record_nudge(tokens_used=100)
            log.info("Ambient nudge: %s", nudge_text)
        else:
            self.aggregator.record_nudge(tokens_used=50)

    def get_notifications(self) -> list[str]:
        """Return and clear pending notifications."""
        notes = list(self._notifications)
        self._notifications.clear()
        return notes

    def record_input(self):
        """Called by shell loop when user sends input."""
        self.sentinel.record_input()

    def stop(self):
        self._running = False
        self._enabled = False

    @property
    def is_enabled(self) -> bool:
        return self._enabled

    @property
    def is_running(self) -> bool:
        return self._running

    def enable(self):
        self._enabled = True

    def disable(self):
        self._enabled = False

    def status(self) -> dict:
        return {
            "enabled": self._enabled,
            "running": self._running,
            "pending_signals": self.aggregator.pending_count,
            "accumulated_priority": round(self.aggregator.accumulated_priority, 2),
            "tokens_remaining": self.aggregator.ledger.remaining(),
            "responsibilities": len(self.responsibilities.list_all()),
        }
