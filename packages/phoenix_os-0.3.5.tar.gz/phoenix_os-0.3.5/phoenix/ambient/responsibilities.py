"""Responsibilities -- scheduled duties with authority levels. Pure scheduling."""

import time
from dataclasses import dataclass
from datetime import datetime, timedelta

DAILY = "daily"
WEEKLY = "weekly"
ON_TRIGGER = "on_trigger"
ONCE = "once"


@dataclass
class Responsibility:
    id: str
    title: str
    description: str = ""
    recurrence: str = DAILY
    authority: str = "advisory"
    priority: float = 0.5
    next_due: float = 0.0
    active: bool = True


_AUTHORITY_LADDER = ["restricted", "advisory", "proactive", "autonomous"]


class ResponsibilityManager:
    """Manages scheduled responsibilities. Pure scheduling -- no tracking."""

    def __init__(self):
        self._responsibilities: dict[str, Responsibility] = {}
        self._seed_defaults()

    def _seed_defaults(self):
        now = time.time()
        today = datetime.fromtimestamp(now)
        morning = today.replace(hour=8, minute=0, second=0)
        if morning.timestamp() < now:
            morning += timedelta(days=1)

        defaults = [
            Responsibility(
                id="morning_briefing",
                title="Morning Briefing",
                description="Check tasks, memory, and ongoing work for a status update",
                recurrence=DAILY,
                authority="proactive",
                priority=0.7,
                next_due=morning.timestamp(),
            ),
            Responsibility(
                id="check_overdue",
                title="Check Overdue Tasks",
                description="Alert about overdue tasks",
                recurrence=DAILY,
                authority="advisory",
                priority=0.5,
                next_due=(morning + timedelta(hours=1)).timestamp(),
            ),
            Responsibility(
                id="eod_summary",
                title="End of Day Summary",
                description="Summarize what was accomplished today",
                recurrence=DAILY,
                authority="advisory",
                priority=0.4,
                next_due=today.replace(hour=18, minute=0).timestamp(),
            ),
        ]

        for r in defaults:
            self._responsibilities[r.id] = r

    def get_due(self, now: float | None = None) -> list[Responsibility]:
        now = now or time.time()
        return [r for r in self._responsibilities.values() if r.active and r.next_due <= now]

    def mark_executed(self, resp_id: str, now: float | None = None):
        now = now or time.time()
        r = self._responsibilities.get(resp_id)
        if not r:
            return

        if r.recurrence == DAILY:
            r.next_due = now + 86400
        elif r.recurrence == WEEKLY:
            r.next_due = now + 86400 * 7
        elif r.recurrence == ONCE:
            r.active = False
        elif r.recurrence == ON_TRIGGER:
            r.next_due = now + 86400 * 365 * 100

    def list_all(self, active_only: bool = True) -> list[Responsibility]:
        resps = list(self._responsibilities.values())
        if active_only:
            resps = [r for r in resps if r.active]
        resps.sort(key=lambda r: r.priority, reverse=True)
        return resps

    def upgrade_authority(self, resp_id: str) -> str | None:
        r = self._responsibilities.get(resp_id)
        if not r:
            return None
        idx = _AUTHORITY_LADDER.index(r.authority) if r.authority in _AUTHORITY_LADDER else 1
        if idx < len(_AUTHORITY_LADDER) - 1:
            r.authority = _AUTHORITY_LADDER[idx + 1]
        return r.authority

    def downgrade_authority(self, resp_id: str) -> str | None:
        r = self._responsibilities.get(resp_id)
        if not r:
            return None
        idx = _AUTHORITY_LADDER.index(r.authority) if r.authority in _AUTHORITY_LADDER else 1
        if idx > 0:
            r.authority = _AUTHORITY_LADDER[idx - 1]
        return r.authority
