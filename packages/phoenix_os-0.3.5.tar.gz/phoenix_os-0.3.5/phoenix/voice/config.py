"""Voice pipeline configuration -- env-based settings."""

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass
class VoiceConfig:
    # Wake word (Porcupine)
    picovoice_access_key: str = ""
    wake_word_model: str = ""

    # STT
    stt_backend: str = "groq"  # "groq" or "local"
    groq_api_key: str = ""
    groq_model: str = "whisper-large-v3"
    local_whisper_model: str = "tiny.en"

    # TTS
    tts_backend: str = "kokoro"  # "kokoro", "say", "elevenlabs", "off"
    tts_voice: str = "Samantha"
    kokoro_voice: str = "af_bella"
    kokoro_speed: float = 1.0
    elevenlabs_api_key: str = ""
    elevenlabs_voice_id: str = "8J6BC8hEQXSzaJr7WMFn"
    tts_max_words: int = 80

    # Audio capture
    sample_rate: int = 44100
    channels: int = 1
    chunk_size: int = 1024
    silence_threshold: int = 500
    silence_duration: float = 2.7

    # Behavior
    followup_window: float = 8.0
    command_max_seconds: float = 15.0

    def __post_init__(self):
        if not self.picovoice_access_key:
            self.picovoice_access_key = os.getenv(
                "PICOVOICE_ACCESS_KEY",
                os.getenv("picovoice_api_key", os.getenv("ACCESS_KEY", "")),  # noqa: SIM112
            )
        if not self.groq_api_key:
            self.groq_api_key = os.getenv("GROQ_API_KEY", "")
        if not self.elevenlabs_api_key:
            self.elevenlabs_api_key = os.getenv(
                "ELEVENLABS_API_KEY",
                os.getenv("eleven_labs_api", ""),  # noqa: SIM112
            )
        if not self.wake_word_model:
            model_path = Path(__file__).parent / "phoenix_en_mac_v3_0_0.ppn"
            if model_path.exists():
                self.wake_word_model = str(model_path)

    @property
    def can_wake_word(self) -> bool:
        return bool(self.picovoice_access_key and self.wake_word_model)

    @property
    def can_stt(self) -> bool:
        return bool(self.groq_api_key) if self.stt_backend == "groq" else True

    @property
    def can_tts(self) -> bool:
        if self.tts_backend == "kokoro":
            return os.path.exists(
                os.path.expanduser("~/.phoenix/kokoro/onnx/model.onnx")
            ) and os.path.exists(os.path.expanduser("~/.phoenix/kokoro/voices-v1.0.bin"))
        if self.tts_backend == "elevenlabs":
            return bool(self.elevenlabs_api_key)
        if self.tts_backend == "say":
            import shutil

            return shutil.which("say") is not None
        return False
