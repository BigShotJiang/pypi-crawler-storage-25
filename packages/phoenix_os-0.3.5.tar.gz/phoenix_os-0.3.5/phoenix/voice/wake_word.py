"""Wake word detection -- Porcupine "Phoenix" detector."""

import asyncio
import logging

import numpy as np

from .audio import AudioFilter
from .config import VoiceConfig

log = logging.getLogger(__name__)


class WakeWordDetector:
    """Listens for "Phoenix" wake word using Porcupine."""

    def __init__(self, config: VoiceConfig):
        self._config = config
        self._porcupine = None
        self._audio_filter = None
        self._running = False

    def _init_porcupine(self):
        if self._porcupine is not None:
            return
        try:
            import pvporcupine

            self._porcupine = pvporcupine.create(
                access_key=self._config.picovoice_access_key,
                keyword_paths=[self._config.wake_word_model],
                sensitivities=[0.35],
            )
            self._audio_filter = AudioFilter(aggressiveness=1)
            log.info(
                "Porcupine initialized (rate=%d, frame=%d)",
                self._porcupine.sample_rate,
                self._porcupine.frame_length,
            )
        except ImportError:
            log.error("pvporcupine not installed")
            raise
        except Exception as e:
            log.error("Porcupine init failed: %s", e)
            raise

    async def wait_for_wake_word(self) -> bool:
        """Block until "Phoenix" is detected. Returns True on detection, False on stop."""
        self._init_porcupine()
        self._running = True
        loop = asyncio.get_event_loop()
        event = asyncio.Event()
        detected = False

        def _listen_thread():
            nonlocal detected
            try:
                import sounddevice as sd

                sr = self._porcupine.sample_rate
                frame_len = self._porcupine.frame_length
                warmup_frames = int(0.5 * sr / frame_len)
                frame_count = 0

                def callback(indata, frames, time_info, status):
                    nonlocal frame_count, detected
                    frame_count += 1
                    if frame_count < warmup_frames:
                        return

                    pcm = (indata[:, 0] * 32767).astype(np.int16)

                    if self._audio_filter and not self._audio_filter.is_speech(pcm, sr):
                        return

                    keyword_index = self._porcupine.process(pcm[:frame_len])
                    if keyword_index >= 0:
                        detected = True
                        loop.call_soon_threadsafe(event.set)
                        raise sd.CallbackAbort()

                with sd.InputStream(
                    samplerate=sr,
                    channels=1,
                    dtype="float32",
                    blocksize=frame_len,
                    latency="low",
                    callback=callback,
                ):
                    while self._running and not detected:
                        sd.sleep(100)

            except Exception as e:
                if "CallbackAbort" not in str(type(e).__name__):
                    log.debug("Wake word thread: %s", e)
                if not detected:
                    loop.call_soon_threadsafe(event.set)

        import threading

        thread = threading.Thread(target=_listen_thread, daemon=True)
        thread.start()
        await event.wait()
        self._running = False
        return detected

    def cleanup(self):
        self._running = False
        if self._porcupine:
            self._porcupine.delete()
            self._porcupine = None

    @property
    def is_listening(self) -> bool:
        return self._running
