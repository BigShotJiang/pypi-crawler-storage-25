"""Audio processing -- WebRTC VAD + spectral noise reduction."""

import logging

import numpy as np

log = logging.getLogger(__name__)


class AudioFilter:
    """WebRTC VAD for speech detection + noisereduce for cleanup."""

    def __init__(self, aggressiveness: int = 2):
        self._aggressiveness = aggressiveness
        self._vad = None
        self._nr_available = True

    def _init_vad(self):
        if self._vad is not None:
            return
        try:
            import webrtcvad

            self._vad = webrtcvad.Vad(self._aggressiveness)
            log.debug("WebRTC VAD initialized (aggressiveness=%d)", self._aggressiveness)
        except ImportError:
            log.warning("webrtcvad not installed -- VAD disabled (fail-open)")
            self._vad = False

    def is_speech(self, pcm_int16: np.ndarray, sample_rate: int) -> bool:
        """Returns True if audio contains speech. Fail-open if VAD unavailable."""
        self._init_vad()
        if self._vad is False:
            return True

        try:
            if sample_rate != 16000:
                pcm_int16 = self._resample(pcm_int16, sample_rate, 16000)

            frame_ms = 30
            frame_samples = int(16000 * frame_ms / 1000)
            frames = len(pcm_int16) // frame_samples

            for i in range(frames):
                frame = pcm_int16[i * frame_samples : (i + 1) * frame_samples]
                frame_bytes = frame.astype(np.int16).tobytes()
                if self._vad.is_speech(frame_bytes, 16000):
                    return True
            return False
        except Exception:
            return True

    def clean_audio(self, pcm_int16: np.ndarray, sample_rate: int) -> np.ndarray:
        """Apply spectral noise reduction. Returns cleaned int16 audio."""
        if not self._nr_available:
            return pcm_int16
        try:
            import noisereduce as nr

            audio_float = pcm_int16.astype(np.float32) / 32768.0
            cleaned = nr.reduce_noise(
                y=audio_float,
                sr=sample_rate,
                prop_decrease=0.75,
                stationary=True,
                n_fft=1024,
                freq_mask_smooth_hz=200,
            )
            return np.clip(cleaned * 32768, -32768, 32767).astype(np.int16)
        except ImportError:
            self._nr_available = False
            log.warning("noisereduce not installed -- skipping noise reduction")
            return pcm_int16
        except Exception:
            return pcm_int16

    @staticmethod
    def _resample(pcm: np.ndarray, from_rate: int, to_rate: int) -> np.ndarray:
        ratio = to_rate / from_rate
        new_len = int(len(pcm) * ratio)
        indices = np.linspace(0, len(pcm) - 1, new_len)
        return np.interp(indices, np.arange(len(pcm)), pcm.astype(np.float32)).astype(np.int16)
