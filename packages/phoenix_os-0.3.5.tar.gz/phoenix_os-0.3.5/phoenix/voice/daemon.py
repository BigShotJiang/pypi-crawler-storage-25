"""Voice daemon -- orchestrates wake word, STT, TTS pipeline."""

import asyncio
import logging
import time

from .config import VoiceConfig
from .stt import SpeechToText
from .tts import TextToSpeech
from .wake_word import WakeWordDetector

log = logging.getLogger(__name__)


class VoiceDaemon:
    """Orchestrates: wake word -> listen -> transcribe -> inject -> speak."""

    def __init__(self, config: VoiceConfig | None = None, voice_queue: asyncio.Queue | None = None):
        self._config = config or VoiceConfig()
        self._voice_queue = voice_queue or asyncio.Queue(maxsize=10)
        self._enabled = True
        self._running = False
        self._in_followup = False
        self._last_response_time: float = 0

        self._wake: WakeWordDetector | None = None
        self._stt: SpeechToText | None = None
        self._tts: TextToSpeech | None = None

    def _init_components(self):
        if self._config.can_wake_word:
            self._wake = WakeWordDetector(self._config)
        else:
            log.warning("Wake word unavailable -- missing Porcupine key or model")

        self._stt = SpeechToText(self._config)
        self._tts = TextToSpeech(self._config)

    async def run(self):
        """Main voice loop."""
        self._init_components()
        self._running = True
        self._print('Voice active -- say "Phoenix" to begin')

        try:
            while self._running and self._enabled:
                try:
                    await self._voice_cycle()
                    await asyncio.sleep(0.1)
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    log.debug("Voice cycle error: %s", e)
                    await asyncio.sleep(2)
        finally:
            self._cleanup()
            self._running = False

    async def _voice_cycle(self):
        in_followup = (
            self._in_followup
            and (time.time() - self._last_response_time) < self._config.followup_window
        )

        if not in_followup:
            self._in_followup = False
            if self._wake is None:
                await asyncio.sleep(1)
                return

            detected = await self._wake.wait_for_wake_word()
            if not detected:
                return

            self._print("Listening...")
            await asyncio.sleep(0.3)

        if self._stt is None:
            return

        text = await self._stt.listen_and_transcribe()
        if not text:
            self._in_followup = False
            await asyncio.sleep(2)
            return

        self._print(f"\033[32m{text}\033[0m")
        try:
            self._voice_queue.put_nowait(text)
        except asyncio.QueueFull:
            self._print("\033[33mVoice queue full\033[0m")

    async def on_response(self, text: str):
        """Called after AI responds. Speaks and opens follow-up window."""
        if self._tts and not self._tts.is_muted:
            await self._tts.speak(text)
            self._last_response_time = time.time()
            self._in_followup = True

    def _print(self, msg: str):
        print(f"  \033[36m[voice]\033[0m {msg}", flush=True)

    def _cleanup(self):
        if self._wake:
            self._wake.cleanup()
        self._print("Voice stopped")

    @property
    def voice_queue(self) -> asyncio.Queue:
        return self._voice_queue

    @property
    def is_enabled(self) -> bool:
        return self._enabled

    @property
    def is_running(self) -> bool:
        return self._running

    def enable(self):
        self._enabled = True

    def disable(self):
        self._enabled = False

    def mute_tts(self):
        if self._tts:
            self._tts.mute()

    def unmute_tts(self):
        if self._tts:
            self._tts.unmute()

    def stop(self):
        self._running = False
        self._enabled = False

    def status(self) -> dict:
        return {
            "enabled": self._enabled,
            "running": self._running,
            "wake_word": "Phoenix (Porcupine)" if self._config.can_wake_word else "unavailable",
            "stt_backend": self._config.stt_backend,
            "tts_backend": self._config.tts_backend,
            "tts_muted": self._tts.is_muted if self._tts else True,
            "in_followup": self._in_followup,
            "can_stt": self._config.can_stt,
            "can_tts": self._config.can_tts,
        }
