"""Phoenix CLI entry point."""


def main():
    try:
        from dotenv import load_dotenv

        load_dotenv()
    except ImportError:
        pass

    from phoenix.main import run

    run()


if __name__ == "__main__":
    main()
