"""Registry -- auto-discovers abilities and agent personalities."""

import importlib
import logging
from pathlib import Path

from phoenix.abilities import AbilityInfo, get_ability_registry
from phoenix.personality.parser import AgentConfig, parse_agent

log = logging.getLogger(__name__)

_ABILITIES_DIR = Path(__file__).parent.parent / "abilities"
_AGENTS_DIR = Path(__file__).parent.parent / "personality" / "agents"


class Registry:
    """Central registry for discovered abilities and agent configs."""

    def __init__(self):
        self._abilities: dict[str, AbilityInfo] = {}
        self._agents: dict[str, AgentConfig] = {}

    def discover_abilities(self, path: Path | None = None):
        """Scan abilities/ folder, import all .py files, collect @ability-decorated functions."""
        abilities_dir = path or _ABILITIES_DIR
        if not abilities_dir.is_dir():
            log.warning("Abilities directory not found: %s", abilities_dir)
            return

        package_base = "phoenix.abilities"
        for py_file in sorted(abilities_dir.glob("*.py")):
            if py_file.name.startswith("_"):
                continue
            module_name = f"{package_base}.{py_file.stem}"
            try:
                importlib.import_module(module_name)
            except Exception as e:
                log.warning("Failed to import ability %s: %s", module_name, e)

        self._abilities = dict(get_ability_registry())
        log.info("Discovered %d abilities: %s", len(self._abilities), list(self._abilities.keys()))

    def discover_agents(self, path: Path | None = None):
        """Scan personality/agents/*.yaml, parse each into AgentConfig."""
        agents_dir = path or _AGENTS_DIR
        if not agents_dir.is_dir():
            log.warning("Agents directory not found: %s", agents_dir)
            return

        for yaml_file in sorted(agents_dir.glob("*.yaml")):
            if yaml_file.name.startswith("_"):
                continue
            try:
                config = parse_agent(yaml_file)
                self._agents[config.name] = config
            except Exception as e:
                log.warning("Failed to parse agent %s: %s", yaml_file.name, e)

        log.info("Discovered %d agents: %s", len(self._agents), list(self._agents.keys()))

    def discover_all(self):
        self.discover_abilities()
        self.discover_agents()

    def get_ability(self, name: str) -> AbilityInfo | None:
        return self._abilities.get(name)

    def get_agent_config(self, name: str) -> AgentConfig | None:
        return self._agents.get(name)

    def list_abilities(self) -> list[str]:
        return list(self._abilities.keys())

    def list_agents(self) -> list[str]:
        return list(self._agents.keys())

    def get_agent_abilities(self, agent_name: str) -> list[AbilityInfo]:
        """Get the AbilityInfo objects for abilities listed in an agent's config."""
        config = self._agents.get(agent_name)
        if not config:
            return []
        abilities = []
        for name in config.abilities:
            info = self._abilities.get(name)
            if info:
                abilities.append(info)
            else:
                log.warning("Agent '%s' references unknown ability '%s'", agent_name, name)
        return abilities


_registry: Registry | None = None


def get_registry() -> Registry:
    """Get the global registry instance (lazy init, read-only after boot)."""
    global _registry
    if _registry is None:
        _registry = Registry()
    return _registry
