"""Interceptor -- wraps abilities with permissions, logging, error handling."""

import asyncio
import functools
import logging
from collections.abc import Callable
from typing import Any, Protocol, runtime_checkable

from phoenix.abilities import AbilityInfo, PhoenixContext

log = logging.getLogger(__name__)


@runtime_checkable
class ApprovalBackend(Protocol):
    async def request_approval(self, tool_name: str, description: str, details: dict) -> bool: ...
    async def ask_user(self, question: str, options: str = "") -> str: ...


class CLIApprovalBackend:
    """Interactive terminal approval."""

    def __init__(self):
        self._approved_all: set[str] = set()

    async def request_approval(self, tool_name: str, description: str, details: dict) -> bool:
        if tool_name in self._approved_all:
            return True
        detail_str = ""
        for k, v in details.items():
            detail_str += f"\n    {k}: {str(v)[:200]}"
        prompt = f"\n  [Approve] {tool_name}: {description}{detail_str}\n  (y)es / (n)o / (a)ll > "
        answer = await asyncio.to_thread(input, prompt)
        answer = answer.strip().lower()
        if answer in ("a", "all"):
            self._approved_all.add(tool_name)
            return True
        return answer in ("y", "yes", "")

    async def ask_user(self, question: str, options: str = "") -> str:
        prompt = f"\n  [Phoenix asks] {question}\n  > "
        return await asyncio.to_thread(input, prompt)


class AutoApprovalBackend:
    """Auto-approve based on mode: 'yolo' (all) or 'auto' (files yes, bash ask)."""

    def __init__(self, mode: str = "auto"):
        self.mode = mode

    async def request_approval(self, tool_name: str, description: str, details: dict) -> bool:
        if self.mode == "yolo":
            return True
        if self.mode == "auto" and tool_name in (
            "read_file",
            "write_file",
            "search_replace",
            "grep",
        ):
            return True
        prompt = f"\n  [Approve] {tool_name}: {description}\n  (y/n) > "
        answer = await asyncio.to_thread(input, prompt)
        return answer.strip().lower() in ("y", "yes", "")

    async def ask_user(self, question: str, options: str = "") -> str:
        prompt = f"\n  {question}\n  > "
        return await asyncio.to_thread(input, prompt)


# Module-level backend (default: CLI)
_backend: ApprovalBackend = CLIApprovalBackend()


def set_approval_backend(backend: ApprovalBackend):
    global _backend
    _backend = backend


def get_approval_backend() -> ApprovalBackend:
    return _backend


class Interceptor:
    """Wraps ability functions with cross-cutting concerns."""

    def __init__(self, hook_runner=None):
        self._hook_runner = hook_runner

    def wrap(
        self,
        ability_info: AbilityInfo,
        context: PhoenixContext | None = None,
    ) -> Callable:
        """Return a wrapped version of the ability function.

        The wrapper handles:
        - PRE_TOOL/POST_TOOL hooks (if hook_runner is set)
        - PhoenixContext injection (if ability needs it)
        - Logging
        - Error handling (returns error string, never raises)
        """
        import inspect

        func = ability_info.func
        needs_ctx = ability_info.needs_context
        name = ability_info.name
        hook_runner = self._hook_runner

        async def _run_func(*args, **kwargs) -> str:
            if needs_ctx and context:
                if ability_info.is_async:
                    return str(await func(context, *args, **kwargs))
                else:
                    return str(await asyncio.to_thread(func, context, *args, **kwargs))
            else:
                if ability_info.is_async:
                    return str(await func(*args, **kwargs))
                else:
                    return str(await asyncio.to_thread(func, *args, **kwargs))

        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> str:
            log.debug("ability.call: %s args=%s kwargs=%s", name, args, kwargs)

            # PRE_TOOL hook
            if hook_runner and hook_runner.has_hooks:
                from phoenix.hooks.runner import HookContext, HookEvent

                hr = await hook_runner.run(
                    HookEvent.PRE_TOOL,
                    HookContext(event=HookEvent.PRE_TOOL, tool_name=name, tool_args=kwargs),
                )
                if not hr.allow:
                    return f"(blocked by hook: {hr.feedback or 'denied'})"

            try:
                result = await _run_func(*args, **kwargs)
            except Exception as e:
                log.error("ability.error: %s -- %s", name, e)
                # ON_ERROR hook
                if hook_runner and hook_runner.has_hooks:
                    from phoenix.hooks.runner import HookContext, HookEvent

                    await hook_runner.run(
                        HookEvent.ON_ERROR,
                        HookContext(event=HookEvent.ON_ERROR, tool_name=name),
                    )
                return f"Error in {name}: {e}"

            # POST_TOOL hook
            if hook_runner and hook_runner.has_hooks:
                from phoenix.hooks.runner import HookContext, HookEvent

                await hook_runner.run(
                    HookEvent.POST_TOOL,
                    HookContext(
                        event=HookEvent.POST_TOOL,
                        tool_name=name,
                        tool_result=result[:200],
                    ),
                )

            return result

        wrapper.__name__ = func.__name__
        wrapper.__doc__ = func.__doc__

        # Strip PhoenixContext from signature so pydantic-ai
        # doesn't try to generate JSON schema for it.
        # The context is injected internally, invisible to the LLM.
        if needs_ctx:
            sig = inspect.signature(func)
            new_params = [
                p
                for p in sig.parameters.values()
                if p.annotation is not PhoenixContext and p.annotation != "PhoenixContext"
            ]
            wrapper.__signature__ = sig.replace(parameters=new_params)

        return wrapper
