"""Engine -- the central orchestrator that boots and runs Phoenix.

Context architecture:
  - Each request is nearly stateless. No full conversation history passed.
  - Context is ENGINEERED from three layers:
    1. Memory recall (cross-session facts, preferences, skills)
    2. Topic summaries (completed topics from this session)
    3. Active topic messages (only the current topic's messages)
  - Cost is FLAT: ~5-6k tokens per turn regardless of session length.
  - One LLM call per topic shift (~every 10 turns) for summarization.
"""

import logging
from typing import Any

from pydantic_ai import Agent

from phoenix.abilities import PhoenixContext
from phoenix.config.settings import PHOENIX_DIR, get_model
from phoenix.core.context import scan_project
from phoenix.core.delegate import delegate
from phoenix.core.factory import build_agent
from phoenix.core.reasoning import (
    classify_query,
    detect_stakes,
    get_reasoning_instruction,
)
from phoenix.core.registry import Registry, get_registry

log = logging.getLogger(__name__)

# Max pydantic-ai messages to keep in active history within a topic.
# ~10 turns = 20 messages (request + response per turn).
MAX_ACTIVE_HISTORY = 20

# On topic shift, keep only last N messages as bridge.
BRIDGE_MESSAGES = 4  # 2 turns


def _trim_history(history: list, keep_last: int) -> list:
    """Trim pydantic-ai message history, keeping last N messages.

    Ensures we don't split tool-call / tool-result pairs, which would
    cause OpenAI API errors. Scans backwards to find a safe cut point
    where a user turn starts (not a tool result continuation).
    """
    if len(history) <= keep_last:
        return history

    start = max(0, len(history) - keep_last)

    # Scan forward from start to find a safe boundary.
    # A safe boundary is a ModelRequest that starts with a UserPromptPart,
    # not a ToolReturnPart (which must follow a tool_calls response).
    try:
        from pydantic_ai.messages import ModelRequest, ToolReturnPart

        while start < len(history) - 2:
            msg = history[start]
            if isinstance(msg, ModelRequest):
                has_tool_return = any(isinstance(p, ToolReturnPart) for p in msg.parts)
                if not has_tool_return:
                    break  # safe cut point
            start += 1
    except ImportError:
        # Fallback: align to even boundary
        if start % 2 != 0:
            start += 1

    return history[start:]


class PhoenixEngine:
    """Central orchestrator -- boots the system, manages the agent lifecycle."""

    def __init__(self):
        self._registry: Registry | None = None
        self._agent: Agent | None = None
        self._project_context: str = ""
        self._memory: Any = None
        self._topic_tracker: Any = None

    async def boot(
        self,
        memory: Any = None,
        hook_runner=None,
        session_id: str = "",
        session_summary: str = "",
    ):
        """Initialize the engine: discover plugins, build brain agent."""
        self._memory = memory
        self._hook_runner = hook_runner
        self._session_summary = session_summary
        self._registry = get_registry()
        self._registry.discover_all()

        self._project_context = scan_project()

        # Initialize topic tracker
        from phoenix.memory.session import TopicTracker

        self._topic_tracker = TopicTracker(
            model=get_model(),
            session_id=session_id,
        )

        context = PhoenixContext(
            config={"phoenix_dir": str(PHOENIX_DIR), "model": get_model()},
            memory=self._memory,
            agent_name="brain",
        )

        self._agent = build_agent(
            agent_name="brain",
            registry=self._registry,
            project_context=self._project_context,
            extra_tools=[delegate],
            phoenix_context=context,
            hook_runner=hook_runner,
        )

        abilities = self._registry.list_abilities()
        agents = self._registry.list_agents()
        log.info(
            "Phoenix booted: %d abilities, %d agents",
            len(abilities),
            len(agents),
        )

    @property
    def agent(self) -> Agent:
        if self._agent is None:
            raise RuntimeError("Engine not booted. Call boot() first.")
        return self._agent

    @property
    def registry(self) -> Registry:
        if self._registry is None:
            raise RuntimeError("Engine not booted. Call boot() first.")
        return self._registry

    @property
    def topic_tracker(self):
        return self._topic_tracker

    def _build_engineered_context(self, user_input: str, memory_context: str) -> str:
        """Build the engineered context from all three layers."""
        parts = []

        # Layer 1: Previous session summary (if --continue)
        if self._session_summary:
            parts.append(f"[Previous session]\n{self._session_summary}")

        # Layer 2: Memory recall (cross-session facts)
        if memory_context:
            parts.append(memory_context)

        # Layer 3: Topic summaries (completed topics this session)
        if self._topic_tracker:
            topic_ctx = self._topic_tracker.build_context()
            if topic_ctx:
                parts.append(f"[Session context]\n{topic_ctx}")

        # Query classification + reasoning instruction
        query_type = classify_query(user_input)
        reasoning = get_reasoning_instruction(query_type)
        if reasoning:
            parts.append(reasoning)

        # User message
        parts.append(user_input)

        return "\n\n".join(parts)

    async def run_stream(
        self,
        user_input: str,
        history: list | None = None,
    ):
        """Execute a turn and yield live events.

        Yields typed tuples (kind, *payload) for the TUI to dispatch:
          ("text", delta: str)
              A streaming text chunk from the assistant response.
          ("tool_call", tool_call_id: str, name: str, args: Any)
              Model decided to call a tool. Render a spinner widget keyed by id.
          ("tool_result", tool_call_id: str, content: str, is_error: bool)
              Tool returned. Transition the spinner widget into a result body.
              is_error=True when pydantic-ai wrapped the tool return in a
              RetryPromptPart (tool raised or returned a retry).

        Uses pydantic-ai 1.80 `run_stream_events` so tool events appear in
        order while streaming, instead of being reconstructed retroactively
        from `stream.all_messages()` after the fact (which put tool widgets
        below the assistant response in the UI).

        The history parameter is the ACTIVE TOPIC's messages only, not the
        full conversation history.
        """
        from pydantic_ai.messages import (
            FunctionToolCallEvent,
            FunctionToolResultEvent,
            PartDeltaEvent,
            RetryPromptPart,
            TextPartDelta,
        )
        from pydantic_ai.run import AgentRunResultEvent

        # Memory pre-turn -- native async via aiosqlite. SQLite runs on
        # aiosqlite's single internal worker thread, so the event loop isn't
        # blocked. No more asyncio.to_thread wrapper needed.
        memory_context = ""
        if self._memory and hasattr(self._memory, "pre_turn"):
            try:
                memory_context = await self._memory.pre_turn(user_input)
            except Exception as e:
                log.warning("Memory pre_turn failed: %s", e)

        # Build engineered context (replaces raw history)
        prompt = self._build_engineered_context(user_input, memory_context)

        # Use only active topic messages as history (not full conversation)
        active_history = history or []

        import time as _time

        chunks: list[str] = []
        final_usage = None
        final_messages: list = []

        turn_start = _time.monotonic()
        log.info(
            "turn.start: model=%s history=%d mem_ctx=%dB prompt=%dB",
            get_model(),
            len(active_history),
            len(memory_context),
            len(prompt),
        )

        async for event in self.agent.run_stream_events(prompt, message_history=active_history):
            if isinstance(event, PartDeltaEvent) and isinstance(event.delta, TextPartDelta):
                delta = event.delta.content_delta
                if delta:
                    chunks.append(delta)
                    yield ("text", delta)
            elif isinstance(event, FunctionToolCallEvent):
                yield (
                    "tool_call",
                    event.part.tool_call_id,
                    event.part.tool_name,
                    event.part.args,
                )
            elif isinstance(event, FunctionToolResultEvent):
                is_error = isinstance(event.result, RetryPromptPart)
                content = getattr(event.result, "content", "")
                if not isinstance(content, str):
                    try:
                        import json as _json

                        content = _json.dumps(content, default=str)
                    except Exception:
                        content = str(content)
                yield (
                    "tool_result",
                    event.result.tool_call_id,
                    content,
                    is_error,
                )
            elif isinstance(event, AgentRunResultEvent):
                try:
                    final_usage = event.result.usage()
                except Exception:
                    final_usage = None
                try:
                    final_messages = event.result.all_messages()
                except Exception:
                    final_messages = []

        full_output = "".join(chunks)
        stakes = detect_stakes(user_input)
        if stakes:
            full_output = f"{stakes}\n\n{full_output}"

        self._last_usage = final_usage
        self._last_output = full_output
        self._last_history = final_messages
        self._last_user_input = user_input

        inp_tok = getattr(final_usage, "request_tokens", 0) or 0
        out_tok = getattr(final_usage, "response_tokens", 0) or 0
        log.info(
            "turn.done: dur=%.2fs out=%dB in_tok=%d out_tok=%d",
            _time.monotonic() - turn_start,
            len(full_output),
            inp_tok,
            out_tok,
        )

    async def run_after_stream(self) -> None:
        """Post-stream work (memory consolidation + topic tracking + history
        trimming). Called by the TUI worker AFTER run_stream's async-for loop
        exits, so the heartbeat indicator can be stopped first. No UI updates
        are implied by this method -- it's bookkeeping only.
        """
        user_input = getattr(self, "_last_user_input", "")
        full_output = getattr(self, "_last_output", "")
        if not user_input:
            return

        if self._memory and hasattr(self._memory, "post_turn"):
            try:
                await self._memory.post_turn(user_input, full_output)
            except Exception as e:
                log.warning("Memory post_turn failed: %s", e)

        if self._topic_tracker:
            completed_before = self._topic_tracker.completed_count
            try:
                await self._topic_tracker.process_turn(
                    user_input=user_input,
                    ai_output=full_output,
                )
            except Exception as e:
                log.warning("Topic tracker failed: %s", e)

            if self._topic_tracker.completed_count > completed_before:
                self._last_history = _trim_history(self._last_history, keep_last=BRIDGE_MESSAGES)
                log.info(
                    "Topic shifted -> trimmed history to %d messages",
                    len(self._last_history),
                )

    async def create_session_summary(self) -> str | None:
        """Create a session summary on exit. Store in memory."""
        if not self._topic_tracker:
            return None

        summary = await self._topic_tracker.create_session_summary()
        if summary and self._memory:
            try:
                await self._memory.post_turn(
                    user_input=f"[Session summary] {summary}",
                    ai_output="",
                    namespace="sessions",
                )
            except Exception as e:
                log.warning("Failed to store session summary: %s", e)

        return summary

    @property
    def last_output(self) -> str:
        return getattr(self, "_last_output", "")

    @property
    def last_history(self) -> list:
        return getattr(self, "_last_history", [])

    @property
    def last_usage(self):
        return getattr(self, "_last_usage", None)
