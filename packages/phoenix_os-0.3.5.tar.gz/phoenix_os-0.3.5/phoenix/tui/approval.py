"""TUI approval backend -- uses a Textual modal instead of stdin input()."""

from __future__ import annotations

import asyncio

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Label, Static


class ApprovalModal(ModalScreen[str]):
    """Returns 'yes', 'no', or 'all'."""

    DEFAULT_CSS = """
    ApprovalModal {
        align: center middle;
    }
    #box {
        width: 70%;
        max-width: 90;
        height: auto;
        background: $panel;
        border: thick #ff6b35;
        padding: 1 2;
    }
    #title {
        color: #ffaf5f;
        text-style: bold;
        margin-bottom: 1;
    }
    #body {
        color: $text;
        margin-bottom: 1;
    }
    #details {
        color: $text-muted;
        margin-bottom: 1;
    }
    #btnrow {
        height: 3;
        align-horizontal: center;
    }
    Button {
        margin: 0 1;
    }
    """

    BINDINGS = [
        Binding("y", "answer('yes')", show=False),
        Binding("n", "answer('no')", show=False),
        Binding("a", "answer('all')", show=False),
        Binding("escape", "answer('no')", show=False),
        Binding("enter", "answer('yes')", show=False, priority=True),
    ]

    def __init__(self, tool_name: str, description: str, details: dict) -> None:
        super().__init__()
        self._tool_name = tool_name
        self._description = description
        self._details = details

    def compose(self) -> ComposeResult:
        with Vertical(id="box"):
            yield Label(f"Approve {self._tool_name}?", id="title")
            yield Static(self._description, id="body")
            if self._details:
                lines = []
                for k, v in list(self._details.items())[:4]:
                    lines.append(f"{k}: {str(v)[:160]}")
                yield Static("\n".join(lines), id="details")
            with Horizontal(id="btnrow"):
                yield Button("Yes (y)", variant="success", id="yes")
                yield Button("No (n)", variant="error", id="no")
                yield Button("All (a)", variant="primary", id="all")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss(event.button.id or "no")

    def action_answer(self, ans: str) -> None:
        self.dismiss(ans)


class AskUserModal(ModalScreen[str]):
    """Returns the user's text response."""

    DEFAULT_CSS = """
    AskUserModal {
        align: center middle;
    }
    #box {
        width: 70%;
        max-width: 90;
        height: auto;
        background: $panel;
        border: thick #ff6b35;
        padding: 1 2;
    }
    #title {
        color: #ffaf5f;
        text-style: bold;
        margin-bottom: 1;
    }
    #question {
        color: $text;
        margin-bottom: 1;
    }
    """

    BINDINGS = [
        Binding("escape", "cancel", show=False),
    ]

    def __init__(self, question: str, options: str = "") -> None:
        super().__init__()
        self._question = question
        self._options = options

    def compose(self) -> ComposeResult:
        from textual.widgets import Input

        with Vertical(id="box"):
            yield Label("Phoenix asks:", id="title")
            yield Static(self._question, id="question")
            if self._options:
                yield Static(f"Options: {self._options}", id="details")
            yield Input(placeholder="your answer...", id="answer")

    def on_input_submitted(self, event) -> None:
        self.dismiss(event.value or "")

    def action_cancel(self) -> None:
        self.dismiss("")


class TUIApprovalBackend:
    """Approval backend that uses Textual modals instead of stdin."""

    def __init__(self, app) -> None:
        self._app = app
        self._approved_all: set[str] = set()
        try:
            self._loop = asyncio.get_running_loop()
        except RuntimeError:
            self._loop = None

    def _make_future(self) -> asyncio.Future[str]:
        loop = self._loop or asyncio.get_running_loop()
        return loop.create_future()

    async def request_approval(self, tool_name: str, description: str, details: dict) -> bool:
        if tool_name in self._approved_all:
            return True

        future: asyncio.Future[str] = self._make_future()

        async def _run():
            result = await self._app.push_screen_wait(
                ApprovalModal(tool_name, description, details)
            )
            if not future.done():
                future.set_result(result or "no")

        self._app.run_worker(_run(), group="approval", exclusive=False)
        answer = await future
        if answer == "all":
            self._approved_all.add(tool_name)
            return True
        return answer == "yes"

    async def ask_user(self, question: str, options: str = "") -> str:
        future: asyncio.Future[str] = self._make_future()

        async def _run():
            result = await self._app.push_screen_wait(AskUserModal(question, options))
            if not future.done():
                future.set_result(result or "")

        self._app.run_worker(_run(), group="ask-user", exclusive=False)
        return await future
