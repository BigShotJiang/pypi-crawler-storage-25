"""Textual messages for Phoenix TUI -- passed from workers to the App."""

from __future__ import annotations

from typing import Any

from textual.message import Message


class StreamStart(Message):
    """Marks the beginning of an assistant response."""


class StreamChunk(Message):
    def __init__(self, text: str) -> None:
        self.text = text
        super().__init__()


class StreamEnd(Message):
    """Assistant response finished. Full text for final markdown render."""

    def __init__(self, full_text: str) -> None:
        self.full_text = full_text
        super().__init__()


class ToolCallEvent(Message):
    def __init__(self, name: str, args: Any, tool_call_id: str = "") -> None:
        self.name = name
        self.args = args
        # tool_call_id links the call to its later result so the TUI can
        # transition one widget in place rather than rendering two.
        self.tool_call_id = tool_call_id
        super().__init__()


class ToolResultEvent(Message):
    def __init__(
        self,
        name: str,
        result: str,
        tool_call_id: str = "",
        is_error: bool = False,
    ) -> None:
        self.name = name
        self.result = result
        self.tool_call_id = tool_call_id
        self.is_error = is_error
        super().__init__()


class TurnUsage(Message):
    def __init__(self, input_tokens: int, output_tokens: int) -> None:
        self.input = input_tokens
        self.output = output_tokens
        super().__init__()


class TurnError(Message):
    def __init__(self, text: str) -> None:
        self.text = text
        super().__init__()


class TurnDone(Message):
    """Marks the turn complete (for UI cleanup / focus)."""


class StatusMessage(Message):
    def __init__(self, text: str) -> None:
        self.text = text
        super().__init__()


class NotificationMessage(Message):
    def __init__(self, text: str) -> None:
        self.text = text
        super().__init__()


class ChatInputSubmitted(Message):
    def __init__(self, text: str) -> None:
        self.text = text
        super().__init__()


class WorkingStart(Message):
    """Stream stalled (probably executing a tool). Show live indicator."""


class WorkingEnd(Message):
    """Work resumed or turn finished -- remove the indicator."""


class BugReportDone(Message):
    """Dispatched when the /report-bug background worker finishes. Carries the
    SubmitResult as `result` (plain object, no pydantic-ai coupling)."""

    def __init__(self, result: Any) -> None:
        self.result = result
        super().__init__()
