"""Phoenix TUI -- Textual-based terminal interface."""

from phoenix.tui.app import run_tui

__all__ = ["run_tui"]
