"""Classifiers -- zero-LLM category/dimension/intent detection via anchor embeddings."""

import logging
from collections.abc import Callable

import numpy as np

from .config import CATEGORY_ANCHORS, DIMENSION_ANCHORS, INTENT_ANCHORS, MemoryParams

log = logging.getLogger(__name__)


class AnchorClassifier:
    """Classify text by cosine similarity to pre-embedded anchor examples."""

    def __init__(self, anchors: dict[str, list[str]], threshold: float = 0.0):
        self._anchors = anchors
        self._threshold = threshold
        self._centroids: dict[str, np.ndarray] = {}
        self._initialized = False

    def initialize(self, embed_fn: Callable[[str], np.ndarray]):
        """Compute centroids from anchor examples. Call once at startup."""
        for category, examples in self._anchors.items():
            vecs = [embed_fn(text) for text in examples]
            centroid = np.mean(vecs, axis=0)
            norm = float(np.linalg.norm(centroid))
            if norm > 1e-9:
                centroid = centroid / norm
            self._centroids[category] = centroid
        self._initialized = True
        log.debug("AnchorClassifier initialized with %d categories", len(self._centroids))

    def classify(self, embedding: np.ndarray) -> tuple[str, float]:
        """Returns (best_category, confidence). Always returns a category."""
        if not self._initialized:
            return "fact", 0.0
        best_cat = "fact"
        best_score = -1.0
        for cat, centroid in self._centroids.items():
            score = float(np.dot(embedding, centroid))
            if score > best_score:
                best_score = score
                best_cat = cat
        if self._threshold > 0 and best_score < self._threshold:
            return "fact", 0.0
        return best_cat, max(best_score, 0.0)

    def get_scores(self, embedding: np.ndarray) -> dict[str, float]:
        """Return scores for all categories."""
        if not self._initialized:
            return {}
        return {
            cat: float(np.dot(embedding, centroid)) for cat, centroid in self._centroids.items()
        }

    @property
    def categories(self) -> list[str]:
        return list(self._centroids.keys())

    @property
    def centroids(self) -> dict[str, np.ndarray]:
        return self._centroids


class DimensionClassifier(AnchorClassifier):
    """Classifies into life dimensions (body/mind/craft/people/legacy)."""

    def classify(self, embedding: np.ndarray) -> tuple[str | None, float]:
        if not self._initialized:
            return None, 0.0
        best_dim = None
        best_score = -1.0
        for dim, centroid in self._centroids.items():
            score = float(np.dot(embedding, centroid))
            if score > best_score:
                best_score = score
                best_dim = dim
        if best_score < self._threshold:
            return None, 0.0
        return best_dim, max(best_score, 0.0)


class IntentClassifier(AnchorClassifier):
    """Classifies intent (planning/venting/reflecting/excited/requesting)."""

    def classify(self, embedding: np.ndarray) -> tuple[str | None, float]:
        if not self._initialized:
            return None, 0.0
        best_intent = None
        best_score = -1.0
        for intent, centroid in self._centroids.items():
            score = float(np.dot(embedding, centroid))
            if score > best_score:
                best_score = score
                best_intent = intent
        if best_score < self._threshold:
            return None, 0.0
        return best_intent, max(best_score, 0.0)


def build_classifiers(
    config: MemoryParams,
    embed_fn: Callable[[str], np.ndarray],
) -> tuple[AnchorClassifier, DimensionClassifier, IntentClassifier]:
    """Build and initialize all three classifiers."""
    cat_clf = AnchorClassifier(CATEGORY_ANCHORS)
    dim_clf = DimensionClassifier(DIMENSION_ANCHORS, threshold=config.dimension_threshold)
    intent_clf = IntentClassifier(INTENT_ANCHORS, threshold=config.intent_threshold)

    cat_clf.initialize(embed_fn)
    dim_clf.initialize(embed_fn)
    intent_clf.initialize(embed_fn)

    return cat_clf, dim_clf, intent_clf
