"""Bug reporting -- gather diagnostics, scrub PII, submit to Phoenix's
Cloudflare Worker which opens a GitHub issue on the user's behalf.

Never use this module to leak raw logs. Everything user-visible goes through
`scrub.scrub_line` or `scrub.scrub_text` before it leaves this process.
"""

from phoenix.report.bundle import ReportBundle, build_bundle
from phoenix.report.submit import LOCAL_REPORT_DIR, SubmitResult, submit

__all__ = ["ReportBundle", "SubmitResult", "build_bundle", "submit", "LOCAL_REPORT_DIR"]
