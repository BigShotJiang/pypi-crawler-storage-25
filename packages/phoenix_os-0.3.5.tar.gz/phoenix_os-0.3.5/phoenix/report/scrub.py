"""PII / secret scrubbing for bug reports.

Runs BEFORE anything leaves the user's machine. Defense in depth: the
Cloudflare Worker re-runs a subset of these, but Phoenix is the primary
gatekeeper because raw user content must never hit the wire.

Scrub rules:
  - API keys: OpenAI, Anthropic, Google, GitHub, Slack, HuggingFace, "Bearer"
  - User home paths on any OS -> <HOME>
  - Long lines (>MAX_LINE_LEN) truncated
  - Email addresses -> <EMAIL>
"""

from __future__ import annotations

import getpass
import os
import re
from pathlib import Path

MAX_LINE_LEN = 500

# Compiled once at import -- these run on every log line.
_SECRET_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    # More-specific `sk-` variants MUST come before the generic OpenAI pattern
    # or the broad sk- regex swallows them first.
    (re.compile(r"sk-ant-[A-Za-z0-9_\-]{20,}"), "<ANTHROPIC_KEY>"),
    (re.compile(r"sk-or-[A-Za-z0-9_\-]{20,}"), "<OPENROUTER_KEY>"),
    (re.compile(r"sk-[A-Za-z0-9_\-]{20,}"), "<OPENAI_KEY>"),
    # Google / Gemini
    (re.compile(r"AIza[A-Za-z0-9_\-]{30,}"), "<GOOGLE_KEY>"),
    # GitHub
    (re.compile(r"ghp_[A-Za-z0-9]{30,}"), "<GITHUB_PAT>"),
    (re.compile(r"github_pat_[A-Za-z0-9_]{40,}"), "<GITHUB_PAT>"),
    # Slack
    (re.compile(r"xox[aboprs]-[A-Za-z0-9\-]{20,}"), "<SLACK_TOKEN>"),
    # HuggingFace
    (re.compile(r"hf_[A-Za-z0-9]{30,}"), "<HF_TOKEN>"),
    # Groq
    (re.compile(r"gsk_[A-Za-z0-9]{30,}"), "<GROQ_KEY>"),
    # Bearer headers
    (re.compile(r"[Bb]earer\s+[A-Za-z0-9_\-\.=]{15,}"), "Bearer <TOKEN>"),
    # Authorization: Basic
    (re.compile(r"[Bb]asic\s+[A-Za-z0-9+/=]{20,}"), "Basic <TOKEN>"),
    # Brave Search
    (re.compile(r"BSA[A-Za-z0-9_\-]{20,}"), "<BRAVE_KEY>"),
    # Email addresses
    (
        re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}"),
        "<EMAIL>",
    ),
]


def _home_path_patterns() -> list[tuple[re.Pattern[str], str]]:
    """Build user-specific home-path regexes at scrub time, not import time,
    so tests can set HOME via monkeypatch and we pick it up."""
    patterns: list[tuple[re.Pattern[str], str]] = []
    try:
        user = getpass.getuser()
    except Exception:
        user = ""
    home = str(Path.home())

    # Order matters -- match the longest/most specific first.
    if home:
        patterns.append((re.compile(re.escape(home)), "<HOME>"))
    if user:
        # macOS / Linux
        patterns.append((re.compile(re.escape(f"/Users/{user}")), "<HOME>"))
        patterns.append((re.compile(re.escape(f"/home/{user}")), "<HOME>"))
        # Windows (escape backslashes for regex)
        patterns.append((re.compile(re.escape(f"C:\\Users\\{user}"), re.IGNORECASE), "<HOME>"))
        # Bare username token inside paths (rarer, last-resort)
        patterns.append((re.compile(rf"\b{re.escape(user)}\b"), "<USER>"))

    return patterns


def scrub_text(text: str) -> str:
    """Scrub a multi-line text block. Used for log tails and description fields."""
    if not text:
        return text

    lines = text.splitlines()
    out = [scrub_line(line) for line in lines]
    return "\n".join(out)


def scrub_line(line: str) -> str:
    """Scrub a single line. Truncates if too long."""
    if not line:
        return line

    for pat, repl in _SECRET_PATTERNS:
        line = pat.sub(repl, line)

    for pat, repl in _home_path_patterns():
        line = pat.sub(repl, line)

    if len(line) > MAX_LINE_LEN:
        line = line[:MAX_LINE_LEN] + f" <truncated {len(line) - MAX_LINE_LEN} chars>"

    return line


def scrub_env_summary() -> dict[str, str]:
    """Return a dict describing WHICH env keys are set, never the values.

    Used so the bug report can say "ANTHROPIC_API_KEY: set, GEMINI_API_KEY: not set"
    without leaking any actual keys.
    """
    keys = (
        "ANTHROPIC_API_KEY",
        "OPENAI_API_KEY",
        "GEMINI_API_KEY",
        "GOOGLE_API_KEY",
        "GROQ_API_KEY",
        "OPENROUTER_API_KEY",
        "MISTRAL_API_KEY",
        "DEEPSEEK_API_KEY",
        "HF_TOKEN",
        "BRAVE_API_KEY",
        "PHOENIX_MODEL",
        "PHOENIX_MEMORY_DB",
        "PHOENIX_EMBEDDING_BACKEND",
        "PHOENIX_LOG_LEVEL",
    )
    return {k: ("set" if os.environ.get(k) else "not set") for k in keys}
