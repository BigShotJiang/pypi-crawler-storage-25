"""Builds a ReportBundle -- the payload that gets sent to the Cloudflare Worker."""

from __future__ import annotations

import platform as _platform
import sys
from dataclasses import dataclass, field

from phoenix import __version__
from phoenix.report.scrub import scrub_env_summary, scrub_text

# How many tail lines of ~/.phoenix/logs/phoenix.log to attach. Matches the
# default log rotation's file size so we cover roughly "one session".
DEFAULT_LOG_TAIL = 500


@dataclass
class ReportBundle:
    """Everything we send. Keep this small + flat so Worker-side parsing is trivial."""

    description: str
    phoenix_version: str
    python_version: str
    platform: str
    model: str
    env: dict[str, str]
    log_tail: str
    log_lines_included: int

    # Internal flag set by scrub; prevents double-scrubbing downstream.
    scrubbed: bool = field(default=True)

    def to_dict(self) -> dict:
        return {
            "description": self.description,
            "phoenix_version": self.phoenix_version,
            "python_version": self.python_version,
            "platform": self.platform,
            "model": self.model,
            "env": self.env,
            "log_tail": self.log_tail,
            "log_lines_included": self.log_lines_included,
            "scrubbed": self.scrubbed,
        }

    def to_markdown(self) -> str:
        """Human-readable rendering. Used for the GitHub issue body and the
        in-TUI preview before submit."""
        env_list = "\n".join(f"- `{k}`: {v}" for k, v in self.env.items())
        body = (
            f"## What went wrong\n"
            f"{self.description}\n\n"
            f"## Environment\n"
            f"- Phoenix: `{self.phoenix_version}`\n"
            f"- Python: `{self.python_version}`\n"
            f"- Platform: `{self.platform}`\n"
            f"- Model: `{self.model}`\n\n"
            f"## Env keys\n"
            f"{env_list}\n\n"
            f"## Log tail ({self.log_lines_included} lines, scrubbed)\n"
            f"```\n{self.log_tail}\n```\n"
        )
        return body


def build_bundle(description: str, tail_lines: int = DEFAULT_LOG_TAIL) -> ReportBundle:
    """Collect system info + scrubbed log tail. Safe to call from anywhere."""
    from phoenix.config.settings import get_model
    from phoenix.logging_setup import tail

    try:
        model = get_model()
    except Exception:
        model = "<unknown>"

    raw_log = tail(tail_lines)
    scrubbed_log = scrub_text(raw_log)
    scrubbed_desc = scrub_text(description.strip())
    log_lines = len(scrubbed_log.splitlines()) if scrubbed_log else 0

    return ReportBundle(
        description=scrubbed_desc,
        phoenix_version=__version__,
        python_version=sys.version.split()[0],
        platform=f"{_platform.system()} {_platform.release()} ({_platform.machine()})",
        model=model,
        env=scrub_env_summary(),
        log_tail=scrubbed_log,
        log_lines_included=log_lines,
    )
