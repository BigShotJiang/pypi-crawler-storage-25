"""PDF text extraction."""

import os

from phoenix.abilities import ability

MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB
MAX_CHARS = 100_000


@ability(name="read_pdf", description="Extract text from PDF files")
def read_pdf(path: str, pages: str = "") -> str:
    """Extract text from a PDF file.

    Args:
        path: Path to the PDF file.
        pages: Page selection (e.g. "1-5", "1,3,7"). 1-indexed. Empty = all pages.
    """
    try:
        import pymupdf
    except ImportError:
        return "Error: pymupdf not installed. Run: pip install pymupdf"

    path = os.path.expanduser(path)
    if not os.path.isabs(path):
        path = os.path.abspath(path)
    if not os.path.exists(path):
        return f"Error: file not found: {path}"

    file_size = os.path.getsize(path)
    if file_size > MAX_FILE_SIZE:
        return f"Error: file too large ({file_size // 1024 // 1024}MB, max 50MB)"

    try:
        doc = pymupdf.open(path)
    except Exception as e:
        return f"Error opening PDF: {e}"

    total_pages = len(doc)
    page_indices = _parse_pages(pages, total_pages)

    text_parts = []
    chars = 0
    for i in page_indices:
        if i >= total_pages:
            continue
        page_text = doc[i].get_text()
        text_parts.append(f"--- Page {i + 1} ---\n{page_text}")
        chars += len(page_text)
        if chars > MAX_CHARS:
            text_parts.append("... (truncated)")
            break

    doc.close()

    if not text_parts:
        return f"No text extracted from {path} ({total_pages} pages)"

    header = f"[{path}] {total_pages} pages"
    if pages:
        header += f", showing: {pages}"
    return f"{header}\n\n" + "\n".join(text_parts)


def _parse_pages(pages_str: str, total: int) -> list[int]:
    """Parse page selection string into 0-indexed page indices."""
    if not pages_str.strip():
        return list(range(total))

    indices = []
    for part in pages_str.split(","):
        part = part.strip()
        if "-" in part:
            try:
                start, end = part.split("-", 1)
                start = int(start) - 1
                end = int(end) - 1
                indices.extend(range(max(0, start), min(end + 1, total)))
            except ValueError:
                continue
        else:
            try:
                indices.append(int(part) - 1)
            except ValueError:
                continue
    return indices
