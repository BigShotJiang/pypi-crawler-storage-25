"""Pattern search using ripgrep or grep fallback."""

import os
import shutil
import subprocess

from phoenix.abilities import ability

MAX_OUTPUT = 64_000
DEFAULT_MAX_MATCHES = 100
TIMEOUT = 60

EXCLUDE_DIRS = [
    ".git",
    "node_modules",
    "__pycache__",
    ".venv",
    "venv",
    ".mypy_cache",
    ".pytest_cache",
    "dist",
    "build",
    ".next",
]


def _build_command(pattern: str, path: str, max_matches: int) -> list[str] | None:
    if shutil.which("rg"):
        cmd = [
            "rg",
            "--line-number",
            "--no-heading",
            "--smart-case",
            "--no-binary",
            f"--max-count={max_matches + 1}",
        ]
        for d in EXCLUDE_DIRS:
            cmd.extend(["--glob", f"!{d}"])
        cmd.extend(["-e", pattern, path])
        return cmd

    if shutil.which("grep"):
        cmd = ["grep", "-r", "-n", "-I", "-E", f"--max-count={max_matches + 1}"]
        for d in EXCLUDE_DIRS:
            cmd.extend(["--exclude-dir", d])
        if pattern == pattern.lower():
            cmd.append("-i")
        cmd.extend(["-e", pattern, path])
        return cmd

    return None


@ability(name="grep", description="Search files for patterns using regex")
def grep(pattern: str, path: str = ".", max_matches: int = DEFAULT_MAX_MATCHES) -> str:
    """Search files recursively for a regex pattern.

    Args:
        pattern: Regex pattern to search for.
        path: Directory or file to search. Defaults to current directory.
        max_matches: Max matching lines to return. Default 100.
    """
    if not pattern:
        return "Error: pattern cannot be empty"

    path = os.path.expanduser(path)
    if not os.path.isabs(path):
        path = os.path.abspath(path)
    if not os.path.exists(path):
        return f"Error: path not found: {path}"

    cmd = _build_command(pattern, path, max_matches)
    if not cmd:
        return "Error: neither 'rg' (ripgrep) nor 'grep' found"

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=TIMEOUT)
        if result.returncode not in (0, 1):
            return f"Error: {result.stderr.strip()[:500]}"
        if result.returncode == 1:
            return "No matches found."

        lines = result.stdout.strip().splitlines()
        truncated = len(lines) > max_matches
        lines = lines[:max_matches]
        output = "\n".join(lines)

        if len(output.encode("utf-8")) > MAX_OUTPUT:
            output = output.encode("utf-8")[:MAX_OUTPUT].decode("utf-8", errors="ignore")
            truncated = True

        header = f"[{len(lines)} matches"
        if truncated:
            header += ", truncated"
        header += "]"
        return f"{header}\n{output}"

    except subprocess.TimeoutExpired:
        return f"Error: search timed out after {TIMEOUT}s"
    except Exception as e:
        return f"Error: {e}"
