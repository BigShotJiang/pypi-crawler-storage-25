"""Claude Code CLI integration -- delegates coding tasks to Claude Code.

Silent execution -- no prints, no spinners. The main UI handles
visual feedback (thinking spinner, bg task status). This ability
just runs the subprocess and returns the result.
"""

import asyncio
import json
import logging
import os
import shutil
import time

from phoenix.abilities import ability

log = logging.getLogger(__name__)


def _find_claude() -> str | None:
    return shutil.which("claude")


@ability(
    name="claude_code",
    description="Delegate complex coding tasks to Claude Code CLI",
)
async def claude_code(prompt: str, workdir: str = "") -> str:
    """Delegate a coding task to Claude Code CLI with full codebase context.

    Use this for substantial coding work: generating files, editing code,
    refactoring, debugging, building projects. Give a detailed prompt
    describing exactly what you want built/fixed/changed.

    Args:
        prompt: Detailed task description for Claude Code.
        workdir: Working directory. Defaults to current directory.
    """
    claude_bin = _find_claude()
    if not claude_bin:
        return (
            "Error: 'claude' CLI not found. Install with: npm install -g @anthropic-ai/claude-code"
        )

    from phoenix.core.interceptor import get_approval_backend

    backend = get_approval_backend()
    first_line = prompt.strip().splitlines()[0][:100]
    approved = await backend.request_approval(
        "claude_code",
        f"Run Claude Code: {first_line}",
        {"prompt": prompt.strip(), "workdir": workdir or os.getcwd()},
    )
    if not approved:
        return "Cancelled by user."

    cwd = workdir or os.getcwd()
    cmd = [
        claude_bin,
        "-p",
        "--output-format",
        "json",
        "--dangerously-skip-permissions",
        "--max-turns",
        "25",
        prompt,
    ]

    log.info("Claude Code starting in %s", cwd)
    start_time = time.time()

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=cwd,
            start_new_session=True,
        )
        stdout, stderr = await proc.communicate()

        elapsed = int(time.time() - start_time)
        mins, secs = divmod(elapsed, 60)
        ts = f"{mins}m{secs}s" if mins else f"{secs}s"

        output = stdout.decode("utf-8", errors="replace").strip()
        err_output = stderr.decode("utf-8", errors="replace").strip()

        if not output and proc.returncode != 0:
            return f"Error: Claude Code exited with code {proc.returncode}. {err_output}"

        try:
            data = json.loads(output)
            result_text = data.get("result", "")
            session_id = data.get("session_id", "")
            cost = data.get("cost_usd", "")

            meta = []
            if session_id:
                meta.append(f"session: {session_id[:8]}")
            if cost:
                meta.append(f"${cost}")
            meta.append(ts)
            meta_str = f" [{', '.join(meta)}]" if meta else ""

            log.info("Claude Code done %s", meta_str)
            return (result_text or output) + f"\n\n(Claude Code{meta_str})"
        except json.JSONDecodeError:
            log.info("Claude Code done in %s", ts)
            return output or f"(no output, exit code {proc.returncode})"

    except FileNotFoundError:
        log.error("Claude Code binary not found at %s", claude_bin)
        return "Error: 'claude' binary not found"
    except Exception as e:
        log.exception("Claude Code failed")
        return f"Error running Claude Code: {e}"
