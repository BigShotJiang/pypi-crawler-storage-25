"""Ask the user a question -- human-in-the-loop ability."""

import asyncio

from phoenix.abilities import ability


@ability(name="ask_user", description="Ask the user a question when genuinely ambiguous")
async def ask_user(question: str, options: str = "") -> str:
    """Ask Boss a question. Use sparingly -- only when genuinely ambiguous.

    Args:
        question: The question to ask.
        options: Comma-separated choices (optional). Empty = free-text answer.
    """
    if options:
        prompt = f"\n  [Phoenix asks] {question}\n  Options: {options}\n  > "
    else:
        prompt = f"\n  [Phoenix asks] {question}\n  > "

    answer = await asyncio.to_thread(input, prompt)
    return answer.strip()
