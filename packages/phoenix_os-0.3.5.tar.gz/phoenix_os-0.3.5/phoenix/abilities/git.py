"""Read-only git operations."""

import subprocess

from phoenix.abilities import ability

ACTIONS = {
    "status": ["git", "status", "--short"],
    "diff": ["git", "diff"],
    "log": ["git", "log", "--oneline", "-20"],
    "branch": ["git", "branch", "-a"],
    "changed_files": ["git", "diff", "--name-only"],
}

DANGEROUS_FLAGS = {"--exec", "--upload-pack", "--receive-pack", "-c", "--config"}


@ability(name="git_info", description="Read-only git operations")
def git_info(action: str, args: str = "") -> str:
    """Run read-only git commands.

    Args:
        action: One of: status, diff, log, branch, changed_files, show
        args: Extra arguments (e.g. file path for diff, commit hash for show).
    """
    action = action.strip().lower()

    if args:
        for token in args.strip().split():
            flag = token.split("=")[0]
            if flag in DANGEROUS_FLAGS:
                return f"Error: flag '{flag}' is not allowed for safety"

    if action == "show":
        cmd = ["git", "show"]
        if args:
            cmd.append(args.strip())
    elif action in ACTIONS:
        cmd = list(ACTIONS[action])
        if args:
            cmd.extend(args.strip().split())
    else:
        available = ", ".join(list(ACTIONS) + ["show"])
        return f"Error: unknown action '{action}'. Use: {available}"

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        output = result.stdout.strip()
        if result.returncode != 0:
            return f"Error (exit {result.returncode}): {result.stderr.strip()}"
        return output or "(no output)"
    except subprocess.TimeoutExpired:
        return "Error: git command timed out"
    except FileNotFoundError:
        return "Error: git not found"
