"""Tests for core/interceptor.py."""

import asyncio

import pytest

from phoenix.abilities import AbilityInfo
from phoenix.core.interceptor import (
    AutoApprovalBackend,
    CLIApprovalBackend,
    Interceptor,
    get_approval_backend,
    set_approval_backend,
)
from phoenix.hooks.runner import HookEvent, HookResult, HookRunner


def _make_ability(name="test", is_async=True, needs_ctx=False):
    if is_async:

        async def func(x: str = "hello") -> str:
            return f"result: {x}"
    else:

        def func(x: str = "hello") -> str:
            return f"result: {x}"

    return AbilityInfo(
        name=name,
        description="test ability",
        func=func,
        is_async=is_async,
        needs_context=needs_ctx,
    )


class TestInterceptor:
    @pytest.mark.asyncio
    async def test_wrap_async_ability(self):
        interceptor = Interceptor()
        info = _make_ability(is_async=True)
        wrapped = interceptor.wrap(info)
        result = await wrapped(x="world")
        assert result == "result: world"

    @pytest.mark.asyncio
    async def test_wrap_sync_ability(self):
        interceptor = Interceptor()
        info = _make_ability(is_async=False)
        wrapped = interceptor.wrap(info)
        result = await wrapped(x="sync")
        assert result == "result: sync"

    @pytest.mark.asyncio
    async def test_error_handling(self):
        async def bad_func() -> str:
            raise ValueError("boom")

        info = AbilityInfo(
            name="bad",
            description="fails",
            func=bad_func,
            is_async=True,
            needs_context=False,
        )
        interceptor = Interceptor()
        wrapped = interceptor.wrap(info)
        result = await wrapped()
        assert "Error" in result
        assert "boom" in result

    @pytest.mark.asyncio
    async def test_pre_tool_hook_blocks(self):
        runner = HookRunner()

        async def deny(ctx):
            return HookResult(allow=False, feedback="denied by hook")

        runner.register(HookEvent.PRE_TOOL, deny)
        interceptor = Interceptor(hook_runner=runner)
        info = _make_ability()
        wrapped = interceptor.wrap(info)
        result = await wrapped(x="test")
        assert "blocked" in result
        assert "denied" in result

    @pytest.mark.asyncio
    async def test_post_tool_hook_fires(self):
        fired = []
        runner = HookRunner()

        async def track(ctx):
            fired.append(ctx.tool_name)
            return None

        runner.register(HookEvent.POST_TOOL, track)
        interceptor = Interceptor(hook_runner=runner)
        info = _make_ability(name="tracked")
        wrapped = interceptor.wrap(info)
        await wrapped(x="test")
        assert "tracked" in fired


class TestApprovalBackend:
    def test_auto_yolo_approves_all(self):
        backend = AutoApprovalBackend("yolo")
        result = asyncio.run(backend.request_approval("bash", "rm -rf /", {}))
        assert result is True

    def test_default_backend_is_cli(self):
        backend = get_approval_backend()
        assert isinstance(backend, CLIApprovalBackend)

    def test_set_backend(self):
        original = get_approval_backend()
        auto = AutoApprovalBackend("yolo")
        set_approval_backend(auto)
        assert get_approval_backend() is auto
        set_approval_backend(original)
