"""Tests for hooks system."""

import json
import tempfile
from pathlib import Path

import pytest

from phoenix.hooks.loader import load_hooks_config
from phoenix.hooks.runner import HookContext, HookEvent, HookResult, HookRunner

# -- HookRunner tests --


class TestHookRunner:
    def test_empty_runner(self):
        runner = HookRunner()
        assert not runner.has_hooks
        assert runner.event_count(HookEvent.PRE_TOOL) == 0

    def test_register_and_count(self):
        runner = HookRunner()

        async def hook(ctx):
            return HookResult(feedback="ok")

        runner.register(HookEvent.PRE_TURN, hook)
        assert runner.has_hooks
        assert runner.event_count(HookEvent.PRE_TURN) == 1

    @pytest.mark.asyncio
    async def test_run_returns_feedback(self):
        runner = HookRunner()

        async def hook(ctx):
            return HookResult(feedback="hook fired")

        runner.register(HookEvent.PRE_TURN, hook)
        result = await runner.run(
            HookEvent.PRE_TURN,
            HookContext(event=HookEvent.PRE_TURN, user_input="test"),
        )
        assert result.allow is True
        assert "hook fired" in result.feedback

    @pytest.mark.asyncio
    async def test_deny_hook_blocks(self):
        runner = HookRunner()

        async def deny(ctx):
            return HookResult(allow=False, feedback="blocked")

        runner.register(HookEvent.PRE_TOOL, deny)
        result = await runner.run(
            HookEvent.PRE_TOOL,
            HookContext(event=HookEvent.PRE_TOOL, tool_name="bash"),
        )
        assert result.allow is False
        assert "blocked" in result.feedback

    @pytest.mark.asyncio
    async def test_multiple_hooks_merge(self):
        runner = HookRunner()

        async def hook_a(ctx):
            return HookResult(feedback="from A")

        async def hook_b(ctx):
            return HookResult(feedback="from B")

        runner.register(HookEvent.POST_TURN, hook_a)
        runner.register(HookEvent.POST_TURN, hook_b)
        result = await runner.run(
            HookEvent.POST_TURN,
            HookContext(event=HookEvent.POST_TURN),
        )
        assert "from A" in result.feedback
        assert "from B" in result.feedback

    @pytest.mark.asyncio
    async def test_exception_in_hook_reported(self):
        runner = HookRunner()

        async def bad_hook(ctx):
            raise ValueError("oops")

        runner.register(HookEvent.ON_ERROR, bad_hook)
        result = await runner.run(
            HookEvent.ON_ERROR,
            HookContext(event=HookEvent.ON_ERROR),
        )
        assert result.allow is True
        assert "oops" in result.feedback

    def test_clear_specific_event(self):
        runner = HookRunner()

        async def hook(ctx):
            return None

        runner.register(HookEvent.PRE_TOOL, hook)
        runner.register(HookEvent.POST_TOOL, hook)
        runner.clear(HookEvent.PRE_TOOL)
        assert runner.event_count(HookEvent.PRE_TOOL) == 0
        assert runner.event_count(HookEvent.POST_TOOL) == 1

    def test_clear_all(self):
        runner = HookRunner()

        async def hook(ctx):
            return None

        runner.register(HookEvent.PRE_TOOL, hook)
        runner.register(HookEvent.POST_TURN, hook)
        runner.clear()
        assert not runner.has_hooks


# -- Loader tests --


class TestLoader:
    def test_nonexistent_config(self):
        runner = load_hooks_config("/nonexistent/path.json")
        assert not runner.has_hooks

    def test_load_config_with_hooks(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(
                {
                    "hooks": {
                        "pre_tool": [
                            {"command": "echo hello", "action": "log"},
                            {
                                "match": "bash",
                                "command": "echo checking",
                                "action": "approve_or_deny",
                            },
                        ],
                        "post_turn": [
                            {"command": "echo done"},
                        ],
                    }
                },
                f,
            )
            f.flush()
            runner = load_hooks_config(f.name)

        assert runner.event_count(HookEvent.PRE_TOOL) == 2
        assert runner.event_count(HookEvent.POST_TURN) == 1
        Path(f.name).unlink()

    def test_empty_config(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump({"hooks": {}}, f)
            f.flush()
            runner = load_hooks_config(f.name)

        assert not runner.has_hooks
        Path(f.name).unlink()
