"""Tests for memory system -- extraction, gating, recall."""

import os
import tempfile

import numpy as np
import pytest

# Use temp DB for all tests
_TEMP_DB = tempfile.mktemp(suffix=".db")
os.environ["PHOENIX_MEMORY_DB"] = _TEMP_DB


import contextlib

from phoenix.memory import MemorySystem  # noqa: E402
from phoenix.memory.classifier import AnchorClassifier, build_classifiers  # noqa: E402
from phoenix.memory.config import CATEGORY_ANCHORS, MINILM_PRESET, MemoryParams  # noqa: E402
from phoenix.memory.embeddings import EmbeddingService  # noqa: E402
from phoenix.memory.extractor import _declarative_signal, extract_facts, sigmoid  # noqa: E402
from phoenix.memory.gate import NoveltyGate, is_self_identity  # noqa: E402
from phoenix.memory.store import MemoryStore  # noqa: E402

# -- Helpers --


# Tests use MINILM_PRESET (FastEmbed backend) for fast, deterministic inference.
# Avoids the ~100s Gemma cold-start + license gate in CI.
_TEST_PARAMS = MemoryParams(**MINILM_PRESET)


def _get_embedder():
    return EmbeddingService(_TEST_PARAMS)


def _get_store():
    return MemoryStore(_TEST_PARAMS)


# -- Embedding tests --


class TestEmbeddings:
    def test_embed_returns_vector(self):
        emb = _get_embedder()
        vec = emb.embed("hello world")
        assert isinstance(vec, np.ndarray)
        # Dim is backend-dependent; read from config so test doesn't hardcode.
        assert vec.shape == (emb.config.embedding_dim,)

    def test_embed_is_normalized(self):
        emb = _get_embedder()
        vec = emb.embed("test sentence")
        norm = float(np.linalg.norm(vec))
        assert abs(norm - 1.0) < 0.01

    def test_similar_texts_higher_than_different(self):
        emb = _get_embedder()
        a = emb.embed("I prefer dark mode")
        b = emb.embed("I like dark theme")
        c = emb.embed("The database runs on PostgreSQL")
        sim_similar = EmbeddingService.cosine_similarity(a, b)
        sim_different = EmbeddingService.cosine_similarity(a, c)
        assert sim_similar > sim_different

    def test_different_texts_low_similarity(self):
        emb = _get_embedder()
        a = emb.embed("I prefer dark mode")
        b = emb.embed("The database runs on PostgreSQL")
        sim = EmbeddingService.cosine_similarity(a, b)
        assert sim < 0.5

    def test_cosine_similarity_matrix(self):
        emb = _get_embedder()
        q = emb.embed("dark mode")
        keys = np.stack([emb.embed("I like dark theme"), emb.embed("PostgreSQL database")])
        sims = EmbeddingService.cosine_similarity_matrix(q, keys)
        assert len(sims) == 2
        assert sims[0] > sims[1]


# -- Extractor tests --


class TestExtractor:
    def test_sigmoid(self):
        assert abs(sigmoid(0) - 0.5) < 0.01
        assert sigmoid(10) > 0.99
        assert sigmoid(-10) < 0.01

    def test_declarative_signal_first_person(self):
        score = _declarative_signal("I prefer using Neovim")
        assert score > 0.5

    def test_declarative_signal_question(self):
        score = _declarative_signal("What is Python?")
        assert score < 0.3

    def test_extract_facts_from_declaration(self):
        emb = _get_embedder()
        clf = AnchorClassifier(CATEGORY_ANCHORS)
        clf.initialize(emb.embed)
        facts = extract_facts("I prefer Python over Java.", "", emb, clf)
        assert len(facts) >= 1
        assert any("Python" in f["content"] for f in facts)

    def test_extract_facts_skips_questions(self):
        emb = _get_embedder()
        clf = AnchorClassifier(CATEGORY_ANCHORS)
        clf.initialize(emb.embed)
        facts = extract_facts("What language should I use?", "", emb, clf)
        assert len(facts) == 0


# -- Gate tests --


class TestGate:
    def test_self_identity_detection(self):
        assert is_self_identity("My name is Harshal")
        assert is_self_identity("I am a developer")
        assert is_self_identity("I work at Google")
        assert not is_self_identity("The project uses Python")

    async def test_first_fact_always_stores(self):
        store = _get_store()
        await store.connect()
        emb = _get_embedder()
        gate = NoveltyGate(_TEST_PARAMS, emb, store)
        vec = emb.embed("I prefer Python")
        result = await gate.evaluate("I prefer Python", vec, namespace="test_gate")
        assert result["action"] == "store"
        await store.close()


# -- Store tests --


class TestStore:
    async def test_add_and_get(self):
        store = _get_store()
        await store.connect()
        emb = _get_embedder()
        vec = emb.embed("test memory")
        mid = await store.add("test memory", category="fact", embedding=vec, namespace="test_store")
        mem = await store.get(mid)
        assert mem is not None
        assert mem["content"] == "test memory"
        assert mem["category"] == "fact"
        await store.close()

    async def test_stats(self):
        store = _get_store()
        await store.connect()
        stats = await store.stats()
        assert "total" in stats
        assert "by_category" in stats
        assert "edge_count" in stats
        await store.close()

    async def test_add_edge(self):
        store = _get_store()
        await store.connect()
        emb = _get_embedder()
        v1 = emb.embed("fact one")
        v2 = emb.embed("fact two")
        id1 = await store.add("fact one", embedding=v1, namespace="test_edges")
        id2 = await store.add("fact two", embedding=v2, namespace="test_edges")
        await store.add_edge(id1, id2, 0.8)
        neighbors = await store.get_neighbors(id1)
        assert len(neighbors) >= 1
        assert any(n[0] == id2 for n in neighbors)
        await store.close()


# -- Classifier tests --


class TestClassifier:
    def test_build_classifiers(self):
        emb = _get_embedder()
        cat, dim, intent = build_classifiers(_TEST_PARAMS, emb.embed)
        assert len(cat.categories) == 5
        assert len(dim.categories) == 5
        assert len(intent.categories) == 5

    def test_classify_preference(self):
        emb = _get_embedder()
        clf = AnchorClassifier(CATEGORY_ANCHORS)
        clf.initialize(emb.embed)
        vec = emb.embed("I prefer dark mode in all my editors")
        category, confidence = clf.classify(vec)
        assert category == "preference"
        assert confidence > 0


# -- MemorySystem integration --


class TestMemorySystem:
    async def test_post_turn_stores_facts(self):
        # Use MINILM_PRESET to avoid pulling Gemma in CI (no HF auth, no 600MB weights).
        mem = MemorySystem(_TEST_PARAMS)
        await mem.post_turn("My name is Harshal. I prefer Python.", "Noted.", session_id="test")
        stats = await mem.stats()
        assert stats["total"] >= 1
        await mem.close()

    async def test_pre_turn_recalls(self):
        mem = MemorySystem(_TEST_PARAMS)
        await mem.post_turn("I switched from VS Code to Neovim.", "Got it.", session_id="test")
        await mem.post_turn("I prefer Python over Java for backend.", "Noted.", session_id="test")
        ctx = await mem.pre_turn("what programming language do I prefer")
        assert isinstance(ctx, str)
        await mem.close()


# -- Concurrent lifecycle: verify the store.connect() lock prevents the
# TOCTOU race where two coroutines both pass the `self._db is not None`
# fast-check and both try to open + migrate the DB. --


class TestStoreConcurrency:
    async def test_concurrent_connect_is_serialised(self):
        """Ten coroutines hitting an unconnected store must not duplicate
        connect/migrate work. Before the _connect_lock fix, this raised
        IntegrityError on the second _migrations INSERT."""
        import asyncio

        store = _get_store()
        # Fan out ten concurrent connects; the lock should serialise them
        # so only the first actually opens + migrates.
        await asyncio.gather(*[store.connect() for _ in range(10)])
        # One connection, migrations recorded exactly once.
        cursor = await store._db.execute(
            "SELECT COUNT(*) FROM _migrations WHERE name = '001_initial.sql'"
        )
        count = (await cursor.fetchone())[0]
        await cursor.close()
        assert count == 1, f"expected 1 migration row, got {count}"
        await store.close()

    async def test_concurrent_stats_and_pre_turn(self):
        """Races stats() against pre_turn() / post_turn() -- all three go
        through _ensure_initialized or stats()'s lazy connect. No
        IntegrityError, no RuntimeError, no silent coroutine drops."""
        import asyncio

        mem = MemorySystem(_TEST_PARAMS)
        results = await asyncio.gather(
            mem.post_turn("I use pytest for all my testing.", "Noted.", session_id="t"),
            mem.stats(),
            mem.pre_turn("what testing framework do I use"),
            mem.stats(),
            return_exceptions=True,
        )
        for r in results:
            assert not isinstance(r, Exception), f"concurrent call raised: {r!r}"
        await mem.close()


# Cleanup
@pytest.fixture(autouse=True, scope="session")
def cleanup():
    yield
    with contextlib.suppress(FileNotFoundError):
        os.unlink(_TEMP_DB)
