"""Rigorous tests for topic-based session context.

Tests the full topic detection pipeline:
- Trigger logic (when analysis fires)
- Explicit shift detection (regex)
- ActiveTopic state management
- Token budget tracking
- Context building with multiple topics
- Session summary creation
- Edge cases (short messages, rapid shifts, long single topics)
- Simulated multi-topic conversations
"""

import time

import pytest

from phoenix.memory.session import (
    ACTIVE_TOKEN_BUDGET,
    ANALYSIS_INTERVAL,
    MIN_TOPIC_TURNS,
    ActiveTopic,
    CompletedTopic,
    SessionSummary,
    TopicAnalysis,
    TopicTracker,
)


class TestActiveTopic:
    def test_empty_topic(self):
        topic = ActiveTopic()
        assert topic.turn_count == 0
        assert topic.estimate_tokens() == 0
        assert topic.messages == []
        assert topic.files_touched == set()

    def test_add_turn(self):
        topic = ActiveTopic()
        topic.add_turn("fix the banner", "Working on it.", None)
        assert topic.turn_count == 1
        assert len(topic.messages) == 1
        assert topic.messages[0][0] == "fix the banner"

    def test_file_tracking(self):
        topic = ActiveTopic()
        topic.add_turn(
            "edit display.py",
            "Done.",
            [
                {"name": "read_file", "args": {"path": "/src/display.py"}, "result": "ok"},
                {"name": "write_file", "args": {"path": "/src/display.py"}, "result": "ok"},
                {"name": "grep", "args": {"pattern": "def"}, "result": "matches"},
            ],
        )
        assert "/src/display.py" in topic.files_touched
        assert len(topic.files_touched) == 1  # grep doesn't track files

    def test_action_tracking(self):
        topic = ActiveTopic()
        topic.add_turn(
            "check status",
            "Here it is.",
            [
                {"name": "bash", "args": {"command": "git status"}, "result": "clean"},
                {"name": "read_file", "args": {"path": "main.py"}, "result": "content..."},
            ],
        )
        assert len(topic.tool_actions) == 2
        assert "bash: clean" in topic.tool_actions[0]

    def test_action_bounded(self):
        """Tool actions list doesn't grow unbounded."""
        topic = ActiveTopic()
        for i in range(30):
            topic.add_turn(
                f"action {i}",
                "ok",
                [{"name": "bash", "args": {}, "result": f"result {i}"}],
            )
        assert len(topic.tool_actions) <= 20

    def test_ai_output_truncated(self):
        """AI output stored truncated to 500 chars."""
        topic = ActiveTopic()
        long_output = "x" * 1000
        topic.add_turn("test", long_output, None)
        assert len(topic.messages[0][1]) == 500

    def test_token_estimation(self):
        topic = ActiveTopic()
        topic.add_turn("short message", "short reply", None)
        tokens_small = topic.estimate_tokens()

        topic.add_turn("a " * 200, "b " * 200, None)
        tokens_large = topic.estimate_tokens()

        assert tokens_large > tokens_small
        assert tokens_large > 100

    def test_format_for_analysis(self):
        topic = ActiveTopic()
        topic.add_turn("fix the bug", "Looking at it.", None)
        topic.add_turn(
            "in display.py",
            "Found it.",
            [
                {"name": "read_file", "args": {"path": "display.py"}, "result": "code..."},
            ],
        )

        text = topic.format_for_analysis()
        assert "Turn 1:" in text
        assert "Turn 2:" in text
        assert "fix the bug" in text
        assert "Tool actions:" in text
        assert "read_file" in text

    def test_format_for_history(self):
        topic = ActiveTopic()
        topic.add_turn("hello", "hi", None)
        topic.add_turn("bye", "goodbye", None)

        history = topic.format_for_history()
        assert len(history) == 2
        assert history[0] == ("hello", "hi")


class TestExplicitShiftDetection:
    def _check(self, text: str) -> bool:
        tracker = TopicTracker(model="test", session_id="test")
        return tracker._has_explicit_shift(text)

    def test_now_lets(self):
        assert self._check("now let's work on the memory system")
        assert self._check("Now lets fix the UI")

    def test_switching_to(self):
        assert self._check("switching to CI setup")
        assert self._check("switch to the database work")

    def test_moving_on(self):
        assert self._check("moving on to the next feature")
        assert self._check("let's move to something else")

    def test_next_thing(self):
        assert self._check("next thing: set up deployment")

    def test_change_topic(self):
        assert self._check("different topic - how about testing?")
        assert self._check("change topic to something fun")

    def test_ok_next(self):
        assert self._check("ok next, let's do the API")
        assert self._check("alright now let's build the frontend")

    def test_new_task(self):
        assert self._check("new task: implement authentication")

    def test_on_to(self):
        assert self._check("on to the database layer")

    def test_lets_talk_about(self):
        assert self._check("let's talk about the deployment strategy")

    def test_negative_no_shift(self):
        """These should NOT trigger a shift."""
        assert not self._check("fix the bug in display.py")
        assert not self._check("yes do that")
        assert not self._check("can you help me with this?")
        assert not self._check("what's the status?")
        assert not self._check("run the tests")
        assert not self._check("I prefer dark mode")
        assert not self._check("show me the file")

    def test_negative_partial_match(self):
        """Substrings that shouldn't match."""
        assert not self._check("the next line of code")
        assert not self._check("I moved the file")


class TestTriggerLogic:
    @pytest.mark.asyncio
    async def test_no_analysis_before_min_turns(self):
        """Analysis should NOT fire before MIN_TOPIC_TURNS."""
        tracker = TopicTracker(model="test", session_id="test")

        # Add turns below minimum
        for i in range(MIN_TOPIC_TURNS - 1):
            # Manually add without triggering analysis
            tracker._active.add_turn(f"msg {i}", "reply", None)
            tracker._total_turns += 1
            tracker._turns_since_analysis += 1

        # Even with explicit shift, should not analyze (too few turns)
        assert tracker._active.turn_count < MIN_TOPIC_TURNS

    @pytest.mark.asyncio
    async def test_interval_trigger(self):
        """Analysis should trigger at ANALYSIS_INTERVAL."""
        tracker = TopicTracker(model="test", session_id="test")

        # Simulate turns up to interval
        for i in range(ANALYSIS_INTERVAL + MIN_TOPIC_TURNS):
            tracker._active.add_turn(f"msg about topic A {i}", "reply about A", None)
            tracker._total_turns += 1
            tracker._turns_since_analysis += 1

        # Check trigger conditions
        should_check = (
            tracker._turns_since_analysis >= ANALYSIS_INTERVAL
            and tracker._active.turn_count >= MIN_TOPIC_TURNS
        )
        assert should_check

    @pytest.mark.asyncio
    async def test_token_budget_trigger(self):
        """Analysis should trigger when active topic exceeds token budget."""
        tracker = TopicTracker(model="test", session_id="test")

        # Add enough content to exceed budget (4000 tokens ~ 3000 words)
        for _i in range(10):
            long_msg = "word " * 500  # ~500 words per turn
            tracker._active.add_turn(long_msg, long_msg, None)
            tracker._total_turns += 1

        should_check = (
            tracker._active.estimate_tokens() > ACTIVE_TOKEN_BUDGET
            and tracker._active.turn_count >= MIN_TOPIC_TURNS
        )
        assert should_check

    @pytest.mark.asyncio
    async def test_explicit_shift_trigger(self):
        """Explicit shift signal should trigger analysis."""
        tracker = TopicTracker(model="test", session_id="test")

        # Add enough turns to meet minimum
        for i in range(MIN_TOPIC_TURNS):
            tracker._active.add_turn(f"working on feature {i}", "ok", None)
            tracker._total_turns += 1
            tracker._turns_since_analysis += 1

        # Explicit shift
        assert tracker._has_explicit_shift("now let's work on testing")
        should_check = (
            tracker._has_explicit_shift("now let's work on testing")
            and tracker._active.turn_count >= MIN_TOPIC_TURNS
        )
        assert should_check


class TestContextBuilding:
    def test_empty_context(self):
        tracker = TopicTracker(model="test", session_id="test")
        assert tracker.build_context() == ""

    def test_single_completed_topic(self):
        tracker = TopicTracker(model="test", session_id="test")
        tracker._completed.append(
            CompletedTopic(
                label="Banner fix",
                summary="Removed box borders.",
                decisions=["use horizontal rules"],
                files=["display.py"],
                open_threads=[],
                turn_count=10,
                started_at=1000,
                ended_at=2000,
            )
        )

        ctx = tracker.build_context()
        assert "Banner fix" in ctx
        assert "Removed box borders" in ctx
        assert "horizontal rules" in ctx
        assert "display.py" in ctx

    def test_multiple_completed_topics(self):
        tracker = TopicTracker(model="test", session_id="test")

        topics = [
            ("Banner fix", "Fixed the banner UI.", ["no boxes"], ["display.py"]),
            ("Memory system", "Built episodic memory.", ["keep full pipeline"], ["memory.py"]),
            ("CI/CD setup", "Added GitHub Actions.", ["use uv"], ["ci.yml"]),
        ]

        for label, summary, decisions, files in topics:
            tracker._completed.append(
                CompletedTopic(
                    label=label,
                    summary=summary,
                    decisions=decisions,
                    files=files,
                    open_threads=[],
                    turn_count=8,
                    started_at=1000,
                    ended_at=2000,
                )
            )

        ctx = tracker.build_context()
        assert "Banner fix" in ctx
        assert "Memory system" in ctx
        assert "CI/CD setup" in ctx
        # All three summaries present
        assert ctx.count("[Completed:") == 3

    def test_max_five_topics_in_context(self):
        """Only last 5 completed topics should appear."""
        tracker = TopicTracker(model="test", session_id="test")

        for i in range(8):
            tracker._completed.append(
                CompletedTopic(
                    label=f"Topic {i}",
                    summary=f"Summary {i}",
                    decisions=[],
                    files=[],
                    open_threads=[],
                    turn_count=5,
                    started_at=1000,
                    ended_at=2000,
                )
            )

        ctx = tracker.build_context()
        assert ctx.count("[Completed:") == 5
        assert "Topic 3" in ctx  # 4th topic (0-indexed)
        assert "Topic 7" in ctx  # last topic
        assert "Topic 0" not in ctx  # dropped
        assert "Topic 2" not in ctx  # dropped

    def test_open_threads_in_context(self):
        tracker = TopicTracker(model="test", session_id="test")
        tracker._completed.append(
            CompletedTopic(
                label="Auth",
                summary="Worked on auth.",
                decisions=[],
                files=[],
                open_threads=["JWT refresh not implemented", "rate limiting pending"],
                turn_count=5,
                started_at=1000,
                ended_at=2000,
            )
        )

        ctx = tracker.build_context()
        assert "JWT refresh" in ctx
        assert "rate limiting" in ctx


class TestPydanticModels:
    def test_topic_analysis_same_topic(self):
        a = TopicAnalysis(same_topic=True, topic_label="Banner fix")
        assert a.same_topic
        assert a.summary == ""
        assert a.key_decisions == []

    def test_topic_analysis_shift(self):
        a = TopicAnalysis(
            same_topic=False,
            topic_label="Memory architecture",
            summary="Designed topic-based context engineering.",
            key_decisions=["use LLM for detection", "structured pydantic output"],
            files_involved=["engine.py", "session.py"],
            open_threads=["test reliability"],
        )
        assert not a.same_topic
        assert len(a.key_decisions) == 2
        assert len(a.files_involved) == 2

    def test_session_summary(self):
        s = SessionSummary(
            summary="Built phoenix-os across 3 topics.",
            topics_covered=["Banner", "Memory", "CI"],
            key_outcomes=["64 files", "59 tests", "topic-based context"],
            open_threads=["voice integration"],
        )
        assert len(s.topics_covered) == 3
        assert "64 files" in s.key_outcomes


class TestSimulatedConversation:
    """Simulate a realistic conversation flow without LLM calls.
    Tests the state management as if the LLM correctly identified topic shifts.
    """

    def _simulate_topic_shift(self, tracker: TopicTracker, label: str, summary: str):
        """Manually simulate what happens when LLM detects a topic shift."""
        completed = CompletedTopic(
            label=label,
            summary=summary,
            decisions=[],
            files=list(tracker._active.files_touched),
            open_threads=[],
            turn_count=tracker._active.turn_count,
            started_at=tracker._active.started_at,
            ended_at=time.time(),
        )
        tracker._completed.append(completed)

        # Keep last 2 messages as bridge
        msgs = tracker._active.messages
        bridge = msgs[-2:] if len(msgs) >= 2 else msgs
        tracker._active = ActiveTopic(
            messages=list(bridge),
            turn_count=len(bridge),
            started_at=time.time(),
            label="",
        )

    def test_three_topic_session(self):
        tracker = TopicTracker(model="test", session_id="test")

        # Topic 1: Banner UI (10 turns)
        for i in range(10):
            tracker._active.add_turn(
                f"banner work {i}",
                f"banner response {i}",
                [{"name": "write_file", "args": {"path": "display.py"}, "result": "ok"}]
                if i % 3 == 0
                else None,
            )
            tracker._total_turns += 1

        assert tracker._active.turn_count == 10
        assert "display.py" in tracker._active.files_touched

        # Topic shift 1 -> 2
        self._simulate_topic_shift(
            tracker,
            "Banner UI fix",
            "Removed box borders, used horizontal rules.",
        )

        assert tracker.completed_count == 1
        assert tracker._active.turn_count == 2  # bridge messages

        # Topic 2: Memory system (8 turns)
        for i in range(8):
            tracker._active.add_turn(
                f"memory work {i}",
                f"memory response {i}",
                [{"name": "read_file", "args": {"path": "memory/__init__.py"}, "result": "ok"}]
                if i == 0
                else None,
            )
            tracker._total_turns += 1

        # Topic shift 2 -> 3
        self._simulate_topic_shift(
            tracker,
            "Memory architecture",
            "Designed topic-based context engineering.",
        )

        assert tracker.completed_count == 2

        # Topic 3: CI/CD (5 turns, active)
        for i in range(5):
            tracker._active.add_turn(f"ci work {i}", f"ci response {i}", None)
            tracker._total_turns += 1

        # Verify state
        assert tracker.total_turns == 23
        assert tracker.completed_count == 2
        assert tracker._active.turn_count == 7  # 2 bridge + 5 new

        # Verify context
        ctx = tracker.build_context()
        assert "Banner UI fix" in ctx
        assert "Memory architecture" in ctx
        assert "[Completed:" in ctx
        assert ctx.count("[Completed:") == 2

    def test_active_messages_independent_of_completed(self):
        """Active topic messages should only be the current topic."""
        tracker = TopicTracker(model="test", session_id="test")

        # Build up 20 messages in topic 1
        for i in range(20):
            tracker._active.add_turn(f"old msg {i}", f"old reply {i}", None)
            tracker._total_turns += 1

        # Shift
        self._simulate_topic_shift(tracker, "Old topic", "Old stuff.")

        # New topic: 3 messages
        for i in range(3):
            tracker._active.add_turn(f"new msg {i}", f"new reply {i}", None)
            tracker._total_turns += 1

        # Active should only have 5 messages (2 bridge + 3 new)
        active = tracker.get_active_messages()
        assert len(active) == 5
        # NOT 23 messages

    def test_rapid_topic_switches(self):
        """Multiple quick topic changes."""
        tracker = TopicTracker(model="test", session_id="test")

        topics = [
            ("Setup", 4),
            ("Database", 5),
            ("Auth", 3),
            ("Frontend", 6),
            ("Deploy", 4),
        ]

        for label, turns in topics[:-1]:  # all but last
            for i in range(turns):
                tracker._active.add_turn(f"{label} {i}", "ok", None)
                tracker._total_turns += 1
            self._simulate_topic_shift(tracker, label, f"Worked on {label}.")

        # Last topic is still active
        label, turns = topics[-1]
        for i in range(turns):
            tracker._active.add_turn(f"{label} {i}", "ok", None)
            tracker._total_turns += 1

        assert tracker.completed_count == 4
        assert tracker._active.turn_count == 4 + 2  # turns + bridge
        assert tracker.total_turns == sum(t for _, t in topics)

        ctx = tracker.build_context()
        assert ctx.count("[Completed:") == 4

    def test_long_single_topic(self):
        """50 turns on the same topic -- no shifts."""
        tracker = TopicTracker(model="test", session_id="test")

        for i in range(50):
            tracker._active.add_turn(f"same topic {i}", f"reply {i}", None)
            tracker._total_turns += 1

        assert tracker.completed_count == 0
        assert tracker._active.turn_count == 50
        assert tracker.build_context() == ""

    def test_session_properties(self):
        tracker = TopicTracker(model="test", session_id="test-123")

        tracker._active.label = "Current work"
        assert tracker.active_topic_label == "Current work"

        for i in range(5):
            tracker._active.add_turn(f"msg {i}", "reply", None)
            tracker._total_turns += 1

        assert tracker.total_turns == 5
        assert tracker.active_turn_count == 5


class TestEdgeCases:
    def test_empty_messages(self):
        topic = ActiveTopic()
        topic.add_turn("", "", None)
        assert topic.turn_count == 1
        assert topic.estimate_tokens() == 0

    def test_very_short_messages(self):
        """'yes', 'ok', 'no' -- these shouldn't break anything."""
        topic = ActiveTopic()
        for msg in ["yes", "ok", "no", "do it", "thanks"]:
            topic.add_turn(msg, "Done.", None)
        assert topic.turn_count == 5

    def test_tool_call_with_missing_fields(self):
        """Tool calls with incomplete data should not crash."""
        topic = ActiveTopic()
        topic.add_turn(
            "test",
            "ok",
            [
                {"name": "bash", "args": {}, "result": ""},
                {"name": "", "args": None, "result": None},
                {},
            ],
        )
        assert topic.turn_count == 1

    def test_unicode_in_messages(self):
        topic = ActiveTopic()
        topic.add_turn("fix the emoji bug", "Done.", None)
        assert topic.turn_count == 1

    def test_very_long_single_message(self):
        topic = ActiveTopic()
        long_msg = "word " * 5000
        topic.add_turn(long_msg, "ok", None)
        assert topic.estimate_tokens() > 1000

    def test_context_with_empty_fields(self):
        """CompletedTopic with all-empty optional fields."""
        tracker = TopicTracker(model="test", session_id="test")
        tracker._completed.append(
            CompletedTopic(
                label="Minimal",
                summary="",
                decisions=[],
                files=[],
                open_threads=[],
                turn_count=3,
                started_at=1000,
                ended_at=2000,
            )
        )
        ctx = tracker.build_context()
        assert "Minimal" in ctx
        assert "Decisions:" not in ctx
        assert "Files:" not in ctx
