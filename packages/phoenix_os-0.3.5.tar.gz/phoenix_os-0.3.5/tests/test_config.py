"""Tests for config/settings.py."""

from phoenix.config.settings import (
    get_model,
    get_model_name,
    get_provider,
    resolve_model,
    set_model,
    setup_logging,
)


def test_setup_logging():
    setup_logging()


def test_get_model_returns_string():
    model = get_model()
    assert isinstance(model, str)
    assert len(model) > 0


def test_get_provider():
    assert get_provider("anthropic:claude-sonnet") == "anthropic"
    assert get_provider("openai:gpt-4o") == "openai"
    assert get_provider("ollama:llama3:8b") == "ollama"
    assert get_provider("some-model") == "unknown"


def test_get_model_name():
    assert get_model_name("anthropic:claude-sonnet") == "claude-sonnet"
    assert get_model_name("ollama:llama3:8b") == "llama3:8b"
    assert get_model_name("bare-model") == "bare-model"


def test_resolve_model_passthrough():
    result = resolve_model("anthropic:claude-sonnet-4-20250514")
    assert result == "anthropic:claude-sonnet-4-20250514"


def test_set_model():
    original = get_model()
    set_model("test:model")
    assert get_model() == "test:model"
    set_model(original)
