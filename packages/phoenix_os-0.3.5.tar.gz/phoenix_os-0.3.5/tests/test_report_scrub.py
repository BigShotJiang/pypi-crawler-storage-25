"""Scrub correctness tests. These must pass before a bug report can ship."""

from __future__ import annotations

from phoenix.report.scrub import MAX_LINE_LEN, scrub_line, scrub_text


class TestSecretMasking:
    def test_openai_key(self):
        out = scrub_line("auth=sk-proj-abc123def456ghi789jkl012mno345pqr678")
        assert "sk-proj-abc" not in out
        assert "<OPENAI_KEY>" in out

    def test_anthropic_key(self):
        out = scrub_line("ANTHROPIC_API_KEY=sk-ant-api03-abc123def456ghi789jkl012")
        assert "sk-ant-api03" not in out
        assert "<ANTHROPIC_KEY>" in out

    def test_google_gemini_key(self):
        out = scrub_line("key=AIzaSyA0_abcdefghijklmnopqrstuvwxyz1234567")
        assert "AIzaSy" not in out
        assert "<GOOGLE_KEY>" in out

    def test_github_pat(self):
        out = scrub_line("token ghp_abcdefghijklmnopqrstuvwxyz01234567")
        assert "ghp_abcdef" not in out
        assert "<GITHUB_PAT>" in out

    def test_bearer_token(self):
        out = scrub_line("Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.abc.def")
        assert "eyJhbGci" not in out
        assert "<TOKEN>" in out

    def test_brave_key(self):
        out = scrub_line("X-Subscription-Token: BSAabcdefghijklmnopqrstuvwxyz")
        assert "BSAabc" not in out
        assert "<BRAVE_KEY>" in out

    def test_hf_token(self):
        out = scrub_line("HF_TOKEN=hf_abcdefghijklmnopqrstuvwxyz01234567")
        assert "hf_abc" not in out
        assert "<HF_TOKEN>" in out

    def test_email_masked(self):
        out = scrub_line("Contact: jane.doe+phoenix@example.com for issues")
        assert "jane.doe" not in out
        assert "<EMAIL>" in out

    def test_multiple_secrets_one_line(self):
        out = scrub_line(
            "keys: sk-abc123def456ghi789jkl012 and AIzaSyA0_abcdefghijklmnopqrstuvwxyz1234567"
        )
        assert "sk-abc" not in out
        assert "AIzaSy" not in out
        assert "<OPENAI_KEY>" in out and "<GOOGLE_KEY>" in out


class TestLineTruncation:
    def test_long_line_truncated(self):
        huge = "x" * (MAX_LINE_LEN + 500)
        out = scrub_line(huge)
        assert len(out) < MAX_LINE_LEN + 100  # truncated down
        assert "truncated" in out

    def test_short_line_unchanged(self):
        line = "hello world"
        assert scrub_line(line) == line

    def test_empty_line_unchanged(self):
        assert scrub_line("") == ""


class TestHomeMasking:
    def test_home_path_masked(self, monkeypatch, tmp_path):
        # Force a predictable home so the regex has something to match.
        fake_home = tmp_path / "bob"
        fake_home.mkdir()
        monkeypatch.setenv("HOME", str(fake_home))
        monkeypatch.setattr("getpass.getuser", lambda: "bob")
        # scrub rebuilds patterns per call (intentional, see scrub._home_path_patterns)
        out = scrub_line(f"Reading {fake_home}/code/phoenix/memory.db")
        assert str(fake_home) not in out
        assert "<HOME>" in out


class TestMultilineText:
    def test_scrub_text_preserves_line_structure(self):
        text = "line1: sk-abcdefghijklmnopqrstuvwxyz0123\nline2: clean text\nline3: AIzaSyA0_abcdefghijklmnopqrstuvwxyz1234567"
        out = scrub_text(text)
        lines = out.splitlines()
        assert len(lines) == 3
        assert "sk-abc" not in out
        assert "AIzaSy" not in out
        assert "clean text" in out


class TestNonMatches:
    def test_plain_text_untouched(self):
        line = "user asked about cryptocurrency prices today"
        assert scrub_line(line) == line

    def test_short_hex_not_masked(self):
        # Hash fragments < key length shouldn't trigger
        line = "commit hash: abc123"
        assert scrub_line(line) == line

    def test_sha1_hash_not_masked(self):
        # 40-char lowercase hex -- git commit hash. No key regex should touch it.
        line = "HEAD at a0e199522b5e4cfb5e21c541b2f168cb0d88d2730195fc3c4e51d183f168cb0"
        assert scrub_line(line) == line


class TestDescriptionFieldScrub:
    """Users may accidentally paste secrets into the description itself
    (e.g. 'the /api call to sk-proj-abc... returns 400'). Must be scrubbed."""

    def test_openai_key_in_description(self):
        desc = "my OPENAI_API_KEY=sk-proj-abcdefghijklmnopqrstuvwx got rejected"
        out = scrub_text(desc)
        assert "sk-proj-abc" not in out
        assert "<OPENAI_KEY>" in out

    def test_anthropic_key_in_description(self):
        desc = "set ANTHROPIC_API_KEY=sk-ant-api03-abcdefghijklmnopqrstuv and it 401s"
        out = scrub_text(desc)
        assert "sk-ant-api03" not in out
        assert "<ANTHROPIC_KEY>" in out

    def test_email_and_path_in_description(self):
        desc = "I'm jane@example.com and phoenix cant write to /Users/jane/.phoenix"
        out = scrub_text(desc)
        assert "jane@example.com" not in out
        assert "<EMAIL>" in out
