"""LLM judge for retrieval quality.

Cross-family judge (Gemini) vs Phoenix's generator (GPT-4o) to defeat the
self-preference bias documented in Panickssery 2024. Structured Pydantic
output via pydantic-ai, deterministic (temperature=0), cached on
`(query, top_k_ids_sorted)`.

Judge model selection:
- Primary: anthropic:claude-sonnet-4-5 (Claude Sonnet 4.5)
  - Cross-family vs the Gemma embedding backend
  - Strong nuanced ranking / completeness judgments
  - ~$6-10 per full training run with trimmed schema + prompt caching
- Fallback via env: set `PHOENIX_JUDGE_MODEL` to any pydantic-ai model string.
"""

from __future__ import annotations

import hashlib
import logging
import os
from pathlib import Path
from typing import Any

from pydantic_ai import Agent
from pydantic_ai.settings import ModelSettings

from learning.evaluator.schemas import RetrievalJudgment

log = logging.getLogger(__name__)


JUDGE_INSTRUCTIONS = """You are an impartial evaluator of a personal memory retrieval system.

Given a user's query and the top-K memories the system returned, score the retrieval on:
- Per-memory relevance (0.0-1.0 each): does this specific memory answer or relate to the query?
- Ranking quality (0.0-1.0): are the most relevant memories placed first?
- Completeness (0.0-1.0): did the system surface the memories most relevant to this query?
- Precision (0.0-1.0): is the top-K free of irrelevant noise?
- Overall quality (0.0-1.0): single composite score the training loop will use.

Special handling for out-of-distribution / should-return-nothing queries:
If the query is about a topic the user's memory has no content on (e.g. weather in a
random city, generic facts), the RETRIEVER is correct to return nothing or low-relevance
noise. Score overall_quality HIGH in that case. Score LOW if the retriever returned
confident irrelevant memories as if relevant.

Be decisive with scores. Write brief reasoning first, then the score. Avoid hedging."""


def _ensure_env() -> None:
    """Ensure GEMINI_API_KEY (or equivalent) is set from .env if present."""
    repo_env = Path(__file__).resolve().parents[2] / ".env"
    if not repo_env.exists():
        return
    for raw in repo_env.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        if k and k not in os.environ:
            os.environ[k] = v


class Judge:
    """LLM-backed retrieval quality scorer with on-disk cache."""

    def __init__(
        self,
        model: str | None = None,
        cache_dir: Path | None = None,
        temperature: float = 0.0,
    ):
        _ensure_env()
        self.model = model or os.environ.get("PHOENIX_JUDGE_MODEL", "anthropic:claude-sonnet-4-5")
        self.cache_dir = cache_dir or Path(__file__).resolve().parents[1] / "runs" / ".judge_cache"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        # max_tokens=400 caps output spend; trimmed schema fits within ~200 tokens.
        self._agent = Agent(
            self.model,
            output_type=RetrievalJudgment,
            instructions=JUDGE_INSTRUCTIONS,
            model_settings=ModelSettings(temperature=temperature, max_tokens=400),
        )
        log.info("Judge model: %s (cache: %s)", self.model, self.cache_dir)

    def _cache_key(self, query: str, top_k: list[dict[str, Any]]) -> str:
        ids = sorted(m.get("id", "") for m in top_k)
        raw = f"{self.model}|{query}|{'|'.join(ids)}"
        return hashlib.sha256(raw.encode()).hexdigest()[:24]

    def _cache_load(self, key: str) -> RetrievalJudgment | None:
        path = self.cache_dir / f"{key}.json"
        if not path.exists():
            return None
        try:
            return RetrievalJudgment.model_validate_json(path.read_text())
        except Exception:
            return None

    def _cache_save(self, key: str, judgment: RetrievalJudgment) -> None:
        path = self.cache_dir / f"{key}.json"
        path.write_text(judgment.model_dump_json(indent=2))

    def judge(
        self,
        query: str,
        top_k: list[dict[str, Any]],
        expected_notes: str | None = None,
    ) -> RetrievalJudgment:
        """Score one query+retrieval tuple synchronously. Uses cache if present."""
        cache_key = self._cache_key(query, top_k)
        cached = self._cache_load(cache_key)
        if cached is not None:
            return cached

        memories_block = self._format_memories(top_k)
        user_prompt = self._format_prompt(query, memories_block, expected_notes)

        result = self._agent.run_sync(user_prompt)
        judgment = result.output
        self._cache_save(cache_key, judgment)
        return judgment

    async def judge_async(
        self,
        query: str,
        top_k: list[dict[str, Any]],
        expected_notes: str | None = None,
    ) -> RetrievalJudgment:
        """Async version for parallel batch judging during training."""
        cache_key = self._cache_key(query, top_k)
        cached = self._cache_load(cache_key)
        if cached is not None:
            return cached

        memories_block = self._format_memories(top_k)
        user_prompt = self._format_prompt(query, memories_block, expected_notes)

        result = await self._agent.run(user_prompt)
        judgment = result.output
        self._cache_save(cache_key, judgment)
        return judgment

    def _format_memories(self, top_k: list[dict[str, Any]]) -> str:
        if not top_k:
            return "(retriever returned no memories)"
        lines = []
        for i, m in enumerate(top_k, 1):
            mid = m.get("id", "?")
            content = (m.get("content") or "").strip()
            content = content[:280] + ("..." if len(content) > 280 else "")
            cat = m.get("category", "?")
            strength = m.get("strength", 0.0)
            direct = m.get("direct_relevance", m.get("relevance", 0.0))
            lines.append(
                f"[{i}] id={mid} category={cat} strength={strength:.2f} "
                f"direct_sim={direct:.3f}\n    {content}"
            )
        return "\n".join(lines)

    def _format_prompt(
        self,
        query: str,
        memories_block: str,
        expected_notes: str | None,
    ) -> str:
        parts = [f"QUERY:\n{query}", "", f"TOP-K RETRIEVED:\n{memories_block}"]
        if expected_notes:
            parts.extend(["", f"NOTES ON EXPECTED BEHAVIOR:\n{expected_notes}"])
        parts.extend(
            [
                "",
                "Score this retrieval. Be decisive. Write reasoning fields before numeric scores.",
            ]
        )
        return "\n".join(parts)
