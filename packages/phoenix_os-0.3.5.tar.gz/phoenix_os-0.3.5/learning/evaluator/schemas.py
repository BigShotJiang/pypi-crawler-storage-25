"""Pydantic schemas for the LLM judge.

Design notes (from cdocs/research/llm-judge-for-phoenix.md, plus cost-optimization
pass): trimmed schema keeps one listwise reasoning + per-item relevance floats,
drops per-item reasoning. Cuts output tokens ~65% with negligible impact on
ranking-tuning signal quality.
"""

from pydantic import BaseModel, Field


class MemoryScore(BaseModel):
    """Pointwise relevance for one returned memory. No per-item reasoning to save tokens."""

    memory_id: str = Field(description="The id of the memory being scored")
    relevance: float = Field(
        ge=0.0,
        le=1.0,
        description=(
            "Relevance of this memory to the query. "
            "1.0 = directly answers, 0.5 = tangential, 0.0 = unrelated/misleading."
        ),
    )


class RetrievalJudgment(BaseModel):
    """Listwise judgment of the full top-K retrieval for one query.

    One reasoning field (listwise) drives chain-of-thought; per-memory relevance
    floats carry the pointwise signal. overall_quality is the composite the
    training loop minimizes as 1 - overall_quality.
    """

    query: str = Field(description="The query being evaluated (echo of input)")
    per_memory: list[MemoryScore] = Field(
        description="Per-memory relevance, one per retrieved item, in return order"
    )
    reasoning: str = Field(
        description=(
            "Brief reasoning (<= 40 words) covering: were the most relevant memories "
            "placed first, any obvious inversions, did the top-K miss anything obvious. "
            "Write this before the scores."
        )
    )
    ranking_quality: float = Field(
        ge=0.0,
        le=1.0,
        description=(
            "How well memories are ordered by relevance. "
            "1.0 = perfect order, 0.5 = golden in top-K but misranked, 0.0 = inverted."
        ),
    )
    completeness: float = Field(
        ge=0.0,
        le=1.0,
        description=(
            "Did the top-K include the most relevant memories? "
            "1.0 = all gold present, 0.0 = missing."
        ),
    )
    precision: float = Field(
        ge=0.0,
        le=1.0,
        description=(
            "Fraction of returned memories that are relevant. 1.0 = no noise, 0.0 = mostly noise."
        ),
    )
    overall_quality: float = Field(
        ge=0.0,
        le=1.0,
        description=(
            "Single composite score the training loop uses. "
            "For OOD / should-return-nothing queries: 1.0 if retriever returned nothing "
            "or only low-relevance noise; 0.0 if it returned confident irrelevant memories."
        ),
    )
