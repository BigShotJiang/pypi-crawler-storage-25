"""Phoenix threshold learning system.

Tunes retrieval thresholds via Bayesian optimization (Optuna) with LLM-judge-
based quality scoring. Offline training tool; not part of Phoenix runtime.

See cdocs/research/bayesian-opt-for-phoenix.md,
    cdocs/research/llm-judge-for-phoenix.md,
    cdocs/research/query-dataset-generation.md
for the research behind this module.
"""
