"""Optuna objective for Phoenix threshold tuning.

One trial:
    1. Optuna suggests the 5 tunable thresholds (delta re-parameterization
       so `min_relevance <= relevance_gate_threshold` by construction).
    2. Run recall for every anchor query (serial; shared MemorySystem).
    3. Judge each (query, top_k) in parallel via Sonnet 4.5.
    4. Aggregate `overall_quality` -> loss = 1 - mean_quality.
    5. Intermediate reports for pruning after each chunk.

Loss weighting: uniform across queries. Category rebalancing is a v0.3 concern.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

import optuna

from learning.dataset.generate import load_anchors
from learning.dataset.schemas import AnchorQuery
from learning.evaluator.judge import Judge
from learning.evaluator.schemas import RetrievalJudgment
from learning.recall_runner import RecallRunner

if TYPE_CHECKING:
    pass

log = logging.getLogger(__name__)


@dataclass
class TrialResult:
    """Per-trial breakdown. Persisted to history.csv for analysis."""

    thresholds: dict[str, float]
    mean_quality: float
    loss: float
    n_queries: int
    n_judged: int
    n_failed: int
    per_category_mean: dict[str, float]


class TrainingObjective:
    """Callable Optuna objective. Wraps one evaluation epoch."""

    def __init__(
        self,
        recall_runner: RecallRunner,
        judge: Judge,
        dataset: list[AnchorQuery] | None = None,
        top_k: int = 5,
        judge_concurrency: int = 5,
    ):
        self.recall_runner = recall_runner
        self.judge = judge
        self.dataset = dataset if dataset is not None else load_anchors()
        self.top_k = top_k
        self.judge_concurrency = judge_concurrency

    def suggest_thresholds(self, trial: optuna.Trial) -> dict[str, float]:
        """Delta re-parameterization so `min_relevance <= relevance_gate_threshold`.

        Base is `min_relevance`, then a non-negative delta to reach
        `relevance_gate_threshold`. Other thresholds are independent.
        """
        min_relevance = trial.suggest_float("min_relevance", 0.05, 0.30)
        # delta >= 0 ensures min_relevance <= relevance_gate_threshold
        gate_delta = trial.suggest_float("gate_delta", 0.0, 0.30)
        relevance_gate_threshold = min(0.45, min_relevance + gate_delta)

        return {
            "min_relevance": round(min_relevance, 4),
            "relevance_gate_threshold": round(relevance_gate_threshold, 4),
            "pinned_boost": round(trial.suggest_float("pinned_boost", 1.00, 1.50), 4),
            "recency_weight": round(trial.suggest_float("recency_weight", 0.0, 0.5), 4),
            "strength_compression": round(trial.suggest_float("strength_compression", 0.1, 0.7), 4),
        }

    def __call__(self, trial: optuna.Trial) -> float:
        thresholds = self.suggest_thresholds(trial)

        # Run recalls serially (shared MemorySystem, not thread-safe)
        pairs: list[tuple[AnchorQuery, list[dict]]] = []
        for q in self.dataset:
            try:
                top_k = self.recall_runner.recall(q.query, thresholds, top_k=self.top_k)
            except Exception as e:
                log.warning("recall failed on %r: %s", q.query[:60], e)
                top_k = []
            pairs.append((q, top_k))

        # Judge in parallel
        judgments = asyncio.run(self._judge_all(pairs, trial))

        qualities: list[float] = []
        per_cat: dict[str, list[float]] = {}
        n_failed = 0
        for (q, _), j in zip(pairs, judgments, strict=False):
            if isinstance(j, Exception) or j is None:
                n_failed += 1
                continue
            qualities.append(j.overall_quality)
            per_cat.setdefault(q.category, []).append(j.overall_quality)

        if not qualities:
            log.error("all judgments failed for trial %d", trial.number)
            return 1.0  # worst possible loss

        mean_quality = sum(qualities) / len(qualities)
        loss = 1.0 - mean_quality

        per_category_mean = {cat: round(sum(vals) / len(vals), 4) for cat, vals in per_cat.items()}

        # Store per-trial result in user attrs for history.csv export
        trial.set_user_attr("mean_quality", round(mean_quality, 4))
        trial.set_user_attr("n_judged", len(qualities))
        trial.set_user_attr("n_failed", n_failed)
        trial.set_user_attr("per_category_mean", per_category_mean)
        trial.set_user_attr("resolved_thresholds", thresholds)

        log.info(
            "trial %d: loss=%.4f quality=%.4f (%d/%d judged) thresholds=%s",
            trial.number,
            loss,
            mean_quality,
            len(qualities),
            len(self.dataset),
            thresholds,
        )

        return loss

    async def _judge_all(
        self,
        pairs: list[tuple[AnchorQuery, list[dict]]],
        trial: optuna.Trial,
    ) -> list[RetrievalJudgment | None]:
        """Judge pairs concurrently with a semaphore cap."""
        sem = asyncio.Semaphore(self.judge_concurrency)

        async def _one(idx: int, anchor: AnchorQuery, top_k: list[dict]):
            async with sem:
                try:
                    return await self.judge.judge_async(
                        anchor.query, top_k, expected_notes=anchor.expected_behavior
                    )
                except Exception as e:
                    log.warning("judge failed on q=%r: %s", anchor.query[:60], e)
                    return None

        tasks = [_one(i, q, tk) for i, (q, tk) in enumerate(pairs)]

        # Report intermediate progress in chunks for pruning
        chunk_size = max(1, len(pairs) // 5)  # 5 intermediate reports
        results: list[RetrievalJudgment | None] = []
        for chunk_start in range(0, len(tasks), chunk_size):
            chunk = tasks[chunk_start : chunk_start + chunk_size]
            chunk_results = await asyncio.gather(*chunk, return_exceptions=False)
            results.extend(chunk_results)

            # Intermediate pruning signal
            partial_qualities = [r.overall_quality for r in results if r is not None]
            if partial_qualities:
                partial_mean = sum(partial_qualities) / len(partial_qualities)
                trial.report(1.0 - partial_mean, step=len(results))
                if trial.should_prune():
                    log.info(
                        "trial %d pruned at step %d (partial_loss=%.4f)",
                        trial.number,
                        len(results),
                        1.0 - partial_mean,
                    )
                    raise optuna.TrialPruned()

        return results
