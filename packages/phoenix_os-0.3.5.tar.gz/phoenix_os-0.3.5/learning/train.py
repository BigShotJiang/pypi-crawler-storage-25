"""CLI to run Phoenix threshold tuning via Optuna Bayesian optimization.

Usage:
    python -m learning.train --epochs 60
    python -m learning.train --study-name my-run --epochs 20 --resume
    python -m learning.train --epochs 30 --workers 5

Outputs go to `learning/runs/<study-name>/`:
    - optuna.db           -- SQLite study state (resumable)
    - history.csv         -- per-trial thresholds + loss + per-category quality
    - best_thresholds.json -- the winning config
    - config.json         -- run parameters
    - loss_curve.png      -- loss over trials (if matplotlib available)
"""

from __future__ import annotations

# CRITICAL: load .env BEFORE any phoenix imports. MemoryParams reads
# PHOENIX_MEMORY_DB at class-definition time; setting the env var later
# is too late -- MemoryParams() then defaults to ~/.phoenix/memory.db.
import os
from pathlib import Path as _Path


def _preload_env():
    env_path = _Path(__file__).resolve().parent.parent / ".env"
    if not env_path.exists():
        return
    for raw in env_path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        if k and k not in os.environ:
            os.environ[k] = v


_preload_env()
os.environ.setdefault("PHOENIX_EMBEDDING_BACKEND", "gemma")

import argparse
import csv
import json
import logging
import sys
import time
from pathlib import Path

import optuna
from optuna.pruners import MedianPruner
from optuna.samplers import GPSampler

from learning.evaluator.judge import Judge
from learning.optimizer.objective import TrainingObjective
from learning.recall_runner import RecallRunner

RUNS_ROOT = Path(__file__).resolve().parent / "runs"


def _setup_logging(verbose: bool) -> None:
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        stream=sys.stderr,
    )
    # Quiet noisy libs
    for name in ("httpx", "httpcore", "openai", "anthropic"):
        logging.getLogger(name).setLevel(logging.WARNING)


def _export_history(study: optuna.Study, out_path: Path) -> None:
    """Per-trial CSV of thresholds + loss + quality breakdown."""
    rows = []
    for t in study.trials:
        if t.state.is_finished() and t.value is not None:
            thresholds = t.user_attrs.get("resolved_thresholds", {})
            rows.append(
                {
                    "trial": t.number,
                    "loss": round(t.value, 4),
                    "mean_quality": t.user_attrs.get("mean_quality", None),
                    "n_judged": t.user_attrs.get("n_judged", 0),
                    "n_failed": t.user_attrs.get("n_failed", 0),
                    **{f"t.{k}": v for k, v in thresholds.items()},
                    "per_category_mean": json.dumps(t.user_attrs.get("per_category_mean", {})),
                    "state": t.state.name,
                }
            )
    if not rows:
        return
    keys = list(rows[0].keys())
    with out_path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def _plot_loss_curve(study: optuna.Study, out_path: Path) -> None:
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return
    trials = [t for t in study.trials if t.value is not None]
    if len(trials) < 2:
        return
    xs = [t.number for t in trials]
    ys = [t.value for t in trials]
    best = []
    cur = min(ys)
    for y in ys:
        cur = min(cur, y)
        best.append(cur)
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(xs, ys, "o-", alpha=0.4, label="per-trial loss")
    ax.plot(xs, best, "-", color="red", label="best so far")
    ax.set_xlabel("trial")
    ax.set_ylabel("loss (1 - mean_quality)")
    ax.set_title("Optuna GPSampler: Phoenix threshold tuning")
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=120)
    plt.close(fig)


def main() -> int:
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    ap.add_argument("--epochs", type=int, default=60, help="Number of trials")
    ap.add_argument("--study-name", type=str, default=None, help="Study name (default: timestamp)")
    ap.add_argument("--resume", action="store_true", help="Resume existing study")
    ap.add_argument("--workers", type=int, default=5, help="Concurrent judge calls")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--db", type=str, default=None, help="Phoenix memory.db path (overrides env)")
    ap.add_argument("--judge-model", type=str, default=None, help="Override judge model")
    ap.add_argument("--verbose", "-v", action="store_true")
    ap.add_argument("--no-pruner", action="store_true", help="Disable MedianPruner")
    ap.add_argument(
        "--baseline",
        action="store_true",
        default=True,
        help="Enqueue current production thresholds as trial 0 (reference baseline). Default on.",
    )
    ap.add_argument(
        "--no-baseline",
        action="store_false",
        dest="baseline",
        help="Disable baseline trial injection.",
    )
    args = ap.parse_args()

    _setup_logging(args.verbose)
    log = logging.getLogger("learning.train")

    study_name = args.study_name or f"run-{time.strftime('%Y%m%d-%H%M%S')}"
    run_dir = RUNS_ROOT / study_name
    run_dir.mkdir(parents=True, exist_ok=True)

    storage_path = run_dir / "optuna.db"
    storage = f"sqlite:///{storage_path}"

    log.info("study: %s", study_name)
    log.info("run_dir: %s", run_dir)

    runner = RecallRunner(db_path=args.db)
    judge = Judge(model=args.judge_model)
    objective = TrainingObjective(recall_runner=runner, judge=judge, judge_concurrency=args.workers)
    log.info("loaded %d anchor queries", len(objective.dataset))

    pruner = (
        MedianPruner(n_startup_trials=5, n_warmup_steps=10)
        if not args.no_pruner
        else optuna.pruners.NopPruner()
    )

    study = optuna.create_study(
        study_name=study_name,
        storage=storage,
        load_if_exists=args.resume,
        direction="minimize",
        sampler=GPSampler(seed=args.seed),
        pruner=pruner,
    )

    # Enqueue baseline: current production thresholds become trial 0 so we have
    # a reference to compare optimized runs against. Optuna's reparameterization
    # expects `gate_delta` (not `relevance_gate_threshold` directly).
    if args.baseline and not args.resume:
        base = runner.base_config
        baseline_params = {
            "min_relevance": float(base.min_relevance),
            "gate_delta": max(0.0, float(base.relevance_gate_threshold - base.min_relevance)),
            "pinned_boost": float(base.pinned_boost),
            "recency_weight": float(base.recency_weight),
            "strength_compression": float(base.strength_compression),
        }
        study.enqueue_trial(baseline_params)
        log.info("enqueued baseline trial: %s", baseline_params)

    # Save run config for reproducibility
    (run_dir / "config.json").write_text(
        json.dumps(
            {
                "study_name": study_name,
                "epochs": args.epochs,
                "workers": args.workers,
                "seed": args.seed,
                "db": args.db or "default",
                "judge_model": args.judge_model or "default",
                "no_pruner": args.no_pruner,
                "n_dataset": len(objective.dataset),
            },
            indent=2,
        )
    )

    t_start = time.time()
    try:
        study.optimize(objective, n_trials=args.epochs, show_progress_bar=False)
    except KeyboardInterrupt:
        log.warning("interrupted by user; partial study retained at %s", storage_path)

    elapsed = time.time() - t_start
    log.info("study complete in %.1fs", elapsed)

    if len(study.trials) == 0:
        log.error("no trials completed")
        return 1

    try:
        best = study.best_trial
    except ValueError:
        log.error("no best trial (all pruned/failed)")
        return 1

    log.info("best trial: #%d loss=%.4f", best.number, best.value)
    log.info("best thresholds: %s", best.user_attrs.get("resolved_thresholds"))

    (run_dir / "best_thresholds.json").write_text(
        json.dumps(
            {
                "trial": best.number,
                "loss": best.value,
                "mean_quality": best.user_attrs.get("mean_quality"),
                "thresholds": best.user_attrs.get("resolved_thresholds"),
                "per_category_mean": best.user_attrs.get("per_category_mean"),
            },
            indent=2,
        )
    )

    _export_history(study, run_dir / "history.csv")
    _plot_loss_curve(study, run_dir / "loss_curve.png")

    print(f"\nBest thresholds (trial {best.number}, loss={best.value:.4f}):")
    for k, v in (best.user_attrs.get("resolved_thresholds") or {}).items():
        print(f"  {k}: {v}")
    print(f"\nArtifacts at {run_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
