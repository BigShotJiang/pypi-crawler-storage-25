"""Generate 50 anchor queries for the MVP training set.

Strategy:
- 30 queries LLM-generated from sampled memories via GPT-4o
    * 10 single_hop_exact (paraphrase memory content into a direct query)
    * 5  single_hop_synonym (reword with different vocabulary)
    * 5  multi_hop (connect two memories)
    * 5  reasoning (abstract question about user's values/patterns)
    * 5  temporal (when did I / what did I last)
- 15 hand-curated OOD + adversarial queries (don't need memory sampling)
- 5  Hindi + Hinglish identity queries (translated from common English questions)

Each query gets:
- gold_memory_ids: list of memory IDs that should be retrieved
- expected_behavior: human text
- should_return_empty: bool (True for OOD)

Output: learning/dataset/anchors.jsonl

Usage:
    python -m learning.dataset.generate
"""

from __future__ import annotations

import logging
import os
import random
import sqlite3
from pathlib import Path

from pydantic_ai import Agent
from pydantic_ai.settings import ModelSettings

from learning.dataset.schemas import AnchorQuery, GeneratedQuery

log = logging.getLogger(__name__)

REPO_ROOT = Path(__file__).resolve().parents[2]
DATASET_PATH = REPO_ROOT / "learning" / "dataset" / "anchors.jsonl"


def _load_env() -> None:
    env_path = REPO_ROOT / ".env"
    if not env_path.exists():
        return
    for raw in env_path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, _, v = line.partition("=")
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        if k and k not in os.environ:
            os.environ[k] = v


GENERATOR_MODEL = os.environ.get("PHOENIX_QUERY_GENERATOR", "anthropic:claude-haiku-4-5")


GEN_INSTRUCTIONS = """You are generating queries to test a personal memory retrieval system.

Given a memory the user has stored, write a NATURAL query that a user would type which
SHOULD retrieve this memory. The query must:
- Sound like something a person would actually ask (not a paraphrase of the memory)
- Not copy the memory's vocabulary verbatim (too easy)
- Match the requested category (direct/synonym/reasoning/temporal/multi-hop)
- Be in the requested language

Write brief reasoning first, then the query, category, language."""


def _get_agent():
    _load_env()
    return Agent(
        GENERATOR_MODEL,
        output_type=GeneratedQuery,
        instructions=GEN_INSTRUCTIONS,
        model_settings=ModelSettings(temperature=0.7),
    )


def _load_memories(db_path: str) -> list[dict]:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        "SELECT id, content, category, strength FROM memories "
        "WHERE superseded_by IS NULL AND source_session != 'consolidation' "
        "ORDER BY strength DESC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _pick_diverse(memories: list[dict], n: int, seed: int = 42) -> list[dict]:
    """Pick n memories, biased toward high-strength + category diversity."""
    random.seed(seed)
    by_cat: dict[str, list[dict]] = {}
    for m in memories:
        by_cat.setdefault(m["category"], []).append(m)
    # Round-robin across categories, taking top by strength
    picks: list[dict] = []
    cats = list(by_cat.keys())
    idx_per_cat = {c: 0 for c in cats}
    while len(picks) < n:
        made_progress = False
        for cat in cats:
            if idx_per_cat[cat] < len(by_cat[cat]):
                picks.append(by_cat[cat][idx_per_cat[cat]])
                idx_per_cat[cat] += 1
                made_progress = True
                if len(picks) >= n:
                    break
        if not made_progress:
            break
    return picks


def _gen_prompt(memory: dict, category: str, language: str) -> str:
    content = memory["content"][:200]
    return f"""Memory to target (id={memory["id"]}, category={memory["category"]}):
    {content!r}

Generate a {category} query in {language} that should retrieve this memory.

Categories:
- single_hop_exact: direct question about the memory's content
- single_hop_synonym: reword using different vocabulary (not memory's words)
- reasoning: abstract question about user values/patterns this memory reflects
- temporal: time-anchored question (when did I, what did I last)
- multi_hop: requires connecting this memory with another topic

Language:
- en: English
- hi: Hindi in Devanagari script
- hi-en: Hinglish (romanized Hindi mixed with English)

Generate one query. Be decisive."""


def generate_from_memories(
    memories: list[dict], specs: list[tuple[str, str, int]]
) -> list[AnchorQuery]:
    """Generate queries via GPT-4o.

    specs: list of (category, language, count) tuples. One memory is picked per query.
    """
    agent = _get_agent()
    total = sum(c for _, _, c in specs)
    picks = _pick_diverse(memories, total)

    results: list[AnchorQuery] = []
    idx = 0
    for category, language, count in specs:
        for _ in range(count):
            if idx >= len(picks):
                break
            mem = picks[idx]
            idx += 1
            try:
                gen = agent.run_sync(_gen_prompt(mem, category, language))
                q = gen.output
                results.append(
                    AnchorQuery(
                        query=q.query,
                        category=category,
                        language=language,
                        gold_memory_ids=[mem["id"]],
                        expected_behavior=(
                            f"Return memory {mem['id'][:8]} in top-3. "
                            f"Target category: {mem['category']}."
                        ),
                        should_return_empty=False,
                        notes=q.reasoning,
                    )
                )
                print(f"  [{category:20}] {q.query}")
            except Exception as e:
                print(f"  [{category:20}] FAIL: {str(e)[:100]}")
    return results


# Hand-curated queries for robustness testing. These are generic and do not
# depend on any user's specific memory content. OOD queries must return empty
# or low-relevance noise; adversarial queries present wrong claims the user
# has stored content contradicting.
#
# For user-specific identity / multilingual queries (e.g., "what's my name" in
# your language), the LLM generator creates those from the corpus automatically.
HAND_CURATED: list[AnchorQuery] = [
    AnchorQuery(
        query="what's the current weather in Tokyo Japan",
        category="ood",
        language="en",
        gold_memory_ids=[],
        expected_behavior="Empty or only low-relevance noise. Personal memory has no weather content.",
        should_return_empty=True,
    ),
    AnchorQuery(
        query="my favorite cryptocurrency trading strategy",
        category="ood",
        language="en",
        gold_memory_ids=[],
        expected_behavior="Empty. OOD query unrelated to personal memory.",
        should_return_empty=True,
    ),
    AnchorQuery(
        query="the best pizza topping for Wednesday",
        category="ood",
        language="en",
        gold_memory_ids=[],
        expected_behavior="Empty. Nonsense query, must not leak pinned memories.",
        should_return_empty=True,
    ),
    AnchorQuery(
        query="recipe for chocolate chip cookies",
        category="ood",
        language="en",
        gold_memory_ids=[],
        expected_behavior="Empty. Generic cooking content, not personal.",
        should_return_empty=True,
    ),
    AnchorQuery(
        query="how tall is Mount Everest",
        category="ood",
        language="en",
        gold_memory_ids=[],
        expected_behavior="Empty. Generic fact, not personal memory.",
        should_return_empty=True,
    ),
    AnchorQuery(
        query="the",
        category="ood",
        language="en",
        gold_memory_ids=[],
        expected_behavior="Empty. Stopword-only, no meaningful signal.",
        should_return_empty=True,
    ),
    AnchorQuery(
        query="",
        category="ood",
        language="en",
        gold_memory_ids=[],
        expected_behavior="Empty. Zero-length query must not crash or surface pinned memories.",
        should_return_empty=True,
    ),
    AnchorQuery(
        query="I own a Ferrari",
        category="adversarial",
        language="en",
        gold_memory_ids=[],
        expected_behavior=(
            "Must NOT confirm the claim. Either empty OR surface actual vehicle/ownership "
            "memories as contradiction."
        ),
        should_return_empty=False,
        notes="Adversarial ownership claim.",
    ),
    AnchorQuery(
        query="I hate programming",
        category="adversarial",
        language="en",
        gold_memory_ids=[],
        expected_behavior="Empty OR surface skill/preference memories as contradiction.",
        should_return_empty=False,
        notes="Adversarial vs technical skill memories.",
    ),
    AnchorQuery(
        query="🔥",
        category="ood",
        language="en",
        gold_memory_ids=[],
        expected_behavior="Empty. Emoji-only query, no semantic content to match.",
        should_return_empty=True,
    ),
]


def generate_all(db_path: str, out_path: Path = DATASET_PATH) -> list[AnchorQuery]:
    """Main: generate + hand-curate, write JSONL."""
    print(f"Loading memories from {db_path}...")
    memories = _load_memories(db_path)
    print(f"  {len(memories)} base memories")

    # 40 LLM-generated queries across categories + languages. The LLM generator
    # creates user-specific identity, preference, project queries automatically,
    # so we do not hard-code any corpus-specific content here. Adjust the spec
    # to your coverage needs.
    specs = [
        ("single_hop_exact", "en", 10),
        ("single_hop_synonym", "en", 5),
        ("reasoning", "en", 5),
        ("temporal", "en", 5),
        ("multi_hop", "en", 5),
        ("single_hop_exact", "hi-en", 5),
        ("single_hop_exact", "hi", 5),
    ]

    print("\nGenerating via GPT-4o...")
    generated = generate_from_memories(memories, specs)
    print(f"\nGenerated {len(generated)} LLM-crafted queries")

    all_queries = generated + HAND_CURATED
    print(f"Total (incl. {len(HAND_CURATED)} hand-curated): {len(all_queries)}")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w") as f:
        for q in all_queries:
            f.write(q.model_dump_json() + "\n")
    print(f"\nWrote {len(all_queries)} queries to {out_path}")
    return all_queries


def load_anchors(path: Path = DATASET_PATH) -> list[AnchorQuery]:
    """Load previously generated anchors from JSONL."""
    return [
        AnchorQuery.model_validate_json(line)
        for line in path.read_text().splitlines()
        if line.strip()
    ]


if __name__ == "__main__":
    _load_env()
    db_path = os.environ.get("PHOENIX_MEMORY_DB", str(Path.home() / ".phoenix" / "memory.db"))
    generate_all(db_path)
