"""Schemas for anchor query dataset."""

from __future__ import annotations

from pydantic import BaseModel, Field


class AnchorQuery(BaseModel):
    """One evaluation query with gold labels and expected behavior."""

    query: str = Field(description="The query text as a user would type it")
    category: str = Field(
        description=(
            "Category: single_hop_exact, single_hop_synonym, multi_hop, temporal, "
            "event_based, reasoning, adversarial, ood, hindi_devanagari, hinglish"
        )
    )
    language: str = Field(description="Language code: en, hi, hi-en (code-switched)")
    gold_memory_ids: list[str] = Field(
        default_factory=list,
        description="Memory IDs that SHOULD be retrieved. Empty for OOD/negative queries.",
    )
    expected_behavior: str = Field(
        description="Human-readable description of what a correct retrieval looks like"
    )
    should_return_empty: bool = Field(
        default=False,
        description="True for OOD/negative queries where the system should return nothing or only low-relevance noise",
    )
    notes: str = Field(default="", description="Optional free-form notes for the judge")


class GeneratedQuery(BaseModel):
    """Output schema for GPT-4o when generating queries from memory samples."""

    query: str = Field(
        description="A natural-sounding query that should retrieve the target memory"
    )
    category: str = Field(description="Category label for this query type")
    language: str = Field(description="en | hi | hi-en")
    reasoning: str = Field(
        description="Why this query should retrieve the target memory (<= 30 words)"
    )
