from uuid import UUID
from pydantic import BaseModel



class UserinfoData(BaseModel):
    id: UUID
    username: str
    first_name: str
    last_name: str
    email_address: str
    phone_number: str
    is_active: bool
    is_admin: bool
    is_superuser: bool
    is_verified: bool


class ClaimData(BaseModel):
    user: UserinfoData
    roles: list[str] = []


class AccessTokenData(BaseModel):
    exp: int
    nbf: int
    iss: str
    aud: str
    iat: int
    sub: UUID
    sid: UUID
    jti: UUID
    azp: str
    access: ClaimData
    scope: str


class RefreshTokenData(BaseModel):
    exp: int
    iat: int
    sub: UUID
    sid: UUID
    jti: UUID
    azp: str


# class TokenData(BaseModel):
#     access_token: str
#     refresh_token: str
#     token_type: str
#     expires_in: int
#     expires_at: datetime
#     scope: str


# class SessionData(BaseModel):
#     code: str = ""
#     verifier: str = ""
#     state: str = ""
#     nonce: str = ""
#     next: str = "/home/"
#     token: Optional[TokenData] = None

