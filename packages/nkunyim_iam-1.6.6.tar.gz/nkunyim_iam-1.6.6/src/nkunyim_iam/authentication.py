from http import HTTPMethod
import json

from rest_framework import authentication

from nkunyim_iam.auth import Auth
from nkunyim_iam.http import Http



class JWTAuthentication(authentication.BaseAuthentication):
    def __init__(self, *args, **kwargs):        
        super().__init__(*args, **kwargs)

        self.http = Http()
        self.www_authenticate_realm = 'api' 

    def authenticate_header(self, request): # type: ignore
        return '{0} realm="{1}"'.format(
            self.http.authentication_headers[0],
            self.www_authenticate_realm,
        )
        
        
    def authenticate(self, request):
        token = self.http.get_jwt_token(request=request)
        if token is None:
            return None
        
        user = Auth.authenticate(token=token)
        if not user:
            return None
        
        if not self.verify_signature(request=request):
            return None
        
        return (user, None)


    def verify_signature(self, request) -> bool:
        if not request.method in [HTTPMethod.POST, HTTPMethod.PATCH, HTTPMethod.PUT]:
            return True
        
        signature = self.http.get_signature(request=request)
        if not signature:
            return False

        body = json.loads(request.body.decode('utf-8'))
        if not body:
            return False
        
        return Auth.verify(signature=signature, payload=body)

