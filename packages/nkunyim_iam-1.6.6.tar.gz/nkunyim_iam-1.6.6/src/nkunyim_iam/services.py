from typing import Optional
from uuid import UUID

from django.contrib import auth
from django.http import HttpRequest

from nkunyim_iam.handlers import UserHandler, LoggingHandler
from nkunyim_iam.models import User



class UserService:
    def __init__(self, req: HttpRequest) -> None:
        self.req = req

    def get_current_user(self) -> Optional[User]:
        try:
            if not self.is_authenticated:
                return None
            
            user_id = self.req.user.id
            if not user_id:
                return None
            
            return UserHandler.find(id=user_id)
        except Exception as ex:
            LoggingHandler.danger(
                message="Failed to retrieve user data from database.",
                trace={
                    "file": __file__,
                    "class": f"{__name__}.{__class__.__name__}",
                    "method": "get_current_user",
                },
                context={"exception": str(ex)},
            )
            return None
        
        
    def find_by_email(self, email_address: str) -> Optional[User]:
        return UserHandler.find_by_email(email_address=email_address)
        
        
    def find_by_phone(self, phone_number: str) -> Optional[User]:
        return UserHandler.find_by_phone(phone_number=phone_number)
        
    
    def find_by_username(self, username: str) -> Optional[User]:
        return UserHandler.find_by_username(username=username)
        
        
    def delete_user(self, id:UUID) -> bool:
        return UserHandler.delete(id=id)
    
    
    def is_authenticated(self) -> bool:
        return self.req.user.is_authenticated
    

    def logout(self) -> None:
        self.req.session.clear()
        self.req.session.flush()
        auth.logout(self.req)
