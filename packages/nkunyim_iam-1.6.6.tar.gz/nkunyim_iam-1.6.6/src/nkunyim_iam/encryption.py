import base64
import hashlib
import json
import jwt
import os

from typing import Optional, Union

from cryptography.fernet import Fernet
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes, serialization

from django.conf import settings

from nkunyim_iam.config import HashingAlgo


class Base64Util:
    @staticmethod
    def encode(input_string: str) -> str:
        string_bytes = input_string.encode('utf-8')
        encoded_bytes = base64.b64encode(string_bytes)
        return encoded_bytes.decode('utf-8')

    @staticmethod
    def decode(encoded_string: str) -> str:
        encoded_bytes = encoded_string.encode('utf-8')
        decoded_bytes = base64.b64decode(encoded_bytes)
        return decoded_bytes.decode('utf-8')

    @staticmethod
    def decode_url(encoded_string: str) -> dict:
        encoded_string = encoded_string + "=="
        decoded_bytes = base64.urlsafe_b64decode(encoded_string.encode('utf-8'))
        return json.loads(decoded_bytes.decode('utf-8'))



class Hashing:
    
    def __init__(self, input_string: str) -> None:
        self.input_bytes = input_string.encode('utf-8')
        self.hash = hashlib.sha256()
    
    def _make(self) -> str:
        self.hash.update(self.input_bytes)
        digest = self.hash.digest()
        return base64.urlsafe_b64encode(digest).decode('utf-8').replace('=', '')
    
    def sha256(self) -> str:
        return self._make()
        
    def sha384(self) -> str:
        self.hash = hashlib.sha384()
        return self._make()
    
    def sha512(self) -> str:
        self.hash = hashlib.sha512()
        return self._make()
    
    def make(self, algo: HashingAlgo) -> str:
        if algo == HashingAlgo.S256:
            return self.sha256()
        elif algo == HashingAlgo.S384:
            return self.sha384()
        elif algo == HashingAlgo.S512:
            return self.sha512()
        else:
            raise Exception(f"HashingAlgo [{algo}] is either invalid or not supported.")



class AESEncryption:
    @staticmethod
    def generate_key() -> str:
        key = Fernet.generate_key()
        return key.decode()


    @staticmethod
    def encrypt(key: str, plain_text: str) -> str:
        cipher_suite = Fernet(key.encode())
        cipher_text = cipher_suite.encrypt(plain_text.encode())
        return cipher_text.decode()

    
    @staticmethod
    def decrypt(key: str, cipher_text: str) -> str:
        cipher_suite = Fernet(key.encode())
        plain_text = cipher_suite.decrypt(cipher_text.encode())
        return plain_text.decode()



class RSAEncryption:
    @staticmethod
    def load_private_pem() -> bytes:
        private_pem = None
        with open(os.path.join(settings.BASE_DIR, 'data/rsa/private_key.pem'), mode='rb') as private_file:
            private_pem = private_file.read()

        return private_pem
    
    @staticmethod
    def load_public_pem(name:str) -> bytes:
        file_name = name.lower()
        public_pem = None
        with open(os.path.join(settings.BASE_DIR, f"data/rsa/{file_name}_key.pem"), mode='rb') as public_file:
            public_pem = public_file.read()

        return public_pem
    
    @staticmethod
    def get_private_key() -> rsa.RSAPrivateKey:
        private_key = serialization.load_pem_private_key(
            RSAEncryption.load_private_pem(),
            password=str.encode(settings.RSA_PRIVATE_PHRASE)
        )
        return private_key # type: ignore

    
    @staticmethod
    def get_public_key(name: Union[str, None] = None) -> rsa.RSAPublicKey:
        if name:
            public_pem = RSAEncryption.load_public_pem(name=name)
            public_key = serialization.load_pem_public_key(public_pem)
        else:
            private_key = RSAEncryption.get_private_key()
            public_key = private_key.public_key()
            
        return public_key # type: ignore
    

    @staticmethod
    def encrypt(plain_text: str, name: Union[str, None] = None) -> bytes:
        public_key = RSAEncryption.get_public_key(name=name)
        cipher_text = public_key.encrypt(
            plain_text.encode(),
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )

        return cipher_text


    @staticmethod
    def decrypt(cipher_text: bytes) -> str:
        private_key = RSAEncryption.get_private_key()
        plain_text = private_key.decrypt(
            cipher_text,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )
        return plain_text.decode()



class JWTEncryption:
    # PyJWT [https://pyjwt.readthedocs.io/en/stable/index.html]
    @staticmethod
    def encode(payload: dict, algorithm: str) -> str:
        private_key = RSAEncryption.get_private_key()
        encoded = jwt.encode(payload, private_key, algorithm=algorithm)
        return encoded
    
    @staticmethod
    def decode(token: str, algorithm: Optional[str] = None, verify: bool = True) -> dict:
        if verify and algorithm:
            private_key = RSAEncryption.get_private_key()
            public_key = private_key.public_key()
            payload = jwt.decode(token, public_key, algorithms=[algorithm])
        else:
            payload = jwt.decode(token, options={"verify_signature": False})
        return payload
