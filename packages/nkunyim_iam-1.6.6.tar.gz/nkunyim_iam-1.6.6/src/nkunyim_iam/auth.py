import base64
from datetime import datetime, timezone
import hashlib
import hmac
import json
from typing import Optional

from nkunyim_iam.commands import UserCommand
from nkunyim_iam.config import ConfigFactory
from nkunyim_iam.data import AccessTokenData, UserinfoData
from nkunyim_iam.encryption import JWTEncryption
from nkunyim_iam.handlers import LoggingHandler, UserHandler
from nkunyim_iam.models import User


class Auth:
    @staticmethod
    def sign(key: str, payload: dict) -> str:
        message = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        digest = hmac.new(key.encode(), msg=message.encode(), digestmod=hashlib.sha256,).hexdigest()
        encoded = digest.encode()
        signature = base64.b64encode(encoded).decode()
        return signature
    
    
    @staticmethod
    def verify(signature: str, payload: dict) -> bool:
        config = ConfigFactory.get()
        if not config.verify:
            return True
        
        resign = Auth.sign(key=config.key, payload=payload)
        return resign == signature
    
    
    @staticmethod
    def jwt_userinfo(access_token: str) -> Optional[UserinfoData]:
        try:
            decoded = JWTEncryption.decode(token=access_token)
            access_token_data = AccessTokenData(**decoded)
            if access_token_data.exp <= int(datetime.now(timezone.utc).timestamp()):
                LoggingHandler.danger(
                    message="Access token has expired.",
                    trace={
                        "file": __file__,
                        "class": f"{__name__}.{__class__.__name__}",
                        "method": "jwt_userinfo",
                    },
                    context={"exp": str(access_token_data.exp)},
                )
                return None
            
            service_name = ConfigFactory.NAME.lower()
            if service_name not in  access_token_data.access.roles:
                LoggingHandler.danger(
                    message="Access denied, invalid role claim.",
                    trace={
                        "file": __file__,
                        "class": f"{__name__}.{__class__.__name__}",
                        "method": "jwt_userinfo",
                    },
                    context={
                        "name": service_name,
                        "roles": ", ".join(access_token_data.access.roles)
                    },
                )
                return None
                
            userinfo = access_token_data.access.user
            userinfo_data = userinfo.model_dump()
            return UserinfoData(**userinfo_data)
        except Exception as ex:
            LoggingHandler.danger(
                message="Failed to decode userinfo data from JWT.",
                trace={
                    "file": __file__,
                    "class": f"{__name__}.{__class__.__name__}",
                    "method": "jwt_userinfo",
                },
                context={"exception": str(ex)},
            )
            return None
        

    @staticmethod
    def authenticate(token: str) -> Optional[User]:
        try:
            userinfo_data = Auth.jwt_userinfo(access_token=token)
            if not userinfo_data:
                return None

            userinfo = userinfo_data.model_dump()
            user_command = UserCommand(**userinfo)
            user_model = UserHandler.handle(command=user_command)
            
            return user_model
        except Exception as ex:
            LoggingHandler.danger(
                message="Failed to retrieve user data from API.",
                trace={
                    "file": __file__,
                    "class": f"{__name__}.{__class__.__name__}",
                    "method": "authenticate",
                },
                context={"exception": str(ex)},
            )
            return None


    @staticmethod
    def authorize(token: str) -> Optional[User]:
        try:
            userinfo_data = Auth.jwt_userinfo(access_token=token)
            if not userinfo_data:
                return None

            userinfo = userinfo_data.model_dump()
            user_command = UserCommand(**userinfo)
            user_model = UserHandler.find(id=user_command.id)
            
            return user_model
        except Exception as ex:
            LoggingHandler.danger(
                message="Failed to retrieve user data from API.",
                trace={
                    "file": __file__,
                    "class": f"{__name__}.{__class__.__name__}",
                    "method": "authorize",
                },
                context={"exception": str(ex)},
            )
            return None
