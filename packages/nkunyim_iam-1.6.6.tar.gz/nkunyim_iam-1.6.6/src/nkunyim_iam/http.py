from typing import Optional

from django.http import HttpRequest
import requests

from rest_framework import HTTP_HEADER_ENCODING

from nkunyim_iam.auth import Auth
from nkunyim_iam.config import ConfigFactory



class Http:
    def __init__(self) -> None:
        self.authentication_headers = ["Bearer", "JWT",]
    
    def get_token(self, key: str, request: HttpRequest) -> Optional[str]:
        header = request.META.get(key, None)
        if header is None:
            return None

        if isinstance(header, str):
            header = header.encode(HTTP_HEADER_ENCODING)

        if isinstance(header, bytes):
            header = header.decode(HTTP_HEADER_ENCODING)

        if not isinstance(header, str):
            header = str(header)
            
        parts = header.split()
        if len(parts) == 0:
            return None

        if parts[0] not in self.authentication_headers:
            return None
        
        if len(parts) != 2:
            return None

        return parts[1]
    
    def get_signature(self, request: HttpRequest) -> Optional[str]:
        return self.get_token(key='HTTP_AUTHENTICATION', request=request)
    
    def get_jwt_token(self, request: HttpRequest) -> Optional[str]:
        return self.get_token(key='HTTP_AUTHORIZATION', request=request)
    
    
class HttpClientBase:
    def __init__(self, req: HttpRequest, service_name: str) -> None:
        self.req = req
        self.config = ConfigFactory.create(name=service_name.upper())
        self.base_url = self.config.back_url.rstrip('/')
        self.headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/x-www-form-urlencoded'
        }

    def _sign(self, data: dict) -> None:
        if self.config.verify and self.config.key is not '':
            signature = Auth.sign(key=self.config.key, payload=data)
            self.headers['Authentication'] = f'JWT {signature}'

    def _url(self, path: str) -> str:
        return f"{self.base_url.rstrip('/')}/{path.strip('/')}/"
        
    def get(self, path: str) -> requests.Response:
        self._sign(data={})
        return requests.get(url=self._url(path), headers=self.headers)

    def post(self, path: str, data: dict) -> requests.Response:
        self._sign(data=data)
        return requests.post(url=self._url(path), data=data, headers=self.headers)

    def put(self, path: str, data: dict) -> requests.Response:
        self._sign(data=data)
        return requests.put(url=self._url(path), data=data, headers=self.headers)

    def patch(self, path: str, data: dict) -> requests.Response:
        self._sign(data=data)
        return requests.patch(url=self._url(path), data=data, headers=self.headers)

    def delete(self, path: str) -> requests.Response:
        self._sign(data={})
        return requests.delete(url=self._url(path), headers=self.headers)
