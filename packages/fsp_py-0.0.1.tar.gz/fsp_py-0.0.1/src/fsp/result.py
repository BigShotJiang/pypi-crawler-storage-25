"""Unified result type for all Fsp operations.

Mirrors grover's contract: every public method returns the same shape so the
output of one call can be fed into the next.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class FSPResult:
    ok: bool = True
    path: str | None = None
    data: Any = None
    error: str | None = None
    meta: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def fail(cls, error: str, path: str | None = None) -> FSPResult:
        return cls(ok=False, path=path, error=error)
