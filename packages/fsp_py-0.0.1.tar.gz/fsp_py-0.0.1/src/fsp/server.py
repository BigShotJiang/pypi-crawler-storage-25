"""MCP server exposing the FSP file system over stdio or HTTP/SSE."""

from __future__ import annotations

import argparse

from mcp.server.fastmcp import FastMCP

from fsp.file_system import FSP


def build_server(root: str = ".", host: str = "127.0.0.1", port: int = 8000) -> FastMCP:
    fs = FSP(root)
    mcp = FastMCP("fsp", host=host, port=port)

    # ---- CRUD ----

    @mcp.tool()
    def read(path: str) -> dict:
        """Read a file's text contents."""
        return fs.read(path).to_dict()

    @mcp.tool()
    def write(path: str, content: str) -> dict:
        """Write text contents to a file, creating parent directories as needed."""
        return fs.write(path, content).to_dict()

    @mcp.tool()
    def edit(path: str, old: str, new: str) -> dict:
        """Replace the first occurrence of `old` with `new` in a file."""
        return fs.edit(path, old, new).to_dict()

    @mcp.tool()
    def delete(path: str) -> dict:
        """Delete a file or directory."""
        return fs.delete(path).to_dict()

    @mcp.tool()
    def move(src: str, dst: str) -> dict:
        """Move a file or directory."""
        return fs.move(src, dst).to_dict()

    @mcp.tool()
    def copy(src: str, dst: str) -> dict:
        """Copy a file or directory."""
        return fs.copy(src, dst).to_dict()

    @mcp.tool()
    def mkdir(path: str) -> dict:
        """Create a directory (parents are created as needed)."""
        return fs.mkdir(path).to_dict()

    # ---- Navigation ----

    @mcp.tool()
    def ls(path: str = "/") -> dict:
        """List directory entries."""
        return fs.ls(path).to_dict()

    @mcp.tool()
    def tree(path: str = "/", max_depth: int = 3) -> dict:
        """Return a recursive directory tree up to `max_depth`."""
        return fs.tree(path, max_depth).to_dict()

    @mcp.tool()
    def stat(path: str) -> dict:
        """Return size, type, and timestamps for a path."""
        return fs.stat(path).to_dict()

    # ---- Pattern Search ----

    @mcp.tool()
    def glob(pattern: str, path: str = "/") -> dict:
        """Recursively match paths against a glob pattern."""
        return fs.glob(pattern, path).to_dict()

    @mcp.tool()
    def grep(pattern: str, path: str = "/") -> dict:
        """Search file contents for a regular expression."""
        return fs.grep(pattern, path).to_dict()

    return mcp


def main() -> None:
    parser = argparse.ArgumentParser(prog="fsp", description="File System Protocol MCP server")
    parser.add_argument("--root", default=".", help="Root directory exposed to MCP clients")
    parser.add_argument("--transport", choices=["stdio", "sse"], default="stdio")
    parser.add_argument("--host", default="127.0.0.1", help="Bind host (sse only)")
    parser.add_argument("--port", type=int, default=8000, help="Bind port (sse only)")
    args = parser.parse_args()

    mcp = build_server(args.root, args.host, args.port)
    mcp.run(transport=args.transport)


if __name__ == "__main__":
    main()
