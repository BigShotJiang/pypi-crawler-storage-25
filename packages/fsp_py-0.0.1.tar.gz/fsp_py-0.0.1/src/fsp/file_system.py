"""FSP — the core file system class.

v0.0.1 ships working implementations for the operations that map cleanly
onto a local POSIX file system (CRUD, navigation, pattern search).
Retrieval, graph, and query methods are present for API parity but return
a not-implemented `FSPResult` until later releases land their backends.
"""

from __future__ import annotations

import re
import shutil
from pathlib import Path
from typing import Any

from fsp.result import FSPResult


class FSP:
    def __init__(self, root: str | Path = ".") -> None:
        self.root = Path(root).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self._mounts: dict[str, dict[str, Any]] = {}

    def _resolve(self, path: str) -> Path:
        candidate = (self.root / path.lstrip("/")).resolve()
        if candidate != self.root and not candidate.is_relative_to(self.root):
            raise PermissionError(f"path escapes root: {path}")
        return candidate

    def add_mount(self, mount_path: str, backend: Any) -> FSPResult:
        # Mount routing lands in a later release; recorded for API parity.
        self._mounts[mount_path] = {"backend": repr(backend)}
        return FSPResult(path=mount_path, meta={"backend": repr(backend), "note": "recorded; routing not implemented in 0.0.1"})

    # -------------------- CRUD --------------------

    def read(self, path: str) -> FSPResult:
        try:
            p = self._resolve(path)
            data = p.read_text()
            return FSPResult(path=path, data=data, meta={"bytes": len(data)})
        except Exception as e:
            return FSPResult.fail(str(e), path)

    def write(self, path: str, content: str) -> FSPResult:
        try:
            p = self._resolve(path)
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content)
            return FSPResult(path=path, meta={"bytes": len(content)})
        except Exception as e:
            return FSPResult.fail(str(e), path)

    def edit(self, path: str, old: str, new: str) -> FSPResult:
        try:
            p = self._resolve(path)
            text = p.read_text()
            if old not in text:
                return FSPResult.fail("old string not found", path)
            updated = text.replace(old, new, 1)
            p.write_text(updated)
            return FSPResult(path=path, data=updated, meta={"replacements": 1})
        except Exception as e:
            return FSPResult.fail(str(e), path)

    def delete(self, path: str) -> FSPResult:
        try:
            p = self._resolve(path)
            if p.is_dir():
                shutil.rmtree(p)
            else:
                p.unlink()
            return FSPResult(path=path)
        except Exception as e:
            return FSPResult.fail(str(e), path)

    def move(self, src: str, dst: str) -> FSPResult:
        try:
            s = self._resolve(src)
            d = self._resolve(dst)
            d.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(s), str(d))
            return FSPResult(path=dst, meta={"from": src})
        except Exception as e:
            return FSPResult.fail(str(e), src)

    def copy(self, src: str, dst: str) -> FSPResult:
        try:
            s = self._resolve(src)
            d = self._resolve(dst)
            d.parent.mkdir(parents=True, exist_ok=True)
            if s.is_dir():
                shutil.copytree(s, d)
            else:
                shutil.copy2(s, d)
            return FSPResult(path=dst, meta={"from": src})
        except Exception as e:
            return FSPResult.fail(str(e), src)

    def mkdir(self, path: str) -> FSPResult:
        try:
            p = self._resolve(path)
            p.mkdir(parents=True, exist_ok=True)
            return FSPResult(path=path)
        except Exception as e:
            return FSPResult.fail(str(e), path)

    def mkconn(self, path: str, backend: str, **options: Any) -> FSPResult:
        return FSPResult.fail("mkconn: backend connections not implemented in 0.0.1", path)

    # -------------------- Navigation --------------------

    def ls(self, path: str = "/") -> FSPResult:
        try:
            p = self._resolve(path)
            entries = [
                {"name": e.name, "type": "dir" if e.is_dir() else "file"}
                for e in sorted(p.iterdir())
            ]
            return FSPResult(path=path, data=entries, meta={"count": len(entries)})
        except Exception as e:
            return FSPResult.fail(str(e), path)

    def tree(self, path: str = "/", max_depth: int = 3) -> FSPResult:
        try:
            top = self._resolve(path)

            def walk(p: Path, depth: int) -> dict[str, Any]:
                if not p.is_dir() or depth < 0:
                    return {"name": p.name, "type": "file" if p.is_file() else "other"}
                children = [walk(c, depth - 1) for c in sorted(p.iterdir())]
                return {"name": p.name, "type": "dir", "children": children}

            return FSPResult(path=path, data=walk(top, max_depth))
        except Exception as e:
            return FSPResult.fail(str(e), path)

    def stat(self, path: str) -> FSPResult:
        try:
            p = self._resolve(path)
            s = p.stat()
            return FSPResult(
                path=path,
                data={
                    "size": s.st_size,
                    "mtime": s.st_mtime,
                    "ctime": s.st_ctime,
                    "type": "dir" if p.is_dir() else "file",
                },
            )
        except Exception as e:
            return FSPResult.fail(str(e), path)

    # -------------------- Pattern Search --------------------

    def glob(self, pattern: str, path: str = "/") -> FSPResult:
        try:
            top = self._resolve(path)
            matches = [str(m.relative_to(self.root)) for m in top.rglob(pattern)]
            return FSPResult(path=path, data=matches, meta={"count": len(matches)})
        except Exception as e:
            return FSPResult.fail(str(e), path)

    def grep(self, pattern: str, path: str = "/") -> FSPResult:
        try:
            top = self._resolve(path)
            rx = re.compile(pattern)
            hits: list[dict[str, Any]] = []
            for p in top.rglob("*"):
                if not p.is_file():
                    continue
                try:
                    text = p.read_text()
                except (UnicodeDecodeError, PermissionError, OSError):
                    continue
                for i, line in enumerate(text.splitlines(), 1):
                    if rx.search(line):
                        hits.append(
                            {"path": str(p.relative_to(self.root)), "line": i, "text": line}
                        )
            return FSPResult(path=path, data=hits, meta={"count": len(hits)})
        except Exception as e:
            return FSPResult.fail(str(e), path)

    # -------------------- Retrieval (stubs) --------------------

    def semantic_search(self, query: str, **kwargs: Any) -> FSPResult:
        return FSPResult.fail("semantic_search: not implemented in 0.0.1")

    def lexical_search(self, query: str, **kwargs: Any) -> FSPResult:
        return FSPResult.fail("lexical_search: not implemented in 0.0.1")

    def vector_search(self, query: str, **kwargs: Any) -> FSPResult:
        return FSPResult.fail("vector_search: not implemented in 0.0.1")

    # -------------------- Graph Traversal (stubs) --------------------

    def predecessors(self, path: str, **kwargs: Any) -> FSPResult:
        return FSPResult.fail("predecessors: not implemented in 0.0.1", path)

    def successors(self, path: str, **kwargs: Any) -> FSPResult:
        return FSPResult.fail("successors: not implemented in 0.0.1", path)

    def ancestors(self, path: str, **kwargs: Any) -> FSPResult:
        return FSPResult.fail("ancestors: not implemented in 0.0.1", path)

    def descendants(self, path: str, **kwargs: Any) -> FSPResult:
        return FSPResult.fail("descendants: not implemented in 0.0.1", path)

    def neighborhood(self, path: str, **kwargs: Any) -> FSPResult:
        return FSPResult.fail("neighborhood: not implemented in 0.0.1", path)

    def meeting_subgraph(self, paths: list[str], **kwargs: Any) -> FSPResult:
        return FSPResult.fail("meeting_subgraph: not implemented in 0.0.1")

    def min_meeting_subgraph(self, paths: list[str], **kwargs: Any) -> FSPResult:
        return FSPResult.fail("min_meeting_subgraph: not implemented in 0.0.1")

    # -------------------- Graph Ranking (stubs) --------------------

    def pagerank(self, **kwargs: Any) -> FSPResult:
        return FSPResult.fail("pagerank: not implemented in 0.0.1")

    def betweenness_centrality(self, **kwargs: Any) -> FSPResult:
        return FSPResult.fail("betweenness_centrality: not implemented in 0.0.1")

    def closeness_centrality(self, **kwargs: Any) -> FSPResult:
        return FSPResult.fail("closeness_centrality: not implemented in 0.0.1")

    def degree_centrality(self, **kwargs: Any) -> FSPResult:
        return FSPResult.fail("degree_centrality: not implemented in 0.0.1")

    def in_degree_centrality(self, **kwargs: Any) -> FSPResult:
        return FSPResult.fail("in_degree_centrality: not implemented in 0.0.1")

    def out_degree_centrality(self, **kwargs: Any) -> FSPResult:
        return FSPResult.fail("out_degree_centrality: not implemented in 0.0.1")

    def hits(self, **kwargs: Any) -> FSPResult:
        return FSPResult.fail("hits: not implemented in 0.0.1")

    # -------------------- Query Engine (stubs) --------------------

    def run_query(self, query: str, **kwargs: Any) -> FSPResult:
        return FSPResult.fail("run_query: not implemented in 0.0.1")

    def cli(self, command: str, **kwargs: Any) -> FSPResult:
        return FSPResult.fail("cli: not implemented in 0.0.1")
