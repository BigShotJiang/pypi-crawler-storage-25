"""fsp — File System Protocol.

An MCP server exposing file system operations for a Plan 9–style mountable
agent environment.
"""

from fsp.file_system import FSP
from fsp.result import FSPResult

__version__ = "0.0.1"
__all__ = ["FSP", "FSPResult", "__version__"]
