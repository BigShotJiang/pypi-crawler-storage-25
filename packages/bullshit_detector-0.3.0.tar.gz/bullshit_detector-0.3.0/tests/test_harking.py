"""Tests for harking.py — breakpoint stability testing for HARKing detection."""

import numpy as np
import pytest

from bullshit_detector.harking import (
    _fit_segmented,
    breakpoint_ci_width,
    check_breakpoint,
    summarise_breakpoint,
)


# ---------------------------------------------------------------------------
# _fit_segmented
# ---------------------------------------------------------------------------


def test_fit_segmented_clear_breakpoint():
    """Deterministic breakpoint at x=5: slope 2 below, flat above."""
    x = np.linspace(0, 10, 100)
    y = np.where(x < 5, 2 * x, 10.0)
    bp, r2, slope_lo, slope_hi = _fit_segmented(x, y)
    assert 4.0 <= bp <= 6.0
    assert r2 > 0.99
    assert slope_lo > 1.5
    assert abs(slope_hi) < 0.5


def test_fit_segmented_no_data():
    """Too few points — no candidate can have >=10 on each side."""
    x = np.array([1.0, 2.0, 3.0])
    y = x.copy()
    bp, r2, slope_lo, slope_hi = _fit_segmented(x, y)
    assert bp is None
    assert r2 is None
    assert slope_lo is None
    assert slope_hi is None


def test_fit_segmented_constant_y():
    """Constant y → ss_tot == 0 → all None."""
    x = np.linspace(0, 10, 100)
    y = np.ones(100) * 5.0
    bp, r2, slope_lo, slope_hi = _fit_segmented(x, y)
    assert bp is None
    assert r2 is None
    assert slope_lo is None
    assert slope_hi is None


def test_fit_segmented_custom_candidates():
    """Custom candidate grid — best should be exactly 5.0."""
    x = np.linspace(0, 10, 100)
    y = np.where(x < 5, 2 * x, 10.0)
    candidates = np.array([3.0, 5.0, 7.0])
    bp, r2, slope_lo, slope_hi = _fit_segmented(x, y, candidates=candidates)
    assert bp == 5.0


# ---------------------------------------------------------------------------
# test_breakpoint
# ---------------------------------------------------------------------------


def test_breakpoint_real_break():
    """Clear breakpoint at 5 with mild noise — should be detected."""
    rng = np.random.default_rng(0)
    x = np.linspace(0, 10, 100)
    y = np.where(x < 5, 2 * x, 10.0) + rng.normal(0, 0.5, 100)
    result = check_breakpoint(x, y, n_boot=500, n_perm=500, seed=42)
    assert result["davies_p"] < 0.05
    assert result["delta_r2"] > 0.05
    ci_lo, ci_hi = result["bootstrap_ci"]
    assert ci_lo > 3.0
    assert ci_hi < 7.0
    assert result["n_boot_valid"] > 400
    assert result["slope_lo"] > 1.0


def test_breakpoint_no_break():
    """Purely linear data — no breakpoint should be found."""
    rng = np.random.default_rng(0)
    x = np.linspace(0, 10, 100)
    y = x + rng.normal(0, 0.5, 100)
    result = check_breakpoint(x, y, n_boot=500, n_perm=500, seed=42)
    assert result["davies_p"] > 0.10
    assert result["delta_r2"] < 0.05
    assert breakpoint_ci_width(result, x) > 0.5


def test_breakpoint_returns_all_keys():
    """Returned dict must contain exactly the expected keys."""
    rng = np.random.default_rng(0)
    x = np.linspace(0, 10, 100)
    y = x + rng.normal(0, 0.5, 100)
    result = check_breakpoint(x, y, n_boot=200, n_perm=200, seed=42)
    expected_keys = {
        "breakpoint",
        "bootstrap_ci",
        "davies_p",
        "delta_r2",
        "n_boot_valid",
        "slope_lo",
        "slope_hi",
    }
    assert set(result.keys()) == expected_keys


def test_breakpoint_seed_reproducibility():
    """Same seed → identical results."""
    rng = np.random.default_rng(0)
    x = np.linspace(0, 10, 100)
    y = x + rng.normal(0, 0.5, 100)
    r1 = check_breakpoint(x, y, n_boot=200, n_perm=200, seed=99)
    r2 = check_breakpoint(x, y, n_boot=200, n_perm=200, seed=99)
    for key in r1:
        if isinstance(r1[key], float):
            assert r1[key] == r2[key], f"Mismatch on {key}"
        elif isinstance(r1[key], tuple):
            assert r1[key] == r2[key], f"Mismatch on {key}"
        else:
            assert r1[key] == r2[key], f"Mismatch on {key}"


def test_breakpoint_insufficient_data():
    """15 points cannot give >=10 on each side for most candidates."""
    x = np.arange(15, dtype=float)
    y = x * 2.0
    result = check_breakpoint(x, y)
    assert result["breakpoint"] is None


# ---------------------------------------------------------------------------
# breakpoint_ci_width
# ---------------------------------------------------------------------------


def test_ci_width_tight():
    """Tight CI → small fractional width."""
    result = {"bootstrap_ci": (4.8, 5.2)}
    x = np.linspace(0, 10, 100)
    width = breakpoint_ci_width(result, x)
    # search range = 80th - 20th percentile = 8.0 - 2.0 = 6.0
    assert width == pytest.approx(0.4 / 6.0, abs=0.01)


def test_ci_width_wide():
    """Wide CI → large fractional width."""
    result = {"bootstrap_ci": (2.5, 7.5)}
    x = np.linspace(0, 10, 100)
    width = breakpoint_ci_width(result, x)
    assert width == pytest.approx(5.0 / 6.0, abs=0.01)


def test_ci_width_none_ci():
    """None CI → nan."""
    result = {"bootstrap_ci": (None, None)}
    x = np.linspace(0, 10, 100)
    assert np.isnan(breakpoint_ci_width(result, x))


# ---------------------------------------------------------------------------
# summarise_breakpoint
# ---------------------------------------------------------------------------


def test_summarise_contains_verdict_fail():
    """Linear data → verdict says 'does NOT survive'."""
    rng = np.random.default_rng(0)
    x = np.linspace(0, 10, 100)
    y = x + rng.normal(0, 0.5, 100)
    result = check_breakpoint(x, y, n_boot=500, n_perm=500, seed=42)
    summary = summarise_breakpoint(result, x)
    assert "does NOT survive" in summary


def test_summarise_contains_verdict_pass():
    """Clear breakpoint → verdict says 'survives resampling'."""
    rng = np.random.default_rng(0)
    x = np.linspace(0, 10, 100)
    y = np.where(x < 5, 2 * x, 10.0) + rng.normal(0, 0.5, 100)
    result = check_breakpoint(x, y, n_boot=500, n_perm=500, seed=42)
    summary = summarise_breakpoint(result, x)
    assert "survives resampling" in summary


def test_summarise_none_breakpoint():
    """No valid breakpoint → specific message."""
    result = {
        "breakpoint": None,
        "bootstrap_ci": (None, None),
        "davies_p": None,
        "delta_r2": None,
        "n_boot_valid": 0,
        "slope_lo": None,
        "slope_hi": None,
    }
    x = np.linspace(0, 10, 100)
    summary = summarise_breakpoint(result, x)
    assert "No valid breakpoint found" in summary
