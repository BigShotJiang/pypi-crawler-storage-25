"""
Tier 2/3 — Breakpoint stability testing for HARKing detection.

Tools for assessing whether a claimed breakpoint (threshold, satiation
point, changepoint) in a bivariate relationship survives resampling.
A single best-fit breakpoint in a noisy scatterplot is the archetype
of a HARKed finding: the algorithm found the split, and the narrative
was written to explain it.

This module provides:
    - Bootstrap confidence intervals on the breakpoint location
    - A Davies-style permutation test for the existence of a breakpoint
    - Convenience functions for interpretation

Based on:
    Davies, R.B. (1987), "Hypothesis testing when a nuisance parameter
    is present only under the alternative", Biometrika, 74(1), 33-43.

    Muggeo, V.M.R. (2003), "Estimating regression models with unknown
    break-points", Statistics in Medicine, 22(19), 3055-3071.

    Kerr, N.L. (1998), "HARKing: Hypothesizing After the Results are
    Known", Personality and Social Psychology Review, 2(3), 196-217.

Worked example:
    GDP-happiness satiation claim from the World Happiness 2017 dataset.
    See ``skills/04_harking_tutorial.ipynb`` for the full walkthrough.

Detector role
-------------
A Tier 2/3 screening question: "Does this breakpoint survive bootstrap
resampling and permutation testing, or is it an artefact of a single
optimisation on noisy data?"

See also ``skills/harking_detection.md`` (Check 5).
"""

import numpy as np
from numpy.polynomial.polynomial import polyfit, polyval


def _fit_segmented(
    x: np.ndarray,
    y: np.ndarray,
    candidates: np.ndarray = None,
) -> tuple:
    """Fit piecewise linear regression over a grid of candidate breakpoints.

    For each candidate breakpoint, fits two separate degree-1 polynomials
    (below and above the breakpoint) and selects the candidate that
    maximises R².  Requires at least 10 observations on each side.

    Parameters
    ----------
    x : np.ndarray
        Independent variable, 1-D.
    y : np.ndarray
        Dependent variable, 1-D, same length as x.
    candidates : np.ndarray, optional
        1-D array of breakpoint locations to evaluate.  Default:
        50 evenly spaced values between the 20th and 80th percentiles
        of x.

    Returns
    -------
    tuple
        (breakpoint, r2_segmented, slope_lo, slope_hi).
        All None if no candidate has >= 10 points on each side.
    """
    if candidates is None:
        candidates = np.linspace(
            np.percentile(x, 20), np.percentile(x, 80), 50
        )
    ss_tot = np.sum((y - y.mean()) ** 2)
    if ss_tot == 0:
        return (None, None, None, None)

    best_r2, best_bp, best_slo, best_shi = -1, None, None, None
    for bp in candidates:
        lo, hi = x <= bp, x > bp
        if lo.sum() < 10 or hi.sum() < 10:
            continue
        c_lo = polyfit(x[lo], y[lo], 1)
        c_hi = polyfit(x[hi], y[hi], 1)
        ss_res = (
            np.sum((y[lo] - polyval(x[lo], c_lo)) ** 2)
            + np.sum((y[hi] - polyval(x[hi], c_hi)) ** 2)
        )
        r2 = 1 - ss_res / ss_tot
        if r2 > best_r2:
            best_r2, best_bp = r2, bp
            best_slo, best_shi = c_lo[1], c_hi[1]

    if best_bp is None:
        return (None, None, None, None)
    return (best_bp, best_r2, best_slo, best_shi)


def check_breakpoint(
    x: np.ndarray,
    y: np.ndarray,
    n_boot: int = 1000,
    n_perm: int = 1000,
    seed: int = None,
) -> dict:
    """Test whether a breakpoint in the (x, y) relationship survives resampling.

    Fits a piecewise linear model, bootstraps the breakpoint location to
    obtain a 95% confidence interval, and runs a Davies-style permutation
    test to determine whether the segmented model improves on a linear fit
    more than expected by chance.

    Parameters
    ----------
    x : np.ndarray
        Independent variable, 1-D.
    y : np.ndarray
        Dependent variable, 1-D, same length as x.
    n_boot : int
        Number of bootstrap resamples for the breakpoint CI.
        Default 1000.
    n_perm : int
        Number of permutations for the Davies test.  Default 1000.
    seed : int, optional
        Random seed for reproducibility.  If None, no seed is set.

    Returns
    -------
    dict
        breakpoint : float
            Best-fit breakpoint location on the observed data.
        bootstrap_ci : tuple of float
            (2.5th percentile, 97.5th percentile) of the bootstrap
            breakpoint distribution.
        davies_p : float
            Permutation p-value for the existence of a breakpoint.
        delta_r2 : float
            R² improvement of the segmented model over a linear fit.
        n_boot_valid : int
            Number of bootstrap resamples that produced a valid
            breakpoint (out of n_boot attempted).
        slope_lo : float
            Slope of the segment below the breakpoint.
        slope_hi : float
            Slope of the segment above the breakpoint.

    Notes
    -----
    The Davies permutation p-value is computed as::

        p = (sum(delta_r2_perm >= delta_r2_obs) + 1) / (n_perm + 1)

    The +1 in numerator and denominator follows Phipson & Smyth (2010)
    to avoid p = 0 and to ensure the test is exact.

    Implementation extracted from ``skills/04_harking_tutorial.ipynb``,
    which demonstrates the GDP-happiness satiation claim as a worked
    HARKing example.

    Examples
    --------
    >>> import numpy as np
    >>> rng = np.random.default_rng(0)
    >>> x = np.linspace(0, 10, 100)
    >>> y = np.where(x < 5, 2 * x, 10.0) + rng.normal(0, 0.5, 100)
    >>> result = check_breakpoint(x, y, seed=42)
    >>> result['davies_p'] < 0.05  # breakpoint is real
    True
    >>> result['bootstrap_ci']  # tight around 5.0
    (...)
    """
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    if seed is not None:
        np.random.seed(seed)

    n = len(x)

    # --- Linear fit ---
    c_lin = polyfit(x, y, 1)
    ss_tot = np.sum((y - y.mean()) ** 2)
    r2_lin = 1 - np.sum((y - polyval(x, c_lin)) ** 2) / ss_tot

    # --- Observed segmented fit ---
    candidates = np.linspace(
        np.percentile(x, 20), np.percentile(x, 80), 50
    )
    obs_bp, obs_r2_seg, obs_slope_lo, obs_slope_hi = _fit_segmented(
        x, y, candidates
    )

    if obs_bp is None:
        return {
            "breakpoint": None,
            "bootstrap_ci": (None, None),
            "davies_p": None,
            "delta_r2": None,
            "n_boot_valid": 0,
            "slope_lo": None,
            "slope_hi": None,
        }

    obs_delta_r2 = obs_r2_seg - r2_lin

    # --- Bootstrap CI on breakpoint location ---
    boot_bps = []
    for _ in range(n_boot):
        idx = np.random.choice(n, n, replace=True)
        xb, yb = x[idx], y[idx]
        bp, _, slo, _ = _fit_segmented(xb, yb, candidates)
        if bp is not None and slo is not None and slo != 0:
            boot_bps.append(bp)

    boot_bps = np.array(boot_bps)
    if len(boot_bps) > 0:
        bp_ci = tuple(np.percentile(boot_bps, [2.5, 97.5]))
    else:
        bp_ci = (None, None)

    # --- Davies-style permutation test ---
    perm_delta_r2 = np.zeros(n_perm)
    for i in range(n_perm):
        y_perm = np.random.permutation(y)
        _, r2_seg_perm, _, _ = _fit_segmented(x, y_perm, candidates)
        c_perm = polyfit(x, y_perm, 1)
        ss_tot_perm = np.sum((y_perm - y_perm.mean()) ** 2)
        if ss_tot_perm == 0:
            perm_delta_r2[i] = 0.0
            continue
        r2_lin_perm = (
            1 - np.sum((y_perm - polyval(x, c_perm)) ** 2) / ss_tot_perm
        )
        if r2_seg_perm is None:
            perm_delta_r2[i] = 0.0
        else:
            perm_delta_r2[i] = r2_seg_perm - r2_lin_perm

    davies_p = (np.sum(perm_delta_r2 >= obs_delta_r2) + 1) / (n_perm + 1)

    return {
        "breakpoint": obs_bp,
        "bootstrap_ci": bp_ci,
        "davies_p": davies_p,
        "delta_r2": obs_delta_r2,
        "n_boot_valid": len(boot_bps),
        "slope_lo": obs_slope_lo,
        "slope_hi": obs_slope_hi,
    }


def breakpoint_ci_width(result: dict, x: np.ndarray) -> float:
    """Width of the bootstrap CI as a fraction of the search range.

    Parameters
    ----------
    result : dict
        Output from ``check_breakpoint()``.
    x : np.ndarray
        The original independent variable (used to define the search
        range as the 20th–80th percentile span).

    Returns
    -------
    float
        CI width as a fraction of the search range.  Values > 0.5
        indicate the breakpoint is indeterminate — the data do not
        constrain its location.

    Examples
    --------
    >>> width = breakpoint_ci_width(result, x)
    >>> width > 0.5  # indeterminate breakpoint
    True
    """
    ci_lo, ci_hi = result["bootstrap_ci"]
    if ci_lo is None or ci_hi is None:
        return float("nan")
    x = np.asarray(x, dtype=float)
    search_lo = np.percentile(x, 20)
    search_hi = np.percentile(x, 80)
    search_range = search_hi - search_lo
    if search_range == 0:
        return float("nan")
    return (ci_hi - ci_lo) / search_range


def summarise_breakpoint(result: dict, x: np.ndarray) -> str:
    """Human-readable summary of breakpoint test results.

    Parameters
    ----------
    result : dict
        Output from ``check_breakpoint()``.
    x : np.ndarray
        The original independent variable (passed to
        ``breakpoint_ci_width()``).

    Returns
    -------
    str
        Formatted multi-line summary including breakpoint location,
        bootstrap CI, CI width, Davies p-value, ΔR², slopes, and a
        plain-language verdict.

    Examples
    --------
    >>> print(summarise_breakpoint(result, x))
    Breakpoint: 1.36
    Bootstrap 95% CI: (0.68, 1.36)
    CI width (fraction of search range): 0.83
    Davies p-value: 0.450
    ΔR²: 0.033
    Slopes: 1.90 (below) → -0.10 (above)
    Verdict: breakpoint does NOT survive resampling
    """
    if result["breakpoint"] is None:
        return "No valid breakpoint found (too few observations on one side)."

    ci_lo, ci_hi = result["bootstrap_ci"]
    width = breakpoint_ci_width(result, x)

    # Verdict logic
    fails_davies = result["davies_p"] is not None and result["davies_p"] > 0.05
    fails_width = width > 0.5
    if fails_davies or fails_width:
        verdict = "breakpoint does NOT survive resampling"
    else:
        verdict = "breakpoint survives resampling (but check effect size)"

    lines = [
        f"Breakpoint: {result['breakpoint']:.2f}",
        f"Bootstrap 95% CI: ({ci_lo:.2f}, {ci_hi:.2f})"
        if ci_lo is not None
        else "Bootstrap 95% CI: (N/A, N/A)",
        f"CI width (fraction of search range): {width:.2f}",
        f"Davies p-value: {result['davies_p']:.3f}",
        f"\u0394R\u00b2: {result['delta_r2']:.3f}",
        f"Slopes: {result['slope_lo']:.2f} (below)"
        f" \u2192 {result['slope_hi']:.2f} (above)",
        f"Verdict: {verdict}",
    ]
    return "\n".join(lines)
