from __future__ import annotations

import sys
import os
from dataclasses import dataclass
from typing import Literal, Optional

# allow local dev imports
_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

# IMPORTANT: import CORE implementations
from .carbon_api import CarbonAPI
from .scheduler import CarbonScheduler as CoreScheduler
from .rl_agent import RLScheduler as CoreRL


@dataclass
class ScheduleResult:
    best_window: str
    worst_window: str
    carbon_saving_pct: float
    carbon_saving_grams: float
    strategy: Literal["rl", "heuristic"]
    urgency: Literal["low", "medium", "high"]
    duration_minutes: int
    current_carbon_intensity: Optional[float] = None
    best_avg_carbon: Optional[float] = None
    worst_avg_carbon: Optional[float] = None


class CarbonScheduler:
    def __init__(self, duration_minutes=60, urgency="medium"):
        self.duration_minutes = duration_minutes
        self.urgency = urgency

    def recommend(self) -> ScheduleResult:
        import numpy as np

        api = CarbonAPI()
        current = api.get_current_intensity()
        df = api.get_24h_forecast()

        heuristic = CoreScheduler(df)
        best, worst, _ = heuristic.find_optimal_window(
            duration_minutes=self.duration_minutes,
            urgency=self.urgency
        )

        carbon_values = df["carbon"].dropna().values
        volatility = float(np.std(carbon_values))

        strategy = "heuristic"
        rl_index = None

        if len(carbon_values) >= 4 and volatility > 30:
            try:
                rl = CoreRL(carbon_values)
                rl_index = rl.train()
                strategy = "rl"
            except:
                pass

        if strategy == "rl" and rl_index is not None:
            best_start = df["from"].iloc[rl_index]
            best_end = df["to"].iloc[min(rl_index + 2, len(df)-1)]
            best_avg = float(df["carbon"].iloc[rl_index:rl_index+2].mean())
        else:
            best_start = best["start"]
            best_end = best["end"]
            best_avg = float(best["avg_carbon"])

        worst_avg = float(worst["avg_carbon"])

        saving_pct = 0.0 if worst_avg == 0 else (worst_avg - best_avg) / worst_avg * 100

        duration_h = self.duration_minutes / 60
        saving_grams = (worst_avg - best_avg) * 0.3 * duration_h

        return ScheduleResult(
            best_window=f"{best_start} — {best_end}",
            worst_window=f"{worst['start']} — {worst['end']}",
            carbon_saving_pct=round(saving_pct, 1),
            carbon_saving_grams=round(saving_grams, 2),
            strategy=strategy,
            urgency=self.urgency,
            duration_minutes=self.duration_minutes,
            current_carbon_intensity=current,
            best_avg_carbon=round(best_avg, 1),
            worst_avg_carbon=round(worst_avg, 1),
        )


__all__ = ["CarbonScheduler", "ScheduleResult"]