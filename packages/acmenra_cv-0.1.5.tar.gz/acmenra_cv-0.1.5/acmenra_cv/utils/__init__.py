"""
Utils: Foundational utility layer for high-performance computer vision operations.

Provides type-safe, validated helper functions for illumination estimation,
geometric calculations, and adaptive preprocessing — engineered for embedded
systems with strict input validation and graceful degradation.
"""

from acmenra_cv.utils.utils import get_frame_illumination
# from acmenra_cv.utils.geometry import ...  # ← раскомментируй, когда добавишь функции
# from acmenra_cv.utils.preprocessing import ...  # ← раскомментируй, когда добавишь функции

__all__ = [
    'get_frame_illumination',
    # 'transform_coords',      # пример: из geometry.py
    # 'adaptive_preprocess',   # пример: из preprocessing.py
]

__version__ = "0.1.5"