"""Pipeline orchestration tests — heal loop, error routing, asset wiring.

End-to-end happy path goes through `test_e2e_godot.py` with a real Godot
install. Here we exercise the orchestration logic with mocked adapters
so failures can be deterministically injected.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from sage.games.engines.base import (
    BuildArtifact,
    EngineCapability,
    GameRequest,
)
from sage.games.exceptions import EngineNotInstalled, GameBuildIncomplete
from sage.games.pipeline import build_game


# Minimal LLM stub. Returns valid plan JSON for decomposition, valid GD
# blocks for script emission.
def _stub_generate(prompt: str) -> str:
    if "Extract the spec" in prompt:
        return json.dumps({
            "title": "Test Game",
            "description": "A test platformer.",
            "features": ["movement", "scoring"],
            "sprites": [{"role": "player", "prompt": "player sprite"}],
            "meshes": [],
            "audio": [{"role": "ambient", "prompt": "calm music", "kind": "music"}],
        })
    return "```Main.gd\nextends Node2D\nfunc _ready(): pass\n```"


def _request(engine: str | None = None) -> GameRequest:
    return GameRequest(engine=engine, genre="platformer", perspective="2d",
                        raw_prompt="build a 2D platformer", target="web")


class TestPipelineSuccess:
    def test_complete_build_returns_report(self, tmp_path: Path) -> None:
        """Happy path with mocked adapter — pipeline returns report with
        every count populated."""
        artifact = BuildArtifact(
            output_path=tmp_path / "build" / "index.html",
            target="web", size_bytes=1024, duration_s=12.0,
        )
        adapter = MagicMock()
        adapter.name = "godot"
        adapter.capabilities = EngineCapability.full()
        adapter.detect.return_value = Path("/fake/godot")
        adapter.scaffold.return_value = None
        adapter.emit_scripts.return_value = [tmp_path / "scripts" / "Main.gd"]
        adapter.consume_assets.return_value = None
        adapter.build.return_value = artifact

        with patch("sage.games.pipeline.get_adapter", return_value=adapter):
            report = build_game(_request(), tmp_path, _stub_generate)

        assert report.engine == "godot"
        assert report.build_artifact == str(artifact.output_path)
        assert report.heal_rounds == 0
        assert report.scripts_written == ["scripts/Main.gd"]


class TestPipelineHealLoop:
    def test_build_failures_trigger_heal(self, tmp_path: Path) -> None:
        """Adapter fails twice then succeeds — heal_rounds should be 2."""
        succeed_after = 2
        artifact = BuildArtifact(
            output_path=tmp_path / "build" / "index.html",
            target="web", size_bytes=1024, duration_s=12.0,
        )
        call_count = {"n": 0}

        def maybe_fail(*_a, **_kw):
            call_count["n"] += 1
            if call_count["n"] <= succeed_after:
                raise RuntimeError("simulated build failure")
            return artifact

        adapter = MagicMock()
        adapter.name = "godot"
        adapter.capabilities = EngineCapability.full()
        adapter.detect.return_value = Path("/fake/godot")
        adapter.build.side_effect = maybe_fail

        with patch("sage.games.pipeline.get_adapter", return_value=adapter):
            report = build_game(_request(), tmp_path, _stub_generate)

        assert report.heal_rounds == succeed_after
        # emit_scripts called once initially + once per heal round.
        assert adapter.emit_scripts.call_count == 1 + succeed_after

    def test_heal_exhaustion_raises_game_build_incomplete(
        self, tmp_path: Path,
    ) -> None:
        """If build keeps failing past cap, raise the typed exception."""
        adapter = MagicMock()
        adapter.name = "godot"
        adapter.capabilities = EngineCapability.full()
        adapter.detect.return_value = Path("/fake/godot")
        adapter.build.side_effect = RuntimeError("persistent failure")

        with patch("sage.games.pipeline.get_adapter", return_value=adapter):
            with pytest.raises(GameBuildIncomplete) as exc_info:
                build_game(_request(), tmp_path, _stub_generate, heal_rounds=2)
            assert exc_info.value.report["heal_rounds"] == 2


class TestPipelineEngineMissing:
    def test_engine_not_installed_raises_immediately(self, tmp_path: Path) -> None:
        """If detect() returns None for a BUILD-capable engine, abort
        before any LLM call — we shouldn't burn tokens on a build that
        can't possibly produce a binary."""
        adapter = MagicMock()
        adapter.name = "godot"
        adapter.capabilities = EngineCapability.full()
        adapter.detect.return_value = None
        adapter.install_hint.return_value = "brew install --cask godot"

        with patch("sage.games.pipeline.get_adapter", return_value=adapter):
            with pytest.raises(EngineNotInstalled):
                build_game(_request(), tmp_path, _stub_generate)
        adapter.scaffold.assert_not_called()  # no work attempted

    def test_scaffold_only_engine_skips_build(self, tmp_path: Path) -> None:
        """An adapter without BUILD capability shouldn't try to build —
        return report after scaffold + scripts + assets."""
        adapter = MagicMock()
        adapter.name = "gamemaker"
        adapter.capabilities = EngineCapability.SCAFFOLD | EngineCapability.SCRIPTS
        adapter.detect.return_value = None  # GUI engines never have headless

        with patch("sage.games.pipeline.get_adapter", return_value=adapter):
            report = build_game(_request("gamemaker"), tmp_path, _stub_generate)

        assert report.build_artifact is None
        adapter.build.assert_not_called()
