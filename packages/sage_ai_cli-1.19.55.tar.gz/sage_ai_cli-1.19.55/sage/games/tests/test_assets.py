"""Asset-generator tests.

We don't hit Vertex/Replicate in unit tests — the placeholder + ffmpeg
paths are what we test here. Network-bound paths are covered by the
opt-in e2e suite.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from sage.games.assets.audio import AudioGenerator
from sage.games.assets.manifest import AssetManifest
from sage.games.assets.meshes import MeshGenerator, _pick_primitive
from sage.games.assets.sprites import SpriteGenerator


class TestSpriteGenerator:
    def test_falls_back_to_placeholder_when_vertex_unavailable(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        # Strip credentials so the generator picks the placeholder path.
        for var in ("GOOGLE_APPLICATION_CREDENTIALS",
                     "VERTEX_AI_PROJECT", "GCP_PROJECT"):
            monkeypatch.delenv(var, raising=False)
        gen = SpriteGenerator(tmp_path)
        result = gen.generate("player", "blue space marine", size=(64, 64))
        assert result.backend == "placeholder"
        assert result.path.is_file()
        # Validate PNG magic bytes — the placeholder must produce a real
        # decodable PNG so engines don't choke on import.
        assert result.path.read_bytes()[:8] == b"\x89PNG\r\n\x1a\n"
        assert result.width == 64 and result.height == 64

    def test_role_color_is_deterministic(self, tmp_path: Path) -> None:
        gen = SpriteGenerator(tmp_path)
        a = gen.generate("player", "x")
        b = gen.generate("player", "x")
        # Same role → same color → same bytes (mtime aside)
        assert a.path.read_bytes() == b.path.read_bytes()


class TestMeshGenerator:
    @pytest.mark.parametrize("prompt,expected_prim", [
        ("orange ball",         "sphere"),
        ("wooden crate",        "cube"),
        ("player character",    "capsule"),
        ("flat ground",         "plane"),
        ("tall pine tree",      "cone"),
        ("brick pillar",        "cylinder"),
        ("nothing matches",     "cube"),     # default
    ])
    def test_prim_heuristic(self, prompt: str, expected_prim: str) -> None:
        assert _pick_primitive(prompt) == expected_prim

    def test_placeholder_glb_is_written_when_no_blender(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        # Force the "no blender" path by stubbing the finder.
        import sage.games.assets.meshes as meshes_mod
        monkeypatch.setattr(meshes_mod, "_find_blender", lambda: None)
        gen = MeshGenerator(tmp_path)
        result = gen.generate("player", "blue capsule")
        assert result.backend == "placeholder"
        assert result.path.is_file()
        # glTF binary magic is "glTF" big-endian at offset 0.
        assert result.path.read_bytes()[:4] == b"glTF"


class TestAudioGenerator:
    def test_silent_fallback_when_no_ffmpeg(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.delenv("REPLICATE_API_TOKEN", raising=False)
        import sage.games.assets.audio as audio_mod
        monkeypatch.setattr(audio_mod, "_ffmpeg_available", lambda: False)
        gen = AudioGenerator(tmp_path)
        music = gen.generate_music("ambient", "calm forest", seconds=5)
        sfx = gen.generate_sfx("jump", "boing")
        assert music.backend == "silent"
        assert sfx.backend == "silent"
        # The silent WAV path produces a valid RIFF header.
        if sfx.path.suffix == ".wav":
            assert sfx.path.read_bytes()[:4] == b"RIFF"


class TestAssetManifest:
    def test_total_count_sums_all_categories(self) -> None:
        m = AssetManifest(
            sprites={"a": Path("a.png"), "b": Path("b.png")},
            meshes={"c": Path("c.glb")},
            audio={"d": Path("d.ogg")},
        )
        assert m.total_count() == 4
