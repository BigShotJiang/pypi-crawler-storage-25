"""Adapter unit tests — scaffold layout, registry lookup, BUILD gating.

Live e2e tests against real engines live in `test_e2e_godot.py` and are
opt-in via `SAGE_E2E_GODOT=1`. These tests stay fast + mockable.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from sage.games.assets.manifest import AssetManifest
from sage.games.engines import REGISTRY, get_adapter
from sage.games.engines.base import EngineCapability, GamePlan, GameRequest
from sage.games.exceptions import BuildNotSupported, EngineNotInstalled


def _plan(title="Test Game", *, genre="platformer", perspective="2d") -> GamePlan:
    return GamePlan(
        request=GameRequest(genre=genre, perspective=perspective, raw_prompt=""),
        title=title,
        description=f"A test {genre}.",
        features=["movement", "scoring"],
    )


class TestRegistry:
    def test_all_engines_registered(self) -> None:
        for key in ("godot", "unity", "unreal", "bevy", "phaser",
                     "love2d", "gamemaker", "construct", "rpgmaker"):
            assert key in REGISTRY, f"{key} missing from REGISTRY"

    def test_default_engine_is_godot(self) -> None:
        adapter = get_adapter(None)
        assert adapter.name == "godot"

    def test_unknown_engine_falls_back_to_default(self) -> None:
        adapter = get_adapter("nonexistent")
        assert adapter.name == "godot"


class TestGodotAdapter:
    """Scaffold + script emission. Build is exercised in the e2e suite."""

    def test_scaffold_writes_project_godot(self, tmp_path: Path) -> None:
        adapter = get_adapter("godot")
        adapter.scaffold(_plan(), tmp_path, log=lambda _m: None)
        assert (tmp_path / "project.godot").is_file()
        assert (tmp_path / "scenes" / "Main.tscn").is_file()
        assert (tmp_path / "export_presets.cfg").is_file()
        assert (tmp_path / "icon.svg").is_file()
        for sub in ("assets/sprites", "assets/audio", "assets/meshes"):
            assert (tmp_path / sub).is_dir(), f"missing {sub}"

    def test_emit_scripts_writes_gd_files(self, tmp_path: Path) -> None:
        adapter = get_adapter("godot")
        adapter.scaffold(_plan(), tmp_path, log=lambda _m: None)
        gd_blob = (
            "```Main.gd\nextends Node2D\nfunc _ready(): pass\n```\n"
            "```Player.gd\nextends CharacterBody2D\nfunc _process(d): pass\n```"
        )
        written = adapter.emit_scripts(
            _plan(), tmp_path,
            generate=lambda _p: gd_blob,
            log=lambda _m: None,
        )
        assert (tmp_path / "scripts" / "Main.gd").is_file()
        assert (tmp_path / "scripts" / "Player.gd").is_file()
        assert len(written) == 2

    def test_build_raises_when_engine_missing(self, tmp_path: Path) -> None:
        adapter = get_adapter("godot")
        with patch.object(adapter, "detect", return_value=None):
            with pytest.raises(EngineNotInstalled) as exc_info:
                adapter.build(tmp_path, target="web", log=lambda _m: None)
            assert "godot" in str(exc_info.value).lower()
            assert "install" in str(exc_info.value).lower()


class TestUnityAdapter:
    def test_scaffold_writes_unity_layout(self, tmp_path: Path) -> None:
        adapter = get_adapter("unity")
        adapter.scaffold(_plan(), tmp_path, log=lambda _m: None)
        assert (tmp_path / "ProjectSettings" / "ProjectVersion.txt").is_file()
        assert (tmp_path / "Assets" / "Editor" / "SageBuilder.cs").is_file()
        assert (tmp_path / "Packages" / "manifest.json").is_file()
        # Editor builder must include the four build methods the cloudbuild
        # `-executeMethod` flag invokes.
        builder = (tmp_path / "Assets" / "Editor" / "SageBuilder.cs").read_text()
        for method in ("BuildWebGL", "BuildWindows", "BuildMac", "BuildLinux"):
            assert method in builder, f"SageBuilder.cs missing {method}"

    def test_build_raises_when_engine_missing(self, tmp_path: Path) -> None:
        adapter = get_adapter("unity")
        with patch.object(adapter, "detect", return_value=None):
            with pytest.raises(EngineNotInstalled):
                adapter.build(tmp_path, target="web", log=lambda _m: None)


class TestUnrealAdapter:
    def test_scaffold_writes_uproject(self, tmp_path: Path) -> None:
        adapter = get_adapter("unreal")
        adapter.scaffold(_plan(title="My Game"), tmp_path, log=lambda _m: None)
        uproject = list(tmp_path.glob("*.uproject"))
        assert len(uproject) == 1, f"expected exactly 1 .uproject, got {uproject}"
        # Sanitize_name should have turned "My Game" → "MyGame"
        assert uproject[0].name == "MyGame.uproject"
        assert (tmp_path / "Source" / "MyGame" / "MyGame.Build.cs").is_file()

    def test_build_raises_when_engine_missing(self, tmp_path: Path) -> None:
        adapter = get_adapter("unreal")
        with patch.object(adapter, "detect", return_value=None):
            with pytest.raises(EngineNotInstalled):
                adapter.build(tmp_path, target="windows", log=lambda _m: None)


class TestStubAdapters:
    """The GUI-only engines (GameMaker/Construct/RPGMaker) must scaffold
    cleanly and refuse to build with a typed exception."""

    @pytest.mark.parametrize("name", ["gamemaker", "construct", "rpgmaker"])
    def test_build_raises_build_not_supported(self, tmp_path: Path, name: str) -> None:
        adapter = get_adapter(name)
        adapter.scaffold(_plan(), tmp_path, log=lambda _m: None)
        with pytest.raises(BuildNotSupported) as exc_info:
            adapter.build(tmp_path, target="web", log=lambda _m: None)
        # User must be able to act on the error.
        assert "editor" in str(exc_info.value).lower()
        # Capability flag must NOT advertise BUILD.
        assert not (adapter.capabilities & EngineCapability.BUILD)

    def test_bevy_scaffold_writes_cargo_toml(self, tmp_path: Path) -> None:
        adapter = get_adapter("bevy")
        adapter.scaffold(_plan(), tmp_path, log=lambda _m: None)
        toml = (tmp_path / "Cargo.toml").read_text()
        assert "bevy" in toml and "0.14" in toml

    def test_phaser_scaffold_writes_package_json(self, tmp_path: Path) -> None:
        adapter = get_adapter("phaser")
        adapter.scaffold(_plan(), tmp_path, log=lambda _m: None)
        import json
        pkg = json.loads((tmp_path / "package.json").read_text())
        assert "phaser" in pkg["dependencies"]
        assert "vite" in pkg["devDependencies"]


class TestAssetConsumption:
    """Adapters must place files where their engine expects them. Verified
    with a synthetic manifest pointing at temp files."""

    def test_godot_consumes_into_res_assets(self, tmp_path: Path) -> None:
        adapter = get_adapter("godot")
        adapter.scaffold(_plan(), tmp_path, log=lambda _m: None)
        sprite_src = tmp_path / "src_sprite.png"
        sprite_src.write_bytes(b"\x89PNG\r\n\x1a\n")
        manifest = AssetManifest(sprites={"player": sprite_src})
        adapter.consume_assets(manifest, tmp_path, log=lambda _m: None)
        assert (tmp_path / "assets" / "sprites" / "src_sprite.png").is_file()
