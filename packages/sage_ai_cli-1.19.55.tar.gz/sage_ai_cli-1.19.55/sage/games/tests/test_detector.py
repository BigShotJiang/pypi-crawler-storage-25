"""Detector test matrix — 20+ prompts → expected (task_type, engine)."""

from __future__ import annotations

import pytest

from sage.games.detector import classify_prompt


# Each row: (prompt, expected_task_type, expected_engine).
# expected_engine is None when sage should pick the default (Godot).
_CASES: list[tuple[str, str, str | None]] = [
    # Engine names — explicit
    ("Build me a 2D platformer in Unity",                        "game", "unity"),
    ("Make a horror walking sim in Unreal Engine 5",             "game", "unreal"),
    ("UE5 first-person shooter on Mars",                         "game", "unreal"),
    ("Build a Godot 4 RPG with turn-based combat",               "game", "godot"),
    ("Phaser 3 browser puzzle game",                             "game", "phaser"),
    ("Bevy roguelike with procedural dungeons",                  "game", "bevy"),
    ("LÖVE 2D shoot-em-up",                                      "game", "love2d"),

    # Genre only — sage picks default engine
    ("A 2D pixel-art platformer where a fox jumps between trees", "game", None),
    ("Tower defense game with three enemy types",                 "game", None),
    ("Bullet hell shmup in space",                                "game", None),
    ("Metroidvania with double-jump and dash",                    "game", None),
    ("Match-3 puzzle game",                                       "game", None),

    # Game noun + perspective
    ("Build a first-person walking simulator in a forest",        "game", None),
    ("Top-down survival game with crafting",                      "game", None),

    # Webapp prompts — must NOT be classified as games
    ("Build a TODO app with FastAPI and React",                   "webapp", None),
    ("CRUD admin dashboard for an e-commerce platform",            "webapp", None),
    ("Multi-tenant SaaS for invoice management",                   "webapp", None),
    ("Build a real-time chat app with WebSockets",                 "webapp", None),

    # Tricky — mentions "game" but is really a quiz / scoring app
    # (sage might still classify as game; that's acceptable.)
    # We don't assert these to keep test stable across detector tuning.
]


@pytest.mark.parametrize("prompt,task_type,engine", _CASES)
def test_classify_prompt(prompt: str, task_type: str, engine: str | None) -> None:
    actual_type, request = classify_prompt(prompt)
    assert actual_type == task_type, (
        f"Prompt {prompt!r}: expected task_type={task_type!r}, got {actual_type!r}"
    )
    if task_type == "game":
        assert request is not None, "game classification must return a GameRequest"
        assert request.engine == engine, (
            f"Prompt {prompt!r}: expected engine={engine!r}, got {request.engine!r}"
        )


def test_classify_attaches_raw_prompt() -> None:
    """The GameRequest must carry the original prompt — the games pipeline
    needs it for decomposition."""
    prompt = "Build me a Godot 4 RPG"
    _, request = classify_prompt(prompt)
    assert request is not None
    assert request.raw_prompt == prompt


def test_no_generate_fallback_is_safe() -> None:
    """Detector must not crash when called without `generate` — webapp
    callers don't always have an LLM handle available."""
    actual_type, request = classify_prompt("something ambiguous")
    assert actual_type in {"game", "webapp"}
