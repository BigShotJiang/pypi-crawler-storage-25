"""Tests for scripts/sync_model_catalogs.py — the weekly Ollama + OpenRouter
catalog refresher.

We don't hit GCS or ollama.com in tests; the network-bound paths are
mocked. The interesting logic is the diff (what's new on the public
library vs already in GCS) and the manifest-digest extraction.
"""

from __future__ import annotations

import importlib.util
import json
from pathlib import Path
from unittest.mock import patch

import pytest


def _load_sync_module():
    """Import scripts/sync_model_catalogs.py as a regular module.

    It's under scripts/ (not on sys.path), so we use importlib's spec
    machinery. Cached per session so tests don't re-import.
    """
    project = Path(__file__).resolve().parent.parent.parent
    script_path = project / "scripts" / "sync_model_catalogs.py"
    spec = importlib.util.spec_from_file_location(
        "sync_model_catalogs", script_path,
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


sync = _load_sync_module()


class TestLibraryDiff:
    def test_new_models_count_as_add(self) -> None:
        """remote={a,b,c}, GCS={a, fresh}. Expect b+c added, a unchanged
        because its remote digest matches GCS."""
        with patch.object(sync, "list_ollama_library_remote",
                           return_value={"a", "b", "c"}), \
             patch.object(sync, "list_ollama_library_gcs",
                           return_value={"a"}), \
             patch.object(sync, "remote_manifest_digest",
                           return_value="same"), \
             patch.object(sync, "gcs_manifest_digest",
                           return_value="same"), \
             patch.object(sync, "pull_and_upload_ollama", return_value=True) as pull:
            added, refreshed, failed = sync.sync_ollama(dry_run=False, limit=0)
        assert added == 2 and refreshed == 0 and failed == 0
        assert {c.args[0] for c in pull.call_args_list} == {"b", "c"}

    def test_stale_existing_model_gets_refreshed(self) -> None:
        """remote digest != GCS digest → model is re-pulled even though
        it's already in GCS."""
        with patch.object(sync, "list_ollama_library_remote",
                           return_value={"a"}), \
             patch.object(sync, "list_ollama_library_gcs",
                           return_value={"a"}), \
             patch.object(sync, "remote_manifest_digest",
                           return_value="NEW_DIGEST"), \
             patch.object(sync, "gcs_manifest_digest",
                           return_value="OLD_DIGEST"), \
             patch.object(sync, "pull_and_upload_ollama", return_value=True):
            added, refreshed, failed = sync.sync_ollama(dry_run=False, limit=0)
        assert added == 0 and refreshed == 1

    def test_fresh_existing_model_is_skipped(self) -> None:
        """Identical digests → no work."""
        with patch.object(sync, "list_ollama_library_remote",
                           return_value={"a"}), \
             patch.object(sync, "list_ollama_library_gcs",
                           return_value={"a"}), \
             patch.object(sync, "remote_manifest_digest",
                           return_value="SAME"), \
             patch.object(sync, "gcs_manifest_digest",
                           return_value="SAME"), \
             patch.object(sync, "pull_and_upload_ollama") as pull:
            added, refreshed, _ = sync.sync_ollama(dry_run=False, limit=0)
        assert added == 0 and refreshed == 0
        pull.assert_not_called()

    def test_unknown_digests_force_refresh(self) -> None:
        """If we can't read either side's digest, default to re-pulling
        rather than silently sitting on a stale bundle."""
        with patch.object(sync, "list_ollama_library_remote",
                           return_value={"a"}), \
             patch.object(sync, "list_ollama_library_gcs",
                           return_value={"a"}), \
             patch.object(sync, "remote_manifest_digest", return_value=""), \
             patch.object(sync, "gcs_manifest_digest", return_value=""), \
             patch.object(sync, "pull_and_upload_ollama", return_value=True):
            added, refreshed, _ = sync.sync_ollama(dry_run=False, limit=0)
        assert refreshed == 1

    def test_limit_zero_means_unlimited(self) -> None:
        """The user explicitly asked for "all the updated models weekly,
        not in pieces." Default cap of 0 = no cap."""
        new = {f"model{i}" for i in range(50)}
        with patch.object(sync, "list_ollama_library_remote", return_value=new), \
             patch.object(sync, "list_ollama_library_gcs", return_value=set()), \
             patch.object(sync, "pull_and_upload_ollama", return_value=True) as pull:
            added, _, _ = sync.sync_ollama(dry_run=False, limit=0)
        assert added == 50
        assert pull.call_count == 50

    def test_positive_limit_is_respected_for_tight_disk_runs(self) -> None:
        """Explicit positive limit (e.g. operator running --limit 5 on a
        full disk) is still honored."""
        new = {f"model{i}" for i in range(50)}
        with patch.object(sync, "list_ollama_library_remote", return_value=new), \
             patch.object(sync, "list_ollama_library_gcs", return_value=set()), \
             patch.object(sync, "pull_and_upload_ollama", return_value=True) as pull:
            added, _, _ = sync.sync_ollama(dry_run=False, limit=5)
        assert added == 5
        assert pull.call_count == 5


class TestManifestDigests:
    def test_extracts_config_and_layer_digests(self, tmp_path: Path) -> None:
        manifest = tmp_path / "latest"
        manifest.write_text(json.dumps({
            "config": {"digest": "sha256:aaa"},
            "layers": [
                {"digest": "sha256:bbb"},
                {"digest": "sha256:ccc"},
            ],
        }), encoding="utf-8")
        digests = sync._digests_from_manifest(manifest)
        assert digests == {"sha256:aaa", "sha256:bbb", "sha256:ccc"}

    def test_malformed_manifest_returns_empty(self, tmp_path: Path) -> None:
        bad = tmp_path / "bad"
        bad.write_text("{not valid json", encoding="utf-8")
        assert sync._digests_from_manifest(bad) == set()


class TestLibraryScrape:
    def test_extracts_names_from_html(self) -> None:
        """The scraper pulls model names out of `<a href="/library/<name>">`
        anchors. Verify the regex on a representative snippet."""
        html = """
        <a href="/library/llama3.2">Llama 3.2</a>
        <a href="/library/deepseek-r1">DeepSeek R1</a>
        <a href="/library/qwen3-coder?tag=latest">Qwen3 Coder</a>
        <a href="/not-library/something">Not a model</a>
        <a href="/library/Test-Model-2">Tricky name</a>
        """
        with patch("httpx.Client") as MockClient:
            instance = MockClient.return_value.__enter__.return_value
            response = instance.get.return_value
            response.text = html
            response.raise_for_status.return_value = None
            names = sync.list_ollama_library_remote()
        assert "llama3.2" in names
        assert "deepseek-r1" in names
        assert "qwen3-coder" in names
        assert "test-model-2" in names      # case-folded
        # The /not-library/ link must NOT have been counted.
        assert "something" not in names


class TestOpenRouterRefresh:
    def test_dry_run_does_not_unlink(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Dry-run should report what it would do but not actually delete."""
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir()
        cache_file = cache_dir / "openrouter_models_v3.json"
        cache_file.write_text('[]')
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        # `.sage/cache/...`
        sage_cache = tmp_path / ".sage" / "cache"
        sage_cache.mkdir(parents=True)
        sage_cache_file = sage_cache / "openrouter_models_v3.json"
        sage_cache_file.write_text("[]")
        result = sync.refresh_openrouter_cache(dry_run=True)
        assert result == -1     # dry-run sentinel
        assert sage_cache_file.exists(), "dry-run must not delete cache"
