from __future__ import annotations

from dataclasses import dataclass, field
from typing import Union


@dataclass(frozen=True)
class Inline:
    """All attributes on the element's opening line, single-space-separated."""


@dataclass(frozen=True)
class PerLine:
    """One attribute per line, indented one level deeper than the element, with equals signs aligned to the longest attribute name."""


@dataclass(frozen=True)
class AlignedGroup:
    """Inline, but attributes column-aligned across consecutive same-tag siblings."""


AttributeLayout = Union[Inline, PerLine, AlignedGroup]


@dataclass(frozen=True)
class ElementRule:
    """Per-tag formatting specification.

    Attributes:
        tags: One or more local element names (namespace-stripped) this rule
            covers. `{ns}LocalName` matches `tags=("LocalName",)`. Pass a
            tuple of names to apply the same layout and attribute order to
            multiple element types and have them share a single
            `AlignedGroup` run.
        attribute_order: Partial ordering. Listed attributes appear first in the
            given order; unlisted attributes follow in document order. `None`
            preserves all original order.
        layout: How attributes are laid out. Defaults to `Inline`.
    """

    tags: tuple[str, ...]
    attribute_order: tuple[str, ...] | None = None
    layout: AttributeLayout = field(default_factory=Inline)
