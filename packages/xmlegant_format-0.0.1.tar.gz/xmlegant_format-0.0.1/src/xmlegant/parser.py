from __future__ import annotations

import codecs
import io
import re
from dataclasses import dataclass
from pathlib import Path

from lxml import etree

_BOM = b"\xef\xbb\xbf"
_WHITESPACE = (b" ", b"\t", b"\n", b"\r")
_ENCODING_RE = re.compile(rb"""encoding\s*=\s*["']([^"']+)["']""")


class UnsupportedEncodingError(ValueError):
    pass


@dataclass(frozen=True)
class ParsedDocument:
    decl: str | None
    doctype: str | None
    tree: etree._ElementTree
    encoding: str


def _is_utf8(name: str) -> bool:
    try:
        return codecs.lookup(name).name == "utf-8"
    except LookupError:
        return False


def _make_parser() -> etree.XMLParser:
    return etree.XMLParser(remove_comments=False, remove_blank_text=False)


def _skip_ws(data: bytes, i: int) -> int:
    n = len(data)
    while i < n and data[i : i + 1] in _WHITESPACE:
        i += 1
    return i


def _extract_prologue(data: bytes) -> tuple[str | None, str | None, str]:
    encoding = "UTF-8"
    decl: str | None = None
    doctype: str | None = None

    i = 3 if data[:3] == _BOM else 0
    i = _skip_ws(data, i)

    if data[i : i + 5] == b"<?xml":
        end = data.find(b"?>", i)
        if end != -1:
            decl_bytes = data[i : end + 2]
            enc_match = _ENCODING_RE.search(decl_bytes)
            if enc_match:
                encoding = enc_match.group(1).decode("ascii")
            decl = decl_bytes.decode(encoding)
            i = _skip_ws(data, end + 2)

    if data[i : i + 9] == b"<!DOCTYPE":
        j = i + 9
        depth = 0
        n = len(data)
        while j < n:
            ch = data[j : j + 1]
            if ch == b"[":
                depth += 1
            elif ch == b"]":
                depth -= 1
            elif ch == b">" and depth == 0:
                break
            j += 1
        if j < n:
            doctype = data[i : j + 1].decode(encoding)

    return decl, doctype, encoding


def parse_bytes(data: bytes) -> ParsedDocument:
    decl, doctype, encoding = _extract_prologue(data)
    if not _is_utf8(encoding):
        raise UnsupportedEncodingError(
            f"xmlegant only supports UTF-8 input; declared encoding {encoding!r}"
        )
    tree = etree.parse(io.BytesIO(data), _make_parser())
    return ParsedDocument(decl=decl, doctype=doctype, tree=tree, encoding=encoding)


def parse_path(path: Path) -> ParsedDocument:
    return parse_bytes(path.read_bytes())
