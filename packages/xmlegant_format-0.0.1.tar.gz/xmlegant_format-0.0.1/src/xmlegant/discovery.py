from __future__ import annotations

import importlib.util
from pathlib import Path

from xmlegant.registry import Rule, registered_rules, reset_registry


class PluginImportError(Exception):
    pass


def load_plugins(config_dir: Path) -> list[Rule]:
    reset_registry()
    if not config_dir.exists() or not config_dir.is_dir():
        return []
    for py in sorted(config_dir.glob("*.py")):
        module_name = f"_xmlegant_plugin_{py.stem}"
        spec = importlib.util.spec_from_file_location(module_name, py)
        if spec is None or spec.loader is None:
            raise PluginImportError(f"could not load plugin {py}")
        module = importlib.util.module_from_spec(spec)
        try:
            spec.loader.exec_module(module)
        except Exception as exc:
            raise PluginImportError(f"failed to load plugin {py}: {exc}") from exc
    return registered_rules()
