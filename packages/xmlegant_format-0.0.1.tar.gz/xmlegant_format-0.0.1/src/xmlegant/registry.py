from __future__ import annotations

from pathlib import Path
from typing import TypeVar

from xmlegant.layout import ElementRule


class Rule:
    """Base class for file-matching rules.

    Subclass and decorate with `@rule` to register. Override `matches` to
    decide which files this rule applies to, and `element_rules` to declare
    per-tag formatting.
    """

    def matches(self, path: Path) -> bool:
        """Return True if this rule applies to `path`. Receives an absolute `pathlib.Path`."""
        raise NotImplementedError

    def element_rules(self) -> list[ElementRule]:
        """Return a flat list of `ElementRule`. Each tag name must appear in at most one rule."""
        return []


_REGISTRY: list[Rule] = []

T = TypeVar("T", bound=type[Rule])


def rule(cls: T) -> T:
    """Class decorator that registers a `Rule` subclass.

    Validates that the decorated class is a `Rule` subclass, instantiates it
    once, and stores the instance in the module-level registry. Returns the
    class unchanged so it can still be imported and unit-tested directly.
    """
    if not isinstance(cls, type) or not issubclass(cls, Rule):
        raise TypeError(f"@rule expected a Rule subclass, got {cls!r}")
    _REGISTRY.append(cls())
    return cls


def registered_rules() -> list[Rule]:
    return list(_REGISTRY)


def reset_registry() -> None:
    _REGISTRY.clear()
