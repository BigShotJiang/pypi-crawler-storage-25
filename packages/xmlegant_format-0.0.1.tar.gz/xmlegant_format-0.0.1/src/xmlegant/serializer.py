from __future__ import annotations

from lxml import etree

from xmlegant.layout import AlignedGroup, ElementRule, Inline, PerLine
from xmlegant.parser import ParsedDocument

INDENT = "  "

NsMap = dict[str | None, str]


def _local_name(tag: str) -> str:
    if tag.startswith("{"):
        return tag.rsplit("}", 1)[1]
    return tag


def _qname(tag: str, nsmap: NsMap) -> str:
    if not tag.startswith("{"):
        return tag
    uri, local = tag[1:].split("}", 1)
    for prefix, ns in nsmap.items():
        if ns == uri:
            return local if prefix is None else f"{prefix}:{local}"
    return local


def _attr_qname(tag: str, nsmap: NsMap) -> str:
    if not tag.startswith("{"):
        return tag
    uri, local = tag[1:].split("}", 1)
    for prefix, ns in nsmap.items():
        if ns == uri and prefix is not None:
            return f"{prefix}:{local}"
    return local


def _new_namespaces(nsmap: NsMap, parent_nsmap: NsMap) -> NsMap:
    return {p: u for p, u in nsmap.items() if parent_nsmap.get(p) != u}


def _ordered_attrs(
    el: etree._Element,
    order: tuple[str, ...] | None,
    nsmap: NsMap,
) -> list[tuple[str, str]]:
    items = [(_attr_qname(k, nsmap), v) for k, v in el.attrib.items()]
    if order is None:
        return items
    by_name = dict(items)
    listed: list[tuple[str, str]] = []
    for name in order:
        if name in by_name:
            listed.append((name, by_name.pop(name)))
    rest = [(k, v) for k, v in items if k in by_name]
    return listed + rest


def _attr_pairs(
    el: etree._Element,
    rule: ElementRule,
    nsmap: NsMap,
    parent_nsmap: NsMap,
) -> list[tuple[str, str]]:
    pairs: list[tuple[str, str]] = []
    for prefix, uri in _new_namespaces(nsmap, parent_nsmap).items():
        name = "xmlns" if prefix is None else f"xmlns:{prefix}"
        pairs.append((name, uri))
    pairs.extend(_ordered_attrs(el, rule.attribute_order, nsmap))
    return pairs


def _escape_attr(value: str) -> str:
    return value.replace("&", "&amp;").replace("<", "&lt;").replace('"', "&quot;")


def _escape_text(value: str) -> str:
    return value.replace("&", "&amp;").replace("<", "&lt;")


def _format_attr(name: str, value: str) -> str:
    return f'{name}="{_escape_attr(value)}"'


def _emit_pi(node: etree._Element, indent: str, out: list[str]) -> None:
    target = node.target  # type: ignore[attr-defined]
    text = node.text
    if text:
        out.append(f"{indent}<?{target} {text}?>\n")
    else:
        out.append(f"{indent}<?{target}?>\n")


def _emit_comment(node: etree._Element, indent: str, out: list[str]) -> None:
    out.append(f"{indent}<!--{node.text or ''}-->\n")


def _preceding_root_siblings(root: etree._Element) -> list[etree._Element]:
    siblings: list[etree._Element] = []
    s = root.getprevious()
    while s is not None:
        siblings.insert(0, s)
        s = s.getprevious()
    return siblings


def _following_root_siblings(root: etree._Element) -> list[etree._Element]:
    siblings: list[etree._Element] = []
    s = root.getnext()
    while s is not None:
        siblings.append(s)
        s = s.getnext()
    return siblings


def serialize(doc: ParsedDocument, rules_by_tag: dict[str, ElementRule]) -> str:
    parts: list[str] = []
    if doc.decl is not None:
        parts.append(doc.decl + "\n")
    if doc.doctype is not None:
        parts.append(doc.doctype + "\n")

    root = doc.tree.getroot()

    for sibling in _preceding_root_siblings(root):
        _emit_top_level(sibling, parts)

    _emit_element(root, rules_by_tag, depth=0, out=parts, parent_nsmap={})

    for sibling in _following_root_siblings(root):
        _emit_top_level(sibling, parts)

    if not parts or not parts[-1].endswith("\n"):
        parts.append("\n")
    return "".join(parts)


def _emit_top_level(node: etree._Element, out: list[str]) -> None:
    if isinstance(node, etree._Comment):
        _emit_comment(node, "", out)
    elif isinstance(node, etree._ProcessingInstruction):
        _emit_pi(node, "", out)


def _emit_element(
    el: etree._Element,
    rules_by_tag: dict[str, ElementRule],
    depth: int,
    out: list[str],
    parent_nsmap: NsMap,
    aligned_widths: tuple[list[str], dict[str, int]] | None = None,
) -> None:
    indent = INDENT * depth

    if isinstance(el, etree._Comment):
        _emit_comment(el, indent, out)
        return
    if isinstance(el, etree._ProcessingInstruction):
        _emit_pi(el, indent, out)
        return

    nsmap: NsMap = dict(el.nsmap)
    qname = _qname(el.tag, nsmap)
    local = _local_name(el.tag)
    rule = rules_by_tag.get(local, ElementRule((local,)))
    pairs = _attr_pairs(el, rule, nsmap, parent_nsmap)

    children = list(el)
    text = el.text
    has_real_text = text is not None and text.strip() != ""
    self_closing = not children and not has_real_text
    text_only = not children and has_real_text

    if self_closing:
        _emit_open(
            out, rule.layout, qname, pairs, indent, close="/>", aligned_widths=aligned_widths
        )
        return

    if text_only:
        assert text is not None
        close = f">{_escape_text(text.strip())}</{qname}>"
        _emit_open(
            out, rule.layout, qname, pairs, indent, close=close, aligned_widths=aligned_widths
        )
        return

    _emit_open(out, rule.layout, qname, pairs, indent, close=">", aligned_widths=aligned_widths)

    if has_real_text:
        assert text is not None
        out.append(f"{INDENT * (depth + 1)}{_escape_text(text.strip())}\n")

    _emit_children(children, rules_by_tag, depth + 1, out, parent_nsmap=nsmap)

    out.append(f"{indent}</{qname}>\n")


def _emit_children(
    children: list[etree._Element],
    rules_by_tag: dict[str, ElementRule],
    depth: int,
    out: list[str],
    parent_nsmap: NsMap,
) -> None:
    indent = INDENT * depth
    i = 0
    n = len(children)
    while i < n:
        child = children[i]
        if _is_aligned_group_member(child, rules_by_tag):
            group_end = _aligned_group_end(children, i, rules_by_tag)
            members = children[i:group_end]
            widths = _compute_group_widths(members, rules_by_tag, parent_nsmap)
            for m in members:
                _emit_element(m, rules_by_tag, depth, out, parent_nsmap, aligned_widths=widths)
                _emit_tail(m, indent, out)
            i = group_end
            continue
        _emit_element(child, rules_by_tag, depth, out, parent_nsmap)
        _emit_tail(child, indent, out)
        i += 1


def _emit_tail(node: etree._Element, indent: str, out: list[str]) -> None:
    tail = node.tail
    if tail is not None and tail.strip() != "":
        out.append(f"{indent}{_escape_text(tail.strip())}\n")


def _is_aligned_group_member(el: etree._Element, rules_by_tag: dict[str, ElementRule]) -> bool:
    if isinstance(el, (etree._Comment, etree._ProcessingInstruction)):
        return False
    local = _local_name(el.tag)
    rule = rules_by_tag.get(local)
    return rule is not None and isinstance(rule.layout, AlignedGroup)


def _aligned_group_end(
    children: list[etree._Element],
    start: int,
    rules_by_tag: dict[str, ElementRule],
) -> int:
    if not _is_aligned_group_member(children[start], rules_by_tag):
        return start + 1
    start_rule = rules_by_tag.get(_local_name(children[start].tag))
    j = start + 1
    while j < len(children):
        c = children[j]
        if isinstance(c, (etree._Comment, etree._ProcessingInstruction)):
            break
        if rules_by_tag.get(_local_name(c.tag)) is not start_rule:
            break
        j += 1
    return j


def _compute_group_widths(
    members: list[etree._Element],
    rules_by_tag: dict[str, ElementRule],
    parent_nsmap: NsMap,
) -> tuple[list[str], dict[str, int]]:
    local = _local_name(members[0].tag)
    rule = rules_by_tag.get(local, ElementRule((local,)))
    first_appearance: list[str] = []
    seen: set[str] = set()
    widths: dict[str, int] = {}
    for m in members:
        m_nsmap: NsMap = dict(m.nsmap)
        pairs = _attr_pairs(m, rule, m_nsmap, parent_nsmap)
        for name, value in pairs:
            w = len(_format_attr(name, value))
            if name not in seen:
                seen.add(name)
                first_appearance.append(name)
                widths[name] = w
            elif w > widths[name]:
                widths[name] = w
    if rule.attribute_order:
        order_set = set(rule.attribute_order)
        xmlns_attrs = [n for n in first_appearance if n == "xmlns" or n.startswith("xmlns:")]
        listed = [n for n in rule.attribute_order if n in seen]
        unlisted = [
            n
            for n in first_appearance
            if not (n == "xmlns" or n.startswith("xmlns:")) and n not in order_set
        ]
        attr_order = xmlns_attrs + listed + unlisted
    else:
        attr_order = first_appearance
    return attr_order, widths


def _emit_open(
    out: list[str],
    layout: Inline | PerLine | AlignedGroup,
    qname: str,
    pairs: list[tuple[str, str]],
    indent: str,
    close: str,
    aligned_widths: tuple[list[str], dict[str, int]] | None = None,
) -> None:
    if pairs and isinstance(layout, PerLine):
        _emit_open_perline(out, qname, pairs, indent, close)
        return
    if pairs and isinstance(layout, AlignedGroup):
        _emit_open_aligned(out, qname, pairs, indent, close, aligned_widths or ([], {}))
        return
    _emit_open_inline(out, qname, pairs, indent, close)


def _emit_open_inline(
    out: list[str],
    qname: str,
    pairs: list[tuple[str, str]],
    indent: str,
    close: str,
) -> None:
    attrs_str = "".join(f" {_format_attr(n, v)}" for n, v in pairs)
    out.append(f"{indent}<{qname}{attrs_str}{close}\n")


def _emit_open_perline(
    out: list[str],
    qname: str,
    pairs: list[tuple[str, str]],
    indent: str,
    close: str,
) -> None:
    attr_indent = indent + INDENT
    max_name = max(len(n) for n, _ in pairs)
    out.append(f"{indent}<{qname}\n")
    last = len(pairs) - 1
    for i, (name, value) in enumerate(pairs):
        pad = " " * (max_name - len(name))
        attr_str = f'{name}{pad}="{_escape_attr(value)}"'
        suffix = close if i == last else ""
        out.append(f"{attr_indent}{attr_str}{suffix}\n")


def _emit_open_aligned(
    out: list[str],
    qname: str,
    pairs: list[tuple[str, str]],
    indent: str,
    close: str,
    widths: tuple[list[str], dict[str, int]],
) -> None:
    attr_order, width_map = widths
    present = dict(pairs)

    last_present_idx = -1
    for i, name in enumerate(attr_order):
        if name in present:
            last_present_idx = i

    parts: list[str] = []
    for i, name in enumerate(attr_order):
        if name in present:
            s = _format_attr(name, present[name])
            if i < last_present_idx:
                s = s.ljust(width_map[name])
            parts.append(s)
        elif i < last_present_idx:
            parts.append(" " * width_map[name])

    out.append(f"{indent}<{qname} {' '.join(parts)}{close}\n")
