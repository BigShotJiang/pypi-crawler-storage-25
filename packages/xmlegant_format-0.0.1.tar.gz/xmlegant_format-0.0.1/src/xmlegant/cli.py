from __future__ import annotations

import argparse
import difflib
import sys
from pathlib import Path

from lxml import etree

from xmlegant.discovery import PluginImportError, load_plugins
from xmlegant.layout import ElementRule
from xmlegant.parser import UnsupportedEncodingError, parse_path
from xmlegant.registry import Rule
from xmlegant.serializer import serialize

DEFAULT_CONFIG_DIR = Path(".xmlegant")


class _NoOpRule(Rule):
    def matches(self, path: Path) -> bool:
        return True

    def element_rules(self) -> list[ElementRule]:
        return []


def _build_rules_by_tag(matched: Rule) -> dict[str, ElementRule]:
    rules: dict[str, ElementRule] = {}
    for er in matched.element_rules():
        for tag in er.tags:
            if tag in rules:
                raise SystemExit(
                    f"xmlegant: duplicate element rule for tag {tag!r} in {type(matched).__name__}"
                )
            rules[tag] = er
    return rules


def _select_rule(plugins: list[Rule], path: Path) -> Rule:
    matched = [r for r in plugins if r.matches(path)]
    if len(matched) == 1:
        return matched[0]
    if len(matched) == 0:
        return _NoOpRule()
    names = ", ".join(type(r).__name__ for r in matched)
    raise SystemExit(f"xmlegant: ambiguous rule match for {path}: {names}")


def _format_one(path: Path, plugins: list[Rule]) -> str:
    matched = _select_rule(plugins, path)
    rules_by_tag = _build_rules_by_tag(matched)
    try:
        doc = parse_path(path)
    except etree.XMLSyntaxError as exc:
        raise SystemExit(f"xmlegant: failed to parse {path}: {exc}") from exc
    return serialize(doc, rules_by_tag)


def _cmd_format(args: argparse.Namespace) -> int:
    config_dir = Path(args.config) if args.config else DEFAULT_CONFIG_DIR
    plugins = load_plugins(config_dir)
    if args.output:
        if len(args.files) != 1:
            print(
                "xmlegant: -o/--output requires exactly one input file",
                file=sys.stderr,
            )
            return 2
        formatted = _format_one(Path(args.files[0]), plugins)
        Path(args.output).write_text(formatted, encoding="utf-8")
        return 0
    for f in args.files:
        path = Path(f)
        formatted = _format_one(path, plugins)
        path.write_text(formatted, encoding="utf-8")
    return 0


def _cmd_check(args: argparse.Namespace) -> int:
    config_dir = Path(args.config) if args.config else DEFAULT_CONFIG_DIR
    plugins = load_plugins(config_dir)
    dirty = False
    for f in args.files:
        path = Path(f)
        original = path.read_text(encoding="utf-8")
        formatted = _format_one(path, plugins)
        if original != formatted:
            dirty = True
            diff = difflib.unified_diff(
                original.splitlines(keepends=True),
                formatted.splitlines(keepends=True),
                fromfile=str(path),
                tofile=str(path),
            )
            sys.stdout.writelines(diff)
    return 1 if dirty else 0


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="xmlegant",
        description="Plugin-based XML formatter.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    fmt = sub.add_parser("format", help="Format XML files in place.")
    fmt.add_argument("-c", "--config", help="Plugin config directory.")
    fmt.add_argument("-o", "--output", help="Write to OUTPUT_FILE instead of in place.")
    fmt.add_argument("files", nargs="+", help="XML files to format.")
    fmt.set_defaults(func=_cmd_format)

    chk = sub.add_parser("check", help="Check whether XML files are formatted.")
    chk.add_argument("-c", "--config", help="Plugin config directory.")
    chk.add_argument("files", nargs="+", help="XML files to check.")
    chk.set_defaults(func=_cmd_check)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except UnsupportedEncodingError as exc:
        print(f"xmlegant: {exc}", file=sys.stderr)
        return 2
    except PluginImportError as exc:
        print(f"xmlegant: {exc}", file=sys.stderr)
        return 2
    except OSError as exc:
        print(f"xmlegant: {exc}", file=sys.stderr)
        return 2
    except SystemExit as exc:
        if isinstance(exc.code, int):
            return exc.code
        print(str(exc.code), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
