# AGENTS.md

Instructions for coding agents working in this repo.

## Design decisions

Decisions that already shaped the codebase. Don't re-litigate without a reason.

- **Indent:** always 2 spaces, not configurable. The tool takes a position.
- **Encoding:** UTF-8 only. Non-UTF-8 declarations are rejected at parse time with
  `UnsupportedEncodingError` (exit 2). No-decl files default to UTF-8 per spec.
- **File matching:** exactly one `Rule` may match a given file. Zero matches →
  canonicalization (default layout). More than one match → exit 2.
- **Architecture:**
  - `parser.py` — lxml wrapper + prologue lexer; returns `ParsedDocument(decl, doctype, tree, encoding)`.
  - `serializer.py` — recursive tree walk; dispatches on `ElementRule.layout` in `_emit_open`.
  - `layout.py` — frozen dataclasses `Inline`, `PerLine`, `AlignedGroup`.
  - `registry.py` + `discovery.py` — `@rule` decorator and non-recursive `*.py` import from config dir.
  - `cli.py` — `format`/`check` subcommands; all exit-2 paths caught in `main()`.
- **Extending layouts:** add a frozen dataclass to `layout.py`, add a branch to `_emit_open` in
  `serializer.py`. Use fixture-first: commit a malformed `.xml` under `tests/fixtures/inputs/`
  and let the failing tests drive the implementation.
- **Known limitations (v1):** mixed-content whitespace is stripped (idempotent but lossy for
  `<p>foo <b>x</b> bar</p>`-style content); CDATA sections are not preserved structurally
  (content survives with entity escaping, but `<![CDATA[...]]>` wrapping is lost).
- **Package layout:** `src/xmlegant/` (PEP 621 / UV default; prevents cwd-import shadowing in tests).

## Dev environment

```sh
uv sync
```

That's the whole setup. UV manages the virtualenv, dependencies, and lockfile.

## Run the CLI

```sh
uv run xmlegant --help
```

## Tests

```sh
uv run pytest
```

Tests live in `tests/`. New test files are `test_*.py`.

### Smoke test pattern (A → B → C)

For each layout/scenario, commit a deliberately-malformed fixture **A** under
`tests/fixtures/inputs/`. The test formats A in memory to produce **B**, then
formats B to produce **C**, and asserts:

- `A != B` (the formatter actually does something)
- `B == C` (idempotence — formatted output is a fixed point)

B and C are in-memory only; never write them to disk and never commit them.

## Format and lint

```sh
uv run ruff format .          # format
uv run ruff format --check .  # CI gate: fail if anything would change
uv run ruff check .           # lint
```

CI runs `ruff format --check` before tests, so unformatted code fails fast.

## Coding rules of thumb

- Python floor is **3.10**. Prefer features available in 3.10 over later
  additions. Avoid PEP 695 type-parameter syntax, `typing.override`, and
  `match`/`case` unless genuinely the clearest option.
- Standard library first. The only third-party runtime dep is **lxml**; the
  only third-party dev deps are **pytest** and **ruff**. Adding others needs
  explicit justification.
- Type hints required on all public function signatures and dataclass fields.
- Public API surface (re-exported from `xmlegant/__init__.py`):
  `rule`, `Rule`, `ElementRule`, `Inline`, `PerLine`, `AlignedGroup`.
  Everything else is internal.
