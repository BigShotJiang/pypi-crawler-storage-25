from __future__ import annotations

from pathlib import Path

import pytest

from xmlegant.parser import parse_bytes
from xmlegant.serializer import serialize

FIXTURES = Path(__file__).parent / "fixtures" / "inputs"
ALL_FIXTURES = sorted(FIXTURES.glob("*.xml"))


def _format(content: bytes) -> bytes:
    doc = parse_bytes(content)
    return serialize(doc, {}).encode("utf-8")


@pytest.mark.parametrize("fixture", ALL_FIXTURES, ids=lambda p: p.name)
def test_format_is_idempotent(fixture: Path) -> None:
    a = fixture.read_bytes()
    b = _format(a)
    c = _format(b)
    assert b == c, f"format(format(x)) != format(x) on {fixture.name}"
