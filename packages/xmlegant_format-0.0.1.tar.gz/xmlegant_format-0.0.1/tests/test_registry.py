from __future__ import annotations

from pathlib import Path
from typing import Iterator

import pytest

from xmlegant.layout import ElementRule
from xmlegant.registry import Rule, registered_rules, reset_registry, rule


@pytest.fixture(autouse=True)
def _clean_registry() -> Iterator[None]:
    reset_registry()
    yield
    reset_registry()


def test_decorator_rejects_non_rule() -> None:
    with pytest.raises(TypeError):

        @rule  # type: ignore[arg-type]
        class NotARule:
            pass


def test_decorator_registers_subclass_once() -> None:
    @rule
    class MyRule(Rule):
        def matches(self, path: Path) -> bool:
            return False

        def element_rules(self) -> list[ElementRule]:
            return []

    instances = registered_rules()
    assert len(instances) == 1
    assert isinstance(instances[0], MyRule)


def test_reset_registry_clears() -> None:
    @rule
    class A(Rule):
        def matches(self, path: Path) -> bool:
            return False

    assert len(registered_rules()) == 1
    reset_registry()
    assert registered_rules() == []


def test_decorator_returns_class_unchanged() -> None:
    class Original(Rule):
        def matches(self, path: Path) -> bool:
            return False

    decorated = rule(Original)
    assert decorated is Original
