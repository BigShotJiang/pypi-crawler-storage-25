from __future__ import annotations

from pathlib import Path

from xmlegant import AlignedGroup, ElementRule, Rule, rule


@rule
class AlignedGroupOptionalElement(Rule):
    def matches(self, path: Path) -> bool:
        return path.name == "aligned_group_optional.xml"

    def element_rules(self) -> list[ElementRule]:
        return [
            ElementRule(
                tags=("element",),
                layout=AlignedGroup(),
                attribute_order=("foo", "bar", "baz"),
            )
        ]
