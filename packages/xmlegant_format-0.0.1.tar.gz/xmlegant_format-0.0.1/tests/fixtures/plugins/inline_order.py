from __future__ import annotations

from pathlib import Path

from xmlegant import ElementRule, Rule, rule


@rule
class PersonRule(Rule):
    def matches(self, path: Path) -> bool:
        return path.name == "rule_inline_attribute_order.xml"

    def element_rules(self) -> list[ElementRule]:
        return [ElementRule(tags=("person",), attribute_order=("id", "name"))]
