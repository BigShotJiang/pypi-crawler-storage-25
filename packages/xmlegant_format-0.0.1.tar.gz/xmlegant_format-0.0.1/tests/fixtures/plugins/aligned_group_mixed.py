from __future__ import annotations

from pathlib import Path

from xmlegant import AlignedGroup, ElementRule, Rule, rule


@rule
class AlignedGroupMixed(Rule):
    def matches(self, path: Path) -> bool:
        return path.name == "aligned_group_mixed.xml"

    def element_rules(self) -> list[ElementRule]:
        return [
            ElementRule(
                tags=("foo", "bar"),
                layout=AlignedGroup(),
                attribute_order=("x", "y"),
            )
        ]
