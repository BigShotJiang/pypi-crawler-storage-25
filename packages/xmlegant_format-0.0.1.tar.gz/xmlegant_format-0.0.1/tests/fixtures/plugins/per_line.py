from __future__ import annotations

from pathlib import Path

from xmlegant import ElementRule, PerLine, Rule, rule


@rule
class PerLineSignal(Rule):
    def matches(self, path: Path) -> bool:
        return path.name == "per_line_basic.xml"

    def element_rules(self) -> list[ElementRule]:
        return [ElementRule(tags=("signal",), layout=PerLine())]
