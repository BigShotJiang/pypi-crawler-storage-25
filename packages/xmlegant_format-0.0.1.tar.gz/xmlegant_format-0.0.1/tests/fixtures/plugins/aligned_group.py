from __future__ import annotations

from pathlib import Path

from xmlegant import AlignedGroup, ElementRule, Rule, rule


@rule
class AlignedGroupElement(Rule):
    def matches(self, path: Path) -> bool:
        return path.name == "aligned_group_basic.xml"

    def element_rules(self) -> list[ElementRule]:
        return [ElementRule(tags=("element",), layout=AlignedGroup())]
