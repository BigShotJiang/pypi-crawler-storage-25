from __future__ import annotations

from pathlib import Path

import pytest

from xmlegant.parser import parse_bytes
from xmlegant.serializer import serialize

FIXTURES = Path(__file__).parent / "fixtures" / "inputs"
CANONICALIZE_FIXTURES = sorted(FIXTURES.glob("canonicalize_*.xml"))


def _format(content: bytes) -> bytes:
    doc = parse_bytes(content)
    return serialize(doc, {}).encode("utf-8")


@pytest.mark.parametrize("fixture", CANONICALIZE_FIXTURES, ids=lambda p: p.name)
def test_canonicalize_smoke(fixture: Path) -> None:
    a = fixture.read_bytes()
    b = _format(a)
    c = _format(b)
    assert a != b, f"formatter did nothing on {fixture.name}; fixture is not malformed"
    assert b == c, f"formatter is not idempotent on {fixture.name}"
