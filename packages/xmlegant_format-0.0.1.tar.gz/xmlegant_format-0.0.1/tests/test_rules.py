from __future__ import annotations

from pathlib import Path
from typing import Iterator

import pytest

from xmlegant.discovery import load_plugins
from xmlegant.parser import parse_bytes
from xmlegant.registry import reset_registry
from xmlegant.serializer import serialize

FIXTURES = Path(__file__).parent / "fixtures"
INPUTS = FIXTURES / "inputs"
PLUGINS = FIXTURES / "plugins"


@pytest.fixture(autouse=True)
def _clean_registry() -> Iterator[None]:
    reset_registry()
    yield
    reset_registry()


def _rules_for(path: Path) -> dict[str, "object"]:
    plugins = load_plugins(PLUGINS)
    matched = [r for r in plugins if r.matches(path)]
    assert len(matched) == 1, f"expected exactly one rule to match {path.name}, got {len(matched)}"
    rules: dict[str, object] = {}
    for er in matched[0].element_rules():
        for tag in er.tags:
            rules[tag] = er
    return rules


def test_inline_attribute_order_via_plugin() -> None:
    fixture = INPUTS / "rule_inline_attribute_order.xml"
    rules_by_tag = _rules_for(fixture)

    formatted = serialize(parse_bytes(fixture.read_bytes()), rules_by_tag)

    expected = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        "<root>\n"
        '  <person id="42" name="Alice" age="30"/>\n'
        '  <person id="7" name="Bob" age="25"/>\n'
        "</root>\n"
    )
    assert formatted == expected


def test_inline_attribute_order_is_idempotent() -> None:
    fixture = INPUTS / "rule_inline_attribute_order.xml"
    rules_by_tag = _rules_for(fixture)

    once = serialize(parse_bytes(fixture.read_bytes()), rules_by_tag)
    twice = serialize(parse_bytes(once.encode("utf-8")), rules_by_tag)
    assert once == twice


def test_per_line_layout_via_plugin() -> None:
    fixture = INPUTS / "per_line_basic.xml"
    rules_by_tag = _rules_for(fixture)

    formatted = serialize(parse_bytes(fixture.read_bytes()), rules_by_tag)

    expected = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        "<root>\n"
        "  <signal\n"
        '    attr_long="value1"\n'
        '    attr2    ="s_value"\n'
        '    attr3    ="value"/>\n'
        "  <signal\n"
        '    attr_long="other"\n'
        '    attr2    ="x"\n'
        '    attr3    ="y">\n'
        '    <child a="1" b="2"/>\n'
        "  </signal>\n"
        "  <signal/>\n"
        "</root>\n"
    )
    assert formatted == expected


def test_per_line_layout_is_idempotent() -> None:
    fixture = INPUTS / "per_line_basic.xml"
    rules_by_tag = _rules_for(fixture)

    once = serialize(parse_bytes(fixture.read_bytes()), rules_by_tag)
    twice = serialize(parse_bytes(once.encode("utf-8")), rules_by_tag)
    assert once == twice


def test_aligned_group_layout_via_plugin() -> None:
    fixture = INPUTS / "aligned_group_basic.xml"
    rules_by_tag = _rules_for(fixture)

    formatted = serialize(parse_bytes(fixture.read_bytes()), rules_by_tag)

    expected = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        "<root>\n"
        '  <element attr1="value1" attr2="s_value"    attr3="value"/>\n'
        '  <element attr1="value1" attr2="long_value" attr3="value"/>\n'
        "  <!-- breaks the run -->\n"
        '  <element attr1="x" attr2="y" attr3="z"/>\n'
        '  <other a="1"/>\n'
        '  <element attr1="alone" attr2="here" attr3="now"/>\n'
        "</root>\n"
    )
    assert formatted == expected


def test_aligned_group_layout_is_idempotent() -> None:
    fixture = INPUTS / "aligned_group_basic.xml"
    rules_by_tag = _rules_for(fixture)

    once = serialize(parse_bytes(fixture.read_bytes()), rules_by_tag)
    twice = serialize(parse_bytes(once.encode("utf-8")), rules_by_tag)
    assert once == twice


def test_aligned_group_optional_attribute_alignment() -> None:
    fixture = INPUTS / "aligned_group_optional.xml"
    rules_by_tag = _rules_for(fixture)

    formatted = serialize(parse_bytes(fixture.read_bytes()), rules_by_tag)

    expected = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        "<root>\n"
        '  <element foo="abc"    bar="x"       baz="value"/>\n'
        '  <element foo="defghi"               baz="value"/>\n'
        '  <element foo="j"      bar="longbar" baz="value"/>\n'
        "</root>\n"
    )
    assert formatted == expected


def test_aligned_group_optional_attribute_alignment_is_idempotent() -> None:
    fixture = INPUTS / "aligned_group_optional.xml"
    rules_by_tag = _rules_for(fixture)

    once = serialize(parse_bytes(fixture.read_bytes()), rules_by_tag)
    twice = serialize(parse_bytes(once.encode("utf-8")), rules_by_tag)
    assert once == twice


def test_aligned_group_mixed_tags_share_run() -> None:
    fixture = INPUTS / "aligned_group_mixed.xml"
    rules_by_tag = _rules_for(fixture)

    formatted = serialize(parse_bytes(fixture.read_bytes()), rules_by_tag)

    expected = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        "<root>\n"
        '  <foo x="a"   y="hello"/>\n'
        '  <bar x="bbb" y="y"/>\n'
        '  <foo x="c"   y="world"/>\n'
        "  <!-- breaks the run -->\n"
        '  <foo x="alone" y="here"/>\n'
        "</root>\n"
    )
    assert formatted == expected


def test_aligned_group_mixed_tags_is_idempotent() -> None:
    fixture = INPUTS / "aligned_group_mixed.xml"
    rules_by_tag = _rules_for(fixture)

    once = serialize(parse_bytes(fixture.read_bytes()), rules_by_tag)
    twice = serialize(parse_bytes(once.encode("utf-8")), rules_by_tag)
    assert once == twice
