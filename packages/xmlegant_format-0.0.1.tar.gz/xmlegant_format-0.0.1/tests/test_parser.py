from __future__ import annotations

import pytest

from xmlegant.parser import UnsupportedEncodingError, parse_bytes


def test_extracts_xml_declaration_verbatim() -> None:
    data = b'<?xml version="1.0" encoding="UTF-8"?>\n<root/>'
    doc = parse_bytes(data)
    assert doc.decl == '<?xml version="1.0" encoding="UTF-8"?>'
    assert doc.doctype is None
    assert doc.encoding == "UTF-8"


def test_preserves_decl_quoting_style() -> None:
    data = b"<?xml version='1.0'?>\n<root/>"
    doc = parse_bytes(data)
    assert doc.decl == "<?xml version='1.0'?>"


def test_extracts_doctype_verbatim() -> None:
    data = b'<?xml version="1.0"?>\n<!DOCTYPE root SYSTEM "root.dtd">\n<root/>'
    doc = parse_bytes(data)
    assert doc.doctype == '<!DOCTYPE root SYSTEM "root.dtd">'


def test_extracts_doctype_with_internal_subset() -> None:
    data = b'<?xml version="1.0"?>\n<!DOCTYPE root [\n<!ELEMENT root (#PCDATA)>\n]>\n<root/>'
    doc = parse_bytes(data)
    assert doc.doctype is not None
    assert "<!ELEMENT root (#PCDATA)>" in doc.doctype
    assert doc.doctype.endswith("]>")


def test_no_decl_no_doctype() -> None:
    data = b"<root/>"
    doc = parse_bytes(data)
    assert doc.decl is None
    assert doc.doctype is None
    assert doc.encoding == "UTF-8"


def test_handles_bom() -> None:
    data = b'\xef\xbb\xbf<?xml version="1.0"?>\n<root/>'
    doc = parse_bytes(data)
    assert doc.decl == '<?xml version="1.0"?>'


def test_accepts_utf8_aliases() -> None:
    for enc in (b"UTF-8", b"utf-8", b"utf8", b"UTF8"):
        data = b'<?xml version="1.0" encoding="' + enc + b'"?>\n<root/>'
        parse_bytes(data)


def test_rejects_non_utf8_encoding() -> None:
    data = b'<?xml version="1.0" encoding="ISO-8859-1"?>\n<root/>'
    with pytest.raises(UnsupportedEncodingError):
        parse_bytes(data)
