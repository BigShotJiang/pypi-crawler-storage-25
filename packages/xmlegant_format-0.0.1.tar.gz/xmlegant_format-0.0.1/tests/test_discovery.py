from __future__ import annotations

from pathlib import Path
from typing import Iterator

import pytest

from xmlegant.discovery import PluginImportError, load_plugins
from xmlegant.registry import reset_registry


@pytest.fixture(autouse=True)
def _clean_registry() -> Iterator[None]:
    reset_registry()
    yield
    reset_registry()


def test_missing_dir_yields_no_rules(tmp_path: Path) -> None:
    rules = load_plugins(tmp_path / "does-not-exist")
    assert rules == []


def test_empty_dir_yields_no_rules(tmp_path: Path) -> None:
    rules = load_plugins(tmp_path)
    assert rules == []


def test_loads_rule_subclass_from_file(tmp_path: Path) -> None:
    plugin = tmp_path / "p.py"
    plugin.write_text(
        "from xmlegant import Rule, rule\n"
        "@rule\n"
        "class P(Rule):\n"
        "    def matches(self, path):\n"
        "        return path.name == 'x.xml'\n"
    )
    rules = load_plugins(tmp_path)
    assert len(rules) == 1
    assert rules[0].matches(Path("x.xml")) is True
    assert rules[0].matches(Path("y.xml")) is False


def test_import_error_raises(tmp_path: Path) -> None:
    plugin = tmp_path / "broken.py"
    plugin.write_text("raise RuntimeError('boom')\n")
    with pytest.raises(PluginImportError) as info:
        load_plugins(tmp_path)
    assert "broken.py" in str(info.value)
    assert isinstance(info.value.__cause__, RuntimeError)


def test_non_recursive_discovery(tmp_path: Path) -> None:
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "nested.py").write_text(
        "from xmlegant import Rule, rule\n"
        "@rule\n"
        "class Nested(Rule):\n"
        "    def matches(self, path):\n"
        "        return True\n"
    )
    rules = load_plugins(tmp_path)
    assert rules == []
