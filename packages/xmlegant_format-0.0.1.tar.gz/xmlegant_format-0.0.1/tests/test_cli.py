from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]


def _run(*args: str, cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-m", "xmlegant.cli", *args],
        cwd=cwd,
        capture_output=True,
        text=True,
        check=False,
    )


def _write(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8")


@pytest.fixture
def workdir(tmp_path: Path) -> Path:
    return tmp_path


def test_format_with_no_config_canonicalizes_in_place(workdir: Path) -> None:
    f = workdir / "a.xml"
    _write(f, '<?xml version="1.0" encoding="UTF-8"?>\n<root>   <c x="1"/></root>\n')
    res = _run("format", str(f), cwd=workdir)
    assert res.returncode == 0, res.stderr
    assert (
        f.read_text(encoding="utf-8")
        == '<?xml version="1.0" encoding="UTF-8"?>\n<root>\n  <c x="1"/>\n</root>\n'
    )


def test_format_with_matching_plugin(workdir: Path) -> None:
    config = workdir / ".xmlegant"
    config.mkdir()
    _write(
        config / "p.py",
        "from pathlib import Path\n"
        "from xmlegant import ElementRule, Rule, rule\n"
        "@rule\n"
        "class R(Rule):\n"
        "    def matches(self, path: Path) -> bool:\n"
        "        return path.suffix == '.xml'\n"
        "    def element_rules(self):\n"
        "        return [ElementRule(tags=('c',), attribute_order=('id',))]\n",
    )
    f = workdir / "a.xml"
    _write(f, '<?xml version="1.0" encoding="UTF-8"?>\n<root><c x="1" id="7"/></root>\n')
    res = _run("format", "-c", str(config), str(f), cwd=workdir)
    assert res.returncode == 0, res.stderr
    assert '<c id="7" x="1"/>' in f.read_text(encoding="utf-8")


def test_format_output_file_with_one_input(workdir: Path) -> None:
    f = workdir / "a.xml"
    out = workdir / "b.xml"
    original = '<?xml version="1.0" encoding="UTF-8"?>\n<root><c/></root>\n'
    _write(f, original)
    res = _run("format", "-o", str(out), str(f), cwd=workdir)
    assert res.returncode == 0, res.stderr
    assert out.exists()
    assert out.read_text(encoding="utf-8") != original
    assert f.read_text(encoding="utf-8") == original


def test_format_output_file_rejects_multiple_inputs(workdir: Path) -> None:
    a = workdir / "a.xml"
    b = workdir / "b.xml"
    out = workdir / "out.xml"
    _write(a, "<root/>\n")
    _write(b, "<root/>\n")
    res = _run("format", "-o", str(out), str(a), str(b), cwd=workdir)
    assert res.returncode == 2
    assert "exactly one" in res.stderr


def test_check_clean_returns_zero(workdir: Path) -> None:
    f = workdir / "a.xml"
    _write(
        f,
        '<?xml version="1.0" encoding="UTF-8"?>\n<root>\n  <c x="1"/>\n</root>\n',
    )
    res = _run("check", str(f), cwd=workdir)
    assert res.returncode == 0
    assert res.stdout == ""


def test_check_dirty_returns_one_with_diff(workdir: Path) -> None:
    f = workdir / "a.xml"
    _write(
        f,
        '<?xml version="1.0" encoding="UTF-8"?>\n<root>   <c x="1"/></root>\n',
    )
    res = _run("check", str(f), cwd=workdir)
    assert res.returncode == 1
    assert res.stdout.startswith("---")
    assert "+++" in res.stdout
    assert '<c x="1"/>' in res.stdout


def test_non_utf8_input_exits_two(workdir: Path) -> None:
    f = workdir / "a.xml"
    f.write_bytes(b'<?xml version="1.0" encoding="ISO-8859-1"?>\n<root/>\n')
    res = _run("format", str(f), cwd=workdir)
    assert res.returncode == 2
    assert "UTF-8" in res.stderr


def test_parse_failure_exits_two(workdir: Path) -> None:
    f = workdir / "bad.xml"
    _write(f, "<root><unclosed>\n")
    res = _run("format", str(f), cwd=workdir)
    assert res.returncode == 2
    assert res.stderr.startswith("xmlegant:")
    assert str(f) in res.stderr
    assert "Traceback" not in res.stderr


def test_missing_input_file_exits_two(workdir: Path) -> None:
    missing = workdir / "nope.xml"
    res = _run("format", str(missing), cwd=workdir)
    assert res.returncode == 2
    assert res.stderr.startswith("xmlegant:")
    assert "Traceback" not in res.stderr


def test_plugin_import_error_exits_two(workdir: Path) -> None:
    config = workdir / ".xmlegant"
    config.mkdir()
    _write(config / "broken.py", "raise RuntimeError('boom')\n")
    f = workdir / "a.xml"
    _write(f, '<?xml version="1.0" encoding="UTF-8"?>\n<root/>\n')
    res = _run("format", "-c", str(config), str(f), cwd=workdir)
    assert res.returncode == 2
    assert res.stderr.startswith("xmlegant:")
    assert "broken.py" in res.stderr
    assert "Traceback" not in res.stderr
