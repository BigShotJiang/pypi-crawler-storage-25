# xmlegant

**Plugin-based XML formatter with a strong house style.**

Think `black`, but for XML — with a small plugin surface so you can pin
domain-specific element layout in a few lines of Python.

```sh
pipx install xmlegant-format
xmlegant format my-file.xml
```

## Why

XML files in industrial domains (AUTOSAR, ASAM, build configuration, …) are
usually generated or hand-edited and end up formatted inconsistently. Existing
pretty-printers either flatten everything to one style or expose so many flags
that maintaining a consistent house style across files becomes a chore.

xmlegant takes the position that:

1. There is one true indent: 2 spaces. Not configurable.
2. Per-element formatting choices belong to the project's domain, not the
   formatter's flag list.
3. Domain knowledge lives in user-supplied Python plugins.

## Where to go next

- **[Quickstart](quickstart.md)** — install, format a file, write your first rule.
- **[Writing rules](writing-rules/index.md)** — the three layout modes,
  attribute ordering, and how to match files.
- **[API reference](reference/api.md)** — auto-generated from source.
- **[CLI reference](reference/cli.md)** — every flag and exit code.
