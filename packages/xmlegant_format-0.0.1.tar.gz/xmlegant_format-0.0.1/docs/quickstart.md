# Quickstart

## Install

xmlegant runs on Linux, macOS, and Windows with Python 3.10 or newer. The
PyPI distribution is `xmlegant-format`; the installed CLI command and import
name are both `xmlegant`.

=== "pipx"

    ```sh
    pipx install xmlegant-format
    ```

=== "uv"

    ```sh
    uv tool install xmlegant-format
    ```

=== "pip"

    ```sh
    pip install xmlegant-format
    ```

## Format a file

With no configuration, xmlegant runs in **canonicalization mode** — it parses
each file and re-emits it with the default layout (2-space indent, `Inline`
attributes, original attribute order).

=== "Before"

    ```xml
    <?xml version="1.0" encoding="UTF-8"?>
    <root>
       <child first="1" second="2"/>
         <child first="3"/>
    </root>
    ```

=== "After `xmlegant format`"

    ```xml
    <?xml version="1.0" encoding="UTF-8"?>
    <root>
      <child first="1" second="2"/>
      <child first="3"/>
    </root>
    ```

```sh
xmlegant format my-file.xml          # rewrite in place
xmlegant format -o out.xml in.xml    # write to a different file
xmlegant check my-file.xml           # print a unified diff if it would change
```

`check` exits 0 when the file is already formatted, 1 when it would change,
and 2 on any operational error. It's the right command to run in CI.

## Write your first rule

A **rule** is a Python class that decides which files it applies to and what
per-tag formatting to use. Rules live in a `.xmlegant/` directory next to your
XML files (override with `-c CONFIG_DIR`).

Create `.xmlegant/my_rules.py`:

```python
from pathlib import Path

from xmlegant import ElementRule, PerLine, Rule, rule


@rule
class MyRules(Rule):
    def matches(self, path: Path) -> bool:
        return path.suffix == ".xml"

    def element_rules(self) -> list[ElementRule]:
        return [
            ElementRule(tags=("signal",), layout=PerLine()),
        ]
```

Now any element whose local name is `signal` will be laid out per-line:

=== "Before"

    ```xml
    <signal attr_long="value1" attr2="s_value" attr3="value"/>
    ```

=== "After (`PerLine` rule for `signal`)"

    ```xml
    <signal
      attr_long="value1"
      attr2    ="s_value"
      attr3    ="value"/>
    ```

Notice the equals signs are aligned to the longest attribute name. That's
not a coincidence — it's the whole point of the [`PerLine`](writing-rules/per-line.md)
layout.

## Next steps

- Learn the [three layout modes](writing-rules/index.md) and when to pick each.
- See how to enforce a partial [attribute order](writing-rules/attribute-order.md).
- See [matching patterns](writing-rules/matching.md) beyond `path.suffix == ".xml"`.
