# AlignedGroup layout

`AlignedGroup` keeps attributes inline but pads each one to a column width
computed across consecutive same-tag siblings. The result reads like a small
table.

## Effect

=== "With `AlignedGroup`"

    ```xml
    <element attr1="value1" attr2="s_value"    attr3="value"/>
    <element attr1="value1" attr2="long_value" attr3="value"/>
    ```

=== "Without (default `Inline`)"

    ```xml
    <element attr1="value1" attr2="s_value" attr3="value"/>
    <element attr1="value1" attr2="long_value" attr3="value"/>
    ```

In the `Inline` version `attr3` lands in a different column on each line,
which makes scanning down the column much harder. `AlignedGroup` pads
`attr2="s_value"` with extra spaces so that `attr3` lines up on both rows.

The **last** attribute of each line is never padded — that way trailing
whitespace can never escape onto a line ending.

## What counts as a "group"

A sibling group is a maximal run of consecutive children that all share the
same `ElementRule` and use `AlignedGroup` layout.

Because a single `ElementRule` can cover multiple tag names (see
[below](#grouping-across-element-types)), elements of different types can
participate in the same run and have their columns aligned together.

Any of the following **breaks** the run, starting a new group with its own
column widths:

- A sibling whose tag is not covered by the same `ElementRule`.
- A comment or processing instruction.

=== "With `AlignedGroup` (groups broken by comment and other tag)"

    ```xml
    <root>
      <element attr1="value1" attr2="s_value"    attr3="value"/>
      <element attr1="value1" attr2="long_value" attr3="value"/>
      <!-- breaks the run -->
      <element attr1="x" attr2="y" attr3="z"/>
      <other a="1"/>
      <element attr1="alone" attr2="here" attr3="now"/>
    </root>
    ```

=== "Without (default `Inline`)"

    ```xml
    <root>
      <element attr1="value1" attr2="s_value" attr3="value"/>
      <element attr1="value1" attr2="long_value" attr3="value"/>
      <!-- breaks the run -->
      <element attr1="x" attr2="y" attr3="z"/>
      <other a="1"/>
      <element attr1="alone" attr2="here" attr3="now"/>
    </root>
    ```

The first two `<element>` siblings form one group and align with each other.
The comment ends that group; the next `<element>` starts a fresh group of
one — and a group of one is identical to `Inline`, since column widths equal
own width.

## Groups of one

A group of one renders identically to `Inline`. This is by design — the
column-width math degenerates to "max width = own width," padding becomes a
no-op, and the unpadded last attribute behaves the same way.

## Mismatched attribute counts

Members with different attribute counts still group; positions past the
shorter member's last attribute simply don't contribute to the width
calculation. Misalignment in that case is acceptable — if it bites you, your
data is probably trying to tell you something.

## Grouping across element types

Pass multiple tag names to `tags` to fold two or more element types into a
single `AlignedGroup` run. This is useful when sibling elements of different
types carry the same attributes and you want a uniform column layout across all
of them.

```python
ElementRule(tags=("foo", "bar"), layout=AlignedGroup(), attribute_order=("x", "y"))
```

Input:

```xml
<root>
  <foo x="a" y="hello"/>
  <bar x="bbb" y="y"/>
  <foo x="c" y="world"/>
</root>
```

Output — `foo` and `bar` share one run, so `x` and `y` align across all three:

```xml
<root>
  <foo x="a"   y="hello"/>
  <bar x="bbb" y="y"/>
  <foo x="c"   y="world"/>
</root>
```

## Applying the rule

```python
from pathlib import Path

from xmlegant import AlignedGroup, ElementRule, Rule, rule


@rule
class AlignedGroupElement(Rule):
    def matches(self, path: Path) -> bool:
        return path.suffix == ".xml"

    def element_rules(self) -> list[ElementRule]:
        return [
            ElementRule(tags=("element",), layout=AlignedGroup()),
        ]
```

## When to use it

- **Tabular sibling lists.** Long runs of `<row>`, `<signal>`, `<port>`,
  `<entry>`, etc. where reading "all the values for attribute X" matters.
- **Generated XML where consistency aids review.** When attribute values
  vary in width and you want column scanning to work.

## When *not* to use it

- **Single elements.** A group of one is just `Inline` — don't bother.
- **Wildly varying attribute counts.** If sibling elements have 2, 5, and 8
  attributes respectively, the alignment is mostly noise.
- **Long attribute values.** When values are too wide for a single line,
  switch to [`PerLine`](per-line.md).

## Reference

::: xmlegant.AlignedGroup
