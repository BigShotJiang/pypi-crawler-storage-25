# Attribute order

The `attribute_order` field on [`ElementRule`](../reference/api.md#xmlegant.ElementRule)
specifies a **partial** ordering for an element's attributes. Listed
attributes appear first in the given order; unlisted attributes follow in
their original document order.

## Effect

=== "With `attribute_order=(\"id\", \"name\")`"

    ```xml
    <person id="42" name="Alice" age="30"/>
    <person id="7" name="Bob" age="25"/>
    ```

=== "Without (preserves document order)"

    ```xml
    <person name="Alice" id="42" age="30"/>
    <person age="25" id="7" name="Bob"/>
    ```

`id` and `name` jump to the front in the given order. `age` stays where it
was relative to other unlisted attributes.

## Partial ordering, not total ordering

You only need to list the attributes whose position you actually care about.
Everything else keeps its document order, which means:

- **Stable.** New attributes that appear in input files don't break the
  rule; they slot in after the listed ones.
- **Idempotent.** Running the formatter twice produces the same output (a
  required property, verified by `tests/test_idempotence.py`).

## Names are matched as written

Attribute names are matched **as they appear in the source XML**, including
any prefix. To order a namespaced attribute like `xml:lang`, write
`("xml:lang", ...)`, not `("lang", ...)`.

## Combining with layouts

`attribute_order` works with all three layouts. The listed attributes appear
first in the given order; the layout decides how they are then formatted on
the page.

=== "With `PerLine` + `attribute_order=(\"id\", \"name\")`"

    ```xml
    <person
      id  ="42"
      name="Alice"
      age ="30"/>
    ```

=== "With `Inline` (default) + `attribute_order=(\"id\", \"name\")`"

    ```xml
    <person id="42" name="Alice" age="30"/>
    ```

## Applying the rule

```python
from pathlib import Path

from xmlegant import ElementRule, Rule, rule


@rule
class PersonRule(Rule):
    def matches(self, path: Path) -> bool:
        return path.suffix == ".xml"

    def element_rules(self) -> list[ElementRule]:
        return [
            ElementRule(tags=("person",), attribute_order=("id", "name")),
        ]
```

## Reference

::: xmlegant.ElementRule
