# Inline layout

`Inline` is the default. All attributes go on the element's opening line,
separated by single spaces. Most XML files want this for most elements; the
other layouts exist for the elements where this would be ugly.

## Effect

`Inline` is what you get when you don't pick a layout. The before/after here
shows what xmlegant does with an `Inline` element regardless: it
canonicalizes whitespace, normalizes the indent to 2 spaces, and emits a
self-closing tag when there's no content.

=== "Before (sloppy whitespace)"

    ```xml
    <root>
       <person   name="Alice" id="42"   age="30"/>
         <person age="25" id="7" name="Bob"/>
    </root>
    ```

=== "After (`Inline`, default)"

    ```xml
    <root>
      <person name="Alice" id="42" age="30"/>
      <person age="25" id="7" name="Bob"/>
    </root>
    ```

Notice the attribute order is **preserved as-is**. If you want to reorder
attributes, combine `Inline` with [`attribute_order`](attribute-order.md).

## Applying the rule

You almost never need to write `layout=Inline()` explicitly — it's the
default. The only time it's useful is when you want to be explicit about
intent, or when you want `Inline` plus a specific `attribute_order`:

```python
from pathlib import Path

from xmlegant import ElementRule, Inline, Rule, rule


@rule
class PersonRule(Rule):
    def matches(self, path: Path) -> bool:
        return path.suffix == ".xml"

    def element_rules(self) -> list[ElementRule]:
        return [
            ElementRule(
                tags=("person",),
                attribute_order=("id", "name"),
                layout=Inline(),  # equivalent to omitting `layout`
            ),
        ]
```

With the rule above, the same input becomes:

```xml
<root>
  <person id="42" name="Alice" age="30"/>
  <person id="7" name="Bob" age="25"/>
</root>
```

`id` and `name` jump to the front in that order; `age` stays where it was.

## When to use it

- **Almost everything.** If an element has 1–4 short attributes, `Inline` is
  what you want.
- **Don't use it** when an element routinely has many attributes (the line
  gets unreadably long) — switch to [`PerLine`](per-line.md).
- **Don't use it** when you have many sibling elements of the same tag with
  attribute values of varying widths — switch to
  [`AlignedGroup`](aligned-group.md) for tabular alignment.

## Reference

::: xmlegant.Inline
