# PerLine layout

`PerLine` puts each attribute on its own line, indented one level deeper than
the element. Equals signs are aligned to the longest attribute name within
the element. The closing `>` or `/>` trails the last attribute.

## Effect

=== "With `PerLine`"

    ```xml
    <signal
      attr_long="value1"
      attr2    ="s_value"
      attr3    ="value"/>
    ```

=== "Without (default `Inline`)"

    ```xml
    <signal attr_long="value1" attr2="s_value" attr3="value"/>
    ```

The difference matters when:

- The line gets long enough to wrap in your editor.
- You want diffs to show *which attribute* changed, not "the whole line
  changed."
- You have many attributes and need each one to be visually findable.

## Elements with children

The `>` trails the last attribute, children follow at the next indent level,
and the closing tag sits at the element's own indent:

=== "With `PerLine`"

    ```xml
    <signal
      attr_long="other"
      attr2    ="x"
      attr3    ="y">
      <child a="1" b="2"/>
    </signal>
    ```

=== "Without (default `Inline`)"

    ```xml
    <signal attr_long="other" attr2="x" attr3="y">
      <child a="1" b="2"/>
    </signal>
    ```

## Elements with text content

For text-only elements, the text and closing tag follow the `>` on the last
attribute line:

```xml
<signal
  attr1="v1"
  attr2="v2">content</signal>
```

## Self-closing elements with no attributes

`PerLine` is a no-op for elements with no attributes — they're emitted as a
plain self-closing tag:

```xml
<signal/>
```

## Namespace declarations

`xmlns` declarations introduced by the element are folded into the attribute
list as the leading entries and are aligned the same way:

```xml
<root
  xmlns    ="http://example.com/default"
  xmlns:x  ="http://example.com/x"
  attr     ="v"/>
```

## Applying the rule

```python
from pathlib import Path

from xmlegant import ElementRule, PerLine, Rule, rule


@rule
class PerLineSignal(Rule):
    def matches(self, path: Path) -> bool:
        return path.suffix == ".xml"

    def element_rules(self) -> list[ElementRule]:
        return [
            ElementRule(tags=("signal",), layout=PerLine()),
        ]
```

You can combine `PerLine` with [`attribute_order`](attribute-order.md) — the
ordering decides which attribute appears on which line, and the equals
alignment is computed from the resulting names.

## When to use it

- **Long attributes.** When attribute values are long URLs, base64 blobs, or
  human-readable descriptions.
- **Many attributes.** Configuration-style elements with 5+ attributes.
- **Diff-friendly elements.** When you care about per-attribute change
  visibility in code review.

## When *not* to use it

- **Tables of similar siblings.** A list of `<row>` or `<signal>` siblings
  reads better as aligned columns — use [`AlignedGroup`](aligned-group.md).
- **Elements with 1–2 short attributes.** `PerLine` makes them taller without
  helping.

## Reference

::: xmlegant.PerLine
