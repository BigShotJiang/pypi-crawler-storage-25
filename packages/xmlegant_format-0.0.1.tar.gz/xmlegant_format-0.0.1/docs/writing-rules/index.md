# Writing rules

A **rule** is a Python class that does two things:

1. **Decides which files it applies to** (`matches`).
2. **Declares per-tag formatting** (`element_rules`).

Rules live as `*.py` files in a `.xmlegant/` directory next to your XML
files. xmlegant scans that directory non-recursively at startup, imports each
file, and registers any class decorated with `@rule`.

## Anatomy of a rule

```python
from pathlib import Path

from xmlegant import AlignedGroup, ElementRule, PerLine, Rule, rule


@rule
class Autosar(Rule):
    def matches(self, path: Path) -> bool:
        return path.suffix == ".arxml"

    def element_rules(self) -> list[ElementRule]:
        return [
            ElementRule(tags=("signal",), layout=AlignedGroup()),
            ElementRule(tags=("port",),   layout=PerLine(),
                        attribute_order=("id", "name", "type")),
        ]
```

What's going on here:

- `@rule` validates that the class is a `Rule` subclass, instantiates it
  once, and stores the instance in xmlegant's registry. The class itself is
  returned unchanged so you can still import it from a unit test.
- `matches(path)` receives an absolute `pathlib.Path` for each input file.
  Return any truthy value to claim the file. See [Matching files](matching.md)
  for patterns beyond suffix checks.
- `element_rules()` returns a flat list of `ElementRule`. Each rule is
  applied to every element with that local name, regardless of nesting depth
  or namespace prefix.

## The three layout modes

xmlegant ships with three attribute layouts. Each has its own page with
before/after examples:

- [**Inline**](inline.md) — the default. All attributes on the opening line,
  separated by single spaces.
- [**PerLine**](per-line.md) — each attribute on its own line, with equals
  signs aligned. Good for elements with many or long attributes.
- [**AlignedGroup**](aligned-group.md) — inline, but with attributes
  column-aligned across consecutive same-tag siblings. Good for tabular data.

The layout is per-tag, not per-element. Once you set `PerLine` for `signal`,
every `signal` in the file gets it.

## Exactly one rule per file

For a given input file, **exactly one** registered rule may match. xmlegant
collects every rule whose `matches(path)` is truthy and:

- **One match** → that rule applies.
- **Zero matches** → no rules; the file is canonicalized with the default
  layout.
- **Two or more matches** → exit code 2 with an error naming the file and
  the conflicting rules.

This is intentional for v1. Don't try to encode priority by side effects in
`matches`; if you need that, file an issue.

## What's not configurable

- **Indentation.** Always 2 spaces. The whole point of the tool is to take a
  position.
- **Quoting.** Always double quotes for attribute values.
- **Final newline.** Always `\n` at end of file.
- **Encoding.** UTF-8 input only. Anything else is rejected at parse time.

If you want any of these to be configurable, this is not the tool for you —
and that's fine.
