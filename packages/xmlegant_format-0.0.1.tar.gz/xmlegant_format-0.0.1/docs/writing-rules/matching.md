# Matching files

`Rule.matches(path)` decides whether a rule applies to a file. It receives
an absolute `pathlib.Path` and returns a truthy value to claim it.

There's no built-in glob mechanism (yet) — you write Python, so you have
the full path API at your disposal. A few common patterns:

## By suffix

```python
def matches(self, path: Path) -> bool:
    return path.suffix == ".arxml"
```

## By exact filename

Useful for one-off configuration files:

```python
def matches(self, path: Path) -> bool:
    return path.name == "build-config.xml"
```

## By directory

```python
def matches(self, path: Path) -> bool:
    return "vendor" in path.parts
```

## By suffix and directory

```python
def matches(self, path: Path) -> bool:
    return path.suffix == ".xml" and path.parent.name == "interfaces"
```

## With a glob

`pathlib.Path.match` does glob-style matching against the path:

```python
def matches(self, path: Path) -> bool:
    return path.match("**/diagrams/*.xml")
```

## With XML inspection

`matches` can read the file if it needs to. Useful when the file extension
doesn't disambiguate which schema you're dealing with:

```python
def matches(self, path: Path) -> bool:
    if path.suffix != ".xml":
        return False
    head = path.read_bytes()[:512]
    return b'xmlns="http://autosar.org/schema/r4.0"' in head
```

!!! warning
    `matches` runs once per file before parsing. Reading the file in
    `matches` adds I/O — keep the read short (a head slice is usually
    enough) so a directory of thousands of XML files doesn't slow to a
    crawl.

## Exactly one rule must match

xmlegant requires **exactly one** match per file. Two rules with overlapping
`matches` will produce an exit-2 error naming the file and the conflicting
rules.

If you have several rules that share a file pattern, either:

- **Merge them** into one rule with a combined `element_rules()`. This is
  almost always the right answer.
- **Tighten the matchers** so they're mutually exclusive — e.g. one looks
  for an AUTOSAR schema URL in the file head, the other excludes it.

## Reference

::: xmlegant.Rule
