# CLI reference

xmlegant exposes two subcommands: `format` and `check`.

```
xmlegant format [-c CONFIG_DIR] [-o OUTPUT_FILE] FILE [FILE ...]
xmlegant check  [-c CONFIG_DIR] FILE [FILE ...]
```

## `format`

Rewrites each input file in place with the formatted output.

| Flag | Argument | Description |
|------|----------|-------------|
| `-c`, `--config` | `CONFIG_DIR` | Directory to scan for plugin `*.py` files. Default: `./.xmlegant`. |
| `-o`, `--output` | `OUTPUT_FILE` | Write to `OUTPUT_FILE` instead of in place. **Errors out if combined with more than one input file.** |
|  | `FILE [FILE ...]` | One or more XML files to format. |

Examples:

```sh
xmlegant format my-file.xml                    # rewrite in place
xmlegant format -o out.xml in.xml              # write to a different file
xmlegant format -c ./rules **/*.xml            # use a custom config dir
```

## `check`

Reads each file, formats in memory, and prints a unified diff to stdout for
any file that would change. Files that are already formatted produce no
output.

| Flag | Argument | Description |
|------|----------|-------------|
| `-c`, `--config` | `CONFIG_DIR` | Directory to scan for plugin `*.py` files. Default: `./.xmlegant`. |
|  | `FILE [FILE ...]` | One or more XML files to check. |

Use `check` in CI to fail builds where someone forgot to run `format`:

```sh
xmlegant check **/*.xml
```

## Exit codes

| Code | Meaning |
|------|---------|
| 0 | `format` succeeded, or `check` found nothing to change. |
| 1 | `check` found at least one file that would be reformatted. |
| 2 | Operational error: parse failure, plugin crash, ambiguous file rule match, invalid CLI usage, I/O error, non-UTF-8 input. |

All exit-2 errors are reported on stderr as `xmlegant: <message>` with no
Python traceback.

## Configuration directory

The `-c CONFIG_DIR` flag (default `./.xmlegant`) names a directory that
xmlegant scans **non-recursively** for `*.py` files. Each file is imported
fresh on every invocation; any class decorated with [`@rule`](api.md#xmlegant.rule)
becomes a candidate for matching.

If the config directory does not exist, xmlegant runs in
**canonicalization mode** — files are still parsed and re-emitted, but with
default formatting (`Inline`, original attribute order, 2-space indent).

## Encoding

xmlegant supports **UTF-8 input only**. Files declared with any other
encoding are rejected at parse time with exit code 2. UTF-8 aliases (`UTF8`,
`utf-8`, etc.) are accepted; files with no XML declaration default to UTF-8.

## Output format

- Always 2-space indentation.
- Always double quotes for attribute values.
- Always `\n` line endings (LF).
- Always a single `\n` at end of file.

These are intentional and non-configurable.
