# API reference

The complete public API. Anything not listed here is internal and may change
between releases without notice.

Import everything from the top-level `xmlegant` package:

```python
from xmlegant import AlignedGroup, ElementRule, Inline, PerLine, Rule, rule
```

## The `@rule` decorator

::: xmlegant.rule

## `Rule`

::: xmlegant.Rule

## `ElementRule`

::: xmlegant.ElementRule

## Layouts

### `Inline`

::: xmlegant.Inline

### `PerLine`

::: xmlegant.PerLine

### `AlignedGroup`

::: xmlegant.AlignedGroup
