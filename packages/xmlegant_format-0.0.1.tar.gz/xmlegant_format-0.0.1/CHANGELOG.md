# Changelog

All notable user-facing changes to this project will be documented in this
file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

### Changed

### Deprecated

### Removed

### Fixed

### Security

## [0.0.1] - 2024-05-12

This is the initial release of `xmlegant`.
It includes the core formatting and checking functionality, as well as basic configuration support.
It's rough around the edges but should be functional for simple use cases.