from __future__ import annotations

import json
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal
from urllib import error, request

from mcp_compressor.core import (
    BackendConfig,
    CompressedSession,
    CompressedSessionConfig,
    generate_client_artifacts,
    start_compressed_session,
    start_compressed_session_from_mcp_config,
    start_compressed_session_with_auth_providers,
)

CompressorMode = Literal["compressed", "cli", "bash", "python", "typescript"]
AuthProvider = Callable[[], Mapping[str, str]]
ServerConfig = dict[str, Any] | str | BackendConfig
ServersInput = dict[str, ServerConfig] | ServerConfig | str


@dataclass(frozen=True)
class ProxyTool:
    name: str
    description: str | None
    input_schema: dict[str, Any]


@dataclass(frozen=True)
class ProxyResponse:
    text: str


@dataclass(frozen=True)
class ExecutableTool:
    name: str
    description: str | None
    input_schema: dict[str, Any]
    execute: Callable[[dict[str, Any] | None], str]


@dataclass(frozen=True)
class GeneratedCodeClient:
    language: Literal["python", "typescript"]
    output_dir: Path
    files: list[Path]
    environment: dict[str, str]


@dataclass(frozen=True)
class JustBashCommand:
    command_name: str
    backend_tool_name: str
    description: str | None
    input_schema: dict[str, Any]
    invoke_tool_name: str


@dataclass(frozen=True)
class JustBashProvider:
    provider_name: str
    help_tool_name: str
    tools: list[JustBashCommand]


def _provider_from_value(value: ServerConfig) -> AuthProvider | None:
    if not isinstance(value, dict):
        return None
    provider = value.get("auth_provider")
    if provider is None:
        provider = value.get("authProvider")
    if provider is None:
        return None
    if not callable(provider):
        msg = "auth_provider must be callable"
        raise TypeError(msg)
    return provider


def _backend_provider_payload(name: str, value: ServerConfig, provider_index: int | None) -> dict[str, Any]:
    backend = _backend_from_value(name, value, resolve_provider=provider_index is not None)
    payload = {
        "name": backend.name,
        "command_or_url": backend.command_or_url,
        "args": backend.args or [],
    }
    if isinstance(value, dict):
        app_name = value.get("oauth_app_name", value.get("oauthAppName"))
        if app_name is not None:
            payload["oauth_app_name"] = str(app_name)
    if provider_index is not None:
        payload["provider_index"] = provider_index
    return payload


def _backend_from_value(name: str, value: ServerConfig, *, resolve_provider: bool = True) -> BackendConfig:
    if isinstance(value, BackendConfig):
        return value
    if isinstance(value, str):
        return BackendConfig(name=name, command_or_url=value)
    if "url" in value:
        args: list[str] = []
        headers = _resolve_headers(value) if resolve_provider else _resolve_headers(value, include_provider=False)
        if headers:
            for key, header_value in headers.items():
                args.extend(["-H", f"{key}={header_value}"])
            if "--auth" not in value.get("args", []):
                args.extend(["--auth", "explicit-headers"])
        args.extend(str(arg) for arg in value.get("args", []))
        app_name = value.get("oauth_app_name", value.get("oauthAppName"))
        return BackendConfig(
            name=name,
            command_or_url=str(value["url"]),
            args=args,
            oauth_app_name=str(app_name) if app_name is not None else None,
        )
    if "command" in value:
        return BackendConfig(
            name=name,
            command_or_url=str(value["command"]),
            args=[str(arg) for arg in value.get("args", [])],
        )
    msg = f"server {name!r} must define command or url"
    raise ValueError(msg)


def _resolve_headers(value: dict[str, Any], *, include_provider: bool = True) -> dict[str, str]:
    headers: dict[str, str] = {}
    raw_headers = value.get("headers")
    if isinstance(raw_headers, dict):
        headers.update({str(key): str(header_value) for key, header_value in raw_headers.items()})
    provider = value.get("auth_provider")
    if provider is None:
        provider = value.get("authProvider")
    if include_provider and provider is not None:
        if not callable(provider):
            msg = "auth_provider must be callable"
            raise TypeError(msg)
        provided = provider()
        if not isinstance(provided, Mapping):
            msg = "auth_provider must return a mapping of header names to values"
            raise TypeError(msg)
        headers.update({str(key): str(header_value) for key, header_value in provided.items()})
    return headers


def _resolve_provider_backends(
    servers: ServersInput,
) -> tuple[list[dict[str, Any]] | None, list[AuthProvider], str | None]:
    if isinstance(servers, str):
        stripped = servers.strip()
        if stripped.startswith("{"):
            return None, [], servers
        return [{"name": "default", "command_or_url": servers, "args": []}], [], None
    if isinstance(servers, BackendConfig):
        return [servers.to_json_dict()], [], None
    payloads: list[dict[str, Any]] = []
    providers: list[AuthProvider] = []
    for name, value in servers.items():
        provider = _provider_from_value(value)
        provider_index = None
        if provider is not None:
            provider_index = len(providers)
            providers.append(provider)
        payloads.append(_backend_provider_payload(name, value, provider_index))
    return payloads, providers, None


def _resolve_backends(servers: ServersInput) -> tuple[list[BackendConfig] | None, str | None]:
    if isinstance(servers, str):
        stripped = servers.strip()
        if stripped.startswith("{"):
            return None, servers
        return [BackendConfig(name="default", command_or_url=servers)], None
    if isinstance(servers, BackendConfig):
        return [servers], None
    return [_backend_from_value(name, value) for name, value in servers.items()], None


class CompressorProxy:
    def __init__(self, session: CompressedSession, default_server: str | None = None) -> None:
        self._session = session
        self._default_server = default_server
        self._closed = False

    @property
    def bridge_url(self) -> str:
        return str(self._session.info()["bridge_url"])

    @property
    def token(self) -> str:
        return str(self._session.info()["token"])

    @property
    def just_bash_providers(self) -> list[JustBashProvider]:
        providers = self._session.info().get("just_bash_providers", [])
        return [
            JustBashProvider(
                provider_name=str(provider["provider_name"]),
                help_tool_name=str(provider["help_tool_name"]),
                tools=[
                    JustBashCommand(
                        command_name=str(command["command_name"]),
                        backend_tool_name=str(command["backend_tool_name"]),
                        description=command.get("description"),
                        input_schema=dict(command["input_schema"]),
                        invoke_tool_name=str(command["invoke_tool_name"]),
                    )
                    for command in provider["tools"]
                ],
            )
            for provider in providers
        ]

    @property
    def tools(self) -> list[ProxyTool]:
        return [
            ProxyTool(
                name=str(tool["name"]),
                description=tool.get("description"),
                input_schema=dict(tool["input_schema"]),
            )
            for tool in self._session.info()["frontend_tools"]
        ]

    def close(self) -> None:
        self._closed = True
        self._session.close()

    def to_executable_tools(self) -> dict[str, ExecutableTool]:
        def make_execute(wrapper_name: str) -> Callable[[dict[str, Any] | None], str]:
            def execute(input: dict[str, Any] | None = None) -> str:
                return self.invoke_wrapper(wrapper_name, input or {}).text

            return execute

        return {
            tool.name: ExecutableTool(
                name=tool.name,
                description=tool.description,
                input_schema=tool.input_schema,
                execute=make_execute(tool.name),
            )
            for tool in self.tools
        }

    def write_client(self, kind: str, output_dir: str | Path, *, name: str | None = None) -> list[Path]:
        info = self._session.info()
        return generate_client_artifacts(
            kind,
            cli_name=name or self._default_server or "mcp",
            bridge_url=str(info["bridge_url"]),
            token=str(info["token"]),
            tools=list(info.get("backend_tools", info["frontend_tools"])),
            output_dir=output_dir,
        )

    def write_code_client(
        self,
        language: Literal["python", "typescript"],
        output_dir: str | Path,
        *,
        name: str | None = None,
    ) -> GeneratedCodeClient:
        output_path = Path(output_dir)
        files = self.write_client(language, output_path, name=name)
        environment = {"PYTHONPATH": str(output_path)} if language == "python" else {}
        return GeneratedCodeClient(
            language=language,
            output_dir=output_path,
            files=files,
            environment=environment,
        )

    def invoke_wrapper(self, wrapper_tool: str, tool_input: dict[str, Any]) -> ProxyResponse:
        if self._closed:
            msg = "Compressor proxy is closed"
            raise RuntimeError(msg)
        body = json.dumps({"tool": wrapper_tool, "input": tool_input}).encode()
        req = request.Request(  # noqa: S310 - local Rust proxy URL
            f"{self.bridge_url}/exec",
            data=body,
            headers={
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with request.urlopen(req, timeout=30) as response:  # noqa: S310 - local Rust proxy
                return ProxyResponse(response.read().decode())
        except error.HTTPError as exc:
            detail = exc.read().decode(errors="replace")
            msg = f"Proxy invocation failed: HTTP {exc.code}: {detail}"
            raise RuntimeError(msg) from exc

    def schema(self, tool: str, *, server: str | None = None) -> dict[str, Any]:
        scoped_tools = self._session.info().get("backend_tools_by_server", [])
        target_server = server or self._default_server
        matches = [
            item
            for item in scoped_tools
            if isinstance(item, dict)
            and item.get("tool", {}).get("name") == tool
            and (target_server is None or (item.get("server_name") or item.get("serverName")) == target_server)
        ]
        if len(matches) == 1:
            schema = matches[0].get("tool", {}).get("input_schema", {})
            if isinstance(schema, dict):
                return schema
            return {}
        if not matches:
            msg = f"Backend tool not found: {tool}"
            raise KeyError(msg)
        msg = "Multiple backend tools matched; specify a server"
        raise RuntimeError(msg)

    def invoke(self, tool: str, tool_input: dict[str, Any] | None = None, *, server: str | None = None) -> str:
        wrapper = _wrapper_name(server or self._default_server, "invoke_tool")
        return self.invoke_wrapper(wrapper, {"tool_name": tool, "tool_input": tool_input or {}}).text


def _wrapper_name(server: str | None, suffix: str) -> str:
    return f"{server}_{suffix}" if server else suffix


def normalize_servers(servers: ServersInput) -> list[BackendConfig] | None:
    """Normalize SDK server config into backend configs.

    Returns ``None`` when the input is raw MCP config JSON, which is passed through
    to the Rust core unchanged.
    """
    backends, mcp_config_json = _resolve_backends(servers)
    if mcp_config_json is not None:
        return None
    return backends


class CompressorClient:
    def __init__(
        self,
        *,
        servers: ServersInput,
        mode: CompressorMode = "compressed",
        compression_level: str = "medium",
        server_name: str | None = None,
        include_tools: list[str] | None = None,
        exclude_tools: list[str] | None = None,
        toonify: bool = False,
    ) -> None:
        self._servers = servers
        self._mode = mode
        self._config = CompressedSessionConfig(
            compression_level=compression_level,
            server_name=server_name,
            include_tools=include_tools,
            exclude_tools=exclude_tools,
            toonify=toonify,
            transform_mode=_transform_mode(mode),
        )
        self._session: CompressedSession | None = None

    def connect(self) -> CompressorProxy:
        if self._session is not None:
            return CompressorProxy(self._session, self._default_server())
        provider_backends, providers, mcp_config_json = _resolve_provider_backends(self._servers)
        if mcp_config_json is not None:
            self._session = start_compressed_session_from_mcp_config(self._config, mcp_config_json)
        elif providers:
            self._session = start_compressed_session_with_auth_providers(
                self._config, provider_backends or [], providers
            )
        else:
            backends, _ = _resolve_backends(self._servers)
            self._session = start_compressed_session(self._config, backends or [])
        return CompressorProxy(self._session, self._default_server())

    def _default_server(self) -> str | None:
        backends, mcp_config_json = _resolve_backends(self._servers)
        if mcp_config_json is not None:
            return None
        if backends is not None and len(backends) == 1:
            return backends[0].name
        return None

    def close(self) -> None:
        if self._session is not None:
            self._session.close()
            self._session = None

    def __enter__(self) -> CompressorProxy:
        return self.connect()

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.close()


def _transform_mode(mode: CompressorMode) -> str | None:
    if mode == "compressed":
        return None
    if mode == "bash":
        return "just-bash"
    if mode == "python" or mode == "typescript":
        return "cli"
    return mode
