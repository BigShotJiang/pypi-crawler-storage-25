"""
explicit-result: Async Utilities
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Async ergonomics for Result and Option. These utilities bridge the gap
between monadic types and async/await code, eliminating nested awaits
and providing a fluent async API.
"""

from __future__ import annotations

import warnings
from typing import (
    Any,
    Awaitable,
    Callable,
    Tuple,
    Type,
    TypeVar,
    Union,
)

from ._result import Ok, Err, Result
from ._option import Option, Some, Nothing

T = TypeVar("T")
E = TypeVar("E")
U = TypeVar("U")


async def from_awaitable(
    aw: Awaitable[T],
    catch: Union[Type[Exception], Tuple[Type[Exception], ...]] = Exception,
    allow_broad: bool = False,
) -> Result[T, Exception]:
    """
    Await an awaitable and wrap the result in Ok/Err.

        result = await from_awaitable(fetch_data(), catch=ConnectionError)
        # Ok(data) or Err(ConnectionError(...))

    Arguments:
        aw: Any awaitable (coroutine, Task, Future).
        catch: Exception type(s) to catch. Defaults to Exception.
        allow_broad: If True, suppress the warning when catching BaseException/Exception.

    Returns:
        Ok(value) on success, Err(exception) on caught failure.
    """
    from ._decorators import _validate_catch
    
    if not allow_broad:
        _catch = _validate_catch(catch, warn_broad=False)
    else:
        _catch = _validate_catch(catch)

    try:
        value = await aw
        return Ok(value)
    except _catch as exc:
        return Err(exc)


async def map_async(
    result: Result[T, E],
    f: Callable[[T], Awaitable[U]],
) -> Result[U, E]:
    """
    Apply an async function to the Ok value of a Result.

        result = Ok(user_id)
        profile = await map_async(result, fetch_profile)
        # Ok(Profile(...)) or original Err

    If the result is Err, the function is never called.
    """
    if isinstance(result, Ok):
        value = await f(result.value)
        return Ok(value)
    return result  # type: ignore[return-value]


async def and_then_async(
    result: Result[T, E],
    f: Callable[[T], Awaitable[Result[U, E]]],
) -> Result[U, E]:
    """
    Chain an async Result-returning function on the Ok value.

        result = Ok(user_id)
        profile = await and_then_async(result, async_find_profile)
        # Ok(Profile(...)) or Err(...)

    If the result is Err, the function is never called.
    This is the async equivalent of .and_then().
    """
    if isinstance(result, Ok):
        return await f(result.value)
    return result  # type: ignore[return-value]


async def from_optional_async(aw: Awaitable[T | None]) -> Option[T]:
    """
    Await a nullable value and wrap it in Option. Nothing if None.

    Example:
        >>> async def get_val(): return None
        >>> await from_optional_async(get_val())
        Nothing
    """
    value = await aw
    return Some(value) if value is not None else Nothing


async def map_option_async(
    opt: Option[T],
    f: Callable[[T], Awaitable[U]],
) -> Option[U]:
    """
    Apply an async function to the Some value of an Option.
    """
    if isinstance(opt, Some):
        value = await f(opt.value)
        return Some(value)
    return opt  # type: ignore[return-value]


async def and_then_option_async(
    opt: Option[T],
    f: Callable[[T], Awaitable[Option[U]]],
) -> Option[U]:
    """
    Chain an async Option-returning function on the Some value.
    """
    if isinstance(opt, Some):
        return await f(opt.value)
    return opt  # type: ignore[return-value]


F = TypeVar("F")

async def map_err_async(
    result: Result[T, E],
    f: Callable[[E], Awaitable[F]],
) -> Result[T, F]:
    """
    Apply an async function to the Err value of a Result.
    """
    if isinstance(result, Err):
        err_val = await f(result.error)
        return Err(err_val)
    return result  # type: ignore[return-value]


async def or_else_async(
    result: Result[T, E],
    f: Callable[[E], Awaitable[Result[T, F]]],
) -> Result[T, F]:
    """
    Chain an async recovery function on the Err value.
    If the result is Ok, the function is never called.
    """
    if isinstance(result, Err):
        return await f(result.error)
    return result  # type: ignore[return-value]


async def or_else_option_async(
    opt: Option[T],
    f: Callable[[], Awaitable[Option[T]]],
) -> Option[T]:
    """
    Chain an async Option-returning function on the Nothing value.
    If the option is Some, the function is never called.
    """
    if isinstance(opt, Some):
        return opt
    return await f()



