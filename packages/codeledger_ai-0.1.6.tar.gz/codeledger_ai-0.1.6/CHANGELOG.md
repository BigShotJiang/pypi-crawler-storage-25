# Changelog

## 0.1.6 — 2026-04-16

### Fixed
- Dashboard accessible at http://localhost:8100 without credentials
- Root route / and /assets/* added to public paths in auth middleware
- Frontend index.html served at root when frontend/dist exists
- Pre-built frontend now bundled in the wheel (backend/frontend_dist/)

## 0.1.5 — 2026-04-16

### Fixed
- Removed all references to codeledger.dev (domain not live yet)
- Replaced with github.com/codeledgerAI/codeledger throughout

## 0.1.4 — 2026-04-16

### Fixed
- **`codeledger serve` on Windows (and any platform) now bails with an
  actionable error when run before `codeledger init`.** Previously the
  CLI fell through to `uvicorn.run("backend.main:app", ...)` which then
  surfaced the cryptic *"Attribute app not found in module
  backend.main"* — caused by `backend/main.py`'s module-level
  `app = create_app()` raising `FileNotFoundError` (no
  `codeledger.toml` to load) and being silently suppressed. The CLI
  now checks for `codeledger.toml` in the current directory before
  invoking uvicorn and prints:

  ```
  CodeLedger is not initialised in this directory.
    Looked for: /full/path/to/codeledger.toml
    Run `codeledger init` here first.
  ```

  Exit code is `2`. After running `codeledger init`, `codeledger serve`
  works as before.

### Verified — no other Windows-startup blockers
- No unix-only signal handlers in `backend/main.py`.
- No `fcntl`/`termios`/`pty`/`grp`/`pwd` imports anywhere.
- No hardcoded `/tmp`, `/var`, `/etc`, `/usr` paths in the CLI or the
  app factory.
- All home-directory references use `Path.home()` (cross-platform).
- `/health` endpoint exists at `backend/main.py:318`, gated outside
  `AuthMiddleware` (per SEC-05) — npm bootstrap probe will resolve.

## 0.1.3 — 2026-04-16

### Fixed
- **Windows compatibility: `asyncpg`** moved from required to the new
  `[postgres]` optional extra. Team-mode PostgreSQL users run
  `pip install codeledger-ai[postgres]`; solo SQLite users no longer
  pay the native-build cost (asyncpg has no Windows wheel on Python
  3.14 as of this release).
- **Windows compatibility: `tiktoken`** moved to the `[tiktoken]`
  optional extra. When tiktoken is absent, `count_tokens` and
  `_truncate_to_tokens` fall back to a character-based approximation
  (~4 chars/token for `cl100k_base` English). Context-budget math
  stays conservative; install tiktoken for exact counts.
- **`uvloop`** was never a direct dependency in this project — no
  change needed.

### Install matrix
- Solo SQLite (default, no compilation):
  `pip install codeledger-ai`
- Team PostgreSQL:
  `pip install codeledger-ai[postgres]`
- Exact token accounting:
  `pip install codeledger-ai[tiktoken]`
- Local embedding fallback (no Ollama):
  `pip install codeledger-ai[local-embed]`
- Everything:
  `pip install codeledger-ai[postgres,tiktoken,local-embed]`

### No behaviour change when the extras are present
Projects that already install `asyncpg` and `tiktoken` (explicitly or
via an extra) see identical behaviour to 0.1.2. Fallbacks engage only
when the optional dependency is not importable.

## 0.1.2 — 2026-04-16

### Fixed
- **Windows compatibility.** Replaced `sqlite-vss` (no Windows wheel
  published) with `sqlite-vec`, the actively-maintained successor by
  the same author. Windows wheels are available for all supported
  CPython versions, so `pip install codeledger-ai` now works on
  Windows, macOS, and Linux without additional native-toolchain
  prerequisites.

### Changed
- Internal vector index now uses `sqlite-vec`'s `vec0` virtual table
  with `distance_metric=cosine` (was `sqlite-vss`'s `vss0` with
  squared-L2). Scoring semantics are preserved: `score = 1 - distance`
  gives cosine similarity in `[-1.0, 1.0]`. Vectors are serialized as
  packed `float32` bytes instead of JSON strings — smaller index size
  for the same data.
- Internal table renamed: `vss_items` → `vec_items`. The
  `SqliteVssStore` class name is retained for API stability.

### Migration
- New installs on 0.1.2 get the new schema automatically.
- Upgrading from 0.1.1 on Linux/macOS: existing vectors live in the
  old `vss_items` virtual table, which no longer exists in 0.1.2. The
  simplest reset is to delete `data/codeledger.db` and re-run
  `codeledger init` for a clean slate — decisions, stories, sessions,
  and provenance records rebuild from source via the change-detection
  backend on the next commit or file save. 0.1.1 was available for
  under a day, so the migration impact is minimal.

## 0.1.1 — 2026-04-16

First real PyPI release. Full MCP server with ~50 tools:
bidirectional code provenance, active context injection via Claude
Code hooks, independent quality harness, drift detection,
tautological-test detection, rollback impact planning. Solo mode
free; team mode with shared decision history. Onboarding walkthrough
at `http://localhost:8100`. Linux and macOS support (Windows blocked
by sqlite-vss native wheel — fixed in 0.1.2).

## 0.0.1 — 0.0.2

Name-reservation placeholders. Yanked.
