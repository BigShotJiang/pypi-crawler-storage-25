import ReactECharts from "echarts-for-react";

/**
 * Placeholder scatter plot for the UMAP projection view.
 *
 * The backend `/api/explorer/projection` endpoint is not yet implemented;
 * this view renders a static demo grid so the surface is navigable.
 */
export function ExplorerView() {
  const option = {
    tooltip: { formatter: (p: { data: number[] }) => `(${p.data[0]}, ${p.data[1]})` },
    xAxis: { type: "value", name: "x" },
    yAxis: { type: "value", name: "y" },
    series: [
      {
        type: "scatter",
        symbolSize: 8,
        data: Array.from({ length: 60 }, () => [
          Math.random() * 10 - 5,
          Math.random() * 10 - 5,
        ]),
        itemStyle: { color: "#7c5cff" },
      },
    ],
  };
  return (
    <div className="space-y-2">
      <p className="text-sm text-muted">
        2D UMAP projection of embedded context items. Hover a point for its
        metadata. (Backend projection endpoint stubbed in this build.)
      </p>
      <ReactECharts option={option} style={{ height: 500 }} />
    </div>
  );
}
