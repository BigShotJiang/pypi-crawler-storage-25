import { useState } from "react";
import ReactECharts from "echarts-for-react";
import { useQuery } from "@tanstack/react-query";
import { api } from "../api/client";

/**
 * Force-directed graph of a decision's provenance tree.
 *
 * Nodes:
 *  - decisions (purple circles)
 *  - git_commit change events (gray circles)
 *  - file_snapshot change events (teal diamonds)
 *  - AST changes (green circles)
 */
export function ProvenanceView() {
  const { data: decisions = [] } = useQuery({
    queryKey: ["decisions"],
    queryFn: () => api.decisions.list(),
  });
  const [selected, setSelected] = useState<string | null>(null);
  const { data: tree } = useQuery({
    queryKey: ["provenance-forward", selected],
    queryFn: () =>
      selected ? api.decisions.trace(selected) : Promise.resolve(null),
    enabled: Boolean(selected),
  });

  type GraphNode = {
    id: string;
    name: string;
    symbol: string;
    itemStyle: { color: string };
    symbolSize: number;
  };
  const nodes: GraphNode[] = [];
  const links: { source: string; target: string }[] = [];
  if (tree) {
    nodes.push({
      id: tree.decision.id,
      name: tree.decision.title || "decision",
      symbol: "circle",
      itemStyle: { color: "#7c5cff" },
      symbolSize: 28,
    });
    for (const e of tree.change_events) {
      const eventNodeId = `evt-${e.change_event_id}`;
      nodes.push({
        id: eventNodeId,
        name: e.label,
        symbol: e.change_event_type === "file_snapshot" ? "diamond" : "circle",
        itemStyle: {
          color: e.change_event_type === "file_snapshot" ? "#2dd4bf" : "#94a3b8",
        },
        symbolSize: 20,
      });
      links.push({ source: tree.decision.id, target: eventNodeId });
      e.ast_changes.forEach((a, i) => {
        const astId = `ast-${eventNodeId}-${i}`;
        nodes.push({
          id: astId,
          name: String(a.entity_name ?? "ast"),
          symbol: "circle",
          itemStyle: { color: "#22c55e" },
          symbolSize: 12,
        });
        links.push({ source: eventNodeId, target: astId });
      });
    }
  }

  const option = {
    tooltip: {},
    series: [
      {
        type: "graph",
        layout: "force",
        roam: true,
        label: { show: true, fontSize: 10 },
        force: { repulsion: 160, edgeLength: 60 },
        data: nodes,
        links,
      },
    ],
  };

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <select
          value={selected ?? ""}
          onChange={(e) => setSelected(e.target.value || null)}
          className="border border-muted/30 rounded px-2 py-1"
        >
          <option value="">Select a decision…</option>
          {decisions.map((d) => (
            <option key={d.id} value={d.id}>
              {d.title}
            </option>
          ))}
        </select>
        <div className="text-xs text-muted self-center">
          Diamonds = file_snapshot events · Circles = git commits / decisions /
          AST changes
        </div>
      </div>
      {selected ? (
        <ReactECharts option={option} style={{ height: 500 }} />
      ) : (
        <div className="text-muted">Pick a decision to visualise its provenance.</div>
      )}
    </div>
  );
}
