import { useState } from "react";

export function LoginView({ onLogin }: { onLogin: (token: string) => void }) {
  const [token, setToken] = useState("");
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-full max-w-md space-y-4 p-8 border border-muted/20 rounded">
        <h1 className="text-2xl font-semibold">Sign in to CodeLedger</h1>
        <p className="text-sm text-muted">
          Paste your bearer token or PAT, or use one of the OAuth providers
          below. CLI users can also run{" "}
          <code className="px-1 bg-muted/10 rounded">codeledger login</code> to
          complete a device-auth flow.
        </p>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (token.trim()) {
              localStorage.setItem("cl.token", token.trim());
              onLogin(token.trim());
            }
          }}
          className="space-y-3"
        >
          <input
            type="password"
            placeholder="Bearer token"
            value={token}
            onChange={(e) => setToken(e.target.value)}
            className="w-full border border-muted/30 rounded px-3 py-2 bg-transparent"
          />
          <button
            type="submit"
            className="w-full bg-accent text-white rounded py-2"
          >
            Continue
          </button>
        </form>
        <div className="flex gap-2">
          <a
            href="/api/auth/oauth/google"
            className="flex-1 text-center border border-muted/30 rounded py-2 hover:bg-muted/10"
          >
            Google
          </a>
          <a
            href="/api/auth/oauth/github"
            className="flex-1 text-center border border-muted/30 rounded py-2 hover:bg-muted/10"
          >
            GitHub
          </a>
        </div>
      </div>
    </div>
  );
}
