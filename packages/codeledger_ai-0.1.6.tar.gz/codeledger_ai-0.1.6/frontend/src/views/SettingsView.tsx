import { useQuery } from "@tanstack/react-query";
import { api } from "../api/client";
import { useAppStore } from "../store/appStore";
import { useProjectStore } from "../store/projectStore";

export function SettingsView() {
  const { data: status } = useQuery({
    queryKey: ["security-status"],
    queryFn: () => api.security.status(),
    retry: false,
  });
  const theme = useAppStore((s) => s.theme);
  const toggleTheme = useAppStore((s) => s.toggleTheme);
  const backend = useProjectStore((s) => s.changeDetectionBackend);

  return (
    <div className="grid grid-cols-3 gap-6">
      <section className="space-y-3">
        <h2 className="font-medium">Connected services</h2>
        <div className="text-sm text-muted">No services connected.</div>
        <h2 className="font-medium mt-6">Personal access tokens</h2>
        <div className="text-sm text-muted">
          Manage PATs from the CLI: <code>codeledger token generate</code>.
        </div>
      </section>

      <section className="space-y-3">
        <h2 className="font-medium">Appearance</h2>
        <button
          onClick={toggleTheme}
          className="border border-muted/30 rounded px-3 py-1"
        >
          Theme: {theme}
        </button>

        <h2 className="font-medium mt-6">Project</h2>
        <div className="text-sm">
          Change detection backend:{" "}
          <span
            className={`px-2 py-0.5 rounded text-xs ${
              backend === "git"
                ? "bg-blue-600 text-white"
                : "bg-amber-500 text-black"
            }`}
          >
            {backend}
          </span>
        </div>
        {backend === "file_watcher" && (
          <div className="text-xs text-amber-300">
            CI verification unavailable. Run{" "}
            <code>git init && codeledger init --reinstall-hooks</code> to enable.
          </div>
        )}
      </section>

      <section className="space-y-3">
        <h2 className="font-medium">Security status</h2>
        <div className="space-y-1">
          {status?.invariants.map((inv) => (
            <div
              key={inv.id}
              className="flex items-center justify-between border border-muted/20 rounded px-3 py-2 text-sm"
            >
              <span>{inv.id}</span>
              <span className="flex items-center gap-2">
                {inv.id === "SEC-11" && inv.total_unlinked !== undefined && (
                  <span className="text-xs text-muted">
                    {inv.total_unlinked} total ({inv.unlinked_commits ?? 0} git,{" "}
                    {inv.unlinked_file_changes ?? 0} file watcher)
                  </span>
                )}
                <span
                  className={`text-xs px-2 py-0.5 rounded ${
                    inv.status === "pass"
                      ? "bg-green-500 text-white"
                      : "bg-amber-500 text-black"
                  }`}
                >
                  {inv.status}
                </span>
              </span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
