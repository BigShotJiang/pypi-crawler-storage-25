import { useState } from "react";

type Transport = "http" | "sse" | "stdio";
type AuthKind = "oauth" | "api_key" | "none";

interface ServerEntry {
  name: string;
  url: string;
  transport: Transport;
  auth: AuthKind;
  toolCount: number;
  status: "connected" | "disconnected";
}

export function MCPServersView() {
  const [servers, setServers] = useState<ServerEntry[]>([
    {
      name: "codeledger",
      url: "http://localhost:8100/mcp",
      transport: "http",
      auth: "api_key",
      toolCount: 16,
      status: "connected",
    },
  ]);
  const [form, setForm] = useState<Partial<ServerEntry>>({
    transport: "http",
    auth: "none",
  });

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        {servers.map((s) => (
          <div
            key={s.name}
            className="flex items-center gap-4 border border-muted/20 rounded p-3"
          >
            <div
              className={`w-2 h-2 rounded-full ${
                s.status === "connected" ? "bg-green-500" : "bg-red-500"
              }`}
            />
            <div className="flex-1">
              <div className="font-medium">{s.name}</div>
              <div className="text-xs text-muted">{s.url}</div>
            </div>
            <span className="text-xs px-2 py-0.5 rounded bg-muted/10">
              {s.transport}
            </span>
            <span className="text-xs px-2 py-0.5 rounded bg-muted/10">
              {s.auth}
            </span>
            <span className="text-xs text-muted">{s.toolCount} tools</span>
          </div>
        ))}
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (form.name && form.url) {
            setServers([
              ...servers,
              {
                name: form.name,
                url: form.url,
                transport: form.transport as Transport,
                auth: form.auth as AuthKind,
                toolCount: 0,
                status: "disconnected",
              },
            ]);
            setForm({ transport: "http", auth: "none" });
          }
        }}
        className="border border-muted/20 rounded p-4 space-y-3"
      >
        <h3 className="font-medium">Add MCP server</h3>
        <input
          placeholder="Name"
          value={form.name ?? ""}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className="w-full border border-muted/30 rounded px-3 py-2 bg-transparent"
        />
        <input
          placeholder="URL or command"
          value={form.url ?? ""}
          onChange={(e) => setForm({ ...form, url: e.target.value })}
          className="w-full border border-muted/30 rounded px-3 py-2 bg-transparent"
        />
        <div className="flex gap-2">
          <select
            value={form.transport}
            onChange={(e) =>
              setForm({ ...form, transport: e.target.value as Transport })
            }
            className="border border-muted/30 rounded px-2 bg-transparent"
          >
            <option value="http">HTTP/SSE</option>
            <option value="sse">SSE</option>
            <option value="stdio">stdio</option>
          </select>
          <select
            value={form.auth}
            onChange={(e) => setForm({ ...form, auth: e.target.value as AuthKind })}
            className="border border-muted/30 rounded px-2 bg-transparent"
          >
            <option value="none">No auth</option>
            <option value="oauth">OAuth</option>
            <option value="api_key">API key</option>
          </select>
          <button className="ml-auto px-4 py-2 bg-accent text-white rounded">
            Connect
          </button>
        </div>
      </form>
    </div>
  );
}
