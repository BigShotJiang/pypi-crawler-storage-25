import { useEffect, useState } from "react";

type SetupStatus = {
  setup_complete: boolean;
  step_reached: number;
  project_name: string;
  change_detection_backend: "git" | "file_watcher";
  mode: "solo" | "team";
  port: number;
  decisions_count: number;
  sessions_count: number;
};

async function fetchStatus(): Promise<SetupStatus> {
  const res = await fetch("/api/setup/status");
  return res.json();
}

async function postComplete(step: number, complete: boolean): Promise<void> {
  await fetch("/api/setup/complete", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ step_reached: step, complete }),
  });
}

function StepIndicator({ current, total }: { current: number; total: number }) {
  return (
    <div className="flex items-center gap-2 mb-6">
      {Array.from({ length: total }, (_, i) => (
        <div
          key={i}
          className={`h-2 flex-1 rounded ${
            i < current ? "bg-accent" : "bg-muted/20"
          }`}
        />
      ))}
      <span className="text-xs text-muted ml-2">
        Step {current} / {total}
      </span>
    </div>
  );
}

function StepWelcome({
  status,
  onNext,
}: {
  status: SetupStatus;
  onNext: () => void;
}) {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Welcome to CodeLedger</h1>
      <p className="text-muted">
        Ask why any function exists. Get the decision that created it.
      </p>
      <p className="text-sm">
        CodeLedger is running. Your MCP server is live at{" "}
        <code className="bg-muted/10 px-1 rounded">
          http://localhost:{status.port}/mcp
        </code>
        .
        {status.mode === "team"
          ? " Team members can connect using the URL printed in team-setup.md."
          : " Claude Code has been configured to connect to it automatically."}
      </p>
      <ul className="space-y-2 text-sm">
        <li>
          <span className="text-green-500">✓</span> Server running on port{" "}
          {status.port}
        </li>
        <li>
          <span className="text-green-500">✓</span>{" "}
          {status.mode === "team"
            ? "Team mode configured"
            : "Claude Code configured"}
        </li>
        <li>
          <span className="text-muted">•</span> Change detection:{" "}
          {status.change_detection_backend}
        </li>
      </ul>
      <button
        onClick={onNext}
        className="px-4 py-2 bg-accent text-white rounded"
      >
        Next
      </button>
    </div>
  );
}

function StepConnectIDE({
  onNext,
  mode,
  port,
}: {
  onNext: () => void;
  mode: "solo" | "team";
  port: number;
}) {
  const [rescans, setRescans] = useState(0);
  // In a real implementation we'd poll a /api/setup/detected-clients endpoint;
  // keep this purely informational so detection errors never block progress.
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">
        {mode === "team" ? "Tell your team" : "Connect your IDE"}
      </h1>
      {mode === "team" ? (
        <p className="text-sm">
          Open <code>team-setup.md</code> in this project root and share it
          with your team. Each developer runs:
          <pre className="bg-muted/10 p-3 rounded mt-2 text-xs font-mono">
            codeledger login --server http://&lt;your-ip&gt;:{port}
            {"\n"}codeledger connect --server http://&lt;your-ip&gt;:{port}
          </pre>
        </p>
      ) : (
        <div className="grid grid-cols-3 gap-3">
          {[
            { name: "Claude Code", primary: true },
            { name: "Cursor", primary: false },
            { name: "Windsurf", primary: false },
          ].map((client) => (
            <div
              key={client.name}
              className={`border rounded p-3 ${
                client.primary ? "border-green-500" : "border-muted/30"
              }`}
            >
              <div className="font-medium">{client.name}</div>
              <div className="text-xs text-muted mt-1">
                Run <code>codeledger connect</code> on this machine to
                auto-configure.
              </div>
            </div>
          ))}
        </div>
      )}
      <div className="flex gap-2">
        <button
          onClick={() => setRescans(rescans + 1)}
          className="px-3 py-1 border border-muted/30 rounded text-sm"
        >
          Re-scan for clients
        </button>
        <button
          onClick={onNext}
          className="px-4 py-2 bg-accent text-white rounded ml-auto"
        >
          Next
        </button>
      </div>
    </div>
  );
}

function StepFirstDecision({
  onNext,
  onStatusPoll,
}: {
  onNext: () => void;
  onStatusPoll: () => Promise<SetupStatus>;
}) {
  const [count, setCount] = useState(0);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const poll = async () => {
      const status = await onStatusPoll().catch(() => null);
      if (cancelled || !status) return;
      setCount(status.decisions_count);
      if (status.decisions_count > 0) setReady(true);
    };
    poll();
    const id = window.setInterval(poll, 3000);
    // Fallback: allow Next after 30s even without a decision.
    const fallback = window.setTimeout(() => setReady(true), 30000);
    return () => {
      cancelled = true;
      window.clearInterval(id);
      window.clearTimeout(fallback);
    };
  }, [onStatusPoll]);

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Make your first decision</h1>
      <p className="text-sm">Start a session in Claude Code and type:</p>
      <pre className="bg-muted/10 p-3 rounded text-xs font-mono whitespace-pre-wrap">
        {`"Use decision.create to record that we use Python 3.11
 with FastAPI for this project's backend."`}
      </pre>
      <p className="text-sm">Then come back here.</p>
      <div
        className={`p-3 rounded border ${
          count > 0
            ? "border-green-500 text-green-500"
            : "border-muted/30 text-muted"
        }`}
      >
        {count > 0 ? "✓" : "•"} Decisions recorded: {count}
      </div>
      <button
        disabled={!ready}
        onClick={onNext}
        className={`px-4 py-2 rounded ${
          ready
            ? "bg-accent text-white"
            : "bg-muted/20 text-muted cursor-not-allowed"
        }`}
      >
        Next
      </button>
    </div>
  );
}

function StepFirstCommit({
  onNext,
  onStatusPoll,
  changeDetection,
}: {
  onNext: () => void;
  onStatusPoll: () => Promise<SetupStatus>;
  changeDetection: "git" | "file_watcher";
}) {
  const [count, setCount] = useState(0);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const poll = async () => {
      const status = await onStatusPoll().catch(() => null);
      if (cancelled || !status) return;
      // Use sessions_count as a proxy for commits/file changes — both
      // bump the session count when CodeLedger links them.
      setCount(status.sessions_count);
      if (status.sessions_count > 0) setReady(true);
    };
    poll();
    const id = window.setInterval(poll, 3000);
    const fallback = window.setTimeout(() => setReady(true), 30000);
    return () => {
      cancelled = true;
      window.clearInterval(id);
      window.clearTimeout(fallback);
    };
  }, [onStatusPoll]);

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Make your first commit</h1>
      {changeDetection === "git" ? (
        <pre className="bg-muted/10 p-3 rounded text-xs font-mono whitespace-pre-wrap">
          {`Make any code change and commit it:

  git add . && git commit -m "first tracked commit"

CodeLedger will link it to your decision automatically.`}
        </pre>
      ) : (
        <p className="text-sm">
          Save any <code>.py</code> or <code>.ts</code> file — CodeLedger
          will detect the change automatically.
        </p>
      )}
      <div
        className={`p-3 rounded border ${
          count > 0
            ? "border-green-500 text-green-500"
            : "border-muted/30 text-muted"
        }`}
      >
        {count > 0 ? "✓" : "•"}{" "}
        {changeDetection === "git"
          ? "Commits detected"
          : "File changes detected"}
        : {count}
      </div>
      <button
        disabled={!ready}
        onClick={onNext}
        className={`px-4 py-2 rounded ${
          ready
            ? "bg-accent text-white"
            : "bg-muted/20 text-muted cursor-not-allowed"
        }`}
      >
        Next
      </button>
    </div>
  );
}

function StepFirstQuery({ onFinish }: { onFinish: () => void }) {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">
        Run your first provenance query
      </h1>
      <p className="text-sm">In Claude Code, type:</p>
      <pre className="bg-muted/10 p-3 rounded text-xs font-mono whitespace-pre-wrap">
        {`"Run decision.list and show me what decisions
 CodeLedger has recorded."

Or try the reverse trace — find any function in your
codebase and run:

provenance.reverse("path/to/file.py", "function_name")`}
      </pre>
      <div className="flex gap-2">
        <button
          onClick={onFinish}
          className="px-4 py-2 bg-accent text-white rounded"
        >
          Go to dashboard
        </button>
        <button
          onClick={onFinish}
          className="text-sm text-muted underline ml-auto"
        >
          Skip setup
        </button>
      </div>
    </div>
  );
}

export function OnboardingView({ onComplete }: { onComplete: () => void }) {
  const [status, setStatus] = useState<SetupStatus | null>(null);
  const [step, setStep] = useState<number>(1);

  useEffect(() => {
    fetchStatus().then((s) => {
      setStatus(s);
      setStep(Math.max(1, Math.min(5, s.step_reached)));
    });
  }, []);

  if (!status) {
    return (
      <div className="min-h-screen flex items-center justify-center text-muted">
        Loading…
      </div>
    );
  }

  const advance = async (next: number) => {
    setStep(next);
    await postComplete(next, false);
  };

  const finish = async () => {
    await postComplete(5, true);
    onComplete();
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-xl border border-muted/20 rounded p-8 space-y-6">
        <StepIndicator current={step} total={5} />
        {step === 1 && (
          <StepWelcome status={status} onNext={() => advance(2)} />
        )}
        {step === 2 && (
          <StepConnectIDE
            mode={status.mode}
            port={status.port}
            onNext={() => advance(3)}
          />
        )}
        {step === 3 && (
          <StepFirstDecision
            onStatusPoll={fetchStatus}
            onNext={() => advance(4)}
          />
        )}
        {step === 4 && (
          <StepFirstCommit
            onStatusPoll={fetchStatus}
            changeDetection={status.change_detection_backend}
            onNext={() => advance(5)}
          />
        )}
        {step === 5 && <StepFirstQuery onFinish={finish} />}
      </div>
    </div>
  );
}
