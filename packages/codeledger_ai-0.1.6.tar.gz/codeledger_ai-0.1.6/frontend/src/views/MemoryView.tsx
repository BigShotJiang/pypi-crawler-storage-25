import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { api } from "../api/client";

type Filter = "all" | "decision" | "story" | "session";

export function MemoryView() {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<Filter>("all");
  const [submitted, setSubmitted] = useState("");

  const { data, isLoading, isError } = useQuery({
    queryKey: ["context-relevant", submitted],
    queryFn: () =>
      submitted
        ? api.context.relevant({ query: submitted, token_budget: 8000 })
        : Promise.resolve(null),
    enabled: Boolean(submitted),
  });

  const items = [
    ...(data?.included_items ?? []),
    ...(data?.summarized_items ?? []),
  ].filter((i) => filter === "all" || i.item_type === filter);

  const usage = data
    ? Math.round((data.total_tokens_used / data.token_budget) * 100)
    : 0;
  const barColor = usage > 80 ? "bg-red-500" : "bg-green-500";

  return (
    <div className="space-y-4">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          setSubmitted(query);
        }}
        className="flex gap-2"
      >
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search memory..."
          className="flex-1 border border-muted/30 rounded px-3 py-2 bg-transparent"
        />
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value as Filter)}
          className="border border-muted/30 rounded px-2"
        >
          <option value="all">All</option>
          <option value="decision">Decisions</option>
          <option value="story">Stories</option>
          <option value="session">Sessions</option>
        </select>
        <button
          type="submit"
          className="px-4 py-2 bg-accent text-white rounded"
        >
          Search
        </button>
      </form>

      {data && (
        <div>
          <div className="flex justify-between text-xs text-muted mb-1">
            <span>Token budget</span>
            <span>
              {data.total_tokens_used} / {data.token_budget} ({usage}%)
            </span>
          </div>
          <div className="h-2 w-full bg-muted/10 rounded">
            <div
              className={`h-2 rounded ${barColor}`}
              style={{ width: `${Math.min(usage, 100)}%` }}
            />
          </div>
        </div>
      )}

      {isLoading && <div className="text-muted">Searching…</div>}
      {isError && <div className="text-red-400">Search failed.</div>}

      <div className="space-y-2">
        {items.map((item) => (
          <div
            key={item.item_id}
            className="border border-muted/20 rounded p-3 space-y-1"
          >
            <div className="flex justify-between text-xs">
              <span className="px-2 py-0.5 rounded bg-accent/20 text-accent">
                {item.item_type}
              </span>
              <span className="text-muted">
                score: {item.score.toFixed(3)} · tokens: {item.token_count}
              </span>
            </div>
            <div className="text-sm font-mono">{item.item_id}</div>
          </div>
        ))}
      </div>

      {data?.excluded_summary && (
        <div className="text-xs text-muted italic border-t border-muted/20 pt-2">
          {data.excluded_summary}
        </div>
      )}
    </div>
  );
}
