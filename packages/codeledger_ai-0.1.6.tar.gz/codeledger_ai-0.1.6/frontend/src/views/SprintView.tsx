import { useQuery } from "@tanstack/react-query";
import ReactECharts from "echarts-for-react";
import { api } from "../api/client";

export function SprintView() {
  const { data: velocity } = useQuery({
    queryKey: ["sprint-velocity"],
    queryFn: () => api.sprints.velocity(),
  });
  const { data: stories = [] } = useQuery<Array<Record<string, unknown>>>({
    queryKey: ["stories"],
    queryFn: () =>
      api.stories.list() as unknown as Promise<Array<Record<string, unknown>>>,
  });

  const buckets: Record<string, Array<Record<string, unknown>>> = {
    backlog: [],
    in_progress: [],
    review: [],
    done: [],
  };
  for (const s of stories) {
    const status = String(s.status ?? "backlog");
    if (buckets[status]) buckets[status].push(s);
  }

  const velocityOption = {
    tooltip: {},
    xAxis: {
      type: "category",
      data: velocity?.series.map((s) => s.sprint_name ?? "sprint") ?? [],
    },
    yAxis: { type: "value" },
    series: [
      {
        type: "bar",
        data: velocity?.series.map((s) => s.points_done) ?? [],
        itemStyle: { color: "#7c5cff" },
      },
    ],
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-3 gap-4">
        <Metric label="Average velocity" value={velocity?.average_velocity.toFixed(1) ?? "—"} />
        <Metric label="Stories in backlog" value={buckets.backlog.length} />
        <Metric label="Stories done" value={buckets.done.length} />
      </div>

      <div className="grid grid-cols-4 gap-3">
        {(["backlog", "in_progress", "review", "done"] as const).map((lane) => (
          <div key={lane} className="border border-muted/20 rounded p-3">
            <div className="text-xs uppercase text-muted mb-2">{lane}</div>
            <div className="space-y-2">
              {buckets[lane].map((s) => (
                <div
                  key={String(s.id)}
                  className="border border-muted/20 rounded p-2 text-sm"
                >
                  {String(s.title ?? "(untitled)")}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="border border-muted/20 rounded p-3">
        <div className="text-sm mb-2">Velocity (last 6 sprints)</div>
        <ReactECharts option={velocityOption} style={{ height: 240 }} />
      </div>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: unknown }) {
  return (
    <div className="border border-muted/20 rounded p-4">
      <div className="text-xs text-muted">{label}</div>
      <div className="text-2xl font-semibold">{String(value)}</div>
    </div>
  );
}
