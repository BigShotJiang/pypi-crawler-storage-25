import { useQuery } from "@tanstack/react-query";
import { api } from "../api/client";
import { useProjectStore } from "../store/projectStore";

function StatusBadge({ status }: { status: string }) {
  const color =
    status === "active"
      ? "bg-green-500"
      : status === "completed"
        ? "bg-muted"
        : status === "completed_forced"
          ? "bg-gray-500"
          : "bg-amber-500";
  return (
    <span className={`px-2 py-0.5 text-xs rounded text-white ${color}`}>
      {status}
    </span>
  );
}

function SessionCard({ sid, agent, status, startedAt, endedAt }: {
  sid: string;
  agent: string;
  status: string;
  startedAt: string;
  endedAt: string | null;
}) {
  const backend = useProjectStore((s) => s.changeDetectionBackend);
  const { data: score } = useQuery({
    queryKey: ["harness-score", sid],
    queryFn: () => api.harness.score(sid),
    retry: false,
  });
  const { data: conflictsResp } = useQuery({
    queryKey: ["conflicts", sid],
    queryFn: () => api.sessions.conflicts(sid),
    retry: false,
  });

  const critical = score?.decision_density_status === "critical";
  const hasConflict = Boolean(conflictsResp?.conflicts?.length);

  const borderColor = critical
    ? "border-l-red-500"
    : hasConflict
      ? "border-l-amber-500"
      : "border-l-transparent";

  return (
    <div
      className={`border border-muted/20 border-l-4 ${borderColor} rounded p-4 space-y-2`}
    >
      <div className="flex items-center gap-2">
        <StatusBadge status={status} />
        {backend === "file_watcher" && (
          <span className="px-2 py-0.5 text-xs rounded bg-amber-500 text-black">
            file watcher
          </span>
        )}
        {critical && (
          <span className="px-2 py-0.5 text-xs rounded bg-red-500 text-white">
            no decisions recorded
          </span>
        )}
        {hasConflict && (
          <span className="px-2 py-0.5 text-xs rounded bg-amber-500 text-black">
            conflict
          </span>
        )}
        <span className="ml-auto text-xs text-muted">
          {new Date(startedAt).toLocaleString()}
          {endedAt ? ` → ${new Date(endedAt).toLocaleTimeString()}` : ""}
        </span>
      </div>
      <div className="font-medium">{agent}</div>
      {score && (
        <div className="text-xs text-muted flex gap-3">
          <span>density: {score.decision_density.toFixed(2)}</span>
          <span>status: {score.harness_status}</span>
          <span>changes: {score.structural_changes}</span>
        </div>
      )}
      {hasConflict && (
        <div className="text-xs text-amber-400 italic">
          Overlaps with {conflictsResp?.conflicts.length} other session(s).
        </div>
      )}
    </div>
  );
}

export function SessionsView() {
  const { data: sessions = [] } = useQuery({
    queryKey: ["sessions"],
    queryFn: () => api.sessions.list(),
  });

  return (
    <div className="space-y-3">
      {sessions.map((s) => (
        <SessionCard
          key={s.id}
          sid={s.id}
          agent={s.agent_name}
          status={s.status}
          startedAt={s.started_at}
          endedAt={s.ended_at}
        />
      ))}
    </div>
  );
}
