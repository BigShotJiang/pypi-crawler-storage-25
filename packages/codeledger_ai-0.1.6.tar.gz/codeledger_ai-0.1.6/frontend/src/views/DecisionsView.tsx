import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { api } from "../api/client";
import { useProjectStore } from "../store/projectStore";

type StatusFilter = "all" | "unverified" | "pending" | "passed" | "failed";

export function DecisionsView() {
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [selected, setSelected] = useState<string | null>(null);
  const backend = useProjectStore((s) => s.changeDetectionBackend);

  const { data: decisions = [] } = useQuery({
    queryKey: ["decisions"],
    queryFn: () => api.decisions.list(),
  });

  const { data: trace } = useQuery({
    queryKey: ["decision-trace", selected],
    queryFn: () =>
      selected ? api.decisions.trace(selected) : Promise.resolve(null),
    enabled: Boolean(selected),
  });

  const { data: verifyStatus } = useQuery({
    queryKey: ["verify", selected],
    queryFn: () =>
      selected ? api.verify.status(selected) : Promise.resolve(null),
    enabled: Boolean(selected),
  });

  const visible = decisions.filter(
    (d) => statusFilter === "all" || d.status === statusFilter,
  );

  const statusColor = (status: string) =>
    ({
      passed: "bg-green-500",
      failed: "bg-red-500",
      pending: "bg-amber-500",
      unverified: "bg-muted",
    }[status] ?? "bg-muted");

  return (
    <div className="grid grid-cols-5 gap-4 h-full">
      <div className="col-span-2 space-y-3">
        <div className="flex gap-2">
          {(["all", "unverified", "pending", "passed", "failed"] as StatusFilter[]).map(
            (f) => (
              <button
                key={f}
                onClick={() => setStatusFilter(f)}
                className={`px-2 py-1 text-xs rounded ${
                  statusFilter === f
                    ? "bg-accent text-white"
                    : "border border-muted/30"
                }`}
              >
                {f}
              </button>
            ),
          )}
        </div>

        <div className="space-y-2">
          {visible.map((d) => (
            <button
              key={d.id}
              onClick={() => setSelected(d.id)}
              className={`w-full text-left border border-muted/20 rounded p-3 ${
                selected === d.id ? "border-accent" : ""
              }`}
            >
              <div className="flex items-center gap-2">
                <span
                  className={`w-2 h-2 rounded-full ${statusColor(d.status)}`}
                />
                <span className="font-medium">{d.title}</span>
              </div>
              <div className="text-xs text-muted mt-1">
                {d.tags?.join(", ")} ·{" "}
                {new Date(d.created_at).toLocaleDateString()}
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="col-span-3 space-y-3">
        {selected && trace ? (
          <>
            <h2 className="text-lg font-semibold">{trace.decision.title}</h2>
            <p className="text-sm text-muted">{trace.decision.description}</p>

            {verifyStatus && (
              <div
                className={`text-xs p-2 rounded ${
                  verifyStatus.verification_available
                    ? "bg-muted/10"
                    : "bg-amber-500/10 text-amber-300"
                }`}
              >
                {verifyStatus.verification_available
                  ? `Verification: ${verifyStatus.status}`
                  : verifyStatus.message ??
                    "CI verification unavailable (file watcher mode)."}
              </div>
            )}

            <h3 className="text-sm font-semibold mt-4">Change events</h3>
            {trace.change_events.map((e) => (
              <div
                key={e.change_event_id}
                className="border border-muted/20 rounded p-3"
              >
                <div className="flex justify-between text-xs text-muted">
                  <span>
                    {e.change_event_type === "git_commit"
                      ? `commit ${e.change_event_id}`
                      : `snapshot ${e.date}`}
                  </span>
                  <span>{e.ast_changes.length} AST changes</span>
                </div>
                <details className="mt-2">
                  <summary className="cursor-pointer text-xs">
                    Show AST changes
                  </summary>
                  <ul className="text-xs text-muted mt-1 space-y-1">
                    {e.ast_changes.map((a, i) => (
                      <li key={i} className="font-mono">
                        {String(a.change_type)} · {String(a.entity_name)} ·{" "}
                        {String(a.file_path)}
                      </li>
                    ))}
                  </ul>
                </details>
              </div>
            ))}
            <div className="text-xs text-muted italic">
              Backend: {backend}
            </div>
          </>
        ) : (
          <div className="text-muted">
            Select a decision to view its provenance.
          </div>
        )}
      </div>
    </div>
  );
}
