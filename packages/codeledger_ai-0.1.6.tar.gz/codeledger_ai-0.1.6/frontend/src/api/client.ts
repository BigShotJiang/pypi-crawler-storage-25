/**
 * Typed API client for the CodeLedger REST surface.
 *
 * The client pulls the bearer token from localStorage (populated at
 * login time) and falls back to same-origin cookies for the dashboard.
 * Every request funnels through `request()` so auth handling and error
 * shaping are uniform.
 */

export type Json = Record<string, unknown> | unknown[];

export interface ApiError extends Error {
  status: number;
  detail?: string;
}

const BASE = "";

function authHeaders(): Record<string, string> {
  const token = localStorage.getItem("cl.token");
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function request<T = Json>(
  path: string,
  opts: RequestInit = {},
): Promise<T> {
  const res = await fetch(BASE + path, {
    ...opts,
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
      ...authHeaders(),
      ...(opts.headers ?? {}),
    },
  });
  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    const err = new Error(`${res.status} ${res.statusText}: ${detail}`) as ApiError;
    err.status = res.status;
    err.detail = detail;
    throw err;
  }
  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

export interface Decision {
  id: string;
  title: string;
  description: string;
  tags: string[];
  status: string;
  created_at: string;
}

export interface Story {
  id: string;
  title: string;
  description: string;
  status: string;
  points: number | null;
  sprint_id: string | null;
}

export interface Session {
  id: string;
  agent_name: string;
  status: string;
  started_at: string;
  ended_at: string | null;
}

export interface SecurityStatus {
  change_detection_backend: "git" | "file_watcher";
  invariants: Array<{
    id: string;
    status: string;
    unlinked_commits?: number;
    unlinked_file_changes?: number;
    total_unlinked?: number;
  }>;
}

export interface HarnessScore {
  session_id: string;
  change_detection_backend: "git" | "file_watcher";
  structural_changes: number;
  decisions_recorded: number;
  decision_density: number;
  decision_density_status: "critical" | "low" | "adequate";
  harness_status: "passing" | "warning" | "failing";
  session_coverage_metric: number;
}

export interface VerifyStatus {
  decision_id?: string;
  status?: string;
  verification_available: boolean;
  change_detection_backend?: "git" | "file_watcher";
  message?: string;
}

export interface ProvenanceTree {
  decision: Decision;
  change_events: Array<{
    change_event_id: string;
    change_event_type: "git_commit" | "file_snapshot";
    label: string;
    date: string;
    ast_changes: Record<string, unknown>[];
  }>;
}

export const api = {
  decisions: {
    list: () => request<Decision[]>("/api/decisions"),
    read: (id: string) => request<Decision>(`/api/decisions/${id}`),
    create: (body: Partial<Decision>) =>
      request<Decision>("/api/decisions", {
        method: "POST",
        body: JSON.stringify(body),
      }),
    trace: (id: string) => request<ProvenanceTree>(`/api/provenance/forward/${id}`),
  },
  stories: {
    list: () => request<Story[]>("/api/stories"),
  },
  sessions: {
    list: () => request<Session[]>("/api/sessions"),
    replay: (id: string) =>
      request<{ event_count: number; timeline: Array<Record<string, unknown>> }>(
        `/api/sessions/${id}/replay`,
      ),
    conflicts: (id: string) =>
      request<{ conflicts: Array<Record<string, unknown>> }>(
        `/api/sessions/${id}/conflicts`,
      ),
  },
  context: {
    relevant: (body: { query?: string; file_path?: string; token_budget?: number }) =>
      request<{
        context_block: string;
        total_tokens_used: number;
        token_budget: number;
        included_items: Array<{ item_id: string; item_type: string; score: number; token_count: number }>;
        summarized_items: Array<{ item_id: string; item_type: string; score: number; token_count: number }>;
        excluded_summary: string;
      }>("/api/context/relevant", {
        method: "POST",
        body: JSON.stringify(body),
      }),
  },
  verify: {
    status: (id: string) => request<VerifyStatus>(`/api/verify/status/${id}`),
    unverified: () =>
      request<{ verification_available: boolean; decisions: Decision[] }>(
        "/api/verify/unverified",
      ),
  },
  harness: {
    score: (sid: string) => request<HarnessScore>(`/api/harness/score/${sid}`),
  },
  sprints: {
    list: () => request<unknown[]>("/api/sprints"),
    burndown: (id: string) =>
      request<{ total_points: number; done_points: number; remaining_points: number }>(
        `/api/sprints/${id}/burndown`,
      ),
    velocity: () =>
      request<{ series: Array<{ sprint_name: string; points_done: number }>; average_velocity: number }>(
        "/api/sprints/velocity",
      ),
  },
  security: {
    status: () => request<SecurityStatus>("/api/security/status"),
  },
  auth: {
    me: () =>
      request<{ id: string; email: string; name: string } | null>(
        "/api/auth/me",
      ).catch(() => null),
    logout: () => {
      localStorage.removeItem("cl.token");
    },
  },
};
