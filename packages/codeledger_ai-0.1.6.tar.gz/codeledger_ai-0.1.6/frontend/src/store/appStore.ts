import { create } from "zustand";

export type Tab =
  | "memory"
  | "decisions"
  | "sprint"
  | "sessions"
  | "explorer"
  | "provenance"
  | "mcp"
  | "settings";

export type Theme = "light" | "dark";

interface AppState {
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
  theme: Theme;
  toggleTheme: () => void;
}

const initialTheme: Theme =
  typeof window !== "undefined" &&
  window.matchMedia("(prefers-color-scheme: dark)").matches
    ? "dark"
    : "light";

export const useAppStore = create<AppState>((set, get) => ({
  activeTab: "memory",
  setActiveTab: (tab) => set({ activeTab: tab }),
  theme: initialTheme,
  toggleTheme: () => {
    const next = get().theme === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    set({ theme: next });
  },
}));
