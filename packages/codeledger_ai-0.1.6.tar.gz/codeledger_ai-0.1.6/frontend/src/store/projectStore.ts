import { create } from "zustand";

export type ChangeDetectionBackend = "git" | "file_watcher";

interface ProjectState {
  activeProjectId: string;
  changeDetectionBackend: ChangeDetectionBackend;
  setActiveProjectId: (id: string) => void;
  setBackend: (b: ChangeDetectionBackend) => void;
}

export const useProjectStore = create<ProjectState>((set) => ({
  activeProjectId: "default",
  changeDetectionBackend: "git",
  setActiveProjectId: (id) => set({ activeProjectId: id }),
  setBackend: (b) => set({ changeDetectionBackend: b }),
}));
