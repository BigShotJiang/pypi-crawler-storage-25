import { useEffect } from "react";
import { useAppStore, Tab } from "../store/appStore";
import { useProjectStore } from "../store/projectStore";
import { useQuery } from "@tanstack/react-query";
import { api } from "../api/client";

const TABS: Array<{ id: Tab; label: string }> = [
  { id: "memory", label: "Memory" },
  { id: "decisions", label: "Decisions" },
  { id: "sprint", label: "Sprint" },
  { id: "sessions", label: "Sessions" },
  { id: "explorer", label: "Explorer" },
  { id: "provenance", label: "Provenance" },
  { id: "mcp", label: "MCP Servers" },
  { id: "settings", label: "Settings" },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const { activeTab, setActiveTab, theme, toggleTheme } = useAppStore();
  const { activeProjectId, changeDetectionBackend, setBackend } =
    useProjectStore();

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  // Pick up the change-detection backend from the security status panel.
  const { data: securityStatus } = useQuery({
    queryKey: ["security-status"],
    queryFn: () => api.security.status(),
    retry: false,
  });
  useEffect(() => {
    if (securityStatus?.change_detection_backend) {
      setBackend(securityStatus.change_detection_backend);
    }
  }, [securityStatus, setBackend]);

  const backendBadge =
    changeDetectionBackend === "git"
      ? "bg-blue-600 text-white"
      : "bg-amber-500 text-black";

  return (
    <div className="min-h-screen flex flex-col">
      <header className="flex items-center gap-4 px-6 py-3 border-b border-muted/20">
        <h1 className="text-lg font-semibold">CodeLedger</h1>
        <span className="text-sm text-muted">{activeProjectId}</span>
        <span
          className={`text-xs rounded px-2 py-0.5 ${backendBadge}`}
          title="Change detection backend"
        >
          {changeDetectionBackend}
        </span>
        <div className="flex-1" />
        <button
          onClick={toggleTheme}
          className="text-sm rounded border border-muted/30 px-2 py-1 hover:bg-muted/10"
        >
          {theme === "dark" ? "Light" : "Dark"}
        </button>
      </header>
      <nav className="flex gap-1 px-6 py-2 border-b border-muted/20 overflow-x-auto">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            className={`px-3 py-1.5 text-sm rounded ${
              activeTab === t.id
                ? "bg-accent text-white"
                : "hover:bg-muted/10 text-muted"
            }`}
          >
            {t.label}
          </button>
        ))}
      </nav>
      <main className="flex-1 p-6 overflow-auto">{children}</main>
    </div>
  );
}
