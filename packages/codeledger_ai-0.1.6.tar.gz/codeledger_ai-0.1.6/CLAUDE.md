# CLAUDE.md — CodeLedger

## Project Overview

CodeLedger is a verified context infrastructure for AI-assisted development. It is an MCP server with a React dashboard that gives AI coding agents persistent, intelligent memory at the project level.

Core capabilities: embedding-based semantic retrieval, AST-level decision provenance, token-budget-aware context injection, multi-agent conflict detection, independent code quality harness, architectural drift detection, tautological test detection, context-aware rollback, cross-project knowledge transfer, and agent capability profiling.

CodeLedger connects to Claude Code, Cursor, Windsurf, and any MCP-compatible tool via the Model Context Protocol. It operates in both git-managed and non-git project directories.

## Stack

Backend: Python 3.11+, FastAPI, FastMCP (mounted at `/mcp`).
Frontend: React 18, Vite, TypeScript, Apache ECharts, Zustand.
Storage: SQLite default with PostgreSQL optional. Vector search via sqlite-vss (SQLite mode) or pgvector (PG mode).
Embeddings: `nomic-embed-text` via Ollama on CPU. No GPU required.
AST parsing: tree-sitter with grammars for Python, TypeScript, JavaScript, Go, Rust, Java, C, C++, Ruby, C#.
Auth: OAuth 2.0 (Google, GitHub, plus configurable providers), email/password with Argon2id hashing, JWT sessions, personal access tokens for MCP clients.
Credential vault: OS keyring primary, AES-256-GCM encrypted file fallback, environment variables for CI.
Change detection: git post-commit hooks (git projects) or watchdog file watcher (non-git projects). Both backends produce identical ASTChange and ProvenanceEdge records via the change_event abstraction.
Served via nginx, managed by systemd.

## Repository Structure

```
codeledger/
├── CLAUDE.md
├── README.md
├── LICENSE                          # Apache 2.0
├── pyproject.toml
├── codeledger.toml.example          # example config, no secrets
├── providers.toml                   # OAuth provider registry
│
├── backend/
│   ├── __init__.py
│   ├── main.py                      # FastAPI app + FastMCP mount
│   ├── config.py                    # typed config from codeledger.toml
│   ├── models.py                    # dataclasses: Decision, Story, Session, ASTChange, etc.
│   │
│   ├── auth/
│   │   ├── __init__.py
│   │   ├── auth_service.py          # registration, login, JWT issuance
│   │   ├── auth_middleware.py       # request auth validation
│   │   ├── oauth_manager.py         # OAuth flows: browser, device, PKCE
│   │   └── credential_manager.py    # vault: keyring, AES-256-GCM, env
│   │
│   ├── db/
│   │   ├── __init__.py
│   │   ├── db_backend.py            # abstract interface + SQLite/PG impls
│   │   ├── migrations.py            # idempotent schema creation
│   │   └── vector_store.py          # sqlite-vss / pgvector abstraction
│   │
│   ├── intelligence/
│   │   ├── __init__.py
│   │   ├── embedder.py              # Ollama embedding client, batching
│   │   ├── semantic_search.py       # embed query → cosine rank → results
│   │   ├── context_triage.py        # token budget pruning + summarization
│   │   ├── ast_tracker.py           # diff/snapshot → tree-sitter → structural changes
│   │   └── tree_sitter_langs.py     # language registry, grammar loading
│   │
│   ├── verification/
│   │   ├── __init__.py
│   │   ├── verifier.py              # CI webhook → decision pass/fail (git mode only)
│   │   ├── harness.py               # independent quality sensors
│   │   ├── conflict_detector.py     # real-time multi-agent file overlap
│   │   └── provenance.py            # decision → change_event → AST graph queries
│   │
│   ├── advanced/
│   │   ├── __init__.py
│   │   ├── drift_detector.py        # architecture decisions vs import/call graph
│   │   ├── tautology_detector.py    # tests vs acceptance criteria mismatch
│   │   ├── rollback_planner.py      # decision dependency graph + impact analysis
│   │   ├── knowledge_packs.py       # export/import verified decision bundles
│   │   └── agent_profiler.py        # per-agent, per-domain capability stats
│   │
│   ├── mcp/
│   │   ├── __init__.py
│   │   ├── mcp_server.py            # FastMCP tool definitions
│   │   └── tool_handlers.py         # business logic behind each MCP tool
│   │
│   ├── api/
│   │   ├── __init__.py
│   │   └── routes.py                # REST endpoints shared by dashboard + MCP
│   │
│   └── utils/
│       ├── __init__.py
│       ├── log_sanitizer.py         # credential redaction on all log output
│       ├── token_counter.py         # tiktoken wrapper for budget calculations
│       ├── git_hooks.py             # git hook installer, callback handler, AST-aware unlinked commit detection
│       ├── file_watcher.py          # watchdog-based file change detection for non-git projects
│       ├── snapshot_store.py        # file content snapshots for non-git diff generation
│       └── project_claude_md.py     # CLAUDE.md template generator for user projects
│
├── frontend/
│   ├── package.json
│   ├── vite.config.ts
│   ├── tsconfig.json
│   ├── index.html
│   └── src/
│       ├── App.tsx
│       ├── main.tsx
│       ├── store/                   # Zustand stores
│       ├── api/                     # API client functions
│       ├── components/              # shared components
│       └── views/
│           ├── MemoryView.tsx       # semantic search + token budget viz
│           ├── DecisionsView.tsx    # decision list + provenance trace panel
│           ├── SprintView.tsx       # kanban + burndown + velocity
│           ├── SessionsView.tsx     # active sessions + conflict indicators
│           ├── ExplorerView.tsx     # 2D UMAP projection of context embeddings
│           ├── ProvenanceView.tsx   # decision → change event → AST graph
│           ├── MCPServersView.tsx   # connection management + custom MCP setup
│           └── SettingsView.tsx     # auth, PATs, provider config, SEC status
│
├── tests/
│   ├── conftest.py
│   ├── security/
│   │   ├── test_no_creds_in_db.py
│   │   ├── test_no_creds_in_logs.py
│   │   ├── test_auth_enforcement.py
│   │   ├── test_pat_hashing.py
│   │   ├── test_oauth_state.py
│   │   ├── test_pkce.py
│   │   └── test_file_permissions.py
│   ├── unit/
│   │   ├── test_config.py
│   │   ├── test_models.py
│   │   ├── test_credential_manager.py
│   │   ├── test_db_backend.py
│   │   ├── test_embedder.py
│   │   ├── test_semantic_search.py
│   │   ├── test_context_triage.py
│   │   ├── test_ast_tracker.py
│   │   ├── test_verifier.py
│   │   ├── test_conflict_detector.py
│   │   ├── test_provenance.py
│   │   ├── test_project_claude_md.py
│   │   ├── test_snapshot_store.py
│   │   └── test_file_watcher.py
│   ├── integration/
│   │   ├── test_mcp_tools.py
│   │   ├── test_oauth_flow.py
│   │   ├── test_device_auth_flow.py
│   │   ├── test_git_hook_pipeline.py
│   │   ├── test_file_watcher_pipeline.py
│   │   └── test_embedding_pipeline.py
│   └── e2e/
│       ├── test_full_decision_lifecycle.py
│       ├── test_full_decision_lifecycle_no_git.py
│       └── test_multi_agent_conflict.py
│
├── scripts/
│   ├── install_hooks.sh
│   └── generate_test_data.py
│
└── docs/
    ├── SECURITY.md
    ├── ARCHITECTURE.md
    └── API.md
```

## Code Standards

All Python follows PEP 8 with type hints on every function signature. No `Any` type unless unavoidable, with a documented justification in a comment at the usage site.

Every function has a single clear responsibility. If a function does two things, split it into two functions.

Every module starts with a module-level docstring that states the module's purpose and lists the security invariants it enforces.

Inline comments appear only where the logic is non-obvious. No comment noise. No `TODO` without a linked issue number.

Error handling wraps every external call — database queries, HTTP requests, file I/O, keyring operations, Ollama API calls, watchdog events. No exception propagates unhandled to the user. Catch specific exceptions, not bare `except`.

No happy-path-only code. Every function accounts for: empty input, missing files, network failures, permission errors, malformed data, concurrent access.

No placeholder logic, no stub functions, no "implement later" patterns. Every function is complete and tested when it enters the codebase.

Readability takes priority over performance unless the function sits on a measured hot path documented with profiling data.

Frontend TypeScript uses strict mode. No `any` type. Functional components with hooks. Zustand for all state management. No inline styles — Tailwind utility classes only.

## Security Invariants

These are not guidelines. They are invariants enforced by automated tests and verified at every phase gate. A violation of any invariant is a critical bug that blocks the phase.

**SEC-01: No credentials in the database.** No token, API key, secret, password, or signing key may exist in any SQLite or PostgreSQL table in any column. Only one-way hashes are permitted (password_hash using Argon2id, pat_hash using SHA-256). The test suite scans every table and column after each phase to verify this invariant.

**SEC-02: No credentials in logs.** Every log statement passes through `log_sanitizer.py` which redacts strings matching known credential patterns (Bearer tokens, API keys, JWTs, OAuth tokens, passwords). The test suite captures all log output during integration tests and asserts zero credential leakage.

**SEC-03: No credentials in MCP tool responses.** MCP tools that call connected services use credentials internally but never return them in responses. The test suite inspects every MCP tool response schema and asserts no field can carry a secret.

**SEC-04: No plaintext credentials on disk.** Outside the OS keyring (which has its own encryption), every secret on disk is encrypted with AES-256-GCM. The file vault uses PBKDF2 key derivation (600,000 iterations, random salt). The config file (`codeledger.toml`) stores only env var names that reference secrets, never secret values.

**SEC-05: Authentication on every endpoint.** Every HTTP endpoint and every MCP tool call requires a valid JWT session token, bearer PAT, or local solo-mode token. No endpoint is publicly accessible. The test suite calls every registered route without auth and asserts 401 on all of them. Exception: `/api/hooks/post-commit` and `/api/hooks/file-change` are authenticated via per-provider webhook secret stored in the credential vault, not bearer token.

**SEC-06: OAuth state and PKCE enforced.** Every OAuth flow generates a cryptographically random `state` parameter validated on callback (CSRF protection) and a PKCE code verifier with S256 challenge method. Tests verify both parameters are generated, transmitted, and validated.

**SEC-07: Password hashing uses Argon2id.** Memory cost 64 MB, time cost 3 iterations, parallelism 4. No bcrypt, no SHA-256 for passwords. Argon2id is the only permitted password hash algorithm.

**SEC-08: JWT signing key in vault only.** The HMAC-SHA256 key used to sign JWTs lives exclusively in the credential vault. It is loaded into memory at server startup and never written to any other location.

**SEC-09: File permissions validated.** Config files, vault files, and SQLite database files must not be world-readable (no `o+r` on POSIX). The server refuses to start if permissions are too open.

**SEC-10: PATs are hashed before storage.** Personal access tokens are SHA-256 hashed before insertion into the `personal_access_tokens` table. The plaintext token exists only in the credential vault and in the user's MCP client config. Validation compares incoming hash against stored hash.

**SEC-11: No structural change without an audit record.** Every change detection event (git post-commit hook or file watcher) that detects structural AST changes must produce either a linked decision or an `unlinked_commit` record (git backend) or `unlinked_file_change` record (file watcher backend). Silent structural changes — where change detection fired but produced neither — are a harness violation. The test suite verifies this for both backends independently.

## Change Detection Backends

CodeLedger detects structural code changes through two backends, selected automatically at `codeledger init` time based on whether a `.git/` directory exists. Both backends produce identical `ASTChange` and `ProvenanceEdge` records through the change_event abstraction.

**Git backend (default when `.git/` exists):**
Post-commit hook calls `/api/hooks/post-commit` with the commit hash and unified diff. The `commit_hash` anchors all provenance records. CI webhooks reference the same commit hash to transition verification status. Full provenance, verification, drift detection, and rollback planning are available.

**File watcher backend (used when no `.git/` exists):**
`watchdog` monitors the project directory for source file modifications. On each modification, `snapshot_store.py` captures before and after file content, generates a synthetic unified diff, and calls `/api/hooks/file-change` with the snapshot IDs. A `change_event_id` (prefixed `snap_`) replaces the commit hash in all provenance records. File snapshots are stored in the `file_snapshots` database table. CI verification is unavailable in this mode — `verify.status` and `verify.list_unverified` return `mode: "file_watcher"` with an explanatory message. All other capabilities (memory, decisions, harness, drift, tautology, rollback, knowledge packs, agent profiling) are fully available. The dashboard shows snapshot timestamps instead of commit hashes in the provenance panel and labels the session with a `file watcher` badge.

**Change event abstraction:**
`ASTChange` and `ProvenanceEdge` use `change_event_id: str` and `change_event_type: Literal["git_commit", "file_snapshot"]` instead of a bare `commit_hash`. All Phase 2–6 modules (`ast_tracker`, `provenance`, `rollback_planner`, `harness`, `drift_detector`) operate identically regardless of backend. The dashboard renders the change event type-appropriate label automatically.

**Upgrading from file watcher to git backend:**
If a user runs `git init` on a previously non-git project, running `codeledger init --reinstall-hooks` installs the git hooks and updates `change_detection_backend = "git"` in `codeledger.toml`. Existing `file_snapshot` provenance records are preserved and remain queryable. New commits will use the git backend going forward.

## Authentication Architecture

CodeLedger supports two operating modes:

**Solo mode** is for single-developer use on a local machine. A bearer token is generated at `codeledger init` time, stored in the credential vault at `~/.codeledger/`, and validated via SHA-256 hash comparison on each request. No login page, no session management, no database user table.

**Team mode** is for multi-developer use on a shared server. Users sign in via Google OAuth (OIDC), GitHub OAuth, or email/password. CodeLedger issues its own JWT session tokens (HttpOnly, Secure, SameSite=Strict cookies for the dashboard; bearer tokens for MCP clients). User records are stored in the database. OAuth identity tokens from Google/GitHub are consumed during validation and immediately discarded — CodeLedger stores no provider tokens for identity purposes.

**MCP client authentication** works without a browser via three mechanisms. (1) Device authorization flow. (2) Pre-generated PAT. (3) Environment variable `CODELEDGER_TOKEN` for CI/Docker.

**Service connections** use a separate OAuth flow per user per service. Access tokens live in memory only. Refresh tokens live in the credential vault. Connection metadata lives in the database.

## Credential Storage Map

**Database:** User profiles. Password hashes (Argon2id). PAT hashes (SHA-256). Service connection metadata. All application data including file snapshots and AST changes. Zero tokens, zero keys, zero secrets.

**Credential vault:** JWT signing key. OAuth refresh tokens. API keys. OAuth client secrets. Solo-mode bearer token. Webhook secrets (per CI provider).

**Memory only:** OAuth access tokens. Active JWT session tokens. OAuth state parameters and PKCE verifiers. Vault decryption key.

**Never stored anywhere:** User plaintext passwords. Google/GitHub identity tokens. OAuth authorization codes.

## Provider Registry

`providers.toml` ships with pre-configured OAuth entries for Google, GitHub, GitLab, Atlassian (Jira/Confluence), Slack, Linear, and Notion. Custom providers can be added by appending entries or via the dashboard. The provider registry reloads without server restart.

## Build Phases

Development proceeds in six phases. Each phase has a strict gate: all tests pass, all security invariants verified, manual code review completed, no regressions in prior phases. No phase begins until the previous phase gate clears.

---

### Phase 1 — Foundation

**Scope:** Configuration, data model, credential vault, authentication, database abstraction, MCP skeleton with CRUD tools, CLI, change detection (git hooks + file watcher), project CLAUDE.md template generator.

**Modules built:**
`config.py`, `models.py`, `credential_manager.py`, `oauth_manager.py`, `auth_service.py`, `auth_middleware.py`, `log_sanitizer.py`, `db_backend.py`, `migrations.py`, `mcp_server.py` (CRUD tools only), `tool_handlers.py` (CRUD only), `routes.py` (CRUD only), `cli.py` (init, serve, login, token set/revoke, connect), `git_hooks.py`, `file_watcher.py`, `snapshot_store.py`, `providers.toml`, `project_claude_md.py`.

**Key model design — change event abstraction:**
`ASTChange` uses `change_event_id: str` and `change_event_type: Literal["git_commit", "file_snapshot"]` instead of `commit_hash`. `ProvenanceEdge` uses the same fields. `UnlinkedCommit` covers git backend gaps. `UnlinkedFileChange` covers file watcher backend gaps. Both surface identically in harness scoring and the SEC-11 audit panel.

**MCP tools delivered:** `context.create`, `context.read`, `context.update`, `context.delete`, `context.list`, `decision.create`, `decision.read`, `decision.list`, `story.create`, `story.read`, `story.update`, `story.list`, `sprint.create`, `sprint.status`, `session.start`, `session.end` (enforced: checks for unlinked file modifications before closing, returns structured warning with unlinked file list; accepts `force: true` with `override_reason` to complete anyway), `session.list`, `standup.generate`.

**Tests required:**
All unit tests for the modules listed above, including `test_project_claude_md.py`, `test_snapshot_store.py`, `test_file_watcher.py`. Full security test suite (SEC-01 through SEC-11). Integration tests: `test_mcp_tools` (all CRUD tools), `test_oauth_flow`, `test_device_auth_flow`, `test_git_hook_pipeline` (structural commit without session → `UnlinkedCommit` record), `test_file_watcher_pipeline` (structural file save in non-git directory → `UnlinkedFileChange` record).

**Phase gate criteria:**
All SEC-01 through SEC-11 pass. Every MCP tool returns correct results with valid auth and 401 without auth. Solo mode and team mode both functional. `codeledger init` in a git repo installs post-commit hook and sets `change_detection_backend = "git"`. `codeledger init` in a non-git directory registers file watcher, sets `change_detection_backend = "file_watcher"`, and prints advisory. `codeledger init` generates `CLAUDE.md` in project root with all five required sections. `session.end` returns `completed_with_warnings` with unlinked file list when modified files have no linked decision. Git post-commit hook produces `ASTChange` records and `UnlinkedCommit` records when no decision is linked. File watcher produces `ASTChange` records and `UnlinkedFileChange` records when no decision is linked. Both backends produce structurally identical `ASTChange` records for the same source change. SQLite and PostgreSQL backends pass the full test suite.

---

### Phase 2 — Intelligence

**Scope:** Embedding pipeline, vector store, semantic retrieval, AST parsing, context triage with token budgeting.

**Modules built:** `embedder.py`, `vector_store.py`, `semantic_search.py`, `context_triage.py`, `ast_tracker.py`, `tree_sitter_langs.py`, `token_counter.py`.

**Note:** `ast_tracker.parse_diff(diff_text, file_path)` accepts a unified diff string regardless of source — git diff or snapshot-generated diff. `ast_tracker.process_change_event(change_event_id, change_event_type, diff_text, project_id)` is the unified entry point called by both `/api/hooks/post-commit` and `/api/hooks/file-change`. This replaces the prior `process_commit` signature.

**MCP tools added:** `context.get_relevant`, `context.get_for_file`, `decision.trace`, `decision.reverse_trace`.

**Tests required:** Unit tests for all modules. `test_embedding_pipeline`. `test_ast_tracker` — tests both git diff input and snapshot-generated diff input, verifying identical `ASTChange` records produced for the same logical change. `test_context_triage`. `test_semantic_search`. Regression: full Phase 1 test suite passes.

**Phase gate criteria:** Embedding pipeline produces consistent vectors. Semantic search returns relevant results in top-3 for known test cases. AST tracker correctly identifies structural changes across all 10 supported languages from both diff sources. Context triage respects token budgets within 5% tolerance. All Phase 1 security invariants hold. No credentials in vector store tables.

---

### Phase 3 — Verification and Multi-Agent

**Scope:** CI webhook verification, agent harness (independent quality sensors including decision density), conflict detection, session replay, provenance graph queries.

**Modules built:** `verifier.py`, `harness.py` (adds `decision_density` sensor: decisions per structural AST change over project lifetime — a score of 0.0 is a valid harness finding that produces `harness_status: "failing"`, not a passing state), `conflict_detector.py`, `provenance.py`. Session replay added to `tool_handlers.py`.

**Note on verification modes:** `verifier.py` requires a `commit_hash` from a CI webhook to transition decision status. Projects using the file watcher backend cannot use CI-linked verification. `verify.status` and `verify.list_unverified` return `change_detection_backend: "file_watcher"` and `verification_available: false` with an explanatory message. All harness sensors remain available.

**MCP tools added:** `verify.status`, `verify.list_unverified`, `session.replay`, `session.conflicts`, `provenance.forward`, `provenance.reverse`, `harness.score` (includes `decision_density`, `decision_density_status`, `session_coverage_metric`, and `change_detection_backend` fields).

**Tests required:** Unit tests for all modules. `test_verifier`. `test_conflict_detector`. `test_session_replay`. `test_provenance` — covers both `change_event_type: "git_commit"` and `change_event_type: "file_snapshot"` forward and reverse trace paths. `test_harness` — `decision_density` of 0.0 with structural changes returns `critical` and `harness_status: "failing"`. E2E tests: `test_full_decision_lifecycle.py` (git), `test_full_decision_lifecycle_no_git.py` (file watcher, snapshot-based provenance). Regression: Phase 1 + Phase 2 pass.

**Phase gate criteria:** CI webhook transitions decision status in git mode. File watcher mode returns `verification_available: false` without crashing. Conflict detector identifies file overlap within 100ms. Session replay timeline includes both event types. Provenance graph traces both event types correctly. Decision density 0.0 → `critical` → `harness_status: "failing"`. Session coverage metric queryable. All security invariants hold.

---

### Phase 4 — Dashboard and Sprint Intelligence

**Scope:** React dashboard with all views, REST API endpoints, sprint intelligence, MCP server management UI, auth/settings UI.

**Views built:** MemoryView, DecisionsView, SprintView, SessionsView (shows `file watcher` badge for non-git sessions; red `no decisions recorded` badge when `decision_density_status: "critical"`), ExplorerView, ProvenanceView (renders `commit hash` label for git events and `snapshot [timestamp]` label for file snapshot events in change nodes), MCPServersView, SettingsView (SEC-01 through SEC-11 live status panel; SEC-11 row shows combined count of `UnlinkedCommit` + `UnlinkedFileChange` records; project change detection mode badge: `git` or `file watcher`).

**MCP tools added:** `sprint.burndown`, `sprint.velocity`, `sprint.retrospective`.

**Tests required:** Frontend component tests. API endpoint tests. Sprint intelligence tests. Full regression. Accessibility checks (axe-core).

**Phase gate criteria:** Dashboard loads all views without errors. ProvenanceView renders correctly for both git and file-snapshot provenance data. SessionsView correctly shows mode badge. All security invariants hold.

---

### Phase 5 — Advanced Intelligence

**Scope:** Architectural drift detection, tautological test detection, context-aware rollback planning, persona-aware retrieval strategies.

**Modules built:** `drift_detector.py`, `tautology_detector.py`, `rollback_planner.py`. Persona system added to `semantic_search.py` and `context_triage.py`.

**Note:** `rollback_planner.plan_rollback` returns `affected_change_events` (list of objects with `change_event_id` and `change_event_type`) rather than `affected_commits`. In file watcher mode, the plan lists the file snapshots to revert rather than commits. The risk assessment logic is identical.

**MCP tools added:** `drift.check`, `drift.report`, `test.check_tautology`, `rollback.plan`, `context.get_relevant` updated with `persona` parameter.

**Phase gate criteria:** All as previously specified. Rollback planner correctly handles both `git_commit` and `file_snapshot` change event types in the impact graph.

---

### Phase 6 — Ecosystem

**Scope:** Cross-project knowledge packs, agent capability profiling, open-source packaging, documentation, 50+ MCP tools.

**Modules built:** `knowledge_packs.py`, `agent_profiler.py`. Expanded tool surface.

**Documentation requirements:** `docs/ARCHITECTURE.md` must document both change detection backends — initialization, data flow, the `change_event_id` abstraction, and limitations (CI verification requires git). `docs/API.md` must note which MCP tools return degraded responses in file watcher mode.

**Phase gate criteria:** All as previously specified. `codeledger init` verified in both a git repo and a plain directory. Documentation accurately describes both backends.

---

## QA Process — Applied After Every Phase

**Step 1: Static analysis.** `ruff check .` — zero warnings. `mypy --strict backend/` — zero errors.

**Step 2: Security test suite.** `pytest tests/security/ -v` — all pass. Enforces SEC-01 through SEC-11.

**Step 3: Unit tests.** `pytest tests/unit/ -v --cov=backend --cov-report=term-missing` — all pass, coverage ≥ 90% for current phase modules.

**Step 4: Integration tests.** `pytest tests/integration/ -v` — all pass.

**Step 5: E2E tests (Phase 3+).** `pytest tests/e2e/ -v` — all pass.

**Step 6: Regression.** `pytest tests/ -v` — zero failures.

**Step 7: Manual review.** Every file changed in this phase. Check: hardcoded secrets, broad exception handling, missing type hints, multi-responsibility functions, dead code, unnecessary dependencies.

**Step 8: Dependency audit.** `pip-audit` — zero known vulnerabilities.

## Dependencies

Backend Python packages (pinned in pyproject.toml):

`fastapi`, `uvicorn`, `fastmcp`, `aiosqlite`, `asyncpg`, `sqlite-vss`, `pgvector`, `ollama`, `tree-sitter`, `tree-sitter-languages`, `tiktoken`, `click`, `keyring`, `cryptography`, `PyJWT`, `argon2-cffi`, `httpx`, `watchdog` (cross-platform filesystem event monitoring for non-git change detection).

Dev dependencies: `ruff`, `mypy`, `pytest`, `pytest-asyncio`, `pytest-cov`, `pip-audit`.

Frontend packages (pinned in package.json): `react`, `react-dom`, `vite`, `typescript`, `zustand`, `echarts`, `echarts-for-react`, `tailwindcss`, `@tanstack/react-query`, `vitest`.

## Environment Variables

`CODELEDGER_CONFIG` — path to codeledger.toml (default: `./codeledger.toml`).
`CODELEDGER_TOKEN` — bearer token for MCP client auth in CI/Docker.
`CODELEDGER_PG_DSN` — PostgreSQL DSN (required only for postgresql backend).
`CODELEDGER_GOOGLE_CLIENT_ID`, `CODELEDGER_GOOGLE_CLIENT_SECRET` — Google OAuth.
`CODELEDGER_GITHUB_CLIENT_ID`, `CODELEDGER_GITHUB_CLIENT_SECRET` — GitHub OAuth.
`CODELEDGER_VAULT_PASSPHRASE` — file vault passphrase (bypasses interactive prompt).

## Distribution and Installation

**PyPI (`pip install codeledger-ai`):** Full backend + pre-built frontend assets + all dependencies. FastAPI serves the dashboard directly — no separate frontend server needed in solo mode.

**npm (`npx codeledger-ai`):** Thin Node wrapper that checks Python 3.11+, creates venv, installs PyPI package, delegates commands.

### Solo mode onboarding

```
pip install codeledger-ai
cd ~/my-project
codeledger init
codeledger serve &
codeledger connect
```

`codeledger init` behavior:
- Always: creates `codeledger.toml`, `~/.codeledger/` vault, bearer token, SQLite DB at `data/codeledger.db`, runs migrations, generates project `CLAUDE.md`.
- If `.git/` exists: installs git hooks, sets `change_detection_backend = "git"`.
- If no `.git/`: registers file watcher, sets `change_detection_backend = "file_watcher"`, prints advisory noting CI verification requires git and how to upgrade with `git init && codeledger init --reinstall-hooks`.

### Team mode onboarding

```
pip install codeledger-ai
codeledger init --mode team --port 8100
codeledger config set-credential google_client_id "<id>"
codeledger config set-credential google_client_secret "<secret>"
codeledger install-service
```

### CLI command reference

`codeledger init [--mode solo|team] [--port N] [--reinstall-hooks]`
`codeledger serve [--host H] [--port N] [--skip-frontend]`
`codeledger connect [--server URL]`
`codeledger login [--server URL]`
`codeledger token set <token>`
`codeledger token revoke`
`codeledger token generate [--name N] [--expiry-days D]`
`codeledger config set-credential <key> <value>`
`codeledger install-service`
`codeledger mcp [--token T]`

## Conventions

Branch naming: `phase-{N}/{module-name}`.
Commit messages: imperative, 72 char limit, phase reference (e.g., `[P1] Add file watcher backend for non-git change detection`).
PR scope: one module per PR. Tightly coupled pairs (e.g., `file_watcher` + `snapshot_store`) may be combined.
Test files mirror source files.

## Repository: Private GitHub

Hosted at `git@github.com:deepsaini80537/codeledge.git`.

No secrets in the repository — ever. `.gitignore` excludes: `codeledger.toml`, `*.enc`, `data/`, `.env` files, `__pycache__/`, `node_modules/`, `dist/`, `*.pyc`. Only `codeledger.toml.example` and `providers.toml` are committed. `.gitignore` is the first file in the first commit.

GitHub settings: private visibility, branch protection on `main` (require PR review, require status checks, no force pushes, no deletions). Apache 2.0 LICENSE in first commit.
