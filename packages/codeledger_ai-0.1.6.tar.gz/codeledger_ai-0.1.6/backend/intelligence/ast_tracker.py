"""AST-level tracking of code changes from git diffs.

Given a unified diff and the file it describes, :class:`ASTTracker`
extracts structural changes (function / class / import additions,
removals, and signature changes) via tree-sitter and links them to
open decisions through :class:`ProvenanceEdge` records in the
database.

The linkage uses two signals described in PHASE_GUIDE:

* Temporal proximity — decisions recorded within the last 24 hours of
  the commit are candidates.
* File overlap — decisions whose ``title`` or ``description`` text
  mentions the changed file path (or a suffix of it) get a stronger
  link via the ``"touches"`` relationship; temporally-close decisions
  without a file mention get the weaker ``"temporally_related"`` label.

Security invariants enforced:
- SEC-01: Writes go to ``ast_changes`` and ``provenance_edges`` only,
  through the validated ``DatabaseBackend`` interface. No credential
  material is introduced.
- Language resolution is anchored on the extension map in
  ``tree_sitter_langs.py`` — the language name never comes from
  attacker-controlled input without validation.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any  # Any: tree_sitter Node attrs lack stubs

from backend.intelligence.tree_sitter_langs import (
    LanguageNotSupportedError,
    LanguageRegistry,
)
from backend.models import (
    ASTChange,
    ProvenanceEdge,
    UnlinkedCommit,
    UnlinkedFileChange,
)

if TYPE_CHECKING:
    from backend.db.db_backend import DatabaseBackend


# Per-language mapping of top-level tree-sitter node types to the
# CodeLedger entity kind they represent. Probed by walking the root
# node's children; nested definitions (e.g. methods in a class) are not
# traversed — top-level detection is sufficient for the current signal.
_LANGUAGE_NODE_MAP: dict[str, dict[str, tuple[str, ...]]] = {
    "python": {
        "function": ("function_definition",),
        "class": ("class_definition",),
        "import": ("import_statement", "import_from_statement"),
    },
    "typescript": {
        "function": ("function_declaration", "method_definition"),
        "class": ("class_declaration", "interface_declaration"),
        "import": ("import_statement",),
    },
    "javascript": {
        "function": ("function_declaration", "method_definition"),
        "class": ("class_declaration",),
        "import": ("import_statement",),
    },
    "go": {
        "function": ("function_declaration", "method_declaration"),
        "class": ("type_declaration",),
        "import": ("import_declaration",),
    },
    "rust": {
        "function": ("function_item",),
        "class": ("struct_item", "enum_item", "trait_item"),
        "import": ("use_declaration",),
    },
    "java": {
        "function": ("method_declaration", "constructor_declaration"),
        "class": (
            "class_declaration",
            "interface_declaration",
            "enum_declaration",
        ),
        "import": ("import_declaration",),
    },
    "c": {
        "function": ("function_definition",),
        "class": ("struct_specifier", "union_specifier"),
        "import": ("preproc_include",),
    },
    "cpp": {
        "function": ("function_definition",),
        "class": ("class_specifier", "struct_specifier"),
        "import": ("preproc_include", "using_declaration"),
    },
    "ruby": {
        "function": ("method",),
        "class": ("class", "module"),
        "import": (),
    },
    "csharp": {
        "function": ("method_declaration", "constructor_declaration"),
        "class": (
            "class_declaration",
            "interface_declaration",
            "struct_declaration",
        ),
        "import": ("using_directive",),
    },
}

# Cap signature text to a reasonable size so DB rows stay small even when
# a function's body has been folded into the signature (e.g. C one-liners).
_MAX_SIGNATURE_CHARS = 240

# Default window used when linking decisions to changes by temporal proximity.
_DEFAULT_LINK_WINDOW_HOURS = 24


class ASTTrackerError(Exception):
    """Raised for AST tracking failures and invalid input."""


@dataclass(frozen=True)
class Entity:
    """A single structural declaration parsed from source.

    Attributes:
        kind: ``"function"``, ``"class"``, or ``"import"``.
        name: The declared entity's identifier (first identifier child).
        signature: A short textual representation of the declaration —
            truncated at ``_MAX_SIGNATURE_CHARS``.
    """

    kind: str
    name: str
    signature: str

    @property
    def key(self) -> tuple[str, str]:
        """Dedup key used when comparing added vs removed entities."""
        return (self.kind, self.name)


class ASTTracker:
    """Parse diffs and commit structural changes to the database.

    Parameters:
        db: An already-connected :class:`DatabaseBackend` instance.
        registry: Optional :class:`LanguageRegistry`; a default is created
            when omitted.
        now: Optional clock callable returning the current UTC datetime;
            used for temporal-proximity linking and override-ed in tests.
    """

    def __init__(
        self,
        db: DatabaseBackend,
        registry: LanguageRegistry | None = None,
        *,
        now: Any = None,  # Any: callable returning datetime; signature optional
    ) -> None:
        self._db = db
        self._langs = registry or LanguageRegistry()
        self._now: Any = now if now is not None else _default_now

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def parse_file_content(self, content: str, file_path: str) -> list[Entity]:
        """Return all top-level entities in ``content`` for the given file.

        Raises:
            ASTTrackerError: ``content`` is not a string or the language
                cannot be detected.
        """
        if not isinstance(content, str):
            raise ASTTrackerError(
                f"content must be str, got {type(content).__name__}"
            )
        try:
            language = self._langs.detect_language(file_path)
        except LanguageNotSupportedError as exc:
            raise ASTTrackerError(str(exc)) from exc
        return self._extract_entities(content, language)

    def parse_diff(
        self, diff_text: str, file_path: str
    ) -> list[ASTChange]:
        """Extract structural changes from a unified diff.

        Added (``+``) and removed (``-``) lines are parsed separately as
        partial source snippets. Entities with the same ``(kind, name)``
        on both sides are reported as ``signature_changed`` when their
        signatures differ and ``function_modified`` / ``class_modified``
        / ``import_modified`` otherwise (import modifications are rare
        but possible when an import's from-clause is rewritten).

        Raises:
            ASTTrackerError: Invalid input or unsupported language.
        """
        if not isinstance(diff_text, str):
            raise ASTTrackerError(
                f"diff_text must be str, got {type(diff_text).__name__}"
            )
        try:
            language = self._langs.detect_language(file_path)
        except LanguageNotSupportedError as exc:
            raise ASTTrackerError(str(exc)) from exc

        added_text, removed_text = _split_diff(diff_text)
        added = self._extract_entities(added_text, language)
        removed = self._extract_entities(removed_text, language)

        added_by_key: dict[tuple[str, str], Entity] = {e.key: e for e in added}
        removed_by_key: dict[tuple[str, str], Entity] = {e.key: e for e in removed}

        changes: list[ASTChange] = []
        for key, new in added_by_key.items():
            if key in removed_by_key:
                old = removed_by_key[key]
                if new.signature == old.signature:
                    continue
                change_type = (
                    "signature_changed"
                    if new.kind == "function"
                    else f"{new.kind}_modified"
                )
                changes.append(
                    ASTChange(
                        file_path=file_path,
                        language=language,
                        change_type=change_type,
                        entity_name=new.name,
                        entity_type=new.kind,
                        old_signature=old.signature,
                        new_signature=new.signature,
                    )
                )
            else:
                changes.append(
                    ASTChange(
                        file_path=file_path,
                        language=language,
                        change_type=f"{new.kind}_added",
                        entity_name=new.name,
                        entity_type=new.kind,
                        new_signature=new.signature,
                    )
                )
        for key, old in removed_by_key.items():
            if key in added_by_key:
                continue
            changes.append(
                ASTChange(
                    file_path=file_path,
                    language=language,
                    change_type=f"{old.kind}_removed",
                    entity_name=old.name,
                    entity_type=old.kind,
                    old_signature=old.signature,
                )
            )
        return changes

    async def link_changes_to_decision(
        self,
        changes: list[ASTChange],
        commit_hash: str,
        project_id: str,
        *,
        session_id: str | None = None,
        window_hours: int = _DEFAULT_LINK_WINDOW_HOURS,
        change_event_id: str | None = None,
        change_event_type: str = "git_commit",
    ) -> list[ProvenanceEdge]:
        """Persist changes and create edges to candidate decisions.

        Decisions qualify as candidates when either:

        * they were recorded in ``session_id`` (strongest signal), or
        * their ``created_at`` falls within ``window_hours`` of now.

        A decision whose ``title`` or ``description`` mentions the
        change's file path gets a ``"touches"`` edge; other temporally
        close decisions get ``"temporally_related"``.

        ``change_event_id`` and ``change_event_type`` stamp the backend-
        neutral fields introduced in migration v3. When omitted,
        ``change_event_id`` defaults to ``commit_hash`` and
        ``change_event_type`` defaults to ``"git_commit"`` — matching
        the legacy git-only behavior.
        """
        if not isinstance(changes, list):
            raise ASTTrackerError(
                f"changes must be list, got {type(changes).__name__}"
            )
        if not isinstance(commit_hash, str) or not commit_hash:
            raise ASTTrackerError("commit_hash must be a non-empty string")
        if not isinstance(project_id, str) or not project_id:
            raise ASTTrackerError("project_id must be a non-empty string")
        if change_event_type not in ("git_commit", "file_snapshot"):
            raise ASTTrackerError(
                f"change_event_type must be 'git_commit' or 'file_snapshot', "
                f"got {change_event_type!r}"
            )
        resolved_event_id = change_event_id or commit_hash

        # Stamp commit + session + change-event abstraction on each change
        # and persist.
        for change in changes:
            change.commit_hash = commit_hash
            change.change_event_id = resolved_event_id
            change.change_event_type = change_event_type
            change.project_id = project_id
            if session_id:
                try:
                    change.session_id = uuid.UUID(session_id)
                except ValueError:
                    change.session_id = None
            try:
                await self._db.insert("ast_changes", change.to_dict())
            except Exception as exc:
                raise ASTTrackerError(
                    f"Failed to persist ASTChange for {change.file_path}: {exc}"
                ) from exc

        if not changes:
            return []

        candidates = await self._decision_candidates(
            session_id=session_id, window_hours=window_hours
        )
        if not candidates:
            return []

        edges: list[ProvenanceEdge] = []
        for change in changes:
            for decision in candidates:
                relationship = (
                    "touches"
                    if _decision_mentions_file(decision, change.file_path)
                    or (
                        session_id is not None
                        and str(decision.get("recorded_in_session_id"))
                        == session_id
                    )
                    else "temporally_related"
                )
                try:
                    source_id = uuid.UUID(str(decision["id"]))
                except (KeyError, ValueError):
                    continue
                edge = ProvenanceEdge(
                    source_type="decision",
                    source_id=source_id,
                    target_type="ast_change",
                    target_id=change.id,
                    relationship=relationship,
                )
                try:
                    await self._db.insert(
                        "provenance_edges", edge.to_dict()
                    )
                except Exception as exc:
                    raise ASTTrackerError(
                        f"Failed to persist ProvenanceEdge: {exc}"
                    ) from exc
                edges.append(edge)
        return edges

    async def process_commit(
        self,
        commit_hash: str,
        diff_text: str,
        project_id: str,
        *,
        session_id: str | None = None,
    ) -> tuple[list[ASTChange], list[ProvenanceEdge]]:
        """Backward-compatible wrapper around :meth:`process_change_event`.

        Kept so existing git-only callers don't need to migrate at once.
        Dispatches with ``change_event_type="git_commit"`` and
        ``change_event_id=commit_hash``.
        """
        if not isinstance(diff_text, str):
            raise ASTTrackerError(
                f"diff_text must be str, got {type(diff_text).__name__}"
            )

        per_file = _split_diff_per_file(diff_text)
        all_changes: list[ASTChange] = []
        for file_path, file_diff in per_file.items():
            try:
                self._langs.detect_language(file_path)
            except LanguageNotSupportedError:
                continue
            try:
                file_changes = self.parse_diff(file_diff, file_path)
            except ASTTrackerError:
                continue
            all_changes.extend(file_changes)

        edges = await self.link_changes_to_decision(
            all_changes,
            commit_hash=commit_hash,
            project_id=project_id,
            session_id=session_id,
            change_event_id=commit_hash,
            change_event_type="git_commit",
        )
        return all_changes, edges

    async def process_change_event(
        self,
        change_event_id: str,
        change_event_type: str,
        diff_text: str,
        project_id: str,
        *,
        active_session_id: str | None = None,
    ) -> dict[str, Any]:
        """Unified entry point for both the git hook and the file watcher.

        Parses ``diff_text`` per-file, persists :class:`ASTChange` rows
        with ``change_event_id`` and ``change_event_type`` stamped on them,
        then attempts to link them to an open decision. When no decision
        matches, an :class:`UnlinkedCommit` (for ``"git_commit"``) or
        :class:`UnlinkedFileChange` (for ``"file_snapshot"``) record is
        created so SEC-11 audits can surface the gap.

        Returns:
            ``{"linked_changes": [...], "unlinked_changes": [symbol, ...]}``
            where ``linked_changes`` is a list of entity names that ended
            up tied to a decision via a :class:`ProvenanceEdge`.

        Raises:
            ASTTrackerError: Invalid inputs or persistence failure.
        """
        if change_event_type not in ("git_commit", "file_snapshot"):
            raise ASTTrackerError(
                f"change_event_type must be 'git_commit' or 'file_snapshot', "
                f"got {change_event_type!r}"
            )
        if not isinstance(change_event_id, str) or not change_event_id:
            raise ASTTrackerError(
                "change_event_id must be a non-empty string"
            )
        if not isinstance(diff_text, str):
            raise ASTTrackerError(
                f"diff_text must be str, got {type(diff_text).__name__}"
            )
        if not isinstance(project_id, str) or not project_id:
            raise ASTTrackerError("project_id must be a non-empty string")

        per_file = _split_diff_per_file(diff_text)
        all_changes: list[ASTChange] = []
        for file_path, file_diff in per_file.items():
            try:
                self._langs.detect_language(file_path)
            except LanguageNotSupportedError:
                continue
            try:
                file_changes = self.parse_diff(file_diff, file_path)
            except ASTTrackerError:
                continue
            all_changes.extend(file_changes)

        # Legacy ``link_changes_to_decision`` still requires a commit_hash
        # argument. For file-snapshot events we reuse the change_event_id
        # so the ast_changes row is internally consistent.
        commit_hash_for_stamp = (
            change_event_id if change_event_type == "git_commit" else ""
        )
        # Commit_hash column is NOT NULL — keep the empty-string default
        # rather than sending None.
        edges = await self.link_changes_to_decision(
            all_changes,
            commit_hash=commit_hash_for_stamp or change_event_id,
            project_id=project_id,
            session_id=active_session_id,
            change_event_id=change_event_id,
            change_event_type=change_event_type,
        )

        linked_symbols = _unique_symbols(all_changes) if edges else []
        unlinked_symbols = (
            [] if edges else _unique_symbols(all_changes)
        )
        if unlinked_symbols:
            await self._record_unlinked(
                change_event_id=change_event_id,
                change_event_type=change_event_type,
                project_id=project_id,
                active_session_id=active_session_id,
                symbols=unlinked_symbols,
                all_changes=all_changes,
            )

        return {
            "linked_changes": linked_symbols,
            "unlinked_changes": unlinked_symbols,
        }

    async def _record_unlinked(
        self,
        *,
        change_event_id: str,
        change_event_type: str,
        project_id: str,
        active_session_id: str | None,
        symbols: list[str],
        all_changes: list[ASTChange],
    ) -> None:
        """Persist an :class:`UnlinkedCommit` or :class:`UnlinkedFileChange`."""
        session_uuid = _safe_uuid(active_session_id)
        if change_event_type == "git_commit":
            record = UnlinkedCommit(
                commit_hash=change_event_id,
                project_id=project_id,
                structurally_changed_symbols=symbols,
                session_id=session_uuid,
            )
            table = "unlinked_commits"
            payload = record.to_dict()
        else:
            file_path = all_changes[0].file_path if all_changes else ""
            record_file = UnlinkedFileChange(
                snapshot_id=change_event_id,
                file_path=file_path,
                project_id=project_id,
                structurally_changed_symbols=symbols,
                session_id=session_uuid,
            )
            table = "unlinked_file_changes"
            payload = record_file.to_dict()
        try:
            await self._db.insert(table, payload)
        except Exception as exc:
            raise ASTTrackerError(
                f"Failed to persist unlinked record for "
                f"{change_event_type} {change_event_id}: {exc}"
            ) from exc

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _extract_entities(
        self, source_text: str, language: str
    ) -> list[Entity]:
        """Parse ``source_text`` with tree-sitter and pull top-level entities."""
        if not source_text.strip():
            return []
        parser = self._langs.get_parser(language)
        try:
            tree = parser.parse(source_text.encode("utf-8", errors="replace"))
        except Exception as exc:
            raise ASTTrackerError(
                f"tree-sitter parse failed for {language}: {exc}"
            ) from exc

        node_map = _LANGUAGE_NODE_MAP.get(language, {})
        entities: list[Entity] = []
        seen: set[tuple[str, str, str]] = set()
        candidate_nodes = list(
            _top_level_nodes(tree.root_node, language)
        )
        for kind, node_types in node_map.items():
            for node in candidate_nodes:
                if node.type not in node_types:
                    continue
                name = _extract_name(node, source_text, language)
                if not name:
                    continue
                signature = _extract_signature(node, source_text, kind)
                dedup_key = (kind, name, signature)
                if dedup_key in seen:
                    continue
                seen.add(dedup_key)
                entities.append(
                    Entity(kind=kind, name=name, signature=signature)
                )

        # Ruby `require` imports are function calls, not a dedicated node —
        # handle as a special case.
        if language == "ruby":
            entities.extend(_extract_ruby_requires(tree.root_node, source_text))
        return entities

    async def _decision_candidates(
        self,
        *,
        session_id: str | None,
        window_hours: int,
    ) -> list[dict[str, Any]]:
        """Return decision rows eligible for linking."""
        try:
            rows = await self._db.query("decisions")
        except Exception as exc:
            raise ASTTrackerError(
                f"Failed to load decisions: {exc}"
            ) from exc

        cutoff = self._now() - timedelta(hours=window_hours)
        candidates: list[dict[str, Any]] = []
        for row in rows:
            if session_id is not None and str(
                row.get("recorded_in_session_id")
            ) == session_id:
                candidates.append(row)
                continue
            created_at_raw = row.get("created_at")
            if not isinstance(created_at_raw, str) or not created_at_raw:
                continue
            try:
                created_at = datetime.fromisoformat(created_at_raw)
            except ValueError:
                continue
            if created_at.tzinfo is None:
                created_at = created_at.replace(tzinfo=UTC)
            if created_at >= cutoff:
                candidates.append(row)
        return candidates


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _default_now() -> datetime:
    return datetime.now(UTC)


def _unique_symbols(changes: list[ASTChange]) -> list[str]:
    """Return a de-duplicated list of entity names across ``changes``."""
    seen: set[str] = set()
    ordered: list[str] = []
    for change in changes:
        name = change.entity_name
        if not name or name in seen:
            continue
        seen.add(name)
        ordered.append(name)
    return ordered


def _safe_uuid(raw: str | None) -> uuid.UUID | None:
    """Parse a UUID string safely; return None for missing or malformed input."""
    if not raw:
        return None
    try:
        return uuid.UUID(raw)
    except ValueError:
        return None


def _top_level_nodes(root: Any, language: str) -> list[Any]:
    """Return the effective top-level nodes, descending through wrappers.

    In TypeScript and JavaScript a top-level declaration may be wrapped
    in an ``export_statement``; in Rust an ``impl_item`` block houses
    ``function_item`` children; we treat the direct children of those
    wrappers as if they were top-level so entity extraction sees them.
    """
    results: list[Any] = []
    for node in root.children:
        if language in {"typescript", "javascript"} and node.type in {
            "export_statement",
            "export_default_declaration",
        }:
            results.extend(node.children)
            continue
        results.append(node)
    return results


def _split_diff(diff_text: str) -> tuple[str, str]:
    """Split a unified diff into (added_text, removed_text) strings.

    Only the payload lines are kept (the leading ``+`` / ``-`` marker is
    dropped). Headers (``+++``, ``---``, ``@@``) and context lines are
    ignored.
    """
    added: list[str] = []
    removed: list[str] = []
    for line in diff_text.splitlines():
        if line.startswith("+++") or line.startswith("---"):
            continue
        if line.startswith("@@"):
            continue
        if line.startswith("+"):
            added.append(line[1:])
        elif line.startswith("-"):
            removed.append(line[1:])
    return "\n".join(added), "\n".join(removed)


def _split_diff_per_file(diff_text: str) -> dict[str, str]:
    """Partition a multi-file unified diff into ``{file_path: file_diff}``.

    Uses the ``diff --git a/<path> b/<path>`` header that ``git diff``
    emits. Falls back to the ``+++ b/<path>`` line for diffs produced
    without the ``--git`` header.
    """
    per_file: dict[str, list[str]] = {}
    current_path: str | None = None
    for line in diff_text.splitlines():
        if line.startswith("diff --git "):
            parts = line.split(" ")
            # "diff --git a/foo b/foo"
            if len(parts) >= 4 and parts[3].startswith("b/"):
                current_path = parts[3][2:]
                per_file.setdefault(current_path, [])
            continue
        if line.startswith("+++ ") and current_path is None:
            target = line[4:].strip()
            if target.startswith("b/"):
                target = target[2:]
            if target != "/dev/null":
                current_path = target
                per_file.setdefault(current_path, [])
            continue
        if current_path is None:
            continue
        per_file[current_path].append(line)
    return {path: "\n".join(lines) for path, lines in per_file.items()}


def _extract_name(node: Any, source_text: str, language: str) -> str:
    """Return the primary identifier of a top-level declaration node."""
    name_field = node.child_by_field_name("name")
    if name_field is not None:
        return _node_text(name_field, source_text)

    # Language-specific fallbacks for nodes that lack a ``name`` field.
    if language == "python":
        for child in node.children:
            if child.type in ("identifier", "dotted_name"):
                return _node_text(child, source_text)
    if language == "c" or language == "cpp":
        # preproc_include: the `path` field holds "<header>" or "\"header\"".
        path_field = node.child_by_field_name("path")
        if path_field is not None:
            return _node_text(path_field, source_text).strip('"<>')
        # function_definition wraps a function_declarator which carries
        # the identifier under its own `declarator` field. Chain down.
        declarator = node.child_by_field_name("declarator")
        while declarator is not None:
            if declarator.type == "identifier":
                return _node_text(declarator, source_text)
            if declarator.type == "field_identifier":
                return _node_text(declarator, source_text)
            inner = declarator.child_by_field_name("declarator")
            if inner is None:
                break
            declarator = inner
    if language == "ruby":
        # class/module nodes: first constant child is the name.
        for child in node.children:
            if child.type in ("constant", "scope_resolution"):
                return _node_text(child, source_text)
    if language == "csharp":
        for child in node.children:
            if child.type == "qualified_name" or child.type == "identifier":
                return _node_text(child, source_text)
    if language == "go":
        for child in node.children:
            if child.type in (
                "import_spec",
                "import_spec_list",
                "type_spec",
                "interpreted_string_literal",
            ):
                return _node_text(child, source_text).strip('"')
    if language == "rust":
        for child in node.children:
            if child.type in ("identifier", "scoped_identifier"):
                return _node_text(child, source_text)

    # Final fallback: first identifier-ish child.
    for child in node.children:
        if "identifier" in child.type:
            return _node_text(child, source_text)
    return ""


def _extract_signature(node: Any, source_text: str, kind: str) -> str:
    """Produce a compact signature string from a declaration node."""
    if kind == "function":
        # Prefer the declaration without the body if the grammar splits it.
        for field_name in ("parameters", "type"):
            field_node = node.child_by_field_name(field_name)
            if field_node is not None:
                # Include everything up to and including the parameters.
                start = node.start_byte
                end = field_node.end_byte
                signature = source_text.encode("utf-8", errors="replace")[
                    start:end
                ].decode("utf-8", errors="replace")
                return _truncate(signature)
    # Default: use the full node text, truncated.
    return _truncate(_node_text(node, source_text))


def _node_text(node: Any, source_text: str) -> str:
    """Return the source slice corresponding to ``node`` as a string."""
    start = node.start_byte
    end = node.end_byte
    data = source_text.encode("utf-8", errors="replace")[start:end]
    return data.decode("utf-8", errors="replace")


def _truncate(text: str) -> str:
    """Clip text to ``_MAX_SIGNATURE_CHARS`` and strip trailing whitespace."""
    text = text.strip()
    if len(text) <= _MAX_SIGNATURE_CHARS:
        return text
    return text[:_MAX_SIGNATURE_CHARS] + "…"


def _extract_ruby_requires(
    root: Any, source_text: str
) -> list[Entity]:
    """Scan a Ruby AST for ``require`` / ``require_relative`` calls."""
    entities: list[Entity] = []
    for child in root.children:
        if child.type != "call":
            continue
        method_node = child.child_by_field_name("method")
        if method_node is None:
            continue
        method_name = _node_text(method_node, source_text)
        if method_name not in {"require", "require_relative"}:
            continue
        args_node = child.child_by_field_name("arguments")
        if args_node is None:
            continue
        name = _node_text(args_node, source_text).strip('()"\' ')
        if not name:
            continue
        entities.append(
            Entity(
                kind="import",
                name=name,
                signature=_truncate(_node_text(child, source_text)),
            )
        )
    return entities


def _decision_mentions_file(
    decision: dict[str, Any], file_path: str
) -> bool:
    """Return ``True`` when the decision text references ``file_path``."""
    title = str(decision.get("title", ""))
    description = str(decision.get("description", ""))
    haystack = f"{title}\n{description}"
    if not haystack or not file_path:
        return False
    if file_path in haystack:
        return True
    # Match by file name alone — decision authors often write "auth.py"
    # rather than "backend/auth/auth_service.py".
    basename = file_path.rsplit("/", 1)[-1]
    return bool(basename) and basename in haystack
