"""Passive decision inference.

Inspects a session's tool-call timeline and structural AST changes and
produces candidate :class:`InferredDecision` records for file-level
changes that have no linked decision. The inferrer never persists
records itself — the caller (``session.end`` in ``tool_handlers``)
decides whether to save the candidates and return them to the agent.

Security invariants enforced:
- SEC-01: Reads are scoped to the validated :class:`DatabaseBackend`
  API. No credential material is introduced.
- SEC-03: Candidate titles and descriptions are derived from AST
  entity names and change types — never from credentials or raw file
  content.
"""

from __future__ import annotations

import json
import os
import uuid as uuid_mod
from collections import defaultdict
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from backend.models import Decision, InferredDecision

if TYPE_CHECKING:
    from backend.db.db_backend import DatabaseBackend
    from backend.intelligence.ast_tracker import ASTTracker


# Maps ``ASTChange.change_type`` to the verb used in candidate titles.
_CHANGE_TYPE_VERBS: dict[str, str] = {
    "function_added": "Add",
    "function_removed": "Remove",
    "function_modified": "Modify",
    "class_added": "Add",
    "class_removed": "Remove",
    "class_modified": "Modify",
    "import_added": "Import",
    "import_removed": "Remove import of",
    "import_modified": "Update import of",
    "signature_changed": "Change signature of",
}


# Confidence ladder (see Prompt 1 spec).
_CONFIDENCE_BASE = 0.6
_CONFIDENCE_SINGLE_FILE = 0.75
_CONFIDENCE_MULTI_FILE = 0.45
_CONFIDENCE_SESSION_PATTERN = 0.4

# Minimum repeats of the same tool on the same directory to warrant a
# module-level inference.
_MODULE_PATTERN_MIN_HITS = 3


@dataclass(frozen=True)
class _UnlinkedChange:
    """Subset of an AST change row needed for candidate construction."""

    file_path: str
    entity_name: str
    change_type: str
    change_event_id: str


class DecisionInferrer:
    """Produce candidate decisions from a session's unlinked AST changes."""

    def __init__(
        self,
        db: DatabaseBackend,
        ast_tracker: ASTTracker | None = None,
    ) -> None:
        self._db = db
        self._ast_tracker = ast_tracker  # Reserved for future use.

    async def infer_from_session(
        self, session_id: str, project_id: str
    ) -> list[InferredDecision]:
        """Return candidate decisions for this session's unlinked structural changes.

        The caller is responsible for persisting the candidates.
        """
        if not session_id:
            return []

        # Step 1 — collect raw material.
        session_events = await self._db.query(
            "session_events", where={"session_id": session_id}
        )
        change_event_types = {
            str(e.get("event_type", "")) for e in session_events
        }
        explicit_files = self._files_with_explicit_decisions(session_events)

        ast_rows = await self._db.query(
            "ast_changes", where={"session_id": session_id}
        )
        if not ast_rows:
            # No structural changes recorded in this session — only pattern
            # inference remains worthwhile.
            return self._infer_session_patterns(
                session_id=session_id,
                project_id=project_id,
                session_events=session_events,
            )

        # Step 2 — identify unlinked structural changes.
        unlinked: list[_UnlinkedChange] = []
        for row in ast_rows:
            file_path = str(row.get("file_path") or "")
            if not file_path or file_path in explicit_files:
                continue
            edges = await self._db.query(
                "provenance_edges",
                where={
                    "target_type": "ast_change",
                    "target_id": str(row["id"]),
                    "source_type": "decision",
                },
            )
            if edges:
                continue
            unlinked.append(
                _UnlinkedChange(
                    file_path=file_path,
                    entity_name=str(row.get("entity_name") or ""),
                    change_type=str(row.get("change_type") or ""),
                    change_event_id=str(row.get("change_event_id") or ""),
                )
            )

        # Step 3 — group by file, generate candidates, skip previously rejected.
        rejected = await self._previously_rejected_file_set(session_id)
        grouped: dict[str, list[_UnlinkedChange]] = defaultdict(list)
        for change in unlinked:
            grouped[change.file_path].append(change)

        distinct_event_ids = {
            c.change_event_id for c in unlinked if c.change_event_id
        }
        single_event = len(distinct_event_ids) <= 1
        multi_file = len(grouped) > 1
        file_candidates: list[InferredDecision] = []

        for file_path, changes in grouped.items():
            if file_path in rejected:
                continue
            candidate = self._build_file_candidate(
                session_id=session_id,
                project_id=project_id,
                file_path=file_path,
                changes=changes,
                single_event=single_event,
                multi_file=multi_file,
            )
            file_candidates.append(candidate)

        # Step 4 — detect session patterns for higher-level inferences.
        pattern_candidates = self._infer_session_patterns(
            session_id=session_id,
            project_id=project_id,
            session_events=session_events,
            exclude_files=explicit_files | set(grouped.keys()),
        )
        _ = change_event_types  # accepted for future filters

        return file_candidates + pattern_candidates

    async def auto_confirm_high_confidence(
        self,
        session_id: str,
        project_id: str,
        threshold: float = 0.75,
        *,
        recorded_by_user_id: uuid_mod.UUID | None = None,
    ) -> list[Decision]:
        """Promote every pending InferredDecision with confidence ≥ threshold.

        The candidate title becomes the decision title. The description
        is prepended with an auto-confirmation note so a developer
        reviewing the record later knows it was produced passively.
        Promoted records have ``inference_status='confirmed'`` and are
        indexed for semantic retrieval by the caller's handler layer
        (this method focuses on the DB writes only).

        ``recorded_by_user_id`` is optional — when the auto-confirmation
        runs via ``session.end`` we plumb the authenticated user through.
        """
        if not 0.0 <= threshold <= 1.0:
            raise ValueError(
                f"threshold must be between 0.0 and 1.0, got {threshold!r}"
            )
        rows = await self._db.query(
            "inferred_decisions",
            where={"session_id": session_id, "status": "pending"},
        )
        promoted: list[Decision] = []
        _ = project_id  # reserved for per-project promotion limits later
        now_iso = datetime.now(UTC).isoformat()
        for row in rows:
            if float(row.get("confidence") or 0.0) < threshold:
                continue
            inferred = InferredDecision.from_dict(row)
            decision = Decision(
                title=inferred.candidate_title,
                description=(
                    "Auto-confirmed from passive inference. Review and "
                    "update description if rationale is known.\n\n"
                    f"{inferred.candidate_description}"
                ),
                tags=[t for t in inferred.candidate_tags if t != "inferred"],
                status="unverified",
                recorded_by_user_id=recorded_by_user_id,
                recorded_in_session_id=inferred.session_id,
                inference_status="confirmed",
                inference_confidence=inferred.confidence,
            )
            try:
                await self._db.insert("decisions", decision.to_dict())
                await self._db.update(
                    "inferred_decisions",
                    str(inferred.id),
                    {
                        "status": "confirmed",
                        "updated_at": now_iso,
                    },
                )
            except Exception:
                # Best-effort — skip this candidate and continue.
                continue
            promoted.append(decision)
        return promoted

    # ------------------------------------------------------------------
    # Candidate construction
    # ------------------------------------------------------------------

    def _build_file_candidate(
        self,
        *,
        session_id: str,
        project_id: str,
        file_path: str,
        changes: list[_UnlinkedChange],
        single_event: bool,
        multi_file: bool,
    ) -> InferredDecision:
        """Create a candidate for a single unlinked file's AST changes."""
        first = changes[0]
        verb = _CHANGE_TYPE_VERBS.get(first.change_type, "Update")
        basename = os.path.basename(file_path) or file_path
        title = f"{verb} {first.entity_name or 'entities'} in {basename}"

        breakdown = ", ".join(
            f"{c.entity_name or 'entity'} ({c.change_type})" for c in changes
        )
        description = (
            "Inferred from session activity. "
            f"{len(changes)} structural changes detected in {file_path}: "
            f"{breakdown}. Rationale not recorded — confirm or provide "
            "description."
        )

        if multi_file:
            confidence = _CONFIDENCE_MULTI_FILE
        elif single_event:
            confidence = _CONFIDENCE_SINGLE_FILE
        else:
            confidence = _CONFIDENCE_BASE

        return InferredDecision(
            session_id=uuid_mod.UUID(session_id),
            project_id=project_id,
            candidate_title=title,
            candidate_description=description,
            candidate_tags=["inferred"],
            files_affected=[file_path],
            inference_source="ast_change",
            confidence=confidence,
        )

    def _infer_session_patterns(
        self,
        *,
        session_id: str,
        project_id: str,
        session_events: list[dict[str, Any]],
        exclude_files: set[str] | None = None,
    ) -> list[InferredDecision]:
        """Detect tool-call repetition patterns and emit module-level candidates."""
        exclude_files = exclude_files or set()
        # Count ``context.get_for_file`` calls per directory.
        per_dir: dict[str, int] = defaultdict(int)
        for evt in session_events:
            if str(evt.get("event_type", "")) != "tool_call":
                continue
            payload = _parse_payload(evt.get("payload"))
            tool = str(payload.get("tool", ""))
            if tool not in ("context.get_for_file", "context_get_for_file"):
                continue
            file_path = str(payload.get("file_path", ""))
            if not file_path or file_path in exclude_files:
                continue
            directory = os.path.dirname(file_path) or "."
            per_dir[directory] += 1

        candidates: list[InferredDecision] = []
        for directory, hits in per_dir.items():
            if hits < _MODULE_PATTERN_MIN_HITS:
                continue
            candidates.append(
                InferredDecision(
                    session_id=uuid_mod.UUID(session_id),
                    project_id=project_id,
                    candidate_title=f"Work on {os.path.basename(directory) or directory} module",
                    candidate_description=(
                        f"Inferred from session activity: {hits} context reads "
                        f"on files under {directory}. Rationale not recorded "
                        "— confirm or provide description."
                    ),
                    candidate_tags=["inferred", "module"],
                    files_affected=[directory],
                    inference_source="session_pattern",
                    confidence=_CONFIDENCE_SESSION_PATTERN,
                )
            )
        return candidates

    # ------------------------------------------------------------------
    # Raw material helpers
    # ------------------------------------------------------------------

    def _files_with_explicit_decisions(
        self, session_events: list[dict[str, Any]]
    ) -> set[str]:
        """Files referenced by ``decision.create`` tool calls in the session."""
        files: set[str] = set()
        for evt in session_events:
            if str(evt.get("event_type", "")) != "tool_call":
                continue
            payload = _parse_payload(evt.get("payload"))
            tool = str(payload.get("tool", ""))
            if tool not in ("decision.create", "decision_create"):
                continue
            affected = payload.get("files_affected") or []
            if isinstance(affected, list):
                files.update(str(f) for f in affected)
        return files

    async def _previously_rejected_file_set(self, session_id: str) -> set[str]:
        """Files whose candidates were previously rejected in this session."""
        rows = await self._db.query(
            "inferred_decisions",
            where={"session_id": session_id, "status": "rejected"},
        )
        rejected: set[str] = set()
        for row in rows:
            raw = row.get("files_affected") or "[]"
            try:
                files = json.loads(raw) if isinstance(raw, str) else list(raw)
            except json.JSONDecodeError:
                files = []
            rejected.update(str(f) for f in files)
        return rejected


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _parse_payload(raw: Any) -> dict[str, Any]:
    """Best-effort parse of a SessionEvent payload."""
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str):
        try:
            loaded = json.loads(raw)
            if isinstance(loaded, dict):
                return loaded
        except json.JSONDecodeError:
            return {}
    return {}
