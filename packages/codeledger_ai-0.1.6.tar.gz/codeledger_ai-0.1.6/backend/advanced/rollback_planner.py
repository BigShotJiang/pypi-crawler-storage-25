"""Context-aware rollback planner.

Given a decision id, produces a :class:`RollbackPlan` that names every
change event the decision produced, the files those events touched, and
the other decisions that would be affected. The risk assessment is
identical for both change-detection backends — only the event labels
differ.

Security invariants enforced:
- SEC-01: All reads go through :class:`DatabaseBackend` or
  :class:`ProvenanceEngine`.
- SEC-03: Plans carry identifiers and short labels. File content and
  commit diffs are never embedded.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    import uuid

    from backend.db.db_backend import DatabaseBackend
    from backend.verification.provenance import ProvenanceEngine


Risk = Literal["low", "medium", "high"]


@dataclass(frozen=True)
class ChangeEventRef:
    """A single change event referenced by the rollback plan."""

    change_event_id: str
    change_event_type: str
    label: str


@dataclass(frozen=True)
class RollbackPlan:
    """The full plan for undoing a decision and surfacing downstream impact."""

    target_decision: dict[str, Any]
    dependent_decisions: list[dict[str, Any]] = field(default_factory=list)
    affected_change_events: list[ChangeEventRef] = field(default_factory=list)
    affected_files: list[str] = field(default_factory=list)
    ast_changes_to_revert: list[dict[str, Any]] = field(default_factory=list)
    risk_assessment: Risk = "low"
    recommended_action: str = ""


class RollbackPlanError(Exception):
    """Raised when a rollback plan cannot be produced."""


class RollbackPlanner:
    """Walk the provenance graph and produce a backend-agnostic rollback plan."""

    def __init__(
        self,
        db: DatabaseBackend,
        provenance: ProvenanceEngine,
    ) -> None:
        self._db = db
        self._provenance = provenance

    async def plan_rollback(self, decision_id: uuid.UUID | str) -> RollbackPlan:
        """Produce the rollback plan for ``decision_id``."""
        try:
            tree = await self._provenance.forward_trace(decision_id)
        except Exception as exc:
            raise RollbackPlanError(str(exc)) from exc
        dependents = await self._provenance.get_decision_dependencies(decision_id)

        change_events: list[ChangeEventRef] = []
        affected_files: set[str] = set()
        ast_changes: list[dict[str, Any]] = []
        for event in tree.change_events:
            change_events.append(
                ChangeEventRef(
                    change_event_id=event.change_event_id,
                    change_event_type=event.change_event_type,
                    label=event.label,
                )
            )
            for change in event.ast_changes:
                ast_changes.append(change)
                fp = str(change.get("file_path") or "")
                if fp:
                    affected_files.add(fp)

        risk = _assess_risk(dependents)
        return RollbackPlan(
            target_decision=tree.decision,
            dependent_decisions=dependents,
            affected_change_events=change_events,
            affected_files=sorted(affected_files),
            ast_changes_to_revert=ast_changes,
            risk_assessment=risk,
            recommended_action=_recommendation_for(risk, dependents),
        )

    async def plan_rollback_dict(
        self, decision_id: uuid.UUID | str
    ) -> dict[str, Any]:
        """Serialisable view of :meth:`plan_rollback`."""
        plan = await self.plan_rollback(decision_id)
        return {
            "target_decision": plan.target_decision,
            "dependent_decisions": plan.dependent_decisions,
            "affected_change_events": [
                {
                    "change_event_id": e.change_event_id,
                    "change_event_type": e.change_event_type,
                    "label": e.label,
                }
                for e in plan.affected_change_events
            ],
            "affected_files": plan.affected_files,
            "ast_changes_to_revert": plan.ast_changes_to_revert,
            "risk_assessment": plan.risk_assessment,
            "recommended_action": plan.recommended_action,
        }


# ---------------------------------------------------------------------------
# Risk logic
# ---------------------------------------------------------------------------


def _assess_risk(dependents: list[dict[str, Any]]) -> Risk:
    """Classify the rollback risk based on downstream decision status."""
    if not dependents:
        return "low"
    any_verified = any(
        str(d.get("status") or "").lower() == "passed" for d in dependents
    )
    if any_verified:
        return "high"
    return "medium"


def _recommendation_for(
    risk: Risk, dependents: list[dict[str, Any]]
) -> str:
    """Render a short prose recommendation."""
    if risk == "low":
        return (
            "Safe to roll back. No downstream decisions reference the "
            "changes this decision authored."
        )
    if risk == "medium":
        return (
            f"Review the {len(dependents)} unverified dependent decision(s) "
            "before rolling back — they may rely on the reverted changes."
        )
    return (
        f"Rollback is high risk. {len(dependents)} dependent decision(s) "
        "include verified (passed) decisions that may regress."
    )
