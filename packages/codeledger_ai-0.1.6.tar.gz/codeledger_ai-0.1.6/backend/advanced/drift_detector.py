"""Architectural drift detector.

Compares verified architectural decisions against the current codebase's
import graph to surface violations — places where the implementation has
drifted from the decision record.

The detector is intentionally simple: it extracts ``must not import``
and ``module X must not depend on module Y`` style constraints from the
decision text, parses the current codebase with :class:`ASTTracker` to
build an import map, and emits one :class:`DriftViolation` per breach.

Works for both backends. Only inspects the current filesystem — no
commit history or snapshot IDs required.

Security invariants enforced:
- SEC-01: All reads go through :class:`DatabaseBackend`; file reads are
  scoped to the supplied ``repo_path``.
- SEC-03: Violations carry file paths and line numbers, never content
  excerpts containing credentials.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    from backend.db.db_backend import DatabaseBackend
    from backend.intelligence.ast_tracker import ASTTracker
    from backend.intelligence.semantic_search import SemanticSearch


_logger = logging.getLogger(__name__)


Severity = Literal["low", "medium", "high"]


@dataclass(frozen=True)
class DriftViolation:
    """A single architectural constraint that the codebase now breaks."""

    decision_id: str
    decision_title: str
    constraint_description: str
    violating_file: str
    violating_line: int
    violation_description: str
    severity: Severity


@dataclass(frozen=True)
class DriftReport:
    """Collection of violations for a single ``check_drift`` run."""

    project_id: str
    violations: list[DriftViolation] = field(default_factory=list)
    checked_files: int = 0
    decisions_considered: int = 0


# Regexes over decision text that identify "must not import / depend" clauses.
# The group names are the "lhs" (guarded module) and the "rhs" (forbidden target).
_DRIFT_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(
        r"(?P<lhs>[A-Za-z_][\w./\-]*)\s+must\s+not\s+import\s+"
        r"(?P<rhs>[A-Za-z_][\w./\-]*)",
        re.IGNORECASE,
    ),
    re.compile(
        r"(?P<lhs>[A-Za-z_][\w./\-]*)\s+must\s+not\s+depend\s+on\s+"
        r"(?P<rhs>[A-Za-z_][\w./\-]*)",
        re.IGNORECASE,
    ),
)


@dataclass(frozen=True)
class _Constraint:
    decision_id: str
    decision_title: str
    lhs: str
    rhs: str
    original_text: str


class DriftDetector:
    """Walk the import graph and flag violations of verified decisions."""

    def __init__(
        self,
        db: DatabaseBackend,
        ast_tracker: ASTTracker,
        semantic_search: SemanticSearch | None = None,
    ) -> None:
        self._db = db
        self._ast_tracker = ast_tracker
        self._semantic_search = semantic_search

    async def check_drift(
        self, project_id: str, repo_path: str
    ) -> DriftReport:
        """Return all drift violations for ``project_id`` under ``repo_path``."""
        if not project_id:
            raise ValueError("project_id must be non-empty")
        root = Path(repo_path)
        if not root.exists() or not root.is_dir():
            return DriftReport(project_id=project_id)

        constraints = await self._extract_constraints(project_id)
        decisions_considered = (
            len(constraints)
            if constraints
            else await self._verified_decision_count()
        )

        checked = 0
        violations: list[DriftViolation] = []
        for file_path in _walk_source_files(root):
            checked += 1
            if not constraints:
                continue
            try:
                content = file_path.read_text(encoding="utf-8", errors="replace")
            except OSError as exc:
                _logger.warning("drift: cannot read %s: %s", file_path, exc)
                continue
            rel_path = file_path.relative_to(root).as_posix()
            violations.extend(
                _violations_for_file(rel_path, content, constraints)
            )
        return DriftReport(
            project_id=project_id,
            violations=violations,
            checked_files=checked,
            decisions_considered=decisions_considered,
        )

    async def drift_report(
        self, project_id: str, repo_path: str
    ) -> dict[str, Any]:
        """Serialisable view of :meth:`check_drift`."""
        report = await self.check_drift(project_id, repo_path)
        return {
            "project_id": report.project_id,
            "checked_files": report.checked_files,
            "decisions_considered": report.decisions_considered,
            "violations": [
                {
                    "decision_id": v.decision_id,
                    "decision_title": v.decision_title,
                    "constraint_description": v.constraint_description,
                    "violating_file": v.violating_file,
                    "violating_line": v.violating_line,
                    "violation_description": v.violation_description,
                    "severity": v.severity,
                }
                for v in report.violations
            ],
        }

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    async def _extract_constraints(
        self, project_id: str
    ) -> list[_Constraint]:
        """Pull "must not import" style rules from verified decisions."""
        _ = project_id
        decisions = await self._db.query(
            "decisions", where={"status": "passed"}
        )
        constraints: list[_Constraint] = []
        for row in decisions:
            title = str(row.get("title") or "")
            description = str(row.get("description") or "")
            blob = f"{title}\n{description}"
            for pattern in _DRIFT_PATTERNS:
                for match in pattern.finditer(blob):
                    constraints.append(
                        _Constraint(
                            decision_id=str(row["id"]),
                            decision_title=title,
                            lhs=match.group("lhs"),
                            rhs=match.group("rhs"),
                            original_text=match.group(0),
                        )
                    )
        return constraints

    async def _verified_decision_count(self) -> int:
        decisions = await self._db.query(
            "decisions", where={"status": "passed"}
        )
        return len(decisions)


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


_SOURCE_EXTS = {
    ".py",
    ".ts",
    ".tsx",
    ".js",
    ".jsx",
    ".go",
    ".rs",
    ".java",
    ".c",
    ".cpp",
    ".h",
    ".hpp",
    ".rb",
    ".cs",
}

_IGNORE_DIR_NAMES = {
    ".git",
    "node_modules",
    "dist",
    "__pycache__",
    "data",
    ".venv",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "build",
}


def _walk_source_files(root: Path) -> list[Path]:
    """Yield every source file beneath ``root`` skipping ignore dirs."""
    results: list[Path] = []
    for path in root.rglob("*"):
        if path.is_dir():
            continue
        if path.suffix.lower() not in _SOURCE_EXTS:
            continue
        if any(part in _IGNORE_DIR_NAMES for part in path.relative_to(root).parts):
            continue
        results.append(path)
    return results


def _violations_for_file(
    file_path: str, content: str, constraints: list[_Constraint]
) -> list[DriftViolation]:
    """Emit violations for each constraint breached by ``file_path``."""
    violations: list[DriftViolation] = []
    for constraint in constraints:
        if not _file_matches_lhs(file_path, constraint.lhs):
            continue
        for lineno, line in enumerate(content.splitlines(), start=1):
            if _line_imports(line, constraint.rhs):
                violations.append(
                    DriftViolation(
                        decision_id=constraint.decision_id,
                        decision_title=constraint.decision_title,
                        constraint_description=constraint.original_text,
                        violating_file=file_path,
                        violating_line=lineno,
                        violation_description=(
                            f"{file_path}:{lineno} imports "
                            f"{constraint.rhs}, which decision "
                            f"'{constraint.decision_title}' forbids."
                        ),
                        severity=_severity_for(constraint),
                    )
                )
    return violations


def _file_matches_lhs(file_path: str, lhs: str) -> bool:
    """Does ``file_path`` belong to the guarded module named in ``lhs``?"""
    normalized = lhs.replace(".", "/").strip("/")
    return (
        normalized in file_path
        or file_path.startswith(normalized + "/")
        or file_path.endswith("/" + normalized)
        or file_path.endswith(normalized + ".py")
        or file_path == normalized + ".py"
    )


def _line_imports(line: str, target: str) -> bool:
    """Crude match for an import of ``target`` on a source line.

    ``target`` matches when the line starts with an import keyword
    (``import``, ``from``, ``use``, ``require(...)``) AND the target
    appears as a full dotted/slashed segment in the same line. This
    catches ``from backend.db import X`` when ``target="backend.db"``
    AND when ``target="db"`` (the trailing segment).
    """
    stripped = line.strip()
    if not stripped or stripped.startswith("#") or stripped.startswith("//"):
        return False
    target_escaped = re.escape(target)
    has_import_kw = (
        bool(re.match(r"(?:import|from|use)\s", stripped))
        or "require(" in stripped
        or re.search(r'from\s+["\']', stripped) is not None
    )
    if not has_import_kw:
        return False
    # Match the target as a standalone segment bounded by whitespace,
    # dots, slashes, colons, or quotes.
    segment_pattern = rf"(?:^|[\s./:\"']){target_escaped}(?:$|[\s./:\"',;])"
    return bool(re.search(segment_pattern, stripped))


def _severity_for(constraint: _Constraint) -> Severity:
    """Default severity: high — drift against a verified decision is serious."""
    _ = constraint
    return "high"
