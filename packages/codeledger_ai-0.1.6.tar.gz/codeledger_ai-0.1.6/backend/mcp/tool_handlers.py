"""Business logic for all MCP tools and REST endpoints.

Every handler method takes a ``DatabaseBackend`` and the authenticated user id,
performs the operation, and returns a plain-dict result. The handler layer is
framework-agnostic — FastMCP tools and FastAPI routes both dispatch into it.

Security invariants enforced:
- SEC-05: Every mutating handler requires an authenticated user id; the caller
  is responsible for supplying it from request state.
- SEC-03: Returned dicts contain only domain fields; no credentials or tokens
  are ever part of a tool response.
"""

from __future__ import annotations

import json
import logging
import os
import re
import uuid
import uuid as _uuid_mod
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import TYPE_CHECKING, Any

from backend.intelligence.context_triage import format_context_block
from backend.intelligence.decision_inferrer import DecisionInferrer
from backend.intelligence.staleness_scorer import StalenessScorer
from backend.models import (
    ContextItem,
    Decision,
    InferredDecision,
    Session,
    Sprint,
    Story,
)

if TYPE_CHECKING:
    from backend.advanced.agent_profiler import AgentProfiler
    from backend.advanced.drift_detector import DriftDetector
    from backend.advanced.knowledge_packs import KnowledgePackManager
    from backend.advanced.rollback_planner import RollbackPlanner
    from backend.advanced.tautology_detector import TautologyDetector
    from backend.db.db_backend import DatabaseBackend
    from backend.intelligence.context_triage import ContextTriage
    from backend.intelligence.semantic_search import SemanticSearch
    from backend.verification.conflict_detector import ConflictDetector
    from backend.verification.harness import QualityHarness
    from backend.verification.provenance import ProvenanceEngine
    from backend.verification.verifier import Verifier


logger = logging.getLogger(__name__)


class HandlerError(Exception):
    """Raised for handler-level failures (not found, invalid input, etc.)."""


@dataclass(frozen=True)
class SessionContextResult:
    """Result of :func:`ensure_session_and_inject_context` / its handler wrapper."""

    session_id: str
    is_new_session: bool
    context_block: str | None
    context_items_count: int
    tokens_used: int


# Default retrieval query used when an agent's first tool call does not
# carry a natural-language prompt (e.g. ``session.start`` in isolation).
_DEFAULT_FIRST_MESSAGE = "project architecture decisions"

# Inactive-session window for matching existing active sessions. This is the
# same value semantically as SessionConfig.inactivity_timeout_minutes but
# kept here as a floor so handlers can be called without a full config.
_DEFAULT_INACTIVITY_TIMEOUT_MINUTES = 30


# Input size ceilings — every handler uses these before forwarding user
# input to DB writes, embedders, or AST parsers. Values are small enough
# to keep memory bounded on a single request but generous enough to
# accept reasonable real-world content.
MAX_TITLE_LEN = 512
MAX_DESCRIPTION_LEN = 16_384        # 16 KB
MAX_CONTENT_LEN = 1_048_576         # 1 MB
MAX_QUERY_LEN = 4096
MAX_FILE_PATH_LEN = 1024
MAX_FILE_CONTENT_LEN = 5_242_880    # 5 MB — well under the 10 MB request cap
MAX_TAGS_COUNT = 32
MAX_TAG_LEN = 64


def _enforce_size(value: Any, field_name: str, limit: int) -> None:
    """Raise HandlerError when a string ``value`` exceeds ``limit`` bytes."""
    if value is None:
        return
    if isinstance(value, str) and len(value) > limit:
        raise HandlerError(
            f"{field_name} exceeds maximum size of {limit} characters"
        )


# Valid status vocabularies enforced at the handler layer
_DECISION_STATUSES = frozenset({"unverified", "pending", "passed", "failed"})
_STORY_STATUSES = frozenset({"backlog", "in_progress", "review", "done"})
_SESSION_STATUSES = frozenset({"active", "idle", "completed"})
_SPRINT_STATUSES = frozenset({"planning", "active", "completed"})


def _ensure(condition: bool, message: str) -> None:
    """Raise HandlerError if condition is false."""
    if not condition:
        raise HandlerError(message)


def _require_str(value: Any, field_name: str) -> str:
    """Coerce to a non-empty string or raise."""
    _ensure(
        isinstance(value, str) and value.strip() != "",
        f"{field_name} must be a non-empty string",
    )
    return str(value)


def _validate_status(value: str, valid: frozenset[str], field_name: str) -> str:
    """Raise HandlerError if value is not a member of valid."""
    _ensure(value in valid, f"Invalid {field_name}: {value!r}")
    return value


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


@dataclass
class ToolHandlers:
    """Collection of all CRUD and aggregation operations over the database.

    Phase 2 adds optional ``semantic_search`` and ``context_triage`` fields.
    When present, the CRUD create/update paths automatically index decisions,
    stories, and context items for semantic retrieval; when absent, the
    handlers behave exactly as in Phase 1 (non-breaking).
    """

    db: DatabaseBackend
    semantic_search: SemanticSearch | None = None
    context_triage: ContextTriage | None = None
    verifier: Verifier | None = None
    harness: QualityHarness | None = None
    conflict_detector: ConflictDetector | None = None
    provenance: ProvenanceEngine | None = None
    drift_detector: DriftDetector | None = None
    tautology_detector: TautologyDetector | None = None
    rollback_planner: RollbackPlanner | None = None
    knowledge_packs: KnowledgePackManager | None = None
    agent_profiler: AgentProfiler | None = None
    decision_inferrer: DecisionInferrer | None = None
    staleness_scorer: StalenessScorer | None = None
    auto_confirm_threshold: float | None = None
    change_detection_backend: str = "git"
    default_project_id: str = "default"
    default_token_budget: int = 8000
    project_root: str = "."
    _session_events_enabled: bool = field(default=True)

    # -- Context ------------------------------------------------------------

    async def context_create(
        self,
        *,
        user_id: uuid.UUID,
        content: str,
        source: str = "",
        tags: list[str] | None = None,
        session_id: uuid.UUID | None = None,
    ) -> dict[str, Any]:
        _require_str(content, "content")
        _enforce_size(content, "content", MAX_CONTENT_LEN)
        _enforce_size(source, "source", MAX_TITLE_LEN)
        if tags and len(tags) > MAX_TAGS_COUNT:
            raise HandlerError(
                f"tags exceeds maximum of {MAX_TAGS_COUNT} items"
            )
        for i, tag in enumerate(tags or []):
            _enforce_size(tag, f"tags[{i}]", MAX_TAG_LEN)
        item = ContextItem(
            content=content,
            source=source,
            tags=list(tags or []),
            session_id=session_id,
        )
        await self.db.insert("context_items", item.to_dict())
        _ = user_id  # reserved for auditing/multi-tenancy in later phases
        await self._maybe_index(
            item_id=str(item.id),
            text=content,
            item_type="context",
            metadata={"source": source, "tags": list(tags or [])},
        )
        return ContextItem.from_dict(
            await self._required_row("context_items", item.id)
        ).to_dict()

    async def context_read(
        self, *, user_id: uuid.UUID, item_id: uuid.UUID
    ) -> dict[str, Any]:
        _ = user_id
        row = await self._required_row("context_items", item_id)
        return ContextItem.from_dict(row).to_dict()

    async def context_update(
        self,
        *,
        user_id: uuid.UUID,
        item_id: uuid.UUID,
        content: str | None = None,
        source: str | None = None,
        tags: list[str] | None = None,
    ) -> dict[str, Any]:
        _ = user_id
        row = await self._required_row("context_items", item_id)
        item = ContextItem.from_dict(row)
        if content is not None:
            item.content = content
        if source is not None:
            item.source = source
        if tags is not None:
            item.tags = list(tags)
        item.updated_at = datetime.now(UTC)
        await self.db.update("context_items", str(item.id), item.to_dict())
        if content is not None:
            await self._maybe_reindex(str(item.id), content)
        return item.to_dict()

    async def context_delete(
        self, *, user_id: uuid.UUID, item_id: uuid.UUID
    ) -> dict[str, Any]:
        _ = user_id
        await self._required_row("context_items", item_id)
        await self.db.delete("context_items", str(item_id))
        await self._maybe_remove(str(item_id))
        return {"deleted": True, "id": str(item_id)}

    async def context_list(
        self,
        *,
        user_id: uuid.UUID,
        session_id: uuid.UUID | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        _ = user_id
        where = {"session_id": str(session_id)} if session_id else None
        rows = await self.db.query(
            "context_items",
            where=where,
            order_by="created_at DESC",
            limit=limit,
        )
        return [ContextItem.from_dict(r).to_dict() for r in rows]

    # -- Decisions ---------------------------------------------------------

    async def decision_create(
        self,
        *,
        user_id: uuid.UUID,
        title: str,
        description: str = "",
        tags: list[str] | None = None,
        session_id: uuid.UUID | None = None,
    ) -> dict[str, Any]:
        _require_str(title, "title")
        _enforce_size(title, "title", MAX_TITLE_LEN)
        _enforce_size(description, "description", MAX_DESCRIPTION_LEN)
        if tags and len(tags) > MAX_TAGS_COUNT:
            raise HandlerError(
                f"tags exceeds maximum of {MAX_TAGS_COUNT} items"
            )
        for i, tag in enumerate(tags or []):
            _enforce_size(tag, f"tags[{i}]", MAX_TAG_LEN)
        decision = Decision(
            title=title,
            description=description,
            tags=list(tags or []),
            status="unverified",
            recorded_by_user_id=user_id,
            recorded_in_session_id=session_id,
        )
        await self.db.insert("decisions", decision.to_dict())
        await self._maybe_index(
            item_id=str(decision.id),
            text=f"{title}\n\n{description}".strip(),
            item_type="decision",
            metadata={"title": title, "tags": list(tags or [])},
        )
        return Decision.from_dict(
            await self._required_row("decisions", decision.id)
        ).to_dict()

    async def decision_read(
        self, *, user_id: uuid.UUID, decision_id: uuid.UUID
    ) -> dict[str, Any]:
        _ = user_id
        row = await self._required_row("decisions", decision_id)
        # Update access tracking.
        now_iso = _now_iso()
        new_access_count = int(row.get("access_count") or 0) + 1
        await self.db.update(
            "decisions",
            str(decision_id),
            {
                "last_accessed_at": now_iso,
                "access_count": new_access_count,
                "updated_at": now_iso,
            },
        )
        # Refresh staleness when a scorer is wired.
        if self.staleness_scorer is not None:
            try:
                await self.staleness_scorer.score_decision(str(decision_id))
            except Exception:
                logger.warning(
                    "Failed to refresh staleness for %s", decision_id,
                    exc_info=True,
                )
        refreshed = await self._required_row("decisions", decision_id)
        return Decision.from_dict(refreshed).to_dict()

    async def decision_list(
        self,
        *,
        user_id: uuid.UUID,
        status: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        _ = user_id
        where: dict[str, Any] | None = None
        if status is not None:
            _validate_status(status, _DECISION_STATUSES, "decision status")
            where = {"status": status}
        rows = await self.db.query(
            "decisions", where=where, order_by="created_at DESC", limit=limit
        )
        return [Decision.from_dict(r).to_dict() for r in rows]

    # -- Stories -----------------------------------------------------------

    async def story_create(
        self,
        *,
        user_id: uuid.UUID,
        title: str,
        description: str = "",
        acceptance_criteria: list[str] | None = None,
        points: int | None = None,
        sprint_id: uuid.UUID | None = None,
    ) -> dict[str, Any]:
        _ = user_id
        _require_str(title, "title")
        if points is not None:
            _ensure(
                isinstance(points, int) and points >= 0 and not isinstance(points, bool),
                "points must be a non-negative integer",
            )
        story = Story(
            title=title,
            description=description,
            acceptance_criteria=list(acceptance_criteria or []),
            points=points,
            sprint_id=sprint_id,
        )
        await self.db.insert("stories", story.to_dict())
        await self._maybe_index(
            item_id=str(story.id),
            text=f"{title}\n\n{description}".strip(),
            item_type="story",
            metadata={"title": title},
        )
        return Story.from_dict(
            await self._required_row("stories", story.id)
        ).to_dict()

    async def story_read(
        self, *, user_id: uuid.UUID, story_id: uuid.UUID
    ) -> dict[str, Any]:
        _ = user_id
        row = await self._required_row("stories", story_id)
        return Story.from_dict(row).to_dict()

    async def story_update(
        self,
        *,
        user_id: uuid.UUID,
        story_id: uuid.UUID,
        title: str | None = None,
        description: str | None = None,
        acceptance_criteria: list[str] | None = None,
        status: str | None = None,
        points: int | None = None,
        sprint_id: uuid.UUID | None = None,
    ) -> dict[str, Any]:
        _ = user_id
        row = await self._required_row("stories", story_id)
        story = Story.from_dict(row)
        if title is not None:
            story.title = title
        if description is not None:
            story.description = description
        if acceptance_criteria is not None:
            story.acceptance_criteria = list(acceptance_criteria)
        if status is not None:
            _validate_status(status, _STORY_STATUSES, "story status")
            story.status = status
        if points is not None:
            story.points = points
        if sprint_id is not None:
            story.sprint_id = sprint_id
        story.updated_at = datetime.now(UTC)
        await self.db.update("stories", str(story.id), story.to_dict())
        return story.to_dict()

    async def story_list(
        self,
        *,
        user_id: uuid.UUID,
        sprint_id: uuid.UUID | None = None,
        status: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        _ = user_id
        where: dict[str, Any] = {}
        if sprint_id is not None:
            where["sprint_id"] = str(sprint_id)
        if status is not None:
            _validate_status(status, _STORY_STATUSES, "story status")
            where["status"] = status
        rows = await self.db.query(
            "stories",
            where=where or None,
            order_by="created_at DESC",
            limit=limit,
        )
        return [Story.from_dict(r).to_dict() for r in rows]

    # -- Sprints -----------------------------------------------------------

    async def sprint_create(
        self,
        *,
        user_id: uuid.UUID,
        name: str,
        start_date: datetime | None = None,
        end_date: datetime | None = None,
    ) -> dict[str, Any]:
        _ = user_id
        _require_str(name, "name")
        sprint = Sprint(
            name=name,
            start_date=start_date,
            end_date=end_date,
            status="planning",
        )
        await self.db.insert("sprints", sprint.to_dict())
        return Sprint.from_dict(
            await self._required_row("sprints", sprint.id)
        ).to_dict()

    async def sprint_status(
        self, *, user_id: uuid.UUID, sprint_id: uuid.UUID
    ) -> dict[str, Any]:
        _ = user_id
        row = await self._required_row("sprints", sprint_id)
        sprint = Sprint.from_dict(row)
        stories_rows = await self.db.query(
            "stories", where={"sprint_id": str(sprint_id)}
        )
        stories = [Story.from_dict(r) for r in stories_rows]

        counts: dict[str, int] = dict.fromkeys(_STORY_STATUSES, 0)
        points_total = 0
        points_done = 0
        for s in stories:
            counts[s.status] = counts.get(s.status, 0) + 1
            if s.points is not None:
                points_total += s.points
                if s.status == "done":
                    points_done += s.points

        return {
            "sprint": sprint.to_dict(),
            "story_counts": counts,
            "stories_total": len(stories),
            "points_total": points_total,
            "points_done": points_done,
            "percent_complete": (
                round(100 * points_done / points_total, 1)
                if points_total
                else 0.0
            ),
        }

    # -- Sessions ----------------------------------------------------------

    async def session_start(
        self,
        *,
        user_id: uuid.UUID,
        agent_name: str,
    ) -> dict[str, Any]:
        _require_str(agent_name, "agent_name")
        session = Session(
            user_id=user_id,
            agent_name=agent_name,
            status="active",
            started_at=datetime.now(UTC),
        )
        await self.db.insert("sessions", session.to_dict())
        if self.conflict_detector is not None:
            try:
                self.conflict_detector.register_session(
                    session_id=str(session.id),
                    project_id=self.default_project_id,
                    agent_name=agent_name,
                    files=[],
                )
            except Exception:
                logger.warning("Failed to register session in conflict detector", exc_info=True)
        await self._log_session_event(
            session_id=str(session.id),
            event_type="session_start",
            payload={"agent_name": agent_name},
        )
        return Session.from_dict(
            await self._required_row("sessions", session.id)
        ).to_dict()

    async def session_end(
        self,
        *,
        user_id: uuid.UUID,
        session_id: uuid.UUID,
        force: bool = False,
        override_reason: str | None = None,
        auto_confirm_threshold: float | None = None,
    ) -> dict[str, Any]:
        """Close a session.

        If there are modified files with no linked decision, returns
        ``status: "completed_with_warnings"`` and the unlinked file list.
        When ``force`` is true, the session is marked ``"completed_forced"``
        and the override is recorded.

        When ``auto_confirm_threshold`` is provided (either by the caller
        or by ``SessionConfig.auto_confirm_threshold`` in
        ``codeledger.toml``), inferred decisions with confidence at or
        above the threshold are promoted to full :class:`Decision` records
        automatically — zero-interaction memory capture.
        """
        _ = user_id
        row = await self._required_row("sessions", session_id)
        session = Session.from_dict(row)
        sid = str(session.id)

        unlinked = await self._session_unlinked_files(sid)
        if unlinked and not force:
            inferred_payload = await self._run_inference_for_session(
                session_id=sid, project_id=self.default_project_id
            )
            effective_threshold = (
                auto_confirm_threshold
                if auto_confirm_threshold is not None
                else self.auto_confirm_threshold
            )
            auto_confirmed_payload: list[dict[str, Any]] = []
            if effective_threshold is not None and inferred_payload:
                auto_confirmed_payload = await self._auto_confirm_inferred(
                    session_id=sid,
                    project_id=self.default_project_id,
                    threshold=effective_threshold,
                    user_id=user_id,
                )
            response: dict[str, Any] = {
                "status": "completed_with_warnings",
                "session_id": sid,
                "unlinked_files": unlinked,
                "message": (
                    f"Decisions were not recorded for {len(unlinked)} "
                    "modified files. Pass force: true with override_reason "
                    "to override, or review the inferred_decisions list and "
                    "call decision.confirm_inferred / decision.reject_inferred."
                ),
                "inferred_decisions": inferred_payload,
            }
            if auto_confirmed_payload:
                response["auto_confirmed_decisions"] = auto_confirmed_payload
            return response

        closed_status = "completed_forced" if (unlinked and force) else "completed"
        session.status = closed_status
        session.ended_at = datetime.now(UTC)
        session.updated_at = session.ended_at
        await self.db.update("sessions", sid, session.to_dict())
        if self.conflict_detector is not None:
            self.conflict_detector.end_session(sid)
        if force and override_reason:
            await self._log_session_event(
                session_id=sid,
                event_type="session_end_override",
                payload={
                    "override": True,
                    "override_reason": override_reason,
                    "unlinked_files": unlinked,
                },
            )
        await self._log_session_event(
            session_id=sid,
            event_type="session_end",
            payload={"status": closed_status, "forced": bool(unlinked and force)},
        )
        result: dict[str, Any] = dict(session.to_dict())
        if unlinked and force:
            result["unlinked_files"] = unlinked
            result["override_reason"] = override_reason or ""
        return result

    async def session_list(
        self,
        *,
        user_id: uuid.UUID,
        status: str | None = None,
        for_current_user: bool = False,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        where: dict[str, Any] = {}
        if status is not None:
            _validate_status(status, _SESSION_STATUSES, "session status")
            where["status"] = status
        if for_current_user:
            where["user_id"] = str(user_id)
        rows = await self.db.query(
            "sessions",
            where=where or None,
            order_by="started_at DESC",
            limit=limit,
        )
        return [Session.from_dict(r).to_dict() for r in rows]

    # -- Standup -----------------------------------------------------------

    async def standup_generate(
        self,
        *,
        user_id: uuid.UUID,
        lookback_hours: int = 24,
    ) -> dict[str, Any]:
        """Assemble a daily standup: yesterday's activity, today's plan, blockers."""
        _ensure(lookback_hours > 0, "lookback_hours must be positive")
        since = datetime.now(UTC) - timedelta(hours=lookback_hours)
        since_iso = since.isoformat()

        # Yesterday: sessions ended during the window
        recent_sessions_all = await self.db.query(
            "sessions", order_by="ended_at DESC", limit=200
        )
        recent_sessions = [
            s
            for s in recent_sessions_all
            if s.get("ended_at") and s["ended_at"] >= since_iso
        ]

        # Yesterday: decisions recorded in the window
        recent_decisions_all = await self.db.query(
            "decisions", order_by="created_at DESC", limit=200
        )
        recent_decisions = [
            d for d in recent_decisions_all if d.get("created_at", "") >= since_iso
        ]

        # Today's plan: in-progress stories
        in_progress = await self.db.query(
            "stories", where={"status": "in_progress"}
        )

        # Blockers: failed or unverified-too-long decisions
        failed = await self.db.query(
            "decisions", where={"status": "failed"}, limit=50
        )

        return {
            "generated_at": _now_iso(),
            "window": {
                "lookback_hours": lookback_hours,
                "since": since_iso,
            },
            "user_id": str(user_id),
            "yesterday": {
                "sessions_ended": len(recent_sessions),
                "decisions_recorded": len(recent_decisions),
                "decisions": [
                    {"id": d["id"], "title": d["title"], "status": d["status"]}
                    for d in recent_decisions
                ],
            },
            "today": {
                "in_progress_stories": [
                    {"id": s["id"], "title": s["title"]} for s in in_progress
                ],
            },
            "blockers": [
                {"id": d["id"], "title": d["title"]} for d in failed
            ],
        }

    # -- Phase 2: Semantic retrieval --------------------------------------

    async def context_get_relevant(
        self,
        *,
        user_id: uuid.UUID,
        query: str | None = None,
        file_path: str | None = None,
        file_content: str | None = None,
        project_id: str | None = None,
        token_budget: int | None = None,
        top_k: int = 10,
        persona: str | None = None,
        blend_weight: float = 0.6,
    ) -> dict[str, Any]:
        """Return a triaged context block for ``query`` or a specific file.

        Either ``query`` or ``file_path`` must be supplied. When
        ``file_path`` is given, ``file_content`` supplements the path in
        the retrieval query. The result bundles both the rendered text
        block for direct injection into an agent's context and a
        structured item list for programmatic consumers.
        """
        _ = user_id
        if self.semantic_search is None or self.context_triage is None:
            raise HandlerError(
                "Semantic retrieval is not enabled on this server"
            )
        _enforce_size(query, "query", MAX_QUERY_LEN)
        _enforce_size(file_path, "file_path", MAX_FILE_PATH_LEN)
        _enforce_size(file_content, "file_content", MAX_FILE_CONTENT_LEN)
        project = project_id or self.default_project_id
        budget = (
            token_budget if token_budget is not None else self.default_token_budget
        )
        _ensure(
            isinstance(budget, int) and budget > 0 and not isinstance(budget, bool),
            "token_budget must be a positive int",
        )
        _ensure(
            isinstance(top_k, int) and top_k > 0 and not isinstance(top_k, bool),
            "top_k must be a positive int",
        )
        if file_path:
            if not isinstance(file_path, str):
                raise HandlerError("file_path must be a string")
            # search_by_file defaults blend to 0.5 when caller keeps the
            # default 0.6; otherwise respect the explicit override.
            file_blend = blend_weight if blend_weight != 0.6 else 0.5
            results = await self.semantic_search.search_by_file(
                file_path=file_path,
                file_content=file_content or "",
                project_id=project,
                top_k=top_k,
                persona=persona,
                blend_weight=file_blend,
            )
            context_for = file_path
        elif query:
            results = await self.semantic_search.search(
                query=query,
                project_id=project,
                top_k=top_k,
                persona=persona,
                blend_weight=blend_weight,
            )
            context_for = query
        else:
            raise HandlerError(
                "Either query or file_path must be provided"
            )

        triage_result = self.context_triage.triage(results, budget)
        block = format_context_block(triage_result, context_for=context_for)
        await self._touch_decisions_from_triage(triage_result)
        return {
            "context_block": block,
            "context_for": context_for,
            "project_id": project,
            "token_budget": budget,
            "total_tokens_used": triage_result.total_tokens_used,
            "budget_remaining": triage_result.budget_remaining,
            "included_items": [
                {
                    "item_id": t.item_id,
                    "item_type": t.item_type,
                    "score": t.score,
                    "token_count": t.token_count,
                    "was_summarised": False,
                }
                for t in triage_result.included_items
            ],
            "summarized_items": [
                {
                    "item_id": t.item_id,
                    "item_type": t.item_type,
                    "score": t.score,
                    "token_count": t.token_count,
                    "was_summarised": True,
                }
                for t in triage_result.summarized_items
            ],
            "excluded_summary": triage_result.excluded_summary,
            "excluded_items": [
                {
                    "item_id": e.item_id,
                    "item_type": e.item_type,
                    "score": e.score,
                    "topic": e.topic,
                }
                for e in triage_result.excluded_items
            ],
        }

    async def context_get_for_file(
        self,
        *,
        user_id: uuid.UUID,
        file_path: str,
        file_content: str = "",
        project_id: str | None = None,
        token_budget: int | None = None,
        top_k: int = 10,
        blend_weight: float = 0.5,
    ) -> dict[str, Any]:
        """File-specific shortcut for :meth:`context_get_relevant`.

        Appends a ``file_context`` field with the top-3 decisions most
        relevant to ``file_path`` — this gives clients without a
        PreToolUse hook (Cursor, Windsurf) an inline file-aware block
        without needing a separate ``context.before_edit`` call.
        """
        _require_str(file_path, "file_path")
        response = await self.context_get_relevant(
            user_id=user_id,
            file_path=file_path,
            file_content=file_content,
            project_id=project_id,
            token_budget=token_budget,
            top_k=top_k,
            blend_weight=blend_weight,
        )
        response["file_context"] = await self._file_context_side_effect(
            file_path=file_path,
            file_content=file_content,
            project_id=project_id or self.default_project_id,
        )
        return response

    # -- Phase 2: Provenance tracing --------------------------------------

    async def decision_trace(
        self,
        *,
        user_id: uuid.UUID,
        decision_id: uuid.UUID,
    ) -> dict[str, Any]:
        """Return the forward provenance chain for a decision.

        Produces ``{decision, commits: [{commit_hash, ast_changes: [...]}]}``.
        """
        _ = user_id
        decision_row = await self._required_row("decisions", decision_id)
        edges = await self.db.query(
            "provenance_edges",
            where={
                "source_type": "decision",
                "source_id": str(decision_id),
                "target_type": "ast_change",
            },
        )
        commits: dict[str, list[dict[str, Any]]] = {}
        primary_file: str = ""
        for edge in edges:
            change = await self.db.get_by_id(
                "ast_changes", str(edge["target_id"])
            )
            if change is None:
                continue
            commit_hash = str(change.get("commit_hash") or "")
            commits.setdefault(commit_hash, []).append(change)
            if not primary_file:
                primary_file = str(change.get("file_path") or "")
        return {
            "decision": Decision.from_dict(decision_row).to_dict(),
            "file_context": await self._file_context_side_effect(
                file_path=primary_file,
                file_content="",
                project_id=self.default_project_id,
            ),
            "commits": [
                {
                    "commit_hash": commit_hash,
                    "ast_changes": changes,
                }
                for commit_hash, changes in commits.items()
            ],
        }

    async def decision_reverse_trace(
        self,
        *,
        user_id: uuid.UUID,
        file_path: str,
        entity_name: str,
    ) -> dict[str, Any]:
        """Return decisions that touched the given file/entity combination.

        Produces ``{changes, decisions}`` — every AST change affecting the
        entity plus the distinct decisions linked to any of those changes,
        ordered by ``created_at`` descending.
        """
        _ = user_id
        _require_str(file_path, "file_path")
        _require_str(entity_name, "entity_name")
        changes = await self.db.query(
            "ast_changes",
            where={"file_path": file_path, "entity_name": entity_name},
            order_by="created_at DESC",
        )
        file_ctx = await self._file_context_side_effect(
            file_path=file_path,
            file_content="",
            project_id=self.default_project_id,
        )
        if not changes:
            return {
                "changes": [],
                "decisions": [],
                "file_context": file_ctx,
            }

        seen_decisions: set[str] = set()
        decision_rows: list[dict[str, Any]] = []
        for change in changes:
            edges = await self.db.query(
                "provenance_edges",
                where={
                    "target_type": "ast_change",
                    "target_id": str(change["id"]),
                    "source_type": "decision",
                },
            )
            for edge in edges:
                source_id = str(edge["source_id"])
                if source_id in seen_decisions:
                    continue
                seen_decisions.add(source_id)
                row = await self.db.get_by_id("decisions", source_id)
                if row is not None:
                    decision_rows.append(row)
        decision_rows.sort(
            key=lambda r: str(r.get("created_at") or ""), reverse=True
        )
        return {
            "changes": changes,
            "decisions": [
                Decision.from_dict(r).to_dict() for r in decision_rows
            ],
            "file_context": file_ctx,
        }

    # -- Internal helpers --------------------------------------------------

    async def _maybe_index(
        self,
        *,
        item_id: str,
        text: str,
        item_type: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Index ``text`` for semantic retrieval when a store is configured."""
        if self.semantic_search is None or not text:
            return
        try:
            await self.semantic_search.index_item(
                item_id=item_id,
                text=text,
                item_type=item_type,
                project_id=self.default_project_id,
                metadata=metadata or {},
            )
        except Exception:
            # Indexing is best-effort — retrieval degrades gracefully if
            # the vector store is temporarily unreachable. The failure is
            # logged (sanitised) but must not break the primary write path.
            logger.warning(
                "Failed to index %s %s for semantic retrieval",
                item_type,
                item_id,
                exc_info=True,
            )

    async def _maybe_reindex(self, item_id: str, new_text: str) -> None:
        if self.semantic_search is None or not new_text:
            return
        try:
            await self.semantic_search.reindex_item(
                item_id=item_id, new_text=new_text
            )
        except Exception:
            logger.warning(
                "Failed to reindex %s for semantic retrieval",
                item_id,
                exc_info=True,
            )

    async def _maybe_remove(self, item_id: str) -> None:
        if self.semantic_search is None:
            return
        try:
            await self.semantic_search.remove_item(item_id=item_id)
        except Exception:
            logger.warning(
                "Failed to remove %s from semantic store", item_id, exc_info=True
            )

    async def _required_row(
        self, table: str, row_id: uuid.UUID | str
    ) -> dict[str, Any]:
        row = await self.db.get_by_id(table, str(row_id))
        if row is None:
            raise HandlerError(f"Not found: {table}/{row_id}")
        return row

    # ------------------------------------------------------------------
    # Phase 3: session events, replay, conflicts, verify, provenance, harness
    # ------------------------------------------------------------------

    async def _log_session_event(
        self,
        *,
        session_id: str,
        event_type: str,
        payload: dict[str, Any],
    ) -> None:
        """Append a SessionEvent row. Best-effort; never raises."""
        if not self._session_events_enabled or not session_id:
            return
        try:
            now_iso = _now_iso()
            await self.db.insert(
                "session_events",
                {
                    "id": str(_uuid_mod.uuid4()),
                    "session_id": session_id,
                    "event_type": event_type,
                    "payload": json.dumps(payload),
                    "created_at": now_iso,
                    "updated_at": now_iso,
                },
            )
        except Exception:
            logger.warning(
                "Failed to log session event %s for %s",
                event_type,
                session_id,
                exc_info=True,
            )

    async def _session_unlinked_files(self, session_id: str) -> list[str]:
        """Return the list of file paths modified in this session without a decision."""
        rows = await self.db.query(
            "ast_changes", where={"session_id": session_id}
        )
        unlinked_files: set[str] = set()
        for row in rows:
            edges = await self.db.query(
                "provenance_edges",
                where={
                    "target_type": "ast_change",
                    "target_id": str(row["id"]),
                    "source_type": "decision",
                },
            )
            if not edges:
                fp = str(row.get("file_path") or "")
                if fp:
                    unlinked_files.add(fp)
        return sorted(unlinked_files)

    async def session_replay(
        self, *, user_id: uuid.UUID, session_id: uuid.UUID
    ) -> dict[str, Any]:
        """Return the full SessionEvent timeline for a session."""
        _ = user_id
        await self._required_row("sessions", session_id)
        events = await self.db.query(
            "session_events",
            where={"session_id": str(session_id)},
            order_by="created_at ASC",
        )
        timeline: list[dict[str, Any]] = []
        for evt in events:
            payload_raw = evt.get("payload") or "{}"
            try:
                payload = json.loads(payload_raw) if isinstance(payload_raw, str) else payload_raw
            except json.JSONDecodeError:
                payload = {"raw": payload_raw}
            timeline.append(
                {
                    "id": evt["id"],
                    "event_type": evt.get("event_type", ""),
                    "created_at": evt.get("created_at", ""),
                    "payload": payload,
                }
            )
        return {
            "session_id": str(session_id),
            "event_count": len(timeline),
            "timeline": timeline,
        }

    async def session_conflicts(
        self,
        *,
        user_id: uuid.UUID,
        session_id: uuid.UUID,
        project_id: str | None = None,
    ) -> dict[str, Any]:
        """Return currently active conflicts for a session."""
        _ = user_id
        pid = project_id or self.default_project_id
        if self.conflict_detector is None:
            return {"session_id": str(session_id), "conflicts": []}
        conflicts = await self.conflict_detector.check_conflicts(
            str(session_id), pid
        )
        return {
            "session_id": str(session_id),
            "project_id": pid,
            "conflicts": [
                {
                    "conflicting_session_id": c.conflicting_session_id,
                    "conflicting_agent": c.conflicting_agent,
                    "overlapping_files": c.overlapping_files,
                    "overlapping_decisions": c.overlapping_decisions,
                    "severity": c.severity,
                }
                for c in conflicts
            ],
        }

    async def verify_status(
        self,
        *,
        user_id: uuid.UUID,
        decision_id: uuid.UUID,
    ) -> dict[str, Any]:
        """Return CI verification status. Degrades gracefully in file_watcher mode."""
        _ = user_id
        if self.verifier is None:
            row = await self._required_row("decisions", decision_id)
            return {
                "decision_id": str(decision_id),
                "status": row.get("status", "unverified"),
                "verification_available": self.change_detection_backend == "git",
                "change_detection_backend": self.change_detection_backend,
            }
        return await self.verifier.get_status(
            decision_id,
            change_detection_backend=self.change_detection_backend,  # type: ignore[arg-type]
        )

    async def verify_list_unverified(
        self,
        *,
        user_id: uuid.UUID,
        project_id: str | None = None,
    ) -> dict[str, Any]:
        """Return decisions whose status is not yet ``passed``."""
        _ = user_id
        pid = project_id or self.default_project_id
        if self.verifier is None:
            return {
                "verification_available": self.change_detection_backend == "git",
                "change_detection_backend": self.change_detection_backend,
                "project_id": pid,
                "decisions": [],
            }
        return await self.verifier.get_unverified(
            pid,
            change_detection_backend=self.change_detection_backend,  # type: ignore[arg-type]
        )

    async def provenance_forward(
        self,
        *,
        user_id: uuid.UUID,
        decision_id: uuid.UUID,
    ) -> dict[str, Any]:
        """Forward provenance trace — decision → change events → AST changes."""
        _ = user_id
        if self.provenance is None:
            raise HandlerError(
                "Provenance engine is not enabled on this server"
            )
        tree = await self.provenance.forward_trace(decision_id)
        return {
            "decision": tree.decision,
            "change_events": [
                {
                    "change_event_id": e.change_event_id,
                    "change_event_type": e.change_event_type,
                    "label": e.label,
                    "date": e.date,
                    "ast_changes": e.ast_changes,
                }
                for e in tree.change_events
            ],
        }

    async def provenance_reverse(
        self,
        *,
        user_id: uuid.UUID,
        file_path: str,
        entity_name: str,
        project_id: str | None = None,
    ) -> dict[str, Any]:
        """Reverse provenance — file/entity → decisions that authored changes."""
        _ = user_id
        _require_str(file_path, "file_path")
        _require_str(entity_name, "entity_name")
        pid = project_id or self.default_project_id
        if self.provenance is None:
            raise HandlerError(
                "Provenance engine is not enabled on this server"
            )
        results = await self.provenance.reverse_trace(
            file_path=file_path, entity_name=entity_name, project_id=pid
        )
        return {
            "file_path": file_path,
            "entity_name": entity_name,
            "project_id": pid,
            "results": [
                {
                    "decision": r.decision,
                    "change_event_id": r.change_event_id,
                    "change_event_type": r.change_event_type,
                    "change_event_label": r.change_event_label,
                    "ast_change": r.ast_change,
                    "confidence_score": r.confidence_score,
                }
                for r in results
            ],
        }

    async def harness_score(
        self,
        *,
        user_id: uuid.UUID,
        session_id: uuid.UUID,
        project_id: str | None = None,
    ) -> dict[str, Any]:
        """Aggregate harness signals across every change event in a session."""
        _ = user_id
        pid = project_id or self.default_project_id
        if self.harness is None:
            raise HandlerError(
                "Quality harness is not enabled on this server"
            )
        score = await self.harness.score_session(
            session_id,
            pid,
            change_detection_backend=self.change_detection_backend,  # type: ignore[arg-type]
        )
        return {
            "session_id": score.session_id,
            "change_detection_backend": score.change_detection_backend,
            "structural_changes": score.structural_changes,
            "decisions_recorded": score.decisions_recorded,
            "decision_density": score.decision_density,
            "decision_density_status": score.decision_density_status,
            "harness_status": score.harness_status,
            "session_coverage_metric": score.session_coverage_metric,
            "per_event_scores": [
                {
                    "change_event_id": ps.change_event_id,
                    "change_event_type": ps.change_event_type,
                    "coverage_delta": ps.coverage_delta,
                    "complexity_score": ps.complexity_score,
                    "import_health": ps.import_health,
                    "drift_violations": ps.drift_violations,
                    "decision_density": ps.decision_density,
                    "decision_density_status": ps.decision_density_status,
                    "harness_status": ps.harness_status,
                }
                for ps in score.per_event_scores
            ],
        }

    # ------------------------------------------------------------------
    # Phase 5: drift, tautology, rollback
    # ------------------------------------------------------------------

    async def drift_check(
        self,
        *,
        user_id: uuid.UUID,
        project_id: str | None = None,
        repo_path: str | None = None,
    ) -> dict[str, Any]:
        _ = user_id
        if self.drift_detector is None:
            raise HandlerError("Drift detector is not enabled on this server")
        pid = project_id or self.default_project_id
        path = repo_path or self.project_root
        return await self.drift_detector.drift_report(pid, path)

    async def drift_report(
        self,
        *,
        user_id: uuid.UUID,
        project_id: str | None = None,
        repo_path: str | None = None,
    ) -> dict[str, Any]:
        return await self.drift_check(
            user_id=user_id, project_id=project_id, repo_path=repo_path
        )

    async def test_check_tautology(
        self,
        *,
        user_id: uuid.UUID,
        project_id: str | None = None,
        repo_path: str | None = None,
    ) -> dict[str, Any]:
        _ = user_id
        if self.tautology_detector is None:
            raise HandlerError(
                "Tautology detector is not enabled on this server"
            )
        pid = project_id or self.default_project_id
        path = repo_path or self.project_root
        return await self.tautology_detector.check_tests_report(pid, path)

    async def rollback_plan(
        self,
        *,
        user_id: uuid.UUID,
        decision_id: uuid.UUID,
    ) -> dict[str, Any]:
        _ = user_id
        if self.rollback_planner is None:
            raise HandlerError(
                "Rollback planner is not enabled on this server"
            )
        return await self.rollback_planner.plan_rollback_dict(decision_id)

    # ------------------------------------------------------------------
    # Passive inference (Phase 2 upgrade)
    # ------------------------------------------------------------------

    async def _auto_confirm_inferred(
        self,
        *,
        session_id: str,
        project_id: str,
        threshold: float,
        user_id: uuid.UUID,
    ) -> list[dict[str, Any]]:
        """Invoke the inferrer's auto-confirm path and index resulting decisions."""
        inferrer = self.decision_inferrer or DecisionInferrer(db=self.db)
        try:
            promoted = await inferrer.auto_confirm_high_confidence(
                session_id=session_id,
                project_id=project_id,
                threshold=threshold,
                recorded_by_user_id=user_id,
            )
        except ValueError:
            raise
        except Exception:
            logger.warning(
                "auto_confirm_high_confidence failed for session %s",
                session_id,
                exc_info=True,
            )
            return []
        payload: list[dict[str, Any]] = []
        for decision in promoted:
            await self._maybe_index(
                item_id=str(decision.id),
                text=f"{decision.title}\n\n{decision.description}".strip(),
                item_type="decision",
                metadata={
                    "title": decision.title,
                    "tags": list(decision.tags),
                    "auto_confirmed": True,
                },
            )
            payload.append(Decision.from_dict(decision.to_dict()).to_dict())
        return payload

    async def _run_inference_for_session(
        self, *, session_id: str, project_id: str
    ) -> list[dict[str, Any]]:
        """Run the :class:`DecisionInferrer` and persist qualifying candidates."""
        inferrer = self.decision_inferrer or DecisionInferrer(db=self.db)
        try:
            candidates = await inferrer.infer_from_session(
                session_id=session_id, project_id=project_id
            )
        except Exception:
            logger.warning(
                "Decision inference failed for session %s", session_id,
                exc_info=True,
            )
            return []

        persisted: list[dict[str, Any]] = []
        for candidate in candidates:
            if candidate.confidence < 0.45:
                continue
            try:
                await self.db.insert(
                    "inferred_decisions", candidate.to_dict()
                )
            except Exception:
                logger.warning(
                    "Failed to persist InferredDecision %s",
                    candidate.id,
                    exc_info=True,
                )
                continue
            persisted.append(
                {
                    "inferred_decision_id": str(candidate.id),
                    "candidate_title": candidate.candidate_title,
                    "files_affected": candidate.files_affected,
                    "confidence": candidate.confidence,
                    "inference_source": candidate.inference_source,
                }
            )
        return persisted

    async def decision_confirm_inferred(
        self,
        *,
        user_id: uuid.UUID,
        inferred_decision_id: uuid.UUID,
        description: str | None = None,
        tags: list[str] | None = None,
    ) -> dict[str, Any]:
        """Promote a pending InferredDecision into a full Decision."""
        row = await self._required_row(
            "inferred_decisions", inferred_decision_id
        )
        status = str(row.get("status") or "")
        if status == "confirmed":
            raise HandlerError(
                f"InferredDecision {inferred_decision_id} is already confirmed"
            )
        if status == "rejected":
            raise HandlerError(
                f"InferredDecision {inferred_decision_id} was rejected — "
                "cannot confirm."
            )

        inferred = InferredDecision.from_dict(row)
        final_description = (
            description if description is not None else inferred.candidate_description
        )
        final_tags = list(tags) if tags is not None else list(inferred.candidate_tags)
        final_tags = [t for t in final_tags if t != "inferred"]
        session_uuid = inferred.session_id
        decision = Decision(
            title=inferred.candidate_title,
            description=final_description,
            tags=final_tags,
            status="unverified",
            recorded_by_user_id=user_id,
            recorded_in_session_id=session_uuid,
            inference_status="confirmed",
            inference_confidence=inferred.confidence,
        )
        await self.db.insert("decisions", decision.to_dict())
        await self._maybe_index(
            item_id=str(decision.id),
            text=f"{decision.title}\n\n{decision.description}".strip(),
            item_type="decision",
            metadata={"title": decision.title, "tags": list(decision.tags)},
        )
        await self.db.update(
            "inferred_decisions",
            str(inferred.id),
            {
                "status": "confirmed",
                "updated_at": _now_iso(),
            },
        )
        return {
            "decision": Decision.from_dict(
                await self._required_row("decisions", decision.id)
            ).to_dict(),
            "files_affected": inferred.files_affected,
            "inferred_decision_id": str(inferred.id),
        }

    async def decision_reject_inferred(
        self,
        *,
        user_id: uuid.UUID,
        inferred_decision_id: uuid.UUID,
        reason: str,
    ) -> dict[str, Any]:
        """Mark a pending InferredDecision as rejected."""
        _ = user_id
        _require_str(reason, "reason")
        row = await self._required_row(
            "inferred_decisions", inferred_decision_id
        )
        current = str(row.get("status") or "")
        if current == "rejected":
            return {
                "status": "rejected",
                "inferred_decision_id": str(inferred_decision_id),
                "already_rejected": True,
            }
        existing_desc = row.get("candidate_description", "")
        new_desc = f"{existing_desc}\n\n[Rejected] {reason}"
        await self.db.update(
            "inferred_decisions",
            str(inferred_decision_id),
            {
                "status": "rejected",
                "candidate_description": new_desc,
                "updated_at": _now_iso(),
            },
        )
        return {
            "status": "rejected",
            "inferred_decision_id": str(inferred_decision_id),
            "reason": reason,
        }

    async def _file_context_side_effect(
        self,
        *,
        file_path: str,
        file_content: str,
        project_id: str,
    ) -> list[dict[str, Any]]:
        """Top-3 file-relevant decisions appended to file-scoped tool responses."""
        if not file_path or self.semantic_search is None:
            return []
        try:
            results = await self.semantic_search.search_by_file(
                file_path=file_path,
                file_content=file_content or "",
                project_id=project_id,
                top_k=3,
                blend_weight=0.5,
            )
        except Exception:
            logger.debug(
                "_file_context_side_effect failed for %s",
                file_path,
                exc_info=True,
            )
            return []
        return [
            {
                "item_id": r.item_id,
                "item_type": r.item_type,
                "score": r.score,
                "title": r.metadata.get("title", "")
                if isinstance(r.metadata, dict)
                else "",
                "retrieval_method": r.retrieval_method,
            }
            for r in results
        ]

    async def _touch_decisions_from_triage(self, triage_result: Any) -> None:
        """Batch-update access tracking for every decision returned."""
        decision_ids: list[str] = []
        for section in (
            getattr(triage_result, "included_items", []) or [],
            getattr(triage_result, "summarized_items", []) or [],
        ):
            for item in section:
                if getattr(item, "item_type", "") == "decision":
                    decision_ids.append(str(item.item_id))
        if not decision_ids:
            return
        placeholders = ", ".join("?" for _ in decision_ids)
        now_iso = _now_iso()
        # Single batched statement — one query for the whole triage result.
        try:
            await self.db.execute_raw(
                f"UPDATE decisions SET "
                f"last_accessed_at = ?, "
                f"access_count = access_count + 1, "
                f"updated_at = ? "
                f"WHERE id IN ({placeholders})",
                (now_iso, now_iso, *decision_ids),
            )
        except Exception:
            logger.warning(
                "Batch access-tracking update failed for %d decisions",
                len(decision_ids),
                exc_info=True,
            )

    # ------------------------------------------------------------------
    # Staleness lifecycle
    # ------------------------------------------------------------------

    async def decision_supersede(
        self,
        *,
        user_id: uuid.UUID,
        decision_id: uuid.UUID,
        new_decision_id: uuid.UUID,
        reason: str,
    ) -> dict[str, Any]:
        """Record that ``new_decision_id`` supersedes ``decision_id``."""
        _ = user_id
        _require_str(reason, "reason")
        old_row = await self._required_row("decisions", decision_id)
        new_row = await self._required_row("decisions", new_decision_id)

        existing_signals_raw = old_row.get("staleness_signals") or "[]"
        try:
            signals = json.loads(existing_signals_raw) if isinstance(
                existing_signals_raw, str
            ) else list(existing_signals_raw)
        except json.JSONDecodeError:
            signals = []
        if not isinstance(signals, list):
            signals = []
        signals.append(f"Superseded: {reason}")

        now_iso = _now_iso()
        await self.db.update(
            "decisions",
            str(decision_id),
            {
                "superseded_by": str(new_decision_id),
                "staleness_score": 1.0,
                "staleness_signals": json.dumps(signals),
                "updated_at": now_iso,
            },
        )
        await self.db.update(
            "decisions",
            str(new_decision_id),
            {
                "supersedes": str(decision_id),
                "updated_at": now_iso,
            },
        )
        return {
            "old_decision": Decision.from_dict(
                await self._required_row("decisions", decision_id)
            ).to_dict(),
            "new_decision": Decision.from_dict(
                await self._required_row("decisions", new_decision_id)
            ).to_dict(),
            "reason": reason,
            "_new_row_id": str(new_row["id"]),  # retained for traceability
        }

    async def decision_staleness_report(
        self,
        *,
        user_id: uuid.UUID,
        project_id: str | None = None,
    ) -> dict[str, Any]:
        """Return decisions with staleness_score > 0.3, sorted descending."""
        _ = user_id
        pid = project_id or self.default_project_id
        if self.staleness_scorer is None:
            self.staleness_scorer = StalenessScorer(self.db)
        await self.staleness_scorer.score_project(pid)

        decisions = await self.db.query("decisions")
        flagged: list[dict[str, Any]] = []
        for row in decisions:
            score = float(row.get("staleness_score") or 0.0)
            if score <= 0.3:
                continue
            raw_signals = row.get("staleness_signals") or "[]"
            try:
                signals = (
                    json.loads(raw_signals)
                    if isinstance(raw_signals, str)
                    else list(raw_signals)
                )
            except json.JSONDecodeError:
                signals = []
            flagged.append(
                {
                    "decision_id": str(row["id"]),
                    "title": row.get("title", ""),
                    "staleness_score": score,
                    "staleness_signals": signals,
                    "last_accessed_at": row.get("last_accessed_at"),
                    "superseded_by": row.get("superseded_by"),
                }
            )
        flagged.sort(key=lambda r: float(r["staleness_score"]), reverse=True)
        return {"project_id": pid, "decisions": flagged}

    async def decision_list_conflicts(
        self,
        *,
        user_id: uuid.UUID,
        project_id: str | None = None,
    ) -> dict[str, Any]:
        """Return all active DecisionConflict records, ordered by confidence."""
        _ = user_id
        pid = project_id or self.default_project_id
        if self.staleness_scorer is None:
            self.staleness_scorer = StalenessScorer(self.db)
        conflicts = await self.staleness_scorer._load_active_conflicts(pid)
        return {
            "project_id": pid,
            "conflicts": [
                {
                    "conflict_id": str(c.id),
                    "decision_id_a": c.decision_id_a,
                    "decision_id_b": c.decision_id_b,
                    "conflict_type": c.conflict_type,
                    "confidence": c.confidence,
                    "description": c.description,
                    "detected_at": c.detected_at.isoformat()
                    if hasattr(c.detected_at, "isoformat")
                    else c.detected_at,
                    "status": c.status,
                }
                for c in conflicts
            ],
        }

    async def decision_resolve_conflict(
        self,
        *,
        user_id: uuid.UUID,
        conflict_id: uuid.UUID,
        resolution_decision_id: uuid.UUID,
        notes: str,
    ) -> dict[str, Any]:
        """Resolve a conflict by naming the decision that takes precedence."""
        _ = user_id
        _require_str(notes, "notes")
        row = await self._required_row("decision_conflicts", conflict_id)
        if str(row.get("status") or "") == "resolved":
            return {
                "conflict_id": str(conflict_id),
                "status": "resolved",
                "already_resolved": True,
            }
        a = str(row.get("decision_id_a") or "")
        b = str(row.get("decision_id_b") or "")
        resolver = str(resolution_decision_id)
        now_iso = _now_iso()

        superseded_of: str | None = None
        superseding_of: str | None = None
        if resolver == a:
            superseded_of = b
            superseding_of = a
        elif resolver == b:
            superseded_of = a
            superseding_of = b

        if superseded_of and superseding_of:
            await self.db.update(
                "decisions",
                superseded_of,
                {
                    "superseded_by": superseding_of,
                    "staleness_score": 1.0,
                    "staleness_signals": json.dumps(
                        [f"Superseded via conflict resolution: {notes}"]
                    ),
                    "updated_at": now_iso,
                },
            )
            await self.db.update(
                "decisions",
                superseding_of,
                {"supersedes": superseded_of, "updated_at": now_iso},
            )

        await self.db.update(
            "decision_conflicts",
            str(conflict_id),
            {
                "status": "resolved",
                "resolved_by_decision_id": resolver,
                "description": f"{row.get('description', '')}\n\n[Resolved] {notes}",
                "updated_at": now_iso,
            },
        )
        return {
            "conflict_id": str(conflict_id),
            "status": "resolved",
            "resolution_decision_id": resolver,
            "superseded_decision_id": superseded_of,
            "notes": notes,
        }

    async def decision_confirm_fresh(
        self,
        *,
        user_id: uuid.UUID,
        decision_id: uuid.UUID,
    ) -> dict[str, Any]:
        """Reset staleness tracking on a decision after developer review."""
        _ = user_id
        await self._required_row("decisions", decision_id)
        now_iso = _now_iso()
        await self.db.update(
            "decisions",
            str(decision_id),
            {
                "staleness_score": 0.0,
                "staleness_signals": json.dumps([]),
                "last_accessed_at": now_iso,
                "updated_at": now_iso,
            },
        )
        return Decision.from_dict(
            await self._required_row("decisions", decision_id)
        ).to_dict()

    async def decision_list_pending_inferred(
        self,
        *,
        user_id: uuid.UUID,
        project_id: str | None = None,
        session_id: uuid.UUID | None = None,
    ) -> list[dict[str, Any]]:
        """List pending InferredDecision records, ordered by confidence desc."""
        _ = user_id
        where: dict[str, Any] = {"status": "pending"}
        if session_id is not None:
            where["session_id"] = str(session_id)
        elif project_id is not None:
            where["project_id"] = project_id
        else:
            where["project_id"] = self.default_project_id
        rows = await self.db.query("inferred_decisions", where=where)
        rows.sort(
            key=lambda r: float(r.get("confidence") or 0.0), reverse=True
        )
        return [InferredDecision.from_dict(r).to_dict() for r in rows]

    # ------------------------------------------------------------------
    # Phase 6: knowledge packs, agent profiling, search, sprint intel
    # ------------------------------------------------------------------

    async def knowledge_export(
        self,
        *,
        user_id: uuid.UUID,
        decision_ids: list[str],
        pack_name: str,
        project_id: str | None = None,
    ) -> dict[str, Any]:
        _ = user_id
        if self.knowledge_packs is None:
            raise HandlerError("Knowledge pack manager is not enabled")
        pid = project_id or self.default_project_id
        pack = await self.knowledge_packs.export_pack(pid, decision_ids, pack_name)
        return {
            "pack_name": pack.pack_name,
            "decision_count": len(pack.decisions),
            "created_at": pack.created_at,
            "source_project_id": pack.source_project_id,
            "decisions": pack.decisions,
        }

    async def knowledge_import(
        self,
        *,
        user_id: uuid.UUID,
        pack_payload: dict[str, Any],
        project_id: str | None = None,
    ) -> dict[str, Any]:
        _ = user_id
        if self.knowledge_packs is None:
            raise HandlerError("Knowledge pack manager is not enabled")
        from backend.advanced.knowledge_packs import KnowledgePack

        pid = project_id or self.default_project_id
        pack = KnowledgePack(
            pack_name=str(pack_payload.get("pack_name") or ""),
            decisions=list(pack_payload.get("decisions") or []),
            embeddings=dict(pack_payload.get("embeddings") or {}),
            source_project_id=pack_payload.get("source_project_id"),
        )
        return await self.knowledge_packs.import_pack(pid, pack)

    async def knowledge_list_exportable(
        self,
        *,
        user_id: uuid.UUID,
        project_id: str | None = None,
    ) -> dict[str, Any]:
        _ = user_id
        if self.knowledge_packs is None:
            raise HandlerError("Knowledge pack manager is not enabled")
        pid = project_id or self.default_project_id
        decisions = await self.knowledge_packs.list_exportable(pid)
        return {"project_id": pid, "decisions": decisions}

    async def knowledge_list_packs(
        self,
        *,
        user_id: uuid.UUID,
        project_id: str | None = None,
    ) -> dict[str, Any]:
        """Persistent packs are not yet stored in the DB — stub for surface."""
        _ = user_id
        pid = project_id or self.default_project_id
        return {"project_id": pid, "packs": []}

    async def agent_profile(
        self,
        *,
        user_id: uuid.UUID,
        agent_name: str,
        project_id: str | None = None,
    ) -> dict[str, Any]:
        _ = user_id
        if self.agent_profiler is None:
            raise HandlerError("Agent profiler is not enabled")
        pid = project_id or self.default_project_id
        return await self.agent_profiler.get_profile_dict(agent_name, pid)

    async def agent_recommend(
        self,
        *,
        user_id: uuid.UUID,
        story_id: uuid.UUID,
        project_id: str | None = None,
    ) -> dict[str, Any]:
        _ = user_id
        if self.agent_profiler is None:
            raise HandlerError("Agent profiler is not enabled")
        pid = project_id or self.default_project_id
        recs = await self.agent_profiler.recommend_agent(str(story_id), pid)
        return {
            "story_id": str(story_id),
            "project_id": pid,
            "recommendations": [
                {
                    "agent_name": r.agent_name,
                    "score": r.score,
                    "reason": r.reason,
                }
                for r in recs
            ],
        }

    async def agent_context_adjustment(
        self,
        *,
        user_id: uuid.UUID,
        agent_name: str,
        story_id: uuid.UUID,
    ) -> dict[str, Any]:
        _ = user_id
        if self.agent_profiler is None:
            raise HandlerError("Agent profiler is not enabled")
        return await self.agent_profiler.get_context_adjustment(
            agent_name, str(story_id)
        )

    # -- Search helpers ----------------------------------------------------

    async def decision_search(
        self,
        *,
        user_id: uuid.UUID,
        query: str,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        _ = user_id
        _require_str(query, "query")
        q = query.lower()
        rows = await self.db.query("decisions", order_by="created_at DESC", limit=limit * 5)
        matched = [
            r
            for r in rows
            if q in str(r.get("title") or "").lower()
            or q in str(r.get("description") or "").lower()
        ]
        return [Decision.from_dict(r).to_dict() for r in matched[:limit]]

    async def story_search(
        self,
        *,
        user_id: uuid.UUID,
        query: str,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        _ = user_id
        _require_str(query, "query")
        q = query.lower()
        rows = await self.db.query(
            "stories", order_by="created_at DESC", limit=limit * 5
        )
        matched = [
            r
            for r in rows
            if q in str(r.get("title") or "").lower()
            or q in str(r.get("description") or "").lower()
        ]
        return [Story.from_dict(r).to_dict() for r in matched[:limit]]

    async def session_search(
        self,
        *,
        user_id: uuid.UUID,
        query: str,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        _ = user_id
        _require_str(query, "query")
        q = query.lower()
        rows = await self.db.query(
            "sessions", order_by="started_at DESC", limit=limit * 5
        )
        matched = [
            r
            for r in rows
            if q in str(r.get("agent_name") or "").lower()
        ]
        return [Session.from_dict(r).to_dict() for r in matched[:limit]]

    # -- Project management ------------------------------------------------

    async def project_create(
        self,
        *,
        user_id: uuid.UUID,
        project_id: str,
        name: str,
    ) -> dict[str, Any]:
        _ = user_id
        _require_str(project_id, "project_id")
        _require_str(name, "name")
        # Projects are currently represented by project_id tags on rows.
        # This handler exists to reserve the API surface and return
        # metadata for the caller.
        return {"project_id": project_id, "name": name, "created": True}

    async def project_list(
        self,
        *,
        user_id: uuid.UUID,
    ) -> list[dict[str, Any]]:
        _ = user_id
        # Aggregate from ast_changes project_id field.
        rows = await self.db.query("ast_changes")
        projects: set[str] = {
            str(r.get("project_id") or "")
            for r in rows
            if str(r.get("project_id") or "")
        }
        projects.add(self.default_project_id)
        return [{"project_id": p, "name": p} for p in sorted(projects)]

    async def project_switch(
        self,
        *,
        user_id: uuid.UUID,
        project_id: str,
    ) -> dict[str, Any]:
        _ = user_id
        _require_str(project_id, "project_id")
        self.default_project_id = project_id
        return {"project_id": project_id, "active": True}

    async def project_members(
        self,
        *,
        user_id: uuid.UUID,
        project_id: str | None = None,
    ) -> dict[str, Any]:
        _ = user_id
        pid = project_id or self.default_project_id
        rows = await self.db.query("users")
        return {
            "project_id": pid,
            "members": [
                {"id": str(r["id"]), "email": r.get("email", ""), "name": r.get("name", "")}
                for r in rows
            ],
        }

    # -- Sprint intelligence ----------------------------------------------

    async def sprint_burndown(
        self,
        *,
        user_id: uuid.UUID,
        sprint_id: uuid.UUID,
    ) -> dict[str, Any]:
        """Compute a burndown series: total vs completed points by story state."""
        _ = user_id
        sprint_row = await self._required_row("sprints", sprint_id)
        stories = await self.db.query(
            "stories", where={"sprint_id": str(sprint_id)}
        )
        total_points = sum(
            int(s["points"] or 0) for s in stories if s.get("points") is not None
        )
        remaining = sum(
            int(s["points"] or 0)
            for s in stories
            if s.get("status") != "done" and s.get("points") is not None
        )
        done = total_points - remaining
        return {
            "sprint_id": str(sprint_id),
            "sprint_name": sprint_row.get("name", ""),
            "total_points": total_points,
            "done_points": done,
            "remaining_points": remaining,
            "series": [
                {"label": "ideal_remaining", "value": 0},
                {"label": "actual_remaining", "value": remaining},
            ],
        }

    async def sprint_velocity(
        self,
        *,
        user_id: uuid.UUID,
        lookback_sprints: int = 6,
    ) -> dict[str, Any]:
        """Points completed per completed sprint, most recent ``lookback_sprints``."""
        _ = user_id
        sprints = await self.db.query(
            "sprints", order_by="end_date DESC", limit=lookback_sprints
        )
        series: list[dict[str, Any]] = []
        for sprint in sprints:
            stories = await self.db.query(
                "stories", where={"sprint_id": str(sprint["id"])}
            )
            done = sum(
                int(s["points"] or 0)
                for s in stories
                if s.get("status") == "done" and s.get("points") is not None
            )
            series.append(
                {
                    "sprint_id": str(sprint["id"]),
                    "sprint_name": sprint.get("name", ""),
                    "end_date": sprint.get("end_date"),
                    "points_done": done,
                }
            )
        avg = (
            sum(s["points_done"] for s in series) / len(series)
            if series
            else 0.0
        )
        return {
            "lookback_sprints": lookback_sprints,
            "series": series,
            "average_velocity": avg,
        }

    async def sprint_retrospective(
        self,
        *,
        user_id: uuid.UUID,
        sprint_id: uuid.UUID,
    ) -> dict[str, Any]:
        """A simple retro summary: completed stories, failed/open decisions."""
        _ = user_id
        sprint_row = await self._required_row("sprints", sprint_id)
        stories = await self.db.query(
            "stories", where={"sprint_id": str(sprint_id)}
        )
        done = [s for s in stories if s.get("status") == "done"]
        open_stories = [s for s in stories if s.get("status") != "done"]
        failed_decisions = await self.db.query(
            "decisions", where={"status": "failed"}
        )
        return {
            "sprint": {"id": str(sprint_id), "name": sprint_row.get("name", "")},
            "completed_stories": [
                {"id": str(s["id"]), "title": s.get("title", "")} for s in done
            ],
            "carryover_stories": [
                {"id": str(s["id"]), "title": s.get("title", "")}
                for s in open_stories
            ],
            "failed_decisions": [
                {"id": str(d["id"]), "title": d.get("title", "")}
                for d in failed_decisions
            ],
        }

    async def retrospective_generate(
        self,
        *,
        user_id: uuid.UUID,
        sprint_id: uuid.UUID,
    ) -> dict[str, Any]:
        """Alias of :meth:`sprint_retrospective` for the ``retrospective`` namespace."""
        return await self.sprint_retrospective(
            user_id=user_id, sprint_id=sprint_id
        )

    async def harness_score_commit(
        self,
        *,
        user_id: uuid.UUID,
        commit_hash: str,
        project_id: str | None = None,
    ) -> dict[str, Any]:
        """Score a single git commit. Rejects file_watcher projects."""
        _ = user_id
        _require_str(commit_hash, "commit_hash")
        if self.harness is None:
            raise HandlerError(
                "Quality harness is not enabled on this server"
            )
        if self.change_detection_backend != "git":
            raise HandlerError(
                "harness.score_commit requires git backend; "
                "file_watcher projects have no commit hash."
            )
        pid = project_id or self.default_project_id
        score = await self.harness.score_commit(commit_hash, pid)
        return {
            "change_event_id": score.change_event_id,
            "change_event_type": score.change_event_type,
            "change_detection_backend": score.change_detection_backend,
            "coverage_delta": score.coverage_delta,
            "complexity_score": score.complexity_score,
            "import_health": score.import_health,
            "drift_violations": score.drift_violations,
            "decision_density": score.decision_density,
            "decision_density_status": score.decision_density_status,
            "harness_status": score.harness_status,
        }

    # ------------------------------------------------------------------
    # Active context injection hooks (Phase 3 upgrade)
    # ------------------------------------------------------------------

    async def hooks_session_context(
        self,
        *,
        user_id: uuid.UUID,
        cwd: str,
        prompt: str,
        token_budget: int = 1500,
    ) -> dict[str, Any]:
        """Hook endpoint: inject relevant context for a user prompt.

        Called by the Claude Code ``UserPromptSubmit`` hook on every
        prompt submission. Detects the project from ``cwd`` by walking
        up looking for ``codeledger.toml``; returns an empty block when
        no project is found or when semantic search isn't wired.
        """
        _ = user_id
        project_id = _find_project_id(cwd)
        if (
            project_id is None
            or self.semantic_search is None
            or self.context_triage is None
        ):
            return {"context_block": "", "project_id": project_id}
        try:
            results = await self.semantic_search.search(
                query=prompt,
                project_id=project_id,
                top_k=8,
            )
            triage_result = self.context_triage.triage(results, token_budget)
            block = format_context_block(triage_result, context_for=prompt)
            await self._touch_decisions_from_triage(triage_result)
            return {
                "context_block": block,
                "project_id": project_id,
                "included_count": len(triage_result.included_items),
                "summarized_count": len(triage_result.summarized_items),
            }
        except Exception:
            logger.warning(
                "hooks_session_context failed for cwd=%s", cwd, exc_info=True
            )
            return {"context_block": "", "project_id": project_id}

    async def hooks_file_context(
        self,
        *,
        user_id: uuid.UUID,
        file_path: str,
        cwd: str,
        token_budget: int = 1500,
    ) -> dict[str, Any]:
        """Hook endpoint: inject relevant context before a file edit.

        Reads the file's current content from disk (best-effort) and
        feeds it into :meth:`SemanticSearch.search_by_file` so the
        returned block is scoped to whatever the developer is about to
        edit.
        """
        _ = user_id
        project_id = _find_project_id(cwd)
        if (
            project_id is None
            or self.semantic_search is None
            or self.context_triage is None
        ):
            return {"context_block": "", "project_id": project_id}
        resolved = _resolve_file_path(file_path, cwd)
        file_content = ""
        if resolved is not None:
            try:
                file_content = resolved.read_text(encoding="utf-8", errors="replace")
            except OSError:
                file_content = ""
        try:
            results = await self.semantic_search.search_by_file(
                file_path=file_path,
                file_content=file_content,
                project_id=project_id,
                top_k=8,
                blend_weight=0.5,
            )
            triage_result = self.context_triage.triage(results, token_budget)
            block = format_context_block(
                triage_result, context_for=file_path
            )
            await self._touch_decisions_from_triage(triage_result)
            return {
                "context_block": block,
                "project_id": project_id,
                "file_path": file_path,
            }
        except Exception:
            logger.warning(
                "hooks_file_context failed for %s", file_path, exc_info=True
            )
            return {
                "context_block": "",
                "project_id": project_id,
                "file_path": file_path,
            }

    async def hooks_conflict_check(
        self,
        *,
        user_id: uuid.UUID,
        file_path: str,
        session_id: uuid.UUID | None,
        cwd: str,
    ) -> dict[str, Any]:
        """Hook endpoint: report any active conflicts on ``file_path``.

        The detector's in-memory state holds whichever sessions are
        currently registered. If the caller's session_id is missing
        (e.g. the Claude Code hook fires before any tool call), the
        endpoint returns ``{conflict: false}`` rather than crashing.
        """
        _ = user_id
        if self.conflict_detector is None or session_id is None:
            return {"conflict": False}
        project_id = _find_project_id(cwd) or self.default_project_id
        try:
            # Ensure the session is registered with the latest file set so
            # the detector can compute overlap for brand-new sessions.
            active = self.conflict_detector.get_active_sessions(project_id)
            known_ids = {s["session_id"] for s in active}
            if str(session_id) in known_ids:
                # Merge the new file into the existing file set.
                existing = next(
                    (
                        set(s["files"])
                        for s in active
                        if s["session_id"] == str(session_id)
                    ),
                    set(),
                )
                existing.add(file_path)
                self.conflict_detector.update_session_files(
                    str(session_id), sorted(existing)
                )
            else:
                self.conflict_detector.register_session(
                    session_id=str(session_id),
                    project_id=project_id,
                    agent_name="hook",
                    files=[file_path],
                )
            conflicts = await self.conflict_detector.check_conflicts(
                str(session_id), project_id
            )
        except Exception:
            logger.warning(
                "hooks_conflict_check failed for %s", file_path, exc_info=True
            )
            return {"conflict": False}
        if not conflicts:
            return {"conflict": False}
        first = conflicts[0]
        return {
            "conflict": True,
            "message": (
                f"File {file_path} is being edited concurrently by "
                f"{first.conflicting_agent} ({first.severity} severity)."
            ),
            "conflicting_session": first.conflicting_session_id,
            "overlapping_files": first.overlapping_files,
            "severity": first.severity,
        }

    async def hooks_import_check(
        self,
        *,
        user_id: uuid.UUID,
        content: str,
        file_path: str,
        cwd: str,
    ) -> dict[str, Any]:
        """Hook endpoint: flag imports in ``content`` that violate drift constraints.

        Runs a lightweight pass: extract architectural constraints from
        verified decisions (same as :class:`DriftDetector`) and scan
        ``content`` line-by-line for imports that trigger any of them.
        Avoids the full repo walk the dashboard uses — this path runs
        on every file edit and must stay under 150ms.
        """
        _ = user_id
        project_id = _find_project_id(cwd) or self.default_project_id
        try:
            decisions = await self.db.query(
                "decisions", where={"status": "passed"}
            )
        except Exception:
            return {"violations": []}
        constraints = _extract_drift_constraints(decisions)
        if not constraints:
            return {"violations": []}
        violations: list[dict[str, Any]] = []
        for line_no, line in enumerate(content.splitlines(), start=1):
            for constraint in constraints:
                if not _file_matches_module(file_path, constraint["lhs"]):
                    continue
                if _line_imports_target(line, constraint["rhs"]):
                    violations.append(
                        {
                            "import": constraint["rhs"],
                            "constraint": constraint["original"],
                            "decision_id": constraint["decision_id"],
                            "decision_title": constraint["decision_title"],
                            "violating_line": line_no,
                            "file_path": file_path,
                        }
                    )
                    break
        return {"violations": violations, "project_id": project_id}

    async def hooks_ensure_session(
        self,
        *,
        user_id: uuid.UUID,
        cwd: str,
        agent: str,
    ) -> dict[str, Any]:
        """Hook endpoint: return an active session id for ``cwd`` + ``agent``.

        Idempotent: repeated calls with the same pair return the same
        session. The mapping from ``cwd`` to session is stored in a
        ``hook_project_root`` :class:`SessionEvent`.
        """
        _require_str(cwd, "cwd")
        _require_str(agent, "agent")
        normalized_cwd = os.path.abspath(cwd)
        try:
            active = await self.db.query(
                "sessions", where={"agent_name": agent, "status": "active"}
            )
            for row in active:
                events = await self.db.query(
                    "session_events",
                    where={
                        "session_id": str(row["id"]),
                        "event_type": "hook_project_root",
                    },
                )
                for evt in events:
                    payload = _parse_payload_value(evt.get("payload"))
                    if str(payload.get("cwd", "")) == normalized_cwd:
                        return {
                            "session_id": str(row["id"]),
                            "created": False,
                        }
        except Exception:
            logger.warning(
                "hooks_ensure_session lookup failed for cwd=%s agent=%s",
                cwd,
                agent,
                exc_info=True,
            )
        started = await self.session_start(user_id=user_id, agent_name=agent)
        sid = str(started["id"])
        await self._log_session_event(
            session_id=sid,
            event_type="hook_project_root",
            payload={"cwd": normalized_cwd, "agent": agent},
        )
        return {"session_id": sid, "created": True}

    async def hooks_close_session(
        self,
        *,
        user_id: uuid.UUID,
        cwd: str,
    ) -> dict[str, Any]:
        """Hook endpoint: close any active session associated with ``cwd``.

        Runs passive inference with the project-configured auto-confirm
        threshold so zero-interaction capture still happens when Claude
        Code stops. Never raises — failure paths log and return
        ``{"status": "closed"}``.
        """
        normalized_cwd = os.path.abspath(cwd)
        try:
            active = await self.db.query(
                "sessions", where={"status": "active"}
            )
            for row in active:
                events = await self.db.query(
                    "session_events",
                    where={
                        "session_id": str(row["id"]),
                        "event_type": "hook_project_root",
                    },
                )
                for evt in events:
                    payload = _parse_payload_value(evt.get("payload"))
                    if str(payload.get("cwd", "")) != normalized_cwd:
                        continue
                    try:
                        result = await self.session_end(
                            user_id=user_id,
                            session_id=uuid.UUID(str(row["id"])),
                            auto_confirm_threshold=self.auto_confirm_threshold,
                        )
                    except Exception:
                        logger.warning(
                            "hooks_close_session session_end failed for %s",
                            row["id"],
                            exc_info=True,
                        )
                        continue
                    return {
                        "status": "closed",
                        "session_id": str(row["id"]),
                        "summary": result,
                    }
        except Exception:
            logger.warning(
                "hooks_close_session failed for cwd=%s",
                cwd,
                exc_info=True,
            )
        return {"status": "closed"}

    # ------------------------------------------------------------------
    # Universal active context (Prompt 8)
    # ------------------------------------------------------------------

    async def ensure_session_and_inject_context(
        self,
        *,
        cwd: str | None,
        agent_name: str | None,
        project_id: str | None,
        first_message: str | None = None,
        user_id: uuid.UUID | None = None,
        token_budget: int = 1500,
        inactivity_timeout_minutes: int | None = None,
    ) -> SessionContextResult | None:
        """Match an existing active session or create one and inject context.

        Returns ``None`` when the caller did not supply all three of
        ``cwd``, ``agent_name``, ``project_id``. This keeps the existing
        handler surface backward-compatible — tools that predate the
        active-context machinery simply do not participate.
        """
        if not (cwd and agent_name and project_id):
            return None
        timeout_minutes = (
            inactivity_timeout_minutes
            if inactivity_timeout_minutes is not None
            else _DEFAULT_INACTIVITY_TIMEOUT_MINUTES
        )
        now = datetime.now(UTC)
        cutoff = now - timedelta(minutes=timeout_minutes)
        existing = await self._find_active_session(
            project_id=project_id, agent_name=agent_name, cutoff=cutoff
        )
        if existing is not None:
            await self.db.update(
                "sessions",
                existing,
                {"last_tool_call_at": now.isoformat()},
            )
            return SessionContextResult(
                session_id=existing,
                is_new_session=False,
                context_block=None,
                context_items_count=0,
                tokens_used=0,
            )

        session = Session(
            user_id=user_id,
            agent_name=agent_name,
            status="active",
            project_id=project_id,
            cwd=cwd,
            last_tool_call_at=now,
        )
        await self.db.insert("sessions", session.to_dict())
        if self.conflict_detector is not None:
            try:
                self.conflict_detector.register_session(
                    session_id=str(session.id),
                    project_id=project_id,
                    agent_name=agent_name,
                    files=[],
                )
            except Exception:
                logger.warning(
                    "Conflict-detector register failed for session %s",
                    session.id,
                    exc_info=True,
                )
        await self._log_session_event(
            session_id=str(session.id),
            event_type="session_start",
            payload={
                "agent_name": agent_name,
                "project_id": project_id,
                "cwd": cwd,
                "auto": True,
            },
        )

        block: str | None = None
        items_count = 0
        tokens_used = 0
        if self.semantic_search is not None and self.context_triage is not None:
            query = first_message or _DEFAULT_FIRST_MESSAGE
            try:
                results = await self.semantic_search.search(
                    query=query, project_id=project_id, top_k=8
                )
                triage = self.context_triage.triage(results, token_budget)
                block = format_context_block(triage, context_for=query)
                items_count = len(triage.included_items) + len(
                    triage.summarized_items
                )
                tokens_used = int(triage.total_tokens_used)
                await self._touch_decisions_from_triage(triage)
            except Exception:
                logger.warning(
                    "ensure_session_and_inject_context: retrieval failed",
                    exc_info=True,
                )
                block = None
        return SessionContextResult(
            session_id=str(session.id),
            is_new_session=True,
            context_block=block,
            context_items_count=items_count,
            tokens_used=tokens_used,
        )

    async def touch_session_activity(self, session_id: str) -> None:
        """Refresh ``last_tool_call_at`` on an existing session.

        Called from the MCP dispatch layer after every tool invocation
        for the session matched by :meth:`ensure_session_and_inject_context`.
        Best-effort — failures are logged and swallowed.
        """
        try:
            await self.db.update(
                "sessions",
                session_id,
                {"last_tool_call_at": datetime.now(UTC).isoformat()},
            )
        except Exception:
            logger.debug(
                "touch_session_activity failed for %s", session_id,
                exc_info=True,
            )

    async def _find_active_session(
        self, *, project_id: str, agent_name: str, cutoff: datetime
    ) -> str | None:
        """Return the most recent active session for ``project_id`` + ``agent_name``.

        Matches ``status = 'active'`` AND ``last_tool_call_at >= cutoff``
        OR ``started_at >= cutoff`` for legacy rows without a recorded
        last-tool-call timestamp. Closing a stale session is the
        background task's job.
        """
        try:
            rows = await self.db.query(
                "sessions",
                where={
                    "project_id": project_id,
                    "agent_name": agent_name,
                    "status": "active",
                },
                order_by="started_at DESC",
            )
        except Exception:
            return None
        cutoff_iso = cutoff.isoformat()
        for row in rows:
            last = row.get("last_tool_call_at") or row.get("started_at")
            if last and str(last) >= cutoff_iso:
                return str(row["id"])
        return None

    async def context_before_edit(
        self,
        *,
        user_id: uuid.UUID,
        file_path: str,
        file_content: str,
        cwd: str,
        agent_name: str,
        project_id: str,
    ) -> dict[str, Any]:
        """Pre-edit context bundle: relevant decisions, conflicts, import warnings.

        The single tool that non-Claude-Code clients (Cursor, Windsurf)
        call before editing a file. Replaces the three PreToolUse hooks
        that Claude Code can run but other clients cannot.
        """
        _require_str(file_path, "file_path")
        _require_str(cwd, "cwd")
        _require_str(agent_name, "agent_name")
        _require_str(project_id, "project_id")

        bootstrap = await self.ensure_session_and_inject_context(
            cwd=cwd,
            agent_name=agent_name,
            project_id=project_id,
            first_message=(
                f"editing {file_path}" if file_path else None
            ),
            user_id=user_id,
        )
        session_id = bootstrap.session_id if bootstrap else ""

        decisions: list[dict[str, Any]] = []
        if self.semantic_search is not None:
            try:
                results = await self.semantic_search.search_by_file(
                    file_path=file_path,
                    file_content=file_content or "",
                    project_id=project_id,
                    top_k=3,
                    blend_weight=0.5,
                )
                decisions = [
                    {
                        "item_id": r.item_id,
                        "item_type": r.item_type,
                        "score": r.score,
                        "title": r.metadata.get("title", "")
                        if isinstance(r.metadata, dict)
                        else "",
                        "retrieval_method": r.retrieval_method,
                    }
                    for r in results
                ]
            except Exception:
                logger.warning(
                    "context_before_edit semantic_search failed",
                    exc_info=True,
                )

        conflicts: list[dict[str, Any]] = []
        if self.conflict_detector is not None and session_id:
            try:
                active = self.conflict_detector.get_active_sessions(project_id)
                known_ids = {s["session_id"] for s in active}
                if session_id in known_ids:
                    existing_files: set[str] = set()
                    for s in active:
                        if s["session_id"] == session_id:
                            existing_files.update(s["files"])
                            break
                    existing_files.add(file_path)
                    self.conflict_detector.update_session_files(
                        session_id, sorted(existing_files)
                    )
                else:
                    self.conflict_detector.register_session(
                        session_id=session_id,
                        project_id=project_id,
                        agent_name=agent_name,
                        files=[file_path],
                    )
                found = await self.conflict_detector.check_conflicts(
                    session_id, project_id
                )
                conflicts = [
                    {
                        "conflicting_session_id": c.conflicting_session_id,
                        "conflicting_agent": c.conflicting_agent,
                        "overlapping_files": c.overlapping_files,
                        "severity": c.severity,
                    }
                    for c in found
                ]
            except Exception:
                logger.warning(
                    "context_before_edit conflict check failed",
                    exc_info=True,
                )

        import_warnings: list[dict[str, Any]] = []
        try:
            passed = await self.db.query(
                "decisions", where={"status": "passed"}
            )
        except Exception:
            passed = []
        constraints = _extract_drift_constraints(passed)
        if constraints and file_content:
            for line_no, line in enumerate(
                file_content.splitlines(), start=1
            ):
                for constraint in constraints:
                    if not _file_matches_module(
                        file_path, constraint["lhs"]
                    ):
                        continue
                    if _line_imports_target(line, constraint["rhs"]):
                        import_warnings.append(
                            {
                                "import": constraint["rhs"],
                                "constraint": constraint["original"],
                                "decision_id": constraint["decision_id"],
                                "decision_title": constraint["decision_title"],
                                "violating_line": line_no,
                                "file_path": file_path,
                            }
                        )
                        break
        response: dict[str, Any] = {
            "session_id": session_id,
            "decisions": decisions,
            "conflicts": conflicts,
            "import_warnings": import_warnings,
        }
        if bootstrap and bootstrap.is_new_session:
            response["session_context"] = {
                "session_id": bootstrap.session_id,
                "context_block": bootstrap.context_block,
                "context_items_count": bootstrap.context_items_count,
                "tokens_used": bootstrap.tokens_used,
            }
        return response

    async def close_inactive_sessions(
        self, *, inactivity_timeout_minutes: int = 30
    ) -> list[str]:
        """Auto-close every active session older than the inactivity window.

        Invoked by the ``close_inactive_sessions`` background task in
        ``main.py``. For each matching session:

        1. Run the unlinked-files enforcement check. If unlinked files
           exist, pass them through :meth:`decision_inferrer
           .auto_confirm_high_confidence` at the project's configured
           threshold before closing.
        2. Score the session via :class:`QualityHarness` (best-effort —
           logged but not required).
        3. Mark the session ``completed``.

        Returns the list of session ids that were closed.
        """
        if inactivity_timeout_minutes <= 0:
            return []
        cutoff = datetime.now(UTC) - timedelta(
            minutes=inactivity_timeout_minutes
        )
        cutoff_iso = cutoff.isoformat()
        try:
            rows = await self.db.query(
                "sessions", where={"status": "active"}
            )
        except Exception:
            logger.warning("close_inactive_sessions query failed", exc_info=True)
            return []
        closed: list[str] = []
        for row in rows:
            last = row.get("last_tool_call_at") or row.get("started_at")
            if not last or str(last) >= cutoff_iso:
                continue
            sid = str(row["id"])
            project = str(row.get("project_id") or self.default_project_id)
            try:
                if self.decision_inferrer is not None:
                    threshold = self.auto_confirm_threshold or 0.75
                    await self.decision_inferrer.auto_confirm_high_confidence(
                        session_id=sid,
                        project_id=project,
                        threshold=threshold,
                    )
            except Exception:
                logger.warning(
                    "close_inactive_sessions auto-confirm failed for %s",
                    sid,
                    exc_info=True,
                )
            try:
                if self.harness is not None:
                    await self.harness.score_session(
                        uuid.UUID(sid),
                        project,
                        change_detection_backend=self.change_detection_backend,  # type: ignore[arg-type]
                    )
            except Exception:
                logger.debug(
                    "close_inactive_sessions harness score failed for %s",
                    sid,
                    exc_info=True,
                )
            try:
                now_iso = _now_iso()
                await self.db.update(
                    "sessions",
                    sid,
                    {
                        "status": "completed",
                        "ended_at": now_iso,
                        "updated_at": now_iso,
                    },
                )
                if self.conflict_detector is not None:
                    self.conflict_detector.end_session(sid)
                await self._log_session_event(
                    session_id=sid,
                    event_type="session_end",
                    payload={
                        "status": "completed",
                        "reason": "inactivity_timeout",
                        "inactivity_timeout_minutes": inactivity_timeout_minutes,
                    },
                )
                closed.append(sid)
            except Exception:
                logger.warning(
                    "close_inactive_sessions close failed for %s",
                    sid,
                    exc_info=True,
                )
        return closed


# ---------------------------------------------------------------------------
# Hook helpers (Phase 3 active context injection)
# ---------------------------------------------------------------------------


def _find_project_id(cwd: str) -> str | None:
    """Walk up ``cwd`` looking for a ``codeledger.toml``; return the directory name.

    The directory name (basename of the directory containing the toml)
    is used as the project id. Multi-project installs can override by
    passing ``project_id`` explicitly on the MCP side — the hooks path
    intentionally keeps this cheap.
    """
    if not cwd:
        return None
    try:
        current = Path(cwd).expanduser().resolve()
    except OSError:
        return None
    for candidate in (current, *current.parents):
        if (candidate / "codeledger.toml").exists():
            return candidate.name or "default"
    return None


def _resolve_file_path(file_path: str, cwd: str) -> Path | None:
    """Resolve ``file_path`` against ``cwd`` and guard against path traversal."""
    if not file_path:
        return None
    try:
        candidate = Path(file_path)
        if not candidate.is_absolute():
            candidate = Path(cwd).expanduser() / file_path
        resolved = candidate.resolve()
    except OSError:
        return None
    if not resolved.exists() or not resolved.is_file():
        return None
    return resolved


def _parse_payload_value(raw: Any) -> dict[str, Any]:
    """Decode a SessionEvent payload, tolerating both str and dict storage."""
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str):
        try:
            loaded = json.loads(raw)
            if isinstance(loaded, dict):
                return loaded
        except json.JSONDecodeError:
            return {}
    return {}


_DRIFT_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(
        r"(?P<lhs>[A-Za-z_][\w./\-]*)\s+must\s+not\s+import\s+"
        r"(?P<rhs>[A-Za-z_][\w./\-]*)",
        re.IGNORECASE,
    ),
    re.compile(
        r"(?P<lhs>[A-Za-z_][\w./\-]*)\s+must\s+not\s+depend\s+on\s+"
        r"(?P<rhs>[A-Za-z_][\w./\-]*)",
        re.IGNORECASE,
    ),
)


def _extract_drift_constraints(
    decisions: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Pull "must not import" rules from a list of verified decisions."""
    out: list[dict[str, Any]] = []
    for row in decisions:
        title = str(row.get("title") or "")
        description = str(row.get("description") or "")
        blob = f"{title}\n{description}"
        for pattern in _DRIFT_PATTERNS:
            for match in pattern.finditer(blob):
                out.append(
                    {
                        "decision_id": str(row.get("id") or ""),
                        "decision_title": title,
                        "lhs": match.group("lhs"),
                        "rhs": match.group("rhs"),
                        "original": match.group(0),
                    }
                )
    return out


def _file_matches_module(file_path: str, lhs: str) -> bool:
    """Does ``file_path`` belong to the guarded module named in ``lhs``?"""
    normalized = lhs.replace(".", "/").strip("/")
    return (
        normalized in file_path
        or file_path.endswith("/" + normalized)
        or file_path.endswith(normalized + ".py")
        or file_path == normalized + ".py"
    )


def _line_imports_target(line: str, target: str) -> bool:
    """Crude import-line match used by the import-check hook."""
    stripped = line.strip()
    if not stripped or stripped.startswith("#") or stripped.startswith("//"):
        return False
    target_escaped = re.escape(target)
    has_import_kw = (
        bool(re.match(r"(?:import|from|use)\s", stripped))
        or "require(" in stripped
        or re.search(r'from\s+["\']', stripped) is not None
    )
    if not has_import_kw:
        return False
    segment_pattern = rf"(?:^|[\s./:\"']){target_escaped}(?:$|[\s./:\"',;])"
    return bool(re.search(segment_pattern, stripped))
