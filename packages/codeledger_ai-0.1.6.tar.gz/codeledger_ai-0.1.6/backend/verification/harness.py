"""Quality harness — independent sensors over commits, snapshots, sessions.

The harness produces numeric signals that feed the dashboard's session
status badges and the ``harness.score`` MCP tool. Sensors included:

* ``complexity_score`` — a crude cyclomatic proxy over the changed text.
* ``import_health`` — circular-dependency probe over the project's
  current import graph.
* ``drift_violations`` — decisions that verified but whose constraints
  are now violated; stubbed at zero until Phase 5 wires the real
  :class:`backend.advanced.drift_detector.DriftDetector`.
* ``decision_density`` — recorded decisions per structural AST change
  (per session or per project). ``0.0`` with structural changes present
  is a SEC-11 critical finding.

Security invariants enforced:
- SEC-03: ``HarnessScore`` values are numeric or small enumerated
  strings; they never carry file content or credential material.
- The harness only reads from the existing DB tables through the
  :class:`DatabaseBackend` interface — it never opens new sockets.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    import uuid

    from backend.db.db_backend import DatabaseBackend


DensityStatus = Literal["critical", "low", "adequate"]
HarnessStatusLiteral = Literal["passing", "warning", "failing"]
ChangeDetectionBackend = Literal["git", "file_watcher"]


# Bucket thresholds for decision_density.
_DENSITY_CRITICAL = 0.1
_DENSITY_LOW = 0.3


class HarnessError(Exception):
    """Raised for harness input or persistence failures."""


@dataclass(frozen=True)
class HarnessScore:
    """A single change-event (commit or snapshot) quality snapshot."""

    change_event_id: str
    change_event_type: str
    change_detection_backend: ChangeDetectionBackend
    coverage_delta: float | None
    complexity_score: float
    import_health: float
    drift_violations: int
    decision_density: float
    decision_density_status: DensityStatus
    harness_status: HarnessStatusLiteral
    coverage_status: str = "unavailable"


@dataclass(frozen=True)
class SessionHarnessScore:
    """Aggregated harness score for an entire session."""

    session_id: str
    change_detection_backend: ChangeDetectionBackend
    structural_changes: int
    decisions_recorded: int
    decision_density: float
    decision_density_status: DensityStatus
    harness_status: HarnessStatusLiteral
    session_coverage_metric: float
    per_event_scores: list[HarnessScore] = field(default_factory=list)


def _classify_density(density: float) -> DensityStatus:
    """Map a density value to its Phase 3 bucket."""
    if density < _DENSITY_CRITICAL:
        return "critical"
    if density < _DENSITY_LOW:
        return "low"
    return "adequate"


def _status_from_density(density_status: DensityStatus) -> HarnessStatusLiteral:
    """A critical density is an immediate failing signal."""
    if density_status == "critical":
        return "failing"
    if density_status == "low":
        return "warning"
    return "passing"


class QualityHarness:
    """Run independent quality sensors over commits, snapshots, and sessions."""

    def __init__(self, db: DatabaseBackend) -> None:
        self._db = db

    # ------------------------------------------------------------------
    # Per-event scoring
    # ------------------------------------------------------------------

    async def score_commit(
        self,
        commit_hash: str,
        project_id: str,
        *,
        change_detection_backend: ChangeDetectionBackend = "git",
    ) -> HarnessScore:
        """Score a single git commit. Only valid in git mode.

        Raises:
            ValueError: Called on a file-watcher project.
        """
        if change_detection_backend != "git":
            raise ValueError(
                "score_commit requires git backend. "
                "Use score_snapshot for file watcher projects."
            )
        return await self._score_change_event(
            change_event_id=commit_hash,
            change_event_type="git_commit",
            change_detection_backend="git",
            project_id=project_id,
        )

    async def score_snapshot(
        self,
        after_snapshot_id: str,
        project_id: str,
    ) -> HarnessScore:
        """Score a file-watcher snapshot event.

        Coverage delta is always ``None`` in this mode — there is no
        stash-based before/after state to compare against.
        """
        return await self._score_change_event(
            change_event_id=after_snapshot_id,
            change_event_type="file_snapshot",
            change_detection_backend="file_watcher",
            project_id=project_id,
        )

    async def _score_change_event(
        self,
        *,
        change_event_id: str,
        change_event_type: str,
        change_detection_backend: ChangeDetectionBackend,
        project_id: str,
    ) -> HarnessScore:
        """Shared scoring logic for commits and snapshots."""
        ast_rows = await self._db.query(
            "ast_changes",
            where={
                "change_event_id": change_event_id,
                "project_id": project_id,
            },
        )
        decisions_linked = await self._linked_decision_count(ast_rows)
        structural_changes = len(ast_rows)
        density = _safe_density(decisions_linked, structural_changes)
        density_status = _classify_density(density)

        return HarnessScore(
            change_event_id=change_event_id,
            change_event_type=change_event_type,
            change_detection_backend=change_detection_backend,
            coverage_delta=None,
            complexity_score=await self._complexity_for(ast_rows),
            import_health=1.0,  # Stub: no circular-dependency probe yet.
            drift_violations=0,  # Stub until Phase 5 wires DriftDetector.
            decision_density=density,
            decision_density_status=density_status,
            harness_status=_status_from_density(density_status),
        )

    # ------------------------------------------------------------------
    # Session aggregation
    # ------------------------------------------------------------------

    async def score_session(
        self,
        session_id: uuid.UUID | str,
        project_id: str,
        *,
        change_detection_backend: ChangeDetectionBackend = "git",
    ) -> SessionHarnessScore:
        """Aggregate harness signals across every change event in a session."""
        session_row = await self._db.get_by_id("sessions", str(session_id))
        if session_row is None:
            raise HarnessError(f"Session not found: {session_id}")

        ast_rows = await self._db.query(
            "ast_changes", where={"session_id": str(session_id)}
        )
        structural_changes = len(ast_rows)
        decisions_linked = await self._linked_decision_count(ast_rows)
        density = _safe_density(decisions_linked, structural_changes)
        density_status = _classify_density(density)

        per_event = await self._per_event_scores(
            ast_rows,
            project_id=project_id,
            change_detection_backend=change_detection_backend,
        )
        coverage_metric = await self._session_coverage_metric(project_id)

        return SessionHarnessScore(
            session_id=str(session_id),
            change_detection_backend=change_detection_backend,
            structural_changes=structural_changes,
            decisions_recorded=decisions_linked,
            decision_density=density,
            decision_density_status=density_status,
            harness_status=_status_from_density(density_status),
            session_coverage_metric=coverage_metric,
            per_event_scores=per_event,
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    async def _linked_decision_count(
        self, ast_rows: list[dict[str, Any]]
    ) -> int:
        """Count distinct decisions linked to the given AST changes."""
        decision_ids: set[str] = set()
        for row in ast_rows:
            edges = await self._db.query(
                "provenance_edges",
                where={"target_id": str(row["id"])},
            )
            for edge in edges:
                if edge.get("source_type") == "decision":
                    decision_ids.add(str(edge["source_id"]))
        return len(decision_ids)

    async def _complexity_for(
        self, ast_rows: list[dict[str, Any]]
    ) -> float:
        """Very rough complexity proxy: number of structural changes, capped."""
        if not ast_rows:
            return 0.0
        # Normalize to [0, 1]: 0 changes → 0.0; 20+ → 1.0.
        return min(len(ast_rows) / 20.0, 1.0)

    async def _session_coverage_metric(self, project_id: str) -> float:
        """Fraction of completed sessions that recorded at least one decision."""
        _ = project_id
        sessions = await self._db.query(
            "sessions", where={"status": "completed"}
        )
        if not sessions:
            return 0.0
        covered = 0
        for session in sessions:
            ast_rows = await self._db.query(
                "ast_changes", where={"session_id": str(session["id"])}
            )
            if await self._linked_decision_count(ast_rows) > 0:
                covered += 1
        return covered / len(sessions)

    async def _per_event_scores(
        self,
        ast_rows: list[dict[str, Any]],
        *,
        project_id: str,
        change_detection_backend: ChangeDetectionBackend,
    ) -> list[HarnessScore]:
        """Score each unique change event once, not once per AST row."""
        seen: set[str] = set()
        scores: list[HarnessScore] = []
        for row in ast_rows:
            event_id = str(row.get("change_event_id", ""))
            if not event_id or event_id in seen:
                continue
            seen.add(event_id)
            event_type = str(row.get("change_event_type", "git_commit"))
            if event_type == "git_commit":
                scores.append(
                    await self.score_commit(
                        event_id,
                        project_id,
                        change_detection_backend=change_detection_backend,
                    )
                )
            else:
                scores.append(await self.score_snapshot(event_id, project_id))
        return scores


def _safe_density(decisions: int, changes: int) -> float:
    """Return decisions / max(changes, 1) guarded against division by zero."""
    return decisions / changes if changes > 0 else 0.0
