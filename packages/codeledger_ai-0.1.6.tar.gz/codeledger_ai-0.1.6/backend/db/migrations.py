"""Schema migrations for CodeLedger's domain tables.

Applies idempotent, additive-only migrations to the database. Each migration
has a monotonic integer version tracked in the ``_migrations`` table. Old
migrations are never modified; schema changes come in as new migrations.

Security invariants enforced:
- SEC-01: ``password_hash`` and ``pat_hash`` are the only columns allowed to
  contain credential-derived material, and both store one-way hashes.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from backend.db.db_backend import DatabaseBackend


@dataclass(frozen=True)
class Migration:
    """A single schema migration: version + per-dialect SQL statements."""

    version: int
    name: str
    sqlite_sql: tuple[str, ...]
    postgresql_sql: tuple[str, ...]


# Initial schema. All ID columns are TEXT (UUID strings). Timestamps are TEXT
# (ISO 8601 strings) to match what ``Model.to_dict()`` produces. Lists are TEXT
# (JSON-encoded). Integers are native.

_V1_SQLITE = (
    """
    CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT NOT NULL,
        name TEXT NOT NULL DEFAULT '',
        provider TEXT NOT NULL DEFAULT '',
        avatar_url TEXT,
        password_hash TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(email)",
    """
    CREATE TABLE IF NOT EXISTS decisions (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL DEFAULT '',
        description TEXT NOT NULL DEFAULT '',
        tags TEXT NOT NULL DEFAULT '[]',
        status TEXT NOT NULL DEFAULT 'unverified',
        recorded_by_user_id TEXT,
        recorded_in_session_id TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_decisions_status ON decisions(status)",
    """
    CREATE TABLE IF NOT EXISTS stories (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL DEFAULT '',
        description TEXT NOT NULL DEFAULT '',
        acceptance_criteria TEXT NOT NULL DEFAULT '[]',
        status TEXT NOT NULL DEFAULT 'backlog',
        points INTEGER,
        sprint_id TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_stories_sprint ON stories(sprint_id)",
    """
    CREATE TABLE IF NOT EXISTS sprints (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL DEFAULT '',
        start_date TEXT,
        end_date TEXT,
        status TEXT NOT NULL DEFAULT 'planning',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS sessions (
        id TEXT PRIMARY KEY,
        user_id TEXT,
        agent_name TEXT NOT NULL DEFAULT '',
        started_at TEXT NOT NULL,
        ended_at TEXT,
        status TEXT NOT NULL DEFAULT 'active',
        files_touched TEXT NOT NULL DEFAULT '[]',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id)",
    "CREATE INDEX IF NOT EXISTS idx_sessions_status ON sessions(status)",
    """
    CREATE TABLE IF NOT EXISTS context_items (
        id TEXT PRIMARY KEY,
        content TEXT NOT NULL DEFAULT '',
        source TEXT NOT NULL DEFAULT '',
        tags TEXT NOT NULL DEFAULT '[]',
        embedding_id TEXT,
        token_count INTEGER NOT NULL DEFAULT 0,
        session_id TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_context_session ON context_items(session_id)",
    """
    CREATE TABLE IF NOT EXISTS verifications (
        id TEXT PRIMARY KEY,
        decision_id TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'unverified',
        ci_provider TEXT,
        ci_run_url TEXT,
        verified_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_verif_decision ON verifications(decision_id)",
    """
    CREATE TABLE IF NOT EXISTS ast_changes (
        id TEXT PRIMARY KEY,
        commit_hash TEXT NOT NULL DEFAULT '',
        file_path TEXT NOT NULL DEFAULT '',
        language TEXT NOT NULL DEFAULT '',
        change_type TEXT NOT NULL DEFAULT '',
        entity_name TEXT NOT NULL DEFAULT '',
        entity_type TEXT NOT NULL DEFAULT '',
        old_signature TEXT,
        new_signature TEXT,
        session_id TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_ast_commit ON ast_changes(commit_hash)",
    """
    CREATE TABLE IF NOT EXISTS provenance_edges (
        id TEXT PRIMARY KEY,
        source_type TEXT NOT NULL DEFAULT '',
        source_id TEXT NOT NULL,
        target_type TEXT NOT NULL DEFAULT '',
        target_id TEXT NOT NULL,
        relationship TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_prov_source ON provenance_edges(source_id)",
    "CREATE INDEX IF NOT EXISTS idx_prov_target ON provenance_edges(target_id)",
    """
    CREATE TABLE IF NOT EXISTS service_connections (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        provider TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL DEFAULT 'disconnected',
        scopes TEXT NOT NULL DEFAULT '[]',
        expires_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_svc_user ON service_connections(user_id)",
    """
    CREATE TABLE IF NOT EXISTS personal_access_tokens (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        name TEXT NOT NULL DEFAULT '',
        pat_hash TEXT NOT NULL,
        expires_at TEXT,
        last_used_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_pat_hash ON personal_access_tokens(pat_hash)",
    "CREATE INDEX IF NOT EXISTS idx_pat_user ON personal_access_tokens(user_id)",
    """
    CREATE TABLE IF NOT EXISTS session_events (
        id TEXT PRIMARY KEY,
        session_id TEXT NOT NULL,
        event_type TEXT NOT NULL DEFAULT '',
        payload TEXT NOT NULL DEFAULT '{}',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_sessevt_session ON session_events(session_id)",
)

# PostgreSQL schema mirrors SQLite with native types where helpful.
_V1_POSTGRES = tuple(
    stmt.replace("INTEGER", "BIGINT").replace("TEXT", "TEXT")
    for stmt in _V1_SQLITE
)


# Migration v2 — non-git change detection backend tables.
#
# file_snapshots stores before/after file content for watchdog-based diffing.
# unlinked_file_changes records SEC-11 audit rows for structural file saves
# that did not have a linked decision at detection time.
_V2_SQLITE = (
    """
    CREATE TABLE IF NOT EXISTS file_snapshots (
        id TEXT PRIMARY KEY,
        project_id TEXT NOT NULL DEFAULT '',
        file_path TEXT NOT NULL DEFAULT '',
        content_hash TEXT NOT NULL DEFAULT '',
        content TEXT NOT NULL DEFAULT '',
        snapshot_at TEXT NOT NULL,
        session_id TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_fsnap_file ON file_snapshots(project_id, file_path)",
    "CREATE INDEX IF NOT EXISTS idx_fsnap_hash ON file_snapshots(content_hash)",
    """
    CREATE TABLE IF NOT EXISTS unlinked_file_changes (
        id TEXT PRIMARY KEY,
        snapshot_id TEXT NOT NULL DEFAULT '',
        file_path TEXT NOT NULL DEFAULT '',
        project_id TEXT NOT NULL DEFAULT '',
        detected_at TEXT NOT NULL,
        structurally_changed_symbols TEXT NOT NULL DEFAULT '[]',
        session_id TEXT,
        override_reason TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_unlfc_project ON unlinked_file_changes(project_id)",
    "CREATE INDEX IF NOT EXISTS idx_unlfc_session ON unlinked_file_changes(session_id)",
)

_V2_POSTGRES = tuple(
    stmt.replace("INTEGER", "BIGINT").replace("TEXT", "TEXT")
    for stmt in _V2_SQLITE
)


# Migration v3 — change event abstraction.
#
# Extends ``ast_changes`` with the abstract ``change_event_id`` /
# ``change_event_type`` fields that let both the git post-commit pipeline
# and the file-watcher pipeline persist structurally-identical rows.
# Adds ``unlinked_commits`` to cover SEC-11 audits for git-backed projects.
#
# All three columns use ``ALTER TABLE ADD COLUMN`` so existing rows (which
# still carry ``commit_hash``) remain valid — migrations stay additive.
_V3_SQLITE = (
    "ALTER TABLE ast_changes ADD COLUMN change_event_id TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE ast_changes ADD COLUMN change_event_type TEXT NOT NULL DEFAULT ''",
    "ALTER TABLE ast_changes ADD COLUMN project_id TEXT NOT NULL DEFAULT ''",
    "CREATE INDEX IF NOT EXISTS idx_ast_event ON ast_changes(change_event_id)",
    "CREATE INDEX IF NOT EXISTS idx_ast_project ON ast_changes(project_id)",
    """
    CREATE TABLE IF NOT EXISTS unlinked_commits (
        id TEXT PRIMARY KEY,
        commit_hash TEXT NOT NULL DEFAULT '',
        project_id TEXT NOT NULL DEFAULT '',
        detected_at TEXT NOT NULL,
        structurally_changed_symbols TEXT NOT NULL DEFAULT '[]',
        session_id TEXT,
        override_reason TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_unlc_project ON unlinked_commits(project_id)",
    "CREATE INDEX IF NOT EXISTS idx_unlc_commit ON unlinked_commits(commit_hash)",
)

_V3_POSTGRES = tuple(
    stmt.replace("INTEGER", "BIGINT").replace("TEXT", "TEXT")
    for stmt in _V3_SQLITE
)


# Migration v4 — passive inference candidates + decision inference metadata.
#
# Adds ``inferred_decisions`` to stage candidate decisions produced by
# :class:`DecisionInferrer`. Extends ``decisions`` with ``inference_status``
# and ``inference_confidence`` so confirmed candidates retain their
# provenance. All columns are additive.
_V4_SQLITE = (
    """
    CREATE TABLE IF NOT EXISTS inferred_decisions (
        id TEXT PRIMARY KEY,
        session_id TEXT NOT NULL DEFAULT '',
        project_id TEXT NOT NULL DEFAULT '',
        candidate_title TEXT NOT NULL DEFAULT '',
        candidate_description TEXT NOT NULL DEFAULT '',
        candidate_tags TEXT NOT NULL DEFAULT '[]',
        files_affected TEXT NOT NULL DEFAULT '[]',
        inference_source TEXT NOT NULL DEFAULT 'ast_change',
        confidence REAL NOT NULL DEFAULT 0.0,
        status TEXT NOT NULL DEFAULT 'pending',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_inf_dec_session ON inferred_decisions(session_id)",
    "CREATE INDEX IF NOT EXISTS idx_inf_dec_project ON inferred_decisions(project_id)",
    "CREATE INDEX IF NOT EXISTS idx_inf_dec_status ON inferred_decisions(status)",
    "ALTER TABLE decisions ADD COLUMN inference_status TEXT NOT NULL DEFAULT 'explicit'",
    "ALTER TABLE decisions ADD COLUMN inference_confidence REAL NOT NULL DEFAULT 1.0",
)

_V4_POSTGRES = tuple(
    stmt.replace("REAL", "DOUBLE PRECISION") for stmt in _V4_SQLITE
)


# Migration v5 — memory staleness and lifecycle fields.
#
# Adds access tracking, staleness scoring, and supersede pointers to
# ``decisions`` and ``context_items``. All columns are additive — legacy
# rows default to fresh (no access recorded, zero staleness).
_V5_SQLITE = (
    "ALTER TABLE decisions ADD COLUMN last_accessed_at TEXT",
    "ALTER TABLE decisions ADD COLUMN access_count INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE decisions ADD COLUMN staleness_score REAL NOT NULL DEFAULT 0.0",
    "ALTER TABLE decisions ADD COLUMN staleness_signals TEXT NOT NULL DEFAULT '[]'",
    "ALTER TABLE decisions ADD COLUMN superseded_by TEXT",
    "ALTER TABLE decisions ADD COLUMN supersedes TEXT",
    "ALTER TABLE context_items ADD COLUMN last_accessed_at TEXT",
    "ALTER TABLE context_items ADD COLUMN access_count INTEGER NOT NULL DEFAULT 0",
    "ALTER TABLE context_items ADD COLUMN staleness_score REAL NOT NULL DEFAULT 0.0",
    "CREATE INDEX IF NOT EXISTS idx_decisions_staleness ON decisions(staleness_score)",
    "CREATE INDEX IF NOT EXISTS idx_decisions_superseded_by ON decisions(superseded_by)",
)

_V5_POSTGRES = tuple(
    stmt.replace("REAL", "DOUBLE PRECISION").replace("INTEGER", "BIGINT")
    for stmt in _V5_SQLITE
)


# Migration v6 — decision contradiction tracking.
#
# Persists ``DecisionConflict`` records produced by
# :class:`StalenessScorer.detect_contradictions`. Uniqueness is enforced
# on the ordered (decision_id_a, decision_id_b) pair so re-running
# detection will not duplicate known conflicts.
_V6_SQLITE = (
    """
    CREATE TABLE IF NOT EXISTS decision_conflicts (
        id TEXT PRIMARY KEY,
        project_id TEXT NOT NULL DEFAULT '',
        decision_id_a TEXT NOT NULL DEFAULT '',
        decision_id_b TEXT NOT NULL DEFAULT '',
        conflict_type TEXT NOT NULL DEFAULT 'scope_overlap',
        confidence REAL NOT NULL DEFAULT 0.0,
        description TEXT NOT NULL DEFAULT '',
        detected_at TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'active',
        resolved_by_decision_id TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )
    """,
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_conflict_pair "
    "ON decision_conflicts(decision_id_a, decision_id_b)",
    "CREATE INDEX IF NOT EXISTS idx_conflict_status ON decision_conflicts(status)",
    "CREATE INDEX IF NOT EXISTS idx_conflict_project ON decision_conflicts(project_id)",
)

_V6_POSTGRES = tuple(
    stmt.replace("REAL", "DOUBLE PRECISION") for stmt in _V6_SQLITE
)


# Migration v7 — universal active context tracking on sessions.
#
# Adds ``project_id``, ``cwd``, and ``last_tool_call_at`` to
# :class:`Session` so the MCP layer can:
#   * match a (project_id, agent_name) pair to an existing active session
#   * close sessions after a configurable inactivity window
#   * surface per-client session lineage in the dashboard
#
# All columns are additive; legacy sessions default to nullable values.
_V7_SQLITE = (
    "ALTER TABLE sessions ADD COLUMN project_id TEXT",
    "ALTER TABLE sessions ADD COLUMN cwd TEXT",
    "ALTER TABLE sessions ADD COLUMN last_tool_call_at TEXT",
    "CREATE INDEX IF NOT EXISTS idx_sessions_project_agent "
    "ON sessions(project_id, agent_name)",
    "CREATE INDEX IF NOT EXISTS idx_sessions_last_tool_call "
    "ON sessions(last_tool_call_at)",
)

_V7_POSTGRES = tuple(_V7_SQLITE)


# Migration v8 — onboarding walkthrough state.
#
# A single-row table capturing whether ``codeledger init`` has been
# completed and, if not, which step the developer reached in the
# browser-based walkthrough. The server reads this at startup to
# decide whether to render the onboarding flow or the dashboard.
_V8_SQLITE = (
    """
    CREATE TABLE IF NOT EXISTS _setup (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        setup_complete INTEGER NOT NULL DEFAULT 0,
        step_reached INTEGER NOT NULL DEFAULT 1,
        updated_at TEXT NOT NULL
    )
    """,
    "INSERT OR IGNORE INTO _setup (id, setup_complete, step_reached, updated_at) "
    "VALUES (1, 0, 1, datetime('now'))",
)

_V8_POSTGRES = (
    """
    CREATE TABLE IF NOT EXISTS _setup (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        setup_complete BOOLEAN NOT NULL DEFAULT FALSE,
        step_reached INTEGER NOT NULL DEFAULT 1,
        updated_at TEXT NOT NULL
    )
    """,
    "INSERT INTO _setup (id, setup_complete, step_reached, updated_at) "
    "VALUES (1, FALSE, 1, NOW()::text) ON CONFLICT (id) DO NOTHING",
)


MIGRATIONS: tuple[Migration, ...] = (
    Migration(
        version=1,
        name="initial_schema",
        sqlite_sql=_V1_SQLITE,
        postgresql_sql=_V1_POSTGRES,
    ),
    Migration(
        version=2,
        name="file_watcher_backend_tables",
        sqlite_sql=_V2_SQLITE,
        postgresql_sql=_V2_POSTGRES,
    ),
    Migration(
        version=3,
        name="change_event_abstraction",
        sqlite_sql=_V3_SQLITE,
        postgresql_sql=_V3_POSTGRES,
    ),
    Migration(
        version=4,
        name="passive_inference_candidates",
        sqlite_sql=_V4_SQLITE,
        postgresql_sql=_V4_POSTGRES,
    ),
    Migration(
        version=5,
        name="memory_lifecycle_fields",
        sqlite_sql=_V5_SQLITE,
        postgresql_sql=_V5_POSTGRES,
    ),
    Migration(
        version=6,
        name="decision_conflicts",
        sqlite_sql=_V6_SQLITE,
        postgresql_sql=_V6_POSTGRES,
    ),
    Migration(
        version=7,
        name="session_active_context_fields",
        sqlite_sql=_V7_SQLITE,
        postgresql_sql=_V7_POSTGRES,
    ),
    Migration(
        version=8,
        name="onboarding_setup_state",
        sqlite_sql=_V8_SQLITE,
        postgresql_sql=_V8_POSTGRES,
    ),
)


_MIGRATIONS_TABLE_SQLITE = """
    CREATE TABLE IF NOT EXISTS _migrations (
        version INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        applied_at TEXT NOT NULL
    )
"""

_MIGRATIONS_TABLE_POSTGRES = """
    CREATE TABLE IF NOT EXISTS _migrations (
        version BIGINT PRIMARY KEY,
        name TEXT NOT NULL,
        applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
"""


async def _applied_versions(backend: DatabaseBackend) -> set[int]:
    """Return the set of migration versions already recorded in _migrations."""
    rows = await backend.execute_raw("SELECT version FROM _migrations")
    return {int(r["version"]) for r in rows}


def _dialect(backend: DatabaseBackend) -> str:
    """Return 'sqlite' or 'postgresql' based on the backend class name."""
    cls = type(backend).__name__
    if cls == "SQLiteBackend":
        return "sqlite"
    if cls == "PostgreSQLBackend":
        return "postgresql"
    raise ValueError(f"Unknown backend type: {cls}")


async def apply_migrations(backend: DatabaseBackend) -> list[int]:
    """Apply all pending migrations. Returns the list of versions just applied.

    Safe to call repeatedly — migrations already recorded in ``_migrations`` are
    skipped.
    """
    dialect = _dialect(backend)
    bootstrap = (
        _MIGRATIONS_TABLE_SQLITE
        if dialect == "sqlite"
        else _MIGRATIONS_TABLE_POSTGRES
    )
    await backend.execute_raw(bootstrap)

    applied = await _applied_versions(backend)
    newly_applied: list[int] = []

    from datetime import UTC, datetime

    for migration in sorted(MIGRATIONS, key=lambda m: m.version):
        if migration.version in applied:
            continue
        statements = (
            migration.sqlite_sql
            if dialect == "sqlite"
            else migration.postgresql_sql
        )
        for stmt in statements:
            await backend.execute_raw(stmt)

        if dialect == "sqlite":
            await backend.execute_raw(
                "INSERT INTO _migrations (version, name, applied_at) VALUES (?, ?, ?)",
                (migration.version, migration.name, datetime.now(UTC).isoformat()),
            )
        else:
            await backend.execute_raw(
                "INSERT INTO _migrations (version, name) VALUES ($1, $2)",
                (migration.version, migration.name),
            )
        newly_applied.append(migration.version)

    return newly_applied
