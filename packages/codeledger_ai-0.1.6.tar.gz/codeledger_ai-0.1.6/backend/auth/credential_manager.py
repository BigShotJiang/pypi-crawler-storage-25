"""Credential manager with keyring, AES-256-GCM file vault, and env backends.

Provides a unified API for storing and retrieving secrets used by CodeLedger.
Reads fall through a priority chain: environment variables, OS keyring, then
encrypted file vault. Writes go to the configured backend only.

Security invariants enforced:
- SEC-04: No plaintext credentials on disk. File vault uses AES-256-GCM with
  PBKDF2 key derivation (600,000 iterations, random salt).
- SEC-08: JWT signing key lives exclusively in the credential vault.
- SEC-09: Vault files are created with 0o600 permissions (owner read/write only).
"""

from __future__ import annotations

import json
import logging
import os
import sys
from pathlib import Path
from typing import TYPE_CHECKING

import keyring as keyring_lib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.hashes import SHA256
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

if TYPE_CHECKING:
    from backend.config import CredentialConfig

logger = logging.getLogger(__name__)


class CredentialError(Exception):
    """Raised for credential storage operation failures."""


_SALT_SIZE = 16
_NONCE_SIZE = 12
_KEY_SIZE = 32  # AES-256
_DEFAULT_ITERATIONS = 600_000


class FileVault:
    """AES-256-GCM encrypted file-based credential store.

    File format: salt (16 bytes) || nonce (12 bytes) || ciphertext+tag (variable).
    Key derived from passphrase + salt via PBKDF2-HMAC-SHA256.
    """

    def __init__(
        self, path: Path, passphrase: str, *, iterations: int = _DEFAULT_ITERATIONS
    ) -> None:
        self._path = path
        self._iterations = iterations
        self._salt = self._load_or_create_salt()
        self._key = self._derive_key(passphrase.encode("utf-8"), self._salt)

    def _load_or_create_salt(self) -> bytes:
        """Read salt from existing vault file, or generate a new one."""
        if self._path.exists() and self._path.stat().st_size >= _SALT_SIZE:
            with open(self._path, "rb") as f:
                return f.read(_SALT_SIZE)
        return os.urandom(_SALT_SIZE)

    def _derive_key(self, passphrase: bytes, salt: bytes) -> bytes:
        kdf = PBKDF2HMAC(
            algorithm=SHA256(),
            length=_KEY_SIZE,
            salt=salt,
            iterations=self._iterations,
        )
        return kdf.derive(passphrase)

    def _read_all(self) -> dict[str, str]:
        """Decrypt and return all stored entries, or empty dict if vault is new."""
        if not self._path.exists():
            return {}
        data = self._path.read_bytes()
        if len(data) < _SALT_SIZE + _NONCE_SIZE + 1:
            return {}
        nonce = data[_SALT_SIZE : _SALT_SIZE + _NONCE_SIZE]
        ciphertext = data[_SALT_SIZE + _NONCE_SIZE :]
        try:
            plaintext = AESGCM(self._key).decrypt(nonce, ciphertext, None)
        except Exception as exc:
            raise CredentialError(
                f"Failed to decrypt vault at {self._path}: {exc}"
            ) from exc
        result: dict[str, str] = json.loads(plaintext)
        return result

    def _write_all(self, entries: dict[str, str]) -> None:
        """Encrypt and atomically write all entries to the vault file."""
        plaintext = json.dumps(entries, separators=(",", ":")).encode("utf-8")
        nonce = os.urandom(_NONCE_SIZE)
        ciphertext = AESGCM(self._key).encrypt(nonce, plaintext, None)
        payload = self._salt + nonce + ciphertext

        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = self._path.with_suffix(".tmp")
        try:
            tmp_path.write_bytes(payload)
            if sys.platform != "win32":
                os.chmod(tmp_path, 0o600)
            tmp_path.replace(self._path)
        except OSError:
            if tmp_path.exists():
                tmp_path.unlink()
            raise

    def get(self, entry_key: str) -> str | None:
        """Return the value for entry_key, or None if not found."""
        return self._read_all().get(entry_key)

    def set(self, entry_key: str, value: str) -> None:
        """Store or overwrite an entry in the vault."""
        entries = self._read_all()
        entries[entry_key] = value
        self._write_all(entries)

    def delete(self, entry_key: str) -> None:
        """Remove an entry from the vault. No error if key is absent."""
        entries = self._read_all()
        if entry_key in entries:
            del entries[entry_key]
            self._write_all(entries)


class CredentialManager:
    """Unified credential storage with env -> keyring -> file vault fallback.

    Reads check all backends in priority order. Writes go to the configured
    backend only (keyring or file). The env backend is read-only.
    """

    def __init__(
        self,
        config: CredentialConfig,
        passphrase: str | None = None,
        *,
        _iterations: int = _DEFAULT_ITERATIONS,
    ) -> None:
        self._config = config
        self._file_vault: FileVault | None = None

        effective_passphrase = passphrase or os.environ.get(
            "CODELEDGER_VAULT_PASSPHRASE"
        )
        if effective_passphrase:
            vault_path = Path(os.path.expanduser(config.vault_path))
            self._file_vault = FileVault(
                vault_path, effective_passphrase, iterations=_iterations
            )
        elif config.backend == "file":
            raise CredentialError(
                "File vault backend requires a passphrase. "
                "Set CODELEDGER_VAULT_PASSPHRASE or pass --passphrase."
            )

    def get(self, provider: str, key: str) -> str | None:
        """Retrieve a credential, checking env -> keyring -> file vault."""
        value = self._get_env(provider, key)
        if value is not None:
            return value
        value = self._get_keyring(provider, key)
        if value is not None:
            return value
        return self._get_file_vault(provider, key)

    def set(self, provider: str, key: str, value: str) -> None:
        """Store a credential in the configured backend."""
        backend = self._config.backend
        if backend == "keyring":
            self._set_keyring(provider, key, value)
        elif backend == "file":
            self._set_file_vault(provider, key, value)
        else:
            raise CredentialError("Cannot write credentials to env-only backend")

    def delete(self, provider: str, key: str) -> None:
        """Delete a credential from the configured backend."""
        backend = self._config.backend
        if backend == "keyring":
            self._delete_keyring(provider, key)
        elif backend == "file":
            self._delete_file_vault(provider, key)
        else:
            raise CredentialError("Cannot delete credentials from env-only backend")

    def rotate(self, provider: str, key: str, new_value: str) -> None:
        """Atomically replace a credential value.

        Uses the same atomic write guarantees as set(). If the write fails,
        the previous value is preserved.
        """
        self.set(provider, key, new_value)

    # -- env backend (read-only) --

    @staticmethod
    def _env_var_name(provider: str, key: str) -> str:
        return f"CODELEDGER_CRED_{provider.upper()}_{key.upper()}"

    def _get_env(self, provider: str, key: str) -> str | None:
        return os.environ.get(self._env_var_name(provider, key))

    # -- keyring backend --

    @staticmethod
    def _keyring_service(provider: str) -> str:
        return f"codeledger:{provider}"

    def _get_keyring(self, provider: str, key: str) -> str | None:
        try:
            return keyring_lib.get_password(self._keyring_service(provider), key)
        except Exception:
            # Keyring backends raise varied errors (DBus, SecretService, etc.)
            logger.debug("Keyring read failed for %s/%s", provider, key, exc_info=True)
            return None

    def _set_keyring(self, provider: str, key: str, value: str) -> None:
        try:
            keyring_lib.set_password(self._keyring_service(provider), key, value)
        except Exception as exc:
            raise CredentialError(
                f"Keyring write failed for {provider}/{key}: {exc}"
            ) from exc

    def _delete_keyring(self, provider: str, key: str) -> None:
        try:
            keyring_lib.delete_password(self._keyring_service(provider), key)
        except Exception as exc:
            raise CredentialError(
                f"Keyring delete failed for {provider}/{key}: {exc}"
            ) from exc

    # -- file vault backend --

    @staticmethod
    def _vault_entry_key(provider: str, key: str) -> str:
        return f"{provider}:{key}"

    def _get_file_vault(self, provider: str, key: str) -> str | None:
        if self._file_vault is None:
            return None
        try:
            return self._file_vault.get(self._vault_entry_key(provider, key))
        except CredentialError:
            logger.debug(
                "File vault read failed for %s/%s", provider, key, exc_info=True
            )
            return None

    def _set_file_vault(self, provider: str, key: str, value: str) -> None:
        if self._file_vault is None:
            raise CredentialError("File vault not initialized (no passphrase provided)")
        self._file_vault.set(self._vault_entry_key(provider, key), value)

    def _delete_file_vault(self, provider: str, key: str) -> None:
        if self._file_vault is None:
            raise CredentialError("File vault not initialized (no passphrase provided)")
        self._file_vault.delete(self._vault_entry_key(provider, key))
