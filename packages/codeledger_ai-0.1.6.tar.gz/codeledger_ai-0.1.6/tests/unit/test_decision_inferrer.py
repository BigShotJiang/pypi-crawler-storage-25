"""Tests for backend.intelligence.decision_inferrer."""

from __future__ import annotations

import json
import uuid
from typing import TYPE_CHECKING

import pytest

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.intelligence.ast_tracker import ASTTracker
from backend.intelligence.decision_inferrer import DecisionInferrer
from backend.models import Decision, InferredDecision, Session

if TYPE_CHECKING:
    from pathlib import Path


_DIFF_SINGLE = (
    "diff --git a/auth_service.py b/auth_service.py\n"
    "--- a/auth_service.py\n"
    "+++ b/auth_service.py\n"
    "@@ -0,0 +1,2 @@\n"
    "+def hash_password(pw):\n"
    "+    return pw\n"
)

_DIFF_OTHER = (
    "diff --git a/other.py b/other.py\n"
    "--- a/other.py\n"
    "+++ b/other.py\n"
    "@@ -0,0 +1,2 @@\n"
    "+def helper(n):\n"
    "+    return n\n"
)


@pytest.fixture
async def db(tmp_path: Path) -> SQLiteBackend:
    backend = SQLiteBackend(tmp_path / "infer.db")
    await backend.connect()
    await apply_migrations(backend)
    yield backend
    await backend.close()


@pytest.fixture
def tracker(db: SQLiteBackend) -> ASTTracker:
    return ASTTracker(db=db)


@pytest.fixture
def inferrer(db: SQLiteBackend, tracker: ASTTracker) -> DecisionInferrer:
    return DecisionInferrer(db=db, ast_tracker=tracker)


async def _start_session(db: SQLiteBackend) -> Session:
    session = Session(agent_name="inferrer-test", status="active")
    await db.insert("sessions", session.to_dict())
    return session


class TestInferFromSession:
    async def test_single_file_single_commit_gets_0_75(
        self,
        db: SQLiteBackend,
        tracker: ASTTracker,
        inferrer: DecisionInferrer,
    ) -> None:
        session = await _start_session(db)
        await tracker.process_change_event(
            change_event_id="cmt-single",
            change_event_type="git_commit",
            diff_text=_DIFF_SINGLE,
            project_id="p1",
            active_session_id=str(session.id),
        )
        candidates = await inferrer.infer_from_session(
            session_id=str(session.id), project_id="p1"
        )
        file_candidates = [c for c in candidates if c.inference_source == "ast_change"]
        assert len(file_candidates) == 1
        assert file_candidates[0].confidence == 0.75
        assert "hash_password" in file_candidates[0].candidate_title
        assert "auth_service.py" in file_candidates[0].candidate_title

    async def test_multi_file_lowered_to_0_45(
        self,
        db: SQLiteBackend,
        tracker: ASTTracker,
        inferrer: DecisionInferrer,
    ) -> None:
        session = await _start_session(db)
        await tracker.process_change_event(
            change_event_id="cmt-multi-a",
            change_event_type="git_commit",
            diff_text=_DIFF_SINGLE,
            project_id="p1",
            active_session_id=str(session.id),
        )
        await tracker.process_change_event(
            change_event_id="cmt-multi-b",
            change_event_type="git_commit",
            diff_text=_DIFF_OTHER,
            project_id="p1",
            active_session_id=str(session.id),
        )
        candidates = await inferrer.infer_from_session(
            session_id=str(session.id), project_id="p1"
        )
        file_candidates = [c for c in candidates if c.inference_source == "ast_change"]
        assert len(file_candidates) == 2
        assert all(c.confidence == 0.45 for c in file_candidates)

    async def test_files_already_covered_by_explicit_decision_not_inferred(
        self,
        db: SQLiteBackend,
        tracker: ASTTracker,
        inferrer: DecisionInferrer,
    ) -> None:
        session = await _start_session(db)
        # Log an explicit decision.create tool call referencing auth_service.py.
        now_iso = session.created_at.isoformat()
        await db.insert(
            "session_events",
            {
                "id": str(uuid.uuid4()),
                "session_id": str(session.id),
                "event_type": "tool_call",
                "payload": json.dumps(
                    {
                        "tool": "decision.create",
                        "files_affected": ["auth_service.py"],
                    }
                ),
                "created_at": now_iso,
                "updated_at": now_iso,
            },
        )
        await tracker.process_change_event(
            change_event_id="cmt-cov",
            change_event_type="git_commit",
            diff_text=_DIFF_SINGLE,
            project_id="p1",
            active_session_id=str(session.id),
        )
        candidates = await inferrer.infer_from_session(
            session_id=str(session.id), project_id="p1"
        )
        files_in_candidates = {
            f for c in candidates for f in c.files_affected
        }
        assert "auth_service.py" not in files_in_candidates

    async def test_already_linked_decision_not_re_inferred(
        self,
        db: SQLiteBackend,
        tracker: ASTTracker,
        inferrer: DecisionInferrer,
    ) -> None:
        session = await _start_session(db)
        # Seed a decision that the tracker will link by title/file match.
        decision = Decision(
            title="Touch auth_service.py for hash_password",
            description="adds hash_password in auth_service.py",
            recorded_in_session_id=session.id,
        )
        await db.insert("decisions", decision.to_dict())
        await tracker.process_change_event(
            change_event_id="cmt-linked",
            change_event_type="git_commit",
            diff_text=_DIFF_SINGLE,
            project_id="p1",
            active_session_id=str(session.id),
        )
        candidates = await inferrer.infer_from_session(
            session_id=str(session.id), project_id="p1"
        )
        file_candidates = [c for c in candidates if c.inference_source == "ast_change"]
        assert file_candidates == []

    async def test_empty_session_returns_empty_list(
        self, db: SQLiteBackend, inferrer: DecisionInferrer
    ) -> None:
        session = await _start_session(db)
        candidates = await inferrer.infer_from_session(
            session_id=str(session.id), project_id="p1"
        )
        assert candidates == []

    async def test_session_pattern_triggers_module_level_candidate(
        self, db: SQLiteBackend, inferrer: DecisionInferrer
    ) -> None:
        session = await _start_session(db)
        now_iso = session.created_at.isoformat()
        for fname in ("a.py", "b.py", "c.py"):
            await db.insert(
                "session_events",
                {
                    "id": str(uuid.uuid4()),
                    "session_id": str(session.id),
                    "event_type": "tool_call",
                    "payload": json.dumps(
                        {
                            "tool": "context.get_for_file",
                            "file_path": f"backend/auth/{fname}",
                        }
                    ),
                    "created_at": now_iso,
                    "updated_at": now_iso,
                },
            )
        candidates = await inferrer.infer_from_session(
            session_id=str(session.id), project_id="p1"
        )
        pattern = [c for c in candidates if c.inference_source == "session_pattern"]
        assert len(pattern) == 1
        assert pattern[0].confidence == 0.4
        assert "auth" in pattern[0].candidate_title

    async def test_rejected_candidate_not_re_inferred(
        self,
        db: SQLiteBackend,
        tracker: ASTTracker,
        inferrer: DecisionInferrer,
    ) -> None:
        session = await _start_session(db)
        # Pre-seed a rejected InferredDecision for auth_service.py
        rejected = InferredDecision(
            session_id=session.id,
            project_id="p1",
            candidate_title="Add hash_password to auth_service.py",
            candidate_description="rejected",
            files_affected=["auth_service.py"],
            inference_source="ast_change",
            confidence=0.75,
            status="rejected",
        )
        await db.insert("inferred_decisions", rejected.to_dict())
        await tracker.process_change_event(
            change_event_id="cmt-re",
            change_event_type="git_commit",
            diff_text=_DIFF_SINGLE,
            project_id="p1",
            active_session_id=str(session.id),
        )
        candidates = await inferrer.infer_from_session(
            session_id=str(session.id), project_id="p1"
        )
        file_candidates = [c for c in candidates if c.inference_source == "ast_change"]
        # Previously rejected file is skipped on subsequent inference.
        assert all(
            "auth_service.py" not in c.files_affected for c in file_candidates
        )


# ---------------------------------------------------------------------------
# Auto-confirm high-confidence inferred decisions (Prompt 5)
# ---------------------------------------------------------------------------


class TestAutoConfirmHighConfidence:
    async def test_promotes_candidates_at_or_above_threshold(
        self, db: SQLiteBackend, inferrer: DecisionInferrer
    ) -> None:
        session = await _start_session(db)
        high = InferredDecision(
            session_id=session.id,
            project_id="p1",
            candidate_title="Add f in g.py",
            candidate_description="high-confidence candidate",
            files_affected=["g.py"],
            inference_source="ast_change",
            confidence=0.8,
            status="pending",
        )
        low = InferredDecision(
            session_id=session.id,
            project_id="p1",
            candidate_title="Maybe touch h.py",
            candidate_description="low-confidence",
            files_affected=["h.py"],
            inference_source="session_pattern",
            confidence=0.5,
            status="pending",
        )
        await db.insert("inferred_decisions", high.to_dict())
        await db.insert("inferred_decisions", low.to_dict())

        promoted = await inferrer.auto_confirm_high_confidence(
            session_id=str(session.id), project_id="p1", threshold=0.75
        )
        assert len(promoted) == 1
        assert promoted[0].title == "Add f in g.py"
        assert promoted[0].inference_status == "confirmed"
        # Low-confidence candidate remains pending.
        low_row = await db.get_by_id("inferred_decisions", str(low.id))
        assert low_row["status"] == "pending"
        # High-confidence candidate marked confirmed on the InferredDecision.
        high_row = await db.get_by_id("inferred_decisions", str(high.id))
        assert high_row["status"] == "confirmed"

    async def test_none_threshold_equivalent_to_manual_review(
        self, db: SQLiteBackend, inferrer: DecisionInferrer
    ) -> None:
        # When the handler's threshold is None, auto_confirm_high_confidence
        # is never invoked — the caller simply leaves candidates pending.
        session = await _start_session(db)
        candidate = InferredDecision(
            session_id=session.id,
            project_id="p1",
            candidate_title="x",
            confidence=0.9,
            status="pending",
        )
        await db.insert("inferred_decisions", candidate.to_dict())
        # Explicit call with a threshold of 1.1 leaves it pending (defensively).
        promoted = await inferrer.auto_confirm_high_confidence(
            session_id=str(session.id), project_id="p1", threshold=1.0
        )
        # confidence >= 1.0 is allowed (equal boundary), so a 0.9 candidate
        # stays pending in this configuration.
        assert promoted == []
        row = await db.get_by_id("inferred_decisions", str(candidate.id))
        assert row["status"] == "pending"

    async def test_threshold_validation(
        self, inferrer: DecisionInferrer
    ) -> None:
        with pytest.raises(ValueError):
            await inferrer.auto_confirm_high_confidence(
                session_id="sid", project_id="p", threshold=1.5
            )
        with pytest.raises(ValueError):
            await inferrer.auto_confirm_high_confidence(
                session_id="sid", project_id="p", threshold=-0.1
            )
