"""Tests for backend.models — domain model dataclasses and serialization.

Covers: default construction, to_dict serialization, from_dict deserialization,
round-trip consistency, edge cases (extra keys, missing keys, None fields), and
structural consistency across all model classes.
"""

from __future__ import annotations

import dataclasses
import json
import uuid
from datetime import UTC, datetime

import pytest

from backend.models import (
    ASTChange,
    ContextItem,
    Decision,
    FileSnapshot,
    Model,
    PersonalAccessToken,
    ProvenanceEdge,
    ServiceConnection,
    Session,
    Sprint,
    Story,
    UnlinkedCommit,
    UnlinkedFileChange,
    User,
    Verification,
)

ALL_MODELS: list[type[Model]] = [
    User,
    Decision,
    Story,
    Sprint,
    Session,
    ContextItem,
    Verification,
    ASTChange,
    ProvenanceEdge,
    ServiceConnection,
    PersonalAccessToken,
    FileSnapshot,
    UnlinkedFileChange,
    UnlinkedCommit,
]


# ---------------------------------------------------------------------------
# Default construction
# ---------------------------------------------------------------------------


class TestModelDefaults:
    """All models can be created with default values."""

    @pytest.mark.parametrize("model_cls", ALL_MODELS, ids=lambda c: c.__name__)
    def test_default_construction(self, model_cls: type[Model]) -> None:
        instance = model_cls()
        assert isinstance(instance.id, uuid.UUID)
        assert isinstance(instance.created_at, datetime)
        assert isinstance(instance.updated_at, datetime)

    def test_unique_ids_per_instance(self) -> None:
        a = Decision()
        b = Decision()
        assert a.id != b.id

    def test_decision_defaults(self) -> None:
        d = Decision()
        assert d.status == "unverified"
        assert d.tags == []
        assert d.recorded_by_user_id is None

    def test_story_defaults(self) -> None:
        s = Story()
        assert s.status == "backlog"
        assert s.acceptance_criteria == []
        assert s.points is None
        assert s.sprint_id is None

    def test_session_defaults(self) -> None:
        s = Session()
        assert s.status == "active"
        assert s.files_touched == []
        assert s.ended_at is None

    def test_sprint_defaults(self) -> None:
        s = Sprint()
        assert s.status == "planning"
        assert s.start_date is None
        assert s.end_date is None

    def test_service_connection_defaults(self) -> None:
        sc = ServiceConnection()
        assert sc.status == "disconnected"
        assert sc.scopes == []
        assert sc.expires_at is None


# ---------------------------------------------------------------------------
# Serialization (to_dict)
# ---------------------------------------------------------------------------


class TestToDict:
    """to_dict produces database-compatible primitives."""

    def test_uuid_serialized_as_string(self) -> None:
        uid = uuid.uuid4()
        d = Decision(id=uid)
        assert d.to_dict()["id"] == str(uid)

    def test_datetime_serialized_as_isoformat(self) -> None:
        ts = datetime(2026, 1, 15, 10, 30, 0, tzinfo=UTC)
        d = Decision(created_at=ts)
        assert d.to_dict()["created_at"] == ts.isoformat()

    def test_list_serialized_as_json_string(self) -> None:
        tags = ["database", "infra"]
        d = Decision(tags=tags)
        assert d.to_dict()["tags"] == json.dumps(tags)

    def test_none_preserved(self) -> None:
        s = Session(ended_at=None, user_id=None)
        data = s.to_dict()
        assert data["ended_at"] is None
        assert data["user_id"] is None

    def test_string_passthrough(self) -> None:
        d = Decision(title="Use PostgreSQL")
        assert d.to_dict()["title"] == "Use PostgreSQL"

    def test_int_passthrough(self) -> None:
        s = Story(points=5)
        assert s.to_dict()["points"] == 5

    def test_full_decision_dict(self) -> None:
        decision_id = uuid.uuid4()
        user_id = uuid.uuid4()
        session_id = uuid.uuid4()
        ts = datetime(2026, 1, 15, 10, 30, 0, tzinfo=UTC)
        d = Decision(
            id=decision_id,
            title="Use PostgreSQL",
            description="For scalability",
            tags=["database", "infra"],
            status="passed",
            recorded_by_user_id=user_id,
            recorded_in_session_id=session_id,
            created_at=ts,
            updated_at=ts,
        )
        data = d.to_dict()
        assert data["id"] == str(decision_id)
        assert data["title"] == "Use PostgreSQL"
        assert data["description"] == "For scalability"
        assert data["tags"] == '["database", "infra"]'
        assert data["status"] == "passed"
        assert data["recorded_by_user_id"] == str(user_id)
        assert data["recorded_in_session_id"] == str(session_id)
        assert data["created_at"] == ts.isoformat()
        assert data["updated_at"] == ts.isoformat()


# ---------------------------------------------------------------------------
# Round-trip serialization
# ---------------------------------------------------------------------------


class TestRoundTrip:
    """to_dict followed by from_dict produces an equal object."""

    def test_decision_round_trip(self) -> None:
        ts = datetime(2026, 1, 15, 10, 30, 0, tzinfo=UTC)
        original = Decision(
            id=uuid.uuid4(),
            title="Use PostgreSQL",
            description="For scalability",
            tags=["database", "infra"],
            status="passed",
            recorded_by_user_id=uuid.uuid4(),
            recorded_in_session_id=None,
            created_at=ts,
            updated_at=ts,
        )
        assert Decision.from_dict(original.to_dict()) == original

    def test_session_round_trip(self) -> None:
        start = datetime(2026, 3, 10, 8, 0, 0, tzinfo=UTC)
        end = datetime(2026, 3, 10, 9, 30, 0, tzinfo=UTC)
        original = Session(
            id=uuid.uuid4(),
            user_id=uuid.uuid4(),
            agent_name="claude-sonnet",
            started_at=start,
            ended_at=end,
            status="completed",
            files_touched=["src/main.py", "tests/test_main.py"],
            created_at=start,
            updated_at=end,
        )
        assert Session.from_dict(original.to_dict()) == original

    def test_user_round_trip(self) -> None:
        ts = datetime(2026, 2, 1, 12, 0, 0, tzinfo=UTC)
        original = User(
            id=uuid.uuid4(),
            email="test@example.com",
            name="Test User",
            provider="google",
            avatar_url="https://example.com/avatar.jpg",
            password_hash=None,
            created_at=ts,
            updated_at=ts,
        )
        assert User.from_dict(original.to_dict()) == original

    def test_story_round_trip(self) -> None:
        ts = datetime(2026, 4, 1, 9, 0, 0, tzinfo=UTC)
        original = Story(
            id=uuid.uuid4(),
            title="Implement auth",
            description="OAuth + email login",
            acceptance_criteria=["Google sign-in works", "Email/password works"],
            status="in_progress",
            points=5,
            sprint_id=uuid.uuid4(),
            created_at=ts,
            updated_at=ts,
        )
        assert Story.from_dict(original.to_dict()) == original

    def test_sprint_round_trip_with_dates(self) -> None:
        ts = datetime(2026, 4, 1, 0, 0, 0, tzinfo=UTC)
        end = datetime(2026, 4, 14, 0, 0, 0, tzinfo=UTC)
        original = Sprint(
            id=uuid.uuid4(),
            name="Sprint 1",
            start_date=ts,
            end_date=end,
            status="active",
            created_at=ts,
            updated_at=ts,
        )
        assert Sprint.from_dict(original.to_dict()) == original

    def test_sprint_round_trip_null_dates(self) -> None:
        ts = datetime(2026, 4, 1, 0, 0, 0, tzinfo=UTC)
        original = Sprint(
            id=uuid.uuid4(),
            name="Future Sprint",
            start_date=None,
            end_date=None,
            status="planning",
            created_at=ts,
            updated_at=ts,
        )
        assert Sprint.from_dict(original.to_dict()) == original

    def test_service_connection_round_trip(self) -> None:
        ts = datetime(2026, 5, 1, 0, 0, 0, tzinfo=UTC)
        exp = datetime(2026, 6, 1, 0, 0, 0, tzinfo=UTC)
        original = ServiceConnection(
            id=uuid.uuid4(),
            user_id=uuid.uuid4(),
            provider="github",
            status="connected",
            scopes=["repo", "user:email"],
            expires_at=exp,
            created_at=ts,
            updated_at=ts,
        )
        assert ServiceConnection.from_dict(original.to_dict()) == original

    def test_personal_access_token_round_trip(self) -> None:
        ts = datetime(2026, 5, 1, 0, 0, 0, tzinfo=UTC)
        original = PersonalAccessToken(
            id=uuid.uuid4(),
            user_id=uuid.uuid4(),
            name="ci-token",
            pat_hash="a1b2c3d4e5f6",
            expires_at=datetime(2027, 1, 1, 0, 0, 0, tzinfo=UTC),
            last_used_at=ts,
            created_at=ts,
            updated_at=ts,
        )
        assert PersonalAccessToken.from_dict(original.to_dict()) == original

    @pytest.mark.parametrize("model_cls", ALL_MODELS, ids=lambda c: c.__name__)
    def test_default_round_trip(self, model_cls: type[Model]) -> None:
        original = model_cls()
        restored = model_cls.from_dict(original.to_dict())
        assert restored == original


# ---------------------------------------------------------------------------
# from_dict edge cases
# ---------------------------------------------------------------------------


class TestFromDictEdgeCases:
    """from_dict handles extra keys, missing keys, and partial data."""

    def test_extra_keys_ignored(self) -> None:
        ts = datetime(2026, 1, 1, 0, 0, 0, tzinfo=UTC)
        data = Decision(created_at=ts, updated_at=ts).to_dict()
        data["nonexistent_field"] = "should be ignored"
        data["another_extra"] = 42
        restored = Decision.from_dict(data)
        assert not hasattr(restored, "nonexistent_field")

    def test_missing_fields_use_defaults(self) -> None:
        d = Decision.from_dict({"title": "Minimal"})
        assert d.title == "Minimal"
        assert isinstance(d.id, uuid.UUID)
        assert d.status == "unverified"
        assert d.tags == []

    def test_empty_dict_uses_all_defaults(self) -> None:
        d = Decision.from_dict({})
        assert isinstance(d.id, uuid.UUID)
        assert isinstance(d.created_at, datetime)
        assert d.title == ""

    def test_empty_list_round_trip(self) -> None:
        d = Decision(tags=[])
        data = d.to_dict()
        assert data["tags"] == "[]"
        restored = Decision.from_dict(data)
        assert restored.tags == []


# ---------------------------------------------------------------------------
# Structural consistency
# ---------------------------------------------------------------------------


class TestStructuralConsistency:
    """All models share the expected base structure."""

    @pytest.mark.parametrize("model_cls", ALL_MODELS, ids=lambda c: c.__name__)
    def test_has_id_and_timestamps(self, model_cls: type[Model]) -> None:
        field_names = {f.name for f in dataclasses.fields(model_cls)}
        assert "id" in field_names
        assert "created_at" in field_names
        assert "updated_at" in field_names

    @pytest.mark.parametrize("model_cls", ALL_MODELS, ids=lambda c: c.__name__)
    def test_to_dict_returns_dict_with_string_id(self, model_cls: type[Model]) -> None:
        data = model_cls().to_dict()
        assert isinstance(data, dict)
        assert isinstance(data["id"], str)

    def test_model_count(self) -> None:
        assert len(ALL_MODELS) == 14


# ---------------------------------------------------------------------------
# File watcher backend models
# ---------------------------------------------------------------------------


class TestFileWatcherModels:
    """Coverage for FileSnapshot and UnlinkedFileChange round-trips."""

    def test_file_snapshot_round_trip(self) -> None:
        ts = datetime(2026, 4, 15, 10, 0, 0, tzinfo=UTC)
        original = FileSnapshot(
            id=uuid.uuid4(),
            project_id="proj-a",
            file_path="src/main.py",
            content_hash="a" * 64,
            content="print('hi')\n",
            snapshot_at=ts,
            session_id=uuid.uuid4(),
            created_at=ts,
            updated_at=ts,
        )
        assert FileSnapshot.from_dict(original.to_dict()) == original

    def test_file_snapshot_null_session(self) -> None:
        original = FileSnapshot(project_id="p", file_path="a.py")
        assert FileSnapshot.from_dict(original.to_dict()) == original
        assert original.to_dict()["session_id"] is None

    def test_unlinked_file_change_round_trip(self) -> None:
        ts = datetime(2026, 4, 15, 10, 0, 0, tzinfo=UTC)
        original = UnlinkedFileChange(
            id=uuid.uuid4(),
            snapshot_id=str(uuid.uuid4()),
            file_path="src/main.py",
            project_id="proj-a",
            detected_at=ts,
            structurally_changed_symbols=["foo", "Bar"],
            session_id=uuid.uuid4(),
            override_reason="hotfix",
            created_at=ts,
            updated_at=ts,
        )
        assert UnlinkedFileChange.from_dict(original.to_dict()) == original

    def test_unlinked_file_change_list_serialization(self) -> None:
        u = UnlinkedFileChange(structurally_changed_symbols=["a", "b"])
        data = u.to_dict()
        assert data["structurally_changed_symbols"] == json.dumps(["a", "b"])

    def test_unlinked_commit_round_trip(self) -> None:
        ts = datetime(2026, 4, 15, 10, 0, 0, tzinfo=UTC)
        original = UnlinkedCommit(
            id=uuid.uuid4(),
            commit_hash="deadbeef",
            project_id="proj-a",
            detected_at=ts,
            structurally_changed_symbols=["foo", "Bar"],
            session_id=uuid.uuid4(),
            override_reason="hotfix",
            created_at=ts,
            updated_at=ts,
        )
        assert UnlinkedCommit.from_dict(original.to_dict()) == original

    def test_ast_change_has_change_event_fields(self) -> None:
        change = ASTChange(
            commit_hash="abc123",
            change_event_id="abc123",
            change_event_type="git_commit",
            project_id="proj-a",
            file_path="x.py",
        )
        data = change.to_dict()
        assert data["change_event_id"] == "abc123"
        assert data["change_event_type"] == "git_commit"
        assert data["project_id"] == "proj-a"
        restored = ASTChange.from_dict(data)
        assert restored == change

    def test_ast_change_file_snapshot_round_trip(self) -> None:
        snap_id = str(uuid.uuid4())
        change = ASTChange(
            change_event_id=snap_id,
            change_event_type="file_snapshot",
            project_id="proj-b",
            file_path="y.py",
            entity_name="foo",
        )
        restored = ASTChange.from_dict(change.to_dict())
        assert restored == change
        assert restored.commit_hash == ""  # not a git event


# ---------------------------------------------------------------------------
# Phase 2 upgrade: InferredDecision and Decision.inference_* fields
# ---------------------------------------------------------------------------


class TestInferredDecisionModel:
    """Round-trip and defaults for the InferredDecision dataclass."""

    def test_defaults(self) -> None:
        from backend.models import InferredDecision

        inferred = InferredDecision()
        assert inferred.status == "pending"
        assert inferred.inference_source == "ast_change"
        assert inferred.confidence == 0.0
        assert inferred.files_affected == []
        assert inferred.candidate_tags == []

    def test_round_trip(self) -> None:
        from backend.models import InferredDecision

        inferred = InferredDecision(
            session_id=uuid.uuid4(),
            project_id="proj-x",
            candidate_title="Add foo to bar.py",
            candidate_description="…",
            candidate_tags=["inferred"],
            files_affected=["bar.py", "baz.py"],
            inference_source="ast_change",
            confidence=0.6,
            status="pending",
        )
        restored = InferredDecision.from_dict(inferred.to_dict())
        assert restored == inferred

    def test_accepts_all_inference_sources(self) -> None:
        from backend.models import InferredDecision

        for source in ("ast_change", "session_pattern", "both"):
            inferred = InferredDecision(inference_source=source)
            assert InferredDecision.from_dict(inferred.to_dict()).inference_source == source


class TestDecisionInferenceFields:
    """Phase 2 upgrade adds inference_status + inference_confidence."""

    def test_defaults(self) -> None:
        from backend.models import Decision

        d = Decision()
        assert d.inference_status == "explicit"
        assert d.inference_confidence == 1.0

    def test_round_trip_with_inferred_fields(self) -> None:
        from backend.models import Decision

        d = Decision(
            title="t",
            description="d",
            inference_status="confirmed",
            inference_confidence=0.75,
        )
        restored = Decision.from_dict(d.to_dict())
        assert restored.inference_status == "confirmed"
        assert restored.inference_confidence == 0.75


class TestDecisionConflictModel:
    def test_defaults(self) -> None:
        from backend.models import DecisionConflict

        c = DecisionConflict()
        assert c.status == "active"
        assert c.confidence == 0.0
        assert c.conflict_type == "scope_overlap"
        assert c.resolved_by_decision_id is None

    def test_round_trip(self) -> None:
        from backend.models import DecisionConflict

        c = DecisionConflict(
            project_id="p",
            decision_id_a="a",
            decision_id_b="b",
            conflict_type="direct_contradiction",
            confidence=0.85,
            description="opposing",
            status="active",
        )
        restored = DecisionConflict.from_dict(c.to_dict())
        assert restored == c
