"""SEC-01 through SEC-11 invariant tests.

Each class corresponds to one numbered invariant from CLAUDE.md. Every
class has at least one concrete assertion.
"""

from __future__ import annotations

import json
import re
import sys
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Any

import pytest

from backend.db.db_backend import ALLOWED_TABLES, SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.mcp.tool_handlers import ToolHandlers

if TYPE_CHECKING:
    from fastapi.testclient import TestClient


# ---------------------------------------------------------------------------
# SEC-01: No credentials in the database
# ---------------------------------------------------------------------------

_TOKEN_PATTERNS = (
    re.compile(r"Bearer\s+eyJ"),
    re.compile(r"\bsk-[A-Za-z0-9]{16,}"),
    re.compile(r"\bsk_[A-Za-z0-9_]{16,}"),
    re.compile(r"\bghp_[A-Za-z0-9]{20,}"),
    re.compile(r"\bgho_[A-Za-z0-9]{20,}"),
    re.compile(r"\bxox[bp]-[A-Za-z0-9-]{10,}"),
    re.compile(r"\beyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+"),
)

_PERMITTED_HASH_COLUMNS = {"password_hash", "pat_hash"}


def _contains_token(value: Any) -> bool:
    if not isinstance(value, str):
        return False
    return any(p.search(value) for p in _TOKEN_PATTERNS)


class TestSEC01_NoCredentialsInDatabase:
    async def test_no_token_patterns_in_any_table(self, db: Any) -> None:
        """Scan every row of every whitelisted table for credential patterns."""
        for table in ALLOWED_TABLES:
            if table.startswith("_"):
                continue
            try:
                rows = await db.query(table)
            except Exception:
                continue
            for row in rows:
                for col, value in row.items():
                    if col in _PERMITTED_HASH_COLUMNS:
                        continue
                    assert not _contains_token(value), (
                        f"Credential pattern found in {table}.{col}: {value!r}"
                    )


# ---------------------------------------------------------------------------
# SEC-02: No credentials in logs
# ---------------------------------------------------------------------------


class TestSEC02_NoCredentialsInLogs:
    def test_bearer_redacted(self) -> None:
        """Bearer tokens are redacted by the shared sanitizer."""
        from backend.utils.log_sanitizer import redact

        sanitized = redact(
            "request header Bearer eyJhbGciOiJIUzI1NiJ9.eyJ0.signed"
        )
        assert "[REDACTED]" in sanitized
        assert "eyJhbGciOiJIUzI1NiJ9" not in sanitized

    def test_api_key_redacted(self) -> None:
        """sk- prefixed API keys are redacted."""
        from backend.utils.log_sanitizer import redact

        sanitized = redact("key=sk-ABCDEFGHIJKLMNOPQRSTUVWXYZ012345")
        assert "[REDACTED]" in sanitized
        assert "ABCDEFGHIJKLMNOPQRSTUVWXYZ012345" not in sanitized

    def test_password_redacted(self) -> None:
        """password=… patterns are redacted."""
        from backend.utils.log_sanitizer import redact

        sanitized = redact("password=super-secret-123")
        assert "[REDACTED]" in sanitized
        assert "super-secret-123" not in sanitized


# ---------------------------------------------------------------------------
# SEC-03: No credentials in MCP responses
# ---------------------------------------------------------------------------


class TestSEC03_NoCredentialsInMCPResponses:
    async def test_decision_create_response_has_no_tokens(
        self, db: Any
    ) -> None:
        """decision.create returns only domain fields."""
        handlers = ToolHandlers(db=db)
        response = await handlers.decision_create(
            user_id=uuid.uuid4(), title="Test"
        )
        dumped = json.dumps(response, default=str)
        assert not _contains_token(dumped)

    async def test_session_start_response_has_no_tokens(
        self, db: Any
    ) -> None:
        """session.start returns only session metadata."""
        handlers = ToolHandlers(db=db)
        response = await handlers.session_start(
            user_id=uuid.uuid4(), agent_name="qa"
        )
        dumped = json.dumps(response, default=str)
        assert not _contains_token(dumped)


# ---------------------------------------------------------------------------
# SEC-04: No plaintext credentials on disk
# ---------------------------------------------------------------------------


class TestSEC04_NoPlaintextCredentialsOnDisk:
    def test_vault_file_is_binary(
        self, vault: tuple[Path, str]
    ) -> None:
        """The encrypted vault file is not plain JSON."""
        vault_path, _token = vault
        blob = vault_path.read_bytes()
        # Must not be parseable as JSON.
        with pytest.raises(Exception):
            json.loads(blob)

    def test_config_file_has_no_secret_values(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """codeledger.toml contains only env-var references, never values."""
        monkeypatch.setenv("CODELEDGER_VAULT_PASSPHRASE", "qa")
        from click.testing import CliRunner

        from backend.cli import cli

        monkeypatch.setattr(
            "backend.cli.DEFAULT_VAULT_DIR", tmp_path / ".codeledger"
        )
        monkeypatch.setattr(
            "backend.cli.HOOK_TOKEN_FILE",
            tmp_path / ".codeledger" / "hook_token",
        )
        CliRunner().invoke(
            cli,
            [
                "init",
                "--project-root",
                str(tmp_path),
                "--vault-backend",
                "file",
                "--no-install-hooks",
            ],
        )
        body = (tmp_path / "codeledger.toml").read_text(encoding="utf-8")
        assert not _contains_token(body)


# ---------------------------------------------------------------------------
# SEC-05: Auth on every endpoint
# ---------------------------------------------------------------------------

_PUBLIC_ROUTES = {
    "/health",
    "/api/hooks/post-commit",
    "/api/hooks/file-change",
    "/api/setup/status",
    "/api/setup/complete",
}


class TestSEC05_AuthOnEveryEndpoint:
    def test_every_private_route_returns_401_without_auth(
        self, client: TestClient
    ) -> None:
        """Every API route except the public allowlist returns 401."""
        with client:
            routes = getattr(client.app, "routes", [])
            for route in routes:
                path = getattr(route, "path", None)
                if path is None or "{" in path:
                    continue
                if path in _PUBLIC_ROUTES:
                    continue
                if not path.startswith("/api/"):
                    continue
                resp = client.get(path)
                assert resp.status_code in (
                    401,
                    405,  # method not allowed — still gated before handler
                    422,  # missing required body — still gated
                ), f"{path} returned {resp.status_code} without auth"

    def test_health_is_unauthenticated(self, client: TestClient) -> None:
        """GET /health returns 200 without credentials."""
        with client:
            resp = client.get("/health")
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# SEC-06: OAuth state + PKCE
# ---------------------------------------------------------------------------


class TestSEC06_OAuthStateAndPKCE:
    def test_pkce_helper_produces_unique_challenges(self) -> None:
        """PKCE pairs are cryptographically random and unique per call."""
        from backend.auth.oauth_manager import generate_pkce

        pairs = set()
        for _ in range(50):
            verifier, challenge = generate_pkce()
            assert len(verifier) >= 43
            assert len(challenge) >= 43
            pairs.add(challenge)
        assert len(pairs) == 50

    def test_state_param_is_random(self) -> None:
        """OAuth state parameters are cryptographically unique."""
        from backend.auth.oauth_manager import generate_state

        states = {generate_state() for _ in range(100)}
        assert len(states) == 100
        for s in states:
            assert len(s) >= 32


# ---------------------------------------------------------------------------
# SEC-07: Argon2id password hashing
# ---------------------------------------------------------------------------


class TestSEC07_Argon2idPasswordHashing:
    async def test_stored_password_is_argon2id(
        self, db: Any, tmp_path: Path
    ) -> None:
        """Registered users land in the DB with an Argon2id hash, never bcrypt."""
        from backend.auth.auth_service import AuthService, AuthSettings
        from backend.auth.credential_manager import CredentialManager
        from backend.config import CredentialConfig

        creds = CredentialManager(
            CredentialConfig(
                backend="file", vault_path=str(tmp_path / "qa-sec07.enc")
            ),
            passphrase="qa-sec07",
        )
        auth = AuthService(
            db,
            creds,
            AuthSettings(
                jwt_expiry_hours=1,
                argon2_memory_cost_kb=512,
                argon2_time_cost=1,
                argon2_parallelism=1,
            ),
        )
        user = await auth.register_email_user(
            "sec07@test.com", "S", "pwd"
        )
        row = await db.get_by_id("users", str(user.id))
        assert row["password_hash"].startswith("$argon2id$")
        assert not row["password_hash"].startswith("$2b$")
        assert not row["password_hash"].startswith("$2a$")


# ---------------------------------------------------------------------------
# SEC-08: JWT signing key in vault only
# ---------------------------------------------------------------------------


class TestSEC08_JWTSigningKeyInVaultOnly:
    async def test_jwt_key_not_in_any_db_column(self, db: Any) -> None:
        """The JWT signing key pattern never appears in the database."""
        for table in ALLOWED_TABLES:
            if table.startswith("_"):
                continue
            try:
                rows = await db.query(table)
            except Exception:
                continue
            for row in rows:
                for col, value in row.items():
                    if col in _PERMITTED_HASH_COLUMNS:
                        continue
                    if not isinstance(value, str):
                        continue
                    # The signing key is base64url, 43+ chars, no '-' in
                    # the first position. We forbid any suspicious long
                    # base64 strings outside the permitted columns.
                    if (
                        len(value) >= 43
                        and re.fullmatch(r"[A-Za-z0-9_-]+", value)
                        and "-" not in value[:1]
                    ):
                        # A UUID is ≤ 36 chars with dashes — so this
                        # check won't trip on IDs.
                        assert False, (
                            f"Suspicious long base64 token in "
                            f"{table}.{col}: {value!r}"
                        )


# ---------------------------------------------------------------------------
# SEC-09: File permissions validated
# ---------------------------------------------------------------------------


class TestSEC09_FilePermissionsValidated:
    @pytest.mark.skipif(
        sys.platform == "win32", reason="POSIX permission bits only"
    )
    def test_world_readable_config_rejected(
        self, tmp_path: Path
    ) -> None:
        """A config file with other-readable bits is rejected by load_config."""
        from backend.config import ConfigError, load_config

        cfg = tmp_path / "codeledger.toml"
        cfg.write_text("[server]\nport = 8100\n", encoding="utf-8")
        cfg.chmod(0o644)
        with pytest.raises(ConfigError, match="world-readable"):
            load_config(cfg, project_root=tmp_path)


# ---------------------------------------------------------------------------
# SEC-10: PATs hashed before storage
# ---------------------------------------------------------------------------


class TestSEC10_PATHashedBeforeStorage:
    async def test_pat_hash_never_plaintext(
        self, db: Any, tmp_path: Path
    ) -> None:
        """PAT rows carry a sha256 hash, not plaintext."""
        from backend.auth.auth_service import AuthService, AuthSettings
        from backend.auth.credential_manager import CredentialManager
        from backend.config import CredentialConfig

        creds = CredentialManager(
            CredentialConfig(
                backend="file", vault_path=str(tmp_path / "qa-sec10.enc")
            ),
            passphrase="qa-sec10",
        )
        auth = AuthService(
            db,
            creds,
            AuthSettings(
                jwt_expiry_hours=1,
                argon2_memory_cost_kb=512,
                argon2_time_cost=1,
                argon2_parallelism=1,
            ),
        )
        user = await auth.register_email_user(
            "sec10@test.com", "S", "pw"
        )
        result = await auth.create_pat(user.id, "qa")
        plaintext = result.plaintext
        rows = await db.query(
            "personal_access_tokens", where={"user_id": str(user.id)}
        )
        for row in rows:
            assert row["pat_hash"] != plaintext
            assert len(row["pat_hash"]) == 64  # sha256 hex
            assert re.fullmatch(r"[0-9a-f]{64}", row["pat_hash"])


# ---------------------------------------------------------------------------
# SEC-11: Structural change audit record
# ---------------------------------------------------------------------------


class TestSEC11_StructuralCommitAuditRecord:
    async def test_unlinked_commit_recorded_when_no_session(
        self, tmp_path: Path
    ) -> None:
        """A structural commit outside any session yields an UnlinkedCommit."""
        db = SQLiteBackend(tmp_path / "sec11.db")
        await db.connect()
        try:
            await apply_migrations(db)
            from backend.intelligence.ast_tracker import ASTTracker

            tracker = ASTTracker(db=db)
            await tracker.process_change_event(
                change_event_id="sec11-cmt",
                change_event_type="git_commit",
                diff_text=(
                    "diff --git a/s.py b/s.py\n"
                    "--- a/s.py\n"
                    "+++ b/s.py\n"
                    "@@ -0,0 +1,2 @@\n"
                    "+def added():\n"
                    "+    return 1\n"
                ),
                project_id="sec11",
            )
            rows = await db.query(
                "unlinked_commits", where={"commit_hash": "sec11-cmt"}
            )
            assert rows, "expected at least one UnlinkedCommit row"
        finally:
            await db.close()
