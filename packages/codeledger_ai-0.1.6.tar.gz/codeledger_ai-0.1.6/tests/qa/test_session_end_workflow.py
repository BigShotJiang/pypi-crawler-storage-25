"""Session-end failure points F5.1 — F5.10.

Verifies the enforcement path in ``session.end`` — not-found, already-
completed, inference-crash resilience, and auto-confirm thresholds.
"""

from __future__ import annotations

import uuid
from typing import Any
from unittest.mock import AsyncMock

import pytest

from backend.intelligence.ast_tracker import ASTTracker
from backend.intelligence.decision_inferrer import DecisionInferrer
from backend.mcp.tool_handlers import HandlerError, ToolHandlers
from backend.models import InferredDecision


class TestSessionEndNotFound:
    async def test_missing_session_raises(self, db: Any) -> None:
        """F5.1 — ending a non-existent session raises HandlerError."""
        handlers = ToolHandlers(db=db)
        with pytest.raises(HandlerError, match="Not found"):
            await handlers.session_end(
                user_id=uuid.uuid4(),
                session_id=uuid.uuid4(),
            )


class TestSessionEndIdempotence:
    async def test_second_close_returns_completed(
        self, db: Any
    ) -> None:
        """F5.2 — closing an already-completed session still returns status."""
        handlers = ToolHandlers(db=db)
        started = await handlers.session_start(
            user_id=uuid.uuid4(), agent_name="qa"
        )
        sid = uuid.UUID(started["id"])
        first = await handlers.session_end(
            user_id=uuid.uuid4(), session_id=sid
        )
        second = await handlers.session_end(
            user_id=uuid.uuid4(), session_id=sid
        )
        assert first["status"] == "completed"
        assert second["status"] == "completed"


class TestSessionEndResilience:
    async def test_inference_crash_still_closes(
        self, db: Any
    ) -> None:
        """F5.4 — an inference RuntimeError does not block session closure."""
        tracker = ASTTracker(db=db)
        inferrer = DecisionInferrer(db=db, ast_tracker=tracker)
        inferrer.infer_from_session = AsyncMock(  # type: ignore[method-assign]
            side_effect=RuntimeError("inference crash simulation")
        )
        handlers = ToolHandlers(db=db, decision_inferrer=inferrer)
        started = await handlers.session_start(
            user_id=uuid.uuid4(), agent_name="qa"
        )
        sid = uuid.UUID(started["id"])
        # Seed an unlinked AST change so inference is triggered.
        from backend.models import ASTChange

        ast = ASTChange(
            file_path="x.py",
            language="python",
            change_type="function_added",
            entity_name="foo",
            entity_type="function",
            commit_hash="cmt",
            change_event_id="cmt",
            change_event_type="git_commit",
            project_id="default",
            session_id=sid,
        )
        await db.insert("ast_changes", ast.to_dict())
        # Should not raise even though inference crashed.
        result = await handlers.session_end(
            user_id=uuid.uuid4(), session_id=sid
        )
        assert result["status"] == "completed_with_warnings"


class TestSessionEndAutoConfirmBoundaries:
    async def test_threshold_zero_confirms_all(self, db: Any) -> None:
        """F5.6 — threshold=0 auto-confirms everything."""
        handlers = ToolHandlers(db=db)
        started = await handlers.session_start(
            user_id=uuid.uuid4(), agent_name="qa"
        )
        sid = uuid.UUID(started["id"])
        # Seed inferred decisions at various confidences.
        import uuid as _uuid

        for i, conf in enumerate((0.1, 0.4, 0.8)):
            inf = InferredDecision(
                session_id=sid,
                project_id="default",
                candidate_title=f"c{i}",
                confidence=conf,
                status="pending",
                id=_uuid.uuid4(),
            )
            await db.insert("inferred_decisions", inf.to_dict())

        tracker = ASTTracker(db=db)
        inferrer = DecisionInferrer(db=db, ast_tracker=tracker)
        promoted = await inferrer.auto_confirm_high_confidence(
            session_id=str(sid), project_id="default", threshold=0.0
        )
        assert len(promoted) == 3

    async def test_threshold_one_confirms_none(self, db: Any) -> None:
        """F5.7 — threshold=1.0 leaves every <1.0 candidate pending."""
        handlers = ToolHandlers(db=db)
        started = await handlers.session_start(
            user_id=uuid.uuid4(), agent_name="qa"
        )
        sid = uuid.UUID(started["id"])
        inf = InferredDecision(
            session_id=sid,
            project_id="default",
            candidate_title="c",
            confidence=0.99,
            status="pending",
        )
        await db.insert("inferred_decisions", inf.to_dict())
        tracker = ASTTracker(db=db)
        inferrer = DecisionInferrer(db=db, ast_tracker=tracker)
        promoted = await inferrer.auto_confirm_high_confidence(
            session_id=str(sid), project_id="default", threshold=1.0
        )
        assert promoted == []


class TestSessionEndEmpty:
    async def test_zero_activity_closes_cleanly(self, db: Any) -> None:
        """F5.9 — a session with no activity still closes without warnings."""
        handlers = ToolHandlers(db=db)
        started = await handlers.session_start(
            user_id=uuid.uuid4(), agent_name="empty-agent"
        )
        sid = uuid.UUID(started["id"])
        result = await handlers.session_end(
            user_id=uuid.uuid4(), session_id=sid
        )
        assert result["status"] == "completed"
        row = await db.get_by_id("sessions", str(sid))
        assert row["status"] == "completed"


class TestSessionEndForce:
    async def test_force_without_reason_accepted(self, db: Any) -> None:
        """F5.8 — force=True without override_reason closes as forced."""
        handlers = ToolHandlers(db=db)
        started = await handlers.session_start(
            user_id=uuid.uuid4(), agent_name="forced"
        )
        sid = uuid.UUID(started["id"])
        # Seed an unlinked AST change to trigger the warning path.
        from backend.models import ASTChange

        ast = ASTChange(
            file_path="forced.py",
            language="python",
            change_type="function_added",
            entity_name="foo",
            entity_type="function",
            commit_hash="cmt",
            change_event_id="cmt",
            change_event_type="git_commit",
            project_id="default",
            session_id=sid,
        )
        await db.insert("ast_changes", ast.to_dict())
        result = await handlers.session_end(
            user_id=uuid.uuid4(),
            session_id=sid,
            force=True,
            override_reason=None,
        )
        assert result["status"] == "completed_forced"
