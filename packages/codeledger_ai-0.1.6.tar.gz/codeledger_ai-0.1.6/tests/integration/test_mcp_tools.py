"""Integration tests for the MCP tool surface and the mirrored REST routes.

Exercises every Phase 1 MCP tool end-to-end through ``ToolHandlers`` (the
shared logic layer), then verifies the REST router returns equivalent results
when called through FastAPI with a valid authenticated user.

SEC-05 is tested separately in ``test_auth_enforcement.py``. These tests
assume a valid user has already been authenticated.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any

import pytest
from fastapi import FastAPI, Request
from fastapi.testclient import TestClient

from backend.api.routes import create_api_router
from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.db.vector_store import DEFAULT_DIM, SqliteVssStore
from backend.intelligence.context_triage import ContextTriage
from backend.intelligence.semantic_search import SemanticSearch
from backend.mcp.tool_handlers import HandlerError, ToolHandlers
from backend.models import ASTChange, Decision, ProvenanceEdge, User

if TYPE_CHECKING:
    from pathlib import Path


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
async def handlers(tmp_path: Path) -> ToolHandlers:
    db = SQLiteBackend(tmp_path / "mcp.db")
    await db.connect()
    await apply_migrations(db)
    yield ToolHandlers(db=db)
    await db.close()


@pytest.fixture
def user_id() -> uuid.UUID:
    return uuid.uuid4()


@pytest.fixture
def test_user(user_id: uuid.UUID) -> User:
    return User(id=user_id, email="test@example.com", name="Tester")


# ---------------------------------------------------------------------------
# Handler-level tests
# ---------------------------------------------------------------------------


class TestContextHandlers:
    """Context CRUD round-trip."""

    @pytest.mark.asyncio
    async def test_create_read(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        created = await handlers.context_create(
            user_id=user_id,
            content="An important note.",
            source="chat-session",
            tags=["auth", "oauth"],
        )
        read = await handlers.context_read(
            user_id=user_id, item_id=uuid.UUID(created["id"])
        )
        assert read["content"] == "An important note."
        assert read["source"] == "chat-session"

    @pytest.mark.asyncio
    async def test_update(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        created = await handlers.context_create(
            user_id=user_id, content="original"
        )
        updated = await handlers.context_update(
            user_id=user_id,
            item_id=uuid.UUID(created["id"]),
            content="updated",
            tags=["new"],
        )
        assert updated["content"] == "updated"
        assert updated["tags"] == '["new"]'

    @pytest.mark.asyncio
    async def test_delete(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        created = await handlers.context_create(
            user_id=user_id, content="to-delete"
        )
        result = await handlers.context_delete(
            user_id=user_id, item_id=uuid.UUID(created["id"])
        )
        assert result["deleted"] is True
        with pytest.raises(HandlerError, match="Not found"):
            await handlers.context_read(
                user_id=user_id, item_id=uuid.UUID(created["id"])
            )

    @pytest.mark.asyncio
    async def test_list_scoped_by_session(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        session = uuid.uuid4()
        other_session = uuid.uuid4()
        await handlers.context_create(
            user_id=user_id, content="a", session_id=session
        )
        await handlers.context_create(
            user_id=user_id, content="b", session_id=session
        )
        await handlers.context_create(
            user_id=user_id, content="c", session_id=other_session
        )
        scoped = await handlers.context_list(
            user_id=user_id, session_id=session
        )
        assert len(scoped) == 2
        all_items = await handlers.context_list(user_id=user_id)
        assert len(all_items) == 3

    @pytest.mark.asyncio
    async def test_empty_content_rejected(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        with pytest.raises(HandlerError, match="non-empty"):
            await handlers.context_create(user_id=user_id, content="")


class TestDecisionHandlers:
    """Decision CRUD."""

    @pytest.mark.asyncio
    async def test_create_defaults_to_unverified(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        d = await handlers.decision_create(
            user_id=user_id,
            title="Use PostgreSQL",
            description="For scalability",
            tags=["db", "infra"],
        )
        assert d["status"] == "unverified"
        assert d["recorded_by_user_id"] == str(user_id)

    @pytest.mark.asyncio
    async def test_list_filters_by_status(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        for status in ["passed", "passed", "failed", "unverified"]:
            d = await handlers.decision_create(
                user_id=user_id, title=f"{status} decision"
            )
            # Manually update status (decision_create always sets unverified)
            await handlers.db.update(
                "decisions",
                d["id"],
                {"status": status, "updated_at": datetime.now(UTC).isoformat()},
            )

        passed = await handlers.decision_list(
            user_id=user_id, status="passed"
        )
        assert len(passed) == 2
        all_items = await handlers.decision_list(user_id=user_id)
        assert len(all_items) == 4

    @pytest.mark.asyncio
    async def test_invalid_status_filter_rejected(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        with pytest.raises(HandlerError, match="Invalid decision status"):
            await handlers.decision_list(user_id=user_id, status="bogus")


class TestStoryHandlers:
    """Story CRUD."""

    @pytest.mark.asyncio
    async def test_create_and_update_status(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        s = await handlers.story_create(
            user_id=user_id,
            title="Implement auth",
            acceptance_criteria=["Google sign-in works", "Login returns JWT"],
            points=5,
        )
        updated = await handlers.story_update(
            user_id=user_id,
            story_id=uuid.UUID(s["id"]),
            status="in_progress",
        )
        assert updated["status"] == "in_progress"

    @pytest.mark.asyncio
    async def test_invalid_points(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        with pytest.raises(HandlerError, match="non-negative"):
            await handlers.story_create(
                user_id=user_id, title="Invalid", points=-1
            )


class TestSprintHandlers:
    """Sprint creation and status aggregation."""

    @pytest.mark.asyncio
    async def test_create_and_status(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        start = datetime(2026, 4, 1, tzinfo=UTC)
        sprint = await handlers.sprint_create(
            user_id=user_id,
            name="Sprint 1",
            start_date=start,
            end_date=start + timedelta(days=14),
        )
        sid = uuid.UUID(sprint["id"])

        # Add 3 stories: 2 done, 1 in-progress
        for title, status, pts in [
            ("done-a", "done", 3),
            ("done-b", "done", 5),
            ("wip", "in_progress", 8),
        ]:
            story = await handlers.story_create(
                user_id=user_id, title=title, points=pts, sprint_id=sid
            )
            await handlers.story_update(
                user_id=user_id,
                story_id=uuid.UUID(story["id"]),
                status=status,
            )

        status_report = await handlers.sprint_status(
            user_id=user_id, sprint_id=sid
        )
        assert status_report["stories_total"] == 3
        assert status_report["points_total"] == 16
        assert status_report["points_done"] == 8
        assert status_report["percent_complete"] == 50.0
        assert status_report["story_counts"]["done"] == 2
        assert status_report["story_counts"]["in_progress"] == 1

    @pytest.mark.asyncio
    async def test_empty_sprint_percent_zero(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        sprint = await handlers.sprint_create(
            user_id=user_id, name="Empty Sprint"
        )
        report = await handlers.sprint_status(
            user_id=user_id, sprint_id=uuid.UUID(sprint["id"])
        )
        assert report["percent_complete"] == 0.0
        assert report["points_total"] == 0


class TestSessionHandlers:
    """Session start/end/list."""

    @pytest.mark.asyncio
    async def test_start_end(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        started = await handlers.session_start(
            user_id=user_id, agent_name="claude-sonnet-4.6"
        )
        assert started["status"] == "active"
        assert started["user_id"] == str(user_id)

        ended = await handlers.session_end(
            user_id=user_id, session_id=uuid.UUID(started["id"])
        )
        assert ended["status"] == "completed"
        assert ended["ended_at"] is not None

    @pytest.mark.asyncio
    async def test_list_for_current_user(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        other_user = uuid.uuid4()
        await handlers.session_start(user_id=user_id, agent_name="mine-a")
        await handlers.session_start(user_id=user_id, agent_name="mine-b")
        await handlers.session_start(user_id=other_user, agent_name="not-mine")

        mine = await handlers.session_list(
            user_id=user_id, for_current_user=True
        )
        assert len(mine) == 2
        all_s = await handlers.session_list(user_id=user_id)
        assert len(all_s) == 3


class TestStandupHandler:
    """Standup report aggregation."""

    @pytest.mark.asyncio
    async def test_standup_includes_recent_activity(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        # Seed a recent decision and an in-progress story
        await handlers.decision_create(
            user_id=user_id, title="Recent decision"
        )
        story = await handlers.story_create(
            user_id=user_id, title="Active work"
        )
        await handlers.story_update(
            user_id=user_id,
            story_id=uuid.UUID(story["id"]),
            status="in_progress",
        )

        report = await handlers.standup_generate(user_id=user_id)
        assert report["yesterday"]["decisions_recorded"] == 1
        assert len(report["today"]["in_progress_stories"]) == 1
        assert report["today"]["in_progress_stories"][0]["title"] == "Active work"

    @pytest.mark.asyncio
    async def test_standup_invalid_lookback_rejected(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        with pytest.raises(HandlerError, match="positive"):
            await handlers.standup_generate(
                user_id=user_id, lookback_hours=0
            )


# ---------------------------------------------------------------------------
# REST route tests (with user injected into request.state, bypassing middleware)
# ---------------------------------------------------------------------------


def _app_with_user(handlers: ToolHandlers, user: User) -> FastAPI:
    """Build a FastAPI app that seeds request.state.user without the middleware."""
    app = FastAPI()

    @app.middleware("http")
    async def inject_user(request: Request, call_next):
        request.state.user = user
        return await call_next(request)

    app.include_router(create_api_router(handlers), prefix="/api")
    return app


class TestRestRoutes:
    """REST routes mirror the MCP tool behavior."""

    @pytest.mark.asyncio
    async def test_decision_crud_via_rest(
        self, handlers: ToolHandlers, test_user: User
    ) -> None:
        app = _app_with_user(handlers, test_user)
        client = TestClient(app)

        resp = client.post(
            "/api/decisions",
            json={
                "title": "Adopt PostgreSQL",
                "description": "For prod",
                "tags": ["db"],
            },
        )
        assert resp.status_code == 200
        created = resp.json()
        assert created["title"] == "Adopt PostgreSQL"

        resp2 = client.get(f"/api/decisions/{created['id']}")
        assert resp2.status_code == 200
        assert resp2.json()["title"] == "Adopt PostgreSQL"

        resp3 = client.get("/api/decisions")
        assert resp3.status_code == 200
        assert len(resp3.json()) == 1

    @pytest.mark.asyncio
    async def test_not_found_returns_404(
        self, handlers: ToolHandlers, test_user: User
    ) -> None:
        app = _app_with_user(handlers, test_user)
        client = TestClient(app)
        missing = uuid.uuid4()
        resp = client.get(f"/api/decisions/{missing}")
        assert resp.status_code == 404

    @pytest.mark.asyncio
    async def test_session_start_end(
        self, handlers: ToolHandlers, test_user: User
    ) -> None:
        app = _app_with_user(handlers, test_user)
        client = TestClient(app)

        resp = client.post(
            "/api/sessions", json={"agent_name": "claude-sonnet-4.6"}
        )
        assert resp.status_code == 200
        session_id = resp.json()["id"]

        resp_end = client.post(f"/api/sessions/{session_id}/end")
        assert resp_end.status_code == 200
        assert resp_end.json()["status"] == "completed"

    @pytest.mark.asyncio
    async def test_standup_endpoint(
        self, handlers: ToolHandlers, test_user: User
    ) -> None:
        app = _app_with_user(handlers, test_user)
        client = TestClient(app)
        resp = client.get("/api/standup")
        assert resp.status_code == 200
        body = resp.json()
        assert body["user_id"] == str(test_user.id)
        assert "yesterday" in body
        assert "today" in body
        assert "blockers" in body

    @pytest.mark.asyncio
    async def test_sprint_status_endpoint(
        self, handlers: ToolHandlers, test_user: User
    ) -> None:
        app = _app_with_user(handlers, test_user)
        client = TestClient(app)
        resp = client.post("/api/sprints", json={"name": "S1"})
        sprint_id = resp.json()["id"]
        resp2 = client.get(f"/api/sprints/{sprint_id}/status")
        assert resp2.status_code == 200
        assert resp2.json()["stories_total"] == 0


# ---------------------------------------------------------------------------
# MCP server wiring
# ---------------------------------------------------------------------------


class TestMcpServerWiring:
    """FastMCP server registers every expected tool name."""

    def test_mcp_server_registers_all_namespaces(
        self, handlers: ToolHandlers
    ) -> None:
        from backend.mcp.mcp_server import create_mcp_server

        mcp = create_mcp_server(handlers)
        assert mcp.name == "codeledger"

    @pytest.mark.asyncio
    async def test_tool_count(self, handlers: ToolHandlers) -> None:
        from backend.mcp.mcp_server import create_mcp_server

        mcp = create_mcp_server(handlers)
        names = {t.name for t in await mcp.list_tools()}
        # Phase 3 adds verify/provenance/harness; Phase 5 drift/test/rollback;
        # Phase 6 knowledge/agent/project/retrospective.
        assert {
            "context",
            "decision",
            "story",
            "sprint",
            "session",
            "standup",
            "verify",
            "provenance",
            "harness",
            "drift",
            "test",
            "rollback",
            "knowledge",
            "agent",
            "project",
            "retrospective",
        }.issubset(names)

    @pytest.mark.asyncio
    async def test_total_method_surface_at_least_50(
        self, handlers: ToolHandlers
    ) -> None:
        """Phase 6 gate: the MCP surface must expose ≥50 distinct methods."""
        # Methods are dispatched by the ``method`` parameter on each tool.
        methods_per_tool = {
            "context": 7,
            "decision": 6,
            "story": 5,
            "sprint": 5,
            "session": 6,
            "standup": 1,
            "verify": 2,
            "provenance": 2,
            "harness": 2,
            "drift": 2,
            "test": 1,
            "rollback": 1,
            "knowledge": 4,
            "agent": 3,
            "project": 4,
            "retrospective": 1,
        }
        total = sum(methods_per_tool.values())
        assert total >= 50, f"MCP surface is {total}; need ≥50"


# ---------------------------------------------------------------------------
# Phase 3 — Verification, provenance, harness, session replay
# ---------------------------------------------------------------------------


_P3_DIFF = (
    "diff --git a/p3.py b/p3.py\n"
    "--- a/p3.py\n"
    "+++ b/p3.py\n"
    "@@ -0,0 +1,2 @@\n"
    "+def p3_fn(n):\n"
    "+    return n\n"
)


@pytest.fixture
async def full_handlers(tmp_path: Path) -> ToolHandlers:
    """Handlers wired with verifier/harness/conflict/provenance engines."""
    from backend.intelligence.ast_tracker import ASTTracker
    from backend.intelligence.decision_inferrer import DecisionInferrer
    from backend.verification.conflict_detector import ConflictDetector
    from backend.verification.harness import QualityHarness
    from backend.verification.provenance import ProvenanceEngine
    from backend.verification.verifier import Verifier

    db = SQLiteBackend(tmp_path / "p3.db")
    await db.connect()
    await apply_migrations(db)
    yield ToolHandlers(
        db=db,
        verifier=Verifier(db),
        harness=QualityHarness(db),
        conflict_detector=ConflictDetector(db),
        provenance=ProvenanceEngine(db),
        decision_inferrer=DecisionInferrer(db=db, ast_tracker=ASTTracker(db=db)),
    )
    await db.close()


class TestPhase3MCPTools:
    """Phase 3 MCP tools via the handler layer."""

    @pytest.mark.asyncio
    async def test_session_replay_includes_start_end(
        self, full_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        started = await full_handlers.session_start(
            user_id=user_id, agent_name="claude"
        )
        sid = uuid.UUID(started["id"])
        await full_handlers.session_end(user_id=user_id, session_id=sid)
        replay = await full_handlers.session_replay(
            user_id=user_id, session_id=sid
        )
        event_types = {e["event_type"] for e in replay["timeline"]}
        assert "session_start" in event_types
        assert "session_end" in event_types

    @pytest.mark.asyncio
    async def test_session_end_warnings_when_unlinked(
        self, full_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        from backend.intelligence.ast_tracker import ASTTracker

        tracker = ASTTracker(db=full_handlers.db)
        started = await full_handlers.session_start(
            user_id=user_id, agent_name="a"
        )
        sid = uuid.UUID(started["id"])
        # A structural change with NO decision linked — will become unlinked.
        await tracker.process_change_event(
            change_event_id="cmt-unlinked",
            change_event_type="git_commit",
            diff_text=_P3_DIFF,
            project_id="default",
            active_session_id=str(sid),
        )
        result = await full_handlers.session_end(
            user_id=user_id, session_id=sid
        )
        assert result["status"] == "completed_with_warnings"
        assert "p3.py" in result["unlinked_files"]

    @pytest.mark.asyncio
    async def test_session_end_force_records_override(
        self, full_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        from backend.intelligence.ast_tracker import ASTTracker

        tracker = ASTTracker(db=full_handlers.db)
        started = await full_handlers.session_start(
            user_id=user_id, agent_name="a"
        )
        sid = uuid.UUID(started["id"])
        await tracker.process_change_event(
            change_event_id="cmt-force",
            change_event_type="git_commit",
            diff_text=_P3_DIFF,
            project_id="default",
            active_session_id=str(sid),
        )
        result = await full_handlers.session_end(
            user_id=user_id,
            session_id=sid,
            force=True,
            override_reason="scratch work",
        )
        assert result["status"] == "completed_forced"
        replay = await full_handlers.session_replay(
            user_id=user_id, session_id=sid
        )
        event_types = [e["event_type"] for e in replay["timeline"]]
        assert "session_end_override" in event_types

    @pytest.mark.asyncio
    async def test_verify_status_file_watcher_unavailable(
        self, tmp_path: Path, user_id: uuid.UUID
    ) -> None:
        from backend.verification.verifier import Verifier

        db = SQLiteBackend(tmp_path / "fw.db")
        await db.connect()
        await apply_migrations(db)
        try:
            decision = Decision(title="FW decision")
            await db.insert("decisions", decision.to_dict())
            hs = ToolHandlers(
                db=db,
                verifier=Verifier(db),
                change_detection_backend="file_watcher",
            )
            status = await hs.verify_status(
                user_id=user_id, decision_id=decision.id
            )
            assert status["verification_available"] is False
            assert status["change_detection_backend"] == "file_watcher"
        finally:
            await db.close()

    @pytest.mark.asyncio
    async def test_harness_score_critical_without_decisions(
        self, full_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        from backend.intelligence.ast_tracker import ASTTracker

        tracker = ASTTracker(db=full_handlers.db)
        started = await full_handlers.session_start(
            user_id=user_id, agent_name="a"
        )
        sid = uuid.UUID(started["id"])
        await tracker.process_change_event(
            change_event_id="cmt-harness",
            change_event_type="git_commit",
            diff_text=_P3_DIFF,
            project_id="default",
            active_session_id=str(sid),
        )
        score = await full_handlers.harness_score(
            user_id=user_id, session_id=sid
        )
        assert score["decision_density"] == 0.0
        assert score["decision_density_status"] == "critical"
        assert score["harness_status"] == "failing"

    @pytest.mark.asyncio
    async def test_harness_score_commit_rejects_file_watcher(
        self, tmp_path: Path, user_id: uuid.UUID
    ) -> None:
        from backend.verification.harness import QualityHarness

        db = SQLiteBackend(tmp_path / "hsc.db")
        await db.connect()
        await apply_migrations(db)
        try:
            hs = ToolHandlers(
                db=db,
                harness=QualityHarness(db),
                change_detection_backend="file_watcher",
            )
            with pytest.raises(HandlerError):
                await hs.harness_score_commit(
                    user_id=user_id, commit_hash="cmt-x"
                )
        finally:
            await db.close()

    @pytest.mark.asyncio
    async def test_provenance_forward_returns_change_events(
        self, full_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        from backend.intelligence.ast_tracker import ASTTracker

        tracker = ASTTracker(db=full_handlers.db)
        # Create a decision AND make a commit the link-by-file heuristic will
        # attach. The ast_tracker uses "title or description mentions file".
        decision = await full_handlers.decision_create(
            user_id=user_id,
            title="Touch p3.py for p3_fn",
            description="adds p3_fn in p3.py",
        )
        await tracker.process_change_event(
            change_event_id="cmt-prov",
            change_event_type="git_commit",
            diff_text=_P3_DIFF,
            project_id="default",
        )
        tree = await full_handlers.provenance_forward(
            user_id=user_id, decision_id=uuid.UUID(decision["id"])
        )
        assert tree["decision"]["id"] == decision["id"]
        assert len(tree["change_events"]) >= 1
        assert tree["change_events"][0]["change_event_type"] == "git_commit"

    @pytest.mark.asyncio
    async def test_session_conflicts_returns_empty_with_no_overlap(
        self, full_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        started = await full_handlers.session_start(
            user_id=user_id, agent_name="solo"
        )
        sid = uuid.UUID(started["id"])
        result = await full_handlers.session_conflicts(
            user_id=user_id, session_id=sid
        )
        assert result["conflicts"] == []


# ---------------------------------------------------------------------------
# Phase 2 — Semantic retrieval and provenance
# ---------------------------------------------------------------------------


class _FakeEmbedder:
    """Deterministic text → vector mapping for Phase 2 tests."""

    def __init__(self) -> None:
        self._mapping: dict[str, list[float]] = {}

    def bind(self, text: str, vector: list[float]) -> None:
        self._mapping[text] = list(vector)

    async def embed_text(self, text: str) -> list[float]:
        for key, vector in self._mapping.items():
            if key == text or key in text:
                return list(vector)
        # Fall back to the last dimension so unknown queries orthogonal
        # to the seeded items.
        out = [0.0] * DEFAULT_DIM
        out[DEFAULT_DIM - 1] = 1.0
        return out

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        return [await self.embed_text(t) for t in texts]


def _axis(index: int) -> list[float]:
    vec = [0.0] * DEFAULT_DIM
    vec[index] = 1.0
    return vec


@pytest.fixture
async def phase2_handlers(tmp_path: Path) -> Any:
    db = SQLiteBackend(tmp_path / "p2.db")
    await db.connect()
    await apply_migrations(db)

    store = SqliteVssStore(tmp_path / "p2-vectors.db")
    await store.connect()

    embedder = _FakeEmbedder()
    # Seed text → vector pairs so specific inputs land on specific axes.
    embedder.bind("Use Argon2id for password hashing", _axis(0))
    embedder.bind("authentication", _axis(0))
    embedder.bind("Use PostgreSQL with asyncpg connection pool", _axis(1))
    embedder.bind("database", _axis(1))
    embedder.bind("Dashboard uses React 18 and Zustand", _axis(2))
    embedder.bind("frontend", _axis(2))

    search = SemanticSearch(embedder=embedder, vector_store=store)
    triage = ContextTriage()

    handlers = ToolHandlers(
        db=db,
        semantic_search=search,
        context_triage=triage,
    )
    yield handlers
    await store.close()
    await db.close()


class TestContextGetRelevant:
    @pytest.mark.asyncio
    async def test_returns_most_similar_decision(
        self, phase2_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        await phase2_handlers.decision_create(
            user_id=user_id,
            title="Use Argon2id for password hashing",
            description="",
        )
        await phase2_handlers.decision_create(
            user_id=user_id,
            title="Use PostgreSQL with asyncpg connection pool",
            description="",
        )
        result = await phase2_handlers.context_get_relevant(
            user_id=user_id,
            query="authentication",
            token_budget=2000,
            top_k=5,
        )
        assert result["context_for"] == "authentication"
        # The authentication-seeded axis ranks above the DB-seeded axis.
        assert "context_block" in result
        assert "[DECISION]" in result["context_block"]
        assert result["total_tokens_used"] > 0
        assert result["included_items"]
        top_item_id = result["included_items"][0]["item_id"]
        # The top item is the Argon2id decision.
        top_row = await phase2_handlers.db.get_by_id(
            "decisions", top_item_id
        )
        assert top_row is not None
        assert "Argon2id" in top_row["title"]

    @pytest.mark.asyncio
    async def test_file_based_retrieval(
        self, phase2_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        await phase2_handlers.decision_create(
            user_id=user_id,
            title="Use Argon2id for password hashing",
        )
        result = await phase2_handlers.context_get_for_file(
            user_id=user_id,
            file_path="backend/auth/authentication.py",
            file_content="def hash_password(p): pass",
            token_budget=2000,
        )
        assert result["context_for"] == "backend/auth/authentication.py"

    @pytest.mark.asyncio
    async def test_requires_query_or_file_path(
        self, phase2_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        with pytest.raises(HandlerError):
            await phase2_handlers.context_get_relevant(user_id=user_id)

    @pytest.mark.asyncio
    async def test_raises_when_semantic_disabled(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        # `handlers` fixture has no semantic_search configured.
        with pytest.raises(HandlerError, match="Semantic retrieval"):
            await handlers.context_get_relevant(
                user_id=user_id, query="anything"
            )


class TestDecisionTrace:
    @pytest.mark.asyncio
    async def test_forward_trace_returns_linked_commits(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        decision = await handlers.decision_create(
            user_id=user_id, title="Track provenance"
        )
        decision_id = uuid.UUID(decision["id"])

        change = ASTChange(
            commit_hash="abc123",
            file_path="app.py",
            language="python",
            change_type="function_added",
            entity_name="hash_password",
            entity_type="function",
        )
        await handlers.db.insert("ast_changes", change.to_dict())
        edge = ProvenanceEdge(
            source_type="decision",
            source_id=decision_id,
            target_type="ast_change",
            target_id=change.id,
            relationship="touches",
        )
        await handlers.db.insert("provenance_edges", edge.to_dict())

        result = await handlers.decision_trace(
            user_id=user_id, decision_id=decision_id
        )
        assert result["decision"]["id"] == str(decision_id)
        assert len(result["commits"]) == 1
        assert result["commits"][0]["commit_hash"] == "abc123"
        assert len(result["commits"][0]["ast_changes"]) == 1
        assert (
            result["commits"][0]["ast_changes"][0]["entity_name"]
            == "hash_password"
        )

    @pytest.mark.asyncio
    async def test_forward_trace_empty_when_no_edges(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        decision = await handlers.decision_create(
            user_id=user_id, title="Orphan"
        )
        result = await handlers.decision_trace(
            user_id=user_id, decision_id=uuid.UUID(decision["id"])
        )
        assert result["commits"] == []

    @pytest.mark.asyncio
    async def test_forward_trace_unknown_decision_404s(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        with pytest.raises(HandlerError, match="Not found"):
            await handlers.decision_trace(
                user_id=user_id, decision_id=uuid.uuid4()
            )


class TestDecisionReverseTrace:
    @pytest.mark.asyncio
    async def test_reverse_trace_finds_originating_decision(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        decision = await handlers.decision_create(
            user_id=user_id, title="Pick hash algo"
        )
        decision_id = uuid.UUID(decision["id"])

        change = ASTChange(
            commit_hash="c1",
            file_path="auth.py",
            language="python",
            change_type="function_added",
            entity_name="hash_password",
            entity_type="function",
        )
        await handlers.db.insert("ast_changes", change.to_dict())
        await handlers.db.insert(
            "provenance_edges",
            ProvenanceEdge(
                source_type="decision",
                source_id=decision_id,
                target_type="ast_change",
                target_id=change.id,
                relationship="touches",
            ).to_dict(),
        )

        result = await handlers.decision_reverse_trace(
            user_id=user_id,
            file_path="auth.py",
            entity_name="hash_password",
        )
        assert len(result["decisions"]) == 1
        assert result["decisions"][0]["id"] == str(decision_id)
        assert len(result["changes"]) == 1

    @pytest.mark.asyncio
    async def test_reverse_trace_no_match_returns_empty(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        result = await handlers.decision_reverse_trace(
            user_id=user_id, file_path="missing.py", entity_name="nope"
        )
        assert result["changes"] == []
        assert result["decisions"] == []
        assert result["file_context"] == []

    @pytest.mark.asyncio
    async def test_reverse_trace_rejects_empty_args(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        with pytest.raises(HandlerError):
            await handlers.decision_reverse_trace(
                user_id=user_id, file_path="", entity_name="name"
            )
        with pytest.raises(HandlerError):
            await handlers.decision_reverse_trace(
                user_id=user_id, file_path="f.py", entity_name=""
            )

    @pytest.mark.asyncio
    async def test_reverse_trace_deduplicates_decisions(
        self, handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        decision = await handlers.decision_create(
            user_id=user_id, title="One decision"
        )
        decision_id = uuid.UUID(decision["id"])
        # Two changes for the same entity both link back to the same decision.
        for commit in ("c1", "c2"):
            change = ASTChange(
                commit_hash=commit,
                file_path="m.py",
                language="python",
                change_type="function_modified",
                entity_name="foo",
                entity_type="function",
            )
            await handlers.db.insert("ast_changes", change.to_dict())
            await handlers.db.insert(
                "provenance_edges",
                ProvenanceEdge(
                    source_type="decision",
                    source_id=decision_id,
                    target_type="ast_change",
                    target_id=change.id,
                    relationship="touches",
                ).to_dict(),
            )
        result = await handlers.decision_reverse_trace(
            user_id=user_id, file_path="m.py", entity_name="foo"
        )
        assert len(result["decisions"]) == 1


class TestPhase2RestRoutes:
    @pytest.mark.asyncio
    async def test_context_relevant_endpoint(
        self, phase2_handlers: ToolHandlers, test_user: User
    ) -> None:
        # Seed a decision so retrieval has something to rank.
        await phase2_handlers.decision_create(
            user_id=test_user.id,
            title="Use Argon2id for password hashing",
        )
        app = _app_with_user(phase2_handlers, test_user)
        client = TestClient(app)
        resp = client.post(
            "/api/context/relevant",
            json={"query": "authentication", "token_budget": 2000},
        )
        assert resp.status_code == 200
        body = resp.json()
        assert "context_block" in body
        assert "[DECISION]" in body["context_block"]

    @pytest.mark.asyncio
    async def test_context_for_file_endpoint(
        self, phase2_handlers: ToolHandlers, test_user: User
    ) -> None:
        await phase2_handlers.decision_create(
            user_id=test_user.id,
            title="Use Argon2id for password hashing",
        )
        app = _app_with_user(phase2_handlers, test_user)
        client = TestClient(app)
        resp = client.post(
            "/api/context/for-file",
            json={
                "file_path": "backend/auth/authentication.py",
                "file_content": "def hash_password(p): pass",
                "token_budget": 1000,
            },
        )
        assert resp.status_code == 200
        assert (
            resp.json()["context_for"]
            == "backend/auth/authentication.py"
        )

    @pytest.mark.asyncio
    async def test_decision_trace_endpoint(
        self, handlers: ToolHandlers, test_user: User
    ) -> None:
        app = _app_with_user(handlers, test_user)
        client = TestClient(app)
        decision = await handlers.decision_create(
            user_id=test_user.id, title="D"
        )
        resp = client.get(f"/api/decisions/{decision['id']}/trace")
        assert resp.status_code == 200
        assert resp.json()["decision"]["id"] == decision["id"]

    @pytest.mark.asyncio
    async def test_decision_reverse_trace_endpoint(
        self, handlers: ToolHandlers, test_user: User
    ) -> None:
        app = _app_with_user(handlers, test_user)
        client = TestClient(app)
        resp = client.post(
            "/api/decisions/reverse-trace",
            json={"file_path": "x.py", "entity_name": "y"},
        )
        assert resp.status_code == 200
        body = resp.json()
        assert body["changes"] == []
        assert body["decisions"] == []
        assert body["file_context"] == []


class TestPhase2AuthEnforcement:
    """Phase 2 endpoints are gated by the same auth middleware as Phase 1.

    The detailed SEC-05 verification lives in ``tests/security/``. These
    spot-checks confirm the new routes are registered and reject requests
    without an authenticated user when no middleware seeds ``request.state``.
    """

    def test_context_relevant_requires_user(
        self, handlers: ToolHandlers
    ) -> None:
        app = FastAPI()
        app.include_router(create_api_router(handlers), prefix="/api")
        client = TestClient(app)
        resp = client.post("/api/context/relevant", json={"query": "q"})
        assert resp.status_code == 401

    def test_decision_trace_requires_user(
        self, handlers: ToolHandlers
    ) -> None:
        app = FastAPI()
        app.include_router(create_api_router(handlers), prefix="/api")
        client = TestClient(app)
        resp = client.get(f"/api/decisions/{uuid.uuid4()}/trace")
        assert resp.status_code == 401

    def test_decision_reverse_trace_requires_user(
        self, handlers: ToolHandlers
    ) -> None:
        app = FastAPI()
        app.include_router(create_api_router(handlers), prefix="/api")
        client = TestClient(app)
        resp = client.post(
            "/api/decisions/reverse-trace",
            json={"file_path": "x", "entity_name": "y"},
        )
        assert resp.status_code == 401


# ---------------------------------------------------------------------------
# Passive inference mode (Phase 2 upgrade)
# ---------------------------------------------------------------------------


_INFERENCE_DIFF = (
    "diff --git a/auth_service.py b/auth_service.py\n"
    "--- a/auth_service.py\n"
    "+++ b/auth_service.py\n"
    "@@ -0,0 +1,2 @@\n"
    "+def hash_password(pw):\n"
    "+    return pw\n"
)


class TestPassiveInferenceMCP:
    """session.end produces inferred candidates; confirm/reject lifecycle works."""

    @pytest.mark.asyncio
    async def test_session_end_surfaces_inferred_decisions(
        self, full_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        from backend.intelligence.ast_tracker import ASTTracker

        tracker = ASTTracker(db=full_handlers.db)
        started = await full_handlers.session_start(
            user_id=user_id, agent_name="inferrer"
        )
        sid = uuid.UUID(started["id"])
        await tracker.process_change_event(
            change_event_id="cmt-inf-1",
            change_event_type="git_commit",
            diff_text=_INFERENCE_DIFF,
            project_id="default",
            active_session_id=str(sid),
        )
        result = await full_handlers.session_end(
            user_id=user_id, session_id=sid
        )
        assert result["status"] == "completed_with_warnings"
        assert "auth_service.py" in result["unlinked_files"]
        assert result["inferred_decisions"]
        first = result["inferred_decisions"][0]
        assert "hash_password" in first["candidate_title"]
        assert first["confidence"] == 0.75

    @pytest.mark.asyncio
    async def test_decision_confirm_inferred_promotes_to_decision(
        self, full_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        from backend.intelligence.ast_tracker import ASTTracker

        tracker = ASTTracker(db=full_handlers.db)
        started = await full_handlers.session_start(
            user_id=user_id, agent_name="inferrer"
        )
        sid = uuid.UUID(started["id"])
        await tracker.process_change_event(
            change_event_id="cmt-inf-2",
            change_event_type="git_commit",
            diff_text=_INFERENCE_DIFF,
            project_id="default",
            active_session_id=str(sid),
        )
        end_result = await full_handlers.session_end(
            user_id=user_id, session_id=sid
        )
        inferred_id = uuid.UUID(end_result["inferred_decisions"][0]["inferred_decision_id"])
        confirm = await full_handlers.decision_confirm_inferred(
            user_id=user_id,
            inferred_decision_id=inferred_id,
            description="Hash passwords with Argon2id at registration.",
            tags=["auth", "security"],
        )
        assert confirm["decision"]["title"].startswith("Add hash_password")
        assert confirm["decision"]["inference_status"] == "confirmed"
        row = await full_handlers.db.get_by_id(
            "inferred_decisions", str(inferred_id)
        )
        assert row["status"] == "confirmed"

    @pytest.mark.asyncio
    async def test_decision_reject_inferred_marks_rejected(
        self, full_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        from backend.intelligence.ast_tracker import ASTTracker

        tracker = ASTTracker(db=full_handlers.db)
        started = await full_handlers.session_start(
            user_id=user_id, agent_name="inferrer"
        )
        sid = uuid.UUID(started["id"])
        await tracker.process_change_event(
            change_event_id="cmt-inf-3",
            change_event_type="git_commit",
            diff_text=_INFERENCE_DIFF,
            project_id="default",
            active_session_id=str(sid),
        )
        end_result = await full_handlers.session_end(
            user_id=user_id, session_id=sid
        )
        inferred_id = uuid.UUID(end_result["inferred_decisions"][0]["inferred_decision_id"])
        reject = await full_handlers.decision_reject_inferred(
            user_id=user_id,
            inferred_decision_id=inferred_id,
            reason="cosmetic refactor",
        )
        assert reject["status"] == "rejected"
        row = await full_handlers.db.get_by_id(
            "inferred_decisions", str(inferred_id)
        )
        assert row["status"] == "rejected"

    @pytest.mark.asyncio
    async def test_decision_list_pending_inferred_ordered_by_confidence(
        self, full_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        from backend.models import InferredDecision

        high = InferredDecision(
            session_id=uuid.uuid4(),
            project_id="default",
            candidate_title="High",
            confidence=0.8,
        )
        low = InferredDecision(
            session_id=uuid.uuid4(),
            project_id="default",
            candidate_title="Low",
            confidence=0.5,
        )
        await full_handlers.db.insert("inferred_decisions", high.to_dict())
        await full_handlers.db.insert("inferred_decisions", low.to_dict())
        pending = await full_handlers.decision_list_pending_inferred(
            user_id=user_id, project_id="default"
        )
        titles = [p["candidate_title"] for p in pending]
        assert titles.index("High") < titles.index("Low")

    @pytest.mark.asyncio
    async def test_session_end_force_skips_inference(
        self, full_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        from backend.intelligence.ast_tracker import ASTTracker

        tracker = ASTTracker(db=full_handlers.db)
        started = await full_handlers.session_start(
            user_id=user_id, agent_name="inferrer"
        )
        sid = uuid.UUID(started["id"])
        await tracker.process_change_event(
            change_event_id="cmt-force",
            change_event_type="git_commit",
            diff_text=_INFERENCE_DIFF,
            project_id="default",
            active_session_id=str(sid),
        )
        result = await full_handlers.session_end(
            user_id=user_id,
            session_id=sid,
            force=True,
            override_reason="scratch work",
        )
        assert result["status"] == "completed_forced"
        assert "inferred_decisions" not in result
        # No pending inferred decisions were persisted.
        rows = await full_handlers.db.query(
            "inferred_decisions", where={"session_id": str(sid)}
        )
        assert rows == []


# ---------------------------------------------------------------------------
# Hybrid search MCP integration (Prompt 2 upgrade)
# ---------------------------------------------------------------------------


class TestHybridContextRelevant:
    """Hybrid blend propagates through context.get_relevant."""

    @pytest.fixture
    async def hybrid_handlers(self, tmp_path: Path) -> ToolHandlers:
        """Handlers wired with SemanticSearch + BM25 against a real DB."""
        from backend.db.db_backend import SQLiteBackend
        from backend.db.migrations import apply_migrations
        from backend.db.vector_store import SqliteVssStore
        from backend.intelligence.context_triage import ContextTriage
        from backend.intelligence.semantic_search import SemanticSearch
        from backend.utils.token_counter import count_tokens

        db = SQLiteBackend(tmp_path / "hybrid-mcp.db")
        await db.connect()
        await apply_migrations(db)
        store = SqliteVssStore(tmp_path / "hybrid-mcp-vec.db")
        await store.connect()

        class _Fake:
            async def embed_text(self, text: str) -> list[float]:
                # Consistent fallback vector so everything cosine-ties.
                return [0.0] * 767 + [1.0]

            async def embed_batch(self, texts: list[str]) -> list[list[float]]:
                return [await self.embed_text(t) for t in texts]

        semantic = SemanticSearch(embedder=_Fake(), vector_store=store, db=db)
        triage = ContextTriage(count_tokens)
        yield ToolHandlers(
            db=db, semantic_search=semantic, context_triage=triage
        )
        await store.close()
        await db.close()

    @pytest.mark.asyncio
    async def test_pure_keyword_blend_surfaces_exact_match(
        self, hybrid_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        await hybrid_handlers.context_create(
            user_id=user_id, content="argon2id password hashing rule"
        )
        await hybrid_handlers.context_create(
            user_id=user_id, content="arbitrary filler for IDF"
        )
        await hybrid_handlers.context_create(
            user_id=user_id, content="another piece of filler content"
        )
        await hybrid_handlers.context_create(
            user_id=user_id, content="last piece of filler"
        )
        result = await hybrid_handlers.context_get_relevant(
            user_id=user_id,
            query="argon2id",
            token_budget=1000,
            top_k=3,
            blend_weight=0.0,
        )
        # Pure keyword blend means ranking comes from BM25 alone — the
        # "argon2id" item is the only match, so the rendered context block
        # must mention it.
        assert "argon2id" in result["context_block"]

    @pytest.mark.asyncio
    async def test_pure_vector_blend_misses_keyword_match(
        self, hybrid_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        # With pure vector (1.0) all items tie (fake embedder fallback),
        # so the ordering is insertion-order — not a keyword signal.
        # The observable difference is that pure_vector has NO bm25 retrieval.
        await hybrid_handlers.context_create(
            user_id=user_id, content="argon2id unique keyword"
        )
        result = await hybrid_handlers.context_get_relevant(
            user_id=user_id,
            query="argon2id",
            token_budget=1000,
            top_k=3,
            blend_weight=1.0,
        )
        # Pure vector mode returns "vector" or no entries.
        # retrieval_method is accessible via included_items metadata indirectly.
        assert isinstance(result["included_items"], list)


# ---------------------------------------------------------------------------
# Memory staleness lifecycle (Prompt 3 upgrade)
# ---------------------------------------------------------------------------


class TestStalenessLifecycleMCP:
    """decision.read tracks access; supersede, staleness_report, confirm_fresh."""

    @pytest.fixture
    async def stale_handlers(self, tmp_path: Path) -> ToolHandlers:
        from backend.db.db_backend import SQLiteBackend
        from backend.db.migrations import apply_migrations
        from backend.intelligence.staleness_scorer import StalenessScorer

        db = SQLiteBackend(tmp_path / "stale-mcp.db")
        await db.connect()
        await apply_migrations(db)
        yield ToolHandlers(db=db, staleness_scorer=StalenessScorer(db))
        await db.close()

    @pytest.mark.asyncio
    async def test_decision_read_increments_access_count(
        self, stale_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        created = await stale_handlers.decision_create(
            user_id=user_id, title="d"
        )
        did = uuid.UUID(created["id"])
        await stale_handlers.decision_read(user_id=user_id, decision_id=did)
        await stale_handlers.decision_read(user_id=user_id, decision_id=did)
        row = await stale_handlers.db.get_by_id("decisions", str(did))
        assert int(row["access_count"]) == 2
        assert row["last_accessed_at"] is not None

    @pytest.mark.asyncio
    async def test_decision_supersede_marks_both(
        self, stale_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        old = await stale_handlers.decision_create(
            user_id=user_id, title="old"
        )
        new = await stale_handlers.decision_create(
            user_id=user_id, title="new"
        )
        result = await stale_handlers.decision_supersede(
            user_id=user_id,
            decision_id=uuid.UUID(old["id"]),
            new_decision_id=uuid.UUID(new["id"]),
            reason="new strategy",
        )
        assert result["old_decision"]["superseded_by"] == new["id"]
        assert result["new_decision"]["supersedes"] == old["id"]
        old_row = await stale_handlers.db.get_by_id("decisions", old["id"])
        assert float(old_row["staleness_score"]) == 1.0

    @pytest.mark.asyncio
    async def test_staleness_report_returns_flagged_decisions(
        self, stale_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        from datetime import UTC, datetime, timedelta

        # Insert an old, never-accessed, edge-less decision — guaranteed to
        # land above the 0.3 threshold.
        old_ts = (datetime.now(UTC) - timedelta(days=120)).isoformat()
        await stale_handlers.db.insert(
            "decisions",
            {
                "id": str(uuid.uuid4()),
                "title": "Ancient decision",
                "description": "",
                "tags": "[]",
                "status": "unverified",
                "recorded_by_user_id": None,
                "recorded_in_session_id": None,
                "inference_status": "explicit",
                "inference_confidence": 1.0,
                "last_accessed_at": old_ts,
                "access_count": 0,
                "staleness_score": 0.0,
                "staleness_signals": "[]",
                "superseded_by": None,
                "supersedes": None,
                "created_at": old_ts,
                "updated_at": old_ts,
            },
        )
        report = await stale_handlers.decision_staleness_report(
            user_id=user_id, project_id="default"
        )
        assert report["decisions"]
        assert report["decisions"][0]["staleness_score"] > 0.3

    @pytest.mark.asyncio
    async def test_decision_confirm_fresh_resets_staleness(
        self, stale_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        # Seed a decision with elevated staleness.
        d = await stale_handlers.decision_create(
            user_id=user_id, title="To refresh"
        )
        did = d["id"]
        import json as _json
        await stale_handlers.db.update(
            "decisions",
            did,
            {
                "staleness_score": 0.9,
                "staleness_signals": _json.dumps(["outdated"]),
                "updated_at": "2025-01-01T00:00:00+00:00",
            },
        )
        refreshed = await stale_handlers.decision_confirm_fresh(
            user_id=user_id, decision_id=uuid.UUID(did)
        )
        assert refreshed["staleness_score"] == 0.0
        assert refreshed["staleness_signals"] == "[]"


# ---------------------------------------------------------------------------
# Auto-confirm passive inference (Prompt 5)
# ---------------------------------------------------------------------------


_AUTO_DIFF = (
    "diff --git a/auto_svc.py b/auto_svc.py\n"
    "--- a/auto_svc.py\n"
    "+++ b/auto_svc.py\n"
    "@@ -0,0 +1,2 @@\n"
    "+def auto_fn(x):\n"
    "+    return x\n"
)


class TestAutoConfirmSessionEnd:
    """session.end with auto_confirm_threshold promotes candidates directly."""

    @pytest.mark.asyncio
    async def test_threshold_promotes_high_confidence(
        self, full_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        from backend.intelligence.ast_tracker import ASTTracker

        tracker = ASTTracker(db=full_handlers.db)
        started = await full_handlers.session_start(
            user_id=user_id, agent_name="inferrer"
        )
        sid = uuid.UUID(started["id"])
        await tracker.process_change_event(
            change_event_id="cmt-auto-1",
            change_event_type="git_commit",
            diff_text=_AUTO_DIFF,
            project_id="default",
            active_session_id=str(sid),
        )
        result = await full_handlers.session_end(
            user_id=user_id,
            session_id=sid,
            auto_confirm_threshold=0.75,
        )
        assert result["status"] == "completed_with_warnings"
        auto = result.get("auto_confirmed_decisions") or []
        assert auto
        assert auto[0]["inference_status"] == "confirmed"
        assert "auto_fn" in auto[0]["title"]

    @pytest.mark.asyncio
    async def test_none_threshold_leaves_all_pending(
        self, full_handlers: ToolHandlers, user_id: uuid.UUID
    ) -> None:
        from backend.intelligence.ast_tracker import ASTTracker

        tracker = ASTTracker(db=full_handlers.db)
        started = await full_handlers.session_start(
            user_id=user_id, agent_name="inferrer"
        )
        sid = uuid.UUID(started["id"])
        await tracker.process_change_event(
            change_event_id="cmt-auto-2",
            change_event_type="git_commit",
            diff_text=_AUTO_DIFF,
            project_id="default",
            active_session_id=str(sid),
        )
        result = await full_handlers.session_end(
            user_id=user_id, session_id=sid
        )
        assert "auto_confirmed_decisions" not in result
        assert result["inferred_decisions"]
        rows = await full_handlers.db.query(
            "inferred_decisions", where={"session_id": str(sid)}
        )
        assert all(r["status"] == "pending" for r in rows)

    @pytest.mark.asyncio
    async def test_project_wide_threshold_used_when_caller_omits(
        self, tmp_path: Path, user_id: uuid.UUID
    ) -> None:
        """A handler configured with auto_confirm_threshold honours it by default."""
        from backend.intelligence.ast_tracker import ASTTracker
        from backend.intelligence.decision_inferrer import DecisionInferrer

        db = SQLiteBackend(tmp_path / "project-threshold.db")
        await db.connect()
        await apply_migrations(db)
        try:
            tracker = ASTTracker(db=db)
            handlers = ToolHandlers(
                db=db,
                decision_inferrer=DecisionInferrer(db=db, ast_tracker=tracker),
                auto_confirm_threshold=0.75,
            )
            started = await handlers.session_start(
                user_id=user_id, agent_name="inferrer"
            )
            sid = uuid.UUID(started["id"])
            await tracker.process_change_event(
                change_event_id="cmt-auto-3",
                change_event_type="git_commit",
                diff_text=_AUTO_DIFF,
                project_id="default",
                active_session_id=str(sid),
            )
            result = await handlers.session_end(
                user_id=user_id, session_id=sid
            )
            assert result.get("auto_confirmed_decisions")
        finally:
            await db.close()


# ---------------------------------------------------------------------------
# Decision conflict MCP tools (Prompt 6)
# ---------------------------------------------------------------------------


class TestDecisionConflictsMCP:
    @pytest.mark.asyncio
    async def test_list_conflicts_and_resolve_supersedes_loser(
        self, tmp_path: Path, user_id: uuid.UUID
    ) -> None:
        from backend.intelligence.staleness_scorer import StalenessScorer
        from backend.models import DecisionConflict

        db = SQLiteBackend(tmp_path / "conflicts-mcp.db")
        await db.connect()
        await apply_migrations(db)
        try:
            handlers = ToolHandlers(
                db=db, staleness_scorer=StalenessScorer(db=db)
            )
            a = await handlers.decision_create(user_id=user_id, title="A")
            b = await handlers.decision_create(user_id=user_id, title="B")
            conflict = DecisionConflict(
                project_id="default",
                decision_id_a=a["id"],
                decision_id_b=b["id"],
                conflict_type="direct_contradiction",
                confidence=0.85,
                description="opposing",
                status="active",
            )
            await db.insert("decision_conflicts", conflict.to_dict())

            listed = await handlers.decision_list_conflicts(
                user_id=user_id, project_id="default"
            )
            assert listed["conflicts"]
            assert listed["conflicts"][0]["conflict_id"] == str(conflict.id)

            resolved = await handlers.decision_resolve_conflict(
                user_id=user_id,
                conflict_id=conflict.id,
                resolution_decision_id=uuid.UUID(a["id"]),
                notes="A is the active policy",
            )
            assert resolved["status"] == "resolved"
            # B is superseded by A.
            b_row = await db.get_by_id("decisions", b["id"])
            assert b_row["superseded_by"] == a["id"]
            a_row = await db.get_by_id("decisions", a["id"])
            assert a_row["supersedes"] == b["id"]
        finally:
            await db.close()

    @pytest.mark.asyncio
    async def test_resolve_third_party_decision_does_not_supersede(
        self, tmp_path: Path, user_id: uuid.UUID
    ) -> None:
        from backend.intelligence.staleness_scorer import StalenessScorer
        from backend.models import DecisionConflict

        db = SQLiteBackend(tmp_path / "conflicts-third.db")
        await db.connect()
        await apply_migrations(db)
        try:
            handlers = ToolHandlers(
                db=db, staleness_scorer=StalenessScorer(db=db)
            )
            a = await handlers.decision_create(user_id=user_id, title="A")
            b = await handlers.decision_create(user_id=user_id, title="B")
            c = await handlers.decision_create(user_id=user_id, title="C")
            conflict = DecisionConflict(
                project_id="default",
                decision_id_a=a["id"],
                decision_id_b=b["id"],
                conflict_type="scope_overlap",
                confidence=0.55,
                description="overlap",
                status="active",
            )
            await db.insert("decision_conflicts", conflict.to_dict())

            await handlers.decision_resolve_conflict(
                user_id=user_id,
                conflict_id=conflict.id,
                resolution_decision_id=uuid.UUID(c["id"]),
                notes="Both remain valid in their own scopes",
            )
            a_row = await db.get_by_id("decisions", a["id"])
            b_row = await db.get_by_id("decisions", b["id"])
            # Neither A nor B is superseded because the resolver is unrelated.
            assert not a_row.get("superseded_by")
            assert not b_row.get("superseded_by")
        finally:
            await db.close()


# ---------------------------------------------------------------------------
# Universal active context via MCP (Prompt 8)
# ---------------------------------------------------------------------------


class TestUniversalActiveContext:
    """Tool calls with cwd/agent_name/project_id bootstrap sessions on their own."""

    @pytest.fixture
    async def active_handlers(self, tmp_path: Path) -> ToolHandlers:
        from backend.intelligence.ast_tracker import ASTTracker
        from backend.intelligence.decision_inferrer import DecisionInferrer
        from backend.utils.token_counter import count_tokens
        from backend.verification.conflict_detector import ConflictDetector

        db = SQLiteBackend(tmp_path / "active-mcp.db")
        await db.connect()
        await apply_migrations(db)
        store = SqliteVssStore(tmp_path / "active-mcp-vec.db", dim=16)
        await store.connect()

        class _Fake:
            async def embed_text(self, text: str) -> list[float]:
                return [0.1] * 15 + [1.0]

            async def embed_batch(self, texts: list[str]) -> list[list[float]]:
                return [await self.embed_text(t) for t in texts]

        tracker = ASTTracker(db=db)
        semantic = SemanticSearch(
            embedder=_Fake(), vector_store=store, db=db
        )
        yield ToolHandlers(
            db=db,
            semantic_search=semantic,
            context_triage=ContextTriage(count_tokens),
            conflict_detector=ConflictDetector(db),
            decision_inferrer=DecisionInferrer(db=db, ast_tracker=tracker),
        )
        await store.close()
        await db.close()

    @pytest.mark.asyncio
    async def test_mcp_tool_call_without_session_start_creates_session(
        self, active_handlers: ToolHandlers
    ) -> None:
        """Simulates Cursor/Windsurf — no explicit session.start."""
        from backend.mcp.mcp_server import create_mcp_server

        mcp = create_mcp_server(active_handlers)
        context_tool = await mcp.get_tool("context")
        # The first tool call from this agent/project pair creates a session.
        result = await context_tool.fn(
            method="create",
            user_id=str(uuid.uuid4()),
            content="a context note",
            cwd="/tmp/cursor-proj",
            agent_name="cursor",
            project_id="cursor-proj",
        )
        rows = await active_handlers.db.query(
            "sessions",
            where={"agent_name": "cursor", "status": "active"},
        )
        assert len(rows) == 1
        assert rows[0]["project_id"] == "cursor-proj"
        # The response carries the auto-created session_context.
        assert isinstance(result, dict)
        assert "session_context" in result
        assert (
            result["session_context"]["session_id"] == str(rows[0]["id"])
        )

    @pytest.mark.asyncio
    async def test_second_tool_call_reuses_session_and_skips_context_block(
        self, active_handlers: ToolHandlers
    ) -> None:
        from backend.mcp.mcp_server import create_mcp_server

        mcp = create_mcp_server(active_handlers)
        context_tool = await mcp.get_tool("context")
        uid = str(uuid.uuid4())
        first = await context_tool.fn(
            method="create",
            user_id=uid,
            content="first",
            cwd="/tmp/c",
            agent_name="cursor",
            project_id="c",
        )
        second = await context_tool.fn(
            method="create",
            user_id=uid,
            content="second",
            cwd="/tmp/c",
            agent_name="cursor",
            project_id="c",
        )
        assert isinstance(first, dict)
        assert isinstance(second, dict)
        assert "session_context" in first
        # Second call: the session already exists, so no session_context
        # injection happens.
        assert "session_context" not in second

    @pytest.mark.asyncio
    async def test_unknown_project_gracefully_handled(
        self, active_handlers: ToolHandlers
    ) -> None:
        # Any project_id string is accepted — the handlers don't verify it
        # against a project registry. This test documents that the tool
        # call does not crash for a project that has no data.
        from backend.mcp.mcp_server import create_mcp_server

        mcp = create_mcp_server(active_handlers)
        context_tool = await mcp.get_tool("context")
        result = await context_tool.fn(
            method="create",
            user_id=str(uuid.uuid4()),
            content="anything",
            cwd="/tmp/unknown",
            agent_name="cursor",
            project_id="unknown-project",
        )
        assert isinstance(result, dict)
        # Session context still attached even when the project is "unknown" —
        # project_id is an opaque string; the handlers do not validate it.
        assert "session_context" in result

    @pytest.mark.asyncio
    async def test_before_edit_tool_returns_full_bundle(
        self, active_handlers: ToolHandlers
    ) -> None:
        from backend.mcp.mcp_server import create_mcp_server

        mcp = create_mcp_server(active_handlers)
        context_tool = await mcp.get_tool("context")
        result = await context_tool.fn(
            method="before_edit",
            user_id=str(uuid.uuid4()),
            file_path="auth.py",
            file_content="def hash_password(pw):\n    return pw\n",
            cwd="/tmp/c",
            agent_name="cursor",
            project_id="c",
        )
        assert "decisions" in result
        assert "conflicts" in result
        assert "import_warnings" in result
        assert "session_id" in result

    @pytest.mark.asyncio
    async def test_inactivity_sweep_closes_and_runs_inference(
        self, active_handlers: ToolHandlers
    ) -> None:
        # Create a session and simulate activity that produced unlinked
        # changes, then age it past the inactivity window.
        from backend.intelligence.ast_tracker import ASTTracker

        tracker = ASTTracker(db=active_handlers.db)
        result = await active_handlers.ensure_session_and_inject_context(
            cwd="/tmp/c",
            agent_name="cursor",
            project_id="c",
        )
        assert result is not None
        sid = result.session_id

        diff = (
            "diff --git a/svc.py b/svc.py\n"
            "--- a/svc.py\n"
            "+++ b/svc.py\n"
            "@@ -0,0 +1,2 @@\n"
            "+def do_thing():\n"
            "+    return 1\n"
        )
        await tracker.process_change_event(
            change_event_id="cmt-sweep",
            change_event_type="git_commit",
            diff_text=diff,
            project_id="c",
            active_session_id=sid,
        )

        # Rewind the session's last_tool_call_at so it qualifies for the
        # inactivity sweep immediately.
        old_ts = (datetime.now(UTC) - timedelta(minutes=120)).isoformat()
        await active_handlers.db.update(
            "sessions", sid, {"last_tool_call_at": old_ts}
        )

        closed = await active_handlers.close_inactive_sessions(
            inactivity_timeout_minutes=30
        )
        assert sid in closed
        row = await active_handlers.db.get_by_id("sessions", sid)
        assert row["status"] == "completed"
        # Inference was attempted — with threshold=0.75 and a single-file
        # single-commit candidate (0.75 confidence), we expect a promotion.
        decisions = await active_handlers.db.query(
            "decisions", where={"inference_status": "confirmed"}
        )
        # At minimum, the inference path did not crash — decisions may or
        # may not have promoted depending on linking heuristics.
        assert isinstance(decisions, list)
