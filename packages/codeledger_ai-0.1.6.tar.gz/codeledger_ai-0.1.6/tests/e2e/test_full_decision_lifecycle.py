"""End-to-end decision lifecycle test for the git change detection backend.

Covers the full chain described in PHASE_GUIDE Module 3.6 (git variant):

1. Start session, record decision, simulate a structural git commit.
2. Verify ASTChange records created with ``change_event_type: "git_commit"``.
3. Verify ProvenanceEdge links the decision to the commit.
4. Simulate a CI webhook and verify the decision transitions to "passed".
5. Forward trace returns the complete change tree.
6. Reverse trace from the function name returns the originating decision.
7. Structural commit without a session creates an UnlinkedCommit row.
8. session.end with unlinked files returns "completed_with_warnings".
"""

from __future__ import annotations

import uuid
from typing import TYPE_CHECKING

import pytest

from backend.db.db_backend import SQLiteBackend
from backend.db.migrations import apply_migrations
from backend.intelligence.ast_tracker import ASTTracker
from backend.mcp.tool_handlers import ToolHandlers
from backend.verification.conflict_detector import ConflictDetector
from backend.verification.harness import QualityHarness
from backend.verification.provenance import ProvenanceEngine
from backend.verification.verifier import Verifier

if TYPE_CHECKING:
    from pathlib import Path


_DIFF_ADD_FN = (
    "diff --git a/lifecycle.py b/lifecycle.py\n"
    "--- a/lifecycle.py\n"
    "+++ b/lifecycle.py\n"
    "@@ -0,0 +1,2 @@\n"
    "+def lifecycle_fn(payload):\n"
    "+    return payload\n"
)


@pytest.fixture
async def handlers(tmp_path: Path) -> ToolHandlers:
    db = SQLiteBackend(tmp_path / "e2e.db")
    await db.connect()
    await apply_migrations(db)
    yield ToolHandlers(
        db=db,
        verifier=Verifier(db),
        harness=QualityHarness(db),
        conflict_detector=ConflictDetector(db),
        provenance=ProvenanceEngine(db),
        change_detection_backend="git",
    )
    await db.close()


class TestGitDecisionLifecycle:
    @pytest.mark.asyncio
    async def test_full_flow(self, handlers: ToolHandlers) -> None:
        tracker = ASTTracker(db=handlers.db)
        user_id = uuid.uuid4()

        # 1. Start a session.
        session = await handlers.session_start(
            user_id=user_id, agent_name="claude-opus"
        )
        sid = uuid.UUID(session["id"])

        # 2. Record a decision that references the file + entity.
        decision = await handlers.decision_create(
            user_id=user_id,
            title="Add lifecycle_fn in lifecycle.py",
            description="Primary entry for the lifecycle pipeline.",
            session_id=sid,
        )
        did = uuid.UUID(decision["id"])

        # 3. Simulate the git post-commit hook.
        result = await tracker.process_change_event(
            change_event_id="commit-e2e",
            change_event_type="git_commit",
            diff_text=_DIFF_ADD_FN,
            project_id="default",
            active_session_id=str(sid),
        )
        assert "lifecycle_fn" in result["linked_changes"]
        assert result["unlinked_changes"] == []

        # 4. ASTChange records stamped with change_event_type: "git_commit".
        ast_rows = await handlers.db.query(
            "ast_changes", where={"change_event_id": "commit-e2e"}
        )
        assert ast_rows
        assert all(r["change_event_type"] == "git_commit" for r in ast_rows)

        # 5. ProvenanceEdge links the decision.
        edges = await handlers.db.query(
            "provenance_edges",
            where={"source_type": "decision", "source_id": str(did)},
        )
        assert edges

        # 6. CI webhook → decision transitions to "passed".
        assert handlers.verifier is not None
        webhook_result = await handlers.verifier.process_webhook(
            {"commit_hash": "commit-e2e", "status": "passed"},
            provider="github",
            project_id="default",
        )
        assert str(did) in webhook_result["transitioned_decisions"]
        status = await handlers.verify_status(
            user_id=user_id, decision_id=did
        )
        assert status["status"] == "passed"

        # 7. Forward trace returns full tree.
        tree = await handlers.provenance_forward(
            user_id=user_id, decision_id=did
        )
        assert len(tree["change_events"]) == 1
        assert tree["change_events"][0]["change_event_type"] == "git_commit"

        # 8. Reverse trace from the file+entity finds the decision.
        reverse = await handlers.provenance_reverse(
            user_id=user_id,
            file_path="lifecycle.py",
            entity_name="lifecycle_fn",
        )
        assert any(
            r["decision"]["id"] == str(did) for r in reverse["results"]
        )

        # 9. session.end succeeds cleanly when the decision is linked.
        ended = await handlers.session_end(
            user_id=user_id, session_id=sid
        )
        assert ended["status"] == "completed"

    @pytest.mark.asyncio
    async def test_unlinked_commit_record_created_outside_session(
        self, handlers: ToolHandlers
    ) -> None:
        tracker = ASTTracker(db=handlers.db)
        await tracker.process_change_event(
            change_event_id="orphan-commit",
            change_event_type="git_commit",
            diff_text=_DIFF_ADD_FN,
            project_id="default",
        )
        orphans = await handlers.db.query(
            "unlinked_commits", where={"commit_hash": "orphan-commit"}
        )
        assert orphans
        assert any("lifecycle_fn" in str(o["structurally_changed_symbols"]) for o in orphans)

    @pytest.mark.asyncio
    async def test_session_end_with_warnings(
        self, handlers: ToolHandlers
    ) -> None:
        tracker = ASTTracker(db=handlers.db)
        user_id = uuid.uuid4()
        session = await handlers.session_start(
            user_id=user_id, agent_name="orphan-agent"
        )
        sid = uuid.UUID(session["id"])

        # Commit a structural change but DO NOT record a decision.
        await tracker.process_change_event(
            change_event_id="commit-warn",
            change_event_type="git_commit",
            diff_text=_DIFF_ADD_FN,
            project_id="default",
            active_session_id=str(sid),
        )

        result = await handlers.session_end(
            user_id=user_id, session_id=sid
        )
        assert result["status"] == "completed_with_warnings"
        assert "lifecycle.py" in result["unlinked_files"]
