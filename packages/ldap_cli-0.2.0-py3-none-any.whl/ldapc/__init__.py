"""LDAP CLI tool for querying LDAP directories."""

from __future__ import annotations

from ldapc._version import __version__

__all__ = ['__version__']
