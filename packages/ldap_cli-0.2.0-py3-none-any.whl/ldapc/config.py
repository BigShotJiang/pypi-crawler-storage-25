"""Configuration management for ldapc.

Handles reading, writing, and validating the ldapc configuration file
stored at ~/.ldapc/config.yaml. Provides serialization between
LdapcConfig dataclass instances and YAML format.
"""

from __future__ import annotations

import os
import stat
from dataclasses import dataclass
from pathlib import Path

import keyring
import yaml

from ldapc.exceptions import ConfigError

DEFAULT_CONFIG_DIR = Path.home() / ".ldapc"
DEFAULT_CONFIG_PATH = DEFAULT_CONFIG_DIR / "config.yaml"


@dataclass
class LdapcConfig:
    """Configuration object for ldapc.

    Attributes:
        host: LDAP server URL (ldaps:// or ldap://).
        username: Bind DN for authentication.
        base_dn: Base DN for searches. Defaults to empty string.
        users_ou: RDN for the users container. Defaults to "cn=users".
        groups_ou: RDN for the groups container. Defaults to "cn=groups".
    """

    host: str
    username: str
    base_dn: str = ""
    users_ou: str = "cn=users"
    groups_ou: str = "cn=groups"


def config_to_yaml(config: LdapcConfig) -> str:
    """Serialize a config object to a YAML string.

    Args:
        config: The LdapcConfig instance to serialize.

    Returns:
        A YAML-formatted string representing the configuration.
    """
    data = {
        "host": config.host,
        "username": config.username,
        "base_dn": config.base_dn,
        "users_ou": config.users_ou,
        "groups_ou": config.groups_ou,
    }
    return yaml.dump(data, default_flow_style=False, sort_keys=False)


def yaml_to_config(yaml_str: str) -> LdapcConfig:
    """Parse a YAML string into a config object.

    Args:
        yaml_str: A YAML-formatted string to parse.

    Returns:
        An LdapcConfig instance populated from the YAML data.

    Raises:
        ConfigError: If the YAML is invalid or missing required fields.
    """
    try:
        data = yaml.safe_load(yaml_str)
    except yaml.YAMLError as exc:
        raise ConfigError(f"Invalid YAML in configuration: {exc}") from exc

    if not isinstance(data, dict):
        raise ConfigError(
            "Invalid configuration file: expected a YAML mapping, "
            f"got {type(data).__name__}"
        )

    missing_fields = []
    for field in ("host", "username"):
        if field not in data:
            missing_fields.append(field)

    if missing_fields:
        raise ConfigError(
            f"Missing required configuration fields: {', '.join(missing_fields)}"
        )

    return LdapcConfig(
        host=str(data["host"]),
        username=str(data["username"]),
        base_dn=str(data.get("base_dn", "")),
        users_ou=str(data.get("users_ou", "cn=users")),
        groups_ou=str(data.get("groups_ou", "cn=groups")),
    )


def load_config(config_path: Path | None = None) -> LdapcConfig:
    """Load configuration from ~/.ldapc/config.yaml.

    Args:
        config_path: Optional path to the config file. Defaults to
            ~/.ldapc/config.yaml.

    Returns:
        An LdapcConfig instance loaded from the file.

    Raises:
        ConfigError: If the file is missing or contains invalid YAML.
    """
    path = config_path or DEFAULT_CONFIG_PATH

    if not path.exists():
        raise ConfigError(
            "Configuration not found. Run 'ldapc configure' to set up."
        )

    try:
        yaml_str = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise ConfigError(f"Unable to read configuration file: {exc}") from exc

    return yaml_to_config(yaml_str)


def save_config(config: LdapcConfig, config_path: Path | None = None) -> None:
    """Serialize config to ~/.ldapc/config.yaml with 0600 permissions.

    Creates the ~/.ldapc/ directory if it does not exist.

    Args:
        config: The LdapcConfig instance to persist.
        config_path: Optional path to the config file. Defaults to
            ~/.ldapc/config.yaml.
    """
    path = config_path or DEFAULT_CONFIG_PATH
    config_dir = path.parent

    config_dir.mkdir(parents=True, exist_ok=True)

    yaml_str = config_to_yaml(config)
    path.write_text(yaml_str, encoding="utf-8")
    os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)


KEYRING_SERVICE = "ldapc"


def store_password(username: str, password: str) -> None:
    """Store password in OS keychain under service 'ldapc'.

    Args:
        username: The account identifier (bind DN) to associate with
            the stored password.
        password: The password to store securely.
    """
    keyring.set_password(KEYRING_SERVICE, username, password)


def retrieve_password(username: str) -> str:
    """Retrieve password from OS keychain.

    Args:
        username: The account identifier (bind DN) whose password
            should be retrieved.

    Returns:
        The stored password string.

    Raises:
        ConfigError: If no password is stored for the account.
    """
    password = keyring.get_password(KEYRING_SERVICE, username)
    if password is None:
        raise ConfigError(
            "No stored password. Run 'ldapc configure' to set up."
        )
    return password
