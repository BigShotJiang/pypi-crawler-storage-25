"""Exception classes for ldapc.

All exceptions inherit from LdapcError, enabling consistent catching
at the CLI layer and mapping to appropriate exit codes.
"""


class LdapcError(Exception):
    """Base exception for ldapc.

    All ldapc-specific exceptions inherit from this class so the CLI
    entry point can catch them uniformly and map to exit codes.
    """


class ConfigError(LdapcError):
    """Configuration-related errors.

    Raised when the configuration file is missing, contains invalid YAML,
    or required fields are absent. Maps to exit code 2.
    """


class ConnectionError(LdapcError):
    """LDAP connection errors.

    Raised when the LDAP server is unreachable, the connection times out,
    or TLS certificate verification fails. Maps to exit code 1.
    """


class AuthenticationError(LdapcError):
    """LDAP bind/authentication errors.

    Raised when the LDAP server rejects the bind credentials.
    Maps to exit code 1.
    """
