# ldapc

A Python CLI tool for querying and managing LDAP directories. Provides a simple subcommand interface to list, search, get, add, and delete users and groups, with persistent configuration and secure credential storage via the OS keychain.

## Features

- List all users or groups
- Search users by name/uid, groups by name (case-insensitive substring)
- Get detailed info on a specific user or group
- Add and delete users and groups
- Manage group membership (add/remove users from groups)
- Text, JSON, and YAML output formats
- Persistent configuration in `~/.ldapc/config.yaml`
- Secure credential storage via OS keychain
- TLS-secured connections with optional certificate verification skip
- Debug logging for troubleshooting

## Installation

```bash
# From PyPI
pip install ldap-cli

# From source (editable, with dev deps)
pip install -e ".[dev]"
```

## Quick Start

```bash
# Configure (host, base DN, bind DN, password)
ldapc configure

# List all users
ldapc list users

# Search for a user
ldapc search user john

# Get user details in YAML
ldapc get user jdoe --yaml

# Skip SSL verification (self-signed certs)
ldapc list users --skip-ssl-verify
```

## Usage

### Configure

```bash
ldapc configure
```

Prompts for LDAP host URL, base DN, bind DN, and password. Config is stored in `~/.ldapc/config.yaml`; password goes to the OS keychain.

### List

```bash
ldapc list users          # all users
ldapc list groups         # all groups
```

### Search

```bash
ldapc search user john    # users matching "john" (case-insensitive)
ldapc search group admin  # groups matching "admin"
```

### Get

```bash
ldapc get user jdoe       # exact user lookup
ldapc get group devs      # exact group lookup
```

### Add / Delete

```bash
ldapc add user newuser
ldapc add group newgroup
ldapc delete user olduser
ldapc delete group oldgroup
```

### Group Membership

```bash
ldapc user add group jdoe developers      # add user to group
ldapc user remove group jdoe developers   # remove user from group
```

### Output Formats

```bash
ldapc list users --json   # JSON output
ldapc list users --yaml   # YAML output (simplified, human-friendly)
```

### Global Flags

These flags can appear after any subcommand:

| Flag | Env Var | Description |
|------|---------|-------------|
| `--debug` | — | Enable debug logging to stderr |
| `--skip-ssl-verify` | `LDAPC_SKIP_SSL_VERIFY=1` | Skip TLS certificate verification |
| `--json` | — | Output as JSON |
| `--yaml` | — | Output as simplified YAML |

### Help

```bash
ldapc --help          # top-level help
ldapc get --help      # subcommand help
ldapc --version       # show version
```

### Documentation

```bash
ldapc --docs                          # list available doc files
ldapc --docs README.md                # render README as rich text
ldapc --docs README.md --page         # render with paging
ldapc --docs README.md --markdown     # output raw markdown
ldapc --docs docs/README.md --page    # view docs/README.md with paging
```

## Running Tests

```bash
pip install -e ".[dev]"
python3 -m pytest tests/ -v
```

With coverage:

```bash
python3 -m pytest tests/ --cov=ldapc --cov-report=term-missing
```

## License

MIT — see [LICENSE](LICENSE) for details.
