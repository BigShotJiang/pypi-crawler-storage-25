# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.0] - 2025-05-12

### Added

- Subcommand-based CLI: `list`, `search`, `get`, `add`, `delete`, `user add group`, `user remove group`
- `ldapc list users` / `ldapc list groups` to list all entries
- `ldapc search user|group <term>` for case-insensitive substring search
- `ldapc get user|group <name>` for exact lookup
- `ldapc add user|group <name>` to create entries
- `ldapc delete user|group <name>` to remove entries
- `ldapc user add group <user> <group>` to add user to group
- `ldapc user remove group <user> <group>` to remove user from group
- `--yaml` flag for simplified YAML output (extracts cn from group DNs)
- `--skip-ssl-verify` can now be set via `LDAPC_SKIP_SSL_VERIFY` environment variable
- `--debug` flag for verbose logging output to stderr
- `--docs` flag to browse and view bundled documentation (rich text or markdown, with optional paging)
- All `.md` files (README, CHANGELOG, docs/) are now included in the wheel
- `rich` added as a runtime dependency for documentation rendering
- LDAP filter input escaping (RFC 4515) to prevent filter injection

### Changed

- CLI switched from flat flags (`--user`, `--group`) to subcommand structure
- `--skip-ssl-verify` defaults to the value of `LDAPC_SKIP_SSL_VERIFY` env var (1/true/yes)
- LDAP search filters now include objectClass constraints for precision
- User/group container OUs are now configurable via `users_ou` and `groups_ou` in config
- Project description updated to reflect full management capabilities

## [0.1.0] - 2025-01-01

### Added

- Initial project scaffolding
- CLI entry point (`ldapc`)
- Configuration module with YAML persistence and keyring credential storage
- LDAP client module with user and group search
- Output formatter with text and JSON modes
- Property-based tests for correctness properties
