# Requirements Document

## Introduction

A Python CLI tool (`ldapc`) for querying LDAP directories. The tool provides a simple interface to search for users and groups, with persistent configuration stored locally and secure credential management via the OS keychain.

## Glossary

- **CLI**: The `ldapc` command-line interface application
- **Configuration_Store**: The YAML configuration file located at `~/.ldapc/config.yaml`
- **Keychain**: The operating system's native credential storage (macOS Keychain, Windows Credential Manager, or Linux Secret Service)
- **LDAP_Server**: The remote LDAP directory server the CLI connects to
- **Config_Parser**: The component that reads and writes `~/.ldapc/config.yaml`
- **Config_Printer**: The component that serializes configuration objects back to YAML format
- **Search_Result**: A structured object containing attributes returned from an LDAP query

## Requirements

### Requirement 1: CLI Entry Point

**User Story:** As a developer, I want to invoke the LDAP CLI by typing `ldapc`, so that I can quickly query LDAP without remembering long commands.

#### Acceptance Criteria

1. THE CLI SHALL be invocable as `ldapc` from the shell after installation
2. WHEN invoked without arguments, THE CLI SHALL display a help message showing available options and usage examples
3. WHEN invoked with `--version`, THE CLI SHALL display the current version string
4. WHEN invoked with `--help`, THE CLI SHALL display the full help text including all supported flags

### Requirement 2: Interactive Configuration

**User Story:** As a developer, I want to configure the LDAP host and credentials interactively, so that I do not have to provide them on every invocation.

#### Acceptance Criteria

1. WHEN invoked with `--configure`, THE CLI SHALL prompt the user for the LDAP host URL
2. WHEN invoked with `--configure`, THE CLI SHALL prompt the user for the bind username
3. WHEN invoked with `--configure`, THE CLI SHALL prompt the user for the bind password
4. WHEN the user completes the configuration prompts, THE Configuration_Store SHALL persist the host and username to `~/.ldapc/config.yaml`
5. WHEN the user completes the configuration prompts, THE CLI SHALL store the password in the Keychain
6. IF the `~/.ldapc/` directory does not exist, THEN THE CLI SHALL create it before writing the configuration file
7. THE Configuration_Store SHALL set file permissions on `~/.ldapc/config.yaml` to owner-read-write only (0600)

### Requirement 3: Configuration File Parsing

**User Story:** As a developer, I want the CLI to reliably read and write its configuration file, so that my settings persist across sessions.

#### Acceptance Criteria

1. WHEN a valid `~/.ldapc/config.yaml` file exists, THE Config_Parser SHALL parse it into a configuration object containing host and username
2. IF `~/.ldapc/config.yaml` contains invalid YAML, THEN THE Config_Parser SHALL return a descriptive error message indicating the parse failure
3. THE Config_Printer SHALL format configuration objects back into valid YAML files
4. FOR ALL valid configuration objects, parsing then printing then parsing SHALL produce an equivalent object (round-trip property)
5. IF `~/.ldapc/config.yaml` does not exist, THEN THE CLI SHALL display an error instructing the user to run `ldapc --configure`

### Requirement 4: Secure Credential Storage

**User Story:** As a developer, I want my LDAP password stored securely in the OS keychain, so that it is not exposed in plain-text files.

#### Acceptance Criteria

1. WHEN storing credentials, THE CLI SHALL use the OS Keychain with service name `ldapc` and the configured username as the account identifier
2. WHEN retrieving credentials for an LDAP connection, THE CLI SHALL read the password from the Keychain
3. IF the Keychain does not contain a stored password for the configured account, THEN THE CLI SHALL display an error instructing the user to run `ldapc --configure`
4. THE CLI SHALL NOT write the password to any file on disk

### Requirement 5: Query by User

**User Story:** As a developer, I want to search LDAP for a user by name, so that I can quickly look up user attributes.

#### Acceptance Criteria

1. WHEN invoked with `--user {searchuser}`, THE CLI SHALL query the LDAP_Server for entries matching the search term against common name and uid attributes
2. WHEN the LDAP_Server returns matching user entries, THE CLI SHALL display each entry's distinguished name, common name, email, and group memberships in a readable format
3. WHEN the LDAP_Server returns no matching user entries, THE CLI SHALL display a message indicating no results were found for the search term
4. IF the LDAP_Server is unreachable, THEN THE CLI SHALL display a connection error message including the configured host
5. IF the LDAP bind credentials are rejected, THEN THE CLI SHALL display an authentication error message

### Requirement 6: Query by Group

**User Story:** As a developer, I want to search LDAP for a group by name, so that I can see group membership details.

#### Acceptance Criteria

1. WHEN invoked with `--group {searchgroup}`, THE CLI SHALL query the LDAP_Server for group entries matching the search term against common name
2. WHEN the LDAP_Server returns matching group entries, THE CLI SHALL display each group's distinguished name, common name, description, and member list in a readable format
3. WHEN the LDAP_Server returns no matching group entries, THE CLI SHALL display a message indicating no results were found for the search term
4. IF the LDAP_Server is unreachable, THEN THE CLI SHALL display a connection error message including the configured host
5. IF the LDAP bind credentials are rejected, THEN THE CLI SHALL display an authentication error message

### Requirement 7: Output Formatting

**User Story:** As a developer, I want search results displayed in a clear, readable format, so that I can quickly find the information I need.

#### Acceptance Criteria

1. THE CLI SHALL display search results using aligned key-value formatting for single results
2. WHEN multiple results are returned, THE CLI SHALL visually separate each entry with a delimiter
3. WHEN the `--json` flag is provided, THE CLI SHALL output results as valid JSON to stdout
4. THE CLI SHALL write error messages to stderr, keeping stdout reserved for query results

### Requirement 8: Connection Management

**User Story:** As a developer, I want the CLI to handle LDAP connections reliably, so that queries complete without leaving stale connections.

#### Acceptance Criteria

1. WHEN a query is initiated, THE CLI SHALL establish a TLS-secured connection to the LDAP_Server
2. WHEN a query completes, THE CLI SHALL unbind and close the LDAP connection
3. IF the connection times out after 10 seconds, THEN THE CLI SHALL display a timeout error and exit with a non-zero status code
4. IF a TLS certificate verification fails, THEN THE CLI SHALL display a certificate error message

### Requirement 9: Exit Codes

**User Story:** As a developer, I want consistent exit codes, so that I can use `ldapc` in scripts and automation.

#### Acceptance Criteria

1. WHEN a query completes successfully, THE CLI SHALL exit with code 0
2. WHEN a query returns no results, THE CLI SHALL exit with code 0
3. IF a connection or authentication error occurs, THEN THE CLI SHALL exit with code 1
4. IF a configuration error occurs, THEN THE CLI SHALL exit with code 2
5. IF an invalid argument is provided, THEN THE CLI SHALL exit with code 2
