# ldapc Documentation

## Contents

- [Commands](#commands) — Full command reference
- [Configuration](#configuration) — Config file and credential storage
- [Output Formats](#output-formats) — Text, JSON, and YAML
- [Environment Variables](#environment-variables) — Env var reference
- [Development](#development) — Contributing, testing, project conventions

## Overview

`ldapc` is a Python CLI tool for querying and managing LDAP directories. It uses a subcommand structure for all operations.

## Commands

### configure

```bash
ldapc configure
```

Interactive setup. Prompts for:
- **LDAP host URL** — e.g. `ldaps://ldap.example.com:636`
- **Base DN** — e.g. `dc=ldap,dc=example,dc=com`
- **Bind DN** — e.g. `uid=admin,cn=users,dc=ldap,dc=example,dc=com`
- **Bind password** — stored in OS keychain

Config saved to `~/.ldapc/config.yaml` (mode 0600).

### list

```bash
ldapc list users    # list all users
ldapc list groups   # list all groups
```

### search

```bash
ldapc search user <term>    # case-insensitive substring match on cn/uid
ldapc search group <term>   # case-insensitive substring match on cn
```

### get

```bash
ldapc get user <name>    # exact match on uid or cn
ldapc get group <name>   # exact match on cn
```

Returns exit code 1 if not found.

### add

```bash
ldapc add user <name>    # creates inetOrgPerson under ou=users
ldapc add group <name>   # creates posixGroup under ou=groups
```

### delete

```bash
ldapc delete user <name>
ldapc delete group <name>
```

### user (group membership)

```bash
ldapc user add group <user> <group>      # add user to group
ldapc user remove group <user> <group>   # remove user from group
```

## Output Formats

### Default (text)

Aligned key-value format:

```
DN        : uid=jdoe,ou=users,dc=example,dc=com
CN        : John Doe
Email     : john@example.com
Groups    : cn=developers,ou=groups,dc=example,dc=com
```

### JSON (`--json`)

```json
[
  {
    "dn": "uid=jdoe,ou=users,dc=example,dc=com",
    "attributes": {
      "cn": ["John Doe"],
      "mail": ["john@example.com"],
      "memberOf": ["cn=developers,ou=groups,dc=example,dc=com"]
    }
  }
]
```

### YAML (`--yaml`)

Simplified, human-friendly format. Group DNs are reduced to just the cn value:

```yaml
---
cn: John Doe
email: john@example.com
groups:
- developers
```

## Global Flags

These flags work with any subcommand and can appear anywhere after the subcommand name:

| Flag | Description |
|------|-------------|
| `--debug` | Enable debug logging (connection details, search filters, result counts) to stderr |
| `--skip-ssl-verify` | Skip TLS certificate verification |
| `--json` | Output results as JSON |
| `--yaml` | Output results as simplified YAML |

## Environment Variables

| Variable | Description |
|----------|-------------|
| `LDAPC_SKIP_SSL_VERIFY` | Set to `1`, `true`, or `yes` to skip TLS cert verification by default |

## Configuration

### File location

`~/.ldapc/config.yaml` (created by `ldapc configure`)

### Format

```yaml
host: ldaps://ldap.example.com:636
username: uid=admin,cn=users,dc=ldap,dc=example,dc=com
base_dn: dc=ldap,dc=example,dc=com
```

### Credentials

Password is stored in the OS keychain (macOS Keychain, Windows Credential Manager, Linux Secret Service) under service name `ldapc`.

## Installation

```bash
# From PyPI
pip install ldap-cli

# From source (editable, with dev deps)
pip install -e ".[dev]"
```

## Development

### Running tests

```bash
pip install -e ".[dev]"
python3 -m pytest tests/ -v
```

### Coverage

```bash
python3 -m pytest tests/ --cov=ldapc --cov-report=term-missing
```

### Project structure

```
ldapc/
  __init__.py        # Package init, exports __version__
  _version.py        # Version extraction from CHANGELOG.md
  cli.py             # CLI entry point with subcommand parser
  config.py          # Config file and keyring management
  ldap_client.py     # LdapClient class (connect, search, CRUD)
  formatter.py       # Output formatting (text, JSON, YAML)
  exceptions.py      # Exception hierarchy
tests/               # Unit tests (pytest + hypothesis)
docs/                # This documentation
```

### Adding a new subcommand

1. Add the subparser in `build_parser()` in `cli.py`
2. Create a `_handle_<command>()` function
3. Add dispatch in `main()`
4. Add corresponding method(s) to `LdapClient` if needed
5. Add tests in `tests/test_cli.py`
6. Update this documentation
7. Add changelog entry under `[Unreleased]`
