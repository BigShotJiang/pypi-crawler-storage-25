"""
ukgeo command-line interface.

Usage examples:
    ukgeo geocode "M62 Junction 26"
    ukgeo geocode locations.csv --output results.csv
    ukgeo geocode locations.csv --output results.csv --domain road_safety
    ukgeo geocode locations.csv --column address --output results.csv
    ukgeo geocode locations.csv --max-level 3
    ukgeo info
"""

import argparse
import sys
import time
import warnings
from pathlib import Path

warnings.filterwarnings("ignore", category=UserWarning, module="requests")
warnings.filterwarnings(
    "ignore",
    message="Unable to find acceptable character detection dependency.*",
    category=Warning,
    module="requests",
)


def cmd_geocode(args) -> int:
    """Geocode a single string or a CSV file."""
    from ukgeo import Geocoder

    # Load domain qualifier config if specified
    extra_qualifiers = []
    if args.domain:
        import yaml

        domain_path = Path(__file__).parent.parent / "config" / f"domain_{args.domain}.yaml"
        if not domain_path.exists():
            print(f"Error: domain config not found: {domain_path}", file=sys.stderr)
            return 1
        with open(domain_path) as f:
            cfg = yaml.safe_load(f)
        extra_qualifiers = cfg.get("extra_qualifiers", [])

    geo = Geocoder(
        max_level=args.max_level,
        extra_qualifiers=extra_qualifiers or None,
    )

    # --- Single string mode ---
    if not args.input.endswith(".csv") and not Path(args.input).exists():
        result = geo.geocode(args.input)
        if result.resolved:
            print(f"lat:        {result.lat}")
            print(f"lon:        {result.lon}")
            print(f"confidence: {result.confidence}")
            print(f"interpreted:{result.interpreted_as}")
            print(f"level:      {result.level_resolved}")
            print(f"notes:      {result.notes}")
        else:
            print(f"Unresolved: {result.notes}", file=sys.stderr)
            return 1
        return 0

    # --- CSV file mode ---
    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: input file not found: {input_path}", file=sys.stderr)
        return 1

    import polars as pl

    df = pl.read_csv(input_path)

    # Detect column
    col = args.column
    if col is None:
        # Auto-detect: first string column
        str_cols = [c for c, t in zip(df.columns, df.dtypes) if str(t) == "String"]
        if not str_cols:
            print("Error: no string column found. Use --column to specify.", file=sys.stderr)
            return 1
        col = str_cols[0]
        print(f"Auto-detected input column: '{col}'", file=sys.stderr)

    if col not in df.columns:
        print(f"Error: column '{col}' not found. Available: {df.columns}", file=sys.stderr)
        return 1

    inputs = df[col].to_list()
    print(f"Geocoding {len(inputs)} rows from '{col}'...", file=sys.stderr)

    t0 = time.time()
    results_df = geo.geocode_batch(inputs, show_progress=True)
    elapsed = time.time() - t0

    # Join results back to original df
    # Drop any geocoder output columns already present in the source CSV
    # (e.g. if the CSV was previously geocoded or has lat/lon columns)
    GEOCODER_COLS = ["lat", "lon", "confidence", "level_resolved",
                     "interpreted_as", "match_type", "candidates_considered", "notes"]
    df_clean = df.drop([c for c in GEOCODER_COLS if c in df.columns])
    output_df = pl.concat([df_clean, results_df.drop("input")], how="horizontal")

    # Output
    output_path = Path(args.output) if args.output else input_path.with_suffix(".geocoded.csv")
    output_df.write_csv(output_path)

    resolved = results_df["lat"].drop_nulls().len()
    print(f"\nDone in {elapsed:.1f}s", file=sys.stderr)
    resolved_pct = 100 * resolved / max(len(inputs), 1)
    print(f"Resolved:   {resolved}/{len(inputs)} ({resolved_pct:.1f}%)", file=sys.stderr)
    print(f"Output:     {output_path}", file=sys.stderr)

    return 0


def cmd_info(args) -> int:
    """Print info about the current ukgeo installation and data."""
    from ukgeo import __version__
    from ukgeo.level3_os_names import _get_api_key
    from ukgeo.lookup import ALIASES_CSV, DEFAULT_PARQUET, JUNCTIONS_PARQUET, OSM_ROADS_PARQUET

    print(f"ukgeo {__version__}")
    print()
    print("Data files:")

    files = [
        ("OS Open Names", DEFAULT_PARQUET),
        ("OS Open Roads junctions", JUNCTIONS_PARQUET),
        ("OSM roads (B-roads)", OSM_ROADS_PARQUET),
    ]

    for label, path in files:
        if path.exists():
            size_mb = path.stat().st_size / (1 << 20)
            size_str = (
                f"{size_mb:.1f} MB"
                if size_mb >= 1
                else f"{path.stat().st_size / 1024:.0f} KB"
            )
            print(f"  ✓ {label:<30} {path.name} ({size_str})")
        else:
            print(f"  ✗ {label:<30} not found — run download script")

    alias_count = 0
    if ALIASES_CSV.exists():
        try:
            import polars as pl

            alias_count = (
                pl.read_csv(ALIASES_CSV, comment_prefix="#")
                .with_columns(pl.col("lat").cast(pl.Utf8).alias("lat_text"))
                .filter(pl.col("lat_text").str.len_chars() > 0)
                .height
            )
        except Exception:
            alias_count = 0
    print(f"  Infrastructure aliases: {alias_count} entries")

    print()
    api_key = _get_api_key()
    print(f"OS Names API key: {'set' if api_key else 'not set (Level 3 disabled)'}")
    print()
    print("Pipeline levels available:")
    print("  Level 1 — regex + postcodes.io     always")
    level2_status = "yes" if DEFAULT_PARQUET.exists() else "no — download OS Open Names"
    level3_status = "yes" if api_key else "no — set OS_API_KEY in .env"
    print(f"  Level 2 — OS Names parquet         {level2_status}")
    print(f"  Level 3 — OS Names API             {level3_status}")
    print("  Level 4 — Ollama LLM               not implemented")

    return 0


def cmd_setup(args) -> int:
    """Download ukgeo data from Kaggle."""
    print("ukgeo setup — downloading data from Kaggle")
    print()

    data_dir = Path(__file__).parent.parent / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    out_path = data_dir / "ukgeo_data.parquet"

    if out_path.exists() and not args.force:
        print(f"✓ Data already present: {out_path}")
        print("  Use --force to re-download.")
        return 0

    try:
        import kaggle

        print("Downloading via Kaggle API...")
        kaggle.api.authenticate()
        kaggle.api.dataset_download_files(
            "thomassimm/ukgeo-combined-dataset",
            path=str(data_dir),
            unzip=True,
            quiet=False,
        )
        print(f"✓ Downloaded to {out_path}")
        return 0
    except ImportError:
        pass
    except Exception as e:
        print(f"Kaggle API failed: {e}")

    print("Downloading via direct URL...")
    print("(For faster downloads, install the Kaggle CLI: pip install kaggle)")
    print()

    kaggle_url = (
        "https://www.kaggle.com/api/v1/datasets/download/"
        "thomassimm/ukgeo-combined-dataset/ukgeo_data.parquet"
    )

    try:
        import base64
        import json

        import httpx

        kaggle_json = Path.home() / ".kaggle" / "kaggle.json"
        headers = {}
        if kaggle_json.exists():
            creds = json.loads(kaggle_json.read_text())
            token = base64.b64encode(
                f"{creds['username']}:{creds['key']}".encode()
            ).decode()
            headers["Authorization"] = f"Basic {token}"

        with httpx.stream(
            "GET",
            kaggle_url,
            headers=headers,
            follow_redirects=True,
            timeout=300,
        ) as r:
            if r.status_code == 401:
                print("Authentication required. Please either:")
                print("  1. Install kaggle CLI: pip install kaggle")
                print("  2. Get API token from https://www.kaggle.com/settings")
                print("  3. Save to ~/.kaggle/kaggle.json")
                print()
                print("Or download manually from:")
                print("  https://www.kaggle.com/datasets/thomassimm/ukgeo-combined-dataset")
                print(f"  and place ukgeo_data.parquet in: {data_dir}")
                return 1

            r.raise_for_status()
            total = int(r.headers.get("content-length", 0))
            received = 0

            with open(out_path, "wb") as f:
                for chunk in r.iter_bytes(chunk_size=1 << 20):
                    f.write(chunk)
                    received += len(chunk)
                    if total:
                        pct = received / total * 100
                        mb = received / (1 << 20)
                        print(f"\r  {pct:.1f}% ({mb:.1f} MB)", end="", flush=True)
            print()

        print(f"✓ Downloaded to {out_path}")
        return 0

    except Exception as e:
        print(f"Download failed: {e}")
        print()
        print("Please download manually from:")
        print("  https://www.kaggle.com/datasets/thomassimm/ukgeo-combined-dataset")
        print(f"  and place ukgeo_data.parquet in: {data_dir}")
        return 1


def cmd_plot(args) -> int:
    """Generate an HTML map from a geocoded CSV."""
    try:
        import folium  # noqa: F401
    except ImportError:
        print("Error: folium not installed. Run: pip install folium", file=sys.stderr)
        return 1

    import polars as pl

    from ukgeo.maps import plot_results

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: file not found: {input_path}", file=sys.stderr)
        return 1

    df = pl.read_csv(input_path)
    required = ["lat", "lon"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        print(
            f"Error: missing columns {missing}. "
            "Run ukgeo geocode first to add lat/lon columns.",
            file=sys.stderr,
        )
        return 1

    output_path = Path(args.output) if args.output else input_path.with_suffix(".html")
    plot_results(df, output_path=output_path)
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="ukgeo",
        description="UK location free-text geocoder",
    )
    parser.add_argument("--version", action="version", version="%(prog)s 0.4.1")
    sub = parser.add_subparsers(dest="command", required=True)

    # --- geocode subcommand ---
    geo_p = sub.add_parser("geocode", help="Geocode a string or CSV file")
    geo_p.add_argument(
        "input",
        help="Location string (e.g. 'M62 Junction 26') or path to a CSV file",
    )
    geo_p.add_argument(
        "--output", "-o",
        help="Output CSV path (default: input.geocoded.csv)",
    )
    geo_p.add_argument(
        "--column", "-c",
        help=(
            "Column name in CSV containing location strings "
            "(default: auto-detect first string column)"
        ),
    )
    geo_p.add_argument(
        "--domain", "-d",
        help="Domain config to load (e.g. 'road_safety' loads config/domain_road_safety.yaml)",
    )
    geo_p.add_argument(
        "--max-level", "-l",
        type=int,
        default=2,
        choices=[1, 2, 3],
        help="Maximum pipeline level to use (default: 2; use 3 to enable OS Names API fallback)",
    )
    geo_p.set_defaults(func=cmd_geocode)

    # --- info subcommand ---
    info_p = sub.add_parser("info", help="Show ukgeo installation status")
    info_p.set_defaults(func=cmd_info)

    # --- setup subcommand ---
    setup_p = sub.add_parser("setup", help="Download ukgeo data from Kaggle")
    setup_p.add_argument(
        "--force",
        action="store_true",
        help="Re-download even if data already exists",
    )
    setup_p.set_defaults(func=cmd_setup)

    # --- plot subcommand ---
    plot_p = sub.add_parser("plot", help="Generate an HTML map from a geocoded CSV")
    plot_p.add_argument("input", help="Path to geocoded CSV (must have lat/lon columns)")
    plot_p.add_argument("--output", "-o", help="Output HTML path (default: input.html)")
    plot_p.set_defaults(func=cmd_plot)

    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
