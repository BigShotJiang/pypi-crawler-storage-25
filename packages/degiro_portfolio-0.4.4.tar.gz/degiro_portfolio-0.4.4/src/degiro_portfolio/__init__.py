"""Stock price visualization application."""
__version__ = "0.4.4"
