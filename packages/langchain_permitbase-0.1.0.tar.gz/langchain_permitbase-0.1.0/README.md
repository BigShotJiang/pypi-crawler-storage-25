# langchain-permitbase

LangChain toolkit for [PermitBase](https://permitbase.org) — the U.S. residential building permit data API.

45 years of history (1980–present) · Place-level · SF/MF differentiated · All 50 states + DC

## Installation

```bash
pip install langchain-permitbase
```

## Quick Start

```python
from langchain_permitbase import PermitBaseToolkit

# Get a free key at https://permitbase.org
toolkit = PermitBaseToolkit(api_key="pb_live_your_key")
tools = toolkit.get_tools()

# Pass to any LangChain agent
from langchain.agents import AgentExecutor, create_openai_tools_agent
agent = create_openai_tools_agent(llm, tools, prompt)
```

Or use the convenience function:

```python
from langchain_permitbase import get_permitbase_tools

tools = get_permitbase_tools(api_key="pb_live_your_key")
```

## Tools Included

| Tool | Description |
|------|-------------|
| `annual_permits` | Year-by-year permit totals with SF/MF split and cycle labels |
| `permit_trends` | Time-series with 5-year rolling average and YoY change |
| `permit_rankings` | Top places ranked by volume or MF share |
| `permit_cycles` | 11 housing cycles (1980–present) with peak/trough analysis |
| `state_permit_summary` | All 50 states + DC aggregated with peak year |

## Environment Variable

Instead of passing `api_key` directly, set:

```bash
export PERMITBASE_API_KEY=pb_live_your_key
```

## Links

- [API Documentation](https://permitbase-api-production.up.railway.app/docs)
- [Website](https://permitbase.org)
- [Hugging Face Dataset](https://huggingface.co/datasets/thanna94/us-building-permits)
- [GitHub](https://github.com/thanna94/permitbase)
