"""
LangChain tools for the PermitBase API — U.S. residential building permit data.

45 years of history (1980–present), place-level, SF/MF differentiated.
Get a free API key at https://permitbase.org
"""

import os
from typing import Optional, Type
import requests
from langchain.tools import BaseTool
from pydantic import BaseModel, Field


API_BASE = os.getenv("PERMITBASE_API_BASE", "https://permitbase-api-production.up.railway.app")


def _call(api_key: str, endpoint: str, params: dict) -> dict:
    params = {k: v for k, v in params.items() if v is not None}
    headers = {"X-API-Key": api_key}
    r = requests.get(f"{API_BASE}{endpoint}", params=params, headers=headers, timeout=20)
    r.raise_for_status()
    return r.json()


# ── Tool Input Schemas ────────────────────────────────────────────────────────

class AnnualPermitsInput(BaseModel):
    state: Optional[str] = Field(None, description="State name, 2-letter abbreviation (e.g. TX), or FIPS code")
    place: Optional[str] = Field(None, description="City/town name, partial match")
    year_from: int = Field(1980, description="Start year (1980–2024)")
    year_to: int = Field(2024, description="End year (1980–2024)")

class TrendsInput(BaseModel):
    state: Optional[str] = Field(None, description="State name, abbreviation, or FIPS code")
    place: Optional[str] = Field(None, description="City/town partial name")
    metric: str = Field("total", description="'total', 'sf', or 'mf'")
    year_from: int = Field(1980)
    year_to: int = Field(2024)

class RankingsInput(BaseModel):
    state: Optional[str] = Field(None, description="Limit to one state (optional)")
    year_from: int = Field(1980)
    year_to: int = Field(2024)
    ranked_by: str = Field("total", description="'total', 'sf', 'mf', or 'mf_pct'")
    limit: int = Field(25)

class CyclesInput(BaseModel):
    state: Optional[str] = Field(None, description="State for state-level analysis (optional)")

class StatesInput(BaseModel):
    year_from: int = Field(1980)
    year_to: int = Field(2024)


# ── Tool Implementations ──────────────────────────────────────────────────────

class AnnualPermitsTool(BaseTool):
    name: str = "annual_permits"
    description: str = (
        "Get annual U.S. residential building permit totals. "
        "Returns year-by-year SF and MF unit counts with YoY change and cycle context. "
        "Covers 1980-present. Filter by state, county, or city."
    )
    args_schema: Type[BaseModel] = AnnualPermitsInput
    api_key: str = ""

    def _run(self, state=None, place=None, year_from=1980, year_to=2024, **kw):
        return _call(self.api_key, "/v1/permits/annual",
                     {"state": state, "place": place, "year_from": year_from, "year_to": year_to})

    async def _arun(self, **kw):
        raise NotImplementedError("Use sync mode")


class TrendsTool(BaseTool):
    name: str = "permit_trends"
    description: str = (
        "Get a time-series permit trend for a specific geography. "
        "Returns annual values with 5-year rolling average and YoY change."
    )
    args_schema: Type[BaseModel] = TrendsInput
    api_key: str = ""

    def _run(self, state=None, place=None, metric="total", year_from=1980, year_to=2024, **kw):
        return _call(self.api_key, "/v1/permits/trends",
                     {"state": state, "place": place, "metric": metric,
                      "year_from": year_from, "year_to": year_to})

    async def _arun(self, **kw):
        raise NotImplementedError


class RankingsTool(BaseTool):
    name: str = "permit_rankings"
    description: str = (
        "Get top places ranked by permit volume or multifamily share. "
        "Use for highest-activity markets, top MF markets, state-level rankings."
    )
    args_schema: Type[BaseModel] = RankingsInput
    api_key: str = ""

    def _run(self, state=None, year_from=1980, year_to=2024, ranked_by="total", limit=25, **kw):
        return _call(self.api_key, "/v1/permits/rankings",
                     {"state": state, "year_from": year_from, "year_to": year_to,
                      "ranked_by": ranked_by, "limit": limit})

    async def _arun(self, **kw):
        raise NotImplementedError


class CyclesTool(BaseTool):
    name: str = "permit_cycles"
    description: str = (
        "Housing market cycle analysis - 11 cycles 1980-present. "
        "Shows avg volume per cycle, peaks, troughs, and where we are now."
    )
    args_schema: Type[BaseModel] = CyclesInput
    api_key: str = ""

    def _run(self, state=None, **kw):
        return _call(self.api_key, "/v1/permits/cycles", {"state": state})

    async def _arun(self, **kw):
        raise NotImplementedError


class StateSummaryTool(BaseTool):
    name: str = "state_permit_summary"
    description: str = (
        "Permit totals aggregated by state. SF, MF, total, MF%, and peak year "
        "for all 50 states + DC."
    )
    args_schema: Type[BaseModel] = StatesInput
    api_key: str = ""

    def _run(self, year_from=1980, year_to=2024, **kw):
        return _call(self.api_key, "/v1/permits/states",
                     {"year_from": year_from, "year_to": year_to})

    async def _arun(self, **kw):
        raise NotImplementedError


# ── Toolkit ───────────────────────────────────────────────────────────────────

class PermitBaseToolkit:
    """
    PermitBase LangChain Toolkit — all permit data tools in one bundle.

    Usage:
        toolkit = PermitBaseToolkit(api_key="pb_live_your_key")
        tools = toolkit.get_tools()
        # Pass tools to any LangChain agent
    """

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv("PERMITBASE_API_KEY", "")
        if not self.api_key:
            raise ValueError(
                "PermitBase API key required. Pass api_key= or set "
                "PERMITBASE_API_KEY env var. Get a free key at https://permitbase.org"
            )

    def get_tools(self) -> list[BaseTool]:
        """Return all PermitBase tools configured with this API key."""
        kwargs = {"api_key": self.api_key}
        return [
            AnnualPermitsTool(**kwargs),
            TrendsTool(**kwargs),
            RankingsTool(**kwargs),
            CyclesTool(**kwargs),
            StateSummaryTool(**kwargs),
        ]


def get_permitbase_tools(api_key: Optional[str] = None) -> list[BaseTool]:
    """Convenience function to get all PermitBase tools."""
    return PermitBaseToolkit(api_key=api_key).get_tools()
