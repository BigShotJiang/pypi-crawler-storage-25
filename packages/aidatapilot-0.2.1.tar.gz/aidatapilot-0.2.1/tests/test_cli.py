import click
from click.testing import CliRunner
from datapilot.cli.main import cli
from pathlib import Path

def test_cli_info():
    runner = CliRunner()
    result = runner.invoke(cli, ["info"])
    assert result.exit_code == 0
    assert "basic_clean" in result.output
    assert "normalize_columns" in result.output

def test_cli_profile(tmp_path):
    csv_path = tmp_path / "test.csv"
    import pandas as pd
    pd.DataFrame({"A": [1, 2], "B": [3, 4]}).to_csv(csv_path, index=False)
    
    runner = CliRunner()
    result = runner.invoke(cli, ["profile", str(csv_path)])
    assert result.exit_code == 0
    assert "Rows     : 2" in result.output
    assert "A" in result.output

