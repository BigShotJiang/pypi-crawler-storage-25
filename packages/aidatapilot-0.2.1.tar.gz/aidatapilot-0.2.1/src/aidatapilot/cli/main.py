"""
aidatapilot CLI 💻
-----------------
Command-line interface for the data automation engine.
"""

from __future__ import annotations

import click

from aidatapilot.core.api import analyze_dataset as _core_analyze
from aidatapilot.core.api import auto_clean as _core_clean
from aidatapilot.simple.ml import auto_ml_prep as _core_ml


@click.group()
def cli():
    """aidatapilot — Lightweight Intelligent Data Automation Engine."""
    pass


@cli.command()
@click.argument("source", type=click.Path(exists=True))
@click.option("--output", "-o", help="Output file path (CSV/Excel/Parquet).")
@click.option("--template", "-t", default="basic_clean", help="Template to use.")
def clean(source, output, template):
    """Clean, repair, and normalize a dataset."""
    import logging
    logger = logging.getLogger("aidatapilot")
    logger.info(f"CLI: Cleaning {source} using '{template}' template...")
    result = _core_clean(source, output, template=template)
    if result.success:
        click.echo(f"Success: {result.rows_out} rows processed.")
    else:
        click.echo(f"Error: {result.error}")


@cli.command()
@click.argument("source", type=click.Path(exists=True))
def analyze(source):
    """Deep structural and statistical profiling of a dataset."""
    _core_analyze(source)


@cli.command()
@click.argument("source", type=click.Path(exists=True))
@click.option("--output", "-o", help="Output file path.")
def ml_prep(source, output):
    """Prepare raw data for ML models."""
    result = _core_ml(source, output)
    if result.success:
        click.echo(f"ML Preprocessing Success. {result.rows_out} rows generated.")
    else:
        click.echo(f"Failed: {result.error}")

if __name__ == "__main__":
    cli()
