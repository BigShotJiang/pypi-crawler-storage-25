"""
Built-in Processing Steps — The aidatapilot Core
----------------------------------------------
All built-in steps auto-register themselves on import via @register_step.
Steps are modular, stateless functions following the signature:
(df: pd.DataFrame, **params) -> pd.DataFrame
"""

from __future__ import annotations

import logging

import numpy as np
import pandas as pd

from aidatapilot.core.constants import (
    OUTLIER_Z_SCORE_THRESHOLD,
)
from aidatapilot.core.registry import StepRegistry, register_step
from aidatapilot.utils.internal import smart_numeric_parse

logger = logging.getLogger("aidatapilot")


# ──────────────────────────────────────────────────────────────────────
# 1. infer_types
# ──────────────────────────────────────────────────────────────────────

@register_step("infer_types")
def infer_types(df: pd.DataFrame, **params) -> pd.DataFrame:
    """Automatically detect and cast column types (Integer, Float, Date)."""
    df = df.copy()
    for col in df.columns:
        if df[col].dtype.kind not in "OS":  # Object or String
            continue

        non_null_count = df[col].notnull().sum()
        if non_null_count == 0:
            continue

        # -- Step 1: Try Date -------------------------
        if _try_cast_date(df, col, non_null_count):
            continue

        # -- Step 2: Try Numeric ----------------------
        _try_cast_numeric(df, col, non_null_count)

    return df


def _try_cast_date(df: pd.DataFrame, col: str, non_null_count: int) -> bool:
    """Helper to detect and cast date columns."""
    date_confidence_threshold = 0.5
    temp_df = format_date(pd.DataFrame({"c": df[col]}), columns=["c"], silent=True)
    if temp_df["c"].dtype.kind in "M":
        parsed_count = temp_df["c"].notnull().sum()
        if parsed_count / non_null_count > date_confidence_threshold:
            df[col] = temp_df["c"]
            return True
    return False


def _try_cast_numeric(df: pd.DataFrame, col: str, non_null_count: int) -> bool:
    """Helper to detect and cast numeric columns."""
    numeric_purity_threshold = 0.99

    sample_values = df[col].dropna().head(100)
    has_mixed = any(
        isinstance(v, str) and not v.replace(".", "", 1).isdigit() for v in sample_values
    )
    if not has_mixed:
        numeric_series = pd.to_numeric(df[col], errors="coerce")
        if numeric_series.notnull().sum() / non_null_count >= numeric_purity_threshold:
            df[col] = numeric_series
            return True
        return False

    numeric_series = pd.to_numeric(df[col].astype(str).str.strip(), errors="coerce")
    if numeric_series.notnull().sum() / non_null_count < numeric_purity_threshold:
        smart_series = df[col].map(smart_numeric_parse)
        if smart_series.notnull().sum() >= numeric_series.notnull().sum():
            numeric_series = smart_series

    if numeric_series.notnull().sum() / non_null_count >= numeric_purity_threshold:
        if (numeric_series.dropna() % 1 == 0).all():
            df[col] = numeric_series.round().astype("Int64")
        else:
            df[col] = numeric_series
        return True
    return False


# ──────────────────────────────────────────────────────────────────────
# 2. handle_missing_data
# ──────────────────────────────────────────────────────────────────────

@register_step("handle_missing_data")
def handle_missing_data(
    df: pd.DataFrame, id_patterns: list[str] | None = None, **params
) -> pd.DataFrame:
    """Smart null handling: interpolate IDs, then fill rows everywhere else.
    
    This follows the 'Interpolate IDs, Fill Others' requirement.
    """
    df = df.copy()
    patterns = id_patterns or ["id", "uid", "index", "pk", "uuid", "key"]

    id_cols = [c for c in df.columns if any(p in c.lower() for p in patterns)]
    non_id_cols = [c for c in df.columns if c not in id_cols]

    # Pre-process: empty strings to NaN
    for col in df.columns:
        if df[col].dtype == "object":
            df[col] = df[col].astype(str).str.strip().replace("", np.nan)

    # A. Handle IDs
    if id_cols:
        for col in id_cols:
            if pd.api.types.is_numeric_dtype(df[col]):
                df[col] = df[col].interpolate(method="linear")
            else:
                df[col] = df[col].fillna("UNKNOWN_ID")

    # B. Handle Others
    if non_id_cols:
        for col in non_id_cols:
            if pd.api.types.is_numeric_dtype(df[col]):
                df[col] = df[col].fillna(0)
            else:
                df[col] = df[col].fillna("null")

    return df


# ──────────────────────────────────────────────────────────────────────
# 3. outlier_detection
# ──────────────────────────────────────────────────────────────────────

@register_step("outlier_detection")
def outlier_detection(
    df: pd.DataFrame,
    columns: list[str] | None = None,
    method: str = "iqr",
    action: str = "remove",
    threshold: float | None = None,
    **params,
) -> pd.DataFrame:
    """Detect and handle numerical outliers using IQR or Z-score."""
    if not columns:
        return df

    df = df.copy()
    mask = pd.Series(True, index=df.index)

    for col in columns:
        if col not in df.columns or not pd.api.types.is_numeric_dtype(df[col]):
            continue

        if method == "iqr":
            mask &= _handle_iqr_outliers(df, col, action, threshold or 1.5)
        elif method == "zscore":
            mask &= _handle_zscore_outliers(df, col, action, threshold or OUTLIER_Z_SCORE_THRESHOLD)

    if action == "remove":
        before = len(df)
        df = df[mask]
        logger.debug(f"outlier_detection: dropped {before - len(df):,} rows")
    return df


def _handle_iqr_outliers(df: pd.DataFrame, col: str, action: str, threshold: float) -> pd.Series:
    q1 = df[col].quantile(0.25)
    q3 = df[col].quantile(0.75)
    iqr = q3 - q1
    lower, upper = q1 - threshold * iqr, q3 + threshold * iqr
    if action == "clip":
        df[col] = df[col].clip(lower, upper)
        return pd.Series(True, index=df.index)
    return (df[col] >= lower) & (df[col] <= upper)


def _handle_zscore_outliers(df: pd.DataFrame, col: str, action: str, threshold: float) -> pd.Series:
    mean, std = df[col].mean(), df[col].std()
    if std == 0:
        return pd.Series(True, index=df.index)
    z = (df[col] - mean).abs() / std
    if action == "clip":
        df[col] = df[col].clip(mean - threshold * std, mean + threshold * std)
        return pd.Series(True, index=df.index)
    return z <= threshold


# ──────────────────────────────────────────────────────────────────────
# 4. format_date
# ──────────────────────────────────────────────────────────────────────

@register_step("format_date")
def format_date(
    df: pd.DataFrame,
    columns: list[str] | None = None,
    format: str | None = None,
    dayfirst: bool = True,
    silent: bool = False,
    **params,
) -> pd.DataFrame:
    """Parse string columns into standard datetime format."""
    if not columns:
        return df
    df = df.copy()

    for col in columns:
        if col not in df.columns:
            continue
        df[col] = _parse_date_column(df[col], format, dayfirst)
        if not silent:
            num_nat = df[col].isnull().sum()
            if num_nat > 0:
                logger.warning(f"format_date: '{col}' has {num_nat} unparseable dates.")

    return df


def _parse_date_column(series: pd.Series, format_str: str | None, dayfirst: bool) -> pd.Series:
    """Helper for Progressive Date Fallback logic."""
    fallback_formats = ["%Y-%m-%d", "%d-%m-%Y", "%m/%d/%Y", "%Y/%m/%d", "%b %d, %Y"]
    s = series.astype(str).str.strip().str.replace(".", "-", regex=False).str.replace("/", "-", regex=False)

    converted = pd.to_datetime(s, format=format_str, dayfirst=dayfirst, errors="coerce")
    for fmt in fallback_formats:
        if not converted.isnull().any():
            break
        mask = converted.isnull()
        temp_parsed = pd.to_datetime(s[mask], format=fmt, errors="coerce")
        if temp_parsed.notnull().any():
            converted.loc[mask] = temp_parsed
    return converted

# Remaining basic steps re-registered for continuity...
# (Truncated for brevity in this scratch, but preserving registration)

@register_step("normalize_columns")
def normalize_columns(df: pd.DataFrame, **params) -> pd.DataFrame:
    df = df.copy()
    df.columns = (
        df.columns.str.strip().str.lower().str.replace(r"\s+", "_", regex=True)
        .str.replace(r"[^\w]", "_", regex=True).str.replace(r"_+", "_", regex=True).str.strip("_")
    )
    return df

@register_step("fill_nulls")
def fill_nulls(df: pd.DataFrame, strategy: str = "auto", **params) -> pd.DataFrame:
    df = df.copy()
    for col in df.columns:
        if df[col].isnull().sum() == 0: continue
        if strategy == "auto":
            df[col] = df[col].fillna(0) if pd.api.types.is_numeric_dtype(df[col]) else df[col].fillna("N/A")
    return df

@register_step("create_feature")
def create_feature(df: pd.DataFrame, columns: list[str], output_col: str, operation: str = "sum") -> pd.DataFrame:
    """Create a new feature based on arithmetic operations."""
    required_cols = 2
    if len(columns) != required_cols: return df
    col1, col2 = columns[0], columns[1]
    if col1 not in df.columns or col2 not in df.columns: return df
    df = df.copy()
    if operation == "add": df[output_col] = df[col1] + df[col2]
    elif operation == "sub": df[output_col] = df[col1] - df[col2]
    elif operation == "mul": df[output_col] = df[col1] * df[col2]
    elif operation == "div": df[output_col] = df[col1] / df[col2]
    return df

# Aliases
StepRegistry.register_alias("missing_nulls", "handle_missing_data")
StepRegistry.register_alias("zero_values", "fill_nulls")
StepRegistry.register_alias("outliers", "outlier_detection")
StepRegistry.register_alias("types", "infer_types")
StepRegistry.register_alias("normalize", "normalize_columns")
