"""
Advanced Analytics Analyzer
--------------------------
Core logic for automated EDA and Health Scoring.
"""

from __future__ import annotations

from typing import Any

import pandas as pd

from aidatapilot.core.constants import OUTLIER_Z_SCORE_THRESHOLD


class AdvancedAnalyzer:
    """Exploratory Data Analysis (EDA) Engine."""

    def __init__(self, df: pd.DataFrame):
        self.df = df

    def profile(self) -> dict[str, Any]:
        """Generate a complete statistical profile of the dataset."""
        rows, cols = self.df.shape
        numeric_df = self.df.select_dtypes(include=["number"])
        summary = numeric_df.describe().to_dict() if not numeric_df.empty else {}
        correlation = numeric_df.corr().to_dict() if not numeric_df.empty else {}
        cat_df = self.df.select_dtypes(exclude=["number"])
        cardinality = {c: self.df[c].nunique() for c in cat_df.columns}
        null_rates = (self.df.isnull().mean() * 100).to_dict()
        score, insights = self.calculate_health_score()

        return {
            "shape": {"rows": rows, "cols": cols},
            "summary": summary,
            "correlation": correlation,
            "cardinality": cardinality,
            "null_rates": null_rates,
            "health_score": score,
            "insights": insights,
        }

    def calculate_health_score(self) -> tuple[int, list[str]]:
        """Proprietary 0-100 Dataset Health Scoring logic."""
        max_missing_penalty = 30
        max_outlier_penalty = 20
        outlier_tolerance = 0.01
        outlier_skew_factor = 500
        max_dup_penalty = 10
        score_base = 100
        percent_factor = 100

        score = score_base
        insights = []

        # A. Missing Data Penalty
        null_rate = self.df.isnull().mean().mean()
        if null_rate > 0:
            penalty = min(max_missing_penalty, int(null_rate * percent_factor))
            score -= penalty
            insights.append(f"Missing Data: {null_rate:.1%} of cells are empty (-{penalty} pts).")

        # B. Outlier Penalty
        numeric_df = self.df.select_dtypes(include=["number"])
        if not numeric_df.empty:
            outlier_rate = 0
            for col in numeric_df.columns:
                z_scores = (numeric_df[col] - numeric_df[col].mean()).abs() / numeric_df[col].std()
                outlier_rate += (z_scores > OUTLIER_Z_SCORE_THRESHOLD).mean()
            outlier_rate /= len(numeric_df.columns)

            if outlier_rate > outlier_tolerance:
                penalty = min(max_outlier_penalty, int(outlier_rate * outlier_skew_factor))
                score -= penalty
                insights.append(f"High Outliers: {outlier_rate:.1%} of numeric data is skewed (-{penalty} pts).")

        # C. Duplicate Penalty
        dup_rate = self.df.duplicated().mean()
        if dup_rate > 0:
            penalty = min(max_dup_penalty, int(dup_rate * percent_factor))
            score -= penalty
            insights.append(f"Duplicates Detected: {dup_rate:.1%} of rows are redundant (-{penalty} pts).")

        return max(0, score), insights
