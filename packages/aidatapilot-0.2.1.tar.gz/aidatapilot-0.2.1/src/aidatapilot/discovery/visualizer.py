"""
aidatapilot Health Visualizer 📊
-----------------------------
Graphical representation of Dataset Health Scoring.
"""

from __future__ import annotations

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

from aidatapilot.core.constants import HEALTH_SCORE_EXCELLENT_MIN, HEALTH_SCORE_GOOD_MIN


class HealthVisualizer:
    """Radial Gauge Visualizer for Dataset Health Scoring."""

    def __init__(self, df: pd.DataFrame):
        self.df = df
        sns.set_theme(style="white")

    def generate_report(self, score: int, save_path: str = "health_report.png") -> str:
        """Create a professional gauge chart for the health score."""
        _fig, ax = plt.subplots(figsize=(6, 6), subplot_kw={'projection': 'polar'})
        
        # Determine Color
        color = "#ff4b4b" # Red
        status = "NEEDS WORK"
        if score >= HEALTH_SCORE_EXCELLENT_MIN:
            color = "#00c853" # Green
            status = "EXCELLENT"
        elif score >= HEALTH_SCORE_GOOD_MIN:
            color = "#ff9100" # Orange
            status = "GOOD"

        # Background Track
        ax.barh(0, 2*np.pi, color="#f0f0f0", height=0.5)
        # Score Bar
        ax.barh(0, (score/100)*2*np.pi, color=color, height=0.5)

        ax.set_ylim(-1, 1)
        ax.set_xticks([])
        ax.set_yticks([])
        ax.spines['polar'].set_visible(False)

        plt.text(0, -0.1, f"{score}", ha='center', va='center', fontsize=50, fontweight='bold', color="#333")
        plt.text(0, -0.5, status, ha='center', va='center', fontsize=20, fontweight='bold', color=color)

        plt.savefig(save_path, bbox_inches='tight', dpi=150)
        plt.close()
        return save_path
