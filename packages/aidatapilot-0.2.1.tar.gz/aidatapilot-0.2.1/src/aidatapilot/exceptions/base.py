"""
aidatapilot Exceptions 🚨
-----------------------
Base classes for all package-specific errors.
"""

class AIDataPilotError(Exception):
    """Base exception for all aidatapilot errors."""
    pass

class PipelineError(AIDataPilotError):
    """Raised when the pipeline configuration or execution fails."""
    pass

class ConnectorError(AIDataPilotError):
    """Raised when a connector fails to read/write data."""
    pass

class TemplateError(AIDataPilotError):
    """Raised when a template is not found or is invalid."""
    pass

class ValidationError(AIDataPilotError):
    """Raised when data validation fails."""
    pass
