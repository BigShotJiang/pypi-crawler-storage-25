"""
aidatapilot - Lightweight Intelligent Data Automation Engine
==========================================================

The simplest way to automate your data pipelines.
"""

# Core Engine
from aidatapilot.core.api import analyze_dataset as analyze
from aidatapilot.core.pipeline import Pipeline as Pipeline
from aidatapilot.core.pipeline import PipelineResult as PipelineResult

# Simplified API (The Public Facade)
from aidatapilot.simple.analytics import auto_analytics as auto_analytics
from aidatapilot.simple.auto import auto_clean as auto_clean
from aidatapilot.simple.auto import auto_pilot as auto_pilot
from aidatapilot.simple.auto import auto_pipeline as auto_pipeline
from aidatapilot.simple.ml import auto_ml_prep as auto_ml_prep
from aidatapilot.simple.text import auto_text_prep as auto_text_prep

# Version
from aidatapilot.version import __version__ as __version__

__all__ = [
    "Pipeline",
    "PipelineResult",
    "__version__",
    "analyze",
    "auto_analytics",
    "auto_clean",
    "auto_ml_prep",
    "auto_pilot",
    "auto_pipeline",
    "auto_text_prep",
]
