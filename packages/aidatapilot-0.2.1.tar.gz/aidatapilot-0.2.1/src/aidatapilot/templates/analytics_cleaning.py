"""
aidatapilot Specialized Templates 📋
-------------------------------
Advanced step sequences for targeted workflows.
"""

from aidatapilot.core.registry import TemplateRegistry


class AnalyticsCleaningTemplate:
    """Blueprint for Professional Analytics."""
    name = "analytics_cleaning"
    steps = [
        "normalize_columns",
        "infer_types",
        "format_date",
        "handle_missing_data",
        "deduplicate",
        "outlier_detection"
    ]

class MLPreprocessTemplate:
    """Blueprint for Machine Learning preparation."""
    name = "ml_preprocess"
    steps = [
        "normalize", 
        "types", 
        "missing_nulls", 
        "outliers", 
        "encode_categorical", 
        "scale_numeric"
    ]

class LLMProcessingTemplate:
    """Blueprint for RAG/LLM preparation."""
    name = "llm_processing"
    steps = [
        "normalize", 
        "clean_text", 
        "chunk_text", 
        "generate_metadata"
    ]

# Self-registration
TemplateRegistry.register("analytics_cleaning", AnalyticsCleaningTemplate())
TemplateRegistry.register("ml_preprocess", MLPreprocessTemplate())
TemplateRegistry.register("llm_processing", LLMProcessingTemplate())
