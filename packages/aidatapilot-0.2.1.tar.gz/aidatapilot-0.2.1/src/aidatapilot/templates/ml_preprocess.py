"""
aidatapilot ML Preprocess Template 🤖
---------------------------------
Recommended for machine learning training pipelines.
"""

from aidatapilot.core.registry import TemplateRegistry


class MLPreprocessTemplate:
    """Blueprint for Machine Learning preparation."""
    name = "ml_preprocess"
    steps = [
        "normalize_columns", 
        "infer_types", 
        "handle_missing_data", 
        "outlier_detection", 
        "encode_categorical", 
        "scale_numeric"
    ]

# Self-registration
TemplateRegistry.register("ml_preprocess", MLPreprocessTemplate())
