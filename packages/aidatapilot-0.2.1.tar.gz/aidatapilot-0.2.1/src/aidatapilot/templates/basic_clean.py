"""
aidatapilot Basic Clean Template 🧼
-------------------------------
Recommended for general purpose data reparation.
"""

from aidatapilot.core.registry import TemplateRegistry


class BasicCleanTemplate:
    """Foundational cleaning blueprint."""
    name = "basic_clean"
    steps = [
        "normalize_columns",
        "infer_types",
        "handle_missing_data",
        "deduplicate"
    ]

# Self-registration
TemplateRegistry.register("basic_clean", BasicCleanTemplate())
