"""
aidatapilot LLM Processing Template 🧠
----------------------------------
Recommended for RAG/LLM preparation pipelines.
"""

from aidatapilot.core.registry import TemplateRegistry


class LLMProcessingTemplate:
    """Blueprint for RAG/LLM preparation."""
    name = "llm_processing"
    steps = [
        "normalize_columns", 
        "clean_text", 
        "chunk_text", 
        "generate_metadata"
    ]

# Self-registration
TemplateRegistry.register("llm_processing", LLMProcessingTemplate())
