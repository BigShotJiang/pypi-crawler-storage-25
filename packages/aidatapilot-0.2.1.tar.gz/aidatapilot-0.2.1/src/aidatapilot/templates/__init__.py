"""
aidatapilot Standard Templates 📋
-----------------------------
Predefined step sequences for common workflows.
"""

from aidatapilot.core.registry import TemplateRegistry


class BaseTemplate:
    """Base template definition."""
    name: str
    steps: list

# 1. basic_clean
TemplateRegistry.register("basic_clean", type("Template", (BaseTemplate,), {
    "name": "basic_clean",
    "steps": [
        "normalize_columns",
        "infer_types",
        "handle_missing_data",
        "deduplicate"
    ]
})())

# 2. analytics_cleaning
TemplateRegistry.register("analytics_cleaning", type("Template", (BaseTemplate,), {
    "name": "analytics_cleaning",
    "steps": [
        "normalize_columns",
        "infer_types",
        "format_date",
        "handle_missing_data",
        "deduplicate",
        "outlier_detection"
    ]
})())

# 3. ml_preprocess (Placeholder - will restore full file in next step)
TemplateRegistry.register("ml_preprocess", type("Template", (BaseTemplate,), {
    "name": "ml_preprocess",
    "steps": ["normalize", "types", "missing_nulls", "outliers", "encode_categorical", "scale_numeric"]
})())

# 4. llm_processing (Placeholder - will restore full file in next step)
TemplateRegistry.register("llm_processing", type("Template", (BaseTemplate,), {
    "name": "llm_processing",
    "steps": ["normalize", "clean_text", "chunk_text", "generate_metadata"]
})())
