"""
aidatapilot Core API 🚀
---------------------
Internal entry points for automated workflows.
"""

from __future__ import annotations

from typing import Any

import pandas as pd

from aidatapilot.core.boot import bootstrap
from aidatapilot.core.pipeline import Pipeline, PipelineResult
from aidatapilot.intelligence.analyzer import DatasetAnalyzer


def auto_clean(
    source: str | pd.DataFrame, 
    output: str | None = None, 
    template: str = "basic_clean", 
    **kwargs
) -> PipelineResult:
    """Core implementation of automated cleaning."""
    bootstrap()
    pipe = Pipeline(template=template)
    pipe.set_source(source)
    if output:
        pipe.set_output(type="file", path=str(output))
    return pipe.run()


def analyze_dataset(source: str | pd.DataFrame) -> Any:
    """Analyze a dataset and return its profile."""
    analyzer = DatasetAnalyzer(source)
    report = analyzer.profile()
    # Simple console printer for now
    print("\n--- Dataset Analysis ---")
    print(f"Shape: {report.rows} rows x {report.cols} cols")
    print(f"Type: {report.dataset_type}")
    print(f"Duplicates: {report.duplicates}")
    print(f"Target Hint: {report.target_col or 'None'}")
    return report

def auto_pilot(source: str | pd.DataFrame, output: str | None = None, **kwargs) -> PipelineResult:
    """Intelligence-driven cleaning."""
    from aidatapilot.intelligence.advisor import IntelligenceAdvisor
    advisor = IntelligenceAdvisor(source)
    recommendation = advisor._recommend_template()
    template = recommendation.get("template", "basic_clean")
    return auto_clean(source, output, template=template, **kwargs)
