"""
Orchestration Runtime
---------------------
Executes a compiled DAG of step nodes against a DataFrame.
Handles retry logic, parallel groups, and lifecycle state tracking.
"""

from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import pandas as pd

from aidatapilot.core.compiler import DAGNode
from aidatapilot.core.registry import StepRegistry
from aidatapilot.utils.logger import get_logger


class PipelineState(str, Enum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    SUCCESS = "SUCCESS"
    FAILED  = "FAILED"


@dataclass
class StepReport:
    """Execution report for a single step."""

    name: str
    success: bool
    duration_seconds: float
    rows_in: int
    rows_out: int
    rows_edited: int = 0
    warnings: list[str] = field(default_factory=list)
    error: str | None = None


@dataclass
class RuntimeResult:
    """Full execution result from the runtime."""

    state: PipelineState
    step_reports: list[StepReport]
    total_duration_seconds: float
    rows_in: int
    rows_out: int
    warnings: list[str]
    error: str | None = None
    _final_df: pd.DataFrame | None = field(default=None, repr=False, compare=False)


class PipelineRuntime:
    """Executes a compiled DAG of :class:`DAGNode` objects.

    Args:
        max_retries: Number of retry attempts on step failure. Default 1
            (means try once then retry once on failure).
        max_workers: Thread pool size for parallel step groups. Default 4.

    Usage::

        runtime = PipelineRuntime(max_retries=2)
        result = runtime.execute(df, nodes)
    """

    def __init__(self, max_retries: int = 1, max_workers: int = 4) -> None:
        self.max_retries = max_retries
        self.max_workers = max_workers
        self._logger = get_logger()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def execute(
        self, df: pd.DataFrame, nodes: list[DAGNode]
    ) -> RuntimeResult:
        """Execute all DAG nodes sequentially (with parallel groups).

        Args:
            df: Input DataFrame.
            nodes: Ordered list of :class:`DAGNode` to execute.

        Returns:
            :class:`RuntimeResult` with per-step stats and final state.
        """
        self._logger.info(
            f"[bold cyan]aidatapilot Runtime[/] starting - "
            f"{len(nodes)} step(s) | {len(df):,} rows"
        )

        start = time.perf_counter()
        step_reports: list[StepReport] = []
        warnings: list[str] = []
        rows_in = len(df)

        # Group consecutive parallel nodes; sequential nodes are solo groups
        groups = self._build_groups(nodes)

        for group in groups:
            if len(group) == 1:
                df, report = self._run_node(df, group[0])
                step_reports.append(report)
                warnings.extend(report.warnings)
                if not report.success:
                    return RuntimeResult(
                        state=PipelineState.FAILED,
                        step_reports=step_reports,
                        total_duration_seconds=time.perf_counter() - start,
                        rows_in=rows_in,
                        rows_out=len(df),
                        warnings=warnings,
                        error=report.error,
                    )
            else:
                # Parallel execution — each branch gets a *copy* of df
                df, group_reports = self._run_parallel_group(df, group)
                step_reports.extend(group_reports)
                for r in group_reports:
                    warnings.extend(r.warnings)
                    if not r.success:
                        return RuntimeResult(
                            state=PipelineState.FAILED,
                            step_reports=step_reports,
                            total_duration_seconds=time.perf_counter() - start,
                            rows_in=rows_in,
                            rows_out=len(df),
                            warnings=warnings,
                            error=r.error,
                        )

        total = time.perf_counter() - start
        self._logger.success(
            f"Pipeline completed in [bold]{total:.2f}s[/] "
            f"- {rows_in:,} -> {len(df):,} rows"
        )
        return RuntimeResult(
            state=PipelineState.SUCCESS,
            step_reports=step_reports,
            total_duration_seconds=total,
            rows_in=rows_in,
            rows_out=len(df),
            warnings=warnings,
            _final_df=df,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _run_node(
        self, df: pd.DataFrame, node: DAGNode
    ) -> tuple[pd.DataFrame, StepReport]:
        step_fn = StepRegistry.get(node.name)
        if step_fn is None:
            available = ", ".join(StepRegistry.list())
            err = (
                f"Step '{node.name}' not found. Available: {available}"
            )
            self._logger.error(err)
            return df, StepReport(
                name=node.name,
                success=False,
                duration_seconds=0,
                rows_in=len(df),
                rows_out=len(df),
                error=err,
            )

        attempt = 0
        last_error: str | None = None
        rows_in = len(df)
        start = time.perf_counter()

        while attempt <= self.max_retries:
            try:
                self._logger.step_start(node.name, attempt)
                result_df = step_fn(df.copy(), **node.params)
                duration = time.perf_counter() - start
                rows_out = len(result_df)
                
                # Calculate rows edited (roughly: any row where values changed)
                rows_edited = 0
                if rows_in == rows_out and df.columns.equals(result_df.columns):
                    # Efficient check for same-shape DataFrames
                    try:
                        rows_edited = (df.values != result_df.values).any(axis=1).sum()
                    except Exception:
                        pass # Fallback to 0 if comparison fails for complex types
                
                self._logger.step_end(node.name, rows_in, rows_out, rows_edited, duration)
                return result_df, StepReport(
                    name=node.name,
                    success=True,
                    duration_seconds=duration,
                    rows_in=rows_in,
                    rows_out=rows_out,
                    rows_edited=int(rows_edited),
                )
            except Exception as exc:
                last_error = f"{type(exc).__name__}: {exc}"
                self._logger.warning(
                    f"Step '{node.name}' attempt {attempt + 1} "
                    f"failed: {last_error}"
                )
                attempt += 1

        duration = time.perf_counter() - start
        self._logger.error(
            f"Step '{node.name}' failed after {attempt} attempt(s)."
        )
        return df, StepReport(
            name=node.name,
            success=False,
            duration_seconds=duration,
            rows_in=rows_in,
            rows_out=len(df),
            error=last_error,
        )

    def _run_parallel_group(
        self, df: pd.DataFrame, nodes: list[DAGNode]
    ) -> tuple[pd.DataFrame, list[StepReport]]:
        """Run a group of steps in parallel (on copies of df).

        The results are concatenated column-wise — suitable for
        independent feature-engineering steps on the same data.
        """
        self._logger.info(
            "[dim]Parallel group:[/] "
            + ", ".join(f"[cyan]{n.name}[/]" for n in nodes)
        )
        results: dict[str, Any] = {}
        reports: list[StepReport] = []

        with ThreadPoolExecutor(max_workers=self.max_workers) as pool:
            futures = {
                pool.submit(self._run_node, df.copy(), node): node
                for node in nodes
            }
            for future in as_completed(futures):
                node = futures[future]
                out_df, report = future.result()
                results[node.name] = out_df
                reports.append(report)

        # For parallel groups we use the last-finished DataFrame as output
        # (common pattern: each step is additive / transformative independently)
        final_df = list(results.values())[-1]
        return final_df, reports

    @staticmethod
    def _build_groups(nodes: list[DAGNode]) -> list[list[DAGNode]]:
        """Group consecutive nodes that share the same parallel_group id."""
        groups: list[list[DAGNode]] = []
        i = 0
        while i < len(nodes):
            node = nodes[i]
            if node.parallel_group is None:
                groups.append([node])
                i += 1
            else:
                # Collect all nodes with the same parallel_group
                grp_id = node.parallel_group
                grp = [node]
                i += 1
                while i < len(nodes) and nodes[i].parallel_group == grp_id:
                    grp.append(nodes[i])
                    i += 1
                groups.append(grp)
        return groups

