"""
Pipeline Compiler
-----------------
Converts a template + step config into an ordered list of DAGNodes
ready for the runtime to execute.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from aidatapilot.core.registry import (
    TemplateRegistry,
)


@dataclass
class DAGNode:
    """A single node in the execution graph.

    Attributes:
        name: Step function name to look up in StepRegistry.
        params: Keyword arguments forwarded to the step function.
        parallel_group: Nodes sharing the same group run concurrently.
    """

    name: str
    params: dict[str, Any] = field(default_factory=dict)
    parallel_group: int | None = None


class PipelineCompiler:
    """Compiles a step list + template into an executable DAG.

    Usage::

        from aidatapilot.core.compiler import PipelineCompiler
        nodes = PipelineCompiler().compile(steps=[...], template="basic_clean")
    """

    def compile(
        self,
        steps: list[dict[str, Any]] | None = None,
        template: str | None = None,
        step_params: dict[str, Any] | None = None,
    ) -> list[DAGNode]:
        """Return an ordered list of :class:`DAGNode` objects.

        Args:
            steps: Explicit step list (overrides template).
            template: Template name; used if ``steps`` is not provided.
            step_params: Global params injected into every step.

        Returns:
            Ordered list of :class:`DAGNode` ready for runtime execution.

        Raises:
            ValueError: If neither *steps* nor *template* is supplied,
                or if the template name is not registered.
        """
        step_params = step_params or {}

        raw_steps = []
        if template:
            tpl = TemplateRegistry.get(template)
            if tpl is None:
                available = ", ".join(TemplateRegistry.list())
                raise ValueError(
                    f"Unknown template '{template}'. "
                    f"Available templates: {available}"
                )
            raw_steps.extend(tpl.steps)
            
        if steps:
            raw_steps.extend(steps)
            
        if not raw_steps:
            raise ValueError(
                "PipelineCompiler requires at least a 'template' or an explicit 'step' list."
            )

        nodes: list[DAGNode] = []
        for i, step in enumerate(raw_steps):
            if isinstance(step, str):
                # Simple step name string — no params
                name, params, group = step, {}, None
            elif isinstance(step, dict):
                name = step["name"]
                params = step.get("params", {})
                group = step.get("parallel_group", None)
            else:
                raise TypeError(
                    f"Step at index {i} must be a str or dict, got {type(step).__name__}."
                )

            # Merge global step_params (step-level params take precedence)
            merged = {**step_params, **params}
            nodes.append(DAGNode(name=name, params=merged, parallel_group=group))

        return nodes

