"""
aidatapilot Registry System 🏷️
---------------------------
Centralized management for connectors, publishers, and templates.
"""

from __future__ import annotations

from typing import Any, ClassVar


class Registry:
    """Base class for all internal registries."""
    _items: ClassVar[dict[str, Any]] = {}
    _aliases: ClassVar[dict[str, str]] = {}

    @classmethod
    def register(cls, name: str, item: Any) -> None:
        cls._items[name] = item

    @classmethod
    def get(cls, name: str) -> Any | None:
        real_name = cls._aliases.get(name, name)
        return cls._items.get(real_name)

    @classmethod
    def list(cls) -> list[str]:
        return sorted(list(cls._items.keys()))

    @classmethod
    def register_alias(cls, alias: str, target: str) -> None:
        cls._aliases[alias] = target

class ConnectorRegistry(Registry):
    _items: ClassVar[dict[str, Any]] = {}
    _aliases: ClassVar[dict[str, str]] = {}

class PublisherRegistry(Registry):
    _items: ClassVar[dict[str, Any]] = {}
    _aliases: ClassVar[dict[str, str]] = {}

class TemplateRegistry(Registry):
    _items: ClassVar[dict[str, Any]] = {}
    _aliases: ClassVar[dict[str, str]] = {}

class StepRegistry(Registry):
    _items: ClassVar[dict[str, Any]] = {}
    _aliases: ClassVar[dict[str, str]] = {}

    @classmethod
    def register_step(cls, name: str):
        """Decorator for step registration."""
        def decorator(func):
            cls.register(name, func)
            return func
        return decorator

# Alias the decorator for easier use in modules
register_step = StepRegistry.register_step
