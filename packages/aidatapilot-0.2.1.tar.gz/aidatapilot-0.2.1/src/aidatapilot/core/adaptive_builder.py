"""
aidatapilot Adaptive Pipeline Builder 🏗️
--------------------------------------
Dynamically constructs a Pipeline based on Dataset profiling.
"""

from __future__ import annotations

from typing import Any

import pandas as pd

from aidatapilot.core.pipeline import Pipeline
from aidatapilot.intelligence.advisor import IntelligenceAdvisor


class AdaptiveBuilder:
    """Intelligent Pipeline Construction Engine."""

    def __init__(self, data: str | pd.DataFrame):
        self.advisor = IntelligenceAdvisor(data)
        self.analyzer = self.advisor.analyzer
        self._report = None

    def build(self) -> Pipeline:
        """Create a tailored pipeline based on data profile."""
        if self._report is None:
            self._report = self.advisor.analyze()

        # 1. Start with recommended template
        recommendation = self.advisor._recommend_template()
        template = recommendation.get("template", "basic_clean")
        
        # 2. Initialize Pipeline
        pipeline = Pipeline(template=template)
        
        # 3. Apply profile-specific overrides / additions
        # (This remains as an extensibility point for more complex rules)
        
        return pipeline

    def get_analysis_summary(self) -> dict[str, Any]:
        """User-friendly summary of the analysis."""
        if self._report is None:
            self._report = self.advisor.analyze()
            
        r = self._report
        return {
            "rows": r.rows,
            "cols": r.cols,
            "dataset_type": r.dataset_type,
            "has_target": r.has_target,
            "target_col": r.target_col,
            "critical_issues": [c for c, p in r.columns.items() if p.missing_ratio > 0.5]
        }
