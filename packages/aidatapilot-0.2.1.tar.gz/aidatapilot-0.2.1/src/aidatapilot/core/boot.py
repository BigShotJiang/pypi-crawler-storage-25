"""
aidatapilot Bootstrapper 🥾
------------------------
Handles the registration of internal modules to avoid circular dependencies
in the core API and Pipeline classes.
"""

def bootstrap() -> None:
    """Import all built-in modules to trigger self-registration."""
    # Connectors & Publishers
    import aidatapilot.connectors.file

    # Processors & Steps
    import aidatapilot.processors.steps
    import aidatapilot.publishers.file
    import aidatapilot.templates.analytics_cleaning

    # Templates
    import aidatapilot.templates.basic_clean
    import aidatapilot.templates.llm_processing
    import aidatapilot.templates.ml_preprocess  # noqa: F401
