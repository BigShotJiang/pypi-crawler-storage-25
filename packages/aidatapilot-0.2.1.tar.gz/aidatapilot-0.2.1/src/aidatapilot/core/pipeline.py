"""
Pipeline — The Heart of aidatapilot
---------------------------------
The main developer-facing class. Opinionated, simple, and powerful.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pandas as pd

from aidatapilot.core.boot import bootstrap
from aidatapilot.core.compiler import PipelineCompiler
from aidatapilot.core.optimizer import RuntimeOptimizer
from aidatapilot.core.registry import ConnectorRegistry, PublisherRegistry
from aidatapilot.core.runtime import PipelineRuntime, PipelineState, RuntimeResult
from aidatapilot.utils.logger import get_logger
from aidatapilot.validators.schema import NullThresholdValidator


@dataclass
class PipelineResult:
    """Final result returned after a pipeline run.

    Attributes:
        success: Whether the pipeline completed without errors.
        state: Final :class:`~aidatapilot.core.runtime.PipelineState`.
        rows_in: Row count of the input dataset.
        rows_out: Row count of the output dataset.
        total_duration_seconds: Wall-clock time for the full run.
        warnings: Non-fatal warnings emitted during processing.
        step_reports: Per-step breakdown of execution stats.
        error: Error message if the pipeline failed.
        df: The final processed DataFrame.
    """

    success: bool
    state: str
    rows_in: int
    rows_out: int
    total_duration_seconds: float
    warnings: list[str]
    step_reports: list[Any]
    error: str | None = None
    df: pd.DataFrame | None = None

    def __str__(self) -> str:
        status = "[v] SUCCESS" if self.success else "[x] FAILED"
        return (
            f"PipelineResult({status} | "
            f"{self.rows_in:,} -> {self.rows_out:,} rows | "
            f"{self.total_duration_seconds:.2f}s)"
        )


class Pipeline:
    """aidatapilot Pipeline — configure once, run anywhere.

    Supports template-based or explicit-step-based pipelines.

    Args:
        template: Name of a built-in template
            (``"basic_clean"``, ``"analytics_cleaning"``, ``"ml_preprocess"``).
        steps: Explicit step list overriding the template.
            Each item can be a step name string or a dict like
            ``{"name": "type_cast", "params": {"columns": {"age": "int"}}}``.
        max_retries: Retry count for each step on failure. Default ``1``.
        max_workers: Thread-pool size for parallel step groups. Default ``4``.
        step_params: Global params forwarded to every step. Useful for
            passing common kwargs without repeating them per step.
    """

    def __init__(
        self,
        steps: list[Any] | None = None,
        template: str | None = None,
        max_retries: int = 1,
        max_workers: int = 4,
        step_params: dict[str, Any] | None = None,
        **kwargs
    ) -> None:
        """Initialize the pipeline with steps or a template."""
        # Trigger registration
        bootstrap()

        if not template and not steps:
            template = "basic_clean"  # Opinionated default

        self._template = template
        self._steps = steps
        self._step_params = step_params or {}
        self._max_retries = max_retries
        self._max_workers = max_workers

        self._source_config: dict[str, Any] | None = None
        self._output_config: dict[str, Any] | None = None
        self._source_df: pd.DataFrame | None = None
        self._output_to_memory: bool = False
        self._last_result: PipelineResult | None = None

        self._logger = get_logger()
        self._compiler = PipelineCompiler()
        self._runtime = PipelineRuntime(
            max_retries=max_retries, max_workers=max_workers
        )

    def set_source(self, type: str = "file", path: str = "", df: pd.DataFrame | None = None, **kwargs) -> Pipeline:
        if df is not None:
            self._source_df = df
            self._source_config = {"type": "memory"}
        else:
            if isinstance(type, str) and "." in type and not path:
                path = type
                type = "file"
            self._source_config = {"type": type, "path": path, **kwargs}
        return self

    def set_output(self, type: str = "file", path: str = "", **kwargs) -> Pipeline:
        if type is None:
            self._output_to_memory = True
            self._output_config = {"type": "memory"}
        else:
            if isinstance(type, str) and "." in type and not path:
                path = type
                type = "file"
            self._output_config = {"type": type, "path": path, **kwargs}
            self._output_to_memory = False
        return self

    def run(self, df: pd.DataFrame | None = None) -> PipelineResult:
        """Execute the pipeline."""
        # -- Resolve source --------------------------------------------
        if df is None:
            if not self._source_config and self._source_df is None:
                raise RuntimeError("No source configured. Call set_source() first.")
            df = self._load_source()

        self._logger.pipeline_start(
            template=self._template, source=self._source_config.get("path", "memory")
        )

        # -- Optimize Runtime ------------------------------------------
        optimizer = RuntimeOptimizer(df=df)
        strategy = optimizer.decide_strategy()
        
        if strategy.memory_save_mode:
            self._logger.info("[yellow]Memory Safety Mode Enabled[/] (Large dataset detected)")
            
        if strategy.use_sequential:
            self._runtime.max_workers = 1 

        # -- Validate source -------------------------------------------
        self._run_validation(df)

        # -- Compile DAG -----------------------------------------------
        nodes = self._compiler.compile(
            steps=self._steps,
            template=self._template,
            step_params=self._step_params,
        )

        # -- Execute ---------------------------------------------------
        runtime_result = self._runtime.execute(df, nodes)

        # -- Publish output if successful ------------------------------
        if runtime_result.state == PipelineState.SUCCESS:
            self._publish_output(runtime_result)

        # -- Build final result ----------------------------------------
        result = PipelineResult(
            success=runtime_result.state == PipelineState.SUCCESS,
            state=runtime_result.state.value,
            rows_in=runtime_result.rows_in,
            rows_out=runtime_result.rows_out,
            total_duration_seconds=runtime_result.total_duration_seconds,
            warnings=runtime_result.warnings,
            step_reports=runtime_result.step_reports,
            error=runtime_result.error,
            df=getattr(runtime_result, "_final_df", None),
        )
        self._last_result = result
        self._logger.print_report(result)
        return result

    def get_report(self) -> PipelineResult | None:
        return self._last_result

    def _load_source(self) -> pd.DataFrame:
        if self._source_df is not None:
            return self._source_df
        cfg = self._source_config
        connector_cls = ConnectorRegistry.get(cfg["type"])
        if connector_cls is None:
            raise ValueError(f"Unknown connector type '{cfg['type']}'")
        connector = connector_cls(**{k: v for k, v in cfg.items() if k != "type"})
        connector.connect()
        df = connector.read()
        connector.close()
        return df

    def _run_validation(self, df: pd.DataFrame) -> None:
        result = NullThresholdValidator(threshold=0.8).validate(df)
        for warning in result.warnings:
            self._logger.warning(warning)

    def _publish_output(self, runtime_result: RuntimeResult) -> None:
        if self._output_to_memory:
            return
        final_df = getattr(runtime_result, "_final_df", None)
        if final_df is None:
            return
        cfg = self._output_config
        pub_cls = PublisherRegistry.get(cfg["type"])
        if pub_cls is None:
            return
        publisher = pub_cls()
        out_path = cfg["path"]
        publisher.publish(final_df, out_path, **{k: v for k, v in cfg.items() if k not in ("type", "path")})
        self._logger.info(f"Output written to [cyan]{out_path}[/]")
