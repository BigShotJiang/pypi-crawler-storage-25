"""
aidatapilot Runtime Optimizer ⚡
------------------------------
Optimizes execution strategy based on data size and system resources.
"""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd
import psutil

from aidatapilot.core.constants import (
    BYTES_TO_MB_FACTOR,
    LARGE_DATASET_MB_THRESHOLD,
    MEMORY_SAFETY_THRESHOLD,
)


@dataclass
class OptimizationStrategy:
    """Execution strategy recommendations."""
    memory_save_mode: bool = False
    use_sequential: bool = False
    max_workers: int = 4

class RuntimeOptimizer:
    """Intelligent workload optimizer."""

    def __init__(self, df: pd.DataFrame):
        self.df = df
        self.mem_usage_mb = df.memory_usage(deep=True).sum() / BYTES_TO_MB_FACTOR

    def decide_strategy(self) -> OptimizationStrategy:
        """Heuristic for execution strategy."""
        strategy = OptimizationStrategy()
        
        # 1. Memory Safety
        available_mem_mb = psutil.virtual_memory().available / BYTES_TO_MB_FACTOR
        if (self.mem_usage_mb / max(available_mem_mb, 1)) > MEMORY_SAFETY_THRESHOLD:
            strategy.memory_save_mode = True
            strategy.use_sequential = True
            strategy.max_workers = 1

        # 2. Dataset Size
        if self.mem_usage_mb > LARGE_DATASET_MB_THRESHOLD:
            strategy.memory_save_mode = True
            
        return strategy
