"""
aidatapilot Core Constants 📐
--------------------------
Single source of truth for all environment-specific thresholds,
heuristics, and algorithm weights.
"""

# ──────────────────────────────────────────────────────────────────────
# 1. Performance & Memory Safety
# ──────────────────────────────────────────────────────────────────────
LARGE_DATASET_MB_THRESHOLD = 50.0  # Alert for optimization
MEMORY_SAFETY_THRESHOLD = 0.8       # Max RAM usage fraction
DEFAULT_FALLBACK_MEM_MB = 1024.0      # Fallback for system RAM discovery
BYTES_TO_MB_FACTOR = 1024 * 1024

MAX_PERMISSION_RETRIES = 5           # For locked files during publish

# ──────────────────────────────────────────────────────────────────────
# 2. Automated EDA & Health Scoring
# ──────────────────────────────────────────────────────────────────────
SKEW_THRESHOLD = 2.0                 # Highly skewed
HIGH_CARDINALITY_THRESHOLD = 50      # Unique values count
OUTLIER_Z_SCORE_THRESHOLD = 3.0      # Standard deviation factor
TEXT_CONTENT_AVG_LEN = 100           # Pivot for Category vs. Text discovery
MISSING_RATIO_THRESHOLD = 0.8        # Threshold to flag critical column status

HEALTH_SCORE_EXCELLENT_MIN = 85
HEALTH_SCORE_GOOD_MIN = 60
