"""
aidatapilot Intelligence Advisor 🧠
---------------------------------
High-level recommendation engine for choosing processing templates.
"""

from __future__ import annotations

from typing import Any

import pandas as pd

from aidatapilot.intelligence.analyzer import DatasetAnalyzer


class IntelligenceAdvisor:
    """Automated Template Recommendation Engine."""

    def __init__(self, data: str | pd.DataFrame):
        self.analyzer = DatasetAnalyzer(data)
        self._report = None

    def analyze(self) -> dict[str, Any]:
        """Profile the dataset."""
        self._report = self.analyzer.profile()
        return self._report

    def _recommend_template(self) -> dict[str, Any]:
        """Heuristic-based template recommendation."""
        if self._report is None:
            self.analyze()

        report = self._report
        
        # 1. Document/RAG Logic
        text_cols = [p.role for p in report.columns.values()].count("text")
        if report.dataset_type == "document" or text_cols >= 1:
            return {"template": "llm_processing", "reason": "High text density detected."}

        # 2. ML Prep Logic
        if report.has_target:
            return {"template": "ml_preprocess", "reason": "Predictive target column detected."}

        # 3. Analytics Logic
        if report.dataset_type in ["transactional", "time_series"]:
            return {"template": "analytics_cleaning", "reason": "Structured numeric/temporal data detected."}

        # 4. Default
        return {"template": "basic_clean", "reason": "General purpose dataset detected."}
