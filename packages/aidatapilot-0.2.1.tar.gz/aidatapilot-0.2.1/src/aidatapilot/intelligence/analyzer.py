"""
aidatapilot Dataset Analyzer 🔍
---------------------------
Performs deep structural and statistical profiling of datasets.
Categorizes columns and detects patterns for the Adaptive Rule Engine.
"""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from aidatapilot.connectors.file import FileConnector
from aidatapilot.core.constants import (
    HIGH_CARDINALITY_THRESHOLD,
    OUTLIER_Z_SCORE_THRESHOLD,
    TEXT_CONTENT_AVG_LEN,
)
from aidatapilot.utils.logger import get_logger

logger = get_logger()

@dataclass
class ColumnProfile:
    """Detailed profile of a single column."""
    name: str
    dtype: str
    role: str  # id, target, feature, text, datetime, categorical
    missing_ratio: float
    unique_count: int
    is_high_cardinality: bool = False
    skew: float = 0.0
    has_outliers: bool = False
    mean: float | None = None
    std: float | None = None

@dataclass
class ProfilingReport:
    """Full dataset profile for the Rule Engine."""
    rows: int
    cols: int
    columns: dict[str, ColumnProfile]
    dataset_type: str  # transactional, document, tabular, time_series
    duplicates: int
    has_target: bool = False
    target_col: str | None = None

class DatasetAnalyzer:
    """Deep engine for dataset profiling."""

    def __init__(self, data: str | pd.DataFrame):
        self.df = self._ensure_df(data)
        self._logger = logger

    def _ensure_df(self, data) -> pd.DataFrame:
        if isinstance(data, pd.DataFrame):
            return data
        return FileConnector(data).connect().read()

    def profile(self) -> ProfilingReport:
        """Execute deep profiling and return a report."""
        rows, cols = self.df.shape
        col_profiles = {}
        
        # 1. Basic Stats
        duplicates = self.df.duplicated().sum()
        
        # 2. Column-by-Column Analysis
        for col in self.df.columns:
            profile = self._profile_column(col)
            col_profiles[col] = profile
            
        # 3. Detect Dataset Type
        ds_type = self._classify_dataset(col_profiles)
        
        # 4. Find potential Target
        target_col = self._guess_target(col_profiles)

        return ProfilingReport(
            rows=rows,
            cols=cols,
            columns=col_profiles,
            dataset_type=ds_type,
            duplicates=duplicates,
            has_target=target_col is not None,
            target_col=target_col
        )

    def _profile_column(self, col: str) -> ColumnProfile:
        series = self.df[col]
        dtype = str(series.dtype)
        missing_ratio = series.isnull().mean()
        unique_count = series.nunique()
        
        # Determine Role
        role = "feature"
        col_low = col.lower()
        
        if any(p in col_low for p in ["id", "uid", "pk", "key", "index"]):
            role = "id"
        elif pd.api.types.is_datetime64_any_dtype(series) or "date" in col_low or "time" in col_low:
            role = "datetime"
        elif pd.api.types.is_numeric_dtype(series):
            role = "numeric"
        elif pd.api.types.is_string_dtype(series) or series.dtype == "object":
            # Guess between categorical and text
            avg_len = series.astype(str).str.len().mean()
            if avg_len > TEXT_CONTENT_AVG_LEN:
                role = "text"
            else:
                role = "categorical"

        # Detailed Numeric Stats
        skew = 0.0
        has_outliers = False
        mean = None
        std = None
        
        if role == "numeric":
            skew = series.skew()
            mean = series.mean()
            std = series.std()
            # Basic Outlier check: |z| > threshold
            if std > 0:
                z_scores = (series - mean).abs() / std
                has_outliers = (z_scores > OUTLIER_Z_SCORE_THRESHOLD).any()

        return ColumnProfile(
            name=col,
            dtype=dtype,
            role=role,
            missing_ratio=missing_ratio,
            unique_count=unique_count,
            is_high_cardinality=unique_count > HIGH_CARDINALITY_THRESHOLD if role == "categorical" else False,
            skew=skew,
            has_outliers=has_outliers,
            mean=mean,
            std=std
        )

    def _classify_dataset(self, profiles: dict[str, ColumnProfile]) -> str:
        roles = [p.role for p in profiles.values()]
        min_text_cols = 1
        min_numeric_cols = 2
        
        # document if text columns are a significant part of the dataset
        if roles.count("text") >= min_text_cols and roles.count("numeric") < min_numeric_cols:
            return "document"
            
        if roles.count("datetime") >= 1 and "numeric" in roles:
            return "time_series"
            
        if "id" in roles and roles.count("numeric") >= min_numeric_cols:
            return "transactional"
            
        return "tabular"

    def _guess_target(self, profiles: dict[str, ColumnProfile]) -> str | None:
        """Heuristic to find a likely target column (e.g., 'price', 'label', 'target')."""
        target_hints = ["target", "label", "price", "amount", "category", "class"]
        for col, _p in profiles.items():
            if any(hint in col.lower() for hint in target_hints):
                return col
        return None
