"""
aidatapilot Professional Business Facade
-------------------------------------
Streamlined, one-line helpers for target audience (ML Engineers, BI Analysts).
Wraps the core/api.py logic into a clean public package.
"""

from aidatapilot.core.api import auto_clean as _core_clean
from aidatapilot.intelligence.advisor import IntelligenceAdvisor


def auto_clean(source, output=None, **kwargs):
    """The gold standard for one-line data cleaning."""
    return _core_clean(source, output, template="basic_clean", **kwargs)

def auto_pilot(source, output=None, **kwargs):
    """
    The 'Smart' one-liner. Analyzes the dataset first and 
    automatically runs the most appropriate cleaning template.
    """
    advisor = IntelligenceAdvisor(source)
    advisor.analyze()
    recommendation = advisor._recommend_template()
    template = recommendation.get("template", "basic_clean")
    
    import logging
    logger = logging.getLogger("aidatapilot")
    logger.info(f"auto_pilot: Intelligence Advisor recommended '{template}' template.")
    
    return _core_clean(source, output, template=template, **kwargs)

def auto_pipeline(source, output=None, objective="auto", **kwargs):
    """
    The 'Master Brain' one-liner.
    Performs deep profiling and dynamically constructs a project-specific pipeline.
    
    Args:
        source: Pre-loaded DataFrame or path to a file.
        output: Destination for processed data.
        objective: Primary goal (default: "auto").
        **kwargs: Extra parameters passed to the AdaptiveBuilder.
    """
    from aidatapilot.core.adaptive_builder import AdaptiveBuilder
    
    builder = AdaptiveBuilder(source)
    pipeline = builder.build()
    
    # Crucial: Set the source so the pipeline knows what to process
    pipeline.set_source(df=builder.analyzer.df)
    
    if output:
        pipeline.set_output(type="file", path=str(output))
    else:
        pipeline.set_output(None)
        
    result = pipeline.run()
    
    # Generate and print the Automation Decision Report
    _print_automation_report(builder, result)
    
    return result

def _print_automation_report(builder, result):
    """Prints a high-impact summary of the automation decisions."""
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    
    console = Console()
    summary = builder.get_analysis_summary()
    
    console.print("\n")
    report_content = (
        f"[bold cyan]AUTOMATION DECISION REPORT[/]\n"
        f"[dim]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[/]\n"
        f"Detected Dataset Type: [bold magenta]{summary['dataset_type'].upper()}[/]\n"
        f"Rows Processed: {summary['rows']:,} | Final Rows: {result.rows_out:,}\n"
    )
    
    if summary['has_target']:
        report_content += f"Detected Goal Target: [bold green]{summary['target_col']}[/]\n"
        
    # Steps Applied table
    table = Table(title="Applied Adaptive Pipeline Steps", header_style="bold yellow", box=None)
    table.add_column("Order", justify="right", style="dim")
    table.add_column("Step Name", style="bold green")
    table.add_column("Reason / Context")
    
    for i, step in enumerate(result.step_reports):
        reason = "Data quality requirement"
        if step.name == "normalize_columns": reason = "Structural standardization"
        if step.name == "log_transform": reason = "Skewed numeric distribution"
        if step.name == "one_hot_encode": reason = "Low-cardinality categorical"
        if step.name == "chunk_text": reason = "Large document segmentation (RAG)"
        
        table.add_row(str(i+1), step.name, reason)
        
    console.print(Panel(report_content, border_style="cyan"))
    console.print(table)
    
    if summary['critical_issues']:
        console.print(f"\n[bold red]![/] Handled [bold]{len(summary['critical_issues'])}[/] critical data quality issues automatically.")
    
    console.print("[bold green]✔[/] Dataset is now [italic]analytics-ready[/] and [italic]ML-ready.[/]\n")
