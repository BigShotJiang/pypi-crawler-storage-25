"""
aidatapilot ML Feature Engineering Facade
----------------------------------------
Tailored formatting for Machine Learning and Model Training.
"""

from __future__ import annotations

from typing import Any

import pandas as pd

from aidatapilot.core.api import auto_clean as _core_clean


def auto_ml_prep(
    source: str | pd.DataFrame, 
    output: str | None = None, 
    **kwargs
) -> Any:
    """Prepares raw data for ML models (scaling, encoding, outliers)."""
    return _core_clean(source, output, template="ml_preprocess", **kwargs)
