"""
aidatapilot Enriched Analytics Facade
------------------------------------
Tailored BI Insights and Professional reporting.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pandas as pd

from aidatapilot.core.api import auto_clean as _core_clean
from aidatapilot.core.constants import HEALTH_SCORE_EXCELLENT_MIN, HEALTH_SCORE_GOOD_MIN
from aidatapilot.discovery.analyzer import AdvancedAnalyzer
from aidatapilot.discovery.visualizer import HealthVisualizer


@dataclass
class DiscoveryResult:
    """Consolidated Analytical Result."""

    df: pd.DataFrame
    health_score: int
    insights: list[str]
    profiles: dict[str, Any]
    report_path: str | None = None

    def __repr__(self):
        status = (
            "EXCELLENT"
            if self.health_score >= HEALTH_SCORE_EXCELLENT_MIN
            else ("GOOD" if self.health_score >= HEALTH_SCORE_GOOD_MIN else "NEEDS WORK")
        )
        return f"DiscoveryResult(Score: {self.health_score}/100 | Status: {status})"


def auto_analytics(
    source: str | pd.DataFrame, output: str | None = None, generate_report: bool = True, **kwargs
) -> DiscoveryResult:
    """Enriched BI Pipeline: Cleans, profiles, and visualizes insights."""
    # 1. Standard Cleaning & Formatting
    clean_result = _core_clean(source, output, template="analytics_cleaning", **kwargs)
    df = clean_result.df

    # 2. Advanced Analytical Discovery
    analyzer = AdvancedAnalyzer(df)
    profiles = analyzer.profile()

    # 3. Visual Health Report Generation
    report_path = None
    if generate_report:
        visualizer = HealthVisualizer(df)
        report_name = f"{output}_health_report.png" if output else "analytics_health_report.png"
        report_path = visualizer.generate_report(profiles["health_score"], save_path=report_name)

    return DiscoveryResult(
        df=df,
        health_score=profiles["health_score"],
        insights=profiles["insights"],
        profiles=profiles,
        report_path=report_path,
    )
