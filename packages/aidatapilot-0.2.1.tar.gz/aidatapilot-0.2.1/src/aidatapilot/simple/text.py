"""
aidatapilot Text & RAG Facade
---------------------------
Tailored preparation for Large Language Models.
"""

from __future__ import annotations

from typing import Any

import pandas as pd

from aidatapilot.core.api import auto_clean as _core_clean


def auto_text_prep(
    input: str | pd.DataFrame, 
    output: str | None = None, 
    params: dict | None = None, 
    **kwargs
) -> Any:
    """Prepares long text fields for RAG/LLM applications (chunking, clean)."""
    return _core_clean(input, output, template="llm_processing", step_params=params, **kwargs)
