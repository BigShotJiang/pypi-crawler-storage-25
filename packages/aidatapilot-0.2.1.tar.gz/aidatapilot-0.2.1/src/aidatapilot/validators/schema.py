"""
aidatapilot Data Validation 🛡️
----------------------------
Standard data quality checks.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd

from aidatapilot.core.constants import MISSING_RATIO_THRESHOLD


@dataclass
class ValidationResult:
    """Consolidated validation outcome."""
    success: bool
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

class NullThresholdValidator:
    """Checks for excessive missing values."""

    def __init__(self, threshold: float = MISSING_RATIO_THRESHOLD):
        self.threshold = threshold

    def validate(self, df: pd.DataFrame) -> ValidationResult:
        """Flag columns exceeding the null threshold."""
        warnings = []
        null_rates = df.isnull().mean()
        for col, rate in null_rates.items():
            if rate > self.threshold:
                warnings.append(
                    f"Column '{col}' has {rate:.1%} missing values (exceeds {self.threshold:.1%} limit)."
                )
        return ValidationResult(success=True, warnings=warnings)
