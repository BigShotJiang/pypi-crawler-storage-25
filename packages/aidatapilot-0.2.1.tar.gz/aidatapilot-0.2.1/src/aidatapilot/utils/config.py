"""
Configuration Manager
----------------------
Loads pipeline configuration from three sources (in priority order):
  1. Python kwargs (highest priority)
  2. YAML file
  3. Environment variables prefixed with ``aidatapilot_``

Usage::

    from aidatapilot.utils.config import ConfigManager

    # From YAML
    config = ConfigManager.load("pipeline.yaml")

    # From dict
    config = ConfigManager.load({"template": "basic_clean", "source": "data.csv"})

    # From environment only
    config = ConfigManager.load()
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any


class ConfigManager:
    """Merge configuration from YAML, environment variables, and Python dicts.

    The precedence order (highest to lowest) is:
      1. Explicit Python kwargs / dict argument
      2. YAML file values
      3. Environment variables (``aidatapilot_<KEY>``)
    """

    ENV_PREFIX = "aidatapilot_"

    @classmethod
    def load(
        cls,
        source: str | dict | None = None,
        **overrides,
    ) -> dict[str, Any]:
        """Load and merge configuration.

        Args:
            source: A file path (str / Path) to a YAML config file,
                or a dict of values, or ``None`` (env-only).
            **overrides: Values that override everything else.

        Returns:
            Merged configuration dictionary.
        """
        config: dict[str, Any] = {}

        # Layer 1: environment variables
        for key, val in os.environ.items():
            if key.startswith(cls.ENV_PREFIX):
                cfg_key = key[len(cls.ENV_PREFIX):].lower()
                config[cfg_key] = val

        # Layer 2: YAML file or dict
        if isinstance(source, dict):
            config.update(source)
        elif source is not None:
            yaml_cfg = cls._load_yaml(str(source))
            config.update(yaml_cfg)

        # Layer 3: explicit overrides (highest priority)
        config.update(overrides)

        return config

    @classmethod
    def _load_yaml(cls, path: str) -> dict[str, Any]:
        """Load a YAML file and return its contents as a dict."""
        try:
            import yaml
        except ImportError:
            raise ImportError(
                "pyyaml is required to load YAML config files. "
                "Install it with: pip install pyyaml"
            )

        yaml_path = Path(path)
        if not yaml_path.exists():
            raise FileNotFoundError(
                f"ConfigManager: YAML config file not found — '{yaml_path}'"
            )

        with open(yaml_path, encoding="utf-8") as f:
            data = yaml.safe_load(f)

        return data if isinstance(data, dict) else {}

