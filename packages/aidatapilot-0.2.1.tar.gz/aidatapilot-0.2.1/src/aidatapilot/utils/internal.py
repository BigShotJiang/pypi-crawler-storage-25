"""
aidatapilot Internal Utilities 🛠️
-------------------------------
Private helpers for the processing engine.
"""

import re
from typing import Optional, Union


def smart_numeric_parse(value: Union[str, float, int]) -> Optional[Union[float, int]]:
    """Progressive string-to-numeric parser for messy data."""
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return None
    
    if isinstance(value, (int, float)):
        return value
    
    s = str(value).strip()
    if not s or s.lower() in ["nan", "null", "none", "n/a", "-"]:
        return None

    # -- 1. Standard Decimal --
    res = _try_standard_decimal(s)
    if res is not None:
        return res

    # -- 2. Scientific/Scientific-ish --
    res = _try_scientific_notation(s)
    if res is not None:
        return res

    # -- 3. Currency/Locale-aware --
    res = _try_currency_locale(s)
    if res is not None:
        return res

    return None

def _try_standard_decimal(s: str) -> Optional[Union[float, int]]:
    """Try simple float/int parsing."""
    try:
        f = float(s)
        return int(f) if f.is_integer() else f
    except ValueError:
        return None

def _try_scientific_notation(s: str) -> Optional[float]:
    """Handle 1.2e3 etc."""
    if "e" in s.lower():
        try:
            return float(s)
        except ValueError:
            pass
    return None

def _try_currency_locale(s: str) -> Optional[float]:
    """Handle '$1,234.56', '1.234,56' etc."""
    # Strip symbols
    clean = re.sub(r"[^\d.,-]", "", s)
    if not clean:
        return None
        
    # Check for European format: 1.234,56
    # If both , and . exist and , is the last one
    if "," in clean and "." in clean:
        if clean.find(",") > clean.find("."):
            clean = clean.replace(".", "").replace(",", ".")
        else:
            clean = clean.replace(",", "")
    elif "," in clean:
        # If ONLY comma exist, maybe it is a decimal separator or thousands
        # Heuristic: if it's near the end and unique, it's a decimal
        if clean.count(",") == 1 and len(clean.split(",")[1]) <= 2:
            clean = clean.replace(",", ".")
        else:
            clean = clean.replace(",", "")
            
    try:
        return float(clean)
    except ValueError:
        return None

import pandas as pd  # For pd.isna
