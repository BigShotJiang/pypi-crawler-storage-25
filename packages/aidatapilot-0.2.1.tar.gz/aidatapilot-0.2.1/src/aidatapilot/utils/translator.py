"""
aidatapilot Translator Utility 🌍
------------------------------
Optional multi-language translation support.
"""

from __future__ import annotations

import logging

logger = logging.getLogger("aidatapilot")

class UniversalTranslator:
    """Translation manager for multi-lingual columns."""

    def __init__(self, target_lang: str = "en"):
        self.target_lang = target_lang
        self._engine = None

    def _get_engine(self):
        if self._engine is None:
            try:
                from deep_translator import GoogleTranslator  # noqa: PLC0415
                self._engine = GoogleTranslator(source='auto', target=self.target_lang)
            except ImportError:
                logger.warning("Translator: 'deep-translator' not installed. Skipping translation.")
        return self._engine

    def translate(self, text: str) -> str:
        """Translate a single string."""
        engine = self._get_engine()
        if engine and text and str(text).strip():
            try:
                return engine.translate(text)
            except Exception as e:
                logger.debug(f"Translator: Failed to translate '{text[:20]}...': {e}")
        return text

    def translate_list(self, texts: list[str]) -> list[str]:
        """Translate a batch of strings."""
        engine = self._get_engine()
        if engine:
            try:
                return engine.translate_batch(texts)
            except Exception as e:
                 logger.debug(f"Translator: Batch failure: {e}")
        return texts
