"""
Internal Visualization Utils
----------------------------
Wraps matplotlib and seaborn to provide clean, high-level plotting.
Users do not interact with this module directly.
"""

from __future__ import annotations

import os

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns


def plot_distribution(
    df: pd.DataFrame,
    column: str,
    title: str | None = None,
    save_path: str | None = None,
):
    """Plot the distribution of a numeric column."""
    plt.figure(figsize=(10, 6))
    sns.histplot(df[column], kde=True, color="skyblue")
    plt.title(title or f"Distribution of {column}")
    plt.xlabel(column)
    plt.ylabel("Frequency")
    _finish_plot(save_path)


def plot_missing(
    df: pd.DataFrame,
    title: str = "Missing Data Heatmap",
    save_path: str | None = None,
):
    """Visualize missing data across all columns."""
    plt.figure(figsize=(12, 6))
    sns.heatmap(df.isnull(), cbar=False, cmap="viridis")
    plt.title(title)
    _finish_plot(save_path)


def plot_correlation(
    df: pd.DataFrame,
    title: str = "Feature Correlation Matrix",
    save_path: str | None = None,
):
    """Plot a correlation heatmap for numerical columns."""
    plt.figure(figsize=(10, 8))
    numeric_df = df.select_dtypes(include=["number"])
    if numeric_df.empty:
        return
    corr = numeric_df.corr()
    sns.heatmap(corr, annot=True, cmap="coolwarm", fmt=".2f")
    plt.title(title)
    _finish_plot(save_path)


def _finish_plot(save_path: str | None = None):
    """Helper to show or save the current plot."""
    if save_path:
        # Ensure directory exists
        os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
        plt.savefig(save_path, bbox_inches="tight")
        plt.close()
    else:
        plt.show()

