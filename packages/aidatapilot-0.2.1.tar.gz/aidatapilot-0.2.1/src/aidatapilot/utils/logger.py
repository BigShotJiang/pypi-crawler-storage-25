from __future__ import annotations

from rich.console import Console
from rich.theme import Theme

# Custom Theme
AIDATAPILOT_THEME = Theme({
    "info": "cyan",
    "warning": "yellow",
    "error": "bold red",
    "success": "bold green",
    "step": "bold magenta",
})

class ConsoleLogger:
    """Singleton-ish logger for terminal feedback."""
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.console = Console(theme=AIDATAPILOT_THEME)
        return cls._instance

    def info(self, msg: str):
        self.console.print(f"[info]INFO:[/] {msg}")

    def warning(self, msg: str):
        self.console.print(f"[warning]WARNING:[/] {msg}")

    def error(self, msg: str):
        self.console.print(f"[error]ERROR:[/] {msg}")

    def success(self, msg: str):
        self.console.print(f"[success]SUCCESS:[/] {msg}")

    def pipeline_start(self, template: str | None, source: str):
        self.console.rule("[bold cyan]aidatapilot Pipeline Running[/]")
        self.console.print(f"Template: [bold]{template or 'custom'}[/] | Source: [dim]{source}[/]")

    def step_start(self, name: str, attempt: int = 0):
        prefix = f" (Attempt {attempt+1})" if attempt > 0 else ""
        self.console.print(f" › [step]{name}[/]{prefix}...")

    def step_end(self, name: str, rows_in: int, rows_out: int, edited: int, duration: float):
        stats = f"[dim]{rows_in}→{rows_out} rows | {edited} edited | {duration:.2f}s[/]"
        self.console.print(f"   [green]✔[/] {name} complete. {stats}")

    def print_report(self, result):
        """Final summary report."""
        from rich.table import Table
        self.console.rule("[bold cyan]Pipeline Report[/]")
        
        table = Table(box=None)
        table.add_column("Property", style="dim")
        table.add_column("Value")
        
        status = "[green]SUCCESS[/]" if result.success else "[red]FAILED[/]"
        table.add_row("Status", status)
        table.add_row("Rows (In/Out)", f"{result.rows_in} -> {result.rows_out}")
        table.add_row("Duration", f"{result.total_duration_seconds:.2f}s")
        
        self.console.print(table)
        if not result.success and result.error:
            self.console.print(f"[bold red]Error:[/] {result.error}")

def get_logger() -> ConsoleLogger:
    return ConsoleLogger()
