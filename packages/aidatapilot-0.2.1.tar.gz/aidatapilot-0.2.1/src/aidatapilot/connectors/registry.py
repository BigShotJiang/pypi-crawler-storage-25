"""Connectors registry convenience re-export."""
from aidatapilot.connectors.base import ConnectorRegistry, register_connector

__all__ = ["ConnectorRegistry", "register_connector"]

