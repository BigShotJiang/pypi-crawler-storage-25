"""
aidatapilot File Connector 📂
---------------------------
Core data ingestion engine for flat files.
"""

from __future__ import annotations

import pandas as pd

from aidatapilot.core.registry import ConnectorRegistry


class FileConnector:
    """Universal File Ingestion Engine."""

    def __init__(self, path: str, **kwargs):
        self.path = path
        self.kwargs = kwargs
        self._df: pd.DataFrame | None = None

    def connect(self) -> FileConnector:
        """Verify file existence and state."""
        import os
        if not os.path.exists(self.path):
            raise FileNotFoundError(f"File not found: {self.path}")
        return self

    def read(self) -> pd.DataFrame:
        """Smart reading of various file formats."""
        ext = self.path.split(".")[-1].lower()
        if ext == "csv":
            self._df = pd.read_csv(self.path, **self.kwargs)
        elif ext in ["xls", "xlsx"]:
            self._df = pd.read_excel(self.path, **self.kwargs)
        elif ext == "parquet":
            self._df = pd.read_parquet(self.path, **self.kwargs)
        else:
            # Fallback to CSV for messy extensions
            self._df = pd.read_csv(self.path, **self.kwargs)
        return self._df

    def close(self):
        """Cleanup resources."""
        pass

# Self-registration
ConnectorRegistry.register("file", FileConnector)
