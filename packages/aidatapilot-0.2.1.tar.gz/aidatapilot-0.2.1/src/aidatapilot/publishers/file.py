"""
aidatapilot File Publisher 💾
---------------------------
Core data persistence engine for flat files.
"""

from __future__ import annotations

import pandas as pd

from aidatapilot.core.registry import PublisherRegistry


class FilePublisher:
    """Universal File Persistence Engine."""

    def __init__(self):
        pass

    def publish(self, df: pd.DataFrame, path: str, **kwargs):
        """Smart writing of various file formats."""
        import os
        # Ensure directory exists
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        
        ext = path.rsplit(".", maxsplit=1)[-1].lower()
        if ext == "csv":
            df.to_csv(path, index=False, **kwargs)
        elif ext in ["xls", "xlsx"]:
            df.to_excel(path, index=False, **kwargs)
        elif ext == "parquet":
            df.to_parquet(path, index=False, **kwargs)
        else:
            # Fallback to CSV for messy extensions
            df.to_csv(path, index=False, **kwargs)

# Self-registration
PublisherRegistry.register("file", FilePublisher)
