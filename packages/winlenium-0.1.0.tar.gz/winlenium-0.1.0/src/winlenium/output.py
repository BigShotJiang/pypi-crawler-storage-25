import json
from typing import Any

from winlenium.core.convert import element_to_dict, walk_tree

# Re-export for backward compatibility
__all__ = [
    "element_to_dict",
    "format_element",
    "format_tree",
    "walk_tree",
]


def format_element(element_dict: dict[str, Any], fmt: str = "text") -> str:
    """Format a single element dict as text or JSON."""
    if fmt == "json":
        return json.dumps(element_dict, indent=2)
    parts = []
    parts.append(f"Name: {element_dict.get('name', '')}")
    parts.append(f"AutomationId: {element_dict.get('automation_id', '')}")
    parts.append(f"ControlType: {element_dict.get('control_type', '')}")
    rect = element_dict.get("bounding_rect", {})
    parts.append(
        f"BoundingRect: ({rect.get('left', 0)}, {rect.get('top', 0)}, "
        f"{rect.get('right', 0)}, {rect.get('bottom', 0)})"
    )
    parts.append(f"IsEnabled: {element_dict.get('is_enabled', False)}")
    if "pid" in element_dict:
        parts.append(f"PID: {element_dict['pid']}")
    return "\n".join(parts)


def format_tree(tree_dict: dict[str, Any], fmt: str = "text", _indent: int = 0) -> str:
    """Format a tree dict (with children) as text or JSON."""
    if fmt == "json":
        return json.dumps(tree_dict, indent=2)
    lines = []
    prefix = "  " * _indent
    name = tree_dict.get("name", "")
    control_type = tree_dict.get("control_type", "")
    automation_id = tree_dict.get("automation_id", "")
    line = f"{prefix}[{control_type}] Name={name!r}"
    if automation_id:
        line += f" AutomationId={automation_id!r}"
    lines.append(line)
    for child in tree_dict.get("children", []):
        lines.append(format_tree(child, fmt="text", _indent=_indent + 1))
    return "\n".join(lines)


def format_window(window_dict: dict[str, Any], fmt: str = "text") -> str:
    """Format a single window dict as text or JSON."""
    if fmt == "json":
        return json.dumps(window_dict, indent=2)
    parts = []
    parts.append(f"Name: {window_dict.get('name', '')}")
    parts.append(f"AutomationId: {window_dict.get('automation_id', '')}")
    parts.append(f"ControlType: {window_dict.get('control_type', '')}")
    parts.append(f"PID: {window_dict.get('pid', '')}")
    parts.append(f"Handle: {window_dict.get('handle', '')}")
    rect = window_dict.get("bounding_rect", {})
    parts.append(
        f"BoundingRect: ({rect.get('left', 0)}, {rect.get('top', 0)}, "
        f"{rect.get('right', 0)}, {rect.get('bottom', 0)})"
    )
    parts.append(f"IsEnabled: {window_dict.get('is_enabled', False)}")
    return "\n".join(parts)


def format_window_list(windows: list[dict[str, Any]], fmt: str = "text") -> str:
    """Format a list of window dicts as text or JSON."""
    if fmt == "json":
        return json.dumps(windows, indent=2)
    if not windows:
        return ""
    parts = []
    for window in windows:
        parts.append(format_window(window, fmt="text"))
    return "\n\n".join(parts)


def format_process(process_dict: dict[str, Any], fmt: str = "text") -> str:
    """Format a single process dict as text or JSON."""
    if fmt == "json":
        return json.dumps(process_dict, indent=2)
    parts = []
    parts.append(f"Name: {process_dict.get('name', '')}")
    parts.append(f"PID: {process_dict.get('pid', '')}")
    parts.append(f"Path: {process_dict.get('path', '')}")
    return "\n".join(parts)


def format_process_list(processes: list[dict[str, Any]], fmt: str = "text") -> str:
    """Format a list of process dicts as text or JSON."""
    if fmt == "json":
        return json.dumps(processes, indent=2)
    if not processes:
        return ""
    parts = []
    for proc in processes:
        parts.append(format_process(proc, fmt="text"))
    return "\n\n".join(parts)


def format_toggle_state(state_name: str, fmt: str = "text") -> str:
    """Format a toggle state as text or JSON."""
    if fmt == "json":
        return json.dumps({"state": state_name})
    return f"Toggled. New state: {state_name}"
