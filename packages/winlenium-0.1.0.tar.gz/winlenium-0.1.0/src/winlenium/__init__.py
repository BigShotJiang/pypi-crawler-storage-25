"""Winlenium: CLI tool for automated testing of Windows programs."""
