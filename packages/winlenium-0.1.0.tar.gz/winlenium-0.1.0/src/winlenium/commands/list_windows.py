import click

from winlenium.core.automation import list_all_windows
from winlenium.output import format_window_list


@click.command("list-windows")
@click.option(
    "--pid",
    default=None,
    type=int,
    help="Only include windows owned by this process ID.",
)
@click.option(
    "--format",
    "fmt",
    default="text",
    type=click.Choice(["text", "json"]),
    help="Output format: text for table-like output, json for structured data.",
)
def list_windows_cmd(pid: int | None, fmt: str) -> None:
    """List all top-level windows.

    \b
    Examples:
      winlenium list-windows
      winlenium list-windows --pid 12345
      winlenium list-windows --format json
    """
    windows = list_all_windows(pid=pid)
    output = format_window_list(windows, fmt=fmt)
    if output:
        click.echo(output)
