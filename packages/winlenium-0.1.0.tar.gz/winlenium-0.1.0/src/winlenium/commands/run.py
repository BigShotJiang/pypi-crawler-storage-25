import sys

import click

from winlenium.core.convert import element_to_dict
from winlenium.core.errors import ProcessError, TimeoutError
from winlenium.core.process import launch
from winlenium.output import format_element


@click.command("run")
@click.argument("executable", metavar="EXECUTABLE")
@click.option(
    "--timeout",
    default=10000,
    type=int,
    show_default=True,
    help="Maximum time to wait for the app main window, in milliseconds.",
)
@click.option(
    "--format",
    "fmt",
    default="text",
    type=click.Choice(["text", "json"]),
    help="Output format: text for human-readable output, json for structured data.",
)
def run_cmd(executable: str, timeout: int, fmt: str) -> None:
    """Launch an executable and wait for its main window.

    \b
    Examples:
      winlenium run notepad.exe
      winlenium run calc.exe --timeout 5000
      winlenium run notepad.exe --format json
    """
    try:
        _proc, window = launch(executable, timeout_ms=timeout)
    except ProcessError as e:
        click.echo(str(e), err=True)
        sys.exit(1)
    except TimeoutError as e:
        click.echo(str(e), err=True)
        sys.exit(2)

    info = element_to_dict(window)
    info["pid"] = window.ProcessId
    click.echo(format_element(info, fmt=fmt))
