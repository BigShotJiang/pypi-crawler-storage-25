import sys
import time

import click

from winlenium.core.automation import (
    find_element,
    find_window,
    find_window_by_selector,
)
from winlenium.core.errors import ElementNotFoundError, SelectorError
from winlenium.core.selector import (
    Selector,
    WindowSelector,
    selector_options,
    window_selector_options,
)


@click.command("wait")
@selector_options
@window_selector_options
@click.option(
    "--timeout",
    default=5000,
    type=int,
    show_default=True,
    help="Maximum time to wait for condition fulfillment, in milliseconds.",
)
@click.option(
    "--until",
    "until_state",
    default="appear",
    type=click.Choice(["appear", "gone"]),
    help="Condition to wait for: appear (found) or gone (no longer found).",
)
def wait_cmd(
    selector: Selector,
    window_selector: WindowSelector | None,
    timeout: int,
    until_state: str,
) -> None:
    """Wait for an element to appear or disappear.

    \b
    Examples:
      winlenium wait --name "Save As" --timeout 5000
      winlenium wait --name "Progress" --until gone --timeout 10000
      winlenium wait --automationid "loadingSpinner" --until gone
    """
    try:
        if until_state == "appear":
            _wait_appear(selector, window_selector, timeout)
            click.echo("Element found.")
        else:
            _wait_gone(selector, window_selector, timeout)
            click.echo("Element is gone.")
    except (ElementNotFoundError, SelectorError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)


def _wait_appear(
    selector: Selector,
    window_selector: WindowSelector | None,
    timeout: int,
) -> None:
    if window_selector:
        window = find_window_by_selector(window_selector, timeout_ms=timeout)
        find_element(window, selector, timeout_ms=timeout)
    else:
        find_window(selector, timeout_ms=timeout)


def _wait_gone(
    selector: Selector,
    window_selector: WindowSelector | None,
    timeout: int,
) -> None:
    deadline = time.time() + timeout / 1000.0
    poll_interval = 0.3
    while True:
        try:
            if window_selector:
                window = find_window_by_selector(window_selector, timeout_ms=500)
                find_element(window, selector, timeout_ms=500)
            else:
                find_window(selector, timeout_ms=500)
        except ElementNotFoundError:
            return  # Element is gone
        if time.time() >= deadline:
            raise ElementNotFoundError(f"Element still present after {timeout}ms")
        time.sleep(poll_interval)
