import sys

import click

from winlenium.core.automation import find_window, find_window_by_selector
from winlenium.core.errors import ElementNotFoundError, SelectorError
from winlenium.core.selector import (
    Selector,
    WindowSelector,
    selector_options,
    window_selector_options,
)


@click.command("focus")
@selector_options
@window_selector_options
@click.option(
    "--timeout",
    default=5000,
    type=int,
    show_default=True,
    help="Maximum time to locate the target window, in milliseconds.",
)
def focus_cmd(
    selector: Selector,
    window_selector: WindowSelector | None,
    timeout: int,
) -> None:
    """Bring a window to the foreground and set input focus.

    \b
    Examples:
      winlenium focus --window-name "Notepad"
      winlenium focus --window-handle 0x1A2B3C
      winlenium focus --name "Calculator"
    """
    try:
        if window_selector:
            window = find_window_by_selector(window_selector, timeout_ms=timeout)
        else:
            window = find_window(selector, timeout_ms=timeout)
    except (ElementNotFoundError, SelectorError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)

    window.SetFocus()
    click.echo("Window focused.")
