import sys

import click

from winlenium.core.automation import find_window, find_window_by_selector
from winlenium.core.errors import (
    ElementNotFoundError,
    PatternNotSupportedError,
    SelectorError,
)
from winlenium.core.selector import (
    Selector,
    WindowSelector,
    selector_options,
    window_selector_options,
)

# WindowVisualState constants
_NORMAL = 0
_MAXIMIZED = 1
_MINIMIZED = 2


@click.group("window")
def window_cmd() -> None:
    """Manage window state (minimize, maximize, restore).

    \b
    Examples:
      winlenium window minimize --window-name "Notepad"
      winlenium window maximize --window-pid 12345
      winlenium window restore --window-handle 0x1A2B3C
    """
    pass


def _get_window_and_pattern(
    selector: Selector,
    window_selector: WindowSelector | None,
    timeout: int,
) -> tuple:
    """Find window and get its WindowPattern."""
    if window_selector:
        window = find_window_by_selector(window_selector, timeout_ms=timeout)
    else:
        window = find_window(selector, timeout_ms=timeout)

    pattern = window.GetWindowPattern()  # type: ignore[attr-defined]
    if not pattern:
        raise PatternNotSupportedError("Window does not support WindowPattern.")
    return window, pattern


@window_cmd.command("minimize")
@selector_options
@window_selector_options
@click.option(
    "--timeout",
    default=5000,
    type=int,
    show_default=True,
    help="Maximum time to locate the target window, in milliseconds.",
)
def minimize_cmd(
    selector: Selector,
    window_selector: WindowSelector | None,
    timeout: int,
) -> None:
    """Minimize a window."""
    try:
        _window, pattern = _get_window_and_pattern(selector, window_selector, timeout)
    except (ElementNotFoundError, SelectorError, PatternNotSupportedError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)

    pattern.SetWindowVisualState(_MINIMIZED)
    click.echo("Window minimized.")


@window_cmd.command("maximize")
@selector_options
@window_selector_options
@click.option(
    "--timeout",
    default=5000,
    type=int,
    show_default=True,
    help="Maximum time to locate the target window, in milliseconds.",
)
def maximize_cmd(
    selector: Selector,
    window_selector: WindowSelector | None,
    timeout: int,
) -> None:
    """Maximize a window."""
    try:
        _window, pattern = _get_window_and_pattern(selector, window_selector, timeout)
    except (ElementNotFoundError, SelectorError, PatternNotSupportedError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)

    pattern.SetWindowVisualState(_MAXIMIZED)
    click.echo("Window maximized.")


@window_cmd.command("restore")
@selector_options
@window_selector_options
@click.option(
    "--timeout",
    default=5000,
    type=int,
    show_default=True,
    help="Maximum time to locate the target window, in milliseconds.",
)
def restore_cmd(
    selector: Selector,
    window_selector: WindowSelector | None,
    timeout: int,
) -> None:
    """Restore a window to its previous size and position."""
    try:
        _window, pattern = _get_window_and_pattern(selector, window_selector, timeout)
    except (ElementNotFoundError, SelectorError, PatternNotSupportedError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)

    pattern.SetWindowVisualState(_NORMAL)
    click.echo("Window restored.")
