import sys

import click

from winlenium.core.automation import find_element, find_window, find_window_by_selector
from winlenium.core.errors import (
    ElementNotFoundError,
    PatternNotSupportedError,
    SelectorError,
)
from winlenium.core.selector import (
    Selector,
    WindowSelector,
    selector_options,
    window_selector_options,
)


@click.command("collapse")
@selector_options
@window_selector_options
@click.option(
    "--timeout",
    default=5000,
    type=int,
    show_default=True,
    help="Maximum time to locate the target element/window, in milliseconds.",
)
def collapse_cmd(
    selector: Selector,
    window_selector: WindowSelector | None,
    timeout: int,
) -> None:
    """Collapse a tree node, menu, or dropdown.

    \b
    Examples:
      winlenium collapse --name "Documents" --window-name "Explorer"
      winlenium collapse --automationid "treeNode1"
    """
    try:
        if window_selector:
            window = find_window_by_selector(window_selector, timeout_ms=timeout)
            element = find_element(window, selector, timeout_ms=timeout)
        else:
            element = find_window(selector, timeout_ms=timeout)
    except (ElementNotFoundError, SelectorError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)

    pattern = element.GetExpandCollapsePattern()  # type: ignore[attr-defined]
    if not pattern:
        err = PatternNotSupportedError(
            "Element does not support ExpandCollapsePattern."
        )
        click.echo(str(err), err=True)
        sys.exit(1)

    pattern.Collapse()
    click.echo("Element collapsed.")
