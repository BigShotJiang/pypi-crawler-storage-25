import sys

import click

from winlenium.core import screenshot as screenshot_core
from winlenium.core.automation import find_element, find_window, find_window_by_selector
from winlenium.core.errors import ElementNotFoundError, SelectorError
from winlenium.core.selector import (
    Selector,
    WindowSelector,
    selector_options,
    window_selector_options,
)


@click.command("screenshot")
@selector_options
@window_selector_options
@click.option(
    "--output",
    "-o",
    default=None,
    help="Destination PNG file path; defaults to screenshot_<timestamp>.png.",
)
@click.option(
    "--timeout",
    default=5000,
    type=int,
    show_default=True,
    help="Maximum time to locate the screenshot target, in milliseconds.",
)
def screenshot_cmd(
    selector: Selector,
    window_selector: WindowSelector | None,
    output: str | None,
    timeout: int,
) -> None:
    """Capture a screenshot of a window or element.

    \b
    Examples:
      winlenium screenshot --name "Untitled - Notepad" --output shot.png
      winlenium screenshot --automationid "editor" --output element.png
      winlenium screenshot --name "Calculator"
    """
    try:
        has_selector = any(
            [selector.name, selector.automation_id, selector.control_type, selector.pid]
        )
        if has_selector and window_selector:
            window = find_window_by_selector(window_selector, timeout_ms=timeout)
            target = find_element(window, selector, timeout_ms=timeout)
        elif has_selector:
            target = find_window(selector, timeout_ms=timeout)
        elif window_selector:
            target = find_window_by_selector(window_selector, timeout_ms=timeout)
        else:
            click.echo("Error: Provide a selector to identify the target.", err=True)
            sys.exit(1)
    except (ElementNotFoundError, SelectorError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)

    output_path = output or screenshot_core.default_path()
    screenshot_core.capture_control(target, output_path)
    click.echo(f"Screenshot saved to {output_path}")
