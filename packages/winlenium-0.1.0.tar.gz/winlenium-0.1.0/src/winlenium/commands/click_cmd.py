import sys

import click

from winlenium.core.automation import find_element, find_window, find_window_by_selector
from winlenium.core.errors import ElementNotFoundError, SelectorError
from winlenium.core.selector import (
    Selector,
    WindowSelector,
    selector_options,
    window_selector_options,
)


@click.command("click")
@selector_options
@window_selector_options
@click.option(
    "--timeout",
    default=5000,
    type=int,
    show_default=True,
    help="Maximum time to locate the target element/window, in milliseconds.",
)
def click_cmd(
    selector: Selector,
    window_selector: WindowSelector | None,
    timeout: int,
) -> None:
    """Click a UI element identified by selector.

    \b
    Examples:
      winlenium click --name "Seven" --window-name "Calculator"
      winlenium click --automationid "btnSubmit" --timeout 3000
      winlenium click --name "Close" --controltype Button
    """
    try:
        if window_selector:
            window = find_window_by_selector(window_selector, timeout_ms=timeout)
            element = find_element(window, selector, timeout_ms=timeout)
        else:
            element = find_window(selector, timeout_ms=timeout)
    except (ElementNotFoundError, SelectorError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)

    if not element.IsEnabled:
        click.echo("Error: Element is not enabled (not interactable).", err=True)
        sys.exit(1)

    try:
        # Try InvokePattern first
        invoke_pattern = element.GetInvokePattern()  # type: ignore[attr-defined]
        if invoke_pattern:
            invoke_pattern.Invoke()
        else:
            element.Click()
    except Exception:
        # Fallback to Click()
        element.Click()

    click.echo("Clicked successfully.")
