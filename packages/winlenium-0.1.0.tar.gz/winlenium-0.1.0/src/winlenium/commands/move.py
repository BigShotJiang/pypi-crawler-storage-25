import sys

import click
import uiautomation as auto

from winlenium.core.automation import find_element, find_window, find_window_by_selector
from winlenium.core.errors import ElementNotFoundError, SelectorError
from winlenium.core.selector import (
    Selector,
    WindowSelector,
    selector_options,
    window_selector_options,
)


@click.command("move")
@selector_options
@window_selector_options
@click.option(
    "--to-name",
    default=None,
    help="Drop target Name for drag-and-drop destination.",
)
@click.option(
    "--to-automationid",
    default=None,
    help="Drop target AutomationId for drag-and-drop destination.",
)
@click.option(
    "--hover",
    is_flag=True,
    help="Only move cursor to source element center; do not drag or click.",
)
@click.option(
    "--timeout",
    default=5000,
    type=int,
    show_default=True,
    help="Maximum time to locate source/target element(s), in milliseconds.",
)
def move_cmd(
    selector: Selector,
    window_selector: WindowSelector | None,
    to_name: str | None,
    to_automationid: str | None,
    hover: bool,
    timeout: int,
) -> None:
    """Move mouse to an element, hover, or drag to another element.

    \b
    Examples:
      winlenium move --name "Button" --hover
      winlenium move --name "DragItem" --to-name "DropTarget"
      winlenium move --automationid "src" --to-automationid "dest"
    """
    try:
        source = _find(selector, window_selector, timeout)
    except (ElementNotFoundError, SelectorError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)

    if hover:
        # Move mouse to element center without clicking
        rect = source.BoundingRectangle
        cx = (rect.left + rect.right) // 2
        cy = (rect.top + rect.bottom) // 2
        auto.SetCursorPos(cx, cy)
        click.echo("Mouse moved to element.")
        return

    if to_name or to_automationid:
        # Drag from source to target
        try:
            target_selector = Selector(name=to_name, automation_id=to_automationid)
            if window_selector:
                window = find_window_by_selector(window_selector, timeout_ms=timeout)
                target = find_element(window, target_selector, timeout_ms=timeout)
            else:
                target = find_window(target_selector, timeout_ms=timeout)
        except (ElementNotFoundError, SelectorError) as e:
            click.echo(f"Drop target error: {e}", err=True)
            sys.exit(1)

        source.DragDrop(target)  # type: ignore[arg-type,call-arg]
        click.echo("Drag-and-drop completed.")
    else:
        # Just move to element
        rect = source.BoundingRectangle
        cx = (rect.left + rect.right) // 2
        cy = (rect.top + rect.bottom) // 2
        auto.SetCursorPos(cx, cy)
        click.echo("Mouse moved to element.")


def _find(
    selector: Selector,
    window_selector: WindowSelector | None,
    timeout: int,
) -> auto.Control:
    if window_selector:
        window = find_window_by_selector(window_selector, timeout_ms=timeout)
        return find_element(window, selector, timeout_ms=timeout)
    return find_window(selector, timeout_ms=timeout)
