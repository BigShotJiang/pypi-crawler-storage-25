import click

from winlenium.core.process import list_processes
from winlenium.output import format_process_list


@click.command("list-processes")
@click.option(
    "--name",
    "name_filter",
    default=None,
    help="Only include processes whose executable name contains this text.",
)
@click.option(
    "--format",
    "fmt",
    default="text",
    type=click.Choice(["text", "json"]),
    help="Output format: text for table-like output, json for structured data.",
)
def list_processes_cmd(name_filter: str | None, fmt: str) -> None:
    """List running processes with visible windows.

    \b
    Examples:
      winlenium list-processes
      winlenium list-processes --name notepad
      winlenium list-processes --format json
    """
    processes = list_processes(name_filter=name_filter)
    output = format_process_list(processes, fmt=fmt)
    if output:
        click.echo(output)
