import sys

import click
import uiautomation as auto

from winlenium.core.automation import find_element, find_window, find_window_by_selector
from winlenium.core.errors import ElementNotFoundError, SelectorError
from winlenium.core.selector import (
    Selector,
    WindowSelector,
    selector_options,
    window_selector_options,
)


@click.command("key")
@selector_options
@window_selector_options
@click.option(
    "--keys",
    "key_combo",
    required=True,
    help="Key combo to send (examples: Ctrl+S, Enter, Alt+F4, Ctrl+Shift+N).",
)
@click.option(
    "--timeout",
    default=5000,
    type=int,
    show_default=True,
    help="Maximum time to locate and focus the target element/window, in milliseconds.",
)
def key_cmd(
    selector: Selector,
    window_selector: WindowSelector | None,
    key_combo: str,
    timeout: int,
) -> None:
    """Send a key combination to the application.

    \b
    Key format uses '+' to combine modifiers:
      Ctrl+S, Alt+F4, Shift+Tab, Ctrl+Shift+N, Enter, Tab, Escape

    \b
    Examples:
      winlenium key --keys "Ctrl+S"
      winlenium key --keys "Enter" --window-name "Save As"
      winlenium key --keys "Alt+F4" --window-name "Notepad"
    """
    try:
        has_selector = any(
            [selector.name, selector.automation_id, selector.control_type, selector.pid]
        )
        if has_selector or window_selector:
            if window_selector:
                window = find_window_by_selector(window_selector, timeout_ms=timeout)
                window.SetFocus()
                if has_selector:
                    element = find_element(window, selector, timeout_ms=timeout)
                    element.SetFocus()
            else:
                element = find_window(selector, timeout_ms=timeout)
                element.SetFocus()
    except (ElementNotFoundError, SelectorError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)

    uia_keys = _convert_key_combo(key_combo)
    auto.SendKeys(uia_keys, interval=0.05)
    click.echo("Keys sent successfully.")


def _convert_key_combo(combo: str) -> str:
    """Convert human-readable key combo to uiautomation SendKeys format.

    uiautomation uses: {Ctrl}, {Shift}, {Alt}, {Enter}, {Tab}, {Escape}, etc.
    Modifiers are wrapped in parentheses for holding: {Ctrl}(key)
    """
    # Map of modifier names to uiautomation format
    modifier_map = {
        "ctrl": "{Ctrl}",
        "alt": "{Alt}",
        "shift": "{Shift}",
        "win": "{Win}",
    }

    # Map of special key names to uiautomation format
    key_map = {
        "enter": "{Enter}",
        "return": "{Enter}",
        "tab": "{Tab}",
        "escape": "{Escape}",
        "esc": "{Escape}",
        "backspace": "{Backspace}",
        "delete": "{Delete}",
        "del": "{Delete}",
        "insert": "{Insert}",
        "home": "{Home}",
        "end": "{End}",
        "pageup": "{PageUp}",
        "pagedown": "{PageDown}",
        "up": "{Up}",
        "down": "{Down}",
        "left": "{Left}",
        "right": "{Right}",
        "space": "{Space}",
        "f1": "{F1}",
        "f2": "{F2}",
        "f3": "{F3}",
        "f4": "{F4}",
        "f5": "{F5}",
        "f6": "{F6}",
        "f7": "{F7}",
        "f8": "{F8}",
        "f9": "{F9}",
        "f10": "{F10}",
        "f11": "{F11}",
        "f12": "{F12}",
    }

    parts = [p.strip() for p in combo.split("+")]
    modifiers = []
    key = None

    for part in parts:
        lower = part.lower()
        if lower in modifier_map:
            modifiers.append(modifier_map[lower])
        elif lower in key_map:
            key = key_map[lower]
        else:
            # Regular character
            key = part.lower()

    if modifiers and key:
        return "".join(modifiers) + f"({key})"
    elif key:
        return key
    elif modifiers:
        # Just modifiers (rare)
        return "".join(modifiers)
    return combo
