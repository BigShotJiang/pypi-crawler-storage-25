import sys

import click

from winlenium.core.automation import find_window, find_window_by_selector
from winlenium.core.errors import (
    ElementNotFoundError,
    PatternNotSupportedError,
    SelectorError,
)
from winlenium.core.process import terminate
from winlenium.core.selector import (
    Selector,
    WindowSelector,
    selector_options,
    window_selector_options,
)


@click.command("close")
@selector_options
@window_selector_options
@click.option(
    "--force",
    is_flag=True,
    help="Terminate the whole process instead of requesting graceful window close.",
)
@click.option(
    "--timeout",
    default=5000,
    type=int,
    show_default=True,
    help="Maximum time to locate the target window, in milliseconds.",
)
def close_cmd(
    selector: Selector,
    window_selector: WindowSelector | None,
    force: bool,
    timeout: int,
) -> None:
    """Close a window or terminate a process.

    By default, closes the window via WindowPattern.Close().
    Use --force to terminate the entire process.

    \b
    Examples:
      winlenium close --window-name "Save As" --window-pid 12345
      winlenium close --name "Untitled - Notepad"
      winlenium close --pid 12345 --force
    """
    try:
        if window_selector:
            window = find_window_by_selector(window_selector, timeout_ms=timeout)
        else:
            window = find_window(selector, timeout_ms=timeout)
    except (ElementNotFoundError, SelectorError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)

    pid = window.ProcessId

    if force:
        terminate(pid, force=True)
        click.echo("Process terminated.")
        return

    try:
        pattern = window.GetWindowPattern()  # type: ignore[attr-defined]
        if pattern:
            pattern.Close()
            click.echo("Window closed successfully.")
        else:
            raise PatternNotSupportedError(
                "Window does not support WindowPattern.Close(). "
                "Use --force to terminate the process."
            )
    except PatternNotSupportedError as e:
        click.echo(str(e), err=True)
        sys.exit(1)
