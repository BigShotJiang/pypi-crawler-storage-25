import sys

import click

from winlenium.core.automation import find_element, find_window, find_window_by_selector
from winlenium.core.errors import (
    ElementNotFoundError,
    PatternNotSupportedError,
    SelectorError,
)
from winlenium.core.selector import (
    Selector,
    WindowSelector,
    selector_options,
    window_selector_options,
)


@click.command("set-value")
@selector_options
@window_selector_options
@click.option(
    "--value",
    required=True,
    help="Exact value to assign through ValuePattern.SetValue().",
)
@click.option(
    "--timeout",
    default=5000,
    type=int,
    show_default=True,
    help="Maximum time to locate the target element/window, in milliseconds.",
)
def set_value_cmd(
    selector: Selector,
    window_selector: WindowSelector | None,
    value: str,
    timeout: int,
) -> None:
    """Set an element's value via ValuePattern.SetValue().

    No fallback to keystroke simulation — use 'type' for that.

    \b
    Examples:
      winlenium set-value --name "Volume" --value "75" --window-name "Settings"
      winlenium set-value --automationid "txtInput" --value "hello"
    """
    try:
        if window_selector:
            window = find_window_by_selector(window_selector, timeout_ms=timeout)
            element = find_element(window, selector, timeout_ms=timeout)
        else:
            element = find_window(selector, timeout_ms=timeout)
    except (ElementNotFoundError, SelectorError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)

    pattern = element.GetValuePattern()  # type: ignore[attr-defined]
    if not pattern:
        err = PatternNotSupportedError("Element does not support ValuePattern.")
        click.echo(str(err), err=True)
        sys.exit(1)

    if pattern.IsReadOnly:
        click.echo("Error: Element is read-only.", err=True)
        sys.exit(1)

    pattern.SetValue(value)
    click.echo("Value set successfully.")
