import sys

import click
import uiautomation as auto

from winlenium.core.automation import find_element, find_window, find_window_by_selector
from winlenium.core.errors import ElementNotFoundError, SelectorError
from winlenium.core.selector import (
    Selector,
    WindowSelector,
    selector_options,
    window_selector_options,
)


@click.command("get-value")
@selector_options
@window_selector_options
@click.option(
    "--timeout",
    default=5000,
    type=int,
    show_default=True,
    help="Maximum time to locate the target element/window, in milliseconds.",
)
def get_value_cmd(
    selector: Selector, window_selector: WindowSelector | None, timeout: int
) -> None:
    """Read the value of a UI element (via ValuePattern).

    \b
    Examples:
      winlenium get-value --name "Text Editor" --window-name "Notepad"
      winlenium get-value --automationid "CalculatorResults"
    """
    try:
        element = _find(selector, window_selector, timeout)
    except (ElementNotFoundError, SelectorError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)

    try:
        value_pattern = element.GetValuePattern()  # type: ignore[attr-defined]
        if value_pattern:
            click.echo(value_pattern.Value)
            return
    except Exception:
        pass

    # Fallback: try Name or text content
    name = element.Name
    if name:
        click.echo(name)
    else:
        click.echo("", err=False)


def _find(
    selector: Selector,
    window_selector: WindowSelector | None,
    timeout: int,
) -> auto.Control:
    if window_selector:
        window = find_window_by_selector(window_selector, timeout_ms=timeout)
        return find_element(window, selector, timeout_ms=timeout)
    return find_window(selector, timeout_ms=timeout)
