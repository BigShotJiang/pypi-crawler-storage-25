import sys

import click
import uiautomation as auto

from winlenium.core.automation import find_element, find_window, find_window_by_selector
from winlenium.core.errors import ElementNotFoundError, SelectorError
from winlenium.core.selector import (
    Selector,
    WindowSelector,
    selector_options,
    window_selector_options,
)


@click.command("get-property")
@selector_options
@window_selector_options
@click.option(
    "--property",
    "prop_name",
    required=True,
    help="UIA property name to read (for example: IsEnabled, Name, ClassName).",
)
@click.option(
    "--timeout",
    default=5000,
    type=int,
    show_default=True,
    help="Maximum time to locate the target element/window, in milliseconds.",
)
def get_property_cmd(
    selector: Selector,
    window_selector: WindowSelector | None,
    prop_name: str,
    timeout: int,
) -> None:
    """Read a specific UIA property of an element.

    \b
    Examples:
      winlenium get-property --name "Submit" --property IsEnabled
      winlenium get-property --name "Title" --property ClassName
      winlenium get-property --automationid "btn1" --property Name
    """
    try:
        element = _find(selector, window_selector, timeout)
    except (ElementNotFoundError, SelectorError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)

    # Try to get the property by attribute name
    prop_value = getattr(element, prop_name, None)
    if prop_value is not None:
        click.echo(str(prop_value))
    else:
        click.echo(f"Property {prop_name!r} not found on element.", err=True)
        sys.exit(1)


def _find(
    selector: Selector,
    window_selector: WindowSelector | None,
    timeout: int,
) -> auto.Control:
    if window_selector:
        window = find_window_by_selector(window_selector, timeout_ms=timeout)
        return find_element(window, selector, timeout_ms=timeout)
    return find_window(selector, timeout_ms=timeout)
