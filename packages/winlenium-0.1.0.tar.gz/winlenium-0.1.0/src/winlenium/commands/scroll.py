import sys

import click
import uiautomation as auto

from winlenium.core.automation import find_element, find_window, find_window_by_selector
from winlenium.core.errors import ElementNotFoundError, SelectorError
from winlenium.core.selector import (
    Selector,
    WindowSelector,
    selector_options,
    window_selector_options,
)


@click.command("scroll")
@selector_options
@window_selector_options
@click.option(
    "--direction",
    required=True,
    type=click.Choice(["up", "down", "left", "right"]),
    help="Scroll direction to apply on each step (up, down, left, or right).",
)
@click.option(
    "--amount",
    default=1,
    type=int,
    show_default=True,
    help="How many scroll steps to perform in the chosen direction.",
)
@click.option(
    "--timeout",
    default=5000,
    type=int,
    show_default=True,
    help="Maximum time to locate the target element/window, in milliseconds.",
)
def scroll_cmd(
    selector: Selector,
    window_selector: WindowSelector | None,
    direction: str,
    amount: int,
    timeout: int,
) -> None:
    """Scroll within a scrollable element.

    \b
    Examples:
      winlenium scroll --name "ItemList" --direction down --amount 3
      winlenium scroll --name "Editor" --direction right --amount 5
      winlenium scroll --automationid "listView" --direction up
    """
    try:
        element = _find(selector, window_selector, timeout)
    except (ElementNotFoundError, SelectorError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)

    try:
        scroll_pattern = element.GetScrollPattern()  # type: ignore[attr-defined]
        if not scroll_pattern:
            click.echo("Error: Element does not support scrolling.", err=True)
            sys.exit(1)
    except Exception:
        click.echo("Error: Element does not support scrolling.", err=True)
        sys.exit(1)

    for _ in range(amount):
        if direction == "down":
            scroll_pattern.Scroll(
                horizontalAmount=-1, verticalAmount=3
            )  # SmallIncrement
        elif direction == "up":
            scroll_pattern.Scroll(
                horizontalAmount=-1, verticalAmount=2
            )  # SmallDecrement
        elif direction == "right":
            scroll_pattern.Scroll(horizontalAmount=3, verticalAmount=-1)
        elif direction == "left":
            scroll_pattern.Scroll(horizontalAmount=2, verticalAmount=-1)

    click.echo(f"Scrolled {direction} by {amount}.")


def _find(
    selector: Selector,
    window_selector: WindowSelector | None,
    timeout: int,
) -> auto.Control:
    if window_selector:
        window = find_window_by_selector(window_selector, timeout_ms=timeout)
        return find_element(window, selector, timeout_ms=timeout)
    return find_window(selector, timeout_ms=timeout)
