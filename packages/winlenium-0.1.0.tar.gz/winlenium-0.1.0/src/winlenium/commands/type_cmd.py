import sys

import click
import uiautomation as auto

from winlenium.core.automation import find_element, find_window, find_window_by_selector
from winlenium.core.errors import ElementNotFoundError, SelectorError
from winlenium.core.selector import (
    Selector,
    WindowSelector,
    selector_options,
    window_selector_options,
)


@click.command("type")
@selector_options
@window_selector_options
@click.option(
    "--text",
    required=True,
    help="Text payload to send as keyboard input.",
)
@click.option(
    "--timeout",
    default=5000,
    type=int,
    show_default=True,
    help="Maximum time to locate and focus the target element/window, in milliseconds.",
)
def type_cmd(
    selector: Selector,
    window_selector: WindowSelector | None,
    text: str,
    timeout: int,
) -> None:
    """Send text input to an element or the focused control.

    \b
    Examples:
      winlenium type --text "Hello World"
      winlenium type --name "SearchBox" --text "query"
      winlenium type --text "Hello" --window-name "Notepad"
    """
    try:
        has_selector = any(
            [selector.name, selector.automation_id, selector.control_type, selector.pid]
        )
        if has_selector or window_selector:
            if window_selector:
                window = find_window_by_selector(window_selector, timeout_ms=timeout)
                if has_selector:
                    element = find_element(window, selector, timeout_ms=timeout)
                    _type_into_element(element, text)
                else:
                    window.SetFocus()
                    auto.SendKeys(text, interval=0.02)
            else:
                element = find_window(selector, timeout_ms=timeout)
                _type_into_element(element, text)
        else:
            # No selector — type into currently focused element
            auto.SendKeys(text, interval=0.02)
    except (ElementNotFoundError, SelectorError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)

    click.echo("Text sent successfully.")


def _type_into_element(element: auto.Control, text: str) -> None:
    """Type text into an element using ValuePattern or SendKeys."""
    try:
        value_pattern = element.GetValuePattern()  # type: ignore[attr-defined]
        if value_pattern:
            value_pattern.SetValue(text)
            return
    except Exception:
        pass
    # Fallback: focus and send keys
    element.SetFocus()
    auto.SendKeys(text, interval=0.02)
