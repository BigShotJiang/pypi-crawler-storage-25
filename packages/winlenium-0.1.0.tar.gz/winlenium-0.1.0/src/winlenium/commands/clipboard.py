import click
import pyperclip


@click.group("clipboard")
def clipboard_cmd() -> None:
    """Read or set Windows clipboard content.

    \b
    Examples:
      winlenium clipboard get
      winlenium clipboard set --text "Hello"
    """
    pass


@clipboard_cmd.command("get")
def clipboard_get() -> None:
    """Get current clipboard content."""
    content = pyperclip.paste()
    click.echo(content)


@clipboard_cmd.command("set")
@click.option(
    "--text",
    required=True,
    help="Clipboard text content to write.",
)
def clipboard_set(text: str) -> None:
    """Set clipboard content to the specified text."""
    pyperclip.copy(text)
    click.echo("Clipboard updated.")
