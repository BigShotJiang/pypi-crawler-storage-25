import sys

import click

from winlenium.core.automation import (
    find_element,
    find_window,
    find_window_by_selector,
)
from winlenium.core.convert import walk_tree
from winlenium.core.errors import ElementNotFoundError, SelectorError
from winlenium.core.selector import (
    Selector,
    WindowSelector,
    selector_options,
    window_selector_options,
)
from winlenium.output import format_tree


@click.command("inspect")
@selector_options
@window_selector_options
@click.option(
    "--depth",
    default=None,
    type=int,
    help="Maximum depth of child nodes to include; omit to print full subtree.",
)
@click.option(
    "--timeout",
    default=5000,
    type=int,
    show_default=True,
    help="Maximum time to locate the inspection root, in milliseconds.",
)
@click.option(
    "--format",
    "fmt",
    default="text",
    type=click.Choice(["text", "json"]),
    help="Output format: text for human-readable tree, json for structured data.",
)
def inspect_cmd(
    selector: Selector,
    window_selector: WindowSelector | None,
    depth: int | None,
    timeout: int,
    fmt: str,
) -> None:
    """Inspect the accessibility tree of a window.

    \b
    Examples:
      winlenium inspect --name "Untitled - Notepad"
      winlenium inspect --pid 12345 --depth 2
      winlenium inspect --name "Calculator" --format json
    """
    try:
        has_element_selector = any(
            [selector.name, selector.automation_id, selector.control_type, selector.pid]
        )
        if window_selector:
            window = find_window_by_selector(window_selector, timeout_ms=timeout)
            if has_element_selector:
                root = find_element(window, selector, timeout_ms=timeout)
            else:
                root = window
        else:
            root = find_window(selector, timeout_ms=timeout)
    except (ElementNotFoundError, SelectorError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)

    tree = walk_tree(root, max_depth=depth)
    click.echo(format_tree(tree, fmt=fmt))
