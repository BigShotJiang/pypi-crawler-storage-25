import sys

import click

from winlenium.core.automation import find_element, find_window, find_window_by_selector
from winlenium.core.errors import (
    ElementNotFoundError,
    PatternNotSupportedError,
    SelectorError,
)
from winlenium.core.selector import (
    Selector,
    WindowSelector,
    selector_options,
    window_selector_options,
)
from winlenium.output import format_toggle_state

_TOGGLE_STATE_NAMES = {0: "Off", 1: "On", 2: "Indeterminate"}


@click.command("toggle")
@selector_options
@window_selector_options
@click.option(
    "--timeout",
    default=5000,
    type=int,
    show_default=True,
    help="Maximum time to locate the target element/window, in milliseconds.",
)
@click.option(
    "--format",
    "fmt",
    default="text",
    type=click.Choice(["text", "json"]),
    help="Output format: text for readable state, json for structured output.",
)
def toggle_cmd(
    selector: Selector,
    window_selector: WindowSelector | None,
    timeout: int,
    fmt: str,
) -> None:
    """Toggle a checkbox or toggle button.

    \b
    Examples:
      winlenium toggle --name "Enable feature" --window-name "Settings"
      winlenium toggle --automationid "chkAgree" --format json
    """
    try:
        if window_selector:
            window = find_window_by_selector(window_selector, timeout_ms=timeout)
            element = find_element(window, selector, timeout_ms=timeout)
        else:
            element = find_window(selector, timeout_ms=timeout)
    except (ElementNotFoundError, SelectorError) as e:
        click.echo(str(e), err=True)
        sys.exit(1)

    pattern = element.GetTogglePattern()  # type: ignore[attr-defined]
    if not pattern:
        err = PatternNotSupportedError("Element does not support TogglePattern.")
        click.echo(str(err), err=True)
        sys.exit(1)

    pattern.Toggle()
    new_state = pattern.ToggleState
    state_name = _TOGGLE_STATE_NAMES.get(new_state, str(new_state))

    click.echo(format_toggle_state(state_name, fmt=fmt))
