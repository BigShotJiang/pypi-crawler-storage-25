from winlenium.cli import main

main()
