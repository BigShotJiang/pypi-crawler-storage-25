import click


@click.group()
@click.version_option(version="0.1.0", prog_name="winlenium")
def main() -> None:
    """Winlenium — Windows UI Automation CLI for automated testing."""
    pass


from winlenium.commands.click_cmd import click_cmd  # noqa: E402
from winlenium.commands.clipboard import clipboard_cmd  # noqa: E402
from winlenium.commands.close import close_cmd  # noqa: E402
from winlenium.commands.collapse import collapse_cmd  # noqa: E402
from winlenium.commands.expand import expand_cmd  # noqa: E402
from winlenium.commands.focus import focus_cmd  # noqa: E402
from winlenium.commands.get_property import get_property_cmd  # noqa: E402
from winlenium.commands.get_value import get_value_cmd  # noqa: E402
from winlenium.commands.inspect_cmd import inspect_cmd  # noqa: E402
from winlenium.commands.key import key_cmd  # noqa: E402
from winlenium.commands.list_processes import list_processes_cmd  # noqa: E402
from winlenium.commands.list_windows import list_windows_cmd  # noqa: E402
from winlenium.commands.move import move_cmd  # noqa: E402
from winlenium.commands.run import run_cmd  # noqa: E402
from winlenium.commands.screenshot import screenshot_cmd  # noqa: E402
from winlenium.commands.scroll import scroll_cmd  # noqa: E402
from winlenium.commands.select_cmd import select_cmd  # noqa: E402
from winlenium.commands.set_value import set_value_cmd  # noqa: E402
from winlenium.commands.toggle import toggle_cmd  # noqa: E402
from winlenium.commands.type_cmd import type_cmd  # noqa: E402
from winlenium.commands.wait import wait_cmd  # noqa: E402
from winlenium.commands.window import window_cmd  # noqa: E402

main.add_command(run_cmd)
main.add_command(inspect_cmd)
main.add_command(click_cmd)
main.add_command(wait_cmd)
main.add_command(type_cmd)
main.add_command(key_cmd)
main.add_command(get_value_cmd)
main.add_command(get_property_cmd)
main.add_command(screenshot_cmd)
main.add_command(scroll_cmd)
main.add_command(close_cmd)
main.add_command(move_cmd)
main.add_command(clipboard_cmd)
main.add_command(list_windows_cmd)
main.add_command(list_processes_cmd)
main.add_command(focus_cmd)
main.add_command(window_cmd)
main.add_command(toggle_cmd)
main.add_command(select_cmd)
main.add_command(expand_cmd)
main.add_command(collapse_cmd)
main.add_command(set_value_cmd)
