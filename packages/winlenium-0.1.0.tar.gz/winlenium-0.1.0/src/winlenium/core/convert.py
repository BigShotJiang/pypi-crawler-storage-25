from typing import Any

import uiautomation as auto


def element_to_dict(control: auto.Control) -> dict[str, Any]:
    """Extract properties from a UIA control as a dictionary.

    Args:
        control: A uiautomation Control object.

    Returns:
        Dictionary with name, automation_id, control_type, bounding_rect,
        and is_enabled fields.
    """
    rect = control.BoundingRectangle
    return {
        "name": control.Name,
        "automation_id": control.AutomationId,
        "control_type": control.ControlTypeName,
        "bounding_rect": {
            "left": rect.left,
            "top": rect.top,
            "right": rect.right,
            "bottom": rect.bottom,
        },
        "is_enabled": control.IsEnabled,
    }


def walk_tree(
    control: auto.Control, max_depth: int | None = None, _current_depth: int = 0
) -> dict[str, Any]:
    """Recursively walk the accessibility tree and return a nested dict.

    Args:
        control: Root control to walk from.
        max_depth: Maximum depth to recurse. None means unlimited.
        _current_depth: Internal recursion tracker.

    Returns:
        Nested dictionary representing the accessibility tree.
    """
    node = element_to_dict(control)
    if max_depth is not None and _current_depth >= max_depth:
        return node
    children = control.GetChildren()
    if children:
        node["children"] = [
            walk_tree(child, max_depth, _current_depth + 1) for child in children
        ]
    return node


def window_to_dict(control: auto.Control) -> dict[str, Any]:
    """Convert a top-level window control to a dictionary.

    Extends element_to_dict with pid and handle (hex string) fields.

    Args:
        control: A uiautomation Control representing a window.

    Returns:
        Dictionary with element fields plus pid and handle.
    """
    result = element_to_dict(control)
    result["pid"] = control.ProcessId
    result["handle"] = hex(control.NativeWindowHandle)
    return result
