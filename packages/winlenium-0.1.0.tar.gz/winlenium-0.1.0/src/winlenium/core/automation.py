import time
from typing import Any

import uiautomation as auto

from winlenium.core.errors import ElementNotFoundError
from winlenium.core.selector import CONTROL_TYPE_MAP, Selector, WindowSelector

DEFAULT_TIMEOUT_MS = 5000
POLL_INTERVAL_S = 0.3


def _get_control_class(control_type_name: str) -> type[auto.Control]:
    """Get the uiautomation Control class for a control type name."""
    class_name = control_type_name + "Control"
    return getattr(auto, class_name, auto.Control)


def _build_search_params(
    selector: Selector,
    search_from: auto.Control | None = None,
    search_depth: int = 1,
) -> dict[str, Any]:
    """Build kwargs for uiautomation Control constructors."""
    kwargs: dict[str, Any] = {}
    if search_from is not None:
        kwargs["searchFromControl"] = search_from
    kwargs["searchDepth"] = search_depth  # type: ignore[assignment]
    if selector.name:
        kwargs["Name"] = selector.name  # type: ignore[assignment]
    if selector.automation_id:
        kwargs["AutomationId"] = selector.automation_id  # type: ignore[assignment]
    if selector.index is not None:
        kwargs["foundIndex"] = selector.index + 1  # type: ignore[assignment]
    return kwargs


def find_window(
    selector: Selector, timeout_ms: int = DEFAULT_TIMEOUT_MS
) -> auto.Control:
    """Find a top-level window matching the selector.

    Args:
        selector: Selector with matching criteria.
        timeout_ms: Maximum time to wait in milliseconds.

    Returns:
        A uiautomation WindowControl.

    Raises:
        ElementNotFoundError: If no window found within timeout.
        SelectorError: If selector is invalid.
    """
    selector.validate()
    kwargs = _build_search_params(selector, search_depth=1)

    if selector.pid:
        # For PID-based search, we need to find windows belonging to that process
        kwargs.pop("searchDepth", None)
        return _find_window_by_pid(selector, timeout_ms)

    # Use WindowControl for window search
    if selector.control_type and selector.control_type != "Window":
        control_cls = _get_control_class(selector.control_type)
    else:
        control_cls = auto.WindowControl

    ctrl = control_cls(**kwargs)

    deadline = time.time() + timeout_ms / 1000.0
    while True:
        if ctrl.Exists(0, 0):
            return ctrl
        if time.time() >= deadline:
            raise ElementNotFoundError(
                f"Window not found matching {_selector_desc(selector)} "
                f"within {timeout_ms}ms"
            )
        time.sleep(POLL_INTERVAL_S)


def _find_window_by_pid(selector: Selector, timeout_ms: int) -> auto.Control:
    """Find a window by process ID, optionally filtered by other criteria."""
    deadline = time.time() + timeout_ms / 1000.0
    while True:
        root = auto.GetRootControl()
        for child in root.GetChildren():
            if child.ProcessId != selector.pid:
                continue
            if selector.name and child.Name != selector.name:
                continue
            if selector.automation_id and child.AutomationId != selector.automation_id:
                continue
            if selector.control_type:
                type_id = CONTROL_TYPE_MAP.get(selector.control_type)
                if type_id and child.ControlType != type_id:
                    continue
            return child
        if time.time() >= deadline:
            raise ElementNotFoundError(
                f"Window not found matching {_selector_desc(selector)} "
                f"within {timeout_ms}ms"
            )
        time.sleep(POLL_INTERVAL_S)


def find_element(
    root: auto.Control, selector: Selector, timeout_ms: int = DEFAULT_TIMEOUT_MS
) -> auto.Control:
    """Find an element within a subtree.

    Args:
        root: The root control to search from.
        selector: Selector with matching criteria.
        timeout_ms: Maximum time to wait in milliseconds.

    Returns:
        A uiautomation Control.

    Raises:
        ElementNotFoundError: If element not found within timeout.
    """
    selector.validate()

    if selector.control_type:
        control_cls = _get_control_class(selector.control_type)
    else:
        control_cls = auto.Control

    kwargs = _build_search_params(selector, search_from=root, search_depth=0xFFFFFFFF)

    ctrl = control_cls(**kwargs)

    deadline = time.time() + timeout_ms / 1000.0
    while True:
        if ctrl.Exists(0, 0):
            return ctrl
        if time.time() >= deadline:
            raise ElementNotFoundError(
                f"Element not found matching {_selector_desc(selector)} "
                f"within {timeout_ms}ms"
            )
        time.sleep(POLL_INTERVAL_S)


def _selector_desc(selector: Selector) -> str:
    """Build a human-readable description of a selector for error messages."""
    parts = []
    if selector.name:
        parts.append(f"Name={selector.name!r}")
    if selector.automation_id:
        parts.append(f"AutomationId={selector.automation_id!r}")
    if selector.control_type:
        parts.append(f"ControlType={selector.control_type!r}")
    if selector.pid:
        parts.append(f"PID={selector.pid}")
    if selector.index is not None:
        parts.append(f"Index={selector.index}")
    return ", ".join(parts)


def _window_selector_desc(ws: WindowSelector) -> str:
    """Build a human-readable description of a window selector."""
    parts = []
    if ws.name:
        parts.append(f"WindowName={ws.name!r}")
    if ws.automation_id:
        parts.append(f"WindowAutomationId={ws.automation_id!r}")
    if ws.control_type:
        parts.append(f"WindowControlType={ws.control_type!r}")
    if ws.pid:
        parts.append(f"WindowPID={ws.pid}")
    if ws.index is not None:
        parts.append(f"WindowIndex={ws.index}")
    if ws.handle:
        parts.append(f"WindowHandle={hex(ws.handle)}")
    return ", ".join(parts)


def _match_window(child: auto.Control, ws: WindowSelector) -> bool:
    """Check if a child control matches the window selector criteria."""
    if ws.name and child.Name != ws.name:
        return False
    if ws.automation_id and child.AutomationId != ws.automation_id:
        return False
    if ws.control_type:
        type_id = CONTROL_TYPE_MAP.get(ws.control_type)
        if type_id and child.ControlType != type_id:
            return False
    return not (ws.pid and child.ProcessId != ws.pid)


def find_window_by_selector(
    ws: WindowSelector, timeout_ms: int = DEFAULT_TIMEOUT_MS
) -> auto.Control:
    """Find a top-level window matching a WindowSelector.

    Args:
        ws: WindowSelector with matching criteria.
        timeout_ms: Maximum time to wait in milliseconds.

    Returns:
        A uiautomation Control for the matched window.

    Raises:
        ElementNotFoundError: If no window found within timeout.
        SelectorError: If selector is invalid.
    """
    ws.validate()

    # Handle-based lookup — unambiguous
    if ws.handle:
        deadline = time.time() + timeout_ms / 1000.0
        while True:
            ctrl = auto.ControlFromHandle(ws.handle)
            if ctrl and ctrl.NativeWindowHandle:
                return ctrl
            if time.time() >= deadline:
                raise ElementNotFoundError(
                    f"Window not found matching {_window_selector_desc(ws)} "
                    f"within {timeout_ms}ms"
                )
            time.sleep(POLL_INTERVAL_S)

    # Criteria-based search across top-level children
    deadline = time.time() + timeout_ms / 1000.0
    while True:
        root = auto.GetRootControl()
        matches: list[auto.Control] = []
        for child in root.GetChildren():
            if _match_window(child, ws):
                matches.append(child)

        if matches:
            if ws.index is not None:
                if ws.index < len(matches):
                    return matches[ws.index]
                # Index out of range — keep waiting in case more windows appear
            else:
                return matches[0]

        if time.time() >= deadline:
            if ws.index is not None and matches:
                raise ElementNotFoundError(
                    f"Window index {ws.index} out of range, "
                    f"found {len(matches)} matching window(s) for "
                    f"{_window_selector_desc(ws)}"
                )
            raise ElementNotFoundError(
                f"Window not found matching {_window_selector_desc(ws)} "
                f"within {timeout_ms}ms"
            )
        time.sleep(POLL_INTERVAL_S)


def list_all_windows(pid: int | None = None) -> list[dict[str, Any]]:
    """List all top-level windows, optionally filtered by PID.

    Args:
        pid: If provided, only return windows belonging to this process.

    Returns:
        List of window dictionaries (from window_to_dict).
    """
    from winlenium.core.convert import window_to_dict

    root = auto.GetRootControl()
    windows: list[dict[str, Any]] = []
    for child in root.GetChildren():
        if pid is not None and child.ProcessId != pid:
            continue
        windows.append(window_to_dict(child))
    return windows
