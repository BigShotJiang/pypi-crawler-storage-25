import datetime
import os

import uiautomation as auto
from PIL import ImageGrab


def capture_control(control: auto.Control, output_path: str) -> None:
    """Capture a screenshot of a UIA control (window or element).

    Args:
        control: A uiautomation Control with a BoundingRectangle.
        output_path: Path to save the PNG image.
    """
    rect = control.BoundingRectangle
    bbox = (rect.left, rect.top, rect.right, rect.bottom)
    img = ImageGrab.grab(bbox=bbox)
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    img.save(output_path)


def default_path() -> str:
    """Generate a default screenshot path with timestamp."""
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"screenshot_{ts}.png"
