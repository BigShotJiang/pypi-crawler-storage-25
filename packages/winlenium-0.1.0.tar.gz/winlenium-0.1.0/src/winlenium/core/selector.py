import functools
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

import click
import uiautomation as auto

from winlenium.core.errors import SelectorError

# Map short control type names to uiautomation ControlType IDs
CONTROL_TYPE_MAP = {
    name.replace("Control", ""): type_id
    for type_id, name in auto.ControlTypeNames.items()
}


@dataclass
class Selector:
    name: str | None = None
    automation_id: str | None = None
    control_type: str | None = None
    pid: int | None = None
    index: int | None = None

    def validate(self) -> None:
        """Raise SelectorError if no criteria are provided."""
        if not any([self.name, self.automation_id, self.control_type, self.pid]):
            raise SelectorError(
                "At least one selector must be provided: "
                "--name, --automationid, --controltype, or --pid"
            )
        if self.control_type and self.control_type not in CONTROL_TYPE_MAP:
            valid = ", ".join(sorted(CONTROL_TYPE_MAP.keys()))
            raise SelectorError(
                f"Unknown control type {self.control_type!r}. Valid types: {valid}"
            )

    def build_search_kwargs(self) -> dict[str, Any]:
        """Build keyword arguments for uiautomation search methods."""
        self.validate()
        kwargs: dict[str, Any] = {"searchDepth": 1}
        if self.name:
            kwargs["Name"] = self.name
        if self.automation_id:
            kwargs["AutomationId"] = self.automation_id
        if self.control_type:
            kwargs["ControlType"] = CONTROL_TYPE_MAP[self.control_type]
        return kwargs


def selector_options(func: Callable[..., Any]) -> Callable[..., Any]:
    """Shared Click options for element/window selectors."""

    @click.option(
        "--name",
        default=None,
        help="Match the UI Automation Name property (exact match).",
    )
    @click.option(
        "--automationid",
        default=None,
        help="Match the UI Automation AutomationId property (exact match).",
    )
    @click.option(
        "--controltype",
        default=None,
        help="Match the control type (for example: Button, Edit, Window).",
    )
    @click.option(
        "--pid",
        default=None,
        type=int,
        help="Restrict matching to elements/windows owned by this process ID.",
    )
    @click.option(
        "--index",
        default=None,
        type=int,
        help="Use a zero-based match index when multiple elements satisfy selectors.",
    )
    @functools.wraps(func)
    def wrapper(
        *args: Any,
        name: str | None,
        automationid: str | None,
        controltype: str | None,
        pid: int | None,
        index: int | None,
        **kwargs: Any,
    ) -> Any:
        selector = Selector(
            name=name,
            automation_id=automationid,
            control_type=controltype,
            pid=pid,
            index=index,
        )
        return func(*args, selector=selector, **kwargs)

    return wrapper


class HexIntParamType(click.ParamType):
    """Click parameter type that accepts hex (0x1A2B) or decimal integers."""

    name = "INTEGER"

    def convert(
        self, value: str | int, param: click.Parameter | None, ctx: click.Context | None
    ) -> int:
        if isinstance(value, int):
            return value
        try:
            return int(value, 0)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid integer or hex value.", param, ctx)


HEX_INT = HexIntParamType()


@dataclass
class WindowSelector:
    """Selector for targeting a specific top-level window."""

    name: str | None = None
    automation_id: str | None = None
    control_type: str | None = None
    pid: int | None = None
    index: int | None = None
    handle: int | None = None

    def is_empty(self) -> bool:
        """Return True if no criteria are set."""
        return not any(
            [
                self.name,
                self.automation_id,
                self.control_type,
                self.pid,
                self.index is not None,
                self.handle,
            ]
        )

    def validate(self) -> None:
        """Raise SelectorError if no criteria are provided."""
        if self.is_empty():
            raise SelectorError(
                "At least one window selector must be provided: "
                "--window-name, --window-automationid, --window-controltype, "
                "--window-pid, --window-index, or --window-handle"
            )
        if self.control_type and self.control_type not in CONTROL_TYPE_MAP:
            valid = ", ".join(sorted(CONTROL_TYPE_MAP.keys()))
            raise SelectorError(
                f"Unknown control type {self.control_type!r}. Valid types: {valid}"
            )


def window_selector_options(func: Callable[..., Any]) -> Callable[..., Any]:
    """Shared Click options for window selectors."""

    @click.option(
        "--window-name",
        default=None,
        help="Match top-level window by UI Automation Name property.",
    )
    @click.option(
        "--window-automationid",
        default=None,
        help="Match top-level window by UI Automation AutomationId property.",
    )
    @click.option(
        "--window-controltype",
        default=None,
        help="Match top-level window control type (for example: Window, Pane).",
    )
    @click.option(
        "--window-pid",
        default=None,
        type=int,
        help="Restrict window matching to this process ID.",
    )
    @click.option(
        "--window-index",
        default=None,
        type=int,
        help="Use a zero-based window index when multiple windows match.",
    )
    @click.option(
        "--window-handle",
        default=None,
        type=HEX_INT,
        help="Match a window by native handle (accepts hex like 0x1A2B or decimal).",
    )
    @functools.wraps(func)
    def wrapper(
        *args: Any,
        window_name: str | None,
        window_automationid: str | None,
        window_controltype: str | None,
        window_pid: int | None,
        window_index: int | None,
        window_handle: int | None,
        **kwargs: Any,
    ) -> Any:
        ws = WindowSelector(
            name=window_name,
            automation_id=window_automationid,
            control_type=window_controltype,
            pid=window_pid,
            index=window_index,
            handle=window_handle,
        )
        window_selector = ws if not ws.is_empty() else None
        return func(*args, window_selector=window_selector, **kwargs)

    return wrapper
