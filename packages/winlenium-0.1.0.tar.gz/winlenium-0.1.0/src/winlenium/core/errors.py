class WinleniumError(Exception):
    """Base exception for all Winlenium errors."""

    pass


class ElementNotFoundError(WinleniumError):
    """Raised when a UI element cannot be found matching the selector."""

    pass


class TimeoutError(WinleniumError):
    """Raised when an operation exceeds its timeout."""

    pass


class ProcessError(WinleniumError):
    """Raised when a process operation fails (launch, terminate, etc.)."""

    pass


class SelectorError(WinleniumError):
    """Raised when a selector is invalid or matches ambiguously."""

    pass


class PatternNotSupportedError(WinleniumError):
    """Raised when a UIA pattern is not supported by an element."""

    pass
