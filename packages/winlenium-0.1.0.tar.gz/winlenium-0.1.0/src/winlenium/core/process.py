import ctypes
import os
import shutil
import subprocess
import time

import uiautomation as auto

from winlenium.core.errors import ProcessError, TimeoutError

DEFAULT_TIMEOUT_MS = 10000
POLL_INTERVAL_S = 0.3

# Windows API constants
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
STILL_ACTIVE = 259


def launch(
    executable: str,
    args: list[str] | None = None,
    timeout_ms: int = DEFAULT_TIMEOUT_MS,
) -> tuple[subprocess.Popen[bytes], auto.Control]:
    """Launch a process and wait for its main window to appear.

    Args:
        executable: Path or name of executable to launch.
        args: Optional list of arguments.
        timeout_ms: Max time to wait for the window in milliseconds.

    Returns:
        Tuple of (subprocess.Popen, uiautomation.Control) for the
        process and its main window.

    Raises:
        ProcessError: If the executable cannot be found or launched.
        TimeoutError: If no window appears within the timeout.
    """
    # Resolve executable
    exe_path = shutil.which(executable)
    if exe_path is None and not os.path.isfile(executable):
        raise ProcessError(f"Executable not found: {executable!r}")

    # Snapshot existing window handles before launch
    root = auto.GetRootControl()
    existing_handles = set()
    for child in root.GetChildren():
        h = child.NativeWindowHandle
        if h:
            existing_handles.add(h)

    cmd = [executable] + (args or [])
    try:
        proc = subprocess.Popen(cmd)
    except OSError as e:
        raise ProcessError(f"Failed to launch {executable!r}: {e}") from e

    launched_pid = proc.pid

    # Wait for a new window to appear
    deadline = time.time() + timeout_ms / 1000.0
    while True:
        root = auto.GetRootControl()
        for child in root.GetChildren():
            # First try: match by PID (works for simple processes)
            if child.ProcessId == launched_pid:
                return proc, child
            # Second try: find new windows not in our snapshot
            h = child.NativeWindowHandle
            if (
                h
                and h not in existing_handles
                and child.Name
                and proc.poll() is not None
            ):
                # Parent exited, so this new window is likely the child
                return proc, child

        if time.time() >= deadline:
            raise TimeoutError(
                f"No window appeared for {executable!r} (PID {launched_pid}) "
                f"within {timeout_ms}ms"
            )
        time.sleep(POLL_INTERVAL_S)


def terminate(pid: int, force: bool = False) -> None:
    """Terminate a process by PID.

    Args:
        pid: Process ID to terminate.
        force: If True, forcefully kill. If False, try graceful close first.
    """
    if force:
        _force_kill(pid)
    else:
        # Try graceful close: find the window and close it
        root = auto.GetRootControl()
        for child in root.GetChildren():
            if child.ProcessId == pid:
                try:
                    pattern = child.GetWindowPattern()  # type: ignore[attr-defined]
                    if pattern:
                        pattern.Close()
                        return
                except Exception:
                    pass
        # Fallback to force kill
        _force_kill(pid)


def _force_kill(pid: int) -> None:
    """Force kill a process by PID."""
    try:
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.OpenProcess(1, False, pid)  # PROCESS_TERMINATE = 1
        if handle:
            kernel32.TerminateProcess(handle, 1)
            kernel32.CloseHandle(handle)
        else:
            raise ProcessError(f"Cannot open process {pid}")
    except ProcessError:
        raise
    except Exception as e:
        raise ProcessError(f"Failed to kill process {pid}: {e}") from e


def is_running(pid: int) -> bool:
    """Check if a process is still running."""
    kernel32 = ctypes.windll.kernel32
    handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not handle:
        return False
    try:
        exit_code = ctypes.c_ulong()
        if kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
            return exit_code.value == STILL_ACTIVE
        return False
    finally:
        kernel32.CloseHandle(handle)


def _get_process_exe_path(pid: int) -> str:
    """Get the full executable path for a process by PID.

    Args:
        pid: Process ID.

    Returns:
        Full path to the executable, or empty string if unavailable.
    """
    kernel32 = ctypes.windll.kernel32
    handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not handle:
        return ""
    try:
        buf = ctypes.create_unicode_buffer(1024)
        size = ctypes.c_ulong(1024)
        if kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
            return buf.value
        return ""
    finally:
        kernel32.CloseHandle(handle)


def list_processes(
    name_filter: str | None = None,
) -> list[dict[str, str | int]]:
    """Enumerate processes that have visible top-level windows.

    Args:
        name_filter: Case-insensitive substring to match against the
            process executable name. If None, all processes with visible
            windows are returned.

    Returns:
        List of dicts with keys: name, pid, path.
    """
    root = auto.GetRootControl()
    seen_pids: set[int] = set()
    result: list[dict[str, str | int]] = []

    for child in root.GetChildren():
        pid = child.ProcessId
        if pid in seen_pids or pid == 0:
            continue
        seen_pids.add(pid)

        exe_path = _get_process_exe_path(pid)
        exe_name = os.path.basename(exe_path) if exe_path else ""

        if name_filter and name_filter.lower() not in exe_name.lower():
            continue

        result.append(
            {
                "name": exe_name,
                "pid": pid,
                "path": exe_path,
            }
        )

    return result
