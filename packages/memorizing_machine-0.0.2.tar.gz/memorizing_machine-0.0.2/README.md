# Memorizing-Machine
A machine that memorizes ideas.

In order to launch it from the command line or as a Python subprocess:
```bash
echo "Theodotos-Alexandreus: Memorize ..., we will talk about it, machine." \
  | uvx memorizing-machine \
    --provider-api-key=sk-proj-... \
    --github-token=ghp_... 
```

Or, with a local pip installation:
```bash
pip install memorizing-machine
```
Set the environment variables:
```bash
export PROVIDER_API_KEY="sk-proj-..."
export GITHUB_TOKEN="ghp_..."
```
Then:
```bash
memorizing-machine multilogue.txt
```
Or:
```bash
memorizing-machine multilogue.txt new_turn.txt
```
Or:
```bash
cat multilogue.txt | memorizing-machine
```
Or:
```bash
cat multilogue.txt | memorizing-machine > multilogue.txt
```
Or: 
```bash
(cat multilogue.txt; echo:"Theodotos: That is an important idea, Memorizing-Machine.") \
  | memorizing-machine
```
Or:
```bash
cat multilogue.txt new_turn.txt | memorizing-machine
```
Or:
```bash
cat multilogue.txt new_turn.txt | memorizing-machine > multilogue.txt
```
Or, if you have installed other machines:
```bash
cat multilogue.md | summarizing-machine | memorizing-machine > memories.md
```

Or use it in your Python code:
```Python
# Python
import memorizing_machine
```
