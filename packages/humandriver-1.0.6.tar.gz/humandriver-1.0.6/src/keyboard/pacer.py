from __future__ import annotations
from ..utils import clamp
from .config import config
from .utils import sleep


class Pacer:
    def __init__(self, min_wpm: float, max_wpm: float, recorder):
        self.min_cps = (min_wpm * 5.0) / 60.0  # min chars/second allowed
        self.max_cps = (max_wpm * 5.0) / 60.0  # max chars/second allowed
        self.elapsed_sec = 0.0  # total time we've accounted for
        self.printable_char_count = 0  # number of printable chars emitted
        self.recorder = recorder

    def record_printable_char(self) -> None:
        """Records a typed character and accounts for dispatch overhead."""
        self.printable_char_count += 1
        # count a small dispatch overhead so pacing includes real-world time
        self.elapsed_sec += config.DISPATCH_OVERHEAD_S

    def record_control_key(self) -> None:
        """Records a non-printable key (backspace, enter, tab) and its overhead."""
        # backspace/enter/tab overhead also affects real time
        self.elapsed_sec += config.DISPATCH_OVERHEAD_S

    def _calculate_required_delay(self, dt: float, will_emit_char_after: bool) -> float:
        """Calculates the time needed to wait to stay within the WPM bounds."""
        if dt <= 0:
            return 0.0

        # Look-ahead: include the next char if about to type one
        chars_next = self.printable_char_count + (1 if will_emit_char_after else 0)

        # Bounds so overall rate stays within [min_cps, max_cps]
        min_elapsed_needed = (chars_next / self.max_cps) if self.max_cps > 0 else 0.0
        max_elapsed_allowed = (
            (chars_next / self.min_cps) if self.min_cps > 0 else float("inf")
        )

        dt_lower = max(0.0, min_elapsed_needed - self.elapsed_sec)  # don't go too fast
        dt_upper = max_elapsed_allowed - self.elapsed_sec  # don't go too slow

        if dt_upper < dt_lower:
            dt_adj = dt_lower
        else:
            dt_adj = clamp(dt, dt_lower, dt_upper)

        dt_adj = max(dt_adj, config.GLOBAL_MIN_INTERVAL_S)
        return max(0.0, dt_adj)

    async def apply_pacing_delay(
        self, dt: float, will_emit_char_after: bool, tag: str
    ) -> None:
        """Calculates, logs, and enforces the pacing delay before the next keystroke."""
        dt_adj = self._calculate_required_delay(dt, will_emit_char_after)
        self.recorder.log("pause", tag, dt_adj)
        await sleep(dt_adj)
        self.elapsed_sec += dt_adj
