from .behaviors import type_in_element
from .analysis import (
    generate_typing_report,
    generate_typing_report_async,
    print_typing_report,
)
from .telemetry import recorder, get_keyboard_recorder

__all__ = [
    "type_in_element",
    "generate_typing_report",
    "generate_typing_report_async",
    "print_typing_report",
    "recorder",
    "get_keyboard_recorder",
]
