## [v0.8.2](https://pypi.org/project/amsdal_server/0.8.2/) - 2026-03-30

### Added

- Automatically enrich FK reference fields with `display_name` when related objects are loaded via `select_related`
- Resolve FK ordering fields via `__ordering__` and `{field}_order_by` conventions
- Resolve direct FK reference filters by converting partition keys to object references