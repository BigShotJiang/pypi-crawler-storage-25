import os
import pickle
from copy import deepcopy
from typing import Any, cast

import orjson
from marlenv.utils import Schedule

from overcooked import Overcooked


def test_deepcopy_overcooked():
    env = Overcooked.from_layout("scenario4")
    env2 = deepcopy(env)
    assert env == env2

    env2.shaping_factor = Schedule.constant(25)
    assert env != env2


def test_deepcopy_schedule():
    env = Overcooked.from_layout(
        "scenario4", reward_shaping_factor=Schedule.linear(1, 0, 10)
    )
    env2 = deepcopy(env)
    assert env == env2

    env.random_step()
    assert not env == env2, "The reward shaping factor should be different"


def test_pickle():
    env = Overcooked.from_layout("scenario1_s", horizon=60)
    serialized = pickle.dumps(env)
    restored = cast(Overcooked, pickle.loads(serialized))
    assert env == restored

    env.reset()
    restored.reset()

    for _ in range(50):
        actions = env.sample_action()
        step = env.step(actions)
        step_restored = restored.step(actions)
        assert step == step_restored


def test_unpickling_from_blank_process():
    import subprocess
    import tempfile

    env = Overcooked.from_layout("large_room")
    env_file = tempfile.NamedTemporaryFile("wb", delete=False)
    pickle.dump(env, env_file)
    env_file.close()

    # Write the python file

    f = tempfile.NamedTemporaryFile("w", delete=False)
    f.write("""
import pickle
import sys

with open(sys.argv[1], "rb") as f:
    env = pickle.load(f)

env.reset()""")
    f.close()
    try:
        output = subprocess.run(
            f"python {f.name} {env_file.name}", shell=True, capture_output=True
        )
        assert output.returncode == 0, output.stderr.decode("utf-8")
    finally:
        os.remove(f.name)
        os.remove(env_file.name)


def test_serialize_json_overcooked():
    env = Overcooked.from_layout("scenario1_s", horizon=60)
    res = orjson.dumps(env, option=orjson.OPT_SERIALIZE_NUMPY)
    deserialized = cast(dict[str, Any], orjson.loads(res))

    assert deserialized["n_agents"] == env.n_agents
    assert tuple(deserialized["observation_shape"]) == env.observation_shape
    assert tuple(deserialized["state_shape"]) == env.state_shape
    assert tuple(deserialized["extras_shape"]) == env.extras_shape
    assert deserialized["extras_meanings"] == env.extras_meanings
