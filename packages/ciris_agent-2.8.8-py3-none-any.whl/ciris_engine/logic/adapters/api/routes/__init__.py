"""
API routes module.

Export all route modules for easy import.
"""

# Import all route modules
from . import (
    agent,
    audit,
    auth,
    billing,
    config,
    connectors,
    consent,
    dsar,
    dsar_multi_source,
    emergency,
    memory,
    my_data,
    partnership,
    scheduler,
    setup,
    system,
    system_extensions,
    telemetry,
    telemetry_export,
    tickets,
    tools,
    transparency,
    users,
    verification,
    wa,
)

__all__ = [
    "agent",
    "audit",
    "auth",
    "billing",
    "config",
    "connectors",
    "consent",
    "dsar",
    "dsar_multi_source",
    "emergency",
    "memory",
    "my_data",
    "partnership",
    "scheduler",
    "setup",
    "system",
    "system_extensions",
    "telemetry",
    "telemetry_export",
    "tickets",
    "tools",
    "transparency",
    "users",
    "verification",
    "wa",
]
