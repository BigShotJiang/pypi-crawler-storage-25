"""
Adapter management endpoints.

Provides functionality for listing, loading, unloading, and managing adapters.
"""

import logging
import re
from datetime import datetime, timezone
from typing import Annotated, Any, Dict, List, Optional

from fastapi import APIRouter, Body, Depends, HTTPException, Request, Response
from pydantic import ValidationError

from ciris_engine.logic.persistence.llm_providers import disable_adapter_in_env
from ciris_engine.schemas.adapters.discovery import (
    AdapterDiscoveryReport,
    EnrichmentCacheResponse,
    EnrichmentCacheStats,
    InstallRequest,
    InstallResponse,
    RecheckEligibilityResponse,
)
from ciris_engine.schemas.api.responses import SuccessResponse
from ciris_engine.schemas.runtime.adapter_management import (
    AdapterConfig,
    AdapterListResponse,
    AdapterMetrics,
    AdapterOperationResult,
    ModuleTypeInfo,
    ModuleTypesResponse,
)
from ciris_engine.schemas.runtime.adapter_management import RuntimeAdapterStatus as AdapterStatusSchema
from ciris_engine.schemas.services.core.runtime import AdapterInfo, AdapterStatus

from ...constants import ERROR_RUNTIME_CONTROL_SERVICE_NOT_AVAILABLE
from ...dependencies.auth import AuthContext, require_admin, require_observer
from .._adapter_discovery import discover_adapters as _discover_adapters
from .._adapter_discovery import get_cli_dependency_status
from .._adapter_discovery import get_core_adapter_info as _get_core_adapter_info
from .._common import RESPONSES_500_503, RESPONSES_ADAPTER_CRUD, RESPONSES_ADAPTER_STATUS
from .helpers import get_adapter_config_service
from .schemas import (
    AdapterActionRequest,
    ConfigStepInfo,
    ConfigurableAdapterInfo,
    ConfigurableAdaptersResponse,
    LoadableAdapterInfo,
    LoadableAdaptersResponse,
    PersistedConfigsResponse,
    RemovePersistedResponse,
)

logger = logging.getLogger(__name__)


def _sanitize_for_log(value: Any, max_length: int = 64) -> str:
    """Sanitize user-controlled data for safe logging."""
    if value is None:
        return "<none>"
    val_str = str(value)
    sanitized = re.sub(r"[\x00-\x1f\x7f-\x9f]", "", val_str)
    if len(sanitized) > max_length:
        sanitized = sanitized[:max_length] + "..."
    return sanitized


router = APIRouter()

ERROR_ADAPTER_CONFIG_SERVICE_NOT_AVAILABLE = "Adapter configuration service not available"


# ============================================================================
# Adapter Listing Helpers
# ============================================================================


def _create_auto_adapter_info(adapter_name: str, service_type: Any) -> AdapterInfo:
    """Create an AdapterInfo for an auto-loaded adapter."""
    return AdapterInfo(
        adapter_id=f"{adapter_name}_auto",
        adapter_type=adapter_name.upper(),
        status=AdapterStatus.RUNNING,
        started_at=datetime.now(timezone.utc),
        config_params=AdapterConfig(adapter_type=adapter_name, enabled=True, settings={}),
        services_registered=[service_type.value],
        messages_processed=0,
        error_count=0,
        last_error=None,
        tools=[],
    )


def _get_auto_loaded_adapters(service_registry: Any, seen_adapter_ids: set[str]) -> List[AdapterInfo]:
    """Get auto-loaded adapters from service registry."""
    from ciris_engine.schemas.runtime.enums import ServiceType

    auto_adapters: List[AdapterInfo] = []
    logger.info("[AUTO_LOADED] Checking for auto-loaded adapters in service_registry")
    for service_type in [ServiceType.TOOL, ServiceType.WISE_AUTHORITY]:
        try:
            providers = service_registry.get_providers_by_type(service_type)
            logger.info("[AUTO_LOADED] %s has %d providers", service_type, len(providers))
            for idx, provider_info in enumerate(providers):
                metadata = provider_info.get("metadata", {})
                logger.info("[AUTO_LOADED]   provider[%d] metadata=%s", idx, metadata)
                if not metadata.get("auto_loaded"):
                    logger.info("[AUTO_LOADED]   provider[%d] SKIPPED - no auto_loaded flag", idx)
                    continue
                adapter_name = metadata.get("adapter", "unknown")
                adapter_id = f"{adapter_name}_auto"
                logger.info("[AUTO_LOADED]   provider[%d] adapter_name=%s adapter_id=%s", idx, adapter_name, adapter_id)
                if adapter_id not in seen_adapter_ids:
                    seen_adapter_ids.add(adapter_id)
                    auto_adapters.append(_create_auto_adapter_info(adapter_name, service_type))
                    logger.info("[AUTO_LOADED]   provider[%d] ADDED to list", idx)
                else:
                    logger.info("[AUTO_LOADED]   provider[%d] SKIPPED - already seen", idx)
        except Exception as e:
            logger.warning(f"[AUTO_LOADED] Error getting {service_type} providers: {e}")
    logger.info("[AUTO_LOADED] Total auto-loaded adapters: %d", len(auto_adapters))
    return auto_adapters


def _convert_adapter_to_status(adapter: AdapterInfo) -> AdapterStatusSchema:
    """Convert AdapterInfo to AdapterStatusSchema."""
    is_running = adapter.status == AdapterStatus.RUNNING or str(adapter.status).lower() == "running"

    config = adapter.config_params or AdapterConfig(adapter_type=adapter.adapter_type, enabled=is_running, settings={})

    metrics = None
    if adapter.messages_processed > 0 or adapter.error_count > 0:
        uptime = (datetime.now(timezone.utc) - adapter.started_at).total_seconds() if adapter.started_at else 0
        metrics = AdapterMetrics(
            messages_processed=adapter.messages_processed,
            errors_count=adapter.error_count,
            uptime_seconds=uptime,
            last_error=adapter.last_error,
            last_error_time=None,
        )

    return AdapterStatusSchema(
        adapter_id=adapter.adapter_id,
        adapter_type=adapter.adapter_type,
        is_running=is_running,
        loaded_at=adapter.started_at or datetime.now(timezone.utc),
        services_registered=adapter.services_registered,
        config_params=config,
        metrics=metrics,
        last_activity=None,
        tools=adapter.tools,
    )


# ============================================================================
# Endpoints
# ============================================================================


# Cache duration for adapter list (reduces polling frequency)
ADAPTERS_CACHE_SECONDS = 10


@router.get("/adapters", responses=RESPONSES_500_503)
async def list_adapters(
    request: Request,
    response: Response,
    auth: Annotated[AuthContext, Depends(require_observer)],
) -> SuccessResponse[AdapterListResponse]:
    """List all loaded adapters with their type, status, and metrics.

    Includes Cache-Control header to reduce excessive client polling.
    """
    runtime_control = getattr(request.app.state, "main_runtime_control_service", None)
    if not runtime_control:
        raise HTTPException(status_code=503, detail=ERROR_RUNTIME_CONTROL_SERVICE_NOT_AVAILABLE)

    try:
        adapters = await runtime_control.list_adapters()
        logger.debug("[LIST_ADAPTERS] Got %d adapters from runtime_control", len(adapters))
        seen_adapter_ids = {a.adapter_id for a in adapters}

        service_registry = getattr(request.app.state, "service_registry", None)
        if service_registry:
            auto_adapters = _get_auto_loaded_adapters(service_registry, seen_adapter_ids)
            logger.debug("[LIST_ADAPTERS] Got %d auto-loaded adapters", len(auto_adapters))
            adapters.extend(auto_adapters)

        # adapters from runtime_control.list_adapters() are already RuntimeAdapterStatus
        # Only convert AdapterInfo objects (from auto_adapters)
        adapter_statuses: List[AdapterStatusSchema] = []
        for a in adapters:
            logger.info(
                "[LIST_ADAPTERS] Processing adapter: type=%s, class=%s",
                getattr(a, "adapter_type", "unknown"),
                type(a).__name__,
            )
            if isinstance(a, AdapterStatusSchema):
                # Already RuntimeAdapterStatus, use directly (preserves needs_reauth, has_auth_step)
                logger.info(
                    "[LIST_ADAPTERS]   is RuntimeAdapterStatus: needs_reauth=%s, has_auth_step=%s, auth_step_id=%s",
                    getattr(a, "needs_reauth", "N/A"),
                    getattr(a, "has_auth_step", "N/A"),
                    getattr(a, "auth_step_id", "N/A"),
                )
                adapter_statuses.append(a)
            else:
                # AdapterInfo from auto-loaded adapters - convert
                logger.info("[LIST_ADAPTERS]   is AdapterInfo, converting to status")
                adapter_statuses.append(_convert_adapter_to_status(a))
        running_count = sum(1 for a in adapter_statuses if a.is_running)

        # Add cache header to reduce polling frequency
        response.headers["Cache-Control"] = f"private, max-age={ADAPTERS_CACHE_SECONDS}"

        return SuccessResponse(
            data=AdapterListResponse(
                adapters=adapter_statuses,
                total_count=len(adapter_statuses),
                running_count=running_count,
            )
        )

    except ValidationError as e:
        logger.error(f"Validation error listing adapters: {e}")
        logger.error(f"Validation errors detail: {e.errors()}")
        return SuccessResponse(data=AdapterListResponse(adapters=[], total_count=0, running_count=0))
    except Exception as e:
        logger.error(f"Error listing adapters: {e}")
        logger.error(f"Error type: {type(e).__name__}")
        import traceback

        logger.error(f"Traceback: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/adapters/types", responses={500: {"description": "Failed to discover module types"}})
async def list_module_types(
    request: Request,
    auth: Annotated[AuthContext, Depends(require_observer)],
) -> SuccessResponse[ModuleTypesResponse]:
    """
    List all available module/adapter types.

    Returns both core adapters (api, cli, discord) and modular services
    (mcp_client, mcp_server, reddit, etc.) with their typed configuration schemas.
    """
    try:
        # Get core adapters
        core_adapter_types = ["api", "cli", "discord"]
        core_modules = [_get_core_adapter_info(t) for t in core_adapter_types]

        # Discover modular services
        adapters = await _discover_adapters()

        response = ModuleTypesResponse(
            core_modules=core_modules,
            adapters=adapters,
            total_core=len(core_modules),
            total_adapters=len(adapters),
        )

        return SuccessResponse(data=response)

    except Exception as e:
        logger.error("Error listing module types: %s", e)
        raise HTTPException(status_code=500, detail=str(e))


# NOTE: Static routes must come BEFORE the parametrized route /adapters/{adapter_id}


@router.get(
    "/adapters/persisted",
    responses={
        500: {"description": "Failed to list persisted configurations"},
        503: {"description": "Adapter configuration service unavailable"},
    },
)
async def list_persisted_configurations(
    request: Request,
    auth: Annotated[AuthContext, Depends(require_admin)],
) -> SuccessResponse[PersistedConfigsResponse]:
    """
    List all persisted adapter configurations.

    Returns configurations that are set to load on startup.

    Requires ADMIN role.
    """
    try:
        adapter_config_service = getattr(request.app.state, "adapter_configuration_service", None)
        config_service = getattr(request.app.state, "config_service", None)

        if not adapter_config_service:
            raise HTTPException(status_code=503, detail=ERROR_ADAPTER_CONFIG_SERVICE_NOT_AVAILABLE)

        persisted_configs: Dict[str, Dict[str, Any]] = {}
        if config_service:
            persisted_configs = await adapter_config_service.load_persisted_configs(config_service)

        response = PersistedConfigsResponse(
            persisted_configs=persisted_configs,
            count=len(persisted_configs),
        )
        return SuccessResponse(data=response)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error listing persisted configurations: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete(
    "/adapters/{adapter_type}/persisted",
    responses={
        500: {"description": "Failed to remove persisted configuration"},
        503: {"description": "Configuration service unavailable"},
    },
)
async def remove_persisted_configuration(
    adapter_type: str,
    request: Request,
    auth: Annotated[AuthContext, Depends(require_admin)],
) -> SuccessResponse[RemovePersistedResponse]:
    """
    Remove a persisted adapter configuration.

    This prevents the adapter from being automatically loaded on startup.

    Requires ADMIN role.
    """
    try:
        adapter_config_service = getattr(request.app.state, "adapter_configuration_service", None)
        config_service = getattr(request.app.state, "config_service", None)

        if not adapter_config_service:
            raise HTTPException(status_code=503, detail=ERROR_ADAPTER_CONFIG_SERVICE_NOT_AVAILABLE)

        if not config_service:
            raise HTTPException(status_code=503, detail="Config service not available")

        success = await adapter_config_service.remove_persisted_config(
            adapter_type=adapter_type,
            config_service=config_service,
        )

        if success:
            message = f"Removed persisted configuration for {adapter_type}"
        else:
            message = f"No persisted configuration found for {adapter_type}"

        response = RemovePersistedResponse(
            success=success,
            adapter_type=adapter_type,
            message=message,
        )
        return SuccessResponse(data=response)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error removing persisted configuration: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/adapters/available",
    responses={500: {"description": "Failed to get adapter availability"}},
)
async def list_available_adapters(
    request: Request,
    auth: Annotated[AuthContext, Depends(require_observer)],
) -> SuccessResponse[AdapterDiscoveryReport]:
    """
    List all discovered adapters with eligibility status.

    Returns both eligible (ready to use) and ineligible (missing requirements)
    adapters, including installation hints for ineligible adapters.
    """
    from ciris_engine.logic.services.tool.discovery_service import AdapterDiscoveryService

    try:
        discovery = AdapterDiscoveryService()
        report = await discovery.get_discovery_report()

        return SuccessResponse(data=report)

    except Exception as e:
        logger.error(f"Error getting adapter availability: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/adapters/{adapter_name}/install",
    responses={
        404: {"description": "Adapter not found"},
        500: {"description": "Installation failed"},
    },
)
async def install_adapter_dependencies(
    adapter_name: str,
    request: Request,
    auth: Annotated[AuthContext, Depends(require_admin)],
    body: Annotated[Optional[InstallRequest], Body()] = None,
) -> SuccessResponse[InstallResponse]:
    """
    Install missing dependencies for an adapter.

    Attempts to install missing binaries or packages using the adapter's
    install hints (brew, apt, pip, npm, etc.).

    Requires ADMIN role.
    """
    from ciris_engine.logic.services.tool.discovery_service import AdapterDiscoveryService
    from ciris_engine.logic.services.tool.installer import ToolInstaller

    try:
        # Handle None body (default empty request)
        if body is None:
            body = InstallRequest()

        discovery = AdapterDiscoveryService()
        status = await discovery.get_adapter_eligibility(adapter_name)

        if not status:
            raise HTTPException(status_code=404, detail=f"Adapter '{adapter_name}' not found")

        if status.eligible:
            return SuccessResponse(
                data=InstallResponse(
                    success=True,
                    message=f"Adapter '{adapter_name}' is already eligible",
                    now_eligible=True,
                    eligibility=status,
                )
            )

        if not status.can_install or not status.install_hints:
            return SuccessResponse(
                data=InstallResponse(
                    success=False,
                    message=f"No installation hints available for '{adapter_name}'",
                    now_eligible=False,
                    eligibility=status,
                )
            )

        # Find specific step if requested, otherwise use all hints
        hints = status.install_hints
        if body.install_step_id:
            hints = [h for h in hints if h.id == body.install_step_id]
            if not hints:
                return SuccessResponse(
                    data=InstallResponse(
                        success=False,
                        message=f"Install step '{body.install_step_id}' not found",
                        now_eligible=False,
                    )
                )

        # Run installation
        installer = ToolInstaller(dry_run=body.dry_run)
        install_result = await installer.install_first_applicable(hints)

        # Recheck eligibility after installation
        new_status = await discovery.get_adapter_eligibility(adapter_name)

        return SuccessResponse(
            data=InstallResponse(
                success=install_result.success,
                message=install_result.message,
                installed_binaries=install_result.binaries_installed or [],
                now_eligible=new_status.eligible if new_status else False,
                eligibility=new_status,
            )
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error installing adapter dependencies: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/adapters/{adapter_name}/check-eligibility",
    responses={
        404: {"description": "Adapter not found"},
        500: {"description": "Eligibility check failed"},
    },
)
async def recheck_adapter_eligibility(
    adapter_name: str,
    request: Request,
    auth: Annotated[AuthContext, Depends(require_observer)],
) -> SuccessResponse[RecheckEligibilityResponse]:
    """
    Recheck eligibility for an adapter.

    Useful after manual installation of dependencies to see if the
    adapter is now eligible.
    """
    from ciris_engine.logic.services.tool.discovery_service import AdapterDiscoveryService

    try:
        discovery = AdapterDiscoveryService()
        status = await discovery.get_adapter_eligibility(adapter_name)

        if not status:
            raise HTTPException(status_code=404, detail=f"Adapter '{adapter_name}' not found")

        return SuccessResponse(
            data=RecheckEligibilityResponse(
                name=adapter_name,
                eligible=status.eligible,
                eligibility_reason=status.eligibility_reason,
                missing_binaries=status.missing_binaries,
                missing_env_vars=status.missing_env_vars,
                missing_config=status.missing_config,
                can_install=status.can_install,
            )
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error checking adapter eligibility: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/adapters/configurable",
    responses={500: {"description": "Failed to list configurable adapters"}},
)
async def list_configurable_adapters(
    request: Request,
    auth: Annotated[AuthContext, Depends(require_admin)],
) -> SuccessResponse[ConfigurableAdaptersResponse]:
    """
    List adapters that support interactive configuration.

    Returns information about all adapters that have defined interactive
    configuration workflows, including their workflow types and step counts.

    Requires ADMIN role.
    """
    try:
        config_service = get_adapter_config_service(request)
        adapter_types = config_service.get_configurable_adapters()

        # Build detailed info for each adapter
        adapters = []
        for adapter_type in adapter_types:
            manifest = config_service._adapter_manifests.get(adapter_type)
            if not manifest:
                continue

            # Check if any step is OAuth
            requires_oauth = any(step.step_type == "oauth" for step in manifest.steps)

            adapters.append(
                ConfigurableAdapterInfo(
                    adapter_type=adapter_type,
                    name=adapter_type.replace("_", " ").title(),
                    description=f"Interactive configuration for {adapter_type}",
                    workflow_type=manifest.workflow_type,
                    step_count=len(manifest.steps),
                    requires_oauth=requires_oauth,
                    steps=[
                        ConfigStepInfo(
                            step_id=step.step_id,
                            step_type=step.step_type,
                            title=step.title,
                            description=step.description,
                            optional=getattr(step, "optional", False),
                        )
                        for step in manifest.steps
                    ],
                )
            )

        response = ConfigurableAdaptersResponse(adapters=adapters, total_count=len(adapters))
        return SuccessResponse(data=response)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error listing configurable adapters: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/adapters/loadable",
    responses={500: {"description": "Failed to list loadable adapters"}},
)
async def list_loadable_adapters(
    request: Request,
    auth: Annotated[AuthContext, Depends(require_admin)],
) -> SuccessResponse[LoadableAdaptersResponse]:
    """
    List all adapters that can be loaded from the UI.

    Returns adapters that either:
    1. Support interactive configuration (wizard workflow)
    2. Can be loaded directly without configuration (platform available, no required config)

    Includes count of currently loaded instances for each adapter type.

    Requires ADMIN role.
    """
    try:
        config_service = get_adapter_config_service(request)
        configurable_types = set(config_service.get_configurable_adapters())

        # Get all discovered adapters
        all_adapters = await _discover_adapters()

        # Count loaded instances by adapter type
        # Note: adapter_type from running instances is derived from class name (e.g., "accordmetrics")
        # while module_id from manifest may differ (e.g., "ciris_accord_metrics")
        # We store both the raw type and a normalized version for matching
        loaded_counts: Dict[str, int] = {}
        runtime_control = getattr(request.app.state, "main_runtime_control_service", None)
        if not runtime_control:
            runtime_control = getattr(request.app.state, "runtime_control_service", None)
        if runtime_control:
            adapter_manager = getattr(runtime_control, "adapter_manager", None)
            if adapter_manager and hasattr(adapter_manager, "loaded_adapters"):
                for _adapter_id, instance in adapter_manager.loaded_adapters.items():
                    adapter_type = getattr(instance, "adapter_type", None)
                    if adapter_type:
                        loaded_counts[adapter_type] = loaded_counts.get(adapter_type, 0) + 1

        def _normalize_module_id(module_id: str) -> str:
            """Normalize module_id to match adapter_type derived from class names.

            Handles cases like:
            - ciris_accord_metrics -> accordmetrics
            - navigation -> navigation
            """
            normalized = module_id.lower()
            # Remove common prefixes
            for prefix in ["ciris_", "ciris-"]:
                if normalized.startswith(prefix):
                    normalized = normalized[len(prefix) :]
                    break
            # Remove underscores to match class-name-derived types
            normalized = normalized.replace("_", "")
            return normalized

        def _get_loaded_count(module_id: str) -> int:
            """Get loaded instance count, trying both exact and normalized matches."""
            # Try exact match first
            if module_id in loaded_counts:
                return loaded_counts[module_id]
            # Try normalized match
            normalized = _normalize_module_id(module_id)
            return loaded_counts.get(normalized, 0)

        # Build the combined list
        loadable_adapters: List[LoadableAdapterInfo] = []
        configurable_count = 0
        direct_count = 0

        for adapter in all_adapters:
            # Skip adapters not available on this platform
            if not adapter.platform_available:
                continue

            # Skip internal-only adapters (e.g., ciris_verify which auto-loads)
            if adapter.internal_only:
                continue

            is_configurable = adapter.module_id in configurable_types

            # Check CLI dependencies availability
            cli_deps, missing_cli_deps, deps_available = get_cli_dependency_status(adapter)

            if is_configurable:
                # Get wizard details from config service
                manifest = config_service._adapter_manifests.get(adapter.module_id)
                if manifest:
                    requires_oauth = any(step.step_type == "oauth" for step in manifest.steps)
                    steps = [
                        ConfigStepInfo(
                            step_id=step.step_id,
                            step_type=step.step_type,
                            title=step.title,
                            description=step.description,
                            optional=getattr(step, "optional", False),
                        )
                        for step in manifest.steps
                    ]
                    loadable_adapters.append(
                        LoadableAdapterInfo(
                            adapter_type=adapter.module_id,
                            name=adapter.name,
                            description=adapter.description or f"Configure {adapter.name}",
                            requires_configuration=True,
                            workflow_type=manifest.workflow_type,
                            step_count=len(manifest.steps),
                            requires_oauth=requires_oauth,
                            steps=steps,
                            service_types=adapter.service_types,
                            platform_available=True,
                            external_dependencies=cli_deps,
                            dependencies_available=deps_available,
                            missing_dependencies=missing_cli_deps,
                            loaded_instances=_get_loaded_count(adapter.module_id),
                        )
                    )
                    configurable_count += 1
            else:
                # Check if adapter has no required configuration parameters
                has_required_params = any(param.required for param in (adapter.configuration_schema or []))

                if not has_required_params:
                    # Can be loaded directly
                    loadable_adapters.append(
                        LoadableAdapterInfo(
                            adapter_type=adapter.module_id,
                            name=adapter.name,
                            description=adapter.description or f"Load {adapter.name}",
                            requires_configuration=False,
                            workflow_type=None,
                            step_count=0,
                            requires_oauth=False,
                            steps=[],
                            service_types=adapter.service_types,
                            platform_available=True,
                            external_dependencies=cli_deps,
                            dependencies_available=deps_available,
                            missing_dependencies=missing_cli_deps,
                            loaded_instances=_get_loaded_count(adapter.module_id),
                        )
                    )
                    direct_count += 1

        response = LoadableAdaptersResponse(
            adapters=loadable_adapters,
            total_count=len(loadable_adapters),
            configurable_count=configurable_count,
            direct_load_count=direct_count,
        )
        return SuccessResponse(data=response)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error listing loadable adapters: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/adapters/context-enrichment",
    responses={500: {"description": "Failed to get context enrichment data"}},
)
async def get_context_enrichment_cache(
    request: Request,
    auth: Annotated[AuthContext, Depends(require_observer)],
    refresh: bool = False,
) -> SuccessResponse[EnrichmentCacheResponse]:
    """
    Get context enrichment cache data from adapters.

    Returns cached results from adapter tools that have context_enrichment=True,
    along with cache statistics. This data is ephemeral and refreshed periodically.

    Args:
        refresh: If True, refresh all enrichment tools before returning data.
    """
    from ciris_engine.logic.context.system_snapshot_helpers import get_enrichment_cache, refresh_enrichment_cache

    try:
        # Refresh cache if requested (re-execute all enrichment tools)
        if refresh:
            runtime = request.app.state.runtime
            if runtime:
                await refresh_enrichment_cache(runtime)

        cache = get_enrichment_cache()
        enrichment_data = cache.get_all_entries()
        cache_stats = cache.stats

        return SuccessResponse(
            data=EnrichmentCacheResponse(
                entries=enrichment_data,
                stats=EnrichmentCacheStats(
                    entry_count=cache_stats.get("entries", 0),
                    hits=cache_stats.get("hits", 0),
                    misses=cache_stats.get("misses", 0),
                    hit_rate_pct=cache_stats.get("hit_rate_pct", 0.0),
                    startup_populated=cache_stats.get("startup_populated", False),
                ),
            )
        )

    except Exception as e:
        logger.error(f"Error getting context enrichment cache: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/adapters/{adapter_id}", responses=RESPONSES_ADAPTER_STATUS)
async def get_adapter_status(
    adapter_id: str,
    request: Request,
    auth: Annotated[AuthContext, Depends(require_observer)],
) -> SuccessResponse[AdapterStatusSchema]:
    """
    Get detailed status of a specific adapter.

    Returns comprehensive information about an adapter instance
    including configuration, metrics, and service registrations.
    """
    runtime_control = getattr(request.app.state, "main_runtime_control_service", None)
    if not runtime_control:
        raise HTTPException(status_code=503, detail=ERROR_RUNTIME_CONTROL_SERVICE_NOT_AVAILABLE)

    try:
        # Sanitize adapter_id for logging to prevent log injection (CWE-117)
        safe_id = adapter_id.replace("\n", "").replace("\r", "")[:64] if adapter_id else "unknown"
        logger.info(f"[ADAPTER_STATUS_ROUTE] Getting info for adapter: {safe_id}")
        # Get adapter info from runtime control service
        adapter_info = await runtime_control.get_adapter_info(adapter_id)

        if not adapter_info:
            logger.warning(f"[ADAPTER_STATUS_ROUTE] Adapter not found: {safe_id}")
            raise HTTPException(status_code=404, detail=f"Adapter '{adapter_id}' not found")

        # Debug logging
        logger.info(f"[ADAPTER_STATUS_ROUTE] Got adapter_info: type={type(adapter_info).__name__}")
        logger.info(f"[ADAPTER_STATUS_ROUTE] services_registered={adapter_info.services_registered}")
        logger.info(f"[ADAPTER_STATUS_ROUTE] tools={adapter_info.tools}")
        logger.info(f"[ADAPTER_STATUS_ROUTE] config_params={adapter_info.config_params}")

        # Convert to response format
        metrics_dict = None
        if adapter_info.messages_processed > 0 or adapter_info.error_count > 0:
            metrics = AdapterMetrics(
                messages_processed=adapter_info.messages_processed,
                errors_count=adapter_info.error_count,
                uptime_seconds=(
                    (datetime.now(timezone.utc) - adapter_info.started_at).total_seconds()
                    if adapter_info.started_at
                    else 0
                ),
                last_error=adapter_info.last_error,
                last_error_time=None,
            )
            metrics_dict = metrics.__dict__

        # Use actual config from adapter if available, otherwise create minimal default
        config_params = adapter_info.config_params or AdapterConfig(
            adapter_type=adapter_info.adapter_type, enabled=True, settings={}
        )

        status = AdapterStatusSchema(
            adapter_id=adapter_info.adapter_id,
            adapter_type=adapter_info.adapter_type,
            is_running=adapter_info.status == AdapterStatus.RUNNING,
            loaded_at=adapter_info.started_at,
            services_registered=adapter_info.services_registered,
            config_params=config_params,
            metrics=metrics_dict,
            last_activity=None,
            tools=adapter_info.tools,
        )

        return SuccessResponse(data=status)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting adapter status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/adapters/{adapter_type}", responses=RESPONSES_ADAPTER_CRUD)
async def load_adapter(
    adapter_type: str,
    body: AdapterActionRequest,
    request: Request,
    auth: Annotated[AuthContext, Depends(require_admin)],
    adapter_id: Optional[str] = None,
) -> SuccessResponse[AdapterOperationResult]:
    """
    Load a new adapter instance.

    Dynamically loads and starts a new adapter of the specified type.
    Requires ADMIN role.

    Adapter types: cli, api, discord, mcp, mcp_server
    """
    runtime_control = getattr(request.app.state, "main_runtime_control_service", None)
    if not runtime_control:
        raise HTTPException(status_code=503, detail=ERROR_RUNTIME_CONTROL_SERVICE_NOT_AVAILABLE)

    try:
        # Generate adapter ID if not provided
        import uuid

        if not adapter_id:
            adapter_id = f"{adapter_type}_{uuid.uuid4().hex[:8]}"

        logger.info(
            "[LOAD_ADAPTER] Loading adapter: type=%s, id=%s, persist=%s",
            _sanitize_for_log(adapter_type),
            _sanitize_for_log(adapter_id),
            body.persist,
        )

        # Merge persist flag into config for RuntimeAdapterManager
        config = body.config or {}
        if isinstance(config, dict):
            config["persist"] = body.persist

        logger.debug(f"[LOAD_ADAPTER] Config: {config}")

        result = await runtime_control.load_adapter(adapter_type=adapter_type, adapter_id=adapter_id, config=config)

        logger.info(
            f"[LOAD_ADAPTER] Result: success={result.success}, adapter_id={result.adapter_id}, error={result.error}"
        )

        # Convert response
        response = AdapterOperationResult(
            success=result.success,
            adapter_id=result.adapter_id,
            adapter_type=adapter_type,
            message=result.error if not result.success else f"Adapter {result.adapter_id} loaded successfully",
            error=result.error,
            details={"timestamp": result.timestamp.isoformat()},
        )

        return SuccessResponse(data=response)

    except Exception as e:
        logger.error(f"[LOAD_ADAPTER] Error loading adapter type={adapter_type}, id={adapter_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/adapters/{adapter_id}", responses=RESPONSES_ADAPTER_CRUD)
async def unload_adapter(
    adapter_id: str,
    request: Request,
    auth: Annotated[AuthContext, Depends(require_admin)],
) -> SuccessResponse[AdapterOperationResult]:
    """
    Unload an adapter instance.

    Stops and removes an adapter from the runtime.
    Will fail if it's the last communication-capable adapter.
    Requires ADMIN role.
    """
    runtime_control = getattr(request.app.state, "main_runtime_control_service", None)
    if not runtime_control:
        raise HTTPException(status_code=503, detail=ERROR_RUNTIME_CONTROL_SERVICE_NOT_AVAILABLE)

    try:
        # Unload adapter through runtime control service
        result = await runtime_control.unload_adapter(
            adapter_id=adapter_id, force=False  # Never force, respect safety checks
        )

        # Log failures explicitly
        if not result.success:
            logger.error(f"Adapter unload failed: {result.error}")
        else:
            # Persist the adapter disable to .env so it doesn't reload on restart
            adapter_type_or_id = result.adapter_type or adapter_id
            # Sanitize for logging (prevent log injection)
            safe_id = adapter_id.replace("\n", "").replace("\r", "")[:100]
            if disable_adapter_in_env(adapter_type_or_id):
                logger.info("Adapter %s disabled in .env for persistence", safe_id)
            else:
                logger.warning("Could not persist adapter %s disable to .env", safe_id)

        # Convert response
        response = AdapterOperationResult(
            success=result.success,
            adapter_id=result.adapter_id,
            adapter_type=result.adapter_type,
            message=result.error if not result.success else f"Adapter {result.adapter_id} unloaded successfully",
            error=result.error,
            details={"timestamp": result.timestamp.isoformat()},
        )

        return SuccessResponse(data=response)

    except Exception as e:
        logger.error(f"Error unloading adapter: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.put(
    "/adapters/{adapter_id}/reload",
    responses={
        **RESPONSES_ADAPTER_CRUD,
        400: {"description": "Failed to unload adapter for reload"},
    },
)
async def reload_adapter(
    adapter_id: str,
    body: AdapterActionRequest,
    request: Request,
    auth: Annotated[AuthContext, Depends(require_admin)],
) -> SuccessResponse[AdapterOperationResult]:
    """
    Reload an adapter with new configuration.

    Stops the adapter and restarts it with new configuration.
    Useful for applying configuration changes without full restart.
    Requires ADMIN role.
    """
    runtime_control = getattr(request.app.state, "main_runtime_control_service", None)
    if not runtime_control:
        raise HTTPException(status_code=503, detail=ERROR_RUNTIME_CONTROL_SERVICE_NOT_AVAILABLE)

    try:
        # Get current adapter info to preserve type
        adapter_info = await runtime_control.get_adapter_info(adapter_id)
        if not adapter_info:
            raise HTTPException(status_code=404, detail=f"Adapter '{adapter_id}' not found")

        # First unload the adapter
        unload_result = await runtime_control.unload_adapter(adapter_id, force=False)
        if not unload_result.success:
            raise HTTPException(status_code=400, detail=f"Failed to unload adapter: {unload_result.error}")

        # Then reload with new config
        # Merge persist flag into config for RuntimeAdapterManager
        config = body.config or {}
        if isinstance(config, dict):
            config["persist"] = body.persist

        load_result = await runtime_control.load_adapter(
            adapter_type=adapter_info.adapter_type,
            adapter_id=adapter_id,
            config=config,
        )

        # Convert response
        response = AdapterOperationResult(
            success=load_result.success,
            adapter_id=load_result.adapter_id,
            adapter_type=adapter_info.adapter_type,
            message=(
                f"Adapter {adapter_id} reloaded successfully"
                if load_result.success
                else f"Reload failed: {load_result.error}"
            ),
            error=load_result.error,
            details={"timestamp": load_result.timestamp.isoformat()},
        )

        return SuccessResponse(data=response)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error reloading adapter: {e}")
        raise HTTPException(status_code=500, detail=str(e))
