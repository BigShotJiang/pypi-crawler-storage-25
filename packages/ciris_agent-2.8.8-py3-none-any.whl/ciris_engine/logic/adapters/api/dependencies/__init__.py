"""API dependencies module."""
