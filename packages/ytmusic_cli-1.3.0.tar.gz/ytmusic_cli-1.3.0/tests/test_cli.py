"""Tests for CLI argument parsing."""

from ytmusic.cli import create_parser


def test_cli_defaults():
    parser = create_parser()
    args = parser.parse_args(["https://example.com"])

    assert args.format == "m4a"
    assert args.bitrate == "192k"
    assert args.no_convert is False
    assert args.quiet is False
    assert args.verbose is False
    assert args.summary is False


def test_cli_flags():
    parser = create_parser()
    args = parser.parse_args(
        [
            "https://example.com",
            "--format",
            "mp3",
            "--bitrate",
            "256k",
            "--no-convert",
            "--quiet",
            "--verbose",
            "--summary",
        ]
    )

    assert args.format == "mp3"
    assert args.bitrate == "256k"
    assert args.no_convert is True
    assert args.quiet is True
    assert args.verbose is True
    assert args.summary is True
