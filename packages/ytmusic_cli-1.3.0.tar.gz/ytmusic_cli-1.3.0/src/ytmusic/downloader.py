"""YouTube playlist and audio downloading functionality."""

import os
import shutil
import subprocess
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from time import perf_counter
from typing import Optional

from pytubefix import Playlist, YouTube
from pytubefix.cli import on_progress
from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
    TimeRemainingColumn,
)

from ytmusic.metadata import download_cover_art, search_itunes_metadata
from ytmusic.tagger import embed_metadata
from ytmusic.utils import extract_song_info, format_filename_from_metadata, sanitize_filename

console = Console()


class PlaylistDownloader:
    """Handles downloading and processing of YouTube playlists."""

    def __init__(
        self,
        similarity_threshold: float = 0.5,
        output_dir: str = "music_library",
        output_format: str = "m4a",
        bitrate: str = "192k",
        convert: bool = True,
        quiet: bool = False,
        verbose: bool = False,
        summary: bool = False,
        max_workers: Optional[int] = None,
    ):
        self.similarity_threshold = similarity_threshold
        self.output_dir = Path(output_dir)
        self.output_format = output_format
        self.bitrate = bitrate
        self.convert = convert
        self.quiet = quiet
        self.verbose = verbose
        self.summary = summary
        self.max_workers = max_workers or min(32, (os.cpu_count() or 1) + 4)
        self._lock = threading.Lock()
        self.skipped_count = 0
        self.downloaded_count = 0
        self.error_count = 0

    def get_best_audio_stream(self, yt: YouTube) -> Optional:
        """Get the best quality audio-only stream."""
        audio_streams = yt.streams.filter(only_audio=True)

        if not audio_streams:
            return None

        # Prefer AAC/mp4a codec for best compatibility
        for stream in audio_streams:
            if stream.audio_codec and ("mp4a" in stream.audio_codec or "aac" in stream.audio_codec):
                return stream

        # Fall back to first available
        return audio_streams.first()

    def _log(self, message: str):
        if not self.quiet:
            console.print(message)

    def _log_verbose(self, message: str):
        if self.verbose and not self.quiet:
            console.print(message)

    def _log_error(self, message: str):
        console.print(message)

    def _unique_path(self, path: Path) -> Path:
        """Ensure output path does not collide with an existing file."""
        if not path.exists():
            return path

        counter = 1
        while True:
            candidate = path.with_name(f"{path.stem}_{counter}{path.suffix}")
            if not candidate.exists():
                return candidate
            counter += 1

    def _extension_from_stream(self, stream: YouTube) -> str:
        """Best-effort extension from stream mime type."""
        mime_type = getattr(stream, "mime_type", "") or ""
        if "/" not in mime_type:
            return ""

        subtype = mime_type.split("/", 1)[1].lower()
        mapping = {
            "webm": ".webm",
            "mp4": ".m4a",
            "mpeg": ".mp3",
            "aac": ".aac",
            "ogg": ".ogg",
            "x-m4a": ".m4a",
            "x-ms-wma": ".wma",
            "wav": ".wav",
            "flac": ".flac",
        }
        return mapping.get(subtype, "")

    def _convert_audio(self, source_path: Path, target_ext: str) -> Path | None:
        """Convert audio using ffmpeg if available."""
        if shutil.which("ffmpeg") is None:
            return None

        target_path = self._unique_path(source_path.with_suffix(target_ext))
        codec = "aac" if target_ext == ".m4a" else "libmp3lame"
        try:
            subprocess.run(
                [
                    "ffmpeg",
                    "-y",
                    "-i",
                    str(source_path),
                    "-vn",
                    "-c:a",
                    codec,
                    "-b:a",
                    self.bitrate,
                    str(target_path),
                ],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return target_path
        except subprocess.CalledProcessError:
            return None

    def _truncate(self, text: str, max_len: int = 60) -> str:
        if len(text) <= max_len:
            return text
        return text[: max_len - 1] + "…"

    def download_song(
        self,
        video_url: str,
        playlist_dir: Path,
        idx: int,
        total: int,
        progress: Progress | None = None,
        task_id: int | None = None,
    ) -> bool:
        """Download and process a single song. Returns True if successful."""
        try:
            yt = YouTube(video_url, on_progress_callback=on_progress)
            youtube_title = yt.title
            if progress is not None and task_id is not None:
                progress.update(
                    task_id, description=f"[{idx}/{total}] {self._truncate(youtube_title)}"
                )

            # Extract song info
            artist, song = extract_song_info(youtube_title)

            # Search metadata first (before downloading)
            metadata = None
            similarity = 0.0

            if artist and song:
                metadata, similarity = search_itunes_metadata(artist, song, youtube_title)

            if not metadata:
                metadata, similarity = search_itunes_metadata(None, youtube_title, youtube_title)

            # Skip if similarity is too low
            if similarity < self.similarity_threshold:
                self._log(
                    f"[yellow]⏭[/yellow] Skipping (low similarity {similarity:.0%}): {youtube_title}"
                )
                with self._lock:
                    self.skipped_count += 1
                return False

            # Generate filename from metadata
            target_filename = format_filename_from_metadata(metadata) or sanitize_filename(
                youtube_title
            )
            target_filename = sanitize_filename(target_filename)

            # Check if already exists
            existing_files = list(playlist_dir.glob(f"{target_filename}.*"))
            if existing_files:
                self._log(
                    f"[yellow]⏭[/yellow] Skipping (already exists): {existing_files[0].name}"
                )
                with self._lock:
                    self.skipped_count += 1
                return False

            # Check for incomplete marker (resumed download)
            marker_path = playlist_dir / f".incomplete_{target_filename}"
            if marker_path.exists():
                self._log(
                    f"[yellow]⟳[/yellow] Resuming: {target_filename}"
                )
            else:
                # Create marker to indicate download in progress
                marker_path.touch()

            # Get audio stream
            audio_stream = self.get_best_audio_stream(yt)
            if not audio_stream:
                self._log_error(f"[red]✗[/red] No audio stream for: {youtube_title}")
                with self._lock:
                    self.error_count += 1
                marker_path.unlink(missing_ok=True)
                return False
            self._log_verbose(
                f"[dim]Stream: {audio_stream.mime_type} / {audio_stream.audio_codec}[/dim]"
            )

            # Download
            temp_file = audio_stream.download(output_path=str(playlist_dir), filename=f"temp_{idx}_{threading.current_thread().ident}")
            file_ext = Path(temp_file).suffix
            if not file_ext:
                file_ext = self._extension_from_stream(audio_stream)

            # Rename to final filename
            final_filename = f"{target_filename}{file_ext}" if file_ext else target_filename
            final_path = playlist_dir / final_filename

            # Handle duplicates
            final_path = self._unique_path(final_path)

            os.rename(temp_file, final_path)

            # Remove incomplete marker on success
            marker_path.unlink(missing_ok=True)

            # Convert based on output format if requested
            taggable_exts = {".m4a", ".mp4", ".aac", ".mp3"}
            if self.output_format in {"m4a", "mp3"} and self.convert:
                target_ext = ".m4a" if self.output_format == "m4a" else ".mp3"
                if final_path.suffix.lower() != target_ext:
                    converted_path = self._convert_audio(final_path, target_ext)
                    if converted_path:
                        final_path.unlink(missing_ok=True)
                        final_path = converted_path
                        file_ext = final_path.suffix
                        self._log_verbose(
                            f"[dim]Converted to {final_path.suffix} at {self.bitrate}[/dim]"
                        )
                    else:
                        self._log(
                            "[yellow]⚠ ffmpeg not available; keeping original format.[/yellow]"
                        )
            elif final_path.suffix.lower() not in taggable_exts:
                if self.convert and self.output_format != "original":
                    self._log(
                        "[yellow]⚠ Unsupported format and conversion disabled.[/yellow]"
                    )

            # Download cover art
            cover_art = None
            if metadata and metadata.get("cover_url"):
                cover_art = download_cover_art(metadata["cover_url"])

            # Embed metadata
            if final_path.suffix.lower() in taggable_exts:
                embed_metadata(str(final_path), file_ext, metadata, cover_art)
            else:
                self._log(
                    f"[yellow]⚠ Skipping metadata embedding for unsupported format: {final_path.suffix}[/yellow]"
                )

            self._log(
                f"[green]✓[/green] Downloaded: [bold]{final_path.name}[/bold] ([cyan]{similarity:.0%}[/cyan] match)"
            )
            with self._lock:
                self.downloaded_count += 1
            return True

        except Exception as e:
            self._log_error(f"[red]✗[/red] Error processing video: {e}")
            with self._lock:
                self.error_count += 1
            # Clean up marker on error
            try:
                marker_path = playlist_dir / f".incomplete_{target_filename}"
                marker_path.unlink(missing_ok=True)
            except NameError:
                pass  # target_filename not defined yet
            return False

    def process(self, playlist_url: str):
        """Process entire playlist."""
        self._log(
            Panel.fit(
                "[bold cyan]🎵 YouTube Music Library[/bold cyan]",
                subtitle=f"Threshold: {self.similarity_threshold:.0%}",
                border_style="cyan",
            )
        )

        # Fetch playlist info
        with console.status("[bold green]Fetching playlist info..."):
            playlist = Playlist(playlist_url)
            playlist_title = sanitize_filename(playlist.title)

        self._log(f"[green]✓[/green] Playlist: [bold]{playlist.title}[/bold]")
        self._log(f"[green]✓[/green] {len(playlist.video_urls)} videos\n")

        # Create output directory
        playlist_dir = self.output_dir / playlist_title
        playlist_dir.mkdir(parents=True, exist_ok=True)

        # Process videos concurrently
        start = perf_counter()
        with Progress(
            SpinnerColumn(),
            TextColumn("[bold blue]{task.description}"),
            BarColumn(bar_width=40),
            TaskProgressColumn(),
            TimeRemainingColumn(),
            console=console,
        ) as progress:
            task = progress.add_task("Processing songs...", total=len(playlist.video_urls))

            # Clean up any stale incomplete markers from previous interrupted runs
            for marker in playlist_dir.glob(".incomplete_*"):
                marker.unlink()
                self._log(f"[dim]Cleaned up stale marker: {marker.name}[/dim]")

            # Submit all download tasks to thread pool
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                future_to_url = {
                    executor.submit(
                        self.download_song,
                        video_url,
                        playlist_dir,
                        idx,
                        len(playlist.video_urls),
                        progress=progress,
                        task_id=task,
                    ): (idx, video_url)
                    for idx, video_url in enumerate(playlist.video_urls, 1)
                }

                # Process completed downloads as they finish
                for future in as_completed(future_to_url):
                    idx, video_url = future_to_url[future]
                    try:
                        future.result()
                    except Exception as e:
                        self._log_error(f"[red]✗[/red] Unexpected error for video {idx}: {e}")
                        with self._lock:
                            self.error_count += 1
                    progress.advance(task)

        # Summary
        duration = perf_counter() - start
        if self.summary or not self.quiet:
            self._log("\n[bold green]✓ Complete![/bold green]")
            self._log(f"  Downloaded: {self.downloaded_count}")
            self._log(f"  Skipped: {self.skipped_count}")
            self._log(f"  Errors: {self.error_count}")
            self._log(f"  Time: {duration:.1f}s")
            self._log(f"\nLocation: {playlist_dir}")
