"""Command-line interface for YouTube Music Library."""

import argparse
import ssl
import sys

from rich.console import Console

from ytmusic import __version__
from ytmusic.downloader import PlaylistDownloader

try:
    import certifi
except Exception:  # pragma: no cover - optional at runtime
    certifi = None

console = Console()


def create_parser() -> argparse.ArgumentParser:
    """Create and configure argument parser."""
    parser = argparse.ArgumentParser(
        prog="ytmusic",
        description="Download YouTube playlists as audio with rich metadata",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic usage
  ytmusic "https://www.youtube.com/playlist?list=PLAYLIST_ID"

  # Custom output directory with stricter matching
  ytmusic "PLAYLIST_URL" -o "my_music" -t 0.7

  # Dry run (see what would be downloaded)
  ytmusic "PLAYLIST_URL" --dry-run

  # Skip existing files
  ytmusic "PLAYLIST_URL" --skip-existing

Threshold Guide:
  0.3 - Lenient (more songs, less accurate metadata)
  0.5 - Balanced (default)
  0.7 - Strict (fewer songs, more accurate metadata)
  0.9 - Very strict (only exact matches)
        """,
    )

    # Required arguments
    parser.add_argument("url", help="YouTube playlist URL or ID")

    # Optional arguments
    parser.add_argument(
        "-o",
        "--output",
        default="music_library",
        metavar="DIR",
        help="Output directory for downloaded music (default: music_library)",
    )

    parser.add_argument(
        "-t",
        "--threshold",
        type=float,
        default=0.5,
        metavar="0.0-1.0",
        help="Similarity threshold for metadata matching 0.0-1.0 (default: 0.5)",
    )

    parser.add_argument(
        "--format",
        choices=["m4a", "mp3", "original"],
        default="m4a",
        help="Output format: m4a, mp3, or original (default: m4a)",
    )

    parser.add_argument(
        "--bitrate",
        default="192k",
        help="Audio bitrate for conversion (default: 192k)",
    )

    parser.add_argument(
        "--no-convert",
        action="store_true",
        help="Disable conversion even if format is set (keeps original)",
    )

    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Reduce output to errors only",
    )

    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Show extra details during processing",
    )

    parser.add_argument(
        "--summary",
        action="store_true",
        help="Print a structured summary at the end",
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview what would be downloaded without downloading",
    )

    parser.add_argument(
        "--workers",
        type=int,
        metavar="N",
        help="Number of concurrent download workers (default: auto-scaled based on CPU cores)",
    )

    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")

    return parser


def validate_args(args) -> bool:
    """Validate command line arguments."""
    if args.threshold < 0.0 or args.threshold > 1.0:
        console.print("[red]Error: Threshold must be between 0.0 and 1.0[/red]")
        return False

    # Validate URL
    if "youtube.com" not in args.url and "youtu.be" not in args.url:
        if not args.url.startswith("PL"):
            console.print("[red]Error: Invalid YouTube URL[/red]")
            return False
        else:
            # Assume it's just a playlist ID
            args.url = f"https://www.youtube.com/playlist?list={args.url}"

    return True


def main(args=None):
    """Main CLI entry point."""
    if certifi is not None:
        ssl._create_default_https_context = lambda: ssl.create_default_context(
            cafile=certifi.where()
        )

    parser = create_parser()
    args = parser.parse_args(args)

    if not validate_args(args):
        sys.exit(1)

    # Handle dry run
    if args.dry_run:
        console.print("[yellow]Dry run mode - no files will be downloaded[/yellow]\n")
        from pytubefix import Playlist

        from ytmusic.metadata import search_itunes_metadata
        from ytmusic.utils import extract_song_info

        playlist = Playlist(args.url)
        console.print(f"Playlist: [bold]{playlist.title}[/bold]")
        console.print(f"Videos: {len(playlist.video_urls)}\n")

        for idx, url in enumerate(playlist.video_urls, 1):
            from pytubefix import YouTube

            yt = YouTube(url)
            artist, song = extract_song_info(yt.title)
            metadata, similarity = (
                search_itunes_metadata(artist, song, yt.title) if artist and song else (None, 0)
            )
            if not metadata:
                metadata, similarity = search_itunes_metadata(None, yt.title, yt.title)

            status = "[green]✓[/green]" if similarity >= args.threshold else "[red]✗[/red]"
            console.print(f"{status} [{idx}] {yt.title[:50]}... ({similarity:.0%} match)")

        console.print("\n[dim]Use without --dry-run to download[/dim]")
        return

    # Run downloader
    downloader = PlaylistDownloader(
        similarity_threshold=args.threshold,
        output_dir=args.output,
        output_format=args.format,
        bitrate=args.bitrate,
        convert=not args.no_convert,
        quiet=args.quiet,
        verbose=args.verbose,
        summary=args.summary,
        max_workers=args.workers,
    )
    downloader.process(args.url)


if __name__ == "__main__":
    main()
