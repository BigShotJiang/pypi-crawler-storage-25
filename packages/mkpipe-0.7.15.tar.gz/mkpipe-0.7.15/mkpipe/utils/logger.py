import json
import logging
import logging.handlers
import os
import time
import traceback
from pathlib import Path
from typing import Optional


_LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO').upper()
_GLOBAL_LOG_DIR: Optional[str] = os.getenv('MKPIPE_LOG_DIR')
_LOG_LEVELS = {
    'debug': logging.DEBUG,
    'info': logging.INFO,
    'warning': logging.WARNING,
    'error': logging.ERROR,
    'critical': logging.CRITICAL,
}
_DEFAULT_LOG_LEVEL = _LOG_LEVELS.get(_LOG_LEVEL.lower(), logging.INFO)

_LOG_FORMAT = (
    '{"timestamp": "%(asctime)s", "level": "%(levelname)s", '
    '"log": %(message)s, "module": "%(name)s"}'
)

_file_handler_installed = False


def _install_file_handler(log_dir: str) -> None:
    """Add a file handler to the root logger so every logger writes to file."""
    global _file_handler_installed
    if _file_handler_installed:
        return

    log_path = Path(log_dir)
    log_path.mkdir(parents=True, exist_ok=True)
    file_path = log_path / 'mkpipe.log'

    json_formatter = logging.Formatter(_LOG_FORMAT)
    json_formatter.converter = time.gmtime

    fh = logging.handlers.TimedRotatingFileHandler(
        file_path, when='midnight', backupCount=7
    )
    fh.setLevel(_DEFAULT_LOG_LEVEL)
    fh.setFormatter(json_formatter)

    root = logging.getLogger()
    root.addHandler(fh)
    if root.level > _DEFAULT_LOG_LEVEL:
        root.setLevel(_DEFAULT_LOG_LEVEL)
    _file_handler_installed = True


# If env var is set at import time, install immediately
if _GLOBAL_LOG_DIR:
    _install_file_handler(_GLOBAL_LOG_DIR)


class Logger:
    def __init__(self, name: str, log_dir: Optional[str] = None):
        self.logger = logging.getLogger(name)

        if not self.logger.handlers:
            self.logger.setLevel(_DEFAULT_LOG_LEVEL)

            json_formatter = logging.Formatter(_LOG_FORMAT)
            json_formatter.converter = time.gmtime

            ch = logging.StreamHandler()
            ch.setLevel(_DEFAULT_LOG_LEVEL)
            ch.setFormatter(json_formatter)
            self.logger.addHandler(ch)

    def _format(self, message):
        if isinstance(message, str):
            return json.dumps(message)
        return json.dumps(message, sort_keys=True, default=str)

    def debug(self, message):
        self.logger.debug(self._format(message))

    def info(self, message):
        self.logger.info(self._format(message))

    def warning(self, message):
        self.logger.warning(self._format(message))

    def error(self, message):
        self.logger.error(self._format(message))

    def critical(self, message):
        self.logger.critical(self._format(message))


def set_log_dir(log_dir: Optional[str]) -> None:
    """Set global log directory. Installs a file handler on the root logger."""
    global _GLOBAL_LOG_DIR
    if log_dir is None or log_dir == _GLOBAL_LOG_DIR:
        return
    _GLOBAL_LOG_DIR = log_dir
    _install_file_handler(log_dir)


def get_logger(name: str, log_dir: Optional[str] = None) -> Logger:
    effective_dir = log_dir or _GLOBAL_LOG_DIR
    if effective_dir:
        _install_file_handler(effective_dir)
    return Logger(name)
