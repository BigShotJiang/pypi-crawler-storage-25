from setuptools import setup

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="gptperoz",  # ← Must match exactly!
    version="0.2.3",
    description="Train AI in 3 lines - The simplest PyTorch alternative",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="APerson091",
    url="https://github.com/APerson091/AL",
    py_modules=["al"],
    python_requires=">=3.8",
    install_requires=["numpy>=1.20.0"],
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)
