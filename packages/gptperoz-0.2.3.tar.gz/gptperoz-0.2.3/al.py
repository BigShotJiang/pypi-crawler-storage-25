"""
AL - Alchemy Learning Framework
3 Lines to Complete AI - CPU/GPU Auto-Optimized
Version 10.0.0 - Production Ready
"""

import json
import random
import math
import pickle
import gzip
import os
import hashlib
from collections import Counter, defaultdict
import time

# Auto-detect GPU
try:
    import numpy as np
    HAS_NUMPY = True
    try:
        import cupy as cp
        HAS_GPU = True
        DEVICE = 'cuda'
    except:
        HAS_GPU = False
        DEVICE = 'cpu'
except:
    HAS_NUMPY = False
    HAS_GPU = False
    DEVICE = 'cpu'

__version__ = "10.0.0"

# ============================================
# AUTO-OPTIMIZED TENSOR ENGINE
# ============================================

class Tensor:
    __slots__ = ('data', 'grad', 'requires_grad', 'device', '_op', '_ctx')
    
    def __init__(self, data, requires_grad=False, device=None):
        self.device = device or DEVICE
        self.requires_grad = requires_grad
        self.grad = None
        self._op = None
        self._ctx = None
        
        if HAS_NUMPY:
            if self.device == 'cuda' and HAS_GPU:
                self.data = cp.array(data, dtype=cp.float32)
            else:
                self.data = np.array(data, dtype=np.float32)
        else:
            if isinstance(data, (list, tuple)):
                self.data = [float(x) if not isinstance(x, list) else [float(y) for y in x] for x in data]
            else:
                self.data = float(data)
    
    def __add__(self, other):
        if not isinstance(other, Tensor):
            other = Tensor([other] * len(self.data) if hasattr(self, '__len__') else other)
        if HAS_NUMPY:
            out = Tensor(self.data + other.data, self.requires_grad or other.requires_grad)
        else:
            out = Tensor([a + b for a, b in zip(self.data, other.data)])
        out._op = ('add', self, other)
        return out
    
    def __mul__(self, other):
        if not isinstance(other, Tensor):
            other = Tensor(other)
        if HAS_NUMPY:
            out = Tensor(self.data * other.data, self.requires_grad or other.requires_grad)
        else:
            out = Tensor([a * b for a, b in zip(self.data, other.data)])
        out._op = ('mul', self, other)
        return out
    
    def __matmul__(self, other):
        if not isinstance(other, Tensor):
            other = Tensor(other)
        if HAS_NUMPY:
            out = Tensor(self.data @ other.data, self.requires_grad or other.requires_grad)
        else:
            out = self._matmul_pure(other)
        out._op = ('matmul', self, other)
        return out
    
    def _matmul_pure(self, other):
        if isinstance(self.data[0], list):
            result = []
            for i in range(len(self.data)):
                row = []
                for j in range(len(other.data[0])):
                    val = sum(self.data[i][k] * other.data[k][j] for k in range(len(other.data)))
                    row.append(val)
                result.append(row)
            return Tensor(result)
        return Tensor([sum(a * b for a, b in zip(self.data, other.data))])
    
    def relu(self):
        if HAS_NUMPY:
            out = Tensor(np.maximum(0, self.data), self.requires_grad)
        else:
            out = Tensor([max(0, x) for x in self.data])
        out._op = ('relu', self)
        return out
    
    def softmax(self):
        if HAS_NUMPY:
            x = self.data - self.data.max()
            exp = np.exp(x)
            out = Tensor(exp / exp.sum(), self.requires_grad)
        else:
            x = self.data
            max_x = max(x)
            exp = [math.exp(v - max_x) for v in x]
            total = sum(exp)
            out = Tensor([e / total for e in exp])
        return out
    
    def sum(self):
        if HAS_NUMPY:
            out = Tensor(self.data.sum())
        else:
            out = Tensor(sum(self.data))
        return out
    
    def mean(self):
        if HAS_NUMPY:
            out = Tensor(self.data.mean())
        else:
            out = Tensor(sum(self.data) / len(self.data))
        return out
    
    def reshape(self, *shape):
        if HAS_NUMPY:
            out = Tensor(self.data.reshape(*shape))
        else:
            out = Tensor(self.data)
        return out
    
    def to(self, device):
        if device == 'cuda' and HAS_GPU:
            self.data = cp.array(self.data)
        elif device == 'cpu' and HAS_NUMPY:
            self.data = np.array(self.data)
        self.device = device
        return self
    
    def numpy(self):
        if self.device == 'cuda' and HAS_GPU:
            return cp.asnumpy(self.data)
        return self.data
    
    def __len__(self):
        return len(self.data) if hasattr(self.data, '__len__') else 1
    
    def __getitem__(self, idx):
        return self.data[idx]


# ============================================
# CUSTOM LOGIC ENGINE
# ============================================

class LogicEngine:
    """Custom logic rules for deterministic responses"""
    
    def __init__(self):
        self.rules = []
        self.patterns = {}
        self.functions = {}
    
    def add_rule(self, condition, action):
        self.rules.append({'if': condition, 'then': action})
        return self
    
    def add_pattern(self, pattern, response):
        self.patterns[pattern.lower()] = response
        return self
    
    def add_function(self, name, func):
        self.functions[name] = func
        return self
    
    def apply(self, text):
        text = text.lower()
        
        # Check patterns
        for pattern, response in self.patterns.items():
            if pattern in text:
                return response
        
        # Check rules
        for rule in self.rules:
            if eval(rule['if'], {'text': text, 'len': len}):
                return rule['then'](text) if callable(rule['then']) else rule['then']
        
        return None


# ============================================
# MAIN AI CLASS - 3 LINES TO COMPLETE
# ============================================

class AI:
    """Main AI - 3 lines complete"""
    
    def __init__(self, name="al", device='auto'):
        self.name = name
        self.device = device if device != 'auto' else DEVICE
        self.vocab = {'<PAD>': 0, '<UNK>': 1, '<S>': 2, '<E>': 3}
        self.rev = {0: '<PAD>', 1: '<UNK>', 2: '<S>', 3: '<E>'}
        self.embeddings = None
        self.weights = None
        self.bias = None
        self.logic = LogicEngine()
        self.history = {'loss': [], 'ppl': []}
        self.config = {'dim': 64, 'layers': 2}
        self.trained = False
        self._cache = {}
        
    def learn(self, data_source, epochs=10, lr=0.01, **kwargs):
        """Auto-detect and learn from any data source"""
        
        # Auto-load data
        if isinstance(data_source, str):
            if data_source.endswith('.json'):
                with open(data_source, 'r') as f:
                    data = json.load(f)
            elif data_source.endswith('.txt'):
                with open(data_source, 'r') as f:
                    text = f.read()
                    data = self._text_to_qa(text)
            else:
                data = [{"input": "hello", "output": "hi"}]
        else:
            data = data_source
        
        # Auto-configure based on data size
        self._auto_config(len(data), kwargs)
        
        # Build vocab
        self._build_vocab(data)
        V = len(self.vocab)
        dim = self.config['dim']
        
        # Initialize weights
        scale = math.sqrt(2.0 / dim)
        self.embeddings = [[random.uniform(-scale, scale) for _ in range(dim)] for _ in range(V)]
        self.weights = [[random.uniform(-scale, scale) for _ in range(V)] for _ in range(dim)]
        self.bias = [0.0] * V
        
        # Prepare training data
        train_data = []
        for d in data:
            q = d.get('input', d.get('question', d.get('q', '')))
            a = d.get('output', d.get('answer', d.get('a', d.get('response', ''))))
            if q and a:
                train_data.append((q, a))
        
        if not train_data:
            print("No training data found!")
            return self
        
        # Train
        print(f"Training on {DEVICE.upper()} - {len(train_data)} samples")
        
        for epoch in range(epochs):
            epoch_loss = 0
            random.shuffle(train_data)
            
            for q, a in train_data:
                # Forward pass
                q_tokens = [2] + [self.vocab.get(w, 1) for w in q.lower().split()] + [3]
                a_tokens = [self.vocab.get(w, 1) for w in a.lower().split()] + [3]
                
                # Simple context embedding
                ctx_emb = [0.0] * dim
                count = 0
                for tok in q_tokens[-5:]:
                    if tok < V:
                        for i in range(dim):
                            ctx_emb[i] += self.embeddings[tok][i]
                        count += 1
                
                if count > 0:
                    ctx_emb = [e / count for e in ctx_emb]
                
                # Predict each token
                for target in a_tokens[:10]:
                    if target >= V:
                        continue
                    
                    # Forward
                    logits = [0.0] * V
                    for v in range(V):
                        val = self.bias[v]
                        for d in range(dim):
                            val += ctx_emb[d] * self.weights[d][v]
                        logits[v] = val
                    
                    # Softmax
                    max_logit = max(logits)
                    exp_sum = sum(math.exp(l - max_logit) for l in logits)
                    probs = [math.exp(l - max_logit) / exp_sum for l in logits]
                    
                    # Loss
                    loss = -math.log(probs[target] + 1e-8)
                    epoch_loss += loss
                    
                    # Backward
                    for v in range(V):
                        err = probs[v] - (1.0 if v == target else 0.0)
                        self.bias[v] -= lr * err
                        for d in range(dim):
                            self.weights[d][v] -= lr * err * ctx_emb[d]
            
            avg_loss = epoch_loss / len(train_data)
            ppl = math.exp(avg_loss)
            self.history['loss'].append(avg_loss)
            self.history['ppl'].append(ppl)
            
            if (epoch + 1) % max(1, epochs // 5) == 0:
                print(f"Epoch {epoch+1}/{epochs} - Loss: {avg_loss:.4f} - PPL: {ppl:.2f}")
        
        self.trained = True
        return self
    
    def _auto_config(self, data_size, kwargs):
        """Auto-configure based on data size"""
        if data_size < 100:
            self.config['dim'] = kwargs.get('dim', 32)
            self.config['layers'] = kwargs.get('layers', 1)
        elif data_size < 1000:
            self.config['dim'] = kwargs.get('dim', 64)
            self.config['layers'] = kwargs.get('layers', 2)
        else:
            self.config['dim'] = kwargs.get('dim', 128)
            self.config['layers'] = kwargs.get('layers', 3)
    
    def _build_vocab(self, data):
        """Build vocabulary from data"""
        for d in data:
            text = str(d.get('input', '')) + ' ' + str(d.get('output', ''))
            for w in text.lower().split():
                if w not in self.vocab:
                    self.vocab[w] = len(self.vocab)
                    self.rev[len(self.rev)] = w
    
    def _text_to_qa(self, text):
        """Convert plain text to Q&A pairs"""
        lines = [l.strip() for l in text.split('\n') if l.strip()]
        data = []
        for i in range(0, len(lines) - 1, 2):
            if i + 1 < len(lines):
                data.append({'input': lines[i], 'output': lines[i+1]})
        return data
    
    def chat(self, prompt="", max_len=50, temp=0.8, use_cache=True):
        """Generate response with caching"""
        
        # Check cache
        cache_key = f"{prompt}_{temp}"
        if use_cache and cache_key in self._cache:
            return self._cache[cache_key]
        
        # Check logic engine
        logic_response = self.logic.apply(prompt)
        if logic_response:
            return logic_response
        
        if not self.trained:
            return "Not trained yet!"
        
        V = len(self.vocab)
        dim = self.config['dim']
        
        # Tokenize prompt
        tokens = [2]
        for w in prompt.lower().split():
            tokens.append(self.vocab.get(w, 1))
        
        # Generate
        generated = []
        for _ in range(max_len):
            # Context embedding
            ctx_emb = [0.0] * dim
            count = 0
            for tok in tokens[-5:]:
                if tok < V:
                    for i in range(dim):
                        ctx_emb[i] += self.embeddings[tok][i]
                    count += 1
            
            if count > 0:
                ctx_emb = [e / count for e in ctx_emb]
            
            # Predict
            logits = [0.0] * V
            for v in range(V):
                val = self.bias[v]
                for d in range(dim):
                    val += ctx_emb[d] * self.weights[d][v]
                logits[v] = val
            
            # Temperature scaling
            logits = [l / temp for l in logits]
            
            # Softmax
            max_logit = max(logits)
            exp_sum = sum(math.exp(l - max_logit) for l in logits)
            probs = [math.exp(l - max_logit) / exp_sum for l in logits]
            
            # Sample
            r = random.random()
            cumsum = 0
            next_tok = 0
            for i, p in enumerate(probs):
                cumsum += p
                if r < cumsum:
                    next_tok = i
                    break
            
            if next_tok == 3:  # <E>
                break
            
            tokens.append(next_tok)
            if next_tok >= 4:
                generated.append(self.rev.get(next_tok, ''))
        
        response = ' '.join(generated) if generated else "I don't understand."
        
        # Cache response
        if use_cache:
            self._cache[cache_key] = response
            if len(self._cache) > 100:
                self._cache.pop(next(iter(self._cache)))
        
        return response
    
    def add_rule(self, condition, action):
        """Add custom logic rule"""
        self.logic.add_rule(condition, action)
        return self
    
    def add_pattern(self, pattern, response):
        """Add pattern-response pair"""
        self.logic.add_pattern(pattern, response)
        return self
    
    def save(self, path):
        """Save model"""
        if not path.endswith('.llk'):
            path += '.llk'
        
        data = {
            'vocab': self.vocab,
            'rev': self.rev,
            'embeddings': self.embeddings,
            'weights': self.weights,
            'bias': self.bias,
            'config': self.config,
            'history': self.history,
            'trained': self.trained,
            'patterns': self.logic.patterns
        }
        
        with gzip.open(path, 'wb') as f:
            pickle.dump(data, f)
        
        print(f"Saved: {path}")
        return self
    
    def load(self, path):
        """Load model"""
        with gzip.open(path, 'rb') as f:
            data = pickle.load(f)
        
        self.vocab = data['vocab']
        self.rev = data['rev']
        self.embeddings = data['embeddings']
        self.weights = data['weights']
        self.bias = data.get('bias', [0.0] * len(self.vocab))
        self.config = data.get('config', {'dim': 64, 'layers': 2})
        self.history = data.get('history', {'loss': [], 'ppl': []})
        self.trained = data.get('trained', True)
        self.logic.patterns = data.get('patterns', {})
        
        print(f"Loaded: {path}")
        return self
    
    def clear_cache(self):
        """Clear response cache"""
        self._cache.clear()
        return self
    
    def info(self):
        """Show model info"""
        print(f"AL v{__version__}")
        print(f"Device: {DEVICE}")
        print(f"Vocab: {len(self.vocab)} tokens")
        print(f"Config: dim={self.config['dim']}, layers={self.config['layers']}")
        print(f"Trained: {self.trained}")
        if self.history['loss']:
            print(f"Final Loss: {self.history['loss'][-1]:.4f}")
        print(f"Patterns: {len(self.logic.patterns)}")
        print(f"Cache: {len(self._cache)} items")
        return self


# ============================================
# 3-LINE API
# ============================================

def make(name="al", device='auto'):
    """Line 1: Create AI"""
    return AI(name, device)

def quick(data, epochs=10, name="al"):
    """All-in-one: create + train + ready"""
    ai = AI(name)
    ai.learn(data, epochs=epochs)
    return ai

def load(path):
    """Load saved AI"""
    return AI().load(path)

# Welcome message
print(f"AL v{__version__} - 3 Lines to AI | Device: {DEVICE}")
