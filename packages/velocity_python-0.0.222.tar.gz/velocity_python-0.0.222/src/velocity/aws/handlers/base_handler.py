"""
Base Handler Module

This module provides a base class for handling AWS Lambda events.
It includes common functionality shared between LambdaHandler and SqsHandler.
"""

import logging
import os
import sys
import traceback
from typing import Any, Dict, List, Optional

from velocity.aws.handlers import context as VelocityContext
from velocity.aws.handlers.context_factory import ContextFactory
from velocity.aws.handlers.exceptions import AlertError

logger = logging.getLogger(__name__)


class BaseHandler:
    """
    Base class for handling AWS Lambda events.

    Provides common functionality including action routing, logging,
    and error handling hooks that can be shared across different handler types.
    """

    def __init__(
        self,
        aws_event: Dict[str, Any],
        aws_context: Any,
        context_factory: Optional[ContextFactory] = None,
        context_class=VelocityContext.Context,
    ):
        """
        Initialize the base handler.

        Args:
            aws_event: The AWS Lambda event
            aws_context: The AWS Lambda context object
            context_class: The context class to use for processing
        """
        self.aws_event = aws_event
        self.aws_context = aws_context
        self.serve_action_default = True  # Set to False to disable OnActionDefault
        self.skip_action = False  # Set to True to skip all actions
        if context_factory is None:
            context_factory = ContextFactory(context_class=context_class)
        self.context_factory = context_factory
        self.context = None

    def create_context(self, *, args, postdata, response, session):
        self.context = self.context_factory.create(
            aws_event=self.aws_event,
            aws_context=self.aws_context,
            args=args,
            postdata=postdata,
            response=response,
            session=session,
        )
        return self.context

    def _update_lambda_ca_certificates(self):
        """Configure SSL certificates for HTTPS requests in Lambda environments."""
        # This is helpful for running HTTPS clients on lambda.
        if os.path.exists("/opt/python/ca-certificates.crt"):
            os.environ["REQUESTS_CA_BUNDLE"] = "/opt/python/ca-certificates.crt"
        elif os.path.exists("/home/ubuntu/PyLibLayer/ca-certificates.crt"):
            os.environ["REQUESTS_CA_BUNDLE"] = (
                "/home/ubuntu/PyLibLayer/ca-certificates.crt"
            )

    def get_calling_function(self) -> str:
        """
        Get the name of the calling function by inspecting the call stack.

        Returns:
            The name of the calling function or "<Unknown>" if not found
        """
        skip_functions = {"x", "log", "_transaction", "get_calling_function"}

        for idx in range(10):  # Limit search to prevent infinite loops
            try:
                frame = sys._getframe(idx)
                function_name = frame.f_code.co_name

                if function_name not in skip_functions:
                    return function_name

            except ValueError:
                # No more frames in the stack
                break

        return "<Unknown>"

    def format_action_name(self, action: str) -> str:
        """
        Format an action string into a method name.

        Args:
            action: The raw action string (e.g., "create-user", "delete_item")

        Returns:
            Formatted method name (e.g., "OnActionCreateUser", "OnActionDeleteItem")
        """
        if not action:
            return ""

        formatted = action.replace("-", " ").replace("_", " ")
        return f"on action {formatted}".title().replace(" ", "")

    def get_actions_to_execute(self, action: Optional[str]) -> List[str]:
        """
        Get the list of actions to execute.

        Args:
            action: The specific action to execute, if any

        Returns:
            List of action method names to try executing
        """
        actions = []

        # Add specific action if available
        if action:
            action_method = self.format_action_name(action)
            actions.append(action_method)

        # Add default action if enabled
        if self.serve_action_default:
            actions.append("OnActionDefault")

        return actions

    def execute_actions(self, tx, local_context, actions: List[str]) -> bool:
        """
        Execute the appropriate actions for the given context.

        Args:
            tx: Database transaction object
            local_context: The context object
            actions: List of action method names to try

        Returns:
            True if an action was executed, False otherwise
        """
        local_context.perf.start("execute_actions total")

        # Execute beforeAction hook if available
        if hasattr(self, "beforeAction"):
            local_context.perf.start("beforeAction")
            self.beforeAction(tx, local_context)
            local_context.perf.log(
                "beforeAction",
                extra={"action": getattr(local_context, "action", lambda: None)()},
            )

        action_executed = False

        # Execute the first matching action
        for action in actions:
            if self.skip_action:
                break

            if hasattr(self, action):
                local_context.perf.start(action)
                result = getattr(self, action)(tx, local_context)
                local_context.perf.log(
                    action,
                    extra={"action": getattr(local_context, "action", lambda: None)()},
                )
                if result is not None:
                    # Gather diagnostic information
                    diagnostic_info = {
                        "note": "Handlers should return None so results are not ignored.",
                        "action": action,
                        "handler_class": self.__class__.__name__,
                    }

                    # Try to get payload/dataset information for debugging
                    try:
                        if hasattr(local_context, "postdata"):
                            diagnostic_info["postdata"] = local_context.postdata()
                        if hasattr(local_context, "action"):
                            diagnostic_info["context_action"] = local_context.action()
                        if hasattr(local_context, "dataset"):
                            diagnostic_info["dataset"] = local_context.dataset()
                    except Exception as e:
                        diagnostic_info["diagnostic_error"] = str(e)
                    logger.warning(
                        "Action %s returned an unexpected non-None result (%r).",
                        action,
                        result,
                        extra=diagnostic_info,
                    )
                action_executed = True
                break

        # Execute afterAction hook if available
        if hasattr(self, "afterAction"):
            local_context.perf.start("afterAction")
            self.afterAction(tx, local_context)
            local_context.perf.log(
                "afterAction",
                extra={"action": getattr(local_context, "action", lambda: None)()},
            )

        local_context.perf.log(
            "execute_actions total",
            extra={"action": getattr(local_context, "action", lambda: None)()},
        )

        return action_executed

    def handle_error(self, tx, local_context, exception: Exception):
        """
        Handle errors that occur during action execution.

        Args:
            tx: Database transaction object
            local_context: The context object
            exception: The exception that occurred
        """
        if isinstance(exception, AlertError):
            payload = {}
            try:
                payload = exception.get_payload() or {}
            except Exception:
                payload = {"message": str(exception)}

            title = payload.get("title") or "Notification"
            message = payload.get("message") or str(exception)
            toast = bool(payload.get("toast"))
            variant = (
                payload.get("variant")
                or payload.get("severity")
                or payload.get("level")
                or "error"
            )

            logger.warning(
                "AlertError during action execution",
                exc_info=True,
                extra={
                    "handler": self.__class__.__name__,
                    "action": getattr(local_context, "action", lambda: None)(),
                    "tx_present": tx is not None,
                },
            )

            # Default behavior: raising AlertError surfaces a UI alert.
            # If `toast: true` is present in the payload, show a toast instead.
            if toast:
                local_context.response().toast(message, variant)
            else:
                local_context.response().alert(message=message, title=title)
            return

        # Always log the original exception so it isn't lost if the error-path
        # (e.g. job-status updates) fails due to a transient DB disconnect.
        logger.exception(
            "Unhandled exception during action execution",
            extra={
                "handler": self.__class__.__name__,
                "action": getattr(local_context, "action", lambda: None)(),
                "tx_present": tx is not None,
            },
        )

        if hasattr(self, "onError"):
            try:
                self.onError(
                    tx,
                    local_context,
                    exc=exception,
                    tb=traceback.format_exc(),
                )
            except Exception as on_error_exc:
                if self._is_transient_db_disconnect(on_error_exc):
                    logger.warning(
                        "onError failed due to transient DB disconnect; continuing",
                        exc_info=True,
                        extra={
                            "handler": self.__class__.__name__,
                            "action": getattr(local_context, "action", lambda: None)(),
                            "original_exc": exception.__class__.__name__,
                            "onerror_exc": on_error_exc.__class__.__name__,
                        },
                    )
                else:
                    raise

        if self._set_unhandled_error_response(local_context):
            return

        if not hasattr(self, "onError"):
            # Non-HTTP contexts without a custom error hook should still fail fast.
            raise exception

    def _set_unhandled_error_response(self, local_context) -> bool:
        response_getter = getattr(local_context, "response", None)
        if not callable(response_getter):
            return False

        response = response_getter()
        if response is None:
            return False

        reference_id = getattr(self.aws_context, "aws_request_id", None)
        title = "Request Failed"
        message = "Something went wrong while processing your request."
        detail = "More information has been logged on the backend."

        body = {
            "message": message,
            "detail": detail,
            "logged": True,
        }

        user_message = f"{message} {detail}"
        console_message = detail
        if reference_id:
            body["reference_id"] = str(reference_id)
            user_message = f"{user_message} Reference: {reference_id}."
            console_message = f"{console_message} Reference: {reference_id}."

        response.set_status(500)
        response.set_body(body)
        response.console(console_message, title=title)
        response.alert(user_message, title=title)
        return True

    def _is_transient_db_disconnect(self, exc: Exception = None, *args, **kwargs) -> bool:
        """Return True if an exception looks like a transient DB disconnect.

        This is intentionally message-based so it works even if the originating
        exception type comes from psycopg2 / SQLAlchemy / wrapped Velocity errors.
        """
        if exc is None and args:
            exc = args[0]

        if exc is None:
            return False

        try:
            from velocity.db import exceptions as db_exceptions

            if isinstance(exc, db_exceptions.DbConnectionError):
                return True
        except Exception:
            # Avoid import-time coupling; fall back to message matching.
            pass

        message = str(exc).lower()
        transient_markers = (
            "current transaction is aborted",
            "commands ignored until end of transaction block",
            "connection reset",
            "connection refused",
            "server closed the connection unexpectedly",
            "could not connect to server",
            "terminating connection",
            "connection not open",
        )

        return any(marker in message for marker in transient_markers)

    def log(
        self, tx, message: str, function: Optional[str] = None, level: str = "info"
    ):
        """Emit structured log output through the shared logger."""
        if not function:
            function = self.get_calling_function()

        log_data = {
            "app_name": os.environ.get("ProjectName", "Unknown"),
            "function": function,
            "message": message,
        }
        self._extend_log_data(log_data)

        log_method = getattr(logger, level, logger.info)
        log_method(
            "%s %s",
            function,
            message,
            extra={"log_data": log_data, "tx_present": tx is not None},
        )

    def _extend_log_data(self, data: Dict[str, Any]):
        """
        Extend log data with handler-specific fields.
        To be overridden by subclasses.

        Args:
            data: The base log data dictionary to extend
        """
        # Default implementation adds basic Lambda info
        data.update(
            {
                "user_agent": "AWS Lambda",
                "device_type": "Lambda",
                "sys_modified_by": "Lambda",
            }
        )

    def OnActionDefault(self, tx, local_context):
        """
        Default action handler when no specific action is found.

        Args:
            local_context: The context object
        """
        action = getattr(local_context, "action", lambda: "unknown")()
        warning_message = (
            f"[Warn] Action handler not found. Calling BaseHandler default action "
            f"`{self.__class__.__name__}.OnActionDefault` with the following parameters:\n"
            f"  - action: {action}\n"
            f"  - handler: {self.__class__.__name__}"
        )
        logger.warning(warning_message)
        local_context.response().set_body(
            {"event": self.aws_event, "postdata": local_context.postdata()}
        )
