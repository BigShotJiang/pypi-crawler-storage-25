"""Payment profile utilities shared across payment processors."""

from decimal import Decimal


PROCESSOR_PROFILE_SOURCES = {
    "stripe": ["ST"],
    "braintree": ["BT", "AN"],
}


def normalize_payment_processor(value):
    raw = str(value or "").strip().lower()
    if not raw or raw == "braintree":
        return "braintree"
    if raw == "stripe":
        return "stripe"
    return raw


def money_to_cents(value):
    amount = Decimal(str(value or 0))
    return int((amount * Decimal("100")).quantize(Decimal("1")))


def get_payment_profile_sources(processor_type):
    processor = normalize_payment_processor(processor_type)
    return list(PROCESSOR_PROFILE_SOURCES.get(processor, ["BT", "AN"]))


def build_stripe_payment_profile(
    customer_id, payment_method, email_address, is_default=True
):
    card = getattr(payment_method, "card", None)
    billing_details = getattr(payment_method, "billing_details", None)
    data = {
        "src": "ST",
        "card_type": (
            str(getattr(card, "brand", "Stripe") or "Stripe")
            .replace("_", " ")
            .title()
        ),
        "card_number": getattr(card, "last4", None),
        "expiration_date": (
            f"{int(getattr(card, 'exp_year', 0)):04d}-{int(getattr(card, 'exp_month', 0)):02d}"
            if getattr(card, "exp_year", None) and getattr(card, "exp_month", None)
            else None
        ),
        "payment_profile_id": payment_method.id,
        "customer_profile_id": customer_id,
        "email_address": email_address,
        "is_default": is_default,
    }
    name = getattr(billing_details, "name", None) if billing_details else None
    if name:
        parts = str(name).split()
        if parts:
            data["first_name"] = " ".join(parts[:-1]) or parts[0]
            data["last_name"] = parts[-1] if len(parts) > 1 else ""
    return data


def upsert_payment_profile(tx, profile_data, key=None):
    lookup_key = key or {"payment_profile_id": profile_data["payment_profile_id"]}
    try:
        tx.table("payment_profiles").upsert(profile_data, lookup_key)
    except Exception:
        data = dict(profile_data)
        data.update(lookup_key)
        tx.table("payment_profiles").insert(data)
        tx.table("payment_profiles").create_index("payment_profile_id", unique=True)