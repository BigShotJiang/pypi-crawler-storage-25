"""
Velocity Payment Processing Module

Provides processor-agnostic payment processing with pluggable adapters for
different payment gateways (Stripe, Braintree, etc.).

This module is designed to be used across multiple projects that need payment
processing capabilities, maintaining consistency and reducing code duplication.

Usage:
    from velocity.payment import get_processor_adapter

    @engine.transaction
    def process_payment(tx, client_id, payment_data):
        adapter = get_processor_adapter(tx, client_id)
        result = adapter.authorize_payment(tx, payment_data)
        return result

Available Adapters:
    - StripeAdapter: Stripe Connect with Express accounts
    - BraintreeAdapter: Braintree sub-merchant accounts

Configuration:
    Adapters are configured via environment variables. See router.py for details.
"""

from .base_adapter import PaymentProcessorAdapter, ProcessorError
from .stripe_adapter import StripeAdapter
from .braintree_adapter import BraintreeAdapter
from .router import (
    get_processor_adapter,
    get_processor_config,
    get_revenue_split_percentage,
    get_processor_account_id,
    charge_stored_payment_method,
    get_or_create_customer_profile,
    attach_payment_method,
    detach_payment_method,
    delete_customer_profile,
)
from .profiles import (
    normalize_payment_processor,
    money_to_cents,
    get_payment_profile_sources,
    build_stripe_payment_profile,
    upsert_payment_profile,
)

__all__ = [
    # Base classes
    "PaymentProcessorAdapter",
    "ProcessorError",
    # Adapters
    "StripeAdapter",
    "BraintreeAdapter",
    # Router functions
    "get_processor_adapter",
    "get_processor_config",
    "get_revenue_split_percentage",
    "get_processor_account_id",
    "charge_stored_payment_method",
    "get_or_create_customer_profile",
    "attach_payment_method",
    "detach_payment_method",
    "delete_customer_profile",
    "normalize_payment_processor",
    "money_to_cents",
    "get_payment_profile_sources",
    "build_stripe_payment_profile",
    "upsert_payment_profile",
]

__version__ = "1.0.0"
