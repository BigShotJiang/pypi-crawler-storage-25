from types import SimpleNamespace

import pytest

from velocity.payment.base_adapter import ProcessorError
from velocity.payment.stripe_adapter import StripeAdapter


class FakeSelectResult:
    def __init__(self, row):
        self._row = row

    def one(self):
        return self._row


class FakePaymentProfilesTable:
    def __init__(self, row=None):
        self.row = row
        self.select_calls = []

    def select(self, **kwargs):
        self.select_calls.append(kwargs)
        return FakeSelectResult(self.row)


class FakeTx:
    def __init__(self, row=None):
        self.payment_profiles = FakePaymentProfilesTable(row=row)

    def table(self, table_name):
        assert table_name == "payment_profiles"
        return self.payment_profiles


@pytest.fixture
def adapter():
    return StripeAdapter({"api_key": "sk_test_123", "environment": "test"})


def test_get_or_create_customer_profile_returns_existing_customer(adapter):
    tx = FakeTx(row={"customer_profile_id": "cus_existing"})

    result = adapter.get_or_create_customer_profile(
        tx, {"email_address": "ada@example.com"}
    )

    assert result == {"customer_profile_id": "cus_existing", "created": False}


def test_get_or_create_customer_profile_creates_customer_when_missing(adapter, monkeypatch):
    tx = FakeTx(row=None)
    captured = {}

    def fake_create(**kwargs):
        captured.update(kwargs)
        return SimpleNamespace(id="cus_new")

    monkeypatch.setattr("velocity.payment.stripe_adapter.stripe.Customer.create", fake_create)

    result = adapter.get_or_create_customer_profile(
        tx,
        {
            "email_address": "ada@example.com",
            "first_name": "Ada",
            "last_name": "Lovelace",
        },
    )

    assert result["customer_profile_id"] == "cus_new"
    assert result["created"] is True
    assert captured["email"] == "ada@example.com"
    assert captured["name"] == "Ada Lovelace"


def test_attach_payment_method_attaches_and_sets_default(adapter, monkeypatch):
    retrieved = SimpleNamespace(id="pm_123", customer=None)
    attached = SimpleNamespace(id="pm_123", customer="cus_123")
    customer_modify_calls = []

    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.stripe.PaymentMethod.retrieve",
        lambda payment_method_id: retrieved,
    )
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.stripe.PaymentMethod.attach",
        lambda payment_method_id, customer: attached,
    )
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.stripe.Customer.modify",
        lambda customer_id, **kwargs: customer_modify_calls.append((customer_id, kwargs)),
    )

    result = adapter.attach_payment_method(
        tx=None,
        customer_profile_id="cus_123",
        payment_method_id="pm_123",
        payment_data={"email_address": "ada@example.com", "name": "Ada Lovelace"},
    )

    assert result["payment_profile_id"] == "pm_123"
    assert result["customer_profile_id"] == "cus_123"
    assert customer_modify_calls[0][0] == "cus_123"
    assert customer_modify_calls[0][1]["invoice_settings"]["default_payment_method"] == "pm_123"


def test_attach_payment_method_raises_when_attached_to_other_customer(adapter, monkeypatch):
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.stripe.PaymentMethod.retrieve",
        lambda payment_method_id: SimpleNamespace(id="pm_123", customer="cus_other"),
    )

    with pytest.raises(ProcessorError, match="already attached"):
        adapter.attach_payment_method(None, "cus_123", "pm_123")


def test_detach_payment_method_detaches_when_customer_present(adapter, monkeypatch):
    detached = SimpleNamespace(id="pm_123", customer=None)
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.stripe.PaymentMethod.retrieve",
        lambda payment_method_id: SimpleNamespace(id="pm_123", customer="cus_123"),
    )
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.stripe.PaymentMethod.detach",
        lambda payment_method_id: detached,
    )

    result = adapter.detach_payment_method(None, "pm_123")

    assert result["detached"] is True
    assert result["payment_profile_id"] == "pm_123"


def test_delete_customer_profile_returns_deleted_result(adapter, monkeypatch):
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.stripe.Customer.delete",
        lambda customer_profile_id: SimpleNamespace(deleted=True),
    )

    result = adapter.delete_customer_profile(None, "cus_123")

    assert result["deleted"] is True
    assert result["customer_profile_id"] == "cus_123"


def test_charge_stored_payment_method_requires_customer_profile(adapter):
    with pytest.raises(ProcessorError, match="customer_profile_id"):
        adapter.charge_stored_payment_method(
            None,
            {
                "amount": 1050,
                "payment_method": "pm_123",
                "processor_account_id": "acct_123",
            },
        )


def test_charge_stored_payment_method_returns_success_payload(adapter, monkeypatch):
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.stripe.PaymentIntent.create",
        lambda **kwargs: SimpleNamespace(
            id="pi_123",
            latest_charge="ch_123",
            status="succeeded",
            amount=1050,
            currency="usd",
            application_fee_amount=210,
        ),
    )

    result = adapter.charge_stored_payment_method(
        None,
        {
            "amount": 1050,
            "payment_method": "pm_123",
            "customer_profile_id": "cus_123",
            "processor_account_id": "acct_123",
            "revenue_split_percentage": 20,
            "client_id": "client_1",
        },
    )

    assert result["success"] is True
    assert result["processor_transaction_id"] == "pi_123"
    assert result["processor_charge_id"] == "ch_123"
    assert result["platform_fee"] == 210