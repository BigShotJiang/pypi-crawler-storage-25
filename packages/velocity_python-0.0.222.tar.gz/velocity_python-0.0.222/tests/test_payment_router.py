import pytest

from velocity.payment import router


class FakeAdapter:
    def __init__(self):
        self.calls = []

    def charge_stored_payment_method(self, tx, payment_data):
        self.calls.append((tx, payment_data))
        return {"status": "ok", "success": True, "payment_data": payment_data}

    def get_or_create_customer_profile(self, tx, customer_data):
        self.calls.append(("get_or_create_customer_profile", tx, customer_data))
        return {"customer_profile_id": "cus_123", "created": False}

    def attach_payment_method(self, tx, customer_profile_id, payment_method_id, payment_data):
        self.calls.append(
            (
                "attach_payment_method",
                tx,
                customer_profile_id,
                payment_method_id,
                payment_data,
            )
        )
        return {"payment_profile_id": payment_method_id}

    def detach_payment_method(self, tx, payment_method_id):
        self.calls.append(("detach_payment_method", tx, payment_method_id))
        return {"payment_profile_id": payment_method_id, "detached": True}

    def delete_customer_profile(self, tx, customer_profile_id):
        self.calls.append(("delete_customer_profile", tx, customer_profile_id))
        return {"customer_profile_id": customer_profile_id, "deleted": True}


@pytest.mark.unit
def test_charge_stored_payment_method_constructs_expected_payload(monkeypatch):
    adapter = FakeAdapter()

    monkeypatch.setattr(router, "_is_processor_enabled", lambda tx, processor_type: True)
    monkeypatch.setattr(router, "_build_adapter", lambda processor_type: adapter)
    monkeypatch.setattr(router, "get_processor_account_id", lambda tx, client_id, processor_type=None: "acct_123")
    monkeypatch.setattr(router, "get_revenue_split_percentage", lambda tx, client_id, form_sys_id=None: 17.5)

    result = router.charge_stored_payment_method(
        tx=object(),
        client_id="client_1",
        payment_profile={
            "payment_profile_id": "pm_123",
            "customer_profile_id": "cus_123",
        },
        amount="10.50",
        donor_email="ada@example.com",
        donor_name="Ada Lovelace",
        description="Recurring donation",
        metadata={"campaign_id": "CAMP"},
        processor_type="stripe",
    )

    assert result["success"] is True
    _, payload = adapter.calls[0]
    assert payload["amount"] == 1050
    assert payload["payment_method"] == "pm_123"
    assert payload["customer_profile_id"] == "cus_123"
    assert payload["processor_account_id"] == "acct_123"
    assert payload["revenue_split_percentage"] == 17.5
    assert payload["description"] == "Recurring donation"
    assert payload["metadata"] == {"campaign_id": "CAMP"}


@pytest.mark.unit
def test_charge_stored_payment_method_rejects_disabled_processor(monkeypatch):
    monkeypatch.setattr(router, "_is_processor_enabled", lambda tx, processor_type: False)

    with pytest.raises(ValueError, match="not enabled"):
        router.charge_stored_payment_method(
            tx=object(),
            client_id="client_1",
            payment_profile={"payment_profile_id": "pm_123"},
            amount="1.00",
            processor_type="stripe",
        )


@pytest.mark.unit
def test_vault_router_helpers_delegate_to_adapter(monkeypatch):
    adapter = FakeAdapter()

    monkeypatch.setattr(router, "_is_processor_enabled", lambda tx, processor_type: True)
    monkeypatch.setattr(router, "_build_adapter", lambda processor_type: adapter)

    customer_result = router.get_or_create_customer_profile(
        object(), "stripe", {"email_address": "ada@example.com"}
    )
    attach_result = router.attach_payment_method(
        object(), "stripe", "cus_123", "pm_123", {"set_default": True}
    )
    detach_result = router.detach_payment_method(object(), "stripe", "pm_123")
    delete_result = router.delete_customer_profile(object(), "stripe", "cus_123")

    assert customer_result["customer_profile_id"] == "cus_123"
    assert attach_result["payment_profile_id"] == "pm_123"
    assert detach_result["detached"] is True
    assert delete_result["deleted"] is True