"""End-to-end tests: a real MCP client through the gateway to real upstreams."""

import json
from pathlib import Path
from typing import Any

import pytest
from fastmcp import Client
from fastmcp.exceptions import ToolError

from bastion.config.schema import BastionConfig
from bastion.gateway import build_gateway


def _config(
    upstreams: dict[str, dict[str, Any]],
    *,
    audit_path: Path | None = None,
    policy: dict[str, Any] | None = None,
    cost: dict[str, Any] | None = None,
) -> BastionConfig:
    raw: dict[str, Any] = {"upstreams": upstreams}
    if audit_path is None:
        raw["audit"] = {"enabled": False}
    else:
        raw["audit"] = {"enabled": True, "path": str(audit_path)}
    if policy is not None:
        raw["policy"] = policy
    if cost is not None:
        raw["cost"] = cost
    return BastionConfig.model_validate(raw)


def _stdio(python_exe: str, sample_upstream: Path) -> dict[str, dict[str, Any]]:
    return {"sample": {"command": python_exe, "args": [str(sample_upstream)]}}


async def test_gateway_lists_upstream_tools(sample_upstream: Path, python_exe: str) -> None:
    gateway = build_gateway(_config(_stdio(python_exe, sample_upstream)))
    async with Client(gateway) as client:
        names = {tool.name for tool in await client.list_tools()}
    assert {"echo", "add", "delete_thing", "write_note"} <= names


async def test_gateway_passes_through_tool_call(sample_upstream: Path, python_exe: str) -> None:
    gateway = build_gateway(_config(_stdio(python_exe, sample_upstream)))
    async with Client(gateway) as client:
        result = await client.call_tool("echo", {"text": "through the gateway"})
    assert result.data == "through the gateway"


async def test_gateway_passes_through_typed_result(sample_upstream: Path, python_exe: str) -> None:
    gateway = build_gateway(_config(_stdio(python_exe, sample_upstream)))
    async with Client(gateway) as client:
        result = await client.call_tool("add", {"a": 2, "b": 40})
    assert result.data == 42


async def test_gateway_namespaces_multiple_upstreams(
    sample_upstream: Path, python_exe: str
) -> None:
    upstreams = {
        "alpha": {"command": python_exe, "args": [str(sample_upstream)]},
        "beta": {"command": python_exe, "args": [str(sample_upstream)]},
    }
    gateway = build_gateway(_config(upstreams))
    async with Client(gateway) as client:
        names = {tool.name for tool in await client.list_tools()}
    assert {"alpha_echo", "beta_echo"} <= names


async def test_gateway_writes_an_audit_record_per_call(
    sample_upstream: Path, python_exe: str, tmp_path: Path
) -> None:
    audit_log = tmp_path / "audit.jsonl"
    gateway = build_gateway(_config(_stdio(python_exe, sample_upstream), audit_path=audit_log))
    async with Client(gateway) as client:
        await client.call_tool("echo", {"text": "hi"})
        await client.call_tool("add", {"a": 1, "b": 2})
    records = [json.loads(line) for line in audit_log.read_text(encoding="utf-8").splitlines()]
    assert [r["tool"] for r in records] == ["echo", "add"]
    assert records[0]["arguments"] == {"text": "hi"}
    assert records[0]["outcome"] == "ok"
    assert records[0]["duration_ms"] >= 0


async def test_gateway_audit_records_a_failing_call(
    sample_upstream: Path, python_exe: str, tmp_path: Path
) -> None:
    audit_log = tmp_path / "audit.jsonl"
    gateway = build_gateway(_config(_stdio(python_exe, sample_upstream), audit_path=audit_log))
    async with Client(gateway) as client:
        with pytest.raises(ToolError):
            await client.call_tool("boom", {})
    records = [json.loads(line) for line in audit_log.read_text(encoding="utf-8").splitlines()]
    assert len(records) == 1
    assert records[0]["tool"] == "boom"
    assert records[0]["outcome"] == "error"
    assert records[0]["error"]


async def test_gateway_blocks_a_denied_tool(
    sample_upstream: Path, python_exe: str, tmp_path: Path
) -> None:
    audit_log = tmp_path / "audit.jsonl"
    config = _config(
        _stdio(python_exe, sample_upstream),
        audit_path=audit_log,
        policy={"default": "allow", "permissions": [{"tool": "delete_thing", "action": "deny"}]},
    )
    gateway = build_gateway(config)
    async with Client(gateway) as client:
        result = await client.call_tool("echo", {"text": "allowed"})
        assert result.data == "allowed"
        with pytest.raises(ToolError):
            await client.call_tool("delete_thing", {"name": "x"})
    records = [json.loads(line) for line in audit_log.read_text(encoding="utf-8").splitlines()]
    assert records[0]["tool"] == "echo"
    assert records[0]["outcome"] == "ok"
    assert records[1]["tool"] == "delete_thing"
    assert records[1]["outcome"] == "denied"


async def test_gateway_default_deny_blocks_unlisted_tools(
    sample_upstream: Path, python_exe: str
) -> None:
    config = _config(
        _stdio(python_exe, sample_upstream),
        policy={"default": "deny", "permissions": [{"tool": "echo", "action": "allow"}]},
    )
    gateway = build_gateway(config)
    async with Client(gateway) as client:
        result = await client.call_tool("echo", {"text": "explicitly allowed"})
        assert result.data == "explicitly allowed"
        with pytest.raises(ToolError):
            await client.call_tool("add", {"a": 1, "b": 1})


async def test_gateway_rate_limits_tool_calls(
    sample_upstream: Path, python_exe: str, tmp_path: Path
) -> None:
    """A global rate-limit rule blocks calls past its burst budget."""
    audit_log = tmp_path / "audit.jsonl"
    config = _config(
        _stdio(python_exe, sample_upstream),
        audit_path=audit_log,
        policy={
            "rate_limits": [
                {"name": "tight-cap", "scope": "global", "max_per_minute": 1, "burst": 1}
            ]
        },
    )
    gateway = build_gateway(config)
    async with Client(gateway) as client:
        result = await client.call_tool("echo", {"text": "first"})
        assert result.data == "first"
        with pytest.raises(ToolError):
            await client.call_tool("echo", {"text": "second"})
    records = [json.loads(line) for line in audit_log.read_text(encoding="utf-8").splitlines()]
    assert len(records) == 2
    assert records[0]["outcome"] == "ok"
    assert records[1]["outcome"] == "denied"
    assert records[1]["error"] and "tight-cap" in records[1]["error"]


async def test_gateway_per_tool_rate_limit_isolates_buckets(
    sample_upstream: Path, python_exe: str
) -> None:
    """A per_tool rate-limit rule keeps a separate bucket per tool name."""
    config = _config(
        _stdio(python_exe, sample_upstream),
        policy={
            "rate_limits": [
                {"name": "per-tool", "scope": "per_tool", "max_per_minute": 1, "burst": 1}
            ]
        },
    )
    gateway = build_gateway(config)
    async with Client(gateway) as client:
        # echo consumes its bucket
        echo_result = await client.call_tool("echo", {"text": "hi"})
        assert echo_result.data == "hi"
        with pytest.raises(ToolError):
            await client.call_tool("echo", {"text": "again"})
        # add has its own bucket and still works
        add_result = await client.call_tool("add", {"a": 1, "b": 2})
        assert add_result.data == 3


async def test_gateway_blocks_when_over_call_budget(
    sample_upstream: Path, python_exe: str, tmp_path: Path
) -> None:
    """A daily call-count budget blocks calls past the cap and audits the denial."""
    audit_log = tmp_path / "audit.jsonl"
    config = _config(
        _stdio(python_exe, sample_upstream),
        audit_path=audit_log,
        policy={
            "budgets": [{"name": "daily-cap", "scope": "global", "per": "day", "max_calls": 2}],
            "budget_checkpoint": None,
        },
    )
    gateway = build_gateway(config)
    async with Client(gateway) as client:
        await client.call_tool("echo", {"text": "first"})
        await client.call_tool("echo", {"text": "second"})
        with pytest.raises(ToolError):
            await client.call_tool("echo", {"text": "third"})
    records = [json.loads(line) for line in audit_log.read_text(encoding="utf-8").splitlines()]
    assert [r["outcome"] for r in records] == ["ok", "ok", "denied"]
    assert "daily-cap" in records[2]["error"]


async def test_gateway_blocks_when_over_cost_budget(sample_upstream: Path, python_exe: str) -> None:
    """A cost budget blocks the call whose cost would push it over the cap."""
    config = _config(
        _stdio(python_exe, sample_upstream),
        cost={"per_tool": {"echo": 0.4, "add": 0.4}},
        policy={
            "budgets": [{"name": "spend", "scope": "global", "per": "day", "max_cost": 1.0}],
            "budget_checkpoint": None,
        },
    )
    gateway = build_gateway(config)
    async with Client(gateway) as client:
        await client.call_tool("echo", {"text": "a"})  # 0.4, total 0.4
        await client.call_tool("add", {"a": 1, "b": 2})  # 0.4, total 0.8
        with pytest.raises(ToolError):
            await client.call_tool("echo", {"text": "c"})  # would push to 1.2 > 1.0


async def test_gateway_budget_survives_a_restart(
    sample_upstream: Path, python_exe: str, tmp_path: Path
) -> None:
    """When checkpointing is enabled, budget counters persist across gateway rebuilds."""
    checkpoint = tmp_path / "budgets.json"
    policy = {
        "budgets": [{"name": "daily-cap", "scope": "global", "per": "day", "max_calls": 2}],
        "budget_checkpoint": str(checkpoint),
    }
    config = _config(_stdio(python_exe, sample_upstream), policy=policy)

    gateway1 = build_gateway(config)
    async with Client(gateway1) as client:
        await client.call_tool("echo", {"text": "1"})
        await client.call_tool("echo", {"text": "2"})

    # Rebuild — loads counters from disk
    gateway2 = build_gateway(config)
    async with Client(gateway2) as client:
        with pytest.raises(ToolError):
            await client.call_tool("echo", {"text": "3"})
