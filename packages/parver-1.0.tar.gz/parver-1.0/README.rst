.. image:: https://img.shields.io/pypi/v/parver.svg
   :target: https://pypi.org/project/parver/
   :alt: PyPI

.. image:: https://img.shields.io/badge/docs-read%20now-blue.svg
   :target: https://parver.readthedocs.io/en/latest/?badge=latest
   :alt: Documentation Status

.. image:: https://github.com/RazerM/parver/workflows/CI/badge.svg?branch=main
   :target: https://github.com/RazerM/parver/actions?workflow=CI
   :alt: CI Status

.. image:: https://codecov.io/gh/RazerM/parver/branch/main/graph/badge.svg
   :target: https://codecov.io/gh/RazerM/parver
   :alt: Test coverage

.. image:: https://img.shields.io/github/license/RazerM/parver.svg
   :target: https://raw.githubusercontent.com/RazerM/parver/main/LICENSE.txt
   :alt: MIT License

parver
======

parver allows parsing and manipulation of `PEP 440`_ version numbers.

Example
=======

.. code:: python

    >>> Version.parse('1.3').bump_dev()
    <Version '1.3.dev0'>
    >>> v = Version.parse('v1.2.alpha-3')
    >>> v.is_alpha
    True
    >>> v.pre
    3
    >>> v
    <Version 'v1.2.alpha-3'>
    >>> v.normalize()
    <Version '1.2a3'>

.. _`PEP 440`: https://www.python.org/dev/peps/pep-0440/
