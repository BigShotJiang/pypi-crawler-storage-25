"""
Zwischenzug provider — LangChain model wrappers via LiteLLM.

This is the **single file** that imports LangChain provider integrations.
All chat models are constructed through `langchain_litellm.ChatLiteLLM`, which
lets Zwischenzug route any LiteLLM-supported provider through one consistent
LangChain interface.
"""
from __future__ import annotations

import os
from typing import Any


_PROVIDER_ENV_HINTS: dict[str, str] = {
    "groq": "GROQ_API_KEY",
    "gemini": "GEMINI_API_KEY or GOOGLE_API_KEY",
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
    "cohere": "COHERE_API_KEY",
    "together_ai": "TOGETHERAI_API_KEY",
    "replicate": "REPLICATE_API_KEY",
}

# Maps provider → list of env vars that satisfy authentication (any one is enough)
_PROVIDER_REQUIRED_KEYS: dict[str, list[str]] = {
    "groq": ["GROQ_API_KEY"],
    "gemini": ["GEMINI_API_KEY", "GOOGLE_API_KEY"],
    "openai": ["OPENAI_API_KEY"],
    "anthropic": ["ANTHROPIC_API_KEY"],
    "openrouter": ["OPENROUTER_API_KEY"],
    "cohere": ["COHERE_API_KEY"],
    "together_ai": ["TOGETHERAI_API_KEY"],
    "replicate": ["REPLICATE_API_KEY"],
}


def resolve_model(provider: str, model: str) -> str:
    """
    Normalize the final LiteLLM model identifier.

    The selected `provider` is authoritative — prefixes the model string so
    LiteLLM routes to the correct backend.
    """
    provider = provider.strip().lower()
    raw_model = model.strip()
    if raw_model.lower().startswith(f"{provider}/"):
        return raw_model
    return f"{provider}/{raw_model}"


def build_llm(provider: str, model: str, **kwargs: Any):
    """
    Factory: return a LiteLLM-backed LangChain chat model.

    Args:
        provider: LiteLLM provider slug (e.g. "groq", "gemini", "openai")
        model:    Model identifier or alias
        **kwargs: temperature, max_tokens, max_retries, api_base, api_key, etc.
    """
    provider = provider.strip().lower()
    resolved_model = resolve_model(provider, model)

    try:
        from langchain_litellm import ChatLiteLLM
    except ImportError as exc:
        raise ImportError(
            "langchain-litellm is not installed.\n"
            "Run: pip install langchain-litellm"
        ) from exc

    _validate_provider_credentials(provider, resolved_model)

    init_kwargs = {
        "model": resolved_model,
        "temperature": kwargs.get("temperature", 0.2),
        "max_tokens": kwargs.get("max_tokens", 8192),
        "max_retries": kwargs.get("max_retries", 2),
        "streaming": kwargs.get("streaming", True),
    }

    for key in (
        "api_base",
        "api_key",
        "organization",
        "custom_llm_provider",
        "include_reasoning",
        "reasoning_effort",
        "reasoning_format",
    ):
        if key in kwargs and kwargs[key] is not None:
            init_kwargs[key] = kwargs[key]

    return ChatLiteLLM(**init_kwargs)


def _validate_provider_credentials(provider: str, resolved_model: str) -> None:
    """
    Raise a friendly error when none of the expected API key env vars are set.

    Only validates providers we know about; unknown providers are left to
    LiteLLM's own validation at call time.
    """
    required_keys = _PROVIDER_REQUIRED_KEYS.get(provider)
    if not required_keys:
        return
    if not any(os.getenv(k, "").strip() for k in required_keys):
        hint = _PROVIDER_ENV_HINTS.get(provider, " or ".join(required_keys))
        raise ValueError(
            f"No API key found for provider '{provider}'. "
            f"Set {hint} in your .env file or export it before running Zwischenzug."
        )


def available_providers() -> list[str]:
    """Return LiteLLM provider slugs that Zwischenzug knows API key hints for,
    plus common ones that use standard env var conventions."""
    return sorted(_PROVIDER_REQUIRED_KEYS.keys()) + [
        "ollama",
        "azure",
        "vertex_ai",
        "together_ai",
    ]


def default_model(provider: str) -> str:
    """No built-in defaults — user must supply a model."""
    return ""


def list_models(provider: str) -> list[str]:
    """No built-in model lists — user supplies the model directly."""
    return []


def provider_env_hint(provider: str) -> str | None:
    """Return the common env var hint for a provider, if known."""
    return _PROVIDER_ENV_HINTS.get(provider.strip().lower())
