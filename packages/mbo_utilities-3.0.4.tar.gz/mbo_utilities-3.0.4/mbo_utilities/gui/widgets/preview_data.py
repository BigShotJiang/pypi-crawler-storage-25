"""
PreviewDataWidget - Main GUI widget for data preview and processing.

This module contains the PreviewDataWidget class which provides:
- Time series data visualization
- Z-stats signal quality analysis
- Suite2p pipeline integration
- File format conversion

The widget uses modular components:
- _menu_bar.py: Menu bar and status indicator
- _popups.py: Tool popups and process console
- _save_as.py: Save As dialog
- _keyboard.py: Keyboard shortcuts
- _dialogs.py: File dialog handling
- _stats.py: Z-stats computation and display
"""

import logging
import threading
from pathlib import Path
from typing import Literal
import os
import importlib.util
import time

# Force rendercanvas to use Qt backend if PyQt6 is available
# This must happen BEFORE importing fastplotlib to avoid glfw selection
if importlib.util.find_spec("PyQt6") is not None:
    os.environ.setdefault("RENDERCANVAS_BACKEND", "qt")
    import PyQt6  # noqa: F401 - Must be imported before rendercanvas.qt can load

    # Fix suite2p PyQt6 compatibility - must happen before any suite2p GUI imports
    from PyQt6.QtWidgets import QSlider
    if not hasattr(QSlider, "NoTicks"):
        QSlider.NoTicks = QSlider.TickPosition.NoTicks

import imgui_bundle
import numpy as np
from numpy import ndarray
from scipy.ndimage import gaussian_filter

from imgui_bundle import imgui, hello_imgui, imgui_ctx, implot

from mbo_utilities.preferences import get_mbo_dirs
from mbo_utilities.reader import MBO_AVAILABLE_FTYPES
from mbo_utilities.arrays.features import PhaseCorrectionFeature
from mbo_utilities.preferences import get_last_dir
from mbo_utilities.arrays import ScanImageArray
from mbo_utilities.gui._availability import HAS_SUITE2P
from mbo_utilities.gui.widgets.gui_logger import GuiLogger, GuiLogHandler
from mbo_utilities.gui.widgets.progress_bar import start_output_capture
from mbo_utilities.gui.widgets import get_supported_widgets, draw_all_widgets
from mbo_utilities import log

# Import modular components
from mbo_utilities.gui.widgets.menu_bar import draw_menu_bar, draw_keybinds_popup
from mbo_utilities.gui._popups import draw_tools_popups, draw_process_console_popup
from mbo_utilities.gui._save_as import draw_saveas_popup
from mbo_utilities.gui._keyboard import handle_keyboard_shortcuts, rebind_space_to_playback
from mbo_utilities.gui._dialogs import check_file_dialogs
from mbo_utilities.gui._stats import compute_zstats, refresh_zstats, draw_stats_section
from mbo_utilities.gui._help_viewer import draw_help_popup
from mbo_utilities.gui._metadata_editor import draw_metadata_popup


import fastplotlib as fpl
from fastplotlib.ui import EdgeWindow
import contextlib

__all__ = ["PreviewDataWidget"]


import re as _re

_PLANE_DIR_RE = _re.compile(r"^plane\d+$", _re.IGNORECASE)


def _outdir_from_fpath(fpath) -> str | None:
    """Default output dir from a loaded fpath: the parent folder when fpath
    is a file, or the folder itself when fpath IS a directory. Used to
    seed the Run-tab output field so re-runs land alongside the source
    data unless the user explicitly browses elsewhere.
    """
    if fpath is None:
        return None
    if isinstance(fpath, (list, tuple)):
        if not fpath:
            return None
        fpath = fpath[0]
    try:
        p = Path(str(fpath))
    except (TypeError, ValueError):
        return None
    if not p.exists():
        return None
    return str(p if p.is_dir() else p.parent)


def _derive_suite2p_output_dir(fpath) -> str | None:
    """Detect a suite2p output location from a file or directory path.

    Returns the directory suite2p would have written into (the parent of
    the `plane*/` subdirs), or None if `fpath` doesn't look like a suite2p
    output. Used to auto-populate the GUI's output-folder field when the
    user opens an existing data.bin / ops.npy / volumetric results dir.

    Cases handled:
      - file inside `…/<root>/plane0/` (e.g. data.bin, ops.npy) → `<root>`
      - directory `…/<root>/plane0/`                            → `<root>`
      - directory `…/<root>/` containing one or more `plane*/`  → `<root>`
    """
    if fpath is None:
        return None
    if isinstance(fpath, (list, tuple)):
        if not fpath:
            return None
        fpath = fpath[0]
    try:
        p = Path(str(fpath))
    except (TypeError, ValueError):
        return None
    if not p.exists():
        return None

    parent = p.parent if p.is_file() else p
    if _PLANE_DIR_RE.match(parent.name):
        return str(parent.parent)
    try:
        for child in parent.iterdir():
            if child.is_dir() and _PLANE_DIR_RE.match(child.name):
                return str(parent)
    except (OSError, PermissionError):
        pass
    return None


class PreviewDataWidget(EdgeWindow):
    """
    Main GUI widget for data preview and processing.

    This widget provides:
    - Time series data visualization with temporal/spatial projections
    - Z-stats signal quality analysis
    - Suite2p pipeline integration
    - File format conversion (tiff, zarr, etc.)

    Parameters
    ----------
    iw : fastplotlib.ImageWidget
        The ImageWidget to attach to.
    fpath : str | list | None
        Path(s) to the data file(s).
    threading_enabled : bool
        Whether to compute z-stats in background threads.
    size : int | None
        Width of the widget panel.
    location : str
        Panel location ("right" or "bottom").
    """

    def __init__(
        self,
        iw: fpl.ImageWidget,
        fpath: str | None | list = None,
        threading_enabled: bool = True,
        size: int | None = None,
        location: Literal["bottom", "right"] = "right",
        title: str = "Data Preview",
        show_title: bool = False,
        movable: bool = False,
        resizable: bool = False,
        scrollable: bool = False,
        auto_resize: bool = True,
        window_flags: int | None = None,
        **kwargs,
    ):

        flags = (
            (imgui.WindowFlags_.no_title_bar if not show_title else 0)
            | (imgui.WindowFlags_.no_move if not movable else 0)
            | (imgui.WindowFlags_.no_resize if not resizable else 0)
            | (imgui.WindowFlags_.no_scrollbar if not scrollable else 0)
            | (imgui.WindowFlags_.always_auto_resize if auto_resize else 0)
            | (window_flags or 0)
        )
        super().__init__(
            figure=iw.figure,
            size=250 if size is None else size,
            location=location,
            title=title,
            window_flags=flags,
        )

        # Initialize logging
        self._init_logging()

        # Initialize Suite2p settings
        self._init_suite2p()

        # Initialize ImPlot context
        if implot.get_current_context() is None:
            implot.create_context()

        # apply opaque imgui style (idempotent, runs once per process)
        from mbo_utilities.gui._imgui_helpers import style_imgui_opaque
        style_imgui_opaque()

        # Setup ImGui fonts
        self._init_fonts()

        # Store kwargs and paths
        self.kwargs = kwargs
        self.fpath = fpath if fpath else getattr(iw, "fpath", None)

        # Image widget setup
        self.image_widget = iw
        self.num_graphics = len(self.image_widget.graphics)
        self.shape = self.image_widget.data[0].shape

        # Determine data type (ScanImage or volumetric TIFF).
        # Peel the squeeze wrapper so isinstance sees the real class.
        from mbo_utilities.arrays import TiffArray
        first_arr = self.image_widget.data[0]
        underlying = getattr(first_arr, "_arr", first_arr)
        self.is_mbo_scan = (
            isinstance(underlying, ScanImageArray) or
            isinstance(underlying, TiffArray)
        )
        self.logger.debug(f"Data type: {type(first_arr).__name__}, is_mbo_scan: {self.is_mbo_scan}")

        # Initialize state
        self._init_state()

        # Initialize z-stats tracking
        self._init_zstats()

        # Initialize save dialog state
        self._init_saveas_state()

        # Initialize viewer
        self._init_viewer()

        # Start z-stats computation
        if threading_enabled:
            self.logger.debug("Starting zstats computation...")
            for i in range(self.num_graphics):
                self._zstats_running[i] = True
            threading.Thread(target=lambda: compute_zstats(self), daemon=True).start()

    def _init_logging(self):
        """Initialize logging system."""
        self.debug_panel = GuiLogger()
        gui_handler = GuiLogHandler(self.debug_panel)
        gui_handler.setFormatter(logging.Formatter("%(message)s"))
        gui_handler.setLevel(logging.DEBUG)
        log.attach(gui_handler)

        console_handler = logging.StreamHandler()
        console_handler.setFormatter(logging.Formatter("%(levelname)s - %(name)s - %(message)s"))
        console_handler.setLevel(logging.DEBUG)

        if bool(int(os.getenv("MBO_DEBUG", "0"))):
            log.set_global_level(logging.DEBUG)
        else:
            log.set_global_level(logging.INFO)

        log.attach(console_handler)
        self.logger = log.get("gui")
        self.logger.debug("Logger initialized.")
        start_output_capture()

    def _init_suite2p(self):
        """Initialize Suite2p settings (lazy)."""
        # NOTE: removed the eager `start_preload()` call here. The preload
        # spawned a daemon thread that, despite a 1s sleep, ended up
        # contending for the GIL during fastplotlib's first-paint, so the
        # widget felt frozen for ~3.5s after the window appeared (suite2p
        # imports torch/numba/cellpose/scipy — ~3500 modules total).
        #
        # Pipeline registration is now fully lazy: `_register_pipelines()`
        # is called the first time the user opens the Pipeline Settings
        # popup, and it falls back to a synchronous import on that one
        # click. Trade-off: ~3.5s pause when the user FIRST opens the
        # popup, vs. instant widget startup. If you want the preload back
        # on a different trigger (e.g. when the user navigates to the Run
        # tab), call `start_preload()` from there.

        # defer dataclass creation until actually needed. all three are
        # lazy-initialized by matching properties below.
        self._s2p = None
        self._s2p_db = None
        self._s2p_extras = None
        self._s2p_dir = ""
        self._s2p_savepath_flash_start = None
        self._s2p_savepath_flash_count = 0
        self._s2p_show_savepath_popup = False
        self._s2p_folder_dialog = None

    @property
    def s2p(self):
        """Suite2p processing settings (upstream schema)."""
        if self._s2p is None and HAS_SUITE2P:
            from mbo_utilities.gui.widgets.pipelines.settings import Suite2pSettings
            self._s2p = Suite2pSettings()
        return self._s2p

    @s2p.setter
    def s2p(self, value):
        self._s2p = value

    @property
    def s2p_db(self):
        """Suite2p input/output db (paths, plane counts) — upstream schema."""
        if self._s2p_db is None and HAS_SUITE2P:
            from mbo_utilities.gui.widgets.pipelines.settings import Suite2pDB
            self._s2p_db = Suite2pDB()
        return self._s2p_db

    @s2p_db.setter
    def s2p_db(self, value):
        self._s2p_db = value

    @property
    def s2p_extras(self):
        """Mbo-only suite2p helper fields (dff_*, accept_all_cells, etc.)."""
        if self._s2p_extras is None and HAS_SUITE2P:
            from mbo_utilities.gui.widgets.pipelines.settings import MboSuite2pExtras
            self._s2p_extras = MboSuite2pExtras()
        return self._s2p_extras

    @s2p_extras.setter
    def s2p_extras(self, value):
        self._s2p_extras = value

    def _init_fonts(self):
        """Initialize ImGui fonts."""
        io = imgui.get_io()

        # disable keyboard nav so Space/Enter don't activate whatever button
        # currently holds nav focus (e.g. the EdgeWindow collapse caret)
        io.config_flags &= ~imgui.ConfigFlags_.nav_enable_keyboard

        fd_settings_dir = (
            Path(get_mbo_dirs()["imgui"])
            .joinpath("assets", "app_settings", "preview_settings.ini")
            .expanduser()
            .resolve()
        )
        io.set_ini_filename(str(fd_settings_dir))

        _fonts_dir = Path(imgui_bundle.__file__).parent.joinpath(
            "assets", "fonts", "Roboto"
        )
        sans_serif_font = str(_fonts_dir / "Roboto-Regular.ttf")
        self._default_imgui_font = io.fonts.add_font_from_file_ttf(
            sans_serif_font, 14, imgui.ImFontConfig()
        )
        # bold variant — used by the pipeline-settings popup to emphasize
        # "look at these first" parameters listed in _IMPORTANT_FIELDS,
        # paired with a thin box around the label. fall back to None if the
        # file is missing (the popup pushes the font only when non-None).
        bold_path = _fonts_dir / "Roboto-Bold.ttf"
        if bold_path.is_file():
            self._bold_font = io.fonts.add_font_from_file_ttf(
                str(bold_path), 14, imgui.ImFontConfig()
            )
        else:
            self._bold_font = None
        imgui.push_font(self._default_imgui_font, self._default_imgui_font.legacy_size)

    def _init_state(self):
        """Initialize widget state."""
        for subplot in self.image_widget.figure:
            subplot.toolbar = False
        self.image_widget._sliders_ui._loop = True

        # Determine nz and nc (z-planes and channels) using dims property
        arr = self.image_widget.data[0]
        dims = getattr(arr, "dims", None)
        dims_lower = tuple(d.lower() for d in dims) if dims else None

        # detect z-planes
        if dims_lower is not None and "z" in dims_lower:
            z_idx = dims_lower.index("z")
            self.nz = self.shape[z_idx]
        elif dims_lower is not None and any(d in dims_lower for d in ("z-planes", "z-slices")):
            for d in ("z-planes", "z-slices"):
                if d in dims_lower:
                    z_idx = dims_lower.index(d)
                    self.nz = self.shape[z_idx]
                    break
        elif dims_lower is not None and "volumes" in dims_lower:
            # piezo: use num_slices if available, otherwise shape[1]
            if hasattr(arr, "num_slices"):
                self.nz = arr.num_slices
            else:
                vol_idx = dims_lower.index("volumes")
                if len(self.shape) >= 2 and self.shape[vol_idx] <= 1 and vol_idx + 1 < len(self.shape):
                    self.nz = self.shape[vol_idx + 1]
                else:
                    self.nz = self.shape[vol_idx]
        elif len(self.shape) >= 4 and (dims_lower is None or "channel" not in dims_lower):
            # only use shape[1] as z if not a channel dimension
            self.nz = self.shape[1]
        else:
            self.nz = 1

        # detect channels (separate from z-planes)
        if dims_lower is not None and "channel" in dims_lower:
            c_idx = dims_lower.index("channel")
            self.nc = self.shape[c_idx]
        elif dims_lower is not None and "channels" in dims_lower:
            c_idx = dims_lower.index("channels")
            self.nc = self.shape[c_idx]
        elif dims_lower is not None and "c" in dims_lower:
            c_idx = dims_lower.index("c")
            self.nc = self.shape[c_idx]
        elif hasattr(arr, "num_color_channels"):
            self.nc = arr.num_color_channels
        else:
            self.nc = 1

        # detect camera views (isoview cm dimension)
        self.n_views = 1
        if dims_lower is not None and "cm" in dims_lower:
            cm_idx = dims_lower.index("cm")
            self.n_views = self.shape[cm_idx]

        self.logger.debug(f"Detected nz={self.nz}, nc={self.nc}, n_views={self.n_views} from dims={dims}")

        # Window/projection/contrast state — all per-data widget controls
        # are reset by _reset_per_data_state. Also called on every reload
        # in load_new_data, so initial-launch defaults and reload defaults
        # never drift.
        self._auto_update = False  # not data-specific, kept here
        from mbo_utilities.gui._dialogs import _reset_per_data_state
        _reset_per_data_state(self)

        # Registration state
        self._register_z = False
        self._register_z_progress = 0.0
        self._register_z_done = False
        self._register_z_running = False
        self._register_z_current_msg = ""
        # axial registration knobs; exposed in the save-as options popup.
        # default search radius matches compute_axial_shifts(max_reg_xy=30).
        self._axial_max_frames = 200
        self._axial_max_reg_xy = 30

        # Selection state
        self._selected_pipelines = None
        self._selected_array = 0
        self._selected_planes = None
        self._planes_str = ""

        # Settings menu flags
        self.show_debug_panel = False
        self.show_scope_window = False
        self.show_metadata_viewer = False
        self.show_diagnostics_window = False
        self._diagnostics_widget = None
        self._show_progress_overlay = True

        # Process monitoring
        self._viewing_process_pid = None

        # File dialogs
        self._file_dialog = None
        self._folder_dialog = None
        self._load_status_msg = ""
        self._load_status_color = imgui.ImVec4(1.0, 1.0, 1.0, 1.0)

        # Initialize Metadata Editor state
        self._custom_metadata = {}
        self._custom_key = ""
        self._custom_value = ""
        self._metadata_editor_open = False

        # Initialize widgets
        self._widgets = get_supported_widgets(self)

    def _init_zstats(self):
        """Initialize z-stats tracking state.

        Per-array slots are dicts keyed by channel int; compute_zstats
        populates one key per channel for multi-channel arrays, just
        ``{0: ...}`` for single-channel. ``_zstats_channel_selection``
        is the user's UI choice (-1 = follow C slider).
        """
        self._zstats = [{} for _ in range(self.num_graphics)]
        self._zstats_means = [{} for _ in range(self.num_graphics)]
        self._zstats_mean_scalar = [{} for _ in range(self.num_graphics)]
        self._zstats_done = [False] * self.num_graphics
        self._zstats_running = [False] * self.num_graphics
        self._zstats_progress = [0.0] * self.num_graphics
        self._zstats_current_z = [0] * self.num_graphics
        self._zstats_channel_selection = -1

    def _init_saveas_state(self):
        """Initialize save-as dialog state."""
        self._ext = ".tiff"
        self._ext_idx = MBO_AVAILABLE_FTYPES.index(".tiff")
        self._overwrite = True
        self._debug = False
        self._saveas_chunk_mb = 100

        # Zarr options
        self._zarr_sharded = True
        self._zarr_ome = True
        self._zarr_compression_level = 1
        self._zarr_pyramid = False
        self._zarr_pyramid_max_layers = 4
        self._zarr_pyramid_method = "mean"

        # H5 options
        # dataset name inside the .h5 file. suite2p reads from "mov" by
        # default and lbm_suite2p_python expects the same; only change this
        # if you're targeting a downstream tool that wants something else.
        self._h5_dataset_name = "mov"

        # Save dialog state
        self._saveas_popup_open = False
        self._saveas_done = False
        self._saveas_running = False
        self._saveas_progress = 0.0
        self._saveas_current_index = 0

        # Set Metadata popup — driven by File menu and Shift+M shortcut
        # (see gui/_metadata_editor.draw_metadata_popup).
        self._show_metadata_popup = False

        # Directories
        save_as_dir = get_last_dir("save_as")
        self._saveas_outdir = str(save_as_dir) if save_as_dir else ""

        # Default suite2p output dir = the loaded path's parent (file) or
        # the folder itself (directory). Most intuitive default — re-runs
        # land next to the source data. Falls back to the cached last-used
        # dir only when nothing is loaded yet.
        _loaded_outdir = _outdir_from_fpath(self.fpath)
        if _loaded_outdir:
            self._s2p_outdir = _loaded_outdir
        else:
            s2p_output_dir = get_last_dir("suite2p_output")
            self._s2p_outdir = str(s2p_output_dir) if s2p_output_dir else ""

        # If the loaded data lives inside a suite2p output tree (data.bin
        # in plane*/, ops.npy / stat.npy / etc.), or is a volumetric root
        # containing plane*/, point _s2p_outdir at that root so a re-run
        # lands in the same place. Wins over the parent-folder default.
        _derived_s2p_dir = _derive_suite2p_output_dir(self.fpath)
        if _derived_s2p_dir:
            self._s2p_outdir = _derived_s2p_dir

        # Hydrate Suite2pSettings/DB/Extras from a sibling settings.npy /
        # db.npy / ops.npy when the loaded data is a suite2p output. The
        # file-menu Open path does this in load_new_data; doing it here
        # covers the CLI launch (`mbo path/to/data.bin` → fpath comes from
        # data_array.source_path which is the plane / volume directory).
        try:
            from mbo_utilities.gui._dialogs import _try_hydrate_s2p_from_binary
            _try_hydrate_s2p_from_binary(self, self.fpath)
        except Exception as _e:
            self.logger.debug(f"suite2p hydrate (init): {_e}")

        self._saveas_folder_dialog = None
        self._saveas_total = 0

        # ROI selection
        self._saveas_selected_roi = set()
        self._saveas_rois = False
        self._saveas_selected_roi_mode = "All"

        # Metadata
        self._saveas_custom_metadata = {}
        self._saveas_custom_key = ""
        self._saveas_custom_value = ""

        # Output suffix
        self._saveas_output_suffix = ""

        # Options
        self._saveas_background = True

        # Scan-phase correction for save/export (separate from display settings)
        # defaults to True for save operations
        self._saveas_fix_phase = True
        self._saveas_use_fft = True

        # Video export options (active when ext is .mp4 or .mov)
        self._saveas_video_fps = 30
        self._saveas_video_speed_factor = 1.0
        self._saveas_video_auto = True
        self._saveas_video_vmin = 0.0
        self._saveas_video_vmax = 1000.0
        self._saveas_video_vmin_pct = 1.0
        self._saveas_video_vmax_pct = 99.5
        self._saveas_video_temporal_smooth = 0
        self._saveas_video_temporal_mode_idx = 0  # 0=mean 1=max 2=std
        self._saveas_video_spatial_smooth = 0.0
        self._saveas_video_gamma = 1.0
        from mbo_utilities.gui._colormaps import DEFAULT_COLORMAPS, DEFAULT_COLORMAP
        self._saveas_video_cmaps: list[str] = list(DEFAULT_COLORMAPS)
        self._saveas_video_cmap_idx: int = self._saveas_video_cmaps.index(DEFAULT_COLORMAP)
        self._saveas_video_quality_idx = 2  # 0=preview 1=high 2=visually lossless 3=lossless
        self._saveas_video_codec_idx = 0  # 0 = libx264
        self._saveas_video_mean_subtract = False
        self._saveas_video_time_overlay = False
        self._saveas_video_scalebar = False

    def _init_viewer(self):
        """Initialize the viewer based on data type."""
        from mbo_utilities.gui.viewers import get_viewer_class
        viewer_cls = get_viewer_class(self.image_widget.data[0])
        self._viewer = viewer_cls(self.image_widget, self.fpath, parent=self)
        self.logger.debug(f"Viewer: {self._viewer.name}")
        self.set_context_info()
        self._update_window_funcs()
        rebind_space_to_playback(self)

    def set_context_info(self):
        """Update app title with dataset name."""
        try:
            if self.fpath is None:
                return
            from mbo_utilities import __version__
            name = Path(self.fpath[0]).parent.name if isinstance(self.fpath, list) else Path(self.fpath).name
            hello_imgui.get_runner_params().app_shallow_settings.window_title = f"Miller Brain Studio v{__version__} - {name}"
        except (RuntimeError, TypeError):
            pass

    # === Properties ===

    @property
    def s2p_dir(self):
        return self._s2p_dir

    @s2p_dir.setter
    def s2p_dir(self, value):
        self.logger.debug(f"Setting Suite2p directory to {value}")
        self._s2p_dir = value

    @property
    def register_z(self):
        return self._register_z

    @register_z.setter
    def register_z(self, value):
        self._register_z = value

    @property
    def processors(self) -> list:
        """Access to underlying NDImageProcessor instances."""
        return self.image_widget._image_processors

    def _get_data_arrays(self) -> list:
        """Get underlying data arrays from image processors."""
        return [proc.data for proc in self.processors]

    @property
    def current_offset(self) -> list[float]:
        """Scan-phase offset of the *currently displayed* frame, per graphic.

        Reads from each array's per-(t, c, z) offset cache via
        `arr.get_offset_at(t, c, z)` rather than `arr.offset`. The latter
        returns `_last_offset`, which is global mutable state clobbered by
        every read on the array — including background reads from histogram
        subsamplers and zstats workers — so it drifts even when the user
        isn't scrubbing. The cached lookup, by contrast, is keyed to the
        exact (t, c, z) cell on screen, so the displayed value only changes
        when the user actually moves a slider.
        """
        # current displayed indices, defaulting to 0 when a slider is absent
        # (e.g. T-only data has no z slider, so we report z=0).
        indices = {}
        if self.image_widget is not None:
            try:
                names = self.image_widget._slider_dim_names or ()
                for name in names:
                    try:
                        indices[name] = int(self.image_widget.indices[name])
                    except (KeyError, IndexError, TypeError):
                        pass
            except Exception:
                pass
        t_idx = indices.get("t", 0)
        c_idx = indices.get("c", 0)
        z_idx = indices.get("z", 0)

        offsets = []
        for arr in self._get_data_arrays():
            value = None
            getter = getattr(arr, "get_offset_at", None)
            if callable(getter):
                value = getter(t_idx, c_idx, z_idx)
            if value is None:
                # cache miss (frame hasn't been read yet under current
                # settings) or array doesn't expose the per-frame cache —
                # leave the display at 0.0 rather than showing stale state.
                offsets.append(0.0)
            else:
                offsets.append(float(value))
        return offsets

    @property
    def has_raster_scan_support(self) -> bool:
        """Check if any data array supports raster scan phase correction."""
        for arr in self._get_data_arrays():
            if hasattr(arr, "phase_correction") and isinstance(arr.phase_correction, PhaseCorrectionFeature):
                return True
            if hasattr(arr, "fix_phase") and hasattr(arr, "use_fft"):
                return True
        return False

    @property
    def has_frame_averaging_support(self) -> bool:
        """Check if any data array supports frame averaging."""
        for arr in self._get_data_arrays():
            if hasattr(arr, "frames_per_slice") and hasattr(arr, "can_average"):
                return True
        return False

    @property
    def fix_phase(self) -> bool:
        """Whether bidirectional phase correction is enabled."""
        arrays = self._get_data_arrays()
        if not arrays:
            return False
        arr = arrays[0]
        if hasattr(arr, "phase_correction") and isinstance(arr.phase_correction, PhaseCorrectionFeature):
            return arr.phase_correction.enabled
        return getattr(arr, "fix_phase", False)

    @fix_phase.setter
    def fix_phase(self, value: bool):
        self.logger.debug(f"Setting fix_phase to {value}.")
        for arr in self._get_data_arrays():
            if hasattr(arr, "phase_correction") and isinstance(arr.phase_correction, PhaseCorrectionFeature):
                arr.phase_correction.enabled = value
            elif hasattr(arr, "fix_phase"):
                arr.fix_phase = value
        self._refresh_image_widget()

    @property
    def use_fft(self) -> bool:
        """Whether FFT-based phase correlation is used."""
        arrays = self._get_data_arrays()
        if not arrays:
            return False
        arr = arrays[0]
        if hasattr(arr, "phase_correction") and isinstance(arr.phase_correction, PhaseCorrectionFeature):
            return arr.phase_correction.use_fft
        return getattr(arr, "use_fft", False)

    @use_fft.setter
    def use_fft(self, value: bool):
        self.logger.debug(f"Setting use_fft to {value}.")
        for arr in self._get_data_arrays():
            if hasattr(arr, "phase_correction") and isinstance(arr.phase_correction, PhaseCorrectionFeature):
                arr.phase_correction.use_fft = value
            elif hasattr(arr, "use_fft"):
                arr.use_fft = value
        self._refresh_image_widget()

    @property
    def border(self) -> int:
        """Border pixels to exclude from phase correlation."""
        arrays = self._get_data_arrays()
        if not arrays:
            return 3
        arr = arrays[0]
        if hasattr(arr, "phase_correction") and isinstance(arr.phase_correction, PhaseCorrectionFeature):
            return arr.phase_correction.border
        return getattr(arr, "border", 3)

    @border.setter
    def border(self, value: int):
        self.logger.debug(f"Setting border to {value}.")
        for arr in self._get_data_arrays():
            if hasattr(arr, "phase_correction") and isinstance(arr.phase_correction, PhaseCorrectionFeature):
                arr.phase_correction.border = value
            elif hasattr(arr, "border"):
                arr.border = value
        self._refresh_image_widget()

    @property
    def max_offset(self) -> int:
        """Maximum pixel offset for phase correction."""
        arrays = self._get_data_arrays()
        return getattr(arrays[0], "max_offset", 3) if arrays else 3

    @max_offset.setter
    def max_offset(self, value: int):
        self.logger.debug(f"Setting max_offset to {value}.")
        for arr in self._get_data_arrays():
            if hasattr(arr, "max_offset"):
                arr.max_offset = value
        self._refresh_image_widget()

    @property
    def selected_array(self) -> int:
        return self._selected_array

    @selected_array.setter
    def selected_array(self, value: int):
        if value < 0 or value >= self.num_graphics:
            raise ValueError(f"Invalid array index: {value}")
        self._selected_array = value

    @property
    def gaussian_sigma(self) -> float:
        """Sigma for Gaussian blur (0 = disabled)."""
        return self._gaussian_sigma

    @gaussian_sigma.setter
    def gaussian_sigma(self, value: float):
        self._gaussian_sigma = max(0.0, value)
        self._rebuild_spatial_func()
        self._refresh_image_widget()

    @property
    def proj(self) -> str:
        """Current projection mode (mean, max, std)."""
        return self._proj

    @proj.setter
    def proj(self, value: str):
        if value != self._proj:
            self.logger.debug(f"Projection changed: {self._proj} -> {value}")
            self._proj = value
            self._update_window_funcs()

    @property
    def mean_subtraction(self) -> bool:
        """Whether mean subtraction is enabled."""
        return self._mean_subtraction

    @mean_subtraction.setter
    def mean_subtraction(self, value: bool):
        if value != self._mean_subtraction:
            self._mean_subtraction = value
            self._update_mean_subtraction()

    @property
    def auto_contrast_on_z(self) -> bool:
        """Whether to auto-reset contrast when z-plane changes."""
        return self._auto_contrast_on_z

    @auto_contrast_on_z.setter
    def auto_contrast_on_z(self, value: bool):
        self._auto_contrast_on_z = value

    @property
    def window_size(self) -> int:
        """Window size for temporal projection."""
        return self._window_size

    @window_size.setter
    def window_size(self, value: int):
        # clamp to available timepoints
        nt = self.shape[0] if len(self.shape) > 0 else 1
        value = max(1, min(value, nt))
        if value == self._window_size:
            return
        self._window_size = value
        self.logger.debug(f"Window size set to {value}.")
        if not self.processors:
            return
        n_slider_dims = self.processors[0].n_slider_dims
        if n_slider_dims == 0:
            return
        per_processor_sizes = (self._window_size,) + (None,) * (n_slider_dims - 1)
        self._set_processor_attr("window_sizes", per_processor_sizes)

    # === Internal methods ===

    def _refresh_image_widget(self):
        """Trigger a frame refresh on the ImageWidget."""
        current_indices = list(self.image_widget.indices)
        self.image_widget.indices = current_indices

    def _set_processor_attr(self, attr: str, value):
        """Set processor attribute without expensive histogram recomputation."""
        if not self.processors:
            return

        # save histogram state and disable recomputation during update
        saved = [(p._compute_histogram, p._histogram) for p in self.processors]
        for proc in self.processors:
            proc._compute_histogram = False

        try:
            if attr == "window_funcs":
                if isinstance(value, tuple):
                    value = [value] * len(self.processors)
                self.image_widget.window_funcs = value
            elif attr == "window_sizes":
                if isinstance(value, (tuple, list)) and not isinstance(value[0], (tuple, list, type(None))):
                    value = [value] * len(self.processors)
                self.image_widget.window_sizes = value
            elif attr == "spatial_func":
                self.image_widget.spatial_func = value
            else:
                for proc in self.processors:
                    setattr(proc, attr, value)
                self._refresh_image_widget()
        except Exception as e:
            self.logger.exception(f"Error setting {attr}: {e}")
        finally:
            # restore histogram state
            for proc, (orig_compute, orig_hist) in zip(self.processors, saved):
                proc._compute_histogram = orig_compute
                proc._histogram = orig_hist
            # fix dock visibility (fastplotlib sets to 0 when histogram is None)
            for subplot in self.image_widget.figure:
                if subplot.docks["right"].size < 1:
                    subplot.docks["right"].size = 80

        # fpl's window_funcs/window_sizes/spatial_func setters refresh via
        # `self.indices = self.indices`, but that runs *before* the histogram
        # restore above and can leave the displayed graphic stale. Force a
        # post-restore refresh so changes take effect immediately.
        if attr in ("window_funcs", "window_sizes", "spatial_func"):
            self._refresh_image_widget()

    def _refresh_widgets(self):
        """Refresh widgets based on current data capabilities."""
        self._widgets = get_supported_widgets(self)

    def _update_mean_subtraction(self):
        """Update spatial_func to apply mean subtraction.

        does NOT reset vmin/vmax — callers that need a contrast reset
        (e.g. the mean_subtraction setter on initial toggle) must do so
        explicitly. this keeps per-z-plane rebuilds from silently
        overriding the user's auto_contrast_on_z preference.
        """
        self._rebuild_spatial_func()
        self._refresh_image_widget()

    def _rebuild_spatial_func(self):
        """Rebuild and apply the combined spatial function."""
        names = self.image_widget._slider_dim_names or ()
        # fastplotlib's `indices` is case-sensitive; isoview uses
        # uppercase TCZYX, LBM/ScanImage use lowercase. Resolve the
        # canonical key by case-insensitive match before indexing.
        z_name = next((n for n in names if n.lower() == "z"), None)
        try:
            z_idx = self.image_widget.indices[z_name] if z_name else 0
        except (IndexError, KeyError):
            z_idx = 0

        sigma = self.gaussian_sigma if self.gaussian_sigma > 0 else None

        # Pick the channel matching the currently displayed C slider so
        # mean subtraction matches what the user sees. `_zstats_means[i]`
        # is now `dict[c, (n_slices, Y, X)]`; fall back to channel 0 if
        # the slider channel hasn't been computed yet.
        c_name = next((n for n in names if n.lower() == "c"), None)
        try:
            c_for_mean = self.image_widget.indices[c_name] if c_name else 0
        except (IndexError, KeyError):
            c_for_mean = 0

        def _means_for(i):
            slot = self._zstats_means[i] if i < len(self._zstats_means) else None
            if not isinstance(slot, dict) or not slot:
                return None
            return slot.get(c_for_mean) or slot.get(0)

        any_mean_sub = self._mean_subtraction and any(
            self._zstats_done[i] and _means_for(i) is not None
            for i in range(self.num_graphics)
        )

        if not any_mean_sub and sigma is None:
            def identity(frame):
                return frame
            self._set_processor_attr("spatial_func", identity)
            return

        spatial_funcs = []
        for i in range(self.num_graphics):
            mean_img = None
            if self._mean_subtraction and self._zstats_done[i]:
                means_arr = _means_for(i)
                if means_arr is not None:
                    mean_img = means_arr[z_idx].astype(np.float32)

            spatial_funcs.append(self._make_spatial_func(mean_img, sigma))

        self._set_processor_attr("spatial_func", spatial_funcs)

    def _make_spatial_func(self, mean_img: np.ndarray | None, sigma: float | None):
        """Create a spatial function that applies mean subtraction and/or gaussian blur."""
        # precompute kernel size for opencv (6*sigma, rounded to odd)
        ksize = (int(sigma * 6) | 1) if sigma else 0

        def spatial_func(frame):
            # fastplotlib passes the raw data object when n_slider_dims==0,
            # which for our lazy arrays is not yet a numpy array.
            # materialize first so arithmetic/ufuncs work.
            result = np.asarray(frame)
            if mean_img is not None and result.ndim == 2:
                # only subtract when frame is 2D (Y, X); skip if 3D since
                # mean_img is z-specific and can't be applied to a full stack
                result = result.astype(np.float32) - mean_img
            if sigma is not None and sigma > 0 and result.ndim == 2:
                try:
                    import cv2
                    result = cv2.GaussianBlur(result, (ksize, ksize), sigma)
                except ImportError:
                    result = gaussian_filter(result, sigma=sigma)
            return result
        return spatial_func

    def _update_window_funcs(self):
        """Update window_funcs on image widget based on current projection mode."""
        if not self.processors:
            return

        def mean_wrapper(data, axis, keepdims):
            return np.mean(data, axis=axis, keepdims=keepdims)

        def max_wrapper(data, axis, keepdims):
            return np.max(data, axis=axis, keepdims=keepdims)

        def std_wrapper(data, axis, keepdims):
            return np.std(data, axis=axis, keepdims=keepdims)

        proj_funcs = {"mean": mean_wrapper, "max": max_wrapper, "std": std_wrapper}
        proj_func = proj_funcs.get(self._proj, mean_wrapper)

        n_slider_dims = self.processors[0].n_slider_dims

        if n_slider_dims == 0:
            return
        elif n_slider_dims == 1:
            window_funcs = (proj_func,)
        elif n_slider_dims == 2:
            window_funcs = (proj_func, None)
        else:
            window_funcs = (proj_func,) + (None,) * (n_slider_dims - 1)

        self._set_processor_attr("window_funcs", window_funcs)

    def gui_progress_callback(self, frac, meta=None):
        """Handle progress callbacks from save operations."""
        if isinstance(meta, (int, np.integer)):
            self._saveas_progress = frac
            self._saveas_current_index = meta
            self._saveas_done = frac >= 1.0
            if frac >= 1.0:
                self._saveas_running = False
                self._saveas_complete_time = time.time()
                self.logger.info("Save complete")
        elif isinstance(meta, str):
            self._register_z_progress = frac
            self._register_z_current_msg = meta
            self._register_z_done = frac >= 1.0
            if frac >= 1.0:
                self._register_z_running = False
                self._register_z_complete_time = time.time()

    def _clear_stale_progress(self):
        """Clear completed progress indicators after a delay."""
        now = time.time()
        clear_delay = 5.0

        if getattr(self, "_saveas_done", False):
            complete_time = getattr(self, "_saveas_complete_time", 0)
            if now - complete_time > clear_delay:
                self._saveas_done = False
                self._saveas_progress = 0.0

        if getattr(self, "_register_z_done", False):
            complete_time = getattr(self, "_register_z_complete_time", 0)
            if now - complete_time > clear_delay:
                self._register_z_done = False
                self._register_z_progress = 0.0
                self._register_z_current_msg = None

    # === Rendering ===

    def draw_window(self):
        """Override parent to handle keyboard shortcuts and global popups."""
        handle_keyboard_shortcuts(self)
        check_file_dialogs(self)

        # Draw independent floating windows
        draw_tools_popups(self)
        draw_saveas_popup(self)
        draw_metadata_popup(self)
        draw_process_console_popup(self)
        draw_keybinds_popup(self)
        draw_help_popup(self)

        super().draw_window()

    def update(self):
        """Main render callback."""
        import time
        t0 = time.perf_counter()
        # `gap` measures wall-clock time since the previous frame entered
        # update(). On a healthy GUI this should hover near the canvas's
        # frame interval (16 ms @ 60 Hz). A spike means the main thread
        # was blocked between frames — by GIL contention with a worker,
        # the canvas swap, a Qt event handler, etc. Logging this is the
        # primary signal for "GUI feels frozen during zstats."
        prev = getattr(self, "_last_frame_t", None)
        gap_ms = (t0 - prev) * 1000.0 if prev is not None else 0.0
        self._last_frame_t = t0

        draw_menu_bar(self)
        t1 = time.perf_counter()
        self._viewer.draw()
        t2 = time.perf_counter()
        menu_ms = (t1 - t0) * 1000
        draw_ms = (t2 - t1) * 1000
        if gap_ms > 100 or menu_ms > 50 or draw_ms > 50:
            self.logger.debug(
                f"SLOW FRAME: gap={gap_ms:.0f}ms menu={menu_ms:.1f}ms draw={draw_ms:.1f}ms"
            )

        # Update mean subtraction when z-plane or channel changes. With
        # all channels precomputed by zstats, a C change just rebinds the
        # mean image from the per-channel cache — no recompute needed.
        # `indices` is case-sensitive; resolve canonical names from the
        # slider list before indexing (isoview uses upper, LBM uses lower).
        names = self.image_widget._slider_dim_names or ()
        z_name = next((n for n in names if n.lower() == "z"), None)
        c_name = next((n for n in names if n.lower() == "c"), None)
        try:
            z_idx = self.image_widget.indices[z_name] if z_name else 0
        except (IndexError, KeyError):
            z_idx = 0
        try:
            c_idx = self.image_widget.indices[c_name] if c_name else 0
        except (IndexError, KeyError):
            c_idx = 0

        if z_idx != self._last_z_idx or c_idx != getattr(self, "_last_c_idx", 0):
            self._last_z_idx = z_idx
            self._last_c_idx = c_idx
            # rebuild mean-sub (if active) and reset contrast (if auto) are
            # independent concerns — both can apply on the same z change.
            if self._mean_subtraction:
                self._update_mean_subtraction()
            if self._auto_contrast_on_z and self.image_widget:
                self.image_widget.reset_vmin_vmax_frame()

    def draw_stats_section(self):
        """Draw z-stats visualization."""
        draw_stats_section(self)

    def draw_preview_section(self):
        """Draw preview section using modular UI widgets."""
        imgui.dummy(imgui.ImVec2(0, 5))
        cflags = imgui.ChildFlags_.auto_resize_y | imgui.ChildFlags_.always_auto_resize
        with imgui_ctx.begin_child("##PreviewChild", imgui.ImVec2(0, 0), cflags):
            draw_all_widgets(self, self._widgets)

    def get_raw_frame(self) -> tuple[ndarray, ...]:
        """Get raw frame data at current indices."""
        idx = self.image_widget.indices
        names = self.image_widget._slider_dim_names or ()
        t = idx["t"] if "t" in names else 0
        z = idx["z"] if "z" in names else 0

        def _ndim_to_frame(arr, t=0, z=0):
            if arr.ndim == 4:
                return arr[t, z]
            if arr.ndim == 3:
                return arr[t]
            if arr.ndim == 2:
                return arr
            raise ValueError(f"Unsupported data shape: {arr.shape}")

        return tuple(_ndim_to_frame(arr, t, z) for arr in self.image_widget.data)

    def compute_zstats(self):
        """Compute z-stats for all graphics."""
        compute_zstats(self)

    def refresh_zstats(self):
        """Reset and recompute z-stats for all arrays."""
        refresh_zstats(self)

    def cleanup(self):
        """Clean up resources when the GUI is closing."""
        from mbo_utilities.gui.widgets.pipelines import cleanup_pipelines
        from mbo_utilities.gui.widgets import cleanup_all_widgets

        cleanup_pipelines(self)
        cleanup_all_widgets(self._widgets)

        self._file_dialog = None
        self._folder_dialog = None
        if hasattr(self, "_s2p_folder_dialog"):
            self._s2p_folder_dialog = None

        self.logger.debug("GUI cleanup complete")
