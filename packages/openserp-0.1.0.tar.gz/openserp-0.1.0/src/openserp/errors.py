from __future__ import annotations

from typing import Any


class SERPError(Exception):
    def __init__(
        self,
        message: str,
        *,
        status: int = 0,
        code: str | None = None,
        reason: str | None = None,
        request_id: str | None = None,
        meta: dict[str, Any] | None = None,
        response: Any = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.code = code
        self.reason = reason
        self.request_id = request_id
        self.meta = meta
        self.response = response


class RateLimitError(SERPError):
    pass


class CaptchaError(SERPError):
    pass


class CloudOnlyError(SERPError):
    def __init__(self, method: str) -> None:
        super().__init__(
            f"{method} is only available against OpenSERP Cloud. "
            "Configure api_key/base_url for https://api.openserp.org/v1 "
            'or set backend="cloud".'
        )


class OssOnlyError(SERPError):
    def __init__(self, method: str) -> None:
        super().__init__(
            f"{method} is only available against a self-hosted OpenSERP server. "
            'Configure base_url for your OSS server or set backend="oss".'
        )


class TimeoutError(SERPError):
    def __init__(self, timeout: float) -> None:
        super().__init__(
            f"OpenSERP request timed out after {timeout:g}s",
            code="request_timeout",
        )


def error_from_response(
    status: int,
    body: Any,
    request_id: str | None = None,
) -> SERPError:
    data = body if isinstance(body, dict) else {}
    code = data.get("error")
    message = data.get("message") or f"OpenSERP request failed with status {status}"
    options = {
        "status": status,
        "code": code,
        "reason": data.get("reason"),
        "request_id": data.get("request_id") or request_id,
        "meta": data.get("meta"),
        "response": body,
    }

    if status == 429 or code == "rate_limited":
        return RateLimitError(message, **options)

    if code == "captcha_detected":
        return CaptchaError(message, **options)

    return SERPError(message, **options)
