# Changelog

## v1.4.1 (2026-05-16)

### Features

- add Python 3.14 support 
- **parser:** warn on non-POSIX env var names (dots, digit-leading, etc.) 
- **parser:** detect circular ${VAR} references and report in lint 

### Fixes

- **ci:** replace hatch with uv run pytest; fix Windows subprocess hang 
- **parser:** normalize bool values to "true"/"false" in structured loaders 
- **parser:** preserve real source line numbers for JSON/TOML/YAML loaders 

### Refactors

- **parser:** remove dead quote-stripping code in load_env_file 

### Docs

- **parser:** document and test ${VAR} fallback to os.environ The fallback is intentional: env files may reference parent-process

### Test

- fix test isolation and remove hardcoded /bin/true path dependency 

## v1.4.0 (2026-05-15)

### ⚠ BREAKING CHANGES
- runenv lint now exits 1 on error-level messages (default --fail-on=error); plain-text output moved to stderr

### Features

- **cli:** add --lint-level and --fail-on flags to run/list/lint subcommands 
- **parser:** change linter message level from error to the warning for duplicated items 

### Fixes

- typo in TOML related error message 
- text formatting in error messages 
- mispelled varialbe in an error message 
- **cli:** catch ValueError from api at CLI boundary 
- **cli:** print help instead of error when runenv is called with no subcommand 
- **cli:** replace "Environment file None does not exist" with context-aware message 
- **cli:** lint exits non-zero on error messages by default BREAKING CHANGE: runenv lint now exits 1 on error-level messages (default --fail-on=error); plain-text output moved to stderr
- **legacy:** add back missing `--search-parent` option 
- **parser:** crash-safety in JSON/YAML/TOML loaders for None, list, and empty roots 

### Refactors

- **parser:** simplify the strip prefix logic 

### Chore

- bump version to 1.4.0 

### Test

- remove dependency on uncommitted .env file in project root 

## v1.3.0 (2025-06-05)

### Features

- add subcommands to better handle different use cases 

### Chore

- **changelog:** write CHANGELOG.md for version v1.3.0 

## v1.2.5 (2025-06-05)

### Fixes

- add python 3.13 as list of supported versions 

### Chore

- **changelog:** write CHANGELOG.md for version v1.2.5 

## v1.2.4 (2025-05-07)

### Fixes

- allow for # in comments, closes: #9 

### Chore

- **changelog:** write CHANGELOG.md for version v1.2.3 
- **changelog:** write CHANGELOG.md for version v1.2.3 

## v1.2.3 (2025-01-06)

### Fixes

- typo in `--strip-prefix` cli option 

### Chore

- rewrite CHANGELOG.md 
- **changelog:** write CHANGELOG.md for version v1.2.3 

### CI

- Run tests using uv + hatch 

### Dev

- upgrade flake.nix to self-contain without .venv 

### Docs

- fix path to requirements in .readthedocs.yaml 
- add .readthedocs.yaml to re-enable readthedocs integration 
- change artificial commits for v1.0.0 - split into separate files 
- update README.md 
- fix `--dry_run` to `--dry-run` in docs, along with single mispell 

### Style

- Move project into src, update flake.nix, Makefile & pyproject.toml with newest hatch layout. 

### Test

- exclude windows tests for 3.7 - has problem with hatch.exe 
- change pinned version for devel 
- change pytest version for python 3.7 
- change python-cov version for python 3.7 
- change mypy to 1.4.1 because of python 3.7 
- Fix tests for python >= 3.8 (annotations) 

## v1.2.2 (2024-10-04)

### Fixes

- change `--dry_run` into valid `--dry-run` option 

### Chore

- **changelog:** write CHANGELOG.md for version v1.2.2 

## v1.2.1 (2024-10-03)

### Features

- bring back python 3.7 

### Chore

- **changelog:** write CHANGELOG.md for version v1.2.0 
- **changelog:** write CHANGELOG.md for version v1.2.0 

### Docs

- remove ./docs in favor of README.md, convert *.rst to markdown versions 
- add CHANGELOG.md to the header tagble 
- add CHANGELOG.md to README.md file 

### Style

- remove empty line after TestRunenv cause tests on python 3.7 are complaining 

## v1.2.0 (2024-10-03)

### Features

- add support for ${VARIABLES} and support --prefix, --stip-prefix, --verbosity 1,2,3, --dry-run at command line 

### Chore

- **changelog:** write CHANGELOG.md for version v1.2.0 

### Docs

- rewrite README.md from scratch, providing python API fresh documentation, along wiht CLI usage 
- add CHANGELOG.md 

## v1.1.2 (2024-10-03)

### Fixes

- remove distutils in favor of shutil to support python 3.12 

### Build

- remove official support for python <=3.8 

### Docs

- update readme 

### Style

- fix ruff errors, and remove 2.7 python from travis 

## v1.1.1 (2024-10-03)

### Features

- migrate to pyproject.toml 
- add newest python versions to .travis.yml/tox.ini 

### Fixes

- support inline comments in .env files 
- readme.rst 
- get back README.rst 
- **doc:** README.md title 

## v1.0.1 (2017-02-03)

### Docs

- fix syntax error in README.md file 

## v1.0.0 (2017-02-03)

### Features

- add support python 3.5 

### Docs

- refine README.md 

## v0.4.0 (2016-08-08)

### Features

- add support for `search_parent` option to find .env files in parent directories 

## v0.3.1 (2016-06-21)

### Features

- add support for quoting values in .env files 

## v0.3.0 (2016-02-14)

### Build

- mark runenv as stable project 

## v0.2.5 (2015-11-30)

## v0.2.4 (2015-07-06)

### Features

- skip `load_env` if env file does not exists without failing 

## v0.2.3 (2015-06-26)

### Features

- support to run commands without explicite path, using PATH environment variable to find them 

## v0.2.2 (2015-06-16)

### Fixes

- support python 3.x 

## v0.2.1 (2015-06-16)

### Features

- add `strip-prefix` to the `load_env` python API function 

## v0.2.0 (2015-06-16)

### Features

- add `load_env` python API function 

## v0.1.4 (2015-06-15)

### Features

- check whether executable exists before run it 

## v0.1.3 (2015-06-01)

### Features

- add support for commened lines with # in .env files 

## v0.1.2 (2015-06-01)

### Features

- return exit code from runned command 

## v0.1.1 (2015-05-31)

### Fixes

- make runvenv work with many parameters for command 

## v0.1.0 (2015-05-31)

### Features

- Initial version of runenv 

