# ROADMAP

Combined, prioritized plan derived from
[PROBLEMS.md](./PROBLEMS.md) and [IMPROVEMENTS.md](./IMPROVEMENTS.md).

Ordering policy:
1. **Most important problems first** — correctness, crashes, and
   silent data corruption.
2. **Most-desired improvements next** — features that make runenv
   competitive with the dev/ops tooling it sits next to.
3. **Then the rest** — polish, ecosystem, and long-term vision.

Each item links back to its `P#` (problem) or `I#` (improvement) ID.

---

## Milestone 1 — v1.3.1 / v1.4.0: Correctness & Safety (critical bug fixes)

These are user-visible bugs that produce wrong behavior, crashes, or
mis-leading messages. They should be the next release.

| #   | Item                                                                  | From  |
| --- | --------------------------------------------------------------------- | ----- |
| 1   | ~~Fix legacy `args.cmd` → `args.command` AttributeError~~             | P1 ✓ |
| 2   | ~~Fix missing closing backticks in all "File … does not exist/exec" msg~~ | P2 ✓ |
| 3   | ~~Thread `--search-parent` through the legacy CLI~~                   | P3 ✓ |
| 4   | ~~Fix TOML loader error message ("YAML" → "TOML")~~                   | P13 ✓ |
| 5   | ~~Fix `strip_prefix` skip/strip double-guard logic (`key == prefix`)~~ | P14 ✓ |
| 6   | ~~Decide & implement consistent duplicate-key behavior (warn or fail)~~ | P16 ✓ |
| 7   | ~~Crash-safety in JSON/YAML/TOML loaders: handle `None`, lists, empty~~ | P19 ✓ |
| 8   | ~~Add `--lint-level` and `--fail-on` to `run`/`lint`/`list`; must be backward-compatible (current silent-load behaviour is preserved by default)~~ | — ✓  |
| 9   | ~~Make `runenv lint` exit non-zero on `error` messages; write to stderr~~ | P9 ✓ |
| 10  | ~~Replace "Environment file None does not exist" with a real message~~ | P6 ✓ |
| 11  | ~~Bare `runenv` (no subcommand, no legacy file) prints help, not error~~ | P7 ✓ |
| 12  | ~~Catch `ValueError("No env file found")` at CLI boundary~~           | P26 ✓ |

**Exit criteria:** all of the above have regression tests. Whole
test matrix green on Linux / macOS / Windows.

---

## Milestone 2 — v1.4.x: Parser correctness & lint usefulness

Fix the parser hazards so users can trust `runenv lint` and the
loaded values.

| #   | Item                                                              | From  |
| --- | ----------------------------------------------------------------- | ----- |
| 12  | ~~Document & test `${VAR}` fallback to `os.environ` (or remove it)~~ | P15 ✓ |
| 13  | ~~Detect circular `${VAR}` references; report in lint~~           | P15 ✓ |
| 14  | ~~Preserve real source line numbers for JSON/TOML/YAML~~             | P17, I8 ✓ |
| 15  | ~~Stop forcing `str(value)`; preserve types, normalize bools~~    | P18, I9 ✓ |
| 16  | ~~Remove dead quote-stripping code in `load_env_file`~~           | P20 ✓ |
| 17  | ~~Restrict env var names to POSIX `[A-Z_][A-Z0-9_]*` (warn on `.`)~~ | P21 ✓ |
| 18  | ~~Add tests for `lint`, JSON, YAML, TOML loaders~~                    | P31, P32 ✓ |
| 19  | ~~Skip `test_run_from_path` on Windows~~ (not needed: Git for Windows provides `true`/`false` on PATH in CI) | P33 ✓ |
| 20  | ~~Use `monkeypatch.chdir` in tests instead of bare `os.chdir`~~       | P34 ✓ |

**Exit criteria:** test coverage for parser ≥ 95 % (incl. negative
cases); `runenv lint` is wired into the repo's own pre-commit.

---

## Milestone 3 — v1.5.0: Dialect upgrade (most-wanted features)

Once the parser is solid, level up the .env dialect. These features
are routinely the reason users reach for `dotenv-cli`, `envsubst`,
or `direnv` instead of `runenv`.

| #   | Item                                                              | From  |
| --- | ----------------------------------------------------------------- | ----- |
| 21  | `${VAR:-default}` / `${VAR:?msg}` / `${VAR:+alt}` expansion       | I1    |
| 22  | Support `export VAR=...`                                          | I2    |
| 23  | Multi-line / heredoc values and standard escape sequences         | I3    |
| 24  | `$$` escape for literal `$`                                       | I4    |
| 25  | `--strict` mode (fail on undefined refs / duplicates)             | I18   |
| 26  | Required-variable declarations + lint                             | I6    |
| 27  | Include / extend other env files (`# @include …`)                 | I7    |
| 28  | Inline-comment behavior documented & tested (`#` in unquoted)     | P24   |

**Exit criteria:** documented dialect spec in `docs/dialect.md`;
`hypothesis`-based parser fuzz tests passing.

---

## Milestone 4 — v1.6.0: CLI ergonomics & dev/ops surface

Make `runenv` pleasant for daily use and CI/CD.

| #   | Item                                                                | From  |
| --- | ------------------------------------------------------------------- | ----- |
| 29  | `runenv export --format=dotenv|docker|k8s-configmap|json|yaml|shell`| I11   |
| 30  | `runenv diff <a> <b>`                                               | I12   |
| 31  | `runenv check` (lint + schema + required + drift, CI-friendly)      | I13   |
| 32  | `runenv init` / `runenv scaffold`                                   | I14   |
| 33  | `runenv set` / `runenv get` / `runenv unset` (comment-preserving)   | I16   |
| 34  | `runenv shell` (interactive subshell)                               | I15   |
| 35  | `--env=<name>` shorthand → `.env.<name>`                            | I19   |
| 36  | `-q/--quiet`, `--log-format=json`, editor-friendly lint output      | I20   |
| 37  | Replace `argparse.REMAINDER` & make `--` optional                   | P10, I17 |
| 38  | `os.execvpe` on POSIX; signal forwarder on Windows                  | I21, P38 |
| 39  | Profiles directory (`.runenv/`)                                     | I10   |
| 40  | Harden legacy detection (explicit flag instead of file-heuristic)   | P8    |
| 41  | Remove unused `--help-legacy` (or implement it)                     | P12   |

**Exit criteria:** every command has `--help` examples; bash/zsh/fish
completions ship; runenv `--version` cold-start ≤ 30 ms.

---

## Milestone 5 — v1.7.0: Python API polish

Make the SDK pleasant for application code.

| #   | Item                                                          | From  |
| --- | ------------------------------------------------------------- | ----- |
| 42  | `load_env` returns the loaded mapping                         | I33   |
| 43  | Context-manager API (`with runenv.activated(...): ...`)       | I34   |
| 44  | Typed settings object (stdlib-only)                           | I32   |
| 45  | `find_env_file(path, names=[...])`                            | I35   |
| 46  | Export `ParseMessage`/`ParseOptions`/`EnvParser`              | I36   |
| 47  | Document or namespace `_RUNENV_WRAPPED`                       | P29   |
| 48  | Align CLI / API defaults for `strip_prefix`                   | P30   |
| 49  | De-duplicate `find_env_file` calls between CLI and API        | P11, P27 |

**Exit criteria:** mypy-strict clean; published typed stubs; docs
site shows API alongside CLI.

---

## Milestone 6 — v2.0.0: Secrets management

Once the basics are rock-solid, this is the differentiator vs.
plain `dotenv`.

| #   | Item                                                                | From  |
| --- | ------------------------------------------------------------------- | ----- |
| 50  | `runenv encrypt` / `runenv decrypt` with `age`                      | I22   |
| 51  | Per-value encrypted markers                                         | I22   |
| 52  | `sops` integration & auto-detection of `.env.sops.*`                | I24   |
| 53  | Cloud secret-manager resolvers (AWS SM, GCP SM, Vault, 1Password)   | I23   |
| 54  | `# @secret` redaction in `list`/`export` (with `--reveal`)          | I25   |
| 55  | `runenv audit` for committed-secret detection + pre-commit hook    | I26, I41 |

**Exit criteria:** documented threat model; integration tests against
sops / age / a local Vault dev server.

---

## Milestone 7 — v2.x: Ecosystem & integrations

| #   | Item                                                       | From   |
| --- | ---------------------------------------------------------- | ------ |
| 56  | Direnv `use runenv` helper                                 | I38    |
| 57  | docker / docker-compose / Helm export recipes              | I39    |
| 58  | Shell completions (`runenv completion bash|zsh|fish`)      | I40    |
| 59  | `runenv hook bash|zsh|fish` for auto-loading (à la direnv) | I40    |
| 60  | GitHub Action `onjin/runenv-action`                        | I42    |
| 61  | Framework helpers: Django / FastAPI / pytest plugin        | I37    |
| 62  | JSON-Schema / `.env.example` generators                    | I43    |

**Exit criteria:** examples directory covers each integration;
`examples/` is tested in CI.

---

## Milestone 8 — Performance & hygiene (continuous)

| #   | Item                                                         | From   |
| --- | ------------------------------------------------------------ | ------ |
| 63  | Class-level cached `LOADERS` & compiled regexes              | I28, P25 |
| 64  | Stream-based parser path                                     | I27    |
| 65  | mtime/content cache (`$XDG_CACHE_HOME/runenv/…`)             | I30    |
| 66  | Benchmark harness in CI (`pytest-benchmark`)                 | I49    |
| 67  | Drop Python 3.7 / 3.8, modernize typing                      | I44, P35 |
| 68  | Tighten `.gitignore`; remove committed dev artifacts          | I45, P39 |
| 69  | Convert `subprocess.check_call(env=os.environ)` → `dict(...)` | P40   |
| 70  | Sigstore-signed releases + CycloneDX SBOM                    | I50    |

---

## Milestone 9 — Long horizon (v3+)

| #   | Item                                                                | From  |
| --- | ------------------------------------------------------------------- | ----- |
| 71  | Static-binary CLI (Go / Rust) for ops environments without Python   | I51   |
| 72  | Multi-language SDKs sharing a dialect conformance suite             | I52   |
| 73  | Optional Rust parser via `maturin` for very large files             | I31   |

---

## Quick "next 90 days" view

If only one stretch of work happens, it should be:

1. **Milestone 1** — release as `v1.3.1`. Bug-fix only. (~1 week)
2. **Milestone 2** — release as `v1.4.0`. Parser + lint trust.
   (~2-3 weeks)
3. **Milestone 3** — release as `v1.5.0`. Dialect upgrade.
   (~4-6 weeks)

After v1.5.0, runenv is competitive with `dotenv-cli` /
`python-dotenv` and meaningfully ahead of them on lint + multi-format
support. The bigger bets (M4+) can then proceed in parallel based on
user demand.
