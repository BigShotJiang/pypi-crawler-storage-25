import numpy as np
from scipy.interpolate import interp1d
from.beiker_string import generate_unique_column_name
import pandas as pd

def fix_serial_numbers(df, column, daCode):
    """
    修复序列号并同步处理daCode字段，添加详细容错机制。

    参数:
    df (pd.DataFrame): 输入的DataFrame。
    column (str): 需要修复的序列号列名。
    daCode (str): 需要同步补零的档号列名。

    返回:
    tuple: 处理后的DataFrame和检测到修改的位置列表。
    """
    detected_positions = []
    zero_counts = {}  # 记录每个行补零次数

    # 处理主列
    for i in range(1, len(df) - 1):
        try:
            prev_num = df.at[i - 1, column]
            current_num = df.at[i, column]
            next_num = df.at[i + 1, column]

            # 检查是否需要补零 [[用户原有逻辑]]
            if prev_num + 1 != current_num and next_num - 1 != current_num:
                num_str = str(current_num)
                k = 0
                max_attempts = 10  # 防止无限循环 [[容错]]
                while k < max_attempts:
                    num_str += '0'
                    k += 1
                    try:
                        new_num = int(num_str)
                    except ValueError:
                        break  # 无法转换时停止
                    # 检查是否在前后数值之间 [[用户原有逻辑]]
                    if prev_num < new_num < next_num:
                        df.at[i, column] = new_num
                        detected_positions.append(i)
                        zero_counts[i] = k  # 记录补零次数
                        break
        except Exception as e:
            print(f"处理行{i}时发生错误: {e}")

    # 处理daCode列
    if daCode in df.columns:
        for i in zero_counts:
            try:
                original_val = df.at[i, daCode]
                # 应用相同次数的补零 [[9]]
                new_val = str(original_val) + '0' * zero_counts[i]
                df.at[i, daCode] = new_val
            except Exception as e:
                print(f"处理daCode列行{i}时出错: {e}")
    else:
        print(f"警告: daCode列 '{daCode}' 不存在，已跳过")  # [[容错]]

    return df, detected_positions
def convert_float_strings(df, column_names=None):
    """
    该函数用于将 DataFrame 中可转换为整数的浮点数字符串转换为整数字符串。

    参数:
    df (pandas.DataFrame): 输入的 DataFrame
    column_names (list, optional): 要进行转换的列名列表。如果为 None，则对所有列进行转换。

    返回:
    pandas.DataFrame: 转换后的 DataFrame
    """
    def convert_value(value):
        """
        内部函数，用于检查单个值是否为可转换为整数的浮点数字符串，并进行转换。

        参数:
        value: 输入的值

        返回:
        若值为可转换为整数的浮点数字符串，则返回对应的整数字符串；否则返回原值。
        """
        try:
            # 检查值是否为字符串
            if isinstance(value, str):
                # 尝试将字符串转换为浮点数
                float_val = float(value)
                # 检查浮点数是否为整数
                if float_val.is_integer():
                    return str(int(float_val))
        except ValueError:
            # 若转换失败，说明不是有效的浮点数，直接返回原值
            pass
        except Exception as e:
            # 捕获其他未知异常，并打印错误信息
            print(f"处理值 {value} 时发生未知错误: {e}")
        return value

    try:
        if column_names is None:
            # 如果未指定列名，对 DataFrame 中的每个元素应用转换函数
            return df.applymap(convert_value)
        else:
            # 对指定列应用转换函数
            for col in column_names:
                if col in df.columns:
                    df[col] = df[col].apply(convert_value)
                else:
                    print(f"列 {col} 不存在于 DataFrame 中，跳过该列。")
            return df
    except AttributeError:
        # 若输入不是有效的 DataFrame，捕获 AttributeError 并给出提示
        print("输入不是有效的 pandas DataFrame，请检查输入。")
    except Exception as e:
        # 捕获其他未知异常，并打印错误信息
        print(f"处理 DataFrame 时发生未知错误: {e}")

def remove_leading_zeros(df, columns, daCode):
    """
    去除DataFrame指定列中字符串前面的零，并处理daCode字段。

    参数:
    df (pd.DataFrame): 输入的DataFrame。
    columns (list): 需要处理前导零的列名列表。
    daCode (str): 需要特殊处理的档号字段名。

    返回:
    pd.DataFrame: 处理后的DataFrame。

    功能说明:
    1. 对columns列表中的列，去除字符串形式数字的前导零
    2. 对daCode字段应用定制的trim_leading_zeros处理
    3. 包含完整的容错机制和状态提示
    """
    
    def process_string(s):
        """处理普通列的前导零"""
        try:
            return str(int(str(s))) if pd.notnull(s) else s  # 处理NaN值 [[9]]
        except (ValueError, TypeError):
            return s
    
    def process_da_code(s):
        """处理daCode字段的特殊规则"""
        try:
            return trim_leading_zeros(str(s)) if pd.notnull(s) else s
        except Exception as e:
            print(f"daCode处理异常（值: {s}）: {str(e)}")
            return s
    
    # 处理常规列的前导零 [[1]][[9]]
    for col in columns:
        if col in df.columns:
            df[col] = df[col].apply(process_string)
        else:
            print(f"警告: 列 '{col}' 不存在，已跳过")
    
    # 处理daCode字段 [[4]][[8]]
    if daCode in df.columns:
        df[daCode] = df[daCode].apply(process_da_code)
    else:
        print(f"警告: daCode列 '{daCode}' 不存在，已跳过")
    
    return df
    
def trim_leading_zeros(s):
    # 分割最后一个点的位置
    last_dot_idx = s.rfind('.')
    
    # 处理无点或点在末尾的特殊情况 [[4]][[6]]
    if last_dot_idx == -1 or last_dot_idx == len(s)-1:
        return s
    
    left_part = s[:last_dot_idx]
    right_part = s[last_dot_idx+1:]
    
    # 去除右侧部分的前导零 [[1]][[8]]
    stripped_right = right_part.lstrip('0')
    if not stripped_right:  # 处理全零情况 [[3]]
        stripped_right = '0'
    
    return f"{left_part}.{stripped_right}"

def linear_interpolation(arr):
    """
    数组由一系列连续的数字组成，但个别位置可能是None或空字符串，用线型插值的方法补全。
    """
    # 将数组转换为浮点数类型，并将空字符串和None转换为numpy.nan
    arr = np.array([float(x) if x != '' and x is not None else np.nan for x in arr])

    # 找出所有非缺失值的索引和对应的值
    non_missing = ~np.isnan(arr)
    x = np.arange(len(arr))[non_missing]
    y = arr[non_missing]

    # 确保至少有两个非缺失值来构建插值函数
    if len(x) < 2:
        raise ValueError("至少需要两个非缺失值来构建插值函数")

    # 创建线性插值函数
    interp_func = interp1d(x, y, kind='linear', bounds_error=False, fill_value='extrapolate')

    # 对整个数组进行插值
    interpolated_arr = interp_func(np.arange(len(arr)))

    return interpolated_arr

def check_for_discontinuities(s):
    # 将Series中的None替换为NaN
    s = s.fillna(np.nan)
    
    # 尝试将Series转换为数值类型，非数字将变为NaN
    numeric_s = pd.to_numeric(s, errors='coerce')
    
    # 计算连续数字之间的差异
    diffs = numeric_s.diff().abs()
    
    # 找出差异大于1的位置，这可能是突变的位置
    jumps = diffs[diffs > 1].index
    
    # 找出NaN的位置，即原始数据中None的位置
    non_numeric = s.isna()
    
    # 找出非数字字符的位置
    non_numeric |= s.apply(lambda x: isinstance(x, str) and x.isdigit() == False)
    
    # 将突变的位置、NaN的位置和非数字字符的位置合并
    issues = non_numeric.astype('object') | jumps.to_series().astype('object')

    # 检查是否存在问题
    if issues.any():
        # 创建一个新的Series，将有问题的位置替换为''
        clean_s = s.copy()
        clean_s[issues] = ''
        # 返回False，有问题的数据，以及清理后的s
        return False, s[issues], clean_s
    else:
        # 如果没有发现问题，返回True和原始数据
        return True, s, s
    
def check_column_names(df, column_function_dict):  
    """  
    检查并更新DataFrame的列名，确保新列名唯一。  
    使用时要 import pandas as pd ，from functools import partial  
    参数:  
    df : pandas.DataFrame  
        需要检查和更新列名的DataFrame。  
    column_function_dict : dict  
        一个字典，其中键为列索引，值为处理函数。处理函数用于检查列数据并返回新的列名。字典格式如下：  
    column_function_dict = {  
        1: partial(is_labels_series, values=['男', '女'], labels=('性别', '未识别')),  
    }
    返回:  
    tuple  
        返回一个元组，包含更新后的DataFrame和新的列名列表。  
    """  

    # 创建新的列名列表，初始为DataFrame的当前列名  
    new_column_names = df.columns.tolist()  
    
    # 遍历列索引和对应的处理函数  
    for column_index, function in column_function_dict.items():  
        # 检查列索引是否在DataFrame的有效范围内  
        if column_index < len(df.columns):  
            # 获取指定列的数据作为Series  
            series = df.iloc[:, column_index]  
            
            # 调用处理函数，返回是否为子集的布尔值和新的列名  
            is_subset, label = function(series)  
            
            # 生成唯一的列名，确保新列名不与现有列名重复  
            unique_label = generate_unique_column_name(new_column_names, label)  
            
            # 更新新的列名列表中的对应列名  
            new_column_names[column_index] = unique_label  

    # 将DataFrame的列名更新为新的列名列表  
    df.columns = new_column_names  
    
    # 返回更新后的DataFrame和新的列名列表  
    return df, new_column_names

def merge_columns_to_dict_series(df, columns, new_column_name):
    """
    将给定列的数据合并成字典，并创建一个新列存储这些字典的字符串表示。

    参数:
    df : pd.DataFrame
        要处理的DataFrame。
    columns : list
        要合并的列名列表。
    new_column_name : str
        新列的列名，用于存储字典的字符串表示。

    返回:
    pd.DataFrame
        更新后的DataFrame。
    """
    # # 确保新列名不在列名列表中
    # if new_column_name in columns:
    #     raise ValueError(f"新列名 '{new_column_name}' 不能在给定列中。")
    
    # 将每一行的给定列数据合并成字典
    df[new_column_name] = df[columns].apply(lambda row: {col: row[col] for col in columns}, axis=1)
    
    # 将字典转换为字符串形式
    df[new_column_name] = df[new_column_name].apply(lambda d: str(d))
    
    # 删除给定列
    df.drop(columns=columns, axis=1, inplace=True)
    
    return df

def remove_columns_duplicates(df, columns, empty_flag=True):
    """
    删除DataFrame中指定列中的重复行，可选择忽略空值。

    参数:
    df : pd.DataFrame
        要处理的DataFrame。
    columns : list
        需要检查重复值的列名列表。
    empty_flag : bool, 默认为True
        如果为True，不处理单元格值为空的行。

    返回:
    pd.DataFrame
        删除重复行后的DataFrame。
    """
    # 创建一个副本，以免修改原始DataFrame
    df = df.copy()

    # 检查每一列是否有重复值，如果有，则只保留第一个出现的行
    for col in columns:
        # 去重前先找出所有重复项的索引
        duplicated = df.duplicated(subset=col, keep=False)
        if empty_flag:
            # 仅处理非空值
            duplicated &= df[col].notna()
        # 反向索引，即保留重复项和非空值项，删除其他项
        df = df[~duplicated]
        
        # 由于删除了重复项，需要重置索引
        df.reset_index(drop=True, inplace=True)
        
    return df