import os
import time
import logging
import argparse
import mysql.connector
import hashlib
import json
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from datetime import datetime

# 配置日志记录
# 设置日志记录的基本配置，日志级别为 INFO，日志格式包含时间、日志级别和具体信息
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

# 数据库连接配置
# 定义一个字典，包含数据库连接所需的信息，如主机地址、数据库名、用户名和密码
DB_CONFIG = {
    'host': '192.168.110.161',
    'database': 'beikerOAMS',
    'user': 'root',
    'password': r'Dag19970625/'
}

GLOBAL_CONFIG = {
    'retry_time': 5,  # 等待重试的时间（秒），当操作失败时，等待指定时间后重试
    'retry_count': 3,  # 重试次数，操作失败后最多重试的次数
    'batch_size': 30,  # 批量大小，在获取待处理文件列表时，每次获取的文件数量
    'initial_scan_batch_size': 30,  # 新增参数，初始扫描文件时的分批大小
    'task_filters': {}  # 存储每个任务的过滤规则，用于判断文件是否需要监控
}
    #以下两个配置放入task_filters中：
    # 'first_level_dir': 默认False,  # 如果为 true，只监控 FOLDER_LIST 指定文件夹列表的第一级目录，不监控下面的子目录，默认为 false
    # 'recheck_on_restart': 默认False  # 当该参数为 True 时，在 watch_task 函数重新启动后，会重新统计指定文件夹里的文件路径



# 定义一个函数，用于创建数据库连接
def create_db_connection():
    try:
        # 使用 mysql.connector 模块的 connect 方法，根据 DB_CONFIG 中的配置信息创建数据库连接
        connection = mysql.connector.connect(**DB_CONFIG)
        if connection.is_connected():
            # 如果连接成功，记录日志信息
            logging.info('Connected to MySQL database')
            return connection
    except mysql.connector.Error as e:
        # 如果连接失败，记录错误日志信息
        logging.error(f'Error while connecting to MySQL: {e}')
        return None


# 定义一个函数，用于计算文件的 MD5 哈希值，添加重试逻辑
def get_file_md5(file_path):
    retries = 0
    while retries < GLOBAL_CONFIG['retry_count']:
        try:
            # 创建一个 MD5 哈希对象
            hash_md5 = hashlib.md5()
            # 以二进制只读模式打开文件
            with open(file_path, "rb") as f:
                # 逐块读取文件内容，每次读取 4096 字节
                for chunk in iter(lambda: f.read(4096), b""):
                    # 更新哈希对象的内容
                    hash_md5.update(chunk)
            # 返回文件的 MD5 哈希值的十六进制表示
            return hash_md5.hexdigest()
        except Exception as e:
            # 如果读取文件或计算哈希值时出现错误，记录错误日志信息
            logging.error(f"Error getting MD5 for {file_path}: {e}")
            retries += 1
            if retries < GLOBAL_CONFIG['retry_count']:
                # 如果重试次数未达到上限，记录等待重试的日志信息，并等待指定时间
                logging.info(f"Retrying in {GLOBAL_CONFIG['retry_time']} seconds...")
                time.sleep(GLOBAL_CONFIG['retry_time'])
    return None


# 定义一个函数，用于根据过滤规则判断文件是否需要监控
def filter_file(task_id, file_path):
    # 获取文件的基本名称（不包含路径）
    file_name = os.path.basename(file_path)
    # 获取文件所在的文件夹路径
    folder_name = os.path.dirname(file_path)
    # 从全局配置中获取指定任务的过滤规则，如果任务不存在，则使用默认的过滤规则
    filter_rules = GLOBAL_CONFIG['task_filters'].get(task_id, {
        'exclude_folders': [],
        'exclude_files': [],
        'exclude_extensions': [],
        'exclude_file_suffixes': [],
        'exclude_folder_suffixes': [],
        'exclude_file_prefixes': [],
        'exclude_folder_prefixes': [],
        'exclude_regex_folders': [],
        'exclude_regex_files': [],
        'include_files': [],
        'include_folders': [],
        'include_file_suffixes': [],
        'include_folder_suffixes': [],
        'include_file_prefixes': [],
        'include_folder_prefixes': [],
        'only_extensions': [],
        'only_files_regrex': [],
        'only_folders_regrex': [],
        'first_level_dir': False,
        'recheck_on_restart': False
    })

    # 检查排除规则
    # 遍历排除文件夹规则列表
    for rule in filter_rules['exclude_folders']:
        if rule in folder_name:
            # 如果文件夹路径包含排除规则中的内容，则返回 False，表示该文件不需要监控
            return False
    # 遍历排除文件规则列表
    for rule in filter_rules['exclude_files']:
        if rule == file_name:
            # 如果文件名与排除规则中的内容相同，则返回 False，表示该文件不需要监控
            return False
    # 遍历排除文件扩展名规则列表
    for rule in filter_rules['exclude_extensions']:
        if file_name.endswith(rule):
            # 如果文件名以排除规则中的扩展名结尾，则返回 False，表示该文件不需要监控
            return False
    # 遍历排除文件后缀规则列表
    for rule in filter_rules['exclude_file_suffixes']:
        if file_name.endswith(rule):
            # 如果文件名以排除规则中的后缀结尾，则返回 False，表示该文件不需要监控
            return False
    # 遍历排除文件夹后缀规则列表
    for rule in filter_rules['exclude_folder_suffixes']:
        if folder_name.endswith(rule):
            # 如果文件夹路径以排除规则中的后缀结尾，则返回 False，表示该文件不需要监控
            return False
    # 遍历排除文件前缀规则列表
    for rule in filter_rules['exclude_file_prefixes']:
        if file_name.startswith(rule):
            # 如果文件名以排除规则中的前缀开头，则返回 False，表示该文件不需要监控
            return False
    # 遍历排除文件夹前缀规则列表
    for rule in filter_rules['exclude_folder_prefixes']:
        if folder_name.startswith(rule):
            # 如果文件夹路径以排除规则中的前缀开头，则返回 False，表示该文件不需要监控
            return False
    import re
    # 遍历排除文件夹正则表达式规则列表
    for rule in filter_rules['exclude_regex_folders']:
        if re.search(rule, folder_name):
            # 如果文件夹路径匹配排除规则中的正则表达式，则返回 False，表示该文件不需要监控
            return False
    # 遍历排除文件正则表达式规则列表
    for rule in filter_rules['exclude_regex_files']:
        if re.search(rule, file_name):
            # 如果文件名匹配排除规则中的正则表达式，则返回 False，表示该文件不需要监控
            return False

    # 检查 only_extensions 规则
    if filter_rules['only_extensions']:
        if not any(file_name.endswith(ext) for ext in filter_rules['only_extensions']):
            return False

    # 检查 only_files_regrex 规则
    if filter_rules['only_files_regrex']:
        if not any(re.search(reg, file_name) for reg in filter_rules['only_files_regrex']):
            return False

    # 检查 only_folders_regrex 规则
    if filter_rules['only_folders_regrex']:
        if not any(re.search(reg, folder_name) for reg in filter_rules['only_folders_regrex']):
            return False

    # 检查包含规则
    if filter_rules['include_files']:
        if file_name not in filter_rules['include_files']:
            # 如果包含文件规则列表不为空，且文件名不在该列表中，则返回 False，表示该文件不需要监控
            return False
    if filter_rules['include_folders']:
        if not any(folder in folder_name for folder in filter_rules['include_folders']):
            # 如果包含文件夹规则列表不为空，且文件夹路径不包含该列表中的任何内容，则返回 False，表示该文件不需要监控
            return False
    if filter_rules['include_file_suffixes']:
        if not any(file_name.endswith(suffix) for suffix in filter_rules['include_file_suffixes']):
            # 如果包含文件后缀规则列表不为空，且文件名不以该列表中的任何后缀结尾，则返回 False，表示该文件不需要监控
            return False
    if filter_rules['include_folder_suffixes']:
        if not any(folder_name.endswith(suffix) for suffix in filter_rules['include_folder_suffixes']):
            # 如果包含文件夹后缀规则列表不为空，且文件夹路径不以该列表中的任何后缀结尾，则返回 False，表示该文件不需要监控
            return False
    if filter_rules['include_file_prefixes']:
        if not any(file_name.startswith(prefix) for prefix in filter_rules['include_file_prefixes']):
            # 如果包含文件前缀规则列表不为空，且文件名不以该列表中的任何前缀开头，则返回 False，表示该文件不需要监控
            return False
    if filter_rules['include_folder_prefixes']:
        if not any(folder_name.startswith(prefix) for prefix in filter_rules['include_folder_prefixes']):
            # 如果包含文件夹前缀规则列表不为空，且文件夹路径不以该列表中的任何前缀开头，则返回 False，表示该文件不需要监控
            return False

    return True


# 定义一个类，继承自 FileSystemEventHandler 类，用于处理文件系统事件
class FileMonitorHandler(FileSystemEventHandler):
    def __init__(self, task_id):
        # 初始化任务 ID
        self.task_id = task_id
        # 创建数据库连接
        self.connection = create_db_connection()

    def on_created(self, event):
        if not event.is_directory:
            # 如果事件不是目录创建事件，获取文件路径
            file_path = event.src_path
            if filter_file(self.task_id, file_path):
                # 如果文件符合过滤规则，则将文件添加到数据库
                self.add_file_to_db(file_path)

    def on_deleted(self, event):
        if not event.is_directory:
            # 如果事件不是目录删除事件，获取文件路径
            file_path = event.src_path
            if filter_file(self.task_id, file_path):
                # 如果文件符合过滤规则，则处理文件删除事件
                self.handle_deleted_file(file_path)

    def handle_deleted_file(self, file_path):
        retries = 0
        while retries < GLOBAL_CONFIG['retry_count']:
            try:
                # 创建数据库游标
                cursor = self.connection.cursor()
                # 执行 SQL 查询，查找指定任务下，文件路径为指定路径，且处理状态为 'pending' 的记录
                query = "SELECT id, process_status FROM file_watcher WHERE task_id = %s AND filePath = %s AND process_status = 'pending'"
                cursor.execute(query, (self.task_id, file_path))
                result = cursor.fetchone()
                if result:
                    # 如果查询到结果，将该记录的处理状态更新为 'except'
                    update_query = "UPDATE file_watcher SET process_status = 'except' WHERE id = %s"
                    cursor.execute(update_query, (result[0],))
                    self.connection.commit()
                    # 记录日志信息
                    logging.info(f'Set status of deleted file {file_path} to except')
                break
            except mysql.connector.Error as e:
                # 如果执行 SQL 语句时出现错误，记录错误日志信息
                logging.error(f'Error while handling deleted file: {e}')
                retries += 1
                if retries < GLOBAL_CONFIG['retry_count']:
                    # 如果重试次数未达到上限，记录等待重试的日志信息，并等待指定时间
                    logging.info(f"Retrying in {GLOBAL_CONFIG['retry_time']} seconds...")
                    time.sleep(GLOBAL_CONFIG['retry_time'])

    def add_file_to_db(self, file_path):
        retries = 0
        while retries < GLOBAL_CONFIG['retry_count']:
            try:
                # 获取文件的大小
                file_size = os.path.getsize(file_path)
                if file_size == 0:
                    # 如果文件大小为 0，记录日志信息并返回
                    logging.info(f'File {file_path} has size 0, ignoring.')
                    return
            except OSError as e:
                # 如果获取文件大小失败，记录错误日志信息
                logging.error(f'Error getting size of {file_path}: {e}')
                retries += 1
                if retries < GLOBAL_CONFIG['retry_count']:
                    # 如果重试次数未达到上限，记录等待重试的日志信息，并等待指定时间
                    logging.info(f"Retrying in {GLOBAL_CONFIG['retry_time']} seconds...")
                    time.sleep(GLOBAL_CONFIG['retry_time'])
                continue

            # 计算文件的 MD5 哈希值
            md5 = get_file_md5(file_path)
            if md5 is None:
                return
            try:
                # 创建数据库游标
                cursor = self.connection.cursor()
                # 执行 SQL 查询，查找指定任务下，文件路径为指定路径的记录
                query = "SELECT id, md5 FROM file_watcher WHERE task_id = %s AND filePath = %s"
                cursor.execute(query, (self.task_id, file_path))
                result = cursor.fetchone()
                # 获取当前时间的字符串表示
                current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                if result:
                    # 如果查询到结果，获取记录的 MD5 哈希值
                    existing_md5 = result[1]
                    if existing_md5 != md5:
                        # 如果记录的 MD5 哈希值与当前计算的 MD5 哈希值不同，更新记录的 MD5 哈希值和处理状态
                        update_query = "UPDATE file_watcher SET md5 = %s, process_status = 'pending', updated_at = %s WHERE id = %s"
                        cursor.execute(update_query, (md5, current_time, result[0]))
                        self.connection.commit()
                        # 记录日志信息
                        logging.info(f'Updated file {file_path} in database')
                else:
                    # 如果查询不到结果，插入一条新记录
                    insert_query = "INSERT INTO file_watcher (task_id, filePath, process_status, md5, created_at, updated_at) VALUES (%s, %s, 'pending', %s, %s, %s)"
                    cursor.execute(insert_query, (self.task_id, file_path, md5, current_time, current_time))
                    self.connection.commit()
                    # 记录日志信息
                    logging.info(f'Added file {file_path} to database')
                break
            except mysql.connector.Error as e:
                # 如果执行 SQL 语句时出现错误，记录错误日志信息
                logging.error(f'Error while adding file to database: {e}')
                retries += 1
                if retries < GLOBAL_CONFIG['retry_count']:
                    # 如果重试次数未达到上限，记录等待重试的日志信息，并等待指定时间
                    logging.info(f"Retrying in {GLOBAL_CONFIG['retry_time']} seconds...")
                    time.sleep(GLOBAL_CONFIG['retry_time'])


# 定义一个函数，用于启动一个监控任务
def watch_task(task_id, FOLDER_LIST):
    try:
        # 创建数据库连接
        connection = create_db_connection()
        # 创建数据库游标
        cursor = connection.cursor(buffered=True)
        # 执行 SQL 查询，查找指定任务下的记录
        query = "SELECT id FROM file_watcher WHERE task_id = %s"
        cursor.execute(query, (task_id,))
        result = cursor.fetchone()
        # 判断任务是否是第一次启动
        is_first_time = result is None
        task_config = GLOBAL_CONFIG['task_filters'].get(task_id, {
            'first_level_dir': False,
            'recheck_on_restart': False
        })
        if is_first_time:
            # 初始化当前文件夹索引和当前文件索引
            current_folder_index = 0
            current_file_index = 0
            batch = []
            handler = FileMonitorHandler(task_id)
            for folder_index, folder in enumerate(FOLDER_LIST):
                if folder_index < current_folder_index:
                    continue
                if task_config['first_level_dir']:
                    # 只监控第一级目录
                    for file in os.listdir(folder):
                        file_path = os.path.join(folder, file)
                        if os.path.isfile(file_path) and filter_file(task_id, file_path):
                            batch.append(file_path)
                        if len(batch) >= GLOBAL_CONFIG['initial_scan_batch_size']:
                            for path in batch:
                                handler.add_file_to_db(path)
                            logging.info(f"成功存入 {len(batch)} 条记录到数据库。")
                            batch = []
                            # 保存当前处理位置
                            current_folder_index = folder_index
                            current_file_index = list(os.listdir(folder)).index(file) + 1
                else:
                    for root, dirs, files in os.walk(folder):
                        for file_index, file in enumerate(files):
                            if folder_index == current_folder_index and file_index < current_file_index:
                                continue
                            file_path = os.path.join(root, file)
                            if filter_file(task_id, file_path):
                                batch.append(file_path)
                            if len(batch) >= GLOBAL_CONFIG['initial_scan_batch_size']:
                                for path in batch:
                                    handler.add_file_to_db(path)
                                logging.info(f"成功存入 {len(batch)} 条记录到数据库。")
                                batch = []
                                # 保存当前处理位置
                                current_folder_index = folder_index
                                current_file_index = file_index + 1
            # 处理最后一批文件
            if batch:
                for path in batch:
                    handler.add_file_to_db(path)
                logging.info(f"成功存入 {len(batch)} 条记录到数据库。")

        # 重新启动时检查是否有新增文件
        if task_config['recheck_on_restart']:
            # 获取数据库中 process_status 为 pending、completed、suspended 的所有文件路径
            cursor.execute("SELECT filePath FROM file_watcher WHERE task_id = %s AND process_status IN ('pending', 'completed', 'suspended')", (task_id,))
            db_files = [row[0] for row in cursor.fetchall()]

            # 重新统计指定文件夹里的文件路径
            all_files = []
            for folder in FOLDER_LIST:
                if task_config['first_level_dir']:
                    # 只监控第一级目录
                    for file in os.listdir(folder):
                        file_path = os.path.join(folder, file)
                        if os.path.isfile(file_path) and filter_file(task_id, file_path):
                            all_files.append(file_path)
                else:
                    for root, dirs, files in os.walk(folder):
                        for file in files:
                            file_path = os.path.join(root, file)
                            if filter_file(task_id, file_path):
                                all_files.append(file_path)

            # 找出新增的文件
            new_files = [file for file in all_files if file not in db_files]

            # 确保游标没有未读取的结果
            if cursor.with_rows:
                cursor.fetchall()

            # 将新增的文件添加到数据库
            handler = FileMonitorHandler(task_id)
            for file in new_files:
                handler.add_file_to_db(file)
            if new_files:
                logging.info(f"发现 {len(new_files)} 个新增文件，已添加到数据库。")

        # 创建文件监控处理对象
        event_handler = FileMonitorHandler(task_id)
        # 创建文件系统观察者对象
        observer = Observer()
        for folder in FOLDER_LIST:
            # 为每个文件夹安排监控任务，是否递归根据 first_level_dir 决定
            recursive = not task_config['first_level_dir']
            observer.schedule(event_handler, path=folder, recursive=recursive)
        # 启动观察者
        observer.start()
        # 记录日志信息
        logging.info(f'Started monitoring task {task_id}')
        try:
            while True:
                # 程序进入无限循环，每隔 1 秒休眠一次
                time.sleep(1)
        except KeyboardInterrupt:
            # 如果用户按下 Ctrl+C，停止观察者
            observer.stop()
        # 等待观察者线程结束
        observer.join()
    except mysql.connector.Error as e:
        # 如果执行 SQL 语句时出现错误，记录错误日志信息
        logging.error(f'Error while starting task {task_id}: {e}')


# 定义一个函数，用于获取待处理的文件列表
def get_file(task_id):
    # 获取批量大小
    batch_size = GLOBAL_CONFIG['batch_size']
    retries = 0
    while retries < GLOBAL_CONFIG['retry_count']:
        try:
            # 创建数据库连接
            connection = create_db_connection()
            # 创建数据库游标
            cursor = connection.cursor()
            # 执行 SQL 查询，查找指定任务下，处理状态为 'pending' 的记录，最多返回指定批量大小的记录
            query = "SELECT id, filePath FROM file_watcher WHERE task_id = %s AND process_status = 'pending' LIMIT %s"
            cursor.execute(query, (task_id, batch_size))
            files = cursor.fetchall()
            # 提取查询结果中的文件路径
            file_paths = [file[1] for file in files]
            unique_file_paths = []
            for file_path in file_paths:
                if file_path not in unique_file_paths:
                    # 如果文件路径不在唯一文件路径列表中，将其添加到列表中
                    unique_file_paths.append(file_path)
                else:
                    # 如果文件路径已经存在于唯一文件路径列表中，将该记录的处理状态更新为 'except'
                    update_query = "UPDATE file_watcher SET process_status = 'except' WHERE filePath = %s"
                    cursor.execute(update_query, (file_path,))
                    connection.commit()
            valid_file_paths = []
            for file_path in unique_file_paths:
                if os.path.exists(file_path):
                    # 如果文件存在，将其添加到有效文件路径列表中
                    valid_file_paths.append(file_path)
                else:
                    # 如果文件不存在，将该记录的处理状态更新为 'except'
                    update_query = "UPDATE file_watcher SET process_status = 'except' WHERE filePath = %s"
                    cursor.execute(update_query, (file_path,))
                    connection.commit()
            for file_path in valid_file_paths:
                # 将有效文件路径列表中的文件的处理状态更新为 'processing'
                update_query = "UPDATE file_watcher SET process_status = 'processing' WHERE filePath = %s"
                cursor.execute(update_query, (file_path,))
                connection.commit()
            return valid_file_paths
        except mysql.connector.Error as e:
            # 如果执行 SQL 语句时出现错误，记录错误日志信息
            logging.error(f'Error while getting files: {e}')
            retries += 1
            if retries < GLOBAL_CONFIG['retry_count']:
                # 如果重试次数未达到上限，记录等待重试的日志信息，并等待指定时间
                logging.info(f"Retrying in {GLOBAL_CONFIG['retry_time']} seconds...")
                time.sleep(GLOBAL_CONFIG['retry_time'])
    return []


# 定义一个函数，用于将指定的文件插入到数据库中
def attach_file(task_id, file_path):
    if isinstance(file_path, str):
        # 如果 file_path 是字符串类型，将其转换为列表
        file_paths = [file_path]
    elif isinstance(file_path, list):
        # 如果 file_path 是列表类型，直接使用该列表
        file_paths = file_path
    else:
        # 如果 file_path 既不是字符串类型也不是列表类型，记录错误日志信息并返回
        logging.error(f"Invalid file_path type: {type(file_path).__name__}. Expected str or list.")
        return

    for single_file_path in file_paths:
        retries = 0
        while retries < GLOBAL_CONFIG['retry_count']:
            try:
                # 获取文件的大小
                file_size = os.path.getsize(single_file_path)
                if file_size == 0:
                    # 如果文件大小为 0，记录日志信息并跳出循环
                    logging.info(f'File {single_file_path} has size 0, ignoring.')
                    break
            except OSError as e:
                # 如果获取文件大小失败，记录错误日志信息
                logging.error(f'Error getting size of {single_file_path}: {e}')
                retries += 1
                if retries < GLOBAL_CONFIG['retry_count']:
                    # 如果重试次数未达到上限，记录等待重试的日志信息，并等待指定时间
                    logging.info(f"Retrying in {GLOBAL_CONFIG['retry_time']} seconds...")
                    time.sleep(GLOBAL_CONFIG['retry_time'])
                continue

            # 计算文件的 MD5 哈希值
            md5 = get_file_md5(single_file_path)
            if md5 is None:
                break
            try:
                # 创建数据库连接
                connection = create_db_connection()
                # 创建数据库游标
                cursor = connection.cursor()
                # 执行 SQL 查询，查找指定任务下，文件路径为指定路径的记录
                query = "SELECT id, md5 FROM file_watcher WHERE task_id = %s AND filePath = %s"
                cursor.execute(query, (task_id, single_file_path))
                result = cursor.fetchone()
                if result:
                    # 如果查询到结果，获取记录的 MD5 哈希值
                    existing_md5 = result[1]
                    if existing_md5 != md5:
                        # 如果记录的 MD5 哈希值与当前计算的 MD5 哈希值不同，更新记录的 MD5 哈希值和处理状态
                        current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                        update_query = "UPDATE file_watcher SET md5 = %s, process_status = 'pending', updated_at = %s WHERE id = %s"
                        cursor.execute(update_query, (md5, current_time, result[0]))
                        connection.commit()
                        # 记录日志信息
                        logging.info(f'Updated file {single_file_path} in database')
                else:
                    # 如果查询不到结果，插入一条新记录
                    current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    insert_query = "INSERT INTO file_watcher (task_id, filePath, process_status, md5, created_at, updated_at) VALUES (%s, %s, 'pending', %s, %s, %s)"
                    cursor.execute(insert_query, (task_id, single_file_path, md5, current_time, current_time))
                    connection.commit()
                    # 记录日志信息
                    logging.info(f'Added file {single_file_path} to database')
                break
            except mysql.connector.Error as e:
                # 如果执行 SQL 语句时出现错误，记录错误日志信息
                logging.error(f'Error while attaching file: {e}')
                retries += 1
                if retries < GLOBAL_CONFIG['retry_count']:
                    # 如果重试次数未达到上限，记录等待重试的日志信息，并等待指定时间
                    logging.info(f"Retrying in {GLOBAL_CONFIG['retry_time']} seconds...")
                    time.sleep(GLOBAL_CONFIG['retry_time'])


# 定义一个函数，用于设置指定文件列表的处理状态
def set_file_status(task_id, file_paths, status):
    retries = 0
    while retries < GLOBAL_CONFIG['retry_count']:
        try:
            # 创建数据库连接
            connection = create_db_connection()
            # 创建数据库游标
            cursor = connection.cursor()
            for file_path in file_paths:
                # 执行 SQL 更新语句，将指定任务下，文件路径为指定路径的记录的处理状态更新为指定状态
                update_query = "UPDATE file_watcher SET process_status = %s WHERE task_id = %s AND filePath = %s"
                cursor.execute(update_query, (status, task_id, file_path))
                connection.commit()
            # 记录日志信息
            logging.info(f'Set status of {len(file_paths)} files to {status}')
            break
        except mysql.connector.Error as e:
            # 如果执行 SQL 语句时出现错误，记录错误日志信息
            logging.error(f'Error while setting file status: {e}')
            retries += 1
            if retries < GLOBAL_CONFIG['retry_count']:
                # 如果重试次数未达到上限，记录等待重试的日志信息，并等待指定时间
                logging.info(f"Retrying in {GLOBAL_CONFIG['retry_time']} seconds...")
                time.sleep(GLOBAL_CONFIG['retry_time'])


# 定义一个函数，用于获取指定文件列表的处理状态
def get_file_status(task_id, file_paths):
    retries = 0
    while retries < GLOBAL_CONFIG['retry_count']:
        try:
            # 创建数据库连接
            connection = create_db_connection()
            # 创建数据库游标
            cursor = connection.cursor()
            statuses = {}
            for file_path in file_paths:
                # 执行 SQL 查询，查找指定任务下，文件路径为指定路径的记录的处理状态
                query = "SELECT process_status FROM file_watcher WHERE task_id = %s AND filePath = %s"
                cursor.execute(query, (task_id, file_path))
                result = cursor.fetchone()
                if result:
                    # 如果查询到结果，将文件路径和处理状态添加到状态字典中
                    statuses[file_path] = result[0]
                else:
                    # 如果查询不到结果，将文件路径和 None 添加到状态字典中
                    statuses[file_path] = None
            return statuses
        except mysql.connector.Error as e:
            # 如果执行 SQL 语句时出现错误，记录错误日志信息
            logging.error(f'Error while getting file status: {e}')
            retries += 1
            if retries < GLOBAL_CONFIG['retry_count']:
                # 如果重试次数未达到上限，记录等待重试的日志信息，并等待指定时间
                logging.info(f"Retrying in {GLOBAL_CONFIG['retry_time']} seconds...")
                time.sleep(GLOBAL_CONFIG['retry_time'])
    return {}


# 定义一个函数，用于更新文件的处理状态
def updated(task_id, completed_files, suspended_files):
    try:
        # 将完成的文件列表的处理状态更新为 'completed'
        set_file_status(task_id, completed_files, 'completed')
        # 将暂停的文件列表的处理状态更新为 'suspended'
        set_file_status(task_id, suspended_files, 'suspended')
        # 记录日志信息
        logging.info(f'Updated status of files for task {task_id}')
    except Exception as e:
        # 如果更新文件状态时出现错误，记录错误日志信息
        logging.error(f'Error while updating file status: {e}')


# 定义一个函数，用于解析命令行参数
def parse_arguments():
    # 创建一个参数解析器对象
    parser = argparse.ArgumentParser(description='File Watcher Program')
    # 添加一个必需的参数 'command'，可选值为 'start' 或 'stop'，用于启动或停止文件监控程序
    parser.add_argument('command', choices=['start', 'stop'], help='Start or stop the file watcher')
    # 添加一个可选参数 '--task_id'，类型为整数，用于指定监控任务的 ID
    parser.add_argument('--task_id', type=int, help='Task ID for monitoring')
    # 添加一个可选参数 '--folders'，可以接受多个值，用于指定要监控的文件夹列表
    parser.add_argument('--folders', nargs='+', help='List of folders to monitor')
    # 添加一个可选参数 '--filter_rules'，类型为 JSON 字符串，用于指定任务的过滤规则
    parser.add_argument('--filter_rules', type=json.loads, help='Filter rules for the task in JSON format')
    return parser.parse_args()


# 新增函数：检查并过滤无效的文件夹路径
def validate_folders(folder_list):
    valid_folders = []
    for folder in folder_list:
        if os.path.exists(folder) and os.path.isdir(folder):
            # 如果文件夹存在且是一个目录，将其添加到有效文件夹列表中
            valid_folders.append(folder)
        else:
            # 如果文件夹不存在或不是一个目录，记录错误日志信息
            print(f"移除无效文件夹路径: {folder}")
            logging.error(f"移除无效文件夹路径: {folder}")
    print(f"有效文件夹路径列表: {valid_folders}")
    logging.error(f"有效文件夹路径列表: {valid_folders}")
    return valid_folders


# 配置管理函数
def watchconfig(task_id=None, **kwargs):
    if task_id is None:
        if not kwargs:
            # 如果没有指定任务 ID 且没有提供关键字参数，返回全局配置
            return GLOBAL_CONFIG
        for key, value in kwargs.items():
            if key in GLOBAL_CONFIG:
                # 如果关键字参数的键存在于全局配置中，更新全局配置的值
                GLOBAL_CONFIG[key] = value
                # 记录日志信息
                logging.info(f"Updated global config: {key} = {value}")
            else:
                # 如果关键字参数的键不存在于全局配置中，记录警告日志信息
                logging.warning(f"Unknown global config key: {key}")
    else:
        if task_id not in GLOBAL_CONFIG['task_filters']:
            # 如果指定的任务 ID 不存在于任务过滤规则中，初始化该任务的过滤规则
            GLOBAL_CONFIG['task_filters'][task_id] = {
                'exclude_folders': [],
                'exclude_files': [],
                'exclude_extensions': [],
                'exclude_file_suffixes': [],
                'exclude_folder_suffixes': [],
                'exclude_file_prefixes': [],
                'exclude_folder_prefixes': [],
                'exclude_regex_folders': [],
                'exclude_regex_files': [],
                'include_files': [],
                'include_folders': [],
                'include_file_suffixes': [],
                'include_folder_suffixes': [],
                'include_file_prefixes': [],
                'include_folder_prefixes': [],
                'only_extensions': [],
                'only_files_regrex': [],
                'only_folders_regrex': [],
                'first_level_dir': False,
                'recheck_on_restart': False
            }
        if not kwargs:
            # 如果没有提供关键字参数，返回指定任务的过滤规则
            return GLOBAL_CONFIG['task_filters'][task_id]
        for key, value in kwargs.items():
            if key in GLOBAL_CONFIG['task_filters'][task_id]:
                # 如果关键字参数的键存在于指定任务的过滤规则中，更新该任务的过滤规则的值
                GLOBAL_CONFIG['task_filters'][task_id][key] = value
                # 记录日志信息
                logging.info(f"Updated filter rule for task {task_id}: {key} = {value}")
            else:
                # 如果关键字参数的键不存在于指定任务的过滤规则中，记录警告日志信息
                logging.warning(f"Unknown filter rule key for task {task_id}: {key}")
    return GLOBAL_CONFIG


# 新增函数：根据给定条件删除数据表中的记录
def delete_watch(task_id=None, file_paths=None, process_status=None):
    retries = 0
    while retries < GLOBAL_CONFIG['retry_count']:
        try:
            connection = create_db_connection()
            cursor = connection.cursor()
            conditions = []
            values = []

            if task_id is not None:
                conditions.append("task_id = %s")
                values.append(task_id)

            if file_paths is not None:
                if isinstance(file_paths, str):
                    file_paths = [file_paths]
                placeholders = ', '.join(['%s'] * len(file_paths))
                conditions.append(f"filePath IN ({placeholders})")
                values.extend(file_paths)

            if process_status is not None:
                conditions.append("process_status = %s")
                values.append(process_status)

            if not conditions:
                logging.warning("没有提供有效的删除条件，不执行删除操作。")
                return

            where_clause = " AND ".join(conditions)
            query = f"DELETE FROM file_watcher WHERE {where_clause}"
            cursor.execute(query, tuple(values))
            connection.commit()
            logging.info(f"成功删除 {cursor.rowcount} 条记录。")
            break
        except mysql.connector.Error as e:
            logging.error(f'Error while deleting records: {e}')
            retries += 1
            if retries < GLOBAL_CONFIG['retry_count']:
                logging.info(f"Retrying in {GLOBAL_CONFIG['retry_time']} seconds...")
                time.sleep(GLOBAL_CONFIG['retry_time'])

                
# 程序入口
if __name__ == '__main__':
    args = parse_arguments()
    if args.folders:
        FOLDER_LIST = args.folders
        FOLDER_LIST = validate_folders(FOLDER_LIST)
        if args.command == 'start':
            if args.task_id:
                if args.filter_rules:
                    watchconfig(args.task_id, **args.filter_rules)
                if not FOLDER_LIST:
                    logging.error('要监控的文件夹列表为空，无法启动任务')
                else:
                    watch_task(args.task_id, FOLDER_LIST)
            else:
                logging.error('启动任务需要指定任务 ID')
        elif args.command == 'stop':
            logging.info('正在停止文件监控程序')
    else:
        logging.info('监控列表为空')