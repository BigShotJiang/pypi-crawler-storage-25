from paddlex import create_model
from PIL import Image
from PIL.ExifTags import IFD, TAGS
import os,time,sys
from typing import Union, List
from beiker.files import filtered_files

def set_exif_orientation(img_path: str, orientation: int):
    try:
        with Image.open(img_path) as img:
            exif_dict = img.getexif()
            # 修复：无EXIF时创建新对象
            if not exif_dict:
                exif_dict = Image.Exif()

            ORIENTATION_TAG = 274
            if orientation == 0:
                if ORIENTATION_TAG in exif_dict:
                    del exif_dict[ORIENTATION_TAG]
            else:
                exif_dict[ORIENTATION_TAG] = orientation

            # 修复：强制格式保存
            img.save(img_path, exif=exif_dict, format=img.format)
    except Exception as e:
        pass

def get_image_orientation(img_path):
    try:
        img = Image.open(img_path)
        exif_data = img._getexif()
        if not exif_data:
            return 0
        for tag, value in exif_data.items():
            decoded = TAGS.get(tag, tag)
            if decoded == "Orientation":
                return value
        return 0
    except:
        return 0

def rotate_image(img: Image.Image, angle: int) -> Image.Image:
    return img.rotate(angle, expand=True)

def get_paddlex_angle(img_path: str, model):
    output = model.predict(img_path, batch_size=1)
    for res in output:
        data = res.json
        return data['res']['label_names'][0]


def correct_image_orientation(
    input_data: Union[str, List[str]],
    log_path: str = None 
):
    if log_path:
        log_dir = os.path.dirname(log_path)
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir, exist_ok=True)
    start_time = time.time()
    start_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(start_time))
    IMAGE_EXTENSIONS = ('.bmp', '.jpg', '.jpeg', '.png', '.tif', '.tiff')
    total_count = 0  # 处理文件总数
    correct_count = 0  # 实际更正（旋转）文件总数
    correct_file_list = []  # 更正文件路径列表
    batch_size = 100  # 每100条写入一次log，防内存爆
    file_list = [input_data] if isinstance(input_data, str) else input_data
    model = create_model("PP-LCNet_x1_0_doc_ori")

    for img_path in file_list:
        total_count += 1
        corrected = False
        # 1. 文件不存在 → 跳过
        if not os.path.exists(img_path):
            print(f"❌ 文件不存在：{img_path}")
            total_count -= 1
            continue
        
        # 2. 不是图片文件 → 跳过（新增）
        if not img_path.lower().endswith(IMAGE_EXTENSIONS):
            print(f"⏭️  非图片文件，自动跳过：{img_path}")
            total_count -= 1
            continue
        print(f"\n===== 开始处理：{img_path} =====")
        exif_val = get_image_orientation(img_path)
        if exif_val not in (0, 1):
            set_exif_orientation(img_path, 1)
            print(f"✅ 前置修正：EXIF方向 {exif_val} → 已强制设置为 1")
            
        ai_angle = get_paddlex_angle(img_path, model)
        print(f"📸 PaddleX检测方向：{ai_angle}")
        
        if ai_angle != "0":
            print("⚠️ 未完全转正，执行二次AI校正")
            with Image.open(img_path) as img:
                if ai_angle == "90":
                    img = rotate_image(img, 90)
                elif ai_angle == "180":
                    img = rotate_image(img, 180)
                elif ai_angle == "270":
                    img = rotate_image(img, 270)
                img.save(img_path)
            
            print("✅ AI校正完成，重置EXIF为正常")
            corrected = True

        print(f"===== 处理完成：{img_path} =====\n")

        if corrected:
            correct_count += 1
            correct_file_list.append(img_path)
        
        # 分批写入log，防止内存爆
        if log_path and len(correct_file_list) > 0 and len(correct_file_list) % batch_size == 0:
            with open(log_path, "a", encoding="utf-8") as f:
                for path in correct_file_list:
                    f.write(f"{path}\n")
            correct_file_list.clear()  # 清空已写入数据

    if log_path:
        end_time = time.time()
        end_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(end_time))
        total_use_time = f"{end_time - start_time:.2f} 秒"
        with open(log_path, "a", encoding="utf-8") as f:
            # 👇 新增：写入开始/结束时间
            f.write(f"\n========== 图片校正日志 ==========\n")
            f.write(f"开始时间：{start_str}\n")
            f.write(f"结束时间：{end_str}\n")
            f.write(f"总用时：{total_use_time}\n")
            
            # 下面是你原来的逻辑，完全不动
            if correct_file_list:
                for path in correct_file_list:
                    f.write(f"{path}\n")
            f.write(f"处理文件总数：{total_count}\n")
            f.write(f"更正文件总数：{correct_count}\n")
            f.write(f"==================================\n\n")