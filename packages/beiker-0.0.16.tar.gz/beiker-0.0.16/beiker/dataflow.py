import base64,requests,json,os,time,re
from typing import Union,List, Dict, Any, Optional
from openai import OpenAI
from PIL import Image

name_to_field={
    "姓名": "xm",
    "曾用名": "cym",
    "年度": "year",
    "入学年度": "enter_year",
    "出生年度": "birth_year",
    "学院或系别": "college",
    "专业": "zy",
    "生源地（省级行政区）": "syd",
    "学科、专业名称": "zy",
    "学习中心": "xxzx",
    "出生地": "csd",
    "层次": "cc",
    "证件号码或身份证号": "zjhm",
    "证件号码": "zjhm",
    "身份证号": "zjhm",
    "籍贯省份": "jg_province",
}
field_map = {
    "xm": "姓名",
    "year": "年度",
    "syd": "生源地（省级行政区）",
    "zy": "学科、专业名称",
    "xxzx": "学习中心",
    "csd": "出生地",
    "cc": "层次",
    "zjhm": "证件号码或身份证号"
}
reverse_field_map = {v: k for k, v in field_map.items()}
def translate_field(abbrev: str) -> str:
    """根据缩写获取中文字段名"""
    return field_map.get(abbrev, abbrev)

def translate_dict(data: dict) -> dict:
    """将字典的英文键替换为中文键"""
    return {field_map.get(k, k): v for k, v in data.items()}

def table_recognize(file_path: str, api_url: str) -> dict:
    """
    表格识别核心函数
    :param file_path: 待识别的图片文件路径
    :param api_url: 表格识别接口地址
    :return: 接口返回的识别结果（JSON字典格式）
    """
    # 1. 读取图片并转为base64编码
    with open(file_path, "rb") as file:
        file_bytes = file.read()
        file_data = base64.b64encode(file_bytes).decode("ascii")

    # 2. 构造请求参数
    payload = {
        "file": file_data,
        "fileType": 1,
        "useDocUnwarping": False
    }

    # 3. 发送POST请求
    response = requests.post(api_url, json=payload)

    # 4. 校验请求状态
    assert response.status_code == 200, f"接口请求失败，状态码：{response.status_code}"

    # 5. 获取结果（修复：兼容接口返回字符串/字典两种格式）
    result_data = response.json()["result"]
    # 如果返回的是字符串，转成字典
    if isinstance(result_data, str):
        result_data = json.loads(result_data)
    
    # 构建目录与文件路径
    dir_path = os.path.dirname(file_path)
    other_dir = os.path.join(dir_path, "other")
    os.makedirs(other_dir, exist_ok=True)

    # 构建新文件名（固定json后缀）
    file_name = os.path.basename(file_path)
    name, _ = os.path.splitext(file_name)
    new_file_name = f"{name}-paddle-tableocr.json"
    save_path = os.path.join(other_dir, new_file_name)

    # 写入JSON结果
    with open(save_path, "w", encoding="utf-8") as f:
        json.dump(result_data, f, ensure_ascii=False, indent=2)
        
    return result_data

def count_invalid_chars(s):
    t = str(s).strip()
    return t.count('O') + t.count('0') + t.count('。')

def compress_ocr_data(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    从输入JSON文件中提取并合并所有数据：
    1. 合并所有 rec_boxes
    2. 合并所有 rec_texts
    3. 合并所有指定label的layout_boxes
    生成扁平化的新JSON文件
    """
    # 定义需要筛选的布局标签
    TARGET_LABELS = {"text", "paragraph_title", "table_title", "number","table"}
    
    try:
        # 1. 初始化【合并后】的结果（直接扁平化，无嵌套）
        result = {
            "rec_boxes": [],
            "rec_texts": [],
            "filtered_layout_boxes": [],
            "dataInfo": data.get("dataInfo", {})
        }

        # 2. 处理所有tableRecResults元素
        table_rec_results = data.get("tableRecResults", [])
        print(f"📊 发现 {len(table_rec_results)} 个tableRecResults元素，开始合并数据...")

        for idx, table_item in enumerate(table_rec_results, 1):
            try:
                # 提取嵌套数据
                pruned_result = table_item.get("prunedResult", {})
                overall_ocr_res = pruned_result.get("overall_ocr_res", {})
                
                # 提取OCR数据
                rec_boxes = overall_ocr_res.get("rec_boxes", [])
                rec_texts = overall_ocr_res.get("rec_texts", [])

                # 提取并筛选布局框
                layout_det_res = pruned_result.get("layout_det_res", {})
                layout_boxes = layout_det_res.get("boxes", [])
                filtered_layout_boxes = [box for box in layout_boxes if box.get("label") in TARGET_LABELS]

                # 核心：合并所有数据（追加到总列表）
                result["rec_boxes"].extend(rec_boxes)
                result["rec_texts"].extend(rec_texts)
                result["filtered_layout_boxes"].extend(filtered_layout_boxes)

                print(f"📝 已合并第{idx}个元素的数据")

            except Exception as e:
                print(f"❌ 处理第{idx}个元素时出错: {str(e)}")
                continue

        print(f"   - 筛选布局框总数: {len(result['filtered_layout_boxes'])}")

        # 可配置参数
        edge_px = 45
        max_invalid = 3
        
        # 从输入data自动取图片宽度
        data_info = data.get("dataInfo", {})
        img_w = data_info.get("width", 1745)  # 取不到默认1745
        
        left_region = (0, edge_px)
        right_region = (img_w - edge_px, img_w)
        
        # 统计边缘内无效字符数量
        invalid_total = 0
        for text, box in zip(result["rec_texts"], result["rec_boxes"]):
            if len(box) < 4:
                continue
            xmin, xmax = box[0], box[2]
        
            in_left = xmin < left_region[1] and xmax > left_region[0]
            in_right = xmin < right_region[1] and xmax > right_region[0]
        
            if in_left or in_right:
                invalid_total += count_invalid_chars(text)
        
        # 超过阈值 → 删除所有边缘内容（复用现有函数）
        if invalid_total > max_invalid:
            keep_x = [(edge_px, img_w - edge_px)]
            clean_texts, clean_boxes = filter_by_x_axis(
                rec_texts=result["rec_texts"],
                rec_boxes=result["rec_boxes"],
                x_ranges=keep_x,
                overlap_mode=False,    # 必须完全在中间才保留
                overlap_threshold=0    # 碰到边缘就删除
            )
            result["rec_texts"] = clean_texts
            result["rec_boxes"] = clean_boxes
            
        # 返回处理好的JSON数据（原逻辑不变）
        return result

    except Exception as e:
        print(f"❌ 程序执行出错: {str(e)}")
        return {}

def extract_json(text: str) -> str:
    """
    从大模型输出文本中提取 JSON 字符串。
    支持 ```json 代码块、``` 代码块、以及裸 JSON。
    """
    # 1. 尝试提取 ```json ... ``` 或 ``` ... ``` 代码块
    match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', text, re.DOTALL)
    if match:
        return match.group(1).strip()
    
    # 2. 尝试提取最外层的大括号内容（贪婪匹配，取最后一个 }）
    match = re.search(r'(\{.*\})', text, re.DOTALL)
    if match:
        return match.group(1).strip()
    
    raise ValueError("未从文本中提取到有效的 JSON")


def parse_llm_output(text: str) -> dict:
    """
    将大模型输出的文本解析为 {"英文键": "值/列表值"} 格式的字典。
    自动适配字符串、数字、列表格式的值，中文键自动转英文缩写
    【修复】安全转换数值：数字自动转int/float，文本保持原样
    """
    # 安全转换：能转数字就转，转失败则返回原字符串（修复核心）
    def safe_convert_num(s):
        try:
            return int(s)
        except (ValueError, TypeError):
            try:
                return float(s)
            except (ValueError, TypeError):
                return s  # 转换失败，返回原始字符串（如北京市）
    
    json_str = extract_json(text)
    data = json.loads(json_str)
    
    result = {}
    for chinese_key, value in data.items():
        eng_key = reverse_field_map.get(chinese_key, name_to_field.get(chinese_key, chinese_key))

        if isinstance(value, list):
            result[eng_key] = [safe_convert_num(item) for item in value]
        else:
            result[eng_key] = safe_convert_num(value)
    
    return result

def extract_info_from_ocr(
    user_text: str,
    api_url: str,
    api_key: str,
    model_name: str
) -> str:
    """
    通用大模型请求函数
    外部构造user_text，函数仅处理请求、计时、返回结果
    不修改任何名称、不新增逻辑、不改变输出
    """
    # 初始化客户端（原代码逻辑）
    client = OpenAI(
        api_key=api_key,
        base_url=api_url,
        timeout=900
    )

    # 请求 + 计时（原代码不动）
    print("\n📷 正在请求模型分析...")
    start_time = time.time()

    completion = client.chat.completions.create(
        model=model_name,
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": user_text},
                ]
            }
        ]
    )

    end_time = time.time()
    elapsed_time = end_time - start_time

    # 提取结果（原代码）
    llm_result =parse_llm_output(completion.choices[0].message.content.strip()) 
    # 日志输出（原格式完全保留）
    print("\n" + "="*60)
    print("大模型返回结果：")
    print(llm_result)
    print("大模型请求执行时间：{:.2f} 秒".format(elapsed_time))
    print("="*60)

    return llm_result

def get_text_above_top_table(ocr_json: dict) -> str:
    """
    提取最顶部表格的最上方所有文本，用空格拼接返回
    严格规则：仅匹配 label="table" 的表格框
    """
    # 1. 提取OCR核心数据
    rec_boxes = ocr_json.get("rec_boxes", [])
    rec_texts = ocr_json.get("rec_texts", [])
    layout_boxes = ocr_json.get("filtered_layout_boxes", [])

    # 2. 严格筛选：仅保留 label="table" 的表格（无任何额外兼容）
    table_boxes = [
        box for box in layout_boxes
        if box.get("label") == "table"
    ]

    # 调试：打印找到的表格数量（核心排查点1）
    print(f"[调试] 找到 label=table 的表格数量：{len(table_boxes)}")
    if not table_boxes:
        # ===================== 【最小改动】无表格时返回前50个文本 =====================
        above_texts = [t.strip() for t in rec_texts[:50] if t.strip()]
        return " ".join(above_texts)

    # 3. 找到最顶部的表格（Y坐标最小）
    top_table = min(table_boxes, key=lambda x: x["coordinate"][1])
    table_top_y = top_table["coordinate"][1]
    print(f"[调试] 最顶部表格的上沿纵坐标：{table_top_y}")

    # 4. 筛选表格上方的文本
    above_texts = []
    for idx, (box, text) in enumerate(zip(rec_boxes, rec_texts)):
        text_top_y = box[1]  # 文本框上沿Y坐标
        # 调试：打印每个文本的坐标（核心排查点2）
        # print(f"[调试] 文本{idx}：{text} | 上沿Y：{text_top_y}")
        
        # 严格判断：文本在表格上方
        if text_top_y < table_top_y:
            clean_text = text.strip()
            if clean_text:
                above_texts.append(clean_text)

    print(f"[调试] 筛选出的上方文本：{above_texts}")
    return " ".join(above_texts)

def filter_by_x_axis(rec_texts, rec_boxes, x_ranges, overlap_mode=True, overlap_threshold=0.01):
    """
    根据横坐标范围过滤文本和对应框
    :param rec_texts: OCR文本列表
    :param rec_boxes: 对应坐标框列表 [x_min, y_min, x_max, y_max]
    :param x_ranges: 横坐标范围列表
    :param overlap_mode: 重合过滤模式，True=按比例重合保留，False=必须完全包含才保留
    :param overlap_threshold: 重合比例阈值，大于该比例才保留
    :return: 过滤后的 texts, boxes
    """
    filtered_texts = []
    filtered_boxes = []
    
    # 遍历 文本+坐标 对（一一对应，同步保留/删除）
    for text, box in zip(rec_texts, rec_boxes):
        if len(box) < 4:
            continue  # 跳过无效框
        
        x_min, _, x_max, _ = int(box[0]), int(box[1]), int(box[2]), int(box[3])
        keep = False
        
        # 判断是否符合横坐标规则
        for (start_x, end_x) in x_ranges:
            start_x, end_x = int(start_x), int(end_x)
            if overlap_mode:
                bbox_width = x_max - x_min
                overlap_start = max(x_min, start_x)
                overlap_end = min(x_max, end_x)
                
                if overlap_start >= overlap_end:
                    continue
                # 核心：重合长度 / 自身宽度 = 落在目标范围的比例
                overlap_ratio = (overlap_end - overlap_start) / bbox_width
                
                # 大于80% → 保留
                if overlap_ratio > overlap_threshold:
                    keep = True
                    break
            else:
                # 原有逻辑：必须完全落入范围才保留
                if start_x <= x_min and x_max <= end_x:
                    keep = True
                    break
        
        # 符合条件：文本和框 同步保留；不符合：同步删除
        if keep:
            filtered_texts.append(text)
            filtered_boxes.append(box)
    
    return filtered_texts, filtered_boxes

def filter_by_table_y_axis(rec_texts, rec_boxes, filtered_layout_boxes, overlap_threshold=0.8):
    """
    根据表格纵坐标范围过滤：文本框80%在table外则删除
    :param rec_texts: 文本列表
    :param rec_boxes: 坐标框列表
    :param filtered_layout_boxes: 布局框列表
    :param overlap_threshold: 重合比例阈值
    :return: 过滤后的 texts, boxes
    """
    filtered_texts = []
    filtered_boxes = []
    
    # 提取所有 label=table 的布局框纵坐标范围 [y_min, y_max]
    table_y_ranges = []
    for layout in filtered_layout_boxes:
        if layout.get("label") == "table":
            coord = layout.get("coordinate", [])
            if len(coord) >= 4:
                y_min = coord[1]
                y_max = coord[3]
                table_y_ranges.append((y_min, y_max))
    
    # 无表格时，所有文本都在表格外，直接返回空列表
    if not table_y_ranges:
        return rec_texts, rec_boxes
    
    # 遍历过滤每个文本框
    for text, box in zip(rec_texts, rec_boxes):
        if len(box) < 4:
            continue
        
        text_y_min = box[1]
        text_y_max = box[3]
        text_height = text_y_max - text_y_min
        total_overlap = 0

        # 计算与所有表格的纵坐标重合总长度
        for (t_y_min, t_y_max) in table_y_ranges:
            overlap_start = max(text_y_min, t_y_min)
            overlap_end = min(text_y_max, t_y_max)
            if overlap_start < overlap_end:
                total_overlap += overlap_end - overlap_start

        # 计算重合比例，大于80%保留，否则删除
        overlap_ratio = total_overlap / text_height
        if overlap_ratio > overlap_threshold:
            filtered_texts.append(text)
            filtered_boxes.append(box)

    return filtered_texts, filtered_boxes

def process_filter_json(input_json, x_ranges, overlap_mode=True, x_overlap_threshold=0.01,y_overlap_threshold=0.8):
    """
    对精简后的JSON进行横坐标过滤 + 表格外文本过滤
    """
    rec_texts = input_json.get("rec_texts", [])
    rec_boxes = input_json.get("rec_boxes", [])
    filtered_layout_boxes = input_json.get("filtered_layout_boxes", [])
    
    # ===================== 核心修改：分别过滤xm、zjhm =====================
    result = {}
    # 遍历x_range字典（键：xm/zjhm，值：横坐标范围）
    for field_name, x_range_list in x_ranges.items():
        # 原有双重过滤逻辑（完全不变）
        new_texts, new_boxes = filter_by_x_axis(rec_texts, rec_boxes, [x_range_list], overlap_mode, x_overlap_threshold)
        new_texts, new_boxes = filter_by_table_y_axis(new_texts, new_boxes, filtered_layout_boxes, y_overlap_threshold)
        
        # 原有裁剪第一个元素逻辑（完全不变）
        result[field_name] = {
            "rec_texts": new_texts[1:],
            "rec_boxes": new_boxes[1:]
        }
    
    # 保留顶层filtered_layout_boxes（完全不变）
    result["filtered_layout_boxes"] = filtered_layout_boxes
    
    return result

def gaokao_convert_ocr_json(original_json_data: dict, image_file_path: str, extra_dict: dict = None) -> dict:
    """
    将原始OCR JSON转换为指定格式的标注JSON
    :param original_json_data: 原始JSON字典数据
    :param image_file_path: 本地图片文件路径（绝对/相对路径均可）
    :param extra_dict: 额外标注字典，默认为None，传入任意键值对则自动生成标注框
    :return: 转换后的JSON字典
    """
    # 1. 提取图片纯文件名（imagePath 仅保存文件名，符合标注规范）
    image_name = os.path.basename(image_file_path)
    
    # 读取图片真实宽高像素
    try:
        with Image.open(image_file_path) as img:
            image_width, image_height = img.size
    except Exception as e:
        raise RuntimeError(f"读取图片失败，请检查路径：{str(e)}")

    # 3. 生成 shapes 数组（核心修改：动态遍历一级标签，排除filtered_layout_boxes）
    shapes_list = []
    # 遍历所有一级字段，跳过filtered_layout_boxes
    for label_name, field_data in original_json_data.items():
        if label_name == "filtered_layout_boxes":
            continue
        
        # 提取当前标签的文本和坐标
        rec_boxes = field_data.get("rec_boxes", [])
        rec_texts = field_data.get("rec_texts", [])

        # 校验坐标和文本数量一致
        if len(rec_boxes) != len(rec_texts):
            raise ValueError(f"{label_name} 的 rec_boxes({len(rec_boxes)})和rec_texts({len(rec_texts)})数量不匹配")

        # 遍历生成标注框，label动态使用一级键名
        for box, text in zip(rec_boxes, rec_texts):
            x1, y1, x2, y2 = box
            # 矩形四点坐标（标准标注格式）
            points = [
                [x1, y1],
                [x2, y1],
                [x2, y2],
                [x1, y2]
            ]
            # 固定字段严格按照要求填写，label动态赋值
            shape_item = {
                "label": label_name,
                "score": None,
                "points": points,
                "group_id": None,
                "description": text,
                "difficult": False,
                "shape_type": "rectangle",
                "flags": {},
                "attributes": {},
                "kie_linking": []
            }
            shapes_list.append(shape_item)

    # 处理额外传入的任意键值对字典
    if extra_dict is not None and isinstance(extra_dict, dict):
        # 固定配置
        start_x, start_y = 100, 50
        box_width, box_height = 100, 40
        spacing = 15
        # 遍历生成标注框
        for idx, (label, value) in enumerate(extra_dict.items()):
            current_x = start_x + idx * (box_width + spacing)
            points = [
                [current_x, start_y],
                [current_x + box_width, start_y],
                [current_x + box_width, start_y + box_height],
                [current_x, start_y + box_height]
            ]
            shape_item = {
                "label": label,
                "score": None,
                "points": points,
                "group_id": None,
                "description": value,
                "difficult": False,
                "shape_type": "rectangle",
                "flags": {},
                "attributes": {},
                "kie_linking": []
            }
            shapes_list.append(shape_item)

    # 4. 组装最终JSON
    converted_result = {
        "version": "2.5.3",
        "flags": {},
        "shapes": shapes_list,
        "imagePath": image_name,
        "imageData": None,
        "imageHeight": image_height,
        "imageWidth": image_width
    }

    return converted_result

def gaokao_process_files(
    input_paths: Union[str, list],          # 输入：文件路径字符串 / 路径列表
    ocr_api_url: str,                      # 敏感参数：无默认值
    chat_api_url: str,                     # 敏感参数：无默认值
    chat_api_key: str,                     # 敏感参数：无默认值
    chat_model_name: str,                  # 敏感参数：无默认值
    var_target_fields: list = ["姓名"],    # 可变字段：默认值
    fix_target_fields: list = ["年度", "生源地(省级行政区)"],  # 固定字段：默认值
    log_path: str = "./output_process.log",        # 日志文件路径：默认值
    overwrite_existing: bool = False
):
    # 允许处理的文件扩展名（小写）
    ALLOWED_EXTENSIONS = {"jpg", "jpeg", "png", "tif", "tiff", "pdf", "bmp"}

    # ========== 初始化统计与日志变量 ==========
    start_total = time.time()
    start_datetime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(start_total))
    total_count = 0    # 总处理量
    success_count = 0  # 成功数
    fail_count = 0     # 失败数
    error_logs = []    # 错误日志列表

    # ========== 统一输入格式：字符串转列表 ==========
    if isinstance(input_paths, str):
        file_list = [input_paths]
    else:
        file_list = input_paths
    total_count = len(file_list)
    print(f"===== 开始处理 | 总文件数：{total_count}")

    # 自动创建输出目录（原有逻辑保留）
    # os.makedirs(output_dir, exist_ok=True)

    # ========== 循环处理所有文件 ==========
    for INPUT_IMAGE in file_list:  # 保留原有核心变量名
        try:
            # ===================== 文件合法性校验（新增需求） =====================
            # 1. 检查文件是否存在
            if not os.path.isfile(INPUT_IMAGE):
                current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                err = f"[{current_time}] 文件不存在：{INPUT_IMAGE}"
                error_logs.append(err)
                fail_count += 1
                continue

            # 2. 检查扩展名（小写化后校验）
            file_ext = os.path.splitext(INPUT_IMAGE)[1][1:].lower()
            if file_ext not in ALLOWED_EXTENSIONS:
                current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                err = f"[{current_time}] 不支持的文件格式：{INPUT_IMAGE} | 允许格式：{ALLOWED_EXTENSIONS}"
                error_logs.append(err)
                fail_count += 1
                continue

            # 提前生成目标JSON文件路径
            image_dir = os.path.dirname(INPUT_IMAGE)
            image_name_no_ext = os.path.splitext(os.path.basename(INPUT_IMAGE))[0]
            output_json_path = os.path.join(image_dir, f"{image_name_no_ext}.json")

            # 检查JSON文件是否存在，按参数决定跳过/覆盖
            if os.path.exists(output_json_path):
                # 参数为False：直接跳过当前文件
                if not overwrite_existing:
                    if not overwrite_existing:
                        try:
                            with open(output_json_path, 'r', encoding='utf-8') as f:
                                existing_json = json.load(f)

                            # 从 shapes 里提取所有 label
                            shapes = existing_json.get("shapes", [])
                            labels = [s.get("label", "") for s in shapes]

                            # 检查条件：必须同时存在 xm、year、syd
                            has_xm = "xm" in labels
                            has_year = "year" in labels
                            has_syd = "syd" in labels

                            if has_xm and has_year and has_syd:
                                print(f"⏭️ JSON数据完整（xm/year/syd都存在），跳过处理：{INPUT_IMAGE}")
                                continue
                            else:
                                print(f"🔄 JSON数据不完整，重新处理：{INPUT_IMAGE}")
                        except Exception as e:
                            print(f"🔄 JSON读取失败/格式错误，重新处理：{INPUT_IMAGE}")
                # 参数为True：提示覆盖，继续执行原有处理逻辑
                print(f"⚠️ 已存在JSON文件，将覆盖写入：{output_json_path}")
            
            # ===================== 原有业务逻辑（100%保留变量/函数/功能） =====================
            print(f"\n===== 正在处理文件：{INPUT_IMAGE}")
            # 表格识别
            recognize_result = table_recognize(INPUT_IMAGE, ocr_api_url)
            print("===== 表格识别完成")

            # 过滤不必要的字段
            extracted_field_json = compress_ocr_data(recognize_result)
            print("===== 提取成功 OCR数据 extracted_field_json =====")

            # 找指定字段的横坐标范围
            VAR_TARGET_FIELDS = var_target_fields
            VAR_field_str = "、".join(VAR_TARGET_FIELDS)
            VAR_ocr_data = extracted_field_json
            VAR_ocr_str = json.dumps(VAR_ocr_data, ensure_ascii=False)

            VAR_user_text = f"""
**任务要求**严格遵守以下规则，从 表格图片OCR 结果中，精准分析提取【{VAR_field_str}】列的横坐标范围 [x_min, x_max] ：
**背景**
1. 文本rec_texts和定位框rec_boxes是一一对应的； 
2. 先找目标列名或目标列性质的文本，再根据其定位框生成横坐标范围。
**不要过度思考，从1-3依次查找横坐标范围，只要其中一种方法找到结果就立即检验是否符合检验条件，符合就输出**
1. 找到目标列的表头定位框，立即生成 [x_min, x_max]，例如查找姓名列，那么rec_texts中带有“姓名”二字的元素对应的定位框就符合此规则；
2. 检查含有目标列性质的文本。例如查找姓名列，那么找到“张三”name的定位框，就符合此规则；
3. 如果目标列和左右列文本发生粘连，找到发生粘连的文本，将其定位框的横坐标范围作为结果，例如查找姓名列，step1和step2都找不到，那么就找包含“李四112301198107010211”的定位框;
**结果必须符合以下检验条件** 
1. 以上步骤找到结果的优先级 1> 2> 3（例如查找姓名列，“姓名”就比“李梓熙”更符合要求，“李梓熙”就比“李梓熙1125223324”更符合要求）；
2. [x_min, x_max]必须是从单个文本框生成的，不是多个文本框复合的结果；
3. 找到的文本框对应的文本包含列名或其性质的文本（例如查找姓名列，那么“姓名”或“3123012810张三”就符合要求，但是“45663525”这种纯数字就不符合要求）；
4. 排除干扰信息，剔除坐标异常（明显偏离）或内容明显不是目标列的结果（例如查找姓名列，找到的文本框里的文本如果是单个文字、语文、考生号、单纯数字等，就不符合要求，必须重新查找）。
**输出格式** 
{{"姓名": [x_min, x_max]}}，不要有任何额外文字。
OCR 结果：
{VAR_ocr_str}
"""
            x_range = extract_info_from_ocr(
                user_text=VAR_user_text,
                api_url=chat_api_url,
                api_key=chat_api_key,
                model_name=chat_model_name
            )
            print("===== 提取的横坐标范围 x_range =====")
            print(x_range)

            filtered_x_data = process_filter_json(extracted_field_json, x_range)

            # 获取年度和生源地
            FIX_TARGET_FIELDS = fix_target_fields
            FIX_field_str = "、".join(FIX_TARGET_FIELDS)
            FIX_ocr_str = get_text_above_top_table(extracted_field_json)
            print("===== 表格上方文本 FIX_ocr_str =====")
            print(FIX_ocr_str)

            FIX__user_text = f"""
依据表格的表头文字，分析并提取【{FIX_field_str}】，严格按下面示例输出全部要求信息：
【输出示例】
{{
    "year": 2003,
    "syd": "内蒙古自治区"
}}
表格OCR结果：
{FIX_ocr_str}
"""
            year_province_dict = extract_info_from_ocr(
                user_text=FIX__user_text,
                api_url=chat_api_url,
                api_key=chat_api_key,
                model_name=chat_model_name
            )
            print("===== 提取的年度+生源地 year_province_dict =====")
            print(year_province_dict)

            # 转化成x-anylabeling数据
            converted_data = gaokao_convert_ocr_json(filtered_x_data, INPUT_IMAGE, year_province_dict)

            print("===== 输出文件路径 output_json_path =====")
            print(output_json_path)

            # 保存结果文件
            with open(output_json_path, "w", encoding="utf-8") as f:
                json.dump(converted_data, f, ensure_ascii=False, indent=2)
            print(f"✅ 处理完成：{INPUT_IMAGE} | 已保存至 {output_json_path}")

            # 成功计数
            success_count += 1

        # 捕获所有异常，记录后跳过当前文件
        except Exception as e:
            current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            err = f"[{current_time}] 处理失败：{INPUT_IMAGE} | 错误信息：{str(e)}"
            error_logs.append(err)
            fail_count += 1
            print(f"❌ 处理失败：{INPUT_IMAGE}，已记录日志")
            continue

    # ========== 处理结束：统计并写入日志（新增需求） ==========
    end_total = time.time()
    end_datetime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(end_total))
    total_use_time = round(end_total - start_total, 2)

    # 组装日志内容
    log_content = [
        "=" * 80,
        "--- 高考录取名册处理 ---",
        f"处理开始时间：{start_datetime}",
        f"处理结束时间：{end_datetime}",
        f"总用时：{total_use_time} 秒",
        f"总处理文件数：{total_count}",
        f"成功处理数：{success_count}",
        f"失败处理数：{fail_count}",
        "--- 错误详情 ---",
        *(error_logs if error_logs else ["无错误"]),
        "=" * 80 + "\n"
    ]

    # 写入日志文件（追加模式，保留历史记录）
    with open(log_path, "a", encoding="utf-8") as f:
        f.write("\n".join(log_content))

    # 打印最终统计
    print("\n" + "="*60)
    print(f"✅ 全部处理完成 | 总耗时：{total_use_time:.2f} 秒")
    print(f"总文件：{total_count} | 成功：{success_count} | 失败：{fail_count}")
    print(f"📝 日志已保存：{log_path}")
    print("="*60)