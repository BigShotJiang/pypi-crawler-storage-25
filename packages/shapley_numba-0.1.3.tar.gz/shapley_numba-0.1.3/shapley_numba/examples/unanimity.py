"""Unanimity game example."""

import numba
import numpy as np

from shapley_numba import numba_game
from shapley_numba.typing import CoalitionType


@numba_game(gamespec=[('veto_set', numba.int32[:]), ('veto_votes', numba.int32)])
class UnanimityGame:
    """Unanimity game class.

    Unanimity game is the simplest game where if coalition contains a veto set
    it wins and if the coalition does not contain the whole veto set it loses.
    """

    def __init__(self, veto_set: CoalitionType):
        """Initialize unanimity game."""
        self.veto_set = veto_set
        self.veto_votes = np.int32(np.sum(veto_set))

    def value(self, subset: CoalitionType) -> np.float64:
        """Return the value of coalition."""
        if sum(subset * self.veto_set) >= self.veto_votes:
            return np.float64(1.0)
        return np.float64(0.0)
