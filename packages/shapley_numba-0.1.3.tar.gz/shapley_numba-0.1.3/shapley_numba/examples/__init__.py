"""Examples for cooperative games."""

import shapley_numba.examples.finance as finance
from shapley_numba.examples.unanimity import UnanimityGame

from .games import AirPortGame, CoalitionGame, GloveGame, WikipediaExample

__all__ = [
    'WikipediaExample',
    'GloveGame',
    'CoalitionGame',
    'finance',
    'AirPortGame',
    'UnanimityGame',
]
