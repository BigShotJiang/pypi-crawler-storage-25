"""A script that demonstrates the exponential complexity of Shapley algorithm.

Since glove game is one of the minimal games that can be run,
It also can serve as a lower bound for timing of computation
of shapley for other algorithms
"""

import time
from types import ModuleType

import numpy as np
from scipy.optimize import curve_fit

from shapley_numba.examples import GloveGame
from shapley_numba.shapley import shapley

plt = ModuleType | None
try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None


def shapley_glove(num_players: int) -> np.ndarray:
    """Compute shapley values of glove game with two left gloves."""
    glove_game = GloveGame(2)
    return shapley(glove_game, num_players)


def time_function(num_players: int, warmup: bool = True) -> float:
    """Time the shapley_glove function for a given number of players."""
    # Warmup run to compile numba functions
    if warmup:
        shapley_glove(num_players)

    # Actual timing
    start = time.perf_counter()
    shapley_glove(num_players)
    end = time.perf_counter()

    return end - start


def exponential_model(series: np.ndarray, exponent: float) -> np.ndarray:
    """Create an exponential model.

    Model: time = a * 2^x.
    """
    return exponent * (2**series)


def run_timing_experiments(max_players: int = 30):
    """Run timing experiments for different numbers of players."""
    print('Running timing experiments...')
    print(f'{"Players":<10} {"Time (s)":<15} {"Time (ms)":<15}')
    print('-' * 40)

    player_counts = []
    times = []

    # Start with smaller values and increase
    for num_players in range(1, max_players + 1):
        try:
            elapsed = time_function(num_players, warmup=(num_players == 1))
            player_counts.append(num_players)
            times.append(elapsed)

            print(f'{num_players:<10} {elapsed:<15.6f} {elapsed * 1000:<15.3f}')

            # Stop if it's taking too long (> 60 seconds)
            if elapsed > 60:
                print(f'\nStopping at {num_players} players (time > 60s)')
                break

        except Exception as e:
            print(f'Error at {num_players} players: {e}')
            break

    return np.array(player_counts), np.array(times)


def fit_and_predict(player_counts, times, predict_up_to=50) -> float:
    """Fit exponential model and predict for larger values."""
    print('\n' + '=' * 60)
    print('Fitting exponential model: time = a * 2^num_players')
    print('=' * 60)

    # Fit the model
    params, _ = curve_fit(exponential_model, player_counts, times, p0=[1e-9])
    a = params[0]

    print(f'\nFitted constant a = {a:.3e}')
    print(f'Model: time = {a:.3e} * 2^num_players\n')

    # Print predictions
    print(f'{"Players":<10} {"Predicted Time":<20} {"Human Readable":<20}')
    print('-' * 60)

    for n in range(1, predict_up_to + 1):
        pred_time = exponential_model(n, a)

        # Convert to human-readable format
        if pred_time < 1e-6:
            readable = f'{pred_time * 1e9:.2f} ns'
        elif pred_time < 1e-3:
            readable = f'{pred_time * 1e6:.2f} μs'
        elif pred_time < 1:
            readable = f'{pred_time * 1e3:.2f} ms'
        elif pred_time < 60:
            readable = f'{pred_time:.2f} s'
        elif pred_time < 3600:
            readable = f'{pred_time / 60:.2f} min'
        elif pred_time < 86400:
            readable = f'{pred_time / 3600:.2f} hours'
        elif pred_time < 31536000:
            readable = f'{pred_time / 86400:.2f} days'
        else:
            readable = f'{pred_time / 31536000:.2f} years'

        print(f'{n:<10} {pred_time:<20.6e} {readable:<20}')

    return a


def plot_results(player_counts, times, a, predict_up_to=40) -> None:
    """Plot measured times and predictions."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

    # Plot 1: Measured data with fit
    ax1.scatter(player_counts, times, label='Measured', s=50, alpha=0.7)

    # Plot fitted curve
    x_fit = np.linspace(player_counts[0], player_counts[-1], 100)
    y_fit = exponential_model(x_fit, a)
    ax1.plot(x_fit, y_fit, 'r-', label=f'Fit: {a:.3e} * 2^n', linewidth=2)

    ax1.set_xlabel('Number of Players')
    ax1.set_ylabel('Time (seconds)')
    ax1.set_title('Measured Timing Data with Exponential Fit')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    ax1.set_yscale('log')

    # Plot 2: Predictions
    x_pred = np.arange(1, predict_up_to + 1)
    y_pred = exponential_model(x_pred, a)

    ax2.semilogy(x_pred, y_pred, 'b-', linewidth=2)
    ax2.scatter(
        player_counts, times, c='red', s=50, alpha=0.7, label='Measured', zorder=5
    )
    ax2.axvline(
        x=player_counts[-1],
        color='gray',
        linestyle='--',
        alpha=0.5,
        label=f'Max measured (n={player_counts[-1]})',
    )

    ax2.set_xlabel('Number of Players')
    ax2.set_ylabel('Time (seconds, log scale)')
    ax2.set_title(f'Predictions up to {predict_up_to} Players')
    ax2.legend()
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig('timing_results.png', dpi=150, bbox_inches='tight')
    print("\nPlot saved as 'timing_results.png'")
    plt.show()


if __name__ == '__main__':
    # Run timing experiments
    player_counts, times = run_timing_experiments(max_players=30)

    # Fit model and predict
    exponent = fit_and_predict(player_counts, times, predict_up_to=50)

    # Plot results
    if plt is not None:
        plot_results(player_counts, times, exponent, predict_up_to=40)
