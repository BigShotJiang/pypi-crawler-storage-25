"""Compare antithetic sampling using the Airport Game."""

import time

import numpy as np
from numpy.typing import NDArray

from shapley_numba.examples import AirPortGame
from shapley_numba.shapley import shapley, shapley_perm_mc


def exact_airport_shapley(
    length_requirements: NDArray[np.float64],
) -> NDArray[np.float64]:
    """Compute exact Shapley values for the Airport Game.

    The airport game has a closed-form solution:
    - Sort players by length requirements in ascending order
    - For each player, accumulate the marginal cost segments
    - Each segment (l_i - l_{i-1}) is divided by the number of remaining players
    - This represents the cost each player pays for their runway increment

    This formula is derived from the fact that the marginal contribution
    of player i is the increase in runway length divided by the number
    of players who benefit from that increase.
    """
    order = np.argsort(length_requirements)  # Ascending order
    num_players = len(length_requirements)
    result = np.zeros_like(length_requirements)
    prev_val = 0.0
    cummul = 0.0

    for num_player, index in enumerate(order):
        val = length_requirements[index]
        diff = val - prev_val
        cummul += diff / (num_players - num_player)
        result[index] = cummul
        prev_val = val

    return result


def generate_random_airport_game(
    num_players: int,
    min_length: float = 100.0,
    max_length: float = 10000.0,
    seed: int | None = None,
) -> NDArray[np.float64]:
    """Generate random runway length requirements.

    Parameters
    ----------
    num_players : int
        Number of players (aircraft types)
    min_length : float
        Minimum runway length
    max_length : float
        Maximum runway length
    seed : int, optional
        Random seed for reproducibility

    Returns
    -------
    NDArray[np.float64]
        Array of runway length requirements

    """
    if seed is not None:
        np.random.seed(seed)

    # Generate lengths uniformly distributed (could also use other distributions)
    lengths = np.random.uniform(min_length, max_length, num_players)

    return lengths


def compute_error_with_timing(
    game: AirPortGame,
    num_players: int,
    paths: int,
    seed: int,
    anthithetic: bool,
    exact: NDArray[np.float64],
    l2_norm: float,
) -> tuple[float, float, float, float, float]:
    """Compute errors and timing of AirportGame.

    Compute RMS error, max error, relative errors,
    and timing compared to exact Shapley values.
    """
    start_time = time.time()
    mc_result = shapley_perm_mc(
        game, num_players, paths=paths, seed=seed, anthithetic=anthithetic
    )
    elapsed_time = time.time() - start_time

    # Compute absolute errors
    rms_error = np.sqrt(np.mean((mc_result - exact) ** 2))
    max_error = np.max(np.abs(mc_result - exact))

    # Compute relative errors
    rms_rel_error = rms_error / l2_norm if l2_norm > 0 else 0.0
    # For max relative error: divide each error by its exact value, then take max
    with np.errstate(divide='ignore', invalid='ignore'):
        rel_errors = np.abs(mc_result - exact) / np.abs(exact)
        rel_errors = rel_errors[np.isfinite(rel_errors)]  # Filter out inf/nan
    max_rel_error = np.max(rel_errors) if len(rel_errors) > 0 else 0.0

    return (
        float(rms_error),
        float(max_error),
        float(rms_rel_error),
        float(max_rel_error),
        elapsed_time,
    )


def verify_exact_solution(num_players: int, lengths: NDArray[np.float64]) -> None:
    """Verify that our exact formula matches the computed Shapley values."""
    game = AirPortGame(lengths)
    computed = shapley(game, num_players)
    formula = exact_airport_shapley(lengths)

    print(f'\n  Verifying exact solution for {num_players} players:')
    print(f'    Max difference: {np.max(np.abs(computed - formula)):.10f}')
    print(f'    Values match? {np.allclose(computed, formula, rtol=1e-6)}')
    print(f'    Total cost (sum of Shapley values): {np.sum(formula):.2f}')
    print(f'    Max runway length: {np.max(lengths):.2f}')


def main() -> None:
    """Compare antithetic vs non-antithetic sampling on Airport Game."""
    print('=' * 120)
    print('Airport Game: Random runway length requirements')
    print('=' * 120)
    print()

    # First, verify our exact solution formula
    print('Verifying exact Shapley value formula:')
    test_lengths_1 = np.array([3000.0, 2000.0, 1500.0, 1000.0, 500.0])
    verify_exact_solution(5, test_lengths_1)

    test_lengths_2 = generate_random_airport_game(20, seed=42)
    verify_exact_solution(20, test_lengths_2)

    print('\n' + '=' * 120)
    print('Monte Carlo Comparison: Antithetic vs No Antithetic')
    print('=' * 120)
    print()

    # Test different numbers of players
    player_counts = [10, 20, 30, 40, 50, 60]
    # Test different numbers of paths
    path_counts = [10_000, 50_000, 100_000, 200_000, 500_000, 1_000_000]

    for num_players in player_counts:
        # Generate random airport game
        lengths = generate_random_airport_game(
            num_players,
            min_length=100.0,
            max_length=10000.0,
            seed=12345 + num_players,  # Different seed for each player count
        )
        game = AirPortGame(lengths)

        # Compute exact Shapley values and norms
        exact = exact_airport_shapley(lengths)
        l2_norm = np.sqrt(np.sum(exact**2))

        print(f'\nNumber of players: {num_players}')
        print(
            f'  Runway lengths: min={np.min(lengths):.1f}, '
            f'max={np.max(lengths):.1f}, mean={np.mean(lengths):.1f}'
        )
        print(
            f'  Shapley values: min={np.min(exact):.2f}, '
            f'max={np.max(exact):.2f}, sum={np.sum(exact):.2f}'
        )
        print(f'  L2 norm: {l2_norm:.2f}')
        print(
            f'{"Paths":<12} {"RMS":<8} {"Rel%":<8} {"√n Ratio":<10} '
            f'{"RMS":<8} {"Rel%":<8} {"√n Ratio":<10} {"Eff N":<10} {"Improv"}'
        )
        print(f'{"":12} {"No Anti":^26} {"Anti":^26} {"":<10} {""}')
        print('-' * 120)

        # Store baseline errors for convergence rate analysis
        baseline_paths = None
        baseline_rms_no_anti = None
        baseline_rms_anti = None

        for paths in path_counts:
            seed = 0xDEADBEEF

            # Compute errors and timings
            (rms_no_anti, _, rms_rel_no_anti, _, _) = compute_error_with_timing(
                game,
                num_players,
                paths,
                seed,
                anthithetic=False,
                exact=exact,
                l2_norm=l2_norm,
            )
            (rms_anti, _, rms_rel_anti, _, _) = compute_error_with_timing(
                game,
                num_players,
                paths,
                seed,
                anthithetic=True,
                exact=exact,
                l2_norm=l2_norm,
            )

            # Compute improvement in relative RMS error
            improvement = (rms_rel_no_anti - rms_rel_anti) / rms_rel_no_anti * 100

            # Set baseline on first iteration
            if baseline_paths is None:
                baseline_paths = paths
                baseline_rms_no_anti = rms_no_anti
                baseline_rms_anti = rms_anti
                sqrt_ratio_no_anti = 1.0
                sqrt_ratio_anti = 1.0
            else:
                # Theoretical √n reduction: error should be
                # baseline * √(baseline_paths/paths)
                theoretical_factor = np.sqrt(baseline_paths / paths)
                expected_rms_no_anti = baseline_rms_no_anti * theoretical_factor
                expected_rms_anti = baseline_rms_anti * theoretical_factor

                # Ratio of actual to theoretical
                # (should be ~1.0 for perfect √n convergence)
                sqrt_ratio_no_anti = rms_no_anti / expected_rms_no_anti
                sqrt_ratio_anti = rms_anti / expected_rms_anti

            # Effective sample size: how many non-antithetic paths needed
            # for same error as antithetic
            effective_n = paths * (rms_no_anti / rms_anti) ** 2

            print(
                f'{paths:<12,} {rms_no_anti:<8.2f} {rms_rel_no_anti * 100:<7.2f}% '
                f'{sqrt_ratio_no_anti:<10.3f} '
                f'{rms_anti:<8.2f} {rms_rel_anti * 100:<7.2f}% '
                f'{sqrt_ratio_anti:<10.3f} '
                f'{effective_n / 1000:<9.0f}K {improvement:>6.1f}%'
            )

    print('\n' + '=' * 120)
    print('\nNote:')
    print('- RMS = Root Mean Square error')
    print('- Rel% = Relative error: RMS / L2_norm')
    print('- √n Ratio = Actual_error / Theoretical_error')
    print('  * Theoretical error assumes perfect √n convergence from baseline')
    print('  * Ratio ≈ 1.0 confirms O(1/√n) convergence')
    print('- Eff N = Effective sample size for antithetic sampling')
    print('  * Number of non-antithetic paths needed to match antithetic error')
    print('  * Computed as: N * (RMS_no_anti / RMS_anti)²')
    print('- Improv = Relative RMS error improvement: (NoAnti - Anti) / NoAnti * 100%')
    print('- Airport game: Coalition value = max runway length required')


if __name__ == '__main__':
    main()
