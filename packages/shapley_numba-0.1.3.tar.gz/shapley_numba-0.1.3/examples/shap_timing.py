"""Timing comparison between shapley-numba and SHAP's Exact explainer."""

import timeit

import numba
import numpy as np
import shap

from shapley_numba.examples import GloveGame
from shapley_numba.shapley import shapley


def shap_game_adapter(game):
    """Wrap a shapley-numba game for use with shap.explainers.Exact."""
    jitted_game = game.jitted_game

    @numba.njit
    def _value_of_coalitions(jg, coalitions):
        ln = len(coalitions)
        result = np.zeros(ln)
        for i, c in enumerate(coalitions):
            result[i] = jg.value(c)
        return result

    def value_of_coalitions(coalitions):
        return _value_of_coalitions(jitted_game, coalitions)

    return value_of_coalitions


def _time_ms(fn, repeats):
    times = timeit.repeat(fn, number=1, repeat=repeats)
    return np.mean(times) * 1e3, np.std(times) * 1e3


def run_one(num_players: int, num_left_gloves: int, repeats: int) -> None:
    """Run timing comparison for a single num_players value."""
    game = GloveGame(num_left_gloves)
    background = np.zeros((1, num_players), dtype=np.int32)
    foreground = np.ones((1, num_players), dtype=np.int32)

    # --- SHAP with numba adapter ---
    adapted = shap_game_adapter(game)
    adapted(foreground)  # warm up JIT
    explainer_nb = shap.explainers.Exact(adapted, background)
    explainer_nb(foreground, max_evals=None)  # warmup
    nb_mean, nb_std = _time_ms(
        lambda: explainer_nb(foreground, max_evals=None), repeats
    )

    # --- shapley-numba ---
    shapley(game, num_players)  # warmup
    sn_mean, sn_std = _time_ms(lambda: shapley(game, num_players), repeats)

    print(
        f'{num_players:>12} '
        f'{nb_mean:>22.1f} ± {nb_std:<8.1f}'
        f'{sn_mean:>22.1f} ± {sn_std:<8.1f}'
    )


def run(
    player_counts: list[int] | None = None,
    num_left_gloves: int = 3,
    repeats: int = 5,
) -> None:
    """Run timing comparison across several player counts for a GloveGame.

    Parameters
    ----------
    player_counts : list[int], optional
        List of num_players values to benchmark. Defaults to [8, 12, 16, 20, 24].
    num_left_gloves : int
        Number of left-glove players in the GloveGame.
    repeats : int
        Number of timing repetitions per configuration.

    """
    if player_counts is None:
        player_counts = [8, 12, 16, 20, 24]

    print(f'GloveGame  num_left_gloves={num_left_gloves}  repeats={repeats}')
    print()
    header = f'{"num_players":>12} {"SHAP numba (ms)":>31}{"shapley-numba (ms)":>31}'
    print(header)
    print('-' * len(header))

    for n in player_counts:
        if n > 20:
            repeats = round(repeats / 2)
        if n > 40:
            repeats = 1
        run_one(n, num_left_gloves, repeats)


if __name__ == '__main__':
    run()
