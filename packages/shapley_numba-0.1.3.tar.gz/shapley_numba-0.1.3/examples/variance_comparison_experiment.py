"""Variance comparison experiment: Antithetic vs No Antithetic sampling.

This experiment tests whether antithetic sampling reduces variance by:
1. Creating random airport games with different player counts
2. Running multiple independent samples (each with 100K paths)
3. Computing the variance across samples
4. Comparing antithetic vs non-antithetic sampling variance
"""

import time
from typing import NamedTuple

import numpy as np
from numpy.typing import NDArray

from shapley_numba.examples import AirPortGame
from shapley_numba.shapley import shapley_perm_mc


class VarianceResults(NamedTuple):
    """Results from variance comparison experiment."""

    num_players: int
    game_seed: int
    num_samples: int
    paths_per_sample: int

    # Statistics for non-antithetic
    mean_values_no_anti: NDArray[np.float64]
    variance_no_anti: NDArray[np.float64]
    total_variance_no_anti: float
    max_variance_no_anti: float

    # Statistics for antithetic
    mean_values_anti: NDArray[np.float64]
    variance_anti: NDArray[np.float64]
    total_variance_anti: float
    max_variance_anti: float

    # Variance reduction
    variance_reduction_ratio: NDArray[np.float64]
    total_variance_reduction: float

    # Timing
    time_no_anti: float
    time_anti: float

    # Exact values for comparison
    exact_values: NDArray[np.float64]


def exact_airport_shapley(
    length_requirements: NDArray[np.float64],
) -> NDArray[np.float64]:
    """Compute exact Shapley values for the Airport Game.

    The airport game has a closed-form solution.
    """
    order = np.argsort(length_requirements)
    num_players = len(length_requirements)
    result = np.zeros_like(length_requirements)
    prev_val = 0.0
    cummul = 0.0

    for num_player, index in enumerate(order):
        val = length_requirements[index]
        diff = val - prev_val
        cummul += diff / (num_players - num_player)
        result[index] = cummul
        prev_val = val

    return result


def generate_random_airport_game(
    num_players: int,
    min_length: float = 100.0,
    max_length: float = 10000.0,
    seed: int | None = None,
) -> NDArray[np.float64]:
    """Generate random runway length requirements."""
    rng = np.random.RandomState(seed)
    lengths = rng.uniform(min_length, max_length, num_players)
    return lengths


def run_variance_experiment(
    num_players: int,
    game_seed: int,
    num_samples: int = 30,
    paths_per_sample: int = 100_000,
    min_length: float = 100.0,
    max_length: float = 10000.0,
) -> VarianceResults:
    """Run variance comparison experiment for a single configuration.

    Parameters
    ----------
    num_players : int
        Number of players in the game
    game_seed : int
        Seed for generating the airport game coefficients
    num_samples : int
        Number of independent samples to run (default: 30)
    paths_per_sample : int
        Number of MC paths per sample (default: 100,000)
    min_length : float
        Minimum runway length
    max_length : float
        Maximum runway length

    Returns
    -------
    VarianceResults
        Complete results including variances and timings

    """
    # Generate the airport game
    lengths = generate_random_airport_game(
        num_players, min_length, max_length, seed=game_seed
    )
    game = AirPortGame(lengths)
    exact_values = exact_airport_shapley(lengths)

    # Storage for samples
    samples_no_anti = np.zeros((num_samples, num_players))
    samples_anti = np.zeros((num_samples, num_players))

    # Run non-antithetic samples
    start_time = time.time()
    for i in range(num_samples):
        # Use different seed for each sample to ensure independence
        sample_seed = game_seed + i * 10000
        samples_no_anti[i] = shapley_perm_mc(
            game,
            num_players,
            paths=paths_per_sample,
            seed=sample_seed,
            anthithetic=False,
        )
    time_no_anti = time.time() - start_time

    # Run antithetic samples
    start_time = time.time()
    for i in range(num_samples):
        sample_seed = game_seed + i * 10000
        samples_anti[i] = shapley_perm_mc(
            game,
            num_players,
            paths=paths_per_sample,
            seed=sample_seed,
            anthithetic=True,
        )
    time_anti = time.time() - start_time

    # Compute statistics
    mean_values_no_anti = np.mean(samples_no_anti, axis=0)
    variance_no_anti = np.var(samples_no_anti, axis=0, ddof=1)
    total_variance_no_anti = float(np.sum(variance_no_anti))
    max_variance_no_anti = float(np.max(variance_no_anti))

    mean_values_anti = np.mean(samples_anti, axis=0)
    variance_anti = np.var(samples_anti, axis=0, ddof=1)
    total_variance_anti = float(np.sum(variance_anti))
    max_variance_anti = float(np.max(variance_anti))

    # Compute variance reduction ratios
    with np.errstate(divide='ignore', invalid='ignore'):
        variance_reduction_ratio = variance_no_anti / variance_anti
        variance_reduction_ratio = np.where(
            np.isfinite(variance_reduction_ratio), variance_reduction_ratio, 1.0
        )

    total_variance_reduction = total_variance_no_anti / total_variance_anti

    return VarianceResults(
        num_players=num_players,
        game_seed=game_seed,
        num_samples=num_samples,
        paths_per_sample=paths_per_sample,
        mean_values_no_anti=mean_values_no_anti,
        variance_no_anti=variance_no_anti,
        total_variance_no_anti=total_variance_no_anti,
        max_variance_no_anti=max_variance_no_anti,
        mean_values_anti=mean_values_anti,
        variance_anti=variance_anti,
        total_variance_anti=total_variance_anti,
        max_variance_anti=max_variance_anti,
        variance_reduction_ratio=variance_reduction_ratio,
        total_variance_reduction=total_variance_reduction,
        time_no_anti=time_no_anti,
        time_anti=time_anti,
        exact_values=exact_values,
    )


def print_summary_table(all_results: list[VarianceResults]) -> None:
    """Print a summary table of all results."""
    print('\n' + '=' * 130)
    print('VARIANCE REDUCTION SUMMARY')
    print('=' * 130)
    print(
        f'{"Players":<10} {"Seed":<10} {"Total Var (No Anti)":<22} '
        f'{"Total Var (Anti)":<22} '
        f'{"Reduction":<12} {"Max Reduction":<15} {"Time (s)":<15}'
    )
    print('-' * 130)

    for result in all_results:
        reduction_pct = (1 - 1 / result.total_variance_reduction) * 100
        max_reduction = np.max(result.variance_reduction_ratio)

        print(
            f'{result.num_players:<10} {result.game_seed:<10} '
            f'{result.total_variance_no_anti:<22.6f} '
            f'{result.total_variance_anti:<22.6f}'
            f'{result.total_variance_reduction:<6.3f}x ({reduction_pct:>5.1f}%) '
            f'{max_reduction:<15.3f} '
            f'{result.time_no_anti:.1f} / {result.time_anti:.1f}'
        )

    print('=' * 130)

    # Compute overall statistics
    total_reductions = [r.total_variance_reduction for r in all_results]
    print('\nOverall variance reduction statistics:')
    print(f'  Mean reduction factor: {np.mean(total_reductions):.3f}x')
    print(f'  Median reduction factor: {np.median(total_reductions):.3f}x')
    print(f'  Min reduction factor: {np.min(total_reductions):.3f}x')
    print(f'  Max reduction factor: {np.max(total_reductions):.3f}x')
    print(f'  Std dev: {np.std(total_reductions):.3f}')


def print_detailed_result(result: VarianceResults) -> None:
    """Print detailed results for a single experiment."""
    print(f'\n{"=" * 100}')
    print(
        f'Players: {result.num_players} | Game Seed: {result.game_seed} | '
        f'Samples: {result.num_samples} | Paths per sample: {result.paths_per_sample:,}'
    )
    print(f'{"=" * 100}')

    # Basic statistics
    print('\nGame statistics:')
    print(
        f'  Exact Shapley values: min={np.min(result.exact_values):.2f}, '
        f'max={np.max(result.exact_values):.2f}, sum={np.sum(result.exact_values):.2f}'
    )

    # Variance comparison
    print(f'\nVariance comparison (across {result.num_samples} independent samples):')
    print('  No Antithetic:')
    print(f'    Total variance: {result.total_variance_no_anti:.6f}')
    print(f'    Max variance (single player): {result.max_variance_no_anti:.6f}')
    print(f'    Mean variance: {np.mean(result.variance_no_anti):.6f}')
    print(f'    Time: {result.time_no_anti:.2f}s')

    print('  Antithetic:')
    print(f'    Total variance: {result.total_variance_anti:.6f}')
    print(f'    Max variance (single player): {result.max_variance_anti:.6f}')
    print(f'    Mean variance: {np.mean(result.variance_anti):.6f}')
    print(f'    Time: {result.time_anti:.2f}s')

    print('\nVariance reduction:')
    print(
        f'  Total variance reduction: {result.total_variance_reduction:.3f}x '
        f'({(1 - 1 / result.total_variance_reduction) * 100:.1f}% reduction)'
    )
    print(
        f'  Mean per-player reduction: {np.mean(result.variance_reduction_ratio):.3f}x'
    )
    print(
        '  Median per-player reduction: '
        f'{np.median(result.variance_reduction_ratio):.3f}x'
    )
    print(f'  Max per-player reduction: {np.max(result.variance_reduction_ratio):.3f}x')
    print(f'  Min per-player reduction: {np.min(result.variance_reduction_ratio):.3f}x')

    # Bias check
    bias_no_anti = np.mean(np.abs(result.mean_values_no_anti - result.exact_values))
    bias_anti = np.mean(np.abs(result.mean_values_anti - result.exact_values))

    print('\nBias check (mean absolute error from exact values):')
    print(f'  No Antithetic: {bias_no_anti:.6f}')
    print(f'  Antithetic: {bias_anti:.6f}')
    print('  Both methods should be unbiased (low bias)')

    # Per-player variance reduction for a few players
    print('\nPer-player variance reduction (first 5 players):')
    print(f'  {"Player":<8} {"Var (No Anti)":<15} {"Var (Anti)":<15} {"Reduction":<12}')
    print(f'  {"-" * 60}')
    for i in range(min(5, result.num_players)):
        reduction = result.variance_reduction_ratio[i]
        print(
            f'  {i:<8} {result.variance_no_anti[i]:<15.6f} '
            f'{result.variance_anti[i]:<15.6f} {reduction:<6.3f}x'
        )


def main() -> None:
    """Run the variance comparison experiment."""
    print('=' * 100)
    print('VARIANCE COMPARISON EXPERIMENT: Antithetic vs No Antithetic Sampling')
    print('=' * 100)
    print('\nExperiment design:')
    print('  - Run multiple independent samples of Monte Carlo estimation')
    print('  - Each sample uses 100K paths')
    print('  - Compute variance across samples')
    print('  - Compare variance: No Antithetic vs Antithetic')
    print('  - Test with different player counts and random game seeds')

    # Configuration
    player_counts = [40, 50, 60]
    game_seeds = [42, 123, 999]  # Three different random seeds
    num_samples = 30  # Number of independent samples per configuration
    paths_per_sample = 100_000

    print('\nConfiguration:')
    print(f'  Player counts: {player_counts}')
    print(f'  Game seeds: {game_seeds}')
    print(f'  Samples per configuration: {num_samples}')
    print(f'  Paths per sample: {paths_per_sample:,}')
    print(f'  Total configurations: {len(player_counts) * len(game_seeds)}')

    # Run experiments
    all_results: list[VarianceResults] = []

    for num_players in player_counts:
        for game_seed in game_seeds:
            print(f'\n\nRunning experiment: {num_players} players, seed {game_seed}...')
            result = run_variance_experiment(
                num_players=num_players,
                game_seed=game_seed,
                num_samples=num_samples,
                paths_per_sample=paths_per_sample,
            )
            all_results.append(result)
            print_detailed_result(result)

    # Print summary table
    print_summary_table(all_results)

    # Additional analysis
    print('\n' + '=' * 100)
    print('INTERPRETATION')
    print('=' * 100)
    print("""
The variance reduction factor shows how much antithetic sampling reduces variance:
  - Factor > 1.0: Antithetic sampling reduces variance (GOOD!)
  - Factor ≈ 2.0: Theoretical maximum for antithetic sampling
  - Factor < 1.0: Antithetic sampling increases variance (BAD - should not happen)

For Monte Carlo methods, reducing variance by factor k is equivalent to:
  - Running k times as many samples without antithetic sampling
  - Achieving the same accuracy with k times less computational cost

The experiment uses independent samples to measure the true variance of the estimator.
Each sample uses a different random seed to ensure statistical independence.
    """)


if __name__ == '__main__':
    main()
