import hypothesis.strategies as st
import numpy as np
import pytest
from hypothesis import assume, given, settings

from shapley_numba.examples import UnanimityGame
from shapley_numba.harsanyi_large import HarsanyiDividendsLarge
from shapley_numba.shapley import shapley

from .testing_utilities import coalition, coalitions


@pytest.fixture(scope='module')
def max_players(request: pytest.FixtureRequest) -> int:
    """Fixture that provides max_players value from parametrize."""
    print('Number of players ', request.param)
    return request.param


@pytest.fixture(scope='module')
def random_coalitions(max_players: int) -> st.SearchStrategy:
    return coalitions(max_players=max_players)


@pytest.fixture(scope='module')
def random_coalition(max_players: int) -> st.SearchStrategy:
    return coalition(max_players=max_players)


@pytest.mark.parametrize(
    'max_players', [6, pytest.param(10, marks=pytest.mark.requires_jit)], indirect=True
)
@settings(deadline=None)
@given(data=st.data())
def test_unanimity_shapley(data, random_coalition):
    drawn_coalition = data.draw(random_coalition)
    assume(sum(drawn_coalition) > 0)
    game = UnanimityGame(drawn_coalition)
    result = shapley(game, len(drawn_coalition))
    expected = drawn_coalition.astype(np.float64) / sum(drawn_coalition)
    assert result == pytest.approx(expected)


@pytest.mark.parametrize(
    'max_players', [6, pytest.param(10, marks=pytest.mark.requires_jit)], indirect=True
)
@settings(deadline=None)
@given(data=st.data())
def test_unanimity_harsanyi(data, random_coalitions):
    drawn_coalitions = data.draw(random_coalitions)
    veto_coalition, *other_coalitions = drawn_coalitions
    other_coalitions = [  # just in case veto coalition got drawn again.
        c for c in other_coalitions if np.max(np.abs(c - veto_coalition)) > 0
    ]
    assume(sum(veto_coalition) > 0)
    assume(len(other_coalitions) > 0)
    game = UnanimityGame(veto_coalition)
    hd = HarsanyiDividendsLarge(game, len(veto_coalition))
    assert hd(veto_coalition) == pytest.approx(1.0)
    for other_coalition in other_coalitions:
        assert hd(other_coalition) == pytest.approx(0.0)
