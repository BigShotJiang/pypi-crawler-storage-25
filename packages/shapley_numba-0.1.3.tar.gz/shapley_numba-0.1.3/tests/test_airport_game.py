import numpy as np
import pytest
from hypothesis import given, settings
from hypothesis import strategies as st
from hypothesis.extra.numpy import arrays

from shapley_numba.examples.games import AirPortGame
from shapley_numba.shapley import shapley


def test_airport_game_wikipedia():
    game = AirPortGame(np.array([8, 11, 13, 18], dtype=np.float64))
    result = shapley(game, 4)
    assert np.allclose(result, [2.0, 3.0, 4.0, 9.0])


def test_negative_requirements_raise_error():
    with pytest.raises(
        ValueError, match='All length requirements must be non-negative.'
    ):
        AirPortGame(np.array([8, -5, 13, 18], dtype=np.float64))


def airport_game_exact_solution(length_requirements):
    order = np.argsort(length_requirements)
    num_players = len(length_requirements)
    result = np.zeros_like(length_requirements)
    prev_val = 0
    cummul = 0
    for num_player, index in enumerate(order):
        val = length_requirements[index]
        diff = val - prev_val
        cummul += diff / (num_players - num_player)
        result[index] = cummul
        prev_val = val
    return result


def test_exact_solution():
    length_requirements = np.array([8, 11, 13, 18], dtype=np.float64)
    result = airport_game_exact_solution(length_requirements)
    assert np.allclose(result, [2.0, 3.0, 4.0, 9.0])


@settings(deadline=None)  # hypothesis doesn't like numba compilation time.
@given(
    arrays(
        dtype=np.float64,
        shape=st.integers(min_value=2, max_value=5),
        elements=st.floats(
            min_value=0,
            max_value=1e7,  # there is a loss of significance
            # in the main shapley algorithm
            allow_nan=False,
            allow_infinity=False,
        ),
    )
)
def test_shapley_is_exact_solution(length_requirements):
    game = AirPortGame(length_requirements)
    result = shapley(game, len(length_requirements))
    expected = airport_game_exact_solution(length_requirements)
    assert np.allclose(result, expected)
