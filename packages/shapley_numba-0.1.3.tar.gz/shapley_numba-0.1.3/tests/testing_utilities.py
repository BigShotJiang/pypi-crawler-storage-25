import hypothesis.strategies as st
import numpy as np

from shapley_numba.common import subsets
from shapley_numba.typing import CoalitionType


@st.composite
def coalition(
    draw: st.DrawFn, *, max_players: int, min_players: int = 2
) -> CoalitionType:
    """Hypothesis strategy that returns a random subset/coalition."""
    subset = draw(
        st.lists(
            st.integers(min_value=0, max_value=1),
            min_size=min_players,
            max_size=max_players,
        )
    )
    return np.array(subset, dtype=np.int32)


@st.composite
def _fixed_number_of_coalitions(
    draw: st.DrawFn, num_coalitions: int, *, num_players: int
) -> list[CoalitionType]:
    """Hypothesis strategy that returns a list of random subsets/coalitions."""
    return [
        draw(coalition(max_players=num_players, min_players=num_players))
        for _ in range(num_coalitions)
    ]


@st.composite
def coalitions(
    draw: st.DrawFn,
    *,
    max_players: int,
    min_players: int = 2,
    min_coalitions: int = 2,
    max_coalitions: int = 100,
) -> list[CoalitionType]:
    """Hypothesis strategy that returns a random number of coalitions."""
    num_players = draw(st.integers(min_value=min_players, max_value=max_players))
    num_coalitions = draw(
        st.integers(min_value=min_coalitions, max_value=max_coalitions)
    )
    return draw(_fixed_number_of_coalitions(num_coalitions, num_players=num_players))


def assert_games_almost_equal(game1, game2, num_players, rtol=1e-7, atol=0):
    """Assert that two games are almost equal.

    Has the same tolerance as `np.testing.assert_allclose`.
    """
    for subset in subsets(num_players):
        np.testing.assert_allclose(
            game1.value(subset),
            game2.value(subset),
            rtol=rtol,
            atol=atol,
            err_msg=f'Games are not equal on {subset}',
        )
