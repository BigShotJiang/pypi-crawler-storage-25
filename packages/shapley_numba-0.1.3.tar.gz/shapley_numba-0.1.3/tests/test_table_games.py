import numpy as np
import pytest

from shapley_numba.examples import WikipediaExample
from shapley_numba.game_templates import TableGame
from tests.testing_utilities import assert_games_almost_equal


def test_wikipedia_as_table_game():
    original_game = WikipediaExample()
    table_game = TableGame(
        {
            (1, 0, 0): 30.0,
            (0, 1, 0): 20.0,
            (0, 0, 1): 10.0,
            (1, 1, 0): 90.0,
            (1, 0, 1): 100.0,
            (0, 1, 1): 30.0,
            (1, 1, 1): 280.0,
        }
    )
    assert not isinstance(table_game.jitted_game, Exception)
    assert_games_almost_equal(original_game, table_game, 3)


@pytest.mark.requires_jit
def test_wikipedia_as_table_game_without_preparation():
    original_game = WikipediaExample()
    table_game = TableGame(
        {
            1: 30.0,
            2: 20.0,
            4: 10.0,
            3: 90.0,
            5: 100.0,
            6: 30.0,
            7: 280.0,
        }
    )
    assert isinstance(table_game.jitted_game, Exception)
    assert_games_almost_equal(original_game, table_game, 3)


def test_non_zero_vacuum():
    table_game = TableGame(
        {(1, 0, 0): 30.0},
        vacuum_value=10.0,
    )
    assert table_game.value(np.array([0, 0, 0])) == 10.0
    assert table_game.value(np.array([1, 0, 0])) == 30.0
    assert table_game.value(np.array([0, 1, 0])) == 0.0
    assert table_game.value(np.array([0, 0, 1])) == 0.0
    assert table_game.value(np.array([1, 1, 0])) == 0.0
    assert table_game.value(np.array([1, 0, 1])) == 0.0
    assert table_game.value(np.array([0, 1, 1])) == 0.0
    assert table_game.value(np.array([1, 1, 1])) == 0.0


def test_non_zero_default():
    table_game = TableGame(
        {(1, 0, 0): 30.0},
        default_value=10.0,
    )
    assert table_game.value(np.array([0, 0, 0])) == 0.0
    assert table_game.value(np.array([1, 0, 0])) == 30.0
    assert table_game.value(np.array([0, 1, 0])) == 10.0
    assert table_game.value(np.array([0, 0, 1])) == 10.0
    assert table_game.value(np.array([1, 1, 0])) == 10.0
    assert table_game.value(np.array([1, 0, 1])) == 10.0
    assert table_game.value(np.array([0, 1, 1])) == 10.0
    assert table_game.value(np.array([1, 1, 1])) == 10.0
