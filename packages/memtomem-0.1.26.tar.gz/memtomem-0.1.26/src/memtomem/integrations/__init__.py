"""Framework integrations for memtomem."""
