"""Web UI API routes."""
