"""Sherpa CSV/Excel/TXT knowledge import plugin"""

__version__ = "1.6.57"
