"""Shared runtime wiring for the watcher's long-running loop.

The CLI `watch` command and the Windows-service `SvcDoRun` entrypoint both
need to assemble the same graph of objects (`StateDB`, `EventReporter`,
`Uploader`, `RunDetector`, `FileMonitor`, `HeartbeatLoop`) and start /
stop them in the same order. Keeping that wiring in one place prevents
the two call sites from drifting — a historical source of bugs, notably
the Windows-service path forgetting to pass `on_tick` to `HeartbeatLoop`
and thereby silently skipping manual-mode upload-queue polling.
"""

from __future__ import annotations
import logging
import threading
from dataclasses import dataclass, field
from pathlib import Path

from data_hub_watcher.api_client import ApiError, DataHubClient
from data_hub_watcher.constants import (
    DEFAULT_CONFIG_DIR,
    HEARTBEAT_INTERVAL_SECONDS,
    PRUNE_DAYS,
)
from data_hub_watcher.events import EventReporter, EventType, WatcherEvent
from data_hub_watcher.heartbeat import HeartbeatLoop, WatcherCounters
from data_hub_watcher.models import WatcherConfig
from data_hub_watcher.monitor import FileMonitor
from data_hub_watcher.run_detector import RunDetector
from data_hub_watcher.state import StateDB
from data_hub_watcher.updater import Updater, evaluate_upgrade_marker
from data_hub_watcher.uploader import Uploader

logger = logging.getLogger(__name__)


@dataclass
class WatcherRuntime:
    """Bundle of all long-lived objects for a running watcher session."""

    state_db: StateDB
    counters: WatcherCounters
    reporter: EventReporter
    uploader: Uploader
    detector: RunDetector
    monitor: FileMonitor
    heartbeat: HeartbeatLoop
    updater: Updater
    # Set when the in-process updater has successfully installed a new
    # watcher version and wants the main loop to exit non-zero so the
    # Windows SCM (or a foreground operator running ``watch``) restarts
    # us into the new code. The CLI / service main loops poll this event
    # in their stop wait so a shutdown can be triggered from any thread.
    shutdown_event: threading.Event = field(default_factory=threading.Event)
    upgrade_restart_event: threading.Event = field(default_factory=threading.Event)


@dataclass(frozen=True)
class ShutdownReason:
    """Why the runtime is shutting down + the matching WATCHER_STOPPED message.

    The CLI ``watch`` command and the Windows service both poll the
    runtime's ``shutdown_event`` and need to attribute the resulting
    ``WATCHER_STOPPED`` event to either a normal stop or an
    auto-update-driven restart. Centralising the message text here keeps
    the two paths in sync — historically the service path always logged
    "Service stopped" even on auto-update restarts, which made it
    impossible to correlate an ``update_started`` event with the
    matching ``watcher_stopped`` event in the dashboard.
    """

    is_upgrade_restart: bool
    stopped_message: str


def classify_shutdown(rt: WatcherRuntime, *, role: str) -> ShutdownReason:
    """Pick the right ``stopped_message`` for the WATCHER_STOPPED event.

    *role* is the human-readable noun for this entrypoint
    (``"Watcher"`` for the CLI, ``"Service"`` for the Windows service)
    so the message reads naturally in the events stream regardless of
    which path triggered the shutdown.

    Note: the CLI's signal-initiated stop has its own "stopped by user"
    message and does not go through this helper — at that point we
    already know the cause is an operator signal, not the auto-updater.
    """
    if rt.upgrade_restart_event.is_set():
        return ShutdownReason(
            is_upgrade_restart=True,
            stopped_message=f"{role} restarting for auto-update",
        )
    return ShutdownReason(
        is_upgrade_restart=False,
        stopped_message=f"{role} stopped",
    )


def build_runtime(
    *,
    client: DataHubClient,
    cfg: WatcherConfig,
    db_path: Path,
) -> WatcherRuntime:
    """Construct the full runtime graph from a validated config.

    The caller is responsible for ensuring `cfg.watcher_id` is set — the
    CLI does this explicitly via a click error, and the service does it
    via a registry lookup. We assert here as a safety net so a silent
    misconfiguration becomes a loud crash.
    """
    if not cfg.watcher_id:
        raise ValueError("cfg.watcher_id must be set before building the runtime")

    inst = cfg.instrument
    watcher_id = cfg.watcher_id

    state_db = StateDB(db_path)
    state_db.prune_uploaded_files(PRUNE_DAYS)

    counters = WatcherCounters()
    reporter = EventReporter(client, watcher_id)

    shutdown_event = threading.Event()
    upgrade_restart_event = threading.Event()

    def _request_upgrade_restart(target_version: str) -> None:
        logger.info(
            "Auto-update: requesting service restart to load watcher %s",
            target_version,
        )
        upgrade_restart_event.set()
        shutdown_event.set()

    updater = Updater(
        client=client,
        reporter=reporter,
        counters=counters,
        state_db=state_db,
        cfg=cfg,
        config_dir=DEFAULT_CONFIG_DIR,
        request_upgrade_restart=_request_upgrade_restart,
    )

    is_auto = inst.upload_mode == "auto"

    uploader = Uploader(
        client=client,
        state_db=state_db,
        event_reporter=reporter,
        counters=counters,
        instrument_id=inst.id,
        watcher_id=watcher_id,
        watch_directory=inst.watch_directory,
    )

    detector = RunDetector(
        pattern=inst.run_detection.pattern,
        instrument_id=inst.id,
        watcher_id=watcher_id,
        client=client,
        state_db=state_db,
        event_reporter=reporter,
        counters=counters,
        upload_callback=uploader.upload_files if is_auto else None,
        watch_directory=inst.watch_directory,
    )

    monitor = FileMonitor(
        watch_directory=inst.watch_directory,
        file_patterns=inst.file_patterns,
        stability_period=inst.stability_period_seconds,
        on_stable_file=detector.on_stable_file,
        state_db=state_db,
        recursive=inst.run_detection.recursive,
        event_reporter=reporter,
    )

    # The heartbeat's `on_tick` hook is now multi-purpose:
    #   1. In manual mode, poll the server's upload queue (uploads
    #      naturally inherit the heartbeat cadence).
    #   2. Always: feed the in-process auto-updater so it can count
    #      idle ticks and run a server update-check roughly hourly.
    # Each side wraps its own try/except so a failure on one side
    # never blocks the other.
    def _on_tick() -> None:
        if not is_auto:
            try:
                uploader.poll_upload_queue()
            except Exception:
                logger.exception("Upload queue poll failed")
        try:
            updater.on_tick()
        except Exception:
            logger.exception("Updater tick failed")

    heartbeat = HeartbeatLoop(
        client=client,
        watcher_id=watcher_id,
        interval_seconds=HEARTBEAT_INTERVAL_SECONDS,
        event_reporter=reporter,
        instrument_id=inst.id,
        watch_directory=str(inst.watch_directory),
        upload_mode=inst.upload_mode,
        counters=counters,
        on_tick=_on_tick,
    )

    return WatcherRuntime(
        state_db=state_db,
        counters=counters,
        reporter=reporter,
        uploader=uploader,
        detector=detector,
        monitor=monitor,
        heartbeat=heartbeat,
        updater=updater,
        shutdown_event=shutdown_event,
        upgrade_restart_event=upgrade_restart_event,
    )


def start_runtime(rt: WatcherRuntime, *, started_message: str) -> None:
    """Queue the started event, recover unreported runs, then start threads.

    The `started_message` varies by entry point (`"Watcher started on …"`
    from the CLI vs `"Service started on …"` from the Windows service)
    so operators can tell from the event log which code path launched.

    Also inspects the on-disk upgrade marker before any threads start so
    a recently-attempted self-update is reported as
    ``UPDATE_SUCCEEDED`` / ``UPDATE_FAILED`` from this fresh process,
    not from the doomed old process that asked for the restart.
    """
    rt.reporter.queue_event(
        WatcherEvent(
            event_type=EventType.WATCHER_STARTED,
            message=started_message,
        )
    )

    outcome = evaluate_upgrade_marker(DEFAULT_CONFIG_DIR)
    if outcome.found:
        if outcome.succeeded:
            rt.reporter.queue_event(
                WatcherEvent(
                    event_type=EventType.UPDATE_SUCCEEDED,
                    message=(
                        f"Restarted into upgraded watcher "
                        f"{outcome.previous_version} -> {outcome.target_version}"
                    ),
                    details={
                        "previous_version": outcome.previous_version,
                        "target_version": outcome.target_version,
                    },
                )
            )
        else:
            rt.reporter.queue_event(
                WatcherEvent(
                    event_type=EventType.UPDATE_FAILED,
                    message=f"Watcher upgrade did not take effect: {outcome.reason}",
                    details={
                        "previous_version": outcome.previous_version,
                        "target_version": outcome.target_version,
                        "reason": outcome.reason,
                    },
                )
            )

    # Rebuild in-memory run state from the local DB before any file
    # events fire. Without this, every restart starts with an empty
    # `_runs` dict and the initial scan would re-POST / re-PATCH runs
    # that were already reported in a previous session. Must happen
    # before `monitor.start()`, which runs the initial scan and may
    # route files through `_update_run` based on hydrated state.
    rt.detector.hydrate_from_state_db()

    rt.heartbeat.start()
    rt.monitor.start()


def sync_config_to_api(
    client: DataHubClient,
    watcher_id: str,
    path: Path,
    reporter: EventReporter,
    *,
    trigger: str = "startup",
) -> bool:
    """Push the local config to the API if it differs from the remote.

    Reporter-aware sibling of ``cli._push_config_to_api`` used by the
    long-running ``watch`` and Windows-service entrypoints. On a
    successful push it queues ``EventType.CONFIG_SYNCED`` (mirroring
    the operator-facing CLI helper) so a dashboard observer can tell
    the watcher caught up to a freshly-edited config. On any API
    failure -- the checksum probe or the push itself -- it queues a
    structured ``kind=config_sync_failed`` ``ERROR`` event so the
    failure is visible centrally rather than only as a yellow startup
    message that nobody reads on a headless lab PC.

    Returns ``True`` if the remote was updated (push attempted),
    ``False`` if the remote already matched and no push was issued.
    """
    # Lazy import so monkey-patching ``config_io.config_checksum`` in
    # tests is observed inside this function (a top-level
    # ``from config_io import config_checksum`` would bind the original
    # at import time and miss the patch).
    from data_hub_watcher.config_io import config_checksum

    try:
        local_checksum = config_checksum(path)
        remote = client.get_config_checksum(watcher_id)
    except ApiError as exc:
        reporter.report_error(
            "config_sync_failed",
            f"Could not check remote config checksum: {exc.message}",
            error=exc.message,
        )
        return False

    if remote is not None and remote.config_checksum == local_checksum:
        return False

    try:
        yaml_content = path.read_text(encoding="utf-8")
        client.push_config(watcher_id, yaml_content, local_checksum)
    except ApiError as exc:
        reporter.report_error(
            "config_sync_failed",
            f"Could not push config to API: {exc.message}",
            checksum=local_checksum,
            error=exc.message,
        )
        return True

    reporter.queue_event(
        WatcherEvent(
            event_type=EventType.CONFIG_SYNCED,
            message=f"Config synced (trigger={trigger})",
            details={"trigger": trigger},
        )
    )
    return True


def stop_runtime(rt: WatcherRuntime, *, stopped_message: str) -> None:
    """Shut everything down in reverse order and flush pending events."""
    rt.monitor.stop()
    rt.reporter.queue_event(
        WatcherEvent(
            event_type=EventType.WATCHER_STOPPED,
            message=stopped_message,
        )
    )
    rt.heartbeat.stop()
    rt.reporter.flush()
    rt.state_db.close()
