"""LangGraph 节点工厂测试 — mock 掉 SoulPolicy Client。"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pytest

from soulpolicy_langgraph import (
    drift_check_node,
    last_ai_text,
    should_block_on_drift,
)


@dataclass
class FakeDriftCheck:
    id: str = "dc_x"
    score: float = 0.5
    z_score: float = 1.0
    severity: str = "warn"
    ema: float = 0.0
    decision: str = "trigger_review"
    evidence: dict[str, Any] = None
    reproducibility: dict[str, Any] = None
    latency_ms: int = 5
    distance_cosine: float | None = 0.5
    distance_mahalanobis: float | None = None
    role_axis_score: float | None = None


class FakeDriftChecks:
    def __init__(self, severity="warn", raise_exc=None):
        self.severity = severity
        self.raise_exc = raise_exc
        self.calls: list[dict] = []

    def check(self, *, text: str, baseline: str):  # noqa: D401
        self.calls.append({"text": text, "baseline": baseline})
        if self.raise_exc is not None:
            raise self.raise_exc
        return FakeDriftCheck(severity=self.severity)


class FakeClient:
    def __init__(self, **kwargs):
        self.drift_checks = FakeDriftChecks(**kwargs)


# ============== last_ai_text ==============


def test_last_ai_text_from_output_string():
    assert last_ai_text({"output": "hello"}) == "hello"


def test_last_ai_text_from_last_message_string():
    assert last_ai_text({"last_message": "world"}) == "world"


def test_last_ai_text_from_messages_dict():
    state = {"messages": [{"role": "user", "content": "hi"}, {"role": "assistant", "content": "ok"}]}
    assert last_ai_text(state) == "ok"


def test_last_ai_text_from_messages_object():
    class M:
        def __init__(self, type, content):
            self.type = type
            self.content = content

    state = {"messages": [M("human", "hi"), M("ai", "yes")]}
    assert last_ai_text(state) == "yes"


def test_last_ai_text_handles_empty():
    assert last_ai_text({}) is None
    assert last_ai_text({"messages": []}) is None


# ============== drift_check_node ==============


def test_drift_node_calls_client_and_writes_state():
    client = FakeClient(severity="critical")
    node = drift_check_node(client, baseline="bl_x")
    out = node({"output": "user output"})
    assert out["drift"]["severity"] == "critical"
    assert client.drift_checks.calls == [{"text": "user output", "baseline": "bl_x"}]


def test_drift_node_no_text_returns_none():
    client = FakeClient()
    node = drift_check_node(client, baseline="bl_x")
    out = node({})
    assert out["drift"] is None
    assert client.drift_checks.calls == []


def test_drift_node_custom_text_extractor():
    client = FakeClient()
    node = drift_check_node(
        client, baseline="bl_x", state_text=lambda s: s["custom"]
    )
    node({"custom": "hello"})
    assert client.drift_checks.calls[0]["text"] == "hello"


def test_drift_node_on_error_raise():
    client = FakeClient(raise_exc=RuntimeError("boom"))
    node = drift_check_node(client, baseline="bl_x")
    with pytest.raises(RuntimeError):
        node({"output": "x"})


def test_drift_node_on_error_skip():
    client = FakeClient(raise_exc=RuntimeError("boom"))
    node = drift_check_node(client, baseline="bl_x", on_error="skip")
    out = node({"output": "x"})
    assert out["drift"] is None
    assert "boom" in out["drift_error"]


# ============== should_block_on_drift ==============


def test_route_continues_below_threshold():
    route = should_block_on_drift("critical")
    assert route({"drift": {"severity": "warn"}}) == "continue"


def test_route_blocks_at_or_above_threshold():
    route = should_block_on_drift("warn")
    assert route({"drift": {"severity": "warn"}}) == "block"
    assert route({"drift": {"severity": "critical"}}) == "block"
    assert route({"drift": {"severity": "ok"}}) == "continue"


def test_route_no_drift_state_continues():
    route = should_block_on_drift("warn")
    assert route({}) == "continue"
    assert route({"drift": None}) == "continue"


def test_route_custom_targets():
    route = should_block_on_drift(
        "critical", continue_target="next", block_target="rollback"
    )
    assert route({"drift": {"severity": "critical"}}) == "rollback"
    assert route({"drift": {"severity": "ok"}}) == "next"


def test_route_invalid_threshold_rejected():
    with pytest.raises(ValueError):
        should_block_on_drift("nope")
