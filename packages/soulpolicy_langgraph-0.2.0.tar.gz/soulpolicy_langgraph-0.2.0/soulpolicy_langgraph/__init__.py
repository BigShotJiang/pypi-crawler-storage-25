"""SoulPolicy 节点包 — 给 LangGraph / LangChain agent 一行接入漂移检测。

用法：

    from langgraph.graph import StateGraph, END
    from soulpolicy import Client
    from soulpolicy_langgraph import drift_check_node, should_block_on_drift

    sp = Client(api_key="sk_live_xxx")

    graph = StateGraph(MyState)
    graph.add_node("agent", agent_step)
    graph.add_node("drift", drift_check_node(sp, baseline="bl_xxx"))
    graph.add_edge("agent", "drift")
    graph.add_conditional_edges(
        "drift",
        should_block_on_drift("warn"),
        {"continue": "agent", "block": END},
    )
"""

from soulpolicy_langgraph._nodes import (
    drift_check_node,
    should_block_on_drift,
    last_ai_text,
)

__version__ = "0.1.0"

__all__ = [
    "drift_check_node",
    "should_block_on_drift",
    "last_ai_text",
    "__version__",
]
