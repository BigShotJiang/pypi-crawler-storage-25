"""LangGraph 节点工厂 + 路由谓词。

设计：不强依赖 langgraph 本身（避免版本耦合）；节点是普通 callable，
state 是普通 dict / TypedDict。LangChain BaseMessage 列表也兼容。
"""
from __future__ import annotations

from typing import Any, Callable, Mapping

# soulpolicy 是同生态的 SDK，但设计上保持松耦合（仅类型用）
try:
    from soulpolicy import Client, DriftCheck  # type: ignore
except Exception:  # pragma: no cover
    Client = Any  # type: ignore
    DriftCheck = Any  # type: ignore


_SEVERITY_RANK = {"ok": 0, "warn": 1, "critical": 2}


def last_ai_text(state: Mapping[str, Any], *, message_key: str = "messages") -> str | None:
    """从常见的 LangChain/LangGraph state 里取最近一条 AI 文本。

    覆盖：
      - state["messages"] 列表，元素含 .type=="ai"/.content 或 dict {"role":"assistant","content":...}
      - state["output"] 直接是 string
      - state["last_message"] 是 string
    """
    if "output" in state and isinstance(state["output"], str):
        return state["output"]
    if "last_message" in state and isinstance(state["last_message"], str):
        return state["last_message"]
    msgs = state.get(message_key)
    if not isinstance(msgs, list) or not msgs:
        return None
    for m in reversed(msgs):
        # LangChain BaseMessage style
        msg_type = getattr(m, "type", None) or (m.get("role") if isinstance(m, dict) else None)
        if msg_type in {"ai", "assistant"}:
            content = getattr(m, "content", None)
            if content is None and isinstance(m, dict):
                content = m.get("content")
            if isinstance(content, str):
                return content
            if isinstance(content, list):  # LangChain message parts
                texts = [p.get("text", "") for p in content if isinstance(p, dict)]
                joined = " ".join(t for t in texts if t)
                if joined:
                    return joined
    return None


def drift_check_node(
    client: "Client",
    *,
    baseline: str,
    state_text: Callable[[Mapping[str, Any]], str | None] | None = None,
    output_key: str = "drift",
    on_error: str = "raise",       # raise | skip
) -> Callable[[Mapping[str, Any]], dict]:
    """生成一个 LangGraph 节点函数，把 drift_check 结果挂到 state[output_key]。

    Args:
      client: SoulPolicy SDK Client
      baseline: bl_xxx
      state_text: 自定义文本提取器；缺省用 last_ai_text
      output_key: state 中存放 DriftCheck 结果的键
      on_error: 调用失败时是 "raise" 还是 "skip"（写入 None）
    """
    extract = state_text or last_ai_text

    def _node(state: Mapping[str, Any]) -> dict:
        text = extract(state)
        if not text:
            return {output_key: None}
        try:
            result = client.drift_checks.check(text=text, baseline=baseline)
        except Exception as e:
            if on_error == "skip":
                return {output_key: None, f"{output_key}_error": str(e)}
            raise
        return {output_key: _drift_to_dict(result)}

    return _node


def should_block_on_drift(
    threshold: str = "critical",
    *,
    output_key: str = "drift",
    block_target: str = "block",
    continue_target: str = "continue",
) -> Callable[[Mapping[str, Any]], str]:
    """生成 LangGraph add_conditional_edges 的路由谓词。

    - state[output_key].severity 达到 threshold 时返回 block_target
    - 否则返回 continue_target
    """
    if threshold not in _SEVERITY_RANK:
        raise ValueError(f"threshold must be ok|warn|critical, got {threshold!r}")
    rank_min = _SEVERITY_RANK[threshold]

    def _route(state: Mapping[str, Any]) -> str:
        drift = state.get(output_key)
        if not drift:
            return continue_target
        sev = drift.get("severity") if isinstance(drift, dict) else getattr(drift, "severity", None)
        if not sev:
            return continue_target
        return block_target if _SEVERITY_RANK.get(sev, 0) >= rank_min else continue_target

    return _route


def _drift_to_dict(result: Any) -> dict:
    """把 DriftCheck dataclass 转 dict（LangGraph state 通常是 JSON-serializable dict）。"""
    if isinstance(result, dict):
        return result
    keys = (
        "id", "score", "z_score", "severity", "ema", "decision",
        "evidence", "reproducibility", "latency_ms",
        "distance_cosine", "distance_mahalanobis", "role_axis_score",
    )
    return {k: getattr(result, k, None) for k in keys}
