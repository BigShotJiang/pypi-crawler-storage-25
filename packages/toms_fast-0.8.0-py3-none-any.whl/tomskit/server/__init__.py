from fastapi import Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from tomskit.server.exceptions import (
    APIException,
    raise_api_error,
    format_validation_errors,
)
from tomskit.server.server import FastApp, FastModule, current_app
from tomskit.server.resource import (
    Resource,
    ResourceRouter,
    ResourceRegistry,
    api_doc,
    register_resource,
)
from tomskit.server.parser import RequestParser
from tomskit.server.type import Boolean, IntRange, StrLen, DatetimeString, PhoneNumber, EmailStr, UUIDType, is_valid_uuid
from tomskit.server.middleware import (
    RequestIDMiddleware,
    ResourceCleanupMiddleware,
    CleanupStrategy,
)
from tomskit.server.config import (
    BaseServerSettings,
    GunicornSettings,
    HypercornSettings,
)

from tomskit.server.context import request_id_context_var, request_id_field


__all__ = [
    # FastAPI/Starlette re-exports
    'Request',
    'RequestValidationError',
    'JSONResponse',
    'StarletteHTTPException',
    # Exceptions
    'raise_api_error',
    'APIException',
    'format_validation_errors',
    # App
    'current_app', 
    'FastApp', 
    'FastModule', 
    # Resource
    'Resource',
    'ResourceRouter',
    'ResourceRegistry',
    'api_doc',
    'register_resource',
    # Parser & Types
    'RequestParser',
    'Boolean', 
    'IntRange', 
    'StrLen', 
    'DatetimeString', 
    'PhoneNumber', 
    'EmailStr',
    'UUIDType',
    'is_valid_uuid',
    # Middleware
    'RequestIDMiddleware',
    'ResourceCleanupMiddleware',
    'CleanupStrategy',
    # Context
    'request_id_context_var',
    'request_id_field',
    # Server Settings
    'BaseServerSettings',
    'GunicornSettings',
    'HypercornSettings',
]
