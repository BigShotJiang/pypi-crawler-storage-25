
import os
import warnings
from contextvars import ContextVar
from typing import Any, Optional, TypeVar

from fastapi import FastAPI
from pydantic_settings import BaseSettings
from starlette.types import ASGIApp

SettingT = TypeVar("SettingT", bound=BaseSettings)


class CurrentApp:
    """
    全局访问当前 FastApp 实例的入口，基于 ContextVar 实现。

    并发约束：
    - **ContextVar 语义**：每个 asyncio task 继承父 context 的副本。
      在 task 内 ``set_app()`` 不会影响父 task；``reset_app()`` 也只影响当前 task。
    - **多应用场景**：若一个进程同时运行多个 FastApp（罕见，通常不这样做），
      不同 task 会看到各自 context 里的 app 实例。
    - **Celery worker**：由 AsyncRuntime 初始化时 ``set_app()``，worker 生命周期内
      所有 task 共享（因为它们在同一个 ContextVar 上下文）。
    - **``reset_app()`` 不是线程安全的**：同时在另一线程调用 ``set_app()``，
      结果未定义。此方法仅用于测试清理。
    """

    __app_ctx: ContextVar[Optional["FastApp"]] = ContextVar('tomskit.current_app.context', default=None)

    def set_app(self, app_instance: "FastApp"):
        self.__app_ctx.set(app_instance)

    def _get_app(self) -> "FastApp":
        """Get the current application instance, raising error if not set."""
        if (app := self.__app_ctx.get()) is None:
            raise RuntimeError("No application instance is currently set")
        return app

    @property
    def app(self) -> "FastApp":
        """Get the current application instance."""
        return self._get_app()

    def __call__(self) -> "FastApp":
        """Get the current application instance when called."""
        return self._get_app()

    @property
    def setting(self) -> BaseSettings:
        """Get the setting from the current application instance."""
        return self._get_app().setting

    @property
    def root_path(self):
        """Get the root path from the current application instance."""
        return self._get_app().root_path

    def reset_app(self):
        """Reset the current application instance."""
        self.__app_ctx.set(None)
        # Also reset FastApp singleton instance for testing
        FastApp.reset_instance()

current_app = CurrentApp()

class FastApp(FastAPI):
    """
    A custom FastAPI instance that disables default documentation paths.

    This class creates a custom FastAPI instance that disables the default
    documentation paths (/docs, /redoc, /openapi) to enhance security and
    reduce unnecessary exposure in production environments.

    This class also adds setting support and can initialize the
    current_app context variable for global access to the application instance.

    Example:
        from pydantic_settings import BaseSettings

        class AppSettings(BaseSettings):
            DEBUG: bool = False
            DATABASE_URL: str = "sqlite:///./test.db"

        app = FastApp(setting=AppSettings())
        # Access setting via current_app.setting

    并发约束：
    - **单例（通过 ``__new__``）**：一个进程内全局一个 FastApp 实例。
      多次 ``FastApp(...)`` 构造返回同一个对象，第二次起的 kwargs 被忽略。
    - **初始化非原子**：``_is_initialized`` 判断 + 赋值不在锁内。
      严格来说同一进程并发构造会有 race，但实际只有应用启动时构造一次，
      这个窗口不是问题。**绝不要在请求处理中构造 FastApp**。
    - **测试隔离**：测试要换配置时用 ``FastApp.reset_instance()`` 清除单例，
      再重新构造。

    重复构造时的行为：
    - 第一次 ``FastApp(setting=x)``：完整初始化。
    - 第二次 ``FastApp(setting=y)``：返回已有实例，``y`` 被丢弃，不报错。
      **不要**依赖第二次构造来换配置。
    """

    _instance: Optional["FastApp"] = None
    _is_initialized: bool = False
    setting: BaseSettings

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._is_initialized = False
        return cls._instance
    
    @classmethod
    def reset_instance(cls):
        """Reset the singleton instance. Useful for testing."""
        cls._instance = None
    
    def __init__(self, setting: Optional[SettingT] = None, *args, **kwargs):
        if not self._is_initialized:
            # Only disable docs if not explicitly provided by user
            if 'docs_url' not in kwargs:
                kwargs['docs_url'] = None
            if 'redoc_url' not in kwargs:
                kwargs['redoc_url'] = None
            if 'openapi_url' not in kwargs:
                kwargs['openapi_url'] = None
            super().__init__(*args, **kwargs)
            self.setting = setting if setting is not None else BaseSettings()
            current_app.set_app(self)
            self._is_initialized = True
        else:
            # Even if already initialized, ensure current_app is set
            # This handles cases where reset_app() was called but instance still exists
            current_app.set_app(self)

    def mount(self, path: str, app: ASGIApp, name: Optional[str] = None):
        """Mount an ASGI application at the specified path."""
        if hasattr(app, "setting"):
            app.setting = self.setting
        super().mount(path, app, name)
        
    # Keys containing these substrings are considered sensitive
    _SENSITIVE_KEY_PATTERNS = {"password", "secret", "token", "api_key", "private_key"}

    def set_environ(self, exclude_sensitive: bool = False):
        """
        Set environment variables from setting.

        Args:
            exclude_sensitive: If True, skip keys containing sensitive patterns
                (password, secret, token, api_key, private_key). Default False
                for backward compatibility.
        """
        for key, value in self.setting.model_dump().items():
            env_key = key.upper()
            if exclude_sensitive and any(p in env_key.lower() for p in self._SENSITIVE_KEY_PATTERNS):
                continue
            if isinstance(value, str):
                os.environ[env_key] = value
            elif isinstance(value, (int, float, bool)):
                os.environ[env_key] = str(value)
            elif value is None:
                os.environ[env_key] = ""
    
    def set_app_root_path(self, app_file: str):
        """Set the application root path based on the app file location."""
        self.app_root_path = os.path.dirname(os.path.abspath(app_file))

    def add_exception_handler(self, exc_class_or_status_code, handler):
        """Add an exception handler to the application."""
        super().add_exception_handler(exc_class_or_status_code, handler)

class FastModule(FastAPI):
    """
    FastAPI sub-application module class.

    Used to create independent sub-application modules, where each module
    can have its own routes, middleware, and configuration. Supports
    automatic Resource registration to simplify module management.
    """

    def __init__(self, name: str, *args, **kwargs):
        """
        Initialize FastModule.

        Args:
            name: Module name used to identify the module. Must match the
                module name in @register_resource(module=...).
            *args, **kwargs: Additional arguments passed to FastAPI.
        """
        # Only disable docs if not explicitly provided by user
        if 'docs_url' not in kwargs:
            kwargs['docs_url'] = None
        if 'redoc_url' not in kwargs:
            kwargs['redoc_url'] = None
        if 'openapi_url' not in kwargs:
            kwargs['openapi_url'] = None
        
        super().__init__(*args, **kwargs)

        self.module_name = name
        self._router: Optional[Any] = None  # Store the unique ResourceRouter instance

        # Get setting from current_app
        try:
            self.setting = current_app.setting
        except RuntimeError:
            raise RuntimeError(
                "FastApp instance must be created and set as current_app before creating FastModule"
            )
    
    def create_router(self, prefix: str = "", **kwargs):
        """
        Create a ResourceRouter and associate it with this module.

        A FastModule can only have one ResourceRouter. If a router has
        already been created, calling this method again will raise a ValueError.

        Args:
            prefix: Route prefix.
            **kwargs: Additional arguments passed to ResourceRouter.

        Returns:
            ResourceRouter: The created ResourceRouter instance.

        Example:
            router = module.create_router(prefix="/api/v1")
        """
        from tomskit.server.resource import ResourceRouter
        
        if self._router is not None:
            raise ValueError(
                f"FastModule '{self.module_name}' already has a router. "
                "A FastModule can only have one ResourceRouter. "
                "If you need multiple routers, create multiple FastModule instances."
            )
        
        router = ResourceRouter(app=self, prefix=prefix, **kwargs)
        self._router = router
        return router
    
    def auto_register_resources(self):
        """
        Automatically register all Resources marked for this module.

        This method searches ResourceRegistry for all Resources marked with
        the current module name and automatically registers them to this
        module's ResourceRouter.

        If the router does not exist, it will be automatically created
        (using default prefix="").

        Example:
            module = FastModule(name="files")
            module.auto_register_resources()  # Auto-register all Resources marked for "files" module

            # Or create router first, then auto-register
            module = FastModule(name="files")
            router = module.create_router(prefix="/api/v1")
            module.auto_register_resources()  # Register to the created router
        """
        from tomskit.server.resource import ResourceRegistry

        # Get or create router
        if self._router is None:
            self._router = self.create_router()

        # Get all Resources for this module from registry
        resources = ResourceRegistry.get_module_resources(self.module_name)

        if not resources:
            # If no Resources are registered, issue a warning but don't error (allows manual registration)
            warnings.warn(
                f"Module '{self.module_name}' has no Resources registered via @register_resource. "
                f"Ensure Resource classes use @register_resource(module='{self.module_name}', ...) decorator.",
                UserWarning,
            )
            return

        # Register all Resources
        for resource_info in resources:
            self._router.add_resource(
                resource_cls=resource_info.resource_cls,
                path=resource_info.path,
                tags=resource_info.tags if resource_info.tags else None,
            )

        # Include router after all resources are registered
        # This ensures router has routes before being included
        self.include_router(self._router)
    
    def setup_cors(
        self,
        allow_origins: Optional[list[str]] = None,
        allow_credentials: bool = True,
        allow_methods: Optional[list[str]] = None,
        allow_headers: Optional[list[str]] = None,
        expose_headers: Optional[list[str]] = None,
    ):
        """
        Configure CORS middleware.

        Args:
            allow_origins: List of allowed origins for cross-origin requests.
            allow_credentials: Whether to allow credentials in cross-origin requests.
            allow_methods: List of allowed HTTP methods.
            allow_headers: List of allowed request headers.
            expose_headers: List of response headers exposed to clients.

        Example:
            module.setup_cors(
                allow_origins=["http://localhost:3000"],
                allow_credentials=True,
                allow_methods=["GET", "POST", "PUT", "DELETE"],
            )
        """
        from fastapi.middleware.cors import CORSMiddleware
        
        self.add_middleware(
            CORSMiddleware,
            allow_origins=allow_origins or [],
            allow_credentials=allow_credentials,
            allow_methods=allow_methods or ["GET", "PUT", "POST", "DELETE", "OPTIONS", "PATCH"],
            allow_headers=allow_headers or ["Content-Type", "Authorization"],
            expose_headers=expose_headers or [],
        )
        
    def add_exception_handler(self, exc_class_or_status_code, handler):
        """Add an exception handler to the module."""
        super().add_exception_handler(exc_class_or_status_code, handler)
