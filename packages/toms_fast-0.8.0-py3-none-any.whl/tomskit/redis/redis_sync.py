"""
Redis 同步客户端模块

支持单机、Sentinel、Cluster 三种模式。
兼容 dict 和 RedisConfig 两种配置传入方式。
"""
from typing import Any, Union

from redis import Redis, Connection, ConnectionPool, Sentinel, SSLConnection, RedisCluster
from redis.cluster import ClusterNode

from tomskit.redis.config import RedisConfig
from tomskit.redis.redis_pool import _parse_host_port

# 同步 Redis 客户端默认连接池大小。
# 之前硬编码为 1 会导致 Celery worker 并发任务串行化等待，严重瓶颈。
# 32 足够覆盖大多数 worker 并发场景，用户可通过 REDIS_MAX_CONNECTIONS 配置覆盖。
DEFAULT_SYNC_MAX_CONNECTIONS = 32


def _get(config: Any, key: str, default: Any = None) -> Any:
    """Unified config accessor: supports both RedisConfig (attr) and dict."""
    if isinstance(config, dict):
        return config.get(key, default)
    return getattr(config, key, default)


def redis_sync_client(config: RedisConfig | dict) -> Redis | None:
    """
    Create a synchronous Redis client.

    Args:
        config: RedisConfig instance (recommended) or legacy dict.

    Returns:
        Redis client instance, or None on failure.
    """
    redis: Redis | None = None

    connection_class: type[Union[Connection, SSLConnection]] = Connection
    if _get(config, "REDIS_USE_SSL"):
        connection_class = SSLConnection

    max_connections = (
        _get(config, "REDIS_MAX_CONNECTIONS", DEFAULT_SYNC_MAX_CONNECTIONS)
        or DEFAULT_SYNC_MAX_CONNECTIONS
    )

    redis_params = {
        "username": _get(config, "REDIS_USERNAME"),
        "password": _get(config, "REDIS_PASSWORD"),
        "db": _get(config, "REDIS_DB"),
        "encoding": "utf-8",
        "encoding_errors": "strict",
        "decode_responses": True,
        "max_connections": max_connections,
    }

    if _get(config, "REDIS_USE_SENTINEL"):
        sentinels_raw = _get(config, "REDIS_SENTINELS") or ""
        sentinel_hosts = [
            _parse_host_port(node, "REDIS_SENTINELS")
            for node in sentinels_raw.split(",")
            if node.strip()
        ]
        if not sentinel_hosts:
            raise ValueError("REDIS_SENTINELS 解析后无有效节点")

        sentinel = Sentinel(
            sentinel_hosts,
            sentinel_kwargs={
                "socket_timeout": _get(config, "REDIS_SENTINEL_SOCKET_TIMEOUT", 0.1),
                "username": _get(config, "REDIS_SENTINEL_USERNAME"),
                "password": _get(config, "REDIS_SENTINEL_PASSWORD"),
            },
        )
        redis = sentinel.master_for(
            _get(config, "REDIS_SENTINEL_SERVICE_NAME"), **redis_params
        )
    elif _get(config, "REDIS_USE_CLUSTERS") or _get(config, "REDIS_USE_CLUSTER"):
        clusters_raw = _get(config, "REDIS_CLUSTERS") or ""
        nodes = [
            ClusterNode(host=host, port=port)
            for host, port in (
                _parse_host_port(node, "REDIS_CLUSTERS")
                for node in clusters_raw.split(",")
                if node.strip()
            )
        ]
        if not nodes:
            raise ValueError("REDIS_CLUSTERS 解析后无有效节点")

        redis_params.update({
            "password": _get(config, "REDIS_CLUSTERS_PASSWORD"),
        })
        redis = RedisCluster(  # type: ignore
            startup_nodes=nodes,
            **redis_params,
        )
    else:
        redis_params.update({
            "host": _get(config, "REDIS_HOST"),
            "port": _get(config, "REDIS_PORT"),
            "connection_class": connection_class,
        })
        pool = ConnectionPool(**redis_params)
        redis = Redis(connection_pool=pool)

    return redis
