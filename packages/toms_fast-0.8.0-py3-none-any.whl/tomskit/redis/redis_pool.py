"""
Redis 扩展模块
"""
import ssl
from typing import Any, Union, Optional, TypeVar, Generic, TYPE_CHECKING
from redis.asyncio import Connection, ConnectionPool, Redis, Sentinel, SSLConnection, RedisCluster
from redis.asyncio.cluster import ClusterNode
from tomskit.redis.config import RedisConfig

T = TypeVar("T", bound=Redis)


def _get_redis_ssl_context(settings: RedisConfig) -> ssl.SSLContext | None:
    """Build an ``ssl.SSLContext`` from *settings*, or return ``None`` when SSL is disabled."""
    if not settings.REDIS_USE_SSL:
        return None

    cert_reqs_map = {
        "CERT_NONE": ssl.CERT_NONE,
        "CERT_OPTIONAL": ssl.CERT_OPTIONAL,
        "CERT_REQUIRED": ssl.CERT_REQUIRED,
    }
    cert_reqs = cert_reqs_map.get(settings.REDIS_SSL_CERT_REQS, ssl.CERT_NONE)

    ctx = ssl.create_default_context(cafile=settings.REDIS_SSL_CA_CERTS)
    ctx.check_hostname = cert_reqs == ssl.CERT_REQUIRED
    ctx.verify_mode = cert_reqs

    # 客户端双向 mTLS 证书
    if settings.REDIS_SSL_CERTFILE and settings.REDIS_SSL_KEYFILE:
        ctx.load_cert_chain(certfile=settings.REDIS_SSL_CERTFILE, keyfile=settings.REDIS_SSL_KEYFILE)

    return ctx


def _parse_host_port(node: str, context: str) -> tuple[str, int]:
    """解析 ``host:port`` 格式的单个节点字符串。

    用 ``rpartition`` 按**最后一个冒号**切分，host 部分可含冒号（兼容 IPv6）。

    Args:
        node: 形如 ``"host:port"`` 的字符串。
        context: 出错时的上下文标签（如 ``"REDIS_SENTINELS"``），便于用户定位配置项。

    Returns:
        ``(host, port)`` 元组。

    Raises:
        ValueError: 格式错误时抛出带明确上下文的错误（空条目 / 缺冒号 / 空 host / 端口非整数 / 端口越界）。
    """
    node = node.strip()
    if not node:
        raise ValueError(f"{context}: 空节点条目（可能是多余的逗号）")
    if ":" not in node:
        raise ValueError(f"{context}: 节点 '{node}' 缺少端口号（格式应为 host:port）")
    host, _, port_str = node.rpartition(":")
    host = host.strip()
    port_str = port_str.strip()
    if not host:
        raise ValueError(f"{context}: 节点 '{node}' 的 host 为空")
    try:
        port = int(port_str)
    except ValueError:
        raise ValueError(
            f"{context}: 节点 '{node}' 的端口 '{port_str}' 不是有效整数"
        ) from None
    if not (1 <= port <= 65535):
        raise ValueError(
            f"{context}: 节点 '{node}' 的端口 {port} 超出合法范围 (1-65535)"
        )
    return host, port


def _get_redis_ssl_params(settings: RedisConfig) -> dict[str, Any]:
    """Return flat SSL keyword arguments consumed by ``redis-py`` connection classes."""
    if not settings.REDIS_USE_SSL:
        return {}

    cert_reqs_map = {
        "CERT_NONE": ssl.CERT_NONE,
        "CERT_OPTIONAL": ssl.CERT_OPTIONAL,
        "CERT_REQUIRED": ssl.CERT_REQUIRED,
    }

    return {
        "ssl": True,
        "ssl_cert_reqs": cert_reqs_map.get(settings.REDIS_SSL_CERT_REQS, ssl.CERT_NONE),
        "ssl_ca_certs": settings.REDIS_SSL_CA_CERTS,
        "ssl_certfile": settings.REDIS_SSL_CERTFILE,
        "ssl_keyfile": settings.REDIS_SSL_KEYFILE,
    }


class RedisClientWrapper(Generic[T]):
    """
    Redis 客户端包装器。

    **类型使用约定**：
    - **Redis 操作**（set/get/hset/delete 等 200+ 方法）通过 ``__getattr__`` 代理到
      内部 ``_client``。**建议**从模块通过 ``from tomskit.redis import redis_client``
      获取全局实例，使用时 IDE 会把它视为 ``Redis`` 实例（见下方 TYPE_CHECKING 伪装），
      拥有完整类型提示和自动补全。
    - **生命周期方法**（``initialize`` / ``shutdown`` / ``set_client``）**必须用类名调用**：

      .. code-block:: python

          RedisClientWrapper.initialize(config)   # ✅
          await RedisClientWrapper.shutdown()     # ✅
          # redis_client.initialize(config)       # ❌ IDE 看不到（类型被伪装成 Redis）
    """

    def __init__(self) -> None:
        self._client: Optional[T] = None

    def __getattr__(self, item: str) -> Any:
        """代理到内部 redis 客户端的属性访问。

        返回类型为 Any —— 无法在单一签名里精确表达"任何 Redis 方法"。
        模块末尾通过 TYPE_CHECKING 给 ``redis_client`` 注入 Redis 类型，解决 IDE 推断问题。
        """
        if self._client is None:
            raise RuntimeError("Redis client is not initialized. Call initialize first.")
        return getattr(self._client, item)

    def set_client(self, client: T) -> None:
        if self._client is None:
            self._client = client

    @staticmethod
    def initialize(settings: RedisConfig) -> None:
        global redis_client
        connection_class: type[Union[Connection, SSLConnection]] = Connection
        if settings.REDIS_USE_SSL:
            connection_class = SSLConnection

        # 通用连接参数（单机 & Sentinel 共用）
        redis_params: dict[str, Any] = {
            "username": settings.REDIS_USERNAME,
            "password": settings.REDIS_PASSWORD,
            "db": settings.REDIS_DB,
            "encoding": "utf-8",
            "encoding_errors": "strict",
            "decode_responses": True,
            "max_connections": settings.REDIS_MAX_CONNECTIONS,
        }
        
        if settings.REDIS_USE_SENTINEL:
            if not settings.REDIS_SENTINELS:
                raise ValueError("REDIS_SENTINELS must be set when REDIS_USE_SENTINEL is True")
            if not settings.REDIS_SENTINEL_SERVICE_NAME:
                raise ValueError("REDIS_SENTINEL_SERVICE_NAME must be set when REDIS_USE_SENTINEL is True")
            
            sentinel_hosts = [
                _parse_host_port(node, "REDIS_SENTINELS")
                for node in settings.REDIS_SENTINELS.split(",")
                if node.strip()   # 跳过空条目（如 "a:1,,b:2" 这种末尾/中间空值）
            ]
            if not sentinel_hosts:
                raise ValueError("REDIS_SENTINELS 解析后无有效节点")

            sentinel_kwargs: dict[str, Any] = {
                "socket_timeout": settings.REDIS_SENTINEL_SOCKET_TIMEOUT or 0.1,
                "username": settings.REDIS_SENTINEL_USERNAME,
                "password": settings.REDIS_SENTINEL_PASSWORD,
            }

            # Sentinel 自身连接也走 SSL
            ssl_context = _get_redis_ssl_context(settings)
            if ssl_context is not None:
                sentinel_kwargs["ssl"] = True
                sentinel_kwargs["ssl_context"] = ssl_context

            sentinel = Sentinel(
                sentinel_hosts,
                sentinel_kwargs=sentinel_kwargs,
            )

            # master_for 连接同样需要 SSL 参数
            ssl_params = _get_redis_ssl_params(settings)
            redis_params.update(ssl_params)

            master = sentinel.master_for(settings.REDIS_SENTINEL_SERVICE_NAME, **redis_params)
            redis_client.set_client(master)
        elif settings.REDIS_USE_CLUSTERS:
            if not settings.REDIS_CLUSTERS:
                raise ValueError("REDIS_CLUSTERS must be set when REDIS_USE_CLUSTERS is True")
            
            nodes = [
                ClusterNode(host=host, port=port)
                for host, port in (
                    _parse_host_port(node, "REDIS_CLUSTERS")
                    for node in settings.REDIS_CLUSTERS.split(",")
                    if node.strip()
                )
            ]
            if not nodes:
                raise ValueError("REDIS_CLUSTERS 解析后无有效节点")

            # RedisCluster 不支持 db（固定 db 0）和 max_connections，
            # 需要使用 max_connections_per_node 代替
            cluster_params: dict[str, Any] = {
                "username": settings.REDIS_USERNAME,
                "password": settings.REDIS_CLUSTERS_PASSWORD,
                "encoding": "utf-8",
                "encoding_errors": "strict",
                "decode_responses": True,
                "max_connections_per_node": settings.REDIS_MAX_CONNECTIONS,
            }

            # Cluster 模式 SSL
            ssl_params = _get_redis_ssl_params(settings)
            cluster_params.update(ssl_params)

            cluster = RedisCluster(
                startup_nodes=nodes,
                **cluster_params
            )
            redis_client.set_client(cluster)  # type: ignore
        else:
            redis_params.update(
                {
                    "host": settings.REDIS_HOST,
                    "port": settings.REDIS_PORT,
                    "max_connections": settings.REDIS_MAX_CONNECTIONS,
                    "connection_class": connection_class,
                }
            )

            # 单机模式 SSL 参数注入到 ConnectionPool
            if settings.REDIS_USE_SSL:
                ssl_params = _get_redis_ssl_params(settings)
                redis_params.update(ssl_params)

            pool = ConnectionPool(**redis_params)
            redis_client.set_client(Redis(connection_pool=pool))

    @staticmethod
    async def shutdown() -> None:
        global redis_client
        if redis_client._client is not None:
            await redis_client._client.aclose()
            redis_client._client = None

if TYPE_CHECKING:
    # 伪装给 IDE / pyright / mypy：使用方看到的 redis_client 是 Redis 实例，
    # 拥有 set/get/hset/scan 等全部方法的类型提示和自动补全。
    # 运行时仍是 RedisClientWrapper，通过 __getattr__ 代理（见类 docstring）。
    redis_client: Redis
else:
    redis_client: RedisClientWrapper[Redis] = RedisClientWrapper()
