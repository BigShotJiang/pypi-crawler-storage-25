import asyncio
import functools


class cached_async_property:
    def __init__(self, func):
        self.func = func
        self.attr_name = f"_cached_{func.__name__}"
        self.lock_name = f"_lock_{func.__name__}"
        functools.update_wrapper(self, func)

    def __get__(self, instance, owner):
        if instance is None:
            return self

        async def wrapper():
            if not hasattr(instance, self.lock_name):
                setattr(instance, self.lock_name, asyncio.Lock())
            async with getattr(instance, self.lock_name):
                if not hasattr(instance, self.attr_name):
                    value = await self.func(instance)
                    setattr(instance, self.attr_name, value)
            return getattr(instance, self.attr_name)

        return wrapper()

    def __delete__(self, instance):
        try:
            delattr(instance, self.attr_name)
        except AttributeError:
            pass
