"""
SQLAlchemy Model 序列化器

将 SQLAlchemy Model 序列化为 Pydantic BaseModel，支持：
- 嵌套关系（一对一、一对多、多对多）
- 异步属性（async property）
- 分页查询结果

使用示例：
    from tomskit.sqlalchemy import ModelSerializer, db
    from app.models.user import User
    from app.controllers.user.schemas import UserResponse
    
    # 单个对象序列化（支持嵌套）
    user = await db.session.get(User, user_id)
    result = await ModelSerializer.serialize(user, UserResponse)
    
    # 列表序列化
    users = await db.session.scalars(select(User))
    result = await ModelSerializer.serialize_list(users.all(), UserResponse)
    
    # 分页查询序列化
    pagination = await db.paginate(select(User), page=1, per_page=10)
    result = await ModelSerializer.serialize_pagination(pagination, UserResponse)
    
注意：
    - 嵌套关系建议使用 selectinload/joinedload 预加载，避免 N+1 查询
    - Schema 需要设置 model_config = ConfigDict(from_attributes=True)
"""

import inspect
import logging
import types
from typing import Any, Generic, Sequence, Type, TypeVar, Union, get_origin, get_args

from pydantic import BaseModel
from pydantic_core import PydanticUndefined

from tomskit.sqlalchemy.pagination import Pagination

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)


class PaginationResponse(BaseModel, Generic[T]):
    """分页响应模型"""
    page: int
    per_page: int
    total: int
    pages: int
    has_prev: bool
    has_next: bool
    items: list[T]


class ModelSerializer:
    """
    SQLAlchemy Model 序列化器
    
    将 SQLAlchemy ORM 对象转换为 Pydantic BaseModel。
    支持嵌套关系、异步属性、列表和分页。
    """
    
    @classmethod
    async def serialize(cls, obj: Any, schema: Type[T]) -> T | None:
        """
        将单个 SQLAlchemy Model 对象序列化为 Pydantic BaseModel
        
        支持嵌套关系和异步属性。
        
        Args:
            obj: SQLAlchemy Model 对象
            schema: 目标 Pydantic BaseModel 类
            
        Returns:
            序列化后的 Pydantic 模型实例，如果 obj 为 None 则返回 None
            
        Example:
            class DepartmentSchema(BaseModel):
                id: str
                name: str
                children: list[DepartmentSchema] = []
                model_config = ConfigDict(from_attributes=True)
            
            class UserSchema(BaseModel):
                id: str
                name: str
                department: DepartmentSchema | None = None
                model_config = ConfigDict(from_attributes=True)
            
            user = await db.session.get(User, user_id)
            result = await ModelSerializer.serialize(user, UserSchema)
        """
        if obj is None:
            return None
        
        # 如果已经是目标类型，直接返回
        if isinstance(obj, schema):
            return obj
        
        data: dict[str, Any] = {}
        
        for field_name, field_info in schema.model_fields.items():
            # 获取值（支持异步属性，安全处理懒加载异常）
            value = await cls._get_value(obj, field_name)
            
            # 解析值（处理嵌套模型、列表等）
            resolved_value = await cls._resolve_value(value, field_info.annotation)
            
            # 处理默认值：如果值为 None 且字段有非 None 默认值，跳过让 Pydantic 使用默认值
            if resolved_value is None:
                has_default = field_info.default is not PydanticUndefined
                has_default_factory = field_info.default_factory is not None
                default_is_none = has_default and field_info.default is None
                if (has_default or has_default_factory) and not default_is_none:
                    continue
            
            data[field_name] = resolved_value
        
        return schema.model_validate(data)
    
    @classmethod
    async def serialize_list(
        cls, 
        items: Sequence[Any] | list[Any], 
        schema: Type[T]
    ) -> list[T]:
        """
        将 SQLAlchemy Model 对象列表序列化为 Pydantic BaseModel 列表
        
        注意：使用顺序执行而非并发，因为 SQLAlchemy AsyncSession 不支持并发访问。
        如果需要更高性能，请确保关系已通过 selectinload/joinedload 预加载。
        
        Args:
            items: SQLAlchemy Model 对象列表
            schema: 目标 Pydantic BaseModel 类
            
        Returns:
            序列化后的 Pydantic 模型列表
            
        Example:
            users = await db.session.scalars(select(User))
            result = await ModelSerializer.serialize_list(users.all(), UserSchema)
        """
        if not items:
            return []
        
        items_list = list(items) if not isinstance(items, list) else items
        
        results = []
        for item in items_list:
            serialized = await cls.serialize(item, schema)
            if serialized is not None:
                results.append(serialized)
        
        return results
    
    @classmethod
    async def serialize_pagination(
        cls,
        pagination: Pagination, 
        schema: Type[T]
    ) -> PaginationResponse[T]:
        """
        将分页查询结果序列化为分页响应
        
        Args:
            pagination: db.paginate() 返回的 Pagination 对象
            schema: 数据项的 Pydantic BaseModel 类
            
        Returns:
            PaginationResponse 对象，包含分页信息和序列化后的数据
            
        Example:
            pagination = await db.paginate(select(User), page=1, per_page=10)
            result = await ModelSerializer.serialize_pagination(pagination, UserSchema)
        """
        items = await cls.serialize_list(pagination.items, schema)
        
        return PaginationResponse[schema](  # type: ignore
            page=pagination.page,
            per_page=pagination.per_page,
            total=pagination.total or 0,
            pages=pagination.pages,
            has_prev=pagination.has_prev,
            has_next=pagination.has_next,
            items=items,
        )
    
    @classmethod
    async def serialize_pagination_dict(
        cls,
        pagination: Pagination, 
        schema: Type[T]
    ) -> dict[str, Any]:
        """
        将分页查询结果序列化为字典格式
        
        Args:
            pagination: db.paginate() 返回的 Pagination 对象
            schema: 数据项的 Pydantic BaseModel 类
            
        Returns:
            包含分页信息和序列化后数据的字典
        """
        items = await cls.serialize_list(pagination.items, schema)
        
        return {
            "page": pagination.page,
            "per_page": pagination.per_page,
            "total": pagination.total or 0,
            "pages": pagination.pages,
            "has_prev": pagination.has_prev,
            "has_next": pagination.has_next,
            "items": [item.model_dump() for item in items],
        }
    
    @staticmethod
    async def _get_value(obj: Any, key: str) -> Any:
        """
        从对象获取属性值，支持异步属性和异步方法
        
        处理三种异步场景：
        1. async def method(self) — iscoroutinefunction，需要先调用再 await
        2. @property 返回协程   — isawaitable，直接 await
        3. 普通同步属性/property — 直接返回值
        
        安全处理 SQLAlchemy 懒加载异常（MissingGreenlet）。
        
        Args:
            obj: 数据源对象
            key: 属性名
            
        Returns:
            属性值（异步属性/方法会自动 await）
        """
        if obj is None:
            return None
        
        try:
            value = getattr(obj, key)
            
            # 场景 1: async def method(self) — 无参数的异步方法
            # getattr 返回 bound method，不是 coroutine
            # 需要先调用 value() 得到 coroutine，再 await
            if inspect.iscoroutinefunction(value):
                value = await value()
            
            # 场景 2: @property 返回 coroutine 或其他 awaitable
            elif inspect.isawaitable(value):
                value = await value
            
            return value
        except (AttributeError, TypeError):
            return None
        except Exception as e:
            # 捕获 SQLAlchemy MissingGreenlet 等懒加载异常
            # 未预加载的关系返回 None，不中断序列化
            logger.debug(
                "获取属性 '%s' 失败 (%s: %s)，可能需要 selectinload/joinedload 预加载",
                key, type(e).__name__, e
            )
            return None
    
    @classmethod
    async def _resolve_value(cls, value: Any, type_annotation: Any) -> Any:
        """
        解析值，处理嵌套模型、列表等
        
        Args:
            value: 原始值
            type_annotation: 类型注解
            
        Returns:
            解析后的值
        """
        # 处理协程
        if inspect.isawaitable(value):
            value = await value
        
        if value is None:
            return None
        
        if type_annotation is None:
            return value
        
        origin = get_origin(type_annotation)
        args = get_args(type_annotation)
        
        # 处理 Optional[T] / Union[T, None] / T | None
        if cls._is_union_type(origin):
            non_none_args = [arg for arg in args if arg is not type(None)]
            if non_none_args:
                type_annotation = non_none_args[0]
                origin = get_origin(type_annotation)
                args = get_args(type_annotation)
        
        # 处理 list[T]
        if origin is list or (origin is None and type_annotation is list):
            # 注意：str 也是 Sequence，但不应该被当作列表处理
            if isinstance(value, str):
                return value
            if not isinstance(value, (list, tuple)):
                try:
                    value = list(value)
                except (TypeError, ValueError):
                    return value
            
            if not value:
                return []
            
            inner_type = args[0] if args else None
            
            # 如果内部类型是 BaseModel，递归序列化
            if inner_type and isinstance(inner_type, type) and issubclass(inner_type, BaseModel):
                return await cls.serialize_list(value, inner_type)
            
            return list(value) if not isinstance(value, list) else value
        
        # 处理嵌套 BaseModel
        if isinstance(type_annotation, type) and issubclass(type_annotation, BaseModel):
            return await cls.serialize(value, type_annotation)
        
        return value
    
    @staticmethod
    def _is_union_type(origin: Any) -> bool:
        """判断是否是 Union 类型（包括 Optional 和 X | Y 语法）"""
        if origin is Union:
            return True
        # Python 3.10+ 的 X | Y 语法
        if hasattr(types, "UnionType") and origin is types.UnionType:
            return True
        return False
