"""Known linux file enricher"""

from json import loads

from ..atom import Other
from ..helper.asyncpg import (
    asyncpg_cleanup_ctx_impl,
    asyncpg_ctx_connection,
    asyncpg_fetch,
)
from ..helper.logging import get_logger
from ..record import Record
from .base import (
    Enricher,
    EnricherConfig,
    EnricherContext,
    Feedback,
    register_enricher,
)

GUID = 'known_lin_file'
_LOGGER = get_logger('enricher.known_lin_file')
_QUERY = '''
SELECT tags FROM centrifuge.known_lin_file
WHERE (pattern = false AND filename = $1) OR (pattern = true AND $1 LIKE filename)
'''


async def _enrich_other_impl(
    ctx: EnricherContext, other: Other, _feedback: Feedback
) -> Record:
    tags = set()
    connection = asyncpg_ctx_connection(ctx)
    async for e_record in asyncpg_fetch(connection, _QUERY, other.value):
        tags.update(loads(e_record['tags']))
    return {'tags': list(sorted(tags))}


_FIELDS = ('tags',)
_ENRICHER = Enricher(
    guid=GUID,
    fields=_FIELDS,
    enrich_impl_map={
        Other: _enrich_other_impl,
    },
    cleanup_ctx_impl=asyncpg_cleanup_ctx_impl,
)
register_enricher(_ENRICHER, EnricherConfig)
