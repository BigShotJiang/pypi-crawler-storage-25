# forja-lakehouse

Plugin de [forja](https://pypi.org/project/forja/) que agrega la arquitectura **Lakehouse medallion** (bronze / silver / gold).

```bash
pip install forja forja-lakehouse
dfg init mi_proyecto --arch lakehouse
```

## Stack

- **DuckDB** — motor analítico local, lee Delta Lake y Parquet nativamente
- **Polars** — transformaciones rápidas con lazy evaluation
- **Delta Lake** — formato ACID para la capa silver
- **PyArrow** — serialización Parquet para la capa bronze
- **fsspec** — abstracción de storage (local, S3, GCS, Cloudflare R2)

## Arquitectura generada

```
src/<proyecto>/
├── bronze/     # ingesta cruda → Parquet
├── silver/     # limpieza con Polars → Delta Lake
├── gold/       # agregaciones con DuckDB → serving
├── pipelines/
│   ├── ingest.py     # dfg run ingest
│   ├── transform.py  # dfg run transform
│   └── serve.py      # dfg run serve
└── config/
    └── storage.py    # STORAGE_ROOT (local o s3://)
```

## Licencia

MIT
