"""Registro del plugin forja-lakehouse."""
from __future__ import annotations

from pathlib import Path

TEMPLATES_PATH = Path(__file__).parent / "templates"


def register(registry) -> None:
    """Registra la arquitectura lakehouse en forja."""
    registry.add_architecture(
        key="lakehouse",
        description="Lakehouse medallion — bronze (raw) / silver (clean) / gold (serving)",
        template_path=TEMPLATES_PATH / "lakehouse_project",
        _source="forja-lakehouse",
    )
