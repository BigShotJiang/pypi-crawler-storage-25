"""Bronze layer — ingesta de datos crudos.

Protocolo: lee datos de cualquier fuente y los escribe como Parquet en storage.
Sin transformaciones. Sin validaciones. Solo traer y persistir.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable, Protocol


class BronzeSource(Protocol):
    """Un BronzeSource trae datos crudos y los persiste en la capa bronze."""

    name: str

    def extract(self) -> Iterable[dict[str, Any]]:
        """Lee datos crudos del origen externo."""
        ...

    def load(self, records: Iterable[dict[str, Any]], dest: Path) -> Path:
        """Escribe los registros como Parquet en `dest`. Retorna la ruta creada."""
        ...
