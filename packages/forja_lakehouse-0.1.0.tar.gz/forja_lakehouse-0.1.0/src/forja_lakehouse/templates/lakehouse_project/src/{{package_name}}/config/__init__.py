"""Config: paths de storage y credenciales."""
from .storage import BRONZE_PATH, SILVER_PATH, GOLD_PATH, STORAGE_ROOT

__all__ = ["BRONZE_PATH", "SILVER_PATH", "GOLD_PATH", "STORAGE_ROOT"]
