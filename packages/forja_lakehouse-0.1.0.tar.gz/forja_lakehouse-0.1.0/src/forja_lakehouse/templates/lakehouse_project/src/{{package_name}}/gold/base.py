"""Gold layer — agregaciones y capa de serving.

Lee datos silver (Delta Lake) con DuckDB y genera las vistas/agregaciones
listas para consumir: BI, APIs, exporters, ML features.
"""
from __future__ import annotations

from pathlib import Path
from typing import Protocol

import duckdb


class GoldModel(Protocol):
    """Produce una vista gold a partir de datos silver."""

    name: str

    def build(self, conn: duckdb.DuckDBPyConnection) -> None:
        """Crea vistas o tablas gold en DuckDB. Se ejecuta en cada refresh."""
        ...

    def query(self, conn: duckdb.DuckDBPyConnection, sql: str):
        """Ejecuta una query sobre los datos gold."""
        ...


def get_connection(db_path: str = ":memory:") -> duckdb.DuckDBPyConnection:
    """Retorna una conexión DuckDB. Default: in-memory para exploración."""
    conn = duckdb.connect(db_path)
    conn.execute("INSTALL delta; LOAD delta;")
    return conn
