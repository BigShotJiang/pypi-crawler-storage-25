"""Pipelines del lakehouse.

ingest.py   — bronze: extrae y persiste datos crudos como Parquet
transform.py — silver: limpia con Polars → Delta Lake
serve.py    — gold: agrega con DuckDB → listo para consumir

Ejecutar:
    dfg run ingest
    dfg run transform
    dfg run serve
"""
