"""Silver: datos limpios, validados y normalizados (Delta Lake)."""
from .base import SilverTransform

__all__ = ["SilverTransform"]
