"""Gold: agregaciones y vistas listas para consumir (DuckDB)."""
from .base import GoldModel, get_connection

__all__ = ["GoldModel", "get_connection"]
