"""Bronze: datos crudos tal como llegan del origen."""
from .base import BronzeSource

__all__ = ["BronzeSource"]
