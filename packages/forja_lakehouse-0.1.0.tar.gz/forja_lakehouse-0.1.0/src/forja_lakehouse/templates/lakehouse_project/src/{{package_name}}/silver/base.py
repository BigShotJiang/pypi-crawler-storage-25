"""Silver layer — limpieza, validación y normalización.

Recibe datos de bronze (Parquet crudo), los limpia con Polars
y los escribe como Delta Lake con schema validado.
"""
from __future__ import annotations

from pathlib import Path
from typing import Protocol

import polars as pl


class SilverTransform(Protocol):
    """Transforma datos bronze → silver."""

    name: str

    def transform(self, df: pl.LazyFrame) -> pl.LazyFrame:
        """Limpia y normaliza. Retorna un LazyFrame listo para escribir."""
        ...

    def validate(self, df: pl.DataFrame) -> pl.DataFrame:
        """Valida el schema y constraints. Lanza error si falla."""
        ...
