"""forja-lakehouse — arquitectura medallion (bronze/silver/gold) para forja."""
__version__ = "0.1.0"
