"""Regression tests for CLI file validation."""

import tempfile
from pathlib import Path

import h5py

from h5tui.h5tui import check_file_validity


def test_empty_path_rejected(capsys):
    assert check_file_validity("") is False
    err = capsys.readouterr().out
    assert "No HDF5 file" in err


def test_missing_file_rejected_no_exception(capsys):
    path = tempfile.gettempdir() + "/h5tui_nonexistent_file_xyz.h5"
    assert Path(path).exists() is False
    assert check_file_validity(path) is False
    err = capsys.readouterr().out
    assert "not an existing file" in err


def test_non_hdf5_file_rejected(capsys):
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        f.write("not hdf5")
        p = f.name
    try:
        assert check_file_validity(p) is False
        err = capsys.readouterr().out
        assert "not a valid HDF5 file" in err
    finally:
        Path(p).unlink(missing_ok=True)


def test_valid_h5_accepted():
    with tempfile.NamedTemporaryFile(suffix=".h5", delete=False) as f:
        p = f.name
    try:
        with h5py.File(p, "w") as h5:
            h5.create_dataset("x", data=[1, 2, 3])
        assert check_file_validity(p) is True
    finally:
        Path(p).unlink(missing_ok=True)
