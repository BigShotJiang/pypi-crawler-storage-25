"""Unit tests for header path truncation (leading ellipsis + suffix)."""

from h5tui.h5tui import _ellipsis_h5_path_truncate_beginning


def test_short_path_unchanged():
    p = "/a/b/c"
    assert _ellipsis_h5_path_truncate_beginning(p, 80) == p


def test_long_path_fits_budget_and_prefixes_ellipsis():
    long = "/experiments/campaign_2024/site_north/building_a/normalized/fuzzy_demo_leaf"
    for budget in (40, 60, 80):
        out = _ellipsis_h5_path_truncate_beginning(long, budget)
        assert len(out) <= budget
        if len(long) > budget:
            assert out.startswith("...")


def test_root_only():
    assert _ellipsis_h5_path_truncate_beginning("/", 10) == "/"


def test_truncates_beginning_keeps_tail():
    long = (
        "/experiments/campaign_2024/site_north/building_a/lab_room_3/"
        "rack_2/instrument_cluster/channel_chain/preamp/digitizer/fifo/"
        "dsp_pipeline/filter_bank/fft_stage/peak_finder/calibration_run/"
        "temperature_compensated/pressure_compensated/final_stage/artifacts/"
        "exports/daily/session_morning/rep_03/burst_capture/windowed/"
        "segment_07/baseline_subtracted/normalized"
    )
    out = _ellipsis_h5_path_truncate_beginning(long, 80)
    assert len(out) <= 80
    assert out.startswith("...")
    assert long.endswith(out[len("...") :])
