def test_pass():
    assert 10 == 10


def test_fail():
    assert 10 == 9
