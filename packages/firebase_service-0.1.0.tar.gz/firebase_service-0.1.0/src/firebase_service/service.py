import json
import firebase_admin
from firebase_admin import credentials, db

# Load service account (firebase.json IS the service account)
with open("firebase.json", "r") as f:
    settings = json.load(f)

project_id = settings["project_id"]
database_url = f"https://{project_id}-default-rtdb.firebaseio.com/"

# Init once (prevent duplicate init crash)
if not firebase_admin._apps:
    cred = credentials.Certificate("firebase.json")
    firebase_admin.initialize_app(cred, {
        "databaseURL": database_url
    })


class FirebaseService:
    def __init__(self, path: str):
        self.ref = db.reference(path)

    # ---------------- ROOT SAFE HELPERS ----------------

    def _child(self, directory):
        return self.ref if directory in (None, "") else self.ref.child(str(directory))

    # ---------------- CORE METHODS ----------------

    def get(self, directory=None):
        return self._child(directory).get()

    def set(self, directory, value):
        self._child(directory).set(value)

    def remove(self, directory):
        self._child(directory).delete()

    def increment(self, directory, delta=1):
        ref = self._child(directory)

        def tx(current):
            if current is None:
                return delta
            if isinstance(current, (int, float)):
                return current + delta
            return current

        return ref.transaction(tx)

    def update(self, directory, callback):
        ref = self._child(directory)
        current = ref.get()
        new_value = callback(current)

        if new_value is not None:
            ref.set(new_value)

        return new_value

    def print(self, directory=None):
        value = self.get(directory)
        print(value)
        return value


# ---------------- EXAMPLE USAGE ----------------

if __name__ == "__main__":
    firebase = FirebaseService("test_node")

    firebase.set("counter", 0)
    print(firebase.get("counter"))

    firebase.increment("counter", 5)
    print(firebase.get("counter"))

    firebase.update("counter", lambda x: x * 2 if isinstance(x, (int, float)) else x)
    print(firebase.get("counter"))

    # ---------------- EMOTION SYSTEM ----------------

    emotion = FirebaseService("emotion_node")

    # ROOT value now works properly
    emotion.set(None, "neutral")

    def emotion_def(state):
        if state == "angry":
            return "neutral"
        elif state == "neutral":
            return "happy"
        elif state == "happy":
            return "sad"
        elif state == "sad":
            return "angry"
        else:
            return "neutral"

    emotion.update(None, emotion_def)
    emotion.print(None)

    emotion.update(None, emotion_def)
    emotion.print(None)

    emotion.update(None, emotion_def)
    emotion.print(None)

    emotion.update(None, emotion_def)
    emotion.print(None)