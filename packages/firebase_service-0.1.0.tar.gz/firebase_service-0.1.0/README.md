# Firebase Service

Simple Python wrapper for Firebase Realtime Database using `firebase-admin`.

## Install

```bash
pip install firebase-service
```

---

## Setup

1. Create a Firebase project
2. Generate a **service account JSON**
3. Place it in your project root as:

```
firebase.json
```

> The package loads `firebase.json` from the **current working directory (CWD)**.

---

## Usage

```python
from firebase_service import FirebaseService

db = FirebaseService("test_node")

db.set("counter", 0)
print(db.get("counter"))

db.increment("counter", 5)
print(db.get("counter"))
```

---

## Root Values

You can use `None` to access the root of your node:

```python
db.set(None, "hello")
print(db.get(None))
```

---

## Methods

### `get(directory=None)`

Get data from a path.

### `set(directory, value)`

Set a value at a path.

### `delete(directory)`

Delete a value.

### `increment(directory, delta=1)`

Atomically increment a number.

### `update(directory, callback)`

Update a value using a function.

```python
db.update("counter", lambda x: x * 2)
```

---

## Example

```python
from firebase_service import FirebaseService

emotion = FirebaseService("emotion_node")

emotion.set(None, "neutral")

def next_state(state):
    order = ["neutral", "happy", "sad", "angry"]
    return order[(order.index(state) + 1) % len(order)] if state in order else "neutral"

emotion.update(None, next_state)
print(emotion.get(None))
```

---

## Notes

* Requires `firebase.json` in the working directory
* Uses Firebase Admin SDK
* Designed for simple scripts and small backends

---

## License

MIT
