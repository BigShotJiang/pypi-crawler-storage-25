"""Driver for the culture -> cultureagent migration.

Usage:
    python _migrate_driver.py --phase {a,b} --culture-root ../culture \
        --output-receipt migration-receipt.json

Reads a manifest of (source_path, dest_path) pairs for the chosen phase,
copies each file, applies the rewrite passes, and emits a JSON receipt
with per-file stats:
    [
      {
        "src": "culture/clients/shared/attention.py",
        "dst": "cultureagent/clients/shared/attention.py",
        "src_sha": "<git blob sha>",
        "import_edits": 4,
        "string_edits": 0,
        "telemetry_count_src": 0,
        "telemetry_count_dst": 0,
        "diff_lines": 4
      },
      ...
    ]

Fails non-zero if telemetry_count_src != telemetry_count_dst for any
file (parity-check guarantee from spec section 6.1, rule 3).
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

from _migrate_rewriter import (
    rewrite_module,
    rewrite_strings,
    telemetry_namespace_count,
)

ALLOWLIST = (
    "culture.clients.shared",
    "culture.clients.claude",
    "culture.clients.codex",
    "culture.clients.copilot",
    "culture.clients.acp",
    # `culture.clients.BACKEND` is a literal placeholder used by the
    # reference impl at packages/agent-harness/ — citation-pattern consumers
    # substitute the actual backend name. Rewrite symmetrically so the
    # placeholder semantics survive the migration.
    "culture.clients.BACKEND",
    "culture.aio",
    "culture.pidfile",
    "culture._constants",
    "culture.constants",
    "culture.protocol",
    "culture.telemetry",
    "culture.cli.shared.constants",
    # `culture.cli.agent` and `culture.config` are imported only inside three
    # `test_daemon_config.py` tests that bridge culture's operator CLI to
    # the daemon config. They rewrite mechanically; the affected tests are
    # marked skip post-migration (modules don't exist on cultureagent side).
    "culture.cli.agent",
    "culture.config",
)


# Imports to strip from source files entirely (lines deleted before rewrite).
# These are out-of-scope re-exports that harness code doesn't use.
STRIP_IMPORTS = {
    "culture.bots.config",  # BOT_CONFIG_FILE re-export in cli/shared/constants.py
}


def _strip_unused_imports(source: str) -> str:
    """Remove import lines whose dotted target is in STRIP_IMPORTS.

    Conservative: matches lines starting with `from <strip_target> import` and
    drops the whole line. Does not touch multi-line / parenthesized imports
    (none of the strip targets currently use that form).
    """
    out_lines = []
    for line in source.splitlines(keepends=True):
        stripped = line.lstrip()
        for target in STRIP_IMPORTS:
            if stripped.startswith(f"from {target} import ") or stripped.startswith(
                f"import {target}"
            ):
                break  # drop the line
        else:
            out_lines.append(line)
            continue
    return "".join(out_lines)


# Phase A — 0.2.0 manifest. (src relative to culture-root, dst relative to repo root.)
PHASE_A = [
    # Vendored utility modules
    ("culture/aio.py", "cultureagent/aio.py"),
    ("culture/pidfile.py", "cultureagent/pidfile.py"),
    ("culture/_constants.py", "cultureagent/_constants.py"),
    ("culture/constants.py", "cultureagent/constants.py"),
    ("culture/cli/shared/constants.py", "cultureagent/cli/shared/constants.py"),
    ("culture/telemetry/__init__.py", "cultureagent/telemetry/__init__.py"),
    ("culture/telemetry/context.py", "cultureagent/telemetry/context.py"),
    ("culture/protocol/__init__.py", "cultureagent/protocol/__init__.py"),
    ("culture/protocol/message.py", "cultureagent/protocol/message.py"),
    # Shared tier
    ("culture/clients/__init__.py", "cultureagent/clients/__init__.py"),
    ("culture/clients/shared/__init__.py", "cultureagent/clients/shared/__init__.py"),
    ("culture/clients/shared/attention.py", "cultureagent/clients/shared/attention.py"),
    ("culture/clients/shared/ipc.py", "cultureagent/clients/shared/ipc.py"),
    ("culture/clients/shared/irc_transport.py", "cultureagent/clients/shared/irc_transport.py"),
    ("culture/clients/shared/message_buffer.py", "cultureagent/clients/shared/message_buffer.py"),
    ("culture/clients/shared/rooms.py", "cultureagent/clients/shared/rooms.py"),
    ("culture/clients/shared/socket_server.py", "cultureagent/clients/shared/socket_server.py"),
    ("culture/clients/shared/telemetry.py", "cultureagent/clients/shared/telemetry.py"),
    ("culture/clients/shared/webhook.py", "cultureagent/clients/shared/webhook.py"),
    ("culture/clients/shared/webhook_types.py", "cultureagent/clients/shared/webhook_types.py"),
    # Phase A tests
    ("tests/harness/conftest.py", "tests/harness/conftest.py"),
    ("tests/harness/test_attention.py", "tests/harness/test_attention.py"),
    ("tests/harness/test_attention_config.py", "tests/harness/test_attention_config.py"),
    (
        "tests/harness/test_irc_transport_propagation.py",
        "tests/harness/test_irc_transport_propagation.py",
    ),
    ("tests/harness/test_telemetry_module.py", "tests/harness/test_telemetry_module.py"),
    ("tests/harness/test_webhook_config_shared.py", "tests/harness/test_webhook_config_shared.py"),
    ("tests/harness/test_record_llm_call.py", "tests/harness/test_record_llm_call.py"),
    ("tests/test_irc_transport.py", "tests/test_irc_transport.py"),
    ("tests/test_irc_transport_tags.py", "tests/test_irc_transport_tags.py"),
    ("tests/test_message_buffer.py", "tests/test_message_buffer.py"),
    ("tests/test_socket_server.py", "tests/test_socket_server.py"),
    ("tests/test_webhook.py", "tests/test_webhook.py"),
    # test_skill_client.py — split: 0.2.0 keeps the shared/ipc-only blocks
    # The driver does not split files; the implementer hand-edits this one
    # after the bulk pass. See plan task A.5.
]


# Phase B — 0.3.0 manifest. Generated programmatically for the four backends.
def _phase_b_manifest() -> list[tuple[str, str]]:
    items: list[tuple[str, str]] = [
        ("packages/agent-harness/config.py", "packages/agent-harness/config.py"),
        ("packages/agent-harness/constants.py", "packages/agent-harness/constants.py"),
        ("packages/agent-harness/daemon.py", "packages/agent-harness/daemon.py"),
        ("packages/agent-harness/culture.yaml", "packages/agent-harness/culture.yaml"),
        ("packages/agent-harness/README.md", "packages/agent-harness/README.md"),
        # NOTE: packages/agent-harness/skill/ has no __init__.py upstream — it
        # ships as a copy-template for cite-pattern consumers, not as an
        # importable package. Don't create one here.
        (
            "packages/agent-harness/skill/irc_client.py",
            "packages/agent-harness/skill/irc_client.py",
        ),
        (
            "packages/agent-harness/skill/SKILL.md",
            "packages/agent-harness/skill/SKILL.md",
        ),
        # Phase B tests
        (
            "tests/harness/test_no_per_backend_copy_of_shared_modules.py",
            "tests/harness/test_no_per_backend_copy_of_shared_modules.py",
        ),
        ("tests/harness/test_all_backends_parity.py", "tests/harness/test_all_backends_parity.py"),
        ("tests/harness/test_daemon_telemetry.py", "tests/harness/test_daemon_telemetry.py"),
        ("tests/test_supervisor.py", "tests/test_supervisor.py"),
        ("tests/test_acp_daemon.py", "tests/test_acp_daemon.py"),
        ("tests/test_codex_daemon.py", "tests/test_codex_daemon.py"),
        ("tests/test_copilot_daemon.py", "tests/test_copilot_daemon.py"),
        ("tests/test_daemon.py", "tests/test_daemon.py"),
        ("tests/test_daemon_config.py", "tests/test_daemon_config.py"),
        ("tests/test_daemon_ipc.py", "tests/test_daemon_ipc.py"),
        ("tests/test_agent_runner.py", "tests/test_agent_runner.py"),
        ("tests/test_skill_client.py", "tests/test_skill_client.py"),
    ]
    for backend in ("claude", "codex", "copilot", "acp"):
        items.extend(
            [
                (
                    f"culture/clients/{backend}/__init__.py",
                    f"cultureagent/clients/{backend}/__init__.py",
                ),
                (
                    f"culture/clients/{backend}/agent_runner.py",
                    f"cultureagent/clients/{backend}/agent_runner.py",
                ),
                (
                    f"culture/clients/{backend}/supervisor.py",
                    f"cultureagent/clients/{backend}/supervisor.py",
                ),
                (
                    f"culture/clients/{backend}/daemon.py",
                    f"cultureagent/clients/{backend}/daemon.py",
                ),
                (
                    f"culture/clients/{backend}/config.py",
                    f"cultureagent/clients/{backend}/config.py",
                ),
                (
                    f"culture/clients/{backend}/constants.py",
                    f"cultureagent/clients/{backend}/constants.py",
                ),
                (
                    f"culture/clients/{backend}/culture.yaml",
                    f"cultureagent/clients/{backend}/culture.yaml",
                ),
                (
                    f"culture/clients/{backend}/skill/__init__.py",
                    f"cultureagent/clients/{backend}/skill/__init__.py",
                ),
                (
                    f"culture/clients/{backend}/skill/irc_client.py",
                    f"cultureagent/clients/{backend}/skill/irc_client.py",
                ),
                (
                    f"culture/clients/{backend}/skill/SKILL.md",
                    f"cultureagent/clients/{backend}/skill/SKILL.md",
                ),
            ]
        )
        items.append(
            (
                f"tests/harness/test_agent_runner_{backend}.py",
                f"tests/harness/test_agent_runner_{backend}.py",
            ),
        )
    items.append(
        ("culture/clients/claude/__main__.py", "cultureagent/clients/claude/__main__.py"),
    )
    return items


PHASE_B = _phase_b_manifest()


def git_blob_sha(path: Path) -> str:
    out = subprocess.run(
        ["git", "hash-object", str(path)],
        capture_output=True,
        text=True,
        check=True,
    )
    return out.stdout.strip()


def migrate_one(src: Path, dst: Path, is_python: bool) -> dict:
    src_text = src.read_text(encoding="utf-8")
    src_sha = git_blob_sha(src)

    if is_python:
        src_text = _strip_unused_imports(src_text)

    src_telemetry = telemetry_namespace_count(src_text)

    if is_python:
        rewritten, import_edits = rewrite_module(src_text, ALLOWLIST)
        rewritten, string_edits = rewrite_strings(rewritten)
    else:
        rewritten, import_edits, string_edits = src_text, 0, 0

    dst_telemetry = telemetry_namespace_count(rewritten)
    if dst_telemetry != src_telemetry:
        raise SystemExit(
            f"PARITY FAIL: {src} telemetry count {src_telemetry} -> " f"{dst} count {dst_telemetry}"
        )

    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(rewritten, encoding="utf-8")

    src_lines = src_text.splitlines()
    dst_lines = rewritten.splitlines()
    diff_lines = sum(1 for a, b in zip(src_lines, dst_lines) if a != b)
    diff_lines += abs(len(src_lines) - len(dst_lines))

    return {
        "src": str(src),
        "dst": str(dst),
        "src_sha": src_sha,
        "import_edits": import_edits,
        "string_edits": string_edits,
        "telemetry_count_src": src_telemetry,
        "telemetry_count_dst": dst_telemetry,
        "diff_lines": diff_lines,
    }


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--phase", choices=("a", "b"), required=True)
    p.add_argument("--culture-root", required=True)
    p.add_argument("--output-receipt", required=True)
    args = p.parse_args()

    manifest = {"a": PHASE_A, "b": PHASE_B}[args.phase]
    culture_root = Path(args.culture_root).resolve()
    repo_root = Path(__file__).resolve().parents[4]

    receipt = []
    for src_rel, dst_rel in manifest:
        src = culture_root / src_rel
        dst = repo_root / dst_rel
        is_python = src.suffix == ".py"
        if not src.exists():
            print(f"MISSING: {src}", file=sys.stderr)
            return 2
        receipt.append(migrate_one(src, dst, is_python))

    Path(args.output_receipt).write_text(json.dumps(receipt, indent=2), encoding="utf-8")
    print(f"OK: {len(receipt)} files migrated; receipt at {args.output_receipt}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
