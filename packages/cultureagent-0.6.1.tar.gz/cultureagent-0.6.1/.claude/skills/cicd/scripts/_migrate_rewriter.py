"""libcst-based Python import rewriter for the
culture -> cultureagent migration.

Rewrites `from culture.<X> import …` and `import culture.<X>` statements
when `culture.<X>` is on the allow-list. Any other `culture.*` import
raises ValueError so the migration script can stop and surface it.

Errors include the dotted-path only; the driver layer is expected to
wrap and add file/line context.

String literals — including telemetry namespace strings like
"culture.harness" — are NEVER touched. Use a separate regex pass for
the bounded string-rewrite classes.
"""

from __future__ import annotations

import re
from collections.abc import Sequence

import libcst as cst


def _starts_with_allowlisted(dotted: str, allowlist: Sequence[str]) -> bool:
    return any(dotted == p or dotted.startswith(p + ".") for p in allowlist)


class _Rewriter(cst.CSTTransformer):
    def __init__(self, allowlist: Sequence[str]):
        super().__init__()
        self.allowlist = allowlist
        self.edits = 0

    def _rewrite_dotted(self, dotted: str) -> str:
        if dotted == "culture" or dotted.startswith("culture."):
            if not _starts_with_allowlisted(dotted, self.allowlist):
                raise ValueError(f"unexpected culture import: {dotted}")
            if dotted == "culture":
                # bare `import culture` would only match if "culture" itself is on
                # the allowlist; it is not, so this branch is unreachable but kept
                # for clarity.
                return dotted
            self.edits += 1
            return "cultureagent." + dotted[len("culture.") :]
        return dotted

    def leave_ImportFrom(
        self, original_node: cst.ImportFrom, updated_node: cst.ImportFrom
    ) -> cst.BaseSmallStatement:
        if updated_node.module is None:
            return updated_node
        dotted = _attr_to_dotted(updated_node.module)
        new_dotted = self._rewrite_dotted(dotted)
        if new_dotted == dotted:
            return updated_node
        return updated_node.with_changes(module=_dotted_to_attr(new_dotted))

    def leave_Import(
        self, original_node: cst.Import, updated_node: cst.Import
    ) -> cst.BaseSmallStatement:
        new_names = []
        changed = False
        for alias in updated_node.names:
            dotted = _attr_to_dotted(alias.name)
            new_dotted = self._rewrite_dotted(dotted)
            if new_dotted == dotted:
                new_names.append(alias)
            else:
                new_names.append(alias.with_changes(name=_dotted_to_attr(new_dotted)))
                changed = True
        if not changed:
            return updated_node
        return updated_node.with_changes(names=new_names)


def _attr_to_dotted(node) -> str:
    if isinstance(node, cst.Name):
        return node.value
    if isinstance(node, cst.Attribute):
        return _attr_to_dotted(node.value) + "." + node.attr.value
    raise TypeError(f"unsupported node: {type(node)}")


def _dotted_to_attr(dotted: str):
    parts = dotted.split(".")
    node = cst.Name(parts[0])
    for part in parts[1:]:
        node = cst.Attribute(value=node, attr=cst.Name(part))
    return node


def rewrite_module(source: str, allowlist: Sequence[str]) -> tuple[str, int]:
    """Rewrite imports in source. Returns (new_source, edit_count).

    Raises ValueError if an unallowed `culture.*` import is encountered.
    """
    tree = cst.parse_module(source)
    rewriter = _Rewriter(allowlist)
    new_tree = tree.visit(rewriter)
    return new_tree.code, rewriter.edits


_MOCK_PATCH_RE = re.compile(r'"(culture\.clients\.[a-zA-Z0-9_.]+)"')
_FS_PATH_RE = re.compile(r'(/\s*)?"culture"(\s*/\s*"clients")')


def rewrite_strings(source: str) -> tuple[str, int]:
    """Rewrite bounded string-literal classes:
      1. mock.patch / module-equality dotted targets ("culture.clients.X")
      2. filesystem path strings ("culture" / "clients")

    Telemetry namespace strings ("culture.harness*", "culture.trace.*",
    "culture.attention.*") are NOT touched. The mock-patch regex is
    bounded to "culture.clients." so telemetry strings (which start with
    "culture.harness", "culture.trace", "culture.attention") cannot match.
    """
    edits = 0

    def _patch_repl(m: re.Match) -> str:
        nonlocal edits
        edits += 1
        return f'"cultureagent.{m.group(1)[len("culture.") :]}"'

    def _fs_repl(m: re.Match) -> str:
        nonlocal edits
        edits += 1
        prefix = m.group(1) or ""
        suffix = m.group(2)
        return f'{prefix}"cultureagent"{suffix}'

    out = _MOCK_PATCH_RE.sub(_patch_repl, source)
    out = _FS_PATH_RE.sub(_fs_repl, out)
    return out, edits


_TELEMETRY_NS_RE = re.compile(r'"(culture\.(?:harness|trace|attention)[^"]*)"')


def telemetry_namespace_count(source: str) -> int:
    """Count telemetry-namespace string literals (for migration parity check)."""
    return len(_TELEMETRY_NS_RE.findall(source))
