#!/usr/bin/env bash
# Driver for the Phase 0b culture -> cultureagent migration.
#
# Usage:
#   migrate-from-culture.sh --phase {a|b} [--culture-root PATH] [--receipt PATH]
#
# Defaults:
#   --culture-root  ../culture
#   --receipt       migration-receipt-phase-<a|b>.json

set -euo pipefail

PHASE=""
CULTURE_ROOT="../culture"
RECEIPT=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --phase) PHASE="$2"; shift 2 ;;
        --culture-root) CULTURE_ROOT="$2"; shift 2 ;;
        --receipt) RECEIPT="$2"; shift 2 ;;
        *) echo "Unknown flag: $1" >&2; exit 2 ;;
    esac
done

if [[ -z "$PHASE" ]]; then
    echo "Usage: migrate-from-culture.sh --phase {a|b} [--culture-root PATH] [--receipt PATH]" >&2
    exit 2
fi

if [[ -z "$RECEIPT" ]]; then
    RECEIPT="migration-receipt-phase-${PHASE}.json"
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR/../../../.."

uv run python "$SCRIPT_DIR/_migrate_driver.py" \
    --phase "$PHASE" \
    --culture-root "$CULTURE_ROOT" \
    --output-receipt "$RECEIPT"
