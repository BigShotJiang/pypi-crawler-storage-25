#!/usr/bin/env python3
"""Verify that pyproject.toml's coverage omit list and sonar-project.properties'
``sonar.coverage.exclusions`` stay in sync.

Background: pytest-cov's ``[tool.coverage.run].omit`` controls which files
are excluded from ``coverage.xml``. SonarCloud's denominator is
``sonar.sources=cultureagent``; files absent from ``coverage.xml`` are
counted as fully uncovered unless they're *also* in
``sonar.coverage.exclusions``. PR #25 made the two lists agree.

This script fails the build if they drift apart. Non-source patterns
(``cultureagent/__pycache__/*``) are filtered out — SonarCloud doesn't
scan ``__pycache__`` either way, so requiring it in both files would
be pure ceremony.

Run via ``python3 scripts/check_coverage_exclusions_sync.py``; exit 0
on match, 1 on drift (with a diff in stderr).
"""

from __future__ import annotations

import sys
import tomllib
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
PYPROJECT = REPO_ROOT / "pyproject.toml"
SONAR = REPO_ROOT / "sonar-project.properties"

# Patterns that don't matter for SonarCloud — pytest-cov needs them
# (e.g., __pycache__ is a build artifact that coverage.py would
# otherwise instrument) but Sonar doesn't scan them.
_NON_SOURCE_PATTERNS = {"cultureagent/__pycache__/*"}


def _load_pyproject_omits() -> set[str]:
    with PYPROJECT.open("rb") as f:
        data = tomllib.load(f)
    omits = data["tool"]["coverage"]["run"]["omit"]
    return {pat for pat in omits if pat not in _NON_SOURCE_PATTERNS}


def _load_sonar_exclusions() -> set[str]:
    """Parse the ``sonar.coverage.exclusions=...`` line from the properties file."""
    text = SONAR.read_text()
    # Properties keys may span lines via trailing backslash; resolve those first.
    text = text.replace("\\\n", "")
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if line.startswith("sonar.coverage.exclusions="):
            _, _, value = line.partition("=")
            return {pat.strip() for pat in value.split(",") if pat.strip()}
    return set()


def main() -> int:
    pytest_omits = _load_pyproject_omits()
    sonar_exclusions = _load_sonar_exclusions()

    if pytest_omits == sonar_exclusions:
        print("OK: pytest-cov omit and sonar.coverage.exclusions are in sync.")
        return 0

    in_pytest_only = sorted(pytest_omits - sonar_exclusions)
    in_sonar_only = sorted(sonar_exclusions - pytest_omits)

    print(
        "ERROR: pytest-cov [tool.coverage.run].omit and " "sonar.coverage.exclusions have drifted.",
        file=sys.stderr,
    )
    print(
        "Update both lists so they match (or add the pattern to "
        "_NON_SOURCE_PATTERNS here if it shouldn't apply to Sonar).",
        file=sys.stderr,
    )
    if in_pytest_only:
        print("\nIn pyproject.toml omit but NOT in sonar.coverage.exclusions:", file=sys.stderr)
        for pat in in_pytest_only:
            print(f"  + {pat}", file=sys.stderr)
    if in_sonar_only:
        print("\nIn sonar.coverage.exclusions but NOT in pyproject.toml omit:", file=sys.stderr)
        for pat in in_sonar_only:
            print(f"  + {pat}", file=sys.stderr)
    return 1


if __name__ == "__main__":
    sys.exit(main())
