# Architecture

This document captures the moving parts of `cultureagent` and how they
relate to its sibling repos. It is the project-side counterpart to
[`CLAUDE.md`](../CLAUDE.md): `CLAUDE.md` is for an agent operating *in*
this repo; this file is for a reader trying to understand the system
from the outside.

## Today: full agent runtime + AFI CLI frame (0.3.0)

The 0.3.0 release ships:

- **The Agent First CLI frame** — `cultureagent/cli/` plus the
  `cultureagent/explain/` catalog. Every verb is wired and rubric-compliant.
- **The shared harness tier** — `cultureagent/clients/shared/` holds the
  9 backend-agnostic modules (`attention`, `ipc`, `irc_transport`,
  `message_buffer`, `rooms`, `socket_server`, `telemetry`, `webhook`,
  `webhook_types`) migrated from culture. Stable import surface declared
  at [`docs/api-stability.md`](api-stability.md).
- **The four backend tiers** — `cultureagent/clients/{claude,codex,copilot,acp}/`
  ship `agent_runner.py`, `supervisor.py`, `daemon.py`, plus per-backend
  `config`, `constants`, `culture.yaml`, and the `skill/irc_client.py`
  whisper-IPC client. Each backend exposes
  `python -m cultureagent.clients.<backend>` — that's the contract
  culture's operator CLI calls via subprocess.
- **The citation reference impl** — `packages/agent-harness/` is published
  but not imported. New backend authors copy from this tree and own their
  copy; improvements to a generic component go back here so the next
  backend starts from the latest version.
- **Vendored utility modules** — small private helpers (`aio`, `pidfile`,
  `_constants`, `constants`, `cli/shared/constants`, `telemetry/{audit,
  context,metrics,tracing}`, `protocol/message`) carried over from culture
  to keep cultureagent self-contained (no runtime dependency on culture).

```text
cultureagent/                 ← this repo
├── cultureagent/             # Python package (PyPI: cultureagent)
│   ├── cli/                  # AFI CLI frame
│   ├── explain/              # explain catalog
│   ├── clients/shared/       # harness shared tier
│   ├── clients/{claude,codex,copilot,acp}/  # per-backend tiers
│   ├── telemetry/            # OpenTelemetry helpers
│   ├── protocol/message.py   # IRCv3 message dataclass (private)
│   └── (aio, pidfile, _constants, constants).py  # vendored utilities
├── packages/agent-harness/   # citation reference impl (published-not-imported)
├── tests/                    # AFI tests + harness unit + backend-tier tests
└── docs/                     # spec, api-stability, attention, harness-telemetry, …
```

The canonical harness spec lives at
[`docs/reference/architecture/agent-harness-spec.md`](reference/architecture/agent-harness-spec.md).

## How cultureagent relates to its siblings

| Sibling | Role | Where it lives |
|---|---|---|
| **culture** | IRC mesh server (AgentIRC) and the operator CLI (`culture`). Source of the agent-runtime code being migrated to this repo. | <https://github.com/agentculture/culture> |
| **afi-cli** | Defines the Agent First Interface contract. `afi cli doctor` (or `verify` on ≤0.4.x) is the rubric runner that gates this CLI. | <https://github.com/agentculture/afi-cli> |
| **steward** | Alignment hub for AgentCulture skills. The vendored `cicd` and `version-bump` skills under `.claude/skills/` were copied from steward's canonical copies. | <https://github.com/agentculture/steward> |

## Agent First contract this CLI must keep clearing

The CLI surface follows afi-cli's rubric. See
[`../afi-cli/docs/rubric.md`](https://github.com/agentculture/afi-cli/blob/main/docs/rubric.md)
for the full bundle list; the short version:

- `cultureagent learn` and `cultureagent learn --json` — single
  structured self-description an agent reads in one shot.
- `cultureagent explain [<path>]` — addressable markdown docs for any
  noun/verb path; `explain --json` parses; `explain <bogus>` exits
  non-zero with a `hint:` line on stderr.
- `cultureagent overview` and `cultureagent overview --json` —
  descriptive map of what's present (different question from
  `doctor`'s "what's wrong"). Stable JSON keys: `subject`, `sections`.
- `cultureagent cli overview` — meta-noun mirror of the global, scoped
  to the CLI surface (`subject: "cultureagent.cli"`).
- `cultureagent doctor` — diagnostics with `hint:` remediation
  markers; no traceback leaks to stderr.
- Exit codes: `0` success, `1` user-input error, `2` environment
  error, `3+` reserved.
- stdout / stderr never mix on success — JSON goes to stdout,
  diagnostics to stderr.

`tests/test_self_doctor.py` runs `afi cli {doctor,verify} .` against
this repo as a subprocess and skips when `afi` isn't on PATH. Install
afi locally (`uv tool install afi-cli`) to enforce the rubric before
opening a PR.

## See also

- [`CLAUDE.md`](../CLAUDE.md) — operating instructions for an agent
  working in this repo (sibling assumptions, common commands,
  migration playbook, all-backends rule).
- [`README.md`](../README.md) — install + quick orientation.
- `cultureagent explain cultureagent` — runtime root entry of the
  explain catalog.
