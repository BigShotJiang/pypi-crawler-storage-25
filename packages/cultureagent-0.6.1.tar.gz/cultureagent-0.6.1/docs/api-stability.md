# Public API stability

cultureagent's public surface is the set of imports and subprocess entry
points listed below. Everything else — module internals, helper functions,
test scaffolds, vendored utility modules — is private and may change at any
0.x or 1.x release.

## Stability promise

- All symbols on this page are behavior-stable through the entire 0.x line.
- Breaking changes only at major bumps (0.x → 1.0, 1.x → 2.0).
- Deprecation: a symbol moves to "deprecated" for one minor cycle (warning
  at import) before removal at the next major.
- "Behavior-stable" means: name, signature, and observable behavior.
  Internal refactoring (renaming private helpers, changing internal data
  flow, reorganizing module internals) does not require a major bump.

## Shared tier — Python imports (since 0.2.0)

| Import path                                                     | Stable since |
|-----------------------------------------------------------------|--------------|
| `cultureagent.clients.shared.attention.AttentionTracker`        | 0.2.0        |
| `cultureagent.clients.shared.attention.Band`                    | 0.2.0        |
| `cultureagent.clients.shared.message_buffer.MessageBuffer`      | 0.2.0        |
| `cultureagent.clients.shared.ipc.decode_message`                | 0.2.0        |
| `cultureagent.clients.shared.ipc.encode_message`                | 0.2.0        |
| `cultureagent.clients.shared.ipc.make_request`                  | 0.2.0        |
| `cultureagent.clients.shared.ipc.make_response`                 | 0.2.0        |
| `cultureagent.clients.shared.irc_transport.IRCTransport`        | 0.2.0        |
| `cultureagent.clients.shared.socket_server.SocketServer`        | 0.2.0        |
| `cultureagent.clients.shared.telemetry.init_harness_telemetry`  | 0.2.0        |
| `cultureagent.clients.shared.webhook.AlertEvent`                | 0.2.0        |
| `cultureagent.clients.shared.webhook.WebhookClient`             | 0.2.0        |
| `cultureagent.clients.shared.webhook_types.WebhookConfig`       | 0.2.0        |
| `cultureagent.clients.shared.rooms.parse_room_meta`             | 0.2.0        |
| `cultureagent.clients.shared.skill_irc_client.SkillClient`      | 0.6.0        |

Modules may export additional helpers at the same dotted path; consult
each module's `__all__` (or its absence) at release time. This table is
the contract; anything not listed is not promised stable.

### `SkillClient` public surface (since 0.6.0)

Async client that connects to the per-agent culture daemon Unix
socket. Used by culture's four cross-package integration tests
(`tests/test_integration_{layer5,skill_client,message_buffer,webhook}.py`)
and by the in-skill `irc-skill` shell-out.

- **Constructor:** `SkillClient(sock_path: str)`.
- **Lifecycle:** `await client.connect()`, `await client.close()`.
- **IRC operations** (all coroutines, returning the daemon's response
  dict):
  - `irc_send(channel: str, message: str)`
  - `irc_read(channel: str, limit: int = 50)`
  - `irc_ask(channel: str, question: str, timeout: int = 30)`
  - `irc_join(channel: str)`
  - `irc_part(channel: str)`
  - `irc_channels()`
  - `irc_who(target: str)`
  - `irc_topic(channel: str, topic: str | None = None)`
- **Agent control:** `compact()`, `clear()` (coroutines — send
  `/compact` and `/clear` to the agent runner).
- **Whisper buffer:** `client.pending_whispers: list[dict]` is the
  live buffer the background read loop appends `MSG_TYPE_WHISPER`
  messages to. `client.drain_whispers()` (sync) returns the current
  list and clears it.

## Per-backend — Python imports (since 0.3.0)

For each backend `B` in `{claude, codex, copilot, acp}`:

| Import path                                              | Stable since | Notes |
|----------------------------------------------------------|--------------|-------|
| `cultureagent.clients.B.config.AgentConfig`              | 0.3.0        | dataclass — fields are part of the contract |
| `cultureagent.clients.B.config.DaemonConfig`             | 0.3.0        | dataclass — top-level config schema |
| `cultureagent.clients.B.config.ServerConnConfig`         | 0.3.0        | dataclass |
| `cultureagent.clients.B.config.SupervisorConfig`         | 0.3.0        | dataclass |
| `cultureagent.clients.B.config.TelemetryConfig`          | 0.3.0        | dataclass — OTEL wiring |
| `cultureagent.clients.B.config.load_config`              | 0.3.0        | parses YAML at the given path |
| `cultureagent.clients.B.config.load_config_or_default`   | 0.3.0        | same, but returns defaults if path missing |
| `cultureagent.clients.B.config.save_config`              | 0.3.0        | round-trips a `DaemonConfig` to disk |
| `cultureagent.clients.B.config.add_agent_to_config`      | 0.3.0        | |
| `cultureagent.clients.B.config.remove_agent`             | 0.3.0        | |
| `cultureagent.clients.B.config.rename_agent`             | 0.3.0        | |
| `cultureagent.clients.B.config.rename_server`            | 0.3.0        | |
| `cultureagent.clients.B.config.sanitize_agent_name`      | 0.3.0        | |
| `cultureagent.clients.B.config.resolve_attention_config` | 0.3.0        | |
| `cultureagent.clients.B.constants.DEFAULT_TURN_TIMEOUT_SECONDS` | 0.3.0  | every backend |
| `cultureagent.clients.claude.config.archive_agent`       | 0.3.0        | claude-only (operator UX) |
| `cultureagent.clients.claude.config.archive_server`      | 0.3.0        | claude-only |
| `cultureagent.clients.claude.config.unarchive_agent`     | 0.3.0        | claude-only |
| `cultureagent.clients.claude.config.unarchive_server`    | 0.3.0        | claude-only |

Per-backend `constants` modules expose additional timeouts (e.g.
`INNER_REQUEST_TIMEOUT_SECONDS` for codex/acp,
`INNER_SDK_TIMEOUT_SECONDS` for copilot,
`STOP_GRACE_SECONDS` for claude). Names that appear in a single backend
are part of that backend's contract only.

## Daemon classes (since 0.6.0)

Culture launches the four per-backend daemons in-process from
`culture agent start <name>` (the systemd `ExecStart` topology, not
subprocess invocations). These classes are now part of the stable
0.x surface:

| Import path                                              | Stable since | Topology |
|----------------------------------------------------------|--------------|----------|
| `cultureagent.clients.claude.daemon.AgentDaemon`         | 0.6.0        | `BaseDaemon` — synchronous mention routing |
| `cultureagent.clients.codex.daemon.CodexDaemon`          | 0.6.0        | `QueuedBaseDaemon` — FIFO mention queue |
| `cultureagent.clients.copilot.daemon.CopilotDaemon`      | 0.6.0        | `QueuedBaseDaemon` — FIFO mention queue |
| `cultureagent.clients.acp.daemon.ACPDaemon`              | 0.6.0        | `QueuedBaseDaemon` + start-failure retry |

`BaseDaemon` / `QueuedBaseDaemon` themselves remain **private** —
their internals (mention routing, supervisor wiring, attention
tracking) may change at any 0.x release. The four concrete subclasses
above and their constructor + lifecycle methods are the contract.

### Constructor contract

Positional args (identical across backends):

```python
<Daemon>(daemon_config: DaemonConfig, agent: AgentConfig)
```

Both args are the backend's own dataclasses, already in the stable
surface (see the per-backend table above).

Keyword args, shared:

- `socket_dir: str | None = None` — directory under which the
  daemon's Unix socket is created. Defaults to
  `cultureagent.cli.shared.constants.culture_runtime_dir()`.

Keyword args, per-backend (intentionally asymmetric — culture's CLI
expects each backend's variant verbatim):

- `AgentDaemon(skip_claude: bool = False)`
- `CodexDaemon(skip_codex: bool = False)`
- `CopilotDaemon(skip_copilot: bool = False)`
- `ACPDaemon(skip_agent: bool = False)` *(ACP routes through whatever
  agent the operator wires — Cline, OpenCode, etc. — and the kwarg
  name reflects that abstraction.)*

When `skip_<sdk>=True`, the daemon wires the transport and socket
but does not spawn the agent runner — used by tests and dry-run
operator flows.

### Lifecycle

Both methods are awaitables:

```python
await daemon.start()   # binds transport + socket; spawns runner unless skip_<sdk>
await daemon.stop()    # graceful shutdown, drains buffers
```

### Class attribute

- `BACKEND_NAME: str` — one of `"claude"`, `"codex"`, `"copilot"`,
  `"acp"`. Culture uses this for log routing and process labelling;
  the value is part of the contract.

## Subprocess entry points (since 0.3.0)

The supported invocation contract for downstream operators:

- `python -m cultureagent.clients.<backend>` — daemon entry per backend.
  Argv: `start [<nick> | --all] [--config PATH]`. Exit codes: `0` clean
  shutdown, `1` config or arg error.
- `python -m cultureagent.clients.<backend>.skill.irc_client` — whisper
  IPC client used by the in-skill `irc-skill` shell-out. Requires
  `CULTURE_NICK` set in the environment.

The four backends produce identical CLI shape (`culture <backend>
agent daemon` argparse tree); see `tests/harness/test_all_backends_parity.py`
for the parity assertions that gate this contract.

## Explicitly NOT public

The following are **private** and may change without major bumps:

- `cultureagent.clients.<backend>.{agent_runner,supervisor}.*`
  (internals — access only via the daemon class lifecycle or the
  subprocess entry points above). The per-backend `daemon` modules
  *were* private through 0.5.x; the concrete `<Backend>Daemon`
  classes are now stable (see "Daemon classes" above), but everything
  else inside `daemon.py` (private helpers, internal hooks like
  `_create_supervisor`, `_start_agent_runner`) is still internal.
- `cultureagent.clients.<backend>.skill.irc_client.*` (per-backend
  module internals; the module's `__main__` subprocess shape is the
  contract, not the symbols. The shared `SkillClient` at
  `cultureagent.clients.shared.skill_irc_client` is the documented
  Python-import entry point — see the shared-tier table above.)
- `cultureagent.{aio,pidfile,_constants,constants,protocol,telemetry}.*`
  (vendored utility modules; private — may move to an external package
  later)
- `cultureagent.cli.shared.constants.*` (private; supports the AFI CLI
  frame)
<!-- packages/agent-harness/* was the citation-pattern reference impl
through 0.3.2. It was removed in 0.3.3 — the shared modules under
cultureagent/clients/shared/ are now the canonical implementation. -->

- Any test scaffolds (`IRCTestClient`, conftest fixtures)

### Note on `cultureagent.protocol.message.Message`

The `Message` class is vendored from culture's IRCv3 wire-format parser.
It is currently private in cultureagent. The arguably correct long-term
home is `agentirc` (the IRCd package). Tracked as a future move alongside
the agentirc-10.0 cleanup; kept private here so the move doesn't require
a major bump.

## What this means for culture

Culture imports through re-export shims that map old `culture.clients.*`
paths onto the symbols above. Shim mechanics live on culture's side; this
contract just says: if it's listed above, you can rely on it. If it's
not, don't import it.

If you find a symbol you need that isn't listed, file a brief on this
repo in the round-trip protocol shape (see issue
[#3](https://github.com/agentculture/cultureagent/issues/3)) so we can
either promote it to the surface or instruct toward a covered alternative.
