# Skill provenance — cultureagent

cultureagent is a **consumer** of skills published by `../steward`. This file
is the deterministic upstream/downstream map for the skills vendored here.

The AgentCulture mesh follows the **cite, don't import** pattern: each
consumer copies the upstream skill into its own `.claude/skills/` and may
diverge from it. Nothing imports across repos at runtime. When upstream
changes, downstream copies do not auto-update — steward broadcasts an issue
to each consumer and the consumer re-vendors at its own cadence.

## Vendored skills

| Skill | Upstream | Vendored from | Local divergence |
|-------|----------|---------------|------------------|
| `cicd` | `../steward/.claude/skills/cicd/` — layered on `agex pr` (in `agentculture/agex-cli`) | steward 0.12.0 | `scripts/migrate-from-culture.sh`, `scripts/_migrate_driver.py`, `scripts/_migrate_rewriter.py` — cite-don't-import Phase 0a/0b migration drivers for pulling agent-harness from `../culture`. Unrelated to the steward-tracked surface; preserved across resyncs. |
| `communicate` | `../steward/.claude/skills/communicate/` — backed by `agtag` (in `agentculture/agtag`) | steward 0.12.0 | None. Signature resolves to `- cultureagent (Claude)` via the agtag basename fallback (no `culture.yaml` yet). |
| `version-bump` | `../steward/.claude/skills/version-bump/` | steward 0.7.0 | None. |

## Resync policy

- **Trigger.** Steward auto-broadcasts an issue when a vendored skill moves
  on. Issues land under <https://github.com/agentculture/cultureagent/issues>
  with title prefix `Resync vendored <name> skill from steward`.
- **Procedure.** Branch out, `cp -R ../steward/.claude/skills/<name>/`
  over the existing tree, `chmod +x scripts/*.sh`, re-apply the
  divergences listed above (only the `cicd` row currently has any),
  bump the version, and open a PR via
  `bash .claude/skills/cicd/scripts/workflow.sh open …`.
- **Acceptance.** Each row's "Local divergence" cell must remain accurate
  after the resync, or the row should be updated in the same PR.

## Signature convention

cultureagent does not ship a `culture.yaml` yet. Both `agex` and `agtag`
fall back to the git-repo basename when resolving the signing nick, so PR
comments and issue posts emit:

```text
- cultureagent (Claude)
```

This matches the convention documented in the project `CLAUDE.md`. Drop a
`culture.yaml` at the repo root if a different nick is ever required.
