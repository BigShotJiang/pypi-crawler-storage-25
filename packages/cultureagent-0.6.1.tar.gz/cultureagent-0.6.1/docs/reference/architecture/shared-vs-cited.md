# Shared modules and per-backend modules

The cultureagent harness uses a **shared-by-default** code-distribution
model. Code that has no SDK-specific behavior lives once under
`cultureagent/clients/shared/` and is imported by every backend; code that
genuinely diverges per backend lives at
`cultureagent/clients/<backend>/`.

## History

Through 0.3.2 the harness used a two-tier model: shared modules under
`cultureagent/clients/shared/` plus a "cited tier" reference impl at
`packages/agent-harness/` that backends could copy verbatim. The cite-
don't-import contract was relaxed in the dedup arc (PR #9, #10, #11)
in favor of shared base classes + thin per-backend subclasses for
cleaner maintenance. The reference tree at `packages/agent-harness/`
was retired in 0.3.3.

## Current rule

A harness module belongs in `cultureagent/clients/shared/` if it can be
the same Python object across all four backends (`claude`, `codex`,
`copilot`, `acp`) — either because the logic is genuinely
backend-agnostic (state machines, IPC frame codecs, telemetry plumbing)
or because the divergence can be expressed via subclassing or
parameter injection.

A module stays per-backend at `cultureagent/clients/<backend>/` only when
SDK shape genuinely forces divergence — e.g. `agent_runner.py` (Claude
SDK's async `query()` vs Codex/ACP's JSON-RPC subprocess vs Copilot's
SDK session model) or `daemon.py`'s lifecycle wiring (different
`AgentRunner` types, different supervisor classes).

## Current file list

### Shared (imported)

| File | Why shared |
|---|---|
| `attention.py` | Pure state machine; no I/O, no SDK shapes |
| `message_buffer.py` | Pure value type |
| `ipc.py` | Frame encoder/decoder for whisper protocol |
| `telemetry.py` | OTel glue; identical config across backends |
| `irc_transport.py` | RFC 2812 client wrapper; no SDK shapes |
| `socket_server.py` | Unix-socket whisper plumbing |
| `webhook.py` | `urllib.request` POST; identical schema |
| `webhook_types.py` | `WebhookConfig` dataclass |
| `rooms.py` | Room metadata parsing |
| `main_runner.py` | Per-backend `__main__.py` boilerplate (extracted in 0.3.1) |
| `skill_irc_client.py` | `SkillClient` + CLI (extracted in 0.3.1) |
| `supervisor.py` | `Supervisor` + `SupervisorVerdict` (extracted in 0.3.2) |
| `sdk_supervisor.py` | `make_sdk_evaluate_fn` (claude/acp share this; extracted in 0.3.2) |
| `base_daemon.py` | `BaseDaemon` — universal daemon surface, claude-shape mention routing (extracted in 0.4.0) |
| `queued_base_daemon.py` | `QueuedBaseDaemon` — adds FIFO mention queue + relay for codex/copilot/acp (extracted in 0.4.0) |

### Per-backend (still per-backend)

| File | Why per-backend |
|---|---|
| `daemon.py` | Thin subclass of `BaseDaemon` (claude) or `QueuedBaseDaemon` (codex/copilot/acp) — keeps lifecycle wiring + SDK-specific agent_runner / supervisor instantiation |
| `config.py` | Per-backend dataclass defaults (model, agent name, telemetry service_name) |
| `constants.py` | Per-backend timeouts (codex 30s vs acp 300s for inner request) |
| `agent_runner.py` | SDK call site — genuinely per-SDK |
| `supervisor.py` | Thin shim over `shared.supervisor`; claude/acp use SDK-shape, codex/copilot use subprocess-shape |
| `__main__.py` | 6-line wrapper over `shared.main_runner.run_main` |
| `skill/irc_client.py` | Re-export shim preserving the `cultureagent.clients.<B>.skill.irc_client.SkillClient` import path |
| `culture.yaml` | Per-backend default config |
| `skill/SKILL.md` | Per-backend agent-side skill instructions |

The shared tier's "no per-backend copy leaked" property is locked down by
`tests/harness/test_no_per_backend_copy_of_shared_modules.py`.

## Fork-back procedure

If a shared module needs to start diverging for one backend (e.g. an SDK
upgrade forces telemetry to emit different attributes per backend):

1. `cp cultureagent/clients/shared/X.py cultureagent/clients/<backend>/X.py`.
2. In *that backend's* code (its `daemon.py` and any tests that targeted
   the shared path), change `from cultureagent.clients.shared.X import …`
   to `from cultureagent.clients.<backend>.X import …`.
3. Leave any backends that still agree pointing at `shared/`.
4. Update this doc — move `X` from the "Shared" table to the
   "Per-backend" table for the now-divergent backend(s).
5. Update `tests/harness/test_no_per_backend_copy_of_shared_modules.py`
   to allow the per-backend copy of `X.py`.

The shared tier is **not** an all-or-nothing commitment — it just
describes where the line currently is.
