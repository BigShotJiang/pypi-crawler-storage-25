# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this repo is

`cultureagent` is the **agent runtime** for the [Culture mesh](https://github.com/agentculture/culture). The repo exists to take over the agent-side machinery that currently lives inside `../culture` and re-ship it as a standalone CLI that satisfies the [Agent First Interface](https://github.com/agentculture/afi-cli) contract.

Concretely, the migration target is two trees from `../culture`:

- `../culture/packages/agent-harness/` — the citation-pattern reference implementation (config, IRC transport, daemon, message buffer, socket server, IPC, webhook, telemetry, attention, the `skill/` IPC client). Spec: `../culture/docs/reference/architecture/agent-harness-spec.md`.
- `../culture/culture/clients/{claude,codex,copilot,acp}/` — the per-backend working copies (`agent_runner.py`, `supervisor.py`, `daemon.py`, plus telemetry/constants).

Once migrated, `culture` keeps the IRCd (`culture/agentirc/`) and the operator CLI; `cultureagent` owns everything that runs on the agent side of the wire and exposes it as `cultureagent <noun> <verb>`.

## Sibling workspace assumption

Path references in this file assume sibling checkouts in the same parent directory:

- `../culture` — source of the harness code being migrated; do not edit it from here. Improvements that affect the reference go back as separate PRs on `culture` (it owns `packages/agent-harness/`).
- `../afi-cli` — the Agent First contract. The rubric (`../afi-cli/docs/rubric.md`) is what `afi cli doctor` enforces; the cite-template at `../afi-cli/afi/cite/references/python-cli/` is the literal source for the CLI shape this repo must wear.
- `../steward` — alignment hub for AgentCulture skills. cultureagent currently vendors `cicd`, `communicate`, and `version-bump` from `../steward/.claude/skills/<name>/`; the provenance ledger is at `docs/skill-sources.md`. When a new skill is needed, copy from steward and add a row.

Workspace-level rules and the cross-repo overview live one directory up at `../CLAUDE.md` (when the workspace parent is checked out).

## Agent First contract (the bar this CLI must clear)

The CLI surface follows afi-cli's seven-bundle rubric. The `tests/test_self_doctor.py` acceptance gate is the standard way to enforce this once tests are in place — it runs `afi cli doctor .` in-process and blocks regressions.

Every command surface owes:

- `cultureagent learn` and `cultureagent learn --json` — single structured self-description an agent reads in one shot. Must mention purpose, commands, exit codes, `--json`, and `explain`.
- `cultureagent explain [<path>]` — addressable markdown docs for any noun/verb path; `explain --json` parses; `explain <bogus>` exits non-zero with a `hint:` line on stderr.
- `cultureagent overview` and `cultureagent overview --json` — descriptive map of what's present (different question from `doctor`'s "what's wrong"). Stable JSON keys: `subject`, `sections`.
- `cultureagent doctor` — diagnostics with `hint:` remediation markers; no traceback leaks to stderr.
- Exit codes: `0` success, `1` user-input error, `2` environment error, `3+` reserved.
- stdout / stderr never mix — JSON goes to stdout, diagnostics to stderr.

When designing a new verb, read `../afi-cli/docs/agent-first.md` first; favor agent ergonomics (low menu cardinality, introspection, machine-actionable errors) over human-UI conventions.

## Inherited AgentCulture conventions

Same stack as `../culture`, `../afi-cli`, `../steward`:

- Python 3.12+, `uv` for deps, `hatchling` backend, `[project.scripts]` entry point. End users will install with `uv tool install cultureagent`, not `pip install`.
- `argparse` noun-verb subcommand groups, registered under `cultureagent/cli/_commands/`. Use the `_ArgumentParser` override and the `_dispatch` try/except pattern from afi-cli's cite template verbatim — those are stable-contract pieces, not reshape candidates.
- `pytest` + `pytest-asyncio` + `pytest-xdist` + `pytest-cov`. Tests under `tests/`.
- Lint: `black`, `isort`, `flake8` (+ `flake8-bandit`, `flake8-bugbear`), `pylint`, `bandit`, `markdownlint-cli2` against a repo-local `.markdownlint-cli2.yaml`.
- **Cite, don't import.** `packages/agent-harness/` is reference; `cultureagent/clients/<backend>/` owns the working copy. No cross-backend imports. Promote generic improvements back into `packages/`.
- **All-backends rule.** Any feature touching one backend (`claude`, `codex`, `copilot`, `acp`) must be propagated to the other three. A feature that exists in only one backend is a bug. This is inherited from `../culture/CLAUDE.md` and applies whenever the migration brings in backend-specific code.
- **Version bump on every PR**, including docs/config-only. CI fails the `version-check` job if the version matches `main`. Use the `version-bump` skill once vendored from `../steward` (`.claude/skills/version-bump/scripts/bump.py {patch|minor|major}`).
- Publish: push to `main` triggers Trusted-Publishing → PyPI; PRs publish a `.dev<run_number>` to TestPyPI; fork PRs are skipped.
- Doc commits live next to code under `docs/` and are part of the same PR — not a separate "docs sweep" later.

## Skills already vendored

Provenance ledger: `docs/skill-sources.md`. Summary:

- `.claude/skills/cicd/` — copied from `../steward/.claude/skills/cicd/` (steward 0.12.0). As of 0.12.0 the skill is a thin delegate to `agex pr` (in `agentculture/agex-cli`). Entry point: `.claude/skills/cicd/scripts/workflow.sh`. Subcommands: `lint` (portability + alignment-trigger lint on the diff), `open` (`agex pr open --delayed-read` — creates the PR, then polls 180s for the first reviewer briefing), `read [PR] [--wait N]` (one-shot or polling briefing — CI checks, SonarCloud gate, comments, next-step footer), `reply <PR>` (JSONL batch replies + thread-resolve), `delta` (sibling alignment dump), and two steward extensions: `status <PR>` (SonarCloud quality gate + hotspots + unresolved-thread tally) and `await <PR>` (`read --wait` + `status`; exits non-zero on Sonar `ERROR` or unresolved threads). Hard requirement: `agex` (>=0.1) on PATH (`uv tool install agex-cli`). Per-machine paths live in `.claude/skills.local.yaml`; the committed `.claude/skills.local.yaml.example` documents the schema. Local divergence: three extra scripts (`migrate-from-culture.sh`, `_migrate_driver.py`, `_migrate_rewriter.py`) drive the cite-don't-import Phase 0a/0b migration from `../culture`; unrelated to the steward surface.
- `.claude/skills/communicate/` — copied from `../steward/.claude/skills/communicate/` (steward 0.12.0). Cross-repo issue I/O (`post-issue.sh`, `post-comment.sh`, `fetch-issues.sh`) backed by `agtag` (>=0.1, `uv tool install agtag`), plus an unsigned mesh-channel wrapper (`mesh-message.sh`). agtag resolves the signing nick from the local `culture.yaml`; cultureagent does not ship one yet, so signatures fall back to repo basename `- cultureagent (Claude)`.
- `.claude/skills/version-bump/` — copied verbatim from `../steward/.claude/skills/version-bump/`. Entry point: `python3 .claude/skills/version-bump/scripts/bump.py {patch,minor,major,show}`. Optional stdin: `{"added":[...],"changed":[...],"fixed":[...]}` JSON to populate the new `CHANGELOG.md` entry. Required on every PR — the `version-check` CI job in `.github/workflows/tests.yml` fails the run if `pyproject.toml` still matches `main`.

PR signature convention from the cicd skill: `- <nick> (Claude)`. Until a `culture.yaml` ships here, `agex`/`agtag` fall back to the repo basename (`cultureagent`).

## Common commands

The CLI frame is wired up. Agent-runtime business logic (harness, daemon, supervisor, per-backend clients) migrates from `../culture` in a follow-up PR — see "Migration playbook" below.

| Task                          | Command                                                              |
|-------------------------------|----------------------------------------------------------------------|
| Install for dev               | `uv sync`                                                            |
| Run CLI from source           | `uv run cultureagent ...` (or `uv run python -m cultureagent ...`)   |
| Tests (parallel)              | `uv run pytest -n auto -v`                                           |
| Single test                   | `uv run pytest tests/test_cli.py::test_learn_text_meets_rubric -v`   |
| Coverage                      | `uv run pytest --cov=cultureagent --cov-report=term`                 |
| Format                        | `uv run black cultureagent tests && uv run isort cultureagent tests` |
| Lint Python                   | `uv run flake8 cultureagent tests`                                   |
| Lint security                 | `uv run bandit -c pyproject.toml -r cultureagent`                    |
| Self-doctor (AFI gate)        | `afi cli doctor .` (requires `uv tool install afi-cli`)              |
| Build distribution            | `uv build`                                                           |
| Version bump (PR-required)    | `python3 .claude/skills/version-bump/scripts/bump.py {patch,minor,major}` |
| Lint diff for portability     | `bash .claude/skills/cicd/scripts/workflow.sh lint`                  |
| Open a PR + reviewer wait     | `bash .claude/skills/cicd/scripts/workflow.sh open --title T ...`    |
| Read PR briefing (CI + comments) | `bash .claude/skills/cicd/scripts/workflow.sh read <PR>`          |
| Wait for reviewers, dump CI   | `bash .claude/skills/cicd/scripts/workflow.sh await <PR>`            |
| SonarCloud / threads gate     | `bash .claude/skills/cicd/scripts/workflow.sh status <PR>`           |
| Reply + resolve threads       | `bash .claude/skills/cicd/scripts/workflow.sh reply <PR> < replies.jsonl` |
| Sibling alignment-delta dump  | `bash .claude/skills/cicd/scripts/workflow.sh delta`                 |
| Post a cross-repo issue       | `bash .claude/skills/communicate/scripts/post-issue.sh --repo O/R --title T --body-file F` |
| Comment on a cross-repo issue | `bash .claude/skills/communicate/scripts/post-comment.sh --repo O/R --number N --body-file F` |
| Fetch sibling-repo issues     | `bash .claude/skills/communicate/scripts/fetch-issues.sh --repo O/R 14 15` |

`tests/test_self_doctor.py` runs `afi cli doctor .` as a subprocess and **skips** when `afi` isn't on PATH — install it locally to enforce the rubric before opening a PR.

## Migration playbook (when asked to bring something over from culture)

For any harness component being migrated:

1. Pull **both** layers — the citation-pattern reference at `../culture/packages/agent-harness/<file>.py` and each per-backend working copy at `../culture/culture/clients/<backend>/<file>.py`. The reference is generic; the per-backend file is the live one.
2. Land them at the corresponding paths here: `packages/agent-harness/<file>.py` and `cultureagent/clients/<backend>/<file>.py`. Preserve the cite-don't-import seam — no imports across backends.
3. Rewrite `culture.clients.<backend>.*` imports to `cultureagent.clients.<backend>.*` and shared imports (e.g. `culture.aio`, `culture.cli.shared.constants`) to whatever the migrated equivalent is here. The first migration PR has to decide where shared utilities land — flag this in the PR body.
4. Apply the all-backends rule: if you touch the claude harness, the codex/copilot/acp copies need the equivalent change in the same PR (or an explicit follow-up issue tracking the gap).
5. Update `docs/reference/architecture/agent-harness-spec.md` (or its successor in this repo) so the spec reflects the new home before the PR merges. Doc gaps in agent-runtime PRs land in the first review round otherwise.
6. Bump the version (`patch` is the correct level for a pure-migration PR with no behavior change).
