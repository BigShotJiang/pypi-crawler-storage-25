"""Public-surface contract for `SkillClient` (since 0.6.0).

Pins what docs/api-stability.md declares stable. Uses
``inspect.Signature.bind`` for dry-run signature validation so the
tests don't need a live daemon socket.

Wire-level behavior is covered by ``tests/test_skill_irc_client_cli.py``;
this file is the contract surface only.
"""

from __future__ import annotations

import inspect

import pytest

from cultureagent.clients.shared.skill_irc_client import SkillClient


def test_skill_client_constructor_signature():
    """`SkillClient(sock_path: str)` — single positional, no required kwargs."""
    sig = inspect.signature(SkillClient.__init__)
    # `self` + `sock_path`
    params = list(sig.parameters.values())
    assert params[0].name == "self"
    assert params[1].name == "sock_path"
    # Should be bindable with just a string
    client = SkillClient("/nonexistent/path.sock")
    assert client.sock_path == "/nonexistent/path.sock"


def test_skill_client_pending_whispers_initialized_empty():
    """`pending_whispers` is an instance attribute starting as an empty list."""
    client = SkillClient("/nonexistent/path.sock")
    assert isinstance(client.pending_whispers, list)
    assert client.pending_whispers == []


def test_skill_client_drain_whispers_is_sync():
    """`drain_whispers()` is a regular (non-coroutine) method."""
    client = SkillClient("/nonexistent/path.sock")
    assert not inspect.iscoroutinefunction(client.drain_whispers)
    # Empty drain returns an empty list and leaves pending_whispers cleared
    client.pending_whispers.append({"type": "whisper", "message": "x"})
    out = client.drain_whispers()
    assert out == [{"type": "whisper", "message": "x"}]
    assert client.pending_whispers == []


# ---------------------------------------------------------------------------
# Lifecycle methods
# ---------------------------------------------------------------------------

_LIFECYCLE_METHODS = ["connect", "close"]


@pytest.mark.parametrize("method_name", _LIFECYCLE_METHODS)
def test_lifecycle_method_is_coroutine(method_name):
    method = getattr(SkillClient, method_name)
    assert inspect.iscoroutinefunction(
        method
    ), f"SkillClient.{method_name} must be a coroutine function"


# ---------------------------------------------------------------------------
# IRC operations — coroutine + signature-bind validation
# ---------------------------------------------------------------------------

# (method_name, positional_args, kwargs that must be accepted)
_IRC_METHODS = [
    ("irc_send", ("#general", "hello"), {}),
    ("irc_read", ("#general",), {"limit": 50}),
    ("irc_ask", ("#general", "what time is it?"), {"timeout": 30}),
    ("irc_join", ("#general",), {}),
    ("irc_part", ("#general",), {}),
    ("irc_channels", (), {}),
    ("irc_who", ("nick",), {}),
    ("irc_topic", ("#general",), {"topic": "set me"}),
]


@pytest.mark.parametrize("method_name,args,kwargs", _IRC_METHODS, ids=lambda v: str(v)[:30])
def test_irc_method_is_coroutine(method_name, args, kwargs):
    method = getattr(SkillClient, method_name)
    assert inspect.iscoroutinefunction(
        method
    ), f"SkillClient.{method_name} must be a coroutine function"


@pytest.mark.parametrize("method_name,args,kwargs", _IRC_METHODS, ids=lambda v: str(v)[:30])
def test_irc_method_signature_accepts_documented_args(method_name, args, kwargs):
    """Bind documented args/kwargs against the method signature — no TypeError."""
    method = getattr(SkillClient, method_name)
    sig = inspect.signature(method)
    # First positional is `self`; supply a dummy SkillClient instance
    dummy = SkillClient("/nonexistent/path.sock")
    sig.bind(dummy, *args, **kwargs)


# ---------------------------------------------------------------------------
# Agent control
# ---------------------------------------------------------------------------

_AGENT_METHODS = ["compact", "clear"]


@pytest.mark.parametrize("method_name", _AGENT_METHODS)
def test_agent_control_method_is_coroutine(method_name):
    method = getattr(SkillClient, method_name)
    assert inspect.iscoroutinefunction(
        method
    ), f"SkillClient.{method_name} must be a coroutine function"


# ---------------------------------------------------------------------------
# Negative — methods declared NOT part of the surface
# ---------------------------------------------------------------------------


def test_skill_client_does_not_expose_start_stop_aliases():
    """Pin against accidental aliasing — `start`/`stop` are NOT the lifecycle.

    Issue #17 used `start()`/`stop()` as placeholder names. The actual
    contract uses `connect()`/`close()`; if a future refactor adds
    `start`/`stop` as aliases we want a deliberate review (the docs
    say `connect`/`close`).
    """
    assert not hasattr(SkillClient, "start")
    assert not hasattr(SkillClient, "stop")
