"""Public-surface contract for the four daemon classes (since 0.6.0).

Pins what docs/api-stability.md declares stable:

- Import paths under `cultureagent.clients.<backend>.daemon`.
- Constructor signature: positional `(daemon_config, agent)`,
  shared kwarg `socket_dir`, per-backend `skip_<sdk>`.
- `start()` / `stop()` are coroutine methods.
- `BACKEND_NAME` class attribute matches the backend.

The tests are inspect-based (no live daemon) so they're fast and
SDK-free. They serve as a regression net for the contract — if a
later refactor renames a kwarg or drops `BACKEND_NAME`, these break
loudly.

Optional SDK handling: claude and acp daemons transitively import
``claude_agent_sdk`` at module-import time; codex/copilot daemons
have analogous SDK imports. On minimal-extras installs (CI default
or downstream consumers without the backend extras) those imports
raise ``ModuleNotFoundError``. We mirror the skip-on-missing pattern
from ``tests/harness/test_all_backends_parity.py`` so the suite
collects cleanly regardless of which extras are present.
"""

from __future__ import annotations

import importlib
import inspect
from dataclasses import dataclass

import pytest


@dataclass
class _BackendBundle:
    """All the symbols a parametrized surface test needs for one backend."""

    daemon_cls: type
    daemon_cfg_cls: type
    agent_cfg_cls: type
    agent_backend: str  # the `agent=` field value used inside AgentConfig
    skip_kwarg: str  # the documented `skip_<sdk>` constructor kwarg
    backend_name: str  # expected BACKEND_NAME class attribute


def _try_load_backend(
    backend: str, daemon_module: str, daemon_attr: str, skip_kwarg: str
) -> _BackendBundle | None:
    """Import a backend's daemon + config modules; return None if the
    optional SDK is missing.

    Mirrors the skip-on-ModuleNotFoundError pattern used by
    ``tests/harness/test_all_backends_parity.py`` so collection on
    minimal installs (no `--extra backend-<backend>`) doesn't crash.
    """
    try:
        daemon_mod = importlib.import_module(daemon_module)
        config_mod = importlib.import_module(f"cultureagent.clients.{backend}.config")
    except ModuleNotFoundError:
        return None
    return _BackendBundle(
        daemon_cls=getattr(daemon_mod, daemon_attr),
        daemon_cfg_cls=config_mod.DaemonConfig,
        agent_cfg_cls=config_mod.AgentConfig,
        agent_backend=backend,
        skip_kwarg=skip_kwarg,
        backend_name=backend,
    )


def _build_backend_params():
    """Build the parametrize list, skipping backends whose SDK is absent."""
    specs = [
        ("claude", "cultureagent.clients.claude.daemon", "AgentDaemon", "skip_claude"),
        ("codex", "cultureagent.clients.codex.daemon", "CodexDaemon", "skip_codex"),
        ("copilot", "cultureagent.clients.copilot.daemon", "CopilotDaemon", "skip_copilot"),
        ("acp", "cultureagent.clients.acp.daemon", "ACPDaemon", "skip_agent"),
    ]
    out = []
    for backend, mod, attr, skip in specs:
        bundle = _try_load_backend(backend, mod, attr, skip)
        if bundle is None:
            out.append(
                pytest.param(
                    None,
                    id=backend,
                    marks=pytest.mark.skip(
                        reason=(
                            f"backend={backend}: optional SDK not installed "
                            f"(install with `uv sync --extra backend-{backend}` or "
                            f"`--extra all-backends`)"
                        )
                    ),
                )
            )
        else:
            out.append(pytest.param(bundle, id=backend))
    return out


_BACKENDS = _build_backend_params()


def _make_agent(agent_cfg_cls, agent_backend):
    """Minimal AgentConfig for constructor smoke tests."""
    return agent_cfg_cls(
        nick="surface-test",
        agent=agent_backend,
        directory="/tmp/surface-test",  # NOSONAR — inert; daemon constructed with skip_*=True
        channels=["#general"],
    )


@pytest.mark.parametrize("bundle", _BACKENDS)
def test_daemon_constructor_documented_kwargs(tmp_path, bundle: _BackendBundle):
    """Constructor accepts (daemon_config, agent, socket_dir, skip_<sdk>)."""
    cfg = bundle.daemon_cfg_cls()
    agent = _make_agent(bundle.agent_cfg_cls, bundle.agent_backend)
    daemon = bundle.daemon_cls(cfg, agent, socket_dir=str(tmp_path), **{bundle.skip_kwarg: True})

    assert daemon.config is cfg
    assert daemon.agent is agent
    # skip_<sdk> mirrors onto an attribute of the same name for the three
    # non-ACP daemons; ACP only propagates skip_agent to BaseDaemon.
    if hasattr(daemon, bundle.skip_kwarg):
        assert getattr(daemon, bundle.skip_kwarg) is True


@pytest.mark.parametrize("bundle", _BACKENDS)
def test_daemon_backend_name_class_attribute(bundle: _BackendBundle):
    """`BACKEND_NAME` class attribute matches the documented value."""
    assert bundle.daemon_cls.BACKEND_NAME == bundle.backend_name


@pytest.mark.parametrize("bundle", _BACKENDS)
def test_daemon_start_stop_are_coroutines(bundle: _BackendBundle):
    """`.start` and `.stop` are coroutine functions on the class."""
    assert inspect.iscoroutinefunction(bundle.daemon_cls.start)
    assert inspect.iscoroutinefunction(bundle.daemon_cls.stop)


@pytest.mark.parametrize("bundle", _BACKENDS)
def test_daemon_constructor_rejects_unknown_kwargs(bundle: _BackendBundle):
    """Unknown kwargs raise TypeError — pins the contract negatively."""
    cfg = bundle.daemon_cfg_cls()
    agent = _make_agent(bundle.agent_cfg_cls, bundle.agent_backend)
    with pytest.raises(TypeError):
        bundle.daemon_cls(cfg, agent, totally_made_up_kwarg=True)


def test_acp_daemon_uses_skip_agent_not_skip_acp(tmp_path):
    """ACP intentionally uses `skip_agent`, not `skip_acp` — pin the asymmetry.

    Skipped when the ACP-backend SDK isn't installed (claude_agent_sdk via
    sdk_supervisor is the transitive blocker on minimal installs).
    """
    try:
        from cultureagent.clients.acp.config import AgentConfig, DaemonConfig
        from cultureagent.clients.acp.daemon import ACPDaemon
    except ModuleNotFoundError as exc:
        pytest.skip(f"acp backend SDK not installed: {exc}")

    cfg = DaemonConfig()
    agent = AgentConfig(
        nick="surface-test",
        agent="acp",
        directory="/tmp/surface-test",  # NOSONAR — inert; daemon constructed with skip_agent=True
        channels=["#general"],
    )
    # skip_acp is NOT a documented kwarg
    with pytest.raises(TypeError):
        ACPDaemon(cfg, agent, skip_acp=True)
    # skip_agent IS
    daemon = ACPDaemon(cfg, agent, socket_dir=str(tmp_path), skip_agent=True)
    assert daemon is not None
