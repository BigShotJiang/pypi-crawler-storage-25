"""Test fixtures for cultureagent.

Slim subset of culture's tests/conftest.py covering only what the migrated
harness/transport tests need at the 0.2.0 shared tier:

- ``IRCTestClient`` — minimal raw-TCP IRC client
- ``server`` — agentirc IRCd on an OS-assigned port (no culture bot manager)
- ``make_client`` — factory yielding ``IRCTestClient`` connected to ``server``

Imports are restricted to ``agentirc.*`` and stdlib so this conftest does
not pull anything from the (read-only sibling) ``culture`` repo.
"""

from __future__ import annotations

import asyncio

import pytest_asyncio
from agentirc.config import ServerConfig, TelemetryConfig
from agentirc.ircd import IRCd

# Default total wait for recv_until / recv. Callers needing a different bound
# should wrap their own ``async with asyncio.timeout(...)`` around the call.
RECV_TIMEOUT_SECONDS = 2.0


class IRCTestClient:
    """A minimal IRC test client over raw TCP."""

    def __init__(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        self.reader = reader
        self.writer = writer
        self._buffer = ""

    async def send(self, text: str) -> None:
        self.writer.write(f"{text}\r\n".encode())
        await self.writer.drain()

    # The per-call timeout parameter on recv / recv_all is the test-helper's
    # whole point — each callsite drains or peeks with a different bound.
    # Refactoring callers to wrap each call in ``async with asyncio.timeout()``
    # was tried and broke recv_all's "swallow on timeout" semantics
    # (CancelledError propagates past the except clause). Keep the parameter.
    async def recv(self, timeout: float = 2.0) -> str:  # NOSONAR
        async with asyncio.timeout(timeout):
            while "\r\n" not in self._buffer:
                data = await self.reader.read(4096)
                if not data:
                    raise ConnectionError("Connection closed")
                self._buffer += data.decode()
        line, self._buffer = self._buffer.split("\r\n", 1)
        return line

    async def recv_all(self, timeout: float = 0.5) -> list[str]:  # NOSONAR
        lines = []
        try:
            while True:
                lines.append(await self.recv(timeout=timeout))
        except (asyncio.TimeoutError, ConnectionError):
            pass
        return lines

    async def recv_until(self, marker: str) -> str:
        """Read lines until one contains marker.

        Bounded by ``RECV_TIMEOUT_SECONDS``. For a different bound, wrap the
        call in ``async with asyncio.timeout(...)``.
        """
        collected = []
        try:
            async with asyncio.timeout(RECV_TIMEOUT_SECONDS):
                while True:
                    line = await self.recv()
                    collected.append(line)
                    if marker in line:
                        return "\r\n".join(collected)
        except (asyncio.TimeoutError, TimeoutError, ConnectionError):
            pass
        return "\r\n".join(collected)

    async def count_until_idle(self, marker: str, seconds: float = 1.0) -> int:
        """Read lines until timeout; return count of lines containing marker."""
        count = 0
        try:
            while True:
                line = await self.recv(timeout=seconds)
                if marker in line:
                    count += 1
        except (asyncio.TimeoutError, ConnectionError):
            pass
        return count

    async def close(self) -> None:
        self.writer.close()
        try:
            await self.writer.wait_closed()
        except ConnectionError:
            pass


@pytest_asyncio.fixture
async def server(tmp_path):
    """An agentirc IRCd on an OS-assigned port.

    Uses the stub BotManager that ships with agentirc 9.6 — transport tests
    don't exercise bot behavior, so no culture-side BotManager is wired in.
    """
    config = ServerConfig(
        name="testserv",
        host="127.0.0.1",
        port=0,
        webhook_port=0,
        telemetry=TelemetryConfig(audit_dir=str(tmp_path / "audit")),
    )
    ircd = IRCd(config)
    await ircd.start()
    # Get actual port from OS-assigned random port
    ircd.config.port = ircd._server.sockets[0].getsockname()[1]
    yield ircd
    await ircd.stop()


@pytest_asyncio.fixture
async def make_client(server):
    clients = []

    async def _make(nick: str | None = None, user: str | None = None) -> IRCTestClient:
        reader, writer = await asyncio.open_connection("127.0.0.1", server.config.port)
        client = IRCTestClient(reader, writer)
        if nick:
            await client.send(f"NICK {nick}")
        if user:
            await client.send(f"USER {user} 0 * :{user}")
        if nick and user:
            # Drain welcome messages
            await client.recv_all(timeout=0.5)
        clients.append(client)
        return client

    yield _make

    for c in clients:
        try:
            await c.close()
        except Exception:
            pass
