"""Crash recovery + agent-exit + supervisor-callback tests for BaseDaemon.

Targets ``_record_crash_time``, ``_evaluate_circuit_breaker``,
``_on_agent_exit``, ``_delayed_restart``, ``_capture_agent_status``,
``_on_supervisor_whisper``, ``_on_supervisor_escalation``,
``_handle_roominvite``, and ``_query_agent_status``.

All collaborators (``_webhook``, ``_socket_server``, ``_transport``,
``_agent_runner``) are MagicMock'd post-construction so the tests are
fast and isolated from real IRC / agent SDKs.
"""

from __future__ import annotations

import asyncio
import time
from unittest.mock import AsyncMock, MagicMock

import pytest

from cultureagent.clients.claude.config import AgentConfig, DaemonConfig
from cultureagent.clients.claude.daemon import AgentDaemon
from cultureagent.clients.shared import base_daemon as _bd


@pytest.fixture
def daemon():
    cfg = DaemonConfig()
    agent = AgentConfig(
        nick="test-agent",
        agent="claude",
        directory="/tmp/test",  # NOSONAR — test fixture
        channels=["#general"],
    )
    return AgentDaemon(cfg, agent, skip_claude=True)


# ── _record_crash_time ───────────────────────────────────────────────


@pytest.mark.asyncio
async def test_record_crash_time_appends_and_fires_webhook(daemon):
    daemon._webhook = MagicMock()
    daemon._webhook.fire = AsyncMock()
    await daemon._record_crash_time(exit_code=1)
    assert len(daemon._crash_times) == 1
    daemon._webhook.fire.assert_called_once()
    event = daemon._webhook.fire.call_args[0][0]
    assert event.event_type == "agent_error"


@pytest.mark.asyncio
async def test_record_crash_time_prunes_old_crashes(daemon):
    """Crashes older than CRASH_WINDOW_SECONDS are pruned before append."""
    daemon._webhook = None  # focus on pruning logic
    daemon._crash_times = [time.time() - 1000, time.time() - 500]
    await daemon._record_crash_time(exit_code=2)
    # All pre-existing entries are >300s old → pruned. New entry appended.
    assert len(daemon._crash_times) == 1


@pytest.mark.asyncio
async def test_record_crash_time_no_webhook(daemon):
    daemon._webhook = None
    # Must not crash even without a webhook
    await daemon._record_crash_time(exit_code=42)
    assert len(daemon._crash_times) == 1


# ── _evaluate_circuit_breaker ────────────────────────────────────────


@pytest.mark.asyncio
async def test_circuit_breaker_below_threshold(daemon):
    daemon._crash_times = [time.time()]
    opened = await daemon._evaluate_circuit_breaker()
    assert opened is False
    assert daemon._circuit_open is False


@pytest.mark.asyncio
async def test_circuit_breaker_opens_at_threshold(daemon):
    daemon._webhook = MagicMock()
    daemon._webhook.fire = AsyncMock()
    daemon._crash_times = [time.time()] * _bd.MAX_CRASH_COUNT
    opened = await daemon._evaluate_circuit_breaker()
    assert opened is True
    assert daemon._circuit_open is True
    daemon._webhook.fire.assert_called_once()
    event = daemon._webhook.fire.call_args[0][0]
    assert event.event_type == "agent_spiraling"


@pytest.mark.asyncio
async def test_circuit_breaker_no_webhook(daemon):
    daemon._webhook = None
    daemon._crash_times = [time.time()] * _bd.MAX_CRASH_COUNT
    opened = await daemon._evaluate_circuit_breaker()
    assert opened is True


# ── _on_agent_exit ───────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_on_agent_exit_clean_fires_complete_webhook(daemon):
    daemon._webhook = MagicMock()
    daemon._webhook.fire = AsyncMock()
    await daemon._on_agent_exit(exit_code=0)
    daemon._webhook.fire.assert_called_once()
    event = daemon._webhook.fire.call_args[0][0]
    assert event.event_type == "agent_complete"
    assert daemon._crash_times == []


@pytest.mark.asyncio
async def test_on_agent_exit_crash_below_threshold_schedules_restart(daemon):
    """A crash below the circuit threshold schedules _delayed_restart."""
    daemon._webhook = None
    restart_scheduled = asyncio.Event()

    async def stub_restart():
        restart_scheduled.set()

    daemon._delayed_restart = stub_restart  # type: ignore[assignment]
    await daemon._on_agent_exit(exit_code=1)
    await asyncio.wait_for(restart_scheduled.wait(), timeout=1.0)
    assert daemon._circuit_open is False


@pytest.mark.asyncio
async def test_on_agent_exit_crash_above_threshold_does_not_restart(daemon):
    daemon._webhook = None
    daemon._crash_times = [time.time()] * (_bd.MAX_CRASH_COUNT - 1)
    restart_called = False

    async def stub_restart():
        nonlocal restart_called
        restart_called = True

    daemon._delayed_restart = stub_restart  # type: ignore[assignment]
    await daemon._on_agent_exit(exit_code=1)
    # Pre-existing N-1 crashes + this one == threshold → circuit opens
    assert daemon._circuit_open is True
    # Allow scheduled tasks to run (there shouldn't be any)
    await asyncio.sleep(0)
    assert restart_called is False


# ── _delayed_restart ─────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_delayed_restart_skips_if_circuit_open(daemon, monkeypatch):
    """If the circuit opened during the delay, skip the restart."""
    monkeypatch.setattr(asyncio, "sleep", AsyncMock())  # zero-out the delay
    daemon._circuit_open = True
    daemon._transport = MagicMock()
    daemon._start_agent_runner = AsyncMock()  # type: ignore[assignment]
    await daemon._delayed_restart()
    daemon._start_agent_runner.assert_not_called()


@pytest.mark.asyncio
async def test_delayed_restart_skips_if_no_transport(daemon, monkeypatch):
    """If transport disconnected during the delay, skip the restart."""
    monkeypatch.setattr(asyncio, "sleep", AsyncMock())
    daemon._circuit_open = False
    daemon._transport = None
    daemon._start_agent_runner = AsyncMock()  # type: ignore[assignment]
    await daemon._delayed_restart()
    daemon._start_agent_runner.assert_not_called()


@pytest.mark.asyncio
async def test_delayed_restart_calls_start_agent_runner(daemon, monkeypatch):
    monkeypatch.setattr(asyncio, "sleep", AsyncMock())
    daemon._circuit_open = False
    daemon._transport = MagicMock()
    daemon._start_agent_runner = AsyncMock()  # type: ignore[assignment]
    await daemon._delayed_restart()
    daemon._start_agent_runner.assert_called_once()


# ── _capture_agent_status ────────────────────────────────────────────


def test_capture_agent_status_dict_block(daemon):
    msg = {"type": "assistant", "content": [{"type": "text", "text": "working on X"}]}
    daemon._capture_agent_status(msg)
    assert daemon._last_activity_text == "working on X"


def test_capture_agent_status_string_block(daemon):
    msg = {"type": "assistant", "content": ["bare string content"]}
    daemon._capture_agent_status(msg)
    assert daemon._last_activity_text == "bare string content"


def test_capture_agent_status_non_assistant_ignored(daemon):
    msg = {"type": "user", "content": [{"type": "text", "text": "from-user"}]}
    daemon._capture_agent_status(msg)
    assert daemon._last_activity_text == ""


def test_capture_agent_status_fulfills_pending_query(daemon):
    daemon._status_query_event = asyncio.Event()
    msg = {"type": "assistant", "content": [{"type": "text", "text": "answer"}]}
    daemon._capture_agent_status(msg)
    assert daemon._status_query_response == "answer"
    assert daemon._status_query_event.is_set()


# ── _on_supervisor_whisper / _on_supervisor_escalation ───────────────


@pytest.mark.asyncio
async def test_on_supervisor_whisper_dispatches_to_socket(daemon):
    daemon._socket_server = MagicMock()
    daemon._socket_server.send_whisper = AsyncMock()
    await daemon._on_supervisor_whisper("nudge", "warning")
    daemon._socket_server.send_whisper.assert_called_once_with("nudge", "warning")


@pytest.mark.asyncio
async def test_on_supervisor_whisper_no_socket(daemon):
    daemon._socket_server = None
    await daemon._on_supervisor_whisper("nudge", "warning")  # no crash


@pytest.mark.asyncio
async def test_on_supervisor_escalation_fires_webhook(daemon):
    daemon._webhook = MagicMock()
    daemon._webhook.fire = AsyncMock()
    await daemon._on_supervisor_escalation("agent looping")
    daemon._webhook.fire.assert_called_once()
    event = daemon._webhook.fire.call_args[0][0]
    assert event.event_type == "agent_spiraling"
    assert "[ESCALATION]" in event.message


@pytest.mark.asyncio
async def test_on_supervisor_escalation_no_webhook(daemon):
    daemon._webhook = None
    await daemon._on_supervisor_escalation("agent looping")  # no crash


# ── _handle_roominvite (claude path — uses real LLM, but auto-joins
#    when no agent_runner is active) ───────────────────────────────────


@pytest.mark.asyncio
async def test_handle_roominvite_auto_joins_when_no_runner(daemon):
    """When no agent runner is active, room invites auto-join."""
    daemon._agent_runner = None
    daemon._transport = MagicMock()
    daemon._transport.send_raw = AsyncMock()
    await daemon._handle_roominvite("#newroom", "purpose=test\ninstructions=join")
    daemon._transport.send_raw.assert_called_once_with("JOIN #newroom")


@pytest.mark.asyncio
async def test_handle_roominvite_runner_not_running_auto_joins(daemon):
    daemon._agent_runner = MagicMock()
    daemon._agent_runner.is_running = MagicMock(return_value=False)
    daemon._transport = MagicMock()
    daemon._transport.send_raw = AsyncMock()
    await daemon._handle_roominvite("#newroom", "purpose=test")
    daemon._transport.send_raw.assert_called_once_with("JOIN #newroom")


@pytest.mark.asyncio
async def test_handle_roominvite_sends_evaluation_prompt(daemon):
    daemon._agent_runner = MagicMock()
    daemon._agent_runner.is_running = MagicMock(return_value=True)
    daemon._agent_runner.send_prompt = AsyncMock()
    daemon._transport = MagicMock()
    daemon._transport.send_raw = AsyncMock()
    await daemon._handle_roominvite(
        "#research", "purpose=hack\ninstructions=join if you want\ntags=ai,ml"
    )
    daemon._agent_runner.send_prompt.assert_called_once()
    prompt = daemon._agent_runner.send_prompt.call_args[0][0]
    assert "#research" in prompt
    assert "hack" in prompt
    daemon._transport.send_raw.assert_not_called()


# ── _query_agent_status ──────────────────────────────────────────────


@pytest.mark.asyncio
async def test_query_agent_status_no_runner(daemon):
    daemon._agent_runner = None
    assert await daemon._query_agent_status() == "nothing"


@pytest.mark.asyncio
async def test_query_agent_status_timeout_returns_busy(daemon, monkeypatch):
    """When the agent doesn't respond within the timeout, return 'busy'."""
    import contextlib

    daemon._agent_runner = MagicMock()
    daemon._agent_runner.is_running = MagicMock(return_value=True)
    daemon._agent_runner.send_prompt = AsyncMock()

    @contextlib.asynccontextmanager
    async def fake_timeout(_seconds):
        raise asyncio.TimeoutError()
        yield  # unreachable, satisfies the asynccontextmanager protocol

    monkeypatch.setattr(asyncio, "timeout", fake_timeout)
    result = await daemon._query_agent_status()
    assert result == "busy (no response)"
    # State is cleaned up after timeout
    assert daemon._status_query_event is None


@pytest.mark.asyncio
async def test_query_agent_status_returns_first_line(daemon):
    daemon._agent_runner = MagicMock()
    daemon._agent_runner.is_running = MagicMock(return_value=True)

    async def fake_send_prompt(_):
        # Simulate the agent calling _capture_agent_status with its response
        daemon._capture_agent_status(
            {"type": "assistant", "content": [{"type": "text", "text": "writing docs"}]}
        )

    daemon._agent_runner.send_prompt = AsyncMock(side_effect=fake_send_prompt)
    result = await daemon._query_agent_status()
    assert result == "writing docs"


# ── _on_agent_message (shared bucket-A path; QueuedBaseDaemon overrides
#    _handle_agent_message_pre_supervisor — claude shape is no-op pre) ─


@pytest.mark.asyncio
async def test_on_agent_message_invokes_supervisor_and_captures(daemon):
    daemon._supervisor = MagicMock()
    daemon._supervisor.observe = AsyncMock()
    msg = {"type": "assistant", "content": [{"type": "text", "text": "done"}]}
    await daemon._on_agent_message(msg)
    daemon._supervisor.observe.assert_called_once_with(msg)
    assert daemon._last_activity_text == "done"


@pytest.mark.asyncio
async def test_on_agent_message_no_supervisor(daemon):
    daemon._supervisor = None
    msg = {"type": "assistant", "content": [{"type": "text", "text": "done"}]}
    await daemon._on_agent_message(msg)  # no crash
    assert daemon._last_activity_text == "done"


# ── _truncate_first_line (static helper) ─────────────────────────────


def test_truncate_first_line_short():
    assert AgentDaemon._truncate_first_line("hello world") == "hello world"


def test_truncate_first_line_multiline():
    assert AgentDaemon._truncate_first_line("first\nsecond") == "first"


def test_truncate_first_line_long():
    long = "x" * 200
    out = AgentDaemon._truncate_first_line(long, max_len=20)
    assert len(out) == 20
    assert out.endswith("...")
