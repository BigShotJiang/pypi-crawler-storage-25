"""Mention / poll / attention routing tests for ``BaseDaemon`` internals.

These exercise the synchronous-shape methods (``_on_mention``, ``_on_ambient``,
``_on_outgoing``, ``_build_*_prompt``, ``_send_channel_poll``,
``_tick_attention_poll``, ``_check_mention_warnings``) without bringing up
a full daemon — instantiate an ``AgentDaemon`` with ``skip_claude=True``
then patch in fake transport / buffer / agent_runner collaborators.

The queued-routing variants live in ``QueuedBaseDaemon``; we use the
``AgentDaemon`` (claude) instance which inherits ``BaseDaemon`` directly,
so the synchronous routing methods are exercised verbatim.
"""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock

import pytest

from cultureagent.clients.claude.config import AgentConfig, DaemonConfig
from cultureagent.clients.claude.daemon import AgentDaemon
from cultureagent.clients.shared.attention import Band


@pytest.fixture
def daemon():
    cfg = DaemonConfig()
    agent = AgentConfig(
        nick="test-agent",
        agent="claude",
        directory="/tmp/test",  # NOSONAR — test fixture
        channels=["#general", "#dev"],
    )
    return AgentDaemon(cfg, agent, skip_claude=True)


# ── _on_outgoing / _on_ambient ────────────────────────────────────────


def test_on_outgoing_records_engagement(daemon):
    daemon._on_outgoing("#general", "hi")
    assert "#general" in daemon._last_engaged_at


def test_on_ambient_without_engagement_is_skipped(daemon):
    """Ambient stimulus on a target the agent hasn't engaged with is ignored."""
    daemon._attention = MagicMock()
    daemon._on_ambient("#unseen", "alice", "hi")
    daemon._attention.on_ambient.assert_not_called()


def test_on_ambient_outside_thread_window_skipped(daemon):
    """If the last engagement is older than thread_window_s, ignore the ambient.

    Anchors the "long ago" timestamp to ``time.monotonic() - 5000`` so the
    assertion holds even on CI hosts that just booted (where ``monotonic()``
    could be small enough that ``now - 0.0`` is below thread_window_s=1800).
    """
    import time as _time

    daemon._attention = MagicMock()
    daemon._last_engaged_at["#general"] = _time.monotonic() - 5000
    daemon._on_ambient("#general", "alice", "hi")
    daemon._attention.on_ambient.assert_not_called()


def test_on_ambient_within_window_calls_attention(daemon):
    """When engaged recently, on_ambient should hit attention.on_ambient."""
    import time as _time

    daemon._attention = MagicMock()
    daemon._last_engaged_at["#general"] = _time.monotonic()
    daemon._on_ambient("#general", "alice", "hi")
    daemon._attention.on_ambient.assert_called_once()


# ── _on_mention ───────────────────────────────────────────────────────


def test_on_mention_paused_short_circuits(daemon):
    daemon._paused = True
    daemon._attention = MagicMock()
    # last_engaged_at should still be updated (engagement is tracked even when paused).
    daemon._on_mention("#general", "alice", "hello @test-agent")
    assert "#general" in daemon._last_engaged_at


def test_on_mention_no_runner_short_circuits(daemon):
    daemon._agent_runner = None
    daemon._attention = MagicMock()
    daemon._on_mention("#general", "alice", "hello @test-agent")
    # No prompt dispatched; _last_activation should remain None.
    assert daemon._last_activation is None


def test_on_mention_dispatches_channel_prompt(daemon):
    daemon._attention = MagicMock()
    daemon._agent_runner = MagicMock()
    daemon._agent_runner.is_running = MagicMock(return_value=True)
    daemon._agent_runner.send_prompt = AsyncMock()

    async def run():
        daemon._on_mention("#general", "alice", "hello @test-agent")
        # Allow background task to run
        await asyncio.sleep(0)
        # The task was added to _background_tasks then dispatched
        for task in list(daemon._background_tasks):
            await task

    asyncio.run(run())
    assert daemon._last_activation is not None
    daemon._agent_runner.send_prompt.assert_called_once()
    prompt = daemon._agent_runner.send_prompt.call_args[0][0]
    assert "[IRC @mention in #general]" in prompt
    assert "<alice> hello @test-agent" in prompt


def test_on_mention_dispatches_dm_prompt(daemon):
    daemon._attention = MagicMock()
    daemon._agent_runner = MagicMock()
    daemon._agent_runner.is_running = MagicMock(return_value=True)
    daemon._agent_runner.send_prompt = AsyncMock()

    async def run():
        daemon._on_mention("alice", "alice", "hi there")
        await asyncio.sleep(0)
        for task in list(daemon._background_tasks):
            await task

    asyncio.run(run())
    daemon._agent_runner.send_prompt.assert_called_once()
    prompt = daemon._agent_runner.send_prompt.call_args[0][0]
    assert "[IRC DM]" in prompt
    assert "<alice> hi there" in prompt


# ── _build_channel_prompt / _build_dm_prompt ─────────────────────────


def test_build_channel_prompt_plain(daemon):
    out = daemon._build_channel_prompt("#general", "alice", "hello")
    assert out == "[IRC @mention in #general] <alice> hello"


def test_build_channel_prompt_with_thread(daemon):
    """A [thread:NAME] prefix includes the thread history in the prompt."""
    thread_msg = MagicMock(nick="bob", text="prior message")
    daemon._buffer = MagicMock()
    daemon._buffer.read_thread = MagicMock(return_value=[thread_msg])
    out = daemon._build_channel_prompt("#general", "alice", "[thread:t1] follow-up question")
    assert "thread:t1" in out
    assert "<bob> prior message" in out
    assert "<alice> [thread:t1] follow-up question" in out


def test_build_channel_prompt_thread_no_buffer(daemon):
    """If the buffer is None, thread tags fall back to the plain channel format."""
    daemon._buffer = None
    out = daemon._build_channel_prompt("#general", "alice", "[thread:t1] hi")
    assert out == "[IRC @mention in #general] <alice> [thread:t1] hi"


def test_build_dm_prompt():
    assert AgentDaemon._build_dm_prompt("alice", "ping") == "[IRC DM] <alice> ping"


# ── _on_attention_transition ──────────────────────────────────────────


def test_on_attention_transition_logs_without_metrics(daemon, caplog):
    daemon._metrics = None
    with caplog.at_level("INFO", logger="cultureagent.clients.shared.base_daemon"):
        daemon._on_attention_transition("#general", Band.WARM, Band.HOT, "direct")
    assert any("attention:" in r.message for r in caplog.records)


def test_on_attention_transition_emits_metric(daemon):
    counter = MagicMock()
    daemon._metrics = MagicMock(attention_transitions=counter)
    daemon._on_attention_transition("#general", Band.WARM, Band.HOT, "direct")
    counter.add.assert_called_once()
    kwargs = counter.add.call_args.kwargs
    assert kwargs["attributes"]["from_band"] == "WARM"
    assert kwargs["attributes"]["to_band"] == "HOT"
    assert kwargs["attributes"]["cause"] == "direct"


# ── _tick_attention_poll / _poll_due_target ──────────────────────────


def test_tick_attention_poll_skips_when_paused(daemon):
    daemon._paused = True
    daemon._attention = MagicMock()
    daemon._tick_attention_poll()
    daemon._attention.due_targets.assert_not_called()


def test_tick_attention_poll_skips_when_no_runner(daemon):
    daemon._paused = False
    daemon._agent_runner = None
    daemon._attention = MagicMock()
    daemon._tick_attention_poll()
    daemon._attention.due_targets.assert_not_called()


def test_tick_attention_poll_skips_when_attention_none(daemon):
    daemon._paused = False
    daemon._agent_runner = MagicMock()
    daemon._agent_runner.is_running = MagicMock(return_value=True)
    daemon._attention = None
    # Should silently no-op (not raise).
    daemon._tick_attention_poll()


def test_poll_due_target_marks_and_emits_metric(daemon):
    """_poll_due_target should call mark_polled and add to attention_polls."""
    daemon._send_channel_poll = MagicMock()  # type: ignore[assignment]
    snapshot_entry = MagicMock(band=Band.HOT)
    daemon._attention = MagicMock()
    daemon._attention.snapshot = MagicMock(return_value={"#general": snapshot_entry})
    counter = MagicMock()
    daemon._metrics = MagicMock(attention_polls=counter)
    daemon._poll_due_target("#general", now=100.0)
    daemon._send_channel_poll.assert_called_once_with("#general")
    daemon._attention.mark_polled.assert_called_once_with("#general", 100.0)
    counter.add.assert_called_once()


def test_poll_due_target_no_metrics_is_safe(daemon):
    daemon._send_channel_poll = MagicMock()  # type: ignore[assignment]
    daemon._attention = MagicMock()
    daemon._metrics = None
    daemon._poll_due_target("#general", now=1.0)
    # No assertions — just verify no crash.


# ── _send_channel_poll / _process_poll_cycle / _legacy_poll_loop ─────


def test_send_channel_poll_skips_when_empty_buffer(daemon):
    daemon._buffer = MagicMock()
    daemon._buffer.read = MagicMock(return_value=[])
    daemon._agent_runner = MagicMock()
    daemon._agent_runner.send_prompt = AsyncMock()
    daemon._send_channel_poll("#general")
    daemon._agent_runner.send_prompt.assert_not_called()


def test_send_channel_poll_filters_self_mentions(daemon):
    """Messages that @mention this agent are filtered (handled by mention path)."""
    msg = MagicMock(nick="alice", text="hey @test-agent are you there")
    daemon._buffer = MagicMock()
    daemon._buffer.read = MagicMock(return_value=[msg])
    daemon._agent_runner = MagicMock()
    daemon._agent_runner.send_prompt = AsyncMock()
    daemon._send_channel_poll("#general")
    daemon._agent_runner.send_prompt.assert_not_called()


def test_send_channel_poll_dispatches_prompt(daemon):
    msg = MagicMock(nick="alice", text="random chatter no mention")
    daemon._buffer = MagicMock()
    daemon._buffer.read = MagicMock(return_value=[msg])
    daemon._agent_runner = MagicMock()
    daemon._agent_runner.send_prompt = AsyncMock()

    async def run():
        daemon._send_channel_poll("#general")
        await asyncio.sleep(0)
        for task in list(daemon._background_tasks):
            await task

    asyncio.run(run())
    daemon._agent_runner.send_prompt.assert_called_once()
    prompt = daemon._agent_runner.send_prompt.call_args[0][0]
    assert "IRC Channel Poll" in prompt
    assert "<alice> random chatter no mention" in prompt


def test_process_poll_cycle_skips_when_paused(daemon):
    daemon._paused = True
    daemon._buffer = MagicMock()
    daemon._agent_runner = MagicMock()
    daemon._agent_runner.is_running = MagicMock(return_value=True)
    daemon._process_poll_cycle()
    daemon._buffer.read.assert_not_called()


def test_process_poll_cycle_iterates_channels(daemon):
    daemon._paused = False
    daemon._agent_runner = MagicMock()
    daemon._agent_runner.is_running = MagicMock(return_value=True)
    daemon._buffer = MagicMock()
    daemon._buffer.read = MagicMock(return_value=[])
    daemon._process_poll_cycle()
    # Two channels in the fixture → buffer.read called twice
    assert daemon._buffer.read.call_count == 2


# ── _check_mention_warnings ───────────────────────────────────────────


def test_check_mention_warnings_no_buffer(daemon):
    daemon._buffer = None
    assert daemon._check_mention_warnings("hi @alice") == []


def test_check_mention_warnings_known_nick(daemon):
    daemon._buffer = MagicMock()
    daemon._buffer.known_nicks = MagicMock(return_value={"alice"})
    assert daemon._check_mention_warnings("hi @alice") == []


def test_check_mention_warnings_unknown(daemon):
    daemon._buffer = MagicMock()
    daemon._buffer.known_nicks = MagicMock(return_value={"alice"})
    warnings = daemon._check_mention_warnings("hi @ghost")
    assert warnings == ["Mentioned nick not found: ghost"]


# ── _on_roominvite ────────────────────────────────────────────────────


def test_on_roominvite_schedules_task(daemon):
    """_on_roominvite should fire a background task that calls _handle_roominvite."""
    called = asyncio.Event()

    async def stub_handle(channel, meta_text):
        called.set()

    daemon._handle_roominvite = stub_handle  # type: ignore[assignment]

    async def run():
        daemon._on_roominvite("#newroom", "purpose=foo")
        await asyncio.wait_for(called.wait(), timeout=1.0)

    asyncio.run(run())


# ── _build_system_prompt ──────────────────────────────────────────────


def test_build_system_prompt_with_override(daemon):
    daemon.agent.system_prompt = "I am customized."
    assert daemon._build_system_prompt() == "I am customized."


def test_build_system_prompt_default(daemon):
    daemon.agent.system_prompt = ""
    out = daemon._build_system_prompt()
    assert daemon.agent.nick in out
    assert "irc skill" in out
    assert daemon.agent.directory in out
