import asyncio
import re

import pytest

from cultureagent.clients.shared.irc_transport import IRCTransport
from cultureagent.clients.shared.message_buffer import MessageBuffer


@pytest.mark.asyncio
async def test_connect_and_register(server):
    buf = MessageBuffer()
    transport = IRCTransport(
        host="127.0.0.1",
        port=server.config.port,
        nick="testserv-bot",
        user="bot",
        channels=["#general"],
        buffer=buf,
    )
    await transport.connect()
    try:
        await asyncio.sleep(0.3)
        assert transport.connected
        assert "testserv-bot" in server.clients
    finally:
        await transport.disconnect()


@pytest.mark.asyncio
async def test_joins_channels(server):
    buf = MessageBuffer()
    transport = IRCTransport(
        host="127.0.0.1",
        port=server.config.port,
        nick="testserv-bot",
        user="bot",
        channels=["#general", "#dev"],
        buffer=buf,
    )
    await transport.connect()
    try:
        await asyncio.sleep(0.3)
        assert "#general" in server.channels
        assert "#dev" in server.channels
    finally:
        await transport.disconnect()


@pytest.mark.asyncio
async def test_buffers_incoming_messages(server, make_client):
    buf = MessageBuffer()
    transport = IRCTransport(
        host="127.0.0.1",
        port=server.config.port,
        nick="testserv-bot",
        user="bot",
        channels=["#general"],
        buffer=buf,
    )
    await transport.connect()
    await asyncio.sleep(0.3)
    human = await make_client(nick="testserv-ori", user="ori")
    await human.send("JOIN #general")
    await human.recv_all(timeout=0.3)
    await human.send("PRIVMSG #general :hello bot")
    await asyncio.sleep(0.3)
    msgs = buf.read("#general", limit=50)
    assert any(m.text == "hello bot" and m.nick == "testserv-ori" for m in msgs)
    await transport.disconnect()


@pytest.mark.asyncio
async def test_send_privmsg(server, make_client):
    buf = MessageBuffer()
    transport = IRCTransport(
        host="127.0.0.1",
        port=server.config.port,
        nick="testserv-bot",
        user="bot",
        channels=["#general"],
        buffer=buf,
    )
    await transport.connect()
    await asyncio.sleep(0.3)
    human = await make_client(nick="testserv-ori", user="ori")
    await human.send("JOIN #general")
    await human.recv_all(timeout=0.3)
    await transport.send_privmsg("#general", "hello human")
    response = await human.recv(timeout=2.0)
    assert "hello human" in response
    await transport.disconnect()


@pytest.mark.asyncio
async def test_send_join_part(server):
    buf = MessageBuffer()
    transport = IRCTransport(
        host="127.0.0.1",
        port=server.config.port,
        nick="testserv-bot",
        user="bot",
        channels=["#general"],
        buffer=buf,
    )
    await transport.connect()
    await asyncio.sleep(0.3)
    await transport.join_channel("#new")
    await asyncio.sleep(0.2)
    assert "#new" in server.channels
    await transport.part_channel("#new")
    await asyncio.sleep(0.2)
    assert "#new" not in server.channels
    await transport.disconnect()


@pytest.mark.asyncio
async def test_connect_raises_on_refused():
    """Connecting to an unreachable server raises ConnectionError with a clear message."""
    buf = MessageBuffer()
    transport = IRCTransport(
        host="127.0.0.1",
        port=1,  # nothing listens here
        nick="testserv-bot",
        user="bot",
        channels=["#general"],
        buffer=buf,
    )
    with pytest.raises(ConnectionError, match=re.escape("127.0.0.1:1")):
        await transport.connect()


@pytest.mark.asyncio
async def test_reconnect_retries_after_connection_error(server):
    """The reconnect loop retries after ConnectionError instead of crashing."""
    buf = MessageBuffer()
    # Use a port where nothing listens so the first _do_connect fails
    transport = IRCTransport(
        host="127.0.0.1",
        port=1,
        nick="testserv-bot",
        user="bot",
        channels=["#general"],
        buffer=buf,
    )
    transport._should_run = True
    transport._reconnecting = False

    # Patch _do_connect to fail once with ConnectionError, then succeed
    call_count = 0
    original_do_connect = transport._do_connect

    async def patched_do_connect():
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            raise ConnectionError("simulated failure")
        # On retry, connect to the real server
        transport.host = "127.0.0.1"
        transport.port = server.config.port
        await original_do_connect()

    transport._do_connect = patched_do_connect

    # _reconnect should retry and eventually succeed
    await asyncio.wait_for(transport._reconnect(), timeout=5.0)
    assert call_count >= 2
    assert transport.connected or not transport._reconnecting
    await transport.disconnect()


@pytest.mark.asyncio
async def test_multiline_privmsg_splits_into_separate_messages(server, make_client):
    """Multi-line text should be split into separate PRIVMSG lines."""
    buf = MessageBuffer()
    transport = IRCTransport(
        host="127.0.0.1",
        port=server.config.port,
        nick="testserv-bot",
        user="bot",
        channels=["#general"],
        buffer=buf,
    )
    await transport.connect()
    await asyncio.sleep(0.3)
    human = await make_client(nick="testserv-ori", user="ori")
    await human.send("JOIN #general")
    await human.recv_all(timeout=0.3)

    await transport.send_privmsg("#general", "line one\nline two\nline three")
    lines = await human.recv_all(timeout=2.0)
    privmsgs = [l for l in lines if "PRIVMSG" in l]
    assert len(privmsgs) == 3
    assert "line one" in privmsgs[0]
    assert "line two" in privmsgs[1]
    assert "line three" in privmsgs[2]
    await transport.disconnect()


@pytest.mark.asyncio
async def test_multiline_privmsg_skips_empty_lines(server, make_client):
    """Empty lines in multi-line text should be skipped."""
    buf = MessageBuffer()
    transport = IRCTransport(
        host="127.0.0.1",
        port=server.config.port,
        nick="testserv-bot",
        user="bot",
        channels=["#general"],
        buffer=buf,
    )
    await transport.connect()
    await asyncio.sleep(0.3)
    human = await make_client(nick="testserv-ori", user="ori")
    await human.send("JOIN #general")
    await human.recv_all(timeout=0.3)

    await transport.send_privmsg("#general", "first\n\n\nsecond")
    lines = await human.recv_all(timeout=2.0)
    privmsgs = [l for l in lines if "PRIVMSG" in l]
    assert len(privmsgs) == 2
    assert "first" in privmsgs[0]
    assert "second" in privmsgs[1]
    await transport.disconnect()


@pytest.mark.asyncio
async def test_join_rejects_channel_without_hash(server):
    """Joining a channel without # prefix should fail."""
    buf = MessageBuffer()
    transport = IRCTransport(
        host="127.0.0.1",
        port=server.config.port,
        nick="testserv-bot",
        user="bot",
        channels=["#general"],
        buffer=buf,
    )
    await transport.connect()
    try:
        await asyncio.sleep(0.3)
        await transport.join_channel("nohash")
        assert "nohash" not in transport.channels
    finally:
        await transport.disconnect()


@pytest.mark.asyncio
async def test_part_rejects_channel_without_hash(server):
    """Parting a channel without # prefix should be a no-op."""
    buf = MessageBuffer()
    transport = IRCTransport(
        host="127.0.0.1",
        port=server.config.port,
        nick="testserv-bot",
        user="bot",
        channels=["#general"],
        buffer=buf,
    )
    await transport.connect()
    try:
        await asyncio.sleep(0.3)
        await transport.part_channel("nohash")
        # Should not crash or modify state
    finally:
        await transport.disconnect()


@pytest.mark.asyncio
async def test_own_messages_in_buffer(server, make_client):
    """Agent's own sent messages should appear in channel history."""
    buf = MessageBuffer()
    transport = IRCTransport(
        host="127.0.0.1",
        port=server.config.port,
        nick="testserv-bot",
        user="bot",
        channels=["#general"],
        buffer=buf,
    )
    await transport.connect()
    await asyncio.sleep(0.3)

    await transport.send_privmsg("#general", "my own message")
    await asyncio.sleep(0.1)

    msgs = buf.read("#general", limit=50)
    assert any(m.text == "my own message" and m.nick == "testserv-bot" for m in msgs)
    await transport.disconnect()


@pytest.mark.asyncio
async def test_own_dm_messages_in_buffer(server, make_client):
    """Agent's own sent DMs should be buffered under DM:{target}."""
    buf = MessageBuffer()
    transport = IRCTransport(
        host="127.0.0.1",
        port=server.config.port,
        nick="testserv-bot",
        user="bot",
        channels=["#general"],
        buffer=buf,
    )
    await transport.connect()
    await asyncio.sleep(0.3)
    human = await make_client(nick="testserv-ori", user="ori")
    await human.recv_all(timeout=0.3)

    await transport.send_privmsg("testserv-ori", "hello via DM")
    await asyncio.sleep(0.1)

    msgs = buf.read("DM:testserv-ori", limit=50)
    assert any(m.text == "hello via DM" and m.nick == "testserv-bot" for m in msgs)
    await transport.disconnect()


# ─────────────────────────────────────────────────────────────────────
# Writer-mocked unit tests (PR 2b — exercises send_* methods without
# bringing up an in-memory IRCd; covers irc_transport.py:151–203).
# ─────────────────────────────────────────────────────────────────────


from unittest.mock import AsyncMock, MagicMock


def _make_transport_with_mock_writer() -> IRCTransport:
    """Build an IRCTransport with a MagicMock writer so the send_* methods
    can be exercised without a real socket / IRCd."""
    buf = MessageBuffer()
    transport = IRCTransport(
        host="127.0.0.1",
        port=6667,
        nick="testbot",
        user="testbot",
        channels=["#general"],
        buffer=buf,
    )
    writer = MagicMock()
    writer.write = MagicMock()
    writer.drain = AsyncMock()
    transport._writer = writer
    return transport


def _writer_lines(transport: IRCTransport) -> list[str]:
    """Decode bytes passed to writer.write into IRC lines (no trailing CRLF)."""
    return [call.args[0].decode().rstrip("\r\n") for call in transport._writer.write.call_args_list]


@pytest.mark.asyncio
async def test_send_privmsg_multiline_writes_each_line():
    t = _make_transport_with_mock_writer()
    await t.send_privmsg("#general", "first line\nsecond line\n\nthird")
    lines = _writer_lines(t)
    assert lines == [
        "PRIVMSG #general :first line",
        "PRIVMSG #general :second line",
        "PRIVMSG #general :third",
    ]


@pytest.mark.asyncio
async def test_send_privmsg_calls_on_outgoing():
    t = _make_transport_with_mock_writer()
    seen: list = []
    t.on_outgoing = lambda target, line: seen.append((target, line))
    await t.send_privmsg("#general", "hi")
    assert seen == [("#general", "hi")]


@pytest.mark.asyncio
async def test_send_privmsg_dm_buffers_under_dm_prefix():
    t = _make_transport_with_mock_writer()
    await t.send_privmsg("alice", "hello")
    msgs = t.buffer.read("DM:alice", limit=10)
    assert msgs and msgs[0].text == "hello"


@pytest.mark.asyncio
async def test_send_thread_create_first_then_replies():
    t = _make_transport_with_mock_writer()
    await t.send_thread_create("#x", "t1", "first line\nsecond line\nthird line")
    lines = _writer_lines(t)
    assert lines[0] == "THREAD CREATE #x t1 :first line"
    assert lines[1] == "THREAD REPLY #x t1 :second line"
    assert lines[2] == "THREAD REPLY #x t1 :third line"


@pytest.mark.asyncio
async def test_send_thread_create_empty_is_noop():
    t = _make_transport_with_mock_writer()
    await t.send_thread_create("#x", "t1", "\n\n")
    assert _writer_lines(t) == []


@pytest.mark.asyncio
async def test_send_thread_reply_multiline():
    t = _make_transport_with_mock_writer()
    await t.send_thread_reply("#x", "t1", "a\n\nb")
    lines = _writer_lines(t)
    assert lines == ["THREAD REPLY #x t1 :a", "THREAD REPLY #x t1 :b"]


@pytest.mark.asyncio
async def test_send_thread_close_collapses_newlines():
    t = _make_transport_with_mock_writer()
    await t.send_thread_close("#x", "t1", "summary\nwith\nlines")
    lines = _writer_lines(t)
    assert lines == ["THREADCLOSE #x t1 :summary with lines"]


@pytest.mark.asyncio
async def test_send_threads_list():
    t = _make_transport_with_mock_writer()
    await t.send_threads_list("#x")
    assert _writer_lines(t) == ["THREADS #x"]


@pytest.mark.asyncio
async def test_join_channel_appends_to_channels():
    t = _make_transport_with_mock_writer()
    await t.join_channel("#new")
    assert _writer_lines(t) == ["JOIN #new"]
    assert "#new" in t.channels


@pytest.mark.asyncio
async def test_join_channel_bad_prefix_is_noop():
    t = _make_transport_with_mock_writer()
    await t.join_channel("noprefix")
    assert _writer_lines(t) == []


@pytest.mark.asyncio
async def test_join_channel_already_present_is_idempotent():
    t = _make_transport_with_mock_writer()
    assert "#general" in t.channels
    await t.join_channel("#general")
    assert _writer_lines(t) == ["JOIN #general"]
    assert t.channels.count("#general") == 1


@pytest.mark.asyncio
async def test_part_channel_removes_from_channels():
    t = _make_transport_with_mock_writer()
    await t.part_channel("#general")
    assert _writer_lines(t) == ["PART #general"]
    assert "#general" not in t.channels


@pytest.mark.asyncio
async def test_part_channel_bad_prefix_is_noop():
    t = _make_transport_with_mock_writer()
    await t.part_channel("noprefix")
    assert _writer_lines(t) == []


@pytest.mark.asyncio
async def test_part_channel_not_present_still_sends():
    t = _make_transport_with_mock_writer()
    await t.part_channel("#never-joined")
    assert _writer_lines(t) == ["PART #never-joined"]


@pytest.mark.asyncio
async def test_send_who():
    t = _make_transport_with_mock_writer()
    await t.send_who("#general")
    assert _writer_lines(t) == ["WHO #general"]


@pytest.mark.asyncio
async def test_send_topic_set():
    t = _make_transport_with_mock_writer()
    await t.send_topic("#x", "new topic")
    assert _writer_lines(t) == ["TOPIC #x :new topic"]


@pytest.mark.asyncio
async def test_send_topic_query():
    t = _make_transport_with_mock_writer()
    await t.send_topic("#x", None)
    assert _writer_lines(t) == ["TOPIC #x"]


@pytest.mark.asyncio
async def test_send_raw_passes_through():
    t = _make_transport_with_mock_writer()
    await t.send_raw("RAW LINE here")
    assert _writer_lines(t) == ["RAW LINE here"]


@pytest.mark.asyncio
async def test_send_raw_skips_traceparent_prefix_when_no_tracer():
    """Without a tracer configured, send_raw must not prefix anything."""
    t = _make_transport_with_mock_writer()
    t._tracer = None
    await t.send_raw("PRIVMSG #x :hi")
    assert _writer_lines(t) == ["PRIVMSG #x :hi"]


@pytest.mark.asyncio
async def test_send_raw_skips_traceparent_when_line_already_tagged():
    """A line already starting with @ is not re-prefixed even if a tracer is set."""
    t = _make_transport_with_mock_writer()
    t._tracer = MagicMock()
    await t.send_raw("@existing-tag PRIVMSG #x :hi")
    assert _writer_lines(t) == ["@existing-tag PRIVMSG #x :hi"]
