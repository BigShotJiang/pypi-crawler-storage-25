import os
import shutil
import tempfile

import pytest


def test_load_config_from_yaml():
    """Load a complete agents.yaml and verify all fields parse."""
    from cultureagent.clients.claude.config import load_config

    yaml_content = """\
server:
  host: 127.0.0.1
  port: 6667

supervisor:
  model: claude-sonnet-4-6
  thinking: medium
  window_size: 20
  eval_interval: 5
  escalation_threshold: 3

webhooks:
  url: "https://example.com/webhook"
  irc_channel: "#alerts"
  events:
    - agent_spiraling
    - agent_error

buffer_size: 300

agents:
  - nick: spark-culture
    directory: /tmp/test
    channels:
      - "#general"
      - "#dev"
    model: claude-opus-4-6
    thinking: medium
"""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        f.write(yaml_content)
        f.flush()
        try:
            config = load_config(f.name)
            assert config.server.host == "127.0.0.1"
            assert config.server.port == 6667
            assert config.supervisor.model == "claude-sonnet-4-6"
            assert config.supervisor.window_size == 20
            assert config.supervisor.eval_interval == 5
            assert config.supervisor.escalation_threshold == 3
            assert config.webhooks.url == "https://example.com/webhook"
            assert config.webhooks.irc_channel == "#alerts"
            assert len(config.webhooks.events) == 2
            assert config.buffer_size == 300
            assert len(config.agents) == 1
            agent = config.agents[0]
            assert agent.nick == "spark-culture"
            assert (
                agent.directory  # NOSONAR — test fixture using /tmp; not a runtime path
                == "/tmp/test"  # NOSONAR — test fixture using /tmp; not a runtime path
            )  # NOSONAR — test fixture using /tmp; not a runtime path
            assert agent.channels == ["#general", "#dev"]
            assert agent.model == "claude-opus-4-6"
            assert agent.thinking == "medium"
        finally:
            os.unlink(f.name)


def test_load_config_defaults():
    """Missing optional fields get defaults."""
    from cultureagent.clients.claude.config import load_config

    yaml_content = """\
agents:
  - nick: spark-culture
    directory: /tmp
    channels:
      - "#general"
"""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        f.write(yaml_content)
        f.flush()
        try:
            config = load_config(f.name)
            assert config.server.host == "localhost"
            assert config.server.port == 6667
            assert config.supervisor.model == "claude-sonnet-4-6"
            assert config.supervisor.thinking == "medium"
            assert config.supervisor.window_size == 20
            assert config.supervisor.eval_interval == 5
            assert config.supervisor.escalation_threshold == 3
            assert config.webhooks.url is None
            assert config.webhooks.irc_channel == "#alerts"
            assert config.buffer_size == 500
            agent = config.agents[0]
            assert agent.model == "claude-opus-4-6"
            assert agent.thinking == "medium"
        finally:
            os.unlink(f.name)


def test_get_agent_by_nick():
    """Look up an agent config by nick."""
    from cultureagent.clients.claude.config import load_config

    yaml_content = """\
agents:
  - nick: spark-culture
    directory: /tmp/a
    channels: ["#general"]
  - nick: spark-citation-cli
    directory: /tmp/b
    channels: ["#dev"]
"""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        f.write(yaml_content)
        f.flush()
        try:
            config = load_config(f.name)
            agent = config.get_agent("spark-citation-cli")
            assert agent is not None
            assert (  # NOSONAR — test fixture using /tmp; not a runtime path
                agent.directory == "/tmp/b"  # NOSONAR — test fixture using /tmp; not a runtime path
            )  # NOSONAR — test fixture using /tmp; not a runtime path
            assert config.get_agent("nonexistent") is None
        finally:
            os.unlink(f.name)


def test_server_name_field():
    """Load YAML with server.name and verify it parses."""
    from cultureagent.clients.claude.config import load_config

    yaml_content = """\
server:
  name: my-server
  host: 127.0.0.1
  port: 6667

agents: []
"""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        f.write(yaml_content)
        f.flush()
        try:
            config = load_config(f.name)
            assert config.server.name == "my-server"
            assert config.server.host == "127.0.0.1"
            assert config.server.port == 6667
        finally:
            os.unlink(f.name)


def test_server_name_default():
    """Load YAML without server.name and verify default 'culture'."""
    from cultureagent.clients.claude.config import load_config

    yaml_content = """\
server:
  host: 127.0.0.1
  port: 6667

agents: []
"""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        f.write(yaml_content)
        f.flush()
        try:
            config = load_config(f.name)
            assert config.server.name == "culture"
        finally:
            os.unlink(f.name)


def test_sanitize_agent_name():
    """Test sanitize_agent_name with various inputs."""
    from cultureagent.clients.claude.config import sanitize_agent_name

    assert sanitize_agent_name("My Project") == "my-project"
    assert sanitize_agent_name("culture") == "culture"
    assert sanitize_agent_name(".hidden") == "hidden"
    assert sanitize_agent_name("UPPER_case") == "upper-case"

    with pytest.raises(ValueError):
        sanitize_agent_name("")

    with pytest.raises(ValueError):
        sanitize_agent_name("...")


def test_save_and_load_roundtrip():
    """Save a DaemonConfig, load it back, verify all fields match."""
    from cultureagent.clients.claude.config import (
        AgentConfig,
        DaemonConfig,
        ServerConnConfig,
        SupervisorConfig,
        WebhookConfig,
        load_config,
        save_config,
    )

    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmpdir, "config.yaml")

        original = DaemonConfig(
            server=ServerConnConfig(  # NOSONAR — hardcoded IP in test fixture (127.0.0.1)
                name="test-server",
                host="10.0.0.1",  # NOSONAR — hardcoded IP in test fixture (127.0.0.1)
                port=6668,  # NOSONAR — hardcoded IP in test fixture (127.0.0.1)
            ),  # NOSONAR — test fixture using /tmp; not a runtime path
            supervisor=SupervisorConfig(model="claude-opus-4-6", thinking="high"),
            webhooks=WebhookConfig(url="https://hook.example.com", irc_channel="#ops"),
            buffer_size=200,
            agents=[
                AgentConfig(
                    nick="spark-culture",
                    directory="/tmp/work",  # NOSONAR — test fixture using /tmp; not a runtime path
                    channels=["#general", "#dev"],
                    model="claude-opus-4-6",
                    thinking="medium",
                ),
            ],
        )

        save_config(path, original)
        loaded = load_config(path)
        # NOSONAR — hardcoded IP in test fixture (127.0.0.1)
        assert loaded.server.name == "test-server"
        assert (
            loaded.server.host == "10.0.0.1"  # NOSONAR — hardcoded IP in test fixture (127.0.0.1)
        )  # NOSONAR — test fixture using /tmp; not a runtime path
        assert loaded.server.port == 6668
        assert loaded.supervisor.model == "claude-opus-4-6"
        assert loaded.supervisor.thinking == "high"
        assert loaded.webhooks.url == "https://hook.example.com"
        assert loaded.webhooks.irc_channel == "#ops"
        assert loaded.buffer_size == 200
        assert len(loaded.agents) == 1  # NOSONAR — test fixture using /tmp; not a runtime path
        assert loaded.agents[0].nick == "spark-culture"
        assert (
            loaded.agents[0].directory
            == "/tmp/work"  # NOSONAR — test fixture using /tmp; not a runtime path
        )  # NOSONAR — test fixture using /tmp; not a runtime path
        assert loaded.agents[0].channels == ["#general", "#dev"]
    finally:
        shutil.rmtree(tmpdir)


def test_load_config_or_default_missing_file():
    """Nonexistent path returns default config."""
    from cultureagent.clients.claude.config import load_config_or_default

    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmpdir, "nonexistent.yaml")
        config = load_config_or_default(path)
        assert config.server.name == "culture"
        assert config.server.host == "localhost"
        assert config.server.port == 6667
        assert config.agents == []
        assert config.buffer_size == 500
    finally:
        shutil.rmtree(tmpdir)


def test_add_agent_to_empty_config():
    """No file exists, add_agent_to_config creates it with the agent."""
    from cultureagent.clients.claude.config import (
        AgentConfig,
        add_agent_to_config,
        load_config,
    )

    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmpdir, "agents.yaml")
        agent = AgentConfig(
            nick="spark-culture",
            directory="/tmp/work",  # NOSONAR — test fixture using /tmp; not a runtime path
            channels=["#general"],
        )

        config = add_agent_to_config(path, agent)
        assert len(config.agents) == 1
        assert config.agents[0].nick == "spark-culture"

        # Verify file was written
        loaded = load_config(path)
        assert len(loaded.agents) == 1
        assert loaded.agents[0].nick == "spark-culture"
    finally:
        shutil.rmtree(tmpdir)


def test_add_agent_to_existing_config():
    """Existing config with one agent, add second, both preserved."""
    from cultureagent.clients.claude.config import (
        AgentConfig,
        DaemonConfig,
        add_agent_to_config,
        load_config,
        save_config,
    )

    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmpdir, "agents.yaml")

        # Create initial config with one agent  # NOSONAR — test fixture using /tmp; not a runtime path
        initial = DaemonConfig(
            agents=[
                AgentConfig(
                    nick="spark-culture",
                    directory="/tmp/a",  # NOSONAR — test fixture using /tmp; not a runtime path
                    channels=["#general"],  # NOSONAR — test fixture using /tmp; not a runtime path
                ),  # NOSONAR — test fixture using /tmp; not a runtime path
            ],
        )
        save_config(path, initial)

        # Add a second agent
        new_agent = AgentConfig(
            nick="spark-ori",
            directory="/tmp/b",  # NOSONAR — test fixture using /tmp; not a runtime path
            channels=["#dev"],
        )
        config = add_agent_to_config(path, new_agent)
        assert len(config.agents) == 2

        # Verify both agents are persisted
        loaded = load_config(path)
        assert len(loaded.agents) == 2
        nicks = {a.nick for a in loaded.agents}
        assert nicks == {"spark-culture", "spark-ori"}
    finally:
        shutil.rmtree(tmpdir)


def test_add_agent_nick_collision():
    """Duplicate nick raises ValueError."""
    from cultureagent.clients.claude.config import (
        AgentConfig,
        DaemonConfig,
        add_agent_to_config,
        save_config,
    )

    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(
            tmpdir, "agents.yaml"
        )  # NOSONAR — test fixture using /tmp; not a runtime path

        # Create config with existing agent
        initial = DaemonConfig(
            agents=[
                AgentConfig(
                    nick="spark-culture",
                    directory="/tmp/a",  # NOSONAR — test fixture using /tmp; not a runtime path
                    channels=["#general"],  # NOSONAR — test fixture using /tmp; not a runtime path
                ),  # NOSONAR — test fixture using /tmp; not a runtime path
            ],
        )
        save_config(path, initial)

        # Try to add agent with same nick
        duplicate = AgentConfig(
            nick="spark-culture",
            directory="/tmp/b",  # NOSONAR — test fixture using /tmp; not a runtime path
            channels=["#dev"],
        )
        with pytest.raises(ValueError, match="already exists"):
            add_agent_to_config(path, duplicate)
    finally:
        shutil.rmtree(tmpdir)


def test_rename_server_updates_config():
    """rename_server changes server.name and agent nick prefixes."""
    from cultureagent.clients.claude.config import (
        AgentConfig,
        DaemonConfig,
        ServerConnConfig,
        load_config,
        rename_server,
        save_config,
    )

    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmpdir, "agents.yaml")
        save_config(
            path,
            DaemonConfig(
                server=ServerConnConfig(name="culture"),
                agents=[
                    AgentConfig(
                        nick="culture-culture",
                        directory=os.path.join(tmpdir, "a"),
                        channels=["#general"],
                    ),
                ],
            ),
        )

        old_name, renamed = rename_server(path, "spark")
        assert old_name == "culture"
        assert renamed == [("culture-culture", "spark-culture")]

        loaded = load_config(path)
        assert loaded.server.name == "spark"
        assert loaded.agents[0].nick == "spark-culture"
    finally:
        shutil.rmtree(tmpdir)


def test_rename_server_multiple_agents():
    """rename_server renames all agents with the old prefix."""
    from cultureagent.clients.claude.config import (
        AgentConfig,
        DaemonConfig,
        ServerConnConfig,
        rename_server,
        save_config,
    )

    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmpdir, "agents.yaml")
        save_config(
            path,
            DaemonConfig(
                server=ServerConnConfig(name="old"),
                agents=[
                    AgentConfig(
                        nick="old-claude",
                        directory=os.path.join(tmpdir, "a"),
                        channels=["#general"],
                    ),
                    AgentConfig(
                        nick="old-ori", directory=os.path.join(tmpdir, "b"), channels=["#general"]
                    ),
                ],
            ),
        )

        old_name, renamed = rename_server(path, "new")
        assert old_name == "old"
        assert len(renamed) == 2
        assert ("old-claude", "new-claude") in renamed
        assert ("old-ori", "new-ori") in renamed
    finally:
        shutil.rmtree(tmpdir)


def test_rename_server_no_agents():
    """rename_server works with empty agent list."""
    from cultureagent.clients.claude.config import (
        DaemonConfig,
        ServerConnConfig,
        load_config,
        rename_server,
        save_config,
    )

    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmpdir, "agents.yaml")
        save_config(
            path,
            DaemonConfig(server=ServerConnConfig(name="culture"), agents=[]),
        )

        old_name, renamed = rename_server(path, "spark")
        assert old_name == "culture"
        assert renamed == []

        loaded = load_config(path)
        assert loaded.server.name == "spark"
    finally:
        shutil.rmtree(tmpdir)


def test_rename_server_noop_same_name():
    """rename_server is a no-op when the name hasn't changed."""
    from cultureagent.clients.claude.config import (
        AgentConfig,
        DaemonConfig,
        ServerConnConfig,
        rename_server,
        save_config,
    )

    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmpdir, "agents.yaml")
        save_config(
            path,
            DaemonConfig(
                server=ServerConnConfig(name="spark"),
                agents=[
                    AgentConfig(
                        nick="spark-claude",
                        directory=os.path.join(tmpdir, "a"),
                        channels=["#general"],
                    ),
                ],
            ),
        )

        old_name, renamed = rename_server(path, "spark")
        assert old_name == "spark"
        assert renamed == []
    finally:
        shutil.rmtree(tmpdir)


def test_rename_agent_suffix():
    """rename_agent changes the nick while keeping the same server prefix."""
    from cultureagent.clients.claude.config import (
        AgentConfig,
        DaemonConfig,
        ServerConnConfig,
        load_config,
        rename_agent,
        save_config,
    )

    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmpdir, "agents.yaml")
        save_config(
            path,
            DaemonConfig(
                server=ServerConnConfig(name="spark"),
                agents=[
                    AgentConfig(
                        nick="spark-culture",
                        directory=os.path.join(tmpdir, "a"),
                        channels=["#general"],
                    ),
                ],
            ),
        )

        rename_agent(path, "spark-culture", "spark-claude")

        loaded = load_config(path)
        assert loaded.agents[0].nick == "spark-claude"
    finally:
        shutil.rmtree(tmpdir)


def test_rename_agent_reassign_server():
    """rename_agent can move an agent to a different server prefix."""
    from cultureagent.clients.claude.config import (
        AgentConfig,
        DaemonConfig,
        ServerConnConfig,
        load_config,
        rename_agent,
        save_config,
    )

    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmpdir, "agents.yaml")
        save_config(
            path,
            DaemonConfig(
                server=ServerConnConfig(name="culture"),
                agents=[
                    AgentConfig(
                        nick="culture-claude",
                        directory=os.path.join(tmpdir, "a"),
                        channels=["#general"],
                    ),
                ],
            ),
        )

        rename_agent(path, "culture-claude", "spark-claude")

        loaded = load_config(path)
        assert loaded.agents[0].nick == "spark-claude"
    finally:
        shutil.rmtree(tmpdir)


def test_rename_agent_collision():
    """rename_agent raises ValueError on nick collision."""
    from cultureagent.clients.claude.config import (
        AgentConfig,
        DaemonConfig,
        ServerConnConfig,
        rename_agent,
        save_config,
    )

    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmpdir, "agents.yaml")
        save_config(
            path,
            DaemonConfig(
                server=ServerConnConfig(name="spark"),
                agents=[
                    AgentConfig(
                        nick="spark-culture",
                        directory=os.path.join(tmpdir, "a"),
                        channels=["#general"],
                    ),
                    AgentConfig(
                        nick="spark-claude",
                        directory=os.path.join(tmpdir, "b"),
                        channels=["#general"],
                    ),
                ],
            ),
        )

        with pytest.raises(ValueError, match="already exists"):
            rename_agent(path, "spark-culture", "spark-claude")
    finally:
        shutil.rmtree(tmpdir)


def test_rename_agent_not_found():
    """rename_agent raises ValueError when old nick doesn't exist."""
    from cultureagent.clients.claude.config import (
        DaemonConfig,
        ServerConnConfig,
        rename_agent,
        save_config,
    )

    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmpdir, "agents.yaml")
        save_config(
            path,
            DaemonConfig(server=ServerConnConfig(name="spark"), agents=[]),
        )

        with pytest.raises(ValueError, match="not found"):
            rename_agent(path, "spark-culture", "spark-claude")
    finally:
        shutil.rmtree(tmpdir)


# -----------------------------------------------------------------------
# ACP config load_config strips unknown fields (#157)
# -----------------------------------------------------------------------


def test_acp_load_config_strips_unknown_fields():
    """ACP load_config should not crash on YAML with claude-specific fields (#157)."""
    import yaml as _yaml

    from cultureagent.clients.acp.config import load_config

    yaml_content = {
        "server": {"host": "127.0.0.1", "port": 6667},
        "agents": [
            {
                "nick": "spark-daria",
                "agent": "acp",
                "acp_command": ["opencode", "acp"],
                "thinking": "medium",
                "archived": True,
                "archived_at": "2026-01-01",
                "archived_reason": "test",
            }
        ],
    }
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        _yaml.dump(yaml_content, f)
        f.flush()
        try:
            config = load_config(f.name)
            assert len(config.agents) == 1
            assert config.agents[0].nick == "spark-daria"
            assert config.agents[0].acp_command == ["opencode", "acp"]
        finally:
            os.unlink(f.name)


# -----------------------------------------------------------------------
# Out-of-scope: culture-side operator CLI bridge tests (#155, #156)
#
# `_coerce_to_acp_agent` and `_make_backend_config` live in culture's
# operator CLI (culture/cli/agent.py) which doesn't migrate to cultureagent.
# These tests stay here for parity with culture's test suite during the
# cutover window but are skipped — they'll resolve once culture's Phase 1
# either deletes them or moves them next to the operator CLI.
# -----------------------------------------------------------------------

_CULTURE_CLI_BRIDGE_REASON = (
    "culture-side operator CLI bridge — `culture.cli.agent` does not "
    "migrate to cultureagent (Phase 0b spec, sections 4 + 14)."
)


@pytest.mark.skip(reason=_CULTURE_CLI_BRIDGE_REASON)
def test_coerce_to_acp_agent_preserves_icon():
    """_coerce_to_acp_agent copies the icon field (#155)."""


@pytest.mark.skip(reason=_CULTURE_CLI_BRIDGE_REASON)
def test_coerce_to_acp_agent_icon_none():
    """_coerce_to_acp_agent handles icon=None gracefully."""


@pytest.mark.skip(reason=_CULTURE_CLI_BRIDGE_REASON)
def test_make_backend_config_passes_all_fields():
    """_make_backend_config includes supervisor, poll_interval, sleep schedule (#156)."""


# ---------------------------------------------------------------------------
# archive_*/unarchive_* ops (claude-only public surface, helpers in shared/)
# ---------------------------------------------------------------------------


def _write_claude_config_with_agents(tmpdir: str, nicks: list[str]) -> str:
    """Write a minimal claude YAML config with the given agent nicks to a tmp file."""
    from cultureagent.clients.claude.config import AgentConfig, DaemonConfig, save_config

    path = os.path.join(tmpdir, "agents.yaml")
    save_config(
        path,
        DaemonConfig(agents=[AgentConfig(nick=n) for n in nicks]),
    )
    return path


def test_archive_agent_marks_archived():
    from cultureagent.clients.claude.config import archive_agent, load_config

    with tempfile.TemporaryDirectory() as tmpdir:
        path = _write_claude_config_with_agents(tmpdir, ["alice", "bob"])
        archive_agent(path, "bob", reason="retired")
        cfg = load_config(path)
        alice = cfg.get_agent("alice")
        bob = cfg.get_agent("bob")
        assert not alice.archived
        assert bob.archived
        assert bob.archived_reason == "retired"
        assert bob.archived_at  # set to today


def test_archive_agent_not_found_raises():
    from cultureagent.clients.claude.config import archive_agent

    with tempfile.TemporaryDirectory() as tmpdir:
        path = _write_claude_config_with_agents(tmpdir, ["alice"])
        with pytest.raises(ValueError, match="ghost.*not found"):
            archive_agent(path, "ghost")


def test_unarchive_agent_clears_flag():
    from cultureagent.clients.claude.config import archive_agent, load_config, unarchive_agent

    with tempfile.TemporaryDirectory() as tmpdir:
        path = _write_claude_config_with_agents(tmpdir, ["bob"])
        archive_agent(path, "bob", reason="x")
        unarchive_agent(path, "bob")
        bob = load_config(path).get_agent("bob")
        assert not bob.archived
        assert bob.archived_at == ""
        assert bob.archived_reason == ""


def test_unarchive_agent_not_archived_raises():
    from cultureagent.clients.claude.config import unarchive_agent

    with tempfile.TemporaryDirectory() as tmpdir:
        path = _write_claude_config_with_agents(tmpdir, ["bob"])
        with pytest.raises(ValueError, match="not archived"):
            unarchive_agent(path, "bob")


def test_unarchive_agent_not_found_raises():
    from cultureagent.clients.claude.config import unarchive_agent

    with tempfile.TemporaryDirectory() as tmpdir:
        path = _write_claude_config_with_agents(tmpdir, ["alice"])
        with pytest.raises(ValueError, match="ghost.*not found"):
            unarchive_agent(path, "ghost")


def test_archive_server_marks_server_and_all_agents():
    from cultureagent.clients.claude.config import archive_server, load_config

    with tempfile.TemporaryDirectory() as tmpdir:
        path = _write_claude_config_with_agents(tmpdir, ["alice", "bob"])
        archived = archive_server(path, reason="sunset")
        assert sorted(archived) == ["alice", "bob"]
        cfg = load_config(path)
        assert cfg.server.archived
        assert cfg.server.archived_reason == "sunset"
        assert cfg.server.archived_at
        assert all(a.archived for a in cfg.agents)


def test_unarchive_server_clears_server_and_archived_agents_only():
    from cultureagent.clients.claude.config import (
        archive_agent,
        archive_server,
        load_config,
        unarchive_server,
    )

    with tempfile.TemporaryDirectory() as tmpdir:
        path = _write_claude_config_with_agents(tmpdir, ["alice", "bob", "carol"])
        # Pre-archive bob only at the agent level, then archive the server
        # (which marks all three). unarchive_server should clear server
        # plus all three agents.
        archive_agent(path, "bob", reason="old")
        archive_server(path, reason="sunset")
        unarchived = unarchive_server(path)
        assert sorted(unarchived) == ["alice", "bob", "carol"]
        cfg = load_config(path)
        assert not cfg.server.archived
        assert cfg.server.archived_at == ""
        assert all(not a.archived for a in cfg.agents)


def test_remove_agent_missing_raises():
    from cultureagent.clients.claude.config import remove_agent

    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, "missing.yaml")
        with pytest.raises(ValueError, match="not found"):
            remove_agent(path, "ghost")


def test_remove_agent_present_drops_it():
    from cultureagent.clients.claude.config import load_config, remove_agent

    with tempfile.TemporaryDirectory() as tmpdir:
        path = _write_claude_config_with_agents(tmpdir, ["alice", "bob"])
        remove_agent(path, "alice")
        cfg = load_config(path)
        assert [a.nick for a in cfg.agents] == ["bob"]


def test_load_config_or_default_returns_default_when_missing():
    from cultureagent.clients.claude.config import DaemonConfig, load_config_or_default

    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, "absent.yaml")
        cfg = load_config_or_default(path)
        assert isinstance(cfg, DaemonConfig)
        assert cfg.agents == []


def test_cross_backend_load_strips_unknown_top_level_fields():
    """A mixed-backend agents.yaml with claude-only fields must still load
    under codex/copilot without raising TypeError. Regression: shared
    load_config previously passed top-level dicts straight into dataclass
    constructors (Qodo, PR #20).
    """
    from cultureagent.clients.codex import config as codex_config
    from cultureagent.clients.copilot import config as copilot_config

    yaml_content = """\
server:
  host: 127.0.0.1
  port: 6667
  archived: false          # claude-only field
  archived_at: ""          # claude-only field
  archived_reason: ""      # claude-only field
supervisor:
  model: claude-sonnet-4-6
  thinking: medium         # claude-only field
  window_size: 20
telemetry:
  enabled: false
  service_name: culture.harness.codex
agents: []
"""
    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, "mixed.yaml")
        with open(path, "w") as f:
            f.write(yaml_content)

        # Neither backend has ``archived*`` on ServerConnConfig nor
        # ``thinking`` on SupervisorConfig; both should still load.
        codex_cfg = codex_config.load_config(path)
        copilot_cfg = copilot_config.load_config(path)
        assert codex_cfg.server.host == "127.0.0.1"
        assert copilot_cfg.supervisor.window_size == 20
