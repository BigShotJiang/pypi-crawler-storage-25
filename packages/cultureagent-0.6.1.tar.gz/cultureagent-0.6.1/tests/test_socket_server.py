import asyncio
import os
import tempfile

import pytest

from cultureagent.clients.shared.ipc import decode_message, encode_message, make_request
from cultureagent.clients.shared.socket_server import SocketServer


@pytest.mark.asyncio
async def test_socket_server_accepts_connection():
    sock_path = os.path.join(tempfile.mkdtemp(), "test.sock")

    async def handler(msg):  # NOSONAR — SocketServer awaits handler(msg); must be async
        return {"type": "response", "id": msg["id"], "ok": True}

    srv = SocketServer(sock_path, handler)
    await srv.start()
    try:
        reader, writer = await asyncio.open_unix_connection(sock_path)
        req = make_request("irc_channels")
        writer.write(encode_message(req))
        await writer.drain()
        data = await asyncio.wait_for(reader.readline(), timeout=2.0)
        resp = decode_message(data)
        assert resp["ok"] is True
        assert resp["id"] == req["id"]
        writer.close()
        await writer.wait_closed()
    finally:
        await srv.stop()
        os.unlink(sock_path)


@pytest.mark.asyncio
async def test_socket_server_sends_whisper():
    sock_path = os.path.join(tempfile.mkdtemp(), "test.sock")

    async def handler(msg):  # NOSONAR — SocketServer awaits handler(msg); must be async
        return {"type": "response", "id": msg["id"], "ok": True}

    srv = SocketServer(sock_path, handler)
    await srv.start()
    try:
        reader, writer = await asyncio.open_unix_connection(sock_path)
        await srv.send_whisper("You're spiraling", "CORRECTION")
        data = await asyncio.wait_for(reader.readline(), timeout=2.0)
        whisper = decode_message(data)
        assert whisper["type"] == "whisper"
        assert whisper["whisper_type"] == "CORRECTION"
        assert "spiraling" in whisper["message"]
        writer.close()
        await writer.wait_closed()
    finally:
        await srv.stop()
        os.unlink(sock_path)


@pytest.mark.asyncio
async def test_socket_permissions():
    sock_path = os.path.join(tempfile.mkdtemp(), "test.sock")

    async def handler(msg):  # NOSONAR — SocketServer awaits handler(msg); must be async
        return {"type": "response", "id": msg["id"], "ok": True}

    srv = SocketServer(sock_path, handler)
    await srv.start()
    try:
        mode = os.stat(sock_path).st_mode & 0o777
        assert mode == 0o600
    finally:
        await srv.stop()
        os.unlink(sock_path)


# ─────────────────────────────────────────────────────────────────────
# Edge-path coverage (PR 2b — fills socket_server.py's 69 → ~95% gap)
# ─────────────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_start_unlinks_stale_socket_file(tmp_path):
    """start() removes a pre-existing socket file before binding."""
    sock_path = str(tmp_path / "stale.sock")
    # Pre-create a stale file at the socket path (a regular file is fine
    # for the unlink branch; bind would fail without the unlink).
    open(sock_path, "w").close()
    assert os.path.exists(sock_path)

    async def handler(msg):
        return {"type": "response", "id": msg["id"], "ok": True}

    srv = SocketServer(sock_path, handler)
    await srv.start()
    try:
        # If start succeeded, the stale file was unlinked and replaced.
        assert os.path.exists(sock_path)
    finally:
        await srv.stop()


@pytest.mark.asyncio
async def test_handler_exception_returns_error_response(tmp_path):
    """When the handler raises, the client receives a structured error."""
    sock_path = str(tmp_path / "test.sock")

    async def handler(msg):
        raise RuntimeError("handler exploded")

    srv = SocketServer(sock_path, handler)
    await srv.start()
    try:
        reader, writer = await asyncio.open_unix_connection(sock_path)
        req = make_request("irc_channels")
        writer.write(encode_message(req))
        await writer.drain()
        data = await asyncio.wait_for(reader.readline(), timeout=2.0)
        resp = decode_message(data)
        assert resp["ok"] is False
        assert "handler exploded" in resp["error"]
        writer.close()
        await writer.wait_closed()
    finally:
        await srv.stop()


@pytest.mark.asyncio
async def test_blank_line_is_skipped(tmp_path):
    """A blank line decodes to None and is skipped without breaking the loop."""
    sock_path = str(tmp_path / "test.sock")

    handler_calls = []

    async def handler(msg):
        handler_calls.append(msg)
        return {"type": "response", "id": msg["id"], "ok": True}

    srv = SocketServer(sock_path, handler)
    await srv.start()
    try:
        reader, writer = await asyncio.open_unix_connection(sock_path)
        # Send blank line first; server should skip it then process the real one
        writer.write(b"\n")
        writer.write(encode_message(make_request("irc_channels")))
        await writer.drain()
        data = await asyncio.wait_for(reader.readline(), timeout=2.0)
        resp = decode_message(data)
        assert resp["ok"] is True
        assert len(handler_calls) == 1  # blank line did not invoke handler
        writer.close()
        await writer.wait_closed()
    finally:
        await srv.stop()


@pytest.mark.asyncio
async def test_whisper_to_already_connected_client(tmp_path):
    """When a client is already connected, send_whisper writes directly."""
    sock_path = str(tmp_path / "test.sock")

    async def handler(msg):
        return {"type": "response", "id": msg["id"], "ok": True}

    srv = SocketServer(sock_path, handler)
    await srv.start()
    try:
        reader, writer = await asyncio.open_unix_connection(sock_path)
        # Give the server's _handle_client a tick to register this writer
        await asyncio.sleep(0.05)
        await srv.send_whisper("urgent", "ESCALATION")
        data = await asyncio.wait_for(reader.readline(), timeout=2.0)
        whisper = decode_message(data)
        assert whisper["whisper_type"] == "ESCALATION"
        writer.close()
        await writer.wait_closed()
    finally:
        await srv.stop()


@pytest.mark.asyncio
async def test_client_disconnect_during_loop(tmp_path):
    """A client that disconnects mid-read terminates the loop without raising.

    Uses a bounded polling wait rather than a fixed ``asyncio.sleep`` —
    ``_cleanup_client`` runs from the ``finally`` of ``_handle_client``
    which is asynchronously scheduled, so a fixed delay would race on
    slow CI hosts (Qodo PR #22 review).
    """
    sock_path = str(tmp_path / "test.sock")

    async def handler(msg):
        return {"type": "response", "id": msg["id"], "ok": True}

    srv = SocketServer(sock_path, handler)
    await srv.start()
    try:
        reader, writer = await asyncio.open_unix_connection(sock_path)
        # Close the client without sending anything — readline() returns b""
        writer.close()
        await writer.wait_closed()

        async def _wait_for_cleanup():
            while srv._clients:
                await asyncio.sleep(0.01)

        await asyncio.wait_for(_wait_for_cleanup(), timeout=2.0)
        assert srv._clients == []
    finally:
        await srv.stop()


@pytest.mark.asyncio
async def test_send_whisper_queues_when_no_clients(tmp_path):
    """send_whisper with no connected clients enqueues for first-connect delivery."""
    sock_path = str(tmp_path / "test.sock")

    async def handler(msg):
        return {"type": "response", "id": msg["id"], "ok": True}

    srv = SocketServer(sock_path, handler)
    await srv.start()
    try:
        # Send before any client connects
        await srv.send_whisper("queued", "REMINDER")
        # Now connect — should receive the queued whisper
        reader, writer = await asyncio.open_unix_connection(sock_path)
        data = await asyncio.wait_for(reader.readline(), timeout=2.0)
        whisper = decode_message(data)
        assert whisper["whisper_type"] == "REMINDER"
        writer.close()
        await writer.wait_closed()
    finally:
        await srv.stop()
