"""Tests for daemon IPC status, pause, and resume handlers."""

import asyncio

import pytest

from cultureagent.clients.claude.config import AgentConfig, DaemonConfig
from cultureagent.clients.claude.daemon import AgentDaemon


@pytest.fixture
def daemon():
    config = DaemonConfig()
    agent = AgentConfig(
        nick="test-agent",
        agent="claude",
        directory="/tmp/test",  # NOSONAR — test fixture using /tmp; not a runtime path
        channels=["#general"],
    )
    return AgentDaemon(config, agent, skip_claude=True)


@pytest.mark.asyncio
async def test_ipc_status_initial(daemon):
    """Status should report idle and not paused initially."""
    resp = await daemon._ipc_status("req-1", {})
    assert resp["ok"] is True
    data = resp["data"]
    assert data["paused"] is False
    assert data["activity"] == "idle"
    assert data["description"] == "nothing"
    assert data["turn_count"] == 0
    assert data["last_activation"] is None


@pytest.mark.asyncio
async def test_ipc_pause(daemon):
    """Pause should set paused flag."""
    resp = daemon._ipc_pause("req-2", {})
    assert resp["ok"] is True
    assert daemon._paused is True

    status = await daemon._ipc_status("req-3", {})
    assert status["data"]["paused"] is True
    assert status["data"]["activity"] == "paused"
    assert status["data"]["description"] == "paused"


@pytest.mark.asyncio
async def test_ipc_resume(daemon):
    """Resume should clear paused flag."""
    daemon._paused = True
    resp = daemon._ipc_resume("req-4", {})
    assert resp["ok"] is True
    assert daemon._paused is False

    status = await daemon._ipc_status("req-5", {})
    assert status["data"]["paused"] is False
    assert status["data"]["activity"] == "idle"
    assert status["data"]["description"] == "nothing"


def test_on_mention_ignored_when_paused(daemon):
    """Mentions should be ignored when paused."""
    daemon._paused = True
    daemon._on_mention("#general", "someone", "hello")
    assert daemon._last_activation is None


def test_sleep_schedule_parsing(daemon):
    """Sleep schedule should parse valid HH:MM format."""
    result = daemon._parse_sleep_schedule()
    assert result is not None
    sleep_min, wake_min = result
    assert sleep_min == 23 * 60  # 23:00
    assert wake_min == 8 * 60  # 08:00


def test_sleep_schedule_invalid():
    """Invalid sleep schedule should return None."""
    config = DaemonConfig(sleep_start="invalid", sleep_end="08:00")
    agent = AgentConfig(
        nick="test", directory="/tmp"  # NOSONAR — test fixture using /tmp; not a runtime path
    )  # NOSONAR — test fixture using /tmp; not a runtime path
    d = AgentDaemon(config, agent, skip_claude=True)
    assert d._parse_sleep_schedule() is None


@pytest.mark.asyncio
async def test_on_agent_message_captures_activity(daemon):
    """Agent messages should be captured for status reporting."""
    msg = {"type": "assistant", "content": [{"type": "text", "text": "Working on fixing tests"}]}
    await daemon._on_agent_message(msg)
    assert daemon._last_activity_text == "Working on fixing tests"

    status = await daemon._ipc_status("req-6", {})
    assert status["data"]["description"] == "Working on fixing tests"


@pytest.mark.asyncio
async def test_describe_activity_truncates(daemon):
    """Long activity text should be truncated."""
    long_text = "x" * 200
    daemon._last_activity_text = long_text
    desc = daemon._describe_activity()
    assert len(desc) <= 120
    assert desc.endswith("...")


@pytest.mark.asyncio
async def test_ipc_send_rejects_whitespace_only_message(daemon):
    """Whitespace-only messages should be rejected like empty messages."""
    resp = await daemon._ipc_irc_send("req-ws", {"channel": "#general", "message": "   "})
    assert resp["ok"] is False
    assert "message" in resp["error"].lower()


@pytest.mark.asyncio
async def test_ipc_send_rejects_unjoined_channel(daemon):
    """Sending to a channel the agent hasn't joined should fail."""
    from unittest.mock import AsyncMock, MagicMock

    daemon._transport = MagicMock()
    daemon._transport.channels = ["#general"]
    daemon._transport.send_privmsg = AsyncMock()

    resp = await daemon._ipc_irc_send("req-uj", {"channel": "#nonexistent", "message": "hello"})
    assert resp["ok"] is False
    assert "not joined" in resp["error"].lower()
    daemon._transport.send_privmsg.assert_not_called()


@pytest.mark.asyncio
async def test_ipc_topic_set(daemon):
    """Topic set should dispatch to transport."""
    from unittest.mock import AsyncMock, MagicMock

    daemon._transport = MagicMock()
    daemon._transport.send_topic = AsyncMock()

    resp = await daemon._ipc_irc_topic("req-t1", {"channel": "#general", "topic": "New topic"})
    assert resp["ok"] is True
    daemon._transport.send_topic.assert_called_once_with("#general", "New topic")


@pytest.mark.asyncio
async def test_ipc_topic_query(daemon):
    """Topic query (no topic param) should dispatch to transport."""
    from unittest.mock import AsyncMock, MagicMock

    daemon._transport = MagicMock()
    daemon._transport.send_topic = AsyncMock()

    resp = await daemon._ipc_irc_topic("req-t2", {"channel": "#general"})
    assert resp["ok"] is True
    daemon._transport.send_topic.assert_called_once_with("#general", None)


@pytest.mark.asyncio
async def test_ipc_topic_missing_channel(daemon):
    """Topic with missing channel should return an error."""
    resp = await daemon._ipc_irc_topic("req-t3", {})
    assert resp["ok"] is False
    assert "channel" in resp["error"].lower()


# ---------------------------------------------------------------------------
# Extended IPC handler coverage (PR 2b — shared harness tests).
#
# Pattern: instantiate AgentDaemon(...) once via the existing fixture, then
# call each `_ipc_*` handler directly with `(req_id, msg_dict)`. Transport,
# buffer, webhook, and agent_runner collaborators are MagicMock'd in-line per
# test — they live as attributes on the daemon, so post-construction
# assignment works.
# ---------------------------------------------------------------------------


from unittest.mock import AsyncMock, MagicMock

# ── _handle_ipc routing ───────────────────────────────────────────────


@pytest.mark.asyncio
async def test_handle_ipc_unknown_type(daemon):
    """Unknown msg_type returns a structured 'Unknown message type' error."""
    resp = await daemon._handle_ipc({"id": "x", "type": "bogus"})
    assert resp["ok"] is False
    assert "Unknown message type" in resp["error"]


@pytest.mark.asyncio
async def test_handle_ipc_handler_raises(daemon):
    """Handler exceptions are caught and wrapped as ok=False responses."""
    daemon._transport = MagicMock()
    daemon._transport.channels = ["#general"]
    daemon._transport.send_privmsg = AsyncMock(side_effect=RuntimeError("boom"))
    resp = await daemon._handle_ipc(
        {"id": "x", "type": "irc_send", "channel": "#general", "message": "hi"}
    )
    assert resp["ok"] is False
    assert "boom" in resp["error"]


# ── _ipc_irc_send happy path + missing-channel error ─────────────────


@pytest.mark.asyncio
async def test_ipc_send_happy_path(daemon):
    daemon._transport = MagicMock()
    daemon._transport.channels = ["#general"]
    daemon._transport.send_privmsg = AsyncMock()
    daemon._buffer = MagicMock()
    daemon._buffer.known_nicks = MagicMock(return_value={"alice", "bob"})
    resp = await daemon._ipc_irc_send("req", {"channel": "#general", "message": "hi @alice"})
    assert resp["ok"] is True
    assert "warnings" not in resp  # @alice is in known_nicks
    daemon._transport.send_privmsg.assert_called_once_with("#general", "hi @alice")


@pytest.mark.asyncio
async def test_ipc_send_warns_on_unknown_mention(daemon):
    daemon._transport = MagicMock()
    daemon._transport.channels = ["#general"]
    daemon._transport.send_privmsg = AsyncMock()
    daemon._buffer = MagicMock()
    daemon._buffer.known_nicks = MagicMock(return_value={"alice"})
    resp = await daemon._ipc_irc_send("req", {"channel": "#general", "message": "hi @ghost"})
    assert resp["ok"] is True
    assert resp["warnings"] == ["Mentioned nick not found: ghost"]


@pytest.mark.asyncio
async def test_ipc_send_missing_channel(daemon):
    resp = await daemon._ipc_irc_send("req", {"message": "hi"})
    assert resp["ok"] is False
    assert "channel" in resp["error"].lower()


@pytest.mark.asyncio
async def test_ipc_send_dm_to_nick_bypasses_channel_check(daemon):
    """A target that doesn't start with '#' (a DM nick) skips the joined-check."""
    daemon._transport = MagicMock()
    daemon._transport.channels = ["#general"]
    daemon._transport.send_privmsg = AsyncMock()
    daemon._buffer = MagicMock()
    daemon._buffer.known_nicks = MagicMock(return_value=set())
    resp = await daemon._ipc_irc_send("req", {"channel": "alice", "message": "hi"})
    assert resp["ok"] is True
    daemon._transport.send_privmsg.assert_called_once_with("alice", "hi")


# ── _ipc_irc_read ─────────────────────────────────────────────────────


def test_ipc_irc_read_happy_path(daemon):
    msg = MagicMock(nick="alice", text="hi", timestamp=1.0)
    daemon._buffer = MagicMock()
    daemon._buffer.read = MagicMock(return_value=[msg])
    resp = daemon._ipc_irc_read("req", {"channel": "#general", "limit": 10})
    assert resp["ok"] is True
    assert resp["data"]["messages"] == [{"nick": "alice", "text": "hi", "timestamp": 1.0}]


def test_ipc_irc_read_missing_channel(daemon):
    resp = daemon._ipc_irc_read("req", {})
    assert resp["ok"] is False


# ── _ipc_irc_join / part ──────────────────────────────────────────────


@pytest.mark.asyncio
async def test_ipc_irc_join_happy(daemon):
    daemon._transport = MagicMock()
    daemon._transport.join_channel = AsyncMock()
    resp = await daemon._ipc_irc_join("req", {"channel": "#newroom"})
    assert resp["ok"] is True
    daemon._transport.join_channel.assert_called_once_with("#newroom")


@pytest.mark.asyncio
async def test_ipc_irc_join_missing_channel(daemon):
    resp = await daemon._ipc_irc_join("req", {})
    assert resp["ok"] is False
    assert "channel" in resp["error"].lower()


@pytest.mark.asyncio
async def test_ipc_irc_join_bad_prefix(daemon):
    resp = await daemon._ipc_irc_join("req", {"channel": "noprefix"})
    assert resp["ok"] is False
    assert "#" in resp["error"]


@pytest.mark.asyncio
async def test_ipc_irc_part_happy(daemon):
    daemon._transport = MagicMock()
    daemon._transport.part_channel = AsyncMock()
    resp = await daemon._ipc_irc_part("req", {"channel": "#room"})
    assert resp["ok"] is True
    daemon._transport.part_channel.assert_called_once_with("#room")


@pytest.mark.asyncio
async def test_ipc_irc_part_missing_channel(daemon):
    resp = await daemon._ipc_irc_part("req", {})
    assert resp["ok"] is False


@pytest.mark.asyncio
async def test_ipc_irc_part_bad_prefix(daemon):
    resp = await daemon._ipc_irc_part("req", {"channel": "noprefix"})
    assert resp["ok"] is False
    assert "#" in resp["error"]


# ── _ipc_irc_channels / who ───────────────────────────────────────────


def test_ipc_irc_channels(daemon):
    daemon._transport = MagicMock()
    daemon._transport.channels = ["#a", "#b"]
    resp = daemon._ipc_irc_channels("req", {})
    assert resp["ok"] is True
    assert resp["data"] == {"channels": ["#a", "#b"]}


@pytest.mark.asyncio
async def test_ipc_irc_who_happy(daemon):
    daemon._transport = MagicMock()
    daemon._transport.send_who = AsyncMock()
    resp = await daemon._ipc_irc_who("req", {"target": "#general"})
    assert resp["ok"] is True
    daemon._transport.send_who.assert_called_once_with("#general")


@pytest.mark.asyncio
async def test_ipc_irc_who_missing_target(daemon):
    resp = await daemon._ipc_irc_who("req", {})
    assert resp["ok"] is False
    assert "target" in resp["error"].lower()


# ── _ipc_irc_ask ─────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_ipc_irc_ask_fires_question_webhook(daemon):
    daemon._transport = MagicMock()
    daemon._transport.send_privmsg = AsyncMock()
    daemon._webhook = MagicMock()
    daemon._webhook.fire = AsyncMock()
    resp = await daemon._ipc_irc_ask("req", {"channel": "#general", "message": "anyone alive?"})
    assert resp["ok"] is True
    daemon._transport.send_privmsg.assert_called_once_with("#general", "anyone alive?")
    daemon._webhook.fire.assert_called_once()
    event = daemon._webhook.fire.call_args[0][0]
    assert event.event_type == "agent_question"


@pytest.mark.asyncio
async def test_ipc_irc_ask_no_webhook(daemon):
    """Ask works even when no webhook is configured."""
    daemon._transport = MagicMock()
    daemon._transport.send_privmsg = AsyncMock()
    daemon._webhook = None
    resp = await daemon._ipc_irc_ask("req", {"channel": "#general", "message": "ping"})
    assert resp["ok"] is True


@pytest.mark.asyncio
async def test_ipc_irc_ask_missing_channel(daemon):
    resp = await daemon._ipc_irc_ask("req", {"message": "hi"})
    assert resp["ok"] is False


@pytest.mark.asyncio
async def test_ipc_irc_ask_blank_message(daemon):
    resp = await daemon._ipc_irc_ask("req", {"channel": "#x", "message": "   "})
    assert resp["ok"] is False
    assert "message" in resp["error"].lower()


# ── _ipc_irc_thread_* ────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_ipc_thread_create_happy(daemon):
    daemon._transport = MagicMock()
    daemon._transport.send_thread_create = AsyncMock()
    resp = await daemon._ipc_irc_thread_create(
        "req", {"channel": "#x", "thread": "t1", "message": "hi"}
    )
    assert resp["ok"] is True
    daemon._transport.send_thread_create.assert_called_once_with("#x", "t1", "hi")


@pytest.mark.asyncio
async def test_ipc_thread_create_missing_field(daemon):
    resp = await daemon._ipc_irc_thread_create("req", {"channel": "#x", "thread": "t"})
    assert resp["ok"] is False


@pytest.mark.asyncio
async def test_ipc_thread_reply_happy(daemon):
    daemon._transport = MagicMock()
    daemon._transport.send_thread_reply = AsyncMock()
    resp = await daemon._ipc_irc_thread_reply(
        "req", {"channel": "#x", "thread": "t", "message": "yo"}
    )
    assert resp["ok"] is True
    daemon._transport.send_thread_reply.assert_called_once_with("#x", "t", "yo")


@pytest.mark.asyncio
async def test_ipc_thread_reply_missing_field(daemon):
    resp = await daemon._ipc_irc_thread_reply("req", {"channel": "#x", "thread": "t"})
    assert resp["ok"] is False


@pytest.mark.asyncio
async def test_ipc_threads_list_happy(daemon):
    daemon._transport = MagicMock()
    daemon._transport.send_threads_list = AsyncMock()
    resp = await daemon._ipc_irc_threads("req", {"channel": "#x"})
    assert resp["ok"] is True
    daemon._transport.send_threads_list.assert_called_once_with("#x")


@pytest.mark.asyncio
async def test_ipc_threads_list_missing_channel(daemon):
    resp = await daemon._ipc_irc_threads("req", {})
    assert resp["ok"] is False


@pytest.mark.asyncio
async def test_ipc_thread_close_happy(daemon):
    daemon._transport = MagicMock()
    daemon._transport.send_thread_close = AsyncMock()
    resp = await daemon._ipc_irc_thread_close(
        "req", {"channel": "#x", "thread": "t", "summary": "done"}
    )
    assert resp["ok"] is True
    daemon._transport.send_thread_close.assert_called_once_with("#x", "t", "done")


@pytest.mark.asyncio
async def test_ipc_thread_close_missing(daemon):
    resp = await daemon._ipc_irc_thread_close("req", {"channel": "#x"})
    assert resp["ok"] is False


def test_ipc_thread_read_happy(daemon):
    msg = MagicMock(nick="alice", text="hi", timestamp=1.0, thread="t1")
    daemon._buffer = MagicMock()
    daemon._buffer.read_thread = MagicMock(return_value=[msg])
    resp = daemon._ipc_irc_thread_read("req", {"channel": "#x", "thread": "t1"})
    assert resp["ok"] is True
    assert resp["data"]["messages"] == [
        {"nick": "alice", "text": "hi", "timestamp": 1.0, "thread": "t1"}
    ]


def test_ipc_thread_read_missing(daemon):
    resp = daemon._ipc_irc_thread_read("req", {"channel": "#x"})
    assert resp["ok"] is False


# ── _ipc_compact / clear / shutdown ───────────────────────────────────


@pytest.mark.asyncio
async def test_ipc_compact_happy(daemon):
    daemon._agent_runner = MagicMock()
    daemon._agent_runner.is_running = MagicMock(return_value=True)
    daemon._agent_runner.send_prompt = AsyncMock()
    resp = await daemon._ipc_compact("req", {})
    assert resp["ok"] is True
    daemon._agent_runner.send_prompt.assert_called_once_with("/compact")


@pytest.mark.asyncio
async def test_ipc_compact_no_runner(daemon):
    daemon._agent_runner = None
    resp = await daemon._ipc_compact("req", {})
    assert resp["ok"] is False
    assert "not running" in resp["error"]


@pytest.mark.asyncio
async def test_ipc_clear_happy(daemon):
    daemon._agent_runner = MagicMock()
    daemon._agent_runner.is_running = MagicMock(return_value=True)
    daemon._agent_runner.send_prompt = AsyncMock()
    resp = await daemon._ipc_clear("req", {})
    assert resp["ok"] is True
    daemon._agent_runner.send_prompt.assert_called_once_with("/clear")


@pytest.mark.asyncio
async def test_ipc_clear_no_runner(daemon):
    daemon._agent_runner = None
    resp = await daemon._ipc_clear("req", {})
    assert resp["ok"] is False


@pytest.mark.asyncio
async def test_ipc_shutdown_schedules_graceful(daemon):
    """_ipc_shutdown returns ok and schedules _graceful_shutdown.

    Stub _graceful_shutdown so the scheduled task doesn't try to tear down
    a half-built daemon.
    """
    called = asyncio.Event()

    async def fake_shutdown():
        called.set()

    daemon._graceful_shutdown = fake_shutdown  # type: ignore[assignment]
    resp = daemon._ipc_shutdown("req", {})
    assert resp["ok"] is True
    # Yield to let the scheduled task run
    await asyncio.wait_for(called.wait(), timeout=1.0)


# ── _graceful_shutdown ───────────────────────────────────────────────


@pytest.mark.asyncio
async def test_graceful_shutdown_with_stop_event(daemon):
    event = asyncio.Event()
    daemon.set_stop_event(event)
    await daemon._graceful_shutdown()
    assert event.is_set()


@pytest.mark.asyncio
async def test_graceful_shutdown_without_stop_event_calls_stop(daemon):
    """When no stop event is registered, _graceful_shutdown awaits stop()."""
    stop_called = asyncio.Event()

    async def fake_stop():
        stop_called.set()

    daemon._stop_event = None
    daemon.stop = fake_stop  # type: ignore[assignment]
    await daemon._graceful_shutdown()
    assert stop_called.is_set()
