"""Smoke tests for cultureagent's CLI (afi-cli rubric coverage)."""

from __future__ import annotations

import json

import pytest

from cultureagent import __version__
from cultureagent.cli import main


def test_version_flag(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as exc:
        main(["--version"])
    assert exc.value.code == 0
    assert __version__ in capsys.readouterr().out


def test_no_args_prints_help(capsys: pytest.CaptureFixture[str]) -> None:
    rc = main([])
    assert rc == 0
    out = capsys.readouterr().out
    assert "cultureagent" in out
    assert "learn" in out


# ── Bundle 2: learnability ────────────────────────────────────────────


def test_learn_text_meets_rubric(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["learn"]) == 0
    out = capsys.readouterr().out
    assert len(out) >= 200
    for marker in ["purpose", "commands", "exit", "--json", "explain"]:
        assert marker.lower() in out.lower(), f"learn output missing marker: {marker}"


# ── Bundle 3: json (machine readability) ──────────────────────────────


def test_learn_json_parseable(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["learn", "--json"]) == 0
    captured = capsys.readouterr()
    assert captured.err == ""
    payload = json.loads(captured.out)
    assert payload["tool"] == "cultureagent"
    assert payload["version"] == __version__
    assert "0" in payload["exit_codes"]


def test_explain_json_parseable(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["explain", "--json", "learn"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["path"] == ["learn"]
    assert payload["markdown"].startswith("#")


# ── Bundle 4: errors (propagation) ────────────────────────────────────


def test_unknown_verb_exits_non_zero_with_hint(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as exc:
        main(["zzz-not-a-real-verb"])
    assert exc.value.code != 0
    err = capsys.readouterr().err
    assert "error:" in err
    assert "hint:" in err
    assert "Traceback" not in err


def test_explain_unknown_path_fails_with_hint(
    capsys: pytest.CaptureFixture[str],
) -> None:
    rc = main(["explain", "zzz-not-a-real-noun"])
    assert rc != 0
    err = capsys.readouterr().err
    assert "error:" in err
    assert "hint:" in err
    assert "Traceback" not in err


# ── Bundle 5: explain (addressable docs) ──────────────────────────────


def test_explain_root_no_args(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["explain"]) == 0
    out = capsys.readouterr().out
    assert out.startswith("#")
    assert "cultureagent" in out


def test_explain_self(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["explain", "cultureagent"]) == 0
    assert capsys.readouterr().out.startswith("#")


# ── Bundle 6: overview ────────────────────────────────────────────────


def test_overview_text(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["overview"]) == 0
    out = capsys.readouterr().out
    assert "globals" in out
    assert "nouns" in out


def test_overview_json_stable_keys(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["overview", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["subject"] == "cultureagent"
    assert isinstance(payload["sections"], list)


def test_overview_unknown_path_falls_back_gracefully(
    capsys: pytest.CaptureFixture[str],
) -> None:
    # Bundle 6: descriptive verbs warn but don't hard-fail on unknown paths.
    rc = main(["overview", "zzz-bogus"])
    assert rc == 0
    captured = capsys.readouterr()
    assert "warning:" in captured.err
    assert "globals" in captured.out


# ── Bundle 7: doctor ──────────────────────────────────────────────────


def test_doctor_exits_zero_with_hint(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["doctor"]) == 0
    captured = capsys.readouterr()
    assert "no checks" in captured.out.lower()
    assert "hint:" in captured.err
    assert "Traceback" not in captured.err


def test_doctor_json_parseable(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["doctor", "--json"]) == 0
    captured = capsys.readouterr()
    payload = json.loads(captured.out)
    assert payload["subject"] == "cultureagent"
    assert "checks" in payload
    # ``hint:`` still goes to stderr in JSON mode (it's a diagnostic, not a result).
    assert "hint:" in captured.err


# ── Bundle 8: cli meta-noun (overview-only) ───────────────────────────


def test_cli_noun_no_verb_runs_overview(capsys: pytest.CaptureFixture[str]) -> None:
    """``cultureagent cli`` with no verb falls through to overview."""
    rc = main(["cli"])
    assert rc == 0
    out = capsys.readouterr().out
    assert "globals" in out


def test_cli_noun_overview_text(capsys: pytest.CaptureFixture[str]) -> None:
    rc = main(["cli", "overview"])
    assert rc == 0
    out = capsys.readouterr().out
    assert "globals" in out


def test_cli_noun_overview_json_scopes_subject(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """`subject` is overridden to ``cultureagent.cli``."""
    assert main(["cli", "overview", "--json"]) == 0
    captured = capsys.readouterr()
    assert captured.err == ""
    payload = json.loads(captured.out)
    assert payload["subject"] == "cultureagent.cli"
    assert isinstance(payload["sections"], list)


def test_cli_noun_overview_known_path_no_warning(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """A known path (``globals``) should not produce the warning diagnostic."""
    assert main(["cli", "overview", "globals"]) == 0
    captured = capsys.readouterr()
    assert "warning:" not in captured.err
    assert "globals" in captured.out


def test_cli_noun_overview_unknown_path_warns(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Unknown paths warn to stderr and still emit the cli overview."""
    assert main(["cli", "overview", "zzz-bogus"]) == 0
    captured = capsys.readouterr()
    assert "warning:" in captured.err
    assert "cli overview" in captured.err
    assert "globals" in captured.out


def test_cli_noun_overview_carries_requested_path_in_json(
    capsys: pytest.CaptureFixture[str],
) -> None:
    assert main(["cli", "overview", "globals", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["requested_path"] == ["globals"]


# ── Bundle 9: _dispatch wraps unexpected exceptions ───────────────────


def test_dispatch_wraps_unexpected_exception(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    """When a command handler raises a non-Cultureagent exception, _dispatch
    must wrap it in a CultureagentError, emit ``error:`` + ``hint:`` to
    stderr, and exit with EXIT_USER_ERROR (1) — no Python traceback."""
    # Import the doctor submodule directly so xdist workers that haven't
    # yet pulled it through main() still have the attribute.
    from cultureagent.cli._commands import doctor as doctor_cmd

    def boom(_args) -> int:
        raise RuntimeError("simulated handler failure")

    monkeypatch.setattr(doctor_cmd, "cmd_doctor", boom)
    rc = main(["doctor"])
    assert rc == 1
    captured = capsys.readouterr()
    assert "Traceback" not in captured.err
    assert "error: unexpected: RuntimeError" in captured.err
    assert "hint: file a bug" in captured.err
