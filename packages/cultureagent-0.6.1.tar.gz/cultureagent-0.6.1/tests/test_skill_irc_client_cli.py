"""Tests for the CLI subcommand handlers in
``cultureagent.clients.shared.skill_irc_client``.

The async ``SkillClient`` class is exercised in tests/test_skill_client.py;
this file targets the CLI helpers (argument parsers, subcommand dispatch,
sock-path resolution) that aren't covered by the round-trip tests.
"""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from cultureagent.clients.shared import skill_irc_client


def _client_mock() -> AsyncMock:
    """Build an AsyncMock that mimics ``SkillClient`` for dispatch tests."""
    client = AsyncMock()
    for method in (
        "irc_send",
        "irc_read",
        "irc_ask",
        "irc_join",
        "irc_part",
        "irc_channels",
        "irc_who",
        "irc_topic",
        "compact",
        "clear",
    ):
        getattr(client, method).return_value = {"ok": True}
    return client


def test_sock_path_from_env_missing_nick_exits(monkeypatch, capsys):
    """Missing required env var is an environment error (AFI rubric exit 2)."""
    monkeypatch.delenv("CULTURE_NICK", raising=False)
    with pytest.raises(SystemExit) as excinfo:
        skill_irc_client._sock_path_from_env()
    assert excinfo.value.code == 2
    assert "CULTURE_NICK" in capsys.readouterr().err


def test_sock_path_from_env_uses_nick(monkeypatch):
    monkeypatch.setenv("CULTURE_NICK", "alice")
    path = skill_irc_client._sock_path_from_env()
    assert path.endswith("/culture-alice.sock")


def test_parse_ask_timeout_default():
    timeout, remaining = skill_irc_client._parse_ask_timeout(["how", "are", "you"])
    assert timeout == 30
    assert remaining == ["how", "are", "you"]


def test_parse_ask_timeout_explicit():
    timeout, remaining = skill_irc_client._parse_ask_timeout(["--timeout", "60", "go"])
    assert timeout == 60
    assert remaining == ["go"]


def test_parse_ask_timeout_missing_value_exits(capsys):
    """--timeout user-input errors exit 1 (AFI rubric)."""
    with pytest.raises(SystemExit) as excinfo:
        skill_irc_client._parse_ask_timeout(["--timeout"])
    assert excinfo.value.code == 1
    assert "requires a value" in capsys.readouterr().err


def test_parse_ask_timeout_non_integer_exits(capsys):
    with pytest.raises(SystemExit) as excinfo:
        skill_irc_client._parse_ask_timeout(["--timeout", "abc"])
    assert excinfo.value.code == 1
    assert "integer" in capsys.readouterr().err


def test_parse_ask_timeout_non_positive_exits(capsys):
    with pytest.raises(SystemExit) as excinfo:
        skill_irc_client._parse_ask_timeout(["--timeout", "0"])
    assert excinfo.value.code == 1
    assert "positive" in capsys.readouterr().err


@pytest.mark.asyncio
async def test_cmd_send_dispatches():
    client = _client_mock()
    res = await skill_irc_client._cmd_send(client, ["send", "#room", "hi", "there"])
    assert res == {"ok": True}
    client.irc_send.assert_awaited_once_with("#room", "hi there")


@pytest.mark.asyncio
async def test_cmd_read_default_limit():
    client = _client_mock()
    await skill_irc_client._cmd_read(client, ["read", "#room"])
    client.irc_read.assert_awaited_once_with("#room", limit=50)


@pytest.mark.asyncio
async def test_cmd_read_custom_limit():
    client = _client_mock()
    await skill_irc_client._cmd_read(client, ["read", "#room", "10"])
    client.irc_read.assert_awaited_once_with("#room", limit=10)


@pytest.mark.asyncio
async def test_cmd_ask_with_timeout_flag():
    client = _client_mock()
    await skill_irc_client._cmd_ask(client, ["ask", "#room", "--timeout", "5", "what?"])
    client.irc_ask.assert_awaited_once_with("#room", "what?", timeout=5)


@pytest.mark.asyncio
async def test_cmd_join_part_channels_who():
    client = _client_mock()
    await skill_irc_client._cmd_join(client, ["join", "#x"])
    await skill_irc_client._cmd_part(client, ["part", "#x"])
    await skill_irc_client._cmd_channels(client, ["channels"])
    await skill_irc_client._cmd_who(client, ["who", "alice"])
    client.irc_join.assert_awaited_once_with("#x")
    client.irc_part.assert_awaited_once_with("#x")
    client.irc_channels.assert_awaited_once_with()
    client.irc_who.assert_awaited_once_with("alice")


@pytest.mark.asyncio
async def test_cmd_topic_get_and_set():
    client = _client_mock()
    await skill_irc_client._cmd_topic(client, ["topic", "#x"])
    await skill_irc_client._cmd_topic(client, ["topic", "#x", "new", "topic"])
    assert client.irc_topic.await_count == 2
    client.irc_topic.assert_any_await("#x", None)
    client.irc_topic.assert_any_await("#x", "new topic")


@pytest.mark.asyncio
async def test_cmd_compact_clear():
    client = _client_mock()
    await skill_irc_client._cmd_compact(client, ["compact"])
    await skill_irc_client._cmd_clear(client, ["clear"])
    client.compact.assert_awaited_once_with()
    client.clear.assert_awaited_once_with()


def test_subcommands_table_complete():
    """Every CLI verb advertised in usage has a registered handler."""
    expected = {
        "send",
        "read",
        "ask",
        "join",
        "part",
        "channels",
        "who",
        "topic",
        "compact",
        "clear",
    }
    assert set(skill_irc_client._SUBCOMMANDS.keys()) == expected


@pytest.mark.asyncio
async def test_main_no_args_exits_1(monkeypatch, capsys):
    monkeypatch.setenv("CULTURE_NICK", "alice")
    with pytest.raises(SystemExit) as excinfo:
        await skill_irc_client._main([])
    assert excinfo.value.code == 1
    assert "Subcommands:" in capsys.readouterr().err


@pytest.mark.asyncio
async def test_main_unknown_subcommand_exits_1(monkeypatch, capsys):
    monkeypatch.setenv("CULTURE_NICK", "alice")
    with pytest.raises(SystemExit) as excinfo:
        await skill_irc_client._main(["bogus"])
    assert excinfo.value.code == 1
    assert "Unknown subcommand" in capsys.readouterr().err
