"""Tests for the libcst-based import rewriter used by the
culture -> cultureagent migration."""

from __future__ import annotations

import pytest

# Migration tooling lives outside the package (runs once per migration PR);
# pyproject [tool.pytest.ini_options].pythonpath adds the scripts dir so
# these modules are importable here without runtime sys.path tweaks.
from _migrate_driver import _strip_unused_imports
from _migrate_rewriter import rewrite_module, rewrite_strings, telemetry_namespace_count

ALLOWLIST = (
    "culture.clients.shared",
    "culture.clients.claude",
    "culture.clients.codex",
    "culture.clients.copilot",
    "culture.clients.acp",
    "culture.aio",
    "culture.pidfile",
    "culture._constants",
    "culture.constants",
    "culture.protocol",
    "culture.telemetry",
    "culture.cli.shared.constants",
)


def test_rewrites_from_culture_clients_shared():
    src = "from culture.clients.shared.attention import AttentionTracker\n"
    out, edits = rewrite_module(src, ALLOWLIST)
    assert out == "from cultureagent.clients.shared.attention import AttentionTracker\n"
    assert edits == 1


def test_rewrites_from_culture_aio():
    src = "from culture.aio import maybe_await\n"
    out, edits = rewrite_module(src, ALLOWLIST)
    assert out == "from cultureagent.aio import maybe_await\n"
    assert edits == 1


def test_does_not_rewrite_unknown_culture_path():
    src = "from culture.agentirc.events import EventType\n"
    with pytest.raises(ValueError, match="unexpected culture import"):
        rewrite_module(src, ALLOWLIST)


def test_leaves_telemetry_string_literals_untouched():
    src = 'TRACER = "culture.harness"\nattrs = {"culture.trace.origin": "remote"}\n'
    out, edits = rewrite_module(src, ALLOWLIST)
    assert out == src
    assert edits == 0


def test_leaves_non_culture_imports_untouched():
    src = "from opentelemetry.sdk import trace\n"
    out, edits = rewrite_module(src, ALLOWLIST)
    assert out == src
    assert edits == 0


def test_rewrites_dotted_import_form():
    src = "import culture.clients.shared.telemetry as t\n"
    out, edits = rewrite_module(src, ALLOWLIST)
    assert out == "import cultureagent.clients.shared.telemetry as t\n"
    assert edits == 1


def test_does_not_silently_pass_bare_culture_from_import():
    src = "from culture import something\n"
    with pytest.raises(ValueError, match="unexpected culture import"):
        rewrite_module(src, ALLOWLIST)


def test_does_not_silently_pass_bare_culture_import():
    src = "import culture\n"
    with pytest.raises(ValueError, match="unexpected culture import"):
        rewrite_module(src, ALLOWLIST)


def test_rewrites_aliased_from_import():
    src = "from culture.clients.shared.attention import AttentionTracker as AT\n"
    out, edits = rewrite_module(src, ALLOWLIST)
    assert out == "from cultureagent.clients.shared.attention import AttentionTracker as AT\n"
    assert edits == 1


def test_rewrites_deep_dotted_import_form():
    src = "import culture.clients.shared.telemetry\n"
    out, edits = rewrite_module(src, ALLOWLIST)
    assert out == "import cultureagent.clients.shared.telemetry\n"
    assert edits == 1


def test_rewrites_mock_patch_target():
    src = '"culture.clients.codex.agent_runner.asyncio.timeout"\n'
    out, edits = rewrite_strings(src)
    assert out == '"cultureagent.clients.codex.agent_runner.asyncio.timeout"\n'
    assert edits == 1


def test_rewrites_module_equality_string():
    src = 'expected_module = "culture.clients.shared.telemetry"\n'
    out, edits = rewrite_strings(src)
    assert out == 'expected_module = "cultureagent.clients.shared.telemetry"\n'
    assert edits == 1


def test_leaves_telemetry_namespace_strings_untouched():
    cases = [
        '"culture.harness"',
        '"culture.harness.claude"',
        '"culture.trace.origin"',
        '"culture.attention.transitions"',
        '"culture.harness.llm.tokens.input"',
    ]
    for src in cases:
        out, edits = rewrite_strings(src)
        assert out == src, f"telemetry namespace was rewritten: {src} -> {out}"
        assert edits == 0


def test_rewrites_filesystem_path_string():
    src = '_REPO_ROOT / "culture" / "clients"\n'
    out, edits = rewrite_strings(src)
    assert out == '_REPO_ROOT / "cultureagent" / "clients"\n'
    assert edits == 1


def test_does_not_rewrite_culture_yaml_filename():
    src = 'yaml_path = backend_dir / "culture.yaml"\n'
    out, edits = rewrite_strings(src)
    assert out == src
    assert edits == 0


def test_telemetry_namespace_count():
    src = (
        '"culture.harness"\n'
        '"culture.harness.claude"\n'
        '"culture.trace.origin"\n'
        '"culture.attention.transitions"\n'
        '"culture.clients.shared.telemetry"\n'
        'service = "culture.harness"  # appears twice in two lines\n'
    )
    assert telemetry_namespace_count(src) == 5


def test_strips_culture_bots_config_import():
    src = (
        "import os\n"
        "from culture.bots.config import BOT_CONFIG_FILE  # noqa: F401\n"
        "from culture.aio import maybe_await\n"
    )
    out = _strip_unused_imports(src)
    assert out == "import os\nfrom culture.aio import maybe_await\n"


def test_strip_unused_imports_keeps_unrelated_lines():
    src = "x = 1\nfrom opentelemetry import trace\n"
    out = _strip_unused_imports(src)
    assert out == src
