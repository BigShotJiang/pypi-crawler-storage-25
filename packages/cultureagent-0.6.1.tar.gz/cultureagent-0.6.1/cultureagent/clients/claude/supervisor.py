"""Claude SDK supervisor adapter — re-exports the shared implementation.

The Supervisor class, SupervisorVerdict dataclass, and the SDK-based
``make_sdk_evaluate_fn`` factory all live under
``cultureagent.clients.shared``. This module preserves the per-backend
import path
``cultureagent.clients.claude.supervisor.{Supervisor, SupervisorVerdict,
make_sdk_evaluate_fn}`` for existing callers and tests.
"""

from __future__ import annotations

from cultureagent.clients.shared.sdk_supervisor import make_sdk_evaluate_fn
from cultureagent.clients.shared.supervisor import (
    EvaluateFn,
    Supervisor,
    SupervisorVerdict,
)

__all__ = ["EvaluateFn", "Supervisor", "SupervisorVerdict", "make_sdk_evaluate_fn"]
