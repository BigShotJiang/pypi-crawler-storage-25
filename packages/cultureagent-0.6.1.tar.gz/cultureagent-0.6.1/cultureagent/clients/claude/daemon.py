"""Claude agent daemon — bridges a Claude agent to the IRC network.

Uses the synchronous mention-routing topology hosted by
``cultureagent.clients.shared.base_daemon.BaseDaemon``. Codex/copilot/acp
use the queued shape via ``QueuedBaseDaemon``.
"""

from __future__ import annotations

import logging

from cultureagent.clients.claude.agent_runner import AgentRunner
from cultureagent.clients.claude.config import (
    AgentConfig,
    DaemonConfig,
    resolve_attention_config,
)
from cultureagent.clients.claude.constants import DEFAULT_TURN_TIMEOUT_SECONDS
from cultureagent.clients.claude.supervisor import Supervisor, make_sdk_evaluate_fn
from cultureagent.clients.shared.base_daemon import BaseDaemon

logger = logging.getLogger(__name__)


class AgentDaemon(BaseDaemon):
    """Claude agent daemon — synchronous mention routing."""

    BACKEND_NAME = "claude"

    def __init__(
        self,
        config: DaemonConfig,
        agent: AgentConfig,
        socket_dir: str | None = None,
        skip_claude: bool = False,
    ) -> None:
        super().__init__(config, agent, socket_dir=socket_dir, skip_agent=skip_claude)
        # Backwards-compat attribute name (tests + culture-side callers may
        # still reference `skip_claude` directly).
        self.skip_claude = skip_claude
        # Per-backend type-narrowed runner / supervisor
        self._agent_runner: AgentRunner | None = None
        self._supervisor: Supervisor | None = None

    def _create_supervisor(self) -> Supervisor:
        return Supervisor(
            window_size=self.config.supervisor.window_size,
            eval_interval=self.config.supervisor.eval_interval,
            escalation_threshold=self.config.supervisor.escalation_threshold,
            evaluate_fn=make_sdk_evaluate_fn(
                model=self.config.supervisor.model,
                thinking=self.config.supervisor.thinking,
                prompt_override=self.config.supervisor.prompt_override,
            ),
            on_whisper=self._on_supervisor_whisper,
            on_escalation=self._on_supervisor_escalation,
        )

    async def _start_agent_runner(self) -> None:  # NOSONAR — live_query: harness contract
        self._agent_runner = AgentRunner(  # NOSONAR — receive-as-is contract
            model=self.agent.model,
            directory=self.agent.directory,
            system_prompt=self._build_system_prompt(),
            on_exit=self._on_agent_exit,
            on_message=self._on_agent_message,
            metrics=self._metrics,
            nick=self.agent.nick,
            turn_timeout_seconds=getattr(
                self.agent, "turn_timeout_seconds", DEFAULT_TURN_TIMEOUT_SECONDS
            ),
        )
        await self._agent_runner.start()
        logger.info("AgentRunner started via SDK for %s", self.agent.nick)

    # Re-export the per-backend resolve_attention_config so historical
    # external callers reaching for `cultureagent.clients.claude.daemon
    # .resolve_attention_config` continue to work.
    _resolve_attention_config_helper = staticmethod(resolve_attention_config)
