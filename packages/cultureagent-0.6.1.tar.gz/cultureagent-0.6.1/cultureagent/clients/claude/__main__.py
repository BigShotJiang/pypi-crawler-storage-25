"""CLI entry point for the claude agent daemon.

Thin wrapper over ``cultureagent.clients.shared.main_runner.run_main``.
"""

from __future__ import annotations

from cultureagent.clients.claude.config import load_config
from cultureagent.clients.claude.daemon import AgentDaemon
from cultureagent.clients.shared.main_runner import run_main


def main() -> None:
    run_main(AgentDaemon, load_config, prog="culture", description="culture agent daemon")


if __name__ == "__main__":
    main()
