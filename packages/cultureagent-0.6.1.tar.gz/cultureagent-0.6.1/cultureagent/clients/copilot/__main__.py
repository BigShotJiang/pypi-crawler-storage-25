"""CLI entry point for the copilot agent daemon.

Thin wrapper over ``cultureagent.clients.shared.main_runner.run_main``.
"""

from __future__ import annotations

from cultureagent.clients.copilot.config import load_config
from cultureagent.clients.copilot.daemon import CopilotDaemon
from cultureagent.clients.shared.main_runner import run_main


def main() -> None:
    run_main(CopilotDaemon, load_config, prog="culture", description="culture copilot agent daemon")


if __name__ == "__main__":
    main()
