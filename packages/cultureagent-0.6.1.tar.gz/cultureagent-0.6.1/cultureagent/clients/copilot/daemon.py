"""Copilot agent daemon — bridges a GitHub Copilot agent to the IRC network.

Uses CopilotAgentRunner (github-copilot-sdk) and CopilotSupervisor.
Inherits the shared FIFO mention-queue topology from
``cultureagent.clients.shared.queued_base_daemon.QueuedBaseDaemon``.
"""

from __future__ import annotations

import logging
import os

from cultureagent.clients.copilot.agent_runner import CopilotAgentRunner
from cultureagent.clients.copilot.config import (
    AgentConfig,
    DaemonConfig,
    resolve_attention_config,
)
from cultureagent.clients.copilot.constants import DEFAULT_TURN_TIMEOUT_SECONDS
from cultureagent.clients.copilot.supervisor import CopilotSupervisor
from cultureagent.clients.shared.queued_base_daemon import QueuedBaseDaemon

logger = logging.getLogger(__name__)


class CopilotDaemon(QueuedBaseDaemon):
    """Copilot agent daemon — queue-shape mention routing."""

    BACKEND_NAME = "copilot"

    def __init__(
        self,
        config: DaemonConfig,
        agent: AgentConfig,
        socket_dir: str | None = None,
        skip_copilot: bool = False,
    ) -> None:
        super().__init__(config, agent, socket_dir=socket_dir, skip_agent=skip_copilot)
        self.skip_copilot = skip_copilot
        self._agent_runner: CopilotAgentRunner | None = None
        self._supervisor: CopilotSupervisor | None = None

    def _resolve_attention_config(self):
        return resolve_attention_config(self.config, self.agent)

    def _create_supervisor(self) -> CopilotSupervisor:
        return CopilotSupervisor(
            model=self.config.supervisor.model,
            window_size=self.config.supervisor.window_size,
            eval_interval=self.config.supervisor.eval_interval,
            escalation_threshold=self.config.supervisor.escalation_threshold,
            prompt_override=self.config.supervisor.prompt_override,
            on_whisper=self._on_supervisor_whisper,
            on_escalation=self._on_supervisor_escalation,
        )

    async def _start_agent_runner(self) -> None:  # NOSONAR — live_query: harness contract
        # Resolve installed skill path for the Copilot session
        skill_dirs: list[str] = []
        copilot_skill = os.path.expanduser("~/.copilot_skills/culture-irc/SKILL.md")
        if os.path.isfile(copilot_skill):
            skill_dirs.append(copilot_skill)

        self._agent_runner = CopilotAgentRunner(  # NOSONAR — receive-as-is contract
            model=self.agent.model,
            directory=self.agent.directory,
            system_prompt=self._build_system_prompt(),
            skill_directories=skill_dirs,
            on_exit=self._on_agent_exit,
            on_message=self._on_agent_message,
            on_turn_error=self._on_turn_error,
            metrics=self._metrics,
            nick=self.agent.nick,
            turn_timeout_seconds=getattr(
                self.agent, "turn_timeout_seconds", DEFAULT_TURN_TIMEOUT_SECONDS
            ),
        )
        await self._agent_runner.start()
        logger.info("CopilotAgentRunner started for %s", self.agent.nick)
