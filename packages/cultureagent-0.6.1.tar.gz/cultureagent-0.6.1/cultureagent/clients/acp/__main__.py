"""CLI entry point for the acp agent daemon.

Thin wrapper over ``cultureagent.clients.shared.main_runner.run_main``.
"""

from __future__ import annotations

from cultureagent.clients.acp.config import load_config
from cultureagent.clients.acp.daemon import ACPDaemon
from cultureagent.clients.shared.main_runner import run_main


def main() -> None:
    run_main(ACPDaemon, load_config, prog="culture", description="culture acp agent daemon")


if __name__ == "__main__":
    main()
