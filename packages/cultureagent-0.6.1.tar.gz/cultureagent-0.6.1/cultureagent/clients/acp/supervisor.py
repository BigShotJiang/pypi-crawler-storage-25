"""ACP SDK supervisor adapter — re-exports the shared implementation.

ACP uses the same claude-agent-sdk shape as the claude backend. The
Supervisor class, SupervisorVerdict dataclass, and the SDK-based
``make_sdk_evaluate_fn`` factory all live under
``cultureagent.clients.shared``. This module preserves the per-backend
import path
``cultureagent.clients.acp.supervisor.{Supervisor, SupervisorVerdict,
make_sdk_evaluate_fn}``.
"""

from __future__ import annotations

from cultureagent.clients.shared.sdk_supervisor import make_sdk_evaluate_fn
from cultureagent.clients.shared.supervisor import (
    EvaluateFn,
    Supervisor,
    SupervisorVerdict,
)

__all__ = ["EvaluateFn", "Supervisor", "SupervisorVerdict", "make_sdk_evaluate_fn"]
