"""ACP agent daemon — bridges any ACP-compatible agent to the IRC network.

Supports Cline (cline --acp), OpenCode (opencode acp), and any other agent
that implements the Agent Client Protocol over stdio.

Uses ACPAgentRunner (JSON-RPC/stdio) and an SDK-based Supervisor
(Claude Agent SDK for periodic evaluation). Inherits the shared FIFO
mention-queue topology from
``cultureagent.clients.shared.queued_base_daemon.QueuedBaseDaemon``.
"""

from __future__ import annotations

import asyncio
import logging
import time

from cultureagent.clients.acp.agent_runner import ACPAgentRunner
from cultureagent.clients.acp.config import (
    AgentConfig,
    DaemonConfig,
    resolve_attention_config,
)
from cultureagent.clients.acp.constants import DEFAULT_TURN_TIMEOUT_SECONDS
from cultureagent.clients.acp.supervisor import Supervisor, make_sdk_evaluate_fn
from cultureagent.clients.shared.base_daemon import CRASH_RESTART_DELAY
from cultureagent.clients.shared.queued_base_daemon import QueuedBaseDaemon

logger = logging.getLogger(__name__)


class ACPDaemon(QueuedBaseDaemon):
    """ACP agent daemon — queue-shape mention routing + retry-on-start-failure."""

    BACKEND_NAME = "acp"

    def __init__(
        self,
        config: DaemonConfig,
        agent: AgentConfig,
        socket_dir: str | None = None,
        skip_agent: bool = False,
    ) -> None:
        super().__init__(config, agent, socket_dir=socket_dir, skip_agent=skip_agent)
        self._agent_runner: ACPAgentRunner | None = None
        self._supervisor: Supervisor | None = None

    def _resolve_attention_config(self):
        return resolve_attention_config(self.config, self.agent)

    def _create_supervisor(self) -> Supervisor:
        return Supervisor(
            window_size=self.config.supervisor.window_size,
            eval_interval=self.config.supervisor.eval_interval,
            escalation_threshold=self.config.supervisor.escalation_threshold,
            evaluate_fn=make_sdk_evaluate_fn(
                model=self.config.supervisor.model,
                thinking=self.config.supervisor.thinking or None,
                prompt_override=self.config.supervisor.prompt_override,
            ),
            on_whisper=self._on_supervisor_whisper,
            on_escalation=self._on_supervisor_escalation,
        )

    def _on_start_agent_runner_failure(self) -> None:
        """ACP variant: log + schedule a delayed retry instead of re-raising."""
        cmd_label = " ".join(self.agent.acp_command)
        logger.exception(
            "Failed to start agent runner for %s (%s), scheduling retry",
            self.agent.nick,
            cmd_label,
        )
        self._agent_runner = None
        self._crash_times.append(time.time())
        task = asyncio.create_task(self._delayed_restart())
        self._background_tasks.add(task)
        task.add_done_callback(self._background_tasks.discard)

    async def _start_agent_runner(self) -> None:  # NOSONAR — live_query: harness contract
        self._agent_runner = ACPAgentRunner(  # NOSONAR — receive-as-is contract
            model=self.agent.model,
            directory=self.agent.directory,
            acp_command=self.agent.acp_command,
            system_prompt=self._build_system_prompt(),
            on_exit=self._on_agent_exit,
            on_message=self._on_agent_message,
            on_turn_error=self._on_turn_error,
            metrics=self._metrics,
            nick=self.agent.nick,
            turn_timeout_seconds=getattr(
                self.agent, "turn_timeout_seconds", DEFAULT_TURN_TIMEOUT_SECONDS
            ),
        )
        # Absorb the system prompt response without relaying to IRC
        self._mention_targets.append(None)
        await self._agent_runner.start()
        logger.info(
            "ACPAgentRunner started for %s (cmd=%s)",
            self.agent.nick,
            " ".join(self.agent.acp_command),
        )

    # ACP-specific override: retries on failure (vs base's plain restart)
    async def _delayed_restart(self) -> None:
        await asyncio.sleep(CRASH_RESTART_DELAY)
        if not self._circuit_open and self._transport is not None:
            try:
                await self._start_agent_runner()
            except Exception:
                logger.exception(
                    "Failed to restart agent runner for %s",
                    self.agent.nick,
                )
                # Record as a crash so the circuit breaker can track it
                await self._on_agent_exit(-1)
