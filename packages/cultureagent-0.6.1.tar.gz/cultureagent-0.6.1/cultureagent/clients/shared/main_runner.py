"""Shared CLI entry point for the four backend daemons.

Per-backend ``__main__.py`` modules are thin wrappers that pass their
backend-specific ``daemon_class`` and ``load_config`` to ``run_main``.
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import signal
import sys
from typing import Any, Callable

logger = logging.getLogger("culture")

DEFAULT_CONFIG = os.path.expanduser("~/.culture/agents.yaml")


def run_main(
    daemon_class: type,
    load_config: Callable[[str], Any],
    *,
    prog: str = "culture",
    description: str = "culture agent daemon",
) -> None:
    """Parse argv, load config, and run one or more daemons.

    ``daemon_class`` is the per-backend daemon class (``AgentDaemon``,
    ``CodexDaemon``, ``CopilotDaemon``, ``ACPDaemon``).
    ``load_config`` is the backend's ``config.load_config`` entry point.
    """
    parser = argparse.ArgumentParser(prog=prog, description=description)
    sub = parser.add_subparsers(dest="command")

    start_parser = sub.add_parser("start", help="Start agent daemon(s)")
    start_parser.add_argument("nick", nargs="?", help="Agent nick to start")
    start_parser.add_argument("--all", action="store_true", help="Start all agents")
    start_parser.add_argument("--config", default=DEFAULT_CONFIG, help="Config file path")

    args = parser.parse_args()

    if args.command != "start":
        parser.print_help()
        sys.exit(1)

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")

    try:
        config = load_config(args.config)
    except OSError as e:
        # AFI rubric: env errors exit 2
        print(f"hint: failed to load config {args.config!r}: {e}", file=sys.stderr)
        sys.exit(2)

    if args.all:
        agents = config.agents
    elif args.nick:
        agent = config.get_agent(args.nick)
        if not agent:
            logger.error("Agent '%s' not found in config", args.nick)
            sys.exit(1)
        agents = [agent]
    else:
        start_parser.print_help()
        sys.exit(1)

    if not agents:
        logger.error("No agents configured")
        sys.exit(1)

    if len(agents) == 1:
        asyncio.run(_run_single(daemon_class, config, agents[0]))
    else:
        _run_multi(daemon_class, config, agents)


async def _run_single(daemon_class: type, config: Any, agent: Any) -> None:
    daemon = daemon_class(config, agent)
    await daemon.start()
    logger.info("Agent %s started", agent.nick)
    stop_event = asyncio.Event()
    loop = asyncio.get_event_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, stop_event.set)
    await stop_event.wait()
    logger.info("Shutting down %s", agent.nick)
    await daemon.stop()


def _run_multi(daemon_class: type, config: Any, agents: list[Any]) -> None:
    for agent in agents:
        pid = os.fork()
        if pid == 0:
            os.setsid()
            asyncio.run(_run_single(daemon_class, config, agent))
            sys.exit(0)
        else:
            logger.info("Started %s (pid %d)", agent.nick, pid)
