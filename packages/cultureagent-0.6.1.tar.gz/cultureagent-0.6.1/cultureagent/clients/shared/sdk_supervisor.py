"""SDK-based supervisor evaluator — used by claude/acp backends.

This module imports ``claude_agent_sdk`` at top level. The codex and
copilot backends do not import it (they use subprocess-based supervision
instead) and do not need the SDK installed; the dep is declared in the
``backend-claude`` and ``backend-acp`` optional-dependencies groups.
"""

from __future__ import annotations

from typing import Any

from claude_agent_sdk import AssistantMessage, ClaudeAgentOptions, TextBlock, query

from cultureagent.clients.shared.supervisor import (
    EvaluateFn,
    SupervisorVerdict,
    _format_window,
)

__all__ = ["make_sdk_evaluate_fn"]

_SUPERVISOR_SYSTEM_PROMPT = """\
You are a supervisor monitoring an AI agent's work session.

Your job: detect when the agent is unproductive and intervene minimally.

Watch for:
- SPIRALING: Same approach retried 3+ times, no progress
- DRIFT: Work diverging from the original task
- STALLING: Long gaps with no meaningful output
- SHALLOW: Complex decisions made without sufficient reasoning

Respond with exactly one line:
- OK — agent is productive, no action needed
- CORRECTION <message> — agent needs redirection
- THINK_DEEPER <message> — agent should use extended thinking
- ESCALATION <message> — humans need to be notified

Be conservative. Only intervene when clearly warranted.
Most evaluations should return OK."""


def _extract_verdict_text(response) -> str:
    """Extract text from an SDK response message."""
    if isinstance(response, AssistantMessage):
        return "".join(block.text for block in response.content if isinstance(block, TextBlock))
    return ""


def make_sdk_evaluate_fn(
    model: str = "claude-sonnet-4-6",
    thinking: str | None = None,
    prompt_override: str = "",
) -> EvaluateFn:
    """Create an evaluate_fn that uses the Claude Agent SDK."""
    system_prompt = prompt_override or _SUPERVISOR_SYSTEM_PROMPT

    async def evaluate(window: list[dict[str, Any]], task: str) -> SupervisorVerdict:
        prompt = _format_window(window, task)
        result_text = ""
        opts = ClaudeAgentOptions(
            model=model,
            max_turns=1,
            system_prompt=system_prompt,
            tools=[],
        )
        if thinking:
            opts.effort = thinking
        async for message in query(prompt=prompt, options=opts):
            result_text += _extract_verdict_text(message)
        return SupervisorVerdict.parse(result_text)

    return evaluate
