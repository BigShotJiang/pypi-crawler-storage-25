"""CLI entry point for the codex agent daemon.

Thin wrapper over ``cultureagent.clients.shared.main_runner.run_main``.
"""

from __future__ import annotations

from cultureagent.clients.codex.config import load_config
from cultureagent.clients.codex.daemon import CodexDaemon
from cultureagent.clients.shared.main_runner import run_main


def main() -> None:
    run_main(CodexDaemon, load_config, prog="culture", description="culture codex agent daemon")


if __name__ == "__main__":
    main()
