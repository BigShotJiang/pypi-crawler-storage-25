"""Public package root for the standalone hf-mcp launch surface."""

__all__ = ["__version__"]
__version__ = "0.1.0"
