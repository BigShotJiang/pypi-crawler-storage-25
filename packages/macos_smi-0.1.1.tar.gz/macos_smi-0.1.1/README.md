# macos-smi

`nvidia-smi` equivalent for Apple Silicon — real-time GPU/CPU/RAM monitor for anyone running LLM inference (MLX, llama.cpp, Ollama, etc.) on a MacBook.

```
╔══════════════════════════════════════════════════════════════════════╗
║  macos-smi                              Sun Apr 12 10:15:30 2026    ║
║  Apple M4 Pro  ·  64 GB unified memory                              ║
╠═══════════════════════════════╦══════════════════════════════════════╣
║  GPU                          ║  Memory (Unified)                    ║
║  Utilization :  73 %          ║  Used    :  24.3 GB                  ║
║  Power       :  18.2 W        ║  Total   :  64.0 GB  (38 %)          ║
╠═══════════════════════════════╬══════════════════════════════════════╣
║  CPU                          ║                                      ║
║  Utilization :  42 %          ║                                      ║
║  Power       :   8.4 W        ║                                      ║
╚═══════════════════════════════╩══════════════════════════════════════╝
  Ctrl-C to quit  ·  1 Hz  ·  local powermetrics
```

## Install

```bash
# Using uv (recommended)
uv tool install macos-smi

# Using pip
pip3 install macos-smi

# From source
git clone https://github.com/tianszz/macos-smi.git
cd macos-smi && uv tool install .
```

## Usage

```bash
# CPU + RAM only (no sudo required)
macos-smi

# Full stats including GPU utilization and power draw
sudo macos-smi

# Single snapshot and exit (like nvidia-smi default)
sudo macos-smi --no-loop

# Faster refresh
sudo macos-smi --interval 500
```

## Requirements

- macOS on Apple Silicon (M1 and later)
- `sudo` access for GPU stats via `powermetrics` (CPU + RAM work without sudo)

## How it works

GPU utilization and power draw are read from Apple's `powermetrics` utility (requires root). CPU utilization and RAM are read via `psutil` (no sudo needed). The display updates at 1 Hz by default using [Rich](https://github.com/Textualize/rich).
