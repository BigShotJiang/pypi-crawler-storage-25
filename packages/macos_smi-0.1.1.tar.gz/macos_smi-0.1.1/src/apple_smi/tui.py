"""
nvidia-smi-style GPU/CPU/RAM monitor for Apple Silicon.
"""
import platform
import subprocess
import time
from datetime import datetime

from rich import box
from rich.columns import Columns
from rich.console import Console, Group
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from apple_smi import monitor


def _chip_name():
    try:
        return subprocess.check_output(
            ["sysctl", "-n", "machdep.cpu.brand_string"],
            stderr=subprocess.DEVNULL,
        ).decode().strip()
    except Exception:
        return platform.processor() or "Apple Silicon"


def _fmt(val, unit="", fmt=".0f"):
    if val is None:
        return "—"
    return f"{val:{fmt}} {unit}".strip()


def _render(stats, chip, interval_ms):
    gpu_u = stats.get("gpu_util")
    gpu_w = stats.get("gpu_w")
    cpu_u = stats.get("cpu_util")
    cpu_w = stats.get("cpu_w")
    ram_u = stats.get("ram_used_gb")
    ram_t = stats.get("ram_total_gb")

    ram_pct = f"({ram_u / ram_t * 100:.0f} %)" if ram_u and ram_t else ""

    # ── Header ──────────────────────────────────────────────────────────────
    ts = datetime.now().strftime("%a %b %d %H:%M:%S %Y")
    total_mem = f"{int(ram_t)} GB unified memory" if ram_t else "? GB unified memory"
    header = Table.grid(expand=True)
    header.add_column(ratio=1)
    header.add_column(justify="right")
    header.add_row(
        Text("macos-smi", style="bold white"),
        Text(ts, style="dim"),
    )
    header.add_row(
        Text(f"{chip}  ·  {total_mem}", style="dim"),
        Text(""),
    )

    # ── Left: GPU / CPU ──────────────────────────────────────────────────────
    left = Table(box=None, show_header=False, padding=(0, 1))
    left.add_column(style="bold cyan", width=16)
    left.add_column()

    left.add_row(Text("GPU", style="bold white underline"), "")
    left.add_row("Utilization", _fmt(gpu_u, "%"))
    left.add_row("Power", _fmt(gpu_w, "W", ".1f"))
    left.add_row("", "")
    left.add_row(Text("CPU", style="bold white underline"), "")
    left.add_row("Utilization", _fmt(cpu_u, "%"))
    left.add_row("Power", _fmt(cpu_w, "W", ".1f"))

    # ── Right: Memory ────────────────────────────────────────────────────────
    right = Table(box=None, show_header=False, padding=(0, 1))
    right.add_column(style="bold cyan", no_wrap=True)
    right.add_column()

    right.add_row(Text("Memory (Unified)", style="bold white underline"), "")
    right.add_row("Used", _fmt(ram_u, "GB", ".1f"))
    right.add_row("Total", f"{_fmt(ram_t, 'GB', '.1f')}  {ram_pct}")

    body = Columns([left, right], expand=True)

    # ── Footer hints ─────────────────────────────────────────────────────────
    hz = f"{1000 // interval_ms} Hz" if interval_ms <= 1000 else f"{interval_ms / 1000:.1f}s"
    hint_parts = [Text(f"Ctrl-C to quit  ·  {hz}  ·  local powermetrics")]
    if gpu_u is None:
        hint_parts.append(Text("GPU stats unavailable — run with sudo for powermetrics", style="dim"))

    content = Group(header, Text(""), body, Text(""), *hint_parts)
    return Panel(content, box=box.DOUBLE, border_style="bright_black")


def run(interval_ms: int = 1000, loop: bool = True):
    chip = _chip_name()
    monitor.start()

    def _source():
        try:
            # Wait one interval so powermetrics has time to produce a first sample
            time.sleep(interval_ms / 1000)
            yield monitor.get_stats()
            if loop:
                while True:
                    time.sleep(interval_ms / 1000)
                    yield monitor.get_stats()
        finally:
            monitor.stop()

    console = Console()
    if loop:
        with Live(console=console, refresh_per_second=1000 // interval_ms, screen=False) as live:
            try:
                for stats in _source():
                    live.update(_render(stats, chip, interval_ms))
            except KeyboardInterrupt:
                pass
    else:
        for stats in _source():
            console.print(_render(stats, chip, interval_ms))


def main():
    import argparse
    p = argparse.ArgumentParser(
        prog="macos-smi",
        description="nvidia-smi equivalent for Apple Silicon — real-time GPU/CPU/RAM monitor",
    )
    p.add_argument(
        "--interval", type=int, default=1000, metavar="MS",
        help="Refresh interval in milliseconds (default: 1000)",
    )
    p.add_argument(
        "--loop", "-l", action="store_true", default=True,
        help="Continuously refresh (default). Use --no-loop to print once and exit.",
    )
    p.add_argument("--no-loop", dest="loop", action="store_false")
    args = p.parse_args()
    run(args.interval, args.loop)
