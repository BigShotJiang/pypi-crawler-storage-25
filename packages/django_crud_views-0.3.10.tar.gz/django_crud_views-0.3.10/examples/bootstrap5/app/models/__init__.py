import uuid

from django.db import models
from django.utils.translation import gettext_lazy as _
from ordered_model.models import OrderedModel

from .campaign import Campaign as Campaign


class Author(OrderedModel):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    first_name = models.CharField(max_length=100, verbose_name=_("First name"))
    last_name = models.CharField(max_length=100, verbose_name=_("Last name"))
    pseudonym = models.CharField(max_length=100, blank=True, null=True, verbose_name=_("Pseudonym"))
    created_dt = models.DateTimeField(auto_now_add=True, verbose_name=_("Created"))
    modified_dt = models.DateTimeField(auto_now=True, verbose_name=_("Modified"))

    class Meta(OrderedModel.Meta):
        verbose_name = _("Author")
        verbose_name_plural = _("Authors")

    def __str__(self):
        return f"{self.first_name} {self.last_name}"

    @property
    def xyz(self):
        return "xyz-prop"

    @property
    def abc(self):
        return True

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"


class Book(OrderedModel):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    title = models.CharField(max_length=100, verbose_name=_("Titel"))
    price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name=_("Price"))
    author = models.ForeignKey(Author, on_delete=models.CASCADE, verbose_name=_("Author"))
    created_dt = models.DateTimeField(auto_now_add=True, verbose_name=_("Created"))
    modified_dt = models.DateTimeField(auto_now=True, verbose_name=_("Modified"))

    class Meta(OrderedModel.Meta):
        verbose_name = _("Book")
        verbose_name_plural = _("Books")

    def __str__(self):
        return f"{self.title} by {self.author}"


class Foo(models.Model):
    name = models.CharField(max_length=100, verbose_name=_("Name"))

    def __str__(self):
        return f"{self.name}"


class Bar(models.Model):
    foo = models.ForeignKey(Foo, on_delete=models.CASCADE)
    name = models.CharField(max_length=100, verbose_name=_("Name"))

    def __str__(self):
        return f"{self.name}"


class Baz(models.Model):
    bar = models.ForeignKey(Bar, on_delete=models.CASCADE)
    name = models.CharField(max_length=100, verbose_name=_("Name"))

    def __str__(self):
        return f"{self.name}"


class Detail(OrderedModel):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    integer = models.IntegerField(verbose_name=_("An integer field"))
    number = models.FloatField(verbose_name=_("A float field"))
    char = models.CharField(max_length=100, verbose_name=_("Text field"))
    text = models.TextField(verbose_name=_("Multiline Text"))
    boolean = models.BooleanField(null=True, default=None, verbose_name=_("A boolean value"))
    boolean_two = models.BooleanField(null=True, default=None, verbose_name=_("Another boolean value"))
    date = models.DateField(verbose_name=_("A date field"))
    date_time = models.DateTimeField(verbose_name=_("A date field with time"))
    author = models.ForeignKey(
        Author, verbose_name=_("A foreign key field"), on_delete=models.SET_NULL, blank=True, null=True
    )
    foo = models.ManyToManyField(Foo, verbose_name=_("Foo selected"))
    created_dt = models.DateTimeField(auto_now_add=True)
    modified_dt = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.id}"

    @property
    def model_prop(self):
        return True


#########################


class Person(models.Model):
    name = models.CharField(max_length=128, verbose_name=_("Name"))

    def __str__(self):
        return self.name


class Group(models.Model):
    name = models.CharField(max_length=128, verbose_name=_("Name"))
    members = models.ManyToManyField(Person, through="Membership", related_name="group")

    def __str__(self):
        return self.name


class Membership(models.Model):
    person = models.ForeignKey(Person, on_delete=models.CASCADE)
    group = models.ForeignKey(Group, on_delete=models.CASCADE)
    date_joined = models.DateField(verbose_name=_("Date joined"))
    invite_reason = models.CharField(max_length=64, verbose_name=_("Invite reason"))

    class Meta:
        constraints = [models.UniqueConstraint(fields=["person", "group"], name="unique_person_group")]
