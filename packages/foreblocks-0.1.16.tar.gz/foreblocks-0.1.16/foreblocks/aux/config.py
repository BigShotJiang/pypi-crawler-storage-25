from dataclasses import dataclass
from typing import List, Optional


@dataclass
class ModelConfig:
    """Configuration for the sequence-to-sequence model architecture."""

    model_type: str = "lstm"
    input_size: int = 1
    output_size: int = 1
    hidden_size: int = 64
    seq_len: int = 10
    target_len: int = 10
    strategy: str = "seq2seq"
    teacher_forcing_ratio: float = 0.5
    input_processor_output_size: Optional[int] = None
    input_skip_connection: bool = False
    dim_feedforward: int = 512
    multi_encoder_decoder: bool = False
    dropout: float = 0.2
    num_encoder_layers: int = 1
    num_decoder_layers: int = 1
    latent_size: Optional[int] = 32  # for VAE
    nheads: int = 8


@dataclass
class TrainingConfig:
    """Type-safe training configuration with NAS + conformal support."""

    num_epochs: int = 100
    learning_rate: float = 0.001
    weight_decay: float = 0.0
    batch_size: int = 32
    patience: int = 10
    min_delta: float = 1e-4
    use_amp: bool = True
    gradient_clip_val: Optional[float] = None
    gradient_accumulation_steps: int = 1
    l1_regularization: float = 0.0
    kl_weight: float = 1.0
    scheduler_type: Optional[str] = None
    lr_step_size: int = 30
    lr_gamma: float = 0.1
    min_lr: float = 1e-6
    verbose: bool = True
    log_interval: int = 10
    save_best_model: bool = True
    save_model_path: Optional[str] = None
    experiment_name: str = "default_experiment"

    # MoE logging toggles
    moe_logging: bool = False
    moe_log_latency: bool = False
    moe_condition_name: Optional[str] = None
    moe_condition_cardinality: Optional[int] = None

    # ── NEW: NAS training toggles ──
    train_nas: bool = False  # Enable two-step NAS optimization
    nas_alpha_lr: float = 3e-4  # Learning rate for α parameters
    nas_alpha_weight_decay: float = 1e-3  # Weight decay for α
    nas_warmup_epochs: int = 5  # Epochs before starting α optimization
    nas_alternate_steps: int = 1  # Steps of α opt per weight opt step
    nas_use_val_for_alpha: bool = True  # Use validation loss for α updates
    nas_discretize_at_end: bool = True  # Discretize alphas after training
    nas_discretize_threshold: float = 0.5  # Threshold for discretization
    nas_log_alphas: bool = True  # Log alpha values during training

    # Conformal prediction
    conformal_enabled: bool = False
    conformal_method: str = "split"
    conformal_quantile: float = 0.9
    conformal_knn_k: int = 50
    conformal_local_window: int = 5000
    conformal_aci_gamma: float = 0.01
    conformal_rolling_alpha: float = 0.1
    conformal_agaci_gammas: Optional[List[float]] = None
    conformal_enbpi_B: int = 20
    conformal_enbpi_window: int = 500
    conformal_tsp_lambda: float = 0.01
    conformal_tsp_window: int = 5000
    conformal_cptc_window: int = 500
    conformal_cptc_tau: float = 1.0
    conformal_cptc_hard_state_filter: bool = False
    conformal_afocp_feature_dim: int = 128
    conformal_afocp_attn_hidden: int = 64
    conformal_afocp_window: int = 500
    conformal_afocp_tau: float = 1.0
    conformal_afocp_internal_feat_hidden: int = 256
    conformal_afocp_internal_feat_depth: int = 3
    conformal_afocp_internal_feat_dropout: float = 0.1
    conformal_afocp_online_lr: float = 0.0
    conformal_afocp_online_steps: int = 1

    def __post_init__(self):
        if self.conformal_agaci_gammas is None:
            self.conformal_agaci_gammas = [0.001, 0.005, 0.01, 0.05, 0.1, 0.2]

    def update(self, **kwargs):
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
            else:
                raise KeyError(f"Config key '{key}' not found")

    def get_conformal_params(self) -> dict:
        return {
            "method": self.conformal_method,
            "quantile": self.conformal_quantile,
            "knn_k": self.conformal_knn_k,
            "local_window": self.conformal_local_window,
            "aci_gamma": self.conformal_aci_gamma,
            "agaci_gammas": self.conformal_agaci_gammas,
            "enbpi_B": self.conformal_enbpi_B,
            "enbpi_window": self.conformal_enbpi_window,
            "tsp_lambda": self.conformal_tsp_lambda,
            "tsp_window": self.conformal_tsp_window,
            "cptc_window": self.conformal_cptc_window,
            "cptc_tau": self.conformal_cptc_tau,
            "cptc_hard_state_filter": self.conformal_cptc_hard_state_filter,
            "afocp_feature_dim": self.conformal_afocp_feature_dim,
            "afocp_attn_hidden": self.conformal_afocp_attn_hidden,
            "afocp_window": self.conformal_afocp_window,
            "afocp_tau": self.conformal_afocp_tau,
            "afocp_internal_feat_hidden": self.conformal_afocp_internal_feat_hidden,
            "afocp_internal_feat_depth": self.conformal_afocp_internal_feat_depth,
            "afocp_internal_feat_dropout": self.conformal_afocp_internal_feat_dropout,
            "afocp_online_lr": self.conformal_afocp_online_lr,
            "afocp_online_steps": self.conformal_afocp_online_steps,
        }
