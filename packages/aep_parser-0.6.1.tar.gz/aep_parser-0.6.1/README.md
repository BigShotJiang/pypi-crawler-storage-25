# aep_parser is now py-aep

This package has been renamed. Use `pip install py-aep` instead.

New package: https://pypi.org/project/py-aep/
