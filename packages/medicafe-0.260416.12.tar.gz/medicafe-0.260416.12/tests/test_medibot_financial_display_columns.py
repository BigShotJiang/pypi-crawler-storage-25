from __future__ import print_function

import io
import os
import sys
import unittest
from datetime import datetime

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


class MediBotFinancialColumnsTests(unittest.TestCase):
    def test_medibot_ui_table_includes_it_code_and_rem_amt(self):
        from MediBot import MediBot_UI

        patient_info = [
            (datetime(2026, 1, 2), 'DOE, JANE', '12345', 'H25', {'Patient ID #2': '12345'})
        ]

        fake_payload = {
            'it_code_display': '12',
            'remaining_amount_display': '$ 250.00'
        }

        fake_lifecycle = {
            'claim_state_display': 'Submitted',
            'claim_substatus_display': 'OPTUMAI <24h'
        }

        with patch('MediBot.MediBot_UI.get_patient_financial_display', return_value=fake_payload), \
             patch('MediBot.MediBot_UI.get_claim_lifecycle_display_for_row', return_value=fake_lifecycle):
            stream = io.StringIO()
            old_stdout = sys.stdout
            try:
                sys.stdout = stream
                MediBot_UI.display_enhanced_patient_table(
                    patient_info,
                    'Test Table',
                    show_line_numbers=True,
                    config={}
                )
            finally:
                sys.stdout = old_stdout

        output = stream.getvalue()
        self.assertIn('IT Code', output)
        self.assertIn('Rem Amt', output)
        self.assertIn('CLM State', output)
        self.assertIn('CLM Detail', output)
        self.assertIn('12', output)
        self.assertIn('$ 250.00', output)
        self.assertIn('Submitted', output)
        self.assertIn('OPTUMAI <24h', output)

    def test_notepad_table_includes_it_code_and_rem_amt(self):
        from MediBot import MediBot_Notepad_Utils

        patient_info = [
            (datetime(2026, 1, 2), 'DOE, JANE', '12345', 'H25', {'Patient ID #2': '12345'})
        ]
        fake_payload = {
            'it_code_display': 'CI',
            'remaining_amount_display': '$ 100.00'
        }

        fake_lifecycle = {
            'claim_state_display': 'Not Sent',
            'claim_substatus_display': '-'
        }

        with patch('MediBot.MediBot_Notepad_Utils.get_patient_financial_display', return_value=fake_payload), \
             patch('MediBot.MediBot_Notepad_Utils.get_claim_lifecycle_display_for_row', return_value=fake_lifecycle):
            content = MediBot_Notepad_Utils.format_patient_table_for_notepad(
                patient_info,
                'Notepad Test',
                config={}
            )

        self.assertIn('IT Code', content)
        self.assertIn('Rem Amt', content)
        self.assertIn('CLM State', content)
        self.assertIn('CLM Detail', content)
        self.assertIn('CI', content)
        self.assertIn('$ 100.00', content)
        self.assertIn('Not Sent', content)

    def test_generate_combined_notepad_builds_lifecycle_context_once(self):
        from MediBot import MediBot_Notepad_Utils

        existing_info = [
            (datetime(2026, 1, 2), 'DOE, JANE', '12345', 'H25', {'Patient ID #2': '12345'})
        ]
        dual_info = [
            (datetime(2026, 1, 3), 'DOE, JANE', '12345', 'H25', {'Patient ID #2': '12345'})
        ]
        fake_payload = {
            'it_code_display': 'CI',
            'remaining_amount_display': '$ 100.00'
        }
        fake_lifecycle = {
            'claim_state_display': 'Submitted',
            'claim_substatus_display': 'OPTUMAI <24h'
        }

        with patch('MediBot.MediBot_Notepad_Utils.get_patient_financial_display', return_value=fake_payload), \
             patch('MediBot.MediBot_Notepad_Utils.get_claim_lifecycle_display_for_row', return_value=fake_lifecycle), \
             patch('MediBot.MediBot_Notepad_Utils.build_claim_lifecycle_context', return_value={'_ctx': True}) as mock_build, \
             patch('MediBot.MediBot_Notepad_Utils.create_and_open_notepad_file', return_value='fake.txt'):
            out = MediBot_Notepad_Utils.generate_combined_patients_notepad(
                existing_info,
                'Existing',
                dual_info,
                'Dual-Date',
                config={}
            )

        self.assertEqual('fake.txt', out)
        self.assertEqual(1, mock_build.call_count)


if __name__ == '__main__':
    unittest.main()
