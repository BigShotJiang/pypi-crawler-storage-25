"""Application layer — use case orchestration."""
