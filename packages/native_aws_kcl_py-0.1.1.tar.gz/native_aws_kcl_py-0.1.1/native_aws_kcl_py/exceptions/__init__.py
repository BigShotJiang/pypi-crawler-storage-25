"""Exception hierarchy for the Native Kinesis Consumer Library.

Based on the AWS KCL exception model. This module provides comprehensive
exception types for handling various failure scenarios in Kinesis stream processing.
"""

# =============================================================================
# Base Exception Classes
# =============================================================================


class KinesisClientLibraryException(Exception):
    """Base exception for all KCL-related errors.

    All KCL exceptions extend from this class.
    """

    def __init__(
        self,
        message: str,
        retryable: bool = False,
        cause: Exception | None = None,
    ):
        super().__init__(message)
        self.retryable = retryable
        self.cause = cause


# =============================================================================
# Checkpoint Exceptions
# =============================================================================


class CheckpointException(KinesisClientLibraryException):
    """Base exception for checkpoint-related errors."""

    pass


class LeaseLostException(CheckpointException):
    """Exception thrown when attempting to checkpoint but the lease has been lost.

    This is NOT retryable - the processor should stop processing immediately.
    """

    def __init__(self, message: str, shard_id: str, cause: Exception | None = None):
        super().__init__(message, retryable=False, cause=cause)
        self.shard_id = shard_id


class InvalidStateException(CheckpointException):
    """Exception thrown when checkpoint fails due to invalid state.

    For example, trying to checkpoint a sequence number that hasn't been processed.
    """

    def __init__(self, message: str, cause: Exception | None = None):
        super().__init__(message, retryable=False, cause=cause)


class ShutdownException(CheckpointException):
    """Exception thrown when attempting operations during shutdown.

    The worker is shutting down and cannot process the request.
    """

    def __init__(self, message: str, cause: Exception | None = None):
        super().__init__(message, retryable=False, cause=cause)


class ThrottlingException(CheckpointException):
    """Exception thrown when checkpoint is throttled by DynamoDB.

    This IS retryable after a backoff period.
    """

    def __init__(
        self,
        message: str,
        retry_after_millis: int = 1000,
        cause: Exception | None = None,
    ):
        super().__init__(message, retryable=True, cause=cause)
        self.retry_after_millis = retry_after_millis


# =============================================================================
# Lease Exceptions
# =============================================================================


class LeaseException(KinesisClientLibraryException):
    """Base exception for lease-related errors."""

    pass


class LeaseProvisionedThroughputExceededException(LeaseException):
    """Exception thrown when a lease operation fails due to provisioned
    throughput exceeded condition in DynamoDB.
    """

    def __init__(self, message: str, cause: Exception | None = None):
        super().__init__(message, retryable=True, cause=cause)


class LeaseDependencyException(LeaseException):
    """Exception thrown when there's a dependency failure in lease operations.

    Typically indicates a service-side issue.
    """

    def __init__(self, message: str, cause: Exception | None = None):
        super().__init__(message, retryable=True, cause=cause)


class LeaseConditionalCheckFailedException(LeaseException):
    """Exception thrown when a conditional check fails during lease operations.

    This usually means the lease was modified by another worker.
    """

    def __init__(self, message: str, lease_key: str, cause: Exception | None = None):
        super().__init__(message, retryable=False, cause=cause)
        self.lease_key = lease_key


class LeaseTimeoutException(LeaseException):
    """Exception thrown when a lease operation times out."""

    def __init__(self, message: str, cause: Exception | None = None):
        super().__init__(message, retryable=True, cause=cause)


class LeaseTableNotFoundException(LeaseException):
    """Exception thrown when the lease table doesn't exist or is not accessible."""

    def __init__(self, message: str, table_name: str, cause: Exception | None = None):
        super().__init__(message, retryable=False, cause=cause)
        self.table_name = table_name


# =============================================================================
# Kinesis Exceptions
# =============================================================================


class KinesisException(KinesisClientLibraryException):
    """Base exception for Kinesis-related errors."""

    pass


class ExpiredIteratorException(KinesisException):
    """Exception thrown when the shard iterator expires.

    This IS retryable - the consumer should get a new iterator.
    """

    def __init__(self, message: str, shard_id: str, cause: Exception | None = None):
        super().__init__(message, retryable=True, cause=cause)
        self.shard_id = shard_id


class KinesisProvisionedThroughputExceededException(KinesisException):
    """Exception thrown when Kinesis provisioned throughput is exceeded.

    This IS retryable after a backoff period.
    """

    def __init__(
        self,
        message: str,
        shard_id: str,
        retry_after_millis: int = 1000,
        cause: Exception | None = None,
    ):
        super().__init__(message, retryable=True, cause=cause)
        self.shard_id = shard_id
        self.retry_after_millis = retry_after_millis


class ResourceNotFoundException(KinesisException):
    """Exception thrown when the requested shard doesn't exist."""

    def __init__(self, message: str, resource_name: str, cause: Exception | None = None):
        super().__init__(message, retryable=False, cause=cause)
        self.resource_name = resource_name


class ResourceInUseException(KinesisException):
    """Exception thrown when there's a resource in use conflict."""

    def __init__(self, message: str, resource_name: str, cause: Exception | None = None):
        super().__init__(message, retryable=False, cause=cause)
        self.resource_name = resource_name


class KinesisTimeoutException(KinesisException):
    """Exception thrown when a Kinesis Data Streams request times out."""

    def __init__(self, message: str, cause: Exception | None = None):
        super().__init__(message, retryable=True, cause=cause)


class KinesisInternalException(KinesisException):
    """Exception thrown when there's an internal Kinesis error."""

    def __init__(self, message: str, cause: Exception | None = None):
        super().__init__(message, retryable=True, cause=cause)


# =============================================================================
# Processing Exceptions
# =============================================================================


class ProcessingException(KinesisClientLibraryException):
    """Base exception for record processing errors."""

    pass


class ProcessingTimeoutException(ProcessingException):
    """Exception thrown when record processing times out."""

    def __init__(
        self,
        message: str,
        shard_id: str,
        timeout_millis: int,
        cause: Exception | None = None,
    ):
        super().__init__(message, retryable=True, cause=cause)
        self.shard_id = shard_id
        self.timeout_millis = timeout_millis


class MaxConsecutiveFailuresException(ProcessingException):
    """Exception thrown when the processor fails consecutively too many times."""

    def __init__(
        self,
        message: str,
        shard_id: str,
        failure_count: int,
        cause: Exception | None = None,
    ):
        super().__init__(message, retryable=False, cause=cause)
        self.shard_id = shard_id
        self.failure_count = failure_count


class ProcessorInitializationException(ProcessingException):
    """Exception thrown when initialization of the record processor fails."""

    def __init__(self, message: str, shard_id: str, cause: Exception | None = None):
        super().__init__(message, retryable=False, cause=cause)
        self.shard_id = shard_id


# =============================================================================
# Scheduler Exceptions
# =============================================================================


class SchedulerException(KinesisClientLibraryException):
    """Base exception for scheduler-related errors."""

    pass


class SchedulerInitializationException(SchedulerException):
    """Exception thrown when the scheduler fails to initialize."""

    def __init__(self, message: str, cause: Exception | None = None):
        super().__init__(message, retryable=False, cause=cause)


class InvalidSchedulerStateException(SchedulerException):
    """Exception thrown when there's an invalid scheduler state transition."""

    def __init__(
        self,
        message: str,
        current_state: str,
        requested_operation: str,
        cause: Exception | None = None,
    ):
        super().__init__(message, retryable=False, cause=cause)
        self.current_state = current_state
        self.requested_operation = requested_operation


# =============================================================================
# Shard Exceptions
# =============================================================================


class UnexpectedChildShardsException(KinesisClientLibraryException):
    """Exception thrown when unexpected child shards are encountered."""

    def __init__(
        self,
        message: str,
        parent_shard_id: str,
        child_shard_ids: list[str],
        cause: Exception | None = None,
    ):
        super().__init__(message, retryable=False, cause=cause)
        self.parent_shard_id = parent_shard_id
        self.child_shard_ids = child_shard_ids


class ParentShardNotCompletedException(KinesisClientLibraryException):
    """Exception thrown when parent shard processing is incomplete."""

    def __init__(
        self,
        message: str,
        shard_id: str,
        parent_shard_ids: list[str],
        cause: Exception | None = None,
    ):
        super().__init__(message, retryable=True, cause=cause)
        self.shard_id = shard_id
        self.parent_shard_ids = parent_shard_ids


# =============================================================================
# Configuration Exceptions
# =============================================================================


class InvalidConfigurationException(KinesisClientLibraryException):
    """Exception thrown when configuration is invalid."""

    def __init__(
        self,
        message: str,
        config_key: str,
        config_value: str | None = None,
        cause: Exception | None = None,
    ):
        super().__init__(message, retryable=False, cause=cause)
        self.config_key = config_key
        self.config_value = config_value


class MissingConfigurationException(KinesisClientLibraryException):
    """Exception thrown when required configuration is missing."""

    def __init__(self, message: str, config_key: str, cause: Exception | None = None):
        super().__init__(message, retryable=False, cause=cause)
        self.config_key = config_key


# =============================================================================
# Utility Functions
# =============================================================================


RETRYABLE_ERROR_NAMES = [
    "ProvisionedThroughputExceededException",
    "ThrottlingException",
    "RequestLimitExceeded",
    "InternalServerError",
    "ServiceUnavailable",
    "TimeoutError",
    "NetworkError",
]


def is_retryable_exception(error: Exception) -> bool:
    """Check if an error is retryable."""
    if isinstance(error, KinesisClientLibraryException):
        return error.retryable

    # Check for common AWS SDK retryable errors
    error_name = type(error).__name__
    return any(name in error_name for name in RETRYABLE_ERROR_NAMES)


def is_lease_lost_exception(error: Exception) -> bool:
    """Check if the error indicates a lost lease."""
    if isinstance(error, LeaseLostException):
        return True

    error_message = str(error).lower()
    return "lease" in error_message and (
        "lost" in error_message or "stolen" in error_message or "conditional" in error_message
    )


__all__ = [
    # Base
    "KinesisClientLibraryException",
    # Checkpoint
    "CheckpointException",
    "LeaseLostException",
    "InvalidStateException",
    "ShutdownException",
    "ThrottlingException",
    # Lease
    "LeaseException",
    "LeaseProvisionedThroughputExceededException",
    "LeaseDependencyException",
    "LeaseConditionalCheckFailedException",
    "LeaseTimeoutException",
    "LeaseTableNotFoundException",
    # Kinesis
    "KinesisException",
    "ExpiredIteratorException",
    "KinesisProvisionedThroughputExceededException",
    "ResourceNotFoundException",
    "ResourceInUseException",
    "KinesisTimeoutException",
    "KinesisInternalException",
    # Processing
    "ProcessingException",
    "ProcessingTimeoutException",
    "MaxConsecutiveFailuresException",
    "ProcessorInitializationException",
    # Scheduler
    "SchedulerException",
    "SchedulerInitializationException",
    "InvalidSchedulerStateException",
    # Shard
    "UnexpectedChildShardsException",
    "ParentShardNotCompletedException",
    # Configuration
    "InvalidConfigurationException",
    "MissingConfigurationException",
    # Utilities
    "is_retryable_exception",
    "is_lease_lost_exception",
]
