"""Lease renewer for maintaining lease ownership."""

import logging
from typing import TYPE_CHECKING

from ..metrics import IMetricsFactory, KCLMetrics, NoOpMetricsFactory
from ..types import ExtendedSequenceNumber, Lease

if TYPE_CHECKING:
    from .dynamodb_lease_refresher import DynamoDBLeaseRefresher


class LeaseRenewer:
    """Responsible for renewing leases owned by this worker.

    The renewer maintains a local cache of owned leases and periodically
    renews them to maintain ownership.
    """

    _logger = logging.getLogger("kcl.LeaseRenewer")

    def __init__(
        self,
        lease_refresher: "DynamoDBLeaseRefresher",
        worker_identifier: str,
        lease_duration_millis: int,
        metrics_factory: IMetricsFactory | None = None,
    ):
        """Initialize the lease renewer.

        Args:
            lease_refresher: The lease refresher implementation
            worker_identifier: This worker's identifier
            lease_duration_millis: Lease duration in milliseconds
            metrics_factory: Optional metrics factory
        """
        self._lease_refresher = lease_refresher
        self._worker_identifier = worker_identifier
        self._lease_duration_millis = lease_duration_millis
        self._metrics_factory = metrics_factory or NoOpMetricsFactory()
        self._owned_leases: dict[str, Lease] = {}

    def add_lease(self, lease: Lease) -> None:
        """Add a lease to be renewed.

        Args:
            lease: The lease to add
        """
        self._owned_leases[lease.lease_key] = lease

    def remove_lease(self, lease_key: str) -> None:
        """Remove a lease from renewal.

        Args:
            lease_key: The lease key to remove
        """
        self._owned_leases.pop(lease_key, None)

    def get_owned_leases(self) -> dict[str, Lease]:
        """Get all leases owned by this worker.

        Returns:
            Dictionary of lease key to lease
        """
        return dict(self._owned_leases)

    def get_lease(self, lease_key: str) -> Lease | None:
        """Get a specific lease.

        Args:
            lease_key: The lease key

        Returns:
            The lease if owned, None otherwise
        """
        return self._owned_leases.get(lease_key)

    def owns_lease(self, lease_key: str) -> bool:
        """Check if this worker owns a lease.

        Args:
            lease_key: The lease key

        Returns:
            True if this worker owns the lease
        """
        return lease_key in self._owned_leases

    def clear(self) -> None:
        """Clear all owned leases."""
        self._owned_leases.clear()

    async def renew_leases(self) -> list[str]:
        """Renew all owned leases.

        Returns:
            List of lease keys that were lost during renewal
        """
        lost_leases: list[str] = []
        scope = self._metrics_factory.create_scope("RenewAllLeases")

        try:
            renewed_count = 0
            failed_count = 0

            for lease_key, lease in list(self._owned_leases.items()):
                try:
                    success = await self._lease_refresher.renew_lease(lease)
                    if success:
                        renewed_count += 1
                    else:
                        # Lease was modified by another worker
                        self._logger.warning(f"Lost lease {lease_key} during renewal")
                        lost_leases.append(lease_key)
                        self._owned_leases.pop(lease_key, None)
                        failed_count += 1

                except Exception as e:
                    self._logger.error(f"Error renewing lease {lease_key}: {e}")
                    failed_count += 1
                    # Don't remove the lease - will retry next cycle

            scope.add_count(KCLMetrics.RENEW_LEASE_SUCCESS, renewed_count)
            scope.add_count(KCLMetrics.RENEW_LEASE_FAILURE, failed_count)
            scope.add_count(KCLMetrics.CURRENT_LEASES, len(self._owned_leases))
            scope.add_count(KCLMetrics.LOST_LEASES, len(lost_leases))

            if renewed_count > 0:
                self._logger.debug(f"Renewed {renewed_count} leases")

            return lost_leases

        finally:
            scope.end()

    async def update_lease_with_checkpoint(
        self,
        lease_key: str,
        sequence_number: str,
        sub_sequence_number: int,
    ) -> bool:
        """Update a lease with a checkpoint.

        Args:
            lease_key: The lease key
            sequence_number: The sequence number to checkpoint
            sub_sequence_number: The sub-sequence number

        Returns:
            True if successful, False otherwise
        """
        lease = self._owned_leases.get(lease_key)
        if not lease:
            self._logger.warning(f"Cannot checkpoint lease {lease_key} - not owned")
            return False

        # Update the checkpoint
        lease.checkpoint = ExtendedSequenceNumber(
            sequence_number=sequence_number,
            sub_sequence_number=sub_sequence_number,
        )

        try:
            success = await self._lease_refresher.update_lease(lease)
            if not success:
                self._logger.warning(f"Failed to checkpoint lease {lease_key}")
            return success

        except Exception as e:
            self._logger.error(f"Error checkpointing lease {lease_key}: {e}")
            raise

    async def update_lease_with_pending_checkpoint(
        self,
        lease_key: str,
        sequence_number: str,
        sub_sequence_number: int,
    ) -> bool:
        """Update a lease with a pending checkpoint (two-phase).

        Args:
            lease_key: The lease key
            sequence_number: The sequence number to prepare
            sub_sequence_number: The sub-sequence number

        Returns:
            True if successful, False otherwise
        """
        lease = self._owned_leases.get(lease_key)
        if not lease:
            self._logger.warning(f"Cannot prepare checkpoint for lease {lease_key} - not owned")
            return False

        # Update the pending checkpoint
        lease.pending_checkpoint = ExtendedSequenceNumber(
            sequence_number=sequence_number,
            sub_sequence_number=sub_sequence_number,
        )

        try:
            success = await self._lease_refresher.update_lease(lease)
            if not success:
                self._logger.warning(f"Failed to prepare checkpoint for lease {lease_key}")
            return success

        except Exception as e:
            self._logger.error(f"Error preparing checkpoint for lease {lease_key}: {e}")
            raise
