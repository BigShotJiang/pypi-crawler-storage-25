"""DynamoDB-based implementation of LeaseRefresher.

Handles all lease storage operations using DynamoDB.
Based on the AWS KCL DynamoDB lease refresher.
"""

import asyncio
import logging
import time
from typing import Any

import aioboto3
from botocore.config import Config
from botocore.exceptions import ClientError

from ..exceptions import (
    LeaseConditionalCheckFailedException,
    LeaseDependencyException,
    LeaseException,
    LeaseProvisionedThroughputExceededException,
    LeaseTableNotFoundException,
    LeaseTimeoutException,
)
from ..types import ExtendedSequenceNumber, Lease, LeaseManagementConfig
from ..utils import BackoffConfig, JitterType, calculate_backoff_with_jitter


class DynamoDBLeaseRefresher:
    """DynamoDB-based implementation of LeaseRefresher.

    Handles all lease storage operations using DynamoDB.
    Includes comprehensive error handling for all DynamoDB exceptions.
    """

    _logger = logging.getLogger("kcl.DynamoDBLeaseRefresher")

    # DynamoDB attribute names
    LEASE_KEY = "leaseKey"
    LEASE_OWNER = "leaseOwner"
    LEASE_COUNTER = "leaseCounter"
    CHECKPOINT_SEQUENCE_NUMBER = "checkpoint"
    CHECKPOINT_SUB_SEQUENCE_NUMBER = "checkpointSubSequenceNumber"
    PENDING_CHECKPOINT_SEQUENCE_NUMBER = "pendingCheckpoint"
    PENDING_CHECKPOINT_SUB_SEQUENCE_NUMBER = "pendingCheckpointSubSequenceNumber"
    OWNER_SWITCHES_SINCE_CHECKPOINT = "ownerSwitchesSinceCheckpoint"
    PARENT_SHARD_IDS = "parentShardIds"
    CHILD_SHARD_IDS = "childShardIds"
    LAST_COUNTER_INCREMENT_NANOS = "lastCounterIncrementNanos"
    HASH_KEY_RANGE_START = "hashKeyRangeStart"
    HASH_KEY_RANGE_END = "hashKeyRangeEnd"

    # Retry configuration
    MAX_RETRIES = 3
    BASE_DELAY_MS = 100
    MAX_DELAY_MS = 5000

    def __init__(
        self,
        config: LeaseManagementConfig,
        region_name: str = "eu-west-1",
        endpoint_url: str | None = None,
    ):
        """Initialize the DynamoDB lease refresher.

        Args:
            config: Lease management configuration
            region_name: AWS region name
            endpoint_url: Optional custom endpoint URL (for local testing)
        """
        self._config = config
        self._table_name = config.table_name
        self._region_name = region_name
        self._endpoint_url = endpoint_url
        self._session = aioboto3.Session()
        self._boto_config = Config(retries={"max_attempts": 3, "mode": "standard"})

    async def _get_client(self):
        """Get a DynamoDB client context manager."""
        return self._session.client(
            "dynamodb",
            region_name=self._region_name,
            endpoint_url=self._endpoint_url,
            config=self._boto_config,
        )

    async def create_lease_table_if_not_exists(self) -> bool:
        """Create the lease table if it doesn't exist.

        Returns:
            True if table was created, False if it already existed.
        """
        try:
            exists = await self.lease_table_exists()
            if exists:
                return False

            async with await self._get_client() as client:  # type: ignore[attr-defined]
                create_params: dict[str, Any] = {
                    "TableName": self._table_name,
                    "KeySchema": [
                        {"AttributeName": self.LEASE_KEY, "KeyType": "HASH"},
                    ],
                    "AttributeDefinitions": [
                        {"AttributeName": self.LEASE_KEY, "AttributeType": "S"},
                    ],
                    "BillingMode": self._config.billing_mode,
                }

                if self._config.billing_mode == "PROVISIONED":
                    create_params["ProvisionedThroughput"] = {
                        "ReadCapacityUnits": self._config.read_capacity_units,
                        "WriteCapacityUnits": self._config.write_capacity_units,
                    }

                await client.create_table(**create_params)
                self._logger.info(f"Created lease table {self._table_name}")
                return True

        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            if error_code == "ResourceInUseException":
                return False
            raise self._wrap_dynamodb_error(e, f"Failed to create lease table {self._table_name}")

    async def wait_for_table_active(self) -> None:
        """Wait for the lease table to become active."""
        max_attempts = 30
        delay_ms = 1000

        for attempt in range(max_attempts):
            try:
                async with await self._get_client() as client:  # type: ignore[attr-defined]
                    response = await client.describe_table(TableName=self._table_name)
                    status = response.get("Table", {}).get("TableStatus")

                    if status == "ACTIVE":
                        return

                    self._logger.debug(f"Table {self._table_name} status: {status}, waiting...")

            except ClientError as e:
                error_code = e.response.get("Error", {}).get("Code", "")
                if error_code == "ResourceNotFoundException":
                    raise LeaseTableNotFoundException(
                        f"Lease table {self._table_name} does not exist",
                        self._table_name,
                        e,
                    )
                raise self._wrap_dynamodb_error(e, f"Failed to describe table {self._table_name}")

            await asyncio.sleep(delay_ms / 1000)

        raise LeaseTimeoutException(
            f"Table {self._table_name} did not become active within {max_attempts * delay_ms}ms"
        )

    async def lease_table_exists(self) -> bool:
        """Check if the lease table exists."""
        try:
            async with await self._get_client() as client:  # type: ignore[attr-defined]
                await client.describe_table(TableName=self._table_name)
                return True
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            if error_code == "ResourceNotFoundException":
                return False
            raise self._wrap_dynamodb_error(e, f"Failed to check if table {self._table_name} exists")

    async def list_leases(self) -> list[Lease]:
        """List all leases from the table."""
        leases: list[Lease] = []
        last_evaluated_key = None

        try:
            async with await self._get_client() as client:  # type: ignore[attr-defined]
                while True:
                    scan_params: dict[str, Any] = {"TableName": self._table_name}
                    if last_evaluated_key:
                        scan_params["ExclusiveStartKey"] = last_evaluated_key

                    response = await self._execute_with_retry(lambda: client.scan(**scan_params))

                    for item in response.get("Items", []):
                        lease = self._item_to_lease(item)
                        if lease:
                            leases.append(lease)

                    last_evaluated_key = response.get("LastEvaluatedKey")
                    if not last_evaluated_key:
                        break

            return leases

        except Exception as e:
            if isinstance(e, LeaseException):
                raise
            raise self._wrap_dynamodb_error(e, f"Failed to list leases from table {self._table_name}")

    async def get_lease(self, lease_key: str) -> Lease | None:
        """Get a specific lease by key."""
        try:
            async with await self._get_client() as client:  # type: ignore[attr-defined]
                response = await self._execute_with_retry(
                    lambda: client.get_item(
                        TableName=self._table_name,
                        Key={self.LEASE_KEY: {"S": lease_key}},
                        ConsistentRead=True,
                    )
                )

                item = response.get("Item")
                if not item:
                    return None

                return self._item_to_lease(item)

        except Exception as e:
            if isinstance(e, LeaseException):
                raise
            raise self._wrap_dynamodb_error(e, f"Failed to get lease {lease_key}")

    async def create_lease(self, lease: Lease) -> bool:
        """Create a new lease.

        Returns:
            True if created, False if already exists.
        """
        try:
            item = self._lease_to_item(lease)

            async with await self._get_client() as client:  # type: ignore[attr-defined]
                await self._execute_with_retry(
                    lambda: client.put_item(
                        TableName=self._table_name,
                        Item=item,
                        ConditionExpression=f"attribute_not_exists({self.LEASE_KEY})",
                    )
                )
            return True

        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            if error_code == "ConditionalCheckFailedException":
                return False
            raise self._wrap_dynamodb_error(e, f"Failed to create lease {lease.lease_key}")

    async def renew_lease(self, lease: Lease) -> bool:
        """Renew a lease (increment counter and update timestamp).

        Returns:
            True if renewed, False if lease was modified by another worker.
        """
        try:
            now = int(time.time() * 1_000_000_000)  # Convert to nanos

            async with await self._get_client() as client:  # type: ignore[attr-defined]
                update_expr = (
                    f"SET {self.LEASE_COUNTER} = {self.LEASE_COUNTER} + :inc, "
                    f"{self.LAST_COUNTER_INCREMENT_NANOS} = :now"
                )
                condition_expr = f"{self.LEASE_COUNTER} = :expectedCounter AND {self.LEASE_OWNER} = :owner"
                await client.update_item(
                    TableName=self._table_name,
                    Key={self.LEASE_KEY: {"S": lease.lease_key}},
                    UpdateExpression=update_expr,
                    ConditionExpression=condition_expr,
                    ExpressionAttributeValues={
                        ":inc": {"N": "1"},
                        ":now": {"N": str(now)},
                        ":expectedCounter": {"N": str(lease.lease_counter)},
                        ":owner": {"S": lease.lease_owner or ""},
                    },
                )

            # Update the local lease object
            lease.lease_counter += 1
            lease.last_counter_increment_nanos = now
            return True

        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            if error_code == "ConditionalCheckFailedException":
                self._logger.debug(f"Lease {lease.lease_key} renewal failed - conditional check failed")
                return False
            if error_code == "ProvisionedThroughputExceededException":
                raise LeaseProvisionedThroughputExceededException(
                    f"Provisioned throughput exceeded while renewing lease {lease.lease_key}",
                    e,
                )
            raise self._wrap_dynamodb_error(e, f"Failed to renew lease {lease.lease_key}")

    async def take_lease(self, lease: Lease, new_owner: str) -> bool:
        """Take a lease from another worker.

        Returns:
            True if taken, False if conditional check failed.
        """
        try:
            now = int(time.time() * 1_000_000_000)
            new_counter = lease.lease_counter + 1
            new_owner_switches = (lease.owner_switches_since_checkpoint or 0) + 1

            update_expression_parts = [
                f"{self.LEASE_COUNTER} = :newCounter",
                f"{self.LEASE_OWNER} = :newOwner",
                f"{self.LAST_COUNTER_INCREMENT_NANOS} = :now",
                f"{self.OWNER_SWITCHES_SINCE_CHECKPOINT} = :ownerSwitches",
            ]

            expression_values: dict[str, Any] = {
                ":newCounter": {"N": str(new_counter)},
                ":newOwner": {"S": new_owner},
                ":now": {"N": str(now)},
                ":ownerSwitches": {"N": str(new_owner_switches)},
                ":expectedCounter": {"N": str(lease.lease_counter)},
            }

            # Condition depends on whether lease has an owner
            if lease.lease_owner:
                condition_expression = f"{self.LEASE_COUNTER} = :expectedCounter AND {self.LEASE_OWNER} = :currentOwner"
                expression_values[":currentOwner"] = {"S": lease.lease_owner}
            else:
                condition_expression = (
                    f"{self.LEASE_COUNTER} = :expectedCounter AND " f"attribute_not_exists({self.LEASE_OWNER})"
                )

            async with await self._get_client() as client:  # type: ignore[attr-defined]
                await client.update_item(
                    TableName=self._table_name,
                    Key={self.LEASE_KEY: {"S": lease.lease_key}},
                    UpdateExpression=f"SET {', '.join(update_expression_parts)}",
                    ConditionExpression=condition_expression,
                    ExpressionAttributeValues=expression_values,
                )

            # Update local lease object
            lease.lease_counter = new_counter
            lease.lease_owner = new_owner
            lease.last_counter_increment_nanos = now
            lease.owner_switches_since_checkpoint = new_owner_switches

            self._logger.info(f"Successfully took lease {lease.lease_key}")
            return True

        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            if error_code == "ConditionalCheckFailedException":
                self._logger.debug(f"Failed to take lease {lease.lease_key} - conditional check failed")
                return False
            raise self._wrap_dynamodb_error(e, f"Failed to take lease {lease.lease_key}")

    async def evict_lease(self, lease: Lease) -> bool:
        """Evict the current owner from a lease."""
        try:
            now = int(time.time() * 1_000_000_000)
            new_counter = lease.lease_counter + 1

            update_expr = (
                f"SET {self.LEASE_COUNTER} = :newCounter, "
                f"{self.LAST_COUNTER_INCREMENT_NANOS} = :now "
                f"REMOVE {self.LEASE_OWNER}"
            )
            async with await self._get_client() as client:  # type: ignore[attr-defined]
                await client.update_item(
                    TableName=self._table_name,
                    Key={self.LEASE_KEY: {"S": lease.lease_key}},
                    UpdateExpression=update_expr,
                    ConditionExpression=f"{self.LEASE_COUNTER} = :expectedCounter",
                    ExpressionAttributeValues={
                        ":newCounter": {"N": str(new_counter)},
                        ":now": {"N": str(now)},
                        ":expectedCounter": {"N": str(lease.lease_counter)},
                    },
                )

            lease.lease_counter = new_counter
            lease.lease_owner = None
            lease.last_counter_increment_nanos = now
            return True

        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            if error_code == "ConditionalCheckFailedException":
                return False
            raise self._wrap_dynamodb_error(e, f"Failed to evict lease {lease.lease_key}")

    async def update_lease(self, lease: Lease) -> bool:
        """Update a lease (e.g., for checkpointing)."""
        try:
            now = int(time.time() * 1_000_000_000)
            new_counter = lease.lease_counter + 1

            update_expression_parts = [
                f"{self.LEASE_COUNTER} = :newCounter",
                f"{self.LAST_COUNTER_INCREMENT_NANOS} = :now",
            ]

            expression_values: dict[str, Any] = {
                ":newCounter": {"N": str(new_counter)},
                ":now": {"N": str(now)},
                ":expectedCounter": {"N": str(lease.lease_counter)},
                ":owner": {"S": lease.lease_owner or ""},
            }

            # Add checkpoint if present
            if lease.checkpoint:
                update_expression_parts.append(f"{self.CHECKPOINT_SEQUENCE_NUMBER} = :checkpoint")
                update_expression_parts.append(f"{self.CHECKPOINT_SUB_SEQUENCE_NUMBER} = :subSeq")
                update_expression_parts.append(f"{self.OWNER_SWITCHES_SINCE_CHECKPOINT} = :zero")
                expression_values[":checkpoint"] = {"S": lease.checkpoint.sequence_number}
                expression_values[":subSeq"] = {"N": str(lease.checkpoint.sub_sequence_number)}
                expression_values[":zero"] = {"N": "0"}

            # Add pending checkpoint if present
            if lease.pending_checkpoint:
                update_expression_parts.append(f"{self.PENDING_CHECKPOINT_SEQUENCE_NUMBER} = :pendingCheckpoint")
                update_expression_parts.append(f"{self.PENDING_CHECKPOINT_SUB_SEQUENCE_NUMBER} = :pendingSubSeq")
                expression_values[":pendingCheckpoint"] = {"S": lease.pending_checkpoint.sequence_number}
                expression_values[":pendingSubSeq"] = {"N": str(lease.pending_checkpoint.sub_sequence_number)}

            # Add child shards if present
            if lease.child_shard_ids and len(lease.child_shard_ids) > 0:
                update_expression_parts.append(f"{self.CHILD_SHARD_IDS} = :childShards")
                expression_values[":childShards"] = {"SS": lease.child_shard_ids}

            async with await self._get_client() as client:  # type: ignore[attr-defined]
                await client.update_item(
                    TableName=self._table_name,
                    Key={self.LEASE_KEY: {"S": lease.lease_key}},
                    UpdateExpression=f"SET {', '.join(update_expression_parts)}",
                    ConditionExpression=f"{self.LEASE_COUNTER} = :expectedCounter AND {self.LEASE_OWNER} = :owner",
                    ExpressionAttributeValues=expression_values,
                )

            lease.lease_counter = new_counter
            lease.last_counter_increment_nanos = now
            if lease.checkpoint:
                lease.owner_switches_since_checkpoint = 0

            return True

        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            if error_code == "ConditionalCheckFailedException":
                raise LeaseConditionalCheckFailedException(
                    f"Conditional check failed while updating lease {lease.lease_key} - lease may have been stolen",
                    lease.lease_key,
                    e,
                )
            if error_code == "ProvisionedThroughputExceededException":
                raise LeaseProvisionedThroughputExceededException(
                    f"Provisioned throughput exceeded while updating lease {lease.lease_key}",
                    e,
                )
            raise self._wrap_dynamodb_error(e, f"Failed to update lease {lease.lease_key}")

    async def delete_lease(self, lease: Lease) -> bool:
        """Delete a lease."""
        try:
            async with await self._get_client() as client:  # type: ignore[attr-defined]
                await client.delete_item(
                    TableName=self._table_name,
                    Key={self.LEASE_KEY: {"S": lease.lease_key}},
                    ConditionExpression=f"{self.LEASE_COUNTER} = :expectedCounter",
                    ExpressionAttributeValues={
                        ":expectedCounter": {"N": str(lease.lease_counter)},
                    },
                )
            return True

        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            if error_code == "ConditionalCheckFailedException":
                return False
            raise self._wrap_dynamodb_error(e, f"Failed to delete lease {lease.lease_key}")

    async def delete_all_leases(self) -> None:
        """Delete all leases (for cleanup)."""
        leases = await self.list_leases()

        async with await self._get_client() as client:  # type: ignore[attr-defined]
            for lease in leases:
                try:
                    await client.delete_item(
                        TableName=self._table_name,
                        Key={self.LEASE_KEY: {"S": lease.lease_key}},
                    )
                except Exception as e:
                    self._logger.warning(f"Failed to delete lease {lease.lease_key}: {e}")

    def is_lease_expired(self, lease: Lease, lease_duration_millis: int) -> bool:
        """Check if a lease is expired."""
        if not lease.last_counter_increment_nanos:
            return True

        last_update_millis = lease.last_counter_increment_nanos / 1_000_000
        now = time.time() * 1000

        return (now - last_update_millis) > lease_duration_millis

    async def _execute_with_retry(self, fn):
        """Execute a function with retry logic for throttling."""
        last_error = None

        for attempt in range(self.MAX_RETRIES):
            try:
                return await fn()
            except ClientError as e:
                last_error = e
                error_code = e.response.get("Error", {}).get("Code", "")

                # Only retry on throttling/capacity errors
                if error_code in [
                    "ProvisionedThroughputExceededException",
                    "RequestLimitExceeded",
                    "InternalServerError",
                ]:
                    delay_ms = calculate_backoff_with_jitter(
                        attempt,
                        BackoffConfig(
                            base_delay_ms=self.BASE_DELAY_MS,
                            max_delay_ms=self.MAX_DELAY_MS,
                            jitter_type=JitterType.FULL,
                        ),
                    )
                    self._logger.warning(
                        f"DynamoDB operation throttled (attempt {attempt + 1}/{self.MAX_RETRIES}), "
                        f"retrying in {delay_ms}ms (with jitter)"
                    )
                    await asyncio.sleep(delay_ms / 1000)
                    continue

                # Don't retry other errors
                raise

        raise LeaseProvisionedThroughputExceededException(
            f"DynamoDB operation failed after {self.MAX_RETRIES} retries",
            last_error,
        )

    def _wrap_dynamodb_error(self, error: Exception, context: str) -> LeaseException:
        """Wrap a DynamoDB error in an appropriate lease exception."""
        if isinstance(error, LeaseException):
            return error

        if isinstance(error, ClientError):
            error_code = error.response.get("Error", {}).get("Code", "")

            if error_code == "ProvisionedThroughputExceededException":
                return LeaseProvisionedThroughputExceededException(f"{context}: {error}", error)

            if error_code in ["ResourceNotFoundException", "TableNotFoundException"]:
                return LeaseTableNotFoundException(f"{context}: Table not found", self._table_name, error)

            if error_code == "ConditionalCheckFailedException":
                return LeaseConditionalCheckFailedException(f"{context}: Conditional check failed", "unknown", error)

            if error_code == "ItemCollectionSizeLimitExceededException":
                return LeaseDependencyException(f"{context}: Item collection size limit exceeded", error)

            if error_code == "InternalServerError":
                return LeaseDependencyException(f"{context}: DynamoDB internal server error", error)

        # Generic wrapper
        error_name = type(error).__name__
        retryable = any(
            name in error_name
            for name in [
                "ProvisionedThroughputExceededException",
                "RequestLimitExceeded",
                "InternalServerError",
                "ServiceUnavailable",
                "ThrottlingException",
                "TimeoutError",
            ]
        )

        return LeaseException(f"{context}: {error}", retryable, error)

    def _item_to_lease(self, item: dict[str, Any]) -> Lease | None:
        """Convert a DynamoDB item to a Lease object."""
        lease_key = item.get(self.LEASE_KEY, {}).get("S")
        if not lease_key:
            return None

        lease = Lease(
            lease_key=lease_key,
            lease_counter=int(item.get(self.LEASE_COUNTER, {}).get("N", "0")),
        )

        if self.LEASE_OWNER in item:
            lease.lease_owner = item[self.LEASE_OWNER].get("S")

        if self.CHECKPOINT_SEQUENCE_NUMBER in item:
            lease.checkpoint = ExtendedSequenceNumber(
                sequence_number=item[self.CHECKPOINT_SEQUENCE_NUMBER]["S"],
                sub_sequence_number=int(item.get(self.CHECKPOINT_SUB_SEQUENCE_NUMBER, {}).get("N", "0")),
            )

        if self.PENDING_CHECKPOINT_SEQUENCE_NUMBER in item:
            lease.pending_checkpoint = ExtendedSequenceNumber(
                sequence_number=item[self.PENDING_CHECKPOINT_SEQUENCE_NUMBER]["S"],
                sub_sequence_number=int(item.get(self.PENDING_CHECKPOINT_SUB_SEQUENCE_NUMBER, {}).get("N", "0")),
            )

        if self.LAST_COUNTER_INCREMENT_NANOS in item:
            lease.last_counter_increment_nanos = int(item[self.LAST_COUNTER_INCREMENT_NANOS]["N"])

        if self.OWNER_SWITCHES_SINCE_CHECKPOINT in item:
            lease.owner_switches_since_checkpoint = int(item[self.OWNER_SWITCHES_SINCE_CHECKPOINT]["N"])

        if self.PARENT_SHARD_IDS in item:
            lease.parent_shard_ids = item[self.PARENT_SHARD_IDS].get("SS")

        if self.CHILD_SHARD_IDS in item:
            lease.child_shard_ids = item[self.CHILD_SHARD_IDS].get("SS")

        if self.HASH_KEY_RANGE_START in item:
            lease.hash_key_range_start = item[self.HASH_KEY_RANGE_START].get("S")

        if self.HASH_KEY_RANGE_END in item:
            lease.hash_key_range_end = item[self.HASH_KEY_RANGE_END].get("S")

        return lease

    def _lease_to_item(self, lease: Lease) -> dict[str, Any]:
        """Convert a Lease object to a DynamoDB item."""
        item: dict[str, Any] = {
            self.LEASE_KEY: {"S": lease.lease_key},
            self.LEASE_COUNTER: {"N": str(lease.lease_counter)},
        }

        if lease.lease_owner:
            item[self.LEASE_OWNER] = {"S": lease.lease_owner}

        if lease.checkpoint:
            item[self.CHECKPOINT_SEQUENCE_NUMBER] = {"S": lease.checkpoint.sequence_number}
            item[self.CHECKPOINT_SUB_SEQUENCE_NUMBER] = {"N": str(lease.checkpoint.sub_sequence_number)}

        if lease.pending_checkpoint:
            item[self.PENDING_CHECKPOINT_SEQUENCE_NUMBER] = {"S": lease.pending_checkpoint.sequence_number}
            item[self.PENDING_CHECKPOINT_SUB_SEQUENCE_NUMBER] = {"N": str(lease.pending_checkpoint.sub_sequence_number)}

        if lease.last_counter_increment_nanos:
            item[self.LAST_COUNTER_INCREMENT_NANOS] = {"N": str(lease.last_counter_increment_nanos)}

        if lease.owner_switches_since_checkpoint is not None:
            item[self.OWNER_SWITCHES_SINCE_CHECKPOINT] = {"N": str(lease.owner_switches_since_checkpoint)}

        if lease.parent_shard_ids and len(lease.parent_shard_ids) > 0:
            item[self.PARENT_SHARD_IDS] = {"SS": lease.parent_shard_ids}

        if lease.child_shard_ids and len(lease.child_shard_ids) > 0:
            item[self.CHILD_SHARD_IDS] = {"SS": lease.child_shard_ids}

        if lease.hash_key_range_start:
            item[self.HASH_KEY_RANGE_START] = {"S": lease.hash_key_range_start}

        if lease.hash_key_range_end:
            item[self.HASH_KEY_RANGE_END] = {"S": lease.hash_key_range_end}

        return item
