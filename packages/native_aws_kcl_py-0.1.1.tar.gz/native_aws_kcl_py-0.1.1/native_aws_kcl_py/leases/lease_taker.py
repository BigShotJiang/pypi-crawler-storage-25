"""Lease taker for acquiring leases."""

import logging
import time
from typing import TYPE_CHECKING

from ..metrics import IMetricsFactory, KCLMetrics, NoOpMetricsFactory
from ..types import Lease

if TYPE_CHECKING:
    from .dynamodb_lease_refresher import DynamoDBLeaseRefresher


class LeaseTaker:
    """Responsible for taking leases from other workers.

    Implements the lease stealing algorithm to balance load across workers.
    """

    _logger = logging.getLogger("kcl.LeaseTaker")

    def __init__(
        self,
        lease_refresher: "DynamoDBLeaseRefresher",
        worker_identifier: str,
        lease_duration_millis: int,
        max_leases_for_worker: int,
        max_leases_to_steal_at_one_time: int,
        metrics_factory: IMetricsFactory | None = None,
    ):
        """Initialize the lease taker.

        Args:
            lease_refresher: The lease refresher implementation
            worker_identifier: This worker's identifier
            lease_duration_millis: Lease duration in milliseconds
            max_leases_for_worker: Maximum leases this worker should hold
            max_leases_to_steal_at_one_time: Maximum leases to steal at once
            metrics_factory: Optional metrics factory
        """
        self._lease_refresher = lease_refresher
        self._worker_identifier = worker_identifier
        self._lease_duration_millis = lease_duration_millis
        self._max_leases_for_worker = max_leases_for_worker
        self._max_leases_to_steal_at_one_time = max_leases_to_steal_at_one_time
        self._metrics_factory = metrics_factory or NoOpMetricsFactory()
        self._all_leases: dict[str, Lease] = {}

    def get_all_leases(self) -> dict[str, Lease]:
        """Get all known leases.

        Returns:
            Dictionary of lease key to lease
        """
        return dict(self._all_leases)

    async def take_leases(self) -> dict[str, Lease]:
        """Take leases from other workers.

        Returns:
            Dictionary of newly taken leases
        """
        scope = self._metrics_factory.create_scope("TakeLeases")
        taken_leases: dict[str, Lease] = {}

        try:
            # List all leases
            start_time = time.time()
            leases = await self._lease_refresher.list_leases()
            list_time = (time.time() - start_time) * 1000
            scope.add_time(KCLMetrics.LIST_LEASES_TIME, list_time)
            scope.add_count(KCLMetrics.LIST_LEASES_SUCCESS, 1)

            # Update our local cache
            self._all_leases.clear()
            for lease in leases:
                self._all_leases[lease.lease_key] = lease

            # Count workers and leases per worker
            worker_to_lease_count: dict[str, int] = {}
            expired_leases: list[Lease] = []
            my_lease_count = 0

            for lease in leases:
                if self._lease_refresher.is_lease_expired(lease, self._lease_duration_millis):
                    expired_leases.append(lease)
                elif lease.lease_owner:
                    worker_to_lease_count[lease.lease_owner] = worker_to_lease_count.get(lease.lease_owner, 0) + 1
                    if lease.lease_owner == self._worker_identifier:
                        my_lease_count += 1

            num_workers = max(1, len(worker_to_lease_count))
            target_leases = len(leases) // num_workers

            # How many leases do we need?
            needed_leases = min(
                self._max_leases_for_worker - my_lease_count,
                target_leases - my_lease_count + 1,  # Allow one extra for load balancing
            )

            scope.add_count(KCLMetrics.TOTAL_LEASES, len(leases))
            scope.add_count(KCLMetrics.EXPIRED_LEASES, len(expired_leases))
            scope.add_count(KCLMetrics.NUM_WORKERS, num_workers)
            scope.add_count(KCLMetrics.NEEDED_LEASES, max(0, needed_leases))

            if needed_leases <= 0:
                self._logger.debug(f"No leases needed (have {my_lease_count}, target {target_leases})")
                return taken_leases

            # First, take expired leases
            leases_to_take: list[Lease] = []
            for lease in expired_leases:
                if len(leases_to_take) >= needed_leases:
                    break
                leases_to_take.append(lease)

            # If we still need more, steal from workers with more than target
            remaining_needed = needed_leases - len(leases_to_take)
            if remaining_needed > 0:
                leases_to_steal = self._compute_leases_to_steal(
                    leases,
                    worker_to_lease_count,
                    target_leases,
                    min(remaining_needed, self._max_leases_to_steal_at_one_time),
                )
                leases_to_take.extend(leases_to_steal)

            scope.add_count(KCLMetrics.LEASES_TO_TAKE, len(leases_to_take))

            # Try to take the leases
            for lease in leases_to_take:
                try:
                    take_start = time.time()
                    success = await self._lease_refresher.take_lease(lease, self._worker_identifier)
                    take_time = (time.time() - take_start) * 1000
                    scope.add_time(KCLMetrics.TAKE_LEASE_TIME, take_time)

                    if success:
                        taken_leases[lease.lease_key] = lease
                        self._logger.info(f"Took lease {lease.lease_key}")
                        scope.add_count(KCLMetrics.TAKE_LEASE_SUCCESS, 1)
                    else:
                        self._logger.debug(f"Failed to take lease {lease.lease_key}")

                except Exception as e:
                    self._logger.error(f"Error taking lease {lease.lease_key}: {e}")

            scope.add_count(KCLMetrics.TAKEN_LEASES, len(taken_leases))

            return taken_leases

        finally:
            scope.end()

    def _compute_leases_to_steal(
        self,
        all_leases: list[Lease],
        worker_to_lease_count: dict[str, int],
        target_leases: int,
        max_to_steal: int,
    ) -> list[Lease]:
        """Compute which leases to steal from other workers.

        Args:
            all_leases: All leases
            worker_to_lease_count: Lease count per worker
            target_leases: Target number of leases per worker
            max_to_steal: Maximum number to steal

        Returns:
            List of leases to try to steal
        """
        leases_to_steal: list[Lease] = []

        # Find workers with more than target+1 leases (allow some slack)
        overloaded_workers: set[str] = set()
        for worker, count in worker_to_lease_count.items():
            if worker != self._worker_identifier and count > target_leases + 1:
                overloaded_workers.add(worker)

        if not overloaded_workers:
            return leases_to_steal

        # Find leases from overloaded workers
        for lease in all_leases:
            if len(leases_to_steal) >= max_to_steal:
                break
            if lease.lease_owner in overloaded_workers:
                leases_to_steal.append(lease)

        return leases_to_steal
