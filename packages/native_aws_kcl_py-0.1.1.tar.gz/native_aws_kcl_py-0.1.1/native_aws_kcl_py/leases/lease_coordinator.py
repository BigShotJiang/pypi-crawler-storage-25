"""Lease coordinator for managing leases across workers."""

import asyncio
import logging
import sys
from collections.abc import Callable
from dataclasses import dataclass

from ..metrics import IMetricsFactory, NoOpMetricsFactory
from ..types import Lease, LeaseManagementConfig
from .dynamodb_lease_refresher import DynamoDBLeaseRefresher
from .lease_renewer import LeaseRenewer
from .lease_taker import LeaseTaker


@dataclass
class LeaseAcquiredEvent:
    """Event emitted when a lease is acquired."""

    type: str = "leaseAcquired"
    lease: Lease | None = None


@dataclass
class LeaseLostEvent:
    """Event emitted when a lease is lost."""

    type: str = "leaseLost"
    lease_key: str = ""


@dataclass
class LeaseRenewedEvent:
    """Event emitted when a lease is renewed."""

    type: str = "leaseRenewed"
    lease: Lease | None = None


@dataclass
class LeaseErrorEvent:
    """Event emitted when a lease error occurs."""

    type: str = "error"
    error: Exception | None = None


LeaseCoordinatorEvent = LeaseAcquiredEvent | LeaseLostEvent | LeaseRenewedEvent | LeaseErrorEvent
LeaseCoordinatorCallback = Callable[[LeaseCoordinatorEvent], None]


class LeaseCoordinator:
    """Coordinates lease management across workers.

    The LeaseCoordinator is responsible for:
    - Taking leases (via LeaseTaker) to acquire shards to process
    - Renewing leases (via LeaseRenewer) to maintain ownership
    - Notifying when leases are acquired or lost

    The persistence layer is pluggable - you can provide a custom LeaseRefresher
    implementation for alternative storage backends (S3, MySQL, Redis, etc.).

    Example:
        ```python
        # Create the coordinator
        coordinator = LeaseCoordinator(
            config=LeaseManagementConfig(
                table_name="my-app-leases",
                worker_identifier="worker-1",
                lease_duration_millis=10000,
            ),
            region_name="eu-west-1",
        )

        # Initialize
        await coordinator.initialize()

        # Register for events
        def on_event(event):
            if event.type == "leaseAcquired":
                print(f"Acquired lease {event.lease.lease_key}")

        coordinator.on_event(on_event)

        # Start coordinating
        await coordinator.start()

        # ... later ...
        await coordinator.stop()
        ```
    """

    _logger = logging.getLogger("kcl.LeaseCoordinator")

    def __init__(
        self,
        config: LeaseManagementConfig,
        region_name: str = "eu-west-1",
        endpoint_url: str | None = None,
        metrics_factory: IMetricsFactory | None = None,
        lease_refresher: DynamoDBLeaseRefresher | None = None,
    ):
        """Initialize the lease coordinator.

        Args:
            config: Lease management configuration
            region_name: AWS region name
            endpoint_url: Optional custom endpoint URL
            metrics_factory: Optional metrics factory
            lease_refresher: Optional custom lease refresher
        """
        self._config = config
        self._metrics_factory = metrics_factory or NoOpMetricsFactory()

        # Create or use provided lease refresher
        self._lease_refresher = lease_refresher or DynamoDBLeaseRefresher(
            config=config,
            region_name=region_name,
            endpoint_url=endpoint_url,
        )

        # Create the taker and renewer
        self._lease_taker = LeaseTaker(
            lease_refresher=self._lease_refresher,
            worker_identifier=config.worker_identifier,
            lease_duration_millis=config.lease_duration_millis,
            max_leases_for_worker=config.max_leases_for_worker or sys.maxsize,
            max_leases_to_steal_at_one_time=config.max_leases_to_steal_at_one_time,
            metrics_factory=self._metrics_factory,
        )

        self._lease_renewer = LeaseRenewer(
            lease_refresher=self._lease_refresher,
            worker_identifier=config.worker_identifier,
            lease_duration_millis=config.lease_duration_millis,
            metrics_factory=self._metrics_factory,
        )

        # Calculate intervals based on lease duration
        # Taker runs at 2 * leaseDuration + epsilon
        self._taker_interval_millis = 2 * config.lease_duration_millis + config.epsilon_millis
        # Renewer runs at leaseDuration / 3 + epsilon
        self._renewer_interval_millis = config.lease_duration_millis // 3 + config.epsilon_millis

        self._taker_task: asyncio.Task | None = None
        self._renewer_task: asyncio.Task | None = None
        self._is_running = False
        self._callbacks: list[LeaseCoordinatorCallback] = []

    async def initialize(self) -> None:
        """Initialize the lease table and coordinator."""
        # Create the lease table if it doesn't exist
        created = await self._lease_refresher.create_lease_table_if_not_exists()
        if created:
            self._logger.info(f"Created lease table {self._config.table_name}")

        # Wait for the table to be active
        await self._lease_refresher.wait_for_table_active()
        self._logger.info(f"Lease table {self._config.table_name} is ready")

    async def start(self) -> None:
        """Start the lease coordinator."""
        if self._is_running:
            self._logger.warning("LeaseCoordinator is already running")
            return

        self._is_running = True

        # Run the taker immediately, then on interval
        await self._run_taker()
        self._taker_task = asyncio.create_task(self._taker_loop())

        # Run the renewer on interval
        self._renewer_task = asyncio.create_task(self._renewer_loop())

        self._logger.info(f"LeaseCoordinator started for worker {self._config.worker_identifier}")

    async def stop(self) -> None:
        """Stop the lease coordinator."""
        if not self._is_running:
            return

        self._is_running = False

        # Cancel tasks
        if self._taker_task:
            self._taker_task.cancel()
            try:
                await self._taker_task
            except asyncio.CancelledError:
                pass
            self._taker_task = None

        if self._renewer_task:
            self._renewer_task.cancel()
            try:
                await self._renewer_task
            except asyncio.CancelledError:
                pass
            self._renewer_task = None

        # Get owned shards before releasing for logging
        owned_leases = self._lease_renewer.get_owned_leases()
        shard_ids = list(owned_leases.keys())

        # Release all leases
        await self._release_all_leases()

        if shard_ids:
            self._logger.info(
                f"LeaseCoordinator stopped for worker {self._config.worker_identifier}, "
                f"released {len(shard_ids)} shard(s): [{', '.join(shard_ids)}]"
            )
        else:
            self._logger.info(f"LeaseCoordinator stopped for worker {self._config.worker_identifier} (no shards held)")

    def on_event(self, callback: LeaseCoordinatorCallback) -> None:
        """Register a callback for lease events.

        Args:
            callback: The callback function
        """
        self._callbacks.append(callback)

    def off_event(self, callback: LeaseCoordinatorCallback) -> None:
        """Remove a callback.

        Args:
            callback: The callback function to remove
        """
        if callback in self._callbacks:
            self._callbacks.remove(callback)

    def get_owned_leases(self) -> dict[str, Lease]:
        """Get all leases currently owned by this worker.

        Returns:
            Dictionary of lease key to lease
        """
        return self._lease_renewer.get_owned_leases()

    def get_lease(self, lease_key: str) -> Lease | None:
        """Get a specific lease.

        Args:
            lease_key: The lease key

        Returns:
            The lease if owned, None otherwise
        """
        return self._lease_renewer.get_lease(lease_key)

    def owns_lease(self, lease_key: str) -> bool:
        """Check if we own a specific lease.

        Args:
            lease_key: The lease key

        Returns:
            True if this worker owns the lease
        """
        return self._lease_renewer.owns_lease(lease_key)

    async def checkpoint(
        self,
        lease_key: str,
        sequence_number: str,
        sub_sequence_number: int,
    ) -> bool:
        """Update lease with checkpoint.

        Args:
            lease_key: The lease key
            sequence_number: The sequence number to checkpoint
            sub_sequence_number: The sub-sequence number

        Returns:
            True if successful
        """
        return await self._lease_renewer.update_lease_with_checkpoint(lease_key, sequence_number, sub_sequence_number)

    async def prepare_checkpoint(
        self,
        lease_key: str,
        sequence_number: str,
        sub_sequence_number: int,
    ) -> bool:
        """Update lease with pending checkpoint.

        Args:
            lease_key: The lease key
            sequence_number: The sequence number to prepare
            sub_sequence_number: The sub-sequence number

        Returns:
            True if successful
        """
        return await self._lease_renewer.update_lease_with_pending_checkpoint(
            lease_key, sequence_number, sub_sequence_number
        )

    def drop_lease(self, lease_key: str) -> None:
        """Drop a lease (stop processing but don't release immediately).

        Args:
            lease_key: The lease key to drop
        """
        self._lease_renewer.remove_lease(lease_key)

    async def create_lease(self, lease: Lease) -> bool:
        """Create a new lease for a shard.

        Args:
            lease: The lease to create

        Returns:
            True if created successfully
        """
        return await self._lease_refresher.create_lease(lease)

    def get_all_leases(self) -> dict[str, Lease]:
        """Get all known leases (for shard sync).

        Returns:
            Dictionary of all leases
        """
        return self._lease_taker.get_all_leases()

    async def list_leases(self) -> list[Lease]:
        """List all leases from DynamoDB.

        Returns:
            List of all leases
        """
        return await self._lease_refresher.list_leases()

    async def delete_lease(self, lease: Lease) -> bool:
        """Delete a lease (for shard completion cleanup).

        Args:
            lease: The lease to delete

        Returns:
            True if deleted successfully
        """
        # Remove from renewer if we own it
        self._lease_renewer.remove_lease(lease.lease_key)
        return await self._lease_refresher.delete_lease(lease)

    def get_lease_refresher(self) -> DynamoDBLeaseRefresher:
        """Get the lease refresher (for advanced operations).

        Returns:
            The lease refresher
        """
        return self._lease_refresher

    async def _taker_loop(self) -> None:
        """Background task for taking leases."""
        while self._is_running:
            await asyncio.sleep(self._taker_interval_millis / 1000)
            if not self._is_running:
                break
            await self._run_taker()

    async def _renewer_loop(self) -> None:
        """Background task for renewing leases."""
        while self._is_running:
            await asyncio.sleep(self._renewer_interval_millis / 1000)
            if not self._is_running:
                break
            await self._run_renewer()

    async def _run_taker(self) -> None:
        """Run the lease taker."""
        if not self._is_running:
            return

        try:
            taken_leases = await self._lease_taker.take_leases()

            # Add taken leases to the renewer and emit events
            for lease in taken_leases.values():
                self._lease_renewer.add_lease(lease)
                self._emit(LeaseAcquiredEvent(lease=lease))

        except Exception as e:
            self._logger.error(f"Error in lease taker: {e}")
            self._emit(LeaseErrorEvent(error=e))

    async def _run_renewer(self) -> None:
        """Run the lease renewer."""
        if not self._is_running:
            return

        try:
            lost_leases = await self._lease_renewer.renew_leases()

            # Emit events for lost leases
            for lease_key in lost_leases:
                self._emit(LeaseLostEvent(lease_key=lease_key))

        except Exception as e:
            self._logger.error(f"Error in lease renewer: {e}")
            self._emit(LeaseErrorEvent(error=e))

    async def _release_all_leases(self) -> None:
        """Release all leases held by this worker."""
        owned_leases = self._lease_renewer.get_owned_leases()

        for lease in owned_leases.values():
            try:
                await self._lease_refresher.evict_lease(lease)
            except Exception as e:
                self._logger.warning(f"Failed to release lease {lease.lease_key}: {e}")

        self._lease_renewer.clear()

    def _emit(self, event: LeaseCoordinatorEvent) -> None:
        """Emit an event to all registered callbacks.

        Args:
            event: The event to emit
        """
        for callback in self._callbacks:
            try:
                callback(event)
            except Exception as e:
                self._logger.error(f"Error in lease coordinator callback: {e}")
