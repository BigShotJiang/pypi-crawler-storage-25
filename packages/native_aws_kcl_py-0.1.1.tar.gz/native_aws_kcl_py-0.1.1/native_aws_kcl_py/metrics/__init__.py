"""Metrics interfaces and implementations for the Kinesis Consumer Library.

The metrics system is pluggable - you can use the default no-op implementation,
CloudWatch, or provide a custom implementation for other backends.

Example:
    >>> # Disable metrics (default)
    >>> factory = create_metrics_factory()

    >>> # Enable CloudWatch metrics
    >>> factory = create_metrics_factory(
    ...     level="SUMMARY",
    ...     namespace="KCL/MyApplication",
    ...     region="us-east-1",
    ... )
    >>> await factory.start()  # Start the background publisher

    >>> # Use a custom implementation
    >>> factory = create_metrics_factory(custom_factory=MyCustomFactory())
"""

from .cloudwatch import (
    CloudWatchMetricsFactory,
    CloudWatchMetricsFactoryConfig,
    CloudWatchMetricsPublisher,
    CloudWatchMetricsPublisherConfig,
    CloudWatchMetricsScope,
)
from .factory import (
    DEFAULT_METRICS_FACTORY,
    CreateMetricsFactoryConfig,
    create_metrics_factory,
    parse_metrics_level,
)
from .interfaces import (
    IMetricsFactory,
    IMetricsPublisher,
    IMetricsScope,
    KCLDimensions,
    KCLMetrics,
    MetricDatum,
    MetricDimension,
    MetricsLevel,
    MetricUnit,
)
from .noop import NoOpMetricsFactory, NoOpMetricsScope

__all__ = [
    # Interfaces
    "MetricsLevel",
    "MetricUnit",
    "MetricDimension",
    "MetricDatum",
    "IMetricsScope",
    "IMetricsFactory",
    "IMetricsPublisher",
    "KCLMetrics",
    "KCLDimensions",
    # No-op implementation
    "NoOpMetricsFactory",
    "NoOpMetricsScope",
    # CloudWatch implementation
    "CloudWatchMetricsFactory",
    "CloudWatchMetricsFactoryConfig",
    "CloudWatchMetricsPublisher",
    "CloudWatchMetricsPublisherConfig",
    "CloudWatchMetricsScope",
    # Factory
    "create_metrics_factory",
    "CreateMetricsFactoryConfig",
    "parse_metrics_level",
    "DEFAULT_METRICS_FACTORY",
]
