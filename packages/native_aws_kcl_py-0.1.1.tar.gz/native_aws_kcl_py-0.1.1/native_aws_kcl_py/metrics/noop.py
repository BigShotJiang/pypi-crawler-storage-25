"""No-op metrics implementation.

This provides a metrics implementation that does nothing, used when metrics are disabled.
"""

from collections.abc import Awaitable, Callable
from typing import TypeVar

from .interfaces import (
    IMetricsFactory,
    IMetricsScope,
    MetricDimension,
    MetricsLevel,
    MetricUnit,
)

T = TypeVar("T")


class NoOpMetricsScope(IMetricsScope):
    """A metrics scope that does nothing.

    Used when metrics are disabled (level == NONE).
    """

    def add_dimension(self, name: str, value: str) -> "NoOpMetricsScope":
        """No-op: Add a dimension."""
        return self

    def add_count(self, name: str, value: float, unit: MetricUnit = MetricUnit.COUNT) -> None:
        """No-op: Add a count metric."""
        pass

    def add_time(self, name: str, value: float, unit: MetricUnit = MetricUnit.MILLISECONDS) -> None:
        """No-op: Add a time metric."""
        pass

    def add_data(self, name: str, value: float, unit: MetricUnit = MetricUnit.BYTES) -> None:
        """No-op: Add a data metric."""
        pass

    async def timer(self, name: str, operation: Callable[[], Awaitable[T]]) -> T:
        """Execute the operation without timing."""
        return await operation()

    def create_scope(self) -> "NoOpMetricsScope":
        """Return another no-op scope."""
        return NoOpMetricsScope()

    def end(self) -> None:
        """No-op: End the scope."""
        pass

    def get_dimensions(self) -> list[MetricDimension]:
        """Return empty dimensions."""
        return []


class NoOpMetricsFactory(IMetricsFactory):
    """A metrics factory that creates no-op scopes.

    Used when metrics are disabled.
    """

    def __init__(self, level: MetricsLevel = MetricsLevel.NONE):
        self._level = level

    def create_scope(self, operation: str) -> NoOpMetricsScope:
        """Create a no-op metrics scope."""
        return NoOpMetricsScope()

    def get_metrics_level(self) -> MetricsLevel:
        """Get the metrics level (always NONE for no-op)."""
        return self._level

    def is_enabled(self) -> bool:
        """Check if metrics are enabled (always False for no-op)."""
        return self._level != MetricsLevel.NONE

    def is_detailed_metrics_enabled(self) -> bool:
        """Check if detailed metrics are enabled (always False for no-op)."""
        return self._level == MetricsLevel.DETAILED

    async def shutdown(self) -> None:
        """No-op: Shutdown."""
        pass
