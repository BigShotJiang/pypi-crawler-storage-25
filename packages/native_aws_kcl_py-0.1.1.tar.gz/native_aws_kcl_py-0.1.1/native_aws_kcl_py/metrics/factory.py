"""Metrics factory utilities.

This module provides a factory function to create the appropriate
metrics factory based on configuration. It supports:

- No-op implementation (DEFAULT - zero overhead when metrics are disabled)
- CloudWatch (when explicitly enabled via level=SUMMARY or level=DETAILED)
- Custom implementations via dependency injection

By default, metrics are DISABLED and the NoOpMetricsFactory is used,
which has zero overhead. To enable CloudWatch metrics, you must explicitly
set the level to SUMMARY or DETAILED and provide a namespace.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from .interfaces import IMetricsFactory, MetricDimension, MetricsLevel
from .noop import NoOpMetricsFactory

if TYPE_CHECKING:
    from types_aiobotocore_cloudwatch import CloudWatchClient

logger = logging.getLogger(__name__)


def parse_metrics_level(level: str | MetricsLevel | None) -> MetricsLevel:
    """Parse a metrics level string into a MetricsLevel enum.

    Supports various aliases:
    - NONE: 'NONE', 'DISABLED', 'OFF'
    - SUMMARY: 'SUMMARY', 'BASIC'
    - DETAILED: 'DETAILED', 'FULL', 'ALL'

    Args:
        level: The level string, MetricsLevel enum, or None

    Returns:
        The corresponding MetricsLevel enum value
    """
    if level is None:
        return MetricsLevel.NONE

    # If already a MetricsLevel, return as-is
    if isinstance(level, MetricsLevel):
        return level

    if not isinstance(level, str):
        return MetricsLevel.NONE

    # Strip whitespace and convert to upper case
    level_upper = level.strip().upper()

    # NONE variants
    if level_upper in ("NONE", "DISABLED", "OFF", ""):
        return MetricsLevel.NONE

    # SUMMARY variants
    if level_upper in ("SUMMARY", "BASIC"):
        return MetricsLevel.SUMMARY

    # DETAILED variants
    if level_upper in ("DETAILED", "FULL", "ALL"):
        return MetricsLevel.DETAILED

    # Unknown - default to NONE with warning
    logger.warning(f'Unknown metrics level "{level}", defaulting to NONE')
    return MetricsLevel.NONE


@dataclass
class CreateMetricsFactoryConfig:
    """Configuration for creating a metrics factory.

    Example:
        >>> # Disable metrics (default)
        >>> config = CreateMetricsFactoryConfig(level=MetricsLevel.NONE)

        >>> # Enable CloudWatch metrics with summary level
        >>> config = CreateMetricsFactoryConfig(
        ...     level=MetricsLevel.SUMMARY,
        ...     namespace="KCL/MyApplication",
        ...     region="us-east-1",
        ... )

        >>> # Enable detailed CloudWatch metrics
        >>> config = CreateMetricsFactoryConfig(
        ...     level=MetricsLevel.DETAILED,
        ...     namespace="KCL/MyApplication",
        ...     region="us-east-1",
        ...     default_dimensions=[
        ...         MetricDimension(name="Environment", value="production"),
        ...     ],
        ... )
    """

    level: MetricsLevel | str = MetricsLevel.NONE
    """The metrics level (NONE, SUMMARY, DETAILED). Default: NONE"""

    namespace: str | None = None
    """The namespace for metrics (e.g., 'KCL/MyApplication').
    Required if level is not NONE."""

    region: str | None = None
    """AWS region for CloudWatch (used if cloudwatch_client is not provided)"""

    endpoint_url: str | None = None
    """Custom CloudWatch endpoint (for local testing with LocalStack, etc.)"""

    cloudwatch_client: CloudWatchClient | None = None
    """CloudWatch client (optional - will be created if not provided)"""

    buffer_time_seconds: float = 10.0
    """Buffer time before flushing metrics (in seconds). Default: 10 seconds"""

    max_queue_size: int = 10000
    """Maximum number of metrics to buffer before flushing. Default: 10000"""

    default_dimensions: list[MetricDimension] = field(default_factory=list)
    """Default dimensions to add to all metrics"""

    custom_factory: IMetricsFactory | None = None
    """Custom metrics factory implementation.
    If provided, this factory will be used instead of creating one.
    This allows plugging in custom metrics backends (Prometheus, Datadog, etc.)"""


def create_metrics_factory(
    config: CreateMetricsFactoryConfig | None = None,
    *,
    # Legacy kwargs for backwards compatibility
    level: MetricsLevel | str | None = None,
    namespace: str | None = None,
    region: str | None = None,
    endpoint_url: str | None = None,
    cloudwatch_client: CloudWatchClient | None = None,
    buffer_time_seconds: float | None = None,
    max_queue_size: int | None = None,
    default_dimensions: list[MetricDimension] | None = None,
    custom_factory: IMetricsFactory | None = None,
) -> IMetricsFactory:
    """Create a metrics factory based on configuration.

    This function supports two calling conventions:
    1. Pass a CreateMetricsFactoryConfig object
    2. Pass individual keyword arguments (for backwards compatibility)

    Args:
        config: Configuration object (preferred)
        level: The metrics level (NONE, SUMMARY, DETAILED)
        namespace: The CloudWatch namespace (required if level != NONE)
        region: AWS region for CloudWatch
        endpoint_url: Custom CloudWatch endpoint URL
        cloudwatch_client: Pre-configured CloudWatch client
        buffer_time_seconds: Buffer time before flushing (default: 10s)
        max_queue_size: Max metrics to buffer (default: 10000)
        default_dimensions: Default dimensions for all metrics
        custom_factory: Custom IMetricsFactory implementation to use

    Returns:
        An IMetricsFactory implementation

    Example:
        >>> # Disable metrics (default)
        >>> factory = create_metrics_factory()

        >>> # Enable CloudWatch metrics with summary level
        >>> factory = create_metrics_factory(
        ...     level="SUMMARY",
        ...     namespace="KCL/MyApplication",
        ...     region="us-east-1",
        ... )

        >>> # Use config object
        >>> config = CreateMetricsFactoryConfig(
        ...     level=MetricsLevel.DETAILED,
        ...     namespace="KCL/MyApplication",
        ... )
        >>> factory = create_metrics_factory(config)

        >>> # Use a custom metrics implementation
        >>> factory = create_metrics_factory(
        ...     custom_factory=MyPrometheusMetricsFactory(),
        ... )
    """
    # Build config from kwargs if not provided
    if config is None:
        config = CreateMetricsFactoryConfig(
            level=level if level is not None else MetricsLevel.NONE,
            namespace=namespace,
            region=region,
            endpoint_url=endpoint_url,
            cloudwatch_client=cloudwatch_client,
            buffer_time_seconds=buffer_time_seconds if buffer_time_seconds is not None else 10.0,
            max_queue_size=max_queue_size if max_queue_size is not None else 10000,
            default_dimensions=default_dimensions if default_dimensions is not None else [],
            custom_factory=custom_factory,
        )

    # If a custom factory is provided, use it
    if config.custom_factory is not None:
        logger.info(f"Using custom metrics factory: {config.custom_factory.__class__.__name__}")
        return config.custom_factory

    # Parse the metrics level
    parsed_level = parse_metrics_level(config.level)

    # If metrics are disabled, return a no-op factory
    if parsed_level == MetricsLevel.NONE:
        logger.info("Metrics disabled (level: NONE)")
        return NoOpMetricsFactory(parsed_level)

    # Validate configuration for enabled metrics
    effective_namespace = config.namespace
    if not effective_namespace:
        logger.warning('Metrics enabled but no namespace provided, using default: "KCL"')
        effective_namespace = "KCL"

    # Create CloudWatch metrics factory
    from .cloudwatch import CloudWatchMetricsFactory, CloudWatchMetricsFactoryConfig

    cloudwatch_config = CloudWatchMetricsFactoryConfig(
        level=parsed_level,
        namespace=effective_namespace,
        region=config.region,
        endpoint_url=config.endpoint_url,
        buffer_time_seconds=config.buffer_time_seconds,
        max_queue_size=config.max_queue_size,
        default_dimensions=list(config.default_dimensions),
    )

    logger.info(f"Creating CloudWatch metrics factory with level: {parsed_level}, " f"namespace: {effective_namespace}")
    return CloudWatchMetricsFactory(
        config=cloudwatch_config,
        cloudwatch_client=config.cloudwatch_client,
    )


# Default metrics factory (no-op)
DEFAULT_METRICS_FACTORY = NoOpMetricsFactory()
