"""Metrics interfaces for the Kinesis Consumer Library.

These interfaces allow pluggable metrics implementations, enabling
easy switching between different monitoring solutions (CloudWatch,
Prometheus, Datadog, etc.).

Based on AWS KCL metrics interfaces.
"""

from abc import ABC, abstractmethod
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import TypeVar

T = TypeVar("T")


class MetricsLevel(str, Enum):
    """Metrics reporting level.

    Controls how much detail is reported to the metrics system.
    """

    NONE = "NONE"
    """No metrics are reported. This is the DEFAULT level if no configuration is provided."""

    SUMMARY = "SUMMARY"
    """Summary metrics only - aggregated metrics across all operations.
    Includes: RecordsProcessed, RecordsBehindLatest, MillisBehindLatest"""

    DETAILED = "DETAILED"
    """Detailed metrics - per-shard and per-operation metrics.
    Includes all SUMMARY metrics plus per-shard processing metrics,
    lease coordination metrics, checkpoint metrics, and individual operation timings."""


class MetricUnit(str, Enum):
    """Standard metric units."""

    COUNT = "Count"
    MILLISECONDS = "Milliseconds"
    SECONDS = "Seconds"
    BYTES = "Bytes"
    KILOBYTES = "Kilobytes"
    MEGABYTES = "Megabytes"
    PERCENT = "Percent"
    NONE = "None"


@dataclass
class MetricDimension:
    """A dimension for categorizing metrics."""

    name: str
    """Dimension name"""

    value: str
    """Dimension value"""


@dataclass
class MetricDatum:
    """A single metric data point."""

    metric_name: str
    """The name of the metric"""

    value: float
    """The value of the metric"""

    unit: MetricUnit
    """The unit of the metric"""

    timestamp: datetime | None = None
    """The timestamp of the metric (defaults to now)"""

    dimensions: list[MetricDimension] | None = None
    """Additional dimensions for the metric"""


class IMetricsScope(ABC):
    """A scope for collecting related metrics.

    Scopes provide a context for metrics collection, including
    common dimensions (like shard ID) that apply to all metrics
    within the scope.

    Scopes are hierarchical - child scopes inherit dimensions from parents.
    """

    @abstractmethod
    def add_dimension(self, name: str, value: str) -> "IMetricsScope":
        """Add a dimension to all metrics in this scope.

        Args:
            name: The dimension name
            value: The dimension value

        Returns:
            This scope for chaining
        """
        pass

    @abstractmethod
    def add_count(self, name: str, value: float, unit: MetricUnit = MetricUnit.COUNT) -> None:
        """Add a count metric.

        Args:
            name: The metric name
            value: The count value
            unit: The unit (defaults to COUNT)
        """
        pass

    @abstractmethod
    def add_time(self, name: str, value: float, unit: MetricUnit = MetricUnit.MILLISECONDS) -> None:
        """Add a time metric.

        Args:
            name: The metric name
            value: The time value
            unit: The unit (defaults to MILLISECONDS)
        """
        pass

    @abstractmethod
    def add_data(self, name: str, value: float, unit: MetricUnit = MetricUnit.BYTES) -> None:
        """Add a data metric (size in bytes).

        Args:
            name: The metric name
            value: The size in bytes
            unit: The unit (defaults to BYTES)
        """
        pass

    @abstractmethod
    async def timer(self, name: str, operation: Callable[[], Awaitable[T]]) -> T:
        """Record a timing metric by measuring the duration of an operation.

        Args:
            name: The metric name
            operation: The async operation to time

        Returns:
            The result of the operation
        """
        pass

    @abstractmethod
    def create_scope(self) -> "IMetricsScope":
        """Create a child scope with additional dimensions.

        Returns:
            A new child scope
        """
        pass

    @abstractmethod
    def end(self) -> None:
        """End this scope and flush any buffered metrics."""
        pass

    @abstractmethod
    def get_dimensions(self) -> list[MetricDimension]:
        """Get the current dimensions for this scope."""
        pass


class IMetricsFactory(ABC):
    """Factory for creating metrics scopes.

    This is the main entry point for the metrics system. Implementations
    can target different monitoring backends (CloudWatch, Prometheus, etc.).
    """

    @abstractmethod
    def create_scope(self, operation: str) -> IMetricsScope:
        """Create a metrics scope for collecting metrics.

        Args:
            operation: The operation name (used as a dimension)

        Returns:
            A new metrics scope
        """
        pass

    @abstractmethod
    def get_metrics_level(self) -> MetricsLevel:
        """Get the current metrics level."""
        pass

    @abstractmethod
    def is_enabled(self) -> bool:
        """Check if metrics are enabled (level != NONE)."""
        pass

    @abstractmethod
    def is_detailed_metrics_enabled(self) -> bool:
        """Check if detailed metrics are enabled (level == DETAILED)."""
        pass

    @abstractmethod
    async def shutdown(self) -> None:
        """Shutdown the metrics factory and flush any pending metrics."""
        pass


class IMetricsPublisher(ABC):
    """A metrics publisher that sends metrics to a backend.

    This interface allows different backends to be plugged in.
    """

    @abstractmethod
    async def publish(self, metrics: list[MetricDatum]) -> None:
        """Publish a batch of metrics.

        Args:
            metrics: The metrics to publish
        """
        pass

    @abstractmethod
    async def shutdown(self) -> None:
        """Shutdown the publisher and flush any pending metrics."""
        pass


# Standard KCL metric names
class KCLMetrics:
    """Standard KCL metric names.

    Based on AWS KCL metrics.
    See: https://docs.aws.amazon.com/streams/latest/dev/monitoring-with-kcl.html
    """

    # ProcessTask Operation Metrics (per-shard)
    RECORDS_PROCESSED = "RecordsProcessed"
    RECORDS_FETCHED = "RecordsFetched"
    DATA_BYTES_PROCESSED = "DataBytesProcessed"
    BYTES_PROCESSED = "BytesProcessed"  # Alias
    MILLIS_BEHIND_LATEST = "MillisBehindLatest"
    ITERATOR_AGE_MILLIS = "IteratorAgeMilliseconds"
    EXPIRED_ITERATOR = "ExpiredIterator"
    PROCESS_TASK_SUCCESS = "ProcessTask.Success"
    PROCESS_TASK_TIME = "ProcessTask.Time"

    # Record Processor Metrics
    RECORD_PROCESSOR_PROCESS_RECORDS_TIME = "RecordProcessor.processRecords.Time"
    RECORD_PROCESSOR_INITIALIZE_TIME = "RecordProcessor.initialize.Time"
    RECORD_PROCESSOR_SHUTDOWN_TIME = "RecordProcessor.shutdown.Time"
    RECORD_PROCESSOR_SHARD_ENDED_TIME = "RecordProcessor.shardEnded.Time"
    RECORD_PROCESSOR_LEASE_LOST_TIME = "RecordProcessor.leaseLost.Time"

    # KinesisDataFetcher Metrics (GetRecords operation)
    GET_RECORDS_SUCCESS = "KinesisDataFetcher.getRecords.Success"
    GET_RECORDS_TIME = "KinesisDataFetcher.getRecords.Time"
    GET_RECORDS_EMPTY = "KinesisDataFetcher.getRecords.Empty"
    GET_RECORDS_FAILURE = "KinesisDataFetcher.getRecords.Failure"
    GET_RECORDS_THROTTLED = "KinesisDataFetcher.getRecords.Throttled"

    # Enhanced Fan-Out Metrics
    SUBSCRIBE_TO_SHARD_TIME = "SubscribeToShard.Time"
    SUBSCRIBE_TO_SHARD_SUCCESS = "SubscribeToShard.Success"
    SUBSCRIBE_TO_SHARD_FAILURE = "SubscribeToShard.Failure"
    SUBSCRIPTION_TIMEOUT = "SubscriptionTimeout"

    # RenewAllLeases Operation Metrics (per-worker)
    RENEW_LEASE_SUCCESS = "RenewLease.Success"
    RENEW_LEASE_TIME = "RenewLease.Time"
    RENEW_LEASE_FAILURE = "RenewLease.Failure"
    CURRENT_LEASES = "CurrentLeases"
    LOST_LEASES = "LostLeases"
    RENEW_ALL_LEASES_SUCCESS = "RenewAllLeases.Success"
    RENEW_ALL_LEASES_TIME = "RenewAllLeases.Time"

    # TakeLeases Operation Metrics (per-worker)
    LIST_LEASES_SUCCESS = "ListLeases.Success"
    LIST_LEASES_TIME = "ListLeases.Time"
    TAKE_LEASE_SUCCESS = "TakeLease.Success"
    TAKE_LEASE_TIME = "TakeLease.Time"
    NUM_WORKERS = "NumWorkers"
    NEEDED_LEASES = "NeededLeases"
    LEASES_TO_TAKE = "LeasesToTake"
    TAKEN_LEASES = "TakenLeases"
    TOTAL_LEASES = "TotalLeases"
    EXPIRED_LEASES = "ExpiredLeases"
    TAKE_LEASES_SUCCESS = "TakeLeases.Success"
    TAKE_LEASES_TIME = "TakeLeases.Time"

    # Checkpoint/UpdateLease Metrics
    UPDATE_LEASE_SUCCESS = "UpdateLease.Success"
    UPDATE_LEASE_TIME = "UpdateLease.Time"
    UPDATE_LEASE_FAILURE = "UpdateLease.Failure"
    CHECKPOINT_TIME = "Checkpoint.Time"
    CHECKPOINT_SUCCESS = "Checkpoint.Success"
    CHECKPOINT_FAILURE = "Checkpoint.Failure"

    # Scheduler/Worker Level Metrics
    CURRENT_SHARDS = "CurrentShards"
    SHARDS_COMPLETED = "ShardsCompleted"
    ACTIVE_WORKERS = "ActiveWorkers"
    LEASES_HELD = "LeasesHeld"
    LEASES_STOLEN = "LeasesStolen"
    LEASES_LOST = "LeasesLost"
    LEASES_TAKEN = "LeasesTaken"
    LEASE_RENEWAL_TIME = "LeaseRenewal.Time"
    LEASE_RENEWAL_SUCCESS = "LeaseRenewal.Success"
    LEASE_RENEWAL_FAILURE = "LeaseRenewal.Failure"

    # Error Metrics
    EXCEPTIONS = "Exceptions"
    NON_RETRYABLE_EXCEPTIONS = "NonRetryableExceptions"
    RETRYABLE_EXCEPTIONS = "RetryableExceptions"

    # Generic
    SUCCESS = "Success"
    TIME = "Time"


class KCLDimensions:
    """Standard KCL dimension names."""

    OPERATION = "Operation"
    SHARD_ID = "ShardId"
    STREAM_NAME = "StreamName"
    WORKER_ID = "WorkerId"
    APPLICATION_NAME = "ApplicationName"
    EXCEPTION_TYPE = "ExceptionType"
