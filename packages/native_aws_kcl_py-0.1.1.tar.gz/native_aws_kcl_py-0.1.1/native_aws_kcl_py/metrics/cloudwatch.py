"""CloudWatch metrics implementation.

This implementation publishes metrics to AWS CloudWatch.
It buffers metrics and publishes them in batches for efficiency.

Based on AWS KCL v2.7.2 CloudWatch metrics implementation.
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, TypeVar

from .interfaces import (
    IMetricsFactory,
    IMetricsPublisher,
    IMetricsScope,
    MetricDatum,
    MetricDimension,
    MetricsLevel,
    MetricUnit,
)

if TYPE_CHECKING:
    from types_aiobotocore_cloudwatch import CloudWatchClient

T = TypeVar("T")

logger = logging.getLogger(__name__)

# Default configuration values
DEFAULT_BUFFER_TIME_SECONDS = 10.0
DEFAULT_MAX_QUEUE_SIZE = 10000
MAX_METRICS_PER_PUT = 1000  # CloudWatch limit is 1000 metrics per PutMetricData call


def _to_cloudwatch_unit(unit: MetricUnit) -> str:
    """Map our metric units to CloudWatch StandardUnit strings.

    Args:
        unit: The MetricUnit enum value

    Returns:
        The CloudWatch StandardUnit string
    """
    mapping = {
        MetricUnit.COUNT: "Count",
        MetricUnit.MILLISECONDS: "Milliseconds",
        MetricUnit.SECONDS: "Seconds",
        MetricUnit.BYTES: "Bytes",
        MetricUnit.KILOBYTES: "Kilobytes",
        MetricUnit.MEGABYTES: "Megabytes",
        MetricUnit.PERCENT: "Percent",
        MetricUnit.NONE: "None",
    }
    return mapping.get(unit, "None")


@dataclass
class CloudWatchMetricsPublisherConfig:
    """Configuration for CloudWatchMetricsPublisher."""

    namespace: str
    """CloudWatch namespace for all metrics (e.g., 'KCL/MyApplication')"""

    region: str | None = None
    """AWS region for CloudWatch (used if cloudwatch_client is not provided)"""

    endpoint_url: str | None = None
    """Custom CloudWatch endpoint URL (for local testing with LocalStack, etc.)"""

    buffer_time_seconds: float = DEFAULT_BUFFER_TIME_SECONDS
    """Time in seconds to buffer metrics before flushing (default: 10 seconds)"""

    max_queue_size: int = DEFAULT_MAX_QUEUE_SIZE
    """Maximum number of metrics to buffer before forcing a flush (default: 10000)"""


class CloudWatchMetricsPublisher(IMetricsPublisher):
    """CloudWatch metrics publisher.

    Buffers metrics and publishes them in batches to CloudWatch.
    This is an async implementation that uses aiobotocore for non-blocking calls.
    """

    def __init__(
        self,
        config: CloudWatchMetricsPublisherConfig,
        cloudwatch_client: CloudWatchClient | None = None,
    ) -> None:
        """Initialize the CloudWatch metrics publisher.

        Args:
            config: Publisher configuration
            cloudwatch_client: Optional pre-configured CloudWatch client.
                If not provided, one will be created when needed.
        """
        from typing import Any

        self._config = config
        self._external_client = cloudwatch_client
        # Use Any for the owned client since aiobotocore returns AioBaseClient
        self._owned_client: Any = None
        self._client_context: Any = None
        self._metrics_buffer: list[MetricDatum] = []
        self._buffer_lock = asyncio.Lock()
        self._flush_task: asyncio.Task | None = None
        self._is_shutting_down = False
        self._is_started = False

    async def _get_client(self) -> CloudWatchClient:
        """Get or create the CloudWatch client.

        Returns:
            The CloudWatch client to use
        """
        if self._external_client is not None:
            return self._external_client

        if self._owned_client is None:
            # Lazy import to avoid requiring aiobotocore when not using CloudWatch
            from aiobotocore.session import get_session

            session = get_session()
            # Create the client context manager and enter it
            client_context = session.create_client(
                "cloudwatch",
                region_name=self._config.region,
                endpoint_url=self._config.endpoint_url,
            )
            self._owned_client = await client_context.__aenter__()
            # Store the context manager so we can exit it later
            self._client_context = client_context

        return self._owned_client  # type: ignore[return-value]

    async def start(self) -> None:
        """Start the periodic flush task."""
        if self._is_started:
            return

        self._is_started = True
        self._flush_task = asyncio.create_task(self._periodic_flush())
        logger.info(f"CloudWatch metrics publisher started for namespace: {self._config.namespace}")

    async def _periodic_flush(self) -> None:
        """Periodically flush metrics to CloudWatch."""
        while not self._is_shutting_down:
            try:
                await asyncio.sleep(self._config.buffer_time_seconds)
                await self._flush()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in periodic flush: {e}")

    async def publish(self, metrics: list[MetricDatum]) -> None:
        """Add metrics to the buffer for publishing.

        Args:
            metrics: The metrics to publish
        """
        if self._is_shutting_down:
            logger.warning("Metrics publisher is shutting down, ignoring new metrics")
            return

        async with self._buffer_lock:
            self._metrics_buffer.extend(metrics)

            # Check if we need to flush due to queue size
            if len(self._metrics_buffer) >= self._config.max_queue_size:
                logger.debug(f"Buffer size ({len(self._metrics_buffer)}) reached max queue size, flushing")

        # Flush outside the lock if needed
        if len(self._metrics_buffer) >= self._config.max_queue_size:
            await self._flush()

    async def shutdown(self) -> None:
        """Shutdown the publisher and flush any pending metrics."""
        self._is_shutting_down = True

        # Cancel the periodic flush task
        if self._flush_task is not None:
            self._flush_task.cancel()
            try:
                await self._flush_task
            except asyncio.CancelledError:
                pass
            self._flush_task = None

        # Final flush
        await self._flush()

        # Close owned client if we created one
        if self._owned_client is not None and hasattr(self, "_client_context"):
            await self._client_context.__aexit__(None, None, None)
            self._owned_client = None

        logger.info("CloudWatch metrics publisher shutdown complete")

    async def _flush(self) -> None:
        """Flush buffered metrics to CloudWatch."""
        async with self._buffer_lock:
            if not self._metrics_buffer:
                return

            # Take all metrics from buffer
            metrics_to_publish = self._metrics_buffer
            self._metrics_buffer = []

        try:
            # Split into batches (CloudWatch limit is 1000 per request)
            for i in range(0, len(metrics_to_publish), MAX_METRICS_PER_PUT):
                batch = metrics_to_publish[i : i + MAX_METRICS_PER_PUT]
                await self._publish_batch(batch)

            logger.debug(f"Flushed {len(metrics_to_publish)} metrics to CloudWatch")
        except Exception as e:
            logger.error(f"Failed to publish metrics to CloudWatch: {e}")
            # Re-add metrics to buffer for retry (if not shutting down and within limits)
            if not self._is_shutting_down:
                async with self._buffer_lock:
                    if len(self._metrics_buffer) + len(metrics_to_publish) <= self._config.max_queue_size:
                        self._metrics_buffer = metrics_to_publish + self._metrics_buffer

    async def _publish_batch(self, metrics: list[MetricDatum]) -> None:
        """Publish a batch of metrics to CloudWatch.

        Args:
            metrics: The batch of metrics to publish
        """
        client = await self._get_client()

        # Convert to CloudWatch format
        cw_metrics = []
        for m in metrics:
            cw_datum: dict = {
                "MetricName": m.metric_name,
                "Value": m.value,
                "Unit": _to_cloudwatch_unit(m.unit),
                "Timestamp": m.timestamp or datetime.now(timezone.utc),
            }

            if m.dimensions:
                cw_datum["Dimensions"] = [{"Name": d.name, "Value": d.value} for d in m.dimensions]

            cw_metrics.append(cw_datum)

        await client.put_metric_data(
            Namespace=self._config.namespace,
            MetricData=cw_metrics,
        )


class CloudWatchMetricsScope(IMetricsScope):
    """A metrics scope that collects metrics for a specific operation.

    Metrics are collected during the scope's lifetime and published when the
    scope is ended.
    """

    def __init__(
        self,
        publisher: IMetricsPublisher,
        level: MetricsLevel,
        operation: str,
        parent_dimensions: list[MetricDimension] | None = None,
    ) -> None:
        """Initialize the CloudWatch metrics scope.

        Args:
            publisher: The metrics publisher to use
            level: The metrics level
            operation: The operation name (added as a dimension)
            parent_dimensions: Dimensions inherited from parent scope
        """
        self._publisher = publisher
        self._level = level
        self._dimensions: list[MetricDimension] = list(parent_dimensions or [])
        if operation:
            self._dimensions.append(MetricDimension(name="Operation", value=operation))
        self._metrics: list[MetricDatum] = []
        self._is_ended = False

    def add_dimension(self, name: str, value: str) -> CloudWatchMetricsScope:
        """Add a dimension to all metrics in this scope.

        Args:
            name: The dimension name
            value: The dimension value

        Returns:
            This scope for chaining
        """
        if not self._is_ended:
            self._dimensions.append(MetricDimension(name=name, value=value))
        return self

    def add_count(self, name: str, value: float, unit: MetricUnit = MetricUnit.COUNT) -> None:
        """Add a count metric.

        Args:
            name: The metric name
            value: The count value
            unit: The unit (defaults to COUNT)
        """
        if not self._is_ended:
            self._metrics.append(
                MetricDatum(
                    metric_name=name,
                    value=value,
                    unit=unit,
                    dimensions=list(self._dimensions),
                )
            )

    def add_time(self, name: str, value: float, unit: MetricUnit = MetricUnit.MILLISECONDS) -> None:
        """Add a time metric.

        Args:
            name: The metric name
            value: The time value
            unit: The unit (defaults to MILLISECONDS)
        """
        if not self._is_ended:
            self._metrics.append(
                MetricDatum(
                    metric_name=name,
                    value=value,
                    unit=unit,
                    dimensions=list(self._dimensions),
                )
            )

    def add_data(self, name: str, value: float, unit: MetricUnit = MetricUnit.BYTES) -> None:
        """Add a data metric (size in bytes).

        Args:
            name: The metric name
            value: The size in bytes
            unit: The unit (defaults to BYTES)
        """
        if not self._is_ended:
            self._metrics.append(
                MetricDatum(
                    metric_name=name,
                    value=value,
                    unit=unit,
                    dimensions=list(self._dimensions),
                )
            )

    async def timer(self, name: str, operation: Callable[[], Awaitable[T]]) -> T:
        """Record a timing metric by measuring the duration of an operation.

        Args:
            name: The metric name
            operation: The async operation to time

        Returns:
            The result of the operation
        """
        start_time = asyncio.get_event_loop().time()
        try:
            result = await operation()
            elapsed_ms = (asyncio.get_event_loop().time() - start_time) * 1000
            self.add_time(name, elapsed_ms)
            return result
        except Exception:
            elapsed_ms = (asyncio.get_event_loop().time() - start_time) * 1000
            self.add_time(name, elapsed_ms)
            raise

    def create_scope(self) -> CloudWatchMetricsScope:
        """Create a child scope with additional dimensions.

        Returns:
            A new child scope
        """
        return CloudWatchMetricsScope(
            publisher=self._publisher,
            level=self._level,
            operation="",  # No operation name for child scopes
            parent_dimensions=list(self._dimensions),
        )

    def end(self) -> None:
        """End this scope and flush any buffered metrics."""
        if self._is_ended:
            return

        self._is_ended = True

        # Publish collected metrics
        if self._metrics:
            # Fire and forget - metrics should not affect application flow
            asyncio.create_task(self._publish_metrics())

    async def _publish_metrics(self) -> None:
        """Publish collected metrics (called when scope ends)."""
        try:
            await self._publisher.publish(self._metrics)
        except Exception as e:
            logger.error(f"Failed to publish metrics: {e}")

    def get_dimensions(self) -> list[MetricDimension]:
        """Get the current dimensions for this scope.

        Returns:
            Copy of the current dimensions
        """
        return list(self._dimensions)


@dataclass
class CloudWatchMetricsFactoryConfig:
    """Configuration for CloudWatchMetricsFactory."""

    level: MetricsLevel
    """The metrics level (NONE, SUMMARY, DETAILED)"""

    namespace: str
    """CloudWatch namespace for all metrics (e.g., 'KCL/MyApplication')"""

    region: str | None = None
    """AWS region for CloudWatch (used if cloudwatch_client is not provided)"""

    endpoint_url: str | None = None
    """Custom CloudWatch endpoint URL (for local testing with LocalStack, etc.)"""

    buffer_time_seconds: float = DEFAULT_BUFFER_TIME_SECONDS
    """Time in seconds to buffer metrics before flushing (default: 10 seconds)"""

    max_queue_size: int = DEFAULT_MAX_QUEUE_SIZE
    """Maximum number of metrics to buffer before forcing a flush (default: 10000)"""

    default_dimensions: list[MetricDimension] = field(default_factory=list)
    """Default dimensions to add to all metrics"""


class CloudWatchMetricsFactory(IMetricsFactory):
    """CloudWatch metrics factory.

    Creates CloudWatch metrics scopes based on the configured level.
    """

    def __init__(
        self,
        config: CloudWatchMetricsFactoryConfig,
        cloudwatch_client: CloudWatchClient | None = None,
    ) -> None:
        """Initialize the CloudWatch metrics factory.

        Args:
            config: Factory configuration
            cloudwatch_client: Optional pre-configured CloudWatch client.
                If not provided, one will be created automatically.
        """
        self._level = config.level
        self._default_dimensions = list(config.default_dimensions)

        # Create publisher configuration
        publisher_config = CloudWatchMetricsPublisherConfig(
            namespace=config.namespace,
            region=config.region,
            endpoint_url=config.endpoint_url,
            buffer_time_seconds=config.buffer_time_seconds,
            max_queue_size=config.max_queue_size,
        )

        # Create the publisher
        self._publisher = CloudWatchMetricsPublisher(
            config=publisher_config,
            cloudwatch_client=cloudwatch_client,
        )

        logger.info(
            f"CloudWatch metrics factory initialized with level: {self._level}, " f"namespace: {config.namespace}"
        )

    async def start(self) -> None:
        """Start the metrics factory (starts the publisher's periodic flush)."""
        await self._publisher.start()

    def create_scope(self, operation: str) -> IMetricsScope:
        """Create a metrics scope for collecting metrics.

        Args:
            operation: The operation name (used as a dimension)

        Returns:
            A new metrics scope
        """
        if self._level == MetricsLevel.NONE:
            # Return no-op scope to avoid any overhead
            from .noop import NoOpMetricsScope

            return NoOpMetricsScope()

        return CloudWatchMetricsScope(
            publisher=self._publisher,
            level=self._level,
            operation=operation,
            parent_dimensions=self._default_dimensions,
        )

    def get_metrics_level(self) -> MetricsLevel:
        """Get the current metrics level.

        Returns:
            The metrics level
        """
        return self._level

    def is_enabled(self) -> bool:
        """Check if metrics are enabled (level != NONE).

        Returns:
            True if metrics are enabled
        """
        return self._level != MetricsLevel.NONE

    def is_detailed_metrics_enabled(self) -> bool:
        """Check if detailed metrics are enabled (level == DETAILED).

        Returns:
            True if detailed metrics are enabled
        """
        return self._level == MetricsLevel.DETAILED

    async def shutdown(self) -> None:
        """Shutdown the metrics factory and flush any pending metrics."""
        logger.info("Shutting down CloudWatch metrics factory")
        await self._publisher.shutdown()
