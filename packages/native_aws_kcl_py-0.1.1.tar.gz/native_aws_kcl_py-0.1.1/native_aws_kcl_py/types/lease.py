"""Lease type definitions for the Kinesis Consumer Library."""

from dataclasses import dataclass
from typing import Protocol

from .records import ExtendedSequenceNumber, InitialPositionInStreamExtended


@dataclass
class Lease:
    """Represents a lease for processing a shard.

    Leases are stored in a persistence layer (DynamoDB by default) and used
    for coordination between workers.
    """

    lease_key: str
    """The shard ID (also the lease key)"""

    lease_counter: int = 0
    """Counter that is incremented each time the lease is updated.
    Used for optimistic locking to prevent concurrent modifications."""

    lease_owner: str | None = None
    """The identifier of the worker that owns this lease"""

    checkpoint: ExtendedSequenceNumber | None = None
    """The checkpoint sequence number"""

    pending_checkpoint: ExtendedSequenceNumber | None = None
    """Pending checkpoint (for two-phase checkpointing)"""

    concurrency_token: str | None = None
    """The concurrency token for conditional updates"""

    last_counter_increment_nanos: int | None = None
    """Timestamp when the lease was last updated (nanoseconds)"""

    parent_shard_ids: list[str] | None = None
    """Parent shard IDs (for shard hierarchy)"""

    child_shard_ids: list[str] | None = None
    """Child shard IDs (populated when shard ends)"""

    owner_switches_since_checkpoint: int = 0
    """Owner switches since last checkpoint (for detecting thrashing)"""

    is_marked_for_lease_steal: bool = False
    """Whether processing of this shard has been marked for steal"""

    hash_key_range_start: str | None = None
    """Hash key range start (for consistent hashing)"""

    hash_key_range_end: str | None = None
    """Hash key range end"""


@dataclass
class LeaseOperationResult:
    """Result of attempting to acquire or renew a lease."""

    success: bool
    """Whether the operation succeeded"""

    lease: Lease | None = None
    """The updated lease if successful"""

    error: str | None = None
    """Error message if failed"""


@dataclass
class LeaseStats:
    """Statistics about lease operations."""

    total_leases: int
    """Total number of leases"""

    owned_leases: int
    """Number of leases owned by this worker"""

    expired_leases: int
    """Number of expired leases (available for taking)"""

    total_workers: int
    """Number of workers"""


@dataclass
class LeaseManagementConfig:
    """Configuration for lease management.

    This contains storage-agnostic settings that apply to all persistence implementations.
    """

    table_name: str
    """Name of the storage container for leases.
    For DynamoDB: table name
    For S3: bucket/prefix
    For Redis: key prefix
    For SQL: table name"""

    worker_identifier: str
    """The worker identifier"""

    lease_duration_millis: int = 10000
    """Duration of a lease in milliseconds (default: 10000)"""

    epsilon_millis: int = 25
    """Epsilon for timing calculations in milliseconds"""

    max_leases_for_worker: int | None = None
    """Maximum number of leases this worker should hold"""

    max_leases_to_steal_at_one_time: int = 1
    """Maximum number of leases to steal at once"""

    initial_position_in_stream: InitialPositionInStreamExtended | None = None
    """Initial position in stream for new leases"""

    cleanup_leases_upon_shard_completion: bool = True
    """Whether to clean up leases for shards that no longer exist"""

    ignore_unexpected_child_shards: bool = False
    """Whether to ignore unexpected child shards"""

    # DynamoDB-specific options
    billing_mode: str = "PAY_PER_REQUEST"
    """Billing mode for DynamoDB table"""

    read_capacity_units: int = 10
    """Read capacity units (if PROVISIONED)"""

    write_capacity_units: int = 10
    """Write capacity units (if PROVISIONED)"""


class LeaseRefresher(Protocol):
    """Interface for lease storage operations.

    This is the core persistence interface that all storage implementations must implement.
    The default implementation uses DynamoDB, but alternative implementations can be provided
    for other storage backends (S3, MySQL, Redis, etc.).
    """

    async def create_lease_table_if_not_exists(self) -> bool:
        """Create the lease table if it doesn't exist.

        Returns:
            True if table was created, False if it already existed.
        """
        ...

    async def wait_for_table_active(self) -> None:
        """Wait for the lease table to become active."""
        ...

    async def lease_table_exists(self) -> bool:
        """Check if the lease table exists."""
        ...

    async def list_leases(self) -> list[Lease]:
        """List all leases."""
        ...

    async def get_lease(self, lease_key: str) -> Lease | None:
        """Get a specific lease by key."""
        ...

    async def create_lease(self, lease: Lease) -> bool:
        """Create a new lease.

        Returns:
            True if created, False if already exists.
        """
        ...

    async def renew_lease(self, lease: Lease) -> bool:
        """Renew a lease (increment counter, update timestamp).

        Returns:
            True if renewed, False if lease was modified by another worker.
        """
        ...

    async def take_lease(self, lease: Lease, new_owner: str) -> bool:
        """Take a lease from another worker.

        Returns:
            True if taken, False if conditional check failed.
        """
        ...

    async def evict_lease(self, lease: Lease) -> bool:
        """Evict the current owner from a lease."""
        ...

    async def update_lease(self, lease: Lease) -> bool:
        """Update a lease (e.g., checkpoint)."""
        ...

    async def delete_lease(self, lease: Lease) -> bool:
        """Delete a lease."""
        ...

    async def delete_all_leases(self) -> None:
        """Delete all leases (for cleanup)."""
        ...

    def is_lease_expired(self, lease: Lease, lease_duration_millis: int) -> bool:
        """Check if a lease is expired based on the lease duration."""
        ...
