"""Record type definitions for the Kinesis Consumer Library."""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class InitialPositionInStream(str, Enum):
    """Initial position in stream for new leases."""

    TRIM_HORIZON = "TRIM_HORIZON"
    """Start reading at the last untrimmed record in the shard (oldest)"""

    LATEST = "LATEST"
    """Start reading just after the most recent record in the shard"""

    AT_TIMESTAMP = "AT_TIMESTAMP"
    """Start reading at a specific timestamp"""


@dataclass
class InitialPositionInStreamExtended:
    """Configuration for initial position when starting to process a shard."""

    initial_position_in_stream: InitialPositionInStream
    """The initial position"""

    timestamp: datetime | None = None
    """Timestamp for AT_TIMESTAMP position"""


@dataclass
class ExtendedSequenceNumber:
    """Position in the stream for checkpointing."""

    sequence_number: str
    """The sequence number"""

    sub_sequence_number: int = 0
    """The sub-sequence number for aggregated records"""

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ExtendedSequenceNumber):
            return False
        return self.sequence_number == other.sequence_number and self.sub_sequence_number == other.sub_sequence_number

    def __hash__(self) -> int:
        return hash((self.sequence_number, self.sub_sequence_number))


@dataclass
class KinesisRecord:
    """Represents a single record from a Kinesis stream.

    Mirrors the structure from AWS SDK Kinesis Record.
    """

    sequence_number: str
    """The unique identifier of the record within its shard"""

    partition_key: str
    """Identifies which shard in the stream the data record is assigned to"""

    data: bytes
    """The data blob"""

    approximate_arrival_timestamp: datetime | None = None
    """The approximate time that the record was inserted into the stream"""

    encryption_type: str | None = None
    """The encryption type used on the record ('NONE' or 'KMS')"""


@dataclass
class KinesisClientRecord(KinesisRecord):
    """Extended record with additional metadata for processing."""

    sub_sequence_number: int | None = None
    """Sub-sequence number used for aggregated records"""

    aggregated: bool = False
    """Whether this record was aggregated"""


@dataclass
class HashKeyRange:
    """The range of possible hash keys for a shard."""

    starting_hash_key: str
    ending_hash_key: str


@dataclass
class SequenceNumberRange:
    """The range of possible sequence numbers for a shard."""

    starting_sequence_number: str
    ending_sequence_number: str | None = None


@dataclass
class Shard:
    """Shard information from Kinesis."""

    shard_id: str
    """The unique identifier of the shard"""

    hash_key_range: HashKeyRange
    """The range of possible hash keys for the shard"""

    sequence_number_range: SequenceNumberRange
    """The range of possible sequence numbers for the shard"""

    parent_shard_id: str | None = None
    """The shard ID of the parent shard"""

    adjacent_parent_shard_id: str | None = None
    """The shard ID of the adjacent parent shard (for merges)"""


@dataclass
class ChildShard:
    """Child shards information (for shard end handling)."""

    shard_id: str
    """The shard ID of the child shard"""

    parent_shards: list[str] = field(default_factory=list)
    """The parent shard IDs"""

    hash_key_range: HashKeyRange | None = None
    """The hash key range"""
