"""Processor type definitions for the Kinesis Consumer Library."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Protocol

from .records import ChildShard, ExtendedSequenceNumber, KinesisClientRecord

if TYPE_CHECKING:
    pass


class ShutdownReason(str, Enum):
    """Shutdown reason enumeration."""

    SHARD_END = "SHARD_END"
    """The shard has been closed (split/merge completed)"""

    LEASE_LOST = "LEASE_LOST"
    """The lease was lost to another worker"""

    REQUESTED = "REQUESTED"
    """A graceful shutdown was requested"""

    ZOMBIE = "ZOMBIE"
    """The consumer became a zombie (too many failures)"""


class RecordProcessorCheckpointer(Protocol):
    """Checkpointer interface for recording progress in processing a shard.

    Used by the record processor to checkpoint processed records.
    """

    async def checkpoint(
        self,
        sequence_number: str | None = None,
        sub_sequence_number: int | None = None,
    ) -> None:
        """Checkpoint at a specific sequence number.

        Args:
            sequence_number: The sequence number to checkpoint at.
                            If None, checkpoints at the last processed record.
            sub_sequence_number: Optional sub-sequence number for aggregated records.
        """
        ...

    async def prepare_checkpoint(
        self,
        sequence_number: str | None = None,
        sub_sequence_number: int | None = None,
    ) -> ExtendedSequenceNumber:
        """Prepare to checkpoint (for two-phase checkpointing).

        Args:
            sequence_number: The sequence number to prepare checkpoint at.
            sub_sequence_number: Optional sub-sequence number.

        Returns:
            The extended sequence number being prepared for checkpoint.
        """
        ...

    def get_shard_id(self) -> str:
        """Get the shard ID associated with this checkpointer."""
        ...


@dataclass
class InitializationInput:
    """Input provided when initializing a record processor."""

    shard_id: str
    """The shard ID that this processor will process"""

    extended_sequence_number: ExtendedSequenceNumber
    """The extended sequence number to start processing from"""

    pending_checkpoint_sequence_number: ExtendedSequenceNumber | None = None
    """The pending checkpoint, if any, from a previous processing attempt"""


@dataclass
class ProcessRecordsInput:
    """Input provided when processing records."""

    records: list[KinesisClientRecord]
    """The records to process"""

    checkpointer: RecordProcessorCheckpointer
    """Checkpointer to record progress"""

    millis_behind_latest: int = 0
    """Milliseconds behind latest - how far behind the processor is"""

    is_at_shard_end: bool = False
    """Whether we're at the end of the shard"""

    child_shards: list[ChildShard] | None = None
    """Child shards if at shard end"""


@dataclass
class LeaseLostInput:
    """Input provided when the lease is lost."""

    shard_id: str
    """The shard ID that lost its lease"""


@dataclass
class ShardEndedInput:
    """Input provided when a shard has ended (split/merge)."""

    shard_id: str
    """The shard ID that has ended"""

    checkpointer: RecordProcessorCheckpointer
    """Checkpointer to record final checkpoint"""

    child_shards: list[ChildShard] | None = None
    """Child shards that resulted from the split/merge"""


@dataclass
class ShutdownRequestedInput:
    """Input provided when shutdown is requested."""

    shard_id: str
    """The shard ID being shut down"""

    checkpointer: RecordProcessorCheckpointer
    """Checkpointer to record final checkpoint before shutdown"""


class ShardRecordProcessor(ABC):
    """The main interface that applications must implement to process records.

    This mirrors the KCL ShardRecordProcessor interface.

    Example:
        ```python
        class MyRecordProcessor(ShardRecordProcessor):
            async def initialize(self, input: InitializationInput) -> None:
                print(f"Starting to process shard {input.shard_id}")

            async def process_records(self, input: ProcessRecordsInput) -> None:
                for record in input.records:
                    # Process the record
                    data = record.data.decode('utf-8')
                    print(f"Processing: {data}")

                # Checkpoint after processing
                if input.records:
                    await input.checkpointer.checkpoint()

            async def lease_lost(self, input: LeaseLostInput) -> None:
                print(f"Lost lease for shard {input.shard_id}")

            async def shard_ended(self, input: ShardEndedInput) -> None:
                # Checkpoint at shard end
                await input.checkpointer.checkpoint()
                print(f"Shard {input.shard_id} ended")

            async def shutdown_requested(self, input: ShutdownRequestedInput) -> None:
                # Checkpoint before shutdown
                await input.checkpointer.checkpoint()
                print(f"Shutdown requested for shard {input.shard_id}")
        ```
    """

    @abstractmethod
    async def initialize(self, initialization_input: InitializationInput) -> None:
        """Called before data records are delivered to the processor.

        Allows the processor to initialize any resources needed for processing.

        Args:
            initialization_input: Initialization information including shard ID.
        """
        pass

    @abstractmethod
    async def process_records(self, process_records_input: ProcessRecordsInput) -> None:
        """Called to process data records.

        The processor should process the records and optionally checkpoint progress.

        Args:
            process_records_input: Contains the records and a checkpointer.
        """
        pass

    @abstractmethod
    async def lease_lost(self, lease_lost_input: LeaseLostInput) -> None:
        """Called when the lease for the shard has been lost.

        After this is called, the processor can no longer checkpoint.

        Args:
            lease_lost_input: Information about the lost lease.
        """
        pass

    @abstractmethod
    async def shard_ended(self, shard_ended_input: ShardEndedInput) -> None:
        """Called when the shard has ended (due to split or merge).

        The processor should checkpoint to indicate completion.

        Args:
            shard_ended_input: Information about shard end including child shards.
        """
        pass

    @abstractmethod
    async def shutdown_requested(self, shutdown_requested_input: ShutdownRequestedInput) -> None:
        """Called when a graceful shutdown has been requested.

        The processor should checkpoint before the lease is released.

        Args:
            shutdown_requested_input: Information for graceful shutdown.
        """
        pass


class ShardRecordProcessorFactory(ABC):
    """Factory for creating ShardRecordProcessor instances.

    The KCL will call this factory to create a processor for each shard.

    Example:
        ```python
        class MyProcessorFactory(ShardRecordProcessorFactory):
            def create_processor(self) -> ShardRecordProcessor:
                return MyRecordProcessor()
        ```
    """

    @abstractmethod
    def create_processor(self) -> ShardRecordProcessor:
        """Create a new ShardRecordProcessor instance.

        Called once for each shard that will be processed.
        """
        pass
