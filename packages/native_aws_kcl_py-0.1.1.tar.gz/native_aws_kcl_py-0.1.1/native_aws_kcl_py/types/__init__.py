"""Type definitions for the Kinesis Consumer Library."""

from .config import (
    DEFAULT_CONFIG,
    AwsConfig,
    CheckpointConfig,
    CoordinatorConfig,
    KinesisConsumerConfig,
    LifecycleConfig,
    MetricsConfig,
    PersistenceConfig,
    RetrievalConfig,
)
from .lease import (
    Lease,
    LeaseManagementConfig,
    LeaseOperationResult,
    LeaseRefresher,
    LeaseStats,
)
from .processor import (
    InitializationInput,
    LeaseLostInput,
    ProcessRecordsInput,
    RecordProcessorCheckpointer,
    ShardEndedInput,
    ShardRecordProcessor,
    ShardRecordProcessorFactory,
    ShutdownReason,
    ShutdownRequestedInput,
)
from .records import (
    ChildShard,
    ExtendedSequenceNumber,
    HashKeyRange,
    InitialPositionInStream,
    InitialPositionInStreamExtended,
    KinesisClientRecord,
    KinesisRecord,
    SequenceNumberRange,
    Shard,
)

__all__ = [
    # Records
    "KinesisRecord",
    "KinesisClientRecord",
    "ExtendedSequenceNumber",
    "InitialPositionInStream",
    "InitialPositionInStreamExtended",
    "Shard",
    "ChildShard",
    "HashKeyRange",
    "SequenceNumberRange",
    # Lease
    "Lease",
    "LeaseOperationResult",
    "LeaseStats",
    "LeaseRefresher",
    "LeaseManagementConfig",
    # Processor
    "RecordProcessorCheckpointer",
    "InitializationInput",
    "ProcessRecordsInput",
    "LeaseLostInput",
    "ShardEndedInput",
    "ShutdownRequestedInput",
    "ShardRecordProcessor",
    "ShardRecordProcessorFactory",
    "ShutdownReason",
    # Config
    "AwsConfig",
    "RetrievalConfig",
    "CheckpointConfig",
    "CoordinatorConfig",
    "LifecycleConfig",
    "MetricsConfig",
    "PersistenceConfig",
    "KinesisConsumerConfig",
    "DEFAULT_CONFIG",
]
