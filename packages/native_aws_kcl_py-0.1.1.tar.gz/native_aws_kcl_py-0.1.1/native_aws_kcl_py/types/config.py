"""Configuration type definitions for the Kinesis Consumer Library."""

import sys
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from .processor import ShardRecordProcessorFactory
from .records import InitialPositionInStreamExtended

if TYPE_CHECKING:
    pass  # Used for forward references in type hints


@dataclass
class AwsConfig:
    """AWS SDK configuration."""

    region: str
    """AWS region"""

    credentials: dict | None = None
    """AWS credentials (optional, uses default provider chain if not provided)
    Dict with: access_key_id, secret_access_key, session_token (optional)"""

    kinesis_endpoint: str | None = None
    """Custom Kinesis endpoint (for local testing)"""

    dynamodb_endpoint: str | None = None
    """Custom DynamoDB endpoint (for local testing)"""

    cloudwatch_endpoint: str | None = None
    """Custom CloudWatch endpoint (for local testing)"""


@dataclass
class RetrievalConfig:
    """Configuration for retrieving records from Kinesis."""

    stream_name: str
    """The name of the Kinesis stream to process"""

    max_records: int = 10000
    """Maximum number of records to retrieve in a single GetRecords call (1-10000)"""

    idle_time_between_reads_millis: int = 1000
    """Idle time between GetRecords calls in milliseconds"""

    use_enhanced_fan_out: bool = False
    """Whether to use enhanced fan-out"""

    stream_arn: str | None = None
    """The ARN of the Kinesis stream (alternative to stream_name)"""

    consumer_arn: str | None = None
    """Consumer ARN for enhanced fan-out (required if use_enhanced_fan_out is True)"""

    consumer_name: str | None = None
    """Consumer name for enhanced fan-out registration"""


@dataclass
class CheckpointConfig:
    """Configuration for checkpointing."""

    call_process_records_even_for_empty_record_list: bool = False
    """Whether to call processRecords even when no records are received"""

    skip_checkpoint_validation_on_shard_end: bool = False
    """Whether to skip checkpointing when shard end is reached"""

    always_start_from_latest: bool = False
    """Always start from the LATEST position in the shard, ignoring any existing checkpoint.

    When set to True:
    - The consumer will always start reading from the newest records in the shard
    - Existing checkpoints in DynamoDB will be ignored (but not deleted)
    - Useful for scenarios where you want to skip backlog and only process new data

    WARNING: Setting this to True means you may miss records that arrived while
    the consumer was not running. Only use this if you intentionally want to skip
    historical data.
    """

    skip_checkpoint_operations: bool = False
    """Skip checkpoint read/write operations.

    When True, checkpoint operations become no-ops - the checkpoint() method returns
    immediately without persisting any data. This is automatically set when:
    - enable_checkpoint=False AND always_start_from_latest=True

    Note: Lease coordination (shard assignment, failover) still uses persistence.
    Only checkpoint data reading/writing is skipped.
    """


@dataclass
class CoordinatorConfig:
    """Configuration for coordinating between workers."""

    lease_duration_millis: int = 10000
    """Duration of lease in milliseconds"""

    epsilon_millis: int = 25
    """Epsilon for timing calculations"""

    max_leases_for_worker: int = sys.maxsize
    """Maximum number of leases this worker can hold (effectively unlimited)"""

    max_leases_to_steal_at_one_time: int = 1
    """Maximum number of leases to steal at once"""

    lease_acquisition_interval_millis: int = 20000
    """Interval for taking leases in milliseconds (2 * leaseDuration + epsilon)"""

    lease_renewal_interval_millis: int = 3000
    """Interval for renewing leases in milliseconds (leaseDuration / 3)"""

    cleanup_leases_upon_shard_completion: bool = True
    """Whether to cleanup leases upon shard completion"""


@dataclass
class LifecycleConfig:
    """Configuration for lifecycle management."""

    log_warning_for_task_after_millis: int = 60000
    """Interval for logging warnings about long-running tasks"""

    task_execution_timeout_millis: int = 300000
    """Timeout for task execution in milliseconds (5 minutes)"""

    max_consecutive_failures: int = 10
    """Number of consecutive task failures before shutdown"""


@dataclass
class MetricsConfig:
    """Configuration for metrics.

    The metrics system is pluggable - you can use CloudWatch (default),
    or provide a custom implementation for other backends.

    Default behavior: NO metrics (level: NONE)
    """

    level: str = "NONE"
    """Metrics reporting level: NONE, SUMMARY, or DETAILED"""

    namespace: str | None = None
    """CloudWatch namespace for metrics.
    Only used when level is not NONE and no custom factory is provided.
    Default: "KCL/{applicationName}" """

    buffer_time_millis: int = 10000
    """Buffer time before flushing metrics (in milliseconds)"""

    max_queue_size: int = 10000
    """Maximum number of metrics to buffer before flushing"""

    custom_factory: Any | None = None
    """Custom metrics factory implementation (IMetricsFactory)"""

    default_dimensions: list[dict] | None = None
    """Default dimensions to add to all metrics.
    Each dict should have 'name' and 'value' keys."""


@dataclass
class PersistenceConfig:
    """Configuration for the persistence layer.

    By default, DynamoDB is used for storing lease and checkpoint information.
    You can provide a custom LeaseRefresher implementation for alternative
    storage backends (S3, MySQL, Redis, etc.).
    """

    lease_refresher: Any | None = None
    """Custom LeaseRefresher implementation.

    If provided, this will be used instead of the default DynamoDB implementation.
    """

    dynamodb_billing_mode: str = "PAY_PER_REQUEST"
    """Billing mode for DynamoDB table"""

    dynamodb_read_capacity_units: int = 10
    """Read capacity units (if PROVISIONED)"""

    dynamodb_write_capacity_units: int = 10
    """Write capacity units (if PROVISIONED)"""


@dataclass
class KinesisConsumerConfig:
    """Main configuration for the Kinesis Consumer."""

    aws: AwsConfig
    """AWS configuration"""

    application_name: str
    """Application name (used as consumer group identifier and DynamoDB table name)"""

    stream_name: str
    """Kinesis stream name or ARN"""

    record_processor_factory: ShardRecordProcessorFactory
    """Factory for creating record processors"""

    worker_identifier: str | None = None
    """Worker identifier (defaults to hostname + UUID)"""

    initial_position_in_stream: InitialPositionInStreamExtended | None = None
    """Initial position in stream (defaults to TRIM_HORIZON)"""

    retrieval: RetrievalConfig | None = None
    """Retrieval configuration"""

    checkpoint: CheckpointConfig | None = None
    """Checkpoint configuration"""

    coordinator: CoordinatorConfig | None = None
    """Coordinator configuration"""

    lifecycle: LifecycleConfig | None = None
    """Lifecycle configuration"""

    metrics: MetricsConfig | None = None
    """Metrics configuration"""

    persistence: PersistenceConfig | None = None
    """Persistence layer configuration"""


# Default configuration values
DEFAULT_CONFIG = {
    "retrieval": {
        "max_records": 10000,
        "idle_time_between_reads_millis": 1000,
        "use_enhanced_fan_out": False,
    },
    "checkpoint": {
        "call_process_records_even_for_empty_record_list": False,
        "skip_checkpoint_validation_on_shard_end": False,
        "always_start_from_latest": False,
        "skip_checkpoint_operations": False,
    },
    "coordinator": {
        "lease_duration_millis": 10000,
        "epsilon_millis": 25,
        "max_leases_for_worker": sys.maxsize,
        "max_leases_to_steal_at_one_time": 1,
        "lease_acquisition_interval_millis": 20000,  # 2 * leaseDuration + epsilon
        "lease_renewal_interval_millis": 3000,  # leaseDuration / 3
        "cleanup_leases_upon_shard_completion": True,
    },
    "lifecycle": {
        "log_warning_for_task_after_millis": 60000,
        "task_execution_timeout_millis": 300000,  # 5 minutes
        "max_consecutive_failures": 10,
    },
    "metrics": {
        "level": "NONE",
        "buffer_time_millis": 10000,
        "max_queue_size": 10000,
    },
}
