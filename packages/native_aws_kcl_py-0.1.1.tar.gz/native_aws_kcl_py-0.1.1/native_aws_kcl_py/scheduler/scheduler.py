"""Scheduler (Worker) - main entry point for the Kinesis Consumer Library.

The Scheduler coordinates all components of the KCL:
- LeaseCoordinator: Manages shard leases for distributed processing
- ShardDetector: Discovers shards in the stream
- ShardSyncer: Synchronizes shards with leases
- ShardConsumers: Process records from individual shards
"""

import asyncio
import logging
import socket
import uuid
from enum import Enum

from ..exceptions import (
    InvalidSchedulerStateException,
    KinesisClientLibraryException,
    KinesisException,
    LeaseException,
    ProcessorInitializationException,
    SchedulerInitializationException,
    is_retryable_exception,
)
from ..kinesis import CHECKPOINT_SENTINEL, RecordFetcher, ShardDetector, ShardSyncer
from ..leases import (
    LeaseAcquiredEvent,
    LeaseCoordinator,
    LeaseCoordinatorEvent,
    LeaseErrorEvent,
    LeaseLostEvent,
    LeaseRenewedEvent,
)
from ..metrics import (
    IMetricsFactory,
    KCLMetrics,
    create_metrics_factory,
    parse_metrics_level,
)
from ..processor import ShardConsumer, ShardConsumerConfig, ShardConsumerState
from ..types import (
    DEFAULT_CONFIG,
    InitialPositionInStream,
    InitialPositionInStreamExtended,
    KinesisConsumerConfig,
    Lease,
    LeaseManagementConfig,
    ShutdownReason,
)


class SchedulerState(str, Enum):
    """State of the scheduler."""

    CREATED = "CREATED"
    INITIALIZING = "INITIALIZING"
    RUNNING = "RUNNING"
    SHUTTING_DOWN = "SHUTTING_DOWN"
    SHUTDOWN = "SHUTDOWN"
    SHUTDOWN_FAILED = "SHUTDOWN_FAILED"


class Scheduler:
    """The Scheduler (also known as Worker in KCL) is the main entry point for
    the Kinesis Consumer Library.

    It coordinates all components:
    - LeaseCoordinator: Manages shard leases for distributed processing
    - ShardDetector: Discovers shards in the stream
    - ShardSyncer: Synchronizes shards with leases
    - ShardConsumers: Process records from individual shards

    Example:
        ```python
        from native_aws_kcl_py import (
            Scheduler,
            KinesisConsumerConfig,
            AwsConfig,
            ShardRecordProcessorFactory,
        )

        class MyProcessorFactory(ShardRecordProcessorFactory):
            def create_processor(self):
                return MyRecordProcessor()

        config = KinesisConsumerConfig(
            aws=AwsConfig(region="eu-west-1"),
            application_name="my-consumer",
            stream_name="my-kinesis-stream",
            record_processor_factory=MyProcessorFactory(),
        )

        scheduler = Scheduler(config)

        # Run until shutdown
        await scheduler.run()
        ```
    """

    _logger = logging.getLogger("kcl.Scheduler")

    MAX_INIT_RETRIES = 3
    INIT_RETRY_DELAY_MS = 5000
    METRICS_INTERVAL_MS = 60000  # 1 minute

    def __init__(self, config: KinesisConsumerConfig):
        """Initialize the scheduler.

        Args:
            config: The consumer configuration
        """
        self._config = self._resolve_config(config)
        self._processor_factory = config.record_processor_factory

        # Initialize metrics factory
        self._metrics_factory = self._create_metrics_factory(config)

        # Components (initialized later)
        self._lease_coordinator: LeaseCoordinator | None = None
        self._shard_detector: ShardDetector | None = None
        self._shard_syncer: ShardSyncer | None = None

        # Active shard consumers
        self._shard_consumers: dict[str, ShardConsumer] = {}

        # State management
        self._state = SchedulerState.CREATED
        self._shutdown_event = asyncio.Event()
        self._shutdown_complete_event = asyncio.Event()

        # Periodic tasks
        self._shard_sync_task: asyncio.Task | None = None
        self._health_check_task: asyncio.Task | None = None
        self._metrics_task: asyncio.Task | None = None

        # Error tracking
        self._consecutive_init_errors = 0
        self._last_error: Exception | None = None

    def _create_metrics_factory(self, config: KinesisConsumerConfig) -> IMetricsFactory:
        """Create the metrics factory based on configuration."""
        if config.metrics and config.metrics.custom_factory:
            self._logger.info("Using custom metrics factory")
            return config.metrics.custom_factory

        level = parse_metrics_level(config.metrics.level if config.metrics else None)

        self._logger.info(f"Metrics level: {level}")
        return create_metrics_factory(
            level=level,
            namespace=config.metrics.namespace if config.metrics else None,
        )

    def get_metrics_factory(self) -> IMetricsFactory:
        """Get the metrics factory."""
        return self._metrics_factory

    async def run(self) -> None:
        """Start the scheduler and begin processing records.

        This method blocks until shutdown is called.

        Raises:
            InvalidSchedulerStateException: If scheduler is not in CREATED state
            SchedulerInitializationException: If initialization fails
        """
        if self._state != SchedulerState.CREATED:
            raise InvalidSchedulerStateException(
                f"Cannot start scheduler in state {self._state}",
                self._state,
                "run",
            )

        self._state = SchedulerState.INITIALIZING
        self._logger.info(f"Starting Kinesis Consumer for stream {self._config['stream_name']}")
        self._logger.info(f"Worker ID: {self._config['worker_identifier']}")

        try:
            # Initialize components with retry
            await self._initialize_with_retry()

            if not self._lease_coordinator:
                raise SchedulerInitializationException("Lease coordinator not initialized")

            # Start the lease coordinator
            await self._lease_coordinator.start()

            # Perform initial shard sync
            await self._sync_shards_with_retry()

            # Start periodic tasks
            self._start_shard_sync()
            self._start_health_check()
            self._start_metrics_publishing()

            self._state = SchedulerState.RUNNING
            self._logger.info("Scheduler is now running")

            # Wait for shutdown
            await self._shutdown_event.wait()

        except Exception as e:
            self._state = SchedulerState.SHUTDOWN_FAILED
            self._last_error = e

            # Clean up any partially initialized components
            await self._cleanup_on_error()

            if isinstance(e, KinesisClientLibraryException):
                raise

            raise SchedulerInitializationException(
                f"Failed to start scheduler: {e}",
                e,
            )

    async def shutdown(self) -> None:
        """Request a graceful shutdown."""
        if self._state not in [SchedulerState.RUNNING, SchedulerState.INITIALIZING]:
            self._logger.warning(f"Shutdown requested but scheduler is in state {self._state}")
            return

        self._state = SchedulerState.SHUTTING_DOWN
        self._logger.info("Initiating graceful shutdown...")

        try:
            # Stop periodic tasks
            self._stop_periodic_tasks()

            # Stop all shard consumers with timeout
            await self._stop_all_consumers()

            # Stop the lease coordinator (releases all leases)
            if self._lease_coordinator:
                try:
                    await self._lease_coordinator.stop()
                except Exception as e:
                    self._logger.warning(f"Error stopping lease coordinator: {e}")

            # Shutdown metrics factory
            await self._metrics_factory.shutdown()

            self._state = SchedulerState.SHUTDOWN
            self._logger.info("Scheduler shutdown complete")

        except Exception as e:
            self._logger.error(f"Error during shutdown: {e}")
            self._state = SchedulerState.SHUTDOWN_FAILED
            self._last_error = e
            raise

        finally:
            # Signal shutdown complete
            self._shutdown_event.set()
            self._shutdown_complete_event.set()

    async def _initialize_with_retry(self) -> None:
        """Initialize components with retry logic."""
        for attempt in range(self.MAX_INIT_RETRIES):
            try:
                await self._initialize_components()
                self._consecutive_init_errors = 0
                return

            except Exception as e:
                self._consecutive_init_errors += 1
                self._logger.error(f"Initialization attempt {attempt + 1}/{self.MAX_INIT_RETRIES} failed: {e}")

                # Don't retry non-retryable errors
                if not is_retryable_exception(e):
                    raise

                if attempt < self.MAX_INIT_RETRIES - 1:
                    await asyncio.sleep(self.INIT_RETRY_DELAY_MS * (attempt + 1) / 1000)

        raise SchedulerInitializationException(f"Failed to initialize after {self.MAX_INIT_RETRIES} attempts")

    async def _initialize_components(self) -> None:
        """Initialize all components."""
        try:
            # Create lease management config
            # Note: Persistence is always needed for lease coordination (shard assignment,
            # failover, etc.). Only checkpoint read/write operations are skipped when
            # skip_checkpoint_operations=True.
            lease_config = LeaseManagementConfig(
                table_name=self._config["application_name"],
                worker_identifier=self._config["worker_identifier"],
                lease_duration_millis=self._config["coordinator"]["lease_duration_millis"],
                epsilon_millis=self._config["coordinator"]["epsilon_millis"],
                max_leases_for_worker=self._config["coordinator"]["max_leases_for_worker"],
                max_leases_to_steal_at_one_time=(self._config["coordinator"]["max_leases_to_steal_at_one_time"]),
                initial_position_in_stream=self._config["initial_position_in_stream"],
                cleanup_leases_upon_shard_completion=(
                    self._config["coordinator"]["cleanup_leases_upon_shard_completion"]
                ),
            )

            # Create the lease coordinator
            self._lease_coordinator = LeaseCoordinator(
                config=lease_config,
                region_name=self._config["aws"]["region"],
                endpoint_url=self._config["aws"].get("dynamodb_endpoint"),
                metrics_factory=self._metrics_factory,
            )

            # Initialize the lease table
            await self._lease_coordinator.initialize()
            self._logger.info("Lease coordinator initialized")

            # Register for lease events
            self._lease_coordinator.on_event(self._handle_lease_event)

            # Create the shard detector
            self._shard_detector = ShardDetector(
                stream_name=self._config["stream_name"],
                region_name=self._config["aws"]["region"],
                endpoint_url=self._config["aws"].get("kinesis_endpoint"),
            )

            # Initialize the shard detector
            await self._shard_detector.initialize()
            self._logger.info("Shard detector initialized")

            # Create the shard syncer
            cleanup_on_completion = self._config["coordinator"]["cleanup_leases_upon_shard_completion"]
            self._shard_syncer = ShardSyncer(
                shard_detector=self._shard_detector,
                lease_coordinator=self._lease_coordinator,
                initial_position=self._config["initial_position_in_stream"],
                cleanup_leases_upon_shard_completion=cleanup_on_completion,
                ignore_unexpected_child_shards=False,
            )
            self._logger.info("Shard syncer initialized")

        except LeaseException as e:
            raise SchedulerInitializationException(
                f"Failed to initialize lease coordinator: {e}",
                e,
            )
        except KinesisException as e:
            raise SchedulerInitializationException(
                f"Failed to initialize shard detector: {e}",
                e,
            )

    async def _sync_shards_with_retry(self) -> None:
        """Sync shards with retry logic."""
        if not self._shard_syncer:
            self._logger.warning("Shard syncer not initialized, skipping sync")
            return

        max_retries = 3

        for attempt in range(max_retries):
            try:
                await self._shard_syncer.sync_shards()
                return
            except Exception as e:
                self._logger.warning(f"Shard sync attempt {attempt + 1}/{max_retries} failed: {e}")

                if attempt < max_retries - 1 and is_retryable_exception(e):
                    await asyncio.sleep(1 * (attempt + 1))
                elif not is_retryable_exception(e):
                    raise

        # Don't fail initialization if shard sync fails - it will retry
        self._logger.warning("Initial shard sync failed, will retry during periodic sync")

    def _handle_lease_event(self, event: LeaseCoordinatorEvent) -> None:
        """Handle lease coordinator events."""
        try:
            if isinstance(event, LeaseAcquiredEvent):
                if event.lease:
                    self._on_lease_acquired(event.lease)
            elif isinstance(event, LeaseLostEvent):
                self._on_lease_lost(event.lease_key)
            elif isinstance(event, LeaseRenewedEvent):
                if event.lease:
                    self._logger.debug(f"Lease renewed: {event.lease.lease_key}")
            elif isinstance(event, LeaseErrorEvent):
                if event.error:
                    self._handle_lease_error(event.error)

        except Exception as e:
            self._logger.error(f"Error handling lease event: {e}")

    def _handle_lease_error(self, error: Exception) -> None:
        """Handle lease errors."""
        self._logger.error(f"Lease coordinator error: {error}")
        self._last_error = error

        # If it's a critical error, we might need to shutdown
        error_msg = str(error).lower()
        if "table not found" in error_msg or "access denied" in error_msg:
            self._logger.error("Critical lease error - initiating shutdown")
            asyncio.create_task(self.shutdown())

    def _on_lease_acquired(self, lease: Lease) -> None:
        """Handle lease acquired event - start a shard consumer."""
        # Don't start consumers if we're shutting down
        if self._state not in [SchedulerState.RUNNING, SchedulerState.INITIALIZING]:
            self._logger.debug(f"Ignoring lease acquisition during {self._state}")
            return

        # Ensure lease coordinator is initialized
        if not self._lease_coordinator:
            self._logger.error("Lease coordinator not initialized, cannot start consumer")
            return

        # Don't start a consumer if one already exists for this shard
        if lease.lease_key in self._shard_consumers:
            self._logger.debug(f"Consumer already exists for shard {lease.lease_key}")
            return

        # Don't start a consumer for completed shards
        if lease.checkpoint and lease.checkpoint.sequence_number == CHECKPOINT_SENTINEL.SHARD_END:
            self._logger.debug(f"Skipping completed shard {lease.lease_key}")
            return

        self._logger.info(f"Acquired lease for shard {lease.lease_key}, starting consumer")

        try:
            # Create a new processor
            processor = self._processor_factory.create_processor()

            # Create a record fetcher for this shard
            record_fetcher = RecordFetcher(
                stream_name=self._config["stream_name"],
                shard_id=lease.lease_key,
                region_name=self._config["aws"]["region"],
                endpoint_url=self._config["aws"].get("kinesis_endpoint"),
                max_records=self._config["retrieval"]["max_records"],
                initial_position=self._config["initial_position_in_stream"],
            )

            # Create consumer config
            retrieval_cfg = self._config["retrieval"]
            checkpoint_cfg = self._config["checkpoint"]
            lifecycle_cfg = self._config["lifecycle"]
            consumer_config = ShardConsumerConfig(
                shard_id=lease.lease_key,
                stream_name=self._config["stream_name"],
                idle_time_between_reads_millis=retrieval_cfg["idle_time_between_reads_millis"],
                call_process_records_even_for_empty_record_list=(
                    checkpoint_cfg["call_process_records_even_for_empty_record_list"]
                ),
                max_consecutive_failures=lifecycle_cfg["max_consecutive_failures"],
                task_timeout_millis=lifecycle_cfg["task_execution_timeout_millis"],
                log_warning_for_task_after_millis=(lifecycle_cfg["log_warning_for_task_after_millis"]),
                always_start_from_latest=checkpoint_cfg["always_start_from_latest"],
                skip_checkpoint_operations=checkpoint_cfg["skip_checkpoint_operations"],
            )

            # Create and start the consumer
            consumer = ShardConsumer(
                lease_coordinator=self._lease_coordinator,
                processor=processor,
                record_fetcher=record_fetcher,
                config=consumer_config,
                metrics_factory=self._metrics_factory,
            )

            self._shard_consumers[lease.lease_key] = consumer

            # Start the consumer (async, don't await)
            asyncio.create_task(self._start_consumer(lease.lease_key, consumer))

        except Exception as e:
            self._logger.error(f"Failed to create consumer for shard {lease.lease_key}: {e}")

    async def _start_consumer(self, shard_id: str, consumer: ShardConsumer) -> None:
        """Start a consumer asynchronously."""
        try:
            await consumer.start()
        except Exception as e:
            self._logger.error(f"Error starting consumer for shard {shard_id}: {e}")
            self._shard_consumers.pop(shard_id, None)

            if isinstance(e, ProcessorInitializationException):
                self._logger.error(f"Processor initialization failed for shard {shard_id}")

    def _on_lease_lost(self, lease_key: str) -> None:
        """Handle lease lost event - stop the shard consumer."""
        consumer = self._shard_consumers.get(lease_key)
        if not consumer:
            return

        self._logger.info(f"Lost lease for shard {lease_key}, stopping consumer")

        # Notify the consumer of lease loss (async)
        asyncio.create_task(consumer.on_lease_lost())
        self._shard_consumers.pop(lease_key, None)

    def _start_shard_sync(self) -> None:
        """Start periodic shard synchronization."""

        async def sync_loop():
            while self._state == SchedulerState.RUNNING:
                await asyncio.sleep(30)  # Sync every 30 seconds
                if self._state != SchedulerState.RUNNING:
                    break
                if not self._shard_syncer:
                    continue
                try:
                    await self._shard_syncer.sync_shards()
                except Exception as e:
                    self._logger.error(f"Error during shard sync: {e}")

        self._shard_sync_task = asyncio.create_task(sync_loop())

    def _start_health_check(self) -> None:
        """Start periodic health checks."""

        async def health_check_loop():
            while self._state == SchedulerState.RUNNING:
                await asyncio.sleep(10)  # Health check every 10 seconds
                if self._state != SchedulerState.RUNNING:
                    break
                try:
                    self._perform_health_check()
                except Exception as e:
                    self._logger.error(f"Error during health check: {e}")

        self._health_check_task = asyncio.create_task(health_check_loop())

    def _perform_health_check(self) -> None:
        """Perform a health check on all consumers."""
        if not self._lease_coordinator:
            return

        owned_leases = self._lease_coordinator.get_owned_leases()

        for lease_key, lease in owned_leases.items():
            # Track completed shards
            if lease.checkpoint and lease.checkpoint.sequence_number == CHECKPOINT_SENTINEL.SHARD_END:
                continue

            consumer = self._shard_consumers.get(lease_key)

            if not consumer:
                # Consumer doesn't exist, create it
                self._logger.info(f"Health check: Creating missing consumer for shard {lease_key}")
                self._on_lease_acquired(lease)

            elif consumer.get_state() in [ShardConsumerState.SHUTDOWN_COMPLETE, ShardConsumerState.SHUTDOWN_FAILED]:
                shutdown_reason = consumer.get_shutdown_reason()
                self._logger.info(
                    f"Health check: Consumer for shard {lease_key} is "
                    f"{consumer.get_state()} (reason: {shutdown_reason})"
                )

                self._shard_consumers.pop(lease_key, None)

                # Don't recreate if it was due to failures or shard end
                if shutdown_reason not in [ShutdownReason.ZOMBIE, ShutdownReason.SHARD_END]:
                    self._on_lease_acquired(lease)

        # Check for consumers that shouldn't be running
        for lease_key, consumer in list(self._shard_consumers.items()):
            if lease_key not in owned_leases:
                self._logger.info(f"Health check: Stopping orphaned consumer for shard {lease_key}")
                asyncio.create_task(consumer.on_lease_lost())
                self._shard_consumers.pop(lease_key, None)

    def _start_metrics_publishing(self) -> None:
        """Start periodic metrics publishing."""
        if not self._metrics_factory.is_enabled():
            return

        async def metrics_loop():
            while self._state == SchedulerState.RUNNING:
                await asyncio.sleep(self.METRICS_INTERVAL_MS / 1000)
                if self._state != SchedulerState.RUNNING:
                    break
                self._publish_scheduler_metrics()

        self._metrics_task = asyncio.create_task(metrics_loop())

    def _publish_scheduler_metrics(self) -> None:
        """Publish scheduler-level metrics."""
        if not self._metrics_factory.is_enabled():
            return

        scope = self._metrics_factory.create_scope("Scheduler")

        try:
            owned_leases = self._lease_coordinator.get_owned_leases() if self._lease_coordinator else {}
            active_shards = len(owned_leases)

            scope.add_count(KCLMetrics.CURRENT_SHARDS, active_shards)
            scope.add_count(KCLMetrics.CURRENT_LEASES, active_shards)
            scope.add_count(KCLMetrics.ACTIVE_WORKERS, len(self._shard_consumers))

        finally:
            scope.end()

    def _stop_periodic_tasks(self) -> None:
        """Stop all periodic tasks."""
        for task in [self._shard_sync_task, self._health_check_task, self._metrics_task]:
            if task:
                task.cancel()

    async def _stop_all_consumers(self) -> None:
        """Stop all shard consumers with timeout."""
        stop_tasks = []
        timeout = self._config["lifecycle"]["task_execution_timeout_millis"] / 1000

        for shard_id, consumer in self._shard_consumers.items():
            self._logger.info(f"Stopping consumer for shard {shard_id}")
            stop_tasks.append(consumer.stop())

        if stop_tasks:
            try:
                await asyncio.wait_for(
                    asyncio.gather(*stop_tasks, return_exceptions=True),
                    timeout=timeout,
                )
            except asyncio.TimeoutError:
                self._logger.warning("Timeout stopping consumers")

        self._shard_consumers.clear()

    async def _cleanup_on_error(self) -> None:
        """Clean up on error during initialization."""
        self._stop_periodic_tasks()

        # Stop any consumers that were started
        for shard_id, consumer in list(self._shard_consumers.items()):
            try:
                await consumer.stop()
            except Exception as e:
                self._logger.warning(f"Error stopping consumer during cleanup: {e}")

        self._shard_consumers.clear()

        # Stop lease coordinator
        if self._lease_coordinator:
            try:
                await self._lease_coordinator.stop()
            except Exception as e:
                self._logger.warning(f"Error stopping lease coordinator during cleanup: {e}")

    def _resolve_config(self, config: KinesisConsumerConfig) -> dict:
        """Resolve the configuration with defaults."""
        worker_identifier = config.worker_identifier or f"{socket.gethostname()}-{uuid.uuid4()}"

        initial_position = config.initial_position_in_stream or InitialPositionInStreamExtended(
            initial_position_in_stream=InitialPositionInStream.TRIM_HORIZON
        )

        retrieval_defaults = DEFAULT_CONFIG["retrieval"]
        checkpoint_defaults = DEFAULT_CONFIG["checkpoint"]
        coordinator_defaults = DEFAULT_CONFIG["coordinator"]
        lifecycle_defaults = DEFAULT_CONFIG["lifecycle"]

        return {
            "aws": {
                "region": config.aws.region,
                "credentials": config.aws.credentials,
                "kinesis_endpoint": config.aws.kinesis_endpoint,
                "dynamodb_endpoint": config.aws.dynamodb_endpoint,
                "cloudwatch_endpoint": config.aws.cloudwatch_endpoint,
            },
            "application_name": config.application_name,
            "stream_name": config.stream_name,
            "worker_identifier": worker_identifier,
            "initial_position_in_stream": initial_position,
            "retrieval": {
                "stream_name": config.stream_name,
                "max_records": (
                    config.retrieval.max_records if config.retrieval else retrieval_defaults["max_records"]
                ),
                "idle_time_between_reads_millis": (
                    config.retrieval.idle_time_between_reads_millis
                    if config.retrieval
                    else retrieval_defaults["idle_time_between_reads_millis"]
                ),
            },
            "checkpoint": {
                "call_process_records_even_for_empty_record_list": (
                    config.checkpoint.call_process_records_even_for_empty_record_list
                    if config.checkpoint
                    else checkpoint_defaults["call_process_records_even_for_empty_record_list"]
                ),
                "skip_checkpoint_validation_on_shard_end": (
                    config.checkpoint.skip_checkpoint_validation_on_shard_end
                    if config.checkpoint
                    else checkpoint_defaults["skip_checkpoint_validation_on_shard_end"]
                ),
                "always_start_from_latest": (
                    config.checkpoint.always_start_from_latest
                    if config.checkpoint
                    else checkpoint_defaults["always_start_from_latest"]
                ),
                "skip_checkpoint_operations": (
                    config.checkpoint.skip_checkpoint_operations
                    if config.checkpoint
                    else checkpoint_defaults["skip_checkpoint_operations"]
                ),
            },
            "coordinator": {
                "lease_duration_millis": (
                    config.coordinator.lease_duration_millis
                    if config.coordinator
                    else coordinator_defaults["lease_duration_millis"]
                ),
                "epsilon_millis": (
                    config.coordinator.epsilon_millis if config.coordinator else coordinator_defaults["epsilon_millis"]
                ),
                "max_leases_for_worker": (
                    config.coordinator.max_leases_for_worker
                    if config.coordinator
                    else coordinator_defaults["max_leases_for_worker"]
                ),
                "max_leases_to_steal_at_one_time": (
                    config.coordinator.max_leases_to_steal_at_one_time
                    if config.coordinator
                    else coordinator_defaults["max_leases_to_steal_at_one_time"]
                ),
                "cleanup_leases_upon_shard_completion": (
                    config.coordinator.cleanup_leases_upon_shard_completion
                    if config.coordinator
                    else coordinator_defaults["cleanup_leases_upon_shard_completion"]
                ),
            },
            "lifecycle": {
                "log_warning_for_task_after_millis": (
                    config.lifecycle.log_warning_for_task_after_millis
                    if config.lifecycle
                    else lifecycle_defaults["log_warning_for_task_after_millis"]
                ),
                "task_execution_timeout_millis": (
                    config.lifecycle.task_execution_timeout_millis
                    if config.lifecycle
                    else lifecycle_defaults["task_execution_timeout_millis"]
                ),
                "max_consecutive_failures": (
                    config.lifecycle.max_consecutive_failures
                    if config.lifecycle
                    else lifecycle_defaults["max_consecutive_failures"]
                ),
            },
        }

    def get_state(self) -> SchedulerState:
        """Get the current state."""
        return self._state

    def get_active_consumer_count(self) -> int:
        """Get the number of active shard consumers."""
        return len(self._shard_consumers)

    def get_worker_identifier(self) -> str:
        """Get the worker identifier."""
        return self._config["worker_identifier"]

    def get_last_error(self) -> Exception | None:
        """Get the last error that occurred."""
        return self._last_error

    def get_consumer_states(self) -> dict[str, ShardConsumerState]:
        """Get consumer states for monitoring."""
        return {shard_id: consumer.get_state() for shard_id, consumer in self._shard_consumers.items()}
