"""Shard syncer for synchronizing shards with leases."""

import logging
from typing import TYPE_CHECKING

from ..types import (
    ExtendedSequenceNumber,
    InitialPositionInStream,
    InitialPositionInStreamExtended,
    Lease,
)

if TYPE_CHECKING:
    from ..leases import LeaseCoordinator
    from .shard_detector import ShardDetector


class CHECKPOINT_SENTINEL:
    """Special checkpoint values."""

    TRIM_HORIZON = "TRIM_HORIZON"
    """Indicates processing should start at TRIM_HORIZON"""

    LATEST = "LATEST"
    """Indicates processing should start at LATEST"""

    AT_TIMESTAMP = "AT_TIMESTAMP"
    """Indicates processing should start at a specific timestamp"""

    SHARD_END = "SHARD_END"
    """Indicates the shard has been fully processed"""


class ShardSyncer:
    """Responsible for synchronizing shards with leases.

    Creates leases for new shards and cleans up leases for completed shards.
    Handles resharding scenarios (shard splits and merges).
    """

    _logger = logging.getLogger("kcl.ShardSyncer")

    def __init__(
        self,
        shard_detector: "ShardDetector",
        lease_coordinator: "LeaseCoordinator",
        initial_position: InitialPositionInStreamExtended,
        cleanup_leases_upon_shard_completion: bool = True,
        ignore_unexpected_child_shards: bool = False,
    ):
        """Initialize the shard syncer.

        Args:
            shard_detector: The shard detector
            lease_coordinator: The lease coordinator
            initial_position: Initial position for new shards
            cleanup_leases_upon_shard_completion: Whether to cleanup completed leases
            ignore_unexpected_child_shards: Whether to ignore unexpected child shards
        """
        self._shard_detector = shard_detector
        self._lease_coordinator = lease_coordinator
        self._initial_position = initial_position
        self._cleanup_leases_upon_shard_completion = cleanup_leases_upon_shard_completion
        self._ignore_unexpected_child_shards = ignore_unexpected_child_shards
        self._is_first_sync = True

    async def sync_shards(self) -> None:
        """Synchronize shards with leases.

        - Creates leases for new shards
        - Handles resharding scenarios (shard splits and merges)
        - Optionally cleans up leases for completed shards

        Resharding handling:
        - SPLIT: One parent shard becomes two child shards. Both children reference the parent.
          Children can only be processed after parent reaches SHARD_END.
        - MERGE: Two parent shards become one child shard. Child references both parents
          (parentShardId and adjacentParentShardId). Child can only be processed after
          BOTH parents reach SHARD_END.
        """
        # Get current shards from Kinesis
        shards = await self._shard_detector.list_shards()
        shard_ids = {s.shard_id for s in shards}

        # Get current leases
        leases = await self._lease_coordinator.list_leases()
        lease_map = {lease.lease_key: lease for lease in leases}

        # Log shard summary on startup
        if self._is_first_sync:
            self._is_first_sync = False
            open_shards = [s for s in shards if not s.sequence_number_range.ending_sequence_number]
            closed_shards = [s for s in shards if s.sequence_number_range.ending_sequence_number]

            self._logger.info("╔══════════════════════════════════════════════════════════════════╗")
            self._logger.info("║                    STREAM SHARD SUMMARY                          ║")
            self._logger.info("╠══════════════════════════════════════════════════════════════════╣")
            self._logger.info(f"║ Total shards discovered: {len(shards):<41}║")
            self._logger.info(f"║   - Open (active) shards: {len(open_shards):<40}║")
            self._logger.info(f"║   - Closed (ended) shards: {len(closed_shards):<39}║")
            self._logger.info(f"║ Existing leases in DynamoDB: {len(leases):<37}║")
            self._logger.info("╚══════════════════════════════════════════════════════════════════╝")

        # Find completed shards (checkpoint at SHARD_END)
        completed_shards: set[str] = set()
        for lease in leases:
            if lease.checkpoint and lease.checkpoint.sequence_number == CHECKPOINT_SENTINEL.SHARD_END:
                completed_shards.add(lease.lease_key)

        # Track shards that need leases created
        shards_needing_leases = []
        shards_waiting_for_parents = []

        # Build a set of all known shard IDs
        all_known_shard_ids = shard_ids | set(lease_map.keys())

        # First pass: categorize shards
        for shard in shards:
            if shard.shard_id in lease_map:
                # Lease already exists
                continue

            # Get all parent shards
            parent_shards = self._shard_detector.get_parent_shard_ids(shard.shard_id)

            if not parent_shards:
                # No parents - this is an original shard
                shards_needing_leases.append(shard)
            else:
                # Check if ALL parents are complete or don't exist anymore
                all_parents_complete = all(
                    parent_id in completed_shards or parent_id not in all_known_shard_ids for parent_id in parent_shards
                )

                if all_parents_complete:
                    shards_needing_leases.append(shard)
                elif not self._ignore_unexpected_child_shards:
                    shards_waiting_for_parents.append(shard)
                else:
                    shards_needing_leases.append(shard)

        # Log resharding status
        if shards_waiting_for_parents:
            open_shards = [s for s in shards if not s.sequence_number_range.ending_sequence_number]
            closed_shards = [s for s in shards if s.sequence_number_range.ending_sequence_number]
            child_shards = [s for s in shards if s.parent_shard_id or s.adjacent_parent_shard_id]

            self._logger.info("╔══════════════════════════════════════════════════════════════════╗")
            self._logger.info("║                    RESHARDING IN PROGRESS                        ║")
            self._logger.info("╠══════════════════════════════════════════════════════════════════╣")
            self._logger.info("║ Stream Status:                                                   ║")
            self._logger.info("║   - Total shards: %-47s║", len(shards))
            self._logger.info("║   - Open (active) shards: %-40s║", len(open_shards))
            self._logger.info("║   - Closed (ended) shards: %-39s║", len(closed_shards))
            self._logger.info("║   - Child shards (from split/merge): %-28s║", len(child_shards))
            self._logger.info("║   - Completed parent shards: %-37s║", len(completed_shards))
            self._logger.info("╠══════════════════════════════════════════════════════════════════╣")
            self._logger.info("║ Child Shards Waiting for Parents:                                ║")

            for shard in shards_waiting_for_parents:
                parents = self._shard_detector.get_parent_shard_ids(shard.shard_id)
                incomplete_parents = [p for p in parents if p not in completed_shards]
                reshard_type = "MERGE" if len(parents) == 2 else "SPLIT"
                shard_info = f"{shard.shard_id} ({reshard_type})"
                padding = " " * max(0, 60 - len(shard_info) - 4)
                self._logger.info("║   • %s%s║", shard_info, padding)
                waiting_for = ", ".join(incomplete_parents)
                padding2 = " " * max(0, 44 - len(waiting_for))
                self._logger.info("║     - Waiting for: %s%s║", waiting_for, padding2)

            self._logger.info("╚══════════════════════════════════════════════════════════════════╝")

        # Create leases for shards that are ready
        for shard in shards_needing_leases:
            parent_shards = self._shard_detector.get_parent_shard_ids(shard.shard_id)
            lease = self._create_lease_for_shard(shard.shard_id, parent_shards)

            created = await self._lease_coordinator.create_lease(lease)
            if created:
                if parent_shards:
                    reshard_type = "MERGE" if len(parent_shards) == 2 else "SPLIT"
                    self._logger.info("╔══════════════════════════════════════════════════════════════════╗")
                    self._logger.info("║              RESHARDING: NEW CHILD SHARD READY                   ║")
                    self._logger.info("╠══════════════════════════════════════════════════════════════════╣")
                    self._logger.info(f"║ Resharding Type: {reshard_type:<49}║")
                    self._logger.info(f"║ New Child Shard: {shard.shard_id:<49}║")
                    self._logger.info(f"║ Parent Shard(s): {', '.join(parent_shards):<49}║")
                    self._logger.info("║ Status: All parent shards completed - child shard now active     ║")
                    self._logger.info("╚══════════════════════════════════════════════════════════════════╝")
                else:
                    self._logger.info(f"Created lease for new shard {shard.shard_id} (original shard, no parents)")

        # Clean up leases for completed shards (if enabled)
        if self._cleanup_leases_upon_shard_completion:
            await self._cleanup_completed_leases(leases, shard_ids)

    def _create_lease_for_shard(
        self,
        shard_id: str,
        parent_shard_ids: list[str],
    ) -> Lease:
        """Create a lease for a new shard.

        Args:
            shard_id: The shard ID
            parent_shard_ids: Parent shard IDs

        Returns:
            A new Lease object
        """
        checkpoint = self._get_initial_checkpoint()

        lease = Lease(
            lease_key=shard_id,
            lease_counter=0,
            checkpoint=ExtendedSequenceNumber(
                sequence_number=checkpoint,
                sub_sequence_number=0,
            ),
            owner_switches_since_checkpoint=0,
        )

        if parent_shard_ids:
            lease.parent_shard_ids = parent_shard_ids

        return lease

    def _get_initial_checkpoint(self) -> str:
        """Get the initial checkpoint based on configuration.

        Returns:
            The initial checkpoint sentinel value
        """
        if self._initial_position.initial_position_in_stream == InitialPositionInStream.TRIM_HORIZON:
            return CHECKPOINT_SENTINEL.TRIM_HORIZON
        elif self._initial_position.initial_position_in_stream == InitialPositionInStream.LATEST:
            return CHECKPOINT_SENTINEL.LATEST
        elif self._initial_position.initial_position_in_stream == InitialPositionInStream.AT_TIMESTAMP:
            return CHECKPOINT_SENTINEL.AT_TIMESTAMP
        else:
            return CHECKPOINT_SENTINEL.TRIM_HORIZON

    async def _cleanup_completed_leases(
        self,
        leases: list[Lease],
        current_shard_ids: set[str],
    ) -> None:
        """Clean up leases for shards that have been fully processed.

        Args:
            leases: All leases
            current_shard_ids: Set of current shard IDs
        """
        for lease in leases:
            # Only clean up leases that are at SHARD_END
            if not lease.checkpoint or lease.checkpoint.sequence_number != CHECKPOINT_SENTINEL.SHARD_END:
                continue

            # Check if any child shards reference this shard
            child_shards = self._shard_detector.get_child_shards(lease.lease_key)

            # Only delete if all child shards have been processed
            can_delete = True
            for child in child_shards:
                child_lease = self._lease_coordinator.get_lease(child.shard_id)
                if child_lease and (
                    not child_lease.checkpoint
                    or child_lease.checkpoint.sequence_number != CHECKPOINT_SENTINEL.SHARD_END
                ):
                    can_delete = False
                    break

            # Also check if the shard still exists in Kinesis
            if lease.lease_key not in current_shard_ids and can_delete:
                try:
                    deleted = await self._lease_coordinator.delete_lease(lease)
                    if deleted:
                        self._logger.info(f"Cleaned up completed lease for shard {lease.lease_key}")
                except Exception as e:
                    self._logger.warning(f"Failed to cleanup lease {lease.lease_key}: {e}")

    def is_shard_ready_for_processing(
        self,
        shard_id: str,
        completed_shards: set[str],
    ) -> bool:
        """Check if a shard is ready for processing.

        Args:
            shard_id: The shard ID
            completed_shards: Set of completed shard IDs

        Returns:
            True if the shard is ready for processing
        """
        return self._shard_detector.are_parent_shards_complete(shard_id, completed_shards)

    def get_shards_ready_for_processing(self, completed_shards: set[str]):
        """Get shards that are ready for processing.

        Args:
            completed_shards: Set of completed shard IDs

        Returns:
            List of shards ready for processing
        """
        return self._shard_detector.find_shards_ready_for_processing(completed_shards)
