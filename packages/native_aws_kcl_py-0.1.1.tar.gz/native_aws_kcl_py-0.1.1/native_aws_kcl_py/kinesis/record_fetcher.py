"""Record fetcher for fetching records from a Kinesis shard."""

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any

import aioboto3
from botocore.config import Config
from botocore.exceptions import ClientError

from ..exceptions import (
    ExpiredIteratorException,
    InvalidConfigurationException,
    KinesisException,
    KinesisInternalException,
    KinesisProvisionedThroughputExceededException,
    KinesisTimeoutException,
    ResourceNotFoundException,
)
from ..types import (
    ChildShard,
    HashKeyRange,
    InitialPositionInStream,
    InitialPositionInStreamExtended,
    KinesisClientRecord,
)
from ..utils import BackoffConfig, calculate_backoff_with_jitter
from .shard_syncer import CHECKPOINT_SENTINEL


@dataclass
class FetchRecordsResult:
    """Result of fetching records."""

    records: list[KinesisClientRecord] = field(default_factory=list)
    """The fetched records"""

    millis_behind_latest: int = 0
    """Milliseconds behind latest"""

    is_at_shard_end: bool = False
    """Whether we've reached the end of the shard"""

    child_shards: list[ChildShard] | None = None
    """Child shards if at shard end"""


class RecordFetcher:
    """Responsible for fetching records from a Kinesis shard.

    Based on the AWS KCL record fetcher implementation.
    Includes comprehensive error handling for all Kinesis exceptions.
    """

    _logger = logging.getLogger("kcl.RecordFetcher")

    MAX_RETRIES = 3
    BASE_DELAY_MS = 100
    MAX_DELAY_MS = 5000
    MAX_CONSECUTIVE_EMPTY_RESPONSES = 1000

    def __init__(
        self,
        stream_name: str,
        shard_id: str,
        region_name: str = "eu-west-1",
        endpoint_url: str | None = None,
        max_records: int = 10000,
        initial_position: InitialPositionInStreamExtended | None = None,
    ):
        """Initialize the record fetcher.

        Args:
            stream_name: The Kinesis stream name
            shard_id: The shard ID to fetch from
            region_name: AWS region name
            endpoint_url: Optional custom endpoint URL
            max_records: Maximum records per GetRecords call
            initial_position: Initial position for new shards
        """
        self._stream_name = stream_name
        self._shard_id = shard_id
        self._region_name = region_name
        self._endpoint_url = endpoint_url
        self._max_records = max_records
        self._initial_position = initial_position or InitialPositionInStreamExtended(
            initial_position_in_stream=InitialPositionInStream.TRIM_HORIZON
        )
        self._session = aioboto3.Session()
        self._config = Config(retries={"max_attempts": 3, "mode": "standard"})

        self._shard_iterator: str | None = None
        self._is_shard_end = False
        self._last_checkpoint: str | None = None
        self._consecutive_empty_responses = 0

    async def _get_client(self):
        """Get a Kinesis client context manager."""
        return self._session.client(
            "kinesis",
            region_name=self._region_name,
            endpoint_url=self._endpoint_url,
            config=self._config,
        )

    async def initialize(self, checkpoint: str | None = None) -> None:
        """Initialize the record fetcher with a starting position.

        Args:
            checkpoint: Optional checkpoint to resume from
        """
        self._last_checkpoint = checkpoint
        self._is_shard_end = False
        self._consecutive_empty_responses = 0
        self._shard_iterator = await self._get_shard_iterator_with_retry(checkpoint)

    async def fetch_records(self) -> FetchRecordsResult:
        """Fetch the next batch of records.

        Returns:
            FetchRecordsResult with records and metadata

        Raises:
            ExpiredIteratorException: If the shard iterator expires
            KinesisProvisionedThroughputExceededException: If throughput exceeded
            ResourceNotFoundException: If stream/shard doesn't exist
            KinesisException: For other Kinesis errors
        """
        if self._is_shard_end:
            return FetchRecordsResult(is_at_shard_end=True)

        if not self._shard_iterator:
            raise KinesisException(
                f"RecordFetcher not initialized for shard {self._shard_id}",
                retryable=False,
            )

        try:
            async with await self._get_client() as client:  # type: ignore[attr-defined]
                response = await client.get_records(
                    ShardIterator=self._shard_iterator,
                    Limit=self._max_records,
                )

            # Update the shard iterator for the next call
            self._shard_iterator = response.get("NextShardIterator")

            # Check if we've reached the end of the shard
            if not self._shard_iterator:
                self._is_shard_end = True
                self._logger.info(
                    f"[RESHARDING] Shard {self._shard_id} has reached its end - "
                    "no more records will be available from this shard"
                )

            # Track empty responses
            raw_records = response.get("Records", [])
            if not raw_records:
                self._consecutive_empty_responses += 1
                if self._consecutive_empty_responses > self.MAX_CONSECUTIVE_EMPTY_RESPONSES:
                    self._logger.debug(
                        f"Received {self._consecutive_empty_responses} consecutive empty "
                        f"responses for shard {self._shard_id}"
                    )
            else:
                self._consecutive_empty_responses = 0

            # Convert AWS SDK records to our record type
            records = []
            for record in raw_records:
                records.append(
                    KinesisClientRecord(
                        sequence_number=record["SequenceNumber"],
                        partition_key=record["PartitionKey"],
                        data=record["Data"],
                        approximate_arrival_timestamp=record.get("ApproximateArrivalTimestamp"),
                        encryption_type=record.get("EncryptionType"),
                    )
                )

            # Extract child shards if at shard end
            child_shards = None
            if response.get("ChildShards"):
                child_shards = []
                for child in response["ChildShards"]:
                    hash_key_range = child.get("HashKeyRange", {})
                    child_shards.append(
                        ChildShard(
                            shard_id=child["ShardId"],
                            parent_shards=child.get("ParentShards", []),
                            hash_key_range=HashKeyRange(
                                starting_hash_key=hash_key_range.get("StartingHashKey", "0"),
                                ending_hash_key=hash_key_range.get("EndingHashKey", "0"),
                            ),
                        )
                    )

                # Log resharding information
                reshard_type = (
                    "SPLIT"
                    if len(child_shards) == 2
                    else ("MERGE" if child_shards and len(child_shards[0].parent_shards) == 2 else "UNKNOWN")
                )
                self._logger.info(f"[RESHARDING] Detected {reshard_type} operation for shard {self._shard_id}")
                self._logger.info(f"[RESHARDING] Parent shard {self._shard_id} has {len(child_shards)} child shard(s):")
                for child in child_shards:
                    self._logger.info(
                        f"[RESHARDING]   → Child: {child.shard_id} " f"(parents: {', '.join(child.parent_shards)})"
                    )

            return FetchRecordsResult(
                records=records,
                millis_behind_latest=response.get("MillisBehindLatest", 0),
                is_at_shard_end=self._is_shard_end,
                child_shards=child_shards,
            )

        except ClientError as e:
            return await self._handle_fetch_error(e)

    async def _handle_fetch_error(self, error: ClientError) -> FetchRecordsResult:
        """Handle errors during record fetching.

        Args:
            error: The ClientError from AWS SDK

        Returns:
            FetchRecordsResult if recovered

        Raises:
            Various KinesisException subclasses
        """
        error_code = error.response.get("Error", {}).get("Code", "")
        error_message = str(error)

        # Handle expired iterator - auto-recover
        if error_code == "ExpiredIteratorException":
            self._logger.warning(f"Shard iterator expired for shard {self._shard_id}, re-initializing")
            try:
                self._shard_iterator = await self._get_shard_iterator_with_retry(self._last_checkpoint)
                return await self.fetch_records()
            except Exception as reinit_error:
                raise ExpiredIteratorException(
                    f"Failed to re-initialize after expired iterator for shard {self._shard_id}: {reinit_error}",
                    self._shard_id,
                    reinit_error,
                )

        # Handle provisioned throughput exceeded
        if error_code == "ProvisionedThroughputExceededException":
            self._logger.warning(f"Provisioned throughput exceeded for shard {self._shard_id}")
            raise KinesisProvisionedThroughputExceededException(
                f"Provisioned throughput exceeded for shard {self._shard_id}",
                self._shard_id,
                1000,
                error,
            )

        # Handle resource not found
        if error_code == "ResourceNotFoundException":
            raise ResourceNotFoundException(
                f"Stream or shard not found: {self._stream_name}/{self._shard_id}",
                f"{self._stream_name}/{self._shard_id}",
                error,
            )

        # Handle access denied
        if error_code == "AccessDeniedException":
            raise KinesisException(
                f"Access denied for shard {self._shard_id}: {error_message}",
                retryable=False,
                cause=error,
            )

        # Handle invalid argument
        if error_code == "InvalidArgumentException":
            raise InvalidConfigurationException(
                f"Invalid argument for shard {self._shard_id}: {error_message}",
                "shardIterator",
                cause=error,
            )

        # Handle timeout errors
        if "timeout" in error_message.lower() or "timed out" in error_message.lower():
            raise KinesisTimeoutException(
                f"Timeout fetching records for shard {self._shard_id}",
                error,
            )

        # Handle internal errors
        if error_code in ["InternalFailure", "ServiceUnavailable", "InternalServerError"]:
            raise KinesisInternalException(
                f"Internal Kinesis error for shard {self._shard_id}: {error_message}",
                error,
            )

        # Generic error
        retryable = error_code in [
            "ProvisionedThroughputExceededException",
            "ThrottlingException",
            "RequestLimitExceeded",
            "InternalServerError",
            "ServiceUnavailable",
        ]
        raise KinesisException(
            f"Error fetching records for shard {self._shard_id}: {error_message}",
            retryable=retryable,
            cause=error,
        )

    async def _get_shard_iterator_with_retry(self, checkpoint: str | None = None) -> str:
        """Get a shard iterator with retry logic.

        Args:
            checkpoint: Optional checkpoint to resume from

        Returns:
            The shard iterator
        """
        last_error = None

        for attempt in range(self.MAX_RETRIES):
            try:
                return await self._get_shard_iterator(checkpoint)
            except Exception as error:
                last_error = error

                # Don't retry non-retryable errors
                if isinstance(error, ClientError):
                    error_code = error.response.get("Error", {}).get("Code", "")
                    if error_code not in [
                        "ProvisionedThroughputExceededException",
                        "ThrottlingException",
                        "RequestLimitExceeded",
                        "InternalServerError",
                    ]:
                        raise

                # Exponential backoff with jitter
                delay_ms = calculate_backoff_with_jitter(
                    attempt,
                    BackoffConfig(base_delay_ms=self.BASE_DELAY_MS, max_delay_ms=self.MAX_DELAY_MS),
                )
                self._logger.warning(
                    f"Failed to get shard iterator (attempt {attempt + 1}/{self.MAX_RETRIES}), "
                    f"retrying in {delay_ms}ms: {error}"
                )
                await asyncio.sleep(delay_ms / 1000)

        raise KinesisException(
            f"Failed to get shard iterator after {self.MAX_RETRIES} attempts for shard {self._shard_id}",
            retryable=False,
            cause=last_error,
        )

    async def _get_shard_iterator(self, checkpoint: str | None = None) -> str:
        """Get a shard iterator based on checkpoint or initial position.

        Args:
            checkpoint: Optional checkpoint to resume from

        Returns:
            The shard iterator
        """
        iterator_type: str
        starting_sequence_number: str | None = None
        timestamp = None

        if checkpoint:
            if checkpoint == CHECKPOINT_SENTINEL.TRIM_HORIZON:
                iterator_type = "TRIM_HORIZON"
            elif checkpoint == CHECKPOINT_SENTINEL.LATEST:
                iterator_type = "LATEST"
            elif checkpoint == CHECKPOINT_SENTINEL.AT_TIMESTAMP:
                iterator_type = "AT_TIMESTAMP"
                timestamp = self._initial_position.timestamp
            elif checkpoint == CHECKPOINT_SENTINEL.SHARD_END:
                # Shard is complete
                self._is_shard_end = True
                iterator_type = "LATEST"
            else:
                # It's an actual sequence number - start after it
                iterator_type = "AFTER_SEQUENCE_NUMBER"
                starting_sequence_number = checkpoint
        else:
            # Use initial position from config
            pos = self._initial_position.initial_position_in_stream
            if pos == InitialPositionInStream.TRIM_HORIZON:
                iterator_type = "TRIM_HORIZON"
            elif pos == InitialPositionInStream.LATEST:
                iterator_type = "LATEST"
            elif pos == InitialPositionInStream.AT_TIMESTAMP:
                iterator_type = "AT_TIMESTAMP"
                timestamp = self._initial_position.timestamp
            else:
                iterator_type = "TRIM_HORIZON"

        try:
            async with await self._get_client() as client:  # type: ignore[attr-defined]
                params: dict[str, Any] = {
                    "StreamName": self._stream_name,
                    "ShardId": self._shard_id,
                    "ShardIteratorType": iterator_type,
                }
                if starting_sequence_number:
                    params["StartingSequenceNumber"] = starting_sequence_number
                if timestamp:
                    params["Timestamp"] = timestamp

                response = await client.get_shard_iterator(**params)

            if not response.get("ShardIterator"):
                raise KinesisException(
                    f"No shard iterator returned for shard {self._shard_id}",
                    retryable=True,
                )

            return response["ShardIterator"]

        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            if error_code == "ResourceNotFoundException":
                raise ResourceNotFoundException(
                    f"Stream or shard not found: {self._stream_name}/{self._shard_id}",
                    f"{self._stream_name}/{self._shard_id}",
                    e,
                )
            raise

    async def seek_to(self, sequence_number: str) -> None:
        """Reset the fetcher to a specific position.

        Args:
            sequence_number: The sequence number to seek to
        """
        self._is_shard_end = False
        self._consecutive_empty_responses = 0
        self._last_checkpoint = sequence_number
        self._shard_iterator = await self._get_shard_iterator_with_retry(sequence_number)

    def is_at_shard_end(self) -> bool:
        """Check if we've reached the end of the shard.

        Returns:
            True if at shard end
        """
        return self._is_shard_end

    def get_shard_id(self) -> str:
        """Get the shard ID.

        Returns:
            The shard ID
        """
        return self._shard_id

    def get_stream_name(self) -> str:
        """Get the stream name.

        Returns:
            The stream name
        """
        return self._stream_name

    async def close(self) -> None:
        """Close the record fetcher."""
        self._shard_iterator = None
