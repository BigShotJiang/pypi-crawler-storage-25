"""Kinesis components for the Consumer Library."""

from .efo_record_fetcher import EFORecordFetcher, EFORecordFetcherConfig
from .record_fetcher import FetchRecordsResult, RecordFetcher
from .record_fetcher_factory import (
    IRecordFetcher,
    RecordFetcherFactory,
    RecordFetcherFactoryConfig,
    RetrievalMode,
)
from .shard_detector import ShardDetector
from .shard_syncer import CHECKPOINT_SENTINEL, ShardSyncer

__all__ = [
    # Shard management
    "ShardDetector",
    "ShardSyncer",
    "CHECKPOINT_SENTINEL",
    # Polling record fetcher
    "RecordFetcher",
    "FetchRecordsResult",
    # Enhanced Fan-Out record fetcher
    "EFORecordFetcher",
    "EFORecordFetcherConfig",
    # Record fetcher factory
    "RecordFetcherFactory",
    "RecordFetcherFactoryConfig",
    "RetrievalMode",
    "IRecordFetcher",
]
