"""Shard detector for discovering shards in a Kinesis stream."""

import asyncio
import logging

import aioboto3
from botocore.config import Config
from botocore.exceptions import ClientError

from ..exceptions import KinesisException, ResourceNotFoundException
from ..types import ChildShard, HashKeyRange, SequenceNumberRange, Shard
from ..utils import BackoffConfig, calculate_backoff_with_jitter


class ShardDetector:
    """Responsible for detecting shards in a Kinesis stream.

    Handles shard discovery and provides utilities for understanding
    shard hierarchy (parent/child relationships for resharding).
    """

    _logger = logging.getLogger("kcl.ShardDetector")

    def __init__(
        self,
        stream_name: str,
        region_name: str = "eu-west-1",
        endpoint_url: str | None = None,
        list_shards_backoff_time_millis: int = 1000,
        max_list_shards_retry_attempts: int = 5,
    ):
        """Initialize the shard detector.

        Args:
            stream_name: The name of the Kinesis stream
            region_name: AWS region name
            endpoint_url: Optional custom endpoint URL
            list_shards_backoff_time_millis: Backoff time for retries
            max_list_shards_retry_attempts: Maximum retry attempts
        """
        self._stream_name = stream_name
        self._region_name = region_name
        self._endpoint_url = endpoint_url
        self._list_shards_backoff_time_millis = list_shards_backoff_time_millis
        self._max_list_shards_retry_attempts = max_list_shards_retry_attempts
        self._session = aioboto3.Session()
        self._config = Config(retries={"max_attempts": 3, "mode": "standard"})

        # Cache of shards
        self._shards: dict[str, Shard] = {}
        self._child_shards: dict[str, list[ChildShard]] = {}
        self._initialized = False

    async def _get_client(self):
        """Get a Kinesis client context manager."""
        return self._session.client(
            "kinesis",
            region_name=self._region_name,
            endpoint_url=self._endpoint_url,
            config=self._config,
        )

    async def initialize(self) -> None:
        """Initialize the shard detector by listing all shards."""
        await self.list_shards()
        self._initialized = True
        self._logger.info(f"ShardDetector initialized with {len(self._shards)} shards")

    async def list_shards(self) -> list[Shard]:
        """List all shards in the stream.

        Returns:
            List of shards
        """
        shards: list[Shard] = []
        next_token = None
        attempt = 0

        while True:
            try:
                async with await self._get_client() as client:  # type: ignore[attr-defined]
                    params = {"StreamName": self._stream_name}
                    if next_token:
                        params = {"NextToken": next_token}
                    else:
                        params = {"StreamName": self._stream_name}

                    response = await client.list_shards(**params)

                    for shard_data in response.get("Shards", []):
                        shard = self._parse_shard(shard_data)
                        shards.append(shard)
                        self._shards[shard.shard_id] = shard

                        # Track child shard relationships
                        if shard.parent_shard_id:
                            if shard.parent_shard_id not in self._child_shards:
                                self._child_shards[shard.parent_shard_id] = []
                            self._child_shards[shard.parent_shard_id].append(
                                ChildShard(
                                    shard_id=shard.shard_id,
                                    parent_shards=[shard.parent_shard_id],
                                    hash_key_range=shard.hash_key_range,
                                )
                            )

                        if shard.adjacent_parent_shard_id:
                            if shard.adjacent_parent_shard_id not in self._child_shards:
                                self._child_shards[shard.adjacent_parent_shard_id] = []
                            self._child_shards[shard.adjacent_parent_shard_id].append(
                                ChildShard(
                                    shard_id=shard.shard_id,
                                    parent_shards=[shard.parent_shard_id or "", shard.adjacent_parent_shard_id],
                                    hash_key_range=shard.hash_key_range,
                                )
                            )

                    next_token = response.get("NextToken")
                    if not next_token:
                        break

                    attempt = 0  # Reset on success

            except ClientError as e:
                error_code = e.response.get("Error", {}).get("Code", "")
                if error_code == "ResourceNotFoundException":
                    raise ResourceNotFoundException(
                        f"Stream not found: {self._stream_name}",
                        self._stream_name,
                        e,
                    )
                if error_code in ["LimitExceededException", "ProvisionedThroughputExceededException"]:
                    attempt += 1
                    if attempt >= self._max_list_shards_retry_attempts:
                        raise KinesisException(
                            f"Failed to list shards after {attempt} attempts",
                            True,
                            e,
                        )
                    backoff = calculate_backoff_with_jitter(
                        attempt,
                        BackoffConfig(base_delay_ms=self._list_shards_backoff_time_millis),
                    )
                    self._logger.warning(f"ListShards throttled, retrying in {backoff}ms")
                    await asyncio.sleep(backoff / 1000)
                    continue
                raise KinesisException(f"Error listing shards: {e}", False, e)

        return shards

    def get_shard(self, shard_id: str) -> Shard | None:
        """Get a specific shard by ID.

        Args:
            shard_id: The shard ID

        Returns:
            The shard if found, None otherwise
        """
        return self._shards.get(shard_id)

    def get_child_shards(self, parent_shard_id: str) -> list[ChildShard]:
        """Get child shards for a parent shard.

        Args:
            parent_shard_id: The parent shard ID

        Returns:
            List of child shards
        """
        return self._child_shards.get(parent_shard_id, [])

    def get_parent_shard_ids(self, shard_id: str) -> list[str]:
        """Get parent shard IDs for a shard.

        Args:
            shard_id: The shard ID

        Returns:
            List of parent shard IDs
        """
        shard = self._shards.get(shard_id)
        if not shard:
            return []

        parents = []
        if shard.parent_shard_id:
            parents.append(shard.parent_shard_id)
        if shard.adjacent_parent_shard_id:
            parents.append(shard.adjacent_parent_shard_id)

        return parents

    def are_parent_shards_complete(
        self,
        shard_id: str,
        completed_shards: set[str],
    ) -> bool:
        """Check if all parent shards are complete.

        Args:
            shard_id: The shard ID to check
            completed_shards: Set of completed shard IDs

        Returns:
            True if all parents are complete or there are no parents
        """
        parent_ids = self.get_parent_shard_ids(shard_id)
        if not parent_ids:
            return True

        return all(parent_id in completed_shards for parent_id in parent_ids)

    def find_shards_ready_for_processing(
        self,
        completed_shards: set[str],
    ) -> list[Shard]:
        """Find shards that are ready for processing.

        A shard is ready if all its parent shards have been completed.

        Args:
            completed_shards: Set of completed shard IDs

        Returns:
            List of shards ready for processing
        """
        ready_shards = []

        for shard in self._shards.values():
            # Skip if already completed
            if shard.shard_id in completed_shards:
                continue

            # Check if all parents are complete
            if self.are_parent_shards_complete(shard.shard_id, completed_shards):
                ready_shards.append(shard)

        return ready_shards

    def _parse_shard(self, shard_data: dict) -> Shard:
        """Parse a shard from AWS SDK response.

        Args:
            shard_data: The shard data from AWS

        Returns:
            A Shard object
        """
        hash_key_range = shard_data.get("HashKeyRange", {})
        sequence_number_range = shard_data.get("SequenceNumberRange", {})

        return Shard(
            shard_id=shard_data["ShardId"],
            hash_key_range=HashKeyRange(
                starting_hash_key=hash_key_range.get("StartingHashKey", "0"),
                ending_hash_key=hash_key_range.get("EndingHashKey", "0"),
            ),
            sequence_number_range=SequenceNumberRange(
                starting_sequence_number=sequence_number_range.get("StartingSequenceNumber", "0"),
                ending_sequence_number=sequence_number_range.get("EndingSequenceNumber"),
            ),
            parent_shard_id=shard_data.get("ParentShardId"),
            adjacent_parent_shard_id=shard_data.get("AdjacentParentShardId"),
        )
