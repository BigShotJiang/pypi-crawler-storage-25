"""Factory for creating record fetchers based on retrieval mode.

Supports two modes:
1. POLLING (DEFAULT) - Uses GetRecords API with shared throughput
2. FANOUT - Uses SubscribeToShard API with dedicated throughput per consumer

Based on AWS KCL v2.7.2 retrieval configuration.
"""

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Any, Protocol

from ..exceptions import InvalidConfigurationException
from ..types import InitialPositionInStreamExtended
from .efo_record_fetcher import EFORecordFetcher, EFORecordFetcherConfig
from .record_fetcher import FetchRecordsResult, RecordFetcher


class RetrievalMode(str, Enum):
    """Retrieval mode for consuming records from Kinesis."""

    POLLING = "POLLING"
    """Default polling mode using GetRecords API.
    Shared throughput of 2 MB/s per shard across all consumers.
    """

    FANOUT = "FANOUT"
    """Enhanced Fan-Out mode using SubscribeToShard API.
    Dedicated throughput of 2 MB/s per consumer per shard.
    Lower latency (~70ms vs ~200ms+).
    """

    DEFAULT = "DEFAULT"
    """Same as POLLING - for backward compatibility with Java KCL config."""


class IRecordFetcher(Protocol):
    """Common interface for record fetchers (polling and EFO)."""

    async def initialize(self, checkpoint: str | None = None) -> None:
        """Initialize the fetcher with an optional checkpoint."""
        ...

    async def fetch_records(self) -> FetchRecordsResult:
        """Fetch the next batch of records."""
        ...

    async def seek_to(self, sequence_number: str) -> None:
        """Reset to a specific sequence number."""
        ...

    def is_at_shard_end(self) -> bool:
        """Check if at shard end."""
        ...

    def get_shard_id(self) -> str:
        """Get the shard ID."""
        ...

    async def close(self) -> None:
        """Close/cleanup the fetcher."""
        ...


@dataclass
class RecordFetcherFactoryConfig:
    """Configuration for creating record fetchers."""

    retrieval_mode: RetrievalMode
    """Retrieval mode (POLLING, FANOUT, or DEFAULT)"""

    stream_name: str
    """The Kinesis stream name"""

    max_records: int
    """Max records per fetch (for polling mode)"""

    initial_position: InitialPositionInStreamExtended
    """Initial position in stream"""

    region_name: str = "eu-west-1"
    """AWS region name"""

    endpoint_url: str | None = None
    """Optional custom endpoint URL (for LocalStack)"""

    stream_arn: str | None = None
    """The stream ARN (required for EFO)"""

    consumer_arn: str | None = None
    """The consumer ARN (required for EFO)"""

    idle_time_between_reads_millis: int = 1000
    """Idle time between reads in milliseconds (for polling mode)"""


class PollingFetcherWrapper:
    """Wrapper to make RecordFetcher implement IRecordFetcher interface."""

    def __init__(self, fetcher: RecordFetcher):
        self._fetcher = fetcher

    async def initialize(self, checkpoint: str | None = None) -> None:
        await self._fetcher.initialize(checkpoint)

    async def fetch_records(self) -> FetchRecordsResult:
        return await self._fetcher.fetch_records()

    async def seek_to(self, sequence_number: str) -> None:
        await self._fetcher.seek_to(sequence_number)

    def is_at_shard_end(self) -> bool:
        return self._fetcher.is_at_shard_end()

    def get_shard_id(self) -> str:
        return self._fetcher.get_shard_id()

    async def close(self) -> None:
        # Polling fetcher doesn't need cleanup
        pass


class RecordFetcherFactory:
    """Factory for creating record fetchers based on retrieval mode.

    Supports two modes:
    1. POLLING (DEFAULT) - Uses GetRecords API with shared throughput
    2. FANOUT - Uses SubscribeToShard API with dedicated throughput per consumer

    Based on AWS KCL v2.7.2 retrieval configuration.
    """

    _logger = logging.getLogger("kcl.RecordFetcherFactory")

    def __init__(self, config: RecordFetcherFactoryConfig, kinesis_client: Any | None = None):
        """Initialize the factory.

        Args:
            config: Factory configuration
            kinesis_client: Optional aioboto3 Kinesis client (required for EFO mode)
        """
        self._kinesis_client = kinesis_client
        self._config = config
        self._validate_config()

    def _validate_config(self) -> None:
        """Validate the configuration."""
        mode = self._config.retrieval_mode

        if mode == RetrievalMode.FANOUT:
            if not self._config.consumer_arn:
                raise InvalidConfigurationException(
                    "consumer_arn is required when using FANOUT retrieval mode",
                    "consumer_arn",
                )
            if not self._config.stream_arn:
                raise InvalidConfigurationException(
                    "stream_arn is required when using FANOUT retrieval mode",
                    "stream_arn",
                )
            if not self._kinesis_client:
                raise InvalidConfigurationException(
                    "kinesis_client is required when using FANOUT retrieval mode",
                    "kinesis_client",
                )

    def create_fetcher(self, shard_id: str) -> IRecordFetcher:
        """Create a record fetcher for a specific shard.

        Args:
            shard_id: The shard ID to fetch records from

        Returns:
            An IRecordFetcher implementation based on the retrieval mode
        """
        mode = self._config.retrieval_mode

        if mode == RetrievalMode.FANOUT:
            return self._create_efo_fetcher(shard_id)

        # Default to polling mode
        return self._create_polling_fetcher(shard_id)

    def _create_polling_fetcher(self, shard_id: str) -> IRecordFetcher:
        """Create a polling record fetcher.

        Args:
            shard_id: The shard ID

        Returns:
            Wrapped RecordFetcher
        """
        self._logger.debug(f"Creating polling fetcher for shard {shard_id}")

        fetcher = RecordFetcher(
            stream_name=self._config.stream_name,
            shard_id=shard_id,
            region_name=self._config.region_name,
            endpoint_url=self._config.endpoint_url,
            max_records=self._config.max_records,
            initial_position=self._config.initial_position,
        )

        return PollingFetcherWrapper(fetcher)

    def _create_efo_fetcher(self, shard_id: str) -> IRecordFetcher:
        """Create an Enhanced Fan-Out record fetcher.

        Args:
            shard_id: The shard ID

        Returns:
            EFORecordFetcher
        """
        self._logger.debug(f"Creating EFO fetcher for shard {shard_id}")

        efo_config = EFORecordFetcherConfig(
            consumer_arn=self._config.consumer_arn,  # type: ignore[arg-type]
            shard_id=shard_id,
            stream_arn=self._config.stream_arn,  # type: ignore[arg-type]
            initial_position=self._config.initial_position,
        )

        return EFORecordFetcher(self._kinesis_client, efo_config)

    def get_retrieval_mode(self) -> RetrievalMode:
        """Get the current retrieval mode.

        Returns:
            The retrieval mode
        """
        return self._config.retrieval_mode

    def is_enhanced_fan_out(self) -> bool:
        """Check if using Enhanced Fan-Out.

        Returns:
            True if using EFO, False otherwise
        """
        return self._config.retrieval_mode == RetrievalMode.FANOUT

    @staticmethod
    def parse_retrieval_mode(mode_str: str | None) -> RetrievalMode:
        """Parse retrieval mode from string (case-insensitive).

        Supports values: POLLING, FANOUT, DEFAULT, EFO, ENHANCED_FAN_OUT

        Args:
            mode_str: The mode string to parse

        Returns:
            The parsed RetrievalMode
        """
        if not mode_str:
            return RetrievalMode.DEFAULT

        normalized = mode_str.upper().strip()

        if normalized == "POLLING":
            return RetrievalMode.POLLING
        elif normalized in ("FANOUT", "FAN_OUT", "EFO", "ENHANCED_FAN_OUT", "ENHANCED-FAN-OUT"):
            return RetrievalMode.FANOUT
        else:
            return RetrievalMode.DEFAULT
