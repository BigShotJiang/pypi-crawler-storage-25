"""Enhanced Fan-Out Record Fetcher using SubscribeToShard API.

Enhanced Fan-Out provides:
- Dedicated throughput of 2 MB/s per consumer per shard
- Push-based delivery over HTTP/2
- Lower latency (~70ms vs ~200ms+ for polling)
- Multiple independent consumers per stream

Based on AWS KCL v2.7.2 FanOutRecordsPublisher implementation.
"""

import asyncio
import logging
from dataclasses import dataclass
from enum import Enum
from typing import Any

from ..exceptions import (
    InvalidConfigurationException,
    KinesisException,
    KinesisProvisionedThroughputExceededException,
    KinesisTimeoutException,
    ResourceNotFoundException,
)
from ..types import (
    ChildShard,
    HashKeyRange,
    InitialPositionInStream,
    InitialPositionInStreamExtended,
    KinesisClientRecord,
)
from ..utils.backoff import BackoffConfig, JitterType, calculate_backoff_with_jitter
from .record_fetcher import FetchRecordsResult
from .shard_syncer import CHECKPOINT_SENTINEL

# Default configuration values
DEFAULT_SUBSCRIPTION_TIMEOUT_MILLIS = 60000  # 1 minute
DEFAULT_MAX_RETRIES = 3
DEFAULT_BASE_DELAY_MS = 100
DEFAULT_MAX_DELAY_MS = 5000
MAX_RESUBSCRIBE_ATTEMPTS = 5
RESUBSCRIBE_RESET_INTERVAL_MS = 60000  # Reset counter after 1 minute of success


class ShardIteratorType(str, Enum):
    """Shard iterator types for Kinesis."""

    TRIM_HORIZON = "TRIM_HORIZON"
    LATEST = "LATEST"
    AT_SEQUENCE_NUMBER = "AT_SEQUENCE_NUMBER"
    AFTER_SEQUENCE_NUMBER = "AFTER_SEQUENCE_NUMBER"
    AT_TIMESTAMP = "AT_TIMESTAMP"


@dataclass
class EFORecordFetcherConfig:
    """Configuration for the Enhanced Fan-Out Record Fetcher."""

    consumer_arn: str
    """The consumer ARN (required for EFO)"""

    shard_id: str
    """The shard ID to subscribe to"""

    stream_arn: str
    """The stream ARN"""

    initial_position: InitialPositionInStreamExtended
    """Initial position in stream"""

    subscription_timeout_millis: int = DEFAULT_SUBSCRIPTION_TIMEOUT_MILLIS
    """Timeout for subscription in milliseconds"""

    max_retries: int = DEFAULT_MAX_RETRIES
    """Maximum retries for subscription"""

    base_delay_ms: int = DEFAULT_BASE_DELAY_MS
    """Base delay for exponential backoff in milliseconds"""

    max_delay_ms: int = DEFAULT_MAX_DELAY_MS
    """Maximum delay for exponential backoff in milliseconds"""


class EFORecordFetcher:
    """Enhanced Fan-Out Record Fetcher using SubscribeToShard API.

    Enhanced Fan-Out provides:
    - Dedicated throughput of 2 MB/s per consumer per shard
    - Push-based delivery over HTTP/2
    - Lower latency (~70ms vs ~200ms+ for polling)
    - Multiple independent consumers per stream

    Based on AWS KCL v2.7.2 FanOutRecordsPublisher implementation.
    """

    def __init__(self, kinesis_client: Any, config: EFORecordFetcherConfig):
        """Initialize the EFO record fetcher.

        Args:
            kinesis_client: The aioboto3 Kinesis client
            config: EFO configuration
        """
        self._kinesis_client = kinesis_client
        self._config = config
        self._subscription_timeout_millis = config.subscription_timeout_millis
        self._max_retries = config.max_retries
        self._base_delay_ms = config.base_delay_ms
        self._max_delay_ms = config.max_delay_ms

        self._is_shard_end = False
        self._last_checkpoint: str | None = None
        self._current_subscription: Any | None = None
        # Store the iterator as an instance variable - this is important!
        # Creating a new iterator each time can cause duplicate subscriptions
        self._current_iterator: Any | None = None
        self._pending_records: list[KinesisClientRecord] = []
        self._is_subscribed = False
        self._continuation_sequence_number: str | None = None
        self._child_shards: list[ChildShard] | None = None
        self._millis_behind_latest = 0

        # Resubscription tracking
        self._resubscribe_attempts = 0
        self._last_successful_fetch: float | None = None

        # Track subscription conflict errors to detect persistent conflicts
        self._subscription_conflict_start_time: float | None = None
        # 6 minutes (slightly more than 5 min subscription lifetime)
        self._max_subscription_conflict_duration_ms = 6 * 60 * 1000

        self._logger = logging.getLogger(f"kcl.EFORecordFetcher.{config.shard_id}")

    async def initialize(self, checkpoint: str | None = None) -> None:
        """Initialize the EFO record fetcher with a starting position.

        Args:
            checkpoint: Optional checkpoint to start from
        """
        self._last_checkpoint = checkpoint
        self._is_shard_end = False
        self._is_subscribed = False
        self._current_iterator = None  # Clear any existing iterator
        self._pending_records = []
        self._continuation_sequence_number = None
        self._child_shards = None
        self._subscription_conflict_start_time = None  # Reset conflict tracking

        # Create initial subscription
        await self._subscribe(checkpoint)

    async def _subscribe(self, checkpoint: str | None = None) -> None:
        """Subscribe to the shard using SubscribeToShard API.

        Args:
            checkpoint: Optional checkpoint to start from
        """
        starting_position = self._get_starting_position(checkpoint)

        pos_type = starting_position["StartingPosition"]["Type"]
        seq_num = starting_position["StartingPosition"].get("SequenceNumber", "")
        seq_suffix = f" at {seq_num}" if seq_num else ""
        self._logger.info(
            f"Subscribing to shard {self._config.shard_id} with EFO consumer "
            f"{self._config.consumer_arn}, starting position: {pos_type}{seq_suffix}"
        )

        last_error: Exception | None = None

        for attempt in range(self._max_retries):
            try:
                response = await self._kinesis_client.subscribe_to_shard(
                    ConsumerARN=self._config.consumer_arn,
                    ShardId=self._config.shard_id,
                    StartingPosition=starting_position["StartingPosition"],
                )

                if "EventStream" in response:
                    event_stream = response["EventStream"]
                    self._current_subscription = event_stream
                    # Create the iterator once and reuse it - this is important!
                    # Creating a new iterator each time can cause duplicate subscriptions
                    self._current_iterator = event_stream.__aiter__()
                    self._is_subscribed = True
                    # Don't clear conflict timer here - only clear it when we successfully fetch records
                    # A successful subscription doesn't guarantee we can process records
                    self._logger.info(f"Successfully subscribed to shard {self._config.shard_id}")
                    return

                raise KinesisException(
                    f"No event stream returned from SubscribeToShard for shard {self._config.shard_id}",
                    retryable=True,
                )
            except Exception as error:
                last_error = error

                # Don't retry non-retryable errors
                if not self._is_retryable(error):
                    break

                # Exponential backoff with jitter
                backoff_config = BackoffConfig(
                    base_delay_ms=self._base_delay_ms,
                    max_delay_ms=self._max_delay_ms,
                    jitter_type=JitterType.EQUAL,
                )
                delay_ms = calculate_backoff_with_jitter(attempt, backoff_config)
                self._logger.warning(
                    f"Failed to subscribe to shard {self._config.shard_id} "
                    f"(attempt {attempt + 1}/{self._max_retries}), retrying in {delay_ms}ms: {error}"
                )
                await asyncio.sleep(delay_ms / 1000)

        raise self._wrap_subscription_error(last_error)

    async def fetch_records(self) -> FetchRecordsResult:
        """Fetch the next batch of records from the subscription.

        Note: Enhanced Fan-Out pushes records to us, so this method processes
        the subscription events and returns available records.

        Returns:
            FetchRecordsResult with records and metadata
        """
        if self._is_shard_end:
            return FetchRecordsResult(
                records=[],
                millis_behind_latest=0,
                is_at_shard_end=True,
                child_shards=self._child_shards,
            )

        # If we have pending records from a previous event, return them
        if self._pending_records:
            records = self._pending_records
            self._pending_records = []
            # Clear conflict timer - we're successfully processing records
            if self._subscription_conflict_start_time is not None:
                self._subscription_conflict_start_time = None
            return FetchRecordsResult(
                records=records,
                millis_behind_latest=self._millis_behind_latest,
                is_at_shard_end=self._is_shard_end,
                child_shards=self._child_shards,
            )

        # If not subscribed, resubscribe
        if not self._is_subscribed or not self._current_subscription:
            await self._resubscribe()

        try:
            # Process subscription events
            return await self._process_subscription_events()
        except Exception as error:
            return await self._handle_fetch_error(error)

    async def _process_subscription_events(self) -> FetchRecordsResult:
        """Process events from the subscription stream.

        Returns:
            FetchRecordsResult with records and metadata
        """
        if not self._current_subscription or not self._current_iterator:
            raise KinesisException(
                f"No active subscription for shard {self._config.shard_id}",
                retryable=True,
            )

        try:
            # Process events from the stored iterator with timeout
            # Important: We reuse the same iterator - creating a new one each time
            # can cause duplicate subscriptions and "Another active subscription exists" errors
            async with asyncio.timeout(self._subscription_timeout_millis / 1000):
                try:
                    event = await self._current_iterator.__anext__()
                    result = self._process_event(event)
                    if result is not None:
                        self._last_successful_fetch = asyncio.get_event_loop().time()
                        return result
                except StopAsyncIteration:
                    # Subscription ended normally - need to resubscribe
                    self._is_subscribed = False
                    self._current_iterator = None
                    return await self._resubscribe_and_fetch()

            # If we get here without returning, continue processing
            # This shouldn't normally happen, but handle it gracefully
            return FetchRecordsResult(
                records=[],
                millis_behind_latest=self._millis_behind_latest,
                is_at_shard_end=self._is_shard_end,
            )

        except asyncio.TimeoutError:
            self._logger.warning(
                f"[EFO] Subscription timeout for shard {self._config.shard_id} "
                f"after {self._subscription_timeout_millis}ms - will resubscribe"
            )
            self._is_subscribed = False
            self._current_iterator = None  # Clear the iterator on timeout
            return await self._resubscribe_and_fetch()

    def _process_event(self, event: dict[str, Any]) -> FetchRecordsResult | None:
        """Process a single event from the subscription stream.

        Args:
            event: The event from SubscribeToShard

        Returns:
            FetchRecordsResult if records are available, None otherwise
        """
        # Handle SubscribeToShardEvent
        if "SubscribeToShardEvent" in event:
            shard_event = event["SubscribeToShardEvent"]

            # Update continuation sequence number for resubscription
            if shard_event.get("ContinuationSequenceNumber"):
                self._continuation_sequence_number = shard_event["ContinuationSequenceNumber"]

            # Update millis behind latest
            if shard_event.get("MillisBehindLatest") is not None:
                self._millis_behind_latest = shard_event["MillisBehindLatest"]

            # Convert records
            records: list[KinesisClientRecord] = []
            for record in shard_event.get("Records", []):
                records.append(
                    KinesisClientRecord(
                        sequence_number=record["SequenceNumber"],
                        approximate_arrival_timestamp=record.get("ApproximateArrivalTimestamp"),
                        data=record["Data"],
                        partition_key=record["PartitionKey"],
                        encryption_type=record.get("EncryptionType"),
                    )
                )

            # Clear conflict timer on successful record fetch - we're actually processing now
            if self._subscription_conflict_start_time is not None:
                conflict_duration = asyncio.get_event_loop().time() * 1000 - self._subscription_conflict_start_time
                total_seconds = int(conflict_duration / 1000)
                minutes_elapsed = total_seconds // 60
                seconds_elapsed = total_seconds % 60
                if minutes_elapsed > 0:
                    seconds_part = f" and {seconds_elapsed} second(s)" if seconds_elapsed > 0 else ""
                    time_display = f"{minutes_elapsed} minute(s){seconds_part}"
                else:
                    time_display = f"{seconds_elapsed} second(s)"
                self._logger.info(
                    f"[EFO] Subscription conflict for shard {self._config.shard_id} resolved after {time_display}. "
                    f"Successfully fetching records now."
                )
                self._subscription_conflict_start_time = None

            # Extract child shards if present
            if shard_event.get("ChildShards"):
                self._child_shards = []
                for child in shard_event["ChildShards"]:
                    hash_key_range_data = child.get("HashKeyRange", {})
                    self._child_shards.append(
                        ChildShard(
                            shard_id=child["ShardId"],
                            parent_shards=child.get("ParentShards", []),
                            hash_key_range=HashKeyRange(
                                starting_hash_key=hash_key_range_data.get("StartingHashKey", "0"),
                                ending_hash_key=hash_key_range_data.get("EndingHashKey", "0"),
                            ),
                        )
                    )

                # Determine resharding type
                reshard_type = (
                    "SPLIT"
                    if len(self._child_shards) == 2
                    else ("MERGE" if len(self._child_shards[0].parent_shards) == 2 else "UNKNOWN")
                )

                self._logger.info(
                    f"[RESHARDING] [EFO] Detected {reshard_type} operation for shard {self._config.shard_id}"
                )
                self._logger.info(
                    f"[RESHARDING] [EFO] Shard {self._config.shard_id} has reached its end - "
                    "no more records will be available"
                )
                child_count = len(self._child_shards)
                self._logger.info(
                    f"[RESHARDING] [EFO] Parent shard {self._config.shard_id} has {child_count} child shard(s):"
                )
                for child in self._child_shards:
                    self._logger.info(
                        f"[RESHARDING] [EFO]   → Child: {child.shard_id} (parents: {', '.join(child.parent_shards)})"
                    )

                # Shard end detected
                self._is_shard_end = True

            return FetchRecordsResult(
                records=records,
                millis_behind_latest=self._millis_behind_latest,
                is_at_shard_end=self._is_shard_end,
                child_shards=self._child_shards,
            )

        # Handle ResourceNotFoundException - shard no longer exists
        if "ResourceNotFoundException" in event:
            self._is_shard_end = True
            self._is_subscribed = False
            # Clear conflict timer - shard no longer exists, so conflict is resolved
            if self._subscription_conflict_start_time is not None:
                self._subscription_conflict_start_time = None
            return FetchRecordsResult(
                records=[],
                millis_behind_latest=0,
                is_at_shard_end=True,
            )

        # Handle ResourceInUseException - another subscription is active
        if "ResourceInUseException" in event:
            raise KinesisException(
                f"Resource in use for shard {self._config.shard_id}: Another subscription may be active",
                retryable=True,
            )

        # Handle InternalFailureException
        if "InternalFailureException" in event:
            raise KinesisException(
                f"Internal failure for shard {self._config.shard_id}",
                retryable=True,
            )

        # Handle KMS exceptions
        kms_exceptions = [
            "KMSAccessDeniedException",
            "KMSDisabledException",
            "KMSInvalidStateException",
            "KMSNotFoundException",
            "KMSOptInRequired",
            "KMSThrottlingException",
        ]
        for kms_exc in kms_exceptions:
            if kms_exc in event:
                is_retryable = kms_exc == "KMSThrottlingException"
                raise KinesisException(
                    f"KMS error for shard {self._config.shard_id}: {kms_exc}",
                    retryable=is_retryable,
                )

        # Unknown event type - continue processing
        self._logger.debug(f"[EFO] Unknown event type for shard {self._config.shard_id}: {list(event.keys())}")
        return None

    async def _resubscribe(self) -> None:
        """Resubscribe to the shard with error handling."""
        self._is_subscribed = False
        self._current_iterator = None  # Clear the old iterator

        # Use continuation sequence number if available, otherwise use last checkpoint
        start_position = self._continuation_sequence_number or self._last_checkpoint

        try:
            await self._subscribe(start_position)
        except Exception as error:
            self._logger.warning(f"[EFO] Failed to resubscribe to shard {self._config.shard_id}: {error}")
            raise

    async def _resubscribe_and_fetch(self) -> FetchRecordsResult:
        """Resubscribe and fetch records with retry limit to prevent infinite loops.

        Returns:
            FetchRecordsResult with records and metadata
        """
        # Reset counter if we've had successful fetches recently
        current_time = asyncio.get_event_loop().time()
        if self._last_successful_fetch and (current_time - self._last_successful_fetch) > (
            RESUBSCRIBE_RESET_INTERVAL_MS / 1000
        ):
            self._resubscribe_attempts = 0

        self._resubscribe_attempts += 1

        if self._resubscribe_attempts > MAX_RESUBSCRIBE_ATTEMPTS:
            self._logger.error(
                f"[EFO] [FATAL] Max resubscribe attempts ({MAX_RESUBSCRIBE_ATTEMPTS}) exceeded "
                f"for shard {self._config.shard_id}. Marking shard as failed."
            )
            # Reset attempts for next time
            self._resubscribe_attempts = 0
            # Throw a non-retryable error to signal the consumer should stop
            raise KinesisException(
                f"Max resubscribe attempts exceeded for shard {self._config.shard_id}",
                retryable=False,
            )

        # Exponential backoff with jitter between resubscribe attempts
        backoff_config = BackoffConfig(
            base_delay_ms=self._base_delay_ms,
            max_delay_ms=self._max_delay_ms,
            jitter_type=JitterType.FULL,  # Use full jitter for EFO resubscription
        )
        backoff_ms = calculate_backoff_with_jitter(self._resubscribe_attempts - 1, backoff_config)

        self._logger.info(
            f"[EFO] Resubscribe attempt {self._resubscribe_attempts}/{MAX_RESUBSCRIBE_ATTEMPTS} "
            f"for shard {self._config.shard_id}, backing off {backoff_ms}ms (with jitter)"
        )

        await asyncio.sleep(backoff_ms / 1000)

        try:
            await self._resubscribe()
            # Reset attempts on successful resubscription
            self._resubscribe_attempts = 0
            self._last_successful_fetch = asyncio.get_event_loop().time()
            return await self.fetch_records()
        except Exception as error:
            # If resubscription failed, try again via handle_fetch_error
            return await self._handle_fetch_error(error)

    async def _handle_fetch_error(self, error: Any) -> FetchRecordsResult:
        """Handle errors during record fetching.

        Args:
            error: The error that occurred

        Returns:
            FetchRecordsResult with records and metadata
        """
        error_name = type(error).__name__
        error_message = str(error)

        # Handle timeout - this is recoverable via resubscription
        if isinstance(error, asyncio.TimeoutError | KinesisTimeoutException):
            self._logger.warning(f"[EFO] Subscription timeout for shard {self._config.shard_id}, resubscribing...")
            self._is_subscribed = False
            return await self._resubscribe_and_fetch()

        # Check for resource not found (shard deleted)
        if "ResourceNotFound" in error_name or "ResourceNotFound" in error_message:
            self._is_shard_end = True
            self._is_subscribed = False
            return FetchRecordsResult(
                records=[],
                millis_behind_latest=0,
                is_at_shard_end=True,
            )

        # Handle "Another active subscription exists" or "Subscription limit exceeded" errors
        # This occurs when another consumer (or the same consumer from a previous run) has an
        # active subscription. EFO subscriptions last up to 5 minutes, so we should wait for
        # it to expire. However, if this persists for more than 6 minutes, it means another
        # worker is actively using the same consumer ARN, which is a configuration issue that
        # won't resolve with retries.
        is_subscription_conflict = (
            "Another active subscription exists" in error_message
            or "active subscription" in error_message.lower()
            or "Subscription limit exceeded" in error_message
            or "ResourceInUse" in error_name
            or "ResourceInUse" in error_message
            or "LimitExceeded" in error_name
            or "LimitExceeded" in error_message
        )

        if is_subscription_conflict:
            current_time = asyncio.get_event_loop().time() * 1000  # Convert to ms

            # Track when the conflict started
            if self._subscription_conflict_start_time is None:
                self._subscription_conflict_start_time = current_time
                self._logger.warning(
                    f"[EFO] Subscription conflict detected for shard {self._config.shard_id}. "
                    f"Another subscription is active. This can happen during rolling deployments. "
                    f"Will retry for up to 6 minutes (subscriptions auto-expire after 5 minutes)."
                )

            conflict_duration = current_time - self._subscription_conflict_start_time

            # If conflict persists for more than 6 minutes, it's likely a configuration issue
            if conflict_duration > self._max_subscription_conflict_duration_ms:
                total_seconds = int(conflict_duration / 1000)
                minutes_elapsed = total_seconds // 60
                seconds_elapsed = total_seconds % 60
                if minutes_elapsed > 0:
                    seconds_part = f" and {seconds_elapsed} second(s)" if seconds_elapsed > 0 else ""
                    time_display = f"{minutes_elapsed} minute(s){seconds_part}"
                else:
                    time_display = f"{seconds_elapsed} second(s)"
                self._logger.error(
                    f"[EFO] [FATAL] Subscription conflict for shard {self._config.shard_id} has persisted for "
                    f"{time_display}. This indicates that another worker is "
                    f"actively using the same EFO consumer ARN ({self._config.consumer_arn}). "
                    f"Each worker should have its own unique consumer ARN, or use polling mode "
                    f"instead of EFO. Giving up on this shard - the lease will be released."
                )
                # Clear the conflict timer
                self._subscription_conflict_start_time = None
                # Throw a non-retryable error to stop processing this shard
                raise KinesisException(
                    f"Persistent subscription conflict for shard {self._config.shard_id}. "
                    f"Another worker is using the same consumer ARN. Check your EFO consumer configuration.",
                    retryable=False,
                )

            # Log progress periodically with accurate time display
            total_seconds = int(conflict_duration / 1000)
            minutes_elapsed = total_seconds // 60
            seconds_elapsed = total_seconds % 60
            if minutes_elapsed > 0:
                time_display = (
                    f"{minutes_elapsed} minute(s){f' and {seconds_elapsed} second(s)' if seconds_elapsed > 0 else ''}"
                )
            else:
                time_display = f"{seconds_elapsed} second(s)"
            self._logger.warning(
                f"[EFO] Subscription conflict for shard {self._config.shard_id} ongoing for {time_display}. "
                f"Will keep retrying until 6 minutes (then will give up)."
            )

            self._is_subscribed = False
            # Use longer backoff for subscription conflicts
            # Increase backoff based on how long we've been retrying
            retry_attempt = min(int(conflict_duration / 30000), 5)
            backoff_ms = calculate_backoff_with_jitter(
                retry_attempt,
                BackoffConfig(base_delay_ms=5000, max_delay_ms=30000, jitter_type=JitterType.FULL),
            )
            self._logger.info(
                f"[EFO] Backing off {round(backoff_ms / 1000)}s before retry for shard {self._config.shard_id}"
            )
            await asyncio.sleep(backoff_ms / 1000)
            return await self._resubscribe_and_fetch()

        # Handle access denied - fatal, cannot recover
        if "AccessDenied" in error_name or "AccessDenied" in error_message:
            self._logger.error(f"[EFO] [FATAL] Access denied for shard {self._config.shard_id}: {error}")
            raise KinesisException(
                f"Access denied for shard {self._config.shard_id}: {error}",
                retryable=False,
                cause=error if isinstance(error, Exception) else None,
            )

        # Handle invalid argument - fatal configuration error
        if "InvalidArgument" in error_name or "InvalidArgument" in error_message:
            self._logger.error(f"[EFO] [FATAL] Invalid argument for shard {self._config.shard_id}: {error}")
            raise InvalidConfigurationException(
                f"Invalid argument for shard {self._config.shard_id}: {error}",
                "startingPosition",
            )

        # For retryable errors, try to resubscribe
        if self._is_retryable(error):
            self._logger.warning(f"[EFO] Retryable error for shard {self._config.shard_id}: {error}")
            self._is_subscribed = False
            await asyncio.sleep(self._base_delay_ms / 1000)
            return await self._resubscribe_and_fetch()

        # Wrap unknown errors - assume retryable first, let the caller decide
        self._logger.warning(
            f"[EFO] Unhandled error type for shard {self._config.shard_id}: "
            f"[{error_name}] {error_message}. Will attempt to resubscribe."
        )
        self._is_subscribed = False
        await asyncio.sleep(self._base_delay_ms / 1000)
        return await self._resubscribe_and_fetch()

    def _get_starting_position(self, checkpoint: str | None = None) -> dict[str, Any]:
        """Get the starting position for SubscribeToShard.

        Args:
            checkpoint: Optional checkpoint to start from

        Returns:
            Starting position dict for SubscribeToShard
        """
        if checkpoint:
            if checkpoint == CHECKPOINT_SENTINEL.TRIM_HORIZON:
                return {"StartingPosition": {"Type": ShardIteratorType.TRIM_HORIZON.value}}
            elif checkpoint == CHECKPOINT_SENTINEL.LATEST:
                return {"StartingPosition": {"Type": ShardIteratorType.LATEST.value}}
            elif checkpoint == CHECKPOINT_SENTINEL.AT_TIMESTAMP:
                return {
                    "StartingPosition": {
                        "Type": ShardIteratorType.AT_TIMESTAMP.value,
                        "Timestamp": self._config.initial_position.timestamp,
                    }
                }
            elif checkpoint == CHECKPOINT_SENTINEL.SHARD_END:
                # Shard is complete
                self._is_shard_end = True
                return {"StartingPosition": {"Type": ShardIteratorType.LATEST.value}}
            else:
                # It's an actual sequence number - start after it
                return {
                    "StartingPosition": {
                        "Type": ShardIteratorType.AFTER_SEQUENCE_NUMBER.value,
                        "SequenceNumber": checkpoint,
                    }
                }

        # Use initial position from config
        initial_pos = self._config.initial_position.initial_position_in_stream
        if initial_pos == InitialPositionInStream.TRIM_HORIZON:
            return {"StartingPosition": {"Type": ShardIteratorType.TRIM_HORIZON.value}}
        elif initial_pos == InitialPositionInStream.LATEST:
            return {"StartingPosition": {"Type": ShardIteratorType.LATEST.value}}
        elif initial_pos == InitialPositionInStream.AT_TIMESTAMP:
            return {
                "StartingPosition": {
                    "Type": ShardIteratorType.AT_TIMESTAMP.value,
                    "Timestamp": self._config.initial_position.timestamp,
                }
            }
        else:
            return {"StartingPosition": {"Type": ShardIteratorType.TRIM_HORIZON.value}}

    def _wrap_subscription_error(self, error: Exception | None) -> KinesisException:
        """Wrap subscription errors.

        Args:
            error: The error to wrap

        Returns:
            Wrapped KinesisException
        """
        if error is None:
            return KinesisException(
                f"Unknown error subscribing to shard {self._config.shard_id}",
                retryable=True,
            )

        error_name = type(error).__name__
        error_message = str(error)

        if "ResourceNotFound" in error_name or "ResourceNotFound" in error_message:
            return ResourceNotFoundException(
                f"Consumer or shard not found: {self._config.consumer_arn}/{self._config.shard_id}",
                f"{self._config.consumer_arn}/{self._config.shard_id}",
                error,
            )

        if "LimitExceeded" in error_name or "LimitExceeded" in error_message:
            return KinesisProvisionedThroughputExceededException(
                f"Subscription limit exceeded for shard {self._config.shard_id}",
                self._config.shard_id,
                1000,
                error,
            )

        if isinstance(error, KinesisException):
            return error

        return KinesisException(
            f"Failed to subscribe to shard {self._config.shard_id}: {error}",
            retryable=self._is_retryable(error),
            cause=error,
        )

    def _is_retryable(self, error: Any) -> bool:
        """Check if an error is retryable.

        Args:
            error: The error to check

        Returns:
            True if retryable, False otherwise
        """
        error_name = type(error).__name__ if error else ""
        error_message = str(error) if error else ""

        retryable_patterns = [
            "ProvisionedThroughputExceededException",
            "ThrottlingException",
            "RequestLimitExceeded",
            "InternalServerError",
            "ServiceUnavailable",
            "TimeoutError",
            "ETIMEDOUT",
            "ECONNRESET",
            "ENOTFOUND",
            "NetworkingError",
            "KMSThrottlingException",
            "ResourceInUseException",
        ]

        return any(pattern in error_name or pattern in error_message for pattern in retryable_patterns)

    async def seek_to(self, sequence_number: str) -> None:
        """Reset the fetcher to a specific position.

        Args:
            sequence_number: The sequence number to seek to
        """
        self._is_shard_end = False
        self._is_subscribed = False
        self._current_iterator = None  # Clear the old iterator
        self._pending_records = []
        self._continuation_sequence_number = None
        self._last_checkpoint = sequence_number
        await self._subscribe(sequence_number)

    def is_at_shard_end(self) -> bool:
        """Check if we've reached the end of the shard.

        Returns:
            True if at shard end, False otherwise
        """
        return self._is_shard_end

    def get_shard_id(self) -> str:
        """Get the shard ID.

        Returns:
            The shard ID
        """
        return self._config.shard_id

    def is_actively_subscribed(self) -> bool:
        """Check if subscribed.

        Returns:
            True if subscribed, False otherwise
        """
        return self._is_subscribed

    async def close(self) -> None:
        """Close the subscription."""
        self._is_subscribed = False
        self._current_iterator = None
        self._current_subscription = None
        self._logger.info(f"Closed EFO subscription for shard {self._config.shard_id}")
