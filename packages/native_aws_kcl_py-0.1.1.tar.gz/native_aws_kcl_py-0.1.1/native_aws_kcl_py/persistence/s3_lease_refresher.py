"""
S3-based implementation of LeaseRefresher.

This implementation uses Amazon S3 for storing lease and checkpoint information.
It leverages S3's conditional writes (If-Match/If-None-Match headers) for
optimistic concurrency control (OCC).

Features:
- Optimistic locking using ETags (If-Match header)
- Write-if-not-exists using If-None-Match: * header
- Strong consistency on S3 General Purpose buckets
- Server-side encryption support (AES256 or KMS)

Key Structure:
{key_prefix}{application_name}/{shard_id}.json

Example: kcl/leases/my-app/shardId-000000000001.json
"""

import json
import logging
import time
from dataclasses import dataclass
from typing import Any

from ..exceptions import (
    LeaseConditionalCheckFailedException,
    LeaseException,
    LeaseTimeoutException,
)
from ..types import Lease, LeaseRefresher
from ..utils import BackoffConfig, JitterType, calculate_backoff_with_jitter
from .interfaces import PersistenceHealthCheckResult


@dataclass
class S3LeaseRefresherConfig:
    """Configuration for the S3 lease refresher."""

    bucket_name: str
    """S3 bucket name"""

    key_prefix: str
    """Key prefix for lease objects (default: 'kcl/leases/')"""

    application_name: str
    """Application name (used in key path)"""

    worker_identifier: str
    """Worker identifier"""

    lease_duration_millis: int
    """Lease duration in milliseconds"""

    server_side_encryption: bool = True
    """Enable server-side encryption"""

    kms_key_id: str | None = None
    """KMS key ID for encryption"""

    storage_class: str = "STANDARD"
    """Storage class for objects"""


class S3LeaseRefresher(LeaseRefresher):
    """
    S3-based implementation of LeaseRefresher.

    Uses S3's conditional writes for optimistic concurrency control:
    - If-None-Match: * for creating new leases (write-if-not-exists)
    - If-Match: {etag} for updating existing leases (compare-and-swap)
    """

    _logger = logging.getLogger("kcl.S3LeaseRefresher")

    MAX_RETRIES = 3
    BASE_DELAY_MS = 100

    def __init__(self, s3_client: Any, config: S3LeaseRefresherConfig):
        """
        Initialize the S3 lease refresher.

        Args:
            s3_client: An aioboto3 S3 client
            config: Configuration for the lease refresher
        """
        self._s3_client = s3_client
        self._config = config
        self._key_prefix = f"{config.key_prefix}{config.application_name}/"
        self._etag_cache: dict[str, str] = {}

    def _get_lease_key(self, lease_key: str) -> str:
        """Get the full S3 key for a lease."""
        return f"{self._key_prefix}{lease_key}.json"

    async def create_lease_table_if_not_exists(self) -> bool:
        """
        Create the lease "table" if it doesn't exist.
        For S3, this verifies the bucket exists.
        """
        try:
            await self._s3_client.head_bucket(Bucket=self._config.bucket_name)
            self._logger.info(
                f"S3 bucket verified for lease storage: {self._config.bucket_name} " f"(prefix: {self._key_prefix})"
            )
            return True
        except Exception as e:
            error_code = getattr(e, "response", {}).get("Error", {}).get("Code", "")
            if error_code == "404" or "Not Found" in str(e):
                raise LeaseException(
                    f"S3 bucket '{self._config.bucket_name}' does not exist. "
                    "Please create it before using S3 persistence.",
                    retryable=False,
                )
            raise LeaseException(
                f"Failed to verify S3 bucket: {e}",
                retryable=True,
                cause=e,
            )

    async def wait_for_table_active(self) -> None:
        """Wait for the lease table to become active."""
        max_attempts = 10
        delay_ms = 500

        for attempt in range(max_attempts):
            try:
                await self._s3_client.head_bucket(Bucket=self._config.bucket_name)
                return
            except Exception as e:
                self._logger.debug(f"S3 bucket check failed (attempt {attempt + 1}/{max_attempts}): {e}")

            await self._delay(delay_ms)

        raise LeaseTimeoutException(
            f"S3 bucket '{self._config.bucket_name}' not accessible within {max_attempts * delay_ms}ms"
        )

    async def lease_table_exists(self) -> bool:
        """Check if the lease table (bucket) exists."""
        try:
            await self._s3_client.head_bucket(Bucket=self._config.bucket_name)
            return True
        except Exception:
            return False

    async def list_leases(self) -> list[Lease]:
        """List all leases from S3."""
        leases: list[Lease] = []

        try:
            continuation_token = None

            while True:
                params = {
                    "Bucket": self._config.bucket_name,
                    "Prefix": self._key_prefix,
                }
                if continuation_token:
                    params["ContinuationToken"] = continuation_token

                response = await self._s3_client.list_objects_v2(**params)

                for obj in response.get("Contents", []):
                    key = obj.get("Key", "")
                    if key.endswith(".json"):
                        try:
                            lease = await self._get_lease_by_key(key)
                            if lease:
                                leases.append(lease)
                        except Exception as e:
                            self._logger.warning(f"Failed to read lease from {key}: {e}")

                if not response.get("IsTruncated"):
                    break
                continuation_token = response.get("NextContinuationToken")

            return leases
        except Exception as e:
            raise LeaseException(
                f"Failed to list leases from S3: {e}",
                retryable=True,
                cause=e,
            )

    async def get_lease(self, lease_key: str) -> Lease | None:
        """Get a specific lease by key."""
        key = self._get_lease_key(lease_key)
        return await self._get_lease_by_key(key)

    async def _get_lease_by_key(self, key: str) -> Lease | None:
        """Get a lease by its full S3 key."""
        try:
            response = await self._s3_client.get_object(
                Bucket=self._config.bucket_name,
                Key=key,
            )

            body = await response["Body"].read()
            lease_data = json.loads(body.decode("utf-8"))
            lease = self._dict_to_lease(lease_data)

            # Store the ETag for future conditional writes
            etag = response.get("ETag")
            if etag:
                self._etag_cache[lease.lease_key] = etag

            return lease
        except Exception as e:
            error_code = getattr(e, "response", {}).get("Error", {}).get("Code", "")
            if error_code == "NoSuchKey" or "NoSuchKey" in str(e):
                return None
            raise LeaseException(
                f"Failed to get lease from S3: {e}",
                retryable=True,
                cause=e,
            )

    async def create_lease(self, lease: Lease) -> bool:
        """
        Create a new lease.
        Uses If-None-Match: * to ensure atomic creation (write-if-not-exists).
        """
        key = self._get_lease_key(lease.lease_key)

        try:
            lease_data = self._serialize_lease(lease)

            params = {
                "Bucket": self._config.bucket_name,
                "Key": key,
                "Body": lease_data,
                "ContentType": "application/json",
                "IfNoneMatch": "*",  # Only create if object doesn't exist
            }
            params.update(self._get_encryption_params())
            if self._config.storage_class:
                params["StorageClass"] = self._config.storage_class

            response = await self._s3_client.put_object(**params)

            # Store the ETag for future updates
            etag = response.get("ETag")
            if etag:
                self._etag_cache[lease.lease_key] = etag

            self._logger.debug(f"Created lease {lease.lease_key} in S3")
            return True
        except Exception as e:
            # 412 Precondition Failed means object already exists
            error_code = getattr(e, "response", {}).get("ResponseMetadata", {}).get("HTTPStatusCode", 0)
            if error_code == 412:
                self._logger.debug(f"Lease {lease.lease_key} already exists in S3")
                return False
            raise LeaseException(
                f"Failed to create lease {lease.lease_key} in S3: {e}",
                retryable=True,
                cause=e,
            )

    async def renew_lease(self, lease: Lease) -> bool:
        """
        Renew a lease (increment counter and update timestamp).
        Uses If-Match with ETag for optimistic concurrency control.
        """
        key = self._get_lease_key(lease.lease_key)

        for attempt in range(self.MAX_RETRIES):
            try:
                # Get current lease with ETag
                current_lease = await self._get_lease_by_key(key)
                if not current_lease:
                    self._logger.debug(f"Lease {lease.lease_key} not found during renewal")
                    return False

                # Verify ownership and counter
                owner_mismatch = current_lease.lease_owner != lease.lease_owner
                counter_mismatch = current_lease.lease_counter != lease.lease_counter
                if owner_mismatch or counter_mismatch:
                    self._logger.debug(f"Lease {lease.lease_key} was modified by another worker")
                    return False

                etag = self._etag_cache.get(lease.lease_key)
                if not etag:
                    self._logger.warning(f"No ETag found for lease {lease.lease_key}")
                    return False

                # Update lease
                now = int(time.time() * 1_000_000_000)  # Nanos
                updated_lease = Lease(
                    lease_key=current_lease.lease_key,
                    lease_owner=current_lease.lease_owner,
                    lease_counter=current_lease.lease_counter + 1,
                    last_counter_increment_nanos=now,
                    checkpoint=current_lease.checkpoint,
                    pending_checkpoint=current_lease.pending_checkpoint,
                    owner_switches_since_checkpoint=current_lease.owner_switches_since_checkpoint,
                    parent_shard_ids=current_lease.parent_shard_ids,
                    child_shard_ids=current_lease.child_shard_ids,
                )

                # Conditional write with ETag
                params = {
                    "Bucket": self._config.bucket_name,
                    "Key": key,
                    "Body": self._serialize_lease(updated_lease),
                    "ContentType": "application/json",
                    "IfMatch": etag,
                }
                params.update(self._get_encryption_params())

                response = await self._s3_client.put_object(**params)

                # Update local lease and cache
                lease.lease_counter = updated_lease.lease_counter
                lease.last_counter_increment_nanos = updated_lease.last_counter_increment_nanos

                new_etag = response.get("ETag")
                if new_etag:
                    self._etag_cache[lease.lease_key] = new_etag

                return True
            except Exception as e:
                resp_metadata = getattr(e, "response", {}).get("ResponseMetadata", {})
                error_code = resp_metadata.get("HTTPStatusCode", 0)
                if error_code == 412:
                    self._logger.debug(
                        f"Lease {lease.lease_key} renewal failed due to concurrent " "modification, retrying..."
                    )
                    backoff_config = BackoffConfig(
                        base_delay_ms=self.BASE_DELAY_MS, max_delay_ms=5000, jitter_type=JitterType.EQUAL
                    )
                    await self._delay(calculate_backoff_with_jitter(attempt, backoff_config))
                    continue

                if attempt == self.MAX_RETRIES - 1:
                    raise LeaseException(
                        f"Failed to renew lease {lease.lease_key} after {self.MAX_RETRIES} attempts: {e}",
                        retryable=True,
                        cause=e,
                    )
                await self._delay(calculate_backoff_with_jitter(attempt))

        return False

    async def take_lease(self, lease: Lease, new_owner: str) -> bool:
        """Take a lease from another worker."""
        key = self._get_lease_key(lease.lease_key)

        for attempt in range(self.MAX_RETRIES):
            try:
                current_lease = await self._get_lease_by_key(key)
                if not current_lease:
                    return False

                # Verify counter matches
                if current_lease.lease_counter != lease.lease_counter:
                    self._logger.debug(f"Lease {lease.lease_key} counter mismatch during take")
                    return False

                # If lease has an owner, verify it matches
                if lease.lease_owner and current_lease.lease_owner != lease.lease_owner:
                    self._logger.debug(f"Lease {lease.lease_key} owner mismatch during take")
                    return False

                etag = self._etag_cache.get(lease.lease_key)
                if not etag:
                    self._logger.warning(f"No ETag found for lease {lease.lease_key}")
                    return False

                now = int(time.time() * 1_000_000_000)
                updated_lease = Lease(
                    lease_key=current_lease.lease_key,
                    lease_owner=new_owner,
                    lease_counter=current_lease.lease_counter + 1,
                    last_counter_increment_nanos=now,
                    checkpoint=current_lease.checkpoint,
                    pending_checkpoint=current_lease.pending_checkpoint,
                    owner_switches_since_checkpoint=(current_lease.owner_switches_since_checkpoint or 0) + 1,
                    parent_shard_ids=current_lease.parent_shard_ids,
                    child_shard_ids=current_lease.child_shard_ids,
                )

                params = {
                    "Bucket": self._config.bucket_name,
                    "Key": key,
                    "Body": self._serialize_lease(updated_lease),
                    "ContentType": "application/json",
                    "IfMatch": etag,
                }
                params.update(self._get_encryption_params())

                response = await self._s3_client.put_object(**params)

                # Update local lease
                lease.lease_owner = updated_lease.lease_owner
                lease.lease_counter = updated_lease.lease_counter
                lease.last_counter_increment_nanos = updated_lease.last_counter_increment_nanos
                lease.owner_switches_since_checkpoint = updated_lease.owner_switches_since_checkpoint

                new_etag = response.get("ETag")
                if new_etag:
                    self._etag_cache[lease.lease_key] = new_etag

                self._logger.info(f"Successfully took lease {lease.lease_key}")
                return True
            except Exception as e:
                error_code = getattr(e, "response", {}).get("ResponseMetadata", {}).get("HTTPStatusCode", 0)
                if error_code == 412:
                    self._logger.debug(
                        f"Lease {lease.lease_key} take failed due to concurrent modification, retrying..."
                    )
                    await self._delay(calculate_backoff_with_jitter(attempt))
                    continue

                if attempt == self.MAX_RETRIES - 1:
                    raise LeaseException(
                        f"Failed to take lease {lease.lease_key}: {e}",
                        retryable=True,
                        cause=e,
                    )
                await self._delay(calculate_backoff_with_jitter(attempt))

        return False

    async def evict_lease(self, lease: Lease) -> bool:
        """Evict the current owner from a lease."""
        key = self._get_lease_key(lease.lease_key)

        try:
            current_lease = await self._get_lease_by_key(key)
            if not current_lease:
                return False

            if current_lease.lease_counter != lease.lease_counter:
                return False

            etag = self._etag_cache.get(lease.lease_key)
            if not etag:
                return False

            now = int(time.time() * 1_000_000_000)
            updated_lease = Lease(
                lease_key=current_lease.lease_key,
                lease_owner=None,
                lease_counter=current_lease.lease_counter + 1,
                last_counter_increment_nanos=now,
                checkpoint=current_lease.checkpoint,
                pending_checkpoint=current_lease.pending_checkpoint,
                owner_switches_since_checkpoint=current_lease.owner_switches_since_checkpoint,
                parent_shard_ids=current_lease.parent_shard_ids,
                child_shard_ids=current_lease.child_shard_ids,
            )

            params = {
                "Bucket": self._config.bucket_name,
                "Key": key,
                "Body": self._serialize_lease(updated_lease),
                "ContentType": "application/json",
                "IfMatch": etag,
            }
            params.update(self._get_encryption_params())

            response = await self._s3_client.put_object(**params)

            lease.lease_owner = None
            lease.lease_counter = updated_lease.lease_counter
            lease.last_counter_increment_nanos = updated_lease.last_counter_increment_nanos

            new_etag = response.get("ETag")
            if new_etag:
                self._etag_cache[lease.lease_key] = new_etag

            return True
        except Exception as e:
            error_code = getattr(e, "response", {}).get("ResponseMetadata", {}).get("HTTPStatusCode", 0)
            if error_code == 412:
                return False
            raise LeaseException(
                f"Failed to evict lease {lease.lease_key}: {e}",
                retryable=True,
                cause=e,
            )

    async def update_lease(self, lease: Lease) -> bool:
        """Update a lease (e.g., for checkpointing)."""
        key = self._get_lease_key(lease.lease_key)

        for attempt in range(self.MAX_RETRIES):
            try:
                current_lease = await self._get_lease_by_key(key)
                if not current_lease:
                    raise LeaseConditionalCheckFailedException(
                        f"Lease {lease.lease_key} not found during update",
                        lease.lease_key,
                    )

                # Verify ownership and counter
                owner_mismatch = current_lease.lease_owner != lease.lease_owner
                counter_mismatch = current_lease.lease_counter != lease.lease_counter
                if owner_mismatch or counter_mismatch:
                    raise LeaseConditionalCheckFailedException(
                        f"Lease {lease.lease_key} was modified - conditional check failed",
                        lease.lease_key,
                    )

                etag = self._etag_cache.get(lease.lease_key)
                if not etag:
                    raise LeaseConditionalCheckFailedException(
                        f"No ETag found for lease {lease.lease_key}",
                        lease.lease_key,
                    )

                now = int(time.time() * 1_000_000_000)
                owner_switches = 0 if lease.checkpoint else current_lease.owner_switches_since_checkpoint
                updated_lease = Lease(
                    lease_key=current_lease.lease_key,
                    lease_owner=current_lease.lease_owner,
                    lease_counter=current_lease.lease_counter + 1,
                    last_counter_increment_nanos=now,
                    checkpoint=lease.checkpoint,
                    pending_checkpoint=lease.pending_checkpoint,
                    owner_switches_since_checkpoint=owner_switches,
                    parent_shard_ids=current_lease.parent_shard_ids,
                    child_shard_ids=lease.child_shard_ids,
                )

                params = {
                    "Bucket": self._config.bucket_name,
                    "Key": key,
                    "Body": self._serialize_lease(updated_lease),
                    "ContentType": "application/json",
                    "IfMatch": etag,
                }
                params.update(self._get_encryption_params())

                response = await self._s3_client.put_object(**params)

                # Update local lease
                lease.lease_counter = updated_lease.lease_counter
                lease.last_counter_increment_nanos = updated_lease.last_counter_increment_nanos
                if lease.checkpoint:
                    lease.owner_switches_since_checkpoint = 0

                new_etag = response.get("ETag")
                if new_etag:
                    self._etag_cache[lease.lease_key] = new_etag

                return True
            except LeaseConditionalCheckFailedException:
                raise
            except Exception as e:
                error_code = getattr(e, "response", {}).get("ResponseMetadata", {}).get("HTTPStatusCode", 0)
                if error_code == 412:
                    self._logger.debug(
                        f"Lease {lease.lease_key} update failed due to concurrent modification, retrying..."
                    )
                    await self._delay(calculate_backoff_with_jitter(attempt))
                    continue

                if attempt == self.MAX_RETRIES - 1:
                    raise LeaseException(
                        f"Failed to update lease {lease.lease_key}: {e}",
                        retryable=True,
                        cause=e,
                    )
                await self._delay(calculate_backoff_with_jitter(attempt))

        return False

    async def delete_lease(self, lease: Lease) -> bool:
        """Delete a lease."""
        key = self._get_lease_key(lease.lease_key)

        try:
            # First verify the lease exists and matches
            current_lease = await self._get_lease_by_key(key)
            if not current_lease:
                return True  # Already deleted

            if current_lease.lease_counter != lease.lease_counter:
                return False

            # S3 doesn't support conditional deletes, so we just delete
            await self._s3_client.delete_object(
                Bucket=self._config.bucket_name,
                Key=key,
            )

            self._etag_cache.pop(lease.lease_key, None)
            return True
        except Exception as e:
            raise LeaseException(
                f"Failed to delete lease {lease.lease_key}: {e}",
                retryable=True,
                cause=e,
            )

    async def delete_all_leases(self) -> None:
        """Delete all leases (for cleanup)."""
        try:
            continuation_token = None

            while True:
                params = {
                    "Bucket": self._config.bucket_name,
                    "Prefix": self._key_prefix,
                }
                if continuation_token:
                    params["ContinuationToken"] = continuation_token

                response = await self._s3_client.list_objects_v2(**params)

                for obj in response.get("Contents", []):
                    key = obj.get("Key")
                    if key:
                        await self._s3_client.delete_object(
                            Bucket=self._config.bucket_name,
                            Key=key,
                        )

                if not response.get("IsTruncated"):
                    break
                continuation_token = response.get("NextContinuationToken")

            self._etag_cache.clear()
            self._logger.info(f"Deleted all leases with prefix {self._key_prefix}")
        except Exception as e:
            self._logger.warning(f"Failed to delete all leases: {e}")

    def is_lease_expired(self, lease: Lease, lease_duration_millis: int) -> bool:
        """Check if a lease is expired."""
        if not lease.last_counter_increment_nanos:
            return True

        last_update_millis = lease.last_counter_increment_nanos / 1_000_000
        now = time.time() * 1000

        return (now - last_update_millis) > lease_duration_millis

    async def health_check(self) -> PersistenceHealthCheckResult:
        """Perform a health check."""
        start_time = time.time()

        try:
            await self._s3_client.head_bucket(Bucket=self._config.bucket_name)
            latency_ms = (time.time() - start_time) * 1000

            return PersistenceHealthCheckResult(
                healthy=True,
                type="s3",
                latency_ms=latency_ms,
                details={
                    "bucket": self._config.bucket_name,
                    "key_prefix": self._key_prefix,
                },
            )
        except Exception as e:
            latency_ms = (time.time() - start_time) * 1000
            return PersistenceHealthCheckResult(
                healthy=False,
                type="s3",
                latency_ms=latency_ms,
                error=str(e),
            )

    def _get_encryption_params(self) -> dict[str, str]:
        """Get encryption parameters for PutObject."""
        if not self._config.server_side_encryption:
            return {}

        if self._config.kms_key_id:
            return {
                "ServerSideEncryption": "aws:kms",
                "SSEKMSKeyId": self._config.kms_key_id,
            }

        return {"ServerSideEncryption": "AES256"}

    def _serialize_lease(self, lease: Lease) -> str:
        """Serialize a lease to JSON string."""
        data = {
            "lease_key": lease.lease_key,
            "lease_owner": lease.lease_owner,
            "lease_counter": lease.lease_counter,
            "last_counter_increment_nanos": lease.last_counter_increment_nanos,
            "owner_switches_since_checkpoint": lease.owner_switches_since_checkpoint,
            "parent_shard_ids": lease.parent_shard_ids,
            "child_shard_ids": lease.child_shard_ids,
        }

        if lease.checkpoint:
            data["checkpoint"] = {
                "sequence_number": lease.checkpoint.sequence_number,
                "sub_sequence_number": lease.checkpoint.sub_sequence_number,
            }

        if lease.pending_checkpoint:
            data["pending_checkpoint"] = {
                "sequence_number": lease.pending_checkpoint.sequence_number,
                "sub_sequence_number": lease.pending_checkpoint.sub_sequence_number,
            }

        return json.dumps(data, indent=2)

    def _dict_to_lease(self, data: dict[str, Any]) -> Lease:
        """Convert a dictionary to a Lease object."""
        from ..types import ExtendedSequenceNumber

        checkpoint = None
        if data.get("checkpoint"):
            checkpoint = ExtendedSequenceNumber(
                sequence_number=data["checkpoint"]["sequence_number"],
                sub_sequence_number=data["checkpoint"].get("sub_sequence_number", 0),
            )

        pending_checkpoint = None
        if data.get("pending_checkpoint"):
            pending_checkpoint = ExtendedSequenceNumber(
                sequence_number=data["pending_checkpoint"]["sequence_number"],
                sub_sequence_number=data["pending_checkpoint"].get("sub_sequence_number", 0),
            )

        return Lease(
            lease_key=data["lease_key"],
            lease_owner=data.get("lease_owner"),
            lease_counter=data.get("lease_counter", 0),
            last_counter_increment_nanos=data.get("last_counter_increment_nanos"),
            checkpoint=checkpoint,
            pending_checkpoint=pending_checkpoint,
            owner_switches_since_checkpoint=data.get("owner_switches_since_checkpoint", 0),
            parent_shard_ids=data.get("parent_shard_ids"),
            child_shard_ids=data.get("child_shard_ids"),
        )

    async def _delay(self, ms: float) -> None:
        """Helper to delay execution."""
        import asyncio

        await asyncio.sleep(ms / 1000)
