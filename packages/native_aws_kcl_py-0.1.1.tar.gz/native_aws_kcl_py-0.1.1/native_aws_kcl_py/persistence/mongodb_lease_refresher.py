"""
MongoDB-based implementation of LeaseRefresher.

This implementation uses MongoDB for storing lease and checkpoint information.
It uses MongoDB's atomic operations (find_one_and_update) with a version field
for optimistic concurrency control (OCC).

Features:
- Optimistic locking using version field
- Atomic operations with find_one_and_update
- TTL index support for automatic lease cleanup (optional)
- Replica set and sharding support
"""

import logging
import time
from dataclasses import dataclass
from typing import Any, Protocol

from ..exceptions import (
    LeaseConditionalCheckFailedException,
    LeaseException,
    LeaseTimeoutException,
)
from ..types import Lease, LeaseRefresher
from ..utils import BackoffConfig, JitterType, calculate_backoff_with_jitter
from .interfaces import PersistenceHealthCheckResult


class MongoDBCollectionProtocol(Protocol):
    """Protocol for MongoDB collection interface."""

    async def find_one(self, filter: dict[str, Any], *args: Any, **kwargs: Any) -> dict[str, Any] | None: ...

    async def find(self, filter: dict[str, Any], *args: Any, **kwargs: Any) -> Any: ...

    async def insert_one(self, document: dict[str, Any], *args: Any, **kwargs: Any) -> Any: ...

    async def update_one(self, filter: dict[str, Any], update: dict[str, Any], *args: Any, **kwargs: Any) -> Any: ...

    async def find_one_and_update(
        self, filter: dict[str, Any], update: dict[str, Any], *args: Any, **kwargs: Any
    ) -> dict[str, Any] | None: ...

    async def delete_one(self, filter: dict[str, Any], *args: Any, **kwargs: Any) -> Any: ...

    async def delete_many(self, filter: dict[str, Any], *args: Any, **kwargs: Any) -> Any: ...

    async def count_documents(self, filter: dict[str, Any], *args: Any, **kwargs: Any) -> int: ...

    async def create_index(self, keys: Any, *args: Any, **kwargs: Any) -> str: ...


@dataclass
class MongoDBLeaseRefresherConfig:
    """Configuration for the MongoDB lease refresher."""

    collection_name: str
    """Collection name for leases"""

    application_name: str
    """Application name"""

    worker_identifier: str
    """Worker identifier"""

    lease_duration_millis: int
    """Lease duration in milliseconds"""

    auto_create_indexes: bool = True
    """Auto-create indexes"""


class MongoDBLeaseRefresher(LeaseRefresher):
    """
    MongoDB-based implementation of LeaseRefresher.

    Uses MongoDB's atomic find_one_and_update for optimistic concurrency control:
    - Each update includes a version check in the filter
    - If the version doesn't match, the operation returns None (conflict)
    - Version is incremented atomically with $inc
    """

    _logger = logging.getLogger("kcl.MongoDBLeaseRefresher")

    MAX_RETRIES = 3
    BASE_DELAY_MS = 100

    def __init__(self, collection: Any, config: MongoDBLeaseRefresherConfig):
        """
        Initialize the MongoDB lease refresher.

        Args:
            collection: A motor MongoDB collection
            config: Configuration for the lease refresher
        """
        self._collection = collection
        self._config = config

    async def create_lease_table_if_not_exists(self) -> bool:
        """Create the lease collection and indexes if they don't exist."""
        try:
            if self._config.auto_create_indexes:
                # Create index on lease_owner for efficient queries
                await self._collection.create_index("lease_owner", background=True)

                # Create index on last_counter_increment_nanos for lease expiration queries
                await self._collection.create_index("last_counter_increment_nanos", background=True)

                self._logger.info(f"MongoDB collection '{self._config.collection_name}' indexes verified/created")
            return True
        except Exception as e:
            raise LeaseException(
                f"Failed to create MongoDB indexes: {e}",
                retryable=False,
                cause=e,
            )

    async def wait_for_table_active(self) -> None:
        """Wait for the collection to become available."""
        max_attempts = 10
        delay_ms = 500

        for attempt in range(max_attempts):
            try:
                # Try to count documents to verify collection is accessible
                await self._collection.count_documents({})
                return
            except Exception as e:
                self._logger.debug(f"MongoDB collection check failed (attempt {attempt + 1}/{max_attempts}): {e}")

            await self._delay(delay_ms)

        raise LeaseTimeoutException(
            f"MongoDB collection '{self._config.collection_name}' not available within {max_attempts * delay_ms}ms"
        )

    async def lease_table_exists(self) -> bool:
        """Check if the collection exists and is accessible."""
        try:
            await self._collection.count_documents({})
            return True
        except Exception:
            return False

    async def list_leases(self) -> list[Lease]:
        """List all leases from MongoDB."""
        try:
            cursor = self._collection.find({})
            documents = await cursor.to_list(length=None)
            return [self._document_to_lease(doc) for doc in documents]
        except Exception as e:
            raise LeaseException(
                f"Failed to list leases from MongoDB: {e}",
                retryable=True,
                cause=e,
            )

    async def get_lease(self, lease_key: str) -> Lease | None:
        """Get a specific lease by key."""
        try:
            document = await self._collection.find_one({"_id": lease_key})

            if not document:
                return None

            return self._document_to_lease(document)
        except Exception as e:
            raise LeaseException(
                f"Failed to get lease {lease_key} from MongoDB: {e}",
                retryable=True,
                cause=e,
            )

    async def create_lease(self, lease: Lease) -> bool:
        """
        Create a new lease.
        Uses insert_one which will fail if document already exists (duplicate _id).
        """
        try:
            from datetime import datetime, timezone

            now = datetime.now(timezone.utc)
            checkpoint_seq = lease.checkpoint.sequence_number if lease.checkpoint else None
            checkpoint_sub = lease.checkpoint.sub_sequence_number if lease.checkpoint else None
            pending_seq = lease.pending_checkpoint.sequence_number if lease.pending_checkpoint else None
            pending_sub = lease.pending_checkpoint.sub_sequence_number if lease.pending_checkpoint else None
            document = {
                "_id": lease.lease_key,
                "lease_owner": lease.lease_owner,
                "lease_counter": lease.lease_counter or 0,
                "checkpoint": checkpoint_seq,
                "checkpoint_sub_sequence_number": checkpoint_sub,
                "pending_checkpoint": pending_seq,
                "pending_checkpoint_sub_sequence_number": pending_sub,
                "owner_switches_since_checkpoint": lease.owner_switches_since_checkpoint or 0,
                "parent_shard_ids": lease.parent_shard_ids,
                "child_shard_ids": lease.child_shard_ids,
                "last_counter_increment_nanos": lease.last_counter_increment_nanos,
                "version": 1,
                "created_at": now,
                "updated_at": now,
            }

            result = await self._collection.insert_one(document)

            if result.acknowledged:
                self._logger.debug(f"Created lease {lease.lease_key} in MongoDB")
                return True

            return False
        except Exception as e:
            # Duplicate key error means lease already exists
            if "duplicate key" in str(e).lower() or "E11000" in str(e):
                self._logger.debug(f"Lease {lease.lease_key} already exists in MongoDB")
                return False
            raise LeaseException(
                f"Failed to create lease {lease.lease_key} in MongoDB: {e}",
                retryable=True,
                cause=e,
            )

    async def renew_lease(self, lease: Lease) -> bool:
        """
        Renew a lease (increment counter and update timestamp).
        Uses find_one_and_update with version check for optimistic locking.
        """
        for attempt in range(self.MAX_RETRIES):
            try:
                from datetime import datetime, timezone

                current_lease = await self.get_lease(lease.lease_key)
                if not current_lease:
                    self._logger.debug(f"Lease {lease.lease_key} not found during renewal")
                    return False

                # Verify ownership and counter
                owner_mismatch = current_lease.lease_owner != lease.lease_owner
                counter_mismatch = current_lease.lease_counter != lease.lease_counter
                if owner_mismatch or counter_mismatch:
                    self._logger.debug(f"Lease {lease.lease_key} was modified by another worker")
                    return False

                now = int(time.time() * 1_000_000_000)  # Nanos
                current_version = getattr(current_lease, "version", 1)

                # Atomic update with version check
                result = await self._collection.find_one_and_update(
                    {"_id": lease.lease_key, "version": current_version},
                    {
                        "$inc": {"version": 1, "lease_counter": 1},
                        "$set": {
                            "last_counter_increment_nanos": now,
                            "updated_at": datetime.now(timezone.utc),
                        },
                    },
                    return_document=True,  # Return the updated document
                )

                if not result:
                    # Version mismatch - concurrent modification
                    self._logger.debug(
                        f"Lease {lease.lease_key} renewal failed due to concurrent " "modification, retrying..."
                    )
                    backoff_config = BackoffConfig(
                        base_delay_ms=self.BASE_DELAY_MS, max_delay_ms=5000, jitter_type=JitterType.EQUAL
                    )
                    await self._delay(calculate_backoff_with_jitter(attempt, backoff_config))
                    continue

                # Update local lease
                lease.lease_counter = result["lease_counter"]
                lease.last_counter_increment_nanos = result["last_counter_increment_nanos"]

                return True
            except Exception as e:
                if attempt == self.MAX_RETRIES - 1:
                    raise LeaseException(
                        f"Failed to renew lease {lease.lease_key} after {self.MAX_RETRIES} attempts: {e}",
                        retryable=True,
                        cause=e,
                    )
                await self._delay(calculate_backoff_with_jitter(attempt))

        return False

    async def take_lease(self, lease: Lease, new_owner: str) -> bool:
        """Take a lease from another worker."""
        for attempt in range(self.MAX_RETRIES):
            try:
                from datetime import datetime

                current_lease = await self.get_lease(lease.lease_key)
                if not current_lease:
                    return False

                # Verify counter matches
                if current_lease.lease_counter != lease.lease_counter:
                    self._logger.debug(f"Lease {lease.lease_key} counter mismatch during take")
                    return False

                # If lease has an owner, verify it matches
                if lease.lease_owner and current_lease.lease_owner != lease.lease_owner:
                    self._logger.debug(f"Lease {lease.lease_key} owner mismatch during take")
                    return False

                now = int(time.time() * 1_000_000_000)
                current_version = getattr(current_lease, "version", 1)

                result = await self._collection.find_one_and_update(
                    {"_id": lease.lease_key, "version": current_version},
                    {
                        "$inc": {"version": 1, "lease_counter": 1, "owner_switches_since_checkpoint": 1},
                        "$set": {
                            "lease_owner": new_owner,
                            "last_counter_increment_nanos": now,
                            "updated_at": datetime.utcnow(),
                        },
                    },
                    return_document=True,
                )

                if not result:
                    self._logger.debug(
                        f"Lease {lease.lease_key} take failed due to concurrent modification, retrying..."
                    )
                    await self._delay(calculate_backoff_with_jitter(attempt))
                    continue

                # Update local lease
                lease.lease_owner = result["lease_owner"]
                lease.lease_counter = result["lease_counter"]
                lease.last_counter_increment_nanos = result["last_counter_increment_nanos"]
                lease.owner_switches_since_checkpoint = result["owner_switches_since_checkpoint"]

                self._logger.info(f"Successfully took lease {lease.lease_key}")
                return True
            except Exception as e:
                if attempt == self.MAX_RETRIES - 1:
                    raise LeaseException(
                        f"Failed to take lease {lease.lease_key}: {e}",
                        retryable=True,
                        cause=e,
                    )
                await self._delay(calculate_backoff_with_jitter(attempt))

        return False

    async def evict_lease(self, lease: Lease) -> bool:
        """Evict the current owner from a lease."""
        try:
            from datetime import datetime

            current_lease = await self.get_lease(lease.lease_key)
            if not current_lease:
                return False

            if current_lease.lease_counter != lease.lease_counter:
                return False

            now = int(time.time() * 1_000_000_000)
            current_version = getattr(current_lease, "version", 1)

            result = await self._collection.find_one_and_update(
                {"_id": lease.lease_key, "version": current_version},
                {
                    "$inc": {"version": 1, "lease_counter": 1},
                    "$set": {
                        "lease_owner": None,
                        "last_counter_increment_nanos": now,
                        "updated_at": datetime.utcnow(),
                    },
                },
                return_document=True,
            )

            if not result:
                return False

            lease.lease_owner = None
            lease.lease_counter = result["lease_counter"]
            lease.last_counter_increment_nanos = result["last_counter_increment_nanos"]

            return True
        except Exception as e:
            raise LeaseException(
                f"Failed to evict lease {lease.lease_key}: {e}",
                retryable=True,
                cause=e,
            )

    async def update_lease(self, lease: Lease) -> bool:
        """Update a lease (e.g., for checkpointing)."""
        for attempt in range(self.MAX_RETRIES):
            try:
                from datetime import datetime

                current_lease = await self.get_lease(lease.lease_key)
                if not current_lease:
                    raise LeaseConditionalCheckFailedException(
                        f"Lease {lease.lease_key} not found during update",
                        lease.lease_key,
                    )

                # Verify ownership and counter
                owner_mismatch = current_lease.lease_owner != lease.lease_owner
                counter_mismatch = current_lease.lease_counter != lease.lease_counter
                if owner_mismatch or counter_mismatch:
                    raise LeaseConditionalCheckFailedException(
                        f"Lease {lease.lease_key} was modified - conditional check failed",
                        lease.lease_key,
                    )

                now = int(time.time() * 1_000_000_000)
                current_version = getattr(current_lease, "version", 1)

                checkpoint_seq = lease.checkpoint.sequence_number if lease.checkpoint else None
                checkpoint_sub = lease.checkpoint.sub_sequence_number if lease.checkpoint else None
                pending_seq = lease.pending_checkpoint.sequence_number if lease.pending_checkpoint else None
                pending_sub = lease.pending_checkpoint.sub_sequence_number if lease.pending_checkpoint else None

                update_set: dict[str, Any] = {
                    "last_counter_increment_nanos": now,
                    "updated_at": datetime.utcnow(),
                    "checkpoint": checkpoint_seq,
                    "checkpoint_sub_sequence_number": checkpoint_sub,
                    "pending_checkpoint": pending_seq,
                    "pending_checkpoint_sub_sequence_number": pending_sub,
                    "child_shard_ids": lease.child_shard_ids,
                }

                # Reset owner switches if checkpointing
                if lease.checkpoint:
                    update_set["owner_switches_since_checkpoint"] = 0

                result = await self._collection.find_one_and_update(
                    {"_id": lease.lease_key, "version": current_version},
                    {
                        "$inc": {"version": 1, "lease_counter": 1},
                        "$set": update_set,
                    },
                    return_document=True,
                )

                if not result:
                    self._logger.debug(
                        f"Lease {lease.lease_key} update failed due to concurrent modification, retrying..."
                    )
                    await self._delay(calculate_backoff_with_jitter(attempt))
                    continue

                # Update local lease
                lease.lease_counter = result["lease_counter"]
                lease.last_counter_increment_nanos = result["last_counter_increment_nanos"]
                if lease.checkpoint:
                    lease.owner_switches_since_checkpoint = 0

                return True
            except LeaseConditionalCheckFailedException:
                raise
            except Exception as e:
                if attempt == self.MAX_RETRIES - 1:
                    raise LeaseException(
                        f"Failed to update lease {lease.lease_key}: {e}",
                        retryable=True,
                        cause=e,
                    )
                await self._delay(calculate_backoff_with_jitter(attempt))

        return False

    async def delete_lease(self, lease: Lease) -> bool:
        """Delete a lease."""
        try:
            current_lease = await self.get_lease(lease.lease_key)
            if not current_lease:
                return True  # Already deleted

            if current_lease.lease_counter != lease.lease_counter:
                return False

            current_version = getattr(current_lease, "version", 1)

            result = await self._collection.delete_one(
                {
                    "_id": lease.lease_key,
                    "version": current_version,
                }
            )

            return result.deleted_count > 0
        except Exception as e:
            raise LeaseException(
                f"Failed to delete lease {lease.lease_key}: {e}",
                retryable=True,
                cause=e,
            )

    async def delete_all_leases(self) -> None:
        """Delete all leases (for cleanup)."""
        try:
            await self._collection.delete_many({})
            self._logger.info(f"Deleted all leases from {self._config.collection_name}")
        except Exception as e:
            self._logger.warning(f"Failed to delete all leases: {e}")

    def is_lease_expired(self, lease: Lease, lease_duration_millis: int) -> bool:
        """Check if a lease is expired."""
        if not lease.last_counter_increment_nanos:
            return True

        last_update_millis = lease.last_counter_increment_nanos / 1_000_000
        now = time.time() * 1000

        return (now - last_update_millis) > lease_duration_millis

    async def health_check(self) -> PersistenceHealthCheckResult:
        """Perform a health check."""
        start_time = time.time()

        try:
            await self._collection.count_documents({})
            latency_ms = (time.time() - start_time) * 1000

            return PersistenceHealthCheckResult(
                healthy=True,
                type="mongodb",
                latency_ms=latency_ms,
                details={
                    "collection": self._config.collection_name,
                },
            )
        except Exception as e:
            latency_ms = (time.time() - start_time) * 1000
            return PersistenceHealthCheckResult(
                healthy=False,
                type="mongodb",
                latency_ms=latency_ms,
                error=str(e),
            )

    def _document_to_lease(self, doc: dict[str, Any]) -> Lease:
        """Convert a MongoDB document to a Lease object."""
        from ..types import ExtendedSequenceNumber

        checkpoint = None
        if doc.get("checkpoint"):
            checkpoint = ExtendedSequenceNumber(
                sequence_number=doc["checkpoint"],
                sub_sequence_number=doc.get("checkpoint_sub_sequence_number", 0) or 0,
            )

        pending_checkpoint = None
        if doc.get("pending_checkpoint"):
            pending_checkpoint = ExtendedSequenceNumber(
                sequence_number=doc["pending_checkpoint"],
                sub_sequence_number=doc.get("pending_checkpoint_sub_sequence_number", 0) or 0,
            )

        lease = Lease(
            lease_key=doc["_id"],
            lease_owner=doc.get("lease_owner"),
            lease_counter=doc.get("lease_counter", 0) or 0,
            last_counter_increment_nanos=doc.get("last_counter_increment_nanos"),
            checkpoint=checkpoint,
            pending_checkpoint=pending_checkpoint,
            owner_switches_since_checkpoint=doc.get("owner_switches_since_checkpoint", 0) or 0,
            parent_shard_ids=doc.get("parent_shard_ids"),
            child_shard_ids=doc.get("child_shard_ids"),
        )

        # Store version for optimistic locking
        lease.version = doc.get("version", 1) or 1  # type: ignore

        return lease

    async def _delay(self, ms: float) -> None:
        """Helper to delay execution."""
        import asyncio

        await asyncio.sleep(ms / 1000)
