"""
Persistence Layer for the Kinesis Client Library.

This module provides interfaces and implementations for storing lease
and checkpoint information. The default implementation uses DynamoDB,
but alternative implementations are provided for:
- S3 (using conditional writes for optimistic concurrency)
- Redis (using WATCH/MULTI/EXEC for optimistic locking)
- PostgreSQL (using version column for optimistic concurrency)
- MySQL (using version column for optimistic concurrency)
- MongoDB (using version field with findOneAndUpdate)
"""

from .factory import (
    CreatePersistenceOptions,
    create_persistence_async,
    is_persistence_type_supported,
    parse_persistence_type,
)
from .interfaces import (
    BasePersistenceConfig,
    DynamoDBPersistenceConfig,
    LeaseRefresherWithHealthCheck,
    MongoDBPersistenceConfig,
    PersistenceHealthCheckResult,
    PersistenceProvider,
    PersistenceType,
    RedisPersistenceConfig,
    S3PersistenceConfig,
    SQLPersistenceConfig,
    supports_health_check,
)
from .mongodb_lease_refresher import MongoDBLeaseRefresher, MongoDBLeaseRefresherConfig
from .redis_lease_refresher import RedisLeaseRefresher, RedisLeaseRefresherConfig
from .s3_lease_refresher import S3LeaseRefresher, S3LeaseRefresherConfig
from .sql_lease_refresher import SQLDialect, SQLLeaseRefresher, SQLLeaseRefresherConfig

__all__ = [
    # Interfaces
    "BasePersistenceConfig",
    "PersistenceType",
    "PersistenceHealthCheckResult",
    "PersistenceProvider",
    "LeaseRefresherWithHealthCheck",
    "supports_health_check",
    "DynamoDBPersistenceConfig",
    "S3PersistenceConfig",
    "RedisPersistenceConfig",
    "SQLPersistenceConfig",
    "MongoDBPersistenceConfig",
    # Factory
    "create_persistence_async",
    "parse_persistence_type",
    "is_persistence_type_supported",
    "CreatePersistenceOptions",
    # Implementations
    "S3LeaseRefresher",
    "S3LeaseRefresherConfig",
    "RedisLeaseRefresher",
    "RedisLeaseRefresherConfig",
    "SQLLeaseRefresher",
    "SQLLeaseRefresherConfig",
    "SQLDialect",
    "MongoDBLeaseRefresher",
    "MongoDBLeaseRefresherConfig",
]
