"""
Persistence Layer Interfaces.

This module defines the interfaces for the persistence layer used by the KCL.
The persistence layer is responsible for storing lease and checkpoint information.

The default implementation uses DynamoDB, but these interfaces allow for
alternative implementations (S3, MySQL, Redis, MongoDB, etc.).
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Literal, Protocol

from ..types import LeaseRefresher

# Persistence types
PersistenceType = Literal["dynamodb", "s3", "redis", "mysql", "postgresql", "mongodb", "custom"]


@dataclass
class BasePersistenceConfig:
    """
    Base configuration for the persistence layer.
    This is the base configuration that all persistence implementations should support.
    """

    table_name: str
    """Name of the storage container (table name for DynamoDB, bucket for S3, etc.)"""

    worker_identifier: str
    """The worker identifier for lease ownership"""

    lease_duration_millis: int = 10000
    """Duration of a lease in milliseconds. Default: 10000 (10 seconds)"""

    epsilon_millis: int = 25
    """Epsilon for timing calculations in milliseconds. Default: 25"""

    max_leases_for_worker: int | None = None
    """Maximum number of leases this worker should hold"""

    max_leases_to_steal_at_one_time: int = 1
    """Maximum number of leases to steal at once. Default: 1"""


@dataclass
class DynamoDBPersistenceConfig(BasePersistenceConfig):
    """DynamoDB-specific configuration extending the base persistence config."""

    billing_mode: Literal["PAY_PER_REQUEST", "PROVISIONED"] = "PAY_PER_REQUEST"
    """Billing mode for DynamoDB table. Default: 'PAY_PER_REQUEST'"""

    read_capacity_units: int | None = None
    """Read capacity units (only used if billing_mode is 'PROVISIONED')"""

    write_capacity_units: int | None = None
    """Write capacity units (only used if billing_mode is 'PROVISIONED')"""

    endpoint: str | None = None
    """Custom DynamoDB endpoint (for local testing with DynamoDB Local)"""


@dataclass
class S3PersistenceConfig(BasePersistenceConfig):
    """
    S3-specific configuration.

    Uses S3's conditional writes (If-Match/If-None-Match headers) for
    optimistic concurrency control. Requires S3 General Purpose buckets
    for strong consistency.
    """

    bucket_name: str = ""
    """S3 bucket name for storing lease data. The bucket must exist before using this provider."""

    key_prefix: str = "kcl/leases/"
    """Key prefix for lease objects. Format: {key_prefix}{application_name}/{shard_id}.json"""

    endpoint: str | None = None
    """Custom S3 endpoint (for local testing with LocalStack or MinIO)"""

    region: str | None = None
    """AWS region for S3 bucket"""

    server_side_encryption: bool = True
    """Enable server-side encryption. Uses AES256 encryption by default."""

    kms_key_id: str | None = None
    """KMS key ID for server-side encryption (optional). If provided, uses aws:kms encryption."""

    storage_class: Literal["STANDARD", "STANDARD_IA", "ONEZONE_IA", "INTELLIGENT_TIERING"] = "STANDARD"
    """Storage class for lease objects"""

    force_path_style: bool = False
    """Enable path-style access (required for some S3-compatible services)"""


@dataclass
class RedisPersistenceConfig(BasePersistenceConfig):
    """Redis-specific configuration."""

    connection_url: str | None = None
    """Redis connection URL (e.g., 'redis://localhost:6379'). Takes precedence over host/port."""

    host: str = "localhost"
    """Redis host. Used if connection_url is not provided."""

    port: int = 6379
    """Redis port. Used if connection_url is not provided."""

    password: str | None = None
    """Redis password (optional)"""

    username: str | None = None
    """Redis username (optional, for Redis 6+ ACL)"""

    key_prefix: str = "kcl:leases:"
    """Key prefix for lease keys. All lease keys will be prefixed with this value."""

    database: int = 0
    """Database number. Default: 0"""

    tls: bool = False
    """Enable TLS/SSL connection"""

    connect_timeout: int = 5000
    """Connection timeout in milliseconds. Default: 5000"""

    command_timeout: int = 5000
    """Command timeout in milliseconds. Default: 5000"""

    cluster: bool = False
    """Enable cluster mode"""

    cluster_nodes: list[dict[str, Any]] | None = None
    """Cluster nodes (required if cluster mode is enabled)"""


@dataclass
class SQLPersistenceConfig(BasePersistenceConfig):
    """
    SQL (PostgreSQL/MySQL) specific configuration.

    Uses a version column for optimistic concurrency control.
    The atomic update pattern: UPDATE ... SET version = version + 1 WHERE version = X
    """

    connection_url: str | None = None
    """Database connection URL (e.g., postgresql://user:pass@host:port/db)"""

    host: str = "localhost"
    """Database host"""

    port: int | None = None
    """Database port (default: 5432 for PostgreSQL, 3306 for MySQL)"""

    database: str | None = None
    """Database name"""

    username: str | None = None
    """Database username"""

    password: str | None = None
    """Database password"""

    schema: str = "public"
    """Schema name (default: 'public' for PostgreSQL)"""

    ssl: bool | dict[str, Any] = False
    """Enable SSL/TLS connection"""

    pool_size: int = 10
    """Connection pool size. Default: 10"""

    connection_timeout: int = 5000
    """Connection timeout in milliseconds. Default: 5000"""

    idle_timeout: int = 10000
    """Idle timeout in milliseconds. Default: 10000"""

    auto_create_table: bool = True
    """Auto-create the lease table if it doesn't exist. Default: True"""


@dataclass
class MongoDBPersistenceConfig(BasePersistenceConfig):
    """
    MongoDB-specific configuration.

    Uses MongoDB's atomic operations (findOneAndUpdate) with a version field
    for optimistic concurrency control.
    """

    connection_url: str | None = None
    """MongoDB connection URL (e.g., mongodb://localhost:27017/db)"""

    host: str = "localhost"
    """MongoDB host. Used if connection_url is not provided."""

    port: int = 27017
    """MongoDB port. Used if connection_url is not provided."""

    database: str | None = None
    """Database name"""

    username: str | None = None
    """MongoDB username"""

    password: str | None = None
    """MongoDB password"""

    collection_name: str = "kcl_leases"
    """Collection name for leases. Default: 'kcl_leases'"""

    auth_source: str = "admin"
    """Authentication database. Default: 'admin'"""

    replica_set: str | None = None
    """Replica set name (for replica set connections)"""

    tls: bool = False
    """Enable TLS/SSL connection"""

    pool_size: int = 10
    """Connection pool size. Default: 10"""

    connect_timeout: int = 5000
    """Connection timeout in milliseconds. Default: 5000"""

    server_selection_timeout: int = 5000
    """Server selection timeout in milliseconds. Default: 5000"""

    write_concern: str | int = "majority"
    """Write concern. Default: 'majority'"""

    read_preference: Literal["primary", "primaryPreferred", "secondary", "secondaryPreferred", "nearest"] = "primary"
    """Read preference. Default: 'primary'"""

    auto_create_indexes: bool = True
    """Auto-create indexes on the collection. Default: True"""


@dataclass
class PersistenceHealthCheckResult:
    """Result of a persistence health check."""

    healthy: bool
    """Whether the persistence layer is healthy"""

    type: PersistenceType
    """The persistence type being used"""

    latency_ms: float
    """Latency of the health check in milliseconds"""

    error: str | None = None
    """Error message if unhealthy"""

    details: dict[str, Any] | None = None
    """Additional details about the persistence layer"""


class LeaseRefresherWithHealthCheck(LeaseRefresher, Protocol):
    """Extended LeaseRefresher interface with health check support."""

    async def health_check(self) -> PersistenceHealthCheckResult:
        """Perform a health check on the persistence layer."""
        ...


def supports_health_check(refresher: LeaseRefresher) -> bool:
    """Type guard to check if a LeaseRefresher supports health checks."""
    return hasattr(refresher, "health_check") and callable(getattr(refresher, "health_check"))


class PersistenceProvider(ABC):
    """
    Provider interface for the persistence layer.

    This interface allows for more complex initialization scenarios,
    such as async initialization or dependency injection.
    """

    @property
    @abstractmethod
    def type(self) -> PersistenceType:
        """The type identifier for this persistence provider."""
        ...

    @abstractmethod
    def create_lease_refresher(self, config: BasePersistenceConfig) -> LeaseRefresher:
        """Create a LeaseRefresher instance."""
        ...

    async def initialize(self) -> None:
        """Optional: Perform any async initialization."""
        pass

    async def shutdown(self) -> None:
        """Optional: Cleanup resources."""
        pass
