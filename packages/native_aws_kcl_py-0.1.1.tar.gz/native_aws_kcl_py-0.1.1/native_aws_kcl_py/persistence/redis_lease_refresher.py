"""
Redis-based implementation of LeaseRefresher.

This implementation uses Redis for storing lease and checkpoint information.
It provides an alternative to DynamoDB for environments where Redis is preferred.

Features:
- Optimistic locking using Redis WATCH/MULTI/EXEC
- Atomic operations for lease updates
- Support for Redis Cluster mode
"""

import json
import logging
import time
from dataclasses import dataclass
from typing import Any, Protocol

from ..exceptions import (
    LeaseConditionalCheckFailedException,
    LeaseException,
    LeaseTimeoutException,
)
from ..types import Lease, LeaseRefresher
from ..utils import BackoffConfig, JitterType, calculate_backoff_with_jitter
from .interfaces import PersistenceHealthCheckResult


class RedisClientProtocol(Protocol):
    """Protocol for Redis client interface."""

    async def get(self, key: str) -> str | None: ...
    async def set(self, key: str, value: str, *args: Any, **kwargs: Any) -> str | None: ...
    async def delete(self, *keys: str) -> int: ...
    async def keys(self, pattern: str) -> list[str]: ...
    async def exists(self, *keys: str) -> int: ...
    async def watch(self, *keys: str) -> bool: ...
    async def unwatch(self) -> bool: ...
    def multi(self) -> Any: ...
    async def ping(self) -> str: ...
    async def scan(self, cursor: int, match: str, count: int) -> tuple: ...


@dataclass
class RedisLeaseRefresherConfig:
    """Configuration for the Redis lease refresher."""

    key_prefix: str
    """Key prefix for all lease keys. Default: 'kcl:leases:'"""

    application_name: str
    """Application name (used in key prefix)"""

    worker_identifier: str
    """Worker identifier"""

    lease_duration_millis: int
    """Lease duration in milliseconds"""


class RedisLeaseRefresher(LeaseRefresher):
    """
    Redis-based implementation of LeaseRefresher.

    Lease data is stored as JSON strings in Redis with the following key format:
    `{key_prefix}{application_name}:{lease_key}`

    Example: `kcl:leases:my-app:shardId-000000000001`
    """

    _logger = logging.getLogger("kcl.RedisLeaseRefresher")

    MAX_RETRIES = 3
    BASE_DELAY_MS = 100

    def __init__(self, redis_client: Any, config: RedisLeaseRefresherConfig):
        """
        Initialize the Redis lease refresher.

        Args:
            redis_client: An aioredis client
            config: Configuration for the lease refresher
        """
        self._redis = redis_client
        self._config = config
        self._key_prefix = f"{config.key_prefix}{config.application_name}:"

    def _get_lease_key(self, lease_key: str) -> str:
        """Get the full Redis key for a lease."""
        return f"{self._key_prefix}{lease_key}"

    async def create_lease_table_if_not_exists(self) -> bool:
        """
        Create the lease "table" if it doesn't exist.
        For Redis, this is a no-op since Redis doesn't require table creation.
        We just verify connectivity.
        """
        try:
            await self._redis.ping()
            self._logger.info(f"Redis connection verified for lease storage (prefix: {self._key_prefix})")
            return True
        except Exception as e:
            raise LeaseException(
                f"Failed to connect to Redis: {e}",
                retryable=False,
                cause=e,
            )

    async def wait_for_table_active(self) -> None:
        """Wait for the lease table to become active."""
        max_attempts = 10
        delay_ms = 500

        for attempt in range(max_attempts):
            try:
                pong = await self._redis.ping()
                if pong == "PONG" or pong is True:
                    return
            except Exception as e:
                self._logger.debug(f"Redis ping failed (attempt {attempt + 1}/{max_attempts}): {e}")

            await self._delay(delay_ms)

        raise LeaseTimeoutException(f"Redis did not respond within {max_attempts * delay_ms}ms")

    async def lease_table_exists(self) -> bool:
        """Check if the lease table exists."""
        try:
            await self._redis.ping()
            return True
        except Exception:
            return False

    async def list_leases(self) -> list[Lease]:
        """List all leases from Redis."""
        leases: list[Lease] = []
        pattern = f"{self._key_prefix}*"

        try:
            # Use SCAN for large datasets to avoid blocking
            cursor = 0
            all_keys: list[str] = []

            while True:
                cursor, keys = await self._redis.scan(cursor, match=pattern, count=100)
                all_keys.extend(keys)
                if cursor == 0:
                    break

            # Fetch all lease data
            for key in all_keys:
                data = await self._redis.get(key)
                if data:
                    try:
                        lease = self._deserialize_lease(data)
                        leases.append(lease)
                    except Exception as e:
                        self._logger.warning(f"Failed to deserialize lease from key {key}: {e}")

            return leases
        except Exception as e:
            raise LeaseException(
                f"Failed to list leases from Redis: {e}",
                retryable=True,
                cause=e,
            )

    async def get_lease(self, lease_key: str) -> Lease | None:
        """Get a specific lease by key."""
        try:
            key = self._get_lease_key(lease_key)
            data = await self._redis.get(key)

            if not data:
                return None

            return self._deserialize_lease(data)
        except Exception as e:
            raise LeaseException(
                f"Failed to get lease {lease_key} from Redis: {e}",
                retryable=True,
                cause=e,
            )

    async def create_lease(self, lease: Lease) -> bool:
        """
        Create a new lease.
        Uses NX (Not eXists) to ensure atomic creation.
        """
        try:
            key = self._get_lease_key(lease.lease_key)
            data = self._serialize_lease(lease)

            # Use NX to only set if key doesn't exist
            result = await self._redis.set(key, data, nx=True)

            if result:
                self._logger.debug(f"Created lease {lease.lease_key} in Redis")
                return True

            # Key already exists
            return False
        except Exception as e:
            raise LeaseException(
                f"Failed to create lease {lease.lease_key} in Redis: {e}",
                retryable=True,
                cause=e,
            )

    async def renew_lease(self, lease: Lease) -> bool:
        """
        Renew a lease (increment counter and update timestamp).
        Uses optimistic locking with WATCH/MULTI/EXEC.
        """
        key = self._get_lease_key(lease.lease_key)

        for attempt in range(self.MAX_RETRIES):
            try:
                # Watch the key for changes
                await self._redis.watch(key)

                # Get current lease
                current_data = await self._redis.get(key)
                if not current_data:
                    await self._redis.unwatch()
                    self._logger.debug(f"Lease {lease.lease_key} not found during renewal")
                    return False

                current_lease = self._deserialize_lease(current_data)

                # Verify ownership and counter
                owner_mismatch = current_lease.lease_owner != lease.lease_owner
                counter_mismatch = current_lease.lease_counter != lease.lease_counter
                if owner_mismatch or counter_mismatch:
                    await self._redis.unwatch()
                    self._logger.debug(f"Lease {lease.lease_key} was modified by another worker")
                    return False

                # Update lease
                now = int(time.time() * 1_000_000_000)  # Nanos
                updated_lease = Lease(
                    lease_key=current_lease.lease_key,
                    lease_owner=current_lease.lease_owner,
                    lease_counter=current_lease.lease_counter + 1,
                    last_counter_increment_nanos=now,
                    checkpoint=current_lease.checkpoint,
                    pending_checkpoint=current_lease.pending_checkpoint,
                    owner_switches_since_checkpoint=current_lease.owner_switches_since_checkpoint,
                    parent_shard_ids=current_lease.parent_shard_ids,
                    child_shard_ids=current_lease.child_shard_ids,
                )

                # Execute atomic update
                pipe = self._redis.multi()
                pipe.set(key, self._serialize_lease(updated_lease))
                results = await pipe.execute()

                if results is None:
                    # Transaction was aborted due to WATCH - retry
                    self._logger.debug(f"Lease {lease.lease_key} renewal transaction aborted, retrying...")
                    continue

                # Update the local lease object
                lease.lease_counter = updated_lease.lease_counter
                lease.last_counter_increment_nanos = updated_lease.last_counter_increment_nanos

                return True
            except Exception as e:
                try:
                    await self._redis.unwatch()
                except Exception:
                    pass

                if attempt == self.MAX_RETRIES - 1:
                    raise LeaseException(
                        f"Failed to renew lease {lease.lease_key} after {self.MAX_RETRIES} attempts: {e}",
                        retryable=True,
                        cause=e,
                    )
                await self._delay(
                    calculate_backoff_with_jitter(
                        attempt,
                        BackoffConfig(
                            base_delay_ms=self.BASE_DELAY_MS, max_delay_ms=5000, jitter_type=JitterType.EQUAL
                        ),
                    )
                )

        return False

    async def take_lease(self, lease: Lease, new_owner: str) -> bool:
        """Take a lease from another worker."""
        key = self._get_lease_key(lease.lease_key)

        for attempt in range(self.MAX_RETRIES):
            try:
                await self._redis.watch(key)

                current_data = await self._redis.get(key)
                if not current_data:
                    await self._redis.unwatch()
                    return False

                current_lease = self._deserialize_lease(current_data)

                # Verify counter matches
                if current_lease.lease_counter != lease.lease_counter:
                    await self._redis.unwatch()
                    self._logger.debug(f"Lease {lease.lease_key} counter mismatch during take")
                    return False

                # If lease has an owner, verify it matches
                if lease.lease_owner and current_lease.lease_owner != lease.lease_owner:
                    await self._redis.unwatch()
                    self._logger.debug(f"Lease {lease.lease_key} owner mismatch during take")
                    return False

                now = int(time.time() * 1_000_000_000)
                updated_lease = Lease(
                    lease_key=current_lease.lease_key,
                    lease_owner=new_owner,
                    lease_counter=current_lease.lease_counter + 1,
                    last_counter_increment_nanos=now,
                    checkpoint=current_lease.checkpoint,
                    pending_checkpoint=current_lease.pending_checkpoint,
                    owner_switches_since_checkpoint=(current_lease.owner_switches_since_checkpoint or 0) + 1,
                    parent_shard_ids=current_lease.parent_shard_ids,
                    child_shard_ids=current_lease.child_shard_ids,
                )

                pipe = self._redis.multi()
                pipe.set(key, self._serialize_lease(updated_lease))
                results = await pipe.execute()

                if results is None:
                    self._logger.debug(f"Lease {lease.lease_key} take transaction aborted, retrying...")
                    continue

                # Update local lease
                lease.lease_owner = updated_lease.lease_owner
                lease.lease_counter = updated_lease.lease_counter
                lease.last_counter_increment_nanos = updated_lease.last_counter_increment_nanos
                lease.owner_switches_since_checkpoint = updated_lease.owner_switches_since_checkpoint

                self._logger.info(f"Successfully took lease {lease.lease_key}")
                return True
            except Exception as e:
                try:
                    await self._redis.unwatch()
                except Exception:
                    pass

                if attempt == self.MAX_RETRIES - 1:
                    raise LeaseException(
                        f"Failed to take lease {lease.lease_key}: {e}",
                        retryable=True,
                        cause=e,
                    )
                await self._delay(calculate_backoff_with_jitter(attempt))

        return False

    async def evict_lease(self, lease: Lease) -> bool:
        """Evict the current owner from a lease."""
        key = self._get_lease_key(lease.lease_key)

        try:
            await self._redis.watch(key)

            current_data = await self._redis.get(key)
            if not current_data:
                await self._redis.unwatch()
                return False

            current_lease = self._deserialize_lease(current_data)

            if current_lease.lease_counter != lease.lease_counter:
                await self._redis.unwatch()
                return False

            now = int(time.time() * 1_000_000_000)
            updated_lease = Lease(
                lease_key=current_lease.lease_key,
                lease_owner=None,
                lease_counter=current_lease.lease_counter + 1,
                last_counter_increment_nanos=now,
                checkpoint=current_lease.checkpoint,
                pending_checkpoint=current_lease.pending_checkpoint,
                owner_switches_since_checkpoint=current_lease.owner_switches_since_checkpoint,
                parent_shard_ids=current_lease.parent_shard_ids,
                child_shard_ids=current_lease.child_shard_ids,
            )

            pipe = self._redis.multi()
            pipe.set(key, self._serialize_lease(updated_lease))
            results = await pipe.execute()

            if results is None:
                return False

            lease.lease_owner = None
            lease.lease_counter = updated_lease.lease_counter
            lease.last_counter_increment_nanos = updated_lease.last_counter_increment_nanos

            return True
        except Exception as e:
            try:
                await self._redis.unwatch()
            except Exception:
                pass
            raise LeaseException(
                f"Failed to evict lease {lease.lease_key}: {e}",
                retryable=True,
                cause=e,
            )

    async def update_lease(self, lease: Lease) -> bool:
        """Update a lease (e.g., for checkpointing)."""
        key = self._get_lease_key(lease.lease_key)

        for attempt in range(self.MAX_RETRIES):
            try:
                await self._redis.watch(key)

                current_data = await self._redis.get(key)
                if not current_data:
                    await self._redis.unwatch()
                    raise LeaseConditionalCheckFailedException(
                        f"Lease {lease.lease_key} not found during update",
                        lease.lease_key,
                    )

                current_lease = self._deserialize_lease(current_data)

                # Verify ownership and counter
                owner_mismatch = current_lease.lease_owner != lease.lease_owner
                counter_mismatch = current_lease.lease_counter != lease.lease_counter
                if owner_mismatch or counter_mismatch:
                    await self._redis.unwatch()
                    raise LeaseConditionalCheckFailedException(
                        f"Lease {lease.lease_key} was modified - conditional check failed",
                        lease.lease_key,
                    )

                now = int(time.time() * 1_000_000_000)
                owner_switches = 0 if lease.checkpoint else current_lease.owner_switches_since_checkpoint
                updated_lease = Lease(
                    lease_key=current_lease.lease_key,
                    lease_owner=current_lease.lease_owner,
                    lease_counter=current_lease.lease_counter + 1,
                    last_counter_increment_nanos=now,
                    checkpoint=lease.checkpoint,
                    pending_checkpoint=lease.pending_checkpoint,
                    owner_switches_since_checkpoint=owner_switches,
                    parent_shard_ids=current_lease.parent_shard_ids,
                    child_shard_ids=lease.child_shard_ids,
                )

                pipe = self._redis.multi()
                pipe.set(key, self._serialize_lease(updated_lease))
                results = await pipe.execute()

                if results is None:
                    self._logger.debug(f"Lease {lease.lease_key} update transaction aborted, retrying...")
                    continue

                # Update local lease
                lease.lease_counter = updated_lease.lease_counter
                lease.last_counter_increment_nanos = updated_lease.last_counter_increment_nanos
                if lease.checkpoint:
                    lease.owner_switches_since_checkpoint = 0

                return True
            except LeaseConditionalCheckFailedException:
                raise
            except Exception as e:
                try:
                    await self._redis.unwatch()
                except Exception:
                    pass

                if attempt == self.MAX_RETRIES - 1:
                    raise LeaseException(
                        f"Failed to update lease {lease.lease_key}: {e}",
                        retryable=True,
                        cause=e,
                    )
                await self._delay(calculate_backoff_with_jitter(attempt))

        return False

    async def delete_lease(self, lease: Lease) -> bool:
        """Delete a lease."""
        key = self._get_lease_key(lease.lease_key)

        try:
            await self._redis.watch(key)

            current_data = await self._redis.get(key)
            if not current_data:
                await self._redis.unwatch()
                return True  # Already deleted

            current_lease = self._deserialize_lease(current_data)

            if current_lease.lease_counter != lease.lease_counter:
                await self._redis.unwatch()
                return False

            pipe = self._redis.multi()
            pipe.delete(key)
            results = await pipe.execute()

            return results is not None
        except Exception as e:
            try:
                await self._redis.unwatch()
            except Exception:
                pass
            raise LeaseException(
                f"Failed to delete lease {lease.lease_key}: {e}",
                retryable=True,
                cause=e,
            )

    async def delete_all_leases(self) -> None:
        """Delete all leases (for cleanup)."""
        pattern = f"{self._key_prefix}*"

        try:
            cursor = 0
            while True:
                cursor, keys = await self._redis.scan(cursor, match=pattern, count=100)

                if keys:
                    await self._redis.delete(*keys)

                if cursor == 0:
                    break

            self._logger.info(f"Deleted all leases with prefix {self._key_prefix}")
        except Exception as e:
            self._logger.warning(f"Failed to delete all leases: {e}")

    def is_lease_expired(self, lease: Lease, lease_duration_millis: int) -> bool:
        """Check if a lease is expired."""
        if not lease.last_counter_increment_nanos:
            return True

        last_update_millis = lease.last_counter_increment_nanos / 1_000_000
        now = time.time() * 1000

        return (now - last_update_millis) > lease_duration_millis

    async def health_check(self) -> PersistenceHealthCheckResult:
        """Perform a health check."""
        start_time = time.time()

        try:
            pong = await self._redis.ping()
            latency_ms = (time.time() - start_time) * 1000

            return PersistenceHealthCheckResult(
                healthy=pong == "PONG" or pong is True,
                type="redis",
                latency_ms=latency_ms,
                details={
                    "key_prefix": self._key_prefix,
                },
            )
        except Exception as e:
            latency_ms = (time.time() - start_time) * 1000
            return PersistenceHealthCheckResult(
                healthy=False,
                type="redis",
                latency_ms=latency_ms,
                error=str(e),
            )

    def _serialize_lease(self, lease: Lease) -> str:
        """Serialize a lease to JSON string."""
        data = {
            "lease_key": lease.lease_key,
            "lease_owner": lease.lease_owner,
            "lease_counter": lease.lease_counter,
            "last_counter_increment_nanos": lease.last_counter_increment_nanos,
            "owner_switches_since_checkpoint": lease.owner_switches_since_checkpoint,
            "parent_shard_ids": lease.parent_shard_ids,
            "child_shard_ids": lease.child_shard_ids,
        }

        if lease.checkpoint:
            data["checkpoint"] = {
                "sequence_number": lease.checkpoint.sequence_number,
                "sub_sequence_number": lease.checkpoint.sub_sequence_number,
            }

        if lease.pending_checkpoint:
            data["pending_checkpoint"] = {
                "sequence_number": lease.pending_checkpoint.sequence_number,
                "sub_sequence_number": lease.pending_checkpoint.sub_sequence_number,
            }

        return json.dumps(data)

    def _deserialize_lease(self, data: str) -> Lease:
        """Deserialize a lease from JSON string."""
        from ..types import ExtendedSequenceNumber

        lease_data = json.loads(data)

        checkpoint = None
        if lease_data.get("checkpoint"):
            checkpoint = ExtendedSequenceNumber(
                sequence_number=lease_data["checkpoint"]["sequence_number"],
                sub_sequence_number=lease_data["checkpoint"].get("sub_sequence_number", 0),
            )

        pending_checkpoint = None
        if lease_data.get("pending_checkpoint"):
            pending_checkpoint = ExtendedSequenceNumber(
                sequence_number=lease_data["pending_checkpoint"]["sequence_number"],
                sub_sequence_number=lease_data["pending_checkpoint"].get("sub_sequence_number", 0),
            )

        return Lease(
            lease_key=lease_data["lease_key"],
            lease_owner=lease_data.get("lease_owner"),
            lease_counter=lease_data.get("lease_counter", 0),
            last_counter_increment_nanos=lease_data.get("last_counter_increment_nanos"),
            checkpoint=checkpoint,
            pending_checkpoint=pending_checkpoint,
            owner_switches_since_checkpoint=lease_data.get("owner_switches_since_checkpoint", 0),
            parent_shard_ids=lease_data.get("parent_shard_ids"),
            child_shard_ids=lease_data.get("child_shard_ids"),
        )

    async def _delay(self, ms: float) -> None:
        """Helper to delay execution."""
        import asyncio

        await asyncio.sleep(ms / 1000)
