"""
SQL-based implementation of LeaseRefresher.

This implementation uses PostgreSQL or MySQL for storing lease and checkpoint information.
It uses a version column for optimistic concurrency control (OCC).

Features:
- Optimistic locking using version column
- Atomic updates with WHERE version = X clause
- Connection pooling support
- Auto-creation of lease table
"""

import json
import logging
import time
from dataclasses import dataclass
from typing import Any, Literal, Protocol

from ..exceptions import (
    LeaseConditionalCheckFailedException,
    LeaseException,
    LeaseTimeoutException,
)
from ..types import Lease, LeaseRefresher
from ..utils import BackoffConfig, JitterType, calculate_backoff_with_jitter
from .interfaces import PersistenceHealthCheckResult

SQLDialect = Literal["postgresql", "mysql"]


class SQLClientProtocol(Protocol):
    """Protocol for SQL client interface."""

    async def execute(self, query: str, *args: Any) -> Any: ...
    async def fetch(self, query: str, *args: Any) -> list[dict[str, Any]]: ...
    async def fetchrow(self, query: str, *args: Any) -> dict[str, Any] | None: ...


@dataclass
class SQLLeaseRefresherConfig:
    """Configuration for the SQL lease refresher."""

    dialect: SQLDialect
    """SQL dialect (postgresql or mysql)"""

    table_name: str
    """Table name for leases"""

    application_name: str
    """Application name"""

    worker_identifier: str
    """Worker identifier"""

    lease_duration_millis: int
    """Lease duration in milliseconds"""

    schema: str = "public"
    """Schema name (for PostgreSQL)"""

    auto_create_table: bool = True
    """Auto-create table if not exists"""


class SQLLeaseRefresher(LeaseRefresher):
    """
    SQL-based implementation of LeaseRefresher.

    Uses a version column for optimistic concurrency control:
    - Each update increments the version
    - Updates include WHERE version = X to detect concurrent modifications
    - If rowcount === 0, the version changed (conflict detected)
    """

    _logger = logging.getLogger("kcl.SQLLeaseRefresher")

    MAX_RETRIES = 3
    BASE_DELAY_MS = 100

    def __init__(self, client: Any, config: SQLLeaseRefresherConfig):
        """
        Initialize the SQL lease refresher.

        Args:
            client: An async database client (asyncpg, aiomysql, etc.)
            config: Configuration for the lease refresher
        """
        self._client = client
        self._config = config

        # Build full table name with schema for PostgreSQL
        if config.dialect == "postgresql" and config.schema:
            self._full_table_name = f'"{config.schema}"."{config.table_name}"'
        else:
            self._full_table_name = config.table_name

    def _placeholder(self, index: int) -> str:
        """Get placeholder syntax for the dialect."""
        return f"${index}" if self._config.dialect == "postgresql" else "%s"

    async def create_lease_table_if_not_exists(self) -> bool:
        """Create the lease table if it doesn't exist."""
        if not self._config.auto_create_table:
            return False

        try:
            create_table_sql = self._get_create_table_sql()
            await self._client.execute(create_table_sql)
            self._logger.info(f"Lease table '{self._full_table_name}' verified/created")
            return True
        except Exception as e:
            raise LeaseException(
                f"Failed to create lease table: {e}",
                retryable=False,
                cause=e,
            )

    def _get_create_table_sql(self) -> str:
        """Get CREATE TABLE SQL for the dialect."""
        if self._config.dialect == "postgresql":
            return f"""
                CREATE TABLE IF NOT EXISTS {self._full_table_name} (
                    lease_key VARCHAR(255) PRIMARY KEY,
                    lease_owner VARCHAR(255),
                    lease_counter BIGINT DEFAULT 0,
                    checkpoint TEXT,
                    checkpoint_sub_sequence_number BIGINT,
                    pending_checkpoint TEXT,
                    pending_checkpoint_sub_sequence_number BIGINT,
                    owner_switches_since_checkpoint BIGINT DEFAULT 0,
                    parent_shard_ids TEXT,
                    child_shard_ids TEXT,
                    last_counter_increment_nanos BIGINT,
                    hash_key_range_start VARCHAR(255),
                    hash_key_range_end VARCHAR(255),
                    version INT DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """
        else:
            # MySQL
            return f"""
                CREATE TABLE IF NOT EXISTS {self._full_table_name} (
                    lease_key VARCHAR(255) PRIMARY KEY,
                    lease_owner VARCHAR(255),
                    lease_counter BIGINT DEFAULT 0,
                    checkpoint TEXT,
                    checkpoint_sub_sequence_number BIGINT,
                    pending_checkpoint TEXT,
                    pending_checkpoint_sub_sequence_number BIGINT,
                    owner_switches_since_checkpoint BIGINT DEFAULT 0,
                    parent_shard_ids TEXT,
                    child_shard_ids TEXT,
                    last_counter_increment_nanos BIGINT,
                    hash_key_range_start VARCHAR(255),
                    hash_key_range_end VARCHAR(255),
                    version INT DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """

    async def wait_for_table_active(self) -> None:
        """Wait for the lease table to become active."""
        max_attempts = 10
        delay_ms = 500

        for attempt in range(max_attempts):
            try:
                exists = await self.lease_table_exists()
                if exists:
                    return
            except Exception as e:
                self._logger.debug(f"Table check failed (attempt {attempt + 1}/{max_attempts}): {e}")

            await self._delay(delay_ms)

        raise LeaseTimeoutException(
            f"Lease table '{self._full_table_name}' not available within {max_attempts * delay_ms}ms"
        )

    async def lease_table_exists(self) -> bool:
        """Check if the lease table exists."""
        try:
            if self._config.dialect == "postgresql":
                sql = """
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables
                        WHERE table_schema = $1 AND table_name = $2
                    )
                """
                result = await self._client.fetchrow(sql, self._config.schema or "public", self._config.table_name)
                return result and result.get("exists", False)
            else:
                sql = """
                    SELECT COUNT(*) as cnt FROM information_schema.tables
                    WHERE table_name = %s
                """
                result = await self._client.fetchrow(sql, self._config.table_name)
                return result and result.get("cnt", 0) > 0
        except Exception:
            return False

    async def list_leases(self) -> list[Lease]:
        """List all leases from the database."""
        try:
            sql = f"SELECT * FROM {self._full_table_name}"
            rows = await self._client.fetch(sql)
            return [self._row_to_lease(row) for row in rows]
        except Exception as e:
            raise LeaseException(
                f"Failed to list leases: {e}",
                retryable=True,
                cause=e,
            )

    async def get_lease(self, lease_key: str) -> Lease | None:
        """Get a specific lease by key."""
        try:
            sql = f"SELECT * FROM {self._full_table_name} WHERE lease_key = {self._placeholder(1)}"
            row = await self._client.fetchrow(sql, lease_key)

            if not row:
                return None

            return self._row_to_lease(row)
        except Exception as e:
            raise LeaseException(
                f"Failed to get lease {lease_key}: {e}",
                retryable=True,
                cause=e,
            )

    async def create_lease(self, lease: Lease) -> bool:
        """Create a new lease."""
        try:
            if self._config.dialect == "postgresql":
                sql = f"""
                    INSERT INTO {self._full_table_name} (
                        lease_key, lease_owner, lease_counter, checkpoint, checkpoint_sub_sequence_number,
                        pending_checkpoint, pending_checkpoint_sub_sequence_number, owner_switches_since_checkpoint,
                        parent_shard_ids, child_shard_ids, last_counter_increment_nanos,
                        hash_key_range_start, hash_key_range_end, version
                    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, 1)
                    ON CONFLICT (lease_key) DO NOTHING
                """
            else:
                sql = f"""
                    INSERT IGNORE INTO {self._full_table_name} (
                        lease_key, lease_owner, lease_counter, checkpoint, checkpoint_sub_sequence_number,
                        pending_checkpoint, pending_checkpoint_sub_sequence_number, owner_switches_since_checkpoint,
                        parent_shard_ids, child_shard_ids, last_counter_increment_nanos,
                        hash_key_range_start, hash_key_range_end, version
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 1)
                """

            params = [
                lease.lease_key,
                lease.lease_owner,
                lease.lease_counter or 0,
                lease.checkpoint.sequence_number if lease.checkpoint else None,
                lease.checkpoint.sub_sequence_number if lease.checkpoint else None,
                lease.pending_checkpoint.sequence_number if lease.pending_checkpoint else None,
                lease.pending_checkpoint.sub_sequence_number if lease.pending_checkpoint else None,
                lease.owner_switches_since_checkpoint or 0,
                json.dumps(lease.parent_shard_ids) if lease.parent_shard_ids else None,
                json.dumps(lease.child_shard_ids) if lease.child_shard_ids else None,
                lease.last_counter_increment_nanos,
                getattr(lease, "hash_key_range_start", None),
                getattr(lease, "hash_key_range_end", None),
            ]

            result = await self._client.execute(sql, *params)

            # Check if row was inserted
            if hasattr(result, "rowcount"):
                if result.rowcount > 0:
                    self._logger.debug(f"Created lease {lease.lease_key}")
                    return True
                return False

            # For asyncpg, result is a string like "INSERT 0 1"
            if isinstance(result, str) and "INSERT" in result:
                parts = result.split()
                if len(parts) >= 3 and int(parts[2]) > 0:
                    self._logger.debug(f"Created lease {lease.lease_key}")
                    return True

            return False
        except Exception as e:
            raise LeaseException(
                f"Failed to create lease {lease.lease_key}: {e}",
                retryable=True,
                cause=e,
            )

    async def renew_lease(self, lease: Lease) -> bool:
        """Renew a lease (increment counter and update timestamp)."""
        for attempt in range(self.MAX_RETRIES):
            try:
                # Get current lease with version
                current_lease = await self.get_lease(lease.lease_key)
                if not current_lease:
                    self._logger.debug(f"Lease {lease.lease_key} not found during renewal")
                    return False

                # Verify ownership and counter
                owner_mismatch = current_lease.lease_owner != lease.lease_owner
                counter_mismatch = current_lease.lease_counter != lease.lease_counter
                if owner_mismatch or counter_mismatch:
                    self._logger.debug(f"Lease {lease.lease_key} was modified by another worker")
                    return False

                version = getattr(current_lease, "version", 1)
                now = int(time.time() * 1_000_000_000)  # Nanos
                new_counter = (current_lease.lease_counter or 0) + 1

                # Atomic update with version check
                if self._config.dialect == "postgresql":
                    sql = f"""
                        UPDATE {self._full_table_name}
                        SET lease_counter = $1, last_counter_increment_nanos = $2,
                            version = version + 1, updated_at = CURRENT_TIMESTAMP
                        WHERE lease_key = $3 AND version = $4
                    """
                else:
                    sql = f"""
                        UPDATE {self._full_table_name}
                        SET lease_counter = %s, last_counter_increment_nanos = %s, version = version + 1
                        WHERE lease_key = %s AND version = %s
                    """

                result = await self._client.execute(sql, new_counter, now, lease.lease_key, version)

                rowcount = self._get_rowcount(result)
                if rowcount == 0:
                    self._logger.debug(
                        f"Lease {lease.lease_key} renewal failed due to concurrent " "modification, retrying..."
                    )
                    backoff_config = BackoffConfig(
                        base_delay_ms=self.BASE_DELAY_MS, max_delay_ms=5000, jitter_type=JitterType.EQUAL
                    )
                    await self._delay(calculate_backoff_with_jitter(attempt, backoff_config))
                    continue

                # Update local lease
                lease.lease_counter = new_counter
                lease.last_counter_increment_nanos = now

                return True
            except Exception as e:
                if attempt == self.MAX_RETRIES - 1:
                    raise LeaseException(
                        f"Failed to renew lease {lease.lease_key} after {self.MAX_RETRIES} attempts: {e}",
                        retryable=True,
                        cause=e,
                    )
                await self._delay(calculate_backoff_with_jitter(attempt))

        return False

    async def take_lease(self, lease: Lease, new_owner: str) -> bool:
        """Take a lease from another worker."""
        for attempt in range(self.MAX_RETRIES):
            try:
                current_lease = await self.get_lease(lease.lease_key)
                if not current_lease:
                    return False

                # Verify counter matches
                if current_lease.lease_counter != lease.lease_counter:
                    self._logger.debug(f"Lease {lease.lease_key} counter mismatch during take")
                    return False

                # If lease has an owner, verify it matches
                if lease.lease_owner and current_lease.lease_owner != lease.lease_owner:
                    self._logger.debug(f"Lease {lease.lease_key} owner mismatch during take")
                    return False

                version = getattr(current_lease, "version", 1)
                now = int(time.time() * 1_000_000_000)
                new_counter = (current_lease.lease_counter or 0) + 1
                owner_switches = (current_lease.owner_switches_since_checkpoint or 0) + 1

                if self._config.dialect == "postgresql":
                    sql = f"""
                        UPDATE {self._full_table_name}
                        SET lease_owner = $1, lease_counter = $2, last_counter_increment_nanos = $3,
                            owner_switches_since_checkpoint = $4, version = version + 1, updated_at = CURRENT_TIMESTAMP
                        WHERE lease_key = $5 AND version = $6
                    """
                else:
                    sql = f"""
                        UPDATE {self._full_table_name}
                        SET lease_owner = %s, lease_counter = %s, last_counter_increment_nanos = %s,
                            owner_switches_since_checkpoint = %s, version = version + 1
                        WHERE lease_key = %s AND version = %s
                    """

                result = await self._client.execute(
                    sql, new_owner, new_counter, now, owner_switches, lease.lease_key, version
                )

                rowcount = self._get_rowcount(result)
                if rowcount == 0:
                    self._logger.debug(
                        f"Lease {lease.lease_key} take failed due to concurrent modification, retrying..."
                    )
                    await self._delay(calculate_backoff_with_jitter(attempt))
                    continue

                # Update local lease
                lease.lease_owner = new_owner
                lease.lease_counter = new_counter
                lease.last_counter_increment_nanos = now
                lease.owner_switches_since_checkpoint = owner_switches

                self._logger.info(f"Successfully took lease {lease.lease_key}")
                return True
            except Exception as e:
                if attempt == self.MAX_RETRIES - 1:
                    raise LeaseException(
                        f"Failed to take lease {lease.lease_key}: {e}",
                        retryable=True,
                        cause=e,
                    )
                await self._delay(calculate_backoff_with_jitter(attempt))

        return False

    async def evict_lease(self, lease: Lease) -> bool:
        """Evict the current owner from a lease."""
        try:
            current_lease = await self.get_lease(lease.lease_key)
            if not current_lease:
                return False

            if current_lease.lease_counter != lease.lease_counter:
                return False

            version = getattr(current_lease, "version", 1)
            now = int(time.time() * 1_000_000_000)
            new_counter = (current_lease.lease_counter or 0) + 1

            if self._config.dialect == "postgresql":
                sql = f"""
                    UPDATE {self._full_table_name}
                    SET lease_owner = NULL, lease_counter = $1, last_counter_increment_nanos = $2,
                        version = version + 1, updated_at = CURRENT_TIMESTAMP
                    WHERE lease_key = $3 AND version = $4
                """
            else:
                sql = f"""
                    UPDATE {self._full_table_name}
                    SET lease_owner = NULL, lease_counter = %s, last_counter_increment_nanos = %s,
                        version = version + 1
                    WHERE lease_key = %s AND version = %s
                """

            result = await self._client.execute(sql, new_counter, now, lease.lease_key, version)

            rowcount = self._get_rowcount(result)
            if rowcount == 0:
                return False

            lease.lease_owner = None
            lease.lease_counter = new_counter
            lease.last_counter_increment_nanos = now

            return True
        except Exception as e:
            raise LeaseException(
                f"Failed to evict lease {lease.lease_key}: {e}",
                retryable=True,
                cause=e,
            )

    async def update_lease(self, lease: Lease) -> bool:
        """Update a lease (e.g., for checkpointing)."""
        for attempt in range(self.MAX_RETRIES):
            try:
                current_lease = await self.get_lease(lease.lease_key)
                if not current_lease:
                    raise LeaseConditionalCheckFailedException(
                        f"Lease {lease.lease_key} not found during update",
                        lease.lease_key,
                    )

                # Verify ownership and counter
                owner_mismatch = current_lease.lease_owner != lease.lease_owner
                counter_mismatch = current_lease.lease_counter != lease.lease_counter
                if owner_mismatch or counter_mismatch:
                    raise LeaseConditionalCheckFailedException(
                        f"Lease {lease.lease_key} was modified - conditional check failed",
                        lease.lease_key,
                    )

                version = getattr(current_lease, "version", 1)
                now = int(time.time() * 1_000_000_000)
                new_counter = (current_lease.lease_counter or 0) + 1
                owner_switches = 0 if lease.checkpoint else (current_lease.owner_switches_since_checkpoint or 0)

                if self._config.dialect == "postgresql":
                    sql = f"""
                        UPDATE {self._full_table_name}
                        SET lease_counter = $1, last_counter_increment_nanos = $2,
                            checkpoint = $3, checkpoint_sub_sequence_number = $4,
                            pending_checkpoint = $5, pending_checkpoint_sub_sequence_number = $6,
                            child_shard_ids = $7, owner_switches_since_checkpoint = $8,
                            version = version + 1, updated_at = CURRENT_TIMESTAMP
                        WHERE lease_key = $9 AND version = $10
                    """
                else:
                    sql = f"""
                        UPDATE {self._full_table_name}
                        SET lease_counter = %s, last_counter_increment_nanos = %s,
                            checkpoint = %s, checkpoint_sub_sequence_number = %s,
                            pending_checkpoint = %s, pending_checkpoint_sub_sequence_number = %s,
                            child_shard_ids = %s, owner_switches_since_checkpoint = %s,
                            version = version + 1
                        WHERE lease_key = %s AND version = %s
                    """

                params = [
                    new_counter,
                    now,
                    lease.checkpoint.sequence_number if lease.checkpoint else None,
                    lease.checkpoint.sub_sequence_number if lease.checkpoint else None,
                    lease.pending_checkpoint.sequence_number if lease.pending_checkpoint else None,
                    lease.pending_checkpoint.sub_sequence_number if lease.pending_checkpoint else None,
                    json.dumps(lease.child_shard_ids) if lease.child_shard_ids else None,
                    owner_switches,
                    lease.lease_key,
                    version,
                ]

                result = await self._client.execute(sql, *params)

                rowcount = self._get_rowcount(result)
                if rowcount == 0:
                    self._logger.debug(
                        f"Lease {lease.lease_key} update failed due to concurrent modification, retrying..."
                    )
                    await self._delay(calculate_backoff_with_jitter(attempt))
                    continue

                # Update local lease
                lease.lease_counter = new_counter
                lease.last_counter_increment_nanos = now
                if lease.checkpoint:
                    lease.owner_switches_since_checkpoint = 0

                return True
            except LeaseConditionalCheckFailedException:
                raise
            except Exception as e:
                if attempt == self.MAX_RETRIES - 1:
                    raise LeaseException(
                        f"Failed to update lease {lease.lease_key}: {e}",
                        retryable=True,
                        cause=e,
                    )
                await self._delay(calculate_backoff_with_jitter(attempt))

        return False

    async def delete_lease(self, lease: Lease) -> bool:
        """Delete a lease."""
        try:
            current_lease = await self.get_lease(lease.lease_key)
            if not current_lease:
                return True  # Already deleted

            if current_lease.lease_counter != lease.lease_counter:
                return False

            version = getattr(current_lease, "version", 1)

            if self._config.dialect == "postgresql":
                sql = f"DELETE FROM {self._full_table_name} WHERE lease_key = $1 AND version = $2"
            else:
                sql = f"DELETE FROM {self._full_table_name} WHERE lease_key = %s AND version = %s"

            result = await self._client.execute(sql, lease.lease_key, version)

            return self._get_rowcount(result) > 0
        except Exception as e:
            raise LeaseException(
                f"Failed to delete lease {lease.lease_key}: {e}",
                retryable=True,
                cause=e,
            )

    async def delete_all_leases(self) -> None:
        """Delete all leases (for cleanup)."""
        try:
            await self._client.execute(f"DELETE FROM {self._full_table_name}")
            self._logger.info(f"Deleted all leases from {self._full_table_name}")
        except Exception as e:
            self._logger.warning(f"Failed to delete all leases: {e}")

    def is_lease_expired(self, lease: Lease, lease_duration_millis: int) -> bool:
        """Check if a lease is expired."""
        if not lease.last_counter_increment_nanos:
            return True

        last_update_millis = lease.last_counter_increment_nanos / 1_000_000
        now = time.time() * 1000

        return (now - last_update_millis) > lease_duration_millis

    async def health_check(self) -> PersistenceHealthCheckResult:
        """Perform a health check."""
        start_time = time.time()

        try:
            await self._client.fetch("SELECT 1")
            latency_ms = (time.time() - start_time) * 1000

            return PersistenceHealthCheckResult(
                healthy=True,
                type=self._config.dialect,
                latency_ms=latency_ms,
                details={
                    "dialect": self._config.dialect,
                    "table": self._full_table_name,
                },
            )
        except Exception as e:
            latency_ms = (time.time() - start_time) * 1000
            return PersistenceHealthCheckResult(
                healthy=False,
                type=self._config.dialect,
                latency_ms=latency_ms,
                error=str(e),
            )

    def _get_rowcount(self, result: Any) -> int:
        """Get the rowcount from a result."""
        if hasattr(result, "rowcount"):
            return result.rowcount

        # For asyncpg, result is a string like "UPDATE 1" or "DELETE 1"
        if isinstance(result, str):
            parts = result.split()
            if len(parts) >= 2:
                try:
                    return int(parts[-1])
                except ValueError:
                    pass

        return 0

    def _row_to_lease(self, row: dict[str, Any]) -> Lease:
        """Convert a database row to a Lease object."""
        from ..types import ExtendedSequenceNumber

        checkpoint = None
        if row.get("checkpoint"):
            checkpoint = ExtendedSequenceNumber(
                sequence_number=row["checkpoint"],
                sub_sequence_number=row.get("checkpoint_sub_sequence_number", 0) or 0,
            )

        pending_checkpoint = None
        if row.get("pending_checkpoint"):
            pending_checkpoint = ExtendedSequenceNumber(
                sequence_number=row["pending_checkpoint"],
                sub_sequence_number=row.get("pending_checkpoint_sub_sequence_number", 0) or 0,
            )

        parent_shard_ids = None
        if row.get("parent_shard_ids"):
            try:
                parent_shard_ids = json.loads(row["parent_shard_ids"])
            except (json.JSONDecodeError, TypeError):
                parent_shard_ids = []

        child_shard_ids = None
        if row.get("child_shard_ids"):
            try:
                child_shard_ids = json.loads(row["child_shard_ids"])
            except (json.JSONDecodeError, TypeError):
                child_shard_ids = []

        lease = Lease(
            lease_key=row["lease_key"],
            lease_owner=row.get("lease_owner"),
            lease_counter=int(row.get("lease_counter", 0) or 0),
            last_counter_increment_nanos=(
                int(row["last_counter_increment_nanos"]) if row.get("last_counter_increment_nanos") else None
            ),
            checkpoint=checkpoint,
            pending_checkpoint=pending_checkpoint,
            owner_switches_since_checkpoint=int(row.get("owner_switches_since_checkpoint", 0) or 0),
            parent_shard_ids=parent_shard_ids,
            child_shard_ids=child_shard_ids,
        )

        # Store version on the lease object for optimistic locking
        lease.version = int(row.get("version", 1) or 1)  # type: ignore

        return lease

    async def _delay(self, ms: float) -> None:
        """Helper to delay execution."""
        import asyncio

        await asyncio.sleep(ms / 1000)
