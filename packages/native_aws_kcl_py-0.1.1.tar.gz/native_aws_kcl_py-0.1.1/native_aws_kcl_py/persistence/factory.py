"""
Persistence Factory.

Factory for creating LeaseRefresher instances based on configuration.
Supports multiple storage backends with DynamoDB as the default.
"""

import logging
from dataclasses import dataclass
from typing import Any

from ..types import LeaseRefresher
from .interfaces import PersistenceType

logger = logging.getLogger(__name__)


@dataclass
class CreatePersistenceOptions:
    """Configuration for creating a persistence layer."""

    type: PersistenceType
    """The type of persistence to use (dynamodb, s3, redis, mysql, postgresql, mongodb)."""

    application_name: str
    """Application name (used as table/bucket name)."""

    worker_identifier: str
    """Worker identifier."""

    region: str | None = None
    """AWS region (required for DynamoDB and S3)."""

    lease_duration_millis: int = 10000
    """Lease duration in milliseconds."""

    epsilon_millis: int = 25
    """Epsilon for timing calculations."""

    max_leases_for_worker: int | None = None
    """Maximum leases per worker."""

    max_leases_to_steal_at_one_time: int = 1
    """Maximum leases to steal at once."""

    endpoint: str | None = None
    """Custom endpoint (for local testing)."""

    credentials: dict[str, str] | None = None
    """AWS credentials (optional)."""

    # DynamoDB-specific options
    dynamodb: dict[str, Any] | None = None
    """DynamoDB-specific options (billing_mode, read_capacity_units, write_capacity_units)."""

    # S3-specific options
    s3: dict[str, Any] | None = None
    """S3-specific options (bucket_name, key_prefix, server_side_encryption, etc.)."""

    # Redis-specific options
    redis: dict[str, Any] | None = None
    """Redis-specific options (host, port, password, key_prefix, etc.)."""

    # PostgreSQL-specific options
    postgresql: dict[str, Any] | None = None
    """PostgreSQL-specific options (host, port, database, username, password, etc.)."""

    # MySQL-specific options
    mysql: dict[str, Any] | None = None
    """MySQL-specific options (host, port, database, username, password, etc.)."""

    # MongoDB-specific options
    mongodb: dict[str, Any] | None = None
    """MongoDB-specific options (host, port, database, collection_name, etc.)."""


def parse_persistence_type(type_str: str | None) -> PersistenceType:
    """
    Parse a persistence type string into a PersistenceType.
    Returns 'dynamodb' as default if the string is invalid or empty.

    Supports aliases:
    - DynamoDB: 'dynamodb', 'dynamo', 'ddb'
    - S3: 's3', 'aws-s3'
    - PostgreSQL: 'postgresql', 'postgres'
    - MongoDB: 'mongodb', 'mongo'
    """
    if not type_str:
        return "dynamodb"

    normalized = type_str.lower().strip()

    if normalized in ("dynamodb", "dynamo", "ddb"):
        return "dynamodb"
    elif normalized in ("s3", "aws-s3"):
        return "s3"
    elif normalized == "redis":
        return "redis"
    elif normalized == "mysql":
        return "mysql"
    elif normalized in ("postgresql", "postgres"):
        return "postgresql"
    elif normalized in ("mongodb", "mongo"):
        return "mongodb"
    else:
        logger.warning(f"Unknown persistence type '{type_str}', defaulting to 'dynamodb'")
        return "dynamodb"


def is_persistence_type_supported(type: PersistenceType) -> bool:
    """Check if a persistence type is currently supported (implemented)."""
    return type in ("dynamodb", "redis", "s3", "postgresql", "mysql", "mongodb")


async def create_persistence_async(options: CreatePersistenceOptions) -> LeaseRefresher:
    """
    Create a LeaseRefresher asynchronously.

    Args:
        options: Configuration options for the persistence layer

    Returns:
        A LeaseRefresher instance

    Raises:
        ValueError: If the persistence type is invalid or not supported
        ImportError: If required dependencies are not installed
    """
    persistence_type = options.type

    logger.info(
        f"Creating persistence layer (async): type={persistence_type}, " f"applicationName={options.application_name}"
    )

    if persistence_type == "dynamodb":
        return await _create_dynamodb_persistence(options)
    elif persistence_type == "s3":
        return await _create_s3_persistence(options)
    elif persistence_type == "redis":
        return await _create_redis_persistence(options)
    elif persistence_type == "postgresql":
        return await _create_postgresql_persistence(options)
    elif persistence_type == "mysql":
        return await _create_mysql_persistence(options)
    elif persistence_type == "mongodb":
        return await _create_mongodb_persistence(options)
    elif persistence_type == "custom":
        raise ValueError(
            "Custom persistence type requires providing a LeaseRefresher instance directly. "
            "Use the persistence.lease_refresher configuration option instead."
        )
    else:
        raise ValueError(f"Unknown persistence type: {persistence_type}")


async def _create_dynamodb_persistence(options: CreatePersistenceOptions) -> LeaseRefresher:
    """Create a DynamoDB-based LeaseRefresher."""
    if not options.region:
        raise ValueError("AWS region is required for DynamoDB persistence")

    from ..leases import DynamoDBLeaseRefresher
    from ..types import InitialPositionInStream, InitialPositionInStreamExtended, LeaseManagementConfig

    config = LeaseManagementConfig(
        table_name=options.application_name,
        worker_identifier=options.worker_identifier,
        lease_duration_millis=options.lease_duration_millis,
        epsilon_millis=options.epsilon_millis,
        max_leases_to_steal_at_one_time=options.max_leases_to_steal_at_one_time,
        initial_position_in_stream=InitialPositionInStreamExtended(
            initial_position_in_stream=InitialPositionInStream.TRIM_HORIZON
        ),
        cleanup_leases_upon_shard_completion=True,
    )

    if options.dynamodb:
        if options.dynamodb.get("billing_mode"):
            config.billing_mode = options.dynamodb["billing_mode"]
        if options.dynamodb.get("read_capacity_units"):
            config.read_capacity_units = options.dynamodb["read_capacity_units"]
        if options.dynamodb.get("write_capacity_units"):
            config.write_capacity_units = options.dynamodb["write_capacity_units"]

    logger.info(
        f"DynamoDB persistence configured: table={options.application_name}, "
        f"region={options.region}"
        f"{', endpoint=' + options.endpoint if options.endpoint else ''}"
    )

    return DynamoDBLeaseRefresher(
        config=config,
        region_name=options.region,
        endpoint_url=options.endpoint,
    )


async def _create_s3_persistence(options: CreatePersistenceOptions) -> LeaseRefresher:
    """Create an S3-based LeaseRefresher."""
    try:
        import aioboto3  # type: ignore[import-not-found]
    except ImportError:
        raise ImportError("aioboto3 package is not installed. Please install it: pip install aioboto3")

    if not options.region:
        raise ValueError("AWS region is required for S3 persistence")

    s3_options = options.s3 or {}
    bucket_name = s3_options.get("bucket_name")
    if not bucket_name:
        raise ValueError("S3 bucket name is required. Set s3.bucket_name configuration.")

    from .s3_lease_refresher import S3LeaseRefresher, S3LeaseRefresherConfig

    session = aioboto3.Session()

    client_kwargs: dict[str, Any] = {"region_name": options.region}
    if options.endpoint:
        client_kwargs["endpoint_url"] = options.endpoint
    if options.credentials:
        access_key = options.credentials.get("access_key_id")
        secret_key = options.credentials.get("secret_access_key")
        session_token = options.credentials.get("session_token")
        if access_key:
            client_kwargs["aws_access_key_id"] = access_key
        if secret_key:
            client_kwargs["aws_secret_access_key"] = secret_key
        if session_token:
            client_kwargs["aws_session_token"] = session_token

    # Note: We create the client here but in real usage, you'd manage the async context
    client = await session.client("s3", **client_kwargs).__aenter__()  # type: ignore[attr-defined]

    key_prefix = s3_options.get("key_prefix", "kcl/leases/")

    config = S3LeaseRefresherConfig(
        bucket_name=bucket_name,
        key_prefix=key_prefix,
        application_name=options.application_name,
        worker_identifier=options.worker_identifier,
        lease_duration_millis=options.lease_duration_millis,
        server_side_encryption=s3_options.get("server_side_encryption", True),
        kms_key_id=s3_options.get("kms_key_id"),
        storage_class=s3_options.get("storage_class", "STANDARD"),
    )

    logger.info(
        f"S3 persistence configured: bucket={bucket_name}, "
        f"key_prefix={key_prefix}{options.application_name}/, region={options.region}"
        f"{', endpoint=' + options.endpoint if options.endpoint else ''}"
    )

    return S3LeaseRefresher(client, config)


async def _create_redis_persistence(options: CreatePersistenceOptions) -> LeaseRefresher:
    """Create a Redis-based LeaseRefresher."""
    try:
        import redis.asyncio as aioredis  # type: ignore[import-not-found]
    except ImportError:
        raise ImportError("redis package is not installed. Please install it: pip install redis")

    from .redis_lease_refresher import RedisLeaseRefresher, RedisLeaseRefresherConfig

    redis_options = options.redis or {}

    # Create Redis client
    if redis_options.get("connection_url"):
        client = aioredis.from_url(
            redis_options["connection_url"],
            decode_responses=True,
        )
    else:
        client = aioredis.Redis(
            host=redis_options.get("host", "localhost"),
            port=redis_options.get("port", 6379),
            password=redis_options.get("password"),
            username=redis_options.get("username"),
            db=redis_options.get("database", 0),
            decode_responses=True,
        )

    # Test connection
    try:
        await client.ping()
    except Exception as e:
        raise ConnectionError(f"Failed to connect to Redis: {e}")

    key_prefix = redis_options.get("key_prefix", "kcl:leases:")
    host = redis_options.get("host", "localhost")
    port = redis_options.get("port", 6379)

    logger.info(
        f"Redis persistence configured: key_prefix={key_prefix}{options.application_name}:, "
        f"host={host}, port={port}"
    )

    config = RedisLeaseRefresherConfig(
        key_prefix=key_prefix,
        application_name=options.application_name,
        worker_identifier=options.worker_identifier,
        lease_duration_millis=options.lease_duration_millis,
    )

    return RedisLeaseRefresher(client, config)


async def _create_postgresql_persistence(options: CreatePersistenceOptions) -> LeaseRefresher:
    """Create a PostgreSQL-based LeaseRefresher."""
    try:
        import asyncpg  # type: ignore[import-not-found]
    except ImportError:
        raise ImportError("asyncpg package is not installed. Please install it: pip install asyncpg")

    from .sql_lease_refresher import SQLLeaseRefresher, SQLLeaseRefresherConfig

    pg_options = options.postgresql or {}

    # Create connection pool
    if pg_options.get("connection_url"):
        pool = await asyncpg.create_pool(pg_options["connection_url"])
    else:
        pool = await asyncpg.create_pool(
            host=pg_options.get("host", "localhost"),
            port=pg_options.get("port", 5432),
            database=pg_options.get("database"),
            user=pg_options.get("username"),
            password=pg_options.get("password"),
            min_size=1,
            max_size=pg_options.get("pool_size", 10),
        )

    # Create adapter for asyncpg
    class AsyncPGAdapter:
        def __init__(self, pool):
            self._pool = pool

        async def execute(self, query: str, *args):
            return await self._pool.execute(query, *args)

        async def fetch(self, query: str, *args):
            rows = await self._pool.fetch(query, *args)
            return [dict(row) for row in rows]

        async def fetchrow(self, query: str, *args):
            row = await self._pool.fetchrow(query, *args)
            return dict(row) if row else None

    client = AsyncPGAdapter(pool)

    schema = pg_options.get("schema", "public")
    table_name = f"kcl_leases_{options.application_name.replace('-', '_')}"
    host = pg_options.get("host", "localhost")
    port = pg_options.get("port", 5432)

    logger.info(f"PostgreSQL persistence configured: host={host}, port={port}, schema={schema}")

    config = SQLLeaseRefresherConfig(
        dialect="postgresql",
        table_name=table_name,
        schema=schema,
        application_name=options.application_name,
        worker_identifier=options.worker_identifier,
        lease_duration_millis=options.lease_duration_millis,
        auto_create_table=pg_options.get("auto_create_table", True),
    )

    return SQLLeaseRefresher(client, config)


async def _create_mysql_persistence(options: CreatePersistenceOptions) -> LeaseRefresher:
    """Create a MySQL-based LeaseRefresher."""
    try:
        import aiomysql  # type: ignore[import-not-found]
    except ImportError:
        raise ImportError("aiomysql package is not installed. Please install it: pip install aiomysql")

    from .sql_lease_refresher import SQLLeaseRefresher, SQLLeaseRefresherConfig

    mysql_options = options.mysql or {}

    # Create connection pool
    pool = await aiomysql.create_pool(
        host=mysql_options.get("host", "localhost"),
        port=mysql_options.get("port", 3306),
        db=mysql_options.get("database"),
        user=mysql_options.get("username"),
        password=mysql_options.get("password"),
        minsize=1,
        maxsize=mysql_options.get("pool_size", 10),
        autocommit=True,
    )

    # Create adapter for aiomysql
    class AioMySQLAdapter:
        def __init__(self, pool):
            self._pool = pool

        async def execute(self, query: str, *args):
            async with self._pool.acquire() as conn:  # type: ignore[attr-defined]
                async with conn.cursor() as cur:  # type: ignore[attr-defined]
                    await cur.execute(query, args)
                    return cur

        async def fetch(self, query: str, *args):
            async with self._pool.acquire() as conn:  # type: ignore[attr-defined]
                async with conn.cursor(aiomysql.DictCursor) as cur:  # type: ignore[attr-defined]
                    await cur.execute(query, args)
                    return await cur.fetchall()

        async def fetchrow(self, query: str, *args):
            async with self._pool.acquire() as conn:  # type: ignore[attr-defined]
                async with conn.cursor(aiomysql.DictCursor) as cur:  # type: ignore[attr-defined]
                    await cur.execute(query, args)
                    return await cur.fetchone()

    client = AioMySQLAdapter(pool)

    table_name = f"kcl_leases_{options.application_name.replace('-', '_')}"
    host = mysql_options.get("host", "localhost")
    port = mysql_options.get("port", 3306)

    logger.info(f"MySQL persistence configured: host={host}, port={port}")

    config = SQLLeaseRefresherConfig(
        dialect="mysql",
        table_name=table_name,
        application_name=options.application_name,
        worker_identifier=options.worker_identifier,
        lease_duration_millis=options.lease_duration_millis,
        auto_create_table=mysql_options.get("auto_create_table", True),
    )

    return SQLLeaseRefresher(client, config)


async def _create_mongodb_persistence(options: CreatePersistenceOptions) -> LeaseRefresher:
    """Create a MongoDB-based LeaseRefresher."""
    try:
        from motor.motor_asyncio import AsyncIOMotorClient  # type: ignore[import-not-found]
    except ImportError:
        raise ImportError("motor package is not installed. Please install it: pip install motor")

    from .mongodb_lease_refresher import MongoDBLeaseRefresher, MongoDBLeaseRefresherConfig

    mongo_options = options.mongodb or {}

    # Build connection URL
    if mongo_options.get("connection_url"):
        connection_url = mongo_options["connection_url"]
    else:
        host = mongo_options.get("host", "localhost")
        port = mongo_options.get("port", 27017)
        database = mongo_options.get("database", "kcl")

        if mongo_options.get("username") and mongo_options.get("password"):
            auth_source = mongo_options.get("auth_source", "admin")
            connection_url = (
                f"mongodb://{mongo_options['username']}:{mongo_options['password']}"
                f"@{host}:{port}/{database}?authSource={auth_source}"
            )
        else:
            connection_url = f"mongodb://{host}:{port}/{database}"

    # Create client
    client = AsyncIOMotorClient(
        connection_url,
        maxPoolSize=mongo_options.get("pool_size", 10),
        connectTimeoutMS=mongo_options.get("connect_timeout", 5000),
        serverSelectionTimeoutMS=mongo_options.get("server_selection_timeout", 5000),
    )

    # Get database and collection
    db_name = mongo_options.get("database", "kcl")
    collection_name = mongo_options.get("collection_name", f"kcl_leases_{options.application_name.replace('-', '_')}")

    db = client[db_name]
    collection = db[collection_name]

    host = mongo_options.get("host", "localhost")
    port = mongo_options.get("port", 27017)

    logger.info(
        f"MongoDB persistence configured: host={host}, port={port}, "
        f"database={db_name}, collection={collection_name}"
    )

    config = MongoDBLeaseRefresherConfig(
        collection_name=collection_name,
        application_name=options.application_name,
        worker_identifier=options.worker_identifier,
        lease_duration_millis=options.lease_duration_millis,
        auto_create_indexes=mongo_options.get("auto_create_indexes", True),
    )

    return MongoDBLeaseRefresher(collection, config)
