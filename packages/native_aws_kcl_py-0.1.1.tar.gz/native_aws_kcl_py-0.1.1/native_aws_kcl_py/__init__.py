"""Native AWS Kinesis Consumer Library for Python.

A Python implementation of the AWS Kinesis Client Library (KCL) with full support for:
- Distributed processing with lease coordination
- Automatic load balancing across workers
- Checkpointing and progress tracking
- Resharding support (shard splits and merges)
- Metrics collection (pluggable, disabled by default)
- Graceful shutdown

Example:
    ```python
    from native_aws_kcl_py import (
        Scheduler,
        KinesisConsumerConfig,
        AwsConfig,
        ShardRecordProcessor,
        ShardRecordProcessorFactory,
        InitializationInput,
        ProcessRecordsInput,
        LeaseLostInput,
        ShardEndedInput,
        ShutdownRequestedInput,
    )

    class MyRecordProcessor(ShardRecordProcessor):
        async def initialize(self, input: InitializationInput) -> None:
            print(f"Starting to process shard {input.shard_id}")

        async def process_records(self, input: ProcessRecordsInput) -> None:
            for record in input.records:
                data = record.data.decode('utf-8')
                print(f"Processing: {data}")

            # Checkpoint after processing
            if input.records:
                await input.checkpointer.checkpoint()

        async def lease_lost(self, input: LeaseLostInput) -> None:
            print(f"Lost lease for shard {input.shard_id}")

        async def shard_ended(self, input: ShardEndedInput) -> None:
            await input.checkpointer.checkpoint()
            print(f"Shard {input.shard_id} ended")

        async def shutdown_requested(self, input: ShutdownRequestedInput) -> None:
            await input.checkpointer.checkpoint()
            print(f"Shutdown requested for shard {input.shard_id}")

    class MyProcessorFactory(ShardRecordProcessorFactory):
        def create_processor(self) -> ShardRecordProcessor:
            return MyRecordProcessor()

    async def main():
        config = KinesisConsumerConfig(
            aws=AwsConfig(region="eu-west-1"),
            application_name="my-consumer",
            stream_name="my-kinesis-stream",
            record_processor_factory=MyProcessorFactory(),
        )

        scheduler = Scheduler(config)

        # Run until shutdown
        await scheduler.run()

    if __name__ == "__main__":
        import asyncio
        asyncio.run(main())
    ```
"""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("native-aws-kcl-py")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"

# Main entry point
# Exceptions
from .exceptions import (
    CheckpointException,
    ExpiredIteratorException,
    InvalidSchedulerStateException,
    InvalidStateException,
    KinesisClientLibraryException,
    KinesisException,
    KinesisProvisionedThroughputExceededException,
    KinesisTimeoutException,
    LeaseConditionalCheckFailedException,
    LeaseException,
    LeaseLostException,
    LeaseProvisionedThroughputExceededException,
    LeaseTableNotFoundException,
    LeaseTimeoutException,
    MaxConsecutiveFailuresException,
    ProcessingException,
    ProcessingTimeoutException,
    ProcessorInitializationException,
    ResourceNotFoundException,
    SchedulerException,
    SchedulerInitializationException,
    ShutdownException,
    ThrottlingException,
    is_lease_lost_exception,
    is_retryable_exception,
)

# Kinesis components (for advanced usage)
from .kinesis import (
    CHECKPOINT_SENTINEL,
    # Enhanced Fan-Out (EFO)
    EFORecordFetcher,
    EFORecordFetcherConfig,
    IRecordFetcher,
    RecordFetcher,
    RecordFetcherFactory,
    RecordFetcherFactoryConfig,
    RetrievalMode,
    ShardDetector,
    ShardSyncer,
)

# Lease components (for advanced usage)
from .leases import (
    DynamoDBLeaseRefresher,
    LeaseCoordinator,
)

# Metrics
from .metrics import (
    IMetricsFactory,
    IMetricsScope,
    KCLDimensions,
    KCLMetrics,
    MetricsLevel,
    MetricUnit,
    NoOpMetricsFactory,
)

# Persistence components (for alternative storage backends)
from .persistence import (
    # Interfaces
    BasePersistenceConfig,
    CreatePersistenceOptions,
    DynamoDBPersistenceConfig,
    LeaseRefresherWithHealthCheck,
    MongoDBLeaseRefresher,
    MongoDBLeaseRefresherConfig,
    MongoDBPersistenceConfig,
    PersistenceHealthCheckResult,
    PersistenceProvider,
    PersistenceType,
    RedisLeaseRefresher,
    RedisLeaseRefresherConfig,
    RedisPersistenceConfig,
    # Implementations
    S3LeaseRefresher,
    S3LeaseRefresherConfig,
    S3PersistenceConfig,
    SQLDialect,
    SQLLeaseRefresher,
    SQLLeaseRefresherConfig,
    SQLPersistenceConfig,
    # Factory
    create_persistence_async,
    is_persistence_type_supported,
    parse_persistence_type,
    supports_health_check,
)

# Processor components (for advanced usage)
from .processor import (
    Checkpointer,
    ShardConsumer,
    ShardConsumerConfig,
    ShardConsumerState,
)
from .scheduler import Scheduler, SchedulerState

# Configuration types
from .types import (
    DEFAULT_CONFIG,
    # Config
    AwsConfig,
    CheckpointConfig,
    ChildShard,
    CoordinatorConfig,
    ExtendedSequenceNumber,
    InitializationInput,
    InitialPositionInStream,
    InitialPositionInStreamExtended,
    KinesisClientRecord,
    KinesisConsumerConfig,
    # Records
    KinesisRecord,
    # Lease
    Lease,
    LeaseLostInput,
    LeaseManagementConfig,
    LifecycleConfig,
    MetricsConfig,
    PersistenceConfig,
    ProcessRecordsInput,
    RecordProcessorCheckpointer,
    RetrievalConfig,
    Shard,
    ShardEndedInput,
    # Processor
    ShardRecordProcessor,
    ShardRecordProcessorFactory,
    ShutdownReason,
    ShutdownRequestedInput,
)

# Utilities
from .utils import (
    BACKOFF_PRESETS,
    BackoffConfig,
    JitterType,
    calculate_backoff_with_jitter,
)

__all__ = [
    # Version
    "__version__",
    # Main entry point
    "Scheduler",
    "SchedulerState",
    # Configuration
    "KinesisConsumerConfig",
    "AwsConfig",
    "RetrievalConfig",
    "CheckpointConfig",
    "CoordinatorConfig",
    "LifecycleConfig",
    "MetricsConfig",
    "PersistenceConfig",
    "DEFAULT_CONFIG",
    # Records
    "KinesisRecord",
    "KinesisClientRecord",
    "ExtendedSequenceNumber",
    "InitialPositionInStream",
    "InitialPositionInStreamExtended",
    "Shard",
    "ChildShard",
    # Lease
    "Lease",
    "LeaseManagementConfig",
    # Processor interfaces
    "ShardRecordProcessor",
    "ShardRecordProcessorFactory",
    "RecordProcessorCheckpointer",
    "InitializationInput",
    "ProcessRecordsInput",
    "LeaseLostInput",
    "ShardEndedInput",
    "ShutdownRequestedInput",
    "ShutdownReason",
    # Exceptions
    "KinesisClientLibraryException",
    "CheckpointException",
    "LeaseLostException",
    "InvalidStateException",
    "ShutdownException",
    "ThrottlingException",
    "LeaseException",
    "LeaseProvisionedThroughputExceededException",
    "LeaseConditionalCheckFailedException",
    "LeaseTimeoutException",
    "LeaseTableNotFoundException",
    "KinesisException",
    "ExpiredIteratorException",
    "KinesisProvisionedThroughputExceededException",
    "ResourceNotFoundException",
    "KinesisTimeoutException",
    "ProcessingException",
    "ProcessingTimeoutException",
    "MaxConsecutiveFailuresException",
    "ProcessorInitializationException",
    "SchedulerException",
    "SchedulerInitializationException",
    "InvalidSchedulerStateException",
    "is_retryable_exception",
    "is_lease_lost_exception",
    # Metrics
    "MetricsLevel",
    "MetricUnit",
    "IMetricsFactory",
    "IMetricsScope",
    "KCLMetrics",
    "KCLDimensions",
    "NoOpMetricsFactory",
    # Utilities
    "BackoffConfig",
    "JitterType",
    "calculate_backoff_with_jitter",
    "BACKOFF_PRESETS",
    # Advanced components
    "ShardDetector",
    "ShardSyncer",
    "RecordFetcher",
    "CHECKPOINT_SENTINEL",
    # Enhanced Fan-Out (EFO)
    "EFORecordFetcher",
    "EFORecordFetcherConfig",
    "RecordFetcherFactory",
    "RecordFetcherFactoryConfig",
    "RetrievalMode",
    "IRecordFetcher",
    "LeaseCoordinator",
    "DynamoDBLeaseRefresher",
    "Checkpointer",
    "ShardConsumer",
    "ShardConsumerState",
    "ShardConsumerConfig",
    # Persistence
    "create_persistence_async",
    "parse_persistence_type",
    "is_persistence_type_supported",
    "CreatePersistenceOptions",
    "BasePersistenceConfig",
    "PersistenceType",
    "PersistenceHealthCheckResult",
    "PersistenceProvider",
    "LeaseRefresherWithHealthCheck",
    "supports_health_check",
    "DynamoDBPersistenceConfig",
    "S3PersistenceConfig",
    "RedisPersistenceConfig",
    "SQLPersistenceConfig",
    "MongoDBPersistenceConfig",
    "S3LeaseRefresher",
    "S3LeaseRefresherConfig",
    "RedisLeaseRefresher",
    "RedisLeaseRefresherConfig",
    "SQLLeaseRefresher",
    "SQLLeaseRefresherConfig",
    "SQLDialect",
    "MongoDBLeaseRefresher",
    "MongoDBLeaseRefresherConfig",
]
