"""Checkpointer for recording progress in processing a shard."""

import logging
from typing import TYPE_CHECKING

from ..exceptions import InvalidStateException, LeaseLostException, ShutdownException
from ..types import ExtendedSequenceNumber

if TYPE_CHECKING:
    from ..leases import LeaseCoordinator


class Checkpointer:
    """Checkpointer implementation for recording progress in processing a shard.

    Used by the record processor to checkpoint processed records.

    Example:
        ```python
        # Checkpoint at a specific sequence number
        await checkpointer.checkpoint("49590...", 0)

        # Checkpoint at the last processed record
        await checkpointer.checkpoint()
        ```
    """

    _logger = logging.getLogger("kcl.Checkpointer")

    def __init__(
        self,
        lease_coordinator: "LeaseCoordinator",
        shard_id: str,
        skip_checkpoint_operations: bool = False,
    ):
        """Initialize the checkpointer.

        Args:
            lease_coordinator: The lease coordinator
            shard_id: The shard ID
            skip_checkpoint_operations: If True, checkpoint operations become no-ops
        """
        self._lease_coordinator = lease_coordinator
        self._shard_id = shard_id
        self._skip_checkpoint_operations = skip_checkpoint_operations
        self._last_processed: ExtendedSequenceNumber | None = None
        self._largest_permitted_checkpoint: ExtendedSequenceNumber | None = None
        self._is_shutdown = False

    async def checkpoint(
        self,
        sequence_number: str | None = None,
        sub_sequence_number: int | None = None,
    ) -> None:
        """Checkpoint at a specific sequence number.

        If no sequence number is provided, checkpoints at the last processed record.

        Args:
            sequence_number: The sequence number to checkpoint at
            sub_sequence_number: Optional sub-sequence number for aggregated records

        Raises:
            ShutdownException: If the consumer is shutting down
            LeaseLostException: If the lease has been lost
            InvalidStateException: If trying to checkpoint beyond processed records
        """
        # Skip checkpoint operations if configured (e.g., when enable_checkpoint=False
        # AND always_start_from_latest=True). This is a no-op - lease coordination
        # still works, but we don't persist checkpoint data.
        if self._skip_checkpoint_operations:
            return

        if self._is_shutdown:
            raise ShutdownException(f"Cannot checkpoint - shard {self._shard_id} is shutting down")

        # Check if we still own the lease
        if not self._lease_coordinator.owns_lease(self._shard_id):
            raise LeaseLostException(
                f"Cannot checkpoint - lease lost for shard {self._shard_id}",
                self._shard_id,
            )

        # Determine what to checkpoint
        if sequence_number is None:
            if self._last_processed is None:
                self._logger.debug(f"No records processed for shard {self._shard_id}, skipping checkpoint")
                return
            checkpoint_seq = self._last_processed.sequence_number
            checkpoint_sub_seq = self._last_processed.sub_sequence_number
        else:
            checkpoint_seq = sequence_number
            checkpoint_sub_seq = sub_sequence_number or 0

        # Validate the checkpoint value
        if self._largest_permitted_checkpoint:
            # This is a simplified validation - a full implementation would compare sequence numbers
            pass

        # Perform the checkpoint
        success = await self._lease_coordinator.checkpoint(
            self._shard_id,
            checkpoint_seq,
            checkpoint_sub_seq,
        )

        if not success:
            raise LeaseLostException(
                f"Checkpoint failed for shard {self._shard_id} - lease may have been lost",
                self._shard_id,
            )

        self._logger.debug(f"Checkpointed shard {self._shard_id} at {checkpoint_seq}")

    async def prepare_checkpoint(
        self,
        sequence_number: str | None = None,
        sub_sequence_number: int | None = None,
    ) -> ExtendedSequenceNumber:
        """Prepare to checkpoint (for two-phase checkpointing).

        Args:
            sequence_number: The sequence number to prepare checkpoint at
            sub_sequence_number: Optional sub-sequence number

        Returns:
            The extended sequence number being prepared for checkpoint

        Raises:
            ShutdownException: If the consumer is shutting down
            LeaseLostException: If the lease has been lost
        """
        if self._is_shutdown:
            raise ShutdownException(f"Cannot prepare checkpoint - shard {self._shard_id} is shutting down")

        if not self._lease_coordinator.owns_lease(self._shard_id):
            raise LeaseLostException(
                f"Cannot prepare checkpoint - lease lost for shard {self._shard_id}",
                self._shard_id,
            )

        # Determine what to checkpoint
        if sequence_number is None:
            if self._last_processed is None:
                raise InvalidStateException("No records processed, cannot prepare checkpoint")
            checkpoint_seq = self._last_processed.sequence_number
            checkpoint_sub_seq = self._last_processed.sub_sequence_number
        else:
            checkpoint_seq = sequence_number
            checkpoint_sub_seq = sub_sequence_number or 0

        # Perform the prepare
        success = await self._lease_coordinator.prepare_checkpoint(
            self._shard_id,
            checkpoint_seq,
            checkpoint_sub_seq,
        )

        if not success:
            raise LeaseLostException(
                f"Prepare checkpoint failed for shard {self._shard_id} - lease may have been lost",
                self._shard_id,
            )

        return ExtendedSequenceNumber(
            sequence_number=checkpoint_seq,
            sub_sequence_number=checkpoint_sub_seq,
        )

    def get_shard_id(self) -> str:
        """Get the shard ID associated with this checkpointer.

        Returns:
            The shard ID
        """
        return self._shard_id

    def set_last_processed(
        self,
        sequence_number: str,
        sub_sequence_number: int,
    ) -> None:
        """Set the last processed sequence number.

        This is called by the shard consumer to track what has been delivered
        to the record processor.

        Args:
            sequence_number: The sequence number
            sub_sequence_number: The sub-sequence number
        """
        self._last_processed = ExtendedSequenceNumber(
            sequence_number=sequence_number,
            sub_sequence_number=sub_sequence_number,
        )

    def set_largest_permitted_checkpoint_value(
        self,
        value: ExtendedSequenceNumber,
    ) -> None:
        """Set the largest permitted checkpoint value.

        Args:
            value: The largest permitted checkpoint value
        """
        self._largest_permitted_checkpoint = value

    def mark_shutdown(self) -> None:
        """Mark the checkpointer as shutdown.

        After this, checkpoint operations will fail.
        """
        self._is_shutdown = True

    def is_shutdown(self) -> bool:
        """Check if the checkpointer is shutdown.

        Returns:
            True if shutdown
        """
        return self._is_shutdown
