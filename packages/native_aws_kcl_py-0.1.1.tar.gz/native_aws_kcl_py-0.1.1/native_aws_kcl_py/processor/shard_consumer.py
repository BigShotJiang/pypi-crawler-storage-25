"""Shard consumer for processing records from a single Kinesis shard."""

import asyncio
import logging
import time
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

from ..exceptions import (
    MaxConsecutiveFailuresException,
    ProcessingTimeoutException,
    ProcessorInitializationException,
    ShutdownException,
    is_lease_lost_exception,
    is_retryable_exception,
)
from ..kinesis import CHECKPOINT_SENTINEL, RecordFetcher
from ..metrics import IMetricsFactory, KCLDimensions, KCLMetrics, MetricUnit, NoOpMetricsFactory
from ..types import (
    ChildShard,
    ExtendedSequenceNumber,
    InitializationInput,
    LeaseLostInput,
    ProcessRecordsInput,
    ShardEndedInput,
    ShardRecordProcessor,
    ShutdownReason,
    ShutdownRequestedInput,
)
from ..utils import BACKOFF_PRESETS, BackoffConfig, calculate_backoff_with_jitter
from .checkpointer import Checkpointer

if TYPE_CHECKING:
    from ..leases import LeaseCoordinator


class ShardConsumerState(str, Enum):
    """State of the shard consumer."""

    CREATED = "CREATED"
    INITIALIZING = "INITIALIZING"
    PROCESSING = "PROCESSING"
    SHUTTING_DOWN = "SHUTTING_DOWN"
    SHUTDOWN_COMPLETE = "SHUTDOWN_COMPLETE"
    SHUTDOWN_FAILED = "SHUTDOWN_FAILED"


@dataclass
class ShardConsumerConfig:
    """Configuration for the shard consumer."""

    shard_id: str
    """The shard ID to consume"""

    stream_name: str
    """The stream name"""

    idle_time_between_reads_millis: int = 1000
    """Idle time between GetRecords calls in milliseconds"""

    call_process_records_even_for_empty_record_list: bool = False
    """Whether to call processRecords even when no records are received"""

    max_consecutive_failures: int = 10
    """Maximum consecutive failures before giving up"""

    task_timeout_millis: int = 300000
    """Task timeout in milliseconds (5 minutes)"""

    log_warning_for_task_after_millis: int = 60000
    """Log warning for task after this many milliseconds (1 minute)"""

    always_start_from_latest: bool = False
    """Always start from LATEST, ignoring existing checkpoint"""

    skip_checkpoint_operations: bool = False
    """Skip checkpoint read/write operations (no-op checkpointing)"""


DEFAULT_MAX_CONSECUTIVE_FAILURES = 10
DEFAULT_TASK_TIMEOUT_MILLIS = 300000
DEFAULT_LOG_WARNING_AFTER_MILLIS = 60000
BACKOFF_BASE_MILLIS = 1000
BACKOFF_MAX_MILLIS = 30000


class ShardConsumer:
    """Consumes records from a single Kinesis shard.

    Manages the lifecycle of a ShardRecordProcessor.
    Based on the AWS KCL ShardConsumer implementation.

    Example:
        ```python
        consumer = ShardConsumer(
            lease_coordinator=coordinator,
            processor=my_processor,
            record_fetcher=fetcher,
            config=ShardConsumerConfig(
                shard_id="shardId-000000000001",
                stream_name="my-stream",
            ),
        )

        await consumer.start()
        # ... later ...
        await consumer.stop()
        ```
    """

    _logger = logging.getLogger("kcl.ShardConsumer")

    def __init__(
        self,
        lease_coordinator: "LeaseCoordinator",
        processor: ShardRecordProcessor,
        record_fetcher: RecordFetcher,
        config: ShardConsumerConfig,
        metrics_factory: IMetricsFactory | None = None,
    ):
        """Initialize the shard consumer.

        Args:
            lease_coordinator: The lease coordinator
            processor: The record processor
            record_fetcher: The record fetcher
            config: Consumer configuration
            metrics_factory: Optional metrics factory
        """
        self._lease_coordinator = lease_coordinator
        self._processor = processor
        self._record_fetcher = record_fetcher
        self._config = config
        self._metrics_factory = metrics_factory or NoOpMetricsFactory()

        self._state = ShardConsumerState.CREATED
        self._checkpointer: Checkpointer | None = None
        self._shutdown_reason: ShutdownReason | None = None
        self._is_running = False
        self._processing_task: asyncio.Task | None = None
        self._consecutive_failures = 0
        self._last_success_time = time.time()

        # Metrics tracking
        self._records_processed = 0
        self._bytes_processed = 0

        # Event for interruptible delays (allows fast shutdown)
        self._delay_interrupt_event: asyncio.Event = asyncio.Event()

    def _create_metrics_scope(self, operation: str):
        """Create a metrics scope for this shard."""
        scope = self._metrics_factory.create_scope(operation)
        if self._metrics_factory.is_enabled():
            scope.add_dimension(KCLDimensions.SHARD_ID, self._config.shard_id)
            scope.add_dimension(KCLDimensions.STREAM_NAME, self._config.stream_name)
        return scope

    async def start(self) -> None:
        """Start consuming records from the shard."""
        if self._is_running:
            self._logger.warning(f"ShardConsumer for {self._config.shard_id} is already running")
            return

        self._is_running = True
        self._state = ShardConsumerState.INITIALIZING

        try:
            # Initialize
            await self._initialize()

            # Start the processing loop
            self._processing_task = asyncio.create_task(self._process_loop())

        except Exception as e:
            self._is_running = False
            self._state = ShardConsumerState.SHUTDOWN_FAILED

            if isinstance(e, ProcessorInitializationException):
                raise

            raise ProcessorInitializationException(
                f"Failed to initialize shard consumer for {self._config.shard_id}: {e}",
                self._config.shard_id,
                e,
            )

    async def stop(self) -> None:
        """Stop consuming records (graceful shutdown)."""
        if not self._is_running:
            return

        self._shutdown_reason = ShutdownReason.REQUESTED
        self._is_running = False

        # Signal any pending delays to wake up immediately (speeds up shutdown)
        self._delay_interrupt_event.set()

        # Close the record fetcher to release the EFO subscription
        if hasattr(self._record_fetcher, "close") and callable(self._record_fetcher.close):
            try:
                await self._record_fetcher.close()
                self._logger.info(f"Closed record fetcher for shard {self._config.shard_id} during stop")
            except Exception as close_error:
                self._logger.error(f"Error closing record fetcher for shard {self._config.shard_id}: {close_error}")

        # Mark checkpointer as shutdown
        if self._checkpointer:
            self._checkpointer.mark_shutdown()

        # Wait for processing to complete (should be fast now that delays are interruptible)
        if self._processing_task:
            try:
                # Short timeout since delays are now interruptible
                await asyncio.wait_for(self._processing_task, timeout=5.0)
            except asyncio.TimeoutError:
                self._logger.warning(f"Timeout waiting for processing to complete for shard {self._config.shard_id}")
                self._processing_task.cancel()
            except asyncio.CancelledError:
                pass

    async def on_lease_lost(self) -> None:
        """Handle lease lost event."""
        self._shutdown_reason = ShutdownReason.LEASE_LOST
        self._is_running = False
        self._state = ShardConsumerState.SHUTTING_DOWN

        # Signal any pending delays to wake up immediately (speeds up shutdown)
        self._delay_interrupt_event.set()

        # CRITICAL: Close the record fetcher FIRST to release the EFO subscription
        # This must happen before notifying the processor to ensure the subscription
        # is released and another worker can acquire it
        if hasattr(self._record_fetcher, "close") and callable(self._record_fetcher.close):
            try:
                await self._record_fetcher.close()
                self._logger.info(f"Closed record fetcher for shard {self._config.shard_id} after lease loss")
            except Exception as close_error:
                self._logger.error(f"Error closing record fetcher for shard {self._config.shard_id}: {close_error}")

        # Mark checkpointer as shutdown
        if self._checkpointer:
            self._checkpointer.mark_shutdown()

        # Notify the processor
        try:
            await self._execute_with_timeout(
                self._processor.lease_lost(LeaseLostInput(shard_id=self._config.shard_id)),
                "leaseLost",
            )
        except Exception as e:
            self._logger.error(f"Error in leaseLost handler for shard {self._config.shard_id}: {e}")

        self._state = ShardConsumerState.SHUTDOWN_COMPLETE

    async def _initialize(self) -> None:
        """Initialize the shard consumer."""
        # Get the lease for this shard
        lease = self._lease_coordinator.get_lease(self._config.shard_id)
        if not lease:
            raise ProcessorInitializationException(
                f"No lease found for shard {self._config.shard_id}",
                self._config.shard_id,
            )

        # Create the checkpointer
        self._checkpointer = Checkpointer(
            self._lease_coordinator,
            self._config.shard_id,
            skip_checkpoint_operations=self._config.skip_checkpoint_operations,
        )

        # Determine starting position
        starting_sequence_number: str | None = None
        if self._config.always_start_from_latest:
            self._logger.info(
                f"[{self._config.shard_id}] ALWAYS_START_FROM_LATEST enabled - "
                "ignoring checkpoint, starting from LATEST"
            )
        elif lease.checkpoint:
            starting_sequence_number = lease.checkpoint.sequence_number
            self._logger.info(f"[{self._config.shard_id}] Resuming from checkpoint: {starting_sequence_number}")
        else:
            self._logger.info(f"[{self._config.shard_id}] No checkpoint found, starting from initial position")

        # Initialize the record fetcher
        try:
            await self._record_fetcher.initialize(starting_sequence_number)
        except Exception as e:
            raise ProcessorInitializationException(
                f"Failed to initialize record fetcher for shard {self._config.shard_id}: {e}",
                self._config.shard_id,
                e,
            )

        # Build initialization input
        init_input = InitializationInput(
            shard_id=self._config.shard_id,
            extended_sequence_number=self._get_starting_position(lease),
            pending_checkpoint_sequence_number=lease.pending_checkpoint,
        )

        # Call the processor's initialize method
        try:
            await self._execute_with_timeout(
                self._processor.initialize(init_input),
                "initialize",
            )
        except Exception as e:
            raise ProcessorInitializationException(
                f"Processor initialization failed for shard {self._config.shard_id}: {e}",
                self._config.shard_id,
                e,
            )

        self._state = ShardConsumerState.PROCESSING
        self._last_success_time = time.time()

    async def _process_loop(self) -> None:
        """Main processing loop."""
        while self._is_running and self._state == ShardConsumerState.PROCESSING:
            try:
                # Check if we still own the lease
                if not self._lease_coordinator.owns_lease(self._config.shard_id):
                    self._logger.warning(f"Lease lost for shard {self._config.shard_id}")
                    await self.on_lease_lost()
                    return

                # Fetch records
                fetch_scope = self._create_metrics_scope("ProcessTask")
                fetch_start_time = time.time()

                try:
                    fetch_result = await self._record_fetcher.fetch_records()
                    fetch_time = (time.time() - fetch_start_time) * 1000

                    fetch_scope.add_time(KCLMetrics.GET_RECORDS_TIME, fetch_time)
                    fetch_scope.add_count(KCLMetrics.GET_RECORDS_SUCCESS, 1)
                    fetch_scope.add_count(KCLMetrics.RECORDS_FETCHED, len(fetch_result.records))

                    if not fetch_result.records:
                        fetch_scope.add_count(KCLMetrics.GET_RECORDS_EMPTY, 1)

                except Exception as e:
                    fetch_scope.add_time(KCLMetrics.GET_RECORDS_TIME, (time.time() - fetch_start_time) * 1000)
                    fetch_scope.add_count(KCLMetrics.GET_RECORDS_FAILURE, 1)
                    fetch_scope.end()
                    await self._handle_fetch_error(e)
                    continue

                finally:
                    fetch_scope.end()

                # Update last processed position if we got records
                if fetch_result.records and self._checkpointer:
                    last_record = fetch_result.records[-1]
                    self._checkpointer.set_last_processed(
                        last_record.sequence_number,
                        last_record.sub_sequence_number or 0,
                    )
                    self._checkpointer.set_largest_permitted_checkpoint_value(
                        ExtendedSequenceNumber(
                            sequence_number=last_record.sequence_number,
                            sub_sequence_number=last_record.sub_sequence_number or 0,
                        )
                    )

                # Process records
                should_process = fetch_result.records or self._config.call_process_records_even_for_empty_record_list
                if should_process and self._checkpointer:
                    process_input = ProcessRecordsInput(
                        records=fetch_result.records,
                        checkpointer=self._checkpointer,
                        millis_behind_latest=fetch_result.millis_behind_latest,
                        is_at_shard_end=fetch_result.is_at_shard_end,
                        child_shards=fetch_result.child_shards,
                    )

                    process_scope = self._create_metrics_scope("ProcessTask")
                    process_start_time = time.time()

                    try:
                        await self._execute_with_timeout(
                            self._processor.process_records(process_input),
                            "processRecords",
                        )

                        # Record metrics
                        process_time = (time.time() - process_start_time) * 1000
                        process_scope.add_time(KCLMetrics.RECORD_PROCESSOR_PROCESS_RECORDS_TIME, process_time)
                        process_scope.add_time(KCLMetrics.PROCESS_TASK_TIME, process_time)
                        process_scope.add_count(KCLMetrics.PROCESS_TASK_SUCCESS, 1)
                        process_scope.add_count(KCLMetrics.RECORDS_PROCESSED, len(fetch_result.records))
                        process_scope.add_count(KCLMetrics.MILLIS_BEHIND_LATEST, fetch_result.millis_behind_latest)

                        # Calculate bytes processed
                        if fetch_result.records:
                            bytes_processed = sum(len(r.data) for r in fetch_result.records)
                            process_scope.add_data(KCLMetrics.DATA_BYTES_PROCESSED, bytes_processed, MetricUnit.BYTES)
                            self._bytes_processed += bytes_processed

                        self._records_processed += len(fetch_result.records)

                        # Reset failure count on success
                        self._consecutive_failures = 0
                        self._last_success_time = time.time()

                    except Exception as e:
                        process_time_ms = (time.time() - process_start_time) * 1000
                        process_scope.add_time(KCLMetrics.RECORD_PROCESSOR_PROCESS_RECORDS_TIME, process_time_ms)
                        process_scope.add_count(KCLMetrics.EXCEPTIONS, 1)
                        process_scope.end()

                        await self._handle_processing_error(e)
                        if not self._is_running:
                            return
                        continue

                    finally:
                        process_scope.end()

                # Handle shard end
                if fetch_result.is_at_shard_end:
                    await self._handle_shard_end(fetch_result.child_shards)
                    return

                # Check for shutdown request
                if self._shutdown_reason == ShutdownReason.REQUESTED:
                    await self._handle_shutdown_requested()
                    return

                # Idle time between reads if no records (interruptible for fast shutdown)
                if not fetch_result.records:
                    await self._interruptible_delay(self._config.idle_time_between_reads_millis / 1000)

            except Exception as e:
                self._logger.error(f"Unexpected error in process loop for shard {self._config.shard_id}: {e}")

                # Check if lease was lost
                if not self._lease_coordinator.owns_lease(self._config.shard_id) or is_lease_lost_exception(e):
                    await self.on_lease_lost()
                    return

                self._consecutive_failures += 1

                if self._consecutive_failures >= self._config.max_consecutive_failures:
                    self._logger.error(
                        f"Max consecutive failures ({self._config.max_consecutive_failures}) "
                        f"reached for shard {self._config.shard_id}"
                    )
                    self._shutdown_reason = ShutdownReason.ZOMBIE
                    self._state = ShardConsumerState.SHUTDOWN_FAILED
                    return

                # Exponential backoff (interruptible for fast shutdown)
                backoff_ms = calculate_backoff_with_jitter(
                    self._consecutive_failures,
                    BackoffConfig(base_delay_ms=BACKOFF_BASE_MILLIS, max_delay_ms=BACKOFF_MAX_MILLIS),
                )
                self._logger.debug(f"Backing off for {backoff_ms}ms (attempt {self._consecutive_failures})")
                await self._interruptible_delay(backoff_ms / 1000)

    async def _handle_fetch_error(self, error: Exception) -> None:
        """Handle errors during record fetching."""
        # Check for lease loss
        if not self._lease_coordinator.owns_lease(self._config.shard_id):
            await self.on_lease_lost()
            return

        error_message = str(error)

        # Persistent subscription conflict is fatal (another worker using same consumer ARN)
        # This error is thrown by EFORecordFetcher after 6 minutes of continuous conflicts
        if "Persistent subscription conflict" in error_message:
            self._logger.error(
                f"[FATAL] Persistent subscription conflict for shard {self._config.shard_id}. "
                f"Stopping consumer - the lease will be released."
            )
            self._is_running = False
            self._shutdown_reason = ShutdownReason.ZOMBIE
            self._state = ShardConsumerState.SHUTDOWN_FAILED
            return

        self._logger.error(f"Error fetching records for shard {self._config.shard_id}: {error}")
        self._consecutive_failures += 1

        # Exponential backoff (interruptible for fast shutdown)
        backoff_ms = calculate_backoff_with_jitter(
            self._consecutive_failures,
            BackoffConfig(base_delay_ms=BACKOFF_BASE_MILLIS, max_delay_ms=BACKOFF_MAX_MILLIS),
        )
        await self._interruptible_delay(backoff_ms / 1000)

    async def _handle_processing_error(self, error: Exception) -> None:
        """Handle errors during record processing."""
        self._logger.error(f"Error processing records for shard {self._config.shard_id}: {error}")

        # Check for lease loss
        if is_lease_lost_exception(error) or not self._lease_coordinator.owns_lease(self._config.shard_id):
            await self.on_lease_lost()
            return

        # Check for shutdown
        if isinstance(error, ShutdownException):
            self._shutdown_reason = ShutdownReason.REQUESTED
            return

        self._consecutive_failures += 1

        # Check for max failures
        if self._consecutive_failures >= self._config.max_consecutive_failures:
            self._logger.error(
                f"Max consecutive failures ({self._config.max_consecutive_failures}) "
                f"reached for shard {self._config.shard_id}"
            )
            raise MaxConsecutiveFailuresException(
                f"Exceeded max consecutive failures for shard {self._config.shard_id}",
                self._config.shard_id,
                self._consecutive_failures,
                error,
            )

        # Exponential backoff for retryable errors (interruptible for fast shutdown)
        if is_retryable_exception(error):
            backoff_ms = calculate_backoff_with_jitter(
                self._consecutive_failures - 1,
                BackoffConfig(base_delay_ms=BACKOFF_BASE_MILLIS, max_delay_ms=BACKOFF_MAX_MILLIS),
            )
            self._logger.info(
                f"Retrying after {backoff_ms}ms backoff "
                f"(failure {self._consecutive_failures}/{self._config.max_consecutive_failures})"
            )
            await self._interruptible_delay(backoff_ms / 1000)
        else:
            # Brief delay for non-retryable errors (interruptible for fast shutdown)
            backoff_ms = calculate_backoff_with_jitter(0, BACKOFF_PRESETS["FAST"])
            await self._interruptible_delay(backoff_ms / 1000)

    async def _handle_shard_end(self, child_shards: list[ChildShard] | None) -> None:
        """Handle the end of a shard (split/merge)."""
        self._state = ShardConsumerState.SHUTTING_DOWN
        self._shutdown_reason = ShutdownReason.SHARD_END

        # Log explicit resharding information
        self._logger.info("╔══════════════════════════════════════════════════════════════════╗")
        self._logger.info("║                 SHARD END DETECTED - RESHARDING                  ║")
        self._logger.info("╠══════════════════════════════════════════════════════════════════╣")
        self._logger.info(f"║ Parent Shard: {self._config.shard_id:<52}║")
        self._logger.info("║ Status: Shard has reached its end (no more records)             ║")

        if child_shards:
            reshard_type = (
                "SPLIT" if len(child_shards) == 2 else ("MERGE" if len(child_shards[0].parent_shards) == 2 else "SPLIT")
            )
            self._logger.info(f"║ Resharding Type: {reshard_type:<49}║")
            self._logger.info("║ Child Shards:                                                    ║")
            for child in child_shards:
                self._logger.info(f"║   • {child.shard_id}" + " " * (61 - len(child.shard_id)) + "║")

        self._logger.info("╚══════════════════════════════════════════════════════════════════╝")

        # Close the record fetcher
        await self._record_fetcher.close()

        if not self._checkpointer:
            self._logger.error(f"Checkpointer not initialized for shard {self._config.shard_id}")
            self._state = ShardConsumerState.SHUTDOWN_FAILED
            return

        shard_ended_input = ShardEndedInput(
            shard_id=self._config.shard_id,
            checkpointer=self._checkpointer,
            child_shards=child_shards,
        )

        try:
            await self._execute_with_timeout(
                self._processor.shard_ended(shard_ended_input),
                "shardEnded",
            )

            # Checkpoint at SHARD_END to mark completion
            try:
                await self._lease_coordinator.checkpoint(
                    self._config.shard_id,
                    CHECKPOINT_SENTINEL.SHARD_END,
                    0,
                )
                self._logger.info(
                    f"[RESHARDING] Successfully checkpointed SHARD_END for shard "
                    f"{self._config.shard_id} - parent shard processing complete"
                )
            except Exception as e:
                self._logger.warning(
                    f"[RESHARDING] Failed to checkpoint SHARD_END for shard " f"{self._config.shard_id}: {e}"
                )

            self._state = ShardConsumerState.SHUTDOWN_COMPLETE
            self._logger.info(
                f"[RESHARDING] Shard {self._config.shard_id} consumer shutdown complete - "
                "child shards can now be processed"
            )

        except Exception as e:
            self._logger.error(f"[RESHARDING] Error in shardEnded handler for shard {self._config.shard_id}: {e}")
            self._state = ShardConsumerState.SHUTDOWN_FAILED

    async def _handle_shutdown_requested(self) -> None:
        """Handle a graceful shutdown request."""
        self._state = ShardConsumerState.SHUTTING_DOWN

        # Close the record fetcher
        await self._record_fetcher.close()

        if not self._checkpointer:
            self._logger.error(f"Checkpointer not initialized for shard {self._config.shard_id}")
            self._state = ShardConsumerState.SHUTDOWN_FAILED
            return

        shutdown_input = ShutdownRequestedInput(
            shard_id=self._config.shard_id,
            checkpointer=self._checkpointer,
        )

        try:
            await self._execute_with_timeout(
                self._processor.shutdown_requested(shutdown_input),
                "shutdownRequested",
            )
            self._state = ShardConsumerState.SHUTDOWN_COMPLETE

        except Exception as e:
            self._logger.error(f"Error in shutdownRequested handler for shard {self._config.shard_id}: {e}")
            self._state = ShardConsumerState.SHUTDOWN_FAILED

    async def _execute_with_timeout(self, coro, operation_name: str):
        """Execute a coroutine with timeout and logging."""
        start_time = time.time()
        warning_logged = False

        async def check_warning():
            nonlocal warning_logged
            while True:
                await asyncio.sleep(1)
                elapsed = (time.time() - start_time) * 1000
                if elapsed >= self._config.log_warning_for_task_after_millis and not warning_logged:
                    self._logger.warning(
                        f"Operation {operation_name} for shard {self._config.shard_id} "
                        f"has been running for {elapsed:.0f}ms"
                    )
                    warning_logged = True
                    break

        warning_task = asyncio.create_task(check_warning())

        try:
            result = await asyncio.wait_for(
                coro,
                timeout=self._config.task_timeout_millis / 1000,
            )
            return result

        except asyncio.TimeoutError:
            raise ProcessingTimeoutException(
                f"Operation {operation_name} timed out after {self._config.task_timeout_millis}ms "
                f"for shard {self._config.shard_id}",
                self._config.shard_id,
                self._config.task_timeout_millis,
            )

        finally:
            warning_task.cancel()
            try:
                await warning_task
            except asyncio.CancelledError:
                pass

    def _get_starting_position(self, lease) -> ExtendedSequenceNumber:
        """Get the starting position from a lease."""
        if self._config.always_start_from_latest:
            return ExtendedSequenceNumber(
                sequence_number=CHECKPOINT_SENTINEL.LATEST,
                sub_sequence_number=0,
            )

        if lease.checkpoint:
            return lease.checkpoint

        return ExtendedSequenceNumber(
            sequence_number=CHECKPOINT_SENTINEL.TRIM_HORIZON,
            sub_sequence_number=0,
        )

    def get_state(self) -> ShardConsumerState:
        """Get the current state."""
        return self._state

    def get_shutdown_reason(self) -> ShutdownReason | None:
        """Get the shutdown reason."""
        return self._shutdown_reason

    def get_shard_id(self) -> str:
        """Get the shard ID."""
        return self._config.shard_id

    def is_active(self) -> bool:
        """Check if the consumer is running."""
        return self._is_running

    def get_consecutive_failures(self) -> int:
        """Get the number of consecutive failures."""
        return self._consecutive_failures

    def get_last_success_time(self) -> float:
        """Get the last success timestamp."""
        return self._last_success_time

    async def _interruptible_delay(self, seconds: float) -> None:
        """Sleep for the specified duration, but wake up early if interrupted.

        This allows the processing loop to exit quickly when stop() or on_lease_lost()
        is called, instead of waiting for the full delay to complete.

        Args:
            seconds: The maximum time to sleep in seconds
        """
        try:
            # Wait for either the delay to complete or the interrupt event to be set
            await asyncio.wait_for(
                self._delay_interrupt_event.wait(),
                timeout=seconds,
            )
            # If we get here, the event was set - clear it for potential reuse
            # (though typically the consumer won't be reused after shutdown)
        except asyncio.TimeoutError:
            # Normal case - the delay completed without interruption
            pass
