"""Backoff utilities with jitter support.

Implements exponential backoff with jitter to prevent the "thundering herd" problem
where multiple workers retry at the same time after throttling or failures.

Based on AWS recommendations and the Java/Node.js KCL implementation.
See: https://aws.amazon.com/blogs/architecture/exponential-backoff-and-jitter/
"""

import random
from dataclasses import dataclass, field
from enum import Enum


class JitterType(str, Enum):
    """Jitter strategy types.

    - FULL: Random value between 0 and calculated delay (most aggressive jitter)
    - EQUAL: Half fixed delay + half random (balanced approach)
    - DECORRELATED: Uses previous delay to calculate next (good for correlated failures)
    - NONE: No jitter, pure exponential backoff
    """

    FULL = "full"
    EQUAL = "equal"
    DECORRELATED = "decorrelated"
    NONE = "none"


@dataclass
class BackoffConfig:
    """Configuration for backoff calculation."""

    base_delay_ms: int = 100
    """Base delay in milliseconds (default: 100)"""

    max_delay_ms: int = 10000
    """Maximum delay in milliseconds (default: 10000)"""

    jitter_type: JitterType = field(default=JitterType.EQUAL)
    """Jitter strategy (default: 'equal')"""

    multiplier: float = 2.0
    """Multiplier for exponential growth (default: 2)"""


DEFAULT_BACKOFF_CONFIG = BackoffConfig()


def calculate_backoff_with_jitter(
    attempt: int,
    config: BackoffConfig | None = None,
    previous_delay: float | None = None,
) -> int:
    """Calculate backoff delay with jitter.

    Args:
        attempt: The current retry attempt (0-based)
        config: Backoff configuration
        previous_delay: Previous delay for decorrelated jitter

    Returns:
        The calculated delay in milliseconds

    Example:
        ```python
        # Basic usage with defaults (equal jitter)
        delay = calculate_backoff_with_jitter(1)

        # Full jitter for aggressive randomization
        delay = calculate_backoff_with_jitter(3, BackoffConfig(jitter_type=JitterType.FULL))

        # Custom configuration
        delay = calculate_backoff_with_jitter(2, BackoffConfig(
            base_delay_ms=500,
            max_delay_ms=30000,
            jitter_type=JitterType.EQUAL,
        ))
        ```
    """
    if config is None:
        config = DEFAULT_BACKOFF_CONFIG

    # Ensure attempt is at least 0
    normalized_attempt = max(0, attempt)

    # Calculate exponential delay: base * multiplier^attempt
    exponential_delay = min(
        config.base_delay_ms * (config.multiplier**normalized_attempt),
        config.max_delay_ms,
    )

    if config.jitter_type == JitterType.FULL:
        # Full jitter: random value between 0 and exponentialDelay
        # Most aggressive - spreads retries across the entire range
        return int(random.random() * (exponential_delay + 1))

    elif config.jitter_type == JitterType.EQUAL:
        # Equal jitter: half fixed + half random
        # Balanced approach - guarantees minimum delay while adding randomness
        half_delay = exponential_delay / 2
        return int(half_delay + random.random() * half_delay)

    elif config.jitter_type == JitterType.DECORRELATED:
        # Decorrelated jitter: uses previous delay
        # Good for correlated failures, provides more variance
        prev_delay = previous_delay if previous_delay is not None else config.base_delay_ms
        decorrelated_delay = min(
            config.max_delay_ms,
            random.random() * (prev_delay * 3 - config.base_delay_ms) + config.base_delay_ms,
        )
        return int(max(config.base_delay_ms, decorrelated_delay))

    else:
        # No jitter - pure exponential backoff
        return int(exponential_delay)


# Common backoff presets
BACKOFF_PRESETS = {
    "FAST": BackoffConfig(
        base_delay_ms=100,
        max_delay_ms=2000,
        jitter_type=JitterType.EQUAL,
    ),
    "STANDARD": BackoffConfig(
        base_delay_ms=100,
        max_delay_ms=10000,
        jitter_type=JitterType.EQUAL,
    ),
    "THROTTLE": BackoffConfig(
        base_delay_ms=1000,
        max_delay_ms=30000,
        jitter_type=JitterType.FULL,
    ),
    "OUTAGE": BackoffConfig(
        base_delay_ms=5000,
        max_delay_ms=60000,
        jitter_type=JitterType.DECORRELATED,
    ),
}
