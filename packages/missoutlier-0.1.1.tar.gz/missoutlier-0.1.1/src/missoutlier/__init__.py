"""missoutlier - Outlier detection using the MISS method."""

from .detect import detect_outliers_miss

__version__ = "0.1.0"
__all__ = ["detect_outliers_miss"]
