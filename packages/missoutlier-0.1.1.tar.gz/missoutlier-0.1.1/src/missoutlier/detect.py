"""Outlier detection using the MISS (MAD-IQR-SD Simultaneous) method."""

import numpy as np
from scipy.stats import median_abs_deviation


def detect_outliers_miss(data, drop=False, na_rm=False, silent=False):
    """
    Detect outliers in data using the MISS method.

    Parameters
    ----------
    data : array-like
        Input data (will be converted to numeric array)
    drop : bool, optional
        If True, removes outliers; if False, replaces with NaN (default False)
    na_rm : bool, optional
        If True, remove NaN values before computation (default False)
    silent : bool, optional
        If True, suppress messages (default False)

    Returns
    -------
    numpy.ndarray
        Array with outliers removed or replaced with NaN

    References
    ----------
    Pech, G., Vaccaro, N., Caspar, E. A., Amerio, P., Cleeremans, A.,
    Leys, C., & Ley, C. (2026). How not to MISS an outlier: comparing
    three classic univariate methods and introducing a new one, the
    MAD-IQR-SD Simultaneous (MISS). *PsyArXiv*.
    https://doi.org/10.31234/osf.io/2r9yw_v2
    """
    # Convert to numpy array and ensure numeric type
    data = np.asarray(data, dtype=float)

    # Check if data is one-dimensional
    if data.ndim > 1:
        raise ValueError("Data must be one-dimensional")

    # Create a copy to avoid modifying original
    data = data.copy()

    # Helper function for handling NaN
    def _get_func(func_name):
        if na_rm:
            return getattr(np, f'nan{func_name}')
        return getattr(np, func_name)

    # Outlier detection using Median Absolute Deviation (MAD)
    med = _get_func('median')(data)
    mad = median_abs_deviation(data, nan_policy='omit' if na_rm else 'propagate')
    outlier_upper_mad = med + (1.5 * mad)
    outlier_lower_mad = med - (1.5 * mad)

    # Outlier detection using Interquartile Range (IQR)
    q75 = np.nanpercentile(data, 75) if na_rm else np.percentile(data, 75)
    q25 = np.nanpercentile(data, 25) if na_rm else np.percentile(data, 25)
    iqr = q75 - q25
    outlier_upper_iqr = q75 + (2 * iqr)
    outlier_lower_iqr = q25 - (2 * iqr)

    # Outlier detection using Standard Deviation (SD)
    mean_val = _get_func('mean')(data)
    std_val = _get_func('std')(data, ddof=1)  # ddof=1 for sample std like R
    outlier_upper_sd = mean_val + (5 * std_val)
    outlier_lower_sd = mean_val - (5 * std_val)

    # Combine all outlier thresholds into the MISS
    outlier_upper_MISS = 0.878 * outlier_upper_mad + 0.012 * outlier_upper_iqr + 0.11 * outlier_upper_sd
    outlier_lower_MISS = 0.878 * outlier_lower_mad + 0.012 * outlier_lower_iqr + 0.11 * outlier_lower_sd

    # Identify outliers
    outlier_idx = np.where((data <= outlier_lower_MISS) | (data >= outlier_upper_MISS))[0]

    # Calculate percentage of outliers
    pct_outliers = len(outlier_idx) / len(data) * 100

    if not silent:
        print(f"Detected {len(outlier_idx)} outliers ({pct_outliers:.2f}% of data) using MISS method.")

    if drop:
        data = np.delete(data, outlier_idx)
    else:
        data[outlier_idx] = np.nan

    return data
