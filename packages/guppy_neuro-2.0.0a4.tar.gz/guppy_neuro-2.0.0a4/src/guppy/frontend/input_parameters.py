import logging
import os

import numpy as np
import pandas as pd
import panel as pn

from .dandi_selector import DandiSelector

logger = logging.getLogger(__name__)


def _default_root_path():
    # Respect GUPPY_BASE_DIR env var for headless/test mode; otherwise use the home directory.
    base_dir_env = os.environ.get("GUPPY_BASE_DIR")
    if base_dir_env and os.path.isdir(base_dir_env):
        return base_dir_env
    return os.path.expanduser("~")


def checkSameLocation(arr, abspath):
    # abspath = []
    for i in range(len(arr)):
        abspath.append(os.path.dirname(arr[i]))
    abspath = np.asarray(abspath)
    abspath = np.unique(abspath)
    if len(abspath) > 1:
        logger.error("All the folders selected should be at the same location")
        raise Exception("All the folders selected should be at the same location")

    return abspath


def getAbsPath(files_1, files_2):
    arr_1, arr_2 = files_1.value, files_2.value
    if len(arr_1) == 0 and len(arr_2) == 0:
        logger.error("No folder is selected for analysis")
        raise Exception("No folder is selected for analysis")

    abspath = []
    if len(arr_1) > 0:
        abspath = checkSameLocation(arr_1, abspath)
    else:
        abspath = checkSameLocation(arr_2, abspath)

    abspath = np.unique(abspath)
    if len(abspath) > 1:
        logger.error("All the folders selected should be at the same location")
        raise Exception("All the folders selected should be at the same location")
    return abspath


class ParameterForm:
    def __init__(self, *, template, start_path=None):
        self.template = template
        self.folder_path = start_path if start_path and os.path.isdir(start_path) else _default_root_path()
        self.styles = dict(background="WhiteSmoke")
        self.setup_individual_parameters()
        self.setup_group_parameters()
        self.setup_visualization_parameters()
        self.add_to_template()

    def setup_individual_parameters(self):
        # Individual analysis components
        self.mark_down_1 = pn.pane.Markdown(
            """**Select folders for the analysis from the file selector below**""", width=600
        )

        # Color the "dandi" button muted pink (matches the DANDI brain-logo palette) so
        # the two options are visually distinguishable at a glance.
        dandi_button_stylesheet = """
        :host .bk-btn-group > button:nth-child(2) {
            background-color: #E8B4BC !important;
            border-color: #D89AA3 !important;
            color: #3A2A2F !important;
        }
        :host .bk-btn-group > button:nth-child(2).bk-active {
            background-color: #C98A94 !important;
            border-color: #B56E78 !important;
            color: #FFFFFF !important;
        }
        """
        self.source_mode = pn.widgets.RadioButtonGroup(
            name="Data Source",
            options=["local", "dandi"],
            value="local",
            button_type="primary",
            width=300,
            stylesheets=[dandi_button_stylesheet],
        )
        self.source_mode.param.watch(self._on_source_mode_change, "value")

        self.files_1 = pn.widgets.FileSelector(self.folder_path, root_directory="/", name="folderNames", width=950)

        self.dandi_selector = DandiSelector(styles=self.styles)
        # Hidden by default; shown when source_mode == "dandi"
        self.dandi_selector.panel.visible = False

        self.explain_time_artifacts = pn.pane.Markdown(
            """
                                - ***Number of cores :*** Number of cores used for analysis. Try to
                                keep it less than the number of cores in your machine.
                                - ***Combine Data? :*** Make this parameter ``` True ``` if user wants to combine
                                the data, especially when there is two different
                                data files for the same recording session.<br>
                                - ***Isosbestic Control Channel? :*** Make this parameter ``` False ``` if user
                                does not want to use isosbestic control channel in the analysis.<br>
                                - ***Eliminate first few seconds :*** It is the parameter to cut out first x seconds
                                from the data. Default is 1 seconds.<br>
                                - ***Window for Moving Average filter :*** The filtering of signals
                                is done using moving average filter. Default window used for moving
                                average filter is 100 datapoints. Change it based on the requirement.<br>
                                - ***Moving Window (transients detection) :*** Transients in the z-score
                                and/or \u0394F/F are detected using this moving window.
                                Default is 15 seconds. Change it based on the requirement.<br>
                                - ***High Amplitude filtering threshold (HAFT) (transients detection) :*** High amplitude
                                events greater than x times the MAD above the median are filtered out. Here, x is
                                high amplitude filtering threshold. Default is 2.
                                - ***Transients detection threshold (TD Thresh):*** Peaks with local maxima greater than x times
                                the MAD above the median of the trace (after filtering high amplitude events) are detected
                                as transients. Here, x is transients detection threshold. Default is 3.
                                - ***Number of channels (Neurophotometrics only) :*** Number of
                                channels used while recording, when data files has no column names mentioning "Flags"
                                or "LedState".
                                - ***removeArtifacts? :*** Make this parameter ``` True``` if there are
                                artifacts and user wants to remove the artifacts.
                                - ***removeArtifacts method :*** Selecting ```concatenate``` will remove bad
                                chunks and concatenate the selected good chunks together.
                                Selecting ```replace with NaN``` will replace bad chunks with NaN
                                values.
                                """,
            width=350,
        )

        self.timeForLightsTurnOn = pn.widgets.LiteralInput(
            name="Eliminate first few seconds (int)", value=1, type=int, width=320
        )

        self.isosbestic_control = pn.widgets.Select(
            name="Isosbestic Control Channel? (bool)", value=True, options=[True, False], width=320
        )

        self.numberOfCores = pn.widgets.LiteralInput(name="# of cores (int)", value=2, type=int, width=150)

        self.combine_data = pn.widgets.Select(
            name="Combine Data? (bool)", value=False, options=[True, False], width=150
        )

        self.computePsth = pn.widgets.Select(
            name="z_score and/or \u0394F/F? (psth)", options=["z_score", "dff", "Both"], width=320
        )

        self.transients = pn.widgets.Select(
            name="z_score and/or \u0394F/F? (transients)", options=["z_score", "dff", "Both"], width=320
        )

        self.plot_zScore_dff = pn.widgets.Select(
            name="z-score plot and/or \u0394F/F plot?",
            options=["z_score", "dff", "Both", "None"],
            value="None",
            width=320,
        )

        self.moving_wd = pn.widgets.LiteralInput(
            name="Moving Window for transients detection (s) (int)", value=15, type=int, width=320
        )

        self.highAmpFilt = pn.widgets.LiteralInput(name="HAFT (int)", value=2, type=int, width=150)

        self.transientsThresh = pn.widgets.LiteralInput(name="TD Thresh (int)", value=3, type=int, width=150)

        self.moving_avg_filter = pn.widgets.LiteralInput(
            name="Window for Moving Average filter (int)", value=100, type=int, width=320
        )

        self.removeArtifacts = pn.widgets.Select(
            name="removeArtifacts? (bool)", value=False, options=[True, False], width=150
        )

        self.artifactsRemovalMethod = pn.widgets.Select(
            name="removeArtifacts method", value="concatenate", options=["concatenate", "replace with NaN"], width=150
        )

        self.no_channels_np = pn.widgets.LiteralInput(
            name="Number of channels (Neurophotometrics only)", value=2, type=int, width=320
        )

        self.z_score_computation = pn.widgets.Select(
            name="z-score computation Method",
            options=["standard z-score", "baseline z-score", "modified z-score"],
            value="standard z-score",
            width=200,
        )

        self.baseline_wd_strt = pn.widgets.LiteralInput(
            name="Baseline Window Start Time (s) (int)", value=0, type=int, width=200
        )
        self.baseline_wd_end = pn.widgets.LiteralInput(
            name="Baseline Window End Time (s) (int)", value=0, type=int, width=200
        )

        self.explain_z_score = pn.pane.Markdown(
            """
                        ***Note :***<br>
                        - Details about z-score computation methods are explained in Github wiki.<br>
                        - The details will make user understand what computation method to use for
                        their data.<br>
                        - Baseline Window Parameters should be kept 0 unless you are using baseline<br>
                        z-score computation method. The parameters are in seconds.
                        """,
            width=580,
        )

        self.explain_nsec = pn.pane.Markdown(
            """
                        - ***Time Interval :*** To omit bursts of event timestamps, user defined time interval
                        is set so that if the time difference between two timestamps is less than this defined time
                        interval, it will be deleted for the calculation of PSTH.
                        - ***Compute Cross-correlation :*** Make this parameter ```True```, when user wants
                        to compute cross-correlation between PSTHs of two different signals or signals
                        recorded from different brain regions.
                        """,
            width=580,
        )

        self.nSecPrev = pn.widgets.LiteralInput(name="Seconds before 0 (int)", value=-10, type=int, width=120)

        self.nSecPost = pn.widgets.LiteralInput(name="Seconds after 0 (int)", value=20, type=int, width=120)

        self.computeCorr = pn.widgets.Select(
            name="Compute Cross-correlation (bool)", options=[True, False], value=False, width=200
        )

        self.timeInterval = pn.widgets.LiteralInput(name="Time Interval (s)", value=2, type=int, width=120)

        self.use_time_or_trials = pn.widgets.Select(
            name="Bin PSTH trials (str)", options=["Time (min)", "# of trials"], value="Time (min)", width=120
        )

        self.bin_psth_trials = pn.widgets.LiteralInput(
            name="Time(min) / # of trials \n for binning? (int)", value=0, type=int, width=200
        )

        self.explain_baseline = pn.pane.Markdown(
            """
                            ***Note :***<br>
                            - If user does not want to do baseline correction,
                            put both parameters 0.<br>
                            - If the first event timestamp is less than the length of baseline
                            window, it will be rejected in the PSTH computation step.<br>
                            - Baseline parameters must be within the PSTH parameters
                            set in the PSTH parameters section.
                            """,
            width=580,
        )

        self.baselineCorrectionStart = pn.widgets.LiteralInput(
            name="Baseline Correction Start time(int)", value=-5, type=int, width=200
        )

        self.baselineCorrectionEnd = pn.widgets.LiteralInput(
            name="Baseline Correction End time(int)", value=0, type=int, width=200
        )

        self.zscore_param_wd = pn.WidgetBox(
            "### Z-score Parameters",
            self.explain_z_score,
            self.z_score_computation,
            pn.Row(self.baseline_wd_strt, self.baseline_wd_end),
            width=600,
        )

        self.psth_param_wd = pn.WidgetBox(
            "### PSTH Parameters",
            self.explain_nsec,
            pn.Row(self.nSecPrev, self.nSecPost, self.computeCorr),
            pn.Row(self.timeInterval, self.use_time_or_trials, self.bin_psth_trials),
            width=600,
        )

        self.baseline_param_wd = pn.WidgetBox(
            "### Baseline Parameters",
            self.explain_baseline,
            pn.Row(self.baselineCorrectionStart, self.baselineCorrectionEnd),
            width=600,
        )
        self.peak_explain = pn.pane.Markdown(
            """
                        ***Note :***<br>
                        - Peak and area are computed between the window set below.<br>
                        - Peak and AUC parameters must be within the PSTH parameters set in the PSTH parameters section.<br>
                        - Please make sure when user changes the parameters in the table below, click on any other cell after
                        changing a value in a particular cell.
                        """,
            width=580,
        )

        self.start_end_point_df = pd.DataFrame(
            {
                "Peak Start time": [-5, 0, 5, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan],
                "Peak End time": [0, 3, 10, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan],
            }
        )

        self.df_widget = pn.widgets.Tabulator(self.start_end_point_df, name="DataFrame", show_index=False, widths=280)

        self.peak_param_wd = pn.WidgetBox("### Peak and AUC Parameters", self.peak_explain, self.df_widget, width=600)

        self.individual_analysis_wd_2 = pn.Column(
            self.explain_time_artifacts,
            pn.Row(self.numberOfCores, self.combine_data),
            self.isosbestic_control,
            self.timeForLightsTurnOn,
            self.moving_avg_filter,
            self.computePsth,
            self.transients,
            self.plot_zScore_dff,
            self.moving_wd,
            pn.Row(self.highAmpFilt, self.transientsThresh),
            self.no_channels_np,
            pn.Row(self.removeArtifacts, self.artifactsRemovalMethod),
        )

        self.psth_baseline_param = pn.Column(
            self.zscore_param_wd, self.psth_param_wd, self.baseline_param_wd, self.peak_param_wd
        )

        self.widget = pn.Column(
            self.mark_down_1,
            pn.Row(pn.pane.Markdown("**Data Source:**"), self.source_mode),
            self.files_1,
            self.dandi_selector.panel,
            pn.Row(self.individual_analysis_wd_2, self.psth_baseline_param),
        )
        self.individual = pn.Card(self.widget, title="Individual Analysis", styles=self.styles, width=1000)

    def _on_source_mode_change(self, event):
        is_dandi = event.new == "dandi"
        self.files_1.visible = not is_dandi
        self.dandi_selector.panel.visible = is_dandi

    def _resolve_dandi_sessions(self):
        """
        Materialize DANDI asset selections into local session directories.

        For each selected ``dandi://`` URI, create a directory under the user-chosen
        output root named after the asset's basename (minus suffix). The returned
        ``dandi_uri_map`` is keyed by that session directory — matching the key
        used by the orchestration layer when ``mode == "dandi"``.

        Returns
        -------
        folder_names : list[str]
            Absolute paths of the created session directories.
        output_root : str
            The user-chosen local output root.
        dandi_uri_map : dict[str, str]
            Mapping from session directory to the originating DANDI URI.
        """
        selected_uris = self.dandi_selector.selected_uris
        output_root = self.dandi_selector.output_root
        if not selected_uris:
            logger.error("DANDI mode: no NWB assets selected")
            raise Exception("DANDI mode: select at least one NWB asset before running the pipeline")
        if not output_root:
            logger.error("DANDI mode: no local output directory selected")
            raise Exception("DANDI mode: select a local output directory before running the pipeline")

        folder_names = []
        dandi_uri_map = {}
        for uri in selected_uris:
            asset_path = uri.split("/", 3)[-1]
            session_stem = os.path.splitext(os.path.basename(asset_path))[0]
            session_directory = os.path.join(output_root, session_stem)
            os.makedirs(session_directory, exist_ok=True)
            folder_names.append(session_directory)
            dandi_uri_map[session_directory] = uri
        return folder_names, output_root, dandi_uri_map

    def setup_group_parameters(self):
        self.mark_down_2 = pn.pane.Markdown(
            """**Select folders for the average analysis from the file selector below**""", width=600
        )

        self.files_2 = pn.widgets.FileSelector(
            self.folder_path, root_directory="/", name="folderNamesForAvg", width=950
        )

        self.averageForGroup = pn.widgets.Select(
            name="Average Group? (bool)", value=False, options=[True, False], width=435
        )

        self.group_analysis_wd_1 = pn.Column(self.mark_down_2, self.files_2, self.averageForGroup, width=800)
        self.group = pn.Card(
            self.group_analysis_wd_1, title="Group Analysis", styles=self.styles, width=1000, collapsed=True
        )

    def setup_visualization_parameters(self):
        self.visualizeAverageResults = pn.widgets.Select(
            name="Visualize Average Results? (bool)", value=False, options=[True, False], width=435
        )

        self.visualize_zscore_or_dff = pn.widgets.Select(
            name="z-score or \u0394F/F? (for visualization)", options=["z_score", "dff"], width=435
        )

        self.visualization_wd = pn.Row(self.visualize_zscore_or_dff, pn.Spacer(width=60), self.visualizeAverageResults)
        self.visualize = pn.Card(
            self.visualization_wd, title="Visualization Parameters", styles=self.styles, width=1000, collapsed=True
        )

    def add_to_template(self):
        self.template.main.append(self.individual)
        self.template.main.append(self.group)
        self.template.main.append(self.visualize)

    def getInputParameters(self):
        if self.source_mode.value == "dandi":
            folder_names, abspath_value, dandi_uri_map = self._resolve_dandi_sessions()
            mode = "dandi"
        else:
            abspath = getAbsPath(self.files_1, self.files_2)
            folder_names = self.files_1.value
            abspath_value = abspath[0]
            dandi_uri_map = None
            mode = "local"

        inputParameters = {
            "mode": mode,
            "dandi_uri_map": dandi_uri_map,
            "abspath": abspath_value,
            "folderNames": folder_names,
            "numberOfCores": self.numberOfCores.value,
            "combine_data": self.combine_data.value,
            "isosbestic_control": self.isosbestic_control.value,
            "timeForLightsTurnOn": self.timeForLightsTurnOn.value,
            "filter_window": self.moving_avg_filter.value,
            "removeArtifacts": self.removeArtifacts.value,
            "artifactsRemovalMethod": self.artifactsRemovalMethod.value,
            "noChannels": self.no_channels_np.value,
            "zscore_method": self.z_score_computation.value,
            "baselineWindowStart": self.baseline_wd_strt.value,
            "baselineWindowEnd": self.baseline_wd_end.value,
            "nSecPrev": self.nSecPrev.value,
            "nSecPost": self.nSecPost.value,
            "computeCorr": self.computeCorr.value,
            "timeInterval": self.timeInterval.value,
            "bin_psth_trials": self.bin_psth_trials.value,
            "use_time_or_trials": self.use_time_or_trials.value,
            "baselineCorrectionStart": self.baselineCorrectionStart.value,
            "baselineCorrectionEnd": self.baselineCorrectionEnd.value,
            "peak_startPoint": list(self.df_widget.value["Peak Start time"]),  # startPoint.value,
            "peak_endPoint": list(self.df_widget.value["Peak End time"]),  # endPoint.value,
            "selectForComputePsth": self.computePsth.value,
            "selectForTransientsComputation": self.transients.value,
            "moving_window": self.moving_wd.value,
            "highAmpFilt": self.highAmpFilt.value,
            "transientsThresh": self.transientsThresh.value,
            "plot_zScore_dff": self.plot_zScore_dff.value,
            "visualize_zscore_or_dff": self.visualize_zscore_or_dff.value,
            "folderNamesForAvg": self.files_2.value,
            "averageForGroup": self.averageForGroup.value,
            "visualizeAverageResults": self.visualizeAverageResults.value,
        }
        return inputParameters
