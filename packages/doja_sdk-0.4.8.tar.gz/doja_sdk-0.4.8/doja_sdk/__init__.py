# doja_sdk/__init__.py
from .client import DojaClient
from .email_client import DojaEmailClient
from .exceptions import (
    DojaAuthError, 
    DojaAPIError, 
    DojaQuotaExceeded,
    DojaLicenseNotFoundError,
    DojaLicenseNotActiveError,
    DojaMessageLimitReachedError,
    DojaValidationError
)

__version__ = "0.4.0"
__all__ = [
    "DojaClient",
    "DojaEmailClient",
    "DojaAuthError", 
    "DojaAPIError",
    "DojaQuotaExceeded",
    "DojaLicenseNotFoundError",
    "DojaLicenseNotActiveError",
    "DojaMessageLimitReachedError",
    "DojaValidationError"
]
