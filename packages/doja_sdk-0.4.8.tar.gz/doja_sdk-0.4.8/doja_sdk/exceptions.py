# doja_sdk/exceptions.py

class DojaSDKException(Exception):
    """Base exception for all DoJa SDK errors"""
    pass

class DojaAuthError(DojaSDKException):
    """Raised when the DoJa license validation fails (Invalid token, expired, etc.)"""
    pass

class DojaQuotaExceeded(DojaSDKException):
    """Raised when the license has valid=True but canSend=False due to exhausted message quota."""
    pass

class DojaAPIError(DojaSDKException):
    """Raised when the WhatsApp Cloud API returns an error response"""
    def __init__(self, message, status_code=None, raw_response=None):
        super().__init__(message)
        self.status_code = status_code
        self.raw_response = raw_response

class DojaLicenseNotFoundError(DojaAuthError):
    """Raised when the license_key is not found (404)"""
    pass

class DojaLicenseNotActiveError(DojaAuthError):
    """Raised when the license_key is suspended or not active (409)"""
    pass

class DojaMessageLimitReachedError(DojaQuotaExceeded):
    """Raised when the message quota limit has been reached (409)"""
    pass

class DojaValidationError(DojaAuthError):
    """Raised when validation fails for parameters (422)"""
    pass
