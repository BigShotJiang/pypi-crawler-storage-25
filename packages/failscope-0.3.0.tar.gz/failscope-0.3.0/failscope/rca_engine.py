"""
Dual-Agent RCA Engine — Analyzer → Critic Pipeline
====================================================

Pattern Source: Agnox AI Configuration (Dual-Agent Actor-Critic)

Architecture:
  Step 1 — Analyzer (Actor): temperature 0.4, creative, generates suggestions
           Output: Structured JSON with root cause, fix suggestions, severity
  Step 2 — Critic (Evaluator): temperature 0.0, deterministic
           Input: Raw evidence + Analyzer output
           Task: Validate every claim. Override hallucinated suggestions.
           Output: Final developer-facing Markdown

Why two passes?
  - Analyzer generates creative, detailed suggestions but can hallucinate
    file names or APIs not present in the logs
  - Critic cross-checks every claim against raw evidence
  - Any suggestion not grounded in the provided data is overridden
  - Prevents the most common failure mode: confident but wrong answers

Supported LLM Providers (BYOK-ready):
  - Groq (Llama 3.1) — default, free tier available
  - OpenAI (gpt-4o)
  - Anthropic (claude-3.5-sonnet)
"""

import asyncio
import json
import os
from dataclasses import dataclass
from enum import Enum
from typing import Any, Optional

from .preprocessor import PreprocessedLog
from .sanitizer import sanitize


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------
class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class LLMProvider(str, Enum):
    GROQ = "groq"
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    OLLAMA = "ollama"


@dataclass
class RCAResult:
    """Structured output from the dual-agent pipeline."""
    root_cause: str
    category: str           # e.g., "assertion_failure", "timeout", "env_issue"
    severity: Severity
    fix_suggestion: str
    affected_file: Optional[str]
    affected_line: Optional[int]
    confidence: float       # 0.0 - 1.0, set by Critic
    evidence: list[str]     # lines from log that support the diagnosis
    was_critic_override: bool  # True if Critic changed Analyzer's conclusion
    raw_analyzer_output: dict  # for debugging
    raw_critic_output: dict


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------
ANALYZER_SYSTEM_PROMPT = """You are an expert QA engineer analyzing a pytest test failure.
Your role is the ANALYZER in a dual-agent pipeline.

Given the test failure context, produce a JSON analysis with:
{
  "root_cause": "One-sentence root cause description",
  "category": "assertion_failure|timeout|connection_error|env_issue|flaky_test|data_issue|import_error|permission_error|other",
  "severity": "critical|high|medium|low",
  "fix_suggestion": "Specific, actionable fix. Reference exact file paths and line numbers from the evidence.",
  "affected_file": "path/to/file.py or null",
  "affected_line": line_number_or_null,
  "evidence": ["line1 from logs", "line2 from logs"],
  "confidence": 0.0_to_1.0
}

Rules:
- ONLY reference file paths that appear in the provided logs
- ONLY suggest fixes based on visible evidence
- Be specific: "Line 42 asserts X==Y but got Z" not "assertion failed"
- If uncertain, set confidence < 0.5

Respond ONLY with valid JSON. No markdown, no explanation."""

SINGLE_PASS_SYSTEM_PROMPT = """You are an expert QA engineer. Analyze the pytest failure and respond ONLY with valid JSON:
{
  "root_cause": "One-sentence description of what caused the failure",
  "category": "assertion_failure|timeout|connection_error|env_issue|flaky_test|data_issue|import_error|permission_error|other",
  "severity": "critical|high|medium|low",
  "fix_suggestion": "Specific actionable fix based only on what is visible in the log",
  "affected_file": "path/to/file.py or null",
  "affected_line": null_or_number,
  "evidence": ["key line 1", "key line 2"],
  "confidence": 0.0_to_1.0
}
Only reference files and line numbers that appear in the log. No markdown, no explanation."""

CRITIC_SYSTEM_PROMPT = """You are a CRITIC in a dual-agent QA analysis pipeline.
Your role is to VALIDATE the Analyzer's output against raw evidence.

You receive:
1. The raw test failure log (ground truth)
2. The Analyzer's JSON analysis

Your task:
- Check every claim in the analysis against the raw log
- If a file path is mentioned that does NOT appear in the log → override it
- If a line number is referenced that does NOT match → correct it
- If the root cause contradicts the evidence → rewrite it
- If the fix suggestion references APIs/functions not in the log → remove it
- Adjust confidence score based on how well-grounded the analysis is

Output the FINAL corrected analysis as JSON with same schema, plus:
{
  ...same fields...,
  "critic_notes": "What was changed and why",
  "was_override": true/false
}

Be ruthlessly factual. Zero tolerance for hallucination.
Respond ONLY with valid JSON."""


# ---------------------------------------------------------------------------
# LLM Client Abstraction (BYOK-ready)
# ---------------------------------------------------------------------------
class LLMClient:
    """
    Multi-provider LLM client.
    Inspired by Agnox's resolveLlmConfig() pattern.
    """

    def __init__(
        self,
        provider: Optional[LLMProvider] = None,
        api_key: Optional[str] = None,
        model_override: Optional[str] = None,
    ):
        self.provider = provider or self._detect_provider()
        self.model_override = model_override  # explicit --fs-model flag
        self.api_key = api_key or self._resolve_key()

    def _detect_provider(self) -> LLMProvider:
        """Auto-detect provider from available env vars."""
        if os.getenv("OLLAMA_HOST") or os.getenv("OLLAMA_MODEL"):
            return LLMProvider.OLLAMA
        if os.getenv("GROQ_API_KEY"):
            return LLMProvider.GROQ
        if os.getenv("OPENAI_API_KEY"):
            return LLMProvider.OPENAI
        if os.getenv("ANTHROPIC_API_KEY"):
            return LLMProvider.ANTHROPIC
        return LLMProvider.GROQ  # default

    def _resolve_key(self) -> str:
        """Resolve API key from environment. Ollama runs locally — no key required."""
        if self.provider == LLMProvider.OLLAMA:
            return ""
        key_map = {
            LLMProvider.GROQ: "GROQ_API_KEY",
            LLMProvider.OPENAI: "OPENAI_API_KEY",
            LLMProvider.ANTHROPIC: "ANTHROPIC_API_KEY",
        }
        key = os.getenv(key_map.get(self.provider, ""), "")
        if not key:
            raise EnvironmentError(
                f"No API key found for {self.provider.value}. "
                f"Set {key_map.get(self.provider, 'UNKNOWN')} env var."
            )
        return key

    def _get_model_name(self) -> str:
        if self.model_override:
            return self.model_override
        model_map = {
            LLMProvider.GROQ: "llama-3.3-70b-versatile",
            LLMProvider.OPENAI: "gpt-4o",
            LLMProvider.ANTHROPIC: "claude-haiku-4-5-20251001",
            LLMProvider.OLLAMA: os.getenv("OLLAMA_MODEL", "llama3.2"),
        }
        return model_map[self.provider]

    def _get_base_url(self) -> str:
        url_map = {
            LLMProvider.GROQ: "https://api.groq.com/openai/v1",
            LLMProvider.OPENAI: "https://api.openai.com/v1",
            LLMProvider.ANTHROPIC: "https://api.anthropic.com/v1",
            LLMProvider.OLLAMA: os.getenv("OLLAMA_HOST", "http://localhost:11434"),
        }
        return url_map[self.provider]

    def complete(self, system_prompt: str, user_prompt: str, temperature: float = 0.4) -> dict:
        """
        Make an LLM completion call.
        Returns parsed JSON response.

        For Groq/OpenAI: uses OpenAI-compatible /chat/completions
        For Anthropic: uses /messages endpoint
        For Ollama: uses native /api/chat with format=json
        """
        import httpx

        if self.provider == LLMProvider.ANTHROPIC:
            return self._complete_anthropic(system_prompt, user_prompt, temperature)
        if self.provider == LLMProvider.OLLAMA:
            return self._complete_ollama(system_prompt, user_prompt, temperature)

        # OpenAI-compatible (Groq, OpenAI)
        url = f"{self._get_base_url()}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self._get_model_name(),
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": temperature,
            "max_tokens": 2000,
            "response_format": {"type": "json_object"},
        }

        response = httpx.post(url, json=payload, headers=headers, timeout=30.0)
        response.raise_for_status()
        data = response.json()

        content = data["choices"][0]["message"]["content"]
        return json.loads(content)

    def _complete_anthropic(self, system_prompt: str, user_prompt: str, temperature: float) -> dict:
        import httpx

        url = f"{self._get_base_url()}/messages"
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self._get_model_name(),
            "max_tokens": 2000,
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_prompt}],
            "temperature": temperature,
        }

        response = httpx.post(url, json=payload, headers=headers, timeout=30.0)
        response.raise_for_status()
        data = response.json()

        content = data["content"][0]["text"]
        # Strip markdown fences if present
        content = content.strip()
        if content.startswith("```"):
            content = content.split("\n", 1)[1]
            content = content.rsplit("```", 1)[0]
        return json.loads(content)

    def _complete_ollama(self, system_prompt: str, user_prompt: str, temperature: float) -> dict:
        """Ollama native API — format=json guarantees parseable output."""
        import httpx

        url = f"{self._get_base_url()}/api/chat"
        payload = {
            "model": self._get_model_name(),
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "stream": False,
            "format": "json",
            "options": {"temperature": temperature},
        }
        # Local models are slower — allow up to 120 seconds
        response = httpx.post(url, json=payload, timeout=120.0)
        response.raise_for_status()
        return json.loads(response.json()["message"]["content"])

    # ------------------------------------------------------------------
    # Async variants — used by DualAgentRCA.analyze_all() for parallelism
    # ------------------------------------------------------------------

    async def acomplete(self, system_prompt: str, user_prompt: str, temperature: float = 0.4) -> dict:
        """Async version of complete(). Uses httpx.AsyncClient."""
        import httpx

        if self.provider == LLMProvider.ANTHROPIC:
            return await self._acomplete_anthropic(system_prompt, user_prompt, temperature)
        if self.provider == LLMProvider.OLLAMA:
            return await self._acomplete_ollama(system_prompt, user_prompt, temperature)

        url = f"{self._get_base_url()}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self._get_model_name(),
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": temperature,
            "max_tokens": 2000,
            "response_format": {"type": "json_object"},
        }

        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(url, json=payload, headers=headers)
            response.raise_for_status()
            data = response.json()

        content = data["choices"][0]["message"]["content"]
        return json.loads(content)

    async def _acomplete_anthropic(self, system_prompt: str, user_prompt: str, temperature: float) -> dict:
        import httpx

        url = f"{self._get_base_url()}/messages"
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self._get_model_name(),
            "max_tokens": 2000,
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_prompt}],
            "temperature": temperature,
        }

        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(url, json=payload, headers=headers)
            response.raise_for_status()
            data = response.json()

        content = data["content"][0]["text"]
        content = content.strip()
        if content.startswith("```"):
            content = content.split("\n", 1)[1]
            content = content.rsplit("```", 1)[0]
        return json.loads(content)

    async def _acomplete_ollama(self, system_prompt: str, user_prompt: str, temperature: float) -> dict:
        import httpx

        url = f"{self._get_base_url()}/api/chat"
        payload = {
            "model": self._get_model_name(),
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "stream": False,
            "format": "json",
            "options": {"temperature": temperature},
        }
        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.post(url, json=payload)
            response.raise_for_status()
        return json.loads(response.json()["message"]["content"])


# ---------------------------------------------------------------------------
# Dual-Agent Pipeline
# ---------------------------------------------------------------------------
class DualAgentRCA:
    """
    The core Failscope engine.

    Implements Agnox's Dual-Agent (Actor-Critic) architecture:
    1. Analyzer (temp 0.4) — creative analysis, generates suggestions
    2. Critic (temp 0.0) — deterministic validation, overrides hallucinations
    """

    def __init__(self, llm_client: Optional[LLMClient] = None):
        self.llm = llm_client or LLMClient()

    def analyze(self, preprocessed: PreprocessedLog, test_context: dict) -> RCAResult:
        """
        Run the full dual-agent pipeline on a preprocessed failure.

        Args:
            preprocessed: Output from preprocessor.preprocess()
            test_context: Additional context dict with keys like
                          'test_name', 'test_file', 'fixtures_used',
                          'local_vars', 'duration_seconds'
        """
        # Ollama (local models): single-pass to stay within context limits of small models
        if self.llm.provider == LLMProvider.OLLAMA:
            return self._analyze_single_pass(preprocessed, test_context)

        # --- Build user prompt ---
        user_prompt = self._build_prompt(preprocessed, test_context)

        # --- Step 1: Analyzer (Actor) — temperature 0.4 ---
        analyzer_output = self.llm.complete(
            system_prompt=ANALYZER_SYSTEM_PROMPT,
            user_prompt=user_prompt,
            temperature=0.4,
        )

        # --- Step 2: Critic (Evaluator) — temperature 0.0 ---
        critic_prompt = self._build_critic_prompt(
            raw_log=preprocessed.processed_text,
            analyzer_output=analyzer_output,
        )
        critic_output = self.llm.complete(
            system_prompt=CRITIC_SYSTEM_PROMPT,
            user_prompt=critic_prompt,
            temperature=0.0,
        )

        # --- Build final result ---
        return self._parse_result(analyzer_output, critic_output)

    async def analyze_async(
        self,
        fingerprint_hash: str,
        preprocessed: "PreprocessedLog",
        test_context: dict,
        semaphore: asyncio.Semaphore,
    ) -> tuple[str, "RCAResult"]:
        """
        Async version of analyze(). Returns (fingerprint_hash, RCAResult).
        The two LLM calls per failure (Analyzer → Critic) remain sequential
        because the Critic depends on the Analyzer's output.
        The semaphore limits concurrent API requests across all failures.
        """
        async with semaphore:
            if self.llm.provider == LLMProvider.OLLAMA:
                result = await self._analyze_single_pass_async(preprocessed, test_context)
                return fingerprint_hash, result

            user_prompt = self._build_prompt(preprocessed, test_context)

            analyzer_output = await self.llm.acomplete(
                system_prompt=ANALYZER_SYSTEM_PROMPT,
                user_prompt=user_prompt,
                temperature=0.4,
            )
            critic_prompt = self._build_critic_prompt(
                raw_log=preprocessed.processed_text,
                analyzer_output=analyzer_output,
            )
            critic_output = await self.llm.acomplete(
                system_prompt=CRITIC_SYSTEM_PROMPT,
                user_prompt=critic_prompt,
                temperature=0.0,
            )

        return fingerprint_hash, self._parse_result(analyzer_output, critic_output)

    async def analyze_all(
        self,
        unique_failures: dict,
        max_concurrent: int = 5,
    ) -> dict[str, "RCAResult"]:
        """
        Analyze all unique failures in parallel, bounded by max_concurrent.
        Returns {fingerprint_hash: RCAResult}.
        """
        semaphore = asyncio.Semaphore(max_concurrent)
        tasks = [
            self.analyze_async(fp_hash, failure["preprocessed"], failure["context"], semaphore)
            for fp_hash, failure in unique_failures.items()
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        rca_results = {}
        for item in results:
            if isinstance(item, Exception):
                print(f"\n⚠️  Failscope async RCA error: {item}")
                continue
            fp_hash, result = item
            rca_results[fp_hash] = result

        return rca_results

    def _analyze_single_pass(self, preprocessed: PreprocessedLog, context: dict) -> RCAResult:
        """
        Single-pass RCA for local models (Ollama).
        Combines Analyzer + Critic roles into one call to stay within the
        context window of small models (3B-8B params).
        """
        user_prompt = self._build_compact_prompt(preprocessed, context)
        output = self.llm.complete(
            system_prompt=SINGLE_PASS_SYSTEM_PROMPT,
            user_prompt=user_prompt,
            temperature=0.2,
        )
        # Normalise to the same shape _parse_result expects
        output.setdefault("was_override", False)
        output.setdefault("critic_notes", "single-pass mode (local model)")
        return self._parse_result(output, output)

    async def _analyze_single_pass_async(
        self, preprocessed: PreprocessedLog, context: dict
    ) -> RCAResult:
        user_prompt = self._build_compact_prompt(preprocessed, context)
        output = await self.llm.acomplete(
            system_prompt=SINGLE_PASS_SYSTEM_PROMPT,
            user_prompt=user_prompt,
            temperature=0.2,
        )
        output.setdefault("was_override", False)
        output.setdefault("critic_notes", "single-pass mode (local model)")
        return self._parse_result(output, output)

    def _build_compact_prompt(self, preprocessed: PreprocessedLog, context: dict) -> str:
        """Compact prompt for local models — key signals only to stay within context window."""
        # Use only the last 3000 chars of the log (where errors concentrate)
        log_tail = preprocessed.processed_text[-3000:]
        signals = preprocessed.error_signals_found[:5]
        sections = [
            f"Test: {context.get('test_name', 'unknown')}",
            f"Error type: {preprocessed.fingerprint.error_type}",
        ]
        if signals:
            sections.append("Key signals: " + " | ".join(signals[:3]))
        sections.append(f"\nLog:\n```\n{sanitize(log_tail).text}\n```")
        return "\n".join(sections)

    def _build_prompt(self, preprocessed: PreprocessedLog, context: dict) -> str:
        """Build the Analyzer prompt with all available context."""
        # Sanitize all user-derived text before it leaves the process
        clean_log = sanitize(preprocessed.processed_text).text

        sections = [
            "## Test Failure Context\n",
            f"**Test:** {context.get('test_name', 'unknown')}",
            f"**File:** {context.get('test_file', 'unknown')}",
            f"**Duration:** {context.get('duration_seconds', 'N/A')}s",
        ]

        if context.get("fixtures_used"):
            sections.append(f"**Fixtures:** {', '.join(context['fixtures_used'])}")

        if context.get("local_vars"):
            # local_vars are already sanitized in plugin._extract_locals(),
            # but run a second pass here as a defence-in-depth measure
            clean_locals = sanitize(context["local_vars"]).text
            sections.append(f"\n**Local Variables at Failure:**\n```\n{clean_locals}\n```")

        sections.append(f"\n## Error Fingerprint")
        sections.append(f"**Type:** {preprocessed.fingerprint.error_type}")
        sections.append(f"**Hash:** {preprocessed.fingerprint.hash}")

        if preprocessed.was_truncated:
            sections.append(f"\n⚠️ Log was truncated (original: {preprocessed.original_length:,} chars)")

        sections.append(f"\n## Raw Log Output\n```\n{clean_log}\n```")

        if preprocessed.error_signals_found:
            clean_signals = [sanitize(s).text for s in preprocessed.error_signals_found[:10]]
            sections.append(f"\n## Key Error Signals")
            for signal in clean_signals:
                sections.append(f"- `{signal}`")

        return "\n".join(sections)

    def _build_critic_prompt(self, raw_log: str, analyzer_output: dict) -> str:
        """Build the Critic prompt with raw evidence + Analyzer output."""
        clean_log = sanitize(raw_log).text
        return (
            "## Raw Log Evidence (Ground Truth)\n"
            f"```\n{clean_log}\n```\n\n"
            "## Analyzer's Output (To Validate)\n"
            f"```json\n{json.dumps(analyzer_output, indent=2)}\n```\n\n"
            "Validate every claim. Override anything not grounded in the raw log."
        )

    def _parse_result(self, analyzer_output: dict, critic_output: dict) -> RCAResult:
        """Parse the dual-agent outputs into a structured RCAResult."""
        # Use critic output as final (it's the validated version)
        final = critic_output

        return RCAResult(
            root_cause=final.get("root_cause", "Unable to determine root cause"),
            category=final.get("category", "other"),
            severity=Severity(final.get("severity", "medium")),
            fix_suggestion=final.get("fix_suggestion", "No suggestion available"),
            affected_file=final.get("affected_file"),
            affected_line=final.get("affected_line"),
            confidence=float(final.get("confidence", 0.5)),
            evidence=final.get("evidence", []),
            was_critic_override=final.get("was_override", False),
            raw_analyzer_output=analyzer_output,
            raw_critic_output=critic_output,
        )


# ---------------------------------------------------------------------------
# Offline Fallback (no LLM needed)
# ---------------------------------------------------------------------------
class OfflineRCA:
    """
    Rule-based RCA fallback when no LLM API key is available.
    Uses pattern matching on error signals — not as good as dual-agent,
    but still useful for basic triage.
    """

    CATEGORY_PATTERNS = {
        "assertion_failure": [r"AssertionError", r"assert\s+", r"!=\s+", r"expected.*got"],
        "timeout": [r"TimeoutError", r"Timeout", r"timed?\s*out"],
        "connection_error": [r"ConnectionError", r"ConnectionRefused", r"HTTPError", r"requests\.exceptions"],
        "import_error": [r"ImportError", r"ModuleNotFoundError", r"No module named"],
        "permission_error": [r"PermissionError", r"Permission denied", r"Access denied"],
        "env_issue": [r"FileNotFoundError", r"No such file", r"env.*not set", r"missing.*config"],
        "data_issue": [r"KeyError", r"IndexError", r"ValueError", r"TypeError"],
        "flaky_test": [r"StaleElement", r"flak", r"intermittent", r"race.*condition"],
    }

    def analyze_all(self, unique_failures: dict, max_concurrent: int = 5) -> dict:
        """Synchronous fallback — OfflineRCA has no network calls so no parallelism needed."""
        return {
            fp_hash: self.analyze(failure["preprocessed"], failure["context"])
            for fp_hash, failure in unique_failures.items()
        }

    def analyze(self, preprocessed: PreprocessedLog, test_context: dict) -> RCAResult:
        """Pattern-based analysis without LLM."""
        category = self._detect_category(preprocessed)
        severity = self._estimate_severity(preprocessed, category)

        return RCAResult(
            root_cause=f"{preprocessed.fingerprint.error_type}: {preprocessed.fingerprint.error_message}",
            category=category,
            severity=severity,
            fix_suggestion=self._generate_suggestion(category, preprocessed),
            affected_file=preprocessed.fingerprint.file_path,
            affected_line=preprocessed.fingerprint.line_number,
            confidence=0.3,  # always lower than LLM
            evidence=preprocessed.error_signals_found[:5],
            was_critic_override=False,
            raw_analyzer_output={"mode": "offline"},
            raw_critic_output={"mode": "offline"},
        )

    def _detect_category(self, preprocessed: PreprocessedLog) -> str:
        import re
        text = preprocessed.processed_text
        for category, patterns in self.CATEGORY_PATTERNS.items():
            if any(re.search(p, text, re.IGNORECASE) for p in patterns):
                return category
        return "other"

    def _estimate_severity(self, preprocessed: PreprocessedLog, category: str) -> Severity:
        severity_map = {
            "connection_error": Severity.CRITICAL,
            "import_error": Severity.HIGH,
            "permission_error": Severity.HIGH,
            "assertion_failure": Severity.MEDIUM,
            "timeout": Severity.MEDIUM,
            "data_issue": Severity.MEDIUM,
            "env_issue": Severity.HIGH,
            "flaky_test": Severity.LOW,
        }
        return severity_map.get(category, Severity.MEDIUM)

    def _generate_suggestion(self, category: str, preprocessed: PreprocessedLog) -> str:
        suggestions = {
            "assertion_failure": "Review the assertion values. Check if test data or expected values need updating.",
            "timeout": "Increase timeout threshold or check if the target service is reachable.",
            "connection_error": "Verify the service URL and network connectivity. Check if the API is up.",
            "import_error": "Ensure the required package is installed: pip install <package>",
            "permission_error": "Check file/directory permissions and user access rights.",
            "env_issue": "Verify environment variables and configuration files are set correctly.",
            "data_issue": "Check input data validity. Verify keys/indices exist before accessing.",
            "flaky_test": "Add explicit waits, stabilize test data, or isolate shared state.",
        }
        return suggestions.get(category, "Review the error logs for more details.")
