"""
Failscope — AI-Powered Root Cause Analysis for pytest
=====================================================

A lightweight pytest plugin that automatically analyzes test failures
using a Dual-Agent (Analyzer → Critic) AI pipeline.

Inspired by production patterns from Agnox's AI Quality Orchestrator,
adapted for the pytest ecosystem as a zero-config CLI plugin.

Key patterns implemented:
  1. Dual-Agent RCA (Actor-Critic) — prevents LLM hallucinations
  2. Smart Log Truncation — first 10% + last 90%
  3. Error Fingerprinting — deduplicate before LLM call
  4. Stability Scoring — A-F grading per test
  5. Structured Context Capture — locals, fixtures, assertion diffs
  6. PII/Secrets Sanitization — scrubs sensitive data before LLM calls
"""

__version__ = "0.3.0"
__author__ = "Yani"
