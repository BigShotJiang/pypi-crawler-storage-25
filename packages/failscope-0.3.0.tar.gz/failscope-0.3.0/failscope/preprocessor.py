"""
Log Preprocessor — Smart Truncation & Error Fingerprinting
==========================================================

Pattern Source: Agnox Auto-Bug Generator
- When logs exceed threshold, preserve first 10% (setup context)
  and last 90% (where errors concentrate)
- Generate errorHash fingerprints to cluster similar failures
- Only unique root causes get sent to LLM → saves tokens & cost
"""

import hashlib
import re
from dataclasses import dataclass, field
from typing import Optional


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
MAX_LOG_CHARS = 80_000          # Agnox uses 80k char threshold
TRUNCATION_MARKER = "\n\n[--- LOG TRUNCATED BY FAILSCOPE ---]\n\n"

# Noise patterns to strip before LLM analysis
NOISE_PATTERNS = [
    r"^={2,}.*$",                           # pytest separator lines
    r"^-{2,}.*$",                           # dashed separators
    r"^\s*\d+\s+passed.*$",                 # summary lines
    r"^platform\s+\w+\s+--\s+Python.*$",    # platform info
    r"^rootdir:.*$",                        # rootdir info
    r"^plugins:.*$",                        # plugin listing
    r"^collecting\s+\.\.\.\s*$",            # collection dots
    r"^\s*$",                               # empty lines
]

# Patterns that indicate the "interesting" part of an error
ERROR_SIGNAL_PATTERNS = [
    r"(?:assert|Assert|ASSERT)",
    r"(?:Error|Exception|Traceback)",
    r"(?:FAILED|FAIL|ERROR)",
    r"(?:raise\s+\w+)",
    r"(?:expected|actual|!=|==)",
    r"(?:timeout|Timeout|TIMEOUT)",
    r"(?:ConnectionError|HTTPError|RequestException)",
]


@dataclass
class ErrorFingerprint:
    """Unique identifier for a class of failures."""
    hash: str
    error_type: str
    error_message: str
    file_path: Optional[str] = None
    line_number: Optional[int] = None
    count: int = 1
    test_names: list[str] = field(default_factory=list)


@dataclass
class PreprocessedLog:
    """Result of preprocessing a raw log/traceback."""
    original_length: int
    processed_text: str
    was_truncated: bool
    noise_lines_removed: int
    error_signals_found: list[str]
    fingerprint: ErrorFingerprint


def smart_truncate(text: str, max_chars: int = MAX_LOG_CHARS) -> tuple[str, bool]:
    """
    Agnox-style smart truncation:
    - First 10% preserved (container/setup context)
    - Last 90% preserved (where errors concentrate)
    - Marker inserted at truncation point

    For pytest context, first 10% = fixture setup, imports, config
    Last 90% = actual test execution, assertions, tracebacks
    """
    if len(text) <= max_chars:
        return text, False

    head_size = int(max_chars * 0.10)
    tail_size = max_chars - head_size - len(TRUNCATION_MARKER)

    head = text[:head_size]
    tail = text[-tail_size:]

    return head + TRUNCATION_MARKER + tail, True


def strip_noise(text: str) -> tuple[str, int]:
    """Remove pytest boilerplate noise that wastes LLM tokens."""
    lines = text.split("\n")
    clean_lines = []
    removed = 0

    for line in lines:
        is_noise = any(re.match(pattern, line) for pattern in NOISE_PATTERNS)
        if is_noise:
            removed += 1
        else:
            clean_lines.append(line)

    return "\n".join(clean_lines), removed


def extract_error_signals(text: str) -> list[str]:
    """Find lines containing error-relevant information."""
    signals = []
    for line in text.split("\n"):
        for pattern in ERROR_SIGNAL_PATTERNS:
            if re.search(pattern, line):
                signals.append(line.strip())
                break
    return signals


def generate_fingerprint(
    error_text: str,
    test_name: str,
    file_path: Optional[str] = None,
    line_number: Optional[int] = None,
) -> ErrorFingerprint:
    """
    Generate an errorHash fingerprint for failure clustering.

    Pattern Source: Agnox Flakiness Detective
    - Similar errors across a run are clustered together
    - AI only analyzes unique root causes
    - Prevents wasting tokens on duplicate failures

    The fingerprint is based on:
    1. Error type (e.g., AssertionError, TimeoutError)
    2. Normalized error message (strip variable data)
    3. File path where error occurred
    """
    # Extract error type
    error_type = "UnknownError"
    type_match = re.search(r"(\w+Error|\w+Exception|\w+Failure)", error_text)
    if type_match:
        error_type = type_match.group(1)

    # Extract and normalize error message
    msg_match = re.search(
        r"(?:Error|Exception|Failure):\s*(.+?)(?:\n|$)", error_text
    )
    error_message = msg_match.group(1).strip() if msg_match else error_text[:200]

    # Normalize: replace numbers, UUIDs, timestamps with placeholders
    normalized = re.sub(r"\b\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}\b", "<TIMESTAMP>", error_message)
    normalized = re.sub(r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b", "<UUID>", normalized)
    normalized = re.sub(r"\b\d+\b", "<NUM>", normalized)
    normalized = re.sub(r"0x[0-9a-fA-F]+", "<ADDR>", normalized)

    # Generate hash from error type + normalized message + file
    hash_input = f"{error_type}::{normalized}::{file_path or 'unknown'}"
    error_hash = hashlib.sha256(hash_input.encode()).hexdigest()[:12]

    return ErrorFingerprint(
        hash=error_hash,
        error_type=error_type,
        error_message=error_message,
        file_path=file_path,
        line_number=line_number,
        count=1,
        test_names=[test_name],
    )


def preprocess(
    raw_log: str,
    test_name: str,
    file_path: Optional[str] = None,
    line_number: Optional[int] = None,
    max_chars: int = MAX_LOG_CHARS,
) -> PreprocessedLog:
    """
    Full preprocessing pipeline:
    1. Strip noise (pytest boilerplate)
    2. Smart truncate if needed (size controlled by --fs-max-log-size)
    3. Extract error signals
    4. Generate fingerprint for deduplication
    """
    original_length = len(raw_log)

    # Step 1: Strip noise
    cleaned, noise_removed = strip_noise(raw_log)

    # Step 2: Smart truncate
    truncated, was_truncated = smart_truncate(cleaned, max_chars=max_chars)

    # Step 3: Extract signals
    signals = extract_error_signals(truncated)

    # Step 4: Generate fingerprint
    fingerprint = generate_fingerprint(
        truncated, test_name, file_path, line_number
    )

    return PreprocessedLog(
        original_length=original_length,
        processed_text=truncated,
        was_truncated=was_truncated,
        noise_lines_removed=noise_removed,
        error_signals_found=signals,
        fingerprint=fingerprint,
    )
