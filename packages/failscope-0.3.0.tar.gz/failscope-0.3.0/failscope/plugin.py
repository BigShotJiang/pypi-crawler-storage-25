"""
Failscope pytest Plugin — Zero-Config Integration
===================================================

Usage:
  pip install failscope
  pytest --failscope              # enable RCA on failures
  pytest --failscope --fs-offline # use offline mode (no API key needed)
  pytest --failscope --fs-report  # generate stability report

This file registers as a pytest plugin via entry_points.
"""

import asyncio
import json
import time
import traceback
from pathlib import Path
from typing import Optional

import pytest

from .preprocessor import preprocess, ErrorFingerprint
from .rca_engine import DualAgentRCA, OfflineRCA, RCAResult, LLMClient, LLMProvider
from .reporter import generate_html_report
from .sanitizer import sanitize, sanitize_locals
from .stability import StabilityScorer


# ---------------------------------------------------------------------------
# Plugin Registration
# ---------------------------------------------------------------------------
def pytest_addoption(parser):
    group = parser.getgroup("failscope", "Failscope AI Root Cause Analysis")
    group.addoption(
        "--failscope",
        action="store_true",
        default=False,
        help="Enable Failscope AI-powered failure analysis",
    )
    group.addoption(
        "--fs-offline",
        action="store_true",
        default=False,
        help="Use offline (rule-based) analysis instead of LLM",
    )
    group.addoption(
        "--fs-report",
        action="store_true",
        default=False,
        help="Generate stability report after test run",
    )
    group.addoption(
        "--fs-provider",
        type=str,
        default=None,
        choices=["groq", "openai", "anthropic", "ollama"],
        help="LLM provider for analysis (default: auto-detect from env). Use 'ollama' for local models.",
    )
    group.addoption(
        "--fs-model",
        type=str,
        default=None,
        help=(
            "Override the LLM model name. Examples: "
            "--fs-model=llama3.2 (Ollama), "
            "--fs-model=gpt-4o-mini (OpenAI), "
            "--fs-model=claude-haiku-4-5-20251001 (Anthropic)"
        ),
    )
    group.addoption(
        "--fs-max-log-size",
        type=int,
        default=80_000,
        help="Max characters of log text sent to LLM (default: 80000). Lower for small local models.",
    )
    group.addoption(
        "--fs-output",
        type=str,
        default=".failscope",
        help="Output directory for reports (default: .failscope)",
    )


def pytest_configure(config):
    """Register the plugin only when --failscope is passed."""
    if config.getoption("--failscope", default=False):
        config.pluginmanager.register(FailscopePlugin(config), "failscope-plugin")


# ---------------------------------------------------------------------------
# Core Plugin
# ---------------------------------------------------------------------------
class FailscopePlugin:
    """
    pytest plugin that:
    1. Captures test failures with full context
    2. Deduplicates via error fingerprinting
    3. Runs dual-agent RCA on unique failures
    4. Tracks stability scores over time
    5. Generates developer-friendly reports
    """

    def __init__(self, config):
        self.config = config
        self.output_dir = Path(config.getoption("--fs-output"))
        self.offline = config.getoption("--fs-offline")
        self.max_log_size: int = config.getoption("--fs-max-log-size")

        # Initialize components
        self.scorer = StabilityScorer(self.output_dir / "stability.json")
        self.rca_engine = self._init_rca_engine()

        # Run state
        self.failures: list[dict] = []
        self.fingerprints: dict[str, ErrorFingerprint] = {}
        self.rca_results: dict[str, RCAResult] = {}
        self.test_timings: dict[str, float] = {}
        self.run_start_time = time.time()

    def _init_rca_engine(self):
        """Initialize RCA engine based on mode."""
        if self.offline:
            return OfflineRCA()
        try:
            provider = self.config.getoption("--fs-provider")
            model = self.config.getoption("--fs-model")
            client = LLMClient(
                provider=LLMProvider(provider) if provider else None,
                model_override=model,
            )
            return DualAgentRCA(client)
        except EnvironmentError:
            # Fall back to offline if no API key
            return OfflineRCA()

    # --- pytest hooks ---

    @pytest.hookimpl(hookwrapper=True)
    def pytest_runtest_makereport(self, item, call):
        """Capture test results and context."""
        outcome = yield
        report = outcome.get_result()

        if report.when != "call":
            return

        # Track timing
        duration = call.duration if hasattr(call, 'duration') else 0.0
        test_name = item.nodeid
        self.test_timings[test_name] = duration

        # Record in stability scorer
        passed = report.passed
        error_hash = None

        if report.failed:
            # Capture failure context
            failure_info = self._capture_failure(item, call, report)
            self.failures.append(failure_info)
            error_hash = failure_info.get("fingerprint_hash")

        self.scorer.record(test_name, passed, duration, error_hash)

    def pytest_sessionfinish(self, session, exitstatus):
        """After all tests: analyze failures and generate reports."""
        if not self.failures:
            if self.config.getoption("--fs-report"):
                self._generate_stability_report()
            return

        # Deduplicate failures by fingerprint
        unique_failures = self._deduplicate_failures()

        # Run RCA — parallel async for DualAgentRCA, sync loop for OfflineRCA
        try:
            if isinstance(self.rca_engine, DualAgentRCA):
                # Each unique failure fires Analyzer+Critic in parallel (up to 5 concurrent)
                self.rca_results = asyncio.run(
                    self.rca_engine.analyze_all(unique_failures)
                )
            else:
                self.rca_results = self.rca_engine.analyze_all(unique_failures)
        except Exception as e:
            print(f"\n⚠️  Failscope RCA batch error: {e}")

        # Generate reports
        self._generate_failure_report()
        if self.config.getoption("--fs-report"):
            self._generate_stability_report()

    def pytest_terminal_summary(self, terminalreporter):
        """Print Failscope summary in terminal."""
        if not self.rca_results:
            return

        terminalreporter.write_sep("=", "FAILSCOPE AI ANALYSIS")

        for fp_hash, result in self.rca_results.items():
            fp = self.fingerprints.get(fp_hash)
            affected_tests = fp.test_names if fp else ["unknown"]

            severity_colors = {
                "critical": "red",
                "high": "yellow",
                "medium": "white",
                "low": "green",
            }
            color = severity_colors.get(result.severity.value, "white")

            terminalreporter.write_line("")
            terminalreporter.write_line(
                f"  🔍 [{result.severity.value.upper()}] {result.root_cause}",
            )
            terminalreporter.write_line(f"     Category: {result.category}")
            terminalreporter.write_line(f"     Confidence: {result.confidence:.0%}")

            if len(affected_tests) > 1:
                terminalreporter.write_line(
                    f"     Affects {len(affected_tests)} tests (deduplicated)"
                )

            if result.fix_suggestion:
                terminalreporter.write_line(f"     💡 Fix: {result.fix_suggestion}")

            if result.was_critic_override:
                terminalreporter.write_line(
                    f"     ⚖️  Critic overrode Analyzer (hallucination prevented)"
                )

        # Summary stats
        terminalreporter.write_line("")
        unique = len(self.rca_results)
        total = len(self.failures)
        terminalreporter.write_line(
            f"  📊 {total} failures → {unique} unique root causes"
        )

        html_path = self.output_dir / "rca_report.html"
        if html_path.exists():
            terminalreporter.write_line(f"  🌐 HTML report: {html_path}")
        elif (self.output_dir / "rca_report.json").exists():
            terminalreporter.write_line(f"  📄 JSON report: {self.output_dir / 'rca_report.json'}")

    # --- Internal helpers ---

    def _capture_failure(self, item, call, report) -> dict:
        """Capture comprehensive failure context."""
        # Get raw traceback/log
        raw_log = str(report.longreprtext) if hasattr(report, 'longreprtext') else str(report.longrepr)

        # Extract file and line info
        file_path = str(item.fspath) if hasattr(item, 'fspath') else None
        line_number = item.reportinfo()[1] if hasattr(item, 'reportinfo') else None

        # Preprocess (size bounded by --fs-max-log-size)
        preprocessed = preprocess(
            raw_log=raw_log,
            test_name=item.nodeid,
            file_path=file_path,
            line_number=line_number,
            max_chars=self.max_log_size,
        )

        # Track fingerprint
        fp = preprocessed.fingerprint
        if fp.hash in self.fingerprints:
            self.fingerprints[fp.hash].count += 1
            self.fingerprints[fp.hash].test_names.append(item.nodeid)
        else:
            self.fingerprints[fp.hash] = fp

        # Capture local variables (if available from traceback)
        local_vars = self._extract_locals(call)

        # Capture fixture names
        fixtures_used = list(item.fixturenames) if hasattr(item, 'fixturenames') else []

        context = {
            "test_name": item.nodeid,
            "test_file": file_path,
            "fixtures_used": fixtures_used,
            "local_vars": local_vars,
            "duration_seconds": self.test_timings.get(item.nodeid, 0.0),
        }

        return {
            "preprocessed": preprocessed,
            "context": context,
            "fingerprint_hash": fp.hash,
        }

    def _extract_locals(self, call) -> Optional[str]:
        """Extract local variables from the failure traceback and sanitize secrets."""
        if not call.excinfo:
            return None
        try:
            tb = call.excinfo.tb
            while tb.tb_next:
                tb = tb.tb_next
            locals_dict = tb.tb_frame.f_locals
            safe_locals = {}
            for k, v in locals_dict.items():
                if k.startswith("_"):
                    continue
                repr_v = repr(v)
                if len(repr_v) > 200:
                    repr_v = repr_v[:200] + "..."
                safe_locals[k] = repr_v

            raw_json = json.dumps(safe_locals, indent=2)
            result = sanitize_locals(raw_json)

            if result.redaction_count > 0:
                unique_types = list(dict.fromkeys(result.redacted_types))
                print(
                    f"\n🔒 Failscope: redacted {result.redaction_count} sensitive value(s) "
                    f"from local vars [{', '.join(unique_types)}] before sending to LLM"
                )

            return result.text
        except Exception:
            return None

    def _deduplicate_failures(self) -> dict:
        """
        Return only unique failures by fingerprint hash.
        Pattern Source: Agnox's errorHash clustering.
        """
        unique = {}
        for failure in self.failures:
            fp_hash = failure["fingerprint_hash"]
            if fp_hash not in unique:
                unique[fp_hash] = failure
        return unique

    def _generate_failure_report(self):
        """Write JSON report with all RCA results."""
        self.output_dir.mkdir(parents=True, exist_ok=True)

        report = {
            "timestamp": time.time(),
            "total_failures": len(self.failures),
            "unique_root_causes": len(self.rca_results),
            "analyses": [],
        }

        for fp_hash, result in self.rca_results.items():
            fp = self.fingerprints.get(fp_hash)
            report["analyses"].append({
                "fingerprint_hash": fp_hash,
                "root_cause": result.root_cause,
                "category": result.category,
                "severity": result.severity.value,
                "fix_suggestion": result.fix_suggestion,
                "affected_file": result.affected_file,
                "affected_line": result.affected_line,
                "confidence": result.confidence,
                "evidence": result.evidence,
                "was_critic_override": result.was_critic_override,
                "affected_tests": fp.test_names if fp else [],
                "occurrence_count": fp.count if fp else 1,
            })

        report_path = self.output_dir / "rca_report.json"
        report_path.write_text(json.dumps(report, indent=2))

        html_path = self.output_dir / "rca_report.html"
        stability_summary = self.scorer.get_summary() if self.scorer.history else None
        html_path.write_text(
            generate_html_report(report, self.fingerprints, stability_summary),
            encoding="utf-8",
        )

    def _generate_stability_report(self):
        """Write stability/flakiness report."""
        self.output_dir.mkdir(parents=True, exist_ok=True)

        summary = self.scorer.get_summary()

        # Add per-test details
        details = []
        for test_name in self.scorer.history:
            stability = self.scorer.score(test_name)
            details.append({
                "test_name": stability.test_name,
                "grade": stability.grade.value,
                "pass_rate": f"{stability.pass_rate:.1%}",
                "flakiness_score": stability.flakiness_score,
                "verdict": stability.verdict.value,
                "total_runs": stability.total_runs,
                "avg_duration": f"{stability.avg_duration:.3f}s",
                "trend": stability.trend,
            })

        report = {
            "timestamp": time.time(),
            "summary": summary,
            "tests": details,
        }

        report_path = self.output_dir / "stability_report.json"
        report_path.write_text(json.dumps(report, indent=2))
