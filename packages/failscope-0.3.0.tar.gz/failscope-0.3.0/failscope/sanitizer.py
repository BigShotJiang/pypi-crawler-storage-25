"""
PII & Secrets Sanitizer — Pre-LLM Scrubbing Layer
===================================================

Scrubs sensitive data from test logs and local variables before
they are sent to external LLM APIs (Groq, OpenAI, Anthropic).

Applied to:
  - preprocessed log text
  - local variable snapshots captured from tracebacks
  - fixture arguments and test context

Replacements use typed placeholders so the LLM still understands
the structure: e.g. [REDACTED:api_key] instead of a blank gap.
"""

import re
from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# Redaction patterns — ordered from most specific to most general
# ---------------------------------------------------------------------------
_PATTERNS: list[tuple[str, str]] = [
    # Private keys / certificates
    (r"-----BEGIN\s+(?:RSA\s+)?PRIVATE KEY-----[\s\S]*?-----END\s+(?:RSA\s+)?PRIVATE KEY-----",
     "private_key"),

    # AWS access key IDs
    (r"\bAKIA[0-9A-Z]{16}\b", "aws_key_id"),

    # AWS secret access key (typical 40-char base64)
    (r"(?i)(?:aws.?secret.?access.?key|AWS_SECRET_ACCESS_KEY)\s*[=:]\s*\S+", "aws_secret"),

    # JWT tokens (three base64url segments)
    (r"\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b", "jwt_token"),

    # Bearer / Authorization header values
    (r"(?i)(?:Bearer\s+|Authorization:\s*(?:Bearer\s+)?)([A-Za-z0-9+/._~:@!$&'()*+,;=%-]{20,})",
     "bearer_token"),

    # Generic API keys in assignment context — handles plain (key=val), YAML (key: val),
    # and JSON ("key": "val") formats
    (r"(?i)['\"]?\b(?:api.?key|api.?token|secret.?key|access.?token|auth.?token|"
     r"client.?secret|private.?key|app.?secret|webhook.?secret)\b['\"]?\s*[=:]\s*"
     r"['\"]?([A-Za-z0-9+/._~-]{8,})['\"]?",
     "api_key"),

    # Passwords in assignment context — handles plain, YAML, and JSON formats.
    # Uses word boundary to avoid false positives like "bypass=..."
    (r"(?i)['\"]?\b(?:password|passwd|pwd)\b['\"]?\s*[=:]\s*['\"]?([^\s,'\";]{4,})['\"]?",
     "password"),

    # Database connection strings (contain credentials)
    (r"(?i)(?:postgres|mysql|mongodb|redis|amqp|smtp)(?:s|srv)?://[^@\s]+@\S+", "db_url"),

    # Common secret prefixes used by popular services
    # GitHub: ghp_, gho_, ghs_; OpenAI: sk-; Anthropic: sk-ant-; Stripe: sk_live_, rk_live_
    (r"\b(?:ghp_|gho_|ghs_|github_pat_|sk-ant-api\d+-|sk-(?:live|test|proj)-|"
     r"rk_(?:live|test)_|pk_(?:live|test)_|xoxb-|xoxp-|xoxa-|ya29\.)[A-Za-z0-9._/+=-]{10,}",
     "service_token"),

    # Email addresses
    (r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b", "email"),

    # Credit card numbers (basic Luhn-adjacent pattern — 13-19 digits with optional separators)
    (r"\b(?:\d[ -]?){13,19}\b(?=.*\b(?:card|cvv|ccv|exp|credit|debit)\b)", "credit_card"),

    # IPv4 addresses — only when adjacent to sensitive key names
    (r"(?i)(?:ip|host|server|endpoint)\s*[=:]\s*(\d{1,3}\.){3}\d{1,3}", "ip_address"),

    # High-entropy strings that look like secrets (32+ hex chars, e.g. MD5/SHA tokens)
    (r"\b[0-9a-f]{32,64}\b", "hex_secret"),
]

# Pre-compile all patterns
_COMPILED: list[tuple[re.Pattern, str]] = [
    (re.compile(pattern, re.MULTILINE), label)
    for pattern, label in _PATTERNS
]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
@dataclass
class SanitizationResult:
    text: str
    redaction_count: int
    redacted_types: list[str] = field(default_factory=list)


def sanitize(text: str) -> SanitizationResult:
    """
    Scrub PII and secrets from a string before sending to an LLM.

    Returns the sanitized text and a count + list of what was redacted
    so the plugin can surface a warning if sensitive data was found.
    """
    if not text:
        return SanitizationResult(text=text, redaction_count=0)

    result = text
    total = 0
    types_found: list[str] = []

    for pattern, label in _COMPILED:
        matches = pattern.findall(result)
        if matches:
            replacement = f"[REDACTED:{label}]"
            result = pattern.sub(replacement, result)
            count = len(matches)
            total += count
            types_found.extend([label] * count)

    return SanitizationResult(
        text=result,
        redaction_count=total,
        redacted_types=types_found,
    )


def sanitize_locals(locals_json: str) -> SanitizationResult:
    """
    Sanitize a JSON-encoded local-variables snapshot.
    Works on the raw JSON string so structure is preserved.
    """
    return sanitize(locals_json)
