use pyo3::prelude::*;

mod transport;
mod pyo3_serde;
mod spec;
mod scale;
pub(crate) mod transform;
pub(crate) mod layout;
pub(crate) mod render;
pub(crate) mod diagnostics;
pub(crate) mod projection;

#[pymodule]
fn _core(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(transport::process_batch, m)?)?;
    m.add_class::<spec::chart::ChartSpec>()?;
    m.add_class::<spec::encoding::EncodingSpec>()?;
    m.add_class::<scale::linear::LinearScale>()?;
    m.add_class::<scale::log::LogScale>()?;
    m.add_class::<scale::symlog::SymlogScale>()?;
    m.add_class::<scale::time::TimeScale>()?;
    m.add_class::<scale::ordinal::OrdinalScale>()?;
    m.add_class::<scale::threshold::ThresholdScale>()?;
    m.add_class::<scale::quantile::QuantileScale>()?;
    m.add_class::<scale::pow::PowScale>()?;
    m.add_class::<scale::pow::SqrtScale>()?;
    m.add_class::<scale::band::BandScale>()?;
    m.add_class::<scale::point::PointScale>()?;
    m.add_class::<scale::sequential::SequentialScale>()?;
    m.add_class::<scale::diverging::DivergingScale>()?;
    m.add_class::<scale::quantize::QuantizeScale>()?;
    m.add_class::<scale::bin_ordinal::BinOrdinalScale>()?;
    // Transform PyO3 wrappers, driven by the single-source-of-truth macro
    // in transform/core.rs. Adding a new transform is one line there;
    // registration happens automatically here.
    macro_rules! register_transforms {
        ($($V:ident => $mod:ident : $py:ident,)*) => {{
            $( m.add_class::<crate::transform::$mod::$py>()?; )*
        }};
    }
    crate::transform::core::for_each_transform!(register_transforms);
    // PyAggregateOp is the op-spec helper class, not a TransformSpec
    // variant — registered manually.
    m.add_class::<transform::aggregate::PyAggregateOp>()?;
    m.add_function(wrap_pyfunction!(layout::binding::compute_layout, m)?)?;
    m.add_function(wrap_pyfunction!(render::binding::render_svg, m)?)?;
    m.add_function(wrap_pyfunction!(render::binding::render_png, m)?)?;
    m.add_function(wrap_pyfunction!(render::binding::render_interactive, m)?)?;
    m.add_function(wrap_pyfunction!(render::binding::rasterize_svg, m)?)?;
    m.add_function(wrap_pyfunction!(render::binding::compose_svg_horizontal_py, m)?)?;
    m.add_function(wrap_pyfunction!(render::binding::compose_svg_vertical_py, m)?)?;
    m.add_function(wrap_pyfunction!(render::binding::compose_svg_grid_py, m)?)?;
    // Phase 8b Task 37: continuous color schemes.
    m.add_class::<render::color::continuous::PyContinuousScheme>()?;
    m.add_function(wrap_pyfunction!(render::color::continuous::Gradient, m)?)?;
    // Phase 10g Task 35: Kendall's tau-b (Knight's O(n log n)).
    m.add_function(wrap_pyfunction!(diagnostics::py_kendall_tau_b, m)?)?;
    // Tier 3: Rust-native statistics (replaces stats.py).
    m.add_function(wrap_pyfunction!(transform::stats::hat_matrix_stats, m)?)?;
    m.add_function(wrap_pyfunction!(transform::stats::studentized_residual_no_x, m)?)?;
    m.add_function(wrap_pyfunction!(transform::stats::py_shapiro_w, m)?)?;
    m.add_function(wrap_pyfunction!(transform::stats::py_rankdata_average, m)?)?;
    m.add_function(wrap_pyfunction!(transform::stats::py_rank1d, m)?)?;
    m.add_function(wrap_pyfunction!(transform::stats::py_rank1d_with_y, m)?)?;
    m.add_function(wrap_pyfunction!(transform::stats::py_rank2d, m)?)?;
    m.add_function(wrap_pyfunction!(transform::stats::pca_scores, m)?)?;
    m.add_function(wrap_pyfunction!(transform::stats::pca_variance, m)?)?;
    m.add_function(wrap_pyfunction!(transform::stats::mds_classical, m)?)?;
    m.add_function(wrap_pyfunction!(transform::stats::silhouette_samples, m)?)?;
    m.add_function(wrap_pyfunction!(transform::stats::silhouette_score, m)?)?;
    m.add_function(wrap_pyfunction!(transform::stats::calinski_harabasz_score, m)?)?;
    // Phase 10: Rust-native t-SNE and UMAP via manifolds-rs.
    m.add_function(wrap_pyfunction!(transform::stats::tsne_embedding, m)?)?;
    m.add_function(wrap_pyfunction!(transform::stats::umap_embedding, m)?)?;
    Ok(())
}
