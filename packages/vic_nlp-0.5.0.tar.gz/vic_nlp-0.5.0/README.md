# Vic - The AI-Powered Computer Interface (v0.3.0)

**Vic** is a library built for **Natural Language Creation and No-Code AI**. It allows anyone to control their computer, generate functional software, and train AI models using simple English.

## Key Features
- 🤖 **AI No-Code Studio**: Train, evaluate, and export AI models (AutoML) with zero coding.
- 🚀 **Zero Code Interface**: Control your system or build apps by just describing them.
- 🎨 **Visual Dashboard**: A multi-tab dashboard for Peek Assistant and AI Training.
- 🛠️ **Editable Apps**: Generates clean Python code that you can modify at any time.
- 🧠 **Smarter Engine**: Auto-corrects typos and provides intelligent suggestions.
- 📦 **Local & Private**: All AI training and commands execute locally on your PC.

## Installation

```bash
cd "c:\my lib\naturalpy"
pip install -e .
```

Dependencies (recommended):
```bash
pip install psutil requests
```

## Quick Start

### 1. The Dashboard (Highly Recommended)
Launch the visual interface to start creating:
```bash
vic --gui
```

### 2. Command Line
Run quick commands from your terminal:
```bash
vic "open calculator"
vic "make a snake game"
vic "search for vic library documentation"
```

### 3. Interactive Mode
```bash
vic -i
```

## Making & Modifying
Vic is designed to help you learn. When you ask Vic to **"make a calculator"**, it generates a file named `calculator_app.py`. 
- In the Dashboard, click **"Modifice in Editor"** to open it.
- The code is heavily commented so you can see exactly how it works.

## Example Commands
- "open notepad"
- "what is my ip address"
- "make a loop that repeats 10 times"
- "build an inventory system"
- "say welcome to the world of Vic"
