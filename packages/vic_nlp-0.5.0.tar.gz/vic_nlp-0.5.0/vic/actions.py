import os
import subprocess
import webbrowser
import platform
import time
from datetime import datetime

class SystemActions:
    def __init__(self):
        self.os_type = platform.system()

    def execute(self, intent, original_sentence):
        """Dispatches to the correct action based on intent."""
        method_name = f"_{intent}"
        if hasattr(self, method_name):
            method = getattr(self, method_name)
            return method(original_sentence)
        else:
            return f"Action '{intent}' recognized, but not implemented in Vic yet."

    # ──────────────────────────────────────────────
    #  ACTION IMPLEMENTATIONS
    # ──────────────────────────────────────────────

    def _open_calculator(self, _):
        if self.os_type == "Windows":
            subprocess.Popen(["calc.exe"])
            return "Opening Calculator... Done."
        return "Calculator opening is only supported on Windows in this version."

    def _open_notepad(self, _):
        if self.os_type == "Windows":
            subprocess.Popen(["notepad.exe"])
            return "Launching Notepad editor... Done."
        return "Notepad is only supported on Windows."

    def _open_explorer(self, _):
        if self.os_type == "Windows":
            subprocess.Popen(["explorer.exe"])
            return "Opening File Explorer... Done."
        return "File Explorer opening is only supported on Windows."

    def _open_browser(self, _):
        webbrowser.open("https://www.google.com")
        return "Opening your default web browser..."

    def _get_time(self, _):
        now = datetime.now().strftime("%H:%M:%S")
        return f"The current time is {now}."

    def _get_date(self, _):
        today = datetime.now().strftime("%A, %B %d, %Y")
        return f"Today is {today}."

    def _web_search(self, sentence):
        query = sentence.lower().replace("search for", "").replace("google", "").replace("search", "").replace("vic", "").strip()
        if not query:
            return "What would you like Vic to search for?"
        url = f"https://www.google.com/search?q={query}"
        webbrowser.open(url)
        return f"Searching for '{query}' online..."

    def _open_website(self, sentence):
        import re
        match = re.search(r'(https?://\S+|www\.\S+|\w+\.com|\w+\.org|\w+\.io)', sentence.lower())
        if match:
            url = match.group(0)
            if not url.startswith("http"):
                url = "https://" + url
            webbrowser.open(url)
            return f"Opening {url}..."
        return "I couldn't find a website link in that sentence."

    def _speak(self, sentence):
        text = sentence.lower().replace("say", "").replace("speak", "").replace("tell me", "").replace("vic", "").strip()
        if not text:
            return "What should I say?"
        
        if self.os_type == "Windows":
            cmd = f'Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak("{text}")'
            subprocess.Popen(["powershell", "-Command", cmd])
            return f"Vic says: {text}"
        return f"Speech synthesis is not yet supported on {self.os_type}."

    def _list_files(self, _):
        files = os.listdir(".")
        file_list = "\n".join(files[:10])
        if len(files) > 10:
            file_list += f"\n... and {len(files)-10} more."
        return f"Files in current folder:\n{file_list}"

    def _check_internet(self, _):
        try:
            subprocess.check_output(["ping", "-n", "1", "8.8.8.8"], stderr=subprocess.STDOUT)
            return "Internet connection confirmed (Pinged 8.8.8.8)."
        except:
            return "No internet connection detected."

    def _get_sysinfo(self, _):
        try:
            import psutil
            cpu = psutil.cpu_percent(interval=1)
            mem = psutil.virtual_memory().percent
            return f"System Stats:\nCPU Usage: {cpu}%\nMemory Usage: {mem}%"
        except ImportError:
            return "Please 'pip install psutil' for detailed system stats."

    def _open_terminal(self, _):
        if self.os_type == "Windows":
            subprocess.Popen(["cmd.exe", "/c", "start", "cmd.exe"])
            return "Opening Command Prompt terminal..."
        return "Terminal opening not supported on this OS."

    def _get_ip(self, _):
        import socket
        try:
            hostname = socket.gethostname()
            ip = socket.gethostbyname(hostname)
            return f"Your local IP: {ip}"
        except:
            return "Couldn't find IP."

    def _create_folder(self, sentence):
        name = sentence.lower().replace("create folder", "").replace("make folder", "").replace("named", "").replace("vic", "").strip()
        if not name:
            name = f"vic_new_folder_{int(time.time())}"
        try:
            os.makedirs(name)
            return f"Vic created folder: {name}"
        except Exception as e:
            return f"Error: {str(e)}"
