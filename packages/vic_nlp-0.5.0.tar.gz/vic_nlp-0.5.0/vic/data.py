import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

class DataProcessor:
    def __init__(self, log_callback=None):
        self.log_callback = log_callback
        self.df = None
        self.file_path = None
        self.history = [] # Tracks actions for reports/code

    def log(self, message):
        if self.log_callback:
            self.log_callback(message)
        else:
            print(f"[Data]: {message}")

    def load_data(self, path):
        try:
            ext = os.path.splitext(path)[1].lower()
            if ext == '.csv':
                self.df = pd.read_csv(path)
            elif ext in ['.xls', '.xlsx']:
                self.df = pd.read_excel(path)
            elif ext == '.json':
                self.df = pd.read_json(path)
            else:
                return False, f"Unsupported format: {ext}"
            
            self.file_path = path
            self.log(f"Loaded dataset with {len(self.df)} rows.")
            self.history.append({"action": "Load Data", "details": f"Loaded {os.path.basename(path)}", "code": f"df = pd.read_csv('{path}')"})
            return True, f"Successfully loaded {os.path.basename(path)}"
        except Exception as e:
            return False, str(e)

    def clean_data(self, action="auto"):
        if self.df is None:
            return False, "No data loaded."
        
        try:
            code = ""
            if action == "auto":
                # 1. Remove duplicates
                self.df.drop_duplicates(inplace=True)
                
                # 2. Handle common messiness (symbols, spaces)
                for col in self.df.columns:
                    if self.df[col].dtype == 'object':
                        # Strip spaces
                        self.df[col] = self.df[col].astype(str).str.strip()
                        # Try to convert currency/percentage to numeric
                        if self.df[col].str.contains('[$%]').any():
                            self.df[col] = self.df[col].str.replace('[$%,]', '', regex=True)
                            self.df[col] = pd.to_numeric(self.df[col], errors='coerce')
                
                # 3. Fill missing values
                for col in self.df.columns:
                    if self.df[col].dtype in ['int64', 'float64']:
                        self.df[col].fillna(self.df[col].mean(), inplace=True)
                    else:
                        self.df[col].fillna(self.df[col].mode()[0] if not self.df[col].mode().empty else "Unknown", inplace=True)
                
                self.log("Auto-cleaned: Handled symbols, removed duplicates and filled missing values.")
                code = "df.drop_duplicates(inplace=True)\n# Cleaning symbols and missing values...\nfor col in df.columns: ... # (Logic for currency stripping and imputation)"
            
            self.history.append({"action": "Data Cleaning", "details": "Robust auto-cleaning performed.", "code": code})
            return True, "Data cleaned successfully."
        except Exception as e:
            return False, str(e)

    def generate_graph(self, type="histogram", column=None, x=None, y=None):
        if self.df is None:
            return False, "No data loaded."
        
        try:
            plt.figure(figsize=(10, 6))
            sns.set_style("whitegrid")
            code = f"import seaborn as sns\nimport matplotlib.pyplot as plt\nplt.figure(figsize=(10, 6))\nsns.set_style('whitegrid')\n"

            if type == "histogram":
                if not column: column = self.df.select_dtypes(include=['number']).columns[0]
                sns.histplot(self.df[column], kde=True, color='skyblue')
                plt.title(f"Histogram of {column}")
                code += f"sns.histplot(df['{column}'], kde=True)\nplt.show()"
            
            elif type == "scatter":
                if not x or not y:
                    nums = self.df.select_dtypes(include=['number']).columns
                    x, y = nums[0], nums[1] if len(nums) > 1 else nums[0]
                sns.scatterplot(data=self.df, x=x, y=y, color='coral')
                plt.title(f"Scatter Plot: {x} vs {y}")
                code += f"sns.scatterplot(data=df, x='{x}', y='{y}')\nplt.show()"
            
            # ... (simplified other types for brevity in this step)

            plt.tight_layout()
            graph_path = f"vic_graph_{int(pd.Timestamp.now().timestamp())}.png"
            plt.savefig(graph_path)
            plt.close()
            
            self.history.append({"action": "Visualization", "details": f"Generated {type} plot.", "code": code, "image": graph_path})
            return True, graph_path
        except Exception as e:
            return False, str(e)

    def generate_report(self):
        from .reporter import HTMLReporter
        reporter = HTMLReporter(project_name=f"Report for {os.path.basename(self.file_path) if self.file_path else 'Analysis'}")
        
        for item in self.history:
            reporter.add_section(item['action'], item['details'], image_path=item.get('image'))
        
        return reporter.generate()

    def export_code(self):
        from .exporter import CodeExporter
        exporter = CodeExporter()
        for item in self.history:
            exporter.add_step(item['action'], item['code'])
        return exporter.generate()

    def get_stats(self):
        if self.df is None:
            return "No data loaded."
        return self.df.describe().to_string()
