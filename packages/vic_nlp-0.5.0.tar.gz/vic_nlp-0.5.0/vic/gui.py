import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import subprocess
import os
import platform
import threading
from vic import Vic
from vic.ai import AutoTrainer

class VicGUI:
    def __init__(self, root):
        self.root = root
        self.vic = Vic()
        self.trainer = AutoTrainer(log_callback=self.ai_log)
        
        self.root.title("Vic - Multi-Purpose AI OS")
        self.root.geometry("850x700")
        
        # --- UI DESIGN (Premium Dark Mode) ---
        self.bg_color = "#1e1e1e"
        self.fg_color = "#e0e0e0"
        self.accent_color = "#007acc"
        self.button_bg = "#333333"
        self.entry_bg = "#2d2d2d"
        
        self.root.configure(bg=self.bg_color)
        
        # Style Configuration
        self.style = ttk.Style()
        self.style.theme_use("default")
        self.style.configure("TNotebook", background=self.bg_color, borderwidth=0)
        self.style.configure("TNotebook.Tab", background="#333333", foreground="#e0e0e0", padding=[20, 5], font=("Inter", 10))
        self.style.map("TNotebook.Tab", background=[("selected", self.accent_color)], foreground=[("selected", "white")])
        self.style.configure("TFrame", background=self.bg_color)
        
        # ProgressBar Style
        self.style.configure("Horizontal.TProgressbar", background=self.accent_color, troughcolor="#2d2d2d", bordercolor="#2d2d2d", lightcolor=self.accent_color, darkcolor=self.accent_color)

        # Tabbed Layout
        self.notebook = ttk.Notebook(root)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=10)

        self.tab_assistant = ttk.Frame(self.notebook)
        self.tab_data_lab = ttk.Frame(self.notebook)
        self.tab_ai_lab = ttk.Frame(self.notebook)

        self.notebook.add(self.tab_assistant, text="  VIC ASSISTANT  ")
        self.notebook.add(self.tab_data_lab, text="  STUDENT DATA LAB  ")
        self.notebook.add(self.tab_ai_lab, text="  AI NO-CODE LAB  ")

        self.setup_assistant_tab()
        self.setup_data_lab_tab()
        self.setup_ai_lab_tab()

    def setup_data_lab_tab(self):
        from vic.data import DataProcessor
        self.data_proc = DataProcessor(log_callback=self.data_log)
        
        header = tk.Label(self.tab_data_lab, text="STUDENT DATA LAB", font=("Inter", 20, "bold"), bg=self.bg_color, fg="#fbbf24", pady=20)
        header.pack()

        form_frame = tk.Frame(self.tab_data_lab, bg=self.bg_color); form_frame.pack(pady=10, fill="x", padx=40)
        
        # Load Data
        tk.Label(form_frame, text="Load Dataset:", bg=self.bg_color, fg=self.fg_color, font=("Inter", 10)).grid(row=0, column=0, sticky="w")
        self.data_file_entry = tk.Entry(form_frame, font=("Inter", 11), bg=self.entry_bg, fg="white", bd=0, highlightthickness=1, highlightbackground="#444444")
        self.data_file_entry.grid(row=1, column=0, sticky="ew", pady=5, ipady=5)
        tk.Button(form_frame, text="BROWSE", command=self.browse_data_lab, bg=self.button_bg, fg="white", font=("Inter", 9), padx=10, bd=0).grid(row=1, column=1, padx=5)

        # Actions
        actions_frame = tk.Frame(self.tab_data_lab, bg=self.bg_color); actions_frame.pack(pady=10, fill="x", padx=40)
        
        tk.Label(actions_frame, text="Data Cleaning & Analysis:", bg=self.bg_color, fg=self.fg_color, font=("Inter", 10, "bold")).pack(anchor="w", pady=5)
        btn_grid = tk.Frame(actions_frame, bg=self.bg_color); btn_grid.pack(fill="x")
        
        self.clean_btn = tk.Button(btn_grid, text="✨ AUTO CLEAN", command=self.run_clean, bg="#3b82f6", fg="white", font=("Inter", 10, "bold"), padx=15, pady=8, bd=0)
        self.clean_btn.pack(side="left", padx=5)
        
        self.stats_btn = tk.Button(btn_grid, text="📊 SHOW STATS", command=self.run_stats, bg="#8b5cf6", fg="white", font=("Inter", 10, "bold"), padx=15, pady=8, bd=0)
        self.stats_btn.pack(side="left", padx=5)

        tk.Label(actions_frame, text="Project Export:", bg=self.bg_color, fg=self.fg_color, font=("Inter", 10, "bold")).pack(anchor="w", pady=(15, 5))
        export_grid = tk.Frame(actions_frame, bg=self.bg_color); export_grid.pack(fill="x")
        
        self.report_btn = tk.Button(export_grid, text="📄 GENERATE REPORT", command=self.run_report, bg="#ec4899", fg="white", font=("Inter", 10, "bold"), padx=15, pady=8, bd=0)
        self.report_btn.pack(side="left", padx=5)
        
        self.code_btn = tk.Button(export_grid, text="💻 SHOW ME THE CODE", command=self.run_export, bg="#10b981", fg="white", font=("Inter", 10, "bold"), padx=15, pady=8, bd=0)
        self.code_btn.pack(side="left", padx=5)

        tk.Label(actions_frame, text="Visualizations:", bg=self.bg_color, fg=self.fg_color, font=("Inter", 10, "bold")).pack(anchor="w", pady=15)
        viz_grid = tk.Frame(actions_frame, bg=self.bg_color); viz_grid.pack(fill="x")
        
        tk.Button(viz_grid, text="📈 HISTOGRAM", command=lambda: self.run_viz("histogram"), bg="#ef4444", fg="white", font=("Inter", 9, "bold"), padx=10, pady=5, bd=0).pack(side="left", padx=5)
        tk.Button(viz_grid, text="📉 SCATTER PLOT", command=lambda: self.run_viz("scatter"), bg="#f59e0b", fg="white", font=("Inter", 9, "bold"), padx=10, pady=5, bd=0).pack(side="left", padx=5)
        tk.Button(viz_grid, text="🌡️ BOX PLOT", command=lambda: self.run_viz("box"), bg="#10b981", fg="white", font=("Inter", 9, "bold"), padx=10, pady=5, bd=0).pack(side="left", padx=5)

        # Log
        tk.Label(self.tab_data_lab, text="Data Console:", bg=self.bg_color, fg=self.fg_color, font=("Inter", 10)).pack(padx=40, anchor="w", pady=(20, 0))
        self.data_log_area = scrolledtext.ScrolledText(self.tab_data_lab, font=("Consolas", 10), bg="#121212", fg="#fbbf24", bd=0, padx=10, pady=10, height=8)
        self.data_log_area.pack(fill="both", expand=True, padx=40, pady=5)
        form_frame.columnconfigure(0, weight=1)

    def browse_data_lab(self):
        filename = filedialog.askopenfilename(filetypes=[("Data files", "*.csv *.xlsx *.xls *.json"), ("All files", "*.*")])
        if filename: self.data_file_entry.delete(0, tk.END); self.data_file_entry.insert(0, filename); self.data_proc.load_data(filename)

    def data_log(self, message):
        self.data_log_area.insert(tk.END, f"{message}\n"); self.data_log_area.see(tk.END); self.root.update()

    def run_clean(self):
        success, msg = self.data_proc.clean_data()
        if success: messagebox.showinfo("Data Lab", "Data cleaned! Duplicates removed and missing values filled.")
        else: messagebox.showerror("Data Lab", msg)

    def run_stats(self):
        stats = self.data_proc.get_stats()
        self.data_log_area.delete(1.0, tk.END); self.data_log(f"--- DATA STATISTICS ---\n{stats}")

    def run_viz(self, type):
        success, path = self.data_proc.generate_graph(type=type)
        if success:
            if platform.system() == "Windows": os.startfile(path)
            else: subprocess.Popen(["open", path])
            self.data_log(f"Generated {type} plot: {path}")
        else: messagebox.showerror("Data Lab", path)

    def run_report(self):
        try:
            path = self.data_proc.generate_report()
            if platform.system() == "Windows": os.startfile(path)
            else: subprocess.Popen(["open", path])
            self.data_log(f"Project report generated: {path}")
        except Exception as e: messagebox.showerror("Report", str(e))

    def run_export(self):
        try:
            path = self.data_proc.export_code()
            if platform.system() == "Windows":
                try: subprocess.Popen(["code", path], shell=True)
                except: os.startfile(path)
            else: subprocess.Popen(["open", path])
            self.data_log(f"Code session exported: {path}")
        except Exception as e: messagebox.showerror("Export", str(e))

    def setup_assistant_tab(self):
        header = tk.Label(self.tab_assistant, text="VIC ASSISTANT", font=("Inter", 20, "bold"), bg=self.bg_color, fg=self.accent_color, pady=20)
        header.pack()
        input_frame = tk.Frame(self.tab_assistant, bg=self.bg_color); input_frame.pack(pady=10, fill="x", padx=40)
        tk.Label(input_frame, text="Describe what you want:", bg=self.bg_color, fg=self.fg_color, font=("Inter", 10)).pack(anchor="w")
        self.entry = tk.Entry(input_frame, font=("Inter", 14), bg=self.entry_bg, fg="white", insertbackground="white", bd=0, highlightthickness=1, highlightbackground="#444444")
        self.entry.pack(fill="x", pady=5, ipady=8); self.entry.bind("<Return>", lambda e: self.process_command())
        btn_frame = tk.Frame(self.tab_assistant, bg=self.bg_color); btn_frame.pack(pady=10)
        self.run_btn = tk.Button(btn_frame, text="RUN COMMAND", command=self.process_command, bg=self.accent_color, fg="white", font=("Inter", 10, "bold"), padx=20, pady=5, bd=0, cursor="hand2")
        self.run_btn.pack(side="left", padx=10)
        output_frame = tk.Frame(self.tab_assistant, bg=self.bg_color); output_frame.pack(pady=20, fill="both", expand=True, padx=40)
        tk.Label(output_frame, text="Response:", bg=self.bg_color, fg=self.fg_color, font=("Inter", 10)).pack(anchor="w")
        self.output_area = scrolledtext.ScrolledText(output_frame, font=("Consolas", 11), bg=self.entry_bg, fg="#d4d4d4", bd=0, padx=10, pady=10, insertbackground="white")
        self.output_area.pack(fill="both", expand=True)
        footer_frame = tk.Frame(self.tab_assistant, bg=self.bg_color); footer_frame.pack(pady=15, fill="x", padx=40)
        self.modify_btn = tk.Button(footer_frame, text="OPEN IN EDITOR", command=self.open_in_editor, bg=self.button_bg, fg="white", font=("Inter", 9), padx=15, pady=3, bd=0, cursor="hand2", state="disabled")
        self.modify_btn.pack(side="left")
        self.copy_btn = tk.Button(footer_frame, text="COPY CODE", command=self.copy_to_clipboard, bg=self.button_bg, fg="white", font=("Inter", 9), padx=15, pady=3, bd=0, cursor="hand2")
        self.copy_btn.pack(side="right")
        self.last_generated_file = None

    def setup_ai_lab_tab(self):
        header = tk.Label(self.tab_ai_lab, text="AI STUDIO", font=("Inter", 20, "bold"), bg=self.bg_color, fg="#10b981", pady=20)
        header.pack()
        form_frame = tk.Frame(self.tab_ai_lab, bg=self.bg_color); form_frame.pack(pady=10, fill="x", padx=40)

        # Dataset Path
        tk.Label(form_frame, text="Dataset Location (CSV/Excel/JSON):", bg=self.bg_color, fg=self.fg_color, font=("Inter", 10)).grid(row=0, column=0, sticky="w", pady=5)
        self.data_path_entry = tk.Entry(form_frame, font=("Inter", 11), bg=self.entry_bg, fg="white", bd=0, highlightthickness=1, highlightbackground="#444444")
        self.data_path_entry.grid(row=1, column=0, sticky="ew", pady=5, ipady=5)
        self.browse_btn = tk.Button(form_frame, text="BROWSE", command=self.browse_data, bg=self.button_bg, fg="white", font=("Inter", 9), padx=10, bd=0); self.browse_btn.grid(row=1, column=1, padx=5)

        # Mode Selection Dropdown
        tk.Label(form_frame, text="Training Mode:", bg=self.bg_color, fg=self.fg_color, font=("Inter", 10)).grid(row=2, column=0, sticky="w", pady=5)
        self.mode_var = tk.StringVar(value="Auto-Detect")
        self.mode_dropdown = ttk.Combobox(form_frame, textvariable=self.mode_var, font=("Inter", 11), state="readonly")
        self.mode_dropdown['values'] = ("Auto-Detect", "Classification", "Regression", "Clustering")
        self.mode_dropdown.grid(row=3, column=0, sticky="ew", pady=5)
        self.mode_dropdown.bind("<<ComboboxSelected>>", self.on_mode_change)

        # Target Column
        self.target_label = tk.Label(form_frame, text="Target Column (What to predict?):", bg=self.bg_color, fg=self.fg_color, font=("Inter", 10))
        self.target_label.grid(row=4, column=0, sticky="w", pady=10)
        self.target_entry = tk.Entry(form_frame, font=("Inter", 11), bg=self.entry_bg, fg="white", bd=0, highlightthickness=1, highlightbackground="#444444")
        self.target_entry.grid(row=5, column=0, sticky="ew", pady=5, ipady=5)

        # Progress Bar
        self.progress = ttk.Progressbar(self.tab_ai_lab, mode="indeterminate", style="Horizontal.TProgressbar")
        self.progress.pack(fill="x", padx=40, pady=5)

        # Train Button
        self.train_btn = tk.Button(self.tab_ai_lab, text="TRAIN MY MODEL", command=self.start_training, bg="#10b981", fg="white", font=("Inter", 12, "bold"), padx=30, pady=10, bd=0, cursor="hand2")
        self.train_btn.pack(pady=15)

        # Results & Actions
        self.bottom_frame = tk.Frame(self.tab_ai_lab, bg=self.bg_color); self.bottom_frame.pack(side="bottom", fill="x", padx=40, pady=10)
        self.save_model_btn = tk.Button(self.bottom_frame, text="💾 EXPORT MODEL (.pkl)", command=self.save_model, bg="#007acc", fg="white", font=("Inter", 11, "bold"), padx=20, pady=10, bd=0, cursor="hand2", state="disabled")
        self.save_model_btn.pack(side="right")

        # Console
        tk.Label(self.tab_ai_lab, text="AI Console:", bg=self.bg_color, fg=self.fg_color, font=("Inter", 10)).pack(padx=40, anchor="w")
        self.ai_log_area = scrolledtext.ScrolledText(self.tab_ai_lab, font=("Consolas", 10), bg="#121212", fg="#10b981", bd=0, padx=10, pady=10, height=8)
        self.ai_log_area.pack(fill="both", expand=True, padx=40, pady=5)
        form_frame.columnconfigure(0, weight=1)

    def on_mode_change(self, event=None):
        if self.mode_var.get() == "Clustering":
            self.target_entry.config(state="disabled")
            self.target_label.config(fg="#555555")
        else:
            self.target_entry.config(state="normal")
            self.target_label.config(fg=self.fg_color)

    def browse_data(self):
        filename = filedialog.askopenfilename(filetypes=[("Data files", "*.csv *.xlsx *.xls *.json"), ("All files", "*.*")])
        if filename: self.data_path_entry.delete(0, tk.END); self.data_path_entry.insert(0, filename)

    def ai_log(self, message):
        self.ai_log_area.insert(tk.END, f"{message}\n"); self.ai_log_area.see(tk.END); self.root.update()

    def start_training(self):
        path = self.data_path_entry.get().strip()
        target = self.target_entry.get().strip()
        mode = self.mode_var.get()
        if not path or (not target and mode != "Clustering"):
            messagebox.showwarning("AI Lab", "Please provide data path and target column (unless Clustering)."); return

        self.ai_log_area.delete(1.0, tk.END); self.train_btn.config(state="disabled", text="PROCESSING BIG DATA..."); self.progress.start(10)
        def run():
            success, msg = self.trainer.train(path, target if mode != "Clustering" else None, mode)
            self.root.after(0, lambda: self.finish_training(success, msg))
        threading.Thread(target=run).start()

    def finish_training(self, success, message):
        self.train_btn.config(state="normal", text="TRAIN MY MODEL"); self.progress.stop()
        if success: self.save_model_btn.config(state="normal"); messagebox.showinfo("AI Lab", message)
        else: messagebox.showerror("AI Lab", f"Failed: {message}")

    def save_model(self):
        file_path = filedialog.asksaveasfilename(defaultextension=".pkl", filetypes=[("Model files", "*.pkl")])
        if file_path:
            success, msg = self.trainer.save_model(file_path)
            if success: messagebox.showinfo("AI Lab", msg)
            else: messagebox.showerror("AI Lab", msg)

    # NLP Tab Logic
    def process_command(self):
        sentence = self.entry.get().strip()
        if not sentence: return
        self.output_area.delete(1.0, tk.END); self.output_area.insert(tk.END, "Thinking...\n"); self.root.update()
        result = self.vic.run(sentence)
        self.output_area.delete(1.0, tk.END); self.output_area.insert(tk.END, result)
        if "Successfully built" in result:
            import re; match = re.search(r'built full app: (\S+)', result)
            if match: self.last_generated_file = match.group(1); self.modify_btn.config(state="normal")
        else: self.modify_btn.config(state="disabled")

    def open_in_editor(self):
        if not self.last_generated_file: return
        path = os.path.abspath(self.last_generated_file)
        if platform.system() == "Windows":
            try: subprocess.Popen(["code", path], shell=True)
            except: subprocess.Popen(["notepad.exe", path])
        else: subprocess.Popen(["open", path])

    def copy_to_clipboard(self):
        text = self.output_area.get(1.0, tk.END); self.root.clipboard_clear(); self.root.clipboard_append(text); messagebox.showinfo("Vic", "Copied!")

def main(): root = tk.Tk(); app = VicGUI(root); root.mainloop()
if __name__ == "__main__": main()
