import os
import webbrowser
from .data import DataProcessor
from .ai import AutoTrainer

class DataActions:
    def __init__(self):
        self.processor = DataProcessor()
        self.trainer = AutoTrainer()
        self.last_dataset = None

    def execute(self, intent, sentence):
        method_name = f"_{intent}"
        if hasattr(self, method_name):
            method = getattr(self, method_name)
            return method(sentence)
        return None

    def _data_clean(self, sentence):
        # In a real NLP scenario, we'd extract the path. 
        # For now, we'll look for a CSV/Excel in the current dir if not specified.
        if not self.last_dataset:
            files = [f for f in os.listdir('.') if f.endswith(('.csv', '.xlsx', '.json'))]
            if not files:
                return "I couldn't find any dataset to clean. Please specify a file path or put a CSV in the folder."
            self.last_dataset = files[0]
        
        self.processor.load_data(self.last_dataset)
        success, msg = self.processor.clean_data(action="auto")
        if success:
            # Save cleaned data
            new_name = f"cleaned_{self.last_dataset}"
            self.processor.df.to_csv(new_name, index=False)
            return f"Done! I've cleaned your data and saved it as '{new_name}'."
        return f"Error cleaning data: {msg}"

    def _data_visualize(self, sentence):
        if not self.last_dataset:
            files = [f for f in os.listdir('.') if f.endswith(('.csv', '.xlsx', '.json'))]
            if not files: return "No dataset found to graph."
            self.last_dataset = files[0]
        
        self.processor.load_data(self.last_dataset)
        
        # Simple heuristic for chart type
        chart_type = "histogram"
        if "scatter" in sentence.lower(): chart_type = "scatter"
        elif "line" in sentence.lower(): chart_type = "line"
        elif "box" in sentence.lower(): chart_type = "box"

        success, path = self.processor.generate_graph(type=chart_type)
        if success:
            import os
            # Try to open the image
            if os.name == 'nt': os.startfile(path)
            else: webbrowser.open(f"file://{os.path.abspath(path)}")
            return f"I've generated a {chart_type} for you! It should be opening now."
        return f"Error generating graph: {path}"

    def _data_stats(self, sentence):
        if not self.last_dataset:
            files = [f for f in os.listdir('.') if f.endswith(('.csv', '.xlsx', '.json'))]
            if not files: return "No dataset found."
            self.last_dataset = files[0]
        
        self.processor.load_data(self.last_dataset)
        stats = self.processor.get_stats()
        return f"Here are the statistics for {self.last_dataset}:\n\n{stats}"

    def _ai_train(self, sentence):
        return "To train a model, please use the 'AI NO-CODE LAB' tab in the GUI for a better experience with target selection!"

    def _ai_save(self, sentence):
        return "Models can be exported directly from the 'AI NO-CODE LAB' after training."
