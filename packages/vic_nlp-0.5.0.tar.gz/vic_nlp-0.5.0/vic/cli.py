import sys
import argparse
from vic import Vic

def main():
    parser = argparse.ArgumentParser(description="Vic - Your Natural Language Computer Interface.")
    parser.add_argument("command", nargs="?", help="The English sentence command to execute.")
    parser.add_argument("-i", "--interactive", action="store_true", help="Launch Vic in interactive mode.")
    parser.add_argument("-g", "--gui", action="store_true", help="Launch the Vic Dashboard (Visual Mode).")
    
    args = parser.parse_args()
    
    if args.gui:
        try:
            from vic.gui import main as gui_main
            gui_main()
            return
        except ImportError as e:
            print(f"Error launching GUI: {e}")
            return

    v = Vic()
    
    if args.interactive or not args.command:
        print("--- VIC INTERACTIVE MODE ---")
        print("Type 'exit' or 'quit' to stop.")
        while True:
            try:
                sentence = input("vic>>> ")
                if sentence.lower() in ["exit", "quit"]:
                    break
                if not sentence.strip():
                    continue
                result = v.run(sentence)
                print(result)
            except KeyboardInterrupt:
                break
            except Exception as e:
                print(f"Error: {str(e)}")
    else:
        result = v.run(args.command)
        print(result)

if __name__ == "__main__":
    main()
