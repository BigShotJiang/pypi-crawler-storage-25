import os
import subprocess

class CodeGenerator:
    def __init__(self):
        pass

    def generate(self, intent):
        """Generates Python code snippets based on the intent."""
        method_name = f"_{intent}"
        if hasattr(self, method_name):
            method = getattr(self, method_name)
            return method()
        else:
            return f"# Code generation for '{intent}' not yet implemented."

    def build_app(self, intent):
        """Builds a full working application script."""
        method_name = f"_{intent}"
        if hasattr(self, method_name):
            method = getattr(self, method_name)
            content = method()
            filename = f"{intent.replace('app_', '')}_app.py"
            with open(filename, "w") as f:
                f.write(content)
            return f"Successfully built full app: {filename}\nYou can modify this file to learn how it works!"
        else:
            return f"Building logic for '{intent}' not yet implemented."

    # ──────────────────────────────────────────────
    #  CODE SNIPPETS
    # ──────────────────────────────────────────────

    def _code_for_loop(self):
        return """# --- VIC GENERATED CODE ---
# A simple 'for' loop that repeats an action 5 times.
# 'range(5)' creates a list of numbers [0, 1, 2, 3, 4]
for i in range(5):
    print(f"This is loop number {i+1}")
"""

    def _code_function(self):
        return """# --- VIC GENERATED CODE ---
# This defines a 'function' called 'greet'.
# Functions are reusable blocks of code.
def greet(name):
    \"\"\"This function takes a name and returns a greeting.\"\"\"
    return f"Hello, {name}! Welcome to coding with Vic."

# Here we use (call) the function
message = greet("User")
print(message)
"""

    def _code_hello_world(self):
        return '# The classic first step in any language\nprint("Hello, World! Created by Vic.")'

    # ──────────────────────────────────────────────
    #  FULL APP TEMPLATES (MODULAR & COMMENTED)
    # ──────────────────────────────────────────────

    def _app_calculator(self):
        return """# --- VIC GENERATED APP: CALCULATOR ---
# This is a GUI calculator made with 'tkinter'.
import tkinter as tk
from tkinter import messagebox

class CalculatorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Vic Calculator")
        self.root.geometry("300x400")
        self.root.configure(bg="#2d2d2d") # Dark theme
        
        self.result_var = tk.StringVar()
        
        # 1. DISPLAY SCREEN
        # This is where numbers appear
        self.display = tk.Entry(
            root, 
            textvariable=self.result_var, 
            font=("Arial", 24), 
            bg="#1e1e1e", 
            fg="white", 
            bd=10, 
            justify='right'
        )
        self.display.grid(row=0, column=0, columnspan=4, sticky="nsew")
        
        # 2. BUTTONS CONFIGURATION
        buttons = [
            '7', '8', '9', '/',
            '4', '5', '6', '*',
            '1', '2', '3', '-',
            'C', '0', '=', '+'
        ]
        
        row, col = 1, 0
        for button in buttons:
            action = lambda x=button: self.on_click(x)
            btn = tk.Button(
                root, text=button, width=5, height=2, 
                font=("Arial", 14), bg="#3d3d3d", fg="white",
                command=action
            )
            btn.grid(row=row, column=col, sticky="nsew")
            col += 1
            if col > 3:
                col = 0
                row += 1

    def on_click(self, char):
        \"\"\"Handles what happens when you press a button.\"\"\"
        if char == '=':
            try:
                # eval() calculates the string (e.g. "2+2")
                res = eval(self.result_var.get())
                self.result_var.set(res)
            except Exception:
                messagebox.showerror("Error", "Check your math!")
                self.result_var.set("")
        elif char == 'C':
            self.result_var.set("")
        else:
            self.result_var.set(self.result_var.get() + str(char))

if __name__ == "__main__":
    root = tk.Tk()
    app = CalculatorApp(root)
    root.mainloop()
"""

    def _app_snake_game(self):
        return """# --- VIC GENERATED APP: SNAKE GAME ---
import tkinter as tk
import random

class SnakeGame:
    def __init__(self, root):
        self.root = root
        self.root.title("Vic Snake Game")
        
        # Game Settings
        self.grid_size = 20
        self.canvas_size = 400
        self.delay = 100
        
        self.canvas = tk.Canvas(root, width=self.canvas_size, height=self.canvas_size, bg="black")
        self.canvas.pack()
        
        self.snake = [(100, 100), (80, 100), (60, 100)]
        self.direction = "Right"
        self.food = self.spawn_food()
        self.running = True
        
        self.root.bind("<Key>", self.change_direction)
        self.play()

    def spawn_food(self):
        x = random.randint(0, (self.canvas_size // self.grid_size) - 1) * self.grid_size
        y = random.randint(0, (self.canvas_size // self.grid_size) - 1) * self.grid_size
        return (x, y)

    def draw(self):
        self.canvas.delete("all")
        # Draw Snake
        for x, y in self.snake:
            self.canvas.create_rectangle(x, y, x + self.grid_size, y + self.grid_size, fill="green")
        # Draw Food
        fx, fy = self.food
        self.canvas.create_oval(fx, fy, fx + self.grid_size, fy + self.grid_size, fill="red")

    def move(self):
        head_x, head_y = self.snake[0]
        if self.direction == "Left": head_x -= self.grid_size
        elif self.direction == "Right": head_x += self.grid_size
        elif self.direction == "Up": head_y -= self.grid_size
        elif self.direction == "Down": head_y += self.grid_size
        
        new_head = (head_x, head_y)
        self.snake.insert(0, new_head)
        
        # Check Food
        if new_head == self.food:
            self.food = self.spawn_food()
        else:
            self.snake.pop()
            
        # Check Collision
        if (head_x < 0 or head_x >= self.canvas_size or 
            head_y < 0 or head_y >= self.canvas_size or 
            new_head in self.snake[1:]):
            self.running = False

    def change_direction(self, event):
        if event.keysym in ["Up", "Down", "Left", "Right"]:
            self.direction = event.keysym

    def play(self):
        if self.running:
            self.move()
            self.draw()
            self.root.after(self.delay, self.play)
        else:
            self.canvas.create_text(200, 200, text="GAME OVER", fill="white", font=("Arial", 30))

if __name__ == "__main__":
    root = tk.Tk()
    game = SnakeGame(root)
    root.mainloop()
"""

    def _app_weather(self):
        return """# --- VIC GENERATED APP: WEATHER ---
import tkinter as tk
import requests

def get_weather():
    # Using Open-Meteo as it requires NO API KEY
    url = "https://api.open-meteo.com/v1/forecast?latitude=40.71&longitude=-74.01&current_weather=true"
    try:
        response = requests.get(url)
        data = response.json()
        temp = data['current_weather']['temperature']
        label.config(text=f"Current Temp in NYC: {temp}°C")
    except:
        label.config(text="Could not fetch weather data.")

root = tk.Tk()
root.title("Vic Weather")
root.geometry("250x150")

label = tk.Label(root, text="Click to get weather", font=("Arial", 12))
label.pack(pady=20)

btn = tk.Button(root, text="Get Weather (NYC)", command=get_weather)
btn.pack()

root.mainloop()
"""

    def _app_inventory(self):
        return """# --- VIC GENERATED APP: INVENTORY ---
import tkinter as tk

class InventoryApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Vic Inventory Manager")
        self.items = {}

        tk.Label(root, text="Item Name:").grid(row=0, column=0)
        self.name_entry = tk.Entry(root)
        self.name_entry.grid(row=0, column=1)

        tk.Label(root, text="Quantity:").grid(row=1, column=0)
        self.qty_entry = tk.Entry(root)
        self.qty_entry.grid(row=1, column=1)

        tk.Button(root, text="Add/Update", command=self.update_item).grid(row=2, column=0, columnspan=2)
        
        self.listbox = tk.Listbox(root, width=40)
        self.listbox.grid(row=3, column=0, columnspan=2, pady=10)

    def update_item(self):
        name = self.name_entry.get()
        qty = self.qty_entry.get()
        if name and qty:
            self.items[name] = qty
            self.refresh_list()

    def refresh_list(self):
        self.listbox.delete(0, tk.END)
        for name, qty in self.items.items():
            self.listbox.insert(tk.END, f"{name}: {qty}")

if __name__ == "__main__":
    root = tk.Tk()
    app = InventoryApp(root)
    root.mainloop()
"""
