import pandas as pd
import numpy as np
import os
import joblib
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.cluster import KMeans
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, r2_score, silhouette_score

class AutoTrainer:
    def __init__(self, log_callback=None):
        self.log_callback = log_callback
        self.model = None
        self.task_type = None # 'classification', 'regression', or 'clustering'
        self.best_score = 0
        self.label_encoders = {}
        self.scaler = StandardScaler()
        self.imputer = SimpleImputer(strategy='mean')

    def log(self, message):
        if self.log_callback:
            self.log_callback(message)
        else:
            print(f"[AI]: {message}")

    def load_data(self, path):
        ext = os.path.splitext(path)[1].lower()
        if ext == '.csv':
            return pd.read_csv(path)
        elif ext in ['.xls', '.xlsx']:
            return pd.read_excel(path)
        elif ext == '.json':
            return pd.read_json(path)
        else:
            raise ValueError(f"Unsupported file format: {ext}")

    def _prepare_features(self, df):
        """Shared logic to clean and scale features X."""
        X = df.copy()
        # Handle Categorical Features in X
        for col in X.select_dtypes(include=['object', 'category']).columns:
            if col not in self.label_encoders:
                self.label_encoders[col] = LabelEncoder()
                X[col] = self.label_encoders[col].fit_transform(X[col].astype(str))
            else:
                X[col] = self.label_encoders[col].transform(X[col].astype(str))

        # Impute missing values
        numeric_cols = X.select_dtypes(include=[np.number]).columns
        if not numeric_cols.empty:
            X[numeric_cols] = self.imputer.fit_transform(X[numeric_cols])

        # Scale features
        X_scaled = self.scaler.fit_transform(X)
        return X_scaled

    def preprocess(self, df, target_column, mode):
        if mode == "Clustering":
            self.log("Preprocessing for Clustering (No target)...")
            self.task_type = 'clustering'
            return self._prepare_features(df), None

        self.log(f"Preprocessing data for prediction (Target: {target_column})...")
        # Drop rows where target is null
        df = df.dropna(subset=[target_column])
        
        y = df[target_column]
        X_df = df.drop(columns=[target_column])

        X_scaled = self._prepare_features(X_df)

        # Detect/Set task_type
        if mode == "Auto-Detect":
            unique_count = len(y.unique())
            is_numeric = pd.api.types.is_numeric_dtype(y)
            if not is_numeric or (unique_count < 10) or (unique_count < len(y) * 0.2):
                self.task_type = 'classification'
            else:
                self.task_type = 'regression'
        else:
            self.task_type = mode.lower()

        # Handle Target encoding for classification
        if self.task_type == 'classification' and not pd.api.types.is_numeric_dtype(y):
            if 'target' not in self.label_encoders:
                self.label_encoders['target'] = LabelEncoder()
                y = self.label_encoders['target'].fit_transform(y.astype(str))
            else:
                y = self.label_encoders['target'].transform(y.astype(str))

        return X_scaled, y

    def train(self, data_path, target_column=None, mode="Auto-Detect"):
        try:
            self.log(f"Loading dataset from {data_path}...")
            df = self.load_data(data_path)
            
            # Big Data Handling: Sampling
            if len(df) > 50000:
                self.log(f"Large dataset detected ({len(df)} rows). Sampling 50,000 for speed...")
                df = df.sample(n=50000, random_state=42)

            X, y = self.preprocess(df, target_column, mode)
            self.log(f"Task Mode: {self.task_type.capitalize()}")

            if self.task_type == 'clustering':
                self.log("Training Clustering model (K-Means)...")
                # Automatically find a reasonable number of clusters (simplified)
                model = KMeans(n_clusters=min(len(X), 5), n_init=10, random_state=42)
                model.fit(X)
                self.model = model
                self.best_score = 0 # Silhouette score can be calculated but is expensive on large data
                return True, f"Success! Created {model.n_clusters} clusters."

            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

            if self.task_type == 'classification':
                models = {
                    "Logistic Regression": LogisticRegression(max_iter=1000),
                    "Random Forest": RandomForestClassifier(n_estimators=100)
                }
                metric_name = "Accuracy"
                scorer = accuracy_score
            else:
                models = {
                    "Linear Regression": LinearRegression(),
                    "Random Forest": RandomForestRegressor(n_estimators=100)
                }
                metric_name = "R2 Score"
                scorer = r2_score

            best_model_name = None
            self.best_score = -np.inf if self.task_type == 'regression' else 0
            
            for name, model in models.items():
                self.log(f"Evaluating {name}...")
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)
                score = scorer(y_test, y_pred)
                self.log(f"-> {name} {metric_name}: {score:.4f}")
                
                if best_model_name is None or score > self.best_score:
                    self.best_score = score
                    self.model = model
                    best_model_name = name

            self.log(f"WINNER: {best_model_name} with {self.best_score:.4f} {metric_name}")
            return True, f"Success! Best model: {best_model_name} ({metric_name}: {self.best_score:.4f})"
        
        except Exception as e:
            self.log(f"ERROR: {str(e)}")
            return False, str(e)

    def save_model(self, file_path):
        if not self.model:
            return False, "No model trained yet."
        
        artifacts = {
            'model': self.model,
            'task_type': self.task_type,
            'label_encoders': self.label_encoders,
            'scaler': self.scaler,
            'imputer': self.imputer
        }
        joblib.dump(artifacts, file_path)
        self.log(f"Model saved to {file_path}")
        return True, f"Model saved successfully to {file_path}"
