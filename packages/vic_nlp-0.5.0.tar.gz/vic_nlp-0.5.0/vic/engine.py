import re
import difflib
from .patterns import ALL_PATTERNS

class IntentEngine:
    def __init__(self):
        self.patterns = ALL_PATTERNS
        # Flatten all phrases for suggestion matching
        self.all_phrases = []
        for phrases, _ in self.patterns:
            self.all_phrases.extend(phrases)

    def _preprocess(self, text):
        """Cleans input text: lowercase, remove special characters."""
        text = text.lower().strip()
        text = re.sub(r'[^\w\s]', '', text)
        return text

    def get_intent(self, sentence):
        """
        Calculates a score for each intent based on keyword overlap
        and returns the best matching intent tag.
        """
        clean_text = self._preprocess(sentence)
        words = set(clean_text.split())
        
        best_intent = None
        highest_score = 0
        
        for phrases, intent_tag in self.patterns:
            for phrase in phrases:
                phrase_words = set(self._preprocess(phrase).split())
                
                # Calculate overlap
                intersection = words.intersection(phrase_words)
                
                # Simple scoring: number of matching words
                # Plus a bonus for exact phrase matching
                score = len(intersection)
                
                # Exact phrase bonus
                if self._preprocess(phrase) in clean_text:
                    score += 5
                
                if score > highest_score:
                    highest_score = score
                    best_intent = intent_tag
                    
        # Minimum threshold to avoid false positives
        if highest_score < 1:
            return None
            
        return best_intent

    def get_suggestions(self, sentence):
        """Uses difflib to suggest close matches if exact intent fails."""
        clean_text = self._preprocess(sentence)
        return difflib.get_close_matches(clean_text, self.all_phrases, n=3, cutoff=0.6)
