"""
Vic - Your English-to-Computer Interface.
"""

from .engine import IntentEngine
from .actions import SystemActions
from .data_actions import DataActions
from .generator import CodeGenerator

class Vic:
    def __init__(self):
        self.engine = IntentEngine()
        self.actions = SystemActions()
        self.data_actions = DataActions()
        self.generator = CodeGenerator()

    def run(self, sentence):
        """
        Processes a natural language sentence and executes the corresponding action.
        """
        intent = self.engine.get_intent(sentence)
        
        if not intent:
            # Try to get suggestions if exact match fails
            suggestions = self.engine.get_suggestions(sentence)
            if suggestions:
                return f"I'm not sure what you mean. Did you mean: '{suggestions[0]}'?"
            return "I'm sorry, I couldn't understand that command."

        if intent.startswith("code_"):
            return self.generator.generate(intent)
        elif intent.startswith("app_"):
            return self.generator.build_app(intent)
        elif intent.startswith("data_") or intent.startswith("ai_"):
            return self.data_actions.execute(intent, sentence)
        else:
            return self.actions.execute(intent, sentence)

__version__ = "0.5.0"
