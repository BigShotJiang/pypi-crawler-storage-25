"""
patterns.py - Command pattern definitions for Vic.
"""

SYSTEM_PATTERNS = [
    (["open calculator", "launch calculator", "open calc", "run calculator"], "open_calculator"),
    (["open notepad", "launch notepad", "open text editor", "open editor"], "open_notepad"),
    (["open file explorer", "open explorer", "open files", "show files", "open folder"], "open_explorer"),
    (["open browser", "open chrome", "open firefox", "open edge", "launch browser"], "open_browser"),
    (["mute volume", "mute sound", "mute audio"], "mute_volume"),
    (["unmute volume", "unmute sound", "unmute audio"], "unmute_volume"),
    (["shutdown computer", "shut down", "power off"], "shutdown"),
    (["restart computer", "reboot", "restart pc"], "restart"),
    (["lock computer", "lock screen", "lock pc"], "lock_screen"),
    (["open task manager", "launch task manager"], "open_task_manager"),
    (["open command prompt", "open cmd", "open terminal", "open powershell"], "open_terminal"),
    (["copy to clipboard", "copy text"], "clipboard_copy"),
    (["paste from clipboard", "paste clipboard"], "clipboard_paste"),
    (["search for", "google", "search web", "look up", "search online"], "web_search"),
    (["open website", "go to website", "visit website", "navigate to"], "open_website"),
    (["say", "speak", "tell me", "read aloud"], "speak"),
    (["what time is it", "tell me the time", "current time", "what is the time"], "get_time"),
    (["what day is it", "tell me the date", "current date", "today's date"], "get_date"),
    (["system info", "computer info", "show system info", "how much ram"], "get_sysinfo"),
    (["list files", "show files in", "list directory"], "list_files"),
    (["create folder", "make folder", "new folder", "create directory"], "create_folder"),
    (["check internet", "am i connected", "test internet", "is internet working"], "check_internet"),
    (["battery status", "battery level", "how much battery"], "get_battery"),
    (["what is my ip", "get ip address", "show ip"], "get_ip"),
]

CODE_PATTERNS = [
    (["make a loop", "create a loop", "write a loop", "for loop", "loop n times"], "code_for_loop"),
    (["make a function", "create a function", "write a function", "define a function"], "code_function"),
    (["make a class", "create a class", "write a class", "define a class"], "code_class"),
    (["create a list", "make a list", "write a list"], "code_list"),
    (["hello world", "print hello world", "basic program"], "code_hello_world"),
    (["get input", "take input", "user input", "ask user for input"], "code_user_input"),
    (["try except", "handle exception", "exception handling"], "code_try_except"),
    (["list comprehension", "compact list"], "code_list_comprehension"),
    (["generate random number", "random number", "pick random"], "code_random"),
]

APP_PATTERNS = [
    (["make a calculator", "build a calculator", "calculator app", "calculator program"], "app_calculator"),
    (["make a todo", "build a todo", "todo app", "task manager app"], "app_todo"),
    (["make a snake game", "build snake game", "snake game app"], "app_snake_game"),
    (["make a weather app", "build weather app", "weather application"], "app_weather"),
    (["make an inventory", "build inventory system", "inventory app", "stock manager"], "app_inventory"),
    (["make a budget tracker", "build budget app", "expense tracker"], "app_budget"),
    (["make a quiz app", "quiz program", "trivia app"], "app_quiz"),
    (["make a notepad app", "build text editor app", "simple editor"], "app_text_editor"),
]

DATA_PATTERNS = [
    (["clean my data", "clean dataset", "fix missing values", "remove duplicates", "data cleaning"], "data_clean"),
    (["plot a graph", "show histogram", "create scatter plot", "draw a chart", "visualize data"], "data_visualize"),
    (["show stats", "data summary", "describe dataset", "get statistics"], "data_stats"),
    (["train model", "train ai", "build model", "predict target"], "ai_train"),
    (["save model", "export ai", "download model"], "ai_save"),
]

ALL_PATTERNS = SYSTEM_PATTERNS + CODE_PATTERNS + APP_PATTERNS + DATA_PATTERNS
