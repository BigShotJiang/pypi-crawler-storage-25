import os
from setuptools import setup, find_packages

setup(
    name="vic-nlp",
    version="0.5.0",
    packages=find_packages(),
    install_requires=[
        "psutil",
        "requests",
        "pandas",
        "scikit-learn",
        "numpy",
        "openpyxl",
        "joblib",
        "matplotlib",
        "seaborn",
    ],
    entry_points={
        "console_scripts": [
            "vic=vic.cli:main",
        ],
    },
    author="Vic Development Team",
    description="Vic: Natural Language Computer Control and App Creation.",
    long_description=open("README.md", encoding="utf-8").read() if os.path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    python_requires=">=3.7",
)
