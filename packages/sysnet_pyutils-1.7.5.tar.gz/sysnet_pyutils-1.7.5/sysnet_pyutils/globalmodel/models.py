from __future__ import annotations

from datetime import datetime
from typing import Any

from .global_model import GlobalModel


class ExampleModel(GlobalModel):
    # Jednoduchá pole
    ts: datetime | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None

    # Kontejnerová pole
    ts_list: list[datetime] | None = None
    ts_map: dict[str, datetime] | None = None
    ts_tuple: tuple[datetime, ...] | None = None
    ts_set: set[datetime] | None = None

    # Libovolně hluboké struktury
    payload: dict[str, Any] | None = None

    # Helper pro test "ostatní typy"
    any_value: Any = None
