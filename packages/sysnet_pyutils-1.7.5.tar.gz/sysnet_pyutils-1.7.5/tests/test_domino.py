"""
Testy pro modul sysnet_pyutils.domino
"""

from datetime import date, datetime

import pytest

from sysnet_pyutils.domino import DdsDictionaryFactory


class TestDdsDictionaryFactoryInit:
    """Testy pro inicializaci"""

    def test_init_with_valid_dict(self):
        data = {"key": "value", "number": 42}
        factory = DdsDictionaryFactory(data)
        assert factory.data == data

    def test_init_raises_for_non_dict(self):
        with pytest.raises(ValueError, match="Invalid data"):
            DdsDictionaryFactory("not a dict")
        with pytest.raises(ValueError):
            DdsDictionaryFactory(None)


class TestGetValue:
    """Testy pro get_value"""

    def test_get_value_returns_existing_value(self):
        data = {"name": "John", "age": 30}
        factory = DdsDictionaryFactory(data)
        assert factory.get_value("name") == "John"
        assert factory.get_value("age") == 30

    def test_get_value_returns_none_for_missing_key(self):
        data = {"name": "John"}
        factory = DdsDictionaryFactory(data)
        assert factory.get_value("missing_key") is None


class TestGetValueString:
    """Testy pro get_value_string"""

    def test_get_value_string_returns_string(self):
        data = {"name": "John", "number": 42}
        factory = DdsDictionaryFactory(data)
        assert factory.get_value_string("name") == "John"

    def test_get_value_string_returns_empty_for_none(self):
        data = {"key": None}
        factory = DdsDictionaryFactory(data)
        assert factory.get_value_string("key") == ""


class TestGetValueBool:
    """Testy pro get_value_bool"""

    def test_get_value_bool_returns_true_for_one(self):
        data = {"active": "1"}
        factory = DdsDictionaryFactory(data)
        assert factory.get_value_bool("active") is True

    def test_get_value_bool_returns_false_for_other_values(self):
        data = {"zero": "0", "text": "false"}
        factory = DdsDictionaryFactory(data)
        assert factory.get_value_bool("zero") is False
        assert factory.get_value_bool("text") is False


class TestGetValueNumeric:
    """Testy pro numerické hodnoty"""

    def test_get_value_float_returns_float(self):
        data = {"price": "19.99"}
        factory = DdsDictionaryFactory(data)
        assert factory.get_value_float("price") == 19.99

    def test_get_value_int_returns_int(self):
        data = {"count": "42"}
        factory = DdsDictionaryFactory(data)
        assert factory.get_value_int("count") == 42

    def test_get_value_int_uses_spare_item(self):
        data = {"main": None, "spare": "100"}
        factory = DdsDictionaryFactory(data)
        result = factory.get_value_int("main", "spare")
        assert result == 100


class TestGetValueDate:
    """Testy pro get_value_date"""

    def test_get_value_date_parses_iso_date(self):
        data = {"date": "2023-05-15"}
        factory = DdsDictionaryFactory(data)
        result = factory.get_value_date("date")
        assert isinstance(result, date)
        assert result == date(2023, 5, 15)

    def test_get_value_date_returns_none_for_invalid(self):
        data = {"invalid": "not-a-date"}
        factory = DdsDictionaryFactory(data)
        assert factory.get_value_date("invalid") is None


class TestGetValueDatetime:
    """Testy pro get_value_datetime"""

    def test_get_value_datetime_parses_iso_datetime(self):
        data = {"datetime": "2023-05-15T12:30:00"}
        factory = DdsDictionaryFactory(data)
        result = factory.get_value_datetime("datetime")
        assert isinstance(result, datetime)
        assert result.year == 2023

    def test_get_value_datetime_converts_to_local_tz(self):
        data = {"datetime": "2023-05-15T12:00:00Z"}
        factory = DdsDictionaryFactory(data)
        result = factory.get_value_datetime("datetime")
        assert result.tzinfo is not None


class TestSetValue:
    """Testy pro set_value"""

    def test_set_value_sets_value(self):
        data = {}
        factory = DdsDictionaryFactory(data)
        factory.set_value("name", "John")
        assert factory.data["name"] == "John"

    def test_set_value_overwrites_existing(self):
        data = {"name": "John"}
        factory = DdsDictionaryFactory(data)
        factory.set_value("name", "Jane")
        assert factory.data["name"] == "Jane"


class TestSetValueString:
    """Testy pro set_value_string"""

    def test_set_value_string_converts_to_string(self):
        data = {}
        factory = DdsDictionaryFactory(data)
        factory.set_value_string("number", 42)
        assert factory.data["number"] == "42"


class TestSetValueBool:
    """Testy pro set_value_bool"""

    def test_set_value_bool_sets_one_for_true(self):
        data = {}
        factory = DdsDictionaryFactory(data)
        factory.set_value_bool("active", True)
        assert factory.data["active"] == "1"

    def test_set_value_bool_sets_none_for_false(self):
        data = {}
        factory = DdsDictionaryFactory(data)
        factory.set_value_bool("active", False)
        assert factory.data["active"] is None


class TestIntegration:
    """Integrační testy"""

    def test_real_world_scenario(self):
        dds_data = {
            "Form": "Document",
            "Title": "Test Document",
            "DateCreated": "2023-05-15T10:00:00",
            "IsActive": "1",
            "Priority": "5",
            "Amount": "99.99",
        }

        factory = DdsDictionaryFactory(dds_data)

        assert factory.get_value_string("Title") == "Test Document"
        assert factory.get_value_bool("IsActive") is True
        assert factory.get_value_int("Priority") == 5
        assert factory.get_value_float("Amount") == 99.99
        date_created = factory.get_value_datetime("DateCreated")
        assert isinstance(date_created, datetime)
