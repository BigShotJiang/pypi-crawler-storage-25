from datetime import date, datetime

import pytest

from sysnet_pyutils import data_utils


class TestDataUtilsEdgeCases:
    def test_get_dict_value_string_returns_empty_for_missing_key(self):
        assert data_utils.get_dict_value_string({"a": 123}, "missing") == ""

    def test_get_dict_value_email_missing_key_returns_none(self):
        assert data_utils.get_dict_value_email({"e": "a@b.cz"}, "missing") is None

    def test_get_dict_value_bool_empty_string_returns_false(self):
        assert data_utils.get_dict_value_bool({"b": ""}, "b") is False

    def test_get_dict_value_bool_truthy_tokens(self):
        for token in ("true", "1", "t", "ano", "a", "on", "yes", "y"):
            assert data_utils.get_dict_value_bool({"b": token}, "b") is True

    def test_get_dict_value_int_primary_typeerror_uses_zero(self):
        assert data_utils.get_dict_value_int({"i": object()}, "i") == 0

    def test_get_dict_value_int_spare_invalid_returns_zero(self):
        assert data_utils.get_dict_value_int({"i": "0", "i2": "bad"}, "i", spare_item_name="i2") == 0

    def test_get_dict_value_list_when_both_missing_returns_none(self):
        assert data_utils.get_dict_value_list({}, "main", spare_item_name="spare") is None

    def test_get_dict_value_float_invalid_primary_returns_zero(self):
        assert data_utils.get_dict_value_float({"f": "not-a-float"}, "f") == 0.0

    def test_get_dict_value_float_spare_invalid_returns_zero(self):
        assert data_utils.get_dict_value_float({"f": "0", "f2": "bad"}, "f", spare_item_name="f2") == 0.0

    def test_convert_iso_to_date_invalid_returns_none(self):
        assert data_utils.convert_iso_to_date("not-iso") is None

    def test_convert_cz_to_date_invalid_returns_none(self):
        assert data_utils.convert_cz_to_date("not-cz") is None

    def test_convert_iso_to_datetime_invalid_returns_none(self):
        assert data_utils.convert_iso_to_datetime("not-iso-datetime") is None

    def test_convert_cz_to_datetime_invalid_returns_none(self):
        assert data_utils.convert_cz_to_datetime("not-cz-datetime") is None

    def test_get_dict_value_datetime_from_datetime_returns_same_instance(self):
        dt = datetime(2024, 1, 2, 3, 4, 5)
        assert data_utils.get_dict_value_datetime({"dt": dt}, "dt") is dt

    def test_get_dict_value_datetime_from_string_invalid_returns_none(self):
        assert data_utils.get_dict_value_datetime({"dt": "not-a-datetime"}, "dt") is None

    def test_get_dict_item_value_list_wraps_scalar(self):
        assert data_utils.get_dict_item_value_list({"x": "A"}, "x") == ["A"]

    def test_get_dict_item_value_uses_alt_names(self):
        assert data_utils.get_dict_item_value({"alt": 123}, "main", alt_item_names=["alt"]) == 123

    def test_get_dict_code_value_list_none_when_missing_any_side(self):
        d = {"codes": '["A";"B"]'}
        assert data_utils.get_dict_code_value_list(d, "codes", "vals") is None

    def test_adjust_datetime_to_utc_for_store_date_returns_datetime_utc(self):
        d = date(2024, 1, 2)
        out = data_utils.adjust_datetime_to_utc(d, for_store=True)
        assert isinstance(out, datetime)
        assert out.year == 2024 and out.month == 1 and out.day == 2
        assert out.tzinfo is not None

    def test_dict_convert_date_to_str_converts_nested(self):
        payload = {
            "a": datetime(2024, 1, 2, 3, 4, 5),  # naive
            "b": {"c": datetime(2024, 1, 2, 3, 4, 5)},
            "lst": [{"d": datetime(2024, 1, 2, 3, 4, 5)}],
        }
        data_utils.dict_convert_date_to_str(payload)
        assert payload["a"].endswith("Z")
        assert payload["b"]["c"].endswith("Z")
        assert payload["lst"][0]["d"].endswith("Z")

    def test_paging_to_mongo_accepts_none_inputs(self):
        out = data_utils.paging_to_mongo(start=None, page_size=None, page=None)
        assert set(out.keys()) == {"start", "page_size", "page", "skip", "limit"}

    @pytest.mark.parametrize(
        ("value", "expected"),
        [
            ("CO", "FOREIGN_LEGAL_ENTITY"),
            ("FN", "NATURAL_PERSON"),
            ("FO", "BUSINESS_NATURAL_PERSON"),
            ("PO", "LEGAL_ENTITY"),
        ],
    )
    def test_get_dict_value_as_person_type_special_mappings(self, value, expected):
        out = data_utils.get_dict_value_as_person_type({"k": value}, "k")
        assert out is not None
        assert out.name == expected

    def test_get_dict_value_as_person_type_invalid_returns_none(self):
        assert data_utils.get_dict_value_as_person_type({"k": "??"}, "k") is None

    def test_get_dict_value_string_item_name_none_returns_empty(self):
        assert data_utils.get_dict_value_string({"a": 1}, None) == ""

    def test_get_dict_value_email_item_name_empty_returns_none(self):
        assert data_utils.get_dict_value_email({"e": "x@y.z"}, "") is None

    def test_get_dict_value_bool_item_name_none_returns_false(self):
        assert data_utils.get_dict_value_bool({"b": "true"}, None) is False

    def test_get_dict_value_int_item_name_empty_returns_zero(self):
        assert data_utils.get_dict_value_int({"i": "123"}, "") == 0

    def test_get_dict_value_date_key_missing_returns_none(self):
        assert data_utils.get_dict_value_date({"d": "2024-01-01"}, "missing") is None

    def test_get_dict_value_uuid_missing_key_returns_none(self):
        assert data_utils.get_dict_value_uuid({"u": "550e8400-e29b-41d4-a716-446655440000"}, "missing") is None

    def test_get_dict_value_datetime_missing_key_returns_none(self):
        assert data_utils.get_dict_value_datetime({"dt": "2024-01-01T00:00:00"}, "missing") is None

    def test_get_dict_value_datetime_string_unparseable_returns_none(self):
        assert data_utils.get_dict_value_datetime({"dt": "not-iso-and-not-cz"}, "dt") is None

    def test_get_dict_item_value_list_returns_empty_list_when_value_none(self):
        assert data_utils.get_dict_item_value_list({"x": None}, "x") == []

    def test_get_dict_item_value_data_none_returns_blank_string_by_default(self):
        assert data_utils.get_dict_item_value(None, "x") == ""

    def test_get_dict_code_value_list_returns_none_when_values_empty_list(self):
        d = {
            "codes": '["A";"B"]',
            "vals": '[""]',  # get_dict_value_list -> []
        }
        assert data_utils.get_dict_code_value_list(d, "codes", "vals") is None

    def test_adjust_datetime_to_utc_empty_string_returns_empty_string(self):
        assert data_utils.adjust_datetime_to_utc("", for_store=False) == ""

    def test_get_dict_value_as_person_type_missing_key_returns_none(self):
        assert data_utils.get_dict_value_as_person_type({"other": "FN"}, "k") is None

    def test_get_dict_value_datetime_parses_cz_datetime_when_iso_fails(self):
        """
        Cíl: data_utils.py řádky 239-240
        Větev: v je str -> ISO parse vrátí None -> zkusí se CZ parse.
        """
        out = data_utils.get_dict_value_datetime({"dt": "02.01.2024 03:04:05"}, "dt")
        assert isinstance(out, datetime)

    def test_get_dict_code_value_list_returns_none_when_codes_missing(self):
        """
        Cíl: data_utils.py řádky 325 (not codes) / 327 (not values) podle toho, jak je to očíslované.
        """
        d = {
            "vals": '["1";"2"]',
        }
        assert data_utils.get_dict_code_value_list(d, "codes", "vals") is None

    def test_get_dict_code_value_list_returns_none_when_values_missing(self):
        """
        Cíl: data_utils.py řádky 325/327 – druhá strana chybí.
        """
        d = {
            "codes": '["A";"B"]',
        }
        assert data_utils.get_dict_code_value_list(d, "codes", "vals") is None

    def test_adjust_datetime_to_utc_none_returns_none(self):
        """
        Cíl: data_utils.py řádek 351 (větev: date_value in [None, ''] -> return date_value)
        """
        assert data_utils.adjust_datetime_to_utc(None, for_store=False) is None

    def test_get_dict_value_as_person_type_data_none_returns_none(self):
        """
        Cíl: data_utils.py (větev: if data is None: return None)
        """
        assert data_utils.get_dict_value_as_person_type(None, "k") is None
