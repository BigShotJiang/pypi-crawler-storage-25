"""
Testy pro normalize_datetime a localize_datetime v sysnet_pyutils.data_utils
"""

from datetime import date, datetime

import pytz
import pytest

from sysnet_pyutils.data_utils import localize_datetime, normalize_datetime

# Referenční zóna shodná s výchozí TZ env proměnnou (Europe/Prague)
PRAGUE = pytz.timezone("Europe/Prague")
UTC = pytz.UTC


# ---------------------------------------------------------------------------
# normalize_datetime
# ---------------------------------------------------------------------------

class TestNormalizeDatetime:
    """normalize_datetime → výstup vždy datetime v UTC (nebo None)"""

    def test_none_returns_none(self):
        assert normalize_datetime(None) is None

    def test_naive_datetime_treated_as_local(self):
        # naivní 2024-03-10 12:00:00 → Prague je UTC+1 (zimní čas)
        naive = datetime(2024, 3, 10, 12, 0, 0)
        result = normalize_datetime(naive)
        expected = PRAGUE.localize(naive).astimezone(UTC)
        assert result == expected

    def test_naive_datetime_summer_time(self):
        # letní čas: Prague je UTC+2
        naive = datetime(2024, 7, 1, 12, 0, 0)
        result = normalize_datetime(naive)
        expected = PRAGUE.localize(naive).astimezone(UTC)
        assert result == expected

    def test_aware_utc_unchanged(self):
        aware = datetime(2024, 6, 15, 10, 0, 0, tzinfo=UTC)
        result = normalize_datetime(aware)
        assert result == aware
        assert result.tzinfo == UTC

    def test_aware_prague_converted_to_utc(self):
        aware = PRAGUE.localize(datetime(2024, 6, 15, 12, 0, 0))
        result = normalize_datetime(aware)
        assert result.tzinfo == UTC
        assert result == aware.astimezone(UTC)

    def test_date_midnight_local_to_utc(self):
        # date 2024-01-15 → půlnoc v Prague (UTC+1 zimní čas) → 23:00 předchozího dne UTC
        d = date(2024, 1, 15)
        result = normalize_datetime(d)
        expected = PRAGUE.localize(datetime(2024, 1, 15, 0, 0, 0)).astimezone(UTC)
        assert result == expected
        assert result.tzinfo == UTC

    def test_date_summer_midnight_local_to_utc(self):
        # date 2024-07-01 → půlnoc v Prague (UTC+2) → 22:00 předchozího dne UTC
        d = date(2024, 7, 1)
        result = normalize_datetime(d)
        expected = PRAGUE.localize(datetime(2024, 7, 1, 0, 0, 0)).astimezone(UTC)
        assert result == expected

    def test_result_is_always_datetime(self):
        assert isinstance(normalize_datetime(date(2024, 1, 1)), datetime)
        assert isinstance(normalize_datetime(datetime(2024, 1, 1)), datetime)

    def test_result_tzinfo_is_utc(self):
        result = normalize_datetime(datetime(2024, 5, 1, 8, 0, 0))
        assert result.utcoffset().total_seconds() == 0


# ---------------------------------------------------------------------------
# localize_datetime
# ---------------------------------------------------------------------------

class TestLocalizeDatetime:
    """localize_datetime → výstup vždy datetime v lokální zóně (TZ) nebo None"""

    def test_none_returns_none(self):
        assert localize_datetime(None) is None

    def test_naive_datetime_treated_as_utc(self):
        # naivní → považuje se za UTC → převede do Prague
        naive = datetime(2024, 3, 10, 11, 0, 0)
        result = localize_datetime(naive)
        expected = UTC.localize(naive).astimezone(PRAGUE)
        assert result == expected

    def test_aware_utc_converted_to_local(self):
        aware = datetime(2024, 1, 15, 23, 0, 0, tzinfo=UTC)
        result = localize_datetime(aware)
        # UTC+1 zimní čas → 00:00 následujícího dne v Prague
        assert result.tzinfo.zone == "Europe/Prague"
        assert result == aware.astimezone(PRAGUE)

    def test_aware_prague_unchanged_zone(self):
        aware = PRAGUE.localize(datetime(2024, 6, 15, 12, 0, 0))
        result = localize_datetime(aware)
        assert result.tzinfo.zone == "Europe/Prague"

    def test_date_midnight_utc_to_local(self):
        # date 2024-07-01 → půlnoc UTC → 02:00 Prague (UTC+2 letní čas)
        d = date(2024, 7, 1)
        result = localize_datetime(d)
        expected = UTC.localize(datetime(2024, 7, 1, 0, 0, 0)).astimezone(PRAGUE)
        assert result == expected
        assert result.tzinfo.zone == "Europe/Prague"

    def test_date_winter_midnight_utc_to_local(self):
        # date 2024-01-15 → půlnoc UTC → 01:00 Prague (UTC+1 zimní čas)
        d = date(2024, 1, 15)
        result = localize_datetime(d)
        expected = UTC.localize(datetime(2024, 1, 15, 0, 0, 0)).astimezone(PRAGUE)
        assert result == expected

    def test_result_is_always_datetime(self):
        assert isinstance(localize_datetime(date(2024, 1, 1)), datetime)
        assert isinstance(localize_datetime(datetime(2024, 1, 1)), datetime)

    def test_result_tzinfo_is_local(self):
        result = localize_datetime(datetime(2024, 5, 1, 8, 0, 0))
        assert result.tzinfo.zone == "Europe/Prague"


# ---------------------------------------------------------------------------
# Symetrie: roundtrip normalize → localize
# ---------------------------------------------------------------------------

class TestRoundtrip:
    """normalize_datetime a localize_datetime jsou inverzní operace."""

    @pytest.mark.parametrize("naive", [
        datetime(2024, 1, 15, 10, 30, 0),
        datetime(2024, 7, 1, 0, 0, 0),
        datetime(2024, 3, 31, 1, 30, 0),   # těsně před přechodem na letní čas
    ])
    def test_normalize_then_localize_roundtrip(self, naive):
        utc = normalize_datetime(naive)
        back = localize_datetime(utc)
        # Po roundtripu musí být hodnota čas. shodná
        assert back.astimezone(UTC) == utc

    @pytest.mark.parametrize("d", [
        date(2024, 1, 15),
        date(2024, 7, 1),
    ])
    def test_date_normalize_then_localize(self, d):
        utc = normalize_datetime(d)
        local = localize_datetime(utc)
        # Půlnoc v lokální zóně → UTC → zpět do lokální → stále půlnoc
        assert local.hour == 0 and local.minute == 0 and local.second == 0
