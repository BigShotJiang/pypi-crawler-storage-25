import importlib


def test_init_version_unknown_when_package_not_installed(monkeypatch):
    """
    Cíl: sysnet_pyutils/__init__.py řádky 7-8
    (except PackageNotFoundError → __version__ = "unknown")

    Řešení: patch importlib.metadata.version, aby vyhodil PackageNotFoundError,
    pak reload modulu.
    """
    import sysnet_pyutils  # už importované; budeme reloadovat

    def fake_version(_dist_name: str):
        from importlib.metadata import PackageNotFoundError

        raise PackageNotFoundError

    monkeypatch.setattr("importlib.metadata.version", fake_version)

    reloaded = importlib.reload(sysnet_pyutils)
    assert reloaded.__version__ == "unknown"
