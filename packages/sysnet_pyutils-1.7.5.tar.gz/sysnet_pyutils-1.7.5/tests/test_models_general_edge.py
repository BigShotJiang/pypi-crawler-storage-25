import json

from sysnet_pyutils.models.general import ApiError, CodeValueType, ContainerHistoryItemType, PersonTypeEnum


class TestModelsGeneralEdge:
    def test_api_error_sets_fields(self):
        err = ApiError(code=400, message="bad")
        assert err.code == 400
        assert err.message == "bad"

    def test_baseenum_missing_none_returns_none(self):
        assert PersonTypeEnum._missing_(None) is None

    def test_baseenum_missing_case_insensitive(self):
        # value 'legalEntity' exists; try different case
        assert PersonTypeEnum("LEGALENTITY".lower()) == PersonTypeEnum.LEGAL_ENTITY

    def test_baseenum_from_json(self):
        val = PersonTypeEnum.from_json(json.dumps("legalEntity"))
        assert val == PersonTypeEnum.LEGAL_ENTITY

    def test_codevaluetype_eq_notimplemented_for_other_type(self):
        cv = CodeValueType(code="A", value="B")
        assert (cv == "x") is False

    def test_codevaluetype_str_empty_when_no_data(self):
        cv = CodeValueType(code=None, value=None)
        assert str(cv) == ""

    def test_codevaluetype_str_join_when_has_values(self):
        cv = CodeValueType(code="CZ", value="Česká republika")
        assert str(cv) == "CZ - Česká republika"

    def test_container_history_item_str_includes_container(self):
        item = ContainerHistoryItemType(container="C1", message="m")
        s = str(item)
        assert "container=C1" in s
