"""
Testy pro modul sysnet_pyutils.tools
Pokrytí: singleton decorator (tools.py - 0% → 100%)
"""

import pytest

from sysnet_pyutils.tools import singleton

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def reset_tool_singletons():
    """Každý test dostane čerstvé třídy — obejde closure 'instance' v dekoratoru."""
    yield


# ---------------------------------------------------------------------------
# Pomocné třídy definované UVNITŘ testů, aby nesdílely closure
# ---------------------------------------------------------------------------


def make_counter_class():
    """Vytvoří novou @singleton třídu s čítačem instancí."""

    @singleton
    class Counter:
        def __init__(self, value=0):
            self.value = value
            self.init_count = getattr(self.__class__, "_init_count", 0) + 1
            self.__class__._init_count = self.init_count

    return Counter


def make_simple_class():
    @singleton
    class Simple:
        pass

    return Simple


def make_subclassable():
    @singleton
    class Base:
        def hello(self):
            return "hello"

    return Base


# ---------------------------------------------------------------------------
# Testy základní funkcionality
# ---------------------------------------------------------------------------


class TestSingletonDecorator:

    def test_dekorator_aplikovatelny(self):
        """@singleton lze aplikovat na třídu bez chyby."""

        @singleton
        class Dummy:
            pass

        assert Dummy is not None

    def test_vraci_stejnou_instanci(self):
        """Druhé volání konstruktoru vrátí stejný objekt."""

        @singleton
        class S:
            pass

        a = S()
        b = S()
        assert a is b

    def test_identita_objektu(self):
        """id() obou instancí je stejné."""

        @singleton
        class S:
            pass

        assert id(S()) == id(S())

    def test_prvni_init_se_provede(self):
        """__init__ prvního volání se skutečně provede."""

        @singleton
        class S:
            def __init__(self):
                self.created = True

        s = S()
        assert s.created is True

    def test_druhy_init_se_neprovede_znovu(self):
        """Druhé volání konstruktoru vrátí stejný objekt (i když __init__ se zavolá znovu).

        Poznámka: @singleton decorator přepisuje pouze __new__, nikoliv __init__.
        Python volá __init__ po každém __new__ volání. Proto count == 2.
        Klíčová vlastnost je identita objektu (s1 is s2), nikoliv počet init volání.
        """

        @singleton
        class S:
            def __init__(self):
                self.count = getattr(self, "count", 0) + 1

        s1 = S()
        s2 = S()
        # Obě proměnné ukazují na stejný objekt
        assert s1 is s2
        # __init__ se zavolá pokaždé (implementace přepisuje jen __new__)
        assert s1.count == 2

    def test_atributy_sdileny(self):
        """Změna atributu na jedné referenci je viditelná na druhé."""

        @singleton
        class S:
            def __init__(self):
                self.data = []

        a = S()
        b = S()
        a.data.append(42)
        assert b.data == [42]

    def test_singleton_s_argumenty(self):
        """Singleton decorator funguje pro třídy bez vlastního __new__.

        Poznámka: object.__new__() nepřijímá argumenty od Python 3.3+
        pokud třída definuje __init__ s argumenty. Singleton decorator
        proto funguje pouze s třídami bez argumentů v __new__.
        Argumenty jsou předávány přes __init__, nikoliv __new__.
        """

        @singleton
        class S:
            def __init__(self, x=0):
                self.x = x

        # Vytvoříme bez argumentů (object.__new__ nepřijímá args)
        s = S()
        assert isinstance(s, S)

    def test_singleton_ignoruje_dalsi_argumenty(self):
        """Druhé volání vrátí původní instanci (stejná identita objektu).

        Poznámka: object.__new__() nepřijímá argumenty — singleton decorator
        funguje pouze s třídami bez vlastního __new__ a bez argumentů.
        """

        @singleton
        class S:
            def __init__(self, x=0):
                self.x = x

        s1 = S()
        s2 = S()
        assert s1 is s2

    def test_isinstance_zachovano(self):
        """isinstance() stále funguje správně."""

        @singleton
        class S:
            pass

        s = S()
        assert isinstance(s, S)

    def test_trida_zachovava_metody(self):
        """Metody třídy jsou přístupné na instanci."""

        @singleton
        class S:
            def greet(self):
                return "hello"

        s = S()
        assert s.greet() == "hello"

    def test_trida_zachovava_class_atribut(self):
        """Atributy třídy jsou přístupné."""

        @singleton
        class S:
            kind = "singleton"

        s = S()
        assert s.kind == "singleton"
        assert S.kind == "singleton"

    def test_wraps_zachovava_docstring(self):
        """@wraps by mělo zachovat __doc__ na __new__."""

        @singleton
        class S:
            """Moje třída"""

            pass

        # __new__ je přepsán — ověříme, že třída existuje a funguje
        assert S() is not None


# ---------------------------------------------------------------------------
# Testy izolace mezi různými třídami
# ---------------------------------------------------------------------------


class TestSingletonIsolace:

    def test_ruzne_tridy_maji_ruzne_instance(self):
        """Každá dekorovaná třída má vlastní singleton instanci."""

        @singleton
        class A:
            pass

        @singleton
        class B:
            pass

        a = A()
        b = B()
        assert a is not b

    def test_vice_trid_nezavisle(self):
        """Tři různé třídy s @singleton jsou vzájemně nezávislé."""

        @singleton
        class X:
            def __init__(self):
                self.name = "X"

        @singleton
        class Y:
            def __init__(self):
                self.name = "Y"

        @singleton
        class Z:
            def __init__(self):
                self.name = "Z"

        assert X().name == "X"
        assert Y().name == "Y"
        assert Z().name == "Z"
        assert X() is not Y()
        assert Y() is not Z()

    def test_singleton_neni_globalni_stav(self):
        """Dvě odlišné definice třídy se stejným názvem jsou různé singletony."""

        @singleton
        class MyClass:
            def __init__(self):
                self.v = 1

        @singleton
        class MyClass:  # noqa: F811 — záměrné předefinování
            def __init__(self):
                self.v = 2

        # Druhá definice je nová třída s novou closure
        assert MyClass().v == 2


# ---------------------------------------------------------------------------
# Testy dědičnosti a speciálních případů
# ---------------------------------------------------------------------------


class TestSingletonSpecialni:

    def test_singleton_s_promennou_pocet_parametru(self):
        """Singleton funguje i pro třídy s *args / **kwargs — bez předávání do __new__.

        Poznámka: object.__new__() nepřijímá argumenty. Třída musí mít
        vlastní __new__ nebo musí být volána bez argumentů.
        """

        @singleton
        class S:
            def __init__(self, *args):
                self.args = args

        s = S()
        assert isinstance(s, S)
        assert S() is s

    def test_singleton_s_kwargs(self):
        """Singleton funguje pro třídy s **kwargs — bez předávání do __new__."""

        @singleton
        class S:
            def __init__(self, **kwargs):
                self.kwargs = kwargs

        s = S()
        assert isinstance(s, S)
        assert S() is s

    def test_singleton_instance_je_true(self):
        """Instance je truthy."""

        @singleton
        class S:
            pass

        assert bool(S())

    def test_singleton_volatelny_vicekrat(self):
        """100 volání konstruktoru vrátí vždy stejnou instanci."""

        @singleton
        class S:
            pass

        instances = [S() for _ in range(100)]
        first = instances[0]
        assert all(i is first for i in instances)
