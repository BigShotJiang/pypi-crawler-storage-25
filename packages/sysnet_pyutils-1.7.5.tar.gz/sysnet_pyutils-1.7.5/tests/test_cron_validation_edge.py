from __future__ import annotations

from datetime import datetime, timedelta


def test_summarize_cron_catches_runtime_error_in_croniter(monkeypatch):
    """
    Cíl: cron_utils/validation.py missing 41-45, 49-51 (except v summarize_cron)
    Vynutíme, aby croniter(expr, start) vyhodil obecnou Exception až po syntaktické validaci.
    """
    from sysnet_pyutils.cron_utils import validation as v

    class Boom(Exception):
        pass

    def fake_croniter(_expr, _start):
        raise Boom("boom")

    # DŮLEŽITÉ: nechat projít syntax validaci, jinak se fake_croniter zavolá už v is_cron_syntax_valid()
    monkeypatch.setattr(v, "is_cron_syntax_valid", lambda _expr: True)
    monkeypatch.setattr(v, "croniter", fake_croniter)

    summary = v.summarize_cron("0 0 * * *", tz="Europe/Prague")
    assert summary.syntax_ok is True
    assert summary.has_occurrence is False
    assert summary.next_run is None
    assert summary.errors and "Nepodařilo se určit další výskyt" in summary.errors[0]


def test_summarize_cron_horizon_turns_occurrence_off(monkeypatch):
    """
    Cíl: větev v summarize_cron, která nastaví has_occ=False, pokud v horizontu není výskyt.
    """
    from sysnet_pyutils.cron_utils import validation as v

    class FakeIter:
        def __init__(self, *_args, **_kwargs):
            pass

        def get_next(self, _type):
            return datetime(2099, 1, 1)

    monkeypatch.setattr(v, "croniter", lambda *_a, **_k: FakeIter())
    monkeypatch.setattr(v, "has_next_occurrence", lambda *_a, **_k: False)

    summary = v.summarize_cron("0 0 * * *", tz="Europe/Prague")
    assert summary.syntax_ok is True
    assert summary.has_occurrence is False
    assert summary.next_run is None
    assert any("v horizontu 5 let" in e for e in (summary.errors or []))


def test_has_next_occurrence_returns_false_when_croniter_init_raises():
    """
    Cíl: has_next_occurrence() řádky 90-91
    croniter(expr, start) vyhodí CroniterBadCronError → False.
    """
    from sysnet_pyutils.cron_utils.validation import has_next_occurrence

    # 5 polí, ale nesmyslný výraz → croniter má vyhodit CroniterBadCronError
    assert has_next_occurrence("abc def ghi jkl mno", start=datetime(2024, 1, 1), horizon_years=1) is False


def test_has_next_occurrence_breaks_when_next_is_beyond_limit(monkeypatch):
    """
    Cíl: has_next_occurrence() řádky 101, 104
    get_next() vrátí datum za limit_dt → provede se break a vrátí False.
    """
    from sysnet_pyutils.cron_utils import validation as v

    start = datetime(2024, 1, 1, 0, 0, 0)
    limit_dt = start + timedelta(days=365 * 1)

    class FakeIter:
        def get_next(self, _type):
            return limit_dt + timedelta(days=1)

    monkeypatch.setattr(v, "croniter", lambda *_a, **_k: FakeIter())

    assert v.has_next_occurrence("0 0 * * *", start=start, horizon_years=1) is False


def test_has_next_occurrence_returns_false_when_get_next_raises(monkeypatch):
    """
    (užitečné i nadále) – když get_next vyhodí CroniterBadDateError → False.
    """
    from sysnet_pyutils.cron_utils import validation as v

    class FakeIter:
        def get_next(self, _type):
            raise v.CroniterBadDateError("bad date")

    monkeypatch.setattr(v, "croniter", lambda *_a, **_k: FakeIter())

    assert v.has_next_occurrence("0 0 * * *", start=datetime(2024, 1, 1), horizon_years=1) is False
