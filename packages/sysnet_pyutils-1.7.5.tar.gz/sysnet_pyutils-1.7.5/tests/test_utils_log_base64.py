"""
Testy pro utils.Log a utils.to_base64 (+ pid_factory, uuid_factory, local_datetime)
Pokrytí: Log (0% → ~90%), to_base64 (17% → 100%), ostatní netestované funkce
"""

import base64
import logging
import os
import tempfile
from datetime import datetime

import pytest
import pytz

from sysnet_pyutils.utils import (
    Log,
    LoggedObject,
    Singleton,
    datetime_now,
    is_base64,
    local_datetime,
    pid_factory,
    to_base64,
    uuid_factory,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def reset_log_singleton():
    """Log je Singleton — resetujeme před každým testem."""
    if hasattr(Singleton, "_instances"):
        Singleton._instances.clear()
    yield
    if hasattr(Singleton, "_instances"):
        Singleton._instances.clear()


# ===========================================================================
# to_base64()
# ===========================================================================


class TestToBase64:

    def test_bytes_uz_v_base64_se_vrati_beze_zmeny(self):
        """Pokud je vstup již base64 bytes, vrátí se beze změny."""
        original = b"hello world"
        encoded = base64.b64encode(original)
        result = to_base64(encoded)
        assert result == encoded

    def test_string_uz_v_base64_se_vrati_beze_zmeny(self):
        """Pokud je vstup již base64 string, vrátí se beze změny (jako bytes)."""
        original = b"hello world"
        encoded_str = base64.b64encode(original).decode("ascii")
        result = to_base64(encoded_str)
        # is_base64 vrátí True → funkce vrátí původní vstup
        assert result is not None

    def test_ascii_string_se_zakoduje(self):
        """Čistý ASCII string se zakóduje do base64."""
        result = to_base64("hello")
        assert result is not None
        decoded = base64.b64decode(result)
        assert decoded == b"hello"

    def test_bytes_se_zakoduje(self):
        """Bytes se zakódují do base64."""
        result = to_base64(b"hello")
        assert result is not None
        decoded = base64.b64decode(result)
        assert decoded == b"hello"

    def test_prazdny_string(self):
        """Prázdný string vrátí base64 prázdného stringu."""
        result = to_base64("")
        assert result is not None
        assert base64.b64decode(result) == b""

    def test_prazdne_bytes(self):
        """Prázdné bytes vrátí base64 prázdného bytestring."""
        result = to_base64(b"")
        assert result is not None

    def test_non_ascii_string_vrati_none(self):
        """Ne-ASCII string (Unicode) způsobí ValueError → vrátí None."""
        result = to_base64("héllo wörld")
        assert result is None

    def test_neplatny_typ_vrati_none(self):
        """Neplatný typ (int) způsobí ValueError → vrátí None."""
        result = to_base64(12345)
        assert result is None

    def test_vysledek_je_validni_base64(self):
        """Výsledek lze ověřit funkcí is_base64."""
        result = to_base64(b"test data 123")
        assert is_base64(result)

    def test_ruzne_vstupy_daji_ruzne_vystupy(self):
        """Různé vstupy dají různé base64 výstupy."""
        r1 = to_base64(b"aaa")
        r2 = to_base64(b"bbb")
        assert r1 != r2

    def test_zakodovani_a_dekodovani_round_trip(self):
        """Zakódovaný string lze znovu dekódovat."""
        original = b"round trip test"
        encoded = to_base64(original)
        decoded = base64.b64decode(encoded)
        assert decoded == original


# ===========================================================================
# pid_factory() a uuid_factory()
# ===========================================================================


class TestPidFactory:

    def test_pid_factory_bez_prefixu(self):
        """Bez prefixu vrátí validní ID."""
        result = pid_factory()
        assert result is not None
        assert isinstance(result, str)
        assert len(result) == 12

    def test_pid_factory_s_prefixem(self):
        """S prefixem delším než 2 znaky se použije prvních 5 znaků."""
        result = pid_factory(prefix="ABC")
        assert result is not None
        assert isinstance(result, str)
        assert result.startswith("ABC")

    def test_pid_factory_kratkym_prefixem(self):
        """Prefix kratší než 3 znaky se ignoruje."""
        result = pid_factory(prefix="AB")
        assert result is not None
        assert isinstance(result, str)

    def test_pid_factory_prazdny_prefix(self):
        """Prázdný prefix se ignoruje."""
        result = pid_factory(prefix="")
        assert result is not None

    def test_pid_factory_none_prefix(self):
        """None prefix je validní."""
        result = pid_factory(prefix=None)
        assert result is not None

    def test_pid_factory_generuje_unikatni(self):
        """Dva po sobě jdoucí výsledky jsou různé."""
        r1 = pid_factory()
        r2 = pid_factory()
        assert r1 != r2


class TestUuidFactory:

    def test_uuid_factory_vraci_string(self):
        """uuid_factory() vrátí UUID string."""
        result = uuid_factory()
        assert isinstance(result, str)

    def test_uuid_factory_generuje_validni_uuid(self):
        """Výsledek uuid_factory() je validní UUID."""
        from uuid import UUID

        result = uuid_factory()
        UUID(result)  # raises ValueError pokud není validní

    def test_uuid_factory_generuje_unikatni_hodnoty(self):
        """Vícenásobné volání generuje různé UUID."""
        uuids = {uuid_factory() for _ in range(10)}
        assert len(uuids) == 10


# ===========================================================================
# local_datetime() a datetime_now()
# ===========================================================================


class TestLocalDatetime:

    def test_local_datetime_none_vrati_none(self):
        """local_datetime(None) vrátí None."""
        result = local_datetime(None)
        assert result is None

    def test_local_datetime_vrati_aware_datetime(self):
        """local_datetime() s naive datetime vrátí timezone-aware datetime."""
        naive = datetime(2024, 6, 15, 12, 0, 0)
        result = local_datetime(naive)
        assert result is not None
        assert result.tzinfo is not None

    def test_local_datetime_je_prazska_zona(self):
        """Výsledek je v Europe/Prague timezone."""
        naive = datetime(2024, 1, 15, 10, 0, 0, tzinfo=pytz.utc)
        result = local_datetime(naive)
        tz_name = result.tzinfo.zone if hasattr(result.tzinfo, "zone") else str(result.tzinfo)
        assert "Prague" in tz_name

    def test_local_datetime_s_ne_datetime_vrati_vstup(self):
        """Pokud value není datetime, vrátí se beze změny."""
        result = local_datetime("not a datetime")
        assert result == "not a datetime"

    def test_local_datetime_s_int_vrati_vstup(self):
        """Pokud value je int, vrátí se beze změny."""
        result = local_datetime(42)
        assert result == 42

    def test_datetime_now_vrati_datetime(self):
        """datetime_now() vrátí datetime objekt."""
        result = datetime_now()
        assert isinstance(result, datetime)

    def test_datetime_now_je_aktualni(self):
        """datetime_now() vrátí čas blízký aktuálnímu."""
        before = datetime.utcnow().replace(tzinfo=pytz.utc)
        result = datetime_now()
        after = datetime.utcnow().replace(tzinfo=pytz.utc)
        if result.tzinfo is None:
            result = result.replace(tzinfo=pytz.utc)
        assert abs((result - before).total_seconds()) < 5


# ===========================================================================
# Log (Singleton logger)
# ===========================================================================


class TestLog:

    def test_log_singleton_vraci_stejnou_instanci(self):
        """Log je Singleton — dvě instance jsou identické."""
        log1 = Log(log_file=None)
        log2 = Log(log_file=None)
        assert log1 is log2

    def test_log_ma_atribut_logger(self):
        """Instance Log má atribut .logger."""
        log = Log(log_file=None)
        assert hasattr(log, "logger")
        assert isinstance(log.logger, logging.Logger)

    def test_log_logger_ma_handlery(self):
        """Logger má alespoň jeden handler (StreamHandler)."""
        log = Log(log_file=None)
        assert len(log.logger.handlers) >= 1

    def test_log_stream_handler_je_pritomen(self):
        """Mezi handlery je StreamHandler na stdout."""
        log = Log(log_file=None)
        handlers = log.logger.handlers
        stream_handlers = [
            h for h in handlers if isinstance(h, logging.StreamHandler) and not isinstance(h, logging.FileHandler)
        ]
        assert len(stream_handlers) >= 1

    def test_log_bez_souboru_nema_file_handler(self):
        """Log(log_file=None) nemá FileHandler."""
        log = Log(log_file=None)
        file_handlers = [h for h in log.logger.handlers if isinstance(h, logging.FileHandler)]
        assert len(file_handlers) == 0

    def test_log_s_souborem_ma_file_handler(self):
        """Log s cestou k souboru vytvoří FileHandler."""
        # Singleton — musíme obejít přes reset
        if hasattr(Singleton, "_instances"):
            Singleton._instances.clear()

        with tempfile.NamedTemporaryFile(suffix=".log", delete=False) as f:
            log_path = f.name

        try:
            log = Log(log_file=log_path)
            file_handlers = [h for h in log.logger.handlers if isinstance(h, logging.FileHandler)]
            assert len(file_handlers) >= 1
        finally:
            # Zavřeme handlery
            for h in log.logger.handlers[:]:
                h.close()
            os.unlink(log_path)

    def test_log_info_nezpusobi_vyjimku(self):
        """log.logger.info() proběhne bez výjimky."""
        log = Log(log_file=None)
        log.logger.info("Test zpráva")  # nesmí vyhodit

    def test_log_error_nezpusobi_vyjimku(self):
        """log.logger.error() proběhne bez výjimky."""
        log = Log(log_file=None)
        log.logger.error("Test chybová zpráva")

    def test_log_debug_nezpusobi_vyjimku(self):
        """log.logger.debug() proběhne bez výjimky."""
        log = Log(log_file=None)
        log.logger.debug("Test debug zpráva")

    def test_log_set_ext_logger_none_nic_nedela(self):
        """set_ext_logger(None) nenastaví žádný logger."""
        log = Log(log_file=None)
        original_logger = log.logger
        log.set_ext_logger(None)
        assert log.logger is original_logger

    def test_log_set_ext_logger_nastavi_logger(self):
        """set_ext_logger(ext) nahradí interní logger."""
        log = Log(log_file=None)
        ext = logging.getLogger("external_test")
        log.set_ext_logger(ext)
        assert log.logger is ext

    def test_log_propagate_je_false(self):
        """Logger má propagate=False (nezahlcuje root logger)."""
        log = Log(log_file=None)
        assert log.logger.propagate is False


# ===========================================================================
# LoggedObject
# ===========================================================================


class TestLoggedObject:

    def test_logged_object_vyzaduje_jmeno(self):
        """LoggedObject vyžaduje object_name."""
        obj = LoggedObject("test_obj")
        assert obj is not None

    def test_logged_object_ma_name(self):
        """LoggedObject má atribut name."""
        obj = LoggedObject("muj_objekt")
        assert obj.name == "muj_objekt"

    def test_logged_object_log_je_logger(self):
        """Property log vrací logging.Logger."""
        obj = LoggedObject("test_obj")
        assert isinstance(obj.log, logging.Logger)

    def test_logged_object_log_ma_spravne_jmeno(self):
        """Logger má jméno shodné s object_name."""
        obj = LoggedObject("muj_logger")
        assert obj.log.name == "muj_logger"

    def test_logged_object_log_info_funguje(self):
        """Přes property log lze volat info()."""
        obj = LoggedObject("test_obj")
        obj.log.info("test zpráva")  # nesmí vyhodit

    def test_logged_object_log_setter_s_none(self):
        """Setter s None nastaví nový logger se stejným jménem."""
        obj = LoggedObject("test_setter")
        obj.log = None
        assert obj.log.name == "test_setter"

    def test_logged_object_log_setter_s_ext_loggerem(self):
        """Setter s externím loggerem ho nastaví."""
        obj = LoggedObject("test_ext")
        ext = logging.getLogger("external_logger")
        obj.log = ext
        assert obj.log.name == "external_logger"
