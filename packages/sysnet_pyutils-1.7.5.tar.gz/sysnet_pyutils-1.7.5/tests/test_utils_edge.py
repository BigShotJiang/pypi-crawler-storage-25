from pathlib import Path

from sysnet_pyutils.constants import CONFIG_API_KEYS, CONFIG_CERT, CONFIG_PASSWD, CONFIG_PASSWORD, CONFIG_PATH
from sysnet_pyutils.utils import (
    Context,
    Log,
    LoggedObject,
    Singleton,
    convert_hex_to_int,
    increment_date,
    is_base64,
    parse_ldap_name,
    to_base64,
)


class TestUtilsEdgeBranches:
    def test_logged_object_log_setter_uses_default_logger(self):
        obj = LoggedObject("X")
        obj.log = None
        assert obj.log.name == "X"

    def test_convert_hex_to_int_invalid_returns_none(self):
        assert convert_hex_to_int("NOT_HEX") is None

    def test_increment_date_invalid_format_returns_none(self):
        assert increment_date("31-12-2024", days=1) is None

    def test_is_base64_invalid_type_returns_false(self):
        assert is_base64(123) is False

    def test_to_base64_invalid_type_returns_none(self):
        assert to_base64(123) is None

    def test_parse_ldap_name_returns_original_when_no_cn(self):
        cn, original = parse_ldap_name("uid=abc,ou=people,dc=example,dc=com")
        assert cn == "uid=abc,ou=people,dc=example,dc=com"
        assert original is None

    def test_parse_ldap_name_parses_cn_with_commas(self):
        cn, original = parse_ldap_name("CN=Jan Novak, O=Org, C=CZ")
        assert cn == "Jan Novak"
        assert original.startswith("CN=")

    def test_context_check_api_key_sets_cert_fields(self):
        cfg = {
            "agenda1": {
                CONFIG_API_KEYS: [{"KEY123": "user1"}],
                CONFIG_CERT: {CONFIG_PATH: "cert.pem", CONFIG_PASSWORD: "secret"},
            }
        }
        ctx = Context(config=cfg)
        ok = ctx.check_api_key("KEY123")
        assert ok is True
        assert ctx.user_name == "user1"
        assert ctx.cert_file == "cert.pem"
        assert ctx.cert_pass == "secret"

    def test_context_check_user_authenticates(self):
        cfg = {
            "agenda1": {
                CONFIG_PASSWD: {"alice": "pwd"},
            }
        }
        ctx = Context(config=cfg)
        ok = ctx.check_user("alice", "pwd")
        assert ok is True
        assert ctx.user_name == "alice"

    def test_log_can_create_file_handler(self, tmp_path: Path):
        log_path = tmp_path / "test.log"
        l = Log(log_file=str(log_path)).logger
        l.info("hello")
        assert log_path.exists()

    def test_context_init_with_none_config_hits_error_branch(self):
        ctx = Context(config=None)
        assert ctx.config is None
        assert ctx.authenticated is False

    def test_singleton_reconfigure_hook_is_called_on_second_instantiation(self):
        class R(metaclass=Singleton):
            def __init__(self, value=None):
                self.value = value

            def _singleton_reconfigure(self, value=None):
                if value is not None:
                    self.value = value

        r1 = R(value=1)
        r2 = R(value=2)

        assert r1 is r2
        assert r1.value == 2

    def test_parse_ldap_name_single_segment_hits_else_branch(self):
        # bez ',' i bez '/' => spadne do větve: ldap = [ldap_name]
        cn, original = parse_ldap_name("cn=Jan Novak")
        assert cn == "Jan Novak"
        assert original == "cn=Jan Novak"

    def test_context_check_user_sets_cert_fields(self):
        cfg = {
            "agenda1": {
                CONFIG_PASSWD: {"alice": "pwd"},
                CONFIG_CERT: {CONFIG_PATH: "cert.pem", CONFIG_PASSWORD: "secret"},
            }
        }
        ctx = Context(config=cfg)
        ok = ctx.check_user("alice", "pwd")
        assert ok is True
        assert ctx.user_name == "alice"
        assert ctx.cert_file == "cert.pem"
        assert ctx.cert_pass == "secret"
