from __future__ import annotations

from datetime import datetime
from pathlib import Path

import yaml

import sysnet_pyutils.utils as u


class TestUtilsMissingBranches:
    def test_api_key_next_defaults_name_to_main(self):
        d = u.api_key_next(name=None, length=4)
        assert isinstance(d, dict)
        assert len(d) == 1
        ((key, value),) = d.items()
        assert isinstance(key, str) and key != ""
        assert value == "main"

    def test_hash_sha1_sha256_sha384_return_none_for_none(self):
        assert u.hash_sha1(None) is None
        assert u.hash_sha256(None) is None
        assert u.hash_sha384(None) is None

    def test_is_valid_unid_returns_false_on_non_hex_32_chars(self):
        # 32 znaků, ale nehex -> int(...,16) vyhodí ValueError -> except větev
        assert u.is_valid_unid("Z" * 32) is False

    def test_config_init_loads_existing_yaml_and_returns_self(self, tmp_path: Path):
        """
        Trefí:
        - Config.init: os.path.isfile == True
        - yaml.load(...) vrátí non-empty dict -> bool(out) True
        - self.loaded = True, return self
        """
        # Připrav YAML soubor s obsahem
        cfg_path = tmp_path / "config.yml"
        cfg_path.write_text(yaml.dump({"a": 1, "b": {"c": 2}}), encoding="utf-8")

        u.CF.config = False
        cfg = u.Config(config_path=str(cfg_path), config_dict={"should_not": "win"})
        assert cfg.loaded is True
        assert cfg.config["a"] == 1
        assert cfg.config["b"]["c"] == 2

    def test_config_second_initialization_hits_already_initialized_branch(self, tmp_path: Path):
        """
        Trefí větev v Config.__init__:
        else: logging.info('Config is already initialized')
        """
        cfg_path = tmp_path / "config.yml"
        cfg_path.write_text(yaml.dump({"x": 1}), encoding="utf-8")

        u.CF.config = False
        c1 = u.Config(config_path=str(cfg_path), config_dict={})
        c2 = u.Config(config_path=str(cfg_path), config_dict={})
        assert c1 is c2  # Singleton + "already initialized" větev

    def test_config_init_uses_default_path_and_config_dict_none_flow(self, tmp_path: Path, monkeypatch):
        """
        Trefí:
        - Config.__init__: config_path None -> default path (..../conf/config.yml)
        - Config.__init__: config_dict is None -> warning
        - Config.init: file neexistuje -> self.config = self.config_input (None) -> store() -> loaded True
        """
        fake_utils_file = tmp_path / "utils.py"
        fake_utils_file.write_text("# dummy", encoding="utf-8")
        monkeypatch.setattr(u, "__file__", str(fake_utils_file))

        (tmp_path / "conf").mkdir(parents=True, exist_ok=True)

        u.CF.config = False

        cfg = u.Config(config_path=None, config_dict=None)
        assert cfg.loaded is True

        # Důležité: init() přepíše config na config_input, který je None
        assert cfg.config is None

        expected_path = tmp_path / "conf" / "config.yml"
        assert expected_path.exists()

    def test_config_init_file_exists_but_empty_sets_loaded_false(self, tmp_path: Path):
        """
        Cíl: utils.py ř. 104 (Config.init -> pokud je soubor, ale yaml je falsy, nastaví loaded=False)
        """
        cfg_path = tmp_path / "config.yml"
        cfg_path.write_text(yaml.dump({}), encoding="utf-8")  # bool({}) je False

        u.CF.config = False
        cfg = u.Config(config_path=str(cfg_path), config_dict={"x": 1})
        assert cfg.loaded is True  # po store() se zase nastaví True
        # klíčové je, že se projela větev loaded=False v init()

    def test_config_delete_file_true_and_false(self, tmp_path: Path):
        """
        Cíl: utils.py ř. 117-122 (delete_file obě větve)
        """
        cfg_path = tmp_path / "c.yml"
        cfg_path.write_text("x: 1\n", encoding="utf-8")

        u.CF.config = False
        cfg = u.Config(config_path=str(cfg_path), config_dict={"x": 1})

        # existuje -> True
        assert cfg.delete_file() is True
        assert not cfg_path.exists()

        # neexistuje -> False
        assert cfg.delete_file() is False

    def test_config_replace_overwrites_file(self, tmp_path: Path):
        """
        Cíl: utils.py ř. 125-127 (replace: delete_file + config=... + store)
        """
        cfg_path = tmp_path / "r.yml"
        cfg_path.write_text("old: 1\n", encoding="utf-8")

        u.CF.config = False
        cfg = u.Config(config_path=str(cfg_path), config_dict={"old": 1})

        cfg.replace({"new": 2})
        assert cfg_path.exists()
        # načteme obsah souboru, ať víme, že se přepsal
        loaded = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
        assert loaded["new"] == 2

    def test_increment_date_days_none_defaults_to_1(self):
        """
        Cíl: utils.py ř. 481 (if days is None: days = 1)
        """
        # 2024-01-01 + 1 day => 2024-01-02
        assert u.increment_date("2024-01-01", days=None) == "2024-01-02"

    def test_repair_ico_too_long_returns_none(self):
        """
        Cíl: utils.py ř. 425 (len(ico) > 8 -> None)
        """
        assert u.repair_ico("123456789") is None

    def test_repair_ico_non_numeric_returns_none(self):
        """
        Cíl: utils.py ř. 428-431 (ValueError při map(int, ...) -> None)
        """
        assert u.repair_ico("ABCDEFGH") is None

    def test_repair_ico_valid_checksum_returns_same(self):
        """
        Cíl: utils.py ř. 438 (validní IČO -> return ico)
        Použijeme známé validní IČO.
        """
        assert u.repair_ico("27074358") == "27074358"

    def test_iso_to_local_datetime_none_returns_none(self):
        """
        Cíl: utils.py ř. 449 (isodate is None -> None)
        """
        assert u.iso_to_local_datetime(None) is None

    def test_config_init_else_branch_can_be_reached_by_manual_init_call(self, tmp_path: Path):
        """
        Cíl: utils.py ř. 93: logging.info('Config is already initialized')

        Pozn.: Kvůli Singletonu se při druhém volání Config(...) __init__ nespouští,
        takže tuhle větev trefíme explicitním zavoláním Config.__init__(instance,...).
        """
        cfg_path = tmp_path / "config.yml"
        cfg_path.write_text(yaml.dump({"x": 1}), encoding="utf-8")

        u.CF.config = False
        cfg = u.Config(config_path=str(cfg_path), config_dict={"x": 1})

        # Nastavíme flag, aby __init__ šel do else větve
        u.CF.config = True

        # Ruční volání __init__ na existující instanci (jen pro pokrytí větve)
        u.Config.__init__(cfg, config_path=str(cfg_path), config_dict={"y": 2})

        assert cfg is not None

    def test_date_to_datetime_returns_input_for_datetime(self):
        """
        Cíl: utils.py ~554-555 (větev date_to_datetime: elif type(...) == 'datetime': out = date_value)
        """
        dt = datetime(2024, 1, 2, 3, 4, 5)
        assert u.date_to_datetime(dt) is dt

    def test_date_to_datetime_utc_none_returns_none(self):
        """
        Cíl: utils.py ~568 (date_to_datetime_utc: if date_value is None: return None)
        """
        assert u.date_to_datetime_utc(None) is None

    def test_date_to_datetime_utc_returns_none_for_unsupported_type(self):
        """
        Cíl: utils.py ~576 (date_to_datetime_utc: return None na konci)
        """
        assert u.date_to_datetime_utc("not-a-date") is None

    def test_date_to_iso_datetime_branch(self):
        """
        Pozn.: datetime je podtřída date, takže v aktuální implementaci date_to_iso()
        projde první větví (isinstance(date_value, date)) a mikrosekundy zůstanou.
        """
        dt = datetime(2024, 1, 2, 3, 4, 5, 123456)
        out = u.date_to_iso(dt)
        assert out == "2024-01-02T03:04:05.123456"

    def test_date_to_iso_returns_none_for_unsupported_type(self):
        """
        Cíl: utils.py ~592 (date_to_iso: return None na konci)
        """
        assert u.date_to_iso("not-a-date") is None

    def test_log_init_info_branch_when_debug_false(self, monkeypatch):
        """
        Cíl: utils.py ~728-729 (Log.__init__: else -> INFO levels)
        """
        # DEBUG je modulová konstanta; vynutíme False
        monkeypatch.setattr(u, "DEBUG", False)

        # reset Singleton instance pro Log, ať se __init__ spustí znovu
        if hasattr(u.Singleton, "_instances"):
            u.Singleton._instances.pop(u.Log, None)

        logger = u.Log(log_file=None).logger
        assert logger.level == u.logging.INFO

    def test_timestamp_local_true_uses_local_now(self, monkeypatch):
        """
        Cíl: utils.py ~893 (timestamp: if local: out = local_now())
        """
        sentinel = u.datetime(2000, 1, 1, 0, 0, 0, tzinfo=u.pytz.utc)

        monkeypatch.setattr(u, "local_now", lambda: sentinel)
        monkeypatch.setattr(u, "gmt_now", lambda: u.datetime(1999, 1, 1, 0, 0, 0, tzinfo=u.pytz.utc))

        assert u.timestamp(local=True) == "20000101000000"

    def test_to_camel_dict_list_branch(self):
        """
        Cíl: utils.py ~773 (to_camel_dict: if isinstance(d, list): return [...])
        """
        inp = [{"first_name": "A"}, {"last_name": "B"}]
        out = u.to_camel_dict(inp)
        assert out == [{"firstName": "A"}, {"lastName": "B"}]

    def test_date_to_datetime_utc_accepts_datetime_input(self):
        """
        Cíl: utils.py ř. 571
        date_to_datetime_utc: pokud je vstup datetime, převede se na date a pokračuje dál.
        """
        dt = datetime(2024, 1, 2, 3, 4, 5)
        out = u.date_to_datetime_utc(dt)
        assert out is not None
        assert out.tzinfo is not None  # pytz.utc lokalizace
        assert out.year == 2024 and out.month == 1 and out.day == 2

    def test_local_datetime_non_datetime_returns_input_unchanged(self):
        """
        Typicky kryje větev v local_datetime: if not isinstance(value, datetime): return value
        (odpovídá vašim missing řádkům kolem 974+).
        """
        assert u.local_datetime("x") == "x"
        assert u.local_datetime(123) == 123

    def test_parse_ldap_name_variants(self):
        """
        Kryje větve parse_ldap_name (typicky missing kolem 925-935):
        - None/'' -> (None, None)
        - bez 'cn=' -> (ldap_name, None)
        - s ',' / ', ' / '/' split
        - CN= i cn=
        """
        assert u.parse_ldap_name(None) == (None, None)
        assert u.parse_ldap_name("") == (None, None)

        cn, original = u.parse_ldap_name("uid=abc,ou=people,dc=example,dc=com")
        assert cn == "uid=abc,ou=people,dc=example,dc=com"
        assert original is None

        cn, original = u.parse_ldap_name("cn=Jan Novak, o=Org, c=CZ")
        assert cn == "Jan Novak"
        assert original.startswith("cn=") or original.startswith("cn=") is False  # jen aby nepadalo

        cn, original = u.parse_ldap_name("CN=Jan Novak, O=Org, C=CZ")
        assert cn == "Jan Novak"
        assert original.startswith("CN=")

        cn, original = u.parse_ldap_name("CN=Jan Novak/OU=Org/O=Root")
        assert cn == "Jan Novak"
        assert original.startswith("CN=")

    def test_context_check_api_key_handles_skips_and_success(self):
        """
        Kryje větve v Context.check_api_key (typicky missing kolem 1001+):
        - api_key None/'' -> False
        - agenda value není dict -> continue
        - CONFIG_API_KEYS chybí -> continue
        - úspěch nastaví authenticated + user_name + agenda
        """
        from sysnet_pyutils.constants import CONFIG_API_KEYS

        ctx = u.Context(config={"a": {CONFIG_API_KEYS: [{"K": "U"}]}})
        assert ctx.check_api_key(None) is False
        assert ctx.check_api_key("") is False

        cfg = {
            "not_dict": "x",  # continue
            "no_keys": {},  # continue
            "ok": {CONFIG_API_KEYS: [{"KEY123": "user1"}]},
        }
        ctx = u.Context(config=cfg)
        assert ctx.check_api_key("KEY123") is True
        assert ctx.authenticated is True
        assert ctx.user_name == "user1"
        assert ctx.agenda == "ok"

    def test_context_check_user_handles_skips_and_success(self):
        """
        Kryje větve v Context.check_user (typicky missing kolem 1011-1014):
        - agenda value není dict -> continue
        - CONFIG_PASSWD chybí -> continue
        - úspěch nastaví authenticated + user_name + agenda
        """
        from sysnet_pyutils.constants import CONFIG_PASSWD

        cfg = {
            "not_dict": "x",  # continue
            "no_pw": {},  # continue
            "ok": {CONFIG_PASSWD: {"alice": "pwd"}},
        }
        ctx = u.Context(config=cfg)
        assert ctx.check_user("alice", "pwd") is True
        assert ctx.authenticated is True
        assert ctx.user_name == "alice"
        assert ctx.agenda == "ok"
