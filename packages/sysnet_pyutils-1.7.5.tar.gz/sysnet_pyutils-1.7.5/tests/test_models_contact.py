"""
Testy pro ContactType a přidružené modely (PhoneNumberType, MailAddressType)
v modulu sysnet_pyutils.models.general

Pokrývá:
  - pyutils-bcn.2: základní vytvoření a pole
  - pyutils-bcn.3: integrace PhoneNumberType a MailAddressType
  - pyutils-bcn.4: alias phoneDefault / phone_default
  - pyutils-bcn.5: hraniční případy
"""

from datetime import datetime

import pytest
from pydantic import ValidationError

from sysnet_pyutils.models.general import (
    ContactType,
    MailAddressType,
    PhoneNumberType,
)


# ---------------------------------------------------------------------------
# Pomocné továrny
# ---------------------------------------------------------------------------

def make_phone(name: str = "mobil", prefix: str = "+420", number: str = "602000001") -> PhoneNumberType:
    return PhoneNumberType(name=name, prefix=prefix, number=number)


def make_email(name: str = "práce", email: str = "test@example.com") -> MailAddressType:
    return MailAddressType(name=name, email=email)


# ---------------------------------------------------------------------------
# PhoneNumberType
# ---------------------------------------------------------------------------

class TestPhoneNumberType:
    """Testy pro PhoneNumberType"""

    def test_create_with_all_fields(self):
        phone = PhoneNumberType(name="mobil", prefix="+420", number="602000001")
        assert phone.name == "mobil"
        assert phone.prefix == "+420"
        assert phone.number == "602000001"

    def test_create_empty(self):
        phone = PhoneNumberType()
        assert phone.name is None
        assert phone.prefix is None
        assert phone.number is None

    def test_create_partial(self):
        phone = PhoneNumberType(number="123456789")
        assert phone.number == "123456789"
        assert phone.name is None
        assert phone.prefix is None


# ---------------------------------------------------------------------------
# MailAddressType
# ---------------------------------------------------------------------------

class TestMailAddressType:
    """Testy pro MailAddressType"""

    def test_create_with_all_fields(self):
        mail = MailAddressType(name="práce", email="jan@example.com")
        assert mail.name == "práce"
        assert mail.email == "jan@example.com"

    def test_create_empty(self):
        mail = MailAddressType()
        assert mail.name is None
        assert mail.email is None

    def test_create_partial(self):
        mail = MailAddressType(email="only@email.cz")
        assert mail.email == "only@email.cz"
        assert mail.name is None


# ---------------------------------------------------------------------------
# ContactType — bcn.2: základní vytvoření a pole
# ---------------------------------------------------------------------------

class TestContactTypeBasic:
    """Testy základního vytvoření ContactType a nastavení polí (bcn.2)"""

    def test_create_empty(self):
        """ContactType lze vytvořit bez argumentů — vše None / default"""
        c = ContactType()
        assert c.identifier is None
        assert c.first_name is None
        assert c.last_name is None
        assert c.degree_before is None
        assert c.degree_after is None
        assert c.full_name is None
        assert c.birthdate is None
        assert c.phone is None
        assert c.phone_default == 0
        assert c.email is None
        assert c.email_default == 0
        assert c.web is None
        assert c.isds is None
        assert c.reference is None

    def test_create_with_scalar_fields(self):
        """Nastavení všech skalárních polí"""
        uuid = "550e8400-e29b-41d4-a716-446655440000"
        c = ContactType(
            identifier=uuid,
            first_name="Jan",
            last_name="Novák",
            full_name="Ing. Jan Novák",
            web="https://novak.cz",
            isds="abc1234",
            reference=uuid,
        )
        assert c.identifier == uuid
        assert c.first_name == "Jan"
        assert c.last_name == "Novák"
        assert c.full_name == "Ing. Jan Novák"
        assert c.web == "https://novak.cz"
        assert c.isds == "abc1234"
        assert c.reference == uuid

    def test_create_with_birthdate(self):
        """Pole birthdate přijímá datetime objekt"""
        bday = datetime(1985, 6, 15)
        c = ContactType(birthdate=bday)
        assert c.birthdate == bday
        assert c.birthdate.year == 1985

    def test_create_with_degree_lists(self):
        """Tituly před/za jménem jsou listy stringů"""
        c = ContactType(
            degree_before=["Ing.", "Bc."],
            degree_after=["PhD.", "MBA"],
        )
        assert c.degree_before == ["Ing.", "Bc."]
        assert c.degree_after == ["PhD.", "MBA"]


# ---------------------------------------------------------------------------
# ContactType — bcn.3: integrace PhoneNumberType a MailAddressType
# ---------------------------------------------------------------------------

class TestContactTypePhoneEmail:
    """Testy integrace PhoneNumberType a MailAddressType v ContactType (bcn.3)"""

    def test_single_phone(self):
        """ContactType s jedním telefonním číslem"""
        c = ContactType(phone=[make_phone()])
        assert len(c.phone) == 1
        assert c.phone[0].number == "602000001"

    def test_multiple_phones(self):
        """ContactType s více telefonními čísly"""
        phones = [
            make_phone(name="mobil", number="602000001"),
            make_phone(name="práce", number="257000002"),
        ]
        c = ContactType(phone=phones)
        assert len(c.phone) == 2
        assert c.phone[0].name == "mobil"
        assert c.phone[1].name == "práce"

    def test_single_email(self):
        """ContactType s jednou e-mailovou adresou"""
        c = ContactType(email=[make_email()])
        assert len(c.email) == 1
        assert c.email[0].email == "test@example.com"

    def test_multiple_emails(self):
        """ContactType s více e-mailovými adresami"""
        emails = [
            make_email(name="práce", email="jan@firma.cz"),
            make_email(name="domů", email="jan@home.cz"),
        ]
        c = ContactType(email=emails)
        assert len(c.email) == 2
        assert c.email[0].name == "práce"
        assert c.email[1].name == "domů"

    def test_phone_and_email_combined(self):
        """ContactType kombinuje phone i email"""
        c = ContactType(
            first_name="Eva",
            last_name="Svobodová",
            phone=[make_phone()],
            email=[make_email()],
        )
        assert c.first_name == "Eva"
        assert len(c.phone) == 1
        assert len(c.email) == 1


# ---------------------------------------------------------------------------
# ContactType — bcn.4: alias phoneDefault / phone_default
# ---------------------------------------------------------------------------

class TestContactTypeAlias:
    """Testy Pydantic aliasu phoneDefault vs phone_default (bcn.4)"""

    def test_phone_default_python_name(self):
        """phone_default lze nastavit přes Python název pole"""
        c = ContactType(phone_default=1)
        assert c.phone_default == 1

    def test_phone_default_via_alias_dict(self):
        """Parsování z dict s camelCase klíčem phoneDefault"""
        data = {"phoneDefault": 2}
        c = ContactType.model_validate(data)
        assert c.phone_default == 2

    def test_phone_default_default_value(self):
        """Výchozí hodnota phone_default je 0"""
        c = ContactType()
        assert c.phone_default == 0

    def test_email_default_default_value(self):
        """Výchozí hodnota email_default je 0"""
        c = ContactType()
        assert c.email_default == 0

    def test_email_default_set(self):
        """email_default lze nastavit"""
        c = ContactType(email_default=3)
        assert c.email_default == 3

    def test_model_dump_snake_case(self):
        """model_dump() vrátí phone_default (snake_case)"""
        c = ContactType(phone_default=1)
        d = c.model_dump()
        assert "phone_default" in d
        assert d["phone_default"] == 1

    def test_model_dump_by_alias(self):
        """model_dump(by_alias=True) vrátí phoneDefault (camelCase)"""
        c = ContactType(phone_default=1)
        d = c.model_dump(by_alias=True)
        assert "phoneDefault" in d
        assert d["phoneDefault"] == 1

    def test_model_dump_by_alias_excludes_snake(self):
        """model_dump(by_alias=True) neobsahuje phone_default snake variantu"""
        c = ContactType(phone_default=1)
        d = c.model_dump(by_alias=True)
        assert "phone_default" not in d


# ---------------------------------------------------------------------------
# ContactType — bcn.5: hraniční případy
# ---------------------------------------------------------------------------

class TestContactTypeEdgeCases:
    """Hraniční případy ContactType (bcn.5)"""

    def test_all_none_fields(self):
        """ContactType přijme explicitní None u všech Optional polí"""
        c = ContactType(
            identifier=None,
            first_name=None,
            last_name=None,
            degree_before=None,
            degree_after=None,
            full_name=None,
            birthdate=None,
            phone=None,
            email=None,
            web=None,
            isds=None,
            reference=None,
        )
        assert c.phone is None
        assert c.email is None

    def test_empty_lists_for_phone_and_email(self):
        """Prázdný seznam pro phone/email je validní"""
        c = ContactType(phone=[], email=[])
        assert c.phone == []
        assert c.email == []

    def test_degree_before_with_none_items(self):
        """List titulů může obsahovat None hodnoty"""
        c = ContactType(degree_before=["Ing.", None, "Bc."])
        assert c.degree_before == ["Ing.", None, "Bc."]

    def test_phone_list_with_none_item(self):
        """Seznam telefonů může obsahovat None (dle type annotation)"""
        c = ContactType(phone=[make_phone(), None])
        assert c.phone[0].number == "602000001"
        assert c.phone[1] is None

    def test_serialization_round_trip(self):
        """model_dump → model_validate zachová data"""
        original = ContactType(
            identifier="abc-123",
            first_name="Petr",
            last_name="Kos",
            phone=[make_phone()],
            email=[make_email()],
            phone_default=0,
            email_default=0,
        )
        data = original.model_dump()
        restored = ContactType.model_validate(data)
        assert restored.identifier == original.identifier
        assert restored.first_name == original.first_name
        assert restored.phone[0].number == original.phone[0].number
        assert restored.email[0].email == original.email[0].email

    def test_json_round_trip(self):
        """model_dump_json → model_validate_json zachová data"""
        original = ContactType(
            first_name="Jana",
            isds="xyz9876",
            phone=[make_phone(number="777888999")],
        )
        json_str = original.model_dump_json()
        restored = ContactType.model_validate_json(json_str)
        assert restored.first_name == "Jana"
        assert restored.isds == "xyz9876"
        assert restored.phone[0].number == "777888999"

    def test_export_from_package_init(self):
        """ContactType je exportován z hlavního __init__ balíčku"""
        from sysnet_pyutils import ContactType as CT
        assert CT is ContactType

