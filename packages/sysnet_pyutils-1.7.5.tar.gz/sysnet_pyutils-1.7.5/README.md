# sysnet-pyutils

**SYSNET Python Utilities Library**

Knihovna obsahuje základní, v aplikacích hojně používané, utility pro Python projekty.

[![Python](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Tests](https://img.shields.io/badge/tests-passing-brightgreen.svg)](tests/)
[![Coverage](https://img.shields.io/badge/coverage-90%25-brightgreen.svg)](tests/)

---

## 📋 Obsah

- [Instalace](#instalace)
- [Rychlý start](#rychlý-start)
- [Moduly](#moduly)
  - [utils](#utilspy---hlavní-modul)
  - [data_utils](#data_utilspy)
  - [domino](#dominopy)
  - [geo](#geopy)
  - [cron_utils](#cron_utils)
  - [globalmodel](#globalmodel)
  - [log](#logpy)
  - [ses](#sespy)
  - [syslog](#syslog)
  - [models.general](#modelsgeneral)
- [Volitelné závislosti](#volitelné-závislosti)
- [Testování](#testování)
- [Vývoj](#vývoj)
- [Systémové proměnné](#systémové-proměnné)
- [Changelog](#changelog)
- [Podpora](#podpora)

---

## 🚀 Instalace

### Základní instalace

```bash
pip install sysnet-pyutils
```

### S volitelnými závislostmi

```bash
# Podpora AWS SES
pip install sysnet-pyutils[aws]

# Podpora MongoDB
pip install sysnet-pyutils[mongodb]

# Podpora cron validace
pip install sysnet-pyutils[cron]

# Vše najednou
pip install sysnet-pyutils[all]
```

### Instalace z repository

```bash
git clone https://github.com/SYSNET-CZ/pyutils.git
cd pyutils
pip install -e .
```

### Požadavky

- Python 3.10+
- Hlavní závislosti (automaticky nainstalovány):
  - `pydantic[email]>=2.10.6`
  - `pytz>=2023.3`
  - `python-dateutil>=2.8.2`
  - `PyYAML>=6.0.1`
  - `xmltodict>=1.0.0`
  - `typing-extensions>=4.12.0`

---

## ⚡ Rychlý start

```python
import sysnet_pyutils as pu

# Generování identifikátorů
pid = pu.pid_next()
uuid = pu.uuid_next()

# Validace
is_valid = pu.is_valid_email("test@example.com")
is_valid_ico = pu.is_valid_ico("27074358")

# Datum a čas
today = pu.today()
now = pu.local_now()

# Hash
sha256 = pu.hash_sha256("text")

# Konfigurace
config = pu.Config(config_path='config.yml', config_dict={'key': 'value'})
```

---

## 📦 Moduly

### utils.py — Hlavní modul

Obsahuje nejčastěji používané utility funkce, třídy a vzory.

#### Singleton pattern

```python
from sysnet_pyutils import Singleton

class MyClass(metaclass=Singleton):
    def __init__(self):
        self.value = 42

instance1 = MyClass()
instance2 = MyClass()
assert instance1 is instance2  # Vždy stejná instance
```

#### Konfigurace

```python
from sysnet_pyutils import Config

config = Config(
    config_path='app_config.yml',
    config_dict={'database': 'mongodb://localhost'}
)

if config.loaded:
    db_url = config.config['database']
```

#### Context a autentizace

```python
from sysnet_pyutils import Context, api_keys_init

# Generování API klíčů
keys = api_keys_init(agenda='my_app', amount=3)

config = {'my_app': {'api_keys': keys}}

ctx = Context(config=config)
if ctx.check_api_key('some_key'):
    print(f"Přihlášen jako: {ctx.user_name}")
```

#### Identifikátory a validace

```python
from sysnet_pyutils import pid_next, pid_check, pid_correct
from sysnet_pyutils import is_valid_uuid, is_valid_ico, is_valid_email, repair_ico

# PID — 12místný identifikátor s kontrolním součtem
pid = pid_next()
is_valid = pid_check(pid)
corrected = pid_correct("SNT12345678X")

# Validace
is_valid_ico("27074358")           # True
is_valid_email("user@example.com") # True
repair_ico("2707435X")             # Opraví kontrolní součet
```

#### Hash funkce

```python
from sysnet_pyutils import hash_md5, hash_sha1, hash_sha256, hash_sha384

sha256 = hash_sha256("Hello World")
```

#### Datum a čas

```python
from sysnet_pyutils import local_now, gmt_now, today, tomorrow
from sysnet_pyutils import date_to_datetime, date_to_datetime_utc, date_to_iso
from datetime import date

dt = date_to_datetime(date(2023, 5, 15))      # datetime v lokální TZ
dt_utc = date_to_datetime_utc(date(2023, 5, 15))  # datetime v UTC
iso = date_to_iso(date(2023, 5, 15))          # "2023-05-15"
```

#### Base64

```python
from sysnet_pyutils import encode_string_b64, decode_b64_string
from sysnet_pyutils import encode_file_b64, decode_b64_to_file

encoded = encode_string_b64("Hello")
decoded = decode_b64_string(encoded)
```

#### Konverze case a XML

```python
from sysnet_pyutils import to_snake, to_camel, to_snake_dict, to_camel_dict
from sysnet_pyutils import xml_to_dict, dict_to_xml

snake = to_snake("camelCase")        # "camel_case"
camel = to_camel("snake_case")       # "snakeCase"
data = xml_to_dict("<root><n>X</n></root>")
```

#### CITES utility

```python
from sysnet_pyutils import order_to_cites, cites_to_order

letters = order_to_cites(1458)  # "BDB"
number = cites_to_order("BDB")  # 1458
```

---

### data_utils.py

Utility pro práci se slovníky, konverzi typů a stránkování MongoDB.

```python
from sysnet_pyutils import (
    get_dict_value_string, get_dict_value_int, get_dict_value_float,
    get_dict_value_bool, get_dict_value_date, get_dict_value_datetime,
    get_dict_value_email, get_dict_value_code, get_dict_value_uuid,
    convert_iso_to_date, convert_cz_to_date,
    paging_to_mongo, address_to_string,
    normalize_datetime, localize_datetime,
)

data = {'name': 'John', 'age': '30', 'email': 'john@example.com'}

name = get_dict_value_string(data, 'name')   # "John"
age = get_dict_value_int(data, 'age')         # 30
email = get_dict_value_email(data, 'email')   # "john@example.com"

# Konverze datumů
d = convert_iso_to_date('2023-05-15')
d_cz = convert_cz_to_date('15.05.2023')

# Stránkování pro MongoDB
paging = paging_to_mongo(start=20, page_size=10)
# {'start': 0, 'page': 2, 'skip': 20, 'limit': 10}

# Adresa na string
address = {'street': 'Main St 123', 'city': 'Prague', 'zip': '110 00'}
addr_str = address_to_string(address)

# Normalizace datetime na UTC
# Naivní datetime dostane zónu dle env TZ (výchozí: Europe/Prague), pak se převede na UTC.
# Čistý date → půlnoc v lokální zóně → UTC.
from datetime import date, datetime
utc_dt = normalize_datetime(datetime(2024, 7, 1, 12, 0, 0))   # naive → Prague → UTC
utc_dt = normalize_datetime(date(2024, 7, 1))                  # půlnoc Prague → UTC
utc_dt = normalize_datetime(None)                              # None → None

# Lokalizace datetime do lokální zóny (env TZ)
# Naivní datetime se považuje za UTC a převede do lokální zóny.
# Čistý date → půlnoc UTC → lokální zóna.
local_dt = localize_datetime(datetime(2024, 7, 1, 10, 0, 0))  # naive UTC → Prague
local_dt = localize_datetime(date(2024, 7, 1))                 # půlnoc UTC → Prague
local_dt = localize_datetime(None)                             # None → None
```

---

### domino.py

Práce s HCL Domino Data Service (DDS).

```python
from sysnet_pyutils import DdsDictionaryFactory

dds_data = {
    'Title': 'Test Document',
    'DateCreated': '2023-05-15T10:00:00',
    'IsActive': '1',
    'Amount': '99.99'
}

factory = DdsDictionaryFactory(dds_data)

title = factory.get_value_string('Title')
is_active = factory.get_value_bool('IsActive')
amount = factory.get_value_float('Amount')
date_created = factory.get_value_datetime('DateCreated')

factory.set_value_string('Status', 'Approved')
factory.set_value_bool('Published', True)
```

---

### geo.py

Geografické transformace — konverze mezi WGS84 a S-JTSK.

```python
from sysnet_pyutils import Wgs84, JTSK

wgs = Wgs84(latitude=50.0755, longitude=14.4378, altitude=200.0)

jtsk = JTSK(0, 0)
jtsk.from_wgs84(lon=wgs.longitude, lat=wgs.latitude, alt=wgs.altitude)

print(f"JTSK X: {jtsk.x:.2f}, Y: {jtsk.y:.2f}")
```

---

### cron_utils

Validace cron výrazů (syntaktická i sémantická).

Vyžaduje volitelnou závislost: `pip install sysnet-pyutils[cron]`

```python
from sysnet_pyutils.cron_utils.validation import (
    is_cron_syntax_valid,
    has_next_occurrence,
    validate_cron,
    summarize_cron,
)

# Syntaktická validace
is_cron_syntax_valid("0 9 * * 1-5")   # True
is_cron_syntax_valid("60 * * * *")    # False — minuta mimo rozsah

# Sémantická validace
has_next_occurrence("0 0 31 2 *")     # False — 31.2. nikdy nenastane

# Kompletní validace
is_valid, errors = validate_cron("0 9 * * 1-5")

# Sumarizace s dalším výskytem
summary = summarize_cron("0 9 * * 1-5")
if summary.syntax_ok and summary.has_occurrence:
    print(f"Další spuštění: {summary.next_run}")
```

---

### globalmodel

Pydantic `BaseModel` s automatickou normalizací `datetime` do UTC.

```python
from sysnet_pyutils import GlobalModel, PRAGUE_TZ
from datetime import datetime

class MyModel(GlobalModel):
    created_at: datetime | None = None

# Naivní datetime je považován za Europe/Prague a převeden na UTC
m = MyModel(created_at=datetime(2023, 5, 15, 10, 0, 0))
print(m.created_at)  # 2023-05-15 08:00:00+00:00 (UTC)
```

---

### log.py

MongoDB logging handler.

Vyžaduje volitelnou závislost: `pip install sysnet-pyutils[mongodb]`

```python
import logging
from sysnet_pyutils.log import MongoHandler

logger = logging.getLogger("myapp")
logger.addHandler(MongoHandler(
    host="localhost",
    port=27017,
    database="logging",
    collection="app_logs",
))

logger.error("Nastala chyba!")
```

---

### ses.py

Odesílání e-mailů přes Amazon SES.

Vyžaduje volitelnou závislost: `pip install sysnet-pyutils[aws]`

```python
from sysnet_pyutils.ses import SesFactory

ses = SesFactory(
    aws_region='eu-west-1',
    aws_access_key='KEY',
    aws_secret_access_key='SECRET',
    sender='noreply@example.com',
)

ses.send_email(
    recipient='user@example.com',
    subject='Test',
    body_text='Tělo zprávy v plain textu.',
    body_html='<p>Tělo zprávy v HTML.</p>',
)
```

---

### syslog

Asynchronní odesílání zpráv na syslog server (UDP/TCP).

```python
import asyncio
from sysnet_pyutils import SyslogFactory

syslog = SyslogFactory(server="192.168.1.10", port=514, tag="my-app")

async def main():
    await syslog.log_info("Aplikace spuštěna")
    await syslog.log_error("Nastala chyba")

asyncio.run(main())
```

---

### models.general

Datové modely kompatibilní s FastAPI a Pydantic v2.

```python
from sysnet_pyutils import (
    PersonBaseType, LocationType, GeoPointType,
    CodeValueType, MetadataType, PersonTypeEnum,
    LogItemType, WorkflowType,
)

# Osoba
person = PersonBaseType(
    name="Test Company s.r.o.",
    ico="27074358",
    email="info@test.com",
    location=LocationType(
        street="Main Street 123",
        city="Prague",
        zip="110 00",
        wgs=GeoPointType(lat=50.0755, lon=14.4378),
        country=CodeValueType(code="CZ", value="Czech Republic"),
    ),
)
person.unid = "3005277CB984B7FFC12587890060E2BF"
person.make_identifier()

# Metadata — default_factory zajistí aktuální čas při každém vytvoření
metadata = MetadataType(title="Important Document", form="certificate")
print(metadata.date_created)  # Aktuální čas

# Log položka
log_item = LogItemType(message="Dokument autorizován", originator="SYSTEM")
print(str(log_item))  # "2023-05-15 10:00:00 [SYSTEM] Dokument autorizován"
```

---

## 🔌 Volitelné závislosti

| Extra | Balíčky | Použití |
|-------|---------|---------|
| `[aws]` | `boto3`, `botocore` | Modul `ses.py` — AWS SES |
| `[mongodb]` | `pymongo` | Modul `log.py` — MongoDB handler |
| `[cron]` | `croniter` | Modul `cron_utils` — validace cron výrazů |
| `[all]` | vše výše | Všechny volitelné funkce |

> **Poznámka:** Moduly `ses.py` a `log.py` lze importovat i bez příslušných závislostí.
> `ImportError` se vyhodí až při pokusu o instanciaci `SesFactory` / `MongoHandler`.

---

## 🧪 Testování

Knihovna obsahuje komplexní sadu testů s >90% pokrytím kódu.

### Spuštění testů

```bash
# Z kořenového adresáře projektu
cd D:\development\git\pyutils

# Všechny testy
venv\Scripts\python.exe -m pytest tests/

# S podrobným výstupem
venv\Scripts\python.exe -m pytest tests/ -v

# S pokrytím kódu
venv\Scripts\python.exe -m pytest tests/ --cov=sysnet_pyutils --cov-report=html

# Konkrétní modul
venv\Scripts\python.exe -m pytest tests/test_utils.py -v
```

### Testovací soubory

| Soubor | Testovaný modul |
|--------|----------------|
| `test_utils.py` | `utils.py` |
| `test_data_utils.py` | `data_utils.py` |
| `test_domino.py` | `domino.py` |
| `test_geo.py` | `geo.py` |
| `test_cron_utils.py` | `cron_utils/` |
| `test_ident_barcode.py` | `ident.py`, `barcode.py` |
| `test_models_general.py` | `models/general.py` |
| `test_global_model_recursive.py` | `globalmodel/` |
| `test_global_model_timezone.py` | `globalmodel/` |

---

## 👨‍💻 Vývoj

### Struktura projektu

```
pyutils/
├── sysnet_pyutils/          # Hlavní balíček
│   ├── __init__.py          # Veřejné API
│   ├── utils.py             # Hlavní utility modul
│   ├── data_utils.py        # Utility pro slovníky a typy
│   ├── domino.py            # HCL Domino DDS
│   ├── geo.py               # Geografické transformace (WGS84 ↔ JTSK)
│   ├── ident.py             # Identifikátory (PID, ID12)
│   ├── barcode.py           # Code39 čárové kódy
│   ├── constants.py         # Konfigurační konstanty
│   ├── log.py               # MongoDB logging handler
│   ├── ses.py               # AWS SES e-mail
│   ├── tools.py             # Singleton dekorátor
│   ├── cron_utils/          # Validace cron výrazů
│   │   └── validation.py
│   ├── globalmodel/         # GlobalModel s UTC normalizací
│   │   ├── global_model.py
│   │   ├── timeutils.py
│   │   └── models.py
│   ├── models/              # Pydantic datové modely
│   │   └── general.py
│   └── syslog/              # Syslog UDP/TCP klient
│       └── factory.py
├── tests/                   # Pytest testy
│   ├── conftest.py
│   └── test_*.py
├── conf/                    # Výchozí konfigurace
├── logs/                    # Adresář pro logy
├── pyproject.toml           # Build a nástroje
├── requirements.txt         # Závislosti (legacy)
├── upload.ps1               # Skript pro publikaci na PyPI
├── upload.cmd               # Skript pro publikaci (cmd)
└── LICENSE
```

### Přidání nové funkcionality

1. Implementujte funkci v příslušném modulu
2. Exportujte ji v `sysnet_pyutils/__init__.py`
3. Napište testy v `tests/test_<modul>.py`
4. Spusťte testy: `venv\Scripts\python.exe -m pytest tests/`
5. Aktualizujte `README.md` a `REVIZE_PROJEKTU.md`

---

## 🛠 Systémové proměnné

| Proměnná | Popis | Výchozí hodnota |
|----------|-------|-----------------|
| `TZ` | Časová zóna | `'Europe/Prague'` |
| `DEBUG` | Debug režim | `'True'` |
| `LOG_FORMAT` | Formát logování | `'%(asctime)s - %(levelname)s in %(module)s: %(message)s'` |
| `LOG_DATE_FORMAT` | Formát data v logu | `'%d.%m.%Y %H:%M:%S'` |
| `LOG_FILE` | Soubor pro logování | `None` |
| `PID_PREFIX` | Prefix pro PID | `'SNT'` |

---

## 📚 Changelog

### Verze 1.7.5 (2026-04-07)

**Nové funkce:**
- ✅ `data_utils.py` — přidána `normalize_datetime(date | datetime | None) -> datetime | None`: naivní vstup dostane zónu dle `TZ`, výstup vždy UTC
- ✅ `data_utils.py` — přidána `localize_datetime(date | datetime | None) -> datetime | None`: naivní vstup se považuje za UTC, výstup v lokální zóně dle `TZ`
- ✅ Obě funkce exportovány z `sysnet_pyutils/__init__.py`
- ✅ 22 nových testů v `tests/test_data_utils_datetime.py` (včetně DST hraničních případů a roundtrip testů)

### Verze 1.7.1 (2026-03-02)

**Opravy:**
- ✅ `constants.py` — doplněna chybějící konstanta `CONFIG_PASSWORD`
- ✅ `ses.py` — import `boto3` přesunut do lazy guardu (`try/except ImportError`)
- ✅ `log.py` — import `pymongo` přesunut do lazy guardu (`try/except ImportError`)
- ✅ `data_utils.py` — opraven zahozený výsledek `datetime.replace()` v `adjust_datetime_to_utc()`
- ✅ `models/general.py` — `Field(default=local_now())` nahrazeno `Field(default_factory=local_now)` na 4 místech
- ✅ `utils.py` — email regex rozšířen na subdomény a TLD libovolné délky
- ✅ `tests/conftest.py` — bare `except:` nahrazeno `except Exception:`
- ✅ `pyproject.toml` — ruff konfigurace aktualizována na `[tool.ruff.lint]`
- ✅ `sysnet_pyutils/__init__.py` — doplněno kompletní veřejné API balíčku
- ✅ `sysnet_pyutils/syslog/__init__.py` — doplněn export `SyslogFactory`
- ✅ Odstraněno 21 dočasných/analytických souborů z kořenového adresáře

### Verze 1.6.1
- ✅ Kompletní testovací pokrytí (251 testů, >90% coverage)
- ✅ Modernizace `pyproject.toml`
- ✅ Opravy singleton konfliktů v testech

### Verze 1.6.0
- Přidán balíček `cron_utils` pro validaci cron výrazů

### Verze 1.5.0
- Nový `SyslogFactory` pro asynchronní odesílání logů

### Verze 1.4.9
- Atribut `authorized` přesunut do `MetadataTypeBase`

### Verze 1.4.8
- Přidána funkce `get_dict_value_as_person_type()`

### Verze 1.4.4
- Přidána funkce `address_to_string()`

### Verze 1.4.0
- Do `PersonBaseType` přidána strukturovaná adresa `location`

### Verze 1.3.10
- Do `MetadataTypeBase` přidán atribut `comment`

### Verze 1.3.5
- Do `PersonBaseType` přidán atribut `person_printable`

### Verze 1.3.1
- Přidán modul `constants.py`

### Verze 1.3.0
- Přidána třída `Context` pro ověřování API klíčů

### Verze 1.2.0
- UUID → str v modelech (pro MongoDB)
- Přidán `BaseEnum` s metodou `has_value`

### Verze 1.1.0
- Přidán datový slovník `models.general` (Pydantic)

### Verze 1.0.8
- Nové utility `data_utils`

### Verze 1.0.5
- Přidána třída `DdsDictionaryFactory`
- Funkce `local_now()`, `is_valid_unid()`

### Verze 1.0.4
- CITES utility: `order_to_cites()`, `cites_to_order()`

### Verze 1.0.3
- Case konverze: `to_camel()`, `to_snake()`
- XML utility: `xml_to_dict()`, `dict_to_xml()`

---

## 📞 Podpora

### Našli jste bug?

1. Zkontrolujte existující issues
2. Vytvořte nový issue s:
   - Popisem problému
   - Kroky k reprodukci
   - Očekávané a skutečné chování
   - Verze Python a sysnet-pyutils

### Chcete přispět?

1. Forkněte repository
2. Vytvořte feature branch
3. Přidejte testy pro novou funkcionalitu
4. Ověřte, že všechny testy procházejí
5. Vytvořte pull request

---

## 📄 Licence

Tento projekt je licencován pod MIT licencí — viz [LICENSE](LICENSE) soubor.

---

**Vytvořeno s ❤️ týmem SYSNET**

*Verze: 1.7.1*  
*Datum: 2026-03-02*
