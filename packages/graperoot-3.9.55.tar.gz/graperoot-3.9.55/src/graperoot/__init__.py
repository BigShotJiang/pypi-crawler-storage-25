"""Dual-graph context engine for AI coding agents."""
__version__ = "3.9.55"
