"""
Main entry point for the Word Document MCP Server.
Acts as the central controller for the MCP server that handles Word document operations.
Supports multiple transports: stdio, sse, and streamable-http using standalone FastMCP.
"""

import os
import sys
from dotenv import load_dotenv
from word_document_server.defaults import DEFAULT_AUTHOR, DEFAULT_INITIALS

# Load environment variables from .env file
print("Loading configuration from .env file...")
load_dotenv()
# Set required environment variable for FastMCP 2.8.1+
os.environ.setdefault('FASTMCP_LOG_LEVEL', 'INFO')
from fastmcp import FastMCP
from mcp.types import ToolAnnotations
from word_document_server.tools import (
    document_tools,
    content_tools,
    format_tools,
    protection_tools,
    footnote_tools,
    extended_document_tools,
    comment_tools,
    comment_write_tools,
    hyperlink_tools,
    tracked_changes_tools,
    live_tools,
    live_read_tools,
    live_layout_tools,
    screen_capture_tools,
    layout_tools,
)
from word_document_server.tools.content_tools import replace_paragraph_block_below_header_tool
from word_document_server.tools.content_tools import replace_block_between_manual_anchors_tool

def get_transport_config():
    """
    Get transport configuration from environment variables.
    
    Returns:
        dict: Transport configuration with type, host, port, and other settings
    """
    # Default configuration
    config = {
        'transport': 'stdio',  # Default to stdio for backward compatibility
        'host': '0.0.0.0',
        'port': 8000,
        'path': '/mcp',
        'sse_path': '/sse'
    }
    
    # Override with environment variables if provided
    transport = os.getenv('MCP_TRANSPORT', 'stdio').lower()
    print(f"Transport: {transport}")
    # Validate transport type
    valid_transports = ['stdio', 'streamable-http', 'sse']
    if transport not in valid_transports:
        print(f"Warning: Invalid transport '{transport}'. Falling back to 'stdio'.")
        transport = 'stdio'
    
    config['transport'] = transport
    config['host'] = os.getenv('MCP_HOST', config['host'])
    # Use PORT from Render if available, otherwise fall back to MCP_PORT or default
    config['port'] = int(os.getenv('PORT', os.getenv('MCP_PORT', config['port'])))
    config['path'] = os.getenv('MCP_PATH', config['path'])
    config['sse_path'] = os.getenv('MCP_SSE_PATH', config['sse_path'])
    
    return config


def setup_logging(debug_mode):
    """
    Setup logging based on debug mode.
    
    Args:
        debug_mode (bool): Whether to enable debug logging
    """
    import logging
    
    if debug_mode:
        logging.basicConfig(
            level=logging.DEBUG,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        print("Debug logging enabled")
    else:
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )


# Initialize FastMCP server
mcp = FastMCP("Word Document Server")


def register_tools():
    """Register all tools with the MCP server using FastMCP decorators."""
    
    # Document tools (create, copy, info, etc.)
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Create Word Document",
            destructiveHint=True,
        ),
    )
    def create_document(filename: str, title: str = None, author: str = None):
        """Create a new Word document with optional metadata."""
        return document_tools.create_document(filename, title, author)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Copy Word Document",
            destructiveHint=True,
        ),
    )
    def copy_document(source_filename: str, destination_filename: str = None):
        """Create a copy of a Word document."""
        return document_tools.copy_document(source_filename, destination_filename)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Get Document Info",
            readOnlyHint=True,
        ),
    )
    def get_document_info(filename: str):
        """Get information about a Word document."""
        return document_tools.get_document_info(filename)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Get Document Text",
            readOnlyHint=True,
        ),
    )
    def get_document_text(filename: str, show_revisions: bool = False):
        """Extract all text from a Word document.

        By default returns the effective final text (insertions applied,
        deletions removed).  Set show_revisions=True to get inline redline
        markup where deletions appear as [-deleted-] and insertions as
        {+inserted+}."""
        return document_tools.get_document_text(filename, show_revisions=show_revisions)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Get Document Outline",
            readOnlyHint=True,
        ),
    )
    def get_document_outline(filename: str):
        """Get the structure of a Word document."""
        return document_tools.get_document_outline(filename)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="List Available Documents",
            readOnlyHint=True,
        ),
    )
    def list_available_documents(directory: str = "."):
        """List all .docx files in the specified directory."""
        return document_tools.list_available_documents(directory)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Get Document XML",
            readOnlyHint=True,
        ),
    )
    def get_document_xml(filename: str):
        """Get the raw XML structure of a Word document."""
        return document_tools.get_document_xml_tool(filename)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Insert Header Near Text",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def insert_header_near_text(filename: str, target_text: str = None, header_title: str = None, position: str = 'after', header_style: str = 'Heading 1', target_paragraph_index: int = None):
        """Insert a header (with specified style) before or after the target paragraph. Specify by text or paragraph index. Args: filename (str), target_text (str, optional), header_title (str), position ('before' or 'after'), header_style (str, default 'Heading 1'), target_paragraph_index (int, optional)."""
        return content_tools.insert_header_near_text_tool(filename, target_text, header_title, position, header_style, target_paragraph_index)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Insert Line Near Text",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def insert_line_or_paragraph_near_text(filename: str, target_text: str = None, line_text: str = None, position: str = 'after', line_style: str = None, target_paragraph_index: int = None):
        """
        Insert a new line or paragraph (with specified or matched style) before or after the target paragraph. Specify by text or paragraph index. Args: filename (str), target_text (str, optional), line_text (str), position ('before' or 'after'), line_style (str, optional), target_paragraph_index (int, optional).
        """
        return content_tools.insert_line_or_paragraph_near_text_tool(filename, target_text, line_text, position, line_style, target_paragraph_index)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Insert List Near Text",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def insert_numbered_list_near_text(filename: str, target_text: str = None, list_items: list[str] = None, position: str = 'after', target_paragraph_index: int = None, bullet_type: str = 'bullet'):
        """Insert a bulleted or numbered list before or after the target paragraph. Specify by text or paragraph index. Args: filename (str), target_text (str, optional), list_items (list of str), position ('before' or 'after'), target_paragraph_index (int, optional), bullet_type ('bullet' for bullets or 'number' for numbered lists, default: 'bullet')."""
        return content_tools.insert_numbered_list_near_text_tool(filename, target_text, list_items, position, target_paragraph_index, bullet_type)
    # Content tools (paragraphs, headings, tables, etc.)
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Add Paragraph",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def add_paragraph(filename: str, text: str, style: str = None,
                      font_name: str = None, font_size: int = None,
                      bold: bool = None, italic: bool = None, color: str = None):
        """Add a paragraph to a Word document with optional formatting.

        Args:
            filename: Path to Word document
            text: Paragraph text content
            style: Optional paragraph style name
            font_name: Font family (e.g., 'Helvetica', 'Times New Roman')
            font_size: Font size in points (e.g., 14, 36)
            bold: Make text bold
            italic: Make text italic
            color: Text color as hex RGB (e.g., '000000')
        """
        return content_tools.add_paragraph(filename, text, style, font_name, font_size, bold, italic, color)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Add Heading",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def add_heading(filename: str, text: str, level: int = 1,
                    font_name: str = None, font_size: int = None,
                    bold: bool = None, italic: bool = None, border_bottom: bool = False):
        """Add a heading to a Word document with optional formatting.

        Args:
            filename: Path to Word document
            text: Heading text
            level: Heading level (1-9)
            font_name: Font family (e.g., 'Helvetica')
            font_size: Font size in points (e.g., 14)
            bold: Make heading bold
            italic: Make heading italic
            border_bottom: Add bottom border (for section headers)
        """
        return content_tools.add_heading(filename, text, level, font_name, font_size, bold, italic, border_bottom)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Add Picture",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def add_picture(filename: str, image_path: str, width: float = None):
        """Add an image to a Word document."""
        return content_tools.add_picture(filename, image_path, width)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Add Table",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def add_table(filename: str, rows: int, cols: int, data: list[list[str]] = None):
        """Add a table to a Word document."""
        return content_tools.add_table(filename, rows, cols, data)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Add Page Break",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def add_page_break(filename: str):
        """Add a page break to the document."""
        return content_tools.add_page_break(filename)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Delete Paragraph",
            destructiveHint=True,
        ),
    )
    def delete_paragraph(filename: str, paragraph_index: int):
        """Delete a paragraph from a document."""
        return content_tools.delete_paragraph(filename, paragraph_index)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Search and Replace",
            destructiveHint=True,
        ),
    )
    def search_and_replace(filename: str, find_text: str, replace_text: str):
        """Search for text and replace all occurrences."""
        return content_tools.search_and_replace(filename, find_text, replace_text)
    
    # Format tools (styling, text formatting, etc.)
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Create Custom Style",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def create_custom_style(filename: str, style_name: str, bold: bool = None,
                          italic: bool = None, font_size: int = None,
                          font_name: str = None, color: str = None,
                          base_style: str = None):
        """Create a custom style in the document."""
        return format_tools.create_custom_style(
            filename, style_name, bold, italic, font_size, font_name, color, base_style
        )
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Format Text",
            readOnlyHint=False,
            destructiveHint=False,
        ),
        description=format_tools.format_text.__doc__,
    )
    def format_text(filename: str, paragraph_index: int, start_pos: int, end_pos: int,
                   bold: bool = None, italic: bool = None, underline: bool = None,
                   color: str = None, font_size: int = None, font_name: str = None):
        return format_tools.format_text(
            filename, paragraph_index, start_pos, end_pos, bold, italic,
            underline, color, font_size, font_name
        )
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Format Table",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def format_table(filename: str, table_index: int, has_header_row: bool = None,
                    border_style: str = None, shading: list[str] = None):
        """Format a table with borders, shading, and structure."""
        return format_tools.format_table(filename, table_index, has_header_row, border_style, shading)
    
    # New table cell shading tools
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Set Table Cell Shading",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def set_table_cell_shading(filename: str, table_index: int, row_index: int,
                              col_index: int, fill_color: str, pattern: str = "clear"):
        """Apply shading/filling to a specific table cell."""
        return format_tools.set_table_cell_shading(filename, table_index, row_index, col_index, fill_color, pattern)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Apply Alternating Row Colors",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def apply_table_alternating_rows(filename: str, table_index: int,
                                   color1: str = "FFFFFF", color2: str = "F2F2F2"):
        """Apply alternating row colors to a table for better readability."""
        return format_tools.apply_table_alternating_rows(filename, table_index, color1, color2)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Highlight Table Header",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def highlight_table_header(filename: str, table_index: int,
                             header_color: str = "4472C4", text_color: str = "FFFFFF"):
        """Apply special highlighting to table header row."""
        return format_tools.highlight_table_header(filename, table_index, header_color, text_color)
    
    # Cell merging tools
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Merge Table Cells",
            readOnlyHint=False,
            destructiveHint=True,
        ),
    )
    def merge_table_cells(filename: str, table_index: int, start_row: int, start_col: int,
                        end_row: int, end_col: int):
        """Merge cells in a rectangular area of a table."""
        return format_tools.merge_table_cells(filename, table_index, start_row, start_col, end_row, end_col)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Merge Cells Horizontally",
            readOnlyHint=False,
            destructiveHint=True,
        ),
    )
    def merge_table_cells_horizontal(filename: str, table_index: int, row_index: int,
                                   start_col: int, end_col: int):
        """Merge cells horizontally in a single row."""
        return format_tools.merge_table_cells_horizontal(filename, table_index, row_index, start_col, end_col)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Merge Cells Vertically",
            readOnlyHint=False,
            destructiveHint=True,
        ),
    )
    def merge_table_cells_vertical(filename: str, table_index: int, col_index: int,
                                 start_row: int, end_row: int):
        """Merge cells vertically in a single column."""
        return format_tools.merge_table_cells_vertical(filename, table_index, col_index, start_row, end_row)
    
    # Cell alignment tools
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Set Cell Alignment",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def set_table_cell_alignment(filename: str, table_index: int, row_index: int, col_index: int,
                               horizontal: str = "left", vertical: str = "top"):
        """Set text alignment for a specific table cell."""
        return format_tools.set_table_cell_alignment(filename, table_index, row_index, col_index, horizontal, vertical)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Set Table Alignment",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def set_table_alignment_all(filename: str, table_index: int,
                              horizontal: str = "left", vertical: str = "top"):
        """Set text alignment for all cells in a table."""
        return format_tools.set_table_alignment_all(filename, table_index, horizontal, vertical)
    
    # Protection tools
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Protect Document",
            readOnlyHint=False,
            destructiveHint=True,
        ),
    )
    def protect_document(filename: str, password: str):
        """Add password protection to a Word document."""
        return protection_tools.protect_document(filename, password)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Unprotect Document",
            readOnlyHint=False,
            destructiveHint=True,
        ),
    )
    def unprotect_document(filename: str, password: str):
        """Remove password protection from a Word document."""
        return protection_tools.unprotect_document(filename, password)
    
    # Footnote tools
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Add Footnote",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def add_footnote_to_document(filename: str, paragraph_index: int, footnote_text: str):
        """Add a footnote to a specific paragraph in a Word document."""
        return footnote_tools.add_footnote_to_document(filename, paragraph_index, footnote_text)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Add Footnote After Text",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def add_footnote_after_text(filename: str, search_text: str, footnote_text: str,
                               output_filename: str = None):
        """Add a footnote after specific text with proper superscript formatting.
        This enhanced function ensures footnotes display correctly as superscript."""
        return footnote_tools.add_footnote_after_text(filename, search_text, footnote_text, output_filename)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Add Footnote Before Text",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def add_footnote_before_text(filename: str, search_text: str, footnote_text: str,
                                output_filename: str = None):
        """Add a footnote before specific text with proper superscript formatting.
        This enhanced function ensures footnotes display correctly as superscript."""
        return footnote_tools.add_footnote_before_text(filename, search_text, footnote_text, output_filename)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Add Footnote Enhanced",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def add_footnote_enhanced(filename: str, paragraph_index: int, footnote_text: str,
                             output_filename: str = None):
        """Enhanced footnote addition with guaranteed superscript formatting.
        Adds footnote at the end of a specific paragraph with proper style handling."""
        return footnote_tools.add_footnote_enhanced(filename, paragraph_index, footnote_text, output_filename)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Add Endnote",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def add_endnote_to_document(filename: str, paragraph_index: int, endnote_text: str):
        """Add an endnote to a specific paragraph in a Word document."""
        return footnote_tools.add_endnote_to_document(filename, paragraph_index, endnote_text)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Customize Footnote Style",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def customize_footnote_style(filename: str, numbering_format: str = "1, 2, 3",
                                start_number: int = 1, font_name: str = None,
                                font_size: int = None):
        """Customize footnote numbering and formatting in a Word document."""
        return footnote_tools.customize_footnote_style(
            filename, numbering_format, start_number, font_name, font_size
        )
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Delete Footnote",
            destructiveHint=True,
        ),
    )
    def delete_footnote_from_document(filename: str, footnote_id: int = None,
                                     search_text: str = None, output_filename: str = None):
        """Delete a footnote from a Word document.
        Identify the footnote either by ID (1, 2, 3, etc.) or by searching for text near it."""
        return footnote_tools.delete_footnote_from_document(
            filename, footnote_id, search_text, output_filename
        )
    
    # Robust footnote tools - Production-ready with comprehensive validation
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Add Footnote Robust",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def add_footnote_robust(filename: str, search_text: str = None,
                           paragraph_index: int = None, footnote_text: str = "",
                           validate_location: bool = True, auto_repair: bool = False):
        """Add footnote with robust validation and Word compliance.
        This is the production-ready version with comprehensive error handling."""
        return footnote_tools.add_footnote_robust_tool(
            filename, search_text, paragraph_index, footnote_text,
            validate_location, auto_repair
        )
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Validate Footnotes",
            readOnlyHint=True,
        ),
    )
    def validate_document_footnotes(filename: str):
        """Validate all footnotes in document for coherence and compliance.
        Returns detailed report on ID conflicts, orphaned content, missing styles, etc."""
        return footnote_tools.validate_footnotes_tool(filename)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Delete Footnote Robust",
            destructiveHint=True,
        ),
    )
    def delete_footnote_robust(filename: str, footnote_id: int = None,
                              search_text: str = None, clean_orphans: bool = True):
        """Delete footnote with comprehensive cleanup and orphan removal.
        Ensures complete removal from document.xml, footnotes.xml, and relationships."""
        return footnote_tools.delete_footnote_robust_tool(
            filename, footnote_id, search_text, clean_orphans
        )
    
    # Extended document tools
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Get Paragraph Text",
            readOnlyHint=True,
        ),
    )
    def get_paragraph_text_from_document(filename: str, paragraph_index: int):
        """Get text from a specific paragraph in a Word document."""
        return extended_document_tools.get_paragraph_text_from_document(filename, paragraph_index)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Find Text",
            readOnlyHint=True,
        ),
    )
    def find_text_in_document(filename: str, text_to_find: str, match_case: bool = True,
                             whole_word: bool = False):
        """Find occurrences of specific text in a Word document."""
        return extended_document_tools.find_text_in_document(
            filename, text_to_find, match_case, whole_word
        )
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Get Highlighted Text",
            readOnlyHint=True,
        ),
    )
    def get_highlighted_text(filename: str, color: str = None):
        """Extract all highlighted/colored text from a Word document, including text inside tables."""
        return extended_document_tools.get_highlighted_text_from_document(filename, color)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Convert to PDF",
            destructiveHint=True,
        ),
    )
    def convert_to_pdf(filename: str, output_filename: str = None):
        """Convert a Word document to PDF format."""
        return extended_document_tools.convert_to_pdf(filename, output_filename)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Replace Block Below Header",
            readOnlyHint=False,
            destructiveHint=True,
        ),
    )
    def replace_paragraph_block_below_header(filename: str, header_text: str, new_paragraphs: list[str], detect_block_end_fn: str = None):
        """Reemplaza el bloque de párrafos debajo de un encabezado, evitando modificar TOC."""
        return replace_paragraph_block_below_header_tool(filename, header_text, new_paragraphs, detect_block_end_fn)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Replace Block Between Anchors",
            readOnlyHint=False,
            destructiveHint=True,
        ),
    )
    def replace_block_between_manual_anchors(filename: str, start_anchor_text: str, new_paragraphs: list[str], end_anchor_text: str = None, match_fn: str = None, new_paragraph_style: str = None):
        """Replace all content between start_anchor_text and end_anchor_text (or next logical header if not provided)."""
        return replace_block_between_manual_anchors_tool(filename, start_anchor_text, new_paragraphs, end_anchor_text, match_fn, new_paragraph_style)

    # Comment tools
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Get All Comments",
            readOnlyHint=True,
        ),
    )
    def get_all_comments(filename: str):
        """Extract all comments from a Word document."""
        return comment_tools.get_all_comments(filename)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Get Comments by Author",
            readOnlyHint=True,
        ),
    )
    def get_comments_by_author(filename: str, author: str):
        """Extract comments from a specific author in a Word document."""
        return comment_tools.get_comments_by_author(filename, author)
    
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Get Comments for Paragraph",
            readOnlyHint=True,
        ),
    )
    def get_comments_for_paragraph(filename: str, paragraph_index: int):
        """Extract comments for a specific paragraph in a Word document."""
        return comment_tools.get_comments_for_paragraph(filename, paragraph_index)
    # Comment write tools
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Add Comment",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def add_comment(filename: str, target_text: str, comment_text: str,
                    author: str = DEFAULT_AUTHOR, initials: str = DEFAULT_INITIALS):
        """Add a comment to a Word document anchored to specific text.
        The comment will appear in Word's Review panel attached to the target text.

        Args:
            filename: Path to Word document
            target_text: Text in the document to attach the comment to
            comment_text: The comment content
            author: Comment author name (env: MCP_AUTHOR)
            initials: Author initials (env: MCP_AUTHOR_INITIALS)
        """
        return comment_write_tools.add_comment(filename, target_text, comment_text, author, initials)

    # Hyperlink tools
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Manage Hyperlinks",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def manage_hyperlinks(filename: str, action: str = "add", text: str = "",
                          url: str = "", paragraph_index: int = None):
        """Add or manage hyperlinks in a Word document.
        Finds the specified text and converts it to a clickable hyperlink with blue underline.

        Args:
            filename: Path to Word document
            action: Action to perform ("add" to add a hyperlink)
            text: Text to convert to a hyperlink
            url: URL the hyperlink should point to
            paragraph_index: If specified, only search in this paragraph (0-based)
        """
        return hyperlink_tools.manage_hyperlinks(filename, action, text, url, paragraph_index)

    # New table column width tools
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Set Column Width",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def set_table_column_width(filename: str, table_index: int, col_index: int,
                              width: float, width_type: str = "points"):
        """Set the width of a specific table column."""
        return format_tools.set_table_column_width(filename, table_index, col_index, width, width_type)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Set Column Widths",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def set_table_column_widths(filename: str, table_index: int, widths: list[float],
                               width_type: str = "points"):
        """Set the widths of multiple table columns."""
        return format_tools.set_table_column_widths(filename, table_index, widths, width_type)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Set Table Width",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def set_table_width(filename: str, table_index: int, width: float,
                       width_type: str = "points"):
        """Set the overall width of a table."""
        return format_tools.set_table_width(filename, table_index, width, width_type)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Auto-Fit Table Columns",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def auto_fit_table_columns(filename: str, table_index: int):
        """Set table columns to auto-fit based on content."""
        return format_tools.auto_fit_table_columns(filename, table_index)

    # New table cell text formatting and padding tools
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Format Cell Text",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def format_table_cell_text(filename: str, table_index: int, row_index: int, col_index: int,
                               text_content: str = None, bold: bool = None, italic: bool = None,
                               underline: bool = None, color: str = None, font_size: int = None,
                               font_name: str = None):
        """Format text within a specific table cell."""
        return format_tools.format_table_cell_text(filename, table_index, row_index, col_index,
                                                   text_content, bold, italic, underline, color, font_size, font_name)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Set Cell Padding",
            readOnlyHint=False,
            destructiveHint=False,
        ),
    )
    def set_table_cell_padding(filename: str, table_index: int, row_index: int, col_index: int,
                               top: float = None, bottom: float = None, left: float = None,
                               right: float = None, unit: str = "points"):
        """Set padding/margins for a specific table cell."""
        return format_tools.set_table_cell_padding(filename, table_index, row_index, col_index,
                                                   top, bottom, left, right, unit)



    # Tracked changes tools
    @mcp.tool(
        annotations=ToolAnnotations(
            title="Track Replace",
            destructiveHint=True,
        ),
        description=tracked_changes_tools.track_replace.__doc__,
    )
    def track_replace(filename: str, old_text: str, new_text: str, author: str = DEFAULT_AUTHOR):
        return tracked_changes_tools.track_replace(filename, old_text, new_text, author)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Track Insert",
            destructiveHint=True,
        ),
        description=tracked_changes_tools.track_insert.__doc__,
    )
    def track_insert(filename: str, after_text: str, insert_text: str, author: str = DEFAULT_AUTHOR):
        return tracked_changes_tools.track_insert(filename, after_text, insert_text, author)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Track Delete",
            destructiveHint=True,
        ),
        description=tracked_changes_tools.track_delete.__doc__,
    )
    def track_delete(filename: str, text: str, author: str = DEFAULT_AUTHOR):
        return tracked_changes_tools.track_delete(filename, text, author)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="List Tracked Changes",
            readOnlyHint=True,
        ),
    )
    def list_tracked_changes(filename: str):
        """List all tracked changes (insertions and deletions) in a Word document.
        Returns author, date, text, and paragraph context for each change."""
        return tracked_changes_tools.list_tracked_changes(filename)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Accept Tracked Changes",
            destructiveHint=True,
        ),
    )
    def accept_tracked_changes(filename: str, author: str = None, change_ids: list[int] = None):
        """Accept tracked changes: apply insertions (keep text) and remove deletions.
        Optionally filter by author or specific change IDs."""
        return tracked_changes_tools.accept_tracked_changes(filename, author, change_ids)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Reject Tracked Changes",
            destructiveHint=True,
        ),
    )
    def reject_tracked_changes(filename: str, author: str = None, change_ids: list[int] = None):
        """Reject tracked changes: remove insertions and restore deleted text.
        Optionally filter by author or specific change IDs."""
        return tracked_changes_tools.reject_tracked_changes(filename, author, change_ids)

    # --- Live editing tools (Windows only, requires Word running) ---

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Screen Capture",
            readOnlyHint=True,
        ),
    )
    def word_screen_capture(filename: str = None, output_path: str = None):
        """[Windows only] Capture a screenshot of a Word document window.
        Returns the path to the saved PNG image. Requires Word to be running."""
        return screen_capture_tools.word_screen_capture(filename, output_path)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Insert Text",
            destructiveHint=True,
        ),
    )
    def word_live_insert_text(
        filename: str = None,
        text: str = "",
        position: str = "end",
        bookmark: str = None,
        track_changes: bool = False,
    ):
        """[Windows only] Insert text into a Word document that is open in Word.
        Position: 'start', 'end', 'cursor', or character offset. Requires Word running."""
        return live_tools.word_live_insert_text(
            filename, text, position, bookmark, track_changes
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Format Text",
            destructiveHint=True,
        ),
        description=live_tools.word_live_format_text.__doc__,
    )
    def word_live_format_text(
        filename: str = None,
        start: int = None,
        end: int = None,
        start_paragraph: int = None,
        end_paragraph: int = None,
        bold: bool = None,
        italic: bool = None,
        underline: bool = None,
        strikethrough: bool = None,
        font_name: str = None,
        font_size: float = None,
        font_color: str = None,
        highlight_color: int = None,
        style_name: str = None,
        paragraph_alignment: str = None,
        page_break_before: bool = None,
        preserve_direct_formatting: bool = False,
        track_changes: bool = False,
    ):
        return live_tools.word_live_format_text(
            filename, start, end, start_paragraph, end_paragraph,
            bold, italic, underline, strikethrough,
            font_name, font_size, font_color, highlight_color,
            style_name, paragraph_alignment, page_break_before,
            preserve_direct_formatting, track_changes,
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Replace Text",
            destructiveHint=True,
        ),
        description=live_tools.word_live_replace_text.__doc__,
    )
    def word_live_replace_text(
        filename: str = None,
        find_text: str = "",
        replace_text: str = "",
        match_case: bool = False,
        match_whole_word: bool = False,
        use_wildcards: bool = False,
        replace_all: bool = True,
        track_changes: bool = False,
    ):
        return live_tools.word_live_replace_text(
            filename, find_text, replace_text, match_case,
            match_whole_word, use_wildcards, replace_all, track_changes,
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Insert Paragraphs",
            destructiveHint=True,
        ),
        description=live_tools.word_live_insert_paragraphs.__doc__,
    )
    def word_live_insert_paragraphs(
        filename: str = None,
        paragraphs: list = None,
        target_text: str = None,
        target_paragraph_index: int = None,
        position: str = "after",
        style: str = None,
        track_changes: bool = False,
    ):
        return live_tools.word_live_insert_paragraphs(
            filename, paragraphs, target_text, target_paragraph_index,
            position, style, track_changes,
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Add Table",
            destructiveHint=True,
        ),
    )
    def word_live_add_table(
        filename: str = None,
        rows: int = 2,
        cols: int = 2,
        position: str = "end",
        data: list = None,
        style: str = "Table Grid",
        autofit: str = "window",
        track_changes: bool = False,
    ):
        """[Windows only] Add a table to a Word document open in Word.
        Optionally provide data as 2D list. Default style is 'Table Grid' with
        autofit to window width. Set style=None for no style, autofit=None for
        legacy fixed behavior. Requires Word running."""
        return live_tools.word_live_add_table(
            filename, rows, cols, position, data, style, autofit, track_changes
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Format Table",
            destructiveHint=True,
        ),
        description=live_tools.word_live_format_table.__doc__,
    )
    def word_live_format_table(
        filename: str = None,
        table_index: int = -1,
        border_style: str = None,
        cell_bold: list = None,
        cell_alignment: list = None,
        column_widths: list = None,
        table_alignment: str = None,
        cell_shading: list = None,
        autofit: str = None,
    ):
        return live_tools.word_live_format_table(
            filename, table_index, border_style, cell_bold, cell_alignment,
            column_widths, table_alignment, cell_shading, autofit
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Modify Table",
            destructiveHint=True,
        ),
        description=live_tools.word_live_modify_table.__doc__,
    )
    def word_live_modify_table(
        filename: str = None,
        table_index: int = 1,
        operation: str = "get_info",
        row: int = None,
        col: int = None,
        text: str = None,
        before_row: int = None,
        before_col: int = None,
        header: str = None,
        cells: list = None,
        start_row: int = None,
        start_col: int = None,
        end_row: int = None,
        end_col: int = None,
        autofit_mode: str = "content",
        accept_revisions: bool = False,
        track_changes: bool = False,
    ):
        return live_tools.word_live_modify_table(
            filename, table_index, operation, row, col, text,
            before_row, before_col, header, cells,
            start_row, start_col, end_row, end_col,
            autofit_mode, accept_revisions, track_changes,
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Delete Text",
            destructiveHint=True,
        ),
    )
    def word_live_delete_text(
        filename: str = None,
        start: int = None,
        end: int = None,
        track_changes: bool = False,
    ):
        """[Windows only] Delete text from a Word document open in Word.
        Specify start/end character positions. Requires Word running."""
        return live_tools.word_live_delete_text(
            filename, start, end, track_changes
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Apply List",
            destructiveHint=True,
        ),
        description=live_tools.word_live_apply_list.__doc__,
    )
    def word_live_apply_list(
        filename: str = None,
        start_paragraph: int = None,
        end_paragraph: int = None,
        list_type: str = "bullet",
        level: int = 0,
        remove: bool = False,
        continue_previous: bool = False,
        number_format: dict = None,
        number_style: dict = None,
        start_at: dict = None,
        level_map: dict = None,
        track_changes: bool = False,
    ):
        return live_tools.word_live_apply_list(
            filename, start_paragraph, end_paragraph, list_type,
            level, remove, continue_previous, number_format,
            number_style, start_at, level_map, track_changes,
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Setup Heading Numbering",
            destructiveHint=True,
        ),
        description=live_tools.word_live_setup_heading_numbering.__doc__,
    )
    def word_live_setup_heading_numbering(
        filename: str = None,
        h1_paragraphs: list = None,
        h2_paragraphs: list = None,
        strip_manual_numbers: bool = True,
        h1_number_format: str = None,
        h2_number_format: str = None,
        font_name: str = None,
        h1_size: float = None,
        h2_size: float = None,
        bold: bool = None,
        alignment: str = None,
        font_color: str = None,
        h1_space_before: float = None,
        h1_space_after: float = None,
        h2_space_before: float = None,
        h2_space_after: float = None,
        line_spacing: float = None,
    ):
        return live_tools.word_live_setup_heading_numbering(
            filename, h1_paragraphs, h2_paragraphs, strip_manual_numbers,
            h1_number_format, h2_number_format,
            font_name, h1_size, h2_size, bold, alignment, font_color,
            h1_space_before, h1_space_after, h2_space_before, h2_space_after,
            line_spacing,
        )

    # --- Live read tools (Windows only, requires Word running) ---

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Get Text",
            readOnlyHint=True,
        ),
    )
    def word_live_get_text(filename: str = None):
        """[Windows only] Get all text from a Word document open in Word, paragraph by paragraph. For large documents (200+ paragraphs), automatically returns only the first 3 pages — use word_live_get_page_text to read specific pages."""
        return live_read_tools.word_live_get_text(filename)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Take Snapshot",
            readOnlyHint=True,
        ),
    )
    def word_live_take_snapshot(filename: str = None):
        """[Windows only] Store a snapshot of the current document text for later diffing without returning the full text. Use word_live_get_diff afterwards to see what changed."""
        return live_read_tools.word_live_take_snapshot(filename)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Get Diff",
            readOnlyHint=True,
        ),
    )
    def word_live_get_diff(filename: str = None):
        """[Windows only] Return only paragraphs that changed since the last snapshot. Compares current document against snapshot from word_live_take_snapshot. Returns added, modified, deleted paragraphs. Automatically updates snapshot after diffing."""
        return live_read_tools.word_live_get_diff(filename)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Snapshot Status",
            readOnlyHint=True,
        ),
    )
    def word_live_snapshot_status(filename: str = None):
        """[Windows only] Check whether a snapshot exists for the document and how old it is. Returns has_snapshot, age_seconds, and paragraph_count."""
        return live_read_tools.word_live_snapshot_status(filename)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Get Paragraph Format",
            readOnlyHint=True,
        ),
        description=live_read_tools.word_live_get_paragraph_format.__doc__,
    )
    def word_live_get_paragraph_format(
        filename: str = None,
        start_paragraph: int = None,
        end_paragraph: int = None,
        include_runs: bool = False,
    ):
        return live_read_tools.word_live_get_paragraph_format(
            filename, start_paragraph, end_paragraph, include_runs,
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Get Info",
            readOnlyHint=True,
        ),
    )
    def word_live_get_info(filename: str = None):
        """[Windows only] Get document info (pages, words, sections, etc.) from a Word document open in Word. Requires Word running."""
        return live_read_tools.word_live_get_info(filename)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live List Open",
            readOnlyHint=True,
        ),
    )
    def word_live_list_open():
        """[Windows only] List all documents currently open in Word with name, path, pages, and saved status."""
        return live_read_tools.word_live_list_open()

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Find Text",
            readOnlyHint=True,
        ),
    )
    def word_live_find_text(
        filename: str = None,
        search_text: str = "",
        match_case: bool = False,
        whole_word: bool = False,
        use_wildcards: bool = False,
        context_chars: int = 60,
        max_results: int = 50,
    ):
        """[Windows only] Find text in a Word document open in Word. Returns positions and context.
        With use_wildcards=True, supports ^m (page break), ^t (tab), ^p (paragraph mark) and Word wildcards.
        context_chars controls how many characters of surrounding context to return (default 60). Requires Word running."""
        return live_read_tools.word_live_find_text(
            filename, search_text, match_case, whole_word,
            use_wildcards, context_chars, max_results,
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Get Comments",
            readOnlyHint=True,
        ),
    )
    def word_live_get_comments(filename: str = None):
        """[Windows only] Get all comments from a Word document open in Word. Requires Word running."""
        return live_read_tools.word_live_get_comments(filename)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Add Comment",
            destructiveHint=True,
        ),
    )
    def word_live_add_comment(
        filename: str = None,
        start: int = None,
        end: int = None,
        paragraph_index: int = None,
        text: str = "",
        author: str = DEFAULT_AUTHOR,
    ):
        """[Windows only] Add a comment to a Word document open in Word.
        Specify start/end character positions or paragraph_index (1-indexed). Requires Word running."""
        return live_read_tools.word_live_add_comment(
            filename, start, end, paragraph_index, text, author
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Reply to Comment",
            destructiveHint=True,
        ),
    )
    def word_live_reply_to_comment(
        filename: str = None,
        comment_index: int = None,
        text: str = "",
        author: str = DEFAULT_AUTHOR,
    ):
        """[Windows only] Reply to an existing comment in a Word document open in Word.
        Adds a threaded reply. Use word_live_get_comments to find the comment_index.
        Requires Word 2016+ running."""
        return live_read_tools.word_live_reply_to_comment(
            filename, comment_index, text, author
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Resolve Comment",
            destructiveHint=True,
        ),
    )
    def word_live_resolve_comment(
        filename: str = None,
        comment_index: int = None,
        resolve: bool = True,
    ):
        """[Windows only] Resolve or unresolve a comment in a Word document open in Word.
        Sets the comment's Done property. Use word_live_get_comments to find comment_index.
        Requires Word 2016+ running."""
        return live_read_tools.word_live_resolve_comment(
            filename, comment_index, resolve
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Delete Comment",
            destructiveHint=True,
        ),
    )
    def word_live_delete_comment(
        filename: str = None,
        comment_index: int = None,
    ):
        """[Windows only] Delete a comment from a Word document open in Word.
        Permanently removes the comment. Use word_live_get_comments to find comment_index.
        Requires Word running."""
        return live_read_tools.word_live_delete_comment(
            filename, comment_index
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live List Revisions",
            readOnlyHint=True,
        ),
    )
    def word_live_list_revisions(filename: str = None):
        """[Windows only] List all tracked changes (revisions) in a Word document open in Word. Requires Word running."""
        return live_read_tools.word_live_list_revisions(filename)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Accept Revisions",
            destructiveHint=True,
        ),
    )
    def word_live_accept_revisions(
        filename: str = None,
        author: str = None,
        revision_ids: list[int] = None,
    ):
        """[Windows only] Accept tracked changes in a Word document open in Word.
        Filter by author or specific revision IDs. Requires Word running."""
        return live_read_tools.word_live_accept_revisions(
            filename, author, revision_ids
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Reject Revisions",
            destructiveHint=True,
        ),
    )
    def word_live_reject_revisions(
        filename: str = None,
        author: str = None,
        revision_ids: list[int] = None,
    ):
        """[Windows only] Reject tracked changes in a Word document open in Word.
        Filter by author or specific revision IDs. Requires Word running."""
        return live_read_tools.word_live_reject_revisions(
            filename, author, revision_ids
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Get Page Text",
            readOnlyHint=True,
        ),
        description=live_read_tools.word_live_get_page_text.__doc__,
    )
    def word_live_get_page_text(
        filename: str = None,
        page: int = 1,
        end_page: int = None,
    ):
        return live_read_tools.word_live_get_page_text(
            filename, page, end_page,
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Get Undo History",
            readOnlyHint=True,
        ),
    )
    def word_live_get_undo_history(filename: str = None):
        """[Windows only] Get the undo stack from a Word document open in Word.
        Shows MCP tool operations as named entries. Requires Word running."""
        return live_read_tools.word_live_get_undo_history(filename)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Undo",
            destructiveHint=True,
        ),
    )
    def word_live_undo(
        filename: str = None,
        times: int = 1,
    ):
        """[Windows only] Undo the last N operations in a Word document open in Word.
        Each MCP tool call is one undo entry. Requires Word running."""
        return live_tools.word_live_undo(filename, times)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Save",
            destructiveHint=True,
        ),
    )
    def word_live_save(
        filename: str = None,
        save_as: str = None,
    ):
        """[Windows only] Save a Word document open in Word.
        Optionally save to a new path with save_as. Requires Word running."""
        return live_tools.word_live_save(filename, save_as)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Toggle Track Changes",
            destructiveHint=True,
        ),
    )
    def word_live_toggle_track_changes(
        filename: str = None,
        enable: bool = None,
    ):
        """[Windows only] Toggle or set Track Changes mode on a Word document.
        If enable is omitted, toggles current state. Requires Word running."""
        return live_tools.word_live_toggle_track_changes(filename, enable)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Insert Image",
            destructiveHint=True,
        ),
        description=live_tools.word_live_insert_image.__doc__,
    )
    def word_live_insert_image(
        filename: str = None,
        image_path: str = "",
        paragraph_index: int = None,
        position: str = "end",
        width_inches: float = None,
        height_inches: float = None,
        width_pt: float = None,
        height_pt: float = None,
        alignment: str = None,
        wrapping: str = None,
        border_style: str = None,
        border_width_pt: float = None,
        border_color: str = None,
        link_to_file: bool = False,
    ):
        return live_tools.word_live_insert_image(
            filename, image_path, paragraph_index, position,
            width_inches, height_inches, width_pt, height_pt,
            alignment, wrapping, border_style, border_width_pt,
            border_color, link_to_file
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Insert Cross Reference",
            destructiveHint=True,
        ),
    )
    def word_live_insert_cross_reference(
        filename: str = None,
        ref_type: str = "heading",
        ref_item: int = 1,
        ref_kind: str = "text",
        insert_position: str = "end",
        paragraph_index: int = None,
        insert_as_hyperlink: bool = True,
    ):
        """[Windows only] Insert a cross-reference to a heading, bookmark, figure, table, etc.
        First use word_live_list_cross_reference_items to discover available targets.
        ref_type: heading, bookmark, figure, table, equation, footnote, endnote.
        ref_kind: text, number, number_no_context, page, above_below.
        Requires Word running."""
        return live_tools.word_live_insert_cross_reference(
            filename, ref_type, ref_item, ref_kind,
            insert_position, paragraph_index, insert_as_hyperlink
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live List Cross Reference Items",
            readOnlyHint=True,
        ),
    )
    def word_live_list_cross_reference_items(
        filename: str = None,
        ref_type: str = "heading",
    ):
        """[Windows only] List available cross-reference targets in a Word document.
        Returns items that can be referenced with word_live_insert_cross_reference.
        ref_type: heading, bookmark, figure, table, equation, footnote, endnote.
        Requires Word running."""
        return live_tools.word_live_list_cross_reference_items(filename, ref_type)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Insert Equation",
            destructiveHint=True,
        ),
    )
    def word_live_insert_equation(
        filename: str = None,
        equation: str = "",
        paragraph_index: int = None,
        position: str = "end",
        display_mode: bool = False,
    ):
        """[Windows only] Insert a mathematical equation into a Word document using UnicodeMath syntax.
        Examples: "x^2 + y^2 = z^2", "(a+b)/(c+d)" (fraction), "\\sqrt(x^2+y^2)" (root),
        "\\alpha + \\beta" (Greek), "\\int_0^\\infty e^(-x^2) dx" (integral),
        "\\sum_(i=1)^n i^2" (summation), "\\matrix(a&b@c&d)" (matrix).
        display_mode=True centers the equation on its own line.
        Requires Word running."""
        return live_tools.word_live_insert_equation(
            filename, equation, paragraph_index, position, display_mode
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Diagnose Layout",
            readOnlyHint=True,
        ),
        description=live_read_tools.word_live_diagnose_layout.__doc__,
    )
    def word_live_diagnose_layout(filename: str = None):
        return live_read_tools.word_live_diagnose_layout(filename)

    # --- Live layout tools (Windows only, requires Word running) ---

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Set Page Layout",
            destructiveHint=True,
        ),
    )
    def word_live_set_page_layout(
        filename: str = None,
        section_index: int = 1,
        orientation: str = None,
        page_width_inches: float = None,
        page_height_inches: float = None,
        margin_top_inches: float = None,
        margin_bottom_inches: float = None,
        margin_left_inches: float = None,
        margin_right_inches: float = None,
    ):
        """[Windows only] Set page layout (orientation, size, margins) for a section in a Word document open in Word. Requires Word running."""
        return live_layout_tools.word_live_set_page_layout(
            filename, section_index, orientation,
            page_width_inches, page_height_inches,
            margin_top_inches, margin_bottom_inches,
            margin_left_inches, margin_right_inches,
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Add Header/Footer",
            destructiveHint=True,
        ),
    )
    def word_live_add_header_footer(
        filename: str = None,
        section_index: int = 1,
        header_text: str = None,
        footer_text: str = None,
        header_alignment: str = "center",
        footer_alignment: str = "center",
    ):
        """[Windows only] Add header and/or footer to a section in a Word document open in Word. Requires Word running."""
        return live_layout_tools.word_live_add_header_footer(
            filename, section_index, header_text, footer_text,
            header_alignment, footer_alignment,
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Add Page Numbers",
            destructiveHint=True,
        ),
    )
    def word_live_add_page_numbers(
        filename: str = None,
        section_index: int = 1,
        position: str = "footer",
        alignment: str = "center",
        prefix: str = "",
        suffix: str = "",
        include_total: bool = False,
    ):
        """[Windows only] Add page numbers to header or footer in a Word document open in Word. Requires Word running."""
        return live_layout_tools.word_live_add_page_numbers(
            filename, section_index, position, alignment,
            prefix, suffix, include_total,
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Add Section Break",
            destructiveHint=True,
        ),
    )
    def word_live_add_section_break(
        filename: str = None,
        break_type: str = "new_page",
    ):
        """[Windows only] Add a section break (new_page, continuous, even_page, odd_page) to a Word document open in Word. Requires Word running."""
        return live_layout_tools.word_live_add_section_break(
            filename, break_type,
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Set Paragraph Spacing",
            destructiveHint=True,
        ),
    )
    def word_live_set_paragraph_spacing(
        filename: str = None,
        paragraph_index: int = None,
        start_paragraph: int = None,
        end_paragraph: int = None,
        space_before_pt: float = None,
        space_after_pt: float = None,
        line_spacing: float = None,
        line_spacing_rule: str = None,
        keep_with_next: bool = None,
        keep_together: bool = None,
        alignment: str = None,
    ):
        """[Windows only] Set paragraph spacing and layout properties in a Word document open in Word. Paragraphs are 1-indexed. Requires Word running."""
        return live_layout_tools.word_live_set_paragraph_spacing(
            filename, paragraph_index, start_paragraph, end_paragraph,
            space_before_pt, space_after_pt, line_spacing, line_spacing_rule,
            keep_with_next, keep_together, alignment,
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Add Bookmark",
            destructiveHint=True,
        ),
    )
    def word_live_add_bookmark(
        filename: str = None,
        paragraph_index: int = 1,
        bookmark_name: str = "",
    ):
        """[Windows only] Add a named bookmark at a paragraph in a Word document open in Word.
        Paragraph is 1-indexed. Requires Word running."""
        return live_layout_tools.word_live_add_bookmark(
            filename, paragraph_index, bookmark_name,
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Word Live Add Watermark",
            destructiveHint=True,
        ),
    )
    def word_live_add_watermark(
        filename: str = None,
        text: str = "TASLAK",
        font_size: int = 72,
        font_color: str = "C0C0C0",
        rotation: int = -45,
        section_index: int = 1,
    ):
        """[Windows only] Add a diagonal text watermark to a Word document open in Word. Requires Word running."""
        return live_layout_tools.word_live_add_watermark(
            filename, text, font_size, font_color, rotation, section_index,
        )

    # --- Layout, header/footer, spacing, bookmark, watermark tools ---

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Set Page Layout",
            destructiveHint=True,
        ),
    )
    def set_page_layout(
        filename: str,
        section_index: int = 0,
        orientation: str = None,
        page_width_inches: float = None,
        page_height_inches: float = None,
        margin_top_inches: float = None,
        margin_bottom_inches: float = None,
        margin_left_inches: float = None,
        margin_right_inches: float = None,
    ):
        """Set page layout (orientation, size, margins) for a document section."""
        return layout_tools.set_page_layout(
            filename, section_index, orientation,
            page_width_inches, page_height_inches,
            margin_top_inches, margin_bottom_inches,
            margin_left_inches, margin_right_inches,
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Add Header/Footer",
            destructiveHint=True,
        ),
    )
    def add_header_footer(
        filename: str,
        section_index: int = 0,
        header_text: str = None,
        footer_text: str = None,
        header_alignment: str = "center",
        footer_alignment: str = "center",
    ):
        """Add header and/or footer text to a document section."""
        return layout_tools.add_header_footer(
            filename, section_index, header_text, footer_text,
            header_alignment, footer_alignment,
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Add Page Numbers",
            destructiveHint=True,
        ),
    )
    def add_page_numbers(
        filename: str,
        section_index: int = 0,
        position: str = "footer",
        alignment: str = "center",
        prefix: str = "",
        suffix: str = "",
        include_total: bool = False,
    ):
        """Add page numbers to header or footer using PAGE/NUMPAGES fields."""
        return layout_tools.add_page_numbers(
            filename, section_index, position, alignment,
            prefix, suffix, include_total,
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Add Section Break",
            destructiveHint=True,
        ),
    )
    def add_section_break(filename: str, break_type: str = "new_page"):
        """Add a section break (new_page, continuous, even_page, odd_page)."""
        return layout_tools.add_section_break(filename, break_type)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Set Paragraph Spacing",
            destructiveHint=True,
        ),
    )
    def set_paragraph_spacing(
        filename: str,
        paragraph_index: int = None,
        start_paragraph: int = None,
        end_paragraph: int = None,
        space_before_pt: float = None,
        space_after_pt: float = None,
        line_spacing: float = None,
        line_spacing_rule: str = None,
    ):
        """Set paragraph spacing (before/after/line) for one or a range of paragraphs.
        line_spacing_rule: single, 1.5_lines, double, exactly, at_least, multiple."""
        return layout_tools.set_paragraph_spacing(
            filename, paragraph_index, start_paragraph, end_paragraph,
            space_before_pt, space_after_pt, line_spacing, line_spacing_rule,
        )

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Add Bookmark",
            destructiveHint=True,
        ),
    )
    def add_bookmark(filename: str, paragraph_index: int, bookmark_name: str):
        """Add a named bookmark at a paragraph for cross-referencing."""
        return layout_tools.add_bookmark(filename, paragraph_index, bookmark_name)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Add Watermark",
            destructiveHint=True,
        ),
    )
    def add_watermark(
        filename: str,
        text: str = "TASLAK",
        font_size: int = 72,
        font_color: str = "C0C0C0",
        rotation: int = -45,
        section_index: int = 0,
    ):
        """Add a diagonal text watermark (e.g. TASLAK, GİZLİ, DRAFT) to a document."""
        return layout_tools.add_watermark(
            filename, text, font_size, font_color, rotation, section_index,
        )

    # --- Previously unregistered existing tools ---

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Add Table of Contents",
            destructiveHint=True,
        ),
    )
    def add_table_of_contents(filename: str, title: str = "Table of Contents", max_level: int = 3):
        """Add a table of contents based on heading styles."""
        return content_tools.add_table_of_contents(filename, title, max_level)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Merge Documents",
            destructiveHint=True,
        ),
    )
    def merge_documents(target_filename: str, source_filenames: list[str], add_page_breaks: bool = True):
        """Merge multiple Word documents into a single target document."""
        return document_tools.merge_documents(target_filename, source_filenames, add_page_breaks)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Add Restricted Editing",
            destructiveHint=True,
        ),
    )
    def add_restricted_editing(filename: str, password: str, editable_sections: list[str]):
        """Add restricted editing to a document, allowing editing only in specified sections."""
        return protection_tools.add_restricted_editing(filename, password, editable_sections)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Add Digital Signature",
            destructiveHint=True,
        ),
    )
    def add_digital_signature(filename: str, signer_name: str, reason: str = None):
        """Add a digital signature to a Word document."""
        return protection_tools.add_digital_signature(filename, signer_name, reason)

    @mcp.tool(
        annotations=ToolAnnotations(
            title="Verify Document",
            readOnlyHint=True,
        ),
    )
    def verify_document(filename: str, password: str = None):
        """Verify document protection and/or digital signature."""
        return protection_tools.verify_document(filename, password)


def run_server():
    """Run the Word Document MCP Server with configurable transport."""
    # Get transport configuration
    config = get_transport_config()
    
    # Setup logging
    # setup_logging(config['debug'])
    
    # Monkey-patch Document.save() to preserve comments.xml and other custom parts
    from word_document_server.utils.save_utils import install_save_hook
    install_save_hook()

    # Monkey-patch PhysPkgReader to detect Word-locked files
    from word_document_server.utils.path_utils import install_path_hook
    install_path_hook()

    # Register all tools
    register_tools()
    
    # Print startup information
    transport_type = config['transport']
    print(f"Starting Word Document MCP Server with {transport_type} transport...")
    
    # if config['debug']:
    #     print(f"Configuration: {config}")
    
    try:
        if transport_type == 'stdio':
            # Run with stdio transport (default, backward compatible)
            print("Server running on stdio transport")
            mcp.run(transport='stdio')
            
        elif transport_type == 'streamable-http':
            # Run with streamable HTTP transport
            print(f"Server running on streamable-http transport at http://{config['host']}:{config['port']}{config['path']}")
            mcp.run(
                transport='streamable-http',
                host=config['host'],
                port=config['port'],
                path=config['path']
            )
            
        elif transport_type == 'sse':
            # Run with SSE transport
            print(f"Server running on SSE transport at http://{config['host']}:{config['port']}{config['sse_path']}")
            mcp.run(
                transport='sse',
                host=config['host'],
                port=config['port'],
                path=config['sse_path']
            )
            
    except KeyboardInterrupt:
        print("\nShutting down server...")
    except Exception as e:
        print(f"Error starting server: {e}")
        if config['debug']:
            import traceback
            traceback.print_exc()
        sys.exit(1)
    
    return mcp


def main():
    """Main entry point for the server."""
    run_server()


if __name__ == "__main__":
    main()
