import logging
import threading
import time
from contextlib import contextmanager, asynccontextmanager, ExitStack, AsyncExitStack

from agent_lab_sdk.core.settings import settings
from agent_lab_sdk.core.unified_semaphore import UnifiedSemaphore
from agent_lab_sdk.llm.managers.ags_token_manager import AgsTokenManager
from agent_lab_sdk.metrics.create import create_metrics

_redis_throttle_enabled = settings.REDIS_THROTTLE_ENABLED
if settings.GIGACHAT_USE_MTLS:
    _redis_throttle_enabled = False
if _redis_throttle_enabled:
    from agent_lab_sdk.llm.managers.limits_manager import get_limits_manager

logger = logging.getLogger(__name__)


def get_limiter_with_metrics(name, max_concurrency):
    in_use, waiting, wait_hist = create_metrics(name)
    return Limiting(UnifiedSemaphore(max_concurrency), name, in_use, waiting, wait_hist)


class Limiting:
    def __init__(self, internal_semaphore, model_type, in_use, waiting, wait_hist):
        self._in_use = in_use
        self._waiting = waiting
        self._wait_hist = wait_hist
        self._lock = threading.Lock()
        self._internal_semaphore = internal_semaphore
        self._model_type = model_type

        self._current_by_credential = {}
        self._waiting_by_credential = {}
        self._set_metric_value(self._in_use, "local", 0)
        self._set_metric_value(self._waiting, "local", 0)
        if _redis_throttle_enabled:
            self._limits_manager = get_limits_manager()

    def get_semaphore_keys(self, key_type, model, agent_id, credential_id):
        key = "{}_{}_{}_{}".format(key_type, model, agent_id, credential_id)
        total_key = "{}_{}".format(key_type, model)
        return key, total_key

    @staticmethod
    def _normalize_credential_id(credential_id):
        if credential_id is None:
            return "local"
        value = str(credential_id).strip()
        return value or "local"

    @staticmethod
    def _metric_with_credential(metric, credential_id):
        if metric is None:
            return None
        labelnames = getattr(metric, "_labelnames", ())
        if "credential_id" in labelnames:
            return metric.labels(credential_id=credential_id)
        return metric

    def _set_metric_value(self, metric, credential_id, value):
        metric_ref = self._metric_with_credential(metric, credential_id)
        if metric_ref is not None:
            metric_ref.set(value)

    def _observe_metric_value(self, metric, credential_id, value):
        metric_ref = self._metric_with_credential(metric, credential_id)
        if metric_ref is not None:
            metric_ref.observe(value)

    def _inc_waiting(self, credential_id):
        with self._lock:
            waiting = self._waiting_by_credential.get(credential_id, 0) + 1
            self._waiting_by_credential[credential_id] = waiting
        self._set_metric_value(self._waiting, credential_id, waiting)

    def _dec_waiting_inc_current(self, credential_id):
        with self._lock:
            waiting = max(0, self._waiting_by_credential.get(credential_id, 0) - 1)
            self._waiting_by_credential[credential_id] = waiting
            current = self._current_by_credential.get(credential_id, 0) + 1
            self._current_by_credential[credential_id] = current
        self._set_metric_value(self._waiting, credential_id, waiting)
        self._set_metric_value(self._in_use, credential_id, current)

    def _wait_hist_in_use_update(self, start, credential_id):
        elapsed = time.time() - start
        self._observe_metric_value(self._wait_hist, credential_id, elapsed)

    def _dec_current_in_use_update(self, credential_id):
        with self._lock:
            current = max(0, self._current_by_credential.get(credential_id, 0) - 1)
            self._current_by_credential[credential_id] = current
        self._set_metric_value(self._in_use, credential_id, current)

    @contextmanager
    def acquire(self, model, credential_id=None):
        metric_credential_id = self._normalize_credential_id(credential_id)
        self._inc_waiting(metric_credential_id)
        start = time.time()

        try:
            self._internal_semaphore.acquire()
            if _redis_throttle_enabled:
                logger.info("redis throttle enabled")
                with ExitStack() as stack:
                    try:
                        key, total_key = self.get_semaphore_keys(self._model_type, model, settings.AGENT_SERVICE_NAME, credential_id)
                        ags_limits = AgsTokenManager.get_token_by_env(model, credential_id)
                        stack.enter_context(self._limits_manager.with_concurrency_limit(ags_limits.total_limits, total_key))
                        stack.enter_context(self._limits_manager.with_concurrency_limit(ags_limits.limits, key))
                        self._limits_manager.with_rate_limit(ags_limits.total_limits, total_key)
                        self._limits_manager.with_rate_limit(ags_limits.limits, key)
                    finally:
                        self._dec_waiting_inc_current(metric_credential_id)
                    self._wait_hist_in_use_update(start, metric_credential_id)
                    yield
            else:
                self._dec_waiting_inc_current(metric_credential_id)
                self._wait_hist_in_use_update(start, metric_credential_id)
                yield
        finally:
            try:
                self._internal_semaphore.release()
            finally:
                self._dec_current_in_use_update(metric_credential_id)

    @asynccontextmanager
    async def acquire_async(self, model, credential_id=None):
        metric_credential_id = self._normalize_credential_id(credential_id)
        self._inc_waiting(metric_credential_id)
        start = time.time()

        try:
            await self._internal_semaphore.acquire_async()
            if _redis_throttle_enabled:
                logger.info("redis throttle enabled")
                async with AsyncExitStack() as stack:
                    try:
                        key, total_key = self.get_semaphore_keys(self._model_type, model, settings.AGENT_SERVICE_NAME, credential_id)
                        ags_limits = AgsTokenManager.get_token_by_env(model, credential_id)
                        await stack.enter_async_context(self._limits_manager.with_concurrency_limit_async(ags_limits.total_limits, total_key))
                        await stack.enter_async_context(self._limits_manager.with_concurrency_limit_async(ags_limits.limits, key))
                        await self._limits_manager.with_rate_limit_async(ags_limits.total_limits, total_key)
                        await self._limits_manager.with_rate_limit_async(ags_limits.limits, key)
                    finally:
                        self._dec_waiting_inc_current(metric_credential_id)
                    self._wait_hist_in_use_update(start, metric_credential_id)
                    yield
            else:
                self._dec_waiting_inc_current(metric_credential_id)
                self._wait_hist_in_use_update(start, metric_credential_id)
                yield
        finally:
            try:
                await self._internal_semaphore.release_async()
            finally:
                self._dec_current_in_use_update(metric_credential_id)
