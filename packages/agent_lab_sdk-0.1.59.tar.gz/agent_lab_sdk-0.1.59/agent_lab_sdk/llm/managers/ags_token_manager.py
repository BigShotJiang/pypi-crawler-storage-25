import logging
import random
import threading
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

from agent_lab_sdk.core.settings import settings, ENV_PREFIX
from agent_lab_sdk.llm.clients.agent_service_client import agent_service_client

logger = logging.getLogger(__name__)

# Случайный порог обновления токена: от 0 до 300 секунд (5 минут)
REFRESH_WINDOW_MAX = 300

@dataclass
class AgsTokenLimits:
    limits: dict
    total_limits: dict
    token: str
    metadata: dict

class AgsTokenManager:
    _thread_lock = threading.Lock()
    _tokens: dict[str, Any] = {}

    @classmethod
    def get_token(cls, agent_id: str, credential_id: str) -> dict:
        if agent_id is None or credential_id is None:
            raise ValueError("Требуются agent_id и client_id для получения токена")
        key = "{}_{}".format(agent_id, credential_id)
        with cls._thread_lock:
            cached_token = cls._tokens.get(key)
            if cached_token is not None:
                expiry_ts = cached_token["expiresAt"]
                now = datetime.now(timezone.utc)

                expiry_time = datetime.fromisoformat(expiry_ts).replace(tzinfo=timezone.utc)
                refresh_window = timedelta(seconds=random.uniform(0, REFRESH_WINDOW_MAX))
                time_left = expiry_time - now
                logger.debug("Осталось времени: %s, порог обновления: %s", time_left, refresh_window)
                if time_left > refresh_window:
                    logger.debug("Используем кэшированный токен; истекает %s", expiry_time.isoformat())
                    return cached_token

            new_token = agent_service_client.get_token(agent_id, credential_id)
            if new_token.get("expiresAt") is None:
                raise ValueError("expiresAt должен быть в ответе AGS")
            cls._tokens[key] = new_token
            return new_token

    @classmethod
    def get_token_by_env(cls, model, credential_id) -> AgsTokenLimits | None:
        if settings.GIGACHAT_USE_MTLS:
            return None
        if settings.AGENT_SERVICE_NAME is None:
            raise ValueError(f"Переменная окружения {ENV_PREFIX}AGENT_SERVICE_NAME не установлена.")
        credential_id = credential_id or settings.GIGACHAT_CREDENTIAL_ID
        if credential_id is None:
            raise ValueError(f"Переменная окружения {ENV_PREFIX}GIGACHAT_CREDENTIAL_ID не установлена.")
        model = model or settings.GIGACHAT_MODEL
        if model is None:
            raise ValueError(f"Переменная окружения {ENV_PREFIX}GIGACHAT_MODEL не установлена.")
        log_key = f"{settings.AGENT_SERVICE_NAME}_{credential_id}"
        token_info = cls.get_token(settings.AGENT_SERVICE_NAME, credential_id)
        token = cls._get_value_or_raise(token_info, "token", log_key)
        metadata = cls._get_value_or_raise(token_info, "metadata", log_key)
        cls._get_value_or_raise(metadata, "baseUrl", f"{log_key}_metadata")
        cls._get_value_or_raise(metadata, "scope", f"{log_key}_metadata")

        all_limits = cls._get_value_or_raise(token_info, "limits", log_key)
        all_total_limits = cls._get_value_or_raise(token_info, "totalLimits", log_key)
        limits = cls._get_value_or_warn(all_limits, model, log_key)
        total_limits = cls._get_value_or_warn(all_total_limits, model, f"{log_key} (total)")

        return AgsTokenLimits(limits, total_limits, token, metadata)

    @staticmethod
    def _get_value_or_warn(data_dict, name, log_key):
        value = data_dict.get(name)
        if value is None:
            logger.warning("%s model not set for creds %s", name, log_key)
        return value

    @staticmethod
    def _get_value_or_raise(data_dict, name, log_key):
        value = data_dict.get(name)
        if value is None:
            raise ValueError(f"Отсутствует поле {name} в ответе AGS key={log_key}")
        return value
