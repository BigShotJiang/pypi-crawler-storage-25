import asyncio
import logging
from contextlib import contextmanager, asynccontextmanager

from agent_lab_sdk.core.settings import settings
from agent_lab_sdk.llm.clients.redis_client import RedisClient
from agent_lab_sdk.llm.managers.redis.ratelimiter import RedisRateLimiter
from agent_lab_sdk.llm.managers.redis.semaphore import RedisSemaphore

logger = logging.getLogger(__name__)


class ConcurrencyTimeoutError(TimeoutError):
    pass

class RatelimitTimeoutError(TimeoutError):
    pass

class LimitsManager:
    def __init__(self, redis_client: RedisClient):
        self.semaphore = RedisSemaphore(redis_client)
        self.rate_limiters = {
            "rps": RedisRateLimiter(redis_client, 1),
            "rpm": RedisRateLimiter(redis_client, 60),
            "rph": RedisRateLimiter(redis_client, 60 * 60),
            "rpd": RedisRateLimiter(redis_client, 60 * 60 * 24),
        }

    @contextmanager
    def with_concurrency_limit(self, limits, key):
        if limits is None or key is None:
            yield
            return
        unique_id = None
        try:
            max_concurrency = limits.get("maxConcurrency")
            if max_concurrency is None or max_concurrency <= 0:
                logger.warning(f"maxConcurrency not set for key {key}")
                yield
                return
            unique_id = self.semaphore.acquire(
                key,
                max_concurrency,
                timeout=settings.REDIS_SEMAPHORE_TIMEOUT,
                blocking_timeout=settings.REDIS_BLOCKING_TIMEOUT
            )
            if unique_id is None:
                raise ConcurrencyTimeoutError("Concurrency semaphore acquire timeout")
            yield
        finally:
            self.semaphore.release(key, unique_id)

    @asynccontextmanager
    async def with_concurrency_limit_async(self, limits, key):
        if limits is None or key is None:
            yield
            return
        unique_id = None
        try:
            max_concurrency = limits.get("maxConcurrency")
            if max_concurrency is None or max_concurrency <= 0:
                logger.warning(f"maxConcurrency not set for key {key}")
                yield
                return
            loop = asyncio.get_running_loop()
            unique_id = await loop.run_in_executor(None, self.semaphore.acquire,
                key,
                max_concurrency,
                settings.REDIS_SEMAPHORE_TIMEOUT,
                settings.REDIS_BLOCKING_TIMEOUT
            )
            if unique_id is None:
                raise ConcurrencyTimeoutError("Concurrency semaphore acquire timeout")
            yield
        finally:
            self.semaphore.release(key, unique_id)

    def with_rate_limit(self, limits, key):
        if limits is None or key is None:
            return
        for rate_name, limiter in self.rate_limiters.items():
            rate_limit = limits.get(rate_name)
            if rate_limit is None or rate_limit <= 0:
                logger.info(f"{rate_name} rate not set for key {key}")
                continue
            available = limiter.wait_hit_available(key, rate_limit, settings.REDIS_BLOCKING_TIMEOUT)
            if not available:
                raise RatelimitTimeoutError("Rate limit acquire timeout")

    async def with_rate_limit_async(self, limits, key):
        if limits is None or key is None:
            return
        for rate_name, limiter in self.rate_limiters.items():
            rate_limit = limits.get(rate_name)
            if rate_limit is None or rate_limit <= 0:
                logger.info(f"{rate_name} rate not set for key {key}")
                continue
            loop = asyncio.get_running_loop()
            available = await loop.run_in_executor(None, limiter.wait_hit_available,
                key,
                rate_limit,
                settings.REDIS_BLOCKING_TIMEOUT
            )
            if not available:
                raise RatelimitTimeoutError("Rate limit acquire timeout")

_limits_manager = None
def get_limits_manager():
    global _limits_manager
    if _limits_manager is None:
        _redis_client = RedisClient()
        _limits_manager = LimitsManager(_redis_client)
    return _limits_manager
