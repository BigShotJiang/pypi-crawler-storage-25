import time
import logging

from agent_lab_sdk.llm.clients.redis_client import RedisClient

logger = logging.getLogger(__name__)


class RedisRateLimiter:
    """Sliding window"""
    def __init__(self, redis_client: RedisClient, interval):
        self.redis_client = redis_client
        self.interval = interval
        self.str_interval = str(interval)
        self.ratelimiter_key = f"{redis_client.redis_key_prefix}ratelimit:{{}}:{{}}"

    def wait_hit_available(self, key, limit, blocking_timeout=None):
        logger.info(f"trying to ratelimit limit={limit} key={key}, interval={self.str_interval}")
        redis_key = self.ratelimiter_key.format(self.interval, key)
        start_time = time.monotonic()
        retry_interval = 0.01

        while True:
            if self._hit(key, redis_key, limit, blocking_timeout):
                logger.info(f"ratelimited limit={limit} key={key}, interval={self.str_interval}")
                return True
            sleep_time = retry_interval
            if blocking_timeout is not None:
                elapsed = time.monotonic() - start_time
                if elapsed >= blocking_timeout:
                    return None
                sleep_time = min(retry_interval, blocking_timeout - elapsed)
            time.sleep(sleep_time)
            retry_interval = min(retry_interval * 2, 0.5)  # Макс. пауза 0.5с

    def _hit(self, key, redis_key, limit, blocking_timeout):
        with self.redis_client.redis_lock(f"{self.str_interval}:{key}", blocking_timeout) as acquired:
            if not acquired:
                return False
            redis = self.redis_client.get_redis()
            redis_time = redis.time()
            now = redis_time[0] + redis_time[1] / 1_000_000

            window_start = now - self.interval

            pipe = redis.pipeline()
            pipe.zremrangebyscore(redis_key, 0, window_start)
            pipe.zcard(redis_key)
            _, current_count = pipe.execute()

            if current_count < limit:
                pipe = redis.pipeline()
                pipe.zadd(redis_key, {str(redis_time): now})
                pipe.expire(redis_key, self.interval)
                pipe.execute()
                return True
            return False
