import time
import logging

from agent_lab_sdk.llm.clients.redis_client import RedisClient

logger = logging.getLogger(__name__)


class RedisSemaphore:
    def __init__(self, redis_client: RedisClient):
        self._redis_client = redis_client
        self.semaphore_key = f"{redis_client.redis_key_prefix}semaphore:{{}}"

    def acquire(self, key, limit, timeout, blocking_timeout=None):
        logger.info(f"try acquire {key} with limit {limit}")
        redis_key = self.semaphore_key.format(key)
        start_time = time.monotonic()
        retry_interval = 0.01

        while True:
            if (unique_id := self._do_acquire(key, redis_key, limit, timeout, blocking_timeout)) is not None:
                logger.info(f"{key} acquired")
                return unique_id
            sleep_time = retry_interval
            if blocking_timeout is not None:
                elapsed = time.monotonic() - start_time
                if elapsed >= blocking_timeout:
                    return None
                sleep_time = min(retry_interval, blocking_timeout - elapsed)
            time.sleep(sleep_time)
            retry_interval = min(retry_interval * 2, 1.0)  # Макс. пауза 1.0с

    def _do_acquire(self, key, redis_key, limit, timeout, blocking_timeout):
        with self._redis_client.redis_lock(key, blocking_timeout) as acquired:
            if not acquired:
                return None
            redis = self._redis_client.get_redis()
            redis_time = redis.time()
            now = redis_time[0] + redis_time[1] / 1_000_000
            unique_id = str(redis_time)

            window_start = now - timeout

            pipe = redis.pipeline()
            pipe.zremrangebyscore(redis_key, 0, window_start)
            pipe.zcard(redis_key)
            _, current_count = pipe.execute()

            if current_count < limit:
                pipe = redis.pipeline()
                pipe.zadd(redis_key, {unique_id: now})
                pipe.expire(redis_key, timeout)
                pipe.execute()
                return unique_id
            return None

    def release(self, key, unique_id):
        logger.info(f"releasing {key} {unique_id}")
        if unique_id is not None:
            redis_key = self.semaphore_key.format(key)
            redis = self._redis_client.get_redis()
            redis.zrem(redis_key, unique_id)

