import functools
import inspect
import logging
import uuid
from dataclasses import dataclass
from typing import Callable, Any

from gigachat.context import trace_id_cvar
from gigachat.exceptions import ResponseError
from langchain_gigachat import GigaChat, GigaChatEmbeddings
from pydantic import PrivateAttr

from agent_lab_sdk.core.settings import settings
from agent_lab_sdk.core.utils import get_trace_id

logger = logging.getLogger(__name__)

@dataclass
class GigaChatErrorContext:
    operation: str
    args: tuple
    kwargs: dict
    model: str | None
    base_url: str


def _method_wrapper(method):
    is_async = inspect.iscoroutinefunction(method)

    def call_error_handler(self, error, operation, *args, **kwargs):
        ctx = GigaChatErrorContext(operation, args, kwargs, self.model, self.base_url)
        result = self._on_request_error(error, ctx)
        logger.info(
            f"Error {error.args[1]} handled by callback. Returning fallback result."
        )
        return result

    @functools.wraps(method)
    async def async_wrapper(self, *args, **kwargs):
        trace_id = get_trace_id() or str(uuid.uuid4())
        trace_id_cvar.set(trace_id)

        try:
            return await method(self, *args, **kwargs)
        except ResponseError as e:
            _, status, _, _ = e.args

            if (
                    settings.ENABLE_HANDLE_GIGACHAT_STATUS
                    and self._on_request_error is not None
            ):
                logger.warning(
                    f"Encountered HTTP {status}. Executing 'on_request_error' handler."
                )
                try:
                    return call_error_handler(self, e, method.__name__, *args, **kwargs)
                except Exception:
                    logger.exception(
                        "Error during gigachat error handling"
                    )

            logger.error(f"GigaChat error: {e}")
            raise
        except Exception as e:
            logger.error(f"Unknown error: {e!r}")
            raise

    @functools.wraps(method)
    def sync_wrapper(self, *args, **kwargs):
        trace_id = get_trace_id() or str(uuid.uuid4())
        trace_id_cvar.set(trace_id)

        try:
            return method(self, *args, **kwargs)
        except ResponseError as e:
            _, status, _, _ = e.args

            if (
                    settings.ENABLE_HANDLE_GIGACHAT_STATUS
                    and self._on_request_error is not None
            ):
                logger.warning(
                    f"Encountered HTTP {status}. Executing 'on_request_error' handler."
                )
                try:
                    return call_error_handler(self, e, method.__name__, *args, **kwargs)
                except Exception:
                    logger.exception(
                        "Error during gigachat error handling"
                    )

            logger.error(f"GigaChat error: {e}")
            raise
        except Exception as e:
            logger.error(f"Unknown error: {e!r}")
            raise

    return async_wrapper if is_async else sync_wrapper

def wrap_gigachat_specific_methods(method_names):
    def wrap_gigachat(cls):
        for name, method in inspect.getmembers(cls, predicate=inspect.isfunction):
            if callable(method) and name in method_names:
                setattr(cls, name, _method_wrapper(method))
        return cls
    return wrap_gigachat


giga_chat_embeddings_wrap_method_names = ["embed_documents", "embed_query", "aembed_documents", "aembed_query"]
giga_chat_wrap_method_names = [
    "invoke", "ainvoke", "stream", "astream", "astream_events", "batch", "abatch",
    "upload_file", "aupload_file", "batch_as_completed", "abatch_as_completed"
]

@wrap_gigachat_specific_methods(giga_chat_wrap_method_names)
class GigaChatWrapper(GigaChat):
    _on_request_error: Callable[[ResponseError, GigaChatErrorContext], Any | None] = PrivateAttr(default=None)

    def __init__(self, *args, on_request_error=None, **kwargs):
        super().__init__(*args, **kwargs)
        self._on_request_error = on_request_error

@wrap_gigachat_specific_methods(giga_chat_embeddings_wrap_method_names)
class GigaChatEmbeddingsWrapper(GigaChatEmbeddings):
    _on_request_error: Callable[[ResponseError, GigaChatErrorContext], Any | None] = PrivateAttr(default=None)

    def __init__(self, on_request_error=None,  **kwargs):
        super().__init__(**kwargs)
        self._on_request_error = on_request_error
