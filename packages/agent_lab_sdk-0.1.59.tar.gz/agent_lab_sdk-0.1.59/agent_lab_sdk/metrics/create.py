from agent_lab_sdk.metrics import get_metric


def create_metrics(prefix: str):
    in_use = get_metric(
        metric_type = "gauge", name = f"{prefix}_slots_in_use",
        documentation = f"Number of {prefix} slots currently in use",
        labelnames=["credential_id"],
    )
    waiting = get_metric(
        metric_type = "gauge", name = f"{prefix}_waiting_tasks",
        documentation = f"Number of tasks waiting for {prefix}",
        labelnames=["credential_id"],
    )
    wait_time = get_metric(
        metric_type = "histogram", name = f"{prefix}_wait_time_seconds",
        documentation = f"Time tasks wait for {prefix}",
        labelnames=["credential_id"],
        buckets = [3, 5, 10, 15, 30, 60, 120, 240, 480, 960, 1920, float("inf")]
    )

    return in_use, waiting, wait_time
