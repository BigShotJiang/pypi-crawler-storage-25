import asyncio
import logging
import uuid
from dataclasses import dataclass
from enum import StrEnum

import httpx

from agent_lab_sdk.core.settings import settings
from agent_lab_sdk.core.utils import get_trace_id
from agent_lab_sdk.llm.limiting import get_limiter_with_metrics
from agent_lab_sdk.metrics import get_metric
import xml.etree.ElementTree as ET


logger = logging.getLogger(__name__)

_search_plugin_retrieval_error_metric = get_metric('gauge', 'search_plugin_retrieval_errors_total', "Количество ошибок Search Plugin retrieval (200 + error в response payload)")
_search_plugin_retrieval_empty_payload_metric = get_metric('gauge', 'search_plugin_retrieval_empty_payload_total', "Количество пустых ответов Search Plugin retrieval")
_search_plugin_rambler_proxy_images_error_metric = get_metric('gauge', 'search_plugin_rambler_images_proxy_errors_total', "Количество ошибок Search Plugin rambler_images_proxy (200 + error в response payload)")
_search_plugin_rambler_proxy_images_empty_payload_metric = get_metric('gauge', 'search_plugin_rambler_images_proxy_empty_payload_total', "Количество пустых ответов Search Plugin rambler_images_proxy")

_limiter = get_limiter_with_metrics("search_plugin", settings.SEARCH_PLUGIN_MAX_CONCURRENCY)


@dataclass
class RetrieveResponse:
    documents: list[dict]
    sources: dict
    images: list[dict]
    mapped_documents: list[dict]

@dataclass
class ImagesProxyResult:
    url: str
    domain: str
    thumbnail_link: str
    thumbnail_width: int
    thumbnail_height: int
    original_width: int
    original_height: int
    html_link: str
    image_link: str
    file_size: int
    mime_type: str

class SearchMode(StrEnum):
    actual_info_web_search = "actual_info_web_search"
    safe_search = "safe_search"
    web_search = "web_search"
    custom = "custom"


class SearchPlugin:
    """
    SearchPlugin Retriever
    """
    def __init__(self, base_url=None, api_key=None, query_domains=None):
        self.query_domains = query_domains or None
        self._api_key = api_key or self._get_setting_or_raise("SEARCH_PLUGIN_KEY")
        self._base_url = base_url

    def _get_setting_or_raise(self, name):
        value = getattr(settings, name, None)
        if not value:
            raise ValueError(f"SearchPlugin setting not found. Please set the {name} environment variable.")
        return value

    async def retrieval_async(self, query, search_mode, doc_text_max_len=None, docs_count=None, headers=None, body_params=None) -> RetrieveResponse:
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None,
            self.retrieval,
            query,
            search_mode,
            doc_text_max_len,
            docs_count,
            headers,
            body_params,
        )
        return result

    async def rambler_images_proxy_async(self, text, headers=None, body_params=None) -> list[ImagesProxyResult]:
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None,
            self.rambler_images_proxy,
            text,
            headers,
            body_params,
        )
        return result

    def retrieval(self, query, search_mode, doc_text_max_len=None, docs_count=None, headers=None, body_params=None) -> RetrieveResponse:
        """
        Searches the query
        Search modes: actual_info_web_search, safe_search, web_search, custom
        Returns:
        """
        with _limiter.acquire("search_plugin_retrieval"):
            return self._retrieval(query, search_mode, doc_text_max_len, docs_count, headers, body_params)

    def rambler_images_proxy(self, text, headers=None, additional_params=None) -> list[ImagesProxyResult]:
        with _limiter.acquire("search_plugin_proxy_images"):
            return self._rambler_images_proxy(text, headers, additional_params)

    def _retrieval(self, query, search_mode, doc_text_max_len=None, docs_count=None, headers=None, body_params=None) -> RetrieveResponse:
        if body_params is None:
            body_params = {}
        if headers is None:
            headers = {}
        logger.info("SearchPlugin: Searching with query {0}...".format(query))

        search_query = query
        if self.query_domains:
            # Add site:domain1 OR site:domain2 OR ... to the tools query
            search_query += " site:" + " OR site:".join(self.query_domains)

        body = {
            "query": search_query,
            "search_mode": str(search_mode),
            **body_params
        }

        headers = {
            "Authorization": f"{self._api_key}",
            "User-Agent": "agent-toolkit",
            "X-User-ID": str(uuid.uuid4()),
            "X-Client-ID": str(uuid.uuid4()),
            "X-Request-ID": str(uuid.uuid4()),
            "X-Session-ID": str(uuid.uuid4()),
            "x-trace-id": get_trace_id() or str(uuid.uuid4()),
            **headers
        }

        search_response = []
        retrieve_response = RetrieveResponse(documents=[], sources={}, images=[], mapped_documents=[])
        url = self._base_url or self._get_setting_or_raise("SEARCH_PLUGIN_URL")

        try:
            with httpx.Client() as client:
                response = client.post(
                    url=url,
                    headers=headers,
                    json=body,
                    timeout=settings.SEARCH_PLUGIN_RETRIEVAL_TIMEOUT
                )

                if response.is_success:
                    result = response.json()
                    if result.get("payload", {}).get("status") != "success":
                        _search_plugin_retrieval_error_metric.inc()
                        raise ValueError(str(result))
                    documents = result.get("payload", {}).get("documents", [])
                    if docs_count is not None:
                        documents = documents[:docs_count]
                    sources = result.get("sources", {})
                    images = result.get("payload", {}).get("images", [])

                    for doc in documents:
                        ref = str(doc.get("reference_keyword"))
                        source = sources.get(ref, {})
                        resp_body = doc.get("text", "")[:doc_text_max_len] if doc_text_max_len else doc.get("text", "")
                        search_response.append({
                            "title": source.get("title", ""),
                            "href": source.get("url", ""),
                            "body": resp_body
                        })
                    retrieve_response.documents = documents
                    retrieve_response.sources = sources
                    retrieve_response.mapped_documents = search_response
                    retrieve_response.images = images
                else:
                    logger.error(f"Failed fetching sources. Resulting in empty response.")
                    _search_plugin_retrieval_error_metric.inc()
                return retrieve_response
        except Exception as e:
            logger.exception(f"Error: {e}. Failed fetching sources. Resulting in empty response.")
            _search_plugin_retrieval_empty_payload_metric.inc()
        return retrieve_response

    def _rambler_images_proxy(self, text, headers=None, additional_params=None) -> list[ImagesProxyResult]:
        if additional_params is None:
            additional_params = {}
        if headers is None:
            headers = {}

        params = {
            "text": text,
            **additional_params
        }
        headers = {
            "Authorization": f"{self._api_key}",
            "User-Agent": "agent-toolkit",
            "x-trace-id": get_trace_id() or str(uuid.uuid4()),
            **headers
        }
        url = self._base_url or self._get_setting_or_raise("SEARCH_IMAGES_PLUGIN_URL")

        try:
            with httpx.Client(verify=True) as client:
                response = client.get(
                    url=url,
                    headers=headers,
                    params=params,
                    timeout=settings.SEARCH_PLUGIN_RAMBLER_PROXY_TIMEOUT
                )

                if response.is_success:
                    result = self._parse_images_response(response.text)
                    return result
                else:
                    logger.error(f"Failed fetching rambler proxy images. Resulting in empty response.")
                    _search_plugin_rambler_proxy_images_error_metric.inc()
                    return []
        except Exception as e:
            logger.exception(f"Error: {e}. Failed fetching  rambler proxy images. Resulting in empty response.")
            _search_plugin_rambler_proxy_images_empty_payload_metric.inc()
            return []

    def _get_text(self, parent: ET.Element, tag: str) -> str:
        """Helper to safely get text content from XML element."""
        elem = parent.find(tag)
        return elem.text if elem is not None and elem.text else ""

    def _get_int(self, parent: ET.Element, tag: str) -> int:
        """Helper to safely get integer content from XML element."""
        elem = parent.find(tag)
        try:
            return int(elem.text) if elem is not None and elem.text else 0
        except (ValueError, TypeError):
            return 0

    def _parse_images_response(self, xml_content: str) -> list[ImagesProxyResult]:
        """Parse Yandex images XML response and extract image information."""

        try:
            root = ET.fromstring(xml_content)

            images = []
            groups = root.findall(".//group")

            for group in groups:
                doc = group.find("doc")
                if doc is None:
                    continue

                url_elem = doc.find("url")
                domain_elem = doc.find("domain")

                img_props = doc.find("image-properties")
                if img_props is None:
                    continue

                try:
                    image_result = ImagesProxyResult(
                        url=url_elem.text if url_elem is not None else "",
                        domain=domain_elem.text if domain_elem is not None else "",
                        thumbnail_link=self._get_text(
                            img_props, "thumbnail-link"
                        ),
                        thumbnail_width=self._get_int(
                            img_props, "thumbnail-width"
                        ),
                        thumbnail_height=self._get_int(
                            img_props, "thumbnail-height"
                        ),
                        original_width=self._get_int(
                            img_props, "original-width"
                        ),
                        original_height=self._get_int(
                            img_props, "original-height"
                        ),
                        html_link=self._get_text(img_props, "html-link"),
                        image_link=self._get_text(img_props, "image-link"),
                        file_size=self._get_int(img_props, "file-size"),
                        mime_type=self._get_text(img_props, "mime-type"),
                    )
                    images.append(image_result)
                except Exception as e:
                    logger.exception(f"Error parsing image result: {e}")
                    continue

            return images

        except ET.ParseError as e:
            logger.exception(f"Error parsing XML: {e}")
            _search_plugin_rambler_proxy_images_empty_payload_metric.inc()
            return []
