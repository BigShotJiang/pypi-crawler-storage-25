from typing import Optional, List
from langchain_core.tools import tool
from agent_lab_sdk.tools.search_plugin.search_plugin import SearchPlugin

DEFAULT_MAX_RESULTS = 6

def _format_documents(documents: List[dict], sources: dict) -> str:
    if not documents:
        return "Search Plugin не нашёл результатов по запросу."

    lines: List[str] = []
    for index, doc in enumerate(documents, 1):
        ref = str(doc.get("reference_keyword"))
        source = sources.get(ref, {}) if sources else {}
        title = source.get("title") or "Без заголовка"
        url = source.get("url") or ""
        snippet = (doc.get("text") or "")[:5000]
        block = f"{index}. {title}\n{url}\n{snippet}".strip()
        lines.append(block)
    return "\n\n".join(lines)

def get_search_plugin_tool(headers=None, body_params=None, doc_text_max_len=None):
    @tool
    def search_plugin_web_search(
            query: str,
            max_results: int = DEFAULT_MAX_RESULTS,
            safe_search: bool = False,
            domains: Optional[List[str]] = None,
    ) -> str:
        """Выполняет веб-поиск через Search Plugin и возвращает краткие выдержки со ссылками."""

        search_plugin = SearchPlugin(domains)
        search_mode = "safe_search" if safe_search else "actual_info_web_search"

        result = search_plugin.retrieval(query,
                                         search_mode=search_mode, docs_count=max_results,
                                         headers=headers, body_params=body_params, doc_text_max_len=doc_text_max_len
                                         )
        return _format_documents(result.documents, result.sources)
    return search_plugin_web_search
