from langchain_core.tools import tool
from agent_lab_sdk.tools.search_plugin.search_plugin import SearchPlugin


def get_search_image_tool(headers=None, additional_params=None):
    @tool
    def search_image_tool(
        text: str,
        image_limit: int
    ):
        """Выполняет веб-поиск картинки через Search Plugin и возвращает картинку в markdownю.
        text - текст запроса, image_limit - максимальное количество картинок"""

        search_plugin = SearchPlugin()
        images = search_plugin.rambler_images_proxy(text, headers=headers, additional_params=additional_params)

        content = []
        i = 1
        for image in images[:image_limit]:
            content.append(f"![Изображение {i}]({image.url})")
        return "\n".join(content)
    return search_image_tool
