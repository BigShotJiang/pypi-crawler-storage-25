import contextvars

from agent_lab_sdk.core.context import trace_id_var, request_id_var
from agent_lab_sdk.core.settings import settings


def _get_worker_context():
    if settings.DISABLE_WORKER_CONTEXT:
        return {}
    ctx = contextvars.copy_context()
    for var, value in ctx.items():
        if var.name == "worker_context":
            return value
    return {}

def get_trace_id() -> str | None:
    trace_id = trace_id_var.get()
    if trace_id is None:
        ctx = _get_worker_context()
        trace_id = ctx.get("trace_id", None)
    return trace_id

def get_request_id() -> str | None:
    request_id = request_id_var.get()
    if request_id is None:
        ctx = _get_worker_context()
        request_id = ctx.get("request_id", None)
    return request_id
