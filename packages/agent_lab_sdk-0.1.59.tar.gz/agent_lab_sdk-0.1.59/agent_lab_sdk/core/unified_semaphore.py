import asyncio
import threading


class UnifiedSemaphore:
    """Threading-based семафор + sync/async API + metrics + контекстники."""
    def __init__(self, limit):
        self._sem       = threading.Semaphore(limit)
        self._limit     = limit

    # ——— синхронный API ———
    def acquire(self):
        self._sem.acquire()

    def release(self):
        self._sem.release()

    # ——— асинхронный API ———
    async def acquire_async(self):
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, self._sem.acquire)

    async def release_async(self):
        # release очень быстрый
        self._sem.release()
