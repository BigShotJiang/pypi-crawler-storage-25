from contextvars import ContextVar
from typing import Optional

trace_id_var: ContextVar[Optional[str]] = ContextVar("trace_id_var", default=None)
request_id_var: ContextVar[Optional[str]] = ContextVar("request_id_var", default=None)
