"""Unit tests for the three Things @tool wrappers.

These tests prove the tool wiring (account resolution, sync side-effects,
argument validation, JSON projection) without touching a real SQLite
engine or Things Cloud. The ``things_sdk`` module is faked at the
``sys.modules`` level via the ``fake_things_sdk`` fixture in
``conftest.py``.
"""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import MagicMock

import httpx
import pytest
from zeno.context import Ctx
from zeno.tool import get_spec
from zeno.tools_things import (
    ThingsConfigurationError,
    ThingsNotFoundError,
    ThingsValidationError,
    things_add,
    things_complete,
    things_list,
)
from zeno.tools_things.account import (
    ThingsAccount,
    _module_account,
    configure_things,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_ctx(*, things: object | None = None) -> Ctx:
    """Build a minimal ``Ctx`` for direct tool invocation."""
    transport = httpx.MockTransport(lambda _req: httpx.Response(200))
    http = httpx.AsyncClient(transport=transport)
    state: dict[str, Any] = {}
    if things is not None:
        state["things"] = things
    return Ctx(
        user_id="alice",
        session_id=None,
        channel="test",
        memory=MagicMock(),
        reply=MagicMock(),
        stream=MagicMock(),
        finalize=MagicMock(),
        http=http,
        logger=MagicMock(),
        tracer=None,
        state=state,
        thread_key="main",
        secrets=MagicMock(),
        turn_id="t1",
    )


async def _call(tool_fn: Any, ctx: Ctx, **kwargs: Any) -> str:
    """Invoke an @tool-decorated function via its handler (skips the SDK
    envelope; we test the behavior, not the envelope)."""
    spec = get_spec(tool_fn)
    result: str = await spec.handler(ctx, **kwargs)
    return result


# ---------------------------------------------------------------------------
# Account resolution
# ---------------------------------------------------------------------------


async def test_tool_raises_when_no_account_configured(fake_things_sdk: Any) -> None:
    ctx = _make_ctx()
    with pytest.raises(ThingsConfigurationError):
        await _call(things_list, ctx, when="today")


async def test_ctx_state_account_wins_over_module_global(
    fake_things_sdk: Any,
    fake_account: Any,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """When both ``ctx.state['things']`` and ``configure_things(...)`` are
    set, the per-Ctx account is used.
    """
    other = type(fake_account)()
    configure_things(account=ThingsAccount(email="x", password="y"))
    # Override the module global with a sentinel-only fake to prove it
    # is NOT consulted when ctx.state wins.
    import zeno.tools_things.account as account_mod

    monkeypatch.setattr(account_mod, "_account", other)

    ctx = _make_ctx(things=fake_account)
    await _call(things_list, ctx, when="today")

    assert fake_account.pull_count == 1
    assert other.pull_count == 0


async def test_module_global_falls_back_when_ctx_unset(
    fake_things_sdk: Any, fake_account: Any
) -> None:
    """Without ``ctx.state['things']``, the global from
    ``configure_things(...)`` services the call.
    """
    import zeno.tools_things.account as account_mod

    account_mod._account = fake_account
    ctx = _make_ctx()
    await _call(things_list, ctx, when="today")
    assert fake_account.pull_count == 1


def test_configure_things_requires_credentials(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("THINGS_EMAIL", raising=False)
    monkeypatch.delenv("THINGS_PASSWORD", raising=False)
    with pytest.raises(ThingsConfigurationError):
        configure_things()


def test_configure_things_reads_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("THINGS_EMAIL", "alice@example.com")
    monkeypatch.setenv("THINGS_PASSWORD", "secret")
    account = configure_things()
    assert isinstance(account, ThingsAccount)
    assert _module_account() is account


# ---------------------------------------------------------------------------
# things_list
# ---------------------------------------------------------------------------


async def test_things_list_today_returns_projected_tasks(
    fake_things_sdk: Any, fake_account: Any
) -> None:
    fake_things_sdk.next_list = [
        {
            "uuid": "u1",
            "title": "Laundry",
            "notes": "use cold water",
            "deadline": 1714435200.0,
            "tags": ["home"],
        },
        {"uuid": "u2", "title": "Buy bread", "notes": "", "deadline": None, "tags": []},
    ]
    ctx = _make_ctx(things=fake_account)
    raw = await _call(things_list, ctx, when="today")

    parsed = json.loads(raw)
    assert parsed == [
        {
            "uuid": "u1",
            "title": "Laundry",
            "notes": "use cold water",
            "deadline": 1714435200.0,
            "tags": ["home"],
        },
        {
            "uuid": "u2",
            "title": "Buy bread",
            "notes": None,
            "deadline": None,
            "tags": [],
        },
    ]
    assert fake_account.pull_count == 1
    assert fake_account.push_count == 0
    assert fake_things_sdk.calls == [("list_today", {})]


@pytest.mark.parametrize(
    "when, expected_call",
    [
        ("today", "list_today"),
        ("inbox", "list_inbox"),
        ("anytime", "list_anytime"),
        ("someday", "list_someday"),
    ],
)
async def test_things_list_dispatches_to_correct_smart_list(
    fake_things_sdk: Any,
    fake_account: Any,
    when: str,
    expected_call: str,
) -> None:
    ctx = _make_ctx(things=fake_account)
    await _call(things_list, ctx, when=when)
    assert fake_things_sdk.calls[0][0] == expected_call


async def test_things_list_rejects_unknown_when(fake_things_sdk: Any, fake_account: Any) -> None:
    ctx = _make_ctx(things=fake_account)
    with pytest.raises(ThingsValidationError):
        await _call(things_list, ctx, when="bogus")
    # Validation runs before any sync side-effect.
    assert fake_account.pull_count == 0


# ---------------------------------------------------------------------------
# things_add
# ---------------------------------------------------------------------------


async def test_things_add_inbox_minimal(fake_things_sdk: Any, fake_account: Any) -> None:
    ctx = _make_ctx(things=fake_account)
    raw = await _call(things_add, ctx, title="Pick up package")
    assert json.loads(raw) == {"uuid": "new-uuid", "title": "Pick up package"}
    name, kwargs = fake_things_sdk.calls[0]
    assert name == "create_task"
    assert kwargs["title"] == "Pick up package"
    assert kwargs["schedule"] == 0  # inbox
    assert kwargs["start_date"] is None
    assert kwargs["deadline"] is None
    assert kwargs["status"] == 0
    assert kwargs["type"] == 0
    assert fake_account.push_count == 1


async def test_things_add_today_pins_start_date(fake_things_sdk: Any, fake_account: Any) -> None:
    ctx = _make_ctx(things=fake_account)
    await _call(things_add, ctx, title="Standup", when="today")
    _name, kwargs = fake_things_sdk.calls[0]
    assert kwargs["schedule"] == 1  # anytime — Things' actual storage for today
    assert isinstance(kwargs["start_date"], float)
    assert kwargs["start_date"] > 0


async def test_things_add_someday(fake_things_sdk: Any, fake_account: Any) -> None:
    ctx = _make_ctx(things=fake_account)
    await _call(things_add, ctx, title="Read more sci-fi", when="someday")
    _name, kwargs = fake_things_sdk.calls[0]
    assert kwargs["schedule"] == 2
    assert kwargs["start_date"] is None


async def test_things_add_with_iso_deadline(fake_things_sdk: Any, fake_account: Any) -> None:
    ctx = _make_ctx(things=fake_account)
    await _call(things_add, ctx, title="File taxes", deadline="2026-04-15")
    _name, kwargs = fake_things_sdk.calls[0]
    assert isinstance(kwargs["deadline"], float)
    # 2026-04-15T00:00 UTC == 1776211200.0
    assert kwargs["deadline"] == pytest.approx(1776211200.0, abs=1.0)


async def test_things_add_rejects_bad_deadline(fake_things_sdk: Any, fake_account: Any) -> None:
    ctx = _make_ctx(things=fake_account)
    with pytest.raises(ThingsValidationError):
        await _call(things_add, ctx, title="x", deadline="tomorrow")
    assert fake_account.push_count == 0


async def test_things_add_rejects_empty_title(fake_things_sdk: Any, fake_account: Any) -> None:
    ctx = _make_ctx(things=fake_account)
    with pytest.raises(ThingsValidationError):
        await _call(things_add, ctx, title="   ")
    assert fake_account.push_count == 0


async def test_things_add_strips_title_whitespace(fake_things_sdk: Any, fake_account: Any) -> None:
    ctx = _make_ctx(things=fake_account)
    await _call(things_add, ctx, title="  Stretch  ")
    _name, kwargs = fake_things_sdk.calls[0]
    assert kwargs["title"] == "Stretch"


# ---------------------------------------------------------------------------
# things_complete
# ---------------------------------------------------------------------------


async def test_things_complete_marks_status_3_and_pushes(
    fake_things_sdk: Any, fake_account: Any
) -> None:
    ctx = _make_ctx(things=fake_account)
    raw = await _call(things_complete, ctx, uuid="abc-123")
    assert json.loads(raw) == {"uuid": "abc-123", "status": "completed"}
    name, kwargs = fake_things_sdk.calls[0]
    assert name == "update_task"
    assert kwargs["uuid"] == "abc-123"
    assert kwargs["updates"]["status"] == 3
    assert "completion_date" in kwargs["updates"]
    assert fake_account.push_count == 1


async def test_things_complete_translates_not_found(
    fake_things_sdk: Any, fake_account: Any
) -> None:
    fake_things_sdk.raise_on_update = True
    ctx = _make_ctx(things=fake_account)
    with pytest.raises(ThingsNotFoundError):
        await _call(things_complete, ctx, uuid="missing")
    assert fake_account.push_count == 0


async def test_things_complete_rejects_empty_uuid(fake_things_sdk: Any, fake_account: Any) -> None:
    ctx = _make_ctx(things=fake_account)
    with pytest.raises(ThingsValidationError):
        await _call(things_complete, ctx, uuid="")
    assert fake_account.push_count == 0
