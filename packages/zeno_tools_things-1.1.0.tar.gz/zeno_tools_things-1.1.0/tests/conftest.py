"""Test fixtures for zeno-tools-things.

Tests fake out ``things_sdk`` at the ``sys.modules`` level so the tool
wrappers exercise their full code path (validation, account resolution,
JSON projection) without needing a real Things Cloud login or a SQLite
engine. The real-things integration test lives outside the default
selection (no equivalent yet — gated behind ``@pytest.mark.live`` once
written).
"""

from __future__ import annotations

import contextlib
import sys
import types
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any

import pytest
from zeno.tools_things import account as account_mod


@dataclass
class _FakeTaskService:
    """Stand-in for ``things_sdk.TaskService`` — every method is a small
    deterministic record/replay shim so tests can assert on call args
    and return canned task dicts.

    Test helpers mutate ``next_list`` and ``next_create`` to seed
    responses; ``calls`` records every method invocation (in order).
    """

    next_list: list[dict[str, Any]] = field(default_factory=list)
    next_create: dict[str, Any] = field(default_factory=dict)
    raise_on_update: bool = False
    calls: list[tuple[str, dict[str, Any]]] = field(default_factory=list)

    async def list_today(self, session: Any) -> list[dict[str, Any]]:
        self.calls.append(("list_today", {}))
        return list(self.next_list)

    async def list_inbox(self, session: Any) -> list[dict[str, Any]]:
        self.calls.append(("list_inbox", {}))
        return list(self.next_list)

    async def list_anytime(self, session: Any) -> list[dict[str, Any]]:
        self.calls.append(("list_anytime", {}))
        return list(self.next_list)

    async def list_someday(self, session: Any) -> list[dict[str, Any]]:
        self.calls.append(("list_someday", {}))
        return list(self.next_list)

    async def create_task(self, session: Any, **kwargs: Any) -> dict[str, Any]:
        self.calls.append(("create_task", kwargs))
        result = {"uuid": "new-uuid", "title": kwargs["title"]}
        result.update(self.next_create)
        return result

    async def update_task(self, session: Any, uuid: str, updates: dict[str, Any]) -> dict[str, Any]:
        self.calls.append(("update_task", {"uuid": uuid, "updates": updates}))
        if self.raise_on_update:
            raise _FakeEntityNotFoundError(f"Task {uuid!r} not found")
        return {"uuid": uuid, **updates}


class _FakeEntityNotFoundError(Exception):
    """Mirrors ``things_sdk.EntityNotFoundError`` for test purposes."""


@dataclass
class _FakeAccount:
    """Drop-in replacement for ``ThingsAccount`` exposing only the
    surface ``tools.py`` consumes.

    Tracks ``maybe_pull`` and ``push`` invocations so tests can assert
    the read/write side-effects fire on the right tools.
    """

    pull_count: int = 0
    push_count: int = 0
    sentinel_session: object = field(default_factory=object)

    async def maybe_pull(self) -> None:
        self.pull_count += 1

    async def push(self) -> None:
        self.push_count += 1

    @contextlib.asynccontextmanager
    async def session(self) -> AsyncIterator[Any]:
        yield self.sentinel_session


@pytest.fixture
def fake_things_sdk(monkeypatch: pytest.MonkeyPatch) -> _FakeTaskService:
    """Replace ``sys.modules['things_sdk']`` with a fake module.

    Returns the shared ``_FakeTaskService`` instance so tests can seed
    return values and assert on method calls.
    """
    svc = _FakeTaskService()
    fake = types.ModuleType("things_sdk")
    fake.TaskService = lambda: svc  # type: ignore[attr-defined]
    fake.EntityNotFoundError = _FakeEntityNotFoundError  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "things_sdk", fake)
    return svc


@pytest.fixture
def fake_account() -> _FakeAccount:
    """Provide a fresh ``_FakeAccount`` for a single test."""
    return _FakeAccount()


@pytest.fixture(autouse=True)
def _reset_module_account() -> None:
    """Make sure ``configure_things(...)`` from one test never bleeds
    into the next.
    """
    account_mod._reset_for_tests()
