# zeno-tools-things

Things Cloud task tools — three `@tool` wrappers (`things_list`, `things_add`, `things_complete`) over a local SQLite mirror that syncs with Things Cloud.

## Sync TTL model

`ThingsAccount` runs reads and writes asymmetrically:

- **Reads (`things_list`)** call `maybe_pull()`, which only hits Things Cloud if the last successful pull was more than `sync_ttl_seconds` ago (default 60s). Multiple read tools in the same turn share one pull.
- **Writes (`things_add`, `things_complete`)** push to the cloud immediately. No deferral — the user expects the change to land before the model claims success.

Tune `sync_ttl_seconds` per app. Long-lived background loops can lift it; interactive chat usually wants the default.

## Account resolution

Tools resolve the account in this order:

1. `ctx.state["things"]` — set by `ZenoApp(things=...)` or by tests.
2. The process-wide handle from `configure_things(...)`.

`configure_things` is intended for example apps and tests. Production apps should pass via `ZenoApp(things=...)` so multiple accounts can coexist in one process.

## Domain errors

Translate at the boundary:

- `ThingsConfigurationError` — credential or account-id missing.
- `ThingsValidationError` — invalid `when=`, missing required field.
- `ThingsNotFoundError` — task UUID does not exist.

Don't let `things_sdk` exception types leak into agent code. The `@tool` envelope formats these messages for the model.

## Dependencies

- `things-sdk` — pre-1.0 internal SDK.
- `aiosqlite>=0.19,<0.21` — pre-1.0 cap per root `AGENTS.md` § Dependency policy.
- `sqlalchemy[asyncio]`, `zeno-core` (lockstep version).

## Testing

`tests/` exercises the TTL guard, the schedule/status enum mappings (must match `things_sdk/tasks.py`), and account resolution. Use `aiosqlite` in-memory DBs — never hit the real Things Cloud from unit tests.
