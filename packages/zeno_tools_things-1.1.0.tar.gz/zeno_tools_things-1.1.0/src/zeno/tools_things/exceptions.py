"""zeno-tools-things exceptions.

Surfaced directly to the LLM through the ``@tool`` envelope, so messages
should be concise and actionable.
"""

from __future__ import annotations


class ThingsError(Exception):
    """Base class for all zeno-tools-things errors."""


class ThingsConfigurationError(ThingsError):
    """Raised when the tools are invoked before ``configure_things(...)`` ran.

    Either call ``configure_things(...)`` once at app startup, or place a
    ``ThingsAccount`` into ``ctx.state['things']`` before dispatching the
    turn.
    """


class ThingsNotFoundError(ThingsError):
    """Raised when a referenced task UUID does not exist."""


class ThingsValidationError(ThingsError):
    """Raised when an argument fails local validation (bad ``when``, bad
    ISO date, etc.) before any DB or network call."""
