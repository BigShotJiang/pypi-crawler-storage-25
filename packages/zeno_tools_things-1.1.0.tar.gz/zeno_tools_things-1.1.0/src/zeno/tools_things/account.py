"""``ThingsAccount`` — lazy SQLite + Things Cloud sync handle.

Owns:
  * one ``aiosqlite`` engine + ``async_sessionmaker`` for the local mirror
  * one ``ThingsClient`` (cloud HTTP client) for pull/push
  * a monotonic-clock TTL guard on ``maybe_pull()`` so multiple read tools
    in the same conversational turn don't hammer Things Cloud

Lifecycle:
  * ``start()`` is idempotent and lazy — the first tool call inside a
    turn drives engine creation + ``init_db``. App authors can also call
    it eagerly during startup if they want the DB file materialized
    before the first turn.
  * ``stop()`` closes the cloud HTTP client and disposes the engine.
  * ``session()`` is an async context manager yielding an
    ``AsyncSession``; tools open/close one per call.

Module globals:
  ``configure_things(...)`` writes a process-wide ``_account`` reference
  that ``tools.py`` resolves via ``ctx.state['things']`` first, falling
  back to the global. Apps that prefer per-Ctx wiring can skip
  ``configure_things`` and put a ``ThingsAccount`` into ``ctx.state``
  themselves.
"""

from __future__ import annotations

import asyncio
import contextlib
import os
import time
from collections.abc import AsyncIterator, Callable
from pathlib import Path
from typing import TYPE_CHECKING, Any

from zeno.tools_things.exceptions import ThingsConfigurationError

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncSession


_DEFAULT_DB_PATH = "~/.zeno/things.db"
_DEFAULT_SYNC_TTL_SECONDS = 60.0


class ThingsAccount:
    """Per-process Things handle: engine + cloud client + sync TTL.

    Parameters
    ----------
    email, password:
        Things Cloud credentials. Required.
    db_path:
        SQLite path for the local mirror. Tilde-expanded; the parent
        directory is created on demand. Defaults to ``~/.zeno/things.db``.
    sync_ttl_seconds:
        How long a successful ``pull_sync`` is considered fresh. Calls
        to ``maybe_pull()`` within this window become no-ops. Default 60.
    client_factory, engine_factory, now_fn:
        Test seams. Production code leaves these ``None`` and the real
        ``things_sdk`` factories are used.
    """

    def __init__(
        self,
        *,
        email: str,
        password: str,
        db_path: str | os.PathLike[str] = _DEFAULT_DB_PATH,
        sync_ttl_seconds: float = _DEFAULT_SYNC_TTL_SECONDS,
        client_factory: Callable[[str, str], Any] | None = None,
        engine_factory: Callable[[str], tuple[Any, Any]] | None = None,
        now_fn: Callable[[], float] | None = None,
    ) -> None:
        self._email = email
        self._password = password
        self._db_path = Path(os.path.expanduser(str(db_path)))
        self._sync_ttl = sync_ttl_seconds
        self._client_factory = client_factory
        self._engine_factory = engine_factory
        self._now_fn: Callable[[], float] = now_fn or time.monotonic

        self._engine: Any | None = None
        self._session_factory: Any | None = None
        self._client: Any | None = None
        self._last_pull_at: float = 0.0
        self._init_lock = asyncio.Lock()
        self._started = False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Open the SQLite engine, run schema migrations, build the cloud
        client. Idempotent.
        """
        if self._started:
            return
        async with self._init_lock:
            if self._started:
                return
            self._db_path.parent.mkdir(parents=True, exist_ok=True)
            engine_factory = self._engine_factory or _real_engine_factory
            engine, session_factory = engine_factory(f"sqlite+aiosqlite:///{self._db_path}")
            if self._engine_factory is None:
                await _real_init_db(engine)
            self._engine = engine
            self._session_factory = session_factory
            client_factory = self._client_factory or _real_client_factory
            self._client = client_factory(self._email, self._password)
            self._started = True

    async def stop(self) -> None:
        """Close the cloud client and dispose the engine. Idempotent."""
        if self._client is not None:
            with contextlib.suppress(Exception):
                await self._client.close()
        if self._engine is not None:
            with contextlib.suppress(Exception):
                await self._engine.dispose()
        self._client = None
        self._engine = None
        self._session_factory = None
        self._last_pull_at = 0.0
        self._started = False

    # ------------------------------------------------------------------
    # Session helper
    # ------------------------------------------------------------------

    @contextlib.asynccontextmanager
    async def session(self) -> AsyncIterator[AsyncSession]:
        """Open one ``AsyncSession`` for a single tool call."""
        await self.start()
        assert self._session_factory is not None  # narrows for mypy
        async with self._session_factory() as session:
            yield session

    # ------------------------------------------------------------------
    # Sync
    # ------------------------------------------------------------------

    async def maybe_pull(self) -> None:
        """Run ``pull_sync`` if the last successful pull was >TTL ago."""
        await self.start()
        now = self._now_fn()
        if now - self._last_pull_at < self._sync_ttl:
            return
        from things_sdk import pull_sync

        async with self.session() as session:
            await pull_sync(self._client, session)
        self._last_pull_at = now

    async def push(self) -> None:
        """Run ``push_sync`` immediately."""
        await self.start()
        from things_sdk import push_sync

        async with self.session() as session:
            await push_sync(self._client, session)


# ---------------------------------------------------------------------------
# Real factories — tucked behind helpers so test seams stay clean.
# ---------------------------------------------------------------------------


def _real_engine_factory(url: str) -> tuple[Any, Any]:
    from things_sdk import create_engine_and_session

    return create_engine_and_session(url)  # type: ignore[no-any-return]


async def _real_init_db(engine: Any) -> None:
    from things_sdk import configure_sync, init_db
    from things_sdk.protocols import DefaultSyncConfig

    configure_sync(DefaultSyncConfig())
    await init_db(engine)


def _real_client_factory(email: str, password: str) -> Any:
    from things_sdk import ThingsClient

    return ThingsClient(email=email, password=password)


# ---------------------------------------------------------------------------
# Module-global wiring
# ---------------------------------------------------------------------------


_account: ThingsAccount | None = None


def configure_things(
    *,
    email: str | None = None,
    password: str | None = None,
    db_path: str | os.PathLike[str] = _DEFAULT_DB_PATH,
    sync_ttl_seconds: float = _DEFAULT_SYNC_TTL_SECONDS,
    account: ThingsAccount | None = None,
) -> ThingsAccount:
    """Install a process-wide ``ThingsAccount`` for the @tool wrappers.

    Two calling shapes:

    * ``configure_things(email=..., password=..., db_path=...)`` — the
      common case. Falls back to ``THINGS_EMAIL`` / ``THINGS_PASSWORD``
      env vars when the kwargs are omitted.
    * ``configure_things(account=ThingsAccount(...))`` — when callers
      need a hand-built account (for tests, or non-default factories).

    Returns the resolved account so callers can ``await account.stop()``
    on shutdown.
    """
    global _account
    if account is not None:
        _account = account
        return account
    email = email or os.environ.get("THINGS_EMAIL")
    password = password or os.environ.get("THINGS_PASSWORD")
    if not email or not password:
        raise ThingsConfigurationError(
            "configure_things requires email + password "
            "(pass directly or set THINGS_EMAIL / THINGS_PASSWORD)."
        )
    _account = ThingsAccount(
        email=email,
        password=password,
        db_path=db_path,
        sync_ttl_seconds=sync_ttl_seconds,
    )
    return _account


def _module_account() -> ThingsAccount | None:
    """Return the configured global account, or ``None``."""
    return _account


def _reset_for_tests() -> None:
    """Clear the module-global ``_account`` (test-only helper)."""
    global _account
    _account = None
