"""zeno-tools-things public API."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

from zeno.tools_things.account import (
    ThingsAccount,
    configure_things,
)
from zeno.tools_things.exceptions import (
    ThingsConfigurationError,
    ThingsError,
    ThingsNotFoundError,
    ThingsValidationError,
)
from zeno.tools_things.tools import (
    things_add,
    things_complete,
    things_list,
)

try:
    __version__ = version("zeno-tools-things")
except PackageNotFoundError:
    __version__ = "0.0.0+unknown"

__all__ = [
    "__version__",
    # Lifecycle
    "ThingsAccount",
    "configure_things",
    # Exceptions
    "ThingsError",
    "ThingsConfigurationError",
    "ThingsNotFoundError",
    "ThingsValidationError",
    # Tools
    "things_list",
    "things_add",
    "things_complete",
]
