"""Built-in Things tools — three @tool wrappers around ``things_sdk``.

Surface:

* :func:`things_list` — read tasks for a given list (today / inbox /
  anytime / someday). Pulls from Things Cloud first, but only if the
  configured TTL window has elapsed.
* :func:`things_add` — create a new task. Pushes to the cloud
  immediately.
* :func:`things_complete` — mark a task complete by UUID. Pushes
  immediately.

Account resolution order: ``ctx.state['things']`` first (so test code
and future ``ZenoApp(things=...)`` wiring win), falling back to the
process-wide handle installed by :func:`configure_things`.

Return values are JSON strings — the @tool envelope hands them to the
model as-is.
"""

from __future__ import annotations

import datetime as dt
import json
import time
from typing import TYPE_CHECKING, Any

from zeno.context import Ctx
from zeno.tool import tool
from zeno.tools_things.account import _module_account
from zeno.tools_things.exceptions import (
    ThingsConfigurationError,
    ThingsNotFoundError,
    ThingsValidationError,
)

if TYPE_CHECKING:
    from zeno.tools_things.account import ThingsAccount


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------


# Things schedule + status enums match things_sdk/tasks.py.
_SCHEDULE_INBOX = 0
_SCHEDULE_ANYTIME = 1
_SCHEDULE_SOMEDAY = 2

_STATUS_PENDING = 0
_STATUS_COMPLETED = 3

_TYPE_TASK = 0

# Allowed values for ``things_list(when=...)`` and ``things_add(when=...)``.
_LIST_WHEN = ("today", "inbox", "anytime", "someday")
_ADD_WHEN = ("inbox", "today", "anytime", "someday")


# ---------------------------------------------------------------------------
# Account resolution
# ---------------------------------------------------------------------------


def _resolve_account(ctx: Ctx) -> ThingsAccount:
    """Return the ``ThingsAccount`` for this turn, or raise.

    Per-Ctx wiring (``ctx.state['things']``) wins; module-global
    ``configure_things(...)`` is the fallback. Either path must be set
    before any tool is invoked.
    """
    account = ctx.state.get("things") or _module_account()
    if account is None:
        raise ThingsConfigurationError(
            "Things tools require configure_things(...) at app startup, "
            "or ctx.state['things'] = ThingsAccount(...)."
        )
    return account


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _start_of_today_utc() -> float:
    """Return the Unix timestamp for 00:00 UTC of the current day."""
    now = dt.datetime.now(tz=dt.UTC)
    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
    return midnight.timestamp()


def _resolve_when_for_add(when: str) -> tuple[int, float | None]:
    """Translate ``when`` into the ``(schedule, start_date)`` pair the
    Things SDK stores natively. ``"today"`` is ``schedule=anytime`` with
    ``start_date`` pinned to today midnight (the same shape Things' own
    UI writes).
    """
    if when not in _ADD_WHEN:
        raise ThingsValidationError(f"unknown when={when!r}; expected one of {_ADD_WHEN}")
    if when == "inbox":
        return _SCHEDULE_INBOX, None
    if when == "today":
        return _SCHEDULE_ANYTIME, _start_of_today_utc()
    if when == "anytime":
        return _SCHEDULE_ANYTIME, None
    return _SCHEDULE_SOMEDAY, None


def _parse_iso_to_epoch(value: str) -> float:
    """Parse ``YYYY-MM-DD`` (or any ``datetime.fromisoformat`` input) and
    return the Unix epoch in seconds at UTC midnight.
    """
    try:
        parsed = dt.datetime.fromisoformat(value)
    except ValueError as exc:
        raise ThingsValidationError(
            f"deadline {value!r} is not a valid ISO date (expected YYYY-MM-DD)."
        ) from exc
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=dt.UTC)
    return parsed.timestamp()


def _project_task(task: dict[str, Any]) -> dict[str, Any]:
    """Return only the fields the model needs to refer to a task.

    Trimming context keeps tool turns cheap; the model can re-fetch by
    UUID if it needs richer detail.
    """
    return {
        "uuid": task.get("uuid"),
        "title": task.get("title"),
        "notes": task.get("notes") or None,
        "deadline": task.get("deadline"),
        "tags": task.get("tags") or [],
    }


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


@tool
async def things_list(ctx: Ctx, when: str = "today") -> str:
    """List Things tasks for ``when`` ∈ ``today|inbox|anytime|someday``.

    Pulls from Things Cloud only if the last successful pull was outside
    the account's TTL window (default 60s) — back-to-back calls in the
    same conversational turn reuse the cached state.

    Returns a JSON array of ``{uuid, title, notes, deadline, tags}``.
    """
    if when not in _LIST_WHEN:
        raise ThingsValidationError(f"unknown when={when!r}; expected one of {_LIST_WHEN}")
    account = _resolve_account(ctx)
    await account.maybe_pull()

    from things_sdk import TaskService

    svc = TaskService()
    async with account.session() as session:
        if when == "today":
            tasks = await svc.list_today(session)
        elif when == "inbox":
            tasks = await svc.list_inbox(session)
        elif when == "anytime":
            tasks = await svc.list_anytime(session)
        else:
            tasks = await svc.list_someday(session)
    return json.dumps([_project_task(t) for t in tasks])


@tool
async def things_add(
    ctx: Ctx,
    title: str,
    notes: str | None = None,
    when: str = "inbox",
    deadline: str | None = None,
) -> str:
    """Create a Things task and push to the cloud.

    Parameters
    ----------
    title:
        Task title (required).
    notes:
        Optional free-form notes body.
    when:
        ``"inbox"`` (default), ``"today"``, ``"anytime"``, or
        ``"someday"``. ``"today"`` schedules the task for today.
    deadline:
        Optional ISO-8601 date (``"YYYY-MM-DD"``). Stored as the Things
        deadline at UTC midnight.

    Returns a JSON object with the new task's ``uuid`` and ``title``.
    """
    if not title or not title.strip():
        raise ThingsValidationError("title is required and cannot be empty")
    schedule, start_date = _resolve_when_for_add(when)
    deadline_epoch = _parse_iso_to_epoch(deadline) if deadline else None
    account = _resolve_account(ctx)

    from things_sdk import TaskService

    svc = TaskService()
    async with account.session() as session:
        result = await svc.create_task(
            session,
            title=title.strip(),
            notes=notes,
            status=_STATUS_PENDING,
            schedule=schedule,
            type=_TYPE_TASK,
            area_uuid=None,
            project_uuid=None,
            heading_uuid=None,
            deadline=deadline_epoch,
            start_date=start_date,
        )
    await account.push()
    return json.dumps({"uuid": result.get("uuid"), "title": result.get("title")})


@tool
async def things_complete(ctx: Ctx, uuid: str) -> str:
    """Mark the task with ``uuid`` as complete and push to the cloud."""
    if not uuid or not uuid.strip():
        raise ThingsValidationError("uuid is required")
    account = _resolve_account(ctx)

    from things_sdk import EntityNotFoundError, TaskService

    svc = TaskService()
    async with account.session() as session:
        try:
            await svc.update_task(
                session,
                uuid,
                {"status": _STATUS_COMPLETED, "completion_date": time.time()},
            )
        except EntityNotFoundError as exc:
            raise ThingsNotFoundError(f"task {uuid!r} not found") from exc
    await account.push()
    return json.dumps({"uuid": uuid, "status": "completed"})
