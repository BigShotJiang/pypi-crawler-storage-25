# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```sh
# Install for development (editable deps go in sibling dirs)
python -m venv .venv && source .venv/bin/activate
pip install -e ../perfact-api-base-model/
pip install -e ../perfact-api-app-model/
pip install -e .

# Run apps
uvicorn perfact.api.main.app:app --reload --reload-include ../
uvicorn perfact.api.main.assignworker:app --reload --reload-include ../

# Full quality check (mirrors CI)
tox

# Individual checks
ruff format --check
ruff check
mypy src
bandit --configfile bandit.yml -r src

# Tests (currently commented out in tox, run manually)
pytest --doctest-modules --cov-branch --cov=src --cov-report=term-missing src
```

## Architecture

Two FastAPI apps in `src/perfact/api/main/`:

- **`app.py`** — user-facing API, all routes under `/api`. Mounts plugins from entry point group `perfact.api`.
- **`assignworker.py`** — internal task runner API for `assignd`, all routes under `/assignworker`. Mounts plugins from `perfact.assignapi`. HTTP Basic Auth via Argon2 hash in config.

Each app uses an inner `_app` (where plugins and middleware attach) mounted on an outer `app` at the path prefix. Plugin `mount(app: FastAPI)` receives `_app`.

### Plugin system

At startup both apps call `entry_points(group=...)` and invoke `mount(app: FastAPI)` on each discovered plugin. Entry point changes require re-running `pip install -e` to regenerate the entry points file in site-packages.

Plugin registration in plugin's `pyproject.toml`:
```toml
[project.entry-points.'perfact.api']
myplugin = 'perfact.api.myplugin.routes:mount'
```

### Auth (`auth.py`)

- `Auth` — FastAPI dependency (`Annotated[Optional[AuthInfo], Depends(...)]`) injected into route handlers. Returns `None` for anonymous access.
- `@require_roles("RoleName")` — decorator that appends a FastAPI dependency to the route signature. Roles are resolved per `appstc` (org area).
- Two auth methods: cookie (`__user_cookie`) and `Authorization: Apikey <ID>-<HASH>` header. API keys support both Argon2 and legacy SSHA hashes.
- `SameSitePostMiddleware` — rejects cross-site POST/PUT/PATCH from browsers (CSRF protection); non-browser clients pass through.

### Database (`dbsession.py`)

- `DBSession` — per-request SQLAlchemy session injected as a FastAPI dependency.
- `DBSessionMiddleware` — creates/commits/rolls back the session around each request.
- `RetryRoute` — custom `APIRoute` class that retries DB errors up to 3 times with 0.5s exponential backoff. Active when plugins use `APIRouter` from `dbsession.py`.

### Configuration

Set `PERFACT_API_CONFIG_PATH` to a YAML file:
```yaml
connstr: postgresql+psycopg://zope@/perfactema  # default if omitted
basicauth: "$argon2id$v=19$..."  # required for assignworker
```

### Linting

Ruff rules: `E`, `F`, `W`, `I`. No mutable defaults (`B006` not in select but Ruff B006 triggers anyway — use `None` sentinel instead of `[]`/`{}`).

Versioning via `setuptools-scm` (git tags).
