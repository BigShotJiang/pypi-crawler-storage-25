import logging
from importlib.metadata import entry_points

from fastapi import FastAPI


def load_plugins(app: FastAPI, entrypoint_group="perfact.api"):
    """
    Discover and load all plugins for the given entry point group.
    """
    log = logging.getLogger("perfact.api.main.discovery")

    log.info("start plugin discovery")
    plugin_count = 0
    for plugin in entry_points(group=entrypoint_group):
        log.info(f"try to include plugin: {plugin.value}")
        try:
            plugin.load()(app)
            plugin_count += 1
        except Exception:
            log.exception(f"failed to include plugin {plugin.value}")
    log.info(f"finished plugin discovery, included {plugin_count} plugins")


def default_logging_settings():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S%z",
    )
