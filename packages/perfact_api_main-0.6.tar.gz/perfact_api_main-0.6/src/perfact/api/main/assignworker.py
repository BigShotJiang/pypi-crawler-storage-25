import logging

from argon2 import PasswordHasher
from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from pydantic_settings import BaseSettings

from .config import Configuration
from .dbsession import DBSessionMiddleware, set_connstr
from .utils import default_logging_settings, load_plugins

default_logging_settings()


log = logging.getLogger(__name__)


class Settings(BaseSettings):
    pwhash: str = ""


settings = Settings()


basic_auth = HTTPBasic()


def _verify_credentials(credentials: HTTPBasicCredentials = Depends(basic_auth)):
    ph = PasswordHasher()
    try:
        ph.verify(settings.pwhash, credentials.password)
    except Exception as _:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Basic"},
        )


_app = FastAPI(
    title="PerFact API for assignd (task runner)",
    dependencies=[Depends(_verify_credentials)],
)
_app.add_middleware(DBSessionMiddleware)


@_app.get("/test")
async def test() -> bool:
    """
    Returns True if the authentification is valid; otherwise Unauthorized.
    """
    return True


def lifespan(outer: FastAPI):
    config = Configuration()
    set_connstr(config.get_connection_string())
    settings.pwhash = config.get_basic_auth_credentials_secret()

    load_plugins(_app, "perfact.assignapi")

    yield


app = FastAPI(lifespan=lifespan)
app.mount("/assignworker", _app)
