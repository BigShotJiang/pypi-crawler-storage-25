import logging

from fastapi import FastAPI, Response, status

from .auth import (
    Auth,
    SameSitePostMiddleware,
    add_403_to_openapi,
)
from .config import Configuration
from .dbsession import DBSessionMiddleware, set_connstr
from .utils import default_logging_settings, load_plugins

default_logging_settings()

log = logging.getLogger(__name__)


_app = FastAPI(title="PerFact API")
_app.add_middleware(DBSessionMiddleware)
_app.add_middleware(SameSitePostMiddleware)


@_app.get("/user/roles")
async def roles(user: Auth, response: Response) -> list[str]:
    """
    Return list of roles the user has. Returns Unauthorized if no user is found
    """
    if user is None:
        response.status_code = status.HTTP_401_UNAUTHORIZED
        return []
    return user.roles


def lifespan(outer: FastAPI):
    config = Configuration()
    set_connstr(config.get_connection_string())

    load_plugins(_app, "perfact.api")

    add_403_to_openapi(_app)
    yield


app = FastAPI(lifespan=lifespan)
app.mount("/api", _app)
