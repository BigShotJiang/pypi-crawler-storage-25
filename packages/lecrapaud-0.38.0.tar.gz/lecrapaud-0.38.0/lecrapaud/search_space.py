from typing import Optional

# ML models
from sklearn.linear_model import (
    SGDRegressor,
    LinearRegression,
    SGDClassifier,
    LogisticRegression,
)
from sklearn.tree import DecisionTreeRegressor, DecisionTreeClassifier
from sklearn.neural_network import MLPRegressor, MLPClassifier
from sklearn.svm import LinearSVR, LinearSVC
from sklearn.naive_bayes import GaussianNB

# Ensemble models
from catboost import CatBoostRegressor, CatBoostClassifier
from sklearn.ensemble import (
    RandomForestRegressor,
    AdaBoostRegressor,
    RandomForestClassifier,
    AdaBoostClassifier,
    BaggingClassifier,
    GradientBoostingRegressor,
    GradientBoostingClassifier,
    HistGradientBoostingRegressor,
    HistGradientBoostingClassifier,
    ExtraTreesRegressor,
    ExtraTreesClassifier,
)
from sklearn.neighbors import KNeighborsRegressor, KNeighborsClassifier
from sklearn.linear_model import (
    HuberRegressor,
    QuantileRegressor,
    PoissonRegressor,
    GammaRegressor,
    TweedieRegressor,
)

# Search spaces
from ray import tune
import pandas as pd

# we cannot use tune.sample_from function to make conditionnal search space,
# because hyperopt and bayesian opt need a fixed search space

ml_models = [
    {
        "model_name": "linear",
        "recurrent": False,
        "need_scaling": True,
        "classification": {
            "create_model": LogisticRegression,
            "search_params": {
                "penalty": tune.choice(
                    ["l2"]
                ),  # None is not compatible with liblinear, and l1/elasticnet not compatible with most solvers
                "C": tune.loguniform(1e-4, 1e2),
                "l1_ratio": tune.quniform(0.2, 0.8, 0.1),
                "solver": tune.choice(
                    [
                        "sag",
                        "saga",
                        "liblinear",
                        "lbfgs",
                        "newton-cg",
                        "newton-cholesky",
                    ]
                ),
                "max_iter": tune.randint(100, 1000),
                "n_jobs": -1,
                "random_state": 42,
            },
        },
        "regression": {
            "create_model": LinearRegression,    # default for "rmse"
            "search_params": {
                "n_jobs": -1,
                "fit_intercept": tune.choice([True, False]),
            },
            # Class-swap mechanism: when target_objective is set to one of these,
            # `resolve_sklearn_model_config` swaps both the create_model class
            # and the search_params with the matching entry below. Each class has
            # its own hyperparams (no `n_jobs` for HuberRegressor, `quantile` for
            # QuantileRegressor, `power` for TweedieRegressor, etc.).
            "objective_models": {
                "huber": {
                    "create_model": HuberRegressor,
                    "search_params": {
                        # epsilon ≥ 1.0; values around 1.35 are the sklearn default.
                        "epsilon": tune.uniform(1.1, 2.0),
                        "alpha": tune.loguniform(1e-5, 1e0),
                        "max_iter": tune.randint(100, 1000),
                        "fit_intercept": tune.choice([True, False]),
                    },
                },
                "quantile": {
                    "create_model": QuantileRegressor,
                    "search_params": {
                        # `quantile` (the target percentile) is injected by the
                        # resolver from experiment.alpha_for(target_number).
                        "alpha": tune.loguniform(1e-5, 1e0),  # L1 regularisation
                        "solver": tune.choice(["highs", "highs-ds", "highs-ipm"]),
                        "fit_intercept": tune.choice([True, False]),
                    },
                },
                "poisson": {
                    "create_model": PoissonRegressor,
                    "search_params": {
                        "alpha": tune.loguniform(1e-5, 1e0),
                        "max_iter": tune.randint(100, 1000),
                        "fit_intercept": tune.choice([True, False]),
                    },
                },
                "gamma": {
                    "create_model": GammaRegressor,
                    "search_params": {
                        "alpha": tune.loguniform(1e-5, 1e0),
                        "max_iter": tune.randint(100, 1000),
                        "fit_intercept": tune.choice([True, False]),
                    },
                },
                "tweedie": {
                    "create_model": TweedieRegressor,
                    "search_params": {
                        # `power` (= variance_power) injected by resolver from
                        # objective_params; default 1.5 (compound Poisson-gamma).
                        "power": tune.uniform(1.1, 1.9),
                        "alpha": tune.loguniform(1e-5, 1e0),
                        "max_iter": tune.randint(100, 1000),
                        "fit_intercept": tune.choice([True, False]),
                    },
                },
            },
        },
    },
    {
        "model_name": "sgd",
        "recurrent": False,
        "need_scaling": True,
        "classification": {
            "create_model": SGDClassifier,
            "search_params": {
                "loss": tune.choice(
                    [
                        "hinge",
                        "log_loss",
                        "modified_huber",
                        "squared_hinge",
                    ]
                ),
                "penalty": tune.choice(["l1", "l2", "elasticnet"]),
                "alpha": tune.loguniform(1e-6, 1e-2),
                "l1_ratio": tune.quniform(0.2, 0.8, 0.1),
                "max_iter": tune.randint(1000, 5000),
                "shuffle": tune.choice([True, False]),
                "random_state": 42,
            },
        },
        "regression": {
            "create_model": SGDRegressor,
            "search_params": {
                "penalty": tune.choice(["l1", "l2", "elasticnet"]),
                "alpha": tune.loguniform(1e-6, 1e-2),
                "l1_ratio": tune.quniform(0.2, 0.8, 0.1),
                "max_iter": tune.randint(1000, 5000),
                "random_state": 42,
            },
            # Per-objective overrides — pin SGD's `loss` based on the user's
            # requested abstract objective. Without this, SGDRegressor defaults
            # to "squared_error" regardless of target_objective.
            "objective_param_overrides": {
                "rmse":  {"loss": "squared_error"},
                "huber": {"loss": "huber"},
                # Closest sklearn-native MAE: epsilon-insensitive with small ε.
                "mae":   {"loss": "epsilon_insensitive", "epsilon": 0.0},
            },
        },
    },
    {
        "model_name": "naive_bayes",
        "recurrent": False,
        "need_scaling": False,
        "classification": {
            "create_model": GaussianNB,  # Naive Bayes classifier for classification
            "search_params": {
                "var_smoothing": tune.loguniform(
                    1e-9, 1e-6
                )  # Smoothing parameter to deal with zero probabilities
            },
        },
        "regression": None,
    },
    {
        "model_name": "bagging_naive_bayes",
        "recurrent": False,
        "need_scaling": False,
        "classification": {
            "create_model": BaggingClassifier,
            "search_params": {
                "estimator": GaussianNB(),  # Base model for bagging
                "n_estimators": tune.randint(10, 100),  # Number of base estimators
                "max_samples": tune.uniform(
                    0.5, 1.0
                ),  # Proportion of samples to draw for each base estimator
                "max_features": tune.uniform(
                    0.5, 1.0
                ),  # Proportion of features to draw for each base estimator
                "bootstrap": tune.choice(
                    [True, False]
                ),  # Whether samples are drawn with replacement
                "bootstrap_features": tune.choice(
                    [True, False]
                ),  # Whether features are drawn with replacement
                "random_state": 42,  # Fixed random state for reproducibility
            },
        },
        "regression": None,
    },
    {
        "model_name": "svm",
        "recurrent": False,
        "need_scaling": True,
        "classification": {
            "create_model": LinearSVC,
            "search_params": {
                # "penalty": tune.choice(["l1", "l2"]), # issue with l1 + hinge
                "C": tune.loguniform(1e-4, 1e2),  # Regularization strength
                "max_iter": tune.randint(100, 2000),  # Maximum number of iterations
                "tol": tune.loguniform(1e-5, 1e-2),  # Tolerance for stopping criteria
                "fit_intercept": tune.choice(
                    [True, False]
                ),  # Whether to calculate intercept
                "loss": tune.choice(["hinge", "squared_hinge"]),  # Loss function
                "dual": "auto",  # Dual only when hinge loss is not used and samples < features
                "random_state": 42,  # Fixed random state for reproducibility
            },
        },
        "regression": {
            "create_model": LinearSVR,
            "search_params": {
                "C": tune.loguniform(1e-4, 1e2),  # Regularization strength
                "max_iter": tune.randint(100, 2000),  # Maximum number of iterations
                "tol": tune.loguniform(1e-5, 1e-2),  # Tolerance for stopping criteria
                "epsilon": tune.loguniform(
                    1e-4, 1e-1
                ),  # Epsilon in the epsilon-insensitive loss function
                "fit_intercept": tune.choice(
                    [True, False]
                ),  # Whether to calculate intercept
                "loss": tune.choice(
                    ["epsilon_insensitive", "squared_epsilon_insensitive"]
                ),  # Loss function
                "dual": "auto",  # Dual is not applicable for certain configurations in SVR
                "random_state": 42,  # Fixed random state for reproducibility
            },
            "objective_param_overrides": {
                "mae":  {"loss": "epsilon_insensitive"},
                "rmse": {"loss": "squared_epsilon_insensitive"},
            },
        },
    },
    {
        "model_name": "tree",
        "recurrent": False,
        "need_scaling": False,
        "classification": {
            "create_model": DecisionTreeClassifier,
            "search_params": {
                "criterion": tune.choice(["gini", "entropy", "log_loss"]),
                "max_depth": tune.randint(8, 64),
                "min_samples_split": tune.randint(2, 10),
                "min_samples_leaf": tune.randint(1, 4),
                "max_features": tune.uniform(
                    0.5, 1.0
                ),  # Proportion of features to draw for each base estimator
                "random_state": 42,
            },
        },
        "regression": {
            "create_model": DecisionTreeRegressor,
            "search_params": {
                "max_depth": tune.randint(8, 64),
                "min_samples_split": tune.randint(2, 10),
                "min_samples_leaf": tune.randint(1, 4),
                "max_features": tune.uniform(
                    0.5, 1.0
                ),  # Proportion of features to draw for each base estimator
                "random_state": 42,
            },
            "objective_param_overrides": {
                "rmse":    {"criterion": "squared_error"},
                "mae":     {"criterion": "absolute_error"},
                "poisson": {"criterion": "poisson"},
            },
        },
    },
    {
        "model_name": "forest",
        "recurrent": False,
        "need_scaling": False,
        "classification": {
            "create_model": RandomForestClassifier,
            "search_params": {
                "n_estimators": tune.randint(50, 1000),  # Number of trees in the forest
                "max_depth": tune.randint(8, 64),  # Maximum depth of the trees
                "min_samples_split": tune.randint(
                    2, 20
                ),  # Minimum samples required to split a node
                "min_samples_leaf": tune.randint(
                    1, 10
                ),  # Minimum samples required at a leaf node
                "max_features": tune.choice(
                    ["sqrt", "log2", None]
                ),  # Number of features to consider at each split
                "bootstrap": tune.choice(
                    [True, False]
                ),  # Whether to use bootstrap sampling
                "criterion": tune.choice(
                    ["gini", "entropy", "log_loss"]
                ),  # The function to measure the quality of a split
                # "oob_score": tune.choice(
                #     [True, False]
                # ),  # Whether to use out-of-bag samples to estimate generalization accuracy: not working if bootstrap = False
                "n_jobs": -1,  # Use all processors
                "random_state": 42,  # Fixed random state for reproducibility
            },
        },
        "regression": {
            "create_model": RandomForestRegressor,
            "search_params": {
                "n_estimators": tune.randint(50, 1000),  # Number of trees in the forest
                "max_depth": tune.randint(5, 30),  # Maximum depth of the trees
                "min_samples_split": tune.randint(
                    2, 20
                ),  # Minimum samples required to split a node
                "min_samples_leaf": tune.randint(
                    1, 10
                ),  # Minimum samples required at a leaf node
                "max_features": tune.choice(
                    ["sqrt", "log2", None]
                ),  # Number of features to consider at each split
                "bootstrap": tune.choice(
                    [True, False]
                ),  # Whether to use bootstrap sampling
                "criterion": tune.choice(
                    ["squared_error", "absolute_error", "friedman_mse"]
                ),  # Loss function to use
                # "oob_score": tune.choice(
                #     [True, False]
                # ),  # Whether to use out-of-bag samples to estimate generalization accuracy: not working if bootstrap = False
                "n_jobs": -1,  # Use all processors
                "random_state": 42,  # Fixed random state for reproducibility
            },
            "objective_param_overrides": {
                "rmse":    {"criterion": "squared_error"},
                "mae":     {"criterion": "absolute_error"},
                "poisson": {"criterion": "poisson"},
            },
        },
    },
    {
        "model_name": "adaboost",
        "recurrent": False,
        "need_scaling": False,
        "classification": {
            "create_model": AdaBoostClassifier,
            "search_params": {
                "n_estimators": tune.randint(50, 1000),  # Number of boosting stages
                "learning_rate": tune.loguniform(
                    1e-4, 1
                ),  # Learning rate shrinks the contribution of each classifier
                "random_state": 42,  # Fixed random state for reproducibility
                "estimator": tune.choice(
                    [
                        DecisionTreeClassifier(max_depth=2**i, random_state=42)
                        for i in range(1, 6)
                    ]
                ),  # Base estimators are decision trees with varying depths
            },
        },
        "regression": {
            "create_model": AdaBoostRegressor,
            "search_params": {
                "n_estimators": tune.randint(50, 1000),  # Number of boosting stages
                "learning_rate": tune.loguniform(1e-4, 1),  # Learning rate
                "loss": tune.choice(
                    ["linear", "square", "exponential"]
                ),  # Loss function to use when updating weights
                "random_state": 42,  # Fixed random state for reproducibility
                "estimator": tune.choice(
                    [
                        DecisionTreeRegressor(max_depth=2**i, random_state=42)
                        for i in range(1, 6)
                    ]
                ),  # Base estimators are decision trees with varying depths
            },
            # AdaBoost regression: "linear" loss = MAE-like, "square" = squared
            # error, "exponential" emphasises tail. No native huber/quantile.
            "objective_param_overrides": {
                "rmse": {"loss": "square"},
                "mae":  {"loss": "linear"},
            },
        },
    },
    {
        # sklearn.ensemble.GradientBoostingRegressor / GradientBoostingClassifier.
        # Native quantile / huber / mae losses make this the only sklearn-side
        # model that can natively serve quantile targets without class swap.
        "model_name": "gb",
        "recurrent": False,
        "need_scaling": False,
        "classification": {
            "create_model": GradientBoostingClassifier,
            "search_params": {
                "n_estimators": tune.randint(50, 500),
                "learning_rate": tune.loguniform(1e-3, 0.3),
                "max_depth": tune.randint(2, 8),
                "min_samples_split": tune.randint(2, 20),
                "min_samples_leaf": tune.randint(1, 10),
                "subsample": tune.uniform(0.6, 1.0),
                "max_features": tune.choice(["sqrt", "log2", None]),
                "random_state": 42,
            },
            "objective_param_overrides": {
                "logloss":     {"loss": "log_loss"},
                # AdaBoost-flavored exponential loss; not a separate abstract
                # objective in our taxonomy but exposed via direct override.
            },
        },
        "regression": {
            "create_model": GradientBoostingRegressor,
            "search_params": {
                "n_estimators": tune.randint(50, 500),
                "learning_rate": tune.loguniform(1e-3, 0.3),
                "max_depth": tune.randint(2, 8),
                "min_samples_split": tune.randint(2, 20),
                "min_samples_leaf": tune.randint(1, 10),
                "subsample": tune.uniform(0.6, 1.0),
                "max_features": tune.choice(["sqrt", "log2", None]),
                "random_state": 42,
            },
            # GradientBoostingRegressor's `loss` covers rmse / mae / huber /
            # quantile natively. For quantile, the resolver also injects
            # `alpha = self.alpha` into search_params.
            "objective_param_overrides": {
                "rmse":     {"loss": "squared_error"},
                "mae":      {"loss": "absolute_error"},
                "huber":    {"loss": "huber", "alpha": 0.9},  # alpha here = quantile threshold for Huber
                "quantile": {"loss": "quantile"},               # alpha injected by resolver from self.alpha
            },
        },
    },
    {
        "model_name": "xgb",
        "recurrent": False,
        "need_scaling": False,
        "classification": {
            "create_model": "xgb",
            "search_params": {
                "num_boost_round": tune.randint(
                    50, 1000
                ),  # Number of boosting rounds (trees)
                "early_stopping_rounds": tune.randint(5, 50),
                "model_params": {
                    "max_depth": tune.randint(3, 10),  # Maximum depth of trees
                    "eta": tune.loguniform(
                        1e-4, 0.5
                    ),  # Learning rate, note 'eta' is used instead of 'learning_rate'
                    "subsample": tune.quniform(
                        0.6, 1, 0.05
                    ),  # Subsample ratio of training instances
                    "colsample_bytree": tune.quniform(
                        0.6, 1, 0.05
                    ),  # Subsample ratio of columns for each tree
                    "gamma": tune.uniform(
                        0, 10
                    ),  # Minimum loss reduction for further partitioning
                    "min_child_weight": tune.loguniform(
                        1, 10
                    ),  # Minimum sum of instance weights in a child
                    "alpha": tune.loguniform(
                        1e-5, 1
                    ),  # L1 regularization term on weights
                    "lambda": tune.loguniform(
                        1e-5, 1
                    ),  # L2 regularization term on weights
                    "random_state": 42,  # Fixed random state
                    "n_jobs": -1,  # Number of parallel threads for computation
                },
            },
        },
        "regression": {
            "create_model": "xgb",
            "search_params": {
                "num_boost_round": tune.randint(
                    50, 1000
                ),  # Number of boosting rounds (trees)
                "early_stopping_rounds": tune.randint(5, 50),
                "model_params": {
                    "max_depth": tune.randint(3, 10),  # Maximum depth of trees
                    "eta": tune.loguniform(1e-4, 0.5),  # Learning rate (eta)
                    "subsample": tune.quniform(
                        0.6, 1, 0.05
                    ),  # Subsample ratio of training instances
                    "colsample_bytree": tune.quniform(
                        0.6, 1, 0.05
                    ),  # Subsample ratio of columns for each tree
                    "gamma": tune.uniform(
                        0, 10
                    ),  # Minimum loss reduction for further partitioning
                    "min_child_weight": tune.loguniform(
                        1, 10
                    ),  # Minimum sum of instance weights in a child
                    "alpha": tune.loguniform(
                        1e-5, 1
                    ),  # L1 regularization term on weights
                    "lambda": tune.loguniform(
                        1e-5, 1
                    ),  # L2 regularization term on weights
                    "random_state": 42,  # Fixed random state
                    "n_jobs": -1,  # Number of parallel threads for computation
                },
            },
        },
    },
    {
        "model_name": "lgb",
        "recurrent": False,
        "need_scaling": False,
        "classification": {
            "create_model": "lgb",
            "search_params": {
                "num_boost_round": tune.randint(
                    50, 1000
                ),  # Number of boosting rounds (trees)
                "early_stopping_rounds": tune.randint(5, 50),
                "model_params": {
                    "max_depth": tune.randint(3, 10),  # Maximum depth of trees
                    "learning_rate": tune.loguniform(1e-4, 0.5),  # Learning rate
                    "num_leaves": tune.randint(
                        20, 150
                    ),  # Maximum number of leaves in one tree
                    "subsample": tune.quniform(
                        0.6, 1, 0.05
                    ),  # Fraction of training data for each boosting round
                    "colsample_bytree": tune.quniform(
                        0.6, 1, 0.05
                    ),  # Fraction of features to use per tree
                    "min_data_in_leaf": tune.randint(
                        20, 100
                    ),  # Minimum number of data points in a leaf
                    "lambda_l1": tune.loguniform(1e-5, 1),  # L1 regularization
                    "lambda_l2": tune.loguniform(1e-5, 1),  # L2 regularization
                    "random_state": 42,  # Fixed random state for reproducibility
                    "n_jobs": -1,  # Use all cores for parallel computation
                },
            },
        },
        "regression": {
            "create_model": "lgb",
            "search_params": {
                "num_boost_round": tune.randint(
                    50, 1000
                ),  # Number of boosting rounds (trees)
                "early_stopping_rounds": tune.randint(5, 50),
                "model_params": {
                    "max_depth": tune.randint(3, 10),  # Maximum depth of trees
                    "learning_rate": tune.loguniform(1e-4, 0.5),  # Learning rate
                    "num_leaves": tune.randint(
                        20, 150
                    ),  # Maximum number of leaves in one tree
                    "subsample": tune.quniform(
                        0.6, 1, 0.05
                    ),  # Fraction of training data for each boosting round
                    "colsample_bytree": tune.quniform(
                        0.6, 1, 0.05
                    ),  # Fraction of features to use per tree
                    "min_data_in_leaf": tune.randint(
                        20, 100
                    ),  # Minimum number of data points in a leaf
                    "lambda_l1": tune.loguniform(1e-5, 1),  # L1 regularization
                    "lambda_l2": tune.loguniform(1e-5, 1),  # L2 regularization
                    "random_state": 42,  # Fixed random state for reproducibility
                    "n_jobs": -1,  # Use all cores for parallel computation
                },
            },
        },
    },
    {
        "model_name": "catboost",
        "recurrent": False,
        "need_scaling": False,
        "classification": {
            "create_model": CatBoostClassifier,
            "search_params": {
                "iterations": tune.randint(50, 1000),
                "num_boost_round": tune.randint(50, 1000),
                "early_stopping_rounds": tune.randint(5, 50),
                "learning_rate": tune.loguniform(1e-4, 0.5),
                "depth": tune.randint(3, 10),
                "l2_leaf_reg": tune.loguniform(1e-5, 10),
                "bagging_temperature": tune.uniform(0.0, 1.0),
                "rsm": tune.quniform(0.6, 1.0, 0.05),
                "random_state": 42,
                "verbose": False,
            },
        },
        "regression": {
            "create_model": CatBoostRegressor,
            "search_params": {
                "iterations": tune.randint(50, 1000),
                "num_boost_round": tune.randint(50, 1000),
                "early_stopping_rounds": tune.randint(5, 50),
                "learning_rate": tune.loguniform(1e-4, 0.5),
                "depth": tune.randint(3, 10),
                "l2_leaf_reg": tune.loguniform(1e-5, 10),
                "bagging_temperature": tune.uniform(0.0, 1.0),
                "rsm": tune.quniform(0.6, 1.0, 0.05),
                "random_state": 42,
                "verbose": False,
            },
        },
    },
    {
        # sklearn.ensemble.HistGradientBoosting{Regressor,Classifier}.
        # Modern histogram-based GBM — typically faster than `gb` and on par
        # with XGBoost/LightGBM. Native NaN handling and no scaling needed.
        # Natively supports quantile / poisson / absolute_error losses.
        "model_name": "hist_gb",
        "recurrent": False,
        "need_scaling": False,
        "classification": {
            "create_model": HistGradientBoostingClassifier,
            "search_params": {
                "max_iter": tune.randint(50, 1000),
                "learning_rate": tune.loguniform(1e-3, 0.3),
                "max_depth": tune.choice([None, 4, 8, 16, 32]),
                "max_leaf_nodes": tune.choice([None, 15, 31, 63, 127]),
                "min_samples_leaf": tune.randint(10, 100),
                "l2_regularization": tune.loguniform(1e-5, 1.0),
                "max_features": tune.uniform(0.5, 1.0),
                "early_stopping": True,
                "random_state": 42,
            },
        },
        "regression": {
            "create_model": HistGradientBoostingRegressor,
            "search_params": {
                "max_iter": tune.randint(50, 1000),
                "learning_rate": tune.loguniform(1e-3, 0.3),
                "max_depth": tune.choice([None, 4, 8, 16, 32]),
                "max_leaf_nodes": tune.choice([None, 15, 31, 63, 127]),
                "min_samples_leaf": tune.randint(10, 100),
                "l2_regularization": tune.loguniform(1e-5, 1.0),
                "max_features": tune.uniform(0.5, 1.0),
                "early_stopping": True,
                "random_state": 42,
            },
            "objective_param_overrides": {
                "rmse":     {"loss": "squared_error"},
                "mae":      {"loss": "absolute_error"},
                "poisson":  {"loss": "poisson"},
                "gamma":    {"loss": "gamma"},
                # `quantile` injects alpha from experiment.alpha_for(target).
                "quantile": {"loss": "quantile"},
            },
        },
    },
    {
        # sklearn.ensemble.ExtraTrees{Regressor,Classifier}.
        # Randomised splits → faster than RandomForest, less variance, often
        # competitive on tabular benchmarks.
        "model_name": "extra_trees",
        "recurrent": False,
        "need_scaling": False,
        "classification": {
            "create_model": ExtraTreesClassifier,
            "search_params": {
                "n_estimators": tune.randint(50, 1000),
                "max_depth": tune.randint(8, 64),
                "min_samples_split": tune.randint(2, 20),
                "min_samples_leaf": tune.randint(1, 10),
                "max_features": tune.choice(["sqrt", "log2", None]),
                "bootstrap": tune.choice([True, False]),
                "criterion": tune.choice(["gini", "entropy", "log_loss"]),
                "n_jobs": -1,
                "random_state": 42,
            },
        },
        "regression": {
            "create_model": ExtraTreesRegressor,
            "search_params": {
                "n_estimators": tune.randint(50, 1000),
                "max_depth": tune.randint(5, 30),
                "min_samples_split": tune.randint(2, 20),
                "min_samples_leaf": tune.randint(1, 10),
                "max_features": tune.choice(["sqrt", "log2", None]),
                "bootstrap": tune.choice([True, False]),
                "criterion": tune.choice(["squared_error", "absolute_error", "friedman_mse"]),
                "n_jobs": -1,
                "random_state": 42,
            },
            "objective_param_overrides": {
                "rmse":    {"criterion": "squared_error"},
                "mae":     {"criterion": "absolute_error"},
                "poisson": {"criterion": "poisson"},
            },
        },
    },
    {
        # sklearn.neural_network.MLP{Regressor,Classifier}.
        # Vanilla feed-forward neural net baseline. Needs scaling.
        "model_name": "mlp",
        "recurrent": False,
        "need_scaling": True,
        "classification": {
            "create_model": MLPClassifier,
            "search_params": {
                "hidden_layer_sizes": tune.choice([
                    (64,), (128,), (64, 32), (128, 64), (128, 64, 32),
                ]),
                "activation": tune.choice(["relu", "tanh", "logistic"]),
                "solver": tune.choice(["adam", "lbfgs"]),
                "alpha": tune.loguniform(1e-6, 1e-2),
                "learning_rate_init": tune.loguniform(1e-4, 1e-2),
                "max_iter": tune.randint(200, 1000),
                "early_stopping": True,
                "random_state": 42,
            },
        },
        "regression": {
            "create_model": MLPRegressor,
            "search_params": {
                "hidden_layer_sizes": tune.choice([
                    (64,), (128,), (64, 32), (128, 64), (128, 64, 32),
                ]),
                "activation": tune.choice(["relu", "tanh", "logistic"]),
                "solver": tune.choice(["adam", "lbfgs"]),
                "alpha": tune.loguniform(1e-6, 1e-2),
                "learning_rate_init": tune.loguniform(1e-4, 1e-2),
                "max_iter": tune.randint(200, 1000),
                "early_stopping": True,
                "random_state": 42,
            },
        },
    },
    {
        # sklearn.neighbors.KNeighbors{Regressor,Classifier}.
        # Distance-based baseline. Needs scaling. No native handling for
        # quantile / huber etc. — alternative weights / metric only.
        "model_name": "knn",
        "recurrent": False,
        "need_scaling": True,
        "classification": {
            "create_model": KNeighborsClassifier,
            "search_params": {
                "n_neighbors": tune.randint(3, 50),
                "weights": tune.choice(["uniform", "distance"]),
                "algorithm": tune.choice(["auto", "ball_tree", "kd_tree"]),
                "leaf_size": tune.randint(10, 50),
                "p": tune.choice([1, 2]),  # 1=Manhattan, 2=Euclidean
                "n_jobs": -1,
            },
        },
        "regression": {
            "create_model": KNeighborsRegressor,
            "search_params": {
                "n_neighbors": tune.randint(3, 50),
                "weights": tune.choice(["uniform", "distance"]),
                "algorithm": tune.choice(["auto", "ball_tree", "kd_tree"]),
                "leaf_size": tune.randint(10, 50),
                "p": tune.choice([1, 2]),
                "n_jobs": -1,
            },
        },
    },
]


# ─── Recurrent / sequence model registry ────────────────────────────────
#
# Architectures are registered via the @register_model decorator. Adding a
# new model = one small builder function + one entry in dl_recurrent_models.
# Keras / TCN are imported lazily inside the closure returned by
# get_model_constructor so that importing this module never pulls in
# TensorFlow when the user only needs the classical ML models.

from types import SimpleNamespace
from typing import Callable

_MODEL_BUILDERS: dict[str, Callable] = {}


def register_model(name: str) -> Callable:
    """Decorator: register a Keras-tensor builder for a recurrent model name."""
    def decorator(fn: Callable) -> Callable:
        if name in _MODEL_BUILDERS:
            raise ValueError(f"Recurrent model {name!r} already registered")
        _MODEL_BUILDERS[name] = fn
        return fn
    return decorator


def _keras_namespace() -> SimpleNamespace:
    """Lazy-import keras + TCN once and bundle into a namespace."""
    from keras import Model, Input
    from keras.layers import (
        Dense,
        LSTM,
        Bidirectional,
        GRU,
        LayerNormalization,
        RepeatVector,
        MultiHeadAttention,
        Add,
        GlobalAveragePooling1D,
        GlobalMaxPooling1D,
        Conv1D,
        MaxPooling1D,
        Dropout,
        Lambda,
    )
    from tcn import TCN
    from keras.regularizers import L2
    from keras.activations import sigmoid

    return SimpleNamespace(
        Model=Model, Input=Input,
        Dense=Dense, LSTM=LSTM, Bidirectional=Bidirectional, GRU=GRU,
        LayerNormalization=LayerNormalization, RepeatVector=RepeatVector,
        MultiHeadAttention=MultiHeadAttention, Add=Add,
        GlobalAveragePooling1D=GlobalAveragePooling1D,
        GlobalMaxPooling1D=GlobalMaxPooling1D,
        Conv1D=Conv1D, MaxPooling1D=MaxPooling1D,
        Dropout=Dropout, Lambda=Lambda, TCN=TCN, L2=L2, sigmoid=sigmoid,
    )


# ─── LSTM family ────────────────────────────────────────────────────────

@register_model("LSTM-1")
def _build_lstm_1(inputs, params, K, input_shape):
    return K.LSTM(**params["model_params"])(inputs)


@register_model("LSTM-2")
def _build_lstm_2(inputs, params, K, input_shape):
    x = K.LSTM(**params["model_params"], return_sequences=True)(inputs)
    return K.LSTM(**params["model_params"])(x)


@register_model("BiLSTM-1")
def _build_bilstm_1(inputs, params, K, input_shape):
    return K.Bidirectional(K.LSTM(**params["model_params"]))(inputs)


@register_model("BiLSTM-2")
def _build_bilstm_2(inputs, params, K, input_shape):
    x = K.Bidirectional(K.LSTM(**params["model_params"], return_sequences=True))(inputs)
    return K.Bidirectional(K.LSTM(**params["model_params"]))(x)


# ─── GRU family ─────────────────────────────────────────────────────────

@register_model("GRU-1")
def _build_gru_1(inputs, params, K, input_shape):
    return K.GRU(**params["model_params"])(inputs)


@register_model("GRU-2")
def _build_gru_2(inputs, params, K, input_shape):
    x = K.GRU(**params["model_params"], return_sequences=True)(inputs)
    return K.GRU(**params["model_params"])(x)


@register_model("BiGRU-1")
def _build_bigru_1(inputs, params, K, input_shape):
    return K.Bidirectional(K.GRU(**params["model_params"]))(inputs)


@register_model("BiGRU-2")
def _build_bigru_2(inputs, params, K, input_shape):
    x = K.Bidirectional(K.GRU(**params["model_params"], return_sequences=True))(inputs)
    return K.Bidirectional(K.GRU(**params["model_params"]))(x)


# ─── TCN family ─────────────────────────────────────────────────────────

@register_model("TCN-1")
def _build_tcn_1(inputs, params, K, input_shape):
    return K.TCN(**params["model_params"])(inputs)


@register_model("TCN-2")
def _build_tcn_2(inputs, params, K, input_shape):
    x = K.TCN(**params["model_params"], return_sequences=True)(inputs)
    return K.TCN(**params["model_params"])(x)


@register_model("BiTCN-1")
def _build_bitcn_1(inputs, params, K, input_shape):
    return K.Bidirectional(K.TCN(**params["model_params"], return_sequences=False))(inputs)


@register_model("BiTCN-2")
def _build_bitcn_2(inputs, params, K, input_shape):
    x = K.Bidirectional(K.TCN(**params["model_params"], return_sequences=True))(inputs)
    return K.Bidirectional(K.TCN(**params["model_params"], return_sequences=False))(x)


# ─── CNN-1D ─────────────────────────────────────────────────────────────

@register_model("CNN-1D")
def _build_cnn_1d(inputs, params, K, input_shape):
    # Stack of 1D convolutions (causal padding so it works for forecasting)
    # with optional MaxPooling between layers, finally global-mean-pooled.
    p = params["model_params"]
    x = inputs
    for _ in range(p["num_layers"]):
        x = K.Conv1D(
            filters=p["nb_filters"],
            kernel_size=p["kernel_size"],
            padding="causal",
            activation="relu",
        )(x)
        x = K.Dropout(p["dropout_rate"])(x)
    return K.GlobalAveragePooling1D()(x)


# ─── Seq2Seq ────────────────────────────────────────────────────────────

@register_model("Seq2Seq")
def _build_seq2seq(inputs, params, K, input_shape):
    # Encoder
    _, encoder_state_h, encoder_state_c = K.LSTM(
        **params["model_params"], return_state=True
    )(inputs)
    encoder_state_h = K.LayerNormalization(epsilon=1e-6)(encoder_state_h)
    encoder_state_c = K.LayerNormalization(epsilon=1e-6)(encoder_state_c)
    # Decoder
    decoder_timesteps = max(int(input_shape[0] / 5), 2)
    decoder = K.RepeatVector(decoder_timesteps)(encoder_state_h)
    return K.LSTM(**params["model_params"], return_state=False)(
        decoder, initial_state=[encoder_state_h, encoder_state_c]
    )


# ─── Transformer family ────────────────────────────────────────────────
# Three architectures sharing the same building blocks but differing on
# attention masking and output position:
#   Transformer : encoder + decoder w/ cross-attention (Vaswani 2017)
#   BERT        : encoder-only, bidirectional, [CLS]-token output
#   GPT         : decoder-only, causal mask, last-token output

def _transformer_block(x, K, *, head_size, num_heads, ff_dim, dropout, causal=False):
    """Pre-norm transformer block. causal=True enables decoder-style self-attn."""
    norm = K.LayerNormalization(epsilon=1e-6)(x)
    attn = K.MultiHeadAttention(
        key_dim=head_size, num_heads=num_heads, dropout=dropout,
    )(query=norm, value=norm, use_causal_mask=causal)
    x = K.Add()([x, attn])
    ff_norm = K.LayerNormalization(epsilon=1e-6)(x)
    ff = K.Dense(ff_dim, activation="relu")(ff_norm)
    ff = K.Dropout(dropout)(ff)
    ff = K.Dense(x.shape[-1])(ff)
    return K.Add()([x, ff])


def _cross_attention_block(dec, enc, K, *, head_size, num_heads, ff_dim, dropout):
    """Decoder block: causal self-attn + cross-attn to encoder + FFN."""
    self_norm = K.LayerNormalization(epsilon=1e-6)(dec)
    self_attn = K.MultiHeadAttention(
        key_dim=head_size, num_heads=num_heads, dropout=dropout,
    )(query=self_norm, value=self_norm, use_causal_mask=True)
    dec = K.Add()([dec, self_attn])
    cross_norm = K.LayerNormalization(epsilon=1e-6)(dec)
    cross_attn = K.MultiHeadAttention(
        key_dim=head_size, num_heads=num_heads, dropout=dropout,
    )(query=cross_norm, value=enc)
    dec = K.Add()([dec, cross_attn])
    ff_norm = K.LayerNormalization(epsilon=1e-6)(dec)
    ff = K.Dense(ff_dim, activation="relu")(ff_norm)
    ff = K.Dropout(dropout)(ff)
    ff = K.Dense(dec.shape[-1])(ff)
    return K.Add()([dec, ff])


@register_model("Transformer")
def _build_transformer(inputs, params, K, input_shape):
    # Full encoder-decoder transformer (Vaswani et al. 2017).
    # Encoder uses bidirectional self-attention, decoder uses causal
    # self-attention plus cross-attention to the encoder output.
    p = params["model_params"]
    enc = inputs
    for _ in range(p["num_layers"]):
        enc = _transformer_block(
            enc, K,
            head_size=p["head_size"], num_heads=p["num_heads"],
            ff_dim=p["ff_dim"], dropout=p["dropout"], causal=False,
        )
    # Decoder seed: a short sequence derived from the encoder summary.
    decoder_timesteps = max(int(input_shape[0] / 5), 2)
    summary = K.GlobalAveragePooling1D()(enc)
    dec = K.RepeatVector(decoder_timesteps)(summary)
    for _ in range(p["num_layers"]):
        dec = _cross_attention_block(
            dec, enc, K,
            head_size=p["head_size"], num_heads=p["num_heads"],
            ff_dim=p["ff_dim"], dropout=p["dropout"],
        )
    x = K.GlobalAveragePooling1D()(dec)
    return K.LayerNormalization(epsilon=1e-6)(x)


@register_model("BERT")
def _build_bert(inputs, params, K, input_shape):
    # Encoder-only transformer: bidirectional self-attention, [CLS]-token
    # readout. The first time-step's representation is used as the
    # sentence-level summary (BERT's classifier head pattern).
    p = params["model_params"]
    x = inputs
    for _ in range(p["num_layers"]):
        x = _transformer_block(
            x, K,
            head_size=p["head_size"], num_heads=p["num_heads"],
            ff_dim=p["ff_dim"], dropout=p["dropout"], causal=False,
        )
    cls = K.Lambda(lambda t: t[:, 0, :], output_shape=lambda s: (s[0], s[2]))(x)
    return K.LayerNormalization(epsilon=1e-6)(cls)


@register_model("GPT")
def _build_gpt(inputs, params, K, input_shape):
    # Decoder-only transformer: causal self-attention, last-token readout.
    # The autoregressive natural endpoint — same pattern as GPT-family LLMs.
    p = params["model_params"]
    x = inputs
    for _ in range(p["num_layers"]):
        x = _transformer_block(
            x, K,
            head_size=p["head_size"], num_heads=p["num_heads"],
            ff_dim=p["ff_dim"], dropout=p["dropout"], causal=True,
        )
    last = K.Lambda(lambda t: t[:, -1, :], output_shape=lambda s: (s[0], s[2]))(x)
    return K.LayerNormalization(epsilon=1e-6)(last)


# ─── Output head + public constructor ──────────────────────────────────

def _build_output_head(x, params, target_type, num_class, K):
    """Final Dense layer (softmax for multiclass, sigmoid/linear otherwise)."""
    if num_class is not None and num_class > 2:
        return K.Dense(
            num_class,
            kernel_initializer="identity",
            kernel_regularizer=K.L2(l2=params["l2"]),
            activation="softmax",
        )(x)
    return K.Dense(
        1,
        kernel_initializer="identity",
        kernel_regularizer=K.L2(l2=params["l2"]),
        activation=(K.sigmoid if target_type == "classification" else "linear"),
    )(x)


def get_model_constructor(model_name: str) -> Callable:
    """Return a closure that builds the Keras model for `model_name` at call time.

    Args:
        model_name: Name of a registered recurrent / sequence model.
            See `list_recurrent_models()` for the full list.

    Returns:
        A callable `(params, input_shape, target_type, num_class=None) -> keras.Model`.

    Raises:
        ValueError: If `model_name` is not registered.
    """
    if model_name not in _MODEL_BUILDERS:
        raise ValueError(
            f"Unknown recurrent model: {model_name!r}. "
            f"Available: {sorted(_MODEL_BUILDERS)}"
        )
    builder = _MODEL_BUILDERS[model_name]

    def constructor(
        params: dict,
        input_shape: tuple[int, int],
        target_type: str,
        num_class: Optional[int] = None,
    ):
        K = _keras_namespace()
        inputs = K.Input(shape=input_shape)
        x = builder(inputs, params, K, input_shape)
        # Optional projection head (BERT-pooler / classifier-head pattern).
        # If `head_units` is set (anything truthy), insert a Dense layer with
        # the chosen activation between the body's pooled representation and
        # the final output Dense. Applies to every registered architecture.
        head_units = params.get("head_units")
        if head_units:
            x = K.Dense(
                head_units,
                activation=params.get("head_activation", "relu"),
            )(x)
        outputs = _build_output_head(x, params, target_type, num_class, K)
        model = K.Model(inputs=inputs, outputs=outputs, name=model_name)
        model.model_name = model.name
        return model

    return constructor


def list_recurrent_models() -> list[str]:
    """Names of every registered recurrent / sequence model."""
    return sorted(_MODEL_BUILDERS)


# ─── Search-space templates (DRY) ──────────────────────────────────────

_COMMON_TRAINING_PARAMS = {
    "learning_rate": tune.loguniform(1e-4, 1e-2),
    "batch_size": tune.choice([32, 64, 128]),
    "epochs": tune.choice([50, 100, 200]),
    "timesteps": tune.choice([5, 10, 20, 50, 120]),
    "clipnorm": tune.quniform(0.5, 2.0, 0.5),
    "l2": tune.loguniform(1e-6, 1e-1),
    # Optional projection head before the final output Dense — the
    # "BERT-pooler" / classifier-head pattern. None = skip (direct linear
    # projection to output). Otherwise a Dense(head_units, head_activation)
    # is inserted between the body and the output head.
    "head_units": tune.choice([None, 32, 64, 128, 256]),
    "head_activation": tune.choice(["relu", "tanh"]),
}

_LSTM_GRU_MODEL_PARAMS = {
    "units": tune.choice([32, 64, 128]),
    "activation": tune.choice(["tanh", "relu"]),
    "recurrent_activation": tune.choice(["sigmoid", "relu"]),
    "kernel_initializer": "identity",
    "recurrent_initializer": "identity",
    "dropout": tune.quniform(0.0, 0.5, 0.1),
    "recurrent_dropout": tune.quniform(0.0, 0.5, 0.1),
}

_SEQ2SEQ_MODEL_PARAMS = {
    "units": tune.choice([32, 64, 128]),
    "kernel_initializer": "identity",
    "recurrent_initializer": "identity",
    "dropout": tune.quniform(0.0, 0.5, 0.1),
    "recurrent_dropout": tune.quniform(0.0, 0.5, 0.1),
}

_TCN_MODEL_PARAMS = {
    "nb_filters": tune.choice([32, 64, 128]),
    "kernel_size": tune.choice([2, 3, 5]),
    "dropout_rate": tune.quniform(0.0, 0.5, 0.1),
}

_CNN_MODEL_PARAMS = {
    "nb_filters": tune.choice([32, 64, 128]),
    "kernel_size": tune.choice([2, 3, 5, 7]),
    "num_layers": tune.choice([1, 2, 3, 4]),
    "dropout_rate": tune.quniform(0.0, 0.5, 0.1),
}

_TRANSFORMER_MODEL_PARAMS = {
    "head_size": tune.choice([32, 64, 128, 256, 512]),
    "num_heads": tune.choice([8, 16, 32]),
    "ff_dim": tune.choice([128, 256, 512, 1024, 2048]),
    "num_layers": tune.choice([6, 12, 24]),
    "dropout": tune.quniform(0.1, 0.5, 0.1),
}


def _recurrent_entry(model_name: str, model_params: dict) -> dict:
    """Build a dl_recurrent_models entry with shared training defaults."""
    return {
        "recurrent": True,
        "need_scaling": True,
        "model_name": model_name,
        "create_model": get_model_constructor(model_name),
        "search_params": {
            "model_params": model_params,
            **_COMMON_TRAINING_PARAMS,
        },
    }


dl_recurrent_models = [
    # LSTM family — the optional projection head (head_units / head_activation
    # in _COMMON_TRAINING_PARAMS) subsumes the former *-Deep variants.
    _recurrent_entry("LSTM-1", _LSTM_GRU_MODEL_PARAMS),
    _recurrent_entry("LSTM-2", _LSTM_GRU_MODEL_PARAMS),
    _recurrent_entry("BiLSTM-1", _LSTM_GRU_MODEL_PARAMS),
    _recurrent_entry("BiLSTM-2", _LSTM_GRU_MODEL_PARAMS),
    # GRU family
    _recurrent_entry("GRU-1", _LSTM_GRU_MODEL_PARAMS),
    _recurrent_entry("GRU-2", _LSTM_GRU_MODEL_PARAMS),
    _recurrent_entry("BiGRU-1", _LSTM_GRU_MODEL_PARAMS),
    _recurrent_entry("BiGRU-2", _LSTM_GRU_MODEL_PARAMS),
    # TCN family
    _recurrent_entry("TCN-1", _TCN_MODEL_PARAMS),
    _recurrent_entry("TCN-2", _TCN_MODEL_PARAMS),
    _recurrent_entry("BiTCN-1", _TCN_MODEL_PARAMS),
    _recurrent_entry("BiTCN-2", _TCN_MODEL_PARAMS),
    # CNN-1D
    _recurrent_entry("CNN-1D", _CNN_MODEL_PARAMS),
    # Seq2Seq
    _recurrent_entry("Seq2Seq", _SEQ2SEQ_MODEL_PARAMS),
    # Transformer family
    _recurrent_entry("Transformer", _TRANSFORMER_MODEL_PARAMS),
    _recurrent_entry("BERT", _TRANSFORMER_MODEL_PARAMS),
    _recurrent_entry("GPT", _TRANSFORMER_MODEL_PARAMS),
]


all_models = ml_models + dl_recurrent_models


def get_models_idx(*model_names):
    matching_idx = [
        i for i, model in enumerate(all_models) if model["model_name"] in model_names
    ]
    return matching_idx


def normalize_models_idx(models_idx: list[int | str]) -> list[int]:
    """
    Convert a list of model identifiers (int or str) to a list of model indices (int).
    If an element is a string, it is resolved using `get_models_idx`.

    Returns:
        List of model indices (ints).
    """
    normalized = []
    for model_idx in models_idx:
        if isinstance(model_idx, int):
            normalized.append(model_idx)
        elif isinstance(model_idx, str):
            resolved = get_models_idx(model_idx)
            if not resolved:
                raise ValueError(f"No model index found for name: {model_idx}")
            normalized.append(resolved[0])
        else:
            raise TypeError(f"Unsupported type: {type(model_idx)}")
    return normalized
