import sys
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import dominus.start as start_module  # noqa: E402


@pytest.fixture()
def sdk(monkeypatch):
    monkeypatch.setattr(start_module, "_VALIDATION_ERROR", None)
    monkeypatch.setattr(start_module, "_TOKEN", "a" * 64)
    monkeypatch.setattr(start_module, "_VALIDATED", False)
    monkeypatch.setattr(start_module, "_BASE_URL", "https://gateway.getdominus.app")
    monkeypatch.setattr(start_module, "_GATEWAY_URL", "https://gateway.getdominus.app")
    return start_module.Dominus()


@pytest.mark.asyncio
async def test_flat_root_shortcuts_dispatch_to_gateway_namespaces(monkeypatch, sdk):
    calls = []

    async def fake_get(key):
        calls.append(("secrets.get", key))
        return "secret-value"

    async def fake_tables(schema="public", use_shared=False, open=False):
        calls.append(("db.tables", schema, use_shared, open))
        return [{"name": "users"}]

    monkeypatch.setattr(sdk.secrets, "get", fake_get)
    monkeypatch.setattr(sdk.db, "tables", fake_tables)

    assert await sdk.get("DB_URL") == "secret-value"
    assert await sdk("sql.app.list_tables", schema="app") == [{"name": "users"}]
    assert calls == [
        ("secrets.get", "DB_URL"),
        ("db.tables", "public", False, False),
    ]


@pytest.mark.asyncio
async def test_removed_legacy_flat_auth_command_raises_clear_error(sdk):
    with pytest.raises(RuntimeError, match="Legacy flat command 'auth.add_user' was removed"):
        await sdk("auth.add_user", username="john")


def test_secure_namespace_is_namespaced_surface(sdk):
    assert hasattr(sdk.secure, "query")
    assert not hasattr(sdk, "db_secure")
