import sys
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dominus.namespaces.logs import LogsNamespace  # noqa: E402


class FakeClient:
    def __init__(self):
        self.calls = []

    async def _request(
        self,
        endpoint,
        method="POST",
        body=None,
        user_token=None,
        use_gateway=False,
        timeout=30.0,
    ):
        self.calls.append(
            {
                "endpoint": endpoint,
                "method": method,
                "body": body,
                "user_token": user_token,
                "use_gateway": use_gateway,
                "timeout": timeout,
            }
        )
        return {"events": [{"event_id": "log-1"}]}


@pytest.mark.asyncio
async def test_logs_tail_forwards_business_filters():
    client = FakeClient()
    namespace = LogsNamespace(client)

    events = await namespace.tail(
        limit=25,
        since="2026-04-11T08:33:00Z",
        level="error",
        company="carebridge-summit",
        subject="PCM47474562",
        run_id="run-123",
        deploy_id="deploy-123",
        installation_id="inst-123",
        artifact_ref="ar://carebridge/summit/production/company/report_snapshot_current",
    )

    assert len(events) == 1
    assert client.calls[0]["endpoint"] == (
        "/api/logs/tail?"
        "limit=25&since=2026-04-11T08%3A33%3A00Z&level=error&company=carebridge-summit"
        "&subject=PCM47474562&run_id=run-123&deploy_id=deploy-123"
        "&installation_id=inst-123&artifact_ref="
        "ar%3A%2F%2Fcarebridge%2Fsummit%2Fproduction%2Fcompany%2Freport_snapshot_current"
    )
    assert client.calls[0]["method"] == "GET"
    assert client.calls[0]["use_gateway"] is True
