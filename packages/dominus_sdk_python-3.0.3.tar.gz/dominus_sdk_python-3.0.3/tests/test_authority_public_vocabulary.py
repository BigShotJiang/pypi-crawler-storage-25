import base64
import inspect
import json

import pytest

from dominus.helpers import core as core_helpers
from dominus.config import endpoints as endpoint_config
from dominus.namespaces.authority import AuthorityNamespace


class FakeClient:
    def __init__(self):
        self.calls = []

    async def _request(
        self,
        endpoint,
        method="POST",
        body=None,
        user_token=None,
        use_gateway=False,
        timeout=30.0,
        actor=None,
        **kwargs,
    ):
        self.calls.append(
            {
                "endpoint": endpoint,
                "method": method,
                "body": body,
                "user_token": user_token,
                "use_gateway": use_gateway,
                "timeout": timeout,
                "actor": actor,
            }
        )
        return {"ok": True}


class FakeMintResponse:
    def __init__(self, text: str):
        self.text = text

    def raise_for_status(self):
        return None


class FakeMintClient:
    instances = []

    def __init__(self, *, base_url, headers, timeout, proxy):
        self.base_url = base_url
        self.headers = headers
        self.timeout = timeout
        self.proxy = proxy
        self.posts = []
        FakeMintClient.instances.append(self)

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def post(self, path, content=None):
        self.posts.append({"path": path, "content": content})
        payload = base64.b64encode(
            json.dumps({"success": True, "data": {"token": "jwt-123"}}).encode("utf-8")
        ).decode("utf-8")
        return FakeMintResponse(payload)


def test_authority_scope_signatures_use_new_public_vocabulary():
    ensure_sig = inspect.signature(AuthorityNamespace.ensure_run)
    bootstrap_sig = inspect.signature(AuthorityNamespace.bootstrap_company)
    release_sig = inspect.signature(AuthorityNamespace.publish_client_release)
    context_sig = inspect.signature(AuthorityNamespace.context_resolve)
    mint_sig = inspect.signature(core_helpers.mint_selected_scope_jwt)

    for name in ("app_slug", "env", "target_org_id", "target_env", "run_kind", "target_app_slug"):
        assert name in ensure_sig.parameters
    for legacy in ("project_slug", "environment", "target_project_id", "target_environment"):
        assert legacy not in ensure_sig.parameters

    for name in ("shared_app_slug", "target_app_slug", "target_env"):
        assert name in bootstrap_sig.parameters
    assert "shared_project_slug" not in bootstrap_sig.parameters

    for name in ("storage_app_slug", "storage_env", "app_slug", "env"):
        assert name in release_sig.parameters
    for legacy in ("storage_project_slug", "storage_environment"):
        assert legacy not in release_sig.parameters

    for name in ("org_id", "app_slug", "target_org_id", "target_app_slug", "target_env", "env"):
        assert name in context_sig.parameters
    for legacy in ("org", "app", "project", "project_id", "project_slug", "environment", "target_project_id", "target_environment"):
        assert legacy not in context_sig.parameters

    for name in ("target_org_id", "target_app_slug", "target_env"):
        assert name in mint_sig.parameters
    for legacy in ("target_project_id", "target_project_slug", "target_environment"):
        assert legacy not in mint_sig.parameters


@pytest.mark.asyncio
async def test_authority_scope_methods_use_canonical_context_wire_names():
    client = FakeClient()
    namespace = AuthorityNamespace(client)

    await namespace.ensure_run(
        workflow_id="wf-123",
        app_slug="carebridge",
        env="production",
        target_org_id="org-123",
        target_env="production",
    )
    await namespace.bootstrap_company(
        "summit-radiology",
        shared_app_slug="shared-core",
        app_slug="carebridge",
        env="production",
        target_app_slug="carebridge",
        target_env="production",
    )
    await namespace.publish_client_release(
        variant_slug="desktop",
        version="1.2.3",
        manifest_path="manifest.json",
        storage_app_slug="storage-core",
        storage_env="production",
        app_slug="carebridge",
        env="production",
    )
    await namespace.context_resolve(
        org_id="org-123",
        app_slug="carebridge",
        target_org_id="target-org-1",
        target_app_slug="shared-core",
        target_env="production",
        env="production",
    )

    ensure_body = client.calls[0]["body"]
    assert ensure_body["app_slug"] == "carebridge"
    assert ensure_body["env"] == "production"
    assert ensure_body["target_org_id"] == "org-123"
    assert ensure_body["target_env"] == "production"

    bootstrap_body = client.calls[1]["body"]
    assert bootstrap_body["shared_app_slug"] == "shared-core"
    assert bootstrap_body["app_slug"] == "carebridge"
    assert bootstrap_body["target_app_slug"] == "carebridge"
    assert bootstrap_body["target_env"] == "production"

    release_body = client.calls[2]["body"]
    assert release_body["storage_app_slug"] == "storage-core"
    assert release_body["storage_env"] == "production"
    assert release_body["app_slug"] == "carebridge"

    context_body = client.calls[3]["body"]
    assert context_body["org_id"] == "org-123"
    assert context_body["app_slug"] == "carebridge"
    assert context_body["target_org_id"] == "target-org-1"
    assert context_body["target_app_slug"] == "shared-core"
    assert context_body["target_env"] == "production"
    assert context_body["env"] == "production"


@pytest.mark.asyncio
async def test_selected_scope_mint_helper_uses_new_public_names_and_route_canonical_mint_payload(monkeypatch):
    FakeMintClient.instances.clear()
    monkeypatch.setattr(core_helpers.httpx, "AsyncClient", FakeMintClient)
    monkeypatch.setattr(endpoint_config, "get_gateway_url", lambda: "https://gateway.example")
    monkeypatch.setattr(endpoint_config, "get_proxy_config", lambda: None)

    token = await core_helpers.mint_selected_scope_jwt(
        "psk-token",
        target_org_id="org-123",
        target_app_slug="carebridge",
        target_env="production",
    )

    assert token == "jwt-123"
    assert FakeMintClient.instances[0].base_url == "https://gateway.example"
    sent = json.loads(
        base64.b64decode(FakeMintClient.instances[0].posts[0]["content"]).decode("utf-8")
    )
    assert sent == {
        "target_org_id": "org-123",
        "target_env": "production",
    }


@pytest.mark.asyncio
async def test_list_runs_drops_target_query_when_matching_gateway_scope():
    client = FakeClient()
    client._gateway_org_id = "a73627b4-071f-4d27-b964-d220464deb6e"
    client._gateway_env = "production"
    ns = AuthorityNamespace(client)
    await ns.list_runs(
        app_slug="dominus-authority",
        env="production",
        target_org_id="a73627b4-071f-4d27-b964-d220464deb6e",
        target_env="production",
        limit=5,
        offset=0,
    )
    ep = client.calls[0]["endpoint"]
    assert "target_org_id" not in ep
    assert "target_env" not in ep
    assert "app_slug=dominus-authority" in ep


@pytest.mark.asyncio
async def test_list_runs_keeps_target_query_when_org_differs_from_gateway():
    client = FakeClient()
    client._gateway_org_id = "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"
    client._gateway_env = "production"
    ns = AuthorityNamespace(client)
    await ns.list_runs(
        app_slug="dominus-authority",
        env="production",
        target_org_id="bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb",
        target_env="production",
        limit=3,
    )
    ep = client.calls[0]["endpoint"]
    assert "target_org_id=bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb" in ep


@pytest.mark.asyncio
async def test_authority_ensure_run_company_bootstrap_omits_workflow_mode():
    client = FakeClient()
    namespace = AuthorityNamespace(client)
    await namespace.ensure_run(
        run_kind="company.bootstrap",
        company="acme-corp",
        app_slug="carebridge",
        env="production",
        target_org_id="org-1",
        execution_mode="async",
        shared_app_slug="shared-core",
    )
    body = client.calls[0]["body"]
    assert body["run_kind"] == "company.bootstrap"
    assert body["company"] == "acme-corp"
    assert body["execution_mode"] == "async"
    assert body["shared_app_slug"] == "shared-core"
    assert "mode" not in body


@pytest.mark.asyncio
async def test_authority_ensure_run_bootstrap_requires_company_slug():
    client = FakeClient()
    namespace = AuthorityNamespace(client)
    with pytest.raises(ValueError, match="company, company_slug, or slug"):
        await namespace.ensure_run(
            run_kind="company_bootstrap",
            app_slug="carebridge",
            env="production",
        )
    assert client.calls == []
