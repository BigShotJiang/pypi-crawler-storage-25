from dominus.errors import DominusError, raise_for_status


def test_dominus_error_exposes_kernel_contract_fields():
    error = DominusError(
        "Validation failed",
        status_code=400,
        details={
            "code": "validation.invalid_body",
            "category": "validation",
            "trace_id": "trace-123",
            "request_id": "req-123",
            "retryable": False,
            "field": "body",
        },
        endpoint="/api/example",
    )

    assert error.code == "validation.invalid_body"
    assert error.category == "validation"
    assert error.trace_id == "trace-123"
    assert error.request_id == "req-123"
    assert error.retryable is False
    assert error.details["field"] == "body"
    assert "[validation.invalid_body]" in str(error)


def test_raise_for_status_backfills_kernel_defaults():
    try:
        raise_for_status(404, "Missing resource", {"trace_id": "trace-404"}, "/api/missing")
    except DominusError as error:
        assert error.code == "http.404"
        assert error.category == "not_found"
        assert error.trace_id == "trace-404"
        assert error.endpoint == "/api/missing"
    else:
        raise AssertionError("raise_for_status should raise DominusError")
