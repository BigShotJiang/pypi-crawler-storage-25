import sys
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dominus.config import endpoints  # noqa: E402
from dominus.helpers import core  # noqa: E402
from dominus.namespaces.health import HealthNamespace  # noqa: E402


class FakeClient:
    def __init__(self):
        self.calls = []

    async def _request(
        self,
        endpoint,
        method="POST",
        body=None,
        user_token=None,
        use_gateway=True,
        timeout=30.0,
        actor=None,
    ):
        self.calls.append(
            {
                "endpoint": endpoint,
                "method": method,
                "body": body,
                "user_token": user_token,
                "use_gateway": use_gateway,
                "timeout": timeout,
                "actor": actor,
            }
        )
        return {"pong": True}


@pytest.mark.asyncio
async def test_health_check_uses_gateway_url(monkeypatch):
    seen = {}

    async def fake_health_check_all(base_url):
        seen["base_url"] = base_url
        return {"status": "ok", "service": "gateway"}

    monkeypatch.setattr(core, "health_check_all", fake_health_check_all)
    monkeypatch.setattr(endpoints, "get_gateway_url", lambda: "https://gateway.example")

    namespace = HealthNamespace(FakeClient())
    result = await namespace.check()

    assert seen["base_url"] == "https://gateway.example"
    assert result["status"] == "ok"
    assert result["service"] == "gateway"


@pytest.mark.asyncio
async def test_health_ping_uses_live_gateway_ping_route():
    client = FakeClient()
    namespace = HealthNamespace(client)

    result = await namespace.ping()

    assert result == {"status": "ok", "pong": True}
    assert client.calls[0]["endpoint"] == "/v1/ping"
    assert client.calls[0]["method"] == "GET"
    assert client.calls[0]["use_gateway"] is True
