"""Provisioning and platform-secret helpers (Node SDK parity)."""
import pytest
from unittest.mock import patch


@pytest.mark.asyncio
async def test_get_platform_secret_returns_value():
    from dominus import dominus

    async def fake_request(endpoint, method="POST", body=None, **kwargs):
        assert endpoint == "/api/secrets/get"
        assert body == {"key": "PROVISION_NEON_API_KEY"}
        return {"key": "PROVISION_NEON_API_KEY", "value": "secret-val"}

    with patch.object(dominus, "_request", side_effect=fake_request):
        v = await dominus.secrets.get_platform_secret("PROVISION_NEON_API_KEY")
        assert v == "secret-val"


@pytest.mark.asyncio
async def test_get_platform_secret_missing_returns_none():
    from dominus import dominus

    async def fake_request(endpoint, method="POST", body=None, **kwargs):
        return {}

    with patch.object(dominus, "_request", side_effect=fake_request):
        v = await dominus.secrets.get_platform_secret("MISSING")
        assert v is None


@pytest.mark.asyncio
async def test_sync_schema_passes_headers_and_body():
    from dominus import dominus

    calls = []

    async def fake_request(**kwargs):
        calls.append(kwargs)
        return {"ok": True}

    with patch.object(dominus, "_request", side_effect=fake_request):
        await dominus.db.sync_schema(
            owner_email="a@b.com",
            app_slug="myapp",
            environment="production",
            timeout=60.0,
        )
    assert len(calls) == 1
    c0 = calls[0]
    assert c0["endpoint"] == "/api/provision/sync"
    assert c0["method"] == "POST"
    assert c0["body"] == {"owner_email": "a@b.com"}
    assert c0["extra_headers"] == {"X-App": "myapp", "X-Env": "production"}


@pytest.mark.asyncio
async def test_provision_neon_delete_uses_delete_with_body():
    from dominus import dominus

    calls = []

    async def fake_request(**kwargs):
        calls.append(kwargs)
        return {"deleted": True}

    with patch.object(dominus, "_request", side_effect=fake_request):
        await dominus.db.provision_neon_delete(app_slug="proj-x", timeout=90.0)
    assert len(calls) == 1
    assert calls[0]["method"] == "DELETE"
    assert calls[0]["body"] == {"app_slug": "proj-x"}
    assert calls[0]["endpoint"] == "/api/provision/delete"
