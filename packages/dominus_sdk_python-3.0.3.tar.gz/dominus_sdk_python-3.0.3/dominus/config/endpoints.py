"""
Dominus SDK Endpoints

Gateway URL for service routing and health checks.
JWT URL for authentication (JWT minting) — defaults to the same host as the gateway.
Logs URL for log ingestion.
Base URL for SDK requests (defaults to gateway).

Defaults always target the production gateway. They do not depend on the caller’s
git branch, PyPI package variant, or deployment environment. Override only with
DOMINUS_* env vars for local or advanced routing.

Configuration:
    Set DOMINUS_GATEWAY_URL to override the gateway URL.
    Set DOMINUS_JWT_URL to override the JWT minting URL (defaults to gateway URL).
    Set DOMINUS_LOGS_URL to override the logs URL.
    Set DOMINUS_BASE_URL to override the SDK request base URL.
    Example: export DOMINUS_BASE_URL=http://localhost:5000

Usage:
    from dominus.config.endpoints import GATEWAY_URL, JWT_URL, LOGS_URL, get_gateway_url, get_jwt_url, get_logs_url
"""
import os

# Production gateway (Cloudflare Worker). Canonical default for all SDK HTTP traffic.
_DEFAULT_GATEWAY_URL = "https://gateway.getdominus.app"
_DEFAULT_LOGS_URL = "https://logs.getdominus.app"

# Gateway URL for service routing (can be overridden via DOMINUS_GATEWAY_URL)
GATEWAY_URL = os.environ.get("DOMINUS_GATEWAY_URL", _DEFAULT_GATEWAY_URL)

# JWT mint/JWKS: same host as gateway by default (matches Node SDK).
JWT_URL = os.environ.get("DOMINUS_JWT_URL", GATEWAY_URL)

# Logs URL for log ingestion (can be overridden via DOMINUS_LOGS_URL)
LOGS_URL = os.environ.get("DOMINUS_LOGS_URL", _DEFAULT_LOGS_URL)

# Base URL for non-gateway SDK paths defaults to the same resolved gateway URL.
BASE_URL = os.environ.get("DOMINUS_BASE_URL", GATEWAY_URL)

# Legacy aliases retained as gateway-first aliases.
SOVEREIGN_URL = BASE_URL
ARCHITECT_URL = BASE_URL
ORCHESTRATOR_URL = BASE_URL
WARDEN_URL = BASE_URL

# Proxy configuration (optional)
# DOMINUS_* variants take precedence over standard HTTP_PROXY/HTTPS_PROXY
HTTP_PROXY = os.environ.get("DOMINUS_HTTP_PROXY") or os.environ.get("HTTP_PROXY")
HTTPS_PROXY = os.environ.get("DOMINUS_HTTPS_PROXY") or os.environ.get("HTTPS_PROXY")


def get_proxy_config() -> str | None:
    """
    Get proxy URL for httpx clients.

    Returns a single proxy URL string for httpx's `proxy` parameter (0.28+),
    or None if no proxy is configured.

    Environment variables (in order of precedence):
        - DOMINUS_HTTPS_PROXY / DOMINUS_HTTP_PROXY (SDK-specific)
        - HTTPS_PROXY / HTTP_PROXY (standard)

    Returns:
        Proxy URL string or None.
    """
    return HTTPS_PROXY or HTTP_PROXY or None


def get_gateway_url() -> str:
    """
    Get the dominus-gateway base URL for service routing.

    Returns the value of DOMINUS_GATEWAY_URL environment variable if set,
    otherwise returns the default Cloudflare Worker URL.
    """
    return os.environ.get("DOMINUS_GATEWAY_URL", _DEFAULT_GATEWAY_URL)


def get_jwt_url() -> str:
    """
    Get the base URL for JWT mint/JWKS (defaults to the same host as the gateway).

    Returns DOMINUS_JWT_URL if set, otherwise the same resolution as get_gateway_url().
    """
    return os.environ.get("DOMINUS_JWT_URL", get_gateway_url())


def get_logs_url() -> str:
    """
    Get the logs worker URL for log ingestion.

    Returns the value of DOMINUS_LOGS_URL environment variable if set,
    otherwise returns the default Cloudflare Worker URL.
    """
    return os.environ.get("DOMINUS_LOGS_URL", _DEFAULT_LOGS_URL)


def get_base_url() -> str:
    """
    Get the SDK request base URL.

    Returns DOMINUS_BASE_URL if set, otherwise the same resolution as get_gateway_url().
    """
    return os.environ.get("DOMINUS_BASE_URL", get_gateway_url())


# DEPRECATED - use get_base_url()
def get_sovereign_url(environment: str = None) -> str:
    """Deprecated: Use get_base_url() instead."""
    return BASE_URL


def get_architect_url(environment: str = None) -> str:
    """Deprecated: Use get_base_url() instead."""
    return BASE_URL


def get_service_url(service: str, environment: str = None) -> str:
    """Deprecated: Use get_base_url() instead. All services are now consolidated."""
    return BASE_URL
