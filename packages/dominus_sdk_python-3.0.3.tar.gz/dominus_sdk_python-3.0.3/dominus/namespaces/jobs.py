"""
Jobs Namespace - Background job queue management.

Provides job enqueueing, status polling, result retrieval, and dead-letter
queue management. Routes through gateway to job-worker.

Usage:
    from dominus import dominus

    # Enqueue a job
    result = await dominus.jobs.enqueue("db_query", {"query": "SELECT 1"})

    # Poll for result
    result = await dominus.jobs.get_result(result["job_id"], timeout_ms=30000)

    # List jobs
    jobs = await dominus.jobs.list(status="pending")

    # Dead letter queue
    dead = await dominus.jobs.list_dead_letter()
    await dominus.jobs.retry_job(dead["dead_jobs"][0]["jobs"][0]["id"])
"""
from typing import Any, Dict, List, Literal, Optional, Union, TYPE_CHECKING

if TYPE_CHECKING:
    from ..start import Dominus

# Job type literals
JobType = Literal["db_query", "db_ddl", "db_migration", "file_upload", "workflow_exec"]
JobStatus = Literal["pending", "running", "completed", "failed", "dead"]


class JobsNamespace:
    """
    Job queue namespace.

    All operations route through gateway to job-worker.
    """

    def __init__(self, client: "Dominus"):
        self._client = client

    async def _api(
        self,
        endpoint: str,
        method: str = "POST",
        body: Optional[Dict[str, Any]] = None,
        timeout: float = 30.0,
    ) -> Dict[str, Any]:
        """Make gateway-routed request to job-worker."""
        return await self._client._request(
            endpoint=endpoint,
            method=method,
            body=body,
            use_gateway=True,
            timeout=timeout,
        )

    async def enqueue(
        self,
        job_type: str,
        payload: Any,
    ) -> Dict[str, Any]:
        """
        Enqueue a new job for asynchronous processing.

        Args:
            job_type: Job type (db_query, db_ddl, db_migration, file_upload, workflow_exec)
            payload: Job-specific payload data

        Returns:
            {job_id, promise_key, poll_url}
        """
        return await self._api(
            "/api/job/enqueue",
            body={"job_type": job_type, "payload": payload},
        )

    async def get_status(self, job_id: str) -> Dict[str, Any]:
        """
        Check the status of a job.

        Args:
            job_id: The job ID to check

        Returns:
            {job_id, type, status, created_at, started_at?, completed_at?, retry_count, error?}
        """
        return await self._api("/api/job/status", body={"job_id": job_id})

    async def get_result(
        self,
        job_id: str,
        timeout_ms: int = 30000,
    ) -> Dict[str, Any]:
        """
        Poll for a job result (blocks until complete or timeout).

        Args:
            job_id: The job ID to wait for
            timeout_ms: Max wait time in ms (default 30000, max 120000)

        Returns:
            {job_id, status, result, timeout?}
        """
        # SDK timeout = server timeout + 5s buffer, capped at 125s
        sdk_timeout = min(timeout_ms + 5000, 125000) / 1000.0
        return await self._api(
            "/api/job/result",
            body={"job_id": job_id, "timeout_ms": timeout_ms},
            timeout=sdk_timeout,
        )

    async def list_dead_letter(
        self,
        job_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        List dead-lettered jobs, optionally filtered by type.

        Args:
            job_type: Optional job type filter

        Returns:
            {dead_jobs: [{type, jobs: [...]}]}
        """
        body: Dict[str, Any] = {"action": "list"}
        if job_type:
            body["job_type"] = job_type
        return await self._api("/api/job/dead-letter", body=body)

    async def retry_job(self, job_id: str) -> Dict[str, Any]:
        """
        Retry a dead-lettered job (re-queues it).

        Args:
            job_id: The dead job ID to retry

        Returns:
            {retried: bool, job_id: str}
        """
        return await self._api(
            "/api/job/dead-letter",
            body={"action": "retry", "job_id": job_id},
        )

    async def discard_job(self, job_id: str) -> Dict[str, Any]:
        """
        Permanently discard a dead-lettered job.

        Args:
            job_id: The dead job ID to discard

        Returns:
            {discarded: bool, job_id: str}
        """
        return await self._api(
            "/api/job/dead-letter",
            body={"action": "discard", "job_id": job_id},
        )

    async def list(
        self,
        status: Optional[str] = None,
        job_type: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        List jobs with optional filters. Automatically sweeps stale pending jobs.

        Args:
            status: Filter by status (pending, running, completed, failed, dead)
            job_type: Filter by job type
            limit: Max items to return

        Returns:
            {jobs: [...], total: int, swept: int}
        """
        body: Dict[str, Any] = {}
        if status:
            body["status"] = status
        if job_type:
            body["job_type"] = job_type
        if limit is not None:
            body["limit"] = limit
        return await self._api("/api/job/list", body=body)

    async def get_health(self) -> Dict[str, Any]:
        """Check job worker health."""
        return await self._api("/api/job/health", method="GET")
