"""
Processor Namespace - Job execution processor.

Provides batch and single job processing operations.
Routes through gateway to processor Cloud Run service.

Usage:
    from dominus import dominus

    # Process all queued jobs
    result = await dominus.processor.process_all()

    # Process a single job (debug/testing)
    result = await dominus.processor.process_one(job_type="db_query")

    # Health check
    health = await dominus.processor.get_health()
"""
from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..start import Dominus


class ProcessorNamespace:
    """
    Job processor namespace.

    Runs on Cloud Run with extended timeouts for batch operations.
    All operations route through gateway to processor service.
    """

    def __init__(self, client: "Dominus"):
        self._client = client

    async def _api(
        self,
        endpoint: str,
        method: str = "POST",
        body: Optional[Dict[str, Any]] = None,
        timeout: float = 30.0,
    ) -> Dict[str, Any]:
        """Make gateway-routed request to processor service."""
        return await self._client._request(
            endpoint=endpoint,
            method=method,
            body=body,
            use_gateway=True,
            timeout=timeout,
        )

    async def get_health(self) -> Dict[str, Any]:
        """Check processor health."""
        return await self._api("/api/processor/health", method="GET")

    async def process_all(
        self,
        job_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Process all queued jobs for the current project/environment.

        Args:
            job_type: Optional filter by job type
                (db_query, db_ddl, db_migration, file_upload, workflow_exec)

        Returns:
            {processed: int}
        """
        body: Dict[str, Any] = {}
        if job_type:
            body["job_type"] = job_type
        return await self._api(
            "/api/processor/process",
            body=body,
            timeout=300.0,  # 5 minutes for batch processing
        )

    async def process_one(
        self,
        job_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Process a single job from the queue (debug/testing).

        Args:
            job_type: Optional filter by job type

        Returns:
            {job_id, status, result}
        """
        body: Dict[str, Any] = {}
        if job_type:
            body["job_type"] = job_type
        return await self._api(
            "/api/processor/process-one",
            body=body,
            timeout=120.0,  # 2 minutes for single job
        )
