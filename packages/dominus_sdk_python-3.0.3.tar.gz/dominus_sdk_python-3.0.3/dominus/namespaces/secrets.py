"""
Secrets Namespace - Warden secrets management.

Provides CRUD operations for secrets stored in the Warden service.
"""
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..start import Dominus


class SecretsNamespace:
    """
    Secrets management namespace.

    All secrets operations use /api/warden/secrets, routed through the Dominus
    gateway (aligned with DB/Redis worker traffic).

    Usage:
        value = await dominus.secrets.get("API_KEY")
        await dominus.secrets.upsert("API_KEY", "secret_value")
        secrets = await dominus.secrets.list(prefix="DB_")
        await dominus.secrets.delete("OLD_KEY")
    """

    def __init__(self, client: "Dominus"):
        self._client = client

    async def get(self, key: str) -> Any:
        """
        Get a secret value.

        Args:
            key: Secret key name

        Returns:
            Secret value (usually string, but can be any JSON-serializable value)

        Raises:
            NotFoundError: If secret doesn't exist
        """
        result = await self._client._request(
            endpoint="/api/warden/secrets",
            body={"action": "get", "key": key},
            use_gateway=True,
        )
        # Response format: {"secret": {"key": "...", "value": "..."}}
        secret = result.get("secret", {})
        return secret.get("value")

    async def upsert(
        self,
        key: str,
        value: str,
        comment: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Create or update a secret.

        Tries update first, falls back to create if secret doesn't exist.

        Args:
            key: Secret key name
            value: Secret value
            comment: Optional comment/description

        Returns:
            Operation result with created/updated status
        """
        body = {"action": "update", "key": key, "value": value}
        if comment:
            body["comment"] = comment

        try:
            result = await self._client._request(
                endpoint="/api/warden/secrets",
                body=body,
                use_gateway=True,
            )
            result["operation"] = "updated"
            return result
        except Exception as e:
            # If update fails (secret doesn't exist), try create
            status = getattr(e, "status_code", None)
            if status is None and hasattr(e, "response"):
                status = getattr(getattr(e, "response", None), "status_code", None)
            if status == 500:
                body["action"] = "create"
                result = await self._client._request(
                    endpoint="/api/warden/secrets",
                    body=body,
                    use_gateway=True,
                )
                result["operation"] = "created"
                return result
            raise

    async def list(self, prefix: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        List secrets, optionally filtered by prefix.

        Args:
            prefix: Optional key prefix filter (e.g., "DB_" for all DB secrets)

        Returns:
            List of secret metadata (keys only, not values)
        """
        body = {"action": "list"}
        if prefix:
            body["prefix"] = prefix

        result = await self._client._request(
            endpoint="/api/warden/secrets",
            body=body,
            use_gateway=True,
        )
        return result.get("secrets", [])

    async def delete(self, key: str) -> Dict[str, Any]:
        """
        Delete a secret.

        Args:
            key: Secret key to delete

        Returns:
            Operation result with deleted status
        """
        return await self._client._request(
            endpoint="/api/warden/secrets",
            body={"action": "delete", "key": key},
            use_gateway=True,
        )

    async def get_platform_secret(self, key: str) -> Optional[str]:
        """
        Read a platform secret via Secrets Worker (``/svc/secrets/get``).

        Use for global provisioning keys (e.g. ``PROVISION_NEON_API_KEY``), distinct from
        Warden project-scoped secrets (:meth:`get` / :meth:`upsert` on ``/api/warden/secrets``).
        """
        data = await self._client._request(
            endpoint="/api/secrets/get",
            method="POST",
            body={"key": key},
            use_gateway=True,
        )
        if isinstance(data, dict):
            val = data.get("value")
            if val is not None and val != "":
                return str(val)
        return None

    async def set_project_secret(
        self,
        *,
        key: str,
        value: str,
        environment: str,
        project_id: str,
    ) -> Dict[str, Any]:
        """Set one Infisical secret for an environment (``POST /api/secrets/set``)."""
        return await self._client._request(
            endpoint="/api/secrets/set",
            method="POST",
            body={
                "key": key,
                "value": value,
                "environment": environment,
                "target_project_id": project_id,
            },
            use_gateway=True,
        )

    async def delete_project_secret(
        self,
        *,
        key: str,
        environment: str,
        project_id: str,
    ) -> Dict[str, Any]:
        """Delete one Infisical secret for an environment (``POST /api/secrets/delete``)."""
        return await self._client._request(
            endpoint="/api/secrets/delete",
            method="POST",
            body={
                "key": key,
                "environment": environment,
                "target_project_id": project_id,
            },
            use_gateway=True,
        )

    async def list_secrets_all_environments(
        self, infisical_project_id: str
    ) -> Dict[str, Any]:
        """Warden grid: secrets across environments for an Infisical project id."""
        return await self._client._request(
            endpoint="/api/warden/secrets",
            body={
                "action": "list-all-environments",
                "infisical_project_id": infisical_project_id,
            },
            use_gateway=True,
        )
