"""
Database Namespace - DB Worker data CRUD operations.

Routes all database operations through the DB Worker (Cloudflare Worker)
via the gateway at /svc/database/*.

Parity target: dominus-sdk-nodejs/src/namespaces/db.ts (provisioning helpers aligned with Node)
"""
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..start import Dominus


class DbNamespace:
    """
    Database CRUD namespace.

    All data operations go through /api/database/* endpoints via the gateway.
    The gateway routes these to the dominus-db-worker (Cloudflare Worker).

    Usage:
        # List schemas
        schemas = await dominus.db.schemas()

        # Query with filters
        result = await dominus.db.query("users", filters={"status": "active"})

        # Query shared hub tables
        companies = await dominus.db.query("hub_companies", use_shared=True)

        # Insert data
        await dominus.db.insert("users", {"name": "John", "email": "john@example.com"})

        # Raw SQL
        result = await dominus.db.raw("SELECT * FROM auth.users WHERE id = $1", [user_id])

        # Transaction
        result = await dominus.db.transaction([
            {"sql": "UPDATE accounts SET balance = balance - $1 WHERE id = $2", "params": [100, from_id]},
            {"sql": "UPDATE accounts SET balance = balance + $1 WHERE id = $2", "params": [100, to_id]},
        ])
    """

    def __init__(self, client: "Dominus"):
        self._client = client

    async def schemas(self, use_shared: bool = False, open: bool = False) -> List[str]:
        """
        List accessible schemas.

        Returns schemas that the current user can access (public, tenant_*, etc.)
        Excludes system schemas (pg_catalog, information_schema, etc.)
        """
        body: Dict[str, Any] = {}
        if use_shared:
            body["use_shared"] = True
        if open:
            body["open"] = True

        result = await self._client._request(
            endpoint="/api/database/schemas",
            body=body,
            use_gateway=True
        )
        if isinstance(result, dict):
            return result.get("schemas", [])
        return result if isinstance(result, list) else []

    async def tables(self, schema: str = "public", use_shared: bool = False, open: bool = False) -> List[Dict[str, Any]]:
        """
        List tables in a schema.

        Args:
            schema: Schema name (default: "public")
            use_shared: If True, query the shared project database
            open: If True, use the open (user-facing) database role
        """
        body: Dict[str, Any] = {"schema": schema}
        if use_shared:
            body["use_shared"] = True
        if open:
            body["open"] = True

        result = await self._client._request(
            endpoint="/api/database/tables",
            body=body,
            use_gateway=True
        )
        if isinstance(result, dict):
            return result.get("tables", [])
        return result if isinstance(result, list) else []

    async def columns(self, table: str, schema: str = "public", use_shared: bool = False, open: bool = False) -> List[Dict[str, Any]]:
        """
        List columns in a table.

        Args:
            table: Table name
            schema: Schema name (default: "public")
            use_shared: If True, query the shared project database
            open: If True, use the open (user-facing) database role
        """
        body: Dict[str, Any] = {"table": table, "schema": schema}
        if use_shared:
            body["use_shared"] = True
        if open:
            body["open"] = True

        result = await self._client._request(
            endpoint="/api/database/columns",
            body=body,
            use_gateway=True
        )
        if isinstance(result, dict):
            return result.get("columns", [])
        return result if isinstance(result, list) else []

    async def query(
        self,
        table: str,
        schema: str = "public",
        filters: Optional[Dict[str, Any]] = None,
        sort_by: Optional[str] = None,
        sort_order: str = "ASC",
        limit: int = 100,
        offset: int = 0,
        use_shared: bool = False,
        columns: Optional[List[str]] = None,
        order_by: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """
        Query table data with filtering, sorting, and pagination.

        Args:
            table: Table name
            schema: Schema name (default: "public")
            filters: Column:value filter dictionary (sent as 'where' to DB Worker)
            sort_by: Column to sort by
            sort_order: "ASC" or "DESC"
            limit: Maximum rows to return (default: 100)
            offset: Rows to skip (default: 0)
            use_shared: If True, query the shared project database
            columns: Optional list of column names to select
            order_by: Optional list of {"column": str, "direction": str} (overrides sort_by)

        Returns:
            Dict with "rows" and "total" keys
        """
        resolved_order_by: Optional[List[Dict[str, Any]]]
        if order_by:
            resolved_order_by = order_by
        elif sort_by:
            resolved_order_by = [{"column": sort_by, "direction": sort_order}]
        else:
            resolved_order_by = None

        body: Dict[str, Any] = {
            "table": table,
            "schema": schema,
            "where": filters,
            "order_by": resolved_order_by,
            "limit": limit,
            "offset": offset,
        }
        if columns:
            body["columns"] = columns
        if use_shared:
            body["use_shared"] = True

        result = await self._client._request(
            endpoint="/api/database/select",
            body=body,
            use_gateway=True
        )

        return {
            "rows": result.get("rows", []) if isinstance(result, dict) else [],
            "total": result.get("row_count", 0) if isinstance(result, dict) else 0,
        }

    async def insert(
        self,
        table: str,
        data: Dict[str, Any],
        schema: str = "public",
        use_shared: bool = False,
        actor: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Insert a row into a table.

        Args:
            table: Table name
            data: Column:value dictionary
            schema: Schema name (default: "public")
            use_shared: If True, write to the shared project database

        Returns:
            Inserted row data
        """
        body: Dict[str, Any] = {
            "table": table,
            "schema": schema,
            "data": data,
            "returning": ["*"],
        }
        if use_shared:
            body["use_shared"] = True

        result = await self._client._request(
            endpoint="/api/database/insert",
            body=body,
            use_gateway=True,
            actor=actor,
        )

        if isinstance(result, dict) and "rows" in result:
            return result["rows"][0] if result["rows"] else result
        return result

    async def update(
        self,
        table: str,
        data: Dict[str, Any],
        filters: Dict[str, Any],
        schema: str = "public",
        use_shared: bool = False,
        actor: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Update rows matching filters.

        Args:
            table: Table name
            data: Column:value dictionary of updates
            filters: Column:value dictionary for WHERE clause (sent as 'where' to DB Worker)
            schema: Schema name (default: "public")
            use_shared: If True, write to the shared project database

        Returns:
            Dict with "affected_rows" count
        """
        body: Dict[str, Any] = {
            "table": table,
            "schema": schema,
            "data": data,
            "where": filters,
            "returning": ["*"],
        }
        if use_shared:
            body["use_shared"] = True

        result = await self._client._request(
            endpoint="/api/database/update",
            body=body,
            use_gateway=True,
            actor=actor,
        )

        return {"affected_rows": result.get("row_count", 0) if isinstance(result, dict) else 0}

    async def delete(
        self,
        table: str,
        filters: Dict[str, Any],
        schema: str = "public",
        use_shared: bool = False,
        actor: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Delete rows matching filters.

        Args:
            table: Table name
            filters: Column:value dictionary for WHERE clause (sent as 'where' to DB Worker)
            schema: Schema name (default: "public")
            use_shared: If True, delete from the shared project database

        Returns:
            Dict with "affected_rows" count
        """
        body: Dict[str, Any] = {
            "table": table,
            "schema": schema,
            "where": filters,
            "returning": ["*"],
        }
        if use_shared:
            body["use_shared"] = True

        result = await self._client._request(
            endpoint="/api/database/delete",
            body=body,
            use_gateway=True,
            actor=actor,
        )

        return {"affected_rows": result.get("row_count", 0) if isinstance(result, dict) else 0}

    async def raw(
        self,
        sql: str,
        params: Optional[List[Any]] = None,
        schema: str = "public",
        use_shared: bool = False,
        actor: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """
        Execute raw SQL queries.

        Args:
            sql: SQL query with $1, $2 style placeholders
            params: Parameter values for placeholders
            schema: Schema name (default: "public")
            use_shared: If True, query the shared project database

        Returns:
            Dict with "rows" and "total" keys
        """
        body: Dict[str, Any] = {
            "sql": sql,
            "params": params or [],
            "schema": schema,
        }
        if use_shared:
            body["use_shared"] = True

        result = await self._client._request(
            endpoint="/api/database/raw",
            body=body,
            use_gateway=True,
            actor=actor,
        )

        return {
            "rows": result.get("rows", []) if isinstance(result, dict) else [],
            "total": result.get("row_count", 0) if isinstance(result, dict) else 0,
        }

    async def bulk_insert(
        self,
        table: str,
        rows: List[Dict[str, Any]],
        schema: str = "public",
        use_shared: bool = False,
    ) -> Dict[str, Any]:
        """
        Insert multiple rows at once using a raw SQL transaction.

        Args:
            table: Table name
            rows: List of column:value dictionaries
            schema: Schema name (default: "public")
            use_shared: If True, write to the shared project database

        Returns:
            Dict with "inserted_count" and optionally "rows"
        """
        if not rows:
            return {"inserted_count": 0, "rows": []}

        columns = list(rows[0].keys())
        quoted_cols = ", ".join(f'"{c}"' for c in columns)
        params: List[Any] = []
        value_clauses: List[str] = []

        for row in rows:
            placeholders = []
            for col in columns:
                params.append(row.get(col))
                placeholders.append(f"${len(params)}")
            value_clauses.append(f"({', '.join(placeholders)})")

        sql = f'INSERT INTO "{table}" ({quoted_cols}) VALUES {", ".join(value_clauses)} RETURNING *'

        result = await self.raw(sql, params, schema=schema, use_shared=use_shared)

        return {
            "inserted_count": result.get("total", 0),
            "rows": result.get("rows", []),
        }

    async def transaction(
        self,
        statements: List[Dict[str, Any]],
        schema: str = "public",
        use_shared: bool = False,
    ) -> Dict[str, Any]:
        """
        Execute multiple SQL statements in a single atomic transaction.

        Args:
            statements: List of dicts with 'sql' and optional 'params' keys
            schema: Schema name (default: "public")
            use_shared: If True, execute against the shared project database

        Returns:
            Dict with "results" array containing rows and row_count per statement
        """
        body: Dict[str, Any] = {
            "statements": statements,
            "schema": schema,
        }
        if use_shared:
            body["use_shared"] = True

        return await self._client._request(
            endpoint="/api/database/transaction",
            body=body,
            use_gateway=True
        )

    # ========================================
    # PROVISIONING (database Cloud Run / gateway)
    # ========================================

    async def sync_schema(
        self,
        *,
        owner_email: Optional[str] = None,
        app_slug: Optional[str] = None,
        environment: Optional[str] = None,
        timeout: float = 120.0,
    ) -> Dict[str, Any]:
        """
        Sync protected schemas to factory default (idempotent).

        ``POST /api/provision/sync`` — optional ``X-App`` / ``X-Env`` for gateway scope.
        """
        body: Dict[str, Any] = {}
        if owner_email:
            body["owner_email"] = owner_email
        extra: Dict[str, str] = {}
        if app_slug:
            extra["X-App"] = app_slug
        if environment:
            extra["X-Env"] = environment
        cap = min(timeout, 300.0)
        return await self._client._request(
            endpoint="/api/provision/sync",
            method="POST",
            body=body,
            use_gateway=True,
            timeout=cap,
            extra_headers=extra or None,
        )

    async def provision_neon_complete(
        self,
        *,
        app_slug: str,
        region: Optional[str] = None,
        timeout: float = 300.0,
    ) -> Dict[str, Any]:
        """Full Neon provisioning via ``POST /api/provision/complete``."""
        cap = min(timeout, 300.0)
        return await self._client._request(
            endpoint="/api/provision/complete",
            method="POST",
            body={
                "app_slug": app_slug,
                "region": region or "aws-us-east-1",
            },
            use_gateway=True,
            timeout=cap,
        )

    async def provision_neon_delete(
        self,
        *,
        app_slug: str,
        timeout: float = 120.0,
    ) -> Dict[str, Any]:
        """Neon teardown via ``DELETE /api/provision/delete``."""
        cap = min(timeout, 300.0)
        return await self._client._request(
            endpoint="/api/provision/delete",
            method="DELETE",
            body={"app_slug": app_slug},
            use_gateway=True,
            timeout=cap,
        )
