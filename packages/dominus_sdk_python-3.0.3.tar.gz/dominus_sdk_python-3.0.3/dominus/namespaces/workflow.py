"""
Workflow Namespace - Workflow management operations.

Provides CRUD operations for workflows, pipelines, and templates.
Routes through gateway to dominus-workflow-manager service.

Usage:
    from dominus import dominus

    # Workflow CRUD
    workflow = await dominus.workflow.save(
        name="My Workflow",
        yaml_content="name: My Workflow\nnodes: []",
        description="A test workflow"
    )
    workflows = await dominus.workflow.list()
    workflow = await dominus.workflow.get(workflow_id, include_content=True)
    await dominus.workflow.delete(workflow_id)

    # Pipelines (execution groups)
    pipeline = await dominus.workflow.create_pipeline(
        name="Intake Pipeline",
        description="Patient intake workflow sequence"
    )
    await dominus.workflow.add_to_pipeline(pipeline_id, workflow_id)
    pipelines = await dominus.workflow.list_pipelines()

    # Templates
    templates = await dominus.workflow.list_templates()
    await dominus.workflow.copy_template(template_id)

    # Workflow tool registry (builtin / http / custom tools)
    tools = await dominus.workflow.list_tools(limit=50)
    await dominus.workflow.register_tool({"slug": "my-tool", "name": "My Tool", "tool_type": "http"})

    # Canonical saved-workflow launch (Authority POST /api/authority/runs/ensure)
    execution = await dominus.workflow.ensure(
        "my-workflow-id",
        subject="PCM47474562",
        company="acme",
        inputs={"key": "value"},
        mode="async",
    )
    # Legacy create_run / validate_run / start_run against /api/workflow/runs are removed.
"""
import base64
import json
import uuid
from typing import Any, Dict, List, Optional, TYPE_CHECKING
from urllib.parse import urlencode

if TYPE_CHECKING:
    from ..start import Dominus


class WorkflowNamespace:
    """
    Workflow management namespace.

    Provides operations for workflow CRUD, pipelines, templates,
    and the saved-workflow run lifecycle via the dominus-workflow-manager service.
    """

    def __init__(self, client: "Dominus"):
        self._client = client

    def _reject_retired_workflow_runs_api(self, method: str) -> None:
        raise RuntimeError(
            f"dominus.workflow.{method} was removed: /api/workflow/runs is retired. "
            "Use ensure() through Authority."
        )

    @staticmethod
    def _is_workflow_ref(value: Optional[str]) -> bool:
        return str(value or "").strip().startswith("wf://")

    @classmethod
    def _workflow_lookup_endpoint(
        cls,
        workflow_id_or_ref: str,
        include_content: bool = False,
    ) -> str:
        if cls._is_workflow_ref(workflow_id_or_ref):
            return "/api/workflow/workflows/by-ref?" + urlencode({
                "workflow_ref": workflow_id_or_ref,
                "include_content": "true" if include_content else "false",
            })

        endpoint = f"/api/workflow/workflows/{workflow_id_or_ref}"
        if include_content:
            endpoint += "?include_content=true"
        return endpoint

    @staticmethod
    def _workflow_identifier_body(
        workflow_id: Optional[str] = None,
        workflow_ref: Optional[str] = None,
    ) -> Dict[str, Any]:
        if workflow_ref and str(workflow_ref).strip():
            return {"workflow_ref": str(workflow_ref).strip()}
        if WorkflowNamespace._is_workflow_ref(workflow_id):
            return {"workflow_ref": str(workflow_id).strip()}
        if workflow_id and str(workflow_id).strip():
            return {"workflow_id": str(workflow_id).strip()}
        raise ValueError("workflow_id or workflow_ref is required")

    @staticmethod
    def _instance_base_endpoint(workflow_id: str) -> str:
        from urllib.parse import quote

        return f"/api/workflow/workflows/{quote(workflow_id, safe='')}/instances"

    @staticmethod
    def _build_instance_nudge_policy(
        nudge_policy: Optional[Dict[str, Any]] = None,
    ) -> Optional[Dict[str, Any]]:
        if not nudge_policy:
            return None

        policy = dict(nudge_policy)
        result: Dict[str, Any] = {}
        if "mode" in policy and policy["mode"] is not None:
            result["mode"] = policy["mode"]
        if "max_rerun_count" in policy and policy["max_rerun_count"] is not None:
            result["max_rerun_count"] = policy["max_rerun_count"]
        elif "maxRerunCount" in policy and policy["maxRerunCount"] is not None:
            result["max_rerun_count"] = policy["maxRerunCount"]
        if "rerun_window_seconds" in policy and policy["rerun_window_seconds"] is not None:
            result["rerun_window_seconds"] = policy["rerun_window_seconds"]
        elif "rerunWindowSeconds" in policy and policy["rerunWindowSeconds"] is not None:
            result["rerun_window_seconds"] = policy["rerunWindowSeconds"]

        for key, value in policy.items():
            if value is None:
                continue
            if key in {"mode", "max_rerun_count", "maxRerunCount", "rerun_window_seconds", "rerunWindowSeconds"}:
                continue
            result[key] = value

        return result or None

    def _build_ensure_instance_body(
        self,
        *,
        group: str,
        owner: str,
        instance_id: Optional[str] = None,
        environment: Optional[str] = None,
        nudge_policy: Optional[Dict[str, Any]] = None,
        bindings: Optional[Dict[str, Any]] = None,
        mode: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {
            "params": {
                "group": group,
                "owner": owner,
            }
        }
        if instance_id:
            body["instance_id"] = instance_id
        if environment:
            body["params"]["env"] = environment
        policy = self._build_instance_nudge_policy(nudge_policy)
        if policy:
            body["params"]["nudge_policy"] = policy
        if bindings:
            body["bindings"] = bindings
        if mode:
            body["mode"] = mode
        if context:
            body["context"] = context
        return body

    @staticmethod
    def _decode_authority_run_id(run_id: str) -> Optional[Dict[str, str]]:
        normalized = str(run_id or "").strip()
        if not normalized:
            return None
        try:
            padding = "=" * ((4 - len(normalized) % 4) % 4)
            decoded = base64.urlsafe_b64decode((normalized + padding).encode("utf-8")).decode("utf-8")
            payload = json.loads(decoded)
        except Exception:
            return None

        required = ("project_id", "environment", "workflow_id", "instance_id")
        if all(isinstance(payload.get(field), str) and str(payload.get(field)).strip() for field in required):
            return {field: str(payload[field]).strip() for field in required}
        return None

    def _is_authority_run_id(self, run_id: str) -> bool:
        return self._decode_authority_run_id(run_id) is not None

    @staticmethod
    def _authority_mutation_body(
        body: Dict[str, Any],
        *,
        idempotency_key: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        result = dict(body)
        if initiator_type:
            result["initiator_type"] = initiator_type
        if initiator_id:
            result["initiator_id"] = initiator_id
        result["idempotency_key"] = idempotency_key or uuid.uuid4().hex
        return result

    def _build_authority_ensure_body(
        self,
        workflow_id: str,
        *,
        workflow_ref: Optional[str] = None,
        subject: Optional[str] = None,
        company: Optional[str] = None,
        inputs: Optional[Dict[str, Any]] = None,
        context: Optional[Dict[str, Any]] = None,
        bindings: Optional[Dict[str, Any]] = None,
        instance_id: Optional[str] = None,
        mode: str = "async",
        target_project_id: Optional[str] = None,
        target_environment: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"mode": mode}
        if workflow_ref:
            body["workflow_ref"] = workflow_ref
        elif self._is_workflow_ref(workflow_id):
            body["workflow_ref"] = workflow_id
        else:
            body["workflow_id"] = workflow_id
        if subject is not None:
            body["subject"] = subject
        if company is not None:
            body["company"] = company
        if inputs:
            body["inputs"] = inputs
        if context:
            body["context"] = context
        if bindings:
            body["bindings"] = bindings
        if instance_id:
            body["instance_id"] = instance_id
        if target_project_id:
            body["target_org_id"] = target_project_id
        if target_environment:
            body["target_env"] = target_environment
        return self._authority_mutation_body(
            body,
            idempotency_key=idempotency_key,
            initiator_type=initiator_type,
            initiator_id=initiator_id,
        )

    async def _api(
        self,
        endpoint: str,
        method: str = "POST",
        body: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Make gateway-routed API request to workflow-manager."""
        return await self._client._request(
            endpoint=endpoint,
            method=method,
            body=body,
            use_gateway=True
        )

    # ========================================
    # Workflow CRUD
    # ========================================

    async def save(
        self,
        name: str,
        yaml_content: str,
        workflow_id: Optional[str] = None,
        tenant_slug: Optional[str] = None,
        description: Optional[str] = None,
        pipeline_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
        is_template: bool = False,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Save a workflow (create or update).

        Args:
            name: Workflow display name
            yaml_content: YAML workflow definition
            workflow_id: Optional ID for updates (omit for create)
            tenant_slug: Optional tenant scope
            description: Optional description
            pipeline_id: Optional pipeline to assign
            tags: Optional list of tags
            is_template: Whether this is a template
            metadata: Optional builder-owned authoring metadata

        Returns:
            Dict with workflow metadata
        """
        body: Dict[str, Any] = {
            "name": name,
            "yaml_content": yaml_content,
        }
        if workflow_id:
            body["workflow_id"] = workflow_id
        if tenant_slug:
            body["tenant_slug"] = tenant_slug
        if description:
            body["description"] = description
        if pipeline_id:
            body["pipeline_id"] = pipeline_id
        if tags:
            body["tags"] = tags
        if is_template:
            body["is_template"] = is_template
        if metadata:
            body["metadata"] = metadata

        return await self._api(
            endpoint="/api/workflow/workflows",
            body=body
        )

    async def get(
        self,
        workflow_id: str,
        include_content: bool = False
    ) -> Dict[str, Any]:
        """
        Get a workflow by UUID or stable workflow_ref.

        Args:
            workflow_id: Workflow UUID or workflow_ref
            include_content: Whether to include YAML content

        Returns:
            Dict with workflow metadata and optionally content
        """
        if not include_content and self._is_authority_run_id(workflow_id):
            return await self.get_run_state(workflow_id)
        endpoint = self._workflow_lookup_endpoint(workflow_id, include_content=include_content)
        return await self._api(endpoint=endpoint, method="GET")

    async def get_workflow(
        self,
        workflow_id: str,
        include_content: bool = False,
    ) -> Dict[str, Any]:
        endpoint = self._workflow_lookup_endpoint(workflow_id, include_content=include_content)
        return await self._api(endpoint=endpoint, method="GET")

    async def get_by_ref(
        self,
        workflow_ref: str,
        include_content: bool = False,
    ) -> Dict[str, Any]:
        """
        Get a workflow by stable workflow_ref.
        """
        return await self.get(workflow_ref, include_content=include_content)

    async def list(
        self,
        tenant_slug: Optional[str] = None,
        pipeline_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
        is_template: Optional[bool] = None,
        search: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """
        List workflows.

        Args:
            tenant_slug: Filter by tenant
            pipeline_id: Filter by pipeline
            tags: Filter by tags (any match)
            is_template: Filter by template status
            search: Search in name/description
            limit: Max results
            offset: Pagination offset

        Returns:
            List of workflow metadata dicts
        """
        params = [f"limit={limit}", f"offset={offset}"]
        if tenant_slug:
            params.append(f"tenant_slug={tenant_slug}")
        if pipeline_id:
            params.append(f"pipeline_id={pipeline_id}")
        if is_template is not None:
            params.append(f"is_template={str(is_template).lower()}")
        if search:
            params.append(f"search={search}")

        query = "&".join(params)
        endpoint = f"/api/workflow/workflows?{query}" if query else "/api/workflow/workflows"

        result = await self._api(
            endpoint=endpoint,
            method="GET"
        )
        return result.get("workflows", result) if isinstance(result, dict) else result

    async def delete(self, workflow_id: str) -> Dict[str, Any]:
        """
        Delete a workflow.

        Args:
            workflow_id: Workflow UUID

        Returns:
            Dict with deletion status
        """
        return await self._api(
            endpoint=f"/api/workflow/workflows/{workflow_id}",
            method="DELETE"
        )

    # ========================================
    # Pipelines (Execution Groups)
    # ========================================

    async def create_pipeline(
        self,
        name: str,
        tenant_slug: Optional[str] = None,
        description: Optional[str] = None,
        definition: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Create a pipeline (execution group).

        Args:
            name: Pipeline display name
            tenant_slug: Optional tenant scope
            description: Optional description

        Returns:
            Dict with pipeline metadata
        """
        body: Dict[str, Any] = {"name": name}
        if tenant_slug:
            body["tenant_slug"] = tenant_slug
        if description:
            body["description"] = description
        if definition is not None:
            body["definition"] = definition

        return await self._api(
            endpoint="/api/workflow/pipelines",
            body=body
        )

    async def get_pipeline(
        self,
        pipeline_id: str,
        include_workflows: bool = False
    ) -> Dict[str, Any]:
        """
        Get a pipeline by ID.

        Args:
            pipeline_id: Pipeline UUID
            include_workflows: Whether to include workflow list

        Returns:
            Dict with pipeline metadata and optionally workflows
        """
        endpoint = f"/api/workflow/pipelines/{pipeline_id}"
        if include_workflows:
            endpoint += "?include_workflows=true"
        return await self._api(endpoint=endpoint, method="GET")

    async def list_pipelines(
        self,
        tenant_slug: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """
        List pipelines.

        Args:
            tenant_slug: Filter by tenant
            limit: Max results
            offset: Pagination offset

        Returns:
            List of pipeline metadata dicts
        """
        params = [f"limit={limit}", f"offset={offset}"]
        if tenant_slug:
            params.append(f"tenant_slug={tenant_slug}")

        query = "&".join(params)
        endpoint = f"/api/workflow/pipelines?{query}" if query else "/api/workflow/pipelines"

        result = await self._api(
            endpoint=endpoint,
            method="GET"
        )
        return result.get("pipelines", result) if isinstance(result, dict) else result

    async def update_pipeline(
        self,
        pipeline_id: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        definition: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Update pipeline metadata or graph definition.

        Args:
            pipeline_id: Pipeline UUID
            name: Optional replacement name
            description: Optional replacement description
            definition: Optional graph definition (None clears when explicitly sent)

        Returns:
            Dict with updated pipeline metadata
        """
        body: Dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if definition is not None:
            body["definition"] = definition

        return await self._api(
            endpoint=f"/api/workflow/pipelines/{pipeline_id}",
            method="PUT",
            body=body,
        )

    async def delete_pipeline(self, pipeline_id: str) -> Dict[str, Any]:
        """
        Delete a pipeline.

        Args:
            pipeline_id: Pipeline UUID

        Returns:
            Dict with deletion status
        """
        return await self._api(
            endpoint=f"/api/workflow/pipelines/{pipeline_id}",
            method="DELETE"
        )

    async def add_to_pipeline(
        self,
        pipeline_id: str,
        workflow_id: str,
        position: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Add a workflow to a pipeline.

        Args:
            pipeline_id: Pipeline UUID
            workflow_id: Workflow UUID
            position: Optional position in execution order

        Returns:
            Dict with operation status
        """
        body: Dict[str, Any] = {"workflow_id": workflow_id}
        if position is not None:
            body["position"] = position

        return await self._api(
            endpoint=f"/api/workflow/pipelines/{pipeline_id}/workflows",
            body=body
        )

    async def remove_from_pipeline(
        self,
        pipeline_id: str,
        workflow_id: str,
    ) -> Dict[str, Any]:
        """
        Remove a workflow from a pipeline.

        Args:
            pipeline_id: Pipeline UUID
            workflow_id: Workflow UUID

        Returns:
            Dict with operation status
        """
        return await self._api(
            endpoint=f"/api/workflow/pipelines/{pipeline_id}/workflows/{workflow_id}",
            method="DELETE"
        )

    async def reorder_pipeline(
        self,
        pipeline_id: str,
        workflow_order: List[str],
    ) -> Dict[str, Any]:
        """
        Reorder workflows in a pipeline.

        Args:
            pipeline_id: Pipeline UUID
            workflow_order: List of workflow IDs in desired order

        Returns:
            Dict with operation status
        """
        return await self._api(
            endpoint=f"/api/workflow/pipelines/{pipeline_id}/workflows/order",
            method="PUT",
            body={"workflow_order": workflow_order}
        )

    async def execute_pipeline(
        self,
        pipeline_id: str,
        *,
        mode: str = "async",
        context: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        workflow_overrides: Optional[Dict[str, Any]] = None,
        continue_on_error: Optional[bool] = None,
        poll_interval_ms: Optional[int] = None,
        timeout_seconds: Optional[int] = None,
        save_events: Optional[bool] = None,
        resume_execution_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Execute a pipeline through workflow-manager's native orchestration runner.

        The returned execution_id is monitored with the existing execution-scoped
        helpers: status(), output(), messages(), events(), and cancel().
        """
        config: Dict[str, Any] = {"mode": mode}
        if continue_on_error is not None:
            config["continue_on_error"] = continue_on_error
        if poll_interval_ms is not None:
            config["poll_interval_ms"] = poll_interval_ms
        if timeout_seconds is not None:
            config["timeout_seconds"] = timeout_seconds
        if save_events is not None:
            config["save_events"] = save_events
        if resume_execution_id:
            config["resume_execution_id"] = resume_execution_id

        body: Dict[str, Any] = {"config": config}
        if context:
            body["context"] = context
        if metadata:
            body["metadata"] = metadata
        if workflow_overrides:
            body["workflow_overrides"] = workflow_overrides

        return await self._api(
            endpoint=f"/api/workflow/pipelines/{pipeline_id}/execute",
            body=body,
        )

    # ========================================
    # Templates
    # ========================================

    async def list_templates(
        self,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """
        List available templates.

        Args:
            limit: Max results
            offset: Pagination offset

        Returns:
            List of template metadata dicts
        """
        params = [f"limit={limit}", f"offset={offset}"]
        endpoint = f"/api/workflow/templates?{'&'.join(params)}"
        result = await self._api(
            endpoint=endpoint,
            method="GET"
        )
        return result.get("templates", result) if isinstance(result, dict) else result

    async def get_template(
        self,
        template_id: str,
        include_content: bool = False
    ) -> Dict[str, Any]:
        """
        Get a template by ID.

        Args:
            template_id: Template UUID
            include_content: Whether to include YAML content

        Returns:
            Dict with template metadata and optionally content
        """
        endpoint = f"/api/workflow/templates/{template_id}"
        if include_content:
            endpoint += "?include_content=true"
        return await self._api(endpoint=endpoint, method="GET")

    async def copy_template(
        self,
        template_id: str,
        name: Optional[str] = None,
        tenant_slug: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Copy a template to create a new workflow.

        Args:
            template_id: Template UUID to copy
            name: Optional name for the new workflow
            tenant_slug: Optional tenant scope

        Returns:
            Dict with new workflow metadata
        """
        body: Dict[str, Any] = {}
        if name:
            body["name"] = name
        if tenant_slug:
            body["tenant_slug"] = tenant_slug

        return await self._api(
            endpoint=f"/api/workflow/templates/{template_id}/copy",
            body=body
        )

    # ========================================
    # Workflow tool registry (HTTP / custom tools)
    # ========================================

    async def list_tools(
        self,
        *,
        tool_type: Optional[str] = None,
        is_enabled: Optional[bool] = None,
        is_builtin: Optional[bool] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> Dict[str, Any]:
        """
        List tools registered with workflow-manager (builtin, http, custom).

        Returns the decoded API envelope (typically ``tools`` and ``total``).
        """
        query: Dict[str, Any] = {"limit": limit, "offset": offset}
        if tool_type:
            query["tool_type"] = tool_type
        if is_enabled is not None:
            query["is_enabled"] = str(is_enabled).lower()
        if is_builtin is not None:
            query["is_builtin"] = str(is_builtin).lower()
        qs = urlencode(query)
        return await self._api(endpoint=f"/api/workflow/tools?{qs}", method="GET")

    async def get_tool(self, tool_id: str) -> Dict[str, Any]:
        """Get a single workflow tool definition by ID."""
        return await self._api(
            endpoint=f"/api/workflow/tools/{tool_id}",
            method="GET",
        )

    async def register_tool(self, spec: Dict[str, Any]) -> Dict[str, Any]:
        """
        Register a new workflow tool. ``spec`` must include ``slug``, ``name``, and ``tool_type``.
        """
        return await self._api(
            endpoint="/api/workflow/tools",
            body=spec,
        )

    async def update_tool(self, tool_id: str, patch: Dict[str, Any]) -> Dict[str, Any]:
        """Update an existing workflow tool (patch must not be empty)."""
        if not patch:
            raise ValueError("patch must not be empty")
        return await self._api(
            endpoint=f"/api/workflow/tools/{tool_id}",
            method="PUT",
            body=patch,
        )

    async def delete_tool(self, tool_id: str) -> Dict[str, Any]:
        """Delete a workflow tool."""
        return await self._api(
            endpoint=f"/api/workflow/tools/{tool_id}",
            method="DELETE",
        )

    async def enable_tool(self, tool_id: str) -> Dict[str, Any]:
        """Enable a workflow tool."""
        return await self._api(
            endpoint=f"/api/workflow/tools/{tool_id}/enable",
            body={},
        )

    async def disable_tool(self, tool_id: str) -> Dict[str, Any]:
        """Disable a workflow tool."""
        return await self._api(
            endpoint=f"/api/workflow/tools/{tool_id}/disable",
            body={},
        )

    @staticmethod
    def _build_start_config(
        *,
        mode: Optional[str] = None,
        timeout_seconds: Optional[int] = None,
        save_events: Optional[bool] = None,
        webhook_url: Optional[str] = None,
    ) -> Dict[str, Any]:
        config: Dict[str, Any] = {}
        if mode:
            config["mode"] = mode
        if timeout_seconds is not None:
            config["timeout_seconds"] = timeout_seconds
        if save_events is not None:
            config["save_events"] = save_events
        if webhook_url:
            config["webhook_url"] = webhook_url
        return config

    async def create_run(
        self,
        workflow_id: Optional[str] = None,
        *,
        workflow_ref: Optional[str] = None,
        run_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        context: Optional[Dict[str, Any]] = None,
        use_shared: Optional[bool] = None,
        shared_project_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        del workflow_id, workflow_ref, run_id, metadata, context, use_shared, shared_project_id
        self._reject_retired_workflow_runs_api("create_run")

    async def ensure(
        self,
        workflow_id: str,
        *,
        instance_id: Optional[str] = None,
        group: Optional[str] = None,
        owner: Optional[str] = None,
        environment: Optional[str] = None,
        nudge_policy: Optional[Dict[str, Any]] = None,
        bindings: Optional[Dict[str, Any]] = None,
        mode: str = "blocking",
        context: Optional[Dict[str, Any]] = None,
        workflow_ref: Optional[str] = None,
        subject: Optional[str] = None,
        company: Optional[str] = None,
        inputs: Optional[Dict[str, Any]] = None,
        target_project_id: Optional[str] = None,
        target_environment: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Ensure a workflow instance exists and optionally launch execution."""
        if mode == "streaming":
            raise ValueError(
                "dominus.workflow.ensure() is Authority-only and supports blocking, async, or ensure_only. "
                "Use execution polling after launch instead of instance streaming on this surface."
            )
        return await self._api(
            endpoint="/api/authority/runs/ensure",
            body=self._build_authority_ensure_body(
                workflow_id,
                workflow_ref=workflow_ref,
                subject=subject,
                company=company,
                inputs=inputs,
                context=context,
                bindings=bindings,
                instance_id=instance_id,
                mode=mode,
                target_project_id=target_project_id,
                target_environment=target_environment,
                initiator_type=initiator_type,
                initiator_id=initiator_id,
                idempotency_key=idempotency_key,
            ),
        )

    async def ensure_instance(
        self,
        workflow_id: str,
        *,
        instance_id: Optional[str] = None,
        group: str,
        owner: str,
        environment: Optional[str] = None,
        nudge_policy: Optional[Dict[str, Any]] = None,
        bindings: Optional[Dict[str, Any]] = None,
        mode: str = "blocking",
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Advanced instance-control surface for workflow-manager.

        This is not the canonical public launch path. Prefer ensure() for
        Authority-backed launch and use instance APIs only when you
        intentionally need lower-level instance reuse or nudge/retry control.
        """
        if mode == "streaming":
            raise ValueError("Use stream_ensure_instance() for streaming instance execution")

        return await self._api(
            endpoint=f"{self._instance_base_endpoint(workflow_id)}/ensure",
            body=self._build_ensure_instance_body(
                instance_id=instance_id,
                group=group,
                owner=owner,
                environment=environment,
                nudge_policy=nudge_policy,
                bindings=bindings,
                mode=mode,
                context=context,
            ),
        )

    async def stream_ensure_instance(
        self,
        workflow_id: str,
        *,
        instance_id: Optional[str] = None,
        group: str,
        owner: str,
        environment: Optional[str] = None,
        nudge_policy: Optional[Dict[str, Any]] = None,
        bindings: Optional[Dict[str, Any]] = None,
        context: Optional[Dict[str, Any]] = None,
        on_chunk: Optional[Any] = None,
    ):
        """
        Advanced instance-control SSE helper for workflow-manager.

        This bypasses Authority launch and is retained only for explicit,
        lower-level instance operations.
        """
        async for chunk in self._client._stream_request(
            endpoint=f"{self._instance_base_endpoint(workflow_id)}/ensure",
            body=self._build_ensure_instance_body(
                instance_id=instance_id,
                group=group,
                owner=owner,
                environment=environment,
                nudge_policy=nudge_policy,
                bindings=bindings,
                mode="streaming",
                context=context,
            ),
            on_chunk=on_chunk,
            use_gateway=True,
        ):
            yield chunk

    async def get_instance_status(self, workflow_id: str, instance_id: str) -> Dict[str, Any]:
        """Get workflow instance status."""
        from urllib.parse import quote

        return await self._api(
            endpoint=f"{self._instance_base_endpoint(workflow_id)}/{quote(instance_id, safe='')}/status",
            method="GET",
        )

    async def list_instances(
        self,
        *,
        workflow_id: Optional[str] = None,
        group: Optional[str] = None,
        owner: Optional[str] = None,
        environment: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """List workflow instances."""
        params = [f"limit={limit}", f"offset={offset}"]
        if workflow_id:
            params.append(f"workflow_id={workflow_id}")
        if group:
            params.append(f"group={group}")
        if owner:
            params.append(f"owner={owner}")
        if environment:
            params.append(f"environment={environment}")
        if status:
            params.append(f"status={status}")

        result = await self._api(
            endpoint=f"/api/workflow/instances?{'&'.join(params)}",
            method="GET",
        )
        return result.get("instances", result) if isinstance(result, dict) else result

    async def list_runs(
        self,
        *,
        workflow_id: Optional[str] = None,
        subject: Optional[str] = None,
        company: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
        target_project_id: Optional[str] = None,
        target_environment: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        params = [f"limit={limit}", f"offset={offset}"]
        if workflow_id:
            params.append(f"workflow_id={workflow_id}")
        if subject:
            params.append(f"owner={subject}")
        if company:
            params.append(f"group={company}")
        if status:
            params.append(f"status={status}")
        if target_project_id:
            params.append(f"target_org_id={target_project_id}")
        if target_environment:
            params.append(f"target_env={target_environment}")

        result = await self._api(
            endpoint=f"/api/authority/runs?{'&'.join(params)}",
            method="GET",
        )
        return result.get("runs", result) if isinstance(result, dict) else result

    async def get_run_state(self, run_id: str) -> Dict[str, Any]:
        return await self._api(
            endpoint=f"/api/authority/runs/{run_id}",
            method="GET",
        )

    async def get_run_timeline(self, run_id: str) -> Dict[str, Any]:
        return await self._api(
            endpoint=f"/api/authority/runs/{run_id}/timeline",
            method="GET",
        )

    async def get_instance_artifacts(self, workflow_id: str, instance_id: str) -> Dict[str, Any]:
        """Get workflow instance artifact addresses."""
        from urllib.parse import quote

        return await self._api(
            endpoint=f"{self._instance_base_endpoint(workflow_id)}/{quote(instance_id, safe='')}/artifacts",
            method="GET",
        )

    async def get_instance_outputs(self, workflow_id: str, instance_id: str) -> Dict[str, Any]:
        """Get workflow instance accepted outputs."""
        from urllib.parse import quote

        return await self._api(
            endpoint=f"{self._instance_base_endpoint(workflow_id)}/{quote(instance_id, safe='')}/outputs",
            method="GET",
        )

    async def get_instance_history(
        self,
        workflow_id: str,
        instance_id: str,
        *,
        limit: int = 50,
        offset: int = 0,
    ) -> Dict[str, Any]:
        """Get workflow instance execution history."""
        from urllib.parse import quote

        return await self._api(
            endpoint=(
                f"{self._instance_base_endpoint(workflow_id)}/{quote(instance_id, safe='')}/history"
                f"?limit={limit}&offset={offset}"
            ),
            method="GET",
        )

    async def nudge(
        self,
        workflow_id: str,
        instance_id: Optional[str] = None,
        *,
        reason: str,
        trigger_artifact: Optional[str] = None,
        mode: str = "async",
        target_project_id: Optional[str] = None,
        target_environment: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Nudge a workflow instance into a new execution."""
        if instance_id is None and self._is_authority_run_id(workflow_id):
            body: Dict[str, Any] = {"reason": reason, "mode": mode}
            if trigger_artifact:
                body["trigger_artifact"] = trigger_artifact
            if target_project_id:
                body["target_org_id"] = target_project_id
            if target_environment:
                body["target_env"] = target_environment
            return await self._api(
                endpoint=f"/api/authority/runs/{workflow_id}/nudge",
                body=self._authority_mutation_body(
                    body,
                    idempotency_key=idempotency_key,
                    initiator_type=initiator_type,
                    initiator_id=initiator_id,
                ),
            )
        return await self.nudge_instance(
            workflow_id,
            instance_id,
            reason=reason,
            trigger_artifact=trigger_artifact,
            mode=mode,
        )

    async def nudge_instance(
        self,
        workflow_id: str,
        instance_id: str,
        *,
        reason: str,
        trigger_artifact: Optional[str] = None,
        mode: str = "async",
    ) -> Dict[str, Any]:
        """Nudge a workflow instance into a new execution."""
        from urllib.parse import quote

        if mode == "streaming":
            raise ValueError("Use stream_nudge_instance() for streaming instance execution")

        body: Dict[str, Any] = {"reason": reason, "mode": mode}
        if trigger_artifact:
            body["trigger_artifact"] = trigger_artifact

        return await self._api(
            endpoint=f"{self._instance_base_endpoint(workflow_id)}/{quote(instance_id, safe='')}/nudge",
            body=body,
        )

    async def stream_nudge_instance(
        self,
        workflow_id: str,
        instance_id: str,
        *,
        reason: str,
        trigger_artifact: Optional[str] = None,
        on_chunk: Optional[Any] = None,
    ):
        """Nudge a workflow instance and stream execution events."""
        from urllib.parse import quote

        body: Dict[str, Any] = {"reason": reason, "mode": "streaming"}
        if trigger_artifact:
            body["trigger_artifact"] = trigger_artifact

        async for chunk in self._client._stream_request(
            endpoint=f"{self._instance_base_endpoint(workflow_id)}/{quote(instance_id, safe='')}/nudge",
            body=body,
            on_chunk=on_chunk,
            use_gateway=True,
        ):
            yield chunk

    async def retry(
        self,
        workflow_id: str,
        instance_id: Optional[str] = None,
        *,
        reason: str = "retry",
        trigger_artifact: Optional[str] = None,
        mode: str = "async",
        target_project_id: Optional[str] = None,
        target_environment: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Retry a workflow instance. Alias for nudge with a default retry reason."""
        if instance_id is None and self._is_authority_run_id(workflow_id):
            body: Dict[str, Any] = {"reason": reason, "mode": mode}
            if trigger_artifact:
                body["trigger_artifact"] = trigger_artifact
            if target_project_id:
                body["target_org_id"] = target_project_id
            if target_environment:
                body["target_env"] = target_environment
            return await self._api(
                endpoint=f"/api/authority/runs/{workflow_id}/retry",
                body=self._authority_mutation_body(
                    body,
                    idempotency_key=idempotency_key,
                    initiator_type=initiator_type,
                    initiator_id=initiator_id,
                ),
            )
        return await self.retry_instance(
            workflow_id,
            instance_id,
            reason=reason,
            trigger_artifact=trigger_artifact,
            mode=mode,
        )

    async def retry_instance(
        self,
        workflow_id: str,
        instance_id: str,
        *,
        reason: str = "retry",
        trigger_artifact: Optional[str] = None,
        mode: str = "async",
    ) -> Dict[str, Any]:
        """Retry a workflow instance. Alias for nudge with a default retry reason."""
        return await self.nudge_instance(
            workflow_id,
            instance_id,
            reason=reason,
            trigger_artifact=trigger_artifact,
            mode=mode,
        )

    async def cancel_instance(self, workflow_id: str, instance_id: str) -> Dict[str, Any]:
        """Cancel a running workflow instance."""
        from urllib.parse import quote

        return await self._api(
            endpoint=f"{self._instance_base_endpoint(workflow_id)}/{quote(instance_id, safe='')}/cancel",
            body={},
        )

    async def get_run(self, run_id: str) -> Dict[str, Any]:
        del run_id
        self._reject_retired_workflow_runs_api("get_run")

    async def get_manifest(self, run_id: str) -> Dict[str, Any]:
        del run_id
        self._reject_retired_workflow_runs_api("get_manifest")

    async def register_artifact(
        self,
        run_id: str,
        artifact_key: str,
        *,
        artifact_id: Optional[str] = None,
        artifact_ref: Optional[str] = None,
        source_artifact_key: Optional[str] = None,
        source_namespace: Optional[str] = None,
        source_conversation_id: Optional[str] = None,
        source_project: Optional[str] = None,
        source_env: Optional[str] = None,
        source_project_id: Optional[str] = None,
        source_tenant: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        metadata_trusted: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """
        Register a source artifact with a saved-workflow run.
        """
        del (
            run_id,
            artifact_key,
            artifact_id,
            artifact_ref,
            source_artifact_key,
            source_namespace,
            source_conversation_id,
            source_project,
            source_env,
            source_project_id,
            source_tenant,
            metadata,
            metadata_trusted,
        )
        self._reject_retired_workflow_runs_api("register_artifact")

    async def validate_run(self, run_id: str) -> Dict[str, Any]:
        del run_id
        self._reject_retired_workflow_runs_api("validate_run")

    async def start_run(
        self,
        run_id: str,
        *,
        mode: str = "blocking",
        timeout_seconds: Optional[int] = None,
        save_events: Optional[bool] = None,
        webhook_url: Optional[str] = None,
    ) -> Dict[str, Any]:
        del run_id, mode, timeout_seconds, save_events, webhook_url
        self._reject_retired_workflow_runs_api("start_run")

    async def stream_start_run(
        self,
        run_id: str,
        *,
        timeout_seconds: Optional[int] = None,
        save_events: Optional[bool] = None,
        on_chunk: Optional[Any] = None,
    ):
        del run_id, timeout_seconds, save_events, on_chunk
        self._reject_retired_workflow_runs_api("stream_start_run")
        yield  # pragma: no cover

    async def status(self, execution_id: str) -> Dict[str, Any]:
        """Get saved-workflow execution status."""
        return await self._api(
            endpoint=f"/api/workflow/executions/{execution_id}/status",
            method="GET",
        )

    async def output(self, execution_id: str) -> Dict[str, Any]:
        """Get saved-workflow execution output."""
        return await self._api(
            endpoint=f"/api/workflow/executions/{execution_id}/output",
            method="GET",
        )

    async def messages(
        self,
        execution_id: str,
        *,
        count: int = 50,
    ) -> List[Dict[str, Any]]:
        """Get saved-workflow execution messages."""
        result = await self._api(
            endpoint=f"/api/workflow/executions/{execution_id}/messages?count={count}",
            method="GET",
        )
        return result.get("messages", result) if isinstance(result, dict) else result

    async def events(
        self,
        execution_id: str,
        *,
        from_id: Optional[str] = None,
        count: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """Replay saved-workflow execution events."""
        query = []
        if from_id:
            query.append(f"from_id={from_id}")
        if count is not None:
            query.append(f"count={count}")
        endpoint = f"/api/workflow/executions/{execution_id}/events"
        if query:
            endpoint += f"?{'&'.join(query)}"
        result = await self._api(
            endpoint=endpoint,
            method="GET",
        )
        return result.get("events", result) if isinstance(result, dict) else result

    async def cancel(
        self,
        execution_id: str,
        *,
        target_project_id: Optional[str] = None,
        target_environment: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Cancel a saved-workflow execution or Authority-backed run."""
        if self._is_authority_run_id(execution_id):
            body: Dict[str, Any] = {}
            if target_project_id:
                body["target_org_id"] = target_project_id
            if target_environment:
                body["target_env"] = target_environment
            return await self._api(
                endpoint=f"/api/authority/runs/{execution_id}/cancel",
                body=self._authority_mutation_body(
                    body,
                    idempotency_key=idempotency_key,
                    initiator_type=initiator_type,
                    initiator_id=initiator_id,
                ),
            )
        return await self._api(
            endpoint=f"/api/workflow/executions/{execution_id}/cancel",
            body={},
        )
