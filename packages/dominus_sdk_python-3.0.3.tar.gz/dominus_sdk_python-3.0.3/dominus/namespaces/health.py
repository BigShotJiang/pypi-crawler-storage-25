"""
Health Namespace - Service health check operations.

Provides health check helpers for the live gateway surface.
"""
from typing import Any, Dict, TYPE_CHECKING

if TYPE_CHECKING:
    from ..start import Dominus


class HealthNamespace:
    """
    Health check namespace.

    Usage:
        status = await dominus.health.check()
        await dominus.health.ping()
    """

    def __init__(self, client: "Dominus"):
        self._client = client

    async def check(self) -> Dict[str, Any]:
        """
        Perform an explicit gateway health check.

        Returns:
            Dict with "status", "latency_ms", and service-specific info
        """
        from ..helpers.core import health_check_all
        from ..config.endpoints import get_gateway_url

        return await health_check_all(get_gateway_url())

    async def ping(self) -> Dict[str, Any]:
        """
        Simple ping check (fastest response).

        Returns:
            Dict with "status": "ok"
        """
        result = await self._client._request(
            endpoint="/v1/ping",
            method="GET",
            use_gateway=True,
        )
        if isinstance(result, dict):
            return {
                "status": "ok" if result.get("pong") else result.get("status", "ok"),
                **result,
            }
        return {"status": "ok", "result": result}
