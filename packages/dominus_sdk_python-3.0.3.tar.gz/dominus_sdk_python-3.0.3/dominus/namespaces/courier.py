"""
Courier namespace for provider-neutral message delivery and courier admin APIs.
"""

from typing import Any, Dict, Optional, TYPE_CHECKING
from urllib.parse import urlencode

if TYPE_CHECKING:
    from ..start import Dominus


def _with_query(endpoint: str, **params: Optional[str]) -> str:
    filtered = {key: value for key, value in params.items() if value not in (None, "")}
    if not filtered:
        return endpoint
    return f"{endpoint}?{urlencode(filtered)}"


class CourierNamespace:
    def __init__(self, client: "Dominus"):
        self._client = client

    async def send(
        self,
        template_alias: str,
        to: str,
        from_email: Optional[str] = None,
        model: Optional[Dict[str, Any]] = None,
        tag: Optional[str] = None,
        reply_to: Optional[str] = None,
        project_id: Optional[str] = None,
        sender_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {
            "template_alias": template_alias,
            "to": to,
            "model": model or {},
        }

        if from_email:
            body["from"] = from_email
        if tag:
            body["tag"] = tag
        if reply_to:
            body["reply_to"] = reply_to
        if project_id:
            body["project_id"] = project_id
        if sender_id:
            body["sender_id"] = sender_id

        return await self._client._request(
            endpoint="/api/courier/send",
            body=body,
        )

    async def send_welcome(
        self,
        to: str,
        from_email: str,
        name: Optional[str] = None,
        product_name: Optional[str] = None,
        app_name: Optional[str] = None,
        action_url: Optional[str] = None,
        **extra_model: Any,
    ) -> Dict[str, Any]:
        model = {
            "user_name": name or to,
            "app_name": app_name or product_name or "Dominus",
            **extra_model,
        }
        if action_url:
            model["action_url"] = action_url

        return await self.send("welcome", to, from_email, model, tag="welcome")

    async def send_password_reset(
        self,
        to: str,
        from_email: str,
        name: Optional[str] = None,
        reset_url: Optional[str] = None,
        product_name: Optional[str] = None,
        app_name: Optional[str] = None,
        **extra_model: Any,
    ) -> Dict[str, Any]:
        model = {
            "user_name": name or to,
            "reset_link": reset_url,
            "app_name": app_name or product_name or "Dominus",
            **extra_model,
        }

        return await self.send("password-reset", to, from_email, model, tag="password-reset")

    async def send_email_verification(
        self,
        to: str,
        from_email: str,
        name: Optional[str] = None,
        verify_url: Optional[str] = None,
        product_name: Optional[str] = None,
        app_name: Optional[str] = None,
        **extra_model: Any,
    ) -> Dict[str, Any]:
        model = {
            "user_name": name or to,
            "verification_link": verify_url,
            "app_name": app_name or product_name or "Dominus",
            **extra_model,
        }

        return await self.send("email-verification", to, from_email, model, tag="email-verification")

    async def send_invitation(
        self,
        to: str,
        from_email: str,
        name: Optional[str] = None,
        invite_url: Optional[str] = None,
        inviter_name: Optional[str] = None,
        product_name: Optional[str] = None,
        app_name: Optional[str] = None,
        **extra_model: Any,
    ) -> Dict[str, Any]:
        model = {
            "user_name": name or to,
            "invite_link": invite_url,
            "inviter_name": inviter_name,
            "app_name": app_name or product_name or "Dominus",
            **extra_model,
        }

        return await self.send("invitation", to, from_email, model, tag="invitation")

    async def get_project_mail_config(self, project_id: str) -> Dict[str, Any]:
        return await self._client._request(
            endpoint=f"/api/courier/admin/projects/{project_id}/mail-config",
            method="GET",
        )

    async def update_project_mail_config(self, project_id: str, config: Dict[str, Any]) -> Dict[str, Any]:
        return await self._client._request(
            endpoint=f"/api/courier/admin/projects/{project_id}/mail-config",
            method="PUT",
            body=config,
        )

    async def test_project_mail_config(self, project_id: str, body: Dict[str, Any]) -> Dict[str, Any]:
        return await self._client._request(
            endpoint=f"/api/courier/admin/projects/{project_id}/mail-config/test",
            body=body,
        )

    async def list_project_senders(self, project_id: str) -> Dict[str, Any]:
        return await self._client._request(
            endpoint=f"/api/courier/admin/projects/{project_id}/senders",
            method="GET",
        )

    async def create_project_sender(self, project_id: str, sender: Dict[str, Any]) -> Dict[str, Any]:
        return await self._client._request(
            endpoint=f"/api/courier/admin/projects/{project_id}/senders",
            body=sender,
        )

    async def update_sender(self, sender_id: str, sender: Dict[str, Any]) -> Dict[str, Any]:
        return await self._client._request(
            endpoint=f"/api/courier/admin/senders/{sender_id}",
            method="PUT",
            body=sender,
        )

    async def delete_sender(self, sender_id: str) -> Dict[str, Any]:
        return await self._client._request(
            endpoint=f"/api/courier/admin/senders/{sender_id}",
            method="DELETE",
        )

    async def list_templates(self, project_id: Optional[str] = None) -> Dict[str, Any]:
        return await self._client._request(
            endpoint=_with_query("/api/courier/admin/templates", project_id=project_id),
            method="GET",
        )

    async def create_template(self, template: Dict[str, Any]) -> Dict[str, Any]:
        return await self._client._request(
            endpoint="/api/courier/admin/templates",
            body=template,
        )

    async def get_template(self, template_id: str, project_id: Optional[str] = None) -> Dict[str, Any]:
        return await self._client._request(
            endpoint=_with_query(f"/api/courier/admin/templates/{template_id}", project_id=project_id),
            method="GET",
        )

    async def update_template(self, template_id: str, template: Dict[str, Any]) -> Dict[str, Any]:
        return await self._client._request(
            endpoint=f"/api/courier/admin/templates/{template_id}",
            method="PUT",
            body=template,
        )

    async def delete_template(self, template_id: str, project_id: Optional[str] = None) -> Dict[str, Any]:
        return await self._client._request(
            endpoint=_with_query(f"/api/courier/admin/templates/{template_id}", project_id=project_id),
            method="DELETE",
        )

    async def render_template(
        self,
        template_id: str,
        model: Dict[str, Any],
        project_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._client._request(
            endpoint=f"/api/courier/admin/templates/{template_id}/render",
            body={
                "model": model,
                "project_id": project_id,
            },
        )

    async def list_deliveries(
        self,
        project_id: Optional[str] = None,
        status: Optional[str] = None,
        template_alias: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> Dict[str, Any]:
        limit_value = str(limit) if limit is not None else None
        return await self._client._request(
            endpoint=_with_query(
                "/api/courier/admin/deliveries",
                project_id=project_id,
                status=status,
                template_alias=template_alias,
                limit=limit_value,
            ),
            method="GET",
        )

    async def get_delivery(self, delivery_id: str) -> Dict[str, Any]:
        return await self._client._request(
            endpoint=f"/api/courier/admin/deliveries/{delivery_id}",
            method="GET",
        )
