"""
Distributed Tracing Module for Dominus Python SDK.

Provides contextvars-based trace context propagation.
Every SDK HTTP request automatically includes X-Trace-Id and X-Parent-Span-Id headers.

Usage patterns:

    # Auto mode (default) — each request gets a unique trace_id
    await dominus.db.query("users")

    # Manual grouping — all requests within scope share one trace_id
    async with with_trace() as trace_id:
        await dominus.db.query("users")
        await dominus.logs.info("queried users")

    # Imperative scope
    trace_id = start_trace()
    await dominus.db.query("users")
    end_trace()
"""

import uuid
from contextvars import ContextVar
from contextlib import asynccontextmanager
from typing import Optional


# ContextVar for trace ID — safe for concurrent async tasks
_active_trace_id: ContextVar[Optional[str]] = ContextVar("_active_trace_id", default=None)


def generate_trace_id() -> str:
    """Generate a new trace ID (UUID v4)."""
    return str(uuid.uuid4())


def get_current_trace_id() -> str:
    """Get the current trace ID from context.

    - If inside a ``with_trace()`` or ``start_trace()`` scope, returns the scoped trace_id.
    - Otherwise, generates a new unique trace_id per call (auto mode).
    """
    return _active_trace_id.get() or generate_trace_id()


def get_current_span_id() -> str:
    """Generate a per-call span ID for parent-child tracking.

    Each SDK HTTP call is a sub-span. The span_id generated here
    is sent as X-Parent-Span-Id so the callee service knows its parent span.
    """
    return str(uuid.uuid4())


def start_trace() -> str:
    """Start a manual trace scope.

    Sets the trace_id in the current context. All SDK requests
    in this context will share the same trace_id.

    Returns:
        The new trace_id
    """
    trace_id = generate_trace_id()
    _active_trace_id.set(trace_id)
    return trace_id


def end_trace() -> None:
    """End the current manual trace scope.

    Clears the trace_id from context so subsequent calls
    revert to auto-mode (unique trace_id per call).
    """
    _active_trace_id.set(None)


@asynccontextmanager
async def with_trace():
    """Async context manager for trace grouping.

    All SDK requests within the ``async with`` block share one trace_id.
    Safe for concurrent async tasks — uses contextvars.

    Usage::

        async with with_trace() as trace_id:
            await dominus.db.query("users")
            await dominus.logs.info("queried users")
    """
    trace_id = generate_trace_id()
    token = _active_trace_id.set(trace_id)
    try:
        yield trace_id
    finally:
        _active_trace_id.reset(token)
