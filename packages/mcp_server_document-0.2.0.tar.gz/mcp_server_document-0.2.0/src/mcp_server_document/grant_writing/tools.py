"""Tool functions for the grant-writing domain of mcp-server-document.

All functions are plain callables; they get wrapped by @mcp.tool()
in the top-level server.py. No FastMCP import here (that would
accidentally register a second MCP server).
"""

from __future__ import annotations

import pathlib
import re


_HERE = pathlib.Path(__file__).resolve().parent
KNOWLEDGE = _HERE


def _load_skill() -> str:
    return (KNOWLEDGE / "skill.md").read_text(encoding="utf-8")


# ------------------------------------------------------------------
# Knowledge loader
# ------------------------------------------------------------------
def grant_writing_usage() -> str:
    """科研費・JSPS・助成金 申請書の作文技術ガイド全体。

    Hook / Vision / タグライン作成、NG パターン診断、登場人物チェック、
    下線整理、物語構造評価、制約検証（ページ・文字数・overfull hbox）、
    md / docx / tex 同期等の総合ガイド。

    呼び出しタイミング:
    - 申請書ドラフトのレビュー依頼 (「このJSPS申請書を見て」)
    - 「ワクワクしない」「読みにくい」feedback 対応
    - Hook / Vision / タグライン作成の相談
    - NG パターン診断（特に「唐突な登場人物」「マイナス始まり」）
    - 下線 / 強調の整理
    - 制約適合（ページ・字数）の検証

    Tools T1-T8 の診断指針、5 phases ワークフロー、定量閾値、
    OK/NG 文例、NG パターン 10、実例集（JSPS Hollaus, PA2026, KDDI）、
    完成検証チェックリストを含む。

    活動ツール（実測）は以下を併用:
    - grant_writing_count_underlines(tex_path)
    - grant_writing_validate_pdf_pages(pdf_path, page_limit)
    - grant_writing_check_overfull_hbox(log_path)
    - grant_writing_analyze_sentences(text, max_len=80)
    """
    return _load_skill()


# ------------------------------------------------------------------
# Active diagnostic tools
# ------------------------------------------------------------------
def grant_writing_count_underlines(tex_path: str) -> dict:
    """T3: TeX/LaTeX ファイル内の下線コマンドの総数を実測。

    目標: 3-6 箇所 / ページ
    警告: ≥10 箇所 / ページ（壁紙化で読者麻痺）

    対応コマンド: \\uline / \\underline / \\uwave / \\uuline /
                 \\sout / \\dashuline（ulem パッケージ他）
    """
    p = pathlib.Path(tex_path)
    if not p.exists():
        return {"error": f"file not found: {tex_path}"}
    text = p.read_text(encoding="utf-8", errors="replace")
    macros = ["uline", "underline", "uwave", "uuline",
              "sout", "dashuline", "dotuline"]
    by_macro: dict[str, int] = {}
    total = 0
    for m in macros:
        n = len(re.findall(r"\\" + m + r"\{", text))
        if n:
            by_macro[m] = n
            total += n
    return {
        "file": str(p),
        "total_underlines": total,
        "by_macro": by_macro,
        "target_range": "3-6 per page",
        "warning_threshold": ">=10 per page (壁紙化)",
    }


def grant_writing_validate_pdf_pages(pdf_path: str, page_limit: int) -> dict:
    """T7: PDF のページ数が制限内か検証。pymupdf が必要。"""
    try:
        import pymupdf  # type: ignore
    except ImportError:
        return {"error": "pymupdf not installed. `pip install pymupdf`"}
    p = pathlib.Path(pdf_path)
    if not p.exists():
        return {"error": f"file not found: {pdf_path}"}
    doc = pymupdf.open(pdf_path)
    n = doc.page_count
    doc.close()
    return {
        "file": str(p),
        "page_count": n,
        "page_limit": page_limit,
        "within_limit": n <= page_limit,
        "pages_over": max(0, n - page_limit),
    }


def grant_writing_check_overfull_hbox(log_path: str) -> dict:
    """T7: uplatex / pdflatex のログ中の Overfull \\hbox 警告をカウント・列挙。

    目標: ゼロ。小さいもの (<1mm 相当) は許容可。
    """
    p = pathlib.Path(log_path)
    if not p.exists():
        return {"error": f"file not found: {log_path}"}
    text = p.read_text(encoding="utf-8", errors="replace")
    matches = re.findall(
        r"Overfull \\hbox \(([^)]+)\) in paragraph at lines (\d+)(?:--(\d+))?",
        text,
    )
    details = [
        {"severity": m[0], "lines": m[1] + (f"-{m[2]}" if m[2] else "")}
        for m in matches[:20]
    ]
    return {
        "file": str(p),
        "overfull_count": len(matches),
        "overfull_details": details,
        "target": "0 (or <=1mm tolerated)",
    }


def grant_writing_analyze_sentences(text: str, max_len: int = 80) -> dict:
    """文体診断: 日本語の句点 `。` で分割し、1 文の長さ統計を返す。

    目標: 平均 ≤80 字 / 文
    警告: ≥120 字 / 文

    引数:
        text: 解析対象の日本語テキスト
        max_len: 1 文の上限 (既定 80)
    """
    sentences = [s.strip() for s in re.split(r"[。．]", text) if s.strip()]
    if not sentences:
        return {"error": "no sentences found (no 。 or ．)"}
    lengths = [len(s) for s in sentences]
    avg = sum(lengths) / len(lengths)
    long_ones = [
        {"index": i, "length": ln, "head": s[:40] + ("..." if len(s) > 40 else "")}
        for i, (s, ln) in enumerate(zip(sentences, lengths))
        if ln > max_len
    ]
    return {
        "total_sentences": len(sentences),
        "avg_length": round(avg, 1),
        "max_length": max(lengths),
        "threshold": max_len,
        "over_threshold_count": len(long_ones),
        "over_threshold_examples": long_ones[:5],
        "target": f"avg <= {max_len}",
        "warning": "avg >= 120 or individual sentence >= 120",
    }


def grant_writing_count_weak_expressions(text: str) -> dict:
    """文体診断: 弱気修飾語（「〜と考えられる」等）の出現数を測定。

    目標: ≤2 / ページ
    警告: ≥5 / ページ
    """
    patterns = {
        "と考えられる": r"と考えられ(る|ます)",
        "と思われる": r"と思われ(る|ます)",
        "ではないかと": r"ではないかと",
        "可能性がある": r"可能性が(ある|あります)",
        "示唆される": r"示唆され(る|ます)",
        "期待される": r"期待され(る|ます)",
        "ように思う": r"ように思(う|います|われる)",
    }
    by_pat: dict[str, int] = {}
    total = 0
    for name, pat in patterns.items():
        n = len(re.findall(pat, text))
        if n:
            by_pat[name] = n
            total += n
    return {
        "total_weak_expressions": total,
        "by_pattern": by_pat,
        "target": "<=2 per page",
        "warning": ">=5 per page",
    }


# ------------------------------------------------------------------
# Bedrock diagnostic tools (木下 / 本多 / 知的 — 全 writing 共通)
# ------------------------------------------------------------------

# 25 redundancy patterns from 本多 + 知的
_REDUNDANCY = [
    (r"することができ(る|ない)", r"でき\1"),
    (r"ということができる", "といえる"),
    (r"に関する", "の"),
    (r"に関して(は)?", ""),
    (r"においては", "では"),
    (r"における", "の"),
    (r"ではないだろうか", "であろう"),
    (r"にほかならない", "である"),
    (r"することによって", "して"),
    (r"することとなる", "する"),
    (r"のような形で", "で"),
    (r"の中で", "で"),
    (r"にあたり", "するとき"),
    (r"ということである", "である"),
    (r"高い精度を持つ", "精度が高い"),
    (r"大きな影響を与える", "大きく影響する"),
    (r"の形で存在する", "として存在する"),
    (r"を目的として行う", "のために"),
    (r"を行う", "する"),
    (r"を行なう", "する"),
    (r"増加することになる", "増加する"),
    (r"〜という[^、。]", ""),
    (r"することとする", "する"),
    (r"〜に対しての", "への"),
    (r"の場合において", "で"),
]

# 問題な日本語 30 patterns (subset of the highest-yield 15)
_MISUSE = [
    (r"よろしかったでしょうか", "「よろしいでしょうか」に"),
    (r"のほう(?=を|が|は)", "「のほう」はぼかし。削除するか具体語に"),
    (r"じゃないですか(?=[、。])", "「のですが」に (同意誘導は弱い)"),
    (r"^なので、", "文頭「なので」は口語。「したがって」「そのため」に"),
    (r"(?<=[^で])ないです(?=[。、])", "口頭語。書面では「ありません」"),
    (r"やむ[お]えない", "正: 「やむを得ない」"),
    (r"(わたし|僕|自分|個人)的に(は)?", "「私としては」「個人としては」"),
    (r"こんにち[わ]", "正: 「こんにちは」"),
    (r"お(連絡|報告|通知|返事|案内|質問|説明)", "漢語には「ご」"),
    (r"違(く[てかっ]|かった)", "正: 「違って」「違った」"),
    (r"(きもい|うざい|きしょい|ぶっちゃけ)", "俗語。書面では使用禁止"),
    (r"みたいな[。、]", "「という感じだ」「と言った」"),
    (r"なにげに", "正: 「何気なく」「それとなく」"),
    (r"とんでもあ(りません|ございません)", "正: 「とんでもない (ことです)」"),
    (r"(咲い|降っ|流れ|吹い)ております", "主体が物なら「〜ています」"),
]


def grant_writing_lint_bedrock(text: str) -> dict:
    """木下 10 原則 + 本多 + 知的 による和文技術文章 bedrock 診断。

    1. 緩衝表現 (「と思われる」「と考えられる」)
    2. 受身連用 (3 文連続で受身末尾)
    3. 逆茂木型文 (「、」4 個以上 + 80 字以上)
    4. 「の」連打 3 個以上
    5. 一文中「は」2 個以上
    6. 文末モノトーン (3 文連続同じ文末)
    7. 意見の事実断定 (主観修飾語 + 断定)
    8. 二重否定 (「ないではない」「なくはない」等)

    すべての writing-family MCP で共通利用可能。
    """
    issues: list[dict] = []

    # Split sentences for several checks
    sentences = [s.strip() for s in re.split(r"[。．]", text) if s.strip()]

    # 1. 緩衝表現
    hedge = re.findall(
        r"(と考えられる|と思われる|と見られる|ではないかと思われる|"
        r"かもしれない|と見てよい|ように思[われう])", text
    )
    if hedge:
        issues.append({
            "rule": "hedging_expressions",
            "severity": "HIGH",
            "count": len(hedge),
            "examples": list(set(hedge))[:5],
            "fix": "断定表現に置換 (「と考える」等の基本形)",
            "source": "木下 p.95",
        })

    # 2. 受身連用 (windowed)
    passive_ends = [bool(re.search(r"(される|られる|された|られた)$", s))
                    for s in sentences]
    consecutive_passive = 0
    max_consec = 0
    for p in passive_ends:
        if p:
            consecutive_passive += 1
            max_consec = max(max_consec, consecutive_passive)
        else:
            consecutive_passive = 0
    if max_consec >= 3:
        issues.append({
            "rule": "passive_voice_chain",
            "severity": "MODERATE",
            "max_consecutive": max_consec,
            "fix": "能動態に書き換え (主語を明示)",
            "source": "木下 p.140",
        })

    # 3. 逆茂木型
    long_sentences = [s for s in sentences
                      if len(s) >= 80 and s.count("、") >= 4]
    if long_sentences:
        issues.append({
            "rule": "gyakumogi_sentence",
            "severity": "MODERATE",
            "count": len(long_sentences),
            "examples": [s[:60] + "..." for s in long_sentences[:3]],
            "fix": "長い前置修飾節は 2 個まで。文を分割。",
            "source": "木下 p.87",
        })

    # 4. 「の」連打 3 個
    no_runs = re.findall(r"の[^の、。\s]{0,8}の[^の、。\s]{0,8}の", text)
    if no_runs:
        issues.append({
            "rule": "no_particle_triple",
            "severity": "LOW",
            "count": len(no_runs),
            "examples": no_runs[:5],
            "fix": "「の」は連続 2 個まで。別助詞へ。",
            "source": "知的 p.46",
        })

    # 5. 一文中「は」2 個
    wa_heavy = []
    for s in sentences:
        # Remove quoted content
        s2 = re.sub(r"「[^」]*」", "", s)
        if s2.count("は") >= 2:
            wa_heavy.append(s)
    if wa_heavy:
        issues.append({
            "rule": "double_wa_in_sentence",
            "severity": "LOW",
            "count": len(wa_heavy),
            "examples": [s[:60] + "..." for s in wa_heavy[:3]],
            "fix": "1 文に「は」は 1 つまで。主題を 1 つに絞る。",
            "source": "知的 p.48",
        })

    # 6. 文末モノトーン
    if len(sentences) >= 3:
        endings = [s[-3:] if len(s) >= 3 else s for s in sentences]
        mono_count = 0
        for i in range(len(endings) - 2):
            if endings[i] == endings[i+1] == endings[i+2]:
                mono_count += 1
        if mono_count >= 1:
            issues.append({
                "rule": "monotone_sentence_ending",
                "severity": "LOW",
                "mono_3_in_a_row_count": mono_count,
                "fix": "文末多様化 (「である」「挙げられる」「報告されている」等を混在)",
                "source": "知的 p.36",
            })

    # 7. 意見の事実断定
    opinion_fact = re.findall(
        r"(便利|すぐれ|優秀|重要|有用|効果的|画期的)[な]?[^。]*である[。\.]",
        text
    )
    if opinion_fact:
        issues.append({
            "rule": "opinion_stated_as_fact",
            "severity": "HIGH",
            "count": len(opinion_fact),
            "examples": [s[:60] + "..." for s in opinion_fact[:3]],
            "fix": "意見と事実を峻別。数値で裏付けるか「〜と考える」の形へ。",
            "source": "木下 p.117",
        })

    # 8. 二重否定
    double_neg = re.findall(r"ない[^。]{0,12}(こと|わけ|の)(は|が)?ない",
                            text)
    if double_neg:
        issues.append({
            "rule": "double_negative",
            "severity": "LOW",
            "count": len(double_neg),
            "fix": "肯定文で書き直す (「有効でないとは言えない」→「有効である」)",
            "source": "中学生 p.190",
        })

    return {
        "total_sentences": len(sentences),
        "issue_count": len(issues),
        "issues": issues,
        "bedrock_principles": (
            "木下 10 原則 (目標規定文 / 重点先行 / パラグラフ 1 主張 / "
            "事実意見峻別 / 逆茂木排除 / 修飾近接 / 受身征伐 / "
            "緩衝表現削除 / 誤解排除 / 主述直結) + 本多テン二大原則"
        ),
    }


def grant_writing_suggest_redundancy_fixes(text: str) -> dict:
    """和文の典型的冗長表現 25 パターンを検出し置換候補を示す。

    『日本語の作文技術』+ 『知的な科学・技術文章の書き方』+ 『問題な日本語』
    の定番 lint。
    """
    suggestions: list[dict] = []
    for pat, replacement in _REDUNDANCY:
        for m in re.finditer(pat, text):
            suggestions.append({
                "pattern": pat,
                "match": m.group(0),
                "position": m.start(),
                "suggested": replacement,
            })
    # De-duplicate patterns (first occurrence only per pattern)
    seen = set()
    dedup = []
    for s in suggestions:
        if s["pattern"] not in seen:
            seen.add(s["pattern"])
            dedup.append(s)
    return {
        "total_matches": len(suggestions),
        "unique_patterns_hit": len(dedup),
        "top_fixes": dedup[:20],
        "note": (
            "置換候補は文脈依存。機械的に全置換せず、1 件ずつ判定。"
        ),
        "source": "本多『日本語の作文技術』+ 『知的な科学・技術文章の書き方』",
    }


def grant_writing_check_misuse_japanese(text: str) -> dict:
    """『問題な日本語』由来の現代誤用 15 パターン検出。

    申請書で低頻度だが、混入すると「校正が甘い」印象で減点対象。
    """
    hits: list[dict] = []
    for pat, hint in _MISUSE:
        for m in re.finditer(pat, text):
            hits.append({
                "pattern": pat,
                "match": m.group(0),
                "position": m.start(),
                "fix": hint,
            })
    return {
        "total_matches": len(hits),
        "issues": hits[:30],
        "source": "北原保雄『問題な日本語』",
    }


def grant_writing_check_kanji_ratio(text: str,
                                     min_ratio: float = 0.18,
                                     max_ratio: float = 0.40,
                                     ) -> dict:
    """漢字比率の偏りを検出。本多『日本語の作文技術』第四章に基づく。

    推奨 range: 0.25-0.35。< 0.18 = 幼稚/冗長、> 0.40 = 「官庁漢語」感。

    漢字・ひらがな・カタカナの unicode 範囲で単純分類。
    """
    kanji = sum(1 for c in text if "一" <= c <= "鿿")
    hira = sum(1 for c in text if "぀" <= c <= "ゟ")
    kata = sum(1 for c in text if "゠" <= c <= "ヿ")
    total = kanji + hira + kata
    if total == 0:
        return {"error": "no Japanese characters found"}
    ratio = kanji / total
    if ratio < min_ratio:
        status = "hiragana_heavy"
        hint = "漢字を増やして締まりを持たせる"
    elif ratio > max_ratio:
        status = "kanji_heavy"
        hint = "形式名詞 (こと/とき/もの) を漢字にしない。官庁漢語を削減。"
    else:
        status = "balanced"
        hint = "良好 (推奨範囲)"
    return {
        "total_jp_chars": total,
        "kanji": kanji,
        "hiragana": hira,
        "katakana": kata,
        "kanji_ratio": round(ratio, 3),
        "target_range": f"{min_ratio:.2f} - {max_ratio:.2f}",
        "status": status,
        "hint": hint,
        "source": "本多『日本語の作文技術』第四章",
    }


def grant_writing_check_subject_predicate_distance(text: str,
                                                     max_chars: int = 40,
                                                     ) -> dict:
    """主述の直結原則 (本多 p.22): 主語と述語の間の距離が遠い文を検出。

    簡易法: 各文で「は」または「が」の最初の出現から文末までの距離を
    計測。40 字超で warning、60 字超で fatal。
    """
    sentences = [s.strip() for s in re.split(r"[。．]", text) if s.strip()]
    violations: list[dict] = []
    for s in sentences:
        # Find first subject marker (は or が, but avoid parenthetical)
        m = re.search(r"(は|が)", s)
        if not m:
            continue
        subj_pos = m.start()
        distance = len(s) - subj_pos
        if distance > max_chars:
            violations.append({
                "sentence_head": s[:50] + ("..." if len(s) > 50 else ""),
                "subject_marker_pos": subj_pos,
                "distance_to_end": distance,
            })
    return {
        "total_sentences": len(sentences),
        "violation_count": len(violations),
        "violations": violations[:10],
        "target": f"距離 <= {max_chars} 字",
        "fatal": "距離 > 60 字 — 読解困難",
        "fix": "長い修飾節を前置せず、主語と述語を近接させる。文を分割。",
        "source": "本多『日本語の作文技術』第一章",
    }


