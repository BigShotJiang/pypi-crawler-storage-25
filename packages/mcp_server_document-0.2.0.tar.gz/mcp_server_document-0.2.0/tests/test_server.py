"""Smoke tests for mcp-server-document — unified server registration."""
import asyncio

import pytest


@pytest.fixture
def mcp_and_counts():
    from mcp_server_document.server import _build_mcp
    return _build_mcp()


def test_server_builds(mcp_and_counts):
    mcp, counts = mcp_and_counts
    assert mcp.name == "mcp-server-document"
    assert counts["grant_writing"] >= 6
    assert counts["paper_writing"] >= 9
    assert counts["presentation"] >= 10


def test_total_tool_count(mcp_and_counts):
    mcp, counts = mcp_and_counts
    tools = asyncio.run(mcp.list_tools())
    # At least 30 tools across the three writing domains
    assert len(tools) >= 30
    # Exact count is locked in by construction:
    #   grant_writing 11 + paper_writing 14 + presentation 15 = 40
    assert len(tools) == sum(counts.values())


def test_tool_namespacing(mcp_and_counts):
    mcp, _ = mcp_and_counts
    tools = asyncio.run(mcp.list_tools())
    names = {t.name for t in tools}
    # Each sub-module's tools carry a matching prefix
    for name in names:
        assert name.startswith((
            "grant_writing_", "paper_writing_", "presentation_", "diagram_"
        )), f"tool {name!r} has unexpected prefix"


def test_usage_returns_skill_md(mcp_and_counts):
    """The *_usage tools should return the sub-module's skill.md."""
    from mcp_server_document.grant_writing.tools import grant_writing_usage
    from mcp_server_document.paper_writing.tools import paper_writing_usage
    from mcp_server_document.presentation.tools import presentation_usage

    for fn, keyword in [
        (grant_writing_usage, "申請書"),
        (paper_writing_usage, "論文"),
        (presentation_usage, "発表"),
    ]:
        out = fn()
        assert isinstance(out, str)
        assert len(out) > 500
        assert keyword in out, f"{fn.__name__} missing expected keyword {keyword!r}"
