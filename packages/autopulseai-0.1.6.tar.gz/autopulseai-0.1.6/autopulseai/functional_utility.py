from . import generic_utility as DQGU   # ✅ CORRECT

import importlib
import time
import warnings
import os
warnings.filterwarnings("ignore")
import pandas as pd
import numpy as np
import random
import re
import datetime
from typing import Optional, Tuple
from datetime import datetime

warnings.filterwarnings("ignore")
global_directory='D:/Data_Sources/'

def run_steps(driver,step_list,web_app_name,file_path,Base_path,SERVICE_NAME,Screenshots_path,sleep_time=0.5):
    global App_number
    try: error_records
    except NameError: error_records = []

    data_extracted = []
    context = {
        "switch_lang": None,
        "app_cancel_No": None
    }

    for step in step_list:
        try:
            step_name, action, el_list, labels, delay = step[0], step[1], step[2], step[3], step[4]
            print(f"\n=== STEP: {step_name} ===")

            # =========================
            # CLICK
            # =========================
            if action == "click":
                DQGU.clicking_on_element_by_all_option(
                    driver,
                    el_list,
                    labels,
                    max_retries=2,
                    scroll=True
                )

            # =========================
            # INPUT
            # =========================
            elif action == "input":
                input_values = step[5]
                for value in input_values:
                    DQGU.input_data_by_all_option(
                        driver,
                        el_list,
                        [''],
                        [value],
                        [value],
                        max_attempts=3,
                        timeout=10,
                        scroll=False,
                        input_delay=1
                    )

            # =========================
            # NEW: GET URL
            # =========================
            elif action == "get_url":
                url = step[5][0]
                driver.get(url)
                print(f"🌐 Navigated to: {url}")

            # =========================
            # SCRAP DATA
            # =========================
            elif action == "Scrap_data":
                extracted = DQGU.extract_text(
                    driver,
                    el_list,
                    max_retries=3,
                    retry_delay=1,
                    waittime=3
                )

                data_extracted.append({
                    "step": step_name,
                    "value": extracted
                })

                # Capture Application Number safely
                if step_name == "Scrap Application_number":
                    App_number = extracted.split('-')[-1].strip()
                    print(f"✅ Extracted App Number: {App_number}")

                # Validation
                if step_name == 'Getting_application_validation':
                    app_cancel = DQGU.extract_text(
                        driver,
                        application_validation_box,
                        max_retries=3,
                        retry_delay=1,
                        waittime=1
                    )

                    if app_cancel:
                        app_cancel_No = DQGU.extract_application_number(extracted)
                        context["app_cancel_No"] = app_cancel_No
                        print(app_cancel_No)

                # Detect Language
                if step_name == 'Detect_language':
                    lang = DQGU.detect_language(extracted)

                    if lang == 'English':
                        context["switch_lang"] = False
                    elif lang == 'Arabic':
                        context["switch_lang"] = True
                    else:
                        context["switch_lang"] = None

                    print('lang ===>', lang, '| switch_lang ===>', context["switch_lang"])

            # =========================
            # WAIT
            # =========================
            time.sleep(delay)

            # =========================
            # LOGGING 
            # =========================
            DQGU.export_network_logs(
                driver,
                f"{web_app_name} - {step_name}",
                Screenshots_path,
                file_path=file_path,
                step_type=step_name,
                action_type=step_name,
                Base_path=Base_path
                
            )

            time.sleep(sleep_time)

        except Exception as e:
            print(f"⚠️ Error during '{step_name}': {e}")
            error_records.append({
                "ServiceName": f"{SERVICE_NAME} - {step_name}",
                "URL": getattr(driver, "current_url", ""),
                "Error": str(e),
            })
            continue

    return context, data_extracted