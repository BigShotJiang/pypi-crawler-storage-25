from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor

class ModuleStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    MODULE_STATUS_UNSPECIFIED: _ClassVar[ModuleStatus]
    MODULE_STATUS_READY: _ClassVar[ModuleStatus]
    MODULE_STATUS_ACTIVE: _ClassVar[ModuleStatus]
    MODULE_STATUS_ARCHIVED: _ClassVar[ModuleStatus]

class SetupStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SETUP_STATUS_UNSPECIFIED: _ClassVar[SetupStatus]
    SETUP_STATUS_DRAFT: _ClassVar[SetupStatus]
    SETUP_STATUS_WAITING_FOR_APPROVAL: _ClassVar[SetupStatus]
    SETUP_STATUS_READY: _ClassVar[SetupStatus]
    SETUP_STATUS_PAUSED: _ClassVar[SetupStatus]
    SETUP_STATUS_FAILED: _ClassVar[SetupStatus]
    SETUP_STATUS_ARCHIVED: _ClassVar[SetupStatus]
    SETUP_STATUS_NEEDS_CONFIGURATION: _ClassVar[SetupStatus]
    SETUP_STATUS_CONFIGURATION_FAILED: _ClassVar[SetupStatus]
    SETUP_STATUS_CONFIGURATION_SUCCEEDED: _ClassVar[SetupStatus]

class Visibility(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    VISIBILITY_UNSPECIFIED: _ClassVar[Visibility]
    VISIBILITY_PUBLIC: _ClassVar[Visibility]
    VISIBILITY_PRIVATE: _ClassVar[Visibility]
    VISIBILITY_INTERNAL: _ClassVar[Visibility]

class ModuleType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    MODULE_TYPE_UNSPECIFIED: _ClassVar[ModuleType]
    MODULE_TYPE_ARCHETYPE: _ClassVar[ModuleType]
    MODULE_TYPE_TOOL: _ClassVar[ModuleType]
MODULE_STATUS_UNSPECIFIED: ModuleStatus
MODULE_STATUS_READY: ModuleStatus
MODULE_STATUS_ACTIVE: ModuleStatus
MODULE_STATUS_ARCHIVED: ModuleStatus
SETUP_STATUS_UNSPECIFIED: SetupStatus
SETUP_STATUS_DRAFT: SetupStatus
SETUP_STATUS_WAITING_FOR_APPROVAL: SetupStatus
SETUP_STATUS_READY: SetupStatus
SETUP_STATUS_PAUSED: SetupStatus
SETUP_STATUS_FAILED: SetupStatus
SETUP_STATUS_ARCHIVED: SetupStatus
SETUP_STATUS_NEEDS_CONFIGURATION: SetupStatus
SETUP_STATUS_CONFIGURATION_FAILED: SetupStatus
SETUP_STATUS_CONFIGURATION_SUCCEEDED: SetupStatus
VISIBILITY_UNSPECIFIED: Visibility
VISIBILITY_PUBLIC: Visibility
VISIBILITY_PRIVATE: Visibility
VISIBILITY_INTERNAL: Visibility
MODULE_TYPE_UNSPECIFIED: ModuleType
MODULE_TYPE_ARCHETYPE: ModuleType
MODULE_TYPE_TOOL: ModuleType
