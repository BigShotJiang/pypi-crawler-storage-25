from agentic_mesh_protocol.registry.v1 import registry_enums_pb2 as _registry_enums_pb2
from agentic_mesh_protocol.registry.v1 import registry_models_pb2 as _registry_models_pb2
from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class RegisterModuleRequest(_message.Message):
    __slots__ = ()
    MODULE_ID_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    PORT_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    module_id: str
    address: str
    port: int
    version: str
    def __init__(self, module_id: _Optional[str] = ..., address: _Optional[str] = ..., port: _Optional[int] = ..., version: _Optional[str] = ...) -> None: ...

class RegisterModuleResponse(_message.Message):
    __slots__ = ()
    MODULE_FIELD_NUMBER: _ClassVar[int]
    module: _registry_models_pb2.ModuleDescriptor
    def __init__(self, module: _Optional[_Union[_registry_models_pb2.ModuleDescriptor, _Mapping]] = ...) -> None: ...

class HeartbeatRequest(_message.Message):
    __slots__ = ()
    MODULE_ID_FIELD_NUMBER: _ClassVar[int]
    module_id: str
    def __init__(self, module_id: _Optional[str] = ...) -> None: ...

class HeartbeatResponse(_message.Message):
    __slots__ = ()
    STATUS_FIELD_NUMBER: _ClassVar[int]
    status: _registry_enums_pb2.ModuleStatus
    def __init__(self, status: _Optional[_Union[_registry_enums_pb2.ModuleStatus, str]] = ...) -> None: ...

class DiscoverSetupsRequest(_message.Message):
    __slots__ = ()
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    VISIBILITY_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MODULE_TYPES_FIELD_NUMBER: _ClassVar[int]
    QUERY_FIELD_NUMBER: _ClassVar[int]
    MODULE_IDS_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    organization_id: str
    visibility: _containers.RepeatedScalarFieldContainer[_registry_enums_pb2.Visibility]
    status: _containers.RepeatedScalarFieldContainer[_registry_enums_pb2.SetupStatus]
    module_types: _containers.RepeatedScalarFieldContainer[_registry_enums_pb2.ModuleType]
    query: str
    module_ids: _containers.RepeatedScalarFieldContainer[str]
    limit: int
    offset: int
    def __init__(self, organization_id: _Optional[str] = ..., visibility: _Optional[_Iterable[_Union[_registry_enums_pb2.Visibility, str]]] = ..., status: _Optional[_Iterable[_Union[_registry_enums_pb2.SetupStatus, str]]] = ..., module_types: _Optional[_Iterable[_Union[_registry_enums_pb2.ModuleType, str]]] = ..., query: _Optional[str] = ..., module_ids: _Optional[_Iterable[str]] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ...) -> None: ...

class DiscoverSetupsResponse(_message.Message):
    __slots__ = ()
    SETUPS_FIELD_NUMBER: _ClassVar[int]
    setups: _containers.RepeatedCompositeFieldContainer[_registry_models_pb2.SetupDescriptor]
    def __init__(self, setups: _Optional[_Iterable[_Union[_registry_models_pb2.SetupDescriptor, _Mapping]]] = ...) -> None: ...

class DiscoverModulesRequest(_message.Message):
    __slots__ = ()
    ORGANIZATION_ID_FIELD_NUMBER: _ClassVar[int]
    MODULE_TYPES_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    VISIBILITY_FIELD_NUMBER: _ClassVar[int]
    QUERY_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    organization_id: str
    module_types: _containers.RepeatedScalarFieldContainer[_registry_enums_pb2.ModuleType]
    status: _containers.RepeatedScalarFieldContainer[_registry_enums_pb2.ModuleStatus]
    visibility: _containers.RepeatedScalarFieldContainer[_registry_enums_pb2.Visibility]
    query: str
    limit: int
    offset: int
    def __init__(self, organization_id: _Optional[str] = ..., module_types: _Optional[_Iterable[_Union[_registry_enums_pb2.ModuleType, str]]] = ..., status: _Optional[_Iterable[_Union[_registry_enums_pb2.ModuleStatus, str]]] = ..., visibility: _Optional[_Iterable[_Union[_registry_enums_pb2.Visibility, str]]] = ..., query: _Optional[str] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ...) -> None: ...

class DiscoverModulesResponse(_message.Message):
    __slots__ = ()
    MODULES_FIELD_NUMBER: _ClassVar[int]
    modules: _containers.RepeatedCompositeFieldContainer[_registry_models_pb2.ModuleDescriptor]
    def __init__(self, modules: _Optional[_Iterable[_Union[_registry_models_pb2.ModuleDescriptor, _Mapping]]] = ...) -> None: ...

class GetSetupRequest(_message.Message):
    __slots__ = ()
    SETUP_ID_FIELD_NUMBER: _ClassVar[int]
    setup_id: str
    def __init__(self, setup_id: _Optional[str] = ...) -> None: ...

class GetModuleRequest(_message.Message):
    __slots__ = ()
    MODULE_ID_FIELD_NUMBER: _ClassVar[int]
    module_id: str
    def __init__(self, module_id: _Optional[str] = ...) -> None: ...
