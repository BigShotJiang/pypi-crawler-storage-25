from agentic_mesh_protocol.task_manager.v1 import task_manager_message_pb2 as _task_manager_message_pb2
from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SendSignalsRequest(_message.Message):
    __slots__ = ()
    TASKS_FIELD_NUMBER: _ClassVar[int]
    tasks: _containers.RepeatedCompositeFieldContainer[_task_manager_message_pb2.Task]
    def __init__(self, tasks: _Optional[_Iterable[_Union[_task_manager_message_pb2.Task, _Mapping]]] = ...) -> None: ...

class SendSignalsResponse(_message.Message):
    __slots__ = ()
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    TASKS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    tasks: _containers.RepeatedCompositeFieldContainer[_task_manager_message_pb2.Task]
    def __init__(self, success: _Optional[bool] = ..., tasks: _Optional[_Iterable[_Union[_task_manager_message_pb2.Task, _Mapping]]] = ...) -> None: ...

class ListHeartbeatsRequest(_message.Message):
    __slots__ = ()
    TASK_IDS_FIELD_NUMBER: _ClassVar[int]
    task_ids: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, task_ids: _Optional[_Iterable[str]] = ...) -> None: ...

class ListHeartbeatsResponse(_message.Message):
    __slots__ = ()
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    TASKS_FIELD_NUMBER: _ClassVar[int]
    total_count: int
    tasks: _containers.RepeatedCompositeFieldContainer[_task_manager_message_pb2.Task]
    def __init__(self, total_count: _Optional[int] = ..., tasks: _Optional[_Iterable[_Union[_task_manager_message_pb2.Task, _Mapping]]] = ...) -> None: ...

class GetSignalsRequest(_message.Message):
    __slots__ = ()
    TASK_IDS_FIELD_NUMBER: _ClassVar[int]
    task_ids: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, task_ids: _Optional[_Iterable[str]] = ...) -> None: ...

class GetSignalsResponse(_message.Message):
    __slots__ = ()
    TASKS_FIELD_NUMBER: _ClassVar[int]
    tasks: _containers.RepeatedCompositeFieldContainer[_task_manager_message_pb2.Task]
    def __init__(self, tasks: _Optional[_Iterable[_Union[_task_manager_message_pb2.Task, _Mapping]]] = ...) -> None: ...
