from agentic_mesh_protocol.task_manager.v1 import task_manager_dto_pb2 as _task_manager_dto_pb2
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor
