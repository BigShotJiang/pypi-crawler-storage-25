# Parsers for characterization schemas.
