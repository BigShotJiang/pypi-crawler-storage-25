# Environment Variables

Environment variables override stored configuration values.

## Authentication & API

| Variable | Description | Default |
|----------|-------------|---------|
| `PRETORIN_API_KEY` | API key for platform access. Overrides `api_key` in config file. | — |
| `PRETORIN_PLATFORM_API_BASE_URL` | Platform REST API base URL | `https://platform.pretorin.com/api/v1/public` |
| `PRETORIN_API_BASE_URL` | Backward-compatible alias for `PRETORIN_PLATFORM_API_BASE_URL` | — |
| `PRETORIN_MODEL_API_BASE_URL` | Model API URL for agent runtime | `https://platform.pretorin.com/api/v1/public/model` |

## Context

| Variable | Description | Default |
|----------|-------------|---------|
| `PRETORIN_SYSTEM_ID` | Active system ID. Overrides the system set via `pretorin context set`. | — |
| `PRETORIN_FRAMEWORK_ID` | Active framework ID. Overrides the framework set via `pretorin context set`. | — |

## Agent Runtime

| Variable | Description | Default |
|----------|-------------|---------|
| `OPENAI_API_KEY` | Model key override for agent runtime. Takes precedence over stored Pretorin login key. | — |
| `OPENAI_BASE_URL` | Base URL for the model API endpoint. Overrides `openai_base_url` in config file. | — |
| `OPENAI_MODEL` | Model name for the agent runtime. | `gpt-4o` |

## Source Attestation

| Variable | Description | Default |
|----------|-------------|---------|
| `PRETORIN_SOURCE_PROVIDERS` | JSON array of source provider configurations. Overrides `source_providers` in config file. | — |
| `PRETORIN_SOURCE_MANIFEST` | JSON string or file path to a source manifest. Falls back to `.pretorin/source-manifest.json` in the git repo root, then `~/.pretorin/source-manifest-{system_id}.json`, then the `source_manifest` config key. | — |

## Behavior

| Variable | Description | Default |
|----------|-------------|---------|
| `PRETORIN_DISABLE_UPDATE_CHECK` | Set to a truthy value (`1`, `true`, `yes`, `on`) to disable passive update notifications. | — |
| `PRETORIN_LOG_LEVEL` | Logging level (`DEBUG`, `INFO`, `WARNING`, `ERROR`) | `WARNING` |

## Precedence

For the API key:
1. `PRETORIN_API_KEY` environment variable (highest)
2. `api_key` in `~/.pretorin/config.json`

For the platform API URL:
1. `PRETORIN_PLATFORM_API_BASE_URL` environment variable (highest)
2. `PRETORIN_API_BASE_URL` environment variable (legacy alias)
3. `platform_api_base_url` in `~/.pretorin/config.json`
4. `api_base_url` in `~/.pretorin/config.json` (legacy)
5. `https://platform.pretorin.com/api/v1/public` default

For the model key (agent runtime):
1. `OPENAI_API_KEY` environment variable (highest)
2. `config.api_key` (from `pretorin login`)
3. `config.openai_api_key`

For the model name:
1. `OPENAI_MODEL` environment variable (highest)
2. `openai_model` in `~/.pretorin/config.json`
3. Org AI settings from the platform (cached)
4. `gpt-4o` default

For the source manifest:
1. `PRETORIN_SOURCE_MANIFEST` environment variable (highest) — JSON string or file path
2. `.pretorin/source-manifest.json` in the git repo root
3. `~/.pretorin/source-manifest-{system_id}.json`
4. `source_manifest` key in `~/.pretorin/config.json`

## CI/CD Example

```bash
export PRETORIN_API_KEY=pretorin_your_key_here
export PRETORIN_DISABLE_UPDATE_CHECK=1
export PRETORIN_SYSTEM_ID=your_system_id

pretorin frameworks list
pretorin evidence push
```
