"""
Timeback MasteryTrack Client

A Python client for MasteryTrack assessment assignment and inventory operations.
"""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("timeback-masterytrack")
except PackageNotFoundError:
    __version__ = "0.0.0"

from .client import MasteryTrackClient
from .exceptions import (
    APIError,
    AuthenticationError,
    ForbiddenError,
    InputValidationError,
    MasteryTrackError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimebackError,
    ValidationError,
    ValidationIssue,
    create_input_validation_error,
)
from .types import (
    MasteryTrackAssignment,
    MasteryTrackAssignmentInput,
    MasteryTrackAssignResponse,
    MasteryTrackAssignResponseData,
    MasteryTrackAuth,
    MasteryTrackAuthorizerInput,
    MasteryTrackAuthorizerResponse,
    MasteryTrackEnvironment,
    MasteryTrackInvalidateAssignmentInput,
    MasteryTrackInvalidatedAssignment,
    MasteryTrackInvalidateResponse,
    MasteryTrackInvalidateResponseData,
    MasteryTrackInventoryItem,
    MasteryTrackInventoryMetadata,
    MasteryTrackInventorySearchParams,
    MasteryTrackInventorySearchResponse,
)

__all__ = [
    "APIError",
    "AuthenticationError",
    "ForbiddenError",
    "InputValidationError",
    "MasteryTrackAssignResponse",
    "MasteryTrackAssignResponseData",
    "MasteryTrackAssignment",
    "MasteryTrackAssignmentInput",
    "MasteryTrackAuth",
    "MasteryTrackAuthorizerInput",
    "MasteryTrackAuthorizerResponse",
    "MasteryTrackClient",
    "MasteryTrackEnvironment",
    "MasteryTrackError",
    "MasteryTrackInvalidateAssignmentInput",
    "MasteryTrackInvalidateResponse",
    "MasteryTrackInvalidateResponseData",
    "MasteryTrackInvalidatedAssignment",
    "MasteryTrackInventoryItem",
    "MasteryTrackInventoryMetadata",
    "MasteryTrackInventorySearchParams",
    "MasteryTrackInventorySearchResponse",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "TimebackError",
    "ValidationError",
    "ValidationIssue",
    "__version__",
    "create_input_validation_error",
]
