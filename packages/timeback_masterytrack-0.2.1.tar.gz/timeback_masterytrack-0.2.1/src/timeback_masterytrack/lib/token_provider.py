"""
MasteryTrack JWT Provider

Acquires and caches JWT tokens via POST /authorizer.
"""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Any, TypedDict

import httpx

if TYPE_CHECKING:
    from ..types.base import MasteryTrackAuth

log = logging.getLogger("timeback_masterytrack.token_provider")

DEFAULT_REFRESH_AFTER_S = 50 * 60  # 50 minutes


class AuthCheckChecks(TypedDict):
    """Detailed check results for auth verification."""

    token_acquisition: bool


class AuthCheckResult(TypedDict, total=False):
    """Result of an authentication check."""

    ok: bool
    latency_ms: int
    error: str | None
    checks: AuthCheckChecks


class MasteryTrackJwtProvider:
    """JWT provider for MasteryTrack API access.

    Calls ``/authorizer`` using ``x-api-key`` header and caches JWT responses.
    """

    def __init__(
        self,
        *,
        base_url: str,
        auth: MasteryTrackAuth,
        http_client: httpx.AsyncClient | None = None,
        refresh_after_s: float = DEFAULT_REFRESH_AFTER_S,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._api_key = auth["api_key"]
        self._default_email = auth["email"]
        self._refresh_after_s = refresh_after_s
        self._injected_client = http_client
        self._client: httpx.AsyncClient | None = http_client

        self._token: str | None = None
        self._token_email: str | None = None
        self._refresh_at: float = 0

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient()
        return self._client

    async def get_token(self, email_override: str | None = None) -> str:
        """Acquire a JWT token, using cache when possible.

        Args:
            email_override: Optional email to use instead of the default.
                            If the email differs from the cached token's email,
                            a fresh token is fetched.

        Returns:
            JWT token string.

        Raises:
            RuntimeError: If the authorizer request fails or returns invalid data.
        """
        email = email_override or self._default_email
        email_changed = self._token_email is not None and self._token_email != email

        if self._token and not email_changed and time.time() < self._refresh_at:
            return self._token

        if not email:
            raise RuntimeError("MasteryTrack email is required for token acquisition")

        client = await self._get_client()
        url = f"{self._base_url}/authorizer"

        try:
            response = await client.post(
                url,
                json={"email": email},
                headers={
                    "Content-Type": "application/json",
                    "x-api-key": self._api_key,
                },
            )
        except httpx.HTTPError as exc:
            raise RuntimeError(f"MasteryTrack authorizer request failed: {exc}") from exc

        payload: Any = None
        try:
            payload = response.json()
        except Exception:
            payload = {}

        if not response.is_success:
            error_message = (
                payload.get("error") if isinstance(payload, dict) else None
            ) or f"MasteryTrack authorizer failed with status {response.status_code}"
            raise RuntimeError(error_message)

        if (
            not isinstance(payload, dict)
            or payload.get("success") is not True
            or not isinstance(payload.get("jwt"), str)
        ):
            raise RuntimeError("MasteryTrack authorizer returned an invalid response")

        jwt: str = payload["jwt"]
        self._token = jwt
        self._token_email = email
        self._refresh_at = time.time() + self._refresh_after_s
        return jwt

    def invalidate(self) -> None:
        """Clear cached JWT token, forcing re-acquisition on next call."""
        self._token = None
        self._token_email = None
        self._refresh_at = 0

    async def check_auth(self) -> AuthCheckResult:
        """Verify that authentication is working.

        Returns:
            Auth check result with ok, latency_ms, and optional error.
        """
        start = time.time()
        try:
            await self.get_token()
            return AuthCheckResult(
                ok=True,
                latency_ms=int((time.time() - start) * 1000),
                checks=AuthCheckChecks(token_acquisition=True),
            )
        except Exception as e:
            return AuthCheckResult(
                ok=False,
                latency_ms=int((time.time() - start) * 1000),
                error=str(e),
                checks=AuthCheckChecks(token_acquisition=False),
            )

    async def close(self) -> None:
        """Close the HTTP client if we own it."""
        if (
            self._client is not None
            and not self._client.is_closed
            and self._injected_client is None
        ):
            await self._client.aclose()
            self._client = None


__all__ = ["AuthCheckChecks", "AuthCheckResult", "MasteryTrackJwtProvider"]
