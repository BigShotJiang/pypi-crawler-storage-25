"""
MasteryTrack Config Resolution

Resolves client configuration from constructor args and environment variables.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import TYPE_CHECKING

from ..constants import MASTERYTRACK_BASE_URLS, MASTERYTRACK_ENV_VARS

if TYPE_CHECKING:
    from ..types.base import MasteryTrackAuth, MasteryTrackEnvironment

VALID_ENVIRONMENTS = frozenset(MASTERYTRACK_BASE_URLS.keys())


@dataclass(frozen=True)
class ResolvedMasteryTrackConfig:
    """Fully resolved configuration for transport initialisation."""

    base_url: str
    auth: MasteryTrackAuth
    timeout: float


def _first_defined(keys: tuple[str, ...]) -> str | None:
    """Return the first non-empty environment variable value from *keys*."""
    for key in keys:
        value = os.environ.get(key)
        if value and value.strip():
            return value
    return None


def resolve_mastery_config(
    *,
    env: MasteryTrackEnvironment | None = None,
    base_url: str | None = None,
    api_key: str | None = None,
    email: str | None = None,
    timeout: float = 30.0,
) -> ResolvedMasteryTrackConfig:
    """Resolve MasteryTrack config into concrete values.

    Resolution priority:
    1. Explicit constructor arguments
    2. Environment variables (TIMEBACK_MASTERYTRACK_* then MASTERYTRACK_*)
    3. Known base URLs for the environment name

    Args:
        env: Environment name (staging or production). Defaults to staging.
        base_url: Explicit base URL override.
        api_key: API key for authentication.
        email: Email for authentication.
        timeout: Request timeout in seconds.

    Returns:
        Fully resolved configuration.

    Raises:
        ValueError: If required values cannot be resolved.
    """
    resolved_env = env or "staging"

    base_url_from_env = _first_defined(MASTERYTRACK_ENV_VARS["base_url"])
    api_key_from_env = _first_defined(MASTERYTRACK_ENV_VARS["api_key"])
    email_from_env = _first_defined(MASTERYTRACK_ENV_VARS["email"])

    resolved_base_url = base_url or base_url_from_env

    if not resolved_base_url and resolved_env not in VALID_ENVIRONMENTS:
        raise ValueError(
            f'Invalid MasteryTrack environment "{resolved_env}". '
            f"Expected one of: {', '.join(sorted(VALID_ENVIRONMENTS))}"
        )

    resolved_base_url = resolved_base_url or MASTERYTRACK_BASE_URLS[resolved_env]

    resolved_api_key = api_key or api_key_from_env or ""
    resolved_email = email or email_from_env or ""

    if not resolved_api_key or not resolved_email:
        raise ValueError(
            "Missing MasteryTrack credentials. Provide api_key and email arguments "
            "or set TIMEBACK_MASTERYTRACK_API_KEY and TIMEBACK_MASTERYTRACK_EMAIL."
        )

    auth: MasteryTrackAuth = {
        "api_key": resolved_api_key,
        "email": resolved_email,
    }

    return ResolvedMasteryTrackConfig(
        base_url=resolved_base_url,
        auth=auth,
        timeout=timeout,
    )


__all__ = ["ResolvedMasteryTrackConfig", "resolve_mastery_config"]
