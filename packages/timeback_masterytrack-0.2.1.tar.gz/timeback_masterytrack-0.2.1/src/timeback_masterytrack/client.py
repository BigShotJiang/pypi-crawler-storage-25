"""
Timeback MasteryTrack Client

Async client for MasteryTrack assessment assignment and inventory operations.
"""

from __future__ import annotations

from typing import Protocol

from .lib.resolve import resolve_mastery_config
from .lib.token_provider import AuthCheckResult, MasteryTrackJwtProvider
from .lib.transport import Transport
from .resources.assignments import AssignmentsResource
from .resources.authorizer import AuthorizerResource
from .resources.inventory import InventoryResource


class MasteryTrackTransportLike(Protocol):
    """Duck-typed transport interface for custom transports."""

    base_url: str

    async def close(self) -> None: ...


class MasteryTrackAuthenticatorLike(Protocol):
    """Duck-typed authenticator interface for custom transports."""

    async def get_token(self, email_override: str | None = None) -> str: ...
    def invalidate(self) -> None: ...
    async def check_auth(self) -> AuthCheckResult: ...


class MasteryTrackClient:
    """MasteryTrack API client for assessment assignment and inventory operations.

    Provides access to authorizer, inventory, and assignments resources.

    Configuration modes:
        - **Env mode**: ``MasteryTrackClient(env="staging", api_key="...", email="...")``
        - **Explicit URL mode**: ``MasteryTrackClient(base_url="...", api_key="...", email="...")``
        - **Custom transport mode**: ``MasteryTrackClient(transport=..., authenticator=...)``
    """

    def __init__(
        self,
        *,
        env: str | None = None,
        base_url: str | None = None,
        api_key: str | None = None,
        email: str | None = None,
        timeout: float = 30.0,
        transport: MasteryTrackTransportLike | None = None,
        authenticator: MasteryTrackAuthenticatorLike | None = None,
    ) -> None:
        self._transport: Transport | MasteryTrackTransportLike
        self._authenticator: MasteryTrackJwtProvider | MasteryTrackAuthenticatorLike

        if transport is not None:
            if authenticator is None:
                raise ValueError("authenticator is required when providing a custom transport")
            self._transport = transport
            self._authenticator = authenticator
            self._owns_transport = False
        else:
            resolved = resolve_mastery_config(
                env=env,  # type: ignore[arg-type]
                base_url=base_url,
                api_key=api_key,
                email=email,
                timeout=timeout,
            )

            jwt_provider = MasteryTrackJwtProvider(
                base_url=resolved.base_url,
                auth=resolved.auth,
            )

            self._authenticator = jwt_provider
            self._transport = Transport(
                base_url=resolved.base_url,
                jwt_provider=jwt_provider,
                timeout=resolved.timeout,
            )
            self._owns_transport = True

        self.authorizer = AuthorizerResource(self._authenticator)  # type: ignore[arg-type]
        self.inventory = InventoryResource(self._transport)  # type: ignore[arg-type]
        self.assignments = AssignmentsResource(self._transport)  # type: ignore[arg-type]

    def get_transport(self) -> Transport | MasteryTrackTransportLike:
        """Get the underlying transport for advanced use cases."""
        return self._transport

    async def check_auth(self) -> AuthCheckResult:
        """Verify that authentication is working.

        Returns:
            Auth check result with ok, latency_ms, and optional error.

        Raises:
            RuntimeError: If the authenticator does not support check_auth.
        """
        return await self._authenticator.check_auth()

    async def close(self) -> None:
        """Close the HTTP client and release resources."""
        await self._transport.close()
        if self._owns_transport and isinstance(self._authenticator, MasteryTrackJwtProvider):
            await self._authenticator.close()

    async def __aenter__(self) -> MasteryTrackClient:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object | None,
    ) -> None:
        await self.close()
