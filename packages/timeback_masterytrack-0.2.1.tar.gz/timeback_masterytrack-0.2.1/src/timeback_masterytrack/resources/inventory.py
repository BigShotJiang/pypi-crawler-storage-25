"""
Inventory Resource

MasteryTrack test inventory operations.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from timeback_common import validate_with_schema

from ..types.inputs import MasteryTrackInventorySearchParams
from ..types.responses import MasteryTrackInventorySearchResponse

if TYPE_CHECKING:
    from ..lib.transport import Transport


class InventoryResource:
    """Resource for MasteryTrack inventory operations."""

    def __init__(self, transport: Transport) -> None:
        self._transport = transport

    async def search(
        self,
        params: dict[str, Any] | MasteryTrackInventorySearchParams | None = None,
    ) -> MasteryTrackInventorySearchResponse:
        """Search and filter tests in MasteryTrack inventory.

        Args:
            params: Optional inventory search filters.

        Returns:
            Inventory search response with matching items.
        """
        search_params = params or {}
        validate_with_schema(
            MasteryTrackInventorySearchParams,
            search_params,
            "MasteryTrack inventory search",
        )

        if isinstance(search_params, MasteryTrackInventorySearchParams):
            query = search_params.model_dump(exclude_none=True)
        elif isinstance(search_params, dict):
            query = {k: v for k, v in search_params.items() if v is not None}
        else:
            query = {}

        result = await self._transport.get(
            "/authoring/inventory/search",
            params=query or None,
        )
        return MasteryTrackInventorySearchResponse.model_validate(result)


__all__ = ["InventoryResource"]
