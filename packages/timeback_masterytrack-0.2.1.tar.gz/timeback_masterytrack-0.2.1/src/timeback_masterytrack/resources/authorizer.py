"""
Authorizer Resource

MasteryTrack authorizer endpoint access.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from timeback_common import validate_with_schema

from ..types.inputs import MasteryTrackAuthorizerInput
from ..types.responses import MasteryTrackAuthorizerResponse

if TYPE_CHECKING:
    from ..lib.token_provider import MasteryTrackJwtProvider


class AuthorizerResource:
    """Resource for MasteryTrack authorizer operations."""

    def __init__(self, authenticator: MasteryTrackJwtProvider) -> None:
        self._authenticator = authenticator

    async def get_token(self, email: str | None = None) -> MasteryTrackAuthorizerResponse:
        """Authenticate and return a fresh MasteryTrack JWT.

        Args:
            email: Optional email override for the authorizer request.

        Returns:
            Authorizer success payload with JWT.
        """
        if email:
            validate_with_schema(
                MasteryTrackAuthorizerInput, {"email": email}, "MasteryTrack authorizer input"
            )
        jwt = await self._authenticator.get_token(email)
        return MasteryTrackAuthorizerResponse(success=True, jwt=jwt)


__all__ = ["AuthorizerResource"]
