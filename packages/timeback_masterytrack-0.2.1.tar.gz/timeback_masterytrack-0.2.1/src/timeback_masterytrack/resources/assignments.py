"""
Assignments Resource

MasteryTrack test assignment operations.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from timeback_common import validate_with_schema

from ..types.inputs import (
    MasteryTrackAssignmentInput,
    MasteryTrackInvalidateAssignmentInput,
)
from ..types.responses import (
    MasteryTrackAssignResponse,
    MasteryTrackInvalidateResponse,
)

if TYPE_CHECKING:
    from ..lib.transport import Transport


class AssignmentsResource:
    """Resource for MasteryTrack assignment operations."""

    def __init__(self, transport: Transport) -> None:
        self._transport = transport

    async def assign(
        self,
        input_data: dict[str, Any] | MasteryTrackAssignmentInput,
    ) -> MasteryTrackAssignResponse:
        """Assign a test to a student.

        Args:
            input_data: Assignment payload with student_email and test identifiers.

        Returns:
            Assignment response envelope.
        """
        validate_with_schema(
            MasteryTrackAssignmentInput, input_data, "MasteryTrack assignment input"
        )

        if isinstance(input_data, MasteryTrackAssignmentInput):
            body = input_data.model_dump(exclude_none=True)
        else:
            body = MasteryTrackAssignmentInput.model_validate(input_data).model_dump(
                exclude_none=True
            )

        result = await self._transport.post("/delivery/assignments/assign", body)
        return MasteryTrackAssignResponse.model_validate(result)

    async def invalidate(
        self,
        input_data: dict[str, Any] | MasteryTrackInvalidateAssignmentInput,
    ) -> MasteryTrackInvalidateResponse:
        """Invalidate one or more assignments for a student.

        Args:
            input_data: Invalidation payload with student_email and identifiers.

        Returns:
            Invalidation response envelope.
        """
        validate_with_schema(
            MasteryTrackInvalidateAssignmentInput,
            input_data,
            "MasteryTrack invalidate assignment input",
        )

        if isinstance(input_data, MasteryTrackInvalidateAssignmentInput):
            body = input_data.model_dump(exclude_none=True)
        else:
            body = MasteryTrackInvalidateAssignmentInput.model_validate(input_data).model_dump(
                exclude_none=True
            )

        result = await self._transport.post("/delivery/assignments/invalidate", body)
        return MasteryTrackInvalidateResponse.model_validate(result)


__all__ = ["AssignmentsResource"]
