package config

import "strings"

// LLMProviderID names the upstream LLM API for defaults (base URL + default model).
type LLMProviderID string

const (
	ProviderOpenRouter LLMProviderID = "openrouter"
	ProviderGemini     LLMProviderID = "gemini"
)

// DefaultBaseURL returns the OpenAI-compatible chat/completions base (no trailing slash).
func (p LLMProviderID) DefaultBaseURL() string {
	switch p {
	case ProviderGemini:
		return "https://generativelanguage.googleapis.com/v1beta/openai"
	case ProviderOpenRouter:
		fallthrough
	default:
		return "https://openrouter.ai/api/v1"
	}
}

// DefaultModel is a sensible default for each provider (override with LLM_MODEL or file).
func (p LLMProviderID) DefaultModel() string {
	switch p {
	case ProviderGemini:
		return "gemini-2.5-flash"
	case ProviderOpenRouter:
		fallthrough
	default:
		return "anthropic/claude-sonnet-4"
	}
}

// ParseLLMProvider maps user input (1–2 or name) to a provider id.
func ParseLLMProvider(s string) (LLMProviderID, bool) {
	s = strings.TrimSpace(strings.ToLower(s))
	switch s {
	case "1", "openrouter", "or":
		return ProviderOpenRouter, true
	case "2", "gemini", "google", "gem":
		return ProviderGemini, true
	default:
		return "", false
	}
}
