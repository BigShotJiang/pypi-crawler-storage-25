package tools

import (
	"context"
	"fmt"

	"github.com/ClareAI/astra-insight-mcp/internal/gateway"
	"github.com/ClareAI/astra-insight-mcp/internal/mcp"
)

func registerListActions(s *mcp.Server, gw *gateway.Client) {
	tool := mcp.Tool{
		Name:        "list_actions",
		Description: "List all configured actions (tools) for the tenant — including platform integrations like HubSpot, Calendly, WhatsApp, web search, etc. Shows action names, platforms, types, and connection status. Use this to understand what capabilities the agent has.",
		InputSchema: mcp.InputSchema{
			Type:       "object",
			Properties: map[string]mcp.Property{},
			Required:   []string{},
		},
	}

	s.RegisterTool(tool, func(ctx context.Context, args map[string]interface{}) (interface{}, error) {
		apiKey := apiKeyFromArgs(args)
		if apiKey == "" {
			return nil, fmt.Errorf("api_key is required")
		}

		return gw.ListActions(ctx, apiKey, gateway.ActionListOpts{})
	})
}

func registerGetAction(s *mcp.Server, gw *gateway.Client) {
	tool := mcp.Tool{
		Name:        "get_action",
		Description: "Get details of a single action — name, description, type, platform, connection status, and configuration. Use this to inspect a specific integration.",
		InputSchema: mcp.InputSchema{
			Type: "object",
			Properties: map[string]mcp.Property{
				"action_id": {Type: "string", Description: "Action ID"},
			},
			Required: []string{"action_id"},
		},
	}

	s.RegisterTool(tool, func(ctx context.Context, args map[string]interface{}) (interface{}, error) {
		apiKey := apiKeyFromArgs(args)
		actionID, _ := args["action_id"].(string)
		if apiKey == "" || actionID == "" {
			return nil, fmt.Errorf("api_key and action_id are required")
		}
		return gw.GetAction(ctx, apiKey, actionID)
	})
}

func registerCreateAction(s *mcp.Server, gw *gateway.Client) {
	s.RegisterTool(mcp.Tool{
		Name:        "create_action",
		Description: "Create a new action (integration tool).",
		InputSchema: mcp.InputSchema{
			Type: "object",
			Properties: map[string]mcp.Property{
				"api_key":        {Type: "string", Description: "API key"},
				"name":           {Type: "string", Description: "Action name"},
				"type":           {Type: "string", Description: "Action type: internal or external"},
				"description":    {Type: "string", Description: "Action description"},
				"platform":       {Type: "string", Description: "Platform identifier"},
				"connection_id":  {Type: "string", Description: "Connection UUID"},
				"execution_type": {Type: "string", Description: "Execution type: auto_run, requires_approval, or agent_decide"},
			},
			Required: []string{"name", "type"},
		},
	}, func(ctx context.Context, args map[string]interface{}) (interface{}, error) {
		apiKey := apiKeyFromArgs(args)
		if apiKey == "" {
			return nil, fmt.Errorf("api_key is required")
		}
		name := strval(args, "name")
		actionType := strval(args, "type")
		if name == "" || actionType == "" {
			return nil, fmt.Errorf("name and type are required")
		}
		req := gateway.ActionCreateRequest{
			Name:          name,
			Type:          actionType,
			Description:   strval(args, "description"),
			Platform:      strval(args, "platform"),
			ConnectionID:  strval(args, "connection_id"),
			ExecutionType: strval(args, "execution_type"),
		}
		return gw.CreateAction(ctx, apiKey, req)
	})
}

func registerUpdateAction(s *mcp.Server, gw *gateway.Client) {
	s.RegisterTool(mcp.Tool{
		Name:        "update_action",
		Description: "Update an existing action.",
		InputSchema: mcp.InputSchema{
			Type: "object",
			Properties: map[string]mcp.Property{
				"api_key":        {Type: "string", Description: "API key"},
				"action_id":      {Type: "string", Description: "Action UUID"},
				"name":           {Type: "string", Description: "New name"},
				"description":    {Type: "string", Description: "New description"},
				"execution_type": {Type: "string", Description: "New execution type"},
			},
			Required: []string{"action_id"},
		},
	}, func(ctx context.Context, args map[string]interface{}) (interface{}, error) {
		apiKey := apiKeyFromArgs(args)
		actionID, _ := args["action_id"].(string)
		if apiKey == "" || actionID == "" {
			return nil, fmt.Errorf("api_key and action_id are required")
		}
		req := gateway.ActionUpdateRequest{
			Name:          strval(args, "name"),
			Description:   strval(args, "description"),
			ExecutionType: strval(args, "execution_type"),
		}
		return gw.UpdateAction(ctx, apiKey, actionID, req)
	})
}

func registerDeleteAction(s *mcp.Server, gw *gateway.Client) {
	s.RegisterTool(mcp.Tool{
		Name:        "delete_action",
		Description: "Delete an action by ID.",
		InputSchema: mcp.InputSchema{
			Type: "object",
			Properties: map[string]mcp.Property{
				"api_key":   {Type: "string", Description: "API key"},
				"action_id": {Type: "string", Description: "Action UUID"},
			},
			Required: []string{"action_id"},
		},
	}, func(ctx context.Context, args map[string]interface{}) (interface{}, error) {
		apiKey := apiKeyFromArgs(args)
		actionID, _ := args["action_id"].(string)
		if apiKey == "" || actionID == "" {
			return nil, fmt.Errorf("api_key and action_id are required")
		}
		return gw.DeleteAction(ctx, apiKey, actionID)
	})
}
