package main

import (
	"flag"

	"github.com/ClareAI/astra-insight-mcp/internal/app"
)

func main() {
	debug := flag.Bool("debug", false, "print full curl commands for every gateway API call")
	flag.Parse()
	app.RunMCPServer(*debug)
}
