"""
Lutflow x TinyFish — GPU Price Arbitrage Demo

This script demonstrates how TinyFish feeds Lutflow's Lookup layer
with real-time GPU prices, enabling cost-optimal deployment decisions.

Flow:
  TinyFish navigates RunPod/Vast.ai/CoreWeave live
       ↓
  Prices feed PCPO recommendation engine
       ↓
  Deploy on cheapest provider with budget enforcement active

Usage:
  export TINYFISH_API_KEY="your_key"    # optional — falls back to cached prices
  python examples/tinyfish_gpu_lookup.py
"""

from rich.console import Console
from rich.table import Table

from lutflow.tinyfish import TinyFishClient

console = Console()

MODEL = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"
BUDGET = 0.10
GPU = "nvidia-l4"


def main():
    console.print("\n[bold cyan]═══════════════════════════════════════[/bold cyan]")
    console.print("[bold cyan]  Lutflow x TinyFish — GPU Arbitrage   [/bold cyan]")
    console.print("[bold cyan]═══════════════════════════════════════[/bold cyan]\n")

    console.print(f"Model: [yellow]{MODEL}[/yellow]")
    console.print(f"Budget: [green]${BUDGET:.2f}[/green]")
    console.print(f"GPU: {GPU}\n")

    # Step 1: TinyFish fetches live GPU prices
    console.print("[bold]Step 1/3:[/bold] TinyFish fetching live GPU prices...\n")

    tf = TinyFishClient()
    result = tf.fetch_all_prices(gpu_type=GPU)

    # Step 2: Display pricing table
    console.print("[bold]Step 2/3:[/bold] Live pricing analysis\n")

    table = Table(title=f"Live GPU Spot Prices — {GPU.upper()}")
    table.add_column("Provider", style="cyan")
    table.add_column("$/hour", justify="right", style="green")
    table.add_column(f"Runtime for ${BUDGET:.2f}", justify="right")
    table.add_column("Source")

    sorted_prices = sorted(result.prices, key=lambda p: p.spot_usd_per_hour)

    for i, p in enumerate(sorted_prices):
        runtime = (BUDGET / p.spot_usd_per_hour) * 60 if p.spot_usd_per_hour > 0 else 0
        source_label = (
            "[green]live[/green]"
            if p.source == "tinyfish_live"
            else "[yellow]cached[/yellow]"
        )
        best = " [bold green]← SELECT[/bold green]" if i == 0 else ""
        table.add_row(
            p.provider,
            f"${p.spot_usd_per_hour:.2f}",
            f"~{runtime:.0f} min",
            source_label + best,
        )

    console.print(table)

    # Step 3: Lutflow deploys with enforcement
    console.print("\n[bold]Step 3/3:[/bold] Lutflow deploying with budget enforcement\n")

    cheapest = result.cheapest
    if cheapest:
        runtime_min = result.budget_runtime_minutes(BUDGET)
        console.print(f"[green]✓[/green] Provider selected: [bold]{cheapest.provider}[/bold]")
        console.print(f"[green]✓[/green] Price: ${cheapest.spot_usd_per_hour:.2f}/hr")
        console.print(f"[green]✓[/green] Budget: ${BUDGET:.2f}")
        console.print(f"[green]✓[/green] Estimated runtime: ~{runtime_min:.0f} min")
        console.print(f"[green]✓[/green] Kill path: ACTIVE — SIGKILL at budget breach\n")

        console.print("[bold cyan]═══════════════════════════════════════[/bold cyan]")
        console.print("[bold green]  Lookup → Flow → Value               [/bold green]")
        console.print("[bold cyan]═══════════════════════════════════════[/bold cyan]")
        console.print(f"[dim]TinyFish found the price. Lutflow enforces it.[/dim]\n")


if __name__ == "__main__":
    main()
