"""Pytest configuration for Lutflow SDK tests."""

import pytest


@pytest.fixture
def mock_openai_response():
    """Mock OpenAI chat completion response."""
    class MockUsage:
        prompt_tokens = 100
        completion_tokens = 50
    
    class MockMessage:
        content = "Hello! How can I help you today?"
        role = "assistant"
    
    class MockChoice:
        message = MockMessage()
        index = 0
        finish_reason = "stop"
    
    class MockResponse:
        id = "chatcmpl-123"
        object = "chat.completion"
        created = 1677652288
        model = "gpt-4"
        choices = [MockChoice()]
        usage = MockUsage()
    
    return MockResponse()


@pytest.fixture
def mock_anthropic_response():
    """Mock Anthropic message response."""
    class MockUsage:
        input_tokens = 100
        output_tokens = 50
    
    class MockTextBlock:
        type = "text"
        text = "Hello! How can I help you today?"
    
    class MockResponse:
        id = "msg_123"
        type = "message"
        role = "assistant"
        content = [MockTextBlock()]
        model = "claude-3-sonnet-20240229"
        stop_reason = "end_turn"
        usage = MockUsage()
    
    return MockResponse()
