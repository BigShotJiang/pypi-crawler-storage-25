# TinyFish Integration

## Overview

TinyFish powers Lutflow's **Lookup** layer — real-time GPU price discovery across cloud providers without relying on static pricing APIs.

```
TinyFish navigates provider pricing pages live
       ↓
Structured pricing data returned to Lutflow
       ↓
PCPO selects cheapest provider for deployment
       ↓
Lutflow enforces budget on selected provider
```

## Architecture

```
┌──────────────────────────────────────────┐
│            lutflow lookup                 │
│   CLI command / Python API               │
├──────────────────────────────────────────┤
│         TinyFishClient                   │
│   - fetch_gpu_price(provider, gpu_type)  │
│   - fetch_all_prices(gpu_type)           │
│   - Falls back to cached if no API key   │
├──────────────────────────────────────────┤
│     TinyFish Web Agent API               │
│   https://agent.tinyfish.ai/v1/          │
│   - Navigates pricing pages              │
│   - Returns structured JSON              │
└──────────────────────────────────────────┘
```

## Usage

### CLI

```bash
# Default: scan runpod, vastai, coreweave
lutflow lookup --gpu nvidia-l4

# Custom providers
lutflow lookup --gpu nvidia-a100-80gb --providers runpod,vastai
```

### Python API

```python
from lutflow.tinyfish import TinyFishClient

client = TinyFishClient()  # reads TINYFISH_API_KEY from env
result = client.fetch_all_prices(gpu_type="nvidia-l4")

for price in sorted(result.prices, key=lambda p: p.spot_usd_per_hour):
    print(f"{price.provider}: ${price.spot_usd_per_hour:.2f}/hr ({price.source})")

best = result.cheapest
print(f"\nRecommendation: {best.provider} at ${best.spot_usd_per_hour:.2f}/hr")
```

## Configuration

| Environment Variable | Required | Description |
|---------------------|----------|-------------|
| `TINYFISH_API_KEY` | No | API key for live pricing. Without it, cached prices are used. |

## Cached Prices

When `TINYFISH_API_KEY` is not set, the client returns conservative cached prices:

| Provider | Spot $/hr | On-Demand $/hr |
|----------|-----------|----------------|
| RunPod | $0.44 | $0.74 |
| Vast.ai | $0.39 | $0.65 |
| CoreWeave | $0.54 | $0.81 |
| Lambda Labs | $0.50 | $0.80 |

These are updated periodically with the SDK releases.

## Providers Supported

- **RunPod** — runpod.io/gpu-instance/pricing
- **Vast.ai** — vast.ai/pricing
- **CoreWeave** — coreweave.com/gpu-cloud-pricing
- **Lambda Labs** — lambdalabs.com/service/gpu-cloud

## Data Flow in Lutflow

```
lutflow lookup --gpu nvidia-l4
       ↓
TinyFishClient.fetch_all_prices()
       ↓
GPUPricingResult { prices: [...], cheapest: {...} }
       ↓
lutflow deploy --model ... --budget 0.10
       ↓
Deploy on cheapest provider → Sentinel monitors → Kill on breach
```

This is the **Lookup → Flow → Value** pipeline.
