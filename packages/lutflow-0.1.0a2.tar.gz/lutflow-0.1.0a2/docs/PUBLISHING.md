# Lutflow SDK Publishing Guide

## Prerequisites

1. PyPI account with 2FA enabled
2. API token from https://pypi.org/manage/account/token/
3. `twine` installed: `pip install twine build`

## Build

```bash
cd sdk-python
python -m build
```

This creates:
- `dist/lutflow-0.1.0.tar.gz` (source distribution)
- `dist/lutflow-0.1.0-py3-none-any.whl` (wheel)

## Test on TestPyPI

```bash
# Upload to TestPyPI first
twine upload --repository testpypi dist/*

# Test installation
pip install --index-url https://test.pypi.org/simple/ lutflow
```

## Publish to PyPI

```bash
# Upload to PyPI
twine upload dist/*

# Verify
pip install lutflow
python -c "from lutflow import Client; print('OK')"
```

## Version Bumping

1. Update version in `pyproject.toml`
2. Update version in `lutflow/__init__.py`
3. Create git tag: `git tag v0.1.0`
4. Push tag: `git push origin v0.1.0`

## CI/CD (GitHub Actions)

Add `.github/workflows/publish-sdk.yml`:

```yaml
name: Publish SDK to PyPI

on:
  release:
    types: [published]

jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - name: Build
        run: |
          cd sdk-python
          pip install build
          python -m build
      - name: Publish
        uses: pypa/gh-action-pypi-publish@release/v1
        with:
          packages-dir: sdk-python/dist/
```
