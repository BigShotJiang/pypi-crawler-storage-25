# Lutflow Python SDK Documentation

## Overview

The Lutflow Python SDK provides a simple way to track and enforce budgets for LLM API calls. It wraps popular LLM providers (OpenAI, Anthropic) and automatically tracks costs, enforcing budget limits based on your configured strategy.

## Installation

```bash
# Basic installation
pip install lutflow

# With OpenAI support
pip install lutflow[openai]

# With Anthropic support
pip install lutflow[anthropic]

# With all providers
pip install lutflow[all]
```

## Quick Start

```python
from lutflow import Client, BudgetStrategy

# Create a client with budget constraints
client = Client(
    tenant_id="my-tenant",
    api_key="lut_xxx",  # Optional: enables cloud reporting
    budget_usd=10.00,
    on_budget_exceeded=BudgetStrategy.SELF_KILL  # Default
)

# Wrap your OpenAI client
import openai
wrapped = client.wrap(openai.OpenAI())

# Use as normal - Lutflow tracks costs automatically
response = wrapped.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Hello!"}]
)

# Check remaining budget
print(f"Remaining: ${client.remaining_budget_usd:.4f}")
print(f"Utilization: {client.budget_utilization_percent:.1f}%")
```

## Budget Strategies

The SDK supports four strategies for handling budget exceeded events:

| Strategy | Description | Use Case |
|----------|-------------|----------|
| `SELF_KILL` | Terminate process immediately | Production workloads, autonomous agents |
| `RAISE_ERROR` | Raise `BudgetExceededError` | Interactive applications |
| `WARN_ONLY` | Log warning but continue | Development, testing |
| `CALLBACK` | Call custom function | Custom handling logic |

### Examples

```python
# Self-kill (default) - process terminates when budget exceeded
client = Client(
    tenant_id="my-tenant",
    budget_usd=5.00,
    on_budget_exceeded=BudgetStrategy.SELF_KILL
)

# Raise error - catch and handle in your code
client = Client(
    tenant_id="my-tenant",
    budget_usd=5.00,
    on_budget_exceeded=BudgetStrategy.RAISE_ERROR
)

try:
    response = wrapped.chat.completions.create(...)
except BudgetExceededError as e:
    print(f"Budget exceeded: ${e.spent_usd:.2f} of ${e.budget_usd:.2f}")

# Custom callback
def on_budget_exceeded(spent: float, budget: float):
    send_alert(f"Budget exceeded: ${spent:.2f}")
    graceful_shutdown()

client = Client(
    tenant_id="my-tenant",
    budget_usd=5.00,
    on_budget_exceeded=BudgetStrategy.CALLBACK,
    on_exceeded_callback=on_budget_exceeded
)
```

## Supported Providers

### OpenAI

```python
from lutflow import Client
import openai

client = Client(tenant_id="my-tenant", budget_usd=10.00)
wrapped = client.wrap(openai.OpenAI())

# Chat completions
response = wrapped.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Hello!"}]
)

# Embeddings
response = wrapped.embeddings.create(
    model="text-embedding-3-small",
    input="Hello world"
)
```

### Anthropic

```python
from lutflow import Client
import anthropic

client = Client(tenant_id="my-tenant", budget_usd=10.00)
wrapped = client.wrap(anthropic.Anthropic())

# Messages
response = wrapped.messages.create(
    model="claude-3-sonnet-20240229",
    max_tokens=1024,
    messages=[{"role": "user", "content": "Hello!"}]
)

# Streaming
with wrapped.messages.stream(
    model="claude-3-sonnet-20240229",
    max_tokens=1024,
    messages=[{"role": "user", "content": "Hello!"}]
) as stream:
    for text in stream.text_stream:
        print(text, end="")
```

## GPU Time Pricing

For self-hosted models (vLLM, TGI), use GPU-time pricing:

```python
from lutflow import Client, PricingMode

client = Client(
    tenant_id="my-tenant",
    budget_usd=5.00,
    pricing_mode=PricingMode.GPU_TIME,
    gpu_type="nvidia-l4",
    gpu_hourly_rate_usd=0.80,  # Optional: override default rate
)

# Manual GPU time reporting
client.report_gpu_seconds(elapsed_seconds=120, gpu_count=1)

# Or use the timer
client.start_gpu_timer()
# ... run inference ...
cost = client.stop_gpu_timer()
print(f"Inference cost: ${cost:.4f}")
```

## Cloud Reporting

When an API key is provided, the SDK reports usage to Lutflow Cloud:

```python
client = Client(
    tenant_id="my-tenant",
    api_key="lut_xxx",  # Enables cloud reporting
    budget_usd=10.00,
    report_to_cloud=True  # Default when api_key is set
)
```

This enables:
- Centralized cost tracking across all deployments
- Real-time dashboards and alerts
- Historical usage analytics
- Team and project-level budgets

## Configuration Reference

### Client Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `tenant_id` | str | Required | Your Lutflow tenant identifier |
| `api_key` | str | None | Lutflow API key (enables cloud reporting) |
| `budget_usd` | float | 10.0 | Maximum budget in USD |
| `deployment_id` | str | Auto | Deployment identifier for tracking |
| `pricing_mode` | PricingMode | TOKEN_BASED | How to calculate costs |
| `on_budget_exceeded` | BudgetStrategy | SELF_KILL | Strategy when budget exceeded |
| `on_exceeded_callback` | Callable | None | Custom callback for CALLBACK strategy |
| `price_per_1k_usd` | float | None | Custom price per 1K tokens |
| `gpu_type` | str | "nvidia-l4" | GPU type for GPU_TIME pricing |
| `gpu_hourly_rate_usd` | float | None | Custom GPU hourly rate |
| `gpu_count` | int | 1 | Number of GPUs |
| `api_base_url` | str | https://api.lutflow.dev | Lutflow API base URL |
| `report_to_cloud` | bool | True (if api_key) | Whether to report to cloud |

### Pricing Modes

| Mode | Description |
|------|-------------|
| `TOKEN_BASED` | Price based on input/output tokens (API providers) |
| `GPU_TIME` | Price based on GPU time (self-hosted models) |
| `HYBRID` | Combination of token and GPU time pricing |

## Error Handling

```python
from lutflow import Client, BudgetStrategy
from lutflow.budget import BudgetExceededError

client = Client(
    tenant_id="my-tenant",
    budget_usd=5.00,
    on_budget_exceeded=BudgetStrategy.RAISE_ERROR
)

try:
    response = wrapped.chat.completions.create(...)
except BudgetExceededError as e:
    print(f"Budget: ${e.budget_usd:.2f}")
    print(f"Spent: ${e.spent_usd:.2f}")
    print(f"Tenant: {e.tenant_id}")
    print(f"Deployment: {e.deployment_id}")
```

## Best Practices

1. **Set realistic budgets**: Start with small budgets and increase as needed
2. **Use SELF_KILL for autonomous agents**: Prevents runaway costs
3. **Use RAISE_ERROR for interactive apps**: Allows graceful handling
4. **Monitor utilization**: Check `budget_utilization_percent` regularly
5. **Enable cloud reporting**: Centralized visibility across deployments

## Troubleshooting

### Budget not enforced

Ensure you're using the wrapped client, not the original:

```python
# Wrong - original client, no tracking
response = openai_client.chat.completions.create(...)

# Correct - wrapped client with tracking
response = wrapped.chat.completions.create(...)
```

### Token counts differ from provider

The SDK uses tiktoken for token estimation. Actual costs are calculated from the response usage when available.

### Cloud reporting fails

Check your API key and network connectivity. Cloud reporting is best-effort and won't block your application.

## Support

- Documentation: https://docs.lutflow.dev/sdk/python
- Issues: https://github.com/Lutflow/lutflow/issues
- Email: support@lutflow.dev
