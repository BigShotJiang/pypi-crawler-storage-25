# Demo Script — Lutflow x TinyFish (2:30 min)

## Setup

```bash
# Terminal 1: Dashboard
lutflow watch --demo

# Terminal 2: Commands (ready, don't execute yet)

# Browser: lutflow.dev open on dashboard
```

## Recording

- Tool: QuickTime Player or OBS Studio
- Resolution: 1920x1080 minimum
- Audio: English narration

---

## Script

### [0:00-0:15] The Problem

> "AI teams are burning budgets in milliseconds.
> Traditional FinOps sees the damage 24 hours later.
> Lutflow enforces in real-time."

*Show lutflow.dev dashboard*

### [0:15-0:45] The Lookup with TinyFish

> "Before we deploy any model, Lutflow needs to know the real market price.
> TinyFish gives us that."

```bash
lutflow lookup --gpu nvidia-l4
```

*Watch pricing table appear*

> "TinyFish just navigated three GPU providers live.
> No static APIs. Real prices, right now."

### [0:45-1:30] Deploy with Enforcement

> "Now we deploy with budget enforcement active."

```bash
lutflow deploy \
  --model TinyLlama/TinyLlama-1.1B-Chat-v1.0 \
  --budget 0.10 \
  --tenant tinyfish-demo
```

*Show kill path confirmation*

```bash
lutflow watch
```

*Dashboard appears, budget filling up*

### [1:30-2:00] The Kill Path

*Budget gauge reaches 100%*

> "Budget reached. Lutflow executes SIGKILL.
> Under 500 milliseconds.
> No human intervention. No damage."

*Show kill confirmed in dashboard*

### [2:00-2:20] pip install

> "This is open for developers right now."

```bash
pip install lutflow
lutflow --help
```

### [2:20-2:30] Call to Action

*Show lutflow.dev/waitlist*

> "Built from Paraguay.
> Lookup → Flow → Value.
> lutflow.dev"

---

## Post-Production

- Cut long silences
- Add on-screen text: `pip install lutflow` and `lutflow.dev/waitlist`
- No music or fancy transitions — authenticity is the point
- Target: 2:30 exact
