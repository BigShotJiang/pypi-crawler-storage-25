"""
PCPO (Predictive Cost & Performance Optimization) integration for Lutflow SDK.

This module provides cost prediction capabilities based on historical usage data.
It enables pre-emptive budget enforcement by predicting costs before execution.

Phase 2 Feature - Requires Lutflow Cloud subscription.
"""

from dataclasses import dataclass
from typing import Optional, Dict, Any
import logging

logger = logging.getLogger("lutflow")


@dataclass
class CostPrediction:
    """Predicted cost for an LLM operation."""
    
    estimated_cost_usd: float
    """Estimated cost in USD."""
    
    confidence: float
    """Confidence level (0.0 to 1.0)."""
    
    estimated_input_tokens: int
    """Estimated input token count."""
    
    estimated_output_tokens: int
    """Estimated output token count."""
    
    model: str
    """Model used for prediction."""
    
    warning: Optional[str] = None
    """Warning message if prediction may be inaccurate."""


class CostPredictor:
    """
    Predicts costs for LLM operations before execution.
    
    Uses historical data and model-specific patterns to estimate costs.
    This enables pre-emptive budget enforcement - rejecting requests
    that would exceed the budget before they're sent to the provider.
    
    Example:
        >>> predictor = CostPredictor(api_key="lut_xxx")
        >>> prediction = predictor.predict(
        ...     model="gpt-4",
        ...     prompt="Write a 500 word essay about AI",
        ...     max_tokens=1000
        ... )
        >>> if prediction.estimated_cost_usd > remaining_budget:
        ...     raise BudgetExceededError(...)
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        api_base_url: str = "https://api.lutflow.dev",
        use_local_model: bool = True,
    ):
        """
        Initialize the cost predictor.
        
        Args:
            api_key: Lutflow API key for cloud predictions.
            api_base_url: Lutflow API base URL.
            use_local_model: Use local heuristics when cloud unavailable.
        """
        self.api_key = api_key
        self.api_base_url = api_base_url
        self.use_local_model = use_local_model
        
        # Local model coefficients (trained on historical data)
        # These are fallback values when cloud prediction is unavailable
        self._local_coefficients: Dict[str, Dict[str, float]] = {
            "gpt-4": {
                "base_output_ratio": 1.5,  # output tokens / input tokens
                "variance": 0.3,
            },
            "gpt-4-turbo": {
                "base_output_ratio": 1.8,
                "variance": 0.25,
            },
            "gpt-3.5-turbo": {
                "base_output_ratio": 2.0,
                "variance": 0.35,
            },
            "claude-3-opus": {
                "base_output_ratio": 1.4,
                "variance": 0.2,
            },
            "claude-3-sonnet": {
                "base_output_ratio": 1.6,
                "variance": 0.25,
            },
            "claude-3-haiku": {
                "base_output_ratio": 2.2,
                "variance": 0.3,
            },
        }
    
    def predict(
        self,
        model: str,
        prompt: str,
        max_tokens: int = 1000,
        system_prompt: Optional[str] = None,
        temperature: float = 0.7,
    ) -> CostPrediction:
        """
        Predict the cost of an LLM operation.
        
        Args:
            model: Model identifier (e.g., "gpt-4", "claude-3-sonnet").
            prompt: User prompt text.
            max_tokens: Maximum output tokens.
            system_prompt: Optional system prompt.
            temperature: Sampling temperature (affects output length).
            
        Returns:
            CostPrediction with estimated cost and confidence.
        """
        # Try cloud prediction first
        if self.api_key:
            try:
                return self._predict_cloud(
                    model, prompt, max_tokens, system_prompt, temperature
                )
            except Exception as e:
                logger.debug("LUTFLOW: Cloud prediction failed, using local: %s", e)
        
        # Fall back to local prediction
        if self.use_local_model:
            return self._predict_local(
                model, prompt, max_tokens, system_prompt, temperature
            )
        
        # No prediction available
        return CostPrediction(
            estimated_cost_usd=0.0,
            confidence=0.0,
            estimated_input_tokens=0,
            estimated_output_tokens=0,
            model=model,
            warning="Prediction unavailable - no API key and local model disabled",
        )
    
    def _predict_cloud(
        self,
        model: str,
        prompt: str,
        max_tokens: int,
        system_prompt: Optional[str],
        temperature: float,
    ) -> CostPrediction:
        """Predict using Lutflow Cloud ML model."""
        import httpx
        
        response = httpx.post(
            f"{self.api_base_url}/api/v1/predict-cost",
            json={
                "model": model,
                "prompt": prompt,
                "max_tokens": max_tokens,
                "system_prompt": system_prompt,
                "temperature": temperature,
            },
            headers={"Authorization": f"Bearer {self.api_key}"},
            timeout=5.0,
        )
        response.raise_for_status()
        data = response.json()
        
        return CostPrediction(
            estimated_cost_usd=data["estimated_cost_usd"],
            confidence=data["confidence"],
            estimated_input_tokens=data["estimated_input_tokens"],
            estimated_output_tokens=data["estimated_output_tokens"],
            model=model,
        )
    
    def _predict_local(
        self,
        model: str,
        prompt: str,
        max_tokens: int,
        system_prompt: Optional[str],
        temperature: float,
    ) -> CostPrediction:
        """Predict using local heuristics."""
        from lutflow.wrappers.openai import count_tokens
        from lutflow.pricing import PricingCalculator
        
        # Count input tokens
        input_tokens = count_tokens(prompt, model)
        if system_prompt:
            input_tokens += count_tokens(system_prompt, model)
        
        # Get model coefficients
        model_key = self._normalize_model(model)
        coeffs = self._local_coefficients.get(
            model_key,
            {"base_output_ratio": 1.5, "variance": 0.3}
        )
        
        # Estimate output tokens
        # Higher temperature = more variance in output length
        temp_factor = 1.0 + (temperature - 0.7) * 0.2
        base_output = int(input_tokens * coeffs["base_output_ratio"] * temp_factor)
        estimated_output = min(base_output, max_tokens)
        
        # Calculate cost
        calculator = PricingCalculator()
        estimated_cost = calculator.calculate_token_cost(
            model, input_tokens, estimated_output
        )
        
        # Confidence based on model familiarity and variance
        confidence = 0.7 - coeffs["variance"]
        if model_key not in self._local_coefficients:
            confidence = 0.4  # Unknown model
        
        return CostPrediction(
            estimated_cost_usd=estimated_cost,
            confidence=confidence,
            estimated_input_tokens=input_tokens,
            estimated_output_tokens=estimated_output,
            model=model,
            warning="Local prediction - accuracy may vary" if confidence < 0.6 else None,
        )
    
    def _normalize_model(self, model: str) -> str:
        """Normalize model name for coefficient lookup."""
        model = model.lower()
        
        if "gpt-4" in model:
            if "turbo" in model:
                return "gpt-4-turbo"
            return "gpt-4"
        if "gpt-3.5" in model:
            return "gpt-3.5-turbo"
        if "claude" in model:
            if "opus" in model:
                return "claude-3-opus"
            if "haiku" in model:
                return "claude-3-haiku"
            return "claude-3-sonnet"
        
        return model


class PredictiveBudgetGuard:
    """
    Budget guard with predictive enforcement.
    
    Extends the basic BudgetGuard with cost prediction capabilities.
    Rejects requests that are predicted to exceed the budget before
    they're sent to the provider.
    
    Example:
        >>> guard = PredictiveBudgetGuard(
        ...     budget_usd=10.0,
        ...     tenant_id="my-tenant",
        ...     api_key="lut_xxx"
        ... )
        >>> 
        >>> # Check if request would exceed budget
        >>> prediction = guard.predict_and_check(
        ...     model="gpt-4",
        ...     prompt="Write a long essay...",
        ...     max_tokens=2000
        ... )
        >>> if not prediction.allowed:
        ...     print(f"Request would exceed budget: ${prediction.estimated_cost_usd}")
    """
    
    def __init__(
        self,
        budget_usd: float,
        tenant_id: str,
        api_key: Optional[str] = None,
        safety_margin: float = 0.1,
    ):
        """
        Initialize the predictive budget guard.
        
        Args:
            budget_usd: Maximum budget in USD.
            tenant_id: Tenant identifier.
            api_key: Lutflow API key for cloud predictions.
            safety_margin: Safety margin (0.1 = 10% buffer).
        """
        self.budget_usd = budget_usd
        self.tenant_id = tenant_id
        self.safety_margin = safety_margin
        self._accumulated_cost_usd = 0.0
        self._predictor = CostPredictor(api_key=api_key)
    
    @property
    def remaining_budget_usd(self) -> float:
        """Remaining budget available."""
        return max(0.0, self.budget_usd - self._accumulated_cost_usd)
    
    @property
    def effective_remaining_usd(self) -> float:
        """Remaining budget with safety margin applied."""
        return self.remaining_budget_usd * (1 - self.safety_margin)
    
    def predict_and_check(
        self,
        model: str,
        prompt: str,
        max_tokens: int = 1000,
        system_prompt: Optional[str] = None,
    ) -> "PredictionResult":
        """
        Predict cost and check if request is allowed.
        
        Args:
            model: Model identifier.
            prompt: User prompt.
            max_tokens: Maximum output tokens.
            system_prompt: Optional system prompt.
            
        Returns:
            PredictionResult with allowed flag and prediction details.
        """
        prediction = self._predictor.predict(
            model=model,
            prompt=prompt,
            max_tokens=max_tokens,
            system_prompt=system_prompt,
        )
        
        allowed = prediction.estimated_cost_usd <= self.effective_remaining_usd
        
        return PredictionResult(
            allowed=allowed,
            prediction=prediction,
            remaining_budget_usd=self.remaining_budget_usd,
            effective_remaining_usd=self.effective_remaining_usd,
        )
    
    def add_cost(self, cost_usd: float) -> None:
        """Add actual cost after execution."""
        self._accumulated_cost_usd += cost_usd


@dataclass
class PredictionResult:
    """Result of a predictive budget check."""
    
    allowed: bool
    """Whether the request is allowed within budget."""
    
    prediction: CostPrediction
    """Cost prediction details."""
    
    remaining_budget_usd: float
    """Remaining budget before this request."""
    
    effective_remaining_usd: float
    """Remaining budget with safety margin."""
