"""Self-kill executor for budget enforcement."""

import logging
import os
import signal
import sys
from typing import Callable, Optional

logger = logging.getLogger("lutflow")


class SelfKillExecutor:
    """
    Executor that terminates the current process when budget is exceeded.
    
    This is the default kill mechanism for BYOC (Bring Your Own Cloud)
    deployments where Lutflow doesn't have infrastructure access.
    
    The executor provides multiple termination strategies:
    - SIGKILL: Immediate termination (default)
    - SIGTERM: Graceful termination with cleanup
    - sys.exit: Python-level exit
    """
    
    def __init__(
        self,
        graceful: bool = False,
        exit_code: int = 137,  # 128 + 9 (SIGKILL)
        cleanup_callback: Optional[Callable[[], None]] = None,
    ):
        """
        Initialize the self-kill executor.
        
        Args:
            graceful: If True, use SIGTERM instead of SIGKILL.
            exit_code: Exit code to use for sys.exit fallback.
            cleanup_callback: Optional callback to run before termination.
        """
        self.graceful = graceful
        self.exit_code = exit_code
        self.cleanup_callback = cleanup_callback
    
    def execute(
        self,
        reason: str = "budget_exceeded",
        spent_usd: float = 0.0,
        budget_usd: float = 0.0,
    ) -> None:
        """
        Execute self-termination.
        
        Args:
            reason: Reason for termination.
            spent_usd: Amount spent in USD.
            budget_usd: Budget limit in USD.
        """
        logger.critical(
            "LUTFLOW: Self-terminating process. reason=%s spent=$%.4f budget=$%.4f",
            reason,
            spent_usd,
            budget_usd,
        )
        
        # Run cleanup callback if provided
        if self.cleanup_callback:
            try:
                self.cleanup_callback()
            except Exception as e:
                logger.error("LUTFLOW: Cleanup callback failed: %s", e)
        
        # Flush all logs
        logging.shutdown()
        
        # Attempt termination
        pid = os.getpid()
        
        if self.graceful:
            # Graceful termination - allows cleanup handlers
            try:
                os.kill(pid, signal.SIGTERM)
            except Exception:
                pass
            
            # If SIGTERM didn't work, escalate to SIGKILL
            try:
                os.kill(pid, signal.SIGKILL)
            except Exception:
                pass
        else:
            # Immediate termination
            try:
                os.kill(pid, signal.SIGKILL)
            except Exception:
                pass
        
        # Fallback: sys.exit (may not work if signal handlers are blocked)
        sys.exit(self.exit_code)


class SubprocessKillExecutor:
    """
    Executor that terminates a subprocess when budget is exceeded.
    
    Use this when the LLM workload runs in a subprocess that the SDK
    can control (e.g., a vLLM server started by the SDK).
    """
    
    def __init__(
        self,
        pid: Optional[int] = None,
        graceful: bool = True,
        timeout_seconds: float = 5.0,
    ):
        """
        Initialize the subprocess kill executor.
        
        Args:
            pid: Process ID to kill. If None, must be set before execute().
            graceful: If True, try SIGTERM before SIGKILL.
            timeout_seconds: Time to wait for graceful termination.
        """
        self.pid = pid
        self.graceful = graceful
        self.timeout_seconds = timeout_seconds
    
    def set_pid(self, pid: int) -> None:
        """Set the target process ID."""
        self.pid = pid
    
    def execute(
        self,
        reason: str = "budget_exceeded",
        spent_usd: float = 0.0,
        budget_usd: float = 0.0,
    ) -> bool:
        """
        Execute subprocess termination.
        
        Args:
            reason: Reason for termination.
            spent_usd: Amount spent in USD.
            budget_usd: Budget limit in USD.
            
        Returns:
            True if process was terminated, False otherwise.
        """
        if self.pid is None:
            logger.error("LUTFLOW: SubprocessKillExecutor has no PID set")
            return False
        
        logger.warning(
            "LUTFLOW: Terminating subprocess pid=%d reason=%s spent=$%.4f",
            self.pid,
            reason,
            spent_usd,
        )
        
        try:
            if self.graceful:
                # Try graceful termination first
                os.kill(self.pid, signal.SIGTERM)
                
                # Wait for process to exit
                import time
                start = time.time()
                while time.time() - start < self.timeout_seconds:
                    try:
                        os.kill(self.pid, 0)  # Check if process exists
                        time.sleep(0.1)
                    except OSError:
                        # Process is gone
                        logger.info("LUTFLOW: Subprocess terminated gracefully")
                        return True
                
                # Process didn't exit, escalate to SIGKILL
                logger.warning("LUTFLOW: Graceful termination timed out, sending SIGKILL")
                os.kill(self.pid, signal.SIGKILL)
            else:
                os.kill(self.pid, signal.SIGKILL)
            
            return True
            
        except ProcessLookupError:
            logger.info("LUTFLOW: Process %d already terminated", self.pid)
            return True
        except PermissionError:
            logger.error("LUTFLOW: Permission denied to kill process %d", self.pid)
            return False
        except Exception as e:
            logger.error("LUTFLOW: Failed to kill process %d: %s", self.pid, e)
            return False
