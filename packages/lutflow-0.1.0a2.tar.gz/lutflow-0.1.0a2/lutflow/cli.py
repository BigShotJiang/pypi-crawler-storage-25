"""
Lutflow CLI — GPU Financial Firewall.

Install: pip install lutflow
Usage:   lutflow [command]
"""

import os
import random
import time
import uuid

import click
import httpx
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.progress import BarColumn, Progress, TextColumn
from rich.table import Table
from rich.text import Text

console = Console()

DEFAULT_ENDPOINT = "https://api.lutflow.dev"


def _endpoint() -> str:
    return os.getenv("LUTFLOW_ENDPOINT", DEFAULT_ENDPOINT)


# ═══════════════════════════════════════════════════════════════════
# Root group
# ═══════════════════════════════════════════════════════════════════

@click.group()
@click.version_option(version="0.1.0a2", prog_name="lutflow")
def cli():
    """
    \b
    Lutflow — GPU Financial Firewall
    Budget enforcement for AI inference workloads.

    \b
    Docs:  https://lutflow.dev/docs
    Demo:  https://lutflow.dev
    """


# ═══════════════════════════════════════════════════════════════════
# deploy
# ═══════════════════════════════════════════════════════════════════

@cli.command()
@click.option("--model", "-m", required=True, help="Model ID (e.g. TinyLlama/TinyLlama-1.1B-Chat-v1.0)")
@click.option("--budget", "-b", required=True, type=float, help="Budget in USD (e.g. 0.10)")
@click.option("--tenant", "-t", default="default", help="Tenant ID for isolation")
@click.option("--gpu", default="nvidia-l4", help="GPU type (default: nvidia-l4)")
@click.option("--endpoint", envvar="LUTFLOW_ENDPOINT", default=DEFAULT_ENDPOINT, help="Lutflow API endpoint")
def deploy(model: str, budget: float, tenant: str, gpu: str, endpoint: str):
    """Deploy a model with budget enforcement.

    \b
    Example:
      lutflow deploy --model TinyLlama/TinyLlama-1.1B-Chat-v1.0 --budget 0.10
    """
    console.print(f"\n[bold cyan]Lutflow GPU Financial Firewall[/bold cyan]")
    console.print(f"Deploying [yellow]{model}[/yellow]...")
    console.print(f"Budget: [green]${budget:.2f}[/green] | GPU: {gpu} | Tenant: {tenant}\n")

    try:
        r = httpx.post(
            f"{endpoint}/v1/deploy",
            json={
                "model_id": model,
                "budget_usd": budget,
                "tenant_id": tenant,
                "gpu_type": gpu,
                "framework": "vllm",
            },
            timeout=30,
        )
        r.raise_for_status()
        data = r.json()
        deploy_id = data.get("deployment_id", "unknown")

        console.print(f"[green]✓[/green] Deployment created: [bold]{deploy_id}[/bold]")
        console.print(f"[green]✓[/green] Kill path: [bold]ACTIVE[/bold]")
        console.print(f"[dim]Track with: lutflow status {deploy_id}[/dim]\n")

    except Exception:
        deploy_id = str(uuid.uuid4())[:8]
        console.print(f"[yellow][OFFLINE MODE][/yellow] API unreachable")
        console.print(f"[green]✓[/green] Local deployment ID: [bold]{deploy_id}[/bold]")
        console.print(f"[green]✓[/green] Budget tracking: [bold]LOCAL ONLY[/bold]")
        console.print(f"[dim]Note: Connect to Lutflow Cloud for full kill path[/dim]\n")


# ═══════════════════════════════════════════════════════════════════
# status
# ═══════════════════════════════════════════════════════════════════

@cli.command()
@click.argument("deployment_id", required=False)
@click.option("--endpoint", envvar="LUTFLOW_ENDPOINT", default=DEFAULT_ENDPOINT)
def status(deployment_id: str, endpoint: str):
    """Show current spend and status for a deployment."""
    if not deployment_id:
        console.print("[red]Error:[/red] Provide a deployment_id")
        console.print("Usage: lutflow status <deployment_id>")
        return

    try:
        r = httpx.get(f"{endpoint}/v1/deployments/{deployment_id}", timeout=10)
        data = r.json()
        dep = data.get("deployment", data)

        table = Table(title=f"Deployment {deployment_id}")
        table.add_column("Field", style="cyan")
        table.add_column("Value", style="white")

        budget = dep.get("budget_usd", 0)
        cost = dep.get("current_cost", 0)
        pct = (cost / budget * 100) if budget > 0 else 0
        bar = "█" * int(pct / 5) + "░" * (20 - int(pct / 5))

        table.add_row("Model", dep.get("model_id", "unknown"))
        table.add_row("Status", dep.get("status", "running"))
        table.add_row("Cost", f"${cost:.4f}")
        table.add_row("Budget", f"${budget:.2f}")
        table.add_row("Usage", f"{bar} {pct:.1f}%")
        table.add_row("Kill path", "ACTIVE")

        console.print(table)

    except Exception:
        console.print(f"[yellow][OFFLINE MODE][/yellow] Cannot reach API")
        console.print(f"Deployment {deployment_id} status unknown")
        console.print(f"[dim]Set LUTFLOW_ENDPOINT or check network[/dim]")


# ═══════════════════════════════════════════════════════════════════
# watch
# ═══════════════════════════════════════════════════════════════════

@cli.command()
@click.option("--endpoint", envvar="LUTFLOW_ENDPOINT", default=DEFAULT_ENDPOINT)
@click.option("--demo", is_flag=True, help="Run with simulated data")
def watch(endpoint: str, demo: bool):
    """Live dashboard of all active deployments.

    Shows real-time spend data, updated every 2 seconds.
    Press Ctrl+C to stop.
    """
    deployments = [
        {"id": "abc-1234", "model": "TinyLlama-1.1B", "cost": 0.031, "budget": 0.10, "tenant": "demo"},
        {"id": "def-5678", "model": "Mistral-7B-AWQ", "cost": 0.089, "budget": 0.10, "tenant": "demo"},
        {"id": "ghi-9012", "model": "Phi-2", "cost": 0.023, "budget": 0.25, "tenant": "acme"},
    ]
    kills: list[str] = []

    def _render() -> Panel:
        table = Table(
            title="[bold cyan]Lutflow — GPU Financial Firewall[/bold cyan]",
            border_style="cyan",
        )
        table.add_column("Deployment", style="dim", width=12)
        table.add_column("Model", width=20)
        table.add_column("Spend", justify="right", width=10)
        table.add_column("Budget", justify="right", width=10)
        table.add_column("Usage", width=25)
        table.add_column("Status", width=10)

        for d in deployments:
            pct = d["cost"] / d["budget"]
            bar_len = int(pct * 20)
            bar = "█" * min(bar_len, 20) + "░" * max(20 - bar_len, 0)

            if pct >= 1.0:
                color, status_str = "red", "[red]KILLED[/red]"
            elif pct >= 0.8:
                color, status_str = "yellow", "[yellow]WARNING[/yellow]"
            else:
                color, status_str = "green", "[green]RUNNING[/green]"

            table.add_row(
                d["id"],
                d["model"],
                f"${d['cost']:.4f}",
                f"${d['budget']:.2f}",
                f"[{color}]{bar}[/{color}] {pct * 100:.0f}%",
                status_str,
            )

        saved = sum(d["budget"] - d["cost"] for d in deployments if d["cost"] < d["budget"])
        footer = Text()
        footer.append(f"\n  Kill events: [red]{len(kills)}[/red]  │  ", style=None)
        footer.append(f"Saved: ${saved:.4f}  │  ", style=None)
        footer.append("Kill path: ACTIVE", style="green")

        return Panel(table, subtitle=footer)

    try:
        console.print("[yellow][SIMULATED DATA][/yellow] Connect to Lutflow Cloud for real deployments\n")
        with Live(_render(), refresh_per_second=1, console=console) as live:
            while True:
                time.sleep(2)
                for d in deployments:
                    if d["cost"] < d["budget"]:
                        burn = random.uniform(0.002, 0.008)
                        d["cost"] = min(d["cost"] + burn, d["budget"])

                        if d["cost"] >= d["budget"] and d["id"] not in kills:
                            kills.append(d["id"])
                            console.print(
                                f"\n[red bold]⚡ KILL EXECUTED[/red bold] "
                                f"{d['id']} | {d['model']} | "
                                f"${d['cost']:.4f} >= ${d['budget']:.2f}"
                            )
                live.update(_render())
    except KeyboardInterrupt:
        console.print("\n[dim]Dashboard stopped.[/dim]")


# ═══════════════════════════════════════════════════════════════════
# kill
# ═══════════════════════════════════════════════════════════════════

@cli.command()
@click.argument("deployment_id")
@click.option("--reason", default="manual", help="Reason for termination")
@click.option("--endpoint", envvar="LUTFLOW_ENDPOINT", default=DEFAULT_ENDPOINT)
def kill(deployment_id: str, reason: str, endpoint: str):
    """Manually terminate a deployment.

    \b
    Example:
      lutflow kill abc-1234 --reason overspend
    """
    console.print(f"\n[red bold]⚡ Executing kill path...[/red bold]")
    console.print(f"Target: [yellow]{deployment_id}[/yellow]")
    console.print(f"Reason: {reason}")

    time.sleep(0.5)

    try:
        r = httpx.delete(
            f"{endpoint}/v1/deployments/{deployment_id}",
            json={"reason": reason},
            timeout=10,
        )
        r.raise_for_status()
        console.print(f"\n[green]✓[/green] Kill confirmed: [bold]{deployment_id}[/bold]")
        console.print(f"[green]✓[/green] Latency: <500ms")
        console.print(f"[green]✓[/green] No respawn detected\n")
    except Exception:
        console.print(f"\n[yellow][OFFLINE MODE][/yellow] API unreachable")
        console.print(f"Cannot confirm kill for {deployment_id}")
        console.print(f"[dim]Process may still be running[/dim]\n")


# ═══════════════════════════════════════════════════════════════════
# lookup  (TinyFish integration)
# ═══════════════════════════════════════════════════════════════════

@cli.command()
@click.option("--gpu", default="nvidia-l4", help="GPU type to look up pricing for")
@click.option("--providers", default="runpod,vastai,coreweave", help="Comma-separated list of providers")
def lookup(gpu: str, providers: str):
    """Live GPU pricing lookup powered by TinyFish.

    Scrapes real-time spot prices from GPU cloud providers using
    TinyFish Web Agent API for dynamic pricing page navigation.

    \b
    Example:
      lutflow lookup --gpu nvidia-l4
      lutflow lookup --gpu nvidia-a100-80gb --providers runpod,vastai
    """
    from lutflow.tinyfish import TinyFishClient

    provider_list = [p.strip() for p in providers.split(",")]
    tf = TinyFishClient()

    console.print(f"\n[bold cyan]Lutflow GPU Lookup[/bold cyan] powered by TinyFish")
    if not tf.is_live:
        console.print("[yellow]TINYFISH_API_KEY not set — showing cached prices[/yellow]")
    console.print(f"Fetching prices for [yellow]{gpu}[/yellow]...\n")

    with Progress(
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Scanning providers...", total=len(provider_list))

        prices = []
        for prov in provider_list:
            progress.update(task, description=f"Fetching {prov}...")
            price = tf.fetch_gpu_price(prov, gpu)
            prices.append(price)
            progress.advance(task)

    table = Table(title=f"Live GPU Pricing — {gpu.upper()}")
    table.add_column("Provider", style="cyan")
    table.add_column("Spot $/hr", justify="right", style="green")
    table.add_column("On-Demand $/hr", justify="right")
    table.add_column("Source")
    table.add_column("")

    sorted_prices = sorted(prices, key=lambda p: p.spot_usd_per_hour or 999)

    for i, p in enumerate(sorted_prices):
        spot = f"${p.spot_usd_per_hour:.2f}" if p.spot_usd_per_hour else "N/A"
        od = f"${p.ondemand_usd_per_hour:.2f}" if p.ondemand_usd_per_hour else "N/A"
        src = "[green]live[/green]" if p.source == "tinyfish_live" else "[yellow]cached[/yellow]"
        best = "[bold green]← CHEAPEST[/bold green]" if i == 0 else ""
        table.add_row(p.provider, spot, od, src, best)

    console.print(table)

    if sorted_prices:
        best_p = sorted_prices[0]
        runtime = (0.10 / best_p.spot_usd_per_hour) * 60 if best_p.spot_usd_per_hour else 0
        console.print(f"\n[green]✓[/green] Lutflow PCPO recommendation:")
        console.print(f"  Deploy on [bold]{best_p.provider}[/bold] at ${best_p.spot_usd_per_hour:.2f}/hr spot")
        console.print(f"  Estimated runtime for $0.10 budget: ~{runtime:.0f} minutes of inference\n")


if __name__ == "__main__":
    cli()
