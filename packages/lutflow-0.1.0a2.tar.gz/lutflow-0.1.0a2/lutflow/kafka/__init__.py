"""Kafka producer for SpendEvents."""

__all__ = []
