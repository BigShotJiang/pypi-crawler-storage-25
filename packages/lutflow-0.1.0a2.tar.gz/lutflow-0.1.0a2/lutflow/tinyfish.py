"""
TinyFish integration for real-time GPU price discovery.

TinyFish navigates GPU cloud provider pricing pages in real time using
browser automation, returning structured pricing data without static APIs.

IMPORTANT: GPU pricing sites are complex and may take 1-3 minutes per provider.
For demos and quick lookups, use `quick=True` to use cached prices instantly.

Docs: https://docs.tinyfish.ai/
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import json
import logging
import os
import time

import httpx

logger = logging.getLogger("lutflow")

TINYFISH_RUN_URL = "https://agent.tinyfish.ai/v1/automation/run"

# Multi-GPU cached prices — updated 2026-03-30
# Source: spot prices observed in production
# These are used as fallback when TinyFish API times out or is unavailable
CACHED_GPU_PRICES: Dict[str, List[Dict[str, Any]]] = {
    "nvidia-l4": [
        {"provider": "vastai", "spot": 0.39, "ondemand": 0.65},
        {"provider": "runpod", "spot": 0.44, "ondemand": 0.74},
        {"provider": "lambdalabs", "spot": 0.50, "ondemand": 0.80},
        {"provider": "coreweave", "spot": 0.54, "ondemand": 0.81},
    ],
    "nvidia-a100-80gb": [
        {"provider": "vastai", "spot": 1.89, "ondemand": 3.20},
        {"provider": "runpod", "spot": 2.49, "ondemand": 3.99},
        {"provider": "lambdalabs", "spot": 2.49, "ondemand": 3.99},
        {"provider": "coreweave", "spot": 2.80, "ondemand": 4.10},
    ],
    "nvidia-h100-80gb": [
        {"provider": "vastai", "spot": 2.99, "ondemand": 5.50},
        {"provider": "lambdalabs", "spot": 3.50, "ondemand": 6.00},
        {"provider": "runpod", "spot": 3.99, "ondemand": 6.99},
        {"provider": "coreweave", "spot": 4.25, "ondemand": 7.50},
    ],
    "nvidia-t4": [
        {"provider": "vastai", "spot": 0.11, "ondemand": 0.35},
        {"provider": "runpod", "spot": 0.14, "ondemand": 0.40},
        {"provider": "coreweave", "spot": 0.18, "ondemand": 0.45},
    ],
}

# Legacy format for backward compatibility
CACHED_PRICES: Dict[str, Dict[str, float]] = {
    "runpod": {"spot": 0.44, "ondemand": 0.74},
    "vastai": {"spot": 0.39, "ondemand": 0.65},
    "coreweave": {"spot": 0.54, "ondemand": 0.81},
    "lambdalabs": {"spot": 0.50, "ondemand": 0.80},
}

GPU_PROVIDER_URLS: Dict[str, str] = {
    "runpod": "https://www.runpod.io/gpu-instance/pricing",
    "vastai": "https://vast.ai/pricing",
    "coreweave": "https://www.coreweave.com/gpu-cloud-pricing",
    "lambdalabs": "https://lambdalabs.com/service/gpu-cloud",
}

# GPU type aliases for convenience
GPU_TYPE_ALIASES: Dict[str, str] = {
    "l4": "nvidia-l4",
    "a100": "nvidia-a100-80gb",
    "a100-80gb": "nvidia-a100-80gb",
    "h100": "nvidia-h100-80gb",
    "h100-80gb": "nvidia-h100-80gb",
    "t4": "nvidia-t4",
}


@dataclass
class GPUPrice:
    """Price quote from a single provider."""

    provider: str
    gpu_type: str
    spot_usd_per_hour: float
    ondemand_usd_per_hour: Optional[float] = None
    source: str = "cached"
    fetched_at: float = field(default_factory=time.time)

    def as_dict(self) -> Dict[str, Any]:
        """Return a JSON-serializable dictionary."""
        return {
            "provider": self.provider,
            "gpu_type": self.gpu_type,
            "spot_usd_per_hour": self.spot_usd_per_hour,
            "ondemand_usd_per_hour": self.ondemand_usd_per_hour,
            "source": self.source,
            "fetched_at": self.fetched_at,
        }


@dataclass
class GPUPricingResult:
    """Aggregated pricing result across providers."""

    gpu_type: str
    prices: List[GPUPrice] = field(default_factory=list)

    @property
    def cheapest(self) -> Optional[GPUPrice]:
        """Return the cheapest provider by spot price."""
        valid = [p for p in self.prices if p.spot_usd_per_hour > 0]
        if not valid:
            return None
        return min(valid, key=lambda p: p.spot_usd_per_hour)

    @property
    def is_live(self) -> bool:
        """Check if any price was fetched live from TinyFish."""
        return any(p.source == "tinyfish_live" for p in self.prices)

    def budget_runtime_minutes(self, budget_usd: float) -> float:
        """Calculate runtime in minutes for given budget using cheapest provider."""
        best = self.cheapest
        if not best or best.spot_usd_per_hour <= 0:
            return 0.0
        return (budget_usd / best.spot_usd_per_hour) * 60

    def as_dict(self) -> Dict[str, Any]:
        """Return a JSON-serializable dictionary."""
        return {
            "gpu_type": self.gpu_type,
            "is_live": self.is_live,
            "prices": [p.as_dict() for p in self.prices],
            "cheapest": self.cheapest.as_dict() if self.cheapest else None,
        }


class TinyFishClient:
    """
    Client for TinyFish Web Agent API.

    Fetches real-time GPU spot prices by navigating provider
    websites that don't have structured pricing APIs.

    IMPORTANT: GPU pricing sites are complex JavaScript apps. Live fetching
    can take 1-3 minutes per provider. For demos and quick lookups, use
    `quick=True` to get cached prices instantly.

    Falls back to cached prices if:
    - TINYFISH_API_KEY is not set
    - API request times out (default 60s)
    - API returns invalid data

    Usage:
        # Quick mode (instant, uses cached prices)
        tf = TinyFishClient()
        result = tf.fetch_all_prices(gpu_type="nvidia-l4", quick=True)

        # Live mode (slow, navigates real websites)
        tf = TinyFishClient(timeout=180)  # 3 min timeout per provider
        result = tf.fetch_all_prices(gpu_type="nvidia-l4")

        print(f"Cheapest: {result.cheapest.provider}")
        print(f"${result.cheapest.spot_usd_per_hour:.2f}/hr")
        print(f"Source: {'live' if result.is_live else 'cached'}")
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        timeout: float = 60.0,
    ):
        """
        Initialize TinyFish client.

        Args:
            api_key: TinyFish API key. Falls back to TINYFISH_API_KEY env var.
            timeout: Timeout in seconds for live API calls. GPU pricing sites
                     can take 1-3 minutes, so increase this for live fetching.
                     Default is 60s which will likely fall back to cached.
        """
        self.api_key = api_key or os.getenv("TINYFISH_API_KEY")
        self.timeout = timeout

    @property
    def is_live(self) -> bool:
        """True if API key is set (live prices available)."""
        return self.api_key is not None and self.api_key != ""

    def fetch_gpu_price(
        self,
        provider: str,
        gpu_type: str = "nvidia-l4",
        quick: bool = False,
    ) -> GPUPrice:
        """
        Fetch a single provider's GPU price.

        Args:
            provider: Provider name (runpod, vastai, coreweave, lambdalabs)
            gpu_type: GPU type or alias (nvidia-l4, l4, a100, etc.)
            quick: If True, skip live API and use cached prices (instant)

        Returns:
            GPUPrice with spot and on-demand pricing
        """
        provider = provider.lower().replace(".", "").replace(" ", "")
        gpu_type = self._normalize_gpu_type(gpu_type)

        if quick:
            return self._fetch_cached(provider, gpu_type)

        if self.is_live:
            try:
                return self._fetch_live(provider, gpu_type)
            except Exception as exc:
                logger.debug("TinyFish live fetch failed for %s: %s", provider, exc)

        return self._fetch_cached(provider, gpu_type)

    def fetch_all_prices(
        self,
        gpu_type: str = "nvidia-l4",
        providers: Optional[List[str]] = None,
        quick: bool = False,
    ) -> GPUPricingResult:
        """
        Fetch prices from all (or specified) providers.

        Args:
            gpu_type: GPU type (nvidia-l4, nvidia-a100-80gb, etc.) or alias (l4, a100)
            providers: List of providers. Defaults to all known providers.
            quick: If True, skip live API and use cached prices (instant).
                   Recommended for demos and quick lookups.

        Returns:
            GPUPricingResult with prices sorted by cost.

        Example:
            # For demos (instant)
            result = tf.fetch_all_prices(gpu_type="l4", quick=True)

            # For production (may take several minutes)
            result = tf.fetch_all_prices(gpu_type="l4")
        """
        gpu_type = self._normalize_gpu_type(gpu_type)

        if providers is None:
            cached = CACHED_GPU_PRICES.get(gpu_type, [])
            if cached:
                providers = [p["provider"] for p in cached]
            else:
                providers = list(GPU_PROVIDER_URLS.keys())

        result = GPUPricingResult(gpu_type=gpu_type)

        for provider in providers:
            price = self.fetch_gpu_price(provider, gpu_type, quick=quick)
            result.prices.append(price)

        result.prices.sort(key=lambda p: p.spot_usd_per_hour)

        return result

    def _normalize_gpu_type(self, gpu_type: str) -> str:
        """Normalize GPU type string to canonical form."""
        gpu_type = gpu_type.lower().replace(" ", "-")
        return GPU_TYPE_ALIASES.get(gpu_type, gpu_type)

    def _fetch_live(self, provider: str, gpu_type: str) -> GPUPrice:
        """Fetch live price from TinyFish API."""
        url = GPU_PROVIDER_URLS.get(provider)
        if not url:
            raise ValueError(f"Unknown provider: {provider}")

        goal = (
            f"Find the current spot price per hour for {gpu_type.upper().replace('-', ' ')} GPU. "
            f"Return ONLY a JSON object with these exact fields: "
            f'{{"spot_usd_per_hour": <float>, "ondemand_usd_per_hour": <float>}}. '
            f"If spot is not available, use the cheapest available price."
        )

        logger.info("TinyFish: Fetching live price for %s from %s (timeout=%ds)",
                    gpu_type, provider, self.timeout)

        response = httpx.post(
            TINYFISH_RUN_URL,
            headers={
                "X-API-Key": self.api_key,
                "Content-Type": "application/json",
            },
            json={
                "url": url,
                "goal": goal,
                "browser_profile": "stealth",
            },
            timeout=self.timeout,
        )
        response.raise_for_status()
        data = response.json()

        if data.get("status") != "COMPLETED":
            logger.warning("TinyFish: Run status=%s for %s", data.get("status"), provider)
            raise ValueError(f"TinyFish run failed: {data.get('error')}")

        result = data.get("result") or {}

        if isinstance(result, str):
            try:
                result = json.loads(result)
            except Exception:
                result = {}

        spot = float(result.get("spot_usd_per_hour", 0) or 0)
        ondemand = float(result.get("ondemand_usd_per_hour", 0) or 0) or None

        if spot > 0:
            logger.info("TinyFish: Got live price for %s/%s: $%.2f/hr",
                        provider, gpu_type, spot)
            return GPUPrice(
                provider=provider,
                gpu_type=gpu_type,
                spot_usd_per_hour=spot,
                ondemand_usd_per_hour=ondemand,
                source="tinyfish_live",
            )

        logger.warning("TinyFish: No valid price in response for %s, using cached", provider)
        return self._fetch_cached(provider, gpu_type)

    def _fetch_cached(self, provider: str, gpu_type: str) -> GPUPrice:
        """Return cached price for a provider/GPU combination."""
        gpu_type = self._normalize_gpu_type(gpu_type)
        cached_list = CACHED_GPU_PRICES.get(gpu_type, [])

        for entry in cached_list:
            if entry["provider"].lower() == provider.lower():
                return GPUPrice(
                    provider=provider,
                    gpu_type=gpu_type,
                    spot_usd_per_hour=entry["spot"],
                    ondemand_usd_per_hour=entry.get("ondemand"),
                    source="cached",
                )

        legacy = CACHED_PRICES.get(provider, {"spot": 0.50, "ondemand": 0.80})

        return GPUPrice(
            provider=provider,
            gpu_type=gpu_type,
            spot_usd_per_hour=legacy["spot"],
            ondemand_usd_per_hour=legacy.get("ondemand"),
            source="cached",
        )
