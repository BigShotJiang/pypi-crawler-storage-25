"""
Lutflow wrapper for Google Gemini API.
Intercepts generate_content calls and tracks token costs.
"""

from typing import TYPE_CHECKING, Any, Optional
import logging

if TYPE_CHECKING:
    from lutflow.budget import BudgetGuard

logger = logging.getLogger("lutflow")

GEMINI_PRICING = {
    "gemini-2.5-flash": {
        "input": 0.000075,
        "output": 0.000300,
    },
    "gemini-2.5-pro": {
        "input": 0.001250,
        "output": 0.005000,
    },
    "gemini-2.0-flash": {
        "input": 0.000075,
        "output": 0.000300,
    },
    "gemini-1.5-flash": {
        "input": 0.000075,
        "output": 0.000300,
    },
    "gemini-1.5-pro": {
        "input": 0.001250,
        "output": 0.005000,
    },
    "gemini-1.0-pro": {
        "input": 0.000500,
        "output": 0.001500,
    },
}


def _normalize_gemini_model_name(name: str) -> str:
    """Normalize model name to pricing table key."""
    name = name.lower()
    if "gemini-2.5-flash" in name:
        return "gemini-2.5-flash"
    if "gemini-2.5-pro" in name:
        return "gemini-2.5-pro"
    if "gemini-2.0-flash" in name:
        return "gemini-2.0-flash"
    if "gemini-1.5-pro" in name:
        return "gemini-1.5-pro"
    if "gemini-1.5-flash" in name:
        return "gemini-1.5-flash"
    if "gemini-pro" in name or "gemini-1.0-pro" in name:
        return "gemini-1.0-pro"
    return "gemini-2.5-flash"


class GeminiWrapper:
    """
    Wraps google.generativeai.GenerativeModel to track costs.
    
    Usage:
        import google.generativeai as genai
        from lutflow import Client
        
        genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))
        client = Client(tenant_id="demo", budget_usd=1.00)
        model = client.wrap(genai.GenerativeModel("gemini-2.5-flash"))
        
        response = model.generate_content("Hello!")
        print(f"Cost: ${client.accumulated_cost_usd:.6f}")
    """
    
    def __init__(self, model: Any, budget_guard: "BudgetGuard"):
        self._model = model
        self._budget_guard = budget_guard
        self._model_name = self._extract_model_name(model)
    
    def _extract_model_name(self, model: Any) -> str:
        """Extract model name from GenerativeModel instance."""
        if hasattr(model, "model_name"):
            name = model.model_name
            if name and isinstance(name, str):
                return name.replace("models/", "")
        if hasattr(model, "_model_name"):
            name = model._model_name
            if name and isinstance(name, str):
                return name.replace("models/", "")
        return "gemini-2.5-flash"
    
    def generate_content(self, prompt: Any, **kwargs) -> Any:
        """
        Intercepts generate_content, tracks cost, enforces budget.
        Compatible with both string prompts and Content objects.
        """
        from lutflow.budget import BudgetExceededError
        
        if not self._budget_guard.check_budget():
            raise BudgetExceededError(
                budget_usd=self._budget_guard.budget_usd,
                spent_usd=self._budget_guard.accumulated_cost_usd,
                tenant_id=self._budget_guard.tenant_id,
                deployment_id=self._budget_guard.deployment_id,
            )
        
        response = self._model.generate_content(prompt, **kwargs)
        
        cost = self._calculate_cost(response)
        self._budget_guard.add_cost(cost)
        
        logger.debug(
            "LUTFLOW: Gemini usage model=%s cost=$%.6f total=$%.4f",
            self._model_name,
            cost,
            self._budget_guard.accumulated_cost_usd,
        )
        
        return response
    
    def _calculate_cost(self, response: Any) -> float:
        """Calculate cost from Gemini response usage_metadata."""
        try:
            usage = response.usage_metadata
            input_tokens = getattr(usage, "prompt_token_count", 0) or 0
            output_tokens = getattr(usage, "candidates_token_count", 0) or 0
            
            model_key = _normalize_gemini_model_name(self._model_name)
            pricing = GEMINI_PRICING.get(model_key, GEMINI_PRICING["gemini-2.5-flash"])
            
            input_cost = (input_tokens / 1000) * pricing["input"]
            output_cost = (output_tokens / 1000) * pricing["output"]
            
            return input_cost + output_cost
        except Exception:
            return 0.0
    
    def start_chat(self, **kwargs) -> "GeminiChatWrapper":
        """Wrap chat session for multi-turn conversations."""
        chat = self._model.start_chat(**kwargs)
        return GeminiChatWrapper(chat, self._budget_guard, self._model_name)
    
    def __getattr__(self, name: str) -> Any:
        """Proxy all other attributes to the underlying model."""
        return getattr(self._model, name)


class GeminiChatWrapper:
    """Wraps Gemini chat sessions for multi-turn cost tracking."""
    
    def __init__(self, chat: Any, budget_guard: "BudgetGuard", model_name: str):
        self._chat = chat
        self._budget_guard = budget_guard
        self._model_name = model_name
    
    def send_message(self, message: Any, **kwargs) -> Any:
        """Send a message and track cost."""
        from lutflow.budget import BudgetExceededError
        
        if not self._budget_guard.check_budget():
            raise BudgetExceededError(
                budget_usd=self._budget_guard.budget_usd,
                spent_usd=self._budget_guard.accumulated_cost_usd,
                tenant_id=self._budget_guard.tenant_id,
                deployment_id=self._budget_guard.deployment_id,
            )
        
        response = self._chat.send_message(message, **kwargs)
        
        cost = self._calculate_cost(response)
        self._budget_guard.add_cost(cost)
        
        logger.debug(
            "LUTFLOW: Gemini chat usage model=%s cost=$%.6f total=$%.4f",
            self._model_name,
            cost,
            self._budget_guard.accumulated_cost_usd,
        )
        
        return response
    
    def _calculate_cost(self, response: Any) -> float:
        """Calculate cost from Gemini response usage_metadata."""
        try:
            usage = response.usage_metadata
            input_tokens = getattr(usage, "prompt_token_count", 0) or 0
            output_tokens = getattr(usage, "candidates_token_count", 0) or 0
            
            model_key = _normalize_gemini_model_name(self._model_name)
            pricing = GEMINI_PRICING.get(model_key, GEMINI_PRICING["gemini-2.5-flash"])
            
            input_cost = (input_tokens / 1000) * pricing["input"]
            output_cost = (output_tokens / 1000) * pricing["output"]
            
            return input_cost + output_cost
        except Exception:
            return 0.0
    
    def __getattr__(self, name: str) -> Any:
        """Proxy all other attributes to the underlying chat."""
        return getattr(self._chat, name)


def wrap_gemini(model: Any, budget_guard: "BudgetGuard") -> GeminiWrapper:
    """
    Wrap a Gemini GenerativeModel for automatic cost tracking.
    
    Args:
        model: The GenerativeModel to wrap.
        budget_guard: The BudgetGuard for cost tracking.
        
    Returns:
        Wrapped Gemini model.
    """
    return GeminiWrapper(model, budget_guard)
