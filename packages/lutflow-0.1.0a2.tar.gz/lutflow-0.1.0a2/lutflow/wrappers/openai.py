"""OpenAI client wrapper for automatic cost tracking."""

from typing import TYPE_CHECKING, Any, Optional
import logging

if TYPE_CHECKING:
    from openai import OpenAI
    from lutflow.client import Client

logger = logging.getLogger("lutflow")


def count_tokens(text: str, model: str = "gpt-4") -> int:
    """
    Count tokens in text using tiktoken.
    
    Args:
        text: Text to count tokens for.
        model: Model name for encoding selection.
        
    Returns:
        Number of tokens.
    """
    try:
        import tiktoken
        
        # Map model to encoding
        if "gpt-4" in model or "gpt-3.5" in model:
            encoding = tiktoken.encoding_for_model(model)
        else:
            # Fallback to cl100k_base (GPT-4 encoding)
            encoding = tiktoken.get_encoding("cl100k_base")
        
        return len(encoding.encode(text))
    except Exception:
        # Rough estimate: ~4 chars per token
        return len(text) // 4


def count_messages_tokens(messages: list, model: str = "gpt-4") -> int:
    """
    Count tokens in a list of chat messages.
    
    Args:
        messages: List of message dicts with 'role' and 'content'.
        model: Model name for encoding selection.
        
    Returns:
        Total number of tokens.
    """
    total = 0
    for msg in messages:
        # Each message has overhead tokens
        total += 4  # <|im_start|>{role}\n ... <|im_end|>\n
        
        content = msg.get("content", "")
        if isinstance(content, str):
            total += count_tokens(content, model)
        elif isinstance(content, list):
            # Multi-modal content
            for part in content:
                if isinstance(part, dict) and part.get("type") == "text":
                    total += count_tokens(part.get("text", ""), model)
        
        # Role name tokens
        total += count_tokens(msg.get("role", ""), model)
    
    # Final assistant prompt
    total += 2
    
    return total


class WrappedChatCompletions:
    """Wrapped chat.completions interface with cost tracking."""
    
    def __init__(self, original: Any, lutflow_client: "Client"):
        self._original = original
        self._lutflow = lutflow_client
    
    def create(self, **kwargs: Any) -> Any:
        """
        Create a chat completion with automatic cost tracking.
        
        All arguments are passed through to the original OpenAI client.
        Cost is calculated from the response usage and reported to Lutflow.
        """
        # Check budget before making request
        if not self._lutflow.check_budget():
            from lutflow.budget import BudgetExceededError
            raise BudgetExceededError(
                budget_usd=self._lutflow.budget_usd,
                spent_usd=self._lutflow.accumulated_cost_usd,
                tenant_id=self._lutflow.tenant_id,
                deployment_id=self._lutflow.deployment_id,
            )
        
        model = kwargs.get("model", "gpt-4")
        
        # Estimate input tokens for pre-check
        messages = kwargs.get("messages", [])
        estimated_input = count_messages_tokens(messages, model)
        
        # Make the actual API call
        response = self._original.create(**kwargs)
        
        # Extract usage from response
        usage = getattr(response, "usage", None)
        if usage:
            input_tokens = getattr(usage, "prompt_tokens", estimated_input)
            output_tokens = getattr(usage, "completion_tokens", 0)
        else:
            input_tokens = estimated_input
            # Estimate output tokens from response
            output_tokens = self._estimate_output_tokens(response, model)
        
        # Report to Lutflow
        self._lutflow.report_tokens(
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            provider="openai",
        )
        
        return response
    
    async def acreate(self, **kwargs: Any) -> Any:
        """Async version of create."""
        # Check budget before making request
        if not self._lutflow.check_budget():
            from lutflow.budget import BudgetExceededError
            raise BudgetExceededError(
                budget_usd=self._lutflow.budget_usd,
                spent_usd=self._lutflow.accumulated_cost_usd,
                tenant_id=self._lutflow.tenant_id,
                deployment_id=self._lutflow.deployment_id,
            )
        
        model = kwargs.get("model", "gpt-4")
        messages = kwargs.get("messages", [])
        estimated_input = count_messages_tokens(messages, model)
        
        response = await self._original.acreate(**kwargs)
        
        usage = getattr(response, "usage", None)
        if usage:
            input_tokens = getattr(usage, "prompt_tokens", estimated_input)
            output_tokens = getattr(usage, "completion_tokens", 0)
        else:
            input_tokens = estimated_input
            output_tokens = self._estimate_output_tokens(response, model)
        
        self._lutflow.report_tokens(
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            provider="openai",
        )
        
        return response
    
    def _estimate_output_tokens(self, response: Any, model: str) -> int:
        """Estimate output tokens from response content."""
        try:
            choices = getattr(response, "choices", [])
            if choices:
                message = getattr(choices[0], "message", None)
                if message:
                    content = getattr(message, "content", "")
                    if content:
                        return count_tokens(content, model)
        except Exception:
            pass
        return 0
    
    def __getattr__(self, name: str) -> Any:
        """Pass through other attributes to original."""
        return getattr(self._original, name)


class WrappedChat:
    """Wrapped chat interface."""
    
    def __init__(self, original: Any, lutflow_client: "Client"):
        self._original = original
        self._lutflow = lutflow_client
        self.completions = WrappedChatCompletions(
            original.completions, lutflow_client
        )
    
    def __getattr__(self, name: str) -> Any:
        """Pass through other attributes to original."""
        return getattr(self._original, name)


class WrappedEmbeddings:
    """Wrapped embeddings interface with cost tracking."""
    
    def __init__(self, original: Any, lutflow_client: "Client"):
        self._original = original
        self._lutflow = lutflow_client
    
    def create(self, **kwargs: Any) -> Any:
        """Create embeddings with automatic cost tracking."""
        if not self._lutflow.check_budget():
            from lutflow.budget import BudgetExceededError
            raise BudgetExceededError(
                budget_usd=self._lutflow.budget_usd,
                spent_usd=self._lutflow.accumulated_cost_usd,
                tenant_id=self._lutflow.tenant_id,
                deployment_id=self._lutflow.deployment_id,
            )
        
        model = kwargs.get("model", "text-embedding-3-small")
        input_text = kwargs.get("input", "")
        
        # Count input tokens
        if isinstance(input_text, str):
            input_tokens = count_tokens(input_text, model)
        elif isinstance(input_text, list):
            input_tokens = sum(count_tokens(t, model) for t in input_text if isinstance(t, str))
        else:
            input_tokens = 0
        
        response = self._original.create(**kwargs)
        
        # Extract actual usage if available
        usage = getattr(response, "usage", None)
        if usage:
            input_tokens = getattr(usage, "total_tokens", input_tokens)
        
        # Embeddings have no output tokens
        self._lutflow.report_tokens(
            model=model,
            input_tokens=input_tokens,
            output_tokens=0,
            provider="openai",
        )
        
        return response
    
    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)


class WrappedOpenAI:
    """
    Wrapped OpenAI client with automatic cost tracking.
    
    This wrapper intercepts API calls and reports usage to Lutflow
    for budget tracking and enforcement.
    """
    
    def __init__(self, original: "OpenAI", lutflow_client: "Client"):
        self._original = original
        self._lutflow = lutflow_client
        self.chat = WrappedChat(original.chat, lutflow_client)
        self.embeddings = WrappedEmbeddings(original.embeddings, lutflow_client)
    
    def __getattr__(self, name: str) -> Any:
        """Pass through other attributes to original client."""
        return getattr(self._original, name)


def wrap_openai(client: "OpenAI", lutflow_client: "Client") -> WrappedOpenAI:
    """
    Wrap an OpenAI client for automatic cost tracking.
    
    Args:
        client: The OpenAI client to wrap.
        lutflow_client: The Lutflow client for cost tracking.
        
    Returns:
        Wrapped OpenAI client.
    """
    return WrappedOpenAI(client, lutflow_client)
