"""Anthropic client wrapper for automatic cost tracking."""

from typing import TYPE_CHECKING, Any
import logging

if TYPE_CHECKING:
    from anthropic import Anthropic
    from lutflow.client import Client

logger = logging.getLogger("lutflow")


def count_tokens_anthropic(text: str) -> int:
    """
    Count tokens for Anthropic models.
    
    Anthropic uses a similar tokenizer to GPT models.
    For accurate counting, use the anthropic.count_tokens() method if available.
    
    Args:
        text: Text to count tokens for.
        
    Returns:
        Estimated number of tokens.
    """
    try:
        import tiktoken
        encoding = tiktoken.get_encoding("cl100k_base")
        return len(encoding.encode(text))
    except Exception:
        # Rough estimate: ~4 chars per token
        return len(text) // 4


def count_messages_tokens_anthropic(messages: list, system: str = "") -> int:
    """
    Count tokens in Anthropic message format.
    
    Args:
        messages: List of message dicts with 'role' and 'content'.
        system: System prompt (separate in Anthropic API).
        
    Returns:
        Total number of tokens.
    """
    total = 0
    
    # System prompt
    if system:
        total += count_tokens_anthropic(system)
        total += 10  # Overhead for system formatting
    
    for msg in messages:
        # Message overhead
        total += 4
        
        content = msg.get("content", "")
        if isinstance(content, str):
            total += count_tokens_anthropic(content)
        elif isinstance(content, list):
            # Multi-modal content blocks
            for block in content:
                if isinstance(block, dict):
                    if block.get("type") == "text":
                        total += count_tokens_anthropic(block.get("text", ""))
                    elif block.get("type") == "image":
                        # Images have fixed token cost in Claude
                        total += 1000  # Approximate
        
        # Role tokens
        total += count_tokens_anthropic(msg.get("role", ""))
    
    return total


class WrappedMessages:
    """Wrapped messages interface with cost tracking."""
    
    def __init__(self, original: Any, lutflow_client: "Client"):
        self._original = original
        self._lutflow = lutflow_client
    
    def create(self, **kwargs: Any) -> Any:
        """
        Create a message with automatic cost tracking.
        
        All arguments are passed through to the original Anthropic client.
        Cost is calculated from the response usage and reported to Lutflow.
        """
        # Check budget before making request
        if not self._lutflow.check_budget():
            from lutflow.budget import BudgetExceededError
            raise BudgetExceededError(
                budget_usd=self._lutflow.budget_usd,
                spent_usd=self._lutflow.accumulated_cost_usd,
                tenant_id=self._lutflow.tenant_id,
                deployment_id=self._lutflow.deployment_id,
            )
        
        model = kwargs.get("model", "claude-3-sonnet-20240229")
        
        # Estimate input tokens
        messages = kwargs.get("messages", [])
        system = kwargs.get("system", "")
        estimated_input = count_messages_tokens_anthropic(messages, system)
        
        # Make the actual API call
        response = self._original.create(**kwargs)
        
        # Extract usage from response
        usage = getattr(response, "usage", None)
        if usage:
            input_tokens = getattr(usage, "input_tokens", estimated_input)
            output_tokens = getattr(usage, "output_tokens", 0)
        else:
            input_tokens = estimated_input
            output_tokens = self._estimate_output_tokens(response)
        
        # Normalize model name for pricing
        model_normalized = self._normalize_model(model)
        
        # Report to Lutflow
        self._lutflow.report_tokens(
            model=model_normalized,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            provider="anthropic",
        )
        
        return response
    
    async def acreate(self, **kwargs: Any) -> Any:
        """Async version of create."""
        if not self._lutflow.check_budget():
            from lutflow.budget import BudgetExceededError
            raise BudgetExceededError(
                budget_usd=self._lutflow.budget_usd,
                spent_usd=self._lutflow.accumulated_cost_usd,
                tenant_id=self._lutflow.tenant_id,
                deployment_id=self._lutflow.deployment_id,
            )
        
        model = kwargs.get("model", "claude-3-sonnet-20240229")
        messages = kwargs.get("messages", [])
        system = kwargs.get("system", "")
        estimated_input = count_messages_tokens_anthropic(messages, system)
        
        response = await self._original.acreate(**kwargs)
        
        usage = getattr(response, "usage", None)
        if usage:
            input_tokens = getattr(usage, "input_tokens", estimated_input)
            output_tokens = getattr(usage, "output_tokens", 0)
        else:
            input_tokens = estimated_input
            output_tokens = self._estimate_output_tokens(response)
        
        model_normalized = self._normalize_model(model)
        
        self._lutflow.report_tokens(
            model=model_normalized,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            provider="anthropic",
        )
        
        return response
    
    def stream(self, **kwargs: Any) -> Any:
        """
        Create a streaming message with cost tracking.
        
        Note: For streaming, we estimate tokens from the accumulated response.
        """
        if not self._lutflow.check_budget():
            from lutflow.budget import BudgetExceededError
            raise BudgetExceededError(
                budget_usd=self._lutflow.budget_usd,
                spent_usd=self._lutflow.accumulated_cost_usd,
                tenant_id=self._lutflow.tenant_id,
                deployment_id=self._lutflow.deployment_id,
            )
        
        model = kwargs.get("model", "claude-3-sonnet-20240229")
        messages = kwargs.get("messages", [])
        system = kwargs.get("system", "")
        input_tokens = count_messages_tokens_anthropic(messages, system)
        
        # Return a wrapped stream that tracks output
        return WrappedStream(
            self._original.stream(**kwargs),
            self._lutflow,
            model,
            input_tokens,
        )
    
    def _estimate_output_tokens(self, response: Any) -> int:
        """Estimate output tokens from response content."""
        try:
            content = getattr(response, "content", [])
            if content:
                text_blocks = [
                    block.text for block in content
                    if hasattr(block, "text")
                ]
                full_text = "".join(text_blocks)
                return count_tokens_anthropic(full_text)
        except Exception:
            pass
        return 0
    
    def _normalize_model(self, model: str) -> str:
        """Normalize model name for pricing lookup."""
        model_lower = model.lower()
        
        if "opus" in model_lower:
            return "claude-3-opus"
        if "haiku" in model_lower:
            return "claude-3-haiku"
        if "sonnet" in model_lower:
            if "3-5" in model_lower or "3.5" in model_lower:
                return "claude-3-5-sonnet"
            return "claude-3-sonnet"
        
        return model
    
    def __getattr__(self, name: str) -> Any:
        """Pass through other attributes to original."""
        return getattr(self._original, name)


class WrappedStream:
    """Wrapped streaming response that tracks token usage."""
    
    def __init__(
        self,
        stream: Any,
        lutflow_client: "Client",
        model: str,
        input_tokens: int,
    ):
        self._stream = stream
        self._lutflow = lutflow_client
        self._model = model
        self._input_tokens = input_tokens
        self._output_text = ""
        self._reported = False
    
    def __iter__(self):
        return self
    
    def __next__(self):
        try:
            event = next(self._stream)
            
            # Accumulate text from content blocks
            if hasattr(event, "delta"):
                delta = event.delta
                if hasattr(delta, "text"):
                    self._output_text += delta.text
            
            return event
            
        except StopIteration:
            # Stream ended, report final usage
            self._report_usage()
            raise
    
    def __enter__(self):
        if hasattr(self._stream, "__enter__"):
            self._stream.__enter__()
        return self
    
    def __exit__(self, *args):
        self._report_usage()
        if hasattr(self._stream, "__exit__"):
            return self._stream.__exit__(*args)
    
    def _report_usage(self):
        """Report accumulated usage to Lutflow."""
        if self._reported:
            return
        self._reported = True
        
        output_tokens = count_tokens_anthropic(self._output_text)
        
        # Normalize model name
        model_normalized = self._model.lower()
        if "opus" in model_normalized:
            model_normalized = "claude-3-opus"
        elif "haiku" in model_normalized:
            model_normalized = "claude-3-haiku"
        elif "sonnet" in model_normalized:
            if "3-5" in model_normalized or "3.5" in model_normalized:
                model_normalized = "claude-3-5-sonnet"
            else:
                model_normalized = "claude-3-sonnet"
        
        self._lutflow.report_tokens(
            model=model_normalized,
            input_tokens=self._input_tokens,
            output_tokens=output_tokens,
            provider="anthropic",
        )


class WrappedAnthropic:
    """
    Wrapped Anthropic client with automatic cost tracking.
    
    This wrapper intercepts API calls and reports usage to Lutflow
    for budget tracking and enforcement.
    """
    
    def __init__(self, original: "Anthropic", lutflow_client: "Client"):
        self._original = original
        self._lutflow = lutflow_client
        self.messages = WrappedMessages(original.messages, lutflow_client)
    
    def __getattr__(self, name: str) -> Any:
        """Pass through other attributes to original client."""
        return getattr(self._original, name)


def wrap_anthropic(client: "Anthropic", lutflow_client: "Client") -> WrappedAnthropic:
    """
    Wrap an Anthropic client for automatic cost tracking.
    
    Args:
        client: The Anthropic client to wrap.
        lutflow_client: The Lutflow client for cost tracking.
        
    Returns:
        Wrapped Anthropic client.
    """
    return WrappedAnthropic(client, lutflow_client)
