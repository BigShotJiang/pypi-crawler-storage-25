"""
Lutflow Client - Main entry point for the SDK.

The Client class provides budget tracking, cost calculation, and
automatic enforcement of spending limits for LLM API calls.
"""

from typing import Any, Callable, Optional, TypeVar, Union
import logging
import time
import uuid

from lutflow.budget import BudgetGuard, BudgetStrategy, BudgetExceededError
from lutflow.pricing import PricingCalculator, PricingMode

logger = logging.getLogger("lutflow")

T = TypeVar("T")


class Client:
    """
    Lutflow client for budget-aware LLM API usage.
    
    The client wraps LLM provider clients (OpenAI, Anthropic, etc.) and
    automatically tracks costs, enforcing budget limits based on the
    configured strategy.
    
    Example:
        >>> client = Client(
        ...     tenant_id="my-tenant",
        ...     budget_usd=10.00,
        ... )
        >>> wrapped = client.wrap(openai.OpenAI())
        >>> response = wrapped.chat.completions.create(...)
    
    Args:
        tenant_id: Your Lutflow tenant identifier.
        api_key: Your Lutflow API key (optional for local-only mode).
        budget_usd: Maximum budget in USD.
        deployment_id: Optional deployment identifier for tracking.
        pricing_mode: How to calculate costs (TOKEN_BASED or GPU_TIME).
        on_budget_exceeded: Strategy when budget is exceeded.
        on_exceeded_callback: Custom callback for CALLBACK strategy.
        price_per_1k_usd: Custom price per 1K tokens (overrides defaults).
        gpu_type: GPU type for GPU_TIME pricing mode.
        gpu_hourly_rate_usd: Custom GPU hourly rate (overrides defaults).
        gpu_count: Number of GPUs for GPU_TIME pricing.
        api_base_url: Lutflow API base URL (default: https://api.lutflow.dev).
        report_to_cloud: Whether to report usage to Lutflow Cloud.
    """
    
    def __init__(
        self,
        tenant_id: str,
        api_key: Optional[str] = None,
        budget_usd: float = 10.0,
        deployment_id: Optional[str] = None,
        pricing_mode: PricingMode = PricingMode.TOKEN_BASED,
        on_budget_exceeded: BudgetStrategy = BudgetStrategy.RAISE_ERROR,
        on_exceeded_callback: Optional[Callable[[float, float], None]] = None,
        price_per_1k_usd: Optional[float] = None,
        gpu_type: str = "nvidia-l4",
        gpu_hourly_rate_usd: Optional[float] = None,
        gpu_count: int = 1,
        api_base_url: str = "https://api.lutflow.dev",
        report_to_cloud: bool = True,
    ):
        self.tenant_id = tenant_id
        self.api_key = api_key
        self.deployment_id = deployment_id or str(uuid.uuid4())[:11]
        self.pricing_mode = pricing_mode
        self.gpu_type = gpu_type
        self.gpu_count = gpu_count
        self.api_base_url = api_base_url
        self.report_to_cloud = report_to_cloud and api_key is not None
        
        # Initialize budget guard
        self._budget_guard = BudgetGuard(
            budget_usd=budget_usd,
            tenant_id=tenant_id,
            deployment_id=self.deployment_id,
            strategy=on_budget_exceeded,
            on_exceeded_callback=on_exceeded_callback,
        )
        
        # Initialize pricing calculator
        self._pricing = PricingCalculator(
            mode=pricing_mode,
            custom_price_per_1k=price_per_1k_usd,
            custom_gpu_hourly_rate=gpu_hourly_rate_usd,
        )
        
        # GPU time tracking
        self._gpu_start_time: Optional[float] = None
        
        logger.info(
            "LUTFLOW: Client initialized tenant=%s deployment=%s budget=$%.2f mode=%s",
            tenant_id,
            self.deployment_id,
            budget_usd,
            pricing_mode.value,
        )
    
    @property
    def accumulated_cost_usd(self) -> float:
        """Total cost accumulated so far."""
        return self._budget_guard.accumulated_cost_usd
    
    @property
    def remaining_budget_usd(self) -> float:
        """Remaining budget available."""
        return self._budget_guard.remaining_budget_usd
    
    @property
    def budget_usd(self) -> float:
        """Total budget limit."""
        return self._budget_guard.budget_usd
    
    @property
    def budget_utilization_percent(self) -> float:
        """Percentage of budget used."""
        return self._budget_guard.budget_utilization_percent
    
    def check_budget(self) -> bool:
        """
        Check if budget is still available.
        
        Returns:
            True if budget is available, False if exceeded.
        """
        return self._budget_guard.check_budget()
    
    def add_cost(self, cost_usd: float) -> bool:
        """
        Manually add cost to the accumulated total.
        
        Args:
            cost_usd: Cost to add in USD.
            
        Returns:
            True if budget is still available, False if exceeded.
        """
        return self._budget_guard.add_cost(cost_usd)
    
    def report_tokens(
        self,
        model: str,
        input_tokens: int,
        output_tokens: int,
        provider: str = "openai",
    ) -> float:
        """
        Report token usage and calculate cost.
        
        Args:
            model: Model identifier (e.g., "gpt-4", "claude-3-sonnet").
            input_tokens: Number of input tokens.
            output_tokens: Number of output tokens.
            provider: Provider name for reporting.
            
        Returns:
            Cost in USD for this usage.
        """
        cost = self._pricing.calculate_token_cost(model, input_tokens, output_tokens)
        self._budget_guard.add_cost(cost)
        
        logger.debug(
            "LUTFLOW: Token usage model=%s in=%d out=%d cost=$%.6f total=$%.4f",
            model,
            input_tokens,
            output_tokens,
            cost,
            self.accumulated_cost_usd,
        )
        
        if self.report_to_cloud:
            self._report_spend_event(
                provider=provider,
                model=model,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                cost_usd=cost,
            )
        
        return cost
    
    def report_gpu_seconds(
        self,
        elapsed_seconds: float,
        gpu_count: Optional[int] = None,
    ) -> float:
        """
        Report GPU time usage and calculate cost.
        
        Args:
            elapsed_seconds: GPU time in seconds.
            gpu_count: Number of GPUs (defaults to client config).
            
        Returns:
            Cost in USD for this usage.
        """
        count = gpu_count or self.gpu_count
        cost = self._pricing.calculate_gpu_cost(
            self.gpu_type,
            elapsed_seconds,
            count,
        )
        self._budget_guard.add_cost(cost)
        
        logger.debug(
            "LUTFLOW: GPU usage type=%s seconds=%.2f gpus=%d cost=$%.6f total=$%.4f",
            self.gpu_type,
            elapsed_seconds,
            count,
            cost,
            self.accumulated_cost_usd,
        )
        
        return cost
    
    def start_gpu_timer(self) -> None:
        """Start tracking GPU time."""
        self._gpu_start_time = time.time()
    
    def stop_gpu_timer(self) -> float:
        """
        Stop tracking GPU time and report usage.
        
        Returns:
            Cost in USD for the elapsed GPU time.
        """
        if self._gpu_start_time is None:
            return 0.0
        
        elapsed = time.time() - self._gpu_start_time
        self._gpu_start_time = None
        return self.report_gpu_seconds(elapsed)
    
    def wrap(self, client: T) -> T:
        """
        Wrap an LLM provider client for automatic cost tracking.
        
        Args:
            client: The provider client to wrap (OpenAI, Anthropic, Gemini, etc.).
            
        Returns:
            Wrapped client with automatic cost tracking.
            
        Example:
            >>> wrapped = lutflow_client.wrap(openai.OpenAI())
            >>> response = wrapped.chat.completions.create(...)
        """
        client_type = type(client).__name__
        client_module = type(client).__module__
        
        if "OpenAI" in client_type:
            from lutflow.wrappers.openai import wrap_openai
            return wrap_openai(client, self)  # type: ignore
        
        if "Anthropic" in client_type:
            from lutflow.wrappers.anthropic import wrap_anthropic
            return wrap_anthropic(client, self)  # type: ignore
        
        if "google" in client_module.lower() or "GenerativeModel" in client_type:
            from lutflow.wrappers.gemini import wrap_gemini
            return wrap_gemini(client, self._budget_guard)  # type: ignore
        
        raise ValueError(
            f"Unsupported client type: {client_type}. "
            "Supported: OpenAI, Anthropic, GenerativeModel"
        )
    
    def _report_spend_event(
        self,
        provider: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
        cost_usd: float,
    ) -> None:
        """Report spend event to Lutflow Cloud (best effort)."""
        if not self.report_to_cloud:
            return
        
        try:
            import httpx
            
            event = {
                "tenant_id": self.tenant_id,
                "deployment_id": self.deployment_id,
                "provider": provider,
                "model": model,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "cost_usd": cost_usd,
                "timestamp_ms": int(time.time() * 1000),
            }
            
            httpx.post(
                f"{self.api_base_url}/api/v1/spend-events",
                json=event,
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=5.0,
            )
        except Exception as e:
            logger.debug("LUTFLOW: Failed to report spend event: %s", e)
