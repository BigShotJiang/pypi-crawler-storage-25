"""Pricing modes and cost calculation."""

from enum import Enum
from typing import Dict, Optional
from dataclasses import dataclass


class PricingMode(Enum):
    """Pricing mode for cost calculation."""
    
    TOKEN_BASED = "TOKEN_BASED"
    """Price based on input/output tokens (for API providers)."""
    
    GPU_TIME = "GPU_TIME"
    """Price based on GPU time (for self-hosted models)."""
    
    HYBRID = "HYBRID"
    """Combination of token and GPU time pricing."""


@dataclass
class ModelPricing:
    """Pricing information for a specific model."""
    
    model_id: str
    input_price_per_1k: float  # USD per 1K input tokens
    output_price_per_1k: float  # USD per 1K output tokens
    
    def calculate_cost(self, input_tokens: int, output_tokens: int) -> float:
        """Calculate cost for given token counts."""
        input_cost = (input_tokens / 1000) * self.input_price_per_1k
        output_cost = (output_tokens / 1000) * self.output_price_per_1k
        return input_cost + output_cost


@dataclass
class GPUPricing:
    """Pricing information for GPU time."""
    
    gpu_type: str
    hourly_rate_usd: float
    
    def calculate_cost(self, seconds: float, gpu_count: int = 1) -> float:
        """Calculate cost for given GPU time."""
        hours = seconds / 3600
        return hours * self.hourly_rate_usd * gpu_count


# Gemini pricing table (per 1K tokens) — March 2026
GEMINI_PRICING: Dict[str, Dict[str, float]] = {
    "gemini-2.5-flash": {
        "input": 0.000075,
        "output": 0.000300,
    },
    "gemini-2.5-pro": {
        "input": 0.001250,
        "output": 0.005000,
    },
    "gemini-2.0-flash": {
        "input": 0.000075,
        "output": 0.000300,
    },
    "gemini-1.5-flash": {
        "input": 0.000075,
        "output": 0.000300,
    },
    "gemini-1.5-pro": {
        "input": 0.001250,
        "output": 0.005000,
    },
    "gemini-1.0-pro": {
        "input": 0.000500,
        "output": 0.001500,
    },
}


# Default pricing for common models (as of March 2026)
DEFAULT_MODEL_PRICING: Dict[str, ModelPricing] = {
    # OpenAI
    "gpt-4": ModelPricing("gpt-4", 0.03, 0.06),
    "gpt-4-turbo": ModelPricing("gpt-4-turbo", 0.01, 0.03),
    "gpt-4o": ModelPricing("gpt-4o", 0.005, 0.015),
    "gpt-4o-mini": ModelPricing("gpt-4o-mini", 0.00015, 0.0006),
    "gpt-3.5-turbo": ModelPricing("gpt-3.5-turbo", 0.0005, 0.0015),
    "text-embedding-3-small": ModelPricing("text-embedding-3-small", 0.00002, 0.0),
    "text-embedding-3-large": ModelPricing("text-embedding-3-large", 0.00013, 0.0),
    
    # Anthropic
    "claude-3-opus": ModelPricing("claude-3-opus", 0.015, 0.075),
    "claude-3-sonnet": ModelPricing("claude-3-sonnet", 0.003, 0.015),
    "claude-3-haiku": ModelPricing("claude-3-haiku", 0.00025, 0.00125),
    "claude-3-5-sonnet": ModelPricing("claude-3-5-sonnet", 0.003, 0.015),
    
    # Google Gemini
    "gemini-2.5-flash": ModelPricing("gemini-2.5-flash", 0.000075, 0.0003),
    "gemini-2.5-pro": ModelPricing("gemini-2.5-pro", 0.00125, 0.005),
    "gemini-2.0-flash": ModelPricing("gemini-2.0-flash", 0.000075, 0.0003),
    "gemini-1.5-pro": ModelPricing("gemini-1.5-pro", 0.00125, 0.005),
    "gemini-1.5-flash": ModelPricing("gemini-1.5-flash", 0.000075, 0.0003),
    "gemini-1.0-pro": ModelPricing("gemini-1.0-pro", 0.0005, 0.0015),
}

# Default GPU pricing (as of March 2026)
DEFAULT_GPU_PRICING: Dict[str, GPUPricing] = {
    "nvidia-l4": GPUPricing("nvidia-l4", 0.80),
    "nvidia-t4": GPUPricing("nvidia-t4", 0.35),
    "nvidia-a100-40gb": GPUPricing("nvidia-a100-40gb", 3.67),
    "nvidia-a100-80gb": GPUPricing("nvidia-a100-80gb", 4.50),
    "nvidia-h100": GPUPricing("nvidia-h100", 8.00),
}


class PricingCalculator:
    """Calculate costs based on pricing mode and usage."""
    
    def __init__(
        self,
        mode: PricingMode = PricingMode.TOKEN_BASED,
        model_pricing: Optional[Dict[str, ModelPricing]] = None,
        gpu_pricing: Optional[Dict[str, GPUPricing]] = None,
        custom_price_per_1k: Optional[float] = None,
        custom_gpu_hourly_rate: Optional[float] = None,
    ):
        self.mode = mode
        self.model_pricing = model_pricing or DEFAULT_MODEL_PRICING
        self.gpu_pricing = gpu_pricing or DEFAULT_GPU_PRICING
        self.custom_price_per_1k = custom_price_per_1k
        self.custom_gpu_hourly_rate = custom_gpu_hourly_rate
    
    def calculate_token_cost(
        self,
        model: str,
        input_tokens: int,
        output_tokens: int,
    ) -> float:
        """Calculate cost for token-based usage."""
        if self.custom_price_per_1k is not None:
            total_tokens = input_tokens + output_tokens
            return (total_tokens / 1000) * self.custom_price_per_1k
        
        # Normalize model name
        model_key = self._normalize_model_name(model)
        
        if model_key in self.model_pricing:
            return self.model_pricing[model_key].calculate_cost(
                input_tokens, output_tokens
            )
        
        # Fallback: use GPT-4o-mini pricing as default
        return self.model_pricing["gpt-4o-mini"].calculate_cost(
            input_tokens, output_tokens
        )
    
    def calculate_gpu_cost(
        self,
        gpu_type: str,
        seconds: float,
        gpu_count: int = 1,
    ) -> float:
        """Calculate cost for GPU time usage."""
        if self.custom_gpu_hourly_rate is not None:
            hours = seconds / 3600
            return hours * self.custom_gpu_hourly_rate * gpu_count
        
        gpu_key = gpu_type.lower().replace("_", "-")
        
        if gpu_key in self.gpu_pricing:
            return self.gpu_pricing[gpu_key].calculate_cost(seconds, gpu_count)
        
        # Fallback: use L4 pricing
        return self.gpu_pricing["nvidia-l4"].calculate_cost(seconds, gpu_count)
    
    def _normalize_model_name(self, model: str) -> str:
        """Normalize model name for lookup."""
        model = model.lower()
        
        # Handle versioned model names
        if model.startswith("gpt-4-"):
            if "turbo" in model:
                return "gpt-4-turbo"
            if "o" in model and "mini" in model:
                return "gpt-4o-mini"
            if "o" in model:
                return "gpt-4o"
            return "gpt-4"
        
        if model.startswith("gpt-3.5"):
            return "gpt-3.5-turbo"
        
        if "claude-3" in model:
            if "opus" in model:
                return "claude-3-opus"
            if "haiku" in model:
                return "claude-3-haiku"
            if "sonnet" in model:
                if "3-5" in model or "3.5" in model:
                    return "claude-3-5-sonnet"
                return "claude-3-sonnet"
        
        if "gemini" in model:
            if "2.0" in model and "flash" in model:
                return "gemini-2.0-flash"
            if "pro" in model:
                if "1.0" in model:
                    return "gemini-1.0-pro"
                return "gemini-1.5-pro"
            if "flash" in model:
                return "gemini-1.5-flash"
        
        return model
