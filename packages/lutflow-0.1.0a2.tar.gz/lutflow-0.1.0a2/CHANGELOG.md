# Changelog

All notable changes to the Lutflow SDK will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0a2] - 2026-03-29

### Added

- Google Gemini wrapper (gemini-2.5-flash, gemini-2.5-pro, gemini-2.0-flash, gemini-1.5-flash, gemini-1.5-pro, gemini-1.0-pro)
- `pip install lutflow[gemini]` for Google AI support
- Gemini pricing table (input/output per 1K tokens)
- Multi-GPU cached prices in TinyFish (L4, A100-80GB, H100-80GB, T4)
- GPU type aliases in TinyFish ("l4" -> "nvidia-l4", "a100" -> "nvidia-a100-80gb")
- `as_dict()` method on GPUPrice and GPUPricingResult for JSON serialization
- `is_live` property on GPUPricingResult to check if any price is live
- `quick=True` parameter for TinyFish to use cached prices instantly (recommended for demos)
- Documentation: Confluent Kafka/Flink/Tableflow architecture
- 13 new tests for Gemini wrapper (including gemini-2.5 normalization)
- 18 new tests for enhanced TinyFish integration (including quick mode)

### Changed

- **BREAKING**: Default `on_budget_exceeded` strategy changed from `SELF_KILL` to `RAISE_ERROR`
  - This is safer for new users who may not expect their process to be killed
  - Use `on_budget_exceeded=BudgetStrategy.SELF_KILL` to restore previous behavior
- CLI commands now show `[OFFLINE MODE]` when Lutflow API is unreachable
  - Previously showed misleading success messages
- CLI `watch` command now shows `[SIMULATED DATA]` header
  - Clarifies that data is simulated until connected to Lutflow Cloud
- Removed `pydantic` from core dependencies (~30MB lighter install)
- README updated with Confluent AI Accelerator Cohort 3 and TinyFish Accelerator mentions
- TinyFish prices now sorted by spot price (cheapest first)
- TinyFish source field changed from "cached_fallback" to "cached" for clarity

### Fixed

- CLI `deploy` no longer prints fake "Kill path: ACTIVE" when API is unreachable
- CLI `status` no longer prints hardcoded fake data when API is unreachable
- CLI `kill` no longer prints fake "kubectl delete deployment executed" when API is unreachable

### Notes

- TinyFish live price fetching can take 1-3 minutes per provider due to complex JavaScript sites
- Use `quick=True` for instant cached prices (recommended for demos and CI/CD)
- Cached prices are updated weekly and are accurate for most use cases

## [0.1.0a1] - 2026-03-28

### Added

- Initial alpha release
- `Client` class for budget-aware LLM API usage
- OpenAI wrapper (`chat.completions`, `embeddings`)
- Anthropic wrapper (`messages`, `stream`)
- Four budget strategies: `RAISE_ERROR`, `WARN_ONLY`, `CALLBACK`, `SELF_KILL`
- Token-based pricing for 13 models (OpenAI, Anthropic, Google)
- GPU-time pricing for 5 GPU types
- TinyFish integration for real-time GPU price discovery
- CLI commands: `lookup`, `deploy`, `status`, `watch`, `kill`
- Local-only mode (no Lutflow Cloud required)
