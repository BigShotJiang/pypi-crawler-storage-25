    # Lutflow SDK — Fixes Required

    Prioritized list of fixes before the TinyFish hackathon video demo.

    ---

    ## P0: Must Fix Before Video

    These issues will break the demo or destroy credibility.

    ### P0-1: Default strategy is SELF_KILL

    **File:** `sdk-python/lutflow/client.py` line 61

    **Current:**
    ```python
    on_budget_exceeded: BudgetStrategy = BudgetStrategy.SELF_KILL,
    ```

    **Problem:** New users running the README quickstart with a low budget will have their process killed with no explanation.

    **Fix Option A (recommended):** Change default to RAISE_ERROR
    ```python
    on_budget_exceeded: BudgetStrategy = BudgetStrategy.RAISE_ERROR,
    ```

    **Fix Option B:** Update README to always specify strategy
    ```python
    client = Client(
        tenant_id="acme",
        budget_usd=10.00,
        on_budget_exceeded=BudgetStrategy.RAISE_ERROR,  # Add this line
    )
    ```

    ---

    ### P0-2: CLI fakes success on failure

    **File:** `sdk-python/lutflow/cli.py`

    **Problem:** When the Lutflow API is unreachable, CLI commands print fake success messages that mislead users.

    **Locations:**
    - `deploy` (lines 90-95): prints "Kill path: ACTIVE" 
    - `status` (lines 135-138): prints hardcoded "Cost: $0.047 / $0.10"
    - `kill` (lines 254-257): prints "kubectl delete deployment executed"

    **Fix:** Add clear `[OFFLINE MODE]` labels:

    ```python
    # In deploy command (line 90-95)
    except Exception:
        deploy_id = str(uuid.uuid4())[:8]
        console.print(f"[yellow][OFFLINE MODE][/yellow] API unreachable")
        console.print(f"[green]✓[/green] Local deployment ID: [bold]{deploy_id}[/bold]")
        console.print(f"[green]✓[/green] Budget tracking: [bold]LOCAL ONLY[/bold]")
        console.print(f"[dim]Note: Connect to Lutflow Cloud for full kill path[/dim]\n")

    # In status command (lines 135-138)
    except Exception:
        console.print(f"[yellow][OFFLINE MODE][/yellow] Cannot reach API")
        console.print(f"Deployment {deployment_id} status unknown")
        console.print(f"[dim]Set LUTFLOW_ENDPOINT or check network[/dim]")

    # In kill command (lines 254-257)
    except Exception:
        console.print(f"[yellow][OFFLINE MODE][/yellow] API unreachable")
        console.print(f"Cannot confirm kill for {deployment_id}")
        console.print(f"[dim]Process may still be running[/dim]\n")
    ```

    ---

    ### P0-3: README shows api_key in free tier example

    **File:** `sdk-python/README.md` lines 57-62

    **Current:**
    ```python
    client = Client(
        tenant_id="my-tenant",
        api_key="lut_xxx",
        budget_usd=10.00,
        on_budget_exceeded=BudgetStrategy.RAISE_ERROR,
    )
    ```

    **Problem:** If someone copies this with a fake api_key, every API call will attempt to POST to api.lutflow.dev (5s timeout per call).

    **Fix:** Remove api_key from free tier examples:
    ```python
    client = Client(
        tenant_id="my-tenant",
        budget_usd=10.00,
        on_budget_exceeded=BudgetStrategy.RAISE_ERROR,
    )
    ```

    Add a separate "Cloud Mode" section for api_key usage.

    ---

    ## P1: Fix Before Public Launch

    These issues degrade the experience but won't break the demo.

    ### P1-1: pydantic is unused core dependency

    **File:** `sdk-python/pyproject.toml` line 28

    **Current:**
    ```toml
    dependencies = [
        "httpx>=0.25.0",
        "pydantic>=2.0.0",  # <-- Never imported
        "tiktoken>=0.5.0",
        "click>=8.1.0",
        "rich>=13.0.0",
    ]
    ```

    **Problem:** Adds ~30MB of unnecessary install weight.

    **Fix:** Remove pydantic or move to optional dependencies:
    ```toml
    dependencies = [
        "httpx>=0.25.0",
        "tiktoken>=0.5.0",
        "click>=8.1.0",
        "rich>=13.0.0",
    ]

    [project.optional-dependencies]
    pydantic = ["pydantic>=2.0.0"]
    ```

    ---

    ### P1-2: CLI watch is 100% simulated

    **File:** `sdk-python/lutflow/cli.py` lines 154-158

    **Problem:** The `watch` command never connects to real data. Users may think it's showing real deployments.

    **Fix Option A:** Add header to output:
    ```python
    console.print("[yellow]SIMULATED DATA[/yellow] — Connect to Lutflow Cloud for real deployments")
    ```

    **Fix Option B:** Require `--demo` flag for simulation:
    ```python
    @cli.command()
    @click.option("--demo", is_flag=True, required=True, help="Run with simulated data")
    def watch(endpoint: str, demo: bool):
        if not demo:
            console.print("[red]Error:[/red] --demo flag required (real data not yet supported)")
            return
    ```

    ---

    ### P1-3: Gemini listed but not implemented

    **File:** `sdk-python/README.md` line 116-117

    **Current:**
    ```markdown
    ## Supported Providers

    - **OpenAI** — GPT-4o, GPT-4, GPT-3.5, embeddings
    - **Anthropic** — Claude 3.5, Claude 3 Opus/Sonnet/Haiku
    - **Google** — Gemini 1.5 Pro/Flash  <-- NOT IMPLEMENTED
    ```

    **Problem:** Gemini wrapper doesn't exist. `client.wrap(genai.Client())` will raise ValueError.

    **Fix Option A:** Remove Gemini from supported list
    **Fix Option B:** Add Gemini wrapper (more work)

    ---

    ## P2: Nice to Have

    ### P2-1: httpx is a core dependency

    **Problem:** Required even for free-tier local-only usage because `tinyfish.py` imports it at module level.

    **Fix:** Lazy import in tinyfish.py:
    ```python
    def _fetch_live(self, provider: str, gpu_type: str) -> GPUPrice:
        import httpx  # Lazy import
        ...
    ```

    ### P2-2: Add type hints to __all__

    **File:** `sdk-python/lutflow/__init__.py`

    **Current:**
    ```python
    __all__ = [
        "Client",
        "BudgetStrategy",
        ...
    ]
    ```

    **Fix:** Export type aliases for better IDE support.

    ---

    ## Implementation Order

    1. **P0-1** (5 min): Change default strategy in client.py
    2. **P0-3** (5 min): Update README examples
    3. **P0-2** (15 min): Add offline mode labels to CLI
    4. **P1-1** (5 min): Remove pydantic from core deps
    5. **P1-2** (10 min): Add simulated data header to watch
    6. **P1-3** (5 min): Remove Gemini from supported list

    **Total estimated time: ~45 minutes**

    ---

    ## Verification

    After applying fixes, run:

    ```bash
    # Clean install test
    rm -rf /tmp/lutflow-test-env
    python3 -m venv /tmp/lutflow-test-env
    source /tmp/lutflow-test-env/bin/activate
    pip install /path/to/sdk-python/

    # Verify default strategy
    python3 -c "from lutflow import Client; c = Client('t', 1.0); print(c._budget_guard.strategy)"
    # Should print: BudgetStrategy.RAISE_ERROR

    # Verify CLI offline labels
    lutflow deploy --model test --budget 0.10
    # Should show [OFFLINE MODE] label

    # Run demo script
    python3 DEMO_SCRIPT_FINAL.py
    ```
