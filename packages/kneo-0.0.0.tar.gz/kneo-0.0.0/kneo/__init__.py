"""kneo 0.0.0 — name placeholder.

This release reserves the `kneo` distribution name on PyPI. This
package does not provide any functionality. See
https://github.com/kneo-agent for the real project artifacts and the
component distributions (`kneo-serv`, …).
"""

__version__ = "0.0.0"
