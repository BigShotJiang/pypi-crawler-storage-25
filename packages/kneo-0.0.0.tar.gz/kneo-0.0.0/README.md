# kneo (name placeholder)

This 0.0.0 release reserves the `kneo` distribution name on PyPI.

This package does **not** provide any functionality. It is
intentionally empty.

The components of the Kneo Agent Platform ship as separate
distributions (`kneo-serv` for the service / control plane, and
related projects). See the
[GitHub account](https://github.com/kneo-agent) for source and release
artifacts.
