"""Tests for the Bedrock inference-profile probe used at `efterlev init`.

v0.1.0-v0.1.35 used a lexical sort over inference-profile IDs to pick the
"latest" Anthropic Opus. That sort gets `claude-opus-4-1-20250805` vs
`claude-opus-4-20250514` wrong because at position 14 the digit `2` of the
date `20250514` outranks the `1` of the version `4-1`. Result: a fresh
`efterlev init` against a Bedrock account with both Opus 4.0 and Opus 4.1
profiles enabled would pick Opus 4.0 (older) over Opus 4.1 (newer).

v0.1.36 replaces the lexical sort with a parsed (major, minor, date_int,
rev) tuple compare and adds a `us.*`-prefix filter (excluding eu/apac/global
inference profiles — the latter forfeits the US-region geographic guarantee
some FedRAMP boundary documentation depends on).

These tests:

- Pin the parser against every shape of Anthropic Bedrock ID currently in
  production (Opus 3, 4.0, 4.1, 4.7; Sonnet 3, 3.5, 3.7, 4, 4.6; Haiku 3,
  3.5, 4.5).
- Verify the ranking order on a synthetic candidate set so a future regex
  edit that breaks ordering fails the suite immediately.
- Verify the `us.*` filter excludes eu/apac/global candidates.
- Verify the family filter (opus / sonnet / haiku) returns the right family.
- A/B-verify the v0.1.36 fix against the v0.1.35 lexical-sort failure mode.
"""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

from efterlev.cli.main import (
    _parse_bedrock_anthropic_version,
    _probe_bedrock_default_model,
    _probe_bedrock_for_family,
)

# --- _parse_bedrock_anthropic_version ----------------------------------------


def test_parse_opus_4_7() -> None:
    assert _parse_bedrock_anthropic_version("us.anthropic.claude-opus-4-7-v1:0") == (4, 7, 0, 1)


def test_parse_opus_4_1_dated() -> None:
    assert _parse_bedrock_anthropic_version("us.anthropic.claude-opus-4-1-20250805-v1:0") == (
        4,
        1,
        20250805,
        1,
    )


def test_parse_opus_4_0_dated_no_minor() -> None:
    """The v0.1.0-v0.1.35 lexical-sort failure mode: Opus 4.0 with a date
    suffix. Pre-v0.1.36 regex would parse minor=20 (greedy from the date);
    v0.1.36 lookahead enforces minor must be followed by `-` or end-of-id,
    so the date is preserved and minor is correctly absent (= 0)."""
    assert _parse_bedrock_anthropic_version("us.anthropic.claude-opus-4-20250514-v1:0") == (
        4,
        0,
        20250514,
        1,
    )


def test_parse_legacy_opus_3() -> None:
    assert _parse_bedrock_anthropic_version("us.anthropic.claude-3-opus-20240229-v1:0") == (
        3,
        0,
        20240229,
        1,
    )


def test_parse_legacy_sonnet_3_5() -> None:
    assert _parse_bedrock_anthropic_version("us.anthropic.claude-3-5-sonnet-20241022-v2:0") == (
        3,
        5,
        20241022,
        2,
    )


def test_parse_legacy_sonnet_3_7() -> None:
    assert _parse_bedrock_anthropic_version("us.anthropic.claude-3-7-sonnet-20250219-v1:0") == (
        3,
        7,
        20250219,
        1,
    )


def test_parse_sonnet_4() -> None:
    assert _parse_bedrock_anthropic_version("us.anthropic.claude-sonnet-4-20250514-v1:0") == (
        4,
        0,
        20250514,
        1,
    )


def test_parse_sonnet_4_6() -> None:
    assert _parse_bedrock_anthropic_version("us.anthropic.claude-sonnet-4-6-v1:0") == (4, 6, 0, 1)


def test_parse_haiku_4_5() -> None:
    assert _parse_bedrock_anthropic_version("us.anthropic.claude-haiku-4-5-20251001-v1:0") == (
        4,
        5,
        20251001,
        1,
    )


def test_parse_legacy_haiku_3_5() -> None:
    assert _parse_bedrock_anthropic_version("us.anthropic.claude-3-5-haiku-20241022-v1:0") == (
        3,
        5,
        20241022,
        1,
    )


def test_parse_unknown_id_returns_none() -> None:
    assert _parse_bedrock_anthropic_version("us.anthropic.cohere-command-r-v1:0") is None
    assert _parse_bedrock_anthropic_version("us.amazon.titan-text-v1:0") is None
    assert _parse_bedrock_anthropic_version("garbage") is None


# --- ranking sanity ----------------------------------------------------------


def test_opus_4_7_ranks_above_opus_4_1() -> None:
    """Major.minor wins over date alone: Opus 4.7 (no date) beats Opus 4.1 (Aug 2025)."""
    assert _parse_bedrock_anthropic_version(
        "us.anthropic.claude-opus-4-7-v1:0"
    ) > _parse_bedrock_anthropic_version("us.anthropic.claude-opus-4-1-20250805-v1:0")


def test_opus_4_1_ranks_above_opus_4_0() -> None:
    """The v0.1.36 bug-fix lock: Opus 4.1 (Aug 2025) MUST beat Opus 4.0 (May
    2025) despite the lexical sort getting this wrong."""
    assert _parse_bedrock_anthropic_version(
        "us.anthropic.claude-opus-4-1-20250805-v1:0"
    ) > _parse_bedrock_anthropic_version("us.anthropic.claude-opus-4-20250514-v1:0")


def test_opus_4_anything_ranks_above_opus_3() -> None:
    """Even the oldest Opus 4 beats every Opus 3."""
    assert _parse_bedrock_anthropic_version(
        "us.anthropic.claude-opus-4-20250514-v1:0"
    ) > _parse_bedrock_anthropic_version("us.anthropic.claude-3-opus-20240229-v1:0")


def test_sonnet_4_6_ranks_above_sonnet_3_7() -> None:
    assert _parse_bedrock_anthropic_version(
        "us.anthropic.claude-sonnet-4-6-v1:0"
    ) > _parse_bedrock_anthropic_version("us.anthropic.claude-3-7-sonnet-20250219-v1:0")


def test_haiku_4_5_ranks_above_haiku_3_5() -> None:
    assert _parse_bedrock_anthropic_version(
        "us.anthropic.claude-haiku-4-5-20251001-v1:0"
    ) > _parse_bedrock_anthropic_version("us.anthropic.claude-3-5-haiku-20241022-v1:0")


# --- _probe_bedrock_for_family (with mocked boto) ----------------------------


def _mock_bedrock_response(profile_ids: list[str]) -> dict[str, Any]:
    """Build a fake `list_inference_profiles` response shaped like boto's."""
    return {
        "inferenceProfileSummaries": [
            {
                "inferenceProfileId": pid,
                "inferenceProfileName": pid,
                "models": [{"modelArn": f"arn:aws:bedrock:::foundation-model/anthropic.{pid}"}],
            }
            for pid in profile_ids
        ]
    }


def _patch_boto(profile_ids: list[str]) -> Any:
    """Build a context manager that patches boto3.Session().client to return
    a stub with `list_inference_profiles` returning the given profile IDs."""
    fake_client = MagicMock()
    fake_client.list_inference_profiles.return_value = _mock_bedrock_response(profile_ids)
    fake_session = MagicMock()
    fake_session.client.return_value = fake_client
    return patch("boto3.Session", return_value=fake_session)


def test_probe_picks_latest_opus_v0_1_36_failure_mode() -> None:
    """Lock the v0.1.36 bug-fix end-to-end: an account with both Opus 4.0
    and Opus 4.1 enabled must pick Opus 4.1, not Opus 4.0.

    Pre-v0.1.36 lexical sort picks `us.anthropic.claude-opus-4-20250514-v1:0`
    (Opus 4.0) because lexically `4-2…` outranks `4-1…`. v0.1.36 parses the
    version tuple correctly and picks Opus 4.1.
    """
    with _patch_boto(
        [
            "us.anthropic.claude-opus-4-20250514-v1:0",
            "us.anthropic.claude-opus-4-1-20250805-v1:0",
            "us.anthropic.claude-3-opus-20240229-v1:0",
        ]
    ):
        result = _probe_bedrock_for_family("us-east-1", "opus")
    assert result == "us.anthropic.claude-opus-4-1-20250805-v1:0"


def test_probe_picks_opus_4_7_when_available() -> None:
    """Account with Opus 4.7 (latest) + 4.1 + 4.0: must pick 4.7."""
    with _patch_boto(
        [
            "us.anthropic.claude-opus-4-1-20250805-v1:0",
            "us.anthropic.claude-opus-4-20250514-v1:0",
            "us.anthropic.claude-opus-4-7-v1:0",
        ]
    ):
        result = _probe_bedrock_for_family("us-east-1", "opus")
    assert result == "us.anthropic.claude-opus-4-7-v1:0"


def test_probe_excludes_eu_apac_global_profiles() -> None:
    """Even if eu/apac/global have a newer profile, US must win.

    FedRAMP boundary policy: data shouldn't egress outside the US
    authorization boundary; `global.*` forfeits the US-region geographic
    guarantee. We err toward conservatism and skip non-US profiles.
    """
    with _patch_boto(
        [
            "global.anthropic.claude-opus-4-7-v1:0",  # newer, but global
            "eu.anthropic.claude-opus-4-7-v1:0",  # newer, but EU
            "apac.anthropic.claude-opus-4-7-v1:0",  # newer, but APAC
            "us.anthropic.claude-opus-4-1-20250805-v1:0",  # older but US — wins
        ]
    ):
        result = _probe_bedrock_for_family("us-east-1", "opus")
    assert result == "us.anthropic.claude-opus-4-1-20250805-v1:0"


def test_probe_filters_by_family() -> None:
    """A `family="sonnet"` probe ignores Opus + Haiku profiles."""
    with _patch_boto(
        [
            "us.anthropic.claude-opus-4-7-v1:0",
            "us.anthropic.claude-sonnet-4-6-v1:0",
            "us.anthropic.claude-haiku-4-5-20251001-v1:0",
        ]
    ):
        sonnet = _probe_bedrock_for_family("us-east-1", "sonnet")
        haiku = _probe_bedrock_for_family("us-east-1", "haiku")
        opus = _probe_bedrock_for_family("us-east-1", "opus")
    assert sonnet == "us.anthropic.claude-sonnet-4-6-v1:0"
    assert haiku == "us.anthropic.claude-haiku-4-5-20251001-v1:0"
    assert opus == "us.anthropic.claude-opus-4-7-v1:0"


def test_probe_returns_none_on_no_us_anthropic_profile() -> None:
    """Account with only non-US or non-Anthropic profiles: probe returns None
    so caller falls back to the hardcoded default."""
    with _patch_boto(
        [
            "global.anthropic.claude-opus-4-7-v1:0",
            "us.amazon.titan-text-v1:0",
        ]
    ):
        result = _probe_bedrock_for_family("us-east-1", "opus")
    assert result is None


def test_probe_returns_none_on_invalid_family() -> None:
    """Unknown families return None without calling boto."""
    assert _probe_bedrock_for_family("us-east-1", "haiku-junior") is None
    assert _probe_bedrock_for_family("us-east-1", "") is None


def test_probe_returns_none_on_no_region() -> None:
    """Region required to construct the bedrock client."""
    assert _probe_bedrock_for_family(None, "opus") is None
    assert _probe_bedrock_for_family("", "opus") is None


def test_default_model_wrapper_returns_opus() -> None:
    """`_probe_bedrock_default_model` is a thin wrapper that asks for Opus."""
    with _patch_boto(
        [
            "us.anthropic.claude-opus-4-7-v1:0",
            "us.anthropic.claude-sonnet-4-6-v1:0",
        ]
    ):
        result = _probe_bedrock_default_model("us-east-1")
    assert result == "us.anthropic.claude-opus-4-7-v1:0"
