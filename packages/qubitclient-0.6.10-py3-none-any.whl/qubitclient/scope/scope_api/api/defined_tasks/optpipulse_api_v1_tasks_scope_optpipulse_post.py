# -*- coding: utf-8 -*-
# Copyright (c) 2026 yaqiang.sun.
# This source code is licensed under the license found in the LICENSE file
# in the root directory of this source tree.
#########################################################################
# Author: yaqiangsun
# Created Time: 2026/04/21 13:21:03
########################################################################

from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.body_optpipulse_api_v1_tasks_scope_optpipulse_post import BodyOptpipulseApiV1TasksScopeOptpipulsePost
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: BodyOptpipulseApiV1TasksScopeOptpipulsePost,
    type_: Union[Unset, str] = "optpipulse",
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["type"] = type_

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/tasks/scope/optpipulse",
        "params": params,
    }

    _kwargs["files"] = body.to_multipart()

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[Any, HTTPValidationError]]:
    if response.status_code == 200:
        response_200 = response.json()
        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[Any, HTTPValidationError]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: BodyOptpipulseApiV1TasksScopeOptpipulsePost,
    type_: Union[Unset, str] = "optpipulse",
) -> Response[Union[Any, HTTPValidationError]]:
    r"""Optpipulse

     Common peak detection for optimizing pi pulse

    Args:
        files: 上传的.npy文件列表
        type: 任务类型，默认为\"optpipulse\"

    Returns:
        dict: 包含检测结果的字典

    Args:
        type_ (Union[Unset, str]): 任务类型 Default: 'optpipulse'.
        body (BodyOptpipulseApiV1TasksScopeOptpipulsePost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, HTTPValidationError]]
    """

    kwargs = _get_kwargs(
        body=body,
        type_=type_,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    body: BodyOptpipulseApiV1TasksScopeOptpipulsePost,
    type_: Union[Unset, str] = "optpipulse",
) -> Optional[Union[Any, HTTPValidationError]]:
    r"""Optpipulse

     Common peak detection for optimizing pi pulse

    Args:
        files: 上传的.npy文件列表
        type: 任务类型，默认为\"optpipulse\"

    Returns:
        dict: 包含检测结果的字典

    Args:
        type_ (Union[Unset, str]): 任务类型 Default: 'optpipulse'.
        body (BodyOptpipulseApiV1TasksScopeOptpipulsePost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, HTTPValidationError]
    """

    return sync_detailed(
        client=client,
        body=body,
        type_=type_,
    ).parsed


async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: BodyOptpipulseApiV1TasksScopeOptpipulsePost,
    type_: Union[Unset, str] = "optpipulse",
) -> Response[Union[Any, HTTPValidationError]]:
    r"""Optpipulse

     Common peak detection for optimizing pi pulse

    Args:
        files: 上传的.npy文件列表
        type: 任务类型，默认为\"optpipulse\"

    Returns:
        dict: 包含检测结果的字典

    Args:
        type_ (Union[Unset, str]): 任务类型 Default: 'optpipulse'.
        body (BodyOptpipulseApiV1TasksScopeOptpipulsePost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, HTTPValidationError]]
    """

    kwargs = _get_kwargs(
        body=body,
        type_=type_,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    body: BodyOptpipulseApiV1TasksScopeOptpipulsePost,
    type_: Union[Unset, str] = "optpipulse",
) -> Optional[Union[Any, HTTPValidationError]]:
    r"""Optpipulse

     Common peak detection for optimizing pi pulse

    Args:
        files: 上传的.npy文件列表
        type: 任务类型，默认为\"optpipulse\"

    Returns:
        dict: 包含检测结果的字典

    Args:
        type_ (Union[Unset, str]): 任务类型 Default: 'optpipulse'.
        body (BodyOptpipulseApiV1TasksScopeOptpipulsePost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, HTTPValidationError]
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            type_=type_,
        )
    ).parsed
