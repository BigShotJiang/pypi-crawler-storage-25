# Service Calculator


## About

Provides a method for microservices to process data from the byneuron platform. Extends to the connector service.

## Concept

In general this method host the process in 3 steps: 
1/ input aggregated data from sources;
2/ performs calculations 
3/ outputs the data to targets.

Handling: 
A/ Scope: Multiple (async) or Single
B/ TimeRange: Actual (for cron based Task intervals), Recent (periodic updates), Historic (init/edit)

Datamodel:
Sources are linked to the entity using:
- itemRelation using metaValues
- deviceRelation using deviceDefinition
- ? solarDevice
Targets are features of the entity.


