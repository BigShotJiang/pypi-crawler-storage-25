<p align="center">
  <img src="https://onyxchat-ai.vercel.app/logo/Group%2071.png" alt="ONYX AI Logo" width="200">
</p>

# 🎙️ ONYX AI Voice Engine

STT (Whisper) and TTS (Edge-TTS) integrated engine for **ONYX** platform.

## 📦 Installation
```bash
pip install onyx-AI-voice
```
# الأصوات المتاحة
```txt
  final Map<String, String> _voiceOptions = {
    "أماني (سوريا)": "ar-SY-AmanyNeural",
    "ليث (سوريا)": "ar-SY-LaithNeural",
    "فاطمة (الإمارات)": "ar-AE-FatimaNeural",
    "حمدان (الإمارات)": "ar-AE-HamdanNeural",
    "علي (البحرين)": "ar-BH-AliNeural",
    "ليلى (البحرين)": "ar-BH-LailaNeural",
    "أمينة (الجزائر)": "ar-DZ-AminaNeural",
    "إسماعيل (الجزائر)": "ar-DZ-IsmaelNeural",
    "سلمى (مصر)": "ar-EG-SalmaNeural",
    "شاكر (مصر)": "ar-EG-ShakirNeural",
    "باسل (العراق)": "ar-IQ-BasselNeural",
    "رنا (العراق)": "ar-IQ-RanaNeural",
    "سناء (الأردن)": "ar-JO-SanaNeural",
    "تيم (الأردن)": "ar-JO-TaimNeural",
    "فهد (الكويت)": "ar-KW-FahedNeural",
    "نورة (الكويت)": "ar-KW-NouraNeural",
    "ليلى (لبنان)": "ar-LB-LaylaNeural",
    "رامي (لبنان)": "ar-LB-RamiNeural",
    "إيمان (ليبيا)": "ar-LY-ImanNeural",
    "عمر (ليبيا)": "ar-LY-OmarNeural",
    "جمال (المغرب)": "ar-MA-JamalNeural",
    "منى (المغرب)": "ar-MA-MounaNeural",
    "عبدالله (عُمان)": "ar-OM-AbdullahNeural",
    "عائشة (عُمان)": "ar-OM-AyshaNeural",
    "أمل (قطر)": "ar-QA-AmalNeural",
    "معاذ (قطر)": "ar-QA-MoazNeural",
    "حامد (السعودية)": "ar-SA-HamedNeural",
    "زارية (السعودية)": "ar-SA-ZariyahNeural",
    "هادي (تونس)": "ar-TN-HediNeural",
    "ريم (تونس)": "ar-TN-ReemNeural",
    "مريم (اليمن)": "ar-YE-MaryamNeural",
    "صالح (اليمن)": "ar-YE-SalehNeural",
    "Natasha (أستراليا)": "en-AU-NatashaNeural",
    "William (أستراليا)": "en-AU-WilliamMultilingualNeural",
    "Clara (كندا)": "en-CA-ClaraNeural",
    "Liam (كندا)": "en-CA-LiamNeural",
    "Libby (بريطانيا)": "en-GB-LibbyNeural",
    "Maisie (بريطانيا)": "en-GB-MaisieNeural",
    "Ryan (بريطانيا)": "en-GB-RyanNeural",
    "Sonia (بريطانيا)": "en-GB-SoniaNeural",
    "Thomas (بريطانيا)": "en-GB-ThomasNeural",
    "Sam (هونغ كونغ)": "en-HK-SamNeural",
    "Yan (هونغ كونغ)": "en-HK-YanNeural",
    "Connor (أيرلندا)": "en-IE-ConnorNeural",
    "Emily (أيرلندا)": "en-IE-EmilyNeural",
    "Neerja (الهند)": "en-IN-NeerjaNeural",
    "Neerja Expressive (الهند)": "en-IN-NeerjaExpressiveNeural",
    "Prabhat (الهند)": "en-IN-PrabhatNeural",
    "Asilia (كينيا)": "en-KE-AsiliaNeural",
    "Chilemba (كينيا)": "en-KE-ChilembaNeural",
    "Abeo (نيجيريا)": "en-NG-AbeoNeural",
    "Ezinne (نيجيريا)": "en-NG-EzinneNeural",
    "Mitchell (نيوزيلندا)": "en-NZ-MitchellNeural",
    "Molly (نيوزيلندا)": "en-NZ-MollyNeural",
    "James (الفلبين)": "en-PH-JamesNeural",
    "Rosa (الفلبين)": "en-PH-RosaNeural",
    "Luna (سنغافورة)": "en-SG-LunaNeural",
    "Wayne (سنغافورة)": "en-SG-WayneNeural",
    "Elimu (تنزانيا)": "en-TZ-ElimuNeural",
    "Imani (تنزانيا)": "en-TZ-ImaniNeural",
    "Ana (USA)": "en-US-AnaNeural",
    "Andrew (USA)": "en-US-AndrewNeural",
    "Andrew Multilingual (USA)": "en-US-AndrewMultilingualNeural",
    "Aria (USA)": "en-US-AriaNeural",
    "Ava (USA)": "en-US-AvaNeural",
    "Ava Multilingual (USA)": "en-US-AvaMultilingualNeural",
    "Brian (USA)": "en-US-BrianNeural",
    "Brian Multilingual (USA)": "en-US-BrianMultilingualNeural",
    "Christopher (USA)": "en-US-ChristopherNeural",
    "Cora (USA)": "en-US-CoraNeural",
    "Davis (USA)": "en-US-DavisNeural",
    "Elizabeth (USA)": "en-US-ElizabethNeural",
    "Emma (USA)": "en-US-EmmaNeural",
    "Eric (USA)": "en-US-EricNeural",
    "Guy (USA)": "en-US-GuyNeural",
    "Jacob (USA)": "en-US-JacobNeural",
    "Jane (USA)": "en-US-JaneNeural",
    "Jason (USA)": "en-US-JasonNeural",
    "Jenny (USA)": "en-US-JennyNeural",
    "Ken (USA)": "en-US-KenNeural",
    "Kevin (USA)": "en-US-KevinNeural",
    "Michelle (USA)": "en-US-MichelleNeural",
    "Monica (USA)": "en-US-MonicaNeural",
    "Nancy (USA)": "en-US-NancyNeural",
    "Roger (USA)": "en-US-RogerNeural",
    "Steffan (USA)": "en-US-SteffanNeural",
  };
```


## Option 2: requirements.txt
```txt
fastapi
uvicorn
python-multipart
openai-whisper
edge-tts
gTTS
ffmpeg-python
langdetect
onyx-AI-voice
```
---
💻 Usage
▶ Standard Script
```python
from ONYXAI_VOICE import OnyxAIVoice
import uvicorn
import os

# 1. تهيئة المحرك (بشكل تلقائي رح يحمل موديل Whisper Small)
# فيكي تغيري الموديل لـ "tiny" إذا بدك سرعة خارقة بس دقة أقل
engine = OnyxAIVoice(whisper_model="small")

# 2. الوصول لتطبيق FastAPI الموجود داخل الكلاس
app = engine.app

@app.get("/")
def home():
    return {
        "status": "ONYX Voice Cloner is Online",
        "owner": "ONYX",
       
    }

if __name__ == "__main__":

    port = int(os.environ.get("PORT", 7860))
    uvicorn.run(app, host="0.0.0.0", port=port
```
```
🛠 API Usage
Endpoint
```
## 1. STT: تحويل الكلام لنص 
```
```
POST /stt
```
```
## 2. TTS: تحويل النص لصوت

```
POST /tts
```

---
🔗 Links
Organization: [ONYX / RUI Company](https://github.com/RUI-com/)
Author: [Eng. Rawan Jassim](https://eng-rawan-abd-alrazak-next-js-website-main.vercel.app/)
---
© 2026 ONYX. All rights reserved.