from .engine import OnyxAIVoice

# هيك بصير الاستدعاء: from ONYXAI_VOICE import OnyxAIVoice
__all__ = ["OnyxAIVoice"]