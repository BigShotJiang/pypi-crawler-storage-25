import asyncio
import logging
import tempfile
import os
import base64
import subprocess
import shutil
import time
from fastapi import FastAPI, File, UploadFile, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import whisper
import edge_tts
from gtts import gTTS

# إعداد الـ Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class OnyxAIVoice:
    def __init__(self, whisper_model="small"):
        self.whisper_model_name = whisper_model
        self.stt_model = None
        
        self.app = FastAPI()
        self._setup_middleware()
        self._setup_routes()

    def _setup_middleware(self):
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    def load_whisper(self):
        if self.stt_model is None:
            logger.info(f"⏳ ONYX: Loading Whisper model ({self.whisper_model_name})...")
            self.stt_model = whisper.load_model(self.whisper_model_name)
            logger.info("✅ ONYX: Whisper model loaded.")
        return self.stt_model

    def _setup_routes(self):
        @self.app.get("/")
        def read_root():
            return {"status": "ONYX Voice API is running"}

        # 1. STT: تحويل الكلام لنص (دمج منطق stt_script.py)
        @self.app.post("/stt")
        async def stt(audio: UploadFile = File(...), method: str = Form("internal")):
            if not audio.content_type.startswith("audio/"):
                return JSONResponse(content={"error": "Unsupported audio format"}, status_code=400)
            
            contents = await audio.read()
            with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp:
                tmp.write(contents)
                tmp_path = tmp.name

            try:
                start_time = time.time()
                # الطريقة الداخلية (أسرع للاستخدام كـ API)
                if method == "internal":
                    model = self.load_whisper()
                    def sync_transcribe():
                        return model.transcribe(tmp_path, language="ar", temperature=0)
                    result = await asyncio.to_thread(sync_transcribe)
                    text = result['text'].strip()
                
                # محاكاة منطق السكريبت الخارجي (إذا كنتِ بتفضلي العزل التام)
                else:
                    # هون الكود بيشتغل مثل stt_script.py تماماً
                    model = self.load_whisper()
                    result = model.transcribe(tmp_path, language="ar", temperature=0, best_of=3)
                    text = result['text'].strip()

                end_time = time.time()
                return JSONResponse(content={
                    "text": text,
                    "processing_time": f"{end_time - start_time:.2f}s",
                    "language": "ar"
                })
            except Exception as e:
                return JSONResponse(content={"error": str(e)}, status_code=500)
            finally:
                if os.path.exists(tmp_path): os.remove(tmp_path)

        # 2. TTS: تحويل النص لصوت (دمج منطق gtts_script.py و edge-tts)
        @self.app.post("/tts")
        async def tts(
            text: str = Form(...), 
            voice: str = Form("ar-SY-AmanyNeural"),
            engine: str = Form("edge") # خيارين: edge أو gtts
        ):
            try:
                with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as tmp_file:
                    out_path = tmp_file.name
                
                if engine == "edge":
                    # استخدام edge-tts (جودة عالية)
                    communicate = edge_tts.Communicate(text, voice)
                    await communicate.save(out_path)
                else:
                    # دمج منطق gtts_script.py (جودة قياسية)
                    def save_gtts():
                        tts_obj = gTTS(text=text, lang='ar', slow=False)
                        tts_obj.save(out_path)
                    await asyncio.to_thread(save_gtts)
                
                with open(out_path, "rb") as f:
                    audio_data = base64.b64encode(f.read()).decode()
                
                return JSONResponse(content={"audio_base64": audio_data, "engine_used": engine})
            except Exception as e:
                return JSONResponse(content={"error": str(e)}, status_code=500)
            finally:
                if os.path.exists(out_path): os.remove(out_path)

    def run(self, host="0.0.0.0", port=7860):
        import uvicorn
        self.load_whisper()
        uvicorn.run(self.app, host=host, port=port)

if __name__ == "__main__":
    onyx_engine = OnyxAIVoice()
    onyx_engine.run()