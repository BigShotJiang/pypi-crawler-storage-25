


import argparse
from .analyzer import LEVEL_ORDER

LEVEL_CHOICES = LEVEL_ORDER

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Log Analyzer CLI",
        allow_abbrev=False
    )

    parser.add_argument("-f", "--file", required=False, help="Log file path")

    parser.add_argument(
        "--format",
        choices=["table", "csv", "json"],
        default="table",
        help="Output format",
    )
    parser.add_argument(
        "--output-format",
        choices=["auto", "json", "csv", "table"],
        default="auto",
        help="Output format (default: auto, inferred from file extension)",
    )
    
    parser.add_argument(
        "--output-json-file",
        help="(deprecated) use --output <file>.json instead",
    )
        
    parser.add_argument(
        "--level",
        action="append",
        type=str.upper,
        choices=["ERROR", "WARNING", "INFO", "DEBUG"],
        
        help="Filter by log level(s)"
    )

    parser.add_argument(
        "--levels",
        help="Comma-separated log levels, for example ERROR,INFO",
    )
    
    parser.add_argument(
        "--since",
        type=str,
        help="Filter logs from this date (inclusive), format YYYY-MM-DD",
    )

    parser.add_argument(
        "--until",
        type=str,
        help="Filter logs up to this date (inclusive), format YYYY-MM-DD",
    )

    parser.add_argument(
        "--today",
        action="store_true",
        help="Filter logs for today only"
    )

    parser.add_argument(
        "--last-days",
        type=int,
        help="Filter logs for last N days (inclusive)"
    )

    parser.add_argument(
        "--date-summary",
        action="store_true",
        help="Show counts grouped by date",
    )

    parser.add_argument(
        "--min-total",
        type=int,
        help="Minimum TOTAL count to include in date summary",
    )

    parser.add_argument(
        "--sort",
        choices=["level", "count", "percent", "alpha", "date", "total"],
        default="level",
        help="Sort output by level order, count, percent, or alphabetically",
    )
        
    parser.add_argument(
        "--top",
        type=int,
        help="Show top N results after sorting"
    )

    parser.add_argument(
        "--min-count",
        type=int,
        help="Show only levels with count >= N"
    )

    parser.add_argument(
        "--reverse",
        action="store_true",
        help="Reverse the final output order",
    )

    parser.add_argument(
        "--limit",
        type=int,        
        help="Limit number of date summary rows",          
    )

    parser.add_argument(
        "--output",
        help="Write output to a file and infer format from extension when possible",
    )

    parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite output file if it already exists",
    )

    parser.add_argument(
        "--append",
        action="store_true",
        help="Append output to file instead of overwriting",
    )

    parser.add_argument(
        "--output-dir",
        help="Write each date summary to a separate file in a directory"
    )

    parser.add_argument(
        "--no-total",
        action="store_true",
        help="Do not show total row in output",
    )

    parser.add_argument(
        "--summary-only",
        action="store_true",
        help="Show only the total summary",
    )
    
    parser.add_argument(
        "--no-header",
        action="store_true",
        help="Do not show header row in table or CSV output",
    )

    parser.add_argument(
        "--percent-decimals",
        type=int,
        default=1,
        help="Number of decimal places for percent output",
    )
    parser.add_argument(
        "--no-percent",
        dest="no_percent",
        action="store_true",
        help="Do not include percent column in output",
    )

    parser.add_argument(
        "--summary-json",
        action="store_true",
        help="Show only total summary in JSON format",
    )

    parser.add_argument(
        "--summary",
        action="store_true",
        help="Shortcut for --date-summary sorted by total"
    )

    parser.add_argument(
        "--full-json",
        action="store_true",
        help="Output full results in JSON format",
    )
    parser.add_argument(
        "--indent",
        type=int,
        help="Indent level for JSON output (e.g. 2 or 4)",
    )
    
    parser.add_argument(
        "--version",
        action="store_true",
        help="Show version and exit",
    )

    return parser
















