"""cc_cortex.agent — Agent management subsystem facade.

Re-exports from top-level modules for ``from cc_cortex.agent import …`` usage.
"""

from cc_cortex.agent.fork_context import (
    CacheSafeParams,
    FileStateCache,
    ForkDepthExceeded,
    SubagentContext,
    create_cache_safe_params,
    create_subagent_context,
    is_in_fork_child,
)
from cc_cortex.agent.iterative_retrieve import (
    CascadeConfig,
    CascadeStats,
    EvolutionScheduler,
    IterativeRetriever,
    L1Retriever,
    RetrievalResult,
)
from cc_cortex.agent.parallel_dispatch import (
    COORDINATOR_PROMPT_SNIPPET,
    DEFAULT_MAX_FORK_DEPTH,
    DEFAULT_MAX_PARALLEL,
    DispatchFeatures,
    DispatchPlan,
    DispatchRejected,
    ForkInForkRejected,
    ParallelDispatcher,
    ParallelLimitExceeded,
    SimpleFeatures,
    SpawnPath,
    SpawnRequest,
    TeammateCannotSpawnBackground,
    TeammateCannotSpawnTeammate,
)
from cc_cortex.agent.retrieve_pipeline import (
    CascadePipelineResult,
    ZIQCascadePipeline,
)
from cc_cortex.agent_artifact_guard import AgentArtifactGuard
from cc_cortex.agent_gate import (
    AgentGateGuard,
    check,
    gate_agent_cap,
    is_research_agent,
)
from cc_cortex.agent_supervisor import (
    AgentSupervisor,
    SupervisedTask,
    VerificationResult,
    verify_task,
)

__all__ = [
    "COORDINATOR_PROMPT_SNIPPET",
    "DEFAULT_MAX_FORK_DEPTH",
    "DEFAULT_MAX_PARALLEL",
    "AgentArtifactGuard",
    "AgentGateGuard",
    "AgentSupervisor",
    "CacheSafeParams",
    "CascadeConfig",
    "CascadePipelineResult",
    "CascadeStats",
    "DispatchFeatures",
    "DispatchPlan",
    "DispatchRejected",
    "EvolutionScheduler",
    "FileStateCache",
    "ForkDepthExceeded",
    "ForkInForkRejected",
    "IterativeRetriever",
    "L1Retriever",
    "ParallelDispatcher",
    "ParallelLimitExceeded",
    "RetrievalResult",
    "SimpleFeatures",
    "SpawnPath",
    "SpawnRequest",
    "SubagentContext",
    "SupervisedTask",
    "TeammateCannotSpawnBackground",
    "TeammateCannotSpawnTeammate",
    "VerificationResult",
    "ZIQCascadePipeline",
    "check",
    "create_cache_safe_params",
    "create_subagent_context",
    "gate_agent_cap",
    "is_in_fork_child",
    "is_research_agent",
    "verify_task",
]
