"""cc_cortex.agent.fork_context — Forked subagent context primitive.

@module agent.fork_context
@responsibility Define the data shape + invariants + state-isolation
    primitive for spawning fork subagents that share the parent's
    Anthropic prompt cache prefix. A fork whose CacheSafeParams are
    byte-identical to the parent's hits the server-side KV cache
    instead of forcing a cold rebuild.

    This module does NOT spawn subagents — that belongs to a future
    `agent.parallel_dispatcher`. This is the primitive layer: immutable
    cache-safe params + per-fork isolated FileStateCache + a
    SubagentContext packet that bundles the two.

@dependencies stdlib only (dataclasses, hashlib, json, typing)
@exports CacheSafeParams, FileStateCache, SubagentContext,
    create_cache_safe_params, create_subagent_context,
    is_in_fork_child, ForkDepthExceeded

Ported from Claude Code's TypeScript source:
  - utils/forkedAgent.ts   (CacheSafeParams, createSubagentContext)
  - utils/fileStateCache.ts (cloneFileStateCache semantics)

Design notes:
  - CacheSafeParams is frozen. Mutating any cache-affecting field
    invalidates the Anthropic prompt cache prefix, so we refuse to
    allow accidental mutation at the type level.
  - FileStateCache is a generic per-fork mutable dict. On fork, the
    parent's cache is SHALLOW-cloned so the fork can mutate its own
    copy without corrupting the parent's dedup state (and vice
    versa). Value-level deep-copy is the caller's problem — this
    mirrors the JS/TS behavior where LRU entries are carried by
    reference.
  - `fork_depth` and `parent_session_id` are metadata and are NOT
    part of the cache-affecting field comparison done by
    `CacheSafeParams.identical_to`. They can differ between parent
    and child without invalidating the KV prefix.
  - `ForkDepthExceeded` is defined here as the canonical exception
    type, but the guard that raises it lives in the dispatcher.
    Context creation is always safe; spawning is the guarded step.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any, Generic, Iterator, TypeVar

__all__ = [
    "CacheSafeParams",
    "FileStateCache",
    "SubagentContext",
    "create_cache_safe_params",
    "create_subagent_context",
    "is_in_fork_child",
    "ForkDepthExceeded",
]

T = TypeVar("T")


# --------------------------------------------------------------------------- #
# CacheSafeParams
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class CacheSafeParams:
    """The subset of a request that MUST be byte-identical between
    parent and fork for the Anthropic prompt cache prefix to hit.

    Any field changing invalidates the server-side KV prefix. These
    are the fields `forkedAgent.ts` L57-L80 carries forward to a
    fork's request.

    Fields:
        system_prompt: The full system prompt text, frozen at fork
            time. Drifting by even a whitespace character causes a
            cache miss.
        tool_defs_hash: sha256 of the canonicalized tool definitions
            list. Canonicalization is `json.dumps(..., sort_keys=True,
            ensure_ascii=False)` so mere key-order shuffling does NOT
            invalidate.
        tool_names: Tuple of tool names in declared order. This is
            for introspection/logging only and is NOT used by
            `identical_to` — ordering changes are tolerated because
            the server sees the canonicalized JSON blob.
        betas: Tuple of anthropic-beta header values in the order
            the parent used them. Order IS cache-affecting.
        effort_value: Extended-thinking effort tier string (e.g.
            "low" / "medium" / "high"). Part of the thinking config
            that the cache key covers.
        parent_session_id: Metadata pointer back to the parent
            session. NOT compared by `identical_to`.
        fork_depth: 0 for the parent, 1 for a first-level fork,
            N for N-levels-deep. NOT compared by `identical_to`.

    Immutability:
        The dataclass is frozen, so instances are hashable and can be
        used as dict keys or put in sets. Any mutation attempt raises
        `FrozenInstanceError`.
    """

    system_prompt: str
    tool_defs_hash: str
    tool_names: tuple[str, ...]
    betas: tuple[str, ...]
    effort_value: str
    parent_session_id: str
    fork_depth: int

    def identical_to(self, other: "CacheSafeParams") -> bool:
        """Return True iff all cache-affecting fields match.

        `fork_depth` and `parent_session_id` are metadata and are
        intentionally excluded — a first-level fork with the same
        prompt/tools/betas as its parent should still register as
        cache-identical.
        """
        return (
            self.system_prompt == other.system_prompt
            and self.tool_defs_hash == other.tool_defs_hash
            and self.betas == other.betas
            and self.effort_value == other.effort_value
        )


# --------------------------------------------------------------------------- #
# FileStateCache
# --------------------------------------------------------------------------- #


class FileStateCache(Generic[T]):
    """Generic per-fork isolated cache with a shallow `clone()`.

    Purpose:
        When a parent spawns a fork subagent, the parent's file-read
        dedup cache (typically ``path -> {mtime, content, hash}``)
        must be CLONED, not shared by reference. A fork writing into
        a shared cache would pollute the parent's dedup view (and
        vice versa), breaking both sides' read-before-edit
        consistency invariants.

    Clone semantics:
        `clone()` returns a new `FileStateCache` with a NEW backing
        dict that contains the same key/value pairs as self. The
        stored values themselves are NOT deep-copied — if T is a
        mutable structure and both the parent and the fork mutate
        the same value object, they will see each other's changes.

        Callers should either:
          1. Treat T as immutable (recommended — ported JS/TS
             `FileState` records are effectively read-only once
             written), or
          2. Deep-copy T values themselves before storing.

        This mirrors `cloneFileStateCache` in
        `utils/fileStateCache.ts`, which loads an LRU dump into a
        new LRU instance — the entry records are shared by
        reference, but the cache containers are separate.

    Ergonomics:
        Supports `len()`, `in`, and iteration over keys.
    """

    __slots__ = ("_store",)

    def __init__(self) -> None:
        self._store: dict[str, T] = {}

    def get(self, key: str) -> T | None:
        return self._store.get(key)

    def set(self, key: str, value: T) -> None:
        self._store[key] = value

    def delete(self, key: str) -> None:
        self._store.pop(key, None)

    def keys(self) -> list[str]:
        return list(self._store.keys())

    def __len__(self) -> int:
        return len(self._store)

    def __contains__(self, key: object) -> bool:
        return key in self._store

    def __iter__(self) -> Iterator[str]:
        return iter(self._store)

    def clone(self) -> "FileStateCache[T]":
        """Return a new `FileStateCache` with an independent dict.

        The new cache contains the same key/value pairs as self. The
        stored values are NOT deep-copied — see the class docstring
        for the sharing-semantics warning.
        """
        new_cache: FileStateCache[T] = FileStateCache()
        new_cache._store = dict(self._store)
        return new_cache


# --------------------------------------------------------------------------- #
# SubagentContext
# --------------------------------------------------------------------------- #


@dataclass
class SubagentContext:
    """The full packet a fork subagent receives from its parent.

    Combines the prefix-critical immutable `CacheSafeParams` with
    the mutable-but-isolated `FileStateCache` and a transcript
    pointer. This is the Python analogue of the object
    `createSubagentContext` in `utils/forkedAgent.ts` returns.

    Fields:
        params: Cache-safe request fingerprint (frozen).
        file_state: Per-fork isolated file-read dedup cache.
            Mutations here do not leak to the parent.
        parent_transcript_ref: Opaque pointer (path or ID) back to
            the parent's transcript record. Used by dispatchers to
            stitch sidechain logs together.
        metadata: Free-form per-fork metadata (labels, tracing ids,
            analytics counters). Intentionally mutable — callers
            append to it during the fork's run.
    """

    params: CacheSafeParams
    file_state: FileStateCache[Any]
    parent_transcript_ref: str
    metadata: dict[str, Any] = field(default_factory=dict)

    def clone_for_child(self, *, increment_depth: bool = True) -> "SubagentContext":
        """Produce a new context for spawning a grandchild fork.

        Re-clones the file state, copies metadata (shallow), and
        bumps `fork_depth` by 1 unless `increment_depth=False`. The
        depth flag exists for edge cases where a dispatcher wants
        to chain contexts without the child counting as a deeper
        level (e.g. ephemeral speculation passes).

        Returns a new `SubagentContext` — does not mutate self.
        """
        new_depth = self.params.fork_depth + (1 if increment_depth else 0)
        new_params = CacheSafeParams(
            system_prompt=self.params.system_prompt,
            tool_defs_hash=self.params.tool_defs_hash,
            tool_names=self.params.tool_names,
            betas=self.params.betas,
            effort_value=self.params.effort_value,
            parent_session_id=self.params.parent_session_id,
            fork_depth=new_depth,
        )
        return SubagentContext(
            params=new_params,
            file_state=self.file_state.clone(),
            parent_transcript_ref=self.parent_transcript_ref,
            metadata=dict(self.metadata),
        )


# --------------------------------------------------------------------------- #
# Factories
# --------------------------------------------------------------------------- #


def create_cache_safe_params(
    *,
    system_prompt: str,
    tool_defs: list[dict[str, Any]],
    betas: tuple[str, ...] = (),
    effort: str = "",
    parent_session_id: str = "",
    fork_depth: int = 0,
) -> CacheSafeParams:
    """Build a `CacheSafeParams` from raw request components.

    The tool-defs list is canonicalized via
    ``json.dumps(tool_defs, sort_keys=True, ensure_ascii=False)``
    before hashing so that purely cosmetic re-ordering of keys
    inside a tool def does NOT change `tool_defs_hash`. (The order
    of the tool defs in the OUTER list IS cache-affecting and is
    preserved — we do not sort the list itself.)

    Tool names are extracted in declared order, falling back to
    ``f"tool_{i}"`` when a def has no ``name`` field.
    """
    canonical = json.dumps(tool_defs, sort_keys=True, ensure_ascii=False)
    digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    names: list[str] = []
    for i, td in enumerate(tool_defs):
        raw_name = td.get("name") if isinstance(td, dict) else None
        if isinstance(raw_name, str) and raw_name:
            names.append(raw_name)
        else:
            names.append(f"tool_{i}")

    return CacheSafeParams(
        system_prompt=system_prompt,
        tool_defs_hash=digest,
        tool_names=tuple(names),
        betas=tuple(betas),
        effort_value=effort,
        parent_session_id=parent_session_id,
        fork_depth=fork_depth,
    )


def create_subagent_context(
    *,
    parent_params: CacheSafeParams,
    parent_file_state: FileStateCache[Any],
    parent_transcript_ref: str,
    metadata: dict[str, Any] | None = None,
) -> SubagentContext:
    """Factory that clones parent state into a fresh `SubagentContext`.

    This is the single public entry point callers should use to
    build the context packet for a fork subagent. It:

      1. Clones `parent_file_state` so the fork's writes do not
         leak back into the parent.
      2. Wraps the (immutable) `parent_params` as-is — the caller
         is responsible for bumping `fork_depth` if they want the
         new context to appear at a deeper level.
      3. Makes a NEW metadata dict rather than sharing the caller's
         reference, so metadata mutations don't leak either.

    It does NOT mutate `parent_params` or `parent_file_state`.
    """
    return SubagentContext(
        params=parent_params,
        file_state=parent_file_state.clone(),
        parent_transcript_ref=parent_transcript_ref,
        metadata=dict(metadata) if metadata is not None else {},
    )


# --------------------------------------------------------------------------- #
# Helpers & exceptions
# --------------------------------------------------------------------------- #


def is_in_fork_child(context: SubagentContext | None) -> bool:
    """Return True iff `context` is a fork child (depth > 0).

    Mirrors `isInForkChild` on the TypeScript side. A fork child
    that tries to fork further should be rejected by the
    dispatcher based on this check plus a `max_fork_depth`
    constant. This helper does not raise — it only reports.
    """
    return context is not None and context.params.fork_depth > 0


class ForkDepthExceeded(RuntimeError):
    """Raised when a spawn would exceed the configured max fork depth.

    Defined here as the canonical exception type so both the
    dispatcher and any test fixtures can import it from one place.
    This module itself NEVER raises it — context creation is always
    safe. The guard lives at the spawn call site.
    """
