"""cc_cortex.cache.microcompact — Prompt-cache microcompaction.

@module cache.microcompact
@responsibility Port of Claude Code's ``microCompact`` layer. Queues
    ``cache_edits`` deletions for tool results whose content is no longer
    worth keeping in the Anthropic server-side prompt cache, so the
    cached prefix hash stays stable (later turns still hit cache) while
    dead tool-result bytes are reclaimed in place. Two triggers:

    - **time-based**: gap since last assistant > cache TTL means the
      cache has (or is about to) expire. Old tool results are queued
      for deletion so the inevitable prefix rewrite carries less weight.
    - **token-budget**: soft/hard thresholds queue oldest tool results
      until projected token use drops under target.

    The module is **library code**. It has no HTTP client of its own —
    the caller supplies a :class:`CacheEditSink` protocol implementation
    that actually forwards the queued edits to the Anthropic API (or
    whichever endpoint the host uses). This keeps ``cc_cortex`` free of
    runtime network dependencies.

@dependencies cc_cortex.core.state_store
@exports COMPACTABLE_TOOLS, TIME_BASED_MC_CLEARED_MESSAGE, ToolCall,
    CacheEdit, CachedMCState, CacheEditSink, Microcompactor,
    compact_if_needed

Design notes (porting contract with ``microCompact.ts``):

- ``COMPACTABLE_TOOLS`` mirrors the TS source-of-truth set. Any tool
  not in this set is silently ignored on ``register_tool_call`` — the
  TS path walks message content and simply never records non-compactable
  tools. We preserve that behavior exactly.
- ``is_main_thread=False`` mirrors ``isMainThreadSource() == false`` in
  ``microCompact.ts:250``. Forked agents (session_memory,
  prompt_suggestion, …) must NOT register into cached MC state because
  the main thread's flush would try to delete phantom IDs from its own
  conversation. Registration is therefore a no-op under a fork.
- ``TIME_BASED_MC_CLEARED_MESSAGE`` is the sentinel the TS layer writes
  in place of cleared ``tool_result.content``. We expose it for parity so
  Python hosts that also manipulate message content locally stay in sync
  with the server-side cache.
- The sink-based ``flush`` / queue split mirrors the TS split between
  ``consumePendingCacheEdits`` (queue side) and the API layer that
  actually attaches ``cache_edits`` blocks to the next request.

v1 scope intentionally excludes pinned-edit replay (``pinCacheEdits`` /
``getPinnedCacheEdits``): those concern the API-request builder, not the
compaction decision engine. They can live in a separate
``cache.pinned_edits`` module when we need them.
"""

from __future__ import annotations

import logging
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Literal, Protocol, Sequence

logger = logging.getLogger("cc_cortex.cache.microcompact")

#: Union of action strings a :class:`CacheEdit` may carry. The original
#: ``delete_tool_result`` remains the only value produced by the tool-call
#: compaction path; the two ``*_section`` values are emitted by the
#: section-edit path (see :class:`SectionEdit`) and exist on the literal
#: alias so static callers can reference a single source of truth.
CacheEditAction = Literal[
    "delete_tool_result",
    "delete_section",
    "replace_section",
]

# ---------------------------------------------------------------------------
# Public constants
# ---------------------------------------------------------------------------

#: Tool names safe to compact. Token-heavy, result-heavy, idempotent-ish.
#: Mirror of ``COMPACTABLE_TOOLS`` in ``services/compact/microCompact.ts:41``.
COMPACTABLE_TOOLS: frozenset[str] = frozenset(
    {
        "Read",
        "Bash",
        "Grep",
        "Glob",
        "WebSearch",
        "WebFetch",
        "Edit",
        "Write",
    }
)

#: Sentinel text inserted where a tool result used to live. Mirrors
#: ``TIME_BASED_MC_CLEARED_MESSAGE`` in the TS source. Host code that edits
#: local message content (not just the server cache) must use this exact
#: string so the API-side and client-side views stay aligned.
TIME_BASED_MC_CLEARED_MESSAGE = (
    "[tool result cleared by microcompact — older than cache TTL]"
)


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class ToolCall:
    """Minimal tool-call record the compactor operates on.

    Attributes:
        call_id: Unique ID of the tool_use block (matches the
            ``tool_use_id`` on the paired ``tool_result``).
        tool_name: Name of the tool (must be in :data:`COMPACTABLE_TOOLS`
            to be tracked).
        input_hash: Stable hash of the tool input — used for
            dedup / equality checks by higher layers.
        result_tokens: Estimated token count of the tool_result content.
            Used by the token-budget trigger to decide how many results
            to queue for deletion.
        timestamp: Monotonic seconds when the result was recorded.
            Used by the time-based trigger.
        result_deleted: Set to True after a successful flush. Deleted
            entries are kept in the list so :meth:`Microcompactor.stats`
            can report the reclaim total, but they are skipped by both
            triggers.
    """

    call_id: str
    tool_name: str
    input_hash: str
    result_tokens: int
    timestamp: float
    result_deleted: bool = False


@dataclass
class CacheEdit:
    """A single edit queued for the Anthropic cache-editing API.

    Attributes:
        call_id: ``tool_use_id`` whose tool_result is to be deleted.
        action: Historically only ``"delete_tool_result"``. The type is
            widened to :data:`CacheEditAction` so the literal alias is a
            single source of truth across the module, but the tool-call
            compaction path still only ever emits ``"delete_tool_result"``.
            Section-edit actions travel on :class:`SectionEdit` instead
            — they are peers, not a subclass.
        reason: ``"time_based"`` | ``"token_budget"`` | ``"manual"`` —
            used for analytics / debugging, not routing.
    """

    call_id: str
    action: CacheEditAction = "delete_tool_result"
    reason: str = ""


@dataclass
class SectionEdit:
    """A prefix-preserving edit to an L3 cognitive_pool section.

    Section edits are **peers** of :class:`CacheEdit`, not a subclass.
    They target the body of a named section in the L3 cognitive pool so
    the Anthropic cache prefix (everything above the section) remains
    stable and the post-edit request still hits cache.

    Attributes:
        section_id: Stable 8-hex hash produced by cognitive_pool. Callers
            MUST supply this — microcompact does not compute section ids
            and does not reach into the pool module.
        action: ``"delete_section"`` removes the section range entirely;
            ``"replace_section"`` substitutes :attr:`new_body` in place.
        start_marker: Literal HTML-comment header tag that brackets the
            section on disk (see ``cognitive_pool.SECTION_HEADER_PREFIX``
            / ``SECTION_HEADER_SUFFIX``). Passed through to the sink
            untouched — the sink is responsible for matching it inside
            the cache body.
        end_marker: Literal HTML-comment footer tag (see
            ``cognitive_pool.SECTION_FOOTER``). Same contract as
            :attr:`start_marker` — microcompact treats it as opaque.
        new_body: Replacement body for ``replace_section``. Ignored for
            ``delete_section``. An empty string is valid for replace and
            will clear the section body while keeping the markers.
        reason: Free-form analytic tag (e.g. ``"drift"`` / ``"refresh"``
            / ``"manual"``). Not used for routing.
    """

    section_id: str
    action: Literal["delete_section", "replace_section"]
    start_marker: str
    end_marker: str
    new_body: str = ""
    reason: str = ""


@dataclass
class CachedMCState:
    """Per-session microcompact state.

    Persisted via :class:`~cc_cortex.core.state_store.StateStore` so that
    restarts within a session don't lose accrued tool-call history.
    """

    tool_calls: list[ToolCall] = field(default_factory=list)
    pending_edits: list[CacheEdit] = field(default_factory=list)
    last_assistant_ts: float = 0.0
    #: Forked-agent guard. Mirrors ``isMainThreadSource`` in the TS port.
    main_thread_only: bool = True
    #: Pending L3 section edits. Parallel queue to :attr:`pending_edits`
    #: — flushed separately via :meth:`Microcompactor.flush_sections`
    #: because section edits hit a sibling sink method, not ``submit``.
    #: Added in v1.16. Legacy state files without this key load with an
    #: empty list.
    pending_section_edits: list[SectionEdit] = field(default_factory=list)
    #: Running total of section edits that have been successfully
    #: flushed, for diagnostics via :meth:`Microcompactor.stats`.
    section_edits_applied_total: int = 0


class CacheEditSink(Protocol):
    """Caller-supplied bridge to the Anthropic cache-editing API.

    CCC deliberately does not depend on any HTTP client. Concrete sinks
    live in the consumer (a hook, a proxy, a test fake) and are injected
    into :class:`Microcompactor`. This keeps the library portable and
    zero-dep.

    The ``submit`` method handles :class:`CacheEdit` (tool-result
    deletions). Sinks that also want to handle L3 section edits should
    implement the optional ``submit_sections`` sibling method — the
    compactor detects it via ``hasattr`` and falls back to a logged
    no-op when absent, so legacy sinks keep working.

    Returns:
        Number of edits successfully applied. If the sink raises, the
        compactor treats the flush as a no-op and keeps the pending list
        intact for the next attempt.
    """

    def submit(self, edits: Sequence[CacheEdit]) -> int:
        ...

    def submit_sections(self, edits: Sequence[SectionEdit]) -> int:
        """Optional: apply L3 section edits in prefix-stable fashion.

        Sinks may omit this method. :meth:`Microcompactor.flush_sections`
        probes for it with ``hasattr`` before calling; absence triggers
        a logged no-op, not a crash.
        """
        ...


# ---------------------------------------------------------------------------
# Microcompactor
# ---------------------------------------------------------------------------


class Microcompactor:
    """Queue and flush cache-delete edits for compactable tool results.

    Args:
        cache_dir: Root directory for persistent state. When ``None``,
            save / load become no-ops (useful for transient sessions and
            tests).
        session_id: Logical session identifier. Scoped state files are
            written under ``{cache_dir}/microcompact/{session_id[:8]}.json``.
        time_based_ttl_s: Time-based trigger threshold. Slightly under
            the Anthropic 5-minute cache TTL by default so we queue
            before the server cache actually expires.
        token_budget_soft: Soft token budget. At or above this level
            :meth:`evaluate_token_budget_trigger` queues oldest results
            until projected use drops back under.
        token_budget_hard: Hard token budget. Triggers an aggressive
            pass (target = ``soft - (hard - soft)``) so the next turn
            has breathing room.
        is_main_thread: Forked-agent guard. ``False`` turns
            :meth:`register_tool_call` into a no-op.
        sink: Concrete :class:`CacheEditSink` used by :meth:`flush`. When
            ``None``, ``flush`` returns ``0`` without touching state.

    Raises:
        ValueError: If ``token_budget_hard < token_budget_soft``.
    """

    #: Namespace used under the state_store root.
    _NAMESPACE = "microcompact"

    def __init__(
        self,
        *,
        cache_dir: str | None = None,
        session_id: str | None = None,
        time_based_ttl_s: float = 270.0,
        token_budget_soft: int = 40_000,
        token_budget_hard: int = 60_000,
        is_main_thread: bool = True,
        sink: CacheEditSink | None = None,
    ) -> None:
        if token_budget_hard < token_budget_soft:
            msg = (
                f"token_budget_hard ({token_budget_hard}) must be >= "
                f"token_budget_soft ({token_budget_soft})"
            )
            raise ValueError(msg)

        self._cache_dir = cache_dir
        self._session_id = session_id or "unknown"
        self._ttl_s = float(time_based_ttl_s)
        self._soft = int(token_budget_soft)
        self._hard = int(token_budget_hard)
        self._sink = sink

        self._state = CachedMCState(main_thread_only=is_main_thread)
        self._store: Any = None  # lazy — stdlib-only outside state_store

    # ---- lifecycle ------------------------------------------------------

    def _ensure_store(self) -> Any:
        if self._cache_dir is None:
            return None
        if self._store is None:
            # Lazy import keeps the module free of cross-package init
            # cost for hosts that never persist.
            from cc_cortex.core.state_store import StateStore

            self._store = StateStore(self._cache_dir)
        return self._store

    def save(self) -> None:
        """Persist current state. No-op when ``cache_dir`` is ``None``."""
        store = self._ensure_store()
        if store is None:
            return
        payload = {
            "tool_calls": [asdict(tc) for tc in self._state.tool_calls],
            "pending_edits": [asdict(ce) for ce in self._state.pending_edits],
            "last_assistant_ts": self._state.last_assistant_ts,
            "main_thread_only": self._state.main_thread_only,
            "pending_section_edits": [
                asdict(se) for se in self._state.pending_section_edits
            ],
            "section_edits_applied_total": self._state.section_edits_applied_total,
        }
        try:
            store.write(self._NAMESPACE, self._session_id, payload)
        except Exception as exc:  # pragma: no cover - defensive
            logger.debug("microcompact save failed: %s", exc)

    def load(self) -> None:
        """Restore state written by a previous :meth:`save`.

        Silently ignores missing / corrupt state — the compactor starts
        empty in that case, which is the safe default.
        """
        store = self._ensure_store()
        if store is None:
            return
        data = store.read(self._NAMESPACE, self._session_id, default={})
        if not isinstance(data, dict):
            return

        raw_calls = data.get("tool_calls") or []
        raw_edits = data.get("pending_edits") or []
        raw_section_edits = data.get("pending_section_edits") or []
        try:
            self._state.tool_calls = [
                ToolCall(**tc) for tc in raw_calls if isinstance(tc, dict)
            ]
            self._state.pending_edits = [
                CacheEdit(**ce) for ce in raw_edits if isinstance(ce, dict)
            ]
            # Backwards compat: pre-1.16 state files have no
            # ``pending_section_edits`` key. ``data.get(...) or []`` on
            # the line above yields [] in that case, so this stays empty.
            self._state.pending_section_edits = [
                SectionEdit(**se)
                for se in raw_section_edits
                if isinstance(se, dict)
            ]
        except TypeError as exc:  # pragma: no cover - defensive
            logger.debug("microcompact load skipped malformed row: %s", exc)
            self._state.tool_calls = []
            self._state.pending_edits = []
            self._state.pending_section_edits = []

        last_ts = data.get("last_assistant_ts", 0.0)
        if isinstance(last_ts, (int, float)):
            self._state.last_assistant_ts = float(last_ts)

        # Backwards compat: default to 0 when the counter is absent.
        applied_total = data.get("section_edits_applied_total", 0)
        if isinstance(applied_total, int):
            self._state.section_edits_applied_total = applied_total

        main_only = data.get("main_thread_only", True)
        if isinstance(main_only, bool):
            self._state.main_thread_only = main_only

    # ---- registration ---------------------------------------------------

    def register_tool_call(
        self,
        *,
        call_id: str,
        tool_name: str,
        input_hash: str,
        result_tokens: int,
    ) -> None:
        """Record a completed tool call.

        Silently returns when:

        - ``is_main_thread=False`` (fork guard), or
        - ``tool_name`` is not in :data:`COMPACTABLE_TOOLS`, or
        - a record with the same ``call_id`` already exists (idempotent).
        """
        if not self._state.main_thread_only:
            return
        if tool_name not in COMPACTABLE_TOOLS:
            return
        if any(tc.call_id == call_id for tc in self._state.tool_calls):
            return

        self._state.tool_calls.append(
            ToolCall(
                call_id=call_id,
                tool_name=tool_name,
                input_hash=input_hash,
                result_tokens=int(result_tokens),
                timestamp=time.monotonic(),
            )
        )

    def note_assistant_message(self, *, timestamp: float) -> None:
        """Stamp the last-seen assistant message time.

        Used by :meth:`evaluate_time_based_trigger` to compute the gap
        since the last model turn. The value must be on the same clock
        as the ``now`` argument to the evaluator (monotonic in tests,
        typically ``time.monotonic()`` in production).
        """
        self._state.last_assistant_ts = float(timestamp)

    # ---- triggers -------------------------------------------------------

    def _already_queued(self, call_id: str) -> bool:
        for edit in self._state.pending_edits:
            if edit.call_id == call_id:
                return True
        return False

    def _queue_delete(self, call_id: str, *, reason: str) -> CacheEdit | None:
        if self._already_queued(call_id):
            return None
        edit = CacheEdit(
            call_id=call_id, action="delete_tool_result", reason=reason
        )
        self._state.pending_edits.append(edit)
        return edit

    def evaluate_time_based_trigger(
        self, *, now: float | None = None
    ) -> list[CacheEdit]:
        """Queue deletes for tool results older than ``time_based_ttl_s``.

        Idempotent: already-deleted or already-queued calls are skipped,
        so calling this each turn is safe.

        Args:
            now: Monotonic clock snapshot. ``None`` → ``time.monotonic()``.

        Returns:
            The list of **new** edits queued on this call (possibly empty).
        """
        clock = time.monotonic() if now is None else float(now)
        new_edits: list[CacheEdit] = []
        for tc in self._state.tool_calls:
            if tc.result_deleted:
                continue
            if tc.timestamp + self._ttl_s >= clock:
                continue
            edit = self._queue_delete(tc.call_id, reason="time_based")
            if edit is not None:
                new_edits.append(edit)
        return new_edits

    def evaluate_token_budget_trigger(
        self, *, current_tokens: int
    ) -> list[CacheEdit]:
        """Queue oldest tool results until projected tokens drop below target.

        Two paths:

        - **soft**: ``current_tokens > soft`` → target = ``soft``.
        - **hard**: ``current_tokens > hard`` → target =
          ``soft - (hard - soft)`` (more aggressive).

        Under the soft threshold this is a no-op.
        """
        current = int(current_tokens)
        if current <= self._soft:
            return []

        if current > self._hard:
            # Hard path is strictly more aggressive than soft — the
            # target drops by the soft/hard gap so the next turn has
            # real headroom rather than landing exactly on soft.
            target = self._soft - (self._hard - self._soft)
        else:
            target = self._soft

        # Sort live calls oldest-first. Already-queued or already-deleted
        # entries are skipped but count toward savings if their bytes are
        # still in the cache (deleted=False with pending edit).
        live = [
            tc
            for tc in self._state.tool_calls
            if not tc.result_deleted and not self._already_queued(tc.call_id)
        ]
        live.sort(key=lambda tc: tc.timestamp)

        new_edits: list[CacheEdit] = []
        projected = current
        for tc in live:
            if projected <= target:
                break
            edit = self._queue_delete(tc.call_id, reason="token_budget")
            if edit is not None:
                new_edits.append(edit)
                projected -= tc.result_tokens
        return new_edits

    # ---- flush ----------------------------------------------------------

    def flush(self) -> int:
        """Hand pending edits to the sink.

        Returns the number of edits successfully applied. When no sink
        is configured, or ``pending_edits`` is empty, returns ``0``. If
        the sink raises, the pending list is preserved so the next
        ``flush`` can retry — no tool calls are marked deleted.
        """
        if self._sink is None:
            return 0
        if not self._state.pending_edits:
            return 0

        edits = list(self._state.pending_edits)
        try:
            applied = int(self._sink.submit(edits))
        except Exception as exc:
            logger.debug("microcompact sink.submit raised: %s", exc)
            return 0

        if applied <= 0:
            return 0

        # Build a fast lookup so marking is O(n+m), not O(n*m).
        flushed_ids = {e.call_id for e in edits}
        for tc in self._state.tool_calls:
            if tc.call_id in flushed_ids:
                tc.result_deleted = True
        self._state.pending_edits.clear()
        return applied

    # ---- section edits (L3 cognitive_pool) -----------------------------

    def queue_section_replace(
        self,
        *,
        section_id: str,
        start_marker: str,
        end_marker: str,
        new_body: str,
        reason: str = "",
    ) -> SectionEdit:
        """Queue a ``replace_section`` edit for later flush.

        Multiple pending edits targeting the same ``section_id`` are
        allowed and applied in insertion order on flush — callers that
        need last-writer-wins semantics should dedupe upstream.

        Returns:
            The queued :class:`SectionEdit` (same object stored on the
            internal pending list — hosts may mutate ``reason`` but not
            the markers after queueing).
        """
        edit = SectionEdit(
            section_id=section_id,
            action="replace_section",
            start_marker=start_marker,
            end_marker=end_marker,
            new_body=new_body,
            reason=reason,
        )
        self._state.pending_section_edits.append(edit)
        return edit

    def queue_section_delete(
        self,
        *,
        section_id: str,
        start_marker: str,
        end_marker: str,
        reason: str = "",
    ) -> SectionEdit:
        """Queue a ``delete_section`` edit for later flush.

        ``new_body`` is forced to an empty string — delete semantics.
        Multiple pending edits for the same section id are allowed and
        applied in order on flush (same policy as
        :meth:`queue_section_replace`).
        """
        edit = SectionEdit(
            section_id=section_id,
            action="delete_section",
            start_marker=start_marker,
            end_marker=end_marker,
            new_body="",
            reason=reason,
        )
        self._state.pending_section_edits.append(edit)
        return edit

    def pending_section_edits(self) -> list[SectionEdit]:
        """Return a snapshot copy of the pending section-edit queue.

        The returned list is a new list instance — mutating it does not
        affect the compactor's internal state. The contained
        :class:`SectionEdit` instances are shared, so mutating their
        fields still reaches the queue (matches the host-introspection
        contract of :attr:`state`).
        """
        return list(self._state.pending_section_edits)

    def flush_sections(self) -> int:
        """Hand pending section edits to the sink.

        Uses :meth:`CacheEditSink.submit_sections` when the sink
        implements it (detected via ``hasattr``). Otherwise logs a
        warning and returns ``0`` — section edits stay queued and the
        host can swap in a capable sink and retry.

        Returns:
            Number of section edits successfully applied. The queue is
            cleared on positive return; preserved on zero / exception.
        """
        if self._sink is None:
            return 0
        if not self._state.pending_section_edits:
            return 0

        submit_sections = getattr(self._sink, "submit_sections", None)
        if submit_sections is None or not callable(submit_sections):
            logger.warning(
                "microcompact flush_sections: sink %r has no "
                "submit_sections method; %d section edits remain queued",
                type(self._sink).__name__,
                len(self._state.pending_section_edits),
            )
            return 0

        edits = list(self._state.pending_section_edits)
        try:
            applied = int(submit_sections(edits))
        except Exception as exc:
            logger.debug("microcompact sink.submit_sections raised: %s", exc)
            return 0

        if applied <= 0:
            return 0

        self._state.pending_section_edits.clear()
        self._state.section_edits_applied_total += applied
        return applied

    # ---- diagnostics ----------------------------------------------------

    def stats(self) -> dict[str, int]:
        """Return a point-in-time stats snapshot.

        Keys:

        - ``tool_calls_total`` — every registration ever observed (incl.
          deleted entries).
        - ``tool_calls_deleted`` — entries whose flush succeeded.
        - ``pending_edits`` — queued but not yet flushed.
        - ``tokens_reclaimed_estimate`` — sum of ``result_tokens`` over
          deleted entries.
        - ``section_edits_pending`` — queued L3 section edits not yet
          flushed (added v1.16).
        - ``section_edits_applied_total`` — running total of section
          edits that have been successfully flushed over this
          compactor's lifetime (added v1.16).
        """
        deleted = [tc for tc in self._state.tool_calls if tc.result_deleted]
        return {
            "tool_calls_total": len(self._state.tool_calls),
            "tool_calls_deleted": len(deleted),
            "pending_edits": len(self._state.pending_edits),
            "tokens_reclaimed_estimate": sum(tc.result_tokens for tc in deleted),
            "section_edits_pending": len(self._state.pending_section_edits),
            "section_edits_applied_total": self._state.section_edits_applied_total,
        }

    # ---- test / host introspection -------------------------------------

    @property
    def state(self) -> CachedMCState:
        """Expose the underlying state for hosts that need to inspect it.

        Intended primarily for tests and diagnostic hooks. Mutating the
        returned object bypasses all guards.
        """
        return self._state


# ---------------------------------------------------------------------------
# Module-level convenience
# ---------------------------------------------------------------------------


def compact_if_needed(
    compactor: Microcompactor,
    *,
    now: float | None = None,
    current_tokens: int | None = None,
) -> int:
    """Run both triggers and flush.

    Args:
        compactor: Configured :class:`Microcompactor`.
        now: Passthrough to :meth:`Microcompactor.evaluate_time_based_trigger`.
        current_tokens: When provided, also runs the token-budget
            trigger. ``None`` skips the token path.

    Returns:
        Number of edits applied by the flush. Note: time/token triggers
        may queue new edits that remain pending if no sink is attached.
    """
    compactor.evaluate_time_based_trigger(now=now)
    if current_tokens is not None:
        compactor.evaluate_token_budget_trigger(current_tokens=current_tokens)
    return compactor.flush()


def compact_all(compactor: Microcompactor) -> tuple[int, int]:
    """Flush both tool-result and L3 section-edit queues.

    Thin convenience wrapper — does not run the time/token triggers;
    call :func:`compact_if_needed` separately if those are needed. The
    two flush methods are independent: a failure (or no-op) in one does
    not prevent the other from running.

    Args:
        compactor: Configured :class:`Microcompactor`.

    Returns:
        ``(tool_edits_applied, section_edits_applied)`` — both are zero
        when their respective queues were empty or the sink refused.
    """
    tool_applied = compactor.flush()
    section_applied = compactor.flush_sections()
    return tool_applied, section_applied
