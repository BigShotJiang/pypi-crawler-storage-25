"""News Watcher engine — periodic team-reviewed topic monitoring.

This is the **engine** for the news-watcher skill family. It runs on the
persistent cron scheduler (one job per registered KB+topic pair) and
drives the deterministic search → scrape → date-gate → relevance-review
→ persist pipeline. The LLM-side decision (per-source relevance
scoring + integrity flags) is delegated to the news-curator agent,
which in turn delegates to fact-checker — a non-negotiable two-agent
team gate that prevents a hallucinating curator from approving slop on
its own.

**Strategy lives in the skill, not here** (Rule 12). Every threshold,
domain blocklist, cadence, and recency knob comes from
``defaults/skills/core/news-watcher/config/news.yaml`` and per-KB
SCHEMA.md `news_watch:` blocks. This module owns engine plumbing:
loading config, calling tools through the contract gate, extracting
publish dates, applying URL cooldowns, persisting keepers.

**The engine never crashes the cron loop.** Every tick wraps the work
in try/except, records failures via ActivityLogger, and returns a
structured result dict. A broken LLM provider, network outage, or
malformed YAML must not silently kill periodic news intake — the
heartbeat retries on the next cycle.

Architecture: see CLAUDE.md Rule 12 + the news-watcher SKILL.md for
the team-cooperation contract this engine implements.
"""
from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import re
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse

if TYPE_CHECKING:
    from agntspace.activity.logger import ActivityLogger
    from agntspace.agent.agent import Agent
    from agntspace.automation.cron import CronScheduler
    from agntspace.skills.loader import SkillLoader
    from agntspace.vault.reader import VaultReader

log = logging.getLogger(__name__)


# ── Hardcoded fallbacks (used only when YAML is missing/malformed) ─────────
# All of these are mirrored in news.yaml — these are the safety net that
# keeps a fresh install / corrupt YAML from crashing the engine.

_FALLBACK_GLOBAL: dict[str, Any] = {  # arch:deterministic — fallback only
    "enabled": True,
    "default_cadence_cron": "0 */6 * * *",
    "default_max_search_results": 8,
    "default_max_reviewed_per_tick": 5,
    "default_search_time_window": "w",
    "default_max_age_days": 14,
    "require_publish_date": False,
    "relevance_threshold": 0.65,
    "llm_tier": "capable",
    "reviewer_agent": "fact-checker",
    "log_empty_ticks": True,
    "extra_skip_domains": [
        "youtube.com", "tiktok.com", "reddit.com", "medium.com", "buzzfeed.com",
    ],
    "url_cooldown_hours": 24,
    "max_cooldown_entries": 500,
}

# Forbidden tier — the skill prompt itself refuses fast-tier execution
# but the engine enforces it again to guard against operator override.
_FORBIDDEN_TIERS = frozenset({"fast"})

# Universal news-watcher noise — social media + video aggregators that
# are NEVER appropriate as news sources regardless of topic. Structural,
# not strategy: a user who genuinely wants Twitter/X content is reading
# a different feed surface, not the news watcher. Per-YAML domains in
# `extra_skip_domains` are appended on top for tunable additions.
# arch:deterministic — universal noise filter, never overridden; tunable
# additions go in news.yaml extra_skip_domains
_BASE_SKIP_DOMAINS = frozenset({  # arch:deterministic — universal news-source-disqualified domains; user adds via extra_skip_domains
    "youtube.com", "twitter.com", "x.com", "facebook.com",
    "instagram.com", "linkedin.com", "tiktok.com",
})


# ── Topic data shape ───────────────────────────────────────────────────────


@dataclass
class TopicConfig:
    """One configured (KB, topic) watch pair with effective config.

    The engine builds these from the per-KB SCHEMA.md `news_watch:`
    block, layering on global defaults from news.yaml. Holds only the
    effective values (post-merge), not the raw YAML — so callers don't
    need to know about override semantics.
    """
    kb_slug: str
    name: str  # canonical topic name, e.g. "AI safety incidents"
    enabled: bool
    query_variants: list[str]
    cadence_cron: str
    max_search_results: int
    max_reviewed_per_tick: int
    relevance_threshold: float
    search_time_window: str | None  # "d"/"w"/"m"/"y" or None
    max_age_days: int
    require_publish_date: bool

    @property
    def slug(self) -> str:
        """ASCII slug for use in cron job names + log paths."""
        return _slugify(self.name)

    @property
    def cron_job_name(self) -> str:
        """Stable, idempotent cron job name."""
        return f"news-{self.kb_slug}-{self.slug}"


# ── Slug helper ────────────────────────────────────────────────────────────


def _slugify(text: str) -> str:
    """ASCII slug generator. Lowercase, hyphens, no consecutive separators."""
    if not text:
        return "untitled"
    s = re.sub(r"[^a-zA-Z0-9]+", "-", text.lower()).strip("-")
    return s[:64] or "untitled"


# ── Config loading ─────────────────────────────────────────────────────────


def load_global_config(skill_loader: SkillLoader | None) -> dict[str, Any]:
    """Read news.yaml; fall back to hardcoded defaults on any error."""
    if skill_loader is None:
        return dict(_FALLBACK_GLOBAL)
    try:
        data = skill_loader.load_skill_config_file("news-watcher", "news.yaml")
    except Exception:
        log.debug("news-watcher: news.yaml load failed", exc_info=True)
        return dict(_FALLBACK_GLOBAL)
    if not isinstance(data, dict):
        return dict(_FALLBACK_GLOBAL)
    # Layer YAML over defaults so missing keys still resolve.
    merged = dict(_FALLBACK_GLOBAL)
    merged.update({k: v for k, v in data.items() if v is not None})
    return merged


def load_kb_news_block(vault_reader: VaultReader | None, kb_slug: str) -> dict[str, Any]:
    """Read the `news_watch:` block from a KB's SCHEMA.md.

    Returns ``{}`` when the KB has no news_watch declaration. Never
    raises — bad YAML in one KB doesn't take down the watcher for
    other KBs.
    """
    if vault_reader is None:
        return {}
    try:
        # SCHEMA.md uses YAML frontmatter for structural fields.
        # We read the WHOLE file and parse the news_watch: block from
        # body content (it's a top-level YAML doc embedded as a
        # fenced block under "## News Watch" OR as a top-level YAML
        # block if SCHEMA.md is pure YAML).
        # For robustness we accept three locations:
        #   1. frontmatter `news_watch:` field (highest priority)
        #   2. top-level YAML block in body (when SCHEMA is pure YAML)
        #   3. fenced ```yaml news_watch: ...``` block in body
        rel_path = f"knowledge/{kb_slug}/SCHEMA.md"
        try:
            doc = vault_reader.read(rel_path)
        except Exception:
            return {}
        if doc is None:
            return {}
        meta = getattr(doc, "metadata", None) or {}
        if isinstance(meta, dict) and isinstance(meta.get("news_watch"), dict):
            return meta["news_watch"]
        # Fall through to body parsing
        body = getattr(doc, "content", "") or ""
        return _parse_news_block_from_body(body)
    except Exception:
        log.debug("news-watcher: KB %s SCHEMA load failed", kb_slug, exc_info=True)
        return {}


def _parse_news_block_from_body(body: str) -> dict[str, Any]:
    """Extract news_watch dict from a SCHEMA.md body string.

    Accepts either:
      * a fenced YAML block introduced by ``## News Watch`` then
        ```yaml ... ```
      * a bare ``news_watch:`` top-level key in a pure YAML body
    """
    if not body or "news_watch" not in body:
        return {}
    try:
        import yaml
    except ImportError:
        return {}

    # Try fenced YAML block under ## News Watch heading.
    m = re.search(
        r"##\s*News Watch[^\n]*\n+```ya?ml\s*\n(.*?)\n```",
        body,
        flags=re.IGNORECASE | re.DOTALL,
    )
    if m:
        try:
            data = yaml.safe_load(m.group(1)) or {}
            if isinstance(data, dict) and isinstance(data.get("news_watch"), dict):
                return data["news_watch"]
        except yaml.YAMLError:
            return {}

    # Try whole body as YAML (when SCHEMA.md is pure YAML).
    try:
        data = yaml.safe_load(body) or {}
        if isinstance(data, dict) and isinstance(data.get("news_watch"), dict):
            return data["news_watch"]
    except yaml.YAMLError:
        return {}

    return {}


# ── Topic resolution ───────────────────────────────────────────────────────


def resolve_topics(
    kb_slug: str,
    kb_block: dict[str, Any],
    global_cfg: dict[str, Any],
) -> list[TopicConfig]:
    """Merge global + per-KB + per-topic config into TopicConfig objects.

    The override chain is:
        global_cfg (news.yaml) → kb_block (KB SCHEMA news_watch) →
        per-topic overrides (kb_block.topics[i])

    Topics with `enabled: false` (or KB-block disabled) are still
    returned but with `enabled=False` so the caller can decide whether
    to register/skip.
    """
    if not isinstance(kb_block, dict):
        return []
    kb_enabled = bool(kb_block.get("enabled", True))
    raw_topics = kb_block.get("topics") or []
    if not isinstance(raw_topics, list):
        return []

    out: list[TopicConfig] = []
    for raw in raw_topics:
        if not isinstance(raw, dict):
            continue
        name = str(raw.get("name") or "").strip()
        if not name:
            continue
        topic_enabled = bool(raw.get("enabled", True))
        variants = raw.get("query_variants") or [name]
        if not isinstance(variants, list) or not variants:
            variants = [name]
        out.append(TopicConfig(
            kb_slug=kb_slug,
            name=name,
            enabled=kb_enabled and topic_enabled,
            query_variants=[str(v) for v in variants if v],
            cadence_cron=str(
                raw.get("cadence_cron")
                or kb_block.get("cadence_cron")
                or global_cfg.get("default_cadence_cron")
                or _FALLBACK_GLOBAL["default_cadence_cron"]
            ),
            max_search_results=int(
                raw.get("max_search_results")
                or kb_block.get("max_search_results")
                or global_cfg.get("default_max_search_results")
                or _FALLBACK_GLOBAL["default_max_search_results"]
            ),
            max_reviewed_per_tick=int(
                raw.get("max_reviewed_per_tick")
                or kb_block.get("max_reviewed_per_tick")
                or global_cfg.get("default_max_reviewed_per_tick")
                or _FALLBACK_GLOBAL["default_max_reviewed_per_tick"]
            ),
            relevance_threshold=float(
                raw.get("relevance_threshold")
                if raw.get("relevance_threshold") is not None
                else (
                    kb_block.get("relevance_threshold")
                    if kb_block.get("relevance_threshold") is not None
                    else global_cfg.get("relevance_threshold", _FALLBACK_GLOBAL["relevance_threshold"])
                )
            ),
            search_time_window=(
                raw.get("search_time_window")
                or kb_block.get("search_time_window")
                or global_cfg.get("default_search_time_window")
            ),
            max_age_days=int(
                raw.get("max_age_days")
                or kb_block.get("max_age_days")
                or global_cfg.get("default_max_age_days")
                or _FALLBACK_GLOBAL["default_max_age_days"]
            ),
            require_publish_date=bool(
                raw.get("require_publish_date")
                if raw.get("require_publish_date") is not None
                else (
                    kb_block.get("require_publish_date")
                    if kb_block.get("require_publish_date") is not None
                    else global_cfg.get("require_publish_date", False)
                )
            ),
        ))
    return out


# ── Publish-date extraction ───────────────────────────────────────────────


# Order matters: stronger signals first. A page that has both JSON-LD
# datePublished AND a URL date pattern should use JSON-LD (the
# publisher's structured-data declaration is more reliable than a
# URL guess).
_DATE_META_RE = re.compile(
    r'<meta[^>]*(?:property|name)\s*=\s*["\']'
    r'(?:article:published_time|og:article:published_time|'
    r'datePublished|pubdate|publishdate|dc\.date|date)["\'][^>]*'
    r'content\s*=\s*["\']([^"\']+)["\']',
    re.IGNORECASE,
)
_TIME_ELEMENT_RE = re.compile(
    r'<time[^>]+datetime\s*=\s*["\']([^"\']+)["\']',
    re.IGNORECASE,
)
_JSONLD_RE = re.compile(
    r'<script[^>]+type\s*=\s*["\']application/ld\+json["\'][^>]*>'
    r'(.*?)</script>',
    re.IGNORECASE | re.DOTALL,
)
_URL_DATE_RE = re.compile(r"/(20\d{2})/(\d{1,2})/(\d{1,2})/")


def extract_published_at(html_or_text: str, url: str = "") -> datetime | None:
    """Best-effort publish-date extraction from raw page HTML or URL.

    Walks the canonical metadata locations in priority order:
      1. JSON-LD ``datePublished`` (schema.org NewsArticle / Article)
      2. ``<meta property="article:published_time">`` and friends
      3. ``<time datetime="...">`` element
      4. URL date pattern ``/2026/04/27/``

    Returns a timezone-aware UTC datetime, or None when no signal
    survives. Never raises — a broken date string falls through to
    the next signal.
    """
    if not html_or_text:
        return _date_from_url(url)

    # 1. JSON-LD
    for m in _JSONLD_RE.finditer(html_or_text):
        try:
            payload = json.loads(m.group(1).strip())
        except (json.JSONDecodeError, ValueError):
            continue
        # JSON-LD can be an array OR an object — handle both.
        candidates = payload if isinstance(payload, list) else [payload]
        for entry in candidates:
            if not isinstance(entry, dict):
                continue
            for key in ("datePublished", "dateCreated", "datePosted"):
                val = entry.get(key)
                if isinstance(val, str):
                    parsed = _parse_iso_date(val)
                    if parsed:
                        return parsed

    # 2. <meta>
    m = _DATE_META_RE.search(html_or_text)
    if m:
        parsed = _parse_iso_date(m.group(1))
        if parsed:
            return parsed

    # 3. <time datetime>
    m = _TIME_ELEMENT_RE.search(html_or_text)
    if m:
        parsed = _parse_iso_date(m.group(1))
        if parsed:
            return parsed

    # 4. URL date pattern
    return _date_from_url(url)


def _parse_iso_date(text: str) -> datetime | None:
    """Parse an ISO-8601 / RFC3339 date string. Returns UTC-aware dt."""
    if not text:
        return None
    text = text.strip()
    # Common variants: "2026-04-27T14:30:00Z", "2026-04-27T14:30:00+02:00",
    # "2026-04-27", "2026-04-27 14:30:00".
    candidates = [
        text,
        text.replace("Z", "+00:00"),
        text.split(".")[0] + ("+00:00" if "+" not in text and "Z" not in text else ""),
    ]
    for c in candidates:
        try:
            dt = datetime.fromisoformat(c)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=UTC)
            return dt.astimezone(UTC)
        except ValueError:
            continue
    return None


def _date_from_url(url: str) -> datetime | None:
    """Extract a date from a URL path like /2026/04/27/article-slug/."""
    if not url:
        return None
    m = _URL_DATE_RE.search(url)
    if not m:
        return None
    try:
        return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)), tzinfo=UTC)
    except (ValueError, OverflowError):
        return None


def is_within_age_window(
    published_at: datetime | None,
    max_age_days: int,
    require_publish_date: bool,
    now: datetime | None = None,
) -> tuple[bool, str]:
    """Decide if a source passes the recency gate.

    Returns ``(passed, reason)``. When ``require_publish_date=True``
    and the date is unknown, this returns ``(False, "no_publish_date")``.
    Otherwise unknown dates pass with reason ``"unknown_date_allowed"``.
    """
    if published_at is None:
        if require_publish_date:
            return False, "no_publish_date"
        return True, "unknown_date_allowed"
    now = now or datetime.now(UTC)
    age = now - published_at
    if age < timedelta(0):
        # Future-dated articles are usually a parsing artifact (timezone
        # confusion). Allow but flag.
        return True, "future_date_tolerated"
    if age <= timedelta(days=max_age_days):
        return True, "within_window"
    return False, f"older_than_{max_age_days}d"


# ── URL cooldown ───────────────────────────────────────────────────────────


@dataclass
class CooldownEntry:
    url: str
    blocked_until: datetime
    reason: str


class URLCooldown:
    """Per-process URL blacklist for rejected sources.

    Prevents a flaky topic from re-scraping the same noise on every
    tick. Bounded size — oldest first eviction. State is in-memory
    only; restart resets cooldowns. Persisting would require another
    SQLite table for marginal value.
    """
    def __init__(self, max_entries: int = 500) -> None:
        self._entries: dict[str, CooldownEntry] = {}
        self._max = max(50, max_entries)

    def block(self, url: str, hours: int, reason: str) -> None:
        if not url or hours <= 0:
            return
        until = datetime.now(UTC) + timedelta(hours=hours)
        self._entries[url] = CooldownEntry(url=url, blocked_until=until, reason=reason)
        if len(self._entries) > self._max:
            # Evict oldest (smallest blocked_until first — but FIFO by
            # insertion is fine since we always extend the time on
            # re-block).
            oldest = next(iter(self._entries))
            self._entries.pop(oldest, None)

    def is_blocked(self, url: str) -> tuple[bool, str | None]:
        entry = self._entries.get(url)
        if not entry:
            return False, None
        if entry.blocked_until <= datetime.now(UTC):
            self._entries.pop(url, None)
            return False, None
        return True, entry.reason

    def size(self) -> int:
        return len(self._entries)


# ── Result shape ───────────────────────────────────────────────────────────


@dataclass
class TickResult:
    """One news-watcher tick outcome.

    Captures the full per-stage flow so the activity log + decision
    record + UI can show what happened. Never raises — exceptions are
    captured into ``error`` and the partial result is returned.
    """
    kb_slug: str
    topic: str
    started_at: str
    finished_at: str | None = None
    success: bool = True
    error: str | None = None
    skipped_reason: str | None = None
    query_used: str = ""
    searched: int = 0
    filtered_in: int = 0
    cooldown_hits: int = 0
    scraped: int = 0
    skipped_quality: int = 0
    skipped_relevance: int = 0
    skipped_age: int = 0
    reviewed: int = 0
    kept: int = 0
    rejected: int = 0
    review_errors: int = 0
    keepers: list[dict[str, Any]] = field(default_factory=list)


# ── Engine ────────────────────────────────────────────────────────────────


class NewsWatcher:
    """The news-watcher engine.

    Wired in main.py with the same dependencies the dream handler uses:
    skill_loader (for config), vault_reader (for KB SCHEMA scans),
    cron (for job registration), agent (for invoke_skill), tool_executor
    (for direct search/scrape calls), activity_logger + decision_logger
    (for Rule #13 observability).

    Lifecycle:
        engine = NewsWatcher(...)
        await engine.discover_and_register()  # called at startup
        # cron fires _action_for_topic(...) on schedule
        # users can also call engine.tick(kb, topic_name) manually

    Adding a topic at runtime: a future PUT /api/kb/{slug}/news-watch
    route can call engine.discover_and_register() again to re-scan
    SCHEMA.md and (re)register cron jobs idempotently. Cron's
    add_job is INSERT OR UPDATE so re-running is safe.
    """

    def __init__(
        self,
        *,
        skill_loader: SkillLoader,
        vault_reader: VaultReader,
        cron: CronScheduler,
        agent: Agent,
        tool_executor: Any,
        activity_logger: ActivityLogger | None = None,
        decision_logger: Any | None = None,
    ) -> None:
        self._skill_loader = skill_loader
        self._vault_reader = vault_reader
        self._cron = cron
        self._agent = agent
        self._tool_executor = tool_executor
        self._activity = activity_logger
        self._decisions = decision_logger
        self._cooldown = URLCooldown()
        self._registered_jobs: set[str] = set()

    # ── Public API ────────────────────────────────────────────────────────

    async def discover_and_register(self) -> dict[str, Any]:
        """Scan all KBs for `news_watch:` SCHEMA blocks; register cron jobs.

        Idempotent — calling repeatedly is safe. Disabled topics are
        skipped (their cron jobs are removed if previously registered).
        Returns a summary dict for logging.
        """
        global_cfg = load_global_config(self._skill_loader)
        if not global_cfg.get("enabled", True):
            self._log_event(
                "knowledge",
                "news_watcher_disabled",
                "News watcher master switch is off — no topics registered",
                {},
                "low",
            )
            return {"enabled": False, "registered": 0, "skipped": 0}

        # Refresh cooldown size limit from config.
        max_cooldown = int(global_cfg.get("max_cooldown_entries") or _FALLBACK_GLOBAL["max_cooldown_entries"])
        self._cooldown._max = max(50, max_cooldown)  # noqa: SLF001

        kb_slugs = self._list_kbs()
        registered = 0
        disabled_topics: list[str] = []
        new_jobs: set[str] = set()

        for kb in kb_slugs:
            kb_block = load_kb_news_block(self._vault_reader, kb)
            if not kb_block:
                continue
            topics = resolve_topics(kb, kb_block, global_cfg)
            for topic in topics:
                job_name = topic.cron_job_name
                if not topic.enabled:
                    disabled_topics.append(job_name)
                    # Remove cron entry if previously registered.
                    if job_name in self._registered_jobs:
                        with contextlib.suppress(Exception):
                            await self._cron.remove_job(job_name)
                        self._registered_jobs.discard(job_name)
                    continue
                # Register handler under the topic's job name. Cron
                # add_job is INSERT OR UPDATE so this is idempotent.
                action = job_name  # action == job name; one-handler-per-topic
                self._cron.register_handler(action, self._make_action(topic))
                await self._cron.add_job(
                    name=job_name,
                    schedule=topic.cadence_cron,
                    action=action,
                )
                new_jobs.add(job_name)
                registered += 1

        # Remove cron jobs for topics that no longer exist.
        for stale in self._registered_jobs - new_jobs:
            with contextlib.suppress(Exception):
                await self._cron.remove_job(stale)
        self._registered_jobs = new_jobs

        summary = {
            "enabled": True,
            "registered": registered,
            "disabled_topics": len(disabled_topics),
            "kb_count": len(kb_slugs),
        }
        if registered > 0:
            self._log_event(
                "knowledge",
                "news_watcher_registered",
                f"News watcher registered {registered} topic(s) across {len(kb_slugs)} KB(s)",
                summary,
                "low",
            )
        return summary

    async def tick(self, kb_slug: str, topic_name: str) -> TickResult:
        """Run ONE news watch tick for a (KB, topic) pair.

        Public surface for both the cron handler and a manual API
        call (`POST /api/kb/{slug}/news-watch/tick`). Captures all
        exceptions into the result — never raises.
        """
        result = TickResult(
            kb_slug=kb_slug,
            topic=topic_name,
            started_at=datetime.now(UTC).isoformat(),
        )
        try:
            global_cfg = load_global_config(self._skill_loader)
            if not global_cfg.get("enabled", True):
                result.skipped_reason = "watcher_disabled"
                return self._finish(result)
            kb_block = load_kb_news_block(self._vault_reader, kb_slug)
            topics = resolve_topics(kb_slug, kb_block, global_cfg)
            topic = next(
                (t for t in topics if t.name == topic_name and t.enabled),
                None,
            )
            if topic is None:
                result.skipped_reason = "topic_not_found_or_disabled"
                return self._finish(result)

            tier = global_cfg.get("llm_tier") or _FALLBACK_GLOBAL["llm_tier"]
            if tier in _FORBIDDEN_TIERS:
                result.skipped_reason = "forbidden_llm_tier"
                result.error = f"news-watcher refuses tier '{tier}' — set llm_tier: capable in news.yaml"
                return self._finish(result)

            await self._run_pipeline(topic, global_cfg, result)
        except Exception as e:
            log.exception("news-watcher tick failed: %s/%s", kb_slug, topic_name)
            result.success = False
            result.error = f"{type(e).__name__}: {e}"
            self._log_event(
                "knowledge",
                "news_watcher_tick_crashed",
                f"News watcher tick crashed: {kb_slug}/{topic_name}",
                {"kb": kb_slug, "topic": topic_name, "error": str(e)},
                "high",
            )
        return self._finish(result)

    # ── Internal pipeline ────────────────────────────────────────────────

    async def _run_pipeline(
        self,
        topic: TopicConfig,
        global_cfg: dict[str, Any],
        result: TickResult,
    ) -> None:
        # 1. Pick the next query variant (rotate by minute so different
        # ticks across the day use different phrasings).
        query_idx = (datetime.now(UTC).hour) % max(1, len(topic.query_variants))
        query = topic.query_variants[query_idx]
        result.query_used = query

        # 2. Search (with recency filter).
        search_results = self._do_search(
            query=query,
            max_results=topic.max_search_results + 3,  # +3 for the post-filter trim
            time_window=topic.search_time_window,
        )
        result.searched = len(search_results)
        if not search_results:
            result.skipped_reason = "no_search_results"
            self._maybe_log_empty(topic, global_cfg, result)
            return

        # 3. Filter results (skip domains + cooldown).
        skip_domains = _BASE_SKIP_DOMAINS | set(global_cfg.get("extra_skip_domains") or [])
        filtered: list[dict[str, Any]] = []
        for r in search_results:
            url = r.get("href") or r.get("url") or ""
            if not url or url.endswith(".pdf"):
                continue
            domain = urlparse(url).netloc.replace("www.", "")
            if domain in skip_domains:
                continue
            blocked, reason = self._cooldown.is_blocked(url)
            if blocked:
                result.cooldown_hits += 1
                continue
            filtered.append(r)
            if len(filtered) >= topic.max_search_results:
                break
        result.filtered_in = len(filtered)
        if not filtered:
            result.skipped_reason = "all_filtered"
            self._maybe_log_empty(topic, global_cfg, result)
            return

        # 4. Scrape via existing browser stack.
        from agntspace.integrations.browser import scrape_many
        urls = [r.get("href") or r.get("url") for r in filtered]
        urls = [u for u in urls if u]
        # scrape_many's `min_len` is keyword-only; passing positionally
        # raises TypeError. Wrap in a small lambda so to_thread keeps
        # the kwarg signature intact.
        def _do_scrape(urls_arg: list[str]) -> list[dict[str, Any]]:
            return scrape_many(urls_arg, min_len=200)
        scrape_results = await asyncio.to_thread(_do_scrape, urls)

        # 5. For each scrape: deterministic gates → date gate → review queue.
        review_queue: list[dict[str, Any]] = []
        now = datetime.now(UTC)
        for r, sr in zip(filtered, scrape_results, strict=False):
            url = r.get("href") or r.get("url") or ""
            content = sr.get("text") or ""
            if not content:
                continue
            word_count = len(re.findall(r"\w+", content))
            # Quality gate (deterministic, free)
            if word_count < 150:
                result.skipped_quality += 1
                self._cooldown.block(url, 6, "thin_content")
                continue
            # Date gate (deterministic, free)
            published_at = extract_published_at(content, url)
            in_window, age_reason = is_within_age_window(
                published_at,
                topic.max_age_days,
                topic.require_publish_date,
                now,
            )
            if not in_window:
                result.skipped_age += 1
                # Cooldown old articles for longer — they aren't going
                # to be news next tick either.
                cooldown_h = int(global_cfg.get("url_cooldown_hours") or 24) * 4
                self._cooldown.block(url, cooldown_h, age_reason)
                continue
            # Relevance gate (deterministic, free) — light keyword overlap
            # uses ToolExecutor's helper if wired; otherwise falls back to
            # simple word presence.
            relevance = self._check_relevance(content, topic.name)
            if not relevance["passed"]:
                result.skipped_relevance += 1
                cooldown_h = int(global_cfg.get("url_cooldown_hours") or 24)
                self._cooldown.block(url, cooldown_h, "off_topic")
                continue
            review_queue.append({
                "url": url,
                "title": r.get("title") or "",
                "content": content,
                "word_count": word_count,
                "relevance_overlap": round(relevance["overlap_ratio"], 3),
                "published_at": published_at.isoformat() if published_at else None,
            })
            if len(review_queue) >= topic.max_reviewed_per_tick:
                break
        result.scraped = len(review_queue) + result.skipped_quality + result.skipped_relevance + result.skipped_age

        if not review_queue:
            result.skipped_reason = "all_filtered_at_gates"
            self._maybe_log_empty(topic, global_cfg, result)
            return

        # 6. Per-source review via news-curator + fact-checker (TEAM gate).
        for candidate in review_queue:
            verdict = await self._dispatch_review(candidate, topic, global_cfg)
            result.reviewed += 1
            if verdict.get("error"):
                result.review_errors += 1
                # Don't penalize the URL — review error is on us, not it.
                continue
            if verdict.get("verdict") == "keep" and verdict.get("score", 0.0) >= topic.relevance_threshold:
                # 7. Save the keeper to KB inbox via the existing pipeline.
                saved = await self._save_keeper(topic, candidate, verdict)
                if saved:
                    result.kept += 1
                    result.keepers.append({
                        "url": candidate["url"],
                        "title": candidate["title"],
                        "score": verdict.get("score"),
                        "saved_to": saved,
                    })
            else:
                result.rejected += 1
                cooldown_h = int(global_cfg.get("url_cooldown_hours") or 24)
                self._cooldown.block(candidate["url"], cooldown_h, "review_rejected")

        if result.kept == 0 and result.reviewed > 0:
            result.skipped_reason = "all_rejected_by_review"
            self._maybe_log_empty(topic, global_cfg, result)
            return

        # 8. Append to _news_log.md so the user has a per-KB audit trail.
        await self._append_news_log(topic, result)

        # 9. Emit a successful-tick event.
        if result.kept > 0:
            self._log_event(
                "knowledge",
                "news_watcher_kept",
                f"News watcher kept {result.kept} source(s) for '{topic.name}' → {topic.kb_slug}",
                {
                    "kb": topic.kb_slug,
                    "topic": topic.name,
                    "kept": result.kept,
                    "rejected": result.rejected,
                    "skipped_age": result.skipped_age,
                    "skipped_quality": result.skipped_quality,
                    "skipped_relevance": result.skipped_relevance,
                    "cooldown_hits": result.cooldown_hits,
                    "query": result.query_used,
                },
                "medium",
            )

    # ── Pipeline helpers ────────────────────────────────────────────────

    def _do_search(
        self,
        *,
        query: str,
        max_results: int,
        time_window: str | None,
    ) -> list[dict[str, Any]]:
        """Search via DuckDuckGo with optional recency filter.

        Catches the import + network errors that DDGS can throw and
        returns an empty list — the caller treats no_search_results
        as a benign skip.
        """
        try:
            from ddgs import DDGS
        except ImportError:
            log.warning("news-watcher: ddgs not installed — search disabled")
            return []
        try:
            kwargs: dict[str, Any] = {"max_results": max_results}
            if time_window in ("d", "w", "m", "y"):
                kwargs["timelimit"] = time_window
            results = DDGS().text(query, **kwargs)
            return list(results) if results else []
        except Exception:
            log.debug("news-watcher: DDGS search failed for %r", query, exc_info=True)
            return []

    def _check_relevance(self, content: str, topic: str) -> dict[str, Any]:
        """Deterministic keyword-overlap relevance check.

        Mirrors ToolExecutor._check_topic_relevance shape but standalone
        so this engine doesn't depend on internal tool internals.
        Defaults are intentionally a notch stricter than research_scrape's
        defaults — news is noisier than ad-hoc research.
        """
        topic_words = {w.lower() for w in re.findall(r"\w{4,}", topic) if not w.isdigit()}
        if not topic_words:
            return {"passed": True, "overlap_ratio": 1.0, "matched": 0}
        text_words = {w.lower() for w in re.findall(r"\w{4,}", content[:8000])}
        matched = len(topic_words & text_words)
        overlap_ratio = matched / max(1, len(topic_words))
        passed = overlap_ratio >= 0.3 and matched >= 1
        return {
            "passed": passed,
            "overlap_ratio": overlap_ratio,
            "matched": matched,
            "topic_keywords": len(topic_words),
        }

    async def _dispatch_review(
        self,
        candidate: dict[str, Any],
        topic: TopicConfig,
        global_cfg: dict[str, Any],
    ) -> dict[str, Any]:
        """Dispatch the news-curator skill for one source.

        Returns a dict with keys: verdict ("keep"|"reject"), score,
        reason, error.
        """
        if self._agent is None or not hasattr(self._agent, "invoke_skill"):
            return {"error": "agent_not_wired"}
        excerpt = (candidate.get("content") or "")[:1500]
        args = {
            "topic": topic.name,
            "kb": topic.kb_slug,
            "url": candidate.get("url"),
            "title": candidate.get("title"),
            "content_excerpt": excerpt,
            "relevance_overlap": candidate.get("relevance_overlap"),
            "word_count": candidate.get("word_count"),
            "published_at": candidate.get("published_at"),
            "threshold": topic.relevance_threshold,
            "reviewer_agent": global_cfg.get("reviewer_agent") or "fact-checker",
        }
        try:
            outcome = await self._agent.invoke_skill(
                "news-watcher",
                args,
                agent_name="news-curator",
                caller="news-watcher-engine",
                # News-watching is background work the user wants kept local
                # + free. ``prefer_local=True`` routes the dispatch to local
                # Ollama even when deployment is cloud, IF the user has
                # enabled ``honor_prefer_local: true`` in models.yaml AND
                # Ollama is reachable. Otherwise the dispatch falls through
                # to the agent's normal tier (capable → cloud). Defensive:
                # older Agent.invoke_skill without prefer_local kwarg
                # gracefully degrades to default routing.
                prefer_local=True,
            )
        except Exception as e:
            log.debug("news-watcher: invoke_skill failed", exc_info=True)
            return {"error": f"invoke_skill failed: {e}"}
        # SkillOutcome.content carries the LLM reply text. (Earlier draft
        # used `summary` which is not a SkillOutcome field — every review
        # parsed as malformed and got rejected silently.)
        reply = getattr(outcome, "content", None)
        if not reply:
            reply = getattr(outcome, "summary", "") or ""
        verdict = _parse_curator_response(reply or "", threshold=topic.relevance_threshold)
        # Visibility: when the parser hits malformed_response, log a short
        # excerpt so we can iterate on the prompt. Stays at debug level
        # so it doesn't pollute production output, but appears in DEBUG
        # logs and dev runs.
        if verdict.get("error"):
            log.debug(
                "news-watcher: malformed curator reply (kb=%s topic=%s url=%s): %r",
                topic.kb_slug, topic.name, candidate.get("url"),
                (reply or "")[:300],
            )
        return verdict

    async def _save_keeper(
        self,
        topic: TopicConfig,
        candidate: dict[str, Any],
        verdict: dict[str, Any],
    ) -> str | None:
        """Save a keeper to the KB inbox with full provenance frontmatter.

        The existing inbox watcher will pick it up on its next 30s tick
        and route it through the standard ingest pipeline (classify →
        compile → reflect → lint).
        """
        try:
            from agntspace.vault.paths import VaultPaths  # noqa: F401
        except ImportError:
            return None
        try:
            inbox_dir = self._vault_reader.paths.resolve(f"knowledge/{topic.kb_slug}/inbox")
        except Exception:
            return None
        inbox_dir.mkdir(parents=True, exist_ok=True)
        url = candidate.get("url") or ""
        parsed = urlparse(url)
        slug_base = (parsed.netloc.replace("www.", "") + parsed.path)
        filename = re.sub(r"[^a-zA-Z0-9]+", "-", slug_base).strip("-")[:80] or "news"
        out_path = inbox_dir / f"{filename}.md"

        # Don't overwrite — content_hash dedup catches re-saves elsewhere
        # but inbox-level filename collisions deserve their own suffix.
        i = 1
        while out_path.exists():
            out_path = inbox_dir / f"{filename}-{i}.md"
            i += 1
            if i > 50:
                return None  # something is very wrong; bail

        title = (candidate.get("title") or "").replace('"', '\\"')
        published_at = candidate.get("published_at") or ""
        score = verdict.get("score", 0.0)
        reason = (verdict.get("reason") or "").replace('"', '\\"').replace("\n", " ")[:200]
        relevance = candidate.get("relevance_overlap", 0.0)
        word_count = candidate.get("word_count", 0)

        frontmatter = (
            f"---\n"
            f"title: \"{title}\"\n"
            f"source_url: {url}\n"
            f"author: agent\n"
            f"agent: news-curator\n"
            f"news_topic: \"{topic.name}\"\n"
            f"news_query: \"{topic.query_variants[0]}\"\n"
            f"published_at: \"{published_at}\"\n"
            f"word_count: {word_count}\n"
            f"relevance_overlap: {relevance:.2f}\n"
            f"review_score: {score:.2f}\n"
            f"review_reason: \"{reason}\"\n"
            f"---\n\n"
        )
        try:
            await asyncio.to_thread(
                out_path.write_text,
                frontmatter + (candidate.get("content") or ""),
                "utf-8",
            )
            return str(out_path)
        except Exception:
            log.debug("news-watcher: save failed for %s", url, exc_info=True)
            return None

    async def _append_news_log(self, topic: TopicConfig, result: TickResult) -> None:
        """Append a single audit line to <kb>/wiki/_news_log.md."""
        try:
            wiki_dir = self._vault_reader.paths.resolve(f"knowledge/{topic.kb_slug}/wiki")
        except Exception:
            return
        wiki_dir.mkdir(parents=True, exist_ok=True)
        log_path = wiki_dir / "_news_log.md"
        ts = datetime.now(UTC).strftime("%Y-%m-%d %H:%M UTC")
        kept_titles = ", ".join(
            (k.get("title") or k.get("url") or "?")[:60] for k in result.keepers
        ) or "—"
        line = (
            f"- {ts} — **{topic.name}** — kept {result.kept}, rejected {result.rejected}, "
            f"skipped_age {result.skipped_age}, skipped_quality {result.skipped_quality}, "
            f"skipped_relevance {result.skipped_relevance}; titles: {kept_titles}\n"
        )
        try:
            if not log_path.exists():
                header = (
                    "---\n"
                    f"title: \"{topic.kb_slug.title()} — News Log\"\n"
                    f"author: agent\n"
                    f"agent: news-curator\n"
                    f"date: {datetime.now(UTC).date().isoformat()}\n"
                    "---\n\n"
                    "# News Log\n\n"
                    "Bookkeeping log of news-watcher ticks. One line per tick. "
                    "See per-source frontmatter in `knowledge/{kb}/library/.../news-*.md` "
                    "or `agntspace-knowledge/{kb}/inbox/` (pre-ingest) for full text.\n\n"
                )
                await asyncio.to_thread(log_path.write_text, header + line, "utf-8")
            else:
                # Append-only; reading + writing protects existing content.
                existing = await asyncio.to_thread(log_path.read_text, "utf-8")
                await asyncio.to_thread(log_path.write_text, existing + line, "utf-8")
        except Exception:
            log.debug("news-watcher: news log append failed for %s", topic.kb_slug, exc_info=True)

    # ── Cron handler factory ───────────────────────────────────────────

    def _make_action(self, topic: TopicConfig):
        """Return an async callable bound to this (kb, topic) pair."""
        kb = topic.kb_slug
        name = topic.name
        async def _action() -> str:
            r = await self.tick(kb, name)
            if not r.success:
                raise RuntimeError(f"news watch failed: {r.error or 'unknown'}")
            return (
                f"news-watch {kb}/{name}: kept={r.kept} rejected={r.rejected} "
                f"skipped_age={r.skipped_age} skipped_quality={r.skipped_quality} "
                f"skipped_relevance={r.skipped_relevance} cooldown_hits={r.cooldown_hits}"
            )
        return _action

    # ── Plumbing ─────────────────────────────────────────────────────────

    def _list_kbs(self) -> list[str]:
        """Enumerate all KB slugs that have a knowledge/{slug}/ tree."""
        if self._vault_reader is None:
            return []
        try:
            knowledge_dir = self._vault_reader.paths.resolve("knowledge")
        except Exception:
            return []
        if not knowledge_dir.is_dir():
            return []
        out: list[str] = []
        for child in knowledge_dir.iterdir():
            if not child.is_dir():
                continue
            if child.name.startswith(".") or child.name.startswith("_"):
                continue
            out.append(child.name)
        return sorted(out)

    def _maybe_log_empty(
        self,
        topic: TopicConfig,
        global_cfg: dict[str, Any],
        result: TickResult,
    ) -> None:
        if not bool(global_cfg.get("log_empty_ticks", True)):
            return
        self._log_event(
            "knowledge",
            "news_watcher_empty_tick",
            f"News watcher tick produced no keepers for '{topic.name}' → {topic.kb_slug}",
            {
                "kb": topic.kb_slug,
                "topic": topic.name,
                "skipped_reason": result.skipped_reason,
                "searched": result.searched,
                "filtered_in": result.filtered_in,
                "cooldown_hits": result.cooldown_hits,
                "skipped_quality": result.skipped_quality,
                "skipped_relevance": result.skipped_relevance,
                "skipped_age": result.skipped_age,
                "rejected": result.rejected,
            },
            "low",
        )

    def _finish(self, result: TickResult) -> TickResult:
        result.finished_at = datetime.now(UTC).isoformat()
        return result

    def _log_event(
        self,
        category: str,
        action: str,
        summary: str,
        details: dict[str, Any],
        importance: str,
    ) -> None:
        if self._activity is None or not hasattr(self._activity, "log"):
            return
        with contextlib.suppress(Exception):
            self._activity.log(category, action, summary, details, importance)


# ── Curator response parser ────────────────────────────────────────────
#
# Curator + fact-checker are LLM agents — even with a strict prompt, they
# return prose like "Based on the fact-checker's review, SCORE: 0.85, I'd
# keep this." The parser treats the response as semi-structured: pull
# SCORE anywhere it appears, VERDICT if explicitly stated, otherwise the
# engine derives VERDICT from `score >= threshold`. This is the right
# trade-off for an LLM-driven layer — strict parsing produced a 75%
# malformed-rate in live testing while real signal was clearly present.


# Score line — accept anywhere in the text, not line-anchored. Captures
# the first plausible number after the keyword. Allows formatting like
# `**SCORE:** 0.85`, `Score: 0.85.`, `score = 0.85`, `scored 0.85`,
# `relevance score is 0.72`, etc. The optional "is/of" connectives
# handle prose like "score is 0.85" without requiring punctuation.
_SCORE_RE = re.compile(
    r"\b(?:scored?|scoring|rating|relevance(?:\s+score)?)"
    r"\s*(?:is|of|was|=|:)?\s*\*?\*?\s*"
    r"([01](?:\.[0-9]+)?|0?\.[0-9]+)",
    re.IGNORECASE,
)

# Verdict line — accept anywhere. The capture group keeps just the
# decision keyword. `VERDICT: keep` and `verdict = reject` both match.
_VERDICT_RE = re.compile(
    r"\bverdict\s*[:=]?\s*\*?\*?\s*(keep|reject|approve|accept|deny|skip)\b",
    re.IGNORECASE,
)

# Reason / justification — optional one-line summary. Captures either an
# explicit `REASON:` line or a `JUSTIFICATION:` line, whichever appears
# first; takes only the first line of the captured value.
_REASON_RE = re.compile(
    r"\b(?:reason|justification)\s*[:=]?\s*\*?\*?\s*(.+)",
    re.IGNORECASE,
)

_VERDICT_NORMALISE: dict[str, str] = {  # arch:deterministic — synonym normalization map for LLM verdict outputs (keep/reject/skip); deterministic string mapping, not strategy
    "keep": "keep",
    "approve": "keep",
    "accept": "keep",
    "reject": "reject",
    "deny": "reject",
    "skip": "reject",
}


def _parse_curator_response(text: str, threshold: float = 0.65) -> dict[str, Any]:
    """Parse the news-curator's reply.

    Lenient by design — extracts ``SCORE:`` and ``VERDICT:`` from anywhere
    in the prose. When VERDICT is missing but SCORE is present, derives
    the verdict from ``score >= threshold``. Only when SCORE itself is
    missing does the parser report ``error: "malformed_response"`` (and
    even then, returns ``verdict: reject`` so a hallucinating curator
    can't sneak slop through).

    Returns dict shape:
        ``{verdict, score, reason}`` on success
        ``{verdict: "reject", score: 0.0, reason: ..., error: ...}`` on
        empty / unparseable input
    """
    if not text or not isinstance(text, str):
        return {"verdict": "reject", "score": 0.0, "reason": "empty_response", "error": "empty_response"}

    # SCORE first — it's the only mandatory field.
    score_match = _SCORE_RE.search(text)
    if not score_match:
        return {
            "verdict": "reject",
            "score": 0.0,
            "reason": "no_score_in_curator_response",
            "error": "malformed_response",
        }
    try:
        score = float(score_match.group(1))
    except (ValueError, TypeError):
        return {
            "verdict": "reject",
            "score": 0.0,
            "reason": "score_not_a_number",
            "error": "malformed_response",
        }
    score = max(0.0, min(1.0, score))

    # VERDICT — explicit if present, otherwise derive from threshold.
    verdict_match = _VERDICT_RE.search(text)
    if verdict_match:
        verdict = _VERDICT_NORMALISE.get(
            verdict_match.group(1).lower(), "reject",
        )
    else:
        verdict = "keep" if score >= threshold else "reject"

    # REASON — take the first line of whatever was captured.
    reason_match = _REASON_RE.search(text)
    reason = ""
    if reason_match:
        first_line = reason_match.group(1).strip().split("\n", 1)[0]
        reason = first_line.rstrip(".*").strip()
    if not reason:
        reason = (
            "kept by score >= threshold"
            if verdict == "keep"
            else "rejected by score < threshold"
        )

    return {"verdict": verdict, "score": score, "reason": reason[:240]}
