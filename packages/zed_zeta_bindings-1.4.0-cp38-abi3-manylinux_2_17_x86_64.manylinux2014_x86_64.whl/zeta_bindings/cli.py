import argparse
import json
import sys

import zeta_bindings as zp


def cmd_format(args: argparse.Namespace) -> None:
    prompt_format = zp.resolve_format(args.format)

    f_in = open(args.input, "r") if args.input else sys.stdin
    f_out = open(args.output, "w") if args.output else sys.stdout

    for example_json in f_in:
        example = json.loads(example_json)
        expected_outputs = example.get("expected_patches")
        if expected_outputs:
            expected_output = expected_outputs[0]
        else:
            expected_output = None

        try:
            prompt_inputs = zp.ZetaPromptInput.from_dict(example["prompt_inputs"])
            formatted_input = zp.format_prompt(prompt_inputs, prompt_format)
            formatted_prefill = zp.get_prefill(prompt_inputs, prompt_format)
            formatted_output = zp.format_expected_output(
                prompt_inputs, prompt_format, expected_output
            )
        except Exception as e:
            print(
                f"Error formatting example {example.get('name')}: {e}", file=sys.stderr
            )
            continue
        example["prompt"] = {
            "input": formatted_input,
            "expected_output": formatted_output,
            "rejected_output": None,
            "prefill": formatted_prefill,
            "provider": prompt_format,
        }

        json.dump(example, f_out)
        f_out.write("\n")


def cmd_parse(args: argparse.Namespace) -> None:
    f_in = open(args.input, "r") if args.input else sys.stdin
    f_out = open(args.output, "w") if args.output else sys.stdout

    for example_json in f_in:
        example = json.loads(example_json)
        prompt = example.get("prompt")
        prompt_inputs_data = example.get("prompt_inputs")

        if prompt is not None and prompt_inputs_data is not None:
            prompt_inputs = zp.ZetaPromptInput.from_dict(prompt_inputs_data)
            predictions = example.get("predictions", [])

            for prediction in predictions:
                actual_output = prediction.get("actual_output")
                if not actual_output:
                    continue

                provider_str = prediction.get("provider") or prompt.get("provider", "")
                format_str = zp.resolve_format(provider_str)
                if format_str is None:
                    example_name = example.get("name", "?")
                    print(
                        f"Warning: no parser format found for provider '{provider_str}' in '{example_name}'",
                        file=sys.stderr,
                    )
                    continue

                try:
                    parsed_output = zp.parse_output(
                        actual_output,
                        format_str,
                        prompt_inputs,
                    )
                    prediction["parsed_output"] = zp.parsed_output_to_dict(
                        parsed_output
                    )
                    prediction["actual_patch"] = zp.parsed_output_to_patch(
                        parsed_output,
                        prompt_inputs,
                    )
                    prediction["actual_cursor"] = zp.actual_cursor_from_parsed_output(
                        parsed_output,
                        prompt_inputs,
                    )
                except Exception as exc:
                    example_name = example.get("name", "?")
                    print(
                        f"Warning: failed to parse prediction for '{example_name}': {exc}",
                        file=sys.stderr,
                    )

        json.dump(example, f_out)
        f_out.write("\n")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Prompt formatter and parser for edit prediction examples."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # -- format --
    format_parser = subparsers.add_parser(
        "format", help="Format prompts for examples in a JSONL file."
    )
    format_parser.add_argument(
        "-p",
        "--format",
        required=True,
        help="Prompt format: V0131, V0131GitMergeMarkersPrefix, V0318, or V0318SeedMultiRegions",
    )
    format_parser.add_argument("input", help="Input JSONL file path", nargs="?")
    format_parser.add_argument("-o", "--output", help="Output JSONL file path")

    # -- parse --
    parse_parser = subparsers.add_parser(
        "parse", help="Parse model outputs in a JSONL file."
    )
    parse_parser.add_argument("input", help="Input JSONL file path", nargs="?")
    parse_parser.add_argument("-o", "--output", help="Output JSONL file path")

    args = parser.parse_args()

    if args.command == "format":
        cmd_format(args)
    elif args.command == "parse":
        cmd_parse(args)


if __name__ == "__main__":
    main()
