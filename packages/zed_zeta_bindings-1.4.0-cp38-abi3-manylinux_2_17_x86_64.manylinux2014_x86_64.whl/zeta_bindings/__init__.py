"""Python bindings for zeta_prompt.

Provides typed dataclasses and helper functions that wrap the native ``_lib``
extension built with Maturin/PyO3.
"""

from __future__ import annotations

import importlib
import importlib.machinery
import importlib.util
import json
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


def _load_native_module() -> Any:
    try:
        return importlib.import_module(f"{__name__}._lib")
    except ImportError as original_error:
        package_root = Path(__file__).resolve().parents[2]
        if sys.platform == "darwin":
            candidate_paths = [
                package_root / "target" / "maturin" / "libzeta_bindings.dylib",
                package_root / "target" / "release" / "libzeta_bindings.dylib",
                package_root / "target" / "release" / "deps" / "libzeta_bindings.dylib",
                package_root / "target" / "maturin" / "libzeta_bindings.so",
            ]
        else:
            candidate_paths = [
                package_root / "target" / "maturin" / "libzeta_bindings.so",
                package_root / "target" / "maturin" / "libzeta_bindings.dylib",
                package_root / "target" / "release" / "libzeta_bindings.dylib",
                package_root / "target" / "release" / "deps" / "libzeta_bindings.dylib",
            ]

        for candidate_path in candidate_paths:
            if not candidate_path.exists():
                continue

            loader = importlib.machinery.ExtensionFileLoader(
                f"{__name__}._lib", str(candidate_path)
            )
            spec = importlib.util.spec_from_loader(f"{__name__}._lib", loader)
            if spec is None or spec.loader is None:
                continue

            module = importlib.util.module_from_spec(spec)
            sys.modules[f"{__name__}._lib"] = module
            spec.loader.exec_module(module)
            return module

        raise ImportError(
            "Could not import zeta_bindings native extension. "
            "Build/install it with `maturin develop`, or run a local build such as "
            "`just build-zeta-prompt-bindings-native` from the zeta-exp repo root."
        ) from original_error


_lib_any: Any = _load_native_module()

__all__ = [
    "ExcerptRanges",
    "Event",
    "RelatedExcerpt",
    "RelatedFile",
    "ActiveBufferDiagnostic",
    "ParsedOutput",
    "ZetaPromptInput",
    "KeptRateResult",
    "ClassificationMetrics",
    "DeltaChrFMetrics",
    "TokenChangeCounts",
    "compute_excerpt_ranges",
    "format_prompt",
    "get_prefill",
    "parse_output",
    "parsed_output_to_patch",
    "parsed_output_to_dict",
    "actual_cursor_from_parsed_output",
    "list_formats",
    "stop_tokens",
    "token_limits",
    "format_expected_output",
    "extract_cursor_from_patch",
    "compute_kept_rate",
    "delta_chr_f",
    "delta_chr_f_beta",
    "braces_disbalance",
    "extract_changed_lines_from_diff",
    "exact_lines_match",
    "has_isolated_whitespace_changes",
    "is_editable_region_correct",
    "count_patch_token_changes",
    "score_examples_json",
    "evaluation_summary_json",
    "evaluate_examples_json",
    "score_examples",
    "evaluation_summary",
    "evaluate_examples",
    "compute_prediction_reversal_ratio_from_history",
]


Range = tuple[int, int]


@dataclass
class ExcerptRanges:
    """Pre-computed byte-offset ranges within ``cursor_excerpt`` for different
    editable and context token budgets."""

    editable_150: Range
    editable_180: Range
    editable_350: Range
    editable_150_context_350: Range
    editable_180_context_350: Range
    editable_350_context_150: Range
    editable_512: Range | None = None
    editable_350_context_512: Range | None = None
    editable_350_context_1024: Range | None = None
    context_4096: Range | None = None
    context_8192: Range | None = None

    @classmethod
    def from_dict(cls, d: dict) -> "ExcerptRanges":
        return _excerpt_ranges_from_dict(d)


@dataclass
class Event:
    """A buffer-change event. Uses serde internal tagging ``#[serde(tag = "event")]``."""

    path: str
    old_path: str
    diff: str
    predicted: bool = False
    in_open_source_repo: bool = False

    @classmethod
    def from_dict(cls, d: dict) -> "Event":
        event_type = d.get("event")
        if event_type is not None and event_type != "BufferChange":
            raise ValueError(f"Unsupported event type: {event_type}")

        return cls(
            path=d["path"],
            old_path=d["old_path"],
            diff=d["diff"],
            predicted=d.get("predicted", False),
            in_open_source_repo=d.get("in_open_source_repo", False),
        )


@dataclass
class RelatedExcerpt:
    """A slice of a related file included as context."""

    row_range: Range
    text: str
    order: int = 0

    @classmethod
    def from_dict(cls, d: dict) -> "RelatedExcerpt":
        return cls(
            row_range=_range_from_dict(d["row_range"]),
            text=d["text"],
            order=d.get("order", 0),
        )


@dataclass
class RelatedFile:
    """A file related to the cursor location, included as context."""

    path: str
    max_row: int
    excerpts: list[RelatedExcerpt]
    in_open_source_repo: bool = False

    @classmethod
    def from_dict(cls, d: dict) -> "RelatedFile":
        return cls(
            path=d["path"],
            max_row=d["max_row"],
            excerpts=[RelatedExcerpt.from_dict(e) for e in d.get("excerpts", [])],
            in_open_source_repo=d.get("in_open_source_repo", False),
        )


@dataclass
class ActiveBufferDiagnostic:
    """A compiler / linter diagnostic present in the active buffer."""

    message: str
    snippet: str
    snippet_buffer_row_range: Range
    diagnostic_range_in_snippet: Range
    severity: int | None = None

    @classmethod
    def from_dict(cls, d: dict) -> "ActiveBufferDiagnostic":
        return cls(
            message=d["message"],
            snippet=d["snippet"],
            snippet_buffer_row_range=_range_from_dict(d["snippet_buffer_row_range"]),
            diagnostic_range_in_snippet=_range_from_dict(
                d["diagnostic_range_in_snippet"]
            ),
            severity=d.get("severity"),
        )


@dataclass
class ParsedOutput:
    """Structured parsed model output for the editable region."""

    new_editable_region: str
    range_in_excerpt: Range
    cursor_offset_in_new_editable_region: int | None = None

    @classmethod
    def from_dict(cls, d: dict) -> "ParsedOutput":
        return cls(
            new_editable_region=d["new_editable_region"],
            range_in_excerpt=_range_from_dict(d["range_in_excerpt"]),
            cursor_offset_in_new_editable_region=d.get(
                "cursor_offset_in_new_editable_region"
            ),
        )


@dataclass
class KeptRateResult:
    """Character-level agreement metrics between candidate and reference edits."""

    candidate_new_chars: int
    reference_new_chars: int
    candidate_deleted_chars: int
    reference_deleted_chars: int
    kept_chars: int
    correctly_deleted_chars: int
    discarded_chars: int
    context_chars: int
    kept_rate: float
    recall_rate: float
    token_annotations: list

    @classmethod
    def from_dict(cls, d: dict) -> "KeptRateResult":
        return cls(**d)


@dataclass
class ClassificationMetrics:
    """Bag-of-items classification counts used by exact-match style metrics."""

    true_positives: int
    false_positives: int
    false_negatives: int

    @classmethod
    def from_dict(cls, d: dict) -> "ClassificationMetrics":
        return cls(**d)


@dataclass
class DeltaChrFMetrics:
    """delta-chrF score and supporting precision/recall counts."""

    score: float
    beta: float
    counts: ClassificationMetrics
    precision: float
    recall: float

    @classmethod
    def from_dict(cls, d: dict) -> "DeltaChrFMetrics":
        return cls(
            score=d["score"],
            beta=d["beta"],
            counts=ClassificationMetrics.from_dict(d["counts"]),
            precision=d["precision"],
            recall=d["recall"],
        )


@dataclass
class TokenChangeCounts:
    """Token insertion and deletion counts for a patch."""

    inserted_tokens: int
    deleted_tokens: int

    @classmethod
    def from_dict(cls, d: dict) -> "TokenChangeCounts":
        return cls(**d)


@dataclass
class ZetaPromptInput:
    """All the data the model needs to produce an edit prediction."""

    cursor_path: str
    cursor_excerpt: str
    cursor_offset_in_excerpt: int
    excerpt_ranges: ExcerptRanges
    excerpt_start_row: int | None = None
    events: list[Event] = field(default_factory=list)
    related_files: list[RelatedFile] | None = None
    active_buffer_diagnostics: list[ActiveBufferDiagnostic] = field(
        default_factory=list
    )
    syntax_ranges: list[Range] | None = None
    experiment: str | None = None
    in_open_source_repo: bool = False
    can_collect_data: bool = False
    repo_url: str | None = None

    @classmethod
    def from_dict(cls, d: dict) -> "ZetaPromptInput":
        events = d.get("events") or []
        related_files = d.get("related_files")
        active_buffer_diagnostics = d.get("active_buffer_diagnostics") or []
        syntax_ranges = d.get("syntax_ranges")

        return cls(
            cursor_path=d["cursor_path"],
            cursor_excerpt=d["cursor_excerpt"],
            cursor_offset_in_excerpt=d["cursor_offset_in_excerpt"],
            excerpt_ranges=ExcerptRanges.from_dict(d["excerpt_ranges"]),
            excerpt_start_row=d.get("excerpt_start_row"),
            events=[Event.from_dict(event) for event in events],
            related_files=(
                [RelatedFile.from_dict(related_file) for related_file in related_files]
                if related_files is not None
                else None
            ),
            active_buffer_diagnostics=[
                ActiveBufferDiagnostic.from_dict(diagnostic)
                for diagnostic in active_buffer_diagnostics
            ],
            syntax_ranges=(
                [_range_from_dict(range_dict) for range_dict in syntax_ranges]
                if syntax_ranges is not None
                else None
            ),
            experiment=d.get("experiment"),
            in_open_source_repo=d.get("in_open_source_repo", False),
            can_collect_data=d.get("can_collect_data", False),
            repo_url=d.get("repo_url"),
        )


# ---- Public API ----


def compute_excerpt_ranges(
    cursor_excerpt: str,
    cursor_offset: int,
    syntax_ranges: list[Range] | None = None,
) -> ExcerptRanges:
    """Compute byte-offset excerpt ranges for all token budgets."""
    result_json = _lib_any.compute_excerpt_ranges(
        cursor_excerpt, cursor_offset, syntax_ranges
    )
    return _excerpt_ranges_from_dict(json.loads(result_json))


def format_prompt(prompt_input: ZetaPromptInput, format_str: str) -> str | None:
    """Render a prompt string ready to be sent to the model."""
    return _lib_any.format_prompt(_input_to_json(prompt_input), format_str)


def get_prefill(prompt_input: ZetaPromptInput, format_str: str) -> str:
    """Return the prompt prefill string for the given format."""
    return _lib_any.get_prefill(_input_to_json(prompt_input), format_str)


def parse_output(
    model_output: str,
    format_str: str,
    prompt_input: ZetaPromptInput,
) -> ParsedOutput:
    """Parse a raw model completion into structured editable-region output."""
    parsed_output_json = _lib_any.parse_output(
        model_output, format_str, _input_to_json(prompt_input)
    )
    return ParsedOutput.from_dict(json.loads(parsed_output_json))


def parsed_output_to_patch(
    parsed_output: ParsedOutput,
    prompt_input: ZetaPromptInput,
) -> str:
    """Convert structured parsed output into a unified diff patch."""
    return _lib_any.parsed_output_to_patch(
        json.dumps(parsed_output_to_dict(parsed_output)),
        _input_to_json(prompt_input),
    )


def parsed_output_to_dict(parsed_output: ParsedOutput) -> dict:
    """Convert structured parsed output into a JSON-serializable dict."""
    return {
        "new_editable_region": parsed_output.new_editable_region,
        "range_in_excerpt": _range_to_dict(parsed_output.range_in_excerpt),
        "cursor_offset_in_new_editable_region": parsed_output.cursor_offset_in_new_editable_region,
    }


def actual_cursor_from_parsed_output(
    parsed_output: ParsedOutput,
    prompt_input: ZetaPromptInput,
) -> dict | None:
    """Compute actual_cursor from parsed editable-region output."""
    parsed_json = json.dumps(parsed_output_to_dict(parsed_output))
    input_json = _input_to_json(prompt_input)
    result_json = _lib_any.cursor_position(parsed_json, input_json)
    if result_json is None:
        return None
    return json.loads(result_json)


def list_formats() -> list[str]:
    """Return the names of all available ``ZetaFormat`` variants."""
    return _lib_any.list_formats()


def resolve_format(format: str) -> str:
    """Return the full format name for the given format string, if known and unique.

    Raises:
        ValueError: If the format string does not match a unique format.
    """
    return _lib_any.resolve_format(format.removeprefix("zeta2:"))


def stop_tokens(format_str: str) -> list[str]:
    """Return the stop-token strings for the given format."""
    return _lib_any.stop_tokens(format_str)


def token_limits(format_str: str) -> Range:
    """Return ``(editable_tokens, context_tokens)`` for the given format."""
    return _lib_any.token_limits(format_str)


def format_expected_output(
    prompt_input: ZetaPromptInput,
    format_str: str,
    patch: str,
) -> str:
    """Compute the expected model output for training.

    Takes a prompt input, format name, and a patch string (which may contain
    encoded cursor position markers). Returns the formatted output string
    that the model should produce.
    """
    return _lib_any.format_expected_output(
        _input_to_json(prompt_input), format_str, patch
    )


def extract_cursor_from_patch(patch: str) -> tuple[str, int | None]:
    """Extract cursor position from a patch string.

    Returns ``(clean_patch, cursor_offset)`` where ``cursor_offset`` is
    ``None`` if no cursor marker was found in the patch.
    """
    return _lib_any.extract_cursor_from_patch(patch)


def compute_kept_rate(base: str, candidate: str, reference: str) -> KeptRateResult:
    """Compute how much of a candidate edit is kept by a reference edit."""
    return KeptRateResult.from_dict(
        json.loads(_lib_any.compute_kept_rate(base, candidate, reference))
    )


def delta_chr_f(original: str, expected: str, actual: str) -> DeltaChrFMetrics:
    """Compute delta-chrF metrics between expected and actual edits."""
    return DeltaChrFMetrics.from_dict(
        json.loads(_lib_any.delta_chr_f(original, expected, actual))
    )


def delta_chr_f_beta() -> float:
    """Return the beta parameter used by the delta-chrF implementation."""
    return _lib_any.delta_chr_f_beta()


def braces_disbalance(text: str) -> int:
    """Count unmatched brace, bracket, and parenthesis characters."""
    return _lib_any.braces_disbalance(text)


def extract_changed_lines_from_diff(diff: str) -> dict[str, int]:
    """Return a multiset of added and removed lines from a unified diff."""
    return json.loads(_lib_any.extract_changed_lines_from_diff(diff))


def exact_lines_match(
    expected_patch: str,
    actual_patch: str,
) -> ClassificationMetrics:
    """Compare changed lines in two patches as a bag of diff lines."""
    return ClassificationMetrics.from_dict(
        json.loads(_lib_any.exact_lines_match(expected_patch, actual_patch))
    )


def has_isolated_whitespace_changes(
    patch_str: str,
    cursor_row: int | None = None,
) -> bool:
    """Return whether a patch contains isolated whitespace-only changes."""
    return _lib_any.has_isolated_whitespace_changes(patch_str, cursor_row)


def is_editable_region_correct(actual_patch: str) -> bool:
    """Return a heuristic signal for whether a patch respects the editable region."""
    return _lib_any.is_editable_region_correct(actual_patch)


def count_patch_token_changes(patch: str) -> TokenChangeCounts:
    """Count inserted and deleted tokens in a unified diff patch."""
    return TokenChangeCounts.from_dict(
        json.loads(_lib_any.count_patch_token_changes(patch))
    )


def reconstruct_texts_from_diff(patch: str) -> tuple[str, str]:
    """Reconstruct old and new text from a unified diff patch.

    Context and deletion lines form the old text; context and addition
    lines form the new text. Returns ``(old_text, new_text)``.
    """
    return _lib_any.reconstruct_texts_from_diff(patch)


def compute_prediction_reversal_ratio_from_history(
    current_content: str,
    edit_history: list[Event] | list[dict],
    predicted_content: str,
    cursor_path: str,
    excerpt_start_row: int | None = None,
) -> float:
    """Estimate how much a prediction would reverse the latest real edit."""
    return _lib_any.compute_prediction_reversal_ratio_from_history(
        current_content,
        _events_to_json(edit_history),
        predicted_content,
        cursor_path,
        excerpt_start_row,
    )


def score_examples_json(examples_json: str) -> str:
    """Score prediction examples from a JSON string, preserving example fields."""
    return _lib_any.score_examples_json(examples_json)


def evaluation_summary_json(scored_examples_json: str) -> str:
    """Aggregate scored prediction examples from a JSON string."""
    return _lib_any.evaluation_summary_json(scored_examples_json)


def evaluate_examples_json(examples_json: str) -> str:
    """Score and summarize prediction examples from a JSON string."""
    return _lib_any.evaluate_examples_json(examples_json)


def score_examples(examples: list[dict]) -> list[dict]:
    """Score prediction examples, returning examples with a ``score`` field."""
    return json.loads(score_examples_json(json.dumps(examples)))


def evaluation_summary(scored_examples: list[dict]) -> dict:
    """Aggregate scored prediction examples into summary metrics."""
    return json.loads(evaluation_summary_json(json.dumps(scored_examples)))


def evaluate_examples(examples: list[dict]) -> dict:
    """Score examples and return ``{"summary": ..., "per_example": ...}``."""
    return json.loads(evaluate_examples_json(json.dumps(examples)))


# ---- Internal helpers ----


def _range_from_dict(d: dict) -> Range:
    return (d["start"], d["end"])


def _range_to_dict(r: Range) -> dict:
    return {"start": r[0], "end": r[1]}


def _excerpt_ranges_from_dict(d: dict) -> ExcerptRanges:
    def opt_range(key: str) -> Range | None:
        value = d.get(key)
        return _range_from_dict(value) if value is not None else None

    return ExcerptRanges(
        editable_150=_range_from_dict(d["editable_150"]),
        editable_180=_range_from_dict(d["editable_180"]),
        editable_350=_range_from_dict(d["editable_350"]),
        editable_150_context_350=_range_from_dict(d["editable_150_context_350"]),
        editable_180_context_350=_range_from_dict(d["editable_180_context_350"]),
        editable_350_context_150=_range_from_dict(d["editable_350_context_150"]),
        editable_512=opt_range("editable_512"),
        editable_350_context_512=opt_range("editable_350_context_512"),
        editable_350_context_1024=opt_range("editable_350_context_1024"),
        context_4096=opt_range("context_4096"),
        context_8192=opt_range("context_8192"),
    )


def _excerpt_ranges_to_dict(ranges: ExcerptRanges) -> dict:
    result: dict = {
        "editable_150": _range_to_dict(ranges.editable_150),
        "editable_180": _range_to_dict(ranges.editable_180),
        "editable_350": _range_to_dict(ranges.editable_350),
        "editable_150_context_350": _range_to_dict(ranges.editable_150_context_350),
        "editable_180_context_350": _range_to_dict(ranges.editable_180_context_350),
        "editable_350_context_150": _range_to_dict(ranges.editable_350_context_150),
    }
    if ranges.editable_512 is not None:
        result["editable_512"] = _range_to_dict(ranges.editable_512)
    if ranges.editable_350_context_512 is not None:
        result["editable_350_context_512"] = _range_to_dict(
            ranges.editable_350_context_512
        )
    if ranges.editable_350_context_1024 is not None:
        result["editable_350_context_1024"] = _range_to_dict(
            ranges.editable_350_context_1024
        )
    if ranges.context_4096 is not None:
        result["context_4096"] = _range_to_dict(ranges.context_4096)
    if ranges.context_8192 is not None:
        result["context_8192"] = _range_to_dict(ranges.context_8192)
    return result


def _event_to_dict(event: Event | dict) -> dict:
    if isinstance(event, dict):
        return {
            "event": event.get("event", "BufferChange"),
            "path": event["path"],
            "old_path": event["old_path"],
            "diff": event["diff"],
            "predicted": event.get("predicted", False),
            "in_open_source_repo": event.get("in_open_source_repo", False),
        }

    return {
        "event": "BufferChange",
        "path": event.path,
        "old_path": event.old_path,
        "diff": event.diff,
        "predicted": event.predicted,
        "in_open_source_repo": event.in_open_source_repo,
    }


def _events_to_json(events: list[Event] | list[dict]) -> str:
    return json.dumps([_event_to_dict(event) for event in events])


def _input_to_json(prompt_input: ZetaPromptInput) -> str:
    events_list = [_event_to_dict(event) for event in prompt_input.events]

    related_files_list = None
    if prompt_input.related_files is not None:
        related_files_list = [
            {
                "path": rf.path,
                "max_row": rf.max_row,
                "in_open_source_repo": rf.in_open_source_repo,
                "excerpts": [
                    {
                        "row_range": {
                            "start": e.row_range[0],
                            "end": e.row_range[1],
                        },
                        "text": e.text,
                        "order": e.order,
                    }
                    for e in rf.excerpts
                ],
            }
            for rf in prompt_input.related_files
        ]

    diagnostics_list = [
        {
            "severity": d.severity,
            "message": d.message,
            "snippet": d.snippet,
            "snippet_buffer_row_range": {
                "start": d.snippet_buffer_row_range[0],
                "end": d.snippet_buffer_row_range[1],
            },
            "diagnostic_range_in_snippet": {
                "start": d.diagnostic_range_in_snippet[0],
                "end": d.diagnostic_range_in_snippet[1],
            },
        }
        for d in prompt_input.active_buffer_diagnostics
    ]

    syntax_ranges_list = None
    if prompt_input.syntax_ranges is not None:
        syntax_ranges_list = [
            {"start": start, "end": end} for start, end in prompt_input.syntax_ranges
        ]

    data = {
        "cursor_path": prompt_input.cursor_path,
        "cursor_excerpt": prompt_input.cursor_excerpt,
        "cursor_offset_in_excerpt": prompt_input.cursor_offset_in_excerpt,
        "excerpt_ranges": _excerpt_ranges_to_dict(prompt_input.excerpt_ranges),
        "events": events_list,
        "related_files": related_files_list,
        "active_buffer_diagnostics": diagnostics_list,
        "syntax_ranges": syntax_ranges_list,
        "excerpt_start_row": prompt_input.excerpt_start_row,
        "experiment": prompt_input.experiment,
        "in_open_source_repo": prompt_input.in_open_source_repo,
        "can_collect_data": prompt_input.can_collect_data,
        "repo_url": prompt_input.repo_url,
    }

    return json.dumps(data)
