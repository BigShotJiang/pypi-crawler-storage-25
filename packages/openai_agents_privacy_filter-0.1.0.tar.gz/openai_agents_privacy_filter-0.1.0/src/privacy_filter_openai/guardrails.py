"""PII redaction guardrails for OpenAI Agents SDK.

Input guardrail: redacts PII from user messages before agent processing.
Output guardrail: restores original values from placeholders in agent responses.
"""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Any, TypedDict

try:
    from agents import (
        Agent,
        GuardrailFunctionOutput,
        InputGuardrail,
        OutputGuardrail,
        RunContextWrapper,
        input_guardrail,
        output_guardrail,
    )
except ImportError:
    raise ImportError(
        "openai-agents is required. Install with: pip install openai-agents-privacy-filter[openai]"
    )

from privacy_filter import (
    PiiStore,
    extract_text_from_content,
    get_classifier,
    redact_text,
    unredact_text,
)

if TYPE_CHECKING:
    from privacy_filter.types import ClassifierPipeline, Entity

logger: logging.Logger = logging.getLogger(__name__)

# TTL for stored PiiStore entries (seconds)
# Prevents memory leaks if output guardrail never runs
_CONTEXT_TTL_SECONDS: int = 300  # 5 minutes


class _StoreEntry(TypedDict):
    """Internal storage entry with timestamp for TTL-based cleanup."""

    store: PiiStore
    timestamp: float


# Per-run storage for placeholder mappings with TTL
_PIISTORE_CONTEXT: dict[int, _StoreEntry] = {}


def _cleanup_expired_stores() -> None:
    """Remove expired entries from the context storage.

    Called periodically to prevent memory leaks from orphaned entries
    when output guardrails fail to execute.
    """
    now = time.time()
    expired = [
        key
        for key, entry in _PIISTORE_CONTEXT.items()
        if now - entry["timestamp"] > _CONTEXT_TTL_SECONDS
    ]
    for key in expired:
        del _PIISTORE_CONTEXT[key]
        logger.warning("Cleaned up expired PiiStore for context %d", key)


def _get_and_remove_store(context_id: int) -> PiiStore | None:
    """Retrieve and remove a PiiStore for the given context ID.

    Args:
        context_id: The context identifier from id(context).

    Returns:
        The stored PiiStore if found, otherwise None.
    """
    entry = _PIISTORE_CONTEXT.pop(context_id, None)
    return entry["store"] if entry else None


class PiiInputGuardrail:
    """Factory for creating PII input guardrails.

    Usage:
        guardrail = PiiInputGuardrail.create(min_score=0.8)
        agent = Agent(input_guardrails=[guardrail])
    """

    @staticmethod
    def create(
        min_score: float = 0.8,
        entity_types: list[str] | None = None,
        cache_dir: str | None = None,
        run_in_parallel: bool = True,
    ) -> InputGuardrail[Any]:
        """Create an input guardrail that redacts PII from user messages."""

        @input_guardrail(run_in_parallel=run_in_parallel)
        async def _pii_input_guardrail(
            context: RunContextWrapper[Any],
            agent: Agent[Any],
            input_content: str | list[Any],
        ) -> GuardrailFunctionOutput:
            """Redact PII from input content."""
            # Periodic cleanup to prevent memory leaks
            _cleanup_expired_stores()

            # Use shared utility to extract text from various content formats
            if isinstance(input_content, list):
                text = extract_text_from_content(input_content)
            else:
                text = input_content

            store = PiiStore()
            classifier: ClassifierPipeline = get_classifier(cache_dir)
            entities: list[Entity] = classifier(text)
            redacted = redact_text(
                text,
                entities,
                store,
                min_score=min_score,
                entity_types=entity_types,
            )

            # Store the PiiStore for output guardrail to use (with timestamp)
            _PIISTORE_CONTEXT[id(context)] = {
                "store": store,
                "timestamp": time.time(),
            }

            triggered = len(store.forward) > 0
            if triggered:
                logger.debug(
                    "Input guardrail triggered: redacted %d entities",
                    len(store.forward),
                )

            return GuardrailFunctionOutput(
                output_info=redacted,
                tripwire_triggered=triggered,
            )

        return _pii_input_guardrail


class PiiOutputGuardrail:
    """Factory for creating PII output guardrails.

    Usage:
        guardrail = PiiOutputGuardrail.create()
        agent = Agent(output_guardrails=[guardrail])
    """

    @staticmethod
    def create() -> OutputGuardrail[Any]:
        """Create an output guardrail that restores PII from placeholders."""

        @output_guardrail()
        async def _pii_output_guardrail(
            context: RunContextWrapper[Any],
            agent: Agent[Any],
            output_content: Any,
        ) -> GuardrailFunctionOutput:
            """Restore PII in output content."""
            # Get the PiiStore from input guardrail
            store = _get_and_remove_store(id(context))

            # Extract text from output_content (could be string or structured)
            if isinstance(output_content, str):
                text = output_content
            else:
                text = str(output_content)

            if not store or not store.forward:
                return GuardrailFunctionOutput(
                    output_info=text,
                    tripwire_triggered=False,
                )

            unredacted = unredact_text(text, store)
            logger.debug(
                "Output guardrail triggered: restored %d placeholders",
                len(store.forward),
            )

            return GuardrailFunctionOutput(
                output_info=unredacted,
                tripwire_triggered=True,
            )

        return _pii_output_guardrail
