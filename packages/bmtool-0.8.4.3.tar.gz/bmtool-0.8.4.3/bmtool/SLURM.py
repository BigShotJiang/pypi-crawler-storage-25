import copy
import json
import os
import shutil
import subprocess
import time
import uuid

import numpy as np
import requests
import bmtk.simulator.core.simulation_config as bmtk_config


def check_job_status(job_id):
    """
    Checks the status of a SLURM job using scontrol.

    Args:
        job_id (str): The SLURM job ID.

    Returns:
        str: The state of the job.
    """
    try:
        result = subprocess.run(["scontrol", "show", "job", job_id], capture_output=True, text=True)
        if result.returncode != 0:
            # this check is not needed if check_interval is less than 5 min (~300 seconds)
            if "slurm_load_jobs error: Invalid job id specified" in result.stderr:
                return "COMPLETED"  # Treat invalid job ID as completed because scontrol expires and removed job info when done.
            # raise Exception(f"Error checking job status: {result.stderr}")

        job_state = None
        for line in result.stdout.split("\n"):
            if "JobState=" in line:
                job_state = line.strip().split("JobState=")[1].split()[0]
                break

        if job_state is None:
            raise Exception(f"Failed to retrieve job status for job ID: {job_id}")

        return job_state
    except Exception as e:
        print(f"Exception while checking job status: {e}", flush=True)
        return "UNKNOWN"


def submit_job(script_path):
    """
    Submits a SLURM job script.

    Args:
        script_path (str): The path to the SLURM job script.

    Returns:
        str: The job ID of the submitted job.

    Raises:
        Exception: If there is an error in submitting the job.
    """
    result = subprocess.run(["sbatch", script_path], capture_output=True, text=True)
    if result.returncode != 0:
        raise Exception(f"Error submitting job: {result.stderr}")
    job_id = result.stdout.strip().split()[-1]
    return job_id


def send_teams_message(webhook, message):
    """Sends a message to a teams channel or chat

    Args:
        webhook (str): A microsoft teams webhook
        message (str): A message to send in the chat/channel
    """
    message = {"text": f"{message}"}

    # Send POST request to trigger the flow
    response = requests.post(
        webhook,
        json=message,  # Using 'json' instead of 'data' for automatic serialization
        headers={"Content-Type": "application/json"},
    )


class seedSweep:
    def __init__(self, json_file_path, param_name):
        """
        Initializes the seedSweep instance.

        Args:
            json_file_path (str): Path to the JSON file to be updated.
            param_name (str): The name of the parameter to be modified.
        """
        self.json_file_path = json_file_path
        self.param_name = param_name

    def edit_json(self, new_value):
        """
        Updates the JSON file with a new parameter value.

        Args:
            new_value: The new value for the parameter.
        """
        with open(self.json_file_path, "r") as f:
            data = json.load(f)

        data[self.param_name] = new_value

        with open(self.json_file_path, "w") as f:
            json.dump(data, f, indent=4)

        print(
            f"JSON file '{self.json_file_path}' modified successfully with {self.param_name}={new_value}.",
            flush=True,
        )

    def change_json_file_path(self, new_json_file_path):
        self.json_file_path = new_json_file_path


# class could just be added to seedSweep but for now will make new class since it was easier
class multiSeedSweep(seedSweep):
    """
    MultSeedSweeps are centered around some base JSON cell file. When that base JSON is updated, the other JSONs
    change according to their ratio with the base JSON.
    """

    def __init__(self, base_json_file_path, param_name, syn_dict, base_ratio=1):
        """
        Initializes the multipleSeedSweep instance.

        Args:
            base_json_file_path (str): File path for the base JSON file.
            param_name (str): The name of the parameter to be modified.
            syn_dict_list (list): A list containing dictionaries with the 'json_file_path' and 'ratio' (in comparison to the base_json) for each JSON file.
            base_ratio (float): The ratio between the other JSONs; usually the current value for the parameter.
        """
        super().__init__(base_json_file_path, param_name)
        self.syn_dict_for_multi = syn_dict
        self.base_ratio = base_ratio

    def edit_all_jsons(self, new_value):
        """
        Updates the base JSON file with a new parameter value and then updates the other JSON files based on the ratio.

        Args:
            new_value: The new value for the parameter in the base JSON.
        """
        self.edit_json(new_value)
        base_ratio = self.base_ratio

        json_file_path = self.syn_dict_for_multi["json_file_path"]
        new_ratio = self.syn_dict_for_multi["ratio"] / base_ratio

        with open(json_file_path, "r") as f:
            data = json.load(f)
        altered_value = new_ratio * new_value
        data[self.param_name] = altered_value

        with open(json_file_path, "w") as f:
            json.dump(data, f, indent=4)

        print(
            f"JSON file '{json_file_path}' modified successfully with {self.param_name}={altered_value}.",
            flush=True,
        )


class SimulationBlock:
    def __init__(
        self,
        block_name,
        time,
        partition,
        nodes,
        ntasks,
        mem,
        simulation_cases,
        output_base_dir,
        account=None,
        additional_commands=None,
        status_list=["COMPLETED", "FAILED", "CANCELLED"],
        component_path=None,
    ):
        """
        Initializes the SimulationBlock instance.

        Args:
            block_name (str): Name of the block.
            time (str): Time limit for the job.
            partition (str): Partition to submit the job to.
            nodes (int): Number of nodes to request.
            ntasks (int): Number of tasks.
            mem (int) : Number of gigabytes (per node)
            simulation_cases (dict): Dictionary of simulation cases with their commands.
            output_base_dir (str): Base directory for the output files.
            account (str) : account to charge on HPC
            additional commands (list): commands to run before bmtk model starts useful for loading modules
            status_list (list): List of things to check before running next block.
                Adding RUNNING runs blocks faster but uses MUCH more resources and is only recommended on large HPC
        """
        self.block_name = block_name
        self.time = time
        self.partition = partition
        self.nodes = nodes
        self.ntasks = ntasks
        self.mem = mem
        self.simulation_cases = simulation_cases
        self.output_base_dir = output_base_dir
        self.account = account
        self.additional_commands = additional_commands if additional_commands is not None else []
        self.status_list = status_list
        self.job_ids = []
        self.component_path = component_path
        self.run_uuid = str(uuid.uuid4())[:8]

    def create_batch_script(self, case_name, command, config_file=None):
        """
        Creates a SLURM batch script for the given simulation case.

        Args:
            case_name (str): Name of the simulation case.
            command (str): Command to run the simulation.
            config_file (str): Optional path to the config file to use.

        Returns:
            str: Path to the batch script file.
        """
        block_output_dir = os.path.join(
            self.output_base_dir, self.block_name
        )  # Create block-specific output folder
        case_output_dir = os.path.join(
            block_output_dir, case_name
        )  # Create case-specific output folder
        os.makedirs(case_output_dir, exist_ok=True)

        batch_script_path = os.path.join(block_output_dir, f"{case_name}_script.sh")
        additional_commands_str = "\n".join(self.additional_commands)
        # Conditional account linegit
        account_line = f"#SBATCH --account={self.account}\n" if self.account else ""

        # If a specific config file is provided, update the command to use it
        if config_file and config_file in command:
             # command already has config_file
             pass
        elif config_file:
            # this is a bit naive, might need adjustment depending on how command is structured
            parts = command.split()
            for i, part in enumerate(parts):
                if part.endswith(".json"):
                    parts[i] = config_file
                    break
            command = " ".join(parts)

        mem_per_cpu = int(
            np.ceil(int(self.mem) / int(self.ntasks))
        )  # do ceil cause more mem is always better then less

        # Write the batch script to the file
        with open(batch_script_path, "w") as script_file:
            script_file.write(
                f"""#!/bin/bash
#SBATCH --job-name={self.block_name}_{case_name}
#SBATCH --output={block_output_dir}/%x_%j.out
#SBATCH --error={block_output_dir}/%x_%j.err
#SBATCH --time={self.time}
#SBATCH --partition={self.partition}
#SBATCH --nodes={self.nodes}
#SBATCH --ntasks={self.ntasks}
#SBATCH --mem-per-cpu={mem_per_cpu}G
{account_line}

# Additional user-defined commands
{additional_commands_str}

export OUTPUT_DIR={case_output_dir}

{command}
"""
            )

        # print(f"Batch script created: {batch_script_path}", flush=True)

        return batch_script_path

    def submit_block(self, config_files=None):
        """
        Submits all simulation cases in the block as separate SLURM jobs.

        Args:
            config_files (dict): Map of case_name to config_file path.
        """
        for case_name, command in self.simulation_cases.items():
            config_file = config_files.get(case_name) if config_files else None
            script_path = self.create_batch_script(case_name, command, config_file=config_file)
            result = subprocess.run(["sbatch", script_path], capture_output=True, text=True)
            if result.returncode == 0:
                job_id = result.stdout.strip().split()[-1]
                self.job_ids.append(job_id)
                print(f"Submitted {case_name} with job ID {job_id}", flush=True)
            else:
                print(f"Failed to submit {case_name}: {result.stderr}", flush=True)

    def check_block_status(self):
        """
        Checks the status of all jobs in the block.

        Returns:
            bool: True if all jobs in the block are completed, False otherwise.
        """
        for job_id in self.job_ids:
            status = check_job_status(job_id)
            if status not in self.status_list:
                return False
        return True

    def check_block_completed(self):
        """checks if all the jobs in the block have been completed by slurm

        Returns:
            bool: True if all block jobs have been ran, false if job is still running
        """
        for job_id in self.job_ids:
            status = check_job_status(job_id)
            # print(f"status of job is {status}")
            if (
                status != "COMPLETED"
            ):  # can add PENDING here for debugging NOT FOR ACTUALLY USING IT
                return False
        return True

    def check_block_running(self):
        """checks if a job is running

        Returns:
            bool: True if jobs are RUNNING false if anything else
        """
        for job_id in self.job_ids:
            status = check_job_status(job_id)
            if status != "RUNNING":  #
                return False
        return True

    def check_block_submited(self):
        """checks if a job is running

        Returns:
            bool: True if jobs are RUNNING false if anything else
        """
        for job_id in self.job_ids:
            status = check_job_status(job_id)
            if status != "PENDING":  #
                return False
        return True


def get_relative_path(endpoint, absolute_path):
    """Convert absolute path to relative path for Globus transfer."""
    try:
        # Get the directories at the mount point
        result = subprocess.run(
            ["globus", "ls", f"{endpoint}:/"], capture_output=True, text=True, check=True
        )
        dirs = set(result.stdout.splitlines())  # Convert to a set for quicker lookup

        # Split the absolute path into parts
        path_parts = absolute_path.strip("/").split("/")

        # Find the first matching directory in the list
        for i, part in enumerate(path_parts):
            if part + "/" in dirs:
                # The mount point is everything up to and including this directory
                mount_point = "/" + "/".join(path_parts[:i])
                relative_path = absolute_path.replace(mount_point, "", 1).lstrip("/")
                return relative_path

        print("Error: Could not determine relative path.")
        return None
    except subprocess.CalledProcessError as e:
        print(f"Error retrieving directories from Globus: {e}")
        return None


def globus_transfer(source_endpoint, dest_endpoint, source_path, dest_path):
    """
    Transfers file using custom globus transfer function.
    For more info see https://github.com/GregGlickert/transfer-files/blob/main/globus_transfer.sh
    work in progress still... kinda forgot about this
    """
    relative_source_path = get_relative_path(source_endpoint, source_path)
    if relative_source_path is None:
        print("Transfer aborted: Could not determine relative source path.")
        return

    command = f"globus transfer {source_endpoint}:{relative_source_path} {dest_endpoint}:{dest_path} --label 'bmtool slurm transfer'"
    os.system(command)


def get_synaptic_params(path_to_syn_folder):
    """Gets values of all json files and puts them into one list"""
    combined_data = []
    if not os.path.exists(path_to_syn_folder):
        return combined_data
    # List all files in the input folder
    for filename in os.listdir(path_to_syn_folder):
        if filename.endswith(".json"):
            file_path = os.path.join(path_to_syn_folder, filename)

            # Open and read the JSON file
            try:
                with open(file_path, "r") as file:
                    data = json.load(file)
                    # Append the filename and its data
                    combined_data.append({"filename": filename, "data": data})
            except Exception as e:
                print(f"Error reading {file_path}: {e}")
    return combined_data


def save_synaptic_params(data, path_to_output_file):
    """Saves combined json data into one file"""
    os.makedirs(os.path.dirname(path_to_output_file), exist_ok=True)
    with open(path_to_output_file, "w") as output_file:
        json.dump(data, output_file, indent=4)


class BlockRunner:
    """
    Class to handle submitting multiple blocks sequentially.

    Attributes:
        blocks (list): List of SimulationBlock instances to be run.
        json_editor (seedSweep or multiSweep): Instance of seedSweep to edit JSON file.
        param_values (list): List of values for the parameter to be modified.
        webhook (str): a microsoft webhook for teams. When used will send teams messages to the hook!
    """

    def __init__(
        self,
        blocks,
        json_editor=None,
        json_file_path=None,
        param_name=None,
        param_values=None,
        check_interval=60,
        syn_dict=None,
        webhook=None,
    ):
        self.blocks = blocks
        self.json_editor = json_editor
        self.param_values = param_values
        self.check_interval = check_interval
        self.webhook = webhook
        self.param_name = param_name
        self.json_file_path = json_file_path
        self.syn_dict = syn_dict
        # Store original component paths to restore later
        self.original_component_paths = [block.component_path for block in self.blocks]

    def restore_component_paths(self):
        """
        Restores all blocks' component_path to their original values.
        """
        for i, block in enumerate(self.blocks):
            block.component_path = self.original_component_paths[i]
        print("Component paths restored to original values.", flush=True)

    def _archive_block(self, block, config_files, circuit_configs, destination_dir):
        """
        Helper to move files after a block completes.
        Moves cloned components, simulation configs, and circuit configs to the block output directory.
        """
        block_output_dir = os.path.join(block.output_base_dir, block.block_name)
        os.makedirs(block_output_dir, exist_ok=True)

        # Move components directory
        archived_comp_path = os.path.join(block_output_dir, os.path.basename(destination_dir))
        if os.path.exists(destination_dir):
            shutil.move(destination_dir, archived_comp_path)
            print(f"Archived components to {archived_comp_path}", flush=True)

        # Move simulation configs
        for config_path in config_files.values():
            if os.path.exists(config_path):
                shutil.move(config_path, os.path.join(block_output_dir, os.path.basename(config_path)))

        # Move circuit configs
        for c_config_path in circuit_configs.values():
            if os.path.exists(c_config_path):
                shutil.move(c_config_path, os.path.join(block_output_dir, os.path.basename(c_config_path)))

    def submit_blocks_sequentially(self):
        """
        Submits all blocks sequentially, ensuring each block starts only after the previous block has completed.
        """
        for i, block in enumerate(self.blocks):
            source_dir = block.component_path
            destination_dir = os.path.join(os.getcwd(), f"components_{block.run_uuid}")
            shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
            
            config_files = {}
            circuit_configs = {}

            # Keep track of the first circ_data for synaptic report generation
            first_circ_data = None

            for case_name, case_command in block.simulation_cases.items():
                original_sim_config = next((p for p in case_command.split() if p.endswith(".json")), None)
                if not original_sim_config: continue

                # Put duplicate config in same directory as original to preserve relative path resolution
                original_config_dir = os.path.dirname(os.path.abspath(original_sim_config))
                new_sim_path = os.path.join(original_config_dir, f"simulation_config_{block.run_uuid}_{case_name}.json")
                config_files[case_name] = new_sim_path

                with open(original_sim_config, "r") as f:
                    sim_data = json.load(f)

                # Use BMTK's config parser to resolve manifest variables like $BASE_DIR automatically
                resolved_config = bmtk_config.from_json(original_sim_config)
                original_circuit_config = resolved_config.get("network")

                # Generate a unique circuit config for this case
                new_circuit_path = os.path.join(os.getcwd(), f"circuit_config_{block.run_uuid}_{case_name}.json")
                circuit_configs[case_name] = new_circuit_path

                # Clone and update the circuit config for this case
                with open(original_circuit_config, "r") as f:
                    circ_data = json.load(f)

                if first_circ_data is None:
                    first_circ_data = circ_data
                
                circ_data["manifest"]["$COMPONENTS_DIR"] = destination_dir

                with open(new_circuit_path, "w") as f:
                    json.dump(circ_data, f, indent=4)

                sim_data["network"] = new_circuit_path
                
                # Update $OUTPUT_DIR in manifest to the correct block and case directory
                block_case_output = os.path.join(block.output_base_dir, block.block_name, case_name)
                sim_data["manifest"]["$OUTPUT_DIR"] = block_case_output
                os.makedirs(block_case_output, exist_ok=True)
                
                with open(new_sim_path, "w") as f:
                    json.dump(sim_data, f, indent=4)

            # Apply parameter sweeps (once per block/destination_dir) BEFORE generating synaptic report
            if self.json_file_path is not None and self.param_values is not None:
                new_val = self.param_values[i]
                target_json = os.path.join(destination_dir, self.json_file_path)
                if self.syn_dict is None:
                    seedSweep(target_json, self.param_name).edit_json(new_val)
                else:
                    sd_copy = copy.deepcopy(self.syn_dict)
                    sd_copy["json_file_path"] = os.path.join(destination_dir, sd_copy["json_file_path"])
                    multiSeedSweep(target_json, self.param_name, syn_dict=sd_copy, base_ratio=1).edit_all_jsons(new_val)
            
            # Generate synaptic report (once per block) AFTER parameter sweeps for accuracy
            syn_models_rel = first_circ_data["components"]["synaptic_models_dir"].replace("$COMPONENTS_DIR/", "")
            syn_data = get_synaptic_params(os.path.join(destination_dir, syn_models_rel))
            block_output_dir = os.path.join(block.output_base_dir, block.block_name)
            os.makedirs(block_output_dir, exist_ok=True)
            save_synaptic_params(syn_data, os.path.join(block_output_dir, f"synaptic_report_{block.run_uuid}.json"))

            print(f"Submitting block: {block.block_name}", flush=True)

            print(f"Submitting block: {block.block_name}", flush=True)
            block.submit_block(config_files=config_files)

            if self.webhook:
                send_teams_message(self.webhook, f"Submitted {block.block_name}. {len(self.blocks)-1-i} remaining.")

            while not block.check_block_status():
                time.sleep(self.check_interval)

            self._archive_block(block, config_files, circuit_configs, destination_dir)

        self.restore_component_paths()
        if self.webhook:
            send_teams_message(self.webhook, "Simulations complete.")

    def submit_blocks_parallel(self):
        """
        Submits all blocks to the queue simultaneously and archives them as they finish.
        """
        active_trackers = [] # List of (block, config_files, circuit_configs, destination_dir)

        for i, block in enumerate(self.blocks):
            source_dir = block.component_path
            destination_dir = os.path.join(os.getcwd(), f"components_{block.run_uuid}")
            shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
            
            config_files = {}
            circuit_configs = {}

            # Keep track of the first circ_data for synaptic report generation
            first_circ_data = None

            for case_name, case_command in block.simulation_cases.items():
                original_sim_config = next((p for p in case_command.split() if p.endswith(".json")), None)
                if not original_sim_config: continue

                # Put duplicate config in same directory as original to preserve relative path resolution
                original_config_dir = os.path.dirname(os.path.abspath(original_sim_config))
                new_sim_path = os.path.join(original_config_dir, f"simulation_config_{block.run_uuid}_{case_name}.json")
                config_files[case_name] = new_sim_path

                with open(original_sim_config, "r") as f:
                    sim_data = json.load(f)

                # Use BMTK's config parser to resolve manifest variables like $BASE_DIR automatically
                resolved_config = bmtk_config.from_json(original_sim_config)
                original_circuit_config = resolved_config.get("network")

                # Generate a unique circuit config for this case
                new_circuit_path = os.path.join(os.getcwd(), f"circuit_config_{block.run_uuid}_{case_name}.json")
                circuit_configs[case_name] = new_circuit_path

                # Clone and update the circuit config for this case
                with open(original_circuit_config, "r") as f:
                    circ_data = json.load(f)

                if first_circ_data is None:
                    first_circ_data = circ_data
                
                circ_data["manifest"]["$COMPONENTS_DIR"] = destination_dir

                with open(new_circuit_path, "w") as f:
                    json.dump(circ_data, f, indent=4)

                sim_data["network"] = new_circuit_path
                
                # Update $OUTPUT_DIR in manifest to the correct block and case directory
                block_case_output = os.path.join(block.output_base_dir, block.block_name, case_name)
                sim_data["manifest"]["$OUTPUT_DIR"] = block_case_output
                os.makedirs(block_case_output, exist_ok=True)
                
                with open(new_sim_path, "w") as f:
                    json.dump(sim_data, f, indent=4)

            # Apply parameter sweeps (once per block/destination_dir) BEFORE generating synaptic report
            if self.json_file_path is not None and self.param_values is not None:
                target_json = os.path.join(destination_dir, self.json_file_path)
                if self.syn_dict is None:
                    seedSweep(target_json, self.param_name).edit_json(self.param_values[i])
                else:
                    sd_copy = copy.deepcopy(self.syn_dict)
                    sd_copy["json_file_path"] = os.path.join(destination_dir, sd_copy["json_file_path"])
                    multiSeedSweep(target_json, self.param_name, syn_dict=sd_copy, base_ratio=1).edit_all_jsons(self.param_values[i])
            
            # Generate synaptic report (once per block) AFTER parameter sweeps for accuracy
            syn_models_rel = first_circ_data["components"]["synaptic_models_dir"].replace("$COMPONENTS_DIR/", "")
            syn_data = get_synaptic_params(os.path.join(destination_dir, syn_models_rel))
            block_output_dir = os.path.join(block.output_base_dir, block.block_name)
            os.makedirs(block_output_dir, exist_ok=True)
            save_synaptic_params(syn_data, os.path.join(block_output_dir, f"synaptic_report_{block.run_uuid}.json"))

            block.submit_block(config_files=config_files)
            active_trackers.append((block, config_files, circuit_configs, destination_dir))

        while active_trackers:
            for tracker in active_trackers[:]:
                block, cfgs, c_cfgs, d_dir = tracker
                if block.check_block_status():
                    self._archive_block(block, cfgs, c_cfgs, d_dir)
                    active_trackers.remove(tracker)
            time.sleep(self.check_interval)

        self.restore_component_paths()
        if self.webhook:
            send_teams_message(self.webhook, "All parallel blocks complete.")
