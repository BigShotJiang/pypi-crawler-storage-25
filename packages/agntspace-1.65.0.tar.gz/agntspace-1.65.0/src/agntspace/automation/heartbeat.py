"""Heartbeat: periodic background loop that checks state and logs observations.

Every pulse is recorded to SQLite for the cardiogram time series.
Deviations (blocked tasks, overdue items, errors) are flagged.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import UTC, datetime
from typing import TYPE_CHECKING

import aiosqlite

from agntspace.automation.heartbeat_pacing import PacingDecision, compute_sleep

if TYPE_CHECKING:
    from agntspace.agent.orchestrator import Orchestrator
    from agntspace.journal.service import JournalService
    from agntspace.tasks.service import TaskService

log = logging.getLogger(__name__)


class Heartbeat:
    """15-minute background loop that monitors state and logs to journal.

    Every pulse is persisted to SQLite so the UI can render a cardiogram.
    """

    def __init__(
        self,
        journal: JournalService,
        task_service: TaskService,
        db: aiosqlite.Connection | None = None,
        interval_seconds: int = 900,
        llm: object | None = None,
        goal_pursuit_seconds: int | None = None,
    ) -> None:
        self._journal = journal
        self._task_service = task_service
        self._db = db
        self._interval = interval_seconds
        # Goal pursuit cadence is independent of heartbeat cadence so the
        # heartbeat can run fast (responsiveness) while goal pursuit stays
        # deliberate. ``None`` means "match the heartbeat interval" — same
        # behavior as before the split.
        self._goal_pursuit_interval = (
            goal_pursuit_seconds if goal_pursuit_seconds is not None else interval_seconds
        )
        self._last_goal_pursuit_at: datetime | None = None
        self._llm = llm  # LLM provider for connectivity checks
        self._work_queue: object | None = None  # Set post-init by main.py
        self._orchestrator: Orchestrator | None = None  # Set post-init by main.py
        self._skill_loader: object | None = None  # Set post-init; owns pacing config
        self._settings: object | None = None  # Set post-init; owns timezone
        self._coach: object | None = None  # Set post-init; for active-goal count signal
        self._last_pacing: PacingDecision | None = None  # For get_status()
        self._task: asyncio.Task | None = None  # type: ignore[type-arg]
        self._running = False
        # Memory monitor — chunk 4 of the 2026-05-05 reliability session.
        # Lazy-constructed on first tick so heartbeat can be instantiated
        # in tests without setup overhead. Set to a real MemoryMonitor
        # the first time _do_run_once runs; subsequent ticks reuse.
        self._memory_monitor: object | None = None
        self._last_memory_snapshot: object | None = None  # For get_status()

    async def init_schema(self) -> None:
        """Create heartbeat tables if they don't exist."""
        if not self._db:
            return
        await self._db.executescript("""
            CREATE TABLE IF NOT EXISTS heartbeat_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts TEXT NOT NULL,
                pulse_type TEXT NOT NULL DEFAULT 'heartbeat',
                status TEXT NOT NULL DEFAULT 'normal',
                observations INTEGER NOT NULL DEFAULT 0,
                active_tasks INTEGER NOT NULL DEFAULT 0,
                blocked_tasks INTEGER NOT NULL DEFAULT 0,
                overdue_tasks INTEGER NOT NULL DEFAULT 0,
                details TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_heartbeat_ts ON heartbeat_log(ts);
        """)
        # Add pulse_type column if upgrading from older schema
        try:
            await self._db.execute("SELECT pulse_type FROM heartbeat_log LIMIT 1")
        except Exception:
            await self._db.execute("ALTER TABLE heartbeat_log ADD COLUMN pulse_type TEXT NOT NULL DEFAULT 'heartbeat'")
        await self._db.commit()

    def start(self) -> None:
        """Start the heartbeat background loop."""
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._loop())
        log.debug("Heartbeat started (interval: %ds)", self._interval)

    def stop(self) -> None:
        """Stop the heartbeat background loop."""
        self._running = False
        if self._task:
            self._task.cancel()
            self._task = None
        log.debug("Heartbeat stopped")

    async def record_pulse(
        self,
        pulse_type: str,
        details: str | None = None,
        status: str | None = None,
    ) -> None:
        """Record any agent activity as a pulse on the cardiogram.

        Pulse types:
        - heartbeat: regular 15-min check (automatic)
        - chat: agent responded to a message
        - tool_use: agent used a tool (email, vault, task, etc.)
        - automation: briefing, EOD, reflection, memory generation
        - channel: handled a channel message
        - cron: cron job executed
        - error: LLM failure, integration error, etc. (auto-deviation)
        - startup: server startup pulse
        """
        if not self._db:
            return
        # Error pulses are always deviations
        if status is None:
            status = "deviation" if pulse_type == "error" else "normal"
        now = datetime.now(UTC).isoformat()
        try:
            await self._db.execute(
                "INSERT INTO heartbeat_log (ts, pulse_type, status, observations, active_tasks, blocked_tasks, overdue_tasks, details) "
                "VALUES (?, ?, ?, 0, 0, 0, 0, ?)",
                (now, pulse_type, status, details),
            )
            await self._db.commit()
        except Exception:
            log.debug("Failed to record %s pulse", pulse_type, exc_info=True)

    @property
    def is_running(self) -> bool:
        return self._running

    async def run_once(self) -> list[str]:
        """Run a single heartbeat cycle. Returns list of observations logged.

        Opens a ``heartbeat-*`` correlation scope so every observation,
        LLM health check, and outreach dispatched from this cycle
        shares one causal chain id in /decisions (Rule #17 Tier B).
        """
        from agntspace.activity.decisions import (
            correlation_scope,
            new_correlation_id,
        )

        with correlation_scope(new_correlation_id("heartbeat")):
            return await self._do_run_once()

    async def _do_run_once(self) -> list[str]:
        """Internal heartbeat body — caller owns the correlation scope."""
        # Pre-authorize contract actions that internal heartbeat paths need
        # when they write to the vault. The heartbeat runs as a background
        # worker (Tier B), so no API route or agent tool has already gated
        # these checks for us — we declare them upfront so
        # CoachService.record_block / set_pursuit_status (which write with
        # contract_action="create_task") pass the VaultWriter runtime guard.
        # Before this, every goal-block write under the heartbeat scope
        # raised ContractBypassError because only proactive_outreach was
        # authorized. `create_task` covers goal/task file writes; the
        # others cover goal pursuit bookkeeping + milestone updates.
        try:
            from agntspace.activity.decisions import mark_actions_authorized
            mark_actions_authorized([
                "create_task",
                "modify_project",
                "proactive_outreach",
                "write_vault",
            ])
        except Exception:  # noqa: BLE001 — auth pre-stamp is opportunistic
            log.debug("heartbeat pre-authorize failed", exc_info=True)

        observations: list[str] = []
        now = datetime.now(UTC)
        now_str = now.strftime("%H:%M")

        # Memory snapshot — log RSS at every tick. Threshold crossings
        # produce visible log lines AND (for the ceiling case) trigger
        # graceful shutdown via record_shutdown_reason + SIGINT. Failure
        # is fully isolated — broken monitor must NEVER break heartbeat.
        try:
            mem_obs = self._check_memory()
            if mem_obs:
                observations.append(mem_obs)
        except Exception:  # noqa: BLE001
            log.debug("memory_monitor: heartbeat check failed", exc_info=True)

        active_count = 0
        blocked_count = 0
        overdue_count = 0

        # Check tasks
        try:
            tasks = self._task_service.list_tasks()
            blocked = [t for t in tasks if t.get("status") == "blocked"]
            in_review = [t for t in tasks if t.get("status") == "review"]
            active = [t for t in tasks if t.get("status") == "in_progress"]

            active_count = len(active)
            blocked_count = len(blocked)

            if blocked:
                names = ", ".join(t.get("title", "?") for t in blocked)
                observations.append(f"Heartbeat: {len(blocked)} blocked task(s): {names}")

            if in_review:
                names = ", ".join(t.get("title", "?") for t in in_review)
                observations.append(f"Heartbeat: {len(in_review)} task(s) awaiting review: {names}")

            if active:
                observations.append(f"Heartbeat: {len(active)} task(s) in progress")

        except Exception:
            log.debug("Heartbeat: task check failed", exc_info=True)

        # Check for overdue tasks
        try:
            tasks = self._task_service.list_tasks()
            today = now.strftime("%Y-%m-%d")
            for t in tasks:
                due = t.get("due", "")
                if due and due < today and t.get("status") not in ("done", "cancelled"):
                    overdue_count += 1
                    observations.append(f"Heartbeat: task '{t.get('title', '?')}' is overdue (due: {due})")
        except Exception:
            pass

        # Check LLM connectivity and update work queue health
        llm_error = None
        if self._llm:
            try:
                from agntspace.llm.base import Message as LLMMessage

                await self._llm.complete(
                    messages=[LLMMessage(role="user", content="ping")],
                    system="Reply with exactly: pong",
                    max_tokens=10,
                    temperature=0,
                )
                # LLM is healthy — notify work queue to drain pending jobs
                if self._work_queue and hasattr(self._work_queue, "set_llm_health"):
                    model_name = getattr(self._llm, "model_name", getattr(self._llm, "_model", ""))
                    self._work_queue.set_llm_health(True, model=model_name)
            except Exception as exc:
                llm_error = str(exc)
                log.info("Heartbeat: LLM check failed: %s", llm_error)

                # If local/Ollama mode, try to auto-start Ollama before giving up
                _model = getattr(self._llm, "_model", "") or ""
                if _model.startswith("ollama/") or _model.startswith("ollama_chat/"):
                    from agntspace.llm.ollama_discovery import ensure_ollama_running
                    if ensure_ollama_running():
                        # Ollama is back — retry the health check once
                        try:
                            await self._llm.complete(
                                messages=[LLMMessage(role="user", content="ping")],
                                system="Reply with exactly: pong",
                                max_tokens=10,
                                temperature=0,
                            )
                            llm_error = None  # recovered
                            if self._work_queue and hasattr(self._work_queue, "set_llm_health"):
                                model_name = getattr(self._llm, "model_name", getattr(self._llm, "_model", ""))
                                self._work_queue.set_llm_health(True, model=model_name)
                            observations.append("Heartbeat: Ollama auto-started and recovered")
                        except Exception:
                            pass  # still failing — fall through to unhealthy

                if llm_error:
                    observations.append(f"Heartbeat: LLM unreachable — {llm_error}")
                    # Mark LLM unhealthy — work queue will defer jobs
                    if self._work_queue and hasattr(self._work_queue, "set_llm_health"):
                        self._work_queue.set_llm_health(False)

        # Determine status
        if llm_error or overdue_count > 0 or blocked_count > 0:
            status = "deviation"
        else:
            status = "normal"

        # Log observations to agent file
        for obs in observations:
            try:
                self._journal.append_observation(obs)
            except Exception:
                log.debug("Heartbeat: failed to log observation", exc_info=True)

        # Record pulse to SQLite
        if self._db:
            details = "; ".join(observations) if observations else None
            try:
                await self._db.execute(
                    "INSERT INTO heartbeat_log (ts, pulse_type, status, observations, active_tasks, blocked_tasks, overdue_tasks, details) "
                    "VALUES (?, 'heartbeat', ?, ?, ?, ?, ?, ?)",
                    (now.isoformat(), status, len(observations), active_count, blocked_count, overdue_count, details),
                )
                await self._db.commit()
            except Exception:
                log.debug("Heartbeat: failed to record pulse", exc_info=True)

        if observations:
            log.info("Heartbeat: %d observations logged (%s)", len(observations), status)
        else:
            log.debug("Heartbeat: pulse at %s — normal", now_str)

        # ── Rule #17 learning loop: SkillSchool zero-effect analysis ──
        # On every heartbeat cycle, check the decision log for skills
        # that produced zero-effect outcomes and surface them as action
        # plan proposals. This is the feedback channel between the
        # zero-effect detector (Agent.invoke_skill) and the tuner.
        if hasattr(self, "_skillschool") and self._skillschool:
            try:
                proposals = await self._skillschool.analyze_zero_effects()
                if proposals:
                    log.info("SkillSchool: %d zero-effect proposals from heartbeat", len(proposals))
                    # Write proposals to the persistent action plan so they
                    # appear in the Simulate/Agents page UI alongside health
                    # check issues. The user sees "Skill 'kb-ingest' had N
                    # zero-effect failures — upgrade tier or add examples."
                    try:
                        from agntspace.agent.action_plan import (
                            append_action_plan_items,
                            skillschool_proposals_to_plan_items,
                        )
                        plan_items = skillschool_proposals_to_plan_items(proposals)
                        vault_dir = getattr(self, "_vault_dir", None)
                        if vault_dir and plan_items:
                            added = await append_action_plan_items(vault_dir, plan_items)
                            if added:
                                log.info("SkillSchool: %d item(s) added to action plan", added)
                    except Exception:
                        log.debug("SkillSchool: action plan write failed", exc_info=True)
                    # Also emit as activity events for the agent's world model
                    if hasattr(self, "_activity") and self._activity:
                        for p in proposals[:5]:
                            self._activity.log(
                                "system", "skill_tune_proposal",
                                p.get("what", "zero-effect skill detected"),
                                p,
                                importance="high" if p.get("severity") == "high" else "medium",
                            )
            except Exception:
                log.debug("SkillSchool analyze_zero_effects failed", exc_info=True)

            # ── Reply-signal analysis — capability hallucinations ──
            # Same flow as zero-effect: SkillSchool reads decision log
            # rows written by reply_guardrails.py, groups by capability,
            # proposes skill tunings. Handlers never mutate replies;
            # this is the learning loop that closes the gap.
            try:
                reply_proposals = await self._skillschool.analyze_reply_signals()
                if reply_proposals:
                    log.info(
                        "SkillSchool: %d reply-signal proposals from heartbeat",
                        len(reply_proposals),
                    )
                    try:
                        from agntspace.agent.action_plan import (
                            append_action_plan_items,
                            skillschool_proposals_to_plan_items,
                        )
                        plan_items = skillschool_proposals_to_plan_items(reply_proposals)
                        vault_dir = getattr(self, "_vault_dir", None)
                        if vault_dir and plan_items:
                            added = await append_action_plan_items(vault_dir, plan_items)
                            if added:
                                log.info(
                                    "SkillSchool: %d reply-signal item(s) added to action plan",
                                    added,
                                )
                    except Exception:
                        log.debug("SkillSchool: reply-signal action plan write failed", exc_info=True)
                    if hasattr(self, "_activity") and self._activity:
                        for p in reply_proposals[:5]:
                            self._activity.log(
                                "system", "skill_tune_proposal",
                                p.get("what", "capability hallucination detected"),
                                p,
                                importance="high" if p.get("severity") == "high" else "medium",
                            )
            except Exception:
                log.debug("SkillSchool analyze_reply_signals failed", exc_info=True)

        # ── Evolution mining (Phase 2 pattern extractor) ──
        # Enqueue a daily mining job that scans accumulated runs, clusters
        # them by (skill, caller, agent, tier), and proposes Reflex /
        # AntiReflex candidates. Deduplicate=True means the work queue
        # collapses bursty enqueues into a single pending job. Throttled
        # by mtime on `_last_evolution_mine` so we don't enqueue every
        # heartbeat — once per configured schedule_interval_hours.
        evolution = getattr(self, "_evolution", None)
        if evolution is not None and self._work_queue is not None:
            try:
                import time as _t
                cfg = evolution.config or {}
                mining_cfg = cfg.get("mining", {}) if isinstance(cfg, dict) else {}
                if bool(mining_cfg.get("enabled", True)):
                    interval_hours = float(mining_cfg.get("schedule_interval_hours", 24))
                    last_ts = getattr(self, "_last_evolution_mine", 0.0)
                    now_t = _t.time()
                    if now_t - last_ts >= interval_hours * 3600:
                        await self._work_queue.enqueue(
                            "evolution_mine_reflexes",
                            {"source": "heartbeat"},
                            deduplicate=True,
                        )
                        self._last_evolution_mine = now_t
                        log.info(
                            "Enqueued evolution_mine_reflexes (interval=%.1fh)",
                            interval_hours,
                        )
            except Exception:
                log.debug("Evolution mining enqueue failed", exc_info=True)

        # ── Anomaly detection (daily sweep) ──
        # Walks verified txns in the YAML-configured window, evaluates
        # the 5 default rules, fires activity events on flags. Throttled
        # to once per ``cooldown_hours`` via _last_anomaly_scan to keep
        # 15-min ticks cheap. Per-(txn_id, rule_name) cooldown lives
        # inside the detector itself.
        anomaly_detector = getattr(self, "_anomaly_detector", None)
        if anomaly_detector is not None:
            try:
                import time as _t
                # Read cadence from the same YAML the detector uses;
                # default 24h matches "daily" per the skill design.
                # Reading via the detector's own config helper keeps
                # the heartbeat from duplicating YAML knowledge.
                cfg = anomaly_detector._load_config()  # noqa: SLF001
                hb_cfg = cfg.get("heartbeat") or {}
                if bool(hb_cfg.get("enabled", True)):
                    cadence_hours = float(hb_cfg.get("cadence_hours", 24))
                    last_ts = getattr(self, "_last_anomaly_scan", 0.0)
                    now_t = _t.time()
                    if now_t - last_ts >= cadence_hours * 3600:
                        result = await anomaly_detector.scan()
                        self._last_anomaly_scan = now_t
                        if result.get("flags"):
                            log.info(
                                "Anomaly detector: flagged %d transaction(s) (window=%dd)",
                                result["flags"], result.get("window_days", 30),
                            )
            except Exception:
                log.debug("Anomaly detector scan failed", exc_info=True)

        # ── Budget threshold alerts ──
        # Closes the "user has to open /finance/budgets to see they hit
        # 95%" gap. Engine substrate at finance/budget_alerts.py reads
        # budget-track/config/thresholds.yaml and fires activity events
        # on transitions UP a band (on_track → near_cap → at_cap →
        # over_cap). First scan baselines silently; cooldown is per-
        # budget. No throttle here — scan is cheap (constant time per
        # budget) and the per-budget cooldown is the real rate-limit.
        budget_alerter = getattr(self, "_budget_alerter", None)
        if budget_alerter is not None:
            try:
                result = await budget_alerter.scan()
                if result.get("alerts"):
                    log.info(
                        "Budget alerter: fired %d threshold alert(s)",
                        result["alerts"],
                    )
            except Exception:
                log.debug("Budget alerter scan failed", exc_info=True)

        # ── Graph curator — entity-dedup auto-apply (Tier-B) ──
        # Closes the "100+ comma-prefix duplicates piling up in the
        # review queue" gap. Strategy lives in
        # _meta/graph-curator/config/curator.yaml; the engine reads
        # cadence_hours and throttles via _last_graph_curator_run.
        # Default cadence is 24h so a heartbeat tick every 15 min stays
        # cheap. Disabled in YAML → service short-circuits.
        graph_curator = getattr(self, "_graph_curator", None)
        if graph_curator is not None:
            try:
                import time as _t
                cfg = graph_curator.config()
                if bool(cfg.get("enabled", False)):
                    cadence_hours = float(cfg.get("cadence_hours", 24))
                    last_ts = getattr(self, "_last_graph_curator_run", 0.0)
                    now_t = _t.time()
                    if now_t - last_ts >= cadence_hours * 3600:
                        result = await graph_curator.auto_apply(
                            caller="heartbeat",
                            source="agent_curator",
                        )
                        self._last_graph_curator_run = now_t
                        applied = result.get("applied", 0)
                        if applied:
                            log.info(
                                "Graph curator: auto-applied %d duplicate "
                                "merges (rules=%s)",
                                applied,
                                ",".join(result.get("rules", [])),
                            )
                        else:
                            log.debug(
                                "Graph curator: nothing to apply (%s)",
                                result.get("reason", "ok"),
                            )
            except Exception:
                log.debug("Graph curator auto-apply failed", exc_info=True)

        # ── Editor quality pass — full lint + reflect + consolidate (Option B) ──
        # Closes the "editor not in the loop" gap from 2026-04-28.
        # Watcher's structural-only auto-lint (Option A) catches the
        # deterministic 95% on every compile. The remaining 5% — semantic
        # merge candidates, contradictions between articles, decision
        # records, append-only-drift consolidation — needs an LLM and
        # belongs on a throttled cadence (default 24h) so we don't spend
        # tokens on every single-file ingest.
        # Strategy in _meta/editor-quality-pass/config/schedule.yaml.
        kb_service_for_quality = getattr(self, "_kb_service", None)
        skill_loader = getattr(kb_service_for_quality, "_skill_loader", None) if kb_service_for_quality else None
        if kb_service_for_quality is not None and skill_loader is not None:
            try:
                cfg = skill_loader.load_skill_config_file(
                    "editor-quality-pass", "schedule.yaml",
                ) or {}
                if bool(cfg.get("enabled", True)):
                    cadence_hours = max(1.0, float(cfg.get("cadence_hours", 24)))
                    last_ts = getattr(self, "_last_editor_quality_run", 0.0)
                    import time as _t_eq
                    now_t = _t_eq.time()
                    # Phase 0.5 (2026-05-04) — back off if the work
                    # queue is busy. The editor pass is the most
                    # expensive heartbeat-driven sweep (lint + reflect +
                    # consolidate + repair_classifications, each up to
                    # 180 s). Running it concurrently with an in-flight
                    # compile would starve foreground request-handling.
                    # Defer one tick — cadence resets on the next
                    # heartbeat cycle.
                    load_gate = getattr(self, "_load_gate", None)
                    if load_gate is not None and await load_gate.is_busy():
                        log.debug(
                            "Editor quality pass: deferring (load gate busy)",
                        )
                    elif now_t - last_ts >= cadence_hours * 3600:
                        max_kbs = int(cfg.get("max_kbs_per_pass", 5))
                        per_kb_timeout = float(cfg.get("per_kb_timeout_seconds", 180))
                        include_reflect = bool(cfg.get("include_reflect", True))
                        include_consolidate = bool(cfg.get("include_consolidate", True))
                        try:
                            kbs = kb_service_for_quality.list_kbs()
                        except Exception:
                            kbs = []
                        # Bound the work — multi-KB vaults catch up over
                        # subsequent ticks rather than burning a 30-min
                        # heartbeat on a single cycle.
                        for kb_info in (kbs or [])[:max_kbs]:
                            kb_slug = kb_info.get("slug") if isinstance(kb_info, dict) else getattr(kb_info, "slug", "")
                            if not kb_slug:
                                continue
                            # Each phase is independent — one failure
                            # doesn't abort the other phases for this KB
                            # or block subsequent KBs.
                            try:
                                await asyncio.wait_for(
                                    kb_service_for_quality.lint(kb_slug),  # full pass
                                    timeout=per_kb_timeout,
                                )
                            except TimeoutError:
                                log.warning(
                                    "Editor quality pass: lint timed out for KB %s after %ds",
                                    kb_slug, int(per_kb_timeout),
                                )
                            except Exception:
                                log.debug("Editor quality pass: lint failed for KB %s", kb_slug, exc_info=True)
                            if include_reflect:
                                try:
                                    await asyncio.wait_for(
                                        kb_service_for_quality.reflect(kb_slug),
                                        timeout=per_kb_timeout,
                                    )
                                except TimeoutError:
                                    log.warning(
                                        "Editor quality pass: reflect timed out for KB %s",
                                        kb_slug,
                                    )
                                except Exception:
                                    log.debug("Editor quality pass: reflect failed for KB %s", kb_slug, exc_info=True)
                            if include_consolidate and hasattr(kb_service_for_quality, "consolidate_articles"):
                                try:
                                    await asyncio.wait_for(
                                        kb_service_for_quality.consolidate_articles(kb_slug),
                                        timeout=per_kb_timeout,
                                    )
                                except TimeoutError:
                                    log.warning(
                                        "Editor quality pass: consolidate timed out for KB %s",
                                        kb_slug,
                                    )
                                except Exception:
                                    log.debug(
                                        "Editor quality pass: consolidate failed for KB %s",
                                        kb_slug, exc_info=True,
                                    )
                            # Phase 7b (2026-04-30) — repair_classifications.
                            # Fixes the "Renewcell tagged as entity_type=person"
                            # class. Owned semantically by the philosopher
                            # (epistemic auditing) but invoked here because
                            # editor-quality-pass already has the per-KB
                            # throttle + cadence + timeout machinery. Idempotent
                            # — re-running on a clean KB is a no-op.
                            if (
                                bool(cfg.get("include_repair_classifications", True))
                                and hasattr(kb_service_for_quality, "repair_classifications")
                            ):
                                rc_limit = int(
                                    cfg.get("repair_classifications_limit", 200),
                                )
                                try:
                                    await asyncio.wait_for(
                                        kb_service_for_quality.repair_classifications(
                                            slug=kb_slug, dry_run=False, limit=rc_limit,
                                        ),
                                        timeout=per_kb_timeout,
                                    )
                                except TimeoutError:
                                    log.warning(
                                        "Editor quality pass: repair_classifications "
                                        "timed out for KB %s after %ds",
                                        kb_slug, int(per_kb_timeout),
                                    )
                                except Exception:
                                    log.debug(
                                        "Editor quality pass: repair_classifications "
                                        "failed for KB %s",
                                        kb_slug, exc_info=True,
                                    )
                        self._last_editor_quality_run = now_t
                        log.info(
                            "Editor quality pass: completed for %d KB(s)",
                            min(len(kbs or []), max_kbs),
                        )
            except Exception:
                log.debug("Editor quality pass scheduling failed", exc_info=True)

        # ── Taxonomy orphan detector — propose missing L2/L3 nodes ──
        # Closes the eyes-mouth gap in the taxonomy evolution loop:
        # when articles cluster on `taxonomy_path` values the YAML tree
        # doesn't know about, automatically propose those nodes via the
        # existing taxonomy_proposals approval queue. Pure frontmatter
        # scan + path math — no LLM. Cadence + threshold from
        # _meta/taxonomy-orphan-detect/config/orphan.yaml (Rule 12).
        orphan_detector = getattr(self, "_taxonomy_orphan_detector", None)
        if orphan_detector is not None:
            try:
                import time as _t2
                if orphan_detector.enabled:
                    cadence_hours = float(orphan_detector.cadence_hours or 24)
                    last_ts = getattr(self, "_last_orphan_detector_run", 0.0)
                    now_t = _t2.time()
                    # Phase 0.5 (2026-05-04) — back off when busy.
                    # The detector is cheap (no LLM) but its FS walk
                    # competes with foreground request handlers for
                    # I/O during heavy ingest cycles. Defer.
                    load_gate = getattr(self, "_load_gate", None)
                    if load_gate is not None and await load_gate.is_busy():
                        log.debug("Taxonomy orphan detector: deferring (load gate busy)")
                    elif now_t - last_ts >= cadence_hours * 3600:
                        result = await orphan_detector.detect_and_propose()
                        self._last_orphan_detector_run = now_t
                        proposals = result.get("proposals_written", 0)
                        if proposals:
                            log.info(
                                "Taxonomy orphan detector: %d new proposal(s) "
                                "from %d cluster(s) — review at /api/wiki/taxonomy/proposals",
                                proposals,
                                result.get("clusters_found", 0),
                            )
                        else:
                            log.debug(
                                "Taxonomy orphan detector: %d cluster(s), "
                                "%d skipped (already pending)",
                                result.get("clusters_found", 0),
                                result.get("skipped_dedup", 0),
                            )
            except Exception:
                log.debug("Taxonomy orphan detector failed", exc_info=True)

        # ── Capability-gap detectors (Rule 21 follow-throughs) ──
        # Three sibling detectors close the eyes-mouth-inbox loop for
        # the three gaps Rule 21 names: missing tools, missing agent
        # ownership, missing contract-action mappings. Each is pure
        # registry + skill + YAML scan — no LLM, no log analysis.
        # Cadence + thresholds from each detector's
        # _meta/missing-*-detect/config/detect.yaml (Rule 12).
        for attr_name, label in (
            ("_missing_contract_action_detector", "Missing-contract-action"),
            ("_missing_tool_detector", "Missing-tool"),
            ("_missing_agent_detector", "Missing-agent"),
            ("_skill_completeness_detector", "Skill-completeness"),
        ):
            detector = getattr(self, attr_name, None)
            if detector is None:
                continue
            try:
                import time as _t3
                if not detector.enabled:
                    continue
                cadence_hours = float(detector.cadence_hours or 24)
                last_ts_attr = f"_last_{attr_name}_run"
                last_ts = getattr(self, last_ts_attr, 0.0)
                now_t = _t3.time()
                if now_t - last_ts < cadence_hours * 3600:
                    continue
                result = await detector.detect_and_propose()
                setattr(self, last_ts_attr, now_t)
                proposals = result.get("proposals_written", 0)
                if proposals:
                    log.info(
                        "%s detector: %d new proposal(s) — review at /proposals",
                        label, proposals,
                    )
                else:
                    log.debug(
                        "%s detector: 0 written, %d skipped",
                        label, result.get("skipped_dedup", 0),
                    )
            except Exception:
                log.debug("%s detector failed", label, exc_info=True)

        # ── Stale-claim re-research (P3.7 smart add #8) ──
        # Heartbeat picks ONE stale ``(as of YYYY-MM)`` marker per day,
        # fires `research_topic` against it, and lands a Rule 21
        # ``research_update`` proposal so the user can review the
        # fresh dossier. Master switch off by default — the manual
        # `GET /api/research/stale-claims` scanner ships first; users
        # opt in to the autonomous loop once they trust the picks.
        # Strategy in ``_meta/research-perplexity/config/perplexity.yaml``
        # under the ``stale_claim:`` block; engine reads it via
        # ``StaleClaimResearcher.config()``.
        stale_researcher = getattr(self, "_stale_claim_researcher", None)
        if stale_researcher is not None:
            try:
                # Throttle is enforced inside ``run_once_if_due`` via
                # cadence_hours + the instance's own ``_last_run_ts``.
                # We still consult the load gate here so the loop
                # defers when foreground work is heavy — the
                # `_exec_research_topic` call hits Perplexity over the
                # network so it's I/O-bound + not GIL-blocking, but
                # the dossier write + mention indexer DO compete with
                # active ingest cycles for the writer lock.
                load_gate = getattr(self, "_load_gate", None)
                if load_gate is not None and await load_gate.is_busy():
                    log.debug("Stale-claim researcher: deferring (load gate busy)")
                else:
                    result = await stale_researcher.run_once_if_due()
                    status = result.get("status", "unknown") if isinstance(result, dict) else "unknown"
                    if status == "ok":
                        log.info(
                            "Stale-claim researcher: re-researched %s "
                            "(marker %s, age %dmo, cost $%.4f, proposal %s)",
                            result.get("article_path", "?"),
                            result.get("marker_label", "?"),
                            int(result.get("age_months", 0) or 0)
                            if isinstance(result.get("age_months"), int | float)
                            else 0,
                            float(result.get("cost_usd", 0.0)),
                            result.get("proposal_id", ""),
                        )
                    elif status not in ("disabled", "deferred", "no_candidates"):
                        log.debug(
                            "Stale-claim researcher: status=%s details=%s",
                            status, result,
                        )
            except Exception:
                log.debug("Stale-claim researcher failed", exc_info=True)

        # ── Version update check (uses 6h cache — no PyPI spam) ──
        try:
            from agntspace.api.routes.health import (
                _check_pypi_latest,
                _get_version,
                _parse_version,
            )
            current = _get_version()
            if current != "dev":
                latest = await _check_pypi_latest()
                if latest and _parse_version(latest) > _parse_version(current):
                    if hasattr(self, "_activity") and self._activity:
                        self._activity.log(
                            "system", "update_available",
                            f"AgntSpace v{latest} is available (running v{current})",
                            {"current": current, "latest": latest},
                            importance="medium",
                        )
        except Exception:
            pass

        # ── Proactive outreach (silence check, important event alerts) ──
        if hasattr(self, "_outreach") and self._outreach:
            try:
                _agent = getattr(self, "_agent", None)
                await self._outreach.check_and_reach_out(agent=_agent)
            except Exception:
                log.debug("Proactive outreach failed", exc_info=True)

        # ── Agent insights generation (proactive awareness) ──
        insights_engine = getattr(self, "_insights_engine", None)
        if insights_engine:
            try:
                snapshot = await insights_engine.generate()
                warning_count = len([i for i in snapshot.insights if i.severity == "warning"])
                if warning_count:
                    observations.append(
                        f"Agent insights: {warning_count} warning(s), "
                        f"{len(snapshot.insights) - warning_count} suggestion(s)"
                    )
            except Exception:
                log.debug("Insights generation failed", exc_info=True)

        # ── Autonomous pipeline triggers (agent-first KB health) ──
        try:
            pipeline_obs = await self._check_autonomous_pipelines()
            observations.extend(pipeline_obs)
        except Exception:
            log.debug("Autonomous pipeline check failed", exc_info=True)

        # ── Phase 2 (2026-04-30) — work-queue zombie reclaim ──
        # Sweep ``state='running'`` rows whose worker died (heartbeat went
        # stale). Without this, ``counts.running`` lies forever on the
        # dashboard AND per-KB asyncio locks held by dead workers stay
        # locked. Best-effort — failures NEVER block other heartbeat work.
        if self._work_queue and hasattr(self._work_queue, "reclaim_zombies"):
            try:
                summary = await self._work_queue.reclaim_zombies()  # type: ignore[attr-defined]
                if summary.get("scanned", 0) > 0:
                    observations.append(
                        f"Reclaimed {summary['scanned']} zombie work-queue row(s) "
                        f"({summary['reclaimed']} retried, "
                        f"{summary['dead_lettered']} dead-lettered)"
                    )
            except Exception:
                log.debug("Work queue zombie reclaim failed", exc_info=True)

        # ── Autonomous goal pursuit (staggered 30s after other checks) ──
        # Throttled independently of the heartbeat cadence: the heartbeat
        # can tick every 5 min for responsiveness while pursuit keeps its
        # deliberate 15-min spacing (configurable via
        # ``schedule.goal_pursuit_seconds``). Skipping without consuming
        # the 30s stagger keeps fast-tick heartbeats cheap.
        coach = getattr(self, "_coach", None)
        if coach:
            should_run = True
            if self._last_goal_pursuit_at is not None:
                elapsed = (now - self._last_goal_pursuit_at).total_seconds()
                should_run = elapsed >= self._goal_pursuit_interval
            if should_run:
                try:
                    import asyncio as _aio
                    await _aio.sleep(30)  # stagger to avoid LLM contention with outreach

                    # Sprint α-bis (2026-05-09): defer goal pursuit when the
                    # user is actively interacting. Goal pursuit dispatches
                    # subagents that make heavy LLM calls (~6 min on local
                    # qwen2.5:14b for the loudest goals); without the gate,
                    # a chat turn arriving mid-dispatch queues behind it on
                    # Ollama. With the gate, pursuit defers to the next
                    # heartbeat tick — the user gets the local LLM,
                    # pursuit runs at night.
                    deferred = False
                    monitor = getattr(self, "_user_activity_monitor", None)
                    activity = getattr(self, "_activity", None)

                    # Sprint α-bis-2: emit started event so the frontend
                    # toaster can show a sticky progress toast while pursuit
                    # runs. Skipped when deferred (no work happened).
                    started_emitted = False

                    async def _pursue_with_progress() -> list[str]:
                        """Wrap pursuit with started/completed/failed events
                        so the front-end progress toast lights up."""
                        nonlocal started_emitted
                        if activity is not None:
                            try:
                                activity.log(
                                    category="performance",
                                    action="heartbeat_goal_pursuit_started",
                                    summary="Pursuing active goals",
                                    details={},
                                    importance="low",
                                )
                                started_emitted = True
                            except Exception:
                                log.debug(
                                    "heartbeat: started event failed",
                                    exc_info=True,
                                )
                        try:
                            obs = await self._pursue_active_goals()
                        except Exception as exc:
                            if activity is not None and started_emitted:
                                try:
                                    activity.log(
                                        category="performance",
                                        action="heartbeat_goal_pursuit_failed",
                                        summary="Goal pursuit failed",
                                        details={"error": str(exc)[:240]},
                                        importance="low",
                                    )
                                except Exception:
                                    log.debug(
                                        "heartbeat: failed event failed",
                                        exc_info=True,
                                    )
                            raise
                        if activity is not None and started_emitted:
                            try:
                                activity.log(
                                    category="performance",
                                    action="heartbeat_goal_pursuit_completed",
                                    summary="Goal pursuit completed",
                                    details={
                                        "observations_count": len(obs or []),
                                    },
                                    importance="low",
                                )
                            except Exception:
                                log.debug(
                                    "heartbeat: completed event failed",
                                    exc_info=True,
                                )
                        return obs

                    if monitor is not None:
                        try:
                            from agntspace.infra.scheduling import defer_if_active
                            goal_obs = await defer_if_active(
                                "heartbeat_goal_pursuit",
                                _pursue_with_progress,
                                monitor=monitor,
                                activity_logger=activity,
                            )
                            # defer_if_active returns None when work was
                            # deferred. Mark deferred so we DON'T advance
                            # _last_goal_pursuit_at — the next tick should
                            # re-consider as soon as user becomes idle.
                            if goal_obs is None:
                                deferred = True
                                goal_obs = []
                        except Exception:
                            log.debug("Goal pursuit gate failed", exc_info=True)
                            goal_obs = await _pursue_with_progress()
                    else:
                        goal_obs = await _pursue_with_progress()

                    observations.extend(goal_obs or [])
                    # Only advance the timestamp when pursuit actually
                    # ran. Deferred ticks intentionally leave the
                    # timestamp untouched so the next heartbeat tick
                    # re-evaluates immediately once the user goes idle,
                    # rather than waiting another full goal_pursuit
                    # interval.
                    if not deferred:
                        self._last_goal_pursuit_at = datetime.now(UTC)
                except Exception:
                    log.debug("Goal pursuit check failed", exc_info=True)

        return observations

    async def _check_autonomous_pipelines(self) -> list[str]:
        """Auto-trigger KB ingest/compile when the agent notices pending work.

        This is a key agent-first behavior: the agent doesn't wait for
        the user to click "Run Pipeline" — it notices files in the inbox
        and acts on them autonomously.
        """
        observations: list[str] = []
        kb_service = getattr(self, "_kb_service", None)
        wq = getattr(self, "_work_queue", None)
        if not kb_service or not wq:
            return observations

        # Check each KB for pending inbox files
        try:
            kbs = kb_service.list_knowledge_bases()
        except Exception:
            return observations

        for kb in kbs:
            slug = kb.get("slug", "")
            if not slug:
                continue

            # Check inbox for files that the watcher might have missed
            # (e.g., files added while server was down)
            try:
                inbox_files = kb_service._reader.list_files(
                    f"knowledge/{slug}/inbox", "*"
                )
                # Exclude both legacy ``.quarantine`` and visible ``quarantine``
                # subdirs from the pending count — ingest never re-tries those
                # automatically; user must restore via /pipeline.
                _norm = lambda p: str(p).replace("\\", "/")  # noqa: E731
                pending = [
                    f for f in inbox_files
                    if "/.quarantine/" not in _norm(f)
                    and "/quarantine/" not in _norm(f)
                    and not f.name.startswith(".")
                    and f.stat().st_size > 0
                ]
                if len(pending) > 0:
                    # Enqueue ingest job — deduplicate so we don't spam
                    job_id = await wq.enqueue(
                        "ingest",
                        {"slug": slug, "source": "heartbeat_auto"},
                        deduplicate=True,
                    )
                    if job_id:
                        observations.append(
                            f"Auto-triggered ingest for KB '{slug}' "
                            f"({len(pending)} file(s) pending)"
                        )
                        if hasattr(self, "_activity") and self._activity:
                            self._activity.log(
                                "knowledge", "auto_ingest_triggered",
                                f"Agent auto-triggered ingest for '{slug}' — {len(pending)} files pending",
                                {"kb_slug": slug, "file_count": len(pending)},
                                importance="medium",
                            )
            except Exception:
                pass

        return observations

    def _is_local_mode(self) -> bool:
        """True when running against a local LLM (Ollama). Used for budget
        gating — local mode has zero dollar cost so only the dispatch cap
        and futility gate are meaningful."""
        from agntspace.infra.config import get_settings
        try:
            return get_settings().llm.mode == "local"
        except Exception:
            return False

    async def _pursue_active_goals(self) -> list[str]:
        """Iterate pursuable goals and dispatch the first one that passes all gates.

        A single blocked goal (e.g. trust too low) no longer starves the rest
        of the queue — we record the block reason on the goal (so the UI can
        explain it) and try the next one. Still max 1 dispatch per tick to
        prevent parallel budget drain.

        Budget gating is mode-aware:
        - **Dispatch cap** (``max_dispatches``) — always enforced.
        - **Dollar budget** — cloud mode only (local models cost $0).
        - **Futility gate** (``max_attempts``) — always enforced by
          ``get_pursuable_goals``.
        - **Trust gate** — bypassable per goal via ``trust_override: true``.
        """
        observations: list[str] = []
        coach = getattr(self, "_coach", None)
        wq = getattr(self, "_work_queue", None)
        if not coach or not wq:
            return observations

        try:
            pursuable = coach.get_pursuable_goals()
        except Exception:
            log.debug("Failed to get pursuable goals", exc_info=True)
            return observations

        if not pursuable:
            return observations

        for goal in pursuable:
            outcome, obs = await self._try_pursue_goal(goal)
            if obs:
                observations.append(obs)
            if outcome == "dispatched":
                break
        return observations

    async def _try_pursue_goal(self, goal: dict) -> tuple[str, str | None]:
        """Run gate checks for one goal and enqueue it when all pass.

        Returns ``(outcome, observation)`` where outcome is one of
        ``"dispatched" | "blocked" | "error"``. Blocked goals have their
        last-block reason recorded on the goal file so the UI can explain
        the halt; dispatched goals clear that marker.
        """
        coach = getattr(self, "_coach", None)
        wq = getattr(self, "_work_queue", None)
        cost = getattr(self, "_cost_tracker", None)
        activity = getattr(self, "_activity", None)
        trust_svc = getattr(self, "_trust_service", None)
        contract = getattr(self, "_contract", None)
        if not coach or not wq:
            return "error", None

        slug = goal["slug"]
        title = goal.get("title", slug)
        budget = goal["budget"]
        consumed = goal["budget_consumed"]
        dispatches = goal.get("dispatches", 0)
        max_dispatches = goal.get("max_dispatches", 50)
        trust_override = bool(goal.get("trust_override", False))
        goal_domain = goal.get("domain", "general")
        local_mode = self._is_local_mode()

        def _record_block(reason: str, details: dict, *, importance: str = "medium", event_action: str = "goal_pursuit_blocked", event_category: str = "trust") -> None:
            try:
                coach.record_block(slug, reason, details)
            except Exception:
                log.debug("record_block failed for %s", slug, exc_info=True)
            if activity:
                try:
                    activity.log(
                        event_category, event_action,
                        f"Goal '{slug}' pursuit blocked: {reason}",
                        {"goal_slug": slug, **details},
                        importance=importance,
                    )
                except Exception:
                    log.debug("activity.log failed", exc_info=True)

        # Gate 0: trust level (bypassable per goal via trust_override).
        # Uses check_goal_trust so the goal's own domain drives the gate
        # (not a derived action domain), and the slug carries per-goal
        # evidence so feedback on goal A doesn't shift goal B in the same
        # domain. New goals with no direct signals fall back to the domain
        # aggregate — identical behavior to the pre-per-goal world until
        # goal-specific evidence accumulates.
        if trust_svc and not trust_override:
            proactivity = contract.rules.proactivity if contract else "advisor"
            trust_check = trust_svc.check_goal_trust(
                goal_domain, proactivity, is_autonomous=True, goal_key=slug,
            )
            from agntspace.trust.service import _TRUST_LEVEL_INDEX
            effective_idx = _TRUST_LEVEL_INDEX.get(trust_check.effective_level, 0)
            if effective_idx < 2:  # Below Assistant
                _record_block(
                    "trust_too_low",
                    {
                        "domain": goal_domain,
                        "effective_level": trust_check.effective_level,
                        "domain_trust": trust_check.domain_trust,
                        "proactivity": proactivity,
                        "effective_score": getattr(trust_check, "effective_score", None),
                        "goal_key": slug,
                    },
                )
                return "blocked", (
                    f"Goal '{title}' halted: trust too low in '{goal_domain}' "
                    f"(have {trust_check.effective_level}, need Assistant)"
                )

        # Gate 1: dispatch cap (universal — works in ALL modes)
        if dispatches >= max_dispatches:
            reason = f"Dispatch limit reached ({dispatches}/{max_dispatches})"
            _record_block(
                "dispatch_limit",
                {"dispatches": dispatches, "max_dispatches": max_dispatches},
                importance="high",
                event_action="goal_pursuit_paused",
                event_category="system",
            )
            try:
                coach.set_pursuit_status(slug, "paused", reason=reason)
            except Exception:
                log.debug("set_pursuit_status failed for %s", slug, exc_info=True)
            return "blocked", f"Goal '{title}' paused: {reason}"

        # Gate 2: dollar budget (cloud mode only — local is free).
        # Gap 7 fix: budget == 0 means "no cap set" (the default for goals
        # created without a budget). Skip the check entirely — the
        # dispatch cap is the real gate in that case. Users who want a
        # dollar cap set budget > 0 explicitly.
        if not local_mode and cost and budget > 0:
            try:
                check = await cost.check_goal_budget(slug, budget)
                if not check["allowed"]:
                    _record_block(
                        "budget_exhausted",
                        {"spent": check.get("spent"), "budget": budget},
                        importance="high",
                        event_action="goal_pursuit_paused",
                        event_category="system",
                    )
                    try:
                        coach.set_pursuit_status(slug, "paused", reason="Budget exhausted")
                    except Exception:
                        log.debug("set_pursuit_status failed", exc_info=True)
                    return "blocked", (
                        f"Goal '{title}' budget exhausted "
                        f"(${check['spent']:.2f} / ${budget:.2f})"
                    )
            except Exception:
                log.debug("Goal budget check failed for %s", slug, exc_info=True)

        if local_mode:
            budget_remaining_str = f"local mode (free), dispatch {dispatches + 1}/{max_dispatches}"
        else:
            budget_remaining_str = f"${budget - consumed:.2f} remaining, dispatch {dispatches + 1}/{max_dispatches}"

        # Enqueue pursuit job
        try:
            job_id = await wq.enqueue(
                "pursue_goal",
                {
                    "goal_slug": slug,
                    "goal_title": title,
                    "goal_metric": goal.get("success_metric", ""),
                    "budget_remaining": budget - consumed,
                    "dispatch_number": dispatches + 1,
                    "max_dispatches": max_dispatches,
                    "local_mode": local_mode,
                },
                deduplicate=True,
            )
        except Exception:
            log.debug("Failed to enqueue goal pursuit for %s", slug, exc_info=True)
            return "error", None

        if job_id:
            try:
                coach.clear_block(slug)
            except Exception:
                log.debug("clear_block failed for %s", slug, exc_info=True)
            return "dispatched", (
                f"Dispatched pursuit of goal '{title}' ({budget_remaining_str})"
            )
        return "blocked", f"Goal '{title}' pursuit already queued"

    def _check_memory(self) -> str | None:
        """Run one memory-monitor tick and return an observation string.

        Returns None on OK / NO_DATA (silent), the threshold-crossing
        message otherwise. The observation is appended to the heartbeat's
        log for that tick — visible in /api/activity and the cardiogram.

        Lazy-constructs the monitor on first call so existing tests that
        instantiate Heartbeat without monitor wiring keep working. The
        ceiling callback is the standard one (record_shutdown_reason +
        SIGINT) — see infra/memory_monitor.py for design rationale.

        Never raises — caller's outer except still catches anything that
        slips through, but each subsystem boundary has its own guard.
        """
        try:
            from agntspace.infra.memory_monitor import (
                MemoryAction,
                MemoryMonitor,
                MemoryMonitorConfig,
                default_ceiling_callback,
            )

            if self._memory_monitor is None:
                # First tick — load YAML config + wire the standard ceiling
                # callback. Strategy lives in
                # _meta/memory-monitor/config/limits.yaml (Rule 12). Fail-soft:
                # any error reading or parsing the YAML falls back to the
                # deterministic _DEFAULT_*_MB constants in memory_monitor.py.
                config = MemoryMonitorConfig()
                if self._skill_loader is not None:
                    try:
                        block = self._skill_loader.load_skill_config_file(
                            "memory-monitor", "limits.yaml",
                        )
                        if block:
                            config = MemoryMonitorConfig.from_yaml_block(block)
                    except Exception:
                        log.debug(
                            "memory_monitor: YAML load failed, using defaults",
                            exc_info=True,
                        )
                self._memory_monitor = MemoryMonitor(
                    on_ceiling_exceeded=default_ceiling_callback,
                    config=config,
                )

            snapshot = self._memory_monitor.check()  # type: ignore[union-attr]
            self._last_memory_snapshot = snapshot

            if snapshot.action == MemoryAction.OK:
                # Log every tick at DEBUG so a quiet day still shows the
                # RSS trajectory. Production log level swallows DEBUG by
                # default; troubleshooting can flip it on.
                if snapshot.rss_mb is not None:
                    log.debug("Heartbeat: memory %.0f MB (ok)", snapshot.rss_mb)
                return None

            if snapshot.action == MemoryAction.NO_DATA:
                return None  # Platform doesn't support RSS reading; silent.

            if snapshot.action == MemoryAction.WARN_CROSSED:
                msg = (
                    f"Heartbeat: memory crossed warn threshold "
                    f"({snapshot.rss_mb:.0f} MB > {snapshot.crossed_threshold_mb} MB)"
                )
                log.info(msg)
                return msg

            if snapshot.action == MemoryAction.ALARM_CROSSED:
                msg = (
                    f"Heartbeat: memory crossed alarm threshold "
                    f"({snapshot.rss_mb:.0f} MB > {snapshot.crossed_threshold_mb} MB) "
                    f"— consider restarting before the ceiling is reached"
                )
                log.warning(msg)
                return msg

            if snapshot.action == MemoryAction.CEILING_EXCEEDED:
                msg = (
                    f"Heartbeat: memory ceiling exceeded "
                    f"({snapshot.rss_mb:.0f} MB > {snapshot.crossed_threshold_mb} MB) "
                    f"— graceful shutdown initiated via SIGINT"
                )
                log.error(msg)
                return msg

        except Exception:  # noqa: BLE001
            log.debug("memory_monitor: _check_memory failed", exc_info=True)

        return None

    async def get_history(self, hours: int = 24, limit: int = 200) -> list[dict]:
        """Get heartbeat history for the cardiogram chart."""
        if not self._db:
            return []
        from datetime import timedelta

        cutoff = (datetime.now(UTC) - timedelta(hours=hours)).isoformat()
        cursor = await self._db.execute(
            "SELECT ts, pulse_type, status, observations, active_tasks, blocked_tasks, overdue_tasks "
            "FROM heartbeat_log WHERE ts >= ? ORDER BY ts DESC LIMIT ?",
            (cutoff, limit),
        )
        rows = await cursor.fetchall()
        return [
            {
                "ts": row[0],
                "pulse_type": row[1],
                "status": row[2],
                "observations": row[3],
                "active_tasks": row[4],
                "blocked_tasks": row[5],
                "overdue_tasks": row[6],
            }
            for row in reversed(rows)  # chronological order
        ]

    async def get_deviations(self, limit: int = 50) -> list[dict]:
        """Get recent deviations (non-normal pulses)."""
        if not self._db:
            return []
        cursor = await self._db.execute(
            "SELECT ts, status, observations, blocked_tasks, overdue_tasks, details "
            "FROM heartbeat_log WHERE status != 'normal' ORDER BY ts DESC LIMIT ?",
            (limit,),
        )
        rows = await cursor.fetchall()
        return [
            {
                "ts": row[0],
                "status": row[1],
                "observations": row[2],
                "blocked_tasks": row[3],
                "overdue_tasks": row[4],
                "details": row[5],
            }
            for row in rows
        ]

    async def get_status(self) -> dict:
        """Get current heartbeat status summary."""
        last_pulse = None
        total_pulses = 0
        total_deviations = 0

        if self._db:
            cursor = await self._db.execute(
                "SELECT ts, status FROM heartbeat_log ORDER BY ts DESC LIMIT 1"
            )
            row = await cursor.fetchone()
            if row:
                last_pulse = {"ts": row[0], "status": row[1]}

            cursor = await self._db.execute("SELECT COUNT(*) FROM heartbeat_log")
            total_pulses = (await cursor.fetchone())[0]

            cursor = await self._db.execute(
                "SELECT COUNT(*) FROM heartbeat_log WHERE status != 'normal'"
            )
            total_deviations = (await cursor.fetchone())[0]

        # Include active dispatches from orchestrator
        active_dispatches: dict[str, str] = {}
        if self._orchestrator:
            try:
                active_dispatches = self._orchestrator.get_active_dispatches()
            except Exception:
                pass

        # Goal-pursuit ETA is independent of heartbeat ETA when the two
        # intervals differ. Callers (goals API route, UI) should prefer
        # this block over the heartbeat last_pulse when reporting "when
        # will this goal potentially dispatch" because that's actually
        # what the user is asking about in the pursuit panel.
        goal_pursuit_block: dict = {
            "interval_seconds": self._goal_pursuit_interval,
            "last_pursuit_at": None,
            "next_pursuit_at": None,
        }
        if self._last_goal_pursuit_at is not None:
            from datetime import timedelta
            last_iso = self._last_goal_pursuit_at.isoformat()
            next_dt = self._last_goal_pursuit_at + timedelta(
                seconds=self._goal_pursuit_interval
            )
            goal_pursuit_block["last_pursuit_at"] = last_iso
            goal_pursuit_block["next_pursuit_at"] = next_dt.isoformat()

        # Pacing block — reports the LAST resolved decision so the UI can
        # explain why the next tick is when it is. "disabled" reason means
        # pacing is off and the base interval is in effect (legacy behavior).
        pacing_block: dict = {
            "enabled": False,
            "base_seconds": self._interval,
            "effective_seconds": self._interval,
            "reason": "disabled",
            "multiplier": 1.0,
        }
        if self._last_pacing is not None:
            cfg = self._pacing_config()
            pacing_block = {
                "enabled": bool(cfg and cfg.get("enabled")),
                "base_seconds": self._interval,
                "effective_seconds": self._last_pacing.seconds,
                "reason": self._last_pacing.reason,
                "multiplier": self._last_pacing.multiplier,
            }

        return {
            "running": self._running,
            "interval_seconds": self._interval,
            "goal_pursuit_interval_seconds": self._goal_pursuit_interval,
            "last_pulse": last_pulse,
            "total_pulses": total_pulses,
            "total_deviations": total_deviations,
            "active_dispatches": active_dispatches,
            "goal_pursuit": goal_pursuit_block,
            "pacing": pacing_block,
        }

    def _seconds_until_next_slot(self) -> float:
        """Calculate seconds until the next clock-aligned slot.

        With a 15-minute interval, pulses land on :00, :15, :30, :45.
        With a 30-minute interval, pulses land on :00, :30.
        """
        now = datetime.now(UTC)
        interval_min = self._interval // 60 or 1
        current_min = now.minute
        next_slot = ((current_min // interval_min) + 1) * interval_min
        seconds_into_minute = now.second + now.microsecond / 1_000_000
        wait = (next_slot - current_min) * 60 - seconds_into_minute
        if wait <= 0:
            wait += self._interval
        return wait

    def _now_local(self) -> datetime:
        """Current time in the user's local timezone (naive datetime).

        Falls back to system local time when ScheduleSettings.timezone
        isn't set or parsing fails. Never raises.
        """
        tz_name = ""
        try:
            if self._settings and hasattr(self._settings, "schedule"):
                tz_name = getattr(self._settings.schedule, "timezone", "") or ""
        except Exception:
            tz_name = ""

        if tz_name:
            try:
                from zoneinfo import ZoneInfo
                return datetime.now(ZoneInfo(tz_name)).replace(tzinfo=None)
            except Exception:
                log.debug("Pacing: invalid timezone %r, falling back to system local", tz_name)

        # System local time — works on every platform.
        return datetime.now()

    def _pacing_signals(self) -> dict:
        """Live signals consumed by the pacing decision function.

        Counts are best-effort — pacing falls through to base on any
        error so a broken signal source never blocks the heartbeat.
        """
        pending = 0
        active_goals = 0

        if self._work_queue is not None:
            try:
                status = getattr(self._work_queue, "status", None)
                if callable(status):
                    wq_status = status()
                    # Both dict and sync-only shapes have a 'pending' key.
                    if isinstance(wq_status, dict):
                        pending = int(wq_status.get("pending", 0) or 0)
            except Exception:
                pending = 0

        if self._coach is not None:
            try:
                goals = getattr(self._coach, "list_goals", None)
                if callable(goals):
                    all_goals = goals() or []
                    active_goals = sum(
                        1 for g in all_goals
                        if isinstance(g, dict) and g.get("pursuit_status") == "pursuing"
                    )
            except Exception:
                active_goals = 0

        return {"pending_queue": pending, "active_goals": active_goals}

    def _pacing_config(self) -> dict | None:
        """Load the pacing block from the heartbeat-pulse skill YAML.

        Returns None when the skill loader isn't wired or the skill isn't
        installed — the engine treats None as 'pacing disabled', which
        matches pre-pacing behavior exactly.
        """
        if self._skill_loader is None:
            return None
        try:
            cfg = self._skill_loader.get_skill_config("heartbeat-pulse", None)
        except TypeError:
            # Older SkillLoader signatures require a specific block name.
            try:
                cfg = self._skill_loader.get_skill_config("heartbeat-pulse", "pacing")
                return cfg if isinstance(cfg, dict) else None
            except Exception:
                return None
        except Exception:
            return None

        if not isinstance(cfg, dict):
            return None
        # Accept either the whole skill dict (with a 'pacing:' block) or
        # the pacing block directly — get_skill_config has varied over time.
        return cfg.get("pacing", cfg) if isinstance(cfg.get("pacing"), dict) else cfg

    def _resolve_sleep(self) -> PacingDecision:
        """Compute the next sleep duration, with adaptive pacing if enabled.

        When pacing is off or not configured, returns the clock-aligned
        base sleep so legacy behavior is preserved exactly. When on,
        consults `compute_sleep()` with live signals + the user's local
        time + the YAML config.
        """
        cfg = self._pacing_config()
        if not cfg or not cfg.get("enabled"):
            # Clock-aligned base (legacy behavior).
            wait = self._seconds_until_next_slot()
            decision = PacingDecision(
                seconds=wait,
                reason="base",
                multiplier=1.0,
            )
            self._last_pacing = decision
            return decision

        decision = compute_sleep(
            base_seconds=float(self._interval),
            now_local=self._now_local(),
            cfg=cfg,
            signals=self._pacing_signals(),
        )
        self._last_pacing = decision
        return decision

    async def _loop(self) -> None:
        """Main heartbeat loop — pulses with adaptive pacing when configured.

        When pacing is disabled (default), pulses land on clean clock
        boundaries (e.g. :00, :15, :30, :45). When enabled, sleep duration
        is determined by the pacing decision function, which may slow the
        loop in quiet hours or speed it up when work is pending.
        """
        # Immediate pulse on startup, then defer to pacing.
        try:
            await self.run_once()
        except Exception:
            log.exception("Heartbeat startup pulse failed")

        decision = self._resolve_sleep()
        log.debug(
            "Heartbeat: next pulse in %.0fs (reason=%s, x%.2f)",
            decision.seconds, decision.reason, decision.multiplier,
        )
        await asyncio.sleep(decision.seconds)

        while self._running:
            try:
                await self.run_once()
            except asyncio.CancelledError:
                break
            except Exception:
                log.exception("Heartbeat error")
            decision = self._resolve_sleep()
            await asyncio.sleep(decision.seconds)
