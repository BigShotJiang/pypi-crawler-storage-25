"""
Tests for conversation history integrity fixes:

1. Gemini thought_signature preservation: Ensures original Content from Gemini
   responses is stored in history rather than reconstructed Parts that lose
   thought_signature and thought flags.

2. Anthropic tool_use_id consistency: Ensures tool_result blocks always reference
   valid tool_use IDs from the preceding assistant message.
"""

import json
import uuid
from typing import Any, Dict, List, Optional
from unittest.mock import MagicMock, AsyncMock, patch

import pytest
from google.genai import types

from em_agent_framework.core.agent import Agent, FunctionCallWithId
from em_agent_framework.core.models.anthropic_provider import AnthropicProvider
from em_agent_framework.core.models.provider import ProviderResponse


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_tool_use_id() -> str:
    return f"toolu_{uuid.uuid4().hex[:24]}"


def _make_fc_with_id(name: str, args: dict, tool_id: str):
    """Create a FunctionCallWithId (like Claude produces)."""
    raw = MagicMock()
    raw.id = tool_id
    raw.name = name
    raw.input = args
    return FunctionCallWithId(name=name, args=args, id=tool_id, raw=raw)


# ===========================================================================
# Anthropic: _convert_history_to_anthropic_format  &  _merge_and_validate
# ===========================================================================

class TestAnthropicToolUseIdConsistency:
    """
    Verify that tool_result.tool_use_id always matches a tool_use.id
    in the preceding assistant message after conversion.
    """

    @pytest.fixture
    def provider(self):
        """Create a minimal AnthropicProvider (client is mocked)."""
        with patch("em_agent_framework.core.models.anthropic_provider.AnthropicVertex"):
            from em_agent_framework.config.settings import ModelConfig
            mc = ModelConfig(name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=10)
            p = AnthropicProvider(
                model_config=mc,
                system_instruction="test",
                project_id="test-project",
                location="us-east5",
            )
        return p

    # ----- basic round-trip ---------------------------------------------------

    def test_basic_tool_call_and_result_ids_match(self, provider):
        """
        A single tool_use → tool_result round-trip should produce matching IDs.
        """
        tool_id = _make_tool_use_id()
        fc = _make_fc_with_id("my_func", {"x": 1}, tool_id)

        history = [
            types.Content(role="user", parts=[types.Part(text="do something")]),
            types.Content(role="model", parts=[types.Part(function_call=fc)]),
        ]

        # Create function response with stored id
        fr = types.FunctionResponse(name="my_func", response={"result": "ok"})
        fr.id = tool_id
        history.append(types.Content(role="user", parts=[types.Part(function_response=fr)]))

        messages = provider._convert_history_to_anthropic_format(history)

        # Find the assistant message with tool_use
        assistant_msg = next(m for m in messages if m["role"] == "assistant")
        tool_use_blocks = [
            b for b in (assistant_msg["content"] if isinstance(assistant_msg["content"], list) else [])
            if isinstance(b, dict) and b.get("type") == "tool_use"
        ]

        # Find the user message with tool_result
        user_msgs_with_results = [
            m for m in messages
            if m["role"] == "user" and isinstance(m.get("content"), list)
            and any(isinstance(b, dict) and b.get("type") == "tool_result" for b in m["content"])
        ]

        assert len(tool_use_blocks) == 1
        assert len(user_msgs_with_results) == 1

        tool_result_blocks = [
            b for b in user_msgs_with_results[0]["content"]
            if isinstance(b, dict) and b.get("type") == "tool_result"
        ]
        assert len(tool_result_blocks) == 1

        # The critical assertion: IDs must match
        assert tool_result_blocks[0]["tool_use_id"] == tool_use_blocks[0]["id"]

    # ----- map-based ID preferred over stored ID ------------------------------

    def test_map_based_id_preferred_over_stale_stored_id(self, provider):
        """
        If a function_call's ID is regenerated during conversion (e.g. lost from
        types.Part wrapping), the function_response should use the regenerated ID
        from the map, not its own (now stale) stored ID.
        """
        original_id = _make_tool_use_id()

        # Simulate a function_call whose .id is None (lost during types.Part wrapping)
        fc_no_id = MagicMock()
        fc_no_id.name = "calculate"
        fc_no_id.args = {"a": 1, "b": 2}
        fc_no_id.id = None  # ID lost
        fc_no_id.raw = MagicMock()
        fc_no_id.raw.id = None

        # Function response still has the original (now stale) ID
        fr = types.FunctionResponse(name="calculate", response={"result": "3"})
        fr.id = original_id  # stale

        history = [
            types.Content(role="user", parts=[types.Part(text="compute")]),
            types.Content(role="model", parts=[types.Part(function_call=fc_no_id)]),
            types.Content(role="user", parts=[types.Part(function_response=fr)]),
        ]

        messages = provider._convert_history_to_anthropic_format(history)

        # Extract IDs
        assistant_msg = next(m for m in messages if m["role"] == "assistant")
        tool_use_blocks = [
            b for b in assistant_msg["content"]
            if isinstance(b, dict) and b.get("type") == "tool_use"
        ]
        user_msgs = [
            m for m in messages
            if m["role"] == "user" and isinstance(m.get("content"), list)
        ]
        tool_result_blocks = [
            b for b in user_msgs[-1]["content"]
            if isinstance(b, dict) and b.get("type") == "tool_result"
        ]

        assert len(tool_use_blocks) == 1
        assert len(tool_result_blocks) == 1
        # tool_result must reference the regenerated ID, not original_id
        assert tool_result_blocks[0]["tool_use_id"] == tool_use_blocks[0]["id"]
        # And the regenerated ID should NOT be the stale original
        assert tool_use_blocks[0]["id"] != original_id

    # ----- multiple parallel tool calls ---------------------------------------

    def test_multiple_parallel_tool_calls_ids_match(self, provider):
        """
        Multiple tool_use in one assistant message should each have a matching
        tool_result with the same ID.
        """
        ids = [_make_tool_use_id() for _ in range(3)]
        names = ["func_a", "func_b", "func_c"]

        fc_parts = []
        fr_parts = []
        for name, tid in zip(names, ids):
            fc = _make_fc_with_id(name, {"v": name}, tid)
            fc_parts.append(types.Part(function_call=fc))

            fr = types.FunctionResponse(name=name, response={"result": f"{name}_done"})
            fr.id = tid
            fr_parts.append(types.Part(function_response=fr))

        history = [
            types.Content(role="user", parts=[types.Part(text="do three things")]),
            types.Content(role="model", parts=fc_parts),
            types.Content(role="user", parts=fr_parts),
        ]

        messages = provider._convert_history_to_anthropic_format(history)

        assistant_msg = next(m for m in messages if m["role"] == "assistant")
        tool_use_ids = {
            b["id"] for b in assistant_msg["content"]
            if isinstance(b, dict) and b.get("type") == "tool_use"
        }

        user_msg = [m for m in messages if m["role"] == "user"][-1]
        tool_result_ids = {
            b["tool_use_id"] for b in user_msg["content"]
            if isinstance(b, dict) and b.get("type") == "tool_result"
        }

        assert tool_use_ids == tool_result_ids
        assert len(tool_use_ids) == 3

    # ----- _merge_and_validate_messages tests ---------------------------------

    def test_merge_consecutive_same_role_messages(self, provider):
        """Consecutive user messages get merged into one."""
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "user", "content": "World"},
            {"role": "assistant", "content": "Hi there"},
        ]
        merged = provider._merge_and_validate_messages(messages)
        assert len(merged) == 2
        assert merged[0]["role"] == "user"
        # Both texts should be in the merged content
        assert isinstance(merged[0]["content"], list)
        assert len(merged[0]["content"]) == 2

    def test_merge_normalizes_string_content_to_list(self, provider):
        """String content gets normalized to list format during merge."""
        messages = [
            {"role": "user", "content": "first"},
            {"role": "user", "content": [{"type": "text", "text": "second"}]},
        ]
        merged = provider._merge_and_validate_messages(messages)
        assert len(merged) == 1
        assert isinstance(merged[0]["content"], list)
        assert len(merged[0]["content"]) == 2

    def test_validate_fixes_orphaned_tool_result(self, provider):
        """
        An orphaned tool_result (ID doesn't match any tool_use) gets fixed by
        assigning an unclaimed tool_use ID.
        """
        good_id = _make_tool_use_id()
        bad_id = _make_tool_use_id()

        messages = [
            {"role": "user", "content": "do something"},
            {
                "role": "assistant",
                "content": [
                    {"type": "tool_use", "id": good_id, "name": "func", "input": {}},
                ],
            },
            {
                "role": "user",
                "content": [
                    {"type": "tool_result", "tool_use_id": bad_id, "content": "done"},
                ],
            },
        ]
        merged = provider._merge_and_validate_messages(messages)

        tool_result = next(
            b for b in merged[2]["content"]
            if isinstance(b, dict) and b.get("type") == "tool_result"
        )
        # Should have been fixed to match the tool_use ID
        assert tool_result["tool_use_id"] == good_id

    def test_validate_leaves_matching_ids_untouched(self, provider):
        """Already-matching IDs should not be changed."""
        tid = _make_tool_use_id()
        messages = [
            {"role": "user", "content": "go"},
            {
                "role": "assistant",
                "content": [
                    {"type": "tool_use", "id": tid, "name": "f", "input": {}},
                ],
            },
            {
                "role": "user",
                "content": [
                    {"type": "tool_result", "tool_use_id": tid, "content": "ok"},
                ],
            },
        ]
        merged = provider._merge_and_validate_messages(messages)
        tool_result = next(
            b for b in merged[2]["content"]
            if isinstance(b, dict) and b.get("type") == "tool_result"
        )
        assert tool_result["tool_use_id"] == tid


# ===========================================================================
# Gemini: _extract_model_content  &  history storage
# ===========================================================================

class TestGeminiThoughtSignaturePreservation:
    """
    Verify that Gemini responses are stored using the original Content object
    from the raw response, which preserves thought_signature and thought flags.
    """

    def _make_gemini_content_with_thought_signature(self):
        """
        Create a mock Gemini Content that looks like a thinking-mode response
        with thought_signature on function_call Parts.
        """
        # Thinking Part
        thought_part = types.Part(text="Let me think about this...")
        # We can't set thought=True directly on proto, but we can simulate
        # by attaching it as an attribute for testing
        thought_part._thought = True

        # Regular text Part
        text_part = types.Part(text="I'll call the function.")

        # Function call Part with thought_signature
        fc_part = types.Part(
            function_call=types.FunctionCall(
                name="load_product_data",
                args={"product_id": "123"},
            )
        )
        # Simulate thought_signature (set as attribute, like Gemini does)
        fc_part._thought_signature = "sig_abc123"

        content = types.Content(role="model", parts=[thought_part, text_part, fc_part])
        return content

    def _make_mock_response(self, content):
        """Wrap Content in a mock raw response structure."""
        candidate = MagicMock()
        candidate.content = content
        candidate.finish_reason = "STOP"

        raw_response = MagicMock()
        raw_response.candidates = [candidate]
        raw_response.usage_metadata = MagicMock()
        raw_response.usage_metadata.prompt_token_count = 100
        raw_response.usage_metadata.candidates_token_count = 50

        return raw_response

    def _make_provider_response(self, content, raw_response):
        """Create a ProviderResponse from content + raw."""
        function_calls = []
        text_parts = []
        for part in content.parts:
            if hasattr(part, "text") and part.text:
                text_parts.append(part.text)
            if hasattr(part, "function_call") and part.function_call:
                function_calls.append({
                    "name": part.function_call.name,
                    "args": dict(part.function_call.args),
                    "raw": part,
                })

        return ProviderResponse(
            text="\n".join(text_parts),
            function_calls=function_calls,
            raw_response=raw_response,
            finish_reason="STOP",
        )

    def test_extract_model_content_returns_original(self):
        """_extract_model_content should return the original Content from raw response."""
        content = self._make_gemini_content_with_thought_signature()
        raw_response = self._make_mock_response(content)
        provider_response = self._make_provider_response(content, raw_response)

        # Create a minimal Agent to test _extract_model_content
        # We patch __init__ to skip actual initialization
        with patch.object(Agent, "__init__", lambda self, **kw: None):
            agent = Agent.__new__(Agent)
            result = agent._extract_model_content(provider_response)

        assert result is content  # exact same object
        assert len(result.parts) == 3

    def test_extract_model_content_preserves_all_parts(self):
        """Original Content should have all Parts including thought and function_call."""
        content = self._make_gemini_content_with_thought_signature()
        raw_response = self._make_mock_response(content)
        provider_response = self._make_provider_response(content, raw_response)

        with patch.object(Agent, "__init__", lambda self, **kw: None):
            agent = Agent.__new__(Agent)
            result = agent._extract_model_content(provider_response)

        # All three parts preserved
        assert len(result.parts) == 3
        # Function call part is preserved as-is (same object)
        fc_part = result.parts[2]
        assert fc_part.function_call.name == "load_product_data"
        # The Part is the exact same object, so thought_signature is preserved
        assert fc_part is content.parts[2]

    def test_extract_model_content_returns_none_for_empty(self):
        """Returns None when raw response has no content."""
        provider_response = ProviderResponse(
            text="", function_calls=[], raw_response=None, finish_reason=None
        )

        with patch.object(Agent, "__init__", lambda self, **kw: None):
            agent = Agent.__new__(Agent)
            result = agent._extract_model_content(provider_response)

        assert result is None

    def test_extract_model_content_returns_none_for_no_candidates(self):
        """Returns None when raw response has no candidates."""
        raw = MagicMock()
        raw.candidates = []
        provider_response = ProviderResponse(
            text="", function_calls=[], raw_response=raw, finish_reason=None
        )

        with patch.object(Agent, "__init__", lambda self, **kw: None):
            agent = Agent.__new__(Agent)
            result = agent._extract_model_content(provider_response)

        assert result is None

    def test_reconstructed_part_loses_identity(self):
        """
        Demonstrates the problem: creating a new Part(function_call=fc) loses
        the original Part object and any extra attributes.
        """
        original_part = types.Part(
            function_call=types.FunctionCall(
                name="test_func", args={"x": 1}
            )
        )
        original_part._thought_signature = "sig_xyz"

        # Reconstructing (the old buggy way)
        new_part = types.Part(function_call=original_part.function_call)

        # New part is NOT the same object
        assert new_part is not original_part
        # And the _thought_signature is lost
        assert not hasattr(new_part, "_thought_signature")

    def test_original_content_preserves_identity(self):
        """
        Using original Content (the fix) preserves Part identity and all attributes.
        """
        content = self._make_gemini_content_with_thought_signature()
        raw_response = self._make_mock_response(content)
        provider_response = self._make_provider_response(content, raw_response)

        with patch.object(Agent, "__init__", lambda self, **kw: None):
            agent = Agent.__new__(Agent)
            extracted = agent._extract_model_content(provider_response)

        # Every Part should be the exact same object
        for orig, ext in zip(content.parts, extracted.parts):
            assert orig is ext


# ===========================================================================
# Integration: verify both fixes work with multi-turn history
# ===========================================================================

class TestMultiTurnHistoryIntegrity:
    """
    End-to-end style tests that verify history remains valid across
    multiple turns of function calling.
    """

    @pytest.fixture
    def anthropic_provider(self):
        with patch("em_agent_framework.core.models.anthropic_provider.AnthropicVertex"):
            from em_agent_framework.config.settings import ModelConfig
            mc = ModelConfig(name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=10)
            p = AnthropicProvider(
                model_config=mc,
                system_instruction="test",
                project_id="test-project",
                location="us-east5",
            )
        return p

    def test_multi_turn_anthropic_ids_consistent(self, anthropic_provider):
        """
        Simulate 2 turns of tool calls. All tool_result IDs must match
        tool_use IDs in the immediately preceding assistant message.
        """
        # Turn 1: assistant calls func_a
        id1 = _make_tool_use_id()
        fc1 = _make_fc_with_id("func_a", {"q": "hello"}, id1)
        fr1 = types.FunctionResponse(name="func_a", response={"result": "world"})
        fr1.id = id1

        # Turn 2: assistant calls func_b
        id2 = _make_tool_use_id()
        fc2 = _make_fc_with_id("func_b", {"q": "test"}, id2)
        fr2 = types.FunctionResponse(name="func_b", response={"result": "done"})
        fr2.id = id2

        history = [
            types.Content(role="user", parts=[types.Part(text="first question")]),
            types.Content(role="model", parts=[types.Part(function_call=fc1)]),
            types.Content(role="user", parts=[types.Part(function_response=fr1)]),
            types.Content(role="model", parts=[
                types.Part(text="Got it. Now let me try another."),
                types.Part(function_call=fc2),
            ]),
            types.Content(role="user", parts=[types.Part(function_response=fr2)]),
            types.Content(role="model", parts=[types.Part(text="All done!")]),
        ]

        messages = anthropic_provider._convert_history_to_anthropic_format(history)

        # Validate every tool_result references a valid tool_use
        for i in range(1, len(messages)):
            msg = messages[i]
            prev = messages[i - 1]

            if msg["role"] != "user" or not isinstance(msg["content"], list):
                continue

            tool_results = [
                b for b in msg["content"]
                if isinstance(b, dict) and b.get("type") == "tool_result"
            ]
            if not tool_results:
                continue

            # Must have a preceding assistant message with tool_use
            assert prev["role"] == "assistant", f"Message {i}: tool_result not preceded by assistant"
            assert isinstance(prev["content"], list)

            tool_use_ids = {
                b["id"] for b in prev["content"]
                if isinstance(b, dict) and b.get("type") == "tool_use"
            }

            for tr in tool_results:
                assert tr["tool_use_id"] in tool_use_ids, (
                    f"tool_result references {tr['tool_use_id']} but assistant only has {tool_use_ids}"
                )

    def test_same_function_name_called_twice_different_turns(self, anthropic_provider):
        """
        The same function called in two different turns should get different IDs
        and each tool_result should match its own turn's tool_use.
        """
        id1 = _make_tool_use_id()
        id2 = _make_tool_use_id()
        assert id1 != id2

        fc1 = _make_fc_with_id("search", {"q": "first"}, id1)
        fr1 = types.FunctionResponse(name="search", response={"result": "r1"})
        fr1.id = id1

        fc2 = _make_fc_with_id("search", {"q": "second"}, id2)
        fr2 = types.FunctionResponse(name="search", response={"result": "r2"})
        fr2.id = id2

        history = [
            types.Content(role="user", parts=[types.Part(text="search twice")]),
            types.Content(role="model", parts=[types.Part(function_call=fc1)]),
            types.Content(role="user", parts=[types.Part(function_response=fr1)]),
            types.Content(role="model", parts=[types.Part(function_call=fc2)]),
            types.Content(role="user", parts=[types.Part(function_response=fr2)]),
        ]

        messages = anthropic_provider._convert_history_to_anthropic_format(history)

        # Collect all tool_use → tool_result pairs
        pairs = []
        for i in range(1, len(messages)):
            msg = messages[i]
            prev = messages[i - 1]
            if msg["role"] != "user" or not isinstance(msg["content"], list):
                continue
            tool_results = [
                b for b in msg["content"]
                if isinstance(b, dict) and b.get("type") == "tool_result"
            ]
            if not tool_results and prev["role"] == "assistant":
                continue
            if prev["role"] != "assistant":
                continue
            tool_uses = [
                b for b in prev["content"]
                if isinstance(b, dict) and b.get("type") == "tool_use"
            ]
            for tu, tr in zip(tool_uses, tool_results):
                pairs.append((tu["id"], tr["tool_use_id"]))

        assert len(pairs) == 2
        for tu_id, tr_id in pairs:
            assert tu_id == tr_id
