"""
Test to check if tools can exist in BOTH active and complementary lists simultaneously.
"""

import pytest
from typing import Annotated

from em_agent_framework import Agent, AgentConfig, ModelConfig
from em_agent_framework.core.tools.decorators import tool


@tool(description="Add two numbers")
def add(a: Annotated[int, "First number"], b: Annotated[int, "Second number"]) -> int:
    """Add two numbers."""
    return a + b


@tool(description="Multiply two numbers")
def multiply(a: Annotated[int, "First number"], b: Annotated[int, "Second number"]) -> int:
    """Multiply two numbers."""
    return a * b


@tool(description="Subtract two numbers")
def subtract(a: Annotated[int, "First number"], b: Annotated[int, "Second number"]) -> int:
    """Subtract second number from first."""
    return a - b


class TestToolInBothLists:
    """Test if tools can exist in both active and complementary lists."""

    @pytest.fixture
    def agent_config(self):
        """Create test agent configuration."""
        return AgentConfig(
            max_turns=10,
            verbose=True,
        )

    @pytest.fixture
    def model_configs(self):
        """Create model configurations for testing."""
        return [
            ModelConfig(
                name="gemini-2.5-flash",
                provider="gemini",
                temperature=0.1,
                timeout=30.0,
            )
        ]

    @pytest.mark.asyncio
    async def test_removed_tool_not_auto_moved_to_complementary(self, agent_config, model_configs):
        """Test that removing a tool via update_tools_func does NOT auto-move it to complementary."""
        call_count = {"count": 0}

        def toggle_tool(conversation_history, current_tools):
            """Toggle subtract on/off."""
            call_count["count"] += 1

            # Odd: include subtract
            if call_count["count"] % 2 == 1:
                return [add, subtract]
            # Even: remove subtract
            else:
                return [add]

        agent = Agent(
            name="Toggle Agent",
            system_instruction="You are a math assistant.",
            tools=[add, subtract],
            model_configs=model_configs,
            agent_config=agent_config,
            update_tools_func=toggle_tool,
        )

        # Initially no complementary tools
        assert len(agent.complementary_tools) == 0

        # Send a message — update_tools_func will be called multiple times
        await agent.send_message("Calculate 5 + 3")

        # After conversation, tools removed by update_tools_func should NOT
        # appear in complementary_tools (no auto-migration)
        complementary_names = {t.__name__ for t in agent.complementary_tools}
        assert "subtract" not in complementary_names, \
            "Removed tools should not be auto-migrated to complementary_tools"

    @pytest.mark.asyncio
    async def test_tool_not_in_both_lists_when_explicitly_managed(self, agent_config, model_configs):
        """Test that when a tool is in active, it's removed from complementary (no overlap)."""
        agent = Agent(
            name="Overlap Agent",
            system_instruction="You are a math assistant.",
            tools=[add],
            complementary_tools=[subtract, multiply],
            model_configs=model_configs,
            agent_config=agent_config,
        )

        # Verify initial state
        active_names = {t.__name__ for t in agent.tools}
        complementary_names = {t.__name__ for t in agent.complementary_tools}
        assert "add" in active_names
        assert "subtract" in complementary_names
        assert "multiply" in complementary_names

        # No overlap initially
        assert len(active_names & complementary_names) == 0, \
            "Active and complementary should not overlap"


if __name__ == "__main__":
    import asyncio

    async def main():
        test = TestToolInBothLists()
        config = AgentConfig(max_turns=10, verbose=True)
        models = [ModelConfig(name="gemini-2.5-flash", provider="gemini", temperature=0.1, timeout=30.0)]

        await test.test_removed_tool_not_auto_moved_to_complementary(config, models)

    asyncio.run(main())
