"""
Tests for GrokProvider: history conversion, tool ID tracking, and response parsing.
"""

import json
import uuid
from typing import Any, Dict, List, Optional
from unittest.mock import MagicMock, AsyncMock, patch, PropertyMock

import pytest
from google.genai import types

from em_agent_framework.core.agent import Agent, FunctionCallWithId
from em_agent_framework.core.models.provider import ProviderResponse


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_tool_call_id() -> str:
    return f"tc_{uuid.uuid4().hex[:24]}"


def _make_fc_with_id(name: str, args: dict, tool_id: str):
    """Create a FunctionCallWithId (like Grok produces)."""
    raw = MagicMock()
    raw.id = tool_id
    raw.function = MagicMock()
    raw.function.name = name
    raw.function.arguments = json.dumps(args)
    return FunctionCallWithId(name=name, args=args, id=tool_id, raw=raw)


# ===========================================================================
# GrokProvider unit tests
# ===========================================================================


class TestGrokProviderInit:
    """Test GrokProvider initialization and properties."""

    def test_provider_type_is_grok(self):
        """Provider type should be 'grok'."""
        with patch("xai_sdk.AsyncClient"):
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.grok_provider import GrokProvider

            mc = ModelConfig(name="grok-3", provider="grok", timeout=10)
            p = GrokProvider(
                model_config=mc,
                system_instruction="test",
                api_key="test-key",
            )
        assert p.provider_type == "grok"

    def test_model_name(self):
        """Model name should match config."""
        with patch("xai_sdk.AsyncClient"):
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.grok_provider import GrokProvider

            mc = ModelConfig(name="grok-3-mini", provider="grok", timeout=10)
            p = GrokProvider(
                model_config=mc,
                system_instruction="test",
                api_key="test-key",
            )
        assert p.model_name == "grok-3-mini"

    def test_is_grok_model(self):
        """is_grok_model should return True."""
        with patch("xai_sdk.AsyncClient"):
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.grok_provider import GrokProvider

            mc = ModelConfig(name="grok-3", provider="grok", timeout=10)
            p = GrokProvider(
                model_config=mc,
                system_instruction="test",
                api_key="test-key",
            )
        assert p.is_grok_model() is True


class TestGrokProviderToolConversion:
    """Test tool conversion from framework format to xai_sdk format."""

    @pytest.fixture
    def provider(self):
        with patch("xai_sdk.AsyncClient"):
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.grok_provider import GrokProvider

            mc = ModelConfig(name="grok-3", provider="grok", timeout=10)
            p = GrokProvider(
                model_config=mc,
                system_instruction="test",
                api_key="test-key",
            )
        return p

    def test_convert_tools_none(self, provider):
        """None tools should return None."""
        assert provider._convert_tools_to_grok_format(None) is None

    def test_convert_tools_empty(self, provider):
        """Empty tools should return None."""
        assert provider._convert_tools_to_grok_format([]) is None

    def test_convert_tools_creates_grok_tools(self, provider):
        """Tools should be converted to xai_sdk format."""
        mock_tool_func = MagicMock()

        with patch("xai_sdk.chat.tool", return_value=mock_tool_func) as mock_grok_tool:
            tool = MagicMock()
            tool.name = "my_func"
            tool.description = "A test function"
            tool.parameters = {"type": "object", "properties": {"x": {"type": "integer"}}}

            result = provider._convert_tools_to_grok_format([tool])

            assert result is not None
            assert len(result) == 1
            mock_grok_tool.assert_called_once_with(
                name="my_func",
                description="A test function",
                parameters={"type": "object", "properties": {"x": {"type": "integer"}}},
            )


class TestGrokProviderResponseParsing:
    """Test parsing of Grok responses into ProviderResponse."""

    @pytest.fixture
    def provider(self):
        with patch("xai_sdk.AsyncClient"):
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.grok_provider import GrokProvider

            mc = ModelConfig(name="grok-3", provider="grok", timeout=10)
            p = GrokProvider(
                model_config=mc,
                system_instruction="test",
                api_key="test-key",
            )
        return p

    def test_parse_text_response(self, provider):
        """Text-only response should be parsed correctly."""
        mock_response = MagicMock()
        mock_response.content = "Hello, world!"
        mock_response.finish_reason = "REASON_STOP"
        mock_response.tool_calls = None
        mock_response.usage = MagicMock()
        mock_response.usage.prompt_tokens = 10
        mock_response.usage.completion_tokens = 5

        result = provider._parse_response(mock_response)

        assert result.text == "Hello, world!"
        assert result.finish_reason == "REASON_STOP"
        assert result.function_calls == []
        assert result.raw_response is mock_response

    def test_parse_tool_call_response(self, provider):
        """Response with tool calls should be parsed correctly."""
        tc = MagicMock()
        tc.function.name = "get_weather"
        tc.function.arguments = '{"city": "London"}'
        tc.id = "tc_123"

        mock_response = MagicMock()
        mock_response.content = "Let me check the weather."
        mock_response.finish_reason = "REASON_TOOL_CALLS"
        mock_response.tool_calls = [tc]
        mock_response.usage = MagicMock()
        mock_response.usage.prompt_tokens = 20
        mock_response.usage.completion_tokens = 10

        result = provider._parse_response(mock_response)

        assert result.text == "Let me check the weather."
        assert result.finish_reason == "REASON_TOOL_CALLS"
        assert len(result.function_calls) == 1
        assert result.function_calls[0]["name"] == "get_weather"
        assert result.function_calls[0]["args"] == {"city": "London"}
        assert result.function_calls[0]["id"] == "tc_123"

    def test_parse_multiple_tool_calls(self, provider):
        """Multiple tool calls should all be parsed."""
        tc1 = MagicMock()
        tc1.function.name = "func_a"
        tc1.function.arguments = '{"x": 1}'
        tc1.id = "tc_1"

        tc2 = MagicMock()
        tc2.function.name = "func_b"
        tc2.function.arguments = '{"y": 2}'
        tc2.id = "tc_2"

        mock_response = MagicMock()
        mock_response.content = ""
        mock_response.finish_reason = "REASON_TOOL_CALLS"
        mock_response.tool_calls = [tc1, tc2]
        mock_response.usage = MagicMock()
        mock_response.usage.prompt_tokens = 15
        mock_response.usage.completion_tokens = 8

        result = provider._parse_response(mock_response)

        assert len(result.function_calls) == 2
        assert result.function_calls[0]["name"] == "func_a"
        assert result.function_calls[1]["name"] == "func_b"

    def test_parse_none_response(self, provider):
        """None response should produce empty ProviderResponse."""
        result = provider._parse_response(None)

        assert result.text == ""
        assert result.function_calls == []
        assert result.raw_response is None

    def test_token_tracking(self, provider):
        """Token usage should be tracked from response."""
        mock_response = MagicMock()
        mock_response.content = "test"
        mock_response.finish_reason = "REASON_STOP"
        mock_response.tool_calls = None
        mock_response.usage = MagicMock()
        mock_response.usage.prompt_tokens = 100
        mock_response.usage.completion_tokens = 50

        provider._parse_response(mock_response)

        assert provider.get_last_input_tokens() == 100
        assert provider.get_last_output_tokens() == 50
        assert provider.count_tokens([], None) == 150


class TestGrokProviderMalformedResponse:
    """Test malformed response detection."""

    @pytest.fixture
    def provider(self):
        with patch("xai_sdk.AsyncClient"):
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.grok_provider import GrokProvider

            mc = ModelConfig(name="grok-3", provider="grok", timeout=10)
            p = GrokProvider(
                model_config=mc,
                system_instruction="test",
                api_key="test-key",
            )
        return p

    def test_none_is_malformed(self, provider):
        assert provider.is_malformed_response(None) is True

    def test_text_response_not_malformed(self, provider):
        mock = MagicMock()
        mock.content = "Hello"
        assert provider.is_malformed_response(mock) is False

    def test_tool_calls_response_not_malformed(self, provider):
        mock = MagicMock()
        mock.content = ""
        mock.tool_calls = [MagicMock()]
        assert provider.is_malformed_response(mock) is False

    def test_empty_response_is_malformed(self, provider):
        """A response with no content attribute at all is malformed."""
        mock = MagicMock(spec=[])  # No attributes at all
        assert provider.is_malformed_response(mock) is True

    def test_empty_string_content_is_valid(self, provider):
        """Empty string content is a valid end-of-turn signal, not malformed."""
        mock = MagicMock()
        mock.content = ""
        mock.tool_calls = []
        assert provider.is_malformed_response(mock) is False


class TestGrokProviderHistoryReplay:
    """Test history replay into xai_sdk chat."""

    @pytest.fixture
    def provider(self):
        with patch("xai_sdk.AsyncClient"):
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.grok_provider import GrokProvider

            mc = ModelConfig(name="grok-3", provider="grok", timeout=10)
            p = GrokProvider(
                model_config=mc,
                system_instruction="test",
                api_key="test-key",
            )
        return p

    @patch("xai_sdk.chat.tool_result")
    @patch("xai_sdk.chat.user")
    def test_replay_user_text_message(self, mock_user, mock_tool_result, provider):
        """User text messages should be replayed as grok_user."""
        mock_chat = MagicMock()

        history = [
            types.Content(role="user", parts=[types.Part(text="Hello")]),
        ]

        provider._replay_history_into_chat(mock_chat, history)

        mock_user.assert_called_once_with("Hello")
        mock_chat.append.assert_called()

    @patch("xai_sdk.chat.tool_result")
    @patch("xai_sdk.chat.user")
    def test_replay_function_response(self, mock_user, mock_tool_result, provider):
        """Function responses should be replayed as tool_result."""
        mock_chat = MagicMock()

        fr = types.FunctionResponse(name="get_weather", response={"result": "sunny"})
        fr.id = "tc_123"

        history = [
            types.Content(role="user", parts=[types.Part(function_response=fr)]),
        ]

        provider._replay_history_into_chat(mock_chat, history)

        mock_tool_result.assert_called_once()
        call_args = mock_tool_result.call_args
        # Should have the result string and tool_call_id
        assert "tc_123" in str(call_args)

    @patch("xai_sdk.chat.tool_result")
    @patch("xai_sdk.chat.user")
    def test_replay_model_text_message(self, mock_user, mock_tool_result, provider):
        """Model text messages should be replayed as assistant messages."""
        mock_chat = MagicMock()

        history = [
            types.Content(role="model", parts=[types.Part(text="I can help with that.")]),
        ]

        # Patch _append_assistant_message to verify it's called correctly
        with patch.object(provider, "_append_assistant_message") as mock_append:
            provider._replay_history_into_chat(mock_chat, history)

            mock_append.assert_called_once_with(
                mock_chat, "I can help with that.", None
            )

    @patch("xai_sdk.chat.tool_result")
    @patch("xai_sdk.chat.user")
    def test_replay_model_with_tool_calls(self, mock_user, mock_tool_result, provider):
        """Model messages with function calls should include tool call data."""
        mock_chat = MagicMock()

        fc = _make_fc_with_id("search", {"q": "test"}, "tc_abc")

        history = [
            types.Content(role="model", parts=[
                types.Part(text="Let me search."),
                types.Part(function_call=fc),
            ]),
        ]

        with patch.object(provider, "_append_assistant_message") as mock_append:
            provider._replay_history_into_chat(mock_chat, history)

            mock_append.assert_called_once()
            call_args = mock_append.call_args
            assert call_args[0][1] == "Let me search."  # text
            tool_calls = call_args[0][2]
            assert len(tool_calls) == 1
            assert tool_calls[0]["name"] == "search"
            assert tool_calls[0]["id"] == "tc_abc"

    @patch("xai_sdk.chat.tool_result")
    @patch("xai_sdk.chat.user")
    def test_replay_tool_call_id_matching(self, mock_user, mock_tool_result, provider):
        """Tool call IDs should propagate from model to function response."""
        mock_chat = MagicMock()

        tc_id = "tc_match_test"
        fc = _make_fc_with_id("my_func", {"x": 1}, tc_id)

        fr = types.FunctionResponse(name="my_func", response={"result": "ok"})
        # No stored ID - should get it from the map
        fr.id = None

        history = [
            types.Content(role="model", parts=[types.Part(function_call=fc)]),
            types.Content(role="user", parts=[types.Part(function_response=fr)]),
        ]

        with patch.object(provider, "_append_assistant_message"):
            provider._replay_history_into_chat(mock_chat, history)

        # tool_result should be called with the mapped ID
        mock_tool_result.assert_called_once()
        call_kwargs = mock_tool_result.call_args
        assert call_kwargs[1]["tool_call_id"] == tc_id


class TestGrokProviderHistoryCompression:
    """Test history compression for fallback scenarios."""

    @pytest.fixture
    def provider(self):
        with patch("xai_sdk.AsyncClient"):
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.grok_provider import GrokProvider

            mc = ModelConfig(name="grok-3", provider="grok", timeout=10)
            p = GrokProvider(
                model_config=mc,
                system_instruction="test",
                api_key="test-key",
            )
        return p

    def test_compress_empty_history(self, provider):
        assert provider._compress_history("") == ""

    def test_compress_text_history(self, provider):
        history = [
            types.Content(role="user", parts=[types.Part(text="Hello")]),
            types.Content(role="model", parts=[types.Part(text="Hi there!")]),
        ]
        result = provider._compress_history(history)
        assert "User: Hello" in result
        assert "Assistant: Hi there!" in result

    def test_compress_with_function_calls(self, provider):
        fc = types.FunctionCall(name="search", args={"q": "test"})

        history = [
            types.Content(role="model", parts=[types.Part(function_call=fc)]),
        ]
        result = provider._compress_history(history)
        assert "search" in result


# ===========================================================================
# Agent integration: _provider_uses_tool_ids
# ===========================================================================


class TestAgentProviderUsesToolIds:
    """Test that _provider_uses_tool_ids correctly identifies providers."""

    def _make_agent_stub(self):
        """Create a minimal Agent with __init__ bypassed."""
        with patch.object(Agent, "__init__", lambda self, **kw: None):
            agent = Agent.__new__(Agent)
        return agent

    def test_anthropic_provider_uses_tool_ids(self):
        """Anthropic provider should use tool IDs."""
        agent = self._make_agent_stub()
        agent.provider = MagicMock()
        agent.provider.is_anthropic_model = MagicMock(return_value=True)
        # Grok check should not be reached
        assert agent._provider_uses_tool_ids() is True

    def test_grok_provider_uses_tool_ids(self):
        """Grok provider should use tool IDs."""
        agent = self._make_agent_stub()
        agent.provider = MagicMock(spec=[])  # No is_anthropic_model
        agent.provider.is_grok_model = MagicMock(return_value=True)
        # Need to add the method dynamically since spec=[] clears everything
        agent.provider = MagicMock()
        agent.provider.is_anthropic_model = MagicMock(return_value=False)
        agent.provider.is_grok_model = MagicMock(return_value=True)
        assert agent._provider_uses_tool_ids() is True

    def test_gemini_provider_no_tool_ids(self):
        """Gemini provider should NOT use tool IDs."""
        agent = self._make_agent_stub()
        agent.provider = MagicMock()
        agent.provider.is_anthropic_model = MagicMock(return_value=False)
        # Gemini provider doesn't have is_grok_model or is_openai_model
        del agent.provider.is_grok_model
        del agent.provider.is_openai_model
        assert agent._provider_uses_tool_ids() is False


# ===========================================================================
# Agent integration: _create_provider for Grok
# ===========================================================================


class TestAgentCreateGrokProvider:
    """Test that _create_provider correctly instantiates GrokProvider for Grok models."""

    def _make_agent_stub(self):
        with patch.object(Agent, "__init__", lambda self, **kw: None):
            agent = Agent.__new__(Agent)
            agent.system_instruction = "test system instruction"
            agent.project_id = "test-project"
            agent.location = "us-central1"
        return agent

    @patch("em_agent_framework.core.agent.GrokProvider")
    def test_create_provider_for_grok_by_name(self, mock_grok_cls):
        """Model name containing 'grok' should create GrokProvider."""
        from em_agent_framework.config.settings import ModelConfig

        agent = self._make_agent_stub()
        mc = ModelConfig(name="grok-3", provider="grok", timeout=30)

        agent._create_provider(mc)

        mock_grok_cls.assert_called_once_with(
            model_config=mc,
            system_instruction="test system instruction",
            api_key=None,
            timeout=30,
        )

    @patch("em_agent_framework.core.agent.GrokProvider")
    def test_create_provider_for_grok_by_provider(self, mock_grok_cls):
        """Provider='grok' should create GrokProvider even without 'grok' in name."""
        from em_agent_framework.config.settings import ModelConfig

        agent = self._make_agent_stub()
        mc = ModelConfig(name="custom-model", provider="grok", timeout=15)

        agent._create_provider(mc)

        mock_grok_cls.assert_called_once()

    @patch("em_agent_framework.core.agent.AnthropicProvider")
    def test_create_provider_for_claude_still_works(self, mock_anthropic_cls):
        """Claude models should still create AnthropicProvider."""
        from em_agent_framework.config.settings import ModelConfig

        agent = self._make_agent_stub()
        mc = ModelConfig(name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=10)

        agent._create_provider(mc)

        mock_anthropic_cls.assert_called_once()

    @patch("em_agent_framework.core.agent.VertexAIProvider")
    def test_create_provider_for_gemini_still_works(self, mock_vertex_cls):
        """Gemini models should still create VertexAIProvider."""
        from em_agent_framework.config.settings import ModelConfig

        agent = self._make_agent_stub()
        mc = ModelConfig(name="gemini-2.5-flash", provider="gemini", timeout=10)

        agent._create_provider(mc)

        mock_vertex_cls.assert_called_once()


# ===========================================================================
# Multi-turn tool calling with Grok-style IDs
# ===========================================================================


class TestGrokToolIdConsistency:
    """
    Verify that tool_call IDs flow correctly through the history replay
    for Grok-style conversations.
    """

    @pytest.fixture
    def provider(self):
        with patch("xai_sdk.AsyncClient"):
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.grok_provider import GrokProvider

            mc = ModelConfig(name="grok-3", provider="grok", timeout=10)
            p = GrokProvider(
                model_config=mc,
                system_instruction="test",
                api_key="test-key",
            )
        return p

    @patch("xai_sdk.chat.tool_result")
    @patch("xai_sdk.chat.user")
    def test_multi_turn_ids_flow(self, mock_user, mock_tool_result, provider):
        """
        Multiple turns of tool calling should have IDs flowing correctly.
        """
        mock_chat = MagicMock()

        # Turn 1
        id1 = _make_tool_call_id()
        fc1 = _make_fc_with_id("func_a", {"q": "hello"}, id1)
        fr1 = types.FunctionResponse(name="func_a", response={"result": "world"})
        fr1.id = id1

        # Turn 2
        id2 = _make_tool_call_id()
        fc2 = _make_fc_with_id("func_b", {"q": "test"}, id2)
        fr2 = types.FunctionResponse(name="func_b", response={"result": "done"})
        fr2.id = id2

        history = [
            types.Content(role="user", parts=[types.Part(text="first question")]),
            types.Content(role="model", parts=[types.Part(function_call=fc1)]),
            types.Content(role="user", parts=[types.Part(function_response=fr1)]),
            types.Content(role="model", parts=[
                types.Part(text="Got it. Now let me try another."),
                types.Part(function_call=fc2),
            ]),
            types.Content(role="user", parts=[types.Part(function_response=fr2)]),
            types.Content(role="model", parts=[types.Part(text="All done!")]),
        ]

        with patch.object(provider, "_append_assistant_message"):
            provider._replay_history_into_chat(mock_chat, history)

        # Verify tool_result was called twice with correct IDs
        assert mock_tool_result.call_count == 2
        calls = mock_tool_result.call_args_list

        # First tool result should have id1
        assert calls[0][1]["tool_call_id"] == id1
        # Second tool result should have id2
        assert calls[1][1]["tool_call_id"] == id2

    @patch("xai_sdk.chat.tool_result")
    @patch("xai_sdk.chat.user")
    def test_parallel_tool_calls_ids(self, mock_user, mock_tool_result, provider):
        """Multiple parallel tool calls should each get correct IDs."""
        mock_chat = MagicMock()

        ids = [_make_tool_call_id() for _ in range(3)]
        names = ["func_a", "func_b", "func_c"]

        fc_parts = []
        fr_parts = []
        for name, tid in zip(names, ids):
            fc = _make_fc_with_id(name, {"v": name}, tid)
            fc_parts.append(types.Part(function_call=fc))

            fr = types.FunctionResponse(name=name, response={"result": f"{name}_done"})
            fr.id = tid
            fr_parts.append(types.Part(function_response=fr))

        history = [
            types.Content(role="user", parts=[types.Part(text="do three things")]),
            types.Content(role="model", parts=fc_parts),
            types.Content(role="user", parts=fr_parts),
        ]

        with patch.object(provider, "_append_assistant_message"):
            provider._replay_history_into_chat(mock_chat, history)

        # tool_result should be called 3 times
        assert mock_tool_result.call_count == 3

        # Each should have the corresponding ID
        result_ids = [call[1]["tool_call_id"] for call in mock_tool_result.call_args_list]
        assert set(result_ids) == set(ids)
