"""
Tests for OpenAIProvider: history conversion, tool ID tracking, and response parsing.
"""

import json
import uuid
from typing import Any, Dict, List, Optional
from unittest.mock import MagicMock, AsyncMock, patch, PropertyMock

import pytest
from google.genai import types

from em_agent_framework.core.agent import Agent, FunctionCallWithId
from em_agent_framework.core.models.provider import ProviderResponse


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_call_id() -> str:
    return f"call_{uuid.uuid4().hex[:24]}"


def _make_fc_with_id(name: str, args: dict, call_id: str):
    """Create a FunctionCallWithId (like OpenAI produces)."""
    raw = MagicMock()
    raw.type = "function_call"
    raw.call_id = call_id
    raw.name = name
    raw.arguments = json.dumps(args)
    return FunctionCallWithId(name=name, args=args, id=call_id, raw=raw)


# ===========================================================================
# OpenAIProvider unit tests
# ===========================================================================


class TestOpenAIProviderInit:
    """Test OpenAIProvider initialization and properties."""

    def test_provider_type_is_openai(self):
        """Provider type should be 'openai'."""
        with patch("openai.AsyncOpenAI"):
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.openai_provider import OpenAIProvider

            mc = ModelConfig(name="gpt-4o", provider="openai", timeout=10)
            p = OpenAIProvider(
                model_config=mc,
                system_instruction="test",
                api_key="test-key",
            )
        assert p.provider_type == "openai"

    def test_model_name(self):
        """Model name should match config."""
        with patch("openai.AsyncOpenAI"):
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.openai_provider import OpenAIProvider

            mc = ModelConfig(name="gpt-4.1-mini", provider="openai", timeout=10)
            p = OpenAIProvider(
                model_config=mc,
                system_instruction="test",
                api_key="test-key",
            )
        assert p.model_name == "gpt-4.1-mini"

    def test_is_openai_model(self):
        """is_openai_model should return True."""
        with patch("openai.AsyncOpenAI"):
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.openai_provider import OpenAIProvider

            mc = ModelConfig(name="gpt-4o", provider="openai", timeout=10)
            p = OpenAIProvider(
                model_config=mc,
                system_instruction="test",
                api_key="test-key",
            )
        assert p.is_openai_model() is True

    def test_api_key_passed_to_client(self):
        """API key should be passed to AsyncOpenAI."""
        with patch("openai.AsyncOpenAI") as mock_client:
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.openai_provider import OpenAIProvider

            mc = ModelConfig(name="gpt-4o", provider="openai", timeout=10)
            OpenAIProvider(
                model_config=mc,
                system_instruction="test",
                api_key="sk-test-12345",
            )

            mock_client.assert_called_once()
            call_kwargs = mock_client.call_args[1]
            assert call_kwargs["api_key"] == "sk-test-12345"

    def test_no_api_key_uses_env(self):
        """When no API key is provided, AsyncOpenAI should use env var."""
        with patch("openai.AsyncOpenAI") as mock_client:
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.openai_provider import OpenAIProvider

            mc = ModelConfig(name="gpt-4o", provider="openai", timeout=10)
            OpenAIProvider(
                model_config=mc,
                system_instruction="test",
            )

            mock_client.assert_called_once()
            call_kwargs = mock_client.call_args[1]
            assert "api_key" not in call_kwargs


class TestOpenAIProviderToolConversion:
    """Test tool conversion from framework format to OpenAI Responses API format."""

    @pytest.fixture
    def provider(self):
        with patch("openai.AsyncOpenAI"):
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.openai_provider import OpenAIProvider

            mc = ModelConfig(name="gpt-4o", provider="openai", timeout=10)
            p = OpenAIProvider(
                model_config=mc,
                system_instruction="test",
                api_key="test-key",
            )
        return p

    def test_convert_tools_none(self, provider):
        """None tools should return None."""
        assert provider._convert_tools_to_openai_format(None) is None

    def test_convert_tools_empty(self, provider):
        """Empty tools should return None."""
        assert provider._convert_tools_to_openai_format([]) is None

    def test_convert_single_tool(self, provider):
        """Single tool should be converted correctly."""
        tool = MagicMock()
        tool.name = "get_weather"
        tool.description = "Get weather for a city"
        tool.parameters = {
            "type": "object",
            "properties": {"city": {"type": "string"}},
        }

        result = provider._convert_tools_to_openai_format([tool])

        assert result is not None
        assert len(result) == 1
        assert result[0]["type"] == "function"
        assert result[0]["name"] == "get_weather"
        assert result[0]["description"] == "Get weather for a city"
        assert result[0]["parameters"]["properties"]["city"]["type"] == "string"

    def test_convert_multiple_tools(self, provider):
        """Multiple tools should all be converted."""
        tools = []
        for name in ["func_a", "func_b", "func_c"]:
            t = MagicMock()
            t.name = name
            t.description = f"Description of {name}"
            t.parameters = {"type": "object", "properties": {}}
            tools.append(t)

        result = provider._convert_tools_to_openai_format(tools)

        assert result is not None
        assert len(result) == 3
        assert result[0]["name"] == "func_a"
        assert result[1]["name"] == "func_b"
        assert result[2]["name"] == "func_c"

    def test_convert_tool_with_none_description(self, provider):
        """Tool with None description should get empty string."""
        tool = MagicMock()
        tool.name = "my_func"
        tool.description = None
        tool.parameters = {"type": "object"}

        result = provider._convert_tools_to_openai_format([tool])

        assert result[0]["description"] == ""

    def test_convert_tool_with_none_parameters(self, provider):
        """Tool with None parameters should get empty dict."""
        tool = MagicMock()
        tool.name = "my_func"
        tool.description = "A function"
        tool.parameters = None

        result = provider._convert_tools_to_openai_format([tool])

        assert result[0]["parameters"] == {}


class TestOpenAIProviderResponseParsing:
    """Test parsing of OpenAI Responses API responses into ProviderResponse."""

    @pytest.fixture
    def provider(self):
        with patch("openai.AsyncOpenAI"):
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.openai_provider import OpenAIProvider

            mc = ModelConfig(name="gpt-4o", provider="openai", timeout=10)
            p = OpenAIProvider(
                model_config=mc,
                system_instruction="test",
                api_key="test-key",
            )
        return p

    def test_parse_text_response(self, provider):
        """Text-only response should be parsed correctly."""
        mock_response = MagicMock()
        mock_response.output_text = "Hello, world!"
        mock_response.status = "completed"
        mock_response.output = [MagicMock(type="message")]
        mock_response.usage = MagicMock()
        mock_response.usage.input_tokens = 10
        mock_response.usage.output_tokens = 5

        result = provider._parse_response(mock_response)

        assert result.text == "Hello, world!"
        assert result.finish_reason == "completed"
        assert result.function_calls == []
        assert result.raw_response is mock_response

    def test_parse_tool_call_response(self, provider):
        """Response with function calls should be parsed correctly."""
        fc_item = MagicMock()
        fc_item.type = "function_call"
        fc_item.name = "get_weather"
        fc_item.arguments = '{"city": "London"}'
        fc_item.call_id = "call_123"

        mock_response = MagicMock()
        mock_response.output_text = ""
        mock_response.status = "completed"
        mock_response.output = [fc_item]
        mock_response.usage = MagicMock()
        mock_response.usage.input_tokens = 20
        mock_response.usage.output_tokens = 10

        result = provider._parse_response(mock_response)

        assert len(result.function_calls) == 1
        assert result.function_calls[0]["name"] == "get_weather"
        assert result.function_calls[0]["args"] == {"city": "London"}
        assert result.function_calls[0]["id"] == "call_123"

    def test_parse_multiple_tool_calls(self, provider):
        """Multiple tool calls should all be parsed."""
        fc1 = MagicMock()
        fc1.type = "function_call"
        fc1.name = "func_a"
        fc1.arguments = '{"x": 1}'
        fc1.call_id = "call_1"

        fc2 = MagicMock()
        fc2.type = "function_call"
        fc2.name = "func_b"
        fc2.arguments = '{"y": 2}'
        fc2.call_id = "call_2"

        mock_response = MagicMock()
        mock_response.output_text = ""
        mock_response.status = "completed"
        mock_response.output = [fc1, fc2]
        mock_response.usage = MagicMock()
        mock_response.usage.input_tokens = 15
        mock_response.usage.output_tokens = 8

        result = provider._parse_response(mock_response)

        assert len(result.function_calls) == 2
        assert result.function_calls[0]["name"] == "func_a"
        assert result.function_calls[1]["name"] == "func_b"

    def test_parse_none_response(self, provider):
        """None response should produce empty ProviderResponse."""
        result = provider._parse_response(None)

        assert result.text == ""
        assert result.function_calls == []
        assert result.raw_response is None

    def test_parse_mixed_output(self, provider):
        """Response with both message and function call items."""
        msg_item = MagicMock()
        msg_item.type = "message"

        fc_item = MagicMock()
        fc_item.type = "function_call"
        fc_item.name = "search"
        fc_item.arguments = '{"query": "test"}'
        fc_item.call_id = "call_abc"

        reasoning_item = MagicMock()
        reasoning_item.type = "reasoning"

        mock_response = MagicMock()
        mock_response.output_text = "Let me search for that."
        mock_response.status = "completed"
        mock_response.output = [reasoning_item, msg_item, fc_item]
        mock_response.usage = MagicMock()
        mock_response.usage.input_tokens = 25
        mock_response.usage.output_tokens = 12

        result = provider._parse_response(mock_response)

        assert result.text == "Let me search for that."
        assert len(result.function_calls) == 1
        assert result.function_calls[0]["name"] == "search"

    def test_token_tracking(self, provider):
        """Token usage should be tracked from response."""
        mock_response = MagicMock()
        mock_response.output_text = "test"
        mock_response.status = "completed"
        mock_response.output = []
        mock_response.usage = MagicMock()
        mock_response.usage.input_tokens = 100
        mock_response.usage.output_tokens = 50

        provider._parse_response(mock_response)

        assert provider.get_last_input_tokens() == 100
        assert provider.get_last_output_tokens() == 50
        assert provider.count_tokens([], None) == 150

    def test_invalid_json_arguments(self, provider):
        """Invalid JSON in arguments should fallback to empty dict."""
        fc_item = MagicMock()
        fc_item.type = "function_call"
        fc_item.name = "broken"
        fc_item.arguments = "not valid json"
        fc_item.call_id = "call_bad"

        mock_response = MagicMock()
        mock_response.output_text = ""
        mock_response.status = "completed"
        mock_response.output = [fc_item]
        mock_response.usage = MagicMock()
        mock_response.usage.input_tokens = 5
        mock_response.usage.output_tokens = 3

        result = provider._parse_response(mock_response)

        assert len(result.function_calls) == 1
        assert result.function_calls[0]["args"] == {}


class TestOpenAIProviderMalformedResponse:
    """Test malformed response detection."""

    @pytest.fixture
    def provider(self):
        with patch("openai.AsyncOpenAI"):
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.openai_provider import OpenAIProvider

            mc = ModelConfig(name="gpt-4o", provider="openai", timeout=10)
            p = OpenAIProvider(
                model_config=mc,
                system_instruction="test",
                api_key="test-key",
            )
        return p

    def test_none_is_malformed(self, provider):
        assert provider.is_malformed_response(None) is True

    def test_text_response_not_malformed(self, provider):
        mock = MagicMock()
        mock.output_text = "Hello"
        assert provider.is_malformed_response(mock) is False

    def test_function_call_response_not_malformed(self, provider):
        fc = MagicMock()
        fc.type = "function_call"
        mock = MagicMock()
        mock.output_text = ""
        mock.output = [fc]
        assert provider.is_malformed_response(mock) is False

    def test_empty_response_is_malformed(self, provider):
        """A response with no output_text attribute at all is malformed."""
        mock = MagicMock(spec=[])  # No attributes at all
        assert provider.is_malformed_response(mock) is True

    def test_empty_string_output_text_is_valid(self, provider):
        """Empty string output_text is a valid end-of-turn signal, not malformed."""
        mock = MagicMock()
        mock.output_text = ""
        mock.output = []
        assert provider.is_malformed_response(mock) is False

    def test_none_output_text_with_function_calls_is_valid(self, provider):
        """Response with no text but with function calls is valid."""
        fc = MagicMock()
        fc.type = "function_call"
        mock = MagicMock(spec=["output"])
        mock.output = [fc]
        assert provider.is_malformed_response(mock) is False


class TestOpenAIProviderHistoryConversion:
    """Test history conversion from Content format to OpenAI input format."""

    @pytest.fixture
    def provider(self):
        with patch("openai.AsyncOpenAI"):
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.openai_provider import OpenAIProvider

            mc = ModelConfig(name="gpt-4o", provider="openai", timeout=10)
            p = OpenAIProvider(
                model_config=mc,
                system_instruction="test",
                api_key="test-key",
            )
        return p

    def test_convert_user_text_message(self, provider):
        """User text messages should be converted to role=user items."""
        history = [
            types.Content(role="user", parts=[types.Part(text="Hello")]),
        ]

        result = provider._convert_history_to_input(history)

        assert len(result) == 1
        assert result[0]["role"] == "user"
        assert result[0]["content"] == "Hello"

    def test_convert_model_text_message(self, provider):
        """Model text messages should be converted to role=assistant items."""
        history = [
            types.Content(role="model", parts=[types.Part(text="Hi there!")]),
        ]

        result = provider._convert_history_to_input(history)

        assert len(result) == 1
        assert result[0]["role"] == "assistant"
        assert result[0]["content"] == [{"type": "output_text", "text": "Hi there!"}]

    def test_convert_model_function_call(self, provider):
        """Model function calls should be converted to function_call items."""
        fc = _make_fc_with_id("get_weather", {"city": "Paris"}, "call_abc123")

        history = [
            types.Content(role="model", parts=[types.Part(function_call=fc)]),
        ]

        result = provider._convert_history_to_input(history)

        assert len(result) == 1
        assert result[0]["type"] == "function_call"
        assert result[0]["call_id"] == "call_abc123"
        assert result[0]["name"] == "get_weather"
        args = json.loads(result[0]["arguments"])
        assert args == {"city": "Paris"}

    def test_convert_function_response(self, provider):
        """Function responses should be converted to function_call_output items."""
        fc = _make_fc_with_id("get_weather", {"city": "Paris"}, "call_abc123")
        fr = types.FunctionResponse(name="get_weather", response={"temp": "22C"})
        fr.id = "call_abc123"

        history = [
            types.Content(role="model", parts=[types.Part(function_call=fc)]),
            types.Content(role="user", parts=[types.Part(function_response=fr)]),
        ]

        result = provider._convert_history_to_input(history)

        assert len(result) == 2
        # First: function_call
        assert result[0]["type"] == "function_call"
        # Second: function_call_output
        assert result[1]["type"] == "function_call_output"
        assert result[1]["call_id"] == "call_abc123"
        output = json.loads(result[1]["output"])
        assert output == {"temp": "22C"}

    def test_convert_mixed_text_and_function_call(self, provider):
        """Model message with both text and function call."""
        fc = _make_fc_with_id("search", {"q": "test"}, "call_xyz")

        history = [
            types.Content(
                role="model",
                parts=[
                    types.Part(text="Let me search."),
                    types.Part(function_call=fc),
                ],
            ),
        ]

        result = provider._convert_history_to_input(history)

        # Should have assistant text + function_call
        assert len(result) == 2
        assert result[0]["role"] == "assistant"
        assert result[0]["content"] == [{"type": "output_text", "text": "Let me search."}]
        assert result[1]["type"] == "function_call"
        assert result[1]["name"] == "search"

    def test_convert_empty_history(self, provider):
        """Empty history should return empty list."""
        result = provider._convert_history_to_input([])
        assert result == []

    def test_tool_call_id_matching_via_map(self, provider):
        """When function response has no stored ID, it should get ID from map."""
        call_id = "call_map_test"
        fc = _make_fc_with_id("my_func", {"x": 1}, call_id)
        fr = types.FunctionResponse(name="my_func", response={"result": "ok"})
        fr.id = None  # No stored ID

        history = [
            types.Content(role="model", parts=[types.Part(function_call=fc)]),
            types.Content(role="user", parts=[types.Part(function_response=fr)]),
        ]

        result = provider._convert_history_to_input(history)

        # The function_call_output should have the correct call_id from the map
        assert result[1]["type"] == "function_call_output"
        assert result[1]["call_id"] == call_id


class TestOpenAIProviderHistoryCompression:
    """Test history compression for fallback scenarios."""

    @pytest.fixture
    def provider(self):
        with patch("openai.AsyncOpenAI"):
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.openai_provider import OpenAIProvider

            mc = ModelConfig(name="gpt-4o", provider="openai", timeout=10)
            p = OpenAIProvider(
                model_config=mc,
                system_instruction="test",
                api_key="test-key",
            )
        return p

    def test_compress_empty_history(self, provider):
        assert provider._compress_history("") == ""

    def test_compress_text_history(self, provider):
        history = [
            types.Content(role="user", parts=[types.Part(text="Hello")]),
            types.Content(role="model", parts=[types.Part(text="Hi there!")]),
        ]
        result = provider._compress_history(history)
        assert "User: Hello" in result
        assert "Assistant: Hi there!" in result

    def test_compress_with_function_calls(self, provider):
        fc = types.FunctionCall(name="search", args={"q": "test"})

        history = [
            types.Content(role="model", parts=[types.Part(function_call=fc)]),
        ]
        result = provider._compress_history(history)
        assert "search" in result


# ===========================================================================
# Agent integration: _provider_uses_tool_ids for OpenAI
# ===========================================================================


class TestAgentProviderUsesToolIdsOpenAI:
    """Test that _provider_uses_tool_ids correctly identifies OpenAI provider."""

    def _make_agent_stub(self):
        """Create a minimal Agent with __init__ bypassed."""
        with patch.object(Agent, "__init__", lambda self, **kw: None):
            agent = Agent.__new__(Agent)
        return agent

    def test_openai_provider_uses_tool_ids(self):
        """OpenAI provider should use tool IDs."""
        agent = self._make_agent_stub()
        agent.provider = MagicMock()
        agent.provider.is_anthropic_model = MagicMock(return_value=False)
        agent.provider.is_grok_model = MagicMock(return_value=False)
        agent.provider.is_openai_model = MagicMock(return_value=True)
        assert agent._provider_uses_tool_ids() is True

    def test_gemini_provider_still_no_tool_ids(self):
        """Gemini provider should still NOT use tool IDs."""
        agent = self._make_agent_stub()
        agent.provider = MagicMock()
        agent.provider.is_anthropic_model = MagicMock(return_value=False)
        # Gemini doesn't have is_grok_model or is_openai_model
        del agent.provider.is_grok_model
        del agent.provider.is_openai_model
        assert agent._provider_uses_tool_ids() is False


# ===========================================================================
# Agent integration: _create_provider for OpenAI
# ===========================================================================


class TestAgentCreateOpenAIProvider:
    """Test that _create_provider correctly instantiates OpenAIProvider."""

    def _make_agent_stub(self):
        with patch.object(Agent, "__init__", lambda self, **kw: None):
            agent = Agent.__new__(Agent)
            agent.system_instruction = "test system instruction"
            agent.project_id = "test-project"
            agent.location = "us-central1"
        return agent

    @patch("em_agent_framework.core.agent.OpenAIProvider")
    def test_create_provider_for_openai_by_name_gpt(self, mock_openai_cls):
        """Model name containing 'gpt' should create OpenAIProvider."""
        from em_agent_framework.config.settings import ModelConfig

        agent = self._make_agent_stub()
        mc = ModelConfig(name="gpt-4o", provider="openai", timeout=30)

        agent._create_provider(mc)

        mock_openai_cls.assert_called_once_with(
            model_config=mc,
            system_instruction="test system instruction",
            api_key=None,
            timeout=30,
        )

    @patch("em_agent_framework.core.agent.OpenAIProvider")
    def test_create_provider_for_openai_by_provider(self, mock_openai_cls):
        """Provider='openai' should create OpenAIProvider even without 'gpt' in name."""
        from em_agent_framework.config.settings import ModelConfig

        agent = self._make_agent_stub()
        mc = ModelConfig(name="custom-model", provider="openai", timeout=15)

        agent._create_provider(mc)

        mock_openai_cls.assert_called_once()

    @patch("em_agent_framework.core.agent.OpenAIProvider")
    def test_create_provider_for_o1_model(self, mock_openai_cls):
        """Model name starting with 'o1' should create OpenAIProvider."""
        from em_agent_framework.config.settings import ModelConfig

        agent = self._make_agent_stub()
        mc = ModelConfig(name="o1-preview", provider="openai", timeout=30)

        agent._create_provider(mc)

        mock_openai_cls.assert_called_once()

    @patch("em_agent_framework.core.agent.OpenAIProvider")
    def test_create_provider_for_o3_model(self, mock_openai_cls):
        """Model name starting with 'o3' should create OpenAIProvider."""
        from em_agent_framework.config.settings import ModelConfig

        agent = self._make_agent_stub()
        mc = ModelConfig(name="o3-mini", provider="openai", timeout=30)

        agent._create_provider(mc)

        mock_openai_cls.assert_called_once()

    @patch("em_agent_framework.core.agent.OpenAIProvider")
    def test_create_provider_for_o4_model(self, mock_openai_cls):
        """Model name starting with 'o4' should create OpenAIProvider."""
        from em_agent_framework.config.settings import ModelConfig

        agent = self._make_agent_stub()
        mc = ModelConfig(name="o4-mini", provider="openai", timeout=30)

        agent._create_provider(mc)

        mock_openai_cls.assert_called_once()

    @patch("em_agent_framework.core.agent.OpenAIProvider")
    def test_create_provider_with_api_key(self, mock_openai_cls):
        """API key from model config should be passed to OpenAIProvider."""
        from em_agent_framework.config.settings import ModelConfig

        agent = self._make_agent_stub()
        mc = ModelConfig(
            name="gpt-4o", provider="openai", timeout=10, api_key="sk-my-key"
        )

        agent._create_provider(mc)

        call_kwargs = mock_openai_cls.call_args[1]
        assert call_kwargs["api_key"] == "sk-my-key"

    @patch("em_agent_framework.core.agent.AnthropicProvider")
    def test_create_provider_for_claude_still_works(self, mock_anthropic_cls):
        """Claude models should still create AnthropicProvider."""
        from em_agent_framework.config.settings import ModelConfig

        agent = self._make_agent_stub()
        mc = ModelConfig(
            name="claude-sonnet-4-5@20250929", provider="anthropic", timeout=10
        )

        agent._create_provider(mc)

        mock_anthropic_cls.assert_called_once()

    @patch("em_agent_framework.core.agent.VertexAIProvider")
    def test_create_provider_for_gemini_still_works(self, mock_vertex_cls):
        """Gemini models should still create VertexAIProvider."""
        from em_agent_framework.config.settings import ModelConfig

        agent = self._make_agent_stub()
        mc = ModelConfig(name="gemini-2.5-flash", provider="gemini", timeout=10)

        agent._create_provider(mc)

        mock_vertex_cls.assert_called_once()

    @patch("em_agent_framework.core.agent.GrokProvider")
    def test_create_provider_for_grok_still_works(self, mock_grok_cls):
        """Grok models should still create GrokProvider."""
        from em_agent_framework.config.settings import ModelConfig

        agent = self._make_agent_stub()
        mc = ModelConfig(name="grok-3", provider="grok", timeout=10)

        agent._create_provider(mc)

        mock_grok_cls.assert_called_once()


# ===========================================================================
# Multi-turn tool calling with OpenAI-style IDs
# ===========================================================================


class TestOpenAIToolIdConsistency:
    """
    Verify that call_ids flow correctly through the history conversion
    for OpenAI-style conversations.
    """

    @pytest.fixture
    def provider(self):
        with patch("openai.AsyncOpenAI"):
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.openai_provider import OpenAIProvider

            mc = ModelConfig(name="gpt-4o", provider="openai", timeout=10)
            p = OpenAIProvider(
                model_config=mc,
                system_instruction="test",
                api_key="test-key",
            )
        return p

    def test_multi_turn_ids_flow(self, provider):
        """Multiple turns of tool calling should have IDs flowing correctly."""
        # Turn 1
        id1 = _make_call_id()
        fc1 = _make_fc_with_id("func_a", {"q": "hello"}, id1)
        fr1 = types.FunctionResponse(name="func_a", response={"result": "world"})
        fr1.id = id1

        # Turn 2
        id2 = _make_call_id()
        fc2 = _make_fc_with_id("func_b", {"q": "test"}, id2)
        fr2 = types.FunctionResponse(name="func_b", response={"result": "done"})
        fr2.id = id2

        history = [
            types.Content(role="user", parts=[types.Part(text="first question")]),
            types.Content(role="model", parts=[types.Part(function_call=fc1)]),
            types.Content(role="user", parts=[types.Part(function_response=fr1)]),
            types.Content(
                role="model",
                parts=[
                    types.Part(text="Got it. Now let me try another."),
                    types.Part(function_call=fc2),
                ],
            ),
            types.Content(role="user", parts=[types.Part(function_response=fr2)]),
            types.Content(role="model", parts=[types.Part(text="All done!")]),
        ]

        result = provider._convert_history_to_input(history)

        # Find all function_call_output items and verify their call_ids
        outputs = [r for r in result if r.get("type") == "function_call_output"]
        assert len(outputs) == 2
        assert outputs[0]["call_id"] == id1
        assert outputs[1]["call_id"] == id2

    def test_parallel_tool_calls_ids(self, provider):
        """Multiple parallel tool calls should each get correct IDs."""
        ids = [_make_call_id() for _ in range(3)]
        names = ["func_a", "func_b", "func_c"]

        fc_parts = []
        fr_parts = []
        for name, tid in zip(names, ids):
            fc = _make_fc_with_id(name, {"v": name}, tid)
            fc_parts.append(types.Part(function_call=fc))

            fr = types.FunctionResponse(name=name, response={"result": f"{name}_done"})
            fr.id = tid
            fr_parts.append(types.Part(function_response=fr))

        history = [
            types.Content(role="user", parts=[types.Part(text="do three things")]),
            types.Content(role="model", parts=fc_parts),
            types.Content(role="user", parts=fr_parts),
        ]

        result = provider._convert_history_to_input(history)

        # Find all function_call items
        fc_items = [r for r in result if r.get("type") == "function_call"]
        assert len(fc_items) == 3

        # Find all function_call_output items
        output_items = [r for r in result if r.get("type") == "function_call_output"]
        assert len(output_items) == 3

        # Each output should have the corresponding ID
        output_ids = {item["call_id"] for item in output_items}
        assert output_ids == set(ids)


# ===========================================================================
# Async send_message and send_function_response
# ===========================================================================


class TestOpenAIProviderSendMessage:
    """Test send_message builds correct API calls."""

    @pytest.fixture
    def provider(self):
        with patch("openai.AsyncOpenAI") as mock_cls:
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.openai_provider import OpenAIProvider

            mc = ModelConfig(name="gpt-4o", provider="openai", timeout=30, temperature=0.5)
            p = OpenAIProvider(
                model_config=mc,
                system_instruction="You are helpful.",
                api_key="test-key",
            )
        return p

    @pytest.mark.asyncio
    async def test_send_message_basic(self, provider):
        """send_message should call responses.create with correct params."""
        mock_response = MagicMock()
        mock_response.output_text = "Response text"
        mock_response.status = "completed"
        mock_response.output = []
        mock_response.usage = MagicMock()
        mock_response.usage.input_tokens = 10
        mock_response.usage.output_tokens = 5

        provider._client.responses.create = AsyncMock(return_value=mock_response)

        result = await provider.send_message("Hello", history=[], tools=None)

        provider._client.responses.create.assert_called_once()
        call_kwargs = provider._client.responses.create.call_args[1]
        assert call_kwargs["model"] == "gpt-4o"
        assert call_kwargs["instructions"] == "You are helpful."
        assert call_kwargs["temperature"] == 0.5
        # Input should have just the user message
        assert len(call_kwargs["input"]) == 1
        assert call_kwargs["input"][0]["role"] == "user"
        assert call_kwargs["input"][0]["content"] == "Hello"

        assert result.text == "Response text"

    @pytest.mark.asyncio
    async def test_send_message_with_tools(self, provider):
        """send_message should include tools when provided."""
        mock_response = MagicMock()
        mock_response.output_text = ""
        mock_response.status = "completed"
        mock_response.output = []
        mock_response.usage = MagicMock()
        mock_response.usage.input_tokens = 10
        mock_response.usage.output_tokens = 5

        provider._client.responses.create = AsyncMock(return_value=mock_response)

        tool = MagicMock()
        tool.name = "my_func"
        tool.description = "A function"
        tool.parameters = {"type": "object", "properties": {}}

        await provider.send_message("Use the tool", history=[], tools=[tool])

        call_kwargs = provider._client.responses.create.call_args[1]
        assert "tools" in call_kwargs
        assert len(call_kwargs["tools"]) == 1
        assert call_kwargs["tools"][0]["name"] == "my_func"

    @pytest.mark.asyncio
    async def test_send_message_with_history(self, provider):
        """send_message should include history in input."""
        mock_response = MagicMock()
        mock_response.output_text = "Got it"
        mock_response.status = "completed"
        mock_response.output = []
        mock_response.usage = MagicMock()
        mock_response.usage.input_tokens = 20
        mock_response.usage.output_tokens = 5

        provider._client.responses.create = AsyncMock(return_value=mock_response)

        history = [
            types.Content(role="user", parts=[types.Part(text="First message")]),
            types.Content(role="model", parts=[types.Part(text="First reply")]),
        ]

        await provider.send_message("Second message", history=history, tools=None)

        call_kwargs = provider._client.responses.create.call_args[1]
        input_items = call_kwargs["input"]
        # Should have: user(First message) + assistant(First reply) + user(Second message)
        assert len(input_items) == 3
        assert input_items[0]["content"] == "First message"
        assert input_items[1]["content"] == [{"type": "output_text", "text": "First reply"}]
        assert input_items[2]["content"] == "Second message"

    @pytest.mark.asyncio
    async def test_send_function_response(self, provider):
        """send_function_response should replay full history."""
        mock_response = MagicMock()
        mock_response.output_text = "The weather is sunny."
        mock_response.status = "completed"
        mock_response.output = []
        mock_response.usage = MagicMock()
        mock_response.usage.input_tokens = 30
        mock_response.usage.output_tokens = 10

        provider._client.responses.create = AsyncMock(return_value=mock_response)

        fc = _make_fc_with_id("get_weather", {"city": "Paris"}, "call_123")
        fr = types.FunctionResponse(
            name="get_weather", response={"temp": "22C"}
        )
        fr.id = "call_123"

        history = [
            types.Content(role="user", parts=[types.Part(text="What is the weather?")]),
            types.Content(role="model", parts=[types.Part(function_call=fc)]),
            types.Content(role="user", parts=[types.Part(function_response=fr)]),
        ]

        provider._tools = [MagicMock(name="get_weather", description="", parameters={})]

        result = await provider.send_function_response(
            function_response_parts=[], history=history
        )

        provider._client.responses.create.assert_called_once()
        assert result.text == "The weather is sunny."


class TestOpenAIProviderUpdateSystemInstruction:
    """Test system instruction update."""

    def test_update_system_instruction(self):
        """Updating system instruction should update the stored value."""
        with patch("openai.AsyncOpenAI"):
            from em_agent_framework.config.settings import ModelConfig
            from em_agent_framework.core.models.openai_provider import OpenAIProvider

            mc = ModelConfig(name="gpt-4o", provider="openai", timeout=10)
            p = OpenAIProvider(
                model_config=mc,
                system_instruction="original",
                api_key="test-key",
            )

        assert p.system_instruction == "original"

        p.update_system_instruction("updated", [])

        assert p.system_instruction == "updated"
