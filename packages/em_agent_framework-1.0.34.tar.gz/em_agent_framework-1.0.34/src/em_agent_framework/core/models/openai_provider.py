"""
OpenAI provider for GPT and o-series models.

Uses the official openai Python SDK (AsyncOpenAI) with the Responses API
(client.responses.create) for interacting with OpenAI models.
Requires the OPENAI_API_KEY environment variable or an explicit api_key parameter.
"""

import asyncio
import json
import uuid
from typing import Any, Dict, List, Optional

from google.genai import types

from em_agent_framework.config.settings import ModelConfig

from .provider import ModelProvider, ProviderResponse


class OpenAIProvider(ModelProvider):
    """
    Provider for OpenAI GPT and o-series models.

    Uses the openai Python SDK's AsyncOpenAI client with the Responses API
    (client.responses.create) for interacting with OpenAI models.
    Authentication is handled via the OPENAI_API_KEY environment variable
    by default, or through an explicit api_key parameter.

    The provider converts between the framework's google.genai.types.Content
    history format and the OpenAI Responses API input format for each API call.
    """

    def __init__(
        self,
        model_config: ModelConfig,
        system_instruction: str,
        api_key: Optional[str] = None,
        timeout: float = 10.0,
    ):
        """
        Initialize OpenAI provider.

        Args:
            model_config: Configuration for the model
            system_instruction: System instruction/prompt
            api_key: Optional OpenAI API key (defaults to OPENAI_API_KEY env var)
            timeout: Request timeout in seconds
        """
        self.model_config = model_config
        self.system_instruction = system_instruction
        self.timeout = timeout
        self._tools = None
        self._history = []
        self._last_input_tokens = 0
        self._last_output_tokens = 0

        # Initialize OpenAI async client
        from openai import AsyncOpenAI

        client_kwargs = {"timeout": timeout}
        if api_key:
            client_kwargs["api_key"] = api_key
        self._client = AsyncOpenAI(**client_kwargs)

    @property
    def model_name(self) -> str:
        """Get the current model name."""
        return self.model_config.name

    @property
    def provider_type(self) -> str:
        """Get the provider type."""
        return "openai"

    def is_openai_model(self) -> bool:
        """Check if current model is an OpenAI model."""
        return True

    def _is_reasoning_model(self) -> bool:
        """Check if current model is a reasoning model that doesn't support temperature."""
        name = self.model_config.name.lower()
        # o-series (o1, o3, o4) and gpt-5-mini are reasoning models
        return name.startswith(("o1", "o3", "o4")) or "gpt-5-mini" in name

    def initialize_chat(
        self, history: List[types.Content], tools: Optional[List[Any]] = None
    ) -> None:
        """
        Initialize or reinitialize the chat session.

        Args:
            history: Initial conversation history
            tools: Optional tools available to the model
        """
        self._tools = tools
        self._history = history or []

    # ---- Tool conversion -----------------------------------------------------

    def _convert_tools_to_openai_format(
        self, tools: Optional[List[Any]] = None
    ) -> Optional[List[Dict[str, Any]]]:
        """
        Convert framework tool declarations to OpenAI Responses API tool format.

        Args:
            tools: Tools in framework format (FunctionDeclaration objects)

        Returns:
            Tools in OpenAI format, or None
        """
        if not tools:
            return None

        openai_tools = []
        for t in tools:
            openai_tools.append(
                {
                    "type": "function",
                    "name": t.name,
                    "description": t.description or "",
                    "parameters": t.parameters or {},
                }
            )
        return openai_tools

    # ---- History conversion --------------------------------------------------

    def _convert_history_to_input(
        self, history: List[types.Content]
    ) -> List[Dict[str, Any]]:
        """
        Convert google.genai.types.Content history to OpenAI Responses API input format.

        The Responses API input format uses a list of items:
        - User messages: {"role": "user", "content": "..."}
        - Assistant messages: {"role": "assistant", "content": "..."}
        - Function calls: {"type": "function_call", "call_id": "...", "name": "...", "arguments": "..."}
        - Function results: {"type": "function_call_output", "call_id": "...", "output": "..."}

        Args:
            history: History in google.genai Content format

        Returns:
            List of input items in OpenAI Responses API format
        """
        input_items = []

        # Track tool_call IDs from model responses for matching with tool results
        # Map: function_name -> list of generated IDs (FIFO queue)
        tool_call_id_map: Dict[str, List[str]] = {}

        for content in history:
            if content.role == "user":
                text_parts = []
                function_responses = []

                for part in content.parts:
                    if hasattr(part, "text") and part.text:
                        text_parts.append(part.text)
                    elif hasattr(part, "function_response") and part.function_response:
                        fr = part.function_response
                        result = fr.response
                        result_str = (
                            json.dumps(result) if isinstance(result, dict) else str(result)
                        )

                        # Get call_id - prefer stored ID, fallback to map
                        call_id = getattr(fr, "id", None)
                        if not call_id:
                            if (
                                fr.name in tool_call_id_map
                                and tool_call_id_map[fr.name]
                            ):
                                call_id = tool_call_id_map[fr.name].pop(0)
                        else:
                            # Consume the map entry even when we have a stored ID
                            if (
                                fr.name in tool_call_id_map
                                and tool_call_id_map[fr.name]
                            ):
                                tool_call_id_map[fr.name].pop(0)

                        function_responses.append(
                            {
                                "type": "function_call_output",
                                "call_id": call_id or f"call_{uuid.uuid4().hex[:24]}",
                                "output": result_str,
                            }
                        )

                if text_parts:
                    input_items.append(
                        {"role": "user", "content": "\n".join(text_parts)}
                    )
                for fr_item in function_responses:
                    input_items.append(fr_item)

            elif content.role == "model":
                text_parts = []
                function_calls = []

                for part in content.parts:
                    if hasattr(part, "text") and part.text:
                        text_parts.append(part.text)
                    elif hasattr(part, "function_call") and part.function_call:
                        fc = part.function_call
                        call_id = getattr(fc, "id", None) or f"call_{uuid.uuid4().hex[:24]}"

                        # Track the call_id for matching with results
                        func_name = fc.name
                        if func_name not in tool_call_id_map:
                            tool_call_id_map[func_name] = []
                        tool_call_id_map[func_name].append(call_id)

                        args_dict = dict(fc.args) if fc.args else {}
                        function_calls.append(
                            {
                                "type": "function_call",
                                "call_id": call_id,
                                "name": fc.name,
                                "arguments": json.dumps(args_dict),
                            }
                        )

                if text_parts:
                    input_items.append(
                        {
                            "role": "assistant",
                            "content": [
                                {"type": "output_text", "text": "\n".join(text_parts)}
                            ],
                        }
                    )
                for fc_item in function_calls:
                    input_items.append(fc_item)

            elif content.role == "function":
                # Legacy function role - convert to function_call_output
                for part in content.parts:
                    if hasattr(part, "function_response") and part.function_response:
                        fr = part.function_response
                        result = fr.response
                        result_str = (
                            json.dumps(result) if isinstance(result, dict) else str(result)
                        )

                        call_id = getattr(fr, "id", None)
                        if not call_id:
                            if (
                                fr.name in tool_call_id_map
                                and tool_call_id_map[fr.name]
                            ):
                                call_id = tool_call_id_map[fr.name].pop(0)

                        input_items.append(
                            {
                                "type": "function_call_output",
                                "call_id": call_id or f"call_{uuid.uuid4().hex[:24]}",
                                "output": result_str,
                            }
                        )

        return input_items

    def _compress_history(self, history: List[types.Content]) -> str:
        """
        Compress conversation history into a text summary.

        Used as a fallback when history from another provider cannot be
        faithfully replayed (e.g., missing tool_call IDs or incompatible formats).

        Args:
            history: Conversation history in Content format

        Returns:
            Text summary of the conversation
        """
        if not history:
            return ""

        summary_parts = ["Previous conversation summary:"]

        for content in history:
            role_label = "User" if content.role == "user" else "Assistant"

            for part in content.parts:
                if hasattr(part, "text") and part.text:
                    summary_parts.append(f"{role_label}: {part.text}")
                elif hasattr(part, "function_call") and part.function_call:
                    summary_parts.append(
                        f"{role_label} called tool '{part.function_call.name}' "
                        f"with args: {dict(part.function_call.args)}"
                    )
                elif hasattr(part, "function_response") and part.function_response:
                    summary_parts.append(
                        f"Tool '{part.function_response.name}' returned: "
                        f"{part.function_response.response}"
                    )

        return "\n".join(summary_parts)

    # ---- API calls -----------------------------------------------------------

    async def send_message(
        self,
        message: str,
        history: List[types.Content],
        tools: Optional[List[Any]] = None,
    ) -> ProviderResponse:
        """
        Send a message to OpenAI using the Responses API.

        Args:
            message: The message to send
            history: Current conversation history
            tools: Optional tools available to the model

        Returns:
            ProviderResponse with model output
        """
        # Update internal state
        if tools != self._tools:
            self._tools = tools
        self._history = history or []

        # Build input list from history
        input_items = []
        if history:
            input_items = self._convert_history_to_input(history)

        # Append new user message
        input_items.append({"role": "user", "content": message})

        # Build API call kwargs
        create_kwargs = {
            "model": self.model_config.name,
            "input": input_items,
            "instructions": self.system_instruction,
        }

        # Add tools if available
        openai_tools = self._convert_tools_to_openai_format(tools)
        if openai_tools:
            create_kwargs["tools"] = openai_tools

        # Add optional parameters (skip temperature for reasoning models that don't support it)
        if self.model_config.temperature is not None and not self._is_reasoning_model():
            create_kwargs["temperature"] = self.model_config.temperature
        if self.model_config.max_output_tokens is not None:
            create_kwargs["max_output_tokens"] = self.model_config.max_output_tokens

        # Call the Responses API with timeout
        response = await asyncio.wait_for(
            self._client.responses.create(**create_kwargs),
            timeout=self.timeout,
        )

        return self._parse_response(response)

    async def send_function_response(
        self,
        function_response_parts: List[Any],
        history: List[types.Content],
    ) -> ProviderResponse:
        """
        Send function execution results back to OpenAI.

        The function responses are already included in the history (appended by
        the agent before calling this method). This method replays the full
        history and samples the next response.

        Args:
            function_response_parts: List of function response parts (already in history)
            history: Current conversation history (includes function responses)

        Returns:
            ProviderResponse with model's next response
        """
        self._history = history or []

        # Build input list from the full history (which includes function responses)
        input_items = self._convert_history_to_input(history) if history else []

        # Build API call kwargs
        create_kwargs = {
            "model": self.model_config.name,
            "input": input_items,
            "instructions": self.system_instruction,
        }

        # Add tools if available
        openai_tools = self._convert_tools_to_openai_format(self._tools)
        if openai_tools:
            create_kwargs["tools"] = openai_tools

        # Add optional parameters (skip temperature for reasoning models that don't support it)
        if self.model_config.temperature is not None and not self._is_reasoning_model():
            create_kwargs["temperature"] = self.model_config.temperature
        if self.model_config.max_output_tokens is not None:
            create_kwargs["max_output_tokens"] = self.model_config.max_output_tokens

        # Call the Responses API with timeout
        response = await asyncio.wait_for(
            self._client.responses.create(**create_kwargs),
            timeout=self.timeout,
        )

        return self._parse_response(response)

    # ---- Response parsing ----------------------------------------------------

    def _parse_response(self, response: Any) -> ProviderResponse:
        """
        Parse OpenAI Responses API response into standardized ProviderResponse.

        The response object has:
        - response.output: list of output items
        - response.output_text: final text output
        - response.usage: token usage info
        - response.status: "completed", "incomplete", etc.
        - Each output item has .type ("message", "function_call", "reasoning", etc.)
        - Function call items have .call_id, .name, .arguments

        Args:
            response: Raw response from OpenAI Responses API

        Returns:
            Standardized ProviderResponse
        """
        text = ""
        function_calls = []
        finish_reason = None

        if response:
            # Extract text content via output_text
            text = getattr(response, "output_text", "") or ""

            # Extract finish reason / status
            finish_reason = getattr(response, "status", None)

            # Extract and track token usage
            usage = getattr(response, "usage", None)
            if usage:
                self._last_input_tokens = getattr(usage, "input_tokens", 0) or 0
                self._last_output_tokens = getattr(usage, "output_tokens", 0) or 0

            # Extract function calls from output items
            output_items = getattr(response, "output", None)
            if output_items:
                for item in output_items:
                    if getattr(item, "type", None) == "function_call":
                        try:
                            args_str = getattr(item, "arguments", "{}")
                            args = (
                                json.loads(args_str)
                                if isinstance(args_str, str)
                                else args_str
                            )
                        except (json.JSONDecodeError, AttributeError):
                            args = {}

                        function_calls.append(
                            {
                                "name": getattr(item, "name", ""),
                                "args": args,
                                "id": getattr(item, "call_id", None),
                                "raw": item,
                            }
                        )

        return ProviderResponse(
            text=text,
            function_calls=function_calls,
            raw_response=response,
            finish_reason=finish_reason,
        )

    def is_malformed_response(self, response: Any) -> bool:
        """
        Check if response is malformed.

        A response is only malformed if the response object itself is None/empty.
        An empty-string output_text (e.g. "") is NOT malformed — OpenAI can
        return empty text as a valid signal after tool calls. We use `is not None`
        instead of truthiness to avoid false positives on empty strings.

        Args:
            response: Response to check

        Returns:
            True if response is malformed
        """
        if not response:
            return True

        # Has text content (including empty string — that's a valid response)
        if hasattr(response, "output_text") and getattr(response, "output_text", None) is not None:
            return False
        # Has output items with function calls
        output_items = getattr(response, "output", None)
        if output_items:
            for item in output_items:
                if getattr(item, "type", None) == "function_call":
                    return False
        return True

    def count_tokens(
        self, messages: List[Dict[str, Any]], tools: Optional[List[Any]] = None
    ) -> int:
        """
        Count tokens based on actual usage from the latest response.

        Args:
            messages: List of messages (not used, kept for interface compatibility)
            tools: Optional tools (not used, kept for interface compatibility)

        Returns:
            Total token count from latest API call
        """
        return self._last_input_tokens + self._last_output_tokens

    def get_chat_history(self) -> List[types.Content]:
        """Get current chat history."""
        return self._history

    def get_last_input_tokens(self) -> int:
        """Get input tokens from the latest API call."""
        return self._last_input_tokens

    def get_last_output_tokens(self) -> int:
        """Get output tokens from the latest API call."""
        return self._last_output_tokens

    def update_system_instruction(
        self, new_instruction: str, history: List[types.Content]
    ) -> None:
        """
        Update system instruction and reinitialize chat.

        Args:
            new_instruction: New system instruction
            history: Current conversation history to preserve
        """
        self.system_instruction = new_instruction
        self.initialize_chat(history, self._tools)
