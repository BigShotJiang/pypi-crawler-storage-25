"""
Tool registry for managing default and custom tools.
"""

import json
import re
from pathlib import Path
from typing import Annotated, Callable, Dict, List, Optional

from em_agent_framework.core.tools.decorators import tool


class InstructionLibrary:
    """Manages instruction templates that can be loaded dynamically."""

    def __init__(self, instructions_file: Optional[str] = None):
        """
        Initialize instruction library.

        Args:
            instructions_file: Path to JSON file with instruction templates
        """
        self.instructions_file = instructions_file
        self.instructions: Dict[str, Dict[str, str]] = {}
        self.loaded_instruction_ids: set = set()

        if instructions_file and Path(instructions_file).exists():
            self._load_instructions()

    def _load_instructions(self) -> None:
        """Load instructions from JSON file."""
        try:
            with open(self.instructions_file, encoding="utf-8") as f:
                file_content = f.read()
                file_length = len(file_content)
                print(f"[InstructionLibrary] Loading from: {self.instructions_file}")
                print(f"[InstructionLibrary] File size: {file_length} characters ({file_length / 1024:.2f} KB)")

                data = json.loads(file_content)
                # Expected format: {"instructions": [{"id": "...", "description": "...", "instruction": "..."}]}
                if isinstance(data, dict) and "instructions" in data:
                    for item in data["instructions"]:
                        self.instructions[item["id"]] = {
                            "description": item.get("description", ""),
                            "instruction": item.get("instruction", ""),
                        }

                print(f"[InstructionLibrary] Loaded {len(self.instructions)} instruction templates:")
                for inst_id, inst_data in self.instructions.items():
                    inst_len = len(inst_data["instruction"])
                    print(f"  - {inst_id}: {inst_data['description']} ({inst_len} chars)")
        except Exception as e:
            print(f"[InstructionLibrary] Failed to load instructions: {e}")

    def get_short_descriptions(self) -> str:
        """
        Get short descriptions of all available instructions for system prompt.

        Returns:
            Formatted string with ID and description of each instruction
        """
        if not self.instructions:
            return "No additional instructions available."

        lines = ["Available instruction templates:"]
        for inst_id, data in self.instructions.items():
            lines.append(f"  - {inst_id}: {data['description']}")
        return "\n".join(lines)

    def get_instruction(self, instruction_id: str) -> Optional[str]:
        """
        Get full instruction text by ID.

        Args:
            instruction_id: ID of the instruction to retrieve

        Returns:
            Full instruction text, or None if not found
        """
        if instruction_id in self.instructions:
            self.loaded_instruction_ids.add(instruction_id)
            instruction_text = self.instructions[instruction_id]["instruction"]
            print(f"[InstructionLibrary] Loading instruction '{instruction_id}'")
            print(f"[InstructionLibrary] Instruction length: {len(instruction_text)} characters")
            print(f"[InstructionLibrary] Instruction content preview: {instruction_text[:200]}...")
            return instruction_text

        print(f"[InstructionLibrary] Instruction '{instruction_id}' not found")
        return None

    def list_available_ids(self) -> List[str]:
        """List all available instruction IDs."""
        return list(self.instructions.keys())

    def is_loaded(self, instruction_id: str) -> bool:
        """Check if an instruction has been loaded."""
        return instruction_id in self.loaded_instruction_ids


class SkillLibrary:
    """Manages agent skills stored as markdown files with YAML frontmatter.

    Each skill is a .md file in a skills directory with the format:
        ---
        name: skill-name
        description: Short description of the skill
        ---
        Full skill content (loaded on demand via load_skill tool).
    """

    _FRONTMATTER_RE = re.compile(r"^---\s*\n(.+?)\n---\s*\n", re.DOTALL)
    _FIELD_RE = re.compile(r"^(\w+):\s*(.+)$", re.MULTILINE)

    def __init__(self, skills_dir: str):
        self.skills_dir = Path(skills_dir)
        self.skills: Dict[str, Dict[str, str]] = {}  # name -> {description, file_path}
        self.loaded_skill_names: set = set()

        if self.skills_dir.is_dir():
            self._load_skills()

    def _parse_frontmatter(self, content: str) -> Optional[Dict[str, str]]:
        """Parse YAML frontmatter from markdown content."""
        match = self._FRONTMATTER_RE.match(content)
        if not match:
            return None
        fields = {}
        for m in self._FIELD_RE.finditer(match.group(1)):
            fields[m.group(1).strip()] = m.group(2).strip()
        return fields

    def _load_skills(self) -> None:
        """Scan skills directory and index all .md skill files."""
        try:
            md_files = sorted(self.skills_dir.rglob("*.md"))
            print(f"[SkillLibrary] Scanning: {self.skills_dir}")

            for md_file in md_files:
                try:
                    content = md_file.read_text(encoding="utf-8")
                    meta = self._parse_frontmatter(content)
                    if meta and "name" in meta:
                        name = meta["name"]
                        description = meta.get("description", "")
                        self.skills[name] = {
                            "description": description,
                            "file_path": str(md_file),
                        }
                    else:
                        print(f"[SkillLibrary] Skipping {md_file.name}: missing frontmatter or name field")
                except Exception as e:
                    print(f"[SkillLibrary] Failed to read {md_file}: {e}")

            print(f"[SkillLibrary] Loaded {len(self.skills)} skills:")
            for skill_name, data in self.skills.items():
                print(f"  - {skill_name}: {data['description']}")
        except Exception as e:
            print(f"[SkillLibrary] Failed to scan skills directory: {e}")

    def get_short_descriptions(self) -> str:
        """Get short descriptions of all available skills for system prompt."""
        if not self.skills:
            return "No agent skills available."

        lines = ["Available agent skills (use load_skill to activate):"]
        for name, data in self.skills.items():
            lines.append(f"  - {name}: {data['description']}")
        return "\n".join(lines)

    def get_skill_content(self, skill_name: str) -> Optional[str]:
        """Get the full markdown content of a skill (everything after frontmatter)."""
        if skill_name not in self.skills:
            print(f"[SkillLibrary] Skill '{skill_name}' not found")
            return None

        file_path = self.skills[skill_name]["file_path"]
        try:
            content = Path(file_path).read_text(encoding="utf-8")
            # Strip the frontmatter, return the body
            match = self._FRONTMATTER_RE.match(content)
            body = content[match.end():] if match else content
            body = body.strip()

            self.loaded_skill_names.add(skill_name)
            print(f"[SkillLibrary] Loading skill '{skill_name}' ({len(body)} chars)")
            return body
        except Exception as e:
            print(f"[SkillLibrary] Failed to read skill '{skill_name}': {e}")
            return None

    def list_available_names(self) -> List[str]:
        """List all available skill names."""
        return list(self.skills.keys())

    def is_loaded(self, skill_name: str) -> bool:
        """Check if a skill has been loaded."""
        return skill_name in self.loaded_skill_names


class ToolRegistry:
    """
    Registry for managing agent tools including default tools.
    """

    def __init__(
        self,
        instruction_library: Optional[InstructionLibrary] = None,
        skill_library: Optional[SkillLibrary] = None,
    ):
        """
        Initialize tool registry.

        Args:
            instruction_library: Optional instruction library for load_instructions tool
            skill_library: Optional skill library for load_skill tool
        """
        self.instruction_library = instruction_library
        self.skill_library = skill_library
        self._default_tools: Dict[str, Callable] = {}
        self._custom_tools: Dict[str, Callable] = {}

    def create_search_tool(
        self, complementary_tools: List[Callable], add_tool_callback: Callable[[Callable], None]
    ) -> Callable:
        """
        Create a search_tool that allows adding complementary tools dynamically.

        Args:
            complementary_tools: List of complementary tools that can be added
            add_tool_callback: Callback function to add tool to active tools

        Returns:
            search_tool function
        """
        complementary_dict = {tool.__name__: tool for tool in complementary_tools}
        available_tools = ", ".join(complementary_dict.keys()) or "none"

        @tool(
            description=f"Search for and add a complementary tool to active tools from available tools: {available_tools}"
        )
        def search_tool(
            tool_name: Annotated[
                str, f"Name of the complementary tool to add. Available: {available_tools}"
            ],
        ) -> str:
            """Search for and add a complementary tool to active tools."""
            if tool_name not in complementary_dict:
                return f"Tool '{tool_name}' not found currently. They could be added dynamically based on location. Are you at the correct location? Available: {', '.join(complementary_dict.keys())}"

            # Add tool via callback
            try:
                add_tool_callback(complementary_dict[tool_name])
                print(f"[search_tool] Tool '{tool_name}' loaded into active tools")
                return f"Successfully added tool '{tool_name}' to active tools."
            except Exception as e:
                return f"Failed to add tool '{tool_name}': {str(e)}"

        return search_tool

    def create_load_instructions_tool(
        self, update_system_instruction_callback: Callable[[str], None]
    ) -> Callable:
        """
        Create a load_instructions tool that loads instruction templates.

        Args:
            update_system_instruction_callback: Callback to update system instruction

        Returns:
            load_instructions function
        """
        if not self.instruction_library:
            raise ValueError("InstructionLibrary not configured")

        available_ids = self.instruction_library.list_available_ids()
        available_str = ", ".join(available_ids) if available_ids else "none"

        @tool(
            description=f"Load additional instructions into the system prompt from available instruction IDs: {available_str}"
        )
        def load_instructions(
            instruction_id: Annotated[
                str, f"ID of the instruction to load. Available: {available_str}"
            ],
        ) -> str:
            """Load additional instructions into the system prompt."""
            print(f"[load_instructions] Tool invoked with instruction_id: '{instruction_id}'")

            # Check if already loaded
            if self.instruction_library.is_loaded(instruction_id):
                msg = f"Instruction '{instruction_id}' is already loaded."
                print(f"[load_instructions] {msg}")
                return msg

            # Get instruction text
            instruction_text = self.instruction_library.get_instruction(instruction_id)
            if instruction_text is None:
                msg = f"Instruction '{instruction_id}' not found. Available: {available_str}"
                print(f"[load_instructions] {msg}")
                return msg

            # Update system instruction via callback
            try:
                print(f"[load_instructions] Calling update callback with {len(instruction_text)} character instruction")
                update_system_instruction_callback(instruction_text)
                msg = f"Successfully loaded instruction '{instruction_id}'."
                print(f"[load_instructions] {msg}")
                return msg
            except Exception as e:
                msg = f"Failed to load instruction '{instruction_id}': {str(e)}"
                print(f"[load_instructions] {msg}")
                return msg

        return load_instructions

    def create_load_skill_tool(
        self, update_system_instruction_callback: Callable[[str], None]
    ) -> Callable:
        """Create a load_skill tool that loads agent skills into the system prompt."""
        if not self.skill_library:
            raise ValueError("SkillLibrary not configured")

        available_names = self.skill_library.list_available_names()
        available_str = ", ".join(available_names) if available_names else "none"

        @tool(
            description=f"Load an agent skill into the system prompt. Available skills: {available_str}"
        )
        def load_skill(
            skill_name: Annotated[
                str, f"Name of the skill to load. Available: {available_str}"
            ],
        ) -> str:
            """Load an agent skill into the system prompt."""
            print(f"[load_skill] Tool invoked with skill_name: '{skill_name}'")

            if self.skill_library.is_loaded(skill_name):
                msg = f"Skill '{skill_name}' is already loaded."
                print(f"[load_skill] {msg}")
                return msg

            skill_content = self.skill_library.get_skill_content(skill_name)
            if skill_content is None:
                msg = f"Skill '{skill_name}' not found. Available: {available_str}"
                print(f"[load_skill] {msg}")
                return msg

            try:
                print(f"[load_skill] Calling update callback with {len(skill_content)} character skill")
                update_system_instruction_callback(skill_content)
                msg = f"Successfully loaded skill '{skill_name}'."
                print(f"[load_skill] {msg}")
                return msg
            except Exception as e:
                msg = f"Failed to load skill '{skill_name}': {str(e)}"
                print(f"[load_skill] {msg}")
                return msg

        return load_skill

    def create_recursive_agent_call_tool(
        self,
        agent_instance: "Agent",  # Forward reference to avoid circular import
    ) -> Callable:
        """
        Create a recursive_agent_call tool that spawns sub-agents for subtasks.

        Args:
            agent_instance: The parent agent instance

        Returns:
            recursive_agent_call function
        """

        @tool(
            description="Spawn a sub-agent to work on a subtask in parallel. Use this when you need to break down a complex task into independent pieces that can be solved separately."
        )
        async def recursive_agent_call(
            subtask: Annotated[
                str, "Description of the subtask to be handled by the sub-agent"
            ],
        ) -> str:
            """
            Spawn a sub-agent to handle a subtask.

            Returns a JSON string with the result and metadata including agent_id and parent_agent_id.
            """
            # Check recursion depth limit
            if agent_instance.recursion_depth >= agent_instance.agent_config.max_recursion_depth:
                return json.dumps({
                    "error": "Maximum recursion depth exceeded",
                    "max_depth": agent_instance.agent_config.max_recursion_depth,
                    "current_depth": agent_instance.recursion_depth,
                })

            # Import Agent here to avoid circular import
            from em_agent_framework.core.agent import Agent

            # Filter out default tools (recursive_agent_call, load_instructions, search_tool)
            # These will be re-added by _add_default_tools()
            default_tool_names = {'recursive_agent_call', 'load_instructions', 'load_skill', 'search_tool'}
            user_tools = [
                tool for tool in agent_instance.tools
                if tool.__name__ not in default_tool_names
            ] if hasattr(agent_instance, 'tools') else []

            # Create sub-agent with same configuration but incremented depth
            sub_agent = Agent(
                name=f"{agent_instance.name}_sub_{agent_instance.recursion_depth + 1}",
                system_instruction=agent_instance.system_instruction,
                tools=user_tools,  # Only pass user-defined tools, not default tools
                complementary_tools=agent_instance.complementary_tools.copy() if hasattr(agent_instance, 'complementary_tools') else [],
                context=agent_instance.context.copy() if agent_instance.context else {},
                model_configs=agent_instance.model_configs,
                agent_config=agent_instance.agent_config,
                project_id=agent_instance.project_id,
                location=agent_instance.location,
                instructions_file=None,  # Don't duplicate instruction file
                skills_dir=None,  # Don't duplicate skills directory
                parent_agent_id=agent_instance.id,
                recursion_depth=agent_instance.recursion_depth + 1,
            )

            try:
                # Execute subtask
                result = await sub_agent.send_message(subtask)

                # Return result with metadata
                return json.dumps({
                    "result": result,
                    "agent_id": sub_agent.id,
                    "parent_agent_id": sub_agent.parent_agent_id,
                    "recursion_depth": sub_agent.recursion_depth,
                    "subtask": subtask,
                })
            except Exception as e:
                return json.dumps({
                    "error": str(e),
                    "agent_id": sub_agent.id,
                    "parent_agent_id": sub_agent.parent_agent_id,
                    "recursion_depth": sub_agent.recursion_depth,
                    "subtask": subtask,
                })

        return recursive_agent_call

    def register_default_tool(self, name: str, tool: Callable) -> None:
        """Register a default tool."""
        self._default_tools[name] = tool

    def register_custom_tool(self, name: str, tool: Callable) -> None:
        """Register a custom tool."""
        self._custom_tools[name] = tool

    def get_tool(self, name: str) -> Optional[Callable]:
        """Get a tool by name."""
        return self._default_tools.get(name) or self._custom_tools.get(name)

    def get_all_tools(self) -> List[Callable]:
        """Get all registered tools."""
        return list(self._default_tools.values()) + list(self._custom_tools.values())
