"""spawner — CLI + TUI game server manager."""

import argparse
import shutil
import sys
from pathlib import Path

import psutil

from src.profiles import get_profile, load_profiles, remove_profile
from src.servers.minecraft import MinecraftServer
from src.system import is_port_free


# ── helpers ────────────────────────────────────────────────────────────


def _ensure_jar(profile: dict) -> None:
    """Download the server jar if it doesn't exist yet."""
    jar_path = Path(profile["jar"]).expanduser()
    if jar_path.exists():
        return
    from src.downloader import download_jar, print_progress

    print(f"Downloading {profile['type']} {profile['version']} jar...")
    download_jar(
        profile["type"],
        profile["version"],
        dest=jar_path,
        progress_callback=print_progress,
    )


def _check_java() -> None:
    """Exit with an error if java is not on PATH."""
    if not MinecraftServer.is_java_available():
        print("Error: Java is not installed or not on PATH.")
        print("Install Java 17+ and try again.")
        sys.exit(1)


def _find_server_process(profile: dict) -> psutil.Process | None:
    """Return the running server process for a profile, or None."""
    pid = MinecraftServer.read_pid_file(profile["directory"])
    if pid is None:
        return None
    try:
        proc = psutil.Process(pid)
        if proc.is_running() and proc.status() != psutil.STATUS_ZOMBIE:
            return proc
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        pass
    return None


def _launch_tui(profile: dict) -> None:
    """Download jar if needed and launch the TUI."""
    _check_java()
    if not is_port_free(profile["port"]):
        proc = _find_server_process(profile)
        if proc is not None:
            print(
                f"Error: server '{profile['name']}' is already running "
                f"(PID {proc.pid})."
            )
            sys.exit(1)
        print(
            f"Warning: port {profile['port']} is in use by another "
            f"process. The server may fail to bind."
        )
    _ensure_jar(profile)
    from src.tui.app import ServerApp

    app = ServerApp(profile)
    app.run()


# ── commands ───────────────────────────────────────────────────────────


def cmd_start(args: argparse.Namespace) -> None:
    """Run setup wizard or relaunch a saved profile."""
    if args.name:
        profile = get_profile(args.name)
        if not profile:
            print(f"Error: no profile named '{args.name}'")
            sys.exit(1)
        _launch_tui(profile)
    else:
        from src.wizard import run_wizard

        profile = run_wizard()
        if profile is not None:
            _launch_tui(profile)


def cmd_list(args: argparse.Namespace) -> None:
    """Print table of all saved profiles."""
    profiles = load_profiles()
    if not profiles:
        print("No saved profiles.")
        return
    header = (
        f"{'Name':<20} {'Type':<10} {'Version':<10} "
        f"{'Port':<8} {'RAM':<6} {'Status':<10}"
    )
    print(header)
    print("-" * len(header))
    for p in profiles:
        proc = _find_server_process(p)
        status = "running" if proc else "stopped"
        print(
            f"{p['name']:<20} {p['type']:<10} {p['version']:<10} "
            f"{p['port']:<8} {p['ram']:<6} {status:<10}"
        )


def cmd_delete(args: argparse.Namespace) -> None:
    """Delete a saved profile and optionally its directory."""
    profile = get_profile(args.name)
    if not profile:
        print(f"Error: no profile named '{args.name}'")
        sys.exit(1)

    # Check not running
    proc = _find_server_process(profile)
    if proc is not None:
        print(
            f"Error: server '{args.name}' is running (PID {proc.pid}). "
            f"Stop it first with: spawner stop {args.name}"
        )
        sys.exit(1)

    directory = Path(profile["directory"]).expanduser()

    # Confirm deletion
    answer = input(
        f"Delete profile '{args.name}'? [y/N] "
    ).strip().lower()
    if answer != "y":
        print("Cancelled.")
        return

    # Ask about directory
    if directory.exists():
        dir_answer = input(
            f"Also delete server directory {directory}? [y/N] "
        ).strip().lower()
        if dir_answer == "y":
            shutil.rmtree(directory)
            print(f"Deleted directory: {directory}")

    remove_profile(args.name)
    print(f"Profile '{args.name}' deleted.")


def cmd_stop(args: argparse.Namespace) -> None:
    """Gracefully stop a running server from outside the TUI."""
    profile = get_profile(args.name)
    if not profile:
        print(f"Error: no profile named '{args.name}'")
        sys.exit(1)

    proc = _find_server_process(profile)
    if proc is None:
        print(f"Server '{args.name}' is not running.")
        return

    print(f"Stopping '{args.name}' (PID {proc.pid})...")
    try:
        proc.terminate()
        proc.wait(timeout=30)
    except psutil.TimeoutExpired:
        print("Force killing...")
        proc.kill()
        proc.wait()

    # Clean up PID file
    pid_file = Path(profile["directory"]).expanduser() / ".spawner.pid"
    pid_file.unlink(missing_ok=True)

    # Clean up UPnP
    if profile.get("upnp"):
        from src.upnp import remove_port_mapping

        if remove_port_mapping(profile["port"]):
            print("UPnP port mapping removed.")

    print(f"Server '{args.name}' stopped.")


def cmd_restart(args: argparse.Namespace) -> None:
    """Restart a running server: stop then launch TUI."""
    profile = get_profile(args.name)
    if not profile:
        print(f"Error: no profile named '{args.name}'")
        sys.exit(1)

    proc = _find_server_process(profile)
    if proc is not None:
        print(f"Stopping '{args.name}' (PID {proc.pid})...")
        try:
            proc.terminate()
            proc.wait(timeout=30)
        except psutil.TimeoutExpired:
            proc.kill()
            proc.wait()
        pid_file = (
            Path(profile["directory"]).expanduser() / ".spawner.pid"
        )
        pid_file.unlink(missing_ok=True)
        print("Stopped.")

    print(f"Starting '{args.name}'...")
    _launch_tui(profile)


# ── parser ─────────────────────────────────────────────────────────────


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="spawner",
        description="CLI + TUI game server manager",
    )
    subparsers = parser.add_subparsers(dest="command")

    p_start = subparsers.add_parser(
        "start", help="Launch setup wizard or saved profile"
    )
    p_start.add_argument(
        "name", nargs="?", default=None,
        help="Profile name to relaunch",
    )
    p_start.set_defaults(func=cmd_start)

    p_list = subparsers.add_parser("list", help="List saved profiles")
    p_list.set_defaults(func=cmd_list)

    p_delete = subparsers.add_parser(
        "delete", help="Delete a saved profile"
    )
    p_delete.add_argument("name", help="Profile name to delete")
    p_delete.set_defaults(func=cmd_delete)

    p_stop = subparsers.add_parser(
        "stop", help="Stop a running server"
    )
    p_stop.add_argument("name", help="Profile name to stop")
    p_stop.set_defaults(func=cmd_stop)

    p_restart = subparsers.add_parser(
        "restart", help="Restart a running server"
    )
    p_restart.add_argument("name", help="Profile name to restart")
    p_restart.set_defaults(func=cmd_restart)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    if args.command is None:
        parser.print_help()
        sys.exit(0)
    args.func(args)


if __name__ == "__main__":
    main()
