"""Main TUI application — 3-panel layout with server management."""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any

from textual import work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.widgets import Button, Header, Input, Static

from src.servers.base import ServerStatus
from src.servers.minecraft import MinecraftServer
from src.system import get_local_ip, get_public_ip
from src.tui.widgets.console import ConsoleWidget
from src.tui.widgets.filebrowser import FileBrowserScreen
from src.tui.widgets.playerlist import PlayerListWidget
from src.tui.widgets.resources import ResourcesWidget
from src.upnp import remove_port_mapping


def _format_uptime(seconds: float) -> str:
    s = int(seconds)
    h, s = divmod(s, 3600)
    m, s = divmod(s, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


_STATUS_DISPLAY = {
    ServerStatus.STARTING: ("\u25cb starting", "yellow"),
    ServerStatus.RUNNING: ("\u25cf running", "green"),
    ServerStatus.STOPPED: ("\u25cb stopped", "red"),
    ServerStatus.CRASHED: ("\u2716 crashed", "red"),
}


class ServerApp(App):
    """Interactive TUI for managing a running game server."""

    TITLE = "spawner"
    BINDINGS = [
        Binding("s", "stop_server", "Stop", show=True),
        Binding("r", "restart_server", "Restart", show=True),
        Binding("c", "toggle_command", "Command", show=True),
        Binding("f", "open_files", "Files", show=True),
        Binding("q", "quit_app", "Quit", show=True),
    ]

    CSS = """
    Screen { layout: vertical; }

    #tui-header {
        height: 2;
        padding: 0 2;
        background: $boost;
        color: $text;
    }
    #tui-header-line1 { text-style: bold; }
    #tui-header-line2 { color: $text-muted; }

    #main-panels {
        height: 1fr;
        layout: horizontal;
    }

    #footer-bar {
        height: 3;
        layout: horizontal;
        align: center middle;
        padding: 0 1;
        background: $surface;
        border-top: solid $primary;
    }
    #footer-bar Button { margin: 0 1; }

    #cmd-bar {
        height: 3;
        padding: 0 2;
        background: $panel;
        layout: horizontal;
        align: left middle;
    }
    #cmd-bar Static { width: auto; margin-right: 1; }
    #cmd-bar Input { width: 1fr; }
    """

    def __init__(self, profile: dict[str, Any]) -> None:
        super().__init__()
        self.profile = profile
        self.server = MinecraftServer(
            name=profile["name"],
            server_type=profile["type"],
            version=profile["version"],
            jar=profile["jar"],
            directory=profile["directory"],
            ram=profile["ram"],
            cores=profile["cores"],
            port=profile["port"],
        )
        self._local_ip = get_local_ip()
        self._public_ip: str = "fetching..."
        self._upnp = profile.get("upnp", False)

    def compose(self) -> ComposeResult:
        yield Header()
        with Vertical(id="tui-header"):
            yield Static("", id="tui-header-line1")
            yield Static("", id="tui-header-line2")
        with Horizontal(id="main-panels"):
            yield ConsoleWidget(id="console")
            yield PlayerListWidget(id="players")
            yield ResourcesWidget(id="resources")
        with Horizontal(id="footer-bar"):
            yield Button("Stop", id="btn-stop", variant="error")
            yield Button("Restart", id="btn-restart", variant="warning")
            yield Button("Command", id="btn-command", variant="primary")
            yield Button("Files", id="btn-files", variant="default")
            yield Button("Quit", id="btn-quit")
        with Horizontal(id="cmd-bar"):
            yield Static(">")
            yield Input(placeholder="Enter server command...", id="cmd-input")

    def on_mount(self) -> None:
        # Hide command bar initially
        self.query_one("#cmd-bar").display = False

        # Set up log callback
        self.server.set_log_callback(self._on_log_line)

        # Start server
        self.server.start()

        # Monitor PID for resources widget
        if self.server._process is not None:
            self.query_one(ResourcesWidget).set_pid(
                self.server._process.pid
            )

        # Timers
        self.set_interval(1.0, self._update_header)
        self.set_interval(2.0, self._update_players)

        # Fetch public IP in background
        self._fetch_public_ip()

    def _on_log_line(self, line: str) -> None:
        """Called from server's log-reader thread."""
        try:
            self.call_from_thread(self._append_log, line)
        except Exception:
            pass

    def _append_log(self, line: str) -> None:
        self.query_one(ConsoleWidget).write(line)
        # Update resource PID when process starts
        if (
            self.server.status == ServerStatus.RUNNING
            and self.server._process is not None
        ):
            res = self.query_one(ResourcesWidget)
            if res._pid is None:
                res.set_pid(self.server._process.pid)

    def _update_header(self) -> None:
        status_text, _color = _STATUS_DISPLAY.get(
            self.server.status, ("\u25cb unknown", "white")
        )
        uptime = _format_uptime(self.server.uptime_seconds)
        name = self.profile["name"]
        port = self.profile["port"]

        line1 = (
            f"spawner  \u00b7  {name}  \u00b7  {status_text}"
            f"  \u00b7  uptime: {uptime}"
        )
        line2 = f"local: {self._local_ip}:{port}"
        if self._upnp:
            line2 += f"   public: {self._public_ip}:{port}"
        else:
            line2 += f"   public: {self._public_ip}:{port}  \u26a0 not port forwarded"

        try:
            self.query_one("#tui-header-line1", Static).update(line1)
            self.query_one("#tui-header-line2", Static).update(line2)
        except Exception:
            pass

    def _update_players(self) -> None:
        players = self.server.get_players()
        try:
            self.query_one(PlayerListWidget).update_players(players)
        except Exception:
            pass

    @work(thread=True)
    def _fetch_public_ip(self) -> None:
        ip = get_public_ip()
        self._public_ip = ip

    # ── Player actions ─────────────────────────────────────────────

    def on_player_list_widget_player_action(
        self, event: PlayerListWidget.PlayerAction
    ) -> None:
        cmd_map = {
            "op": f"op {event.player}",
            "kick": f"kick {event.player}",
            "ban": f"ban {event.player}",
        }
        cmd = cmd_map.get(event.action)
        if cmd:
            self.server.send_command(cmd)
            self.notify(f"Sent: {cmd}")

    # ── Button handlers ────────────────────────────────────────────

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn = event.button.id or ""
        if btn == "btn-stop":
            self.action_stop_server()
        elif btn == "btn-restart":
            self.action_restart_server()
        elif btn == "btn-command":
            self.action_toggle_command()
        elif btn == "btn-files":
            self.action_open_files()
        elif btn == "btn-quit":
            self.action_quit_app()

    # ── Command input ──────────────────────────────────────────────

    def action_toggle_command(self) -> None:
        cmd_bar = self.query_one("#cmd-bar")
        cmd_bar.display = not cmd_bar.display
        if cmd_bar.display:
            self.query_one("#cmd-input", Input).focus()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "cmd-input":
            cmd = event.value.strip()
            if cmd:
                self.server.send_command(cmd)
                self.query_one(ConsoleWidget).write(f"> {cmd}")
            event.input.value = ""
            self.query_one("#cmd-bar").display = False

    # ── File browser ───────────────────────────────────────────────

    def action_open_files(self) -> None:
        self.push_screen(
            FileBrowserScreen(self.profile["directory"])
        )

    # ── Server lifecycle ───────────────────────────────────────────

    def action_stop_server(self) -> None:
        if self.server.status in (
            ServerStatus.RUNNING,
            ServerStatus.STARTING,
        ):
            self.notify("Stopping server...")
            self._do_stop()

    @work(thread=True)
    def _do_stop(self) -> None:
        self.server.stop()
        self.app.call_from_thread(
            self.notify, "Server stopped"
        )

    def action_restart_server(self) -> None:
        self.notify("Restarting server...")
        self._do_restart()

    @work(thread=True)
    def _do_restart(self) -> None:
        self.server.restart()
        if self.server._process is not None:
            pid = self.server._process.pid
            self.app.call_from_thread(
                self.query_one(ResourcesWidget).set_pid, pid
            )
        self.app.call_from_thread(self.notify, "Server restarted")

    def action_quit_app(self) -> None:
        self._do_quit()

    @work(thread=True)
    def _do_quit(self) -> None:
        # Stop server gracefully
        if self.server.status in (
            ServerStatus.RUNNING,
            ServerStatus.STARTING,
        ):
            self.server.stop()
        # Clean up UPnP
        if self._upnp:
            remove_port_mapping(self.profile["port"])
        self.app.call_from_thread(self.exit)
