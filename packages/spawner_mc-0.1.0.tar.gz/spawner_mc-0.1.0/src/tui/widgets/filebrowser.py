"""File browser — overlay screen with directory tree and inline editor."""

from __future__ import annotations

from pathlib import Path

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import (
    Button,
    DirectoryTree,
    Static,
    TextArea,
)


class FileBrowserScreen(ModalScreen):
    """Full-screen overlay: browse server files, edit in-place."""

    BINDINGS = [
        Binding("ctrl+s", "save", "Save", show=True),
        Binding("escape", "close", "Close", show=True),
    ]

    DEFAULT_CSS = """
    FileBrowserScreen {
        align: center middle;
    }
    FileBrowserScreen #fb-root {
        width: 90%;
        height: 90%;
        border: thick $accent;
        background: $surface;
    }
    FileBrowserScreen #fb-header {
        height: 1;
        background: $boost;
        padding: 0 1;
        layout: horizontal;
    }
    FileBrowserScreen #fb-title {
        width: 1fr;
        text-style: bold;
    }
    FileBrowserScreen #fb-close {
        min-width: 5;
    }
    FileBrowserScreen #fb-breadcrumb {
        height: 1;
        padding: 0 1;
        color: $text-muted;
    }
    FileBrowserScreen #fb-body {
        height: 1fr;
        layout: horizontal;
    }
    FileBrowserScreen DirectoryTree {
        width: 30;
        border-right: solid $primary;
    }
    FileBrowserScreen #fb-editor-pane {
        width: 1fr;
    }
    FileBrowserScreen TextArea {
        height: 1fr;
    }
    FileBrowserScreen #fb-status {
        height: 1;
        padding: 0 1;
        color: $text-muted;
    }
    FileBrowserScreen #fb-footer {
        height: 3;
        padding: 0 1;
        layout: horizontal;
        align: left middle;
    }
    FileBrowserScreen #fb-footer Button {
        margin: 0 1;
    }
    """

    def __init__(self, directory: str | Path) -> None:
        super().__init__()
        self.directory = Path(directory).expanduser()
        self._current_file: Path | None = None

    def compose(self) -> ComposeResult:
        with Vertical(id="fb-root"):
            with Horizontal(id="fb-header"):
                yield Static("File Browser", id="fb-title")
                yield Button("\u2715", id="fb-close", variant="error")
            yield Static(str(self.directory), id="fb-breadcrumb")
            with Horizontal(id="fb-body"):
                yield DirectoryTree(
                    str(self.directory), id="fb-tree"
                )
                with Vertical(id="fb-editor-pane"):
                    yield TextArea(
                        "",
                        id="fb-editor",
                        language=None,
                        read_only=True,
                    )
            yield Static(
                "Click a file to view/edit. Ctrl+S to save.",
                id="fb-status",
            )
            with Horizontal(id="fb-footer"):
                yield Button("Save", id="fb-save", variant="primary")
                yield Button("Close", id="fb-close-btn")

    def on_directory_tree_file_selected(
        self, event: DirectoryTree.FileSelected
    ) -> None:
        """Load selected file into the editor."""
        path = Path(event.path)
        self._current_file = path
        try:
            self.query_one("#fb-breadcrumb", Static).update(str(path))
        except Exception:
            pass
        try:
            content = path.read_text(encoding="utf-8", errors="replace")
            editor = self.query_one("#fb-editor", TextArea)
            editor.read_only = False
            editor.load_text(content)
            self.query_one("#fb-status", Static).update(
                f"Editing: {path.name}"
            )
        except Exception as exc:
            self.query_one("#fb-status", Static).update(
                f"Cannot open: {exc}"
            )

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id or ""
        if btn_id in ("fb-close", "fb-close-btn"):
            self.dismiss()
            event.stop()
        elif btn_id == "fb-save":
            self.action_save()
            event.stop()

    def action_save(self) -> None:
        """Save the current file."""
        if self._current_file is None:
            self.notify("No file open", severity="warning")
            return
        try:
            editor = self.query_one("#fb-editor", TextArea)
            self._current_file.write_text(
                editor.text, encoding="utf-8"
            )
            self.query_one("#fb-status", Static).update(
                f"Saved: {self._current_file.name}"
            )
            self.notify(f"Saved {self._current_file.name}")
        except Exception as exc:
            self.notify(f"Save failed: {exc}", severity="error")

    def action_close(self) -> None:
        self.dismiss()
