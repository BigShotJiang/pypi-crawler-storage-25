"""Console widget — scrolling log output with auto-scroll."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.widget import Widget
from textual.widgets import RichLog, Static


class ConsoleWidget(Widget):
    """Live server log output with auto-scroll."""

    DEFAULT_CSS = """
    ConsoleWidget {
        height: 1fr;
        border: solid $primary;
    }
    ConsoleWidget #console-title {
        height: 1;
        background: $boost;
        padding: 0 1;
        text-style: bold;
    }
    ConsoleWidget RichLog {
        height: 1fr;
    }
    """

    def compose(self) -> ComposeResult:
        yield Static("Console", id="console-title")
        yield RichLog(id="log-output", auto_scroll=True, wrap=True)

    def write(self, line: str) -> None:
        """Append a log line to the console."""
        try:
            self.query_one("#log-output", RichLog).write(line)
        except Exception:
            pass

    def clear(self) -> None:
        """Clear all log output."""
        try:
            self.query_one("#log-output", RichLog).clear()
        except Exception:
            pass
