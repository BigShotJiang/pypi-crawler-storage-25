"""Resources widget — CPU and RAM bars refreshing every 2 seconds."""

from __future__ import annotations

import psutil

from textual.app import ComposeResult
from textual.widget import Widget
from textual.widgets import Static


class ResourcesWidget(Widget):
    """CPU % and RAM usage bars for the server process."""

    DEFAULT_CSS = """
    ResourcesWidget {
        width: 28;
        border: solid $primary;
    }
    ResourcesWidget #res-title {
        height: 1;
        background: $boost;
        padding: 0 1;
        text-style: bold;
    }
    ResourcesWidget #res-display {
        padding: 1;
    }
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._pid: int | None = None
        self._process: psutil.Process | None = None

    def compose(self) -> ComposeResult:
        yield Static("Resources", id="res-title")
        yield Static("Waiting for server...", id="res-display")

    def on_mount(self) -> None:
        self.set_interval(2.0, self._refresh)

    def set_pid(self, pid: int | None) -> None:
        """Set the server process PID to monitor."""
        self._pid = pid
        self._process = None
        if pid is not None:
            try:
                self._process = psutil.Process(pid)
            except psutil.NoSuchProcess:
                self._process = None

    def _refresh(self) -> None:
        lines: list[str] = []

        # Server process stats
        proc = self._process
        if proc is not None:
            try:
                cpu = proc.cpu_percent(interval=0)
                mem = proc.memory_info()
                mem_mb = mem.rss / (1024**2)
                lines.append("Server Process")
                lines.append(f"  CPU: {self._bar(cpu, 100)} {cpu:.0f}%")
                lines.append(f"  RAM: {mem_mb:.0f} MB")
                lines.append("")
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                self._process = None

        # System stats
        sys_cpu = psutil.cpu_percent(interval=0)
        sys_mem = psutil.virtual_memory()
        used_gb = (sys_mem.total - sys_mem.available) / (1024**3)
        total_gb = sys_mem.total / (1024**3)
        mem_pct = sys_mem.percent

        lines.append("System")
        lines.append(f"  CPU: {self._bar(sys_cpu, 100)} {sys_cpu:.0f}%")
        lines.append(
            f"  RAM: {self._bar(mem_pct, 100)} {mem_pct:.0f}%"
        )
        lines.append(f"       {used_gb:.1f} / {total_gb:.1f} GB")

        try:
            self.query_one("#res-display", Static).update("\n".join(lines))
        except Exception:
            pass

    @staticmethod
    def _bar(value: float, maximum: float, width: int = 14) -> str:
        ratio = min(value / maximum, 1.0) if maximum > 0 else 0.0
        filled = int(width * ratio)
        return "\u2588" * filled + "\u2591" * (width - filled)
