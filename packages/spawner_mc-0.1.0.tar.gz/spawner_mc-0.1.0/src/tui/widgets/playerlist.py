"""Player list widget — live player list with context menu."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.message import Message
from textual.widget import Widget
from textual.widgets import Button, Label, ListItem, ListView, Static


class PlayerListWidget(Widget):
    """Live player list with click-for-actions context menu."""

    DEFAULT_CSS = """
    PlayerListWidget {
        width: 24;
        border: solid $primary;
    }
    PlayerListWidget #pl-title {
        height: 1;
        background: $boost;
        padding: 0 1;
        text-style: bold;
    }
    PlayerListWidget ListView {
        height: 1fr;
    }
    PlayerListWidget #pl-context {
        height: auto;
        padding: 1;
        background: $surface;
        border: solid $accent;
    }
    PlayerListWidget #pl-context-name {
        text-style: bold;
        margin-bottom: 1;
    }
    PlayerListWidget #pl-context Button {
        width: 100%;
        margin-bottom: 0;
    }
    """

    class PlayerAction(Message):
        """Fired when the user picks an action on a player."""

        def __init__(self, player: str, action: str) -> None:
            super().__init__()
            self.player = player
            self.action = action

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._players: list[str] = []
        self._selected_player: str | None = None

    def compose(self) -> ComposeResult:
        yield Static("Players (0)", id="pl-title")
        yield ListView(id="pl-list")
        yield Vertical(
            Static("", id="pl-context-name"),
            Button("Op", id="pl-op", variant="default"),
            Button("Kick", id="pl-kick", variant="warning"),
            Button("Ban", id="pl-ban", variant="error"),
            Button("Cancel", id="pl-cancel"),
            id="pl-context",
        )

    def on_mount(self) -> None:
        self.query_one("#pl-context").display = False

    def update_players(self, players: list[str]) -> None:
        """Refresh the player list."""
        if players == self._players:
            return
        self._players = list(players)
        try:
            self.query_one("#pl-title", Static).update(
                f"Players ({len(players)})"
            )
            lv = self.query_one("#pl-list", ListView)
            lv.clear()
            for name in players:
                lv.append(ListItem(Label(name), id=f"player-{name}"))
        except Exception:
            pass

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Show context menu for clicked player."""
        item_id = event.item.id or ""
        if item_id.startswith("player-"):
            name = item_id[7:]
            self._selected_player = name
            self.query_one("#pl-context-name", Static).update(name)
            self.query_one("#pl-list").display = False
            self.query_one("#pl-context").display = True

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn = event.button.id or ""
        if btn == "pl-cancel":
            self._close_context()
            event.stop()
        elif btn in ("pl-op", "pl-kick", "pl-ban"):
            if self._selected_player:
                action = btn[3:]  # "op", "kick", or "ban"
                self.post_message(
                    self.PlayerAction(self._selected_player, action)
                )
            self._close_context()
            event.stop()

    def _close_context(self) -> None:
        self._selected_player = None
        self.query_one("#pl-context").display = False
        self.query_one("#pl-list").display = True
