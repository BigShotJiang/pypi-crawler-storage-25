"""System helpers — RAM, CPU, port, and IP utilities."""

import socket

import psutil
import requests


def get_total_ram() -> int:
    """Return total physical RAM in bytes."""
    return psutil.virtual_memory().total


def get_available_ram() -> int:
    """Return available RAM in bytes."""
    return psutil.virtual_memory().available


def get_cpu_count() -> int:
    """Return number of logical CPU cores."""
    return psutil.cpu_count(logical=True) or 1


def get_cpu_load() -> list[float]:
    """Return per-core CPU usage percentages."""
    return psutil.cpu_percent(interval=0.5, percpu=True)


def is_port_free(port: int) -> bool:
    """Check whether a TCP port is available on localhost."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(("", port))
            return True
        except OSError:
            return False


def next_free_port(start: int) -> int:
    """Return the first free TCP port starting from *start*."""
    port = start
    while port < 65536:
        if is_port_free(port):
            return port
        port += 1
    raise RuntimeError(f"No free port found starting from {start}")


def validate_ram_allocation(requested_gb: float, total_bytes: int) -> str | None:
    """Return an error string if *requested_gb* exceeds 50 % of total RAM, else None."""
    max_bytes = total_bytes * 0.5
    requested_bytes = requested_gb * (1024 ** 3)
    if requested_bytes > max_bytes:
        max_gb = round(max_bytes / (1024 ** 3), 1)
        return (
            f"Requested {requested_gb}G exceeds 50% of total RAM. "
            f"Maximum allowed: {max_gb}G"
        )
    return None


def get_local_ip() -> str:
    """Return the machine's LAN IP address."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"


def get_public_ip() -> str:
    """Return the public IP via api.ipify.org, or 'unavailable'."""
    try:
        resp = requests.get("https://api.ipify.org", timeout=5)
        resp.raise_for_status()
        return resp.text.strip()
    except (requests.RequestException, ValueError):
        return "unavailable"
