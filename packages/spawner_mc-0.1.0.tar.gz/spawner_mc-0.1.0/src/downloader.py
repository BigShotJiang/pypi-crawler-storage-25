"""Jar downloader — fetch version lists and download server jars."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import requests

JARS_DIR = Path.home() / ".spawner" / "jars"

VANILLA_MANIFEST = (
    "https://launchermeta.mojang.com/mc/game/version_manifest.json"
)
PAPER_API = "https://api.papermc.io/v2/projects/paper"
FABRIC_GAME_VERSIONS = "https://meta.fabricmc.net/v2/versions/game"
FABRIC_LOADER_VERSIONS = "https://meta.fabricmc.net/v2/versions/loader"
FABRIC_INSTALLER_VERSIONS = "https://meta.fabricmc.net/v2/versions/installer"
FORGE_PROMOS = (
    "https://files.minecraftforge.net/net/minecraftforge/forge/"
    "promotions_slim.json"
)

TIMEOUT = 15


# ── version list fetchers ─────────────────────────────────────────────


def fetch_vanilla_versions() -> list[dict[str, str]]:
    """Return ``[{"id": "1.21.4", "type": "release"}, ...]``."""
    resp = requests.get(VANILLA_MANIFEST, timeout=TIMEOUT)
    resp.raise_for_status()
    return [
        {"id": v["id"], "type": v["type"]}
        for v in resp.json()["versions"]
    ]


def fetch_paper_versions() -> list[str]:
    """Return version strings newest-first."""
    resp = requests.get(PAPER_API, timeout=TIMEOUT)
    resp.raise_for_status()
    versions: list[str] = resp.json()["versions"]
    return list(reversed(versions))


def fetch_fabric_versions() -> list[dict[str, Any]]:
    """Return ``[{"version": "1.21.4", "stable": True}, ...]``."""
    resp = requests.get(FABRIC_GAME_VERSIONS, timeout=TIMEOUT)
    resp.raise_for_status()
    return resp.json()


def fetch_forge_versions() -> list[str]:
    """Return MC versions that have a Forge build, newest-first."""
    resp = requests.get(FORGE_PROMOS, timeout=TIMEOUT)
    resp.raise_for_status()
    promos: dict[str, str] = resp.json()["promos"]
    seen: dict[str, bool] = {}
    versions: list[str] = []
    for key in promos:
        mc_ver = key.rsplit("-", 1)[0]
        if mc_ver not in seen:
            seen[mc_ver] = True
            versions.append(mc_ver)
    return list(reversed(versions))


# ── download-URL resolvers ────────────────────────────────────────────


def _resolve_vanilla_url(version: str) -> str:
    """Get the server jar download URL for a vanilla version."""
    manifest = requests.get(VANILLA_MANIFEST, timeout=TIMEOUT)
    manifest.raise_for_status()
    version_entry = next(
        (v for v in manifest.json()["versions"] if v["id"] == version), None
    )
    if version_entry is None:
        raise ValueError(f"Vanilla version '{version}' not found")
    meta = requests.get(version_entry["url"], timeout=TIMEOUT)
    meta.raise_for_status()
    data = meta.json()
    server_dl = data.get("downloads", {}).get("server")
    if server_dl is None:
        raise ValueError(f"No server jar available for vanilla {version}")
    return server_dl["url"]


def _resolve_paper_url(version: str) -> str:
    """Get the latest Paper build jar URL for a version."""
    builds_url = f"{PAPER_API}/versions/{version}/builds"
    resp = requests.get(builds_url, timeout=TIMEOUT)
    resp.raise_for_status()
    builds = resp.json()["builds"]
    if not builds:
        raise ValueError(f"No Paper builds for version {version}")
    latest = builds[-1]
    build_num = latest["build"]
    jar_name = latest["downloads"]["application"]["name"]
    return (
        f"{PAPER_API}/versions/{version}/builds/{build_num}"
        f"/downloads/{jar_name}"
    )


def _resolve_fabric_url(version: str) -> str:
    """Get the Fabric server launcher jar URL."""
    # pick latest stable loader
    resp = requests.get(FABRIC_LOADER_VERSIONS, timeout=TIMEOUT)
    resp.raise_for_status()
    loaders = resp.json()
    loader = next((l for l in loaders if l.get("stable")), loaders[0])
    loader_ver = loader["version"]
    # pick latest stable installer
    resp = requests.get(FABRIC_INSTALLER_VERSIONS, timeout=TIMEOUT)
    resp.raise_for_status()
    installers = resp.json()
    installer = next((i for i in installers if i.get("stable")), installers[0])
    installer_ver = installer["version"]
    return (
        f"https://meta.fabricmc.net/v2/versions/loader/"
        f"{version}/{loader_ver}/{installer_ver}/server/jar"
    )


def _resolve_forge_url(version: str) -> str:
    """Get the Forge installer jar URL."""
    resp = requests.get(FORGE_PROMOS, timeout=TIMEOUT)
    resp.raise_for_status()
    promos: dict[str, str] = resp.json()["promos"]
    forge_ver = promos.get(f"{version}-recommended") or promos.get(
        f"{version}-latest"
    )
    if forge_ver is None:
        raise ValueError(f"No Forge build for MC {version}")
    return (
        f"https://maven.minecraftforge.net/net/minecraftforge/forge/"
        f"{version}-{forge_ver}/forge-{version}-{forge_ver}-installer.jar"
    )


_RESOLVERS = {
    "vanilla": _resolve_vanilla_url,
    "paper": _resolve_paper_url,
    "fabric": _resolve_fabric_url,
    "forge": _resolve_forge_url,
}


# ── download with progress ────────────────────────────────────────────


def download_jar(
    server_type: str,
    version: str,
    *,
    dest: Path | None = None,
    progress_callback: Any | None = None,
) -> Path:
    """Download a server jar and return the local path.

    *progress_callback*, if given, is called as
    ``callback(downloaded_bytes, total_bytes)`` where *total_bytes* may be 0
    if the server doesn't send Content-Length.
    """
    url = _RESOLVERS[server_type](version)
    if dest is None:
        dest = JARS_DIR / f"{server_type}-{version}.jar"

    dest.parent.mkdir(parents=True, exist_ok=True)

    resp = requests.get(url, stream=True, timeout=TIMEOUT)
    resp.raise_for_status()
    total = int(resp.headers.get("content-length", 0))
    downloaded = 0
    chunk_size = 1024 * 64

    with dest.open("wb") as fh:
        for chunk in resp.iter_content(chunk_size=chunk_size):
            fh.write(chunk)
            downloaded += len(chunk)
            if progress_callback is not None:
                progress_callback(downloaded, total)

    if progress_callback is None:
        _print_done(dest)

    return dest


def _print_done(path: Path) -> None:
    size_mb = path.stat().st_size / (1024 * 1024)
    print(f"Downloaded {path.name} ({size_mb:.1f} MB)")


def print_progress(downloaded: int, total: int) -> None:
    """Simple CLI progress bar callback."""
    if total > 0:
        pct = downloaded / total * 100
        bar_len = 40
        filled = int(bar_len * downloaded // total)
        bar = "█" * filled + "░" * (bar_len - filled)
        sys.stdout.write(f"\r  [{bar}] {pct:5.1f}%")
    else:
        mb = downloaded / (1024 * 1024)
        sys.stdout.write(f"\r  Downloaded {mb:.1f} MB")
    sys.stdout.flush()
    if total > 0 and downloaded >= total:
        sys.stdout.write("\n")
