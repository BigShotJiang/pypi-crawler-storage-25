"""UPnP port forwarding via miniupnpc."""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def add_port_mapping(port: int, description: str = "spawner") -> bool:
    """Attempt to add a TCP port mapping via UPnP.

    Returns True on success, False on failure (logged as warning).
    """
    try:
        import miniupnpc  # type: ignore[import-untyped]
    except ImportError:
        logger.warning("miniupnpc not installed — skipping UPnP")
        return False

    try:
        upnp = miniupnpc.UPnP()
        upnp.discoverdelay = 2000
        devices = upnp.discover()
        if devices == 0:
            logger.warning("No UPnP devices found")
            return False
        upnp.selectigd()
        result = upnp.addportmapping(
            port,
            "TCP",
            upnp.lanaddr,
            port,
            description,
            "",
        )
        if result:
            logger.info("UPnP: mapped port %d (TCP)", port)
            return True
        logger.warning("UPnP: addportmapping returned failure for port %d", port)
        return False
    except Exception as exc:
        logger.warning("UPnP failed: %s", exc)
        return False


def remove_port_mapping(port: int) -> bool:
    """Remove a previously added TCP port mapping.

    Returns True on success, False on failure.
    """
    try:
        import miniupnpc  # type: ignore[import-untyped]
    except ImportError:
        return False

    try:
        upnp = miniupnpc.UPnP()
        upnp.discoverdelay = 2000
        if upnp.discover() == 0:
            return False
        upnp.selectigd()
        result = upnp.deleteportmapping(port, "TCP")
        if result:
            logger.info("UPnP: removed port %d mapping", port)
        return bool(result)
    except Exception as exc:
        logger.warning("UPnP cleanup failed: %s", exc)
        return False
