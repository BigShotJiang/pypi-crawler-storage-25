"""Setup wizard — step-by-step server configuration."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from textual import work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal
from textual.message import Message
from textual.reactive import reactive
from textual.widget import Widget
from textual.widgets import (
    Button,
    Header,
    Input,
    Label,
    ListItem,
    ListView,
    LoadingIndicator,
    Static,
)

from src.downloader import (
    fetch_fabric_versions,
    fetch_forge_versions,
    fetch_paper_versions,
    fetch_vanilla_versions,
)
from src.profiles import add_profile, load_profiles
from src.system import (
    get_available_ram,
    get_cpu_count,
    get_cpu_load,
    get_total_ram,
    is_port_free,
    next_free_port,
    validate_ram_allocation,
)
from src.upnp import add_port_mapping

SPAWNER_DIR = Path.home() / ".spawner"
NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9-]*$")
SERVER_TYPES = ["Vanilla", "Paper", "Fabric", "Forge"]
DEFAULT_PORT = 25565

STEP_TITLES = [
    "Server Name",
    "Server Type",
    "Minecraft Version",
    "Jar Source",
    "RAM Allocation",
    "CPU Cores",
    "Port",
    "UPnP Port Forwarding",
    "Server Directory",
    "Summary",
]


# ── Custom widget: value slider ────────────────────────────────────────


class ValueSlider(Widget):
    """Clickable +/- value selector."""

    DEFAULT_CSS = """
    ValueSlider {
        height: 3;
    }
    ValueSlider Horizontal {
        height: 3;
        align: left middle;
    }
    ValueSlider Button {
        min-width: 5;
        max-width: 5;
        margin: 0 1;
    }
    ValueSlider .slider-value {
        width: 14;
        content-align: center middle;
    }
    """

    class Changed(Message):
        """Posted when the slider value changes."""

        def __init__(self, slider: ValueSlider, value: int) -> None:
            super().__init__()
            self.slider = slider
            self.value = value

    value: reactive[int] = reactive(1)

    def __init__(
        self,
        min_val: int = 1,
        max_val: int = 100,
        step: int = 1,
        value: int = 1,
        unit: str = "",
        slider_id: str = "slider",
    ) -> None:
        super().__init__()
        self.min_val = min_val
        self.max_val = max_val
        self.step_size = step
        self.unit = unit
        self.slider_id = slider_id
        self.value = value

    def compose(self) -> ComposeResult:
        yield Horizontal(
            Button("\u2212", id=f"{self.slider_id}-dec"),
            Static(self._format(), classes="slider-value"),
            Button("+", id=f"{self.slider_id}-inc"),
        )

    def _format(self) -> str:
        return f" {self.value} {self.unit} "

    def watch_value(self, new_value: int) -> None:
        try:
            self.query_one(".slider-value", Static).update(self._format())
        except Exception:
            pass
        try:
            self.post_message(self.Changed(self, new_value))
        except Exception:
            pass

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == f"{self.slider_id}-dec":
            self.value = max(self.min_val, self.value - self.step_size)
            event.stop()
        elif event.button.id == f"{self.slider_id}-inc":
            self.value = min(self.max_val, self.value + self.step_size)
            event.stop()


# ── Base step ──────────────────────────────────────────────────────────


class WizardStep(Widget):
    """Base for all wizard steps."""

    DEFAULT_CSS = """
    WizardStep { padding: 1 2; }
    .step-desc { margin-bottom: 1; }
    .error-text { color: red; }
    .info-text { color: $text-muted; margin-top: 1; }
    """

    def __init__(self, data: dict[str, Any]) -> None:
        super().__init__()
        self.data = data

    def validate(self) -> str | None:
        return None

    def get_data(self) -> dict[str, Any]:
        return {}


# ── Step 1: Server name ───────────────────────────────────────────────


class StepName(WizardStep):

    def compose(self) -> ComposeResult:
        yield Static("Enter a name for your server:", classes="step-desc")
        yield Input(
            value=self.data.get("name", ""),
            placeholder="my-server",
            id="name-input",
        )
        yield Static(
            "Alphanumeric and hyphens only. Must be unique.",
            classes="info-text",
        )

    def validate(self) -> str | None:
        name = self.query_one("#name-input", Input).value.strip()
        if not name:
            return "Name cannot be empty"
        if not NAME_RE.match(name):
            return "Only letters, numbers, and hyphens allowed"
        existing = load_profiles()
        if any(p["name"] == name for p in existing):
            return f"Profile '{name}' already exists"
        return None

    def get_data(self) -> dict[str, Any]:
        return {"name": self.query_one("#name-input", Input).value.strip()}


# ── Step 2: Server type ───────────────────────────────────────────────


class StepType(WizardStep):

    def compose(self) -> ComposeResult:
        yield Static("Choose server type:", classes="step-desc")
        items = [
            ListItem(Label(t), id=f"type-{t.lower()}")
            for t in SERVER_TYPES
        ]
        yield ListView(*items, id="type-list")

    def on_mount(self) -> None:
        prev = self.data.get("type", "")
        lv = self.query_one("#type-list", ListView)
        for i, t in enumerate(SERVER_TYPES):
            if t.lower() == prev:
                lv.index = i
                return
        lv.index = 0

    def validate(self) -> str | None:
        if self.query_one("#type-list", ListView).index is None:
            return "Select a server type"
        return None

    def get_data(self) -> dict[str, Any]:
        idx = self.query_one("#type-list", ListView).index or 0
        return {"type": SERVER_TYPES[idx].lower()}


# ── Step 3: Minecraft version ─────────────────────────────────────────


class StepVersion(WizardStep):

    def __init__(self, data: dict[str, Any]) -> None:
        super().__init__(data)
        self._versions: list[str] = []

    def compose(self) -> ComposeResult:
        yield Static("Select Minecraft version:", classes="step-desc")
        yield LoadingIndicator(id="ver-loading")
        yield ListView(id="ver-list")

    def on_mount(self) -> None:
        self.query_one("#ver-list", ListView).display = False
        self._fetch_versions()

    @work(thread=True)
    def _fetch_versions(self) -> None:
        server_type = self.data.get("type", "vanilla")
        try:
            if server_type == "vanilla":
                raw = fetch_vanilla_versions()
                versions = [v["id"] for v in raw if v["type"] == "release"]
            elif server_type == "paper":
                versions = fetch_paper_versions()
            elif server_type == "fabric":
                raw = fetch_fabric_versions()
                versions = [v["version"] for v in raw if v.get("stable")]
            elif server_type == "forge":
                versions = fetch_forge_versions()
            else:
                versions = []
        except Exception:
            versions = []
        self.app.call_from_thread(self._show_versions, versions)

    def _show_versions(self, versions: list[str]) -> None:
        self._versions = versions
        try:
            self.query_one("#ver-loading").display = False
            lv = self.query_one("#ver-list", ListView)
            lv.clear()
            for v in versions:
                lv.append(ListItem(Label(v)))
            lv.display = True
            prev = self.data.get("version", "")
            if prev in versions:
                lv.index = versions.index(prev)
            elif versions:
                lv.index = 0
        except Exception:
            pass

    def validate(self) -> str | None:
        if not self._versions:
            return "No versions loaded — go back and try again"
        if self.query_one("#ver-list", ListView).index is None:
            return "Select a version"
        return None

    def get_data(self) -> dict[str, Any]:
        idx = self.query_one("#ver-list", ListView).index or 0
        if idx < len(self._versions):
            return {"version": self._versions[idx]}
        return {}


# ── Step 4: Jar source ────────────────────────────────────────────────


class StepJarSource(WizardStep):

    def compose(self) -> ComposeResult:
        yield Static(
            "How should the server jar be obtained?", classes="step-desc"
        )
        yield ListView(
            ListItem(Label("Auto-download (recommended)"), id="jar-auto"),
            ListItem(Label("Provide path to existing jar"), id="jar-path"),
            id="jar-list",
        )
        yield Input(
            value=self.data.get("jar_path", ""),
            placeholder="/path/to/server.jar",
            id="jar-path-input",
        )

    def on_mount(self) -> None:
        prev = self.data.get("jar_source", "auto")
        lv = self.query_one("#jar-list", ListView)
        lv.index = 0 if prev == "auto" else 1
        self.query_one("#jar-path-input", Input).display = prev == "path"

    def on_list_view_highlighted(
        self, event: ListView.Highlighted
    ) -> None:
        if event.item is None:
            return
        show = event.item.id == "jar-path"
        self.query_one("#jar-path-input", Input).display = show

    def validate(self) -> str | None:
        lv = self.query_one("#jar-list", ListView)
        if (lv.index or 0) == 1:
            path_str = self.query_one("#jar-path-input", Input).value.strip()
            if not path_str:
                return "Please enter a jar file path"
            if not Path(path_str).expanduser().exists():
                return f"File not found: {path_str}"
        return None

    def get_data(self) -> dict[str, Any]:
        lv = self.query_one("#jar-list", ListView)
        if (lv.index or 0) == 1:
            return {
                "jar_source": "path",
                "jar_path": self.query_one(
                    "#jar-path-input", Input
                ).value.strip(),
            }
        return {"jar_source": "auto"}


# ── Step 5: RAM allocation ────────────────────────────────────────────


class StepRam(WizardStep):

    def compose(self) -> ComposeResult:
        total = get_total_ram()
        available = get_available_ram()
        total_gb = total / (1024**3)
        avail_gb = available / (1024**3)
        max_gb = max(1, int(total_gb * 0.5))
        default = self.data.get(
            "ram_gb", min(max_gb, max(1, int(total_gb * 0.25)))
        )

        yield Static("Set RAM allocation:", classes="step-desc")
        yield Static(
            f"Total: {total_gb:.1f} GB  |  "
            f"Available: {avail_gb:.1f} GB  |  "
            f"Max: {max_gb} GB (50%)",
            id="ram-info",
        )
        yield ValueSlider(
            min_val=1,
            max_val=max_gb,
            step=1,
            value=default,
            unit="GB",
            slider_id="ram",
        )
        yield Static("", id="ram-bar")

    def on_mount(self) -> None:
        self._update_bar()

    def on_value_slider_changed(self, event: ValueSlider.Changed) -> None:
        self._update_bar()

    def _update_bar(self) -> None:
        try:
            val = self.query_one(ValueSlider).value
            total_gb = get_total_ram() / (1024**3)
            pct = val / total_gb * 100
            filled = int(40 * val / total_gb)
            bar = "\u2588" * filled + "\u2591" * (40 - filled)
            self.query_one("#ram-bar", Static).update(
                f"  [{bar}] {pct:.0f}% of total"
            )
        except Exception:
            pass

    def validate(self) -> str | None:
        val = self.query_one(ValueSlider).value
        return validate_ram_allocation(val, get_total_ram())

    def get_data(self) -> dict[str, Any]:
        val = self.query_one(ValueSlider).value
        return {"ram_gb": val, "ram": f"{val}G"}


# ── Step 6: CPU cores ─────────────────────────────────────────────────


class StepCpu(WizardStep):

    def compose(self) -> ComposeResult:
        count = get_cpu_count()
        default = self.data.get("cores", max(1, count // 2))

        yield Static("Set CPU core allocation:", classes="step-desc")
        yield Static(f"Total logical cores: {count}", id="cpu-info")
        yield ValueSlider(
            min_val=1,
            max_val=count,
            step=1,
            value=default,
            unit="cores",
            slider_id="cpu",
        )
        yield Static("Loading...", id="cpu-load")

    def on_mount(self) -> None:
        self._refresh_load()
        self.set_interval(2.0, self._refresh_load)

    def _refresh_load(self) -> None:
        try:
            loads = get_cpu_load()
            lines = []
            for i, load in enumerate(loads):
                filled = int(20 * load / 100)
                bar = "\u2588" * filled + "\u2591" * (20 - filled)
                lines.append(f"  Core {i:2d}: [{bar}] {load:5.1f}%")
            self.query_one("#cpu-load", Static).update("\n".join(lines))
        except Exception:
            pass

    def get_data(self) -> dict[str, Any]:
        return {"cores": self.query_one(ValueSlider).value}


# ── Step 7: Port ──────────────────────────────────────────────────────


class StepPort(WizardStep):

    def compose(self) -> ComposeResult:
        prev = self.data.get("port", DEFAULT_PORT)
        yield Static("Set server port:", classes="step-desc")
        yield Input(value=str(prev), placeholder="25565", id="port-input")
        yield Static("", id="port-status", classes="info-text")

    def on_mount(self) -> None:
        self._check_port()

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id == "port-input":
            self._check_port()

    def _check_port(self) -> None:
        text = self.query_one("#port-input", Input).value.strip()
        try:
            port = int(text)
        except ValueError:
            self.query_one("#port-status").update(
                "Enter a valid port number"
            )
            return
        if is_port_free(port):
            self.query_one("#port-status").update(
                f"\u2713 Port {port} is available"
            )
        else:
            free = next_free_port(port + 1)
            self.query_one("#port-status").update(
                f"\u26a0 Port {port} in use. Next free: {free}"
            )

    def validate(self) -> str | None:
        try:
            port = int(self.query_one("#port-input", Input).value.strip())
        except ValueError:
            return "Invalid port number"
        if port < 1 or port > 65535:
            return "Port must be between 1 and 65535"
        if not is_port_free(port):
            return f"Port {port} is already in use"
        return None

    def get_data(self) -> dict[str, Any]:
        return {
            "port": int(self.query_one("#port-input", Input).value.strip())
        }


# ── Step 8: UPnP ──────────────────────────────────────────────────────


class StepUpnp(WizardStep):

    def compose(self) -> ComposeResult:
        yield Static("Configuring port forward...", id="upnp-status")

    def on_mount(self) -> None:
        self._run_upnp()

    @work(thread=True)
    def _run_upnp(self) -> None:
        port = self.data.get("port", DEFAULT_PORT)
        success = add_port_mapping(port, description="spawner")
        self.app.call_from_thread(self._show_result, success)

    def _show_result(self, success: bool) -> None:
        try:
            st = self.query_one("#upnp-status", Static)
            if success:
                st.update(
                    "\u2713 Port forwarding configured successfully!"
                )
            else:
                st.update(
                    "\u26a0 Port forwarding unavailable.\n\n"
                    "  Your server may not be reachable from outside\n"
                    "  your local network. You can configure port\n"
                    "  forwarding manually in your router settings."
                )
        except Exception:
            pass
        self.data["upnp"] = success

    def get_data(self) -> dict[str, Any]:
        return {"upnp": self.data.get("upnp", False)}


# ── Step 9: Server directory ──────────────────────────────────────────


class StepDirectory(WizardStep):

    def compose(self) -> ComposeResult:
        name = self.data.get("name", "server")
        default = str(SPAWNER_DIR / "servers" / name)
        prev = self.data.get("directory", default)
        yield Static("Server directory:", classes="step-desc")
        yield Input(value=prev, id="dir-input")
        yield Static(
            "Server files will be created here.", classes="info-text"
        )

    def validate(self) -> str | None:
        if not self.query_one("#dir-input", Input).value.strip():
            return "Directory path cannot be empty"
        return None

    def get_data(self) -> dict[str, Any]:
        return {
            "directory": self.query_one("#dir-input", Input).value.strip()
        }


# ── Step 10: Summary ──────────────────────────────────────────────────


class StepSummary(WizardStep):

    def compose(self) -> ComposeResult:
        d = self.data
        jar_display = (
            "Auto-download"
            if d.get("jar_source") == "auto"
            else d.get("jar_path", "?")
        )
        lines = [
            f"  Name:      {d.get('name', '')}",
            f"  Type:      {d.get('type', '')}",
            f"  Version:   {d.get('version', '')}",
            f"  Jar:       {jar_display}",
            f"  RAM:       {d.get('ram', '')}",
            f"  CPU:       {d.get('cores', '')} cores",
            f"  Port:      {d.get('port', '')}",
            f"  UPnP:      {'Enabled' if d.get('upnp') else 'Disabled'}",
            f"  Directory: {d.get('directory', '')}",
        ]
        yield Static(
            "Review your server configuration:\n", classes="step-desc"
        )
        yield Static("\n".join(lines))
        yield Static(
            "\nClick Confirm to create the server, or Back to edit.",
            classes="info-text",
        )


# ── Step registry ─────────────────────────────────────────────────────

STEP_CLASSES: list[type[WizardStep]] = [
    StepName,
    StepType,
    StepVersion,
    StepJarSource,
    StepRam,
    StepCpu,
    StepPort,
    StepUpnp,
    StepDirectory,
    StepSummary,
]


# ── Wizard app ─────────────────────────────────────────────────────────


class WizardApp(App):
    """Interactive setup wizard for spawner."""

    TITLE = "spawner"
    SUB_TITLE = "Setup Wizard"
    BINDINGS = [Binding("escape", "cancel", "Cancel", show=True)]

    CSS = """
    Screen { layout: vertical; }
    #step-header {
        width: 100%;
        height: 1;
        background: $boost;
        color: $text;
        text-style: bold;
        padding: 0 2;
    }
    #step-container {
        height: 1fr;
        overflow-y: auto;
    }
    #nav-bar {
        dock: bottom;
        height: 3;
        width: 100%;
        layout: horizontal;
        align: right middle;
        padding: 0 2;
        background: $surface;
    }
    #nav-bar Button { margin: 0 1; }
    """

    current_step: reactive[int] = reactive(0)

    def __init__(self) -> None:
        super().__init__()
        self.wizard_data: dict[str, Any] = {}
        self.result: dict[str, Any] | None = None

    def compose(self) -> ComposeResult:
        yield Header()
        yield Static("", id="step-header")
        yield Container(id="step-container")
        yield Horizontal(
            Button("Back", id="nav-back", variant="default"),
            Button("Next", id="nav-next", variant="primary"),
            id="nav-bar",
        )

    def on_mount(self) -> None:
        self._show_step()

    def _update_chrome(self) -> None:
        idx = self.current_step
        title = STEP_TITLES[idx]
        self.query_one("#step-header", Static).update(
            f"  Step {idx + 1} of {len(STEP_CLASSES)} \u2014 {title}"
        )
        self.query_one("#nav-back", Button).disabled = idx == 0
        btn = self.query_one("#nav-next", Button)
        btn.label = "Confirm" if idx == len(STEP_CLASSES) - 1 else "Next"

    def _show_step(self) -> None:
        container = self.query_one("#step-container")
        container.remove_children()
        step_cls = STEP_CLASSES[self.current_step]
        container.mount(step_cls(self.wizard_data))
        self._update_chrome()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "nav-next":
            self._go_next()
        elif event.button.id == "nav-back":
            self._go_back()

    def _current_step_widget(self) -> WizardStep | None:
        children = list(self.query_one("#step-container").children)
        if children and isinstance(children[0], WizardStep):
            return children[0]
        return None

    def _go_next(self) -> None:
        step = self._current_step_widget()
        if step is not None:
            error = step.validate()
            if error:
                self.notify(error, severity="error")
                return
            self.wizard_data.update(step.get_data())

        if self.current_step >= len(STEP_CLASSES) - 1:
            self._confirm()
        else:
            self.current_step += 1
            self._show_step()

    def _go_back(self) -> None:
        if self.current_step <= 0:
            return
        step = self._current_step_widget()
        if step is not None:
            try:
                self.wizard_data.update(step.get_data())
            except Exception:
                pass
        self.current_step -= 1
        self._show_step()

    def action_cancel(self) -> None:
        self.exit()

    def _confirm(self) -> None:
        data = self.wizard_data
        directory = Path(data["directory"]).expanduser()
        directory.mkdir(parents=True, exist_ok=True)

        # server.properties
        (directory / "server.properties").write_text(
            f"server-port={data['port']}\n", encoding="utf-8"
        )
        # eula.txt
        (directory / "eula.txt").write_text("eula=true\n", encoding="utf-8")

        # jar path
        if data.get("jar_source") == "auto":
            jar = str(
                SPAWNER_DIR
                / "jars"
                / f"{data['type']}-{data['version']}.jar"
            )
        else:
            jar = data.get("jar_path", "")

        profile = {
            "name": data["name"],
            "type": data["type"],
            "version": data["version"],
            "jar": jar,
            "directory": str(directory),
            "ram": data["ram"],
            "cores": data["cores"],
            "port": data["port"],
            "upnp": data.get("upnp", False),
        }
        add_profile(profile)
        self.result = profile
        self.exit()


# ── Public entry point ─────────────────────────────────────────────────


def run_wizard() -> dict[str, Any] | None:
    """Run the setup wizard. Returns the created profile or None."""
    app = WizardApp()
    app.run()
    if app.result is not None:
        name = app.result["name"]
        directory = app.result["directory"]
        print(f'Server "{name}" created at {directory}')
    return app.result
