"""Profile persistence — load/save ~/.spawner/profiles.json."""

import json
from pathlib import Path
from typing import Any

SPAWNER_DIR = Path.home() / ".spawner"
PROFILES_PATH = SPAWNER_DIR / "profiles.json"


def _ensure_dir() -> None:
    """Create ~/.spawner/ if it doesn't exist."""
    SPAWNER_DIR.mkdir(parents=True, exist_ok=True)


def load_profiles() -> list[dict[str, Any]]:
    """Load all profiles from disk. Returns empty list if file is missing."""
    if not PROFILES_PATH.exists():
        return []
    text = PROFILES_PATH.read_text(encoding="utf-8")
    data = json.loads(text)
    if not isinstance(data, list):
        return []
    return data


def save_profiles(profiles: list[dict[str, Any]]) -> None:
    """Write profiles list to disk."""
    _ensure_dir()
    PROFILES_PATH.write_text(
        json.dumps(profiles, indent=2) + "\n",
        encoding="utf-8",
    )


def add_profile(profile: dict[str, Any]) -> None:
    """Append a profile and save."""
    profiles = load_profiles()
    profiles.append(profile)
    save_profiles(profiles)


def remove_profile(name: str) -> bool:
    """Remove a profile by name. Returns True if found and removed."""
    profiles = load_profiles()
    updated = [p for p in profiles if p["name"] != name]
    if len(updated) == len(profiles):
        return False
    save_profiles(updated)
    return True


def get_profile(name: str) -> dict[str, Any] | None:
    """Look up a profile by name."""
    for p in load_profiles():
        if p["name"] == name:
            return p
    return None
