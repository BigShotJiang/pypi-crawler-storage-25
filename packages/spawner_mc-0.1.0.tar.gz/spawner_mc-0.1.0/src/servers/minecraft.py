"""Minecraft server backend — Vanilla, Paper, Fabric, Forge."""

from __future__ import annotations

import logging
import os
import platform
import re
import subprocess
import threading
import time
from pathlib import Path
from typing import Any, Callable

from src.servers.base import ServerBackend, ServerStatus

logger = logging.getLogger(__name__)

_JOIN_RE = re.compile(r"(\w+) joined the game")
_LEAVE_RE = re.compile(r"(\w+) left the game")

STOP_TIMEOUT = 30


class MinecraftServer(ServerBackend):
    """Manages a single Minecraft server process."""

    def __init__(
        self,
        *,
        name: str,
        server_type: str,
        version: str,
        jar: str | Path,
        directory: str | Path,
        ram: str,
        cores: int,
        port: int,
    ) -> None:
        self.name = name
        self.server_type = server_type
        self.version = version
        self.jar = Path(jar).expanduser()
        self.directory = Path(directory).expanduser()
        self.ram = ram
        self.cores = cores
        self.port = port

        self._process: subprocess.Popen[str] | None = None
        self._status = ServerStatus.STOPPED
        self._players: list[str] = []
        self._lock = threading.Lock()
        self._log_thread: threading.Thread | None = None
        self._on_log: Callable[[str], None] | None = None
        self._start_time: float | None = None

    @property
    def status(self) -> ServerStatus:
        return self._status

    @property
    def uptime_seconds(self) -> float:
        if self._start_time is None:
            return 0.0
        return time.time() - self._start_time

    def get_players(self) -> list[str]:
        with self._lock:
            return list(self._players)

    def set_log_callback(self, callback: Callable[[str], None]) -> None:
        """Register a callback invoked for each log line."""
        self._on_log = callback

    # ── lifecycle ──────────────────────────────────────────────────────

    def start(self) -> None:
        if self._status == ServerStatus.RUNNING:
            return
        self.directory.mkdir(parents=True, exist_ok=True)
        cmd = self._build_command()
        self._status = ServerStatus.STARTING
        self._players.clear()

        kwargs: dict[str, Any] = {
            "stdin": subprocess.PIPE,
            "stdout": subprocess.PIPE,
            "stderr": subprocess.STDOUT,
            "text": True,
            "cwd": str(self.directory),
            "bufsize": 1,
        }

        if platform.system() != "Windows":
            kwargs["preexec_fn"] = self._set_cpu_affinity

        self._process = subprocess.Popen(cmd, **kwargs)
        self._start_time = time.time()
        self._write_pid_file()
        self._log_thread = threading.Thread(
            target=self._read_logs, daemon=True
        )
        self._log_thread.start()

    def stop(self) -> None:
        proc = self._process
        if proc is None or proc.poll() is not None:
            self._status = ServerStatus.STOPPED
            return
        self.send_command("stop")
        try:
            proc.wait(timeout=STOP_TIMEOUT)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
        self._status = ServerStatus.STOPPED
        self._start_time = None
        self._remove_pid_file()

    def restart(self) -> None:
        self.stop()
        self.start()

    def send_command(self, cmd: str) -> None:
        proc = self._process
        if proc is None or proc.stdin is None or proc.poll() is not None:
            return
        try:
            proc.stdin.write(cmd + "\n")
            proc.stdin.flush()
        except OSError:
            pass

    # ── command building ───────────────────────────────────────────────

    def _build_command(self) -> list[str]:
        java = "java"
        ram_flags = [f"-Xmx{self.ram}", f"-Xms{self.ram}"]

        if self.server_type == "forge":
            return self._build_forge_command(java, ram_flags)

        return [java, *ram_flags, "-jar", str(self.jar), "nogui"]

    def _build_forge_command(
        self, java: str, ram_flags: list[str]
    ) -> list[str]:
        # Modern Forge (1.17+) generates run scripts; try them first.
        if platform.system() == "Windows":
            run_script = self.directory / "run.bat"
        else:
            run_script = self.directory / "run.sh"

        if run_script.exists():
            if platform.system() == "Windows":
                return ["cmd", "/c", str(run_script)]
            return ["bash", str(run_script)]

        # Fallback: direct jar launch (older Forge versions).
        return [java, *ram_flags, "-jar", str(self.jar), "nogui"]

    # ── CPU affinity (Linux only) ──────────────────────────────────────

    def _set_cpu_affinity(self) -> None:
        try:
            cores = list(range(self.cores))
            os.sched_setaffinity(0, cores)
        except (AttributeError, OSError):
            pass

    # ── log reader ─────────────────────────────────────────────────────

    def _read_logs(self) -> None:
        proc = self._process
        if proc is None or proc.stdout is None:
            return

        for line in proc.stdout:
            line = line.rstrip("\n")
            self._parse_log_line(line)
            if self._on_log is not None:
                try:
                    self._on_log(line)
                except Exception:
                    pass

        # Process ended — determine status from exit code.
        exit_code = proc.wait()
        if exit_code != 0 and self._status != ServerStatus.STOPPED:
            self._status = ServerStatus.CRASHED
        elif self._status != ServerStatus.STOPPED:
            self._status = ServerStatus.STOPPED

    def _parse_log_line(self, line: str) -> None:
        # Detect server-ready message.
        if "Done" in line and "For help" in line:
            self._status = ServerStatus.RUNNING

        # Player join / leave.
        join = _JOIN_RE.search(line)
        if join:
            name = join.group(1)
            with self._lock:
                if name not in self._players:
                    self._players.append(name)
            return

        leave = _LEAVE_RE.search(line)
        if leave:
            name = leave.group(1)
            with self._lock:
                if name in self._players:
                    self._players.remove(name)

    # ── PID file ───────────────────────────────────────────────────

    def _pid_file_path(self) -> Path:
        return self.directory / ".spawner.pid"

    def _write_pid_file(self) -> None:
        if self._process is not None:
            try:
                self._pid_file_path().write_text(
                    str(self._process.pid), encoding="utf-8"
                )
            except OSError:
                pass

    def _remove_pid_file(self) -> None:
        try:
            self._pid_file_path().unlink(missing_ok=True)
        except OSError:
            pass

    @staticmethod
    def read_pid_file(directory: str | Path) -> int | None:
        """Read the PID from a server directory, or None."""
        pid_file = Path(directory).expanduser() / ".spawner.pid"
        if not pid_file.exists():
            return None
        try:
            return int(pid_file.read_text(encoding="utf-8").strip())
        except (ValueError, OSError):
            return None

    @staticmethod
    def is_java_available() -> bool:
        """Check whether java is on PATH."""
        import shutil
        return shutil.which("java") is not None
