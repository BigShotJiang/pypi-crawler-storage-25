"""Abstract base class for game server backends."""

from __future__ import annotations

import enum
from abc import ABC, abstractmethod


class ServerStatus(enum.Enum):
    STARTING = "starting"
    RUNNING = "running"
    STOPPED = "stopped"
    CRASHED = "crashed"


class ServerBackend(ABC):
    """Interface that every game-server backend must implement."""

    @abstractmethod
    def start(self) -> None:
        """Launch the server process."""

    @abstractmethod
    def stop(self) -> None:
        """Gracefully stop the server (wait up to 30 s, then force-kill)."""

    @abstractmethod
    def restart(self) -> None:
        """Stop then start the server."""

    @abstractmethod
    def send_command(self, cmd: str) -> None:
        """Send a console command to the server's stdin."""

    @abstractmethod
    def get_players(self) -> list[str]:
        """Return a list of currently online player names."""

    @property
    @abstractmethod
    def status(self) -> ServerStatus:
        """Return the current server status."""
