# spawner

CLI + TUI game server manager. Currently supports Minecraft Java Edition (Vanilla, Paper, Fabric, Forge).

## Install

Requires Python 3.10+ and Java 17+.

```bash
pipx install spawner-mc
```

Or install with pip:

```bash
pip install spawner-mc
```

For development:

```bash
git clone https://github.com/peroxide-dev/spawner.git && cd spawner
pip install -e .
```

## Quickstart

```bash
spawner start
```

This launches an interactive setup wizard that walks you through:

1. Server name
2. Server type (Vanilla / Paper / Fabric / Forge)
3. Minecraft version (fetched from official APIs)
4. Jar source (auto-download or provide path)
5. RAM allocation (with 50% hard cap)
6. CPU cores
7. Port configuration
8. UPnP port forwarding (automatic)
9. Server directory
10. Review and confirm

After confirmation, spawner creates the server directory, downloads the jar, and opens a full-screen TUI with live console, player list, resource monitoring, and a file browser.

## Commands

| Command | Description |
|---|---|
| `spawner start` | Run setup wizard, create server, open TUI |
| `spawner start <name>` | Relaunch a saved profile directly into TUI |
| `spawner list` | Show all saved profiles with status |
| `spawner delete <name>` | Delete a profile (with confirmation) |
| `spawner stop <name>` | Gracefully stop a running server |
| `spawner restart <name>` | Stop and relaunch a server |

## TUI Controls

### Keybinds

| Key | Action |
|---|---|
| `s` | Stop server |
| `r` | Restart server |
| `c` | Toggle command input bar |
| `f` | Open file browser |
| `q` | Quit (stops server, cleans up UPnP) |
| `Escape` | Close overlays |

### Panels

- **Console** — live scrolling server log output
- **Player List** — click a player name for Op / Kick / Ban actions
- **Resources** — CPU and RAM bars (server process + system), refreshes every 2s

### File Browser

Press `f` to open a full-screen file browser. Click files to edit, `Ctrl+S` to save.

## Profiles

Server configurations are saved to `~/.spawner/profiles.json` and can be relaunched with `spawner start <name>`.

Downloaded jars are cached at `~/.spawner/jars/`.

## Supported Server Types

- **Vanilla** → Official Mojang server
- **Paper** → High-performance Spigot fork
- **Fabric** → Lightweight modding platform
- **Forge** → Full modding framework

## Dependencies

- [textual](https://github.com/Textualize/textual) → TUI framework
- [psutil](https://github.com/giampaolo/psutil) → System monitoring
- [requests](https://github.com/psf/requests) → HTTP client
- [miniupnpc](https://github.com/miniupnp/miniupnp) → UPnP port forwarding
