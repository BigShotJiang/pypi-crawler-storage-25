"""Contains all unit tests for the get_all_docker_tags method."""

from unittest.mock import MagicMock, patch

import pytest

from voraus_pipeline_utils.methods.docker import get_all_docker_tags


@pytest.mark.parametrize("image_name", ["", None])
def test_get_all_docker_tags_invalid_image_name(image_name: str | None) -> None:
    with pytest.raises(ValueError, match="Invalid image name"):
        get_all_docker_tags(repositories=["docker"], image_name=image_name, registry="example.com")


def test_get_all_docker_tags_branch_name_missing_build_number() -> None:
    with pytest.raises(ValueError, match="Build number must be provided when branch name is given"):
        get_all_docker_tags(repositories=["docker"], image_name="test", branch_name="test", registry="example.com")


def test_get_all_docker_tags_branch_name_missing_repositories() -> None:
    with pytest.raises(ValueError, match="No repositories provided"):
        get_all_docker_tags(repositories=[], image_name="test", branch_name="test", registry="example.com")


def test_test_get_all_docker_tags_branch() -> None:
    assert get_all_docker_tags(
        repositories=["docker"],
        image_name="test",
        branch_name="test",
        build_number=1,
        registry="example.com",
    ) == [
        "example.com/docker/test:test-latest",
        "example.com/docker/test:test-1",
    ]


@patch("voraus_pipeline_utils.methods.docker.should_add_latest_docker_tag")
def test_test_get_all_docker_tags_tag(mock_should_add_latest: MagicMock) -> None:
    mock_should_add_latest.return_value = True

    assert get_all_docker_tags(
        repositories=["docker"], image_name="test", tag="my-tag", registry="artifactory.vorausrobotik.com"
    ) == [
        "artifactory.vorausrobotik.com/docker/test:my-tag",
        "artifactory.vorausrobotik.com/docker/test:latest",
    ]


@patch("voraus_pipeline_utils.methods.docker.should_add_latest_docker_tag")
def test_test_get_all_docker_tags_branch_and_tag(mock_should_add_latest: MagicMock) -> None:
    mock_should_add_latest.return_value = True

    assert get_all_docker_tags(
        repositories=["docker"],
        image_name="test",
        branch_name="whatever",
        build_number=1,
        tag="1.2.0",
        registry="artifactory.vorausrobotik.com",
    ) == [
        "artifactory.vorausrobotik.com/docker/test:1.2.0",
        "artifactory.vorausrobotik.com/docker/test:latest",
    ]


@patch("voraus_pipeline_utils.methods.docker.should_add_latest_docker_tag")
def test_get_all_docker_tags_with_latest_on_main_highest_version(
    mock_should_add_latest: MagicMock,
) -> None:
    """Test that 'latest' tag is added when version is the highest."""
    mock_should_add_latest.return_value = True

    result = get_all_docker_tags(
        repositories=["docker"],
        image_name="test",
        tag="2.0.0",
        registry="artifactory.vorausrobotik.com",
    )

    assert result == [
        "artifactory.vorausrobotik.com/docker/test:2.0.0",
        "artifactory.vorausrobotik.com/docker/test:latest",
    ]
    mock_should_add_latest.assert_called_once_with(version_tag="2.0.0")


@patch("voraus_pipeline_utils.methods.docker.should_add_latest_docker_tag")
def test_get_all_docker_tags_without_latest_on_main_hotfix(
    mock_should_add_latest: MagicMock,
) -> None:
    """Test that 'latest' tag is NOT added for hotfix releases."""
    mock_should_add_latest.return_value = False

    result = get_all_docker_tags(
        repositories=["docker"],
        image_name="test",
        tag="1.1.2",
        registry="artifactory.vorausrobotik.com",
    )

    assert result == [
        "artifactory.vorausrobotik.com/docker/test:1.1.2",
    ]
    mock_should_add_latest.assert_called_once_with(version_tag="1.1.2")


@patch("voraus_pipeline_utils.methods.docker.should_add_latest_docker_tag")
def test_get_all_docker_tags_without_latest_not_highest(
    mock_should_add_latest: MagicMock,
) -> None:
    """Test that 'latest' tag is NOT added when version is not the highest."""
    mock_should_add_latest.return_value = False

    result = get_all_docker_tags(
        repositories=["docker"],
        image_name="test",
        tag="1.2.0",
        registry="artifactory.vorausrobotik.com",
    )

    assert result == [
        "artifactory.vorausrobotik.com/docker/test:1.2.0",
    ]
    mock_should_add_latest.assert_called_once_with(version_tag="1.2.0")


@patch("voraus_pipeline_utils.methods.docker.should_add_latest_docker_tag")
def test_get_all_docker_tags_with_multiple_repositories(
    mock_should_add_latest: MagicMock,
) -> None:
    """Test that 'latest' tag is added to all repositories when appropriate."""
    mock_should_add_latest.return_value = True

    result = get_all_docker_tags(
        repositories=["docker", "releases"],
        image_name="test",
        tag="3.0.0",
        registry="artifactory.vorausrobotik.com",
    )

    assert result == [
        "artifactory.vorausrobotik.com/docker/test:3.0.0",
        "artifactory.vorausrobotik.com/releases/test:3.0.0",
        "artifactory.vorausrobotik.com/docker/test:latest",
        "artifactory.vorausrobotik.com/releases/test:latest",
    ]
    mock_should_add_latest.assert_called_once_with(version_tag="3.0.0")
