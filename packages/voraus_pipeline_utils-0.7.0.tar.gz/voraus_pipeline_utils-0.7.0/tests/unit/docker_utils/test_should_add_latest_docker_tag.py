"""Contains all tests for the should_add_latest_docker_tag method."""

from unittest.mock import MagicMock, patch

import pytest
from packaging.version import Version

from voraus_pipeline_utils.methods.docker import should_add_latest_docker_tag


@patch("voraus_pipeline_utils.methods.docker.list_semver_tags")
def test_should_add_latest_docker_tag_no_existing_tags(
    mock_list_semver_tags: MagicMock, caplog: pytest.LogCaptureFixture
) -> None:
    """Test that latest tag is added when no existing tags exist."""
    mock_list_semver_tags.return_value = ()

    with caplog.at_level("INFO"):
        result = should_add_latest_docker_tag("1.0.0")

    assert result is True
    assert "Adding 'latest' tag: no existing version tags found" in caplog.text


@patch("voraus_pipeline_utils.methods.docker.list_semver_tags")
def test_should_add_latest_docker_tag_is_highest(
    mock_list_semver_tags: MagicMock, caplog: pytest.LogCaptureFixture
) -> None:
    """Test that latest tag is added when the current version is the highest existing tag."""
    mock_list_semver_tags.return_value = (Version("1.0.0"), Version("1.1.0"), Version("2.1.0"))

    with caplog.at_level("INFO"):
        result = should_add_latest_docker_tag("2.1.0")

    assert result is True
    assert "Adding 'latest' tag: version 2.1.0 is the highest existing version" in caplog.text


@patch("voraus_pipeline_utils.methods.docker.list_semver_tags")
def test_should_add_latest_docker_tag_hotfix_lower_version(
    mock_list_semver_tags: MagicMock, caplog: pytest.LogCaptureFixture
) -> None:
    """Test that latest tag is NOT added for hotfix releases with a lower version."""
    mock_list_semver_tags.return_value = (Version("1.0.0"), Version("1.1.2"), Version("1.2.0"), Version("2.0.0"))

    with caplog.at_level("INFO"):
        result = should_add_latest_docker_tag("1.1.2")

    assert result is False
    assert "Not adding 'latest' tag: version 1.1.2 is lower than the highest existing version 2.0.0" in caplog.text


@patch("voraus_pipeline_utils.methods.docker.list_semver_tags")
def test_should_add_latest_docker_tag_invalid_version(
    mock_list_semver_tags: MagicMock, caplog: pytest.LogCaptureFixture
) -> None:
    """Non-semver tags must not fail the build and never receive the 'latest' tag."""
    mock_list_semver_tags.return_value = (Version("1.0.0"),)

    with caplog.at_level("INFO"):
        result = should_add_latest_docker_tag("not-a-version")

    assert result is False
    assert "Not adding 'latest' tag: 'not-a-version' is not a valid semver tag" in caplog.text


@pytest.mark.parametrize("prerelease_version", ["1.2.0rc1", "1.2.0a1", "1.2.0b2", "1.2.0.dev1"])
@patch("voraus_pipeline_utils.methods.docker.list_semver_tags")
def test_should_add_latest_docker_tag_prerelease(
    mock_list_semver_tags: MagicMock, caplog: pytest.LogCaptureFixture, prerelease_version: str
) -> None:
    """Pre-releases must never receive the 'latest' tag."""
    mock_list_semver_tags.return_value = (Version("1.0.0"),)

    with caplog.at_level("INFO"):
        result = should_add_latest_docker_tag(prerelease_version)

    assert result is False
    assert "is a pre-release" in caplog.text


@patch("voraus_pipeline_utils.methods.docker.list_semver_tags")
def test_should_add_latest_docker_tag_post_release(
    mock_list_semver_tags: MagicMock, caplog: pytest.LogCaptureFixture
) -> None:
    """Post-releases qualify for the 'latest' tag when they are the highest version."""
    mock_list_semver_tags.return_value = (Version("1.0.0"), Version("1.2.0.post1"))

    with caplog.at_level("INFO"):
        result = should_add_latest_docker_tag("1.2.0.post1")

    assert result is True
