"""Contains all tests for the git methods."""

from unittest.mock import MagicMock, PropertyMock, patch

import pytest
from packaging.version import InvalidVersion, Version

from voraus_pipeline_utils.methods.git import list_semver_tags, list_tags


@patch("voraus_pipeline_utils.methods.git.Repo")
def test_list_tags(mock_repo: MagicMock) -> None:
    """Test that list_tags returns all tags from the repository."""
    type(mock_repo.return_value).tags = PropertyMock(return_value=["v1.0.0", "v2.0.0"])

    result = list_tags()

    assert result == ("v1.0.0", "v2.0.0")
    mock_repo.assert_called_once_with(".")


@patch("voraus_pipeline_utils.methods.git.list_tags")
def test_list_semver_tags_valid_tags(mock_list_tags: MagicMock) -> None:
    """Test that list_semver_tags correctly parses and sorts valid semver tags."""
    mock_list_tags.return_value = ("1.0.0", "2.1.0", "1.5.0")

    result = list_semver_tags()

    assert len(result) == 3
    assert result == (Version("1.0.0"), Version("1.5.0"), Version("2.1.0"))


@patch("voraus_pipeline_utils.methods.git.list_tags")
def test_list_semver_tags_mixed_valid_invalid(mock_list_tags: MagicMock, caplog: pytest.LogCaptureFixture) -> None:
    """Test that invalid tags are skipped by default."""
    mock_list_tags.return_value = ("1.0.0", "not-a-version", "2.0.0")

    result = list_semver_tags()

    assert len(result) == 2
    assert result == (Version("1.0.0"), Version("2.0.0"))
    assert "Skipping invalid semantic version tag: not-a-version" in caplog.text


@patch("voraus_pipeline_utils.methods.git.list_tags")
def test_list_semver_tags_raise_on_invalid(mock_list_tags: MagicMock) -> None:
    """Test that InvalidVersion is raised when raise_on_invalid=True."""
    mock_list_tags.return_value = ("1.0.0", "invalid-tag")

    with pytest.raises(InvalidVersion):
        list_semver_tags(raise_on_invalid=True)


@patch("voraus_pipeline_utils.methods.git.list_tags")
def test_list_semver_tags_empty(mock_list_tags: MagicMock) -> None:
    """Test that an empty tuple is returned when no tags exist."""
    mock_list_tags.return_value = ()

    result = list_semver_tags()

    assert result == ()
