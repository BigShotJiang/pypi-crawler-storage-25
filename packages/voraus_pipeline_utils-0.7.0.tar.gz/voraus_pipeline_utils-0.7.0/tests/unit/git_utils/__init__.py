"""This module contains tests for git methods."""
