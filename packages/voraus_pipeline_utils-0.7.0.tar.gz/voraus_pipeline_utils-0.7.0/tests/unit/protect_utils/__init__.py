"""Contains all unit tests for the protect helpers."""
