"""Integration tests for the Docker 'latest' tag policy against real git repositories."""
