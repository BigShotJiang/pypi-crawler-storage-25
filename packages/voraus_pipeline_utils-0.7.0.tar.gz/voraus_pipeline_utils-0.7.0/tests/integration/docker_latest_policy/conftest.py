"""Fixtures for the Docker 'latest' tag policy integration tests."""

from collections.abc import Callable, Iterator
from pathlib import Path

import pytest
from git import Repo


@pytest.fixture(name="git_repo", autouse=True)
def git_repo_fixture(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[Repo]:
    """Initialize an empty git repository in a temp directory and chdir into it.

    A default user identity is configured so commits can be created without
    relying on the ambient git configuration.
    """
    repo = Repo.init(tmp_path)
    with repo.config_writer() as cw:
        cw.set_value("user", "name", "Integration Test")
        cw.set_value("user", "email", "integration@test.local")

    monkeypatch.chdir(tmp_path)
    yield repo
    repo.close()


@pytest.fixture(name="make_tagged_commit")
def make_tagged_commit_fixture(git_repo: Repo) -> Callable[[str], None]:
    """Return a helper that creates a commit and tags it with the given tag name.

    Each call produces a unique file change so git accepts the commit.
    """
    counter = {"n": 0}

    def _make(tag: str) -> None:
        counter["n"] += 1
        workdir = Path(git_repo.working_dir)
        marker = workdir / f"file_{counter['n']}.txt"
        marker.write_text(f"content for {tag}\n")
        git_repo.index.add([str(marker)])
        git_repo.index.commit(f"Add {marker.name} for tag {tag}")
        git_repo.create_tag(tag)

    return _make
