"""Integration tests that exercise the Docker 'latest' tag policy against a real git repository.

Each scenario initializes a fresh git repository in a temporary directory, applies a set of
tags via real commits, and verifies the behavior of `list_tags`, `list_semver_tags` and
`should_add_latest_docker_tag` end-to-end.

`should_add_latest_docker_tag` is always called with a version that has already been tagged,
matching how the CI pipeline invokes it.
"""

from collections.abc import Callable

import pytest
from packaging.version import InvalidVersion, Version

from voraus_pipeline_utils.methods.docker import should_add_latest_docker_tag
from voraus_pipeline_utils.methods.git import list_semver_tags, list_tags


class TestListTags:
    """Scenarios for `list_tags` against a real git repository."""

    def test_empty_repo_returns_no_tags(self) -> None:
        """An empty repository without any tags yields an empty result."""
        assert list_tags() == ()

    def test_returns_all_created_tags(self, make_tagged_commit: Callable[[str], None]) -> None:
        """All tags applied to the repository are returned."""
        for tag in ("1.0.0", "1.1.0", "2.0.0"):
            make_tagged_commit(tag)

        assert set(list_tags()) == {"1.0.0", "1.1.0", "2.0.0"}

    def test_includes_non_semver_tags(self, make_tagged_commit: Callable[[str], None]) -> None:
        """Non-semver tags are returned alongside semver tags without filtering."""
        make_tagged_commit("1.0.0")
        make_tagged_commit("release-candidate")

        assert set(list_tags()) == {"1.0.0", "release-candidate"}


class TestListSemverTags:
    """Scenarios for `list_semver_tags` against a real git repository."""

    def test_empty_repo(self) -> None:
        """An empty repository yields an empty tuple of versions."""
        assert list_semver_tags() == ()

    def test_tags_are_sorted_ascending(self, make_tagged_commit: Callable[[str], None]) -> None:
        """Tags are returned sorted as PEP 440 versions, not lexicographically."""
        for tag in ("2.0.0", "1.0.0", "1.10.0", "1.2.0"):
            make_tagged_commit(tag)

        assert list_semver_tags() == (
            Version("1.0.0"),
            Version("1.2.0"),
            Version("1.10.0"),
            Version("2.0.0"),
        )

    def test_invalid_tags_are_skipped_by_default(
        self, make_tagged_commit: Callable[[str], None], caplog: pytest.LogCaptureFixture
    ) -> None:
        """Non-parseable tags are skipped and a warning is emitted."""
        make_tagged_commit("1.0.0")
        make_tagged_commit("not-a-version")
        make_tagged_commit("2.0.0")

        result = list_semver_tags()

        assert result == (Version("1.0.0"), Version("2.0.0"))
        assert "Skipping invalid semantic version tag: not-a-version" in caplog.text

    def test_invalid_tag_raises_when_requested(self, make_tagged_commit: Callable[[str], None]) -> None:
        """With raise_on_invalid=True, an unparsable tag propagates as InvalidVersion."""
        make_tagged_commit("1.0.0")
        make_tagged_commit("nope")

        with pytest.raises(InvalidVersion):
            list_semver_tags(raise_on_invalid=True)

    def test_v_prefixed_tags_are_parsed(self, make_tagged_commit: Callable[[str], None]) -> None:
        """`vX.Y.Z` style tags are accepted because PEP 440 strips the leading 'v'."""
        make_tagged_commit("v1.0.0")
        make_tagged_commit("v2.0.0")

        assert list_semver_tags() == (Version("1.0.0"), Version("2.0.0"))


class TestShouldAddLatestDockerTag:
    """End-to-end scenarios for `should_add_latest_docker_tag`.

    In every scenario the "current" version has already been tagged in the repo, mirroring
    real pipeline behavior where the build is triggered by that git tag.
    """

    def test_latest_is_added_when_current_is_the_only_tag(
        self, make_tagged_commit: Callable[[str], None], caplog: pytest.LogCaptureFixture
    ) -> None:
        """The very first release receives 'latest'."""
        make_tagged_commit("1.0.0")

        with caplog.at_level("INFO"):
            assert should_add_latest_docker_tag("1.0.0") is True
        assert "version 1.0.0 is the highest existing version" in caplog.text

    def test_latest_is_added_when_current_is_highest(
        self, make_tagged_commit: Callable[[str], None], caplog: pytest.LogCaptureFixture
    ) -> None:
        """The current version receives 'latest' when it is the highest tag in the repo."""
        for tag in ("1.0.0", "1.1.0", "2.0.0", "2.1.0"):
            make_tagged_commit(tag)

        with caplog.at_level("INFO"):
            assert should_add_latest_docker_tag("2.1.0") is True
        assert "version 2.1.0 is the highest existing version" in caplog.text

    def test_hotfix_on_older_minor_does_not_get_latest(
        self, make_tagged_commit: Callable[[str], None], caplog: pytest.LogCaptureFixture
    ) -> None:
        """A hotfix like 1.1.2 released after 2.0.0 must not receive 'latest'."""
        for tag in ("1.0.0", "1.1.0", "1.1.1", "1.1.2", "1.2.0", "2.0.0"):
            make_tagged_commit(tag)

        with caplog.at_level("INFO"):
            assert should_add_latest_docker_tag("1.1.2") is False
        assert "version 1.1.2 is lower than the highest existing version 2.0.0" in caplog.text

    def test_semver_ordering_is_numeric_not_lexicographic(self, make_tagged_commit: Callable[[str], None]) -> None:
        """1.10.0 is higher than 1.2.0; 1.3.0 released afterwards must not receive 'latest'."""
        for tag in ("1.2.0", "1.3.0", "1.10.0"):
            make_tagged_commit(tag)

        assert should_add_latest_docker_tag("1.10.0") is True
        assert should_add_latest_docker_tag("1.3.0") is False

    def test_non_semver_tags_are_ignored(self, make_tagged_commit: Callable[[str], None]) -> None:
        """Non-semver tags must not influence the decision for the current version."""
        for tag in ("release-candidate", "nightly", "0.0.1"):
            make_tagged_commit(tag)

        assert should_add_latest_docker_tag("0.0.1") is True

    def test_final_release_over_its_pre_release(self, make_tagged_commit: Callable[[str], None]) -> None:
        """Per PEP 440 ``2.0.0rc1 < 2.0.0``; the final release receives 'latest'."""
        make_tagged_commit("2.0.0rc1")
        make_tagged_commit("2.0.0")

        assert should_add_latest_docker_tag("2.0.0") is True

    def test_pre_release_of_next_version_does_not_get_latest(self, make_tagged_commit: Callable[[str], None]) -> None:
        """Pre-releases never receive the 'latest' tag, even if higher than any final release."""
        make_tagged_commit("2.0.0")
        make_tagged_commit("2.1.0rc1")

        assert should_add_latest_docker_tag("2.1.0rc1") is False

    def test_late_pre_release_of_released_version_does_not_get_latest(
        self, make_tagged_commit: Callable[[str], None]
    ) -> None:
        """A pre-release published after its final release is older and must not receive 'latest'."""
        make_tagged_commit("2.0.0")
        make_tagged_commit("2.0.0rc2")

        assert should_add_latest_docker_tag("2.0.0rc2") is False

    def test_invalid_current_version_does_not_get_latest(self, make_tagged_commit: Callable[[str], None]) -> None:
        """Unparsable version tags must not fail the pipeline and never receive 'latest'."""
        make_tagged_commit("1.0.0")

        assert should_add_latest_docker_tag("not-a-version") is False
