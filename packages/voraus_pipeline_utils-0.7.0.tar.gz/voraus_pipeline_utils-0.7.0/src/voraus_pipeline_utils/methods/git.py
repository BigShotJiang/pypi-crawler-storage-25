"""Contains all git related methods."""

import logging

from git import Repo
from packaging.version import InvalidVersion, Version
from packaging.version import parse as parse_version

_logger = logging.getLogger(__name__)


def list_tags() -> tuple[str, ...]:
    """List all git tags in the current repository.

    Returns:
        A tuple of all git tag names as strings.
    """
    return tuple(str(tag) for tag in Repo(".").tags)


def list_semver_tags(*, raise_on_invalid: bool = False) -> tuple[Version, ...]:
    """Parse git tags as semantic versions.

    Args:
        raise_on_invalid: If True, raises an exception when encountering an invalid version tag.
                         If False, logs a warning and skips invalid tags.

    Returns:
        A tuple of successfully parsed Version objects.

    Raises:
        InvalidVersion: If raise_on_invalid is True and an invalid version tag is encountered.
    """
    valid_versions: list[Version] = []
    for tag in list_tags():
        try:
            semver_tag = parse_version(tag)
            valid_versions.append(semver_tag)
        except InvalidVersion:
            if raise_on_invalid:
                raise
            _logger.warning("Skipping invalid semantic version tag: %s", tag)
    return tuple(sorted(valid_versions))
