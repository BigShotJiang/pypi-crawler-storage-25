"""This module defines the protect CLI commands for encrypting files."""

from enum import StrEnum
from pathlib import Path
from typing import Annotated

import typer

from voraus_pipeline_utils.methods.protect import protect_file


class FileType(StrEnum):
    """Supported file types for protection."""

    wheel = "wheel"
    elf = "elf"


def protect(  # noqa: PLR0913
    file_type: Annotated[FileType, typer.Argument(help="Type of file to protect (wheel or elf)")],
    file: Annotated[Path, typer.Argument(help="Path to the file to protect.")],
    identifier: Annotated[str, typer.Option(help="The protection identifier")],
    access_key_id: Annotated[
        str, typer.Option(help="Access key ID for authentication.", envvar="PROTECTOR_ACCESS_KEY_ID", hide_input=True)
    ],
    access_secret_key: Annotated[
        str,
        typer.Option(
            help="Access secret key for authentication.", envvar="PROTECTOR_ACCESS_SECRET_KEY", hide_input=True
        ),
    ],
    replace: Annotated[  # noqa: FBT002
        bool, typer.Option(help="Whether to replace the original file or create a new file.")
    ] = True,
    api_endpoint: Annotated[
        str, typer.Option(help="The protector API endpoint.", envvar="PROTECTOR_API_ENDPOINT")
    ] = "https://protector.vorausrobotik.com",
) -> None:
    r"""Encrypt files using the voraus-software-protector service.

    This feature enables secure distribution of protected files in CI/CD pipelines.
    The command encrypts files via REST API. Credentials can be provided via environment
    variables or CLI options.

    Environment Variables:
    - PROTECTOR_ACCESS_KEY_ID: Access key ID for authentication
    - PROTECTOR_ACCESS_SECRET_KEY: Access secret key for authentication
    - PROTECTOR_API_ENDPOINT: API endpoint URL (optional, defaults to https://protector.vorausrobotik.com)

    Examples:
    Basic usage with environment variables::

        export PROTECTOR_ACCESS_KEY_ID="your-key-id"
        export PROTECTOR_ACCESS_SECRET_KEY="your-secret-key"
        vpu protect wheel dist/my_package-1.0.0-py3-none-any.whl --identifier=my-package-1

    Using explicit credentials::

        vpu protect wheel dist/my_package-1.0.0-py3-none-any.whl \\
            --identifier=my-package-1 \\
            --access-key-id=your-key-id \\
            --access-secret-key=your-secret-key

    Protecting an ELF binary::

        vpu protect elf build/my_binary --identifier=my-binary-1

    Create encrypted copy without replacing original::

        vpu protect wheel dist/my_package-1.0.0-py3-none-any.whl \\
            --identifier=my-package-1 \\
            --no-replace

    Jenkins Pipeline Example::

        pipeline {
            agent any
            stages {
                stage('Protect Wheel') {
                    steps {
                        withCredentials([
                            usernamePassword(
                                credentialsId: 'protector-credentials',
                                usernameVariable: 'PROTECTOR_ACCESS_KEY_ID',
                                passwordVariable: 'PROTECTOR_ACCESS_SECRET_KEY'
                            )
                        ]) {
                            sh '''
                                vpu protect wheel dist/*.whl --identifier=my-package-1
                            '''
                        }
                    }
                }
            }
        }

    GitHub Actions Example::

        - name: Protect wheel
          env:
            PROTECTOR_ACCESS_KEY_ID: ${{ secrets.PROTECTOR_ACCESS_KEY_ID }}
            PROTECTOR_ACCESS_SECRET_KEY: ${{ secrets.PROTECTOR_ACCESS_SECRET_KEY }}
          run: |
            vpu protect wheel dist/*.whl --identifier=my-package-1

    """
    # Map FileType enum to encryption endpoint type
    encryption_type_map = {
        FileType.wheel: "python",
        FileType.elf: "elf",
    }

    protect_file(
        file_path=file,
        file_type=encryption_type_map[file_type],
        identifier=identifier,
        api_endpoint=api_endpoint,
        access_key_id=access_key_id,
        access_secret_key=access_secret_key,
        replace=replace,
    )
