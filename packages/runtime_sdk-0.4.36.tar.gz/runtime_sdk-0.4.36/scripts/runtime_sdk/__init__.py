from importlib.metadata import PackageNotFoundError, version

from runtime_sdk.client import RuntimeAPIError, RuntimeClient
from runtime_sdk.config import PendingSignup, RuntimeConfig, RuntimeConfigError

try:
    __version__ = version("runtime-sdk")
except PackageNotFoundError:  # pragma: no cover - local source tree fallback
    __version__ = "0.0.0"

__all__ = [
    "PendingSignup",
    "RuntimeAPIError",
    "RuntimeClient",
    "RuntimeConfig",
    "RuntimeConfigError",
    "__version__",
]
