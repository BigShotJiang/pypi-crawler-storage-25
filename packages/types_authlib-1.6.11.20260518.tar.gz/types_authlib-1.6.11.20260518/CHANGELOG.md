## 1.6.11.20260518 (2026-05-18)

Upgrade black to 26.5.0 ([#15801](https://github.com/python/typeshed/pull/15801))

## 1.6.11.20260514 (2026-05-14)

[Authlib] Add default for `generate_token(chars)` ([#15787](https://github.com/python/typeshed/pull/15787))

[Authlib] `add_params_to_qs`, `extract_params`: Fix accepted types ([#15786](https://github.com/python/typeshed/pull/15786))

## 1.6.11.20260512 (2026-05-12)

[Authlib] Fix JsonWebKey.import_key typing ([#15766](https://github.com/python/typeshed/pull/15766))

## 1.6.11.20260508 (2026-05-08)

Import some items from typing instead of typing_extensions ([#15711](https://github.com/python/typeshed/pull/15711))

Part of #13782

## 1.6.11.20260418 (2026-04-18)

[Authlib] Bump to 1.6.11 ([#15647](https://github.com/python/typeshed/pull/15647))

## 1.6.10.20260414 (2026-04-14)

[stubsabot] Bump Authlib to 1.6.10 ([#15643](https://github.com/python/typeshed/pull/15643))

## 1.6.9.20260408 (2026-04-08)

Use dashes instead of underscores for METADATA.toml field names ([#15614](https://github.com/python/typeshed/pull/15614))

## 1.6.9.20260402 (2026-04-02)

Rename `requires` to `dependencies` in METADATA files ([#15594](https://github.com/python/typeshed/pull/15594))

Update most test/lint dependencies ([#15582](https://github.com/python/typeshed/pull/15582))

Update mypy to 1.20.0 ([#15588](https://github.com/python/typeshed/pull/15588))

## 1.6.9.20260303 (2026-03-03)

[Authlib] Update to 1.6.9 ([#15481](https://github.com/python/typeshed/pull/15481))

## 1.6.8.20260215 (2026-02-15)

[stubsabot] Bump Authlib to 1.6.8 ([#15429](https://github.com/python/typeshed/pull/15429))

## 1.6.7.20260208 (2026-02-08)

[stubsabot] Bump Authlib to 1.6.7 ([#15382](https://github.com/python/typeshed/pull/15382))

Release: https://pypi.org/pypi/Authlib/1.6.7
Repository: https://github.com/authlib/authlib
Typeshed stubs: https://github.com/python/typeshed/tree/main/stubs/Authlib
Diff: https://github.com/authlib/authlib/compare/v1.6.6...v1.6.7

Stubsabot analysis of the diff between the two releases:
 - 0 public Python files have been added.
 - 0 files included in typeshed's stubs have been deleted.
 - 5 files included in typeshed's stubs have been modified or renamed: `authlib/consts.py`, `authlib/jose/__init__.py`, `authlib/oauth2/rfc9101/authorization_server.py`, `authlib/oidc/core/grants/util.py`, `authlib/oidc/core/userinfo.py`.
 - Total lines of Python code added: 37.
 - Total lines of Python code deleted: 12.

If stubtest fails for this PR:
- Leave this PR open (as a reminder, and to prevent stubsabot from opening another PR)
- Fix stubtest failures in another PR, then close this PR

Note that you will need to close and re-open the PR in order to trigger CI

Co-authored-by: stubsabot <>

## 1.6.6.20260130 (2026-01-30)

Update outdated upstream_repository fields ([#15334](https://github.com/python/typeshed/pull/15334))

## 1.6.6.20260116 (2026-01-16)

[Authlib] Annotate more ([#15203](https://github.com/python/typeshed/pull/15203))

## 1.6.6.20251220 (2025-12-20)

[Authlib] Update return types ([#15153](https://github.com/python/typeshed/pull/15153))

* Remove return types for not implemented methods
* Add some obvious return types
* Fix some incorrect types found

[Authlib] Add integrations dirs ([#15147](https://github.com/python/typeshed/pull/15147))

## 1.6.6.20251214 (2025-12-14)

[Authlib] Update to 1.6.6 ([#15131](https://github.com/python/typeshed/pull/15131))

Remove outdated allowlist entries ([#15133](https://github.com/python/typeshed/pull/15133))

## 1.6.5.20251005 (2025-10-05)

[Authlib] Update to 1.6.5 ([#14830](https://github.com/python/typeshed/pull/14830))

## 1.6.4.20250920 (2025-09-20)

Added annotation for fetch_request_token of OAuth1Client class ([#14711](https://github.com/python/typeshed/pull/14711))

## 1.6.4.20250919 (2025-09-19)

[Authlib] Update to 1.6.4 ([#14736](https://github.com/python/typeshed/pull/14736))

## 1.6.2.20250914 (2025-09-14)

Update mypy to 1.18.1 ([#14699](https://github.com/python/typeshed/pull/14699))

## 1.6.2.20250825 (2025-08-25)

[Authlib] Update to 1.6.2 ([#14635](https://github.com/python/typeshed/pull/14635))

## 1.6.0.20250809 (2025-08-09)

Mark stub-only private symbols as `@type_check_only` in third-party stubs ([#14545](https://github.com/python/typeshed/pull/14545))

## 1.6.0.20250711 (2025-07-11)

[Authlib] Mark as partial again ([#14394](https://github.com/python/typeshed/pull/14394))

Some integrations are missing from the stubs

## 1.6.0.20250708 (2025-07-08)

[Authlib] Add missing stubs ([#14368](https://github.com/python/typeshed/pull/14368))

## 1.6.0.20250705 (2025-07-05)

Bump Authlib to ~=1.6.0 ([#14364](https://github.com/python/typeshed/pull/14364))

## 1.5.2.20250704 (2025-07-04)

[Authlib] Update to 1.5.2 ([#13840](https://github.com/python/typeshed/pull/13840))

## 1.5.0.20250608 (2025-06-08)

[Authlib] Fix stubtest for latest Python 3.13 patch release ([#14233](https://github.com/python/typeshed/pull/14233))

## 1.5.0.20250516 (2025-05-16)

Replace `Incomplete | None = None` in third party stubs ([#14063](https://github.com/python/typeshed/pull/14063))

## 1.5.0.20250416 (2025-04-16)

Update authlib to 1.5.* ([#13540](https://github.com/python/typeshed/pull/13540))

## 1.4.0.20250408 (2025-04-08)

Improve `Authlib` ([#13801](https://github.com/python/typeshed/pull/13801))

## 1.4.0.20241230 (2024-12-30)

[stubsabot] Bump Authlib to 1.4.* ([#13329](https://github.com/python/typeshed/pull/13329))

Release: https://pypi.org/pypi/Authlib/1.4.0
Repository: https://github.com/lepture/authlib
Typeshed stubs: https://github.com/python/typeshed/tree/main/stubs/Authlib
Diff: https://github.com/lepture/authlib/compare/v1.3.2...v1.4.0

Stubsabot analysis of the diff between the two releases:
 - 0 public Python files have been added.
 - 0 files included in typeshed's stubs have been deleted.
 - 5 files included in typeshed's stubs have been modified or renamed: `authlib/consts.py`, `authlib/jose/rfc7517/key_set.py`, `authlib/oauth2/rfc9068/introspection.py`, `authlib/oauth2/rfc9068/revocation.py`, `authlib/oidc/core/grants/util.py`.
 - Total lines of Python code added: 90.
 - Total lines of Python code deleted: 13.

## 1.3.0.20241229 (2024-12-29)

Authlib (v2) ([#13140](https://github.com/python/typeshed/pull/13140))

Co-authored-by: Brian Villemarette <brian.villemarette@trucesoftware.com>
Co-authored-by: Jelle Zijlstra <jelle.zijlstra@gmail.com>

