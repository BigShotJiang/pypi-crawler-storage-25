from typing import Final

UNICODE_ASCII_CHARACTER_SET: Final[str]

def generate_token(length: int = 30, chars: str = UNICODE_ASCII_CHARACTER_SET) -> str: ...  # noqa: Y011
def is_secure_transport(uri: str) -> bool: ...
