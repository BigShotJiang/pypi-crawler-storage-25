import inspect
import json
import os
import site
import sys
import logging
from functools import wraps
from importlib.metadata import distributions
from typing import Optional

import feast
import grpc
import mlflow
from feast.errors import FeastError
from feast.protos.feast.registry.RegistryServer_pb2_grpc import RegistryServerStub
from mlflow.models.model import Model
from mlflow.tracking import MlflowClient
from mlflow.tracking._tracking_service.client import TrackingServiceClient

from wedata_ml_runtime.common.base_client import BaseClient
from wedata_ml_runtime.experiment import (
    create_experiment,
    delete_experiment,
    rename_experiment,
    restore_experiment,
    get_experiment,
    get_experiment_by_name,
    search_experiments,
    set_experiment
)


__doc__ = """
WeData 3.0 Machine Learning Notebook Kernel runtime client.
"""

PROXY_HEADER_KEY_IP = "X-Target-Service-IP"
PROXY_HEADER_KEY_PORT = "X-Target-Service-PORT"

FEAST_PROXY_ENV_KEY_IP = "FEAST_SERVICE_IP"
FEAST_PROXY_ENV_KEY_PORT = "FEAST_SERVICE_PORT"

MLFLOW_PROXY_ENV_KEY_IP = "MLFLOW_SERVICE_IP"
MLFLOW_PROXY_ENV_KEY_PORT = "MLFLOW_SERVICE_PORT"

KERNEL_WEDATA_PREFIX = "KERNEL_WEDATA_"

# Data-science experiment types allowed to be operated on by the decorators below.
_ALLOWED_DS_TYPES = (
    "MACHINE_LEARNING",
    "DEEP_LEARNING",
    "REGRESSION",
    "CLASSIFICATION",
    "FORECASTING",
)


def get_kernel_env_key(key):
    """Return a WeData-specific environment variable key with the kernel prefix.

    This prefix avoids collisions with standard environment variables.
    Example: ``key = "REGION"`` returns ``"KERNEL_WEDATA_REGION"``.

    :param key: logical variable name (without prefix).
    :return: the prefixed environment variable name.
    """
    return KERNEL_WEDATA_PREFIX + key


def _make_log_after_terminated(base_url: str, workspace_id: str, ap_region_id: int):
    """Build a post-hook decorator for ``set_terminated`` that logs the run URL."""
    def log_after_terminated(func):
        @wraps(func)
        def wrapper(self, run_id, *args, **kwargs):
            print("wedata log_after_terminated wrapper")
            result = func(self, run_id, *args, **kwargs)
            run_info = self.store.get_run(run_id).info
            run_name = run_info.run_name
            experiment_id = run_info.experiment_id
            experiment_url = (
                f"{base_url}/datascience/experiments/experiments-single/{experiment_id}"
                f"?o={workspace_id}&r={ap_region_id}"
            )
            run_url = (
                f"{base_url}/datascience/experiments/task-detail-learn/{run_id}"
                f"?o={workspace_id}&r={ap_region_id}"
            )
            print(f"View run {run_name} at :{run_url}")
            print(f"View experiment at: {experiment_url}")
            return result

        return wrapper

    return log_after_terminated


def _make_inject_model_version_tag(workspace_id: str):
    """Build a decorator that injects WeData tags onto registered model versions."""
    def inject_model_version_tag(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            print("wedata inject_model_version_tag wrapper")
            registered_model_name = kwargs.get("registered_model_name")
            if registered_model_name is None:
                sig = inspect.signature(func)
                params = list(sig.parameters.keys())
                if "registered_model_name" in params:
                    idx = params.index("registered_model_name") - 1
                    if len(args) > idx:
                        registered_model_name = args[idx]
            result = func(*args, **kwargs)
            model_version = result.registered_model_version
            if registered_model_name and model_version:
                from mlflow import MlflowClient
                MlflowClient().set_model_version_tag(
                    registered_model_name, model_version, "mlflow.user",
                    os.environ.get(get_kernel_env_key("QCLOUD_SUBUIN"), ""),
                )
                MlflowClient().set_model_version_tag(
                    registered_model_name, model_version, "wedata.workspace", workspace_id,
                )
                MlflowClient().set_model_version_tag(
                    registered_model_name, model_version, "wedata.datascience.type", "MACHINE_LEARNING",
                )
            return result

        return wrapper

    return inject_model_version_tag


def _resolve_tags_from_args(method_name: str, args_list: list):
    """Locate the positional ``tags`` argument index and its current value by method name."""
    tags_index = -1
    current_tags = None
    if method_name in ("create_experiment", "create_run"):
        tags_index = 2
        if len(args_list) >= 3:
            current_tags = args_list[2]
    elif method_name in ("create_registered_model",):
        tags_index = 1
        if len(args_list) >= 2:
            current_tags = args_list[1]
    elif method_name in ("create_model_version",):
        tags_index = 4
        if len(args_list) >= 5:
            current_tags = args_list[4]
    return tags_index, current_tags


def inject_workspace_tag(func):
    """Decorator that injects the ``wedata.workspace`` and related tags into write operations."""
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        workspace = os.getenv("WEDATA_WORKSPACE_ID")
        args_list = list(args)
        if workspace:
            if "tags" in kwargs:
                tags = kwargs["tags"] or {}
                tags = tags.copy()
                # If caller already supplies wedata.workspace / wedata.datascience.type, keep caller's values.
                if "wedata.workspace" not in tags:
                    tags["wedata.workspace"] = workspace
                if "wedata.datascience.type" not in tags:
                    tags["wedata.datascience.type"] = "MACHINE_LEARNING"
                kwargs["tags"] = tags
            else:
                tags_index, current_tags = _resolve_tags_from_args(
                    func.__name__, args_list
                )
                current_tags = current_tags.copy() if current_tags else {}
                current_tags["wedata.workspace"] = workspace
                current_tags["wedata.datascience.type"] = "MACHINE_LEARNING"
                current_tags["mlflow.user"] = os.environ.get(get_kernel_env_key("QCLOUD_SUBUIN"), "")
                # If tags lives in positional args, update args_list in place.
                if tags_index >= 0 and len(args_list) > tags_index:
                    args_list[tags_index] = current_tags
                    args = tuple(args_list)
                else:
                    # Otherwise pass it through kwargs.
                    kwargs["tags"] = current_tags
        return func(self, *args, **kwargs)

    return wrapper


def validate_wedata_tag(func):
    """Decorator that validates the ``wedata.workspace`` tag on the returned object."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        workspace = os.getenv("WEDATA_WORKSPACE_ID")
        obj = func(*args, **kwargs)
        if obj is None:
            return obj
        workspace_tag = None
        method_name = func.__name__
        obj_name = "object"
        if "run" in method_name:
            workspace_tag = obj.data.tags.get("wedata.workspace")
            obj_name = "run"
        elif "experiment" in method_name:
            obj_name = "experiment"
            workspace_tag = obj.tags.get("wedata.workspace")
        elif "model" in method_name:
            obj_name = "model"
            workspace_tag = obj.tags.get("wedata.workspace")
        if workspace and workspace_tag != workspace:
            print(f"this workspace:{workspace},has no {obj_name}")
            return None
        return obj

    return wrapper


def _fetch_resource_tags(client: MlflowClient, method_name: str, args, kwargs):
    """Fetch the resource by method name and return (id_name, workspace_tag, data_science_type, found)."""
    if "experiment" in method_name:
        id_name = kwargs.get("experiment_id") or (args[0] if args else None)
        res = client.get_experiment(id_name)
        if not res:
            print(f"Experiment: '{id_name}' not exist or does not have permission to operate")
            return id_name, None, None, False
        return id_name, res.tags.get("wedata.workspace"), res.tags.get("wedata.datascience.type"), True
    elif "model" in method_name:
        id_name = kwargs.get("name") or (args[0] if args else None)
        res = client.get_registered_model(id_name)
        if not res:
            print(f"Model '{id_name}' not exist or does not have permission to operate")
            return id_name, None, None, False
        return id_name, res.tags.get("wedata.workspace"), res.tags.get("wedata.datascience.type"), True
    else:
        id_name = kwargs.get("run_id") or (args[0] if args else None)
        res = client.get_run(id_name)
        if not res:
            print(f"run: '{id_name}' not exist or does not have permission to operate")
            return id_name, None, None, False
        return id_name, res.data.tags.get("wedata.workspace"), res.data.tags.get("wedata.datascience.type"), True


def validate_wedata_before_operation(func):
    """Decorator that validates workspace ownership before a mutating operation runs."""
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        workspace = os.getenv("WEDATA_WORKSPACE_ID")
        if not workspace:
            return func(self, *args, **kwargs)
        method_name = func.__name__
        id_name, workspace_tag, data_science_type, found = _fetch_resource_tags(
            self, method_name, args, kwargs
        )
        if not found:
            return
        if workspace_tag != workspace or data_science_type not in _ALLOWED_DS_TYPES:
            print(f"Unauthorized operation:{method_name} ({id_name})")
            return
        if method_name in (
            "update_tag",
            "delete_tags",
            "set_registered_model_tag",
            "delete_registered_model_tag",
            "delete_model_version_tag",
            "set_experiment_tag",
        ):
            key_value = kwargs.get("key") or (args[1] if args else None)
            if key_value == "wedata.workspace":
                print(f"No permission to operate protected tags: {key_value}")
                return
        return func(self, *args, **kwargs)

    return wrapper


class _GrpcClientProxyHeaderInterceptor(
    grpc.UnaryUnaryClientInterceptor,
    grpc.UnaryStreamClientInterceptor,
    grpc.StreamUnaryClientInterceptor,
    grpc.StreamStreamClientInterceptor,
):
    def __init__(self):
        self.proxy_ip = os.environ.get(FEAST_PROXY_ENV_KEY_IP)
        self.proxy_port = os.environ.get(FEAST_PROXY_ENV_KEY_PORT)
        if not self.proxy_ip:
            raise FeastError(
                f"Environment variable `{FEAST_PROXY_ENV_KEY_IP}` is not set"
            )
        if not self.proxy_port:
            raise FeastError(
                f"Environment variable `{FEAST_PROXY_ENV_KEY_PORT}` is not set"
            )

    def intercept_unary_unary(self, continuation, client_call_details, request_iterator):
        return self._handle_call(continuation, client_call_details, request_iterator)

    def intercept_unary_stream(self, continuation, client_call_details, request_iterator):
        return self._handle_call(continuation, client_call_details, request_iterator)

    def intercept_stream_unary(self, continuation, client_call_details, request_iterator):
        return self._handle_call(continuation, client_call_details, request_iterator)

    def intercept_stream_stream(self, continuation, client_call_details, request_iterator):
        return self._handle_call(continuation, client_call_details, request_iterator)

    def _handle_call(self, continuation, client_call_details, request_iterator):
        client_call_details = self._append_proxy_header_metadata(client_call_details)
        result = continuation(client_call_details, request_iterator)
        if result.exception() is not None:
            mapped_error = FeastError.from_error_detail(result.exception().details())
            if mapped_error is not None:
                raise mapped_error
        return result

    def _append_proxy_header_metadata(self, client_call_details):
        metadata = client_call_details.metadata or []
        metadata.append((PROXY_HEADER_KEY_IP.lower(), self.proxy_ip))
        metadata.append((PROXY_HEADER_KEY_PORT.lower(), self.proxy_port))
        client_call_details = client_call_details._replace(metadata=metadata)
        return client_call_details


class Wedata3PreCodeClient(BaseClient):
    """WeData 3.0 Machine Learning Notebook Kernel runtime client.

    Required parameters:
        - workspace_id: workspace ID
        - mlflow_tracking_uri: MLflow tracking URI
        - base_url: WeData console base URL
        - mlflow_gateway_url: MLflow Serverless gateway URL
        - feast_gateway_url: Feast Serverless gateway URL
        - mlflow_proxy_ip: MLflow forwarding proxy IP
        - mlflow_proxy_port: MLflow forwarding proxy port
        - feast_proxy_ip: Feast forwarding proxy IP
        - feast_proxy_port: Feast forwarding proxy port

    Optional parameters:
        - region: region code
        - ap_region_id: AP region numeric ID
        - kernel_task_name: Notebook path name
        - kernel_task_id: Notebook file ID
        - kernel_submit_form_workflow: workflow identifier of the submit form
        - kernel_is_international: whether this is an international site
        - cloud_sdk_secret_id: Cloud SDK secret ID
        - cloud_sdk_secret_key: Cloud SDK secret key
        - cloud_sdk_secret_token: Cloud SDK secret token
        - cloud_sdk_env: Cloud SDK environment (dev/test/pre)
        - cloud_sdk_user_id: Cloud SDK user ID (used when cloud_sdk_env == "test")
        - qcloud_uin: Tencent Cloud UIN
        - qcloud_subuin: Tencent Cloud sub-UIN
    """

    workspace_id: str
    base_url: str
    region: Optional[str] = ""
    ap_region_id: Optional[int] = 0
    # Serverless gateway URLs.
    mlflow_gateway_url: str
    feast_gateway_url: str
    # MLflow forwarding proxy endpoint.
    mlflow_proxy_ip: str
    mlflow_proxy_port: str
    # Feast forwarding proxy endpoint.
    feast_proxy_ip: str
    feast_proxy_port: str
    # Kernel-side identity variables.
    kernel_task_name: Optional[str]
    kernel_task_id: Optional[str]
    kernel_submit_form_workflow: Optional[str] = ""
    # Cloud SDK credentials.
    cloud_sdk_secret_id: Optional[str] = ""
    cloud_sdk_secret_key: Optional[str] = ""
    cloud_sdk_secret_token: Optional[str] = ""
    cloud_sdk_env: Optional[str] = ""
    cloud_sdk_user_id: Optional[str] = ""
    # Account identifiers.
    qcloud_uin: Optional[str] = ""
    qcloud_subuin: Optional[str] = ""

    def init(self):
        mlflow_tracking_uri = f"http://{self.mlflow_proxy_ip}:{self.mlflow_proxy_port}"
        mlflow_registry_uri = f"tclake:{self.region}"
        feast_remote_address = f"{self.feast_proxy_ip}:{self.feast_proxy_port}"

        if self.mlflow_gateway_url:
            mlflow_tracking_uri = f"http://{self.mlflow_gateway_url}"

        if self.feast_gateway_url:
            feast_remote_address = self.feast_gateway_url

        os.environ[MLFLOW_PROXY_ENV_KEY_IP] = self.mlflow_proxy_ip
        os.environ[MLFLOW_PROXY_ENV_KEY_PORT] = self.mlflow_proxy_port
        os.environ[FEAST_PROXY_ENV_KEY_IP] = self.feast_proxy_ip
        os.environ[FEAST_PROXY_ENV_KEY_PORT] = self.feast_proxy_port

        os.environ["WEDATA_WORKSPACE_ID"] = self.workspace_id
        os.environ["MLFLOW_TRACKING_URI"] = mlflow_tracking_uri
        os.environ["MLFLOW_REGISTRY_URI"] = mlflow_registry_uri
        os.environ[get_kernel_env_key("REGION")] = self.region
        os.environ["KERNEL_FEAST_REMOTE_ADDRESS"] = feast_remote_address

        # Kernel identity env vars.
        os.environ[get_kernel_env_key("TASK_NAME")] = self.kernel_task_name
        os.environ[get_kernel_env_key("TASK_ID")] = self.kernel_task_id
        os.environ[get_kernel_env_key("SUBMIT_FORM_WORKFLOW")] = self.kernel_submit_form_workflow
        os.environ[get_kernel_env_key("CLOUD_SDK_SECRET_ID")] = self.cloud_sdk_secret_id
        os.environ[get_kernel_env_key("CLOUD_SDK_SECRET_KEY")] = self.cloud_sdk_secret_key
        os.environ[get_kernel_env_key("CLOUD_SDK_SECRET_TOKEN")] = self.cloud_sdk_secret_token
        _allowed_envs = ("dev", "test", "pre")
        if self.cloud_sdk_env in _allowed_envs:
            os.environ["TENCENTCLOUD_ENDPOINT"] = f"wedata.{self.cloud_sdk_env}.tencentcloudapi.com"
            os.environ["TENCENTCLOUD_TCCATALOG_ENDPOINT"] = f"tccatalog.{self.cloud_sdk_env}.tencentcloudapi.com"
        else:
            os.environ["TENCENTCLOUD_ENDPOINT"] = "wedata.internal.tencentcloudapi.com"
            os.environ["TENCENTCLOUD_TCCATALOG_ENDPOINT"] = "tccatalog.internal.tencentcloudapi.com"
        if self.cloud_sdk_env == "test":
            os.environ["IS_WEDATA_TEST"] = "true"
            os.environ["TEST_USER_ID"] = self.cloud_sdk_user_id
        os.environ[get_kernel_env_key("QCLOUD_UIN")] = self.qcloud_uin
        os.environ[get_kernel_env_key("QCLOUD_SUBUIN")] = self.qcloud_subuin

        mlflow.set_tracking_uri(mlflow_tracking_uri)
        mlflow.set_registry_uri(mlflow_registry_uri)

        if not os.environ.get("MLFLOW_RUN_CONTEXT"):
            # Skip if already configured.
            run_context_data = {
                "mlflow.source.name": self.kernel_task_name,
                "mlflow.user": self.qcloud_uin,
                "wedata.taskId": self.kernel_task_id,
                "wedata.workflowId": self.kernel_submit_form_workflow,
                "wedata.datascience.type": "MACHINE_LEARNING",
                "wedata.workspace": self.workspace_id,
            }
            os.environ["MLFLOW_RUN_CONTEXT"] = json.dumps(run_context_data, indent=None)

        if self.region:
            log_after_terminated = _make_log_after_terminated(
                self.base_url, self.workspace_id, self.ap_region_id
            )
            TrackingServiceClient.set_terminated = log_after_terminated(
                TrackingServiceClient.set_terminated
            )

        # Apply decorators.
        inject_model_version_tag = _make_inject_model_version_tag(self.workspace_id)

        Model.log = inject_model_version_tag(Model.log)

        MlflowClient.create_experiment = inject_workspace_tag(create_experiment)
        MlflowClient.get_experiment = validate_wedata_tag(get_experiment)
        MlflowClient.get_experiment_by_name = validate_wedata_tag(get_experiment_by_name)
        MlflowClient.search_experiments = search_experiments
        MlflowClient.get_run = validate_wedata_tag(MlflowClient.get_run)
        MlflowClient.get_parent_run = validate_wedata_tag(MlflowClient.get_parent_run)
        MlflowClient.delete_experiment = delete_experiment
        MlflowClient.restore_experiment = restore_experiment
        MlflowClient.rename_experiment = validate_wedata_before_operation(rename_experiment)
        MlflowClient.set_experiment_tag = validate_wedata_before_operation(
            MlflowClient.set_experiment_tag
        )
        MlflowClient.set_tag = validate_wedata_before_operation(MlflowClient.set_tag)
        MlflowClient.delete_tag = validate_wedata_before_operation(MlflowClient.delete_tag)
        MlflowClient.update_run = validate_wedata_before_operation(MlflowClient.update_run)
        MlflowClient.download_artifacts = validate_wedata_before_operation(
            MlflowClient.download_artifacts
        )
        MlflowClient.list_artifacts = validate_wedata_before_operation(
            MlflowClient.list_artifacts
        )
        MlflowClient.delete_run = validate_wedata_before_operation(MlflowClient.delete_run)
        MlflowClient.restore_run = validate_wedata_before_operation(MlflowClient.restore_run)
        mlflow.set_experiment = set_experiment

        # 2026-01-27. The preload script now force-installs the tclake plugin,
        # so the registered-model decorators below are disabled.
        # fmt: off
        # MlflowClient.create_registered_model = inject_workspace_tag(MlflowClient.create_registered_model)  # noqa: E501
        # MlflowClient.create_model_version = inject_workspace_tag(MlflowClient.create_model_version)  # noqa: E501
        # MlflowClient.get_registered_model = validate_wedata_tag(MlflowClient.get_registered_model)  # noqa: E501
        # MlflowClient.rename_registered_model = validate_wedata_before_operation(MlflowClient.rename_registered_model)  # noqa: E501
        # MlflowClient.update_registered_model = validate_wedata_before_operation(MlflowClient.update_registered_model)  # noqa: E501
        # MlflowClient.delete_registered_model = validate_wedata_before_operation(MlflowClient.delete_registered_model)  # noqa: E501
        # MlflowClient.update_model_version = validate_wedata_before_operation(MlflowClient.update_model_version)  # noqa: E501
        # MlflowClient.delete_model_version = validate_wedata_before_operation(MlflowClient.delete_model_version)  # noqa: E501
        # MlflowClient.set_model_version_tag = validate_wedata_before_operation(MlflowClient.set_model_version_tag)  # noqa: E501
        # MlflowClient.delete_model_version_tag = validate_wedata_before_operation(MlflowClient.delete_model_version_tag)  # noqa: E501
        # MlflowClient.set_registered_model_alias = validate_wedata_before_operation(MlflowClient.set_registered_model_alias)  # noqa: E501
        # MlflowClient.delete_registered_model_alias = validate_wedata_before_operation(MlflowClient.delete_registered_model_alias)  # noqa: E501
        # MlflowClient.set_registered_model_tag = validate_wedata_before_operation(MlflowClient.set_registered_model_tag)  # noqa: E501
        # MlflowClient.delete_registered_model_tag = validate_wedata_before_operation(MlflowClient.delete_registered_model_tag)  # noqa: E501
        # fmt: on

        self._setup_feast_proxy()
        # 刷新 /opt/spark/pip_list.json：把运行时实际装好的包（含 preload 脚本通过 %pip install
        # 装上的 wedata3-ml-runtime 及其传递依赖）快照回写，DLC 以此作为"系统包白名单"来消除
        # 后续用户 cell 里 `%pip install` 同名同版本包时的重复装包告警。
        self._refresh_sys_pkg()

    def _setup_feast_proxy(self):
        """Replace Feast RemoteRegistry with a version that attaches gRPC proxy headers."""
        import feast.infra.registry.remote  # 显式导入子模块，避免 AttributeError

        _original_remote_registry = feast.infra.registry.remote.RemoteRegistry

        def patched_registry(*args, **kwargs):
            registry = _original_remote_registry(*args, **kwargs)
            registry.channel = grpc.intercept_channel(registry.channel, _GrpcClientProxyHeaderInterceptor())
            registry.stub = RegistryServerStub(registry.channel)
            return registry

        feast.infra.registry.remote.RemoteRegistry = patched_registry

    @staticmethod
    def _refresh_sys_pkg(output_path: str = "/opt/spark/pip_list.json"):
        """Snapshot currently installed Python packages as JSON at ``output_path``.

        :param output_path: output file path, default ``/opt/spark/pip_list.json``.
        """
        # Make sure setuptools' vendored packages are discoverable as well.
        for p in site.getsitepackages():
            if p not in sys.path:
                sys.path.insert(0, p)
            vp = os.path.join(p, "setuptools", "_vendor")
            if os.path.isdir(vp) and vp not in sys.path:
                sys.path.insert(0, vp)

        seen: set = set()
        modules = [
            {"name": d.metadata["Name"], "version": d.metadata["Version"]}
            for d in distributions()
            if (d.metadata.get("Name"), d.metadata.get("Version")) != (None, None)
            and (d.metadata.get("Name"), d.metadata.get("Version")) not in seen
            and not seen.add((d.metadata.get("Name"), d.metadata.get("Version")))  # type: ignore[func-returns-value]
        ]

        try:
            with open(output_path, "w", encoding="utf-8") as f:
                json.dump(modules, f)
        except Exception as e:
            logging.warning(f"Failed to write pip list to {output_path}: {e}")
