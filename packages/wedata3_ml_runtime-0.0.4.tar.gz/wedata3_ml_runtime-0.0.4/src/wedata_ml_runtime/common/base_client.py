__doc__ = """
Base client class.
"""

from abc import abstractmethod
from pydantic import BaseModel


class BaseClient(BaseModel):
    """Base client class."""

    @abstractmethod
    def init(self):
        pass
