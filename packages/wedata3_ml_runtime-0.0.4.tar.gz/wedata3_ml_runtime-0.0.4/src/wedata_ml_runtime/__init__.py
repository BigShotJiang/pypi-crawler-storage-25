"""WeData ML Runtime.

WeData 3.0 Notebook Kernel runtime initialization library. Provides deep
bridging with MLflow / Feast and platform-level multi-tenant isolation for
Machine Learning experiments.

History: this package is the WeData 3.0 portion split out of
`wedata-pre-code` (which originally served both 2.0 and 3.0). Only 3.0 logic
is carried here.
"""

# ---------------------------------------------------------------------------
# MLflow 3.x 兼容垫片
# ---------------------------------------------------------------------------
# 背景：部分第三方 MLflow 插件（wedata3-mlflow-tclake-plugin / wedata3-mlflow-header-plugin
# 等）仍在模块加载期 import 一些老版本 mlflow 的符号；在 mlflow>=3 环境里这些
# 符号已被改名/移除，导致 Notebook 预执行脚本 ``ImportError`` 无法初始化。
#
# 本垫片必须在 ``wedata_ml_runtime`` 被 import 时立即生效（先于 client 里
# ``import mlflow`` 触发的第三方插件注册链路），以回填别名/注入 stub 的方式
# 让后续 ``from mlflow.xxx import YYY`` 能命中。
#
# 已覆盖符号：
#   1. ``mlflow.types.llm.ChatResponse``
#      mlflow 2.x 旧名，3.x 改名为 ``ChatCompletionResponse``。
#   2. ``mlflow.utils.databricks_utils.is_in_databricks_serverless``
#      mlflow 早期私有/内部符号，3.x 已移除。WeData/DLC 运行环境不是 Databricks
#      Serverless，用永远返回 ``False`` 的 stub 兜底即可。
#   3. ``mlflow.utils.model_utils.RECORD_ENV_VAR_ALLOWLIST``
#      mlflow 新版本引入的 ``set``，用于标记允许记录到 model 元数据的环境
#      变量白名单。在老版本 mlflow（如生产环境 Python 3.11 下仍在用的旧包）
#      里缺失，第三方插件 eager import 会直接 ``ImportError``。这里用空
#      ``set()`` 兜底——语义等价于 "不额外记录任何环境变量"，对 WeData/DLC
#      场景安全无副作用。
#   4. ``mlflow.models.display_utils``（整模块缺失）
#      mlflow 较新版本才新增的子模块，用于在 Databricks Notebook 里渲染
#      Agent Eval / ModelInfo 的 HTML 展示组件。老版本 mlflow 根本没有
#      该子模块，第三方插件 ``import mlflow.models.display_utils`` 会抛
#      ``ModuleNotFoundError``。这里向 ``sys.modules`` 注入一个伪模块，
#      并提供 noop 版本的 ``maybe_render_agent_eval_recipe``，保证
#      ``import``/``from ... import ...`` 两种用法都可过，且在非 Databricks
#      环境下本就不需要真实渲染。
#
# 关联：2026-05 修复 Notebook 预执行脚本因第三方插件 import 老符号/老模块报
#       ``ImportError: cannot import name 'ChatResponse' / 'is_in_databricks_serverless'
#         / 'RECORD_ENV_VAR_ALLOWLIST'`` 以及
#       ``ModuleNotFoundError: No module named 'mlflow.models.display_utils'`` 的问题。
try:  # pragma: no cover - 防御性兜底，失败也不应影响主流程
    import mlflow.types.llm as _mlflow_llm  # type: ignore

    if not hasattr(_mlflow_llm, "ChatResponse"):
        _fallback = getattr(_mlflow_llm, "ChatCompletionResponse", None)
        if _fallback is not None:
            _mlflow_llm.ChatResponse = _fallback  # type: ignore[attr-defined]
except Exception:  # noqa: BLE001 - 不能让垫片报错阻断 runtime 初始化
    pass

try:  # pragma: no cover
    import mlflow.utils.databricks_utils as _mlflow_dbx  # type: ignore

    if not hasattr(_mlflow_dbx, "is_in_databricks_serverless"):
        def _is_in_databricks_serverless_stub(*_args, **_kwargs) -> bool:  # noqa: D401
            """WeData/DLC 运行环境恒定不是 Databricks Serverless，返回 False。"""
            return False

        _mlflow_dbx.is_in_databricks_serverless = _is_in_databricks_serverless_stub  # type: ignore[attr-defined]
except Exception:  # noqa: BLE001
    pass

try:  # pragma: no cover
    import mlflow.utils.model_utils as _mlflow_model_utils  # type: ignore

    if not hasattr(_mlflow_model_utils, "RECORD_ENV_VAR_ALLOWLIST"):
        # 空 set 语义：不额外把环境变量写入 model 元数据，对 WeData/DLC 安全无副作用
        _mlflow_model_utils.RECORD_ENV_VAR_ALLOWLIST = set()  # type: ignore[attr-defined]
except Exception:  # noqa: BLE001
    pass

try:  # pragma: no cover
    # 整模块缺失：老 mlflow 版本没有 ``mlflow.models.display_utils`` 子模块，
    # 必须向 sys.modules 注入伪模块，避免第三方插件
    # ``import mlflow.models.display_utils`` / ``from ... import maybe_render_agent_eval_recipe``
    # 直接抛 ``ModuleNotFoundError``。
    import importlib as _importlib
    import sys as _sys
    import types as _types

    _DISPLAY_UTILS_FQN = "mlflow.models.display_utils"
    _need_stub_display_utils = False
    try:
        _importlib.import_module(_DISPLAY_UTILS_FQN)
    except Exception:  # noqa: BLE001 - 任何导入异常都视为"模块不可用"，注入 stub
        _need_stub_display_utils = True

    if _need_stub_display_utils:
        _stub = _types.ModuleType(_DISPLAY_UTILS_FQN)

        def _maybe_render_agent_eval_recipe(*_args, **_kwargs):  # noqa: D401
            """Noop：非 Databricks Notebook 环境下无需渲染 agent eval recipe。"""
            return None

        _stub.maybe_render_agent_eval_recipe = _maybe_render_agent_eval_recipe  # type: ignore[attr-defined]
        _stub.__all__ = ["maybe_render_agent_eval_recipe"]  # type: ignore[attr-defined]
        _sys.modules[_DISPLAY_UTILS_FQN] = _stub

        # 同步把伪模块挂到父模块属性上，保持 ``mlflow.models.display_utils`` 可用
        try:
            import mlflow.models as _mlflow_models  # type: ignore

            if not hasattr(_mlflow_models, "display_utils"):
                _mlflow_models.display_utils = _stub  # type: ignore[attr-defined]
        except Exception:  # noqa: BLE001
            pass
except Exception:  # noqa: BLE001
    pass

from wedata_ml_runtime.client import Wedata3PreCodeClient

__all__ = ["Wedata3PreCodeClient"]

__version__ = "0.0.3"
