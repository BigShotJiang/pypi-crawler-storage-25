# wedata3-ml-runtime

WeData 3.0 机器学习 Notebook Kernel 运行时初始化库。

## 定位

本包是 WeData 3.0 Notebook 场景下，运行在 DLC 计算容器中的 **Kernel 启动适配层**。它不改变用户代码，而是通过 monkey patching 把开源的 `mlflow` / `feast` 改造成带有 WeData 平台语义（多租户隔离、CAM 鉴权、审计、网关代理）的版本。

> 前身：`wedata-pre-code`（同时支持 2.0 和 3.0）
>
> 本包仅承载 WeData 3.0 逻辑。WeData 2.0 仍沿用 `wedata-pre-code`，位于 `../wedata-pre-execute/`（已进入维护模式）。

## 核心能力

1. **装包标记**：配合 DLC 镜像预装 → 运行时刷新 `/opt/spark/pip_list.json` 系统包快照，消除重复装包告警
2. **环境变量注入**：`WEDATA_WORKSPACE_ID` / `MLFLOW_TRACKING_URI` / `TENCENTCLOUD_SECRET_ID/KEY/TOKEN` / `KERNEL_WEDATA_*` 等 20+ 条
3. **MLflow 客户端重写**：
   - `create/get/search/rename/delete experiment` 改走腾讯云 OpenAPI（TC3-HMAC-SHA256 手签）
   - `MlflowClient` 上所有写操作套装饰器做 workspace_id 校验
4. **Feast gRPC 代理**：给 `RemoteRegistry` 加 `X-Target-Service-IP/PORT` 请求头走反向代理
5. **自动 tag 注入**：所有 mlflow 对象自动打上 `wedata.workspace / wedata.datascience.type / mlflow.user`

## 使用

```python
%pip install wedata3-ml-runtime
from wedata_ml_runtime.client import Wedata3PreCodeClient

client = Wedata3PreCodeClient(
    workspace_id="...",
    base_url="...",
    region="...",
    ap_region_id=1,
    mlflow_gateway_url="...",
    feast_gateway_url="...",
    mlflow_proxy_ip="...",
    mlflow_proxy_port="...",
    feast_proxy_ip="...",
    feast_proxy_port="...",
    kernel_task_name="...",
    kernel_task_id="...",
    cloud_sdk_secret_id="...",
    cloud_sdk_secret_key="...",
    cloud_sdk_secret_token="...",
    qcloud_uin="...",
    qcloud_subuin="...",
)
client.init()
```

## 必传参数

| 参数 | 说明 |
|------|------|
| `workspace_id` | 工作空间 ID |
| `base_url` | WeData 控制台基础 URL |
| `mlflow_gateway_url` | MLflow Serverless 网关地址 |
| `feast_gateway_url` | Feast Serverless 网关地址 |
| `mlflow_proxy_ip` / `mlflow_proxy_port` | MLflow 转发地址 |
| `feast_proxy_ip` / `feast_proxy_port` | Feast 转发地址 |

## 可选参数

| 参数 | 说明 |
|------|------|
| `region` / `ap_region_id` | 地域标识 |
| `kernel_task_name` / `kernel_task_id` | 任务身份 |
| `kernel_submit_form_workflow` | 工作流标识 |
| `cloud_sdk_secret_id` / `cloud_sdk_secret_key` / `cloud_sdk_secret_token` | CAM 临时凭证三元组（12 小时过期） |
| `cloud_sdk_env` | SDK 环境（`dev` / `test` / `pre`） |
| `cloud_sdk_user_id` | 测试账户 ID（`cloud_sdk_env=test` 时使用） |
| `qcloud_uin` / `qcloud_subuin` | 腾讯云主账号 / 子账号 UIN |

## 构建发布

```bash
bash build.sh
```

脚本内容：`rm -rf dist/ build/` → `uv build` → `twine upload dist/*`

## 从 wedata-pre-code 迁移

| 维度 | 老包 `wedata-pre-code` | 新包 `wedata3-ml-runtime` |
|------|----------------------|------------------------|
| PyPI 名 | `wedata-pre-code` | `wedata3-ml-runtime` |
| Python 模块 | `wedata_pre_code.wedata3.client` | `wedata_ml_runtime.client` |
| 客户端类 | `Wedata3PreCodeClient` | `Wedata3PreCodeClient`（保持兼容）|
| extras | `pip install "wedata-pre-code[wedata-3]"` | 无需 extras，主依赖已覆盖 |
| 覆盖平台 | 2.0 + 3.0 | **仅 3.0** |

**迁移办法**：把 `%pip install wedata-pre-code[wedata-3]==X.Y.Z` 改为 `%pip install wedata3-ml-runtime==X.Y.Z`，并把 `from wedata_pre_code.wedata3.client import Wedata3PreCodeClient` 改为 `from wedata_ml_runtime.client import Wedata3PreCodeClient`。

## 相关设计文档

- `application/science/doc/plan/wedata-pre-code-image-baseline-plan.md`：DLC 镜像基线 + 运行时 Override 方案
