"""ICNLI OS Kernel — execute_sdk_tool.

The ONLY entry point for extension execution.
System tools (discover_tools, system_chat) are intercepted before extension dispatch.

Scope enforcement is NOT done here — it belongs at the API layer
(Cases API, Panel, Auth Gateway verify JWT before sending signals).
The kernel is a trusted internal component that executes unconditionally.
"""
import asyncio
import logging
import os
import json as _json
import time as _time
import uuid

from imperal_sdk.runtime.loader import ExtensionLoader
from imperal_sdk.runtime.context_factory import ContextFactory
from imperal_sdk.runtime.task_manager import (
    generate_task_id, create_task, promote_task, complete_task,
    count_active_tasks, update_progress, is_cancelled,
)
from imperal_sdk.runtime.action_writer import generate_trace_id, write_action
from imperal_sdk.runtime.event_publisher import publish_kernel_event

log = logging.getLogger(__name__)

_loader: ExtensionLoader | None = None
_factory: ContextFactory | None = None
_catalog = None

# System chat LLM client (lazy init)

_redis_client = None

# Maximum concurrent tasks per user (default)
MAX_TASKS_PER_USER = int(os.getenv("IMPERAL_MAX_TASKS_PER_USER", "3"))

# Promotion threshold in ms (tasks running longer become visible background tasks)
PROMOTION_THRESHOLD_MS = int(os.getenv("IMPERAL_PROMOTION_THRESHOLD_MS", "5000"))


async def _get_redis():
    global _redis_client
    if _redis_client is None:
        import redis.asyncio as aioredis
        _redis_client = aioredis.from_url(os.getenv("REDIS_URL", "redis://104.224.88.155:6379/0"))
    return _redis_client


async def _resolve_user_identity(user_id: str, email: str = "") -> dict:
    """Resolve user_id to full profile from Auth Gateway. Cached in Redis 5min.
    Uses direct GET /v1/users/{id} — O(1) instead of fetching all users."""
    if not user_id or user_id == "0":
        return {"id": user_id, "email": "", "role": "system", "scopes": ["*"], "attributes": {}, "tenant_id": "default", "is_active": True}

    cache_key = f"imperal:identity:{user_id}"
    try:
        r = await _get_redis()
        cached = await r.get(cache_key)
        if cached:
            return _json.loads(cached)
    except Exception:
        pass

    gw_url = os.getenv("IMPERAL_GATEWAY_URL", "http://104.224.88.155:8085")
    svc_token = os.getenv("IMPERAL_SERVICE_TOKEN", "")

    try:
        import httpx
        async with httpx.AsyncClient(timeout=5) as client:
            # Direct lookup by imperal_id — O(1)
            resp = await client.get(
                f"{gw_url}/v1/users/{user_id}",
                headers={"X-Service-Token": svc_token},
            )
            if resp.status_code == 200:
                u = resp.json()
                profile = {
                    "id": str(u.get("imperal_id", u.get("id", user_id))),
                    "email": u.get("email", ""),
                    "role": u.get("role", "user"),
                    "scopes": u.get("scopes") or ["*"],
                    "attributes": u.get("attributes", {}),
                    "tenant_id": u.get("tenant_id", "default"),
                    "is_active": u.get("is_active", True),
                }
                try:
                    r = await _get_redis()
                    await r.setex(cache_key, 300, _json.dumps(profile))
                except Exception:
                    pass
                return profile

            # Fallback: search by email if direct lookup failed
            if email:
                resp = await client.get(
                    f"{gw_url}/v1/users?search={email}&limit=1",
                    headers={"X-Service-Token": svc_token},
                )
                if resp.status_code == 200:
                    data = resp.json()
                    items = data.get("items", data) if isinstance(data, dict) else data
                    if isinstance(items, list) and items:
                        u = items[0]
                        profile = {
                            "id": str(u.get("imperal_id", u.get("id", user_id))),
                            "email": u.get("email", ""),
                            "role": u.get("role", "user"),
                            "scopes": u.get("scopes") or ["*"],
                            "attributes": u.get("attributes", {}),
                            "tenant_id": u.get("tenant_id", "default"),
                            "is_active": u.get("is_active", True),
                        }
                        try:
                            r = await _get_redis()
                            await r.setex(cache_key, 300, _json.dumps(profile))
                        except Exception:
                            pass
                        return profile

    except Exception as e:
        log.warning(f"Identity resolution failed for user {user_id}: {e}")

    return {"id": user_id, "email": "", "role": "user", "scopes": ["*"], "attributes": {}, "tenant_id": "default", "is_active": True}


async def _resolve_config(tenant_id: str, app_id: str, role: str, user_id: str) -> dict:
    """Resolve config for user+app+tenant from Auth Gateway. Redis cached 300s."""
    cache_key = f"imperal:config:resolved:{tenant_id}:{app_id}:{role}:{user_id}"
    try:
        r = await _get_redis()
        cached = await r.get(cache_key)
        if cached:
            return _json.loads(cached)
    except Exception:
        pass

    try:
        import httpx
        gw_url = os.getenv("IMPERAL_GATEWAY_URL", "http://104.224.88.155:8085")
        svc_token = os.getenv("IMPERAL_SERVICE_TOKEN", "")
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.get(
                f"{gw_url}/v1/internal/config/resolve",
                params={"tenant_id": tenant_id, "app_id": app_id, "role": role, "user_id": user_id},
                headers={"X-Service-Token": svc_token},
            )
            if resp.status_code == 200:
                resolved = resp.json()
                try:
                    r = await _get_redis()
                    await r.setex(cache_key, 300, _json.dumps(resolved))
                except Exception:
                    pass
                return resolved
    except Exception as e:
        log.warning(f"Config resolve error: {e}")
    return {}


def _check_tool_scopes(user_scopes: list[str], required_scopes: list[str]) -> tuple[bool, list[str]]:
    """Check scopes with colon format (resource:action). Supports wildcards."""
    if not required_scopes or required_scopes == ["*"]:
        return True, []
    if "*" in user_scopes:
        return True, []
    missing = []
    for required in required_scopes:
        if required in user_scopes:
            continue
        resource, sep, action = required.partition(":")
        if sep and f"{resource}:*" in user_scopes:
            continue
        # extensions:ACTION covers all extension tools (meta-scope)
        if sep and action and f"extensions:{action}" in user_scopes:
            continue
        if "extensions:*" in user_scopes:
            continue
        # Legacy dot format fallback
        if "." in required:
            parts = required.split(".")
            if parts[0] + ".*" in user_scopes:
                continue
        missing.append(required)
    return len(missing) == 0, missing


# ── Target Scope Guard ────────────────────────────────────────────
# Kernel-level guard: prevents cross-user actions without proper scopes.
# Convention-based parameter detection + graduated scope requirements.

TARGET_PARAM_CONVENTIONS = {
    "user_id": "user_id",
    "target_user": "user_id",
    "user_ids": "user_id_list",
    "email": "email",
    "target_email": "email",
    "account_id": "account_id",
}

# Graduated scope requirements by intent type
_TARGET_SCOPE_BY_INTENT = {
    "read": ["users:read"],
    "write": ["users:manage"],
    "destructive": ["users:admin"],
}


def _check_target_scope(
    tool_use_params: dict,
    caller_id: str,
    caller_email: str,
    caller_scopes: list[str],
    intent_type: str = "read",
    connected_emails: list[str] | None = None,
    target_params_override: list[str] | None = None,
) -> dict:
    """Kernel target scope guard.

    Inspects tool_use parameters for target user identifiers.
    If target differs from caller, checks graduated scopes.

    Args:
        tool_use_params: The parameters from tool_use (e.g. {"user_id": "xxx", "role": "admin"})
        caller_id: The requesting user's imperal_id (ctx.user.id)
        caller_email: The requesting user's email (ctx.user.email)
        caller_scopes: The requesting user's scopes list
        intent_type: "read", "write", or "destructive"
        connected_emails: List of caller's connected email addresses (multi-account)
        target_params_override: SDK decorator override — explicit list of param names that are targets

    Returns:
        dict with keys:
            "allowed": bool
            "cross_user": bool
            "target_user_id": str|None
            "target_param": str|None
            "required_scope": str|None
            "force_confirmation": bool
            "verdict": str — "self_target" | "no_target" | "pass" | "blocked" | "escalated"
    """
    if not tool_use_params or not isinstance(tool_use_params, dict):
        return {"allowed": True, "cross_user": False, "target_user_id": None,
                "target_param": None, "required_scope": None,
                "force_confirmation": False, "verdict": "no_target"}

    # Determine which params to check
    params_to_check = target_params_override or list(TARGET_PARAM_CONVENTIONS.keys())
    caller_emails = set()
    if caller_email:
        caller_emails.add(caller_email.lower())
    if connected_emails:
        caller_emails.update(e.lower() for e in connected_emails)

    # Scan params for target identifiers
    for param_name in params_to_check:
        if param_name not in tool_use_params:
            continue
        value = tool_use_params[param_name]
        if value is None or value == "":
            continue

        # Determine identifier type
        id_type = TARGET_PARAM_CONVENTIONS.get(param_name, "user_id")

        # Handle list params (e.g. user_ids)
        if id_type == "user_id_list":
            if not isinstance(value, list) or not value:
                continue
            # All-or-nothing: if ANY element is cross-user, entire op is cross-user
            has_cross_user = any(str(uid) != str(caller_id) for uid in value)
            if not has_cross_user:
                continue  # All self-targets
            return _evaluate_cross_user(
                target_id=",".join(str(v) for v in value),
                param_name=param_name,
                caller_scopes=caller_scopes,
                intent_type=intent_type,
            )

        # Handle single value
        value_str = str(value).strip()

        if id_type == "email":
            if value_str.lower() in caller_emails:
                continue  # Self-target
        elif id_type in ("user_id", "account_id"):
            if value_str == str(caller_id):
                continue  # Self-target

        # Cross-user detected
        return _evaluate_cross_user(
            target_id=value_str,
            param_name=param_name,
            caller_scopes=caller_scopes,
            intent_type=intent_type,
        )

    # No cross-user targets found
    return {"allowed": True, "cross_user": False, "target_user_id": None,
            "target_param": None, "required_scope": None,
            "force_confirmation": False, "verdict": "no_target"}


def _evaluate_cross_user(
    target_id: str,
    param_name: str,
    caller_scopes: list[str],
    intent_type: str,
) -> dict:
    """Evaluate whether a cross-user action is allowed based on scopes."""
    required_scopes = _TARGET_SCOPE_BY_INTENT.get(intent_type, ["users:read"])
    allowed, missing = _check_tool_scopes(caller_scopes, required_scopes)

    if not allowed:
        log.warning(
            f"TARGET_SCOPE BLOCKED: target={target_id} param={param_name} "
            f"intent={intent_type} missing={missing}"
        )
        return {
            "allowed": False,
            "cross_user": True,
            "target_user_id": target_id,
            "target_param": param_name,
            "required_scope": required_scopes[0] if required_scopes else None,
            "force_confirmation": False,
            "verdict": "blocked",
        }

    # Scope sufficient — but destructive cross-user forces 2-Step
    force_confirm = (intent_type == "destructive")
    if force_confirm:
        log.info(
            f"TARGET_SCOPE ESCALATED: target={target_id} param={param_name} "
            f"intent={intent_type} → forced 2-Step Confirmation"
        )
    else:
        log.info(
            f"TARGET_SCOPE PASS: target={target_id} param={param_name} "
            f"intent={intent_type}"
        )

    return {
        "allowed": True,
        "cross_user": True,
        "target_user_id": target_id,
        "target_param": param_name,
        "required_scope": required_scopes[0] if required_scopes else None,
        "force_confirmation": force_confirm,
        "verdict": "escalated" if force_confirm else "pass",
    }


async def _resolve_confirmation_settings(user_id: str, tenant_id: str) -> dict:
    """Fetch user confirmation + KAV settings from Auth Gateway.
    Returns defaults on failure (confirmation off, KAV retries 2)."""
    defaults = {
        "confirmation_enabled": False,
        "confirmation_actions": [],
        "confirmation_overrides": {},
        "kav_max_retries": 2,
        "confirmation_ttl": 300,
    }
    try:
        import httpx
        gw_url = os.getenv("IMPERAL_GATEWAY_URL", "http://104.224.88.155:8085")
        svc_token = os.getenv("IMPERAL_SERVICE_TOKEN", "")
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.get(
                f"{gw_url}/v1/internal/users/{user_id}/settings",
                params={"tenant_id": tenant_id},
                headers={"X-Service-Token": svc_token},
            )
            if resp.status_code == 200:
                data = resp.json()
                # Settings may be nested under "settings" key
                settings = data.get("settings", data) if isinstance(data, dict) else data
                return {
                    "confirmation_enabled": settings.get("confirmation_enabled", False),
                    "confirmation_actions": settings.get("confirmation_actions", {}),
                    "confirmation_overrides": settings.get("confirmation_overrides", {}),
                    "kav_max_retries": settings.get("kav_max_retries", 2),
                    "confirmation_ttl": settings.get("confirmation_ttl", 300),
                }
    except Exception as e:
        log.debug(f"Confirmation settings fetch failed for user {user_id}: {e}")
    return defaults



def _prune_skeleton(skeleton_data: dict, target_app_id: str) -> dict:
    """Guard 4: Keep only relevant skeleton sections for target extension.

    Hub/system tools see everything. Individual extensions see only their own
    skeleton sections + kernel context (_context) + shared data (email_accounts).
    """
    if not skeleton_data or not isinstance(skeleton_data, dict):
        return skeleton_data or {}
    if target_app_id in ("__system__", "imperal-hub"):
        return skeleton_data

    pruned = {}
    for key, value in skeleton_data.items():
        if key == "_context":
            pruned[key] = value
        elif key == "email_accounts":
            pruned[key] = value
        elif isinstance(value, dict) and value.get("app_id"):
            if value["app_id"] == target_app_id:
                pruned[key] = value
        else:
            pruned[key] = value

    if len(pruned) != len(skeleton_data):
        log.debug(f"Skeleton pruned: {len(skeleton_data)} -> {len(pruned)} keys for {target_app_id}")

    return pruned


def _get_llm():
    """Get LLM provider singleton (Anthropic or OpenAI-compatible)."""
    from imperal_sdk.runtime.llm_provider import get_llm_provider
    return get_llm_provider()


def init_runtime(gateway_url: str, service_token: str, extensions_dir: str = "/opt/extensions", catalog=None):
    """Initialize the ICNLI OS runtime. Called once at worker startup."""
    global _loader, _factory, _catalog
    _loader = ExtensionLoader(extensions_dir=extensions_dir)
    _factory = ContextFactory(gateway_url=gateway_url, service_token=service_token)
    _catalog = catalog
    log.info(f"ICNLI OS Runtime initialized: gateway={gateway_url}, extensions={extensions_dir}")


async def execute_sdk_tool(tool_input: dict) -> dict:
    """ICNLI OS syscall — the ONLY way extensions execute.

    System tools are intercepted before extension dispatch:
    - discover_tools: semantic search over tool catalog
    - system_chat: general conversation with full capability awareness

    Args:
        tool_input: dict with app_id, tool_name, user, message, history, skeleton, channel, context

    Returns:
        {"response": "..."} always
    """
    if _loader is None or _factory is None:
        return {"response": "ICNLI OS Runtime not initialized"}

    _start_time = _time.time()

    tool_name = tool_input.get("tool_name", "")

    # ── Identity Resolution (ALL tools, including system) ─────────
    user_info = tool_input.get("user", {})
    user_id_raw = str(user_info.get("id", ""))

    # Panel sends user identity in context (enrichedContext from session)
    ctx_data = tool_input.get("context", {})
    skeleton_ctx = tool_input.get("skeleton", {}).get("_context", {})
    panel_email = ctx_data.get("user_email") or skeleton_ctx.get("user_email") or ""
    panel_role = ctx_data.get("user_role") or skeleton_ctx.get("user_role") or ""
    panel_imperal_id = ctx_data.get("imperal_id") or skeleton_ctx.get("imperal_id") or ""

    if panel_email:
        # Fast path: Panel already sent identity, no Auth Gateway call needed
        identity = {
            "id": user_id_raw,
            "email": panel_email,
            "role": panel_role or user_info.get("role", "user"),
            "scopes": user_info.get("scopes", ["*"]),
            "attributes": user_info.get("attributes", {}),
            "tenant_id": ctx_data.get("tenant_id") or user_info.get("tenant_id", "default"),
            "is_active": True,
            "imperal_id": panel_imperal_id,
        }
        # Still try to enrich scopes from Auth Gateway (cached)
        gw_identity = await _resolve_user_identity(user_id_raw, email=panel_email)
        if gw_identity.get("email"):
            identity["scopes"] = gw_identity.get("scopes", identity["scopes"])
            identity["attributes"] = gw_identity.get("attributes", identity["attributes"])
    else:
        identity = await _resolve_user_identity(user_id_raw)

    # Merge: if Auth Gateway resolved (has email), its data is authoritative.
    # If fallback (no email = no match), only fill gaps — don't overwrite Panel data.
    if identity.get("email"):
        # Auth Gateway resolved — authoritative source, overrides Panel
        enriched_user = {**user_info, **identity}
    else:
        # Fallback — only fill fields that are missing in user_info
        enriched_user = {**identity, **user_info}
    tool_input["user"] = enriched_user

    # ── Config Resolution ─────────────────────────────────────────
    _tenant_id = enriched_user.get("tenant_id", "default")
    _role = enriched_user.get("role", "user")
    _app_id = tool_input.get("app_id", "system")
    resolved_config = await _resolve_config(_tenant_id, _app_id, _role, user_id_raw)

    # ── Time Context ──────────────────────────────────────────────
    from datetime import datetime
    try:
        from zoneinfo import ZoneInfo
    except ImportError:
        from backports.zoneinfo import ZoneInfo

    _user_tz_name = enriched_user.get("attributes", {}).get("timezone", "UTC")
    try:
        _user_tz = ZoneInfo(_user_tz_name)
    except Exception:
        _user_tz = ZoneInfo("UTC")
        _user_tz_name = "UTC"

    _now_utc = datetime.now(ZoneInfo("UTC"))
    _now_local = _now_utc.astimezone(_user_tz)

    ctx_data["user_timezone"] = _user_tz_name
    ctx_data["_time"] = {
        "timezone": _user_tz_name,
        "offset": _now_local.strftime("%z"),
        "now_utc": _now_utc.isoformat(),
        "now_local": _now_local.isoformat(),
        "hour_local": _now_local.hour,
        "is_business_hours": 9 <= _now_local.hour <= 17,
    }

    # ── System tool interception ──────────────────────────────────
    if tool_name == "discover_tools":
        return await _handle_discover_tools(tool_input)
    if tool_name in ("hub_chat", "system_chat"):
        # Hub chat: ALWAYS inline. Chain execution can take 20-60s but session_workflow
        # has 300s activity timeout. Frontend sees live status via _update_chain_status.
        # Background promotion doesn't work inside activity execution (tasks get cancelled).
        log.info(f"Hub chat: executing inline (no promotion)")
        _hub_result = await _handle_hub_chat(tool_input)
        # Publish SSE event for action counter (Hub path was missing this)
        if isinstance(_hub_result, dict) and _hub_result.get("_had_function_calls"):
            await _publish_action_event(
                user_id=user_info.get("id", ""),
                tenant_id=enriched_user.get("tenant_id", "default"),
                app_id=_hub_result.get("_action_meta", {}).get("app_id", "__system__"),
                tool_name=_hub_result.get("_action_meta", {}).get("tool_name", "hub_chat"),
                message=tool_input.get("message", ""),
                result=_hub_result,
            )
        return _hub_result
    if tool_name == "manage_automations":
        return await _handle_manage_automations(tool_input)

    # ── Extension tool dispatch ───────────────────────────────────
    app_id = tool_input.get("app_id", "")
    message = tool_input.get("message", "")

    # ── Scope Enforcement ─────────────────────────────────────────
    required_scopes = ["*"]
    if _catalog and _catalog.loaded:
        for t in _catalog.tools:
            if t["activity_name"] == tool_name:
                required_scopes = t.get("required_scopes", ["*"])
                break

    user_scopes = enriched_user.get("scopes", ["*"])
    allowed, missing = _check_tool_scopes(user_scopes, required_scopes)
    if not allowed:
        log.warning(f"KERNEL REJECT: user={user_id_raw} ({enriched_user.get('email','')}) tool={tool_name} missing={missing}")
        # Publish access.denied to audit log
        try:
            import httpx
            _audit_gw_url = os.getenv("IMPERAL_GATEWAY_URL", "http://104.224.88.155:8085")
            _audit_svc_token = os.getenv("IMPERAL_SERVICE_TOKEN", "")
            async with httpx.AsyncClient(timeout=5.0) as _audit_client:
                await _audit_client.post(
                    f"{_audit_gw_url}/v1/internal/audit",
                    headers={"X-Service-Token": _audit_svc_token},
                    json={
                        "actor_id": user_id_raw,
                        "actor_type": "user",
                        "action": "access.denied",
                        "target_type": "tool",
                        "target_id": tool_name,
                        "metadata": {
                            "tool": tool_name,
                            "app_id": app_id,
                            "required_scopes": required_scopes,
                            "user_scopes": user_scopes,
                            "scope": missing[0] if missing else None,
                        },
                        "source": "kernel",
                    }
                )
        except Exception:
            pass  # audit is best-effort, don't block execution
        return {"response": f"Access denied: this action requires {', '.join(missing)} permission. Contact your administrator.", "_handled": False}

    # ── Extension status check (defense-in-depth) ─────────────────
    if _catalog and _catalog.loaded:
        known_apps = {t["app_id"] for t in _catalog.tools}
        if app_id not in known_apps:
            log.warning(f"KERNEL REJECT: app '{app_id}' not in active catalog, tool={tool_name}")
            return {"response": f"Extension '{app_id}' is not available. It may be suspended or removed."}

    # 1. Load extension (mtime cache, auto-reload)
    try:
        ext = _loader.load(app_id)
    except (FileNotFoundError, ImportError) as e:
        log.error(f"Failed to load extension '{app_id}': {e}")
        return {"response": f"Extension '{app_id}' not available"}

    # 2. Check tool exists
    tool_def = ext.tools.get(tool_name)
    if tool_def is None:
        return {"response": f"Unknown tool: {tool_name}"}

    # Guard 4: Skeleton pruning — filter by target extension
    _pruned_skeleton = _prune_skeleton(tool_input.get("skeleton", {}), _app_id)

    # 3. Create process environment (Context)
    ctx = await _factory.create(
        user_info=user_info,
        extension_id=app_id,
        history=tool_input.get("history", []),
        skeleton_data=_pruned_skeleton,
        resolved_config=resolved_config,
        time_context=ctx_data.get("_time"),
    )

    # Track task_id for cleanup in finally/except
    _task_id = None

    try:
        # 4a. Kernel injects capability boundary
        # Extensions must know what they CAN and CANNOT do to prevent hallucination
        _inject_capability_boundary(ctx, app_id, ext)

        # ── 4b. Confirmation + KAV pre-check ─────────────────────────
        _intent_type = ctx_data.get("_intent_type", "read")
        _is_write_intent = _intent_type in ("write", "destructive")
        _confirmation_settings = None
        log.info(f"KAV check: {app_id}/{tool_name} intent={_intent_type} is_write={_is_write_intent} user={user_id_raw}")

        _confirmation_bypassed = ctx_data.get("_confirmation_bypassed", False)
        if _is_write_intent and not _confirmation_bypassed:
            _confirmation_settings = await _resolve_confirmation_settings(user_id_raw, _tenant_id)
            log.info(f"KAV settings: enabled={_confirmation_settings.get('confirmation_enabled')} actions={_confirmation_settings.get('confirmation_actions')} for user={user_id_raw}")
            if _confirmation_settings.get("confirmation_enabled"):
                # Check if this action type requires confirmation
                _conf_actions = _confirmation_settings.get("confirmation_actions", {})
                # Support both dict {"write": true} and list ["write"] formats
                if isinstance(_conf_actions, dict):
                    should_confirm = _conf_actions.get(_intent_type, False) or _conf_actions.get("all", False)
                else:
                    should_confirm = _intent_type in _conf_actions or "all" in _conf_actions
                log.info(f"KAV confirm check: intent={_intent_type} actions={_conf_actions} should_confirm={should_confirm}")
                if should_confirm:
                    ctx_data["_confirmation_required"] = True
                    ctx._confirmation_required = True  # Also set on ctx object for ChatExtension
                    ctx._confirmation_settings = _confirmation_settings
                    log.info(f"KAV: confirmation required for {app_id}/{tool_name} intent={_intent_type}")

        # Chain mode: kernel forces function calling in ChatExtension
        if ctx_data.get("_chain_mode"):
            ctx._chain_mode = True
        # Intent type: kernel guards read-only requests from write actions
        ctx._intent_type = ctx_data.get("_intent_type", "read")

        # ── 4c. Task creation + limit check ───────────────────────────
        redis = await _get_redis()

        # Skip task tracking for system/skeleton calls — only track user-initiated actions
        _is_system_task = (
            tool_name.startswith("skeleton_")
            or tool_name.startswith("_internal_")
            or ctx_data.get("_is_skeleton_call")
            or ctx_data.get("_is_system_call")
        )

        # Check task limit for this user (only for user tasks)
        if not _is_system_task:
            active_count = await count_active_tasks(redis, user_id_raw)
            if active_count >= MAX_TASKS_PER_USER:
                log.warning(f"Task limit reached: user={user_id_raw} active={active_count} max={MAX_TASKS_PER_USER}")
                return {
                    "response": f"You have {active_count} tasks running. Please wait for one to finish before starting another.",
                    "type": "task_limit_reached",
                    "active_tasks": active_count,
                    "max_tasks": MAX_TASKS_PER_USER,
                }

            # Create task record (user-initiated only)
            _task_id = generate_task_id()
            await create_task(redis, _task_id, user_id_raw, _tenant_id, app_id, tool_name, message,
                              threshold_ms=PROMOTION_THRESHOLD_MS)
            ctx_data["_task_id"] = _task_id
            # Immediately visible in System Tray for ALL actions
            await promote_task(redis, _task_id)
            try:
                await redis.publish(f"imperal:events:{_tenant_id}", _json.dumps({
                    "type": "state_changed", "scope": "task", "action": "promoted",
                    "data": {"task_id": _task_id, "app_id": app_id, "tool_name": tool_name,
                             "message_preview": message[:200] if message else "", "user_id": user_id_raw}
                }))
            except Exception:
                pass

        # ── 4d. Inject progress callback into context ─────────────────
        _last_progress_time = [0.0]

        async def _progress_callback(percent, msg):
            now = _time.time()
            if now - _last_progress_time[0] >= 2.0:
                _last_progress_time[0] = now
                await update_progress(redis, _task_id, percent, msg)
                # Publish SSE progress event
                try:
                    await redis.publish(f"imperal:events:{_tenant_id}", _json.dumps({
                        "type": "task.progress", "scope": "task", "action": "progress",
                        "data": {"task_id": _task_id, "percent": percent, "message": msg,
                                 "app_id": app_id, "user_id": user_id_raw}
                    }))
                except Exception:
                    pass  # SSE publish is best-effort
            return await is_cancelled(redis, _task_id)

        ctx_data["_progress_callback"] = _progress_callback

        # ── 4e. Execute extension tool ────────────────────────────────
        log.info(f"Executing {app_id}/{tool_name} for user {ctx.user.id} task={_task_id} system={_is_system_task}")

        if _is_system_task:
            # System/skeleton task — direct execution, no racing, no promotion
            result = await ext.call_tool(tool_name, ctx, message=message)
        elif ctx_data.get("_is_async_task"):
            # Re-execution of a promoted task — no racing needed
            result = await ext.call_tool(tool_name, ctx, message=message)
        elif ctx_data.get("_suppress_promotion"):
            # Chain mode — no promotion, wait for full result inline
            result = await ext.call_tool(tool_name, ctx, message=message)
            await complete_task(redis, _task_id, user_id_raw, "completed")
            try:
                await redis.publish(f"imperal:events:{_tenant_id}", _json.dumps({
                    "type": "state_changed", "scope": "task", "action": "completed",
                    "data": {"task_id": _task_id, "user_id": user_id_raw}
                }))
            except Exception:
                pass
        elif ctx_data.get("_confirmation_required"):
            # Confirmation mode — must wait for full result to check _intercepted
            result = await ext.call_tool(tool_name, ctx, message=message)
            await complete_task(redis, _task_id, user_id_raw, "completed")
            try:
                await redis.publish(f"imperal:events:{_tenant_id}", _json.dumps({
                    "type": "state_changed", "scope": "task", "action": "completed",
                    "data": {"task_id": _task_id, "user_id": user_id_raw}
                }))
            except Exception:
                pass
        elif tool_name == "hub_chat":
            # Hub manages sub-extension racing internally — no outer racing
            result = await ext.call_tool(tool_name, ctx, message=message)
            await complete_task(redis, _task_id, user_id_raw, "completed")
            try:
                await redis.publish(f"imperal:events:{_tenant_id}", _json.dumps({
                    "type": "state_changed", "scope": "task", "action": "completed",
                    "data": {"task_id": _task_id, "user_id": user_id_raw}
                }))
            except Exception:
                pass
        else:
            # Race extension against threshold timer
            ext_task = asyncio.create_task(ext.call_tool(tool_name, ctx, message=message))
            timer_task = asyncio.create_task(asyncio.sleep(PROMOTION_THRESHOLD_MS / 1000.0))

            done, pending = await asyncio.wait(
                {ext_task, timer_task},
                return_when=asyncio.FIRST_COMPLETED,
            )

            if ext_task in done:
                # Extension finished before threshold — fast path
                timer_task.cancel()
                result = ext_task.result()
                await complete_task(redis, _task_id, user_id_raw, "completed")
                try:
                    await redis.publish(f"imperal:events:{_tenant_id}", _json.dumps({
                        "type": "state_changed", "scope": "task", "action": "completed",
                        "data": {"task_id": _task_id, "user_id": user_id_raw}
                    }))
                except Exception:
                    pass
            else:
                # Timer fired first — PROMOTE to visible background task
                # Do NOT cancel ext_task — let it continue running
                # But we detach from inline response and return a task_promoted stub
                await promote_task(redis, _task_id)

                # Publish SSE promoted event
                try:
                    await redis.publish(f"imperal:events:{_tenant_id}", _json.dumps({
                        "type": "task.promoted", "scope": "task", "action": "promoted",
                        "data": {"task_id": _task_id, "message_preview": message[:200],
                                 "app_id": app_id, "tool_name": tool_name, "user_id": user_id_raw}
                    }))
                except Exception:
                    pass

                # Schedule background completion handler for the still-running ext_task
                # Pass ctx so it can be destroyed AFTER the task finishes (not before)
                asyncio.create_task(_background_task_completion(
                    ext_task, redis, _task_id, user_id_raw, _tenant_id,
                    app_id, tool_name, message, user_info, enriched_user, ctx,
                ))

                ctx._promoted = True  # Signal finally to skip destroy
                return {
                    "response": "", "type": "task_promoted",
                    "task_id": _task_id, "app_id": app_id,
                    "tool_name": tool_name, "message_preview": message[:200],
                    "user_message": message[:200],
                }

        # ── 5. Handle intercepted result (2-step confirmation) ────────
        if isinstance(result, dict) and result.get("_intercepted"):
            confirmation_id = f"conf_{uuid.uuid4().hex[:12]}"
            _conf_ttl = 300
            if _confirmation_settings:
                _conf_ttl = _confirmation_settings.get("confirmation_ttl", 300)

            intercepted_calls = result.get("intercepted_calls", [])
            from datetime import datetime, timezone
            expires_at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

            # Store in Redis for later confirmation
            try:
                r = await _get_redis()
                store_data = _json.dumps({
                    "confirmation_id": confirmation_id,
                    "app_id": app_id,
                    "tool_name": tool_name,
                    "user_id": user_id_raw,
                    "tenant_id": _tenant_id,
                    "message": message,
                    "intercepted_calls": intercepted_calls,
                    "context": {k: v for k, v in ctx_data.items() if not k.startswith("_")},
                    "created_at": expires_at,
                })
                await r.setex(f"imperal:confirmation:{confirmation_id}", _conf_ttl, store_data)
                # Add to user's active confirmations set
                user_set_key = f"imperal:confirmations:user:{user_id_raw}"
                await r.sadd(user_set_key, confirmation_id)
                await r.expire(user_set_key, _conf_ttl + 60)
                log.info(f"KAV: stored confirmation {confirmation_id} TTL={_conf_ttl}s calls={len(intercepted_calls)}")
            except Exception as e:
                log.error(f"KAV: failed to store confirmation in Redis: {e}")

            # Calculate actual expiry
            from datetime import timedelta
            _exp = datetime.now(timezone.utc) + timedelta(seconds=_conf_ttl)
            expires_at = _exp.isoformat().replace("+00:00", "Z")

            return {
                "response": "",
                "type": "confirmation",
                "confirmation_id": confirmation_id,
                "app_id": app_id,
                "actions": intercepted_calls,
                "expires_at": expires_at,
                "message": message,
            }

        # ── 5b. Normalize result ──────────────────────────────────────
        if isinstance(result, dict):
            normalized = result if "response" in result else {"response": str(result)}
        else:
            normalized = {"response": str(result) if result else "Done."}

        # ── 5c. Kernel response style enforcement ────────────────────
        # Applied to ALL extensions (including non-ChatExtension like admin).
        # Strips emojis, filler phrases, excessive whitespace. CODE, not prompt.
        if isinstance(normalized, dict) and isinstance(normalized.get("response"), str) and normalized["response"]:
            from imperal_sdk.chat.extension import _enforce_response_style
            normalized["response"] = _enforce_response_style(normalized["response"])

        # ── 6. KAV Post-Execution Verification (LOOP) ─────────────────
        # Only for write/destructive intents — automations have intent_type="read" so SAFE
        # Loop re-checks _functions_called after each retry to support kav_max_retries > 1
        if _is_write_intent:
            if _confirmation_settings is None:
                _confirmation_settings = await _resolve_confirmation_settings(user_id_raw, _tenant_id)
            _kav_max = _confirmation_settings.get("kav_max_retries", 2)

            while True:
                _functions_called = normalized.get("_functions_called", [])
                _any_write_called = any(
                    fc.get("action_type") in ("write", "destructive")
                    for fc in _functions_called
                )

                if _any_write_called:
                    break  # Success — write function was called

                if not _functions_called:
                    _kav_count = ctx_data.get("_kav_retry_count", 0)
                    if _kav_count == 0:
                        # First attempt: no functions called — LLM answered from memory. Retry.
                        log.warning(f"KAV: {app_id}/{tool_name} — NO functions called for write intent, retrying")
                        # Fall through to retry logic below
                    else:
                        # Already retried but LLM still won't call functions — accept (likely impossible action)
                        log.info(f"KAV: {app_id}/{tool_name} — still no functions after retry, accepting (action may be impossible)")
                        break

                elif normalized.get("_handled", True):
                    # Extension called read functions and returned a response — this is
                    # legitimate multi-step behavior (e.g. list_notes before delete_note).
                    log.info(f"KAV: {app_id}/{tool_name} called read functions and handled — accepting")
                    break
                else:
                    log.info(f"KAV: {app_id}/{tool_name} — _handled=False, retrying")

                # LLM was asked to write but didn't call write functions
                _kav_count = ctx_data.get("_kav_retry_count", 0)
                if _kav_count >= _kav_max:
                    # All retries exhausted — honest failure
                    log.error(
                        f"KAV: retries exhausted ({_kav_max}) for {app_id}/{tool_name} — "
                        f"write action never executed"
                    )
                    normalized = {
                        "response": (
                            f"Could not execute the action after {_kav_max + 1} attempts. "
                            "Please try again or rephrase your request."
                        ),
                        "_kav_failed": True,
                    }
                    break

                # Retry — increment count and re-execute with KAV injection
                ctx_data["_kav_retry_count"] = _kav_count + 1
                _kav_msg = (
                    "KERNEL VERIFICATION FAILED: You were asked to perform a write action but only called read functions. "
                    "You MUST call the appropriate write/send/create/delete function to fulfill the user request. "
                    "Do NOT just describe what you would do — actually call the function. "
                    "If the action is impossible (e.g. nothing to delete), call a read/list function to verify and explain why."
                )
                ctx_data["_kav_injection"] = _kav_msg
                ctx._kav_injection = _kav_msg  # Also set on ctx for ChatExtension
                log.warning(
                    f"KAV: retry {_kav_count + 1}/{_kav_max} for {app_id}/{tool_name} — "
                    f"no write function called, injecting correction"
                )

                result = await ext.call_tool(tool_name, ctx, message=message)
                if isinstance(result, dict):
                    normalized = result if "response" in result else {"response": str(result)}
                else:
                    normalized = {"response": str(result) if result else "Done."}
                # Loop continues — re-checks _functions_called from new result
            # If write function was called but returned success:False — let error pass through

        # ── 7. Check for function calls BEFORE cleaning internal fields ──
        _fc_list = normalized.get("_functions_called", []) if isinstance(normalized, dict) else []
        _had_function_calls = bool(_fc_list and any(fc.get("name") != "__cancelled__" for fc in _fc_list))
        if not _is_system_task:
            log.debug(f"Action check: {app_id}/{tool_name} _functions_called={len(_fc_list)} _had={_had_function_calls}")
        # Also check if any write/destructive function succeeded
        _had_successful_action = bool(
            isinstance(normalized, dict) and normalized.get("_functions_called")
            and any(
                fc.get("action_type") in ("write", "destructive") and fc.get("success")
                for fc in normalized.get("_functions_called", [])
                if not fc.get("intercepted")
            )
        )
        # Store truth flags in result — survives cleanup, used by session_workflow Truth Gate
        if isinstance(normalized, dict):
            normalized["_had_function_calls"] = _had_function_calls
            normalized["_had_successful_action"] = _had_successful_action
        # NOTE: Do NOT clean _functions_called here — session_workflow Truth Gate needs it.
        # Cleanup happens in session_workflow after verification + action writing.
        # Only clean fields that are purely executor-internal:
        for _internal_key in ("_intercepted", "intercepted_calls"):
            normalized.pop(_internal_key, None)

        # ── 8. Skeleton: NO signal from actions. Skeleton runs on TICK ONLY (60s).
        # This is intentional — skeleton is a background context aggregator,
        # not a real-time reactor. Real-time updates go through SSE events.

        # ── 9. Pack action metadata for session_workflow ───────────────
        # Session_workflow owns Action Writer — writes AFTER Truth Gate verification.
        # We pack all executor-local data needed for recording.
        _is_navigate = tool_name in ("hub_chat", "system_chat", "discover_tools")
        _was_handled = normalized.get("_handled", True) if isinstance(normalized, dict) else True
        if isinstance(normalized, dict) and not _is_system_task and not _is_navigate and (_had_function_calls or _was_handled):
            normalized["_action_meta"] = {
                "app_id": app_id,
                "tool_name": tool_name,
                "intent_type": _intent_type,
                "duration_ms": int((_time.time() - _start_time) * 1000),
                "trace_id": generate_trace_id(),
                "chain_id": ctx_data.get("_chain_id"),
                "task_id": ctx_data.get("_task_id"),
                "message_preview": message[:200] if message else "",
                "user_id": user_id_raw,
                "tenant_id": _tenant_id,
                "kav_failed": bool(normalized.get("_kav_failed")),
                "task_cancelled": bool(normalized.get("_task_cancelled")),
                "user_scopes": user_scopes,
                "checked_scopes": required_scopes,
            }
            # Enrich with LLM model info from provider's last call
            try:
                from imperal_sdk.runtime.llm_provider import get_llm_provider
                _llm_info = getattr(get_llm_provider(), '_last_call_info', None)
                if _llm_info:
                    normalized["_action_meta"]["llm_provider"] = _llm_info.get("provider", "")
                    normalized["_action_meta"]["llm_model"] = _llm_info.get("model", "")
            except Exception:
                pass

            # Enrich _action_meta with target scope audit data
            _fc_for_audit = normalized.get("_functions_called", [])
            _tsg_audit = None
            for _fc in _fc_for_audit:
                _fc_tsg = _fc.get("_target_scope")
                if _fc_tsg and _fc_tsg.get("cross_user"):
                    _tsg_audit = _fc_tsg
                    break
            if _tsg_audit:
                normalized["_action_meta"]["target_user_id"] = _tsg_audit.get("target_user_id")
                normalized["_action_meta"]["target_param"] = _tsg_audit.get("target_param")
                normalized["_action_meta"]["cross_user"] = True
                normalized["_action_meta"]["target_scope_required"] = _tsg_audit.get("required_scope")
                normalized["_action_meta"]["target_scope_verdict"] = _tsg_audit.get("verdict")
            else:
                normalized["_action_meta"]["cross_user"] = False
        # ── 10. Kernel event: publish SSE AFTER action write (so counters are current)
        if not tool_name.startswith("skeleton_"):
            await _publish_action_event(
                user_id=user_info.get("id", ""),
                tenant_id=enriched_user.get("tenant_id", "default"),
                app_id=app_id,
                tool_name=tool_name,
                message=message,
                result=normalized,
            )

        # ── 10b. Kernel Event Publishing (ActionResult events for automations) ──
        from imperal_sdk.chat.action_result import ActionResult  # lazy import to avoid circular
        _fc_list_ev = normalized.get("_functions_called", []) if isinstance(normalized, dict) else []
        for _fc_ev in _fc_list_ev:
            _fc_result = _fc_ev.get("result")
            _fc_event = _fc_ev.get("event")
            if (_fc_result is not None
                    and isinstance(_fc_result, ActionResult)
                    and _fc_result.status == "success"
                    and _fc_event
                    and _fc_ev.get("action_type") in ("write", "destructive")):
                try:
                    _ev_redis = await _get_redis()
                    if _ev_redis:
                        await publish_kernel_event(
                            redis_client=_ev_redis,
                            tenant_id=enriched_user.get("tenant_id", "default"),
                            event_type=f"{app_id}.{_fc_event}",
                            data=_fc_result.data,
                            user_id=user_info.get("id", ""),
                            app_id=app_id,
                            function_name=_fc_ev.get("name", ""),
                            action_type=_fc_ev.get("action_type", ""),
                            timestamp=_now_utc.isoformat(),
                        )
                except Exception as _ev_err:
                    log.error(f"Kernel event publish error: {_ev_err}")

        return normalized

    except Exception as e:
        log.error(f"Extension error {app_id}/{tool_name}: {e}", exc_info=True)
        # Mark task as failed if it was created
        if _task_id:
            try:
                redis = await _get_redis()
                await complete_task(redis, _task_id, user_id_raw, "failed")
            except Exception:
                pass

        # ── L8 Cascade Map: check cascade effects on extension failure ──
        _cascade_effects = []
        try:
            from imperal_sdk.runtime.cascade_map import get_cascade_map, get_cascade_effects
            _cascade = await get_cascade_map()
            _cascade_effects = get_cascade_effects(_cascade, app_id)
            if _cascade_effects:
                log.warning(f"CASCADE ALERT: {app_id} failed, affected: {[e['app_id'] for e in _cascade_effects]}")
        except Exception:
            pass  # cascade check is best-effort

        return {
            "response": "An error occurred while processing your request.",
            "_cascade_effects": _cascade_effects if _cascade_effects else None,
        }

    finally:
        # 7. Cleanup — skip if task was promoted (background handler owns ctx)
        if not getattr(ctx, "_promoted", False):
            await _factory.destroy(ctx)


async def _deliver_to_chat(redis, user_id: str, content: str, msg_type: str = "response",
                           task_id: str = "", tenant_id: str = "default") -> None:
    """Deliver a background task result to chat history via Redis.

    Strategy: find the existing task_promoted message and UPDATE it with the result.
    This way Panel polling (which watches for status=done on the known message ID)
    picks up the content automatically. Falls back to append if no promoted msg found.
    Also publishes SSE so Panel re-fetches chat if polling already stopped.
    """
    from datetime import datetime
    history_key = f"imperal:hub:chat:{user_id}"
    try:
        existing = await redis.get(history_key)
        messages = _json.loads(existing) if existing else []

        # Strategy 1: Find and update existing task_promoted message for this task
        updated = False
        if task_id:
            for msg in messages:
                if msg.get("type") == "task_promoted" and msg.get("task_id") == task_id:
                    msg["content"] = content
                    msg["status"] = "done"
                    msg["status_text"] = None
                    msg["type"] = msg_type
                    updated = True
                    break

        # Strategy 2: Append as new message if no promoted message found
        if not updated:
            messages.append({
                "id": int(_time.time() * 1000),
                "role": "assistant",
                "content": content,
                "status": "done",
                "status_text": None,
                "type": msg_type,
                "ts": datetime.utcnow().isoformat() + "Z",
            })

        await redis.set(history_key, _json.dumps(messages, ensure_ascii=False), ex=86400)

        # Publish SSE so Panel knows to re-fetch chat history
        try:
            await redis.publish(f"imperal:events:{tenant_id}", _json.dumps({
                "type": "state_changed",
                "scope": "hub",
                "action": "background_task_delivered",
                "id": task_id or "unknown",
                "actor": user_id,
                "tenant_id": tenant_id,
                "user_id": user_id,
                "timestamp": _time.strftime("%Y-%m-%dT%H:%M:%SZ", _time.gmtime()),
                "data": {"task_id": task_id, "msg_type": msg_type},
            }))
        except Exception:
            pass

    except Exception as e:
        log.warning(f"Failed to deliver background result to chat for {user_id}: {e}")


async def _background_task_completion(
    ext_task: asyncio.Task,
    redis,
    task_id: str,
    user_id: str,
    tenant_id: str,
    app_id: str,
    tool_name: str,
    message: str,
    user_info: dict,
    enriched_user: dict,
    ctx=None,
) -> None:
    """Handle completion of a promoted background task.

    Waits for ext_task to finish, then marks the task as completed/failed,
    publishes SSE events, and delivers the result to chat history.
    Owns the ctx lifecycle — destroys it when done.
    """
    try:
        result = await ext_task
        await complete_task(redis, task_id, user_id, "completed")

        # Normalize result
        if isinstance(result, dict):
            response_text = result.get("response", str(result))
        else:
            response_text = str(result) if result else "Done."

        # ── Truth Gate (same logic as session_workflow) ───────────
        # Prevents fabricated or integrity-failed responses in background tasks.
        _action_claims = (
            "sent", "deleted", "archived", "created", "forwarded", "replied",
            "moved", "removed", "updated", "saved", "composed",
            "отправлено", "удалено", "заархивировано", "создано", "переслано",
            "перемещено", "сохранено", "обновлено",
        )
        _success_claims = (
            "successfully", "done", "completed", "success",
            "успешно", "готово", "выполнено",
        )
        _bg_verdict = "pass"
        if response_text and isinstance(result, dict):
            _tl = response_text.lower()
            if any(c in _tl for c in _action_claims):
                _bg_had_action = result.get("_had_successful_action", False)
                _bg_had_fn = result.get("_had_function_calls", False)
                if _bg_had_action:
                    _bg_verdict = "pass"
                elif _bg_had_fn:
                    _fc = result.get("_functions_called", [])
                    _failed = [f for f in _fc if f.get("action_type") in ("write", "destructive") and not f.get("success") and not f.get("intercepted")]
                    if _failed and any(w in _tl for w in _success_claims):
                        _ok = [f.get("name", "?") for f in _fc if f.get("success")]
                        _fl = [f"- {f.get('name','?')}: {f.get('error','')}" for f in _failed]
                        parts = []
                        if _ok: parts.append(f"Completed: {', '.join(_ok)}.")
                        if _fl: parts.append("Could not complete:\n" + "\n".join(_fl))
                        response_text = "Some actions failed.\n\n" + "\n\n".join(parts)
                        _bg_verdict = "integrity_failure"
                else:
                    response_text = "I wasn't able to complete that action. Please try again."
                    _bg_verdict = "fabrication"
        if _bg_verdict != "pass":
            log.warning(f"Background Truth Gate: {_bg_verdict} for {app_id}/{tool_name} task={task_id}")

        # Determine message type from result
        _bg_fc_list = result.get("_functions_called", []) if isinstance(result, dict) else []
        _bg_msg_type = "function_call" if (_bg_fc_list and any(fc.get("name") != "__cancelled__" for fc in _bg_fc_list)) else "response"

        # Store result so Panel Task Monitor can fetch it
        await redis.setex(
            f"imperal:task:{task_id}:result",
            86400,
            _json.dumps({"response": response_text[:2000]}),
        )

        # Deliver result to chat history so user sees it in the conversation
        if response_text and response_text.strip():
            await _deliver_to_chat(redis, user_id, response_text, _bg_msg_type, task_id=task_id, tenant_id=tenant_id)

        # Publish completion SSE
        await redis.publish(f"imperal:events:{tenant_id}", _json.dumps({
            "type": "task.completed", "scope": "task", "action": "completed",
            "data": {"task_id": task_id, "app_id": app_id, "tool_name": tool_name,
                     "user_id": user_id, "response_preview": response_text[:200]}
        }))

        # ── Action Writer for promoted tasks ─────────────────────
        # Step 9 is never reached for promoted tasks (main path returns early).
        # Write action here using _had_function_calls from the result.
        _fc_list = result.get("_functions_called", []) if isinstance(result, dict) else []
        _bg_had_function_calls = bool(_fc_list and any(fc.get("name") != "__cancelled__" for fc in _fc_list))
        if _bg_had_function_calls and not tool_name.startswith("skeleton_"):
            _bg_intent = "read"
            if _fc_list:
                for fc in _fc_list:
                    if fc.get("action_type") in ("write", "destructive") and fc.get("success"):
                        _bg_intent = fc["action_type"]
                        break
            try:
                await write_action(
                    gateway_url=os.getenv("IMPERAL_GATEWAY_URL", "http://104.224.88.155:8085"),
                    service_token=os.getenv("IMPERAL_SERVICE_TOKEN", ""),
                    trace_id=generate_trace_id(),
                    user_id=user_id,
                    tenant_id=tenant_id,
                    app_id=app_id,
                    tool_name=tool_name,
                    action_type=_bg_intent,
                    intent_type=_bg_intent,
                    status="completed",
                    message_preview=message[:200] if message else "",
                    result_preview=response_text[:200],
                    duration_ms=0,
                    parent_task_id=task_id,
                )
                log.info(f"Background action written: {app_id}/{tool_name} intent={_bg_intent} task={task_id}")
            except Exception as _aw_err:
                log.warning(f"Background action write failed (non-blocking): {_aw_err}")

        # Publish action event (SSE)
        if not tool_name.startswith("skeleton_"):
            await _publish_action_event(
                user_id=user_info.get("id", ""),
                tenant_id=enriched_user.get("tenant_id", "default"),
                app_id=app_id,
                tool_name=tool_name,
                message=message,
                result={"response": response_text},
            )

        log.info(f"Background task completed: task={task_id} app={app_id}/{tool_name}")

    except asyncio.CancelledError:
        await complete_task(redis, task_id, user_id, "cancelled")
        log.warning(f"Background task cancelled: task={task_id}")

    except Exception as e:
        log.error(f"Background task failed: task={task_id} error={e}", exc_info=True)
        await complete_task(redis, task_id, user_id, "failed")

        # Deliver error to chat so user knows what happened
        await _deliver_to_chat(redis, user_id, f"Task failed: {str(e)[:200]}", "task_failed", task_id=task_id, tenant_id=tenant_id)

        try:
            await redis.publish(f"imperal:events:{tenant_id}", _json.dumps({
                "type": "task.failed", "scope": "task", "action": "failed",
                "data": {"task_id": task_id, "app_id": app_id, "tool_name": tool_name,
                         "user_id": user_id, "error": str(e)[:200]}
            }))
        except Exception:
            pass

    finally:
        # Destroy context after background task completes (we own it)
        if ctx is not None:
            try:
                await _factory.destroy(ctx)
            except Exception:
                pass


# ── Kernel Action Event Publisher ──────────────────────────────────

# Action counter — tracks total executions per tool per session
_action_counter: dict[str, int] = {}

async def _publish_action_event(user_id: str, tenant_id: str, app_id: str,
                                 tool_name: str, message: str, result: dict) -> None:
    """Kernel-level event publisher. EVERY extension action gets an event.
    
    Published to Redis imperal:events:{tenant_id} for:
    - SSE → Panel real-time updates
    - Rule engine → automation triggers
    
    Includes timestamp + use counter automatically.
    Extensions don't need to publish events — kernel does it.
    """
    # Increment action counter
    counter_key = f"{app_id}/{tool_name}"
    _action_counter[counter_key] = _action_counter.get(counter_key, 0) + 1
    
    # Determine scope from app_id
    scope_map = {
        "gmail": "email", "admin": "admin", "sharelock-v2": "case",
        "notes": "notes", "__system__": "system",
    }
    scope = scope_map.get(app_id, app_id)
    
    # Determine action from tool response
    response_text = result.get("response", "") if isinstance(result, dict) else str(result)
    action = tool_name.replace(f"tool_{app_id.replace('-','_')}_chat", "action").replace("tool_", "")
    
    try:
        import redis.asyncio as aioredis
        r = aioredis.Redis(
            host=os.getenv("REDIS_HOST", "104.224.88.155"),
            port=int(os.getenv("REDIS_PORT", "6379")),
            password=os.getenv("REDIS_PASS", "Rqrq131353114023(*&"),
            db=0,
        )
        event = _json.dumps({
            "type": "state_changed",
            "scope": scope,
            "action": action,
            "id": f"{app_id}/{tool_name}",
            "actor": user_id,
            "tenant_id": tenant_id,
            "user_id": user_id,
            "timestamp": _time.strftime("%Y-%m-%dT%H:%M:%SZ", _time.gmtime()),
            "data": {
                "app_id": app_id,
                "tool_name": tool_name,
                "message": message[:200] if message else "",
                "response_preview": response_text[:200] if isinstance(response_text, str) else "",
                "use_count": _action_counter[counter_key],
            },
        })
        await r.publish(f"imperal:events:{tenant_id}", event)
        await r.aclose()
        log.info(f"Kernel event: {scope}.{action} app={app_id} tool={tool_name} count={_action_counter[counter_key]}")
    except Exception as e:
        log.warning(f"Kernel event publish failed: {e}")


# ── Kernel Signals ────────────────────────────────────────────────

def _inject_capability_boundary(ctx, app_id: str, ext):
    """Kernel injects ICNLI integrity protocol into every extension context.

    Two parts:
    1. Capability boundary — what this extension CAN and CANNOT do
    2. ICNLI integrity rules — zero hallucination, verified actions only

    Injected into skeleton._context so extension's LLM sees it in system prompt."""
    skeleton = ctx.skeleton_data if ctx.skeleton_data else {}
    _context = skeleton.get("_context", {})

    my_tools = list(ext.tools.keys())

    other_capabilities = []
    if _catalog and _catalog.loaded:
        for t in _catalog.tools:
            if t["app_id"] != app_id:
                other_capabilities.append({
                    "app_id": t["app_id"],
                    "name": t["name"],
                    "description": t.get("description", "")[:100],
                })

    _context["_capability_boundary"] = {
        "you_are": app_id,
        "your_tools": my_tools,
        "your_tool_count": len(my_tools),
        "other_extensions": other_capabilities,
        "rule": (
            f"You are extension '{app_id}'. You can ONLY perform actions using your tools: {my_tools}. "
            f"If the user asks for something outside your capabilities, "
            f"you MUST say: 'This is handled by [correct extension]. Please ask it directly.' "
            f"NEVER pretend you performed an action you don't have a tool for."
        ),
    }

    # ICNLI Integrity Protocol — injected into EVERY extension by kernel
    _context["_icnli_integrity"] = {
        "protocol": "ICNLI",
        "version": "1.0",
        "rules": [
            "ONLY report what functions actually returned. If a function returned an error, report the error.",
            "NEVER fabricate data, URLs, links, tokens, IDs, or any information not returned by a function.",
            "NEVER claim an action succeeded unless the function result explicitly confirms success.",
            "NEVER generate OAuth URLs, authorization links, or credentials — you do not have this capability.",
            "If unsure whether an action succeeded, call a read/list function to verify before reporting.",
            "If you cannot perform what the user asked, say what you cannot do and which extension handles it.",
            "NEVER apologize repeatedly or contradict yourself. State facts once.",
            "NEVER answer questions from cached context or conversation history — always call a function for fresh data.",
            "ALWAYS respond in the SAME language as the user's last message. If they write in Russian, respond in Russian. If English, respond in English. Match their language exactly.",
        ],
        "enforcement": "KERNEL — these rules are enforced by the ICNLI OS. Violation = system integrity failure.",
    }

    # ── Skeleton Freshness Validation (ICNLI L6 compliance) ──────
    # Scan skeleton sections for stale data and inject warnings.
    # Extensions and LLM see _stale_sections so they know to be cautious.
    import time as _fresh_time
    _stale_sections = []
    for _sec_name, _sec_data in skeleton.items():
        if _sec_name.startswith("_"):
            continue
        if isinstance(_sec_data, dict) and "_freshness" in _sec_data:
            _fr = _sec_data["_freshness"]
            _ttl_rem = _fr.get("ttl_remaining", -1)
            _refreshed_at = _fr.get("refreshed_at")
            _ttl_orig = _sec_data.get("_ttl_seconds", 0)
            # Mark stale if: TTL remaining < 10% of original OR refreshed_at > 2x TTL ago
            if _ttl_orig and _ttl_rem >= 0 and _ttl_rem < _ttl_orig * 0.1:
                _stale_sections.append({"section": _sec_name, "ttl_remaining": _ttl_rem, "reason": "ttl_expiring"})
            elif _refreshed_at and _ttl_orig and (_fresh_time.time() - _refreshed_at) > _ttl_orig * 2:
                _stale_sections.append({"section": _sec_name, "age_seconds": int(_fresh_time.time() - _refreshed_at), "reason": "overdue_refresh"})
    if _stale_sections:
        _context["_stale_sections"] = _stale_sections
        _context["_freshness_warning"] = (
            "Some skeleton data may be outdated. If the user asks about real-time state, "
            "call a function to get fresh data instead of relying on skeleton cache."
        )

    skeleton["_context"] = _context
    ctx.skeleton_data = skeleton


async def _signal_skeleton_after_action(user_id: str, app_id: str, tool_name: str):
    """Signal skeleton workflow to refresh after any extension tool execution.
    Non-blocking: failures are logged but don't affect the tool response.
    Skips skeleton_* tools to avoid infinite recursion."""
    if not user_id:
        return
    try:
        import httpx
        _gw_url = os.getenv("IMPERAL_GATEWAY_URL", "http://104.224.88.155:8085")
        _svc_token = os.getenv("IMPERAL_SERVICE_TOKEN", "")
        r = await _get_redis()
        await r.publish("imperal:config:invalidate", _json.dumps({
            "scope": "skeleton", "user_id": user_id, "app_id": app_id,
        }))
        log.info(f"Kernel signal: skeleton refresh for user {user_id} after {app_id}/{tool_name}")
    except Exception as e:
        # Non-fatal: skeleton may not be running yet, or already terminated
        log.debug(f"Skeleton signal skipped for user {user_id}: {e}")


# ── System Tools ──────────────────────────────────────────────────


async def _handle_discover_tools(tool_input: dict) -> dict:
    """Handle discover_tools system call — semantic search over tool catalog."""
    if _catalog is None or not _catalog.loaded:
        log.warning("discover_tools called but catalog not loaded")
        return {"response": {"tools_found": 0, "tools": [], "error": "Catalog not available"}}

    message = tool_input.get("message", "")
    context = tool_input.get("context", {})
    top_k = context.get("top_k", 5)
    session_tools = context.get("session_tools", [])

    user_info = tool_input.get("user", {})
    user_scopes = user_info.get("scopes", ["*"])
    results = await _catalog.search(
        query=message,
        top_k=min(top_k, 10),
        session_tools=session_tools,
        user_scopes=user_scopes,
    )

    log.info(f"discover_tools: query='{message[:60]}', found={len(results)}")

    return {
        "response": {
            "tools_found": len(results),
            "tools": results,
        }
    }


async def _handle_hub_chat(tool_input: dict) -> dict:
    """Handle hub_chat — ICNLI OS kernel orchestrator.

    Replaces system_chat as default handler. Two modes:
    - Navigation: no extension matches → help user find the right extension
    - Orchestration: extensions matched → parallel dispatch + combine
    """
    from imperal_sdk.runtime.hub import handle_hub_chat
    from imperal_sdk.runtime.relations import load_app_relations

    user_info = tool_input.get("user", {})
    tenant_id = user_info.get("tenant_id", "default")

    relations = await load_app_relations(tenant_id)

    return await handle_hub_chat(
        tool_input=tool_input,
        execute_fn=execute_sdk_tool,
        catalog=_catalog,
        relations=relations,
    )


# DEPRECATED: system_chat now handled by _handle_hub_chat via hub.py
# Kept for reference only
async def _handle_system_chat(tool_input: dict) -> dict:
    """Handle system_chat — OS-level conversation with full capability awareness.

    The system knows ALL its capabilities from the ToolCatalog.
    Used for greetings, "what can you do?", and any message that
    doesn't match a specific extension tool.

    CRITICAL: system_chat is READ-ONLY. It cannot execute any actions.
    It can only navigate users to the right extension.
    """
    message = tool_input.get("message", "")
    history = tool_input.get("history", [])
    skeleton = tool_input.get("skeleton", {})
    user_info = tool_input.get("user", {})

    # Build capabilities list from live catalog
    capabilities = []
    if _catalog and _catalog.loaded:
        # Group tools by extension
        ext_tools: dict[str, list[str]] = {}
        for t in _catalog.tools:
            app = t.get("app_display_name", t.get("app_id", "unknown"))
            desc = t.get("description", t.get("name", ""))
            ext_tools.setdefault(app, []).append(desc)

        for app_name, tools in ext_tools.items():
            tool_list = "; ".join(t for t in tools if t)
            if tool_list:
                capabilities.append(f"- **{app_name}**: {tool_list}")
            else:
                capabilities.append(f"- **{app_name}**")

    capabilities_text = "\n".join(capabilities) if capabilities else "No extensions installed."

    # Build skeleton context (known issues, alerts)
    skeleton_context = ""
    ctx_data = skeleton.get("_context", {})
    for key, val in skeleton.items():
        if key.startswith("_") or val is None:
            continue
        if isinstance(val, str) and val.strip():
            skeleton_context += f"- {key}: {val[:200]}\n"
        elif isinstance(val, dict):
            summary = str(val)[:200]
            skeleton_context += f"- {key}: {summary}\n"

    # User identity (resolved by kernel)
    user_email = user_info.get("email", "unknown")
    user_role = user_info.get("role", "user")
    user_id_display = user_info.get("id", "")
    user_identity = f"CURRENT USER: {user_email} (role: {user_role}, id: {user_id_display})"

    system_prompt = f"""You are the Imperal Cloud ICNLI OS — an intelligent cloud operating system.
You are the system shell, not an extension or app. You help users navigate to the right extension.

{user_identity}

AVAILABLE EXTENSIONS (live from catalog — these are the ONLY things that exist):
{capabilities_text}

{f"SYSTEM CONTEXT:{chr(10)}{skeleton_context}" if skeleton_context else ""}

ABSOLUTE RULES — VIOLATION IS SYSTEM FAILURE:
1. You are READ-ONLY. You CANNOT execute any actions, commands, or operations.
2. You CANNOT suspend, activate, delete, create, update, or modify ANYTHING.
3. You CANNOT generate URLs, OAuth links, tokens, credentials, or authorization links.
4. You CANNOT connect accounts, send emails, manage users, or perform any operation.
5. If the user asks you to DO something (suspend, activate, connect, show data, etc.) — tell them WHICH EXTENSION handles it. Example: "This is handled by System Admin. Please ask it directly — just say 'suspend gmail extension'."
6. You can ONLY: greet users, explain what extensions are available, and direct users to the right extension.
7. NEVER say "I did it", "Done", "Suspended", "Activated", or any confirmation of an action. You cannot do actions.
8. NEVER fabricate or invent any data, links, or results.
9. When asked "what can you do?" — list ONLY the extensions from the catalog above. Nothing else.
10. Respond in the user's language. No emojis. "Imperal" not "Imperial".
11. Be concise. One or two sentences max. Direct the user, don't explain at length."""

    # Build messages for Haiku
    messages = []
    for h in history[-6:]:
        role = h.get("role", "user")
        content = h.get("content", "")
        if role in ("user", "assistant") and content:
            messages.append({"role": role, "content": content})
    messages.append({"role": "user", "content": message})

    try:
        provider = _get_llm()
        resp = await provider.create_message(
            model="claude-haiku-4-5-20251001",
            max_tokens=1024,
            system=system_prompt,
            messages=messages,
        )
        response_text = resp.content[0].text if resp.content else "Hello! How can I help you?"
        log.info(f"system_chat: user='{message[:60]}', response_len={len(response_text)}")
        return {"response": response_text}

    except Exception as e:
        log.error(f"system_chat error: {e}")
        return {"response": "Hello! I'm the Imperal Cloud OS. How can I help you today?"}


async def _handle_manage_automations(tool_input: dict) -> dict:
    """System tool: manage user automations via Auth Gateway API.
    
    Available to any user with automations:* scope.
    No admin extension needed — direct API calls.
    """
    import httpx
    import json as _json

    gw_url = os.getenv("IMPERAL_GATEWAY_URL", "http://104.224.88.155:8085")
    svc_token = os.getenv("IMPERAL_SERVICE_TOKEN", "")
    
    message = tool_input.get("message", "")
    user_info = tool_input.get("user", {})
    user_id = user_info.get("id", "")
    user_role = user_info.get("role", "user")
    history = tool_input.get("history", [])

    # Scope check
    user_scopes = user_info.get("scopes", [])
    has_automations = (
        "*" in user_scopes
        or "automations:*" in user_scopes
        or "automations:read" in user_scopes
        or "extensions:read" in user_scopes
    )
    if not has_automations:
        return {"response": "You don't have permission to manage automations."}

    can_write = (
        "*" in user_scopes
        or "automations:*" in user_scopes
        or "automations:write" in user_scopes
        or "extensions:write" in user_scopes
    )

    # Fetch user's automations for context
    try:
        tz = user_info.get("attributes", {}).get("timezone", "UTC")
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(
                f"{gw_url}/v1/automations",
                headers={"X-Service-Token": svc_token},
                params={"user_id": user_id, "tenant_id": "default", "timezone": tz},
            )
            my_rules = resp.json() if resp.status_code == 200 else []
    except Exception:
        my_rules = []

    rules_summary = ""
    if my_rules:
        for r in my_rules:
            rules_summary += f"- Rule #{r['id']}: \"{r.get('prompt','')}\" status={r.get('status','?')} triggers={r.get('trigger_count',0)}\n"
    else:
        rules_summary = "(no automations yet)"

    # Define tools for Haiku
    tools = [
        {
            "name": "list_automations",
            "description": "List all user's automation rules with their status and trigger counts",
            "input_schema": {"type": "object", "properties": {}, "required": []},
        },
        {
            "name": "create_automation",
            "description": "Create a new automation rule from a natural language prompt. Example: 'When I receive an email from boss@company.com, create a note with the summary'",
            "input_schema": {
                "type": "object",
                "properties": {
                    "prompt": {"type": "string", "description": "Natural language description of the automation rule"},
                    "cooldown_seconds": {"type": "integer", "description": "Minimum seconds between triggers (default 60)", "default": 60},
                    "max_per_hour": {"type": "integer", "description": "Maximum triggers per hour (default 10)", "default": 10},
                },
                "required": ["prompt"],
            },
        },
        {
            "name": "pause_automation",
            "description": "Pause an active automation rule",
            "input_schema": {
                "type": "object",
                "properties": {"rule_id": {"type": "integer", "description": "The rule ID to pause"}},
                "required": ["rule_id"],
            },
        },
        {
            "name": "resume_automation",
            "description": "Resume a paused automation rule",
            "input_schema": {
                "type": "object",
                "properties": {"rule_id": {"type": "integer", "description": "The rule ID to resume"}},
                "required": ["rule_id"],
            },
        },
        {
            "name": "delete_automation",
            "description": "Permanently delete an automation rule",
            "input_schema": {
                "type": "object",
                "properties": {"rule_id": {"type": "integer", "description": "The rule ID to delete"}},
                "required": ["rule_id"],
            },
        },
    ]

    # Remove write tools if user only has read
    if not can_write:
        tools = [t for t in tools if t["name"] == "list_automations"]

    system = f"""You are the Imperal Cloud automation manager. Help the user manage their automation rules.

CURRENT USER AUTOMATIONS:
{rules_summary}

RULES:
- Users can only manage their OWN automations (already filtered).
- Be concise. Respond in the user's language.
- When creating automations, the 'prompt' should be a clear natural language description of the trigger and action.
- When listing, format nicely with rule ID, description, status, and trigger count.
- "Imperal" not "Imperial". No emojis."""

    msgs = []
    for h in (history or [])[-4:]:
        if h.get("role") in ("user", "assistant") and h.get("content"):
            msgs.append({"role": h["role"], "content": h["content"]})
    msgs.append({"role": "user", "content": message})

    try:
        aclient = _get_llm()
        
        # Round 1: Haiku decides what to do
        resp = await aclient.create_message(
            model="claude-haiku-4-5-20251001",
            max_tokens=1024,
            system=system,
            messages=msgs,
            tools=tools,
        )

        functions_called = []
        response_text = ""

        for block in resp.content:
            if block.type == "text":
                response_text += block.text
            elif block.type == "tool_use":
                fn_name = block.name
                fn_input = block.input
                fn_result = await _execute_automation_fn(fn_name, fn_input, user_id, gw_url, svc_token)
                functions_called.append({"name": fn_name, "success": "error" not in str(fn_result).lower()})

                # Round 2: Haiku formats the result
                msgs.append({"role": "assistant", "content": resp.content})
                msgs.append({"role": "user", "content": [{"type": "tool_result", "tool_use_id": block.id, "content": _json.dumps(fn_result, ensure_ascii=False)}]})
                resp2 = await aclient.create_message(
                    model="claude-haiku-4-5-20251001",
                    max_tokens=1024,
                    system=system,
                    messages=msgs,
                    tools=tools,
                )
                for b2 in resp2.content:
                    if b2.type == "text":
                        response_text += b2.text

        return {
            "response": response_text or "I can help you manage your automations. Try asking me to list, create, pause, resume, or delete automation rules.",
            "_had_function_calls": len(functions_called) > 0,
            "_had_successful_action": any(fc.get("success") for fc in functions_called),
            "_handled": True,
            "_functions_called": functions_called,
        }

    except Exception as e:
        log.error(f"manage_automations error: {e}")
        return {"response": f"Failed to process automation request: {e}", "_handled": True}


async def _execute_automation_fn(fn_name: str, fn_input: dict, user_id: str, gw_url: str, svc_token: str) -> dict:
    """Execute a single automation management function via Auth Gateway API."""
    import httpx

    headers = {"X-Service-Token": svc_token, "Content-Type": "application/json"}

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            if fn_name == "list_automations":
                resp = await client.get(
                    f"{gw_url}/v1/automations",
                    headers=headers,
                    params={"user_id": user_id, "tenant_id": "default"},
                )
                if resp.status_code == 200:
                    rules = resp.json()
                    return {"rules": rules, "count": len(rules)}
                return {"error": f"Failed to list automations: {resp.status_code}"}

            elif fn_name == "create_automation":
                prompt = fn_input.get("prompt", "")
                if not prompt:
                    return {"error": "Prompt is required"}
                
                # Use Haiku to interpret the rule
                aclient = _get_llm()
                interp = await aclient.create_message(
                    model="claude-haiku-4-5-20251001",
                    max_tokens=300,
                    messages=[{"role": "user", "content": f"""Parse this automation rule into structured format.

Rule: "{prompt}"

Return JSON only:
{{"event_type": "email.received|schedule.cron|...", "interpretation": "one sentence summary", "actions": [{{"message": "natural language action step"}}], "cooldown_seconds": 60}}"""}],
                )
                import json as _json
                raw = interp.content[0].text.strip()
                if raw.startswith("```"):
                    raw = "\n".join(l for l in raw.split("\n") if not l.strip().startswith("```"))
                parsed = _json.loads(raw)

                # Validate cron schedule if system.scheduled
                _evt_type = parsed.get("event_type", "email.received")
                _schedule = parsed.get("schedule", "")
                if _evt_type == "system.scheduled" and _schedule:
                    try:
                        from croniter import croniter as _cron
                        _cron(_schedule)
                    except (ValueError, KeyError) as _ce:
                        return {"error": f"Invalid cron expression '{_schedule}': {_ce}"}

                body = {
                    "user_id": user_id,
                    "tenant_id": "default",
                    "prompt": prompt,
                    "trigger_filter": {"event_type": _evt_type, **(
                        {"schedule": _schedule} if _schedule else {}
                    )},
                    "actions": parsed.get("actions", [{"message": prompt}]),
                    "interpretation": parsed.get("interpretation", prompt),
                    "cooldown_seconds": fn_input.get("cooldown_seconds", parsed.get("cooldown_seconds", 60)),
                    "max_per_hour": fn_input.get("max_per_hour", 10),
                    "max_iterations": 50,
                    "status": "active",
                }
                resp = await client.post(f"{gw_url}/v1/automations", headers=headers, json=body)
                if resp.status_code in (200, 201):
                    return {"created": True, "rule": resp.json()}
                return {"error": f"Failed to create: {resp.status_code} {resp.text}"}

            elif fn_name == "pause_automation":
                rule_id = fn_input.get("rule_id")
                resp = await client.patch(
                    f"{gw_url}/v1/automations/{rule_id}",
                    headers=headers,
                    json={"status": "paused"},
                    params={"user_id": user_id},
                )
                if resp.status_code == 200:
                    return {"paused": True, "rule_id": rule_id}
                return {"error": f"Failed to pause: {resp.status_code}"}

            elif fn_name == "resume_automation":
                rule_id = fn_input.get("rule_id")
                resp = await client.patch(
                    f"{gw_url}/v1/automations/{rule_id}",
                    headers=headers,
                    json={"status": "active"},
                    params={"user_id": user_id},
                )
                if resp.status_code == 200:
                    return {"resumed": True, "rule_id": rule_id}
                return {"error": f"Failed to resume: {resp.status_code}"}

            elif fn_name == "delete_automation":
                rule_id = fn_input.get("rule_id")
                resp = await client.delete(
                    f"{gw_url}/v1/automations/{rule_id}",
                    headers=headers,
                    params={"user_id": user_id},
                )
                if resp.status_code in (200, 204):
                    return {"deleted": True, "rule_id": rule_id}
                return {"error": f"Failed to delete: {resp.status_code}"}

            else:
                return {"error": f"Unknown function: {fn_name}"}

    except Exception as e:
        return {"error": str(e)}
