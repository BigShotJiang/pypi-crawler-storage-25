"""
secrets — Credential Vault 인터페이스 + 레지스트리 (v0.17 트랙 5).

설계 원칙:
  - **LLM 에 평문 노출 금지.** Tool 파라미터는 `{"secret_ref": "prod_shop_pw"}`
    같은 참조만 보고, 실행 시점에 Vault 가 치환.
  - **엔진은 Vault 인터페이스만 제공.** 실제 저장소(Postgres 암호화 컬럼, HashiCorp
    Vault, .env 파일 등) 구현은 **이식측 / 외부 패키지**. entry_points 로 자동 연결.
  - **하드코딩 0.** 새 Vault 구현 추가는 `register_vault("my_vault", impl)` 한 줄.

사용 흐름:
  1. 이식측이 PostgresVault 를 구현해 `register_vault("postgres", PostgresVault(...))`
  2. LLM tool 파라미터: `{"password": {"secret_ref": "shop_main_pw", "vault": "postgres"}}`
  3. s07_act 실행 전 `resolve_secret_refs(tool_input)` 로 치환
  4. 치환된 값은 subprocess 경계 이후 메모리에서만, 이벤트 로그에 평문 미노출
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional, Protocol

logger = logging.getLogger("harness.secrets")


class Vault(Protocol):
    """Credential 조회 인터페이스. get(ref) → 평문 비밀. 실패 시 KeyError."""

    def get(self, ref: str) -> str:
        ...

    def name(self) -> str:
        ...


_VAULTS: dict[str, Vault] = {}


def register_vault(name: str, impl: Vault) -> None:
    """Vault 등록. 같은 이름 재등록은 덮어쓰기 (테스트/재설정 용이)."""
    _VAULTS[name] = impl
    logger.info("[secrets] Vault registered: %s (%s)", name, type(impl).__name__)


def unregister_vault(name: str) -> None:
    _VAULTS.pop(name, None)


def get_vault(name: str) -> Optional[Vault]:
    return _VAULTS.get(name)


def list_vaults() -> list[str]:
    return sorted(_VAULTS.keys())


def get_default_vault() -> Optional[Vault]:
    """Vault 가 딱 하나만 등록돼 있으면 그것을 default 로. 0/2+ 이면 None."""
    if len(_VAULTS) == 1:
        return next(iter(_VAULTS.values()))
    return None


# ── entry_points 자동 발견 ────────────────────────────────────────

def _bootstrap_vaults_from_entry_points() -> None:
    try:
        import sys
        if sys.version_info >= (3, 10):
            from importlib.metadata import entry_points
            eps = entry_points(group="xgen_harness.vaults")
        else:
            from importlib.metadata import entry_points
            eps = entry_points().get("xgen_harness.vaults", [])
        for ep in eps:
            try:
                factory = ep.load()
                impl = factory() if callable(factory) else factory
                register_vault(ep.name, impl)
            except Exception as e:
                logger.warning("[secrets] vault plugin %s load failed: %s", ep.name, e)
    except Exception as e:
        logger.debug("[secrets] entry_points discovery skipped: %s", e)


_bootstrap_vaults_from_entry_points()


# ── secret_ref 치환 ───────────────────────────────────────────────

@dataclass
class ResolveResult:
    resolved: dict
    touched: list[str]  # 치환한 경로 (감사용 — 평문 X)
    errors: list[str]


def resolve_secret_refs(
    tool_input: dict,
    default_vault_name: Optional[str] = None,
) -> ResolveResult:
    """tool_input 재귀 순회하며 `{"secret_ref": "key", "vault": "name"}` 모양 치환.

    - "vault" 미지정이면 default_vault_name 사용, 그것도 없으면 get_default_vault().
    - 실패 시 value 를 None 으로 두고 errors 에 사유 누적 (raise 안 함 — 감사 우선).
    """
    touched: list[str] = []
    errors: list[str] = []

    def _walk(node, path: str):
        if isinstance(node, dict):
            if "secret_ref" in node and isinstance(node["secret_ref"], str):
                ref = node["secret_ref"]
                vault_name = node.get("vault") or default_vault_name
                vault = get_vault(vault_name) if vault_name else get_default_vault()
                if vault is None:
                    errors.append(f"{path}: no vault available (ref={ref})")
                    return None
                try:
                    val = vault.get(ref)
                    touched.append(f"{path} <- {vault.name()}:{ref}")
                    return val
                except Exception as e:
                    errors.append(f"{path}: vault.get({ref}) failed — {e}")
                    return None
            return {k: _walk(v, f"{path}.{k}") for k, v in node.items()}
        if isinstance(node, list):
            return [_walk(v, f"{path}[{i}]") for i, v in enumerate(node)]
        return node

    resolved = _walk(dict(tool_input), "$")
    return ResolveResult(resolved=resolved, touched=touched, errors=errors)


__all__ = [
    "Vault",
    "register_vault",
    "unregister_vault",
    "get_vault",
    "list_vaults",
    "get_default_vault",
    "resolve_secret_refs",
    "ResolveResult",
]
