"""
S12 Publish — Auto-Publish (자가 증식 도구 에이전트, v0.18.0)

실행 성공 후 워크플로우를 **자동 compile → SandboxEnv 에 pip install** 해서
다음 요청부터 LLM 이 카탈로그로 발견 가능한 gallery tool 로 등록.

발동 조건 (HarnessConfig.auto_publish_mode):
    - "off"             : 실행 안 함 (기본값 아님 — v0.18.0 기본은 planner_decides)
    - "planner_decides" : Plan.auto_publish=True 일 때만
    - "on_score"        : validation_score >= auto_publish_threshold (기본 0.85)

안전장치:
    - SandboxEnv (venv 격리) — 호스트 python 절대 건드리지 않음
    - smoke import 검증 실패 시 등록 차단
    - DisclosureEvent(kind="gallery_publish") 로 관측
"""

from __future__ import annotations

import logging
from typing import Any

from ...core.stage import Stage, StrategyInfo
from ...core.state import PipelineState

logger = logging.getLogger("harness.stage.publish")


class PublishStage(Stage):
    """Auto-Publish egress Stage."""

    @property
    def stage_id(self) -> str:
        return "s12_publish"

    @property
    def order(self) -> int:
        # s11_finalize (11) 직후. egress phase.
        return 12

    @property
    def phase(self) -> str:
        return "egress"

    @property
    def env_hint(self) -> str:
        return (
            "자가 증식 env — 성공한 워크플로우를 자동 compile → SandboxEnv 에 pip install → "
            "다음 요청에서 tool 로 자동 발견. Plan.auto_publish=True 일 때만 발동."
        )

    def should_bypass(self, state: PipelineState) -> bool:
        """auto_publish_mode 조건 미충족이면 bypass."""
        cfg = state.config
        mode = getattr(cfg, "auto_publish_mode", "off") or "off"
        if mode == "off":
            return True
        plan = state.metadata.get("harness_plan") or {}
        if mode == "planner_decides":
            return not bool(plan.get("auto_publish"))
        if mode == "on_score":
            score = float(getattr(state, "validation_score", 0.0) or 0.0)
            threshold = float(getattr(cfg, "auto_publish_threshold", 0.85))
            return score < threshold
        return True

    async def execute(self, state: PipelineState) -> dict:
        from ...events.types import DisclosureEvent

        wf_id = state.workflow_id or f"auto-{state.execution_id[:8]}"
        # gallery 이름 규약: auto 표시 + workflow id
        gallery_name = f"auto-{wf_id}".replace("_", "-").lower()[:60]
        gallery_version = f"0.0.{int(state.start_time) % 100000}"

        # 1. compile_workflow() — host tempfile 에 wheel 생성
        try:
            from ...compile import compile_workflow
        except Exception as e:
            logger.warning("[s12_publish] compile module 불러오기 실패: %s", e)
            return {"published": False, "reason": f"compile import failed: {e}"}

        import tempfile
        from pathlib import Path

        out_dir = Path(tempfile.mkdtemp(prefix=f"xgen-auto-{gallery_name}-"))
        try:
            result = compile_workflow(
                harness_config=state.config,
                workflow_data=state.workflow_data or {"nodes": [], "edges": []},
                gallery_name=gallery_name,
                gallery_version=gallery_version,
                description=(state.metadata.get("harness_plan") or {}).get("reasoning", "auto-published")[:200],
                out_dir=str(out_dir),
                extra_metadata={
                    "auto_published": True,
                    "workflow_id": wf_id,
                    "execution_id": state.execution_id,
                },
            )
        except Exception as e:
            logger.warning("[s12_publish] compile 실패: %s", e)
            return {"published": False, "reason": f"compile failed: {e}"}

        wheel_path = result.wheel_path
        wheel_size = wheel_path.stat().st_size if wheel_path.exists() else 0

        # 2. SandboxEnv 에 pip install
        from ...core.sandbox import SandboxEnv

        env = SandboxEnv.get_or_create(wf_id)
        try:
            env.ensure_venv()
        except Exception as e:
            logger.warning("[s12_publish] venv bootstrap 실패: %s", e)
            return {"published": False, "reason": f"venv bootstrap failed: {e}"}

        install_result = env.pip_install(str(wheel_path), timeout=300)
        if not install_result.success:
            logger.warning(
                "[s12_publish] pip install 실패: rc=%s stderr=%s",
                install_result.exit_code, install_result.stderr[:200],
            )
            await state.emit_verbose(DisclosureEvent(
                stage_id=self.stage_id,
                level=2,
                kind="gallery_publish",
                items_folded=0,
                reason=f"install failed: rc={install_result.exit_code}",
            ))
            return {
                "published": False,
                "reason": f"pip install failed: rc={install_result.exit_code}",
                "stderr_tail": install_result.stderr[-500:],
            }

        # 3. smoke — import 검증
        smoke_result = env.smoke(result.package_name)
        if not smoke_result.success:
            logger.warning(
                "[s12_publish] smoke import 실패: %s",
                smoke_result.stderr[:200],
            )
            await state.emit_verbose(DisclosureEvent(
                stage_id=self.stage_id,
                level=2,
                kind="gallery_publish",
                items_folded=0,
                reason=f"smoke failed: {smoke_result.stderr[:80]}",
            ))
            return {
                "published": False,
                "reason": "smoke import failed",
                "stderr_tail": smoke_result.stderr[-500:],
            }

        # 4. 관측 이벤트 — 성공
        await state.emit_verbose(DisclosureEvent(
            stage_id=self.stage_id,
            level=4,
            kind="gallery_publish",
            items_folded=1,
            bytes_before=0,
            bytes_after=wheel_size,
            pd_key=result.dist_name,
            reason=f"auto-published {result.dist_name}@{gallery_version}",
        ))
        logger.info(
            "[s12_publish] auto-published: dist=%s version=%s sandbox=%s",
            result.dist_name, gallery_version, env.venv_dir,
        )

        return {
            "published": True,
            "dist_name": result.dist_name,
            "package_name": result.package_name,
            "version": gallery_version,
            "wheel_size": wheel_size,
            "sandbox_venv": str(env.venv_dir),
        }

    def list_strategies(self) -> list[StrategyInfo]:
        return []  # Strategy 없음 — 단일 경로
