"""Shared CLI list-renderers.

Phase 2 step 3 — multiple subcommands (``task list``, ``inbox list``,
upcoming ``decision list`` / ``workspace`` listings) all materialise a
small set of rows and render them in one of three formats:

* ``table`` — aligned fixed-width columns for terminal eyeballing.
* ``json`` — a JSON array of row dicts, suitable for piping into ``jq``.
* ``md`` — a GitHub-flavoured Markdown table for PR descriptions and
  agent transcripts.

Rather than duplicating that pattern across every subcommand (Phase 1's
``cli/_task_list.py`` was the first implementation), this module exposes
a tiny :class:`Column` descriptor + three pure rendering functions. A
subcommand declares its columns once and calls :func:`dispatch` with the
requested format and the rows; the rendering is uniform across the CLI.

The module is intentionally dependency-light: only stdlib + ``typing``.
Each subcommand still owns its own row-fetching code (SQLAlchemy queries
talk to the projection tables), but the rendering layer no longer
re-implements column alignment / JSON serialisation / Markdown escaping
per command.

ADR-0001 cold-start discipline:

The CLI subcommand modules (``cli/task.py``, ``cli/inbox.py`` etc.) keep
their module-level imports tiny so ``opshub --help`` stays under the
300ms budget. ``_render`` lives behind the ``_`` prefix and is only
loaded via the lazy-import inside a command callback — so the helper
modules it pulls in (``json``, ``datetime``) never enter the cold-start
path. The companion test in ``tests/integration/test_cli_imports.py``
only checks public CLI modules; private helpers like this one are free
to ``import json`` at the top.
"""

from __future__ import annotations

import json
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from datetime import date, datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from opshub.services.briefings import Briefing
    from opshub.services.links import GraphSubset, Link, LinkPath
    from opshub.services.proposals import Proposal

__all__ = [
    "Column",
    "ProposalSummary",
    "dispatch",
    "format_date",
    "id_prefix",
    "render_briefing_json",
    "render_briefing_md",
    "render_graph_subset_dot",
    "render_graph_subset_json",
    "render_graph_subset_md",
    "render_json",
    "render_link_list_json",
    "render_link_list_md",
    "render_link_paths_dot",
    "render_link_paths_json",
    "render_link_paths_md",
    "render_links_dot",
    "render_md",
    "render_proposal_json",
    "render_proposal_list_json",
    "render_proposal_list_md",
    "render_proposal_md",
    "render_table",
    "truncate",
]


_ALLOWED_FORMATS = ("table", "json", "md")
_DEFAULT_ID_PREFIX_LEN = 8
_ELLIPSIS = "..."


@dataclass(frozen=True)
class Column:
    """Describes one rendered column.

    Attributes
    ----------
    header:
        Display label. Used as the table header, the Markdown header, and
        — lower-cased and underscored — as the JSON key.
    accessor:
        Callable taking the row (a mapping or arbitrary object) and
        returning the raw value for the cell. Letting the caller supply
        the access function avoids a hardcoded ``row[key]`` shape and
        lets the renderer accept dicts, dataclasses, or SQLAlchemy
        ``RowMapping`` instances interchangeably.
    width:
        Fixed display width in the ``table`` format. ``None`` means
        "auto" — the renderer falls back to ``len(header)``.
    md_align:
        Markdown column alignment hint (``"left"`` / ``"right"`` /
        ``"center"``) — controls the separator row formatting.
    json_key:
        Optional override for the JSON key. Defaults to a derived form
        of ``header`` (lower-cased, spaces → underscores).
    """

    header: str
    accessor: Callable[[Any], Any]
    width: int | None = None
    md_align: str = "left"
    json_key: str | None = None

    @property
    def effective_json_key(self) -> str:
        """Return the JSON key the column will emit.

        Defaults to ``header.lower().replace(" ", "_")`` so a column
        header of ``"Updated At"`` becomes ``"updated_at"`` — matching
        the existing ``opshub task list --format json`` shape.
        """
        if self.json_key is not None:
            return self.json_key
        return self.header.lower().replace(" ", "_")

    @property
    def effective_width(self) -> int:
        """Return the column width to use in the ``table`` format.

        ``None`` widths fall back to the header length so the table
        always has *something* to align against. Callers can still
        explicitly set a width to truncate long content.
        """
        return self.width if self.width is not None else len(self.header)


def dispatch(fmt: str, columns: Sequence[Column], rows: Sequence[Any]) -> str:
    """Render ``rows`` in ``fmt`` using ``columns``.

    Raises
    ------
    ValueError
        If ``fmt`` is not one of ``"table"``, ``"json"``, ``"md"``.
        Callers (subcommand modules) catch this and re-raise as
        :class:`opshub.core.errors.ValidationError` so the CLI exit-code
        mapping in ``cli/app.main()`` takes effect.
    """
    if fmt not in _ALLOWED_FORMATS:
        raise ValueError(f"invalid format {fmt!r}; expected one of {', '.join(_ALLOWED_FORMATS)}")
    if fmt == "json":
        return render_json(rows, columns)
    if fmt == "md":
        return render_md(rows, columns)
    return render_table(rows, columns)


def render_table(rows: Sequence[Any], columns: Sequence[Column]) -> str:
    """Render rows as an aligned fixed-width plain-text table.

    The header is always rendered (even when ``rows`` is empty) so a
    user piping into ``head`` sees the column names; this matches the
    existing ``task list`` behaviour.
    """
    header_cells = [f"{col.header.upper():<{col.effective_width}}" for col in columns]
    header_line = "  ".join(header_cells)
    if not rows:
        return header_line

    body_lines: list[str] = []
    for row in rows:
        cells: list[str] = []
        for col in columns:
            raw = col.accessor(row)
            text = _stringify(raw)
            if col.width is not None:
                text = truncate(text, col.width)
            cells.append(f"{text:<{col.effective_width}}")
        body_lines.append("  ".join(cells))
    return "\n".join([header_line, *body_lines])


def render_json(rows: Sequence[Any], columns: Sequence[Column]) -> str:
    """Render rows as a JSON array of objects keyed by column JSON-key.

    Datetime / date values are serialised via :func:`datetime.isoformat`
    so the JSON survives a ``jq`` pipe without losing tzinfo (when
    present). Everything else is passed through to :func:`json.dumps`
    which raises for un-serialisable types — that is intentional;
    callers should pick accessors that return JSON-native values.
    """
    payload: list[dict[str, Any]] = []
    for row in rows:
        payload.append({col.effective_json_key: _jsonable(col.accessor(row)) for col in columns})
    return json.dumps(payload, ensure_ascii=False)


def render_md(rows: Sequence[Any], columns: Sequence[Column]) -> str:
    """Render rows as a GitHub-flavoured Markdown table.

    The separator row encodes ``md_align`` per column:
    ``:---`` (left), ``---:`` (right), ``:---:`` (center). The base
    ``---`` form (no colon) renders as left-aligned in GitHub, so
    callers that don't care about alignment can leave ``md_align`` at
    its default and get the same look as the existing ``task list``
    renderer.
    """
    header_line = "| " + " | ".join(col.header for col in columns) + " |"
    separator_line = "| " + " | ".join(_md_separator(col) for col in columns) + " |"
    if not rows:
        return "\n".join([header_line, separator_line])

    body_lines: list[str] = []
    for row in rows:
        cells = [_escape_md(_stringify(col.accessor(row))) for col in columns]
        body_lines.append("| " + " | ".join(cells) + " |")
    return "\n".join([header_line, separator_line, *body_lines])


# ---- public helpers -------------------------------------------------------


def id_prefix(value: str, length: int = _DEFAULT_ID_PREFIX_LEN) -> str:
    """Return the first ``length`` characters of a ULID-shaped string.

    Most CLI list views render an 8-character ULID prefix — long enough
    to disambiguate within a user's working set, short enough to scan
    quickly. Exported so callers can build :class:`Column` accessors
    without re-implementing the trim.
    """
    return value[:length]


def truncate(value: str, width: int) -> str:
    """Truncate ``value`` to ``width`` characters, suffixing ``...`` if cut.

    When ``width`` is smaller than the ellipsis itself, we fall back to
    a hard slice — ``...``-ing a 2-char column would look worse than
    just clipping.
    """
    if len(value) <= width:
        return value
    if width <= len(_ELLIPSIS):
        return value[:width]
    return value[: width - len(_ELLIPSIS)] + _ELLIPSIS


def format_date(value: Any) -> str:
    """Render a datetime / date / other value as ``YYYY-MM-DD``.

    SQLite's stdlib driver may surface ``DateTime(timezone=True)`` columns
    as naive datetimes whose components reflect UTC; both naive and
    aware datetimes are accepted. Anything else (string, ``None``, ...)
    falls through to ``str(value)`` so a single bad cell never crashes
    the render path.
    """
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    return str(value)


# ---- private helpers ------------------------------------------------------


def _stringify(value: Any) -> str:
    """Coerce a cell value to a string for table / md rendering.

    Datetimes use the project-wide ``YYYY-MM-DD`` short form (full
    ISO strings are kept for the JSON path). ``None`` collapses to an
    empty string so an absent value doesn't bloat the column width.
    """
    if value is None:
        return ""
    if isinstance(value, datetime | date):
        return format_date(value)
    return str(value)


def _jsonable(value: Any) -> Any:
    """Return a JSON-serialisable representation of ``value``.

    Datetimes / dates are emitted as ISO strings (preserving precision
    and tzinfo when the source had it). Other types pass through —
    :func:`json.dumps` will raise on un-serialisable types, which is
    the right failure mode (the column accessor should be fixed, not
    the renderer).
    """
    if isinstance(value, datetime | date):
        return value.isoformat()
    return value


def _md_separator(col: Column) -> str:
    """Build the Markdown separator cell honouring ``md_align``."""
    if col.md_align == "right":
        return "---:"
    if col.md_align == "center":
        return ":---:"
    return "---"


def _escape_md(value: str) -> str:
    """Escape pipe characters so cell content doesn't break the table.

    Pipes are the column delimiter in Markdown tables; replacing them
    with an escaped form (``\\|``) keeps arbitrary user input from
    corrupting the rendered output.
    """
    return value.replace("|", "\\|")


# ---- briefing renderers (Phase 5 step B4) ---------------------------------
#
# Briefings are single-record outputs (one :class:`Briefing` instance per
# ``opshub brief`` invocation), not tabular lists, so they don't fit the
# :class:`Column` / :func:`dispatch` shape. We expose two dedicated
# helpers — :func:`render_briefing_md` (raw markdown for the eyeball
# path) and :func:`render_briefing_json` (full record dump for
# pipe-into-tooling) — keeping the brief CLI body slim and the JSON
# schema centralised here for future ``opshub brief history``
# regression tests.


def render_briefing_md(briefing: Briefing) -> str:
    """Render a :class:`Briefing` for stdout output.

    The :class:`Briefing.markdown` field already carries the
    LLM-generated body (per ADR-0015 the model is instructed to emit
    Markdown). Returning the field unchanged keeps the CLI honest —
    operators can pipe ``opshub brief "topic" > out.md`` and get a
    clean Markdown file with no extra framing.
    """
    return briefing.markdown


def render_briefing_json(briefing: Briefing) -> str:
    """Render a :class:`Briefing` as a JSON document.

    Surfaces the full record (id, topic, scope, model identifiers,
    token usage, source refs, markdown body, generated timestamp) so
    callers piping into ``jq`` can introspect the cost trace or pluck
    individual source refs. The shape mirrors
    :class:`opshub.domain.events.briefing.BriefingGenerated` so a
    follow-up Phase 5.x ``opshub brief history --format json`` can
    emit the same keys.

    ``source_refs`` is emitted as a list of
    ``{"entity_type": ..., "entity_id": ...}`` objects rather than a
    flat tuple-of-tuples, which is friendlier to most JSON consumers
    (Python is the unusual one in allowing heterogeneous tuples in
    its serialisers).

    ``ensure_ascii=False`` so a topic that survives non-ASCII content
    (e.g. CJK characters in a quoted source body) stays human-readable
    in the output.
    """
    return json.dumps(
        {
            "briefing_id": briefing.briefing_id,
            "topic": briefing.topic,
            "scope": briefing.scope,
            "model_id": briefing.model_id,
            "model_version": briefing.model_version,
            "tokens_in": briefing.tokens_in,
            "tokens_out": briefing.tokens_out,
            "source_refs": [
                {"entity_type": entity_type, "entity_id": entity_id}
                for entity_type, entity_id in briefing.source_refs
            ],
            "markdown": briefing.markdown,
            "generated_at": briefing.generated_at.isoformat(),
        },
        indent=2,
        ensure_ascii=False,
    )


# ---- proposal renderers (Phase 6 step B4) --------------------------------
#
# Proposals come in two shapes here:
#
# * The freshly generated :class:`Proposal` returned by
#   :meth:`ProposalService.generate` — a single record with full
#   ``candidates`` payload + cost trace, rendered for the
#   ``opshub propose generate`` CLI body.
# * The ``proposals`` projection rows surfaced by
#   ``opshub propose list`` — a many-row summary view. The
#   :class:`ProposalSummary` dataclass below is the CLI-local row shape;
#   it lives here rather than in :mod:`opshub.cli.propose` so the
#   renderer + the row dataclass stay co-located (mirrors the
#   ``Column`` + ``dispatch`` pairing above).


# Length of the proposal-id short prefix shown in user-facing output.
# 6 hex/Base32 characters is enough to disambiguate within an
# operator's working window without overwhelming a one-row summary
# (mirrors the convention used by `git log --oneline`).
_PROPOSAL_ID_SHORT_LEN = 6
_PROPOSAL_TOPIC_TRUNCATE = 40
_CANDIDATE_BODY_TRUNCATE = 200


@dataclass(frozen=True)
class ProposalSummary:
    """One row of the ``opshub propose list`` view.

    The CLI builds these from a SELECT against the ``proposals``
    projection (``id`` / ``topic`` / ``candidate_states`` /
    ``generated_at``); the renderer below knows how to flatten the
    parallel ``candidate_states`` list into the ``Np/Mp/Kr`` summary
    cell. Kept here rather than on the projection module so the
    projection layer stays purely data-shape (no CLI concerns).
    """

    proposal_id: str
    topic: str
    candidate_states: list[str]
    generated_at: datetime | None


def render_proposal_md(proposal: Proposal) -> str:
    """Render a freshly generated :class:`Proposal` for stdout (markdown).

    The output is hand-formatted (not via :func:`dispatch`) because the
    candidates are heterogeneous: a task candidate has ``title`` /
    ``body``, a decision candidate has ``text`` / ``context``. The
    rendered shape is designed for an agent that needs to pick a next
    action without re-querying — the proposal id and per-candidate
    index appear verbatim so the operator can paste them straight into
    ``opshub propose apply <id> <index>``.

    The trailing usage hint mentions both ``apply`` and ``reject`` so
    a first-time user discovers both lifecycle verbs from the help
    output alone.
    """
    lines: list[str] = [
        f'# Proposals for "{proposal.topic}"',
        "",
        f"Proposal: {proposal.proposal_id}",
        (
            f"Model: {proposal.model_id} "
            f"(in: {proposal.tokens_in} tokens, out: {proposal.tokens_out} tokens)"
        ),
        f"Generated: {proposal.generated_at.isoformat()}",
    ]
    if proposal.briefing_id is not None:
        lines.append(f"Briefing: {proposal.briefing_id}")
    if proposal.scope and proposal.scope != "all":
        lines.append(f"Scope: {proposal.scope}")
    lines.append("")

    for index, candidate in enumerate(proposal.candidates):
        kind = getattr(candidate, "kind", "?")
        if kind == "task":
            title = getattr(candidate, "title", "")
            body = getattr(candidate, "body", None)
            lines.append(f"[{index}] task: {title}")
            if body is not None and str(body).strip():
                truncated = truncate(str(body), _CANDIDATE_BODY_TRUNCATE)
                lines.append(f"    body: {truncated}")
        elif kind == "decision":
            text = getattr(candidate, "text", "")
            context = getattr(candidate, "context", None)
            truncated_text = truncate(str(text), _CANDIDATE_BODY_TRUNCATE)
            lines.append(f"[{index}] decision: {truncated_text}")
            if context is not None and str(context).strip():
                truncated_context = truncate(str(context), _CANDIDATE_BODY_TRUNCATE)
                lines.append(f"    context: {truncated_context}")
        else:
            # Phase 6.x candidate kinds (e.g. inbox_item / source) land
            # here; the renderer falls back to a JSON dump of the
            # payload so an unexpected kind is still legible.
            lines.append(f"[{index}] {kind}: {candidate!r}")

    lines.extend(
        [
            "",
            f"To apply:  opshub propose apply {proposal.proposal_id} <index>",
            (f"To reject: opshub propose reject {proposal.proposal_id} <index> [--reason ...]"),
        ]
    )
    return "\n".join(lines)


def render_proposal_json(proposal: Proposal) -> str:
    """Render a freshly generated :class:`Proposal` as a JSON document.

    Surfaces the full record (id, topic, scope, optional briefing
    link, model identifiers, token usage, candidate list, generated
    timestamp) so callers piping into ``jq`` can introspect the cost
    trace or extract a specific candidate body. Each candidate is
    rendered as the dict produced by
    :meth:`pydantic.BaseModel.model_dump` so the ``kind`` /
    ``schema_version`` discriminators survive the JSON round-trip
    (ADR-0016 §決定 (f)).

    ``ensure_ascii=False`` so a CJK topic / candidate body stays
    human-readable in the output.
    """
    candidates_payload: list[Any] = []
    for candidate in proposal.candidates:
        # All current candidate types are Pydantic v2 models; fall back
        # to a best-effort string cast for any future non-Pydantic
        # candidate shape so the renderer never raises on the JSON
        # path.
        dump = getattr(candidate, "model_dump", None)
        if callable(dump):
            candidates_payload.append(dump(mode="json"))
        else:
            candidates_payload.append(str(candidate))
    return json.dumps(
        {
            "proposal_id": proposal.proposal_id,
            "topic": proposal.topic,
            "scope": proposal.scope,
            "briefing_id": proposal.briefing_id,
            "model_id": proposal.model_id,
            "model_version": proposal.model_version,
            "tokens_in": proposal.tokens_in,
            "tokens_out": proposal.tokens_out,
            "candidates": candidates_payload,
            "generated_at": proposal.generated_at.isoformat(),
        },
        indent=2,
        ensure_ascii=False,
    )


def render_proposal_list_md(rows: Sequence[ProposalSummary]) -> str:
    """Render a list of :class:`ProposalSummary` rows as a Markdown table.

    Each row is one proposal. The ``Candidates`` column collapses the
    parallel ``candidate_states`` list into a single ``Np/Ma/Kr`` cell
    (pending / applied / rejected counts) so an operator scanning the
    table can spot proposals that still have actionable candidates
    without expanding every row.

    The renderer uses :func:`dispatch` with ``fmt="md"`` so the
    output uses the GitHub-flavoured Markdown table shape that every
    other ``list`` view emits.
    """
    columns = _proposal_summary_columns()
    return dispatch("md", columns, list(rows))


def render_proposal_list_json(rows: Sequence[ProposalSummary]) -> str:
    """Render a list of :class:`ProposalSummary` rows as a JSON array.

    The shape matches the Markdown columns (id prefix, full topic,
    per-state counts, generated_at ISO string) plus the full
    ``candidate_states`` list so a ``jq`` consumer can re-derive the
    breakdown. The proposal id is emitted in full (not the short
    prefix) because the JSON path is the machine-readable surface.
    """
    payload: list[dict[str, Any]] = []
    for row in rows:
        counts = _candidate_state_counts(row.candidate_states)
        payload.append(
            {
                "proposal_id": row.proposal_id,
                "topic": row.topic,
                "candidate_count": len(row.candidate_states),
                "states": counts,
                "candidate_states": list(row.candidate_states),
                "generated_at": (
                    row.generated_at.isoformat() if row.generated_at is not None else None
                ),
            }
        )
    return json.dumps(payload, indent=2, ensure_ascii=False)


def _proposal_summary_columns() -> list[Column]:
    """Column descriptors for the ``opshub propose list`` Markdown view.

    Kept as a function (not a module-level constant) so the dataclass
    field accessors are constructed lazily — the dataclass forward
    ref :class:`ProposalSummary` is fully defined by the time the
    function is called.
    """
    return [
        Column(
            header="ID",
            accessor=lambda row: id_prefix(row.proposal_id, _PROPOSAL_ID_SHORT_LEN),
            width=_PROPOSAL_ID_SHORT_LEN,
            json_key="proposal_id",
        ),
        Column(
            header="Topic",
            accessor=lambda row: truncate(row.topic, _PROPOSAL_TOPIC_TRUNCATE),
            width=_PROPOSAL_TOPIC_TRUNCATE,
            json_key="topic",
        ),
        Column(
            header="Candidates",
            accessor=lambda row: _format_candidate_states(row.candidate_states),
            width=12,
            json_key="states",
        ),
        Column(
            header="Generated",
            accessor=lambda row: format_date(row.generated_at),
            width=10,
            json_key="generated_at",
        ),
    ]


def _format_candidate_states(states: list[str]) -> str:
    """Render the candidate-state breakdown as ``Np/Ma/Kr``.

    A proposal with 2 pending / 1 applied / 0 rejected candidates
    renders as ``2p/1a/0r`` — the trailing letter is the first
    character of each state name so the cell stays compact.
    """
    counts = _candidate_state_counts(states)
    return f"{counts['pending']}p/{counts['applied']}a/{counts['rejected']}r"


def _candidate_state_counts(states: list[str]) -> dict[str, int]:
    """Tally candidate states; unknown state labels collapse silently.

    Used by both the Markdown column accessor and the JSON renderer
    so the counts are computed from a single code path.
    """
    counts = {"pending": 0, "applied": 0, "rejected": 0}
    for state in states:
        if state in counts:
            counts[state] += 1
    return counts


# ---- link renderers (Phase 8 step D1) -------------------------------------
#
# The link CLI surface (``opshub link list``, ``opshub graph related /
# trace``) emits three shapes:
#
# * Flat link list — one :class:`Link` per row, rendered as a Markdown
#   table, JSON array, or Graphviz DOT digraph.
# * Path list — :class:`LinkPath` chains from :meth:`LinkService.trace`,
#   rendered as a Markdown bullet list of ``A -> B -> C (type)``
#   chains, a JSON array of path objects, or a DOT digraph that
#   unions every edge across every path.
#
# DOT escaping: entity ids and types are surrounded with double quotes
# and any embedded quote / backslash is escaped per the Graphviz DOT
# spec so a malformed-but-not-malicious id (e.g. an early connector
# that emits a quote in its id string) still produces a parseable
# document.


_LINK_ID_SHORT_LEN = 8


def _format_link_endpoint(entity_type: str, entity_id: str) -> str:
    """Return ``"<type>:<id>"`` for human-readable link rendering."""
    return f"{entity_type}:{entity_id}"


def _escape_dot(value: str) -> str:
    """Escape a string for inclusion as a DOT node id or label.

    Graphviz DOT uses double-quoted strings for node ids; inside that
    string a literal ``"`` must be backslash-escaped and a literal
    ``\\`` doubled. Newlines collapse to ``\\n`` so a label that
    accidentally contains one does not break the digraph file. The
    output does NOT include the surrounding quotes — callers add
    those so the same helper handles both node ids and edge labels.
    """
    return value.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")


def _quote_dot(value: str) -> str:
    """Return ``value`` wrapped in DOT-safe double quotes."""
    return f'"{_escape_dot(value)}"'


def render_link_list_md(links: Sequence[Link]) -> str:
    """Render a list of :class:`Link` rows as a GitHub-flavoured Markdown table.

    Columns: short id prefix (8 chars), from endpoint, to endpoint,
    link_type, created_at date. The header is always rendered so a
    user piping into ``head`` sees the labels even when the result
    set is empty.
    """
    columns = [
        Column(
            header="ID",
            accessor=lambda row: id_prefix(row.id, _LINK_ID_SHORT_LEN),
            width=_LINK_ID_SHORT_LEN,
            json_key="id",
        ),
        Column(
            header="From",
            accessor=lambda row: _format_link_endpoint(row.from_entity_type, row.from_entity_id),
            json_key="from",
        ),
        Column(
            header="To",
            accessor=lambda row: _format_link_endpoint(row.to_entity_type, row.to_entity_id),
            json_key="to",
        ),
        Column(
            header="Type",
            accessor=lambda row: row.link_type,
            json_key="link_type",
        ),
        Column(
            header="Created",
            accessor=lambda row: format_date(row.created_at),
            width=10,
            json_key="created_at",
        ),
    ]
    return dispatch("md", columns, list(links))


def render_link_list_json(links: Sequence[Link]) -> str:
    """Render a list of :class:`Link` rows as a JSON array.

    Each entry surfaces the full link record (id, from + to endpoints,
    link_type, created_at ISO timestamp, source_event_id, metadata
    dict). The shape mirrors the :class:`Link` dataclass so a
    follow-up ``opshub link list --format json`` regression test can
    pin the keys.
    """
    payload: list[dict[str, Any]] = []
    for link in links:
        payload.append(
            {
                "id": link.id,
                "from_entity_type": link.from_entity_type,
                "from_entity_id": link.from_entity_id,
                "to_entity_type": link.to_entity_type,
                "to_entity_id": link.to_entity_id,
                "link_type": link.link_type,
                "created_at": link.created_at.isoformat(),
                "source_event_id": link.source_event_id,
                "metadata": link.metadata,
            }
        )
    return json.dumps(payload, indent=2, ensure_ascii=False)


def render_links_dot(
    links: Sequence[Link],
    *,
    focus: tuple[str, str] | None = None,
) -> str:
    """Render a list of :class:`Link` rows as a Graphviz DOT digraph.

    ``focus`` (optional) identifies the central entity of the query
    so the renderer can place a ``[shape=box]`` style hint on that
    node — useful when piping into ``dot -Tpng`` for a quick visual
    check of who is connected to the queried entity. When ``focus``
    is omitted (or the focused entity has no edges), the digraph is
    just the union of every edge in ``links``.

    Each edge carries a ``label="<link_type>"`` attribute so the
    rendered image shows the relationship verb. Endpoint ids are
    DOT-escaped (see :func:`_escape_dot`) so arbitrary ULIDs /
    connector ids survive the format unchanged.
    """
    lines: list[str] = ["digraph opshub_graph {"]
    lines.append('  node [shape="ellipse"];')

    seen_nodes: set[str] = set()

    def _emit_node(entity_type: str, entity_id: str) -> str:
        key = _format_link_endpoint(entity_type, entity_id)
        if key not in seen_nodes:
            seen_nodes.add(key)
            shape = ""
            if focus is not None and (entity_type, entity_id) == focus:
                shape = ' [shape="box"]'
            lines.append(f"  {_quote_dot(key)}{shape};")
        return key

    for link in links:
        from_node = _emit_node(link.from_entity_type, link.from_entity_id)
        to_node = _emit_node(link.to_entity_type, link.to_entity_id)
        lines.append(
            f"  {_quote_dot(from_node)} -> {_quote_dot(to_node)}"
            f" [label={_quote_dot(link.link_type)}];"
        )

    # Always emit the focus node when supplied, even if it has no
    # incident edges in ``links`` — gives the operator a visible
    # confirmation that the query targeted the right entity.
    if focus is not None:
        _emit_node(focus[0], focus[1])

    lines.append("}")
    return "\n".join(lines)


def render_link_paths_md(
    paths: Sequence[LinkPath],
    *,
    focus: tuple[str, str] | None = None,
) -> str:
    """Render :class:`LinkPath` chains as a Markdown bullet list.

    Each path is shown as a chain ``A -> B -> C (type1, type2)`` so
    the operator can scan provenance at a glance. ``focus`` (the
    query root) appears as the right-most node since :meth:`trace`
    returns paths ordered nearest-to-root → farthest. When ``paths``
    is empty, the renderer emits a single informational line so the
    operator sees that the query ran (not silent stdout).
    """
    if not paths:
        focus_repr = _format_link_endpoint(focus[0], focus[1]) if focus is not None else "<entity>"
        return f"No incoming links found for {focus_repr}."

    lines: list[str] = []
    if focus is not None:
        lines.append(f"# Trace for {_format_link_endpoint(focus[0], focus[1])}")
        lines.append("")
    for index, path in enumerate(paths):
        # Walk the path nearest-root → farthest, so the root is the
        # right-hand endpoint in our rendered chain.
        if focus is not None:
            current_endpoint = _format_link_endpoint(focus[0], focus[1])
        else:
            # Fallback: derive the root from the first link's ``to_*``.
            first = path.links[0]
            current_endpoint = _format_link_endpoint(first.to_entity_type, first.to_entity_id)
        chain_segments: list[str] = [current_endpoint]
        type_segments: list[str] = []
        for link in path.links:
            upstream = _format_link_endpoint(link.from_entity_type, link.from_entity_id)
            chain_segments.append(upstream)
            type_segments.append(link.link_type)
        # Render upstream → ... → root for natural reading order.
        chain = " <- ".join(chain_segments)
        types = ", ".join(type_segments)
        lines.append(f"- [{index}] depth={path.depth}: {chain} ({types})")
    return "\n".join(lines)


def render_link_paths_json(paths: Sequence[LinkPath]) -> str:
    """Render :class:`LinkPath` chains as a JSON array.

    Each path becomes an object with ``depth`` plus an ordered
    ``links`` list of link records (same shape as
    :func:`render_link_list_json`). The renderer preserves the
    nearest-root → farthest order from :meth:`LinkService.trace`.
    """
    payload: list[dict[str, Any]] = []
    for path in paths:
        link_payloads: list[dict[str, Any]] = []
        for link in path.links:
            link_payloads.append(
                {
                    "id": link.id,
                    "from_entity_type": link.from_entity_type,
                    "from_entity_id": link.from_entity_id,
                    "to_entity_type": link.to_entity_type,
                    "to_entity_id": link.to_entity_id,
                    "link_type": link.link_type,
                    "created_at": link.created_at.isoformat(),
                    "source_event_id": link.source_event_id,
                    "metadata": link.metadata,
                }
            )
        payload.append({"depth": path.depth, "links": link_payloads})
    return json.dumps(payload, indent=2, ensure_ascii=False)


def render_link_paths_dot(
    paths: Sequence[LinkPath],
    *,
    focus: tuple[str, str] | None = None,
) -> str:
    """Render :class:`LinkPath` chains as a Graphviz DOT digraph.

    The renderer unions every edge across every path into a single
    digraph; duplicate ``(from, to, link_type)`` triples collapse to
    one edge so a diamond graph does not double-render its shared
    sub-edges. ``focus`` is highlighted via :func:`render_links_dot`'s
    convention (``shape="box"`` on the query root).
    """
    # Flatten paths into a unique-edge list and reuse the link-list
    # DOT renderer so the two graph paths share one codebase. Edge
    # deduplication keys on ``(from, to, link_type)`` because two
    # paths through the same node pair via the same link_type are
    # visually indistinguishable.
    seen: set[tuple[str, str, str, str, str]] = set()
    flattened: list[Link] = []
    for path in paths:
        for link in path.links:
            key = (
                link.from_entity_type,
                link.from_entity_id,
                link.to_entity_type,
                link.to_entity_id,
                link.link_type,
            )
            if key in seen:
                continue
            seen.add(key)
            flattened.append(link)
    return render_links_dot(flattened, focus=focus)


# ---- graph subset renderers (Phase 8 step D2) ----------------------------
#
# :meth:`LinkService.expand` returns a :class:`GraphSubset` carrying
# the root entity, a frozenset of reachable nodes, the tuple of
# deduplicated edges between those nodes, and the applied depth limit.
# ``opshub graph expand`` ships three rendering formats; each helper
# below is shaped to match the equivalent ``graph related`` / ``graph
# trace`` renderer so operators see consistent output across the three
# verbs.


def render_graph_subset_md(subset: GraphSubset) -> str:
    """Render a :class:`GraphSubset` as Markdown: nodes table + edges list.

    The output is two sections: a "Nodes" Markdown table (one row per
    reachable entity, columns ``Type`` / ``Id`` / ``Role`` where
    ``Role`` flags the root with ``"root"``) and an "Edges" bullet
    list (one bullet per :class:`Link`, formatted as
    ``from -> to (link_type)``). When ``subset.edges`` is empty, the
    Edges section is replaced with a single informational line so the
    operator sees that the query ran even when the root has no links.

    The nodes table sorts by ``(entity_type, entity_id)`` so the
    output is deterministic across runs — :class:`GraphSubset.nodes`
    is a frozenset whose iteration order is hash-dependent and would
    otherwise flap between invocations.
    """
    root_type, root_id = subset.root
    sorted_nodes = sorted(subset.nodes)

    root_endpoint = _format_link_endpoint(root_type, root_id)
    header = f"# Graph expansion of {root_endpoint} (depth={subset.depth})"
    nodes_lines: list[str] = [
        header,
        "",
        "## Nodes",
        "",
        "| Type | Id | Role |",
        "| --- | --- | --- |",
    ]
    for entity_type, entity_id in sorted_nodes:
        role = "root" if (entity_type, entity_id) == subset.root else ""
        nodes_lines.append(f"| {entity_type} | {entity_id} | {role} |")

    edges_lines: list[str] = ["", "## Edges", ""]
    if not subset.edges:
        edges_lines.append("_No edges in the expansion._")
    else:
        for link in subset.edges:
            from_endpoint = _format_link_endpoint(link.from_entity_type, link.from_entity_id)
            to_endpoint = _format_link_endpoint(link.to_entity_type, link.to_entity_id)
            edges_lines.append(f"- {from_endpoint} -> {to_endpoint} ({link.link_type})")

    return "\n".join([*nodes_lines, *edges_lines])


def render_graph_subset_json(subset: GraphSubset) -> str:
    """Render a :class:`GraphSubset` as a JSON document.

    Surfaces the root tuple, sorted nodes list, edge list (full link
    records — same shape as :func:`render_link_list_json`), and the
    applied depth. Nodes are sorted by ``(entity_type, entity_id)``
    so the JSON payload is deterministic across runs (matching the
    Markdown renderer's ordering contract).

    ``ensure_ascii=False`` so non-ASCII entity ids (rare, but possible
    for ``inbox_item`` / ``source`` ids derived from connector data)
    survive the round-trip readably.
    """
    sorted_nodes = sorted(subset.nodes)
    edges_payload: list[dict[str, Any]] = []
    for link in subset.edges:
        edges_payload.append(
            {
                "id": link.id,
                "from_entity_type": link.from_entity_type,
                "from_entity_id": link.from_entity_id,
                "to_entity_type": link.to_entity_type,
                "to_entity_id": link.to_entity_id,
                "link_type": link.link_type,
                "created_at": link.created_at.isoformat(),
                "source_event_id": link.source_event_id,
                "metadata": link.metadata,
            }
        )
    payload = {
        "root": {"entity_type": subset.root[0], "entity_id": subset.root[1]},
        "depth": subset.depth,
        "nodes": [
            {"entity_type": entity_type, "entity_id": entity_id}
            for entity_type, entity_id in sorted_nodes
        ],
        "edges": edges_payload,
    }
    return json.dumps(payload, indent=2, ensure_ascii=False)


def render_graph_subset_dot(subset: GraphSubset) -> str:
    """Render a :class:`GraphSubset` as a Graphviz DOT digraph.

    Reuses the :func:`render_links_dot` helper for edge / node
    rendering so the DOT shape (``shape="ellipse"`` nodes,
    ``shape="box"`` for the root, ``label="<link_type>"`` on each
    edge, backslash-escaped quoted ids) stays consistent with
    ``graph related`` / ``graph trace``. Any node reachable from the
    root that has no incident edge in ``subset.edges`` is still
    emitted as a bare node so the operator sees the full reachable
    set in the rendered graph.
    """
    rendered = render_links_dot(list(subset.edges), focus=subset.root)
    # Inject any isolated nodes (reachable but no incident edge in
    # the expansion result). ``render_links_dot`` only emits nodes it
    # sees on an edge endpoint, so we walk the subset nodes set and
    # add bare-node lines before the closing brace for any node not
    # already present in the rendered output.
    emitted_nodes: set[tuple[str, str]] = set()
    for link in subset.edges:
        emitted_nodes.add((link.from_entity_type, link.from_entity_id))
        emitted_nodes.add((link.to_entity_type, link.to_entity_id))
    # The root is always added by ``render_links_dot(focus=...)`` so
    # we don't need to re-emit it here even when ``edges`` is empty.
    emitted_nodes.add(subset.root)

    missing = sorted(subset.nodes - emitted_nodes)
    if not missing:
        return rendered

    # Splice the missing-node lines just before the closing brace so
    # the DOT file stays well-formed.
    lines = rendered.split("\n")
    assert lines[-1] == "}"
    extra_lines: list[str] = []
    for entity_type, entity_id in missing:
        key = _format_link_endpoint(entity_type, entity_id)
        extra_lines.append(f"  {_quote_dot(key)};")
    return "\n".join([*lines[:-1], *extra_lines, lines[-1]])
