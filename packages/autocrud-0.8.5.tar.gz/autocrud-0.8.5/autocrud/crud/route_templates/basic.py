"""Route template protocol and shared error helpers.

This module hosts the foundation that every route template builds on:

* :class:`IRouteTemplate` — the abstract route template interface.
* :class:`BaseRouteTemplate` — concrete base providing dependency wiring
  and an ``order`` for stable application order.
* :func:`raise_unique_conflict` — converts a
  :class:`UniqueConstraintError` into an HTTP 409 response.

For backward compatibility, this module also re-exports the helpers that
historically lived here:

* :class:`DependencyProvider` from
  :mod:`autocrud.crud.route_templates.dependency_provider`.
* Response types and JSON-schema helpers from
  :mod:`autocrud.crud.route_templates.responses`.
* Query parameter parsing from
  :mod:`autocrud.crud.route_templates.query_inputs`.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TypeVar

from fastapi import APIRouter, HTTPException

from autocrud.crud.route_templates.dependency_provider import DependencyProvider
from autocrud.crud.route_templates.query_inputs import (
    QueryInputs,
    QueryInputsWithReturns,
    build_query,
    get_partial_fields,
)
from autocrud.crud.route_templates.responses import (
    FullResourceResponse,
    JsonListResponse,
    MsgspecResponse,
    RevisionListResponse,
    _sanitize_schema_names,
    jsonschema_to_json_schema_extra,
    jsonschema_to_openapi,
    struct_to_responses_type,
)
from autocrud.types import (
    IResourceManager,
    UniqueConstraintError,
)

__all__ = [
    "BaseRouteTemplate",
    "DependencyProvider",
    "FullResourceResponse",
    "IRouteTemplate",
    "JsonListResponse",
    "MsgspecResponse",
    "QueryInputs",
    "QueryInputsWithReturns",
    "RevisionListResponse",
    "_sanitize_schema_names",
    "build_query",
    "get_partial_fields",
    "jsonschema_to_json_schema_extra",
    "jsonschema_to_openapi",
    "raise_unique_conflict",
    "struct_to_responses_type",
]

T = TypeVar("T")


def raise_unique_conflict(e: UniqueConstraintError) -> None:
    """Convert a :class:`UniqueConstraintError` into an HTTP 409 response."""
    raise HTTPException(
        status_code=409,
        detail={
            "message": str(e),
            "field": e.field,
            "conflicting_resource_id": e.conflicting_resource_id,
        },
    )


class IRouteTemplate(ABC):
    """路由模板基類，定義如何為資源生成單一 API 路由"""

    @abstractmethod
    def apply(
        self,
        model_name: str,
        resource_manager: IResourceManager[T],
        router: APIRouter,
    ) -> None:
        """將路由模板應用到指定的資源管理器和路由器

        Args:
            model_name: 模型名稱
            resource_manager: 資源管理器
            router: FastAPI 路由器
        """

    @property
    @abstractmethod
    def order(self) -> int:
        """獲取路由模板的排序權重"""


class BaseRouteTemplate(IRouteTemplate):
    def __init__(
        self,
        dependency_provider: DependencyProvider = None,
        order: int = 100,
    ):
        """初始化路由模板

        Args:
            dependency_provider: 依賴提供者，如果為 None 則創建預設的
        """
        self.deps = dependency_provider or DependencyProvider()
        self._order = order

    @property
    def order(self) -> int:
        return self._order

    def __lt__(self, other: IRouteTemplate):
        return self.order < other.order

    def __le__(self, other: IRouteTemplate):
        return self.order <= other.order
