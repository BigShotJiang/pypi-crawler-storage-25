#!/usr/bin/env python3
"""
Terminal MCP Server
-------------------
An agent-capable MCP server with terminal access, filesystem control,
and persistent memory.

Tools:
  Terminal:
    - run_command   : Execute shell commands (full ROOT_DIR)
    - read_file     : Read files (allowed dirs only)
    - write_file    : Write files (allowed dirs only)
    - list_files    : List directories (full ROOT_DIR)
    - run_workflow   : Named workflows (npm, python, shell)

  Memory:
    - memory_store  : Save a memory (user, feedback, project, reference, note)
    - memory_recall : Retrieve a specific memory by name
    - memory_search : Search memories by keyword and/or type
    - memory_delete : Delete a memory
    - memory_list   : List all stored memories

Environment variables:
  TERMINAL_MCP_ROOT        Base directory (default: $HOME)
  TERMINAL_MCP_PLAYGROUND  Playground subdirectory name (default: claude_playground)
  TERMINAL_MCP_SHELL       Shell to use (default: /bin/zsh on macOS, /bin/bash otherwise)
  TERMINAL_MCP_TIMEOUT     Default command timeout in seconds (default: 30)
"""

from __future__ import annotations

import asyncio
import json
import os
import platform
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import CallToolResult, TextContent, Tool

from terminal_mcp.memory import MemoryStore

# ── Config ───────────────────────────────────────────────────────────────────

ROOT_DIR = Path(
    os.environ.get("TERMINAL_MCP_ROOT", os.environ.get("HOME", "/tmp"))
).resolve()

PLAYGROUND_NAME = os.environ.get("TERMINAL_MCP_PLAYGROUND", "claude_playground")
PLAYGROUND_DIR = ROOT_DIR / PLAYGROUND_NAME
ACCESS_FILE = PLAYGROUND_DIR / "path.txt"
LOG_FILE = PLAYGROUND_DIR / "terminal.log"
MEMORY_DIR = PLAYGROUND_DIR / "memory"

DEFAULT_SHELL = "/bin/zsh" if platform.system() == "Darwin" else "/bin/bash"
SHELL = os.environ.get("TERMINAL_MCP_SHELL", DEFAULT_SHELL)
DEFAULT_TIMEOUT = int(os.environ.get("TERMINAL_MCP_TIMEOUT", "30"))

BLOCKED_PATTERNS: list[re.Pattern] = [
    re.compile(r"\brm\s+-rf\s+/\b"),
    re.compile(r"\bmkfs\b"),
    re.compile(r"\bdd\s+.*of=/dev"),
    re.compile(r":\(\)\{.*\}"),
]

# ── Memory store instance ────────────────────────────────────────────────────

memory = MemoryStore(MEMORY_DIR)

# ── Logger ───────────────────────────────────────────────────────────────────


def log(level: str, message: str) -> None:
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] [{level.upper()}] {message}"
    print(line, file=sys.stderr, flush=True)
    try:
        LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        with LOG_FILE.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


# ── Access control ───────────────────────────────────────────────────────────


def load_allowed_paths() -> list[Path]:
    """
    Read the access file and return resolved allowed directories.
    Re-read every call so edits take effect without restart.
    PLAYGROUND_DIR is always included.
    """
    allowed = [PLAYGROUND_DIR]
    if not ACCESS_FILE.exists():
        return allowed
    for raw_line in ACCESS_FILE.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        p = Path(line).resolve()
        if p not in allowed:
            allowed.append(p)
    return allowed


def is_path_allowed(target: Path, allowed: list[Path]) -> bool:
    """Check if target is inside (or equal to) any allowed directory."""
    target_str = str(target)
    return any(target_str == str(a) or target_str.startswith(str(a) + os.sep) for a in allowed)


def is_command_safe(cmd: str) -> bool:
    return not any(p.search(cmd) for p in BLOCKED_PATTERNS)


# ── Path resolution ─────────────────────────────────────────────────────────


def resolve_readwrite(path_str: str) -> Path:
    """Resolve a path and verify it falls within allowed directories."""
    p = Path(path_str)
    abs_path = p.resolve() if p.is_absolute() else (ROOT_DIR / path_str).resolve()

    allowed = load_allowed_paths()
    if not is_path_allowed(abs_path, allowed):
        allowed_list = "\n  ".join(str(a) for a in allowed)
        raise PermissionError(
            f'Access denied: "{path_str}" is not inside any allowed path.\n'
            f"Allowed paths:\n  {allowed_list}\n"
            f"Add the path to {ACCESS_FILE} to grant access."
        )
    return abs_path


def resolve_within_root(rel_path: str) -> Path:
    """Resolve relative to ROOT_DIR; must stay inside ROOT_DIR."""
    abs_path = (ROOT_DIR / rel_path).resolve()
    if not (str(abs_path) == str(ROOT_DIR) or str(abs_path).startswith(str(ROOT_DIR) + os.sep)):
        raise PermissionError(f'Path "{rel_path}" escapes ROOT_DIR ({ROOT_DIR})')
    return abs_path


# ── Shell execution ──────────────────────────────────────────────────────────


async def run_shell(cmd: str, cwd: Path, timeout: int = DEFAULT_TIMEOUT) -> tuple[str, str]:
    proc = await asyncio.create_subprocess_shell(
        cmd,
        cwd=str(cwd),
        executable=SHELL,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout_b, stderr_b = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    return stdout_b.decode(errors="replace"), stderr_b.decode(errors="replace")


def format_output(cmd: str | None, stdout: str, stderr: str) -> str:
    parts: list[str] = []
    if cmd:
        parts.append(f"> {cmd}")
    if stdout.strip():
        parts.append(f"STDOUT:\n{stdout.strip()}")
    if stderr.strip():
        parts.append(f"STDERR:\n{stderr.strip()}")
    if not stdout.strip() and not stderr.strip():
        parts.append("(no output)")
    return "\n\n".join(parts)


# ── Result helpers ───────────────────────────────────────────────────────────


def _ok(text: str) -> CallToolResult:
    return CallToolResult(content=[TextContent(type="text", text=str(text))])


def _err(msg: str) -> CallToolResult:
    log("blocked", msg)
    return CallToolResult(content=[TextContent(type="text", text=f"Error: {msg}")], isError=True)


# ── Tool definitions ─────────────────────────────────────────────────────────

MEMORY_TYPE_ENUM = ["user", "feedback", "project", "reference", "note"]


def _build_terminal_tools(allowed_display: str) -> list[Tool]:
    return [
        Tool(
            name="run_command",
            description=(
                "Run a shell command. "
                "Working directory defaults to ROOT_DIR unless `cwd` is given."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "Shell command to execute"},
                    "cwd": {"type": "string", "description": "Working directory relative to ROOT_DIR (optional)"},
                    "timeout_seconds": {"type": "number", "description": f"Timeout in seconds (default {DEFAULT_TIMEOUT})"},
                },
                "required": ["command"],
            },
        ),
        Tool(
            name="read_file",
            description=(
                f"Read a file's contents. "
                f"Allowed paths: {allowed_display}. "
                f"Add more via {ACCESS_FILE}."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Absolute path or relative to ROOT_DIR"},
                },
                "required": ["path"],
            },
        ),
        Tool(
            name="write_file",
            description=(
                f"Write or overwrite a file (parent dirs auto-created). "
                f"Allowed paths: {allowed_display}. "
                f"Add more via {ACCESS_FILE}."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Absolute path or relative to ROOT_DIR"},
                    "content": {"type": "string", "description": "Text content to write"},
                },
                "required": ["path", "content"],
            },
        ),
        Tool(
            name="list_files",
            description="List files and folders in a directory (relative to ROOT_DIR).",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Directory path relative to ROOT_DIR (defaults to root)"},
                    "recursive": {"type": "boolean", "description": "List recursively, skipping hidden files (default false)"},
                },
            },
        ),
        Tool(
            name="run_workflow",
            description="Run a named workflow: npm_install, npm_run, python_run, or shell_script.",
            inputSchema={
                "type": "object",
                "properties": {
                    "workflow": {
                        "type": "string",
                        "enum": ["npm_install", "npm_run", "python_run", "shell_script"],
                        "description": "Workflow type",
                    },
                    "args": {
                        "type": "object",
                        "description": (
                            "Workflow arguments:\n"
                            "  npm_run      -> { script: str }\n"
                            "  python_run   -> { file: str, args?: str }\n"
                            "  shell_script -> { script_path: str, args?: str }"
                        ),
                    },
                    "cwd": {"type": "string", "description": "Working directory relative to ROOT_DIR (optional)"},
                },
                "required": ["workflow"],
            },
        ),
    ]


def _build_memory_tools() -> list[Tool]:
    return [
        Tool(
            name="memory_store",
            description=(
                "Store a persistent memory. Memories survive across conversations. "
                "Types: user (about the user), feedback (how to work), "
                "project (ongoing work context), reference (external pointers), "
                "note (general). If a memory with the same name exists, it is updated."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Short, descriptive name for the memory (used as identifier)",
                    },
                    "content": {
                        "type": "string",
                        "description": "The memory content. For feedback/project types, structure as: rule/fact, then Why: and How to apply: lines",
                    },
                    "type": {
                        "type": "string",
                        "enum": MEMORY_TYPE_ENUM,
                        "description": "Memory category (default: note)",
                    },
                    "tags": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Optional tags for searchability",
                    },
                },
                "required": ["name", "content"],
            },
        ),
        Tool(
            name="memory_recall",
            description=(
                "Retrieve a specific memory by name. "
                "Returns the full content, metadata, and file path."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "Name of the memory to recall"},
                },
                "required": ["name"],
            },
        ),
        Tool(
            name="memory_search",
            description=(
                "Search across all memories by keyword. "
                "Searches name, tags, and content. Optionally filter by type."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Search keyword or phrase"},
                    "type": {
                        "type": "string",
                        "enum": MEMORY_TYPE_ENUM,
                        "description": "Filter by memory type (optional)",
                    },
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="memory_delete",
            description="Delete a memory by name.",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "Name of the memory to delete"},
                },
                "required": ["name"],
            },
        ),
        Tool(
            name="memory_list",
            description=(
                "List all stored memories. Returns the MEMORY.md index "
                "grouped by type with names, links, and descriptions."
            ),
            inputSchema={"type": "object", "properties": {}},
        ),
    ]


# ── Tool handlers ────────────────────────────────────────────────────────────


async def _handle_terminal(name: str, arguments: dict[str, Any]) -> CallToolResult:
    """Handle terminal/filesystem tools."""

    if name == "run_command":
        command = arguments["command"]
        cwd_rel = arguments.get("cwd", "")
        timeout = int(arguments.get("timeout_seconds", DEFAULT_TIMEOUT))
        cwd = resolve_within_root(cwd_rel) if cwd_rel else ROOT_DIR

        if not is_command_safe(command):
            return _err(f'Blocked dangerous command: "{command}"')

        log("run", f"CMD: {command}  |  CWD: {cwd}")
        stdout, stderr = await run_shell(command, cwd, timeout)
        log("done", f"CMD finished: {command}")
        return _ok(format_output(None, stdout, stderr))

    elif name == "read_file":
        abs_path = resolve_readwrite(arguments["path"])
        if not abs_path.is_file():
            return _err(f"Not a file: {abs_path}")
        log("read", f"FILE: {abs_path}")
        content = abs_path.read_text(encoding="utf-8", errors="replace")
        return _ok(content)

    elif name == "write_file":
        abs_path = resolve_readwrite(arguments["path"])
        abs_path.parent.mkdir(parents=True, exist_ok=True)
        log("write", f"FILE: {abs_path}")
        abs_path.write_text(arguments["content"], encoding="utf-8")
        return _ok(f"Written: {abs_path}")

    elif name == "list_files":
        directory = resolve_within_root(arguments["path"]) if arguments.get("path") else ROOT_DIR
        recursive = arguments.get("recursive", False)
        log("list", f"DIR: {directory}  recursive={recursive}")

        if not directory.is_dir():
            return _err(f"Not a directory: {directory}")

        if recursive:
            stdout, _ = await run_shell("find . -not -path '*/.*'", directory, timeout=15)
            return _ok(stdout.strip() or "(empty)")

        entries = sorted(directory.iterdir(), key=lambda p: (p.is_file(), p.name))
        lines = [f"{'[dir]  ' if e.is_dir() else '[file] '}{e.name}" for e in entries]
        return _ok("\n".join(lines) or "(empty directory)")

    elif name == "run_workflow":
        workflow = arguments["workflow"]
        wargs: dict = arguments.get("args") or {}
        cwd = resolve_within_root(arguments["cwd"]) if arguments.get("cwd") else ROOT_DIR

        match workflow:
            case "npm_install":
                command = "npm install"
            case "npm_run":
                script = wargs.get("script")
                if not script:
                    return _err("npm_run requires args.script")
                command = f"npm run {script}"
            case "python_run":
                file = wargs.get("file")
                if not file:
                    return _err("python_run requires args.file")
                extra = f" {wargs['args']}" if wargs.get("args") else ""
                command = f"python3 {file}{extra}"
            case "shell_script":
                script_path = wargs.get("script_path")
                if not script_path:
                    return _err("shell_script requires args.script_path")
                extra = f" {wargs['args']}" if wargs.get("args") else ""
                command = f"bash {script_path}{extra}"
            case _:
                return _err(f"Unknown workflow: {workflow}")

        if not is_command_safe(command):
            return _err(f'Blocked dangerous command: "{command}"')

        log("workflow", f"{workflow.upper()}: {command}  |  CWD: {cwd}")
        stdout, stderr = await run_shell(command, cwd, timeout=120)
        log("done", f"Workflow finished: {command}")
        return _ok(format_output(command, stdout, stderr))

    return _err(f"Unknown terminal tool: {name}")


def _handle_memory(name: str, arguments: dict[str, Any]) -> CallToolResult:
    """Handle memory tools."""

    if name == "memory_store":
        mem_name = arguments["name"]
        content = arguments["content"]
        mem_type = arguments.get("type", "note")
        tags = arguments.get("tags", [])

        path = memory.store(mem_name, content, memory_type=mem_type, tags=tags)
        log("memory", f"STORE: {mem_name} ({mem_type})")
        return _ok(f"Memory stored: {mem_name}\nType: {mem_type}\nPath: {path}")

    elif name == "memory_recall":
        mem_name = arguments["name"]
        result = memory.recall(mem_name)
        if result is None:
            return _err(f'Memory not found: "{mem_name}"')

        log("memory", f"RECALL: {mem_name}")
        meta = result["meta"]
        output = (
            f"Name: {meta.get('name', mem_name)}\n"
            f"Type: {meta.get('type', 'note')}\n"
            f"Tags: {', '.join(meta.get('tags', [])) or '(none)'}\n"
            f"Created: {meta.get('created', '?')}\n"
            f"Updated: {meta.get('updated', '?')}\n"
            f"---\n{result['body']}"
        )
        return _ok(output)

    elif name == "memory_search":
        query = arguments["query"]
        mem_type = arguments.get("type")
        results = memory.search(query, memory_type=mem_type)
        log("memory", f"SEARCH: q={query} type={mem_type} hits={len(results)}")

        if not results:
            return _ok(f'No memories found for "{query}"')

        lines = [f"Found {len(results)} memor{'y' if len(results) == 1 else 'ies'}:\n"]
        for r in results:
            tags_str = f" [{', '.join(r['tags'])}]" if r["tags"] else ""
            lines.append(f"  [{r['type']}] {r['name']}{tags_str}")
            lines.append(f"    Updated: {r['updated']}")
            if r["preview"]:
                lines.append(f"    {r['preview'][:120]}")
            lines.append("")
        return _ok("\n".join(lines))

    elif name == "memory_delete":
        mem_name = arguments["name"]
        deleted = memory.delete(mem_name)
        if deleted:
            log("memory", f"DELETE: {mem_name}")
            return _ok(f"Deleted memory: {mem_name}")
        return _err(f'Memory not found: "{mem_name}"')

    elif name == "memory_list":
        log("memory", "LIST all")
        index = memory.list_all()
        return _ok(index)

    return _err(f"Unknown memory tool: {name}")


# ── MCP Server ───────────────────────────────────────────────────────────────

TERMINAL_TOOLS = {"run_command", "read_file", "write_file", "list_files", "run_workflow"}
MEMORY_TOOLS = {"memory_store", "memory_recall", "memory_search", "memory_delete", "memory_list"}

app = Server("terminal-mcp")


@app.list_tools()
async def list_tools() -> list[Tool]:
    allowed = load_allowed_paths()
    allowed_display = ", ".join(str(a) for a in allowed)
    return _build_terminal_tools(allowed_display) + _build_memory_tools()


@app.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> CallToolResult:
    try:
        if name in TERMINAL_TOOLS:
            return await _handle_terminal(name, arguments)
        elif name in MEMORY_TOOLS:
            return _handle_memory(name, arguments)
        else:
            return _err(f"Unknown tool: {name}")
    except asyncio.TimeoutError:
        return _err("Command timed out")
    except PermissionError as e:
        return _err(str(e))
    except ValueError as e:
        return _err(str(e))
    except Exception as exc:
        return _err(f"Unexpected error: {exc}")


# ── Entry point ──────────────────────────────────────────────────────────────


async def main():
    log("startup", f"terminal-mcp started | ROOT: {ROOT_DIR} | PLAYGROUND: {PLAYGROUND_DIR} | MEMORY: {MEMORY_DIR}")
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())


def run():
    """CLI entry point."""
    asyncio.run(main())


if __name__ == "__main__":
    run()
