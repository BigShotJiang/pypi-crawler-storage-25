"""Allow running with `python -m terminal_mcp`."""

from terminal_mcp.server import run

run()
