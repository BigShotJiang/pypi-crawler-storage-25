"""
Persistent memory store for terminal-mcp.

Memories are stored as individual markdown files with YAML frontmatter
inside PLAYGROUND_DIR/memory/. An index file (MEMORY.md) provides a
quick-lookup summary of all stored memories.

File format:
    ---
    name: short-name
    type: user | feedback | project | reference | note
    tags: [tag1, tag2]
    created: 2025-01-15T14:30:00
    updated: 2025-01-15T14:30:00
    ---
    Memory content goes here.

MEMORY.md format:
    - [Title](filename.md) — one-line description
"""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path
from typing import Any, Optional


# ── Frontmatter parsing ─────────────────────────────────────────────────────

_FM_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)

VALID_TYPES = {"user", "feedback", "project", "reference", "note"}


def _parse_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    """Parse YAML-like frontmatter and return (metadata, body)."""
    m = _FM_RE.match(text)
    if not m:
        return {}, text

    meta: dict[str, Any] = {}
    for line in m.group(1).splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        key = key.strip()
        value = value.strip()
        # Handle list values: [a, b, c]
        if value.startswith("[") and value.endswith("]"):
            meta[key] = [v.strip().strip("\"'") for v in value[1:-1].split(",") if v.strip()]
        else:
            meta[key] = value.strip("\"'")
    body = text[m.end():]
    return meta, body


def _serialize_frontmatter(meta: dict[str, Any], body: str) -> str:
    """Serialize metadata + body back to frontmatter markdown."""
    lines = ["---"]
    for key, value in meta.items():
        if isinstance(value, list):
            lines.append(f"{key}: [{', '.join(value)}]")
        else:
            lines.append(f"{key}: {value}")
    lines.append("---")
    lines.append("")
    lines.append(body.strip())
    lines.append("")
    return "\n".join(lines)


# ── Memory store ─────────────────────────────────────────────────────────────


class MemoryStore:
    """File-backed persistent memory with index."""

    def __init__(self, memory_dir: Path):
        self.memory_dir = memory_dir
        self.index_file = memory_dir / "MEMORY.md"

    def _ensure_dir(self) -> None:
        self.memory_dir.mkdir(parents=True, exist_ok=True)

    def _slug(self, name: str) -> str:
        """Convert a name to a safe filename slug."""
        slug = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")
        return slug[:80] or "unnamed"

    def _rebuild_index(self) -> None:
        """Rebuild MEMORY.md from all memory files."""
        entries: list[tuple[str, str, str, str]] = []  # (name, filename, description, type)

        for f in sorted(self.memory_dir.glob("*.md")):
            if f.name == "MEMORY.md":
                continue
            try:
                meta, body = _parse_frontmatter(f.read_text(encoding="utf-8"))
            except Exception:
                continue
            name = meta.get("name", f.stem)
            mtype = meta.get("type", "note")
            # Use first line of body as description, or tags
            desc = body.strip().split("\n")[0][:120] if body.strip() else ", ".join(meta.get("tags", []))
            entries.append((name, f.name, desc, mtype))

        # Group by type
        lines = [f"# Memory Index\n"]
        if not entries:
            lines.append("_No memories stored yet._\n")
        else:
            by_type: dict[str, list[tuple[str, str, str]]] = {}
            for name, filename, desc, mtype in entries:
                by_type.setdefault(mtype, []).append((name, filename, desc))
            for mtype in ["user", "feedback", "project", "reference", "note"]:
                items = by_type.get(mtype, [])
                if not items:
                    continue
                lines.append(f"\n## {mtype.title()}\n")
                for name, filename, desc in items:
                    lines.append(f"- [{name}]({filename}) — {desc}")

        self.index_file.write_text("\n".join(lines) + "\n", encoding="utf-8")

    # ── Public API ───────────────────────────────────────────────────────────

    def store(
        self,
        name: str,
        content: str,
        memory_type: str = "note",
        tags: list[str] | None = None,
    ) -> str:
        """Store or overwrite a memory. Returns the file path."""
        self._ensure_dir()

        if memory_type not in VALID_TYPES:
            raise ValueError(f"Invalid type '{memory_type}'. Must be one of: {', '.join(sorted(VALID_TYPES))}")

        slug = self._slug(name)
        filepath = self.memory_dir / f"{slug}.md"
        now = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")

        # Preserve created timestamp if updating
        created = now
        if filepath.exists():
            old_meta, _ = _parse_frontmatter(filepath.read_text(encoding="utf-8"))
            created = old_meta.get("created", now)

        meta = {
            "name": name,
            "type": memory_type,
            "tags": tags or [],
            "created": created,
            "updated": now,
        }
        filepath.write_text(_serialize_frontmatter(meta, content), encoding="utf-8")
        self._rebuild_index()
        return str(filepath)

    def recall(self, name: str) -> dict[str, Any] | None:
        """Retrieve a memory by name. Returns {meta, body, path} or None."""
        self._ensure_dir()
        slug = self._slug(name)
        filepath = self.memory_dir / f"{slug}.md"

        if not filepath.exists():
            # Fallback: search by name field in all files
            for f in self.memory_dir.glob("*.md"):
                if f.name == "MEMORY.md":
                    continue
                try:
                    meta, body = _parse_frontmatter(f.read_text(encoding="utf-8"))
                    if meta.get("name", "").lower() == name.lower():
                        return {"meta": meta, "body": body, "path": str(f)}
                except Exception:
                    continue
            return None

        meta, body = _parse_frontmatter(filepath.read_text(encoding="utf-8"))
        return {"meta": meta, "body": body, "path": str(filepath)}

    def search(self, query: str, memory_type: str | None = None) -> list[dict[str, Any]]:
        """Search memories by keyword across name, tags, and content."""
        self._ensure_dir()
        results: list[dict[str, Any]] = []
        query_lower = query.lower()

        for f in sorted(self.memory_dir.glob("*.md")):
            if f.name == "MEMORY.md":
                continue
            try:
                text = f.read_text(encoding="utf-8")
                meta, body = _parse_frontmatter(text)
            except Exception:
                continue

            if memory_type and meta.get("type") != memory_type:
                continue

            # Search across name, tags, and body
            searchable = " ".join([
                meta.get("name", ""),
                " ".join(meta.get("tags", [])),
                body,
            ]).lower()

            if query_lower in searchable:
                results.append({
                    "name": meta.get("name", f.stem),
                    "type": meta.get("type", "note"),
                    "tags": meta.get("tags", []),
                    "updated": meta.get("updated", ""),
                    "preview": body.strip()[:200],
                    "path": str(f),
                })

        return results

    def delete(self, name: str) -> bool:
        """Delete a memory by name. Returns True if deleted."""
        self._ensure_dir()
        slug = self._slug(name)
        filepath = self.memory_dir / f"{slug}.md"

        if not filepath.exists():
            # Try searching by name field
            for f in self.memory_dir.glob("*.md"):
                if f.name == "MEMORY.md":
                    continue
                try:
                    meta, _ = _parse_frontmatter(f.read_text(encoding="utf-8"))
                    if meta.get("name", "").lower() == name.lower():
                        f.unlink()
                        self._rebuild_index()
                        return True
                except Exception:
                    continue
            return False

        filepath.unlink()
        self._rebuild_index()
        return True

    def list_all(self) -> str:
        """Return the full MEMORY.md index content."""
        self._ensure_dir()
        self._rebuild_index()
        return self.index_file.read_text(encoding="utf-8")
