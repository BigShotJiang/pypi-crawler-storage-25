"""Terminal MCP Server — give Claude safe terminal and filesystem access."""

__version__ = "0.1.0"
