"""Bundled Docker sandbox assets."""
