"""
TmuxBroadcastEffector: Fire-and-forget send-keys to a tmux pane via the dev daemon.

Unlike TmuxSessionEffector (which captures stdout/exit_code via POST /run),
this effector simply types the plan's content into the target pane's stdin
via POST /keys. Use for voice-broadcast or user-visible interactions where
the tmux pane is the shared source of truth.

This is the ONLY component that may mutate world state (Invariant E1).
"""

import json
import logging
import os
import uuid
from datetime import datetime
from types import MappingProxyType

from atomicguard.domain.interfaces import EffectorInterface, Idempotency
from atomicguard.domain.models import (
    Artifact,
    ArtifactId,
    ArtifactStatus,
    ContextSnapshot,
)
from atomicguard.infrastructure.effectors.tmux_session_effector import (
    _UnixHTTPConnection,
)

logger = logging.getLogger(__name__)


class TmuxBroadcastEffector(EffectorInterface):
    """Sends keystrokes to a tmux pane via the dev daemon's POST /keys endpoint.

    The plan artifact's content is sent as keystrokes — the daemon calls
    tmux send-keys, making the input visible in the pane's scrollback.
    Fire-and-forget: no stdout capture, no exit code, no waiting.
    """

    def __init__(
        self,
        *,
        session: str,
        pane: str = "1.1",
        socket_path: str = "~/.local/run/dev.sock",
        idempotent: bool = False,
    ):
        self._session = session
        self._pane = pane
        self._socket_path = os.path.expanduser(socket_path)
        self._idempotent = idempotent

    @property
    def idempotency(self) -> Idempotency:
        return (
            Idempotency.IDEMPOTENT if self._idempotent else Idempotency.NON_IDEMPOTENT
        )

    def execute(self, plan: Artifact) -> Artifact:
        """Send plan.content as keystrokes to the target tmux pane."""
        keys = plan.content
        logger.info(
            "TmuxBroadcastEffector: sending keys %r to %s:%s",
            keys,
            self._session,
            self._pane,
        )

        conn: _UnixHTTPConnection | None = None
        sent = ""
        stderr = ""
        exit_code: str | None = None
        try:
            conn = _UnixHTTPConnection(self._socket_path)
            body = json.dumps({"keys": keys})
            path = f"/sessions/{self._session}/panes/{self._pane}/keys"
            conn.request(
                "POST",
                path,
                body=body,
                headers={
                    "Content-Type": "application/json",
                },
            )
            response = conn.getresponse()
            data = json.loads(response.read().decode())
            sent = str(data.get("sent", 0))
        except (OSError, json.JSONDecodeError, KeyError, ValueError) as exc:
            stderr = f"dev daemon error: {exc}"
            exit_code = "-2"
        finally:
            if conn is not None:
                conn.close()

        metadata: dict[str, str] = {
            "session": self._session,
            "pane": self._pane,
            "keys": keys,
        }
        if exit_code is not None:
            metadata["exit_code"] = exit_code
            metadata["stderr"] = stderr
        else:
            metadata["sent"] = sent

        return Artifact(
            artifact_id=ArtifactId(str(uuid.uuid4())),
            workflow_id=plan.workflow_id,
            content="",
            previous_attempt_id=None,
            parent_action_pair_id=None,
            action_pair_id=plan.action_pair_id,
            created_at=datetime.now().isoformat(),
            attempt_number=plan.attempt_number,
            status=ArtifactStatus.PENDING,
            guard_result=None,
            context=ContextSnapshot(
                workflow_id=plan.workflow_id,
                specification=plan.context.specification if plan.context else "",
                constraints="",
                feedback_history=(),
            ),
            metadata=MappingProxyType(metadata),
        )

    def undo(self, plan: Artifact) -> bool:  # noqa: ARG002
        """No undo for fire-and-forget keystrokes."""
        return False
