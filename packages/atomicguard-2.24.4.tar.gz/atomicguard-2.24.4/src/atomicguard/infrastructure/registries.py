"""
Registry helper functions for building generator and guard registries.

These are adapter-level conveniences — the CLI and web adapters call
these to build base registries, then extend or override entries as needed.
"""

from __future__ import annotations

from atomicguard.domain.interfaces import (
    EffectorInterface,
    GeneratorInterface,
    GuardInterface,
    HumanReviewerInterface,
    PauseCallback,
)


def build_generator_registry(
    model: str,
    provider: str,
    api_key: str = "",
    base_url: str = "",
) -> dict[str, GeneratorInterface]:
    """Build the standard generator registry.

    Creates one LLM generator entry keyed by a canonical name that
    workflow definitions reference.  The registry maps the generator
    name string (from ``ActionPairDefinition.generator``) to a
    concrete ``GeneratorInterface`` instance.

    Args:
        model: Model name / identifier (e.g. ``"qwen2.5-coder:14b"``).
        provider: One of ``"ollama"``, ``"openrouter"``, ``"openai"``,
            ``"huggingface"``.
        api_key: API key (for openrouter/openai/huggingface).
        base_url: API base URL (for ollama/openai).
        **kwargs: Additional keyword arguments passed to the generator.

    Returns:
        Registry dict mapping generator name → instance.
    """
    registry: dict[str, GeneratorInterface] = {}

    # Import generators lazily to keep the module lightweight
    if provider == "ollama":
        from atomicguard.infrastructure.llm.ollama import (
            OllamaGenerator,
            OllamaGeneratorConfig,
        )

        config = OllamaGeneratorConfig(
            model=model,
            base_url=base_url or "http://localhost:11434/v1",
            api_key=api_key or None,
        )
        gen = OllamaGenerator(config=config)
        registry["OllamaGenerator"] = gen
        registry["LLMGenerator"] = gen  # canonical alias

    elif provider == "huggingface":
        from atomicguard.infrastructure.llm.huggingface import (
            HuggingFaceGenerator,
            HuggingFaceGeneratorConfig,
        )

        hf_config = HuggingFaceGeneratorConfig(model=model, api_key=api_key)
        hf_gen = HuggingFaceGenerator(config=hf_config)
        registry["HuggingFaceGenerator"] = hf_gen
        registry["LLMGenerator"] = hf_gen

    elif provider in ("openrouter", "openai"):
        # Both use the PydanticAI OpenAI-compatible path
        from atomicguard.infrastructure.llm.ollama import (
            OllamaGenerator,
            OllamaGeneratorConfig,
        )

        config = OllamaGeneratorConfig(
            model=model,
            base_url=base_url,
            api_key=api_key or None,
        )
        gen = OllamaGenerator(config=config)
        registry["OllamaGenerator"] = gen
        registry["LLMGenerator"] = gen

    # Always include MockGenerator for testing workflows
    from atomicguard.infrastructure.llm.mock import MockGenerator

    registry["MockGenerator"] = MockGenerator(responses=["# mock"])

    return registry


def build_guard_registry(
    human_reviewer: HumanReviewerInterface | None = None,
    job_id: str = "",
    on_review_pause: PauseCallback | None = None,
    on_review_resume: PauseCallback | None = None,
) -> dict[str, GuardInterface]:
    """Build the standard guard registry.

    Returns a registry populated with all framework-provided guards.
    Adapters can extend or override entries after calling this.

    If ``human_reviewer`` is provided, the ``HumanReviewGuard``
    entry is replaced with a ``HumanReviewAdapter`` that
    delegates to the reviewer (stdin, DB-polled, or cloud API).

    Args:
        human_reviewer: Optional reviewer for human review.
            If None, the default stdin-blocking ``HumanReviewGuard``
            is used.
        job_id: Job identifier passed to the review adapter.
            Only required when ``human_reviewer`` is set.
        on_review_pause: Called when the guard pauses for human review.
        on_review_resume: Called when the guard resumes after review.

    Returns:
        Registry dict mapping guard name → instance.
    """
    from atomicguard.guards.composite import CompositeGuard  # noqa: F401
    from atomicguard.guards.dynamic import DynamicTestGuard, TestGuard
    from atomicguard.guards.static import ImportGuard, SyntaxGuard
    from atomicguard.infrastructure.guards.all_passed_guard import AllPassedGuard
    from atomicguard.infrastructure.guards.diff_empty_guard import DiffEmptyGuard
    from atomicguard.infrastructure.guards.exit_code_guard import ExitCodeGuard

    # Build human guard — either adapter-backed or default stdin
    if human_reviewer is not None:
        from atomicguard.infrastructure.guards.human_review_adapter import (
            HumanReviewAdapter,
        )

        human_guard: GuardInterface = HumanReviewAdapter(
            reviewer=human_reviewer,
            job_id=job_id,
            on_pause=on_review_pause,
            on_resume=on_review_resume,
        )
    else:
        from atomicguard.guards.interactive import HumanReviewGuard

        human_guard = HumanReviewGuard()

    registry: dict[str, GuardInterface] = {
        "SyntaxGuard": SyntaxGuard(),
        "ImportGuard": ImportGuard(),
        "TestGuard": TestGuard(),
        "DynamicTestGuard": DynamicTestGuard(),
        "HumanReviewGuard": human_guard,
        "ExitCodeGuard": ExitCodeGuard(),
        "AllPassedGuard": AllPassedGuard(),
        "DiffEmptyGuard": DiffEmptyGuard(),
    }

    return registry


def build_effector_registry(
    *,
    timeout: int = 30,
) -> dict[str, EffectorInterface]:
    """Build the standard effector registry.

    Returns a registry populated with framework-provided effectors.
    The WorkflowEffector is NOT included — it requires a catalogue
    and is wired by the meta-workflow builder specifically.

    Args:
        timeout: Default timeout for BashCommandExecutor.

    Returns:
        Registry dict mapping effector name -> instance.
    """
    from atomicguard.infrastructure.effectors.bash_executor import BashCommandExecutor
    from atomicguard.infrastructure.effectors.tmux_broadcast_effector import (
        TmuxBroadcastEffector,
    )
    from atomicguard.infrastructure.effectors.tmux_session_effector import (
        TmuxSessionEffector,
    )

    return {
        "BashCommandExecutor": BashCommandExecutor(timeout=timeout),
        "TmuxSessionEffector": TmuxSessionEffector(
            session="",  # overridden per-workflow via effector_config
            socket_path="~/.local/run/dev.sock",
            timeout=timeout,
        ),
        "TmuxBroadcastEffector": TmuxBroadcastEffector(
            session="",  # overridden per-workflow via effector_config
            socket_path="~/.local/run/dev.sock",
        ),
    }
