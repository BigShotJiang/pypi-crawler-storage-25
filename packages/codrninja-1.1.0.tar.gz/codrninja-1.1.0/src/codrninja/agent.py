"""Agent loop for codrninja — makes it a real coding tool."""

import copy
import hashlib
import json
import os
import re
from typing import Dict, List, Optional, Any, Callable, TYPE_CHECKING

if TYPE_CHECKING:
    from .subagent import SubagentManager

from .config import Config
from .core import AICode
from .tools import ToolRegistry, ToolResult
from .permissions import PermissionManager, PermissionRule
from .skills import SkillRegistry
from .todo import TodoManager, TodoItem, format_todo_item
from .safety import SafetyConfig, SafetyManager


BASE_SYSTEM_PROMPT = """You are an expert software engineer. You help write, review, and modify code.

When you need to perform actions, use the TOOL format:

```tool
{
  \"tool\": \"tool_name\",
  \"params\": {
    \"param1\": \"value1\",
    \"param2\": \"value2\"
  }
}
```

Available tools:
- read_file: Read file contents. Params: path, offset, limit
- write_file: Write content to file. Params: path, content
- edit_file: Edit file by replacing text. Params: path, old_text, new_text
- execute_command: Run shell command. Params: command, cwd
- list_files: List directory contents. Params: path, depth
- search_files: Search for files. Params: pattern, path
- web_fetch: Fetch and clean a web page. Params: url, max_length, timeout
- web_search: Search the internet for up-to-date information. Params: query, num_results
- todo_add: Create a session todo item. Params: task, session_id(optional)
- todo_list: List session todo items. Params: session_id(optional)
- todo_complete: Mark a todo item as done. Params: todo_id
- todo_remove: Delete a todo item. Params: todo_id
- lsp_definition: Go to definition. Params: file_path, line, column
- lsp_hover: Get hover/type information. Params: file_path, line, column
- lsp_references: Find references. Params: file_path, line, column
- lsp_diagnostics: Get language diagnostics. Params: file_path
- lsp_symbols: Get document outline/symbols. Params: file_path
- lsp_rename: Preview rename edits. Params: file_path, line, column, new_name

Rules:
1. Always check existing files before modifying them
2. Use execute_command for builds, tests, git operations
3. Show file paths when creating or modifying files
4. Be concise but thorough
5. If a task requires multiple steps, use multiple tool calls
6. For multi-step work, use todo_add to track tasks and todo_list to review progress
7. **ALWAYS execute tool calls immediately** — never just describe or plan what you will do. When you need information, use read_file or search_files. When you need to run code, use execute_command. Do NOT say "I will search for..." or "Let me look at..." without immediately following it with the actual tool call.
8. When a task requires multiple steps, output ALL tool calls in a single response rather than waiting for permission between each step.

After using tools, summarize what you did and any important findings.
You can fetch web pages and search the internet for up-to-date information.
You can use LSP tools for go-to-definition, hover info, find references, diagnostics, and symbols."""


class AgentMode:
    """Agent operating modes."""
    BUILD = "build"
    PLAN = "plan"
    SUBAGENT = "subagent"


class Agent:
    """Agent that can use tools to accomplish coding tasks."""

    def __init__(
        self,
        ai: AICode,
        session_name: str,
        max_iterations: int = 10,
        mode: str = AgentMode.BUILD,
        permission_manager: Optional[PermissionManager] = None,
        parent_permission_manager: Optional[PermissionManager] = None,
        max_steps: Optional[int] = None,
        safety_config: Optional[SafetyConfig] = None,
    ):
        self.ai = ai
        self.session_name = session_name
        self.config = ai.config
        self.tools = ToolRegistry()
        self.tools.set_session(session_name)
        self.todo_manager = TodoManager()
        self.max_iterations = max_iterations
        self.mode = mode
        self.message_history = []
        self.on_progress: Optional[Callable[[str], None]] = None
        self.subagent_messages: List[Dict[str, Any]] = []
        self.subagent_manager: Optional["SubagentManager"] = None
        self.permission_decisions: List[Dict[str, Any]] = []
        self.doom_loop_counts: Dict[str, int] = {}
        self.max_steps = max_steps or int(os.environ.get("CODRNINJA_MAX_STEPS", "50"))
        self.step_count = 0
        self.skill_registry = SkillRegistry()
        self.skill_registry.discover()
        self.skill_registry.register_tools(self.tools)
        self.system_prompt = self._build_system_prompt()
        self.agent_type = self._resolve_agent_type(mode)
        self.permissions = permission_manager or PermissionManager(
            mode=self.config.permissions_mode,
            project_root=os.getcwd(),
            parent=parent_permission_manager,
        )
        self.tools.set_permissions(self.permissions, self.agent_type)
        self.safety = SafetyManager(safety_config or SafetyConfig(max_steps=self.max_steps))
        self.max_steps = self.safety.config.max_steps
        self.git_checkpoint_state: Optional[Dict[str, Any]] = None

        if self.mode == AgentMode.PLAN:
            self._restrict_to_readonly()

        from .subagent import SubagentManager
        self.subagent_manager = SubagentManager(ai, self)

    def run(self, message: str, auto_approve: bool = False) -> Dict[str, Any]:
        self.message_history.append({"role": "user", "content": message})
        context = self._build_context(message)
        iteration = 0
        tool_results = []
        content = ""
        total_tokens = {'input': 0, 'output': 0}
        previous_todo_ids = {item.id for item in self.todo_manager.list(self.session_name)}
        self.ai.session_manager.set_status(self.session_name, "running")

        try:
            while iteration < self.max_iterations:
                iteration += 1
                response = self._call_ai(context)
                response_tokens = response.get('tokens') or {}
                total_tokens['input'] = response_tokens.get('input', 0) or 0
                total_tokens['output'] = response_tokens.get('output', 0) or 0

                if not response.get('success'):
                    self._finalize_git(success=False)
                    self.ai.session_manager.set_status(self.session_name, "error")
                    return {
                        'success': False,
                        'error': response.get('error', 'Unknown error'),
                        'iterations': iteration,
                        'safety': self.safety.get_report(),
                    }

                content = response['response']
                tool_calls = self._parse_tool_calls(content)

                if not tool_calls:
                    self.message_history.append({"role": "assistant", "content": content})
                    self._finalize_git(success=True)
                    self.ai.session_manager.set_status(self.session_name, "completed")
                    todos = self.todo_manager.list(self.session_name)
                    new_todos = [item for item in todos if item.id not in previous_todo_ids]
                    return self._success_payload(content, iteration, tool_results, todos, new_todos, total_tokens)

                for tool_call in tool_calls:
                    if self.step_count >= self.max_steps:
                        self._finalize_git(success=False)
                        self.ai.session_manager.set_status(self.session_name, "error")
                        return {
                            'success': False,
                            'error': f'Max steps exceeded ({self.max_steps})',
                            'iterations': iteration,
                            'permission_decisions': self.permission_decisions,
                            'safety': self.safety.get_report(),
                        }

                    tool_name = tool_call['tool']
                    params = tool_call['params']
                    loop_block = self._detect_doom_loop(tool_name, params)
                    if loop_block:
                        tool_results.append({'tool': tool_name, 'params': params, 'success': False, 'output': loop_block})
                        context += f"\n\n[Tool Result: {tool_name}]\nError: {loop_block}"
                        continue

                    if not auto_approve:
                        permission_error = self._enforce_permission(tool_name, params)
                        if permission_error:
                            self._finalize_git(success=False)
                            self.ai.session_manager.set_status(self.session_name, "error")
                            return {
                                'success': False,
                                'error': permission_error,
                                'iterations': iteration,
                                'permission_decisions': self.permission_decisions,
                                'safety': self.safety.get_report(),
                            }

                    result = self._execute_tool(tool_name, params)
                    self.step_count += 1
                    tool_results.append({
                        'tool': tool_name,
                        'params': params,
                        'success': result.success,
                        'output': result.output[:500] if result.success else (result.error or result.output),
                    })

                    context += f"\n\n[Tool Result: {tool_name}]\n"
                    context += f"Success: {result.output[:500]}" if result.success else f"Error: {result.error or result.output}"

                    if self.on_progress:
                        preview = result.output if result.success else (result.error or result.output or "")
                        self.on_progress(f"[OK] {tool_name}: {preview[:100]}...")

                    if not result.success and self._is_mutating_tool(tool_name):
                        self._finalize_git(success=False)
                        self.ai.session_manager.set_status(self.session_name, "error")
                        return {
                            'success': False,
                            'error': result.error or result.output,
                            'iterations': iteration,
                            'permission_decisions': self.permission_decisions,
                            'safety': self.safety.get_report(),
                        }

            self.message_history.append({"role": "assistant", "content": content})
            self._finalize_git(success=True)
            self.ai.session_manager.set_status(self.session_name, "completed")
            todos = self.todo_manager.list(self.session_name)
            new_todos = [item for item in todos if item.id not in previous_todo_ids]
            payload = self._success_payload(content, iteration, tool_results, todos, new_todos, total_tokens)
            payload['note'] = 'Max iterations reached'
            return payload
        except Exception as exc:
            self.ai.session_manager.append_event(self.session_name, 'agent_error', {'error': str(exc)})
            self._finalize_git(success=False)
            self.ai.session_manager.set_status(self.session_name, "error")
            return {
                'success': False,
                'error': str(exc),
                'iterations': iteration,
                'permission_decisions': self.permission_decisions,
                'safety': self.safety.get_report(),
            }

    def _success_payload(self, content, iteration, tool_results, todos, new_todos, total_tokens):
        return {
            'success': True,
            'response': content,
            'iterations': iteration,
            'tool_calls': len(tool_results),
            'tools_used': tool_results,
            'subagent_messages': self.subagent_messages,
            'permission_decisions': self.permission_decisions,
            'todos': [self._todo_to_dict(item) for item in todos],
            'new_todos': [self._todo_to_dict(item) for item in new_todos],
            'tokens': total_tokens,
            'safety': self.safety.get_report(),
        }

    def _execute_tool(self, tool_name: str, params: Dict[str, Any]) -> ToolResult:
        denied = self.safety.check_tool(tool_name, params)
        if denied:
            self.ai.session_manager.append_event(self.session_name, 'tool_denied', {
                'tool': tool_name,
                'params': params,
                'reason': denied,
            })
            return ToolResult(False, denied, denied)

        if self.safety.config.require_approval and not self.safety.check_approval(tool_name, params):
            reason = 'Explicit approval required'
            self.ai.session_manager.append_event(self.session_name, 'tool_denied', {
                'tool': tool_name,
                'params': params,
                'reason': reason,
            })
            return ToolResult(False, reason, reason)

        checkpoint = None
        if self._is_mutating_tool(tool_name) and self.safety.config.git_checkpoint:
            checkpoint = self._ensure_checkpoint(tool_name)

        self.ai.session_manager.append_event(self.session_name, 'tool_call', {
            'tool': tool_name,
            'params': params,
            'step': self.safety.step_count,
        })
        result = self.tools.call(tool_name, **params)

        if self._is_mutating_tool(tool_name):
            path = params.get('path') or params.get('cwd') or params.get('command', '')
            action = 'command' if tool_name == 'execute_command' else 'modify'
            self.ai.session_manager.append_artifact(self.session_name, str(path), action)
            status = self.ai.git.get_status()
            self.ai.session_manager.update_state(
                self.session_name,
                git_branch=status.get('branch', ''),
                files_changed=[item.get('path') for item in status.get('files_changed', [])],
            )

        if not result.success and checkpoint and checkpoint.get('method') == 'stash' and self.safety.config.rollback_on_error:
            rollback = self.ai.git.rollback('stash', checkpoint.get('hash'))
            self.ai.session_manager.append_event(self.session_name, 'git_rollback', rollback)

        self.ai.session_manager.append_event(self.session_name, 'tool_result', {
            'tool': tool_name,
            'success': result.success,
            'output': result.output[:1000],
            'error': result.error,
        })
        return result

    def _ensure_checkpoint(self, tool_name: str) -> Optional[Dict[str, Any]]:
        if self.git_checkpoint_state:
            return self.git_checkpoint_state
        checkpoint = self.ai.git.checkpoint(self.session_name, message=f'codrninja before {tool_name}')
        self.git_checkpoint_state = checkpoint
        self.ai.session_manager.append_event(self.session_name, 'git_checkpoint', checkpoint)
        return checkpoint

    def _finalize_git(self, success: bool):
        if not self.safety.config.git_checkpoint:
            return
        patch = self.ai.git.save_patch(self.ai.session_manager, self.session_name, label='final')
        self.ai.session_manager.append_event(self.session_name, 'git_patch', patch)
        if not success and self.git_checkpoint_state and self.git_checkpoint_state.get('method') == 'stash' and self.safety.config.rollback_on_error:
            rollback = self.ai.git.rollback('stash', self.git_checkpoint_state.get('hash'))
            self.ai.session_manager.append_event(self.session_name, 'git_rollback', rollback)

    def _is_mutating_tool(self, tool_name: str) -> bool:
        return tool_name in {'write_file', 'edit_file', 'execute_command'}

    def _build_system_prompt(self) -> str:
        prompt = BASE_SYSTEM_PROMPT
        provider = self.ai.config.default_provider
        model = self.ai.config.default_model
        url = self.ai.config.ollama_url if provider == "ollama" else ""
        tool_names = list(self.tools.tools.keys()) if hasattr(self, 'tools') and self.tools else []
        prompt += (
            f"\n\n## Runtime Context"
            f"\nYou are the AI backend of **codrninja** — an AI-first CLI coding assistant."
            f"\nCurrent model: `{model}` via provider `{provider}`."
        )
        if url:
            prompt += f"\nOllama server: {url}"
        if tool_names:
            prompt += f"\nAvailable tools: {', '.join(tool_names)}"
        prompt += (
            "\nSession is inside a terminal TUI. The user sees your responses rendered with markdown "
            "(bold, italic, inline code, code blocks, bullet lists all work)."
            "\n\nIMPORTANT: Do NOT use Unicode emojis (like 👋, 🎉, ✅). Use ASCII emoticons instead (like :) , ;) , :( , :D )."
        )
        prompt += "\n"
        level = self.config.reasoning_level
        if level == "none":
            prompt += "\n\nReasoning: Be concise. Do not explain your thought process."""
        elif level == "low":
            prompt += "\n\nReasoning: Provide brief reasoning (1-2 sentences max) for major decisions only."""
        elif level == "medium":
            prompt += "\n\nReasoning: Explain your approach briefly before implementing. Show key steps."""
        elif level == "high":
            prompt += "\n\nReasoning: Think step by step. Explain your reasoning thoroughly before each action. Consider alternatives and trade-offs."""
        skill_prompts = self.skill_registry.get_system_prompts()
        if skill_prompts:
            prompt += f"\n\nAdditional active skills:\n{skill_prompts}"
        return prompt

    def _build_context(self, message: str) -> str:
        """Build user message context (NO system prompt — added separately as system role)."""
        context = "Working directory: `" + os.getcwd() + "`\n"
        result = self.tools.list_files(path=".", depth=1)
        if result.success and result.output.strip():
            context += "Files:\n" + result.output.strip() + "\n\n"
        else:
            context += "\n"
        context += message
        return context

    def _call_ai(self, context: str) -> Dict[str, Any]:
        original_prompt = self.ai.config.system_prompt
        try:
            self.ai.config.system_prompt = self.system_prompt
            return self.ai.send_message(self.session_name, context)
        finally:
            self.ai.config.system_prompt = original_prompt

    def _parse_tool_calls(self, content: str) -> List[Dict[str, Any]]:
        tool_calls = []
        pattern = r'```tool\s*\n(.*?)\n```'
        matches = re.findall(pattern, content, re.DOTALL)
        for match in matches:
            try:
                tool_data = json.loads(match.strip())
                if 'tool' in tool_data and 'params' in tool_data:
                    tool_calls.append(tool_data)
            except json.JSONDecodeError:
                continue
        return tool_calls

    def _restrict_to_readonly(self):
        readonly = {k: v for k, v in self.tools.tools.items() if k in ('read_file', 'list_files', 'search_files')}
        self.tools.tools = readonly

    def _resolve_agent_type(self, mode: str) -> str:
        if mode == AgentMode.PLAN:
            return "plan"
        if mode == AgentMode.SUBAGENT:
            return "subagent"
        return "build"

    def _permission_request(self, tool_name: str, params: Dict[str, Any]) -> tuple[str, str]:
        if tool_name == 'execute_command':
            return 'execute', params.get('command', '')
        return ('read' if tool_name == 'read_file' else 'write'), params.get('path', '')

    def _enforce_permission(self, tool_name: str, params: Dict[str, Any]) -> Optional[str]:
        action, target = self._permission_request(tool_name, params)
        decision = self.permissions.decide(action, target, self.agent_type)
        explanation = self.permissions.explain(action, target, self.agent_type)
        self.permission_decisions.append({
            'tool': tool_name,
            'action': action,
            'target': target,
            'decision': decision.action,
            'explanation': explanation,
            'params': params,
        })
        if self.permissions.mode == 'auto':
            return None
        if self.permissions.mode == 'none':
            return f'Permission denied for {tool_name}: permission mode is none'
        if decision.action == 'deny':
            return f'Permission denied for {tool_name}: {explanation}'
        if decision.action == 'ask' and not self._ask_permission(tool_name, params, action, target):
            return f'User denied permission for {tool_name}: {explanation}'
        return None

    def _ask_permission(self, tool_name: str, params: Dict[str, Any], action: str, target: str) -> bool:
        from .tui import TUI
        formatted_params = json.dumps(params, indent=2, ensure_ascii=False)
        prompt_text = (
            "Permission Request\n"
            f"Tool: {tool_name}\n"
            f"Action: {action}\n"
            f"Target: {target or '(none)'}\n\n"
            "Parameters:\n"
            f"{formatted_params}\n\n"
            "Select an option:"
        )
        options = [
            "✓ Yes — Execute this time",
            "✓ Always — Allow this tool always",
            "✗ No — Skip this time",
            "✗ Never — Block this tool always",
        ]
        tui = TUI.__new__(TUI)
        idx = tui._select_option(options, prompt_text)
        if idx == 0:
            self.permission_decisions.append({'interactive': 'yes', 'tool': tool_name, 'action': action, 'target': target, 'params': params})
            return True
        if idx == 1:
            self.permissions.add_rule(PermissionRule(tool_name, 'allow', action, self.agent_type, 1000))
            self.permission_decisions.append({'interactive': 'always', 'tool': tool_name, 'action': action, 'target': target, 'params': params})
            return True
        if idx == 2:
            self.permission_decisions.append({'interactive': 'no', 'tool': tool_name, 'action': action, 'target': target, 'params': params})
            return False
        if idx == 3:
            self.permissions.add_rule(PermissionRule(tool_name, 'deny', action, self.agent_type, 1000))
            self.permission_decisions.append({'interactive': 'never', 'tool': tool_name, 'action': action, 'target': target, 'params': params})
            return False
        self.permission_decisions.append({'interactive': 'cancelled', 'tool': tool_name, 'action': action, 'target': target, 'params': params})
        return False

    def _detect_doom_loop(self, tool_name: str, params: Dict[str, Any]) -> Optional[str]:
        signature = hashlib.sha256(json.dumps({'tool': tool_name, 'params': params}, sort_keys=True).encode()).hexdigest()
        count = self.doom_loop_counts.get(signature, 0) + 1
        self.doom_loop_counts[signature] = count
        if count >= 3:
            warning = f'Doom loop detected for {tool_name} with identical input; auto-denied after {count} attempts'
            self.permission_decisions.append({'tool': tool_name, 'decision': 'deny', 'reason': warning})
            return warning
        return None

    def spawn_subagent(self, name: str, task: str, mode: str = AgentMode.BUILD):
        if not self.subagent_manager:
            from .subagent import SubagentManager
            self.subagent_manager = SubagentManager(self.ai, self)
        return self.subagent_manager.spawn(name=name, task=task, mode=mode)

    def receive_subagent_message(self, message: Dict[str, Any]):
        self.subagent_messages.append(message)
        summary = message.get("result", {}).get("response") or message.get("result", {}).get("error") or "Subagent completed"
        self.message_history.append({"role": "assistant", "content": f"[Subagent {message.get('name')}] {summary}"})

    def _todo_to_dict(self, item: TodoItem) -> Dict[str, Any]:
        return {
            'id': item.id,
            'task': item.task,
            'status': item.status,
            'created_at': item.created_at,
            'completed_at': item.completed_at,
            'session_id': item.session_id,
            'display': format_todo_item(item),
        }

    def format_todos_for_display(self, todos: List[Dict[str, Any]]) -> str:
        return "\n".join(todo.get('display', f"□ [{todo['id']}] {todo['task']}") for todo in todos)

    def _call_ai_stream(self, context: str):
        """Like _call_ai but yields streaming delta chunks from the provider."""
        original_prompt = self.ai.config.system_prompt
        try:
            self.ai.config.system_prompt = self.system_prompt
            session = self.ai.get_session(self.session_name)
            if not session:
                session = self.ai.create_session(self.session_name)

            # Use session-specific model/provider if set, else global config
            session_state = self.ai.session_manager.get(self.session_name) or {}
            current_provider_name = self.ai.config.default_provider
            session_model = session_state.get("model", "")
            session_provider = session_state.get("provider", "")
            # Only use session model when it was set for the current provider
            if session_model and (not session_provider or session_provider == current_provider_name):
                model = session_model
            else:
                model = self.ai.config.default_model
            provider = self.ai.provider_manager.get_provider()

            # Patch system prompt so AI self-reports the actual session model, not the stale default
            sys_content = self.system_prompt
            default_model = self.ai.config.default_model
            if model != default_model:
                sys_content = sys_content.replace(
                    f"Current model: `{default_model}` via provider `{current_provider_name}`",
                    f"Current model: `{model}` via provider `{current_provider_name}`",
                )
            messages = [{"role": "system", "content": sys_content}]
            messages.extend(session.messages)
            messages.append({"role": "user", "content": context})

            full_content = ""
            tokens_in = tokens_out = 0
            if not hasattr(provider, 'chat_stream'):
                # Fallback: blocking call emitted as one chunk
                result = provider.chat(messages, model)
                if result.get("error"):
                    yield {"error": result["error"], "delta": "", "done": True}
                    return
                text = result.get("content", "")
                full_content = text
                tokens_in = result.get("tokens_input", 0)
                tokens_out = result.get("tokens_output", 0)
                if text:
                    yield {"delta": text, "done": False, "tokens_input": tokens_in, "tokens_output": tokens_out}
                yield {"delta": "", "done": True, "tokens_input": tokens_in, "tokens_output": tokens_out}
            else:
                for chunk in provider.chat_stream(messages, model):
                    if chunk.get("error"):
                        yield chunk
                        return
                    tokens_in = chunk.get("tokens_input", tokens_in)
                    tokens_out = chunk.get("tokens_output", tokens_out)
                    full_content += chunk.get("delta", "")
                    yield chunk

            # Persist messages after full response
            self.ai._save_message(session.id, "user", context)
            self.ai._save_message(session.id, "assistant", full_content, model=model,
                                  tokens_in=tokens_in, tokens_out=tokens_out)
            self.ai.session_manager.append_message(self.session_name, "user", context, model=model)
            self.ai.session_manager.append_message(self.session_name, "assistant", full_content, model=model)
            # Update session state so the session list shows the last-used model
            self.ai.session_manager.update_state(self.session_name, model=model)
        finally:
            self.ai.config.system_prompt = original_prompt

    def stream_run(self, message: str, auto_approve: bool = False):
        """Generator that yields SSE-style event dicts as the agent runs."""
        self.message_history.append({"role": "user", "content": message})
        context = self._build_context(message)
        iteration = 0
        tool_results = []
        content = ""
        total_tokens = {'input': 0, 'output': 0}
        previous_todo_ids = {item.id for item in self.todo_manager.list(self.session_name)}
        self.ai.session_manager.set_status(self.session_name, "running")

        try:
            while iteration < self.max_iterations:
                iteration += 1
                content = ""

                # Stream AI response token by token
                for chunk in self._call_ai_stream(context):
                    if chunk.get("error"):
                        self._finalize_git(success=False)
                        self.ai.session_manager.set_status(self.session_name, "error")
                        yield {"type": "result", "result": {"success": False, "error": chunk["error"]}}
                        return
                    delta = chunk.get("delta", "")
                    if delta:
                        content += delta
                        yield {"type": "assistant_chunk", "text": content}
                    if chunk.get("done"):
                        total_tokens['input'] = chunk.get("tokens_input", 0) or 0
                        total_tokens['output'] = chunk.get("tokens_output", 0) or 0

                tool_calls_parsed = self._parse_tool_calls(content)

                if not tool_calls_parsed:
                    self.message_history.append({"role": "assistant", "content": content})
                    self._finalize_git(success=True)
                    self.ai.session_manager.set_status(self.session_name, "completed")
                    todos = self.todo_manager.list(self.session_name)
                    new_todos = [item for item in todos if item.id not in previous_todo_ids]
                    yield {"type": "result", "result": self._success_payload(content, iteration, tool_results, todos, new_todos, total_tokens)}
                    return

                # Handle tool calls
                for i, tool_call in enumerate(tool_calls_parsed):
                    tool_name = tool_call['tool']
                    params = tool_call['params']
                    call_id = f"{iteration}_{i}_{tool_name}"

                    if self.step_count >= self.max_steps:
                        self._finalize_git(success=False)
                        self.ai.session_manager.set_status(self.session_name, "error")
                        yield {"type": "result", "result": {"success": False, "error": f"Max steps exceeded ({self.max_steps})", "iterations": iteration}}
                        return

                    loop_block = self._detect_doom_loop(tool_name, params)
                    if loop_block:
                        tool_results.append({'tool': tool_name, 'params': params, 'success': False, 'output': loop_block})
                        context += f"\n\n[Tool Result: {tool_name}]\nError: {loop_block}"
                        yield {"type": "tool_start", "call_id": call_id, "tool": tool_name, "args": params, "step": self.step_count}
                        yield {"type": "tool_result", "call_id": call_id, "output": loop_block, "success": False}
                        continue

                    if not auto_approve:
                        permission_error = self._enforce_permission(tool_name, params)
                        if permission_error:
                            self._finalize_git(success=False)
                            self.ai.session_manager.set_status(self.session_name, "error")
                            yield {"type": "result", "result": {"success": False, "error": permission_error, "iterations": iteration}}
                            return

                    yield {"type": "tool_start", "call_id": call_id, "tool": tool_name, "args": params, "step": self.step_count}

                    result = self._execute_tool(tool_name, params)
                    self.step_count += 1
                    tool_results.append({
                        'tool': tool_name, 'params': params, 'success': result.success,
                        'output': result.output[:500] if result.success else (result.error or result.output),
                    })

                    context += f"\n\n[Tool Result: {tool_name}]\n"
                    context += f"Success: {result.output[:500]}" if result.success else f"Error: {result.error or result.output}"

                    yield {"type": "tool_result", "call_id": call_id, "output": result.output if result.success else (result.error or result.output), "success": result.success}

                    if not result.success and self._is_mutating_tool(tool_name):
                        self._finalize_git(success=False)
                        self.ai.session_manager.set_status(self.session_name, "error")
                        yield {"type": "result", "result": {"success": False, "error": result.error or result.output, "iterations": iteration}}
                        return

                self.message_history.append({"role": "assistant", "content": content})

            # Max iterations reached
            self._finalize_git(success=True)
            self.ai.session_manager.set_status(self.session_name, "completed")
            todos = self.todo_manager.list(self.session_name)
            new_todos = [item for item in todos if item.id not in previous_todo_ids]
            payload = self._success_payload(content, iteration, tool_results, todos, new_todos, total_tokens)
            payload['note'] = 'Max iterations reached'
            yield {"type": "result", "result": payload}

        except Exception as exc:
            self.ai.session_manager.append_event(self.session_name, 'agent_error', {'error': str(exc)})
            self._finalize_git(success=False)
            self.ai.session_manager.set_status(self.session_name, "error")
            yield {"type": "result", "result": {"success": False, "error": str(exc), "iterations": iteration}}

    def run_with_progress(self, message: str, auto_approve: bool = False, on_tick: Optional[Callable[[Dict[str, Any]], None]] = None) -> Dict[str, Any]:
        import threading
        import time
        result_holder: Dict[str, Any] = {}
        error_holder: Dict[str, Any] = {}
        def worker():
            try:
                result_holder['result'] = self.run(message, auto_approve)
            except Exception as exc:
                error_holder['error'] = {'success': False, 'error': str(exc)}
        thread = threading.Thread(target=worker, daemon=True)
        thread.start()
        if on_tick:
            start_time = time.monotonic()
            while thread.is_alive():
                elapsed = time.monotonic() - start_time
                on_tick({'elapsed': elapsed})
                thread.join(0.05)
        else:
            thread.join()
        if error_holder:
            return error_holder['error']
        return copy.deepcopy(result_holder.get('result', {'success': False, 'error': 'No response from AI'}))
