# polymarket-price-feed

Multi-source real-time crypto price feed using Binance and CoinGecko in parallel.

Standalone re-export from [polymarket-trading-mcp](https://github.com/whitmorelabs/polymarket-mcp).

## Install

```bash
pip install polymarket-price-feed
```

## Usage

```python
from polymarket_price_feed import get_crypto_price
```

## Source

Part of [Whitmore Labs polymarket-mcp](https://github.com/whitmorelabs/polymarket-mcp).
