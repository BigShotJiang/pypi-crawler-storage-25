"""
polymarket-price-feed — Multi-source real-time crypto price feed.

Standalone re-export from polymarket-trading-mcp.
"""
from polymarket_mcp.tools.price_feed import get_crypto_price

__all__ = ["get_crypto_price"]
__version__ = "0.1.0"
