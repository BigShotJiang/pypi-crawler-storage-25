# Pipely Design System

Dark-first, data-dense monitoring UI. Minimal chrome, maximum information density. Built with Inter and CSS custom properties.

---

## Colors

All colors are defined as CSS custom properties on `:root`. The scheme is **dark only** (`color-scheme: dark`).

### Base surfaces

| Token | Hex | Usage |
|---|---|---|
| `--bg` | `#0c0e10` | Page/app background |
| `--surface` | `#141719` | Top bar, stat cards, chart cards |
| `--surface2` | `#191d21` | Sidebar items hover, buttons, step bodies, facts |

### Borders

| Token | Hex | Usage |
|---|---|---|
| `--border` | `#232a32` | Primary dividers, card borders |
| `--border2` | `#2d3540` | Secondary borders, button borders, step connectors |

### Text

| Token | Hex | Usage |
|---|---|---|
| `--text` | `#e2e8f0` | Primary text, headings |
| `--muted` | `#7c8fa3` | Secondary labels, metadata, placeholders |
| `--muted2` | `#4d5c6e` | Tertiary / disabled text |

### Semantic / accent

| Token | Hex | Usage |
|---|---|---|
| `--accent` | `#3b82f6` | Primary action color — active nav, primary buttons, run item active border, logo icon bg |
| `--accent-dim` | `#1e3a5f` | (reserved for future tinted backgrounds) |
| `--green` | `#22c55e` | Success / completed status, success values, success rate bar fill |
| `--green-dim` | `#14532d` | (reserved) |
| `--red` | `#ef4444` | Failed / error status, error text, danger buttons |
| `--red-dim` | `#450a0a` | (reserved) |
| `--purple` | `#a78bfa` | Cancelled / skipped status, avg-duration accent |
| `--purple-dim` | `#2d1b69` | (reserved) |
| `--yellow` | `#fbbf24` | Pending / waiting status |
| `--yellow-dim` | `#451a03` | (reserved) |

### Additional semantic color

- `#60a5fa` — Running state text/value (lighter blue, used inline without a token)
- `#fca5a5` — Error notice body text (light red for readability on dark notice bg)
- `#c9d3dd` — Code block text
- `#080a0c` — Code block background (darker than `--bg`)

### Chart palette

| Status | Color |
|---|---|
| Success / completed | `rgba(34,197,94,0.75)` |
| Failed | `rgba(239,68,68,0.75)` |
| Cancelled | `rgba(167,139,250,0.65)` |
| Duration bars | `rgba(167,139,250,0.75)` |
| Chart grid lines | `#1a2030` |

---

## Typography

**Font family:** `'Inter'`, `ui-sans-serif`, `system-ui`, `sans-serif`  
**Monospace:** `ui-monospace`, `'Cascadia Code'`, `'Fira Code'`, `SFMono-Regular`, `Menlo`, `monospace`

| Role | Size | Weight | Notes |
|---|---|---|---|
| Body / default | 13px | 400 | Base font size on `<body>` |
| Small / meta | 11px | 400–600 | Timestamps, labels, badges, section titles |
| Small code | 11.5px | 400 | Inside `<code>` blocks, line-height 1.6 |
| Button / nav tab | 12–13px | 500 | |
| Run name / step name | 13px | 500 | |
| Detail title | 18px | 600 | letter-spacing -0.3px |
| Logo | 15px | 600 | letter-spacing -0.3px |
| Stat value (big number) | 28px | 600 | letter-spacing -0.5px, line-height 1 |
| Chart title | 12px | 600 | letter-spacing -0.1px |
| Section / table header | 11px | 600 | uppercase, letter-spacing 0.06–0.08em |

---

## Spacing & Layout

- **Base unit:** 4px
- **Top bar height:** 56px
- **Sidebar width:** 320px
- **Content padding (detail panel):** `20px 24px`
- **Monitoring scroll padding:** `24px 28px 40px`
- **Stat cards gap:** 10px
- **Charts gap:** 14px
- **Section title margin:** `18px 0 8px`

### Grid

- App shell: `grid-template-rows: 56px 1fr`, full viewport height, no overflow
- Runs layout: `grid-template-columns: 320px 1fr`
- Facts row: `repeat(4, 1fr)`, gap 8px
- Stat cards: `repeat(5, 1fr)`, gap 10px
- Charts main row: `1fr 320px`, gap 14px
- Charts second row: `1fr 1fr`, gap 14px

---

## Border Radius

| Context | Radius |
|---|---|
| Logo icon, empty-state icon | 7–12px |
| Buttons | 6px |
| Badges / pill counters | 999px (full pill) |
| Cards (stat, chart, step body, facts) | 8–10px |
| Code blocks | 8px |
| Step meta tags | 4px |
| Scrollbar thumb | 3px |
| Rate bar track/fill | 2px |
| Step connector | — |

---

## Components

### Top Bar

- Height: 56px, `background: --surface`, bottom border `1px solid --border`
- Padding: `0 20px`, flex row with `gap: 12px`
- Logo: flex, gap 10px, font 15px/600, right padding 20px, right border `1px solid --border`
- **Logo icon:** 28×28px, `background: --accent`, border-radius 7px, white SVG icon 16×16

### Nav Tabs

- Placed inside top bar, padding-left 12px, gap 2px
- Inactive: color `--muted`, transparent bg and border, 5px 12px padding, border-radius 6px
- Hover: color `--text`, `background: --surface2`
- **Active:** color `--text`, `background: --surface2`, `border-color: --border2`
- Icon + label, icon 13×13px

### Badges (status pills)

Pill shape (`border-radius: 999px`), 11px/500, padding `3px 8px`.  
Dot indicator via `::before` pseudo-element (5×5px circle).

| Variant | Background | Text | Border |
|---|---|---|---|
| `completed` / `success` | green 12% | `--green` | green 25% |
| `failed` | red 12% | `--red` | red 25% |
| `running` / `retrying` | accent 12% | `#60a5fa` | accent 30% |
| `cancelled` / `skipped` | purple 12% | `--purple` | purple 25% |
| `pending` / `waiting` | yellow 10% | `--yellow` | yellow 25% |

Running/retrying dot pulses with `pulse-dot` animation (1s, opacity 1→0.3→1).

### Buttons

Default: `background: --surface2`, border `1px solid --border2`, border-radius 6px, padding `6px 12px`, 12px/500, min-height 32px.  
Hover: `background: #242b34`, `border-color: #3d4a58`.

| Variant | Style |
|---|---|
| Default | As above |
| `.primary` | `background: --accent`, border `#2563eb`, white text. Hover: `#2563eb` |
| `.danger` | Text `--red`, border red 30%. Hover: red 10% tinted bg |
| `.ghost` | Transparent bg + border, text `--muted`. Hover: surface2 bg, text, border2 |

### Sidebar Run Items

Padding `11px 14px`, bottom border `1px solid --border`, cursor pointer.  
Hover: `background: --surface2`.  
**Active:** `background: color-mix(--accent 8%, --surface2)`, `border-left: 2px solid --accent`, padding-left 12px.

Run name: 13px/500, truncated.  
Meta line: 11px, `--muted`.  
Error preview: 11px, `--red`, truncated.

### Run Count Badge

`background: --surface2`, border `1px solid --border2`, pill radius, padding `1px 7px`, 11px, `--muted`.

### Facts Grid

4-column grid, gap 8px. Each fact cell: `--surface2` bg, border `1px solid --border`, border-radius 8px, padding `10px 12px`.  
Label: 11px/600, uppercase, letter-spacing 0.06em, `--muted`.  
Value: 13px, `--text`.

### Stat Cards (Monitoring)

`background: --surface`, border `1px solid --border`, border-radius 10px, padding `16px 18px`, flex column gap 6px.  
Top accent stripe: `height: 2px`, color varies by variant (accent / green / red / `#60a5fa` / purple).

Label: 11px/600, uppercase, `--muted`.  
Value: 28px/600, letter-spacing -0.5px.  
Sub: 11px, `--muted`.

Colored value variants: `.success` → `--green`, `.failed` → `--red`, `.running` → `#60a5fa`, `.avg` → `--purple`.

### Chart Cards

`background: --surface`, border `1px solid --border`, border-radius 10px, padding `18px 20px 14px`, flex column gap 14px.  
Title: 12px/600. Subtitle: 11px, `--muted`, margin-top 2px.

### Step Timeline

Two-column grid: 32px connector column + 1fr body column.

**Step node:** 28×28px circle, border 2px, `--surface2` bg. Color by status (mirrors badge colors).  
**Connector:** 2px wide line, `--border2`, min-height 12px.  
**Step body:** `--surface2` bg, border `1px solid --border`, border-radius 8px, margin-bottom 10px. Border tinted by status on active states.

### Notice (error box)

Border-radius 8px, padding `10px 14px`, 12px, line-height 1.5, flex row gap 8px.  
Error variant: `background: red 8% + --surface2`, border red 25%, text `#fca5a5`.

### Code Blocks

`<pre>`: `background: #080a0c`, border `1px solid --border`, border-radius 8px, padding `12px 14px`, max-height 320px, scrollable.  
`<code>`: monospace, 11.5px, line-height 1.6, color `#c9d3dd`.

Details inside steps: `<summary>` has top border, 11px/500, `--muted`, with triangle arrow (`::before`). Hover: `--surface` bg.

### Section Titles

11px/600, uppercase, letter-spacing 0.08em, `--muted`. Extends a 1px `--border` line to the right via `::after { flex: 1 }`.

### Pipeline Table

Full-width, font 12px, border-collapse.  
Header: 11px/600, uppercase, letter-spacing 0.06em, `--muted`, padding `8px 12px`, bottom border.  
Cell: padding `9px 12px`, `--text`. Last row has no bottom border.  
Row hover: `background: --surface2` on all cells.  
Numeric cells (`.num`): right-aligned, tabular-nums.

### Rate Bar

Flex row, gap 8px. Track: `flex: 1`, height 4px, `--border2` bg, radius 2px, min-width 60px.  
Fill: height 100%, radius 2px, `transition: width 0.4s`.

| Fill variant | Color |
|---|---|
| Default (≥80%) | `--green` |
| `.mid` (50–79%) | `--yellow` |
| `.low` (<50%) | `--red` |

Label: 11px, `--muted`, min-width 32px, right-aligned.

### Scrollbars

Width/height 6px. Track: transparent. Thumb: `--border2`, radius 3px. Hover: `#3d4a58`.

### Refresh Indicator

Flex row, gap 6px, 12px, `--muted`. Animated dot: 6×6px green circle, `pulse-dot` 2s animation.

---

## Animations

```css
@keyframes pulse-dot {
  0%, 100% { opacity: 1; }
  50%       { opacity: 0.3; }
}
```

- Refresh dot: 2s duration (live indicator)
- Running badge dot: 1s duration (active pulse)

All Chart.js animations are **disabled** (`animation: false`) for a snappy data-dense feel.  
UI transitions are short: `0.1s–0.15s` for color/background changes.

---

## Responsive Breakpoints

| Breakpoint | Changes |
|---|---|
| `≤ 1100px` | Stat grid → 3 columns; Charts main row → 1 column |
| `≤ 900px` | App no longer fixed height; Sidebar stacks above main (1 col), max-height 320px; Facts → 2 col; Stat grid → 2 col; Charts row → 1 col |
| `≤ 560px` | Facts → 2 col (already), detail padding → 14px; Stat grid → 2 col |

---

## Design Principles

- **Dark only.** No light mode. Use `color-scheme: dark`.
- **Semantic color, not decorative.** Green = success, red = failure, blue = active/running, purple = cancelled, yellow = waiting. Never use these colors for arbitrary decoration.
- **Density over whitespace.** 13px base, compact padding, small gaps. This is a dashboard, not a marketing page.
- **Tinted surfaces, not solid fills.** Status backgrounds use `color-mix()` at 8–15% opacity over the base surface — subtle context without shouting.
- **Borders carry structure.** `--border` for primary layout dividers; `--border2` for interactive/secondary.
- **Muted by default, accent on interaction.** Navigation items, labels, and metadata start at `--muted`; they become `--text` on hover/active.
- **No decorative shadows.** Elevation is expressed through border color contrast, not drop shadows.
- **Consistent uppercase labels.** Section titles, column headers, stat labels, and fact labels use `text-transform: uppercase` with positive letter-spacing (0.06–0.08em) at 11px/600.
