# Публикация новой версии на PyPI

## Перед публикацией

1. Обнови версию в `pyproject.toml`:
   ```toml
   version = "0.2.0"
   ```

2. Добавь запись в `CHANGELOG.md`.

3. Убедись что тесты проходят:
   ```bash
   python -m pytest tests/
   ```

## Сборка и загрузка

```bash
# Удали старые артефакты
rm -rf dist/

# Собери
hatch build

# Проверь
twine check dist/*

# Загрузи на PyPI
twine upload dist/*
# Username: __token__
# Password: pypi-ВАШ_ТОКЕН
```

## Настройка токена (один раз)

Создай `~/.pypirc` чтобы не вводить токен каждый раз:

```ini
[pypi]
username = __token__
password = pypi-ВАШ_ТОКЕН
```

Токен получить/обновить: https://pypi.org/manage/account/token/

## Страница пакета

https://pypi.org/project/pipely-core/
