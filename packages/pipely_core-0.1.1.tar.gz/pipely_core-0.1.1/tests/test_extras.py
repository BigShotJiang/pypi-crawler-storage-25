from __future__ import annotations

import pytest
import anyio

from pipely import PipelineContext, Pipely, step
from pipely.exceptions import InvalidRunStateError


@pytest.fixture
def pipely_instance() -> Pipely:
    return Pipely(database_url="sqlite+aiosqlite:///:memory:")


# ---------------------------------------------------------------------------
# cancel
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_cancel_pending_run(pipely_instance: Pipely) -> None:
    await pipely_instance.init()

    @pipely_instance.pipeline("cancel_test")
    class CancelPipeline:
        @step()
        async def slow(self, ctx: PipelineContext) -> None:
            await anyio.sleep(10)

    run = await pipely_instance.storage.create_run("cancel_test", {})
    await pipely_instance.cancel(run.id)
    refreshed = await pipely_instance.storage.get_run(run.id)
    assert refreshed.status == "cancelled"


@pytest.mark.anyio
async def test_cancel_terminal_run_raises(pipely_instance: Pipely) -> None:
    @pipely_instance.pipeline("cancel_done")
    class DonePipeline:
        @step()
        async def noop(self, ctx: PipelineContext) -> None:
            pass

    run = await pipely_instance.start("cancel_done", input={})
    assert run.status == "completed"

    with pytest.raises(InvalidRunStateError):
        await pipely_instance.cancel(run.id)


# ---------------------------------------------------------------------------
# submit (background execution)
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_submit_runs_in_background(pipely_instance: Pipely) -> None:
    @pipely_instance.pipeline("bg")
    class BgPipeline:
        @step()
        async def work(self, ctx: PipelineContext) -> None:
            ctx.set("done", True)

    async with anyio.create_task_group() as tg:
        pipely_instance._task_group = tg
        await pipely_instance.init()
        pending = await pipely_instance.submit("bg", input={})
        assert pending.status == "pending"
        # give the background task a moment to finish
        await anyio.sleep(0.2)
        tg.cancel_scope.cancel()

    finished = await pipely_instance.storage.get_run(pending.id)
    assert finished.status == "completed"
    assert finished.state["done"] is True


# ---------------------------------------------------------------------------
# ctx.log
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_ctx_log_persists_entries(pipely_instance: Pipely) -> None:
    @pipely_instance.pipeline("logging")
    class LogPipeline:
        @step()
        async def logged(self, ctx: PipelineContext) -> None:
            await ctx.log("hello", level="info", payload={"x": 1})
            await ctx.log("warn", level="warning")

    run = await pipely_instance.start("logging", input={})
    logs = await pipely_instance.storage.list_logs(run.id)

    assert len(logs) == 2
    assert logs[0].message == "hello"
    assert logs[0].level == "info"
    assert logs[0].payload == {"x": 1}
    assert logs[1].level == "warning"


# ---------------------------------------------------------------------------
# ctx.flush
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_ctx_flush_persists_mid_step(pipely_instance: Pipely) -> None:
    flushed_state: dict = {}

    @pipely_instance.pipeline("flush_test")
    class FlushPipeline:
        @step()
        async def long_step(self, ctx: PipelineContext) -> None:
            ctx.set("mid", True)
            await ctx.flush()
            # capture state from DB right after flush
            run = await pipely_instance.storage.get_run(ctx.run_id)
            flushed_state.update(run.state)

    await pipely_instance.start("flush_test", input={})
    assert flushed_state.get("mid") is True


# ---------------------------------------------------------------------------
# error scenarios
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_start_unknown_pipeline_raises(pipely_instance: Pipely) -> None:
    from pipely.exceptions import PipelineNotFoundError
    with pytest.raises(PipelineNotFoundError):
        await pipely_instance.start("nonexistent", input={})


@pytest.mark.anyio
async def test_restart_from_unknown_step_raises(pipely_instance: Pipely) -> None:
    from pipely.exceptions import StepNotFoundError

    @pipely_instance.pipeline("restart_err")
    class P:
        @step()
        async def only(self, ctx: PipelineContext) -> None:
            pass

    run = await pipely_instance.start("restart_err", input={})
    with pytest.raises(StepNotFoundError):
        await pipely_instance.restart_from_step(run.id, "no_such_step")


@pytest.mark.anyio
async def test_retry_failed_on_completed_run_raises(pipely_instance: Pipely) -> None:
    @pipely_instance.pipeline("retry_done")
    class P:
        @step()
        async def noop(self, ctx: PipelineContext) -> None:
            pass

    run = await pipely_instance.start("retry_done", input={})
    with pytest.raises(InvalidRunStateError):
        await pipely_instance.retry_failed(run.id)


# ---------------------------------------------------------------------------
# REST API
# ---------------------------------------------------------------------------

@pytest.mark.anyio
async def test_api_start_and_get_run() -> None:
    from fastapi import FastAPI
    from httpx import AsyncClient, ASGITransport

    app = FastAPI()
    engine = Pipely(database_url="sqlite+aiosqlite:///:memory:")

    @engine.pipeline("api_test")
    class ApiPipeline:
        @step()
        async def work(self, ctx: PipelineContext) -> None:
            ctx.set("result", 42)

    engine.mount(app)

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        # start a run
        resp = await client.post("/_pipely/api/runs", json={"pipeline_name": "api_test", "input": {}})
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "completed"
        assert data["state"]["result"] == 42
        run_id = data["id"]

        # get the run
        resp2 = await client.get(f"/_pipely/api/runs/{run_id}")
        assert resp2.status_code == 200
        assert resp2.json()["id"] == run_id

        # list runs
        resp3 = await client.get("/_pipely/api/runs")
        assert resp3.status_code == 200
        assert any(r["id"] == run_id for r in resp3.json())

        # 404 for unknown pipeline
        resp4 = await client.post("/_pipely/api/runs", json={"pipeline_name": "nope", "input": {}})
        assert resp4.status_code == 404

        # cancel already-completed run → 409
        resp5 = await client.post(f"/_pipely/api/runs/{run_id}/cancel")
        assert resp5.status_code == 409
