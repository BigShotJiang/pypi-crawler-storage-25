from __future__ import annotations

import pytest

from pipely import PipelineContext, Pipely, step


@pytest.fixture
def pipely() -> Pipely:
    return Pipely(database_url="sqlite+aiosqlite:///:memory:")


@pytest.mark.anyio
async def test_start_runs_linear_pipeline(pipely: Pipely) -> None:
    @pipely.pipeline("ok")
    class OkPipeline:
        @step(retries=1)
        async def first(self, ctx: PipelineContext) -> None:
            ctx.set("first", ctx.input["value"] + 1)

        @step(retries=1)
        async def second(self, ctx: PipelineContext) -> None:
            ctx.set("second", ctx.get("first") + 1)

    run = await pipely.start("ok", input={"value": 1})

    assert run.status == "completed"
    assert run.state == {"first": 2, "second": 3}
    assert [s.status for s in run.steps] == ["success", "success"]


@pytest.mark.anyio
async def test_retries_then_completes(pipely: Pipely) -> None:
    calls = {"flaky": 0}

    @pipely.pipeline("flaky")
    class FlakyPipeline:
        @step(retries=2)
        async def flaky(self, ctx: PipelineContext) -> None:
            calls["flaky"] += 1
            if calls["flaky"] < 2:
                raise RuntimeError("temporary")
            ctx.set("ok", True)

    run = await pipely.start("flaky", input={})

    assert run.status == "completed"
    assert run.steps[0].attempt == 2
    assert run.state["ok"] is True


@pytest.mark.anyio
async def test_retry_failed_restarts_failed_and_following_steps(pipely: Pipely) -> None:
    calls = {"bad": 0, "after": 0}

    @pipely.pipeline("retry")
    class RetryPipeline:
        @step(retries=0)
        async def first(self, ctx: PipelineContext) -> None:
            ctx.set("first", True)

        @step(retries=0)
        async def bad(self, ctx: PipelineContext) -> None:
            calls["bad"] += 1
            if calls["bad"] == 1:
                raise RuntimeError("boom")
            ctx.set("bad", True)

        @step(retries=0)
        async def after(self, ctx: PipelineContext) -> None:
            calls["after"] += 1
            ctx.set("after", True)

    failed = await pipely.start("retry", input={})
    assert failed.status == "failed"
    assert calls["after"] == 0

    completed = await pipely.retry_failed(failed.id)

    assert completed.status == "completed"
    assert completed.state == {"first": True, "bad": True, "after": True}
    assert calls == {"bad": 2, "after": 1}


@pytest.mark.anyio
async def test_resume_skips_success_steps(pipely: Pipely) -> None:
    calls = {"first": 0, "second": 0}

    @pipely.pipeline("resume")
    class ResumePipeline:
        @step(retries=0)
        async def first(self, ctx: PipelineContext) -> None:
            calls["first"] += 1
            ctx.set("first", True)

        @step(retries=0)
        async def second(self, ctx: PipelineContext) -> None:
            calls["second"] += 1
            if calls["second"] == 1:
                raise RuntimeError("fail once")
            ctx.set("second", True)

    failed = await pipely.start("resume", input={})
    completed = await pipely.resume(failed.id)

    assert completed.status == "completed"
    assert calls == {"first": 1, "second": 2}


@pytest.mark.anyio
async def test_restart_from_step(pipely: Pipely) -> None:
    calls = {"first": 0, "second": 0}

    @pipely.pipeline("restart")
    class RestartPipeline:
        @step()
        async def first(self, ctx: PipelineContext) -> None:
            calls["first"] += 1
            ctx.set("first", calls["first"])

        @step()
        async def second(self, ctx: PipelineContext) -> None:
            calls["second"] += 1
            ctx.set("second", calls["second"])

    run = await pipely.start("restart", input={})
    restarted = await pipely.restart_from_step(run.id, "second")

    assert restarted.status == "completed"
    assert restarted.state == {"first": 1, "second": 2}
    assert calls == {"first": 1, "second": 2}


@pytest.mark.anyio
async def test_step_timeout_triggers_retry(pipely: Pipely) -> None:
    calls = {"slow": 0}

    @pipely.pipeline("timeout_retry")
    class TimeoutRetryPipeline:
        @step(retries=1, timeout=0.05)
        async def slow(self, ctx: PipelineContext) -> None:
            import anyio
            calls["slow"] += 1
            if calls["slow"] == 1:
                await anyio.sleep(1.0)
            ctx.set("done", True)

    run = await pipely.start("timeout_retry", input={})

    assert run.status == "completed"
    assert calls["slow"] == 2
    assert run.state["done"] is True
