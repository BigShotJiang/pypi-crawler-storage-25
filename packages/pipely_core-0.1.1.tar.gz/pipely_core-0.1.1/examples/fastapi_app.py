import asyncio
import random
from contextlib import asynccontextmanager

from fastapi import FastAPI

from pipely import PipelineContext, Pipely, step

pipely = Pipely(
    database_url="postgresql+asyncpg://postgres:postgres@localhost:5432/postgres",
    ui_path="/_pipely",
)


@pipely.pipeline("meeting_protocol")
class MeetingProtocolPipeline:
    @step(retries=2, timeout=35.0)
    async def transcribe(self, ctx: PipelineContext) -> None:
        await asyncio.sleep(random.uniform(5.0, 30.0))
        if random.random() < 0.30:
            raise RuntimeError("STT timeout — внешний сервис не ответил")
        ctx.set("transcript", f"Transcript for {ctx.input['audio_url']}")
        await ctx.log("audio transcribed")

    @step(retries=2, timeout=15.0)
    async def clean_transcript(self, ctx: PipelineContext) -> None:
        await asyncio.sleep(random.uniform(1.0, 5.0))
        if random.random() < 0.20:
            raise ValueError("transcript is empty or malformed")
        ctx.set("clean_transcript", ctx.get("transcript").strip())
        await ctx.log("transcript cleaned")

    @step(retries=2, timeout=15.0)
    async def extract_tasks(self, ctx: PipelineContext) -> None:
        await asyncio.sleep(random.uniform(1.0, 4.0))
        if random.random() < 0.15:
            raise RuntimeError("LLM quota exceeded")
        ctx.set("tasks", [{"title": "Send meeting notes", "owner": "ops"}])
        await ctx.log("tasks extracted", payload={"count": 1})


@pipely.pipeline("broken_protocol")
class BrokenProtocol:
    @step(retries=0)
    async def transcribe(self, ctx: PipelineContext) -> None:
        raise RuntimeError("STT сервис недоступен")

    @step(retries=0)
    async def clean_transcript(self, ctx: PipelineContext) -> None:
        ctx.set("clean", "done")


@asynccontextmanager
async def lifespan(app: FastAPI):
    async with pipely.lifespan(app):
        yield


app = FastAPI(lifespan=lifespan)
pipely.mount(app)


@app.post("/meetings/protocol")
async def create_protocol(audio_url: str) -> dict[str, str]:
    """Start a pipeline run in the background and return the run_id immediately."""
    run = await pipely.submit("meeting_protocol", input={"audio_url": audio_url})
    return {"run_id": str(run.id), "status": run.status}
