"""
Load test for Pipely / MeetingProtocolPipeline.

Запуск:
    python examples/load_test.py
"""
import asyncio
import time
from collections import Counter
from dataclasses import dataclass, field

import httpx

BASE = "http://127.0.0.1:8000"
API  = f"{BASE}/_pipely/api"

CONCURRENCY   = 10    # параллельных запросов на старт
TOTAL_RUNS    = 30    # всего ранов
POLL_INTERVAL = 0.3   # секунд между опросами статуса
POLL_TIMEOUT  = 60    # максимум секунд ждать завершения рана


@dataclass
class RunResult:
    run_id: str
    final_status: str
    retried: bool = False
    error: str | None = None
    duration: float = 0.0
    step_attempts: dict[str, int] = field(default_factory=dict)


async def start_run(client: httpx.AsyncClient, index: int) -> str:
    r = await client.post(
        f"{BASE}/meetings/protocol",
        params={"audio_url": f"meeting_{index:03d}.mp3"},
    )
    r.raise_for_status()
    return r.json()["run_id"]


async def poll_until_done(client: httpx.AsyncClient, run_id: str) -> dict:
    deadline = time.monotonic() + POLL_TIMEOUT
    while time.monotonic() < deadline:
        r = await client.get(f"{API}/runs/{run_id}")
        data = r.json()
        if data["status"] not in ("pending", "running"):
            return data
        await asyncio.sleep(POLL_INTERVAL)
    raise TimeoutError(f"run {run_id} did not finish in {POLL_TIMEOUT}s")


async def handle_run(client: httpx.AsyncClient, index: int, sem: asyncio.Semaphore) -> RunResult:
    async with sem:
        t0 = time.monotonic()
        run_id = await start_run(client, index)

    data = await poll_until_done(client, run_id)
    retried = False

    if data["status"] == "failed":
        # авто-ретрай через API
        r = await client.post(f"{API}/runs/{run_id}/retry")
        if r.status_code == 200:
            retried = True
            data = await poll_until_done(client, run_id)

    duration = time.monotonic() - t0
    step_attempts = {s["step_name"]: s["attempt"] for s in data.get("steps", [])}

    return RunResult(
        run_id=run_id,
        final_status=data["status"],
        retried=retried,
        error=data.get("error"),
        duration=round(duration, 2),
        step_attempts=step_attempts,
    )


def print_report(results: list[RunResult], total_time: float) -> None:
    statuses = Counter(r.final_status for r in results)
    retried  = sum(1 for r in results if r.retried)
    durations = [r.duration for r in results]
    avg_dur = sum(durations) / len(durations)
    max_dur = max(durations)
    min_dur = min(durations)

    # суммарные попытки по шагам
    step_totals: Counter = Counter()
    for r in results:
        for step, att in r.step_attempts.items():
            step_totals[step] += att

    print("\n" + "═" * 56)
    print(f"  Нагрузочный тест  •  {len(results)} ранов  •  {total_time:.1f}с")
    print("═" * 56)
    print(f"  completed : {statuses.get('completed', 0):>4}")
    print(f"  failed    : {statuses.get('failed', 0):>4}")
    print(f"  cancelled : {statuses.get('cancelled', 0):>4}")
    print(f"  авто-ретраи : {retried:>3}")
    print("─" * 56)
    print(f"  время: min={min_dur:.1f}s  avg={avg_dur:.1f}s  max={max_dur:.1f}s")
    print("─" * 56)
    print("  попыток на шаг (суммарно):")
    for step, total in step_totals.most_common():
        runs_with_step = sum(1 for r in results if step in r.step_attempts)
        avg = total / runs_with_step if runs_with_step else 0
        print(f"    {step:<22} всего={total:>3}  avg/ран={avg:.2f}")
    print("─" * 56)
    failed_runs = [r for r in results if r.final_status == "failed"]
    if failed_runs:
        print("  упавшие раны (первые 5):")
        for r in failed_runs[:5]:
            print(f"    {r.run_id}  {r.error or '—'}")
    print("═" * 56)


async def main() -> None:
    sem = asyncio.Semaphore(CONCURRENCY)
    t0 = time.monotonic()

    async with httpx.AsyncClient(timeout=120) as client:
        tasks = [
            asyncio.create_task(handle_run(client, i, sem))
            for i in range(TOTAL_RUNS)
        ]
        results: list[RunResult] = []
        for coro in asyncio.as_completed(tasks):
            result = await coro
            symbol = "✓" if result.final_status == "completed" else "✗"
            retry_mark = " (retried)" if result.retried else ""
            print(f"  {symbol} {result.run_id[:8]}…  {result.final_status:<10} {result.duration:.1f}s{retry_mark}")
            results.append(result)

    print_report(results, time.monotonic() - t0)


if __name__ == "__main__":
    asyncio.run(main())
