from __future__ import annotations

import inspect
import traceback as traceback_module
import uuid
from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

import anyio
import anyio.abc

from pipely.context import PipelineContext
from pipely.decorators import StepDefinition
from pipely.exceptions import RunCancelledError
from pipely.models import PipelineStatus, StepStatus
from pipely.storage import Storage

if TYPE_CHECKING:
    pass


@dataclass(frozen=True, slots=True)
class PipelineDefinition:
    """Internal registered pipeline metadata."""

    name: str
    cls: type[Any]
    steps: tuple[StepDefinition, ...]


class InProcessExecutor:
    """Sequential in-process pipeline executor backed by anyio.

    Runs steps inside the calling task group. Each run gets its own
    ``CancelScope`` registered with the owner ``Pipely`` instance so that
    ``cancel()`` can interrupt a running step immediately rather than waiting
    for the next between-step check.

    Per-step timeouts are applied via ``anyio.fail_after`` when a
    ``StepDefinition.timeout`` is set.
    """

    def __init__(self, storage: Storage, cancel_scope_registry: dict[uuid.UUID, anyio.CancelScope]) -> None:
        self.storage = storage
        self._cancel_scopes = cancel_scope_registry

    async def execute(
        self,
        pipeline: PipelineDefinition,
        run_id: uuid.UUID,
        *,
        start_step: str | None = None,
        completion_event: anyio.Event | None = None,
    ) -> None:
        """Execute a pipeline run inside the current task.

        Args:
            pipeline: Registered pipeline definition.
            run_id: Existing pipeline run UUID.
            start_step: Optional step name to start from. Earlier steps are
                skipped.
            completion_event: If provided, set after execution finishes
                (success or failure) so that a waiting caller can unblock.
        """

        await self.storage.mark_running_steps_failed(run_id)
        run = await self.storage.mark_run_running(run_id)
        instance = pipeline.cls()
        started = start_step is None

        with anyio.CancelScope() as scope:
            self._cancel_scopes[run_id] = scope
            try:
                for definition in pipeline.steps:
                    if start_step == definition.name:
                        started = True
                    if not started:
                        continue

                    run = await self.storage.get_run(run_id)
                    if run.status == PipelineStatus.CANCELLED:
                        raise RunCancelledError("run was cancelled")

                    step_run = await self.storage.upsert_step_waiting(
                        run_id, definition.name, definition.retries
                    )
                    if step_run.status == StepStatus.SUCCESS and not start_step:
                        continue

                    await self._execute_step(instance, pipeline, definition, run_id)

                if not scope.cancelled_caught:
                    latest = await self.storage.get_run(run_id)
                    await self.storage.mark_run_completed(run_id, dict(latest.state))
            except RunCancelledError as exc:
                await self.storage.mark_run_failed(run_id, str(exc))
                await self.storage.cancel_run(run_id)
            except Exception as exc:
                await self.storage.mark_run_failed(run_id, str(exc))
            finally:
                self._cancel_scopes.pop(run_id, None)
                if completion_event is not None:
                    completion_event.set()

        if scope.cancelled_caught:
            await self.storage.cancel_run(run_id)

    async def _execute_step(
        self,
        instance: Any,
        pipeline: PipelineDefinition,
        definition: StepDefinition,
        run_id: uuid.UUID,
    ) -> None:
        step_run = await self.storage.upsert_step_waiting(run_id, definition.name, definition.retries)
        while step_run.attempt <= definition.retries:
            run = await self.storage.get_run(run_id)
            context = PipelineContext(
                storage=self.storage,
                run_id=run.id,
                pipeline_name=pipeline.name,
                input=dict(run.input),
                state=dict(run.state),
                step_name=definition.name,
            )
            attempt = step_run.attempt + 1
            await self.storage.mark_step_running(step_run.id, dict(context.state), attempt)
            try:
                result = definition.func(instance, context)
                if not inspect.isawaitable(result):
                    raise TypeError(f"step {definition.name!r} must be async")
                if definition.timeout is not None:
                    with anyio.fail_after(definition.timeout):
                        await result
                else:
                    await result
                await context.flush()
                await self.storage.mark_step_success(step_run.id, dict(context.state))
                return
            except Exception as exc:
                tb = traceback_module.format_exc()
                await self.storage.mark_step_failed(step_run.id, str(exc), tb)
                step_run = await self.storage.get_step_run(run_id, definition.name)
                if step_run is None or step_run.attempt > definition.retries:
                    raise
