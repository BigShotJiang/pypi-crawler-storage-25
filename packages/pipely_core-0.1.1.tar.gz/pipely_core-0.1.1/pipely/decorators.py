from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any


StepCallable = Callable[[Any, Any], Awaitable[None]]


@dataclass(frozen=True, slots=True)
class StepDefinition:
    """Internal metadata for a decorated pipeline step."""

    name: str
    func: StepCallable
    retries: int = 0
    timeout: float | None = None


def step(
    *, retries: int = 0, name: str | None = None, timeout: float | None = None
) -> Callable[[StepCallable], StepCallable]:
    """Mark an async method as a pipeline step.

    Args:
        retries: Number of retries after the first failed execution. For
            example, ``retries=3`` means up to four total executions: the
            initial attempt plus three retries.
        name: Optional stable step name. Defaults to the method name.
        timeout: Optional wall-clock timeout in seconds for each individual
            attempt. Raises ``TimeoutError`` on expiry, which counts as a
            failure and triggers the retry logic.

    Returns:
        A decorator for async instance methods that receive
        ``PipelineContext``.

    Example:
        >>> @step(retries=2, timeout=30.0)
        ... async def extract(self, ctx: PipelineContext) -> None:
        ...     ctx.set("items", [])
    """

    if retries < 0:
        raise ValueError("retries must be >= 0")
    if timeout is not None and timeout <= 0:
        raise ValueError("timeout must be > 0")

    def decorator(func: StepCallable) -> StepCallable:
        setattr(
            func,
            "__pipely_step__",
            StepDefinition(name=name or func.__name__, func=func, retries=retries, timeout=timeout),
        )
        return func

    return decorator
