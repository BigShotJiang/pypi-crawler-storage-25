from __future__ import annotations

import uuid

from fastapi import APIRouter, HTTPException

from pipely.exceptions import (
    InvalidRunStateError,
    PipelineNotFoundError,
    PipelyError,
    RunNotFoundError,
    StepNotFoundError,
)
from pipely.schemas import PipelineRunOut, RestartFromStepIn, StartRunIn, StepLogOut


def build_router(pipely: object) -> APIRouter:
    router = APIRouter(tags=["pipely"])

    @router.get("/runs", response_model=list[PipelineRunOut])
    async def list_runs() -> list[PipelineRunOut]:
        runs = await pipely.storage.list_runs()  # type: ignore[attr-defined]
        return [PipelineRunOut.model_validate(run) for run in runs]

    @router.post("/runs", response_model=PipelineRunOut)
    async def start_run(payload: StartRunIn) -> PipelineRunOut:
        try:
            run = await pipely.start(payload.pipeline_name, input=payload.input)  # type: ignore[attr-defined]
            return await _run_out(pipely, run.id)
        except (PipelineNotFoundError, StepNotFoundError) as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except PipelyError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @router.get("/runs/{run_id}", response_model=PipelineRunOut)
    async def get_run(run_id: uuid.UUID) -> PipelineRunOut:
        try:
            return await _run_out(pipely, run_id)
        except (RunNotFoundError, PipelineNotFoundError, StepNotFoundError) as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    @router.post("/runs/{run_id}/retry", response_model=PipelineRunOut)
    async def retry_run(run_id: uuid.UUID) -> PipelineRunOut:
        return await _action(pipely.retry_failed, run_id)  # type: ignore[attr-defined]

    @router.post("/runs/{run_id}/resume", response_model=PipelineRunOut)
    async def resume_run(run_id: uuid.UUID) -> PipelineRunOut:
        return await _action(pipely.resume, run_id)  # type: ignore[attr-defined]

    @router.post("/runs/{run_id}/restart-from-step", response_model=PipelineRunOut)
    async def restart_from_step(run_id: uuid.UUID, payload: RestartFromStepIn) -> PipelineRunOut:
        return await _action(pipely.restart_from_step, run_id, payload.step_name)  # type: ignore[attr-defined]

    @router.post("/runs/{run_id}/cancel")
    async def cancel_run(run_id: uuid.UUID) -> dict[str, str]:
        try:
            await pipely.cancel(run_id)  # type: ignore[attr-defined]
            return {"status": "cancelled"}
        except (RunNotFoundError,) as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except InvalidRunStateError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        except PipelyError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    return router


async def _action(func: object, *args: object) -> PipelineRunOut:
    try:
        run = await func(*args)  # type: ignore[misc]
        return PipelineRunOut.model_validate(run)
    except (RunNotFoundError, PipelineNotFoundError, StepNotFoundError) as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except InvalidRunStateError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except PipelyError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


async def _run_out(pipely: object, run_id: uuid.UUID) -> PipelineRunOut:
    run = await pipely.storage.get_run(run_id, with_steps=True)  # type: ignore[attr-defined]
    logs = await pipely.storage.list_logs(run_id)  # type: ignore[attr-defined]
    output = PipelineRunOut.model_validate(run)
    output.logs = [StepLogOut.model_validate(log) for log in logs]
    return output
