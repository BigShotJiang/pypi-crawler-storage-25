from __future__ import annotations

import uuid
from typing import Any

from pipely.storage import Storage


class PipelineContext:
    """Runtime object passed to each pipeline step.

    The context is the only object business code usually needs. It exposes the
    original run input and the mutable pipeline state.

    Attributes:
        run_id: UUID of the current pipeline run.
        pipeline_name: Registered pipeline name.
        input: JSON-like input dict passed to ``pipely.start``.
        state: JSON-like mutable state shared by all steps in the run.
        step_name: Name of the currently executing step, when available.

    State persistence:
        ``ctx.set(...)`` updates the in-memory state and marks it dirty. Pipely
        flushes dirty state automatically after a successful step. Call
        ``await ctx.flush()`` inside a long step when intermediate state should
        be persisted before the step returns.
    """

    def __init__(
        self,
        *,
        storage: Storage,
        run_id: uuid.UUID,
        pipeline_name: str,
        input: dict[str, Any],
        state: dict[str, Any],
        step_name: str | None = None,
    ) -> None:
        self._storage = storage
        self.run_id = run_id
        self.pipeline_name = pipeline_name
        self.input = input
        self.state = state
        self.step_name = step_name
        self._dirty = False

    def get(self, key: str, default: Any = None) -> Any:
        """Return a value from pipeline state.

        Args:
            key: State key.
            default: Value returned when the key is missing.
        """

        return self.state.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """Set a value in pipeline state.

        Values should be JSON-serializable because state is persisted to a JSON
        database column. The change is saved after the step succeeds or earlier
        if ``flush`` is called explicitly.
        """

        self.state[key] = value
        self._dirty = True

    async def flush(self) -> None:
        """Persist dirty pipeline state to the database immediately."""

        if self._dirty:
            await self._storage.update_run_state(self.run_id, self.state)
            self._dirty = False

    async def log(
        self, message: str, level: str = "info", payload: dict[str, Any] | None = None
    ) -> None:
        """Write a structured log entry for the current run and step.

        Args:
            message: Human-readable log message.
            level: Log level string such as ``"debug"``, ``"info"``,
                ``"warning"``, or ``"error"``.
            payload: Optional JSON-serializable details.
        """

        await self._storage.add_log(
            run_id=self.run_id,
            step_name=self.step_name,
            level=level,
            message=message,
            payload=payload,
        )
