from pipely.models import Base

__all__ = ["Base"]
