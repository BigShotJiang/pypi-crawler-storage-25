"""Bundled static assets for the built-in Pipely UI."""
