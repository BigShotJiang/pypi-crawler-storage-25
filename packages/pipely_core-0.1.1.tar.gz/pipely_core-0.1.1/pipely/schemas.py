from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict


class StepRunOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    run_id: uuid.UUID
    step_name: str
    status: str
    attempt: int
    max_retries: int
    input_snapshot: dict[str, Any] | None
    output_snapshot: dict[str, Any] | None
    error: str | None
    traceback: str | None
    started_at: datetime | None
    finished_at: datetime | None
    updated_at: datetime


class StepLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    run_id: uuid.UUID
    step_name: str | None
    level: str
    message: str
    payload: dict[str, Any] | None
    created_at: datetime


class PipelineRunOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    pipeline_name: str
    status: str
    input: dict[str, Any]
    state: dict[str, Any]
    result: dict[str, Any] | None
    error: str | None
    created_at: datetime
    started_at: datetime | None
    finished_at: datetime | None
    updated_at: datetime
    steps: list[StepRunOut] = []
    logs: list[StepLogOut] = []


class RestartFromStepIn(BaseModel):
    step_name: str


class StartRunIn(BaseModel):
    pipeline_name: str
    input: dict[str, Any] = {}
