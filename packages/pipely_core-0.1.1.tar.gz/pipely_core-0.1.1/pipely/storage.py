from __future__ import annotations

import uuid
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import Select, delete, select
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import selectinload

from pipely.exceptions import RunNotFoundError
from pipely.models import Base, PipelineRun, PipelineStatus, StepLog, StepRun, StepStatus


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Storage:
    def __init__(
        self,
        *,
        database_url: str | None = None,
        engine: AsyncEngine | None = None,
        sessionmaker: async_sessionmaker[AsyncSession] | None = None,
    ) -> None:
        if sessionmaker is None and engine is None and database_url is None:
            raise ValueError("database_url, engine, or sessionmaker is required")
        self.engine = engine or create_async_engine(str(database_url), future=True)
        self.sessionmaker = sessionmaker or async_sessionmaker(self.engine, expire_on_commit=False)

    async def create_tables(self) -> None:
        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

    @asynccontextmanager
    async def session(self) -> AsyncIterator[AsyncSession]:
        async with self.sessionmaker() as session:
            yield session

    async def create_run(self, pipeline_name: str, input: dict[str, Any]) -> PipelineRun:
        async with self.sessionmaker() as session:
            run = PipelineRun(
                pipeline_name=pipeline_name,
                status=PipelineStatus.PENDING,
                input=input,
                state={},
                result=None,
                error=None,
            )
            session.add(run)
            await session.commit()
            await session.refresh(run)
            return run

    async def get_run(self, run_id: uuid.UUID, *, with_steps: bool = False) -> PipelineRun:
        async with self.sessionmaker() as session:
            stmt: Select[tuple[PipelineRun]] = select(PipelineRun).where(PipelineRun.id == run_id)
            if with_steps:
                stmt = stmt.options(selectinload(PipelineRun.steps))
            run = (await session.execute(stmt)).scalar_one_or_none()
            if run is None:
                raise RunNotFoundError(f"run not found: {run_id}")
            if with_steps:
                run.steps.sort(key=lambda step: step.started_at or step.updated_at)
            return run

    async def list_runs(self, *, limit: int = 100) -> list[PipelineRun]:
        async with self.sessionmaker() as session:
            result = await session.execute(
                select(PipelineRun)
                .options(selectinload(PipelineRun.steps))
                .order_by(PipelineRun.created_at.desc())
                .limit(limit)
            )
            return list(result.scalars().all())

    async def update_run_state(self, run_id: uuid.UUID, state: dict[str, Any]) -> None:
        async with self.sessionmaker() as session:
            run = await session.get(PipelineRun, run_id)
            if run is None:
                raise RunNotFoundError(f"run not found: {run_id}")
            run.state = dict(state)
            run.updated_at = utcnow()
            await session.commit()

    async def mark_run_running(self, run_id: uuid.UUID) -> PipelineRun:
        async with self.sessionmaker() as session:
            run = await self._get_run_in_session(session, run_id)
            run.status = PipelineStatus.RUNNING
            run.error = None
            run.started_at = run.started_at or utcnow()
            run.finished_at = None
            run.updated_at = utcnow()
            await session.commit()
            await session.refresh(run)
            return run

    async def mark_run_completed(self, run_id: uuid.UUID, result: dict[str, Any]) -> None:
        async with self.sessionmaker() as session:
            run = await self._get_run_in_session(session, run_id)
            run.status = PipelineStatus.COMPLETED
            run.result = result
            run.error = None
            run.finished_at = utcnow()
            run.updated_at = utcnow()
            await session.commit()

    async def mark_run_failed(self, run_id: uuid.UUID, error: str) -> None:
        async with self.sessionmaker() as session:
            run = await self._get_run_in_session(session, run_id)
            run.status = PipelineStatus.FAILED
            run.error = error
            run.finished_at = utcnow()
            run.updated_at = utcnow()
            await session.commit()

    async def cancel_run(self, run_id: uuid.UUID) -> None:
        async with self.sessionmaker() as session:
            run = await self._get_run_in_session(session, run_id)
            run.status = PipelineStatus.CANCELLED
            run.finished_at = utcnow()
            run.updated_at = utcnow()
            await session.commit()

    async def get_step_run(self, run_id: uuid.UUID, step_name: str) -> StepRun | None:
        async with self.sessionmaker() as session:
            result = await session.execute(
                select(StepRun).where(StepRun.run_id == run_id, StepRun.step_name == step_name)
            )
            return result.scalar_one_or_none()

    async def upsert_step_waiting(
        self, run_id: uuid.UUID, step_name: str, max_retries: int
    ) -> StepRun:
        async with self.sessionmaker() as session:
            step_run = (
                await session.execute(
                    select(StepRun).where(StepRun.run_id == run_id, StepRun.step_name == step_name)
                )
            ).scalar_one_or_none()
            if step_run is None:
                step_run = StepRun(
                    run_id=run_id,
                    step_name=step_name,
                    status=StepStatus.WAITING,
                    attempt=0,
                    max_retries=max_retries,
                )
                session.add(step_run)
            else:
                step_run.max_retries = max_retries
                step_run.updated_at = utcnow()
            await session.commit()
            await session.refresh(step_run)
            return step_run

    async def mark_step_running(
        self, step_id: uuid.UUID, input_snapshot: dict[str, Any], attempt: int
    ) -> None:
        async with self.sessionmaker() as session:
            step = await session.get(StepRun, step_id)
            if step is None:
                return
            step.status = StepStatus.RUNNING
            step.attempt = attempt
            step.input_snapshot = input_snapshot
            step.error = None
            step.traceback = None
            step.started_at = utcnow()
            step.finished_at = None
            step.updated_at = utcnow()
            await session.commit()

    async def mark_step_success(self, step_id: uuid.UUID, output_snapshot: dict[str, Any]) -> None:
        async with self.sessionmaker() as session:
            step = await session.get(StepRun, step_id)
            if step is None:
                return
            step.status = StepStatus.SUCCESS
            step.output_snapshot = output_snapshot
            step.error = None
            step.traceback = None
            step.finished_at = utcnow()
            step.updated_at = utcnow()
            await session.commit()

    async def mark_step_failed(self, step_id: uuid.UUID, error: str, traceback: str) -> None:
        async with self.sessionmaker() as session:
            step = await session.get(StepRun, step_id)
            if step is None:
                return
            step.status = StepStatus.FAILED
            step.error = error
            step.traceback = traceback
            step.finished_at = utcnow()
            step.updated_at = utcnow()
            await session.commit()

    async def mark_running_steps_failed(self, run_id: uuid.UUID) -> None:
        async with self.sessionmaker() as session:
            result = await session.execute(
                select(StepRun).where(StepRun.run_id == run_id, StepRun.status == StepStatus.RUNNING)
            )
            for step in result.scalars():
                step.status = StepStatus.FAILED
                step.error = "Step was running when execution stopped"
                step.finished_at = utcnow()
                step.updated_at = utcnow()
            await session.commit()

    async def reset_steps_from(self, run_id: uuid.UUID, step_names: list[str]) -> None:
        async with self.sessionmaker() as session:
            await session.execute(
                delete(StepRun).where(StepRun.run_id == run_id, StepRun.step_name.in_(step_names))
            )
            run = await self._get_run_in_session(session, run_id)
            run.status = PipelineStatus.PENDING
            run.error = None
            run.finished_at = None
            run.updated_at = utcnow()
            await session.commit()

    async def add_log(
        self,
        *,
        run_id: uuid.UUID,
        step_name: str | None,
        level: str,
        message: str,
        payload: dict[str, Any] | None,
    ) -> None:
        async with self.sessionmaker() as session:
            session.add(
                StepLog(
                    run_id=run_id,
                    step_name=step_name,
                    level=level,
                    message=message,
                    payload=payload,
                )
            )
            await session.commit()

    async def list_logs(self, run_id: uuid.UUID) -> list[StepLog]:
        async with self.sessionmaker() as session:
            result = await session.execute(
                select(StepLog).where(StepLog.run_id == run_id).order_by(StepLog.created_at.asc())
            )
            return list(result.scalars().all())

    async def _get_run_in_session(self, session: AsyncSession, run_id: uuid.UUID) -> PipelineRun:
        run = await session.get(PipelineRun, run_id)
        if run is None:
            raise RunNotFoundError(f"run not found: {run_id}")
        return run
