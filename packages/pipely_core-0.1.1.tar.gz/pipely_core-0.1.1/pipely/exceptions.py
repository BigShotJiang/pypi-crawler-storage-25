class PipelyError(Exception):
    """Base exception for pipely."""


class PipelineNotFoundError(PipelyError):
    """Raised when a requested pipeline is not registered."""


class StepNotFoundError(PipelyError):
    """Raised when a requested step is not part of the pipeline."""


class RunNotFoundError(PipelyError):
    """Raised when a run does not exist."""


class RunCancelledError(PipelyError):
    """Raised when execution is stopped because the run was cancelled."""


class InvalidRunStateError(PipelyError):
    """Raised when an operation is not valid for the run's current status."""
