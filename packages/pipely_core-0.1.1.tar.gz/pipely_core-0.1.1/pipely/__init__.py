"""Public API for Pipely.

Pipely is a small embedded pipeline engine for FastAPI applications.

Typical usage:

    from fastapi import FastAPI
    from pipely import Pipely, PipelineContext, step

    app = FastAPI()
    pipely = Pipely(database_url="postgresql+asyncpg://user:pass@host/db")
    pipely.mount(app)

    @pipely.pipeline("example")
    class ExamplePipeline:
        @step(retries=2)
        async def do_work(self, ctx: PipelineContext) -> None:
            ctx.set("answer", 42)

    run = await pipely.start("example", input={})
"""

from pipely.context import PipelineContext
from pipely.core import Pipely
from pipely.decorators import step

__all__ = ["Pipely", "PipelineContext", "step"]
