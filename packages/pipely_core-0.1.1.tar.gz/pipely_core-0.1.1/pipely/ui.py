from __future__ import annotations

from functools import lru_cache
from importlib.resources import files

from fastapi import APIRouter
from fastapi.responses import HTMLResponse


def build_ui_router(pipely: object) -> APIRouter:
    """Build the dependency-free Pipely HTML UI router."""

    router = APIRouter(include_in_schema=False)

    @router.get("", response_class=HTMLResponse)
    @router.get("/", response_class=HTMLResponse)
    async def index() -> str:
        return load_ui_html()

    return router


@lru_cache(maxsize=1)
def load_ui_html() -> str:
    """Read the bundled UI HTML file once per process."""

    return files("pipely.static").joinpath("ui.html").read_text(encoding="utf-8")
