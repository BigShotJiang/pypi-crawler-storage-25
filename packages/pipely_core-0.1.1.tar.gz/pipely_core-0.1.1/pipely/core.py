from __future__ import annotations

import uuid
from collections.abc import AsyncIterator, Callable
from contextlib import asynccontextmanager
from typing import Any

import anyio
import anyio.abc
from fastapi import FastAPI
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker

from pipely.api import build_router
from pipely.decorators import StepDefinition
from pipely.exceptions import InvalidRunStateError, PipelineNotFoundError, StepNotFoundError
from pipely.executor import InProcessExecutor, PipelineDefinition
from pipely.storage import Storage
from pipely.ui import build_ui_router


class Pipely:
    """Embedded pipeline engine for a FastAPI application.

    Pipely stores pipeline runs, step runs, logs, errors, retries, and state in
    an async SQLAlchemy database. It is meant to be imported into an existing
    FastAPI service, not run as a separate scheduler.

    Args:
        database_url: SQLAlchemy async database URL. For Postgres use
            ``postgresql+asyncpg://user:password@host:5432/database``.
        engine: Existing SQLAlchemy ``AsyncEngine``. Use this when the host
            application already owns database engine creation.
        sessionmaker: Existing SQLAlchemy async sessionmaker. Use this when
            the host application owns session lifecycle configuration.
        ui_path: Base path for the built-in UI and REST API. With the default
            ``"/_pipely"``, the UI is mounted at ``/_pipely`` and the API at
            ``/_pipely/api``.

    Example:
        >>> pipely = Pipely(database_url=settings.DATABASE_URL)
        >>>
        >>> @pipely.pipeline("document_flow")
        ... class DocumentFlow:
        ...     @step(retries=3)
        ...     async def parse(self, ctx: PipelineContext) -> None:
        ...         ctx.set("text", "parsed")
    """

    def __init__(
        self,
        *,
        database_url: str | None = None,
        engine: AsyncEngine | None = None,
        sessionmaker: async_sessionmaker[AsyncSession] | None = None,
        ui_path: str = "/_pipely",
    ) -> None:
        self.ui_path = ui_path.rstrip("/") or "/_pipely"
        self.storage = Storage(database_url=database_url, engine=engine, sessionmaker=sessionmaker)
        self._cancel_scopes: dict[uuid.UUID, anyio.CancelScope] = {}
        self.executor = InProcessExecutor(self.storage, self._cancel_scopes)
        self._pipelines: dict[str, PipelineDefinition] = {}
        self._initialized = False
        self._task_group: anyio.abc.TaskGroup | None = None

    def pipeline(self, name: str) -> Callable[[type[Any]], type[Any]]:
        """Register a class as a named pipeline.

        Methods decorated with ``@step`` are collected in class definition
        order and executed sequentially.

        Args:
            name: Stable pipeline name stored in ``pipeline_runs.pipeline_name``
                and used by ``start(name, input=...)``.

        Returns:
            A class decorator that returns the original class unchanged.
        """

        def decorator(cls: type[Any]) -> type[Any]:
            steps = self._collect_steps(cls)
            self._pipelines[name] = PipelineDefinition(name=name, cls=cls, steps=tuple(steps))
            return cls

        return decorator

    async def init(self) -> None:
        """Create Pipely database tables if they do not exist.

        ``mount(app)`` calls this automatically via the lifespan context.
        Direct method calls such as ``start`` and ``resume`` also call it
        lazily, so explicit init is optional in most applications.
        """

        if not self._initialized:
            await self.storage.create_tables()
            self._initialized = True

    @asynccontextmanager
    async def lifespan(self, app: object) -> AsyncIterator[None]:
        """Async context manager for FastAPI lifespan integration.

        Initialises Pipely tables on entry and runs a managed ``anyio``
        task group for the lifetime of the application. All background tasks
        spawned by ``submit()`` run inside this group and are guaranteed to
        finish (or be cancelled) before the context exits.

        Typical usage — compose with an existing app lifespan:

            @asynccontextmanager
            async def lifespan(app: FastAPI):
                async with pipely.lifespan(app):
                    yield

            app = FastAPI(lifespan=lifespan)

        Or let ``mount()`` wire it automatically.
        """

        await self.init()
        async with anyio.create_task_group() as tg:
            self._task_group = tg
            yield
        self._task_group = None

    def mount(self, app: FastAPI) -> None:
        """Mount the built-in REST API and HTML UI into a FastAPI app.

        Composes Pipely's lifespan with any existing lifespan already set on
        the application. If no lifespan is configured, installs one.

        Mounted routes with the default ``ui_path="/_pipely"``:

        - ``GET /_pipely``: developer UI.
        - ``GET /_pipely/api/runs``: list runs.
        - ``GET /_pipely/api/runs/{run_id}``: inspect one run.
        - ``POST /_pipely/api/runs``: start a run.
        - ``POST /_pipely/api/runs/{run_id}/retry``: retry from failed step.
        - ``POST /_pipely/api/runs/{run_id}/resume``: resume from first
          unfinished step.
        - ``POST /_pipely/api/runs/{run_id}/restart-from-step``: restart from
          a named step.
        - ``POST /_pipely/api/runs/{run_id}/cancel``: mark a run cancelled.
        """

        existing_lifespan = app.router.lifespan_context  # type: ignore[attr-defined]

        @asynccontextmanager
        async def _combined_lifespan(a: object) -> AsyncIterator[None]:
            async with self.lifespan(a):
                async with existing_lifespan(a):
                    yield

        app.router.lifespan_context = _combined_lifespan  # type: ignore[attr-defined]
        app.include_router(build_router(self), prefix=f"{self.ui_path}/api")  # type: ignore[attr-defined]
        app.include_router(build_ui_router(self), prefix=self.ui_path)  # type: ignore[attr-defined]

    async def start(self, pipeline_name: str, *, input: dict[str, Any]) -> Any:
        """Create and execute a pipeline run, blocking until it finishes.

        Execution runs in the current task and returns after the run finishes
        or fails. Safe to use in tests and scripts where a task group managed
        by ``mount()`` is not available.

        Args:
            pipeline_name: Name previously registered with ``@pipely.pipeline``.
            input: JSON-serializable input stored on ``pipeline_runs.input`` and
                exposed to steps as ``ctx.input``.

        Returns:
            A ``PipelineRun`` ORM object loaded with its step runs.
        """

        await self.init()
        pipeline = self._get_pipeline(pipeline_name)
        run = await self.storage.create_run(pipeline.name, input)
        event = anyio.Event()
        if self._task_group is not None:
            self._task_group.start_soon(
                self.executor.execute, pipeline, run.id,
            )
            # Re-use the task group but wait for this specific run to finish.
            await self._wait_for_run(run.id, event)
        else:
            await self.executor.execute(pipeline, run.id, completion_event=event)
        return await self.storage.get_run(run.id, with_steps=True)

    async def submit(self, pipeline_name: str, *, input: dict[str, Any]) -> Any:
        """Start a pipeline run in the background and return immediately.

        The run is created synchronously so the caller receives a ``run_id``
        straight away. Actual execution is deferred to the anyio task group
        managed by the application lifespan.

        Requires that ``mount()`` has been called (or that ``lifespan()`` is
        active), because a live task group is needed.

        Args:
            pipeline_name: Name previously registered with ``@pipely.pipeline``.
            input: JSON-serializable input stored on ``pipeline_runs.input``.

        Returns:
            A ``PipelineRun`` ORM object in ``pending`` status.

        Raises:
            RuntimeError: If called before the application lifespan is active.
        """

        if self._task_group is None:
            raise RuntimeError(
                "submit() requires an active task group. "
                "Call mount(app) and start the application, or use start() instead."
            )
        await self.init()
        pipeline = self._get_pipeline(pipeline_name)
        run = await self.storage.create_run(pipeline.name, input)
        self._task_group.start_soon(self.executor.execute, pipeline, run.id)
        return run

    async def resume(self, run_id: uuid.UUID | str) -> Any:
        """Resume a run from the first step that is not successful.

        Successful steps are skipped. The first unfinished, failed, or stale
        running step and all following step records are reset and executed
        again.

        Args:
            run_id: Pipeline run UUID.

        Returns:
            A refreshed ``PipelineRun`` ORM object loaded with step runs.

        Raises:
            InvalidRunStateError: If the run has already completed successfully.
        """

        await self.init()
        run_uuid = self._uuid(run_id)
        run = await self.storage.get_run(run_uuid, with_steps=True)
        if run.status == "completed":
            raise InvalidRunStateError(
                f"run {run_uuid} is already completed; use restart_from_step to re-run a specific step"
            )
        pipeline = self._get_pipeline(run.pipeline_name)
        step_names = [step.name for step in pipeline.steps]
        first_not_success = next(
            (
                step
                for step in step_names
                if not any(s.step_name == step and s.status == "success" for s in run.steps)
            ),
            None,
        )
        if first_not_success is not None:
            await self.storage.reset_steps_from(
                run_uuid, step_names[step_names.index(first_not_success):]
            )
            await self.executor.execute(pipeline, run_uuid, start_step=first_not_success)
        else:
            await self.executor.execute(pipeline, run_uuid)
        return await self.storage.get_run(run_uuid, with_steps=True)

    async def retry_failed(self, run_id: uuid.UUID | str) -> Any:
        """Retry a failed run from its first failed step.

        Args:
            run_id: Pipeline run UUID.

        Returns:
            A refreshed ``PipelineRun`` ORM object loaded with step runs.

        Raises:
            InvalidRunStateError: If the run is not in ``failed`` status.
        """

        await self.init()
        run_uuid = self._uuid(run_id)
        run = await self.storage.get_run(run_uuid, with_steps=True)
        if run.status != "failed":
            raise InvalidRunStateError(
                f"retry_failed requires a failed run; current status is {run.status!r}"
            )
        pipeline = self._get_pipeline(run.pipeline_name)
        step_names = [step.name for step in pipeline.steps]
        failed = next(
            (step for step in step_names if any(s.step_name == step and s.status == "failed" for s in run.steps)),
            None,
        )
        if failed is not None:
            await self.storage.reset_steps_from(run_uuid, step_names[step_names.index(failed):])
            await self.executor.execute(pipeline, run_uuid, start_step=failed)
        else:
            await self.executor.execute(pipeline, run_uuid)
        return await self.storage.get_run(run_uuid, with_steps=True)

    async def restart_from_step(self, run_id: uuid.UUID | str, step_name: str) -> Any:
        """Restart a run from a specific step name.

        Step records for ``step_name`` and all following steps are deleted, then
        execution resumes from that step. Existing ``pipeline_runs.state`` is
        preserved; this is useful for manually re-running the tail of a
        pipeline after changing business code or input-dependent behavior.

        Args:
            run_id: Pipeline run UUID.
            step_name: Name of a registered step in the run's pipeline.

        Returns:
            A refreshed ``PipelineRun`` ORM object loaded with step runs.

        Raises:
            StepNotFoundError: If ``step_name`` is not part of the pipeline.
        """

        await self.init()
        run_uuid = self._uuid(run_id)
        run = await self.storage.get_run(run_uuid)
        pipeline = self._get_pipeline(run.pipeline_name)
        step_names = [step.name for step in pipeline.steps]
        if step_name not in step_names:
            raise StepNotFoundError(f"step not found: {step_name}")
        await self.storage.reset_steps_from(run_uuid, step_names[step_names.index(step_name):])
        await self.executor.execute(pipeline, run_uuid, start_step=step_name)
        return await self.storage.get_run(run_uuid, with_steps=True)

    async def cancel(self, run_id: uuid.UUID | str) -> None:
        """Cancel a run, interrupting any currently executing step.

        Uses the anyio ``CancelScope`` registered by the executor to
        immediately cancel the running coroutine rather than waiting for the
        next between-step check.

        Raises:
            InvalidRunStateError: If the run has already reached a terminal
                status (``completed``, ``failed``, or ``cancelled``).
        """

        await self.init()
        run_uuid = self._uuid(run_id)
        run = await self.storage.get_run(run_uuid)
        if run.status in ("completed", "failed", "cancelled"):
            raise InvalidRunStateError(
                f"cannot cancel a run with status {run.status!r}"
            )
        scope = self._cancel_scopes.pop(run_uuid, None)
        if scope is not None:
            scope.cancel()
        else:
            await self.storage.cancel_run(run_uuid)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _wait_for_run(self, run_id: uuid.UUID, event: anyio.Event) -> None:
        """Poll storage until the run leaves the running/pending state."""
        while True:
            run = await self.storage.get_run(run_id)
            if run.status not in ("pending", "running"):
                return
            await anyio.sleep(0.05)

    def _get_pipeline(self, name: str) -> PipelineDefinition:
        pipeline = self._pipelines.get(name)
        if pipeline is None:
            raise PipelineNotFoundError(f"pipeline not found: {name}")
        return pipeline

    def _collect_steps(self, cls: type[Any]) -> list[StepDefinition]:
        steps: list[StepDefinition] = []
        for attr_name in cls.__dict__:
            attr = getattr(cls, attr_name)
            definition = getattr(attr, "__pipely_step__", None)
            if isinstance(definition, StepDefinition):
                steps.append(definition)
        return steps

    def _uuid(self, value: uuid.UUID | str) -> uuid.UUID:
        return value if isinstance(value, uuid.UUID) else uuid.UUID(str(value))
