import json
from dataclasses import dataclass
from typing import Optional, Any

from dataclasses_json.core import Json

from ..card import InputCard


@dataclass
class HiddenCard(InputCard):
    name: str
    value: Json = None

    use_socketio_support: bool = False
    use_centrifuge_support: bool = False
    use_mitt_support: bool = False
    centrifuge_channel: Optional[str] = None

    def generate(self):
        data = super(HiddenCard, self).generate()
        data["data"]["value"] = json.dumps(self.value)
        return data

    def parse(self, data: str) -> Any:
        return json.loads(data)

    def __repr__(self):
        return "HiddenCard(%s)" % self.name

    def clear(self):
        self.value = None

    def create_update_event(self, value):
        return self.create_event("update", {"value": json.dumps(value)})

    def get_supported_events(self):
        return ["update"]
