import ast
from dataclasses import dataclass
from pathlib import Path

from pie.config import get_settings

_CARD_BASE_SUFFIXES = ("Card", "InputCard")
_AJAX_FIELD_NAMES = {"pathname", "deps_names", "kwargs"}
_IO_FIELD_NAMES = {
    "use_socketio_support",
    "use_centrifuge_support",
    "use_mitt_support",
    "centrifuge_channel",
}


@dataclass(frozen=True)
class CardListItem:
    name: str
    type: str
    ajax: str
    io: str
    file: str


def handle_card_list() -> list[CardListItem]:
    components_dir = get_settings().components_dir
    items = discover_card_components(components_dir)
    if not items:
        print(f"[pie] No cards found in {components_dir}")
        return []

    print(render_card_table(items))
    return items


def discover_card_components(components_dir: Path) -> list[CardListItem]:
    if not components_dir.is_dir():
        return []

    items: list[CardListItem] = []
    for file_path in sorted(components_dir.rglob("*.py")):
        items.extend(discover_cards_in_file(file_path))
    return sorted(items, key=lambda item: (item.name.lower(), item.file))


def discover_cards_in_file(file_path: Path) -> list[CardListItem]:
    try:
        module = ast.parse(
            file_path.read_text(encoding="utf-8"), filename=str(file_path)
        )
    except (OSError, SyntaxError, UnicodeDecodeError):
        return []

    aliases = build_alias_map(module)
    items: list[CardListItem] = []
    for node in module.body:
        if not isinstance(node, ast.ClassDef) or not inherits_card_base(node, aliases):
            continue

        field_names = class_field_names(node)
        annotations = class_field_annotations(node)
        items.append(
            CardListItem(
                name=node.name,
                type=infer_card_type(annotations, aliases),
                ajax=yes_no(any(name in _AJAX_FIELD_NAMES for name in field_names)),
                io=yes_no(any(name in _IO_FIELD_NAMES for name in field_names)),
                file=display_path(file_path),
            )
        )
    return items


def build_alias_map(module: ast.Module) -> dict[str, str]:
    aliases: dict[str, str] = {}
    for node in module.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                local_name = alias.asname or alias.name
                aliases[local_name] = alias.name
        elif isinstance(node, ast.ImportFrom):
            module_name = node.module or ""
            for alias in node.names:
                if alias.name == "*":
                    continue
                local_name = alias.asname or alias.name
                aliases[local_name] = (
                    f"{module_name}.{alias.name}" if module_name else alias.name
                )
    return aliases


def inherits_card_base(node: ast.ClassDef, aliases: dict[str, str]) -> bool:
    return any(
        is_card_base_name(resolve_name(dotted_name(base), aliases))
        for base in node.bases
    )


def class_field_names(node: ast.ClassDef) -> set[str]:
    names: set[str] = set()
    for statement in node.body:
        if isinstance(statement, ast.AnnAssign) and isinstance(
            statement.target, ast.Name
        ):
            names.add(statement.target.id)
        elif isinstance(statement, ast.Assign):
            for target in statement.targets:
                if isinstance(target, ast.Name):
                    names.add(target.id)
    return names


def class_field_annotations(node: ast.ClassDef) -> list[ast.expr]:
    annotations: list[ast.expr] = []
    for statement in node.body:
        if isinstance(statement, ast.AnnAssign):
            annotations.append(statement.annotation)
    return annotations


def infer_card_type(annotations: list[ast.expr], aliases: dict[str, str]) -> str:
    if any(is_list_of_card(annotation, aliases) for annotation in annotations):
        return "container"
    if any(contains_card_type(annotation, aliases) for annotation in annotations):
        return "complex"
    return "simple"


def is_list_of_card(annotation: ast.expr, aliases: dict[str, str]) -> bool:
    if not isinstance(annotation, ast.Subscript):
        return False

    outer_name = resolve_name(dotted_name(annotation.value), aliases)
    if not outer_name or outer_name.split(".")[-1] not in {"List", "list"}:
        return False
    return contains_card_type(annotation.slice, aliases)


def contains_card_type(annotation: ast.expr, aliases: dict[str, str]) -> bool:
    if is_card_base_name(resolve_name(dotted_name(annotation), aliases)):
        return True

    for child in ast.iter_child_nodes(annotation):
        if isinstance(child, ast.expr) and contains_card_type(child, aliases):
            return True
    return False


def dotted_name(node: ast.AST | None) -> str | None:
    if node is None:
        return None
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        prefix = dotted_name(node.value)
        if prefix is None:
            return node.attr
        return f"{prefix}.{node.attr}"
    return None


def resolve_name(name: str | None, aliases: dict[str, str]) -> str | None:
    if not name:
        return None

    parts = name.split(".")
    if parts[0] not in aliases:
        return name
    resolved_root = aliases[parts[0]]
    if len(parts) == 1:
        return resolved_root
    return ".".join([resolved_root, *parts[1:]])


def is_card_base_name(name: str | None) -> bool:
    if not name:
        return False
    return any(
        name == suffix or name.endswith(f".{suffix}") for suffix in _CARD_BASE_SUFFIXES
    )


def display_path(path: Path) -> str:
    try:
        return path.relative_to(Path.cwd()).as_posix()
    except ValueError:
        return path.as_posix()


def yes_no(value: bool) -> str:
    return "Yes" if value else "No"


def render_card_table(items: list[CardListItem]) -> str:
    headers = ("Name", "Type", "Ajax", "IO", "File")
    rows = [(item.name, item.type, item.ajax, item.io, item.file) for item in items]
    widths = [len(header) for header in headers]
    for row in rows:
        for index, cell in enumerate(row):
            widths[index] = max(widths[index], len(cell))

    def format_row(row: tuple[str, ...]) -> str:
        return " │ ".join(cell.ljust(widths[index]) for index, cell in enumerate(row))

    separator = "─┼─".join("─" * width for width in widths)
    return "\n".join(
        [format_row(headers), separator, *(format_row(row) for row in rows)]
    )
