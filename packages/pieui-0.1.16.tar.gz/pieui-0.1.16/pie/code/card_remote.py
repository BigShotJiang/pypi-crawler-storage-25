"""CLI handlers for remote PieUI storage (see OpenAPI: /api/components/...)."""

import ast
import json
from pathlib import Path

from dotenv import load_dotenv

from pie.code.card_add import class_filename, normalize_class_name
from pie.code.card_list import (
    _AJAX_FIELD_NAMES,
    _IO_FIELD_NAMES,
    build_alias_map,
    class_field_names,
    dotted_name,
    resolve_name,
)
from pie.code.services.models import (
    ComponentFileDiff,
    ComponentHistoryEntry,
    ComponentHistoryPage,
    ComponentObject,
    PublicComponentState,
)
from pie.code.services.storage import PieStorageError, PieStorageService
from pie.config import get_settings


def inspect_card_upload_metadata(file_path: Path, class_name: str) -> dict[str, object]:
    tree = ast.parse(file_path.read_text(encoding="utf-8"), filename=str(file_path))
    aliases = build_alias_map(tree)
    class_node = next(
        (
            node
            for node in tree.body
            if isinstance(node, ast.ClassDef) and node.name == class_name
        ),
        None,
    )
    if class_node is None:
        raise ValueError(f"Class {class_name!r} not found in {file_path}")

    base_names = [resolve_name(dotted_name(base), aliases) for base in class_node.bases]
    field_names = class_field_names(class_node)
    return {
        "component": class_name,
        "input": any(is_input_card_base_name(name) for name in base_names),
        "ajax": any(name in _AJAX_FIELD_NAMES for name in field_names),
        "io": any(name in _IO_FIELD_NAMES for name in field_names),
    }


def is_input_card_base_name(name: str | None) -> bool:
    if not name:
        return False
    return name == "InputCard" or name.endswith(".InputCard")


def parse_card_ref(card_ref: str) -> tuple[str, int | None]:
    """Parse ``Name`` or ``Name@<revision>`` into ``(normalized_name, revision)``."""
    name, sep, revision_part = card_ref.partition("@")
    if not sep:
        return normalize_class_name(card_ref), None
    if not revision_part:
        raise ValueError(f"missing revision after '@' in {card_ref!r}")
    try:
        revision = int(revision_part)
    except ValueError as error:
        raise ValueError(
            f"revision must be a positive integer, got {revision_part!r}"
        ) from error
    if revision < 1:
        raise ValueError(f"revision must be >= 1, got {revision}")
    return normalize_class_name(name), revision


def parse_pull_ref(card_ref: str) -> tuple[str | None, str, int | None]:
    """Parse ``Name``, ``Name@<revision>``, ``project/Name`` or ``project/Name@<revision>``."""
    raw_ref = card_ref.strip()
    if not raw_ref:
        raise ValueError("component reference is required")

    slash_count = raw_ref.count("/")
    if slash_count > 1:
        raise ValueError(
            "pull reference must be NAME, NAME@REVISION, project/NAME, or project/NAME@REVISION"
        )

    if slash_count == 0:
        component_name, revision = parse_card_ref(raw_ref)
        return None, component_name, revision

    raw_project_slug, raw_component_ref = raw_ref.split("/", 1)
    project_slug = raw_project_slug.strip()
    component_ref = raw_component_ref.strip()
    if not project_slug or not component_ref:
        raise ValueError("pull reference must be project/NAME or project/NAME@REVISION")
    if project_slug in {".", ".."} or "\\" in project_slug:
        raise ValueError("project slug must be a single path segment")

    component_name, revision = parse_card_ref(component_ref)
    return project_slug, component_name, revision


def parse_public_pull_ref(card_ref: str) -> tuple[str, str]:
    """Parse ``r/<user_id>/<component_name>`` for public component pull."""
    raw_ref = card_ref.strip()
    parts = raw_ref.split("/")
    if len(parts) != 3 or parts[0] != "r":
        raise ValueError("public pull reference must be r/<user_id>/<component_name>")

    _, raw_user_id, raw_component_ref = parts
    user_id = raw_user_id.strip()
    component_ref = raw_component_ref.strip()
    if not user_id or not component_ref:
        raise ValueError("public pull reference must be r/<user_id>/<component_name>")
    if user_id in {".", ".."} or "\\" in user_id:
        raise ValueError("public user_id must be a single path segment")

    component_name, revision = parse_card_ref(component_ref)
    if revision is not None:
        raise ValueError("public pull does not accept a revision suffix")
    return user_id, component_name


def handle_card_remote_push(card_name: str) -> ComponentObject:
    load_dotenv()
    get_settings.cache_clear()
    class_name, revision = parse_card_ref(card_name)
    if revision is not None:
        raise ValueError("push does not accept a revision suffix")
    settings = get_settings()
    file_path = (settings.components_dir / class_filename(class_name)).resolve()
    if not file_path.is_file():
        raise ValueError(f"Card file not found: {file_path}")

    metadata = inspect_card_upload_metadata(file_path, class_name)
    service = PieStorageService(settings)
    uploaded_files = service.upload_language_files_batch(
        component_name=class_name,
        files=[(file_path.name, file_path)],
    )
    if not uploaded_files:
        raise ValueError(f"No files uploaded for card: {class_name}")
    uploaded = uploaded_files[0]
    uploaded_metadata = service.upload_metadata_content(
        component_name=class_name,
        schema_kind="eventSchema",
        content=(
            json.dumps(metadata, ensure_ascii=False, sort_keys=True) + "\n"
        ).encode("utf-8"),
    )
    latest_revision = _latest_revision(service, class_name)
    print(f"[pie] Uploaded card: {class_name}")
    print(f"[pie] Path: {file_path}")
    print(f"[pie] Remote key: {uploaded.key}")
    print(f"[pie] Metadata key: {uploaded_metadata.key}")
    if latest_revision is not None:
        print(f"[pie] Revision: {class_name}@{latest_revision}")
    print(
        "[pie] Metadata: "
        f"Input={'Yes' if metadata['input'] else 'No'}, "
        f"Ajax={'Yes' if metadata['ajax'] else 'No'}, "
        f"IO={'Yes' if metadata['io'] else 'No'}"
    )
    return uploaded


def _latest_revision(service: PieStorageService, component_name: str) -> int | None:
    try:
        revisions = service.list_revisions(component_name=component_name)
    except PieStorageError:
        return None
    if not revisions.revisions:
        return None
    return max(entry.revision for entry in revisions.revisions)


def handle_card_remote_list(
    *,
    user_id: str | None = None,
    project_slug: str | None = None,
) -> None:
    load_dotenv()
    get_settings.cache_clear()
    settings = get_settings()
    uid = user_id or settings.user_id
    slug = project_slug or settings.project_slug
    if not uid:
        raise ValueError("user_id is required (use --user or set PIE_USER_ID)")
    if not slug:
        raise ValueError("project is required (use --project or set PIE_PROJECT)")

    result = PieStorageService(settings).list_project_components(
        user_id=uid,
        project_slug=slug,
    )
    print(
        f"[pie] Remote components for user_id={result.user_id!r} "
        f"project_slug={result.project_slug!r}:"
    )
    for entry in sorted(result.components, key=lambda c: c.name.lower()):
        print(entry.name)


def handle_card_remote_history(
    card_name: str,
    *,
    page: int = 1,
    per_page: int = 10,
    from_revision: int | None = None,
    to_revision: int | None = None,
) -> ComponentHistoryPage:
    load_dotenv()
    get_settings.cache_clear()
    settings = get_settings()
    if not settings.user_id:
        raise ValueError("user_id is required (set PIE_USER_ID in env or .env)")
    project_slug_override, class_name, revision = parse_pull_ref(card_name)
    if revision is not None:
        raise ValueError("history does not accept a revision suffix")
    if project_slug_override is None and not settings.project_slug:
        raise ValueError(
            "project is required (set PIE_PROJECT or PIE_PROJECT_SLUG in env or .env)"
        )

    history = PieStorageService(settings).list_history(
        component_name=class_name,
        user_id=None,
        project_slug=project_slug_override,
        page=page,
        per_page=per_page,
        from_revision=from_revision,
        to_revision=to_revision,
    )
    print(format_component_history(history))
    return history


def handle_card_remote_public(card_name: str) -> PublicComponentState:
    load_dotenv()
    get_settings.cache_clear()
    settings = get_settings()
    if not settings.user_id:
        raise ValueError("user_id is required (set PIE_USER_ID in env or .env)")
    project_slug_override, class_name, revision = parse_pull_ref(card_name)
    if revision is not None:
        raise ValueError("public does not accept a revision suffix")
    if project_slug_override is None and not settings.project_slug:
        raise ValueError(
            "project is required (set PIE_PROJECT or PIE_PROJECT_SLUG in env or .env)"
        )

    state = PieStorageService(settings).publish_component(
        component_name=class_name,
        user_id=None,
        project_slug=project_slug_override,
    )
    print(f"[pie] Published public card: {state.user_id}/{state.component_name}")
    print(f"[pie] Source: {state.user_id}/{state.project_slug}/{state.component_name}")
    if state.public_registry_name:
        print(f"[pie] Registry: {state.user_id}/{state.public_registry_name}.json")
    return state


def handle_card_remote_private(card_name: str) -> PublicComponentState:
    load_dotenv()
    get_settings.cache_clear()
    settings = get_settings()
    if not settings.user_id:
        raise ValueError("user_id is required (set PIE_USER_ID in env or .env)")
    project_slug_override, class_name, revision = parse_pull_ref(card_name)
    if revision is not None:
        raise ValueError("private does not accept a revision suffix")
    if project_slug_override is None and not settings.project_slug:
        raise ValueError(
            "project is required (set PIE_PROJECT or PIE_PROJECT_SLUG in env or .env)"
        )

    state = PieStorageService(settings).unpublish_component(
        component_name=class_name,
        user_id=None,
        project_slug=project_slug_override,
    )
    print(f"[pie] Made private card: {state.user_id}/{state.component_name}")
    print(f"[pie] Source: {state.user_id}/{state.project_slug}/{state.component_name}")
    return state


def format_component_history(history: ComponentHistoryPage) -> str:
    lines = [
        (
            "component "
            f"{history.user_id}/{history.project_slug}/{history.component_name}"
        ),
        (
            f"page {history.page} "
            f"per-page {history.per_page} "
            f"total-revisions {history.total_revisions}"
        ),
    ]
    if history.from_revision is not None or history.to_revision is not None:
        lines.append(
            "range "
            f"{history.from_revision if history.from_revision is not None else '*'}"
            ".."
            f"{history.to_revision if history.to_revision is not None else '*'}"
        )
    if history.entries:
        lines.append("")

    for index, entry in enumerate(history.entries):
        if index > 0:
            lines.append("")
        lines.extend(format_component_history_entry(history, entry))
    return "\n".join(lines)


def format_component_history_entry(
    history: ComponentHistoryPage, entry: ComponentHistoryEntry
) -> list[str]:
    lines = [
        f"revision {history.component_name}@{entry.revision}",
        f"date {entry.created_at.isoformat()}",
        f"mutation {entry.mutation}",
    ]
    if entry.previous_revision is not None:
        lines.append(f"previous {entry.previous_revision}")
    if entry.deleted:
        lines.append("deleted true")
    lines.append("")

    for file_index, file_diff in enumerate(entry.diff.files):
        if file_index > 0:
            lines.append("")
        lines.extend(format_component_history_file(history, file_diff))
    return lines


def format_component_history_file(
    history: ComponentHistoryPage, file_diff: ComponentFileDiff
) -> list[str]:
    path = history_path(history, file_diff.key)
    before_path = path
    after_path = path
    if file_diff.status == "added":
        before_path = "/dev/null"
    elif file_diff.status == "deleted":
        after_path = "/dev/null"

    lines = [
        f"diff --git a/{before_path} b/{after_path}",
        f"{file_diff.status} +{file_diff.additions} -{file_diff.deletions} {path}",
    ]
    if file_diff.is_binary:
        lines.append("Binary files differ")
    elif file_diff.patch:
        lines.append(file_diff.patch.rstrip("\n"))
    return lines


def history_path(history: ComponentHistoryPage, key: str) -> str:
    marker = f"/{history.component_name}/python/"
    if marker in key:
        _, _, suffix = key.partition(marker)
        return suffix
    return key


def handle_card_remote_pull(card_name: str) -> list[Path]:
    """Download component using PIE_USER_ID and current or explicit project."""
    load_dotenv()
    get_settings.cache_clear()
    settings = get_settings()
    if not settings.user_id:
        raise ValueError("user_id is required (set PIE_USER_ID in env or .env)")
    project_slug_override, class_name, revision = parse_pull_ref(card_name)
    if project_slug_override is None and not settings.project_slug:
        raise ValueError(
            "project is required (set PIE_PROJECT or PIE_PROJECT_SLUG in env or .env)"
        )
    target_dir = settings.components_dir.resolve()
    target_dir.mkdir(parents=True, exist_ok=True)

    paths = PieStorageService(settings).download_component_directory(
        component_name=class_name,
        target_dir=target_dir,
        user_id=None,
        project_slug=project_slug_override,
        revision=revision,
    )
    if not paths:
        revision_part = f"@{revision}" if revision is not None else ""
        project_part = project_slug_override or settings.project_slug
        raise ValueError(
            f"No python files found for remote component {class_name}{revision_part!r} "
            f"(user_id={settings.user_id!r}, project={project_part!r})"
        )
    suffix = f"@{revision}" if revision is not None else ""
    if project_slug_override:
        print(f"[pie] Pulled card: {project_slug_override}/{class_name}{suffix}")
    else:
        print(f"[pie] Pulled card: {class_name}{suffix}")
    for p in paths:
        print(f"[pie] Path: {p}")
    return paths


def handle_card_pull(card_name: str) -> list[Path]:
    load_dotenv()
    get_settings.cache_clear()
    if card_name.strip().startswith("r/"):
        user_id, class_name = parse_public_pull_ref(card_name)
        settings = get_settings()
        target_dir = settings.components_dir.resolve()
        target_dir.mkdir(parents=True, exist_ok=True)

        paths = PieStorageService(settings).download_public_component_directory(
            component_name=class_name,
            target_dir=target_dir,
            user_id=user_id,
        )
        if not paths:
            raise ValueError(
                f"No python files found for public component {class_name!r} under user {user_id!r}"
            )
        print(f"[pie] Pulled public card: {user_id}/{class_name}")
        for p in paths:
            print(f"[pie] Path: {p}")
        return paths

    return handle_card_remote_pull(card_name)


def handle_card_remote_remove(card_name: str) -> None:
    load_dotenv()
    get_settings.cache_clear()
    settings = get_settings()
    if not settings.user_id:
        raise ValueError("user_id is required (set PIE_USER_ID in env or .env)")
    if not settings.project_slug:
        raise ValueError(
            "project is required (set PIE_PROJECT or PIE_PROJECT_SLUG in env or .env)"
        )

    class_name, revision = parse_card_ref(card_name)
    if revision is not None:
        raise ValueError("remove does not accept a revision suffix")
    PieStorageService(settings).delete_component(
        component_name=class_name,
        user_id=None,
        project_slug=None,
    )
    print(f"[pie] Removed remote component: {class_name}")
