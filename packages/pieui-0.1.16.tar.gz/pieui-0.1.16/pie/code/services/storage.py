import mimetypes
from collections.abc import Iterable
from contextlib import ExitStack
from pathlib import Path
from typing import List, Optional
from urllib.parse import quote

import httpx

from pie.code.services.models import (
    ComponentHistoryPage,
    ComponentObject,
    ComponentRevisionList,
    ComponentTree,
    ProjectComponentList,
    PublicComponentState,
)
from pie.config import Settings

METADATA_CONTENT_TYPES = {
    "jsonSchema": "application/json",
    "eventSchema": "application/json",
    "llms.txt": "text/plain",
}
STORAGE_LANGUAGE = "python"
DEFAULT_TIMEOUT = 30


class PieStorageError(RuntimeError):
    pass


class PieStorageService:
    def __init__(self, settings: Settings):
        self._settings = settings
        self._base_url = str(settings.api_base_url).rstrip("/")

    def list_project_components(
        self,
        *,
        user_id: str,
        project_slug: str,
    ) -> ProjectComponentList:
        response = self._request(
            "GET",
            self._project_components_url(user_id=user_id, project_slug=project_slug),
            headers=self._headers(),
            timeout=DEFAULT_TIMEOUT,
        )
        self._raise_for_error(response)
        return ProjectComponentList.model_validate(response.json())

    def list_component(
        self,
        *,
        component_name: str,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
        revision: Optional[int] = None,
    ) -> ComponentTree:
        response = self._request(
            "GET",
            self._component_tree_url(
                component_name=component_name,
                user_id=user_id,
                project_slug=project_slug,
                revision=revision,
            ),
            headers=self._headers(),
            timeout=DEFAULT_TIMEOUT,
        )
        self._raise_for_error(response)
        payload = response.json()
        if revision is not None:
            tree_payload = payload.get("tree", payload)
        else:
            tree_payload = payload
        return ComponentTree.model_validate(tree_payload)

    def list_public_component(
        self,
        *,
        component_name: str,
        user_id: str,
    ) -> ComponentTree:
        response = self._request(
            "GET",
            self._public_component_url(
                component_name=component_name,
                user_id=user_id,
            ),
            timeout=DEFAULT_TIMEOUT,
        )
        self._raise_for_error(response)
        return ComponentTree.model_validate(response.json())

    def list_revisions(
        self,
        *,
        component_name: str,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> ComponentRevisionList:
        response = self._request(
            "GET",
            self._revisions_url(
                component_name=component_name,
                user_id=user_id,
                project_slug=project_slug,
            ),
            headers=self._headers(),
            timeout=DEFAULT_TIMEOUT,
        )
        self._raise_for_error(response)
        return ComponentRevisionList.model_validate(response.json())

    def list_history(
        self,
        *,
        component_name: str,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
        page: int = 1,
        per_page: int = 10,
        from_revision: int | None = None,
        to_revision: int | None = None,
    ) -> ComponentHistoryPage:
        params: dict[str, int] = {"page": page, "per_page": per_page}
        if from_revision is not None:
            params["from"] = from_revision
        if to_revision is not None:
            params["to"] = to_revision
        response = self._request(
            "GET",
            self._history_url(
                component_name=component_name,
                user_id=user_id,
                project_slug=project_slug,
            ),
            params=params,
            headers=self._headers(),
            timeout=DEFAULT_TIMEOUT,
        )
        self._raise_for_error(response)
        return ComponentHistoryPage.model_validate(response.json())

    def publish_component(
        self,
        *,
        component_name: str,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> PublicComponentState:
        response = self._request(
            "PUT",
            self._component_public_url(
                component_name=component_name,
                user_id=user_id,
                project_slug=project_slug,
            ),
            headers=self._headers(),
            timeout=DEFAULT_TIMEOUT,
        )
        self._raise_for_error(response)
        return PublicComponentState.model_validate(response.json())

    def unpublish_component(
        self,
        *,
        component_name: str,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> PublicComponentState:
        response = self._request(
            "DELETE",
            self._component_public_url(
                component_name=component_name,
                user_id=user_id,
                project_slug=project_slug,
            ),
            headers=self._headers(),
            timeout=DEFAULT_TIMEOUT,
        )
        self._raise_for_error(response)
        return PublicComponentState.model_validate(response.json())

    def delete_component(
        self,
        *,
        component_name: str,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> None:
        response = self._request(
            "DELETE",
            self._component_url(
                component_name=component_name,
                user_id=user_id,
                project_slug=project_slug,
            ),
            headers=self._headers(),
            timeout=DEFAULT_TIMEOUT,
        )
        self._raise_for_error(response)

    def upload_component_directory(
        self,
        *,
        component_name: str,
        source_dir: Path,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> List[ComponentObject]:
        source_dir = source_dir.resolve()
        if not source_dir.is_dir():
            raise PieStorageError(f"component directory not found: {source_dir}")

        files = [
            (file_path.relative_to(source_dir).as_posix(), file_path)
            for file_path in self._iter_files(source_dir)
        ]
        if not files:
            return []

        return self.upload_language_files_batch(
            component_name=component_name,
            files=files,
            user_id=user_id,
            project_slug=project_slug,
        )

    def upload_language_files_batch(
        self,
        *,
        component_name: str,
        files: Iterable[tuple[str, Path]],
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> List[ComponentObject]:
        upload_items = [
            (self._normalize_object_path(object_path), file_path.resolve())
            for object_path, file_path in files
        ]
        for _, file_path in upload_items:
            if not file_path.is_file():
                raise PieStorageError(f"file not found: {file_path}")
        if not upload_items:
            return []

        multipart: list[
            tuple[str, tuple[str | None, object, str] | tuple[None, str]]
        ] = [("object_paths", (None, object_path)) for object_path, _ in upload_items]

        with ExitStack() as stack:
            for _object_path, file_path in upload_items:
                content_type = (
                    mimetypes.guess_type(file_path.name)[0]
                    or "application/octet-stream"
                )
                multipart.append(
                    (
                        "files",
                        (
                            file_path.name,
                            stack.enter_context(file_path.open("rb")),
                            content_type,
                        ),
                    )
                )

            response = self._request(
                "PUT",
                self._language_batch_url(
                    component_name=component_name,
                    user_id=user_id,
                    project_slug=project_slug,
                ),
                files=multipart,
                headers=self._headers(),
                timeout=DEFAULT_TIMEOUT,
            )
        self._raise_for_error(response)
        return [
            ComponentObject.from_dict(item)
            for item in response.json().get("objects", [])
        ]

    def upload_language_file(
        self,
        *,
        component_name: str,
        object_path: str,
        file_path: Path,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> ComponentObject:
        file_path = file_path.resolve()
        if not file_path.is_file():
            raise PieStorageError(f"file not found: {file_path}")

        content_type = (
            mimetypes.guess_type(file_path.name)[0] or "application/octet-stream"
        )
        with file_path.open("rb") as file_obj:
            response = self._request(
                "PUT",
                self._language_file_url(
                    component_name=component_name,
                    object_path=object_path,
                    user_id=user_id,
                    project_slug=project_slug,
                ),
                files={"file": (file_path.name, file_obj, content_type)},
                headers=self._headers(),
                timeout=DEFAULT_TIMEOUT,
            )
        self._raise_for_error(response)
        return ComponentObject.from_dict(response.json())

    def download_component_directory(
        self,
        *,
        component_name: str,
        target_dir: Path,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
        revision: Optional[int] = None,
    ) -> list[Path]:
        tree = self.list_component(
            component_name=component_name,
            user_id=user_id,
            project_slug=project_slug,
            revision=revision,
        )
        tree_data = tree.model_dump()
        objects = (tree_data.get(STORAGE_LANGUAGE) or {}).get("objects") or []
        prefix = f"{tree.prefix}{STORAGE_LANGUAGE}/"

        downloaded: list[Path] = []
        for item in objects:
            key = item["key"]
            if not key.startswith(prefix):
                continue
            object_path = key.removeprefix(prefix)
            downloaded.append(
                self.download_language_file(
                    component_name=component_name,
                    object_path=object_path,
                    target_path=target_dir / object_path,
                    user_id=user_id,
                    project_slug=project_slug,
                    revision=revision,
                )
            )
        return downloaded

    def download_public_component_directory(
        self,
        *,
        component_name: str,
        target_dir: Path,
        user_id: str,
    ) -> list[Path]:
        tree = self.list_public_component(
            component_name=component_name,
            user_id=user_id,
        )
        tree_data = tree.model_dump()
        objects = (tree_data.get(STORAGE_LANGUAGE) or {}).get("objects") or []
        prefix = f"{tree.prefix}{STORAGE_LANGUAGE}/"

        downloaded: list[Path] = []
        for item in objects:
            key = item["key"]
            if not key.startswith(prefix):
                continue
            object_path = key.removeprefix(prefix)
            downloaded.append(
                self.download_public_language_file(
                    component_name=component_name,
                    object_path=object_path,
                    target_path=target_dir / object_path,
                    user_id=user_id,
                )
            )
        return downloaded

    def download_language_file(
        self,
        *,
        component_name: str,
        object_path: str,
        target_path: Path,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
        revision: Optional[int] = None,
    ) -> Path:
        response = self._request(
            "GET",
            self._language_file_url(
                component_name=component_name,
                object_path=object_path,
                user_id=user_id,
                project_slug=project_slug,
                revision=revision,
            ),
            headers=self._headers(),
            timeout=DEFAULT_TIMEOUT,
        )
        self._raise_for_error(response)
        target_path.parent.mkdir(parents=True, exist_ok=True)
        target_path.write_bytes(response.content)
        return target_path

    def delete_language_file(
        self,
        *,
        component_name: str,
        object_path: str,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> None:
        response = self._request(
            "DELETE",
            self._language_file_url(
                component_name=component_name,
                object_path=object_path,
                user_id=user_id,
                project_slug=project_slug,
            ),
            headers=self._headers(),
            timeout=DEFAULT_TIMEOUT,
        )
        self._raise_for_error(response)

    def download_public_language_file(
        self,
        *,
        component_name: str,
        object_path: str,
        target_path: Path,
        user_id: str,
    ) -> Path:
        response = self._request(
            "GET",
            self._public_language_file_url(
                component_name=component_name,
                object_path=object_path,
                user_id=user_id,
            ),
            timeout=DEFAULT_TIMEOUT,
        )
        self._raise_for_error(response)
        target_path.parent.mkdir(parents=True, exist_ok=True)
        target_path.write_bytes(response.content)
        return target_path

    def upload_metadata(
        self,
        *,
        component_name: str,
        schema_kind: str,
        file_path: Path,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> ComponentObject:
        self._metadata_content_type(schema_kind)
        if not file_path.is_file():
            raise PieStorageError(f"file not found: {file_path}")

        return self.upload_metadata_content(
            component_name=component_name,
            schema_kind=schema_kind,
            content=file_path.read_bytes(),
            user_id=user_id,
            project_slug=project_slug,
        )

    def upload_metadata_content(
        self,
        *,
        component_name: str,
        schema_kind: str,
        content: bytes,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> ComponentObject:
        content_type = self._metadata_content_type(schema_kind)
        response = self._request(
            "PUT",
            self._metadata_url(
                component_name=component_name,
                schema_kind=schema_kind,
                user_id=user_id,
                project_slug=project_slug,
            ),
            content=content,
            headers={**self._headers(), "content-type": content_type},
            timeout=DEFAULT_TIMEOUT,
        )
        self._raise_for_error(response)
        return ComponentObject.from_dict(response.json())

    def download_metadata(
        self,
        *,
        component_name: str,
        schema_kind: str,
        target_path: Path,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> Path:
        self._metadata_content_type(schema_kind)
        response = self._request(
            "GET",
            self._metadata_url(
                component_name=component_name,
                schema_kind=schema_kind,
                user_id=user_id,
                project_slug=project_slug,
            ),
            headers=self._headers(),
            timeout=DEFAULT_TIMEOUT,
        )
        self._raise_for_error(response)
        target_path.parent.mkdir(parents=True, exist_ok=True)
        target_path.write_bytes(response.content)
        return target_path

    def delete_metadata(
        self,
        *,
        component_name: str,
        schema_kind: str,
        user_id: Optional[str] = None,
        project_slug: Optional[str] = None,
    ) -> None:
        self._metadata_content_type(schema_kind)
        response = self._request(
            "DELETE",
            self._metadata_url(
                component_name=component_name,
                schema_kind=schema_kind,
                user_id=user_id,
                project_slug=project_slug,
            ),
            headers=self._headers(),
            timeout=DEFAULT_TIMEOUT,
        )
        self._raise_for_error(response)

    def _project_components_url(self, *, user_id: str, project_slug: str) -> str:
        return (
            f"{self._base_url}/components/"
            f"{self._path_part(user_id)}/{self._path_part(project_slug)}"
        )

    def _component_url(
        self,
        *,
        component_name: str,
        user_id: Optional[str],
        project_slug: Optional[str],
    ) -> str:
        uid = user_id or self._settings.user_id
        slug = project_slug or self._settings.project_slug
        if uid is None:
            raise PieStorageError(
                "user_id is required (configure PIE_USER_ID or pass user_id)"
            )
        return (
            f"{self._base_url}/components/"
            f"{self._path_part(uid)}/"
            f"{self._path_part(slug)}/"
            f"{self._path_part(component_name)}"
        )

    def _public_component_url(
        self,
        *,
        component_name: str,
        user_id: str,
    ) -> str:
        return (
            f"{self._base_url}/public-components/"
            f"{self._path_part(user_id)}/"
            f"{self._path_part(component_name)}"
        )

    def _language_file_url(
        self,
        *,
        component_name: str,
        object_path: str,
        user_id: Optional[str],
        project_slug: Optional[str],
        revision: Optional[int] = None,
    ) -> str:
        component_url = self._component_url(
            component_name=component_name,
            user_id=user_id,
            project_slug=project_slug,
        )
        if revision is not None:
            return (
                f"{component_url}/revisions/{revision}"
                f"/{STORAGE_LANGUAGE}/{self._object_path(object_path)}"
            )
        return f"{component_url}/{STORAGE_LANGUAGE}/{self._object_path(object_path)}"

    def _public_language_file_url(
        self,
        *,
        component_name: str,
        object_path: str,
        user_id: str,
    ) -> str:
        component_url = self._public_component_url(
            component_name=component_name,
            user_id=user_id,
        )
        return f"{component_url}/{STORAGE_LANGUAGE}/{self._object_path(object_path)}"

    def _component_tree_url(
        self,
        *,
        component_name: str,
        user_id: Optional[str],
        project_slug: Optional[str],
        revision: Optional[int] = None,
    ) -> str:
        component_url = self._component_url(
            component_name=component_name,
            user_id=user_id,
            project_slug=project_slug,
        )
        if revision is not None:
            return f"{component_url}/revisions/{revision}"
        return component_url

    def _revisions_url(
        self,
        *,
        component_name: str,
        user_id: Optional[str],
        project_slug: Optional[str],
    ) -> str:
        component_url = self._component_url(
            component_name=component_name,
            user_id=user_id,
            project_slug=project_slug,
        )
        return f"{component_url}/revisions"

    def _history_url(
        self,
        *,
        component_name: str,
        user_id: Optional[str],
        project_slug: Optional[str],
    ) -> str:
        component_url = self._component_url(
            component_name=component_name,
            user_id=user_id,
            project_slug=project_slug,
        )
        return f"{component_url}/history"

    def _component_public_url(
        self,
        *,
        component_name: str,
        user_id: Optional[str],
        project_slug: Optional[str],
    ) -> str:
        component_url = self._component_url(
            component_name=component_name,
            user_id=user_id,
            project_slug=project_slug,
        )
        return f"{component_url}/public"

    def _language_batch_url(
        self,
        *,
        component_name: str,
        user_id: Optional[str],
        project_slug: Optional[str],
    ) -> str:
        component_url = self._component_url(
            component_name=component_name,
            user_id=user_id,
            project_slug=project_slug,
        )
        return f"{component_url}/batch/{STORAGE_LANGUAGE}"

    def _metadata_url(
        self,
        *,
        component_name: str,
        schema_kind: str,
        user_id: Optional[str],
        project_slug: Optional[str],
    ) -> str:
        component_url = self._component_url(
            component_name=component_name,
            user_id=user_id,
            project_slug=project_slug,
        )
        return f"{component_url}/metadata/{quote(schema_kind, safe='')}"

    def _headers(self) -> dict[str, str]:
        if not self._settings.api_key:
            return {}
        return {"x-api-key": self._settings.api_key}

    def _request(self, method: str, url: str, **kwargs: object) -> httpx.Response:
        try:
            return httpx.request(method, url, **kwargs)
        except httpx.HTTPError as error:
            raise PieStorageError(f"{method} {url} failed: {error}") from error

    @staticmethod
    def _path_part(value: str) -> str:
        return quote(value, safe="")

    @staticmethod
    def _object_path(value: str) -> str:
        return quote(PieStorageService._normalize_object_path(value), safe="/")

    @staticmethod
    def _normalize_object_path(value: str) -> str:
        parts = value.replace("\\", "/").split("/")
        if (
            value.startswith("/")
            or "" in parts
            or any(part in {".", ".."} for part in parts)
        ):
            raise PieStorageError(
                "object path must be relative and must not contain . or .."
            )
        return quote("/".join(parts), safe="/")

    @staticmethod
    def _iter_files(root: Path) -> Iterable[Path]:
        for path in sorted(root.rglob("*")):
            if path.is_file():
                yield path

    @staticmethod
    def _metadata_content_type(schema_kind: str) -> str:
        try:
            return METADATA_CONTENT_TYPES[schema_kind]
        except KeyError as error:
            allowed = ", ".join(sorted(METADATA_CONTENT_TYPES))
            raise PieStorageError(
                f"unknown metadata kind: {schema_kind}. Use one of: {allowed}"
            ) from error

    @staticmethod
    def _raise_for_error(response: httpx.Response) -> None:
        if not response.is_error:
            return
        detail = response.text.strip()
        message = (
            f"{response.request.method} {response.request.url} "
            f"failed: {response.status_code}"
        )
        if detail:
            message = f"{message}\n{detail}"
        raise PieStorageError(message)
