from dataclasses import dataclass
from datetime import datetime
from typing import Literal, Optional

from dataclasses_json import DataClassJsonMixin, LetterCase, dataclass_json
from pydantic import BaseModel, ConfigDict


class ComponentTree(BaseModel):
    """Remote component listing (prefix + language groups). Extra keys are allowed."""

    model_config = ConfigDict(extra="allow")

    prefix: str


class ProjectComponentEntry(BaseModel):
    """One component name under a user/project (OpenAPI ProjectComponentList.components[]."""

    model_config = ConfigDict(extra="ignore")

    name: str


class ProjectComponentList(BaseModel):
    """Response of GET /api/components/{user_id}/{project_slug}."""

    model_config = ConfigDict(extra="ignore")

    user_id: str
    project_slug: str
    components: list[ProjectComponentEntry]


class ComponentRevisionSummary(BaseModel):
    model_config = ConfigDict(extra="ignore")

    revision: int
    created_at: datetime
    mutation: str
    deleted: bool = False


class ComponentRevisionList(BaseModel):
    model_config = ConfigDict(extra="ignore")

    user_id: str
    project_slug: str
    component_name: str
    revisions: list[ComponentRevisionSummary]


class ComponentFileDiff(BaseModel):
    model_config = ConfigDict(extra="ignore")

    key: str
    status: Literal["added", "modified", "deleted"]
    is_binary: bool
    additions: int = 0
    deletions: int = 0
    patch: str | None = None
    before_version_id: str | None = None
    after_version_id: str | None = None


class ComponentHistoryDiff(BaseModel):
    model_config = ConfigDict(extra="ignore")

    files: list[ComponentFileDiff]


class ComponentHistoryEntry(BaseModel):
    model_config = ConfigDict(extra="ignore")

    revision: int
    previous_revision: int | None = None
    created_at: datetime
    mutation: str
    deleted: bool = False
    diff: ComponentHistoryDiff


class ComponentHistoryPage(BaseModel):
    model_config = ConfigDict(extra="ignore")

    user_id: str
    project_slug: str
    component_name: str
    page: int
    per_page: int
    total_revisions: int
    from_revision: int | None = None
    to_revision: int | None = None
    entries: list[ComponentHistoryEntry]


class PublicComponentState(BaseModel):
    model_config = ConfigDict(extra="ignore")

    user_id: str
    project_slug: str
    component_name: str
    is_public: bool
    public_registry_name: str | None = None


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass
class ComponentObject(DataClassJsonMixin):
    key: str
    size: int | None = None
    content_type: Optional[str] = None
    signed_url: Optional[str] = None
