import logging
import sys
from logging import getLevelName
from typing import Optional, Dict, Any

# Cache to store created loggers
_loggers: Dict[str, logging.Logger] = {}

_level = None
_handler = None


def set_log_level(level: any = None) -> any:
    """Set configured log level."""
    global _level
    _level = level
    for logger in _loggers.values():
        logger.setLevel(level)

    return level

def get_logger(name: str, level: Optional[int] = None) -> logging.Logger:
    """Get a logger with consistent formatting."""
    global _level, _handler

    if name in _loggers:
        logger = _loggers[name]
    else:
        logger = logging.getLogger(name)
        _loggers[name] = logger

    if not logger.handlers:  # Only add handler if none exists
        if _handler is None:
            handler = logging.StreamHandler(sys.stderr)
            formatter = logging.Formatter(
                fmt='%(asctime)s.%(msecs)03d %(levelname)-5s: %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            handler.setFormatter(formatter)
            _handler = handler

        logger.addHandler(_handler)
        # Don't bubble to root — root may have its own StreamHandler
        # (e.g. multiprocessing workers calling logging.basicConfig)
        # which would emit each message twice.
        logger.propagate = False

    if _level is not None:
        level = _level
    else:
        level = logging.INFO
    logger.setLevel(level)
    logger.debug(f"setLevel: level:{getLevelName(level)} name: {name} ")

    return logger

def class_name(obj: Any) -> str:
    if isinstance(obj, type):
        return obj.__name__
    else:
        return obj.__class__.__name__
