import re
from typing import Optional


# ── Defaults for the *Service* item inside ``Services`` array ──────────────
SERVICE_DEFAULTS = {
    "Replicas": 1,
    "ChargeType": "POSTPAID_BY_HOUR",
    "ScaleMode": "MANUAL",
}

# ── Defaults for request top-level fields ──────────────────────────────────
REQUEST_DEFAULTS = {
    "AuthorizationEnable": False,
    "LogEnable": False,
    "ModelSource": "MODEL",
    "Status": "NEW",
    "ServiceAction": "START",
}

# snake_case key → PascalCase key mapping (user-facing config → API fields)
# Service-level fields (go inside Services[0])
_SERVICE_FIELD_MAP = {
    "instance_type": "InstanceType",
    "replicas": "Replicas",
    "charge_type": "ChargeType",
    "scale_mode": "ScaleMode",
    "scheduled_action": "ScheduledAction",
    "service_limit": "ServiceLimit",
}

# Request-level fields (go at top level)
_REQUEST_FIELD_MAP = {
    "authorization_enable": "AuthorizationEnable",
    "log_enable": "LogEnable",
    "log_config": "LogConfig",
    "service_description": "ServiceDescription",
    "model_source": "ModelSource",
    "status": "Status",
    "service_action": "ServiceAction",
    "inference_table_push_enable": "InferenceTablePushEnable",
    "catalog_path": "CatalogPath",
    "schema_path": "SchemaPath",
    "payload_path": "PayloadPath",
}

# ── Update-specific field map (flat structure – all fields at top level) ─────
_UPDATE_FIELD_MAP = {
    **_SERVICE_FIELD_MAP,
    **_REQUEST_FIELD_MAP,
    "service_port": "ServicePort",
}

# All known snake_case keys (for splitting config into service vs. request level)
_ALL_FIELD_MAP = {**_SERVICE_FIELD_MAP, **_REQUEST_FIELD_MAP}


def _camel_to_snake(name: str) -> str:
    s1 = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", name)
    return re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s1).lower()


def to_snake_case_dict(data: dict) -> dict:
    """Recursively convert dict keys from camelCase/PascalCase to snake_case.

    Also walks into list values so that nested dicts inside arrays (e.g.
    ``data["services"][i]["MlModelInfo"]``) are converted too.
    """
    result = {}
    for k, v in data.items():
        snake_key = _camel_to_snake(k)
        if isinstance(v, dict):
            result[snake_key] = to_snake_case_dict(v)
        elif isinstance(v, list):
            result[snake_key] = [
                to_snake_case_dict(item) if isinstance(item, dict) else item
                for item in v
            ]
        else:
            result[snake_key] = v
    return result


def snake_to_camel_dict(config: dict) -> dict:
    """Convert config dict keys from snake_case to PascalCase using _ALL_FIELD_MAP."""
    return {_ALL_FIELD_MAP.get(k, k): v for k, v in config.items()}


def parse_model_uri(model_uri: str, api_client=None) -> dict:
    """Parse MLflow model URI and resolve model version info.

    The ``models:/`` URI uses a **three-part** ModelName:

        models:/CatalogName.SchemaName.ModelName/Version

    When *api_client* is provided, calls ``ListModelVersions`` to resolve the
    model version's ``Id`` and ``ModelPath``.

    Returns:
        dict with keys:
            catalog_name, schema_name, model_name  – parsed from URI
            ml_model_info – {"Id", "Name", "Version", "ModelPath"} for MlModelInfo
    """
    if model_uri.startswith("models:/"):
        parts = model_uri[len("models:/"):].split("/")
        if len(parts) < 2 or not parts[0] or not parts[1]:
            raise ValueError(
                f"Invalid models URI: {model_uri}. "
                "Expected format: models:/CatalogName.SchemaName.ModelName/Version"
            )

        full_name = parts[0]
        model_version = parts[1]

        # Validate three-part name: CatalogName.SchemaName.ModelName
        name_parts = full_name.split(".")
        if len(name_parts) != 3 or not all(name_parts):
            raise ValueError(
                f"Invalid model name '{full_name}' in URI: {model_uri}. "
                "ModelName must be three-part format: CatalogName.SchemaName.ModelName"
            )
        catalog_name, schema_name, model_name = name_parts

        model_id = None
        model_path = None

        if api_client is not None:
            versions = api_client.list_model_versions(
                model_name,
                catalog_name=catalog_name,
                schema_name=schema_name,
            )
            for v in versions:
                if str(v.get("Version")) == str(model_version):
                    props = {
                        p["Key"]: p["Value"]
                        for p in v.get("Properties", [])
                    }
                    model_id = props.get("tclake.mlflow.model_id")
                    model_path = props.get("tclake.mlflow.artifact_path")
                    break

        return {
            "catalog_name": catalog_name,
            "schema_name": schema_name,
            "model_name": model_name,
            "ml_model_info": {
                "Id": model_id,
                "Name": model_name,
                "Version": model_version,
                "ModelPath": model_path,
            },
        }
    elif model_uri.startswith("runs:/"):
        return {
            "catalog_name": None,
            "schema_name": None,
            "model_name": None,
            "ml_model_info": {
                "Id": None,
                "Name": None,
                "Version": None,
                "ModelPath": model_uri,
            },
        }
    else:
        raise ValueError(f"Unsupported model_uri scheme: {model_uri}")


def build_create_request(
    name: str,
    model_uri: str,
    config: dict,
    endpoint: Optional[str] = None,
    api_client=None,
) -> dict:
    """Assemble the ``CreateMLModelServices`` request body.

    Produces the nested structure expected by the API::

        {
            "ServiceName": "...",
            "LogEnable": false,
            "AuthorizationEnable": false,
            "ModelSource": "MODEL",
            "Status": "NEW",
            "ServiceAction": "START",
            "Services": [{
                "Replicas": 1,
                "ChargeType": "POSTPAID_BY_HOUR",
                "InstanceType": "...",
                "CatalogName": "...",
                "SchemaName": "...",
                "MlModelInfo": { "Id": "...", "Name": "...", "Version": "...", "ModelPath": "..." }
            }]
        }

    Note: ``WorkspaceId`` is injected by ``ModelServiceApiClient._base_body()``.
    """
    if not config.get("instance_type"):
        raise ValueError(
            "config must include 'instance_type'. "
            "Use list_instance_types() to see available options."
        )

    # Split user config into service-level and request-level fields
    service_overrides = {}
    request_overrides = {}
    for k, v in config.items():
        pascal_key = _ALL_FIELD_MAP.get(k)
        if pascal_key is None:
            # Unknown key – pass through at service level
            service_overrides[k] = v
        elif k in _SERVICE_FIELD_MAP:
            service_overrides[pascal_key] = v
        else:
            request_overrides[pascal_key] = v

    # Parse model URI → catalog/schema/model + MlModelInfo
    parsed = parse_model_uri(model_uri, api_client=api_client)

    # Build the Service item
    service = {**SERVICE_DEFAULTS, **service_overrides}
    service["MlModelInfo"] = parsed["ml_model_info"]
    if parsed["catalog_name"]:
        service["CatalogName"] = parsed["catalog_name"]
    if parsed["schema_name"]:
        service["SchemaName"] = parsed["schema_name"]

    # Build top-level request
    req = {**REQUEST_DEFAULTS, **request_overrides}
    req["ServiceName"] = name
    req["Services"] = [service]

    if endpoint:
        req["ServiceGroupId"] = endpoint

    return req


def build_update_request(
    service_id: str,
    model_uri: Optional[str] = None,
    config: Optional[dict] = None,
    api_client=None,
) -> dict:
    """Assemble the ``UpdateMLModelService`` request body.

    See: https://cloud.tencent.com/document/product/851/83228

    Unlike ``build_create_request``, Update uses a **flat** structure – all
    fields sit at the top level (no ``Services`` array)::

        {
            "ServiceId": "...",
            "ChargeType": "POSTPAID_BY_HOUR",
            "MlModelInfo": { "Id": "...", "Name": "...", ... },
            "Replicas": 1,
            "InstanceType": "...",
            "ScaleMode": "MANUAL",
            "ServicePort": 8000,
            "ServiceLimit": { ... },
            "LogEnable": false,
            "AuthorizationEnable": false,
            "Status": "NEW"
        }

    Only the provided fields are included – omitted fields are not sent so
    the server keeps their current values.

    **ServiceAction** (special update behaviour):
    When ``config`` contains ``service_action``, the corresponding
    ``ServiceAction`` field is sent at the top level.  Allowed values:

    - ``"STOP"``   — stop the service
    - ``"RESUME"`` — resume / restart the service
    - ``"SCALE"``  — trigger a scaling operation

    ⚠️  When ``ServiceAction`` is present, the server **ignores all other
    update fields** in the same request.

    Note: ``ServiceId`` and ``WorkspaceId`` are injected by
    ``ModelServiceApiClient.update_deployment()``.
    """
    config = config or {}

    # Convert snake_case config keys to PascalCase via _UPDATE_FIELD_MAP
    req: dict = {}
    for k, v in config.items():
        pascal_key = _UPDATE_FIELD_MAP.get(k, k)
        req[pascal_key] = v

    # If model_uri is provided, resolve and attach MlModelInfo
    if model_uri:
        parsed = parse_model_uri(model_uri, api_client=api_client)
        req["MlModelInfo"] = parsed["ml_model_info"]

    return req
