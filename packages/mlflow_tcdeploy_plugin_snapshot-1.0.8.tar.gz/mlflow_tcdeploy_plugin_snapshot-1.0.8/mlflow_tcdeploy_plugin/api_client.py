from typing import Optional

from tencentcloud.common import credential
from tencentcloud.common.abstract_client import AbstractClient
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from mlflow.exceptions import MlflowException

from mlflow_tcdeploy_plugin.config import TcDeployConfig


class WedataDeployClient(AbstractClient):
    """WeData deployment API client, inherits AbstractClient for TC3 signing."""
    _apiVersion = '2025-10-10'
    _endpoint = 'wedata.internal.tencentcloudapi.com'
    _service = 'wedata'


class ModelServiceApiClient:
    """Wraps WeData model service cloud API calls."""

    def __init__(self, config: TcDeployConfig):
        self._config = config
        cred = credential.Credential(
            config.secret_id,
            config.secret_key,
            config.secret_token,
        )
        client_profile = ClientProfile()
        client_profile.httpProfile.endpoint = config.endpoint

        self._wedata_client = WedataDeployClient(cred, config.region, client_profile)

    def _call(self, action: str, body: dict) -> dict:
        try:
            raw = self._wedata_client.call_json(action, body)
        except TencentCloudSDKException as e:
            raise MlflowException(f"{e.code}: {e.message}") from e

        # Tencent Cloud JSON responses are wrapped in a top-level ``Response``
        # key that contains both the business payload and ``RequestId``.
        # Peel the wrapper here so callers can work with the inner object
        # directly (e.g. ``resp.get("Data")``, ``resp.get("Groups")``).
        if isinstance(raw, dict) and "Response" in raw and isinstance(raw["Response"], dict):
            return raw["Response"]
        return raw

    def _base_body(self) -> dict:
        """Common fields required in all requests."""
        return {"WorkspaceId": self._config.workspace_id}

    def create_deployment(self, body: dict) -> dict:
        req = {**self._base_body(), **body}
        return self._call("CreateMLModelServices", req)

    def update_deployment(self, service_id: str, body: dict) -> dict:
        req = {**self._base_body(), "ServiceId": service_id, **body}
        resp = self._call("UpdateMLModelService", req)
        return resp.get("Data", resp)

    def delete_deployment(self, service_id: str) -> None:
        req = {**self._base_body(), "ServiceId": service_id}
        try:
            self._call("DeleteMLModelService", req)
        except MlflowException as e:
            if "ResourceNotFound" in str(e):
                return  # idempotent
            raise

    def get_deployment(self, service_id: str) -> dict:
        req = {**self._base_body(), "ServiceId": service_id}
        return self._call("GetMLModelService", req)

    def list_deployments(self, endpoint: Optional[str] = None) -> list:
        req = {**self._base_body()}
        if endpoint:
            req["ServiceGroupId"] = endpoint
        resp = self._call("ListMLModelServiceGroups", req)
        return resp.get("Groups", [])

    def predict(
        self,
        service_group_id: str,
        curl_data: str,
        relative_url=None,
        auth_token_value=None,
    ) -> dict:
        req = {
            **self._base_body(),
            "ServiceGroupId": service_group_id,
            "ServiceId": service_group_id,
            "CurlData": curl_data,
        }
        if relative_url is not None:
            req["RelativeUrl"] = relative_url
        if auth_token_value is not None:
            req["AuthTokenValue"] = auth_token_value
        return self._call("ModelServiceInterfaceCallTest", req)

    def debug_pod_shell(self, service_id: str, pod_name: str) -> dict:
        req = {
            **self._base_body(),
            "ServiceId": service_id,
            "PodName": pod_name,
        }
        return self._call("CreateModelServicePodUrl", req)

    def restart_pod(self, service_id: str, pod_name: str) -> dict:
        req = {
            **self._base_body(),
            "ServiceId": service_id,
            "PodName": pod_name,
        }
        return self._call("RebuildModelServicePod", req)

    def list_model_versions(
        self,
        model_name: str,
        catalog_name: str = "default",
        schema_name: str = "default",
    ) -> list:
        """Call ListModelVersions to get all versions of a model.

        Response structure (from call_json):
            {"Data": {"Items": [...], "NextPageToken": "", "TotalCount": "N"}, "RequestId": "..."}
        """
        req = {
            **self._base_body(),
            "CatalogName": catalog_name,
            "SchemaName": schema_name,
            "ModelName": model_name,
            "MaxResults": "1000",
        }
        resp = self._call("ListModelVersions", req)
        data = resp.get("Data", {})
        return data.get("Items", [])

    def get_pod_logs(
        self,
        service_id: str,
        pod_name: str,
        limit=None,
        start_time=None,
        end_time=None,
        context=None,
    ) -> dict:
        """Call ``ListMLServiceLogs``.

        ``Service`` is a fixed value ``"INFER"``.  Response data is nested
        under ``Data``.
        """
        req = {
            **self._base_body(),
            "Service": "INFER",
            "ServiceId": service_id,
            "PodName": pod_name,
        }
        if limit is not None:
            req["Limit"] = limit
        if start_time is not None:
            req["StartTime"] = start_time
        if end_time is not None:
            req["EndTime"] = end_time
        if context is not None:
            req["Context"] = context
        resp = self._call("ListMLServiceLogs", req)
        return resp.get("Data", resp)
