import json
import re
from typing import List, Optional
from urllib.parse import urlparse, unquote

from mlflow.deployments import BaseDeploymentClient
from tencentcloud.common import credential
from tencentcloud.tione.v20211111 import tione_client

from mlflow_tcdeploy_plugin.api_client import ModelServiceApiClient
from mlflow_tcdeploy_plugin.config import TcDeployConfig
from mlflow_tcdeploy_plugin.models import (
    build_create_request,
    build_update_request,
    to_snake_case_dict,
)


class TcDeploymentClient(BaseDeploymentClient):
    """
    MLflow deployment client, connecting Tencent Cloud model service as MLflow deployment backend.

    Usage:
        from mlflow.deployments import get_deploy_client
        client = get_deploy_client("tcdeploy")

    Required environment variables (from wedata-pre-execute):
        KERNEL_WEDATA_CLOUD_SDK_SECRET_ID, KERNEL_WEDATA_CLOUD_SDK_SECRET_KEY,
        KERNEL_WEDATA_REGION, WEDATA_WORKSPACE_ID
    """

    def __init__(self, target_uri: str):
        super().__init__(target_uri)
        self._config = TcDeployConfig()
        self._api = ModelServiceApiClient(self._config)

    def create_deployment(
        self,
        name: str,
        model_uri: str,
        flavor=None,
        config: Optional[dict] = None,
        endpoint: Optional[str] = None,
    ) -> dict:
        """
        Create a model service (calls ``CreateMLModelServices``).

        Args:
            name: service name
            model_uri: MLflow model URI in three-part format:
                       ``models:/CatalogName.SchemaName.ModelName/Version``
            config: deployment config, must include ``instance_type``.
                    Use ``list_instance_types()`` to see available options.
                    Additional keys: ``replicas``, ``charge_type``, ``log_enable``,
                    ``authorization_enable``, ``log_config``, ``service_description``, etc.
            endpoint: service group ID (ServiceGroupId), optional
        """
        body = build_create_request(
            name=name,
            model_uri=model_uri,
            config=config or {},
            endpoint=endpoint,
            api_client=self._api,
        )
        raw = self._api.create_deployment(body)
        return to_snake_case_dict(raw)

    def update_deployment(
        self,
        name: str,
        model_uri: Optional[str] = None,
        flavor=None,
        config: Optional[dict] = None,
        endpoint: Optional[str] = None,
    ) -> dict:
        """
        Update a model service (calls ``UpdateMLModelService``).

        Args:
            name: serviceId of the service to update
            model_uri: optional MLflow model URI in three-part format:
                       ``models:/CatalogName.SchemaName.ModelName/Version``
                       When provided, resolves MlModelInfo and includes it in
                       the update request.
            config: fields to update, e.g. ``instance_type``, ``replicas``,
                    ``charge_type``, ``scale_mode``, ``service_port``,
                    ``service_limit``, ``log_enable``, ``authorization_enable``,
                    ``status``, etc.  Only the provided fields are sent; omitted
                    fields keep their server-side values.

                    Special key — ``service_action`` (``ServiceAction``):
                    When set, the request is treated as a **special action**
                    and all other update fields in this request are **ignored**
                    by the server.  Allowed values:

                    - ``"STOP"``   — stop the service
                    - ``"RESUME"`` — resume / restart the service
                    - ``"SCALE"``  — trigger a scaling operation

        Returns:
            snake_case dict of the updated service details.
        """
        body = build_update_request(
            service_id=name,
            model_uri=model_uri,
            config=config,
            api_client=self._api,
        )
        raw = self._api.update_deployment(name, body)
        return to_snake_case_dict(raw or {})

    def delete_deployment(
        self,
        name: str,
        config: Optional[dict] = None,
        endpoint: Optional[str] = None,
    ) -> None:
        """
        Delete a model service. name is serviceId. Idempotent.
        """
        self._api.delete_deployment(name)

    def get_deployment(self, name: str, endpoint: Optional[str] = None) -> dict:
        """
        Get model service details. name is serviceId. Returns snake_case dict.
        """
        raw = self._api.get_deployment(name)
        return to_snake_case_dict(raw)

    def list_deployments(self, endpoint: Optional[str] = None) -> List[dict]:
        """
        List service groups. endpoint is serviceGroupId filter, optional.
        Each item includes "name" field (serviceGroupId) as required by MLflow spec.
        """
        raw_list = self._api.list_deployments(endpoint=endpoint)
        result = []
        for item in raw_list:
            converted = to_snake_case_dict(item)
            # MLflow spec requires each item to have "name" field
            converted["name"] = item.get("ServiceGroupId", "")
            result.append(converted)
        return result

    def list_instance_types(self, spec_type: Optional[str] = None) -> List[dict]:
        """
        Query available TIone spec list. Calls TIone SDK directly, bypassing Java layer.

        Args:
            spec_type: "CPU" or "GPU", returns all if not specified

        Returns:
            list of dict with spec_name, spec_alias, spec_type, available, available_region, gpu_type
        """
        cred = credential.Credential(
            self._config.secret_id,
            self._config.secret_key,
            self._config.secret_token,
        )
        client = tione_client.TioneClient(cred, self._config.region)

        # Access via module attribute so that unit-test patches on tione_client are effective
        req = tione_client.models.DescribeInferenceSpecsRequest()
        resp = client.DescribeInferenceSpecs(req)

        specs = []
        for s in resp.SpecInfos or []:
            if spec_type and s.SpecType != spec_type:
                continue
            specs.append({
                "spec_name": s.SpecName,
                "spec_alias": s.SpecAlias,
                "spec_type": s.SpecType,
                "available": s.Available,
                "available_region": list(s.AvailableRegion or []),
                "gpu_type": s.GpuType or "",
            })
        return specs

    # Characters that MUST NOT appear anywhere in a relative URL path.
    # Prevents CRLF injection, null-byte injection, and tab/form-feed tricks.
    _DANGEROUS_CHARS_RE = re.compile(r"[\r\n\x00\t\x0c]")

    @staticmethod
    def _validate_relative_url(url: str) -> str:
        """Ensure *url* is a safe, normalised relative path.

        Defends against SSRF vectors including:
        * absolute URLs with a scheme (``http://evil.com``)
        * protocol-relative URLs (``//evil.com``)
        * backslash variants (``\\\\evil.com``, ``/\\evil.com``)
        * ``@`` host-override trick (``/legitimate@evil.com``)
        * percent-encoded bypasses (``%2f%2fevil.com``)
        * path traversal (``/../internal``)
        * CRLF / null-byte injection

        Returns:
            A path guaranteed to start with ``/`` and contain no dangerous
            characters.

        Raises:
            ValueError: when the URL is detected as unsafe.
        """
        if not isinstance(url, str) or not url.strip():
            raise ValueError("endpoint must be a non-empty string")

        # ── 1. Decode percent-encoded characters to catch encoded attacks ──
        decoded = unquote(url)

        # ── 2. Reject dangerous control characters ──
        if TcDeploymentClient._DANGEROUS_CHARS_RE.search(decoded):
            raise ValueError(
                f"endpoint contains illegal control characters: {url!r}"
            )

        # ── 3. Reject absolute URLs (scheme present) ──
        if "://" in decoded:
            raise ValueError(
                f"endpoint must be a relative path, got absolute URL: {url}"
            )

        # ── 4. Reject protocol-relative / backslash-relative URLs ──
        #    Covers //host, \\host, /\host, \/host
        stripped = decoded.lstrip("/").lstrip("\\")
        if decoded.startswith("//") or decoded.startswith("\\"):
            raise ValueError(
                f"endpoint must not be a protocol-relative URL: {url}"
            )
        # Also check the original un-decoded form
        if url.startswith("//") or url.startswith("\\"):
            raise ValueError(
                f"endpoint must not be a protocol-relative URL: {url}"
            )

        # ── 5. Reject '@' which could be used to redirect to a different host ──
        if "@" in decoded:
            raise ValueError(
                f"endpoint must not contain '@': {url}"
            )

        # ── 6. Parse and verify: no scheme, no netloc, no fragment ──
        parsed = urlparse(decoded)
        if parsed.scheme or parsed.netloc:
            raise ValueError(
                f"endpoint must be a relative path, got: {url}"
            )

        # ── 7. Normalise the path: collapse dots and ensure leading '/' ──
        normalised = parsed.path
        if not normalised.startswith("/"):
            normalised = "/" + normalised

        # Reject path traversal (e.g. /../internal, /foo/../../etc/passwd)
        # Resolve '..' segments and check the result still starts with '/'
        segments: list[str] = []
        for seg in normalised.split("/"):
            if seg == "..":
                raise ValueError(
                    f"endpoint must not contain path traversal '..': {url}"
                )
            elif seg and seg != ".":
                segments.append(seg)
        normalised = "/" + "/".join(segments)

        return normalised

    def predict(
        self,
        deployment_name=None,
        inputs=None,
        endpoint=None,
        config=None,
    ):
        try:
            curl_data = json.dumps(inputs)
        except (TypeError, ValueError) as e:
            raise ValueError(f"inputs must be JSON-serializable, got {type(inputs).__name__}: {e}") from e

        raw = self._api.predict(
            service_group_id=deployment_name,
            curl_data=curl_data,
            relative_url=self._validate_relative_url(endpoint) if endpoint else "/predict",
            auth_token_value=(config or {}).get("auth_token"),
        )

        raw_str = raw.get("CurlResponseRaw", "")
        try:
            return json.loads(raw_str)
        except (json.JSONDecodeError, TypeError):
            return {"raw": raw_str}

    def debug_pod_shell(self, service_id, pod_name):
        raw = self._api.debug_pod_shell(service_id=service_id, pod_name=pod_name)
        return to_snake_case_dict(raw)

    def restart_pod(self, service_id, pod_name):
        raw = self._api.restart_pod(service_id=service_id, pod_name=pod_name)
        return {"request_id": raw.get("TiOneRebuildServiceRequestId")}

    def get_pod_logs(self, service_id, pod_name, limit=None, start_time=None, end_time=None, context=None):
        """
        Get pod logs (calls ``ListMLServiceLogs``).

        Args:
            service_id: service ID
            pod_name: pod name (e.g. ``ms-cp6rgw9r-1*`` supports wildcard)
            limit: max number of log entries
            start_time: ISO 8601 start time (e.g. ``2022-01-10T12:15:03+08:00``)
            end_time: ISO 8601 end time
            context: pagination context from previous response

        Returns:
            dict with ``logs`` (list of snake_case entries) and ``context``
            (pagination token).
        """
        raw = self._api.get_pod_logs(
            service_id=service_id,
            pod_name=pod_name,
            limit=limit,
            start_time=start_time,
            end_time=end_time,
            context=context,
        )
        logs = [to_snake_case_dict(entry) for entry in (raw.get("Content") or [])]
        return {"logs": logs, "context": raw.get("Context")}


# ---------------------------------------------------------------------------
# MLflow deployment plugin module-level hooks
#
# MLflow 的 plugin_manager 会在模块（entry_point 指向的模块）级别查找以下
# 两个函数；缺失任何一个都会抛出：
#     Missing interfaces: {'run_local', 'target_help'}
# 因此这里提供标准实现（本插件为远程云服务，不支持 run_local）。
# ---------------------------------------------------------------------------

def run_local(target, name, model_uri, flavor=None, config=None):
    """
    Not supported: Tencent Cloud deployment plugin only supports remote deployment.

    MLflow requires this function to exist at module level for every
    deployment plugin, even if the backend cannot run models locally.
    Signature matches :py:func:`mlflow.deployments.base.run_local`.
    """
    raise NotImplementedError(
        "tcdeploy plugin does not support run_local; deployments run on "
        "Tencent Cloud TI-ONE. Use client.create_deployment(...) instead."
    )


def target_help():
    """
    Return a short help string shown by ``mlflow deployments help -t tcdeploy``.
    """
    return (
        "Tencent Cloud deployment plugin (target: tcdeploy).\n"
        "\n"
        "Required environment variables:\n"
        "  KERNEL_WEDATA_CLOUD_SDK_SECRET_ID\n"
        "  KERNEL_WEDATA_CLOUD_SDK_SECRET_KEY\n"
        "  KERNEL_WEDATA_REGION           e.g. ap-guangzhou\n"
        "  WEDATA_WORKSPACE_ID            WeData workspace id\n"
        "\n"
        "Usage:\n"
        "  from mlflow.deployments import get_deploy_client\n"
        "  client = get_deploy_client('tcdeploy')\n"
        "  client.create_deployment(name='svc', model_uri='models:/cat.sch.M/1',\n"
        "                           config={'instance_type': 'TI.SA5.2XLARGE32.POST'})\n"
    )
