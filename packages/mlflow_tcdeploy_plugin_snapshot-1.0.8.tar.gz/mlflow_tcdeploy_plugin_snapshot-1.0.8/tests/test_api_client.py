import os
import pytest
from unittest.mock import patch, MagicMock
from mlflow.exceptions import MlflowException

from mlflow_tcdeploy_plugin.config import TcDeployConfig
from mlflow_tcdeploy_plugin.api_client import ModelServiceApiClient

BASE_ENV = {
    "KERNEL_WEDATA_CLOUD_SDK_SECRET_ID": "id",
    "KERNEL_WEDATA_CLOUD_SDK_SECRET_KEY": "key",
    "KERNEL_WEDATA_REGION": "ap-guangzhou",
    "WEDATA_WORKSPACE_ID": "ws-123",
    "KERNEL_LOGIN_UIN": "100000",
    "QCLOUD_UIN": "200000",
}


def make_client():
    with patch.dict(os.environ, BASE_ENV, clear=True):
        config = TcDeployConfig()
    return ModelServiceApiClient(config)


class TestCreateDeployment:
    def test_calls_CreateMLModelServices_action(self):
        client = make_client()
        mock_resp = {"ServiceId": "svc-1", "ServiceName": "my-svc"}

        with patch.object(client._wedata_client, "call_json", return_value=mock_resp) as mock_call:
            result = client.create_deployment({"ServiceName": "my-svc"})

        mock_call.assert_called_once_with("CreateMLModelServices", {"WorkspaceId": "ws-123", "ServiceName": "my-svc"})
        assert result == mock_resp

    def test_raises_mlflow_exception_on_sdk_error(self):
        from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
        client = make_client()

        with patch.object(client._wedata_client, "call_json",
                          side_effect=TencentCloudSDKException("InvalidParameter", "bad param")):
            with pytest.raises(MlflowException, match="InvalidParameter"):
                client.create_deployment({"ServiceName": "svc"})


class TestDeleteDeployment:
    def test_calls_DeleteMLModelService_action(self):
        client = make_client()

        with patch.object(client._wedata_client, "call_json", return_value={}) as mock_call:
            client.delete_deployment("svc-1")

        mock_call.assert_called_once_with(
            "DeleteMLModelService", {"ServiceId": "svc-1", "WorkspaceId": "ws-123"}
        )

    def test_is_idempotent_on_not_found(self):
        from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
        client = make_client()

        with patch.object(client._wedata_client, "call_json",
                          side_effect=TencentCloudSDKException("ResourceNotFound", "not found")):
            # Should not raise
            result = client.delete_deployment("svc-1")
        assert result is None


class TestListDeployments:
    def test_calls_ListMLModelServiceGroups_action(self):
        client = make_client()
        mock_resp = {"Groups": [], "TotalCount": 0}

        with patch.object(client._wedata_client, "call_json", return_value=mock_resp) as mock_call:
            result = client.list_deployments(endpoint="grp-001")

        call_body = mock_call.call_args[0][1]
        assert mock_call.call_args[0][0] == "ListMLModelServiceGroups"
        assert call_body.get("ServiceGroupId") == "grp-001"
        assert result == []


class TestPredict:
    def test_calls_ModelServiceInterfaceCallTest_action(self):
        client = make_client()
        mock_resp = {"CurlResponseRaw": '{"status": 200, "body": "ok"}'}

        with patch.object(client._wedata_client, "call_json", return_value=mock_resp) as mock_call:
            result = client.predict(
                service_group_id="grp-001",
                curl_data='{"data": [1, 2, 3]}',
            )

        call_args = mock_call.call_args[0]
        assert call_args[0] == "ModelServiceInterfaceCallTest"
        assert call_args[1]["ServiceGroupId"] == "grp-001"
        assert call_args[1]["CurlData"] == '{"data": [1, 2, 3]}'
        assert call_args[1]["WorkspaceId"] == "ws-123"
        assert result == mock_resp

    def test_passes_optional_fields(self):
        client = make_client()

        with patch.object(client._wedata_client, "call_json", return_value={}) as mock_call:
            client.predict(
                service_group_id="grp-001",
                curl_data="{}",
                relative_url="/v1/infer",
                auth_token_value="Bearer token-xxx",
            )

        call_body = mock_call.call_args[0][1]
        assert call_body["RelativeUrl"] == "/v1/infer"
        assert call_body["AuthTokenValue"] == "Bearer token-xxx"


class TestDebugPodShell:
    def test_calls_CreateModelServicePodUrl_action(self):
        client = make_client()
        mock_resp = {"Url": "https://shell.example.com/pod-0"}

        with patch.object(client._wedata_client, "call_json", return_value=mock_resp) as mock_call:
            result = client.debug_pod_shell(service_id="svc-1", pod_name="pod-0")

        call_args = mock_call.call_args[0]
        assert call_args[0] == "CreateModelServicePodUrl"
        assert call_args[1]["ServiceId"] == "svc-1"
        assert call_args[1]["PodName"] == "pod-0"
        assert call_args[1]["WorkspaceId"] == "ws-123"
        assert result == mock_resp


class TestRestartPod:
    def test_calls_RebuildModelServicePod_action(self):
        client = make_client()
        mock_resp = {"TiOneRebuildServiceRequestId": "req-abc123"}

        with patch.object(client._wedata_client, "call_json", return_value=mock_resp) as mock_call:
            result = client.restart_pod(service_id="svc-1", pod_name="pod-0")

        call_args = mock_call.call_args[0]
        assert call_args[0] == "RebuildModelServicePod"
        assert call_args[1]["ServiceId"] == "svc-1"
        assert call_args[1]["PodName"] == "pod-0"
        assert call_args[1]["WorkspaceId"] == "ws-123"
        assert result == mock_resp


class TestGetPodLogs:
    def test_calls_ListMLServiceLogs_action(self):
        client = make_client()
        mock_resp = {
            "Data": {
                "Content": [{"Id": "1", "Message": "started", "PodName": "pod-0", "Timestamp": "2026-03-11T00:00:00Z"}],
                "Context": "cursor-xyz",
            }
        }

        with patch.object(client._wedata_client, "call_json", return_value=mock_resp) as mock_call:
            result = client.get_pod_logs(service_id="svc-1", pod_name="pod-0")

        call_args = mock_call.call_args[0]
        assert call_args[0] == "ListMLServiceLogs"
        assert call_args[1]["ServiceId"] == "svc-1"
        assert call_args[1]["PodName"] == "pod-0"
        assert call_args[1]["Service"] == "INFER"
        assert call_args[1]["WorkspaceId"] == "ws-123"
        # get_pod_logs returns resp.get("Data", resp), so result is the inner dict
        assert result["Content"][0]["Message"] == "started"
        assert result["Context"] == "cursor-xyz"

    def test_passes_optional_filter_params(self):
        client = make_client()

        with patch.object(client._wedata_client, "call_json", return_value={}) as mock_call:
            client.get_pod_logs(
                service_id="svc-1",
                pod_name="pod-0",
                limit=50,
                start_time="2026-03-10T00:00:00+08:00",
                end_time="2026-03-10T23:59:59+08:00",
                context="cursor-prev",
            )

        call_body = mock_call.call_args[0][1]
        assert call_body["PodName"] == "pod-0"
        assert call_body["Limit"] == 50
        assert call_body["StartTime"] == "2026-03-10T00:00:00+08:00"
        assert call_body["EndTime"] == "2026-03-10T23:59:59+08:00"
        assert call_body["Context"] == "cursor-prev"
