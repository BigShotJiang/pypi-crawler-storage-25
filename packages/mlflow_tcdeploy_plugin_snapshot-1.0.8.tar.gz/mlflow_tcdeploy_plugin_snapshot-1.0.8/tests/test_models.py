import pytest
from unittest.mock import MagicMock
from mlflow_tcdeploy_plugin.models import (
    parse_model_uri,
    to_snake_case_dict,
    build_create_request,
    build_update_request,
    SERVICE_DEFAULTS,
    REQUEST_DEFAULTS,
)


class TestParseModelUri:
    def test_parses_three_part_name_without_api_client(self):
        """Without api_client, Id and ModelPath are None."""
        result = parse_model_uri("models:/yb_test.sc_test.MyModel/3")
        assert result == {
            "catalog_name": "yb_test",
            "schema_name": "sc_test",
            "model_name": "MyModel",
            "ml_model_info": {
                "Id": None,
                "Name": "MyModel",
                "Version": "3",
                "ModelPath": None,
            },
        }

    def test_parses_three_part_name_with_api_client(self):
        """With api_client, Id and ModelPath are resolved from Properties."""
        mock_api = MagicMock()
        mock_api.list_model_versions.return_value = [
            {
                "Version": "2",
                "Uri": "models:/m-aaa",
                "Properties": [
                    {"Key": "tclake.mlflow.model_id", "Value": "m-aaa"},
                    {"Key": "tclake.mlflow.artifact_path", "Value": "mlflow-artifacts:/2/models/m-aaa/artifacts"},
                ],
            },
            {
                "Version": "3",
                "Uri": "models:/m-bbb",
                "Properties": [
                    {"Key": "tclake.mlflow.model_id", "Value": "m-bbb"},
                    {"Key": "tclake.mlflow.artifact_path", "Value": "mlflow-artifacts:/2/models/m-bbb/artifacts"},
                    {"Key": "tclake.mlflow.deployment_status", "Value": "UnDeployment"},
                ],
            },
        ]
        result = parse_model_uri("models:/yb_test.sc_test.MyModel/3", api_client=mock_api)
        assert result["ml_model_info"] == {
            "Id": "m-bbb",
            "Name": "MyModel",
            "Version": "3",
            "ModelPath": "mlflow-artifacts:/2/models/m-bbb/artifacts",
        }
        assert result["catalog_name"] == "yb_test"
        assert result["schema_name"] == "sc_test"
        assert result["model_name"] == "MyModel"
        mock_api.list_model_versions.assert_called_once_with(
            "MyModel", catalog_name="yb_test", schema_name="sc_test"
        )

    def test_version_not_found(self):
        """When version is not found, Id and ModelPath remain None."""
        mock_api = MagicMock()
        mock_api.list_model_versions.return_value = [
            {
                "Version": "1",
                "Properties": [
                    {"Key": "tclake.mlflow.model_id", "Value": "m-ccc"},
                    {"Key": "tclake.mlflow.artifact_path", "Value": "mlflow-artifacts:/2/models/m-ccc/artifacts"},
                ],
            },
        ]
        result = parse_model_uri("models:/cat.sch.Mdl/99", api_client=mock_api)
        assert result["ml_model_info"]["Id"] is None
        assert result["ml_model_info"]["ModelPath"] is None

    def test_raises_on_non_three_part_name(self):
        with pytest.raises(ValueError, match="three-part"):
            parse_model_uri("models:/MyModel/3")
        with pytest.raises(ValueError, match="three-part"):
            parse_model_uri("models:/Catalog.Model/3")
        with pytest.raises(ValueError, match="three-part"):
            parse_model_uri("models:/a.b.c.d/3")

    def test_raises_on_empty_name_parts(self):
        with pytest.raises(ValueError, match="three-part"):
            parse_model_uri("models:/.schema.model/3")
        with pytest.raises(ValueError, match="three-part"):
            parse_model_uri("models:/catalog..model/3")
        with pytest.raises(ValueError, match="three-part"):
            parse_model_uri("models:/catalog.schema./3")

    def test_raises_on_missing_version(self):
        with pytest.raises(ValueError, match="Invalid models URI"):
            parse_model_uri("models:/cat.sch.model")

    def test_raises_on_empty_version(self):
        with pytest.raises(ValueError, match="Invalid models URI"):
            parse_model_uri("models:/cat.sch.model/")

    def test_parses_run_artifact_uri(self):
        result = parse_model_uri("runs:/abc123/my_model")
        assert result["ml_model_info"] == {
            "Id": None,
            "Name": None,
            "Version": None,
            "ModelPath": "runs:/abc123/my_model",
        }
        assert result["catalog_name"] is None

    def test_raises_on_unsupported_scheme(self):
        with pytest.raises(ValueError, match="Unsupported model_uri"):
            parse_model_uri("s3://bucket/model")


class TestToSnakeCaseDict:
    def test_converts_camel_to_snake(self):
        data = {"serviceId": "svc-1", "serviceGroupId": "grp-1", "createTime": "2024"}
        result = to_snake_case_dict(data)
        assert result == {"service_id": "svc-1", "service_group_id": "grp-1", "create_time": "2024"}

    def test_handles_nested_dict(self):
        data = {"MlModelInfo": {"ModelPath": "/path"}}
        result = to_snake_case_dict(data)
        assert result == {"ml_model_info": {"model_path": "/path"}}

    def test_handles_none_values(self):
        data = {"serviceId": None}
        result = to_snake_case_dict(data)
        assert result == {"service_id": None}


class TestBuildCreateRequest:
    def test_produces_correct_structure(self):
        """The request must have ServiceName at top level and Services array."""
        req = build_create_request(
            name="my-svc",
            model_uri="models:/cat.sch.M/1",
            config={"instance_type": "TI.S6.LARGE8.POST"},
        )
        # Top-level fields
        assert req["ServiceName"] == "my-svc"
        assert req["AuthorizationEnable"] is False
        assert req["LogEnable"] is False
        assert req["ModelSource"] == "MODEL"
        assert req["Status"] == "NEW"
        assert req["ServiceAction"] == "START"
        # WorkspaceId is NOT here (injected by api_client._base_body())
        assert "WorkspaceId" not in req

        # Services array
        assert len(req["Services"]) == 1
        svc = req["Services"][0]
        assert svc["InstanceType"] == "TI.S6.LARGE8.POST"
        assert svc["Replicas"] == 1
        assert svc["ChargeType"] == "POSTPAID_BY_HOUR"
        assert svc["ScaleMode"] == "MANUAL"
        assert svc["CatalogName"] == "cat"
        assert svc["SchemaName"] == "sch"
        assert svc["MlModelInfo"]["Name"] == "M"
        assert svc["MlModelInfo"]["Version"] == "1"

    def test_config_overrides_service_defaults(self):
        req = build_create_request(
            name="svc",
            model_uri="models:/cat.sch.M/1",
            config={"instance_type": "TI.S6.LARGE8.POST", "replicas": 3},
        )
        assert req["Services"][0]["Replicas"] == 3

    def test_config_overrides_request_defaults(self):
        req = build_create_request(
            name="svc",
            model_uri="models:/cat.sch.M/1",
            config={
                "instance_type": "TI.S6.LARGE8.POST",
                "log_enable": True,
                "authorization_enable": True,
            },
        )
        assert req["LogEnable"] is True
        assert req["AuthorizationEnable"] is True

    def test_raises_when_instance_type_missing(self):
        with pytest.raises(ValueError, match="instance_type"):
            build_create_request(
                name="svc",
                model_uri="models:/cat.sch.M/1",
                config={},
            )

    def test_sets_service_group_id_when_endpoint_given(self):
        req = build_create_request(
            name="svc",
            model_uri="models:/cat.sch.M/1",
            config={"instance_type": "TI.S6.LARGE8.POST"},
            endpoint="grp-001",
        )
        assert req["ServiceGroupId"] == "grp-001"

    def test_log_config_at_request_level(self):
        log_cfg = {"LogsetId": "abc", "TopicId": "xyz"}
        req = build_create_request(
            name="svc",
            model_uri="models:/cat.sch.M/1",
            config={"instance_type": "TI.S6.LARGE8.POST", "log_config": log_cfg},
        )
        assert req["LogConfig"] == log_cfg
        assert "LogConfig" not in req["Services"][0]


class TestBuildUpdateRequest:
    def test_basic_flat_structure(self):
        """Update request is flat – no Services array."""
        req = build_update_request(
            service_id="f0121",
            config={
                "instance_type": "TI.S.MEDIUM.POST",
                "replicas": 1,
                "charge_type": "POSTPAID_BY_HOUR",
                "scale_mode": "MANUAL",
                "service_port": 8000,
                "log_enable": False,
                "authorization_enable": False,
                "status": "NEW",
            },
        )
        assert req["InstanceType"] == "TI.S.MEDIUM.POST"
        assert req["Replicas"] == 1
        assert req["ChargeType"] == "POSTPAID_BY_HOUR"
        assert req["ScaleMode"] == "MANUAL"
        assert req["ServicePort"] == 8000
        assert req["LogEnable"] is False
        assert req["AuthorizationEnable"] is False
        assert req["Status"] == "NEW"
        # No nested Services array
        assert "Services" not in req
        # ServiceId is injected by api_client, not here
        assert "ServiceId" not in req

    def test_with_model_uri(self):
        """When model_uri is provided, MlModelInfo is resolved and attached."""
        mock_api = MagicMock()
        mock_api.list_model_versions.return_value = [
            {
                "Version": "1",
                "Properties": [
                    {"Key": "tclake.mlflow.model_id", "Value": "9c"},
                    {"Key": "tclake.mlflow.artifact_path", "Value": "mlflow-artifacts:/1model"},
                ],
            },
        ]
        req = build_update_request(
            service_id="f0121",
            model_uri="models:/cat.sch.iris-model/1",
            config={"instance_type": "TI.S.MEDIUM.POST"},
            api_client=mock_api,
        )
        assert req["MlModelInfo"] == {
            "Id": "9c",
            "Name": "iris-model",
            "Version": "1",
            "ModelPath": "mlflow-artifacts:/1model",
        }
        assert req["InstanceType"] == "TI.S.MEDIUM.POST"
        mock_api.list_model_versions.assert_called_once_with(
            "iris-model", catalog_name="cat", schema_name="sch"
        )

    def test_without_model_uri(self):
        """When model_uri is not provided, no MlModelInfo is included."""
        req = build_update_request(
            service_id="f0121",
            config={"replicas": 2},
        )
        assert "MlModelInfo" not in req
        assert req["Replicas"] == 2

    def test_empty_config(self):
        """Empty config produces empty request body."""
        req = build_update_request(service_id="f0121")
        assert req == {}

    def test_service_limit_passthrough(self):
        """ServiceLimit (dict value) passes through correctly."""
        limit = {
            "EnableInstanceRpsLimit": False,
            "InstanceRpsLimit": 5001,
            "EnableInstanceReqLimit": False,
            "InstanceReqLimit": 1,
        }
        req = build_update_request(
            service_id="f0121",
            config={"service_limit": limit},
        )
        assert req["ServiceLimit"] == limit

    def test_full_update_matches_api_example(self):
        """Reproduces the full UpdateMLModelService request example."""
        mock_api = MagicMock()
        mock_api.list_model_versions.return_value = [
            {
                "Version": "1",
                "Properties": [
                    {"Key": "tclake.mlflow.model_id", "Value": "9c"},
                    {"Key": "tclake.mlflow.artifact_path", "Value": "mlflow-artifacts:/1model"},
                ],
            },
        ]
        req = build_update_request(
            service_id="f0121",
            model_uri="models:/cat.sch.iris-model/1",
            config={
                "charge_type": "POSTPAID_BY_HOUR",
                "replicas": 1,
                "instance_type": "TI.S.MEDIUM.POST",
                "scale_mode": "MANUAL",
                "service_port": 8000,
                "service_limit": {
                    "EnableInstanceRpsLimit": False,
                    "InstanceRpsLimit": 5001,
                    "EnableInstanceReqLimit": False,
                    "InstanceReqLimit": 1,
                },
                "log_enable": False,
                "authorization_enable": False,
                "status": "NEW",
            },
            api_client=mock_api,
        )
        # Verify all fields match the API example structure
        assert req == {
            "ChargeType": "POSTPAID_BY_HOUR",
            "MlModelInfo": {
                "Id": "9c",
                "Name": "iris-model",
                "Version": "1",
                "ModelPath": "mlflow-artifacts:/1model",
            },
            "Replicas": 1,
            "InstanceType": "TI.S.MEDIUM.POST",
            "ScaleMode": "MANUAL",
            "ServicePort": 8000,
            "ServiceLimit": {
                "EnableInstanceRpsLimit": False,
                "InstanceRpsLimit": 5001,
                "EnableInstanceReqLimit": False,
                "InstanceReqLimit": 1,
            },
            "LogEnable": False,
            "AuthorizationEnable": False,
            "Status": "NEW",
        }
