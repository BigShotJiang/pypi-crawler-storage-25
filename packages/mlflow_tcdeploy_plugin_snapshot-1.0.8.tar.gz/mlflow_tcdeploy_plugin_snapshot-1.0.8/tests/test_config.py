import os
import pytest
from unittest.mock import patch

from mlflow_tcdeploy_plugin.config import TcDeployConfig

BASE_ENV = {
    "KERNEL_WEDATA_CLOUD_SDK_SECRET_ID": "test-id",
    "KERNEL_WEDATA_CLOUD_SDK_SECRET_KEY": "test-key",
    "KERNEL_WEDATA_REGION": "ap-guangzhou",
    "WEDATA_WORKSPACE_ID": "ws-123",
    "KERNEL_LOGIN_UIN": "100000",
    "QCLOUD_UIN": "200000",
}


class TestTcDeployConfigFromEnv:
    def test_reads_all_fields_from_env(self):
        with patch.dict(os.environ, BASE_ENV, clear=True):
            config = TcDeployConfig()
        assert config.secret_id == "test-id"
        assert config.secret_key == "test-key"
        assert config.region == "ap-guangzhou"
        assert config.workspace_id == "ws-123"
        assert config.secret_token is None
        # endpoint has default value, not required
        assert config.endpoint == "wedata.internal.tencentcloudapi.com"

    def test_reads_optional_token_from_env(self):
        env = {**BASE_ENV, "KERNEL_WEDATA_CLOUD_SDK_SECRET_TOKEN": "my-token"}
        with patch.dict(os.environ, env, clear=True):
            config = TcDeployConfig()
        assert config.secret_token == "my-token"

    def test_reads_custom_endpoint_from_env(self):
        env = {**BASE_ENV, "TENCENTCLOUD_ENDPOINT": "wedata.internal.tencentcloudapi.com"}
        with patch.dict(os.environ, env, clear=True):
            config = TcDeployConfig()
        assert config.endpoint == "wedata.internal.tencentcloudapi.com"

    def test_raises_when_secret_id_missing(self):
        env = {k: v for k, v in BASE_ENV.items() if k != "KERNEL_WEDATA_CLOUD_SDK_SECRET_ID"}
        with patch.dict(os.environ, env, clear=True):
            with pytest.raises(ValueError, match="KERNEL_WEDATA_CLOUD_SDK_SECRET_ID"):
                TcDeployConfig()

    def test_raises_when_secret_key_missing(self):
        env = {k: v for k, v in BASE_ENV.items() if k != "KERNEL_WEDATA_CLOUD_SDK_SECRET_KEY"}
        with patch.dict(os.environ, env, clear=True):
            with pytest.raises(ValueError, match="KERNEL_WEDATA_CLOUD_SDK_SECRET_KEY"):
                TcDeployConfig()

    def test_raises_when_workspace_id_missing(self):
        env = {k: v for k, v in BASE_ENV.items() if k != "WEDATA_WORKSPACE_ID"}
        with patch.dict(os.environ, env, clear=True):
            with pytest.raises(ValueError, match="WEDATA_WORKSPACE_ID"):
                TcDeployConfig()


class TestTcDeployConfigOverride:
    def test_kwargs_override_env(self):
        with patch.dict(os.environ, BASE_ENV, clear=True):
            config = TcDeployConfig(secret_id="override-id", workspace_id="override-ws")
        assert config.secret_id == "override-id"
        assert config.workspace_id == "override-ws"
        assert config.secret_key == "test-key"  # not overridden, reads from env


class TestEndpointValidation:
    """SSRF prevention: endpoint must match allowed Tencent Cloud domains."""

    def test_default_endpoint_passes(self):
        with patch.dict(os.environ, BASE_ENV, clear=True):
            config = TcDeployConfig()
        assert config.endpoint == "wedata.internal.tencentcloudapi.com"

    def test_valid_tencentcloudapi_endpoint(self):
        with patch.dict(os.environ, BASE_ENV, clear=True):
            config = TcDeployConfig(endpoint="wedata.tencentcloudapi.com")
        assert config.endpoint == "wedata.tencentcloudapi.com"

    def test_valid_tencentcloud_endpoint(self):
        with patch.dict(os.environ, BASE_ENV, clear=True):
            config = TcDeployConfig(endpoint="wedata.tencentcloud.com")
        assert config.endpoint == "wedata.tencentcloud.com"

    def test_rejects_arbitrary_domain(self):
        with patch.dict(os.environ, BASE_ENV, clear=True):
            with pytest.raises(ValueError, match="not in the allowed domain"):
                TcDeployConfig(endpoint="evil.com")

    def test_rejects_look_alike_domain(self):
        """evil-tencentcloudapi.com should NOT pass."""
        with patch.dict(os.environ, BASE_ENV, clear=True):
            with pytest.raises(ValueError, match="not in the allowed domain"):
                TcDeployConfig(endpoint="evil-tencentcloudapi.com")

    def test_rejects_endpoint_with_scheme(self):
        with patch.dict(os.environ, BASE_ENV, clear=True):
            with pytest.raises(ValueError, match="Invalid endpoint format"):
                TcDeployConfig(endpoint="https://wedata.tencentcloudapi.com")

    def test_rejects_endpoint_with_path(self):
        with patch.dict(os.environ, BASE_ENV, clear=True):
            with pytest.raises(ValueError, match="Invalid endpoint format"):
                TcDeployConfig(endpoint="wedata.tencentcloudapi.com/api")

    def test_rejects_endpoint_with_at_sign(self):
        with patch.dict(os.environ, BASE_ENV, clear=True):
            with pytest.raises(ValueError, match="Invalid endpoint format"):
                TcDeployConfig(endpoint="user@wedata.tencentcloudapi.com")

    def test_rejects_malicious_env_endpoint(self):
        """Environment variable SSRF attempt."""
        env = {**BASE_ENV, "TENCENTCLOUD_ENDPOINT": "attacker.com"}
        with patch.dict(os.environ, env, clear=True):
            with pytest.raises(ValueError, match="not in the allowed domain"):
                TcDeployConfig()
