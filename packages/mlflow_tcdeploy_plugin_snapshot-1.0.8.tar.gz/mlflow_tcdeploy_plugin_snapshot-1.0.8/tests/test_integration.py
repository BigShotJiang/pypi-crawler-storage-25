"""
mlflow-tcdeploy-plugin 集成测试（真实连接 WeData / TI-ONE）

⚠️ 这些用例会真的创建一个模型服务，所以默认被 skip。
   只有设置 ``RUN_INTEGRATION=1`` 才执行。

测试目标
--------
覆盖 9 个接口（按业务依赖排序，便于"一次跑完整生命周期"）：
  1) create_deployment      创建模型服务
  2) get_deployment         获取服务详情（轮询直到 Running）
  3) list_deployments       列出服务分组
  4) update_deployment      更新模型服务（调 replicas）
  5) get_pod_logs           获取 Pod 日志
  6) debug_pod_shell        Pod WebShell URL
  7) predict                模型推理预测
  8) restart_pod            重启 Pod
  9) delete_deployment      停止 + 删除服务

为了可重复执行，本文件遵循三条原则：
  - 每次跑都用带时间戳/uuid 的服务名，不会和之前的冲突
  - "尽力而为"模式：单个步骤失败不中断整个链路，只记录 ❌ 继续往下
  - finally 里强制 STOP + DELETE，外加残留清理器扫旧服务（名前缀匹配）

需要的环境变量（可从 Wedata Notebook os.environ 拷贝）
----------------------------------------------------
必填：
  RUN_INTEGRATION                       设为 "1" 才执行
  KERNEL_WEDATA_CLOUD_SDK_SECRET_ID     云 API SecretId
  KERNEL_WEDATA_CLOUD_SDK_SECRET_KEY    云 API SecretKey
  KERNEL_WEDATA_REGION                  地域（如 ap-chongqing）
  WEDATA_WORKSPACE_ID                   WeData 工作空间 ID
  IT_MODEL_URI                          三段式 URI，例如：
                                        models:/brucellu_model.default.wine_0305_model/1

可选：
  KERNEL_WEDATA_CLOUD_SDK_SECRET_TOKEN  临时 Token（若为临时凭证必填）
  TENCENTCLOUD_ENDPOINT                 内网域名（默认）
  IT_INSTANCE_TYPE                      机型，默认 TI.S.MEDIUM.POST
  IT_SERVICE_NAME_PREFIX                服务名前缀，默认 mlflow-it
  IT_KEEP_SERVICE=1                     保留服务不清理（手动调试时用）
  IT_SKIP_STALE_CLEANUP=1               跳过启动前"旧残留清理"
  IT_WAIT_RUNNING_SECONDS               等 Running 的超时，默认 600
  IT_PREDICT_INPUT                      predict 时传的 JSON（字符串），
                                        默认用一个通用的 dataframe_split 结构
  IT_PREDICT_ENDPOINT                   predict 的 relative_url，默认 /predict

运行方式::

    cd mlflow-tcdeploy-plugin
    RUN_INTEGRATION=1 \\
    ... (环境变量) \\
    pytest tests/test_integration.py -v -s
"""

import os
import time
import uuid
from typing import Optional

import pytest

# ── Skip 守卫：未开开关时整个模块不执行 ──────────────────────────────────
pytestmark = pytest.mark.skipif(
    os.getenv("RUN_INTEGRATION") != "1",
    reason="Set RUN_INTEGRATION=1 to run the real-cloud integration tests.",
)

# 运行时才 import，避免普通单测 collect 阶段就加载 SDK
import json  # noqa: E402
import pprint  # noqa: E402

from mlflow.deployments import get_deploy_client  # noqa: E402
from mlflow.exceptions import MlflowException  # noqa: E402

from mlflow_tcdeploy_plugin.models import parse_model_uri  # noqa: E402


# ── 配置读取 ──────────────────────────────────────────────────────────
# ⚠️ 注意：此文件在 pytest collect 阶段也会被 import，但 collect 时
# RUN_INTEGRATION 很可能为空。为了让 collect 不因缺少环境变量而失败，
# required=True 只在"已开 RUN_INTEGRATION"时才会真的 skip；否则返回占位值。
_RUN_INTEGRATION = os.getenv("RUN_INTEGRATION") == "1"


def _env(key: str, default: Optional[str] = None, required: bool = False) -> Optional[str]:
    v = os.getenv(key, default)
    if required and not v:
        if _RUN_INTEGRATION:
            pytest.skip(
                f"Integration test requires env var: {key}",
                allow_module_level=True,
            )
        # collect 阶段缺变量时不 skip，返回占位值
        return f"<missing-{key}>"
    return v


MODEL_URI = _env("IT_MODEL_URI", required=True)
INSTANCE_TYPE = _env("IT_INSTANCE_TYPE", "TI.S.MEDIUM.POST")
NAME_PREFIX = _env("IT_SERVICE_NAME_PREFIX", "mlflow-it")
KEEP_SERVICE = _env("IT_KEEP_SERVICE") == "1"
SKIP_STALE_CLEANUP = _env("IT_SKIP_STALE_CLEANUP") == "1"
WAIT_RUNNING_SECONDS = int(_env("IT_WAIT_RUNNING_SECONDS", "600"))
PREDICT_ENDPOINT = _env("IT_PREDICT_ENDPOINT", "/predict")
# 默认的 mlflow pyfunc 兼容输入（wine_0305_model 是 11 维特征）
_DEFAULT_PREDICT_INPUT = json.dumps({
    "dataframe_split": {
        "columns": [
            "fixed_acidity", "volatile_acidity", "citric_acid", "residual_sugar",
            "chlorides", "free_sulfur_dioxide", "total_sulfur_dioxide",
            "density", "ph", "sulphates", "alcohol",
        ],
        "data": [[7.4, 0.7, 0.0, 1.9, 0.076, 11, 34, 0.9978, 3.51, 0.56, 9.4]],
    }
})
PREDICT_INPUT_JSON = _env("IT_PREDICT_INPUT", _DEFAULT_PREDICT_INPUT)


# ── Fixtures ─────────────────────────────────────────────────────────
@pytest.fixture(scope="module")
def client():
    """真实 TcDeploymentClient（读取环境变量里的云凭证）。"""
    c = get_deploy_client("tcdeploy")
    print(f"\n[integration] workspace_id = {c._config.workspace_id}")
    print(f"[integration] region       = {c._config.region}")
    print(f"[integration] endpoint     = {c._config.endpoint}")
    return c


@pytest.fixture(scope="module")
def service_name() -> str:
    # 服务名：前缀 + 时间戳后 6 位 + uuid 4 位，保证可重复运行不撞名
    return f"{NAME_PREFIX}-{int(time.time()) % 1000000}-{uuid.uuid4().hex[:4]}"


# ── 公共工具 ─────────────────────────────────────────────────────────
def _stop_and_delete(client, service_id: str, wait: int = 10) -> None:
    """先 STOP 再 DELETE，幂等。"""
    try:
        client.update_deployment(
            name=service_id,
            config={"service_action": "STOP"},
        )
    except MlflowException:
        pass  # 可能已经停了
    time.sleep(wait)
    try:
        client.delete_deployment(name=service_id)
    except MlflowException:
        pass  # 可能已删


def _make_step_runner(results: dict):
    """构造一个 step 装饰器：统一打印步骤开始/结束 + 记录结果。

    results 字典会被就地改写，key 为步骤名，value 为 ("✅"|"❌"|"⏭", detail)。
    """
    def step(name: str):
        def decorator(fn):
            def wrapper(*args, **kwargs):
                print(f"\n{'=' * 70}")
                print(f"[STEP] {name}")
                print("=" * 70)
                try:
                    rv = fn(*args, **kwargs)
                    results[name] = ("✅", rv if isinstance(rv, str) else "ok")
                    print(f"✅ {name} 通过")
                    return rv
                except Exception as e:
                    results[name] = ("❌", f"{type(e).__name__}: {e}")
                    print(f"❌ {name} 失败: {type(e).__name__}: {e}")
                    return None
            return wrapper
        return decorator
    return step


def _print_summary(title: str, results: dict) -> int:
    """打印最终汇总表格，返回失败步骤数（用于 assert）。"""
    pass_cnt = sum(1 for s, _ in results.values() if s == "✅")
    fail_cnt = sum(1 for s, _ in results.values() if s == "❌")
    skip_cnt = sum(1 for s, _ in results.values() if s == "⏭")

    print("\n" + "=" * 70)
    print(f"[SUMMARY] {title}")
    print("=" * 70)
    for step_name, (status, detail) in results.items():
        print(f"  {status} {step_name:35s} {detail}")
    print(f"\n  总计: ✅ {pass_cnt}  ❌ {fail_cnt}  ⏭ {skip_cnt}")
    print("=" * 70 + "\n")
    return fail_cnt


def _cleanup_stale_services(client, prefix: str) -> int:
    """扫描 list_deployments 找名字以 prefix 开头的残留，挨个 STOP+DELETE。

    返回清理掉的服务数量。list_deployments 或 get_deployment 抛异常时
    返回 0，不中断主流程。
    """
    cleaned = 0
    try:
        groups = client.list_deployments()
    except MlflowException as e:
        print(f"  ⚠️ list_deployments 失败，跳过残留清理: {e}")
        return 0

    for g in groups:
        name = g.get("service_group_name", "")
        if not name.startswith(prefix):
            continue
        group_id = g.get("service_group_id") or g.get("name")
        if not group_id:
            continue
        print(f"  🧹 发现旧残留 {name} ({group_id})，清理中 ...")
        # service_group_id 下可能有多个 service_id（形如 "<group>-1"、"-2" 等）
        # 先 get_deployment 拿到 services 列表
        try:
            detail = client.get_deployment(name=group_id)
            data = detail.get("data") or detail
            services = data.get("services") or []
            for svc in services:
                svc_id = svc.get("service_id") or svc.get("ServiceId")
                if svc_id:
                    _stop_and_delete(client, svc_id, wait=5)
                    cleaned += 1
        except MlflowException as e:
            print(f"     ⚠️ 获取 {group_id} 详情失败: {e}")
    return cleaned


# ──────────────────────────────────────────────────────────────────────
# 诊断用例（发版前跑一次验证模型可被解析，平时可用 -k 过滤跳过）
# ──────────────────────────────────────────────────────────────────────
class TestIntegrationDiscoverRealThreePartName:
    """探索型诊断：列出 workspace 下所有 catalog/schema/model。"""

    def _call(self, client, action: str, body: dict) -> dict:
        req = {"WorkspaceId": client._config.workspace_id, **body}
        return client._api._call(action, req)

    def test_discover_real_three_part_name(self, client):
        after_scheme = MODEL_URI[len("models:/"):]
        name_part, _, _ = after_scheme.partition("/")
        expect_catalog, expect_schema, expect_model = name_part.split(".")

        print("\n========== Discover real three-part name ==========")
        print(f"  expect: {expect_catalog}.{expect_schema}.{expect_model}")
        print(f"  workspace_id: {client._config.workspace_id}")

        try:
            resp = self._call(client, "ListCatalogs", {"MaxResults": 1000})
        except MlflowException as e:
            pytest.fail(f"ListCatalogs 调用失败: {e}")

        data_section = resp.get("Data") or {}
        catalogs = (
            data_section.get("Items")
            or data_section.get("Catalogs")
            or resp.get("Items")
            or resp.get("Catalogs")
            or []
        )
        catalog_names = [c.get("CatalogName") or c.get("Name") for c in catalogs]
        print(f"  共 {len(catalogs)} 个 catalog: {catalog_names}")

        if not catalogs:
            pytest.fail("❌ ListCatalogs 没返回任何 catalog")

        hit = None
        for catalog in catalogs:
            cname = catalog.get("CatalogName") or catalog.get("Name")
            if not cname:
                continue
            try:
                resp = self._call(client, "ListSchemas",
                                  {"CatalogName": cname, "MaxResults": 1000})
                schemas = (resp.get("Data") or {}).get("Items", []) or []
            except MlflowException:
                continue
            for schema in schemas:
                sname = schema.get("SchemaName") or schema.get("Name")
                if not sname:
                    continue
                try:
                    resp = self._call(client, "ListModels", {
                        "CatalogName": cname,
                        "SchemaName": sname,
                        "MaxResults": 1000,
                    })
                    models = (resp.get("Data") or {}).get("Items", []) or []
                except MlflowException:
                    continue
                for m in models:
                    mname = m.get("ModelName") or m.get("Name")
                    if mname == expect_model:
                        hit = (cname, sname, mname)

        if hit is None:
            pytest.fail(f"❌ 在当前 workspace 下没找到 model '{expect_model}'")

        real = ".".join(hit)
        expect = f"{expect_catalog}.{expect_schema}.{expect_model}"
        if real == expect:
            print(f"✅ 输入三段式与云端一致：{real}")
        else:
            pytest.fail(f"❌ 三段式不匹配：输入 {expect}，云端 {real}")


class TestIntegrationListModelVersionsDebug:
    """在真正创建部署前验证 MlModelInfo.Id 能被解析出来。"""

    def test_list_model_versions_debug(self, client):
        assert MODEL_URI.startswith("models:/")
        after_scheme = MODEL_URI[len("models:/"):]
        name_part, _, version = after_scheme.partition("/")
        catalog_name, schema_name, model_name = name_part.split(".")

        print(f"\n[ListModelVersions] {catalog_name}.{schema_name}.{model_name}/{version}")
        try:
            versions = client._api.list_model_versions(
                model_name, catalog_name=catalog_name, schema_name=schema_name,
            )
        except MlflowException as e:
            pytest.fail(f"ListModelVersions 失败: {e}")
        print(f"  共 {len(versions)} 条版本")

        parsed = parse_model_uri(MODEL_URI, api_client=client._api)
        pprint.pprint(parsed)
        mi = parsed["ml_model_info"]
        assert mi.get("Id"), f"MlModelInfo.Id 解析失败: {mi}"
        print(f"✅ MlModelInfo.Id = {mi['Id']}")


# ──────────────────────────────────────────────────────────────────────
# 核心用例：9 个接口的完整生命周期（"尽力而为"模式）
# ──────────────────────────────────────────────────────────────────────
class TestIntegrationFullLifecycle:
    """串联 9 个接口，每步独立打印结果，最后输出总览。

    "尽力而为"模式：单步失败不影响后续能独立跑的步骤；依赖 Running
    状态的步骤（predict / restart_pod / get_pod_logs / debug_pod_shell）
    在未 Running 时会被跳过标记。

    最终 finally 强制 STOP + DELETE，保证可重复运行不残留。
    """

    def test_full_lifecycle(self, client, service_name):
        # results: step_name -> ("✅"|"❌"|"⏭", detail)
        results: dict = {}
        step = _make_step_runner(results)

        # ── Setup：清理可能遗留的旧服务 ───────────────────────────
        if not SKIP_STALE_CLEANUP:
            print("\n[SETUP] 清理旧残留 ...")
            n = _cleanup_stale_services(client, NAME_PREFIX)
            print(f"  共清理 {n} 个旧服务")

        service_id: Optional[str] = None
        service_group_id: Optional[str] = None
        pod_name: Optional[str] = None

        try:
            # ── STEP 1: create_deployment ─────────────────────────
            @step("1) create_deployment")
            def _create():
                nonlocal service_id, service_group_id
                resp = client.create_deployment(
                    name=service_name,
                    model_uri=MODEL_URI,
                    config={
                        "instance_type": INSTANCE_TYPE,
                        "replicas": 1,
                        "charge_type": "POSTPAID_BY_HOUR",
                        "log_enable": False,
                        "authorization_enable": True,  # predict 时更稳
                        "service_description": "integration test full lifecycle",
                    },
                )
                data = resp.get("data") or {}
                services = data.get("services") or []
                assert services, f"services 为空: {resp}"
                service_id = services[0]["service_id"]
                service_group_id = data["service_group_id"]
                print(f"  service_id       = {service_id}")
                print(f"  service_group_id = {service_group_id}")
                return f"service_id={service_id}"

            _create()

            # 后续所有步骤都依赖 service_id，取不到就直接跳过
            if not service_id:
                print("\n⏭ service_id 未创建成功，跳过后续所有步骤")
                return

            # ── STEP 2: get_deployment（第一次，看初始状态）────────
            @step("2) get_deployment (初始)")
            def _get_initial():
                detail = client.get_deployment(name=service_id)
                data = detail.get("data") or detail
                services = data.get("services") or []
                status = services[0].get("status") if services else "?"
                print(f"  初始 status = {status}")
                return f"status={status}"

            _get_initial()

            # ── STEP 3: list_deployments（确认服务在列表中）────────
            @step("3) list_deployments")
            def _list():
                groups = client.list_deployments()
                print(f"  workspace 下共 {len(groups)} 个 service group")
                # 找自己这个组
                mine = [g for g in groups if g.get("name") == service_group_id]
                assert mine, (
                    f"新建的 {service_group_id} 没在 list_deployments 里出现"
                )
                print(f"  ✓ 找到了自己的 group: {mine[0].get('service_group_name')}")
                return f"groups={len(groups)}"

            _list()

            # ── STEP 4: update_deployment（改 replicas=1，幂等）────
            @step("4) update_deployment (replicas=1)")
            def _update():
                resp = client.update_deployment(
                    name=service_id,
                    config={"replicas": 1},
                )
                print(f"  update_resp = {json.dumps(resp, ensure_ascii=False, default=str)[:200]} ...")
                return "replicas=1"

            _update()

            # ── 等待 Running（为后续依赖 Running 的步骤铺路）────────
            print(f"\n[WAIT] 等待服务进入 RUNNING，最多 {WAIT_RUNNING_SECONDS}s ...")
            deadline = time.time() + WAIT_RUNNING_SECONDS
            last_status = "Unknown"
            while time.time() < deadline:
                try:
                    detail = client.get_deployment(name=service_id)
                    data = detail.get("data") or detail
                    services = data.get("services") or []
                    if services:
                        last_status = (services[0].get("status") or "").lower()
                        pods = services[0].get("pod_infos") or []
                        if pods:
                            pod_name = pods[0].get("name") or pods[0].get("Name")
                    print(f"  [{int(time.time() - (deadline - WAIT_RUNNING_SECONDS))}s] "
                          f"status={last_status}  pod_name={pod_name}")
                    if last_status == "running":
                        break
                    if last_status in ("failed", "abnormal", "deployfailed"):
                        print(f"  ❌ 服务进入终态 {last_status}，放弃等待")
                        break
                except MlflowException as e:
                    print(f"  ⚠️ get_deployment 轮询失败: {e}")
                time.sleep(20)

            is_running = last_status == "running"
            print(f"[WAIT] 最终状态: {last_status}  is_running={is_running}")

            # ── STEP 5: get_pod_logs（需要 pod_name）──────────────
            @step("5) get_pod_logs")
            def _logs():
                if not pod_name:
                    raise RuntimeError("pod_name 未拿到（服务未创建出 pod）")
                logs = client.get_pod_logs(
                    service_id=service_id,
                    pod_name=pod_name,
                    limit=20,
                )
                n = len(logs.get("logs", []))
                print(f"  拿到 {n} 条日志")
                if n > 0:
                    first_msg = logs["logs"][0].get("message", "")[:80]
                    print(f"  首条: {first_msg}")
                return f"logs={n}"

            _logs()

            # ── STEP 6: debug_pod_shell ───────────────────────────
            @step("6) debug_pod_shell")
            def _shell():
                if not pod_name:
                    raise RuntimeError("pod_name 未拿到")
                r = client.debug_pod_shell(service_id=service_id, pod_name=pod_name)
                url = r.get("url") or r.get("Url")
                print(f"  shell url = {url}")
                assert url, f"debug_pod_shell 未返回 url: {r}"
                return "url ok"

            _shell()

            # ── STEP 7: predict（必须 Running 才能调）─────────────
            if is_running:
                @step("7) predict")
                def _predict():
                    inputs = json.loads(PREDICT_INPUT_JSON)
                    result = client.predict(
                        deployment_name=service_group_id,
                        inputs=inputs,
                        endpoint=PREDICT_ENDPOINT,
                    )
                    print(f"  predict result = {json.dumps(result, ensure_ascii=False, default=str)[:200]}")
                    return "ok"

                _predict()
            else:
                results["7) predict"] = ("⏭", f"跳过（status={last_status}，非 running）")
                print(f"\n⏭ [STEP] 7) predict 跳过（服务未 running）")

            # ── STEP 8: restart_pod ───────────────────────────────
            if is_running and pod_name:
                @step("8) restart_pod")
                def _restart():
                    r = client.restart_pod(service_id=service_id, pod_name=pod_name)
                    print(f"  request_id = {r.get('request_id')}")
                    assert r.get("request_id"), f"restart_pod 无 request_id: {r}"
                    return "ok"

                _restart()
            else:
                results["8) restart_pod"] = ("⏭", "跳过（未 running 或无 pod）")
                print(f"\n⏭ [STEP] 8) restart_pod 跳过")

        finally:
            # ── STEP 9: delete_deployment（兜底必执行）────────────
            print("\n" + "=" * 70)
            print("[STEP] 9) delete_deployment (cleanup)")
            print("=" * 70)
            if service_id and not KEEP_SERVICE:
                try:
                    _stop_and_delete(client, service_id, wait=10)
                    results["9) delete_deployment"] = ("✅", "已清理")
                    print("✅ 9) delete_deployment 已清理")
                except Exception as e:
                    results["9) delete_deployment"] = ("❌", str(e))
                    print(f"❌ 9) delete_deployment 失败: {e}")
            elif service_id and KEEP_SERVICE:
                results["9) delete_deployment"] = ("⏭", f"IT_KEEP_SERVICE=1，保留 {service_id}")
                print(f"⏭ 9) delete_deployment 跳过（保留 {service_id}）")
            else:
                results["9) delete_deployment"] = ("⏭", "service_id 未创建，无需清理")
                print("⏭ 9) delete_deployment 跳过（没 service_id）")

            # ── 最终汇总 ──────────────────────────────────────────
            fail_cnt = _print_summary(
                "Full Lifecycle Integration Test", results,
            )

            # 严格模式：任何 ❌ 都让 pytest 报 fail，但汇总日志已经打出来了
            assert fail_cnt == 0, (
                f"Full lifecycle 有 {fail_cnt} 个步骤失败，详见上方 SUMMARY"
            )


# ──────────────────────────────────────────────────────────────────────
# 快速冒烟：不等 Running 的接口（~30 秒）
# ──────────────────────────────────────────────────────────────────────
class TestIntegrationQuickNoWait:
    """只跑「下发请求就能拿结果」的 5 个接口，不等服务 Running。

    涵盖接口：
      1) create_deployment
      2) get_deployment        （取初始状态，不等 Running）
      3) list_deployments      （确认服务出现在列表）
      4) update_deployment     （改 replicas=1，幂等）
      5) delete_deployment     （STOP + DELETE 兜底清理）

    不涵盖：get_pod_logs / debug_pod_shell / predict / restart_pod
    （这 4 个接口需要 Pod 已经起来，请用 TestIntegrationRunningService 跑）

    典型耗时：~30 秒（主要花在 STOP 后 sleep(10) 等状态切换）。
    """

    def test_quick_no_wait(self, client, service_name):
        results: dict = {}
        step = _make_step_runner(results)

        if not SKIP_STALE_CLEANUP:
            print("\n[SETUP] 清理旧残留 ...")
            n = _cleanup_stale_services(client, NAME_PREFIX)
            print(f"  共清理 {n} 个旧服务")

        service_id: Optional[str] = None
        service_group_id: Optional[str] = None

        try:
            # ── STEP 1: create_deployment ─────────────────────────
            @step("1) create_deployment")
            def _create():
                nonlocal service_id, service_group_id
                resp = client.create_deployment(
                    name=service_name,
                    model_uri=MODEL_URI,
                    config={
                        "instance_type": INSTANCE_TYPE,
                        "replicas": 1,
                        "charge_type": "POSTPAID_BY_HOUR",
                        "log_enable": False,
                        "authorization_enable": False,
                        "service_description": "integration test quick no-wait",
                    },
                )
                data = resp.get("data") or {}
                services = data.get("services") or []
                assert services, f"services 为空: {resp}"
                service_id = services[0]["service_id"]
                service_group_id = data["service_group_id"]
                print(f"  service_id       = {service_id}")
                print(f"  service_group_id = {service_group_id}")
                return f"service_id={service_id}"

            _create()

            if not service_id:
                print("\n⏭ service_id 未创建成功，跳过后续步骤")
                return

            # ── STEP 2: get_deployment ────────────────────────────
            @step("2) get_deployment")
            def _get():
                detail = client.get_deployment(name=service_id)
                data = detail.get("data") or detail
                services = data.get("services") or []
                status = services[0].get("status") if services else "?"
                print(f"  status = {status}")
                return f"status={status}"

            _get()

            # ── STEP 3: list_deployments ──────────────────────────
            @step("3) list_deployments")
            def _list():
                groups = client.list_deployments()
                print(f"  workspace 下共 {len(groups)} 个 service group")
                mine = [g for g in groups if g.get("name") == service_group_id]
                assert mine, (
                    f"新建的 {service_group_id} 没在 list_deployments 里出现"
                )
                print(f"  ✓ 找到了自己的 group: {mine[0].get('service_group_name')}")
                return f"groups={len(groups)}"

            _list()

            # ── STEP 4: update_deployment ─────────────────────────
            @step("4) update_deployment (replicas=1)")
            def _update():
                resp = client.update_deployment(
                    name=service_id,
                    config={"replicas": 1},
                )
                print(f"  update_resp = {json.dumps(resp, ensure_ascii=False, default=str)[:200]} ...")
                return "replicas=1"

            _update()

        finally:
            # ── STEP 5: delete_deployment（兜底必执行）────────────
            print("\n" + "=" * 70)
            print("[STEP] 5) delete_deployment (cleanup)")
            print("=" * 70)
            if service_id and not KEEP_SERVICE:
                try:
                    _stop_and_delete(client, service_id, wait=10)
                    results["5) delete_deployment"] = ("✅", "已清理")
                    print("✅ 5) delete_deployment 已清理")
                except Exception as e:
                    results["5) delete_deployment"] = ("❌", str(e))
                    print(f"❌ 5) delete_deployment 失败: {e}")
            elif service_id and KEEP_SERVICE:
                results["5) delete_deployment"] = ("⏭", f"IT_KEEP_SERVICE=1，保留 {service_id}")
                print(f"⏭ 5) delete_deployment 跳过（保留 {service_id}）")
            else:
                results["5) delete_deployment"] = ("⏭", "service_id 未创建，无需清理")
                print("⏭ 5) delete_deployment 跳过（没 service_id）")

            fail_cnt = _print_summary("Quick No-Wait Integration Test", results)
            assert fail_cnt == 0, (
                f"Quick no-wait 有 {fail_cnt} 个步骤失败，详见上方 SUMMARY"
            )


# ──────────────────────────────────────────────────────────────────────
# 针对已存在的 Running 服务：只跑依赖 Pod 已起来的接口（~30 秒）
# ──────────────────────────────────────────────────────────────────────
class TestIntegrationRunningService:
    """针对一个**已经在 Running 状态**的服务跑 4 个接口，不做创建/删除。

    涵盖接口：
      1) get_deployment       （校验服务仍在 Running + 发现 pod_name）
      2) get_pod_logs
      3) debug_pod_shell
      4) predict
      5) restart_pod          （默认跳过，设 IT_ALLOW_RESTART=1 才跑）

    需要的环境变量：
      IT_EXISTING_SERVICE_ID         必填：已 Running 的 service_id
      IT_EXISTING_SERVICE_GROUP_ID   可选：predict 用的 service_group_id
                                     （不填会自动从 get_deployment 里取）
      IT_EXISTING_POD_NAME           可选：指定 pod_name
                                     （不填会自动从 get_deployment 里取第一个）
      IT_ALLOW_RESTART               可选：设 "1" 才真的调 restart_pod
                                     （重启会影响服务可用性，默认跳过更安全）

    典型耗时：~30 秒。
    """

    def test_running_service(self, client):
        existing_service_id = _env("IT_EXISTING_SERVICE_ID")
        if not existing_service_id:
            pytest.skip(
                "Set IT_EXISTING_SERVICE_ID=<running-service-id> "
                "to run this test (需要一个已 Running 的服务)"
            )

        existing_group_id = _env("IT_EXISTING_SERVICE_GROUP_ID")
        existing_pod_name = _env("IT_EXISTING_POD_NAME")
        allow_restart = _env("IT_ALLOW_RESTART") == "1"

        print(f"\n[RunningService] service_id     = {existing_service_id}")
        print(f"[RunningService] service_group  = {existing_group_id or '(auto)'}")
        print(f"[RunningService] pod_name       = {existing_pod_name or '(auto)'}")
        print(f"[RunningService] allow_restart  = {allow_restart}")

        results: dict = {}
        step = _make_step_runner(results)

        service_group_id: Optional[str] = existing_group_id
        pod_name: Optional[str] = existing_pod_name
        is_running = False

        # ── STEP 1: get_deployment（顺便自动发现 group/pod）────────
        @step("1) get_deployment (验证 Running + 发现 pod)")
        def _get():
            nonlocal service_group_id, pod_name, is_running
            detail = client.get_deployment(name=existing_service_id)
            data = detail.get("data") or detail
            services = data.get("services") or []
            assert services, f"服务 {existing_service_id} 不存在或无 services"

            svc = services[0]
            status = (svc.get("status") or "").lower()
            is_running = status == "running"
            print(f"  status = {status}")

            if not service_group_id:
                service_group_id = data.get("service_group_id")
                print(f"  [auto] service_group_id = {service_group_id}")

            if not pod_name:
                pods = svc.get("pod_infos") or []
                if pods:
                    pod_name = pods[0].get("name") or pods[0].get("Name")
                    print(f"  [auto] pod_name = {pod_name}")

            assert is_running, (
                f"服务当前 status={status}，不是 Running。"
                f"本测试要求服务已在 Running 状态下执行。"
            )
            return f"status={status}, pod={pod_name}"

        _get()

        # 没起来 / 没 pod 的话，后面几步都没法跑
        if not is_running:
            print("\n⏭ 服务未 Running，跳过后续所有步骤")
            fail_cnt = _print_summary("Running Service Integration Test", results)
            assert fail_cnt == 0
            return

        # ── STEP 2: get_pod_logs ──────────────────────────────────
        @step("2) get_pod_logs")
        def _logs():
            if not pod_name:
                raise RuntimeError("pod_name 未拿到")
            logs = client.get_pod_logs(
                service_id=existing_service_id,
                pod_name=pod_name,
                limit=20,
            )
            n = len(logs.get("logs", []))
            print(f"  拿到 {n} 条日志")
            if n > 0:
                first_msg = logs["logs"][0].get("message", "")[:80]
                print(f"  首条: {first_msg}")
            return f"logs={n}"

        _logs()

        # ── STEP 3: debug_pod_shell ───────────────────────────────
        @step("3) debug_pod_shell")
        def _shell():
            if not pod_name:
                raise RuntimeError("pod_name 未拿到")
            r = client.debug_pod_shell(
                service_id=existing_service_id,
                pod_name=pod_name,
            )
            url = r.get("url") or r.get("Url")
            print(f"  shell url = {url}")
            assert url, f"debug_pod_shell 未返回 url: {r}"
            return "url ok"

        _shell()

        # ── STEP 4: predict ───────────────────────────────────────
        @step("4) predict")
        def _predict():
            if not service_group_id:
                raise RuntimeError(
                    "service_group_id 未拿到（显式传 "
                    "IT_EXISTING_SERVICE_GROUP_ID 或检查 get_deployment 返回）"
                )
            inputs = json.loads(PREDICT_INPUT_JSON)
            result = client.predict(
                deployment_name=service_group_id,
                inputs=inputs,
                endpoint=PREDICT_ENDPOINT,
            )
            print(f"  predict result = {json.dumps(result, ensure_ascii=False, default=str)[:200]}")
            return "ok"

        _predict()

        # ── STEP 5: restart_pod（默认跳过，加环境变量才跑）─────────
        if allow_restart and pod_name:
            @step("5) restart_pod")
            def _restart():
                r = client.restart_pod(
                    service_id=existing_service_id,
                    pod_name=pod_name,
                )
                print(f"  request_id = {r.get('request_id')}")
                assert r.get("request_id"), f"restart_pod 无 request_id: {r}"
                return "ok"

            _restart()
        else:
            skip_reason = (
                "未设 IT_ALLOW_RESTART=1（重启会影响可用性）"
                if not allow_restart else "pod_name 未拿到"
            )
            results["5) restart_pod"] = ("⏭", skip_reason)
            print(f"\n⏭ [STEP] 5) restart_pod 跳过（{skip_reason}）")

        # ── 汇总 ────────────────────────────────────────────────
        fail_cnt = _print_summary("Running Service Integration Test", results)
        assert fail_cnt == 0, (
            f"Running service 有 {fail_cnt} 个步骤失败，详见上方 SUMMARY"
        )