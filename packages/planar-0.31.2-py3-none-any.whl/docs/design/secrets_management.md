# Pluggable Secrets Management

## 1. Context & Motivation

The Planar configuration system (`PlanarConfig`) originally relied exclusively on environment variable substitution during config loading. This has limitations:

- **Security Risk**: Sensitive secrets must be exposed as environment variables, which can leak into logs or debugging output.
- **Operational Complexity**: Managing secrets across environments and clouds requires external orchestration to inject them as env vars before the application starts.
- **Lack of Flexibility**: No native framework-level support for fetching secrets directly from dedicated secrets management services (AWS Secrets Manager, Azure Key Vault).
- **No Runtime Refresh**: Secrets baked into config at boot become stale when credentials are rotated, requiring a full restart.

## 2. Objective

A pluggable secrets management system integrated into the configuration loading lifecycle. Secrets are referenced in `planar.yaml` using a custom syntax, resolved at runtime from configured providers, and automatically refreshed via TTL-based caching. The system supports custom user-defined providers.

## 3. Architecture

### 3.1. Secret Provider Protocol

All secret providers implement a consistent interface:

```python
# planar/secrets/protocol.py

class SecretProvider(Protocol):
    def get_secret(self, secret_id: str) -> str:
        """
        Retrieve a secret by its ID.
        Raises SecretNotFoundError if the secret is not found.
        Raises SecretAccessError on permission or network errors.
        """
        ...
```

### 3.2. Concrete Providers

Three built-in providers in `planar/secrets/providers.py`:

1.  **`EnvVarSecretProvider`**: Wraps `os.environ`. Default fallback.
2.  **`AwsSecretsManagerProvider`**: Fetches from AWS Secrets Manager via `boto3`.
3.  **`AzureKeyVaultProvider`**: Fetches from Azure Key Vault via `azure-keyvault-secrets`.

### 3.3. Secret Registry

The `SecretRegistry` manages provider instances, handles secret resolution, and owns the TTL cache:

```python
class SecretRegistry:
    _provider_types: dict[str, Type[SecretProvider]] = { ... }

    @classmethod
    def register_provider_type(cls, name: str, provider_cls: Type[SecretProvider]) -> None:
        """Register a custom provider class with a label."""
        ...

    def resolve_secret(
        self, provider_name: str, secret_id: str, json_key: str | None = None
    ) -> SecretStr:
        """
        Resolve a secret value, using a per-provider TTL cache.

        The cache is keyed by (provider_name, secret_id) so that multiple
        json_key extractions from the same secret share one provider fetch.
        """
        ...
```

The registry caches raw provider responses keyed by `(provider_name, secret_id)`. Multiple `json_key` extractions from the same secret share one cached fetch. Each provider has a configurable TTL; only stale values trigger an external fetch.

### 3.4. RefreshableSecret

A `SecretStr` subclass that re-resolves from its provider on each `.get_secret_value()` call:

```python
# planar/secrets/refreshable.py

class RefreshableSecret(SecretStr):
    """A SecretStr whose value is re-resolved from a provider on each access."""

    resolver: Callable[[], str]

    def __init__(self, *, resolver: Callable[[], str]) -> None:
        super().__init__(resolver())
        self.resolver = resolver

    def get_secret_value(self) -> str:
        return self.resolver()
```

Key properties:

- Calls `resolver()` during `__init__` to populate the initial `SecretStr` value (fail-fast on bad config, and a real value for Pydantic coercion).
- Every subsequent `.get_secret_value()` call goes through the resolver, which hits the registry's TTL cache.
- Passes `isinstance(x, SecretStr)` checks, so all existing call sites work unchanged.

**Hardcoded values** (no `${secret:...}` syntax): remain plain `SecretStr`, unchanged. Only provider-backed references become `RefreshableSecret`.

## 4. Configuration Schema

### 4.1. Provider Configuration

```python
class SecretsProviderConfig(BaseModel):
    provider: str  # "env", "aws_secrets_manager", "azure_key_vault", or custom
    options: dict[str, Any] = Field(default_factory=dict)

class SecretsSection(BaseModel):
    providers: dict[str, SecretsProviderConfig] = Field(default_factory=dict)
    custom_secrets: dict[str, SecretStr] = Field(default_factory=dict)
```

### 4.2. TTL Configuration

Each provider has a default TTL. Users can override per-provider via the `ttl` option:

| Provider type            | Default TTL | Rationale                                    |
| ------------------------ | ----------- | -------------------------------------------- |
| `aws_secrets_manager`    | 300s        | Balance freshness vs. API cost               |
| `azure_key_vault`        | 300s        | Same                                         |
| All others (env, custom) | `inf`       | Cache forever unless user opts in to refresh |

To enable periodic refresh for a provider, set `ttl` in its options. Use `0` for no caching (fetch on every access), or `.inf` to explicitly cache forever.

```yaml
secrets:
  providers:
    aws_prod:
      provider: aws_secrets_manager
      options:
        region: us-west-2
        ttl: 120 # refresh every 2 minutes
```

## 5. Resolution Syntax

Custom interpolation syntax within YAML configuration:

```
${secret:<provider_name>:<secret_id>[:<json_key>]}
```

- `provider_name`: Matches a key in `secrets.providers`.
- `secret_id`: The identifier used by the provider (supports ARN-style IDs).
- `json_key` (Optional): If the secret value is a JSON string, extract this field.

## 6. Implementation: Two-Pass Loading

### Phase 1: Bootstrap

1.  **Load Raw YAML** into a raw Python dictionary.
2.  **Env expansion (scoped)**: Expand `${VAR}` patterns in the `secrets` section only (so provider config can reference env vars).
3.  **Initialize Registry**: Instantiate providers from config, store per-provider TTLs.

### Phase 2: Resolution

1.  **Global env expansion**: Expand `${VAR}` patterns across the entire config.
2.  **Secret resolution**: For every string matching `${secret:...}`, create a `RefreshableSecret` with a resolver closure. The `RefreshableSecret` constructor calls the resolver immediately (fail-fast validation + initial cached value).

### Phase 3: Validation

1.  **Model validation**: Pass the resolved dictionary to `PlanarConfig.model_validate()`. `RefreshableSecret` instances pass through as `SecretStr` subclass instances.

## 7. Runtime Secret Refresh

### How It Works

Freshness is handled transparently:

1. Code calls `.get_secret_value()` on a config field (e.g., `password`).
2. If the field is a `RefreshableSecret`, it calls the resolver closure.
3. The resolver calls `registry.resolve_secret(...)`.
4. The registry checks its TTL cache. If fresh, returns cached value. If stale, fetches from the provider and updates the cache.

### SQLAlchemy Integration

The PostgreSQL engine is created with `pool_pre_ping=True`, which sends a health check before reusing pooled connections. When a rotated password causes the server to kill old connections, the pre-ping detects the failure, discards the stale connection, and opens a new one — firing the `do_connect` event with fresh credentials:

```
pool_pre_ping detects dead connection -> opens new connection
  -> do_connect fires
    -> _provide_credentials() calls self.db_url_provider()    # DatabaseManager
    -> lambda: self.config.connection_url()                   # PlanarApp
    -> PostgreSQLConfig.connection_url()                      # config.py
    -> self.password.get_secret_value()                       # RefreshableSecret
    -> resolver() -> registry.resolve_secret()                # TTL-cached
```

### DuckDB Connection Staleness

DuckDB connections embed credentials in `CREATE SECRET` SQL at creation time and cannot be refreshed in-place. The connection pool in `planar/data/connection.py` uses age-based expiry combined with a secret fingerprint check: when a pool is older than `_CONNECTION_MAX_AGE_SECONDS`, the current secret values are re-resolved and hashed into a fingerprint. If the fingerprint matches the one stored at pool creation time, the pool's age is reset and existing connections are reused. If the fingerprint differs (i.e., a credential has actually rotated), the stale pool is discarded and rebuilt with fresh credentials via `RefreshableSecret`.

## 8. Example Usage

### Built-in Provider

```yaml
secrets:
  providers:
    aws_prod:
      provider: aws_secrets_manager
      options:
        region: us-west-2

app:
  db_connection: app
db_connections:
  app:
    driver: postgresql
    password: ${secret:aws_prod:prod/db/credentials:password}
```

### Custom Provider (Registered via Code)

Register a custom provider before `PlanarApp()` is created:

```python
# main.py
from planar.secrets.protocol import SecretProvider
from planar.secrets.registry import SecretRegistry

class MyCustomProvider(SecretProvider):
    def __init__(self, options: dict[str, Any]):
        self.options = options

    def get_secret(self, secret_id: str) -> str:
        # ... implementation ...
        pass

SecretRegistry.register_provider_type("my_custom", MyCustomProvider)

app = PlanarApp()
```

```yaml
# planar.yaml
secrets:
  providers:
    my_vault:
      provider: my_custom
      options:
        url: https://vault.myorg.internal
  custom_secrets:
    stripe: ${secret:my_vault:stripe_live_key}
```

### Accessing Secrets in Code

Secrets are available as standard values in the `PlanarConfig` object:

```python
from planar.config import load_environment_aware_config

config = load_environment_aware_config()

# Accessing a custom secret
stripe_key = config.secrets.custom_secrets["stripe"]
```

## 9. Deliverables

1.  `planar/secrets/protocol.py`: `SecretProvider` protocol and error classes.
2.  `planar/secrets/providers.py`: Built-in provider implementations.
3.  `planar/secrets/registry.py`: `SecretRegistry` with TTL caching.
4.  `planar/secrets/refreshable.py`: `RefreshableSecret` class.
5.  `planar/config.py`: Updated `PlanarConfig` and `load_environment_aware_config`.
6.  `planar/data/connection.py`: Age-based DuckDB connection pool expiry.
7.  Tests for registry, providers, config loading, and secret rotation e2e.
