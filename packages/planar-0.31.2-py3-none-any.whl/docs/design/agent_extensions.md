# Agent Extension Framework

## Overview

Extensions are composable capability bundles that contribute tools, instructions, and runtime hooks to an agent. Each extension is a subclass of `AgentExtension`.

Extensions also have a serialization API so Planar can expose extension metadata in APIs and UIs, and record which extension configuration and per-run options were used for a specific agent run. It is for inspection and run history, not for persisting or reconstructing in-memory runtime state.

An extension can provide:

- tools via `get_tools()`
- instruction fragments via `get_instructions()`
- typed per-run options via `options_type`
- run lifecycle hooks (`before_run`, `after_run`, `on_run_error`, `teardown_run`)
- model hooks (`before_model_run`, `after_model_run`)
- tool hooks (`before_tool_call`, `after_tool_call`, `on_tool_error`)
- serialization via `describe()`, `serialize_config()`, `serialize_options()`

## `AgentExtension`

```python
from planar.ai.extensions import AgentExtension

class AgentExtension:
    # Class-level identity and configuration
    extension_key: ClassVar[str | None] = None
    extension_version: ClassVar[int] = 1
    options_type: ClassVar[type[Any] | None] = None

    # --- Static configuration (called at agent construction) ---

    def get_tools(self) -> list[Callable[..., Any]]:
        """Return tools contributed by this extension."""
        return []

    def get_instructions(self) -> str | None:
        """Return instruction text prepended to the system prompt."""
        return None

    # --- Run lifecycle hooks ---

    async def before_run(self, *, ctx: ExtensionRunContext) -> None: ...
    async def after_run(self, *, ctx, result) -> AgentRunResult[Any]: ...
    async def on_run_error(self, *, ctx, error) -> AgentRunResult[Any]: ...
    async def teardown_run(self, *, ctx, error) -> None: ...

    # --- Model hooks ---

    async def before_model_run(self, *, ctx, messages) -> list[ModelMessage]: ...
    async def after_model_run(self, *, ctx, run_response) -> ModelRunResponse[Any]: ...

    # --- Tool hooks ---

    async def before_tool_call(self, *, ctx, tool_fn, tool_args) -> dict[str, Any]: ...
    async def after_tool_call(self, *, ctx, tool_fn, raw_result) -> Any: ...
    async def on_tool_error(self, *, ctx, tool_fn, error) -> Exception | None: ...

    # --- Serialization ---

    def describe(self, options: BaseModel | None = None) -> ExtensionDescriptor: ...
    def serialize_config(self) -> dict[str, Any] | None: ...
    def serialize_options(self, options: BaseModel) -> dict[str, Any] | None: ...
```

### Class variables

| Variable            | Purpose                                                                                                                          |
| ------------------- | -------------------------------------------------------------------------------------------------------------------------------- |
| `extension_key`     | Stable identifier for UI metadata and historical run snapshots. Defaults to the class name if `None`.                            |
| `extension_version` | Version number for schema evolution.                                                                                             |
| `options_type`      | Pydantic `BaseModel` subclass that this extension accepts at call time. Set to `None` if the extension takes no per-run options. |

### Hook semantics

- **`before_*`**: may modify inputs, returns the modified value.
- **`after_*`**: success-only, may transform outputs.
- **`on_*_error`**: error-only. May re-raise, translate, or recover. For `on_run_error`, returning an `AgentRunResult` recovers. For `on_tool_error`, returning `None` propagates the original error; returning an `Exception` replaces it.
- **`teardown_run`**: always runs (even if `before_run` fails), cleanup only, returns `None`. Exceptions are swallowed.

### Serialization methods

- **`describe(options)`**: Returns an `ExtensionDescriptor` for live agent metadata. Called with no options for live agent listing; called with matched options when building run snapshots.
- **`serialize_config()`**: Returns serializable static config for the descriptor's `config` field.
- **`serialize_options(options)`**: Returns serializable per-run options for the descriptor's `options` field.

## `ExtensionRunContext`

The per-run context object passed to all hooks:

```python
@dataclass
class ExtensionRunContext:
    agent: AgentInfo
    input_value: BaseModel | str
    extension_options: list[object]

    def options_for(self, extension: AgentExtension) -> T | None:
        """Return the typed options object for this extension, or None."""

    def state_for(self, extension: AgentExtension) -> dict[str, Any]:
        """Return mutable per-run scratch state for this extension."""
```

- **`options_for(self)`** matches the caller-supplied `extension_options` list against `extension.options_type` using exact type equality.
- **`state_for(self)`** returns a per-extension-instance dict that lives for the duration of the run. Use it for counters, provider handles, cached values, or teardown coordination. It is not durable.

## Tools and Instructions Composition

At agent construction, extensions contribute their static configuration:

- **Tools**: deduped by name. Priority: direct agent tools first, then extension tools from last extension to first.
- **Instructions**: concatenated in extension declaration order. The agent's own `system_prompt` is appended last.

## Runtime Hook Ordering

- `before_*` hooks run in extension declaration order.
- `after_*`, `on_*_error`, and `teardown_run` run in reverse declaration order.

This gives middleware-style unwinding while keeping input shaping predictable.

## Writing a Custom Extension

```python
from collections.abc import Callable
from typing import Any, ClassVar

from pydantic import BaseModel

from planar.ai.extensions import AgentExtension, ExtensionRunContext


class AuditOptions(BaseModel):
    tenant_id: str


class AuditExtension(AgentExtension):
    extension_key = "audit"
    options_type = AuditOptions

    async def before_run(self, *, ctx: ExtensionRunContext) -> None:
        options = ctx.options_for(self)
        if options:
            ctx.state_for(self)["tenant_id"] = options.tenant_id

    async def after_tool_call(
        self,
        *,
        ctx: ExtensionRunContext,
        tool_fn: Callable[..., Any],
        raw_result: Any,
    ) -> Any:
        tenant_id = ctx.state_for(self).get("tenant_id")
        logger.info("tool call completed", tool=tool_fn.__name__, tenant_id=tenant_id)
        return raw_result
```

Use it on any agent:

```python
agent = Agent(
    name="audited_agent",
    system_prompt="...",
    model="openai:gpt-4.1",
    extensions=[AuditExtension()],
)

result = await agent("...", extension_options=[AuditOptions(tenant_id="acme")])
```

## Built-in Extensions

### `SandboxExtension`

Adds sandboxed code execution (Python, bash, file operations):

- Tools: `execute_python`, `bash`, `read_file`, `write_file`, `read_file_bytes`, `list_files`, `delete_file`
- Options: `SandboxOptions(files=...)` for mounting `PlanarFile` objects
- Lifecycle: creates sandbox provider in `before_run`, cleans up in `teardown_run`
- Tool interception: unwraps `SandboxToolResult` in `after_tool_call`

Each sandbox tool is decorated with `@sandbox_tool`, which handles snapshot threading for durable replay.

### `IOExtension`

Adds operator-facing display and input tools:

- Display tools: `display_markdown`, `display_table`, `display_object`
- Input tools: `request_text_input`, `request_confirmation`, `request_table_input`

## Durability Constraints

The extension framework does not change the durability model:

- `ctx.state_for(extension)` is scratch state only — it does not survive replay.
- Lifecycle, model, and tool hooks run outside durable step boundaries. They may rebuild ephemeral runtime state from durable references (creating providers, loading files from stable IDs), but they must not become the source of truth for replay-critical data.
- Replay-critical behavior must live inside durable steps or durable tool wrappers (e.g. `@sandbox_tool`).
