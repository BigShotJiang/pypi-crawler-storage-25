# Testing Workflows

## Basic Setup

Create an `app` fixture for your test file:

```python
import pytest
from planar import PlanarApp, sqlite_config

@pytest.fixture(name="app")
def app_fixture(tmp_db_path: str):
    app = PlanarApp(
        config=sqlite_config(tmp_db_path),
        title="Test App",
        description="Testing",
    )
    yield app
```

## Important: Avoid Internal Orchestrator APIs

**Do not use internal orchestrator APIs like `execute()` in tests that use `PlanarTestClient` or `PlanarApp` fixtures.** These fixtures run a full orchestrator that automatically calls `execute()` on started workflows. Using `execute()` directly will cause conflicts and unpredictable behavior.

```python
# WRONG - Never do this in tests with PlanarApp/PlanarTestClient
async def test_bad_example(app: PlanarApp, client: PlanarTestClient):
    wf = await my_workflow.start()
    result = await execute(wf)  # ❌ Don't call execute() directly!

# CORRECT - Use the orchestrator's wait_for_completion
async def test_good_example(app: PlanarApp, client: PlanarTestClient):
    resp = await client.post("/planar/v1/workflows/my_workflow/start", json={})
    workflow_id = UUID(resp.json()["id"])
    result = await app.orchestrator.wait_for_completion(workflow_id)  # ✓ Correct
```

## Pure Manual Workflow Tests

Use this pattern when you want deterministic control over execution and do not need the app lifespan or HTTP routes.

```python
async def test_manual_workflow_execution(session: AsyncSession):
    @workflow()
    async def my_workflow():
        return "done"

    wf = await my_workflow.start()
    result = await execute(wf)

    assert result == "done"
```

Important:

- Do not request the `client` fixture in these tests.
- The `client` fixture starts app lifespan, which starts the background orchestrator.
- `execute(wf)` should be the only workflow driver in the test.

## Mixed Tests: Manual Execution Before API Calls

Some tests need manual workflow execution first and HTTP requests later. In that case, do not request the `client` fixture up front. This is an alternative to `orchestrator.wait_for_completion` which still lets the orchestrator drive the workflow to completion.

Instead:

- request `app`, `observer`, and `session`
- manually call `_workflow.start()` and `execute(wf)` first
- only then open `planar_test_client(app, observer=observer)` for the HTTP portion

```python
async def test_manual_then_api(
    app: PlanarApp,
    observer: WorkflowObserver,
    session: AsyncSession,
):
    wf = await my_workflow.start()
    result = await execute(wf)
    assert isinstance(result, Suspend)

    async with planar_test_client(app, observer=observer) as client:
        response = await client.post("/planar/v1/...")
        assert response.status_code == 200
```

This keeps the orchestrator out of the test until the HTTP section begins.

## Simple Workflow Test

```python
async def test_simple_workflow(
    client: PlanarTestClient,
    app: PlanarApp
):
    @step()
    async def process_data(value: int):
        return value * 2

    @workflow()
    async def my_workflow(input_value: int):
        result = await process_data(input_value)
        return result

    app.register_workflow(my_workflow)

    resp = await client.post(
        "/planar/v1/workflows/my_workflow/start",
        json={"input_value": 5}
    )
    workflow_id = UUID(resp.json()["id"])

    result = await app.orchestrator.wait_for_completion(workflow_id)
    assert result == 10
```

## Using asyncio.Event for Coordination

```python
async def test_workflow_coordination(
    client: PlanarTestClient,
    app: PlanarApp
):
    signal = asyncio.Event()

    @step()
    async def long_step():
        return "done"

    @workflow()
    async def blocking_workflow():
        await signal.wait()  # Block until signal is set
        result = await long_step()
        return result

    app.register_workflow(blocking_workflow)

    resp = await client.post(
        "/planar/v1/workflows/blocking_workflow/start",
        json={}
    )
    workflow_id = UUID(resp.json()["id"])

    # Do something while workflow is blocked
    # ...

    signal.set()  # Unblock the workflow
    result = await app.orchestrator.wait_for_completion(workflow_id)
    assert result == "done"
```

## Using WorkflowObserver

```python
async def test_with_observer(
    client: PlanarTestClient,
    app: PlanarApp,
    observer: WorkflowObserver,
):
    @step()
    async def quick_step():
        return "step_done"

    @workflow()
    async def observable_workflow():
        await quick_step()
        await suspend(interval=timedelta(seconds=60))
        return "done"

    app.register_workflow(observable_workflow)

    resp = await client.post(
        "/planar/v1/workflows/observable_workflow/start",
        json={}
    )
    workflow_id = UUID(resp.json()["id"])

    # Wait for workflow to suspend
    await observer.wait(Notification.WORKFLOW_SUSPENDED, workflow_id)

    # Verify suspended state
    async with session.begin_read():
        wf = await session.get(Workflow, workflow_id)
        assert wf
    assert wf.status == WorkflowStatus.PENDING
    assert wf.wakeup_at is not None
```

## Verifying Database State

```python
async def test_workflow_state(
    client: PlanarTestClient,
    session: PlanarSession,
    app: PlanarApp
):
    @workflow()
    async def simple_workflow():
        return "completed"

    app.register_workflow(simple_workflow)

    resp = await client.post(
        "/planar/v1/workflows/simple_workflow/start",
        json={}
    )
    workflow_id = UUID(resp.json()["id"])

    await app.orchestrator.wait_for_completion(workflow_id)

    # Verify database state
    async with session.begin_read():
        wf = await session.get(Workflow, workflow_id)
    assert wf
    assert wf.status == WorkflowStatus.SUCCEEDED
```

## Refreshing ORM State After API Writes

`PlanarSession` uses `expire_on_commit=False`, so ORM objects remain cached across commits.

If an API request or another session modifies rows that are already loaded in your test session, expire or refresh those objects before asserting on relationships or other derived state.

```python
await session.refresh(task)
# or
session.expire(task)
updated_task = (await session.exec(select(HumanTask).where(HumanTask.id == task.id))).one()
```

Common symptom if you forget this:

- assertions still see the old assignment or scope after a successful API request

## Key Points

- Always register workflows with `app.register_workflow()`
- Use `client.post()` to start workflows via the API
- Use `app.orchestrator.wait_for_completion()` to wait for results
- **Never call `execute()` directly in tests with `PlanarApp` or `PlanarTestClient` fixtures**
- For pure manual workflow tests, do not request `client` fixture
- If a test needs manual execution before an API call, start `planar_test_client(...)` only for the HTTP section
- Use `asyncio.Event()` to coordinate workflow execution timing
- Use `observer.wait()` to wait for specific workflow events
- Verify database state with `session.begin_read()` and `session.get()`
- Expire or refresh ORM objects after cross-session writes before asserting on them
