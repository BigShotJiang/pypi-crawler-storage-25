from datetime import date, datetime
from enum import Enum
from typing import Annotated, Any, Literal, Self
from uuid import UUID

from pydantic import BaseModel, Field, model_validator

from planar.exceptions import ErrorDetails
from planar.modeling.field_helpers import JsonSchema
from planar.routers.step_metadata import StepMetadata
from planar.workflows import Workflow
from planar.workflows.models import (
    StepStatus,
    StepType,
    WorkflowStatus,
    WorkflowStep,
)
from planar.workflows.visualization_spec import VisualizationGraph

# Alias for backward compatibility in workflow context
StepRunError = ErrorDetails


class EntityMetadata(BaseModel):
    name: str
    description: str | None = None
    json_schema: JsonSchema
    instance_count: int = 0


class EntityInstance(BaseModel):
    id: str
    entity_name: str
    data: dict[str, Any]


class EntityInstanceList(BaseModel):
    items: list[EntityInstance]
    total: int
    offset: int
    limit: int


class SortDirection(str, Enum):
    """Enum for sort direction options."""

    ASC = "asc"
    DESC = "desc"


class TextEntityFilter(BaseModel):
    filter_type: Literal["text"] = Field(default="text", init=False)
    field: str
    operator: Literal["is", "is_not", "contains", "starts_with"]
    value: str
    value_end: None = None


class NumberEntityFilter(BaseModel):
    filter_type: Literal["number"] = Field(default="number", init=False)
    field: str
    operator: Literal["==", "!=", ">", ">=", "<", "<="]
    value: float
    value_end: None = None


class DateEntityFilter(BaseModel):
    filter_type: Literal["date"] = Field(default="date", init=False)
    field: str
    operator: Literal["before", "after", "between"]
    value: date | datetime
    value_end: date | datetime | None = None


class EnumEntityFilter(BaseModel):
    filter_type: Literal["enum"] = Field(default="enum", init=False)
    field: str
    operator: Literal["is", "is_not"]
    value: list[str]
    value_end: None = None


EntityQueryFilter = Annotated[
    TextEntityFilter | NumberEntityFilter | DateEntityFilter | EnumEntityFilter,
    Field(discriminator="filter_type"),
]


class EntityInstancesQuery(BaseModel):
    skip: int = 0
    limit: int = 100
    filters: list[EntityQueryFilter] = Field(default_factory=list)
    sort_field: str | None = None
    sort_direction: SortDirection | None = None


# Models related to the workflow management REST API
class WorkflowStartResponse(BaseModel):
    id: UUID


class ForkWorkflowRequest(BaseModel):
    last_completed_step_id: int | None = Field(
        default=None,
        description="The last completed step ID to copy from the source workflow. "
        "If not provided, the forked workflow will start from scratch with no steps copied.",
    )


class WorkflowStatusResponse(BaseModel):
    workflow: Workflow


class DurationStats(BaseModel):
    min_seconds: int | None = None
    avg_seconds: int | None = None
    max_seconds: int | None = None


class WorkflowRunStatusCounts(BaseModel):
    """Type-safe representation of workflow run status counts."""

    # Virtual statuses (computed, never persisted)
    running: int = 0
    suspended: int = 0

    # Persisted statuses (stored in database)
    pending: int = 0
    succeeded: int = 0
    failed: int = 0
    cancelled: int = 0


class WorkflowDefinition(BaseModel):
    fully_qualified_name: str
    name: str
    description: str | None = None
    input_schema: JsonSchema | None = None
    output_schema: JsonSchema | None = None
    total_runs: int
    run_statuses: WorkflowRunStatusCounts
    durations: DurationStats | None = None
    is_interactive: bool


class StepStats(BaseModel):
    completed: int = 0
    failed: int = 0
    running: int = 0


class WorkflowRun(BaseModel):
    id: UUID
    status: WorkflowStatus
    args: list[Any] | None = None
    kwargs: dict[str, Any] | None = None
    result: Any | None = None
    error: dict[str, Any] | None = None
    created_at: datetime
    updated_at: datetime
    step_stats: StepStats
    started_by: str | None = None
    cancelled_by: str | None = None


class WorkflowStepInfo(BaseModel):
    step_id: int
    is_internal_step: bool = Field(
        default=False,
        description="Whether the step is an internal Planar step, or a user-defined step",
    )
    parent_step_id: int | None = None
    workflow_id: UUID
    function_name: str
    display_name: str
    description: str | None = None
    step_type: StepType
    status: StepStatus
    args: list[Any] | None = None
    kwargs: dict[str, Any] | None = None
    result: Any | None = None
    error: StepRunError | None = None
    retry_count: int
    created_at: datetime
    updated_at: datetime
    meta: StepMetadata | None = Field(
        default=None,
        description="Step type-specific rich data (e.g., human task details for human_in_the_loop steps)",
    )

    def model_post_init(self, context: Any) -> None:
        if self.function_name.startswith("planar."):
            self.is_internal_step = True

    @staticmethod
    def get_display_name(custom_name: str | None, function_name: str) -> str:
        """
        If provided, use custom name, otherwise extract function name from a "fully qualified" function name.

        For example, 'module.directory.fn_name' becomes 'fn_name'.
        If there are no periods in the string, returns the original string.
        """
        return custom_name or function_name.rsplit(".", maxsplit=1)[-1]

    @classmethod
    def from_step(cls, step: WorkflowStep, metadata: dict[int, StepMetadata]) -> Self:
        return cls(
            step_id=step.step_id,
            parent_step_id=step.parent_step_id,
            workflow_id=step.workflow_id,
            function_name=step.function_name,
            display_name=cls.get_display_name(step.display_name, step.function_name),
            description=None,
            status=step.status,
            step_type=step.step_type,
            args=step.args,
            kwargs=step.kwargs,
            result=step.result,
            error=StepRunError.model_validate(step.error) if step.error else None,
            retry_count=step.retry_count,
            created_at=step.created_at,
            updated_at=step.updated_at,
            # Use .get because metadata may be unavailable for some steps
            meta=metadata.get(step.step_id),
        )

    @model_validator(mode="after")
    def validate_meta_step_type(self):
        """
        Make sure the outer step_type agrees with whatever subtype was
        chosen for `meta`. This runs *after* normal field validation,
        so `self.meta` is already an instantiated metadata object.
        """
        if self.meta is None:
            return self  # nothing to compare

        if self.step_type != self.meta.step_type:
            raise ValueError(
                f"meta.step_type={self.meta.step_type!r} does not match "
                f"outer step_type={self.step_type!r}"
            )
        return self


class WorkflowRunList(BaseModel):
    items: list[WorkflowRun]
    total: int
    offset: int | None
    limit: int | None


class WorkflowStepList(BaseModel):
    items: list[WorkflowStepInfo]
    total: int
    offset: int | None
    limit: int | None


class WorkflowList(BaseModel):
    items: list[WorkflowDefinition]
    total: int
    offset: int | None
    limit: int | None


class WorkflowVisualizationResponse(BaseModel):
    graph: VisualizationGraph | None
    from_cache: bool
    generated_at: datetime | None = None
    llm_model: str | None = None
