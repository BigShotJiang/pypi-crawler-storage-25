"""
Utility functions for gathering rich metadata for workflow steps.

This module provides helper functions for getting step-specific
metadata for the various step types in Planar workflows.
"""

from datetime import datetime
from typing import Annotated, Any, Literal, Self
from uuid import UUID

from pydantic import BaseModel, Field
from sqlmodel import select

from planar.ai.models import ToolCall
from planar.ai.utils import AgentSerializeable, get_agent_serializable
from planar.human import HumanTask, HumanTaskStatus
from planar.logging import get_logger
from planar.object_registry import ObjectRegistry
from planar.rules.models import (
    RuleSerializeable,
)
from planar.rules.rule_configuration import rule_configuration
from planar.session import get_session
from planar.workflows.models import StepType, WorkflowStep
from planar.workflows.step_meta import (
    HumanTaskMeta,
    deserialize_step_metadata,
)

logger = get_logger(__name__)


type JsonObject = dict[str, JsonValue | None]
type JsonValue = JsonObject | str | int | float | bool | list[JsonValue | None]


class HumanTaskInputs(BaseModel):
    input_data: JsonObject | None = None
    message: str | None = None
    suggested_data: JsonObject | None = None

    @classmethod
    def from_step_args(cls, args: list[Any] | None) -> Self | None:
        """Extract human task inputs from the step's positional args.

        Human.run_step is called with positional args in the order:
        (input_data, message, suggested_data, assigned_to, scoped_to)
        """
        if not args:
            return None
        input_data = args[0] if len(args) > 0 else None
        message = args[1] if len(args) > 1 else None
        suggested_data = args[2] if len(args) > 2 else None

        out = cls(
            input_data=input_data if isinstance(input_data, dict) else None,
            message=message if isinstance(message, str) else None,
            suggested_data=suggested_data if isinstance(suggested_data, dict) else None,
        )
        if (
            out.input_data is None
            and out.message is None
            and out.suggested_data is None
        ):
            return
        return out


class HumanTaskOutputs(BaseModel):
    task_id: UUID
    status: HumanTaskStatus = HumanTaskStatus.COMPLETED
    output: JsonObject | None = None
    completed_at: datetime
    cancellation_reason: str | None = None


class HumanTaskMetadata(BaseModel):
    """Metadata wrapper for human task steps."""

    step_type: Literal[StepType.HUMAN_IN_THE_LOOP] = StepType.HUMAN_IN_THE_LOOP
    human_task: HumanTask
    inputs: HumanTaskInputs | None = None
    outputs: HumanTaskOutputs | None = None

    @classmethod
    async def from_step(cls, step: WorkflowStep) -> Self | None:
        task_id = None
        if step.meta_payload:
            meta = deserialize_step_metadata(step.meta_payload, HumanTaskMeta)
            task_id = meta.task_id

        if task_id is None:
            logger.debug(
                "human task metadata not found",
                workflow_id=step.workflow_id,
                step_id=step.step_id,
            )
            return None

        session = get_session()
        async with session.begin_read():
            task = await session.get(HumanTask, task_id)
            if not task:
                logger.debug(
                    "human task not found",
                    task_id=str(task_id),
                    workflow_id=step.workflow_id,
                    step_id=step.step_id,
                )
                return None

        inputs = HumanTaskInputs.from_step_args(step.args)
        outputs = None
        if step.result is not None and isinstance(step.result, dict):
            outputs = HumanTaskOutputs.model_validate(step.result)
        return cls(human_task=task, inputs=inputs, outputs=outputs)


class AgentOutputs(BaseModel):
    output: JsonObject | str


class AgentMetadata(BaseModel):
    """Metadata wrapper for agent steps."""

    step_type: Literal[StepType.AGENT] = StepType.AGENT
    agent: AgentSerializeable
    inputs: JsonObject | str | None
    outputs: AgentOutputs | None

    @classmethod
    async def from_step(
        cls, step: WorkflowStep, registry: ObjectRegistry
    ) -> Self | None:
        if not step.display_name:
            logger.debug(
                "agent step display_name not found",
                workflow_id=step.workflow_id,
                step_id=step.step_id,
            )
            return None

        agent_name = step.display_name
        logger.debug("agent name from step display_name", agent_name=agent_name)

        agent_serializable = await get_agent_serializable(
            agent_name=agent_name, registry=registry
        )

        if not agent_serializable:
            logger.debug("agent serializable not found", agent_name=agent_name)
            return None

        raw_input = step.kwargs and step.kwargs.get("input_value")
        inputs = raw_input if isinstance(raw_input, (dict, str)) else None

        raw_output = (
            step.result.get("output") if isinstance(step.result, dict) else None
        )
        outputs = (
            AgentOutputs(output=raw_output)
            if isinstance(raw_output, (dict, str))
            else None
        )

        return cls(agent=agent_serializable, inputs=inputs, outputs=outputs)


class RuleMetadata(BaseModel):
    """Metadata wrapper for rule steps."""

    step_type: Literal[StepType.RULE] = StepType.RULE
    rule: RuleSerializeable
    inputs: JsonObject | list[JsonObject] | None
    outputs: JsonObject | list[JsonObject] | None

    @classmethod
    async def from_step(
        cls, step: WorkflowStep, registry: ObjectRegistry
    ) -> Self | None:
        rule_name = extract_simple_name(step.function_name)
        logger.debug("rule name extracted", rule_name=rule_name)

        rule = next((r for r in registry.get_rules() if r.name == rule_name), None)

        if not rule:
            logger.debug("rule not found in registry", rule_name=rule_name)
            return None

        configs = await rule_configuration.read_configs_with_default(
            rule_name, rule.to_config()
        )
        logger.debug(
            "retrieved configs for rule",
            count=len(configs),
            rule_name=rule_name,
        )

        rule_serializable = RuleSerializeable(
            input_schema=rule.input.model_json_schema(),
            output_schema=rule.output.model_json_schema(),
            name=rule_name,
            description=step.display_name or rule_name,
            configs=configs,
        )

        def _is_expected_shape(x: Any | None) -> bool:
            return isinstance(x, dict) or (
                isinstance(x, list) and all(isinstance(i, dict) for i in x)
            )

        raw_input = step.args[0] if step.args and len(step.args) > 0 else None
        inputs = raw_input if _is_expected_shape(raw_input) else None

        outputs = step.result if _is_expected_shape(step.result) else None

        return cls(rule=rule_serializable, inputs=inputs, outputs=outputs)


class ToolCallMetadata(BaseModel):
    """Metadata wrapper for tool call steps."""

    step_type: Literal[StepType.TOOL_CALL] = StepType.TOOL_CALL
    tool_call: ToolCall
    inputs: None = None
    outputs: JsonValue | None

    @classmethod
    def from_step(cls, step: WorkflowStep, parent_step: WorkflowStep | None) -> Self:
        tool_name = extract_simple_name(step.function_name)
        logger.debug("tool name extracted", tool_name=tool_name)

        tool_call_id = None
        if parent_step and parent_step.result and isinstance(parent_step.result, dict):
            if "tool_calls" in parent_step.result:
                for tc in parent_step.result["tool_calls"]:
                    if tc.get("name") == tool_name:
                        tool_call_id = tc.get("id")
                        logger.debug(
                            "found tool_call_id for tool in parent step result",
                            tool_call_id=tool_call_id,
                            tool_name=tool_name,
                        )
                        break

        if not tool_call_id:
            logger.debug(
                "could not determine tool_call_id for tool", tool_name=tool_name
            )

        tool_call_obj = ToolCall(
            id=tool_call_id or "unknown_tool_call_id",
            name=tool_name,
            arguments=step.kwargs or {},
        )
        return cls(
            tool_call=tool_call_obj,
            inputs=None,
            outputs=step.result,
        )


class MessageMetadata(BaseModel):
    """Metadata wrapper for message steps."""

    step_type: Literal[StepType.MESSAGE] = StepType.MESSAGE
    inputs: JsonObject | str | None
    outputs: None = None

    @classmethod
    def from_step(cls, step: WorkflowStep) -> Self:
        raw_input = step.args[0] if step.args and len(step.args) > 0 else None
        inputs = raw_input if isinstance(raw_input, (dict, str)) else None
        return cls(inputs=inputs, outputs=None)


class ComputeMetadata(BaseModel):
    """Metadata wrapper for compute steps."""

    step_type: Literal[StepType.COMPUTE] = StepType.COMPUTE
    inputs: None = None
    outputs: JsonValue | None

    @classmethod
    def from_step(cls, step: WorkflowStep) -> Self:
        return cls(inputs=None, outputs=step.result)


StepMetadata = Annotated[
    HumanTaskMetadata
    | AgentMetadata
    | RuleMetadata
    | ToolCallMetadata
    | MessageMetadata
    | ComputeMetadata,
    Field(discriminator="step_type"),
]


def extract_simple_name(fully_qualified_name: str) -> str:
    """
    Extract the last part of a fully qualified name.

    For example: 'module.directory.fn_name' becomes 'fn_name'.
    If there are no periods in the string, returns the original string.

    Args:
        fully_qualified_name: A possibly fully qualified name with dot separators

    Returns:
        The last part of the name
    """
    return (
        fully_qualified_name.rsplit(".", maxsplit=1)[-1]
        if "." in fully_qualified_name
        else fully_qualified_name
    )


async def _get_parent_steps(
    tool_call_steps: list[WorkflowStep],
    all_steps: list[WorkflowStep],
) -> dict[int, WorkflowStep]:
    """Build a mapping from step_id -> parent WorkflowStep for tool call steps.

    Looks in the already-loaded `all_steps` first, then falls back to a DB
    query for any parent steps not present in the batch.
    """
    steps_by_id: dict[tuple[UUID, int], WorkflowStep] = {
        (s.workflow_id, s.step_id): s for s in all_steps
    }

    parent_map: dict[int, WorkflowStep] = {}
    missing: list[tuple[UUID, int, int]] = []  # (workflow_id, parent_step_id, step_id)

    for step in tool_call_steps:
        if step.parent_step_id is None:
            continue
        key = (step.workflow_id, step.parent_step_id)
        if key in steps_by_id:
            parent_map[step.step_id] = steps_by_id[key]
        else:
            missing.append((step.workflow_id, step.parent_step_id, step.step_id))

    if missing:
        session = get_session()
        async with session.begin_read():
            for workflow_id, parent_step_id, step_id in missing:
                parent = (
                    await session.exec(
                        select(WorkflowStep).where(
                            (WorkflowStep.workflow_id == workflow_id)
                            & (WorkflowStep.step_id == parent_step_id)
                        )
                    )
                ).first()
                if parent:
                    parent_map[step_id] = parent

    return parent_map


async def get_steps_metadata(
    steps: list[WorkflowStep], registry: ObjectRegistry
) -> dict[int, StepMetadata]:
    """
    Get metadata for multiple steps efficiently.

    Args:
        steps: A list of workflow steps
        registry: Optional ObjectRegistry instance for looking up agents

    Returns:
        A dictionary mapping step_id to strongly-typed StepMetadata objects
    """
    result: dict[int, StepMetadata] = {}

    human_steps = [s for s in steps if s.step_type == StepType.HUMAN_IN_THE_LOOP]
    agent_steps = [s for s in steps if s.step_type == StepType.AGENT]
    rule_steps = [s for s in steps if s.step_type == StepType.RULE]
    tool_call_steps = [s for s in steps if s.step_type == StepType.TOOL_CALL]
    message_steps = [s for s in steps if s.step_type == StepType.MESSAGE]
    compute_steps = [s for s in steps if s.step_type == StepType.COMPUTE]

    if human_steps:
        for step in human_steps:
            metadata = await HumanTaskMetadata.from_step(step)
            if metadata:
                result[step.step_id] = metadata

    if agent_steps:
        for step in agent_steps:
            metadata = await AgentMetadata.from_step(step, registry)
            if metadata:
                result[step.step_id] = metadata

    if rule_steps:
        for step in rule_steps:
            metadata = await RuleMetadata.from_step(step, registry)
            if metadata:
                result[step.step_id] = metadata

    if tool_call_steps:
        parent_map = await _get_parent_steps(tool_call_steps, steps)
        for step in tool_call_steps:
            result[step.step_id] = ToolCallMetadata.from_step(
                step, parent_map.get(step.step_id)
            )

    if message_steps:
        for step in message_steps:
            result[step.step_id] = MessageMetadata.from_step(step)

    if compute_steps:
        for step in compute_steps:
            result[step.step_id] = ComputeMetadata.from_step(step)

    return result
