"""
Pytest fixtures for the Planar library.

This module provides pytest fixtures that can be used both internally by the planar library
and by external users who want to test their code that uses planar.

Usage in external projects:
- By default, these fixtures are auto-loaded when planar is installed
- To disable auto-loading: set PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
- To manually enable: use `uv run pytest -p planar` or add to conftest.py:
  `pytest_plugins = ["planar.testing.fixtures"]`
  or add to pyproject.toml:
  `[project.entry-points.pytest11]
  planar = "planar.testing.fixtures"
  `

Available fixtures:
- storage: In-memory file storage for tests
- data_config: Test data configuration with SQLite catalog and local storage
- app_with_data: PlanarApp instance with data configuration
- tmp_db_url: Parametrized database URL (SQLite/PostgreSQL)
- session: Database session
- client: Planar test client
- observer: Workflow observer for testing
- tracer: Tracer for workflow testing
"""

import asyncio
import os
import subprocess
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path

import asyncpg
import pytest
from pydantic import SecretStr
from sqlalchemy import make_url

from planar.app import PlanarApp
from planar.config import load_config, load_environment_aware_config
from planar.data.config import DataConfig, PostgresCatalogConfig, SQLiteCatalogConfig
from planar.db import DatabaseManager, new_session
from planar.files.storage.config import LocalDirectoryConfig
from planar.files.storage.context import set_storage
from planar.logging import set_context_metadata
from planar.object_registry import ObjectRegistry
from planar.session import config_var, engine_var, session_var
from planar.testing.memory_storage import MemoryStorage
from planar.testing.planar_test_client import (
    planar_test_client,
)
from planar.testing.workflow_observer import WorkflowObserver
from planar.workflows.tracing import Tracer

_TEST_DATABASES = []
if os.getenv("PLANAR_TEST_SQLITE", "1") == "1":
    _TEST_DATABASES.append("sqlite")
if os.getenv("PLANAR_TEST_POSTGRESQL", "0") == "1":
    _TEST_DATABASES.append("postgresql")

_POSTGRESQL_SERVER_URL_ENV = "PLANAR_TEST_POSTGRESQL_SERVER_URL"
_POSTGRESQL_DEFAULT_SERVER_URL = "postgresql://postgres:postgres@127.0.0.1:5432"


def load_logging_config():
    logging_config = os.getenv("PLANAR_TEST_LOGGING_CONFIG", None)
    if logging_config is None:
        return None
    f = Path(logging_config)
    if not f.exists():
        print("Logging configuration file does not exist:", f)
        return None
    try:
        text = f.read_text()
        return load_config(text)
    except Exception as e:
        print("Failed to load logging configuration:", e)
        return None


@pytest.fixture(autouse=True, scope="session")
def configure_session_logging():
    test_config = load_logging_config()
    if test_config:
        if test_config.otel:
            test_config.otel.resource_attributes = {
                **(test_config.otel.resource_attributes or {}),
                "service.name": f"{time.strftime('%Y-%m-%d %H:%M:%S')}-planar-test-run",
            }
        test_config.configure_logging()


@pytest.fixture(autouse=True)
async def configure_test_logging(request):
    # get the current test name
    set_context_metadata("test.id", request.node.name)


@pytest.fixture(autouse=True)
def reset_object_registry():
    """
    Reset the ObjectRegistry singleton before each test to ensure clean state.
    """
    ObjectRegistry.get_instance().reset()
    yield  # Run the test


@pytest.fixture()
def tmp_db_path(tmp_path_factory):
    """
    Create a temporary SQLite database file and return its URL. The database
    file is created in a temporary directory managed by pytest.
    """
    tmp_dir = tmp_path_factory.mktemp("sqlite_db")
    db_file = tmp_dir / "test.db"
    return str(db_file)


@pytest.fixture()
async def storage():
    storage = MemoryStorage()
    set_storage(storage)
    yield storage


@pytest.fixture()
def data_config(tmp_path, request):
    """Create a test data configuration."""
    data_dir = tmp_path / "data"
    data_dir.mkdir(exist_ok=True)

    storage_path = data_dir / "ducklake_files"
    storage_path.mkdir(exist_ok=True)

    catalog_type = getattr(request, "param", "sqlite")

    if catalog_type == "postgres":
        postgres_url = make_url(request.getfixturevalue("tmp_postgresql_url"))
        assert postgres_url.host is not None, "PostgreSQL host must be configured"
        assert postgres_url.database is not None, (
            "PostgreSQL database must be configured"
        )

        password = (
            SecretStr(postgres_url.password)
            if postgres_url.password is not None
            else None
        )
        catalog = PostgresCatalogConfig(
            type="postgres",
            host=postgres_url.host,
            port=postgres_url.port,
            user=postgres_url.username,
            password=password,
            db=postgres_url.database,
        )
    elif catalog_type == "sqlite":
        catalog_path = data_dir / "test.sqlite"
        catalog = SQLiteCatalogConfig(type="sqlite", path=str(catalog_path))
    else:
        raise ValueError(f"Unsupported test data catalog type: {catalog_type}")

    return DataConfig(
        catalog=catalog,
        storage=LocalDirectoryConfig(backend="localdir", directory=str(storage_path)),
    )


@pytest.fixture(name="app_with_data")
def app_with_data_fixture(data_config):
    """Create a PlanarApp with data configuration."""
    config = load_environment_aware_config()

    config.data = data_config

    app = PlanarApp(config=config)

    return app


@pytest.fixture()
def tmp_sqlite_url(tmp_db_path: str):
    return f"sqlite+aiosqlite:///{tmp_db_path}"


def _resolve_postgresql_server_url(request) -> str:
    server_url = os.getenv(_POSTGRESQL_SERVER_URL_ENV)
    if server_url:
        # Prefer an explicitly configured local/external Postgres server when present.
        return server_url

    if not os.getenv("PLANAR_TEST_POSTGRESQL_CONTAINER"):
        # Lazy load the session-scoped container fixture, which will
        # create a temporary docker container for the duration of the session.
        request.getfixturevalue("tmp_postgresql_container")

    # Docker mode always resolves to the localhost server exposed by the fixture
    # (or by a user-managed container using the same port mapping).
    return _POSTGRESQL_DEFAULT_SERVER_URL


def _build_postgresql_urls(server_url: str, db_name: str) -> tuple[str, str]:
    url = make_url(server_url)
    sqlalchemy_drivername = (
        "postgresql+asyncpg"
        if url.drivername == "postgresql"
        else url.drivername or "postgresql+asyncpg"
    )
    # asyncpg.connect() accepts a plain PostgreSQL DSN, while SQLAlchemy's async
    # engine needs the +asyncpg dialect for the per-test database URL.
    admin_url = url.set(drivername="postgresql", database="postgres")
    db_url = url.set(drivername=sqlalchemy_drivername, database=db_name)
    return (
        admin_url.render_as_string(hide_password=False),
        db_url.render_as_string(hide_password=False),
    )


async def _create_postgresql_database(admin_url: str, db_name: str) -> None:
    connection = await asyncpg.connect(admin_url)
    try:
        await connection.execute(f'CREATE DATABASE "{db_name}"')
    finally:
        await connection.close()


async def _drop_postgresql_database(admin_url: str, db_name: str) -> None:
    connection = await asyncpg.connect(admin_url)
    try:
        await connection.execute(
            """
            SELECT pg_terminate_backend(pid)
            FROM pg_stat_activity
            WHERE
              -- don't kill my own connection!
              pid <> pg_backend_pid()
              -- don't kill the connections to other databases
              AND datname = $1
            """,
            db_name,
        )
        await connection.execute(f'DROP DATABASE "{db_name}"')
    finally:
        await connection.close()


@pytest.fixture(scope="session")
def tmp_postgresql_container():
    container_name = "planar-postgres-" + uuid.uuid4().hex

    # Start the postgres container.
    container_process = subprocess.Popen(
        [
            "docker",
            "run",
            "--rm",
            "--name",
            container_name,
            "-e",
            "POSTGRES_PASSWORD=postgres",
            "-p",
            "127.0.0.1:5432:5432",
            "docker.io/library/postgres",
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    # Wait until Postgres is ready to accept connections.
    remaining_tries = 10
    while remaining_tries > 0:
        process = subprocess.run(
            [
                "docker",
                "exec",
                container_name,
                "psql",
                "-U",
                "postgres",
                "-c",
                "CREATE DATABASE dummy;",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        if process.returncode != 0:
            remaining_tries -= 1
            if remaining_tries == 0:
                # Terminate container if it fails to start.
                container_process.terminate()
                container_process.wait()
                raise Exception("Failed to create database")
            time.sleep(10)
        else:
            break

    try:
        yield container_name
    finally:
        container_process.terminate()
        container_process.wait()


@pytest.fixture()
def tmp_postgresql_url(request):
    db_name = "test_" + uuid.uuid4().hex
    server_url = _resolve_postgresql_server_url(request)
    admin_url, url = _build_postgresql_urls(server_url, db_name)

    # Create an isolated database for each test invocation, regardless of
    # whether the backing server comes from Docker or a local Postgres instance.
    asyncio.run(_create_postgresql_database(admin_url, db_name))

    try:
        yield url
    finally:
        # Drop only the per-test database and leave the backing server intact.
        asyncio.run(_drop_postgresql_database(admin_url, db_name))


@pytest.fixture(params=_TEST_DATABASES)
def tmp_db_url(request):
    fixture_name = f"tmp_{request.param}_url"
    return request.getfixturevalue(fixture_name)


@pytest.fixture()
async def tmp_db_engine(tmp_db_url: str):
    async with engine_context(tmp_db_url) as engine:
        yield engine


@pytest.fixture(name="session")
async def session_fixture(tmp_db_engine):
    async with new_session(tmp_db_engine) as session:
        tok = session_var.set(session)
        yield session
        session_var.reset(tok)


@pytest.fixture(name="config")
def config_fixture(tmp_db_path: str):
    """Provide a PlanarConfig context for tests."""
    from planar.config import sqlite_config

    config = sqlite_config(tmp_db_path)
    token = config_var.set(config)
    try:
        yield config
    finally:
        config_var.reset(token)


@pytest.fixture(name="observer")
def workflow_observer_fixture():
    yield WorkflowObserver()


@pytest.fixture(name="client")
async def planar_test_client_fixture(
    app: PlanarApp,
    tmp_db_url: str,
    tracer: Tracer,
    observer: WorkflowObserver,
    storage: MemoryStorage,
):
    """
    Create a PlanarTestClient for testing.

    This fixture requires an 'app' fixture to be defined in your test file
    or conftest.py that returns a PlanarApp instance.

    Example:
        @pytest.fixture(name="app")
        def app_fixture():
            app = PlanarApp()
            app.register_workflow(my_workflow)
            return app
    """
    app.tracer = tracer
    app.storage = storage
    async with planar_test_client(app, tmp_db_url, observer) as client:
        yield client


@pytest.fixture(name="tracer")
async def tracer_fixture():
    yield None


@asynccontextmanager
async def engine_context(url: str):
    db_manager = DatabaseManager(lambda: make_url(url))
    db_manager.connect()
    await db_manager.migrate()
    engine = db_manager.get_engine()
    tok = engine_var.set(engine)
    try:
        yield engine
    finally:
        engine_var.reset(tok)
        await db_manager.disconnect()


@pytest.fixture(autouse=True, scope="session")
def set_dummy_api_keys():
    for key in [
        "OPENAI_API_KEY",
        "ANTHROPIC_API_KEY",
        "DEEPSEEK_API_KEY",
        "GROQ_API_KEY",
        "GEMINI_API_KEY",
        "CO_API_KEY",
        "MISTRAL_API_KEY",
        "OPENROUTER_API_KEY",
    ]:
        current = os.getenv(key)
        if not current:
            current = "mock-api-key"
        os.environ[key] = current
