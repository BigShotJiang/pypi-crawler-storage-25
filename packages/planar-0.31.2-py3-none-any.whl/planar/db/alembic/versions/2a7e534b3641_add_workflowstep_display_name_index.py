"""add WorkflowStep.display_name index

Revision ID: 2a7e534b3641
Revises: 4ca7ba90cdbc
Create Date: 2026-02-04 16:53:16.346574

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "2a7e534b3641"
down_revision: str | None = "4ca7ba90cdbc"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    bind = op.get_bind()
    is_sqlite = bind.dialect.name == "sqlite"

    if is_sqlite:
        with op.batch_alter_table("workflow_step") as batch_op:
            batch_op.create_index(
                batch_op.f("ix_planar_workflow_step_display_name"),
                ["display_name"],
                unique=False,
            )
    else:
        # For PostgreSQL, use CONCURRENTLY outside transaction
        op.execute(sa.text("COMMIT"))
        op.execute(
            sa.text(
                "CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_planar_workflow_step_display_name ON planar.workflow_step (display_name)"
            )
        )


def downgrade() -> None:
    bind = op.get_bind()
    is_sqlite = bind.dialect.name == "sqlite"

    if is_sqlite:
        with op.batch_alter_table("workflow_step") as batch_op:
            batch_op.drop_index(batch_op.f("ix_planar_workflow_step_display_name"))
    else:
        # For PostgreSQL, use CONCURRENTLY outside transaction
        op.execute(sa.text("COMMIT"))
        op.execute(
            sa.text(
                "DROP INDEX CONCURRENTLY planar.ix_planar_workflow_step_display_name"
            )
        )
