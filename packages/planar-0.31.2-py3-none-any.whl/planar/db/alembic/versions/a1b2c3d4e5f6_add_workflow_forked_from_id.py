"""Add Workflow fork fields (forked_from_id, forked_step_id)

Revision ID: a1b2c3d4e5f6
Revises: 4ca7ba90cdbc
Create Date: 2026-01-13 12:00:00.000000

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "a1b2c3d4e5f6"
down_revision: str | None = "2a7e534b3641"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    with op.batch_alter_table("workflow", schema="planar") as batch_op:
        batch_op.add_column(
            sa.Column("forked_from_id", sa.Uuid(), nullable=True, index=True)
        )
        batch_op.add_column(sa.Column("forked_step_id", sa.Integer(), nullable=True))
        batch_op.create_foreign_key(
            "fk_workflow_forked_from_id",
            "workflow",
            ["forked_from_id"],
            ["id"],
            referent_schema="planar",
        )


def downgrade() -> None:
    with op.batch_alter_table("workflow", schema="planar") as batch_op:
        batch_op.drop_constraint("fk_workflow_forked_from_id", type_="foreignkey")
        batch_op.drop_column("forked_step_id")
        batch_op.drop_column("forked_from_id")
