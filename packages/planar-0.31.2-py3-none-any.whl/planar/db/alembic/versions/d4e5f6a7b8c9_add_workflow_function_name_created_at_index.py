"""add index on workflow (function_name, created_at)

Revision ID: d4e5f6a7b8c9
Revises: 7ea143da60e4
Create Date: 2026-04-14 00:00:00.000000

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "d4e5f6a7b8c9"
down_revision: str | None = "7ea143da60e4"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    bind = op.get_bind()
    is_sqlite = bind.dialect.name == "sqlite"

    if is_sqlite:
        with op.batch_alter_table("workflow", schema="planar") as batch_op:
            batch_op.create_index(
                "ix_workflow_function_name_created_at",
                ["function_name", "created_at"],
                unique=False,
            )
    else:
        # Use CONCURRENTLY to avoid locking the table in production
        op.execute(sa.text("COMMIT"))
        op.execute(
            sa.text(
                "CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_workflow_function_name_created_at"
                " ON planar.workflow (function_name, created_at)"
            )
        )


def downgrade() -> None:
    bind = op.get_bind()
    is_sqlite = bind.dialect.name == "sqlite"

    if is_sqlite:
        with op.batch_alter_table("workflow", schema="planar") as batch_op:
            batch_op.drop_index("ix_workflow_function_name_created_at")
    else:
        op.execute(sa.text("COMMIT"))
        op.execute(
            sa.text(
                "DROP INDEX CONCURRENTLY IF EXISTS planar.ix_workflow_function_name_created_at"
            )
        )
