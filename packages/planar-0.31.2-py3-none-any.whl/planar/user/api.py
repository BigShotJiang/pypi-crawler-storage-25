from uuid import UUID

from sqlalchemy.orm.strategy_options import selectinload
from sqlmodel import col, select

from planar.session import get_session
from planar.user.models import IDPUser


async def get_user_with_groups(id: UUID) -> IDPUser | None:
    session = get_session()

    result = await session.exec(
        select(IDPUser)
        .where(col(IDPUser.id) == id, col(IDPUser.disabled_at).is_(None))
        .options(selectinload(IDPUser.groups))  # pyright: ignore[reportArgumentType]
    )
    return result.one_or_none()
