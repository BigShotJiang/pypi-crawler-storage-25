from collections.abc import Callable

from pydantic import SecretStr


class RefreshableSecret(SecretStr):
    """A SecretStr whose value is re-resolved from a provider on each access."""

    resolver: Callable[[], str]

    def __init__(self, *, resolver: Callable[[], str]) -> None:
        super().__init__(resolver())
        self.resolver = resolver

    def get_secret_value(self) -> str:
        return self.resolver()
