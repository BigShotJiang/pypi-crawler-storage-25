import os
from typing import Any

from planar.secrets.protocol import (
    SecretAccessError,
    SecretNotFoundError,
    SecretProvider,
)


class EnvVarSecretProvider(SecretProvider):
    """
    Wraps os.environ. Serves as the default fallback.
    Resolution: get_secret("MY_VAR") -> os.environ.get("MY_VAR").
    """

    def __init__(self, config: dict[str, Any]):
        self.config = config

    def get_secret(self, secret_id: str) -> str:
        value = os.environ.get(secret_id)
        if value is None:
            raise SecretNotFoundError(f"Environment variable '{secret_id}' not found")
        return value


class AwsSecretsManagerProvider(SecretProvider):
    """
    Fetches secrets from AWS Secrets Manager using boto3.
    Resolution: get_secret("prod/db/password") calls get_secret_value.
    """

    def __init__(self, config: dict[str, Any]):
        try:
            import boto3
        except ImportError as e:
            raise ImportError(
                "boto3 is required for AwsSecretsManagerProvider. Please install it."
            ) from e

        self.client = boto3.client("secretsmanager", **config)

    def get_secret(self, secret_id: str) -> str:
        try:
            response = self.client.get_secret_value(SecretId=secret_id)
            secret_string = response.get("SecretString")
            if secret_string is None:
                raise SecretNotFoundError(
                    f"Secret '{secret_id}' found but has no SecretString"
                )
            return secret_string
        except self.client.exceptions.ResourceNotFoundException as e:
            raise SecretNotFoundError(
                f"Secret '{secret_id}' not found in AWS Secrets Manager"
            ) from e
        except Exception as e:
            raise SecretAccessError(
                f"Error accessing secret '{secret_id}' in AWS Secrets Manager: {e}"
            ) from e


class AzureKeyVaultProvider(SecretProvider):
    """
    Fetches secrets from Azure Key Vault using azure-keyvault-secrets.
    Resolution: get_secret("db-password") calls get_secret.
    """

    def __init__(self, config: dict[str, Any]):
        try:
            from azure.identity import DefaultAzureCredential
            from azure.keyvault.secrets import SecretClient
        except ImportError as e:
            raise ImportError(
                "azure-keyvault-secrets and azure-identity are required for AzureKeyVaultProvider. Please install them."
            ) from e

        vault_url = config.get("vault_url")
        if not vault_url:
            raise ValueError("vault_url is required for AzureKeyVaultProvider config")

        # Filter config for DefaultAzureCredential arguments (e.g. managed_identity_client_id)
        credential_kwargs = {k: v for k, v in config.items() if k != "vault_url"}

        credential = DefaultAzureCredential(**credential_kwargs)
        self.client = SecretClient(vault_url=vault_url, credential=credential)

    def get_secret(self, secret_id: str) -> str:
        try:
            secret = self.client.get_secret(secret_id)
            if secret.value is None:
                raise SecretNotFoundError(
                    f"Secret '{secret_id}' found but has no value"
                )
            return secret.value
        except Exception as e:
            from azure.core.exceptions import ResourceNotFoundError

            if isinstance(e, ResourceNotFoundError):
                raise SecretNotFoundError(
                    f"Secret '{secret_id}' not found in Azure Key Vault"
                ) from e
            raise SecretAccessError(
                f"Error accessing secret '{secret_id}' in Azure Key Vault: {e}"
            ) from e
