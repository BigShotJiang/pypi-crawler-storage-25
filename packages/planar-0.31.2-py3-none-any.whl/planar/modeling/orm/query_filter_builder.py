from collections.abc import Sequence
from typing import Any, overload

from sqlalchemy import ColumnElement
from sqlalchemy.sql import func as sql_func
from sqlmodel import desc, select
from sqlmodel.sql.expression import Select, SelectOfScalar

from planar.routers.models import SortDirection


# select(Model) returns SelectOfScalar, select(Model.a, Model.b) returns Select.
# These are sibling classes in sqlmodel (not parent-child), and session.exec()
# has distinct overloads for each, so we need overloads here to preserve the type.
@overload
def build_paginated_query[T: Any](
    query: SelectOfScalar[T],
    filters: Sequence[ColumnElement[bool]] | None = None,
    offset: int | None = None,
    limit: int | None = None,
    order_by: Any = None,
    order_direction: SortDirection | None = None,
) -> tuple[SelectOfScalar[T], SelectOfScalar[int]]: ...


@overload
def build_paginated_query[T: Any](
    query: Select[T],
    filters: Sequence[ColumnElement[bool]] | None = None,
    offset: int | None = None,
    limit: int | None = None,
    order_by: Any = None,
    order_direction: SortDirection | None = None,
) -> tuple[Select[T], SelectOfScalar[int]]: ...


def build_paginated_query[T: Any](
    query: Select[T] | SelectOfScalar[T],
    filters: Sequence[ColumnElement[bool]] | None = None,
    offset: int | None = None,
    limit: int | None = None,
    order_by: Any = None,
    order_direction: SortDirection | None = None,
) -> tuple[Select[T] | SelectOfScalar[T], SelectOfScalar[int]]:
    """Build a paginated, filtered, and ordered query.

    Args:
        query: The base SQL query to build upon.
        filters: Optional SQLAlchemy column expressions to apply as WHERE clauses.
        offset: Optional offset for pagination.
        limit: Optional limit for pagination.
        order_by: Optional field or list of fields to order by.
        order_direction: Optional direction to order by.

    Returns:
        Tuple of (paginated query, total count query).
        The count query is guaranteed to work with the session.exec().one() pattern.
    """
    result_query = query

    if filters:
        for filter in filters:
            result_query = result_query.where(filter)

    count_query = select(sql_func.count()).select_from(result_query.subquery())

    if offset is not None:
        result_query = result_query.offset(offset)

    if limit is not None:
        result_query = result_query.limit(limit)

    if order_by:
        if order_direction == SortDirection.ASC:
            result_query = result_query.order_by(order_by)
        else:
            result_query = result_query.order_by(desc(order_by))

    return result_query, count_query
