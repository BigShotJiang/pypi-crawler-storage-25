"""Column descriptor for IO.input.table with JSON Schema metadata."""

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class Column:
    """Describes a table column with optional JSON Schema validation metadata.

    Use ``Column`` in the ``columns`` parameter of ``IO.input.table`` to attach
    type constraints, enum values, format hints, and other JSON Schema-compatible
    metadata to individual columns. Plain strings remain supported for columns
    that don't need extra metadata.

    Example::

        await IO.input.table(
            "Edit employees",
            data=employees,
            columns=[
                Column("name", type="string", min_length=1, max_length=100),
                Column(
                    "salary",
                    type="number",
                    format="currency",
                    currency="USD",
                    minimum=30000,
                    maximum=500000,
                ),
                Column(
                    "department",
                    type="string",
                    enum=["Engineering", "Sales", "Marketing"],
                ),
                Column("rating", type="number", minimum=0.0, maximum=5.0),
                "is_active",  # plain string — no extra metadata
            ],
        )

    Args:
        name: Column key matching a key in the data dicts.
        type: JSON Schema type (``"string"``, ``"number"``, ``"integer"``,
            ``"boolean"``).
        description: Human-readable description of the column.
        enum: Allowed values for the column (renders as a dropdown/select).
        format: JSON Schema ``format`` keyword (e.g. ``"currency"``,
            ``"email"``, ``"date"``).
        currency: ISO 4217 currency code (e.g. ``"USD"``). Implies
            ``format="currency"`` when set.
        minimum: Minimum numeric value (inclusive).
        maximum: Maximum numeric value (inclusive).
        min_length: Minimum string length.
        max_length: Maximum string length.
        pattern: Regex pattern the value must match.
    """

    name: str
    type: str | None = None
    description: str | None = None
    enum: list[str] | None = None
    format: str | None = None
    currency: str | None = None
    minimum: float | int | None = None
    maximum: float | int | None = None
    min_length: int | None = None
    max_length: int | None = None
    pattern: str | None = None

    def to_json_schema(self) -> dict[str, Any]:
        """Build a JSON Schema fragment for this column.

        Returns:
            A dict suitable for use as a property schema inside a JSON Schema
            ``"properties"`` block.
        """
        schema: dict[str, Any] = {}

        if self.type is not None:
            schema["type"] = self.type

        if self.description is not None:
            schema["description"] = self.description

        if self.enum is not None:
            schema["enum"] = list(self.enum)

        # Resolve format: explicit format wins, otherwise infer from currency
        effective_format = self.format
        if effective_format is None and self.currency is not None:
            effective_format = "currency"
        if effective_format is not None:
            schema["format"] = effective_format

        if self.currency is not None:
            schema["currency"] = self.currency

        if self.minimum is not None:
            schema["minimum"] = self.minimum
        if self.maximum is not None:
            schema["maximum"] = self.maximum
        if self.min_length is not None:
            schema["minLength"] = self.min_length
        if self.max_length is not None:
            schema["maxLength"] = self.max_length

        if self.pattern is not None:
            schema["pattern"] = self.pattern

        return schema


__all__ = ["Column"]
