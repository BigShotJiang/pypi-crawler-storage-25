import mimetypes
import os
import uuid
from collections.abc import Callable, Coroutine
from functools import wraps
from typing import Any, cast, get_type_hints

from planar.ai.sandbox.context import SandboxToolContext
from planar.ai.sandbox.models import BashResult, PythonResult, SandboxToolResult
from planar.ai.tool_context import get_tool_context
from planar.files.models import PlanarFile


def sandbox_tool[T](
    *,
    mutates_state: bool = True,
) -> Callable[
    [Callable[..., Coroutine[Any, Any, T]]],
    Callable[..., Coroutine[Any, Any, SandboxToolResult[T]]],
]:
    """Decorator to mark a function as a sandbox tool."""

    def decorator(
        func: Callable[..., Coroutine[Any, Any, T]],
    ) -> Callable[..., Coroutine[Any, Any, SandboxToolResult[T]]]:
        try:
            return_type = get_type_hints(func).get("return", Any)
        except Exception:
            return_type = Any

        @wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> SandboxToolResult[T]:
            sandbox_context = get_tool_context(SandboxToolContext)
            await sandbox_context.restore_current_snapshot()
            result = await func(*args, **kwargs)

            if mutates_state:
                snapshot_ref = await sandbox_context.snapshot_current_state()
            else:
                snapshot_ref = sandbox_context.current_snapshot_ref

            return SandboxToolResult(result=result, snapshot_ref=snapshot_ref)

        annotations = dict(getattr(wrapper, "__annotations__", {}))
        annotations["return"] = SandboxToolResult[return_type]
        wrapper.__annotations__ = annotations
        wrapped = cast(Any, wrapper)
        wrapped._is_sandbox_tool = True
        wrapped._sandbox_tool_mutates_state = mutates_state
        return cast(Callable[..., Coroutine[Any, Any, SandboxToolResult[T]]], wrapper)

    return decorator


def is_sandbox_tool(fn) -> bool:
    """Check if a function is a sandbox tool."""
    return getattr(fn, "_is_sandbox_tool", False)


def tool_mutates_state(fn) -> bool:
    """Check whether a sandbox tool mutates provider state."""
    return getattr(fn, "_sandbox_tool_mutates_state", True)


@sandbox_tool(mutates_state=True)
async def execute_python(code: str) -> PythonResult:
    """
    Execute Python code in an isolated sandbox.

    Each execution is ephemeral - variables and imports do not persist between calls.
    The sandbox filesystem is mounted at /data within Python.

    Args:
        code: Python code to execute

    Returns:
        PythonResult with stdout, stderr, exit_code, and optional error info
    """
    ctx = get_tool_context(SandboxToolContext)
    return await ctx.provider.execute_python(
        code, preload_packages=["pillow", "pymupdf"]
    )


@sandbox_tool(mutates_state=True)
async def bash(command: str) -> BashResult:
    """Execute a bash command in the sandbox."""
    ctx = get_tool_context(SandboxToolContext)
    return await ctx.provider.bash(command)


@sandbox_tool(mutates_state=False)
async def read_file(path: str) -> str:
    """Read a file from the sandbox filesystem."""
    ctx = get_tool_context(SandboxToolContext)
    try:
        return await ctx.provider.read_file(path)
    except FileNotFoundError:
        return f"File {path} not found"


@sandbox_tool(mutates_state=True)
async def write_file(path: str, content: str) -> str:
    """Write content to a file in the sandbox filesystem."""
    ctx = get_tool_context(SandboxToolContext)
    await ctx.provider.write_file(path, content)
    return f"Wrote {len(content)} characters to {path}"


@sandbox_tool(mutates_state=False)
async def read_file_bytes(path: str) -> PlanarFile:
    """Read a binary file from the sandbox and upload it as a PlanarFile."""
    ctx = get_tool_context(SandboxToolContext)
    file_bytes = await ctx.provider.read_file_bytes(path)
    resolved_filename = os.path.basename(path) or f"sandbox_file_{uuid.uuid4()}"
    resolved_content_type = mimetypes.guess_type(resolved_filename)[0]
    return await PlanarFile.upload(
        content=file_bytes,
        filename=resolved_filename,
        content_type=resolved_content_type,
    )


@sandbox_tool(mutates_state=False)
async def list_files(path: str = "/") -> list[str]:
    """List files in a sandbox directory."""
    ctx = get_tool_context(SandboxToolContext)
    return await ctx.provider.list_files(path)


@sandbox_tool(mutates_state=True)
async def delete_file(path: str) -> str:
    """Delete a file from the sandbox filesystem."""
    ctx = get_tool_context(SandboxToolContext)
    await ctx.provider.delete_file(path)
    return f"Deleted {path}"


SANDBOX_TOOLS = {
    bash,
    delete_file,
    execute_python,
    list_files,
    read_file,
    read_file_bytes,
    write_file,
}
