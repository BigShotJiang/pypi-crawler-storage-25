from pydantic import BaseModel

from planar.ai.sandbox.models import SnapshotRef
from planar.ai.sandbox.provider import SandboxProvider
from planar.logging import get_logger

logger = get_logger(__name__)


class SandboxToolContext(BaseModel):
    """Tool context providing sandbox provider access and snapshot state."""

    model_config = {"arbitrary_types_allowed": True}

    provider: SandboxProvider
    current_snapshot_ref: SnapshotRef | None = None

    def apply_snapshot_ref(self, value: SnapshotRef | None) -> None:
        """Apply snapshot ref from a completed (or replayed) tool step."""
        self.current_snapshot_ref = value

    async def restore_current_snapshot(self) -> None:
        if self.current_snapshot_ref is None:
            return
        await self.provider.restore(self.current_snapshot_ref)
        logger.debug("restored sandbox snapshot for tool call")

    async def snapshot_current_state(self) -> SnapshotRef:
        snapshot_ref = await self.provider.snapshot()
        logger.debug("captured sandbox snapshot after tool call")
        return snapshot_ref

    async def cleanup(self) -> None:
        """Clean up sandbox resources associated with this context."""
        await self.provider.cleanup()

    def cleanup_now(self) -> None:
        """Synchronous best-effort cleanup for coroutine close paths."""
        self.provider.cleanup_now()
