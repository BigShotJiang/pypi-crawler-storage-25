from typing import Annotated, Generic, Literal, TypeVar
from uuid import UUID

from pydantic import BaseModel, Field


class SandboxConfig(BaseModel):
    """Configuration for sandbox execution."""

    provider: Literal["local"] = "local"
    initial_cwd: str = "/data"


class PythonResult(BaseModel):
    """Result of executing Python code in the sandbox."""

    stdout: str
    stderr: str
    exit_code: int
    error: str | None = None


class BashResult(BaseModel):
    """Result of executing a bash command in the sandbox."""

    stdout: str
    stderr: str
    exit_code: int


class LocalSandboxSnapshotRef(BaseModel):
    """Snapshot reference for a LocalSandbox filesystem snapshot."""

    kind: Literal["localsandbox"] = "localsandbox"
    version: Literal[1] = 1
    planar_file_id: UUID


# We can add other per-provider snapshot ref kinds here.
SnapshotRef = Annotated[
    LocalSandboxSnapshotRef,
    Field(discriminator="kind"),
]


TResult = TypeVar("TResult")


class SandboxToolResult(BaseModel, Generic[TResult]):
    """Internal durable wrapper for sandbox tool step results."""

    model_config = {"arbitrary_types_allowed": True}

    result: TResult
    snapshot_ref: SnapshotRef | None = None
