from pathlib import Path

from planar.ai.sandbox.models import SandboxConfig
from planar.ai.sandbox.provider import SandboxProvider


def create_sandbox_provider(
    config: SandboxConfig,
    initial_files: dict[str, str | Path | bytes] | None = None,
) -> SandboxProvider:
    """Create a sandbox provider from configured provider type."""
    if config.provider == "local":
        from planar.ai.sandbox.providers.local import LocalSandboxProvider

        return LocalSandboxProvider(config=config, initial_files=initial_files)

    raise ValueError(f"Unsupported sandbox provider: {config.provider}")
