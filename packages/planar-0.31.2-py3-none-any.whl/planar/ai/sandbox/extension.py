from collections.abc import Callable
from pathlib import Path
from typing import Any, override

from pydantic import BaseModel

from planar.ai.extensions import (
    AgentExtension,
    ExtensionRunContext,
)
from planar.ai.sandbox.context import SandboxToolContext
from planar.ai.sandbox.factory import create_sandbox_provider
from planar.ai.sandbox.models import SandboxToolResult
from planar.ai.sandbox.tools import (
    bash,
    delete_file,
    execute_python,
    list_files,
    read_file,
    read_file_bytes,
    write_file,
)
from planar.ai.tool_context import pop_tool_context, push_tool_context
from planar.files.models import PlanarFile
from planar.logging import get_logger
from planar.session import get_config

logger = get_logger(__name__)

DEFAULT_SANDBOX_AGENT_SYSTEM_PROMPT = """You can use sandbox tools to execute python/bash and read or write files under /data.
Prefer tool calls over guessing when file or code execution is needed.
Use absolute paths (for example, /data/input.txt)."""

_DEFAULT_SANDBOX_TOOLS = (
    execute_python,
    bash,
    read_file,
    write_file,
    read_file_bytes,
    list_files,
    delete_file,
)


class SandboxOptions(BaseModel):
    files: dict[str, PlanarFile] | None = None


class SandboxExtension(AgentExtension):
    """Extension that contributes sandbox tools and manages sandbox lifecycle."""

    extension_key = "sandbox"
    options_type = SandboxOptions

    def __init__(
        self,
        *,
        include_tools: bool = True,
        instructions: str | None = DEFAULT_SANDBOX_AGENT_SYSTEM_PROMPT,
    ) -> None:
        self.include_tools = include_tools
        self.instructions = instructions

    def get_tools(self) -> list[Callable[..., Any]]:
        return list(_DEFAULT_SANDBOX_TOOLS) if self.include_tools else []

    def get_instructions(self) -> str | None:
        return self.instructions

    def serialize_config(self) -> dict[str, Any] | None:
        return {
            "include_tools": self.include_tools,
            "has_instructions": self.instructions is not None,
        }

    def serialize_options(self, options: object | None) -> dict[str, Any] | None:
        if options is not None and not isinstance(options, SandboxOptions):
            raise ValueError(f"expected SandboxOptions, got {type(options)}")
        return {
            "files": {
                path: planar_file.model_dump(mode="json")
                for path, planar_file in ((options and options.files) or {}).items()
            }
        }

    @override
    async def before_run(self, *, ctx: ExtensionRunContext) -> None:
        options = ctx.options_for(self)
        sandbox_files = options.files if isinstance(options, SandboxOptions) else None

        initial_files = await self._prepare_sandbox_files(
            sandbox_files=sandbox_files,
        )
        sandbox_context = self._create_sandbox_context(initial_files=initial_files)
        ctx.state_for(self)["sandbox_context"] = sandbox_context
        push_tool_context(sandbox_context)
        logger.debug("added sandbox context for agent", agent_name=ctx.agent.name)

    @override
    async def teardown_run(
        self,
        *,
        ctx: ExtensionRunContext,
        error: BaseException | None,
    ) -> None:
        sandbox_context = ctx.state_for(self).get("sandbox_context")
        if not isinstance(sandbox_context, SandboxToolContext):
            logger.warning(
                "received unexpected sandbox context for teardown",
                sandbox_context=sandbox_context,
            )
            return

        try:
            if isinstance(error, GeneratorExit):
                sandbox_context.cleanup_now()
            else:
                await sandbox_context.cleanup()
        finally:
            pop_tool_context(SandboxToolContext)
            ctx.state_for(self).pop("sandbox_context", None)

    @override
    async def after_tool_call(
        self,
        *,
        ctx: ExtensionRunContext,
        tool_fn: Callable[..., Any],
        raw_result: Any,
    ) -> Any:
        _ = tool_fn
        if not isinstance(raw_result, SandboxToolResult):
            return raw_result

        sandbox_context = ctx.state_for(self).get("sandbox_context")
        if not isinstance(sandbox_context, SandboxToolContext):
            raise RuntimeError("sandbox context not available for sandbox tool result")

        sandbox_context.apply_snapshot_ref(raw_result.snapshot_ref)
        return raw_result.result

    @staticmethod
    def _create_sandbox_context(
        initial_files: dict[str, str | Path | bytes] | None = None,
    ) -> SandboxToolContext:
        config = get_config()
        sandbox_config = config.sandbox

        if sandbox_config is None:
            raise ValueError(
                "Sandbox config is not set, please set it your planar.yaml file"
            )

        provider = create_sandbox_provider(
            config=sandbox_config,
            initial_files=initial_files,
        )
        return SandboxToolContext(provider=provider)

    @staticmethod
    async def _prepare_sandbox_files(
        *,
        sandbox_files: dict[str, PlanarFile] | None,
    ) -> dict[str, str | Path | bytes] | None:
        if not sandbox_files:
            return None

        initial_files: dict[str, str | Path | bytes] = {}
        for path, planar_file in sandbox_files.items():
            if not path.startswith("/"):
                raise ValueError(f"sandbox file path must be absolute, got: {path}")
            try:
                initial_files[path] = await planar_file.get_content()
            except Exception:
                logger.exception(
                    "failed to load file content for sandbox",
                    file_id=str(planar_file.id),
                    filename=planar_file.filename,
                    sandbox_path=path,
                )
                raise

        logger.debug(
            "prepared sandbox initial files",
            num_files=len(initial_files),
        )
        return initial_files
