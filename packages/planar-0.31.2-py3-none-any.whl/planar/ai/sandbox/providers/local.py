from pathlib import Path

try:
    from localsandbox import CommandError as LocalSandboxCommandError
    from localsandbox import FileNotFoundError as LocalSandboxFileNotFoundError
    from localsandbox import LocalSandbox
except ImportError as import_error:
    raise ImportError(
        "localsandbox is required for sandbox tools. "
        "Install with: uv sync --extra sandbox"
    ) from import_error

from planar.ai.sandbox.models import (
    BashResult,
    LocalSandboxSnapshotRef,
    PythonResult,
    SandboxConfig,
    SnapshotRef,
)
from planar.files.models import PlanarFile
from planar.logging import get_logger

logger = get_logger(__name__)


class LocalSandboxProvider:
    """Sandbox provider backed by the localsandbox SDK."""

    def __init__(
        self,
        config: SandboxConfig,
        initial_files: dict[str, str | Path | bytes] | None = None,
    ) -> None:
        self._config = config
        self._initial_files = initial_files
        self._sandbox: LocalSandbox | None = None

    def get_sandbox(self) -> LocalSandbox:
        if self._sandbox is not None:
            return self._sandbox

        self._sandbox = LocalSandbox(
            cwd=self._config.initial_cwd, files=self._initial_files
        )
        return self._sandbox

    async def bash(self, command: str) -> BashResult:
        try:
            result = await self.get_sandbox().abash(command)
            return BashResult(
                stdout=result.stdout,
                stderr=result.stderr,
                exit_code=result.exit_code,
            )
        except LocalSandboxCommandError as exc:
            return BashResult(
                stdout=exc.stdout,
                stderr=exc.stderr or str(exc),
                exit_code=exc.exit_code,
            )

    async def execute_python(
        self,
        code: str,
        cwd: str | None = None,
        preload_packages: list[str] | None = None,
    ) -> PythonResult:
        sandbox = self.get_sandbox()
        result = await sandbox.aexecute_python(
            code, cwd=cwd, preload_packages=preload_packages
        )
        return PythonResult(
            stdout=result.stdout,
            stderr=result.stderr,
            exit_code=result.exit_code,
            error=result.error,
        )

    async def read_file(self, path: str) -> str:
        sandbox = self.get_sandbox()
        try:
            return await sandbox.aread_file(path)
        except LocalSandboxFileNotFoundError:
            raise FileNotFoundError(path) from None

    async def read_file_bytes(self, path: str) -> bytes:
        sandbox = self.get_sandbox()
        try:
            return await sandbox.aread_file_bytes(path)
        except LocalSandboxFileNotFoundError:
            raise FileNotFoundError(path) from None

    async def write_file(self, path: str, content: str) -> None:
        sandbox = self.get_sandbox()
        await sandbox.awrite_file(path, content)

    async def list_files(self, path: str = "/") -> list[str]:
        sandbox = self.get_sandbox()
        return await sandbox.alist_files(path)

    async def delete_file(self, path: str) -> None:
        sandbox = self.get_sandbox()
        await sandbox.adelete_file(path)

    async def restore(self, snapshot_ref: SnapshotRef) -> None:
        if not isinstance(snapshot_ref, LocalSandboxSnapshotRef):
            raise ValueError(
                f"LocalSandboxProvider expected LocalSandboxSnapshotRef, got {type(snapshot_ref).__name__}"
            )

        snapshot_file = await PlanarFile.get(snapshot_ref.planar_file_id)
        snapshot_bytes = await snapshot_file.get_content()

        await self.cleanup()
        self._sandbox = LocalSandbox(snapshot=snapshot_bytes)
        logger.debug(
            "restored local sandbox from snapshot",
            snapshot_file_id=str(snapshot_ref.planar_file_id),
        )

    async def snapshot(self) -> SnapshotRef:
        sandbox = self.get_sandbox()
        snapshot_bytes = sandbox.export_snapshot()
        snapshot_file = await PlanarFile.upload(
            content=snapshot_bytes,
            filename="sandbox_snapshot.sqlite",
            content_type="application/vnd.sqlite3",
        )
        logger.debug(
            "persisted local sandbox snapshot",
            snapshot_file_id=str(snapshot_file.id),
        )
        return LocalSandboxSnapshotRef(planar_file_id=snapshot_file.id)

    async def cleanup(self) -> None:
        if self._sandbox is None:
            return
        await self._sandbox.adestroy()
        self._sandbox = None

    def cleanup_now(self) -> None:
        if self._sandbox is None:
            return
        self._sandbox.destroy()
        self._sandbox = None
