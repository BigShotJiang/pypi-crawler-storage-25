from collections.abc import Mapping
from typing import TYPE_CHECKING

from planar.dependencies import lazy_exports

_DEFERRED_IMPORTS: Mapping[str, tuple[str, str]] = {
    "SandboxConfig": (".models", "SandboxConfig"),
    "SandboxExtension": (".extension", "SandboxExtension"),
    "SandboxOptions": (".extension", "SandboxOptions"),
    "SandboxToolResult": (".models", "SandboxToolResult"),
    "SandboxToolContext": (".context", "SandboxToolContext"),
    "SnapshotRef": (".models", "SnapshotRef"),
    "SandboxProvider": (".provider", "SandboxProvider"),
    "create_sandbox_provider": (".factory", "create_sandbox_provider"),
    "SANDBOX_TOOLS": (".tools", "SANDBOX_TOOLS"),
    "bash": (".tools", "bash"),
    "delete_file": (".tools", "delete_file"),
    "execute_python": (".tools", "execute_python"),
    "is_sandbox_tool": (".tools", "is_sandbox_tool"),
    "list_files": (".tools", "list_files"),
    "read_file": (".tools", "read_file"),
    "read_file_bytes": (".tools", "read_file_bytes"),
    "sandbox_tool": (".tools", "sandbox_tool"),
    "tool_mutates_state": (".tools", "tool_mutates_state"),
    "write_file": (".tools", "write_file"),
}

if TYPE_CHECKING:
    from .context import SandboxToolContext
    from .extension import SandboxExtension, SandboxOptions
    from .factory import create_sandbox_provider
    from .models import (
        SandboxConfig,
        SandboxToolResult,
        SnapshotRef,
    )
    from .provider import SandboxProvider
    from .tools import (
        SANDBOX_TOOLS,
        bash,
        delete_file,
        execute_python,
        is_sandbox_tool,
        list_files,
        read_file,
        read_file_bytes,
        sandbox_tool,
        tool_mutates_state,
        write_file,
    )

    __all__ = [
        "SandboxConfig",
        "SandboxExtension",
        "SandboxOptions",
        "SandboxToolResult",
        "SandboxToolContext",
        "SnapshotRef",
        "SandboxProvider",
        "create_sandbox_provider",
        "SANDBOX_TOOLS",
        "bash",
        "delete_file",
        "execute_python",
        "is_sandbox_tool",
        "list_files",
        "read_file",
        "read_file_bytes",
        "sandbox_tool",
        "tool_mutates_state",
        "write_file",
    ]

lazy_exports(__name__, _DEFERRED_IMPORTS)
