import abc
from collections.abc import Callable, Coroutine
from dataclasses import dataclass, field
from typing import (
    Any,
    cast,
    overload,
)
from uuid import UUID

from pydantic import BaseModel

from planar.ai.extensions import (
    AgentExtension,
    ExtensionRunContext,
)
from planar.ai.models import (
    AgentConfig,
    AgentEventEmitter,
    AgentInfo,
    AgentRunResult,
    ExtensionDescriptor,
    ModelMessage,
    PlanarModelSettings,
)
from planar.ai.tool_context import pop_tool_context, push_tool_context
from planar.logging import get_logger
from planar.modeling.field_helpers import JsonSchema
from planar.utils import P, R, T, U
from planar.workflows import as_step
from planar.workflows.models import StepType

logger = get_logger(__name__)


@dataclass
class AgentBase[
    # TODO: add `= str` default when we upgrade to 3.13
    TInput: BaseModel | str,
    TOutput: BaseModel | str,
    TToolContext,
](abc.ABC):
    """An LLM-powered agent that can be called directly within workflows."""

    name: str
    system_prompt: str
    output_type: type[TOutput] | None = None
    input_type: type[TInput] | None = None
    user_prompt: str = ""
    tools: list[Callable] = field(default_factory=list)
    max_turns: int = 2
    model_parameters: PlanarModelSettings = field(
        default_factory=lambda: cast(PlanarModelSettings, {})
    )
    event_emitter: AgentEventEmitter | None = None
    durable: bool = True
    tool_context_type: type[TToolContext] | None = None
    extensions: list[AgentExtension] = field(default_factory=list)

    def __post_init__(self):
        if self.input_type:
            if (
                not issubclass(self.input_type, BaseModel)
                and self.input_type is not str
            ):
                raise ValueError(
                    "input_type must be 'str' or a subclass of a Pydantic model"
                )

        self._collect_extension_tools()
        self._compose_extension_instructions()

        if self.max_turns < 1:
            raise ValueError("Max_turns must be greater than or equal to 1.")
        if self.tools and self.max_turns <= 1:
            raise ValueError(
                "For tool calling to work, max_turns must be greater than 1."
            )

    def _collect_extension_tools(self) -> None:
        # Tool precedence is:
        # 1. direct agent tools, in declaration order
        # 2. extension tools from last extension to first extension
        # Dedupe by first occurrence in that priority order.
        priority_tools = list(self.tools) + [
            tool
            for extension in reversed(self.extensions)
            for tool in extension.get_tools()
        ]

        deduped_tools: list[Callable] = []
        seen_tool_names: set[str] = set()
        for tool in priority_tools:
            if tool.__name__ in seen_tool_names:
                continue
            seen_tool_names.add(tool.__name__)
            deduped_tools.append(tool)

        self.tools = deduped_tools

    def _compose_extension_instructions(self) -> None:
        instruction_parts = [
            instructions
            for extension in self.extensions
            if (instructions := extension.get_instructions())
        ]
        if self.system_prompt:
            instruction_parts.append(self.system_prompt)
        self.system_prompt = "\n\n".join(instruction_parts)

    def describe_extensions(
        self,
        ctx: ExtensionRunContext | None = None,
    ) -> list[ExtensionDescriptor]:
        return [
            extension.describe(ctx.options_for(extension) if ctx is not None else None)
            for extension in self.extensions
        ]

    def input_schema(self) -> JsonSchema | None:
        if self.input_type is None:
            return None
        if self.input_type is str:
            return None
        assert issubclass(self.input_type, BaseModel), (
            "input_type must be a subclass of BaseModel or str"
        )
        return self.input_type.model_json_schema()

    def output_schema(self) -> JsonSchema | None:
        if self.output_type is None:
            return None
        if self.output_type is str:
            return None
        assert issubclass(self.output_type, BaseModel), (
            "output_type must be a subclass of BaseModel or str"
        )
        return self.output_type.model_json_schema()

    @overload
    async def __call__(
        self: "AgentBase[TInput, str, TToolContext]",
        input_value: TInput,
        tool_context: TToolContext | None = None,
        extension_options: list[object] | None = None,
        config_id: UUID | None = None,
    ) -> AgentRunResult[str]: ...

    @overload
    async def __call__(
        self: "AgentBase[TInput, TOutput, TToolContext]",
        input_value: TInput,
        tool_context: TToolContext | None = None,
        extension_options: list[object] | None = None,
        config_id: UUID | None = None,
    ) -> AgentRunResult[TOutput]: ...

    def as_step_if_durable(
        self,
        func: Callable[P, Coroutine[T, U, R]],
        step_type: StepType,
        display_name: str | None = None,
        return_type: type[R] | None = None,
    ) -> Callable[P, Coroutine[T, U, R]]:
        if not self.durable:
            return func
        return as_step(
            func,
            step_type=step_type,
            display_name=display_name or self.name,
            return_type=return_type,
        )

    async def _run_extensions_before_run(
        self,
        *,
        ctx: ExtensionRunContext,
    ) -> None:
        for extension in self.extensions:
            await extension.before_run(ctx=ctx)

    async def _run_extensions_after_run(
        self,
        *,
        ctx: ExtensionRunContext,
        result: AgentRunResult[Any],
    ) -> AgentRunResult[Any]:
        current_result = result
        for extension in reversed(self.extensions):
            current_result = await extension.after_run(
                ctx=ctx,
                result=current_result,
            )
        return current_result

    async def _run_extensions_on_run_error(
        self,
        *,
        ctx: ExtensionRunContext,
        error: BaseException,
    ) -> AgentRunResult[Any]:
        current_error: BaseException = error
        for extension in reversed(self.extensions):
            try:
                return await extension.on_run_error(
                    ctx=ctx,
                    error=current_error,
                )
            except BaseException as new_error:
                current_error = new_error
        raise current_error

    async def _run_extensions_teardown_run(
        self,
        *,
        ctx: ExtensionRunContext,
        error: BaseException | None,
    ) -> None:
        for extension in reversed(self.extensions):
            try:
                await extension.teardown_run(ctx=ctx, error=error)
            except Exception:
                logger.exception(
                    "failed to cleanup agent extension",
                    agent_name=self.name,
                    extension_name=type(extension).__name__,
                )

    async def _run_extensions_before_model_run(
        self,
        *,
        ctx: ExtensionRunContext,
        messages: list[ModelMessage],
    ) -> list[ModelMessage]:
        current_messages = messages
        for extension in self.extensions:
            current_messages = await extension.before_model_run(
                ctx=ctx,
                messages=current_messages,
            )
        return current_messages

    async def _run_extensions_after_model_run(
        self,
        *,
        ctx: ExtensionRunContext,
        run_response: Any,
    ) -> Any:
        current_response = run_response
        for extension in reversed(self.extensions):
            current_response = await extension.after_model_run(
                ctx=ctx,
                run_response=current_response,
            )
        return current_response

    async def _run_extensions_before_tool_call(
        self,
        *,
        ctx: ExtensionRunContext,
        tool_fn: Callable,
        tool_args: dict[str, Any],
    ) -> dict[str, Any]:
        args = tool_args
        for extension in self.extensions:
            args = await extension.before_tool_call(
                ctx=ctx,
                tool_fn=tool_fn,
                tool_args=args,
            )
        return args

    async def _run_extensions_after_tool_call(
        self,
        *,
        ctx: ExtensionRunContext,
        tool_fn: Callable,
        raw_result: Any,
    ) -> Any:
        result = raw_result
        for extension in reversed(self.extensions):
            result = await extension.after_tool_call(
                ctx=ctx,
                tool_fn=tool_fn,
                raw_result=result,
            )
        return result

    async def _run_extensions_on_tool_error(
        self,
        *,
        ctx: ExtensionRunContext,
        tool_fn: Callable,
        error: Exception,
    ) -> Exception | None:
        for extension in reversed(self.extensions):
            handled = await extension.on_tool_error(
                ctx=ctx,
                tool_fn=tool_fn,
                error=error,
            )
            if handled is not None:
                return handled
        return None

    async def __call__(
        self,
        input_value: TInput,
        tool_context: TToolContext | None = None,
        extension_options: list[object] | None = None,
        config_id: UUID | None = None,
    ) -> AgentRunResult[Any]:
        if self.input_type is not None and not isinstance(input_value, self.input_type):
            raise ValueError(
                f"Input value must be of type {self.input_type}, but got {type(input_value)}"
            )
        elif not isinstance(input_value, (str, BaseModel)):
            # Should not happen based on type constraints, but just in case
            # user does not have type checking enabled
            raise ValueError(
                "Input value must be a string or a Pydantic model if input_type is not provided"
            )

        extension_context = ExtensionRunContext.from_extensions(
            agent=AgentInfo(name=self.name, model_name=self.get_model_str()),
            input_value=input_value,
            extension_options=extension_options,
        )

        async def run_step_with_context(
            input_value: TInput,
        ) -> AgentRunResult[TOutput]:
            return await self.run_step(
                input_value=input_value,
                config_id=config_id,
                extension_context=extension_context,
            )

        if self.output_type is None:
            run_step = self.as_step_if_durable(
                run_step_with_context,
                step_type=StepType.AGENT,
                display_name=self.name,
                return_type=AgentRunResult[str],
            )
        else:
            run_step = self.as_step_if_durable(
                run_step_with_context,
                step_type=StepType.AGENT,
                display_name=self.name,
                return_type=AgentRunResult[self.output_type],
            )

        if tool_context is not None:
            if self.tool_context_type is not None:
                if type(tool_context) is not self.tool_context_type:
                    raise ValueError(
                        f"tool_context must be of type {self.tool_context_type}, "
                        f"but got {type(tool_context)}"
                    )
            push_tool_context(tool_context)

        run_result: AgentRunResult[TOutput] | None = None
        teardown_error: BaseException | None = None
        try:
            await self._run_extensions_before_run(ctx=extension_context)
            result = await run_step(
                input_value=input_value,
            )
            run_result = cast(AgentRunResult[TOutput], result)
            run_result = cast(
                AgentRunResult[TOutput],
                await self._run_extensions_after_run(
                    ctx=extension_context,
                    result=run_result,
                ),
            )
        except BaseException as exc:
            teardown_error = exc
            try:
                run_result = cast(
                    AgentRunResult[TOutput],
                    await self._run_extensions_on_run_error(
                        ctx=extension_context,
                        error=exc,
                    ),
                )
                # If the extension handled the error,
                # we should clear the error we pass to teardown_run
                teardown_error = None
            except BaseException as handled_error:
                teardown_error = handled_error
                raise
        finally:
            await self._run_extensions_teardown_run(
                ctx=extension_context,
                error=teardown_error,
            )
            if tool_context is not None:
                pop_tool_context(type(tool_context))

        assert run_result is not None, "agent run should always produce a result"
        return run_result

    @abc.abstractmethod
    async def run_step(
        self,
        input_value: TInput,
        *,
        extension_context: ExtensionRunContext,
        config_id: UUID | None = None,
    ) -> AgentRunResult[TOutput]: ...

    @abc.abstractmethod
    def get_model_str(self) -> str: ...

    def to_config(self) -> AgentConfig:
        return AgentConfig(
            system_prompt=self.system_prompt,
            user_prompt=self.user_prompt,
            model=self.get_model_str(),
            max_turns=self.max_turns,
            model_parameters=self.model_parameters,
        )
