"""IO-enabled agent tools and extension helpers."""

from collections.abc import Callable, Sequence
from typing import Annotated, Any, TypedDict, cast

from pydantic import Field

from planar.ai.extensions import AgentExtension
from planar.io import IO, Column

IO_AGENT_TOOL_PROMPT = """You can interact with the human operator via dedicated IO tools:
- use `display_markdown` to show formatted content in the UI.
- use `display_table` to show tabular data. Pass data as a list of rows, provide columns when you know the column names, and never call this with empty data.
- use `display_object` to show a single object's details. Pass data as a list of `{name, value}` entries.
- use `request_text_input` to ask the operator for text.
- use `request_confirmation` when you need a yes/no answer.
- use `request_table_input` to let the operator edit tabular data. Returns the edited list of dicts.
Prefer showing context with markdown, tables, or object displays and ask concise, clear questions when requesting input."""

DisplayScalar = str | int | float | bool | None
DisplayRows = Annotated[list[list[DisplayScalar]], Field(min_length=1)]


class DisplayObjectField(TypedDict):
    """Structured field entry for object display tool calls."""

    name: str
    value: DisplayScalar


DisplayObjectFields = Annotated[list[DisplayObjectField], Field(min_length=1)]


async def display_markdown(message: str) -> str:
    """Render markdown for the human operator."""
    await IO.display.markdown(message)
    return "Displayed markdown to the operator."


async def display_table(
    label: str,
    data: DisplayRows,
    columns: list[str],
    search_enabled: bool = False,
    sorting_enabled: bool = False,
) -> str:
    """Display tabular data to the human operator.

    Args:
        label: Title for the table.
        data: List of rows containing JSON-serializable values.
        columns: Column names.
        search_enabled: Enable client-side filtering.
        sorting_enabled: Enable client-side sorting.
    """
    dict_data = [{col: value for col, value in zip(columns, row)} for row in data]
    await IO.display.table(
        label,
        data=dict_data,
        columns=columns,
        search_enabled=search_enabled,
        sorting_enabled=sorting_enabled,
    )
    return f"Displayed table '{label}' with {len(data)} rows to the operator."


async def display_object(
    label: str,
    data: DisplayObjectFields,
) -> str:
    """Display a single object's details to the human operator.

    Args:
        label: Title for the object display.
        data: List of field/value pairs.
    """
    await IO.display.object(
        label,
        data={entry["name"]: entry["value"] for entry in data},
        fields=None,
    )
    return f"Displayed object '{label}' to the operator."


async def request_text_input(
    label: str,
    help_text: str | None = None,
    placeholder: str | None = None,
) -> str:
    """Prompt the operator for textual input."""
    return await IO.input.text(
        label,
        help_text=help_text,
        placeholder=placeholder,
    )


async def request_confirmation(
    short_title: str,
    prompt: str,
    confirm_label: str = "Confirm",
    cancel_label: str = "Cancel",
) -> bool:
    """Ask the operator to confirm or decline an action."""
    return await IO.input.boolean(
        short_title,
        help_text=f"{prompt}. Confirm with '{confirm_label}' or cancel with '{cancel_label}'.",
        default=False,
    )


async def request_table_input(
    label: str,
    data: Sequence[dict[str, Any]],
    columns: list[str] | None = None,
    delete_enabled: bool = False,
    search_enabled: bool = True,
    help_text: str | None = None,
) -> list[dict[str, Any]]:
    """Present editable tabular data to the operator and return the edited result.

    Args:
        label: Title for the table.
        data: List of row dicts mapping column names to values.
        columns: Optional column ordering/selection. If None, inferred from first row.
            Columns not listed here are hidden but preserved in the returned data.
        delete_enabled: Allow the operator to delete rows.
        search_enabled: Enable client-side filtering.
        help_text: Optional description shown to the operator.
    """
    return await IO.input.table(
        label,
        data=list(data),
        columns=cast(list[str | Column] | None, columns),
        delete_enabled=delete_enabled,
        search_enabled=search_enabled,
        help_text=help_text,
    )


_DEFAULT_IO_TOOLS: tuple[Callable[..., Any], ...] = (
    display_markdown,
    display_table,
    display_object,
    request_text_input,
    request_confirmation,
    request_table_input,
)


class IOExtension(AgentExtension):
    """Extension that contributes workflow IO tools and operator guidance."""

    extension_key = "io"

    def __init__(
        self,
        *,
        include_tools: bool = True,
        instructions: str | None = IO_AGENT_TOOL_PROMPT,
    ) -> None:
        self.include_tools = include_tools
        self.instructions = instructions

    def get_tools(self) -> list[Callable[..., Any]]:
        return list(_DEFAULT_IO_TOOLS) if self.include_tools else []

    def get_instructions(self) -> str | None:
        return self.instructions

    def serialize_config(self) -> dict[str, Any] | None:
        return {
            "include_tools": self.include_tools,
            "has_instructions": self.instructions is not None,
        }
