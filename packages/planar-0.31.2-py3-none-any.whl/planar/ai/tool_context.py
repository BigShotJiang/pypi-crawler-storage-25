from typing import Any, cast

from planar.task_local import TaskLocal

# Store context stacks by type
_contexts: TaskLocal[dict[type, list[Any]]] = TaskLocal()


def _get_or_init_contexts() -> dict[type, list[Any]]:
    """Get the contexts dict, initializing if needed."""
    if not _contexts.is_set():
        _contexts.set({})
    return _contexts.get()


def push_tool_context(ctx: Any) -> None:
    """Push a context value onto the stack for its type."""
    contexts = _get_or_init_contexts()
    ctx_type = type(ctx)
    stack = contexts.setdefault(ctx_type, [])
    stack.append(ctx)


def pop_tool_context(ctx_type: type) -> None:
    """Pop one context value from the stack for the given type."""
    contexts = _get_or_init_contexts()
    stack = contexts.get(ctx_type)
    if not stack:
        return
    stack.pop()
    if not stack:
        contexts.pop(ctx_type, None)


def get_tool_context[T](ctx_type: type[T]) -> T:
    """Get the active tool context (top of stack) for a type."""
    contexts = _get_or_init_contexts()
    stack = contexts.get(ctx_type)
    if not stack:
        raise RuntimeError(f"No tool context of type {ctx_type.__name__} found")
    return cast(T, stack[-1])


def has_tool_context(ctx_type: type) -> bool:
    """Check if a tool context of the given type exists."""
    contexts = _get_or_init_contexts()
    stack = contexts.get(ctx_type)
    return bool(stack)


def clear_tool_context() -> None:
    """Clear all tool contexts."""
    _get_or_init_contexts().clear()
