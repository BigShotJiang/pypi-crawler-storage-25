"""Helpers for resolving configured agent models at runtime."""

import inspect
from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Self

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    RootModel,
    model_validator,
)
from pydantic_ai import models

from planar.ai.factories import (
    azure_openai_responses_model_factory,
    openai_responses_model_factory,
)
from planar.logging import get_logger

if TYPE_CHECKING:  # pragma: no cover - circular import guard
    from planar.config import PlanarConfig


logger = get_logger(__name__)


DEFAULT_MODEL_NAME = "openai:gpt-4o"
OPENAI_RESPONSES_FACTORY_KEY = "openai_responses"
AZURE_OPENAI_RESPONSES_FACTORY_KEY = "azure_openai_responses"
DEFAULT_RESOLUTION_CACHE_KEY = "__default__"


@dataclass(frozen=True)
class ConfiguredModelKey:
    """Reference to a named configured model."""

    name: str


@dataclass(frozen=True)
class ResolvedModelConfig:
    """Resolved model plus model settings defaults from configuration."""

    model: models.Model
    parameters: dict[str, Any]


class ModelProviderConfig(BaseModel):
    """Configuration for a shared provider instance."""

    factory: str
    options: dict[str, Any] = Field(default_factory=dict)


class ModelDefinition(BaseModel):
    """Configuration for a provider-backed or inferred model."""

    provider: str | None = None
    model: str | None = None
    provider_options: dict[str, Any] = Field(default_factory=dict)
    parameters: dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(extra="forbid")

    @model_validator(mode="after")
    def validate_model_definition(self) -> Self:
        if self.provider is None and self.model is None:
            raise ValueError(
                "ai_models.models entries must define either 'provider' or 'model'."
            )
        return self


class ModelEntrySpec(RootModel[str | ModelDefinition]):
    """Wrapper allowing either a provider-based model or a direct identifier."""

    root: str | ModelDefinition


class AIModelsConfig(BaseModel):
    """Top-level configuration for model registry models."""

    default: str | None = None
    providers: dict[str, ModelProviderConfig] = Field(default_factory=dict)
    models: dict[str, ModelEntrySpec] = Field(default_factory=dict)

    @model_validator(mode="after")
    def default_refers_to_entry(self) -> Self:
        if self.default and self.default not in self.models:
            raise ValueError("ai_models.default must reference a declared model.")
        return self

    def first_entry(self) -> ModelEntrySpec | None:
        for value in self.models.values():
            return value
        return None

    def default_entry(self) -> ModelEntrySpec | None:
        if self.default and self.default in self.models:
            return self.models[self.default]
        return self.first_entry()

    def resolve_model_spec(self, key: str) -> ModelEntrySpec:
        try:
            return self.models[key]
        except KeyError as exc:
            raise ValueError(
                f"Configured model '{key}' not found. Check ai_models.models."
            ) from exc


DEFAULT_MODEL_CONFIG = AIModelsConfig(
    default="default",
    models={
        "default": ModelEntrySpec.model_validate(
            ModelDefinition(model=DEFAULT_MODEL_NAME)
        )
    },
)


class ModelRegistry:
    """Resolves configured models defined in PlanarConfig.ai_models."""

    def __init__(self, config: "PlanarConfig"):
        self._config = config
        self._cache: dict[str, ResolvedModelConfig] = {}
        self._factories: dict[str, Callable[..., Any]] = {}
        self._register_builtin_factories()

    async def resolve(self, key: ConfiguredModelKey | None) -> models.Model:
        """Return a resolved model for the provided key or default configuration."""

        return (await self.resolve_with_settings(key)).model

    async def resolve_with_settings(
        self, key: ConfiguredModelKey | None
    ) -> ResolvedModelConfig:
        """Resolve a model and default model settings from ai_models configuration."""

        cache_key = key.name if key else DEFAULT_RESOLUTION_CACHE_KEY
        if cache_key in self._cache:
            return self._cache[cache_key]

        spec, label = self._select_entry(key)
        resolved = await self._instantiate_spec(spec, label)
        self._cache[cache_key] = resolved
        return resolved

    def _select_entry(
        self, key: ConfiguredModelKey | None
    ) -> tuple[ModelEntrySpec, str]:
        ai_models_config = self._config.ai_models or DEFAULT_MODEL_CONFIG
        if key:
            return ai_models_config.resolve_model_spec(key.name), key.name

        default_entry = ai_models_config.default_entry()
        if not default_entry:
            raise ValueError("No configured model key or default model configured.")

        return default_entry, "default"

    async def _instantiate_spec(
        self, spec: ModelEntrySpec, label: str
    ) -> ResolvedModelConfig:
        value = spec.root
        if isinstance(value, str):
            model = models.infer_model(value)
            return ResolvedModelConfig(
                model=model,
                parameters={},
            )

        if isinstance(value, ModelDefinition):
            return await self._instantiate_model_definition(value, label)

        raise ValueError(
            f"Invalid model configuration for '{label}'. Expected string or ModelDefinition."
        )

    async def _instantiate_model_definition(
        self, model_def: ModelDefinition, label: str
    ) -> ResolvedModelConfig:
        if not model_def.provider:
            model_name = model_def.model
            if model_name is None:
                raise ValueError(
                    f"Model '{label}' must define 'model' when 'provider' is omitted."
                )
            model = models.infer_model(model_name)
            return ResolvedModelConfig(
                model=model,
                parameters=dict(model_def.parameters),
            )

        provider = self._get_provider(model_def.provider, label)
        model_options = dict(model_def.provider_options)
        if model_def.model:
            # Some providers may use the model as a parameter
            # to the factory, so we include it in the options
            # ex. openai_responses_model_factory
            model_options["model"] = model_def.model
        merged_options = {**provider.options, **model_options}
        model = await self._call_factory_by_name(
            provider.factory,
            merged_options,
            label,
        )
        return ResolvedModelConfig(
            model=model,
            parameters=dict(model_def.parameters),
        )

    def _get_provider(self, provider_key: str, label: str) -> ModelProviderConfig:
        ai_models_config = self._config.ai_models
        if not ai_models_config or provider_key not in ai_models_config.providers:
            logger.warning(
                "requested model provider missing",
                provider=provider_key,
                model_label=label,
            )
            raise ValueError(
                f"Provider '{provider_key}' not found. "
                "Check ai_models.providers configuration."
            )
        return ai_models_config.providers[provider_key]

    def _build_factory_kwargs(
        self, factory: Callable[..., Any], options: dict[str, Any]
    ) -> dict[str, Any]:
        sig = inspect.signature(factory)
        kwargs: dict[str, Any] = {}

        accepts_var_kwargs = any(
            param.kind == inspect.Parameter.VAR_KEYWORD
            for param in sig.parameters.values()
        )

        if "options" in sig.parameters or accepts_var_kwargs:
            kwargs["options"] = options
        if "config" in sig.parameters or accepts_var_kwargs:
            kwargs["config"] = self._config
        return kwargs

    def _register_builtin_factories(self) -> None:
        self.register_factory(
            OPENAI_RESPONSES_FACTORY_KEY, openai_responses_model_factory
        )
        self.register_factory(
            AZURE_OPENAI_RESPONSES_FACTORY_KEY, azure_openai_responses_model_factory
        )
        # Backwards-compatible aliases for configs that still point to dotted paths
        self.register_factory(
            "planar.ai.factories.openai_responses_model_factory",
            openai_responses_model_factory,
        )
        self.register_factory(
            "planar.ai.factories.azure_openai_responses_model_factory",
            azure_openai_responses_model_factory,
        )

    def register_factory(self, name: str, factory: Callable[..., Any]) -> None:
        if not name:
            raise ValueError("Factory name must be a non-empty string.")
        existing = self._factories.get(name)
        if existing and existing is not factory:
            logger.warning(
                "overriding configured model factory",
                factory_key=name,
                previous=self._factory_name(existing),
                new=self._factory_name(factory),
            )
        self._factories[name] = factory

    def _get_factory(self, name: str) -> Callable[..., Any]:
        factory = self._factories.get(name)
        if factory:
            return factory
        logger.warning("unregistered model factory requested", factory_key=name)
        raise ValueError(
            f"Factory '{name}' is not registered. Call PlanarApp.register_model_factory "
            "before resolving configured models."
        )

    async def _call_factory_by_name(
        self, factory_key: str, options: dict[str, Any], label: str
    ) -> models.Model:
        factory = self._get_factory(factory_key)
        logger.debug(
            "invoking configured model factory",
            factory=factory_key,
            model_label=label,
        )
        kwargs = self._build_factory_kwargs(factory, options)
        result = factory(**kwargs)
        if inspect.isawaitable(result):
            result = await result
        if not isinstance(result, models.Model):
            raise TypeError(
                f"Configured model factory '{factory_key}' must return a "
                "pydantic_ai.models.Model instance."
            )
        return result

    @staticmethod
    def _factory_name(factory: Callable[..., Any]) -> str:
        if hasattr(factory, "__name__"):
            return factory.__name__  # type: ignore[attr-defined]
        return factory.__class__.__name__
