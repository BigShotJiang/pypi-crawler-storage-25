"""
Utility functions for working with AI models and agents.
"""

from pydantic import BaseModel
from sqlmodel import col, select

from planar.ai.agent import Agent
from planar.ai.agent_utils import agent_configuration, create_tool_definition
from planar.ai.models import AgentSerializeable
from planar.logging import get_logger
from planar.object_registry import ObjectRegistry
from planar.session import get_session
from planar.workflows import models as m

logger = get_logger(__name__)


async def serialize_agent(
    agent_obj: Agent,
) -> AgentSerializeable:
    """
    Serialize an agent object into AgentSerializeable with schema validation warnings.

    Creates a serializable representation of an Agent, including all database
    configurations and schema validation status.

    Args:
        agent_obj: The agent object to serialize

    Returns:
        AgentSerializeable representation of the agent
    """
    logger.debug("serializing agent", agent_name=agent_obj.name)
    # Process tools if present
    tool_definitions = []
    if agent_obj.tools:
        tool_definitions = [
            create_tool_definition(t).model_dump() for t in agent_obj.tools
        ]
    logger.debug(
        "tool definitions for agent",
        agent_name=agent_obj.name,
        num_tools=len(tool_definitions),
    )

    input_schema = agent_obj.input_schema()
    result_schema = agent_obj.output_schema()
    logger.debug(
        "agent schema presence",
        input_schema_present=input_schema is not None,
        output_schema_present=result_schema is not None,
    )

    configs_list = await agent_configuration.read_configs_with_default(
        agent_obj.name, agent_obj.to_config()
    )
    logger.debug(
        "retrieved configurations for agent",
        num_configs=len(configs_list),
        agent_name=agent_obj.name,
    )

    serializable = AgentSerializeable(
        name=agent_obj.name,
        tool_definitions=tool_definitions,
        extensions=agent_obj.describe_extensions(),
        input_schema=input_schema,
        output_schema=result_schema,
        configs=configs_list,
    )
    logger.debug("agent serialized successfully", agent_name=agent_obj.name)
    return serializable


async def get_agent_serializable(
    agent_name: str,
    registry: ObjectRegistry,
) -> AgentSerializeable | None:
    """
    Look up an agent by name in the registry and serialize it.

    Args:
        agent_name: The name of the agent to look up
        registry: ObjectRegistry to look up the agent

    Returns:
        AgentSerializeable representation of the agent, or None if not found
    """
    logger.debug("looking up agent by name", agent_name=agent_name)
    # Find the first agent with matching name, or None if none found
    try:
        reg_agent = registry.get_agent(agent_name)
    except ValueError:
        logger.debug("agent not found in registry", agent_name=agent_name)
        return None

    logger.debug(
        "found agent in registry, serializing",
        agent_name=agent_name,
    )
    return await serialize_agent(reg_agent)


class StepWithWorkflow(BaseModel):
    """A WorkflowStep paired with its parent workflow's name."""

    step: m.WorkflowStep
    workflow_name: str


class StepWithWorkflowPage(BaseModel):
    """Paginated list of workflow steps joined with workflow names."""

    items: list[StepWithWorkflow]
    total: int
    offset: int
    limit: int


async def query_agent_runs(
    agent_name: str, offset: int = 0, limit: int = 50
) -> StepWithWorkflowPage:
    """Find all the invocations of `agent_name`."""
    from planar.modeling.orm.query_filter_builder import build_paginated_query

    session = get_session()

    async with session.begin_read():
        base_query = (
            select(m.WorkflowStep, m.Workflow.function_name)
            .join(m.Workflow, col(m.WorkflowStep.workflow_id) == col(m.Workflow.id))
            .where(
                col(m.WorkflowStep.step_type) == m.StepType.AGENT,
                col(m.WorkflowStep.display_name) == agent_name,
            )
            .order_by(
                col(m.WorkflowStep.created_at).desc(),
                col(m.WorkflowStep.step_id).desc(),
            )
        )

        paginated_query, count_query = build_paginated_query(
            base_query,
            offset=offset,
            limit=limit,
        )
        total = (await session.exec(count_query)).one()

        result = await session.exec(paginated_query)
        return StepWithWorkflowPage(
            items=[
                StepWithWorkflow(step=step, workflow_name=wf_name)
                for step, wf_name in result.all()
            ],
            total=total,
            offset=offset,
            limit=limit,
        )
