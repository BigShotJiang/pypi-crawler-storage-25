import inspect
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, ClassVar, Self

from pydantic import BaseModel

from planar.ai.models import (
    AgentInfo,
    AgentRunResult,
    ExtensionDescriptor,
    ModelMessage,
)

if TYPE_CHECKING:
    from planar.ai.pydantic_ai import ModelRunResponse


@dataclass
class ExtensionRunContext:
    """Per-run extension context containing typed options and scratch state."""

    agent: AgentInfo
    input_value: BaseModel | str
    extension_options: list[object] = field(default_factory=list)
    _options_by_type: dict[type[Any], object | None] = field(
        default_factory=dict,
        init=False,
        repr=False,
    )
    _state_by_extension_id: dict[int, dict[str, Any]] = field(
        default_factory=dict,
        init=False,
        repr=False,
    )

    @classmethod
    def from_extensions(
        cls,
        *,
        agent: AgentInfo,
        input_value: BaseModel | str,
        extension_options: Sequence[object] | None = None,
    ) -> Self:
        ctx = cls(
            agent=agent,
            input_value=input_value,
            extension_options=list(extension_options or []),
        )
        if extension_options is not None:
            ctx._options_by_type = {
                type(option): option for option in extension_options
            }

        return ctx

    def options_for(self, extension: "AgentExtension") -> object | None:
        """Return the typed options object for the provided extension instance."""
        if extension.options_type is None:
            return None
        return self._options_by_type.get(extension.options_type)

    def state_for(self, extension: "AgentExtension") -> dict[str, Any]:
        """Return mutable per-run scratch state for the provided extension instance."""
        return self._state_by_extension_id.setdefault(id(extension), {})


class AgentExtension:
    """Composable unit of agent behavior."""

    extension_key: ClassVar[str | None] = None
    extension_version: ClassVar[int] = 1
    options_type: ClassVar[type[Any] | None] = None

    def get_tools(self) -> list[Callable[..., Any]]:
        """Return tools contributed by this extension."""
        return []

    def get_instructions(self) -> str | None:
        """Return static instruction text contributed by this extension."""
        return None

    def serialize_config(self) -> dict[str, Any] | None:
        """Return safe static config for persistence and display."""
        return None

    def serialize_options(self, options: object | None) -> dict[str, Any] | None:
        """Return safe run-specific options for persistence and display."""
        if options is None:
            return None
        if isinstance(options, BaseModel):
            return options.model_dump(mode="json")
        return None

    def describe(self, options: object | None = None) -> ExtensionDescriptor:
        """Describe this extension for live and historical inspection."""
        options_schema: dict[str, Any] | None = None
        if self.options_type is not None and issubclass(self.options_type, BaseModel):
            options_schema = self.options_type.model_json_schema()

        return ExtensionDescriptor(
            key=self.extension_key or type(self).__name__,
            version=self.extension_version,
            label=type(self).__name__,
            description=inspect.getdoc(type(self)),
            config=self.serialize_config(),
            options_schema=options_schema,
            options=self.serialize_options(options),
        )

    async def before_run(self, *, ctx: ExtensionRunContext) -> None:
        pass

    async def after_run(
        self,
        *,
        ctx: ExtensionRunContext,
        result: AgentRunResult[Any],
    ) -> AgentRunResult[Any]:
        return result

    async def on_run_error(
        self,
        *,
        ctx: ExtensionRunContext,
        error: BaseException,
    ) -> AgentRunResult[Any]:
        raise error

    async def teardown_run(
        self,
        *,
        ctx: ExtensionRunContext,
        error: BaseException | None,
    ) -> None:
        pass

    async def before_model_run(
        self,
        *,
        ctx: ExtensionRunContext,
        messages: list[ModelMessage],
    ) -> list[ModelMessage]:
        return messages

    async def after_model_run(
        self,
        *,
        ctx: ExtensionRunContext,
        run_response: "ModelRunResponse[Any]",
    ) -> "ModelRunResponse[Any]":
        return run_response

    async def before_tool_call(
        self,
        *,
        ctx: ExtensionRunContext,
        tool_fn: Callable[..., Any],
        tool_args: dict[str, Any],
    ) -> dict[str, Any]:
        return tool_args

    async def after_tool_call(
        self,
        *,
        ctx: ExtensionRunContext,
        tool_fn: Callable[..., Any],
        raw_result: Any,
    ) -> Any:
        return raw_result

    async def on_tool_error(
        self,
        *,
        ctx: ExtensionRunContext,
        tool_fn: Callable[..., Any],
        error: Exception,
    ) -> Exception | None:
        return None
