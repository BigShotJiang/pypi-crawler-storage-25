import logging
import logging.config
import os
import re
import sys
from collections.abc import Callable
from contextlib import contextmanager
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Annotated, Any, Literal

import yaml
from dotenv import load_dotenv
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    HttpUrl,
    PrivateAttr,
    SecretStr,
    ValidationError,
    model_validator,
)
from sqlalchemy import URL, make_url

from planar.ai.model_registry import AIModelsConfig, ModelRegistry
from planar.ai.sandbox.models import SandboxConfig
from planar.data.config import DataConfig
from planar.files.storage.config import LocalDirectoryConfig, StorageConfig
from planar.logging import get_logger
from planar.logging.formatter import StructuredFormatter
from planar.secrets.refreshable import RefreshableSecret
from planar.secrets.registry import SecretRegistry

logger = get_logger(__name__)


class Environment(str, Enum):
    DEV = "dev"
    PROD = "prod"


class InvalidConfigurationError(Exception):
    pass


class LogLevel(str, Enum):
    NOTSET = "NOTSET"
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"


class LoggerConfig(BaseModel):
    level: LogLevel = LogLevel.INFO
    propagate: bool | None = False
    file: str | None = None


class SQLiteConfig(BaseModel):
    driver: Literal["sqlite", "sqlite+aiosqlite"] = "sqlite+aiosqlite"
    path: str
    strict: bool = False

    def connection_url(self) -> URL:
        driver = self.driver
        if driver == "sqlite":
            # allow "sqlite" to be used as a shortcut for "sqlite+aiosqlite"
            driver = "sqlite+aiosqlite"
        return URL.create(drivername=driver, database=self.path)


class PostgreSQLConfig(BaseModel):
    driver: Literal["postgresql", "postgresql+asyncpg"] = (
        "postgresql+asyncpg"  # Allow async PostgreSQL
    )
    host: str | None = None
    port: int | None = None
    user: str | SecretStr | None = None
    password: SecretStr | None = None
    db: str | None

    def connection_url(self) -> URL:
        driver = self.driver
        if driver == "postgresql":
            # allow "postgresql" to be used as a shortcut for "postgresql+asyncpg"
            # we only support asyncpg, but this lets users use "postgresql"
            driver = "postgresql+asyncpg"

        username = (
            self.user.get_secret_value()
            if isinstance(self.user, SecretStr)
            else self.user
        )

        return URL.create(
            drivername=driver,
            host=self.host,
            port=self.port,
            username=username,
            password=self.password.get_secret_value() if self.password else None,
            database=self.db,
        )


DatabaseConfig = Annotated[
    SQLiteConfig | PostgreSQLConfig, Field(discriminator="driver")
]


class AppConfig(BaseModel):
    db_connection: str
    max_db_conflict_retries: int | None = None
    # Default schema for user-defined entities (PlanarBaseEntity)
    # Postgres: used as the target schema for user tables
    # SQLite: ignored (SQLite has no schemas)
    entity_schema: str = "planar_entity"


def default_storage_config() -> StorageConfig:
    return LocalDirectoryConfig(backend="localdir", directory=".files")


class CorsConfig(BaseModel):
    allow_origins: list[str] | str
    allow_credentials: bool
    allow_methods: list[str]
    allow_headers: list[str]

    @model_validator(mode="after")
    def validate_allow_origins(self):
        if self.allow_credentials and "*" in self.allow_origins:
            raise ValueError(
                "allow_credentials cannot be True if allow_origins includes '*'. Must explicitly specify allowed origins."
            )
        return self


LOCAL_CORS_CONFIG = CorsConfig(
    # Locally accept requests from ports 3000-3004 as there may be multiple instances
    # of coplane app running locally via git worktrees or similar functionality
    allow_origins=[
        "https://app.coplane.com",
        "https://staging.coplane.com",
        *[f"http://127.0.0.1:300{x}" for x in range(5)],
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

PROD_CORS_CONFIG = CorsConfig(
    allow_origins=r"^https://(?:[a-zA-Z0-9-]+\.)+coplane\.(dev|com)$",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class JWTConfig(BaseModel):
    client_id: str | None = None
    org_id: str | None = None
    additional_exclusion_paths: list[str] | None = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_client_id(self):
        if not self.client_id or not self.org_id:
            raise ValueError("Both client_id and org_id required to enable JWT")
        return self


# Coplane ORG JWT config
JWT_COPLANE_CONFIG = JWTConfig(
    client_id="client_01JSJHJPKG09TMSK6NHJP0S180",
    org_id="org_01JY4QP57Y7H4EQ7HT3BGN7TNK",
)


class OtelConfig(BaseModel):
    collector_endpoint: HttpUrl
    resource_attributes: dict[str, str] | None = None


def install_otel_provider(otel_config: OtelConfig):
    try:
        from planar.logging.otel import get_otel_collector_handler  # noqa: PLC0415
    except ImportError as e:
        raise ImportError(
            "OpenTelemetry is not installed. Please install it to use OpenTelemetry logging."
        ) from e
    return get_otel_collector_handler(
        otel_config.collector_endpoint, otel_config.resource_attributes
    )


class AuthzConfig(BaseModel):
    enabled: bool = True
    policy_file: str | None = None


class ServiceTokenConfig(BaseModel):
    token: str | None = Field(None, min_length=1)


class SecurityConfig(BaseModel):
    cors: CorsConfig = PROD_CORS_CONFIG
    jwt: JWTConfig | None = None
    service_token: ServiceTokenConfig | None = None
    authz: AuthzConfig | None = None


class SecretsProviderConfig(BaseModel):
    # Built-in provides: "env", "aws_secrets_manager", "azure_key_vault"
    # OR a python path to a custom provider class: "my_app.secrets.MyHashicorpVaultProvider"
    provider: str

    # Arbitrary configuration passed to the provider's __init__
    options: dict[str, Any] = Field(default_factory=dict)


class SecretsSection(BaseModel):
    providers: dict[str, SecretsProviderConfig] = Field(default_factory=dict)
    custom_secrets: dict[str, SecretStr] = Field(default_factory=dict)


class DirSyncConfig(BaseModel):
    coplane_api_url: str
    coplane_api_token: SecretStr
    cron_schedule: str | None = None


class PlanarConfig(BaseModel):
    db_connections: dict[str, DatabaseConfig | SecretStr]
    app: AppConfig
    ai_models: AIModelsConfig | None = None
    storage: StorageConfig | None = default_storage_config()
    sse_hub: str | bool = False
    environment: Environment = Environment.DEV
    security: SecurityConfig = SecurityConfig()
    logging: dict[str, LoggerConfig] | None = None
    otel: OtelConfig | None = None
    data: DataConfig | None = None
    dir_sync: DirSyncConfig | None = None
    sandbox: SandboxConfig | None = None
    secrets: SecretsSection | None = None

    # forbid extra keys in the config to prevent accidental misconfiguration
    model_config = ConfigDict(extra="forbid")
    _model_registry: ModelRegistry | None = PrivateAttr(default=None)

    @model_validator(mode="after")
    def validate_db_connection_reference(self):
        if self.app.db_connection not in self.db_connections:
            raise ValueError(
                f"Invalid db_connection reference: {self.app.db_connection}"
            )
        return self

    def connection_url(self) -> URL:
        connection = self.db_connections[self.app.db_connection]
        if isinstance(connection, SecretStr):
            # treat the connection as a URL string
            return make_url(connection.get_secret_value())
        return connection.connection_url()

    def configure_logging(self):
        loggers_config = {
            # root logger default level should be INFO
            "": LoggerConfig(level=LogLevel.INFO),
            # force disable uvicorn's logger and let it propagate to root
            "uvicorn": LoggerConfig(level=LogLevel.NOTSET, propagate=True),
        }
        if self.logging:
            # Merge provided logging config with defaults
            loggers_config.update(self.logging)

        root_logger_config = None
        loggers = {}
        # define some standard formatters and handlers
        formatters = {
            "structured_console": {
                "()": "planar.logging.formatter.StructuredFormatter",
                "use_colors": True,
            },
            "structured_file": {
                "()": "planar.logging.formatter.StructuredFormatter",
                "use_colors": False,
            },
        }
        filters = {
            "add_attributes": {
                "()": "planar.logging.attributes.ExtraAttributesFilter",
            },
            "suppress_internal_sse_push_noise": {
                "()": "planar.logging.attributes.InternalSSEPushNoiseFilter",
            },
        }
        handlers = {
            "console": {
                "class": "logging.StreamHandler",
                "formatter": "structured_console",
                "stream": sys.stderr,
                "filters": ["add_attributes", "suppress_internal_sse_push_noise"],
            },
        }

        for name, cfg in loggers_config.items():
            default_handler = "console"

            if cfg.file:
                # File was specified. Create a handler for that file if it doesn't exist already
                default_handler = f"file:{cfg.file}"
                if default_handler not in handlers:
                    handlers[default_handler] = {
                        "class": "logging.FileHandler",
                        "formatter": "structured_file",
                        "filename": cfg.file,
                        "filters": [
                            "add_attributes",
                            "suppress_internal_sse_push_noise",
                        ],
                    }

            logging_module_cfg = {
                "level": cfg.level.value,
                "handlers": [default_handler] if not cfg.propagate else [],
                "propagate": cfg.propagate,
            }

            if name == "":
                root_logger_config = logging_module_cfg
            else:
                loggers[name] = logging_module_cfg

        logging_config = dict(
            version=1,
            disable_existing_loggers=False,
            root=root_logger_config,
            loggers=loggers,
            handlers=handlers,
            formatters=formatters,
            filters=filters,
        )
        logging.config.dictConfig(logging_config)

        if self.otel:
            handler = install_otel_provider(self.otel)
            for k, v in loggers.items():
                if not v["propagate"]:
                    # If the logger does not propagate, we need to add the otel handler
                    logger = logging.getLogger(k)
                    logger.handlers.append(handler)
            # always add otel handler to the root logger so it forwards
            # propagated logs
            logging.root.addHandler(handler)

    def get_model_registry(self) -> ModelRegistry:
        if self._model_registry is None:
            self._model_registry = ModelRegistry(self)
        return self._model_registry


def load_config(yaml_str: str) -> PlanarConfig:
    try:
        raw = yaml.safe_load(yaml_str) or {}
        return PlanarConfig.model_validate(raw)
    except (ValidationError, yaml.YAMLError) as e:
        raise InvalidConfigurationError(f"Configuration error: {e}") from e


def load_config_from_file(file_path: Path) -> PlanarConfig:
    """
    Load configuration from a YAML file.

    Args:
        file_path: Path to the YAML config file

    Returns:
        Parsed PlanarConfig object

    Raises:
        InvalidConfigurationError: If the config file cannot be loaded or is invalid
    """
    try:
        with open(file_path) as f:
            yaml_str = f.read()
        return load_config(yaml_str)
    except FileNotFoundError as exc:
        raise InvalidConfigurationError(
            f"Configuration file not found: {file_path}"
        ) from exc
    except (ValidationError, yaml.YAMLError) as e:
        raise InvalidConfigurationError(
            f"Configuration error in {file_path}: {e}"
        ) from e


def sqlite_config(db_path: str) -> PlanarConfig:
    return PlanarConfig(
        app=AppConfig(db_connection="app"),
        db_connections={"app": SQLiteConfig(path=db_path)},
    )


def connection_string_config(connection_string: str) -> PlanarConfig:
    return PlanarConfig(
        app=AppConfig(db_connection="app"),
        db_connections={"app": SecretStr(connection_string)},
    )


def get_environment() -> str:
    """Get the current Planar environment (dev or prod), defaulting to dev."""
    return os.environ.get("PLANAR_ENV", "dev")


def get_config_path() -> Path | None:
    """Get the path to the config file from environment variable"""
    config_path = os.environ.get("PLANAR_CONFIG")
    return Path(config_path) if config_path else None


def deep_merge_dicts(
    source: dict[str, Any], destination: dict[str, Any]
) -> dict[str, Any]:
    """
    Deeply merge dictionary `source` into `destination`.

    Modifies `destination` in place.
    """
    for key, value in source.items():
        if isinstance(value, dict):
            # Get node or create one
            node = destination.setdefault(key, {})
            if isinstance(node, dict):
                deep_merge_dicts(value, node)
            else:
                # If the destination node is not a dict, overwrite it
                destination[key] = value
        else:
            destination[key] = value
    return destination


def _expand_env_vars(text: str) -> str:
    """
    Custom environment variable expansion that is safer than os.path.expandvars.
    It only expands ${VAR} where VAR is a valid identifier.

    This avoids incorrectly interpreting complex patterns (like ${secret:...}) as
    shell parameter expansions, while still allowing simple variable expansion
    inside them (e.g. ${secret:provider:${VAR}}).
    """
    # Pattern for ${VAR}
    pattern = re.compile(r"\$\{([a-zA-Z_][a-zA-Z0-9_]*)\}")

    def replace(match: re.Match[str]) -> str:
        var_name = match.group(1)
        return os.environ.get(var_name, match.group(0))

    return pattern.sub(replace, text)


def expand_env_vars_in_dict(obj: Any) -> Any:
    """
    Recursively expand ${VAR} environment variable patterns in string values.

    This allows YAML to be parsed first (preserving structure), then env vars
    are expanded in the resulting values. This prevents YAML special characters
    in env var values from being interpreted as YAML syntax.

    Args:
        obj: A dict, list, string, or other value

    Returns:
        The same structure with env vars expanded in all string values
    """
    return _transform_nested_strings(obj, _expand_env_vars)


_SECRET_PATTERN = re.compile(r"\$\{secret:([^}]+)\}")


@dataclass(frozen=True)
class ParsedSecretToken:
    provider_name: str
    secret_id: str
    json_key: str | None = None


def _parse_secret_token(content: str) -> ParsedSecretToken | None:
    provider_name, sep, remainder = content.partition(":")
    if not sep or not provider_name or not remainder:
        return None

    secret_id, json_sep, json_key = remainder.partition(":")
    if not secret_id:
        return None
    return ParsedSecretToken(
        provider_name=provider_name,
        secret_id=secret_id,
        json_key=json_key if json_sep and json_key else None,
    )


def _transform_nested_strings(obj: Any, transform: Callable[[str], Any]) -> Any:
    if isinstance(obj, str):
        return transform(obj)
    if isinstance(obj, dict):
        return {k: _transform_nested_strings(v, transform) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_transform_nested_strings(item, transform) for item in obj]
    return obj


def _resolve_parsed_secret(
    parsed: ParsedSecretToken,
    raw_token: str,
    registry: SecretRegistry,
) -> RefreshableSecret:
    def resolver() -> str:
        return registry.resolve_secret(
            parsed.provider_name,
            parsed.secret_id,
            parsed.json_key,
        ).get_secret_value()

    try:
        return RefreshableSecret(resolver=resolver)
    except Exception as e:
        raise InvalidConfigurationError(
            f"Failed to resolve secret {raw_token}: {e}"
        ) from e


def _resolve_secret_string(value: str, registry: SecretRegistry) -> str | SecretStr:
    if "${secret:" not in value:
        return value

    exact_match = _SECRET_PATTERN.fullmatch(value)
    if exact_match is not None:
        parsed = _parse_secret_token(exact_match.group(1))
        if parsed is None:
            return value
        return _resolve_parsed_secret(parsed, exact_match.group(0), registry)

    def replace_match(match: re.Match[str]) -> str:
        parsed = _parse_secret_token(match.group(1))
        if parsed is None:
            return match.group(0)
        try:
            return registry.resolve_secret(
                parsed.provider_name,
                parsed.secret_id,
                parsed.json_key,
            ).get_secret_value()
        except Exception as e:
            raise InvalidConfigurationError(
                f"Failed to resolve secret {match.group(0)}: {e}"
            ) from e

    return SecretStr(_SECRET_PATTERN.sub(replace_match, value))


def resolve_secrets_in_dict(obj: Any, registry: SecretRegistry) -> Any:
    """Recursively resolve ${secret:...} patterns in string values."""
    return _transform_nested_strings(
        obj,
        lambda value: _resolve_secret_string(value, registry),
    )


def load_environment_aware_env_vars() -> None:
    """
    Load environment variables based on environment settings.

    We look for .env file in the entry point and local directory, with environment
    specific files (e.g. .env.dev, .env.prod) taking precedence.
    """
    env = get_environment()
    paths_to_check = []
    if entry_point := os.environ.get("PLANAR_ENTRY_POINT"):
        entry_point_dir = Path(entry_point).parent
        paths_to_check.append(entry_point_dir / f".env.{env}")
        paths_to_check.append(entry_point_dir / ".env")
    paths_to_check.append(Path(f".env.{env}"))
    paths_to_check.append(Path(".env"))

    for path in paths_to_check:
        if path.exists():
            load_dotenv(path)
            return


@contextmanager
def _temporary_config_logging():
    """Install a console handler so config loading logs are visible before configuration."""
    root_logger = logging.getLogger()
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(StructuredFormatter(use_colors=sys.stderr.isatty()))
    handler.setLevel(logging.NOTSET)

    previous_level = root_logger.level
    if root_logger.getEffectiveLevel() > logging.INFO:
        root_logger.setLevel(logging.INFO)

    root_logger.addHandler(handler)

    try:
        yield
    finally:
        root_logger.removeHandler(handler)
        handler.close()
        root_logger.setLevel(previous_level)


def load_environment_aware_config[ConfigClass]() -> PlanarConfig:
    """
    Load configuration based on environment settings, using environment variables
    and config files.

    Priority order:
    1. Explicit path via PLANAR_CONFIG environment variable.
    2. Environment-specific file (planar.{env}.yaml) overriding defaults.
    3. Default configuration based on environment (dev/prod).

    Returns:
        Configured PlanarConfig object

    Raises:
        InvalidConfigurationError: If configuration loading or validation fails.
    """
    with _temporary_config_logging():
        load_environment_aware_env_vars()
        env = get_environment()

        if env == "dev":
            base_config = sqlite_config(db_path="planar_dev.db")
            base_config.security = SecurityConfig(cors=LOCAL_CORS_CONFIG)
            base_config.environment = Environment.DEV
        else:
            base_config = sqlite_config(db_path="planar.db")
            base_config.environment = Environment.PROD
            base_config.security = SecurityConfig(
                cors=PROD_CORS_CONFIG, jwt=JWT_COPLANE_CONFIG
            )

        # Convert base config to dict for merging
        # Use by_alias=False to work with Python field names before validation
        base_dict = base_config.model_dump(mode="python", by_alias=False)

        override_config_path = get_config_path()
        if override_config_path:
            if not override_config_path.exists():
                raise InvalidConfigurationError(
                    f"Configuration file not found: {override_config_path}"
                )
        else:
            paths_to_check = []
            if os.environ.get("PLANAR_ENTRY_POINT"):
                # Extract the directory from the entry point path
                entry_point_dir = Path(os.environ["PLANAR_ENTRY_POINT"]).parent
                paths_to_check = [
                    entry_point_dir / f"planar.{env}.yaml",
                    entry_point_dir / "planar.yaml",
                ]
            paths_to_check.append(Path(f"planar.{env}.yaml"))
            paths_to_check.append(Path("planar.yaml"))

            override_config_path = next(
                (path for path in paths_to_check if path.exists()), None
            )
            if override_config_path is None:
                logger.warning(
                    "no override config file found, using default config",
                    search_paths=[str(p) for p in paths_to_check],
                    env=env,
                )

        merged_dict = base_dict
        if override_config_path and override_config_path.exists():
            logger.info(
                "using override config file",
                override_config_path=override_config_path,
            )
            try:
                # We can't use load_config_from_file here because we expect
                # the override config to not be a fully validated PlanarConfig object,
                # and we need to merge it onto the base default config.
                with open(override_config_path) as f:
                    override_yaml_str = f.read()

                # Parse YAML first to preserve structure.
                # We do NOT expand env vars yet, as per the two-pass strategy.
                override_dict = yaml.safe_load(override_yaml_str) or {}
                logger.debug("loaded override config", keys=list(override_dict.keys()))

                # Deep merge the override onto the base dictionary
                merged_dict = deep_merge_dicts(override_dict, base_dict)
                logger.debug("merged config dict", keys=list(merged_dict.keys()))
            except yaml.YAMLError as e:
                raise InvalidConfigurationError(
                    f"Error parsing override configuration file {override_config_path}: {e}"
                ) from e

        # --- Phase 1: Bootstrap Secrets ---
        # Extract secrets section and expand env vars ONLY in it
        secrets_section = merged_dict.get("secrets")
        if secrets_section:
            providers = expand_env_vars_in_dict(secrets_section.get("providers", {}))
            secrets_section["providers"] = providers
            # Update the merged dict with the expanded providers in the secrets section
            merged_dict["secrets"] = secrets_section

        # Initialize Registry
        providers_config = {}
        if secrets_section:
            providers_config = secrets_section.get("providers", {})

        try:
            registry = SecretRegistry.from_config(providers_config)
        except Exception as e:
            raise InvalidConfigurationError(
                f"Failed to initialize secret registry: {e}"
            ) from e

        # --- Phase 2: Resolution ---
        # 1. Global Env Expansion
        merged_dict = expand_env_vars_in_dict(merged_dict)

        # 2. Resolve secrets in the entire dict
        try:
            merged_dict = resolve_secrets_in_dict(merged_dict, registry)
        except Exception as e:
            raise InvalidConfigurationError(f"Failed to resolve secrets: {e}") from e

        # --- Phase 3: Validation ---
        try:
            final_config = PlanarConfig.model_validate(merged_dict)
            return final_config
        except ValidationError as e:
            raise InvalidConfigurationError(
                f"Configuration validation error: {e}"
            ) from e
