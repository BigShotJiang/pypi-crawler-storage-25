"""Shared enumerations module."""

import enum
import sys
import typing

RUNTIME_VERSION = f"{sys.version_info.major}.{sys.version_info.minor}"


class TargetType(enum.Enum):
    """Enumerations of target types."""

    FUNCTION = "function"
    LAYER = "layer"


class DependencyType(enum.Enum):
    """Enumeration of dependency types, i.e. package managers."""

    PIP = "pip"
    PIPPER = "pipper"
    POETRY = "poetry"
    POETRY_COMMAND = "poetry_command"
    UV = "uv"
    UV_COMMAND = "uv_command"


class DefaultFile(enum.Enum):
    """Enumeration of default files for each dependency type."""

    PIP = "requirements.txt"
    PIPPER = "pipper.json"
    POETRY = "pyproject.toml"
    UV = "pyproject.toml"

    @classmethod
    def from_dependency_type(
        cls,
        dependency_type: typing.Union["DependencyType", str],
    ) -> "DefaultFile":
        """Lookup default file from a dependency type."""
        key = typing.cast(str, getattr(dependency_type, "value", dependency_type))
        return {
            DependencyType.PIP.value: DefaultFile.PIP,
            DependencyType.PIPPER.value: DefaultFile.PIPPER,
            DependencyType.POETRY.value: DefaultFile.POETRY,
            DependencyType.UV.value: DefaultFile.UV,
        }.get(key, DefaultFile.PIP)
