# Demo of markdown features with extensions including Mermaid diagrams

This demo showcases the capabilities of the markdown viewer, including support for various Markdown features and extensions. Below are examples of different Markdown elements and how they are rendered.

## Headers
# H1 Header
## H2 Header
### H3 Header

## Lists
- Unordered list item 1
- Unordered list item 2
  - Nested unordered list item      
1. Ordered list item 1
2. Ordered list item 2
    1. Nested ordered list item

## Links
[Google](https://www.google.com)
[GitHub](https://www.github.com)

## Images
![Sample Image](https://via.placeholder.com/150)

## Code Blocks
```python
def hello_world():
    print("Hello, world!")
``` 
## Tables
| Name   | Age | City       |
|--------|-----|------------|       
| Alice  | 30  | New York   |
| Bob    | 25  | San Francisco |

## Mermaid Diagrams
```mermaid
graph TD
    A[Start] --> B{Is it working?}
    B -- Yes --> C[Great!]
    B -- No --> D[Check the code]
    D --> B         
    C --> E[End]
```

