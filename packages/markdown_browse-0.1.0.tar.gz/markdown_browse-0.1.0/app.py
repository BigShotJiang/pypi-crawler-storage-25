from flask import Flask, render_template_string, send_from_directory, request
import markdown
import os
import re
import argparse

def create_app(folder='.', port=5000):
    app = Flask(__name__)
    
    # Configure Markdown with extensions
    md = markdown.Markdown(extensions=[
        'fenced_code',
        'tables',
        'codehilite',
        'toc',
        'markdown_mermaidjs'
    ])
    
    @app.route('/')
    def index():
        # List .md files in specified directory
        files = [f for f in os.listdir(folder) if f.endswith('.md')]
        html = '''
        <html>
        <head><title>Markdown Viewer</title></head>
        <body>
            <h1>Select a Markdown file:</h1>
            <ul>
            {% for f in files %}
                <li><a href="/{{ f }}">{{ f }}</a></li>
            {% endfor %}
            </ul>
        </body>
        </html>
        '''
        return render_template_string(html, files=files)
    
    @app.route('/<path:filepath>')
    def render_file(filepath):
        full_path = os.path.join(folder, filepath)
        if filepath.endswith('.md'):
            try:
                with open(full_path, 'r') as f:
                    content = f.read()
                html_content = md.convert(content)
                
                # Post-process links to .md files to point to app routes
                html_content = re.sub(r'href="([^"]*\.md)"', r'href="/\1"', html_content)
                
                # Get referer for back link
                referer = request.headers.get('Referer', '/')
                back_link = f'<a href="{referer}">Back</a><br><br>' if referer and referer != request.url else ''
                
                full_html = f'''
                <html>
                <head>
                    <title>{filepath}</title>
                    <script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
                    <script>
                        mermaid.initialize({{ startOnLoad: true }});
                    </script>
                </head>
                <body>
                    {back_link}
                    <div>{html_content}</div>
                </body>
                </html>
                '''
                return render_template_string(full_html)
            except FileNotFoundError:
                return 'File not found', 404
        else:
            # Serve other files (images, etc.)
            try:
                return send_from_directory(folder, filepath)
            except FileNotFoundError:
                return 'File not found', 404
    
    return app

def main():
    parser = argparse.ArgumentParser(description='Markdown Viewer Flask App')
    parser.add_argument('--port', type=int, default=5000, help='Port to run the server on (default: 5000)')
    parser.add_argument('--folder', type=str, default='.', help='Folder to serve Markdown files from (default: current directory)')
    
    args = parser.parse_args()
    
    app = create_app(folder=args.folder, port=args.port)
    app.run(debug=True, port=args.port)

if __name__ == '__main__':
    main()