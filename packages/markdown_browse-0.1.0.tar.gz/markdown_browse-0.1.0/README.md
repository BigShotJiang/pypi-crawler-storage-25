# Markdown Viewer

A simple Flask app to render Markdown files with Mermaid support. It allows browsing and viewing .md files in a directory, with support for relative links between Markdown files and proper image rendering.

## Features

- Lists all .md files in the specified directory
- Renders Markdown with GitHub-style extensions (fenced code, tables, code highlighting, TOC)
- Mermaid diagram support with client-side rendering
- Follows relative links to other .md files
- Provides back links when navigating between files
- Serves images and other assets correctly
- Configurable port and folder via command-line arguments
- Installable via PyPI

## Installation

### From PyPI (once published)

```bash
pip install markdown-viewer
```

### From Source

1. Clone the repository
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

### As a Script (after PyPI installation)

```bash
markdown-viewer --port 8080 --folder /path/to/markdown/files
```

### From Source

```bash
python app.py --port 8080 --folder /path/to/markdown/files
```

### Options

- `--port PORT`: Port to run the server on (default: 5000)
- `--folder FOLDER`: Folder to serve Markdown files from (default: current directory)

### Examples

Run on default port 5000, current directory:
```bash
markdown-viewer
```

Run on port 3000, specific folder:
```bash
markdown-viewer --port 3000 --folder ./docs
```

Then visit `http://127.0.0.1:PORT/` in your browser.

## Publishing to PyPI

This project uses Hatch for packaging. To build and publish:

1. Install Hatch: `pip install hatch`
2. Build: `hatch build`
3. Publish: `hatch publish` (requires PyPI credentials)

## Dependencies

- Flask: Web framework
- Markdown: Markdown parsing
- pymdown-extensions: Additional Markdown extensions including Mermaid support