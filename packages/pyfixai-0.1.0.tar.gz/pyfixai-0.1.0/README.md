# Pyfixai 🚀

**Pyfixai** is an intelligent Python debugging tool that automatically detects, analyzes, and fixes errors in your code by running it iteratively and applying safe corrections.

Instead of manually debugging errors one by one, pyfixai does it for you — turning broken code into working code with minimal effort.

---

## ✨ Features

* 🔁 **Automatic Debugging Loop**
  Runs your code, detects errors, fixes them, and retries until it works.

* 🧠 **Smart Error Detection**
  Handles common Python errors like:

  * NameError
  * TypeError
  * IndexError
  * KeyError
  * FileNotFoundError
  * RecursionError
  * And more...

* 🛡️ **Safe Fixing Mechanism**
  Avoids destructive changes and prevents infinite loops.

* 🔧 **Self-Healing Fixes**
  Can fix issues introduced during previous attempts.

* ⚡ **CLI Tool**
  Simple command-line usage for fast debugging.

---

## 🧠 How It Works

pyfixai follows a smart debugging cycle:

```text
Run → Detect Error → Analyze → Fix → Repeat
```

### Step-by-step process:

1. Executes your Python file
2. Captures errors and traceback
3. Analyzes the failure
4. Applies targeted fixes
5. Re-runs the code
6. Repeats until the code runs successfully or max retries reached

---

## 📦 Installation

Install directly from PyPI:

```bash
pip install pyfixai
```

---

## 🚀 Usage

Run pyfixai on any Python file:

```bash
pyfixai run your_script.py
```

---

## 🧪 Example

### ❌ Input (buggy code)

```python
def test():
    return "10" + 5
```

### ▶ Run

```bash
pyfixai run test.py
```

### ✅ Output (fixed automatically)

```python
def test():
    return "10" + str(5)
```

---

## 📁 Project Structure

```text
pyfixai/
│
├── core.py      # Main execution engine
├── fixer.py     # Smart fixing logic
├── cli.py       # Command-line interface
└── utils.py     # Helper functions
```

---

## 🔮 Future Improvements

* AST-based code fixing (safer modifications)
* AI-assisted debugging (LLM integration)
* VS Code extension
* Smarter output validation

---

## 🤝 Contributing

Contributions are welcome!
Feel free to improve the fixer engine, add new rules, or optimize performance.

---

## 📜 License

This project is licensed under the MIT License.

---

## 👨‍💻 Author

**Akhila Bodduri**

**Yashwant **

---

## ⭐ Support

If you found this useful, consider giving it a ⭐ on GitHub!
