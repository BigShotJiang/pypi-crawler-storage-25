"""Official IP-Atlas API client — IP geolocation, ASN, VPN detection."""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

import requests

__version__ = "0.1.0"
__all__ = ["IPAtlas", "IPAtlasError"]

_DEFAULT_BASE_URL = "https://api.ip-atlas.io"


class IPAtlasError(Exception):
    """Raised when the IP-Atlas API returns a non-2xx response."""

    def __init__(self, message: str, status_code: int, body: object) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body


class IPAtlas:
    """Client for the IP-Atlas API.

    Args:
        api_key: Optional API key sent as the X-API-Key header.
        base_url: Base URL for the API (default: https://api.ip-atlas.io).
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = _DEFAULT_BASE_URL,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self._session = requests.Session()
        if api_key:
            self._session.headers.update({"X-API-Key": api_key})

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        url = f"{self.base_url}{path}"
        response = self._session.request(method, url, **kwargs)
        if not response.ok:
            try:
                body = response.json()
            except Exception:
                body = response.text
            raise IPAtlasError(
                f"IP-Atlas API error: {response.status_code} {response.reason}",
                response.status_code,
                body,
            )
        return response.json()

    def lookup(self, ip: str) -> Dict[str, Any]:
        """Look up geolocation data for a single IP address.

        Args:
            ip: IPv4 or IPv6 address to look up.

        Returns:
            Dictionary containing geolocation, ASN, and threat fields.
        """
        return self._request("GET", f"/json/{ip}")

    def lookup_self(self) -> Dict[str, Any]:
        """Look up geolocation data for the caller's own IP address.

        Returns:
            Dictionary containing geolocation, ASN, and threat fields.
        """
        return self._request("GET", "/json")

    def lookup_batch(self, ips: List[str]) -> Dict[str, List[Dict[str, Any]]]:
        """Look up multiple IP addresses in a single request (max 100).

        Args:
            ips: List of IPv4 or IPv6 addresses (up to 100).

        Returns:
            A dict ``{"results": [...]}`` where each element is in the same
            order as the input list. Each element is either a successful
            lookup dict (``{"ip": ..., "country": ..., ...}``) or an error
            dict (``{"ip": ..., "error": "invalid IP address"}``). Request-
            level errors such as authentication or quota failures raise
            IPAtlasError and are not present in the list.
        """
        if not ips:
            raise ValueError("lookup_batch: ips must not be empty")
        if len(ips) > 100:
            raise ValueError("lookup_batch: maximum 100 IPs per request")
        return self._request("POST", "/v1/batch", json={"ips": ips})

    def account(self) -> Dict[str, Any]:
        """Fetch the account metadata (plan, key prefix, usage, quotas) for the
        API key bound to this client. Raises IPAtlasError if no key is set."""
        return self._request("GET", "/v1/account")

    def rotate_key(self) -> Dict[str, str]:
        """Revoke the current API key and issue a replacement with the same
        plan and billing linkage. Returns ``{"api_key": "...", "key_prefix": "..."}``.
        The new plaintext key is only returned once — save it."""
        return self._request("POST", "/v1/account/rotate")
