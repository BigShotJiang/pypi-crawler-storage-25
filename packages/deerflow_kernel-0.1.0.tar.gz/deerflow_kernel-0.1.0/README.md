# deerflow-kernel

This repository is an extracted standalone kernel package generated from the
open-source DeerFlow repository.

- Source repository: /home/deer-flow
- Source commit: 711ab3086d0591351b456dc867cac28e4d698101

## Contents

- deerflow/: harness runtime, agents, tools, sandbox, memory, MCP, skills
- langgraph.json: LangGraph graph and checkpointer entrypoints
- pyproject.toml: standalone package metadata for deerflow-kernel

## Local build

```bash
uv build
```

## Quick validation

```bash
uv run deerflow-kernel check
```

## Regenerating this repository

This repository is intended to be regenerated from the main DeerFlow monorepo
using scripts/export-deerflow-kernel.sh in the source repository.
