"""SLSA v1.0 provenance generation and verification.

Generates in-toto Statement v1 envelopes with SLSA provenance predicates
that wrap CertiSigma attestations. This bridges Census's forensic integrity
model with the supply chain security ecosystem (SLSA, in-toto, cosign).

No new dependencies — the in-toto Statement and SLSA predicate are plain
JSON generated with stdlib.
"""

from __future__ import annotations

import base64
import json
import logging
import os
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .manifest import Manifest

logger = logging.getLogger(__name__)

STATEMENT_TYPE = "https://in-toto.io/Statement/v1"
PREDICATE_TYPE = "https://slsa.dev/provenance/v1"
BUILD_TYPE = "https://certisigma.ch/census/scan/v1"
DEFAULT_BUILDER_ID = "https://certisigma.ch/census"

MAX_PROVENANCE_FILE_BYTES = 10 * 1024 * 1024  # 10 MB
MAX_MATERIALS = 10_000


@dataclass
class CIEnvironment:
    """Builder metadata auto-detected from CI environment variables."""

    ci_system: str
    repo_url: str = ""
    commit_sha: str = ""
    workflow: str = ""
    runner_id: str = ""
    invocation_id: str = ""
    invocation_url: str = ""


@dataclass
class ProvenanceStatement:
    """In-toto Statement v1 with SLSA provenance v1 predicate."""

    subject: list[dict[str, Any]]
    predicate: dict[str, Any]
    predicate_type: str = PREDICATE_TYPE
    statement_type: str = STATEMENT_TYPE

    def to_dict(self) -> dict[str, Any]:
        return {
            "_type": self.statement_type,
            "subject": self.subject,
            "predicateType": self.predicate_type,
            "predicate": self.predicate,
        }

    def to_json(self, *, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, default=str)


@dataclass
class ProvenanceVerifyResult:
    """Outcome of verifying a provenance statement."""

    total_subjects: int = 0
    verified: int = 0
    unverified: int = 0
    errors: list[str] = field(default_factory=list)
    attestation_details: list[dict[str, Any]] = field(default_factory=list)

    @property
    def success(self) -> bool:
        return self.unverified == 0 and not self.errors


def detect_ci_environment() -> CIEnvironment | None:
    """Auto-detect CI environment from standard environment variables.

    Returns ``None`` when not running in a known CI system.
    """
    if os.environ.get("GITHUB_ACTIONS") == "true":
        server = os.environ.get("GITHUB_SERVER_URL", "https://github.com")
        repo = os.environ.get("GITHUB_REPOSITORY", "")
        run_id = os.environ.get("GITHUB_RUN_ID", "")
        return CIEnvironment(
            ci_system="github-actions",
            repo_url=f"{server}/{repo}" if repo else "",
            commit_sha=os.environ.get("GITHUB_SHA", ""),
            workflow=os.environ.get("GITHUB_WORKFLOW", ""),
            runner_id=os.environ.get("RUNNER_NAME", ""),
            invocation_id=run_id,
            invocation_url=f"{server}/{repo}/actions/runs/{run_id}" if repo and run_id else "",
        )

    if os.environ.get("GITLAB_CI") == "true":
        return CIEnvironment(
            ci_system="gitlab-ci",
            repo_url=os.environ.get("CI_PROJECT_URL", ""),
            commit_sha=os.environ.get("CI_COMMIT_SHA", ""),
            workflow=os.environ.get("CI_PIPELINE_NAME", ""),
            runner_id=os.environ.get("CI_RUNNER_ID", ""),
            invocation_id=os.environ.get("CI_PIPELINE_ID", ""),
            invocation_url=os.environ.get("CI_PIPELINE_URL", ""),
        )

    if os.environ.get("JENKINS_URL"):
        return CIEnvironment(
            ci_system="jenkins",
            repo_url=os.environ.get("GIT_URL", ""),
            commit_sha=os.environ.get("GIT_COMMIT", ""),
            workflow=os.environ.get("JOB_NAME", ""),
            runner_id=os.environ.get("NODE_NAME", ""),
            invocation_id=os.environ.get("BUILD_ID", ""),
            invocation_url=os.environ.get("BUILD_URL", ""),
        )

    if os.environ.get("CI") == "true":
        return CIEnvironment(
            ci_system="generic-ci",
            commit_sha=os.environ.get("CI_COMMIT_SHA", ""),
        )

    return None


def generate_provenance(
    manifest: Manifest,
    *,
    builder_id: str | None = None,
    source: str | None = None,
    commit_sha: str | None = None,
    started_on: str | None = None,
    finished_on: str | None = None,
    attestation_ids: list[str] | None = None,
    sbom_doc: object | None = None,
    ci_env: CIEnvironment | None = None,
    embed_materials: bool = False,
) -> ProvenanceStatement:
    """Generate a SLSA v1.0 provenance statement for a manifest.

    Parameters
    ----------
    manifest:
        The Census manifest to generate provenance for.
    builder_id:
        Builder identity URI (default: ``https://certisigma.ch/census``).
    source:
        Source label for the scan.
    commit_sha:
        Git commit SHA (full 40 chars preferred).
    started_on:
        ISO-8601 timestamp of scan start.
    finished_on:
        ISO-8601 timestamp of scan completion.
    attestation_ids:
        CertiSigma attestation IDs from batch_attest.
    sbom_doc:
        Optional ``SBOMDocument`` to include as resolvedDependencies.
    ci_env:
        CI environment metadata (auto-detected if ``None``).
    embed_materials:
        If ``True``, include individual file digests as resolvedDependencies
        (capped at ``MAX_MATERIALS``). Default: subject-only.
    """
    from . import __version__

    if not manifest.entries:
        raise ValueError("Cannot generate provenance for an empty manifest (no subjects)")

    if ci_env is None:
        ci_env = detect_ci_environment()

    effective_builder = builder_id or DEFAULT_BUILDER_ID
    effective_commit = commit_sha or (ci_env.commit_sha if ci_env else "")

    now_iso = datetime.now(timezone.utc).isoformat()
    effective_started = started_on or now_iso
    effective_finished = finished_on or now_iso

    subject = _build_subject(manifest)
    resolved_deps = _build_resolved_dependencies(
        manifest, sbom_doc=sbom_doc, embed_materials=embed_materials,
        commit_sha=effective_commit, ci_env=ci_env,
    )
    external_params: dict[str, Any] = {}
    if source:
        external_params["source"] = source
    if manifest.root_dir:
        external_params["root_dir"] = manifest.root_dir

    internal_params: dict[str, Any] = {
        "census_version": __version__,
        "slsa_build_level": 1,
    }

    metadata: dict[str, Any] = {
        "startedOn": effective_started,
        "finishedOn": effective_finished,
    }
    if ci_env and ci_env.invocation_id:
        metadata["invocationId"] = ci_env.invocation_id

    byproducts: list[dict[str, Any]] = []
    if attestation_ids:
        payload = json.dumps(attestation_ids, default=str).encode("utf-8")
        byproducts.append({
            "name": "certisigma-attestation-ids",
            "content": base64.b64encode(payload).decode("ascii"),
            "mediaType": "application/json",
        })

    builder: dict[str, Any] = {
        "id": effective_builder,
        "version": {"census": __version__},
    }

    predicate = {
        "buildDefinition": {
            "buildType": BUILD_TYPE,
            "externalParameters": external_params,
            "internalParameters": internal_params,
            "resolvedDependencies": resolved_deps,
        },
        "runDetails": {
            "builder": builder,
            "metadata": metadata,
            "byproducts": byproducts,
        },
    }

    return ProvenanceStatement(subject=subject, predicate=predicate)


def _build_subject(manifest: Manifest) -> list[dict[str, Any]]:
    """Build the in-toto subject from a manifest."""
    entries = manifest.entries
    digests: list[dict[str, Any]] = []
    for h, entry in entries.items():
        digests.append({
            "name": entry.path,
            "digest": {"sha256": h},
        })
    return digests


def _build_resolved_dependencies(
    manifest: Manifest,
    *,
    sbom_doc: object | None = None,
    embed_materials: bool = False,
    commit_sha: str = "",
    ci_env: CIEnvironment | None = None,
) -> list[dict[str, Any]]:
    """Build the resolvedDependencies array."""
    deps: list[dict[str, Any]] = []

    if ci_env and ci_env.repo_url:
        vcs_dep: dict[str, Any] = {
            "uri": ci_env.repo_url,
        }
        if commit_sha:
            vcs_dep["digest"] = {"gitCommit": commit_sha}
        deps.append(vcs_dep)
    elif commit_sha:
        deps.append({
            "digest": {"gitCommit": commit_sha},
        })

    if embed_materials:
        count = 0
        for h, entry in manifest.entries.items():
            if count >= MAX_MATERIALS:
                logger.warning(
                    "Materials capped at %d entries (manifest has %d)",
                    MAX_MATERIALS, manifest.total,
                )
                break
            deps.append({
                "uri": f"file:{entry.path}",
                "digest": {"sha256": h},
            })
            count += 1

    if sbom_doc is not None:
        try:
            components = getattr(sbom_doc, "components", [])
            for comp in components:
                comp_hash = getattr(comp, "hash_hex", None) or ""
                if comp_hash and re.fullmatch(r"[0-9a-f]{64}", comp_hash):
                    dep: dict[str, Any] = {
                        "name": getattr(comp, "name", ""),
                        "digest": {"sha256": comp_hash},
                    }
                    purl = getattr(comp, "purl", None)
                    if purl:
                        dep["uri"] = purl
                    deps.append(dep)
        except Exception as exc:
            logger.warning("Cannot extract SBOM components: %s", exc)

    return deps


def verify_provenance(
    statement: ProvenanceStatement,
    client: Any,
    *,
    show_progress: bool = False,
) -> ProvenanceVerifyResult:
    """Verify all subject digests against the CertiSigma registry.

    Parameters
    ----------
    statement:
        The provenance statement to verify.
    client:
        A ``CertiSigmaClient`` instance.
    show_progress:
        Show a progress bar during verification.
    """
    from .retry import retry_api_call

    result = ProvenanceVerifyResult(total_subjects=len(statement.subject))
    hashes = []
    for subj in statement.subject:
        digest = subj.get("digest", {})
        sha = digest.get("sha256", "")
        if sha and re.fullmatch(r"[0-9a-f]{64}", sha):
            hashes.append(sha)
        else:
            result.errors.append(f"Invalid digest in subject: {subj.get('name', '?')}")

    if not hashes:
        return result

    BATCH_SIZE = 100
    verified_set: dict[str, dict[str, Any]] = {}
    for i in range(0, len(hashes), BATCH_SIZE):
        batch = hashes[i:i + BATCH_SIZE]
        try:
            resp = retry_api_call(client.batch_verify, batch)
            for item in resp.results:
                h = item.get("hash_hex", item.get("hash", ""))
                exists = item.get("exists", False)
                detail = {"hash_hex": h, "verified": exists}
                if exists:
                    detail["attestation_id"] = item.get("id", item.get("attestation_id", ""))
                verified_set[h] = detail
        except Exception as exc:
            result.errors.append(f"Batch verify failed: {exc}")

    for h in hashes:
        info = verified_set.get(h)
        if info and info.get("verified"):
            result.verified += 1
            result.attestation_details.append(info)
        else:
            result.unverified += 1

    return result


def write_provenance(
    statement: ProvenanceStatement,
    path: Path,
    *,
    format: str = "json",
) -> None:
    """Write a provenance statement to disk.

    Parameters
    ----------
    format:
        ``"json"`` for a single JSON document, ``"intoto-jsonl"`` for
        newline-delimited JSON (one statement per line).
    """
    data = statement.to_dict()
    if format == "intoto-jsonl":
        line = json.dumps(data, default=str)
        path.write_text(line + "\n", encoding="utf-8")
    else:
        path.write_text(json.dumps(data, indent=2, default=str) + "\n", encoding="utf-8")


def load_provenance(path: Path) -> ProvenanceStatement:
    """Load and validate a provenance statement from disk.

    Raises ``ValueError`` on schema violations.
    Raises ``OSError`` on I/O errors.
    """
    size = path.stat().st_size
    if size > MAX_PROVENANCE_FILE_BYTES:
        raise ValueError(
            f"Provenance file too large: {size:,} bytes "
            f"(max {MAX_PROVENANCE_FILE_BYTES:,})"
        )

    text = path.read_text(encoding="utf-8").strip()
    if not text:
        raise ValueError("Empty provenance file")

    data = json.loads(text)
    return _validate_statement(data)


def _validate_statement(data: object) -> ProvenanceStatement:
    """Validate a parsed JSON object against the in-toto Statement v1 schema."""
    if not isinstance(data, dict):
        raise ValueError("Provenance statement must be a JSON object")

    stmt_type = data.get("_type", "")
    if stmt_type != STATEMENT_TYPE:
        raise ValueError(f"Unexpected _type: {stmt_type!r} (expected {STATEMENT_TYPE!r})")

    pred_type = data.get("predicateType", "")
    if pred_type != PREDICATE_TYPE:
        raise ValueError(
            f"Unexpected predicateType: {pred_type!r} (expected {PREDICATE_TYPE!r})"
        )

    subject = data.get("subject")
    if not isinstance(subject, list) or not subject:
        raise ValueError("subject must be a non-empty array")

    for i, subj in enumerate(subject):
        if not isinstance(subj, dict):
            raise ValueError(f"subject[{i}] must be an object")
        digest = subj.get("digest")
        if not isinstance(digest, dict):
            raise ValueError(f"subject[{i}].digest must be an object")
        sha = digest.get("sha256", "")
        if sha and not re.fullmatch(r"[0-9a-f]{64}", sha):
            raise ValueError(f"subject[{i}].digest.sha256 is not a valid SHA-256 hex string")

    predicate = data.get("predicate")
    if not isinstance(predicate, dict):
        raise ValueError("predicate must be an object")

    build_def = predicate.get("buildDefinition")
    if not isinstance(build_def, dict):
        raise ValueError("predicate.buildDefinition must be an object")
    if "buildType" not in build_def:
        raise ValueError("predicate.buildDefinition.buildType is required")

    run_details = predicate.get("runDetails")
    if not isinstance(run_details, dict):
        raise ValueError("predicate.runDetails must be an object")
    builder = run_details.get("builder")
    if not isinstance(builder, dict) or "id" not in builder:
        raise ValueError("predicate.runDetails.builder.id is required")

    return ProvenanceStatement(
        subject=subject,
        predicate=predicate,
        predicate_type=pred_type,
        statement_type=stmt_type,
    )
