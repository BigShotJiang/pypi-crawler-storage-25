"""Forensic timeline — queryable index over the tamper-evident audit log.

Census's audit log (``audit.jsonl``) is the authoritative, hash-chained
record of every operation.  This module builds a **derived** SQLite
index that enables:

- Time-range and field-level queries (action, path, hash)
- Temporal aggregation (busiest windows, anomaly detection)
- Export to standard DFIR formats (TSK body file, Plaso l2tcsv, CASE/UCO)

The timeline DB is always rebuildable from the audit log — it is never
the source of truth.

Default location:
    ~/.local/share/certisigma-census/timeline/
"""

from __future__ import annotations

import csv
import html
import json
import logging
import os
import re
import sqlite3
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from . import __version__
from .audit_log import AuditEntry, iter_entries

logger = logging.getLogger(__name__)

# ── Constants ────────────────────────────────────────────────────────

MAX_TIMELINE_DB_SIZE = 500 * 1024 * 1024  # 500 MB
MAX_EVENTS_PER_BUILD = 10_000_000
MAX_QUERY_LIMIT = 100_000
MAX_EXPORT_EVENTS = 1_000_000
MAX_AUDIT_LOG_SIZE = 500 * 1024 * 1024  # 500 MB pre-check
SCHEMA_VERSION = 1

AGGREGATION_WINDOWS = {"1m": 60, "5m": 300, "1h": 3600, "1d": 86400}

_CENSUS_UUID_NS = uuid.UUID("a3e8f7c1-5b2d-4e9a-8f3c-1a2b3c4d5e6f")

_CATEGORY_MAP: dict[str, str] = {
    "scan": "scan",
    "compare": "compare",
    "integrity": "integrity",
    "verify": "verify",
    "alert": "alert",
    "velocity_alert": "alert",
    "annotate": "admin",
    "share": "admin",
    "tag": "admin",
    "key_rotate": "admin",
    "derived_list": "admin",
    "merge": "admin",
    "timeline": "admin",
    "watch": "scan",
    "export": "admin",
    "snapshot": "admin",
    "seal": "admin",
    "sbom": "scan",
    "provenance": "admin",
    "git_hook": "scan",
    "compliance": "admin",
    "ai_policy": "admin",
}

_RELATIVE_TIME_RE = re.compile(r"^-(\d+)([smhd])$")

_CONTROL_CHAR_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]")

_TIMELINE_SCHEMA = """\
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS events (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp       TEXT    NOT NULL,
    unix_ts         REAL    NOT NULL,
    action          TEXT    NOT NULL,
    category        TEXT    NOT NULL,
    path            TEXT    NOT NULL DEFAULT '',
    hash_hex        TEXT    NOT NULL DEFAULT '',
    attestation_id  TEXT    NOT NULL DEFAULT '',
    detail          TEXT    NOT NULL DEFAULT '',
    source          TEXT    NOT NULL DEFAULT '',
    audit_entry_hash TEXT   NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_events_ts ON events(unix_ts);
CREATE INDEX IF NOT EXISTS idx_events_action ON events(action);
CREATE INDEX IF NOT EXISTS idx_events_path ON events(path);
CREATE INDEX IF NOT EXISTS idx_events_hash ON events(hash_hex);
CREATE INDEX IF NOT EXISTS idx_events_category ON events(category);
"""

# ── Dataclasses ──────────────────────────────────────────────────────


@dataclass
class TimelineEvent:
    """Single event in the forensic timeline."""

    id: int = 0
    timestamp: str = ""
    unix_ts: float = 0.0
    action: str = ""
    category: str = ""
    path: str = ""
    hash_hex: str = ""
    attestation_id: str = ""
    detail: str = ""
    source: str = ""
    audit_entry_hash: str = ""


@dataclass
class TimelineQuery:
    """Filter parameters for timeline queries."""

    start: Optional[float] = None
    end: Optional[float] = None
    actions: Optional[list[str]] = None
    path_pattern: Optional[str] = None
    hash_hex: Optional[str] = None
    source: Optional[str] = None
    attested_only: bool = False
    unattested_only: bool = False
    around: Optional[float] = None
    window_seconds: int = 300
    limit: int = 10000
    offset: int = 0


@dataclass
class TimelineStats:
    """Aggregation result for timeline analysis."""

    total_events: int = 0
    time_range: Optional[tuple[str, str]] = None
    events_by_category: dict[str, int] = field(default_factory=dict)
    events_by_action: dict[str, int] = field(default_factory=dict)
    busiest_window: dict[str, Any] = field(default_factory=dict)
    sources: list[str] = field(default_factory=list)


# ── Helpers ──────────────────────────────────────────────────────────


def _default_timeline_dir() -> Path:
    return Path.home() / ".local" / "share" / "certisigma-census" / "timeline"


def _resolve_timeline_dir(override: str | Path | None = None) -> Path:
    if override:
        return Path(override).resolve()
    from .config import load_config

    cfg = load_config()
    configured = cfg.get("timeline_dir", "")
    if configured:
        return Path(configured).resolve()
    return _default_timeline_dir()


def _sanitize_path(value: str) -> str:
    """Strip control characters and pipe chars for export safety."""
    cleaned = _CONTROL_CHAR_RE.sub("", value)
    cleaned = cleaned.replace("|", "_")
    if len(cleaned) > 4096:
        return cleaned[:4096]
    return cleaned


def _category_for(action: str) -> str:
    """Derive top-level category from an action name."""
    if not action:
        return "admin"
    base = action.split(".")[0].split("_")[0]
    return _CATEGORY_MAP.get(base, _CATEGORY_MAP.get(action, "admin"))


def parse_relative_time(spec: str) -> float:
    """Parse a relative time specification like ``-1h`` or ``-7d``.

    Returns a Unix timestamp (seconds since epoch).
    Raises ``ValueError`` on invalid format.
    """
    m = _RELATIVE_TIME_RE.match(spec)
    if not m:
        raise ValueError(f"Invalid relative time: {spec!r} (use -Ns, -Nm, -Nh, -Nd)")
    amount = int(m.group(1))
    unit = m.group(2)
    multiplier = {"s": 1, "m": 60, "h": 3600, "d": 86400}[unit]
    return time.time() - (amount * multiplier)


def parse_time_spec(spec: str) -> float:
    """Parse an ISO-8601 timestamp or a relative time spec.

    Returns a Unix timestamp.
    """
    if spec.startswith("-"):
        return parse_relative_time(spec)
    for fmt in ("%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
        try:
            dt = datetime.strptime(spec, fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.timestamp()
        except ValueError:
            continue
    raise ValueError(f"Cannot parse time: {spec!r}")


def _iso_to_unix(ts: str) -> float:
    """Convert an ISO-8601 timestamp string to Unix seconds."""
    for fmt in ("%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
        try:
            dt = datetime.strptime(ts, fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.timestamp()
        except ValueError:
            continue
    return 0.0


def _extract_detail(entry: AuditEntry) -> str:
    """Build a human-readable detail string from an audit entry."""
    parts: list[str] = [entry.action]
    p = entry.params
    if p.get("source"):
        parts.append(f"source={p['source']}")
    if p.get("directory"):
        parts.append(f"dir={p['directory']}")
    r = entry.result
    if r.get("total_files"):
        parts.append(f"files={r['total_files']}")
    if r.get("attested"):
        parts.append(f"attested={r['attested']}")
    if r.get("matched"):
        parts.append(f"matched={r['matched']}")
    if r.get("status"):
        parts.append(f"status={r['status']}")
    return " | ".join(parts)


def _extract_events(entry: AuditEntry) -> list[TimelineEvent]:
    """Convert a single AuditEntry into one or more TimelineEvents."""
    unix_ts = _iso_to_unix(entry.timestamp)
    base = TimelineEvent(
        timestamp=entry.timestamp,
        unix_ts=unix_ts,
        action=entry.action,
        category=_category_for(entry.action),
        path=entry.params.get("directory", entry.params.get("path", "")),
        hash_hex=entry.params.get("hash_hex", entry.result.get("hash_hex", "")),
        attestation_id=str(entry.result.get("attestation_id", "")),
        detail=_extract_detail(entry),
        source=entry.params.get("source", entry.params.get("manifest", "")),
        audit_entry_hash=entry.entry_hash,
    )
    return [base]


# ── Timeline DB operations ───────────────────────────────────────────


def _open_timeline_db(timeline_dir: Path, *, readonly: bool = False) -> sqlite3.Connection:
    """Open (or create) the timeline SQLite database."""
    db_path = timeline_dir / "timeline.db"

    if readonly:
        if not db_path.exists():
            raise FileNotFoundError(f"Timeline database not found: {db_path}")
    else:
        timeline_dir.mkdir(parents=True, exist_ok=True)

    uri = f"file:{db_path}"
    if readonly:
        uri += "?mode=ro"
        conn = sqlite3.connect(uri, uri=True)
    else:
        conn = sqlite3.connect(str(db_path))
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")

    conn.row_factory = sqlite3.Row
    return conn


def _init_schema(conn: sqlite3.Connection) -> None:
    """Create tables and indices if they don't exist."""
    conn.executescript(_TIMELINE_SCHEMA)
    existing = {
        r[0]
        for r in conn.execute("SELECT key FROM meta").fetchall()
    }
    if "schema_version" not in existing:
        conn.execute(
            "INSERT INTO meta (key, value) VALUES (?, ?)",
            ("schema_version", str(SCHEMA_VERSION)),
        )
    if "census_version" not in existing:
        conn.execute(
            "INSERT INTO meta (key, value) VALUES (?, ?)",
            ("census_version", __version__),
        )
    conn.commit()


def _get_last_entry_hash(conn: sqlite3.Connection) -> str:
    """Get the audit_entry_hash of the last ingested event (for incremental builds)."""
    row = conn.execute(
        "SELECT audit_entry_hash FROM events ORDER BY id DESC LIMIT 1"
    ).fetchone()
    return row[0] if row else ""


def _set_db_permissions(timeline_dir: Path) -> None:
    db_path = timeline_dir / "timeline.db"
    try:
        db_path.chmod(0o600)
    except OSError:
        pass


def build_timeline(
    audit_log_path: str | Path | None = None,
    manifest_path: str | Path | None = None,
    timeline_dir: str | Path | None = None,
    *,
    rebuild: bool = False,
) -> TimelineStats:
    """Build or update the timeline database from the audit log.

    Args:
        audit_log_path: Override audit log location.
        manifest_path: Manifest for event enrichment (paths, hashes).
        timeline_dir: Override timeline storage directory.
        rebuild: Drop existing timeline and rebuild from scratch.

    Returns:
        TimelineStats summary of the built timeline.
    """
    from .audit_log import _resolve_log_path

    resolved_log = _resolve_log_path(audit_log_path)
    tdir = _resolve_timeline_dir(timeline_dir)

    if resolved_log.exists():
        log_size = resolved_log.stat().st_size
        if log_size > MAX_AUDIT_LOG_SIZE:
            raise ValueError(
                f"Audit log too large ({log_size:,} bytes, max {MAX_AUDIT_LOG_SIZE:,}). "
                "Consider rotating the audit log."
            )

    manifest_entries: dict[str, Any] = {}
    if manifest_path:
        try:
            from .manifest import Manifest

            mp = Path(manifest_path)
            if mp.exists():
                with Manifest.load(mp) as m:
                    for e in m.iter_entries():
                        manifest_entries[e.hash_hex] = e
        except Exception as exc:
            logger.warning("Cannot load manifest for enrichment: %s", exc)

    conn = _open_timeline_db(tdir)
    try:
        _init_schema(conn)

        if rebuild:
            conn.execute("DELETE FROM events")
            conn.execute(
                "INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
                ("last_rebuild", time.strftime("%Y-%m-%dT%H:%M:%S%z")),
            )
            conn.commit()
            last_hash = ""
        else:
            last_hash = _get_last_entry_hash(conn)

        skip = bool(last_hash)
        ingested = 0

        for entry in iter_entries(audit_log_path):
            if skip:
                if entry.entry_hash == last_hash:
                    skip = False
                continue

            events = _extract_events(entry)
            for ev in events:
                if ev.hash_hex and ev.hash_hex in manifest_entries:
                    me = manifest_entries[ev.hash_hex]
                    if not ev.path:
                        ev.path = me.path
                    if me.attestation_id and not ev.attestation_id:
                        ev.attestation_id = str(me.attestation_id)

                conn.execute(
                    "INSERT INTO events "
                    "(timestamp, unix_ts, action, category, path, hash_hex, "
                    "attestation_id, detail, source, audit_entry_hash) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        ev.timestamp,
                        ev.unix_ts,
                        ev.action,
                        ev.category,
                        ev.path,
                        ev.hash_hex,
                        ev.attestation_id,
                        ev.detail,
                        ev.source,
                        ev.audit_entry_hash,
                    ),
                )
                ingested += 1

                if ingested >= MAX_EVENTS_PER_BUILD:
                    logger.warning(
                        "Event limit reached (%d). Stopping ingestion.",
                        MAX_EVENTS_PER_BUILD,
                    )
                    break

            if ingested >= MAX_EVENTS_PER_BUILD:
                break

            if ingested > 0 and ingested % 10000 == 0:
                conn.commit()

        conn.execute(
            "INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)",
            ("census_version", __version__),
        )
        conn.commit()
        _set_db_permissions(tdir)

        return _compute_stats(conn)
    finally:
        conn.close()


# ── Query ────────────────────────────────────────────────────────────


def query_timeline(
    timeline_dir: str | Path | None = None,
    query: Optional[TimelineQuery] = None,
) -> list[TimelineEvent]:
    """Query the timeline database with filters.

    Returns a list of matching TimelineEvent objects.
    """
    if query is None:
        query = TimelineQuery()

    effective_limit = min(query.limit, MAX_QUERY_LIMIT)

    tdir = _resolve_timeline_dir(timeline_dir)
    conn = _open_timeline_db(tdir, readonly=True)
    try:
        sql = "SELECT * FROM events WHERE 1=1"
        params: list[Any] = []

        start = query.start
        end = query.end
        if query.around is not None:
            half = query.window_seconds / 2.0
            start = query.around - half
            end = query.around + half

        if start is not None:
            sql += " AND unix_ts >= ?"
            params.append(start)
        if end is not None:
            sql += " AND unix_ts <= ?"
            params.append(end)

        if query.actions:
            action_clauses = []
            for a in query.actions:
                action_clauses.append("action LIKE ?")
                params.append(a + "%")
            sql += " AND (" + " OR ".join(action_clauses) + ")"

        if query.path_pattern:
            like_pat = query.path_pattern.replace("*", "%").replace("?", "_")
            sql += " AND path LIKE ?"
            params.append(like_pat)

        if query.hash_hex:
            sql += " AND hash_hex = ?"
            params.append(query.hash_hex)

        if query.source:
            sql += " AND source = ?"
            params.append(query.source)

        if query.attested_only:
            sql += " AND attestation_id != ''"
        elif query.unattested_only:
            sql += " AND attestation_id = ''"

        sql += " ORDER BY unix_ts ASC"
        sql += " LIMIT ? OFFSET ?"
        params.extend([effective_limit, query.offset])

        rows = conn.execute(sql, params).fetchall()
        return [
            TimelineEvent(
                id=r["id"],
                timestamp=r["timestamp"],
                unix_ts=r["unix_ts"],
                action=r["action"],
                category=r["category"],
                path=r["path"],
                hash_hex=r["hash_hex"],
                attestation_id=r["attestation_id"],
                detail=r["detail"],
                source=r["source"],
                audit_entry_hash=r["audit_entry_hash"],
            )
            for r in rows
        ]
    finally:
        conn.close()


# ── Aggregation ──────────────────────────────────────────────────────


def aggregate_timeline(
    timeline_dir: str | Path | None = None,
    window_seconds: int = 3600,
    *,
    query: Optional[TimelineQuery] = None,
) -> TimelineStats:
    """Aggregate timeline events by time window.

    Returns stats including the busiest window for anomaly detection.
    """
    tdir = _resolve_timeline_dir(timeline_dir)
    conn = _open_timeline_db(tdir, readonly=True)
    try:
        where = "WHERE 1=1"
        params: list[Any] = []

        if query:
            if query.start is not None:
                where += " AND unix_ts >= ?"
                params.append(query.start)
            if query.end is not None:
                where += " AND unix_ts <= ?"
                params.append(query.end)
            if query.actions:
                clauses = []
                for a in query.actions:
                    clauses.append("action LIKE ?")
                    params.append(a + "%")
                where += " AND (" + " OR ".join(clauses) + ")"

        rows = conn.execute(
            f"SELECT CAST(unix_ts / ? AS INTEGER) AS bucket, COUNT(*) AS cnt "
            f"FROM events {where} GROUP BY bucket ORDER BY cnt DESC",
            [window_seconds] + params,
        ).fetchall()

        busiest: dict[str, Any] = {}
        total = 0
        for r in rows:
            total += r["cnt"]
            if not busiest or r["cnt"] > busiest.get("count", 0):
                bucket_ts = r["bucket"] * window_seconds
                busiest = {
                    "timestamp": datetime.fromtimestamp(
                        bucket_ts, tz=timezone.utc
                    ).strftime("%Y-%m-%dT%H:%M:%SZ"),
                    "count": r["cnt"],
                    "window_seconds": window_seconds,
                }

        stats = _compute_stats(conn, where_clause=where, where_params=params)
        stats.busiest_window = busiest
        return stats
    finally:
        conn.close()


def _compute_stats(
    conn: sqlite3.Connection,
    *,
    where_clause: str = "",
    where_params: Optional[list[Any]] = None,
) -> TimelineStats:
    """Compute summary statistics from the timeline DB."""
    wc = where_clause or "WHERE 1=1"
    wp = where_params or []

    row = conn.execute(
        f"SELECT COUNT(*) AS total, MIN(timestamp) AS earliest, "
        f"MAX(timestamp) AS latest FROM events {wc}",
        wp,
    ).fetchone()

    total = row["total"] if row else 0
    time_range = None
    if row and row["earliest"] and row["latest"]:
        time_range = (row["earliest"], row["latest"])

    cat_rows = conn.execute(
        f"SELECT category, COUNT(*) AS cnt FROM events {wc} GROUP BY category",
        wp,
    ).fetchall()
    events_by_category = {r["category"]: r["cnt"] for r in cat_rows}

    action_rows = conn.execute(
        f"SELECT action, COUNT(*) AS cnt FROM events {wc} GROUP BY action ORDER BY cnt DESC",
        wp,
    ).fetchall()
    events_by_action = {r["action"]: r["cnt"] for r in action_rows}

    source_rows = conn.execute(
        f"SELECT DISTINCT source FROM events {wc} AND source != ''",
        wp,
    ).fetchall()
    sources = [r["source"] for r in source_rows]

    return TimelineStats(
        total_events=total,
        time_range=time_range,
        events_by_category=events_by_category,
        events_by_action=events_by_action,
        sources=sources,
    )


# ── Export: TSK 3.x body file ────────────────────────────────────────


def export_bodyfile(events: list[TimelineEvent], output_path: str | Path) -> int:
    """Export events as a TSK 3.x body file.

    Format: ``MD5|name|inode|mode_as_string|UID|GID|size|atime|mtime|ctime|crtime``

    Returns the number of lines written.
    """
    out = Path(output_path)
    count = 0
    fd = os.open(str(out), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            for ev in events[:MAX_EXPORT_EVENTS]:
                name = _sanitize_path(ev.path) if ev.path else "(no path)"
                if ev.hash_hex:
                    name += f" [SHA256:{ev.hash_hex}]"
                ts = str(int(ev.unix_ts)) if ev.unix_ts else "0"
                line = f"0|{name}|0|-|0|0|0|{ts}|{ts}|{ts}|{ts}\n"
                f.write(line)
                count += 1
    except Exception:
        try:
            out.unlink(missing_ok=True)
        except OSError as exc:
            logger.warning("Cannot remove partial body file %s: %s", out, exc)
        raise
    return count


# ── Export: Plaso l2tcsv ─────────────────────────────────────────────


def export_l2tcsv(events: list[TimelineEvent], output_path: str | Path) -> int:
    """Export events in Plaso l2tcsv format (17 comma-separated fields).

    Returns the number of data rows written.
    """
    out = Path(output_path)
    count = 0
    fd = os.open(str(out), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                "date", "time", "timezone", "MACB", "source", "sourcetype",
                "type", "user", "host", "short", "desc", "version",
                "filename", "inode", "notes", "format", "extra",
            ])

            for ev in events[:MAX_EXPORT_EVENTS]:
                try:
                    dt = datetime.fromtimestamp(ev.unix_ts, tz=timezone.utc)
                except (OSError, ValueError, OverflowError):
                    dt = datetime(2000, 1, 1, tzinfo=timezone.utc)

                date_str = dt.strftime("%m/%d/%Y")
                time_str = dt.strftime("%H:%M:%S")

                macb = _macb_for_action(ev.action)
                short = _sanitize_path(ev.action)
                desc_parts = [ev.action]
                if ev.path:
                    desc_parts.append(_sanitize_path(ev.path))
                if ev.hash_hex:
                    desc_parts.append(f"SHA256:{ev.hash_hex}")
                desc = " | ".join(desc_parts)

                writer.writerow([
                    date_str,
                    time_str,
                    "UTC",
                    macb,
                    "CENSUS",
                    "CertiSigma Census",
                    _type_for_action(ev.action),
                    "-",
                    "-",
                    short,
                    desc,
                    "2",
                    _sanitize_path(ev.path) if ev.path else "-",
                    "0",
                    ev.attestation_id or "-",
                    "certisigma_census",
                    f"category={ev.category}",
                ])
                count += 1
    except Exception:
        try:
            out.unlink(missing_ok=True)
        except OSError as exc:
            logger.warning("Cannot remove partial l2tcsv file %s: %s", out, exc)
        raise
    return count


def _macb_for_action(action: str) -> str:
    """Map Census action to MACB indicator."""
    if "new_file" in action or "create" in action:
        return "...B"
    if "modified" in action or "scan" in action:
        return "M..."
    if "removed" in action or "delete" in action:
        return "M..."
    return ".A.."


def _type_for_action(action: str) -> str:
    """Map Census action to l2tcsv type field."""
    if "scan" in action:
        return "Content Modification Time"
    if "integrity" in action:
        return "Metadata Modification Time"
    if "compare" in action or "verify" in action:
        return "Last Access Time"
    return "Content Modification Time"


# ── Export: CASE/UCO JSON-LD ─────────────────────────────────────────


def export_case_json(
    events: list[TimelineEvent],
    output_path: str | Path,
    *,
    case_name: str = "CertiSigma Census Investigation",
    examiner: str = "",
) -> int:
    """Export events as CASE/UCO JSON-LD.

    Returns the number of objects in the @graph.
    """
    context = {
        "kb": "http://example.org/kb/",
        "case-investigation": "https://ontology.caseontology.org/case/investigation/",
        "uco-action": "https://ontology.unifiedcyberontology.org/uco/action/",
        "uco-core": "https://ontology.unifiedcyberontology.org/uco/core/",
        "uco-observable": "https://ontology.unifiedcyberontology.org/uco/observable/",
        "uco-types": "https://ontology.unifiedcyberontology.org/uco/types/",
        "xsd": "http://www.w3.org/2001/XMLSchema#",
    }

    graph: list[dict[str, Any]] = []

    inv_id = f"kb:investigation-{uuid.uuid5(_CENSUS_UUID_NS, case_name)}"
    investigation: dict[str, Any] = {
        "@id": inv_id,
        "@type": "case-investigation:Investigation",
        "uco-core:name": html.escape(case_name),
    }
    if examiner:
        investigation["uco-core:description"] = f"Examiner: {html.escape(examiner)}"
    graph.append(investigation)

    seen_files: dict[str, str] = {}

    for ev in events[:MAX_EXPORT_EVENTS]:
        file_id = ""
        if ev.path or ev.hash_hex:
            file_key = ev.hash_hex or ev.path
            if file_key not in seen_files:
                file_uuid = uuid.uuid5(_CENSUS_UUID_NS, f"file:{file_key}")
                file_id = f"kb:file-{file_uuid}"
                seen_files[file_key] = file_id

                file_obj: dict[str, Any] = {
                    "@id": file_id,
                    "@type": "uco-observable:File",
                    "uco-core:hasFacet": [],
                }

                if ev.path:
                    file_facet: dict[str, Any] = {
                        "@type": "uco-observable:FileFacet",
                        "uco-observable:filePath": html.escape(ev.path),
                    }
                    if ev.unix_ts:
                        ts_str = datetime.fromtimestamp(
                            ev.unix_ts, tz=timezone.utc
                        ).strftime("%Y-%m-%dT%H:%M:%SZ")
                        file_facet["uco-observable:modifiedTime"] = {
                            "@type": "xsd:dateTime",
                            "@value": ts_str,
                        }
                    file_obj["uco-core:hasFacet"].append(file_facet)

                if ev.hash_hex:
                    content_facet: dict[str, Any] = {
                        "@type": "uco-observable:ContentDataFacet",
                        "uco-observable:hash": [
                            {
                                "@type": "uco-types:Hash",
                                "uco-types:hashMethod": "SHA256",
                                "uco-types:hashValue": {
                                    "@type": "xsd:hexBinary",
                                    "@value": ev.hash_hex,
                                },
                            }
                        ],
                    }
                    file_obj["uco-core:hasFacet"].append(content_facet)

                graph.append(file_obj)
            else:
                file_id = seen_files[file_key]

        action_uuid = uuid.uuid5(_CENSUS_UUID_NS, f"action:{ev.audit_entry_hash or str(ev.id)}")
        action_obj: dict[str, Any] = {
            "@id": f"kb:action-{action_uuid}",
            "@type": "case-investigation:InvestigativeAction",
            "uco-core:name": html.escape(ev.action),
            "uco-core:description": html.escape(ev.detail),
            "uco-action:startTime": {
                "@type": "xsd:dateTime",
                "@value": ev.timestamp,
            },
        }
        if ev.attestation_id:
            action_obj["uco-core:object"] = [
                {"@id": inv_id},
            ]
        graph.append(action_obj)

        if file_id:
            rel_uuid = uuid.uuid5(
                _CENSUS_UUID_NS,
                f"rel:{ev.audit_entry_hash or str(ev.id)}:{file_id}",
            )
            graph.append({
                "@id": f"kb:relationship-{rel_uuid}",
                "@type": "uco-observable:ObservableRelationship",
                "uco-core:source": {"@id": action_obj["@id"]},
                "uco-core:target": {"@id": file_id},
                "uco-core:kindOfRelationship": "Acted_On",
                "uco-core:isDirectional": True,
            })

    doc = {"@context": context, "@graph": graph}

    out = Path(output_path)
    fd = os.open(str(out), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(doc, f, indent=2, default=str)
            f.write("\n")
    except Exception:
        try:
            out.unlink(missing_ok=True)
        except OSError as exc:
            logger.warning("Cannot remove partial CASE file %s: %s", out, exc)
        raise

    return len(graph)


# ── Export: HTML timeline report ─────────────────────────────────────


_TIMELINE_HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CertiSigma Census — Forensic Timeline</title>
<style>
:root {{ --bg: #fafbfc; --fg: #1a1a2e; --accent: #0f3460; --border: #dde; --ok: #27ae60; --warn: #e74c3c; }}
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
body {{ font-family: "Segoe UI", system-ui, sans-serif; background: var(--bg); color: var(--fg); line-height: 1.6; padding: 2rem; max-width: 1100px; margin: auto; }}
h1 {{ color: var(--accent); border-bottom: 3px solid var(--accent); padding-bottom: .4rem; margin-bottom: 1.5rem; }}
h2 {{ color: var(--accent); margin: 1.5rem 0 .8rem; }}
table {{ width: 100%; border-collapse: collapse; margin: 1rem 0; font-size: .9rem; }}
th {{ background: var(--accent); color: #fff; padding: .5rem .7rem; text-align: left; }}
td {{ padding: .4rem .7rem; border-bottom: 1px solid var(--border); }}
tr:hover td {{ background: #eef; }}
.mono {{ font-family: "Cascadia Code", "Fira Mono", monospace; font-size: .85em; }}
.summary {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; margin: 1rem 0; }}
.card {{ background: #fff; border: 1px solid var(--border); border-radius: 8px; padding: 1rem; }}
.card .label {{ font-size: .85rem; color: #666; }}
.card .value {{ font-size: 1.8rem; font-weight: 700; color: var(--accent); }}
.section {{ margin-bottom: 2rem; }}
.cat {{ display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: .8rem; font-weight: 600; }}
.cat-scan {{ background: #e3f2fd; color: #1565c0; }}
.cat-integrity {{ background: #fff3e0; color: #e65100; }}
.cat-alert {{ background: #fce4ec; color: #c62828; }}
.cat-compare {{ background: #f3e5f5; color: #6a1b9a; }}
.cat-verify {{ background: #e8f5e9; color: #2e7d32; }}
.cat-admin {{ background: #eceff1; color: #455a64; }}
footer {{ margin-top: 3rem; border-top: 1px solid var(--border); padding-top: 1rem; font-size: .85rem; color: #888; }}
</style>
</head>
<body>

<h1>CertiSigma Census — Forensic Timeline</h1>

<div class="section">
<p><strong>Generated:</strong> {generated_at}</p>
<p><strong>Tool version:</strong> certisigma-census {tool_version}</p>
{title_line}
</div>

<h2>Summary</h2>
<div class="summary">
<div class="card"><div class="label">Total Events</div><div class="value">{total_events}</div></div>
<div class="card"><div class="label">Time Range</div><div class="value" style="font-size:1rem">{time_range}</div></div>
{category_cards}
</div>

<h2>Event Timeline</h2>
<table>
<thead><tr><th>Timestamp</th><th>Category</th><th>Action</th><th>Path</th><th>SHA-256</th><th>Detail</th></tr></thead>
<tbody>
{event_rows}
</tbody>
</table>

<footer>
<p>Generated by CertiSigma Census v{tool_version} — <a href="https://certisigma.ch">certisigma.ch</a></p>
</footer>

</body>
</html>"""


def export_html(
    events: list[TimelineEvent],
    output_path: str | Path,
    *,
    title: str = "",
    stats: Optional[TimelineStats] = None,
) -> int:
    """Export events as an HTML forensic timeline report.

    Returns the number of events rendered.
    """
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    title_line = ""
    if title:
        title_line = f"<p><strong>Title:</strong> {html.escape(title)}</p>"

    total = stats.total_events if stats else len(events)
    tr = "N/A"
    if stats and stats.time_range:
        tr = f"{html.escape(stats.time_range[0])} — {html.escape(stats.time_range[1])}"
    elif events:
        tr = f"{html.escape(events[0].timestamp)} — {html.escape(events[-1].timestamp)}"

    category_cards = ""
    if stats:
        for cat, cnt in sorted(stats.events_by_category.items()):
            category_cards += (
                f'<div class="card"><div class="label">{html.escape(cat.title())}</div>'
                f'<div class="value">{cnt:,}</div></div>\n'
            )

    rows: list[str] = []
    for ev in events[:MAX_EXPORT_EVENTS]:
        cat_class = f"cat-{html.escape(ev.category)}"
        hash_display = html.escape(ev.hash_hex[:16] + "...") if ev.hash_hex else ""
        rows.append(
            f"<tr>"
            f"<td class=\"mono\">{html.escape(ev.timestamp)}</td>"
            f"<td><span class=\"cat {cat_class}\">{html.escape(ev.category)}</span></td>"
            f"<td>{html.escape(ev.action)}</td>"
            f"<td class=\"mono\">{html.escape(ev.path)}</td>"
            f"<td class=\"mono\">{hash_display}</td>"
            f"<td>{html.escape(ev.detail)}</td>"
            f"</tr>"
        )

    content = _TIMELINE_HTML_TEMPLATE.format(
        generated_at=html.escape(now),
        tool_version=html.escape(__version__),
        title_line=title_line,
        total_events=f"{total:,}",
        time_range=tr,
        category_cards=category_cards,
        event_rows="\n".join(rows),
    )

    out = Path(output_path)
    fd = os.open(str(out), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(content)
    except Exception:
        try:
            out.unlink(missing_ok=True)
        except OSError as exc:
            logger.warning("Cannot remove partial HTML file %s: %s", out, exc)
        raise

    return len(rows)


# ── Export: JSON ─────────────────────────────────────────────────────


def export_json(events: list[TimelineEvent], output_path: str | Path) -> int:
    """Export events as JSON with Census metadata envelope."""
    data = {
        "events": [asdict(ev) for ev in events[:MAX_EXPORT_EVENTS]],
        "total": len(events),
        "census_version": __version__,
        "exported_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    out = Path(output_path)
    fd = os.open(str(out), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str)
            f.write("\n")
    except Exception:
        try:
            out.unlink(missing_ok=True)
        except OSError as exc:
            logger.warning("Cannot remove partial JSON file %s: %s", out, exc)
        raise
    return len(events[:MAX_EXPORT_EVENTS])


# ── Export: CSV ──────────────────────────────────────────────────────


def export_csv(events: list[TimelineEvent], output_path: str | Path) -> int:
    """Export events as CSV."""
    out = Path(output_path)
    count = 0
    fd = os.open(str(out), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                "timestamp", "unix_ts", "action", "category", "path",
                "hash_hex", "attestation_id", "detail", "source",
            ])
            for ev in events[:MAX_EXPORT_EVENTS]:
                writer.writerow([
                    ev.timestamp,
                    ev.unix_ts,
                    ev.action,
                    ev.category,
                    ev.path,
                    ev.hash_hex,
                    ev.attestation_id,
                    ev.detail,
                    ev.source,
                ])
                count += 1
    except Exception:
        try:
            out.unlink(missing_ok=True)
        except OSError as exc:
            logger.warning("Cannot remove partial CSV file %s: %s", out, exc)
        raise
    return count
