"""Git hook integration — automatic attestation on commit.

Installs a post-commit Git hook that hashes changed files, records them
in the Census manifest, and optionally attests via the CertiSigma API.

The hook is **non-blocking**: if the API is unreachable or no API key is
configured, files are still hashed and recorded locally.  Attestation
happens on a best-effort basis with a configurable timeout.

Install: ``census git-hook install``
"""

from __future__ import annotations

import fnmatch
import logging
import os
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Sequence

from certisigma import hash_file

from .manifest import Manifest, ManifestEntry

logger = logging.getLogger(__name__)

HOOK_MARKER = "# CENSUS_GIT_HOOK"
HOOK_TIMEOUT_SECONDS = 30
MAX_FILES_PER_HOOK = 5000

_HOOK_SCRIPT = """\
#!/usr/bin/env python3
{marker} — do not edit (managed by census git-hook install)
import subprocess, sys
try:
    subprocess.run(
        [sys.executable, "-m", "certisigma_census", "git-hook", "run"],
        timeout={timeout},
        capture_output=True,
    )
except Exception:
    pass  # post-commit hook must never block
"""


@dataclass
class HookConfig:
    """Configuration for the git post-commit hook."""

    manifest_path: str = ".census-manifest.db"
    source: str = "git-commit"
    dry_run: bool = False
    exclude: list[str] = field(default_factory=lambda: [
        "*.pyc", "__pycache__/**", ".git/**", "*.egg-info/**",
    ])
    timeout: int = HOOK_TIMEOUT_SECONDS

    @classmethod
    def from_config(cls, config: dict) -> HookConfig:
        """Build from a loaded Census config dict's ``[git_hook]`` section."""
        section = config.get("git_hook", {})
        if not isinstance(section, dict):
            return cls()
        defaults = cls()
        try:
            raw_timeout = section.get("timeout", defaults.timeout)
            if isinstance(raw_timeout, bool):
                raw_timeout = defaults.timeout
            timeout = max(1, min(int(raw_timeout), 300))
        except (ValueError, TypeError):
            timeout = defaults.timeout
        exclude_raw = section.get("exclude", defaults.exclude)
        if not isinstance(exclude_raw, list):
            exclude_raw = defaults.exclude
        exclude = [str(p) for p in exclude_raw]
        return cls(
            manifest_path=str(section.get("manifest", defaults.manifest_path)),
            source=str(section.get("source", defaults.source)),
            dry_run=bool(section.get("dry_run", defaults.dry_run)),
            exclude=exclude,
            timeout=timeout,
        )


@dataclass
class HookResult:
    """Result of a git hook execution."""

    success: bool
    files_hashed: int = 0
    files_attested: int = 0
    commit_sha: str = ""
    manifest_path: str = ""
    dry_run: bool = False
    errors: list[str] = field(default_factory=list)
    elapsed_seconds: float = 0.0


def find_git_root(start: Path | None = None) -> Optional[Path]:
    """Find the nearest .git directory by walking up from *start*."""
    current = (start or Path.cwd()).resolve()
    for _ in range(50):
        if (current / ".git").is_dir():
            return current
        parent = current.parent
        if parent == current:
            break
        current = parent
    return None


def _hooks_dir(repo_root: Path) -> Path:
    """Return the hooks directory, respecting core.hooksPath."""
    try:
        result = subprocess.run(
            ["git", "config", "--get", "core.hooksPath"],
            capture_output=True, text=True, timeout=5,
            cwd=str(repo_root),
        )
        if result.returncode == 0 and result.stdout.strip():
            custom = Path(result.stdout.strip())
            if custom.is_absolute():
                return custom
            return repo_root / custom
    except (OSError, subprocess.TimeoutExpired):
        pass
    return repo_root / ".git" / "hooks"


_MAX_HOOK_FILE_BYTES = 64 * 1024  # 64 KB — hooks are small scripts


def _is_census_hook(path: Path) -> bool:
    """Check if a hook file was installed by Census."""
    if not path.is_file():
        return False
    try:
        if path.stat().st_size > _MAX_HOOK_FILE_BYTES:
            return False
        content = path.read_text(encoding="utf-8", errors="replace")
        return HOOK_MARKER in content
    except OSError:
        return False


def install_hook(
    repo_root: Path,
    config: HookConfig | None = None,
) -> Path:
    """Install a post-commit hook into the Git repository.

    Returns the path to the installed hook script.

    Raises ``FileExistsError`` if a non-Census hook already exists.
    Raises ``ValueError`` if *repo_root* is not a Git repository.
    """
    cfg = config or HookConfig()

    if not (repo_root / ".git").is_dir():
        raise ValueError(f"Not a Git repository: {repo_root}")

    hooks = _hooks_dir(repo_root)
    hooks.mkdir(parents=True, exist_ok=True)

    hook_path = hooks / "post-commit"

    if hook_path.exists() and not _is_census_hook(hook_path):
        raise FileExistsError(
            f"A non-Census post-commit hook already exists at {hook_path}. "
            "Remove it manually or use a hook manager like pre-commit."
        )

    script = _HOOK_SCRIPT.format(
        marker=HOOK_MARKER,
        timeout=cfg.timeout,
    )

    fd = os.open(str(hook_path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o755)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(script)
    except BaseException:
        try:
            os.unlink(str(hook_path))
        except OSError as exc:
            logger.warning("Cannot remove partial hook file %s: %s", hook_path, exc)
        raise

    logger.debug("Installed Census post-commit hook at %s", hook_path)
    return hook_path


def uninstall_hook(repo_root: Path) -> bool:
    """Remove Census post-commit hook. Returns True if removed."""
    if not (repo_root / ".git").is_dir():
        raise ValueError(f"Not a Git repository: {repo_root}")

    hook_path = _hooks_dir(repo_root) / "post-commit"

    if not _is_census_hook(hook_path):
        return False

    try:
        hook_path.unlink()
    except OSError as exc:
        logger.warning("Cannot remove hook file %s: %s", hook_path, exc)
        return False

    logger.debug("Removed Census post-commit hook from %s", hook_path)
    return True


@dataclass
class HookStatus:
    """Status of the Census git hook in a repository."""

    installed: bool
    hook_path: Optional[str] = None
    repo_root: Optional[str] = None
    config: Optional[dict] = None


def get_hook_status(repo_root: Path, config: HookConfig | None = None) -> HookStatus:
    """Check if Census hook is installed and return status."""
    if not (repo_root / ".git").is_dir():
        return HookStatus(installed=False)

    hook_path = _hooks_dir(repo_root) / "post-commit"
    installed = _is_census_hook(hook_path)

    cfg = config or HookConfig()
    return HookStatus(
        installed=installed,
        hook_path=str(hook_path) if installed else None,
        repo_root=str(repo_root),
        config={
            "manifest": cfg.manifest_path,
            "source": cfg.source,
            "dry_run": cfg.dry_run,
            "exclude": cfg.exclude,
            "timeout": cfg.timeout,
        } if installed else None,
    )


def _get_commit_sha(repo_root: Path) -> str:
    """Get the current HEAD commit SHA."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True, text=True, timeout=5,
            cwd=str(repo_root),
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (OSError, subprocess.TimeoutExpired):
        pass
    return ""


def _get_changed_files(repo_root: Path) -> list[Path]:
    """Get files changed in the latest commit.

    Validates that every resolved path stays within *repo_root* to prevent
    path-traversal via crafted Git history.
    """
    try:
        result = subprocess.run(
            ["git", "diff-tree", "--no-commit-id", "--name-only", "-r", "HEAD"],
            capture_output=True, text=True, timeout=10,
            cwd=str(repo_root),
        )
        if result.returncode != 0:
            return []

        resolved_root = repo_root.resolve()
        files = []
        for line in result.stdout.strip().splitlines():
            line = line.strip()
            if not line:
                continue
            p = (repo_root / line).resolve()
            if not p.is_relative_to(resolved_root):
                logger.warning("Path escapes repo root, skipping: %s", line)
                continue
            if p.is_file():
                files.append(p)
        return files[:MAX_FILES_PER_HOOK]
    except (OSError, subprocess.TimeoutExpired):
        return []


def _should_exclude(rel_path: str, patterns: Sequence[str]) -> bool:
    """Check if a relative path matches any exclude pattern."""
    name = rel_path.rsplit("/", 1)[-1] if "/" in rel_path else rel_path
    for pattern in patterns:
        if fnmatch.fnmatch(rel_path, pattern):
            return True
        if "/" not in pattern and fnmatch.fnmatch(name, pattern):
            return True
    return False


def _watcher_is_running(repo_root: Path) -> bool:
    """Check if census watch is running on this directory (PID file)."""
    pid_file = repo_root / ".census-watch.pid"
    if not pid_file.exists():
        return False
    try:
        if pid_file.stat().st_size > 32:
            return False
        pid = int(pid_file.read_text().strip())
        os.kill(pid, 0)
        return True
    except (ValueError, OSError):
        return False


def run_post_commit(
    repo_root: Path,
    config: HookConfig | None = None,
    api_key: str | None = None,
    base_url: str | None = None,
) -> HookResult:
    """Execute the post-commit hook logic.

    1. Get changed files from the latest commit
    2. Hash each file
    3. Record in manifest
    4. If API key available and not dry_run: batch attest
    """
    t0 = time.monotonic()
    cfg = config or HookConfig()
    commit_sha = _get_commit_sha(repo_root)
    short_sha = commit_sha[:8] if commit_sha else "unknown"

    if _watcher_is_running(repo_root):
        logger.debug("Census watch is running — skipping git hook to avoid duplicate attestations")
        return HookResult(
            success=True,
            commit_sha=commit_sha,
            manifest_path=cfg.manifest_path,
            dry_run=cfg.dry_run,
            elapsed_seconds=time.monotonic() - t0,
        )

    changed = _get_changed_files(repo_root)
    if not changed:
        return HookResult(
            success=True,
            commit_sha=commit_sha,
            manifest_path=cfg.manifest_path,
            dry_run=cfg.dry_run,
            elapsed_seconds=time.monotonic() - t0,
        )

    resolved_root = repo_root.resolve()
    filtered = []
    for p in changed:
        try:
            rel = str(p.resolve().relative_to(resolved_root))
        except ValueError:
            continue
        if not _should_exclude(rel, cfg.exclude):
            filtered.append((p, rel))

    if not filtered:
        return HookResult(
            success=True,
            commit_sha=commit_sha,
            manifest_path=cfg.manifest_path,
            dry_run=cfg.dry_run,
            elapsed_seconds=time.monotonic() - t0,
        )

    manifest_path = (repo_root / cfg.manifest_path).resolve()
    if not manifest_path.is_relative_to(repo_root.resolve()):
        return HookResult(
            success=False,
            commit_sha=commit_sha,
            manifest_path=cfg.manifest_path,
            dry_run=cfg.dry_run,
            errors=["manifest path escapes repository root"],
            elapsed_seconds=time.monotonic() - t0,
        )
    errors: list[str] = []

    manifest = Manifest()
    if manifest_path.is_file():
        try:
            manifest.close()
            manifest = Manifest.load(manifest_path)
        except Exception as exc:
            logger.warning("Cannot load existing manifest %s: %s", manifest_path, exc)
            manifest = Manifest()

    hashed_entries: list[ManifestEntry] = []
    try:
        for abs_path, rel_path in filtered:
            try:
                st = abs_path.stat()
                h = hash_file(str(abs_path))
                entry = ManifestEntry(
                    hash_hex=h,
                    path=rel_path,
                    size=st.st_size,
                    mtime=st.st_mtime,
                )
                manifest.add(entry)
                hashed_entries.append(entry)
            except Exception as exc:
                errors.append(f"{rel_path}: {exc}")
                logger.debug("Failed to hash %s: %s", rel_path, exc)

        try:
            manifest.save(manifest_path)
        except Exception as exc:
            errors.append(f"manifest save: {exc}")
            logger.warning("Cannot save manifest %s: %s", manifest_path, exc)
    finally:
        manifest.close()

    files_attested = 0
    if hashed_entries and api_key and not cfg.dry_run:
        try:
            from certisigma import CertiSigmaClient
            from .retry import retry_api_call

            source_label = f"{cfg.source}:{short_sha}" if cfg.source else f"git-commit:{short_sha}"
            client = CertiSigmaClient(api_key=api_key, base_url=base_url or "https://api.certisigma.ch")
            try:
                hashes = [e.hash_hex for e in hashed_entries]
                for i in range(0, len(hashes), 100):
                    batch = hashes[i:i + 100]
                    try:
                        retry_api_call(client.batch_attest, batch, source=source_label)
                        files_attested += len(batch)
                    except Exception as exc:
                        errors.append(f"batch_attest: {exc}")
                        logger.debug("Batch attest failed: %s", exc)
            finally:
                client.close()
        except Exception as exc:
            errors.append(f"api: {exc}")
            logger.debug("API client error: %s", exc)

    elapsed = time.monotonic() - t0
    return HookResult(
        success=len(errors) == 0,
        files_hashed=len(hashed_entries),
        files_attested=files_attested,
        commit_sha=commit_sha,
        manifest_path=str(manifest_path),
        dry_run=cfg.dry_run,
        errors=errors,
        elapsed_seconds=elapsed,
    )
