"""Velocity alerting for watch mode — rolling-window event counter.

Detects file-change velocity spikes that may indicate exfiltration,
ransomware, or unauthorized bulk operations.  Pure logic module: no I/O,
no CLI, no hooks.  Integration happens in ``watcher.py``.
"""

from __future__ import annotations

import dataclasses
import threading
import time
from collections import deque


@dataclasses.dataclass(frozen=True)
class VelocityAlert:
    """Immutable snapshot emitted when the velocity threshold is exceeded."""

    timestamp: str
    events_in_window: int
    window_seconds: float
    threshold: int
    cooldown_seconds: float
    sample_paths: list[str]
    event_counts: dict[str, int]
    alerts_fired: int
    suppressed_since_last: int
    total_events_since_start: int
    uptime_seconds: float


_MAX_WINDOW: float = 86_400.0  # 24 h — sanity cap
_MAX_COOLDOWN: float = 86_400.0


class VelocityMonitor:
    """Thread-safe rolling-window event counter with cooldown.

    Parameters
    ----------
    window_seconds:
        Duration of the sliding window (default 300 s = 5 min).
    cooldown_seconds:
        Minimum interval between consecutive alerts (default 600 s = 10 min).
    """

    def __init__(
        self,
        window_seconds: float = 300.0,
        cooldown_seconds: float = 600.0,
    ) -> None:
        if window_seconds <= 0 or window_seconds > _MAX_WINDOW:
            raise ValueError(
                f"window_seconds must be in (0, {_MAX_WINDOW}], got {window_seconds}"
            )
        if cooldown_seconds < 0 or cooldown_seconds > _MAX_COOLDOWN:
            raise ValueError(
                f"cooldown_seconds must be in [0, {_MAX_COOLDOWN}], got {cooldown_seconds}"
            )
        self._window = window_seconds
        self._cooldown = cooldown_seconds
        self._buckets: deque[tuple[float, int]] = deque()
        self._lock = threading.Lock()
        self._last_alert_at: float = 0.0
        self._alerts_fired: int = 0
        self._suppressed: int = 0
        self._last_suppressed: int = 0
        self._total_events: int = 0
        self._start_time: float = time.monotonic()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def record_batch(self, count: int, *, _now: float | None = None) -> int:
        """Record *count* events and return total events in the current window.

        The ``_now`` parameter is for testing only (monotonic seconds).
        """
        now = _now if _now is not None else time.monotonic()
        with self._lock:
            if count > 0:
                self._buckets.append((now, count))
                self._total_events += count
            self._evict(now)
            return self._window_total()

    def should_alert(self, threshold: int, *, _now: float | None = None) -> bool:
        """Return ``True`` if threshold is exceeded *and* cooldown has elapsed.

        When the threshold is exceeded but cooldown blocks the alert,
        an internal suppressed counter is incremented.
        """
        if threshold <= 0:
            return False
        now = _now if _now is not None else time.monotonic()
        with self._lock:
            self._evict(now)
            total = self._window_total()
            if total < threshold:
                return False
            if (now - self._last_alert_at) < self._cooldown:
                self._suppressed += 1
                return False
            self._last_alert_at = now
            self._alerts_fired += 1
            suppressed = self._suppressed
            self._suppressed = 0
            # Store suppressed count for the caller to read immediately
            self._last_suppressed = suppressed
            return True

    def current_rate(self) -> tuple[int, float]:
        """Return ``(events_in_window, window_seconds)``."""
        now = time.monotonic()
        with self._lock:
            self._evict(now)
            return self._window_total(), self._window

    def stats(self) -> dict[str, int | float]:
        """Return cumulative statistics (thread-safe snapshot)."""
        with self._lock:
            return {
                "alerts_fired": self._alerts_fired,
                "suppressed_since_last": self._last_suppressed,
                "total_events_since_start": self._total_events,
                "uptime_seconds": round(time.monotonic() - self._start_time, 1),
            }

    def reset(self) -> None:
        """Clear all state.  Useful for testing."""
        with self._lock:
            self._buckets.clear()
            self._last_alert_at = 0.0
            self._alerts_fired = 0
            self._suppressed = 0
            self._last_suppressed = 0
            self._total_events = 0
            self._start_time = time.monotonic()

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _evict(self, now: float) -> None:
        cutoff = now - self._window
        while self._buckets and self._buckets[0][0] < cutoff:
            self._buckets.popleft()

    def _window_total(self) -> int:
        return sum(c for _, c in self._buckets)
