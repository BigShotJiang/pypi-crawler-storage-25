"""Tests for SLSA v1.0 provenance generation and verification (Phase 32)."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from certisigma_census.cli import main
from certisigma_census.manifest import Manifest, ManifestEntry
from certisigma_census.provenance import (
    BUILD_TYPE,
    DEFAULT_BUILDER_ID,
    MAX_PROVENANCE_FILE_BYTES,
    PREDICATE_TYPE,
    STATEMENT_TYPE,
    CIEnvironment,
    ProvenanceStatement,
    ProvenanceVerifyResult,
    _validate_statement,
    detect_ci_environment,
    generate_provenance,
    load_provenance,
    write_provenance,
)


# ── Unit tests: generate_provenance ──────────────────────────────────────


class TestGenerateProvenance:
    def test_minimal(self, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        m = Manifest(root_dir=str(root))
        m.add(ManifestEntry(hash_hex="aa" * 32, path="a.txt", size=5, mtime=1.0))
        try:
            stmt = generate_provenance(m)
            d = stmt.to_dict()
            assert d["_type"] == STATEMENT_TYPE
            assert d["predicateType"] == PREDICATE_TYPE
            assert len(d["subject"]) == 1
            assert d["subject"][0]["digest"]["sha256"] == "aa" * 32
            assert d["predicate"]["buildDefinition"]["buildType"] == BUILD_TYPE
            assert d["predicate"]["runDetails"]["builder"]["id"] == DEFAULT_BUILDER_ID
        finally:
            m.close()

    def test_with_source_and_commit(self, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        m = Manifest(root_dir=str(root))
        m.add(ManifestEntry(hash_hex="bb" * 32, path="b.txt", size=5, mtime=1.0))
        try:
            stmt = generate_provenance(m, source="release-v2", commit_sha="abcd1234" * 5)
            d = stmt.to_dict()
            assert d["predicate"]["buildDefinition"]["externalParameters"]["source"] == "release-v2"
            deps = d["predicate"]["buildDefinition"]["resolvedDependencies"]
            git_deps = [dep for dep in deps if "gitCommit" in dep.get("digest", {})]
            assert len(git_deps) == 1
            assert git_deps[0]["digest"]["gitCommit"] == "abcd1234" * 5
        finally:
            m.close()

    def test_custom_builder_id(self, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        m = Manifest(root_dir=str(root))
        m.add(ManifestEntry(hash_hex="cc" * 32, path="c.txt", size=5, mtime=1.0))
        try:
            stmt = generate_provenance(m, builder_id="https://example.com/my-builder")
            d = stmt.to_dict()
            assert d["predicate"]["runDetails"]["builder"]["id"] == "https://example.com/my-builder"
        finally:
            m.close()

    def test_attestation_ids_in_byproducts(self, tmp_path):
        import base64

        root = tmp_path / "data"
        root.mkdir()
        m = Manifest(root_dir=str(root))
        m.add(ManifestEntry(hash_hex="dd" * 32, path="d.txt", size=5, mtime=1.0))
        try:
            stmt = generate_provenance(m, attestation_ids=["att_1", "att_2"])
            d = stmt.to_dict()
            byproducts = d["predicate"]["runDetails"]["byproducts"]
            assert len(byproducts) == 1
            payload = json.loads(base64.b64decode(byproducts[0]["content"]))
            assert payload == ["att_1", "att_2"]
        finally:
            m.close()

    def test_embed_materials(self, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        m = Manifest(root_dir=str(root))
        for i in range(5):
            h = f"{i:02x}" * 32
            m.add(ManifestEntry(hash_hex=h, path=f"file_{i}.txt", size=10, mtime=1.0))
        try:
            stmt = generate_provenance(m, embed_materials=True)
            d = stmt.to_dict()
            deps = d["predicate"]["buildDefinition"]["resolvedDependencies"]
            file_deps = [dep for dep in deps if dep.get("uri", "").startswith("file:")]
            assert len(file_deps) == 5
        finally:
            m.close()

    def test_ci_environment_injected(self, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        m = Manifest(root_dir=str(root))
        m.add(ManifestEntry(hash_hex="ee" * 32, path="e.txt", size=5, mtime=1.0))
        ci = CIEnvironment(
            ci_system="github-actions",
            repo_url="https://github.com/org/repo",
            commit_sha="abc123" * 6 + "abcd",
            invocation_id="12345",
        )
        try:
            stmt = generate_provenance(m, ci_env=ci)
            d = stmt.to_dict()
            meta = d["predicate"]["runDetails"]["metadata"]
            assert meta["invocationId"] == "12345"
            deps = d["predicate"]["buildDefinition"]["resolvedDependencies"]
            vcs_deps = [dep for dep in deps if "github.com" in dep.get("uri", "")]
            assert len(vcs_deps) == 1
        finally:
            m.close()

    def test_slsa_build_level_in_internal_params(self, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        m = Manifest(root_dir=str(root))
        m.add(ManifestEntry(hash_hex="ff" * 32, path="f.txt", size=5, mtime=1.0))
        try:
            stmt = generate_provenance(m)
            d = stmt.to_dict()
            internal = d["predicate"]["buildDefinition"]["internalParameters"]
            assert internal["slsa_build_level"] == 1
        finally:
            m.close()

    def test_census_version_in_output(self, tmp_path):
        from certisigma_census import __version__

        root = tmp_path / "data"
        root.mkdir()
        m = Manifest(root_dir=str(root))
        m.add(ManifestEntry(hash_hex="aa" * 32, path="a.txt", size=5, mtime=1.0))
        try:
            stmt = generate_provenance(m)
            d = stmt.to_dict()
            assert d["predicate"]["buildDefinition"]["internalParameters"]["census_version"] == __version__
            assert d["predicate"]["runDetails"]["builder"]["version"]["census"] == __version__
        finally:
            m.close()

    def test_sbom_integration(self, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        m = Manifest(root_dir=str(root))
        m.add(ManifestEntry(hash_hex="aa" * 32, path="a.txt", size=5, mtime=1.0))

        mock_comp = MagicMock()
        mock_comp.hash_hex = "bb" * 32
        mock_comp.name = "libfoo"
        mock_comp.purl = "pkg:pypi/libfoo@1.0"
        mock_sbom = MagicMock()
        mock_sbom.components = [mock_comp]

        try:
            stmt = generate_provenance(m, sbom_doc=mock_sbom)
            d = stmt.to_dict()
            deps = d["predicate"]["buildDefinition"]["resolvedDependencies"]
            sbom_deps = [dep for dep in deps if dep.get("name") == "libfoo"]
            assert len(sbom_deps) == 1
            assert sbom_deps[0]["digest"]["sha256"] == "bb" * 32
            assert sbom_deps[0]["uri"] == "pkg:pypi/libfoo@1.0"
        finally:
            m.close()


# ── Unit tests: detect_ci_environment ────────────────────────────────────


class TestDetectCI:
    def test_github_actions(self):
        env = {
            "GITHUB_ACTIONS": "true",
            "GITHUB_REPOSITORY": "org/repo",
            "GITHUB_SHA": "abc123",
            "GITHUB_WORKFLOW": "CI",
            "GITHUB_RUN_ID": "99",
            "GITHUB_SERVER_URL": "https://github.com",
        }
        with patch.dict("os.environ", env, clear=True):
            ci = detect_ci_environment()
            assert ci is not None
            assert ci.ci_system == "github-actions"
            assert ci.repo_url == "https://github.com/org/repo"
            assert ci.commit_sha == "abc123"
            assert ci.invocation_id == "99"

    def test_gitlab_ci(self):
        env = {
            "GITLAB_CI": "true",
            "CI_PROJECT_URL": "https://gitlab.com/org/repo",
            "CI_COMMIT_SHA": "def456",
            "CI_PIPELINE_ID": "42",
        }
        with patch.dict("os.environ", env, clear=True):
            ci = detect_ci_environment()
            assert ci is not None
            assert ci.ci_system == "gitlab-ci"
            assert ci.commit_sha == "def456"

    def test_jenkins(self):
        env = {
            "JENKINS_URL": "https://jenkins.example.com",
            "GIT_COMMIT": "789abc",
            "BUILD_ID": "100",
        }
        with patch.dict("os.environ", env, clear=True):
            ci = detect_ci_environment()
            assert ci is not None
            assert ci.ci_system == "jenkins"
            assert ci.commit_sha == "789abc"

    def test_generic_ci(self):
        env = {"CI": "true"}
        with patch.dict("os.environ", env, clear=True):
            ci = detect_ci_environment()
            assert ci is not None
            assert ci.ci_system == "generic-ci"

    def test_no_ci(self):
        with patch.dict("os.environ", {}, clear=True):
            ci = detect_ci_environment()
            assert ci is None


# ── Unit tests: write + load round-trip ──────────────────────────────────


class TestWriteLoad:
    def test_json_roundtrip(self, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        m = Manifest(root_dir=str(root))
        m.add(ManifestEntry(hash_hex="aa" * 32, path="a.txt", size=5, mtime=1.0))
        try:
            stmt = generate_provenance(m)
        finally:
            m.close()

        out = tmp_path / "prov.json"
        write_provenance(stmt, out, format="json")
        loaded = load_provenance(out)
        assert loaded.to_dict() == stmt.to_dict()

    def test_jsonl_roundtrip(self, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        m = Manifest(root_dir=str(root))
        m.add(ManifestEntry(hash_hex="bb" * 32, path="b.txt", size=5, mtime=1.0))
        try:
            stmt = generate_provenance(m)
        finally:
            m.close()

        out = tmp_path / "prov.intoto.jsonl"
        write_provenance(stmt, out, format="intoto-jsonl")
        loaded = load_provenance(out)
        assert loaded.subject == stmt.subject

    def test_load_rejects_oversized(self, tmp_path):
        big_file = tmp_path / "huge.json"
        big_file.write_text("x" * (MAX_PROVENANCE_FILE_BYTES + 1))
        with pytest.raises(ValueError, match="too large"):
            load_provenance(big_file)

    def test_load_rejects_empty(self, tmp_path):
        empty = tmp_path / "empty.json"
        empty.write_text("")
        with pytest.raises(ValueError, match="Empty"):
            load_provenance(empty)

    def test_load_rejects_invalid_json(self, tmp_path):
        bad = tmp_path / "bad.json"
        bad.write_text("{not valid json}")
        with pytest.raises(json.JSONDecodeError):
            load_provenance(bad)


# ── Unit tests: _validate_statement ──────────────────────────────────────


class TestValidateStatement:
    def test_rejects_non_dict(self):
        with pytest.raises(ValueError, match="JSON object"):
            _validate_statement([])

    def test_rejects_wrong_type(self):
        with pytest.raises(ValueError, match="_type"):
            _validate_statement({
                "_type": "wrong",
                "predicateType": PREDICATE_TYPE,
                "subject": [{"digest": {"sha256": "aa" * 32}}],
                "predicate": {},
            })

    def test_rejects_wrong_predicate_type(self):
        with pytest.raises(ValueError, match="predicateType"):
            _validate_statement({
                "_type": STATEMENT_TYPE,
                "predicateType": "wrong",
                "subject": [{"digest": {"sha256": "aa" * 32}}],
                "predicate": {},
            })

    def test_rejects_empty_subject(self):
        with pytest.raises(ValueError, match="non-empty"):
            _validate_statement({
                "_type": STATEMENT_TYPE,
                "predicateType": PREDICATE_TYPE,
                "subject": [],
                "predicate": {
                    "buildDefinition": {"buildType": BUILD_TYPE},
                    "runDetails": {"builder": {"id": "test"}},
                },
            })

    def test_rejects_invalid_hash_in_subject(self):
        with pytest.raises(ValueError, match="valid SHA-256"):
            _validate_statement({
                "_type": STATEMENT_TYPE,
                "predicateType": PREDICATE_TYPE,
                "subject": [{"name": "bad", "digest": {"sha256": "not-a-hash"}}],
                "predicate": {
                    "buildDefinition": {"buildType": BUILD_TYPE},
                    "runDetails": {"builder": {"id": "test"}},
                },
            })

    def test_rejects_missing_build_definition(self):
        with pytest.raises(ValueError, match="buildDefinition"):
            _validate_statement({
                "_type": STATEMENT_TYPE,
                "predicateType": PREDICATE_TYPE,
                "subject": [{"name": "a", "digest": {"sha256": "aa" * 32}}],
                "predicate": {"runDetails": {"builder": {"id": "test"}}},
            })

    def test_rejects_missing_builder_id(self):
        with pytest.raises(ValueError, match="builder.id"):
            _validate_statement({
                "_type": STATEMENT_TYPE,
                "predicateType": PREDICATE_TYPE,
                "subject": [{"name": "a", "digest": {"sha256": "aa" * 32}}],
                "predicate": {
                    "buildDefinition": {"buildType": BUILD_TYPE},
                    "runDetails": {"builder": {}},
                },
            })

    def test_accepts_valid_statement(self):
        stmt = _validate_statement({
            "_type": STATEMENT_TYPE,
            "predicateType": PREDICATE_TYPE,
            "subject": [{"name": "a.txt", "digest": {"sha256": "aa" * 32}}],
            "predicate": {
                "buildDefinition": {
                    "buildType": BUILD_TYPE,
                    "externalParameters": {},
                    "internalParameters": {},
                    "resolvedDependencies": [],
                },
                "runDetails": {
                    "builder": {"id": DEFAULT_BUILDER_ID},
                    "metadata": {},
                    "byproducts": [],
                },
            },
        })
        assert isinstance(stmt, ProvenanceStatement)
        assert len(stmt.subject) == 1


# ── CLI integration tests ────────────────────────────────────────────────


class TestProvenanceGenerateCLI:
    def test_basic_generate(self, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        (root / "a.txt").write_text("hello")

        from certisigma import hash_file
        h = hash_file(str(root / "a.txt"))
        m = Manifest(root_dir=str(root))
        m.add(ManifestEntry(hash_hex=h, path="a.txt", size=5, mtime=1.0))
        mp = tmp_path / "m.db"
        m.save(mp)
        m.close()

        runner = CliRunner()
        result = runner.invoke(main, ["provenance", "generate", str(mp)])
        assert result.exit_code == 0
        assert "Provenance statement generated" in result.output

        out_file = mp.with_suffix(".db.provenance.json")
        assert out_file.exists()
        data = json.loads(out_file.read_text())
        assert data["_type"] == STATEMENT_TYPE

    def test_generate_json_output(self, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        (root / "a.txt").write_text("hello")

        from certisigma import hash_file
        h = hash_file(str(root / "a.txt"))
        m = Manifest(root_dir=str(root))
        m.add(ManifestEntry(hash_hex=h, path="a.txt", size=5, mtime=1.0))
        mp = tmp_path / "m.db"
        m.save(mp)
        m.close()

        runner = CliRunner()
        result = runner.invoke(main, ["provenance", "generate", str(mp), "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "census_version" in data
        assert "subjects" in data

    def test_generate_intoto_jsonl(self, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        (root / "a.txt").write_text("hello")

        from certisigma import hash_file
        h = hash_file(str(root / "a.txt"))
        m = Manifest(root_dir=str(root))
        m.add(ManifestEntry(hash_hex=h, path="a.txt", size=5, mtime=1.0))
        mp = tmp_path / "m.db"
        m.save(mp)
        m.close()

        runner = CliRunner()
        out = tmp_path / "prov.intoto.jsonl"
        result = runner.invoke(main, [
            "provenance", "generate", str(mp),
            "--format", "intoto-jsonl", "--output", str(out),
        ])
        assert result.exit_code == 0
        assert out.exists()
        data = json.loads(out.read_text().strip())
        assert data["_type"] == STATEMENT_TYPE

    def test_generate_with_source(self, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        (root / "a.txt").write_text("hello")

        from certisigma import hash_file
        h = hash_file(str(root / "a.txt"))
        m = Manifest(root_dir=str(root))
        m.add(ManifestEntry(hash_hex=h, path="a.txt", size=5, mtime=1.0))
        mp = tmp_path / "m.db"
        m.save(mp)
        m.close()

        runner = CliRunner()
        result = runner.invoke(main, [
            "provenance", "generate", str(mp), "--source", "release-v1",
        ])
        assert result.exit_code == 0
        out_file = mp.with_suffix(".db.provenance.json")
        data = json.loads(out_file.read_text())
        assert data["predicate"]["buildDefinition"]["externalParameters"]["source"] == "release-v1"

    def test_generate_embed_materials(self, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        (root / "a.txt").write_text("hello")
        (root / "b.txt").write_text("world")

        from certisigma import hash_file
        m = Manifest(root_dir=str(root))
        for fname in ["a.txt", "b.txt"]:
            h = hash_file(str(root / fname))
            st = (root / fname).stat()
            m.add(ManifestEntry(hash_hex=h, path=fname, size=st.st_size, mtime=st.st_mtime))
        mp = tmp_path / "m.db"
        m.save(mp)
        m.close()

        runner = CliRunner()
        result = runner.invoke(main, [
            "provenance", "generate", str(mp), "--embed-materials",
        ])
        assert result.exit_code == 0
        out_file = mp.with_suffix(".db.provenance.json")
        data = json.loads(out_file.read_text())
        deps = data["predicate"]["buildDefinition"]["resolvedDependencies"]
        file_deps = [d for d in deps if d.get("uri", "").startswith("file:")]
        assert len(file_deps) == 2

    def test_invalid_commit_rejected(self, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        (root / "a.txt").write_text("hello")

        from certisigma import hash_file
        h = hash_file(str(root / "a.txt"))
        m = Manifest(root_dir=str(root))
        m.add(ManifestEntry(hash_hex=h, path="a.txt", size=5, mtime=1.0))
        mp = tmp_path / "m.db"
        m.save(mp)
        m.close()

        runner = CliRunner()
        result = runner.invoke(main, [
            "provenance", "generate", str(mp), "--commit", "not-a-hex-sha!",
        ])
        assert result.exit_code != 0
        assert "Invalid commit SHA" in result.output

    def test_empty_manifest_error(self, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        m = Manifest(root_dir=str(root))
        mp = tmp_path / "m.db"
        m.save(mp)
        m.close()

        runner = CliRunner()
        result = runner.invoke(main, ["provenance", "generate", str(mp)])
        assert result.exit_code != 0

    def test_help(self):
        runner = CliRunner()
        result = runner.invoke(main, ["provenance", "generate", "--help"])
        assert result.exit_code == 0
        assert "--source" in result.output
        assert "--embed-materials" in result.output
        assert "--attest" in result.output


class TestProvenanceVerifyCLI:
    @patch("certisigma.CertiSigmaClient")
    def test_verify_all_attested(self, mock_client_cls, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        m = Manifest(root_dir=str(root))
        m.add(ManifestEntry(hash_hex="aa" * 32, path="a.txt", size=5, mtime=1.0))
        try:
            stmt = generate_provenance(m)
        finally:
            m.close()

        prov_file = tmp_path / "prov.json"
        write_provenance(stmt, prov_file)

        mock_client = MagicMock()
        mock_client_cls.return_value = mock_client
        mock_resp = MagicMock()
        mock_resp.results = [{"hash_hex": "aa" * 32, "exists": True, "id": "att_1"}]
        mock_client.batch_verify = MagicMock(return_value=mock_resp)

        runner = CliRunner()
        result = runner.invoke(main, ["provenance", "verify", str(prov_file)])
        assert result.exit_code == 0
        assert "Verified: 1" in result.output

    @patch("certisigma.CertiSigmaClient")
    def test_verify_strict_unverified(self, mock_client_cls, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        m = Manifest(root_dir=str(root))
        m.add(ManifestEntry(hash_hex="aa" * 32, path="a.txt", size=5, mtime=1.0))
        try:
            stmt = generate_provenance(m)
        finally:
            m.close()

        prov_file = tmp_path / "prov.json"
        write_provenance(stmt, prov_file)

        mock_client = MagicMock()
        mock_client_cls.return_value = mock_client
        mock_resp = MagicMock()
        mock_resp.results = [{"hash_hex": "aa" * 32, "exists": False}]
        mock_client.batch_verify = MagicMock(return_value=mock_resp)

        runner = CliRunner()
        result = runner.invoke(main, ["provenance", "verify", str(prov_file), "--strict"])
        assert result.exit_code == 1

    @patch("certisigma.CertiSigmaClient")
    def test_verify_json_output(self, mock_client_cls, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        m = Manifest(root_dir=str(root))
        m.add(ManifestEntry(hash_hex="aa" * 32, path="a.txt", size=5, mtime=1.0))
        try:
            stmt = generate_provenance(m)
        finally:
            m.close()

        prov_file = tmp_path / "prov.json"
        write_provenance(stmt, prov_file)

        mock_client = MagicMock()
        mock_client_cls.return_value = mock_client
        mock_resp = MagicMock()
        mock_resp.results = [{"hash_hex": "aa" * 32, "exists": True, "id": "att_1"}]
        mock_client.batch_verify = MagicMock(return_value=mock_resp)

        runner = CliRunner()
        result = runner.invoke(main, ["provenance", "verify", str(prov_file), "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["verified"] == 1
        assert data["success"] is True
        assert "census_version" in data

    def test_verify_invalid_provenance(self, tmp_path):
        bad = tmp_path / "bad.json"
        bad.write_text('{"not": "provenance"}')
        runner = CliRunner()
        result = runner.invoke(main, ["provenance", "verify", str(bad)])
        assert result.exit_code == 1

    def test_help(self):
        runner = CliRunner()
        result = runner.invoke(main, ["provenance", "verify", "--help"])
        assert result.exit_code == 0
        assert "--strict" in result.output


# ── Unit tests: ProvenanceVerifyResult ───────────────────────────────────


class TestVerifyResult:
    def test_success_when_all_verified(self):
        r = ProvenanceVerifyResult(total_subjects=3, verified=3, unverified=0)
        assert r.success is True

    def test_failure_when_unverified(self):
        r = ProvenanceVerifyResult(total_subjects=3, verified=2, unverified=1)
        assert r.success is False

    def test_failure_on_errors(self):
        r = ProvenanceVerifyResult(total_subjects=1, verified=1, errors=["api error"])
        assert r.success is False


# ── Unit tests: to_json ──────────────────────────────────────────────────


class TestGenerateEdgeCases:
    def test_empty_manifest_raises(self, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        m = Manifest(root_dir=str(root))
        try:
            with pytest.raises(ValueError, match="empty manifest"):
                generate_provenance(m)
        finally:
            m.close()

    def test_sbom_with_invalid_hash_skipped(self, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        m = Manifest(root_dir=str(root))
        m.add(ManifestEntry(hash_hex="aa" * 32, path="a.txt", size=5, mtime=1.0))

        good = MagicMock()
        good.hash_hex = "bb" * 32
        good.name = "good-lib"
        good.purl = None
        bad = MagicMock()
        bad.hash_hex = "NOT-A-VALID-HEX"
        bad.name = "bad-lib"
        bad.purl = None
        sbom = MagicMock()
        sbom.components = [good, bad]

        try:
            stmt = generate_provenance(m, sbom_doc=sbom)
            d = stmt.to_dict()
            deps = d["predicate"]["buildDefinition"]["resolvedDependencies"]
            sbom_deps = [dep for dep in deps if dep.get("name")]
            assert len(sbom_deps) == 1
            assert sbom_deps[0]["name"] == "good-lib"
        finally:
            m.close()


class TestVerifyEdgeCases:
    def test_batch_error_recorded(self):
        """batch_verify failure is recorded in errors and marks result as failed."""
        stmt = ProvenanceStatement(
            subject=[{"name": "a.txt", "digest": {"sha256": "aa" * 32}}],
            predicate={},
        )
        from certisigma_census.provenance import verify_provenance

        mock_client = MagicMock()
        mock_client.batch_verify = MagicMock(side_effect=RuntimeError("API unavailable"))

        with patch("certisigma_census.retry.retry_api_call", side_effect=lambda fn, *a, **kw: fn(*a, **kw)):
            result = verify_provenance(stmt, mock_client)
        assert result.unverified == 1
        assert len(result.errors) == 1
        assert "API unavailable" in result.errors[0]
        assert result.success is False

    def test_invalid_digest_counted_as_error(self):
        """Subjects with non-SHA-256 digests are reported as errors."""
        stmt = ProvenanceStatement(
            subject=[
                {"name": "good.txt", "digest": {"sha256": "aa" * 32}},
                {"name": "bad.txt", "digest": {"sha256": "INVALID"}},
            ],
            predicate={},
        )
        from certisigma_census.provenance import verify_provenance

        mock_client = MagicMock()
        mock_resp = MagicMock()
        mock_resp.results = [{"hash_hex": "aa" * 32, "exists": True, "id": "att_1"}]
        mock_client.batch_verify = MagicMock(return_value=mock_resp)

        with patch("certisigma_census.retry.retry_api_call", side_effect=lambda fn, *a, **kw: fn(*a, **kw)):
            result = verify_provenance(stmt, mock_client)
        assert result.total_subjects == 2
        assert result.verified == 1
        assert result.unverified == 0
        assert len(result.errors) == 1
        assert "Invalid digest" in result.errors[0]


class TestToJson:
    def test_produces_valid_json(self, tmp_path):
        root = tmp_path / "data"
        root.mkdir()
        m = Manifest(root_dir=str(root))
        m.add(ManifestEntry(hash_hex="aa" * 32, path="a.txt", size=5, mtime=1.0))
        try:
            stmt = generate_provenance(m)
        finally:
            m.close()

        text = stmt.to_json()
        data = json.loads(text)
        assert data["_type"] == STATEMENT_TYPE
