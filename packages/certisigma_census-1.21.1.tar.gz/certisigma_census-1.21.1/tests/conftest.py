"""Shared pytest fixtures for CertiSigma Census tests."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pytest

from certisigma_census.manifest import Manifest, ManifestEntry


@pytest.fixture()
def populated_dir(tmp_path: Path) -> Path:
    """Create a temporary directory with known files for scanning."""
    files = {
        "report.pdf": b"quarterly earnings report",
        "data.csv": b"id,name,value\n1,alpha,100\n2,beta,200",
        "notes.txt": b"internal meeting notes 2026-03-01",
        "schema.json": b'{"type": "object", "properties": {}}',
        "image.png": b"\x89PNG\r\n\x1a\nfake-png-content",
    }
    for name, content in files.items():
        (tmp_path / name).write_bytes(content)
    return tmp_path


@pytest.fixture()
def sample_manifest() -> Manifest:
    """A pre-populated Manifest with 5 entries, 2 attested."""
    m = Manifest(root_dir="/data/sensitive")
    entries = [
        ManifestEntry(hash_hex=f"{i:064x}", path=f"file_{i}.dat", size=(i + 1) * 100, mtime=float(i))
        for i in range(5)
    ]
    for e in entries:
        m.add(e)
    m.mark_attested(f"{0:064x}", "att_1", "2026-01-01T00:00:00Z")
    m.mark_attested(f"{1:064x}", "att_2", "2026-01-02T00:00:00Z")
    yield m
    m.close()


@pytest.fixture()
def mock_client() -> MagicMock:
    """A mocked CertiSigmaClient with default batch_attest/batch_verify responses."""
    client = MagicMock()
    client.batch_attest.return_value = MagicMock(
        batch_id="batch_001",
        count=0,
        created=0,
        existing=0,
        attestations=[],
    )
    client.batch_verify.return_value = MagicMock(
        count=0,
        found=0,
        not_found=0,
        results=[],
    )
    return client
