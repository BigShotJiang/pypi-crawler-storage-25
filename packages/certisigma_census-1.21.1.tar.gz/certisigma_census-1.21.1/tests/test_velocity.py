"""Tests for certisigma_census.velocity — VelocityMonitor and VelocityAlert."""

from __future__ import annotations

import dataclasses
import threading
import time

import pytest

from certisigma_census.velocity import VelocityAlert, VelocityMonitor


# ── VelocityMonitor construction ─────────────────────────────────────

class TestInit:
    def test_default_params(self):
        vm = VelocityMonitor()
        assert vm._window == 300.0
        assert vm._cooldown == 600.0

    def test_custom_params(self):
        vm = VelocityMonitor(window_seconds=60.0, cooldown_seconds=120.0)
        assert vm._window == 60.0
        assert vm._cooldown == 120.0

    def test_zero_window_rejected(self):
        with pytest.raises(ValueError, match="window_seconds"):
            VelocityMonitor(window_seconds=0)

    def test_negative_window_rejected(self):
        with pytest.raises(ValueError, match="window_seconds"):
            VelocityMonitor(window_seconds=-10)

    def test_excessive_window_rejected(self):
        with pytest.raises(ValueError, match="window_seconds"):
            VelocityMonitor(window_seconds=100_000)

    def test_negative_cooldown_rejected(self):
        with pytest.raises(ValueError, match="cooldown_seconds"):
            VelocityMonitor(cooldown_seconds=-1)

    def test_zero_cooldown_accepted(self):
        vm = VelocityMonitor(cooldown_seconds=0)
        assert vm._cooldown == 0.0


# ── Rolling window mechanics ─────────────────────────────────────────

class TestRecordBatch:
    def test_single_batch(self):
        vm = VelocityMonitor(window_seconds=10.0)
        total = vm.record_batch(5, _now=100.0)
        assert total == 5

    def test_multiple_batches_in_window(self):
        vm = VelocityMonitor(window_seconds=10.0)
        vm.record_batch(3, _now=100.0)
        vm.record_batch(7, _now=105.0)
        total = vm.record_batch(2, _now=109.0)
        assert total == 12

    def test_old_batches_evicted(self):
        vm = VelocityMonitor(window_seconds=10.0)
        vm.record_batch(100, _now=100.0)
        vm.record_batch(5, _now=111.0)
        total = vm.record_batch(0, _now=112.0)
        assert total == 5

    def test_zero_count_no_bucket_added(self):
        vm = VelocityMonitor(window_seconds=10.0)
        total = vm.record_batch(0, _now=100.0)
        assert total == 0
        assert len(vm._buckets) == 0

    def test_cumulative_total_tracks_all(self):
        vm = VelocityMonitor(window_seconds=5.0)
        vm.record_batch(10, _now=100.0)
        vm.record_batch(20, _now=200.0)
        assert vm._total_events == 30

    def test_window_boundary_exact(self):
        """Event at exactly cutoff=now-window is still in the window (< not <=)."""
        vm = VelocityMonitor(window_seconds=10.0)
        vm.record_batch(5, _now=100.0)
        total = vm.record_batch(3, _now=110.0)
        assert total == 8  # 100.0 is not < 100.0, so bucket stays

    def test_window_boundary_just_past(self):
        vm = VelocityMonitor(window_seconds=10.0)
        vm.record_batch(5, _now=100.0)
        total = vm.record_batch(3, _now=110.1)
        assert total == 3  # 100.0 < 100.1, so old bucket evicted


# ── Alert threshold ──────────────────────────────────────────────────

class TestShouldAlert:
    def test_below_threshold_no_alert(self):
        vm = VelocityMonitor(window_seconds=10.0, cooldown_seconds=0)
        vm.record_batch(5, _now=100.0)
        assert not vm.should_alert(10, _now=100.0)

    def test_at_threshold_fires(self):
        vm = VelocityMonitor(window_seconds=10.0, cooldown_seconds=0)
        vm.record_batch(10, _now=100.0)
        assert vm.should_alert(10, _now=100.0)

    def test_above_threshold_fires(self):
        vm = VelocityMonitor(window_seconds=10.0, cooldown_seconds=0)
        vm.record_batch(50, _now=100.0)
        assert vm.should_alert(10, _now=100.0)

    def test_threshold_zero_never_fires(self):
        vm = VelocityMonitor(window_seconds=10.0, cooldown_seconds=0)
        vm.record_batch(100, _now=100.0)
        assert not vm.should_alert(0, _now=100.0)

    def test_negative_threshold_never_fires(self):
        vm = VelocityMonitor(window_seconds=10.0, cooldown_seconds=0)
        vm.record_batch(100, _now=100.0)
        assert not vm.should_alert(-5, _now=100.0)


# ── Cooldown ─────────────────────────────────────────────────────────

class TestCooldown:
    def test_cooldown_blocks_second_alert(self):
        vm = VelocityMonitor(window_seconds=60.0, cooldown_seconds=30.0)
        vm.record_batch(100, _now=100.0)
        assert vm.should_alert(10, _now=100.0)
        vm.record_batch(100, _now=110.0)
        assert not vm.should_alert(10, _now=110.0)

    def test_cooldown_expires_allows_alert(self):
        vm = VelocityMonitor(window_seconds=60.0, cooldown_seconds=30.0)
        vm.record_batch(100, _now=100.0)
        assert vm.should_alert(10, _now=100.0)
        vm.record_batch(100, _now=131.0)
        assert vm.should_alert(10, _now=131.0)

    def test_zero_cooldown_fires_every_time(self):
        vm = VelocityMonitor(window_seconds=60.0, cooldown_seconds=0)
        vm.record_batch(100, _now=100.0)
        assert vm.should_alert(10, _now=100.0)
        vm.record_batch(100, _now=101.0)
        assert vm.should_alert(10, _now=101.0)

    def test_suppressed_count_tracked(self):
        vm = VelocityMonitor(window_seconds=60.0, cooldown_seconds=30.0)
        vm.record_batch(100, _now=100.0)
        vm.should_alert(10, _now=100.0)
        for t in range(105, 130, 5):
            vm.record_batch(50, _now=float(t))
            vm.should_alert(10, _now=float(t))
        assert vm._suppressed > 0

    def test_suppressed_reset_on_alert(self):
        vm = VelocityMonitor(window_seconds=60.0, cooldown_seconds=10.0)
        vm.record_batch(100, _now=100.0)
        vm.should_alert(10, _now=100.0)
        vm.record_batch(100, _now=105.0)
        vm.should_alert(10, _now=105.0)  # suppressed
        vm.record_batch(100, _now=111.0)
        vm.should_alert(10, _now=111.0)  # fires, resets suppressed
        assert vm._suppressed == 0


# ── Stats ────────────────────────────────────────────────────────────

class TestStats:
    def test_alerts_fired_counter(self):
        vm = VelocityMonitor(window_seconds=60.0, cooldown_seconds=0)
        vm.record_batch(100, _now=100.0)
        vm.should_alert(10, _now=100.0)
        vm.should_alert(10, _now=101.0)
        assert vm.stats()["alerts_fired"] == 2

    def test_total_events(self):
        vm = VelocityMonitor(window_seconds=10.0)
        vm.record_batch(10, _now=100.0)
        vm.record_batch(20, _now=200.0)
        assert vm.stats()["total_events_since_start"] == 30

    def test_uptime(self):
        vm = VelocityMonitor()
        time.sleep(0.05)
        uptime = vm.stats()["uptime_seconds"]
        assert uptime >= 0.04


# ── Current rate ─────────────────────────────────────────────────────

class TestCurrentRate:
    def test_returns_window(self):
        vm = VelocityMonitor(window_seconds=42.0)
        events, window = vm.current_rate()
        assert window == 42.0
        assert events == 0


# ── Reset ────────────────────────────────────────────────────────────

class TestReset:
    def test_clears_everything(self):
        vm = VelocityMonitor(window_seconds=60.0, cooldown_seconds=0)
        vm.record_batch(100, _now=100.0)
        vm.should_alert(10, _now=100.0)
        vm.reset()
        assert vm.stats()["alerts_fired"] == 0
        assert vm.stats()["total_events_since_start"] == 0
        events, _ = vm.current_rate()
        assert events == 0


# ── Thread safety ────────────────────────────────────────────────────

class TestThreadSafety:
    def test_concurrent_record_batch(self):
        vm = VelocityMonitor(window_seconds=60.0, cooldown_seconds=0)
        errors: list[Exception] = []

        def worker():
            try:
                for _ in range(100):
                    vm.record_batch(1)
                    vm.should_alert(50)
            except Exception as exc:
                errors.append(exc)

        threads = [threading.Thread(target=worker) for _ in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors
        assert vm._total_events == 800


# ── VelocityAlert dataclass ──────────────────────────────────────────

class TestVelocityAlert:
    def test_immutable(self):
        alert = VelocityAlert(
            timestamp="2026-03-18T10:00:00+0100",
            events_in_window=150,
            window_seconds=300.0,
            threshold=100,
            cooldown_seconds=600.0,
            sample_paths=["a.txt", "b.txt"],
            event_counts={"created": 50, "modified": 100},
            alerts_fired=1,
            suppressed_since_last=3,
            total_events_since_start=500,
            uptime_seconds=1200.0,
        )
        with pytest.raises(dataclasses.FrozenInstanceError):
            alert.threshold = 200  # type: ignore[misc]

    def test_asdict(self):
        alert = VelocityAlert(
            timestamp="2026-03-18T10:00:00+0100",
            events_in_window=150,
            window_seconds=300.0,
            threshold=100,
            cooldown_seconds=600.0,
            sample_paths=["a.txt"],
            event_counts={"created": 150},
            alerts_fired=1,
            suppressed_since_last=0,
            total_events_since_start=150,
            uptime_seconds=60.0,
        )
        d = dataclasses.asdict(alert)
        assert d["events_in_window"] == 150
        assert d["sample_paths"] == ["a.txt"]
        assert isinstance(d, dict)
