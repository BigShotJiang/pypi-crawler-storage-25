"""Tests for git hook integration — install, uninstall, status, run."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from certisigma_census.cli import main
from certisigma_census.git_hooks import (
    HOOK_MARKER,
    HookConfig,
    HookResult,
    HookStatus,
    find_git_root,
    get_hook_status,
    install_hook,
    run_post_commit,
    uninstall_hook,
)


@pytest.fixture
def git_repo(tmp_path: Path) -> Path:
    """Create a minimal git repository for testing."""
    subprocess.run(["git", "init", str(tmp_path)], capture_output=True, check=True)
    subprocess.run(
        ["git", "config", "user.email", "test@test.com"],
        cwd=str(tmp_path), capture_output=True, check=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "Test"],
        cwd=str(tmp_path), capture_output=True, check=True,
    )
    (tmp_path / "hello.txt").write_text("hello world\n")
    subprocess.run(
        ["git", "add", "."], cwd=str(tmp_path), capture_output=True, check=True,
    )
    subprocess.run(
        ["git", "commit", "-m", "initial"],
        cwd=str(tmp_path), capture_output=True, check=True,
    )
    return tmp_path


# ── find_git_root ────────────────────────────────────────────────────────


class TestFindGitRoot:
    def test_finds_root(self, git_repo: Path) -> None:
        assert find_git_root(git_repo) == git_repo

    def test_finds_from_subdirectory(self, git_repo: Path) -> None:
        sub = git_repo / "a" / "b"
        sub.mkdir(parents=True)
        assert find_git_root(sub) == git_repo

    def test_returns_none_if_no_git(self, tmp_path: Path) -> None:
        assert find_git_root(tmp_path) is None


# ── install / uninstall ──────────────────────────────────────────────────


class TestInstallHook:
    def test_install_creates_hook(self, git_repo: Path) -> None:
        hook_path = install_hook(git_repo)
        assert hook_path.exists()
        assert hook_path.name == "post-commit"
        content = hook_path.read_text()
        assert HOOK_MARKER in content
        assert "certisigma_census" in content

    def test_hook_is_executable(self, git_repo: Path) -> None:
        hook_path = install_hook(git_repo)
        assert os.access(hook_path, os.X_OK)

    def test_reinstall_overwrites_census_hook(self, git_repo: Path) -> None:
        install_hook(git_repo)
        hook_path = install_hook(git_repo)
        assert hook_path.exists()

    def test_refuses_to_overwrite_foreign_hook(self, git_repo: Path) -> None:
        hooks_dir = git_repo / ".git" / "hooks"
        hooks_dir.mkdir(parents=True, exist_ok=True)
        foreign = hooks_dir / "post-commit"
        foreign.write_text("#!/bin/bash\necho 'custom hook'\n")
        with pytest.raises(FileExistsError, match="non-Census"):
            install_hook(git_repo)

    def test_raises_on_non_git_dir(self, tmp_path: Path) -> None:
        with pytest.raises(ValueError, match="Not a Git repository"):
            install_hook(tmp_path)

    def test_install_with_config(self, git_repo: Path) -> None:
        cfg = HookConfig(manifest_path="custom.db", source="ci", dry_run=True)
        hook_path = install_hook(git_repo, cfg)
        assert hook_path.exists()

    def test_creates_hooks_dir_if_missing(self, git_repo: Path) -> None:
        hooks = git_repo / ".git" / "hooks"
        if hooks.exists():
            import shutil
            shutil.rmtree(hooks)
        hook_path = install_hook(git_repo)
        assert hook_path.exists()


class TestUninstallHook:
    def test_uninstall_removes_hook(self, git_repo: Path) -> None:
        install_hook(git_repo)
        assert uninstall_hook(git_repo) is True
        hook_path = git_repo / ".git" / "hooks" / "post-commit"
        assert not hook_path.exists()

    def test_uninstall_returns_false_if_no_hook(self, git_repo: Path) -> None:
        assert uninstall_hook(git_repo) is False

    def test_uninstall_ignores_foreign_hook(self, git_repo: Path) -> None:
        hooks_dir = git_repo / ".git" / "hooks"
        hooks_dir.mkdir(parents=True, exist_ok=True)
        (hooks_dir / "post-commit").write_text("#!/bin/bash\necho custom\n")
        assert uninstall_hook(git_repo) is False

    def test_raises_on_non_git_dir(self, tmp_path: Path) -> None:
        with pytest.raises(ValueError, match="Not a Git repository"):
            uninstall_hook(tmp_path)


# ── get_hook_status ──────────────────────────────────────────────────────


class TestGetHookStatus:
    def test_status_not_installed(self, git_repo: Path) -> None:
        status = get_hook_status(git_repo)
        assert status.installed is False
        assert status.hook_path is None

    def test_status_installed(self, git_repo: Path) -> None:
        install_hook(git_repo)
        status = get_hook_status(git_repo)
        assert status.installed is True
        assert status.hook_path is not None
        assert "post-commit" in status.hook_path

    def test_status_non_git(self, tmp_path: Path) -> None:
        status = get_hook_status(tmp_path)
        assert status.installed is False


# ── HookConfig ───────────────────────────────────────────────────────────


class TestHookConfig:
    def test_default_values(self) -> None:
        cfg = HookConfig()
        assert cfg.manifest_path == ".census-manifest.db"
        assert cfg.source == "git-commit"
        assert cfg.dry_run is False
        assert cfg.timeout == 30

    def test_from_config(self) -> None:
        data = {
            "git_hook": {
                "manifest": "custom.db",
                "source": "ci-build",
                "dry_run": True,
                "timeout": 60,
            }
        }
        cfg = HookConfig.from_config(data)
        assert cfg.manifest_path == "custom.db"
        assert cfg.source == "ci-build"
        assert cfg.dry_run is True
        assert cfg.timeout == 60

    def test_from_empty_config(self) -> None:
        cfg = HookConfig.from_config({})
        assert cfg.manifest_path == ".census-manifest.db"

    def test_from_non_dict_section(self) -> None:
        cfg = HookConfig.from_config({"git_hook": "bad"})
        assert cfg.manifest_path == ".census-manifest.db"


# ── run_post_commit ──────────────────────────────────────────────────────


class TestRunPostCommit:
    def test_no_changed_files(self, git_repo: Path) -> None:
        result = run_post_commit(git_repo)
        assert result.success is True
        assert result.files_hashed == 0

    def test_hashes_changed_files(self, git_repo: Path) -> None:
        (git_repo / "new_file.txt").write_text("new content\n")
        subprocess.run(
            ["git", "add", "."], cwd=str(git_repo), capture_output=True, check=True,
        )
        subprocess.run(
            ["git", "commit", "-m", "add file"],
            cwd=str(git_repo), capture_output=True, check=True,
        )
        result = run_post_commit(git_repo)
        assert result.success is True
        assert result.files_hashed >= 1
        assert result.commit_sha != ""

    def test_creates_manifest(self, git_repo: Path) -> None:
        (git_repo / "tracked.txt").write_text("track me\n")
        subprocess.run(
            ["git", "add", "."], cwd=str(git_repo), capture_output=True, check=True,
        )
        subprocess.run(
            ["git", "commit", "-m", "add tracked"],
            cwd=str(git_repo), capture_output=True, check=True,
        )
        cfg = HookConfig(manifest_path=".census-manifest.db")
        result = run_post_commit(git_repo, cfg)
        assert result.success is True
        manifest_file = git_repo / ".census-manifest.db"
        assert manifest_file.exists()

    def test_dry_run_no_attest(self, git_repo: Path) -> None:
        (git_repo / "dry.txt").write_text("dry run\n")
        subprocess.run(
            ["git", "add", "."], cwd=str(git_repo), capture_output=True, check=True,
        )
        subprocess.run(
            ["git", "commit", "-m", "dry"],
            cwd=str(git_repo), capture_output=True, check=True,
        )
        cfg = HookConfig(dry_run=True)
        result = run_post_commit(git_repo, cfg, api_key="cs_test")
        assert result.files_attested == 0
        assert result.dry_run is True

    def test_skips_excluded_files(self, git_repo: Path) -> None:
        pycache = git_repo / "__pycache__"
        pycache.mkdir()
        (pycache / "mod.cpython-312.pyc").write_bytes(b"bytecode")
        (git_repo / "keep.txt").write_text("keep\n")
        subprocess.run(
            ["git", "add", "."], cwd=str(git_repo), capture_output=True, check=True,
        )
        subprocess.run(
            ["git", "commit", "-m", "mixed"],
            cwd=str(git_repo), capture_output=True, check=True,
        )
        cfg = HookConfig(exclude=["*.pyc", "__pycache__/**"])
        result = run_post_commit(git_repo, cfg)
        assert result.files_hashed >= 1

    def test_skips_when_watcher_running(self, git_repo: Path) -> None:
        pid_file = git_repo / ".census-watch.pid"
        pid_file.write_text(str(os.getpid()))
        (git_repo / "skip.txt").write_text("skip me\n")
        subprocess.run(
            ["git", "add", "."], cwd=str(git_repo), capture_output=True, check=True,
        )
        subprocess.run(
            ["git", "commit", "-m", "skip"],
            cwd=str(git_repo), capture_output=True, check=True,
        )
        result = run_post_commit(git_repo)
        assert result.success is True
        assert result.files_hashed == 0

    @patch("certisigma.CertiSigmaClient")
    def test_attests_with_api_key(self, mock_cls: MagicMock, git_repo: Path) -> None:
        mock_client = MagicMock()
        mock_cls.return_value = mock_client
        mock_client.batch_attest.return_value = MagicMock(results=[])

        (git_repo / "attest_me.txt").write_text("attest this\n")
        subprocess.run(
            ["git", "add", "."], cwd=str(git_repo), capture_output=True, check=True,
        )
        subprocess.run(
            ["git", "commit", "-m", "attest"],
            cwd=str(git_repo), capture_output=True, check=True,
        )
        result = run_post_commit(git_repo, api_key="cs_test_key")
        assert result.files_hashed >= 1

    def test_result_has_elapsed_seconds(self, git_repo: Path) -> None:
        result = run_post_commit(git_repo)
        assert result.elapsed_seconds >= 0


# ── CLI integration ──────────────────────────────────────────────────────

runner = CliRunner()


class TestGitHookCLI:
    def test_install_help(self) -> None:
        result = runner.invoke(main, ["git-hook", "install", "--help"])
        assert result.exit_code == 0
        assert "post-commit" in result.output.lower()

    def test_uninstall_help(self) -> None:
        result = runner.invoke(main, ["git-hook", "uninstall", "--help"])
        assert result.exit_code == 0

    def test_status_help(self) -> None:
        result = runner.invoke(main, ["git-hook", "status", "--help"])
        assert result.exit_code == 0

    def test_run_help(self) -> None:
        result = runner.invoke(main, ["git-hook", "run", "--help"])
        assert result.exit_code == 0

    def test_install_in_git_repo(self, git_repo: Path) -> None:
        result = runner.invoke(main, ["git-hook", "install", "--repo", str(git_repo)])
        assert result.exit_code == 0
        assert "installed" in result.output.lower()

    def test_install_json_output(self, git_repo: Path) -> None:
        result = runner.invoke(main, ["git-hook", "install", "--repo", str(git_repo), "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["installed"] is True
        assert "census_version" in data

    def test_uninstall_after_install(self, git_repo: Path) -> None:
        runner.invoke(main, ["git-hook", "install", "--repo", str(git_repo)])
        result = runner.invoke(main, ["git-hook", "uninstall", "--repo", str(git_repo)])
        assert result.exit_code == 0
        assert "removed" in result.output.lower()

    def test_status_not_installed(self, git_repo: Path) -> None:
        result = runner.invoke(main, ["git-hook", "status", "--repo", str(git_repo)])
        assert result.exit_code == 0
        assert "no census hook" in result.output.lower()

    def test_status_installed(self, git_repo: Path) -> None:
        runner.invoke(main, ["git-hook", "install", "--repo", str(git_repo)])
        result = runner.invoke(main, ["git-hook", "status", "--repo", str(git_repo)])
        assert result.exit_code == 0
        assert "installed" in result.output.lower()

    def test_status_json(self, git_repo: Path) -> None:
        runner.invoke(main, ["git-hook", "install", "--repo", str(git_repo)])
        result = runner.invoke(main, ["git-hook", "status", "--repo", str(git_repo), "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["installed"] is True
        assert "census_version" in data

    def test_run_no_changes(self, git_repo: Path) -> None:
        result = runner.invoke(main, ["git-hook", "run", "--repo", str(git_repo)])
        assert result.exit_code == 0
        assert "no changed files" in result.output.lower()

    def test_run_with_changes(self, git_repo: Path) -> None:
        (git_repo / "new.txt").write_text("new\n")
        subprocess.run(
            ["git", "add", "."], cwd=str(git_repo), capture_output=True, check=True,
        )
        subprocess.run(
            ["git", "commit", "-m", "new"],
            cwd=str(git_repo), capture_output=True, check=True,
        )
        result = runner.invoke(main, ["git-hook", "run", "--repo", str(git_repo)])
        assert result.exit_code == 0
        assert "files hashed" in result.output.lower()

    def test_run_json_output(self, git_repo: Path) -> None:
        result = runner.invoke(main, ["git-hook", "run", "--repo", str(git_repo), "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "files_hashed" in data
        assert "census_version" in data

    def test_install_not_git_repo(self, tmp_path: Path) -> None:
        result = runner.invoke(main, ["git-hook", "install", "--repo", str(tmp_path)])
        assert result.exit_code != 0

    def test_install_dry_run_flag(self, git_repo: Path) -> None:
        result = runner.invoke(main, [
            "git-hook", "install", "--repo", str(git_repo), "--dry-run",
        ])
        assert result.exit_code == 0
        assert "dry-run" in result.output.lower()

    def test_install_custom_manifest(self, git_repo: Path) -> None:
        result = runner.invoke(main, [
            "git-hook", "install", "--repo", str(git_repo),
            "--manifest", "custom.db",
        ])
        assert result.exit_code == 0

    def test_install_custom_source(self, git_repo: Path) -> None:
        result = runner.invoke(main, [
            "git-hook", "install", "--repo", str(git_repo),
            "--source", "ci-pipeline",
        ])
        assert result.exit_code == 0


# ── Security ─────────────────────────────────────────────────────────────


class TestGitHookSecurity:
    def test_hook_script_no_shell_injection(self, git_repo: Path) -> None:
        install_hook(git_repo)
        hook_path = git_repo / ".git" / "hooks" / "post-commit"
        content = hook_path.read_text()
        assert "shell=True" not in content
        assert "eval" not in content
        assert "os.system" not in content

    def test_hook_permissions_are_0755(self, git_repo: Path) -> None:
        hook_path = install_hook(git_repo)
        mode = os.stat(hook_path).st_mode
        assert mode & 0o755 == 0o755

    def test_max_files_per_hook_cap(self) -> None:
        from certisigma_census.git_hooks import MAX_FILES_PER_HOOK
        assert MAX_FILES_PER_HOOK <= 10000

    def test_hook_marker_in_script(self, git_repo: Path) -> None:
        install_hook(git_repo)
        hook_path = git_repo / ".git" / "hooks" / "post-commit"
        assert HOOK_MARKER in hook_path.read_text()

    def test_manifest_path_traversal_rejected(self, git_repo: Path) -> None:
        """manifest_path with ../../ must be rejected (containment check)."""
        (git_repo / "f.txt").write_text("x\n")
        subprocess.run(["git", "add", "."], cwd=str(git_repo), capture_output=True, check=True)
        subprocess.run(["git", "commit", "-m", "x"], cwd=str(git_repo), capture_output=True, check=True)
        cfg = HookConfig(manifest_path="../../escape.db")
        result = run_post_commit(git_repo, cfg)
        assert result.success is False
        assert any("escapes" in e for e in result.errors)

    def test_is_census_hook_rejects_large_file(self, git_repo: Path) -> None:
        """_is_census_hook must not read files > _MAX_HOOK_FILE_BYTES."""
        from certisigma_census.git_hooks import _is_census_hook, _MAX_HOOK_FILE_BYTES
        hooks_dir = git_repo / ".git" / "hooks"
        hooks_dir.mkdir(parents=True, exist_ok=True)
        big_file = hooks_dir / "post-commit"
        big_file.write_bytes(b"x" * (_MAX_HOOK_FILE_BYTES + 1))
        assert _is_census_hook(big_file) is False

    def test_config_timeout_clamped(self) -> None:
        """Timeout from config must be clamped to [1, 300]."""
        cfg = HookConfig.from_config({"git_hook": {"timeout": 9999}})
        assert cfg.timeout <= 300
        cfg2 = HookConfig.from_config({"git_hook": {"timeout": -5}})
        assert cfg2.timeout >= 1

    def test_config_timeout_non_numeric_fallback(self) -> None:
        """Non-numeric timeout falls back to default."""
        cfg = HookConfig.from_config({"git_hook": {"timeout": "bad"}})
        assert cfg.timeout == 30

    def test_config_boolean_timeout_rejected(self) -> None:
        """bool is a subclass of int — must not be accepted as timeout."""
        cfg = HookConfig.from_config({"git_hook": {"timeout": True}})
        assert cfg.timeout == 30

    def test_config_non_list_exclude_fallback(self) -> None:
        """Non-list exclude falls back to default."""
        cfg = HookConfig.from_config({"git_hook": {"exclude": "not-a-list"}})
        assert isinstance(cfg.exclude, list)
        assert len(cfg.exclude) > 0

    def test_run_json_exits_nonzero_on_errors(self, git_repo: Path) -> None:
        """--json mode must exit non-zero when there are errors."""
        (git_repo / "err.txt").write_text("e\n")
        subprocess.run(["git", "add", "."], cwd=str(git_repo), capture_output=True, check=True)
        subprocess.run(["git", "commit", "-m", "err"], cwd=str(git_repo), capture_output=True, check=True)
        cfg = HookConfig(manifest_path="../../escape.db")
        with patch("certisigma_census.git_hooks.HookConfig.from_config", return_value=cfg):
            result = runner.invoke(main, ["git-hook", "run", "--repo", str(git_repo), "--json"])
            assert result.exit_code != 0
