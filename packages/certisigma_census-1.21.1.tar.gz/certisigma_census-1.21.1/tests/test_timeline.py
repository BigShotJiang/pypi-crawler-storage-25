"""Tests for the forensic timeline — build, query, aggregate, export, CLI, security."""

from __future__ import annotations

import csv
import json
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from certisigma_census import __version__
from certisigma_census.audit_log import append_entry
from certisigma_census.cli import main
from certisigma_census.timeline import (
    AGGREGATION_WINDOWS,
    MAX_AUDIT_LOG_SIZE,
    MAX_QUERY_LIMIT,
    TimelineEvent,
    TimelineQuery,
    TimelineStats,
    _category_for,
    _sanitize_path,
    aggregate_timeline,
    build_timeline,
    export_bodyfile,
    export_case_json,
    export_csv,
    export_html,
    export_json,
    export_l2tcsv,
    parse_relative_time,
    parse_time_spec,
    query_timeline,
)


# ── Fixtures ─────────────────────────────────────────────────────────


@pytest.fixture()
def audit_log(tmp_path: Path) -> Path:
    """Create a sample audit log with several entries."""
    log = tmp_path / "audit.jsonl"
    append_entry("scan", {"directory": "/data", "source": "test"}, {"total_files": 10}, log_path=log)
    append_entry("scan.batch_attest", {"source": "test"}, {"attested": 5}, log_path=log)
    append_entry(
        "integrity.modified",
        {"path": "file_a.txt", "hash_hex": "ab" * 32},
        {"status": "modified"},
        log_path=log,
    )
    append_entry(
        "compare.match",
        {"path": "secret.doc", "hash_hex": "cd" * 32},
        {"matched": 1},
        log_path=log,
    )
    append_entry("verify", {"hash_hex": "ef" * 32}, {"status": "verified"}, log_path=log)
    return log


@pytest.fixture()
def timeline_dir(tmp_path: Path, audit_log: Path) -> Path:
    """Build a timeline and return the timeline directory."""
    tdir = tmp_path / "timeline"
    build_timeline(audit_log_path=audit_log, timeline_dir=tdir)
    return tdir


@pytest.fixture()
def sample_events() -> list[TimelineEvent]:
    """Return a list of sample TimelineEvent objects for export tests."""
    return [
        TimelineEvent(
            id=1,
            timestamp="2026-04-10T10:00:00+0000",
            unix_ts=1776070800.0,
            action="scan",
            category="scan",
            path="data/report.pdf",
            hash_hex="ab" * 32,
            attestation_id="att_1",
            detail="scan | source=test | files=10",
            source="test",
            audit_entry_hash="ff" * 32,
        ),
        TimelineEvent(
            id=2,
            timestamp="2026-04-10T10:05:00+0000",
            unix_ts=1776071100.0,
            action="integrity.modified",
            category="integrity",
            path="data/secret.doc",
            hash_hex="cd" * 32,
            attestation_id="",
            detail="integrity.modified | status=modified",
            source="test",
            audit_entry_hash="ee" * 32,
        ),
        TimelineEvent(
            id=3,
            timestamp="2026-04-10T10:10:00+0000",
            unix_ts=1776071400.0,
            action="alert.velocity",
            category="alert",
            path="",
            hash_hex="",
            attestation_id="",
            detail="alert.velocity | count=50",
            source="",
            audit_entry_hash="dd" * 32,
        ),
    ]


# ── Dataclass Tests ──────────────────────────────────────────────────


class TestTimelineEvent:
    def test_defaults(self):
        ev = TimelineEvent()
        assert ev.id == 0
        assert ev.timestamp == ""
        assert ev.category == ""
        assert ev.path == ""

    def test_full_construction(self):
        ev = TimelineEvent(
            id=42,
            timestamp="2026-01-01T00:00:00Z",
            unix_ts=1767225600.0,
            action="scan",
            category="scan",
            path="/data/file.txt",
            hash_hex="ab" * 32,
            attestation_id="att_1",
            detail="scan detail",
            source="test",
            audit_entry_hash="ff" * 32,
        )
        assert ev.id == 42
        assert ev.action == "scan"
        assert len(ev.hash_hex) == 64


class TestTimelineQuery:
    def test_defaults(self):
        q = TimelineQuery()
        assert q.start is None
        assert q.limit == 10000
        assert q.offset == 0
        assert q.window_seconds == 300

    def test_custom_fields(self):
        q = TimelineQuery(start=100.0, end=200.0, actions=["scan"], limit=50)
        assert q.start == 100.0
        assert q.actions == ["scan"]


class TestTimelineStats:
    def test_defaults(self):
        s = TimelineStats()
        assert s.total_events == 0
        assert s.time_range is None
        assert s.events_by_category == {}
        assert s.busiest_window == {}

    def test_serializable(self):
        s = TimelineStats(total_events=10, events_by_category={"scan": 5})
        d = asdict(s)
        assert d["total_events"] == 10


# ── Helper Tests ─────────────────────────────────────────────────────


class TestCategoryFor:
    def test_scan(self):
        assert _category_for("scan") == "scan"
        assert _category_for("scan.batch_attest") == "scan"

    def test_integrity(self):
        assert _category_for("integrity.modified") == "integrity"

    def test_alert(self):
        assert _category_for("alert.velocity") == "alert"
        assert _category_for("velocity_alert") == "alert"

    def test_admin(self):
        assert _category_for("annotate") == "admin"
        assert _category_for("key_rotate") == "admin"

    def test_unknown(self):
        assert _category_for("unknown_action_xyz") == "admin"

    def test_empty(self):
        assert _category_for("") == "admin"


class TestSanitizePath:
    def test_strips_control_chars(self):
        assert _sanitize_path("file\x00name.txt") == "filename.txt"
        assert _sanitize_path("dir\x1b[31m/file") == "dir[31m/file"

    def test_strips_pipe(self):
        assert _sanitize_path("file|name.txt") == "file_name.txt"

    def test_truncates_long(self):
        long = "a" * 5000
        result = _sanitize_path(long)
        assert len(result) == 4096

    def test_passthrough_normal(self):
        assert _sanitize_path("data/report.pdf") == "data/report.pdf"

    def test_unicode(self):
        assert _sanitize_path("données/résumé.pdf") == "données/résumé.pdf"


class TestParseRelativeTime:
    def test_hours(self):
        import time as t
        result = parse_relative_time("-1h")
        assert abs(result - (t.time() - 3600)) < 2

    def test_days(self):
        import time as t
        result = parse_relative_time("-7d")
        assert abs(result - (t.time() - 7 * 86400)) < 2

    def test_minutes(self):
        import time as t
        result = parse_relative_time("-30m")
        assert abs(result - (t.time() - 1800)) < 2

    def test_seconds(self):
        import time as t
        result = parse_relative_time("-60s")
        assert abs(result - (t.time() - 60)) < 2

    def test_invalid(self):
        with pytest.raises(ValueError, match="Invalid relative time"):
            parse_relative_time("1h")

    def test_invalid_unit(self):
        with pytest.raises(ValueError, match="Invalid relative time"):
            parse_relative_time("-1x")


class TestParseTimeSpec:
    def test_iso_full(self):
        ts = parse_time_spec("2026-04-10T10:00:00+0000")
        assert ts > 0

    def test_iso_date_only(self):
        ts = parse_time_spec("2026-04-10")
        assert ts > 0

    def test_relative(self):
        ts = parse_time_spec("-1h")
        assert ts > 0

    def test_invalid(self):
        with pytest.raises(ValueError, match="Cannot parse time"):
            parse_time_spec("not-a-time")


# ── Build Tests ──────────────────────────────────────────────────────


class TestBuildTimeline:
    def test_build_from_audit_log(self, audit_log: Path, tmp_path: Path):
        tdir = tmp_path / "tl"
        stats = build_timeline(audit_log_path=audit_log, timeline_dir=tdir)
        assert stats.total_events == 5
        assert (tdir / "timeline.db").exists()

    def test_incremental_build(self, audit_log: Path, tmp_path: Path):
        tdir = tmp_path / "tl"
        stats1 = build_timeline(audit_log_path=audit_log, timeline_dir=tdir)
        append_entry("annotate", {"note": "extra"}, log_path=audit_log)
        stats2 = build_timeline(audit_log_path=audit_log, timeline_dir=tdir)
        assert stats2.total_events == stats1.total_events + 1

    def test_rebuild_mode(self, audit_log: Path, tmp_path: Path):
        tdir = tmp_path / "tl"
        build_timeline(audit_log_path=audit_log, timeline_dir=tdir)
        append_entry("extra", log_path=audit_log)
        stats = build_timeline(audit_log_path=audit_log, timeline_dir=tdir, rebuild=True)
        assert stats.total_events == 6

    def test_empty_audit_log(self, tmp_path: Path):
        log = tmp_path / "empty.jsonl"
        log.touch()
        tdir = tmp_path / "tl"
        stats = build_timeline(audit_log_path=log, timeline_dir=tdir)
        assert stats.total_events == 0

    def test_nonexistent_audit_log(self, tmp_path: Path):
        log = tmp_path / "nonexistent.jsonl"
        tdir = tmp_path / "tl"
        stats = build_timeline(audit_log_path=log, timeline_dir=tdir)
        assert stats.total_events == 0

    def test_corrupt_entries_skipped(self, tmp_path: Path):
        log = tmp_path / "corrupt.jsonl"
        e = append_entry("scan", log_path=log)
        with log.open("a") as f:
            f.write("NOT JSON\n")
        append_entry("verify", log_path=log)
        tdir = tmp_path / "tl"
        stats = build_timeline(audit_log_path=log, timeline_dir=tdir)
        assert stats.total_events >= 1

    def test_size_cap_enforcement(self, tmp_path: Path):
        log = tmp_path / "big.jsonl"
        log.touch()
        with patch("certisigma_census.timeline.MAX_AUDIT_LOG_SIZE", 10):
            log.write_text("x" * 100)
            tdir = tmp_path / "tl"
            with pytest.raises(ValueError, match="too large"):
                build_timeline(audit_log_path=log, timeline_dir=tdir)

    def test_manifest_enrichment(self, audit_log: Path, tmp_path: Path):
        from certisigma_census.manifest import Manifest, ManifestEntry

        mp = tmp_path / "manifest.db"
        m = Manifest(root_dir="/data")
        m.add(ManifestEntry(
            hash_hex="ab" * 32,
            path="enriched_file.txt",
            size=100,
            mtime=1000.0,
            attested=True,
            attestation_id="att_99",
        ))
        m.save(mp)
        m.close()

        tdir = tmp_path / "tl"
        build_timeline(audit_log_path=audit_log, manifest_path=mp, timeline_dir=tdir)

        events = query_timeline(tdir)
        enriched = [e for e in events if e.hash_hex == "ab" * 32]
        assert len(enriched) >= 1
        assert enriched[0].attestation_id == "att_99"

    def test_db_permissions(self, audit_log: Path, tmp_path: Path):
        tdir = tmp_path / "tl"
        build_timeline(audit_log_path=audit_log, timeline_dir=tdir)
        db = tdir / "timeline.db"
        mode = db.stat().st_mode & 0o777
        assert mode == 0o600


# ── Query Tests ──────────────────────────────────────────────────────


class TestQueryTimeline:
    def test_no_filters(self, timeline_dir: Path):
        events = query_timeline(timeline_dir)
        assert len(events) == 5

    def test_time_range(self, timeline_dir: Path):
        events = query_timeline(timeline_dir)
        if len(events) >= 2:
            mid = events[len(events) // 2].unix_ts
            q = TimelineQuery(start=mid)
            filtered = query_timeline(timeline_dir, q)
            assert len(filtered) <= len(events)

    def test_action_prefix(self, timeline_dir: Path):
        q = TimelineQuery(actions=["scan"])
        events = query_timeline(timeline_dir, q)
        assert all(e.action.startswith("scan") for e in events)

    def test_action_multiple(self, timeline_dir: Path):
        q = TimelineQuery(actions=["scan", "compare"])
        events = query_timeline(timeline_dir, q)
        assert all(
            e.action.startswith("scan") or e.action.startswith("compare")
            for e in events
        )

    def test_hash_exact(self, timeline_dir: Path):
        h = "ab" * 32
        q = TimelineQuery(hash_hex=h)
        events = query_timeline(timeline_dir, q)
        assert all(e.hash_hex == h for e in events)

    def test_attested_only(self, timeline_dir: Path):
        q = TimelineQuery(attested_only=True)
        events = query_timeline(timeline_dir, q)
        assert all(e.attestation_id != "" for e in events)

    def test_unattested_only(self, timeline_dir: Path):
        q = TimelineQuery(unattested_only=True)
        events = query_timeline(timeline_dir, q)
        assert all(e.attestation_id == "" for e in events)

    def test_limit(self, timeline_dir: Path):
        q = TimelineQuery(limit=2)
        events = query_timeline(timeline_dir, q)
        assert len(events) <= 2

    def test_offset(self, timeline_dir: Path):
        all_events = query_timeline(timeline_dir)
        q = TimelineQuery(offset=2)
        events = query_timeline(timeline_dir, q)
        assert len(events) == len(all_events) - 2

    def test_around_window(self, timeline_dir: Path):
        all_events = query_timeline(timeline_dir)
        if all_events:
            anchor = all_events[0].unix_ts
            q = TimelineQuery(around=anchor, window_seconds=1)
            events = query_timeline(timeline_dir, q)
            assert len(events) >= 1

    def test_path_pattern(self, timeline_dir: Path):
        q = TimelineQuery(path_pattern="*.txt")
        events = query_timeline(timeline_dir, q)
        for ev in events:
            assert ev.path.endswith(".txt") or "%" in ev.path or ev.path == ""

    def test_empty_results(self, timeline_dir: Path):
        q = TimelineQuery(hash_hex="00" * 32)
        events = query_timeline(timeline_dir, q)
        assert events == []

    def test_limit_capped(self, timeline_dir: Path):
        q = TimelineQuery(limit=MAX_QUERY_LIMIT + 100)
        events = query_timeline(timeline_dir, q)
        assert len(events) <= MAX_QUERY_LIMIT

    def test_missing_db(self, tmp_path: Path):
        with pytest.raises(FileNotFoundError):
            query_timeline(tmp_path / "nonexistent")

    def test_combined_filters(self, timeline_dir: Path):
        q = TimelineQuery(actions=["scan"], limit=1)
        events = query_timeline(timeline_dir, q)
        assert len(events) <= 1
        if events:
            assert events[0].action.startswith("scan")


# ── Aggregation Tests ────────────────────────────────────────────────


class TestAggregateTimeline:
    def test_hourly_window(self, timeline_dir: Path):
        stats = aggregate_timeline(timeline_dir, 3600)
        assert stats.total_events == 5

    def test_minute_window(self, timeline_dir: Path):
        stats = aggregate_timeline(timeline_dir, 60)
        assert stats.total_events == 5

    def test_daily_window(self, timeline_dir: Path):
        stats = aggregate_timeline(timeline_dir, 86400)
        assert stats.total_events == 5

    def test_busiest_window(self, timeline_dir: Path):
        stats = aggregate_timeline(timeline_dir, 3600)
        if stats.busiest_window:
            assert "count" in stats.busiest_window
            assert stats.busiest_window["count"] > 0

    def test_filtered_aggregation(self, timeline_dir: Path):
        q = TimelineQuery(actions=["scan"])
        stats = aggregate_timeline(timeline_dir, 3600, query=q)
        assert stats.total_events <= 5

    def test_categories(self, timeline_dir: Path):
        stats = aggregate_timeline(timeline_dir, 3600)
        assert isinstance(stats.events_by_category, dict)

    def test_missing_db(self, tmp_path: Path):
        with pytest.raises(FileNotFoundError):
            aggregate_timeline(tmp_path / "nonexistent")


# ── Export: Body File Tests ──────────────────────────────────────────


class TestExportBodyfile:
    def test_format(self, sample_events: list[TimelineEvent], tmp_path: Path):
        out = tmp_path / "timeline.bodyfile"
        count = export_bodyfile(sample_events, out)
        assert count == 3
        lines = out.read_text().strip().split("\n")
        assert len(lines) == 3
        for line in lines:
            fields = line.split("|")
            assert len(fields) == 11
            assert fields[0] == "0"

    def test_sha256_in_name(self, sample_events: list[TimelineEvent], tmp_path: Path):
        out = tmp_path / "timeline.bodyfile"
        export_bodyfile(sample_events, out)
        content = out.read_text()
        assert "[SHA256:" in content

    def test_empty_events(self, tmp_path: Path):
        out = tmp_path / "empty.bodyfile"
        count = export_bodyfile([], out)
        assert count == 0
        assert out.read_text() == ""

    def test_sanitized_paths(self, tmp_path: Path):
        events = [TimelineEvent(
            id=1, timestamp="t", unix_ts=100.0, action="scan",
            category="scan", path="file|with|pipes\x00null.txt",
        )]
        out = tmp_path / "sanitized.bodyfile"
        export_bodyfile(events, out)
        content = out.read_text()
        assert "|" not in content.split("|", 1)[1].split("|")[0] or "file_with_pipes" in content

    def test_permissions(self, sample_events: list[TimelineEvent], tmp_path: Path):
        out = tmp_path / "timeline.bodyfile"
        export_bodyfile(sample_events, out)
        mode = out.stat().st_mode & 0o777
        assert mode == 0o600


# ── Export: l2tcsv Tests ─────────────────────────────────────────────


class TestExportL2tcsv:
    def test_header(self, sample_events: list[TimelineEvent], tmp_path: Path):
        out = tmp_path / "timeline.csv"
        count = export_l2tcsv(sample_events, out)
        assert count == 3
        with open(out, newline="") as f:
            reader = csv.reader(f)
            header = next(reader)
            assert len(header) == 17
            assert header[0] == "date"
            assert header[4] == "source"

    def test_17_fields(self, sample_events: list[TimelineEvent], tmp_path: Path):
        out = tmp_path / "timeline.csv"
        export_l2tcsv(sample_events, out)
        with open(out, newline="") as f:
            reader = csv.reader(f)
            next(reader)
            for row in reader:
                assert len(row) == 17

    def test_empty_events(self, tmp_path: Path):
        out = tmp_path / "empty.csv"
        count = export_l2tcsv([], out)
        assert count == 0

    def test_source_field(self, sample_events: list[TimelineEvent], tmp_path: Path):
        out = tmp_path / "timeline.csv"
        export_l2tcsv(sample_events, out)
        with open(out, newline="") as f:
            reader = csv.reader(f)
            next(reader)
            row = next(reader)
            assert row[4] == "CENSUS"
            assert row[5] == "CertiSigma Census"


# ── Export: CASE/UCO Tests ───────────────────────────────────────────


class TestExportCaseJson:
    def test_valid_jsonld(self, sample_events: list[TimelineEvent], tmp_path: Path):
        out = tmp_path / "case.json"
        count = export_case_json(sample_events, out, case_name="Test Case")
        assert count > 0
        doc = json.loads(out.read_text())
        assert "@context" in doc
        assert "@graph" in doc
        assert isinstance(doc["@graph"], list)

    def test_uco_namespaces(self, sample_events: list[TimelineEvent], tmp_path: Path):
        out = tmp_path / "case.json"
        export_case_json(sample_events, out)
        doc = json.loads(out.read_text())
        ctx = doc["@context"]
        assert "uco-core" in ctx
        assert "uco-observable" in ctx
        assert "uco-types" in ctx

    def test_investigation_node(self, sample_events: list[TimelineEvent], tmp_path: Path):
        out = tmp_path / "case.json"
        export_case_json(sample_events, out, case_name="My Case", examiner="Dr. Smith")
        doc = json.loads(out.read_text())
        inv = doc["@graph"][0]
        assert inv["@type"] == "case-investigation:Investigation"
        assert "My Case" in inv["uco-core:name"]
        assert "Dr. Smith" in inv.get("uco-core:description", "")

    def test_uuid5_deterministic(self, sample_events: list[TimelineEvent], tmp_path: Path):
        out1 = tmp_path / "case1.json"
        out2 = tmp_path / "case2.json"
        export_case_json(sample_events, out1, case_name="Test")
        export_case_json(sample_events, out2, case_name="Test")
        doc1 = json.loads(out1.read_text())
        doc2 = json.loads(out2.read_text())
        ids1 = [n["@id"] for n in doc1["@graph"]]
        ids2 = [n["@id"] for n in doc2["@graph"]]
        assert ids1 == ids2

    def test_hash_objects(self, sample_events: list[TimelineEvent], tmp_path: Path):
        out = tmp_path / "case.json"
        export_case_json(sample_events, out)
        content = out.read_text()
        assert "SHA256" in content
        assert "xsd:hexBinary" in content

    def test_html_escape_in_values(self, tmp_path: Path):
        events = [TimelineEvent(
            id=1, timestamp="t", unix_ts=100.0,
            action="scan",
            category="scan",
            path='<script>alert("xss")</script>',
            detail='<img onerror="alert(1)">',
            audit_entry_hash="aa" * 32,
        )]
        out = tmp_path / "xss.json"
        export_case_json(events, out)
        content = out.read_text()
        assert "<script>" not in content
        assert "&lt;script&gt;" in content

    def test_empty_events(self, tmp_path: Path):
        out = tmp_path / "empty.json"
        count = export_case_json([], out)
        assert count == 1  # investigation node only


# ── Export: HTML Tests ───────────────────────────────────────────────


class TestExportHtml:
    def test_structure(self, sample_events: list[TimelineEvent], tmp_path: Path):
        out = tmp_path / "timeline.html"
        stats = TimelineStats(
            total_events=3,
            events_by_category={"scan": 1, "integrity": 1, "alert": 1},
            time_range=("2026-04-10T10:00:00", "2026-04-10T10:10:00"),
        )
        count = export_html(sample_events, out, title="Test", stats=stats)
        assert count == 3
        content = out.read_text()
        assert "CertiSigma Census" in content
        assert "Forensic Timeline" in content

    def test_css_variables(self, sample_events: list[TimelineEvent], tmp_path: Path):
        out = tmp_path / "timeline.html"
        export_html(sample_events, out)
        content = out.read_text()
        assert "--bg: #fafbfc" in content
        assert "--accent: #0f3460" in content
        assert "--fg: #1a1a2e" in content

    def test_xss_prevention(self, tmp_path: Path):
        events = [TimelineEvent(
            id=1, timestamp="t", unix_ts=100.0,
            action='<script>alert("xss")</script>',
            category="scan",
            path='"><img onerror=alert(1)>',
            detail="normal",
        )]
        out = tmp_path / "xss.html"
        export_html(events, out)
        content = out.read_text()
        assert "<script>" not in content
        assert "&lt;script&gt;" in content
        assert '"><img' not in content

    def test_empty_events(self, tmp_path: Path):
        out = tmp_path / "empty.html"
        count = export_html([], out)
        assert count == 0
        assert out.exists()

    def test_category_badges(self, sample_events: list[TimelineEvent], tmp_path: Path):
        out = tmp_path / "timeline.html"
        stats = TimelineStats(
            total_events=3,
            events_by_category={"scan": 1, "integrity": 1, "alert": 1},
        )
        export_html(sample_events, out, stats=stats)
        content = out.read_text()
        assert "cat-scan" in content
        assert "cat-integrity" in content


# ── Export: JSON / CSV Tests ─────────────────────────────────────────


class TestExportJson:
    def test_structure(self, sample_events: list[TimelineEvent], tmp_path: Path):
        out = tmp_path / "timeline.json"
        count = export_json(sample_events, out)
        assert count == 3
        doc = json.loads(out.read_text())
        assert "events" in doc
        assert "census_version" in doc
        assert len(doc["events"]) == 3

    def test_empty(self, tmp_path: Path):
        out = tmp_path / "empty.json"
        count = export_json([], out)
        assert count == 0


class TestExportCsv:
    def test_header_and_rows(self, sample_events: list[TimelineEvent], tmp_path: Path):
        out = tmp_path / "timeline.csv"
        count = export_csv(sample_events, out)
        assert count == 3
        with open(out, newline="") as f:
            reader = csv.reader(f)
            header = next(reader)
            assert "timestamp" in header
            assert "action" in header
            rows = list(reader)
            assert len(rows) == 3

    def test_empty(self, tmp_path: Path):
        out = tmp_path / "empty.csv"
        count = export_csv([], out)
        assert count == 0


# ── CLI Integration Tests ────────────────────────────────────────────


class TestTimelineCLI:
    def _build_log(self, tmp_path: Path) -> tuple[Path, Path]:
        log = tmp_path / "audit.jsonl"
        append_entry("scan", {"directory": "/data"}, {"total_files": 5}, log_path=log)
        append_entry("verify", {"hash_hex": "ab" * 32}, log_path=log)
        tdir = tmp_path / "tl"
        return log, tdir

    def test_build_json(self, tmp_path: Path):
        log, tdir = self._build_log(tmp_path)
        runner = CliRunner()
        result = runner.invoke(main, [
            "timeline", "build",
            "--audit-log", str(log),
            "--timeline-dir", str(tdir),
            "--json",
        ])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "census_version" in data
        assert data["total_events"] == 2

    def test_build_text(self, tmp_path: Path):
        log, tdir = self._build_log(tmp_path)
        runner = CliRunner()
        result = runner.invoke(main, [
            "timeline", "build",
            "--audit-log", str(log),
            "--timeline-dir", str(tdir),
        ])
        assert result.exit_code == 0
        assert "Timeline built" in result.output

    def test_build_rebuild(self, tmp_path: Path):
        log, tdir = self._build_log(tmp_path)
        runner = CliRunner()
        runner.invoke(main, [
            "timeline", "build", "--audit-log", str(log), "--timeline-dir", str(tdir),
        ])
        result = runner.invoke(main, [
            "timeline", "build", "--audit-log", str(log),
            "--timeline-dir", str(tdir), "--rebuild", "--json",
        ])
        assert result.exit_code == 0

    def test_query_json(self, tmp_path: Path):
        log, tdir = self._build_log(tmp_path)
        runner = CliRunner()
        runner.invoke(main, [
            "timeline", "build", "--audit-log", str(log), "--timeline-dir", str(tdir),
        ])
        result = runner.invoke(main, [
            "timeline", "query", "--timeline-dir", str(tdir), "--json",
        ])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "events" in data
        assert "census_version" in data

    def test_query_text(self, tmp_path: Path):
        log, tdir = self._build_log(tmp_path)
        runner = CliRunner()
        runner.invoke(main, [
            "timeline", "build", "--audit-log", str(log), "--timeline-dir", str(tdir),
        ])
        result = runner.invoke(main, [
            "timeline", "query", "--timeline-dir", str(tdir),
        ])
        assert result.exit_code == 0
        assert "events" in result.output.lower()

    def test_query_jsonl(self, tmp_path: Path):
        log, tdir = self._build_log(tmp_path)
        runner = CliRunner()
        runner.invoke(main, [
            "timeline", "build", "--audit-log", str(log), "--timeline-dir", str(tdir),
        ])
        result = runner.invoke(main, [
            "timeline", "query", "--timeline-dir", str(tdir), "--format", "jsonl",
        ])
        assert result.exit_code == 0
        lines = result.output.strip().split("\n")
        last = json.loads(lines[-1])
        assert last.get("_summary") is True

    def test_query_bodyfile(self, tmp_path: Path):
        log, tdir = self._build_log(tmp_path)
        runner = CliRunner()
        runner.invoke(main, [
            "timeline", "build", "--audit-log", str(log), "--timeline-dir", str(tdir),
        ])
        out = tmp_path / "out.bodyfile"
        result = runner.invoke(main, [
            "timeline", "query", "--timeline-dir", str(tdir),
            "--format", "bodyfile", "--output", str(out),
        ])
        assert result.exit_code == 0
        assert out.exists()

    def test_query_html(self, tmp_path: Path):
        log, tdir = self._build_log(tmp_path)
        runner = CliRunner()
        runner.invoke(main, [
            "timeline", "build", "--audit-log", str(log), "--timeline-dir", str(tdir),
        ])
        out = tmp_path / "out.html"
        result = runner.invoke(main, [
            "timeline", "query", "--timeline-dir", str(tdir),
            "--format", "html", "--output", str(out),
        ])
        assert result.exit_code == 0
        assert out.exists()

    def test_query_case_json(self, tmp_path: Path):
        log, tdir = self._build_log(tmp_path)
        runner = CliRunner()
        runner.invoke(main, [
            "timeline", "build", "--audit-log", str(log), "--timeline-dir", str(tdir),
        ])
        out = tmp_path / "case.json"
        result = runner.invoke(main, [
            "timeline", "query", "--timeline-dir", str(tdir),
            "--format", "case-json", "--output", str(out),
            "--case-name", "TestCase", "--examiner", "Dr. Test",
        ])
        assert result.exit_code == 0
        doc = json.loads(out.read_text())
        assert "@context" in doc

    def test_query_invalid_hash(self, tmp_path: Path):
        log, tdir = self._build_log(tmp_path)
        runner = CliRunner()
        runner.invoke(main, [
            "timeline", "build", "--audit-log", str(log), "--timeline-dir", str(tdir),
        ])
        result = runner.invoke(main, [
            "timeline", "query", "--timeline-dir", str(tdir),
            "--hash", "not-a-hash",
        ])
        assert result.exit_code != 0

    def test_query_missing_db(self, tmp_path: Path):
        runner = CliRunner()
        result = runner.invoke(main, [
            "timeline", "query", "--timeline-dir", str(tmp_path / "nope"),
        ])
        assert result.exit_code != 0

    def test_stats_json(self, tmp_path: Path):
        log, tdir = self._build_log(tmp_path)
        runner = CliRunner()
        runner.invoke(main, [
            "timeline", "build", "--audit-log", str(log), "--timeline-dir", str(tdir),
        ])
        result = runner.invoke(main, [
            "timeline", "stats", "--timeline-dir", str(tdir), "--json",
        ])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "census_version" in data
        assert "total_events" in data

    def test_stats_text(self, tmp_path: Path):
        log, tdir = self._build_log(tmp_path)
        runner = CliRunner()
        runner.invoke(main, [
            "timeline", "build", "--audit-log", str(log), "--timeline-dir", str(tdir),
        ])
        result = runner.invoke(main, [
            "timeline", "stats", "--timeline-dir", str(tdir),
        ])
        assert result.exit_code == 0
        assert "Total events" in result.output

    def test_json_output_purity(self, tmp_path: Path):
        log, tdir = self._build_log(tmp_path)
        runner = CliRunner()
        runner.invoke(main, [
            "timeline", "build", "--audit-log", str(log), "--timeline-dir", str(tdir),
        ])
        result = runner.invoke(main, [
            "timeline", "query", "--timeline-dir", str(tdir), "--json",
        ])
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert isinstance(parsed, dict)

    def test_quiet_suppresses(self, tmp_path: Path):
        log, tdir = self._build_log(tmp_path)
        runner = CliRunner()
        result = runner.invoke(main, [
            "-q", "timeline", "build",
            "--audit-log", str(log), "--timeline-dir", str(tdir),
        ])
        assert result.exit_code == 0
        assert result.output.strip() == ""


# ── Security Tests ───────────────────────────────────────────────────


class TestTimelineSecurity:
    def test_sql_injection_path(self, timeline_dir: Path):
        """Parameterized queries prevent SQL injection via --path."""
        q = TimelineQuery(path_pattern="'; DROP TABLE events; --")
        events = query_timeline(timeline_dir, q)
        all_events = query_timeline(timeline_dir)
        assert len(all_events) == 5

    def test_sql_injection_action(self, timeline_dir: Path):
        """Parameterized queries prevent SQL injection via --action."""
        q = TimelineQuery(actions=["scan'; DROP TABLE events; --"])
        events = query_timeline(timeline_dir, q)
        all_events = query_timeline(timeline_dir)
        assert len(all_events) == 5

    def test_sql_injection_hash(self, timeline_dir: Path):
        """Parameterized queries prevent SQL injection via --hash."""
        q = TimelineQuery(hash_hex="ab" * 32)
        events = query_timeline(timeline_dir, q)
        all_events = query_timeline(timeline_dir)
        assert len(all_events) == 5

    def test_xss_in_html_export(self, sample_events: list[TimelineEvent], tmp_path: Path):
        events = list(sample_events)
        events[0] = TimelineEvent(
            id=99, timestamp="t", unix_ts=100.0,
            action="scan", category="scan",
            path='<script>alert("xss")</script>',
            hash_hex="ab" * 32,
            detail='"><img src=x onerror=alert(1)>',
        )
        out = tmp_path / "xss.html"
        export_html(events, out)
        content = out.read_text()
        assert "<script>" not in content
        assert "&lt;script&gt;" in content
        assert '"><img' not in content
        assert "&quot;&gt;&lt;img" in content

    def test_bodyfile_pipe_injection(self, tmp_path: Path):
        events = [TimelineEvent(
            id=1, timestamp="t", unix_ts=100.0,
            action="scan", category="scan",
            path="file|with|pipes.txt",
        )]
        out = tmp_path / "inj.bodyfile"
        export_bodyfile(events, out)
        content = out.read_text()
        fields = content.strip().split("|")
        assert len(fields) == 11
