"""Tests for CI/CD workflow files — validates structure, security, and hardening.

Covers:
  - publish.yml: version validation, OIDC, PyPI upload
  - homebrew.yml: post-publish formula update (workflow_run), PyPI wait, push retry
  - docker.yml: version validation, PyPI wait, GHCR push
  - test.yml: matrix, mypy, coverage
  - All workflows: Node.js 24 opt-in, no hardcoded secrets
"""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml

WORKFLOW_DIR = Path(__file__).resolve().parent.parent / ".github" / "workflows"


def _load(name: str) -> dict:
    text = (WORKFLOW_DIR / name).read_text(encoding="utf-8")
    parsed = yaml.safe_load(text)
    assert isinstance(parsed, dict)
    return parsed


def _raw(name: str) -> str:
    return (WORKFLOW_DIR / name).read_text(encoding="utf-8")


@pytest.fixture(scope="module")
def publish() -> dict:
    return _load("publish.yml")


@pytest.fixture(scope="module")
def docker() -> dict:
    return _load("docker.yml")


@pytest.fixture(scope="module")
def test_wf() -> dict:
    return _load("test.yml")


@pytest.fixture(scope="module")
def homebrew() -> dict:
    return _load("homebrew.yml")


class TestPublishWorkflow:
    """Validate publish.yml structure and hardening."""

    def test_triggers_on_semver_tag(self, publish: dict) -> None:
        on = publish.get("on") or publish.get(True, {})
        tags = on.get("push", {}).get("tags", [])
        assert any("v[0-9]" in t for t in tags)

    def test_publish_job_has_oidc(self, publish: dict) -> None:
        perms = publish["jobs"]["publish"].get("permissions", {})
        assert perms.get("id-token") == "write"

    def test_publish_job_has_version_validation(self) -> None:
        raw = _raw("publish.yml")
        assert "Validate tag format" in raw or "grep -qE" in raw

    def test_publish_job_has_version_consistency_check(self) -> None:
        raw = _raw("publish.yml")
        assert "__version__" in raw, "publish.yml must verify __version__ matches tag"

    def test_publish_job_has_artifact_verification(self) -> None:
        raw = _raw("publish.yml")
        assert "Verify built artifacts" in raw or ".whl" in raw

    def test_publish_only_upload_job(self, publish: dict) -> None:
        assert set(publish["jobs"].keys()) == {"publish"}, "Homebrew must be a separate workflow so Docker runs on PyPI success"

    def test_no_hardcoded_api_tokens(self) -> None:
        raw = _raw("publish.yml")
        assert "TWINE_PASSWORD" not in raw
        assert "TWINE_USERNAME" not in raw

    def test_no_inputs_interpolation_in_run(self) -> None:
        raw = _raw("publish.yml")
        assert "${{ inputs." not in raw

    def test_node24_env(self, publish: dict) -> None:
        env = publish.get("env", {})
        assert env.get("FORCE_JAVASCRIPT_ACTIONS_TO_NODE24") is True


class TestHomebrewWorkflow:
    """Validate homebrew.yml — runs after successful PyPI publish."""

    def test_triggers_on_publish_workflow_run(self, homebrew: dict) -> None:
        on = homebrew.get("on") or homebrew.get(True, {})
        wfr = on.get("workflow_run", {})
        assert "Publish to PyPI" in wfr.get("workflows", [])

    def test_runs_only_when_publish_succeeds(self, homebrew: dict) -> None:
        job = homebrew["jobs"]["update-homebrew"]
        assert "success" in job.get("if", "")

    def test_resolves_version_from_init(self) -> None:
        raw = _raw("homebrew.yml")
        assert "__init__.py" in raw and "__version__" in raw

    def test_has_push_retry(self) -> None:
        raw = _raw("homebrew.yml")
        assert "attempt" in raw

    def test_has_rebase_before_staging(self) -> None:
        raw = _raw("homebrew.yml")
        assert "pull --rebase" in raw
        assert "git add contrib/homebrew/certisigma-census.rb" in raw

    def test_pypi_wait_has_explicit_failure(self) -> None:
        raw = _raw("homebrew.yml")
        assert "FOUND" in raw

    def test_node24_env(self, homebrew: dict) -> None:
        env = homebrew.get("env", {})
        assert env.get("FORCE_JAVASCRIPT_ACTIONS_TO_NODE24") is True


class TestDockerWorkflow:
    """Validate docker.yml structure and hardening."""

    def test_triggers_on_publish_success(self, docker: dict) -> None:
        on = docker.get("on") or docker.get(True, {})
        wfr = on.get("workflow_run", {})
        assert "Publish to PyPI" in wfr.get("workflows", [])

    def test_condition_checks_success(self, docker: dict) -> None:
        job = docker["jobs"]["build"]
        assert "success" in job.get("if", "")

    def test_has_version_validation(self) -> None:
        raw = _raw("docker.yml")
        assert "grep -qE" in raw, "docker.yml must validate version format"

    def test_pypi_wait_has_explicit_failure(self) -> None:
        raw = _raw("docker.yml")
        assert "FOUND" in raw

    def test_pushes_to_ghcr(self) -> None:
        raw = _raw("docker.yml")
        assert "ghcr.io" in raw

    def test_node24_env(self, docker: dict) -> None:
        env = docker.get("env", {})
        assert env.get("FORCE_JAVASCRIPT_ACTIONS_TO_NODE24") is True

    def test_passes_version_build_arg(self) -> None:
        raw = _raw("docker.yml")
        assert "VERSION=" in raw


class TestTestWorkflow:
    """Validate test.yml structure."""

    def test_triggers_on_push_and_pr(self, test_wf: dict) -> None:
        on = test_wf.get("on") or test_wf.get(True, {})
        assert "push" in on
        assert "pull_request" in on

    def test_matrix_has_three_python_versions(self, test_wf: dict) -> None:
        job = test_wf["jobs"]["test"]
        versions = job.get("strategy", {}).get("matrix", {}).get("python-version", [])
        assert len(versions) >= 3

    def test_runs_mypy(self) -> None:
        raw = _raw("test.yml")
        assert "mypy" in raw

    def test_runs_pytest_with_coverage(self) -> None:
        raw = _raw("test.yml")
        assert "--cov" in raw

    def test_permissions_read_only(self, test_wf: dict) -> None:
        job = test_wf["jobs"]["test"]
        perms = job.get("permissions", {})
        assert perms.get("contents") == "read"
        assert "write" not in str(perms.values())

    def test_node24_env(self, test_wf: dict) -> None:
        env = test_wf.get("env", {})
        assert env.get("FORCE_JAVASCRIPT_ACTIONS_TO_NODE24") is True

    def test_fail_fast_disabled(self, test_wf: dict) -> None:
        job = test_wf["jobs"]["test"]
        assert job.get("strategy", {}).get("fail-fast") is False


class TestAllWorkflowsSecurity:
    """Cross-cutting security checks for all workflow files."""

    @pytest.mark.parametrize("name", ["publish.yml", "docker.yml", "test.yml", "dogfood.yml", "homebrew.yml"])
    def test_no_shell_injection_via_inputs(self, name: str) -> None:
        raw = _raw(name)
        assert "${{ inputs." not in raw or "env:" in raw

    @pytest.mark.parametrize("name", ["publish.yml", "docker.yml", "test.yml", "dogfood.yml", "homebrew.yml"])
    def test_uses_checkout_v4(self, name: str) -> None:
        raw = _raw(name)
        assert "actions/checkout@v4" in raw
