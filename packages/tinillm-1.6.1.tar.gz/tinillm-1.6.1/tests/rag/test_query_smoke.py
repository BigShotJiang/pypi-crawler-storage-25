"""Smoke tests for query pipeline components — no Ollama required."""

from __future__ import annotations

from pathlib import Path


class TestRRF:
    def test_rrf_merges_results(self):
        from tinillm.rag.retriever import reciprocal_rank_fusion
        from tinillm.rag.vectorstore import ChunkPoint

        dense = [
            ChunkPoint(id="a", score=0.9, payload={"chunk_text": "chunk a"}),
            ChunkPoint(id="b", score=0.7, payload={"chunk_text": "chunk b"}),
            ChunkPoint(id="c", score=0.5, payload={"chunk_text": "chunk c"}),
        ]
        sparse = [
            ("b", 10.0),
            ("a", 8.0),
            ("d", 5.0),  # BM25-only hit — no payload in dense
        ]

        merged = reciprocal_rank_fusion(dense, sparse, k=60)
        # b appears in both lists so should be near top
        ids = [p.id for p in merged]
        assert "a" in ids
        assert "b" in ids
        # b should rank highly (in both lists)
        assert ids.index("b") <= ids.index("c")

    def test_rrf_empty_lists(self):
        from tinillm.rag.retriever import reciprocal_rank_fusion
        result = reciprocal_rank_fusion([], [])
        assert result == []

    def test_rrf_dense_only(self):
        from tinillm.rag.retriever import reciprocal_rank_fusion
        from tinillm.rag.vectorstore import ChunkPoint

        dense = [ChunkPoint(id="x", score=0.8, payload={})]
        result = reciprocal_rank_fusion(dense, [])
        assert len(result) == 1
        assert result[0].id == "x"


class TestQueryConfig:
    def test_config_defaults(self):
        from tinillm.rag.config import RagConfig
        cfg = RagConfig()
        assert cfg.llm_model is None
        assert cfg.embed_model is None
        assert cfg.rerank_top_k == 5
        assert cfg.dense_threshold == 0.30

    def test_config_ensure_dirs(self, tmp_path):
        from tinillm.rag.config import RagConfig
        cfg = RagConfig()
        cfg.data_dir = tmp_path / "rag"
        cfg.ensure_dirs()
        assert cfg.qdrant_path.exists()
        assert cfg.data_dir.exists()

    def test_load_config_missing_file(self, tmp_path):
        from tinillm.rag.config import load_config
        cfg = load_config(config_path=tmp_path / "nonexistent.toml")
        # Should return defaults without error
        assert cfg.llm_model is None
        assert cfg.embed_model is None

    def test_load_config_with_toml(self, tmp_path):
        from tinillm.rag.config import load_config
        cfg_file = tmp_path / "rag.toml"
        cfg_file.write_text(
            '[models]\nllm_model = "llama3.2:3b"\nembed_model = "nomic-embed-text"\n'
        )
        cfg = load_config(config_path=cfg_file)
        assert cfg.llm_model == "llama3.2:3b"
        assert cfg.embed_model == "nomic-embed-text"

    def test_save_model_selection(self, tmp_path):
        from tinillm.rag.config import save_model_selection, load_config
        cfg_file = tmp_path / "rag.toml"
        save_model_selection(
            llm_model="qwen2.5:7b",
            embed_model="nomic-embed-text",
            config_path=cfg_file,
        )
        cfg = load_config(config_path=cfg_file)
        assert cfg.llm_model == "qwen2.5:7b"
        assert cfg.embed_model == "nomic-embed-text"


class TestChunkIdempotency:
    def test_chunk_id_from_same_inputs_matches(self):
        from tinillm.rag.chunkers.base import Chunk
        a = Chunk.make_id("/my/file.pdf", 42)
        b = Chunk.make_id("/my/file.pdf", 42)
        assert a == b

    def test_chunk_uuid_to_int_stable(self):
        from tinillm.rag.ingest import _chunk_uuid_to_int
        from tinillm.rag.chunkers.base import Chunk
        cid = Chunk.make_id("/test.txt", 0)
        n = _chunk_uuid_to_int(cid)
        assert isinstance(n, int)
        assert n >= 0
        # Same input → same int
        assert _chunk_uuid_to_int(cid) == n


class TestFallbackParser:
    def test_fallback_uses_second_on_failure(self, tmp_path):
        from tinillm.rag.parsers.base import FallbackChainParser, Document
        from pathlib import Path

        class FailParser:
            def parse(self, path):
                raise RuntimeError("always fails")

        class OkParser:
            def parse(self, path):
                return [Document(content="ok", metadata={})]

        f = tmp_path / "test.txt"
        f.write_text("hello")
        parser = FallbackChainParser([FailParser(), OkParser()])
        docs = parser.parse(f)
        assert len(docs) == 1
        assert docs[0].content == "ok"

    def test_fallback_raises_when_all_fail(self, tmp_path):
        from tinillm.rag.parsers.base import FallbackChainParser
        import pytest

        class FailParser:
            def parse(self, path):
                raise RuntimeError("always fails")

        f = tmp_path / "test.txt"
        f.write_text("hello")
        parser = FallbackChainParser([FailParser(), FailParser()])
        with pytest.raises(RuntimeError):
            parser.parse(f)
