"""QA tests for all `tinillm rag` subcommands.

Covers: ingest, query, status, config, delete, reset
All Ollama calls are mocked. Qdrant and BM25 run in temp dirs.
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from tinillm.main import app


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def corpus(tmp_path):
    """Small mixed-format corpus for ingest tests."""
    (tmp_path / "paper.txt").write_text(
        "Metformin is contraindicated in patients with eGFR below 30 mL/min."
    )
    (tmp_path / "notes.md").write_text(
        "# Drug Interactions\n\nSome drugs interact with metformin."
    )
    (tmp_path / "script.py").write_text(
        "def greet():\n    return 'hello'\n"
    )
    (tmp_path / "report.html").write_text(
        "<html><body><p>Clinical trial results 2024.</p></body></html>"
    )
    return tmp_path


@pytest.fixture
def mock_ollama_embed():
    """Mock ollama.embeddings to return a fake 768-dim vector."""
    fake_vector = [0.01] * 768
    with patch("ollama.embeddings", return_value={"embedding": fake_vector}):
        yield fake_vector


@pytest.fixture
def mock_ollama_list():
    """Mock ollama.list() returning two test models.

    Order in picker: embed models first, then general.
    nomic-embed-text → shown as #1 (embed), qwen2.5:7b → shown as #2 (general).
    """
    model_a = MagicMock()
    model_a.model = "qwen2.5:7b"
    model_a.size = 4_500_000_000

    model_b = MagicMock()
    model_b.model = "nomic-embed-text"
    model_b.size = 270_000_000

    resp = MagicMock()
    resp.models = [model_a, model_b]

    with patch("ollama.list", return_value=resp):
        yield resp


@pytest.fixture
def mock_ollama_running(mock_ollama_list):
    """Ollama is reachable and returns models."""
    yield mock_ollama_list


def _extract_json(output: str) -> dict:
    """Extract the last JSON object from output that may have non-JSON prefix."""
    import re
    # Find the first '{' that starts a JSON block
    idx = output.find("{")
    if idx == -1:
        raise ValueError(f"No JSON found in output:\n{output}")
    return json.loads(output[idx:])


# ══════════════════════════════════════════════════════════════════════════════
# RAG GROUP HELP
# ══════════════════════════════════════════════════════════════════════════════

class TestRagGroupHelp:
    def test_rag_in_root_help(self, runner):
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "rag" in result.output

    def test_rag_group_help(self, runner):
        result = runner.invoke(app, ["rag", "--help"])
        assert result.exit_code == 0

    def test_rag_group_lists_all_subcommands(self, runner):
        result = runner.invoke(app, ["rag", "--help"])
        for cmd in ["ingest", "query", "status", "config", "delete", "reset"]:
            assert cmd in result.output, f"Missing subcommand: {cmd}"

    def test_unknown_subcommand_exits_nonzero(self, runner):
        result = runner.invoke(app, ["rag", "foobar"])
        assert result.exit_code != 0


# ══════════════════════════════════════════════════════════════════════════════
# INGEST
# ══════════════════════════════════════════════════════════════════════════════

class TestIngestHelp:
    def test_ingest_help_exits_zero(self, runner):
        result = runner.invoke(app, ["rag", "ingest", "--help"])
        assert result.exit_code == 0

    def test_ingest_help_shows_all_flags(self, runner):
        result = runner.invoke(app, ["rag", "ingest", "--help"])
        for flag in ["--resume", "--force-reindex", "--types", "--dry-run", "--json", "--no-color"]:
            assert flag in result.output, f"Missing flag: {flag}"

    def test_ingest_requires_source_arg(self, runner):
        result = runner.invoke(app, ["rag", "ingest"])
        assert result.exit_code != 0


class TestIngestDryRun:
    def test_dry_run_exits_zero(self, runner, corpus):
        result = runner.invoke(app, ["rag", "ingest", str(corpus), "--dry-run"])
        assert result.exit_code == 0

    def test_dry_run_does_not_call_ollama(self, runner, corpus):
        with patch("ollama.embeddings") as mock_embed:
            runner.invoke(app, ["rag", "ingest", str(corpus), "--dry-run"])
        mock_embed.assert_not_called()

    def test_dry_run_json_is_valid(self, runner, corpus):
        result = runner.invoke(app, ["rag", "ingest", str(corpus), "--dry-run", "--json"])
        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert "discovered" in payload
        assert "skipped" in payload
        assert "embedded" in payload
        assert payload["embedded"] == 0

    def test_dry_run_discovers_correct_count(self, runner, corpus):
        result = runner.invoke(app, ["rag", "ingest", str(corpus), "--dry-run", "--json"])
        payload = json.loads(result.output)
        assert payload["discovered"] == 4  # txt, md, py, html

    def test_dry_run_types_filter_txt(self, runner, corpus):
        result = runner.invoke(app, [
            "rag", "ingest", str(corpus), "--dry-run", "--types", "txt", "--json"
        ])
        payload = json.loads(result.output)
        assert payload["discovered"] == 1

    def test_dry_run_types_filter_md_py(self, runner, corpus):
        result = runner.invoke(app, [
            "rag", "ingest", str(corpus), "--dry-run", "--types", "md,py", "--json"
        ])
        payload = json.loads(result.output)
        assert payload["discovered"] == 2

    def test_dry_run_no_color_no_ansi(self, runner, corpus):
        result = runner.invoke(app, [
            "rag", "ingest", str(corpus), "--dry-run", "--no-color"
        ])
        assert "\x1b[" not in result.output

    def test_dry_run_multiple_sources(self, runner, tmp_path):
        src1 = tmp_path / "src1"
        src2 = tmp_path / "src2"
        src1.mkdir()
        src2.mkdir()
        (src1 / "a.txt").write_text("hello")
        (src2 / "b.txt").write_text("world")
        result = runner.invoke(app, [
            "rag", "ingest", str(src1), str(src2), "--dry-run", "--json"
        ])
        payload = json.loads(result.output)
        assert payload["discovered"] == 2

    def test_dry_run_nonexistent_source_exits_nonzero(self, runner):
        result = runner.invoke(app, ["rag", "ingest", "/nonexistent/path", "--dry-run"])
        assert result.exit_code != 0


class TestIngestFull:
    def test_ingest_calls_embed_for_each_file(self, runner, corpus, tmp_path,
                                               mock_ollama_running):
        fake_vector = [0.01] * 768
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", tmp_path / "rag"),
        ):
            result = runner.invoke(
                app,
                ["rag", "ingest", str(corpus), "--json"],
                input="1\nn\n",  # pick nomic-embed-text (#1), don't save
            )
        assert result.exit_code == 0
        payload = _extract_json(result.output)
        assert payload["embedded"] > 0

    def test_ingest_resume_skips_already_embedded(self, runner, corpus, tmp_path,
                                                    mock_ollama_running):
        fake_vector = [0.01] * 768
        data_dir = tmp_path / "rag"
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", data_dir),
        ):
            # First ingest
            first = runner.invoke(
                app,
                ["rag", "ingest", str(corpus), "--json"],
                input="1\nn\n",
            )
            first_payload = _extract_json(first.output)
            embedded_count = first_payload["embedded"]

            # Second ingest — should skip everything embedded the first time
            result = runner.invoke(
                app,
                ["rag", "ingest", str(corpus), "--resume", "--json"],
                input="1\nn\n",
            )
        assert result.exit_code == 0
        payload = _extract_json(result.output)
        # Files already embedded are skipped; failed files from run 1 may be retried
        assert payload["skipped"] >= embedded_count
        assert payload["skipped"] > 0

    def test_ingest_force_reindex_reembeds_all(self, runner, corpus, tmp_path,
                                                mock_ollama_running):
        fake_vector = [0.01] * 768
        data_dir = tmp_path / "rag"
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", data_dir),
        ):
            # First ingest
            runner.invoke(
                app, ["rag", "ingest", str(corpus), "--json"],
                input="1\nn\n",
            )
            # Force reindex
            result = runner.invoke(
                app, ["rag", "ingest", str(corpus), "--force-reindex", "--json"],
                input="1\nn\n",
            )
        assert result.exit_code == 0
        payload = _extract_json(result.output)
        assert payload["skipped"] == 0
        assert payload["embedded"] > 0

    def test_ingest_ollama_not_running_exits_nonzero(self, runner, corpus):
        with patch("ollama.list", side_effect=Exception("not running")):
            result = runner.invoke(app, ["rag", "ingest", str(corpus)])
        assert result.exit_code != 0
        assert "ollama" in result.output.lower()


# ══════════════════════════════════════════════════════════════════════════════
# QUERY
# ══════════════════════════════════════════════════════════════════════════════

class TestQueryHelp:
    def test_query_help_exits_zero(self, runner):
        result = runner.invoke(app, ["rag", "query", "--help"])
        assert result.exit_code == 0

    def test_query_help_shows_all_flags(self, runner):
        result = runner.invoke(app, ["rag", "query", "--help"])
        for flag in ["--model", "--top-k", "--no-rerank", "--web", "--verbose", "--json", "--no-color"]:
            assert flag in result.output, f"Missing flag: {flag}"

    def test_query_requires_question_arg(self, runner):
        result = runner.invoke(app, ["rag", "query"])
        assert result.exit_code != 0


class TestQueryExecution:
    def _setup_index(self, runner, corpus, data_dir, mock_ollama_running):
        """Ingest corpus into temp data dir and return the dir."""
        fake_vector = [0.01] * 768
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", data_dir),
        ):
            runner.invoke(
                app, ["rag", "ingest", str(corpus), "--json"],
                input="2\nn\n",  # pick nomic-embed-text, don't save
            )

    def test_query_ollama_not_running_exits_nonzero(self, runner):
        with patch("ollama.list", side_effect=Exception("not running")):
            result = runner.invoke(app, ["rag", "query", "test question"])
        assert result.exit_code != 0

    def test_query_empty_index_shows_message(self, runner, tmp_path, mock_ollama_running):
        fake_vector = [0.01] * 768
        mock_chunk = MagicMock()
        mock_chunk.message.content = "No answer."
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", tmp_path / "empty_rag"),
            patch("ollama.chat", return_value=iter([mock_chunk])),
        ):
            # "1\n" picks embed model, "n\n" don't save, "1\n" picks LLM, "n\n" don't save
            result = runner.invoke(
                app, ["rag", "query", "anything"],
                input="1\nn\n1\nn\n",
            )
        assert result.exit_code == 0
        assert "no relevant" in result.output.lower() or "index" in result.output.lower()

    def test_query_with_model_flag_skips_picker(self, runner, tmp_path, mock_ollama_running):
        fake_vector = [0.01] * 768
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", tmp_path / "rag"),
            patch("tinillm.rag.model_picker.pick_llm_model") as mock_picker,
            patch("ollama.chat") as mock_chat,
        ):
            mock_chat.return_value = MagicMock(message=MagicMock(content="Test answer."))
            runner.invoke(
                app, ["rag", "query", "test", "--model", "qwen2.5:7b"],
            )
        # picker should NOT be called when --model is provided
        mock_picker.assert_not_called()

    def test_query_json_output_is_valid(self, runner, tmp_path, mock_ollama_running):
        """Verify --json output shape by mocking the full query pipeline."""
        from tinillm.rag.query import QueryResult, Citation

        fake_result = QueryResult(
            answer="Metformin is contraindicated in renal failure.",
            citations=[Citation(key="[1]", file_path="/tmp/paper.txt", page_number=1)],
            chunks_retrieved=5,
            chunks_reranked=3,
        )

        with (
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", tmp_path / "rag"),
            patch("tinillm.rag.model_picker.pick_embed_model",
                  return_value="nomic-embed-text"),
            patch("tinillm.rag.query.run_query", return_value=fake_result),
        ):
            result = runner.invoke(
                app, ["rag", "query", "metformin", "--model", "qwen2.5:7b", "--json"],
            )

        assert result.exit_code == 0, result.output
        payload = json.loads(result.output)
        assert "answer" in payload
        assert "citations" in payload
        assert "chunks_retrieved" in payload
        assert isinstance(payload["citations"], list)
        assert payload["answer"] == "Metformin is contraindicated in renal failure."
        assert payload["chunks_retrieved"] == 5

    def test_query_no_rerank_flag_accepted(self, runner, tmp_path, mock_ollama_running):
        fake_vector = [0.01] * 768
        mock_chunk = MagicMock()
        mock_chunk.message.content = "ok"
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", tmp_path / "rag"),
            patch("tinillm.rag.model_picker.pick_embed_model",
                  return_value="nomic-embed-text"),
            patch("ollama.chat", return_value=iter([mock_chunk])),
        ):
            result = runner.invoke(
                app, ["rag", "query", "test", "--model", "qwen2.5:7b", "--no-rerank"],
            )
        assert result.exit_code == 0

    def test_query_top_k_flag_accepted(self, runner, tmp_path, mock_ollama_running):
        fake_vector = [0.01] * 768
        mock_chunk = MagicMock()
        mock_chunk.message.content = "ok"
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", tmp_path / "rag"),
            patch("tinillm.rag.model_picker.pick_embed_model",
                  return_value="nomic-embed-text"),
            patch("ollama.chat", return_value=iter([mock_chunk])),
        ):
            result = runner.invoke(
                app, ["rag", "query", "test", "--model", "qwen2.5:7b", "--top-k", "3"],
            )
        assert result.exit_code == 0

    def test_query_no_color_no_ansi(self, runner, tmp_path, mock_ollama_running):
        fake_vector = [0.01] * 768
        mock_chunk = MagicMock()
        mock_chunk.message.content = "ok"
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", tmp_path / "rag"),
            patch("tinillm.rag.model_picker.pick_embed_model",
                  return_value="nomic-embed-text"),
            patch("ollama.chat", return_value=iter([mock_chunk])),
        ):
            result = runner.invoke(
                app,
                ["rag", "query", "test", "--model", "qwen2.5:7b", "--no-color"],
            )
        assert "\x1b[" not in result.output


# ══════════════════════════════════════════════════════════════════════════════
# STATUS
# ══════════════════════════════════════════════════════════════════════════════

class TestStatusHelp:
    def test_status_help_exits_zero(self, runner):
        result = runner.invoke(app, ["rag", "status", "--help"])
        assert result.exit_code == 0

    def test_status_help_shows_all_flags(self, runner):
        result = runner.invoke(app, ["rag", "status", "--help"])
        for flag in ["--verbose", "--json", "--no-color"]:
            assert flag in result.output


class TestStatusEmpty:
    def test_status_no_index_exits_zero(self, runner, tmp_path):
        with patch("tinillm.rag.config._DEFAULT_DATA_DIR", tmp_path / "empty"):
            result = runner.invoke(app, ["rag", "status"])
        assert result.exit_code == 0

    def test_status_json_no_index_exits_zero(self, runner, tmp_path):
        with patch("tinillm.rag.config._DEFAULT_DATA_DIR", tmp_path / "empty"):
            result = runner.invoke(app, ["rag", "status", "--json"])
        assert result.exit_code == 0

    def test_status_no_index_shows_hint(self, runner, tmp_path):
        with patch("tinillm.rag.config._DEFAULT_DATA_DIR", tmp_path / "empty"):
            result = runner.invoke(app, ["rag", "status"])
        assert "ingest" in result.output.lower() or "no index" in result.output.lower()


class TestStatusWithIndex:
    def test_status_after_ingest_shows_counts(self, runner, corpus, tmp_path,
                                               mock_ollama_running):
        data_dir = tmp_path / "rag"
        fake_vector = [0.01] * 768
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", data_dir),
        ):
            runner.invoke(
                app, ["rag", "ingest", str(corpus), "--json"],
                input="2\nn\n",
            )
            result = runner.invoke(app, ["rag", "status"])
        assert result.exit_code == 0
        assert any(c.isdigit() for c in result.output)

    def test_status_json_structure(self, runner, corpus, tmp_path, mock_ollama_running):
        data_dir = tmp_path / "rag"
        fake_vector = [0.01] * 768
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", data_dir),
        ):
            runner.invoke(
                app, ["rag", "ingest", str(corpus), "--json"],
                input="2\nn\n",
            )
            result = runner.invoke(app, ["rag", "status", "--json"])
        assert result.exit_code == 0
        payload = json.loads(result.output)
        for key in ["indexed_files", "total_files", "total_chunks", "vectors_count"]:
            assert key in payload, f"Missing key: {key}"

    def test_status_json_indexed_files_correct(self, runner, corpus, tmp_path,
                                                mock_ollama_running):
        data_dir = tmp_path / "rag"
        fake_vector = [0.01] * 768
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", data_dir),
        ):
            runner.invoke(
                app, ["rag", "ingest", str(corpus), "--json"],
                input="2\nn\n",
            )
            result = runner.invoke(app, ["rag", "status", "--json"])
        payload = json.loads(result.output)
        # At least 3 of 4 files must be indexed (html may vary by parser availability)
        assert payload["indexed_files"] >= 3

    def test_status_verbose_shows_type_breakdown(self, runner, corpus, tmp_path,
                                                   mock_ollama_running):
        data_dir = tmp_path / "rag"
        fake_vector = [0.01] * 768
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", data_dir),
        ):
            runner.invoke(
                app, ["rag", "ingest", str(corpus), "--json"],
                input="2\nn\n",
            )
            result = runner.invoke(app, ["rag", "status", "--verbose"])
        assert result.exit_code == 0
        # Should show file type breakdown
        assert any(ft in result.output for ft in ["txt", "md", "py", "html"])

    def test_status_no_color_no_ansi(self, runner, corpus, tmp_path, mock_ollama_running):
        data_dir = tmp_path / "rag"
        fake_vector = [0.01] * 768
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", data_dir),
        ):
            runner.invoke(
                app, ["rag", "ingest", str(corpus), "--json"],
                input="2\nn\n",
            )
            result = runner.invoke(app, ["rag", "status", "--no-color"])
        assert "\x1b[" not in result.output


# ══════════════════════════════════════════════════════════════════════════════
# CONFIG
# ══════════════════════════════════════════════════════════════════════════════

class TestConfigHelp:
    def test_config_help_exits_zero(self, runner):
        result = runner.invoke(app, ["rag", "config", "--help"])
        assert result.exit_code == 0

    def test_config_help_shows_check_flag(self, runner):
        result = runner.invoke(app, ["rag", "config", "--help"])
        assert "--check" in result.output


class TestConfigShow:
    def test_config_exits_zero(self, runner):
        result = runner.invoke(app, ["rag", "config"])
        assert result.exit_code == 0

    def test_config_shows_data_dir(self, runner):
        result = runner.invoke(app, ["rag", "config"])
        assert "data_dir" in result.output

    def test_config_shows_model_fields(self, runner):
        result = runner.invoke(app, ["rag", "config"])
        assert "llm_model" in result.output
        assert "embed_model" in result.output

    def test_config_shows_chunk_sizes(self, runner):
        result = runner.invoke(app, ["rag", "config"])
        assert "chunk_size" in result.output

    def test_config_unset_models_show_hint(self, runner, tmp_path):
        with patch("tinillm.rag.config._DEFAULT_CONFIG_PATH", tmp_path / "rag.toml"):
            result = runner.invoke(app, ["rag", "config"])
        assert "not set" in result.output.lower() or "pick" in result.output.lower()

    def test_config_set_model_shows_value(self, runner, tmp_path):
        cfg_file = tmp_path / "rag.toml"
        cfg_file.write_text('[models]\nllm_model = "qwen2.5:7b"\n')
        with patch("tinillm.rag.config._DEFAULT_CONFIG_PATH", cfg_file):
            result = runner.invoke(app, ["rag", "config"])
        assert "qwen2.5:7b" in result.output

    def test_config_no_color_no_ansi(self, runner):
        result = runner.invoke(app, ["rag", "config", "--no-color"])
        assert "\x1b[" not in result.output


class TestConfigCheck:
    def test_config_check_exits_zero(self, runner):
        result = runner.invoke(app, ["rag", "config", "--check"])
        assert result.exit_code == 0

    def test_config_check_shows_dependency_status(self, runner):
        result = runner.invoke(app, ["rag", "config", "--check"])
        assert "qdrant" in result.output.lower() or "OK" in result.output or "MISS" in result.output

    def test_config_check_shows_ollama_status(self, runner):
        result = runner.invoke(app, ["rag", "config", "--check"])
        assert "ollama" in result.output.lower()

    def test_config_check_installed_dep_shows_ok(self, runner):
        result = runner.invoke(app, ["rag", "config", "--check"])
        # rank-bm25 is installed, should show OK
        assert "OK" in result.output


# ══════════════════════════════════════════════════════════════════════════════
# DELETE
# ══════════════════════════════════════════════════════════════════════════════

class TestDeleteHelp:
    def test_delete_help_exits_zero(self, runner, tmp_path):
        # delete requires an existing path arg, use tmp_path
        result = runner.invoke(app, ["rag", "delete", "--help"])
        assert result.exit_code == 0

    def test_delete_help_shows_confirm_flag(self, runner):
        result = runner.invoke(app, ["rag", "delete", "--help"])
        assert "--confirm" in result.output


class TestDeleteBehavior:
    def test_delete_without_confirm_prompts(self, runner, tmp_path, corpus,
                                            mock_ollama_running):
        data_dir = tmp_path / "rag"
        fake_vector = [0.01] * 768
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", data_dir),
        ):
            runner.invoke(
                app, ["rag", "ingest", str(corpus), "--json"],
                input="2\nn\n",
            )
            # Without --confirm, should prompt. Abort with 'n'
            result = runner.invoke(
                app, ["rag", "delete", str(corpus)],
                input="n\n",
            )
        assert result.exit_code != 0 or "aborted" in result.output.lower()

    def test_delete_with_confirm_removes_files(self, runner, corpus, tmp_path,
                                               mock_ollama_running):
        data_dir = tmp_path / "rag"
        fake_vector = [0.01] * 768
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", data_dir),
        ):
            runner.invoke(
                app, ["rag", "ingest", str(corpus), "--json"],
                input="2\nn\n",
            )
            result = runner.invoke(
                app, ["rag", "delete", str(corpus), "--confirm"],
            )
        assert result.exit_code == 0
        assert "removed" in result.output.lower() or "0" in result.output

    def test_delete_nonexistent_source_exits_nonzero(self, runner):
        result = runner.invoke(app, ["rag", "delete", "/nonexistent/path", "--confirm"])
        assert result.exit_code != 0

    def test_delete_updates_status(self, runner, corpus, tmp_path, mock_ollama_running):
        data_dir = tmp_path / "rag"
        fake_vector = [0.01] * 768
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", data_dir),
        ):
            runner.invoke(
                app, ["rag", "ingest", str(corpus), "--json"],
                input="2\nn\n",
            )
            runner.invoke(
                app, ["rag", "delete", str(corpus), "--confirm"],
            )
            result = runner.invoke(app, ["rag", "status", "--json"])
        payload = json.loads(result.output)
        assert payload["indexed_files"] == 0


# ══════════════════════════════════════════════════════════════════════════════
# RESET
# ══════════════════════════════════════════════════════════════════════════════

class TestResetHelp:
    def test_reset_help_exits_zero(self, runner):
        result = runner.invoke(app, ["rag", "reset", "--help"])
        assert result.exit_code == 0

    def test_reset_help_shows_confirm_flag(self, runner):
        result = runner.invoke(app, ["rag", "reset", "--help"])
        assert "--confirm" in result.output


class TestResetBehavior:
    def test_reset_without_confirm_prompts(self, runner):
        result = runner.invoke(app, ["rag", "reset"], input="n\n")
        assert result.exit_code != 0 or "aborted" in result.output.lower()

    def test_reset_with_confirm_exits_zero(self, runner, tmp_path):
        with patch("tinillm.rag.config._DEFAULT_DATA_DIR", tmp_path / "rag"):
            result = runner.invoke(app, ["rag", "reset", "--confirm"])
        assert result.exit_code == 0

    def test_reset_nothing_to_remove_message(self, runner, tmp_path):
        with patch("tinillm.rag.config._DEFAULT_DATA_DIR", tmp_path / "empty_rag"):
            result = runner.invoke(app, ["rag", "reset", "--confirm"])
        assert result.exit_code == 0
        assert "nothing" in result.output.lower() or "removed" in result.output.lower()

    def test_reset_removes_manifest(self, runner, corpus, tmp_path, mock_ollama_running):
        data_dir = tmp_path / "rag"
        fake_vector = [0.01] * 768
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", data_dir),
        ):
            runner.invoke(
                app, ["rag", "ingest", str(corpus), "--json"],
                input="2\nn\n",
            )
        assert (data_dir / "manifest.db").exists()

        with patch("tinillm.rag.config._DEFAULT_DATA_DIR", data_dir):
            runner.invoke(app, ["rag", "reset", "--confirm"])

        assert not (data_dir / "manifest.db").exists()

    def test_reset_removes_qdrant_dir(self, runner, corpus, tmp_path, mock_ollama_running):
        data_dir = tmp_path / "rag"
        fake_vector = [0.01] * 768
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", data_dir),
        ):
            runner.invoke(
                app, ["rag", "ingest", str(corpus), "--json"],
                input="2\nn\n",
            )
        assert (data_dir / "qdrant").exists()

        with patch("tinillm.rag.config._DEFAULT_DATA_DIR", data_dir):
            runner.invoke(app, ["rag", "reset", "--confirm"])

        assert not (data_dir / "qdrant").exists()

    def test_reset_status_shows_empty(self, runner, corpus, tmp_path, mock_ollama_running):
        data_dir = tmp_path / "rag"
        fake_vector = [0.01] * 768
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", data_dir),
        ):
            runner.invoke(
                app, ["rag", "ingest", str(corpus), "--json"],
                input="2\nn\n",
            )
        with patch("tinillm.rag.config._DEFAULT_DATA_DIR", data_dir):
            runner.invoke(app, ["rag", "reset", "--confirm"])
            result = runner.invoke(app, ["rag", "status"])
        assert result.exit_code == 0
        assert "ingest" in result.output.lower() or "no index" in result.output.lower()

    def test_reset_no_color_no_ansi(self, runner, tmp_path):
        with patch("tinillm.rag.config._DEFAULT_DATA_DIR", tmp_path / "rag"):
            result = runner.invoke(app, ["rag", "reset", "--confirm", "--no-color"])
        assert "\x1b[" not in result.output


# ══════════════════════════════════════════════════════════════════════════════
# MODEL PICKER
# ══════════════════════════════════════════════════════════════════════════════

class TestModelPicker:
    def test_pick_embed_model_shows_table(self, runner, corpus, mock_ollama_running, tmp_path):
        fake_vector = [0.01] * 768
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", tmp_path / "rag"),
        ):
            result = runner.invoke(
                app,
                ["rag", "ingest", str(corpus), "--dry-run"],
                # dry-run won't show picker, just confirm normal flow
            )
        assert result.exit_code == 0

    def test_pick_embed_auto_selects_single_model(self, runner, corpus, tmp_path):
        """If only one model, it should be picked automatically."""
        single_model = MagicMock()
        single_model.model = "nomic-embed-text"
        single_model.size = 270_000_000
        resp = MagicMock()
        resp.models = [single_model]

        fake_vector = [0.01] * 768
        with (
            patch("ollama.list", return_value=resp),
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", tmp_path / "rag"),
        ):
            result = runner.invoke(
                app,
                ["rag", "ingest", str(corpus), "--json"],
                input="1\nn\n",  # pick model #1, don't save
            )
        assert result.exit_code == 0

    def test_pick_model_no_ollama_exits_nonzero(self, runner, corpus):
        with patch("ollama.list", side_effect=Exception("not running")):
            result = runner.invoke(app, ["rag", "ingest", str(corpus)])
        assert result.exit_code != 0

    def test_config_with_model_skips_picker(self, runner, corpus, tmp_path, mock_ollama_running):
        """If embed_model is already in config, picker is skipped."""
        cfg_file = tmp_path / "rag.toml"
        cfg_file.write_text('[models]\nembed_model = "nomic-embed-text"\n')
        data_dir = tmp_path / "rag"

        fake_vector = [0.01] * 768
        with (
            patch("ollama.embeddings", return_value={"embedding": fake_vector}),
            patch("tinillm.rag.config._DEFAULT_DATA_DIR", data_dir),
            patch("tinillm.rag.config._DEFAULT_CONFIG_PATH", cfg_file),
            patch("tinillm.rag.model_picker.pick_embed_model",
                  wraps=lambda cfg: cfg.embed_model) as mock_picker,
        ):
            runner.invoke(app, ["rag", "ingest", str(corpus), "--json"])

        # pick_embed_model returns early when model is already set
        assert mock_picker.call_count <= 1
