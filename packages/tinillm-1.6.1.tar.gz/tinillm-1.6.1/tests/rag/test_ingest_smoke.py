"""Smoke tests for the ingest pipeline — no Ollama required."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest
from click.testing import CliRunner

from tinillm.main import app


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def tmp_corpus(tmp_path):
    """Create a tiny corpus of text files for testing."""
    (tmp_path / "a.txt").write_text("Metformin is contraindicated in renal failure.")
    (tmp_path / "b.md").write_text("# Pharmacology\n\nDrug interactions matter.")
    (tmp_path / "c.py").write_text("def hello():\n    return 'world'\n")
    return tmp_path


class TestRagHelp:
    def test_rag_appears_in_root_help(self, runner):
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "rag" in result.output

    def test_rag_help(self, runner):
        result = runner.invoke(app, ["rag", "--help"])
        assert result.exit_code == 0
        assert "ingest" in result.output
        assert "query" in result.output
        assert "status" in result.output
        assert "config" in result.output
        assert "delete" in result.output
        assert "reset" in result.output

    def test_ingest_help(self, runner):
        result = runner.invoke(app, ["rag", "ingest", "--help"])
        assert result.exit_code == 0
        assert "--resume" in result.output
        assert "--force-reindex" in result.output
        assert "--types" in result.output
        assert "--dry-run" in result.output
        assert "--json" in result.output

    def test_query_help(self, runner):
        result = runner.invoke(app, ["rag", "query", "--help"])
        assert result.exit_code == 0
        assert "--model" in result.output
        assert "--top-k" in result.output
        assert "--no-rerank" in result.output
        assert "--web" in result.output

    def test_status_help(self, runner):
        result = runner.invoke(app, ["rag", "status", "--help"])
        assert result.exit_code == 0
        assert "--verbose" in result.output
        assert "--json" in result.output


class TestDryRun:
    def test_dry_run_does_not_require_ollama(self, runner, tmp_corpus):
        result = runner.invoke(app, [
            "rag", "ingest", str(tmp_corpus), "--dry-run"
        ])
        # dry-run should exit cleanly — no Ollama needed
        assert result.exit_code == 0

    def test_dry_run_json(self, runner, tmp_corpus):
        result = runner.invoke(app, [
            "rag", "ingest", str(tmp_corpus), "--dry-run", "--json"
        ])
        assert result.exit_code == 0
        payload = json.loads(result.output)
        assert "discovered" in payload
        assert "skipped" in payload
        assert payload["embedded"] == 0  # dry-run never embeds

    def test_dry_run_types_filter(self, runner, tmp_corpus):
        result = runner.invoke(app, [
            "rag", "ingest", str(tmp_corpus),
            "--dry-run", "--types", "txt", "--json"
        ])
        assert result.exit_code == 0
        payload = json.loads(result.output)
        # Only txt files discovered
        assert payload["discovered"] <= 1


class TestStatusEmpty:
    def test_status_no_index(self, runner, tmp_path, monkeypatch):
        # Point config data_dir to empty temp dir so no index exists
        monkeypatch.setenv("HOME", str(tmp_path))
        result = runner.invoke(app, ["rag", "status"])
        assert result.exit_code == 0

    def test_status_json_no_index(self, runner, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path))
        result = runner.invoke(app, ["rag", "status", "--json"])
        assert result.exit_code == 0


class TestConfigCmd:
    def test_config_shows_output(self, runner):
        result = runner.invoke(app, ["rag", "config"])
        assert result.exit_code == 0
        assert "data_dir" in result.output or "llm_model" in result.output

    def test_config_check_runs(self, runner):
        result = runner.invoke(app, ["rag", "config", "--check"])
        assert result.exit_code == 0


class TestParsers:
    def test_plain_text_parser(self, tmp_path):
        from tinillm.rag.parsers.text import PlainTextParser
        f = tmp_path / "test.txt"
        f.write_text("Hello world")
        docs = PlainTextParser().parse(f)
        assert len(docs) == 1
        assert "Hello world" in docs[0].content

    def test_markdown_parser(self, tmp_path):
        from tinillm.rag.parsers.text import MarkdownParser
        f = tmp_path / "test.md"
        f.write_text("# Title\n\nSome content here.")
        docs = MarkdownParser().parse(f)
        assert len(docs) == 1
        assert "Title" in docs[0].content

    def test_html_parser(self, tmp_path):
        from tinillm.rag.parsers.text import HTMLParser
        f = tmp_path / "test.html"
        f.write_text("<html><body><h1>Title</h1><p>Content</p></body></html>")
        docs = HTMLParser().parse(f)
        assert len(docs) == 1
        assert "Title" in docs[0].content
        assert "Content" in docs[0].content

    def test_html_strips_scripts(self, tmp_path):
        from tinillm.rag.parsers.text import HTMLParser
        f = tmp_path / "test.html"
        f.write_text("<html><body><script>alert(1)</script><p>Real content</p></body></html>")
        docs = HTMLParser().parse(f)
        assert "alert" not in docs[0].content
        assert "Real content" in docs[0].content

    def test_empty_file_returns_empty(self, tmp_path):
        from tinillm.rag.parsers.text import PlainTextParser
        f = tmp_path / "empty.txt"
        f.write_text("")
        docs = PlainTextParser().parse(f)
        assert docs == []


class TestChunkers:
    def test_semantic_chunker(self):
        from tinillm.rag.chunkers.semantic import SemanticChunker
        from tinillm.rag.config import RagConfig
        from tinillm.rag.parsers.base import Document

        config = RagConfig()
        config.prose_chunk_size = 20  # tiny for test
        chunker = SemanticChunker(config)
        doc = Document(
            content="This is sentence one. This is sentence two. This is sentence three.",
            metadata={"file_path": "/tmp/test.txt", "file_type": "txt"},
        )
        chunks = chunker.chunk(doc, file_id=1, sha256="abc123")
        assert len(chunks) >= 1
        for c in chunks:
            assert c.text.strip()
            assert c.file_id == 1
            assert c.sha256 == "abc123"

    def test_header_chunker(self):
        from tinillm.rag.chunkers.header import HeaderChunker
        from tinillm.rag.config import RagConfig
        from tinillm.rag.parsers.base import Document

        config = RagConfig()
        chunker = HeaderChunker(config)
        doc = Document(
            content="# Section One\n\nContent under section one.\n\n# Section Two\n\nContent under two.",
            metadata={"file_path": "/tmp/test.md", "file_type": "md"},
        )
        chunks = chunker.chunk(doc, file_id=1, sha256="abc")
        assert len(chunks) >= 2
        sections = [c.section for c in chunks]
        assert "Section One" in sections or any("Section" in (s or "") for s in sections)

    def test_layout_chunker(self):
        from tinillm.rag.chunkers.layout import LayoutChunker
        from tinillm.rag.config import RagConfig
        from tinillm.rag.parsers.base import Document

        config = RagConfig()
        config.pdf_chunk_size = 10  # tiny for test
        chunker = LayoutChunker(config)
        doc = Document(
            content=" ".join(["word"] * 100),
            metadata={"file_path": "/tmp/test.pdf", "file_type": "pdf", "page_number": 1},
        )
        chunks = chunker.chunk(doc, file_id=1, sha256="xyz")
        assert len(chunks) >= 2

    def test_chunk_ids_are_deterministic(self):
        from tinillm.rag.chunkers.base import Chunk
        id1 = Chunk.make_id("/tmp/test.txt", 0)
        id2 = Chunk.make_id("/tmp/test.txt", 0)
        assert id1 == id2

    def test_chunk_ids_differ_by_index(self):
        from tinillm.rag.chunkers.base import Chunk
        id1 = Chunk.make_id("/tmp/test.txt", 0)
        id2 = Chunk.make_id("/tmp/test.txt", 1)
        assert id1 != id2


class TestDiscovery:
    def test_discover_new_files(self, tmp_corpus, tmp_path):
        from tinillm.rag.config import RagConfig
        from tinillm.rag.discovery import discover
        from tinillm.rag.manifest import ManifestDB

        config = RagConfig()
        config.data_dir = tmp_path / "rag"
        config.ensure_dirs()
        manifest = ManifestDB(config.manifest_path)

        result = discover([tmp_corpus], manifest)
        manifest.close()

        assert result.skipped == 0
        assert len(result.to_process) == 3
        dispositions = {r.disposition for r in result.to_process}
        assert dispositions == {"new"}

    def test_discover_skips_unchanged(self, tmp_corpus, tmp_path):
        from tinillm.rag.config import RagConfig
        from tinillm.rag.discovery import discover
        from tinillm.rag.manifest import ManifestDB
        from tinillm.rag.discovery import hash_file

        config = RagConfig()
        config.data_dir = tmp_path / "rag"
        config.ensure_dirs()
        manifest = ManifestDB(config.manifest_path)

        # First pass — mark all as embedded
        result1 = discover([tmp_corpus], manifest)
        for rec in result1.to_process:
            manifest.update_embed_status(rec.id, "embedded")

        # Second pass — should skip all
        result2 = discover([tmp_corpus], manifest, resume=True)
        manifest.close()

        assert result2.skipped == 3
        assert len(result2.to_process) == 0


class TestManifest:
    def test_upsert_and_lookup(self, tmp_path):
        from tinillm.rag.manifest import ManifestDB

        db = ManifestDB(tmp_path / "manifest.db")
        rec = db.upsert(
            path=Path("/tmp/test.txt"),
            sha256="abc123",
            size_bytes=100,
            mtime=1234567890.0,
            file_type="txt",
            disposition="new",
        )
        assert rec.sha256 == "abc123"
        assert rec.parse_status == "pending"

        found = db.lookup(Path("/tmp/test.txt"))
        assert found is not None
        assert found.sha256 == "abc123"
        db.close()

    def test_update_parse_status(self, tmp_path):
        from tinillm.rag.manifest import ManifestDB

        db = ManifestDB(tmp_path / "manifest.db")
        rec = db.upsert(
            path=Path("/tmp/test.txt"),
            sha256="abc",
            size_bytes=10,
            mtime=0.0,
            file_type="txt",
            disposition="new",
        )
        db.update_parse_status(rec.id, "parsed", chunk_count=5)
        updated = db.lookup(Path("/tmp/test.txt"))
        assert updated.parse_status == "parsed"
        assert updated.chunk_count == 5
        db.close()

    def test_get_stats_empty(self, tmp_path):
        from tinillm.rag.manifest import ManifestDB
        db = ManifestDB(tmp_path / "manifest.db")
        stats = db.get_stats()
        assert stats["total_files"] == 0
        db.close()


class TestBM25:
    def test_add_and_search(self):
        from tinillm.rag.bm25 import BM25Index
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            idx = BM25Index(Path(tmpdir) / "bm25.pkl")
            idx.add_documents([
                (1, "chunk-1", "metformin is used for diabetes treatment"),
                (2, "chunk-2", "insulin resistance is a metabolic condition"),
                (3, "chunk-3", "completely unrelated topic about cars"),
            ])
            results = idx.search("metformin diabetes", top_k=2)
            assert len(results) >= 1
            chunk_ids = [r[0] for r in results]
            assert "chunk-1" in chunk_ids

    def test_save_and_load(self, tmp_path):
        from tinillm.rag.bm25 import BM25Index

        idx = BM25Index(tmp_path / "bm25.pkl")
        idx.add_documents([(1, "c1", "hello world"), (2, "c2", "foo bar")])
        idx.save()

        idx2 = BM25Index(tmp_path / "bm25.pkl")
        assert idx2.doc_count == 2

    def test_empty_search_returns_empty(self, tmp_path):
        from tinillm.rag.bm25 import BM25Index
        idx = BM25Index(tmp_path / "bm25.pkl")
        results = idx.search("something", top_k=5)
        assert results == []
