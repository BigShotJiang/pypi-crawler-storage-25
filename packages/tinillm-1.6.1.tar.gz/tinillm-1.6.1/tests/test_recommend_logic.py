"""Unit tests for tinillm.recommend.logic — ranking and scoring."""

from __future__ import annotations

import pytest

from tinillm.analyzer.types import FitLevel, LlmModel, ModelFit, Quant
from tinillm.models.database import RealModel
from tinillm.recommend.logic import (
    FIT_SCORE,
    USE_CASE_AFFINITY,
    _EXCLUDED_MODELS,
    ScoredModel,
    rank_models,
)


# ── Helpers ───────────────────────────────────────────────────────────────

def _real(name: str, params_b: float = 7.0) -> RealModel:
    return RealModel(
        name=name, display_name=name, provider="Test",
        params_b=params_b, num_layers=32, num_kv_heads=8,
        head_dim=128, context_length=8192,
        ollama_tag=name, description="Test model",
    )


def _fit(fit_level: FitLevel, tps: float = 50.0) -> ModelFit:
    lm = LlmModel("test", 7.0, 32, 8, 128, 8192)
    if fit_level == FitLevel.TOO_TIGHT:
        return ModelFit(model=lm, fit_level=fit_level,
                        best_quant=None, mem_required_gb=None,
                        tokens_per_sec=None, runs_on_gpu=True)
    return ModelFit(model=lm, fit_level=fit_level,
                    best_quant=Quant.Q4_K_M, mem_required_gb=5.0,
                    tokens_per_sec=tps, runs_on_gpu=True)


# ── FIT_SCORE constants ───────────────────────────────────────────────────

class TestFitScoreConstants:
    def test_perfect_is_4(self):
        assert FIT_SCORE["Perfect"] == 4

    def test_good_is_3(self):
        assert FIT_SCORE["Good"] == 3

    def test_marginal_is_2(self):
        assert FIT_SCORE["Marginal"] == 2

    def test_toottight_is_0(self):
        assert FIT_SCORE["TooTight"] == 0


# ── USE_CASE_AFFINITY structure ────────────────────────────────────────────

class TestUseCaseAffinityStructure:
    def test_all_use_cases_present(self):
        for uc in ["chat", "coding", "reasoning", "writing", "fast"]:
            assert uc in USE_CASE_AFFINITY

    def test_affinity_values_are_1_or_2(self):
        for uc, mapping in USE_CASE_AFFINITY.items():
            for model_name, score in mapping.items():
                assert score in (1, 2), f"{uc}/{model_name} has invalid affinity {score}"

    def test_chat_includes_llama_primary(self):
        assert USE_CASE_AFFINITY["chat"]["llama3.2:3b"] == 2
        assert USE_CASE_AFFINITY["chat"]["mistral:7b"] == 2
        assert USE_CASE_AFFINITY["chat"]["gemma3:4b"] == 2

    def test_coding_includes_codellama_primary(self):
        assert USE_CASE_AFFINITY["coding"]["codellama:7b"] == 2

    def test_coding_includes_deepseek_primary(self):
        assert USE_CASE_AFFINITY["coding"]["deepseek-r1:7b"] == 2

    def test_reasoning_includes_deepseek_primary(self):
        assert USE_CASE_AFFINITY["reasoning"]["deepseek-r1:7b"] == 2

    def test_reasoning_includes_phi4_primary(self):
        assert USE_CASE_AFFINITY["reasoning"]["phi4:14b"] == 2

    def test_fast_includes_smollm2_primary(self):
        assert USE_CASE_AFFINITY["fast"]["smollm2:135m"] == 2

    def test_writing_includes_command_r_primary(self):
        assert USE_CASE_AFFINITY["writing"]["command-r:35b"] == 2


# ── _EXCLUDED_MODELS ──────────────────────────────────────────────────────

class TestExclusions:
    def test_nomic_embed_is_excluded(self):
        assert "nomic-embed-text:v1.5" in _EXCLUDED_MODELS

    def test_nomic_embed_not_in_results(self):
        nomic = _real("nomic-embed-text:v1.5")
        results = rank_models([(nomic, _fit(FitLevel.PERFECT, tps=999.0))], use_case=None)
        assert len(results) == 0

    def test_toottight_excluded(self):
        m = _real("big:model")
        results = rank_models([(m, _fit(FitLevel.TOO_TIGHT))], use_case=None)
        assert len(results) == 0

    def test_all_toottight_returns_empty(self):
        candidates = [(_real(f"m{i}"), _fit(FitLevel.TOO_TIGHT)) for i in range(5)]
        assert rank_models(candidates, use_case=None) == []


# ── rank_models() — basic ranking ─────────────────────────────────────────

class TestRankModels:
    def test_returns_at_most_top_n(self):
        candidates = [(_real(f"m{i}"), _fit(FitLevel.PERFECT)) for i in range(10)]
        assert len(rank_models(candidates, use_case=None, top_n=3)) == 3

    def test_returns_fewer_than_top_n_when_not_enough(self):
        candidates = [(_real("only"), _fit(FitLevel.GOOD))]
        assert len(rank_models(candidates, use_case=None, top_n=3)) == 1

    def test_empty_candidates_returns_empty(self):
        assert rank_models([], use_case=None) == []

    def test_perfect_ranks_above_good(self):
        candidates = [
            (_real("good:m"), _fit(FitLevel.GOOD,    tps=100.0)),
            (_real("perf:m"), _fit(FitLevel.PERFECT, tps=10.0)),
        ]
        results = rank_models(candidates, use_case=None)
        assert results[0].real_model.name == "perf:m"

    def test_good_ranks_above_marginal(self):
        candidates = [
            (_real("marg:m"), _fit(FitLevel.MARGINAL, tps=200.0)),
            (_real("good:m"), _fit(FitLevel.GOOD,     tps=1.0)),
        ]
        results = rank_models(candidates, use_case=None)
        assert results[0].real_model.name == "good:m"

    def test_tps_breaks_ties_within_same_fit(self):
        candidates = [
            (_real("slow"), _fit(FitLevel.PERFECT, tps=30.0)),
            (_real("fast"), _fit(FitLevel.PERFECT, tps=90.0)),
        ]
        results = rank_models(candidates, use_case=None)
        assert results[0].real_model.name == "fast"


# ── rank_models() — use-case affinity ─────────────────────────────────────

class TestUseCaseAffinity:
    def test_affinity_lifts_good_model_above_perfect_generic(self):
        """Good (3) + primary affinity (2) = 5 > Perfect (4) + no affinity (0) = 4."""
        chat_model = _real("llama3.2:3b")   # +2 for "chat"
        generic = _real("generic:7b")       # 0 affinity
        candidates = [
            (generic,    _fit(FitLevel.PERFECT, tps=50.0)),  # 4+0=4
            (chat_model, _fit(FitLevel.GOOD,    tps=50.0)),  # 3+2=5
        ]
        results = rank_models(candidates, use_case="chat")
        assert results[0].real_model.name == "llama3.2:3b"

    def test_no_use_case_ignores_affinity(self):
        """Without use_case all affinities are 0 — Pure fit+tps order."""
        chat_model = _real("llama3.2:3b")
        generic = _real("generic:7b")
        candidates = [
            (chat_model, _fit(FitLevel.GOOD,    tps=50.0)),
            (generic,    _fit(FitLevel.PERFECT, tps=50.0)),
        ]
        results = rank_models(candidates, use_case=None)
        assert results[0].real_model.name == "generic:7b"

    def test_unknown_use_case_safe_zero_affinity(self):
        m = _real("some:model")
        results = rank_models([(m, _fit(FitLevel.PERFECT))], use_case="nonexistent")
        assert len(results) == 1
        assert results[0].affinity == 0

    def test_scored_model_fields_populated_for_coding(self):
        m = _real("deepseek-r1:7b")
        results = rank_models([(m, _fit(FitLevel.PERFECT, tps=80.0))], use_case="coding")
        sm = results[0]
        assert sm.fit_score == 4
        assert sm.affinity == 2
        assert sm.total_score == 6

    def test_secondary_affinity_is_1(self):
        m = _real("phi4:14b")  # secondary for "coding"
        results = rank_models([(m, _fit(FitLevel.PERFECT))], use_case="coding")
        assert results[0].affinity == 1

    def test_fast_use_case_prefers_high_tps_small_model(self):
        """For 'fast', SmolLM2 (Perfect+2=6) beats large model (Perfect+0=4)."""
        smol = _real("smollm2:135m")
        big = _real("llama3.1:70b")
        candidates = [
            (big,  _fit(FitLevel.PERFECT, tps=5.0)),    # 4+0=4
            (smol, _fit(FitLevel.PERFECT, tps=500.0)),  # 4+2=6
        ]
        results = rank_models(candidates, use_case="fast")
        assert results[0].real_model.name == "smollm2:135m"
