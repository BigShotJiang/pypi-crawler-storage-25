"""Query pipeline — stage 5: embed, retrieve, rerank, generate."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from tinillm.rag.config import RagConfig


@dataclass
class Citation:
    key: str
    file_path: str
    page_number: Optional[int] = None
    section: Optional[str] = None


@dataclass
class QueryResult:
    answer: str
    citations: list[Citation]
    chunks_retrieved: int
    chunks_reranked: int


def run_query(
    question: str,
    config: RagConfig,
    llm_model: str,
    rerank: bool = True,
    web_augment: bool = False,
    top_k: int = 5,
    verbose: bool = False,
    console=None,
) -> QueryResult:
    """
    Full query pipeline: embed → hybrid search → rerank → generate.
    Streams LLM output to console via Rich Live.
    """
    from tinillm.rag.bm25 import BM25Index
    from tinillm.rag.embedder import Embedder
    from tinillm.rag.retriever import hybrid_search
    from tinillm.rag.vectorstore import VectorStore

    if console is None:
        from tinillm.rag.render import make_console
        console = make_console()

    vs = VectorStore(config.qdrant_path, config)
    bm25 = BM25Index(config.bm25_path)
    embedder = Embedder(config)

    try:
        return _run_query(
            question, config, llm_model,
            vs, bm25, embedder,
            rerank, web_augment, top_k, verbose, console,
        )
    finally:
        vs.close()


def _run_query(
    question: str,
    config: RagConfig,
    llm_model: str,
    vs,
    bm25,
    embedder,
    rerank: bool,
    web_augment: bool,
    top_k: int,
    verbose: bool,
    console,
) -> QueryResult:
    from tinillm.rag.retriever import hybrid_search

    # ── Step 1: Optional query rewrite ───────────────────────────────────
    effective_query = question
    if config.query_rewrite:
        effective_query = _rewrite_query(question, llm_model, config)
        if verbose:
            console.print(f"[dim]Rewritten: {effective_query}[/dim]")

    # ── Step 2: Embed query ───────────────────────────────────────────────
    query_vector = embedder.embed_single(effective_query)

    # ── Step 3: Hybrid retrieval ─────────────────────────────────────────
    candidates = hybrid_search(query_vector, question, config, vs, bm25)

    if not candidates:
        console.print("[bold yellow]No relevant documents found.[/] Index some documents first:")
        console.print("    [bold]tinillm rag ingest <path>[/]")
        return QueryResult(
            answer="No relevant documents found in the index.",
            citations=[],
            chunks_retrieved=0,
            chunks_reranked=0,
        )

    chunks_retrieved = len(candidates)

    # ── Step 4: Reranking ────────────────────────────────────────────────
    if rerank and len(candidates) > 1:
        from tinillm.rag.reranker import rerank as do_rerank
        final_chunks = do_rerank(question, candidates, top_k=top_k)
    else:
        final_chunks = candidates[:top_k]

    chunks_reranked = len(final_chunks)

    # ── Step 5: Optional web augmentation ───────────────────────────────
    web_context = ""
    if web_augment and config.searxng_url:
        web_context = _fetch_web_context(question, config)

    # ── Step 6: Context assembly with citations ──────────────────────────
    citations: list[Citation] = []
    context_parts: list[str] = []

    for i, chunk in enumerate(final_chunks, 1):
        p = chunk.payload
        key = f"[{i}]"
        fname = Path(p.get("file_path", "unknown")).name
        page = p.get("page_number")
        page_str = f", p.{page}" if page else ""
        context_parts.append(
            f"{key} (source: {fname}{page_str})\n{p.get('chunk_text', '')}"
        )
        citations.append(Citation(
            key=key,
            file_path=p.get("file_path", ""),
            page_number=page,
            section=p.get("section"),
        ))

    context = "\n\n---\n\n".join(context_parts)
    if web_context:
        context += f"\n\n---\n\nWeb context:\n{web_context}"

    # ── Step 7: Streaming generation ────────────────────────────────────
    prompt = (
        f"Context:\n{context}\n\n"
        f"Question: {question}\n\n"
        "Answer using only the context above. "
        "Cite sources as [N] inline."
    )

    answer_parts: list[str] = []
    try:
        import ollama
        from rich.live import Live
        from rich.markdown import Markdown

        stream = ollama.chat(
            model=llm_model,
            messages=[
                {"role": "system", "content": config.system_prompt},
                {"role": "user", "content": prompt},
            ],
            stream=True,
        )

        console.print()
        with Live(console=console, refresh_per_second=15) as live:
            for chunk in stream:
                token = chunk.message.content or ""
                answer_parts.append(token)
                live.update(Markdown("".join(answer_parts)))

    except KeyboardInterrupt:
        pass
    except Exception as exc:
        console.print(f"[bold red]Generation failed:[/] {exc}")

    answer = "".join(answer_parts)
    return QueryResult(
        answer=answer,
        citations=citations,
        chunks_retrieved=chunks_retrieved,
        chunks_reranked=chunks_reranked,
    )


def _rewrite_query(question: str, llm_model: str, config: RagConfig) -> str:
    """Rewrite a query to improve retrieval recall."""
    try:
        import ollama
        resp = ollama.chat(
            model=llm_model,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "Rewrite the user's query to improve document retrieval. "
                        "Output only the rewritten query, nothing else."
                    ),
                },
                {"role": "user", "content": question},
            ],
        )
        rewritten = resp.message.content.strip()
        return rewritten if rewritten else question
    except Exception:
        return question


def _fetch_web_context(question: str, config: RagConfig) -> str:
    """Fetch top results from SearXNG and return as formatted context."""
    try:
        import httpx
        resp = httpx.get(
            config.searxng_url.rstrip("/") + "/search",
            params={
                "q": question,
                "format": "json",
                "engines": "general",
            },
            timeout=10.0,
        )
        data = resp.json()
        results = data.get("results", [])[: config.searxng_max_results]
        lines = []
        for r in results:
            title = r.get("title", "")
            content = r.get("content", "")
            if title or content:
                lines.append(f"{title}: {content}")
        return "\n".join(lines)
    except Exception:
        return ""
