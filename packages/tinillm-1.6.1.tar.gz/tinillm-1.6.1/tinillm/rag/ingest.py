"""Ingestion pipeline — stages 1-4: discover, parse, chunk, embed+index."""

from __future__ import annotations

import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from tinillm.rag.chunkers.base import Chunk, get_chunker
from tinillm.rag.config import RagConfig
from tinillm.rag.discovery import discover
from tinillm.rag.manifest import FileRecord, ManifestDB
from tinillm.rag.parsers.base import Document, get_parser


@dataclass
class IngestionStats:
    discovered: int = 0
    skipped: int = 0
    parsed: int = 0
    embedded: int = 0
    failed: int = 0
    deleted: int = 0


def _parse_file(record: FileRecord) -> tuple[FileRecord, list[Document], Optional[str]]:
    """Parse a single file. Returns (record, docs, error_or_None)."""
    try:
        parser = get_parser(record.file_type)
        docs = parser.parse(Path(record.path))
        return record, docs, None
    except Exception as exc:
        return record, [], str(exc)


def _chunk_documents(
    record: FileRecord,
    docs: list[Document],
    config: RagConfig,
) -> list[Chunk]:
    chunker = get_chunker(record.file_type, config)
    all_chunks: list[Chunk] = []
    global_idx = 0
    for doc in docs:
        chunks = chunker.chunk(doc, record.id, record.sha256)
        for chunk in chunks:
            chunk.chunk_index = global_idx
            chunk.id = Chunk.make_id(record.path, global_idx)
            global_idx += 1
        all_chunks.extend(chunks)
    return all_chunks


def run_ingestion(
    sources: list[Path],
    config: RagConfig,
    include_types: Optional[set[str]] = None,
    force_reindex: bool = False,
    resume: bool = True,
    dry_run: bool = False,
    progress_callback=None,
) -> IngestionStats:
    """
    Full ingestion pipeline.
    progress_callback(stage, current, total, message) is called at each step.
    """
    config.ensure_dirs()
    manifest = ManifestDB(config.manifest_path)
    stats = IngestionStats()

    try:
        _run(
            sources, config, manifest, stats,
            include_types, force_reindex, resume, dry_run,
            progress_callback,
        )
    except KeyboardInterrupt:
        if progress_callback:
            progress_callback("interrupt", 0, 0, "Interrupted — run again to resume")
        manifest.close()
        raise
    finally:
        manifest.close()

    return stats


def _run(
    sources, config, manifest, stats,
    include_types, force_reindex, resume, dry_run, progress_callback,
):
    from tinillm.rag.bm25 import BM25Index
    from tinillm.rag.embedder import Embedder
    from tinillm.rag.vectorstore import VectorStore

    def _progress(stage, cur, total, msg):
        if progress_callback:
            progress_callback(stage, cur, total, msg)

    # ── Stage 1: Discovery ────────────────────────────────────────────────
    _progress("discover", 0, 0, "Scanning files...")
    result = discover(sources, manifest, include_types, force_reindex, resume)
    stats.discovered = len(result.to_process)
    stats.skipped = result.skipped

    if dry_run:
        _progress("dry_run", 0, 0,
                  f"Would process {stats.discovered} files, skip {stats.skipped}")
        return

    # Handle deletions
    if result.deleted:
        vs_del = VectorStore(config.qdrant_path, config)
        bm25_del = BM25Index(config.bm25_path)
        for rec in result.deleted:
            vs_del.delete_by_filter(rec.sha256)
            bm25_del.remove_documents(rec.id)
            manifest.mark_deleted(rec.id)
            stats.deleted += 1
        bm25_del.save()
        vs_del.close()

    if not result.to_process:
        return

    # ── Stage 2: Parse ────────────────────────────────────────────────────
    _progress("parse", 0, len(result.to_process), "Parsing files...")
    parsed: list[tuple[FileRecord, list[Document]]] = []

    with ThreadPoolExecutor(max_workers=config.parse_concurrency) as pool:
        futures = {pool.submit(_parse_file, rec): rec for rec in result.to_process}
        done = 0
        for future in as_completed(futures):
            rec, docs, err = future.result()
            done += 1
            if err:
                manifest.update_parse_status(rec.id, "failed", error=err)
                stats.failed += 1
            else:
                manifest.update_parse_status(
                    rec.id, "parsed", chunk_count=len(docs)
                )
                stats.parsed += 1
                parsed.append((rec, docs))
            _progress("parse", done, len(result.to_process),
                      f"Parsed {done}/{len(result.to_process)}")

    # ── Stage 3: Chunk ────────────────────────────────────────────────────
    _progress("chunk", 0, len(parsed), "Chunking documents...")
    chunked: list[tuple[FileRecord, list[Chunk]]] = []

    for i, (rec, docs) in enumerate(parsed):
        try:
            chunks = _chunk_documents(rec, docs, config)
            if chunks:
                manifest.update_parse_status(
                    rec.id, "parsed", chunk_count=len(chunks)
                )
                chunked.append((rec, chunks))
        except Exception as exc:
            manifest.update_parse_status(rec.id, "failed", error=str(exc))
            stats.failed += 1
        _progress("chunk", i + 1, len(parsed),
                  f"Chunked {i + 1}/{len(parsed)}")

    # ── Stage 4: Embed + Index ────────────────────────────────────────────
    if not chunked:
        return

    embedder = Embedder(config)
    vs = VectorStore(config.qdrant_path, config)
    bm25 = BM25Index(config.bm25_path)

    total_files = len(chunked)
    _progress("embed", 0, total_files, "Embedding and indexing...")

    def _embed_and_index(rec: FileRecord, chunks: list[Chunk]) -> Optional[str]:
        try:
            texts = [c.text for c in chunks]
            vectors = embedder.embed_batch(texts)

            points = [
                {
                    "id": _chunk_uuid_to_int(c.id),
                    "vector": vec,
                    "payload": {
                        "file_id":    c.file_id,
                        "file_path":  c.file_path,
                        "file_type":  c.file_type,
                        "chunk_index": c.chunk_index,
                        "chunk_text": c.text,
                        "page_number": c.page_number,
                        "section":    c.section,
                        "language":   c.language,
                        "sha256":     c.sha256,
                        "token_count": len(c.text) // 4,
                        "source_url": c.source_url,
                        "chunk_id":   c.id,
                    },
                }
                for c, vec in zip(chunks, vectors)
            ]
            vs.upsert(points)

            bm25_docs = [(c.file_id, c.id, c.text) for c in chunks]
            bm25.add_documents(bm25_docs)

            manifest.update_embed_status(rec.id, "embedded")
            return None
        except Exception as exc:
            return str(exc)

    with ThreadPoolExecutor(max_workers=config.embed_concurrency) as pool:
        futures = {
            pool.submit(_embed_and_index, rec, chunks): rec
            for rec, chunks in chunked
        }
        done = 0
        for future in as_completed(futures):
            rec = futures[future]
            err = future.result()
            done += 1
            if err:
                manifest.update_embed_status(rec.id, "failed", error=err)
                stats.failed += 1
            else:
                stats.embedded += 1
            _progress("embed", done, total_files,
                      f"Embedded {done}/{total_files}")

    bm25.save()
    vs.close()


def _chunk_uuid_to_int(chunk_id: str) -> int:
    """Convert UUID string to a uint64 for Qdrant point ID."""
    import uuid
    return uuid.UUID(chunk_id).int & 0xFFFFFFFFFFFFFFFF
