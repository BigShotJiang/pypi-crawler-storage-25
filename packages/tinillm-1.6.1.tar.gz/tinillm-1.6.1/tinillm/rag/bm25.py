"""BM25 sparse index backed by rank-bm25, serialized to disk."""

from __future__ import annotations

import pickle
import re
from pathlib import Path
from typing import Optional


def _tokenize(text: str) -> list[str]:
    return re.findall(r"\b\w+\b", text.lower())


class BM25Index:
    def __init__(self, index_path: Path) -> None:
        self._path = index_path
        self._docs: list[list[str]] = []         # tokenized docs
        self._ids: list[str] = []                # chunk ids parallel to _docs
        self._file_id_to_indices: dict[int, list[int]] = {}  # file_id → positions
        self._index = None                        # BM25Plus instance

        if index_path.exists():
            self._load()

    def add_documents(self, docs: list[tuple[int, str, str]]) -> None:
        """
        Add documents to the index.
        docs: list of (file_id, chunk_id, text)
        """
        for file_id, chunk_id, text in docs:
            tokens = _tokenize(text)
            pos = len(self._docs)
            self._docs.append(tokens)
            self._ids.append(chunk_id)
            self._file_id_to_indices.setdefault(file_id, []).append(pos)

        self._index = None  # invalidate cached index

    def _build_index(self):
        if self._index is None and self._docs:
            from rank_bm25 import BM25Plus
            self._index = BM25Plus(self._docs)

    def search(self, query: str, top_k: int = 50) -> list[tuple[str, float]]:
        if not self._docs:
            return []
        self._build_index()
        tokens = _tokenize(query)
        if not tokens:
            return []
        scores = self._index.get_scores(tokens)
        # Get top_k indices sorted by score descending
        indexed = sorted(enumerate(scores), key=lambda x: x[1], reverse=True)[:top_k]
        return [
            (self._ids[i], float(s))
            for i, s in indexed
            if s > 0
        ]

    def remove_documents(self, file_id: int) -> None:
        """Remove all chunks belonging to file_id and rebuild index."""
        indices_to_remove = set(self._file_id_to_indices.pop(file_id, []))
        if not indices_to_remove:
            return

        new_docs: list[list[str]] = []
        new_ids: list[str] = []
        # old_pos → new_pos mapping so other file_id entries stay correct
        old_to_new: dict[int, int] = {}

        for old_pos, (tokens, chunk_id) in enumerate(zip(self._docs, self._ids)):
            if old_pos in indices_to_remove:
                continue
            new_pos = len(new_docs)
            old_to_new[old_pos] = new_pos
            new_docs.append(tokens)
            new_ids.append(chunk_id)

        self._docs = new_docs
        self._ids = new_ids
        self._index = None

        # Remap surviving entries in _file_id_to_indices to new positions
        new_file_map: dict[int, list[int]] = {}
        for fid, positions in self._file_id_to_indices.items():
            remapped = [old_to_new[p] for p in positions if p in old_to_new]
            if remapped:
                new_file_map[fid] = remapped
        self._file_id_to_indices = new_file_map

    def save(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        with open(self._path, "wb") as f:
            pickle.dump(
                {
                    "docs": self._docs,
                    "ids": self._ids,
                    "file_id_map": self._file_id_to_indices,
                },
                f,
            )

    def _load(self) -> None:
        try:
            with open(self._path, "rb") as f:
                data = pickle.load(f)
            self._docs = data.get("docs", [])
            self._ids = data.get("ids", [])
            self._file_id_to_indices = data.get("file_id_map", {})
        except Exception:
            self._docs = []
            self._ids = []
            self._file_id_to_indices = {}

    @property
    def doc_count(self) -> int:
        return len(self._docs)
