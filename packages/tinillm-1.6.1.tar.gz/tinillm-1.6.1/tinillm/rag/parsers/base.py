"""Base types and parser factory."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Protocol


@dataclass
class Document:
    content: str
    metadata: dict = field(default_factory=dict)
    # metadata keys used downstream:
    #   file_path, file_type, page_number, section, language, source_url


class Parser(Protocol):
    def parse(self, path: Path) -> list[Document]:
        ...


class FallbackChainParser:
    """Try parsers in order; return result from first success."""

    def __init__(self, parsers: list[Parser]) -> None:
        self._parsers = parsers

    def parse(self, path: Path) -> list[Document]:
        last_exc: Optional[Exception] = None
        for parser in self._parsers:
            try:
                docs = parser.parse(path)
                if docs and any(d.content.strip() for d in docs):
                    return docs
            except Exception as exc:
                last_exc = exc
        raise RuntimeError(
            f"All parsers failed for {path}: {last_exc}"
        ) from last_exc


def get_parser(file_type: str) -> Parser:
    """Return the appropriate parser for a given file type."""
    from tinillm.rag.parsers.pdf import PDFParser
    from tinillm.rag.parsers.text import (
        PlainTextParser,
        MarkdownParser,
        HTMLParser,
    )
    from tinillm.rag.parsers.code import CodeParser
    from tinillm.rag.parsers.office import DocxParser, PptxParser, XlsxParser

    mapping: dict[str, Parser] = {
        "pdf":  PDFParser(),
        "txt":  PlainTextParser(),
        "md":   MarkdownParser(),
        "rst":  PlainTextParser(),
        "org":  PlainTextParser(),
        "html": HTMLParser(),
        "docx": FallbackChainParser([DocxParser(), PlainTextParser()]),
        "pptx": FallbackChainParser([PptxParser(), PlainTextParser()]),
        "xlsx": FallbackChainParser([XlsxParser(), PlainTextParser()]),
        "py":   CodeParser("python"),
        "c":    CodeParser("c"),
        "cpp":  CodeParser("cpp"),
        "rs":   CodeParser("rust"),
        "js":   CodeParser("javascript"),
        "ts":   CodeParser("typescript"),
        "v":    CodeParser("verilog"),
        "sv":   CodeParser("verilog"),
        "sh":   PlainTextParser(),
    }
    return mapping.get(file_type, PlainTextParser())
