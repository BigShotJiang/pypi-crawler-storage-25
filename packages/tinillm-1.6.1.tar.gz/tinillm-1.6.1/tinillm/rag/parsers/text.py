"""Plain text, Markdown, RST, and HTML parsers."""

from __future__ import annotations

from pathlib import Path

from tinillm.rag.parsers.base import Document


class PlainTextParser:
    def parse(self, path: Path) -> list[Document]:
        try:
            text = path.read_text(encoding="utf-8", errors="replace").strip()
        except Exception as exc:
            raise RuntimeError(f"Cannot read {path}: {exc}") from exc
        if not text:
            return []
        ext = path.suffix.lower().lstrip(".")
        return [Document(
            content=text,
            metadata={"file_path": str(path), "file_type": ext or "txt"},
        )]


class MarkdownParser:
    def parse(self, path: Path) -> list[Document]:
        try:
            text = path.read_text(encoding="utf-8", errors="replace").strip()
        except Exception as exc:
            raise RuntimeError(f"Cannot read {path}: {exc}") from exc
        if not text:
            return []
        return [Document(
            content=text,
            metadata={"file_path": str(path), "file_type": "md"},
        )]


class HTMLParser:
    def parse(self, path: Path) -> list[Document]:
        try:
            raw = path.read_text(encoding="utf-8", errors="replace")
        except Exception as exc:
            raise RuntimeError(f"Cannot read {path}: {exc}") from exc

        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(raw, "lxml")
        except ImportError:
            from bs4 import BeautifulSoup  # type: ignore[no-redef]
            soup = BeautifulSoup(raw, "html.parser")

        # Remove script/style tags
        for tag in soup(["script", "style", "noscript", "head"]):
            tag.decompose()

        text = soup.get_text(separator="\n").strip()
        # Collapse excessive blank lines
        import re
        text = re.sub(r"\n{3,}", "\n\n", text).strip()

        if not text:
            return []
        return [Document(
            content=text,
            metadata={"file_path": str(path), "file_type": "html"},
        )]
