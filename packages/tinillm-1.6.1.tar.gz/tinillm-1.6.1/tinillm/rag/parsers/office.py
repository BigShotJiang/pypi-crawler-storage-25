"""Office document parsers — .docx, .pptx, .xlsx."""

from __future__ import annotations

from pathlib import Path

from tinillm.rag.parsers.base import Document


class DocxParser:
    def parse(self, path: Path) -> list[Document]:
        try:
            from docx import Document as DocxDoc
        except ImportError:
            raise ImportError("python-docx not installed. Run: pip install tinillm[rag]")

        doc = DocxDoc(str(path))
        paragraphs = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
        text = "\n\n".join(paragraphs)
        if not text:
            return []
        return [Document(
            content=text,
            metadata={"file_path": str(path), "file_type": "docx"},
        )]


class PptxParser:
    def parse(self, path: Path) -> list[Document]:
        try:
            from pptx import Presentation
        except ImportError:
            raise ImportError("python-pptx not installed. Run: pip install tinillm[rag]")

        prs = Presentation(str(path))
        docs: list[Document] = []
        for slide_num, slide in enumerate(prs.slides, 1):
            texts = []
            for shape in slide.shapes:
                if hasattr(shape, "text") and shape.text.strip():
                    texts.append(shape.text.strip())
            if texts:
                docs.append(Document(
                    content="\n".join(texts),
                    metadata={
                        "file_path": str(path),
                        "file_type": "pptx",
                        "page_number": slide_num,
                    },
                ))
        return docs


class XlsxParser:
    def parse(self, path: Path) -> list[Document]:
        try:
            import openpyxl
        except ImportError:
            raise ImportError("openpyxl not installed. Run: pip install tinillm[rag]")

        wb = openpyxl.load_workbook(str(path), read_only=True, data_only=True)
        docs: list[Document] = []
        for sheet in wb.worksheets:
            rows = []
            for row in sheet.iter_rows(values_only=True):
                cells = [str(c) for c in row if c is not None and str(c).strip()]
                if cells:
                    rows.append("\t".join(cells))
            if rows:
                docs.append(Document(
                    content="\n".join(rows),
                    metadata={
                        "file_path": str(path),
                        "file_type": "xlsx",
                        "section": sheet.title,
                    },
                ))
        wb.close()
        return docs
