"""Code parser — tree-sitter AST-aware extraction with plain-text fallback."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from tinillm.rag.parsers.base import Document

# Map our file_type names to tree-sitter language package names
_LANG_MAP = {
    "python":     "python",
    "c":          "c",
    "cpp":        "cpp",
    "rust":       "rust",
    "javascript": "javascript",
    "typescript": "typescript",
    "verilog":    None,  # tree-sitter-verilog may not be available
}


def _load_language(lang_name: str):
    """Load a tree-sitter Language object. Returns None if unavailable."""
    try:
        import importlib
        mod = importlib.import_module(f"tree_sitter_{lang_name.replace('-', '_')}")
        from tree_sitter import Language
        if hasattr(mod, "language"):
            return Language(mod.language())
        if hasattr(mod, "LANGUAGE"):
            return Language(mod.LANGUAGE)
        # Try the older API
        lang_fn = getattr(mod, f"language_{lang_name}", None)
        if lang_fn:
            return Language(lang_fn())
    except Exception:
        pass
    return None


class CodeParser:
    """
    Extracts top-level definitions (functions, classes, modules) using tree-sitter.
    Falls back to whole-file plain text if tree-sitter grammar unavailable.
    """

    def __init__(self, language: str) -> None:
        self._language = language

    def parse(self, path: Path) -> list[Document]:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except Exception as exc:
            raise RuntimeError(f"Cannot read {path}: {exc}") from exc

        if not text.strip():
            return []

        lang_name = _LANG_MAP.get(self._language, self._language)
        if lang_name:
            docs = self._parse_with_treesitter(path, text, lang_name)
            if docs:
                return docs

        # Fallback: return whole file as one document
        return [Document(
            content=text.strip(),
            metadata={
                "file_path": str(path),
                "file_type": self._language,
                "language": self._language,
            },
        )]

    def _parse_with_treesitter(
        self, path: Path, text: str, lang_name: str
    ) -> list[Document]:
        try:
            from tree_sitter import Parser as TSParser
        except ImportError:
            return []

        lang = _load_language(lang_name)
        if lang is None:
            return []

        try:
            parser = TSParser(lang)
            tree = parser.parse(text.encode("utf-8"))
        except Exception:
            return []

        # Extract top-level named nodes that represent code units
        target_types = {
            "function_definition",    # Python
            "class_definition",       # Python
            "function_item",          # Rust
            "impl_item",              # Rust
            "struct_item",            # Rust
            "function_declaration",   # JS/TS
            "method_definition",      # JS/TS
            "class_declaration",      # JS/TS
            "function_definition",    # C/C++
            "declaration",            # C/C++
            "module_item",            # Rust modules
        }

        docs: list[Document] = []
        for node in tree.root_node.children:
            if node.type in target_types:
                chunk_text = text[node.start_byte: node.end_byte].strip()
                if len(chunk_text) < 10:
                    continue
                docs.append(Document(
                    content=chunk_text,
                    metadata={
                        "file_path": str(path),
                        "file_type": self._language,
                        "language": self._language,
                        "start_line": node.start_point[0] + 1,
                        "end_line": node.end_point[0] + 1,
                    },
                ))

        # If no top-level defs found, fall back to whole file
        return docs if docs else []
