"""PDF parser — PyMuPDF primary, Marker fallback for complex/scanned docs."""

from __future__ import annotations

from pathlib import Path

from tinillm.rag.parsers.base import Document, FallbackChainParser


class _PyMuPDFParser:
    """Extract text using PyMuPDF with layout-aware block extraction."""

    def parse(self, path: Path) -> list[Document]:
        import fitz  # PyMuPDF

        docs: list[Document] = []
        with fitz.open(str(path)) as pdf:
            for page_num, page in enumerate(pdf, 1):
                text = page.get_text("text").strip()
                if not text:
                    continue
                docs.append(Document(
                    content=text,
                    metadata={
                        "file_path": str(path),
                        "file_type": "pdf",
                        "page_number": page_num,
                    },
                ))
        return docs


class _PyMuPDF4LLMParser:
    """Extract structured markdown including tables via pymupdf4llm."""

    def parse(self, path: Path) -> list[Document]:
        import pymupdf4llm

        md_text = pymupdf4llm.to_markdown(str(path), page_chunks=True)
        docs: list[Document] = []
        if isinstance(md_text, list):
            for chunk in md_text:
                text = chunk.get("text", "") if isinstance(chunk, dict) else str(chunk)
                page = chunk.get("metadata", {}).get("page", None) if isinstance(chunk, dict) else None
                if text.strip():
                    docs.append(Document(
                        content=text.strip(),
                        metadata={
                            "file_path": str(path),
                            "file_type": "pdf",
                            "page_number": page,
                        },
                    ))
        else:
            if str(md_text).strip():
                docs.append(Document(
                    content=str(md_text).strip(),
                    metadata={"file_path": str(path), "file_type": "pdf"},
                ))
        return docs


class _MarkerParser:
    """Marker-PDF fallback for complex/scanned PDFs."""

    def parse(self, path: Path) -> list[Document]:
        try:
            from marker.convert import convert_single_pdf
            from marker.models import load_all_models
        except ImportError:
            raise ImportError("marker-pdf not installed. Run: pip install tinillm[rag]")

        model_lst = load_all_models()
        full_text, _, _ = convert_single_pdf(str(path), model_lst)
        if not full_text or not full_text.strip():
            return []
        return [Document(
            content=full_text.strip(),
            metadata={"file_path": str(path), "file_type": "pdf"},
        )]


class PDFParser:
    """
    Tries in order:
    1. pymupdf4llm (best for text-native PDFs with tables)
    2. PyMuPDF plain (fast fallback)
    3. Marker (scanned / complex layout)
    """

    def __init__(self) -> None:
        self._chain = FallbackChainParser([
            _PyMuPDF4LLMParser(),
            _PyMuPDFParser(),
            _MarkerParser(),
        ])

    def parse(self, path: Path) -> list[Document]:
        return self._chain.parse(path)
