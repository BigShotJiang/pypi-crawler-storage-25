"""Parser package — format-specific document extractors."""

from __future__ import annotations

from tinillm.rag.parsers.base import Document, Parser, get_parser

__all__ = ["Document", "Parser", "get_parser"]
