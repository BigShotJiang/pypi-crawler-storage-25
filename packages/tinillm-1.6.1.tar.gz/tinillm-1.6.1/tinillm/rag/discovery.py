"""File discovery, deduplication, and change detection."""

from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator, Optional

from tinillm.rag.manifest import FileRecord, ManifestDB

# File extensions we know how to handle
SUPPORTED_EXTENSIONS: dict[str, str] = {
    # documents
    ".pdf":  "pdf",
    ".txt":  "txt",
    ".md":   "md",
    ".rst":  "rst",
    ".org":  "org",
    # web
    ".html": "html",
    ".htm":  "html",
    ".mhtml": "html",
    # office
    ".docx": "docx",
    ".pptx": "pptx",
    ".xlsx": "xlsx",
    # code
    ".py":   "py",
    ".c":    "c",
    ".h":    "c",
    ".cpp":  "cpp",
    ".cc":   "cpp",
    ".cxx":  "cpp",
    ".hpp":  "cpp",
    ".rs":   "rs",
    ".js":   "js",
    ".ts":   "ts",
    ".jsx":  "js",
    ".tsx":  "ts",
    ".v":    "v",
    ".sv":   "sv",
    ".sh":   "sh",
    ".bash": "sh",
    ".zsh":  "sh",
}

CODE_TYPES = {"py", "c", "cpp", "rs", "js", "ts", "v", "sv", "sh"}


def _walk_paths(sources: list[Path], include_types: Optional[set[str]]) -> Iterator[Path]:
    for source in sources:
        if source.is_file():
            yield source
        else:
            for root, dirs, files in os.walk(source):
                # Skip hidden directories
                dirs[:] = [d for d in dirs if not d.startswith(".")]
                for fname in files:
                    p = Path(root) / fname
                    ext = p.suffix.lower()
                    if ext not in SUPPORTED_EXTENSIONS:
                        continue
                    ftype = SUPPORTED_EXTENSIONS[ext]
                    if include_types and ftype not in include_types:
                        continue
                    yield p


def hash_file(path: Path) -> str:
    """SHA-256 of file contents, reading in 64 KB chunks."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


@dataclass
class DiscoveryResult:
    to_process: list[FileRecord]
    skipped: int
    deleted: list[FileRecord]


def discover(
    sources: list[Path],
    manifest: ManifestDB,
    include_types: Optional[set[str]] = None,
    force_reindex: bool = False,
    resume: bool = True,
) -> DiscoveryResult:
    """Walk sources, hash files, compare with manifest, return disposition."""
    to_process: list[FileRecord] = []
    skipped = 0

    seen_paths: set[str] = set()

    for path in _walk_paths(sources, include_types):
        try:
            stat = path.stat()
        except OSError:
            continue

        seen_paths.add(str(path))
        ext = path.suffix.lower()
        file_type = SUPPORTED_EXTENSIONS.get(ext, "txt")
        mtime = stat.st_mtime
        size_bytes = stat.st_size

        existing: Optional[FileRecord] = manifest.lookup(path)

        if force_reindex:
            sha256 = hash_file(path)
            disposition = "changed"
        elif existing is None:
            sha256 = hash_file(path)
            disposition = "new"
        else:
            # Fast-path: if mtime and size match, trust the existing hash
            if (
                abs(existing.mtime - mtime) < 1.0
                and existing.size_bytes == size_bytes
                and existing.embed_status == "embedded"
                and resume
            ):
                skipped += 1
                continue
            # Re-hash only when metadata changed
            sha256 = hash_file(path)
            if existing.sha256 == sha256 and existing.embed_status == "embedded" and resume:
                skipped += 1
                continue
            elif existing.sha256 == sha256 and existing.embed_status in ("pending", "failed"):
                disposition = "resume"
            else:
                disposition = "changed" if existing.sha256 != sha256 else "resume"

        record = manifest.upsert(path, sha256, size_bytes, mtime, file_type, disposition)
        to_process.append(record)

    deleted = manifest.find_deleted(sources)

    return DiscoveryResult(
        to_process=to_process,
        skipped=skipped,
        deleted=deleted,
    )
