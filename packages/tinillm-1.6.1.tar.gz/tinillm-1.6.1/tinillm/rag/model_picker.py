"""Interactive model picker for RAG — lists Ollama-installed models."""

from __future__ import annotations

import sys
from typing import Optional

import click


def _get_ollama_models() -> list[dict]:
    """Return list of dicts with 'name' and 'size_gb' for installed models."""
    try:
        import ollama
        response = ollama.list()
        models = []
        for m in response.models:
            name = m.model if hasattr(m, "model") else str(m)
            size_gb = round(m.size / 1_073_741_824, 1) if hasattr(m, "size") and m.size else 0.0
            models.append({"name": name, "size_gb": size_gb})
        return models
    except Exception:
        return []


def _is_embed_model(name: str) -> bool:
    embed_keywords = ["embed", "nomic", "mxbai", "bge-m3", "all-minilm"]
    n = name.lower()
    return any(k in n for k in embed_keywords)


def _make_console():
    import os
    from rich.console import Console
    from tinillm.render.styles import TINILLM_THEME
    no_color = "NO_COLOR" in os.environ
    return Console(theme=TINILLM_THEME, no_color=no_color, highlight=False)


def check_ollama_running() -> bool:
    try:
        import ollama
        ollama.list()
        return True
    except Exception:
        return False


def pick_embed_model(config) -> Optional[str]:
    """
    If config.embed_model is set, return it.
    Otherwise list installed Ollama models, show a picker, and optionally save.
    Returns the selected model name, or None if user quit.
    """
    if config.embed_model:
        return config.embed_model

    console = _make_console()
    models = _get_ollama_models()

    if not models:
        console.print("[bold red]No Ollama models found.[/] Pull one first:")
        console.print("    [bold]ollama pull nomic-embed-text[/]")
        sys.exit(1)

    # Prefer embed-specific models first
    embed_models = [m for m in models if _is_embed_model(m["name"])]
    general_models = [m for m in models if not _is_embed_model(m["name"])]
    ordered = embed_models + general_models

    _print_model_table(console, ordered, title="Select an embedding model", highlight_embed=True)

    choice = _prompt_choice(len(ordered))
    if choice is None:
        sys.exit(0)

    selected = ordered[choice - 1]["name"]

    if click.confirm("Save as default embed model for future ingestions?", default=False):
        from tinillm.rag.config import save_model_selection
        save_model_selection(embed_model=selected)
        config.embed_model = selected
        console.print(f"[dim]Saved embed model: {selected}[/]")

    return selected


def pick_llm_model(config) -> Optional[str]:
    """
    If config.llm_model is set, return it.
    If only one model installed, auto-select silently.
    Otherwise show a picker and optionally save.
    Returns selected model name, or None if user quit.
    """
    if config.llm_model:
        return config.llm_model

    console = _make_console()
    models = _get_ollama_models()

    if not models:
        console.print("[bold red]No Ollama models found.[/] Pull one first:")
        console.print("    [bold]ollama pull qwen2.5:7b[/]")
        sys.exit(1)

    # Filter out pure embed models for LLM selection
    llm_models = [m for m in models if not _is_embed_model(m["name"])]
    if not llm_models:
        llm_models = models  # fall back to all if nothing else

    if len(llm_models) == 1:
        selected = llm_models[0]["name"]
        console.print(f"[dim]Auto-selected model: {selected}[/]")
        return selected

    _print_model_table(console, llm_models, title="Select a model for generation")

    choice = _prompt_choice(len(llm_models))
    if choice is None:
        sys.exit(0)

    selected = llm_models[choice - 1]["name"]

    if click.confirm("Save as default LLM model for future queries?", default=False):
        from tinillm.rag.config import save_model_selection
        save_model_selection(llm_model=selected)
        config.llm_model = selected
        console.print(f"[dim]Saved LLM model: {selected}[/]")

    return selected


def _print_model_table(
    console,
    models: list[dict],
    title: str,
    highlight_embed: bool = False,
) -> None:
    from rich.table import Table
    from rich import box

    console.print(f"\n[bold white]{title}:[/]\n")

    table = Table(
        box=box.SIMPLE_HEAD,
        show_header=True,
        header_style="bold white",
        padding=(0, 1),
    )
    table.add_column("#", style="dim", width=4)
    table.add_column("Model", min_width=30)
    table.add_column("Size", min_width=10, justify="right")
    if highlight_embed:
        table.add_column("Type", min_width=14)

    for i, m in enumerate(models, 1):
        size_str = f"{m['size_gb']:.1f} GB" if m["size_gb"] > 0 else "—"
        if highlight_embed:
            mtype = "[bold cyan]embedding[/]" if _is_embed_model(m["name"]) else "general"
            table.add_row(str(i), m["name"], size_str, mtype)
        else:
            table.add_row(str(i), m["name"], size_str)

    console.print(table)


def _prompt_choice(count: int) -> Optional[int]:
    while True:
        raw = click.prompt(
            f"Enter number [1-{count}] (q to quit)",
            default="q",
            show_default=False,
        )
        stripped = raw.strip().lower()
        if stripped == "q":
            return None
        try:
            n = int(stripped)
        except ValueError:
            click.echo("Please enter a number or 'q' to quit.")
            continue
        if 1 <= n <= count:
            return n
        click.echo(f"Please enter a number between 1 and {count}.")
