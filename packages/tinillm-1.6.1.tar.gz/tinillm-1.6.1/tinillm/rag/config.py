"""RagConfig — loads ~/.config/tinillm/rag.toml, falls back to defaults."""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomllib
    except ImportError:
        import tomli as tomllib  # type: ignore[no-redef]


_DEFAULT_DATA_DIR = Path.home() / ".local" / "share" / "tinillm" / "rag"
_DEFAULT_CONFIG_PATH = Path.home() / ".config" / "tinillm" / "rag.toml"


@dataclass
class RagConfig:
    # paths
    data_dir: Path = field(default_factory=lambda: _DEFAULT_DATA_DIR)

    # models — None means "not configured; pick interactively"
    llm_model: Optional[str] = None
    embed_model: Optional[str] = None
    embed_dim: int = 768

    # chunking
    pdf_chunk_size: int = 512
    pdf_overlap: int = 64
    prose_chunk_size: int = 384
    prose_overlap: int = 48
    code_chunk_size: int = 256
    code_overlap: int = 32

    # embedding
    embed_batch_size: int = 32
    embed_concurrency: int = 4
    parse_concurrency: int = 8

    # search
    dense_top_k: int = 50
    sparse_top_k: int = 50
    rerank_top_k: int = 5
    dense_threshold: float = 0.30
    query_rewrite: bool = False

    # generation
    system_prompt: str = (
        "You are a precise research assistant. "
        "Answer using only the provided context. Cite sources as [N]."
    )

    # web augmentation
    searxng_url: str = ""
    searxng_max_results: int = 5

    @property
    def manifest_path(self) -> Path:
        return self.data_dir / "manifest.db"

    @property
    def qdrant_path(self) -> Path:
        return self.data_dir / "qdrant"

    @property
    def bm25_path(self) -> Path:
        return self.data_dir / "bm25.pkl"

    def ensure_dirs(self) -> None:
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.qdrant_path.mkdir(parents=True, exist_ok=True)


def load_config(config_path: Optional[Path] = None) -> RagConfig:
    """Load RagConfig from TOML file; fall back to defaults if absent."""
    path = config_path or _DEFAULT_CONFIG_PATH
    raw: dict = {}

    if path.exists():
        with open(path, "rb") as f:
            raw = tomllib.load(f)

    cfg = RagConfig()

    paths = raw.get("paths", {})
    if "data_dir" in paths:
        cfg.data_dir = Path(paths["data_dir"]).expanduser()

    models = raw.get("models", {})
    cfg.llm_model = models.get("llm_model") or None
    cfg.embed_model = models.get("embed_model") or None
    if "embed_dim" in models:
        cfg.embed_dim = int(models["embed_dim"])

    chunking = raw.get("chunking", {})
    for attr in ("pdf_chunk_size", "pdf_overlap", "prose_chunk_size", "prose_overlap",
                 "code_chunk_size", "code_overlap"):
        if attr in chunking:
            setattr(cfg, attr, int(chunking[attr]))

    embedding = raw.get("embedding", {})
    for attr in ("embed_batch_size", "embed_concurrency", "parse_concurrency"):
        if attr in embedding:
            setattr(cfg, attr, int(embedding[attr]))

    search = raw.get("search", {})
    for attr in ("dense_top_k", "sparse_top_k", "rerank_top_k"):
        if attr in search:
            setattr(cfg, attr, int(search[attr]))
    if "dense_threshold" in search:
        cfg.dense_threshold = float(search["dense_threshold"])
    if "query_rewrite" in search:
        cfg.query_rewrite = bool(search["query_rewrite"])

    generation = raw.get("generation", {})
    if "system_prompt" in generation:
        cfg.system_prompt = generation["system_prompt"]

    web = raw.get("web", {})
    if "searxng_url" in web:
        cfg.searxng_url = web["searxng_url"]
    if "searxng_max_results" in web:
        cfg.searxng_max_results = int(web["searxng_max_results"])

    return cfg


def save_model_selection(
    llm_model: Optional[str] = None,
    embed_model: Optional[str] = None,
    config_path: Optional[Path] = None,
) -> None:
    """Persist model selections back to rag.toml."""
    path = config_path or _DEFAULT_CONFIG_PATH
    path.parent.mkdir(parents=True, exist_ok=True)

    # Read existing content as text to preserve other settings
    existing_lines: list[str] = []
    if path.exists():
        existing_lines = path.read_text().splitlines()

    # Simple approach: rewrite [models] section
    # Build new content
    new_lines: list[str] = []
    in_models = False
    models_written = False

    for line in existing_lines:
        stripped = line.strip()
        if stripped.startswith("[") and stripped != "[models]":
            if in_models and not models_written:
                # write model keys before next section
                _append_model_keys(new_lines, llm_model, embed_model)
                models_written = True
            in_models = False
            new_lines.append(line)
        elif stripped == "[models]":
            in_models = True
            new_lines.append(line)
        elif in_models and stripped.startswith("llm_model"):
            if llm_model is not None:
                new_lines.append(f'llm_model = "{llm_model}"')
            # else drop the key (unset)
        elif in_models and stripped.startswith("embed_model"):
            if embed_model is not None:
                new_lines.append(f'embed_model = "{embed_model}"')
        else:
            new_lines.append(line)

    if in_models and not models_written:
        _append_model_keys(new_lines, llm_model, embed_model)
        models_written = True

    if not models_written:
        new_lines.append("")
        new_lines.append("[models]")
        _append_model_keys(new_lines, llm_model, embed_model)

    path.write_text("\n".join(new_lines) + "\n")


def _append_model_keys(
    lines: list[str],
    llm_model: Optional[str],
    embed_model: Optional[str],
) -> None:
    if llm_model is not None:
        lines.append(f'llm_model = "{llm_model}"')
    if embed_model is not None:
        lines.append(f'embed_model = "{embed_model}"')
