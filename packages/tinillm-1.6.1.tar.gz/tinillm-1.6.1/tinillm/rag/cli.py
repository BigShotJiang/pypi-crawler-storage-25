"""tinillm rag — Click group and all subcommands."""

from __future__ import annotations

import os
import sys
import time
from pathlib import Path
from typing import Optional

import click


@click.group()
def rag() -> None:
    """Local-first RAG — index documents, query locally via Ollama."""
    pass


# ── ingest ────────────────────────────────────────────────────────────────────

@rag.command("ingest")
@click.argument("sources", nargs=-1, required=True, type=click.Path(exists=True))
@click.option("--resume/--no-resume", default=True, show_default=True,
              help="Skip files already successfully indexed.")
@click.option("--force-reindex", is_flag=True, default=False,
              help="Re-embed all files regardless of hash.")
@click.option("--types", default=None, metavar="TYPES",
              help="Comma-separated file types to include, e.g. pdf,md,txt,py")
@click.option("--dry-run", is_flag=True, default=False,
              help="Show what would be indexed without doing it.")
@click.option("--no-color", is_flag=True, default=False,
              help="Suppress colors.")
@click.option("--json", "json_output", is_flag=True, default=False,
              help="Output summary as JSON.")
def ingest(
    sources: tuple[str, ...],
    resume: bool,
    force_reindex: bool,
    types: Optional[str],
    dry_run: bool,
    no_color: bool,
    json_output: bool,
) -> None:
    """Index documents from one or more source paths."""
    if no_color:
        os.environ["NO_COLOR"] = "1"

    from tinillm.rag.config import load_config
    from tinillm.rag.ingest import run_ingestion
    from tinillm.rag.model_picker import check_ollama_running, pick_embed_model
    from tinillm.rag.render import (
        make_console,
        render_ingest_progress,
        render_ingest_start,
        render_ingest_summary,
    )

    config = load_config()
    console = make_console()
    source_paths = [Path(s) for s in sources]

    if not dry_run:
        if not check_ollama_running():
            console.print("[bold red]Ollama is not running.[/] Start it with:")
            console.print("    [bold]ollama serve[/]")
            sys.exit(1)

        # Pick embed model interactively if not configured
        embed_model = pick_embed_model(config)
        config.embed_model = embed_model

    include_types: Optional[set[str]] = None
    if types:
        include_types = {t.strip().lower() for t in types.split(",")}

    if not json_output:
        render_ingest_start(console, source_paths, dry_run)

    def _progress(stage, cur, total, msg):
        if not json_output:
            render_ingest_progress(console, stage, cur, total, msg)

    start = time.time()
    try:
        stats = run_ingestion(
            sources=source_paths,
            config=config,
            include_types=include_types,
            force_reindex=force_reindex,
            resume=resume,
            dry_run=dry_run,
            progress_callback=_progress,
        )
    except KeyboardInterrupt:
        if not json_output:
            console.print(
                "\n[bold yellow]Interrupted.[/] Run again with [bold]--resume[/] to continue."
            )
        sys.exit(1)

    elapsed = time.time() - start

    if json_output:
        import json
        click.echo(json.dumps({
            "discovered": stats.discovered,
            "skipped":    stats.skipped,
            "parsed":     stats.parsed,
            "embedded":   stats.embedded,
            "failed":     stats.failed,
            "deleted":    stats.deleted,
            "elapsed_s":  round(elapsed, 2),
        }, indent=2))
    else:
        render_ingest_summary(console, stats, elapsed)


# ── query ─────────────────────────────────────────────────────────────────────

@rag.command("query")
@click.argument("question")
@click.option("--model", default=None, metavar="MODEL_TAG",
              help="Override LLM model for this query only.")
@click.option("--top-k", default=5, show_default=True, type=int,
              help="Number of chunks to use in final context.")
@click.option("--no-rerank", is_flag=True, default=False,
              help="Skip cross-encoder reranking (faster, lower quality).")
@click.option("--web", is_flag=True, default=False,
              help="Augment with SearXNG web results (requires searxng_url in config).")
@click.option("--verbose", "-v", is_flag=True, default=False,
              help="Show retrieval details.")
@click.option("--no-color", is_flag=True, default=False,
              help="Suppress colors.")
@click.option("--json", "json_output", is_flag=True, default=False,
              help="Output result as JSON.")
def query(
    question: str,
    model: Optional[str],
    top_k: int,
    no_rerank: bool,
    web: bool,
    verbose: bool,
    no_color: bool,
    json_output: bool,
) -> None:
    """Ask a question against the indexed corpus."""
    if no_color:
        os.environ["NO_COLOR"] = "1"

    from tinillm.rag.config import load_config
    from tinillm.rag.model_picker import check_ollama_running, pick_embed_model, pick_llm_model
    from tinillm.rag.query import run_query
    from tinillm.rag.render import make_console, render_citations, render_query_json

    config = load_config()
    console = make_console()

    if not check_ollama_running():
        console.print("[bold red]Ollama is not running.[/] Start it with:")
        console.print("    [bold]ollama serve[/]")
        sys.exit(1)

    # Resolve embed model (needed to embed the query vector)
    embed_model = pick_embed_model(config)
    config.embed_model = embed_model

    # --model flag overrides config for this invocation only
    if model:
        config.llm_model = model
        llm_model = model
    else:
        llm_model = pick_llm_model(config)

    result = run_query(
        question=question,
        config=config,
        llm_model=llm_model,
        rerank=not no_rerank,
        web_augment=web,
        top_k=top_k,
        verbose=verbose,
        console=console,
    )

    if json_output:
        click.echo(render_query_json(result))
    else:
        render_citations(console, result.citations)
        if verbose:
            console.print(
                f"[dim]Retrieved: {result.chunks_retrieved} chunks, "
                f"reranked to {result.chunks_reranked}[/dim]"
            )


# ── status ────────────────────────────────────────────────────────────────────

@rag.command("status")
@click.argument("source", required=False, default=None, type=click.Path())
@click.option("--verbose", "-v", is_flag=True, default=False,
              help="Show per-file-type breakdown.")
@click.option("--no-color", is_flag=True, default=False,
              help="Suppress colors.")
@click.option("--json", "json_output", is_flag=True, default=False,
              help="Output as JSON.")
def status(
    source: Optional[str],
    verbose: bool,
    no_color: bool,
    json_output: bool,
) -> None:
    """Show index statistics and ingestion state."""
    if no_color:
        os.environ["NO_COLOR"] = "1"

    from tinillm.rag.bm25 import BM25Index
    from tinillm.rag.config import load_config
    from tinillm.rag.manifest import ManifestDB
    from tinillm.rag.render import (
        make_console,
        render_status,
        render_status_by_type,
        render_status_json,
    )
    from tinillm.rag.vectorstore import VectorStore

    config = load_config()
    console = make_console()

    if not config.manifest_path.exists():
        if not json_output:
            console.print("[dim]No index found. Run:[/dim] tinillm rag ingest <path>")
        else:
            click.echo('{"indexed_files": 0}')
        return

    manifest = ManifestDB(config.manifest_path)
    db_stats = manifest.get_stats()
    by_type = manifest.get_stats_by_type() if verbose else []
    manifest.close()

    try:
        vs = VectorStore(config.qdrant_path, config)
        vector_info = vs.get_collection_info()
    except Exception:
        vector_info = {}

    bm25 = BM25Index(config.bm25_path)
    bm25_count = bm25.doc_count

    if json_output:
        click.echo(render_status_json(db_stats, vector_info, bm25_count))
    else:
        render_status(console, db_stats, vector_info, bm25_count)
        if verbose and by_type:
            render_status_by_type(console, by_type)


# ── config ────────────────────────────────────────────────────────────────────

@rag.command("config")
@click.option("--check", is_flag=True, default=False,
              help="Validate config and check all dependencies.")
@click.option("--no-color", is_flag=True, default=False,
              help="Suppress colors.")
def config_cmd(check: bool, no_color: bool) -> None:
    """Show or validate current RAG configuration."""
    if no_color:
        os.environ["NO_COLOR"] = "1"

    from tinillm.rag.config import load_config
    from tinillm.rag.render import make_console, render_config, render_config_check

    config = load_config()
    console = make_console()

    if check:
        render_config_check(console, config)
    else:
        render_config(console, config)


# ── delete ────────────────────────────────────────────────────────────────────

@rag.command("delete")
@click.argument("source", type=click.Path(exists=True))
@click.option("--confirm", is_flag=True, default=False,
              help="Skip confirmation prompt.")
@click.option("--no-color", is_flag=True, default=False,
              help="Suppress colors.")
def delete(source: str, confirm: bool, no_color: bool) -> None:
    """Remove a source path and all its chunks from the index."""
    if no_color:
        os.environ["NO_COLOR"] = "1"

    from tinillm.rag.bm25 import BM25Index
    from tinillm.rag.config import load_config
    from tinillm.rag.manifest import ManifestDB
    from tinillm.rag.render import make_console
    from tinillm.rag.vectorstore import VectorStore

    config = load_config()
    console = make_console()
    source_path = str(Path(source).resolve())

    if not confirm:
        click.confirm(
            f"Remove all indexed chunks from {source_path}?",
            abort=True,
        )

    manifest = ManifestDB(config.manifest_path)
    vs = VectorStore(config.qdrant_path, config)
    bm25 = BM25Index(config.bm25_path)

    # Find all files under this source
    rows = manifest._conn.execute(
        "SELECT id, sha256 FROM files WHERE path LIKE ? AND embed_status='embedded'",
        (source_path + "%",),
    ).fetchall()

    count = 0
    for file_id, sha256 in rows:
        vs.delete_by_filter(sha256)
        bm25.remove_documents(file_id)
        manifest.mark_deleted(file_id)
        count += 1

    bm25.save()
    manifest.close()

    console.print(f"[bold #87d700]Removed[/] {count} file(s) from index.")


# ── reset ─────────────────────────────────────────────────────────────────────

@rag.command("reset")
@click.option("--confirm", is_flag=True, default=False,
              help="Skip confirmation prompt.")
@click.option("--no-color", is_flag=True, default=False,
              help="Suppress colors.")
def reset(confirm: bool, no_color: bool) -> None:
    """Wipe the entire index and manifest. This is destructive."""
    if no_color:
        os.environ["NO_COLOR"] = "1"

    from tinillm.rag.config import load_config
    from tinillm.rag.render import make_console

    config = load_config()
    console = make_console()

    if not confirm:
        click.confirm(
            "This will delete ALL indexed data. Are you sure?",
            abort=True,
        )

    import shutil
    removed = []

    if config.manifest_path.exists():
        config.manifest_path.unlink()
        removed.append("manifest.db")

    if config.qdrant_path.exists():
        shutil.rmtree(config.qdrant_path)
        removed.append("qdrant/")

    if config.bm25_path.exists():
        config.bm25_path.unlink()
        removed.append("bm25.pkl")

    if removed:
        console.print(f"[bold #87d700]Reset complete.[/] Removed: {', '.join(removed)}")
    else:
        console.print("[dim]Nothing to remove.[/dim]")
