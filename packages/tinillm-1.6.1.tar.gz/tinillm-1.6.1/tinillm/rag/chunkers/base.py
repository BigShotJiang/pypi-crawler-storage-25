"""Chunk dataclass and chunker factory."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Optional, Protocol

from tinillm.rag.parsers.base import Document
from tinillm.rag.config import RagConfig


@dataclass
class Chunk:
    id: str
    text: str
    file_id: int
    chunk_index: int
    file_path: str
    file_type: str
    page_number: Optional[int] = None
    section: Optional[str] = None
    language: Optional[str] = None
    sha256: str = ""
    source_url: Optional[str] = None

    @staticmethod
    def make_id(file_path: str, chunk_index: int) -> str:
        # Deterministic UUID from path + index so re-indexing is idempotent
        return str(uuid.uuid5(uuid.NAMESPACE_URL, f"{file_path}:{chunk_index}"))


class Chunker(Protocol):
    def chunk(self, doc: Document, file_id: int, sha256: str) -> list[Chunk]:
        ...


def get_chunker(file_type: str, config: RagConfig) -> Chunker:
    from tinillm.rag.chunkers.layout import LayoutChunker
    from tinillm.rag.chunkers.header import HeaderChunker
    from tinillm.rag.chunkers.semantic import SemanticChunker
    from tinillm.rag.chunkers.ast_chunker import ASTChunker
    from tinillm.rag.discovery import CODE_TYPES

    if file_type == "pdf":
        return LayoutChunker(config)
    if file_type in ("md", "rst", "org"):
        return HeaderChunker(config)
    if file_type in CODE_TYPES:
        return ASTChunker(config)
    return SemanticChunker(config)
