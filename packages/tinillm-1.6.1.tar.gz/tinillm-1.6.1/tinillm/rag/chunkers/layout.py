"""Layout-aware chunker for PDFs — respects page boundaries."""

from __future__ import annotations

import re
from typing import Optional

from tinillm.rag.chunkers.base import Chunk
from tinillm.rag.config import RagConfig
from tinillm.rag.parsers.base import Document


def _approx_tokens(text: str) -> int:
    return len(text) // 4


def _split_into_chunks(
    text: str,
    chunk_size: int,
    overlap: int,
) -> list[str]:
    """Split text into overlapping chunks by approximate token count."""
    words = text.split()
    if not words:
        return []

    chunks: list[str] = []
    # words per chunk (approx 4 chars per token)
    words_per_chunk = max(1, chunk_size * 4 // 5)
    step = max(1, words_per_chunk - overlap * 4 // 5)

    i = 0
    while i < len(words):
        chunk_words = words[i: i + words_per_chunk]
        chunks.append(" ".join(chunk_words))
        i += step
        if i + words_per_chunk // 2 >= len(words):
            # Include remainder as last chunk
            remaining = words[i:]
            if remaining:
                chunks.append(" ".join(remaining))
            break

    return chunks


class LayoutChunker:
    """
    For PDFs: each page from the parser is already a unit.
    Split pages that exceed chunk_size; respect overlap across pages.
    """

    def __init__(self, config: RagConfig) -> None:
        self._chunk_size = config.pdf_chunk_size
        self._overlap = config.pdf_overlap

    def chunk(self, doc: Document, file_id: int, sha256: str) -> list[Chunk]:
        text = doc.content.strip()
        if not text:
            return []

        page_num = doc.metadata.get("page_number")
        file_path = doc.metadata.get("file_path", "")
        file_type = doc.metadata.get("file_type", "pdf")

        sub_chunks = _split_into_chunks(text, self._chunk_size, self._overlap)
        result: list[Chunk] = []

        # chunk_index will be set by the caller relative to all chunks for this file
        for i, chunk_text in enumerate(sub_chunks):
            if not chunk_text.strip():
                continue
            result.append(Chunk(
                id="",  # set by caller
                text=chunk_text,
                file_id=file_id,
                chunk_index=i,
                file_path=file_path,
                file_type=file_type,
                page_number=page_num,
                sha256=sha256,
            ))

        return result
