"""Sentence-boundary chunker for plain prose."""

from __future__ import annotations

import re

from tinillm.rag.chunkers.base import Chunk
from tinillm.rag.config import RagConfig
from tinillm.rag.parsers.base import Document

_SENTENCE_END = re.compile(r"(?<=[.!?])\s+")


def _split_sentences(text: str) -> list[str]:
    parts = _SENTENCE_END.split(text)
    return [p.strip() for p in parts if p.strip()]


class SemanticChunker:
    def __init__(self, config: RagConfig) -> None:
        self._chunk_size = config.prose_chunk_size
        self._overlap = config.prose_overlap

    def chunk(self, doc: Document, file_id: int, sha256: str) -> list[Chunk]:
        text = doc.content.strip()
        if not text:
            return []

        file_path = doc.metadata.get("file_path", "")
        file_type = doc.metadata.get("file_type", "txt")
        sentences = _split_sentences(text)

        # Approximate tokens per sentence
        words_per_chunk = max(1, self._chunk_size * 4 // 5)
        overlap_words = max(0, self._overlap * 4 // 5)

        chunks: list[Chunk] = []
        current_words: list[str] = []
        chunk_idx = 0

        for sentence in sentences:
            s_words = sentence.split()
            current_words.extend(s_words)

            if len(current_words) >= words_per_chunk:
                chunk_text = " ".join(current_words)
                chunks.append(Chunk(
                    id="",
                    text=chunk_text,
                    file_id=file_id,
                    chunk_index=chunk_idx,
                    file_path=file_path,
                    file_type=file_type,
                    sha256=sha256,
                ))
                chunk_idx += 1
                # Keep overlap
                current_words = current_words[-overlap_words:] if overlap_words else []

        # Last partial chunk
        if current_words:
            chunk_text = " ".join(current_words)
            if chunk_text.strip():
                chunks.append(Chunk(
                    id="",
                    text=chunk_text,
                    file_id=file_id,
                    chunk_index=chunk_idx,
                    file_path=file_path,
                    file_type=file_type,
                    sha256=sha256,
                ))

        return chunks
