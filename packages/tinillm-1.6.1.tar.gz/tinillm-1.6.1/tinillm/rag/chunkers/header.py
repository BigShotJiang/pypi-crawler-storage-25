"""Header-aware chunker for Markdown, RST, and Org files."""

from __future__ import annotations

import re

from tinillm.rag.chunkers.base import Chunk
from tinillm.rag.chunkers.layout import _split_into_chunks
from tinillm.rag.config import RagConfig
from tinillm.rag.parsers.base import Document

_MD_HEADER = re.compile(r"^(#{1,6})\s+(.+)$", re.MULTILINE)
_RST_UNDERLINE = re.compile(r"^[=\-~`#^*+<>]{3,}\s*$", re.MULTILINE)


def _split_by_headers(text: str) -> list[tuple[str, str]]:
    """
    Returns list of (section_title, section_content).
    If no headers found, returns [(None, full_text)].
    """
    matches = list(_MD_HEADER.finditer(text))
    if not matches:
        return [("", text)]

    sections: list[tuple[str, str]] = []
    for i, match in enumerate(matches):
        title = match.group(2).strip()
        start = match.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        content = text[start:end].strip()
        if content:
            sections.append((title, content))
        elif not content and i == 0:
            # Text before first header
            before = text[: match.start()].strip()
            if before:
                sections.insert(0, ("", before))

    return sections if sections else [("", text)]


class HeaderChunker:
    def __init__(self, config: RagConfig) -> None:
        self._chunk_size = config.prose_chunk_size
        self._overlap = config.prose_overlap

    def chunk(self, doc: Document, file_id: int, sha256: str) -> list[Chunk]:
        text = doc.content.strip()
        if not text:
            return []

        file_path = doc.metadata.get("file_path", "")
        file_type = doc.metadata.get("file_type", "md")

        sections = _split_by_headers(text)
        result: list[Chunk] = []

        for section_title, section_text in sections:
            sub_chunks = _split_into_chunks(section_text, self._chunk_size, self._overlap)
            for chunk_text in sub_chunks:
                if not chunk_text.strip():
                    continue
                result.append(Chunk(
                    id="",
                    text=chunk_text,
                    file_id=file_id,
                    chunk_index=len(result),
                    file_path=file_path,
                    file_type=file_type,
                    section=section_title or None,
                    sha256=sha256,
                ))

        return result
