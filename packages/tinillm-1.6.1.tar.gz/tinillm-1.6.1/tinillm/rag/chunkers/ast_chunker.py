"""AST-aware chunker for code — each parsed Definition = one chunk."""

from __future__ import annotations

from tinillm.rag.chunkers.base import Chunk
from tinillm.rag.chunkers.layout import _split_into_chunks
from tinillm.rag.config import RagConfig
from tinillm.rag.parsers.base import Document


class ASTChunker:
    """
    The code parser already extracted per-definition Documents.
    This chunker just enforces size limits — splitting oversized
    definitions by line count if needed.
    """

    def __init__(self, config: RagConfig) -> None:
        self._chunk_size = config.code_chunk_size
        self._overlap = config.code_overlap

    def chunk(self, doc: Document, file_id: int, sha256: str) -> list[Chunk]:
        text = doc.content.strip()
        if not text:
            return []

        file_path = doc.metadata.get("file_path", "")
        file_type = doc.metadata.get("file_type", "py")
        language = doc.metadata.get("language")
        start_line = doc.metadata.get("start_line")
        end_line = doc.metadata.get("end_line")

        # If the definition fits in one chunk, return it directly
        approx_tokens = len(text) // 4
        if approx_tokens <= self._chunk_size:
            return [Chunk(
                id="",
                text=text,
                file_id=file_id,
                chunk_index=0,
                file_path=file_path,
                file_type=file_type,
                language=language,
                sha256=sha256,
            )]

        # Too large — split by lines with overlap
        sub_chunks = _split_into_chunks(text, self._chunk_size, self._overlap)
        result: list[Chunk] = []
        for i, chunk_text in enumerate(sub_chunks):
            if not chunk_text.strip():
                continue
            result.append(Chunk(
                id="",
                text=chunk_text,
                file_id=file_id,
                chunk_index=i,
                file_path=file_path,
                file_type=file_type,
                language=language,
                sha256=sha256,
            ))

        return result
