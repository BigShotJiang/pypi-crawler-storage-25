"""Chunker package — content-type aware text splitting."""

from __future__ import annotations

from tinillm.rag.chunkers.base import Chunk, get_chunker

__all__ = ["Chunk", "get_chunker"]
