"""Ollama embedding wrapper — batched with backpressure via ThreadPoolExecutor."""

from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional

from tinillm.rag.config import RagConfig


class Embedder:
    def __init__(self, config: RagConfig, model: Optional[str] = None) -> None:
        self._model = model or config.embed_model
        self._batch_size = config.embed_batch_size
        self._concurrency = config.embed_concurrency
        if not self._model:
            raise ValueError("No embed model specified. Run tinillm rag ingest to pick one.")

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Embed a list of texts, returning a list of float vectors."""
        if not texts:
            return []

        batches = [
            texts[i: i + self._batch_size]
            for i in range(0, len(texts), self._batch_size)
        ]

        results: dict[int, list[list[float]]] = {}

        with ThreadPoolExecutor(max_workers=self._concurrency) as pool:
            futures = {
                pool.submit(self._embed_single_batch, batch): idx
                for idx, batch in enumerate(batches)
            }
            for future in as_completed(futures):
                idx = futures[future]
                results[idx] = future.result()

        ordered: list[list[float]] = []
        for i in range(len(batches)):
            ordered.extend(results[i])
        return ordered

    def embed_single(self, text: str) -> list[float]:
        return self._embed_one(text)

    def _embed_single_batch(self, texts: list[str]) -> list[list[float]]:
        return [self._embed_one(t) for t in texts]

    def _embed_one(self, text: str, retries: int = 3) -> list[float]:
        import ollama
        last_exc: Optional[Exception] = None
        delay = 1.0
        for attempt in range(retries):
            try:
                resp = ollama.embeddings(model=self._model, prompt=text)
                return resp["embedding"]
            except Exception as exc:
                last_exc = exc
                if attempt < retries - 1:
                    time.sleep(delay)
                    delay *= 2
        raise RuntimeError(
            f"Embedding failed after {retries} attempts: {last_exc}"
        ) from last_exc
