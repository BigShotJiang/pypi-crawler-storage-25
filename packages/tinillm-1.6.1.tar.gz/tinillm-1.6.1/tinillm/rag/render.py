"""Rich rendering for tinillm rag — consistent with TINILLM_THEME."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Optional

from rich.console import Console
from rich.table import Table
from rich import box

from tinillm.render.styles import TINILLM_THEME


def make_console() -> Console:
    no_color = "NO_COLOR" in os.environ
    width = None if sys.stdout.isatty() else int(os.environ.get("COLUMNS", "220"))
    return Console(theme=TINILLM_THEME, no_color=no_color, highlight=False, width=width)


# ── Ingest ────────────────────────────────────────────────────────────────────

def render_ingest_start(console: Console, sources: list[Path], dry_run: bool) -> None:
    mode = "[dim](dry run)[/dim] " if dry_run else ""
    src_str = ", ".join(str(s) for s in sources)
    console.print(f"\n[bold white]tinillm rag ingest[/] {mode}· {src_str}\n")


def render_ingest_progress(console: Console, stage: str, current: int, total: int, msg: str) -> None:
    stage_labels = {
        "discover": "[label]Discover[/]",
        "parse":    "[label]Parse   [/]",
        "chunk":    "[label]Chunk   [/]",
        "embed":    "[label]Embed   [/]",
        "dry_run":  "[label]Dry Run [/]",
        "interrupt":"[bold yellow]Interrupt[/]",
    }
    label = stage_labels.get(stage, f"[label]{stage:8s}[/]")
    if total > 0:
        pct = int(current / total * 100)
        bar_filled = pct // 5
        bar = "█" * bar_filled + "░" * (20 - bar_filled)
        console.print(f"  {label}  [{bar}] {pct:3d}%  {msg}")
    else:
        console.print(f"  {label}  {msg}")


def render_ingest_summary(console: Console, stats, elapsed: float) -> None:
    console.print()
    table = Table(box=box.SIMPLE_HEAD, show_header=False, padding=(0, 1))
    table.add_column("Label", style="dim", width=16)
    table.add_column("Value", style="bold white")

    table.add_row("Discovered",  str(stats.discovered))
    table.add_row("Skipped",     f"[dim]{stats.skipped}[/dim]")
    table.add_row("Parsed",      str(stats.parsed))
    table.add_row("Embedded",    f"[bold #87d700]{stats.embedded}[/]")
    table.add_row("Failed",      f"[bold #ff5f5f]{stats.failed}[/]" if stats.failed else "0")
    table.add_row("Deleted",     str(stats.deleted))
    table.add_row("Time",        f"{elapsed:.1f}s")

    console.print(table)
    console.print()


# ── Status ────────────────────────────────────────────────────────────────────

def render_status(console: Console, db_stats: dict, vector_info: dict, bm25_count: int) -> None:
    console.print("\n[bold white]tinillm rag status[/]\n")

    table = Table(box=box.SIMPLE_HEAD, show_header=False, padding=(0, 1))
    table.add_column("Label", style="dim", width=20)
    table.add_column("Value", style="bold white")

    table.add_row("Indexed files",  str(db_stats.get("indexed_files", 0)))
    table.add_row("Total files",    str(db_stats.get("total_files", 0)))
    table.add_row("Failed files",   str(db_stats.get("failed_files", 0)))
    table.add_row("Chunks (DB)",    str(db_stats.get("total_chunks", 0)))
    table.add_row("Vectors (Qdrant)", str(vector_info.get("vectors_count", 0)))
    table.add_row("BM25 docs",      str(bm25_count))

    console.print(table)
    console.print()


def render_status_by_type(console: Console, rows: list[dict]) -> None:
    if not rows:
        return
    table = Table(
        box=box.SIMPLE_HEAD,
        show_header=True,
        header_style="bold white",
        padding=(0, 1),
    )
    table.add_column("Type",   min_width=10)
    table.add_column("Files",  min_width=8, justify="right")
    table.add_column("Chunks", min_width=10, justify="right")

    for r in rows:
        table.add_row(r["file_type"], str(r["file_count"]), str(r["chunk_count"]))

    console.print(table)
    console.print()


def render_status_json(db_stats: dict, vector_info: dict, bm25_count: int) -> str:
    return json.dumps({
        "indexed_files":    db_stats.get("indexed_files", 0),
        "total_files":      db_stats.get("total_files", 0),
        "failed_files":     db_stats.get("failed_files", 0),
        "total_chunks":     db_stats.get("total_chunks", 0),
        "vectors_count":    vector_info.get("vectors_count", 0),
        "bm25_doc_count":   bm25_count,
    }, indent=2)


# ── Query ─────────────────────────────────────────────────────────────────────

def render_citations(console: Console, citations) -> None:
    if not citations:
        return
    console.print("\n[dim]Sources:[/dim]")
    for cit in citations:
        fname = Path(cit.file_path).name if cit.file_path else "unknown"
        page_str = f", p.{cit.page_number}" if cit.page_number else ""
        section_str = f" — {cit.section}" if cit.section else ""
        console.print(f"  [dim]{cit.key}[/dim] {fname}{page_str}{section_str}")
    console.print()


def render_query_json(result) -> str:
    return json.dumps({
        "answer": result.answer,
        "citations": [
            {
                "key":         c.key,
                "file_path":   c.file_path,
                "page_number": c.page_number,
                "section":     c.section,
            }
            for c in result.citations
        ],
        "chunks_retrieved": result.chunks_retrieved,
        "chunks_reranked":  result.chunks_reranked,
    }, indent=2)


# ── Config ────────────────────────────────────────────────────────────────────

def render_config(console: Console, config) -> None:
    console.print("\n[bold white]tinillm rag config[/]\n")

    table = Table(box=box.SIMPLE_HEAD, show_header=False, padding=(0, 1))
    table.add_column("Key",   style="dim", min_width=22)
    table.add_column("Value", style="bold white")

    table.add_row("data_dir",        str(config.data_dir))
    table.add_row("llm_model",       config.llm_model or "[dim]not set (pick on query)[/dim]")
    table.add_row("embed_model",     config.embed_model or "[dim]not set (pick on ingest)[/dim]")
    table.add_row("embed_dim",       str(config.embed_dim))
    table.add_row("pdf_chunk_size",  str(config.pdf_chunk_size))
    table.add_row("prose_chunk_size",str(config.prose_chunk_size))
    table.add_row("code_chunk_size", str(config.code_chunk_size))
    table.add_row("rerank_top_k",    str(config.rerank_top_k))
    table.add_row("dense_threshold", str(config.dense_threshold))
    table.add_row("query_rewrite",   str(config.query_rewrite))
    table.add_row("searxng_url",     config.searxng_url or "[dim]disabled[/dim]")

    console.print(table)
    console.print()


def render_config_check(console: Console, config) -> None:
    render_config(console, config)
    console.print("[bold white]Dependency check:[/]\n")

    checks = [
        ("qdrant-client",  "qdrant_client"),
        ("FlagEmbedding",  "FlagEmbedding"),
        ("rank-bm25",      "rank_bm25"),
        ("pymupdf",        "fitz"),
        ("pymupdf4llm",    "pymupdf4llm"),
        ("marker-pdf",     "marker"),
        ("pytesseract",    "pytesseract"),
        ("py-tree-sitter", "tree_sitter"),
        ("python-docx",    "docx"),
        ("python-pptx",    "pptx"),
        ("openpyxl",       "openpyxl"),
        ("beautifulsoup4", "bs4"),
        ("httpx",          "httpx"),
    ]

    for name, import_name in checks:
        try:
            __import__(import_name)
            console.print(f"  [bold #87d700]OK[/]  {name}")
        except ImportError:
            console.print(f"  [bold #ff5f5f]MISS[/] {name}")

    # Ollama check
    try:
        import ollama
        ollama.list()
        console.print("  [bold #87d700]OK[/]  ollama (running)")
    except Exception:
        console.print("  [bold #ff5f5f]MISS[/] ollama (not running — start with: ollama serve)")

    console.print()
