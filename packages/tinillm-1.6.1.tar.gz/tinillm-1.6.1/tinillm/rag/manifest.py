"""SQLite manifest DB — tracks every file's parse and embed state."""

from __future__ import annotations

import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


_SCHEMA = """
CREATE TABLE IF NOT EXISTS files (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    path            TEXT    NOT NULL UNIQUE,
    sha256          TEXT    NOT NULL,
    size_bytes      INTEGER NOT NULL DEFAULT 0,
    mtime           REAL    NOT NULL DEFAULT 0,
    file_type       TEXT    NOT NULL DEFAULT '',
    parse_status    TEXT    NOT NULL DEFAULT 'pending',
    parse_error     TEXT,
    chunk_count     INTEGER NOT NULL DEFAULT 0,
    embed_status    TEXT    NOT NULL DEFAULT 'pending',
    embed_error     TEXT,
    indexed_at      REAL,
    created_at      REAL    NOT NULL,
    updated_at      REAL    NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_files_sha256       ON files(sha256);
CREATE INDEX IF NOT EXISTS idx_files_parse_status ON files(parse_status);
CREATE INDEX IF NOT EXISTS idx_files_embed_status ON files(embed_status);
CREATE INDEX IF NOT EXISTS idx_files_file_type    ON files(file_type);

CREATE TABLE IF NOT EXISTS ingestion_runs (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at       REAL    NOT NULL,
    finished_at      REAL,
    status           TEXT    NOT NULL DEFAULT 'running',
    source_paths     TEXT    NOT NULL DEFAULT '[]',
    files_discovered INTEGER DEFAULT 0,
    files_parsed     INTEGER DEFAULT 0,
    files_embedded   INTEGER DEFAULT 0,
    files_failed     INTEGER DEFAULT 0,
    files_skipped    INTEGER DEFAULT 0
);
"""


@dataclass
class FileRecord:
    id: int
    path: str
    sha256: str
    size_bytes: int
    mtime: float
    file_type: str
    parse_status: str
    parse_error: Optional[str]
    chunk_count: int
    embed_status: str
    embed_error: Optional[str]
    indexed_at: Optional[float]
    disposition: str = "unknown"  # new | changed | resume | unchanged


class ManifestDB:
    def __init__(self, db_path: Path) -> None:
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(db_path), check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.executescript(_SCHEMA)
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()

    def lookup(self, path: Path) -> Optional[FileRecord]:
        row = self._conn.execute(
            "SELECT id, path, sha256, size_bytes, mtime, file_type, "
            "parse_status, parse_error, chunk_count, embed_status, embed_error, indexed_at "
            "FROM files WHERE path = ?",
            (str(path),),
        ).fetchone()
        if row is None:
            return None
        return FileRecord(*row)

    def upsert(
        self,
        path: Path,
        sha256: str,
        size_bytes: int,
        mtime: float,
        file_type: str,
        disposition: str,
    ) -> FileRecord:
        now = time.time()
        existing = self.lookup(path)
        if existing is None:
            cur = self._conn.execute(
                "INSERT INTO files (path, sha256, size_bytes, mtime, file_type, "
                "parse_status, embed_status, created_at, updated_at) "
                "VALUES (?, ?, ?, ?, ?, 'pending', 'pending', ?, ?)",
                (str(path), sha256, size_bytes, mtime, file_type, now, now),
            )
            self._conn.commit()
            row_id = cur.lastrowid
        else:
            if disposition == "changed":
                # Reset statuses for re-processing
                self._conn.execute(
                    "UPDATE files SET sha256=?, size_bytes=?, mtime=?, file_type=?, "
                    "parse_status='pending', parse_error=NULL, chunk_count=0, "
                    "embed_status='pending', embed_error=NULL, indexed_at=NULL, updated_at=? "
                    "WHERE path=?",
                    (sha256, size_bytes, mtime, file_type, now, str(path)),
                )
                self._conn.commit()
            row_id = existing.id

        rec = self.lookup(path)
        assert rec is not None
        rec.disposition = disposition
        return rec

    def update_parse_status(
        self,
        file_id: int,
        status: str,
        chunk_count: int = 0,
        error: Optional[str] = None,
    ) -> None:
        self._conn.execute(
            "UPDATE files SET parse_status=?, parse_error=?, chunk_count=?, updated_at=? "
            "WHERE id=?",
            (status, error, chunk_count, time.time(), file_id),
        )
        self._conn.commit()

    def update_embed_status(
        self,
        file_id: int,
        status: str,
        error: Optional[str] = None,
    ) -> None:
        indexed_at = time.time() if status == "embedded" else None
        self._conn.execute(
            "UPDATE files SET embed_status=?, embed_error=?, indexed_at=?, updated_at=? "
            "WHERE id=?",
            (status, error, indexed_at, time.time(), file_id),
        )
        self._conn.commit()

    def find_deleted(self, source_roots: list[Path]) -> list[FileRecord]:
        """Return manifest records whose paths no longer exist on disk."""
        rows = self._conn.execute(
            "SELECT id, path, sha256, size_bytes, mtime, file_type, "
            "parse_status, parse_error, chunk_count, embed_status, embed_error, indexed_at "
            "FROM files WHERE embed_status = 'embedded'"
        ).fetchall()
        deleted = []
        for row in rows:
            p = Path(row[1])
            # Only consider files under one of the source roots
            under_source = any(
                str(p).startswith(str(root)) for root in source_roots
            )
            if under_source and not p.exists():
                deleted.append(FileRecord(*row))
        return deleted

    def mark_deleted(self, file_id: int) -> None:
        self._conn.execute(
            "UPDATE files SET embed_status='deleted', parse_status='deleted', "
            "updated_at=? WHERE id=?",
            (time.time(), file_id),
        )
        self._conn.commit()

    def start_run(self, source_paths: list[Path]) -> int:
        import json
        cur = self._conn.execute(
            "INSERT INTO ingestion_runs (started_at, source_paths) VALUES (?, ?)",
            (time.time(), json.dumps([str(p) for p in source_paths])),
        )
        self._conn.commit()
        return cur.lastrowid  # type: ignore[return-value]

    def finish_run(self, run_id: int, stats: "IngestionStats") -> None:  # noqa: F821
        self._conn.execute(
            "UPDATE ingestion_runs SET finished_at=?, status='done', "
            "files_discovered=?, files_parsed=?, files_embedded=?, "
            "files_failed=?, files_skipped=? WHERE id=?",
            (
                time.time(),
                stats.discovered,
                stats.parsed,
                stats.embedded,
                stats.failed,
                stats.skipped,
                run_id,
            ),
        )
        self._conn.commit()

    def get_stats(self) -> dict:
        row = self._conn.execute(
            "SELECT COUNT(*), "
            "SUM(CASE WHEN embed_status='embedded' THEN 1 ELSE 0 END), "
            "SUM(chunk_count), "
            "SUM(CASE WHEN parse_status='failed' OR embed_status='failed' THEN 1 ELSE 0 END) "
            "FROM files WHERE parse_status != 'deleted'"
        ).fetchone()
        total, indexed, chunks, failed = row
        return {
            "total_files": total or 0,
            "indexed_files": indexed or 0,
            "total_chunks": chunks or 0,
            "failed_files": failed or 0,
        }

    def get_stats_by_type(self) -> list[dict]:
        rows = self._conn.execute(
            "SELECT file_type, COUNT(*), SUM(chunk_count) "
            "FROM files WHERE embed_status='embedded' "
            "GROUP BY file_type ORDER BY COUNT(*) DESC"
        ).fetchall()
        return [
            {"file_type": r[0], "file_count": r[1], "chunk_count": r[2] or 0}
            for r in rows
        ]
