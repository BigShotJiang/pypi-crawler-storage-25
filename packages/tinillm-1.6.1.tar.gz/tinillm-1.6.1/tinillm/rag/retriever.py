"""Hybrid retrieval — dense (Qdrant) + sparse (BM25) with Reciprocal Rank Fusion."""

from __future__ import annotations

from typing import Any

from tinillm.rag.vectorstore import ChunkPoint


def reciprocal_rank_fusion(
    dense: list[ChunkPoint],
    sparse: list[tuple[str, float]],
    k: int = 60,
    vector_store=None,
) -> list[ChunkPoint]:
    """
    Merge dense and sparse result lists using RRF.
    sparse: list of (chunk_id_str, bm25_score)
    vector_store: used to fetch payloads for BM25-only hits (not in dense results).
    Returns merged list of ChunkPoints sorted by fused score descending.
    """
    scores: dict[str, float] = {}
    id_to_point: dict[str, ChunkPoint] = {}

    for rank, point in enumerate(dense):
        scores[point.id] = scores.get(point.id, 0.0) + 1.0 / (k + rank + 1)
        id_to_point[point.id] = point

    bm25_only_ids: list[str] = []
    for rank, (chunk_id, _) in enumerate(sparse):
        scores[chunk_id] = scores.get(chunk_id, 0.0) + 1.0 / (k + rank + 1)
        if chunk_id not in id_to_point:
            bm25_only_ids.append(chunk_id)

    # Fetch payloads for BM25-only hits so they aren't silently dropped
    if bm25_only_ids and vector_store is not None:
        try:
            fetched = vector_store.fetch_by_ids(bm25_only_ids)
            for point in fetched:
                id_to_point[point.id] = point
        except Exception:
            pass  # degrade gracefully — BM25-only hits lost but won't crash

    results: list[tuple[str, float]] = sorted(
        scores.items(), key=lambda x: x[1], reverse=True
    )

    return [id_to_point[cid] for cid, _ in results if cid in id_to_point]


def hybrid_search(
    query_vector: list[float],
    query_text: str,
    config,
    vector_store,
    bm25_index,
) -> list[ChunkPoint]:
    """Run dense + sparse search and merge via RRF."""
    dense = vector_store.search(
        query_vector,
        limit=config.dense_top_k,
        score_threshold=config.dense_threshold,
    )
    sparse = bm25_index.search(query_text, top_k=config.sparse_top_k)

    merged = reciprocal_rank_fusion(dense, sparse, vector_store=vector_store)
    return merged[:config.dense_top_k]
