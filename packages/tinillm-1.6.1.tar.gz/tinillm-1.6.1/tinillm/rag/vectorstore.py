"""Qdrant local in-process vector store wrapper."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from tinillm.rag.config import RagConfig

COLLECTION_NAME = "tinirag_chunks"


@dataclass
class ChunkPoint:
    id: str
    score: float
    payload: dict[str, Any]


class VectorStore:
    def __init__(self, qdrant_path: Path, config: RagConfig) -> None:
        from qdrant_client import QdrantClient
        from qdrant_client.models import (
            Distance,
            HnswConfigDiff,
            ScalarQuantizationConfig,
            ScalarType,
            VectorParams,
        )

        self._dim = config.embed_dim
        self._client = QdrantClient(path=str(qdrant_path))

        existing = [c.name for c in self._client.get_collections().collections]
        if COLLECTION_NAME not in existing:
            self._client.create_collection(
                collection_name=COLLECTION_NAME,
                vectors_config=VectorParams(
                    size=self._dim,
                    distance=Distance.COSINE,
                    hnsw_config=HnswConfigDiff(
                        m=16,
                        ef_construct=200,
                        full_scan_threshold=10_000,
                    ),
                ),
                quantization_config=ScalarQuantizationConfig(
                    type=ScalarType.INT8,
                    quantile=0.99,
                    always_ram=True,
                ),
            )
            # Create payload indexes for fast filtering
            from qdrant_client.models import PayloadSchemaType
            import warnings
            for field_name in ("file_path", "file_type", "sha256", "language"):
                try:
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore")
                        self._client.create_payload_index(
                            collection_name=COLLECTION_NAME,
                            field_name=field_name,
                            field_schema=PayloadSchemaType.KEYWORD,
                        )
                except Exception:
                    pass

    def upsert(self, points: list[dict]) -> None:
        """Upsert a list of point dicts with 'id', 'vector', 'payload'."""
        from qdrant_client.models import PointStruct

        qdrant_points = [
            PointStruct(
                id=p["id"],
                vector=p["vector"],
                payload=p["payload"],
            )
            for p in points
        ]

        batch_size = 500
        for i in range(0, len(qdrant_points), batch_size):
            self._client.upsert(
                collection_name=COLLECTION_NAME,
                points=qdrant_points[i: i + batch_size],
            )

    def search(
        self,
        vector: list[float],
        limit: int = 50,
        score_threshold: float = 0.0,
        filters: Optional[dict] = None,
    ) -> list[ChunkPoint]:
        from qdrant_client.models import Filter, FieldCondition, MatchValue

        qfilter = None
        if filters:
            conditions = [
                FieldCondition(key=k, match=MatchValue(value=v))
                for k, v in filters.items()
            ]
            qfilter = Filter(must=conditions)

        # qdrant-client >= 1.10 removed client.search(); use query_points instead
        response = self._client.query_points(
            collection_name=COLLECTION_NAME,
            query=vector,
            limit=limit,
            score_threshold=score_threshold if score_threshold > 0.0 else None,
            query_filter=qfilter,
            with_payload=True,
        )

        return [
            ChunkPoint(id=str(r.id), score=r.score, payload=r.payload or {})
            for r in response.points
        ]

    def close(self) -> None:
        """Release the Qdrant file lock."""
        try:
            self._client.close()
        except Exception:
            pass

    def delete_by_filter(self, sha256: str) -> None:
        from qdrant_client.models import Filter, FieldCondition, MatchValue
        self._client.delete(
            collection_name=COLLECTION_NAME,
            points_selector=Filter(
                must=[FieldCondition(key="sha256", match=MatchValue(value=sha256))]
            ),
        )

    def get_collection_info(self) -> dict:
        try:
            info = self._client.get_collection(COLLECTION_NAME)
            return {
                "vectors_count": info.vectors_count or 0,
                "indexed_vectors_count": info.indexed_vectors_count or 0,
                "status": str(info.status),
            }
        except Exception:
            return {"vectors_count": 0, "indexed_vectors_count": 0, "status": "unknown"}

    def fetch_by_ids(self, ids: list[str]) -> list[ChunkPoint]:
        results = self._client.retrieve(
            collection_name=COLLECTION_NAME,
            ids=ids,
            with_payload=True,
        )
        return [
            ChunkPoint(id=str(r.id), score=0.0, payload=r.payload or {})
            for r in results
        ]
