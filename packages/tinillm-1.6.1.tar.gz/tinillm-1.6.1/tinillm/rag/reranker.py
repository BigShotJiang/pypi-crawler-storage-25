"""Cross-encoder reranker using BAAI/bge-reranker-v2-m3 via FlagEmbedding."""

from __future__ import annotations

from typing import Optional

from tinillm.rag.vectorstore import ChunkPoint

_reranker_instance = None


def _get_reranker():
    global _reranker_instance
    if _reranker_instance is None:
        try:
            from FlagEmbedding import FlagReranker
            _reranker_instance = FlagReranker(
                "BAAI/bge-reranker-v2-m3",
                use_fp16=True,
            )
        except ImportError:
            raise ImportError(
                "FlagEmbedding not installed. Run: pip install tinillm[rag]"
            )
    return _reranker_instance


def rerank(
    query: str,
    candidates: list[ChunkPoint],
    top_k: int = 5,
) -> list[ChunkPoint]:
    """
    Rerank candidates using bge-reranker-v2-m3.
    Returns top_k chunks sorted by cross-encoder score.
    """
    if not candidates:
        return []

    try:
        reranker = _get_reranker()
        texts = [c.payload.get("chunk_text", "") for c in candidates]
        pairs = [[query, text] for text in texts]
        scores = reranker.compute_score(pairs, normalize=True)

        if not isinstance(scores, list):
            scores = [float(scores)]

        ranked = sorted(
            zip(candidates, scores),
            key=lambda x: x[1],
            reverse=True,
        )
        return [chunk for chunk, _ in ranked[:top_k]]

    except Exception:
        # If reranker fails, return top_k by dense score
        return candidates[:top_k]
