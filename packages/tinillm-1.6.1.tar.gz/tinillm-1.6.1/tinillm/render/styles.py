"""Rich style constants for tinillm output."""

from __future__ import annotations

from rich.style import Style
from rich.theme import Theme

# FitLevel colours (hex)
FIT_COLORS = {
    "Perfect":  "#00d7af",   # bright cyan-green
    "Good":     "#87d700",   # yellow-green
    "Marginal": "#ffd700",   # gold/amber
    "TooTight": "#ff5f5f",   # soft red
}

TINILLM_THEME = Theme(
    {
        "header":       "bold white",
        "label":        "bold cyan",
        "value":        "white",
        "dim":          "dim white",
        "fit.perfect":  f"bold {FIT_COLORS['Perfect']}",
        "fit.good":     f"bold {FIT_COLORS['Good']}",
        "fit.marginal": f"bold {FIT_COLORS['Marginal']}",
        "fit.tootight": f"bold {FIT_COLORS['TooTight']}",
        "backend.cuda":  "bold green",
        "backend.rocm":  "bold yellow",
        "backend.metal": "bold cyan",
        "backend.vulkan": "bold blue",
        "backend.directx": "bold magenta",
    }
)


def fit_style(fit_value: str) -> str:
    """Return a Rich markup style tag for the given FitLevel string."""
    mapping = {
        "Perfect":  "fit.perfect",
        "Good":     "fit.good",
        "Marginal": "fit.marginal",
        "TooTight": "fit.tootight",
    }
    return mapping.get(fit_value, "white")


def backend_style(backend: str) -> str:
    mapping = {
        "CUDA":    "backend.cuda",
        "ROCm":    "backend.rocm",
        "Metal":   "backend.metal",
        "Vulkan":  "backend.vulkan",
        "DirectX": "backend.directx",
    }
    return mapping.get(backend, "white")
