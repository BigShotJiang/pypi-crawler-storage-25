"""Bordered hardware summary card renderer."""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

from tinillm.hardware.types import SystemSpecs
from tinillm.render.styles import backend_style


def render_hardware_summary(console: Console, specs: SystemSpecs) -> None:
    """Print a bordered hardware summary panel."""
    grid = Table.grid(padding=(0, 2))
    grid.add_column(style="label", min_width=8)
    grid.add_column(style="value")

    # CPU row
    cpu = specs.cpu
    freq_str = f"  {cpu.freq_mhz / 1000:.1f} GHz" if cpu.freq_mhz else ""
    grid.add_row(
        "CPU",
        f"{cpu.model_name}   {cpu.physical_cores}c / {cpu.logical_cores}t{freq_str}",
    )

    # RAM row
    grid.add_row(
        "RAM",
        f"{specs.total_ram_gb:.1f} GB total  ·  {specs.free_ram_gb:.1f} GB free",
    )

    # GPU rows
    if specs.gpus:
        for i, gpu in enumerate(specs.gpus):
            count_str = f" × {gpu.count}" if gpu.count > 1 else ""
            unified_str = "  (unified)" if gpu.unified_memory else ""
            backend_markup = f"[{backend_style(gpu.backend)}]{gpu.backend}[/]"
            label = f"GPU {i}" if len(specs.gpus) > 1 else "GPU"
            grid.add_row(
                label,
                f"{gpu.name}{count_str}  {gpu.vram_gb:.1f} GB  {backend_markup}{unified_str}",
            )
    else:
        grid.add_row("GPU", "[dim]None detected — CPU-only mode[/dim]")

    # OS row
    grid.add_row("OS", specs.os)

    panel = Panel(
        grid,
        title="[bold white]tinillm scan — Hardware Report[/]",
        border_style="bright_blue",
        box=box.ROUNDED,
        expand=False,
        padding=(0, 1),
    )
    console.print(panel)
