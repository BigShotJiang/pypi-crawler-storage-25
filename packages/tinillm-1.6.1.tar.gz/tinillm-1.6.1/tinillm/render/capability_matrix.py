"""Color-coded LLM capability matrix renderer."""

from __future__ import annotations

from rich.console import Console
from rich.table import Table
from rich.text import Text
from rich import box

from tinillm.analyzer.types import FitLevel, ModelFit
from tinillm.render.styles import FIT_COLORS


def render_capability_matrix(
    console: Console,
    fits: list[ModelFit],
    verbose: bool = False,
) -> None:
    """Print the LLM capability table to the console."""
    table = Table(
        title="\nLLM Capability Matrix",
        title_style="bold white",
        box=box.SIMPLE_HEAD,
        show_lines=False,
        header_style="bold dim white",
        expand=False,
    )

    table.add_column("Model",      style="bold white",   min_width=7)
    table.add_column("Fit",        min_width=10)
    table.add_column("Best Quant", min_width=10)
    table.add_column("Mem Needed", min_width=10, justify="right")
    table.add_column("Tokens/sec", min_width=10, justify="right")

    for fit in fits:
        if fit.fit_level == FitLevel.TOO_TIGHT and not verbose:
            continue

        color = FIT_COLORS.get(fit.fit_level.value, "#ffffff")
        fit_text = Text(fit.fit_level.value, style=f"bold {color}")

        if fit.fit_level == FitLevel.TOO_TIGHT:
            table.add_row(
                fit.model.name,
                fit_text,
                Text("—", style="dim"),
                Text("—", style="dim"),
                Text("—", style="dim"),
            )
        else:
            quant_str = fit.best_quant.value if fit.best_quant else "—"
            mem_str = f"{fit.mem_required_gb:.1f} GB" if fit.mem_required_gb else "—"
            tps = fit.tokens_per_sec or 0.0
            tps_str = f"{tps:.0f} t/s" if tps >= 1 else f"{tps:.1f} t/s"

            table.add_row(
                fit.model.name,
                fit_text,
                Text(quant_str, style=f"{color}"),
                Text(mem_str, style="white"),
                Text(tps_str, style="white"),
            )

    console.print(table)

    # Footer legend
    _print_legend(console, fits, verbose)


def _print_legend(
    console: Console, fits: list[ModelFit], verbose: bool
) -> None:
    tight_count = sum(1 for f in fits if f.fit_level == FitLevel.TOO_TIGHT)
    if tight_count > 0 and not verbose:
        console.print(
            f"  [dim]{tight_count} model size(s) too large — use --verbose to show[/dim]"
        )

    legend_parts = []
    for level, color in FIT_COLORS.items():
        legend_parts.append(f"[{color}]{level}[/]")
    console.print("  " + "  ·  ".join(legend_parts) + "\n")
