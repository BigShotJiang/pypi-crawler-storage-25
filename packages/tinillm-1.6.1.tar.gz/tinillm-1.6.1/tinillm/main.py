"""tinillm — local LLM hardware capability tool."""

import click


@click.group(invoke_without_command=True)
@click.pass_context
def app(ctx: click.Context) -> None:
    """Know what LLMs your hardware can run — locally, instantly."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@app.command("scan")
@click.option("--json", "json_output", is_flag=True, default=False,
              help="Output machine-readable JSON.")
@click.option("--no-color", is_flag=True, default=False,
              help="Suppress colors even on a TTY.")
@click.option("--verbose", "-v", is_flag=True, default=False,
              help="Show all model sizes including TooTight.")
def scan(json_output: bool, no_color: bool, verbose: bool) -> None:
    """Scan hardware and show which LLM sizes can run on this machine."""
    from tinillm.hardware.detect import detect
    from tinillm.analyzer.fit import analyze
    from tinillm.render.report import render_report, render_json

    specs = detect()
    fits = analyze(specs)

    if json_output:
        click.echo(render_json(specs, fits))
        return

    if no_color:
        import os
        os.environ["NO_COLOR"] = "1"

    render_report(specs, fits, verbose=verbose)


@app.command("models")
@click.option("--filter", "name_filter", default=None, metavar="TEXT",
              help="Filter models by name (case-insensitive substring).")
@click.option("--size", default=None,
              type=click.Choice(["1b", "3b", "7b", "13b", "34b", "70b"], case_sensitive=False),
              help="Filter by approximate model size.")
@click.option("--fits-only", is_flag=True, default=False,
              help="Hide models that don't fit on this hardware.")
@click.option("--ollama", "check_ollama", is_flag=True, default=False,
              help="Show which models are installed in local Ollama.")
@click.option("--json", "json_output", is_flag=True, default=False,
              help="Output machine-readable JSON.")
@click.option("--no-color", is_flag=True, default=False,
              help="Suppress colors even on a TTY.")
def models(
    name_filter: str | None,
    size: str | None,
    fits_only: bool,
    check_ollama: bool,
    json_output: bool,
    no_color: bool,
) -> None:
    """Browse real LLM models and see which ones fit on this machine."""
    from tinillm.models.cmd import run_models

    if no_color:
        import os
        os.environ["NO_COLOR"] = "1"

    run_models(
        name_filter=name_filter,
        size_filter=size,
        fits_only=fits_only,
        check_ollama=check_ollama,
        json_output=json_output,
    )


@app.command("run")
@click.argument("model_tag", required=False, default=None, metavar="[MODEL_TAG]")
@click.option("--use-case", "use_case",
              type=click.Choice(["chat", "coding", "reasoning", "writing", "fast"]),
              default=None,
              help="Sort the interactive picker by use-case affinity.")
@click.option("--force", is_flag=True, default=False,
              help="Run even if the model is TooTight for this hardware.")
@click.option("--dry-run", "dry_run", is_flag=True, default=False,
              help="Print the ollama command without executing it.")
@click.option("--no-color", is_flag=True, default=False,
              help="Suppress colors even on a TTY.")
def run(
    model_tag: str | None,
    use_case: str | None,
    force: bool,
    dry_run: bool,
    no_color: bool,
) -> None:
    """Pick a compatible model and run it via Ollama.

    Optionally pass MODEL_TAG directly (e.g. llama3.1:8b) to skip the picker.
    """
    if no_color:
        import os
        os.environ["NO_COLOR"] = "1"
    from tinillm.run.cmd import run_run
    run_run(model_tag=model_tag, use_case=use_case, force=force, dry_run=dry_run)


@app.command("recommend")
@click.option("--use-case", "use_case",
              type=click.Choice(["chat", "coding", "reasoning", "writing", "fast"]),
              default=None,
              help="Your intended use case.")
@click.option("--json", "json_output", is_flag=True, default=False,
              help="Output machine-readable JSON.")
@click.option("--no-color", is_flag=True, default=False,
              help="Suppress colors even on a TTY.")
def recommend(use_case: str | None, json_output: bool, no_color: bool) -> None:
    """Get a personalised model recommendation for your hardware and use case."""
    if no_color:
        import os
        os.environ["NO_COLOR"] = "1"
    from tinillm.recommend.cmd import run_recommend
    run_recommend(use_case, json_output)


try:
    from tinillm.rag.cli import rag as _rag_group
    app.add_command(_rag_group, name="rag")
except ImportError:
    # rag extras not installed — register a stub that tells the user what to do
    @app.command("rag")
    def _rag_stub() -> None:
        """Index and query local documents with a local LLM (requires rag extras)."""
        import sys
        click.echo(
            "tinillm rag requires additional dependencies.\n\n"
            "Install them with:\n\n"
            "    pip install 'tinillm[rag]'\n\n"
            "Then run:  tinillm rag --help",
            err=True,
        )
        sys.exit(1)


if __name__ == "__main__":
    app()
