"""Rich renderer for `tinillm recommend` output."""

from __future__ import annotations

import json
import os
import sys

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

from tinillm.hardware.types import SystemSpecs
from tinillm.render.styles import FIT_COLORS, TINILLM_THEME
from tinillm.recommend.logic import ScoredModel


def _make_console() -> Console:
    no_color = "NO_COLOR" in os.environ
    width = None if sys.stdout.isatty() else int(os.environ.get("COLUMNS", "220"))
    return Console(theme=TINILLM_THEME, no_color=no_color, highlight=False, width=width)


def _hardware_label(specs: SystemSpecs, budget_gb: float, runs_on_gpu: bool) -> str:
    if runs_on_gpu and specs.gpus:
        gpu = max(specs.gpus, key=lambda g: g.vram_gb)
        return f"{budget_gb:.1f} GB VRAM ({gpu.backend})"
    return f"{budget_gb:.1f} GB RAM (CPU)"


def render_recommend_table(
    ranked: list[ScoredModel],
    specs: SystemSpecs,
    budget_gb: float,
    runs_on_gpu: bool,
    use_case: str | None,
) -> None:
    console = _make_console()
    console.print()

    use_case_str = use_case if use_case else "general"
    hw_str = _hardware_label(specs, budget_gb, runs_on_gpu)

    console.print(
        Panel(
            f"[bold white]Use case:[/] [cyan]{use_case_str}[/]  ·  "
            f"[bold white]Hardware:[/] [cyan]{hw_str}[/]",
            title="[bold white]tinillm recommend[/]",
            border_style="bright_blue",
            box=box.ROUNDED,
            expand=False,
        )
    )
    console.print()

    if not ranked:
        console.print(
            "  [dim]No models fit on this hardware. Try upgrading RAM or VRAM.[/dim]\n"
        )
        return

    table = Table(
        box=box.SIMPLE_HEAD,
        show_lines=False,
        header_style="bold dim white",
        expand=False,
        padding=(0, 1),
    )

    table.add_column("#",           min_width=3,  justify="center")
    table.add_column("Model",       min_width=22, no_wrap=True)
    table.add_column("Fit",         min_width=10)
    table.add_column("Quant",       min_width=8)
    table.add_column("Mem",         min_width=9,  justify="right")
    table.add_column("Speed",       min_width=9,  justify="right")
    table.add_column("Ollama Pull", min_width=30, no_wrap=True)

    for i, scored in enumerate(ranked):
        model = scored.real_model
        fit = scored.fit
        color = FIT_COLORS.get(fit.fit_level.value, "#ffffff")
        fit_text = Text(fit.fit_level.value, style=f"bold {color}")

        rank_label = Text("★", style="bold yellow") if i == 0 else Text(str(i + 1))
        name_style = "bold white" if i == 0 else "white"
        quant_str = fit.best_quant.value if fit.best_quant else "—"
        mem_str = f"{fit.mem_required_gb:.1f} GB" if fit.mem_required_gb else "—"
        tps = fit.tokens_per_sec or 0.0
        tps_str = f"{tps:.0f} t/s" if tps >= 1 else f"{tps:.1f} t/s"

        table.add_row(
            rank_label,
            Text(model.display_name, style=name_style),
            fit_text,
            Text(quant_str, style=color),
            Text(mem_str),
            Text(tps_str),
            Text(f"ollama pull {model.ollama_tag}", style="dim cyan"),
        )

    console.print(table)

    top = ranked[0].real_model
    console.print(
        f"  [bold white]Run it now:[/]  "
        f"[bold cyan]ollama pull {top.ollama_tag}[/]\n"
    )


def render_recommend_json(
    ranked: list[ScoredModel],
    specs: SystemSpecs,
    budget_gb: float,
    runs_on_gpu: bool,
    use_case: str | None,
) -> str:
    def _entry(scored: ScoredModel) -> dict:
        m = scored.real_model
        f = scored.fit
        return {
            "name":            m.name,
            "display_name":    m.display_name,
            "provider":        m.provider,
            "params_b":        m.params_b,
            "ollama_tag":      m.ollama_tag,
            "description":     m.description,
            "fit_level":       f.fit_level.value,
            "best_quant":      f.best_quant.value if f.best_quant else None,
            "mem_required_gb": f.mem_required_gb,
            "tokens_per_sec":  f.tokens_per_sec,
            "runs_on_gpu":     f.runs_on_gpu,
            "fit_score":       scored.fit_score,
            "affinity":        scored.affinity,
            "total_score":     scored.total_score,
        }

    payload: dict = {
        "use_case": use_case,
        "hardware": {
            "budget_gb":   budget_gb,
            "runs_on_gpu": runs_on_gpu,
        },
        "top_pick":        _entry(ranked[0]) if ranked else None,
        "recommendations": [_entry(s) for s in ranked],
    }
    return json.dumps(payload, indent=2)
