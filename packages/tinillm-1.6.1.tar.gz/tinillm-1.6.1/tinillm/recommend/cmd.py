"""Entry point for `tinillm recommend`."""

from __future__ import annotations

from tinillm.models.database import MODELS, RealModel
from tinillm.analyzer.fit import _memory_budget, best_quant_for_budget, score_fit_level
from tinillm.analyzer.types import FitLevel, ModelFit, LlmModel
from tinillm.analyzer.throughput import estimate_tokens_per_sec
from tinillm.hardware.detect import detect
from tinillm.hardware.bandwidth import gpu_bandwidth_gbps
from tinillm.recommend.logic import rank_models


def _to_llm_model(m: RealModel) -> LlmModel:
    """Convert a RealModel to the LlmModel type used by the analyzer."""
    return LlmModel(
        name=m.display_name,
        params_b=m.params_b,
        num_layers=m.num_layers,
        num_kv_heads=m.num_kv_heads,
        head_dim=m.head_dim,
        context_length=m.context_length,
    )


def _fit_model(
    model: RealModel,
    budget_gb: float,
    bandwidth_gbps: float,
    runs_on_gpu: bool,
) -> ModelFit:
    """Run fit analysis for a single RealModel against the hardware budget."""
    lm = _to_llm_model(model)
    result = best_quant_for_budget(lm, budget_gb)

    if result is None:
        return ModelFit(
            model=lm,
            fit_level=FitLevel.TOO_TIGHT,
            best_quant=None,
            mem_required_gb=None,
            tokens_per_sec=None,
            runs_on_gpu=runs_on_gpu,
        )

    best_quant, mem_required, ctx = result
    fit_level = score_fit_level(mem_required, budget_gb, runs_on_gpu, best_quant, lm, ctx)
    tps = estimate_tokens_per_sec(lm, best_quant, bandwidth_gbps, runs_on_gpu)

    return ModelFit(
        model=lm,
        fit_level=fit_level,
        best_quant=best_quant,
        mem_required_gb=round(mem_required, 1),
        tokens_per_sec=round(tps, 1),
        runs_on_gpu=runs_on_gpu,
    )


def run_recommend(use_case: str | None, json_output: bool) -> None:
    """Detect hardware, score all models, and render the top recommendation."""
    from tinillm.recommend.render import render_recommend_table, render_recommend_json

    specs = detect()
    budget_gb, runs_on_gpu = _memory_budget(specs)

    if specs.gpus:
        best_gpu = max(specs.gpus, key=lambda g: g.vram_gb)
        bw = gpu_bandwidth_gbps(best_gpu.name)
    else:
        bw = 0.0

    candidates = [
        (model, _fit_model(model, budget_gb, bw, runs_on_gpu))
        for model in MODELS
    ]

    ranked = rank_models(candidates, use_case)

    if json_output:
        import click
        click.echo(render_recommend_json(ranked, specs, budget_gb, runs_on_gpu, use_case))
        return

    render_recommend_table(ranked, specs, budget_gb, runs_on_gpu, use_case)
