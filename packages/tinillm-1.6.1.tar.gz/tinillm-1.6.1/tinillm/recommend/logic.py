"""Ranking logic for `tinillm recommend`."""

from __future__ import annotations

from dataclasses import dataclass

from tinillm.analyzer.types import FitLevel, ModelFit
from tinillm.models.database import RealModel


# ── Fit-level → numeric score ─────────────────────────────────────────────

FIT_SCORE: dict[str, int] = {
    "Perfect":  4,
    "Good":     3,
    "Marginal": 2,
    "TooTight": 0,
}

# ── Models to exclude from recommendations ────────────────────────────────
# nomic-embed-text is an embedding model only — no generation, exclude it.
_EXCLUDED_MODELS: frozenset[str] = frozenset({
    "nomic-embed-text:v1.5",
})

# ── Use-case affinity map ─────────────────────────────────────────────────
# Key: RealModel.name  Value: 2 = primary match, 1 = secondary. Absent = 0.
USE_CASE_AFFINITY: dict[str, dict[str, int]] = {
    "chat": {
        # Primary — Llama 3.x
        "llama3.2:1b":      2,
        "llama3.2:3b":      2,
        "llama3.1:8b":      2,
        "llama3.1:70b":     2,
        "llama3.3:70b":     2,
        # Primary — Mistral family
        "mistral:7b":       2,
        "mistral-nemo:12b": 2,
        "mixtral:8x7b":     2,
        # Primary — Gemma 3
        "gemma3:1b":        2,
        "gemma3:4b":        2,
        "gemma3:12b":       2,
        "gemma3:27b":       2,
        # Secondary — capable general-purpose
        "smollm2:1.7b":     1,
        "qwen2.5:7b":       1,
        "qwen2.5:14b":      1,
        "qwen2.5:32b":      1,
        "qwen2.5:72b":      1,
        "phi4-mini:3.8b":   1,
    },
    "coding": {
        # Primary — CodeLlama
        "codellama:7b":     2,
        "codellama:13b":    2,
        "codellama:34b":    2,
        # Primary — DeepSeek-R1
        "deepseek-r1:1.5b": 2,
        "deepseek-r1:7b":   2,
        "deepseek-r1:8b":   2,
        "deepseek-r1:14b":  2,
        "deepseek-r1:32b":  2,
        "deepseek-r1:70b":  2,
        # Primary — Qwen 2.5
        "qwen2.5:0.5b":     2,
        "qwen2.5:1.5b":     2,
        "qwen2.5:3b":       2,
        "qwen2.5:7b":       2,
        "qwen2.5:14b":      2,
        "qwen2.5:32b":      2,
        "qwen2.5:72b":      2,
        # Secondary
        "phi4:14b":         1,
        "mistral:7b":       1,
    },
    "reasoning": {
        # Primary — DeepSeek-R1
        "deepseek-r1:1.5b": 2,
        "deepseek-r1:7b":   2,
        "deepseek-r1:8b":   2,
        "deepseek-r1:14b":  2,
        "deepseek-r1:32b":  2,
        "deepseek-r1:70b":  2,
        # Primary — Phi-4
        "phi4-mini:3.8b":   2,
        "phi4:14b":         2,
        # Primary — Qwen 2.5
        "qwen2.5:3b":       2,
        "qwen2.5:7b":       2,
        "qwen2.5:14b":      2,
        "qwen2.5:32b":      2,
        "qwen2.5:72b":      2,
        # Secondary
        "gemma3:12b":       1,
        "gemma3:27b":       1,
        "llama3.1:8b":      1,
    },
    "writing": {
        # Primary — instruction-following / long-context models
        "mistral-nemo:12b":    2,
        "command-r:35b":       2,
        "command-r-plus:104b": 2,
        "llama3.1:8b":         2,
        "llama3.1:70b":        2,
        "llama3.3:70b":        2,
        # Secondary
        "mistral:7b":          1,
        "mixtral:8x7b":        1,
        "qwen2.5:14b":         1,
        "qwen2.5:32b":         1,
        "qwen2.5:72b":         1,
    },
    "fast": {
        # Primary — sub-2B speed demons
        "smollm2:135m":     2,
        "smollm2:360m":     2,
        "smollm2:1.7b":     2,
        "gemma3:1b":        2,
        "qwen2.5:0.5b":     2,
        # Secondary — compact but useful
        "llama3.2:1b":      1,
        "qwen2.5:1.5b":     1,
        "deepseek-r1:1.5b": 1,
        "llama3.2:3b":      1,
    },
}


@dataclass
class ScoredModel:
    """A model that passed TooTight filtering, with its computed ranking scores."""
    real_model: RealModel
    fit: ModelFit
    fit_score: int    # FIT_SCORE[fit_level]
    affinity: int     # 0, 1, or 2 from USE_CASE_AFFINITY
    total_score: int  # fit_score + affinity


def rank_models(
    candidates: list[tuple[RealModel, ModelFit]],
    use_case: str | None,
    top_n: int = 3,
) -> list[ScoredModel]:
    """Score and rank models for the given use case, returning the top_n results.

    Scoring:
        total_score = fit_score + affinity
    Sort key: (-total_score, -tokens_per_sec) — TPS breaks ties within the same score.
    TooTight models and embedding-only models are excluded.
    """
    affinity_map: dict[str, int] = USE_CASE_AFFINITY.get(use_case, {}) if use_case else {}

    scored: list[ScoredModel] = []
    for real_model, fit in candidates:
        if real_model.name in _EXCLUDED_MODELS:
            continue
        if fit.fit_level == FitLevel.TOO_TIGHT:
            continue
        fit_score = FIT_SCORE[fit.fit_level.value]
        affinity = affinity_map.get(real_model.name, 0)
        total = fit_score + affinity
        scored.append(ScoredModel(
            real_model=real_model,
            fit=fit,
            fit_score=fit_score,
            affinity=affinity,
            total_score=total,
        ))

    scored.sort(key=lambda s: (
        -s.total_score,
        -(s.fit.tokens_per_sec or 0.0),
    ))
    return scored[:top_n]
