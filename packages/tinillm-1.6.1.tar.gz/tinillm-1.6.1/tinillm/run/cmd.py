"""Core logic for `tinillm run`."""

from __future__ import annotations

import sys
from typing import Optional

import click

from tinillm.models.database import MODELS, RealModel
from tinillm.analyzer.fit import _memory_budget, _primary_gpu_bandwidth
from tinillm.analyzer.types import FitLevel
from tinillm.hardware.detect import detect
from tinillm.models.cmd import _fit_model
from tinillm.recommend.logic import USE_CASE_AFFINITY, FIT_SCORE


def _check_ollama(console) -> None:
    """Verify Ollama is reachable; print an error and exit if it is not."""
    try:
        import ollama
        ollama.list()
        return
    except Exception:
        pass

    console.print("[bold red]✗[/] Ollama is not running. Start it with:")
    console.print("    [bold]ollama serve[/]")
    sys.exit(1)


def _find_model(tag: str) -> Optional[RealModel]:
    """Return the RealModel whose ollama_tag or display_name matches tag (case-insensitive)."""
    tag_lower = tag.lower()
    for m in MODELS:
        if m.ollama_tag.lower() == tag_lower or m.display_name.lower() == tag_lower:
            return m
    return None


def _launch(tag: str, dry_run: bool, console) -> None:
    """Start a tinillm chat session with web_search, or print a description for --dry-run."""
    if dry_run:
        console.print(f"[dim]Would run:[/] tinillm chat session · {tag} (web_search enabled)")
        return
    from tinillm.run.chat import run_chat
    run_chat(tag, console)


def run_run(
    model_tag: Optional[str],
    use_case: Optional[str],
    force: bool,
    dry_run: bool,
) -> None:
    """Detect hardware, pick or validate a model, check Ollama, and launch it."""
    from rich.console import Console
    from tinillm.run.render import render_picker_table, render_fit_warning
    from tinillm.render.styles import TINILLM_THEME

    console = Console(theme=TINILLM_THEME)

    specs = detect()
    budget_gb, runs_on_gpu = _memory_budget(specs)
    bw = _primary_gpu_bandwidth(specs)

    # ── Explicit model tag ────────────────────────────────────────────────
    if model_tag:
        db_model = _find_model(model_tag)

        if db_model is None:
            console.print(
                f"[dim]Note:[/] '{model_tag}' is not in tinillm's model database — "
                "skipping fit check."
            )
        else:
            fit = _fit_model(db_model, budget_gb, bw, runs_on_gpu)
            if fit.fit_level == FitLevel.TOO_TIGHT and not force:
                render_fit_warning(console, db_model, fit, budget_gb)
                sys.exit(1)
            if fit.fit_level in (FitLevel.MARGINAL, FitLevel.TOO_TIGHT):
                render_fit_warning(console, db_model, fit, budget_gb)

        if not dry_run:
            _check_ollama(console)
        _launch(model_tag, dry_run, console)
        return

    # ── Interactive picker ────────────────────────────────────────────────
    candidates = [
        (model, _fit_model(model, budget_gb, bw, runs_on_gpu))
        for model in MODELS
    ]

    runnable = [(m, f) for m, f in candidates if f.fit_level != FitLevel.TOO_TIGHT]

    if not runnable:
        console.print(
            "[bold red]No models fit on this hardware.[/] "
            "Try upgrading RAM or adding a GPU."
        )
        sys.exit(1)

    if use_case:
        affinity_map = USE_CASE_AFFINITY.get(use_case, {})
        runnable.sort(key=lambda pair: (
            -affinity_map.get(pair[0].name, 0),
            -FIT_SCORE.get(pair[1].fit_level.value, 0),
            -(pair[1].tokens_per_sec or 0.0),
        ))
    else:
        runnable.sort(key=lambda pair: (
            -FIT_SCORE.get(pair[1].fit_level.value, 0),
            -(pair[1].tokens_per_sec or 0.0),
        ))

    entries = [(i + 1, m, f) for i, (m, f) in enumerate(runnable)]
    render_picker_table(console, specs, entries)

    while True:
        raw = click.prompt(
            f"Enter model number [1-{len(entries)}] (q to quit)",
            default="q",
            show_default=False,
        )
        stripped = raw.strip().lower()
        if stripped == "q":
            sys.exit(0)
        try:
            choice = int(stripped)
        except ValueError:
            console.print("[dim]Please enter a number or 'q' to quit.[/]")
            continue
        if 1 <= choice <= len(entries):
            _, chosen_model, _ = entries[choice - 1]
            break
        console.print(f"[dim]Please enter a number between 1 and {len(entries)}.[/]")

    if not dry_run:
        _check_ollama(console)
    _launch(chosen_model.ollama_tag, dry_run, console)
