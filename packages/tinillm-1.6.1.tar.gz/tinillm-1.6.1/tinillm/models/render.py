"""Rich table renderer for `tinillm models` output."""

from __future__ import annotations

import json
import os

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

from tinillm.analyzer.types import FitLevel, ModelFit
from tinillm.hardware.types import SystemSpecs
from tinillm.models.database import RealModel
from tinillm.render.styles import FIT_COLORS, TINILLM_THEME


def _make_console() -> Console:
    import sys
    no_color = "NO_COLOR" in os.environ
    # In non-interactive environments (pipes, tests) Rich defaults to 80 cols and
    # truncates wide tables.  Use COLUMNS if set, otherwise a wide fallback so all
    # columns (including the optional "Installed" one) are always visible.
    width = None if sys.stdout.isatty() else int(os.environ.get("COLUMNS", "220"))
    return Console(theme=TINILLM_THEME, no_color=no_color, highlight=False, width=width)


def render_models_table(
    results: list[tuple[RealModel, ModelFit, bool]],
    specs: SystemSpecs,
    budget_gb: float,
    runs_on_gpu: bool,
    show_installed: bool,
) -> None:
    console = _make_console()
    console.print()

    # Header panel
    gpu_str = specs.gpus[0].name if specs.gpus else "CPU only"
    budget_src = "VRAM" if runs_on_gpu else "RAM"
    console.print(
        Panel(
            f"[bold white]Hardware budget:[/] [cyan]{budget_gb:.1f} GB[/] {budget_src}  ·  "
            f"[bold white]GPU:[/] [cyan]{gpu_str}[/]  ·  "
            f"[bold white]Showing:[/] [cyan]{len(results)} models[/]",
            title="[bold white]tinillm models[/]",
            border_style="bright_blue",
            box=box.ROUNDED,
            expand=False,
        )
    )
    console.print()

    if not results:
        console.print("  [dim]No models match the current filters.[/dim]\n")
        return

    # Build table
    table = Table(
        box=box.SIMPLE_HEAD,
        show_lines=False,
        header_style="bold dim white",
        expand=False,
        padding=(0, 1),
    )

    table.add_column("Model",       min_width=22, no_wrap=True)
    table.add_column("Provider",    min_width=12)
    table.add_column("Size",        min_width=6,  justify="right")
    table.add_column("Fit",         min_width=10)
    table.add_column("Best Quant",  min_width=10)
    table.add_column("Mem Needed",  min_width=10, justify="right")
    table.add_column("Tokens/sec",  min_width=10, justify="right")
    table.add_column("Ollama Pull", min_width=18, no_wrap=True)
    if show_installed:
        table.add_column("Installed", min_width=9, justify="center")

    for model, fit, is_installed in results:
        color = FIT_COLORS.get(fit.fit_level.value, "#ffffff")
        fit_text = Text(fit.fit_level.value, style=f"bold {color}")

        size_str = _fmt_size(model.params_b)

        if fit.fit_level == FitLevel.TOO_TIGHT:
            row = [
                Text(model.display_name, style="dim"),
                Text(model.provider, style="dim"),
                Text(size_str, style="dim"),
                fit_text,
                Text("—", style="dim"),
                Text("—", style="dim"),
                Text("—", style="dim"),
                Text(model.ollama_tag, style="dim"),
            ]
        else:
            quant_str = fit.best_quant.value if fit.best_quant else "—"
            mem_str = f"{fit.mem_required_gb:.1f} GB" if fit.mem_required_gb else "—"
            tps = fit.tokens_per_sec or 0.0
            tps_str = f"{tps:.0f} t/s" if tps >= 1 else f"{tps:.1f} t/s"

            row = [
                Text(model.display_name, style="bold white"),
                Text(model.provider),
                Text(size_str),
                fit_text,
                Text(quant_str, style=f"{color}"),
                Text(mem_str),
                Text(tps_str),
                Text(f"ollama pull {model.ollama_tag}", style="dim cyan"),
            ]

        if show_installed:
            row.append(Text("✓", style="bold green") if is_installed else Text(""))

        table.add_row(*row)

    console.print(table)
    _print_footer(console, results, show_installed)


def _fmt_size(params_b: float) -> str:
    if params_b < 1.0:
        return f"{params_b * 1000:.0f}M"
    elif params_b == int(params_b):
        return f"{int(params_b)}B"
    else:
        return f"{params_b:.1f}B"


def _print_footer(
    console: Console,
    results: list[tuple[RealModel, ModelFit, bool]],
    show_installed: bool,
) -> None:
    tight = sum(1 for _, f, _ in results if f.fit_level == FitLevel.TOO_TIGHT)
    if tight:
        console.print(f"  [dim]{tight} model(s) marked TooTight — won't fit current hardware[/dim]")

    legend = "  " + "  ·  ".join(
        f"[{color}]{level}[/]" for level, color in FIT_COLORS.items()
    )
    console.print(legend)

    if not show_installed:
        console.print("  [dim]Tip: add --ollama to see which models are already installed[/dim]")
    console.print()


def render_models_json(
    results: list[tuple[RealModel, ModelFit, bool]],
    specs: SystemSpecs,
    show_installed: bool,
) -> str:
    models_list = []
    for model, fit, is_installed in results:
        entry: dict = {
            "name": model.name,
            "display_name": model.display_name,
            "provider": model.provider,
            "params_b": model.params_b,
            "ollama_tag": model.ollama_tag,
            "description": model.description,
            "fit_level": fit.fit_level.value,
            "best_quant": fit.best_quant.value if fit.best_quant else None,
            "mem_required_gb": fit.mem_required_gb,
            "tokens_per_sec": fit.tokens_per_sec,
            "runs_on_gpu": fit.runs_on_gpu,
        }
        if show_installed:
            entry["installed"] = is_installed
        models_list.append(entry)

    return json.dumps({"models": models_list}, indent=2)
