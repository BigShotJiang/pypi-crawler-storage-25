"""Tests für Pre-Validation: aktive Profile brauchen konfigurierte Targets."""

from pathlib import Path

from familienfilm_manager.api.models import (
    PublishRequest,
    RuntimeOptions,
)
from familienfilm_manager.core.directory_publisher import run_publish_directory
from familienfilm_manager.core.publisher import run_publish


def _make_video(tmp_path: Path) -> Path:
    """Hilfsfunktion: erstellt eine Dummy-Videodatei."""
    video = tmp_path / "2026-04-16 Test.mov"
    video.touch()
    return video


# ── run_publish ──


def test_publish_fails_without_web_target_when_web_enabled(tmp_path: Path):
    """Explizit aktivierter Web-Kanal (``web_enabled=True``) ohne web_target
    → Fehler. (Web ist seit v0.8.0 per Default AUS.)"""
    video = _make_video(tmp_path)
    request = PublishRequest(
        source_path=video,
        skip_infuse=True,
        web_enabled=True,  # Web explizit aktiviert
        skip_archive=True,
    )
    runtime = RuntimeOptions()  # Keine Targets konfiguriert
    result = run_publish(request, runtime)
    assert result.success is False
    assert "targets.web" in (result.error_message or "")


def test_publish_default_web_off_passes_without_web_target(tmp_path: Path):
    """Default-Safety: Ohne explizites ``web_enabled`` läuft Publish ohne
    web_target durch (Web wird nicht deployed)."""
    video = _make_video(tmp_path)
    request = PublishRequest(
        source_path=video,
        skip_infuse=True,
        skip_archive=True,
    )
    runtime = RuntimeOptions()  # Keine Targets
    result = run_publish(request, runtime)
    # Validation passt, weitere Verarbeitung kann scheitern — aber NICHT
    # wegen targets.web
    if result.error_message:
        assert "targets.web" not in result.error_message


def test_publish_fails_without_archive_target(tmp_path: Path):
    """Aktives Archive ohne archive_target → Fehler."""
    video = _make_video(tmp_path)
    request = PublishRequest(
        source_path=video,
        skip_infuse=True,
        skip_web=True,
        skip_archive=False,  # Archive aktiv
    )
    runtime = RuntimeOptions()
    result = run_publish(request, runtime)
    assert result.success is False
    assert "targets.archive" in (result.error_message or "")


def test_publish_fails_without_infuse_target(tmp_path: Path):
    """Aktives Infuse ohne infuse_target → Fehler."""
    video = _make_video(tmp_path)
    request = PublishRequest(
        source_path=video,
        skip_infuse=False,  # Infuse aktiv
        skip_web=True,
        skip_archive=True,
    )
    runtime = RuntimeOptions()
    result = run_publish(request, runtime)
    assert result.success is False
    assert "targets.infuse" in (result.error_message or "")


def test_publish_skip_all_passes_validation(tmp_path: Path):
    """Wenn alle Profile übersprungen → keine Target-Validierung."""
    video = _make_video(tmp_path)
    request = PublishRequest(
        source_path=video,
        skip_infuse=True,
        skip_web=True,
        skip_archive=True,
    )
    runtime = RuntimeOptions()
    result = run_publish(request, runtime)
    # Validation passt, aber Verarbeitung scheitert weiter unten (kein Datum etc.)
    # Wichtig: error_message darf NICHT von Target-Validation kommen
    if result.error_message:
        assert "targets." not in result.error_message


def test_publish_combined_targets_in_error(tmp_path: Path):
    """Mehrere fehlende Targets werden aufgelistet.
    Web ist per Default aus → muss hier explizit aktiviert werden."""
    video = _make_video(tmp_path)
    request = PublishRequest(source_path=video, web_enabled=True)
    runtime = RuntimeOptions()
    result = run_publish(request, runtime)
    assert result.success is False
    assert "targets.infuse" in (result.error_message or "")
    assert "targets.web" in (result.error_message or "")
    assert "targets.archive" in (result.error_message or "")


# ── run_publish_directory ──


def test_publish_directory_fails_early_without_infuse_target(tmp_path: Path):
    """publish-dir bricht früh ab wenn Infuse-Target fehlt — kein Scanning."""
    video = _make_video(tmp_path)  # Wäre qualifiziert
    runtime = RuntimeOptions()  # Keine Targets
    result = run_publish_directory(tmp_path, runtime, skip_web=True, skip_archive=True)
    # skip_infuse=False (Default) und kein infuse_target → früher Fehler
    assert result.success is False
    assert "targets.infuse" in (result.error_message or "")
    # Wichtig: keine Videos verarbeitet
    assert len(result.videos) == 0


def test_publish_directory_web_target_checked_per_video(tmp_path: Path):
    """Fehlendes web_target wird erst pro Video validiert. Web ist per
    Default aus — ohne ``web_enabled`` irgendwo gesetzt passiert nichts."""
    video = _make_video(tmp_path)
    runtime = RuntimeOptions()  # Keine Targets
    result = run_publish_directory(tmp_path, runtime, skip_infuse=True, skip_archive=True)
    # Web default aus → Directory-Level läuft durch, pro Video läuft durch
    # (oder scheitert an anderem Grund, aber nicht an targets.web).
    # Wichtig: kein früher Directory-Level-Fehler wegen targets.web.
    assert "targets.web" not in (result.error_message or "")


def test_publish_directory_passes_with_skip_flags(tmp_path: Path):
    """Wenn alle Profile übersprungen → keine Target-Validierung im Batch."""
    runtime = RuntimeOptions()
    result = run_publish_directory(
        tmp_path,
        runtime,
        skip_infuse=True,
        skip_web=True,
        skip_archive=True,
    )
    # Validation passt, leeres Verzeichnis → keine Videos
    assert result.success is True
    assert len(result.videos) == 0
