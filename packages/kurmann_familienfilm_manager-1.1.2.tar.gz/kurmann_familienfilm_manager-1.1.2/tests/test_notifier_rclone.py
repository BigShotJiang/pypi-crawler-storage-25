"""Tests für notifier_storage + rclone-aware notifier (v0.12.0)."""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import patch

import pytest


@pytest.fixture(autouse=True)
def _no_retry_sleep():
    """Patcht time.sleep im retry-loop, damit Tests nicht 13s pro Fail warten."""
    with patch("familienfilm_manager.core._rclone.time.sleep"):
        yield

from familienfilm_manager.core.notifier import (
    append_pending,
    mark_all_pending_as_aborted,
    mark_entry_cleaned_up,
    replace_entry_published,
)
from familienfilm_manager.core.notifier_storage import (
    NotificationStorage,
    push_to_remote,
    resolve_storage,
)


# ── resolve_storage ───────────────────────────────────────────────────


def test_resolve_storage_local_path():
    """Lokaler Pfad: Cache = Pfad direkt, kein Remote."""
    storage = resolve_storage("/tmp/test.html")
    assert storage.cache == Path("/tmp/test.html")
    assert storage.remote is None
    assert storage.is_remote is False


def test_resolve_storage_rclone_uri_uses_cache_dir(tmp_path, monkeypatch):
    """rclone-URI: Cache liegt unter ~/.cache/familienfilm-manager/<basename>."""
    monkeypatch.setattr(
        "familienfilm_manager.core.notifier_storage._CACHE_DIR",
        tmp_path / ".cache",
    )
    monkeypatch.setattr(
        "familienfilm_manager.core._rclone.DEFAULT_RETRY_DELAYS", (),
    )

    def fake_run(args, **kwargs):
        # rclone cat schlägt fehl (= remote leer) → kein initial pull
        raise subprocess.CalledProcessError(
            1, args, output="", stderr=b"not found",
        )

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        storage = resolve_storage("mega.nz:Familienfilme/Familienfilme.html")

    assert storage.cache == tmp_path / ".cache" / "Familienfilme.html"
    assert storage.remote == "mega.nz:Familienfilme/Familienfilme.html"
    assert storage.is_remote is True


def test_resolve_storage_initial_pull_when_cache_missing(tmp_path, monkeypatch):
    """Wenn Cache fehlt UND Remote etwas hat: initial-pull lädt es runter."""
    monkeypatch.setattr(
        "familienfilm_manager.core.notifier_storage._CACHE_DIR",
        tmp_path / ".cache",
    )
    remote_content = b"<html>existing remote content</html>"

    def fake_run(args, **kwargs):
        if "cat" in args:
            return subprocess.CompletedProcess(
                args=args, returncode=0,
                stdout=remote_content.decode("utf-8"), stderr="",
            )
        return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        storage = resolve_storage("mega.nz:Familienfilme/Familienfilme.html")

    assert storage.cache.exists()
    assert storage.cache.read_bytes() == remote_content


def test_resolve_storage_no_pull_when_cache_exists(tmp_path, monkeypatch):
    """Wenn Cache bereits da: kein erneuter Pull."""
    monkeypatch.setattr(
        "familienfilm_manager.core.notifier_storage._CACHE_DIR",
        tmp_path / ".cache",
    )
    cache = tmp_path / ".cache" / "Familienfilme.html"
    cache.parent.mkdir(parents=True)
    cache.write_text("local cached")

    cat_calls: list = []

    def fake_run(args, **kwargs):
        cat_calls.append(args)
        return subprocess.CompletedProcess(args=args, returncode=0, stdout="x", stderr="")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        storage = resolve_storage("mega.nz:Familienfilme/Familienfilme.html")

    assert storage.cache.read_text() == "local cached"
    # kein rclone-Aufruf
    assert cat_calls == []


# ── push_to_remote ────────────────────────────────────────────────────


def test_push_to_remote_local_only_is_noop():
    """Lokaler Storage: push_to_remote macht nichts."""
    storage = NotificationStorage(cache=Path("/tmp/x"), remote=None)
    with patch("familienfilm_manager.core._rclone.subprocess.run") as run_mock:
        ok = push_to_remote(storage)
    assert ok is True
    run_mock.assert_not_called()


def test_push_to_remote_calls_rclone_copyto(tmp_path):
    cache = tmp_path / "Familienfilme.html"
    cache.write_text("hello")
    storage = NotificationStorage(cache=cache, remote="mega.nz:remote.html")
    calls: list = []

    def fake_run(args, **kwargs):
        calls.append(list(args))
        return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        ok = push_to_remote(storage)

    assert ok is True
    assert any(c[1] == "copyto" and c[2] == str(cache) and c[3] == "mega.nz:remote.html" for c in calls)


def test_push_to_remote_dedup_then_copyto(tmp_path):
    """v1.0.1+: vor copyto wird ein delete --include <basename> aufgerufen,
    damit mega.nz-Duplikate nicht auflaufen."""
    cache = tmp_path / "Familienfilme.html"
    cache.write_text("hello")
    storage = NotificationStorage(
        cache=cache, remote="mega.nz:Videoschnitt/Familienfilme.html",
    )
    calls: list = []

    def fake_run(args, **kwargs):
        calls.append(list(args))
        return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        ok = push_to_remote(storage)

    assert ok is True
    # Reihenfolge: erst delete (parent + --include basename), dann copyto.
    op_sequence = [c[1] for c in calls]
    assert op_sequence == ["delete", "copyto"]
    delete_call = calls[0]
    assert delete_call[2] == "mega.nz:Videoschnitt"
    assert "--include" in delete_call
    assert delete_call[delete_call.index("--include") + 1] == "Familienfilme.html"


def test_push_to_remote_dedup_failure_is_swallowed(tmp_path):
    """Wenn der Pre-Upload-Delete fehlschlägt (z.B. parent existiert noch nicht),
    läuft copyto trotzdem — Hygiene-Schritt soll den Sync nicht blockieren."""
    cache = tmp_path / "Familienfilme.html"
    cache.write_text("hello")
    storage = NotificationStorage(cache=cache, remote="mega.nz:remote.html")
    calls: list = []

    def fake_run(args, **kwargs):
        calls.append(list(args))
        if args[1] == "delete":
            raise subprocess.CalledProcessError(1, args, stderr=b"directory not found")
        return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        with patch("familienfilm_manager.core._rclone.DEFAULT_RETRY_DELAYS", ()):
            ok = push_to_remote(storage)

    assert ok is True
    assert any(c[1] == "copyto" for c in calls)


def test_push_to_remote_tolerates_rclone_failure(tmp_path, capsys):
    """Wenn rclone copyto fehlschlägt: False zurück, Cache bleibt aktuell, Warning auf stderr."""
    cache = tmp_path / "Familienfilme.html"
    cache.write_text("hello")
    storage = NotificationStorage(cache=cache, remote="mega.nz:remote.html")

    def fake_run(args, **kwargs):
        raise subprocess.CalledProcessError(1, args, stderr=b"network error")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            with patch("familienfilm_manager.core._rclone.DEFAULT_RETRY_DELAYS", ()):
                ok = push_to_remote(storage)

    assert ok is False
    captured = capsys.readouterr()
    assert "Notification-Sync" in captured.err
    assert "fehlgeschlagen" in captured.err


# ── notifier integration: sync flag ───────────────────────────────────


def test_append_pending_with_string_target_uses_resolver(tmp_path, monkeypatch):
    """append_pending mit String-Target soll Cache + Sync-Pfad nutzen."""
    monkeypatch.setattr(
        "familienfilm_manager.core.notifier_storage._CACHE_DIR",
        tmp_path / ".cache",
    )
    monkeypatch.setattr(
        "familienfilm_manager.core._rclone.DEFAULT_RETRY_DELAYS", (),
    )
    copyto_calls: list = []

    def fake_run(args, **kwargs):
        if "cat" in args:
            # Remote leer
            raise subprocess.CalledProcessError(1, args, stderr=b"not found")
        if "copyto" in args:
            copyto_calls.append(list(args))
        return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        append_pending(
            "mega.nz:Familienfilme.md",
            video_id="abc",
            title="Test",
        )

    cache = tmp_path / ".cache" / "Familienfilme.md"
    assert cache.exists()
    content = cache.read_text()
    assert "id: abc · status: pending" in content
    assert "## " in content and "Test" in content
    # Sync zum Remote ist erfolgt
    assert len(copyto_calls) == 1


def test_mark_all_pending_as_aborted_does_not_sync(tmp_path, monkeypatch):
    """mark_all_pending_as_aborted ist eine interne Hygiene-Funktion und
    soll NICHT zum Remote syncen — geht beim nächsten echten Write mit raus."""
    monkeypatch.setattr(
        "familienfilm_manager.core.notifier_storage._CACHE_DIR",
        tmp_path / ".cache",
    )
    cache = tmp_path / ".cache" / "Familienfilme.md"
    cache.parent.mkdir(parents=True)
    # Pre-existing pending entry (neues v1.1.0-Format)
    cache.write_text(
        "# Familienfilme\n\n_Aktualisiert: 01.05.2026, 12:00_\n\n"
        "## 01.05.2026 — X\n"
        "> id: abc · status: pending · aktualisiert: 2026-05-01T10:00:00Z\n"
        "\n"
        "- **Status:** In Bearbeitung\n"
        "\n"
    )
    copyto_calls: list = []

    def fake_run(args, **kwargs):
        if "copyto" in args:
            copyto_calls.append(list(args))
        return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        count = mark_all_pending_as_aborted("mega.nz:Familienfilme.md")

    assert count == 1
    # Cache wurde geändert (aborted statt pending)
    assert "status: aborted" in cache.read_text()
    # Aber KEIN Sync zum Remote
    assert copyto_calls == []


def test_replace_entry_published_with_path_object_no_sync(tmp_path):
    """Path-Objekt (lokaler Modus) macht keinen rclone-Aufruf."""
    target = tmp_path / "Familienfilme.md"
    with patch("familienfilm_manager.core._rclone.subprocess.run") as run_mock:
        replace_entry_published(target, video_id="abc", title="T")
    assert target.exists()
    run_mock.assert_not_called()


def test_mark_entry_cleaned_up_syncs(tmp_path, monkeypatch):
    """Cleanup-Note (real-time-relevant) syncen."""
    monkeypatch.setattr(
        "familienfilm_manager.core.notifier_storage._CACHE_DIR",
        tmp_path / ".cache",
    )
    cache = tmp_path / ".cache" / "Familienfilme.md"
    cache.parent.mkdir(parents=True)

    target = "mega.nz:Familienfilme.md"
    copyto_calls: list = []

    def fake_run(args, **kwargs):
        if "copyto" in args:
            copyto_calls.append(list(args))
        if len(args) > 1 and args[1] == "cat":
            # Initial-Pull: Remote leer
            raise subprocess.CalledProcessError(1, args, stderr=b"not found")
        return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")

    # Wichtig: subprocess.run muss den GANZEN Test über gepatched sein —
    # auch beim ersten replace_entry_published-Aufruf, der sonst real
    # rclone ruft und im falschen Verzeichnis schreiben könnte.
    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        # Pre-existing published entry mit Web-URL
        replace_entry_published(
            target, video_id="abc", title="T",
            video_url="https://example.com/q26qobjxl4c3/",
        )
        copyto_calls.clear()  # reset für die eigentliche Assertion unten

        ok = mark_entry_cleaned_up(
            target, web_id="q26qobjxl4c3",
            branding_base_url="https://example.com",
            cleanup_date="2026-04-30",
            reason="älter als 365 Tage",
        )

    assert ok is True
    assert "cleaned-up" in cache.read_text()
    assert "(älter als 365 Tage)" in cache.read_text()
    assert len(copyto_calls) == 1
