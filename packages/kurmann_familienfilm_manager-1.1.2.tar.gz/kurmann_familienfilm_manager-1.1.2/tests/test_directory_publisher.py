"""Tests für den Verzeichnis-Publisher (Filter, Sortierung, Skip-Logik)."""

from datetime import datetime
from pathlib import Path

from familienfilm_manager.core.directory_publisher import (
    _date_from_filename,
    _filter_stable_videos,
    _is_already_published,
    _is_qualified_video,
    _scan_directory,
)
from familienfilm_manager.core.sidecar_manager import (
    SidecarSettings,
    compute_source_fingerprint,
    write_sidecar,
)


def _write_published_sidecar(video_path: Path, **overrides) -> None:
    """Hilfsfunktion: schreibt ein Sidecar für ein voll publiziertes Video
    (alle drei Kanäle + per-Kanal-Fingerprint).

    Ab v0.6.0 braucht der Skip-Check auf allen aktiven Kanälen einen
    ``published_at``. Ab v0.8.0 zusätzlich einen per-Kanal-Fingerprint
    (Size + Head-SHA1).
    """
    size, head = compute_source_fingerprint(video_path)
    now_iso = datetime.now().isoformat(timespec="seconds")
    # Per-Kanal-Fingerprint (v0.8.0+). Overrides auf Legacy-``source_*`` bleiben
    # möglich für Tests, die explizit die Fallback-Migration prüfen.
    fp_size = overrides.get("source_size_bytes", size)
    fp_head = overrides.get("source_head_sha1", head)
    settings = SidecarSettings(
        web_id=overrides.get("web_id", "a3xk9mn2pqrw"),
        web_published_at=overrides.get("web_published_at", now_iso),
        web_source_size_bytes=fp_size,
        web_source_head_sha1=fp_head,
        local_published_at=overrides.get("local_published_at", now_iso),
        local_source_size_bytes=fp_size,
        local_source_head_sha1=fp_head,
        archive_published_at=overrides.get("archive_published_at", now_iso),
        archive_source_size_bytes=fp_size,
        archive_source_head_sha1=fp_head,
    )
    write_sidecar(video_path, settings)


# ── _is_qualified_video: Filter ──


def test_qualified_video_with_date_prefix(tmp_path: Path):
    """Datei mit Datum-Präfix und .mov-Endung ist qualifiziert."""
    f = tmp_path / "2026-04-16 HDR-Test.mov"
    f.touch()
    assert _is_qualified_video(f) is True


def test_qualified_video_mp4(tmp_path: Path):
    """Auch .mp4 ist qualifiziert."""
    f = tmp_path / "2026-04-12 Wanderung.mp4"
    f.touch()
    assert _is_qualified_video(f) is True


def test_unqualified_no_date_prefix(tmp_path: Path):
    """Ohne Datum-Präfix → nicht qualifiziert."""
    f = tmp_path / "HDR-Test.mov"
    f.touch()
    assert _is_qualified_video(f) is False


def test_unqualified_unknown_extension(tmp_path: Path):
    """Unbekannte Endung → nicht qualifiziert."""
    f = tmp_path / "2026-04-16 Test.txt"
    f.touch()
    assert _is_qualified_video(f) is False


def test_unqualified_hidden_file(tmp_path: Path):
    """Hidden Files (mit .) werden ignoriert."""
    f = tmp_path / ".2026-04-16 Test.mov"
    f.touch()
    assert _is_qualified_video(f) is False


def test_unqualified_directory(tmp_path: Path):
    """Verzeichnis ist nicht qualifiziert (auch wenn Name passt)."""
    d = tmp_path / "2026-04-16 Verzeichnis.mov"
    d.mkdir()
    assert _is_qualified_video(d) is False


# ── _date_from_filename ──


def test_date_extraction(tmp_path: Path):
    """Datum wird korrekt aus Stem extrahiert."""
    assert _date_from_filename(Path("/tmp/2026-04-16 Test.mov")) == "2026-04-16"


def test_date_extraction_with_poster_suffix(tmp_path: Path):
    """Auch mit Poster-Suffix wird das Datum korrekt extrahiert."""
    assert _date_from_filename(Path("/tmp/2026-04-12 Test poster-1min30.mov")) == "2026-04-12"


# ── _scan_directory: Sortierung ──


def test_scan_sorts_by_date_oldest_first(tmp_path: Path):
    """Videos werden chronologisch sortiert (älteste zuerst)."""
    (tmp_path / "2026-04-16 C.mov").touch()
    (tmp_path / "2026-04-12 A.mov").touch()
    (tmp_path / "2026-04-14 B.mov").touch()

    result, _ = _scan_directory(tmp_path)
    names = [p.name for p in result]
    assert names == ["2026-04-12 A.mov", "2026-04-14 B.mov", "2026-04-16 C.mov"]


def test_scan_ignores_unqualified_files(tmp_path: Path):
    """Unqualifizierte Dateien werden ignoriert."""
    (tmp_path / "2026-04-16 Valid.mov").touch()
    (tmp_path / "Invalid.mov").touch()
    (tmp_path / "2026-04-15 Notes.txt").touch()

    result, _ = _scan_directory(tmp_path)
    names = [p.name for p in result]
    assert names == ["2026-04-16 Valid.mov"]


def test_scan_empty_directory(tmp_path: Path):
    """Leeres Verzeichnis → leere Liste."""
    assert _scan_directory(tmp_path) == ([], [])


def test_scan_same_date_alphabetical(tmp_path: Path):
    """Bei gleichem Datum → alphabetisch."""
    (tmp_path / "2026-04-16 Z-Video.mov").touch()
    (tmp_path / "2026-04-16 A-Video.mov").touch()

    result, _ = _scan_directory(tmp_path)
    names = [p.name for p in result]
    assert names == ["2026-04-16 A-Video.mov", "2026-04-16 Z-Video.mov"]


# ── _scan_directory: recursive ──


def test_recursive_scan_finds_videos_in_subdirectories(tmp_path: Path):
    """Mit recursive=True werden Unterverzeichnisse mitgescannt."""
    (tmp_path / "2026-04-16 Root.mov").touch()
    sub = tmp_path / "2026" / "Q2"
    sub.mkdir(parents=True)
    (sub / "2026-04-17 Deep.mov").touch()

    result_flat, _ = _scan_directory(tmp_path, recursive=False)
    result_recursive, _ = _scan_directory(tmp_path, recursive=True)

    assert {p.name for p in result_flat} == {"2026-04-16 Root.mov"}
    assert {p.name for p in result_recursive} == {
        "2026-04-16 Root.mov",
        "2026-04-17 Deep.mov",
    }


def test_recursive_scan_skips_hidden_subdirectories(tmp_path: Path):
    """Hidden-Verzeichnisse (.Trashes etc.) werden bei recursive=True ignoriert."""
    trashes = tmp_path / ".Trashes"
    trashes.mkdir()
    (trashes / "2026-04-10 Alt.mov").touch()
    (tmp_path / "2026-04-16 Neu.mov").touch()

    result, _ = _scan_directory(tmp_path, recursive=True)
    assert [p.name for p in result] == ["2026-04-16 Neu.mov"]


def test_recursive_scan_sorts_across_subdirectories(tmp_path: Path):
    """Bei recursive werden Videos über Verzeichnisgrenzen chronologisch sortiert."""
    (tmp_path / "2026-04-18 C.mov").touch()
    sub = tmp_path / "Unterverzeichnis"
    sub.mkdir()
    (sub / "2026-04-12 A.mov").touch()
    (sub / "2026-04-15 B.mov").touch()

    result, _ = _scan_directory(tmp_path, recursive=True)
    names = [p.name for p in result]
    assert names == ["2026-04-12 A.mov", "2026-04-15 B.mov", "2026-04-18 C.mov"]


def test_verbose_logs_directory_settings_resolution(tmp_path: Path, monkeypatch):
    """Bei `-v` loggt run_publish_directory pro Parent-Dir einmal, welche
    familienfilm.toml gefunden wurde und wie sie interpretiert wurde."""
    import familienfilm_manager.core.directory_publisher as dp
    from familienfilm_manager.api.models import (
        FamilienfilmStage,
        PublishResult,
        RuntimeOptions,
    )

    (tmp_path / "familienfilm.toml").write_text(
        'category = "Familie"\nweb_enabled = true\n', encoding="utf-8",
    )
    video = tmp_path / "2026-04-16 Test.mov"
    video.write_bytes(b"x")

    events = []

    def on_event(ev):
        events.append(ev)

    def fake_run_publish(request, runtime, on_event=None):  # noqa: ARG001
        return PublishResult(success=True)

    monkeypatch.setattr(dp, "run_publish", fake_run_publish)

    dp.run_publish_directory(
        directory=tmp_path,
        runtime=RuntimeOptions(infuse_target="nas:/i", archive_target="nas:/a"),
        on_event=on_event,
    )

    settings_events = [
        e for e in events if e.stage_id == FamilienfilmStage.DIRECTORY_SETTINGS_RESOLVED
    ]
    assert len(settings_events) == 1
    msg = settings_events[0].message
    assert "familienfilm.toml" in msg
    assert "category='Familie'" in msg
    assert "web_enabled=true" in msg


def test_verbose_logs_missing_directory_settings(tmp_path: Path, monkeypatch):
    """Ohne familienfilm.toml meldet der Verbose-Log 'keine gefunden'."""
    import familienfilm_manager.core.directory_publisher as dp
    from familienfilm_manager.api.models import (
        FamilienfilmStage,
        PublishResult,
        RuntimeOptions,
    )

    video = tmp_path / "2026-04-16 Test.mov"
    video.write_bytes(b"x")

    events = []
    monkeypatch.setattr(
        dp, "run_publish",
        lambda request, runtime, on_event=None: PublishResult(success=True),
    )

    dp.run_publish_directory(
        directory=tmp_path,
        runtime=RuntimeOptions(infuse_target="nas:/i", archive_target="nas:/a"),
        on_event=events.append,
    )

    settings_events = [
        e for e in events if e.stage_id == FamilienfilmStage.DIRECTORY_SETTINGS_RESOLVED
    ]
    assert len(settings_events) == 1
    assert "keine gefunden" in settings_events[0].message


def test_verbose_logs_once_per_parent_dir(tmp_path: Path, monkeypatch):
    """Mehrere Videos im gleichen Parent-Dir → nur ein DIRECTORY_SETTINGS_RESOLVED-Event."""
    import familienfilm_manager.core.directory_publisher as dp
    from familienfilm_manager.api.models import (
        FamilienfilmStage,
        PublishResult,
        RuntimeOptions,
    )

    (tmp_path / "familienfilm.toml").write_text('category = "A"\n', encoding="utf-8")
    (tmp_path / "2026-04-16 A.mov").write_bytes(b"a")
    (tmp_path / "2026-04-17 B.mov").write_bytes(b"b")
    (tmp_path / "2026-04-18 C.mov").write_bytes(b"c")

    events = []
    monkeypatch.setattr(
        dp, "run_publish",
        lambda request, runtime, on_event=None: PublishResult(success=True),
    )

    dp.run_publish_directory(
        directory=tmp_path,
        runtime=RuntimeOptions(infuse_target="nas:/i", archive_target="nas:/a"),
        on_event=events.append,
    )

    settings_events = [
        e for e in events if e.stage_id == FamilienfilmStage.DIRECTORY_SETTINGS_RESOLVED
    ]
    assert len(settings_events) == 1


def test_recursive_scan_skips_fcpxmld_package(tmp_path: Path):
    """.fcpxmld-Packages (FCP XML Bundles) sind technisch Directories, aber
    semantisch undurchsichtige Blobs — rekursiver Scan darf nicht hineinlaufen."""
    pkg = tmp_path / "2026-04-16 Projekt.fcpxmld"
    pkg.mkdir()
    # Innerhalb des Packages liegt ein Video mit Datumspräfix, das fälschlich
    # als eigener Kandidat aufgenommen würde.
    (pkg / "2026-04-10 Cached.mov").touch()
    # Regulärer Kandidat daneben
    (tmp_path / "2026-04-16 Echt.mov").touch()

    result, _ = _scan_directory(tmp_path, recursive=True)
    assert [p.name for p in result] == ["2026-04-16 Echt.mov"]


def test_recursive_scan_skips_lfpackage(tmp_path: Path):
    """LumaFusion-Projekte (.lfpackage) sind ebenfalls Package-Dirs."""
    pkg = tmp_path / "Projekt.lfpackage"
    pkg.mkdir()
    (pkg / "2026-04-10 Cached.mov").touch()

    result, _ = _scan_directory(tmp_path, recursive=True)
    assert result == []


def test_recursive_scan_skips_nested_package_dir(tmp_path: Path):
    """Package-Dir kann auch mehrere Ebenen tief liegen (Videoschnittprojekte/X.fcpxmld/)."""
    sub = tmp_path / "Videoschnittprojekte"
    sub.mkdir()
    pkg = sub / "2026-04-16 Projekt.fcpxmld"
    pkg.mkdir()
    (pkg / "2026-04-10 Cached.mov").touch()
    # Reguläre Datei im gleichen Unterverzeichnis wird weiterhin erfasst
    (sub / "2026-04-15 Regulär.mov").touch()

    result, _ = _scan_directory(tmp_path, recursive=True)
    assert [p.name for p in result] == ["2026-04-15 Regulär.mov"]


# ── _is_already_published: Skip-Logik ──


def test_not_published_no_sidecar(tmp_path: Path):
    """Ohne Sidecar → noch nicht publiziert."""
    f = tmp_path / "2026-04-16 Test.mov"
    f.touch()
    skip, ts = _is_already_published(f)
    assert skip is False
    assert ts is None


def test_not_published_no_published_at(tmp_path: Path):
    """Sidecar ohne published_at → noch nicht publiziert."""
    f = tmp_path / "2026-04-16 Test.mov"
    f.touch()
    write_sidecar(f, SidecarSettings(web_id="a3xk9mn2pqrw"))
    skip, ts = _is_already_published(f)
    assert skip is False


def test_already_published_unchanged(tmp_path: Path):
    """Sidecar mit published_at + matchendem Fingerprint → skip."""
    f = tmp_path / "2026-04-16 Test.mov"
    f.write_bytes(b"video-bytes-v1")
    _write_published_sidecar(f)

    skip, ts = _is_already_published(f)
    assert skip is True
    assert ts is not None


def test_video_content_changed(tmp_path: Path):
    """Video-Inhalt (Bytes/Size) wurde geändert → republish."""
    f = tmp_path / "2026-04-16 Test.mov"
    f.write_bytes(b"video-bytes-v1")
    _write_published_sidecar(f)

    # Inhalt ändern (unterschiedliche Size)
    f.write_bytes(b"video-bytes-v2-different-length")

    skip, ts = _is_already_published(f)
    assert skip is False


def test_video_head_changed_same_size(tmp_path: Path):
    """Video-Kopf wurde geändert, Size identisch → republish (Hash erkennt Unterschied)."""
    f = tmp_path / "2026-04-16 Test.mov"
    original = b"ORIGINAL-HEAD-content-padding"
    f.write_bytes(original)
    _write_published_sidecar(f)

    # Gleiche Länge, anderer Inhalt am Kopf
    modified = b"MODIFIED-HEAD-content-padding"
    assert len(modified) == len(original)
    f.write_bytes(modified)

    skip, ts = _is_already_published(f)
    assert skip is False


def test_mtime_change_does_not_trigger_republish(tmp_path: Path):
    """Nur mtime ändert sich (z.B. Spotlight, SMB-Resync), Inhalt identisch → skip bleibt."""
    import os as _os

    f = tmp_path / "2026-04-16 Test.mov"
    f.write_bytes(b"video-bytes-v1")
    _write_published_sidecar(f)

    # mtime in die Zukunft setzen (simuliert externe Timestamp-Veränderung)
    future_ts = datetime.now().timestamp() + 3600
    _os.utime(f, (future_ts, future_ts))

    skip, ts = _is_already_published(f)
    assert skip is True, "mtime-Änderung darf keinen Republish auslösen, wenn Inhalt gleich ist"


def test_legacy_sidecar_without_fingerprint(tmp_path: Path):
    """Altes Sidecar ohne Fingerprint (aus ≤ 0.5.0) → einmaliger Republish."""
    f = tmp_path / "2026-04-16 Test.mov"
    f.write_bytes(b"video-bytes-v1")
    # Sidecar wie vor 0.6.0: nur web_published_at, kein source_size/head
    write_sidecar(f, SidecarSettings(
        web_id="a3xk9mn2pqrw",
        web_published_at=datetime.now().isoformat(timespec="seconds"),
    ))

    skip, ts = _is_already_published(f)
    assert skip is False, "Legacy-Sidecars ohne Fingerprint sollen einmalig republizieren"
    assert ts is not None


def test_legacy_sidecar_only_web_channel_triggers_republish(tmp_path: Path):
    """Sidecar aus ≤ 0.6.0-RC (nur [web].published_at, kein [local]/[archive])
    → einmaliger voller Republish, der alle drei Kanäle füllt."""
    from familienfilm_manager.core.sidecar_manager import compute_source_fingerprint

    f = tmp_path / "2026-04-16 Test.mov"
    f.write_bytes(b"x")
    size, head = compute_source_fingerprint(f)

    write_sidecar(f, SidecarSettings(
        web_id="a3xk9mn2pqrw",
        web_published_at=datetime.now().isoformat(timespec="seconds"),
        source_size_bytes=size,
        source_head_sha1=head,
        # Kein local_published_at, kein archive_published_at → Legacy
    ))

    skip, ts = _is_already_published(f)
    assert skip is False
    assert ts is not None, "Alter web-Zeitstempel wird zurückgemeldet (für Info)"


def test_skip_only_when_all_channels_published(tmp_path: Path):
    """Skip greift nur wenn alle drei Kanäle published_at haben."""
    f = tmp_path / "2026-04-16 Test.mov"
    f.write_bytes(b"x")

    # Nur Web + Local, kein Archive → kein Skip
    _write_published_sidecar(f, archive_published_at=None)
    skip, _ = _is_already_published(f)
    assert skip is False

    # Alle drei → Skip
    _write_published_sidecar(f)
    skip, _ = _is_already_published(f)
    assert skip is True


def test_skip_respects_inactive_channels(tmp_path: Path):
    """Wenn ein Kanal deaktiviert ist (skip_*), wird sein published_at nicht verlangt."""
    f = tmp_path / "2026-04-16 Test.mov"
    f.write_bytes(b"x")

    # Nur web und local publiziert, archive fehlt
    _write_published_sidecar(f, archive_published_at=None)

    # Default: archive required → kein Skip
    skip, _ = _is_already_published(f)
    assert skip is False

    # Mit skip_archive: archive nicht required → Skip greift
    skip, _ = _is_already_published(f, requires_archive=False)
    assert skip is True


def test_skip_honors_sidecar_web_enabled_false(tmp_path: Path):
    """Sidecar ``[web].enabled = false`` → Web zählt nicht mehr als aktiver
    Kanal, auch wenn der Caller ``requires_web=True`` übergibt."""
    f = tmp_path / "2026-04-16 Test.mov"
    f.write_bytes(b"x")

    size, head = compute_source_fingerprint(f)
    now_iso = datetime.now().isoformat(timespec="seconds")
    write_sidecar(f, SidecarSettings(
        web_enabled=False,  # explizit Web deaktiviert (Opt-in nicht gesetzt)
        local_published_at=now_iso,
        local_source_size_bytes=size,
        local_source_head_sha1=head,
        archive_published_at=now_iso,
        archive_source_size_bytes=size,
        archive_source_head_sha1=head,
    ))

    # Caller fragt requires_web=True, aber Sidecar überstimmt → Skip
    skip, _ = _is_already_published(f)
    assert skip is True


def test_per_channel_fingerprint_only_stale_channel_republishes(tmp_path: Path):
    """v0.8.0 PR2: Wenn nur der Fingerprint eines Kanals veraltet ist
    (weil dieser Kanal beim letzten Lauf versagt hat und die Quelle
    seitdem geändert wurde), soll NUR dieser Kanal als „needs republish"
    zurückkommen. Die anderen mit passendem Fingerprint bleiben Skip-Kandidaten."""
    from familienfilm_manager.core.sidecar_manager import (
        SidecarSettings,
        channel_needs_publish,
        compute_source_fingerprint,
        write_sidecar,
    )

    f = tmp_path / "2026-04-16 Test.mov"
    f.write_bytes(b"video-bytes-v2")
    current_size, current_head = compute_source_fingerprint(f)

    # Alter Fingerprint für web+archive (matched nicht mehr mit v2),
    # aktueller Fingerprint für local (matched).
    write_sidecar(f, SidecarSettings(
        web_published_at="2026-04-15T10:00:00",
        web_source_size_bytes=999,  # veraltet
        web_source_head_sha1="oldhash",
        local_published_at="2026-04-15T10:01:00",
        local_source_size_bytes=current_size,
        local_source_head_sha1=current_head,
        archive_published_at="2026-04-15T10:02:00",
        archive_source_size_bytes=999,  # veraltet
        archive_source_head_sha1="oldhash",
    ))

    from familienfilm_manager.core.sidecar_manager import read_sidecar
    sidecar = read_sidecar(f)
    fp = (current_size, current_head)

    assert channel_needs_publish(sidecar, "web", active=True, current_fingerprint=fp) is True
    assert channel_needs_publish(sidecar, "local", active=True, current_fingerprint=fp) is False
    assert channel_needs_publish(sidecar, "archive", active=True, current_fingerprint=fp) is True


def test_channel_needs_publish_inactive_is_false(tmp_path: Path):
    """Inaktive Kanäle triggern nie einen Republish."""
    from familienfilm_manager.core.sidecar_manager import (
        SidecarSettings,
        channel_needs_publish,
    )

    sidecar = SidecarSettings()  # leer, gar nichts publiziert
    # Inaktiv → False, auch ohne published_at
    assert channel_needs_publish(sidecar, "web", active=False, current_fingerprint=(100, "x")) is False


def test_channel_needs_publish_legacy_global_fingerprint_fallback(tmp_path: Path):
    """Sidecar aus ≤ v0.7.0 mit globalem [source]-Block: alle Kanäle matchen
    den Legacy-Fingerprint → kein Republish nötig."""
    from familienfilm_manager.core.sidecar_manager import (
        SidecarSettings,
        channel_needs_publish,
    )

    sidecar = SidecarSettings(
        web_published_at="2026-04-15T10:00:00",
        local_published_at="2026-04-15T10:01:00",
        archive_published_at="2026-04-15T10:02:00",
        source_size_bytes=42,
        source_head_sha1="ab12",
    )
    fp = (42, "ab12")
    assert channel_needs_publish(sidecar, "web", active=True, current_fingerprint=fp) is False
    assert channel_needs_publish(sidecar, "local", active=True, current_fingerprint=fp) is False
    assert channel_needs_publish(sidecar, "archive", active=True, current_fingerprint=fp) is False


def test_partial_failure_leads_to_republish(tmp_path: Path):
    """Teilerfolg (Web ok, Local fehlgeschlagen) → beim nächsten Lauf Republish."""
    from familienfilm_manager.core.sidecar_manager import compute_source_fingerprint

    f = tmp_path / "2026-04-16 Test.mov"
    f.write_bytes(b"x")
    size, head = compute_source_fingerprint(f)

    # Simuliere Zustand nach Partial Failure
    write_sidecar(f, SidecarSettings(
        web_id="a3xk9mn2pqrw",
        web_published_at=datetime.now().isoformat(timespec="seconds"),
        # local_published_at FEHLT (Deploy fehlgeschlagen)
        archive_published_at=datetime.now().isoformat(timespec="seconds"),
        source_size_bytes=size,
        source_head_sha1=head,
    ))

    skip, _ = _is_already_published(f)
    assert skip is False, "Partial failure (local fehlt) muss Republish triggern"


# ── _filter_stable_videos ──


def test_stability_filter_disabled_when_window_zero(tmp_path: Path):
    """Bei stability_window_seconds=0 werden alle Kandidaten sofort durchgereicht."""
    a = tmp_path / "2026-04-16 A.mov"
    a.write_bytes(b"x" * 100)
    b = tmp_path / "2026-04-17 B.mov"
    b.write_bytes(b"y" * 200)

    stable, unstable = _filter_stable_videos([a, b], stability_window_seconds=0, on_event=None)
    assert stable == [a, b]
    assert unstable == []


def test_stability_filter_detects_growing_file(tmp_path: Path, monkeypatch):
    """Eine Datei, die zwischen den beiden Messungen wächst, landet in 'unstable'."""
    import familienfilm_manager.core.directory_publisher as dp

    stable_file = tmp_path / "2026-04-16 Stable.mov"
    stable_file.write_bytes(b"x" * 100)

    growing_file = tmp_path / "2026-04-17 Growing.mov"
    growing_file.write_bytes(b"y" * 100)

    def fake_sleep(_seconds: int) -> None:
        # Simuliere, dass während der Wartezeit der Export weitergeschrieben wird.
        growing_file.write_bytes(b"y" * 500)

    monkeypatch.setattr(dp.time, "sleep", fake_sleep)

    stable, unstable = _filter_stable_videos(
        [stable_file, growing_file], stability_window_seconds=60, on_event=None,
    )
    assert stable == [stable_file]
    assert unstable == [growing_file]


def test_stability_filter_handles_empty_list(tmp_path: Path):
    """Leere Kandidatenliste triggert keinen Sleep und kein OS-Aufruf."""
    stable, unstable = _filter_stable_videos([], stability_window_seconds=60, on_event=None)
    assert stable == []
    assert unstable == []


# ── _filter_stable_remote_videos (v0.8.0 PR3) ──


def test_stability_filter_rclone_disabled_when_window_zero(monkeypatch):
    """Bei stability_window_seconds=0 wird kein lsjson-Call gemacht."""
    import familienfilm_manager.core.directory_publisher as dp
    from familienfilm_manager.core.remote_scanner import RemoteVideoRef

    called = {"count": 0}

    def fake_lsjson(*args, **kwargs):
        called["count"] += 1
        return []

    monkeypatch.setattr(
        "familienfilm_manager.core._rclone.rclone_lsjson", fake_lsjson,
    )

    candidates = [
        RemoteVideoRef(uri="nas:/q/2026-04-16 A.mov", name="2026-04-16 A.mov", size_bytes=100),
    ]
    stable, unstable = dp._filter_stable_remote_videos(
        candidates, stability_window_seconds=0, rclone_path="rclone", on_event=None,
    )
    assert stable == candidates
    assert unstable == []
    assert called["count"] == 0


def test_stability_filter_rclone_detects_growing_file(monkeypatch):
    """Ein Video, dessen Size zwischen den beiden lsjson-Snapshots wächst,
    wird als unstable ausgefiltert. Ein zweites Video mit gleicher Size
    bleibt stabil."""
    import familienfilm_manager.core.directory_publisher as dp
    from familienfilm_manager.core.remote_scanner import RemoteVideoRef

    # Zwei Kandidaten aus dem gleichen Parent-Verzeichnis
    candidates = [
        RemoteVideoRef(uri="nas:/q/2026-04-16 Stable.mov", name="2026-04-16 Stable.mov", size_bytes=100),
        RemoteVideoRef(uri="nas:/q/2026-04-17 Growing.mov", name="2026-04-17 Growing.mov", size_bytes=100),
    ]

    # Vor Sleep: beide bei Size 100
    snapshot_before = [
        {"Name": "2026-04-16 Stable.mov", "Size": 100, "ModTime": "2026-04-18T10:00:00Z", "IsDir": False},
        {"Name": "2026-04-17 Growing.mov", "Size": 100, "ModTime": "2026-04-18T10:00:00Z", "IsDir": False},
    ]
    # Nach Sleep: Growing hat Size 500 (und neue ModTime)
    snapshot_after = [
        {"Name": "2026-04-16 Stable.mov", "Size": 100, "ModTime": "2026-04-18T10:00:00Z", "IsDir": False},
        {"Name": "2026-04-17 Growing.mov", "Size": 500, "ModTime": "2026-04-18T10:00:05Z", "IsDir": False},
    ]

    call_count = {"n": 0}

    def fake_lsjson(uri, *, recursive=False, rclone_path="rclone", **kwargs):
        call_count["n"] += 1
        return snapshot_before if call_count["n"] == 1 else snapshot_after

    monkeypatch.setattr(
        "familienfilm_manager.core._rclone.rclone_lsjson", fake_lsjson,
    )
    monkeypatch.setattr(dp.time, "sleep", lambda _s: None)

    stable, unstable = dp._filter_stable_remote_videos(
        candidates, stability_window_seconds=60, rclone_path="rclone", on_event=None,
    )
    assert [r.name for r in stable] == ["2026-04-16 Stable.mov"]
    assert [r.name for r in unstable] == ["2026-04-17 Growing.mov"]
    # Genau 2 lsjson-Calls: einer vor, einer nach dem Sleep (Bündel-Cache).
    assert call_count["n"] == 2


def test_stability_filter_rclone_bundles_lsjson_per_parent(monkeypatch):
    """Bei N Videos aus dem gleichen Parent-Verzeichnis wird nur 1 lsjson
    pro Snapshot aufgerufen (nicht N)."""
    import familienfilm_manager.core.directory_publisher as dp
    from familienfilm_manager.core.remote_scanner import RemoteVideoRef

    candidates = [
        RemoteVideoRef(uri=f"nas:/q/2026-04-{d} T.mov", name=f"2026-04-{d} T.mov", size_bytes=100)
        for d in ("16", "17", "18")
    ]
    entries = [
        {"Name": f"2026-04-{d} T.mov", "Size": 100, "ModTime": "t", "IsDir": False}
        for d in ("16", "17", "18")
    ]

    call_count = {"n": 0}

    def fake_lsjson(uri, *, recursive=False, rclone_path="rclone", **kwargs):
        call_count["n"] += 1
        return entries

    monkeypatch.setattr(
        "familienfilm_manager.core._rclone.rclone_lsjson", fake_lsjson,
    )
    monkeypatch.setattr(dp.time, "sleep", lambda _s: None)

    stable, unstable = dp._filter_stable_remote_videos(
        candidates, stability_window_seconds=30, rclone_path="rclone", on_event=None,
    )
    assert len(stable) == 3
    assert unstable == []
    # 1 Parent × 2 Snapshots = 2 lsjson-Aufrufe, nicht 6.
    assert call_count["n"] == 2


def test_stability_filter_rclone_disappeared_file_treated_unstable(monkeypatch):
    """Wenn ein Video im zweiten Snapshot fehlt (z.B. verschoben),
    wird es als unstable markiert — beim nächsten Tick neu entschieden."""
    import familienfilm_manager.core.directory_publisher as dp
    from familienfilm_manager.core.remote_scanner import RemoteVideoRef

    candidates = [
        RemoteVideoRef(uri="nas:/q/2026-04-16 Gone.mov", name="2026-04-16 Gone.mov", size_bytes=100),
    ]
    snapshot_before = [
        {"Name": "2026-04-16 Gone.mov", "Size": 100, "ModTime": "t", "IsDir": False},
    ]
    snapshot_after: list[dict] = []  # Datei weg

    call_count = {"n": 0}

    def fake_lsjson(*args, **kwargs):
        call_count["n"] += 1
        return snapshot_before if call_count["n"] == 1 else snapshot_after

    monkeypatch.setattr(
        "familienfilm_manager.core._rclone.rclone_lsjson", fake_lsjson,
    )
    monkeypatch.setattr(dp.time, "sleep", lambda _s: None)

    stable, unstable = dp._filter_stable_remote_videos(
        candidates, stability_window_seconds=30, rclone_path="rclone", on_event=None,
    )
    assert stable == []
    assert len(unstable) == 1


# ── category wird in PublishRequest durchgereicht ──


def test_category_is_passed_through_to_run_publish(tmp_path: Path, monkeypatch):
    """run_publish_directory gibt die Kategorie an jeden PublishRequest weiter."""
    import familienfilm_manager.core.directory_publisher as dp
    from familienfilm_manager.api.models import (
        PublishResult,
        RuntimeOptions,
    )

    video = tmp_path / "2026-04-16 Test.mov"
    video.write_bytes(b"x")

    captured: list[str | None] = []

    def fake_run_publish(request, runtime, on_event=None):  # noqa: ARG001
        captured.append(request.category)
        return PublishResult(success=True)

    monkeypatch.setattr(dp, "run_publish", fake_run_publish)

    runtime = RuntimeOptions(
        infuse_target="nas:/i", web_target="nas:/w", archive_target="nas:/a",
    )

    dp.run_publish_directory(
        directory=tmp_path,
        runtime=runtime,
        category="Familie Kurmann-Glück",
    )

    assert captured == ["Familie Kurmann-Glück"]


def test_directory_web_default_off_skips_correctly(tmp_path: Path, monkeypatch):
    """Web ist per Default aus. Ohne ``web_enabled = true`` in
    ``familienfilm.toml`` oder Sidecar gelten Videos mit ``local`` +
    ``archive`` ``published_at`` als voll publiziert — kein Web-Deploy,
    kein ``web_published_at`` nötig. Kein ``web_target`` in RuntimeOptions
    darf nicht stören (Web ist ja nicht aktiviert)."""
    import familienfilm_manager.core.directory_publisher as dp
    from familienfilm_manager.api.models import PublishResult, RuntimeOptions

    # Keine familienfilm.toml — Default ist Web aus

    video = tmp_path / "2026-04-16 Test.mov"
    video.write_bytes(b"x")

    # Sidecar mit local + archive (kein web), per-Kanal-Fingerprint
    size, head = compute_source_fingerprint(video)
    now_iso = datetime.now().isoformat(timespec="seconds")
    write_sidecar(video, SidecarSettings(
        local_published_at=now_iso,
        local_source_size_bytes=size,
        local_source_head_sha1=head,
        archive_published_at=now_iso,
        archive_source_size_bytes=size,
        archive_source_head_sha1=head,
    ))

    captured: list = []

    def fake_run_publish(request, runtime, on_event=None):  # noqa: ARG001
        captured.append(request)
        return PublishResult(success=True)

    monkeypatch.setattr(dp, "run_publish", fake_run_publish)

    runtime = RuntimeOptions(
        infuse_target="nas:/i", archive_target="nas:/a",
        # Kein web_target — irrelevant, weil Web per Default aus
    )

    result = dp.run_publish_directory(
        directory=tmp_path,
        runtime=runtime,
    )

    assert captured == []
    assert len(result.videos) == 1
    assert result.videos[0].kind.name == "SKIPPED"


def test_directory_web_enabled_requires_web_timestamp(tmp_path: Path, monkeypatch):
    """Mit ``web_enabled = true`` in ``familienfilm.toml`` muss auch
    ``web_published_at`` im Sidecar existieren, sonst Republish."""
    import familienfilm_manager.core.directory_publisher as dp
    from familienfilm_manager.api.models import PublishResult, RuntimeOptions

    (tmp_path / "familienfilm.toml").write_text(
        'web_enabled = true\n', encoding="utf-8",
    )

    video = tmp_path / "2026-04-16 Test.mov"
    video.write_bytes(b"x")

    size, head = compute_source_fingerprint(video)
    now_iso = datetime.now().isoformat(timespec="seconds")
    write_sidecar(video, SidecarSettings(
        # web_published_at FEHLT — obwohl web aktiv ist
        local_published_at=now_iso,
        archive_published_at=now_iso,
        source_size_bytes=size,
        source_head_sha1=head,
    ))

    captured: list = []

    def fake_run_publish(request, runtime, on_event=None):  # noqa: ARG001
        captured.append(request)
        return PublishResult(success=True)

    monkeypatch.setattr(dp, "run_publish", fake_run_publish)

    runtime = RuntimeOptions(
        infuse_target="nas:/i", web_target="nas:/w", archive_target="nas:/a",
    )

    dp.run_publish_directory(directory=tmp_path, runtime=runtime)

    # Video wurde an run_publish übergeben — nicht übersprungen
    assert len(captured) == 1


def test_category_none_is_passed_through(tmp_path: Path, monkeypatch):
    """Ohne category gibt's None weiter (kein Magic)."""
    import familienfilm_manager.core.directory_publisher as dp
    from familienfilm_manager.api.models import PublishResult, RuntimeOptions

    video = tmp_path / "2026-04-16 Test.mov"
    video.write_bytes(b"x")

    captured: list[str | None] = []

    def fake_run_publish(request, runtime, on_event=None):  # noqa: ARG001
        captured.append(request.category)
        return PublishResult(success=True)

    monkeypatch.setattr(dp, "run_publish", fake_run_publish)

    runtime = RuntimeOptions(
        infuse_target="nas:/i", web_target="nas:/w", archive_target="nas:/a",
    )

    dp.run_publish_directory(directory=tmp_path, runtime=runtime)

    assert captured == [None]


# ── Unqualifizierte Videos werden reportet (v0.12.0) ──


def test_scan_directory_reports_unqualified_videos(tmp_path):
    """Videos mit Endung aber ohne Datums-Präfix landen in der unqualified-Liste."""
    from familienfilm_manager.core.directory_publisher import _scan_directory

    # Qualifiziert
    (tmp_path / "2026-04-18 Test.mov").write_bytes(b"x")
    # Nicht qualifiziert (kein Datum, falscher Datumsstring, führendes Leerzeichen)
    (tmp_path / "Ohne-Datum.mov").write_bytes(b"x")
    (tmp_path / " 2026-04-19 Leerzeichen.mov").write_bytes(b"x")
    (tmp_path / "2026 abgeschnittenes Datum.mov").write_bytes(b"x")
    # Andere File-Typen werden gar nicht erst betrachtet
    (tmp_path / "Readme.txt").write_text("x")

    qualified, unqualified = _scan_directory(tmp_path)
    qualified_names = sorted(p.name for p in qualified)
    unqualified_names = sorted(p.name for p in unqualified)

    assert qualified_names == ["2026-04-18 Test.mov"]
    assert unqualified_names == [
        " 2026-04-19 Leerzeichen.mov",
        "2026 abgeschnittenes Datum.mov",
        "Ohne-Datum.mov",
    ]


def test_scan_directory_no_unqualified(tmp_path):
    """Alle Videos qualifiziert → leere unqualified-Liste."""
    from familienfilm_manager.core.directory_publisher import _scan_directory
    (tmp_path / "2026-04-18 A.mov").write_bytes(b"x")
    (tmp_path / "2026-04-19 B.mov").write_bytes(b"x")
    qualified, unqualified = _scan_directory(tmp_path)
    assert len(qualified) == 2
    assert unqualified == []
