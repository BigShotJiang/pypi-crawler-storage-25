"""Tests für das Web-Storage-Budget-Modul (v0.10.0)."""

from __future__ import annotations

import json
import subprocess
from datetime import datetime, timezone
from unittest.mock import patch

import pytest

from familienfilm_manager.api.models import (
    FamilienfilmEvent,
    FamilienfilmStage,
)
from familienfilm_manager.core.web_storage import (
    SAFETY_MARGIN_PERCENT,
    WebMediaset,
    cleanup_oldest_until_fits,
    format_size,
    list_web_mediasets,
    parse_size,
)


# ── parse_size ────────────────────────────────────────────────────────


def test_parse_size_basic_units():
    assert parse_size("500GB") == 500 * 10**9
    assert parse_size("1TB") == 10**12
    assert parse_size("1.5GB") == 1_500_000_000
    assert parse_size("100MB") == 100_000_000


def test_parse_size_case_insensitive():
    assert parse_size("500gb") == parse_size("500GB")
    assert parse_size("1tb") == parse_size("1TB")
    assert parse_size("1Tb") == parse_size("1TB")


def test_parse_size_with_underscores():
    assert parse_size("500_000_000_000") == 500_000_000_000
    assert parse_size("1_000B") == 1_000


def test_parse_size_short_suffix():
    assert parse_size("500g") == 500 * 10**9
    assert parse_size("1t") == 10**12


def test_parse_size_no_unit_is_bytes():
    assert parse_size("12345") == 12345


def test_parse_size_invalid_raises():
    with pytest.raises(ValueError):
        parse_size("")
    with pytest.raises(ValueError):
        parse_size("   ")
    with pytest.raises(ValueError):
        parse_size("not a size")
    with pytest.raises(ValueError):
        parse_size("100XB")  # unbekannte Einheit


def test_format_size_human_readable():
    assert "GB" in format_size(500 * 10**9)
    assert "MB" in format_size(200 * 10**6)
    assert "B" in format_size(500)


# ── list_web_mediasets ────────────────────────────────────────────────


def _mock_lsjson(entries: list[dict]):
    """Baut einen subprocess.run-Mock, der rclone lsjson simuliert."""
    def fake(args, **kwargs):
        return subprocess.CompletedProcess(
            args=args, returncode=0, stdout=json.dumps(entries), stderr="",
        )
    return fake


def test_list_web_mediasets_aggregates_per_web_id():
    """Ein Mediaset = ein Top-Level-Verzeichnis. Files darin werden summiert,
    index.html-mtime liefert das Alter."""
    entries = [
        {"Path": "abc12345abcd/index.html", "Size": 1000,
         "ModTime": "2026-04-20T10:00:00+02:00", "IsDir": False},
        {"Path": "abc12345abcd/video.mp4", "Size": 200_000_000,
         "ModTime": "2026-04-20T09:50:00+02:00", "IsDir": False},
        {"Path": "abc12345abcd/poster.jpg", "Size": 50_000,
         "ModTime": "2026-04-20T09:55:00+02:00", "IsDir": False},
        {"Path": "xyz98765xyz0/index.html", "Size": 1100,
         "ModTime": "2026-04-24T14:30:00+02:00", "IsDir": False},
        {"Path": "xyz98765xyz0/video.mp4", "Size": 100_000_000,
         "ModTime": "2026-04-24T14:25:00+02:00", "IsDir": False},
    ]
    with patch("familienfilm_manager.core._rclone.subprocess.run",
               side_effect=_mock_lsjson(entries)):
        result = list_web_mediasets("hostpoint:")

    assert len(result) == 2
    # Sortiert: ältestes zuerst
    assert result[0].web_id == "abc12345abcd"
    assert result[1].web_id == "xyz98765xyz0"
    # Größen aggregiert
    assert result[0].size_bytes == 1000 + 200_000_000 + 50_000
    assert result[1].size_bytes == 1100 + 100_000_000
    # mtime kommt von index.html (nicht vom video.mp4 Min)
    assert result[0].index_mtime.year == 2026
    assert result[0].index_mtime.month == 4
    assert result[0].index_mtime.day == 20


def test_list_web_mediasets_falls_back_when_no_index_html():
    """Ohne index.html nehmen wir die älteste File-mtime im Verzeichnis."""
    entries = [
        {"Path": "weirdcase01ab/video.mp4", "Size": 50_000_000,
         "ModTime": "2026-04-22T10:00:00+02:00", "IsDir": False},
        {"Path": "weirdcase01ab/poster.jpg", "Size": 50_000,
         "ModTime": "2026-04-22T09:55:00+02:00", "IsDir": False},
    ]
    with patch("familienfilm_manager.core._rclone.subprocess.run",
               side_effect=_mock_lsjson(entries)):
        result = list_web_mediasets("hostpoint:")

    assert len(result) == 1
    # Älteste mtime wurde übernommen (poster.jpg um 09:55)
    assert result[0].index_mtime.minute == 55


def test_list_web_mediasets_ignores_root_files():
    """Files direkt im Root (z.B. user-eigene Datei) gehören zu keinem Mediaset."""
    entries = [
        {"Path": "README.txt", "Size": 100,
         "ModTime": "2026-01-01T00:00:00+00:00", "IsDir": False},
        {"Path": "abc12345abcd/index.html", "Size": 1000,
         "ModTime": "2026-04-20T10:00:00+02:00", "IsDir": False},
    ]
    with patch("familienfilm_manager.core._rclone.subprocess.run",
               side_effect=_mock_lsjson(entries)):
        result = list_web_mediasets("hostpoint:")

    assert [m.web_id for m in result] == ["abc12345abcd"]


def test_list_web_mediasets_empty_target():
    with patch("familienfilm_manager.core._rclone.subprocess.run",
               side_effect=_mock_lsjson([])):
        result = list_web_mediasets("hostpoint:")
    assert result == []


# ── cleanup_oldest_until_fits ─────────────────────────────────────────


def _make_entries(specs: list[tuple[str, int, str]]) -> list[dict]:
    """specs: [(web_id, size_bytes, modtime_iso)]. Erzeugt index.html-Einträge."""
    return [
        {"Path": f"{wid}/index.html", "Size": sz,
         "ModTime": mt, "IsDir": False}
        for wid, sz, mt in specs
    ]


def test_cleanup_no_action_when_budget_fits():
    """Wenn (used + new + 5%) ins Budget passt, wird nichts gelöscht."""
    entries = _make_entries([
        ("a" * 12, 100_000_000, "2026-04-20T10:00:00+02:00"),
        ("b" * 12, 100_000_000, "2026-04-22T10:00:00+02:00"),
    ])
    events: list[FamilienfilmEvent] = []
    with patch("familienfilm_manager.core._rclone.subprocess.run",
               side_effect=_mock_lsjson(entries)):
        result = cleanup_oldest_until_fits(
            "hostpoint:",
            new_mediaset_size=100_000_000,
            budget_bytes=1_000_000_000,
            on_event=events.append,
        )

    assert result == []
    # Trotzdem ein BUDGET_CHECK-Event
    assert any(e.stage_id == FamilienfilmStage.WEB_BUDGET_CHECK for e in events)
    # Kein Cleanup-Event
    assert not any(e.stage_id == FamilienfilmStage.WEB_CLEANUP_DELETED for e in events)


def test_cleanup_deletes_oldest_when_budget_tight():
    """Bei knappem Budget wird das älteste Mediaset (kleinste mtime) gelöscht."""
    entries = _make_entries([
        ("oldest000000", 400_000_000, "2026-04-20T10:00:00+02:00"),
        ("middle000000", 300_000_000, "2026-04-22T10:00:00+02:00"),
        ("newest000000", 200_000_000, "2026-04-24T10:00:00+02:00"),
    ])
    # Total used: 900 MB. Budget 1 GB, Marge 5 % = 950 MB effektiv.
    # Available: 950 - 900 = 50 MB. Neuer Upload: 200 MB → braucht 150 MB,
    # also muss mindestens das älteste (400 MB) raus → frei 450 MB > 200 MB.

    events: list[FamilienfilmEvent] = []
    purge_calls: list[list[str]] = []

    def fake_run(args, **kwargs):
        if "purge" in args:
            purge_calls.append(args)
            return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")
        return subprocess.CompletedProcess(
            args=args, returncode=0, stdout=json.dumps(entries), stderr="",
        )

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        result = cleanup_oldest_until_fits(
            "hostpoint:",
            new_mediaset_size=200_000_000,
            budget_bytes=1_000_000_000,
            on_event=events.append,
        )

    assert len(result) == 1
    assert result[0].web_id == "oldest000000"
    # purge-Aufruf erfolgte mit korrektem URI
    assert any(c == ["rclone", "purge", "hostpoint:/oldest000000"] for c in purge_calls)
    # Cleanup-Event emittiert
    deleted_events = [e for e in events
                      if e.stage_id == FamilienfilmStage.WEB_CLEANUP_DELETED]
    assert len(deleted_events) == 1
    assert "oldest000000" in deleted_events[0].message


def test_cleanup_iterates_until_enough_freed():
    """Wenn ein Cleanup nicht reicht, wird das nächst-älteste gelöscht."""
    entries = _make_entries([
        ("oldest000000", 100_000_000, "2026-04-20T10:00:00+02:00"),
        ("middle000000", 100_000_000, "2026-04-22T10:00:00+02:00"),
        ("newest000000", 100_000_000, "2026-04-24T10:00:00+02:00"),
    ])
    # used 300 MB, budget 350 MB, Marge 5 % = 332.5 effektiv. Available = 32 MB.
    # Neu 200 MB → braucht 168 MB → 2 löschen reicht.

    events: list[FamilienfilmEvent] = []
    purge_calls: list[list[str]] = []

    def fake_run(args, **kwargs):
        if "purge" in args:
            purge_calls.append(args)
            return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")
        return subprocess.CompletedProcess(
            args=args, returncode=0, stdout=json.dumps(entries), stderr="",
        )

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        result = cleanup_oldest_until_fits(
            "hostpoint:",
            new_mediaset_size=200_000_000,
            budget_bytes=350_000_000,
            on_event=events.append,
        )

    assert [m.web_id for m in result] == ["oldest000000", "middle000000"]
    assert len(purge_calls) == 2


def test_cleanup_dry_run_does_not_purge():
    entries = _make_entries([
        ("oldest000000", 400_000_000, "2026-04-20T10:00:00+02:00"),
    ])
    events: list[FamilienfilmEvent] = []
    purge_calls: list[list[str]] = []

    def fake_run(args, **kwargs):
        if "purge" in args:
            purge_calls.append(args)
            return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")
        return subprocess.CompletedProcess(
            args=args, returncode=0, stdout=json.dumps(entries), stderr="",
        )

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        result = cleanup_oldest_until_fits(
            "hostpoint:",
            new_mediaset_size=300_000_000,
            budget_bytes=500_000_000,
            dry_run=True,
            on_event=events.append,
        )

    assert len(result) == 1
    assert purge_calls == []  # nichts tatsächlich gelöscht
    assert any(e.stage_id == FamilienfilmStage.WEB_CLEANUP_DRY_RUN for e in events)


def test_cleanup_emits_budget_exceeded_when_mediaset_too_big():
    """Pathologischer Fall: neues Mediaset alleine grösser als Budget."""
    entries = _make_entries([
        ("oldest000000", 100_000_000, "2026-04-20T10:00:00+02:00"),
    ])
    events: list[FamilienfilmEvent] = []

    def fake_run(args, **kwargs):
        if "purge" in args:
            return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")
        return subprocess.CompletedProcess(
            args=args, returncode=0, stdout=json.dumps(entries), stderr="",
        )

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        cleanup_oldest_until_fits(
            "hostpoint:",
            new_mediaset_size=2_000_000_000,  # 2 GB
            budget_bytes=500_000_000,         # 500 MB Budget
            on_event=events.append,
        )

    assert any(e.stage_id == FamilienfilmStage.WEB_BUDGET_EXCEEDED for e in events)


def test_cleanup_uses_5_percent_safety_margin():
    """Marge wird bei der Berechnung angewendet, nicht nur in der Meldung."""
    # Budget 100, used 90, neu 5 → ohne Marge passt's (95). Mit 5%-Marge:
    # effective = 95, available = 5, neu 5 → braucht 0 → kein Cleanup. Edge.
    # Setze neu 6 → braucht 1 → Cleanup.
    entries = _make_entries([
        ("oldest000000", 90, "2026-04-20T10:00:00+02:00"),
    ])
    events: list[FamilienfilmEvent] = []
    purge_calls: list[list[str]] = []

    def fake_run(args, **kwargs):
        if "purge" in args:
            purge_calls.append(args)
            return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")
        return subprocess.CompletedProcess(
            args=args, returncode=0, stdout=json.dumps(entries), stderr="",
        )

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        cleanup_oldest_until_fits(
            "hostpoint:",
            new_mediaset_size=6,
            budget_bytes=100,
            on_event=events.append,
        )

    # Marge=5%: effective=95, available=5, neu=6 > 5 → muss löschen
    assert len(purge_calls) == 1


def test_safety_margin_constant_is_documented_5_percent():
    """Sanity-Test gegen versehentliche Änderung des hartcodierten Werts."""
    assert SAFETY_MARGIN_PERCENT == 5


# ── cleanup_aged_mediasets (v0.10.0) ──────────────────────────────────


from datetime import datetime, timezone
from familienfilm_manager.core.web_storage import cleanup_aged_mediasets


def _iso_n_days_ago(n: int, anchor: datetime) -> str:
    """Hilfsfunktion: ISO-mtime n Tage vor anchor."""
    from datetime import timedelta
    return (anchor - timedelta(days=n)).isoformat()


def test_cleanup_aged_deletes_only_older_than_threshold():
    """Nur Mediasets älter als max_age_days werden gelöscht."""
    now = datetime(2026, 5, 1, 12, 0, 0, tzinfo=timezone.utc)
    entries = _make_entries([
        ("ancient00000", 100, _iso_n_days_ago(400, now)),
        ("oldenough000", 100, _iso_n_days_ago(370, now)),
        ("borderline00", 100, _iso_n_days_ago(366, now)),
        ("recent000000", 100, _iso_n_days_ago(30, now)),
        ("brandnew0000", 100, _iso_n_days_ago(1, now)),
    ])
    purge_calls: list[list[str]] = []
    events: list[FamilienfilmEvent] = []

    def fake_run(args, **kwargs):
        if "purge" in args:
            purge_calls.append(args)
            return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")
        return subprocess.CompletedProcess(
            args=args, returncode=0, stdout=json.dumps(entries), stderr="",
        )

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        result = cleanup_aged_mediasets(
            "hostpoint:",
            max_age_days=365,
            on_event=events.append,
            _now=now,
        )

    deleted_ids = {m.web_id for m in result}
    # 400 + 370 + 366 sind älter als 365 — alle drei raus.
    assert deleted_ids == {"ancient00000", "oldenough000", "borderline00"}
    # purge wurde 3x aufgerufen
    assert len(purge_calls) == 3


def test_cleanup_aged_zero_or_negative_disables():
    """max_age_days <= 0 deaktiviert die Prüfung komplett (kein lsjson-Aufruf)."""
    with patch("familienfilm_manager.core._rclone.subprocess.run") as run_mock:
        result = cleanup_aged_mediasets("hostpoint:", max_age_days=0)
    assert result == []
    run_mock.assert_not_called()


def test_cleanup_aged_dry_run_does_not_purge():
    now = datetime(2026, 5, 1, tzinfo=timezone.utc)
    entries = _make_entries([
        ("ancient00000", 100, _iso_n_days_ago(400, now)),
    ])
    purge_calls: list[list[str]] = []
    events: list[FamilienfilmEvent] = []

    def fake_run(args, **kwargs):
        if "purge" in args:
            purge_calls.append(args)
            return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")
        return subprocess.CompletedProcess(
            args=args, returncode=0, stdout=json.dumps(entries), stderr="",
        )

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        result = cleanup_aged_mediasets(
            "hostpoint:", max_age_days=365,
            dry_run=True, on_event=events.append, _now=now,
        )

    assert len(result) == 1
    assert purge_calls == []  # nichts tatsächlich gelöscht
    assert any(e.stage_id == FamilienfilmStage.WEB_CLEANUP_DRY_RUN for e in events)


def test_cleanup_aged_emits_messages_with_age():
    """Event-Message enthält das tatsächliche Alter in Tagen."""
    now = datetime(2026, 5, 1, tzinfo=timezone.utc)
    entries = _make_entries([
        ("oldenough000", 100, _iso_n_days_ago(380, now)),
    ])
    events: list[FamilienfilmEvent] = []

    def fake_run(args, **kwargs):
        if "purge" in args:
            return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")
        return subprocess.CompletedProcess(
            args=args, returncode=0, stdout=json.dumps(entries), stderr="",
        )

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        cleanup_aged_mediasets("hostpoint:", max_age_days=365,
                               on_event=events.append, _now=now)

    deleted_msgs = [e.message for e in events
                    if e.stage_id == FamilienfilmStage.WEB_CLEANUP_DELETED]
    assert any("380 Tage" in m for m in deleted_msgs)
    assert any("max 365" in m for m in deleted_msgs)


def test_cleanup_aged_empty_target():
    """Leeres Target: leere Liste, kein Crash."""
    with patch("familienfilm_manager.core._rclone.subprocess.run",
               side_effect=_mock_lsjson([])):
        result = cleanup_aged_mediasets("hostpoint:", max_age_days=365)
    assert result == []
