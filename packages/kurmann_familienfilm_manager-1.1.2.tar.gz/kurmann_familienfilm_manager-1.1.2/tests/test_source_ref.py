"""Tests für die URI-Abstraktion (lokale Pfade vs. rclone-Remotes)."""

from pathlib import Path

import pytest

from familienfilm_manager.core.source_ref import SourceRef, _looks_like_rclone_uri


# ── URI-Detection ──


@pytest.mark.parametrize("uri,expected", [
    # rclone
    ("lyssach-nas:/Archiv/foo.mov", True),
    ("myremote:", True),
    ("myremote:/", True),
    ("gdrive:Videos/2026/", True),
    ("remote_with_underscore:path", True),
    ("remote-with-dash:path", True),
    # lokal — absolute Pfade
    ("/Users/me/Movies/foo.mov", False),
    ("/tmp/foo", False),
    # lokal — relative Pfade
    ("./relativ/foo.mov", False),
    ("foo.mov", False),
    ("subdir/foo.mov", False),
    # Windows-Laufwerksbuchstabe — bei uns macOS, aber defensiv gelesen als lokal
    ("C:/Users/test", True),   # Leider: "C:" matcht _RCLONE_REMOTE_RE{2,} nicht — genauer Blick nötig
    # Edge cases
    ("", False),
    (":foo", False),           # nur Doppelpunkt, kein Remote-Name
])
def test_looks_like_rclone_uri(uri: str, expected: bool):
    # Hinweis: "C:" = 1 Zeichen vor ':' → matcht _RCLONE_REMOTE_RE{2,} nicht,
    # ergibt False. Der Parametrize-Eintrag oben ist falsch. Fix:
    actual = _looks_like_rclone_uri(uri)
    if uri == "C:/Users/test":
        # Windows-Laufwerk: 1-char-Prefix, regex verlangt {2,} → False erwartet
        assert actual is False
    else:
        assert actual is expected


# ── SourceRef.is_rclone ──


def test_is_rclone_true_for_remote_uri():
    assert SourceRef("nas:/foo.mov").is_rclone is True


def test_is_rclone_false_for_local_path():
    assert SourceRef("/Users/x/foo.mov").is_rclone is False


# ── SourceRef.name / stem / suffix ──


@pytest.mark.parametrize("uri,name,stem,suffix", [
    ("/Users/x/2026-04-18 Test.mov", "2026-04-18 Test.mov", "2026-04-18 Test", ".mov"),
    ("foo.settings.toml", "foo.settings.toml", "foo.settings", ".toml"),
    ("nas:/Quelle/2026-04-18 Test.mov", "2026-04-18 Test.mov", "2026-04-18 Test", ".mov"),
    ("nas:video.mp4", "video.mp4", "video", ".mp4"),
    ("nas:", "", "", ""),
    ("nas:/", "", "", ""),
    ("nofile", "nofile", "nofile", ""),
    (".hidden", ".hidden", ".hidden", ""),
])
def test_name_stem_suffix(uri: str, name: str, stem: str, suffix: str):
    ref = SourceRef(uri)
    assert ref.name == name
    assert ref.stem == stem
    assert ref.suffix == suffix


# ── parent_uri ──


@pytest.mark.parametrize("uri,expected_parent", [
    # Lokale Pfade — Verhalten wie Path.parent
    ("/a/b/c.mov", "/a/b"),
    ("/a/b", "/a"),
    ("/a", "/"),
    # rclone — Pfad-Teil wird um letztes Segment gekürzt
    ("nas:/a/b/c.mov", "nas:/a/b"),
    ("nas:/a/b", "nas:/a"),
    ("nas:/a", "nas:"),
    ("nas:a", "nas:"),
    ("nas:", "nas:"),  # Root — kein weiteres Aufsteigen
])
def test_parent_uri(uri: str, expected_parent: str):
    assert SourceRef(uri).parent_uri() == expected_parent


# ── child_uri ──


@pytest.mark.parametrize("uri,child,expected", [
    ("/a/b", "c.mov", "/a/b/c.mov"),
    ("nas:/a/b", "c.mov", "nas:/a/b/c.mov"),
    ("nas:/a/b/", "c.mov", "nas:/a/b/c.mov"),   # trailing slash trimmed
    ("nas:", "c.mov", "nas:c.mov"),
    ("nas:/", "c.mov", "nas:/c.mov"),
])
def test_child_uri(uri: str, child: str, expected: str):
    assert SourceRef(uri).child_uri(child) == expected


# ── as_local_path ──


def test_as_local_path_returns_path_for_local():
    assert SourceRef("/Users/x/foo.mov").as_local_path() == Path("/Users/x/foo.mov")


def test_as_local_path_raises_for_rclone():
    with pytest.raises(ValueError, match="rclone-Remote"):
        SourceRef("nas:/foo.mov").as_local_path()


# ── is_root ──


@pytest.mark.parametrize("uri,expected_root", [
    ("nas:", True),
    ("nas:/", True),
    ("nas:a", False),
    ("nas:/a/b", False),
    ("/", True),
    ("/a", False),
    ("/a/b", False),
])
def test_is_root(uri: str, expected_root: bool):
    assert SourceRef(uri).is_root() is expected_root


def test_str_returns_uri():
    assert str(SourceRef("nas:/a/b")) == "nas:/a/b"


def test_source_ref_is_hashable_and_frozen():
    """dataclass(frozen=True) → kann als Dict-Key / Set-Member verwendet werden."""
    s = {SourceRef("nas:/a"), SourceRef("nas:/a"), SourceRef("nas:/b")}
    assert len(s) == 2


def test_source_ref_normalizes_nfd_to_nfc():
    """macOS-Terminals liefern Umlaute oft in NFD; SFTP-Remotes erwarten NFC.
    SourceRef normalisiert beim Init, damit rclone-Aufrufe funktionieren."""
    import unicodedata
    from familienfilm_manager.core.source_ref import SourceRef

    nfc = "remote:/Familie Glück/foo.mov"
    nfd = unicodedata.normalize("NFD", nfc)
    assert nfc != nfd  # Sanity: tatsächlich verschieden

    ref = SourceRef(nfd)
    assert ref.uri == nfc
    # NFC-Form überlebt auch andere Properties
    assert "Glück" in ref.parent_uri()


def test_source_ref_nfc_input_unchanged():
    """NFC-Input bleibt NFC — kein zusätzliches Normalisieren nötig."""
    from familienfilm_manager.core.source_ref import SourceRef
    nfc = "remote:/foo.mov"
    ref = SourceRef(nfc)
    assert ref.uri == nfc


def test_source_ref_empty_uri_does_not_crash():
    from familienfilm_manager.core.source_ref import SourceRef
    ref = SourceRef("")
    assert ref.uri == ""


def test_rclone_remote_with_dot_in_name():
    """v0.11.1: Remote-Namen mit Punkt (z.B. mega.nz, hostpoint.com) müssen
    als rclone-URI erkannt werden — sind in rclone config legal vergeben."""
    from familienfilm_manager.core.source_ref import (
        SourceRef,
        _looks_like_rclone_uri,
    )
    assert _looks_like_rclone_uri("mega.nz:Videoschnitt") is True
    assert _looks_like_rclone_uri("mega.nz:") is True
    assert _looks_like_rclone_uri("hostpoint.com:public") is True
    assert SourceRef("mega.nz:Videoschnitt").is_rclone is True
    # Sanity: der bestehende Bindestrich-Variante bleibt funktional
    assert _looks_like_rclone_uri("lyssach-nas:/Archiv") is True
    # Lokale Pfade mit Punkt im Dateinamen werden NICHT zu rclone (kein „:")
    assert _looks_like_rclone_uri("/Users/me/file.mov") is False
    assert _looks_like_rclone_uri("./relativ/foo.mov") is False
