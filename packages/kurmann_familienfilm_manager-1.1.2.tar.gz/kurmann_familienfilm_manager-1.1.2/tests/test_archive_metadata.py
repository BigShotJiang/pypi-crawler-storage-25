"""Tests für .archive.toml: Roundtrip mit Umlauten, Multiline, Backslash, Quote."""

from __future__ import annotations

import os
import tomllib
from pathlib import Path

from familienfilm_manager.core.archive_metadata import (
    read_archive_metadata,
    write_archive_metadata,
)


def _source(tmp_path: Path) -> Path:
    video = tmp_path / "2026-04-18 Über den Äquätor \"Spezial\".mov"
    video.write_bytes(b"x")
    os.utime(video, (1713442330.0, 1713442330.0))
    return video


def test_roundtrip_basic(tmp_path: Path):
    video = _source(tmp_path)
    out = tmp_path / "out.archive.toml"
    write_archive_metadata(
        source_video=video,
        target_toml=out,
        recording_date="2026-04-18",
        title="Über den Äquätor",
        description="Einzeilig.",
    )
    parsed = read_archive_metadata(out)
    assert parsed["original_filename"] == video.name
    assert parsed["title"] == "Über den Äquätor"
    assert parsed["description"] == "Einzeilig."
    assert parsed["recording_date"].isoformat() == "2026-04-18"
    assert parsed["schema_version"] == 1
    # generator-Zeile muss den App-Namen enthalten
    assert parsed["generator"].startswith("Kurmann Familienfilm-Manager")


def test_description_multiline_and_special_chars(tmp_path: Path):
    video = _source(tmp_path)
    out = tmp_path / "out.archive.toml"
    desc = (
        "Zeile 1 mit Umlaut ä, ö, ü.\n"
        "Zeile 2 mit Backslash: C:\\Users\\foo\n"
        "Zeile 3 mit \"Zitat\" und 'Apostroph'.\n"
        "Zeile 4 mit Tab:\tund Emoji-Kandidat 𝄞."
    )
    write_archive_metadata(
        source_video=video,
        target_toml=out,
        recording_date="2026-04-18",
        title="T",
        description=desc,
    )
    parsed = read_archive_metadata(out)
    assert parsed["description"] == desc


def test_description_with_triple_quote(tmp_path: Path):
    """Beschreibungen dürfen \"\"\" enthalten, ohne den Multiline-String zu sprengen."""
    video = _source(tmp_path)
    out = tmp_path / "out.archive.toml"
    desc = 'Text mit """ drei Quotes und mehr Text.\nZweite Zeile.'
    write_archive_metadata(
        source_video=video,
        target_toml=out,
        title="T",
        description=desc,
    )
    # Darf ohne Exception parsen
    parsed = tomllib.loads(out.read_text(encoding="utf-8"))
    assert parsed["description"] == desc


def test_title_with_quote_and_backslash(tmp_path: Path):
    video = _source(tmp_path)
    out = tmp_path / "out.archive.toml"
    write_archive_metadata(
        source_video=video,
        target_toml=out,
        title='Titel mit "Zitat" und \\Backslash',
    )
    parsed = read_archive_metadata(out)
    assert parsed["title"] == 'Titel mit "Zitat" und \\Backslash'


def test_original_mtime_is_iso_with_offset(tmp_path: Path):
    video = _source(tmp_path)
    out = tmp_path / "out.archive.toml"
    write_archive_metadata(source_video=video, target_toml=out, title="T")
    parsed = read_archive_metadata(out)
    # tomllib parst TOML-Datetime zu datetime — mit TZ-Info (lokal)
    dt = parsed["original_mtime"]
    assert dt.tzinfo is not None
    # Der Timestamp muss dem gesetzten mtime entsprechen (lokale Zeit).
    assert abs(dt.timestamp() - video.stat().st_mtime) < 1.5
