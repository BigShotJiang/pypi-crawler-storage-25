"""Tests für den Markdown-Notifier (v1.1.0+).

Die Notification-Datei ist seit v1.1.0 Markdown statt HTML. Einträge sind
durch H2-Boundaries gegliedert; Metadaten (id, status, aktualisiert)
stehen als sichtbare Block-Quote-Zeile direkt unter jedem H2.
"""

from pathlib import Path

from familienfilm_manager.core.notifier import (
    append_pending,
    derive_video_id,
    mark_all_pending_as_aborted,
    mark_entry_cleaned_up,
    replace_entry_failed,
    replace_entry_published,
)
from familienfilm_manager.core.notifier_markdown import MAX_ENTRIES


# ── derive_video_id ────────────────────────────────────────────────────


def test_derive_video_id_stable_per_path(tmp_path: Path):
    a = tmp_path / "video.mov"
    b = tmp_path / "video.mov"
    a.touch()
    assert derive_video_id(a) == derive_video_id(b)


def test_derive_video_id_differs_per_path(tmp_path: Path):
    a = tmp_path / "a.mov"; a.touch()
    b = tmp_path / "b.mov"; b.touch()
    assert derive_video_id(a) != derive_video_id(b)


# ── append_pending ────────────────────────────────────────────────────


def test_append_pending_creates_file_with_entry(tmp_path: Path):
    path = tmp_path / "notification.md"
    append_pending(path, video_id="abc123", title="Wanderung")

    content = path.read_text()
    assert content.startswith("# Familienfilme")
    assert "id: abc123 · status: pending" in content
    assert "## " in content and "Wanderung" in content
    assert "- **Status:** In Bearbeitung" in content
    assert "> id: " in content  # Metadaten-Quote unter dem H2


def test_append_pending_replaces_existing_entry_with_same_id(tmp_path: Path):
    path = tmp_path / "notification.md"
    append_pending(path, video_id="abc123", title="Alter Titel")
    append_pending(path, video_id="abc123", title="Neuer Titel")

    content = path.read_text()
    # Nur einmal vorhanden (keine Duplikate)
    assert content.count("id: abc123 ") == 1
    assert "Neuer Titel" in content
    assert "Alter Titel" not in content


# ── replace_entry_published ───────────────────────────────────────────


def test_replace_entry_published_replaces_pending(tmp_path: Path):
    path = tmp_path / "notification.md"
    append_pending(path, video_id="abc123", title="Wanderung")
    replace_entry_published(
        path,
        video_id="abc123",
        title="Wanderung",
        video_url="https://example.com/abc123/",
        category="Familie",
        recording_date="2026-04-18",
    )

    content = path.read_text()
    assert 'status="pending"' not in content
    assert "id: abc123 · status: published" in content
    assert "- **Status:** Veröffentlicht" in content
    assert "- **Web:** <https://example.com/abc123/>" in content
    assert "- **Kategorie:** Familie" in content
    assert "- **Aufnahmedatum:** 2026-04-18" in content


def test_replace_falls_back_to_insert_when_no_pending_exists(tmp_path: Path):
    path = tmp_path / "notification.md"
    replace_entry_published(path, video_id="xyz", title="Neu", video_url="https://e/xyz/")

    content = path.read_text()
    assert "id: xyz · status: published" in content


# ── replace_entry_failed ──────────────────────────────────────────────


def test_replace_entry_failed_replaces_pending_with_error(tmp_path: Path):
    path = tmp_path / "notification.md"
    append_pending(path, video_id="abc123", title="Wanderung")
    replace_entry_failed(
        path,
        video_id="abc123",
        title="Wanderung",
        error_message="rclone fehlgeschlagen",
    )

    content = path.read_text()
    assert "id: abc123 · status: failed" in content
    assert "- **Status:** Fehlgeschlagen — rclone fehlgeschlagen" in content


# ── mark_all_pending_as_aborted ───────────────────────────────────────


def test_mark_all_pending_as_aborted(tmp_path: Path):
    path = tmp_path / "notification.md"
    append_pending(path, video_id="a", title="A")
    append_pending(path, video_id="b", title="B")
    # Eines abschliessen → bleibt published, nicht pending
    replace_entry_published(path, video_id="a", title="A", video_url="https://e/a/")

    count = mark_all_pending_as_aborted(path)
    assert count == 1

    content = path.read_text()
    assert "id: b · status: aborted" in content
    assert "id: a · status: published" in content
    assert 'status="pending"' not in content
    assert "- **Status:** Abgebrochen" in content


def test_mark_all_pending_noop_when_file_missing(tmp_path: Path):
    path = tmp_path / "notification.md"
    assert mark_all_pending_as_aborted(path) == 0
    assert not path.exists()


# ── Kanal-Anzeige (Web + Lokal) ───────────────────────────────────────


def test_published_entry_shows_local_target(tmp_path: Path):
    """Bei Local-only-Publish (nur Infuse, kein Web) wird der Lokal-Pfad angezeigt."""
    path = tmp_path / "notification.md"
    replace_entry_published(
        path, video_id="a", title="Testvideo",
        infuse_target_path="nas:/Familienfilme/Final/2026",
    )
    content = path.read_text()
    assert "- **Lokal:** `nas:/Familienfilme/Final/2026`" in content
    # Kein Web-Block, wenn keine URL
    assert "**Web:**" not in content


def test_published_entry_shows_both_channels(tmp_path: Path):
    """Mit Web-URL + Lokal werden beide Kanäle angezeigt."""
    path = tmp_path / "notification.md"
    replace_entry_published(
        path, video_id="a", title="Testvideo",
        video_url="https://mediathek.example/xxx/",
        infuse_target_path="nas:/Familienfilme/Final/2026",
        archive_target_path="nas:/Archiv/2026/Videoschnitt",
    )
    content = path.read_text()
    assert "- **Web:** <https://mediathek.example/xxx/>" in content
    assert "- **Lokal:** `nas:/Familienfilme/Final/2026`" in content
    # Archiv wird in MD bewusst NICHT mehr gerendert (v1.1.0+)
    assert "Archiv" not in content
    assert "nas:/Archiv" not in content


def test_published_entry_without_channels_has_only_status(tmp_path: Path):
    """Ohne Targets/URL bleibt nur die Status-Zeile."""
    path = tmp_path / "notification.md"
    replace_entry_published(path, video_id="a", title="Testvideo")
    content = path.read_text()
    assert "**Web:**" not in content
    assert "**Lokal:**" not in content
    assert "- **Status:** Veröffentlicht" in content


# ── mark_entry_cleaned_up ─────────────────────────────────────────────


def test_mark_entry_cleaned_up_changes_status_and_keeps_local(tmp_path):
    """Bestehender published-Eintrag wird als cleaned-up markiert; Lokal-Zeile bleibt."""
    path = tmp_path / "Familienfilme.md"
    replace_entry_published(
        path, video_id="abc", title="Bergmolch",
        video_url="https://mediathek.kurmann.swiss/q26qobjxl4c3/",
        infuse_target_path="nas:/Filme/2026",
    )

    ok = mark_entry_cleaned_up(
        path, web_id="q26qobjxl4c3",
        branding_base_url="https://mediathek.kurmann.swiss",
        cleanup_date="27.04.2026",
    )
    assert ok is True

    content = path.read_text()
    assert "id: abc · status: cleaned-up" in content
    assert "- **Status:** Aus Web-Speicher entfernt am 27.04.2026" in content
    # Lokal bleibt sichtbar (Infuse-Kopie ist noch da)
    assert "- **Lokal:** `nas:/Filme/2026`" in content
    # Web-Zeile bleibt drin (Teil der Geschichte) — Status signalisiert die Änderung
    assert "https://mediathek.kurmann.swiss/q26qobjxl4c3/" in content


def test_mark_entry_cleaned_up_no_match_returns_false(tmp_path):
    path = tmp_path / "Familienfilme.md"
    replace_entry_published(
        path, video_id="abc", title="X",
        video_url="https://mediathek.kurmann.swiss/aaaaaaaaaaaa/",
    )
    ok = mark_entry_cleaned_up(
        path, web_id="bbbbbbbbbbbb",
        branding_base_url="https://mediathek.kurmann.swiss",
    )
    assert ok is False


def test_mark_entry_cleaned_up_missing_file_returns_false(tmp_path):
    path = tmp_path / "doesnotexist.md"
    ok = mark_entry_cleaned_up(
        path, web_id="anything",
        branding_base_url="https://mediathek.kurmann.swiss",
    )
    assert ok is False


def test_mark_entry_cleaned_up_idempotent(tmp_path):
    path = tmp_path / "Familienfilme.md"
    replace_entry_published(
        path, video_id="abc", title="X",
        video_url="https://mediathek.kurmann.swiss/q26qobjxl4c3/",
    )
    mark_entry_cleaned_up(
        path, web_id="q26qobjxl4c3",
        branding_base_url="https://mediathek.kurmann.swiss",
        cleanup_date="2026-04-27",
    )
    first = path.read_text()
    mark_entry_cleaned_up(
        path, web_id="q26qobjxl4c3",
        branding_base_url="https://mediathek.kurmann.swiss",
        cleanup_date="2026-04-27",
    )
    second = path.read_text()
    # Zweiter Aufruf darf den Inhalt nicht erneut verdoppeln
    assert first.count("cleaned-up") == second.count("cleaned-up")
    assert second.count("Aus Web-Speicher entfernt am 2026-04-27") == 1


def test_mark_entry_cleaned_up_with_reason_appends(tmp_path):
    """Reason landet in Klammern in der Status-Zeile."""
    path = tmp_path / "Familienfilme.md"
    replace_entry_published(
        path, video_id="abc", title="X",
        video_url="https://mediathek.kurmann.swiss/q26qobjxl4c3/",
    )
    mark_entry_cleaned_up(
        path, web_id="q26qobjxl4c3",
        branding_base_url="https://mediathek.kurmann.swiss",
        cleanup_date="27.04.2026",
        reason="älter als 365 Tage",
    )
    content = path.read_text()
    assert (
        "- **Status:** Aus Web-Speicher entfernt am 27.04.2026 (älter als 365 Tage)"
        in content
    )


# ── MAX_ENTRIES-Trimming (v1.1.0+) ─────────────────────────────────────


def test_max_entries_trimming(tmp_path: Path):
    """Wenn mehr als MAX_ENTRIES Einträge existieren, fallen die ältesten raus."""
    path = tmp_path / "notification.md"
    # MAX_ENTRIES + 5 unterschiedliche Einträge anlegen
    for i in range(MAX_ENTRIES + 5):
        append_pending(path, video_id=f"id{i:04d}", title=f"Video {i}")

    content = path.read_text()
    # Genau MAX_ENTRIES Einträge — die jüngsten 50
    assert content.count("\n## ") == MAX_ENTRIES
    # Die jüngsten 5 müssen drin sein
    for i in range(MAX_ENTRIES, MAX_ENTRIES + 5):
        assert f"id: id{i:04d} " in content
    # Die ältesten 5 müssen weg sein
    for i in range(5):
        assert f"id: id{i:04d} " not in content


def test_document_header_present_and_refreshed(tmp_path: Path):
    """Header bleibt am Anfang, Update-Zeitstempel wird mitgepflegt."""
    path = tmp_path / "notification.md"
    append_pending(path, video_id="x", title="X")
    first = path.read_text()
    assert first.startswith("# Familienfilme")
    assert "_Aktualisiert: " in first
    # Hinweis-Block-Quote ist da (rendert als grauer kursiver Block in MD-Viewern)
    assert "automatisch vom Familienfilm-Manager geschrieben" in first
    # Anzahl Header-Zeilen exakt 1 (kein Duplikat nach zweitem Write)
    append_pending(path, video_id="y", title="Y")
    second = path.read_text()
    assert second.count("# Familienfilme") == 1
    assert second.count("_Aktualisiert: ") == 1


def test_newest_entry_appears_first(tmp_path: Path):
    """Neueste Einträge stehen oben (chronologisch absteigend)."""
    path = tmp_path / "notification.md"
    append_pending(path, video_id="a", title="A first")
    append_pending(path, video_id="b", title="B second")
    append_pending(path, video_id="c", title="C third")

    content = path.read_text()
    pos_a = content.find("id: a ")
    pos_b = content.find("id: b ")
    pos_c = content.find("id: c ")
    # c ist neuestes und steht oben → kleinster Offset
    assert pos_c < pos_b < pos_a
