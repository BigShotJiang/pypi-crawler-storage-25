"""Tests für den rclone-Retry-Mechanismus."""

import subprocess
from unittest.mock import patch

import pytest

from familienfilm_manager.core._rclone import (
    DEFAULT_RETRY_DELAYS,
    run_rclone_with_retry,
)


def _make_error(returncode: int = 1, stderr: str = "nas: connection refused") -> subprocess.CalledProcessError:
    err = subprocess.CalledProcessError(returncode, ["rclone", "copy"])
    err.stderr = stderr
    return err


def _make_success() -> subprocess.CompletedProcess:
    return subprocess.CompletedProcess(["rclone", "copy"], 0, stdout="", stderr="")


def test_first_try_succeeds_no_retry():
    """Bei Erfolg im ersten Versuch wird kein Retry ausgelöst."""
    calls = []
    retries = []

    def fake_run(*args, **kwargs):
        calls.append(args[0])
        return _make_success()

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        result = run_rclone_with_retry(
            ["rclone", "copy", "a", "b"],
            on_retry=lambda a, m, e: retries.append((a, m, e)),
        )

    assert len(calls) == 1
    assert retries == []
    assert result.returncode == 0


def test_retry_on_transient_error_then_success():
    """Flüchtiger Fehler: einmal scheitert, zweiter Versuch klappt."""
    attempts = iter([_make_error(), _make_success()])
    retries = []

    def fake_run(*args, **kwargs):
        r = next(attempts)
        if isinstance(r, subprocess.CalledProcessError):
            raise r
        return r

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        with patch("familienfilm_manager.core._rclone.time.sleep") as sleep_mock:
            result = run_rclone_with_retry(
                ["rclone", "copy", "a", "b"],
                retry_delays=(1, 3, 9),
                on_retry=lambda a, m, e: retries.append((a, m)),
            )

    assert result.returncode == 0
    assert len(retries) == 1
    assert retries[0] == (1, 4)  # Versuch 1 fehlgeschlagen, max 4 Versuche
    sleep_mock.assert_called_once_with(1)  # erstes Backoff-Delay


def test_all_retries_fail_raises_last_error():
    """Nach Erschöpfung aller Retries wird die letzte Exception geworfen."""
    errors = [_make_error(stderr=f"fail {i}") for i in range(4)]
    attempts = iter(errors)
    retries = []

    def fake_run(*args, **kwargs):
        raise next(attempts)

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            with pytest.raises(subprocess.CalledProcessError) as excinfo:
                run_rclone_with_retry(
                    ["rclone", "copy", "a", "b"],
                    retry_delays=(1, 3, 9),
                    on_retry=lambda a, m, e: retries.append(a),
                )

    # Letzte Exception enthält die "fail 3" Meldung
    assert excinfo.value.stderr == "fail 3"
    # 3 Retry-Callbacks (nach Versuch 1, 2, 3; nach Versuch 4 gibt's keinen mehr)
    assert retries == [1, 2, 3]


def test_filenotfound_not_retried():
    """Nicht-flüchtige Fehler (z.B. rclone-Binary nicht gefunden) werden nicht retried."""
    call_count = [0]

    def fake_run(*args, **kwargs):
        call_count[0] += 1
        raise FileNotFoundError("rclone: command not found")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            with pytest.raises(FileNotFoundError):
                run_rclone_with_retry(["rclone", "copy", "a", "b"])

    assert call_count[0] == 1, "FileNotFoundError soll nicht retried werden"


def test_custom_retry_delays_control_count():
    """Die Länge von retry_delays bestimmt die Anzahl Retries."""
    errors = [_make_error() for _ in range(3)]
    attempts = iter(errors)

    def fake_run(*args, **kwargs):
        raise next(attempts)

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        with patch("familienfilm_manager.core._rclone.time.sleep") as sleep_mock:
            with pytest.raises(subprocess.CalledProcessError):
                run_rclone_with_retry(
                    ["rclone", "copy", "a", "b"],
                    retry_delays=(5, 10),   # 2 Retries → max 3 Versuche
                )

    assert sleep_mock.call_count == 2
    assert [c.args[0] for c in sleep_mock.call_args_list] == [5, 10]


def test_default_retry_delays_are_exponential():
    """Default ist (1, 3, 9) — konservatives exponentielles Backoff."""
    assert DEFAULT_RETRY_DELAYS == (1, 3, 9)



def test_keyboard_interrupt_during_subprocess_propagates_no_retry():
    """Ctrl+C im subprocess.run wird direkt durchgereicht — kein weiterer Retry."""
    call_count = [0]

    def fake_run(*args, **kwargs):
        call_count[0] += 1
        raise KeyboardInterrupt()

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        with patch("familienfilm_manager.core._rclone.time.sleep") as sleep_mock:
            with pytest.raises(KeyboardInterrupt):
                run_rclone_with_retry(["rclone", "copy", "a", "b"])

    assert call_count[0] == 1, "KeyboardInterrupt darf keinen Retry triggern"
    assert sleep_mock.call_count == 0, "Keine Sleep-Phase nach Ctrl+C"


def test_keyboard_interrupt_during_sleep_propagates_no_retry():
    """Ctrl+C während der Retry-Sleep-Phase bricht sofort ab."""
    call_count = [0]

    def fake_run(*args, **kwargs):
        call_count[0] += 1
        raise _make_error()

    def fake_sleep(_seconds):
        raise KeyboardInterrupt()

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        with patch("familienfilm_manager.core._rclone.time.sleep", side_effect=fake_sleep):
            with pytest.raises(KeyboardInterrupt):
                run_rclone_with_retry(["rclone", "copy", "a", "b"])

    # Genau 1 Versuch: erster subprocess-Call scheitert → Sleep → Ctrl+C → Abbruch.
    assert call_count[0] == 1, "Nach Ctrl+C darf kein zweiter subprocess-Versuch kommen"


def test_child_signal_exit_130_treated_as_interrupt():
    """rclone, das mit Exit-Code 130 (128 + SIGINT) beendet, wird als
    User-Abbruch behandelt — kein Retry. Tritt auf, wenn das Watch-Loop
    eigene SIGINT-Handler installiert hat und Python selbst keinen
    KeyboardInterrupt sieht, aber der Child-Prozess trotzdem SIGINT
    abbekam und sauber mit Exit 130 beendete."""
    call_count = [0]

    def fake_run(*args, **kwargs):
        call_count[0] += 1
        err = subprocess.CalledProcessError(130, ["rclone", "copy"])
        err.stderr = "Command interrupted"
        raise err

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        with patch("familienfilm_manager.core._rclone.time.sleep") as sleep_mock:
            with pytest.raises(KeyboardInterrupt):
                run_rclone_with_retry(["rclone", "copy", "a", "b"])

    assert call_count[0] == 1, "Exit 130 darf keinen Retry triggern"
    assert sleep_mock.call_count == 0


def test_child_signal_exit_minus2_treated_as_interrupt():
    """POSIX-Variante: Child wird durch SIGINT gekillt, bevor es exit()
    ausführen kann → returncode = -2. Muss gleich behandelt werden."""
    call_count = [0]

    def fake_run(*args, **kwargs):
        call_count[0] += 1
        err = subprocess.CalledProcessError(-2, ["rclone", "move"])
        err.stderr = "died with <Signals.SIGINT: 2>"
        raise err

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        with patch("familienfilm_manager.core._rclone.time.sleep") as sleep_mock:
            with pytest.raises(KeyboardInterrupt):
                run_rclone_with_retry(["rclone", "move", "a", "b"])

    assert call_count[0] == 1, "Exit -2 darf keinen Retry triggern"
    assert sleep_mock.call_count == 0


def test_other_non_zero_exit_still_retries():
    """Regression-Schutz: normale Fehler (z.B. Netzwerk-Timeout, Exit 1)
    werden weiterhin retried — nur 130/-2 sind reserviert für Abbruch."""
    from familienfilm_manager.core._rclone import DEFAULT_RETRY_DELAYS

    call_count = [0]

    def fake_run(*args, **kwargs):
        call_count[0] += 1
        err = subprocess.CalledProcessError(1, ["rclone", "copy"])
        err.stderr = "connection refused"
        raise err

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            with pytest.raises(subprocess.CalledProcessError):
                run_rclone_with_retry(["rclone", "copy", "a", "b"])

    assert call_count[0] == len(DEFAULT_RETRY_DELAYS) + 1, (
        "Normaler Fehler soll alle Retries ausschöpfen"
    )
