"""Tests für familienfilm.toml-Vererbung in der Verzeichniskette."""

from pathlib import Path

from familienfilm_manager.core.directory_settings import (
    SETTINGS_FILENAME,
    find_directory_settings,
)


def _write_settings(directory: Path, category: str) -> None:
    (directory / SETTINGS_FILENAME).write_text(
        f'category = "{category}"\n', encoding="utf-8",
    )


def test_no_settings_file_anywhere(tmp_path: Path):
    """Keine familienfilm.toml im Pfad → leeres Settings-Objekt."""
    video_dir = tmp_path / "nested" / "deeper"
    video_dir.mkdir(parents=True)

    result = find_directory_settings(video_dir, stop_at=tmp_path)
    assert result.category is None
    assert result.source_uri is None


def test_settings_directly_in_start_dir(tmp_path: Path):
    """familienfilm.toml im Start-Verzeichnis wird gefunden."""
    _write_settings(tmp_path, "Familie Direkt")

    result = find_directory_settings(tmp_path, stop_at=tmp_path)
    assert result.category == "Familie Direkt"
    assert result.source_uri == str(tmp_path / SETTINGS_FILENAME)


def test_settings_inherited_from_parent(tmp_path: Path):
    """familienfilm.toml im Parent vererbt sich an Unterverzeichnisse."""
    _write_settings(tmp_path, "Familie Parent")
    child = tmp_path / "2026" / "quartal-2"
    child.mkdir(parents=True)

    result = find_directory_settings(child, stop_at=tmp_path)
    assert result.category == "Familie Parent"


def test_child_settings_override_parent(tmp_path: Path):
    """Nächstgelegenes Verzeichnis gewinnt: Child-Settings überschreiben Parent."""
    _write_settings(tmp_path, "Familie Parent")
    child = tmp_path / "Arbeit"
    child.mkdir()
    _write_settings(child, "Firma XY")

    result = find_directory_settings(child, stop_at=tmp_path)
    assert result.category == "Firma XY"


def test_stop_at_is_inclusive(tmp_path: Path):
    """stop_at wird selbst noch geprüft (inklusive Grenze)."""
    _write_settings(tmp_path, "Familie Grenze")
    # Start-Dir = Grenze selbst
    result = find_directory_settings(tmp_path, stop_at=tmp_path)
    assert result.category == "Familie Grenze"


def test_stop_at_prevents_looking_above(tmp_path: Path):
    """Oberhalb von stop_at wird nicht gesucht."""
    # Settings im Grandparent, nicht im scan-root
    scan_root = tmp_path / "scan-root"
    scan_root.mkdir()
    _write_settings(tmp_path, "Familie Grandparent")

    result = find_directory_settings(scan_root, stop_at=scan_root)
    assert result.category is None


def test_broken_toml_is_treated_as_missing(tmp_path: Path):
    """Kaputte TOML-Datei wird ignoriert (statt Exception)."""
    (tmp_path / SETTINGS_FILENAME).write_text(
        "this is not valid [[[ toml", encoding="utf-8",
    )

    result = find_directory_settings(tmp_path, stop_at=tmp_path)
    assert result.category is None


def test_toml_without_category_field(tmp_path: Path):
    """TOML existiert, hat aber keinen category-Key → None, weiter nach oben suchen."""
    (tmp_path / "child").mkdir()
    (tmp_path / SETTINGS_FILENAME).write_text(
        'category = "Familie Oben"\n', encoding="utf-8",
    )
    (tmp_path / "child" / SETTINGS_FILENAME).write_text(
        "# empty settings — kein category\n", encoding="utf-8",
    )

    result = find_directory_settings(tmp_path / "child", stop_at=tmp_path)
    assert result.category == "Familie Oben"


def test_stop_at_none_walks_until_filesystem_root(tmp_path: Path):
    """Ohne stop_at läuft die Suche bis zum Filesystem-Root — ohne Exception."""
    nested = tmp_path / "a" / "b" / "c"
    nested.mkdir(parents=True)

    # Kein Settings-File im Pfad von tmp_path bis /
    result = find_directory_settings(nested, stop_at=None)
    assert result.category is None


# ── web_enabled (v0.8.0) ──


def test_web_enabled_read_from_toml(tmp_path: Path):
    """``web_enabled = true`` in familienfilm.toml wird gelesen."""
    (tmp_path / SETTINGS_FILENAME).write_text(
        'web_enabled = true\n', encoding="utf-8",
    )
    result = find_directory_settings(tmp_path, stop_at=tmp_path)
    assert result.web_enabled is True
    assert result.category is None


def test_web_enabled_inherited_from_parent(tmp_path: Path):
    """``web_enabled`` vererbt sich an Unterverzeichnisse."""
    (tmp_path / SETTINGS_FILENAME).write_text(
        'web_enabled = true\n', encoding="utf-8",
    )
    child = tmp_path / "2026"
    child.mkdir()
    result = find_directory_settings(child, stop_at=tmp_path)
    assert result.web_enabled is True


def test_per_field_first_match_merge(tmp_path: Path):
    """Verschiedene Felder können auf verschiedenen Ebenen stehen.
    Pro Feld gewinnt das erste (nächstgelegene) Vorkommen."""
    # Oben: nur category
    (tmp_path / SETTINGS_FILENAME).write_text(
        'category = "Familie"\n', encoding="utf-8",
    )
    # Unten: nur web_enabled
    child = tmp_path / "Öffentlich"
    child.mkdir()
    (child / SETTINGS_FILENAME).write_text(
        'web_enabled = true\n', encoding="utf-8",
    )
    result = find_directory_settings(child, stop_at=tmp_path)
    assert result.category == "Familie"
    assert result.web_enabled is True


def test_child_web_enabled_wins_over_parent(tmp_path: Path):
    """Closest-wins: Child ``web_enabled = false`` überschreibt Parent ``true``."""
    (tmp_path / SETTINGS_FILENAME).write_text(
        'web_enabled = true\n', encoding="utf-8",
    )
    child = tmp_path / "Privat"
    child.mkdir()
    (child / SETTINGS_FILENAME).write_text(
        'web_enabled = false\n', encoding="utf-8",
    )
    result = find_directory_settings(child, stop_at=tmp_path)
    assert result.web_enabled is False


def test_default_web_enabled_is_none_when_not_set(tmp_path: Path):
    """Ohne ``web_enabled`` bleibt das Feld None (Semantik: nicht gesetzt).
    Die Default-Entscheidung (Web aus) wird im Aufrufer getroffen."""
    (tmp_path / SETTINGS_FILENAME).write_text(
        'category = "Familie"\n', encoding="utf-8",
    )
    result = find_directory_settings(tmp_path, stop_at=tmp_path)
    assert result.web_enabled is None
