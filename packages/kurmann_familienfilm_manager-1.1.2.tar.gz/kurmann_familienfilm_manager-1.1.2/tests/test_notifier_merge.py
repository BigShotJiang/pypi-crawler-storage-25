"""Tests für den Multi-Machine-Merge der Notification-MD (v1.1.0+).

Vor jedem Push zum rclone-Remote pullen wir den aktuellen Remote-Stand
und vereinigen ihn mit unserem modifizierten Lokal-Inhalt (Union per
``video-id``, jüngerer ``aktualisiert``-Timestamp gewinnt). Damit kann
ein zweiter Rechner, der parallel publiziert, unsere Einträge nicht
mehr überschreiben.
"""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import patch

import pytest

from familienfilm_manager.core.notifier import (
    append_pending,
    replace_entry_published,
)
from familienfilm_manager.core.notifier_markdown import (
    MAX_ENTRIES,
    EntryBlock,
    merge_documents,
    parse_blocks,
    render_block,
    render_document,
    render_entry,
)
from familienfilm_manager.core.notifier_storage import (
    NotificationStorage,
    fetch_remote_content,
)


@pytest.fixture(autouse=True)
def _no_retry_sleep():
    with patch("familienfilm_manager.core._rclone.time.sleep"):
        yield


# ── parse_blocks / render_block round-trip ────────────────────────────


def test_render_entry_includes_metadata_quote():
    md = render_entry(
        video_id="abc", status="pending", title="X",
        updated="2026-05-01T12:00:00Z",
    )
    assert "> id: abc · status: pending · aktualisiert: 2026-05-01T12:00:00Z" in md


def test_parse_blocks_extracts_metadata():
    doc = render_entry(
        video_id="abc", status="published", title="X",
        updated="2026-05-01T10:00:00Z",
    )
    blocks = parse_blocks(doc)
    assert len(blocks) == 1
    assert blocks[0].video_id == "abc"
    assert blocks[0].status == "published"
    assert blocks[0].updated == "2026-05-01T10:00:00Z"


def test_parse_blocks_skips_h2_without_metadata_quote():
    """H2 ohne Metadaten-Quote wird übersprungen — schützt vor User-eigenen H2s."""
    doc = (
        "# Familienfilme\n\n"
        "## Eine eigene Sektion vom User\n"
        "Hier steht beliebiger Markdown-Text.\n\n"
        "## 01.05.2026 — Echter Eintrag\n"
        "> id: abc · status: pending · aktualisiert: 2026-05-01T10:00:00Z\n"
        "\n"
        "- **Status:** In Bearbeitung\n"
        "\n"
    )
    blocks = parse_blocks(doc)
    assert len(blocks) == 1
    assert blocks[0].video_id == "abc"


def test_render_block_round_trip():
    block = EntryBlock(
        video_id="x", status="published",
        updated="2026-05-01T12:00:00Z",
        title_line="## 01.05.2026 — Test",
        body="- **Status:** Veröffentlicht",
    )
    md = render_block(block)
    parsed = parse_blocks(md)
    assert parsed == [block]


# ── merge_documents core behavior ─────────────────────────────────────


def _make_doc(*entries: tuple[str, str, str]) -> str:
    """Helper: baut Dokument aus (video_id, status, updated)-Tupeln."""
    blocks = [
        EntryBlock(
            video_id=vid, status=status, updated=updated,
            title_line=f"## 01.05.2026 — Entry {vid}",
            body=f"- **Status:** {status}",
        )
        for vid, status, updated in entries
    ]
    return render_document(blocks)


def test_merge_disjoint_video_ids_unifies():
    local = _make_doc(("a", "published", "2026-05-01T10:00:00Z"))
    remote = _make_doc(("b", "published", "2026-05-01T11:00:00Z"))

    merged = merge_documents(local=local, remote=remote)
    blocks = parse_blocks(merged)
    ids = {b.video_id for b in blocks}
    assert ids == {"a", "b"}


def test_merge_same_id_newer_updated_wins():
    """Bei identischer video-id gewinnt der Eintrag mit jüngerem updated."""
    local = _make_doc(("a", "published", "2026-05-01T15:00:00Z"))
    remote = _make_doc(("a", "pending", "2026-05-01T10:00:00Z"))

    merged = merge_documents(local=local, remote=remote)
    blocks = parse_blocks(merged)
    assert len(blocks) == 1
    assert blocks[0].status == "published"  # Local gewinnt (jünger)


def test_merge_remote_newer_wins_when_local_is_older():
    local = _make_doc(("a", "pending", "2026-05-01T10:00:00Z"))
    remote = _make_doc(("a", "published", "2026-05-01T15:00:00Z"))

    merged = merge_documents(local=local, remote=remote)
    blocks = parse_blocks(merged)
    assert len(blocks) == 1
    assert blocks[0].status == "published"  # Remote gewinnt (jünger)


def test_merge_equal_updated_local_wins():
    """Bei Gleichstand gewinnt local — denn das ist unsere frische Modifikation."""
    ts = "2026-05-01T12:00:00Z"
    local = _make_doc(("a", "published", ts))
    remote = _make_doc(("a", "failed", ts))

    merged = merge_documents(local=local, remote=remote)
    blocks = parse_blocks(merged)
    assert blocks[0].status == "published"


def test_merge_sorts_by_updated_descending():
    local = _make_doc(
        ("old", "published", "2026-05-01T08:00:00Z"),
        ("new", "published", "2026-05-01T18:00:00Z"),
    )
    remote = _make_doc(("mid", "published", "2026-05-01T13:00:00Z"))

    merged = merge_documents(local=local, remote=remote)
    blocks = parse_blocks(merged)
    assert [b.video_id for b in blocks] == ["new", "mid", "old"]


def test_merge_respects_max_entries():
    """Auch nach Merge wird auf MAX_ENTRIES getrimmt — älteste raus."""
    local_entries = [
        (f"local{i:03d}", "published", f"2026-05-01T{i:02d}:00:00Z")
        for i in range(MAX_ENTRIES)  # 50 lokale Einträge
    ]
    remote_entries = [
        (f"remote{i:03d}", "published", f"2026-05-02T{i:02d}:00:00Z")  # alle jünger
        for i in range(10)
    ]
    local = _make_doc(*local_entries)
    remote = _make_doc(*remote_entries)

    merged = merge_documents(local=local, remote=remote)
    blocks = parse_blocks(merged)
    assert len(blocks) == MAX_ENTRIES
    ids = {b.video_id for b in blocks}
    assert all(f"remote{i:03d}" in ids for i in range(10))
    # Älteste 10 lokalen müssen raus sein
    assert all(f"local{i:03d}" not in ids for i in range(10))


# ── Integration: _write macht Pull-Merge-Push ─────────────────────────


def test_remote_write_pulls_and_merges_before_push(tmp_path, monkeypatch):
    """End-to-End: ein zweiter Rechner hat einen Eintrag, der in unserem
    Cache fehlt. Nach unserem Publish ist der fremde Eintrag immer noch da."""
    monkeypatch.setattr(
        "familienfilm_manager.core.notifier_storage._CACHE_DIR",
        tmp_path / ".cache",
    )
    monkeypatch.setattr(
        "familienfilm_manager.core._rclone.DEFAULT_RETRY_DELAYS", (),
    )

    target = "mega.nz:Familienfilme.md"

    # Remote-Stand: wurde von einem anderen Rechner geschrieben (Video Y).
    remote_state = (
        "# Familienfilme\n\n"
        "_Aktualisiert: 01.05.2026, 10:00_\n\n"
        "## 01.05.2026 — From Other Machine\n"
        "> id: otherY · status: published · aktualisiert: 2026-05-01T10:00:00Z\n"
        "\n"
        "- **Status:** Veröffentlicht\n"
        "\n"
    )

    pushed_files: list[bytes] = []

    def fake_run(args, **kwargs):
        if args[1] == "cat":
            return subprocess.CompletedProcess(
                args=args, returncode=0,
                stdout=remote_state, stderr="",
            )
        if args[1] == "delete":
            return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")
        if args[1] == "copyto":
            local_path = Path(args[2])
            pushed_files.append(local_path.read_bytes())
            return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")
        return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        replace_entry_published(
            target, video_id="ourX", title="From Us",
            video_url="https://e/ourX/",
        )

    assert len(pushed_files) == 1
    pushed_content = pushed_files[0].decode("utf-8")
    assert "id: ourX · status: published" in pushed_content
    assert "id: otherY · status: published" in pushed_content  # nicht überschrieben!
    assert "From Other Machine" in pushed_content
    assert "From Us" in pushed_content


def test_remote_pull_failure_falls_back_to_local_only(tmp_path, monkeypatch):
    """Wenn rclone cat scheitert (Network), wird trotzdem unser Local gepushed."""
    monkeypatch.setattr(
        "familienfilm_manager.core.notifier_storage._CACHE_DIR",
        tmp_path / ".cache",
    )
    monkeypatch.setattr(
        "familienfilm_manager.core._rclone.DEFAULT_RETRY_DELAYS", (),
    )

    pushed_files: list[bytes] = []

    def fake_run(args, **kwargs):
        if args[1] == "cat":
            raise subprocess.CalledProcessError(
                1, args, output="", stderr=b"network unreachable",
            )
        if args[1] == "copyto":
            pushed_files.append(Path(args[2]).read_bytes())
        return subprocess.CompletedProcess(args=args, returncode=0, stdout="", stderr="")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        append_pending(
            "mega.nz:Familienfilme.md", video_id="abc", title="Trotzdem",
        )

    assert len(pushed_files) == 1
    assert b"Trotzdem" in pushed_files[0]


def test_local_only_target_does_not_pull_or_merge(tmp_path):
    """Bei lokalem Path-Target: kein rclone-Aufruf, also auch kein Merge."""
    target = tmp_path / "Familienfilme.md"
    with patch("familienfilm_manager.core._rclone.subprocess.run") as run_mock:
        replace_entry_published(target, video_id="abc", title="T")
    run_mock.assert_not_called()
    assert target.exists()


def test_fetch_remote_content_returns_string():
    storage = NotificationStorage(cache=Path("/tmp/x"), remote="mega.nz:test.md")

    def fake_run(args, **kwargs):
        return subprocess.CompletedProcess(
            args=args, returncode=0,
            stdout="hello world", stderr="",
        )

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        content = fetch_remote_content(storage)
    assert content == "hello world"


def test_fetch_remote_content_local_only_returns_none():
    storage = NotificationStorage(cache=Path("/tmp/x"), remote=None)
    content = fetch_remote_content(storage)
    assert content is None


def test_fetch_remote_content_pull_failure_returns_none():
    storage = NotificationStorage(cache=Path("/tmp/x"), remote="mega.nz:test.md")

    def fake_run(args, **kwargs):
        raise subprocess.CalledProcessError(1, args, stderr=b"network down")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        with patch("familienfilm_manager.core._rclone.DEFAULT_RETRY_DELAYS", ()):
            content = fetch_remote_content(storage)
    assert content is None


# ── Document-Header Hinweis ───────────────────────────────────────────


def test_document_header_contains_user_hint():
    """Der File-Hinweis warnt den User vor manueller Bearbeitung."""
    target_path = "/tmp/test.md"  # Path-String reicht für Pfad-Aufruf
    md = render_entry(
        video_id="abc", status="pending", title="X",
        updated="2026-05-01T10:00:00Z",
    )
    # render_entry alleine hat keinen Header; aber render_document schon.
    doc = render_document(parse_blocks(md))
    assert "automatisch vom Familienfilm-Manager" in doc
    assert "Bitte nicht manuell editieren" in doc
