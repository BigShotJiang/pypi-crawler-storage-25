"""Tests für den Directory-Watcher (Loop, --once, Fehler-Isolation, Signal-Stop)."""

from pathlib import Path
from unittest.mock import patch

from familienfilm_manager.api.models import (
    DirectoryPublishResult,
    FamilienfilmEvent,
    FamilienfilmStage,
    VideoStatus,
    VideoStatusKind,
    WatchRequest,
)
from familienfilm_manager.core.directory_watcher import run_watch


def _fake_dir_result(directory: Path, published: int = 0, failed: int = 0) -> DirectoryPublishResult:
    r = DirectoryPublishResult(success=(failed == 0), directory=directory)
    for i in range(published):
        v = directory / f"pub_{i}.mov"
        r.videos.append(VideoStatus(path=v, kind=VideoStatusKind.PUBLISHED))
    for i in range(failed):
        v = directory / f"fail_{i}.mov"
        r.videos.append(VideoStatus(
            path=v, kind=VideoStatusKind.FAILED, error_message="fake",
        ))
    return r


def test_once_runs_single_tick(tmp_path: Path):
    d = tmp_path / "watched"
    d.mkdir()

    calls = []

    def fake_run(directory, **kwargs):  # noqa: ARG001
        calls.append(directory)
        return _fake_dir_result(directory, published=1)

    with patch(
        "familienfilm_manager.core.directory_watcher.run_publish_directory",
        side_effect=fake_run,
    ):
        result = run_watch(
            WatchRequest(directories=[d], interval_seconds=1, once=True, stability_window_seconds=0),
        )

    assert result.tick_count == 1
    assert len(result.ticks) == 1
    assert calls == [d]
    assert result.ticks[0].published_count == 1


def test_multiple_directories_in_single_tick(tmp_path: Path):
    d1 = tmp_path / "a"; d1.mkdir()
    d2 = tmp_path / "b"; d2.mkdir()

    def fake_run(directory, **kwargs):  # noqa: ARG001
        return _fake_dir_result(directory, published=2)

    with patch(
        "familienfilm_manager.core.directory_watcher.run_publish_directory",
        side_effect=fake_run,
    ):
        result = run_watch(
            WatchRequest(directories=[d1, d2], once=True, stability_window_seconds=0),
        )

    assert result.ticks[0].published_count == 4
    assert len(result.ticks[0].directory_results) == 2


def test_exception_in_one_directory_isolated(tmp_path: Path):
    d1 = tmp_path / "a"; d1.mkdir()
    d2 = tmp_path / "b"; d2.mkdir()

    def fake_run(directory, **kwargs):  # noqa: ARG001
        if directory == d1:
            raise RuntimeError("kaputt")
        return _fake_dir_result(directory, published=3)

    with patch(
        "familienfilm_manager.core.directory_watcher.run_publish_directory",
        side_effect=fake_run,
    ):
        result = run_watch(
            WatchRequest(directories=[d1, d2], once=True, stability_window_seconds=0),
        )

    tick = result.ticks[0]
    assert "kaputt" in " ".join(tick.error_messages)
    assert tick.published_count == 3  # d2 läuft weiter durch


def test_missing_directory_logged_not_raised(tmp_path: Path):
    missing = tmp_path / "nicht-da"
    existing = tmp_path / "da"; existing.mkdir()

    def fake_run(directory, **kwargs):  # noqa: ARG001
        return _fake_dir_result(directory, published=1)

    with patch(
        "familienfilm_manager.core.directory_watcher.run_publish_directory",
        side_effect=fake_run,
    ):
        result = run_watch(
            WatchRequest(directories=[missing, existing], once=True, stability_window_seconds=0),
        )

    assert result.tick_count == 1
    tick = result.ticks[0]
    assert any("nicht gefunden" in m for m in tick.error_messages)
    # Nur existing wurde publiziert
    assert tick.published_count == 1


def test_empty_directories_raises():
    import pytest

    with pytest.raises(ValueError):
        run_watch(WatchRequest(directories=[], once=True))


def test_category_from_request_passed_to_publish_directory(tmp_path: Path):
    """Die Kategorie aus dem WatchRequest landet bei run_publish_directory."""
    d = tmp_path / "watched"
    d.mkdir()

    captured_kwargs: list[dict] = []

    def fake_run(directory, **kwargs):  # noqa: ARG001
        captured_kwargs.append(kwargs)
        return _fake_dir_result(directory, published=1)

    with patch(
        "familienfilm_manager.core.directory_watcher.run_publish_directory",
        side_effect=fake_run,
    ):
        run_watch(
            WatchRequest(
                directories=[d],
                once=True,
                stability_window_seconds=0,
                category="Familie Kurmann-Glück",
            ),
        )

    assert captured_kwargs[0]["category"] == "Familie Kurmann-Glück"


def test_directory_exception_emits_event(tmp_path: Path):
    """Wenn run_publish_directory crasht, muss der Grund als DEPLOY_FAILED-Event erscheinen.

    Vor v0.10.0 wurde die Exception nur in tick_result.error_messages gehängt
    und nirgends ausgegeben — der User sah nur „0 von allem" im Tick-Summary
    (Bug aufgedeckt durch PermissionError auf iCloud-notification.file).
    """
    d = tmp_path / "watched"
    d.mkdir()
    events: list[FamilienfilmEvent] = []

    def boom(directory, **kwargs):  # noqa: ARG001
        raise PermissionError("Operation not permitted: notification.file")

    with patch(
        "familienfilm_manager.core.directory_watcher.run_publish_directory",
        side_effect=boom,
    ):
        run_watch(
            WatchRequest(directories=[d], once=True, stability_window_seconds=0),
            on_event=events.append,
        )

    failed = [e for e in events if e.stage_id == FamilienfilmStage.DEPLOY_FAILED]
    assert failed, f"DEPLOY_FAILED-Event erwartet, got: {[e.stage_id for e in events]}"
    assert "Operation not permitted" in failed[0].message


def test_directory_level_failure_emits_event(tmp_path: Path):
    """Wenn run_publish_directory ohne Exception zurückkommt, aber success=False
    + error_message gesetzt hat (z.B. fehlendes Target), wird ebenfalls
    ein DEPLOY_FAILED-Event emittiert."""
    d = tmp_path / "watched"
    d.mkdir()
    events: list[FamilienfilmEvent] = []

    def fail(directory, **kwargs):  # noqa: ARG001
        return DirectoryPublishResult(
            success=False, directory=directory,
            error_message="targets.archive nicht konfiguriert",
        )

    with patch(
        "familienfilm_manager.core.directory_watcher.run_publish_directory",
        side_effect=fail,
    ):
        run_watch(
            WatchRequest(directories=[d], once=True, stability_window_seconds=0),
            on_event=events.append,
        )

    failed = [e for e in events if e.stage_id == FamilienfilmStage.DEPLOY_FAILED]
    assert failed, "DEPLOY_FAILED-Event bei dir-level error erwartet"
    assert "targets.archive" in failed[0].message
