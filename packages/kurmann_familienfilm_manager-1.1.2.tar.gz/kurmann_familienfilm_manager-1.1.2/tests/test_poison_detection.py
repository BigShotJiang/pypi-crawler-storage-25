"""Tests für die v0.11.0 Poison-Video-Detection im directory_publisher."""

from __future__ import annotations

from pathlib import Path

from familienfilm_manager.core.sidecar_manager import (
    POISON_FAILURE_THRESHOLD,
    SidecarSettings,
    clear_publish_failures,
    is_poisoned,
    read_sidecar,
    record_publish_failure,
    write_sidecar,
)


def test_is_poisoned_below_threshold_returns_false():
    sidecar = SidecarSettings(publish_failure_count=POISON_FAILURE_THRESHOLD - 1)
    assert is_poisoned(sidecar, current_fingerprint=(100, "abc")) is False


def test_is_poisoned_at_threshold_with_unchanged_source_returns_true():
    sidecar = SidecarSettings(
        publish_failure_count=POISON_FAILURE_THRESHOLD,
        web_source_size_bytes=100,
        web_source_head_sha1="abc",
    )
    assert is_poisoned(sidecar, current_fingerprint=(100, "abc")) is True


def test_is_poisoned_resets_when_source_size_changed():
    """Wenn die Source-Größe sich geändert hat, neuer Versuch verdient — kein Poison."""
    sidecar = SidecarSettings(
        publish_failure_count=POISON_FAILURE_THRESHOLD,
        web_source_size_bytes=100,
        web_source_head_sha1="abc",
    )
    assert is_poisoned(sidecar, current_fingerprint=(200, "def")) is False


def test_is_poisoned_resets_when_source_head_changed():
    sidecar = SidecarSettings(
        publish_failure_count=POISON_FAILURE_THRESHOLD,
        web_source_size_bytes=100,
        web_source_head_sha1="abc",
    )
    assert is_poisoned(sidecar, current_fingerprint=(100, "different-hash")) is False


def test_is_poisoned_with_no_failure_count():
    sidecar = SidecarSettings()
    assert is_poisoned(sidecar, current_fingerprint=(100, "abc")) is False


def test_is_poisoned_uses_legacy_global_fingerprint_as_fallback():
    """Wenn kein per-Kanal-Fingerprint da, fällt is_poisoned auf [source]-Block zurück."""
    sidecar = SidecarSettings(
        publish_failure_count=POISON_FAILURE_THRESHOLD,
        source_size_bytes=100,
        source_head_sha1="abc",
    )
    assert is_poisoned(sidecar, current_fingerprint=(100, "abc")) is True
    assert is_poisoned(sidecar, current_fingerprint=(999, "abc")) is False


def test_record_publish_failure_increments_counter(tmp_path: Path):
    video = tmp_path / "v.mov"
    video.write_bytes(b"x")
    record_publish_failure(video, reason="erste fehler")
    record_publish_failure(video, reason="zweiter fehler")
    s = read_sidecar(video)
    assert s.publish_failure_count == 2
    assert s.publish_last_failure_reason == "zweiter fehler"
    assert s.publish_last_failure_at is not None


def test_record_publish_failure_resets_on_source_change(tmp_path: Path):
    video = tmp_path / "v.mov"
    video.write_bytes(b"x")
    # Initial: 2 Fehler mit Fingerprint A
    write_sidecar(video, SidecarSettings(
        publish_failure_count=2,
        web_source_size_bytes=100,
    ))
    # Neuer Aufruf mit anderer Size → reset auf 0+1=1
    record_publish_failure(video, reason="neu", current_fingerprint=(999, None))
    s = read_sidecar(video)
    assert s.publish_failure_count == 1


def test_clear_publish_failures_removes_all(tmp_path: Path):
    video = tmp_path / "v.mov"
    video.write_bytes(b"x")
    write_sidecar(video, SidecarSettings(
        publish_failure_count=5,
        publish_last_failure_at="2026-04-28T10:00:00",
        publish_last_failure_reason="oops",
    ))
    clear_publish_failures(video)
    s = read_sidecar(video)
    assert s.publish_failure_count is None
    assert s.publish_last_failure_at is None
    assert s.publish_last_failure_reason is None


def test_clear_publish_failures_noop_if_none(tmp_path: Path):
    video = tmp_path / "v.mov"
    video.write_bytes(b"x")
    # Keine Sidecar — sollte nicht crashen
    clear_publish_failures(video)


def test_sidecar_roundtrip_preserves_publish_block(tmp_path: Path):
    video = tmp_path / "v.mov"
    video.write_bytes(b"x")
    write_sidecar(video, SidecarSettings(
        publish_failure_count=3,
        publish_last_failure_at="2026-04-28T10:00:00",
        publish_last_failure_reason="test fehler",
        poster_selected_by="ai",
        poster_ai_reasoning="Frame 142 zeigt schönes Lächeln",
    ))
    s = read_sidecar(video)
    assert s.publish_failure_count == 3
    assert s.publish_last_failure_reason == "test fehler"
    assert s.poster_selected_by == "ai"
    assert s.poster_ai_reasoning == "Frame 142 zeigt schönes Lächeln"


def test_poster_ai_reasoning_multiline(tmp_path: Path):
    """KI-Begründung kann mehrzeilig sein — wird als TOML-Multiline geschrieben."""
    video = tmp_path / "v.mov"
    video.write_bytes(b"x")
    multiline = "Zeile 1: gutes Bild\nZeile 2: scharfer Fokus\nMit \"Quotes\" und \\backslash"
    write_sidecar(video, SidecarSettings(
        poster_selected_by="ai",
        poster_ai_reasoning=multiline,
    ))
    s = read_sidecar(video)
    assert s.poster_ai_reasoning == multiline


# ── poster_selected_by-Werte (v0.11.0 Verfeinerung) ──


def test_sidecar_persists_all_selected_by_values(tmp_path: Path):
    """Roundtrip aller dokumentierten selected_by-Werte."""
    video = tmp_path / "v.mov"
    video.write_bytes(b"x")
    for value in ("cli", "filename", "sidecar", "ai", "sidecar-image"):
        write_sidecar(video, SidecarSettings(
            timestamp_seconds=42.0,
            poster_selected_by=value,
        ))
        s = read_sidecar(video)
        assert s.poster_selected_by == value, f"Roundtrip-Fehler für {value!r}"


# ── Sidecar-Schema-Versioning (v0.12.0) ──


def test_sidecar_write_always_emits_schema_version(tmp_path: Path):
    from familienfilm_manager.core.sidecar_manager import (
        SETTINGS_SCHEMA_VERSION,
        SidecarSettings,
        read_sidecar,
        write_sidecar,
    )
    video = tmp_path / "v.mov"
    video.write_bytes(b"x")
    write_sidecar(video, SidecarSettings(timestamp_seconds=42.0))
    s = read_sidecar(video)
    assert s.schema_version == SETTINGS_SCHEMA_VERSION


def test_sidecar_read_pre_v012_without_schema_version(tmp_path: Path):
    """Bestehende v0.11.x-Sidecars (ohne [meta]-Block) werden weiter gelesen."""
    from familienfilm_manager.core.sidecar_manager import read_sidecar

    video = tmp_path / "v.mov"
    video.write_bytes(b"x")
    sidecar_path = tmp_path / "v.settings.toml"
    sidecar_path.write_text("""
[poster]
frame_number = 42

[metadata]
category = "Test"
""", encoding="utf-8")

    s = read_sidecar(video)
    assert s.frame_number == 42
    assert s.category == "Test"
    # schema_version fehlt → None (= pre-v0.12.0-Sidecar)
    assert s.schema_version is None
