"""Tests für das optionale Source-Delete (v0.9.0)."""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import patch

from familienfilm_manager.core.source_delete import delete_source
from familienfilm_manager.core.source_ref import SourceRef


def test_delete_local_video_and_sidecar(tmp_path: Path):
    video = tmp_path / "2026-04-18 Test.mov"
    video.write_bytes(b"x")
    sidecar = tmp_path / "2026-04-18 Test.settings.toml"
    sidecar.write_text("[web]\n", encoding="utf-8")
    other = tmp_path / "2026-04-18 Test.fcpxml"
    other.write_text("<xml/>", encoding="utf-8")

    removed = delete_source(SourceRef(str(video)))

    assert not video.exists()
    assert not sidecar.exists()
    # .fcpxml bleibt (gehört zum Editing-Projekt)
    assert other.exists()
    assert str(video) in removed
    assert str(sidecar) in removed


def test_delete_local_without_sidecar_ok(tmp_path: Path):
    video = tmp_path / "2026-04-18 Test.mov"
    video.write_bytes(b"x")

    removed = delete_source(SourceRef(str(video)))

    assert not video.exists()
    assert removed == [str(video)]


def test_delete_rclone_calls_deletefile_for_video_and_sidecar():
    calls: list[list[str]] = []

    def fake_run(*args, **kwargs):
        calls.append(list(args[0]))
        return subprocess.CompletedProcess(args=args[0], returncode=0, stdout="", stderr="")

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        removed = delete_source(SourceRef("nas:/Quelle/2026-04-18 Test.mov"))

    video_calls = [c for c in calls if c[1] == "deletefile" and c[2].endswith(".mov")]
    sidecar_calls = [c for c in calls if c[1] == "deletefile" and c[2].endswith(".settings.toml")]
    assert len(video_calls) == 1
    assert len(sidecar_calls) == 1
    assert "nas:/Quelle/2026-04-18 Test.mov" in removed


def test_delete_rclone_tolerates_missing_sidecar():
    """Wenn die rclone-Seite kein Sidecar hat, darf delete_source nicht fehlschlagen."""
    state = {"call_idx": 0}

    def fake_run(*args, **kwargs):
        state["call_idx"] += 1
        args_list = args[0]
        # Erster Call: Video-Löschen OK. Zweiter Call: Sidecar → fehlt.
        if state["call_idx"] == 1:
            return subprocess.CompletedProcess(args=args_list, returncode=0, stdout="", stderr="")
        err = subprocess.CalledProcessError(1, args_list)
        err.stderr = "file does not exist"
        raise err

    with patch("familienfilm_manager.core._rclone.subprocess.run", side_effect=fake_run):
        with patch("familienfilm_manager.core._rclone.time.sleep"):
            removed = delete_source(SourceRef("nas:/Quelle/foo.mov"))

    # Video ist drin, Sidecar nicht — aber kein Crash
    assert "nas:/Quelle/foo.mov" in removed
