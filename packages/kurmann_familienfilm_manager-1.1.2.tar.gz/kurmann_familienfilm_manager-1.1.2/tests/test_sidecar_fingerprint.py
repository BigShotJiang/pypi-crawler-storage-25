"""Tests für Fingerprint-Persistierung im Sidecar (Size + Head-SHA1)."""

from pathlib import Path

from familienfilm_manager.core.sidecar_manager import (
    HEAD_HASH_BYTES,
    SidecarSettings,
    compute_source_fingerprint,
    read_sidecar,
    write_sidecar,
)


def test_fingerprint_reflects_size_and_head_hash(tmp_path: Path):
    """Fingerprint enthält korrekte Dateigrösse und SHA1 der ersten 1 MB."""
    import hashlib

    f = tmp_path / "video.mov"
    payload = b"A" * (HEAD_HASH_BYTES + 100)  # 1 MB + Rest
    f.write_bytes(payload)

    size, head = compute_source_fingerprint(f)

    assert size == len(payload)
    assert head == hashlib.sha1(payload[:HEAD_HASH_BYTES]).hexdigest()


def test_fingerprint_small_file(tmp_path: Path):
    """Dateien kleiner als 1 MB: Hash über gesamte Datei."""
    import hashlib

    f = tmp_path / "small.mov"
    f.write_bytes(b"tiny")

    size, head = compute_source_fingerprint(f)
    assert size == 4
    assert head == hashlib.sha1(b"tiny").hexdigest()


def test_sidecar_roundtrip_per_channel_fingerprint(tmp_path: Path):
    """Per-Kanal Fingerprint (v0.8.0+) wird korrekt geschrieben und gelesen."""
    video = tmp_path / "video.mov"
    video.touch()

    original = SidecarSettings(
        web_id="abc123456789",
        web_published_at="2026-04-18T10:00:00",
        web_source_size_bytes=123456789,
        web_source_head_sha1="deadbeef" * 5,
    )
    write_sidecar(video, original)

    parsed = read_sidecar(video)
    assert parsed.web_source_size_bytes == 123456789
    assert parsed.web_source_head_sha1 == "deadbeef" * 5
    assert parsed.web_id == "abc123456789"
    assert parsed.web_published_at == "2026-04-18T10:00:00"


def test_sidecar_without_fingerprint_is_readable(tmp_path: Path):
    """Altes Sidecar ohne [source]-Sektion liefert None für Fingerprint-Felder."""
    video = tmp_path / "video.mov"
    video.touch()

    legacy_sidecar = video.parent / f"{video.stem}.settings.toml"
    legacy_sidecar.write_text(
        '[web]\nweb_id = "abc123456789"\npublished_at = "2026-04-18T10:00:00"\n',
        encoding="utf-8",
    )

    parsed = read_sidecar(video)
    assert parsed.web_id == "abc123456789"
    assert parsed.web_published_at == "2026-04-18T10:00:00"
    assert parsed.source_size_bytes is None
    assert parsed.source_head_sha1 is None


def test_legacy_global_source_read_fallback(tmp_path: Path):
    """Sidecar aus ≤ v0.7.0 mit globalem [source]-Block wird weiterhin gelesen
    und via ``fingerprint_for_channel`` als Fallback geliefert."""
    video = tmp_path / "video.mov"
    video.touch()

    (video.parent / f"{video.stem}.settings.toml").write_text(
        '[web]\npublished_at = "2026-04-18T10:00:00"\n'
        '[local]\npublished_at = "2026-04-18T10:01:00"\n'
        '[source]\nsize_bytes = 42\nhead_sha1 = "ab12"\n',
        encoding="utf-8",
    )

    parsed = read_sidecar(video)
    # Legacy-Felder werden gelesen
    assert parsed.source_size_bytes == 42
    assert parsed.source_head_sha1 == "ab12"
    # Pro Kanal: kein per-Kanal-Wert → Fallback auf Legacy
    assert parsed.fingerprint_for_channel("web") == (42, "ab12")
    assert parsed.fingerprint_for_channel("local") == (42, "ab12")


def test_per_channel_fingerprint_wins_over_legacy(tmp_path: Path):
    """Wenn ein Kanal per-Kanal-Fingerprint hat, gewinnt dieser gegen Legacy."""
    video = tmp_path / "video.mov"
    video.touch()

    (video.parent / f"{video.stem}.settings.toml").write_text(
        '[web]\npublished_at = "2026-04-18T10:00:00"\n'
        'source_size_bytes = 999\nsource_head_sha1 = "new1"\n'
        '[source]\nsize_bytes = 42\nhead_sha1 = "old1"\n',
        encoding="utf-8",
    )

    parsed = read_sidecar(video)
    assert parsed.fingerprint_for_channel("web") == (999, "new1")
    # Andere Kanäle fallen weiter auf Legacy zurück
    assert parsed.fingerprint_for_channel("local") == (42, "old1")


def test_v080_does_not_write_legacy_source_block(tmp_path: Path):
    """v0.8.0+ schreibt kein globales [source] mehr — nur per-Kanal-Fingerprints."""
    video = tmp_path / "video.mov"
    video.touch()
    write_sidecar(video, SidecarSettings(
        web_published_at="2026-04-18T10:00:00",
        web_source_size_bytes=100,
        web_source_head_sha1="aa",
    ))
    toml_content = (video.parent / f"{video.stem}.settings.toml").read_text()
    assert "[source]" not in toml_content
    # Per-Kanal-Fingerprint steht im [web]-Block
    assert "source_size_bytes = 100" in toml_content


def test_sidecar_roundtrip_with_metadata_category(tmp_path: Path):
    """[metadata].category wird korrekt geschrieben und gelesen — macht das TAR selbsttragend."""
    video = tmp_path / "video.mov"
    video.touch()

    original = SidecarSettings(
        web_id="abc123456789",
        web_published_at="2026-04-18T10:00:00",
        category="Familie Kurmann-Glück",
    )
    write_sidecar(video, original)

    parsed = read_sidecar(video)
    assert parsed.category == "Familie Kurmann-Glück"


# ── Per-Kanal published_at ──


def test_sidecar_roundtrip_all_three_channels(tmp_path: Path):
    """Alle drei Kanäle [web]/[local]/[archive] werden korrekt gelesen/geschrieben."""
    video = tmp_path / "video.mov"
    video.touch()

    original = SidecarSettings(
        web_id="abc123456789",
        web_published_at="2026-04-18T10:00:00",
        local_published_at="2026-04-18T10:01:00",
        archive_published_at="2026-04-18T10:02:00",
    )
    write_sidecar(video, original)

    parsed = read_sidecar(video)
    assert parsed.web_published_at == "2026-04-18T10:00:00"
    assert parsed.local_published_at == "2026-04-18T10:01:00"
    assert parsed.archive_published_at == "2026-04-18T10:02:00"


def test_legacy_pre_channels_flag(tmp_path: Path):
    """is_legacy_pre_channels erkennt alte Sidecars mit nur [web].published_at."""
    video = tmp_path / "video.mov"
    video.touch()

    legacy = SidecarSettings(
        web_id="abc",
        web_published_at="2026-04-18T10:00:00",
        # keine local/archive
    )
    assert legacy.is_legacy_pre_channels is True

    full = SidecarSettings(
        web_published_at="2026-04-18T10:00:00",
        local_published_at="2026-04-18T10:01:00",
        archive_published_at="2026-04-18T10:02:00",
    )
    assert full.is_legacy_pre_channels is False

    empty = SidecarSettings()
    assert empty.is_legacy_pre_channels is False


def test_sidecar_reads_partial_channels(tmp_path: Path):
    """Wenn nur web + local gesetzt sind, bleibt archive_published_at None."""
    video = tmp_path / "video.mov"
    video.touch()

    write_sidecar(video, SidecarSettings(
        web_published_at="t1",
        local_published_at="t2",
    ))

    parsed = read_sidecar(video)
    assert parsed.web_published_at == "t1"
    assert parsed.local_published_at == "t2"
    assert parsed.archive_published_at is None


def test_sidecar_category_with_quotes_is_escaped(tmp_path: Path):
    """Kategorie-Werte mit Anführungszeichen landen korrekt im TOML (ohne Syntax-Bruch)."""
    video = tmp_path / "video.mov"
    video.touch()

    tricky = 'Familie "Kurmann" & Co'
    write_sidecar(video, SidecarSettings(category=tricky))

    parsed = read_sidecar(video)
    assert parsed.category == tricky


def test_sidecar_without_metadata_section_returns_none(tmp_path: Path):
    """Sidecar ohne [metadata]-Sektion: category ist None."""
    video = tmp_path / "video.mov"
    video.touch()

    legacy = video.parent / f"{video.stem}.settings.toml"
    legacy.write_text('[web]\nweb_id = "x"\n', encoding="utf-8")

    parsed = read_sidecar(video)
    assert parsed.category is None


# ── web_enabled (v0.8.0) ──


def test_web_enabled_roundtrip_true(tmp_path: Path):
    """``[web].enabled = true`` wird korrekt geschrieben und gelesen."""
    video = tmp_path / "video.mov"
    video.touch()

    write_sidecar(video, SidecarSettings(web_enabled=True, local_published_at="x"))
    parsed = read_sidecar(video)
    assert parsed.web_enabled is True


def test_web_enabled_roundtrip_false(tmp_path: Path):
    """``[web].enabled = false`` (expliziter Opt-out) wird persistiert."""
    video = tmp_path / "video.mov"
    video.touch()

    write_sidecar(video, SidecarSettings(web_enabled=False, local_published_at="x"))
    parsed = read_sidecar(video)
    assert parsed.web_enabled is False


def test_web_enabled_none_not_written(tmp_path: Path):
    """``web_enabled=None`` (nicht gesetzt) erzeugt keine ``enabled``-Zeile."""
    video = tmp_path / "video.mov"
    video.touch()

    write_sidecar(video, SidecarSettings(local_published_at="x"))
    toml_content = (video.parent / f"{video.stem}.settings.toml").read_text()
    assert "enabled" not in toml_content


def test_web_enabled_read_from_toml(tmp_path: Path):
    """Manuell gepflegtes ``[web] enabled = true`` wird gelesen."""
    video = tmp_path / "video.mov"
    video.touch()
    (video.parent / f"{video.stem}.settings.toml").write_text(
        '[web]\nenabled = true\n', encoding="utf-8",
    )

    parsed = read_sidecar(video)
    assert parsed.web_enabled is True
