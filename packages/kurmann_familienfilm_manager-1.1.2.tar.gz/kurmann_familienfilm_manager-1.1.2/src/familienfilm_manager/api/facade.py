"""Öffentliche Fassade – delegiert an Core-Module mit Fehlerbehandlung."""

from __future__ import annotations

from typing import Callable

from pathlib import Path

from familienfilm_manager.api.models import (
    ArchiveRequest,
    ArchiveResult,
    DeployRequest,
    DeployResult,
    DirectoryPublishResult,
    FamilienfilmEvent,
    PublishRequest,
    PublishResult,
    RuntimeOptions,
    WatchRequest,
    WatchResult,
)


def publish(
    request: PublishRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[FamilienfilmEvent], None] | None = None,
) -> PublishResult:
    """Veröffentlicht ein Video: Medienset erstellen + optional Infuse/Web/Archiv."""
    from familienfilm_manager.core.publisher import run_publish

    try:
        return run_publish(request, runtime, on_event)
    except Exception as e:
        return PublishResult(success=False, error_message=str(e))


def publish_directory(
    directory: Path | str,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[FamilienfilmEvent], None] | None = None,
    skip_infuse: bool = False,
    skip_web: bool = False,
    web_enabled: bool = False,
    skip_archive: bool = False,
    force: bool = False,
    dry_run: bool = False,
    work_dir: Path | None = None,
    stability_window_seconds: int = 0,
    category: str | None = None,
    recursive: bool = False,
    delete_source_after_publish: bool = False,
    web_cleanup_dry_run: bool = False,
) -> DirectoryPublishResult:
    """Publiziert alle qualifizierten Videos in einem Verzeichnis sequenziell.

    Filtert nach Muster ``<YYYY-MM-DD> <titel>.<ext>`` und bekannten Video-Endungen.
    Sortiert chronologisch (älteste zuerst). Überspringt bereits publizierte Videos
    (Sidecar-``published_at``), sofern weder Video noch Sidecar geändert wurden.

    Args:
        work_dir: Arbeitsverzeichnis für temporäre Dateien (gilt für jedes Video
            im Batch). Wird auch an mediaset-creator durchgereicht. Standard:
            Verzeichnis des jeweiligen Quellvideos.
    """
    from familienfilm_manager.core.directory_publisher import run_publish_directory

    try:
        return run_publish_directory(
            directory=directory,
            runtime=runtime,
            on_event=on_event,
            skip_infuse=skip_infuse,
            skip_web=skip_web,
            web_enabled=web_enabled,
            skip_archive=skip_archive,
            force=force,
            dry_run=dry_run,
            work_dir=work_dir,
            stability_window_seconds=stability_window_seconds,
            category=category,
            recursive=recursive,
            delete_source_after_publish=delete_source_after_publish,
            web_cleanup_dry_run=web_cleanup_dry_run,
        )
    except Exception as e:
        return DirectoryPublishResult(
            success=False, directory=directory, error_message=str(e),
        )


def deploy_infuse(
    request: DeployRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[FamilienfilmEvent], None] | None = None,
) -> DeployResult:
    """Deployt ein bestehendes Verzeichnis mit Infuse-Dateien."""
    from familienfilm_manager.core.infuse_deployer import deploy_to_infuse

    rt = runtime or RuntimeOptions()
    try:
        return deploy_to_infuse(
            source_dir=request.source_dir,
            infuse_target=rt.infuse_target,
            rclone_path=rt.rclone_path,
            group_by=rt.infuse_group_by,
            on_event=on_event,
        )
    except Exception as e:
        return DeployResult(success=False, error_message=str(e))


def deploy_web(
    request: DeployRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[FamilienfilmEvent], None] | None = None,
) -> DeployResult:
    """Deployt ein Web-Medienset-Verzeichnis zum Webserver."""
    from familienfilm_manager.core.web_deployer import deploy_to_web

    rt = runtime or RuntimeOptions()
    try:
        return deploy_to_web(
            source_dir=request.source_dir,
            web_target=rt.web_target,
            rclone_path=rt.rclone_path,
            on_event=on_event,
        )
    except Exception as e:
        return DeployResult(success=False, error_message=str(e))


def archive(
    request: ArchiveRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[FamilienfilmEvent], None] | None = None,
) -> ArchiveResult:
    """Archiviert eine Videodatei als ISO und verschiebt sie zum Archiv-Ziel."""
    from familienfilm_manager.core.archiver import archive_video

    rt = runtime or RuntimeOptions()
    try:
        return archive_video(
            source_path=request.source_path,
            archive_target=rt.archive_target,
            rclone_path=rt.rclone_path,
            recording_date=request.recording_date,
            title=request.title,
            description=getattr(request, "description", None),
            work_dir=request.work_dir,
            on_event=on_event,
        )
    except Exception as e:
        return ArchiveResult(success=False, error_message=str(e))


def watch_directories(
    request: WatchRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[FamilienfilmEvent], None] | None = None,
) -> WatchResult:
    """Überwacht ein oder mehrere Verzeichnisse und publiziert neue Videos.

    Jeder Tick ruft ``publish_directory()`` pro konfiguriertem Verzeichnis auf
    und nutzt die Fingerprint-basierte Idempotenz für das Überspringen
    bereits publizierter Videos. Fehler in einem Verzeichnis brechen den
    Lauf nicht ab — die anderen Verzeichnisse werden weiter verarbeitet und
    beim nächsten Tick wird erneut versucht.

    Mit ``request.once=True`` läuft genau ein Tick (launchd/cron-kompatibel),
    ansonsten Endlosschleife mit ``request.interval_seconds`` zwischen Ticks.
    SIGTERM und SIGINT beenden die Schleife sauber nach dem laufenden Tick.
    """
    from familienfilm_manager.core.directory_watcher import run_watch

    return run_watch(request, runtime, on_event)
