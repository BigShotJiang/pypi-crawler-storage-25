"""CLI-Adapter für den Familienfilm Manager."""

import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from familienfilm_manager.api import (
    ArchiveRequest,
    DeployRequest,
    FamilienfilmEvent,
    FamilienfilmStage,
    PublishRequest,
    RuntimeOptions,
    VideoStatusKind,
    WatchRequest,
    archive,
    deploy_infuse,
    deploy_web,
    publish,
    publish_directory,
    watch_directories,
)
from familienfilm_manager.services import config_manager


def _parse_duration(value: str) -> int:
    """Parst Dauer-Angaben mit optionalem Suffix: '30s', '5m', '2h', oder '600'.

    Nackte Zahlen werden als Sekunden interpretiert.
    """
    v = value.strip().lower()
    if not v:
        raise ValueError("Leere Dauer-Angabe")
    multipliers = {"s": 1, "m": 60, "h": 3600, "d": 86400}
    if v[-1] in multipliers:
        unit = v[-1]
        try:
            return int(float(v[:-1]) * multipliers[unit])
        except ValueError as e:
            raise ValueError(f"Ungültige Dauer-Angabe '{value}': {e}") from None
    try:
        return int(v)
    except ValueError:
        raise ValueError(
            f"Ungültige Dauer-Angabe '{value}'. Erlaubt: Zahl (Sekunden) oder mit Suffix s/m/h/d."
        ) from None


def _resolve_watch_directories(cli_dirs: list[str] | list[Path] | None) -> list[Path | str]:
    """Auflösung der Watch-Verzeichnisse: CLI > Config.

    CLI: eine oder mehrere ``-d/--directory``-Optionen (mehrfach angebbar).
    Config: komma-separiert in ``watch.directories``.

    Ab v0.7.0 können sowohl lokale Pfade als auch rclone-URIs (``remote:path``)
    gemischt angegeben werden. Lokale Pfade werden zu ``Path`` (mit ``~``-
    Expansion), rclone-URIs bleiben als String.
    """
    def _normalize(entry: str | Path) -> Path | str:
        from familienfilm_manager.core.source_ref import _looks_like_rclone_uri
        # Path-Objekte (z.B. aus Tests) werden direkt durchgereicht
        if isinstance(entry, Path):
            return entry
        if _looks_like_rclone_uri(entry):
            return entry
        return Path(entry).expanduser()

    if cli_dirs:
        return [_normalize(d) for d in cli_dirs]
    config_value = config_manager.get("watch.directories")
    if config_value:
        return [_normalize(p.strip()) for p in config_value.split(",") if p.strip()]
    return []

app = typer.Typer(invoke_without_command=True)
config_app = typer.Typer()
app.add_typer(config_app, name="config", help="Konfiguration verwalten.")
web_storage_app = typer.Typer(help="Web-Speicher-Status und -Verwaltung (v0.11.0+).")
app.add_typer(web_storage_app, name="web-storage")

stderr_console = Console(stderr=True)


def _build_runtime() -> RuntimeOptions:
    """Baut RuntimeOptions aus der Konfiguration."""
    # v0.10.0: Web-Storage-Budget aus Config parsen ('500GB' → Bytes).
    # Leerer/ungültiger Wert → None = unbegrenzt (kein automatischer Cleanup).
    budget_str = config_manager.get_with_default("web.storage_budget")
    web_budget_bytes: int | None = None
    if budget_str.strip():
        try:
            from familienfilm_manager.core.web_storage import parse_size
            web_budget_bytes = parse_size(budget_str)
        except ValueError as e:
            stderr_console.print(
                f"[yellow]Hinweis:[/yellow] web.storage_budget = {budget_str!r} "
                f"konnte nicht geparst werden ({e}); kein Cleanup aktiv."
            )

    # v0.10.0: Web-Max-Age aus Config (Integer-String, leer = aus).
    age_str = config_manager.get_with_default("web.max_age_days")
    web_max_age_days: int | None = None
    if age_str.strip():
        try:
            web_max_age_days = int(age_str.strip())
            if web_max_age_days <= 0:
                web_max_age_days = None
        except ValueError:
            stderr_console.print(
                f"[yellow]Hinweis:[/yellow] web.max_age_days = {age_str!r} "
                f"konnte nicht als Integer geparst werden; keine Altersbegrenzung aktiv."
            )

    return RuntimeOptions(
        infuse_target=config_manager.get_with_default("targets.infuse"),
        web_target=config_manager.get_with_default("targets.web"),
        archive_target=config_manager.get_with_default("targets.archive"),
        infuse_group_by=config_manager.get_with_default("infuse.group_by"),
        branding_base_url=config_manager.get_with_default("mediaset.branding_base_url"),
        branding_site_name=config_manager.get_with_default("mediaset.branding_site_name"),
        ffmpeg_path=config_manager.get_with_default("tools.ffmpeg"),
        ffprobe_path=config_manager.get_with_default("tools.ffprobe"),
        rclone_path=config_manager.get_with_default("tools.rclone"),
        web_storage_budget_bytes=web_budget_bytes,
        web_max_age_days=web_max_age_days,
    )


def _resolve_web_budget_override(value: Optional[str]) -> Optional[int]:
    """Parst --web-budget zu Bytes oder None bei leer/unparsbar (mit Hinweis)."""
    if value is None:
        return None
    try:
        from familienfilm_manager.core.web_storage import parse_size
        return parse_size(value)
    except ValueError as e:
        stderr_console.print(
            f"[yellow]Hinweis:[/yellow] --web-budget {value!r} konnte nicht "
            f"geparst werden ({e}); Config-Wert bleibt aktiv."
        )
        return None


def _resolve_work_dir(cli_work_dir: Optional[Path]) -> Optional[Path]:
    """Auflösung des Arbeitsverzeichnisses: CLI > Config > None.

    None bedeutet: Publisher fällt auf Quellverzeichnis zurück.
    """
    if cli_work_dir is not None:
        return cli_work_dir
    config_value = config_manager.get("paths.work_dir")
    if config_value:
        return Path(config_value).expanduser()
    return None


def _make_event_callback(verbose: bool):
    """Erstellt einen Event-Callback für die CLI."""
    ALWAYS_SHOW = {
        FamilienfilmStage.MEDIASET_CREATED,
        FamilienfilmStage.INFUSE_DEPLOYED,
        FamilienfilmStage.WEB_DEPLOYED,
        FamilienfilmStage.ARCHIVED,
        FamilienfilmStage.SOURCE_DELETED,
        FamilienfilmStage.SOURCE_DELETE_SKIPPED,
        FamilienfilmStage.PUBLISH_COMPLETED,
        FamilienfilmStage.DIRECTORY_SCANNED,
        FamilienfilmStage.DIRECTORY_VIDEO_STARTED,
        FamilienfilmStage.DIRECTORY_VIDEO_UNSTABLE,
        FamilienfilmStage.WATCH_STARTED,
        FamilienfilmStage.WATCH_TICK_COMPLETED,
        FamilienfilmStage.WATCH_STOPPED,
        # Fehler- und Retry-Events sind immer sichtbar (egal ob -v)
        FamilienfilmStage.DEPLOY_RETRY,
        FamilienfilmStage.DEPLOY_FAILED,
        FamilienfilmStage.DEPLOYMENT_VERIFIED,
        FamilienfilmStage.WEB_BUDGET_CHECK,
        FamilienfilmStage.WEB_CLEANUP_DELETED,
        FamilienfilmStage.WEB_CLEANUP_DRY_RUN,
        FamilienfilmStage.WEB_BUDGET_EXCEEDED,
    }

    def on_event(event: FamilienfilmEvent) -> None:
        if not verbose and event.stage_id not in ALWAYS_SHOW:
            return
        if event.stage_id == FamilienfilmStage.DEPLOY_FAILED:
            stderr_console.print(f"  [red]{event.message}[/red]")
        elif event.stage_id == FamilienfilmStage.DEPLOY_RETRY:
            stderr_console.print(f"  [yellow]{event.message}[/yellow]")
        elif event.stage_id == FamilienfilmStage.DEPLOYMENT_VERIFIED:
            stderr_console.print(f"  [green]✓[/green] {event.message}")
        elif event.stage_id == FamilienfilmStage.SOURCE_DELETED:
            stderr_console.print(f"  [green]✓[/green] {event.message}")
        elif event.stage_id == FamilienfilmStage.SOURCE_DELETE_SKIPPED:
            stderr_console.print(f"  [yellow]{event.message}[/yellow]")
        elif event.stage_id == FamilienfilmStage.WEB_CLEANUP_DELETED:
            stderr_console.print(f"  [yellow]{event.message}[/yellow]")
        elif event.stage_id == FamilienfilmStage.WEB_CLEANUP_DRY_RUN:
            stderr_console.print(f"  [cyan]{event.message}[/cyan]")
        elif event.stage_id == FamilienfilmStage.WEB_BUDGET_EXCEEDED:
            stderr_console.print(f"  [red]{event.message}[/red]")
        else:
            stderr_console.print(f"  {event.message}")

    return on_event


@app.callback()
def main(ctx: typer.Context) -> None:
    """Familienfilm Manager – Veröffentlichung von Familienfilmen."""
    if ctx.invoked_subcommand is None:
        ctx.get_help()


# ---------------------------------------------------------------------------
# publish – Gesamtworkflow
# ---------------------------------------------------------------------------

@app.command(name="publish")
def publish_cmd(
    video: Path = typer.Argument(
        ...,
        help="Pfad zur Videodatei.",
        exists=True,
        dir_okay=False,
    ),
    title: Optional[str] = typer.Option(
        None,
        "--title",
        help="Video-Titel (überschreibt Metadaten).",
    ),
    description: Optional[str] = typer.Option(
        None,
        "--description",
        help="Beschreibung des Videos.",
    ),
    category: Optional[str] = typer.Option(
        None,
        "--category",
        help="Kategorie (z.B. 'Familie Kurmann-Glück').",
    ),
    date: Optional[str] = typer.Option(
        None,
        "--date",
        help="Aufnahmedatum im ISO-Format (YYYY-MM-DD).",
    ),
    output_dir: Optional[Path] = typer.Option(
        None,
        "--output-dir",
        help="Basisverzeichnis für die Web-Medienset-Ausgabe.",
    ),
    work_dir: Optional[Path] = typer.Option(
        None,
        "--work-dir",
        help="Arbeitsverzeichnis für temporäre Dateien (Standard: Verzeichnis der Quelldatei).",
    ),
    no_infuse: bool = typer.Option(
        False,
        "--no-infuse",
        help="Infuse-Deployment überspringen.",
    ),
    no_web: bool = typer.Option(
        False,
        "--no-web",
        help="Web-Deployment überspringen (One-Shot-Override, gewinnt gegen alles).",
    ),
    web: bool = typer.Option(
        False,
        "--web",
        help="Web-Deployment aktivieren (One-Shot-Override, falls in "
             "familienfilm.toml/Sidecar nicht explizit ``web_enabled = true`` gesetzt).",
    ),
    no_archive: bool = typer.Option(
        False,
        "--no-archive",
        help="Archivierung überspringen.",
    ),
    poster_frame: Optional[int] = typer.Option(
        None,
        "--poster-frame",
        help="Frame-Nummer für Vorschaubild (überspringt KI-Auswahl).",
    ),
    poster_at: Optional[float] = typer.Option(
        None,
        "--poster-at",
        help="Zeitpunkt in Sekunden für Vorschaubild (z.B. 90 oder 1.5).",
    ),
    poster_crop: Optional[str] = typer.Option(
        None,
        "--poster-crop",
        help="Bildausschnitt für Poster (left/center-left/center/center-right/right).",
    ),
    web_id: Optional[str] = typer.Option(
        None,
        "--web-id",
        help="Web-ID für Web-Medienset (12 Zeichen, a-z 0-9; überschreibt Sidecar-Wert).",
    ),
    max_luminance: Optional[int] = typer.Option(
        None,
        "--max-luminance",
        help="Peak-Leuchtdichte in nits (MaxCLL) für HDR-Metadaten im Web-Video. Default: 1000. Wird im Sidecar gespeichert.",
    ),
    no_sidecar: bool = typer.Option(
        False,
        "--no-sidecar",
        help="Sidecar-Datei (.settings.toml) nicht lesen/schreiben.",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Neuerstellung erzwingen.",
    ),
    delete_source: bool = typer.Option(
        False,
        "--delete-source",
        help=(
            "Originaldatei (inkl. .settings.toml) in der Quelle löschen, "
            "wenn alle aktiven Kanäle erfolgreich waren UND das Archiv "
            "Size-verifiziert ist. Default: aus. Andere Sidecars (.fcpxml, "
            ".lfpackage) bleiben erhalten — sie gehören zum Editing-Projekt."
        ),
    ),
    web_budget: Optional[str] = typer.Option(
        None, "--web-budget",
        help=(
            "Override Web-Speicherbudget für diesen Lauf (z.B. '500GB', '1TB'). "
            "Überschreibt web.storage_budget aus Config."
        ),
    ),
    web_max_age: Optional[int] = typer.Option(
        None, "--web-max-age",
        help=(
            "Override maximales Alter eines Web-Mediasets in Tagen (z.B. 365). "
            "Vor dem Upload werden ältere Mediasets gelöscht. Überschreibt "
            "web.max_age_days aus Config."
        ),
    ),
    web_cleanup_dry_run: bool = typer.Option(
        False, "--web-cleanup-dry-run",
        help=(
            "Zeigt welche Web-Mediasets bei Budget-Überschuss oder Alter gelöscht "
            "würden, löscht aber nichts. Upload erfolgt trotzdem."
        ),
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Zusätzliche Ablaufinformationen auf stderr ausgeben.",
    ),
) -> None:
    """Veröffentlicht ein Video: Medienset erstellen, Infuse/Web deployen, archivieren."""
    request = PublishRequest(
        source_path=video,
        title=title,
        description=description,
        category=category,
        recording_date=date,
        output_dir=output_dir,
        work_dir=_resolve_work_dir(work_dir),
        force=force,
        skip_infuse=no_infuse,
        skip_web=no_web,
        web_enabled=web,
        skip_archive=no_archive,
        poster_frame=poster_frame,
        poster_at=poster_at,
        poster_crop=poster_crop,
        web_id=web_id,
        max_luminance=max_luminance,
        no_sidecar=no_sidecar,
        delete_source_after_publish=delete_source,
        web_budget_override=_resolve_web_budget_override(web_budget),
        web_max_age_days_override=web_max_age if (web_max_age and web_max_age > 0) else None,
        web_cleanup_dry_run=web_cleanup_dry_run,
    )

    runtime = _build_runtime()
    result = publish(request, runtime, on_event=_make_event_callback(verbose))

    if not result.success:
        stderr_console.print(f"[red]Fehler:[/red] {result.error_message}")
        raise typer.Exit(code=1)

    # Stdout: Web-URL (wenn verfügbar) > web_dir (lokal, wenn nicht aufgeräumt) > infuse_dir
    print(result.web_url or result.web_dir or result.infuse_dir)


# ---------------------------------------------------------------------------
# publish-dir – Batch-Workflow für ganzes Verzeichnis
# ---------------------------------------------------------------------------

@app.command(name="publish-dir")
def publish_dir_cmd(
    directory: str = typer.Argument(
        ...,
        help=(
            "Verzeichnis mit Quell-Videos. Entweder lokaler Pfad oder "
            "rclone-URI (z.B. 'nas:/Quelle')."
        ),
    ),
    category: Optional[str] = typer.Option(
        None,
        "--category",
        help="Kategorie für alle Videos im Verzeichnis (überschreibt defaults.category aus Config).",
    ),
    no_infuse: bool = typer.Option(
        False,
        "--no-infuse",
        help="Infuse-Deployment für alle Videos überspringen.",
    ),
    no_web: bool = typer.Option(
        False,
        "--no-web",
        help="Web-Deployment für alle Videos überspringen (One-Shot-Override).",
    ),
    web: bool = typer.Option(
        False,
        "--web",
        help="Web-Deployment für alle Videos aktivieren (One-Shot-Override, falls "
             "``web_enabled = true`` nirgendwo in familienfilm.toml/Sidecar gesetzt).",
    ),
    no_archive: bool = typer.Option(
        False,
        "--no-archive",
        help="Archivierung für alle Videos überspringen.",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Auch bereits publizierte Videos neu publizieren.",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Nur anzeigen welche Videos publiziert würden, ohne zu publizieren.",
    ),
    delete_source: bool = typer.Option(
        False,
        "--delete-source",
        help=(
            "Pro Video: Originaldatei in der Quelle löschen, wenn alle aktiven "
            "Kanäle erfolgreich waren UND das Archiv Size-verifiziert ist. "
            "Greift nur bei erfolgreich publizierten Videos; --dry-run löscht nie."
        ),
    ),
    web_budget: Optional[str] = typer.Option(
        None, "--web-budget",
        help=(
            "Override Web-Speicherbudget für diesen Lauf (z.B. '500GB', '1TB'). "
            "Überschreibt web.storage_budget aus Config; gilt für jedes Video im Batch."
        ),
    ),
    web_max_age: Optional[int] = typer.Option(
        None, "--web-max-age",
        help=(
            "Override max. Alter eines Web-Mediasets in Tagen für diesen Batch. "
            "Überschreibt web.max_age_days aus Config."
        ),
    ),
    web_cleanup_dry_run: bool = typer.Option(
        False, "--web-cleanup-dry-run",
        help=(
            "Cleanup-Plan zeigen (Budget + Alter), nichts löschen. Upload erfolgt "
            "trotzdem (kann Budget temporär überziehen)."
        ),
    ),
    recursive: bool = typer.Option(
        False,
        "--recursive",
        "-r",
        help=(
            "Unterverzeichnisse mit einbeziehen. Eine 'familienfilm.toml' im "
            "Scan-Root oder einem Unterverzeichnis liefert Default-Werte "
            "(z.B. category) für alle Videos darunter."
        ),
    ),
    work_dir: Optional[Path] = typer.Option(
        None,
        "--work-dir",
        help="Arbeitsverzeichnis für temporäre Dateien (Standard: paths.work_dir aus Config oder Quellverzeichnis). Lokaler SSD bei SMB-Quellen empfohlen.",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Zusätzliche Ablaufinformationen pro Video auf stderr ausgeben.",
    ),
) -> None:
    """Publiziert alle qualifizierten Videos im Verzeichnis sequenziell (älteste zuerst).

    Filtert nach Muster `<YYYY-MM-DD> <titel>.<ext>` (mov/mp4/m4v/mkv).
    Überspringt bereits publizierte Videos (Sidecar `published_at`),
    sofern weder Video noch Sidecar seither geändert wurden.

    Mit ``--recursive`` werden auch Unterverzeichnisse gescannt; eine
    ``familienfilm.toml`` in einem höheren Verzeichnis liefert Default-Werte
    (z.B. ``category``) für alle Videos darunter (nächstgelegenes Verzeichnis
    gewinnt).
    """
    runtime = _build_runtime()
    # v0.10.0: --web-budget / --web-max-age übersteuern Config für diesen
    # Lauf (gilt für alle Videos im Batch — die Mediasets teilen sich das
    # Budget bzw. die Altersregel).
    budget_override = _resolve_web_budget_override(web_budget)
    if budget_override is not None:
        runtime.web_storage_budget_bytes = budget_override
    if web_max_age and web_max_age > 0:
        runtime.web_max_age_days = web_max_age
    result = publish_directory(
        directory=directory,
        runtime=runtime,
        on_event=_make_event_callback(verbose),
        skip_infuse=no_infuse,
        skip_web=no_web,
        web_enabled=web,
        skip_archive=no_archive,
        force=force,
        dry_run=dry_run,
        work_dir=_resolve_work_dir(work_dir),
        category=category,
        recursive=recursive,
        delete_source_after_publish=delete_source and not dry_run,
        web_cleanup_dry_run=web_cleanup_dry_run,
    )

    if result.error_message:
        stderr_console.print(f"[red]Fehler:[/red] {result.error_message}")
        raise typer.Exit(code=1)

    # Dry-Run Übersicht
    if dry_run:
        if result.pending_count == 0:
            stderr_console.print("Keine Videos zu publizieren (alle aktuell).")
        else:
            stderr_console.print(f"Würde {result.pending_count} Videos publizieren:")
            for v in result.videos:
                if v.kind == VideoStatusKind.PENDING:
                    print(v.path)
        return

    # Zusammenfassung
    summary_parts = [f"{result.published_count} publiziert"]
    if result.skipped_count:
        summary_parts.append(f"{result.skipped_count} übersprungen")
    if result.failed_count:
        summary_parts.append(f"[red]{result.failed_count} fehlgeschlagen[/red]")
    stderr_console.print(f"  Verzeichnis-Publikation abgeschlossen: {', '.join(summary_parts)}")

    # Fehlgeschlagene Videos detailliert auflisten
    if result.failed_count:
        stderr_console.print("\n[red]Fehlgeschlagene Videos:[/red]")
        for v in result.videos:
            if v.kind == VideoStatusKind.FAILED:
                stderr_console.print(f"  [red]✗[/red] {v.path.name}: {v.error_message}")

    # Stdout: URLs aller erfolgreich publizierten Videos
    for v in result.videos:
        if v.kind == VideoStatusKind.PUBLISHED and v.publish_result:
            url = v.publish_result.web_url or v.publish_result.web_dir or v.publish_result.infuse_dir
            if url:
                print(url)

    if result.failed_count:
        raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# watch-dir – Verzeichnis-Überwachung (Daemon oder --once für launchd/cron)
# ---------------------------------------------------------------------------

@app.command(name="watch-dir")
def watch_dir_cmd(
    directory: Optional[list[str]] = typer.Option(
        None,
        "--directory",
        "-d",
        help=(
            "Zu überwachendes Verzeichnis (mehrfach angebbar). "
            "Akzeptiert lokale Pfade oder rclone-URIs (z.B. 'nas:/Quelle'). "
            "Überschreibt watch.directories aus der Config."
        ),
    ),
    interval: Optional[str] = typer.Option(
        None,
        "--interval",
        help=(
            "Intervall zwischen Ticks (z.B. '24h', '90m', '600'). "
            "Default: watch.interval_seconds aus Config (24h). Im --once-Modus ignoriert."
        ),
    ),
    once: bool = typer.Option(
        False,
        "--once",
        help=(
            "Genau einen Tick ausführen, dann Exit. "
            "Ideal für launchd/cron — das externe Scheduling bestimmt das Timing."
        ),
    ),
    stability_window: Optional[str] = typer.Option(
        None,
        "--stability-window",
        help=(
            "Wartezeit zur Erkennung wachsender Dateien (z.B. '60s', '2m'). "
            "Dateien, deren Grösse sich innerhalb dieses Fensters ändert, werden "
            "im nächsten Tick erneut geprüft. Default: watch.stability_window_seconds (60s)."
        ),
    ),
    category: Optional[str] = typer.Option(
        None,
        "--category",
        help="Kategorie für alle Videos in allen überwachten Verzeichnissen (überschreibt defaults.category).",
    ),
    recursive: bool = typer.Option(
        False,
        "--recursive",
        "-r",
        help=(
            "Unterverzeichnisse der überwachten Verzeichnisse mit einbeziehen. "
            "Eine 'familienfilm.toml' in einem Verzeichnis liefert Default-Werte "
            "(z.B. category) für alle Videos darunter."
        ),
    ),
    no_infuse: bool = typer.Option(False, "--no-infuse", help="Infuse-Deployment überspringen."),
    no_web: bool = typer.Option(False, "--no-web", help="Web-Deployment überspringen (One-Shot-Override)."),
    web: bool = typer.Option(False, "--web", help="Web-Deployment aktivieren (One-Shot-Override)."),
    no_archive: bool = typer.Option(False, "--no-archive", help="Archivierung überspringen."),
    force: bool = typer.Option(
        False, "--force", help="Auch bereits publizierte Videos neu publizieren.",
    ),
    delete_source: bool = typer.Option(
        False,
        "--delete-source",
        help=(
            "Pro Video: Originaldatei (+ .settings.toml) im überwachten "
            "Verzeichnis löschen, wenn alle aktiven Kanäle erfolgreich waren "
            "UND das Archiv Size-verifiziert ist. Gedacht für unattended "
            "Watch-Läufe auf Export-Verzeichnissen, damit nach erfolgreicher "
            "Publikation Platz frei wird. Greift nur pro erfolgreich "
            "publiziertem Video."
        ),
    ),
    web_budget: Optional[str] = typer.Option(
        None, "--web-budget",
        help=(
            "Override Web-Speicherbudget für diesen Watch-Lauf (z.B. '500GB'). "
            "Überschreibt web.storage_budget aus Config; gilt für jedes Video."
        ),
    ),
    web_max_age: Optional[int] = typer.Option(
        None, "--web-max-age",
        help=(
            "Override max. Alter eines Web-Mediasets in Tagen für diesen "
            "Watch-Lauf. Überschreibt web.max_age_days aus Config."
        ),
    ),
    web_cleanup_dry_run: bool = typer.Option(
        False, "--web-cleanup-dry-run",
        help="Cleanup-Plan zeigen (Budget + Alter), nichts löschen.",
    ),
    work_dir: Optional[Path] = typer.Option(
        None,
        "--work-dir",
        help="Arbeitsverzeichnis für temporäre Dateien (überschreibt paths.work_dir).",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Überwacht ein oder mehrere Verzeichnisse und publiziert neue Videos.

    Ein Tick = ein Scan+Publish-Durchlauf über alle Verzeichnisse — identisch
    zu einem publish-dir-Lauf. Im Default läuft der Prozess als Daemon und
    wiederholt den Tick im konfigurierten Intervall (Default 24h). Mit --once
    läuft nur ein Tick (ideal für launchd/cron).

    Idempotenz: bereits publizierte Videos werden per Fingerprint (Dateigrösse
    + SHA1 der ersten 1 MB) erkannt und übersprungen. Siehe publish-dir.
    """
    dirs = _resolve_watch_directories(directory)
    if not dirs:
        stderr_console.print(
            "[red]Fehler:[/red] Keine Verzeichnisse angegeben. "
            "Nutze --directory/-d (mehrfach möglich) oder setze watch.directories in der Config."
        )
        raise typer.Exit(code=2)

    try:
        interval_seconds = (
            _parse_duration(interval)
            if interval
            else int(config_manager.get_with_default("watch.interval_seconds"))
        )
        stability_seconds = (
            _parse_duration(stability_window)
            if stability_window
            else int(config_manager.get_with_default("watch.stability_window_seconds"))
        )
    except ValueError as e:
        stderr_console.print(f"[red]Fehler:[/red] {e}")
        raise typer.Exit(code=2) from None

    if once and interval is not None:
        stderr_console.print(
            "[yellow]Hinweis:[/yellow] --once ignoriert --interval "
            "(das Timing bestimmt dein Scheduler)."
        )

    request = WatchRequest(
        directories=dirs,
        interval_seconds=interval_seconds,
        stability_window_seconds=stability_seconds,
        once=once,
        recursive=recursive,
        category=category,
        skip_infuse=no_infuse,
        skip_web=no_web,
        web_enabled=web,
        skip_archive=no_archive,
        force=force,
        work_dir=_resolve_work_dir(work_dir),
        delete_source_after_publish=delete_source,
        web_cleanup_dry_run=web_cleanup_dry_run,
    )

    runtime = _build_runtime()
    # v0.10.0: --web-budget / --web-max-age übersteuern Config für diesen
    # Watch-Lauf.
    budget_override = _resolve_web_budget_override(web_budget)
    if budget_override is not None:
        runtime.web_storage_budget_bytes = budget_override
    if web_max_age and web_max_age > 0:
        runtime.web_max_age_days = web_max_age
    result = watch_directories(
        request, runtime, on_event=_make_event_callback(verbose),
    )

    # Zusammenfassung
    total_pub = sum(t.published_count for t in result.ticks)
    total_fail = sum(t.failed_count for t in result.ticks)
    total_unstable = sum(t.unstable_count for t in result.ticks)
    stderr_console.print(
        f"  Überwachung abgeschlossen: {result.tick_count} Tick(s), "
        f"{total_pub} publiziert, {total_fail} fehlgeschlagen, {total_unstable} wächst noch."
    )
    if total_fail:
        raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# deploy-infuse – Einzeloperation
# ---------------------------------------------------------------------------

@app.command(name="deploy-infuse")
def deploy_infuse_cmd(
    source_dir: Path = typer.Argument(
        ...,
        help="Pfad zum Verzeichnis mit Infuse-Dateien.",
        exists=True,
        file_okay=False,
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Deployt ein Verzeichnis mit Infuse-Dateien via rclone."""
    runtime = _build_runtime()
    result = deploy_infuse(
        DeployRequest(source_dir=source_dir),
        runtime,
        on_event=_make_event_callback(verbose),
    )

    if not result.success:
        stderr_console.print(f"[red]Fehler:[/red] {result.error_message}")
        raise typer.Exit(code=1)

    if result.target_path:
        print(result.target_path)


# ---------------------------------------------------------------------------
# deploy-web – Einzeloperation
# ---------------------------------------------------------------------------

@app.command(name="deploy-web")
def deploy_web_cmd(
    source_dir: Path = typer.Argument(
        ...,
        help="Pfad zum Web-Medienset-Verzeichnis (Web-ID).",
        exists=True,
        file_okay=False,
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Deployt ein Web-Medienset-Verzeichnis zum Webserver (via rclone)."""
    runtime = _build_runtime()
    result = deploy_web(
        DeployRequest(source_dir=source_dir),
        runtime,
        on_event=_make_event_callback(verbose),
    )

    if not result.success:
        stderr_console.print(f"[red]Fehler:[/red] {result.error_message}")
        raise typer.Exit(code=1)

    if result.target_path:
        print(result.target_path)


# ---------------------------------------------------------------------------
# archive – Einzeloperation
# ---------------------------------------------------------------------------

@app.command(name="archive")
def archive_cmd(
    video: Path = typer.Argument(
        ...,
        help="Pfad zur Original-Videodatei.",
        exists=True,
        dir_okay=False,
    ),
    title: Optional[str] = typer.Option(
        None,
        "--title",
        help="Titel für ISO-Dateiname und Volume-Name.",
    ),
    date: Optional[str] = typer.Option(
        None,
        "--date",
        help="Aufnahmedatum (YYYY-MM-DD) für ISO-Dateiname.",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Archiviert eine Videodatei als ISO und verschiebt sie zum Archiv-Ziel."""
    runtime = _build_runtime()
    result = archive(
        ArchiveRequest(source_path=video, recording_date=date, title=title),
        runtime,
        on_event=_make_event_callback(verbose),
    )

    if not result.success:
        stderr_console.print(f"[red]Fehler:[/red] {result.error_message}")
        raise typer.Exit(code=1)

    if result.archive_path:
        print(result.archive_path)


# ---------------------------------------------------------------------------
# config – Subcommands
# ---------------------------------------------------------------------------

@config_app.command(name="set")
def config_set_cmd(
    key: str = typer.Argument(..., help="Konfigurationsschlüssel (z.B. 'targets.infuse')."),
    value: str = typer.Argument(..., help="Wert."),
) -> None:
    """Speichert einen Konfigurationswert."""
    if not config_manager.set_value(key, value):
        stderr_console.print(f"[red]Fehler:[/red] Unbekannter Schlüssel '{key}'.")
        stderr_console.print("Erlaubte Schlüssel:")
        for k, (desc, default) in config_manager.ALLOWED_KEYS.items():
            stderr_console.print(f"  {k}: {desc} (Standard: {default or '(leer)'})")
        raise typer.Exit(code=2)
    stderr_console.print(f"Gespeichert: {key} = {value}")


@config_app.command(name="get")
def config_get_cmd(
    key: str = typer.Argument(..., help="Konfigurationsschlüssel."),
) -> None:
    """Liest einen Konfigurationswert."""
    if key not in config_manager.ALLOWED_KEYS:
        stderr_console.print(f"[red]Fehler:[/red] Unbekannter Schlüssel '{key}'.")
        raise typer.Exit(code=2)
    val = config_manager.get(key)
    if val is None:
        desc, default = config_manager.ALLOWED_KEYS[key]
        stderr_console.print(f"(nicht gesetzt, Standard: {default or '(leer)'})")
    else:
        print(val)


@config_app.command(name="list")
def config_list_cmd() -> None:
    """Zeigt alle konfigurierten Werte an."""
    stored = config_manager.list_all()
    if not stored:
        stderr_console.print("Keine Konfigurationswerte gespeichert.")
        stderr_console.print(f"Konfigurationsdatei: {config_manager.CONFIG_PATH}")
        return
    for key, val in sorted(stored.items()):
        print(f"{key} = {val}")


@config_app.command(name="unset")
def config_unset_cmd(
    key: str = typer.Argument(..., help="Konfigurationsschlüssel zum Entfernen."),
) -> None:
    """Entfernt einen Konfigurationswert (v0.11.0+).

    Wenn der Schlüssel nicht gesetzt war, wird ein Hinweis ausgegeben aber
    kein Fehler geworfen.
    """
    if key not in config_manager.ALLOWED_KEYS:
        stderr_console.print(f"[red]Fehler:[/red] Unbekannter Schlüssel '{key}'.")
        raise typer.Exit(code=2)
    if config_manager.unset_value(key):
        stderr_console.print(f"Entfernt: {key}")
    else:
        stderr_console.print(f"(war nicht gesetzt: {key})")


# ---------------------------------------------------------------------------
# web-storage – Web-Target Belegungs- und Bereinigungs-Status (v0.11.0+)
# ---------------------------------------------------------------------------

@web_storage_app.command(name="status")
def web_storage_status_cmd(
    web_budget: Optional[str] = typer.Option(
        None, "--web-budget",
        help="Override Budget für diese Anzeige (z.B. '500GB'). Default: Config.",
    ),
    web_max_age: Optional[int] = typer.Option(
        None, "--web-max-age",
        help="Override Max-Age (Tage) für diese Anzeige. Default: Config.",
    ),
) -> None:
    """Zeigt Belegung, Mediasets und Cleanup-Vorhersage für das Web-Target.

    Reine Lese-Operation — verändert nichts. Hilft zu beurteilen, wie nahe
    das Web-Target am Budget oder an der Aufbewahrungsgrenze ist, ohne erst
    publishen zu müssen.
    """
    from datetime import datetime, timezone
    from familienfilm_manager.core.web_storage import (
        SAFETY_MARGIN_PERCENT,
        format_size,
        list_web_mediasets,
    )

    runtime = _build_runtime()
    if not runtime.web_target:
        stderr_console.print(
            "[red]Fehler:[/red] Kein Web-Target konfiguriert. "
            "Setze: familienfilm-manager config set targets.web '<rclone-uri>'"
        )
        raise typer.Exit(code=2)

    # Effektives Budget + Max-Age (Override > Config)
    effective_budget = _resolve_web_budget_override(web_budget) or runtime.web_storage_budget_bytes
    effective_max_age = (
        web_max_age
        if (web_max_age and web_max_age > 0)
        else runtime.web_max_age_days
    )

    print(f"Web-Target: {runtime.web_target}")
    if effective_budget:
        margin = effective_budget * SAFETY_MARGIN_PERCENT // 100
        print(f"Budget: {format_size(effective_budget)} (Marge {SAFETY_MARGIN_PERCENT}% = {format_size(margin)})")
    else:
        print("Budget: (nicht konfiguriert — kein Cleanup)")
    if effective_max_age:
        print(f"Max-Age: {effective_max_age} Tage")
    else:
        print("Max-Age: (nicht konfiguriert — keine Altersbegrenzung)")
    print()

    try:
        mediasets = list_web_mediasets(runtime.web_target, rclone_path=runtime.rclone_path)
    except Exception as e:
        stderr_console.print(f"[red]Fehler beim Lesen des Web-Targets:[/red] {e}")
        raise typer.Exit(code=1) from None

    if not mediasets:
        print("Keine Mediasets im Web-Target.")
        return

    used = sum(m.size_bytes for m in mediasets)
    print(f"Mediasets: {len(mediasets)}")
    print(f"Belegt: {format_size(used)}")
    if effective_budget:
        pct = used / effective_budget * 100
        free_effective = effective_budget * (100 - SAFETY_MARGIN_PERCENT) // 100 - used
        print(f"  → {pct:.1f}% des Budgets")
        print(f"  → effektiv frei (mit Marge): {format_size(max(free_effective, 0))}")
    print()

    # Ältestes / neuestes
    now = datetime.now(tz=timezone.utc)
    oldest = mediasets[0]  # bereits sortiert in list_web_mediasets
    newest = mediasets[-1]
    oldest_age_days = (now - oldest.index_mtime).days
    newest_age_days = (now - newest.index_mtime).days
    print(f"Ältestes:  {oldest.web_id} ({format_size(oldest.size_bytes)}, "
          f"{oldest_age_days} Tage alt)")
    print(f"Neuestes:  {newest.web_id} ({format_size(newest.size_bytes)}, "
          f"{newest_age_days} Tage alt)")

    if effective_max_age:
        aged = [m for m in mediasets if (now - m.index_mtime).days > effective_max_age]
        if aged:
            print(f"\n→ {len(aged)} Mediaset(s) sind älter als {effective_max_age} Tage")
            print("   und würden beim nächsten Web-Upload gelöscht.")
        else:
            tage_bis_rotation = effective_max_age - oldest_age_days
            print(f"\n→ Erstes Mediaset wird in {tage_bis_rotation} Tag(en) "
                  f"alters-rotiert (bei nächstem Web-Upload).")


@web_storage_app.command(name="cleanup")
def web_storage_cleanup_cmd(
    web_budget: Optional[str] = typer.Option(
        None, "--web-budget",
        help="Override Budget für diesen Cleanup (z.B. '500GB'). Default: Config.",
    ),
    web_max_age: Optional[int] = typer.Option(
        None, "--web-max-age",
        help="Override Max-Age (Tage) für diesen Cleanup. Default: Config.",
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run",
        help="Zeigt was gelöscht würde, löscht aber nichts.",
    ),
) -> None:
    """Manueller Cleanup des Web-Targets (v0.12.0+).

    Standardmässig läuft Cleanup nur vor jedem Web-Upload (lazy). Dieser
    Befehl triggert einen Cleanup-Lauf manuell, ohne dass ein Publish nötig
    wäre. Praktisch z.B. nach einer Konfigurationsänderung
    (`web.max_age_days`) oder vor einem geplanten Republish-Bulk.

    Reihenfolge ist identisch zum Publish-Pfad: erst Age-Pass (falls
    `max_age_days` gesetzt), dann Budget-Pass (falls `storage_budget`
    gesetzt). Bei `--dry-run` wird nur geloggt, was passieren würde.
    """
    from familienfilm_manager.core.web_storage import (
        cleanup_aged_mediasets,
        cleanup_oldest_until_fits,
    )

    runtime = _build_runtime()
    if not runtime.web_target:
        stderr_console.print(
            "[red]Fehler:[/red] Kein Web-Target konfiguriert. "
            "Setze: familienfilm-manager config set targets.web '<rclone-uri>'"
        )
        raise typer.Exit(code=2)

    effective_budget = _resolve_web_budget_override(web_budget) or runtime.web_storage_budget_bytes
    effective_max_age = (
        web_max_age
        if (web_max_age and web_max_age > 0)
        else runtime.web_max_age_days
    )

    if not effective_budget and not effective_max_age:
        stderr_console.print(
            "[yellow]Hinweis:[/yellow] Weder web.storage_budget noch web.max_age_days "
            "konfiguriert. Nichts zu tun."
        )
        return

    on_event = _make_event_callback(verbose=True)

    deleted_total: int = 0
    if effective_max_age:
        aged = cleanup_aged_mediasets(
            web_target=runtime.web_target,
            max_age_days=effective_max_age,
            rclone_path=runtime.rclone_path,
            dry_run=dry_run,
            on_event=on_event,
        )
        deleted_total += len(aged)

    # Budget-Pass: hier ist new_mediaset_size=0 (kein anstehender Upload).
    # Der Budget-Pass löscht nur, wenn used > effective_budget × 95%.
    if effective_budget:
        cleaned = cleanup_oldest_until_fits(
            web_target=runtime.web_target,
            new_mediaset_size=0,
            budget_bytes=effective_budget,
            rclone_path=runtime.rclone_path,
            dry_run=dry_run,
            on_event=on_event,
        )
        deleted_total += len(cleaned)

    verb = "würden gelöscht" if dry_run else "gelöscht"
    if deleted_total == 0:
        stderr_console.print("Nichts zu tun — Budget eingehalten und keine Mediasets über Max-Age.")
    else:
        stderr_console.print(f"\n{deleted_total} Mediaset(s) {verb}.")
