"""Konservierte Original-Metadaten für archivierte Videos (``.archive.toml``).

Seit v0.9.0 liegt neben jeder archivierten Videodatei eine ``.archive.toml``
mit Werten, die bei späteren Moves zwischen Archiv-Locations verloren gehen
würden (insbesondere die FS-``mtime``, die implizit das Export-/Schnittdatum
kodiert) oder die beim ASCII-Slug-Archivnamen nicht mehr sichtbar sind
(Originaldateiname mit Umlauten).

Bewusst **separat** vom ``.settings.toml``: jenes ist Publish-Konfiguration
(Poster, Web-ID, Fingerprints für Idempotenz), während ``.archive.toml``
unveränderliche Originalmetadaten ist — eine andere Halbwertszeit.
"""

from __future__ import annotations

import tomllib
from dataclasses import dataclass
from datetime import datetime, timezone
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

SCHEMA_VERSION = 1

# Menschenlesbarer App-Name für die ``generator``-Zeile im Archiv-Sidecar.
# Entspricht dem PyPI-Projekt ``kurmann-familienfilm-manager``.
APP_NAME = "Kurmann Familienfilm-Manager"


def _app_version() -> str:
    """Liest die installierte Package-Version via importlib.metadata.

    Fallback ``"unknown"`` falls das Paket nicht installiert ist (z.B. in
    isolierten Test-Setups) — die Metadaten-Datei muss trotzdem schreibbar
    bleiben.
    """
    try:
        return version("kurmann-familienfilm-manager")
    except PackageNotFoundError:
        return "unknown"


@dataclass
class ArchiveMetadata:
    """In der ``.archive.toml`` konservierte Werte."""

    original_filename: str
    original_mtime: str                 # ISO-8601 mit Offset
    recording_date: str | None = None   # YYYY-MM-DD
    title: str | None = None
    description: str | None = None
    archived_at: str | None = None      # ISO-8601 mit Offset
    schema_version: int = SCHEMA_VERSION


def _escape_basic(value: str) -> str:
    """Escape für TOML-Basic-Strings (einzeilig, ``"..."``)."""
    return (
        value.replace("\\", "\\\\")
             .replace('"', '\\"')
             .replace("\n", "\\n")
             .replace("\r", "\\r")
             .replace("\t", "\\t")
    )


def _emit_string(value: str) -> str:
    """Wählt automatisch zwischen Basic- und Multiline-Basic-String.

    Multiline-Form ``\"\"\"...\"\"\"`` bewahrt Zeilenumbrüche im TOML-File
    lesbar — wichtig für mehrzeilige Video-Beschreibungen. Innerhalb der
    Multiline-Form müssen nur ``\\`` und Tripel-Quotes entschärft werden.
    """
    if "\n" not in value and "\r" not in value:
        return f'"{_escape_basic(value)}"'

    # Multi-line basic string. ``\\`` und ``"""`` müssen escaped werden.
    body = value.replace("\\", "\\\\")
    # Tripel-Quote zerstören: jedes ``"""`` → ``""\"`` (ungültig machen).
    body = body.replace('"""', '""\\"')
    # Führende Newline-Konvention: TOML ignoriert genau **einen** Newline
    # unmittelbar nach der öffnenden Delimiter-Sequenz. Wir geben ihr einen
    # sauberen Start.
    return f'"""\n{body}"""'


def _iso_local(ts: float) -> str:
    """Konvertiert einen Unix-Timestamp in ISO-8601 mit lokaler Zeitzone + Offset."""
    return datetime.fromtimestamp(ts).astimezone().isoformat(timespec="seconds")


def write_archive_metadata(
    source_video: Path,
    target_toml: Path,
    recording_date: str | None = None,
    title: str | None = None,
    description: str | None = None,
) -> Path:
    """Erzeugt die ``.archive.toml`` mit konservierten Originalmetadaten.

    Die FS-``mtime`` der Quelldatei wird als ``original_mtime`` festgeschrieben
    — damit bleibt das Export-/Schnittdatum auch erhalten, wenn das Archiv
    später umsortiert wird und die FS-``mtime`` verloren geht.

    Args:
        source_video: Originalvideo (für Name und ``mtime``).
        target_toml: Zielpfad der ``.archive.toml`` (lokal; der Archiver
            kopiert sie anschliessend ins Archiv-Ziel).
        recording_date: Aufnahmedatum (ISO, ``YYYY-MM-DD``) — optional.
        title: Video-Titel — optional.
        description: Beschreibung (darf Zeilenumbrüche und Umlaute enthalten).

    Returns:
        Der Pfad zur geschriebenen Datei.
    """
    stat = source_video.stat()

    generator = f"{APP_NAME} {_app_version()}"

    lines: list[str] = [
        f"# {APP_NAME} — konservierte Originalmetadaten",
        "# Diese Datei wird nicht verändert — sie hält fragile Werte fest,",
        "# die bei späteren Verschiebungen verloren gehen könnten.",
        "",
        f"schema_version = {SCHEMA_VERSION}",
        f"generator = {_emit_string(generator)}",
        f"original_filename = {_emit_string(source_video.name)}",
        # TOML-Datetime (nicht als String) — tomllib parst es als datetime.
        f"original_mtime = {_iso_local(stat.st_mtime)}",
        f"archived_at = {_iso_local(datetime.now(timezone.utc).timestamp())}",
    ]

    if recording_date:
        lines.append(f"recording_date = {recording_date}")
    if title:
        lines.append(f"title = {_emit_string(title)}")
    if description:
        lines.append(f"description = {_emit_string(description)}")

    target_toml.parent.mkdir(parents=True, exist_ok=True)
    target_toml.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return target_toml


def read_archive_metadata(path: Path) -> dict:
    """Liest eine ``.archive.toml`` zurück als Dict.

    Primär für Tests (Roundtrip) und künftige Re-Import-/Inspect-Flows.
    """
    return tomllib.loads(path.read_text(encoding="utf-8"))
