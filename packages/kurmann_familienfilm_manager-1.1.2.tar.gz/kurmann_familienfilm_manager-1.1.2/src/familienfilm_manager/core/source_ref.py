"""Source-Referenz: URI-basierte Abstraktion über lokale Pfade und rclone-Remotes.

Eine ``SourceRef`` kapselt einen Quell-Ort — entweder ein lokaler Dateipfad
oder ein rclone-URI der Form ``remote:path``. Die Abstraktion ist bewusst
dünn: Nur die Pfad-Manipulationen (``parent``, ``name``, ``stem``, ``suffix``,
``child``), die für beide Fälle trivial sind, plus die ``is_rclone``-Weiche
für weitere Code-Pfade.

Detection-Regel: ein URI gilt als rclone-Pfad, wenn er ein ``:`` **vor** dem
ersten ``/`` enthält und nicht absolut-lokal ist. Beispiele:

    "lyssach-nas:/Archiv/foo.mov"          → rclone
    "myremote:"                            → rclone (Root)
    "gdrive:Videos/2026/"                  → rclone (kein führendes /)
    "/Users/me/Movies/foo.mov"             → lokal
    "./relativ/foo.mov"                    → lokal
    "foo.mov"                              → lokal (relativ)
    "C:/Users/..."                         → lokal (Windows-Laufwerk — wir
                                             sind auf macOS, aber der Test
                                             schadet nicht)
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from pathlib import Path

# rclone-Remote: Name (a-z, 0-9, _, -, .), dann ':', dann optional Pfad.
# Punkt erlaubt für Hostname-artige Remote-Namen (``mega.nz:``,
# ``hostpoint.com:`` usw. — frei vom User in ``rclone config`` vergeben).
# Ein einzelner Großbuchstabe vor ':' wäre eher ein Windows-Laufwerk;
# durch ``{2,}`` ausgeschlossen.
_RCLONE_REMOTE_RE = re.compile(r"^[a-zA-Z0-9_.\-]{2,}:")


def _looks_like_rclone_uri(uri: str) -> bool:
    """Heuristik: URI ist ein rclone-Pfad.

    - ``:`` erscheint vor dem ersten ``/`` (oder es gibt keinen ``/``)
    - Prefix ist mindestens 2 Zeichen (Windows-Laufwerksbuchstaben raus)
    - Keine absolute Pfad-Form (beginnt nicht mit ``/``)
    """
    if not uri:
        return False
    if uri.startswith("/"):
        return False
    return _RCLONE_REMOTE_RE.match(uri) is not None


@dataclass(frozen=True)
class SourceRef:
    """Verweis auf eine Video-Quelle (lokal oder rclone).

    ``uri`` ist die Rohform — entweder ein lokaler Pfad-String oder
    ``remote:path``. Alle weiteren Properties leiten daraus ab.

    Unicode-Normalisierung (seit v0.10.0): die URI wird beim Erstellen
    auf NFC normalisiert. Hintergrund: macOS-Terminals/Dateinamen liefern
    Umlaute oft in NFD (``ä`` = ``a`` + U+0308 combining diaeresis), die
    meisten Backends (SFTP/SMB-NAS, Linux) erwarten aber NFC. Ohne
    Normalisierung schlug ``rclone lsjson "remote:/.../Glück/..."`` mit
    Exit 3 „directory not found" fehl, obwohl der Pfad faktisch existierte.
    """

    uri: str

    def __post_init__(self) -> None:
        # frozen dataclass: object.__setattr__ ist die einzige saubere Art,
        # einen normalisierten Wert in das Feld zu schreiben.
        normalized = unicodedata.normalize("NFC", self.uri) if self.uri else self.uri
        if normalized != self.uri:
            object.__setattr__(self, "uri", normalized)

    @property
    def is_rclone(self) -> bool:
        return _looks_like_rclone_uri(self.uri)

    @property
    def name(self) -> str:
        """Letztes Segment (Dateiname oder Verzeichnisname).

        Für rclone-Root-URIs (``remote:``) ist der Name leer.
        """
        if self.is_rclone:
            # "remote:path/to/name" → "name"
            _, _, path = self.uri.partition(":")
            if not path:
                return ""
            return path.rsplit("/", 1)[-1]
        return Path(self.uri).name

    @property
    def stem(self) -> str:
        """Dateiname ohne letzte Extension."""
        name = self.name
        if "." in name and not name.startswith("."):
            return name.rsplit(".", 1)[0]
        return name

    @property
    def suffix(self) -> str:
        """Letzte Extension inkl. Punkt (z.B. ``.mov``)."""
        name = self.name
        if "." in name and not name.startswith("."):
            return "." + name.rsplit(".", 1)[-1]
        return ""

    def parent_uri(self) -> str:
        """URI des Elternverzeichnisses.

        Für rclone: ``remote:path/to/file`` → ``remote:path/to``.
        Root-Fall: ``remote:`` → ``remote:`` (kein weiterer Aufstieg möglich).

        Für lokale Pfade: ``Path.parent`` (stringifiziert).
        """
        if self.is_rclone:
            remote, _, path = self.uri.partition(":")
            if not path or "/" not in path:
                # Root-Niveau erreicht
                return f"{remote}:"
            parent_path = path.rsplit("/", 1)[0]
            if not parent_path:
                # war "remote:/name" → "remote:"
                return f"{remote}:"
            return f"{remote}:{parent_path}"
        return str(Path(self.uri).parent)

    def child_uri(self, name: str) -> str:
        """URI eines Kindeintrags mit gegebenem Namen.

        Für rclone: der Remote-Teil bleibt erhalten, der Pfad-Teil wird
        um ``/name`` erweitert.
        """
        if self.is_rclone:
            remote, _, path = self.uri.partition(":")
            if not path:
                return f"{remote}:{name}"
            # Doppel-Slash vermeiden (auch wenn path schon mit / endet)
            return f"{remote}:{path.rstrip('/')}/{name}"
        return str(Path(self.uri) / name)

    def as_local_path(self) -> Path:
        """Gibt einen ``Path`` für lokale URIs zurück; rclone → ``ValueError``."""
        if self.is_rclone:
            raise ValueError(
                f"SourceRef {self.uri!r} ist ein rclone-Remote, kein lokaler Pfad."
            )
        return Path(self.uri)

    def is_root(self) -> bool:
        """True wenn weiter kein Elternteil mehr existiert (Remote-Root oder Filesystem-Root).

        Für rclone ist ``remote:`` / ``remote:/`` Root; ``remote:a`` ist noch
        kein Root (Parent wäre ``remote:``).
        """
        if self.is_rclone:
            _, _, path = self.uri.partition(":")
            return not path.strip("/")
        p = Path(self.uri)
        return p == p.parent

    def __str__(self) -> str:
        return self.uri
