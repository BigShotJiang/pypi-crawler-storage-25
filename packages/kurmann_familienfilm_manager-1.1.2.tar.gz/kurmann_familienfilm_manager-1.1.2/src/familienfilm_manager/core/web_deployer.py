"""Web-Deployment: Web-ID-Verzeichnis via rclone zum Webserver kopieren."""

from __future__ import annotations

import subprocess
from pathlib import Path

from familienfilm_manager.api.models import (
    DeployResult,
    FamilienfilmEvent,
    FamilienfilmStage,
)
from familienfilm_manager.core._rclone import (
    run_rclone_with_retry,
    verify_rclone_target_contains,
)


def deploy_to_web(
    source_dir: Path,
    web_target: str,
    rclone_path: str = "rclone",
    on_event=None,
    *,
    budget_bytes: int | None = None,
    max_age_days: int | None = None,
    cleanup_dry_run: bool = False,
) -> DeployResult:
    """Kopiert das Web-Medienset-Verzeichnis via rclone zum Webserver.

    Args:
        source_dir: Pfad zum Web-ID-Verzeichnis (vom WebProfile erstellt).
        web_target: rclone-Ziel für den Webserver.
        rclone_path: Pfad zur rclone-Binärdatei.
        on_event: Optionaler Event-Callback.
        budget_bytes: Optionales hartes Speicherbudget für das Web-Target
            (v0.10.0+). Wenn gesetzt, prüft der Deployer vor dem Upload, ob
            ``aktuell_belegt + neues_mediaset + 5 % Sicherheitsmarge`` das
            Budget übersteigt — und löscht ältester Mediasets bis Platz reicht.
            None = kein Cleanup, altes Verhalten.
        max_age_days: Maximales Alter eines Web-Mediasets in Tagen (v0.10.0+).
            Vor jedem Upload werden Mediasets, deren ``index.html``-mtime älter
            als die Schwelle ist, komplett gelöscht — unabhängig vom Budget.
            None = keine Altersbegrenzung. Der Age-Pass läuft VOR dem Budget-
            Pass; ist nach dem Age-Pass schon genug Platz, läuft Budget leer.
        cleanup_dry_run: Wenn True, wird der Cleanup-Plan nur geloggt, nicht
            tatsächlich gelöscht. Gilt für beide Cleanup-Pfade (Age + Budget).
            Upload erfolgt trotzdem (kann temporär das Budget überziehen).

    Returns:
        DeployResult mit Erfolg/Fehler. ``cleaned_up_web_ids`` enthält die
        ``web_id``s der im Zuge dieses Uploads gelöschten Mediasets — der
        Publisher kann daraus die Notification-HTML aktualisieren.
    """
    if not web_target:
        return DeployResult(
            success=False,
            error_message="Kein Web-Ziel konfiguriert (targets.web).",
        )

    if not source_dir.exists():
        return DeployResult(
            success=False,
            error_message=f"Quellverzeichnis nicht gefunden: {source_dir}",
        )

    web_id_name = source_dir.name
    target_dir = f"{web_target.rstrip('/')}/{web_id_name}"

    # v0.10.0: Cleanup-Pässe vor dem Upload. Reihenfolge:
    #   1. Age-Pass: alle Mediasets älter als max_age_days entfernen
    #      (komplett unabhängig vom Budget — proaktive Hygiene)
    #   2. Budget-Pass: falls (used + new + 5%-Marge) > Budget, ältester
    #      Rest weg, bis Platz reicht
    # Bei dry_run wird in beiden Pässen nur geloggt was gelöscht würde.
    # ``cleanup_reasons`` speichert pro web_id den Grund — für die
    # Notification-HTML-Markierung beim Caller (publisher).
    cleaned_up_web_ids: dict[str, str] = {}

    if max_age_days is not None and max_age_days > 0:
        try:
            from familienfilm_manager.core.web_storage import (
                cleanup_aged_mediasets,
            )
            aged = cleanup_aged_mediasets(
                web_target=web_target,
                max_age_days=max_age_days,
                rclone_path=rclone_path,
                dry_run=cleanup_dry_run,
                on_event=on_event,
            )
            for m in aged:
                cleaned_up_web_ids[m.web_id] = f"älter als {max_age_days} Tage"
        except Exception as e:
            if on_event:
                on_event(FamilienfilmEvent(
                    stage_id=FamilienfilmStage.DEPLOY_FAILED,
                    message=(
                        f"Web-Alter-Check fehlgeschlagen: {e}. Lauf wird "
                        f"fortgesetzt."
                    ),
                ))

    if budget_bytes is not None and budget_bytes > 0:
        # Lokale Mediaset-Grösse messen (rekursiv über alle Files).
        local_size = sum(
            f.stat().st_size for f in source_dir.rglob("*") if f.is_file()
        )
        try:
            from familienfilm_manager.core.web_storage import (
                cleanup_oldest_until_fits,
            )
            cleaned = cleanup_oldest_until_fits(
                web_target=web_target,
                new_mediaset_size=local_size,
                budget_bytes=budget_bytes,
                rclone_path=rclone_path,
                dry_run=cleanup_dry_run,
                on_event=on_event,
            )
            for m in cleaned:
                # Wenn schon vom Age-Pass gelöscht: Grund nicht überschreiben
                # (Age war chronologisch zuerst).
                cleaned_up_web_ids.setdefault(m.web_id, "Speicherplatz")
        except Exception as e:
            # Cleanup-Fehler ist nicht tödlich — Upload trotzdem versuchen.
            # Hostpoint entscheidet ob Platz da ist.
            if on_event:
                on_event(FamilienfilmEvent(
                    stage_id=FamilienfilmStage.DEPLOY_FAILED,
                    message=(
                        f"Web-Budget-Check fehlgeschlagen: {e}. Upload erfolgt "
                        f"trotzdem (Hostpoint kann ablehnen)."
                    ),
                ))

    def _on_retry(attempt: int, max_attempts: int, exc: Exception) -> None:
        if on_event:
            stderr = getattr(exc, "stderr", "") or str(exc)
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOY_RETRY,
                message=(
                    f"Web-Deployment fehlgeschlagen (Versuch {attempt}/{max_attempts}), "
                    f"retry: {stderr.strip().splitlines()[-1] if stderr.strip() else exc}"
                ),
            ))

    try:
        run_rclone_with_retry(
            [rclone_path, "copy", str(source_dir), target_dir],
            on_retry=_on_retry,
        )
    except subprocess.CalledProcessError as e:
        msg = f"Web-Deployment fehlgeschlagen: {e.stderr or e}"
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOY_FAILED,
                message=msg,
            ))
        # Cleaned-up Mediasets sind real gelöscht — Notification soll sie
        # auch dann markieren, wenn der nachfolgende Upload scheitert.
        return DeployResult(
            success=False, error_message=msg,
            cleaned_up_web_ids=cleaned_up_web_ids,
        )
    except Exception as e:
        msg = f"Web-Deployment fehlgeschlagen: {e}"
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOY_FAILED,
                message=msg,
            ))
        return DeployResult(
            success=False, error_message=msg,
            cleaned_up_web_ids=cleaned_up_web_ids,
        )

    if on_event:
        on_event(FamilienfilmEvent(
            stage_id=FamilienfilmStage.WEB_DEPLOYED,
            message=f"Web-Deployment: {web_id_name} → {target_dir}",
        ))

    # Post-Deploy Health-Check: das Web-ID-Verzeichnis muss auf dem Server da sein.
    # Wir prüfen gegen das übergeordnete Verzeichnis (parent), um nach dem web_id_name
    # als Eintrag zu suchen.
    parent_target = web_target.rstrip("/")
    ok, missing = verify_rclone_target_contains(
        parent_target, [web_id_name], rclone_path=rclone_path,
    )
    if not ok:
        msg = (
            f"Web-Deployment ist laut rclone erfolgreich, aber der Health-Check "
            f"findet das Verzeichnis '{web_id_name}' nicht in {parent_target}."
        )
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOY_FAILED,
                message=msg,
            ))
        return DeployResult(
            success=False, target_path=target_dir, error_message=msg,
            cleaned_up_web_ids=cleaned_up_web_ids,
        )
    if on_event:
        on_event(FamilienfilmEvent(
            stage_id=FamilienfilmStage.DEPLOYMENT_VERIFIED,
            message=f"Web-Deployment verifiziert: {web_id_name} im Ziel vorhanden",
        ))

    return DeployResult(
        success=True,
        target_path=target_dir,
        cleaned_up_web_ids=cleaned_up_web_ids,
    )
