"""Benachrichtigung: Protokolliert Publikations-Status in einer Markdown-Datei.

Seit v1.1.0 ist das Format Markdown (vorher HTML, ein Breaking Change).
Die Datei ist gleichzeitig State-Datenbank und Render-Output — Einträge
sind durch unsichtbare HTML-Kommentar-Marker abgegrenzt, die jeder MD-
Renderer (mega.nz, GitHub, Obsidian, Apple Notes, …) wegblendet:

::

    <!-- ffm-entry video-id="abc123" status="published" -->
    ## 01.05.2026 — Langnau im Emmental

    - **Status:** Veröffentlicht
    - **Web:** <https://mediathek.kurmann.swiss/...>
    - **Lokal:** `lyssach-nas:/Familienfilme/Final/2024`
    <!-- /ffm-entry -->

Auf mega.nz und anderen Cloud-Plattformen rendert MD nativ mit klickbaren
Links — anders als die alte HTML-Datei, die im Cloud-Browser nur als
Quelltext angezeigt wurde.

Jeder Eintrag erhält eine stabile ``video-id`` (SHA1-Prefix des absoluten
Quell-Pfads bzw. der URI), die das spätere Wiederfinden / Ersetzen
ermöglicht — unabhängig von Umbenennungen während der Publikation.

Limitierung: ``MAX_ENTRIES = 50`` (siehe ``notifier_markdown``). Beim
Append wird auf 50 jüngste getrimmt; älteste Einträge fallen raus.
"""

from __future__ import annotations

import hashlib
from datetime import datetime
from pathlib import Path

from familienfilm_manager.core.notifier_markdown import (
    MAX_ENTRIES,  # noqa: F401  (re-export für externe Konsumenten)
    EntryBlock,
    _now_iso,
    convert_all_pending_to_aborted,
    find_block_by_web_url,
    init_document,
    merge_documents,
    parse_blocks,
    refresh_document_header,
    render_document,
    render_entry,
    replace_or_prepend,
    trim_to_max_entries,
    update_status_in_body,
)


def derive_video_id(source_path: Path | str) -> str:
    """Stabile Kennung pro Quelldatei (SHA1-Prefix des absoluten Pfades / URI).

    Wird als ``video-id``-Attribut in den Entry-Marker geschrieben und erlaubt
    späteres Wiederfinden / Ersetzen des Eintrags. Unabhängig von Umbenennungen
    innerhalb der Publikation (Poster-Suffix-Stripping etc.).

    Für rclone-Quellen sollte die Original-URI übergeben werden (z.B.
    ``"nas:/Quelle/2026-04-15 foo.mov"``) — nicht der gestagede lokale Pfad.
    Sonst wechselt die ID bei jedem Staging.
    """
    if isinstance(source_path, str):
        return hashlib.sha1(source_path.encode("utf-8")).hexdigest()[:16]
    return hashlib.sha1(str(source_path.resolve()).encode("utf-8")).hexdigest()[:16]


def _ensure_storage(target):
    """Auflösung eines notification-targets zu einer ``NotificationStorage``.

    Akzeptiert: ``Path`` (lokal-only, kein Sync), ``str`` (lokal oder
    rclone-URI, via Resolver), oder ein bereits aufgelöstes
    ``NotificationStorage``-Objekt (durchgereicht).

    v0.12.0+: String-Werte mit rclone-URI (``mega.nz:...``, ``hostpoint:...``)
    bekommen einen lokalen Cache + Push-Sync zum Remote.
    """
    from familienfilm_manager.core.notifier_storage import (
        NotificationStorage,
        resolve_storage,
    )
    if isinstance(target, NotificationStorage):
        return target
    if isinstance(target, Path):
        return NotificationStorage(cache=target, remote=None)
    return resolve_storage(str(target))


def _read_or_init(target) -> str:
    storage = _ensure_storage(target)
    if storage.cache.exists():
        return storage.cache.read_text(encoding="utf-8")
    return init_document()


def _write(target, content: str, *, sync: bool = True) -> None:
    """Schreibt die MD in den lokalen Cache und synchronisiert optional zum Remote.

    Args:
        target: ``Path`` / ``str`` / ``NotificationStorage`` (siehe
            ``_ensure_storage``).
        content: Voller MD-Content.
        sync: Wenn True und ``target`` einen Remote hat, wird via
            ``rclone copyto`` zum Remote synchronisiert. v0.12.0+:
            real-time-relevante Updates (pending/published/failed/cleaned-up)
            syncen, interne Hygiene-Updates lassen ``sync=False`` und
            warten auf den nächsten echten Sync.

    Multi-Machine-Merge (v1.1.0+): Bei ``sync=True`` und einem rclone-
    Remote wird vor dem Schreiben der Remote-Stand frisch gepullt und mit
    unserem modifizierten Content vereinigt (Union per ``video-id``,
    jüngerer ``updated``-Timestamp gewinnt). Damit überschreibt ein
    zweiter Rechner, der parallel publiziert, unsere Einträge nicht.
    Bei rein lokalem Target oder ``sync=False`` (interne Hygiene wie
    ``mark_all_pending_as_aborted``) wird nicht gemerged.
    """
    from familienfilm_manager.core.notifier_storage import (
        fetch_remote_content,
        push_to_remote,
    )

    storage = _ensure_storage(target)
    if sync and storage.is_remote:
        remote_content = fetch_remote_content(storage)
        if remote_content is not None:
            content = merge_documents(local=content, remote=remote_content)
    storage.cache.parent.mkdir(parents=True, exist_ok=True)
    storage.cache.write_text(content, encoding="utf-8")
    if sync:
        push_to_remote(storage)


def append_pending(
    notification_path: "Path | str",
    *,
    video_id: str,
    title: str,
    category: str | None = None,
    recording_date: str | None = None,
) -> None:
    """Trägt einen „In Bearbeitung"-Eintrag ganz oben ein.

    Wenn bereits ein Eintrag mit dieser ``video_id`` existiert, wird er ersetzt
    (vermeidet Duplikate bei Republish). Trimmt nach dem Insert auf
    ``MAX_ENTRIES``.
    """
    entry = render_entry(
        video_id=video_id,
        status="pending",
        title=title,
        category=category,
        recording_date=recording_date,
    )
    content = refresh_document_header(_read_or_init(notification_path))
    content = replace_or_prepend(content, video_id, entry)
    content = trim_to_max_entries(content)
    _write(notification_path, content)


def replace_entry_published(
    notification_path: "Path | str",
    *,
    video_id: str,
    title: str,
    video_url: str | None = None,
    category: str | None = None,
    recording_date: str | None = None,
    infuse_target_path: str | None = None,
    archive_target_path: str | None = None,  # bewusst ignoriert in MD (v1.1.0+)
) -> None:
    """Ersetzt einen bestehenden Eintrag mit der „Veröffentlicht"-Variante.

    Zeigt pro publiziertem Kanal eine Zeile:
    - **Web:** ``<URL>`` (klickbar in jedem MD-Renderer)
    - **Lokal:** rclone-Target-Pfad des Infuse/lokal-Verzeichnisses

    Der Archiv-Pfad wird in v1.1.0+ bewusst NICHT mehr gerendert — Archiv
    ist Backend-Detail, das in der Status-Übersicht keinen Mehrwert bietet.
    Der ``archive_target_path``-Parameter bleibt aus Kompat-Gründen und
    wird ignoriert.

    Fällt auf Einfügen zurück, wenn der Eintrag nicht existiert (z.B. wenn
    die Datei zwischen Start und Abschluss gelöscht wurde).
    """
    entry = render_entry(
        video_id=video_id,
        status="published",
        title=title,
        web_url=video_url,
        local_target=infuse_target_path,
        category=category,
        recording_date=recording_date,
    )
    content = refresh_document_header(_read_or_init(notification_path))
    content = replace_or_prepend(content, video_id, entry)
    content = trim_to_max_entries(content)
    _write(notification_path, content)


def replace_entry_failed(
    notification_path: "Path | str",
    *,
    video_id: str,
    title: str,
    error_message: str,
    category: str | None = None,
    recording_date: str | None = None,
) -> None:
    """Ersetzt einen bestehenden Eintrag mit der „Fehlgeschlagen"-Variante.

    Die Fehlermeldung erscheint in der Status-Zeile:
    ``- **Status:** Fehlgeschlagen — <error_message>``
    """
    entry = render_entry(
        video_id=video_id,
        status="failed",
        title=title,
        error_message=error_message,
        category=category,
        recording_date=recording_date,
    )
    content = refresh_document_header(_read_or_init(notification_path))
    content = replace_or_prepend(content, video_id, entry)
    content = trim_to_max_entries(content)
    _write(notification_path, content)


def mark_entry_cleaned_up(
    notification_path: "Path | str",
    *,
    web_id: str,
    branding_base_url: str,
    cleanup_date: str | None = None,
    reason: str | None = None,
) -> bool:
    """Markiert den Eintrag, dessen Web-URL ``{base}/{web_id}/`` enthält,
    als „Aus Web-Speicher entfernt am {cleanup_date}" (v0.10.0+).

    Wenn ``reason`` gesetzt ist (z.B. ``"älter als 365 Tage"``), wird er
    in Klammern an den Status-Text angehängt. Die Web-Zeile bleibt im
    Eintrag stehen — das ist Teil der Geschichte; der Status-Text
    signalisiert, dass die URL nicht mehr live ist.

    Tolerant gegen fehlende oder unzugängliche Datei: gibt einfach
    ``False`` zurück und ändert nichts. Idempotent — wenn der Eintrag
    schon ``cleaned-up`` ist, passiert nichts.
    """
    storage = _ensure_storage(notification_path)
    if not storage.cache.exists():
        return False
    try:
        content = storage.cache.read_text(encoding="utf-8")
    except OSError:
        return False
    if not branding_base_url:
        return False

    base = branding_base_url.rstrip("/")
    web_url_marker = f"{base}/{web_id}/"
    target = find_block_by_web_url(content, web_url_marker)
    if target is None:
        return False
    if target.status == "cleaned-up":
        return True

    today = cleanup_date or datetime.now().strftime("%d.%m.%Y")
    reason_part = f" ({reason})" if reason else ""
    new_status_text = f"Aus Web-Speicher entfernt am {today}{reason_part}"
    new_body = update_status_in_body(target.body, new_status_text)
    # Cleanup ist eine echte Status-Änderung — frischer Timestamp, damit
    # der Eintrag im Multi-Machine-Merge gegen ältere Versionen gewinnt.
    updated_block = EntryBlock(
        video_id=target.video_id,
        status="cleaned-up",
        updated=_now_iso(),
        title_line=target.title_line,
        body=new_body,
    )

    blocks = parse_blocks(content)
    new_blocks = [
        updated_block if b.video_id == target.video_id else b
        for b in blocks
    ]
    new_content = render_document(new_blocks)
    _write(storage, new_content)
    return True


def mark_all_pending_as_aborted(notification_path: "Path | str") -> int:
    """Setzt alle ``pending``-Einträge auf ``aborted``.

    Vorgesehen für den Start eines Watch-Prozesses: wenn beim letzten Lauf
    ein Publish mitten drin abgebrochen wurde, bleibt sonst ein pending-
    Eintrag ewig stehen. Gibt die Anzahl der geänderten Einträge zurück.

    v0.12.0+: Diese interne Hygiene-Markierung wird **nicht** sofort zum
    Remote synchronisiert (``sync=False``). Sie geht beim nächsten echten
    Update (pending/published/failed) automatisch mit raus.
    """
    storage = _ensure_storage(notification_path)
    if not storage.cache.exists():
        return 0
    content = storage.cache.read_text(encoding="utf-8")
    new_content, count = convert_all_pending_to_aborted(content)
    if count:
        _write(storage, new_content, sync=False)
    return count
