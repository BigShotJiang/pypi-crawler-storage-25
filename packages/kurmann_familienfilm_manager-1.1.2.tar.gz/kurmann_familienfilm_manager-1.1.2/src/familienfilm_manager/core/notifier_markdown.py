"""Markdown-Renderer und -Parser für die Notification-Datenbank (v1.1.0+).

Markdown ist seit v1.1.0 **gleichzeitig State-Storage und Render-Output**
für die Publikations-Benachrichtigung. Anders als in einer Vor-Iteration
desselben Releases verwenden wir KEINE HTML-Kommentar-Marker mehr (die im
Roh-MD-Format als „wüst" empfunden wurden), sondern ein konventionsbasiertes
Format mit sichtbaren Block-Quote-Metadaten:

::

    # Familienfilme

    > _Diese Datei wird automatisch vom Familienfilm-Manager geschrieben._
    > _Bitte nicht manuell editieren — Änderungen werden beim nächsten
    > Publish überschrieben._

    _Aktualisiert: 01.05.2026, 14:58_

    ## 01.05.2026 — Langnau im Emmental
    > id: d969107420757722 · status: published · aktualisiert: 2026-05-01T12:57:45Z

    - **Status:** Veröffentlicht
    - **Aufnahmedatum:** 04.02.2024
    - **Web:** <https://mediathek.kurmann.swiss/mteyn0n1pm9d/>
    - **Lokal:** `lyssach-nas:/Familienfilme/Final/2024`

Read-Modify-Write findet Einträge per H2-Boundary (jedes ``## `` startet einen
neuen Eintrag). Die Metadaten-Zeile direkt unter dem H2 trägt ``id``,
``status`` und ``aktualisiert`` (UTC-ISO-Timestamp für Multi-Machine-Merge).
H2-Blöcke ohne diese Metadaten-Zeile werden übersprungen — das ist die
sanfte Abgrenzung zu vom Nutzer manuell hinzugefügtem Inhalt.

Älteste Einträge werden auf ``MAX_ENTRIES`` getrimmt.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timezone

# Maximalzahl der Einträge in der Datei. Überschreitende werden bei Append
# weggeschnitten (älteste verschwinden zuerst). Hardcodiert als Modul-
# konstante — auf mega.nz / iPhone ist eine kurze, scrollbare Liste
# angenehmer als die volle Historie.
MAX_ENTRIES = 50

# Klartext-Labels für die Status-Zeile. Failed und cleaned-up werden zur
# Laufzeit erweitert (Fehlermeldung bzw. Datum + Grund).
STATUS_LABELS = {
    "pending": "In Bearbeitung",
    "published": "Veröffentlicht",
    "failed": "Fehlgeschlagen",
    "aborted": "Abgebrochen",
    "cleaned-up": "Aus Web-Speicher entfernt",
}

# Hinweis-Block direkt unter dem H1, der dem User bei Roh-Inspektion klar
# macht: hier nicht mit der Hand reineditieren. Mehrzeiliges Block-Quote,
# rendert in jedem MD-Viewer als kleiner kursiv-grauer Kasten.
DOC_HINT = (
    "> _Diese Datei wird automatisch vom Familienfilm-Manager geschrieben._\n"
    "> _Bitte nicht manuell editieren — Änderungen werden beim nächsten "
    "Publish überschrieben._"
)

# Doc-Header. Wird bei jedem Write per ``refresh_document_header`` mit dem
# aktuellen Zeitstempel überschrieben.
# Match: ab ``# Familienfilme`` bis und einschliesslich der ersten Leerzeile
# nach ``_Aktualisiert: …_``. ``.*?`` non-greedy verschluckt den Hinweis-Block,
# egal ob er sich zwischen Versionen leicht ändert.
_DOC_HEADER_RE = re.compile(
    r"^# Familienfilme\n.*?_Aktualisiert: [^\n]+_\n\n",
    re.DOTALL,
)

# Match für eine H2-Zeile (Eintrag-Beginn).
_H2_RE = re.compile(r"^## .*$", re.MULTILINE)

# Match für die Metadaten-Zeile direkt unter einem H2:
#     > id: d969107420757722 · status: published · aktualisiert: 2026-05-01T12:57:45Z
_META_RE = re.compile(
    r"^> id: (?P<video_id>\S+) · status: (?P<status>\S+) · "
    r"aktualisiert: (?P<updated>\S+)\s*$",
    re.MULTILINE,
)


def _now_label() -> str:
    return datetime.now().strftime("%d.%m.%Y, %H:%M")


def _today_label() -> str:
    return datetime.now().strftime("%d.%m.%Y")


def _now_iso() -> str:
    """Aktueller Zeitstempel als UTC-ISO 8601, lexikographisch sortierbar.

    Wird in das ``aktualisiert``-Feld der Metadaten-Zeile geschrieben und
    dient dem Multi-Machine-Merge: bei identischer ``id`` in zwei Quellen
    gewinnt der Eintrag mit dem grösseren ``aktualisiert``.
    """
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def render_document_header() -> str:
    return (
        f"# Familienfilme\n\n"
        f"{DOC_HINT}\n\n"
        f"_Aktualisiert: {_now_label()}_\n\n"
    )


def init_document() -> str:
    """Leeres Dokument mit Header (kein Entry)."""
    return render_document_header()


def render_entry(
    *,
    video_id: str,
    status: str,
    title: str,
    update_date: str | None = None,
    recording_date: str | None = None,
    category: str | None = None,
    web_url: str | None = None,
    local_target: str | None = None,
    error_message: str | None = None,
    cleanup_date: str | None = None,
    cleanup_reason: str | None = None,
    updated: str | None = None,
) -> str:
    """Rendert einen kompletten Entry-Block (H2 + Metadaten-Quote + Bullets + Trenn-Leerzeile).

    Die Felder ``updated`` und ``update_date`` sind primär für Tests
    explizit setzbar; im Normalbetrieb werden sie aus dem aktuellen
    Zeitpunkt abgeleitet.
    """
    label = update_date or _today_label()
    timestamp = updated or _now_iso()

    # Status-Zeile — Failed und cleaned-up bekommen erweiterten Text.
    status_text = STATUS_LABELS.get(status, status)
    if status == "failed" and error_message:
        status_text = f"{status_text} — {error_message}"
    elif status == "cleaned-up":
        date_part = cleanup_date or _today_label()
        reason_part = f" ({cleanup_reason})" if cleanup_reason else ""
        status_text = f"Aus Web-Speicher entfernt am {date_part}{reason_part}"

    bullets: list[str] = [f"- **Status:** {status_text}"]
    if recording_date:
        bullets.append(f"- **Aufnahmedatum:** {recording_date}")
    if category:
        bullets.append(f"- **Kategorie:** {category}")
    if web_url:
        bullets.append(f"- **Web:** <{web_url}>")
    if local_target:
        bullets.append(f"- **Lokal:** `{local_target}`")
    body = "\n".join(bullets)

    title_line = f"## {label} — {title}"
    return _format_block(
        title_line=title_line,
        video_id=video_id,
        status=status,
        updated=timestamp,
        body=body,
    )


def _format_block(
    *,
    title_line: str,
    video_id: str,
    status: str,
    updated: str,
    body: str,
) -> str:
    """Setzt H2-Titel + Metadaten-Quote + Body zu einem Eintrags-Block zusammen."""
    return (
        f"{title_line}\n"
        f"> id: {video_id} · status: {status} · aktualisiert: {updated}\n"
        "\n"
        f"{body.rstrip()}\n"
        "\n"
    )


# ── Strukturierte Sicht für Merge-Operationen (v1.1.0+) ────────────────


@dataclass
class EntryBlock:
    """Strukturierte Sicht eines Entry-Blocks.

    ``title_line`` enthält die komplette H2-Zeile inkl. ``## ``-Präfix
    (z.B. ``"## 01.05.2026 — Langnau im Emmental"``).
    ``body`` ist der Bullet-Block ohne Titel und ohne Metadaten-Quote,
    so wie er in der Datei steht — enthält Status, Aufnahmedatum, Web,
    Lokal etc.
    """

    video_id: str
    status: str
    updated: str
    title_line: str
    body: str


def parse_blocks(content: str) -> list[EntryBlock]:
    """Zerlegt ein MD-Dokument in strukturierte EntryBlocks.

    Boundary-Logik: jede H2-Zeile (``^## ``) startet einen neuen Block,
    der bis zur nächsten H2-Zeile (oder EOF) reicht. Innerhalb eines
    Blocks wird die Metadaten-Zeile (``> id: … · status: … · aktualisiert: …``)
    gesucht; H2-Blöcke ohne Metadaten werden übersprungen (das schützt
    vor unbeabsichtigten Treffern, falls der User einen eigenen H2 in die
    Datei einfügt — laut Hinweisblock unerwünscht, aber tolerant).
    """
    h2_matches = list(_H2_RE.finditer(content))
    if not h2_matches:
        return []

    blocks: list[EntryBlock] = []
    for i, h2 in enumerate(h2_matches):
        chunk_start = h2.start()
        chunk_end = (
            h2_matches[i + 1].start() if i + 1 < len(h2_matches) else len(content)
        )
        chunk = content[chunk_start:chunk_end]

        title_line, _, rest = chunk.partition("\n")

        meta_match = _META_RE.search(rest)
        if meta_match is None:
            # Kein FFM-Metadaten-Quote → wahrscheinlich vom User eingefügter
            # H2 → still überspringen.
            continue

        body = rest[meta_match.end() :].strip("\n")

        blocks.append(
            EntryBlock(
                video_id=meta_match["video_id"],
                status=meta_match["status"],
                updated=meta_match["updated"],
                title_line=title_line,
                body=body,
            )
        )
    return blocks


def render_block(block: EntryBlock) -> str:
    """Re-emittiert einen EntryBlock als String."""
    return _format_block(
        title_line=block.title_line,
        video_id=block.video_id,
        status=block.status,
        updated=block.updated,
        body=block.body,
    )


def render_document(blocks: list[EntryBlock]) -> str:
    """Rendert ein komplettes Dokument: frischer Header + Blocks in Reihenfolge."""
    parts = [render_document_header()]
    for block in blocks:
        parts.append(render_block(block))
    return "".join(parts).rstrip() + "\n"


def replace_or_prepend(
    content: str, video_id: str, new_entry_block: str,
) -> str:
    """Ersetzt einen bestehenden Block (matched by video-id) inplace,
    oder fügt ihn ganz oben ein (vor allen anderen Einträgen).

    ``new_entry_block`` ist die String-Form (wie von ``render_entry``
    geliefert); intern wird sie geparst, damit das Dokument konsistent
    wieder aus ``EntryBlock``-Instanzen aufgebaut werden kann.
    """
    parsed_new = parse_blocks(new_entry_block)
    if not parsed_new:
        # Sollte nicht passieren bei korrekt gerendertem Block.
        return content
    new_block = parsed_new[0]

    existing = parse_blocks(content)
    found = False
    next_blocks: list[EntryBlock] = []
    for block in existing:
        if block.video_id == video_id:
            next_blocks.append(new_block)
            found = True
        else:
            next_blocks.append(block)
    if not found:
        next_blocks.insert(0, new_block)

    return render_document(next_blocks)


def trim_to_max_entries(content: str, max_entries: int = MAX_ENTRIES) -> str:
    """Behält die ersten ``max_entries`` Einträge (in Datei-Reihenfolge)."""
    blocks = parse_blocks(content)
    if len(blocks) <= max_entries:
        return content
    return render_document(blocks[:max_entries])


def update_status_in_body(body: str, status_text: str) -> str:
    """Ersetzt die ``- **Status:** …``-Zeile durch eine neue."""
    return re.sub(
        r"^- \*\*Status:\*\* .*$",
        f"- **Status:** {status_text}",
        body,
        count=1,
        flags=re.MULTILINE,
    )


def refresh_document_header(content: str) -> str:
    """Aktualisiert den Header (oder fügt ihn hinzu wenn fehlend)."""
    if _DOC_HEADER_RE.match(content):
        return _DOC_HEADER_RE.sub(render_document_header(), content, count=1)
    return render_document_header() + content


def find_block_by_web_url(
    content: str, web_url_substring: str,
) -> EntryBlock | None:
    """Findet den ersten Eintrag, dessen Body ``web_url_substring`` enthält."""
    for block in parse_blocks(content):
        if web_url_substring in block.body:
            return block
    return None


def convert_all_pending_to_aborted(content: str) -> tuple[str, int]:
    """Setzt alle pending-Einträge auf aborted.

    Returns (new_content, count_changed). Der ``aktualisiert``-Zeitstempel
    wird bei jedem konvertierten Eintrag auf jetzt gesetzt — das ist eine
    echte Status-Änderung, die im Multi-Machine-Merge gegen ältere Versionen
    gewinnen soll.
    """
    blocks = parse_blocks(content)
    if not blocks:
        return content, 0

    timestamp = _now_iso()
    count = 0
    new_blocks: list[EntryBlock] = []
    for block in blocks:
        if block.status == "pending":
            count += 1
            new_body = update_status_in_body(block.body, STATUS_LABELS["aborted"])
            new_blocks.append(
                EntryBlock(
                    video_id=block.video_id,
                    status="aborted",
                    updated=timestamp,
                    title_line=block.title_line,
                    body=new_body,
                )
            )
        else:
            new_blocks.append(block)
    if count == 0:
        return content, 0
    return render_document(new_blocks), count


# ── Multi-Machine-Merge ───────────────────────────────────────────────


# Sentinel für Einträge, die kein ``aktualisiert`` haben (Pre-merge oder
# defekt). Lexikographisch ältester ISO-Zeitstempel — verlieren immer
# gegen einen frischen Eintrag.
_OLD_TIMESTAMP_SENTINEL = "1970-01-01T00:00:00Z"


def merge_documents(
    *, local: str, remote: str, max_entries: int = MAX_ENTRIES,
) -> str:
    """Vereinigt zwei Dokumente per ``video-id``-Union (Multi-Machine-Safe).

    Strategie:
    - Beide Quellen werden in EntryBlocks zerlegt.
    - Für jede ``video-id`` gewinnt der Eintrag mit dem grösseren
      ``updated``-Timestamp (lexikographische ISO-8601-Vergleich genügt).
      Bei Gleichstand gewinnt local — denn local enthält bereits unsere
      frische Modifikation, die wir definitiv pushen wollen.
    - Sortierung absteigend nach ``updated`` (jüngstes zuerst), Trimmung
      auf ``max_entries``, frischer Doc-Header.

    Wird vor jedem Push aufgerufen, wenn das Target ein rclone-Remote
    ist. Bei rein lokalem Target macht der Caller diese Operation gar
    nicht erst auf — siehe ``notifier._write``.
    """
    by_id: dict[str, EntryBlock] = {}
    # Remote zuerst: local kann bei Gleichstand gewinnen.
    for block in parse_blocks(remote):
        by_id[block.video_id] = block
    for block in parse_blocks(local):
        existing = by_id.get(block.video_id)
        local_updated = block.updated or _OLD_TIMESTAMP_SENTINEL
        existing_updated = existing.updated if existing else _OLD_TIMESTAMP_SENTINEL
        if existing is None or local_updated >= existing_updated:
            by_id[block.video_id] = block

    sorted_blocks = sorted(
        by_id.values(),
        key=lambda b: b.updated or _OLD_TIMESTAMP_SENTINEL,
        reverse=True,
    )
    sorted_blocks = sorted_blocks[:max_entries]
    return render_document(sorted_blocks)
