"""Sidecar-Manager: Lesen/Schreiben von Settings-Dateien neben dem Video."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path

import tomllib

# v0.12.0+: Format-Version der ``.settings.toml``. Wird beim Write immer
# in ``[meta].schema_version`` gesetzt; beim Read als optional behandelt
# (fehlt → pre-v0.12.0-Sidecar, alle bisherigen Formate werden weiter
# unterstützt). Eine künftige Version würde inkrementiert wenn ein
# Read-Path nötig wird, der pre-v0.12.0-Daten erkennen muss.
SETTINGS_SCHEMA_VERSION = 1

# Grösse des Kopf-Samples für den Fingerprint (SHA1 der ersten N Bytes).
# 1 MB ist ein guter Kompromiss: kollisionssicher genug für Identitätsprüfung
# und schnell genug auch auf langsamen Netzwerk-Shares (~100ms bei SMB).
HEAD_HASH_BYTES = 1 * 1024 * 1024


def compute_source_fingerprint(video_path: Path) -> tuple[int, str]:
    """Berechnet (size_bytes, head_sha1_hex) für die Quelldatei.

    Der Fingerprint wird als Identitätsanker verwendet — robuster als mtime,
    die auf SMB/NAS-Shares unzuverlässig ist.
    """
    size = video_path.stat().st_size
    hasher = hashlib.sha1()
    with video_path.open("rb") as f:
        hasher.update(f.read(HEAD_HASH_BYTES))
    return size, hasher.hexdigest()


@dataclass
class SidecarSettings:
    """Persistierte Einstellungen in einer .settings.toml Datei neben dem Video.

    Jeder der drei Deploy-Kanäle (``web``, ``local``, ``archive``) hat einen
    eigenen ``published_at``-Zeitstempel **und** seit v0.8.0 einen eigenen
    Fingerprint (``source_size_bytes`` + ``source_head_sha1``). Beides wird
    nur nach erfolgreichem Deploy dieses Kanals geschrieben. Die Skip-Logik
    bei ``publish-dir`` / ``watch-dir`` verlangt, dass **alle aktiven Kanäle**
    einen Zeitstempel UND einen passenden Fingerprint haben — Teilerfolge
    oder Quelldatei-Änderungen führen zum gezielten Nachholen nur der
    fehlenden/veralteten Kanäle.

    Per-Kanal-Fingerprint (v0.8.0): Wenn sich die Quelldatei ändert aber nur
    ein Kanal hatte zuvor einen Deploy-Fehler, wird nun **nur** dieser
    eine Kanal re-publiziert — nicht alle drei (wie vor v0.8.0).
    """

    # Poster-Einstellungen
    frame_number: int | None = None
    timestamp_seconds: float | None = None
    crop_position: str | None = None
    poster_selected_by: str | None = None
    """v0.11.0+: Wer hat das Poster gewählt? ``"manual"`` (CLI/Sidecar/Filename),
    ``"ai"`` (Claude über Vorschaubild-Manager) oder ``"sidecar-image"``
    (neben dem Video lag ein Bild als Vorlage). Bei ``"ai"`` werden die Werte
    beim nächsten Republish wiederverwendet — ohne neuen KI-Aufruf."""
    poster_ai_reasoning: str | None = None
    """v0.11.0+: KI-Begründung für den Frame-Vorschlag (nur bei
    ``poster_selected_by == "ai"``). Reine Doku — keine Logik liest sie."""

    # Poison-Detection (v0.11.0): konsekutive Fehlversuche zählen, damit
    # watch-dir nicht ewig dasselbe kaputte Video bei jedem Tick erneut
    # versucht. Wird durch Source-Fingerprint-Änderung resettet.
    publish_failure_count: int | None = None
    publish_last_failure_at: str | None = None  # ISO-8601
    publish_last_failure_reason: str | None = None  # erste Zeile, gekürzt

    # Web-Kanal (Hostpoint / öffentlicher Webserver)
    web_id: str | None = None
    max_luminance: int | None = None
    web_published_at: str | None = None
    web_enabled: bool | None = None
    web_source_size_bytes: int | None = None
    web_source_head_sha1: str | None = None

    # Local-Kanal (Infuse / Medienserver im LAN)
    local_published_at: str | None = None
    local_source_size_bytes: int | None = None
    local_source_head_sha1: str | None = None

    # Archive-Kanal (TAR im Langzeit-Archiv)
    archive_published_at: str | None = None
    archive_source_size_bytes: int | None = None
    archive_source_head_sha1: str | None = None

    # Legacy-globaler Fingerprint (≤ v0.7.0). Nur für Read-Fallback —
    # wird beim nächsten Publish durch per-Kanal-Werte ersetzt und ab da
    # nicht mehr geschrieben. Siehe ``fingerprint_for_channel``.
    source_size_bytes: int | None = None
    source_head_sha1: str | None = None

    # Effektive Metadaten (für selbsttragendes Archiv)
    category: str | None = None

    # v0.12.0+: Format-Version der Sidecar-Datei. Steht im ``[meta]``-Block
    # (nicht zu verwechseln mit ``[metadata]`` für semantische Video-Daten).
    # Beim Read: None bedeutet pre-v0.12.0-Sidecar (= heutiges Verhalten,
    # alle bestehenden Formate werden unterstützt). Beim Write wird immer
    # SETTINGS_SCHEMA_VERSION gesetzt.
    schema_version: int | None = None

    def fingerprint_for_channel(self, channel: str) -> tuple[int | None, str | None]:
        """Liefert (size, head_sha1) für einen Kanal mit Legacy-Fallback.

        Ordnung:
        1. Per-Kanal-Werte (v0.8.0+), wenn beide gesetzt.
        2. Globaler ``[source]``-Block (v0.7.0 und früher).
        3. ``(None, None)`` wenn nichts bekannt.
        """
        per_channel = {
            "web": (self.web_source_size_bytes, self.web_source_head_sha1),
            "local": (self.local_source_size_bytes, self.local_source_head_sha1),
            "archive": (self.archive_source_size_bytes, self.archive_source_head_sha1),
        }.get(channel, (None, None))
        size, head = per_channel
        if size is not None and head is not None:
            return size, head
        return self.source_size_bytes, self.source_head_sha1

    def has_values(self) -> bool:
        """Prüft ob mindestens ein Wert gesetzt ist."""
        return any(v is not None for v in (
            self.frame_number, self.timestamp_seconds, self.crop_position,
            self.poster_selected_by, self.poster_ai_reasoning,
            self.web_id, self.max_luminance,
            self.web_published_at, self.web_enabled,
            self.web_source_size_bytes, self.web_source_head_sha1,
            self.local_published_at,
            self.local_source_size_bytes, self.local_source_head_sha1,
            self.archive_published_at,
            self.archive_source_size_bytes, self.archive_source_head_sha1,
            self.source_size_bytes, self.source_head_sha1,
            self.category,
            self.publish_failure_count, self.publish_last_failure_at,
            self.publish_last_failure_reason,
        ))

    @property
    def is_legacy_pre_channels(self) -> bool:
        """Legacy-Sidecar (≤ 0.6.0 RC) mit ``web_published_at`` aber ohne
        ``local_published_at`` oder ``archive_published_at``.

        Semantik des alten ``[web].published_at``: „irgendwas wurde publiziert",
        aber welcher Kanal ist unklar. Konservative Annahme für die Migration:
        behandeln als „noch nicht vollständig publiziert" → nächster Lauf
        republiziert voll und füllt alle drei Zeitstempel.
        """
        return (
            self.web_published_at is not None
            and self.local_published_at is None
            and self.archive_published_at is None
        )


def channel_needs_publish(
    sidecar: SidecarSettings,
    channel: str,
    *,
    active: bool,
    current_fingerprint: tuple[int | None, str | None],
) -> bool:
    """Entscheidet, ob ein Kanal publiziert werden muss.

    Args:
        sidecar: Aktueller Sidecar-Stand.
        channel: ``"web"``, ``"local"`` oder ``"archive"``.
        active: Ob der Kanal für diesen Lauf überhaupt aktiv ist
            (``effective_web_enabled`` / ``not skip_infuse`` / ``not skip_archive``).
        current_fingerprint: ``(size, head_sha1)`` der aktuellen Quelldatei.
            Beim Remote-Light-Peek darf ``head_sha1`` None sein — dann wird
            nur ``size`` verglichen.

    Returns:
        True, wenn der Kanal publiziert/re-publiziert werden muss.
        False, wenn der Kanal inaktiv oder bereits aktuell ist.
    """
    if not active:
        return False

    published_at = {
        "web": sidecar.web_published_at,
        "local": sidecar.local_published_at,
        "archive": sidecar.archive_published_at,
    }.get(channel)

    if not published_at:
        return True

    stored_size, stored_head = sidecar.fingerprint_for_channel(channel)
    current_size, current_head = current_fingerprint

    # Ohne gespeicherten Fingerprint: konservativ republishen (unbekannte Historie).
    if stored_size is None:
        return True

    if current_size is not None and current_size != stored_size:
        return True

    # Head-SHA1 ist bei Remote-Light-Peek nicht verfügbar → nur prüfen wenn beide Seiten da.
    if stored_head is not None and current_head is not None and current_head != stored_head:
        return True

    return False


def sidecar_path_for(video_path: Path) -> Path:
    """Gibt den Pfad zur Sidecar-Datei zurück."""
    return video_path.parent / f"{video_path.stem}.settings.toml"


def record_publish_failure(
    video_path: Path,
    *,
    reason: str,
    current_fingerprint: tuple[int | None, str | None] | None = None,
) -> None:
    """Erhöht ``[publish].failure_count`` im Sidecar um 1 und merkt Grund + Datum.

    Wenn der aktuelle Fingerprint sich vom gespeicherten unterscheidet, wird
    der Counter zuerst auf 0 zurückgesetzt (neue Datei → neuer Versuch).

    Tolerant gegen fehlende Sidecar (legt eine an).
    """
    from datetime import datetime

    sidecar = read_sidecar(video_path)

    # Reset wenn Source-Fingerprint sich geändert hat seit dem letzten Fail.
    if current_fingerprint is not None and sidecar.publish_failure_count:
        stored_size = (
            sidecar.web_source_size_bytes
            or sidecar.local_source_size_bytes
            or sidecar.archive_source_size_bytes
            or sidecar.source_size_bytes
        )
        cur_size, _ = current_fingerprint
        if cur_size is not None and stored_size is not None and cur_size != stored_size:
            sidecar.publish_failure_count = 0

    sidecar.publish_failure_count = (sidecar.publish_failure_count or 0) + 1
    sidecar.publish_last_failure_at = datetime.now().isoformat(timespec="seconds")
    # Reason auf eine kurze Zeile reduzieren, damit das Sidecar lesbar bleibt.
    short_reason = (reason or "unbekannter Fehler").splitlines()[0][:200]
    sidecar.publish_last_failure_reason = short_reason
    write_sidecar(video_path, sidecar)


def record_publish_failure_remote(
    video_uri: str,
    *,
    reason: str,
    current_size: int | None,
    work_dir: Path,
    rclone_path: str = "rclone",
) -> None:
    """v0.12.0+: Wie ``record_publish_failure``, aber für rclone-Quellen.

    Liest die Sidecar via ``rclone cat`` vom Remote, erhöht den Failure-
    Counter, und schreibt die geänderte Sidecar via ``rclone copyto`` zurück.
    Source-Fingerprint-Reset funktioniert analog (per ``current_size``).

    Tolerant gegen Fehler: wenn der Read oder Write scheitert, wird die
    Exception nach oben propagiert — der Caller (directory_publisher
    rclone-Pfad) entscheidet ob er das ignoriert.
    """
    from datetime import datetime

    from familienfilm_manager.core._rclone import (
        rclone_cat,
        rclone_copyto,
    )
    from familienfilm_manager.core.source_ref import SourceRef

    video_ref = SourceRef(video_uri)
    sidecar_name = f"{video_ref.stem}.settings.toml"
    parent_uri = video_ref.parent_uri()
    if parent_uri.endswith(":"):
        sidecar_uri = f"{parent_uri}{sidecar_name}"
    else:
        sidecar_uri = f"{parent_uri.rstrip('/')}/{sidecar_name}"

    # 1. Aktuelle Remote-Sidecar laden (oder leer initialisieren)
    raw = rclone_cat(sidecar_uri, rclone_path=rclone_path)
    work_dir.mkdir(parents=True, exist_ok=True)
    # Wir benutzen einen Stand-In-Video-Pfad im work_dir, damit
    # read_sidecar / write_sidecar den Sidecar-Pfad daneben ableiten.
    shadow_video = work_dir / video_ref.name
    shadow_video.touch()
    shadow_sidecar = work_dir / sidecar_name
    if raw is not None:
        shadow_sidecar.write_bytes(raw)
        sidecar = read_sidecar(shadow_video)
    else:
        sidecar = SidecarSettings()

    # 2. Reset wenn Source-Größe sich geändert hat seit dem letzten Fail.
    if current_size is not None and sidecar.publish_failure_count:
        stored_size = (
            sidecar.web_source_size_bytes
            or sidecar.local_source_size_bytes
            or sidecar.archive_source_size_bytes
            or sidecar.source_size_bytes
        )
        if stored_size is not None and current_size != stored_size:
            sidecar.publish_failure_count = 0

    sidecar.publish_failure_count = (sidecar.publish_failure_count or 0) + 1
    sidecar.publish_last_failure_at = datetime.now().isoformat(timespec="seconds")
    sidecar.publish_last_failure_reason = (
        reason or "unbekannter Fehler"
    ).splitlines()[0][:200]

    # 3. Lokal schreiben + zurück zum Remote
    write_sidecar(shadow_video, sidecar)
    rclone_copyto(str(shadow_sidecar), sidecar_uri, rclone_path=rclone_path)


def clear_publish_failures(video_path: Path) -> None:
    """Löscht ``[publish].failure_*``-Felder im Sidecar nach erfolgreichem Lauf.

    No-op wenn keine Sidecar existiert oder keine Failures protokolliert sind.
    """
    sidecar = read_sidecar(video_path)
    if not sidecar.publish_failure_count and not sidecar.publish_last_failure_at:
        return
    sidecar.publish_failure_count = None
    sidecar.publish_last_failure_at = None
    sidecar.publish_last_failure_reason = None
    write_sidecar(video_path, sidecar)


# v0.11.0: Poison-Detection — wieviele Fehlversuche akzeptieren, bevor das
# Video als "vergiftet" geskippt wird. Passend gewählt: ein flüchtiger
# rclone-Hiccup (1 Fehlversuch) reicht nicht; drei aufeinander folgende
# zeigen ein systemisches Problem (Codec, falsches Poster-At, etc.).
POISON_FAILURE_THRESHOLD = 3


def is_poisoned(
    sidecar: SidecarSettings,
    *,
    current_fingerprint: tuple[int | None, str | None],
) -> bool:
    """True wenn das Video als „Poison" geskippt werden sollte.

    Bedingungen (alle müssen erfüllt sein):
      1. ``publish_failure_count >= POISON_FAILURE_THRESHOLD``
      2. Source-Fingerprint hat sich seit dem letzten Fehler nicht geändert
         (sonst Reset — neue Datei verdient neuen Versuch).

    Beim Aufruf mit Light-Peek (current_head=None) wird nur ``size``
    verglichen — passt zum bestehenden ``channel_needs_publish``-Pattern.

    `--force` umgeht diesen Check (Caller-Verantwortung).
    """
    fc = sidecar.publish_failure_count or 0
    if fc < POISON_FAILURE_THRESHOLD:
        return False

    # Welcher Fingerprint war beim letzten Fehler aktuell? Wir nehmen den
    # bekanntesten verfügbaren (web/local/archive — alle drei sollten beim
    # letzten Fehlerzeitpunkt synchron gewesen sein, weil ein Fail nicht
    # selektiv ist). Fallback: Legacy-globaler Block.
    stored_size = (
        sidecar.web_source_size_bytes
        or sidecar.local_source_size_bytes
        or sidecar.archive_source_size_bytes
        or sidecar.source_size_bytes
    )
    stored_head = (
        sidecar.web_source_head_sha1
        or sidecar.local_source_head_sha1
        or sidecar.archive_source_head_sha1
        or sidecar.source_head_sha1
    )

    current_size, current_head = current_fingerprint
    # Source unverändert? Wenn Fingerprint sich geändert hat → kein Poison
    # (neue Datei verdient frischen Versuch).
    if current_size is not None and stored_size is not None and current_size != stored_size:
        return False
    if (
        current_head is not None
        and stored_head is not None
        and current_head != stored_head
    ):
        return False

    return True


def read_sidecar(video_path: Path) -> SidecarSettings:
    """Liest die Sidecar-Datei. Gibt leeres SidecarSettings zurück wenn nicht vorhanden."""
    path = sidecar_path_for(video_path)
    if not path.exists():
        return SidecarSettings()

    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return SidecarSettings()

    poster = data.get("poster") or {}
    if not isinstance(poster, dict):
        poster = {}

    web = data.get("web") or {}
    if not isinstance(web, dict):
        web = {}

    local = data.get("local") or {}
    if not isinstance(local, dict):
        local = {}

    archive = data.get("archive") or {}
    if not isinstance(archive, dict):
        archive = {}

    source = data.get("source") or {}
    if not isinstance(source, dict):
        source = {}

    metadata = data.get("metadata") or {}
    if not isinstance(metadata, dict):
        metadata = {}

    publish = data.get("publish") or {}
    if not isinstance(publish, dict):
        publish = {}

    meta = data.get("meta") or {}
    if not isinstance(meta, dict):
        meta = {}

    def _as_int(v):
        return int(v) if v is not None else None

    def _as_float(v):
        return float(v) if v is not None else None

    def _as_str(v):
        return str(v) if v is not None else None

    def _as_bool(v):
        return bool(v) if v is not None else None

    return SidecarSettings(
        frame_number=_as_int(poster.get("frame_number")),
        timestamp_seconds=_as_float(poster.get("timestamp_seconds")),
        crop_position=_as_str(poster.get("crop_position")),
        poster_selected_by=_as_str(poster.get("selected_by")),
        poster_ai_reasoning=_as_str(poster.get("ai_reasoning")),
        publish_failure_count=_as_int(publish.get("failure_count")),
        publish_last_failure_at=_as_str(publish.get("last_failure_at")),
        publish_last_failure_reason=_as_str(publish.get("last_failure_reason")),
        web_id=_as_str(web.get("web_id")),
        max_luminance=_as_int(web.get("max_luminance")),
        web_published_at=_as_str(web.get("published_at")),
        web_enabled=_as_bool(web.get("enabled")),
        web_source_size_bytes=_as_int(web.get("source_size_bytes")),
        web_source_head_sha1=_as_str(web.get("source_head_sha1")),
        local_published_at=_as_str(local.get("published_at")),
        local_source_size_bytes=_as_int(local.get("source_size_bytes")),
        local_source_head_sha1=_as_str(local.get("source_head_sha1")),
        archive_published_at=_as_str(archive.get("published_at")),
        archive_source_size_bytes=_as_int(archive.get("source_size_bytes")),
        archive_source_head_sha1=_as_str(archive.get("source_head_sha1")),
        source_size_bytes=_as_int(source.get("size_bytes")),
        source_head_sha1=_as_str(source.get("head_sha1")),
        category=_as_str(metadata.get("category")),
        schema_version=_as_int(meta.get("schema_version")),
    )


def write_sidecar(video_path: Path, settings: SidecarSettings) -> Path:
    """Schreibt die Sidecar-Datei. Nur gesetzte Felder werden geschrieben.

    Returns:
        Pfad zur geschriebenen Datei.
    """
    path = sidecar_path_for(video_path)
    lines: list[str] = []

    def _append_section(name: str, body: list[str]) -> None:
        if not body:
            return
        if lines:
            lines.append("")
        lines.append(f"[{name}]")
        lines.extend(body)

    # [poster]
    poster_lines: list[str] = []
    if settings.frame_number is not None:
        poster_lines.append(f"frame_number = {settings.frame_number}")
    if settings.timestamp_seconds is not None:
        poster_lines.append(f"timestamp_seconds = {settings.timestamp_seconds}")
    if settings.crop_position is not None:
        poster_lines.append(f'crop_position = "{settings.crop_position}"')
    if settings.poster_selected_by is not None:
        poster_lines.append(f'selected_by = "{settings.poster_selected_by}"')
    if settings.poster_ai_reasoning is not None:
        # KI-Begründung kann lang sein — als Multi-Line-Basic-String wenn nötig.
        reasoning = settings.poster_ai_reasoning
        if "\n" in reasoning:
            escaped = reasoning.replace("\\", "\\\\").replace('"""', '""\\"')
            poster_lines.append(f'ai_reasoning = """\n{escaped}"""')
        else:
            escaped = reasoning.replace("\\", "\\\\").replace('"', '\\"')
            poster_lines.append(f'ai_reasoning = "{escaped}"')
    _append_section("poster", poster_lines)

    # [web]
    web_lines: list[str] = []
    if settings.web_id is not None:
        web_lines.append(f'web_id = "{settings.web_id}"')
    if settings.max_luminance is not None:
        web_lines.append(f"max_luminance = {settings.max_luminance}")
    if settings.web_published_at is not None:
        web_lines.append(f'published_at = "{settings.web_published_at}"')
    if settings.web_enabled is not None:
        web_lines.append(f"enabled = {'true' if settings.web_enabled else 'false'}")
    if settings.web_source_size_bytes is not None:
        web_lines.append(f"source_size_bytes = {settings.web_source_size_bytes}")
    if settings.web_source_head_sha1 is not None:
        web_lines.append(f'source_head_sha1 = "{settings.web_source_head_sha1}"')
    _append_section("web", web_lines)

    # [local] (Infuse / LAN-Medienserver)
    local_lines: list[str] = []
    if settings.local_published_at is not None:
        local_lines.append(f'published_at = "{settings.local_published_at}"')
    if settings.local_source_size_bytes is not None:
        local_lines.append(f"source_size_bytes = {settings.local_source_size_bytes}")
    if settings.local_source_head_sha1 is not None:
        local_lines.append(f'source_head_sha1 = "{settings.local_source_head_sha1}"')
    _append_section("local", local_lines)

    # [archive] (TAR-Langzeit-Archiv)
    archive_lines: list[str] = []
    if settings.archive_published_at is not None:
        archive_lines.append(f'published_at = "{settings.archive_published_at}"')
    if settings.archive_source_size_bytes is not None:
        archive_lines.append(f"source_size_bytes = {settings.archive_source_size_bytes}")
    if settings.archive_source_head_sha1 is not None:
        archive_lines.append(f'source_head_sha1 = "{settings.archive_source_head_sha1}"')
    _append_section("archive", archive_lines)

    # Legacy [source] — wird v0.8.0+ nicht mehr geschrieben; Lesen aber weiterhin
    # unterstützt für Migration von Sidecars aus ≤ v0.7.0. Der Fallback greift in
    # ``fingerprint_for_channel()``. Kein Write-Path mehr.

    # [metadata] — effektive Metadaten (für selbsttragendes Archiv)
    metadata_lines: list[str] = []
    if settings.category is not None:
        escaped = settings.category.replace('"', '\\"')
        metadata_lines.append(f'category = "{escaped}"')
    _append_section("metadata", metadata_lines)

    # [publish] — Poison-Detection (v0.11.0+). Nur geschrieben wenn ein
    # vorheriger Lauf gescheitert ist UND nicht durch Erfolg überschrieben
    # wurde. Source-Fingerprint-Änderung resettet die Werte (siehe Publisher).
    publish_lines: list[str] = []
    if settings.publish_failure_count is not None:
        publish_lines.append(f"failure_count = {settings.publish_failure_count}")
    if settings.publish_last_failure_at is not None:
        publish_lines.append(f'last_failure_at = "{settings.publish_last_failure_at}"')
    if settings.publish_last_failure_reason is not None:
        escaped = settings.publish_last_failure_reason.replace('"', '\\"')
        publish_lines.append(f'last_failure_reason = "{escaped}"')
    _append_section("publish", publish_lines)

    # [meta] — Format-Version (v0.12.0+). Wird IMMER geschrieben, damit
    # zukünftige FFM-Versionen wissen, mit welchem Schema dieser Sidecar
    # erzeugt wurde. Vor v0.12.0 fehlt das Feld → optional beim Read.
    _append_section("meta", [f"schema_version = {SETTINGS_SCHEMA_VERSION}"])

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path
