"""Verzeichnis-Überwachung: wiederholte publish_directory-Aufrufe mit Signal-Handling.

Ein Tick im Watch-Modus ist verhaltensidentisch zu einem einzelnen
``publish-dir``-Lauf über alle konfigurierten Verzeichnisse. Das Timing
der Wiederholung gehört ins Watch-Modul; wer ``once=True`` setzt, erhält
exakt einen Tick und Exit — ideal für launchd/cron-Integration.
"""

from __future__ import annotations

import signal
import time
from collections.abc import Callable
from pathlib import Path

from familienfilm_manager.api.models import (
    DirectoryPublishResult,
    FamilienfilmEvent,
    FamilienfilmStage,
    RuntimeOptions,
    WatchRequest,
    WatchResult,
    WatchTickResult,
)
from familienfilm_manager.core.directory_publisher import run_publish_directory
from familienfilm_manager.services import config_manager


class _ShutdownRequested(Exception):
    """Interne Ausnahme zum sauberen Beenden der Schleife zwischen Ticks."""


def _install_signal_handlers() -> Callable[[], bool]:
    """Installiert SIGTERM/SIGINT-Handler, die ein Stop-Flag setzen.

    Returns:
        Callable ``should_stop()`` — wird beim nächsten Schleifen-Check geprüft.
        Gibt ``True`` zurück sobald ein Signal empfangen wurde.
    """
    stopped = {"value": False}

    def _handler(signum, frame):  # noqa: ARG001
        stopped["value"] = True

    try:
        signal.signal(signal.SIGTERM, _handler)
        signal.signal(signal.SIGINT, _handler)
    except ValueError:
        # Nicht im Main-Thread — Signale können nicht installiert werden.
        # Watch kann trotzdem laufen, Stop nur via SIGKILL/KeyboardInterrupt in der Loop.
        pass

    return lambda: stopped["value"]


def _interruptible_sleep(seconds: int, should_stop: Callable[[], bool]) -> None:
    """Sleep mit regelmässiger Stop-Flag-Prüfung (max. 1 Sek. Granularität)."""
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        if should_stop():
            return
        remaining = end - time.monotonic()
        time.sleep(min(1.0, max(0.0, remaining)))


def _cleanup_stale_pending_notifications() -> None:
    """Setzt liegengebliebene pending-Einträge in der Benachrichtigungsdatei auf „abgebrochen".

    Vorgesehen für den Watch-Start: wenn ein vorheriger Lauf mitten in einer
    Publikation abgebrochen wurde (Crash, kill -9), bleibt sonst ein pending-Block
    dauerhaft stehen.
    """
    notification_file = config_manager.get("notification.file")
    if not notification_file:
        return
    from familienfilm_manager.core.notifier import mark_all_pending_as_aborted

    mark_all_pending_as_aborted(notification_file)


def _run_tick(
    request: WatchRequest,
    runtime: RuntimeOptions | None,
    on_event: Callable[[FamilienfilmEvent], None] | None,
) -> WatchTickResult:
    """Ein Scan+Publish-Durchlauf über alle konfigurierten Verzeichnisse."""
    tick_result = WatchTickResult()

    from familienfilm_manager.core.source_ref import SourceRef

    for directory in request.directories:
        directory_ref = SourceRef(str(directory))
        # Lokale Existenz nur bei lokalen Pfaden prüfen — rclone-URIs kann man
        # nur per rclone selbst verifizieren, was run_publish_directory ohnehin tut.
        if not directory_ref.is_rclone:
            local_dir = directory_ref.as_local_path()
            if not local_dir.exists():
                tick_result.error_messages.append(f"Verzeichnis nicht gefunden: {directory}")
                continue
            if not local_dir.is_dir():
                tick_result.error_messages.append(f"Kein Verzeichnis: {directory}")
                continue

        try:
            dir_result = run_publish_directory(
                directory=directory,
                runtime=runtime,
                on_event=on_event,
                skip_infuse=request.skip_infuse,
                skip_web=request.skip_web,
                web_enabled=request.web_enabled,
                skip_archive=request.skip_archive,
                force=request.force,
                work_dir=request.work_dir,
                stability_window_seconds=request.stability_window_seconds,
                category=request.category,
                recursive=request.recursive,
                delete_source_after_publish=request.delete_source_after_publish,
                web_cleanup_dry_run=request.web_cleanup_dry_run,
            )
        except Exception as e:
            # Nie den gesamten Watch-Lauf abbrechen — nur dieses Verzeichnis.
            msg = f"{directory}: {e}"
            tick_result.error_messages.append(msg)
            tick_result.directory_results.append(
                DirectoryPublishResult(
                    success=False, directory=directory, error_message=str(e),
                )
            )
            # Sichtbar machen — sonst geht der Grund (z.B. PermissionError auf
            # notification.file, fehlendes Verzeichnis, rclone-Auth-Fehler) im
            # Tick-Summary („0 von allem") komplett unter.
            if on_event:
                on_event(FamilienfilmEvent(
                    stage_id=FamilienfilmStage.DEPLOY_FAILED,
                    message=f"Verzeichnis-Lauf fehlgeschlagen: {msg}",
                ))
            continue

        # Verzeichnis-Level-Fehler (z.B. fehlende Targets, work_dir-Missing
        # bei rclone-Quelle): success=False mit error_message, ohne Exception.
        if not dir_result.success and dir_result.error_message and on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOY_FAILED,
                message=f"{directory}: {dir_result.error_message}",
            ))

        tick_result.directory_results.append(dir_result)

    return tick_result


def run_watch(
    request: WatchRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[FamilienfilmEvent], None] | None = None,
) -> WatchResult:
    """Führt den Watch-Lauf aus (ein oder mehrere Ticks).

    Der erste Tick startet sofort — Daemon- und ``--once``-Modus verhalten sich
    in einem Tick identisch. Unterschied: Daemon schläft nach dem Tick
    ``request.interval_seconds`` und wiederholt, ``--once`` bricht ab.
    """
    if not request.directories:
        raise ValueError(
            "Keine Verzeichnisse zum Überwachen angegeben "
            "(WatchRequest.directories oder --directory/Config)."
        )

    should_stop = _install_signal_handlers()
    _cleanup_stale_pending_notifications()

    result = WatchResult()

    if on_event:
        dirs_str = ", ".join(str(d) for d in request.directories)
        mode = "einmalig (--once)" if request.once else f"alle {request.interval_seconds}s"
        on_event(FamilienfilmEvent(
            stage_id=FamilienfilmStage.WATCH_STARTED,
            message=f"Überwachung gestartet ({mode}): {dirs_str}",
        ))

    try:
        while True:
            if on_event:
                on_event(FamilienfilmEvent(
                    stage_id=FamilienfilmStage.WATCH_TICK_STARTED,
                    message=f"Tick {result.tick_count + 1}: Scan startet",
                ))

            tick_result = _run_tick(request, runtime, on_event)
            result.ticks.append(tick_result)
            result.tick_count += 1

            if on_event:
                summary = (
                    f"Tick {result.tick_count} abgeschlossen: "
                    f"{tick_result.published_count} publiziert, "
                    f"{tick_result.skipped_count} übersprungen, "
                    f"{tick_result.unstable_count} wächst noch, "
                    f"{tick_result.failed_count} fehlgeschlagen"
                )
                if tick_result.poisoned_count:
                    summary += f", {tick_result.poisoned_count} vergiftet"
                on_event(FamilienfilmEvent(
                    stage_id=FamilienfilmStage.WATCH_TICK_COMPLETED,
                    message=summary,
                ))

            if request.once or should_stop():
                break

            _interruptible_sleep(request.interval_seconds, should_stop)
            if should_stop():
                break
    finally:
        result.stopped_by_signal = should_stop()
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.WATCH_STOPPED,
                message=(
                    "Überwachung beendet (Signal empfangen)"
                    if result.stopped_by_signal
                    else "Überwachung beendet"
                ),
            ))

    return result
