"""Archivierung: Originaldatei + Sidecars direkt via rclone ins Archiv-Ziel kopieren.

Seit v0.9.0 erstellt der Archiver **kein TAR mehr**. Die Videodatei wird 1:1 unter
einem ASCII-sicheren Namen (``{recording_date}-{slug}.{ext}``) ins Archiv kopiert,
daneben liegen die ``.settings.toml`` und eine neue ``.archive.toml`` mit
konservierten Originalmetadaten (Dateiname mit Umlauten, Export-mtime, Titel,
Beschreibung). Vorteil: direkter Zugriff auf archivierte Videos im NAS —
kein Entpacken mehr nötig.

Andere Sidecar-Typen (z.B. ``.fcpxml``, ``.lfpackage``) werden in dieser
Version **nicht mehr ins Archiv übernommen** — sie gehören zum Videoschnitt-
projekt (der User-seitigen Disaster-Recovery-Kopie), nicht zum Archiv der
publizierten Familienfilme.
"""

from __future__ import annotations

import re
import subprocess
import unicodedata
from dataclasses import dataclass
from pathlib import Path

from familienfilm_manager.api.models import (
    ArchiveResult,
    FamilienfilmEvent,
    FamilienfilmStage,
)
from familienfilm_manager.core._rclone import (
    run_rclone_with_retry,
    verify_rclone_target_files_with_size,
)

# Deutsche Transliteration für ASCII-sichere Dateinamen
_GERMAN_TRANSLITERATION: dict[str, str] = {
    "ä": "ae", "ö": "oe", "ü": "ue", "ß": "ss",
    "Ä": "Ae", "Ö": "Oe", "Ü": "Ue",
}


def _to_ascii_slug(text: str) -> str:
    """Konvertiert einen Text in einen ASCII-sicheren Slug (Bindestriche statt Leerzeichen).

    Beispiel: "Leah gähnt im Bett" → "Leah-gaehnt-im-Bett"

    macOS speichert Dateinamen in NFD (z.B. "ä" = "a" + Combining Diaeresis).
    Daher zuerst nach NFC normalisieren, sonst greift die Transliteration nicht
    und Umlaute landen als nacktes "a"/"o"/"u" im Slug ("Madchen" statt "Maedchen").
    """
    # 1. NFC-Normalisierung (kombiniert Diakritika zu einem Code-Point)
    text = unicodedata.normalize("NFC", text)

    # 2. Deutsche Sonderzeichen transliterieren
    for char, replacement in _GERMAN_TRANSLITERATION.items():
        text = text.replace(char, replacement)

    # 3. Restliche Diakritika (z.B. é, à) auf ASCII reduzieren
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")

    # 4. Nicht-alphanumerische Zeichen durch Bindestriche ersetzen
    text = re.sub(r"[^a-zA-Z0-9]+", "-", text)

    # 5. Führende/abschliessende Bindestriche entfernen
    return text.strip("-")


@dataclass(frozen=True)
class ArchiveNames:
    """Berechnete Dateinamen pro Archiv-Mediaset.

    Konsistente, deterministische Slug-Bildung — wird von ``archive_video()``
    UND vom Publisher (für den Sidecar-Re-Upload nach ``write_sidecar()``)
    verwendet, damit beide dieselbe Logik teilen.
    """

    stem: str           # ASCII-Slug-Stem (ohne Extension), z.B. "2026-04-24-Bergmolch"
    video: str          # Video-Dateiname (mit Extension)
    settings_toml: str  # "{stem}.settings.toml"
    archive_toml: str   # "{stem}.archive.toml"


def compute_archive_names(
    source_path: Path,
    recording_date: str | None = None,
    title: str | None = None,
) -> ArchiveNames:
    """Leitet die ASCII-sicheren Archiv-Dateinamen aus Source + Datum + Titel ab.

    Public Helper, damit der Publisher nach dem finalen ``write_sidecar()``
    den korrekten Sidecar-Zielnamen kennt, ohne die Slug-Logik dupliziert.
    """
    ext = source_path.suffix  # inkl. Punkt
    if title and recording_date:
        slug = _to_ascii_slug(title)
    elif recording_date:
        slug = _to_ascii_slug(source_path.stem)
    else:
        slug = _to_ascii_slug(source_path.stem)

    if not slug:
        slug = "archive"

    stem = f"{recording_date}-{slug}" if recording_date else slug
    return ArchiveNames(
        stem=stem,
        video=f"{stem}{ext}",
        settings_toml=f"{stem}.settings.toml",
        archive_toml=f"{stem}.archive.toml",
    )


def upload_settings_sidecar_to_archive(
    local_sidecar: Path,
    archive_target: str,
    *,
    source_path: Path,
    recording_date: str | None,
    title: str | None,
    rclone_path: str = "rclone",
    on_event=None,
) -> bool:
    """Lädt das (frisch geschriebene) ``.settings.toml`` ins Archiv-Ziel.

    Wird vom Publisher NACH dem finalen ``write_sidecar()`` aufgerufen,
    damit das Sidecar im Archiv die aktuellen Channel-Timestamps hat
    (insbesondere ``[archive].published_at``, der erst nach erfolgreichem
    Archive bekannt ist). Idempotent — überschreibt eine eventuell schon
    vorhandene Sidecar im Ziel.

    Returns:
        True bei Erfolg, False wenn die lokale Sidecar nicht existiert
        (kein Fehler — der Publisher schreibt das Sidecar nur, wenn was
        zu tun ist).
    """
    if not local_sidecar.exists():
        return False

    names = compute_archive_names(source_path, recording_date, title)
    dest_uri = f"{archive_target.rstrip('/')}/{names.settings_toml}"
    try:
        _rclone_copyto(
            local_sidecar, dest_uri, rclone_path,
            on_event=on_event, retry_label="Sidecar-Upload (final)",
        )
    except Exception as e:
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOY_FAILED,
                message=(
                    f"Sidecar-Re-Upload ins Archiv fehlgeschlagen: {e}. "
                    f"Archive ist publiziert, aber settings.toml fehlt im Ziel."
                ),
            ))
        return False

    if on_event:
        on_event(FamilienfilmEvent(
            stage_id=FamilienfilmStage.DEPLOYMENT_VERIFIED,
            message=(
                f"settings.toml im Archiv aktualisiert: {names.settings_toml}"
            ),
        ))
    return True


def _rclone_copyto(
    src: Path,
    dest_uri: str,
    rclone_path: str,
    on_event=None,
    *,
    retry_label: str = "Upload",
) -> None:
    """Kopiert eine einzelne Datei ins rclone-Ziel (mit Retry-Backoff).

    Nutzt ``rclone copyto`` — ``src`` wird nicht gelöscht. Für die Archivierung
    ist das wichtig: die Originaldatei bleibt bis zum expliziten
    ``--delete-source``-Schritt unangetastet.
    """

    def _on_retry(attempt: int, max_attempts: int, exc: Exception) -> None:
        if on_event:
            stderr = getattr(exc, "stderr", "") or str(exc)
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOY_RETRY,
                message=(
                    f"{retry_label} fehlgeschlagen (Versuch {attempt}/{max_attempts}), "
                    f"retry: {stderr.strip().splitlines()[-1] if stderr.strip() else exc}"
                ),
            ))

    run_rclone_with_retry(
        [rclone_path, "copyto", str(src), dest_uri],
        on_retry=_on_retry,
    )


def archive_video(
    source_path: Path,
    archive_target: str,
    rclone_path: str = "rclone",
    recording_date: str | None = None,
    title: str | None = None,
    description: str | None = None,
    work_dir: Path | None = None,
    on_event=None,
) -> ArchiveResult:
    """Archiviert eine Videodatei 1:1 im Archiv-Ziel (kein TAR seit v0.9.0).

    Das Archiv enthält:
    - ``{recording_date}-{slug}.{ext}`` — die Originalvideo-Datei (direkter
      Zugriff, kein Entpacken nötig).
    - ``{recording_date}-{slug}.settings.toml`` — das Publish-Sidecar,
      wenn vorhanden (seit v0.6.0 neben dem Archiv-Objekt).
    - ``{recording_date}-{slug}.archive.toml`` — **NEU in v0.9.0**:
      konservierte Originalmetadaten (Originaldateiname mit Umlauten,
      Export-/Schnittdatum via ``original_mtime``, Titel, Beschreibung).
      Bleibt erhalten, auch wenn die FS-``mtime`` bei späteren Moves
      zwischen Archiv-Locations verloren geht.

    Args:
        source_path: Pfad zur Originaldatei.
        archive_target: rclone-Ziel (z.B. nas:/archive/familienfilme/).
        rclone_path: Pfad zur rclone-Binärdatei.
        recording_date: ISO-Datum für den Archiv-Dateinamen.
        title: Titel für den Archiv-Dateinamen und die .archive.toml.
        description: Optionale Beschreibung für die .archive.toml.
        work_dir: Arbeitsverzeichnis für temporär erzeugte Dateien
            (``.archive.toml``). Standard (None): Quellverzeichnis.
        on_event: Optionaler Event-Callback.

    Returns:
        ArchiveResult mit Erfolg/Fehler. Bei Erfolg enthält
        ``archive_path`` den rclone-URI der Videodatei im Ziel.
    """
    from familienfilm_manager.core.archive_metadata import (
        write_archive_metadata,
    )

    if not archive_target:
        return ArchiveResult(
            success=False,
            error_message="Kein Archiv-Ziel konfiguriert (targets.archive).",
        )

    if not source_path.exists():
        return ArchiveResult(
            success=False,
            error_message=f"Quelldatei nicht gefunden: {source_path}",
        )

    names = compute_archive_names(source_path, recording_date, title)
    archive_video_name = names.video
    archive_settings_name = names.settings_toml
    archive_metadata_name = names.archive_toml

    # Arbeitsverzeichnis für die .archive.toml (vorher temp. erzeugen).
    if work_dir is not None:
        work_dir.mkdir(parents=True, exist_ok=True)
        metadata_local = work_dir / archive_metadata_name
    else:
        metadata_local = source_path.parent / archive_metadata_name

    try:
        # 1. Originalvideo ins Ziel kopieren.
        video_dest_uri = f"{archive_target.rstrip('/')}/{archive_video_name}"
        _rclone_copyto(
            source_path, video_dest_uri, rclone_path,
            on_event=on_event, retry_label="Archiv-Upload",
        )

        # 2. .archive.toml mit konservierten Metadaten erzeugen und hochladen.
        # Hinweis: das ``.settings.toml`` wird NICHT mehr hier hochgeladen.
        # Bis v0.10.0 versuchte archive_video, eine eventuell schon im
        # Source-Verzeichnis liegende Sidecar mitzunehmen — die war aber meist
        # entweder nicht vorhanden oder veraltet (ohne ``[archive].published_at``
        # des aktuellen Laufs). Stattdessen ruft der Publisher nach dem finalen
        # ``write_sidecar()`` ``upload_settings_sidecar_to_archive()`` auf und
        # garantiert damit immer die aktuellste Sidecar im Archiv.
        write_archive_metadata(
            source_video=source_path,
            target_toml=metadata_local,
            recording_date=recording_date,
            title=title,
            description=description,
        )
        metadata_dest_uri = f"{archive_target.rstrip('/')}/{archive_metadata_name}"
        _rclone_copyto(
            metadata_local, metadata_dest_uri, rclone_path,
            on_event=on_event, retry_label="Archiv-Metadaten-Upload",
        )

        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.ARCHIVED,
                message=(
                    f"Archiviert: {archive_video_name} + archive.toml "
                    f"→ {archive_target} (settings.toml folgt nach Sidecar-Finalisierung)"
                ),
            ))

        # 3. Post-Deploy Health-Check: Video + .archive.toml müssen im Ziel sein,
        #    Video byte-gleich (Voraussetzung für ein sicheres --delete-source).
        #    Die settings.toml wird vom Publisher separat überprüft.
        source_size = source_path.stat().st_size
        expected_with_size: dict[str, int | None] = {
            archive_video_name: source_size,
            archive_metadata_name: None,  # Size nicht prüfen (kleiner TOML-Output)
        }

        ok, missing, size_mismatch = verify_rclone_target_files_with_size(
            archive_target, expected_with_size, rclone_path=rclone_path,
        )
        if not ok:
            reasons: list[str] = []
            if missing:
                reasons.append(f"fehlen: {', '.join(missing)}")
            if size_mismatch:
                reasons.append(
                    "Grösse weicht ab: " + ", ".join(
                        f"{name} (erwartet {exp}, gefunden {got})"
                        for name, exp, got in size_mismatch
                    ),
                )
            msg = (
                f"Archivierung ist laut rclone erfolgreich, aber der Health-Check "
                f"im Ziel {archive_target} meldet: {'; '.join(reasons)}."
            )
            if on_event:
                on_event(FamilienfilmEvent(
                    stage_id=FamilienfilmStage.DEPLOY_FAILED,
                    message=msg,
                ))
            return ArchiveResult(success=False, error_message=msg)

        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOYMENT_VERIFIED,
                message=(
                    f"Archivierung verifiziert: {archive_video_name} "
                    f"({source_size} Bytes) im Ziel vorhanden"
                ),
            ))

        return ArchiveResult(
            success=True,
            archive_path=Path(video_dest_uri),
        )

    except subprocess.CalledProcessError as e:
        msg = f"Archivierung fehlgeschlagen: {e.stderr or e}"
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOY_FAILED,
                message=msg,
            ))
        return ArchiveResult(success=False, error_message=msg)
    except Exception as e:
        msg = f"Archivierung fehlgeschlagen: {e}"
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DEPLOY_FAILED,
                message=msg,
            ))
        return ArchiveResult(success=False, error_message=msg)
    finally:
        # Lokale .archive.toml aufräumen (wurde ins Ziel kopiert).
        if metadata_local.exists():
            try:
                metadata_local.unlink()
            except OSError:
                pass
