"""Storage-Resolver für die Notification-HTML (v0.12.0+).

Der Pfad in ``notification.file`` kann ab v0.12.0 zwei Formen haben:

1. **Lokaler Pfad** (heute, unverändert):
   ``/Users/.../Familienfilme.html``
   Wird direkt gelesen/geschrieben — wie immer.

2. **rclone-URI** (neu):
   ``mega.nz:Familienfilme/Familienfilme.html`` o.ä.
   FFM hält einen lokalen Cache unter ``~/.cache/familienfilm-manager/``
   und synchronisiert nach ausgewählten Schreib-Operationen via
   ``rclone copyto`` zum Remote. Damit ist die HTML auf jedem
   rclone-fähigen Cloud-Anbieter zugänglich (auch vom Telefon, über
   die jeweilige Cloud-App).

Sync-Strategie ist **Hybrid** — die Caller-Funktionen in ``notifier.py``
entscheiden per ``sync=True/False``-Parameter, ob nach einem Write
sofort hochgeladen wird. Real-time fürs Telefon ist nur bei
"angenommen"/"published"/"failed"/"cleaned-up" wichtig; interne
Hygiene-Updates (z.B. mark_all_pending_as_aborted beim Watch-Start)
gehen beim nächsten echten Sync mit raus.

Konflikt-Strategie: **FFM gewinnt immer.** Initial-Pull nur wenn der
lokale Cache fehlt. Wer den Remote-HTML manuell editiert während FFM
läuft, wird beim nächsten Sync überschrieben.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path

from familienfilm_manager.core._rclone import (
    rclone_cat,
    rclone_copyto,
    rclone_delete_matching,
)
from familienfilm_manager.core.source_ref import _looks_like_rclone_uri

# XDG-konformer Cache-Ort. macOS hat keinen offiziellen XDG-Standard,
# aber ``~/.cache`` ist als Konvention akzeptiert.
_CACHE_DIR = Path.home() / ".cache" / "familienfilm-manager"


@dataclass(frozen=True)
class NotificationStorage:
    """Auflösung eines ``notification.file``-Werts in lokal+remote.

    Attributes:
        cache: Lokaler Pfad, auf dem alle Reads und Writes laufen.
            Bei lokaler Konfiguration ist das der Pfad direkt; bei
            rclone-URI ein Cache-Pfad in ``~/.cache/familienfilm-manager/``.
        remote: Optional rclone-URI. Wenn gesetzt, wird nach manchen
            Writes via ``rclone copyto`` synchronisiert.
    """

    cache: Path
    remote: str | None

    @property
    def is_remote(self) -> bool:
        return self.remote is not None


def resolve_storage(target: str) -> NotificationStorage:
    """Auflösung des ``notification.file``-Config-Werts.

    Bei rclone-URI: Cache-Pfad ableiten + bei Bedarf initial pull.
    Bei lokalem Pfad: direkt verwenden, kein Cache.

    Initial-Pull-Verhalten: nur wenn der lokale Cache fehlt. Wenn der
    Pull selbst scheitert (Remote noch leer, Network down), bleibt
    der Cache nicht angelegt — der erste Write erstellt ihn dann
    von Grund auf.
    """
    if not _looks_like_rclone_uri(target):
        return NotificationStorage(cache=Path(target), remote=None)

    # rclone-URI — Cache-Pfad aus dem Basename der HTML-Datei ableiten.
    basename = target.rsplit("/", 1)[-1] if "/" in target else target.split(":", 1)[-1]
    if not basename:
        basename = "Familienfilme.md"
    cache_path = _CACHE_DIR / basename

    storage = NotificationStorage(cache=cache_path, remote=target)

    # Initial-Pull: nur wenn Cache fehlt. Wir wollen NICHT bei jedem
    # Aufruf re-pullen, denn FFM ist die einzige Schreibinstanz.
    if not cache_path.exists():
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            content = rclone_cat(target)
            if content is not None:
                cache_path.write_bytes(content)
        except Exception:
            # Remote nicht erreichbar oder leer — der erste Write erstellt
            # die HTML von Grund auf. Kein Fehler.
            pass

    return storage


def fetch_remote_content(storage: NotificationStorage) -> str | None:
    """Lädt den aktuellen Remote-Inhalt (best-effort), ohne den Cache zu überschreiben.

    Verwendet vom Multi-Machine-Merge-Pfad in ``notifier._write``: vor
    jedem Push wird der Remote frisch gepullt und mit unserem modifizierten
    Lokal-Stand vereinigt, damit parallele Schreibe von einem zweiten Rechner
    nicht überschrieben werden.

    Returns:
        Den Remote-Inhalt als String, oder None wenn:
        - kein Remote konfiguriert (``storage.remote is None``)
        - Pull schlägt fehl (Network down, File noch nicht da, Auth-Problem)
        - Remote ist leer

    Bei None fällt der Caller still auf „local-only push" zurück. Worst Case:
    ein paralleles Schreib-Race verliert eine einzelne Notification-Zeile —
    keine Daten werden korrumpiert.
    """
    if storage.remote is None:
        return None
    try:
        content = rclone_cat(storage.remote)
        if content is None or not content.strip():
            return None
        if isinstance(content, bytes):
            return content.decode("utf-8", errors="replace")
        return content
    except Exception:
        return None


def _split_remote_uri(uri: str) -> tuple[str, str]:
    """Zerlegt einen rclone-URI in Eltern-Verzeichnis + Basename.

    ``mega.nz:Videoschnitt/Familienfilme.html`` → ``("mega.nz:Videoschnitt", "Familienfilme.html")``
    ``mega.nz:Familienfilme.html``              → ``("mega.nz:", "Familienfilme.html")``
    """
    colon = uri.index(":")
    remote_prefix = uri[: colon + 1]  # "mega.nz:"
    path = uri[colon + 1 :]
    if "/" in path:
        parent, basename = path.rsplit("/", 1)
        return f"{remote_prefix}{parent}", basename
    return remote_prefix, path


def push_to_remote(storage: NotificationStorage) -> bool:
    """Lädt den lokalen Cache zum rclone-Remote hoch.

    No-op wenn ``storage.remote`` None ist. Tolerant gegen Sync-Fehler:
    Cache bleibt aktuell, beim nächsten erfolgreichen Sync wird
    aufgeholt. Eine kurze Warnung landet auf stderr.

    **Pre-Upload-Cleanup gegen mega.nz-Duplikate** (v1.0.1+):
    Vor dem ``copyto`` läuft ein ``rclone delete --include <basename>``
    auf dem Eltern-Verzeichnis. Hintergrund: mega.nz erlaubt mehrere
    Knoten mit demselben Filenamen im selben Ordner und ``rclone copyto``
    legt bei jedem Upload einen neuen Knoten an statt zu ersetzen.
    Ohne diesen Sweep wachsen Duplikate über die Zeit (1× pro Sync).
    Auf anderen Backends (hostpoint/SFTP, S3, Drive…) ist der Delete
    entweder no-op oder löscht die einzige existierende Datei — beides
    harmlos. Fehler im Delete-Schritt werden ignoriert (best-effort).

    Returns:
        True bei Erfolg (oder no-op), False bei Sync-Fehler.
    """
    if storage.remote is None:
        return True
    if not storage.cache.exists():
        # Sollte nicht eintreten — wer pushed will, hat vorher geschrieben.
        return False

    # Best-effort: Duplikate bereinigen, bevor wir die neue Version hochladen.
    # Schluckt alle Fehler — das ist Hygiene, nicht der eigentliche Sync.
    try:
        parent_uri, basename = _split_remote_uri(storage.remote)
        rclone_delete_matching(parent_uri, basename)
    except Exception:
        pass

    try:
        rclone_copyto(str(storage.cache), storage.remote)
        return True
    except Exception as e:
        sys.stderr.write(
            f"Notification-Sync zum Remote ({storage.remote}) fehlgeschlagen: "
            f"{e}. Cache lokal aktuell, nächster erfolgreicher Sync räumt auf.\n"
        )
        return False
