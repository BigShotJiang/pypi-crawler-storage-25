"""rclone-Schicht: zentrale Subprocess-Wrapper, Retry-Logik und Encoding-Robustheit.

Dieses Modul ist die einzige Stelle im Projekt, die ``subprocess.run`` mit
``rclone`` aufruft. Alle anderen Module (``source_staging``, ``archiver``,
``notifier_storage``, ``source_delete`` etc.) gehen ausschliesslich über die
hier definierten Primitives. Damit ist Encoding-Robustheit, Retry-Verhalten
und Cancel-Handling **eine Eigenschaft der Schicht**, nicht jeder
Aufruf-Stelle.

## Schicht-Aufbau (von unten nach oben)

1. **``run_rclone_with_retry``** — Roh-Subprocess mit exponential-Backoff bei
   transient errors (1s/3s/9s) und sauberem Ctrl+C-Handling. Hier weiss
   noch niemand, dass es um rclone geht — das ist generisch.

2. **``run_rclone_with_unicode_fallback``** — Wrapper über (1), der bei
   ``not found``-Fehlern (Exit 3, Exit 4 oder stderr-Substring) einen
   einmaligen NFC↔NFD-Retry der als „Lookup-URI" markierten Args macht.
   Hintergrund: Mega.nz speichert Dateinamen in NFD, unsere ``SourceRef``
   normalisiert auf NFC (nötig für SMB/SFTP) — der Fallback gleicht aus.

3. **Primitives** — ``rclone_cat``, ``rclone_copyto``, ``rclone_lsjson``,
   ``rclone_purge``, ``rclone_deletefile``, ``rclone_delete_matching``.
   Jedes ist eine ~5-Zeiler über (2), das nur seine Lookup-Arg-Indices
   deklariert.

4. **Verify-Helpers** — ``verify_rclone_target_contains``,
   ``verify_rclone_target_files_with_size``. Listen-basiert, mit eigener
   NFC-Normalisierung beim Vergleich.

## Lookup-Arg-Konvention

Die Liste ``lookup_arg_indices`` markiert jene Argumente, deren Pfad-Existenz
rclone prüft (= deren Encoding-Form für den Erfolg entscheidend ist). Write-
Targets (z.B. ``dst`` bei ``copyto``) gehören NICHT dazu, weil sie sonst in
der falschen Form geschrieben würden.

| Befehl                                | Lookup-Indices    |
|---------------------------------------|-------------------|
| ``cat <uri>``                         | ``(2,)``          |
| ``copyto <src> <dst>``                | ``(2,)`` nur src  |
| ``lsjson [--flags] <uri>``            | letztes Element   |
| ``purge <uri>``                       | ``(2,)``          |
| ``deletefile <uri>``                  | ``(2,)``          |
| ``delete <parent> --include <pat>``   | ``(2,)`` parent   |

## Was hier NICHT hingehört

- Geschäfts-Logik (z.B. „verify_archive_target nach Publish"): die lebt in
  ``archiver.py``, ``deployer.py`` etc. und ruft die Primitives auf.
- ``SourceRef`` und URI-Parsing: ``source_ref.py`` ist eigene Verantwortung.
- Notification-Sync: ``notifier_storage.py`` orchestriert Cache + Push,
  ruft uns nur für die rclone-Operationen.

Wer ein neues rclone-Subkommando braucht: füge eine neue Primitive über
``run_rclone_with_unicode_fallback`` mit den passenden ``lookup_arg_indices``
hinzu — Encoding-Robustheit kommt automatisch mit.
"""

from __future__ import annotations

import json
import subprocess
import time
import unicodedata
from collections.abc import Callable, Sequence

# Wartezeiten zwischen Retry-Versuchen (Sekunden). Die Länge der Sequenz
# bestimmt die maximale Anzahl zusätzlicher Versuche nach dem ersten.
DEFAULT_RETRY_DELAYS: tuple[int, ...] = (1, 3, 9)


# ── Schicht 1: Encoding-Helpers ───────────────────────────────────────


def _alternate_unicode_form(s: str) -> str:
    """Tauscht zwischen NFC und NFD.

    Hintergrund (v1.1.1+): Mega.nz speichert Dateinamen mit Umlauten in
    NFD-Form (Wahl der Mega-Webapp / Cloud-Drive-Clients). Unsere
    ``SourceRef``-Klasse normalisiert jedoch alle URIs auf NFC (seit
    v0.10.0 nötig für SMB/SFTP-Backends). Folge: rclone-Operationen mit
    NFC-URI auf einer NFD-Datei scheitern mit „not found".

    Diese Funktion liefert die jeweils andere Form. Wenn ``s`` keine
    combining-Zeichen enthält (NFC == NFD), wird der String unverändert
    zurückgegeben — kein unnötiger Retry.
    """
    nfc = unicodedata.normalize("NFC", s)
    nfd = unicodedata.normalize("NFD", s)
    if nfc == nfd:
        return s
    return nfd if s == nfc else nfc


def _is_not_found_error(e: subprocess.CalledProcessError) -> bool:
    """True wenn der Fehler ein „not found"-Fehler ist (Datei oder Verzeichnis).

    rclone Exit-Codes: 3 = directory not found, 4 = file not found.
    Manche Backends melden Exit 1 mit „not found"-Substring im stderr —
    daher zusätzlich Substring-Check.
    """
    if e.returncode in (3, 4):
        return True
    stderr = e.stderr or ""
    if isinstance(stderr, bytes):
        stderr = stderr.decode("utf-8", errors="replace")
    stderr = stderr.lower()
    return any(s in stderr for s in ("not found", "does not exist", "no such"))


# ── Schicht 2 & 3: Subprocess-Wrapper (Retry + Encoding-Fallback) ─────


def run_rclone_with_unicode_fallback(
    args: list[str],
    *,
    lookup_arg_indices: tuple[int, ...] = (),
    retry_delays: Sequence[int] = DEFAULT_RETRY_DELAYS,
    on_retry: Callable[[int, int, Exception], None] | None = None,
) -> subprocess.CompletedProcess:
    """Wie ``run_rclone_with_retry``, mit einmaligem NFC/NFD-Fallback bei not-found.

    Die zentrale Stelle für Encoding-Robustheit aller rclone-Primitives
    (cat, copyto, lsjson, purge, deletefile, delete --include). Mega.nz
    speichert Umlaute in NFD, unsere SourceRef normalisiert auf NFC —
    bei jedem Lookup auf eine umlauthaltige Datei kann es zum Mismatch
    kommen. Wir versuchen einmal mit umgekehrter Normform und sind
    danach durch.

    Args:
        args: Die kompletten rclone-Argumente inkl. Binary-Pfad.
        lookup_arg_indices: 0-basierte Indices der Args, die als „Lookup-
            URI" gelten — also Pfade, deren Existenz rclone prüft. Diese
            werden im Fallback-Pass in die andere Unicode-Normform
            umgeschrieben. WICHTIG: Write-Targets (z.B. ``dst`` bei
            ``copyto``) gehören NICHT in diese Liste, weil das Alternieren
            sonst zur Datei-Inkonsistenz führen kann.

            Beispiele:
                - ``cat <uri>`` → ``(2,)``
                - ``copyto <src> <dst>`` → ``(2,)`` (nur src)
                - ``lsjson [--flags] <uri>`` → ``(len(args)-1,)``
                - ``deletefile <uri>`` → ``(2,)``
                - ``purge <uri>`` → ``(2,)``
                - ``delete <parent> --include <pat>`` → ``(2,)`` (parent)
        retry_delays / on_retry: durchgereicht an ``run_rclone_with_retry``.

    Returns:
        Das ``CompletedProcess`` des erfolgreichen Aufrufs (egal ob
        Original oder Fallback).

    Raises:
        ``subprocess.CalledProcessError``: wenn auch der Fallback scheitert
        oder ein nicht-not-found-Fehler vorliegt.
    """
    try:
        return run_rclone_with_retry(args, retry_delays=retry_delays, on_retry=on_retry)
    except subprocess.CalledProcessError as e:
        if not _is_not_found_error(e) or not lookup_arg_indices:
            raise
        alt = list(args)
        any_changed = False
        for i in lookup_arg_indices:
            if i >= len(alt) or ":" not in alt[i]:
                continue
            new = _alternate_unicode_form(alt[i])
            if new != alt[i]:
                alt[i] = new
                any_changed = True
        if not any_changed:
            raise
        return run_rclone_with_retry(alt, retry_delays=retry_delays, on_retry=on_retry)


def run_rclone_with_retry(
    args: Sequence[str],
    *,
    retry_delays: Sequence[int] = DEFAULT_RETRY_DELAYS,
    on_retry: Callable[[int, int, Exception], None] | None = None,
) -> subprocess.CompletedProcess:
    """Führt einen rclone-Befehl aus und wiederholt bei flüchtigen Fehlern.

    Args:
        args: Komplette Argumentliste inkl. ``rclone``-Binary (z.B.
            ``[rclone_path, "copy", source, target]``).
        retry_delays: Wartezeiten zwischen Versuchen in Sekunden. Default
            ``(1, 3, 9)`` = 3 Retries nach dem ersten Versuch (maximal 4
            Versuche insgesamt).
        on_retry: Optionaler Callback, der vor jedem Retry aufgerufen wird —
            erhält ``(attempt, max_attempts, last_exception)``. Ideal für
            Event-basierte Fortschrittsanzeige.

    Returns:
        ``CompletedProcess`` des erfolgreichen Laufs.

    Raises:
        subprocess.CalledProcessError: Wenn alle Versuche fehlgeschlagen sind.
            Die Exception des letzten Versuchs wird weitergereicht.
        FileNotFoundError: Wenn die rclone-Binary nicht gefunden wurde
            (wird nicht retried — Konfigurationsfehler).
        KeyboardInterrupt: Wird direkt durchgereicht, ohne weitere Retry-
            Versuche zu starten (seit v0.8.0). Vorher konnte Ctrl+C
            während eines ``subprocess.run`` oder der ``time.sleep``-
            Pause vom Retry-Loop fälschlich als transient error
            interpretiert werden und den nächsten Versuch triggern.
    """
    max_attempts = len(retry_delays) + 1
    last_error: subprocess.CalledProcessError | None = None

    for attempt in range(1, max_attempts + 1):
        try:
            return subprocess.run(
                list(args),
                check=True,
                capture_output=True,
                text=True,
            )
        except KeyboardInterrupt:
            # Ctrl+C während des rclone-Aufrufs → sofort durchreichen,
            # kein weiterer Retry. subprocess.run gibt SIGINT an den
            # Kindprozess weiter; wir respektieren die User-Entscheidung.
            raise
        except subprocess.CalledProcessError as e:
            # Exit-Code 130 (= 128 + SIGINT, rclone's eigenes Handling) oder
            # -2 (POSIX: durch SIGINT gekillt, bevor rclone selbst exit()
            # aufrufen konnte): Der Child-Prozess wurde durch Ctrl+C beendet.
            # Grund für die Sonderbehandlung: der Watch-Loop installiert einen
            # SIGINT-Handler, der das Signal in ein Flag umwandelt statt
            # ``KeyboardInterrupt`` auszulösen — Python sieht das Signal
            # deshalb nicht, der Child aber schon. Wir müssen hier manuell
            # ``KeyboardInterrupt`` auslösen, damit der Retry-Loop nicht
            # trotz User-Abbruch weiterläuft.
            if e.returncode in (130, -2):
                raise KeyboardInterrupt() from e
            last_error = e
            if attempt >= max_attempts:
                break
            if on_retry is not None:
                on_retry(attempt, max_attempts, e)
            # Sleep-Phase darf ebenfalls durch Ctrl+C unterbrochen werden
            # (time.sleep wirft KeyboardInterrupt, das wir propagieren).
            try:
                time.sleep(retry_delays[attempt - 1])
            except KeyboardInterrupt:
                raise

    assert last_error is not None
    raise last_error


# ── Schicht 4: Verify-Helpers (Listen-basierte Existenzprüfung) ───────


def verify_rclone_target_contains(
    target: str,
    expected_names: Sequence[str],
    *,
    rclone_path: str = "rclone",
) -> tuple[bool, list[str]]:
    """Prüft, dass ``expected_names`` (Dateien oder Unterverzeichnisse) im ``target`` existieren.

    Ruft ``rclone lsf <target>`` auf (schnell — nur Namen, keine Metadata) und
    prüft, ob jeder Name in ``expected_names`` in der Ausgabe vorkommt.

    Args:
        target: rclone-Ziel (z.B. ``nas:/Archiv/2026/Videoschnitt``).
        expected_names: Namen, die im Target erwartet werden (z.B. TAR-Name oder
            Web-ID-Verzeichnis).
        rclone_path: Pfad zur rclone-Binary.

    Returns:
        Tuple ``(alle_vorhanden, fehlende_namen)``. Wenn rclone selbst nicht
        ausgeführt werden kann (Remote nicht erreichbar), wird ``(False, expected_names)``
        zurückgegeben — das Ziel gilt als unverifizierbar, gleichbedeutend mit
        „Dateien fehlen".
    """
    try:
        result = subprocess.run(
            [rclone_path, "lsf", target],
            check=True,
            capture_output=True,
            text=True,
        )
    except (subprocess.CalledProcessError, FileNotFoundError, OSError):
        return False, list(expected_names)

    # rclone lsf gibt Namen zeilenweise aus; Verzeichnisse enden mit "/".
    # Unicode-Normalisierung (NFC) auf beiden Seiten: macOS liefert
    # Dateinamen aus dem lokalen Filesystem oft in NFD (z.B. ``ä`` als
    # ``a`` + U+0308), während das SFTP-Ziel NFC liefert. Ohne
    # Normalisierung schlägt ein Vergleich für Umlaute/Akzente fehl,
    # obwohl die Dateien faktisch im Ziel sind (beobachtet in v0.8.0
    # End-to-End-Test).
    def _nfc(s: str) -> str:
        return unicodedata.normalize("NFC", s)

    present = {
        _nfc(line.rstrip("/").strip())
        for line in result.stdout.splitlines()
        if line.strip()
    }
    missing = [
        name.rstrip("/")
        for name in expected_names
        if _nfc(name.rstrip("/")) not in present
    ]
    return len(missing) == 0, missing


def verify_rclone_target_files_with_size(
    target: str,
    expected: dict[str, int | None],
    *,
    rclone_path: str = "rclone",
) -> tuple[bool, list[str], list[tuple[str, int, int]]]:
    """Prüft Existenz und optional die Grösse erwarteter Dateien im Ziel.

    Ruft ``rclone lsf --format "sp" <target>`` auf (gibt ``size;path``
    pro Datei zurück) und vergleicht mit den erwarteten Einträgen.

    Args:
        target: rclone-Ziel (z.B. ``nas:/archive/familienfilme``).
        expected: Mapping ``name → erwartete_size_in_bytes``. Wenn der Wert
            ``None`` ist, wird nur die Existenz geprüft (kein Size-Vergleich).
        rclone_path: Pfad zur rclone-Binary.

    Returns:
        Tuple ``(ok, missing, size_mismatch)``.

        - ``ok``: True wenn alle erwarteten Dateien vorhanden sind **und** alle
          Grössenangaben übereinstimmen.
        - ``missing``: Liste der nicht gefundenen Namen.
        - ``size_mismatch``: Liste ``(name, expected_size, actual_size)`` für
          Dateien, die zwar gefunden, aber in falscher Grösse vorliegen.

        Wenn rclone selbst fehlschlägt (Remote nicht erreichbar), wird
        ``(False, list(expected), [])`` zurückgegeben — alle Dateien gelten
        als fehlend.
    """
    try:
        result = subprocess.run(
            [rclone_path, "lsf", "--format", "sp", target],
            check=True,
            capture_output=True,
            text=True,
        )
    except (subprocess.CalledProcessError, FileNotFoundError, OSError):
        return False, list(expected.keys()), []

    def _nfc(s: str) -> str:
        return unicodedata.normalize("NFC", s)

    # Jede Zeile: "<size>;<path>". Verzeichnisse erkennt rclone mit trailing "/".
    present: dict[str, int] = {}
    for line in result.stdout.splitlines():
        line = line.strip()
        if not line or ";" not in line:
            continue
        size_str, _, path = line.partition(";")
        path = path.rstrip("/").strip()
        if not path:
            continue
        try:
            size = int(size_str)
        except ValueError:
            continue
        present[_nfc(path)] = size

    missing: list[str] = []
    size_mismatch: list[tuple[str, int, int]] = []
    for name, expected_size in expected.items():
        key = _nfc(name.rstrip("/"))
        if key not in present:
            missing.append(name.rstrip("/"))
            continue
        if expected_size is not None and present[key] != expected_size:
            size_mismatch.append((name.rstrip("/"), expected_size, present[key]))

    ok = not missing and not size_mismatch
    return ok, missing, size_mismatch


# ---------------------------------------------------------------------------
# Primitives für v0.7.0: rclone als Quell-Backend (Lesen vom Remote).
# ---------------------------------------------------------------------------


# ── Schicht 3: rclone-Subkommando-Primitives ──────────────────────────
#
# Jede Primitive baut die Argumentliste, deklariert die Lookup-Indices und
# delegiert an ``run_rclone_with_unicode_fallback``. Encoding-Robustheit
# (Mega-NFD) und Retry-Verhalten kommen automatisch.


def rclone_cat(
    uri: str,
    *,
    rclone_path: str = "rclone",
    retry_delays: Sequence[int] = DEFAULT_RETRY_DELAYS,
    on_retry: Callable[[int, int, Exception], None] | None = None,
) -> bytes | None:
    """Liest eine Datei vom rclone-Remote.

    Nutzt ``rclone cat <uri>``. Für kleine Dateien (Sidecars, familienfilm.toml)
    gedacht. Bei CalledProcessError mit ``not found``/``does not exist``-Text
    wird ``None`` zurückgegeben (als „Datei nicht vorhanden"-Signal — rclone
    hat leider keinen separaten Exit-Code dafür).

    Andere Fehler (Verbindung, Auth) werden nach Retry-Exhaustion re-raised.
    Encoding-Robustheit (Mega-NFD) kommt automatisch via
    ``run_rclone_with_unicode_fallback``.
    """
    try:
        result = run_rclone_with_unicode_fallback(
            [rclone_path, "cat", uri],
            lookup_arg_indices=(2,),
            retry_delays=retry_delays,
            on_retry=on_retry,
        )
    except subprocess.CalledProcessError as e:
        if _is_not_found_error(e):
            return None
        raise
    # rclone cat liefert Bytes via stdout; run_rclone_with_retry nutzt text=True,
    # also haben wir einen String. Für TOML-Inhalte reicht das. Wir geben
    # Bytes zurück für Roundtrip-Sicherheit.
    return result.stdout.encode("utf-8") if result.stdout else b""


def rclone_lsjson(
    uri: str,
    *,
    recursive: bool = False,
    files_only: bool = False,
    rclone_path: str = "rclone",
    retry_delays: Sequence[int] = DEFAULT_RETRY_DELAYS,
    on_retry: Callable[[int, int, Exception], None] | None = None,
) -> list[dict]:
    """Listet den Inhalt eines rclone-Remote-Verzeichnisses als JSON.

    Aufruf: ``rclone lsjson [--recursive] [--files-only] <uri>``.

    Args:
        files_only: Wenn True, werden Verzeichnis-Einträge in der Ausgabe
            unterdrückt (``--files-only``). Praktisch in Kombination mit
            ``recursive=True``, um in einem Aufruf alle Files mit Size +
            ModTime zu bekommen (Web-Storage-Aggregation, v0.10.0+).

    Returns:
        Liste von Dicts mit mindestens ``Name`` (str), ``Size`` (int),
        ``IsDir`` (bool), ``Path`` (str, relativ zu ``uri``), ``ModTime``
        (ISO-8601 String). Leere Liste wenn Verzeichnis existiert aber leer.

    Raises:
        subprocess.CalledProcessError: Bei endgültigem Fehler (Verzeichnis
            existiert nicht, Auth-Problem nach Retries etc.).
    """
    args = [rclone_path, "lsjson"]
    if recursive:
        args.append("--recursive")
    if files_only:
        args.append("--files-only")
    args.append(uri)

    # uri liegt am Ende (Position variiert je nach Flags) — daher dynamischer Index.
    result = run_rclone_with_unicode_fallback(
        args,
        lookup_arg_indices=(len(args) - 1,),
        retry_delays=retry_delays,
        on_retry=on_retry,
    )
    if not result.stdout.strip():
        return []
    data = json.loads(result.stdout)
    if not isinstance(data, list):
        raise ValueError(f"Unerwartete rclone-lsjson-Ausgabe: {type(data).__name__}")
    return data


def rclone_copyto(
    src: str,
    dst: str,
    *,
    rclone_path: str = "rclone",
    retry_delays: Sequence[int] = DEFAULT_RETRY_DELAYS,
    on_retry: Callable[[int, int, Exception], None] | None = None,
) -> None:
    """Kopiert eine einzelne Datei mit neuem Namen (``rclone copyto``).

    Unterschied zu ``rclone copy``: copyto nimmt exakt einen Source-File und
    einen Target-File-Pfad, nicht Verzeichnisse. Perfekt für Sidecar-
    Rücksync und Video-Staging mit ggf. umbenannten Zielnamen.

    Quelle oder Ziel können lokal (``/pfad``) oder rclone-URI (``remote:pfad``)
    sein. Beide lokal: rclone tut's trotzdem korrekt (delegiert an OS).

    Encoding-Robustheit (Mega-NFD) kommt automatisch via
    ``run_rclone_with_unicode_fallback``. Nur ``src`` ist ein Lookup —
    ``dst`` ist ein Write-Target und wird NICHT alterniert.
    """
    run_rclone_with_unicode_fallback(
        [rclone_path, "copyto", src, dst],
        lookup_arg_indices=(2,),
        retry_delays=retry_delays,
        on_retry=on_retry,
    )


def rclone_delete_matching(
    parent_uri: str,
    basename: str,
    *,
    rclone_path: str = "rclone",
    retry_delays: Sequence[int] = DEFAULT_RETRY_DELAYS,
    on_retry: Callable[[int, int, Exception], None] | None = None,
) -> None:
    """Löscht alle Dateien mit dem gegebenen Basename aus einem rclone-Verzeichnis.

    Ruft ``rclone delete <parent_uri> --include <basename>`` auf. Im Gegensatz
    zu ``rclone deletefile`` arbeitet das auch dann robust, wenn am Remote
    mehrere Knoten mit demselben Namen existieren — typisch für mega.nz, das
    Duplikat-Filenamen erlaubt und beim ``copyto`` neue Knoten anlegt statt
    zu ersetzen. Verwendet von ``push_to_remote`` als Pre-Upload-Cleanup,
    damit nach jedem Sync genau eine Datei mit dem Namen am Ziel liegt.

    Tolerant gegen "nichts zu löschen": wenn das Verzeichnis nicht existiert
    oder kein Treffer gefunden wird, ist das je nach rclone-Backend Erfolg
    oder ein harmloser Fehler — Caller sollte Exceptions abfangen.

    Encoding-Robustheit (Mega-NFD) für ``parent_uri`` kommt automatisch
    via ``run_rclone_with_unicode_fallback``.
    """
    run_rclone_with_unicode_fallback(
        [rclone_path, "delete", parent_uri, "--include", basename],
        lookup_arg_indices=(2,),
        retry_delays=retry_delays,
        on_retry=on_retry,
    )


def rclone_deletefile(
    uri: str,
    *,
    rclone_path: str = "rclone",
    retry_delays: Sequence[int] = DEFAULT_RETRY_DELAYS,
    on_retry: Callable[[int, int, Exception], None] | None = None,
) -> None:
    """Löscht eine einzelne Datei (``rclone deletefile <uri>``).

    Im Gegensatz zu ``rclone purge`` (rekursives Verzeichnis-Löschen) und
    ``rclone delete --include`` (Pattern-basiertes Mehrfach-Löschen)
    operiert ``deletefile`` auf genau einer Datei und ist die richtige
    Wahl für ``--delete-source``-Workflows nach einem verifizierten
    Publish.

    Encoding-Robustheit (Mega-NFD) kommt automatisch via
    ``run_rclone_with_unicode_fallback``.
    """
    run_rclone_with_unicode_fallback(
        [rclone_path, "deletefile", uri],
        lookup_arg_indices=(2,),
        retry_delays=retry_delays,
        on_retry=on_retry,
    )


def rclone_purge(
    uri: str,
    *,
    rclone_path: str = "rclone",
    retry_delays: Sequence[int] = DEFAULT_RETRY_DELAYS,
    on_retry: Callable[[int, int, Exception], None] | None = None,
) -> None:
    """Löscht ein rclone-Remote-Verzeichnis komplett (rekursiv) via ``rclone purge``.

    Eingeführt für die Web-Storage-Bereinigung (v0.10.0+): wenn das
    konfigurierte Speicherbudget des Web-Targets vor einem Upload überschritten
    würde, werden ältere Mediaset-Verzeichnisse als Ganzes entfernt.

    Mit den üblichen Retry- und KeyboardInterrupt-Garantien. Fehler nach
    allen Retries werden als ``subprocess.CalledProcessError`` re-raised.
    Encoding-Robustheit (Mega-NFD) kommt automatisch via
    ``run_rclone_with_unicode_fallback``.
    """
    run_rclone_with_unicode_fallback(
        [rclone_path, "purge", uri],
        lookup_arg_indices=(2,),
        retry_delays=retry_delays,
        on_retry=on_retry,
    )
