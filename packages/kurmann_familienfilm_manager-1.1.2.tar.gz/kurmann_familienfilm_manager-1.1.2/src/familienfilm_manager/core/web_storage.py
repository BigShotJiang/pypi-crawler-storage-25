"""Web-Target Storage-Budget mit automatischer Bereinigung ältester Mediasets.

Hostpoint hat ein hartes Speicherlimit (typisch 500 GB). Vor jedem Web-Upload
prüft dieses Modul, ob ``aktuell_belegt + neues_mediaset + 5 % Sicherheitsmarge``
das Budget übersteigt — wenn ja, wird das älteste Web-Mediaset (gemessen an der
``mtime`` der ``index.html`` im Mediaset-Verzeichnis) komplett via
``rclone purge`` gelöscht. Iteriert solange, bis Platz reicht.

Kein Side-Channel-Index nötig: ``rclone lsjson --recursive --files-only``
liefert in einem Aufruf alle Files mit Size + ModTime. Daraus aggregieren wir
pro Top-Level-Verzeichnis (= ``web_id``) Grösse und älteste mtime.

Sichtbarkeit: pro Cleanup-Aktion fliesst ein ``WEB_CLEANUP_DELETED``-Event nach
oben (wird in der CLI rot markiert). Im Dry-Run werden die Events stattdessen
als ``WEB_CLEANUP_DRY_RUN`` emittiert und tatsächlich nichts gelöscht.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional

from familienfilm_manager.api.models import (
    FamilienfilmEvent,
    FamilienfilmStage,
)
from familienfilm_manager.core._rclone import (
    rclone_lsjson,
    rclone_purge,
)

EventCallback = Optional[Callable[[FamilienfilmEvent], None]]

# Hartcodierter Sicherheitspuffer auf das konfigurierte Budget.
# Verhindert „rasiert genau bis zur Kante" — gibt Hostpoint etwas Luft für
# Atomicity / vorübergehende Doubletten beim rclone-Copy.
SAFETY_MARGIN_PERCENT = 5

# 1 GB im SI-Sinn (10^9 Bytes) — entspricht der Anzeige im Hostpoint-
# Customer-Portal und in macOS Finder. Wir folgen bewusst NICHT dem
# binären GiB-Schema (1024^3), weil es für den Endnutzer verwirrend wäre.
_SIZE_UNITS = {
    "":   1,
    "b":  1,
    "k":  1_000,             "kb": 1_000,
    "m":  1_000_000,         "mb": 1_000_000,
    "g":  1_000_000_000,     "gb": 1_000_000_000,
    "t":  1_000_000_000_000, "tb": 1_000_000_000_000,
}

_SIZE_RE = re.compile(r"^\s*([0-9_]+(?:\.[0-9]+)?)\s*([a-zA-Z]*)\s*$")


def parse_size(s: str) -> int:
    """Konvertiert Grössenangaben wie ``"500GB"``, ``"1.5tb"``, ``"1_000_000"`` in Bytes.

    SI-Basis (1 GB = 10⁹ Bytes), nicht GiB. Unterstützte Suffixe (case-insensitiv):
    ``B``, ``K`` / ``KB``, ``M`` / ``MB``, ``G`` / ``GB``, ``T`` / ``TB``.

    Wirft ``ValueError`` bei leerem oder unparsbarem String — der Caller
    (Config-Loader) entscheidet, ob er Fallback auf „kein Budget" macht.
    """
    if not s or not s.strip():
        raise ValueError("Leere Grössenangabe")
    m = _SIZE_RE.match(s)
    if not m:
        raise ValueError(f"Ungültige Grössenangabe: {s!r}")
    number = float(m.group(1).replace("_", ""))
    suffix = m.group(2).lower()
    if suffix not in _SIZE_UNITS:
        raise ValueError(
            f"Unbekannte Einheit {suffix!r} in {s!r}. "
            f"Erlaubt: {', '.join(sorted(_SIZE_UNITS))}",
        )
    return int(number * _SIZE_UNITS[suffix])


def format_size(n: int) -> str:
    """Menschenlesbare SI-Grösse für Log-Ausgaben (z.B. „483.6 GB")."""
    if n < 1_000:
        return f"{n} B"
    if n < 1_000_000:
        return f"{n / 1_000:.1f} KB"
    if n < 1_000_000_000:
        return f"{n / 1_000_000:.1f} MB"
    if n < 1_000_000_000_000:
        return f"{n / 1_000_000_000:.2f} GB"
    return f"{n / 1_000_000_000_000:.2f} TB"


@dataclass(frozen=True)
class WebMediaset:
    """Zusammenfassung eines Mediasets im Web-Target.

    Aus ``rclone lsjson --recursive --files-only`` aggregiert: pro Top-Level-
    Verzeichnis (= ``web_id``) summieren wir die Files und nehmen die ``mtime``
    der ``index.html`` als Upload-Zeitpunkt-Proxy. Fehlt die ``index.html``,
    dient die älteste File-mtime im Verzeichnis als Fallback.
    """

    web_id: str
    size_bytes: int
    index_mtime: datetime  # tz-aware (UTC normalisiert)


def _parse_rclone_modtime(s: str) -> datetime:
    """Parst rclone-ModTime-Strings (ISO-8601 mit ggf. Sub-Sekunden + TZ)."""
    # rclone liefert z.B. "2026-04-24T12:30:00.123456789+02:00" — Python's
    # fromisoformat akzeptiert max. 6 Nachkommastellen; bei mehr abschneiden.
    if "." in s:
        head, _, tail = s.partition(".")
        # alles bis zum ersten Nicht-Digit ist die Sub-Sekunden-Komponente
        digits = ""
        rest = ""
        for i, ch in enumerate(tail):
            if ch.isdigit():
                digits += ch
            else:
                rest = tail[i:]
                break
        digits = digits[:6]
        s = f"{head}.{digits}{rest}" if digits else f"{head}{rest}"
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        # Fallback: ohne TZ als UTC interpretieren
        dt = datetime.fromisoformat(s.split("+")[0].split("Z")[0]).replace(
            tzinfo=timezone.utc,
        )
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def list_web_mediasets(
    web_target: str,
    *,
    rclone_path: str = "rclone",
) -> list[WebMediaset]:
    """Listet alle Web-Mediasets im Target, sortiert von ältestem zu jüngstem.

    Gruppiert die rekursive Files-Liste nach Top-Level-Path-Segment. Files
    direkt im Root (kein Top-Level-Verzeichnis) werden ignoriert — z.B.
    eine künftige ``.web-index.toml`` oder vom User abgelegte Dateien.

    Returns:
        Liste von ``WebMediaset``, sortiert nach ``index_mtime`` aufsteigend
        (ältestes zuerst). Leer wenn das Target leer ist oder nur Top-Level-
        Files enthält.
    """
    entries = rclone_lsjson(
        web_target, recursive=True, files_only=True, rclone_path=rclone_path,
    )

    # Gruppieren: Top-Level-Segment des `Path`-Felds = web_id
    by_id: dict[str, dict] = {}
    for entry in entries:
        path = entry.get("Path", "")
        if "/" not in path:
            # Datei im Root des Targets — gehört zu keinem Mediaset
            continue
        web_id = path.split("/", 1)[0]
        size = int(entry.get("Size", 0))
        modtime_raw = entry.get("ModTime", "")
        try:
            modtime = _parse_rclone_modtime(modtime_raw)
        except (ValueError, TypeError):
            # Backend liefert keine brauchbare ModTime → epoch als Fallback
            modtime = datetime.fromtimestamp(0, tz=timezone.utc)

        bucket = by_id.setdefault(web_id, {
            "size": 0,
            "index_mtime": None,
            "min_mtime": None,
        })
        bucket["size"] += size

        # index.html mtime hat Vorrang — sie entspricht dem Upload-Zeitpunkt
        # des sichtbaren Mediasets. Wenn nicht vorhanden, fallen wir auf
        # die älteste File-mtime im Verzeichnis zurück.
        filename = path.rsplit("/", 1)[-1].lower()
        if filename == "index.html":
            bucket["index_mtime"] = modtime
        if bucket["min_mtime"] is None or modtime < bucket["min_mtime"]:
            bucket["min_mtime"] = modtime

    mediasets = [
        WebMediaset(
            web_id=wid,
            size_bytes=b["size"],
            index_mtime=b["index_mtime"] or b["min_mtime"],
        )
        for wid, b in by_id.items()
    ]
    mediasets.sort(key=lambda m: m.index_mtime)
    return mediasets


def cleanup_aged_mediasets(
    web_target: str,
    max_age_days: int,
    *,
    rclone_path: str = "rclone",
    dry_run: bool = False,
    on_event: EventCallback = None,
    _now: datetime | None = None,
) -> list[WebMediaset]:
    """Löscht alle Mediasets, deren ``index.html``-mtime älter als ``max_age_days``.

    Unabhängig vom Speicherbudget — wenn 50 Mediasets älter als die Schwelle
    sind, gehen alle 50 raus. Konsistente, vorhersehbare Regel.

    Args:
        web_target: rclone-URI des Web-Targets.
        max_age_days: Schwelle in Tagen. ``<= 0`` deaktiviert die Prüfung.
        rclone_path: rclone-Binary.
        dry_run: Wenn True, wird nur geloggt was gelöscht würde.
        on_event: Event-Callback (WEB_BUDGET_CHECK / WEB_CLEANUP_DELETED /
            WEB_CLEANUP_DRY_RUN).
        _now: Test-Hook — überschreibt ``datetime.now(tz=UTC)`` für
            deterministische Unit-Tests.

    Returns:
        Liste der entfernten ``WebMediaset``-Einträge.
    """
    if max_age_days <= 0:
        return []

    mediasets = list_web_mediasets(web_target, rclone_path=rclone_path)
    now = _now or datetime.now(tz=timezone.utc)
    cutoff = now - timedelta(days=max_age_days)

    aged = [m for m in mediasets if m.index_mtime < cutoff]

    if on_event:
        on_event(FamilienfilmEvent(
            stage_id=FamilienfilmStage.WEB_BUDGET_CHECK,
            message=(
                f"Web-Alter-Check: max {max_age_days} Tage, "
                f"{len(aged)} von {len(mediasets)} Mediaset(s) zu alt"
            ),
        ))

    deleted: list[WebMediaset] = []
    for old in aged:
        age_days = (now - old.index_mtime).days
        if on_event:
            stage = (
                FamilienfilmStage.WEB_CLEANUP_DRY_RUN
                if dry_run
                else FamilienfilmStage.WEB_CLEANUP_DELETED
            )
            verb = "würde löschen" if dry_run else "lösche"
            on_event(FamilienfilmEvent(
                stage_id=stage,
                message=(
                    f"Web-Cleanup (Alter): {verb} {old.web_id} "
                    f"({format_size(old.size_bytes)}, "
                    f"{age_days} Tage alt — älter als max {max_age_days})"
                ),
            ))

        if not dry_run:
            target_uri = f"{web_target.rstrip('/')}/{old.web_id}"
            try:
                rclone_purge(target_uri, rclone_path=rclone_path)
            except Exception as e:
                if on_event:
                    on_event(FamilienfilmEvent(
                        stage_id=FamilienfilmStage.WEB_BUDGET_EXCEEDED,
                        message=(
                            f"Web-Cleanup (Alter) für {old.web_id} fehlgeschlagen: "
                            f"{e}. Lauf wird fortgesetzt."
                        ),
                    ))
                continue
        deleted.append(old)

    return deleted


def cleanup_oldest_until_fits(
    web_target: str,
    new_mediaset_size: int,
    budget_bytes: int,
    *,
    rclone_path: str = "rclone",
    dry_run: bool = False,
    on_event: EventCallback = None,
) -> list[WebMediaset]:
    """Bereinigt ältester Mediasets im Web-Target, bis das Budget passt.

    Logik:
      effektives_budget = budget_bytes * (100 - 5) / 100
      benötigt_freier_platz = neues_mediaset
      verfügbar = effektives_budget - aktuell_belegt
      Solange benötigt_freier_platz > verfügbar:
          ältestes Mediaset löschen, verfügbar entsprechend erhöhen.

    Returns:
        Liste der gelöschten Mediasets (im dry_run: die, die gelöscht würden).
        Caller kann daraus die Notification-HTML aktualisieren.

    Events:
        - ``WEB_BUDGET_CHECK`` immer (info, mit aktuellem Stand)
        - ``WEB_CLEANUP_DELETED`` (oder ``_DRY_RUN``) pro Mediaset
        - ``WEB_BUDGET_EXCEEDED`` wenn auch nach allen Löschungen nicht
          genug Platz wäre (pathologisch — neues Mediaset alleine grösser
          als gesamtes Budget).
    """
    mediasets = list_web_mediasets(web_target, rclone_path=rclone_path)
    used = sum(m.size_bytes for m in mediasets)
    margin_bytes = budget_bytes * SAFETY_MARGIN_PERCENT // 100
    effective_budget = budget_bytes - margin_bytes

    if on_event:
        on_event(FamilienfilmEvent(
            stage_id=FamilienfilmStage.WEB_BUDGET_CHECK,
            message=(
                f"Web-Budget: belegt {format_size(used)} / "
                f"{format_size(budget_bytes)} (Marge {SAFETY_MARGIN_PERCENT}% "
                f"= {format_size(margin_bytes)}), "
                f"neuer Upload {format_size(new_mediaset_size)}"
            ),
        ))

    available = effective_budget - used
    needed = new_mediaset_size - available
    if needed <= 0:
        return []

    deleted: list[WebMediaset] = []
    pending = list(mediasets)  # Kopie, älteste zuerst
    while needed > 0 and pending:
        oldest = pending.pop(0)

        if on_event:
            stage = (
                FamilienfilmStage.WEB_CLEANUP_DRY_RUN
                if dry_run
                else FamilienfilmStage.WEB_CLEANUP_DELETED
            )
            verb = "würde löschen" if dry_run else "lösche"
            on_event(FamilienfilmEvent(
                stage_id=stage,
                message=(
                    f"Web-Cleanup: {verb} {oldest.web_id} "
                    f"({format_size(oldest.size_bytes)}, "
                    f"index.html-mtime {oldest.index_mtime.isoformat(timespec='seconds')})"
                ),
            ))

        if not dry_run:
            target_uri = f"{web_target.rstrip('/')}/{oldest.web_id}"
            try:
                rclone_purge(target_uri, rclone_path=rclone_path)
            except Exception as e:
                # Löschung scheitert: nicht weiterzählen, Event + abort.
                if on_event:
                    on_event(FamilienfilmEvent(
                        stage_id=FamilienfilmStage.WEB_BUDGET_EXCEEDED,
                        message=(
                            f"Web-Cleanup für {oldest.web_id} fehlgeschlagen: "
                            f"{e}. Upload erfolgt trotzdem (Hostpoint kann ablehnen)."
                        ),
                    ))
                break

        deleted.append(oldest)
        needed -= oldest.size_bytes

    if needed > 0 and on_event:
        on_event(FamilienfilmEvent(
            stage_id=FamilienfilmStage.WEB_BUDGET_EXCEEDED,
            message=(
                f"Web-Budget kann nicht eingehalten werden: nach "
                f"{len(deleted)} Bereinigungen fehlen weiterhin "
                f"{format_size(max(needed, 0))}. Upload erfolgt trotzdem "
                f"— Hostpoint kann ablehnen."
            ),
        ))

    return deleted
