"""Scan von rclone-Remotes: findet qualifizierte Videos ohne lokalen Mount.

Analog zu ``_scan_directory`` im ``directory_publisher``, aber mit
``rclone lsjson`` statt Filesystem-Iteration. Gibt URIs zurück, die
später per ``stage_source`` lokal gemacht werden.

Zusätzlich ein **Light-Peek** für die Skip-Logik: bevor das Video (u.U.
mehrere GB) gestaged wird, wird nur die kleine ``.settings.toml``
herangezogen. Stimmen ``published_at`` für alle aktiven Kanäle und
``source_size_bytes`` mit der aktuellen Remote-Size überein, kann der
Publisher das Video überspringen — ohne einen einzigen Byte Video-
Traffic.
"""

from __future__ import annotations

import json
import re
from collections.abc import Sequence
from dataclasses import dataclass

from familienfilm_manager.core._rclone import (
    rclone_cat,
    rclone_lsjson,
)
from familienfilm_manager.core.directory_publisher import (
    _DATE_PREFIX_RE,
    _VIDEO_EXTENSIONS,
    _is_package_dir_name,
)
from familienfilm_manager.core.sidecar_manager import SidecarSettings
from familienfilm_manager.core.source_ref import SourceRef


@dataclass
class RemoteVideoRef:
    """Ergebnis des rclone-Scans: ein qualifiziertes Video auf dem Remote."""

    uri: str                    # Voller rclone-URI zum Video
    name: str                   # Dateiname
    size_bytes: int             # Aktuelle Remote-Dateigröße


def _is_qualified_remote_video(name: str) -> bool:
    """Filterregeln identisch zum lokalen Scan, aber nur namensbasiert
    (kein Filesystem-Zugriff)."""
    if not name or name.startswith("."):
        return False
    # Suffix prüfen
    if "." not in name:
        return False
    suffix = "." + name.rsplit(".", 1)[-1]
    if suffix.lower() not in _VIDEO_EXTENSIONS:
        return False
    # Stem muss das Datum-Präfix erfüllen
    stem = name.rsplit(".", 1)[0]
    return bool(_DATE_PREFIX_RE.match(stem))


def _is_remote_video_file(name: str) -> bool:
    """Wie ``_is_qualified_remote_video``, aber OHNE Datums-Präfix-Check.

    Wird verwendet, um Videos zu finden, die zwar Video-Dateien sind, aber
    wegen falschem Dateinamen (kein Datums-Präfix) nicht publiziert werden
    — damit der Caller sie dem User reporten kann statt still zu ignorieren
    (v0.12.0+, analog zur lokalen Variante).
    """
    if not name or name.startswith("."):
        return False
    if "." not in name:
        return False
    suffix = "." + name.rsplit(".", 1)[-1]
    return suffix.lower() in _VIDEO_EXTENSIONS


def _date_from_remote_name(name: str) -> str:
    """Extrahiert das Datum aus einem Dateinamen (für Sortierung)."""
    stem = name.rsplit(".", 1)[0] if "." in name else name
    match = _DATE_PREFIX_RE.match(stem)
    return match.group(1) if match else "0000-00-00"


def scan_rclone_directory(
    directory_uri: str,
    *,
    recursive: bool = False,
    rclone_path: str = "rclone",
) -> tuple[list[RemoteVideoRef], list[str]]:
    """Listet qualifizierte UND nicht-qualifizierte Videos in einem rclone-Remote.

    Sortierung der qualifizierten: chronologisch nach Datum im Dateinamen,
    älteste zuerst.

    Args:
        directory_uri: rclone-URI des Verzeichnisses (z.B.
            ``"lyssach-nas:/Quelle/neu2"``).
        recursive: Wenn True, werden Unterverzeichnisse mitgescannt.
            Hidden-Pfade (mit ``.`` am Anfang) werden übersprungen.
        rclone_path: Pfad zur rclone-Binary.

    Returns:
        Tuple ``(qualified, unqualified_names)``. ``qualified`` ist die
        sortierte Liste von ``RemoteVideoRef``. ``unqualified_names`` sind
        Dateinamen mit Video-Endung aber ohne Datums-Präfix — der Caller
        reportet sie dem User (v0.12.0+).
    """
    base_ref = SourceRef(directory_uri)
    # Keine bare-except-Schluckung mehr (seit v0.10.0): rclone-Fehler
    # (CalledProcessError bei Auth, Netzwerk-Hiccup, falscher Pfad) werden
    # propagiert. Sie landen im Watcher als DEPLOY_FAILED-Event statt still
    # als „Verzeichnis leer" interpretiert zu werden — das hatte vorher zu
    # 0/0/0/0-Tick-Summaries ohne erkennbare Ursache geführt.
    entries = rclone_lsjson(directory_uri, recursive=recursive, rclone_path=rclone_path)

    results: list[RemoteVideoRef] = []
    unqualified: list[str] = []
    for entry in entries:
        if entry.get("IsDir"):
            continue
        # Bei recursive=True hat "Path" den relativen Pfad inkl. Unterverzeichnis
        relative_path = entry.get("Path") or entry.get("Name", "")
        name = entry.get("Name", "")

        # Hidden- und Package-Unterverzeichnisse überspringen
        # (Package = ``.fcpxmld`` / ``.lfpackage`` — FCP/LumaFusion-Bundles
        # sind filesystem-technisch Directories, dürfen aber nicht gescannt
        # werden, sonst landen darin gecachte Medien als eigene Kandidaten.)
        if recursive and "/" in relative_path:
            parts = relative_path.split("/")
            if any(p.startswith(".") for p in parts[:-1]):
                continue
            if any(_is_package_dir_name(p) for p in parts[:-1]):
                continue

        if not _is_qualified_remote_video(name):
            # Video-Datei aber Datums-Präfix passt nicht? Für User-Report sammeln.
            if _is_remote_video_file(name):
                unqualified.append(relative_path)
            continue

        # Vollen URI konstruieren: directory_uri + relative_path
        video_uri = base_ref.child_uri(relative_path)
        results.append(RemoteVideoRef(
            uri=video_uri,
            name=name,
            size_bytes=int(entry.get("Size", -1)),
        ))

    results.sort(key=lambda r: (_date_from_remote_name(r.name), r.name.lower()))
    return results, unqualified


def peek_remote_sidecar(
    video_uri: str,
    *,
    rclone_path: str = "rclone",
) -> SidecarSettings | None:
    """Light-Peek: zieht NUR das kleine ``.settings.toml`` vom Remote.

    Spart bei grossen Videos GB-weise Bandbreite, wenn das Video wegen
    bereits vollständigem Publish ohnehin übersprungen werden könnte.

    Returns:
        Geparste ``SidecarSettings`` oder ``None``, wenn keine Sidecar
        vorhanden ist.
    """
    from familienfilm_manager.core.sidecar_manager import read_sidecar
    import tempfile
    from pathlib import Path

    video_ref = SourceRef(video_uri)
    sidecar_uri = video_ref.parent_uri()
    sidecar_name = f"{video_ref.stem}.settings.toml"
    if sidecar_uri.endswith(":"):
        sidecar_full_uri = f"{sidecar_uri}{sidecar_name}"
    else:
        sidecar_full_uri = f"{sidecar_uri.rstrip('/')}/{sidecar_name}"

    raw = rclone_cat(sidecar_full_uri, rclone_path=rclone_path)
    if raw is None:
        return None

    # rclone_cat liefert Bytes — in Tempfile schreiben und via read_sidecar parsen.
    # Wir könnten direkt parsen, aber so bleiben wir bei dem einen Parser.
    with tempfile.TemporaryDirectory() as td:
        td_path = Path(td)
        video_shadow = td_path / video_ref.name
        video_shadow.touch()  # read_sidecar leitet den Sidecar-Pfad aus Video ab
        sidecar_shadow = td_path / sidecar_name
        sidecar_shadow.write_bytes(raw)
        return read_sidecar(video_shadow)


def is_remote_video_already_published(
    video_uri: str,
    size_bytes: int,
    *,
    requires_web: bool = True,
    requires_local: bool = True,
    requires_archive: bool = True,
    rclone_path: str = "rclone",
) -> tuple[bool, str | None]:
    """Light-Peek Skip-Check für Remote-Quellen.

    Prüft (ohne das Video zu stagen):
    - Sidecar existiert und enthält die nötigen ``published_at``-Timestamps
      für alle aktiven Kanäle
    - Sidecar-``source_size_bytes`` stimmt mit aktueller Remote-Size überein

    Head-SHA1-Check entfällt bei Remote-Quellen (wir haben nur die ersten
    1 MB vom Video nach Staging — wäre kontraproduktiv).

    Returns:
        ``(skip_möglich, published_at_oder_None)``.
    """
    from familienfilm_manager.core.sidecar_manager import channel_needs_publish

    sidecar = peek_remote_sidecar(video_uri, rclone_path=rclone_path)
    if sidecar is None:
        return False, None

    # Sidecar-Opt-out für Web: wenn ``[web].enabled = false`` explizit gesetzt
    # ist, gilt Web nicht als aktiver Kanal — unabhängig vom Caller-Wert.
    if sidecar.web_enabled is False:
        requires_web = False

    # Legacy-Sidecar (nur [web].published_at) → Republish erzwingen
    if sidecar.is_legacy_pre_channels:
        return False, sidecar.web_published_at

    # Remote-Light-Peek: nur Size bekannt, kein head_sha1 verfügbar
    # (das Video ist noch nicht gestaged). ``channel_needs_publish`` akzeptiert
    # ``head_sha1=None`` und prüft dann nur die Size.
    current_fingerprint = (size_bytes, None)

    active_flags = {"web": requires_web, "local": requires_local, "archive": requires_archive}
    for channel, active in active_flags.items():
        if channel_needs_publish(
            sidecar, channel,
            active=active,
            current_fingerprint=current_fingerprint,
        ):
            return False, None

    timestamps = [
        ts for ts, active in [
            (sidecar.web_published_at, requires_web),
            (sidecar.local_published_at, requires_local),
            (sidecar.archive_published_at, requires_archive),
        ]
        if active and ts
    ]
    oldest = min(timestamps) if timestamps else None
    return True, oldest
