"""Whilly v4.0 — distributed task orchestrator (Postgres + FastAPI + remote workers)."""

__version__ = "4.5.0"
