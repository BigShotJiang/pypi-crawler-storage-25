from collections.abc import Iterator
from typing_extensions import override

class IDPropertyArray:
    """An array of values with a fixed type, supporting indexing and slicing."""

    typecode: object
    """The type of the data in the array {'f': float (32-bit), 'd': double (64-bit), 'i': int, 'b': bool}. Both 'f' and 'd' use Python's :class:`float` type but differ in storage precision."""

    def __delitem__(self, key: int | slice) -> None:
        """Delete self[key]."""

    def __getitem__(self, key: object, /) -> None:
        """Return self[key]."""

    def __len__(self) -> int:
        """Return len(self)."""

    def __setitem__(self, key: object, value: object, /) -> None:
        """Set self[key] to value."""

    def to_list(self) -> list[int] | list[float] | list[bool]:
        """Return the array as a list."""

    def __iter__(self) -> Iterator[object]: ...
    def __buffer__(self, flags: int, /) -> memoryview: ...

class IDPropertyGroup:
    """A dictionary-like group of ID properties, supporting key access, iteration, and membership testing."""

    name: object
    """The name of this Group."""

    def __contains__(self, key: object, /) -> bool:
        """Return bool(key in self)."""

    def __delitem__(self, key: int | slice) -> None:
        """Delete self[key]."""

    def __getitem__(self, key: object, /) -> None:
        """Return self[key]."""

    def __iter__(self) -> None:
        """Implement iter(self)."""

    def __len__(self) -> int:
        """Return len(self)."""

    def __setitem__(self, key: object, value: object, /) -> None:
        """Set self[key] to value."""

    def clear(self) -> None:
        """Clear all members from this group."""

    def get(self, key: str, default: object | None = None) -> object:
        """Return the value for key, if it exists, else default.

        :param key: The key to look up.
        """

    def items(self) -> object:
        """Return a view of the items in the group, behaves like dictionary method items."""

    def keys(self) -> object:
        """Return a view of the keys in the group."""

    def pop(self, key: str, default: object) -> object:
        """Remove an item from the group, returning a Python representation.

        :raises KeyError: When the item doesn't exist and no *default* is given.

        :param key: Name of item to remove.
        """

    def to_dict(self) -> dict[str, object]:
        """Return a purely Python version of the group."""

    def update(self, other: object | dict[str, object], /) -> None:
        """Update key-value pairs from *other*, overwriting existing keys.

        :param other: Updates the values in the group with this.
        """

    def values(self) -> object:
        """Return the values associated with this group."""

class IDPropertyGroupIterItems:
    """Iterator over :class:`IDPropertyGroup` items (key/value pairs)."""

    @override
    def __eq__(self, value: object, /) -> bool:
        """Return self==value."""

    def __ge__(self, value: object, /) -> bool:
        """Return self>=value."""

    def __gt__(self, value: object, /) -> bool:
        """Return self>value."""

    def __iter__(self) -> None:
        """Implement iter(self)."""

    def __le__(self, value: object, /) -> bool:
        """Return self<=value."""

    def __lt__(self, value: object, /) -> bool:
        """Return self<value."""

    @override
    def __ne__(self, value: object, /) -> bool:
        """Return self!=value."""

class IDPropertyGroupIterKeys:
    """Iterator over :class:`IDPropertyGroup` keys."""

    @override
    def __eq__(self, value: object, /) -> bool:
        """Return self==value."""

    def __ge__(self, value: object, /) -> bool:
        """Return self>=value."""

    def __gt__(self, value: object, /) -> bool:
        """Return self>value."""

    def __iter__(self) -> None:
        """Implement iter(self)."""

    def __le__(self, value: object, /) -> bool:
        """Return self<=value."""

    def __lt__(self, value: object, /) -> bool:
        """Return self<value."""

    @override
    def __ne__(self, value: object, /) -> bool:
        """Return self!=value."""

class IDPropertyGroupIterValues:
    """Iterator over :class:`IDPropertyGroup` values."""

    @override
    def __eq__(self, value: object, /) -> bool:
        """Return self==value."""

    def __ge__(self, value: object, /) -> bool:
        """Return self>=value."""

    def __gt__(self, value: object, /) -> bool:
        """Return self>value."""

    def __iter__(self) -> None:
        """Implement iter(self)."""

    def __le__(self, value: object, /) -> bool:
        """Return self<=value."""

    def __lt__(self, value: object, /) -> bool:
        """Return self<value."""

    @override
    def __ne__(self, value: object, /) -> bool:
        """Return self!=value."""

class IDPropertyGroupViewItems:
    """A view of :class:`IDPropertyGroup` items as key/value pairs (supports ``len()``, ``in``, iteration, and ``reversed()``)."""

    def __contains__(self, key: object, /) -> bool:
        """Return bool(key in self)."""

    @override
    def __eq__(self, value: object, /) -> bool:
        """Return self==value."""

    def __ge__(self, value: object, /) -> bool:
        """Return self>=value."""

    def __gt__(self, value: object, /) -> bool:
        """Return self>value."""

    def __iter__(self) -> None:
        """Implement iter(self)."""

    def __le__(self, value: object, /) -> bool:
        """Return self<=value."""

    def __len__(self) -> int:
        """Return len(self)."""

    def __lt__(self, value: object, /) -> bool:
        """Return self<value."""

    @override
    def __ne__(self, value: object, /) -> bool:
        """Return self!=value."""

class IDPropertyGroupViewKeys:
    """A view of :class:`IDPropertyGroup` keys (supports ``len()``, ``in``, iteration, and ``reversed()``)."""

    def __contains__(self, key: object, /) -> bool:
        """Return bool(key in self)."""

    @override
    def __eq__(self, value: object, /) -> bool:
        """Return self==value."""

    def __ge__(self, value: object, /) -> bool:
        """Return self>=value."""

    def __gt__(self, value: object, /) -> bool:
        """Return self>value."""

    def __iter__(self) -> None:
        """Implement iter(self)."""

    def __le__(self, value: object, /) -> bool:
        """Return self<=value."""

    def __len__(self) -> int:
        """Return len(self)."""

    def __lt__(self, value: object, /) -> bool:
        """Return self<value."""

    @override
    def __ne__(self, value: object, /) -> bool:
        """Return self!=value."""

class IDPropertyGroupViewValues:
    """A view of :class:`IDPropertyGroup` values (supports ``len()``, ``in``, iteration, and ``reversed()``)."""

    def __contains__(self, key: object, /) -> bool:
        """Return bool(key in self)."""

    @override
    def __eq__(self, value: object, /) -> bool:
        """Return self==value."""

    def __ge__(self, value: object, /) -> bool:
        """Return self>=value."""

    def __gt__(self, value: object, /) -> bool:
        """Return self>value."""

    def __iter__(self) -> None:
        """Implement iter(self)."""

    def __le__(self, value: object, /) -> bool:
        """Return self<=value."""

    def __len__(self) -> int:
        """Return len(self)."""

    def __lt__(self, value: object, /) -> bool:
        """Return self<value."""

    @override
    def __ne__(self, value: object, /) -> bool:
        """Return self!=value."""
