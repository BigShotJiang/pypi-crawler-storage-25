"""This module provides access to ID property types, used for
custom properties on data-blocks, accessed via ``["key"]`` syntax.

- See :ref:`info_quickstart-custom_properties` for example usage.
- See :ref:`bpy_types-custom_properties` for types that support custom properties."""

from . import types as types
