"""This module provides access to selection."""

def load_id(id: int, /) -> None:
    """Set the selection ID.

    :param id: Number (32-bit uint).
    """
