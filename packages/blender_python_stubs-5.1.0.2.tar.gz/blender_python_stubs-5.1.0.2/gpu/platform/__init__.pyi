"""This module provides access to GPU Platform definitions."""

def backend_type_get() -> str:
    """Get active GPU backend."""

def device_type_get() -> str:
    """Get GPU device type."""

def renderer_get() -> str:
    """Get GPU to be used for rendering."""

def vendor_get() -> str:
    """Get GPU vendor."""

def version_get() -> str:
    """Get GPU driver version."""
