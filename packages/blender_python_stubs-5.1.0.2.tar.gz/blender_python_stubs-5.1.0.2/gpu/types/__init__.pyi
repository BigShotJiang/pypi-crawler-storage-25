from collections.abc import Iterator
from collections.abc import Sequence
from typing import Literal
from typing import Self
import bpy.types
import mathutils

class Buffer:
    """.. class:: Buffer(format, dimensions, data)

    For Python access to GPU functions requiring a pointer.

    :param format: Format type to interpret the buffer.
       ``UINT_24_8`` is deprecated, use ``FLOAT`` instead.
    :type format: Literal['FLOAT', 'INT', 'UINT', 'UBYTE', 'UINT_24_8', '10_11_11_REV']
    :param dimensions: Array describing the dimensions.
    :type dimensions: int | Sequence[int]
    :param data: Optional data array.
    :type data: Buffer | Sequence[float] | Sequence[int]
    """

    dimensions: object

    def __init__(
        self,
        format: Literal["FLOAT", "INT", "UINT", "UBYTE", "UINT_24_8", "10_11_11_REV"],
        dimensions: int | Sequence[int],
        data: Buffer | Sequence[float] | Sequence[int],
    ) -> None: ...
    def __delitem__(self, key: int | slice) -> None:
        """Delete self[key]."""

    def __getitem__(self, key: object, /) -> None:
        """Return self[key]."""

    def __len__(self) -> int:
        """Return len(self)."""

    def __setitem__(self, key: object, value: object, /) -> None:
        """Set self[key] to value."""

    def to_list(self) -> list[object]:
        """Return the buffer as a list."""

    def __iter__(self) -> Iterator[object]: ...
    def __buffer__(self, flags: int, /) -> memoryview: ...

class GPUBatch:
    """.. class:: GPUBatch(type, buf, elem=None)

    Reusable container for drawable geometry.

    :param type: The primitive type of geometry to be drawn.
    :type type: Literal['POINTS', 'LINES', 'TRIS', 'LINE_STRIP', 'LINE_LOOP', 'TRI_STRIP', 'TRI_FAN', 'LINES_ADJ', 'TRIS_ADJ', 'LINE_STRIP_ADJ']
    :param buf: Vertex buffer containing all or some of the attributes required for drawing.
    :type buf: :class:`GPUVertBuf`
    :param elem: An optional index buffer.
    :type elem: :class:`GPUIndexBuf` | None
    """

    def __init__(
        self,
        type: Literal[
            "POINTS",
            "LINES",
            "TRIS",
            "LINE_STRIP",
            "LINE_LOOP",
            "TRI_STRIP",
            "TRI_FAN",
            "LINES_ADJ",
            "TRIS_ADJ",
            "LINE_STRIP_ADJ",
        ],
        buf: GPUVertBuf,
        elem: GPUIndexBuf | None = None,
    ) -> None: ...
    def draw(self, shader: GPUShader | None = None) -> None:
        """Run the drawing shader with the parameters assigned to the batch.

        :param shader: Shader that performs the drawing operations.
           If ``None`` is passed, the last shader set to this batch will run.
        """

    def draw_instanced(
        self, program: GPUShader, *, instance_start: int = 0, instance_count: int = 0
    ) -> None:
        """Draw multiple instances of the drawing program with the parameters assigned
        to the batch. In the vertex shader, ``gl_InstanceID`` will contain the instance
        number being drawn.

        :param program: Program that performs the drawing operations.
        """

    def draw_range(
        self, program: GPUShader, *, elem_start: int = 0, elem_count: int = 0
    ) -> None:
        """Run the drawing program with the parameters assigned to the batch. Only draw the ``elem_count`` elements of the index buffer starting at ``elem_start``.

        :param program: Program that performs the drawing operations.
        """

    def program_set(self, program: GPUShader, /) -> None:
        """Assign a shader to this batch that will be used for drawing when not overwritten later.
        Note: This method has to be called in the draw context that the batch will be drawn in.
        This function does not need to be called when you always
        set the shader when calling :meth:`GPUBatch.draw`.

        :param program: The program/shader the batch will use in future draw calls.
        """

    def vertbuf_add(self, buf: GPUVertBuf, /) -> None:
        """Add another vertex buffer to the Batch.
        It is not possible to add more vertices to the batch using this method.
        Instead it can be used to add more attributes to the existing vertices.
        A good use case would be when you have a separate
        vertex buffer for vertex positions and vertex normals.
        Current a batch can have at most GPU_BATCH_VBO_MAX_LEN vertex buffers.

        :param buf: The vertex buffer that will be added to the batch.
        """

class GPUFrameBuffer:
    """.. class:: GPUFrameBuffer(*, depth_slot=None, color_slots=None)

    This object gives access to framebuffer functionalities.
    When a 'layer' is specified in a argument, a single layer of a 3D or array texture is attached to the frame-buffer.
    For cube map textures, layer is translated into a cube map face.

    :param depth_slot: GPUTexture to attach or a ``dict`` containing keywords: 'texture', 'layer' and 'mip'.
    :type depth_slot: :class:`GPUTexture` | dict[str, int | :class:`GPUTexture`] | None
    :param color_slots: Tuple where each item can be a GPUTexture or a ``dict`` containing keywords: 'texture', 'layer' and 'mip'.
    :type color_slots: :class:`GPUTexture` | dict[str, int | :class:`GPUTexture`] | Sequence[:class:`GPUTexture` | dict[str, int | :class:`GPUTexture`]] | None
    """

    is_bound: object
    """Checks if this is the active frame-buffer in the context."""

    def __init__(
        self,
        *,
        depth_slot: GPUTexture | dict[str, int | GPUTexture] | None = None,
        color_slots: (
            GPUTexture
            | dict[str, int | GPUTexture]
            | Sequence[GPUTexture | dict[str, int | GPUTexture]]
            | None
        ) = None,
    ) -> None: ...
    def bind(self) -> None:
        """Context manager to ensure balanced bind calls, even in the case of an error."""

    def clear(
        self,
        *,
        color: Sequence[float] | None = None,
        depth: float | None = None,
        stencil: int | None = None,
    ) -> None:
        """Fill color, depth and stencil textures with specific value.
        Common values: color=(0.0, 0.0, 0.0, 1.0), depth=1.0, stencil=0.

        :param color: Sequence of 3 or 4 floats representing ``(r, g, b, a)``.
        """

    def read_color(
        self,
        x: int,
        y: int,
        xsize: int,
        ysize: int,
        channels: int,
        slot: int,
        format: Literal["FLOAT", "INT", "UINT", "UBYTE", "UINT_24_8", "10_11_11_REV"],
        *,
        data: Buffer | None = None,
    ) -> Buffer:
        """Read a block of pixels from the frame buffer.

        :param x: Lower left corner x of a rectangular block of pixels.
        """

    def read_depth(
        self, x: int, y: int, xsize: int, ysize: int, *, data: Buffer | None = None
    ) -> Buffer:
        """Read a pixel depth block from the frame buffer.

        :param x: Lower left corner x of a rectangular block of pixels.
        """

    def viewport_get(self) -> tuple[int, int, int, int]:
        """Returns position and dimension to current viewport."""

    def viewport_set(self, x: int, y: int, xsize: int, ysize: int) -> None:
        """Set the viewport for this framebuffer object.
        Note: The viewport state is not saved upon framebuffer rebind.

        :param x: Lower left corner x of the viewport rectangle, in pixels.
        """

class GPUIndexBuf:
    """.. class:: GPUIndexBuf(type, seq)

    Contains an index buffer.

    :param type: The primitive type this index buffer is composed of.
    :type type: Literal['POINTS', 'LINES', 'TRIS', 'LINES_ADJ', 'TRIS_ADJ']
    :param seq: Indices this index buffer will contain.
       Whether a 1D or 2D sequence is required depends on the type.
       Optionally the sequence can support the buffer protocol.
    :type seq: Buffer | Sequence[int] | Sequence[Sequence[int]]
    """

    def __init__(
        self,
        type: Literal["POINTS", "LINES", "TRIS", "LINES_ADJ", "TRIS_ADJ"],
        seq: Buffer | Sequence[int] | Sequence[Sequence[int]],
    ) -> None: ...

class GPUOffScreen:
    """.. class:: GPUOffScreen(width, height, *, format='RGBA8')

    This object gives access to off screen buffers.

    :param width: Horizontal dimension of the buffer.
    :type width: int
    :param height: Vertical dimension of the buffer.
    :type height: int
    :param format: Internal data format inside GPU memory for color attachment texture.
    :type format: Literal['RGBA8', 'RGBA16', 'RGBA16F', 'RGBA32F']
    """

    height: int
    """Height of the texture.

:type: int"""

    texture_color: GPUTexture
    """The color texture attached.

:type: :class:`GPUTexture`"""

    width: int
    """Width of the texture.

:type: int"""

    def __init__(
        self,
        width: int,
        height: int,
        *,
        format: Literal["RGBA8", "RGBA16", "RGBA16F", "RGBA32F"] = "RGBA8",
    ) -> None: ...
    def bind(self) -> OffScreenStackContext:
        """Context manager to ensure balanced bind calls, even in the case of an error."""

    def draw_view3d(
        self,
        scene: bpy.types.Scene,
        view_layer: bpy.types.ViewLayer,
        view3d: bpy.types.SpaceView3D,
        region: bpy.types.Region,
        view_matrix: mathutils.Matrix,
        projection_matrix: mathutils.Matrix,
        *,
        do_color_management: bool = False,
        draw_background: bool = True,
    ) -> None:
        """Draw the 3d viewport in the offscreen object.

        :param scene: Scene to draw.
        """

    def free(self) -> None:
        """Free the offscreen object.
        The framebuffer, texture and render objects will no longer be accessible.
        """

    def unbind(self, *, restore: bool = True) -> None:
        """Unbind the offscreen object.

        :param restore: Restore the OpenGL state, can only be used when the state has been saved before.
        """

class GPUShader:
    @property
    def name(self) -> str:
        """The name of the shader object for debugging purposes (read-only).

        :type: str"""

    @property
    def program(self) -> int:
        """The name of the program object for use by the OpenGL API (read-only).
        This is deprecated and will always return -1.

        :type: int"""

    def attr_from_name(self, name: str, /) -> int:
        """Get attribute location by name.

        :param name: The name of the attribute variable whose location is to be queried.
        """

    def attrs_info_get(self) -> tuple[tuple[str, str | None], ...]:
        """Information about the attributes used in the Shader."""

    def bind(self) -> None:
        """Bind the shader object. Required to be able to change uniforms of this shader."""

    def format_calc(self) -> GPUVertFormat:
        """Build a new format based on the attributes of the shader."""

    def image(self, name: str, texture: GPUTexture) -> None:
        """Specify the value of an image variable for the current GPUShader.

        :param name: Name of the image variable to which the texture is to be bound.
        """

    def uniform_block(self, name: str, ubo: GPUUniformBuf) -> None:
        """Specify the value of a uniform buffer object variable for the current GPUShader.

        :param name: Name of the uniform variable whose UBO is to be specified.
        """

    def uniform_block_from_name(self, name: str, /) -> int:
        """Get uniform block location by name.

        :param name: Name of the uniform block variable whose location is to be queried.
        """

    def uniform_bool(self, name: str, value: bool | Sequence[bool]) -> None:
        """Specify the value of a uniform variable for the current program object.

        :param name: Name of the uniform variable whose value is to be changed.
        """

    def uniform_float(
        self,
        name: str,
        value: (
            float
            | int
            | Sequence[float]
            | mathutils.Matrix
            | mathutils.Vector
            | mathutils.Euler
            | mathutils.Quaternion
            | mathutils.Color
        ),
    ) -> None:
        """Specify the value of a uniform variable for the current program object.

        :param name: Name of the uniform variable whose value is to be changed.
        """

    def uniform_from_name(self, name: str, /) -> int:
        """Get uniform location by name.

        :param name: Name of the uniform variable whose location is to be queried.
        """

    def uniform_int(self, name: str, seq: int | Sequence[int]) -> None:
        """Specify the value of a uniform variable for the current program object.

        :param name: Name of the uniform variable whose value is to be changed.
        """

    def uniform_sampler(self, name: str, texture: GPUTexture) -> None:
        """Specify the value of a texture uniform variable for the current GPUShader.

        :param name: Name of the uniform variable whose texture is to be specified.
        """

    def uniform_vector_float(
        self, location: int, buffer: Sequence[float], length: int, count: int
    ) -> None:
        """Set the buffer to fill the uniform.

        :param location: Location of the uniform variable to be modified.
        """

    def uniform_vector_int(
        self, location: int, buffer: Buffer, length: int, count: int
    ) -> None:
        """Set the buffer to fill the uniform.

        :param location: Location of the uniform variable to be modified.
        """

class GPUShaderCreateInfo:
    """.. class:: GPUShaderCreateInfo()

    Stores and describes types and variables that are used in shader sources.
    """

    def compute_source(self, source: str, /) -> None:
        """compute shader source code written in GLSL.

        Example:

        :param source: The compute shader source code.
        """

    def define(self, name: str, value: str) -> None:
        """Add a preprocessing define directive. In GLSL it would be something like:

        :param name: Token name.
        """

    def depth_write(
        self, value: Literal["UNCHANGED", "ANY", "GREATER", "LESS"], /
    ) -> None:
        """Specify a depth write behavior when modifying gl_FragDepth.

        There is a common optimization for GPUs that relies on an early depth
        test to be run before the fragment shader so that the shader evaluation
        can be skipped if the fragment ends up being discarded because it is occluded.

        This optimization does not affect the final rendering, and is typically
        possible when the fragment does not change the depth programmatically.
        There is, however, a class of operations on the depth in the shader which
        could still be performed while allowing the early depth test to operate.

        This function alters the behavior of the optimization to allow those operations
        to be performed.

        :param value: Depth write value.
           :UNCHANGED: disables depth write in a fragment shader and execution of the fragments can be optimized away.
           :ANY: enables depth write in a fragment shader for any fragments
           :GREATER: enables depth write in a fragment shader for depth values that are greater than the depth value in the output buffer.
           :LESS: enables depth write in a fragment shader for depth values that are less than the depth value in the output buffer.
        """

    def fragment_out(
        self,
        slot: int,
        type: Literal[
            "FLOAT",
            "VEC2",
            "VEC3",
            "VEC4",
            "MAT3",
            "MAT4",
            "UINT",
            "UVEC2",
            "UVEC3",
            "UVEC4",
            "INT",
            "IVEC2",
            "IVEC3",
            "IVEC4",
            "BOOL",
        ],
        name: str,
        *,
        blend: Literal["NONE", "SRC_0", "SRC_1"] = "NONE",
    ) -> None:
        """Specify a fragment output corresponding to a framebuffer target slot.

        :param slot: The attribute index.
        """

    def fragment_source(self, source: str, /) -> None:
        """Fragment shader source code written in GLSL.

        Example:

        :param source: The fragment shader source code.
        """

    def image(
        self,
        slot: int,
        format: Literal[
            "RGBA8UI",
            "RGBA8I",
            "RGBA8",
            "RGBA32UI",
            "RGBA32I",
            "RGBA32F",
            "RGBA16UI",
            "RGBA16I",
            "RGBA16F",
            "RGBA16",
            "RG8UI",
            "RG8I",
            "RG8",
            "RG32UI",
            "RG32I",
            "RG32F",
            "RG16UI",
            "RG16I",
            "RG16F",
            "RG16",
            "R8UI",
            "R8I",
            "R8",
            "R32UI",
            "R32I",
            "R32F",
            "R16UI",
            "R16I",
            "R16F",
            "R16",
            "R11F_G11F_B10F",
            "DEPTH32F_STENCIL8",
            "DEPTH24_STENCIL8",
            "SRGB8_A8",
            "RGB16F",
            "SRGB8_A8_DXT1",
            "SRGB8_A8_DXT3",
            "SRGB8_A8_DXT5",
            "RGBA8_DXT1",
            "RGBA8_DXT3",
            "RGBA8_DXT5",
            "DEPTH_COMPONENT32F",
            "DEPTH_COMPONENT24",
            "DEPTH_COMPONENT16",
        ],
        type: Literal[
            "FLOAT_BUFFER",
            "FLOAT_1D",
            "FLOAT_1D_ARRAY",
            "FLOAT_2D",
            "FLOAT_2D_ARRAY",
            "FLOAT_3D",
            "FLOAT_CUBE",
            "FLOAT_CUBE_ARRAY",
            "INT_BUFFER",
            "INT_1D",
            "INT_1D_ARRAY",
            "INT_2D",
            "INT_2D_ARRAY",
            "INT_3D",
            "INT_CUBE",
            "INT_CUBE_ARRAY",
            "UINT_BUFFER",
            "UINT_1D",
            "UINT_1D_ARRAY",
            "UINT_2D",
            "UINT_2D_ARRAY",
            "UINT_3D",
            "UINT_CUBE",
            "UINT_CUBE_ARRAY",
            "SHADOW_2D",
            "SHADOW_2D_ARRAY",
            "SHADOW_CUBE",
            "SHADOW_CUBE_ARRAY",
            "DEPTH_2D",
            "DEPTH_2D_ARRAY",
            "DEPTH_CUBE",
            "DEPTH_CUBE_ARRAY",
        ],
        name: str,
        *,
        qualifiers: set[Literal["NO_RESTRICT", "READ", "WRITE"]] = ...,
    ) -> None:
        """Specify an image resource used for arbitrary load and store operations.

        :param slot: The image resource index.
        """

    def local_group_size(self, x: int, y: int = 1, z: int = 1) -> None:
        """Specify the local group size for compute shaders.

        :param x: The local group size in the x dimension.
        """

    def push_constant(
        self,
        type: Literal[
            "FLOAT",
            "VEC2",
            "VEC3",
            "VEC4",
            "MAT3",
            "MAT4",
            "UINT",
            "UVEC2",
            "UVEC3",
            "UVEC4",
            "INT",
            "IVEC2",
            "IVEC3",
            "IVEC4",
            "BOOL",
        ],
        name: str,
        size: int = 0,
    ) -> None:
        """Specify a global access constant.

        :param type: The data type of the constant.
        """

    def sampler(
        self,
        slot: int,
        type: Literal[
            "FLOAT_BUFFER",
            "FLOAT_1D",
            "FLOAT_1D_ARRAY",
            "FLOAT_2D",
            "FLOAT_2D_ARRAY",
            "FLOAT_3D",
            "FLOAT_CUBE",
            "FLOAT_CUBE_ARRAY",
            "INT_BUFFER",
            "INT_1D",
            "INT_1D_ARRAY",
            "INT_2D",
            "INT_2D_ARRAY",
            "INT_3D",
            "INT_CUBE",
            "INT_CUBE_ARRAY",
            "UINT_BUFFER",
            "UINT_1D",
            "UINT_1D_ARRAY",
            "UINT_2D",
            "UINT_2D_ARRAY",
            "UINT_3D",
            "UINT_CUBE",
            "UINT_CUBE_ARRAY",
            "SHADOW_2D",
            "SHADOW_2D_ARRAY",
            "SHADOW_CUBE",
            "SHADOW_CUBE_ARRAY",
            "DEPTH_2D",
            "DEPTH_2D_ARRAY",
            "DEPTH_CUBE",
            "DEPTH_CUBE_ARRAY",
        ],
        name: str,
    ) -> None:
        """Specify an image texture sampler.

        :param slot: The image texture sampler index.
        """

    def typedef_source(self, source: str, /) -> None:
        """Source code included before resource declaration. Useful for defining structs used by Uniform Buffers.

        Example:

        :param source: The source code defining types.
        """

    def uniform_buf(self, slot: int, type_name: str, name: str) -> None:
        """Specify a uniform variable whose type can be one of those declared in :meth:`GPUShaderCreateInfo.typedef_source`.

        :param slot: The uniform variable index.
        """

    def vertex_in(
        self,
        slot: int,
        type: Literal[
            "FLOAT",
            "VEC2",
            "VEC3",
            "VEC4",
            "MAT3",
            "MAT4",
            "UINT",
            "UVEC2",
            "UVEC3",
            "UVEC4",
            "INT",
            "IVEC2",
            "IVEC3",
            "IVEC4",
            "BOOL",
        ],
        name: str,
    ) -> None:
        """Add a vertex shader input attribute.

        :param slot: The attribute index.
        """

    def vertex_out(self, interface: GPUStageInterfaceInfo, /) -> None:
        """Add a vertex shader output interface block.

        :param interface: Object describing the block.
        """

    def vertex_source(self, source: str, /) -> None:
        """Vertex shader source code written in GLSL.

        Example:

        :param source: The vertex shader source code.
        """

class GPUStageInterfaceInfo:
    """.. class:: GPUStageInterfaceInfo(name)

    List of varyings between shader stages.

    :param name: Name of the interface block.
    :type name: str
    """

    name: str
    """Name of the interface block.

:type: str"""

    def __init__(self, name: str) -> None: ...
    def flat(
        self,
        type: Literal[
            "FLOAT",
            "VEC2",
            "VEC3",
            "VEC4",
            "MAT3",
            "MAT4",
            "UINT",
            "UVEC2",
            "UVEC3",
            "UVEC4",
            "INT",
            "IVEC2",
            "IVEC3",
            "IVEC4",
            "BOOL",
        ],
        name: str,
    ) -> None:
        """Add an attribute with qualifier of type ``flat`` to the interface block.

        :param type: The data type of the attribute.
        """

    def no_perspective(
        self,
        type: Literal[
            "FLOAT",
            "VEC2",
            "VEC3",
            "VEC4",
            "MAT3",
            "MAT4",
            "UINT",
            "UVEC2",
            "UVEC3",
            "UVEC4",
            "INT",
            "IVEC2",
            "IVEC3",
            "IVEC4",
            "BOOL",
        ],
        name: str,
    ) -> None:
        """Add an attribute with qualifier of type ``no_perspective`` to the interface block.

        :param type: The data type of the attribute.
        """

    def smooth(
        self,
        type: Literal[
            "FLOAT",
            "VEC2",
            "VEC3",
            "VEC4",
            "MAT3",
            "MAT4",
            "UINT",
            "UVEC2",
            "UVEC3",
            "UVEC4",
            "INT",
            "IVEC2",
            "IVEC3",
            "IVEC4",
            "BOOL",
        ],
        name: str,
    ) -> None:
        """Add an attribute with qualifier of type *smooth* to the interface block.

        :param type: The data type of the attribute.
        """

class GPUTexture:
    """.. class:: GPUTexture(size, *, layers=0, is_cubemap=False, format='RGBA8', data=None)

    This object gives access to GPU textures.

    :param size: Dimensions of the texture 1D, 2D, 3D or cubemap.
    :type size: int | Sequence[int]
    :param layers: Number of layers in texture array or number of cubemaps in cubemap array
    :type layers: int
    :param is_cubemap: Indicates the creation of a cubemap texture.
    :type is_cubemap: bool
    :param format: Internal data format inside GPU memory.
       ``DEPTH24_STENCIL8`` is deprecated, use ``DEPTH32F_STENCIL8``.
       ``DEPTH_COMPONENT24`` is deprecated, use ``DEPTH_COMPONENT32F``.
    :type format: Literal['RGBA8UI', 'RGBA8I', 'RGBA8', 'RGBA32UI', 'RGBA32I', 'RGBA32F', 'RGBA16UI', 'RGBA16I', 'RGBA16F', 'RGBA16', 'RG8UI', 'RG8I', 'RG8', 'RG32UI', 'RG32I', 'RG32F', 'RG16UI', 'RG16I', 'RG16F', 'RG16', 'R8UI', 'R8I', 'R8', 'R32UI', 'R32I', 'R32F', 'R16UI', 'R16I', 'R16F', 'R16', 'R11F_G11F_B10F', 'DEPTH32F_STENCIL8', 'DEPTH24_STENCIL8', 'SRGB8_A8', 'RGB16F', 'SRGB8_A8_DXT1', 'SRGB8_A8_DXT3', 'SRGB8_A8_DXT5', 'RGBA8_DXT1', 'RGBA8_DXT3', 'RGBA8_DXT5', 'DEPTH_COMPONENT32F', 'DEPTH_COMPONENT24', 'DEPTH_COMPONENT16']
    :param data: Buffer object to fill the texture.
    :type data: :class:`Buffer` | None
    """

    format: str
    """Format of the texture.

:type: str"""

    height: int
    """Height of the texture.

:type: int"""

    width: int
    """Width of the texture.

:type: int"""

    def __init__(
        self,
        size: int | Sequence[int],
        *,
        layers: int = 0,
        is_cubemap: bool = False,
        format: Literal[
            "RGBA8UI",
            "RGBA8I",
            "RGBA8",
            "RGBA32UI",
            "RGBA32I",
            "RGBA32F",
            "RGBA16UI",
            "RGBA16I",
            "RGBA16F",
            "RGBA16",
            "RG8UI",
            "RG8I",
            "RG8",
            "RG32UI",
            "RG32I",
            "RG32F",
            "RG16UI",
            "RG16I",
            "RG16F",
            "RG16",
            "R8UI",
            "R8I",
            "R8",
            "R32UI",
            "R32I",
            "R32F",
            "R16UI",
            "R16I",
            "R16F",
            "R16",
            "R11F_G11F_B10F",
            "DEPTH32F_STENCIL8",
            "DEPTH24_STENCIL8",
            "SRGB8_A8",
            "RGB16F",
            "SRGB8_A8_DXT1",
            "SRGB8_A8_DXT3",
            "SRGB8_A8_DXT5",
            "RGBA8_DXT1",
            "RGBA8_DXT3",
            "RGBA8_DXT5",
            "DEPTH_COMPONENT32F",
            "DEPTH_COMPONENT24",
            "DEPTH_COMPONENT16",
        ] = "RGBA8",
        data: Buffer | None = None,
    ) -> None: ...
    def anisotropic_filter(self, use_anisotropic: bool, /) -> None:
        """Set anisotropic filter usage. This only has effect if mipmapping is enabled.

        :param use_anisotropic: If set to true, the texture will use anisotropic filtering.
        """

    def clear(
        self,
        format: Literal[
            "FLOAT", "INT", "UINT", "UBYTE", "UINT_24_8", "10_11_11_REV"
        ] = "FLOAT",
        value: Sequence[float] | Sequence[int] = ...,
    ) -> None:
        """Fill texture with specific value.

        :param format: The format that describes the content of a single item.
           ``UINT_24_8`` is deprecated, use ``FLOAT`` instead.
        """

    def extend_mode(
        self,
        extend_mode: Literal["EXTEND", "REPEAT", "MIRRORED_REPEAT", "CLAMP_TO_BORDER"],
        /,
    ) -> None:
        """Set texture sampling method for coordinates outside of the [0..1] uv range along
        both the x and y axis.

        :param extend_mode: the specified extent mode.
        """

    def extend_mode_x(
        self,
        extend_mode: Literal["EXTEND", "REPEAT", "MIRRORED_REPEAT", "CLAMP_TO_BORDER"],
        /,
    ) -> None:
        """Set texture sampling method for coordinates outside of the [0..1] uv range along the x axis.

        :param extend_mode: the specified extent mode.
        """

    def extend_mode_y(
        self,
        extend_mode: Literal["EXTEND", "REPEAT", "MIRRORED_REPEAT", "CLAMP_TO_BORDER"],
        /,
    ) -> None:
        """Set texture sampling method for coordinates outside of the [0..1] uv range along the y axis.

        :param extend_mode: the specified extent mode.
        """

    def filter_mode(self, use_filter: bool, /) -> None:
        """Set texture filter usage.

        :param use_filter: If set to true, the texture will use linear interpolation between neighboring texels.
        """

    def mipmap_mode(self, use_mipmap: bool = True, use_filter: bool = True) -> None:
        """Set texture filter and mip-map usage.

        :param use_mipmap: If set to true, the texture will use mip-mapping as anti-aliasing method.
        """

    def read(self) -> Buffer:
        """Creates a buffer with the value of all pixels."""

class GPUUniformBuf:
    """.. class:: GPUUniformBuf(data)

    This object gives access to uniform buffers.

    :param data: Data to fill the buffer.
    :type data: Buffer
    """

    def __init__(self, data: Buffer) -> None: ...
    def update(self, data: Buffer, /) -> None:
        """Update the data of the uniform buffer object.

        :param data: Data to fill the buffer.
        """

class GPUVertBuf:
    """.. class:: GPUVertBuf(format, len)

    Contains a VBO.

    :param format: Vertex format.
    :type format: :class:`GPUVertFormat`
    :param len: Amount of vertices that will fit into this buffer.
    :type len: int
    """

    def __init__(self, format: GPUVertFormat, len: int) -> None: ...
    def attr_fill(
        self,
        id: int | str,
        data: (
            Buffer
            | Sequence[float]
            | Sequence[int]
            | Sequence[Sequence[float]]
            | Sequence[Sequence[int]]
        ),
    ) -> None:
        """Insert data into the buffer for a single attribute.

        :param id: Either the name or the id of the attribute.
        """

class GPUVertFormat:
    """.. class:: GPUVertFormat()

    This object contains information about the structure of a vertex buffer.
    """

    def attr_add(
        self,
        id: str,
        comp_type: Literal["I8", "U8", "I16", "U16", "I32", "U32", "F32", "I10"],
        len: int,
        fetch_mode: Literal["FLOAT", "INT", "INT_TO_FLOAT_UNIT"],
    ) -> None:
        """Add a new attribute to the format.

        :param id: Name of the attribute. Often ``position``, ``normal``, ...
        """

class MatrixStackContext:
    """Context manager for matrix stack push/pop."""

    def __enter__(self) -> Self: ...
    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None: ...

class OffScreenStackContext:
    """Context manager for off-screen framebuffer binding."""

    def __enter__(self) -> Self: ...
    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None: ...
