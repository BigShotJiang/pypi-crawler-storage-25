"""This module provides Python wrappers for the GPU implementation in Blender.
Some higher level functions can be found in the :mod:`gpu_extras` module."""

from . import capabilities as capabilities
from . import compute as compute
from . import matrix as matrix
from . import platform as platform
from . import select as select
from . import shader as shader
from . import state as state
from . import texture as texture
from . import types as types
