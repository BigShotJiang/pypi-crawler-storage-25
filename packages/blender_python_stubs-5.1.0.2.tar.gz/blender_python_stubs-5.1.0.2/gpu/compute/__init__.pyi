"""This module provides access to the global GPU compute functions."""

import gpu.types

def dispatch(
    shader: gpu.types.GPUShader, groups_x_len: int, groups_y_len: int, groups_z_len: int
) -> None:
    """Dispatches GPU compute.

    :param shader: The shader that you want to dispatch.
    """
