"""This module provides access to bmesh geometry evaluation functions."""

from collections.abc import Sequence
import bmesh
import bmesh.types

def intersect_face_point(
    face: bmesh.types.BMFace, point: tuple[float, float, float] | Sequence[float]
) -> bool:
    """Tests if the projection of a point is inside a face (using the face's normal).

    :param face: The face to test.
    """
