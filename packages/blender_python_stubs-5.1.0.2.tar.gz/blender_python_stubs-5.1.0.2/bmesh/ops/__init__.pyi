"""Access to BMesh operators."""

def average_vert_facedata(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.average_vert_facedata(bmesh, verts=[])
    -> dict()
    """

def beautify_fill(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.beautify_fill(bmesh, faces=[], edges=[], use_restrict_tag=False, method='AREA')
    -> dict(geom=[])
    """

def bevel(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.bevel(bmesh, geom=[], offset=0.0, offset_type='OFFSET', profile_type='SUPERELLIPSE', segments=0, profile=0.0, affect='VERTICES', clamp_overlap=False, material=0, loop_slide=False, mark_seam=False, mark_sharp=False, harden_normals=False, face_strength_mode='NONE', miter_outer='SHARP', miter_inner='SHARP', spread=0.0, custom_profile=None, vmesh_method='ADJ')
    -> dict(faces=[], edges=[], verts=[])
    """

def bisect_edges(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.bisect_edges(bmesh, edges=[], cuts=0, edge_percents={})
    -> dict(geom_split=[])
    """

def bisect_plane(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.bisect_plane(bmesh, geom=[], dist=0.0, plane_co=Vector(), plane_no=Vector(), use_snap_center=False, clear_outer=False, clear_inner=False)
    -> dict(geom_cut=[], geom=[])
    """

def bmesh_to_mesh(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.bmesh_to_mesh(bmesh, mesh=None, object=None)
    -> dict()
    """

def bridge_loops(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.bridge_loops(bmesh, edges=[], use_pairs=False, use_cyclic=False, use_merge=False, merge_factor=0.0, twist_offset=0)
    -> dict(faces=[], edges=[])
    """

def collapse(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.collapse(bmesh, edges=[], uvs=False)
    -> dict()
    """

def collapse_uvs(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.collapse_uvs(bmesh, edges=[])
    -> dict()
    """

def connect_vert_pair(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.connect_vert_pair(bmesh, verts=[], verts_exclude=[], faces_exclude=[])
    -> dict(edges=[])
    """

def connect_verts(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.connect_verts(bmesh, verts=[], faces_exclude=[], check_degenerate=False)
    -> dict(edges=[])
    """

def connect_verts_concave(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.connect_verts_concave(bmesh, faces=[])
    -> dict(edges=[], faces=[])
    """

def connect_verts_nonplanar(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.connect_verts_nonplanar(bmesh, angle_limit=0.0, faces=[])
    -> dict(edges=[], faces=[])
    """

def contextual_create(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.contextual_create(bmesh, geom=[], mat_nr=0, use_smooth=False)
    -> dict(faces=[], edges=[])
    """

def convex_hull(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.convex_hull(bmesh, input=[], use_existing_faces=False)
    -> dict(geom=[], geom_interior=[], geom_unused=[], geom_holes=[])
    """

def create_circle(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.create_circle(bmesh, cap_ends=False, cap_tris=False, segments=0, radius=0.0, matrix=Matrix(), calc_uvs=False)
    -> dict(verts=[])
    """

def create_cone(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.create_cone(bmesh, cap_ends=False, cap_tris=False, segments=0, radius1=0.0, radius2=0.0, depth=0.0, matrix=Matrix(), calc_uvs=False)
    -> dict(verts=[])
    """

def create_cube(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.create_cube(bmesh, size=0.0, matrix=Matrix(), calc_uvs=False)
    -> dict(verts=[])
    """

def create_grid(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.create_grid(bmesh, x_segments=0, y_segments=0, size=0.0, matrix=Matrix(), calc_uvs=False)
    -> dict(verts=[])
    """

def create_icosphere(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.create_icosphere(bmesh, subdivisions=0, radius=0.0, matrix=Matrix(), calc_uvs=False)
    -> dict(verts=[])
    """

def create_monkey(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.create_monkey(bmesh, matrix=Matrix(), calc_uvs=False)
    -> dict(verts=[])
    """

def create_uvsphere(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.create_uvsphere(bmesh, u_segments=0, v_segments=0, radius=0.0, matrix=Matrix(), calc_uvs=False)
    -> dict(verts=[])
    """

def create_vert(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.create_vert(bmesh, co=Vector())
    -> dict(vert=[])
    """

def delete(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.delete(bmesh, geom=[], context='VERTS')
    -> dict()
    """

def dissolve_degenerate(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.dissolve_degenerate(bmesh, dist=0.0, edges=[])
    -> dict()
    """

def dissolve_edges(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.dissolve_edges(bmesh, edges=[], use_verts=False, use_face_split=False, angle_threshold=0.0)
    -> dict(region=[])
    """

def dissolve_faces(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.dissolve_faces(bmesh, faces=[], use_verts=False)
    -> dict(region=[])
    """

def dissolve_limit(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.dissolve_limit(bmesh, angle_limit=0.0, use_dissolve_boundaries=False, verts=[], edges=[], delimit={})
    -> dict(region=[])
    """

def dissolve_verts(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.dissolve_verts(bmesh, verts=[], use_face_split=False, use_boundary_tear=False)
    -> dict()
    """

def duplicate(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.duplicate(bmesh, geom=[], dest=None, use_select_history=False, use_edge_flip_from_face=False)
    -> dict(geom_orig=[], geom=[], vert_map={}, edge_map={}, face_map={}, boundary_map={}, isovert_map={})
    """

def edgeloop_fill(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.edgeloop_fill(bmesh, edges=[], mat_nr=0, use_smooth=False)
    -> dict(faces=[])
    """

def edgenet_fill(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.edgenet_fill(bmesh, edges=[], mat_nr=0, use_smooth=False, sides=0)
    -> dict(faces=[])
    """

def edgenet_prepare(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.edgenet_prepare(bmesh, edges=[])
    -> dict(edges=[])
    """

def extrude_discrete_faces(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.extrude_discrete_faces(bmesh, faces=[], use_normal_flip=False, use_select_history=False)
    -> dict(faces=[])
    """

def extrude_edge_only(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.extrude_edge_only(bmesh, edges=[], use_normal_flip=False, use_select_history=False)
    -> dict(geom=[])
    """

def extrude_face_region(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.extrude_face_region(bmesh, geom=[], edges_exclude={}, use_keep_orig=False, use_normal_flip=False, use_normal_from_adjacent=False, use_dissolve_ortho_edges=False, use_select_history=False, skip_input_flip=False)
    -> dict(geom=[])
    """

def extrude_vert_indiv(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.extrude_vert_indiv(bmesh, verts=[], use_select_history=False)
    -> dict(edges=[], verts=[])
    """

def face_attribute_fill(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.face_attribute_fill(bmesh, faces=[], use_normals=False, use_data=False)
    -> dict(faces_fail=[])
    """

def find_doubles(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.find_doubles(bmesh, verts=[], keep_verts=[], use_connected=False, dist=0.0)
    -> dict(targetmap={})
    """

def flip_quad_tessellation(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.flip_quad_tessellation(bmesh, faces=[])
    -> dict()
    """

def grid_fill(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.grid_fill(bmesh, edges=[], mat_nr=0, use_smooth=False, use_interp_simple=False)
    -> dict(faces=[])
    """

def holes_fill(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.holes_fill(bmesh, edges=[], sides=0)
    -> dict(faces=[])
    """

def inset_individual(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.inset_individual(bmesh, faces=[], thickness=0.0, depth=0.0, use_even_offset=False, use_interpolate=False, use_relative_offset=False)
    -> dict(faces=[])
    """

def inset_region(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.inset_region(bmesh, faces=[], faces_exclude=[], use_boundary=False, use_even_offset=False, use_interpolate=False, use_relative_offset=False, use_edge_rail=False, thickness=0.0, depth=0.0, use_outset=False)
    -> dict(faces=[])
    """

def join_triangles(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.join_triangles(bmesh, faces=[], cmp_seam=False, cmp_sharp=False, cmp_uvs=False, cmp_vcols=False, cmp_materials=False, angle_face_threshold=0.0, angle_shape_threshold=0.0, topology_influence=0.0, deselect_joined=False)
    -> dict(faces=[])
    """

def mesh_to_bmesh(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.mesh_to_bmesh(bmesh, mesh=None, object=None, use_shapekey=False)
    -> dict()
    """

def mirror(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.mirror(bmesh, geom=[], matrix=Matrix(), merge_dist=0.0, axis='X', mirror_u=False, mirror_v=False, mirror_udim=False, use_shapekey=False)
    -> dict(geom=[])
    """

def object_load_bmesh(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.object_load_bmesh(bmesh, scene=None, object=None)
    -> dict()
    """

def offset_edgeloops(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.offset_edgeloops(bmesh, edges=[], use_cap_endpoint=False)
    -> dict(edges=[])
    """

def planar_faces(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.planar_faces(bmesh, faces=[], iterations=0, factor=0.0)
    -> dict(geom=[])
    """

def pointmerge(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.pointmerge(bmesh, verts=[], merge_co=Vector())
    -> dict()
    """

def pointmerge_facedata(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.pointmerge_facedata(bmesh, verts=[], vert_snap=None)
    -> dict()
    """

def poke(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.poke(bmesh, faces=[], offset=0.0, center_mode='MEAN_WEIGHTED', use_relative_offset=False)
    -> dict(verts=[], faces=[])
    """

def recalc_face_normals(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.recalc_face_normals(bmesh, faces=[])
    -> dict()
    """

def region_extend(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.region_extend(bmesh, geom=[], use_contract=False, use_faces=False, use_face_step=False)
    -> dict(geom=[])
    """

def remove_doubles(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.remove_doubles(bmesh, verts=[], use_connected=False, dist=0.0)
    -> dict()
    """

def reverse_colors(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.reverse_colors(bmesh, faces=[], color_index=0)
    -> dict()
    """

def reverse_faces(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.reverse_faces(bmesh, faces=[], flip_multires=False)
    -> dict()
    """

def reverse_uvs(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.reverse_uvs(bmesh, faces=[])
    -> dict()
    """

def rotate(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.rotate(bmesh, cent=Vector(), matrix=Matrix(), verts=[], space=Matrix(), use_shapekey=False)
    -> dict()
    """

def rotate_colors(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.rotate_colors(bmesh, faces=[], use_ccw=False, color_index=0)
    -> dict()
    """

def rotate_edges(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.rotate_edges(bmesh, edges=[], use_ccw=False)
    -> dict(edges=[])
    """

def rotate_uvs(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.rotate_uvs(bmesh, faces=[], use_ccw=False)
    -> dict()
    """

def scale(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.scale(bmesh, vec=Vector(), space=Matrix(), verts=[], use_shapekey=False)
    -> dict()
    """

def smooth_laplacian_vert(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.smooth_laplacian_vert(bmesh, verts=[], lambda_factor=0.0, lambda_border=0.0, use_x=False, use_y=False, use_z=False, preserve_volume=False)
    -> dict()
    """

def smooth_vert(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.smooth_vert(bmesh, verts=[], factor=0.0, mirror_clip_x=False, mirror_clip_y=False, mirror_clip_z=False, clip_dist=0.0, use_axis_x=False, use_axis_y=False, use_axis_z=False)
    -> dict()
    """

def solidify(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.solidify(bmesh, geom=[], thickness=0.0)
    -> dict(geom=[])
    """

def spin(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.spin(bmesh, geom=[], cent=Vector(), axis=Vector(), dvec=Vector(), angle=0.0, space=Matrix(), steps=0, use_merge=False, use_normal_flip=False, use_duplicate=False)
    -> dict(geom_last=[])
    """

def split(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.split(bmesh, geom=[], dest=None, use_only_faces=False)
    -> dict(geom=[], boundary_map={}, isovert_map={})
    """

def split_edges(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.split_edges(bmesh, edges=[], verts=[], use_verts=False)
    -> dict(edges=[])
    """

def subdivide_edgering(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.subdivide_edgering(bmesh, edges=[], interp_mode='LINEAR', smooth=0.0, cuts=0, profile_shape='SMOOTH', profile_shape_factor=0.0)
    -> dict(faces=[])
    """

def subdivide_edges(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.subdivide_edges(bmesh, edges=[], smooth=0.0, smooth_falloff='SMOOTH', fractal=0.0, along_normal=0.0, cuts=0, seed=0, custom_patterns={}, edge_percents={}, quad_corner_type='STRAIGHT_CUT', use_grid_fill=False, use_single_edge=False, use_only_quads=False, use_sphere=False, use_smooth_even=False)
    -> dict(geom_inner=[], geom_split=[], geom=[])
    """

def symmetrize(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.symmetrize(bmesh, input=[], direction='-X', dist=0.0, use_shapekey=False)
    -> dict(geom=[])
    """

def transform(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.transform(bmesh, matrix=Matrix(), space=Matrix(), verts=[], use_shapekey=False)
    -> dict()
    """

def translate(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.translate(bmesh, vec=Vector(), space=Matrix(), verts=[], use_shapekey=False)
    -> dict()
    """

def triangle_fill(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.triangle_fill(bmesh, use_beauty=False, use_dissolve=False, edges=[], normal=Vector())
    -> dict(geom=[])
    """

def triangulate(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.triangulate(bmesh, faces=[], quad_method='BEAUTY', ngon_method='BEAUTY')
    -> dict(edges=[], faces=[], face_map={}, face_map_double={})
    """

def unsubdivide(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.unsubdivide(bmesh, verts=[], iterations=0)
    -> dict()
    """

def weld_verts(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.weld_verts(bmesh, targetmap={}, use_centroid=False)
    -> dict()
    """

def wireframe(*args: object, **kwargs: object) -> None:
    """BMeshOpFunc bmesh.ops.wireframe(bmesh, faces=[], thickness=0.0, offset=0.0, use_replace=False, use_boundary=False, use_even_offset=False, use_crease=False, crease_weight=0.0, use_relative_offset=False, material_offset=0)
    -> dict(faces=[])
    """
