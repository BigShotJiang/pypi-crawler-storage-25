""".. |UV_STICKY_SELECT_MODE_REF| replace:: (:class:`bpy.types.ToolSettings.uv_sticky_select_mode` which may be passed in directly).

.. |UV_STICKY_SELECT_MODE_TYPE| replace:: Literal['SHARED_LOCATION', 'DISABLED', 'SHARED_VERTEX']

.. |UV_SELECT_FLUSH_MODE_NEEDED| replace:: This function is selection-mode independent, typically :meth:`BMesh.uv_select_flush_mode` should be called afterwards.

.. |UV_SELECT_SYNC_TO_MESH_NEEDED| replace:: This function doesn't flush the selection to the mesh, typically :meth:`BMesh.uv_select_sync_to_mesh` should be called afterwards.
"""

from collections.abc import Callable
from collections.abc import Iterable
from collections.abc import Iterator
from collections.abc import Sequence
from typing import Generic, TypeVar
from typing import Literal
from typing import Self
import bpy.types
import builtins
import mathutils

_T = TypeVar("_T")

class BMDeformVert:
    def __contains__(self, key: object, /) -> bool:
        """Return bool(key in self)."""

    def __delitem__(self, key: int | slice) -> None:
        """Delete self[key]."""

    def __getitem__(self, key: object, /) -> None:
        """Return self[key]."""

    def __len__(self) -> int:
        """Return len(self)."""

    def __setitem__(self, key: object, value: object, /) -> None:
        """Set self[key] to value."""

    def clear(self) -> None:
        """Clears all weights."""

    def get(self, key: int, default: object | None = None) -> float | object:
        """Returns the deform weight matching the key or default
        when not found (matches Python's dictionary function of the same name).

        :param key: The vertex group index.
        """

    def items(self) -> list[tuple[int, float]]:
        """Return (group, weight) pairs for this vertex
        (matching Python's dict.items() functionality).
        """

    def keys(self) -> list[int]:
        """Return the group indices used by this vertex
        (matching Python's dict.keys() functionality).
        """

    def values(self) -> list[float]:
        """Return the weights of the deform vertex
        (matching Python's dict.values() functionality).
        """

    def __iter__(self) -> Iterator[object]: ...

class BMEdge:
    """The BMesh edge connecting 2 verts"""

    hide: bool
    """Hidden state of this element.

:type: bool"""

    index: int
    """Index of this element.

:type: int

.. note::

   This value is not necessarily valid, while editing the mesh it can become *dirty*.

   It's also possible to assign any number to this attribute for a scripts internal logic.

   To ensure the value is up to date - see :meth:`BMElemSeq.index_update`."""

    @property
    def is_boundary(self) -> bool:
        """True when this edge is at the boundary of a face (read-only).

        :type: bool"""

    @property
    def is_contiguous(self) -> bool:
        """True when this edge is manifold, between two faces with the same winding (read-only).

        :type: bool"""

    @property
    def is_convex(self) -> bool:
        """True when this edge joins two convex faces, depends on a valid face normal (read-only).

        :type: bool"""

    @property
    def is_manifold(self) -> bool:
        """True when this edge is manifold (read-only).

        :type: bool"""
    is_valid: bool
    """True when this element is valid (hasn't been freed or removed).

:type: bool"""

    @property
    def is_wire(self) -> bool:
        """True when this edge is not connected to any faces (read-only).

        :type: bool"""

    @property
    def link_faces(self) -> BMElemSeq[BMFace]:
        """Faces connected to this edge, (read-only).

        :type: :class:`BMElemSeq`\\ [:class:`BMFace`]"""

    @property
    def link_loops(self) -> BMElemSeq[BMLoop]:
        """Loops connected to this edge, (read-only).

        :type: :class:`BMElemSeq`\\ [:class:`BMLoop`]"""
    seam: bool
    """Seam for UV unwrapping.

:type: bool"""

    select: bool
    """Selected state of this element.

:type: bool"""

    smooth: bool
    """Smooth state of this element.

:type: bool"""

    tag: bool
    """Generic attribute scripts can use for own logic

:type: bool"""

    @property
    def verts(self) -> BMElemSeq[BMVert]:
        """Verts this edge uses (always 2), (read-only).

        :type: :class:`BMElemSeq`\\ [:class:`BMVert`]"""

    def __delitem__(self, key: int | slice) -> None:
        """Delete self[key]."""

    def __getitem__(self, key: object, /) -> None:
        """Return self[key]."""

    def __setitem__(self, key: object, value: object, /) -> None:
        """Set self[key] to value."""

    def calc_face_angle(self, fallback: object | None = None) -> float:
        """Return the angle between this edge's two connected faces.

        :param fallback: return this when the edge doesn't have 2 faces
           (instead of raising a :exc:`ValueError`).
        """

    def calc_face_angle_signed(self, fallback: object | None = None) -> float:
        """Return the signed angle between this edge's two connected faces.

        :param fallback: return this when the edge doesn't have 2 faces
           (instead of raising a :exc:`ValueError`).
        """

    def calc_length(self) -> float:
        """Return the length of the edge."""

    def calc_tangent(self, loop: BMLoop) -> mathutils.Vector:
        """Return the tangent at this edge relative to a face (pointing inward into the face).
        This uses the face normal for calculation.

        :param loop: The loop used for tangent calculation.
        """

    def copy_from(self, other: Self, /) -> None:
        """Copy values from another element of matching type.

        :param other: Another element of the same type to copy from.
        """

    def hide_set(self, hide: bool, /) -> None:
        """Set the hide state.
        This is different from the *hide* attribute because it updates the selection and hide state of associated geometry.

        :param hide: Hidden or visible.
        """

    def normal_update(self) -> None:
        """Update normals of all connected faces and the edge verts."""

    def other_vert(self, vert: BMVert, /) -> BMVert | None:
        """Return the other vertex on this edge or None if the vertex is not used by this edge.

        :param vert: a vert in this edge.
        """

    def select_set(self, select: bool, /) -> None:
        """Set the selection.
        This is different from the *select* attribute because it updates the selection state of associated geometry.

        :param select: Select or de-select.
        """

    def __iter__(self) -> Iterator[object]: ...

class BMEdgeSeq:
    @property
    def layers(self) -> BMLayerAccessEdge:
        """custom-data layers (read-only).

        :type: :class:`BMLayerAccessEdge`"""

    def __contains__(self, key: object, /) -> bool:
        """Return bool(key in self)."""

    def __getitem__(self, key: object, /) -> None:
        """Return self[key]."""

    def __iter__(self) -> None:
        """Implement iter(self)."""

    def __len__(self) -> int:
        """Return len(self)."""

    def ensure_lookup_table(self) -> None:
        """Ensure internal data needed for int subscript access is initialized with verts/edges/faces, eg ``bm.verts[index]``.

        This needs to be called again after adding/removing data in this sequence.
        """

    def get(
        self, verts: Sequence[BMVert], fallback: object | None = None
    ) -> BMEdge | None:
        """Return an edge which uses the **verts** passed.

        :param verts: Pair of verts (exactly 2).
        """

    def index_update(self) -> None:
        """Initialize the index values of this sequence.

        This is the equivalent of looping over all elements and assigning the index values.
        """

    def new(self, verts: Sequence[BMVert], source: BMEdge | None = None) -> BMEdge:
        """Create a new edge from a given pair of verts.

        :param verts: Vertex pair.
        """

    def remove(self, edge: BMEdge, /) -> None:
        """Remove an edge.

        :param edge: The edge to remove.
        """

    def sort(
        self,
        *,
        key: Callable[[BMVert | BMEdge | BMFace], int] | None = None,
        reverse: bool = False,
    ) -> None:
        """Sort the elements of this sequence, using an optional custom sort key.
        Indices of elements are not changed, :meth:`BMElemSeq.index_update` can be used for that.

        :param key: The key that sets the ordering of the elements.
        """

class BMEditSelIter:
    def __iter__(self) -> None:
        """Implement iter(self)."""

class BMEditSelSeq:
    @property
    def active(self) -> BMVert | BMEdge | BMFace | None:
        """The last selected element or None (read-only).

        :type: :class:`BMVert` | :class:`BMEdge` | :class:`BMFace` | None"""

    def __contains__(self, key: object, /) -> bool:
        """Return bool(key in self)."""

    def __getitem__(self, key: object, /) -> None:
        """Return self[key]."""

    def __iter__(self) -> None:
        """Implement iter(self)."""

    def __len__(self) -> int:
        """Return len(self)."""

    def add(self, element: BMVert | BMEdge | BMFace, /) -> None:
        """Add an element to the selection history (no action taken if its already added).

        :param element: The element to add.
        """

    def clear(self) -> None:
        """Empties the selection history."""

    def discard(self, element: BMVert | BMEdge | BMFace, /) -> None:
        """Discard an element from the selection history.

        Like remove but doesn't raise an error when the element is not in the selection list.

        :param element: The element to discard.
        """

    def remove(self, element: BMVert | BMEdge | BMFace, /) -> None:
        """Remove an element from the selection history.

        :param element: The element to remove.
        """

    def validate(self) -> None:
        """Ensures all elements in the selection history are selected."""

class BMElemSeq(Generic[_T]):
    """General sequence type used for accessing any sequence of
    :class:`BMVert`, :class:`BMEdge`, :class:`BMFace`, :class:`BMLoop`.

    When accessed via :class:`BMesh.verts`, :class:`BMesh.edges`, :class:`BMesh.faces`
    there are also functions to create/remove items.
    """

    def __contains__(self, key: object, /) -> bool:
        """Return bool(key in self)."""

    def __getitem__(self, key: object, /) -> None:
        """Return self[key]."""

    def __iter__(self) -> None:
        """Implement iter(self)."""

    def __len__(self) -> int:
        """Return len(self)."""

    def index_update(self) -> None:
        """Initialize the index values of this sequence.

        This is the equivalent of looping over all elements and assigning the index values.
        """

class BMFace:
    """The BMesh face with 3 or more sides"""

    @property
    def edges(self) -> BMElemSeq[BMEdge]:
        """Edges of this face, (read-only).

        :type: :class:`BMElemSeq`\\ [:class:`BMEdge`]"""
    hide: bool
    """Hidden state of this element.

:type: bool"""

    index: int
    """Index of this element.

:type: int

.. note::

   This value is not necessarily valid, while editing the mesh it can become *dirty*.

   It's also possible to assign any number to this attribute for a scripts internal logic.

   To ensure the value is up to date - see :meth:`BMElemSeq.index_update`."""

    is_valid: bool
    """True when this element is valid (hasn't been freed or removed).

:type: bool"""

    @property
    def loops(self) -> BMElemSeq[BMLoop]:
        """Loops of this face, (read-only).

        :type: :class:`BMElemSeq`\\ [:class:`BMLoop`]"""
    material_index: int
    """The face's material index.

:type: int"""

    @property
    def normal(self) -> mathutils.Vector:
        """The normal for this face as a 3D, wrapped vector.

        :type: :class:`mathutils.Vector`"""

    @normal.setter
    def normal(self, value: mathutils.Vector | Sequence[float]) -> None: ...

    select: bool
    """Selected state of this element.

:type: bool"""

    smooth: bool
    """Smooth state of this element.

:type: bool"""

    tag: bool
    """Generic attribute scripts can use for own logic

:type: bool"""

    uv_select: bool
    """UV selected state of this element.

:type: bool"""

    @property
    def verts(self) -> BMElemSeq[BMVert]:
        """Verts of this face, (read-only).

        :type: :class:`BMElemSeq`\\ [:class:`BMVert`]"""

    def __delitem__(self, key: int | slice) -> None:
        """Delete self[key]."""

    def __getitem__(self, key: object, /) -> None:
        """Return self[key]."""

    def __setitem__(self, key: object, value: object, /) -> None:
        """Set self[key] to value."""

    def calc_area(self) -> float:
        """Return the area of the face."""

    def calc_center_bounds(self) -> mathutils.Vector:
        """Return bounds center of the face."""

    def calc_center_median(self) -> mathutils.Vector:
        """Return median center of the face."""

    def calc_center_median_weighted(self) -> mathutils.Vector:
        """Return median center of the face weighted by edge lengths."""

    def calc_perimeter(self) -> float:
        """Return the perimeter of the face."""

    def calc_tangent_edge(self) -> mathutils.Vector:
        """Return face tangent based on longest edge."""

    def calc_tangent_edge_diagonal(self) -> mathutils.Vector:
        """Return face tangent based on the edge farthest from any vertex."""

    def calc_tangent_edge_pair(self) -> mathutils.Vector:
        """Return face tangent based on the two longest disconnected edges.

        - Tris: Use the edge pair with the most similar lengths.
        - Quads: Use the longest edge pair.
        - NGons: Use the two longest disconnected edges.
        """

    def calc_tangent_vert_diagonal(self) -> mathutils.Vector:
        """Return face tangent based on the two most distant vertices."""

    def copy(self, *, verts: bool = True, edges: bool = True) -> BMFace:
        """Make a copy of this face.

        :param verts: When set, the faces verts will be duplicated too.
        """

    def copy_from(self, other: Self, /) -> None:
        """Copy values from another element of matching type.

        :param other: Another element of the same type to copy from.
        """

    def copy_from_face_interp(self, face: BMFace, vert: bool = True) -> None:
        """Interpolate the customdata from another face onto this one (faces should overlap).

        :param face: The face to interpolate data from.
        """

    def hide_set(self, hide: bool, /) -> None:
        """Set the hide state.
        This is different from the *hide* attribute because it updates the selection and hide state of associated geometry.

        :param hide: Hidden or visible.
        """

    def normal_flip(self) -> None:
        """Reverses winding of a face, which flips its normal."""

    def normal_update(self) -> None:
        """Update face normal based on the positions of the face verts.
        This does not update the normals of face verts.
        """

    def select_set(self, select: bool, /) -> None:
        """Set the selection.
        This is different from the *select* attribute because it updates the selection state of associated geometry.

        :param select: Select or de-select.
        """

    def uv_select_set(self, select: bool, /) -> None:
        """Set the UV face selection state.

        :param select: Select or de-select.
        """

    def __iter__(self) -> Iterator[object]: ...

class BMFaceSeq:
    active: BMFace | None
    """active face.

:type: :class:`BMFace` | None"""

    @property
    def layers(self) -> BMLayerAccessFace:
        """custom-data layers (read-only).

        :type: :class:`BMLayerAccessFace`"""

    def __contains__(self, key: object, /) -> bool:
        """Return bool(key in self)."""

    def __getitem__(self, key: object, /) -> None:
        """Return self[key]."""

    def __iter__(self) -> None:
        """Implement iter(self)."""

    def __len__(self) -> int:
        """Return len(self)."""

    def ensure_lookup_table(self) -> None:
        """Ensure internal data needed for int subscript access is initialized with verts/edges/faces, eg ``bm.verts[index]``.

        This needs to be called again after adding/removing data in this sequence.
        """

    def get(
        self, verts: Sequence[BMVert], fallback: object | None = None
    ) -> BMFace | None:
        """Return a face which uses the **verts** passed.

        :param verts: Sequence of verts.
        """

    def index_update(self) -> None:
        """Initialize the index values of this sequence.

        This is the equivalent of looping over all elements and assigning the index values.
        """

    def new(self, verts: Sequence[BMVert], source: BMFace | None = None) -> BMFace:
        """Create a new face from a given set of verts.

        :param verts: Sequence of 3 or more verts.
        """

    def remove(self, face: BMFace, /) -> None:
        """Remove a face.

        :param face: The face to remove.
        """

    def sort(
        self,
        *,
        key: Callable[[BMVert | BMEdge | BMFace], int] | None = None,
        reverse: bool = False,
    ) -> None:
        """Sort the elements of this sequence, using an optional custom sort key.
        Indices of elements are not changed, :meth:`BMElemSeq.index_update` can be used for that.

        :param key: The key that sets the ordering of the elements.
        """

class BMIter:
    """Internal BMesh type for looping over verts/faces/edges,
    used for iterating over :class:`BMElemSeq` types.
    """

    def __iter__(self) -> None:
        """Implement iter(self)."""

class BMLayerAccessEdge:
    """Exposes custom-data layer attributes."""

    bool: BMLayerCollection[builtins.bool]
    """Generic boolean custom-data layer.

:type: :class:`BMLayerCollection`\\ [bool]"""

    color: BMLayerCollection[mathutils.Vector]
    """Generic RGBA color with 8-bit precision custom-data layer.

:type: :class:`BMLayerCollection`\\ [:class:`mathutils.Vector`]"""

    float: BMLayerCollection[builtins.float]
    """Generic float custom-data layer.

:type: :class:`BMLayerCollection`\\ [float]"""

    float_color: BMLayerCollection[mathutils.Vector]
    """Generic RGBA color with float precision custom-data layer.

:type: :class:`BMLayerCollection`\\ [:class:`mathutils.Vector`]"""

    float_vector: BMLayerCollection[mathutils.Vector]
    """Generic 3D vector with float precision custom-data layer.

:type: :class:`BMLayerCollection`\\ [:class:`mathutils.Vector`]"""

    int: BMLayerCollection[builtins.int]
    """Generic int custom-data layer.

:type: :class:`BMLayerCollection`\\ [int]"""

    string: BMLayerCollection[bytes]
    """Generic string custom-data layer (exposed as bytes, 255 max length).

:type: :class:`BMLayerCollection`\\ [bytes]"""

class BMLayerAccessFace:
    """Exposes custom-data layer attributes."""

    bool: BMLayerCollection[builtins.bool]
    """Generic boolean custom-data layer.

:type: :class:`BMLayerCollection`\\ [bool]"""

    color: BMLayerCollection[mathutils.Vector]
    """Generic RGBA color with 8-bit precision custom-data layer.

:type: :class:`BMLayerCollection`\\ [:class:`mathutils.Vector`]"""

    float: BMLayerCollection[builtins.float]
    """Generic float custom-data layer.

:type: :class:`BMLayerCollection`\\ [float]"""

    float_color: BMLayerCollection[mathutils.Vector]
    """Generic RGBA color with float precision custom-data layer.

:type: :class:`BMLayerCollection`\\ [:class:`mathutils.Vector`]"""

    float_vector: BMLayerCollection[mathutils.Vector]
    """Generic 3D vector with float precision custom-data layer.

:type: :class:`BMLayerCollection`\\ [:class:`mathutils.Vector`]"""

    int: BMLayerCollection[builtins.int]
    """Generic int custom-data layer.

:type: :class:`BMLayerCollection`\\ [int]"""

    string: BMLayerCollection[bytes]
    """Generic string custom-data layer (exposed as bytes, 255 max length).

:type: :class:`BMLayerCollection`\\ [bytes]"""

class BMLayerAccessLoop:
    """Exposes custom-data layer attributes."""

    bool: BMLayerCollection[builtins.bool]
    """Generic boolean custom-data layer.

:type: :class:`BMLayerCollection`\\ [bool]"""

    color: BMLayerCollection[mathutils.Vector]
    """Generic RGBA color with 8-bit precision custom-data layer.

:type: :class:`BMLayerCollection`\\ [:class:`mathutils.Vector`]"""

    float: BMLayerCollection[builtins.float]
    """Generic float custom-data layer.

:type: :class:`BMLayerCollection`\\ [float]"""

    float_color: BMLayerCollection[mathutils.Vector]
    """Generic RGBA color with float precision custom-data layer.

:type: :class:`BMLayerCollection`\\ [:class:`mathutils.Vector`]"""

    float_vector: BMLayerCollection[mathutils.Vector]
    """Generic 3D vector with float precision custom-data layer.

:type: :class:`BMLayerCollection`\\ [:class:`mathutils.Vector`]"""

    int: BMLayerCollection[builtins.int]
    """Generic int custom-data layer.

:type: :class:`BMLayerCollection`\\ [int]"""

    string: BMLayerCollection[bytes]
    """Generic string custom-data layer (exposed as bytes, 255 max length).

:type: :class:`BMLayerCollection`\\ [bytes]"""

    uv: BMLayerCollection[BMLoopUV]
    """Accessor for :class:`BMLoopUV` UV (as a 2D Vector).

:type: :class:`BMLayerCollection`\\ [:class:`BMLoopUV`]"""

class BMLayerAccessVert:
    """Exposes custom-data layer attributes."""

    bool: BMLayerCollection[builtins.bool]
    """Generic boolean custom-data layer.

:type: :class:`BMLayerCollection`\\ [bool]"""

    color: BMLayerCollection[mathutils.Vector]
    """Generic RGBA color with 8-bit precision custom-data layer.

:type: :class:`BMLayerCollection`\\ [:class:`mathutils.Vector`]"""

    deform: BMLayerCollection[BMDeformVert]
    """Vertex deform weight :class:`BMDeformVert` (TODO).

:type: :class:`BMLayerCollection`\\ [:class:`BMDeformVert`]"""

    float: BMLayerCollection[builtins.float]
    """Generic float custom-data layer.

:type: :class:`BMLayerCollection`\\ [float]"""

    float_color: BMLayerCollection[mathutils.Vector]
    """Generic RGBA color with float precision custom-data layer.

:type: :class:`BMLayerCollection`\\ [:class:`mathutils.Vector`]"""

    float_vector: BMLayerCollection[mathutils.Vector]
    """Generic 3D vector with float precision custom-data layer.

:type: :class:`BMLayerCollection`\\ [:class:`mathutils.Vector`]"""

    int: BMLayerCollection[builtins.int]
    """Generic int custom-data layer.

:type: :class:`BMLayerCollection`\\ [int]"""

    shape: BMLayerCollection[mathutils.Vector]
    """Vertex shape-key absolute location (as a 3D Vector).

:type: :class:`BMLayerCollection`\\ [:class:`mathutils.Vector`]"""

    skin: BMLayerCollection[object]
    """Accessor for skin layer.

:type: :class:`BMLayerCollection`\\ [:class:`BMVertSkin`]"""

    string: BMLayerCollection[bytes]
    """Generic string custom-data layer (exposed as bytes, 255 max length).

:type: :class:`BMLayerCollection`\\ [bytes]"""

class BMLayerCollection(Generic[_T]):
    """Gives access to a collection of custom-data layers of the same type and behaves like Python dictionaries, except for the ability to do list like index access."""

    @property
    def active(self) -> BMLayerItem | None:
        """The active layer of this type (read-only).

        :type: :class:`BMLayerItem` | None"""

    @property
    def is_singleton(self) -> bool:
        """True if there can exist only one layer of this type (read-only).

        :type: bool"""

    def __contains__(self, key: object, /) -> bool:
        """Return bool(key in self)."""

    def __getitem__(self, key: object, /) -> None:
        """Return self[key]."""

    def __iter__(self) -> None:
        """Implement iter(self)."""

    def __len__(self) -> int:
        """Return len(self)."""

    def get(self, key: str, default: object | None = None) -> BMLayerItem | object:
        """Returns the value of the layer matching the key or default
        when not found (matches Python's dictionary function of the same name).

        :param key: The key associated with the layer.
        """

    def items(self) -> list[tuple[str, BMLayerItem]]:
        """Return the (key, value) pairs of collection members
        (matching Python's dict.items() functionality).
        """

    def keys(self) -> list[str]:
        """Return the identifiers of collection members
        (matching Python's dict.keys() functionality).
        """

    def new(self, name: str = "") -> BMLayerItem:
        """Create a new layer

        :param name: Optional name argument (will be made unique).
        """

    def remove(self, layer: BMLayerItem, /) -> None:
        """Remove a layer

        :param layer: The layer to remove.
        """

    def values(self) -> list[BMLayerItem]:
        """Return the values of collection
        (matching Python's dict.values() functionality).
        """

    def verify(self) -> BMLayerItem:
        """Create a new layer or return an existing active layer"""

class BMLayerItem:
    """Exposes a single custom data layer, its main purpose is for use as an item accessor to custom-data when used with vert/edge/face/loop data."""

    @property
    def name(self) -> str:
        """The layer's unique name (read-only).

        :type: str"""

    def copy_from(self, other: BMLayerItem, /) -> None:
        """Copy data from another layer.

        :param other: Another layer to copy from.
        """

class BMLoop:
    """This is normally accessed from :class:`BMFace.loops` where each face loop represents a corner of the face."""

    @property
    def edge(self) -> BMEdge:
        """The loop's edge (between this loop and the next), (read-only).

        :type: :class:`BMEdge`"""

    @property
    def face(self) -> BMFace:
        """The face this loop belongs to (read-only).

        :type: :class:`BMFace`"""
    index: int
    """Index of this element.

:type: int

.. note::

   This value is not necessarily valid, while editing the mesh it can become *dirty*.

   It's also possible to assign any number to this attribute for a scripts internal logic.

   To ensure the value is up to date - see :meth:`BMElemSeq.index_update`."""

    @property
    def is_convex(self) -> bool:
        """True when this loop is at the convex corner of a face, depends on a valid face normal (read-only).

        :type: bool"""
    is_valid: bool
    """True when this element is valid (hasn't been freed or removed).

:type: bool"""

    @property
    def link_loop_next(self) -> BMLoop:
        """The next face corner (read-only).

        :type: :class:`BMLoop`"""

    @property
    def link_loop_prev(self) -> BMLoop:
        """The previous face corner (read-only).

        :type: :class:`BMLoop`"""

    @property
    def link_loop_radial_next(self) -> BMLoop:
        """The next loop around the edge (read-only).

        :type: :class:`BMLoop`"""

    @property
    def link_loop_radial_prev(self) -> BMLoop:
        """The previous loop around the edge (read-only).

        :type: :class:`BMLoop`"""

    @property
    def link_loops(self) -> BMElemSeq[BMLoop]:
        """Loops connected to this loop, (read-only).

        :type: :class:`BMElemSeq`\\ [:class:`BMLoop`]"""
    tag: bool
    """Generic attribute scripts can use for own logic

:type: bool"""

    uv_select_edge: bool
    """UV edge selected state of this loop.

:type: bool"""

    uv_select_vert: bool
    """UV vertex selected state of this loop.

:type: bool"""

    @property
    def vert(self) -> BMVert:
        """The loop's vertex (read-only).

        :type: :class:`BMVert`"""

    def __delitem__(self, key: int | slice) -> None:
        """Delete self[key]."""

    def __getitem__(self, key: object, /) -> None:
        """Return self[key]."""

    def __setitem__(self, key: object, value: object, /) -> None:
        """Set self[key] to value."""

    def calc_angle(self) -> float:
        """Return the angle at this loops corner of the face.
        This is calculated so sharper corners give lower angles.
        """

    def calc_normal(self) -> mathutils.Vector:
        """Return normal at this loops corner of the face.
        Falls back to the face normal for straight lines.
        """

    def calc_tangent(self) -> mathutils.Vector:
        """Return the tangent at this loops corner of the face (pointing inward into the face).
        Falls back to the face normal for straight lines.
        """

    def copy_from(self, other: Self, /) -> None:
        """Copy values from another element of matching type.

        :param other: Another element of the same type to copy from.
        """

    def copy_from_face_interp(
        self, face: BMFace, vert: bool = True, multires: bool = True
    ) -> None:
        """Interpolate the customdata from a face onto this loop (the loop's vert should overlap the face).

        :param face: The face to interpolate data from.
        """

    def uv_select_edge_set(self, select: bool, /) -> None:
        """Set the UV edge selection state.

        :param select: Select or de-select.
        """

    def uv_select_vert_set(self, select: bool, /) -> None:
        """Set the UV vertex selection state.

        :param select: Select or de-select.
        """

    def __iter__(self) -> Iterator[object]: ...

class BMLoopSeq:
    @property
    def layers(self) -> BMLayerAccessLoop:
        """custom-data layers (read-only).

        :type: :class:`BMLayerAccessLoop`"""

class BMLoopUV:
    pin_uv: bool
    """UV pin state.

:type: bool"""

    @property
    def uv(self) -> mathutils.Vector:
        """Loop UV (as a 2D Vector).

        :type: :class:`mathutils.Vector`"""

    @uv.setter
    def uv(self, value: mathutils.Vector | Sequence[float]) -> None: ...

class BMVert:
    """The BMesh vertex type"""

    @property
    def co(self) -> mathutils.Vector:
        """The coordinates for this vertex as a 3D, wrapped vector.

        :type: :class:`mathutils.Vector`"""

    @co.setter
    def co(self, value: mathutils.Vector | Sequence[float]) -> None: ...

    hide: bool
    """Hidden state of this element.

:type: bool"""

    index: int
    """Index of this element.

:type: int

.. note::

   This value is not necessarily valid, while editing the mesh it can become *dirty*.

   It's also possible to assign any number to this attribute for a scripts internal logic.

   To ensure the value is up to date - see :meth:`BMElemSeq.index_update`."""

    @property
    def is_boundary(self) -> bool:
        """True when this vertex is connected to boundary edges (read-only).

        :type: bool"""

    @property
    def is_manifold(self) -> bool:
        """True when this vertex is manifold (read-only).

        :type: bool"""
    is_valid: bool
    """True when this element is valid (hasn't been freed or removed).

:type: bool"""

    @property
    def is_wire(self) -> bool:
        """True when this vertex is not connected to any faces (read-only).

        :type: bool"""

    @property
    def link_edges(self) -> BMElemSeq[BMEdge]:
        """Edges connected to this vertex (read-only).

        :type: :class:`BMElemSeq`\\ [:class:`BMEdge`]"""

    @property
    def link_faces(self) -> BMElemSeq[BMFace]:
        """Faces connected to this vertex (read-only).

        :type: :class:`BMElemSeq`\\ [:class:`BMFace`]"""

    @property
    def link_loops(self) -> BMElemSeq[BMLoop]:
        """Loops that use this vertex (read-only).

        :type: :class:`BMElemSeq`\\ [:class:`BMLoop`]"""

    @property
    def normal(self) -> mathutils.Vector:
        """The normal for this vertex as a 3D, wrapped vector.

        :type: :class:`mathutils.Vector`"""

    @normal.setter
    def normal(self, value: mathutils.Vector | Sequence[float]) -> None: ...

    select: bool
    """Selected state of this element.

:type: bool"""

    tag: bool
    """Generic attribute scripts can use for own logic

:type: bool"""

    def __delitem__(self, key: int | slice) -> None:
        """Delete self[key]."""

    def __getitem__(self, key: object, /) -> None:
        """Return self[key]."""

    def __setitem__(self, key: object, value: object, /) -> None:
        """Set self[key] to value."""

    def calc_edge_angle(self, fallback: object | None = None) -> float:
        """Return the angle between this vert's two connected edges.

        :param fallback: return this when the vert doesn't have 2 edges
           (instead of raising a :exc:`ValueError`).
        """

    def calc_shell_factor(self) -> float:
        """Return a multiplier calculated based on the sharpness of the vertex.
        Where a flat surface gives 1.0, and higher values sharper edges.
        This is used to maintain shell thickness when offsetting verts along their normals.
        """

    def copy_from(self, other: Self, /) -> None:
        """Copy values from another element of matching type.

        :param other: Another element of the same type to copy from.
        """

    def copy_from_face_interp(self, face: BMFace) -> None:
        """Interpolate the customdata from a face onto this vert (the vert should overlap the face).

        :param face: The face to interpolate data from.
        """

    def copy_from_vert_interp(self, vert_pair: Sequence[BMVert], fac: float) -> None:
        """Interpolate the customdata from a vert between 2 other verts.

        :param vert_pair: The verts between which to interpolate data from.
        """

    def hide_set(self, hide: bool, /) -> None:
        """Set the hide state.
        This is different from the *hide* attribute because it updates the selection and hide state of associated geometry.

        :param hide: Hidden or visible.
        """

    def normal_update(self) -> None:
        """Update vertex normal.
        This does not update the normals of adjoining faces.
        """

    def select_set(self, select: bool, /) -> None:
        """Set the selection.
        This is different from the *select* attribute because it updates the selection state of associated geometry.

        :param select: Select or de-select.
        """

    def __iter__(self) -> Iterator[object]: ...

class BMVertSeq:
    @property
    def layers(self) -> BMLayerAccessVert:
        """custom-data layers (read-only).

        :type: :class:`BMLayerAccessVert`"""

    def __contains__(self, key: object, /) -> bool:
        """Return bool(key in self)."""

    def __getitem__(self, key: object, /) -> None:
        """Return self[key]."""

    def __iter__(self) -> None:
        """Implement iter(self)."""

    def __len__(self) -> int:
        """Return len(self)."""

    def ensure_lookup_table(self) -> None:
        """Ensure internal data needed for int subscript access is initialized with verts/edges/faces, eg ``bm.verts[index]``.

        This needs to be called again after adding/removing data in this sequence.
        """

    def index_update(self) -> None:
        """Initialize the index values of this sequence.

        This is the equivalent of looping over all elements and assigning the index values.
        """

    def new(
        self,
        co: tuple[float, float, float] | Sequence[float] = ...,
        source: BMVert | None = None,
    ) -> BMVert:
        """Create a new vertex.

        :param co: The initial location of the vertex (optional argument).
        """

    def remove(self, vert: BMVert, /) -> None:
        """Remove a vert.

        :param vert: The vert to remove.
        """

    def sort(
        self,
        *,
        key: Callable[[BMVert | BMEdge | BMFace], int] | None = None,
        reverse: bool = False,
    ) -> None:
        """Sort the elements of this sequence, using an optional custom sort key.
        Indices of elements are not changed, :meth:`BMElemSeq.index_update` can be used for that.

        :param key: The key that sets the ordering of the elements.
        """

class BMesh:
    """The BMesh data structure"""

    @property
    def edges(self) -> BMEdgeSeq:
        """This mesh's edge sequence (read-only).

        :type: :class:`BMEdgeSeq`"""

    @property
    def faces(self) -> BMFaceSeq:
        """This mesh's face sequence (read-only).

        :type: :class:`BMFaceSeq`"""
    is_valid: bool
    """True when this element is valid (hasn't been freed or removed).

:type: bool"""

    is_wrapped: bool
    """True when this mesh is owned by blender (typically the editmode BMesh).

:type: bool"""

    @property
    def loops(self) -> BMLoopSeq:
        """This mesh's loops (read-only).

        :type: :class:`BMLoopSeq`

        .. note::

           Loops must be accessed via faces, this is only exposed for layer access."""
    select_history: BMEditSelSeq
    """Sequence of selected items (the last is displayed as active).

:type: :class:`BMEditSelSeq`"""

    select_mode: set[Literal["VERT", "EDGE", "FACE"]]
    """The selection mode, cannot be assigned an empty set.

:type: set[Literal['VERT', 'EDGE', 'FACE']]"""

    uv_select_sync_valid: bool
    """When true, the UV selection has been synchronized. Setting to False means the UV selection will be ignored. While setting to true is supported it is up to the script author to ensure a correct selection state before doing so.

:type: bool"""

    @property
    def verts(self) -> BMVertSeq:
        """This mesh's vert sequence (read-only).

        :type: :class:`BMVertSeq`"""

    def calc_loop_triangles(self) -> list[tuple[BMLoop, BMLoop, BMLoop]]:
        """Calculate triangle tessellation from quads/ngons."""

    def calc_volume(self, *, signed: bool = False) -> float:
        """Calculate mesh volume based on face normals.

        :param signed: when signed is true, negative values may be returned.
        """

    def clear(self) -> None:
        """Clear all mesh data."""

    def copy(self) -> BMesh: ...
    def free(self) -> None:
        """Explicitly free the BMesh data from memory, causing exceptions on further access."""

    def from_mesh(
        self,
        mesh: bpy.types.Mesh,
        *,
        face_normals: bool = True,
        vertex_normals: bool = True,
        use_shape_key: bool = False,
        shape_key_index: int = 0,
    ) -> None:
        """Initialize this bmesh from existing mesh data-block.

        :param mesh: The mesh data to load.
        """

    def from_object(
        self,
        object: bpy.types.Object,
        depsgraph: bpy.types.Depsgraph,
        *,
        cage: bool = False,
        face_normals: bool = True,
        vertex_normals: bool = True,
    ) -> None:
        """Initialize this bmesh from existing object data-block (only meshes are currently supported).

        :param object: The object data to load.
        """

    def normal_update(self) -> None:
        """Update normals of mesh faces and verts."""

    def select_flush(self, select: bool, /) -> None:
        """Flush selection from vertices, independent of the current selection mode.

        :param select: flush selection or de-selected elements.
        """

    def select_flush_mode(self, *, flush_down: bool = False) -> None:
        """Flush selection based on the current mode :attr:`BMesh.select_mode`.

        :param flush_down: Flush selection down from faces to edges & verts or from edges to verts. This option is ignored when vertex selection mode is enabled.
        """

    def to_mesh(self, mesh: bpy.types.Mesh) -> None:
        """Writes this BMesh data into an existing Mesh data-block.

        :param mesh: The mesh data to write into.
        """

    def transform(
        self,
        matrix: mathutils.Matrix,
        *,
        filter: set[Literal["SELECT", "HIDE", "SEAM", "SMOOTH", "TAG"]] | None = None,
    ) -> None:
        """Transform the mesh (optionally filtering flagged data only).

        :param matrix: 4x4 transform matrix.
        """

    def uv_select_flush(self, select: bool, /) -> None:
        """Flush selection from UV vertices to edges & faces independent of the selection mode.

        :param select: Flush selection or de-selected elements.
        """

    def uv_select_flush_mode(self, *, flush_down: bool = False) -> None:
        """Flush UV selection based on the current mode :attr:`BMesh.select_mode`.

        :param flush_down: Flush selection down from faces to edges & verts or from edges to verts. This option is ignored when vertex selection mode is enabled.
        """

    def uv_select_flush_shared(self, select: bool, /) -> None:
        """Flush selection from UV vertices to contiguous UV's independent of the selection mode.

        :param select: Flush selection or de-selected elements.
        """

    def uv_select_foreach_set(
        self,
        select: bool,
        /,
        *,
        loop_verts: Iterable[BMLoop] = (),
        loop_edges: Iterable[BMLoop] = (),
        faces: Iterable[BMFace] = (),
        sticky_select_mode: str = "SHARED_LOCATION",
    ) -> None:
        """Set the UV selection state for loop-vertices, loop-edges & faces.

        This is a close equivalent to selecting in the UV editor.

        :param select: The selection state to set.
        """

    def uv_select_foreach_set_from_mesh(
        self,
        select: bool,
        /,
        *,
        verts: Iterable[BMVert] = (),
        edges: Iterable[BMEdge] = (),
        faces: Iterable[BMFace] = (),
        sticky_select_mode: str = "SHARED_LOCATION",
    ) -> None:
        """Select or de-select mesh elements, updating the UV selection.

        An equivalent to selecting from the 3D viewport for selection operations that support maintaining a synchronized UV selection.

        :param select: The selection state to set.
        """

    def uv_select_sync_from_mesh(
        self, *, sticky_select_mode: str = "SHARED_LOCATION"
    ) -> None:
        """Sync selection from mesh to UVs.

        :param sticky_select_mode: Behavior when flushing from the mesh to UV selection |UV_STICKY_SELECT_MODE_REF|. This should only be used when preparing to create a UV selection.
        """

    def uv_select_sync_to_mesh(self) -> None:
        """Sync selection from UVs to the mesh."""
