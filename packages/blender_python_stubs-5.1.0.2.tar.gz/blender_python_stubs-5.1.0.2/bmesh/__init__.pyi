"""This module provides access to Blender's bmesh data structures.

.. include:: include__bmesh.rst"""

from . import geometry as geometry
from . import ops as ops
from . import types as types
from . import utils as utils
import bmesh.types
import bpy.types

def from_edit_mesh(mesh: bpy.types.Mesh, /) -> bmesh.types.BMesh:
    """Return a BMesh from this mesh, currently the mesh must already be in editmode.

    :param mesh: The editmode mesh.
    """

def new(*, use_operators: bool = True) -> bmesh.types.BMesh:
    """:param use_operators: Support calling operators in :mod:`bmesh.ops` (uses some extra memory per vert/edge/face)."""

def update_edit_mesh(
    mesh: bpy.types.Mesh, *, loop_triangles: bool = True, destructive: bool = True
) -> None:
    """Update the mesh after changes to the BMesh in editmode,
    optionally recalculating n-gon tessellation.

    :param mesh: The editmode mesh.
    """
