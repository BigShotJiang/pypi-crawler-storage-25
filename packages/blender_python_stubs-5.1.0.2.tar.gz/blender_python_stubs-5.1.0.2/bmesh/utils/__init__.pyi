"""This module provides bmesh utility functions for splitting, joining, and modifying mesh elements."""

from collections.abc import Sequence
import bmesh
import bmesh.types

def edge_rotate(
    edge: bmesh.types.BMEdge, ccw: bool = False
) -> bmesh.types.BMEdge | None:
    """Rotate the edge and return the newly created edge.
    If rotating the edge fails, None will be returned.

    :param edge: The edge to rotate.
    """

def edge_split(
    edge: bmesh.types.BMEdge, vert: bmesh.types.BMVert, fac: float
) -> tuple[bmesh.types.BMEdge, bmesh.types.BMVert]:
    """Split an edge, return the newly created data.

    :param edge: The edge to split.
    """

def face_flip(face: bmesh.types.BMFace, /) -> None:
    """Flip the face's direction.

    :param face: Face to flip.
    """

def face_join(
    faces: Sequence[bmesh.types.BMFace], remove: bool = True
) -> bmesh.types.BMFace | None:
    """Joins a sequence of faces.

    :param faces: Sequence of faces.
    """

def face_split(
    face: bmesh.types.BMFace,
    vert_a: bmesh.types.BMVert,
    vert_b: bmesh.types.BMVert,
    *,
    coords: Sequence[Sequence[float]] = (),
    use_exist: bool = True,
    source: bmesh.types.BMEdge | None = None,
) -> tuple[bmesh.types.BMFace, bmesh.types.BMLoop]:
    """Face split with optional intermediate points.

    :param face: The face to cut.
    """

def face_split_edgenet(
    face: bmesh.types.BMFace, edgenet: Sequence[bmesh.types.BMEdge]
) -> tuple[bmesh.types.BMFace, ...]:
    """Splits a face into any number of regions defined by an edgenet.

    :param face: The face to split.
    """

def face_vert_separate(
    face: bmesh.types.BMFace, vert: bmesh.types.BMVert
) -> bmesh.types.BMVert | None:
    """Rip a vertex in a face away and add a new vertex.

    :param face: The face to separate.
    """

def loop_separate(loop: bmesh.types.BMLoop, /) -> bmesh.types.BMVert | None:
    """Rip a vertex in a face away and add a new vertex.

    :param loop: The loop to separate.
    """

def uv_select_check(
    bm: bmesh.types.BMesh,
    /,
    *,
    sync: bool = True,
    flush: bool = False,
    contiguous: bool = False,
) -> dict[str, int] | None:
    """Check UV selection state for consistency issues.

    :param bm: The BMesh to check.
    """

def vert_collapse_edge(
    vert: bmesh.types.BMVert, edge: bmesh.types.BMEdge
) -> bmesh.types.BMEdge:
    """Collapse a vertex into an edge.

    :param vert: The vert that will be collapsed.
    """

def vert_collapse_faces(
    vert: bmesh.types.BMVert, edge: bmesh.types.BMEdge, fac: float, join_faces: bool
) -> bmesh.types.BMEdge:
    """Collapses a vertex that has only two manifold edges onto a vertex it shares an edge with.

    :param vert: The vert that will be collapsed.
    """

def vert_dissolve(vert: bmesh.types.BMVert) -> bool:
    """Dissolve this vertex (will be removed).

    :param vert: The vert to be dissolved.
    """

def vert_separate(
    vert: bmesh.types.BMVert, edges: Sequence[bmesh.types.BMEdge]
) -> tuple[bmesh.types.BMVert, ...]:
    """Separate this vertex at every edge.

    :param vert: The vert to be separated.
    """

def vert_splice(vert: bmesh.types.BMVert, vert_target: bmesh.types.BMVert) -> None:
    """Splice vert into vert_target, merging them.

    :param vert: The vertex to be removed.
    """
