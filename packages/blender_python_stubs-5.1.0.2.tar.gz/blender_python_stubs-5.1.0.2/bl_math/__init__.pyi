"""Miscellaneous math utilities module."""

def clamp(value: float, min: float = 0, max: float = 1) -> float:
    """Clamps the float value between minimum and maximum. To avoid
    confusion, any call must use either one or all three arguments.

    :param value: The value to clamp.
    """

def lerp(from_value: float, to_value: float, factor: float) -> float:
    """Linearly interpolate between two float values based on factor.

    :param from_value: The value to return when factor is 0.
    """

def smoothstep(from_value: float, to_value: float, value: float) -> float:
    """Performs smooth interpolation between 0 and 1 as value changes between from and to values.
    Outside the range the function returns the same value as the nearest edge.

    :param from_value: The edge value where the result is 0.
    """
