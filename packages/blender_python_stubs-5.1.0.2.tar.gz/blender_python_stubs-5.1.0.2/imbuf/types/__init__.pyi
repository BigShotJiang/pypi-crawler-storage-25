"""This module provides access to image buffer types.

.. note::

   Image buffer is also the structure used by :class:`bpy.types.Image`
   ID type to store and manipulate image data at runtime."""

class ImBuf:
    channels: int
    """Number of color channels.

:type: int"""

    filepath: str
    """Filepath associated with this image.

:type: str"""

    planes: int
    """Number of bits per pixel.

:type: int"""

    ppm: tuple[float, float]
    """Pixels per meter.

:type: tuple[float, float]"""

    size: tuple[int, int]
    """Size of the image in pixels.

:type: tuple[int, int]"""

    def copy(self) -> ImBuf:
        """Return a copy of the image."""

    def crop(self, min: tuple[int, int], max: tuple[int, int]) -> None:
        """Crop the image in-place.

        :param min: Minimum pixel coordinates (X, Y), inclusive.
        """

    def free(self) -> None:
        """Clear image data immediately (causing an error on re-use)."""

    def resize(self, size: tuple[int, int], *, method: str = "FAST") -> None:
        """Resize the image in-place.

        :param size: New size.
        """
