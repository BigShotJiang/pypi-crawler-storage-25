"""This module provides access to Blender's image manipulation API.

It provides access to image buffers outside of Blender's
:class:`bpy.types.Image` data-block context."""

from . import types as types
import imbuf.types

def load(filepath: str | bytes) -> imbuf.types.ImBuf:
    """Load an image from a file.

    :param filepath: The filepath of the image.
    """

def load_from_buffer(buffer: bytes) -> imbuf.types.ImBuf:
    """Load an image from a buffer.

    :param buffer: A buffer containing the image data.
    """

def new(size: tuple[int, int]) -> imbuf.types.ImBuf:
    """Create a new image.

    :param size: The size of the image in pixels.
    """

def write(image: imbuf.types.ImBuf, *, filepath: str | bytes | None = None) -> None:
    """Write an image.

    :param image: The image to write.
    """
