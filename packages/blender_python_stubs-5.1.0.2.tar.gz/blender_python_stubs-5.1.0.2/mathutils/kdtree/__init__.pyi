"""Generic 3-dimensional kd-tree to perform spatial searches."""

from collections.abc import Callable
from collections.abc import Sequence
import mathutils

class KDTree:
    """.. class:: KDTree(size)

    KDTree(size) -> new kd-tree initialized to hold up to ``size`` items.

    :param size: Maximum number of items.
    :type size: int

    .. note::

       :meth:`KDTree.balance` must have been called before using any of the ``find`` methods.
    """

    def __init__(self, size: int) -> None: ...
    def balance(self) -> None:
        """Balance the tree."""

    def find(
        self, co: Sequence[float], *, filter: Callable[[int], bool] | None = None
    ) -> tuple[mathutils.Vector, int, float] | tuple[None, None, None]:
        """Find nearest point to ``co``.

        :param co: 3D coordinate.
        """

    def find_n(
        self, co: Sequence[float], n: int
    ) -> list[tuple[mathutils.Vector, int, float]]:
        """Find nearest ``n`` points to ``co``.

        :param co: 3D coordinate.
        """

    def find_range(
        self, co: Sequence[float], radius: float
    ) -> list[tuple[mathutils.Vector, int, float]]:
        """Find all points within ``radius`` of ``co``.

        :param co: 3D coordinate.
        """

    def insert(self, co: Sequence[float], index: int) -> None:
        """Insert a point into the KDTree.

        :param co: Point 3d position.
        """
