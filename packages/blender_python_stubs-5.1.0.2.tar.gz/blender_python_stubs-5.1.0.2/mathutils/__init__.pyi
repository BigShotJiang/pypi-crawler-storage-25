"""This module provides access to math operations.

.. note::

   Classes, methods and attributes that accept vectors also accept other numeric sequences,
   such as tuples, lists.

The :mod:`mathutils` module provides the following classes:

- :class:`Color`,
- :class:`Euler`,
- :class:`Matrix`,
- :class:`Quaternion`,
- :class:`Vector`,"""

from . import bvhtree as bvhtree
from . import geometry as geometry
from . import interpolate as interpolate
from . import kdtree as kdtree
from . import noise as noise
from collections.abc import Iterator
from collections.abc import Sequence
from typing import Literal
from typing import Self
from typing_extensions import override

class Color:
    """.. class:: Color(rgb=(0.0, 0.0, 0.0), /)

    This object gives access to Colors in Blender.

    Most colors returned by Blender APIs are in scene linear color space, as defined by the OpenColorIO configuration. The notable exception is user interface theming colors, which are in sRGB color space.

    :param rgb: (red, green, blue) color values where (0, 0, 0) is black & (1, 1, 1) is white.
    :type rgb: Sequence[float]
    """

    b: float
    """Blue color channel.

:type: float"""

    g: float
    """Green color channel.

:type: float"""

    h: float
    """HSV Hue component in [0, 1].

:type: float"""

    hsv: tuple[float, float, float]
    """HSV Values in [0, 1].

:type: tuple[float, float, float]"""

    @property
    def is_frozen(self) -> bool:
        """True when this object has been frozen (read-only).

        :type: bool"""
    is_valid: bool
    """True when the owner of this data is valid.

:type: bool"""

    @property
    def is_wrapped(self) -> bool:
        """True when this object wraps external data (read-only).

        :type: bool"""

    @property
    def owner(self) -> object:
        """The item this is wrapping or None (read-only).

        :type: Any"""
    r: float
    """Red color channel.

:type: float"""

    s: float
    """HSV Saturation component in [0, 1].

:type: float"""

    v: float
    """HSV Value component in [0, 1].

:type: float"""

    def __init__(self, rgb: Sequence[float] = ..., /) -> None: ...
    def __add__(self, value: object, /) -> Color:
        """Return self+value."""

    def __delitem__(self, key: int | slice) -> None:
        """Delete self[key]."""

    @override
    def __eq__(self, value: object, /) -> bool:
        """Return self==value."""

    def __ge__(self, value: object, /) -> bool:
        """Return self>=value."""

    def __getitem__(self, key: int | slice) -> float:
        """Return self[key]."""

    def __gt__(self, value: object, /) -> bool:
        """Return self>value."""

    def __iadd__(self, value: object, /) -> Color:
        """Return self+=value."""

    def __imul__(self, value: object, /) -> Color:
        """Return self*=value."""

    def __isub__(self, value: object, /) -> Color:
        """Return self-=value."""

    def __itruediv__(self, value: object, /) -> Color:
        """Return self/=value."""

    def __le__(self, value: object, /) -> bool:
        """Return self<=value."""

    def __len__(self) -> int:
        """Return len(self)."""

    def __lt__(self, value: object, /) -> bool:
        """Return self<value."""

    def __mul__(self, value: object, /) -> Color:
        """Return self*value."""

    @override
    def __ne__(self, value: object, /) -> bool:
        """Return self!=value."""

    def __neg__(self) -> Color:
        """-self"""

    def __pos__(self) -> Color:
        """+self"""

    def __radd__(self, value: object, /) -> Color:
        """Return value+self."""

    def __rmul__(self, value: object, /) -> Color:
        """Return value*self."""

    def __rsub__(self, value: object, /) -> Color:
        """Return value-self."""

    def __rtruediv__(self, value: object, /) -> None:
        """Return value/self."""

    def __setitem__(
        self, key: int | slice, value: float | Sequence[float] | Color
    ) -> None:
        """Set self[key] to value."""

    def __sub__(self, value: object, /) -> Color:
        """Return self-value."""

    def __truediv__(self, value: object, /) -> Color:
        """Return self/value."""

    def copy(self) -> Color:
        """Returns a copy of this color."""

    def freeze(self) -> Self:
        """Make this object immutable.

        After this the object can be hashed, used in dictionaries & sets.
        """

    def from_aces_to_scene_linear(self) -> Color:
        """Convert from ACES2065-1 linear to scene linear color space."""

    def from_acescg_to_scene_linear(self) -> Color:
        """Convert from ACEScg linear to scene linear color space."""

    def from_rec2020_linear_to_scene_linear(self) -> Color:
        """Convert from Rec.2020 linear color space to scene linear color space."""

    def from_rec709_linear_to_scene_linear(self) -> Color:
        """Convert from Rec.709 linear color space to scene linear color space."""

    def from_scene_linear_to_aces(self) -> Color:
        """Convert from scene linear to ACES2065-1 linear color space."""

    def from_scene_linear_to_acescg(self) -> Color:
        """Convert from scene linear to ACEScg linear color space."""

    def from_scene_linear_to_rec2020_linear(self) -> Color:
        """Convert from scene linear to Rec.2020 linear color space."""

    def from_scene_linear_to_rec709_linear(self) -> Color:
        """Convert from scene linear to Rec.709 linear color space."""

    def from_scene_linear_to_srgb(self) -> Color:
        """Convert from scene linear to sRGB color space."""

    def from_scene_linear_to_xyz_d65(self) -> Color:
        """Convert from scene linear to CIE XYZ (Illuminant D65) color space."""

    def from_srgb_to_scene_linear(self) -> Color:
        """Convert from sRGB to scene linear color space."""

    def from_xyz_d65_to_scene_linear(self) -> Color:
        """Convert from CIE XYZ (Illuminant D65) to scene linear color space."""

    def __iter__(self) -> Iterator[float]: ...
    def __buffer__(self, flags: int, /) -> memoryview: ...

class Euler:
    """.. class:: Euler(angles=(0.0, 0.0, 0.0), order='XYZ', /)

    This object gives access to Eulers in Blender.

    .. seealso:: `Euler angles <https://en.wikipedia.org/wiki/Euler_angles>`__ on Wikipedia.

    :param angles: (X, Y, Z) angles in radians.
    :type angles: Sequence[float]
    :param order: Euler rotation order.
    :type order: Literal['XYZ', 'XZY', 'YXZ', 'YZX', 'ZXY', 'ZYX']
    """

    @property
    def is_frozen(self) -> bool:
        """True when this object has been frozen (read-only).

        :type: bool"""
    is_valid: bool
    """True when the owner of this data is valid.

:type: bool"""

    @property
    def is_wrapped(self) -> bool:
        """True when this object wraps external data (read-only).

        :type: bool"""
    order: Literal["XYZ", "XZY", "YXZ", "YZX", "ZXY", "ZYX"]
    """Euler rotation order.

:type: Literal['XYZ', 'XZY', 'YXZ', 'YZX', 'ZXY', 'ZYX']"""

    @property
    def owner(self) -> object:
        """The item this is wrapping or None (read-only).

        :type: Any"""
    x: float
    """Euler axis angle in radians.

:type: float"""

    y: float
    """Euler axis angle in radians.

:type: float"""

    z: float
    """Euler axis angle in radians.

:type: float"""

    def __init__(
        self,
        angles: Sequence[float] = ...,
        order: Literal["XYZ", "XZY", "YXZ", "YZX", "ZXY", "ZYX"] = "XYZ",
        /,
    ) -> None: ...
    def __delitem__(self, key: int | slice) -> None:
        """Delete self[key]."""

    @override
    def __eq__(self, value: object, /) -> bool:
        """Return self==value."""

    def __ge__(self, value: object, /) -> bool:
        """Return self>=value."""

    def __getitem__(self, key: int | slice) -> float:
        """Return self[key]."""

    def __gt__(self, value: object, /) -> bool:
        """Return self>value."""

    def __le__(self, value: object, /) -> bool:
        """Return self<=value."""

    def __len__(self) -> int:
        """Return len(self)."""

    def __lt__(self, value: object, /) -> bool:
        """Return self<value."""

    @override
    def __ne__(self, value: object, /) -> bool:
        """Return self!=value."""

    def __setitem__(
        self, key: int | slice, value: float | Sequence[float] | Euler
    ) -> None:
        """Set self[key] to value."""

    def copy(self) -> Euler:
        """Returns a copy of this euler."""

    def freeze(self) -> Self:
        """Make this object immutable.

        After this the object can be hashed, used in dictionaries & sets.
        """

    def make_compatible(self, other: Euler | Sequence[float], /) -> None:
        """Make this euler compatible with another,
        so interpolating between them works as intended.

        :param other: Other euler rotation.
        """

    def rotate(self, other: Euler | Quaternion | Matrix, /) -> None:
        """Rotates the euler by another mathutils value.

        :param other: rotation component of mathutils value
        """

    def rotate_axis(self, axis: Literal["X", "Y", "Z"], angle: float, /) -> None:
        """Rotates the euler a certain amount, wrapping the result to produce
        a unique euler rotation (no 720 degree pitches).

        :param axis: An axis string.
        """

    def to_matrix(self) -> Matrix:
        """Return a matrix representation of the euler."""

    def to_quaternion(self) -> Quaternion:
        """Return a quaternion representation of the euler."""

    def zero(self) -> None:
        """Set all values to zero."""

    def __iter__(self) -> Iterator[float]: ...
    def __buffer__(self, flags: int, /) -> memoryview: ...

class Matrix:
    """.. class:: Matrix(rows=Matrix.Identity(4), /)

    This object gives access to Matrices in Blender, supporting square and rectangular
    matrices from 2x2 up to 4x4.

    :param rows: Sequence of rows.
    :type rows: Sequence[Sequence[float]]
    """

    @property
    def col(self) -> MatrixAccess:
        """Access the matrix by columns (read-only).

        :type: :class:`MatrixAccess`"""

    @property
    def is_frozen(self) -> bool:
        """True when this object has been frozen (read-only).

        :type: bool"""

    @property
    def is_identity(self) -> bool:
        """True if this is an identity matrix (read-only).

        :type: bool"""

    @property
    def is_negative(self) -> bool:
        """True if this matrix results in a negative scale, 3x3 and 4x4 only, (read-only).

        :type: bool"""

    @property
    def is_orthogonal(self) -> bool:
        """True if this matrix is orthogonal, 3x3 and 4x4 only, (read-only).

        :type: bool"""

    @property
    def is_orthogonal_axis_vectors(self) -> bool:
        """True if this matrix has orthogonal axis vectors, 3x3 and 4x4 only, (read-only).

        :type: bool"""
    is_valid: bool
    """True when the owner of this data is valid.

:type: bool"""

    @property
    def is_wrapped(self) -> bool:
        """True when this object wraps external data (read-only).

        :type: bool"""

    @property
    def median_scale(self) -> float:
        """The average scale applied to each axis (read-only).

        :type: float"""

    @property
    def owner(self) -> object:
        """The item this is wrapping or None (read-only).

        :type: Any"""

    @property
    def row(self) -> MatrixAccess:
        """Access the matrix by rows (default), (read-only).

        :type: :class:`MatrixAccess`"""

    @property
    def translation(self) -> Vector:
        """The translation component of the matrix.

        :type: :class:`Vector`"""

    @translation.setter
    def translation(self, value: Vector | Sequence[float]) -> None: ...
    def __init__(self, rows: Sequence[Sequence[float]] = ..., /) -> None: ...
    @classmethod
    def Diagonal(cls, vector: Sequence[float], /) -> Matrix:
        """Create a diagonal (scaling) matrix using the values from the vector.

        :param vector: The vector of values for the diagonal.
        """

    @classmethod
    def Identity(cls, size: int) -> Matrix:
        """Create an identity matrix.

        :param size: The size of the identity matrix to construct [2, 4].
        """

    @classmethod
    def LocRotScale(
        cls,
        location: Sequence[float] | Vector | None,
        rotation: Matrix | Quaternion | Euler | None,
        scale: Sequence[float] | Vector | None,
    ) -> Matrix:
        """Create a matrix combining translation, rotation and scale,
        acting as the inverse of the decompose() method.

        Any of the inputs may be replaced with None if not needed.

        :param location: The translation component.
        """

    @classmethod
    def OrthoProjection(
        cls, axis: Literal["X", "Y", "XY", "XZ", "YZ"] | Sequence[float], size: int
    ) -> Matrix:
        """Create a matrix to represent an orthographic projection.

        :param axis: An axis string,
           where a single axis is for a 2D matrix.
           Or a vector for an arbitrary axis
        """

    @classmethod
    def Rotation(
        cls, angle: float, size: int, axis: Literal["X", "Y", "Z"] | Sequence[float]
    ) -> Matrix:
        """Create a matrix representing a rotation.

        :param angle: The angle of rotation desired, in radians.
        """

    @classmethod
    def Scale(cls, factor: float, size: int, axis: Sequence[float]) -> Matrix:
        """Create a matrix representing a scaling.

        :param factor: The factor of scaling to apply.
        """

    @classmethod
    def Shear(
        cls,
        plane: Literal["X", "Y", "XY", "XZ", "YZ"],
        size: int,
        factor: float | Sequence[float],
    ) -> Matrix:
        """Create a matrix to represent a shear transformation.

        :param plane: An axis string,
           where a single axis is for a 2D matrix only.
        """

    @classmethod
    def Translation(cls, vector: Sequence[float] | Vector, /) -> Matrix:
        """Create a matrix representing a translation.

        :param vector: The translation vector.
        """

    def __add__(self, value: object, /) -> Matrix:
        """Return self+value."""

    def __delitem__(self, key: int | slice) -> None:
        """Delete self[key]."""

    @override
    def __eq__(self, value: object, /) -> bool:
        """Return self==value."""

    def __ge__(self, value: object, /) -> bool:
        """Return self>=value."""

    def __getitem__(self, key: int | slice) -> Vector:
        """Return self[key]."""

    def __gt__(self, value: object, /) -> bool:
        """Return self>value."""

    def __imatmul__(self, value: object, /) -> Matrix:
        """Return self@=value."""

    def __imul__(self, value: object, /) -> Matrix:
        """Return self*=value."""

    def __invert__(self) -> None:
        """~self"""

    def __le__(self, value: object, /) -> bool:
        """Return self<=value."""

    def __len__(self) -> int:
        """Return len(self)."""

    def __lt__(self, value: object, /) -> bool:
        """Return self<value."""

    def __matmul__(self, value: object, /) -> Matrix:
        """Return self@value."""

    def __mul__(self, value: object, /) -> Matrix:
        """Return self*value."""

    @override
    def __ne__(self, value: object, /) -> bool:
        """Return self!=value."""

    def __radd__(self, value: object, /) -> Matrix:
        """Return value+self."""

    def __rmatmul__(self, value: object, /) -> Matrix:
        """Return value@self."""

    def __rmul__(self, value: object, /) -> Matrix:
        """Return value*self."""

    def __rsub__(self, value: object, /) -> Matrix:
        """Return value-self."""

    def __setitem__(
        self, key: int | slice, value: Vector | Sequence[Vector] | Matrix
    ) -> None:
        """Set self[key] to value."""

    def __sub__(self, value: object, /) -> Matrix:
        """Return self-value."""

    def adjugate(self) -> None:
        """Set the matrix to its adjugate.

        :raises ValueError: if the matrix cannot be adjugated.
        """

    def adjugated(self) -> Matrix:
        """Return an adjugated copy of the matrix."""

    def copy(self) -> Matrix:
        """Returns a copy of this matrix."""

    def decompose(self) -> tuple[Vector, Quaternion, Vector]:
        """Return the translation, rotation, and scale components of this 4x4 matrix."""

    def determinant(self) -> float:
        """Return the determinant of a matrix."""

    def freeze(self) -> Self:
        """Make this object immutable.

        After this the object can be hashed, used in dictionaries & sets.
        """

    def identity(self) -> None:
        """Set the matrix to the identity matrix."""

    def invert(self, fallback: Matrix | None = None, /) -> None:
        """Set the matrix to its inverse.

        :param fallback: Set the matrix to this value when the inverse cannot be calculated
           (instead of raising a :exc:`ValueError` exception).
        """

    def invert_safe(self) -> None:
        """Set the matrix to its inverse, will never error.
        If degenerated (e.g. zero scale on an axis), add some epsilon to its diagonal, to get an invertible one.
        If tweaked matrix is still degenerated, set to the identity matrix instead.
        """

    def inverted(self, fallback: object | None = None, /) -> Matrix | object:
        """Return an inverted copy of the matrix.

        :param fallback: return this when the inverse can't be calculated
           (instead of raising a :exc:`ValueError`).
        """

    def inverted_safe(self) -> Matrix:
        """Return an inverted copy of the matrix, will never error.
        If degenerated (e.g. zero scale on an axis), add some epsilon to its diagonal, to get an invertible one.
        If tweaked matrix is still degenerated, return the identity matrix instead.
        """

    def lerp(self, other: Matrix, factor: float, /) -> Matrix:
        """Returns the interpolation of two matrices. Uses polar decomposition, see "Matrix Animation and Polar Decomposition", Shoemake and Duff, 1992.

        :param other: value to interpolate with.
        """

    def normalize(self) -> None:
        """Normalize each of the matrix columns (3x3 and 4x4 only)."""

    def normalized(self) -> Matrix:
        """Return a column normalized matrix (3x3 and 4x4 only)."""

    def resize_4x4(self) -> None:
        """Resize the matrix to 4x4."""

    def rotate(self, other: Euler | Quaternion | Matrix, /) -> None:
        """Rotates the matrix by another mathutils value.

        :param other: rotation component of mathutils value
        """

    def to_2x2(self) -> Matrix:
        """Return a 2x2 copy of this matrix."""

    def to_3x3(self) -> Matrix:
        """Return a 3x3 copy of this matrix."""

    def to_4x4(self) -> Matrix:
        """Return a 4x4 copy of this matrix."""

    def to_euler(
        self,
        order: Literal["XYZ", "XZY", "YXZ", "YZX", "ZXY", "ZYX"] = "XYZ",
        euler_compat: Euler | None = None,
        /,
    ) -> Euler:
        """Return an Euler representation of the rotation matrix
        (3x3 or 4x4 matrix only).

        :param order: A rotation order string.
        """

    def to_quaternion(self) -> Quaternion:
        """Return a quaternion representation of the rotation matrix."""

    def to_scale(self) -> Vector:
        """Return the scale part of a 3x3 or 4x4 matrix."""

    def to_translation(self) -> Vector:
        """Return the translation part of a 4x4 matrix."""

    def transpose(self) -> None:
        """Set the matrix to its transpose."""

    def transposed(self) -> Matrix:
        """Return a new, transposed matrix."""

    def zero(self) -> None:
        """Set all the matrix values to zero."""

    def __iter__(self) -> Iterator[Vector]: ...
    def __buffer__(self, flags: int, /) -> memoryview: ...

class MatrixAccess:
    """An indexable type for accessing matrix rows or columns as :class:`Vector` types."""

    def __delitem__(self, key: int | slice) -> None:
        """Delete self[key]."""

    def __getitem__(self, key: object, /) -> None:
        """Return self[key]."""

    def __iter__(self) -> None:
        """Implement iter(self)."""

    def __len__(self) -> int:
        """Return len(self)."""

    def __setitem__(self, key: object, value: object, /) -> None:
        """Set self[key] to value."""

class Quaternion:
    """.. class:: Quaternion(seq=(1.0, 0.0, 0.0, 0.0), angle=0.0, /)

    This object gives access to Quaternions in Blender.

    :param seq: A (w, x, y, z) quaternion, a 3D exponential map vector,
       or a 3D axis vector (when *angle* is also provided).
    :type seq: Sequence[float]
    :param angle: rotation angle, in radians
    :type angle: float

    The constructor takes arguments in various forms:

    (), *no args*
       Create an identity quaternion
    (*wxyz*)
       Create a quaternion from a ``(w, x, y, z)`` vector.
    (*exponential_map*)
       Create a quaternion from a 3d exponential map vector.

       .. seealso:: :meth:`to_exponential_map`
    (*axis, angle*)
       Create a quaternion representing a rotation of *angle* radians over *axis*.

       .. seealso:: :meth:`to_axis_angle`
    """

    angle: float
    """Angle of the quaternion.

:type: float"""

    @property
    def axis(self) -> Vector:
        """Quaternion axis as a vector.

        :type: :class:`Vector`"""

    @axis.setter
    def axis(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def is_frozen(self) -> bool:
        """True when this object has been frozen (read-only).

        :type: bool"""
    is_valid: bool
    """True when the owner of this data is valid.

:type: bool"""

    @property
    def is_wrapped(self) -> bool:
        """True when this object wraps external data (read-only).

        :type: bool"""

    @property
    def magnitude(self) -> float:
        """Size of the quaternion (read-only).

        :type: float"""

    @property
    def owner(self) -> object:
        """The item this is wrapping or None (read-only).

        :type: Any"""
    w: float
    """Quaternion component value.

:type: float"""

    x: float
    """Quaternion component value.

:type: float"""

    y: float
    """Quaternion component value.

:type: float"""

    z: float
    """Quaternion component value.

:type: float"""

    def __init__(
        self, seq: Sequence[float] | Vector = ..., angle: object = 0.0, /
    ) -> None: ...
    def __add__(self, value: object, /) -> Quaternion:
        """Return self+value."""

    def __delitem__(self, key: int | slice) -> None:
        """Delete self[key]."""

    @override
    def __eq__(self, value: object, /) -> bool:
        """Return self==value."""

    def __ge__(self, value: object, /) -> bool:
        """Return self>=value."""

    def __getitem__(self, key: int | slice) -> float:
        """Return self[key]."""

    def __gt__(self, value: object, /) -> bool:
        """Return self>value."""

    def __imatmul__(self, value: object, /) -> Quaternion:
        """Return self@=value."""

    def __imul__(self, value: object, /) -> Quaternion:
        """Return self*=value."""

    def __le__(self, value: object, /) -> bool:
        """Return self<=value."""

    def __len__(self) -> int:
        """Return len(self)."""

    def __lt__(self, value: object, /) -> bool:
        """Return self<value."""

    def __matmul__(self, value: object, /) -> Quaternion:
        """Return self@value."""

    def __mul__(self, value: object, /) -> Quaternion:
        """Return self*value."""

    @override
    def __ne__(self, value: object, /) -> bool:
        """Return self!=value."""

    def __neg__(self) -> Quaternion:
        """-self"""

    def __pos__(self) -> Quaternion:
        """+self"""

    def __radd__(self, value: object, /) -> Quaternion:
        """Return value+self."""

    def __rmatmul__(self, value: object, /) -> Quaternion:
        """Return value@self."""

    def __rmul__(self, value: object, /) -> Quaternion:
        """Return value*self."""

    def __rsub__(self, value: object, /) -> Quaternion:
        """Return value-self."""

    def __setitem__(
        self, key: int | slice, value: float | Sequence[float] | Quaternion
    ) -> None:
        """Set self[key] to value."""

    def __sub__(self, value: object, /) -> Quaternion:
        """Return self-value."""

    def conjugate(self) -> None:
        """Set the quaternion to its conjugate (negate x, y, z)."""

    def conjugated(self) -> Quaternion:
        """Return a new conjugated quaternion."""

    def copy(self) -> Quaternion:
        """Returns a copy of this quaternion."""

    def cross(self, other: Quaternion | Sequence[float], /) -> Quaternion:
        """Return the cross product of this quaternion and another.

        :param other: The other quaternion to perform the cross product with.
        """

    def dot(self, other: Quaternion | Sequence[float], /) -> float:
        """Return the dot product of this quaternion and another.

        :param other: The other quaternion to perform the dot product with.
        """

    def freeze(self) -> Self:
        """Make this object immutable.

        After this the object can be hashed, used in dictionaries & sets.
        """

    def identity(self) -> None:
        """Set the quaternion to an identity quaternion."""

    def invert(self) -> None:
        """Set the quaternion to its inverse."""

    def inverted(self) -> Quaternion:
        """Return a new, inverted quaternion."""

    def make_compatible(self, other: Quaternion | Sequence[float], /) -> None:
        """Make this quaternion compatible with another,
        so interpolating between them works as intended.

        :param other: The reference quaternion to make this one compatible with.
        """

    def negate(self) -> None:
        """Set the quaternion to its negative."""

    def normalize(self) -> None:
        """Normalize the quaternion."""

    def normalized(self) -> Quaternion:
        """Return a new normalized quaternion."""

    def rotate(self, other: Euler | Quaternion | Matrix, /) -> None:
        """Rotates the quaternion by another mathutils value.

        :param other: rotation component of mathutils value
        """

    def rotation_difference(self, other: Quaternion | Sequence[float], /) -> Quaternion:
        """Returns a quaternion representing the rotational difference.

        :param other: second quaternion.
        """

    def slerp(
        self, other: Quaternion | Sequence[float], factor: float, /
    ) -> Quaternion:
        """Returns the interpolation of two quaternions.

        :param other: value to interpolate with.
        """

    def to_axis_angle(self) -> tuple[Vector, float]:
        """Return the axis, angle representation of the quaternion."""

    def to_euler(
        self,
        order: Literal["XYZ", "XZY", "YXZ", "YZX", "ZXY", "ZYX"] = "XYZ",
        euler_compat: Euler | None = None,
        /,
    ) -> Euler:
        """Return Euler representation of the quaternion.

        :param order: Rotation order.
        """

    def to_exponential_map(self) -> Vector:
        """Return the exponential map representation of the quaternion.

        This representation consists of the rotation axis multiplied by the rotation angle.
        Such a representation is useful for interpolation between multiple orientations.
        """

    def to_matrix(self) -> Matrix:
        """Return a matrix representation of the quaternion."""

    def to_swing_twist(
        self, axis: Literal["X", "Y", "Z"], /
    ) -> tuple[Quaternion, float]:
        """Split the rotation into a swing quaternion with the specified
        axis fixed at zero, and the remaining twist rotation angle.

        :param axis: Twist axis as a string.
        """

    def __iter__(self) -> Iterator[float]: ...
    def __buffer__(self, flags: int, /) -> memoryview: ...

class Vector:
    """.. class:: Vector(seq=(0.0, 0.0, 0.0), /)

    This object gives access to Vectors in Blender.

    :param seq: Components of the vector, must be a sequence of at least two.
    :type seq: Sequence[float]
    """

    @property
    def is_frozen(self) -> bool:
        """True when this object has been frozen (read-only).

        :type: bool"""
    is_valid: bool
    """True when the owner of this data is valid.

:type: bool"""

    @property
    def is_wrapped(self) -> bool:
        """True when this object wraps external data (read-only).

        :type: bool"""
    length: float
    """Vector Length.

:type: float"""

    length_squared: float
    """Vector length squared (v.dot(v)).

:type: float"""

    magnitude: float
    """Vector Length.

:type: float"""

    @property
    def owner(self) -> object:
        """The item this is wrapping or None (read-only).

        :type: Any"""
    w: float
    """Vector W axis (4D Vectors only).

:type: float"""

    @property
    def ww(self) -> Vector:
        """:type: :class:`Vector`"""

    @ww.setter
    def ww(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def www(self) -> Vector:
        """:type: :class:`Vector`"""

    @www.setter
    def www(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wwww(self) -> Vector:
        """:type: :class:`Vector`"""

    @wwww.setter
    def wwww(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wwwx(self) -> Vector:
        """:type: :class:`Vector`"""

    @wwwx.setter
    def wwwx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wwwy(self) -> Vector:
        """:type: :class:`Vector`"""

    @wwwy.setter
    def wwwy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wwwz(self) -> Vector:
        """:type: :class:`Vector`"""

    @wwwz.setter
    def wwwz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wwx(self) -> Vector:
        """:type: :class:`Vector`"""

    @wwx.setter
    def wwx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wwxw(self) -> Vector:
        """:type: :class:`Vector`"""

    @wwxw.setter
    def wwxw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wwxx(self) -> Vector:
        """:type: :class:`Vector`"""

    @wwxx.setter
    def wwxx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wwxy(self) -> Vector:
        """:type: :class:`Vector`"""

    @wwxy.setter
    def wwxy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wwxz(self) -> Vector:
        """:type: :class:`Vector`"""

    @wwxz.setter
    def wwxz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wwy(self) -> Vector:
        """:type: :class:`Vector`"""

    @wwy.setter
    def wwy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wwyw(self) -> Vector:
        """:type: :class:`Vector`"""

    @wwyw.setter
    def wwyw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wwyx(self) -> Vector:
        """:type: :class:`Vector`"""

    @wwyx.setter
    def wwyx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wwyy(self) -> Vector:
        """:type: :class:`Vector`"""

    @wwyy.setter
    def wwyy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wwyz(self) -> Vector:
        """:type: :class:`Vector`"""

    @wwyz.setter
    def wwyz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wwz(self) -> Vector:
        """:type: :class:`Vector`"""

    @wwz.setter
    def wwz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wwzw(self) -> Vector:
        """:type: :class:`Vector`"""

    @wwzw.setter
    def wwzw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wwzx(self) -> Vector:
        """:type: :class:`Vector`"""

    @wwzx.setter
    def wwzx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wwzy(self) -> Vector:
        """:type: :class:`Vector`"""

    @wwzy.setter
    def wwzy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wwzz(self) -> Vector:
        """:type: :class:`Vector`"""

    @wwzz.setter
    def wwzz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wx(self) -> Vector:
        """:type: :class:`Vector`"""

    @wx.setter
    def wx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wxw(self) -> Vector:
        """:type: :class:`Vector`"""

    @wxw.setter
    def wxw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wxww(self) -> Vector:
        """:type: :class:`Vector`"""

    @wxww.setter
    def wxww(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wxwx(self) -> Vector:
        """:type: :class:`Vector`"""

    @wxwx.setter
    def wxwx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wxwy(self) -> Vector:
        """:type: :class:`Vector`"""

    @wxwy.setter
    def wxwy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wxwz(self) -> Vector:
        """:type: :class:`Vector`"""

    @wxwz.setter
    def wxwz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wxx(self) -> Vector:
        """:type: :class:`Vector`"""

    @wxx.setter
    def wxx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wxxw(self) -> Vector:
        """:type: :class:`Vector`"""

    @wxxw.setter
    def wxxw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wxxx(self) -> Vector:
        """:type: :class:`Vector`"""

    @wxxx.setter
    def wxxx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wxxy(self) -> Vector:
        """:type: :class:`Vector`"""

    @wxxy.setter
    def wxxy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wxxz(self) -> Vector:
        """:type: :class:`Vector`"""

    @wxxz.setter
    def wxxz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wxy(self) -> Vector:
        """:type: :class:`Vector`"""

    @wxy.setter
    def wxy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wxyw(self) -> Vector:
        """:type: :class:`Vector`"""

    @wxyw.setter
    def wxyw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wxyx(self) -> Vector:
        """:type: :class:`Vector`"""

    @wxyx.setter
    def wxyx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wxyy(self) -> Vector:
        """:type: :class:`Vector`"""

    @wxyy.setter
    def wxyy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wxyz(self) -> Vector:
        """:type: :class:`Vector`"""

    @wxyz.setter
    def wxyz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wxz(self) -> Vector:
        """:type: :class:`Vector`"""

    @wxz.setter
    def wxz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wxzw(self) -> Vector:
        """:type: :class:`Vector`"""

    @wxzw.setter
    def wxzw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wxzx(self) -> Vector:
        """:type: :class:`Vector`"""

    @wxzx.setter
    def wxzx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wxzy(self) -> Vector:
        """:type: :class:`Vector`"""

    @wxzy.setter
    def wxzy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wxzz(self) -> Vector:
        """:type: :class:`Vector`"""

    @wxzz.setter
    def wxzz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wy(self) -> Vector:
        """:type: :class:`Vector`"""

    @wy.setter
    def wy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wyw(self) -> Vector:
        """:type: :class:`Vector`"""

    @wyw.setter
    def wyw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wyww(self) -> Vector:
        """:type: :class:`Vector`"""

    @wyww.setter
    def wyww(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wywx(self) -> Vector:
        """:type: :class:`Vector`"""

    @wywx.setter
    def wywx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wywy(self) -> Vector:
        """:type: :class:`Vector`"""

    @wywy.setter
    def wywy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wywz(self) -> Vector:
        """:type: :class:`Vector`"""

    @wywz.setter
    def wywz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wyx(self) -> Vector:
        """:type: :class:`Vector`"""

    @wyx.setter
    def wyx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wyxw(self) -> Vector:
        """:type: :class:`Vector`"""

    @wyxw.setter
    def wyxw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wyxx(self) -> Vector:
        """:type: :class:`Vector`"""

    @wyxx.setter
    def wyxx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wyxy(self) -> Vector:
        """:type: :class:`Vector`"""

    @wyxy.setter
    def wyxy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wyxz(self) -> Vector:
        """:type: :class:`Vector`"""

    @wyxz.setter
    def wyxz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wyy(self) -> Vector:
        """:type: :class:`Vector`"""

    @wyy.setter
    def wyy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wyyw(self) -> Vector:
        """:type: :class:`Vector`"""

    @wyyw.setter
    def wyyw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wyyx(self) -> Vector:
        """:type: :class:`Vector`"""

    @wyyx.setter
    def wyyx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wyyy(self) -> Vector:
        """:type: :class:`Vector`"""

    @wyyy.setter
    def wyyy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wyyz(self) -> Vector:
        """:type: :class:`Vector`"""

    @wyyz.setter
    def wyyz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wyz(self) -> Vector:
        """:type: :class:`Vector`"""

    @wyz.setter
    def wyz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wyzw(self) -> Vector:
        """:type: :class:`Vector`"""

    @wyzw.setter
    def wyzw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wyzx(self) -> Vector:
        """:type: :class:`Vector`"""

    @wyzx.setter
    def wyzx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wyzy(self) -> Vector:
        """:type: :class:`Vector`"""

    @wyzy.setter
    def wyzy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wyzz(self) -> Vector:
        """:type: :class:`Vector`"""

    @wyzz.setter
    def wyzz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wz(self) -> Vector:
        """:type: :class:`Vector`"""

    @wz.setter
    def wz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wzw(self) -> Vector:
        """:type: :class:`Vector`"""

    @wzw.setter
    def wzw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wzww(self) -> Vector:
        """:type: :class:`Vector`"""

    @wzww.setter
    def wzww(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wzwx(self) -> Vector:
        """:type: :class:`Vector`"""

    @wzwx.setter
    def wzwx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wzwy(self) -> Vector:
        """:type: :class:`Vector`"""

    @wzwy.setter
    def wzwy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wzwz(self) -> Vector:
        """:type: :class:`Vector`"""

    @wzwz.setter
    def wzwz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wzx(self) -> Vector:
        """:type: :class:`Vector`"""

    @wzx.setter
    def wzx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wzxw(self) -> Vector:
        """:type: :class:`Vector`"""

    @wzxw.setter
    def wzxw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wzxx(self) -> Vector:
        """:type: :class:`Vector`"""

    @wzxx.setter
    def wzxx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wzxy(self) -> Vector:
        """:type: :class:`Vector`"""

    @wzxy.setter
    def wzxy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wzxz(self) -> Vector:
        """:type: :class:`Vector`"""

    @wzxz.setter
    def wzxz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wzy(self) -> Vector:
        """:type: :class:`Vector`"""

    @wzy.setter
    def wzy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wzyw(self) -> Vector:
        """:type: :class:`Vector`"""

    @wzyw.setter
    def wzyw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wzyx(self) -> Vector:
        """:type: :class:`Vector`"""

    @wzyx.setter
    def wzyx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wzyy(self) -> Vector:
        """:type: :class:`Vector`"""

    @wzyy.setter
    def wzyy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wzyz(self) -> Vector:
        """:type: :class:`Vector`"""

    @wzyz.setter
    def wzyz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wzz(self) -> Vector:
        """:type: :class:`Vector`"""

    @wzz.setter
    def wzz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wzzw(self) -> Vector:
        """:type: :class:`Vector`"""

    @wzzw.setter
    def wzzw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wzzx(self) -> Vector:
        """:type: :class:`Vector`"""

    @wzzx.setter
    def wzzx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wzzy(self) -> Vector:
        """:type: :class:`Vector`"""

    @wzzy.setter
    def wzzy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def wzzz(self) -> Vector:
        """:type: :class:`Vector`"""

    @wzzz.setter
    def wzzz(self, value: Vector | Sequence[float]) -> None: ...

    x: float
    """Vector X axis.

:type: float"""

    @property
    def xw(self) -> Vector:
        """:type: :class:`Vector`"""

    @xw.setter
    def xw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xww(self) -> Vector:
        """:type: :class:`Vector`"""

    @xww.setter
    def xww(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xwww(self) -> Vector:
        """:type: :class:`Vector`"""

    @xwww.setter
    def xwww(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xwwx(self) -> Vector:
        """:type: :class:`Vector`"""

    @xwwx.setter
    def xwwx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xwwy(self) -> Vector:
        """:type: :class:`Vector`"""

    @xwwy.setter
    def xwwy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xwwz(self) -> Vector:
        """:type: :class:`Vector`"""

    @xwwz.setter
    def xwwz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xwx(self) -> Vector:
        """:type: :class:`Vector`"""

    @xwx.setter
    def xwx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xwxw(self) -> Vector:
        """:type: :class:`Vector`"""

    @xwxw.setter
    def xwxw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xwxx(self) -> Vector:
        """:type: :class:`Vector`"""

    @xwxx.setter
    def xwxx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xwxy(self) -> Vector:
        """:type: :class:`Vector`"""

    @xwxy.setter
    def xwxy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xwxz(self) -> Vector:
        """:type: :class:`Vector`"""

    @xwxz.setter
    def xwxz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xwy(self) -> Vector:
        """:type: :class:`Vector`"""

    @xwy.setter
    def xwy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xwyw(self) -> Vector:
        """:type: :class:`Vector`"""

    @xwyw.setter
    def xwyw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xwyx(self) -> Vector:
        """:type: :class:`Vector`"""

    @xwyx.setter
    def xwyx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xwyy(self) -> Vector:
        """:type: :class:`Vector`"""

    @xwyy.setter
    def xwyy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xwyz(self) -> Vector:
        """:type: :class:`Vector`"""

    @xwyz.setter
    def xwyz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xwz(self) -> Vector:
        """:type: :class:`Vector`"""

    @xwz.setter
    def xwz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xwzw(self) -> Vector:
        """:type: :class:`Vector`"""

    @xwzw.setter
    def xwzw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xwzx(self) -> Vector:
        """:type: :class:`Vector`"""

    @xwzx.setter
    def xwzx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xwzy(self) -> Vector:
        """:type: :class:`Vector`"""

    @xwzy.setter
    def xwzy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xwzz(self) -> Vector:
        """:type: :class:`Vector`"""

    @xwzz.setter
    def xwzz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xx(self) -> Vector:
        """:type: :class:`Vector`"""

    @xx.setter
    def xx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xxw(self) -> Vector:
        """:type: :class:`Vector`"""

    @xxw.setter
    def xxw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xxww(self) -> Vector:
        """:type: :class:`Vector`"""

    @xxww.setter
    def xxww(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xxwx(self) -> Vector:
        """:type: :class:`Vector`"""

    @xxwx.setter
    def xxwx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xxwy(self) -> Vector:
        """:type: :class:`Vector`"""

    @xxwy.setter
    def xxwy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xxwz(self) -> Vector:
        """:type: :class:`Vector`"""

    @xxwz.setter
    def xxwz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xxx(self) -> Vector:
        """:type: :class:`Vector`"""

    @xxx.setter
    def xxx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xxxw(self) -> Vector:
        """:type: :class:`Vector`"""

    @xxxw.setter
    def xxxw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xxxx(self) -> Vector:
        """:type: :class:`Vector`"""

    @xxxx.setter
    def xxxx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xxxy(self) -> Vector:
        """:type: :class:`Vector`"""

    @xxxy.setter
    def xxxy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xxxz(self) -> Vector:
        """:type: :class:`Vector`"""

    @xxxz.setter
    def xxxz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xxy(self) -> Vector:
        """:type: :class:`Vector`"""

    @xxy.setter
    def xxy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xxyw(self) -> Vector:
        """:type: :class:`Vector`"""

    @xxyw.setter
    def xxyw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xxyx(self) -> Vector:
        """:type: :class:`Vector`"""

    @xxyx.setter
    def xxyx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xxyy(self) -> Vector:
        """:type: :class:`Vector`"""

    @xxyy.setter
    def xxyy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xxyz(self) -> Vector:
        """:type: :class:`Vector`"""

    @xxyz.setter
    def xxyz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xxz(self) -> Vector:
        """:type: :class:`Vector`"""

    @xxz.setter
    def xxz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xxzw(self) -> Vector:
        """:type: :class:`Vector`"""

    @xxzw.setter
    def xxzw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xxzx(self) -> Vector:
        """:type: :class:`Vector`"""

    @xxzx.setter
    def xxzx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xxzy(self) -> Vector:
        """:type: :class:`Vector`"""

    @xxzy.setter
    def xxzy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xxzz(self) -> Vector:
        """:type: :class:`Vector`"""

    @xxzz.setter
    def xxzz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xy(self) -> Vector:
        """:type: :class:`Vector`"""

    @xy.setter
    def xy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xyw(self) -> Vector:
        """:type: :class:`Vector`"""

    @xyw.setter
    def xyw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xyww(self) -> Vector:
        """:type: :class:`Vector`"""

    @xyww.setter
    def xyww(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xywx(self) -> Vector:
        """:type: :class:`Vector`"""

    @xywx.setter
    def xywx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xywy(self) -> Vector:
        """:type: :class:`Vector`"""

    @xywy.setter
    def xywy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xywz(self) -> Vector:
        """:type: :class:`Vector`"""

    @xywz.setter
    def xywz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xyx(self) -> Vector:
        """:type: :class:`Vector`"""

    @xyx.setter
    def xyx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xyxw(self) -> Vector:
        """:type: :class:`Vector`"""

    @xyxw.setter
    def xyxw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xyxx(self) -> Vector:
        """:type: :class:`Vector`"""

    @xyxx.setter
    def xyxx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xyxy(self) -> Vector:
        """:type: :class:`Vector`"""

    @xyxy.setter
    def xyxy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xyxz(self) -> Vector:
        """:type: :class:`Vector`"""

    @xyxz.setter
    def xyxz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xyy(self) -> Vector:
        """:type: :class:`Vector`"""

    @xyy.setter
    def xyy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xyyw(self) -> Vector:
        """:type: :class:`Vector`"""

    @xyyw.setter
    def xyyw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xyyx(self) -> Vector:
        """:type: :class:`Vector`"""

    @xyyx.setter
    def xyyx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xyyy(self) -> Vector:
        """:type: :class:`Vector`"""

    @xyyy.setter
    def xyyy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xyyz(self) -> Vector:
        """:type: :class:`Vector`"""

    @xyyz.setter
    def xyyz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xyz(self) -> Vector:
        """:type: :class:`Vector`"""

    @xyz.setter
    def xyz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xyzw(self) -> Vector:
        """:type: :class:`Vector`"""

    @xyzw.setter
    def xyzw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xyzx(self) -> Vector:
        """:type: :class:`Vector`"""

    @xyzx.setter
    def xyzx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xyzy(self) -> Vector:
        """:type: :class:`Vector`"""

    @xyzy.setter
    def xyzy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xyzz(self) -> Vector:
        """:type: :class:`Vector`"""

    @xyzz.setter
    def xyzz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xz(self) -> Vector:
        """:type: :class:`Vector`"""

    @xz.setter
    def xz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xzw(self) -> Vector:
        """:type: :class:`Vector`"""

    @xzw.setter
    def xzw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xzww(self) -> Vector:
        """:type: :class:`Vector`"""

    @xzww.setter
    def xzww(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xzwx(self) -> Vector:
        """:type: :class:`Vector`"""

    @xzwx.setter
    def xzwx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xzwy(self) -> Vector:
        """:type: :class:`Vector`"""

    @xzwy.setter
    def xzwy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xzwz(self) -> Vector:
        """:type: :class:`Vector`"""

    @xzwz.setter
    def xzwz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xzx(self) -> Vector:
        """:type: :class:`Vector`"""

    @xzx.setter
    def xzx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xzxw(self) -> Vector:
        """:type: :class:`Vector`"""

    @xzxw.setter
    def xzxw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xzxx(self) -> Vector:
        """:type: :class:`Vector`"""

    @xzxx.setter
    def xzxx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xzxy(self) -> Vector:
        """:type: :class:`Vector`"""

    @xzxy.setter
    def xzxy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xzxz(self) -> Vector:
        """:type: :class:`Vector`"""

    @xzxz.setter
    def xzxz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xzy(self) -> Vector:
        """:type: :class:`Vector`"""

    @xzy.setter
    def xzy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xzyw(self) -> Vector:
        """:type: :class:`Vector`"""

    @xzyw.setter
    def xzyw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xzyx(self) -> Vector:
        """:type: :class:`Vector`"""

    @xzyx.setter
    def xzyx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xzyy(self) -> Vector:
        """:type: :class:`Vector`"""

    @xzyy.setter
    def xzyy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xzyz(self) -> Vector:
        """:type: :class:`Vector`"""

    @xzyz.setter
    def xzyz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xzz(self) -> Vector:
        """:type: :class:`Vector`"""

    @xzz.setter
    def xzz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xzzw(self) -> Vector:
        """:type: :class:`Vector`"""

    @xzzw.setter
    def xzzw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xzzx(self) -> Vector:
        """:type: :class:`Vector`"""

    @xzzx.setter
    def xzzx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xzzy(self) -> Vector:
        """:type: :class:`Vector`"""

    @xzzy.setter
    def xzzy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def xzzz(self) -> Vector:
        """:type: :class:`Vector`"""

    @xzzz.setter
    def xzzz(self, value: Vector | Sequence[float]) -> None: ...

    y: float
    """Vector Y axis.

:type: float"""

    @property
    def yw(self) -> Vector:
        """:type: :class:`Vector`"""

    @yw.setter
    def yw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yww(self) -> Vector:
        """:type: :class:`Vector`"""

    @yww.setter
    def yww(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def ywww(self) -> Vector:
        """:type: :class:`Vector`"""

    @ywww.setter
    def ywww(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def ywwx(self) -> Vector:
        """:type: :class:`Vector`"""

    @ywwx.setter
    def ywwx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def ywwy(self) -> Vector:
        """:type: :class:`Vector`"""

    @ywwy.setter
    def ywwy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def ywwz(self) -> Vector:
        """:type: :class:`Vector`"""

    @ywwz.setter
    def ywwz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def ywx(self) -> Vector:
        """:type: :class:`Vector`"""

    @ywx.setter
    def ywx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def ywxw(self) -> Vector:
        """:type: :class:`Vector`"""

    @ywxw.setter
    def ywxw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def ywxx(self) -> Vector:
        """:type: :class:`Vector`"""

    @ywxx.setter
    def ywxx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def ywxy(self) -> Vector:
        """:type: :class:`Vector`"""

    @ywxy.setter
    def ywxy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def ywxz(self) -> Vector:
        """:type: :class:`Vector`"""

    @ywxz.setter
    def ywxz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def ywy(self) -> Vector:
        """:type: :class:`Vector`"""

    @ywy.setter
    def ywy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def ywyw(self) -> Vector:
        """:type: :class:`Vector`"""

    @ywyw.setter
    def ywyw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def ywyx(self) -> Vector:
        """:type: :class:`Vector`"""

    @ywyx.setter
    def ywyx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def ywyy(self) -> Vector:
        """:type: :class:`Vector`"""

    @ywyy.setter
    def ywyy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def ywyz(self) -> Vector:
        """:type: :class:`Vector`"""

    @ywyz.setter
    def ywyz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def ywz(self) -> Vector:
        """:type: :class:`Vector`"""

    @ywz.setter
    def ywz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def ywzw(self) -> Vector:
        """:type: :class:`Vector`"""

    @ywzw.setter
    def ywzw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def ywzx(self) -> Vector:
        """:type: :class:`Vector`"""

    @ywzx.setter
    def ywzx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def ywzy(self) -> Vector:
        """:type: :class:`Vector`"""

    @ywzy.setter
    def ywzy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def ywzz(self) -> Vector:
        """:type: :class:`Vector`"""

    @ywzz.setter
    def ywzz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yx(self) -> Vector:
        """:type: :class:`Vector`"""

    @yx.setter
    def yx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yxw(self) -> Vector:
        """:type: :class:`Vector`"""

    @yxw.setter
    def yxw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yxww(self) -> Vector:
        """:type: :class:`Vector`"""

    @yxww.setter
    def yxww(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yxwx(self) -> Vector:
        """:type: :class:`Vector`"""

    @yxwx.setter
    def yxwx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yxwy(self) -> Vector:
        """:type: :class:`Vector`"""

    @yxwy.setter
    def yxwy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yxwz(self) -> Vector:
        """:type: :class:`Vector`"""

    @yxwz.setter
    def yxwz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yxx(self) -> Vector:
        """:type: :class:`Vector`"""

    @yxx.setter
    def yxx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yxxw(self) -> Vector:
        """:type: :class:`Vector`"""

    @yxxw.setter
    def yxxw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yxxx(self) -> Vector:
        """:type: :class:`Vector`"""

    @yxxx.setter
    def yxxx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yxxy(self) -> Vector:
        """:type: :class:`Vector`"""

    @yxxy.setter
    def yxxy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yxxz(self) -> Vector:
        """:type: :class:`Vector`"""

    @yxxz.setter
    def yxxz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yxy(self) -> Vector:
        """:type: :class:`Vector`"""

    @yxy.setter
    def yxy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yxyw(self) -> Vector:
        """:type: :class:`Vector`"""

    @yxyw.setter
    def yxyw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yxyx(self) -> Vector:
        """:type: :class:`Vector`"""

    @yxyx.setter
    def yxyx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yxyy(self) -> Vector:
        """:type: :class:`Vector`"""

    @yxyy.setter
    def yxyy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yxyz(self) -> Vector:
        """:type: :class:`Vector`"""

    @yxyz.setter
    def yxyz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yxz(self) -> Vector:
        """:type: :class:`Vector`"""

    @yxz.setter
    def yxz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yxzw(self) -> Vector:
        """:type: :class:`Vector`"""

    @yxzw.setter
    def yxzw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yxzx(self) -> Vector:
        """:type: :class:`Vector`"""

    @yxzx.setter
    def yxzx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yxzy(self) -> Vector:
        """:type: :class:`Vector`"""

    @yxzy.setter
    def yxzy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yxzz(self) -> Vector:
        """:type: :class:`Vector`"""

    @yxzz.setter
    def yxzz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yy(self) -> Vector:
        """:type: :class:`Vector`"""

    @yy.setter
    def yy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yyw(self) -> Vector:
        """:type: :class:`Vector`"""

    @yyw.setter
    def yyw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yyww(self) -> Vector:
        """:type: :class:`Vector`"""

    @yyww.setter
    def yyww(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yywx(self) -> Vector:
        """:type: :class:`Vector`"""

    @yywx.setter
    def yywx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yywy(self) -> Vector:
        """:type: :class:`Vector`"""

    @yywy.setter
    def yywy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yywz(self) -> Vector:
        """:type: :class:`Vector`"""

    @yywz.setter
    def yywz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yyx(self) -> Vector:
        """:type: :class:`Vector`"""

    @yyx.setter
    def yyx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yyxw(self) -> Vector:
        """:type: :class:`Vector`"""

    @yyxw.setter
    def yyxw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yyxx(self) -> Vector:
        """:type: :class:`Vector`"""

    @yyxx.setter
    def yyxx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yyxy(self) -> Vector:
        """:type: :class:`Vector`"""

    @yyxy.setter
    def yyxy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yyxz(self) -> Vector:
        """:type: :class:`Vector`"""

    @yyxz.setter
    def yyxz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yyy(self) -> Vector:
        """:type: :class:`Vector`"""

    @yyy.setter
    def yyy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yyyw(self) -> Vector:
        """:type: :class:`Vector`"""

    @yyyw.setter
    def yyyw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yyyx(self) -> Vector:
        """:type: :class:`Vector`"""

    @yyyx.setter
    def yyyx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yyyy(self) -> Vector:
        """:type: :class:`Vector`"""

    @yyyy.setter
    def yyyy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yyyz(self) -> Vector:
        """:type: :class:`Vector`"""

    @yyyz.setter
    def yyyz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yyz(self) -> Vector:
        """:type: :class:`Vector`"""

    @yyz.setter
    def yyz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yyzw(self) -> Vector:
        """:type: :class:`Vector`"""

    @yyzw.setter
    def yyzw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yyzx(self) -> Vector:
        """:type: :class:`Vector`"""

    @yyzx.setter
    def yyzx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yyzy(self) -> Vector:
        """:type: :class:`Vector`"""

    @yyzy.setter
    def yyzy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yyzz(self) -> Vector:
        """:type: :class:`Vector`"""

    @yyzz.setter
    def yyzz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yz(self) -> Vector:
        """:type: :class:`Vector`"""

    @yz.setter
    def yz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yzw(self) -> Vector:
        """:type: :class:`Vector`"""

    @yzw.setter
    def yzw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yzww(self) -> Vector:
        """:type: :class:`Vector`"""

    @yzww.setter
    def yzww(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yzwx(self) -> Vector:
        """:type: :class:`Vector`"""

    @yzwx.setter
    def yzwx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yzwy(self) -> Vector:
        """:type: :class:`Vector`"""

    @yzwy.setter
    def yzwy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yzwz(self) -> Vector:
        """:type: :class:`Vector`"""

    @yzwz.setter
    def yzwz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yzx(self) -> Vector:
        """:type: :class:`Vector`"""

    @yzx.setter
    def yzx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yzxw(self) -> Vector:
        """:type: :class:`Vector`"""

    @yzxw.setter
    def yzxw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yzxx(self) -> Vector:
        """:type: :class:`Vector`"""

    @yzxx.setter
    def yzxx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yzxy(self) -> Vector:
        """:type: :class:`Vector`"""

    @yzxy.setter
    def yzxy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yzxz(self) -> Vector:
        """:type: :class:`Vector`"""

    @yzxz.setter
    def yzxz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yzy(self) -> Vector:
        """:type: :class:`Vector`"""

    @yzy.setter
    def yzy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yzyw(self) -> Vector:
        """:type: :class:`Vector`"""

    @yzyw.setter
    def yzyw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yzyx(self) -> Vector:
        """:type: :class:`Vector`"""

    @yzyx.setter
    def yzyx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yzyy(self) -> Vector:
        """:type: :class:`Vector`"""

    @yzyy.setter
    def yzyy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yzyz(self) -> Vector:
        """:type: :class:`Vector`"""

    @yzyz.setter
    def yzyz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yzz(self) -> Vector:
        """:type: :class:`Vector`"""

    @yzz.setter
    def yzz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yzzw(self) -> Vector:
        """:type: :class:`Vector`"""

    @yzzw.setter
    def yzzw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yzzx(self) -> Vector:
        """:type: :class:`Vector`"""

    @yzzx.setter
    def yzzx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yzzy(self) -> Vector:
        """:type: :class:`Vector`"""

    @yzzy.setter
    def yzzy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def yzzz(self) -> Vector:
        """:type: :class:`Vector`"""

    @yzzz.setter
    def yzzz(self, value: Vector | Sequence[float]) -> None: ...

    z: float
    """Vector Z axis (3D Vectors only).

:type: float"""

    @property
    def zw(self) -> Vector:
        """:type: :class:`Vector`"""

    @zw.setter
    def zw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zww(self) -> Vector:
        """:type: :class:`Vector`"""

    @zww.setter
    def zww(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zwww(self) -> Vector:
        """:type: :class:`Vector`"""

    @zwww.setter
    def zwww(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zwwx(self) -> Vector:
        """:type: :class:`Vector`"""

    @zwwx.setter
    def zwwx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zwwy(self) -> Vector:
        """:type: :class:`Vector`"""

    @zwwy.setter
    def zwwy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zwwz(self) -> Vector:
        """:type: :class:`Vector`"""

    @zwwz.setter
    def zwwz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zwx(self) -> Vector:
        """:type: :class:`Vector`"""

    @zwx.setter
    def zwx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zwxw(self) -> Vector:
        """:type: :class:`Vector`"""

    @zwxw.setter
    def zwxw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zwxx(self) -> Vector:
        """:type: :class:`Vector`"""

    @zwxx.setter
    def zwxx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zwxy(self) -> Vector:
        """:type: :class:`Vector`"""

    @zwxy.setter
    def zwxy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zwxz(self) -> Vector:
        """:type: :class:`Vector`"""

    @zwxz.setter
    def zwxz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zwy(self) -> Vector:
        """:type: :class:`Vector`"""

    @zwy.setter
    def zwy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zwyw(self) -> Vector:
        """:type: :class:`Vector`"""

    @zwyw.setter
    def zwyw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zwyx(self) -> Vector:
        """:type: :class:`Vector`"""

    @zwyx.setter
    def zwyx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zwyy(self) -> Vector:
        """:type: :class:`Vector`"""

    @zwyy.setter
    def zwyy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zwyz(self) -> Vector:
        """:type: :class:`Vector`"""

    @zwyz.setter
    def zwyz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zwz(self) -> Vector:
        """:type: :class:`Vector`"""

    @zwz.setter
    def zwz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zwzw(self) -> Vector:
        """:type: :class:`Vector`"""

    @zwzw.setter
    def zwzw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zwzx(self) -> Vector:
        """:type: :class:`Vector`"""

    @zwzx.setter
    def zwzx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zwzy(self) -> Vector:
        """:type: :class:`Vector`"""

    @zwzy.setter
    def zwzy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zwzz(self) -> Vector:
        """:type: :class:`Vector`"""

    @zwzz.setter
    def zwzz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zx(self) -> Vector:
        """:type: :class:`Vector`"""

    @zx.setter
    def zx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zxw(self) -> Vector:
        """:type: :class:`Vector`"""

    @zxw.setter
    def zxw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zxww(self) -> Vector:
        """:type: :class:`Vector`"""

    @zxww.setter
    def zxww(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zxwx(self) -> Vector:
        """:type: :class:`Vector`"""

    @zxwx.setter
    def zxwx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zxwy(self) -> Vector:
        """:type: :class:`Vector`"""

    @zxwy.setter
    def zxwy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zxwz(self) -> Vector:
        """:type: :class:`Vector`"""

    @zxwz.setter
    def zxwz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zxx(self) -> Vector:
        """:type: :class:`Vector`"""

    @zxx.setter
    def zxx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zxxw(self) -> Vector:
        """:type: :class:`Vector`"""

    @zxxw.setter
    def zxxw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zxxx(self) -> Vector:
        """:type: :class:`Vector`"""

    @zxxx.setter
    def zxxx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zxxy(self) -> Vector:
        """:type: :class:`Vector`"""

    @zxxy.setter
    def zxxy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zxxz(self) -> Vector:
        """:type: :class:`Vector`"""

    @zxxz.setter
    def zxxz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zxy(self) -> Vector:
        """:type: :class:`Vector`"""

    @zxy.setter
    def zxy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zxyw(self) -> Vector:
        """:type: :class:`Vector`"""

    @zxyw.setter
    def zxyw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zxyx(self) -> Vector:
        """:type: :class:`Vector`"""

    @zxyx.setter
    def zxyx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zxyy(self) -> Vector:
        """:type: :class:`Vector`"""

    @zxyy.setter
    def zxyy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zxyz(self) -> Vector:
        """:type: :class:`Vector`"""

    @zxyz.setter
    def zxyz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zxz(self) -> Vector:
        """:type: :class:`Vector`"""

    @zxz.setter
    def zxz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zxzw(self) -> Vector:
        """:type: :class:`Vector`"""

    @zxzw.setter
    def zxzw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zxzx(self) -> Vector:
        """:type: :class:`Vector`"""

    @zxzx.setter
    def zxzx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zxzy(self) -> Vector:
        """:type: :class:`Vector`"""

    @zxzy.setter
    def zxzy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zxzz(self) -> Vector:
        """:type: :class:`Vector`"""

    @zxzz.setter
    def zxzz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zy(self) -> Vector:
        """:type: :class:`Vector`"""

    @zy.setter
    def zy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zyw(self) -> Vector:
        """:type: :class:`Vector`"""

    @zyw.setter
    def zyw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zyww(self) -> Vector:
        """:type: :class:`Vector`"""

    @zyww.setter
    def zyww(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zywx(self) -> Vector:
        """:type: :class:`Vector`"""

    @zywx.setter
    def zywx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zywy(self) -> Vector:
        """:type: :class:`Vector`"""

    @zywy.setter
    def zywy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zywz(self) -> Vector:
        """:type: :class:`Vector`"""

    @zywz.setter
    def zywz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zyx(self) -> Vector:
        """:type: :class:`Vector`"""

    @zyx.setter
    def zyx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zyxw(self) -> Vector:
        """:type: :class:`Vector`"""

    @zyxw.setter
    def zyxw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zyxx(self) -> Vector:
        """:type: :class:`Vector`"""

    @zyxx.setter
    def zyxx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zyxy(self) -> Vector:
        """:type: :class:`Vector`"""

    @zyxy.setter
    def zyxy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zyxz(self) -> Vector:
        """:type: :class:`Vector`"""

    @zyxz.setter
    def zyxz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zyy(self) -> Vector:
        """:type: :class:`Vector`"""

    @zyy.setter
    def zyy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zyyw(self) -> Vector:
        """:type: :class:`Vector`"""

    @zyyw.setter
    def zyyw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zyyx(self) -> Vector:
        """:type: :class:`Vector`"""

    @zyyx.setter
    def zyyx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zyyy(self) -> Vector:
        """:type: :class:`Vector`"""

    @zyyy.setter
    def zyyy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zyyz(self) -> Vector:
        """:type: :class:`Vector`"""

    @zyyz.setter
    def zyyz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zyz(self) -> Vector:
        """:type: :class:`Vector`"""

    @zyz.setter
    def zyz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zyzw(self) -> Vector:
        """:type: :class:`Vector`"""

    @zyzw.setter
    def zyzw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zyzx(self) -> Vector:
        """:type: :class:`Vector`"""

    @zyzx.setter
    def zyzx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zyzy(self) -> Vector:
        """:type: :class:`Vector`"""

    @zyzy.setter
    def zyzy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zyzz(self) -> Vector:
        """:type: :class:`Vector`"""

    @zyzz.setter
    def zyzz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zz(self) -> Vector:
        """:type: :class:`Vector`"""

    @zz.setter
    def zz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zzw(self) -> Vector:
        """:type: :class:`Vector`"""

    @zzw.setter
    def zzw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zzww(self) -> Vector:
        """:type: :class:`Vector`"""

    @zzww.setter
    def zzww(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zzwx(self) -> Vector:
        """:type: :class:`Vector`"""

    @zzwx.setter
    def zzwx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zzwy(self) -> Vector:
        """:type: :class:`Vector`"""

    @zzwy.setter
    def zzwy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zzwz(self) -> Vector:
        """:type: :class:`Vector`"""

    @zzwz.setter
    def zzwz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zzx(self) -> Vector:
        """:type: :class:`Vector`"""

    @zzx.setter
    def zzx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zzxw(self) -> Vector:
        """:type: :class:`Vector`"""

    @zzxw.setter
    def zzxw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zzxx(self) -> Vector:
        """:type: :class:`Vector`"""

    @zzxx.setter
    def zzxx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zzxy(self) -> Vector:
        """:type: :class:`Vector`"""

    @zzxy.setter
    def zzxy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zzxz(self) -> Vector:
        """:type: :class:`Vector`"""

    @zzxz.setter
    def zzxz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zzy(self) -> Vector:
        """:type: :class:`Vector`"""

    @zzy.setter
    def zzy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zzyw(self) -> Vector:
        """:type: :class:`Vector`"""

    @zzyw.setter
    def zzyw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zzyx(self) -> Vector:
        """:type: :class:`Vector`"""

    @zzyx.setter
    def zzyx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zzyy(self) -> Vector:
        """:type: :class:`Vector`"""

    @zzyy.setter
    def zzyy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zzyz(self) -> Vector:
        """:type: :class:`Vector`"""

    @zzyz.setter
    def zzyz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zzz(self) -> Vector:
        """:type: :class:`Vector`"""

    @zzz.setter
    def zzz(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zzzw(self) -> Vector:
        """:type: :class:`Vector`"""

    @zzzw.setter
    def zzzw(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zzzx(self) -> Vector:
        """:type: :class:`Vector`"""

    @zzzx.setter
    def zzzx(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zzzy(self) -> Vector:
        """:type: :class:`Vector`"""

    @zzzy.setter
    def zzzy(self, value: Vector | Sequence[float]) -> None: ...
    @property
    def zzzz(self) -> Vector:
        """:type: :class:`Vector`"""

    @zzzz.setter
    def zzzz(self, value: Vector | Sequence[float]) -> None: ...
    def __init__(self, seq: Sequence[float] = ..., /) -> None: ...
    @classmethod
    def Fill(cls, size: int, fill: float) -> Vector:
        """Create a vector of length size with all values set to fill.

        :param size: The length of the vector to be created.
        """

    @classmethod
    def Linspace(cls, start: float, stop: float, size: int) -> Vector:
        """Create a vector of the specified size which is filled with linearly spaced values between start and stop values.

        :param start: The start of the range used to fill the vector.
        """

    @classmethod
    def Range(cls, start: int, stop: int, step: int) -> Vector:
        """Create a vector filled with a range of values.

        This method can also be called with a single argument, in which case the argument is interpreted as ``stop`` and ``start`` defaults to 0.

        :param start: The start of the range used to fill the vector.
        """

    @classmethod
    def Repeat(cls, vector: Vector | Sequence[float], size: int) -> Vector:
        """Create a vector by repeating the values in vector until the required size is reached.

        :param vector: The vector to draw values from.
        """

    def __add__(self, value: object, /) -> Vector:
        """Return self+value."""

    def __delitem__(self, key: int | slice) -> None:
        """Delete self[key]."""

    @override
    def __eq__(self, value: object, /) -> bool:
        """Return self==value."""

    def __ge__(self, value: object, /) -> bool:
        """Return self>=value."""

    def __getitem__(self, key: int | slice) -> float:
        """Return self[key]."""

    def __gt__(self, value: object, /) -> bool:
        """Return self>value."""

    def __iadd__(self, value: object, /) -> Vector:
        """Return self+=value."""

    def __imatmul__(self, value: object, /) -> None:
        """Return self@=value."""

    def __imul__(self, value: object, /) -> Vector:
        """Return self*=value."""

    def __isub__(self, value: object, /) -> Vector:
        """Return self-=value."""

    def __itruediv__(self, value: object, /) -> Vector:
        """Return self/=value."""

    def __le__(self, value: object, /) -> bool:
        """Return self<=value."""

    def __len__(self) -> int:
        """Return len(self)."""

    def __lt__(self, value: object, /) -> bool:
        """Return self<value."""

    def __matmul__(self, value: object, /) -> float:
        """Return self@value."""

    def __mul__(self, value: object, /) -> Vector:
        """Return self*value."""

    @override
    def __ne__(self, value: object, /) -> bool:
        """Return self!=value."""

    def __neg__(self) -> Vector:
        """-self"""

    def __pos__(self) -> Vector:
        """+self"""

    def __radd__(self, value: object, /) -> Vector:
        """Return value+self."""

    def __rmatmul__(self, value: object, /) -> float:
        """Return value@self."""

    def __rmul__(self, value: object, /) -> Vector:
        """Return value*self."""

    def __rsub__(self, value: object, /) -> Vector:
        """Return value-self."""

    def __rtruediv__(self, value: object, /) -> None:
        """Return value/self."""

    def __setitem__(
        self, key: int | slice, value: float | Sequence[float] | Vector
    ) -> None:
        """Set self[key] to value."""

    def __sub__(self, value: object, /) -> Vector:
        """Return self-value."""

    def __truediv__(self, value: object, /) -> Vector:
        """Return self/value."""

    def angle(
        self, other: Vector | Sequence[float], fallback: object | None = None, /
    ) -> float | object:
        """Return the angle between two vectors.

        :param other: another vector to compare the angle with
        """

    def angle_signed(
        self, other: Vector | Sequence[float], fallback: object | None = None, /
    ) -> float | object:
        """Return the signed angle between two 2D vectors (clockwise is positive).

        :param other: another vector to compare the angle with
        """

    def copy(self) -> Vector:
        """Returns a copy of this vector."""

    def cross(self, other: Vector | Sequence[float], /) -> Vector | float:
        """Return the cross product of this vector and another.

        :param other: The other vector to perform the cross product with.
        """

    def dot(self, other: Vector | Sequence[float], /) -> float:
        """Return the dot product of this vector and another.

        :param other: The other vector to perform the dot product with.
        """

    def freeze(self) -> Self:
        """Make this object immutable.

        After this the object can be hashed, used in dictionaries & sets.
        """

    def lerp(self, other: Vector | Sequence[float], factor: float, /) -> Vector:
        """Returns the interpolation of two vectors.

        :param other: value to interpolate with.
        """

    def negate(self) -> None:
        """Set all values to their negative."""

    def normalize(self) -> None:
        """Normalize the vector, making the length of the vector always 1.0."""

    def normalized(self) -> Vector:
        """Return a new, normalized vector."""

    def orthogonal(self) -> Vector:
        """Return a perpendicular vector."""

    def project(self, other: Vector | Sequence[float], /) -> Vector:
        """Return the projection of this vector onto the *other*.

        :param other: second vector.
        """

    def reflect(self, mirror: Vector | Sequence[float], /) -> Vector:
        """Return the reflection vector from the *mirror* argument.

        :param mirror: This vector could be a normal from the reflecting surface.
        """

    def resize(self, size: int, /) -> None:
        """Resize the vector to have size number of elements.

        :param size: The new size of the vector.
        """

    def resize_2d(self) -> None:
        """Resize the vector to 2D (x, y)."""

    def resize_3d(self) -> None:
        """Resize the vector to 3D (x, y, z)."""

    def resize_4d(self) -> None:
        """Resize the vector to 4D (x, y, z, w)."""

    def resized(self, size: int, /) -> Vector:
        """Return a resized copy of the vector with size number of elements.

        :param size: The new size of the vector.
        """

    def rotate(self, other: Euler | Quaternion | Matrix, /) -> None:
        """Rotate the vector by a rotation value.

        :param other: rotation component of mathutils value
        """

    def rotation_difference(self, other: Vector | Sequence[float], /) -> Quaternion:
        """Returns a quaternion representing the rotational difference between this
        vector and another.

        :param other: second vector.
        """

    def slerp(
        self,
        other: Vector | Sequence[float],
        factor: float,
        fallback: object | None = None,
        /,
    ) -> Vector:
        """Returns the interpolation of two non-zero vectors (spherical coordinates).

        :param other: value to interpolate with.
        """

    def to_2d(self) -> Vector:
        """Return a 2d copy of the vector."""

    def to_3d(self) -> Vector:
        """Return a 3d copy of the vector."""

    def to_4d(self) -> Vector:
        """Return a 4d copy of the vector."""

    def to_track_quat(
        self, track: object = "Z", up: Literal["X", "Y", "Z"] = "Y", /
    ) -> Quaternion:
        """Return a quaternion rotation from the vector and the track and up axis.

        :param track: Track axis string.
        """

    def to_tuple(self, precision: int = -1, /) -> tuple[float, ...]:
        """Return this vector as a tuple with a given precision.

        :param precision: The number to round the value to in [-1, 21].
        """

    def zero(self) -> None:
        """Set all values to zero."""

    def __iter__(self) -> Iterator[float]: ...
    def __buffer__(self, flags: int, /) -> memoryview: ...
