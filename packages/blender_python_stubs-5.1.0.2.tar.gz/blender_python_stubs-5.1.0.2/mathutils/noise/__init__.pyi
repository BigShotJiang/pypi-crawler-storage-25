"""The Blender noise module."""

from collections.abc import Sequence
from typing import Literal
import mathutils

def cell(position: mathutils.Vector | Sequence[float], /) -> float:
    """Returns cell noise value at the specified position.

    :param position: The position to evaluate the cell noise at.
    """

def cell_vector(position: mathutils.Vector | Sequence[float], /) -> mathutils.Vector:
    """Returns cell noise vector at the specified position.

    :param position: The position to evaluate the cell noise at.
    """

def fractal(
    position: mathutils.Vector | Sequence[float],
    H: float,
    lacunarity: float,
    octaves: float,
    /,
    *,
    noise_basis: Literal[
        "BLENDER",
        "PERLIN_ORIGINAL",
        "PERLIN_NEW",
        "VORONOI_F1",
        "VORONOI_F2",
        "VORONOI_F3",
        "VORONOI_F4",
        "VORONOI_F2F1",
        "VORONOI_CRACKLE",
        "CELLNOISE",
    ] = "PERLIN_ORIGINAL",
) -> float:
    """Returns the fractal Brownian motion (fBm) noise value from the noise basis at the specified position.

    :param position: The position to evaluate the selected noise function.
    """

def hetero_terrain(
    position: mathutils.Vector | Sequence[float],
    H: float,
    lacunarity: float,
    octaves: float,
    offset: float,
    /,
    *,
    noise_basis: Literal[
        "BLENDER",
        "PERLIN_ORIGINAL",
        "PERLIN_NEW",
        "VORONOI_F1",
        "VORONOI_F2",
        "VORONOI_F3",
        "VORONOI_F4",
        "VORONOI_F2F1",
        "VORONOI_CRACKLE",
        "CELLNOISE",
    ] = "PERLIN_ORIGINAL",
) -> float:
    """Returns the heterogeneous terrain value from the noise basis at the specified position.

    :param position: The position to evaluate the selected noise function.
    """

def hybrid_multi_fractal(
    position: mathutils.Vector | Sequence[float],
    H: float,
    lacunarity: float,
    octaves: float,
    offset: float,
    gain: float,
    /,
    *,
    noise_basis: Literal[
        "BLENDER",
        "PERLIN_ORIGINAL",
        "PERLIN_NEW",
        "VORONOI_F1",
        "VORONOI_F2",
        "VORONOI_F3",
        "VORONOI_F4",
        "VORONOI_F2F1",
        "VORONOI_CRACKLE",
        "CELLNOISE",
    ] = "PERLIN_ORIGINAL",
) -> float:
    """Returns hybrid multifractal value from the noise basis at the specified position.

    :param position: The position to evaluate the selected noise function.
    """

def multi_fractal(
    position: mathutils.Vector | Sequence[float],
    H: float,
    lacunarity: float,
    octaves: float,
    /,
    *,
    noise_basis: Literal[
        "BLENDER",
        "PERLIN_ORIGINAL",
        "PERLIN_NEW",
        "VORONOI_F1",
        "VORONOI_F2",
        "VORONOI_F3",
        "VORONOI_F4",
        "VORONOI_F2F1",
        "VORONOI_CRACKLE",
        "CELLNOISE",
    ] = "PERLIN_ORIGINAL",
) -> float:
    """Returns multifractal noise value from the noise basis at the specified position.

    :param position: The position to evaluate the selected noise function.
    """

def noise(
    position: mathutils.Vector | Sequence[float],
    /,
    *,
    noise_basis: Literal[
        "BLENDER",
        "PERLIN_ORIGINAL",
        "PERLIN_NEW",
        "VORONOI_F1",
        "VORONOI_F2",
        "VORONOI_F3",
        "VORONOI_F4",
        "VORONOI_F2F1",
        "VORONOI_CRACKLE",
        "CELLNOISE",
    ] = "PERLIN_ORIGINAL",
) -> float:
    """Returns noise value from the noise basis at the position specified.

    :param position: The position to evaluate the selected noise function.
    """

def noise_vector(
    position: mathutils.Vector | Sequence[float],
    /,
    *,
    noise_basis: Literal[
        "BLENDER",
        "PERLIN_ORIGINAL",
        "PERLIN_NEW",
        "VORONOI_F1",
        "VORONOI_F2",
        "VORONOI_F3",
        "VORONOI_F4",
        "VORONOI_F2F1",
        "VORONOI_CRACKLE",
        "CELLNOISE",
    ] = "PERLIN_ORIGINAL",
) -> mathutils.Vector:
    """Returns the noise vector from the noise basis at the specified position.

    :param position: The position to evaluate the selected noise function.
    """

def random() -> float:
    """Returns a random number in the range [0, 1)."""

def random_unit_vector(*, size: int = 3) -> mathutils.Vector:
    """Returns a unit vector with random entries.

    :param size: The size of the vector to be produced, in the range [2, 4].
    """

def random_vector(*, size: int = 3) -> mathutils.Vector:
    """Returns a vector with random entries in the range (-1, 1).

    :param size: The size of the vector to be produced, must be 2 or greater.
    """

def ridged_multi_fractal(
    position: mathutils.Vector | Sequence[float],
    H: float,
    lacunarity: float,
    octaves: float,
    offset: float,
    gain: float,
    /,
    *,
    noise_basis: Literal[
        "BLENDER",
        "PERLIN_ORIGINAL",
        "PERLIN_NEW",
        "VORONOI_F1",
        "VORONOI_F2",
        "VORONOI_F3",
        "VORONOI_F4",
        "VORONOI_F2F1",
        "VORONOI_CRACKLE",
        "CELLNOISE",
    ] = "PERLIN_ORIGINAL",
) -> float:
    """Returns ridged multifractal value from the noise basis at the specified position.

    :param position: The position to evaluate the selected noise function.
    """

def seed_set(seed: int, /) -> None:
    """Sets the random seed used for random_unit_vector, random_vector, and random.

    :param seed: Seed used for the random generator.
       When seed is zero, the current time will be used instead.
    """

def turbulence(
    position: mathutils.Vector | Sequence[float],
    octaves: int,
    hard: bool,
    /,
    *,
    noise_basis: Literal[
        "BLENDER",
        "PERLIN_ORIGINAL",
        "PERLIN_NEW",
        "VORONOI_F1",
        "VORONOI_F2",
        "VORONOI_F3",
        "VORONOI_F4",
        "VORONOI_F2F1",
        "VORONOI_CRACKLE",
        "CELLNOISE",
    ] = "PERLIN_ORIGINAL",
    amplitude_scale: float = 0.5,
    frequency_scale: float = 2.0,
) -> float:
    """Returns the turbulence value from the noise basis at the specified position.

    :param position: The position to evaluate the selected noise function.
    """

def turbulence_vector(
    position: mathutils.Vector | Sequence[float],
    octaves: int,
    hard: bool,
    /,
    *,
    noise_basis: Literal[
        "BLENDER",
        "PERLIN_ORIGINAL",
        "PERLIN_NEW",
        "VORONOI_F1",
        "VORONOI_F2",
        "VORONOI_F3",
        "VORONOI_F4",
        "VORONOI_F2F1",
        "VORONOI_CRACKLE",
        "CELLNOISE",
    ] = "PERLIN_ORIGINAL",
    amplitude_scale: float = 0.5,
    frequency_scale: float = 2.0,
) -> mathutils.Vector:
    """Returns the turbulence vector from the noise basis at the specified position.

    :param position: The position to evaluate the selected noise function.
    """

def variable_lacunarity(
    position: mathutils.Vector | Sequence[float],
    distortion: float,
    /,
    *,
    noise_type1: Literal[
        "BLENDER",
        "PERLIN_ORIGINAL",
        "PERLIN_NEW",
        "VORONOI_F1",
        "VORONOI_F2",
        "VORONOI_F3",
        "VORONOI_F4",
        "VORONOI_F2F1",
        "VORONOI_CRACKLE",
        "CELLNOISE",
    ] = "PERLIN_ORIGINAL",
    noise_type2: Literal[
        "BLENDER",
        "PERLIN_ORIGINAL",
        "PERLIN_NEW",
        "VORONOI_F1",
        "VORONOI_F2",
        "VORONOI_F3",
        "VORONOI_F4",
        "VORONOI_F2F1",
        "VORONOI_CRACKLE",
        "CELLNOISE",
    ] = "PERLIN_ORIGINAL",
) -> float:
    """Returns variable lacunarity noise value, a distorted variety of noise, from noise type 1 distorted by noise type 2 at the specified position.

    :param position: The position to evaluate the selected noise function.
    """

def voronoi(
    position: mathutils.Vector | Sequence[float],
    /,
    *,
    distance_metric: Literal[
        "DISTANCE",
        "DISTANCE_SQUARED",
        "MANHATTAN",
        "CHEBYCHEV",
        "MINKOVSKY",
        "MINKOVSKY_HALF",
        "MINKOVSKY_FOUR",
    ] = "DISTANCE",
    exponent: float = 2.5,
) -> list[list[float] | list[mathutils.Vector]]:
    """Returns a list of distances to the four closest features and their locations.

    :param position: The position to evaluate the selected noise function.
    """
