"""The Blender geometry module."""

from collections.abc import Sequence
import mathutils

def area_tri(
    v1: mathutils.Vector | Sequence[float],
    v2: mathutils.Vector | Sequence[float],
    v3: mathutils.Vector | Sequence[float],
    /,
) -> float:
    """Returns the area of the 2D or 3D triangle defined.

    :param v1: Point1
    """

def barycentric_transform(
    point: mathutils.Vector | Sequence[float],
    tri_a1: mathutils.Vector | Sequence[float],
    tri_a2: mathutils.Vector | Sequence[float],
    tri_a3: mathutils.Vector | Sequence[float],
    tri_b1: mathutils.Vector | Sequence[float],
    tri_b2: mathutils.Vector | Sequence[float],
    tri_b3: mathutils.Vector | Sequence[float],
    /,
) -> mathutils.Vector:
    """Return a transformed point, the transformation is defined by 2 triangles.

    :param point: The point to transform.
    """

def box_fit_2d(points: Sequence[Sequence[float]], /) -> float:
    """Returns an angle that best fits the points to an axis aligned rectangle

    :param points: Sequence of 2D points.
    """

def box_pack_2d(boxes: list[list[float]], /) -> tuple[float, float]:
    """Returns a tuple with the width and height of the packed bounding box.

    :param boxes: list of boxes, each box is a list where the first 4 items are [X, Y, width, height, ...] other items are ignored. The X & Y values in this list are modified to set the packed positions.
    """

def closest_point_on_tri(
    pt: mathutils.Vector | Sequence[float],
    tri_p1: mathutils.Vector | Sequence[float],
    tri_p2: mathutils.Vector | Sequence[float],
    tri_p3: mathutils.Vector | Sequence[float],
    /,
) -> mathutils.Vector:
    """Takes 4 vectors: one is the point and the next 3 define the triangle.

    :param pt: Point
    """

def convex_hull_2d(points: Sequence[Sequence[float]], /) -> list[int]:
    """Returns the indices of the points forming the convex hull, in counter-clockwise order.

    :param points: Sequence of 2D points.
    """

def delaunay_2d_cdt(
    vert_coords: Sequence[mathutils.Vector],
    edges: Sequence[tuple[int, int]],
    faces: Sequence[Sequence[int]],
    output_type: int,
    epsilon: float,
    need_ids: bool = True,
    /,
) -> tuple[
    list[mathutils.Vector],
    list[tuple[int, int]],
    list[list[int]],
    list[list[int]],
    list[list[int]],
    list[list[int]],
]:
    """Computes the Constrained Delaunay Triangulation of a set of vertices,
    with edges and faces that must appear in the triangulation.
    Some triangles may be eaten away, or combined with other triangles,
    according to output type.
    The returned verts may be in a different order from input verts, may be moved
    slightly, and may be merged with other nearby verts.
    The three returned orig lists give, for each of verts, edges, and faces, the list of
    input element indices corresponding to the positionally same output element.
    For edges, the orig indices start with the input edges and then continue
    with the edges implied by each of the faces (n of them for an n-gon).
    If the need_ids argument is supplied, and False, then the code skips the preparation
    of the orig arrays, which may save some time.

    :param vert_coords: Vertex coordinates (2d)
    """

def distance_point_to_plane(
    pt: mathutils.Vector | Sequence[float],
    plane_co: mathutils.Vector | Sequence[float],
    plane_no: mathutils.Vector | Sequence[float],
    /,
) -> float:
    """Returns the signed distance between a point and a plane (negative when below the normal).

    :param pt: Point
    """

def interpolate_bezier(
    knot1: mathutils.Vector | Sequence[float],
    handle1: mathutils.Vector | Sequence[float],
    handle2: mathutils.Vector | Sequence[float],
    knot2: mathutils.Vector | Sequence[float],
    resolution: int,
    /,
) -> list[mathutils.Vector]:
    """Interpolate a bezier spline segment.

    :param knot1: First bezier spline point.
    """

def intersect_line_line(
    v1: mathutils.Vector | Sequence[float],
    v2: mathutils.Vector | Sequence[float],
    v3: mathutils.Vector | Sequence[float],
    v4: mathutils.Vector | Sequence[float],
    /,
) -> tuple[mathutils.Vector, mathutils.Vector] | None:
    """Returns a tuple with the points on each line respectively closest to the other.

    :param v1: First point of the first line
    """

def intersect_line_line_2d(
    lineA_p1: mathutils.Vector | Sequence[float],
    lineA_p2: mathutils.Vector | Sequence[float],
    lineB_p1: mathutils.Vector | Sequence[float],
    lineB_p2: mathutils.Vector | Sequence[float],
    /,
) -> mathutils.Vector | None:
    """Takes 2 segments (defined by 4 vectors) and returns a vector for their point of intersection or None.

    :param lineA_p1: First point of the first segment
    """

def intersect_line_plane(
    line_a: mathutils.Vector | Sequence[float],
    line_b: mathutils.Vector | Sequence[float],
    plane_co: mathutils.Vector | Sequence[float],
    plane_no: mathutils.Vector | Sequence[float],
    no_flip: bool = False,
    /,
) -> mathutils.Vector | None:
    """Calculate the intersection between a line (as 2 vectors) and a plane.
    Returns a vector for the intersection or None.

    :param line_a: First point of the line
    """

def intersect_line_sphere(
    line_a: mathutils.Vector | Sequence[float],
    line_b: mathutils.Vector | Sequence[float],
    sphere_co: mathutils.Vector | Sequence[float],
    sphere_radius: float,
    clip: bool = True,
    /,
) -> tuple[mathutils.Vector | None, mathutils.Vector | None]:
    """Takes a line (as 2 points) and a sphere (as a point and a radius) and
    returns the intersection

    :param line_a: First point of the line
    """

def intersect_line_sphere_2d(
    line_a: mathutils.Vector | Sequence[float],
    line_b: mathutils.Vector | Sequence[float],
    sphere_co: mathutils.Vector | Sequence[float],
    sphere_radius: float,
    clip: bool = True,
    /,
) -> tuple[mathutils.Vector | None, mathutils.Vector | None]:
    """Takes a line (as 2 points) and a circle (as a point and a radius) and
    returns the intersection

    :param line_a: First point of the line
    """

def intersect_plane_plane(
    plane_a_co: mathutils.Vector | Sequence[float],
    plane_a_no: mathutils.Vector | Sequence[float],
    plane_b_co: mathutils.Vector | Sequence[float],
    plane_b_no: mathutils.Vector | Sequence[float],
    /,
) -> tuple[mathutils.Vector, mathutils.Vector] | tuple[None, None]:
    """Return the intersection between two planes

    :param plane_a_co: Point on the first plane
    """

def intersect_point_line(
    pt: mathutils.Vector | Sequence[float],
    line_p1: mathutils.Vector | Sequence[float],
    line_p2: mathutils.Vector | Sequence[float],
    /,
) -> tuple[mathutils.Vector, float]:
    """Takes a point and a line and returns the closest point on the line and its parametric distance from the first point of the line. A value of 0.0 is the first point, 1.0 is the second, values outside [0, 1] are extrapolated.

    :param pt: Point
    """

def intersect_point_line_segment(
    pt: mathutils.Vector | Sequence[float],
    seg_p1: mathutils.Vector | Sequence[float],
    seg_p2: mathutils.Vector | Sequence[float],
    /,
) -> tuple[mathutils.Vector, float]:
    """Takes a point and a segment and returns the closest point on the segment and the distance to the segment.

    :param pt: Point
    """

def intersect_point_quad_2d(
    pt: mathutils.Vector | Sequence[float],
    quad_p1: mathutils.Vector | Sequence[float],
    quad_p2: mathutils.Vector | Sequence[float],
    quad_p3: mathutils.Vector | Sequence[float],
    quad_p4: mathutils.Vector | Sequence[float],
    /,
) -> int:
    """Takes 5 vectors (using only the x and y coordinates): one is the point and the next 4 define the quad,
    only the x and y are used from the vectors. Returns a non-zero value if the point is within the quad, otherwise 0.
    Works only with convex quads without singular edges.

    :param pt: Point
    """

def intersect_point_tri(
    pt: mathutils.Vector | Sequence[float],
    tri_p1: mathutils.Vector | Sequence[float],
    tri_p2: mathutils.Vector | Sequence[float],
    tri_p3: mathutils.Vector | Sequence[float],
    /,
) -> mathutils.Vector | None:
    """Takes 4 vectors: one is the point and the next 3 define the triangle. Projects the point onto the triangle plane and checks if it is within the triangle.

    :param pt: Point
    """

def intersect_point_tri_2d(
    pt: mathutils.Vector | Sequence[float],
    tri_p1: mathutils.Vector | Sequence[float],
    tri_p2: mathutils.Vector | Sequence[float],
    tri_p3: mathutils.Vector | Sequence[float],
    /,
) -> int:
    """Takes 4 vectors (using only the x and y coordinates): one is the point and the next 3 define the triangle. Returns a non-zero value if the point is within the triangle, otherwise 0.

    :param pt: Point
    """

def intersect_ray_tri(
    v1: mathutils.Vector | Sequence[float],
    v2: mathutils.Vector | Sequence[float],
    v3: mathutils.Vector | Sequence[float],
    ray: mathutils.Vector | Sequence[float],
    orig: mathutils.Vector | Sequence[float],
    clip: bool = True,
    /,
) -> mathutils.Vector | None:
    """Returns the intersection between a ray and a triangle, if possible, returns None otherwise.

    :param v1: Point1
    """

def intersect_sphere_sphere_2d(
    p_a: mathutils.Vector | Sequence[float],
    radius_a: float,
    p_b: mathutils.Vector | Sequence[float],
    radius_b: float,
    /,
) -> tuple[mathutils.Vector, mathutils.Vector] | tuple[None, None]:
    """Returns the 2 intersection points of two circles.

    :param p_a: Center of the first circle
    """

def intersect_tri_tri_2d(
    tri_a1: mathutils.Vector | Sequence[float],
    tri_a2: mathutils.Vector | Sequence[float],
    tri_a3: mathutils.Vector | Sequence[float],
    tri_b1: mathutils.Vector | Sequence[float],
    tri_b2: mathutils.Vector | Sequence[float],
    tri_b3: mathutils.Vector | Sequence[float],
    /,
) -> bool:
    """Check if two 2D triangles intersect.

    :param tri_a1: First vertex of the first triangle.
    """

def normal(*vectors: Sequence[Sequence[float]]) -> mathutils.Vector:
    """Returns the normal of a 3D polygon.

    :param vectors: 3 or more vectors to calculate normals.
    """

def points_in_planes(
    planes: list[mathutils.Vector],
    epsilon_coplanar: float = 1e-4,
    epsilon_isect: float = 1e-6,
    /,
) -> tuple[list[mathutils.Vector], list[int]]:
    """Returns a list of points inside all planes given and a list of index values for the planes used.

    :param planes: List of planes (4D vectors).
    """

def tessellate_polygon(
    polylines: Sequence[Sequence[Sequence[float]]], /
) -> list[tuple[int, int, int]]:
    """Takes a list of polylines (each point a pair or triplet of numbers) and returns the point indices for a polyline filled with triangles. Does not handle degenerate geometry (such as zero-length lines due to consecutive identical points).

    :param polylines: Polygons where each polygon is a sequence of 2D or 3D points.
    """

def volume_tetrahedron(
    v1: mathutils.Vector | Sequence[float],
    v2: mathutils.Vector | Sequence[float],
    v3: mathutils.Vector | Sequence[float],
    v4: mathutils.Vector | Sequence[float],
    /,
) -> float:
    """Return the absolute (unsigned) volume formed by a tetrahedron (points can be in any order).

    :param v1: Point1
    """
