"""The Blender interpolate module."""

from collections.abc import Sequence

def poly_3d_calc(
    veclist: Sequence[Sequence[float]], pt: Sequence[float], /
) -> list[float]:
    """Calculate barycentric weights for a point on a polygon.

    :param veclist: Sequence of 3D positions.
    """
