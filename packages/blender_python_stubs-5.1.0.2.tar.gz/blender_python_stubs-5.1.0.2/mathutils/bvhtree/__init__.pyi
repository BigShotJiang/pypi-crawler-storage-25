"""BVH tree structures for proximity searches and ray casts on geometry."""

from collections.abc import Sequence
import bmesh
import bmesh.types
import bpy.types
import mathutils

class BVHTree:
    @classmethod
    def FromBMesh(cls, bmesh: bmesh.types.BMesh, epsilon: float) -> BVHTree:
        """BVH tree based on :class:`BMesh` data.

        :param bmesh: BMesh data.
        """

    @classmethod
    def FromObject(
        cls,
        object: bpy.types.Object,
        depsgraph: bpy.types.Depsgraph,
        deform: bool,
        cage: bool,
        epsilon: float,
    ) -> BVHTree:
        """BVH tree based on :class:`Object` data.

        :param object: Mesh object.
        """

    @classmethod
    def FromPolygons(
        cls,
        vertices: Sequence[Sequence[float]],
        polygons: Sequence[Sequence[int]],
        all_triangles: bool,
        epsilon: float,
    ) -> BVHTree:
        """BVH tree constructed from geometry passed in as arguments.

        :param vertices: float triplets each representing ``(x, y, z)`` coordinates.
        """

    def find_nearest(
        self, origin: mathutils.Vector | Sequence[float], distance: float = ..., /
    ) -> tuple[
        mathutils.Vector | None, mathutils.Vector | None, int | None, float | None
    ]:
        """Find the nearest element (typically face index) to a point.

        :param origin: Find nearest element to this point.
        """

    def find_nearest_range(
        self, origin: mathutils.Vector | Sequence[float], distance: float = ..., /
    ) -> list[tuple[mathutils.Vector, mathutils.Vector, int, float]]:
        """Find the nearest elements (typically face index) to a point in the distance range.

        :param origin: Find nearest elements to this point.
        """

    def overlap(self, other_tree: BVHTree, /) -> list[tuple[int, int]]:
        """Find overlapping indices between 2 trees.

        :param other_tree: Other tree to perform overlap test on.
        """

    def ray_cast(
        self,
        origin: mathutils.Vector | Sequence[float],
        direction: mathutils.Vector | Sequence[float],
        distance: float = ...,
        /,
    ) -> tuple[
        mathutils.Vector | None, mathutils.Vector | None, int | None, float | None
    ]:
        """Cast a ray onto the geometry.

        :param origin: Start location of the ray.
        """
