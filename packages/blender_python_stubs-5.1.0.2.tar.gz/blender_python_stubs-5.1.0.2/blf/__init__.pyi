"""This module provides access to Blender's text drawing functions."""

import imbuf.types

CLIPPING: int

MONOCHROME: int

ROTATION: int

SHADOW: int

WORD_WRAP: int

def aspect(fontid: int, aspect: float) -> None:
    """Set the aspect for drawing text.

    :param fontid: The id of the typeface as returned by :func:`blf.load`, for default font use 0.
    """

def bind_imbuf(
    fontid: int, imbuf: imbuf.types.ImBuf, *, display_name: str | None = None
) -> object:
    """Context manager to draw text into an image buffer instead of the GPU's context.

    :param fontid: The id of the typeface as returned by :func:`blf.load`, for default font use 0.
    """

def clipping(fontid: int, xmin: float, ymin: float, xmax: float, ymax: float) -> None:
    """Set the clipping, enable/disable using :data:`CLIPPING`.

    :param fontid: The id of the typeface as returned by :func:`blf.load`, for default font use 0.
    """

def color(fontid: int, r: float, g: float, b: float, a: float) -> None:
    """Set the color for drawing text.

    :param fontid: The id of the typeface as returned by :func:`blf.load`, for default font use 0.
    """

def dimensions(fontid: int, text: str) -> tuple[float, float]:
    """Return the width and height of the text.

    :param fontid: The id of the typeface as returned by :func:`blf.load`, for default font use 0.
    """

def disable(fontid: int, option: int) -> None:
    """Disable a font drawing option.

    :param fontid: The id of the typeface as returned by :func:`blf.load`, for default font use 0.
    """

def draw(fontid: int, text: str) -> None:
    """Draw text in the current context.

    :param fontid: The id of the typeface as returned by :func:`blf.load`, for default font use 0.
    """

def draw_buffer(fontid: int, text: str) -> None:
    """Draw text into the image buffer bound via :func:`blf.bind_imbuf`.

    :param fontid: The id of the typeface as returned by :func:`blf.load`, for default font use 0.
    """

def enable(fontid: int, option: int) -> None:
    """Enable a font drawing option.

    :param fontid: The id of the typeface as returned by :func:`blf.load`, for default font use 0.
    """

def load(filepath: str | bytes) -> int:
    """Load a new font.

    :param filepath: The filepath of the font.
    """

def position(fontid: int, x: float, y: float, z: float) -> None:
    """Set the position for drawing text.

    :param fontid: The id of the typeface as returned by :func:`blf.load`, for default font use 0.
    """

def rotation(fontid: int, angle: float) -> None:
    """Set the text rotation angle, enable/disable using :data:`ROTATION`.

    :param fontid: The id of the typeface as returned by :func:`blf.load`, for default font use 0.
    """

def shadow(fontid: int, level: int, r: float, g: float, b: float, a: float) -> None:
    """Shadow options, enable/disable using :data:`SHADOW`.

    :param fontid: The id of the typeface as returned by :func:`blf.load`, for default font use 0.
    """

def shadow_offset(fontid: int, x: int, y: int) -> None:
    """Set the offset for shadow text, enable/disable using :data:`SHADOW`.

    :param fontid: The id of the typeface as returned by :func:`blf.load`, for default font use 0.
    """

def size(fontid: int, size: float) -> None:
    """Set the size for drawing text.

    :param fontid: The id of the typeface as returned by :func:`blf.load`, for default font use 0.
    """

def unload(filepath: str | bytes) -> None:
    """Unload an existing font.

    :param filepath: The filepath of the font.
    """

def word_wrap(fontid: int, wrap_width: int) -> None:
    """Set the wrap width, enable/disable using :data:`WORD_WRAP`.

    :param fontid: The id of the typeface as returned by :func:`blf.load`, for default font use 0.
    """
