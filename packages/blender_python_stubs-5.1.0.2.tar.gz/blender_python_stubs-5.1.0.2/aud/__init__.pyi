import collections.abc

"""Audaspace (pronounced "outer space") is a high level audio library."""

from typing import Generic, TypeVar

_T = TypeVar("_T")

AP_LOCATION: int

AP_ORIENTATION: int

AP_PANNING: int

AP_PITCH: int

AP_PITCH_SCALE: int

AP_TIME_STRETCH: int

AP_VOLUME: int

CHANNELS_INVALID: int

CHANNELS_MONO: int

CHANNELS_STEREO: int

CHANNELS_STEREO_LFE: int

CHANNELS_SURROUND4: int

CHANNELS_SURROUND5: int

CHANNELS_SURROUND51: int

CHANNELS_SURROUND61: int

CHANNELS_SURROUND71: int

CODEC_AAC: int

CODEC_AC3: int

CODEC_FLAC: int

CODEC_INVALID: int

CODEC_MP2: int

CODEC_MP3: int

CODEC_OPUS: int

CODEC_PCM: int

CODEC_VORBIS: int

CONTAINER_AAC: int

CONTAINER_AC3: int

CONTAINER_FLAC: int

CONTAINER_INVALID: int

CONTAINER_MATROSKA: int

CONTAINER_MP2: int

CONTAINER_MP3: int

CONTAINER_OGG: int

CONTAINER_WAV: int

DISTANCE_MODEL_EXPONENT: int

DISTANCE_MODEL_EXPONENT_CLAMPED: int

DISTANCE_MODEL_INVALID: int

DISTANCE_MODEL_INVERSE: int

DISTANCE_MODEL_INVERSE_CLAMPED: int

DISTANCE_MODEL_LINEAR: int

DISTANCE_MODEL_LINEAR_CLAMPED: int

FORMAT_FLOAT32: int

FORMAT_FLOAT64: int

FORMAT_INVALID: int

FORMAT_S16: int

FORMAT_S24: int

FORMAT_S32: int

FORMAT_U8: int

RATE_11025: int

RATE_16000: int

RATE_192000: int

RATE_22050: int

RATE_32000: int

RATE_44100: int

RATE_48000: int

RATE_8000: int

RATE_88200: int

RATE_96000: int

RATE_INVALID: int

STATUS_INVALID: int

STATUS_PAUSED: int

STATUS_PLAYING: int

STATUS_STOPPED: int

STRETCHER_QUALITY_CONSISTENT: int

STRETCHER_QUALITY_FAST: int

STRETCHER_QUALITY_HIGH: int

class AnimateableProperty:
    """An AnimateableProperty object stores an array of float values for animating sound properties (e.g. pan, volume, pitch-scale)"""

    animated: object
    """Whether the property is animated."""

    count: object
    """The count of floats for a property."""

    def read(self, position: float) -> object:
        """Reads the properties value at the given position.

        :param position: The position in the animation in frames.
        """

    def readSingle(self, position: float) -> float:
        """Reads the properties value at the given position, assuming there is exactly one value.

        :param position: The position in the animation in frames.
        """

    def write(self, data: object, position: int) -> None:
        """Writes the properties value.

        If `position` is also given, the property is marked animated and
        the values are written starting at `position`.

        :param data: numpy array of float32 values.
        """

    def writeConstantRange(
        self, data: object, position_start: int, position_end: int
    ) -> None:
        """Fills the properties frame range with a constant value and marks it animated.

        :param data: numpy array of float values representing the constant value.
        """

class Device:
    """Device objects represent an audio output backend like OpenAL or SDL, but might also represent a file output or RAM buffer output."""

    channels: object
    """The channel count of the device."""

    distance_model: object
    """The distance model of the device.

.. seealso:: `OpenAL Documentation <https://www.openal.org/documentation/>`__"""

    doppler_factor: object
    """The doppler factor of the device.
This factor is a scaling factor for the velocity vectors in doppler calculation. So a value bigger than 1 will exaggerate the effect as it raises the velocity."""

    format: object
    """The native sample format of the device."""

    listener_location: object
    """The listeners's location in 3D space, a 3D tuple of floats."""

    listener_orientation: object
    """The listener's orientation in 3D space as quaternion, a 4 float tuple."""

    listener_velocity: object
    """The listener's velocity in 3D space, a 3D tuple of floats."""

    rate: object
    """The sampling rate of the device in Hz."""

    speed_of_sound: object
    """The speed of sound of the device.
The speed of sound in air is typically 343.3 m/s."""

    volume: object
    """The overall volume of the device."""

    def lock(self) -> None:
        """Locks the device so that it's guaranteed, that no samples are
        read from the streams until :meth:`unlock` is called.
        This is useful if you want to do start/stop/pause/resume some
        sounds at the same time.
        """

    def play(self, sound: Sound, keep: bool = False) -> Handle:
        """Plays a sound."""

    def stopAll(self) -> None:
        """Stops all playing and paused sounds."""

    def unlock(self) -> None:
        """Unlocks the device after a lock call, see :meth:`lock` for
        details.
        """

class DynamicMusic:
    """The DynamicMusic object allows to play music depending on a current scene, scene changes are managed by the class, with the possibility of custom transitions.
    The default transition is a crossfade effect, and the default scene is silent and has id 0
    """

    fadeTime: object
    """The length in seconds of the crossfade transition"""

    position: object
    """The playback position of the scene in seconds."""

    scene: object
    """The current scene"""

    status: object
    """Whether the scene is playing, paused or stopped (=invalid)."""

    volume: object
    """The volume of the scene."""

    def addScene(self, scene: Sound, /) -> int:
        """Adds a new scene."""

    def addTransition(self, ini: int, end: int, transition: Sound) -> bool:
        """Adds a new scene."""

    def pause(self) -> bool:
        """Pauses playback of the scene."""

    def resume(self) -> bool:
        """Resumes playback of the scene."""

    def stop(self) -> bool:
        """Stops playback of the scene."""

class HRTF:
    """An HRTF object represents a set of head related transfer functions as impulse responses. It's used for binaural sound"""

    def addImpulseResponseFromSound(
        self, sound: Sound, azimuth: float, elevation: float
    ) -> bool:
        """Adds a new hrtf to the HRTF object"""

    @classmethod
    def loadLeftHrtfSet(cls, extension: str, directory: object) -> HRTF:
        """Loads all HRTFs from a directory."""

    @classmethod
    def loadRightHrtfSet(cls, extension: str, directory: object) -> HRTF:
        """Loads all HRTFs from a directory."""

class Handle:
    """Handle objects are playback handles that can be used to control playback of a sound. If a sound is played back multiple times then there are as many handles."""

    attenuation: object
    """This factor is used for distance based attenuation of the source.

.. seealso:: :attr:`Device.distance_model`"""

    cone_angle_inner: object
    """The opening angle of the inner cone of the source. If the cone values of a source are set there are two (audible) cones with the apex at the :attr:`location` of the source and with infinite height, heading in the direction of the source's :attr:`orientation`.
In the inner cone the volume is normal. Outside the outer cone the volume will be :attr:`cone_volume_outer` and in the area between the volume will be interpolated linearly."""

    cone_angle_outer: object
    """The opening angle of the outer cone of the source.

.. seealso:: :attr:`cone_angle_inner`"""

    cone_volume_outer: object
    """The volume outside the outer cone of the source.

.. seealso:: :attr:`cone_angle_inner`"""

    distance_maximum: object
    """The maximum distance of the source.
If the listener is further away the source volume will be 0.

.. seealso:: :attr:`Device.distance_model`"""

    distance_reference: object
    """The reference distance of the source.
At this distance the volume will be exactly :attr:`volume`.

.. seealso:: :attr:`Device.distance_model`"""

    keep: object
    """Whether the sound should be kept paused in the device when its end is reached.
This can be used to seek the sound to some position and start playback again.

.. warning:: If this is set to true and you forget stopping this equals a memory leak as the handle exists until the device is destroyed."""

    location: object
    """The source's location in 3D space, a 3D tuple of floats."""

    loop_count: object
    """The (remaining) loop count of the sound. A negative value indicates infinity."""

    orientation: object
    """The source's orientation in 3D space as quaternion, a 4 float tuple."""

    pitch: object
    """The pitch of the sound."""

    position: object
    """The playback position of the sound in seconds."""

    relative: object
    """Whether the source's location, velocity and orientation is relative or absolute to the listener."""

    status: object
    """Whether the sound is playing, paused or stopped (=invalid)."""

    velocity: object
    """The source's velocity in 3D space, a 3D tuple of floats."""

    volume: object
    """The volume of the sound."""

    volume_maximum: object
    """The maximum volume of the source.

.. seealso:: :attr:`Device.distance_model`"""

    volume_minimum: object
    """The minimum volume of the source.

.. seealso:: :attr:`Device.distance_model`"""

    def pause(self) -> bool:
        """Pauses playback."""

    def resume(self) -> bool:
        """Resumes playback."""

    def stop(self) -> bool:
        """Stops playback."""

class ImpulseResponse:
    """An ImpulseResponse object represents a filter with which to convolve a sound."""

class PlaybackManager:
    """A PlabackManager object allows to easily control groups os sounds organized in categories."""

    def addCategory(self, volume: float) -> int:
        """Adds a category with a custom volume."""

    def clean(self) -> None:
        """Cleans all the invalid and finished sound from the playback manager."""

    def getVolume(self, catKey: int) -> float:
        """Retrieves the volume of a category."""

    def pause(self, catKey: int) -> bool:
        """Pauses playback of the category."""

    def play(self, sound: Sound, catKey: int) -> Handle:
        """Plays a sound through the playback manager and assigns it to a category."""

    def resume(self, catKey: int) -> bool:
        """Resumes playback of the catgory."""

    def setVolume(self, volume: float, catKey: int) -> int:
        """Changes the volume of a category."""

    def stop(self, catKey: int) -> bool:
        """Stops playback of the category."""

class Sequence(Sound, Generic[_T]):
    """This sound represents sequenced entries to play a sound sequence."""

    channels: object
    """The channel count of the sequence."""

    distance_model: object
    """The distance model of the sequence.

.. seealso:: `OpenAL Documentation <https://www.openal.org/documentation/>`__"""

    doppler_factor: object
    """The doppler factor of the sequence.
This factor is a scaling factor for the velocity vectors in doppler calculation. So a value bigger than 1 will exaggerate the effect as it raises the velocity."""

    fps: object
    """The listeners's location in 3D space, a 3D tuple of floats."""

    muted: object
    """Whether the whole sequence is muted."""

    rate: object
    """The sampling rate of the sequence in Hz."""

    speed_of_sound: object
    """The speed of sound of the sequence.
The speed of sound in air is typically 343.3 m/s."""

    def add(self, sound: Sound, begin: float, end: float, skip: float) -> SequenceEntry:
        """Adds a new entry to the sequence."""

    def remove(self, entry: SequenceEntry) -> None:
        """Removes an entry from the sequence."""

    def setAnimationData(
        self,
        type: int,
        frame: int,
        data: collections.abc.Sequence[float],
        animated: bool,
    ) -> None:
        """Writes animation data to a sequence."""

class SequenceEntry:
    """SequenceEntry objects represent an entry of a sequenced sound."""

    attenuation: object
    """This factor is used for distance based attenuation of the source.

.. seealso:: :attr:`Device.distance_model`"""

    cone_angle_inner: object
    """The opening angle of the inner cone of the source. If the cone values of a source are set there are two (audible) cones with the apex at the :attr:`location` of the source and with infinite height, heading in the direction of the source's :attr:`orientation`.
In the inner cone the volume is normal. Outside the outer cone the volume will be :attr:`cone_volume_outer` and in the area between the volume will be interpolated linearly."""

    cone_angle_outer: object
    """The opening angle of the outer cone of the source.

.. seealso:: :attr:`cone_angle_inner`"""

    cone_volume_outer: object
    """The volume outside the outer cone of the source.

.. seealso:: :attr:`cone_angle_inner`"""

    distance_maximum: object
    """The maximum distance of the source.
If the listener is further away the source volume will be 0.

.. seealso:: :attr:`Device.distance_model`"""

    distance_reference: object
    """The reference distance of the source.
At this distance the volume will be exactly :attr:`volume`.

.. seealso:: :attr:`Device.distance_model`"""

    muted: object
    """Whether the entry is muted."""

    relative: object
    """Whether the source's location, velocity and orientation is relative or absolute to the listener."""

    sound: object
    """The sound the entry is representing and will be played in the sequence."""

    volume_maximum: object
    """The maximum volume of the source.

.. seealso:: :attr:`Device.distance_model`"""

    volume_minimum: object
    """The minimum volume of the source.

.. seealso:: :attr:`Device.distance_model`"""

    def move(self, begin: float, end: float, skip: float) -> None:
        """Moves the entry."""

    def setAnimationData(
        self,
        type: int,
        frame: int,
        data: collections.abc.Sequence[float],
        animated: bool,
    ) -> None:
        """Writes animation data to a sequenced entry."""

class Sound:
    """Sound objects are immutable and represent a sound that can be played simultaneously multiple times. They are called factories because they create reader objects internally that are used for playback."""

    length: object
    """The sample specification of the sound as a tuple with rate and channel count."""

    specs: object
    """The sample specification of the sound as a tuple with rate and channel count."""

    def ADSR(
        self, attack: float, decay: float, sustain: float, release: float
    ) -> Sound:
        """Attack-Decay-Sustain-Release envelopes the volume of a sound.
        Note: there is currently no way to trigger the release with this API.
        """

    def accumulate(self, additive: bool = False) -> Sound:
        """Accumulates a sound by summing over positive input
        differences thus generating a monotonic sigal.
        If additivity is set to true negative input differences get added too,
        but positive ones with a factor of two.

        Note that with additivity the signal is not monotonic anymore.
        """

    def addSound(self, sound: Sound, /) -> None:
        """Adds a new sound to a sound list."""

    def animateableTimeStretchPitchScale(
        self,
        fps: float,
        time_stretch: float | object,
        pitch_scale: float | object,
        quality: int,
        preserve_formant: bool,
    ) -> Sound:
        """Applies time-stretching and pitch-scaling to the sound."""

    def binaural(self, hrtf: HRTF, source: Source, threadPool: ThreadPool) -> Sound:
        """Creates a binaural sound using another sound as source. The original sound must be mono"""

    @classmethod
    def buffer(cls, data: object, rate: float) -> Sound:
        """Creates a sound from a data buffer."""

    def cache(self) -> Sound:
        """Caches a sound into RAM.

        This saves CPU usage needed for decoding and file access if the
        underlying sound reads from a file on the harddisk,
        but it consumes a lot of memory.
        """

    def convolver(
        self, impulseResponse: ImpulseResponse, threadPool: ThreadPool
    ) -> Sound:
        """Creates a sound that will apply convolution to another sound."""

    def data(self) -> object:
        """Retrieves the data of the sound as numpy array."""

    def delay(self, time: float) -> Sound:
        """Delays by playing adding silence in front of the other sound's data."""

    def echo(self, delay: float, feedback: float, mix: float) -> Sound:
        """Adds Echo effect to the sound."""

    def envelope(
        self, attack: float, release: float, threshold: float, arthreshold: float
    ) -> Sound:
        """Delays by playing adding silence in front of the other sound's data."""

    def fadein(self, start: float, length: float) -> Sound:
        """Fades a sound in by raising the volume linearly in the given
        time interval.
        """

    def fadeout(self, start: float, length: float) -> Sound:
        """Fades a sound in by lowering the volume linearly in the given
        time interval.
        """

    @classmethod
    def file(cls, filename: str) -> Sound:
        """Creates a sound object of a sound file."""

    def filter(
        self,
        b: collections.abc.Sequence[float],
        a: collections.abc.Sequence[float] = (1,),
    ) -> Sound:
        """Filters a sound with the supplied IIR filter coefficients.
        Without the second parameter you'll get a FIR filter.

        If the first value of the a sequence is 0,
        it will be set to 1 automatically.
        If the first value of the a sequence is neither 0 nor 1, all
        filter coefficients will be scaled by this value so that it is 1
        in the end, you don't have to scale yourself.
        """

    def highpass(self, frequency: float, Q: float = 0.5) -> Sound:
        """Creates a second order highpass filter based on the transfer
        function :math:`H(s) = s^2 / (s^2 + s/Q + 1)`
        """

    def join(self, sound: Sound, /) -> Sound:
        """Plays two factories in sequence."""

    def limit(self, start: float, end: float) -> Sound:
        """Limits a sound within a specific start and end time."""

    @classmethod
    def list(cls, random: int) -> Sound:
        """Creates an empty sound list that can contain several sounds."""

    def loop(self, count: int) -> Sound:
        """Loops a sound."""

    def lowpass(self, frequency: float, Q: float = 0.5) -> Sound:
        """Creates a second order lowpass filter based on the transfer    function :math:`H(s) = 1 / (s^2 + s/Q + 1)`"""

    def mix(self, sound: Sound, /) -> Sound:
        """Mixes two factories."""

    def modulate(self, sound: Sound, /) -> Sound:
        """Modulates two factories."""

    def mutable(self) -> Sound:
        """Creates a sound that will be restarted when sought backwards.
        If the original sound is a sound list, the playing sound can change.
        """

    def pingpong(self) -> Sound:
        """Plays a sound forward and then backward.
        This is like joining a sound with its reverse.
        """

    def pitch(self, factor: float) -> Sound:
        """Changes the pitch of a sound with a specific factor."""

    def rechannel(self, channels: int) -> Sound:
        """Rechannels the sound."""

    def resample(self, rate: float, quality: int) -> Sound:
        """Resamples the sound."""

    def reverse(self) -> Sound:
        """Plays a sound reversed."""

    @classmethod
    def sawtooth(cls, frequency: float, rate: int) -> Sound:
        """Creates a sawtooth sound which plays a sawtooth wave."""

    @classmethod
    def silence(cls, rate: int) -> Sound:
        """Creates a silence sound which plays simple silence."""

    @classmethod
    def sine(cls, frequency: float, rate: int) -> Sound:
        """Creates a sine sound which plays a sine wave."""

    @classmethod
    def square(cls, frequency: float, rate: int) -> Sound:
        """Creates a square sound which plays a square wave."""

    def sum(self) -> Sound:
        """Sums the samples of a sound."""

    def threshold(self, threshold: float = 0) -> Sound:
        """Makes a threshold wave out of an audio wave by setting all samples
        with a amplitude >= threshold to 1, all <= -threshold to -1 and
        all between to 0.
        """

    def timeStretchPitchScale(
        self,
        time_stretch: float,
        pitch_scale: float,
        quality: int,
        preserve_formant: bool,
    ) -> Sound:
        """Applies time-stretching and pitch-scaling to the sound."""

    @classmethod
    def triangle(cls, frequency: float, rate: int) -> Sound:
        """Creates a triangle sound which plays a triangle wave."""

    def volume(self, volume: float) -> Sound:
        """Changes the volume of a sound."""

    def write(
        self,
        filename: str,
        rate: int,
        channels: int,
        format: int,
        container: int,
        codec: int,
        bitrate: int,
        buffersize: int,
    ) -> None:
        """Writes the sound to a file."""

class Source:
    """The source object represents the source position of a binaural sound."""

    azimuth: object
    """The azimuth angle."""

    distance: object
    """The distance value. 0 is min, 1 is max."""

    elevation: object
    """The elevation angle."""

class ThreadPool:
    """A ThreadPool is used to parallelize convolution efficiently."""

class error:
    """Common base class for all non-exit exceptions."""
