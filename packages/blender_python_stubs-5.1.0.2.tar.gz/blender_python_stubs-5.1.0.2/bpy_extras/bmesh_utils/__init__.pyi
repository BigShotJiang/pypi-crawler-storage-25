import bmesh
import bmesh.types

def bmesh_linked_uv_islands(
    bmesh: bmesh.types.BMLayerItem, uv_layer: object
) -> list[list[int]]:
    """Returns lists of faces connected by UV islands.

    For meshes use :class:`bpy.types.Mesh.mesh_linked_uv_islands` instead.

    :param bm: the bmesh used to group with.
    """

def match_uv(face: object, vert: object, uv: object, uv_layer: object) -> None: ...
