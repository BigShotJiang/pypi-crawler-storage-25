from collections.abc import Callable
import bpy.types

def load_image(
    imagepath: str,
    dirname: str = "",
    place_holder: bool = False,
    recursive: bool = False,
    ncase_cmp: bool = True,
    convert_callback: Callable[[str], str] | None = None,
    verbose: bool = False,
    relpath: str | None = None,
    check_existing: bool = False,
    force_reload: bool = False,
) -> bpy.types.Image | None:
    """Return an image from the file path with options to search multiple paths
    and return a placeholder if it's not found.

    :param imagepath: The image filename
       If a path precedes it, this will be searched as well.
    """
