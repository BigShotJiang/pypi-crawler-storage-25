"""Helpers for asset management tasks."""

import bpy.types

class AssetBrowserPanel:
    """Mixin class for panels that should only show in the asset browser."""

    @property
    def bl_space_type(self) -> str: ...
    @classmethod
    def asset_browser_panel_poll(cls, context: bpy.types.Context) -> bool:
        """Check if the panel should be shown in the asset browser.

        :param context: The context.
        """

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        """Poll for asset browser visibility.

        :param context: The context.
        """

class AssetMetaDataPanel:
    """Mixin class for panels that display asset metadata in the asset browser."""

    @property
    def bl_region_type(self) -> str: ...
    @property
    def bl_space_type(self) -> str: ...
    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        """Poll for asset browser with active asset metadata.

        :param context: The context.
        """

class SpaceAssetInfo:
    """Utility class for checking if a space is an asset browser."""

    @classmethod
    def is_asset_browser(cls, space_data: bpy.types.Space) -> bool:
        """Check if the given space is an asset browser.

        :param space_data: The space to check.
        """

    @classmethod
    def is_asset_browser_poll(cls, context: bpy.types.Context) -> bool:
        """Poll whether the active space is an asset browser.

        :param context: The context.
        """
