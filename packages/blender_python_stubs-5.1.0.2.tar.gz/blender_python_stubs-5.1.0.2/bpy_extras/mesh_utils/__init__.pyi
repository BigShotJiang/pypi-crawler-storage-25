from collections.abc import Sequence
import bpy.types
import mathutils

def edge_face_count(mesh: bpy.types.Mesh) -> list[int]:
    """:param mesh: The mesh to count edges for."""

def edge_face_count_dict(mesh: bpy.types.Mesh) -> dict[tuple[int, int], int]:
    """:param mesh: The mesh to count edges for."""

def edge_loops_from_edges(
    mesh: bpy.types.Mesh, edges: list[bpy.types.MeshEdge] | None = None
) -> list[list[int]]:
    """Edge loops defined by edges.

    Takes mesh.edges or a list of edges and returns the edge loops
    as a list of vertex indices.
    Closed loops have matching start and end values.

    :param mesh: The mesh to extract edge loops from.
    """

def mesh_linked_triangles(
    mesh: bpy.types.Mesh,
) -> list[list[bpy.types.MeshLoopTriangle]]:
    """Splits the mesh into connected triangles, use this for separating cubes from
    other mesh elements within 1 mesh data-block.

    :param mesh: the mesh used to group with.
    """

def mesh_linked_uv_islands(mesh: bpy.types.Mesh) -> list[list[int]]:
    """Returns lists of polygon indices connected by UV islands.

    :param mesh: the mesh used to group with.
    """

def ngon_tessellate(
    from_data: bpy.types.Mesh | list[Sequence[float]] | tuple[Sequence[float]],
    indices: list[int],
    fix_loops: bool = True,
    debug_print: bool = True,
) -> list[tuple[int, int, int]]:
    """Takes a poly-line of indices (ngon) and returns a list of face
    index lists. Designed to be used for importers that need indices for an
    ngon to create from existing verts.

    :param from_data: Either a mesh, or a list/tuple of 3D vectors.
    """

def triangle_random_points(
    num_points: int, loop_triangles: Sequence[bpy.types.MeshLoopTriangle]
) -> list[mathutils.Vector]:
    """Generates a list of random points over mesh loop triangles.

    :param num_points: The number of random points to generate on each triangle.
    """
