from collections.abc import Generator
from collections.abc import Iterable
from collections.abc import Iterator
from collections.abc import Sequence
from typing import TypeAlias
from typing_extensions import override
import bpy.types
import collections.abc

FCurveKey: TypeAlias = tuple[str, int]

ListKeyframes: TypeAlias = list[float]

def action_ensure_channelbag_for_slot(
    action: bpy.types.Action, slot: bpy.types.ActionSlot
) -> bpy.types.ActionChannelbag:
    """Ensure a layer and a keyframe strip exists, then ensure that strip has a channelbag for the slot."""

def action_get_channelbag_for_slot(
    action: bpy.types.Action | None, slot: bpy.types.ActionSlot | None
) -> bpy.types.ActionChannelbag | None:
    """Returns the first channelbag found for the slot.
    In case there are multiple layers or strips they are iterated until a
    channelbag for that slot is found. In case no matching channelbag is found, returns None.
    """

def action_get_first_suitable_slot(
    action: bpy.types.Action | None, target_id_type: str
) -> bpy.types.ActionSlot | None:
    """Return the first Slot of the given Action that's suitable for the given ID type.

    Typically you should not need this function; when an Action is assigned to a
    data-block, just use the slot that was assigned along with it.
    """

def animdata_get_channelbag_for_assigned_slot(
    anim_data: object,
) -> bpy.types.ActionChannelbag:
    """Return the channelbag used in the given anim_data or None if there is no Action
    + Slot combination defined.
    """

def bake_action(
    obj: bpy.types.Object,
    *,
    action: bpy.types.Action | None,
    frames: Iterable[int],
    bake_options: BakeOptions
) -> bpy.types.Action | None:
    """:param obj: Object to bake."""

def bake_action_iter(
    obj: bpy.types.Object, *, action: bpy.types.Action | None, bake_options: BakeOptions
) -> bpy.types.Action | None:
    """A coroutine that bakes action for a single object.

    :param obj: Object to bake.
    """

def bake_action_objects(
    object_action_pairs: Sequence[tuple[bpy.types.Object, bpy.types.Action | None]],
    *,
    frames: Iterable[int],
    bake_options: BakeOptions
) -> Sequence[bpy.types.Action]:
    """A version of :func:`bake_action_objects_iter` that takes frames and returns the output.

    :param object_action_pairs: Sequence of object action tuples,
       action is the destination for the baked data. When None a new action will be created.
    """

def bake_action_objects_iter(
    object_action_pairs: Sequence[tuple[bpy.types.Object, bpy.types.Action | None]],
    bake_options: BakeOptions,
) -> Generator[str, None, None]:
    """A coroutine that bakes actions for multiple objects.

    :param object_action_pairs: Sequence of object action tuples,
       action is the destination for the baked data. When None a new action will be created.
    """

class AutoKeying:
    """Auto-keying support."""

    @classmethod
    def active_keyingset(cls, context: bpy.types.Context) -> bpy.types.KeyingSet | None:
        """Return the active keying set, if it should be used.

        Only returns the active keying set when the auto-key settings indicate
        it should be used, and when it is not using absolute paths (because
        that's not supported by the Copy Global Transform add-on).

        :param context: The context.
        """

    @classmethod
    def autokey_transformation(
        cls, context: bpy.types.Context, target: bpy.types.Object | bpy.types.PoseBone
    ) -> None:
        """Auto-key transformation properties.

        :param context: The context.
        """

    @classmethod
    def autokeying_options(cls, context: bpy.types.Context) -> set[str] | None:
        """Retrieve the Auto Keyframe options, or None if disabled.

        :param context: The context.
        """

    def get_4d_rotlock(self, bone: bpy.types.PoseBone) -> list[bool]:
        """Retrieve the lock status for 4D rotation.

        :param bone: The pose bone to check.
        """

    @classmethod
    def key_transformation(
        cls, target: bpy.types.Object | bpy.types.PoseBone, options: set[str]
    ) -> None:
        """Keyframe transformation properties, avoiding keying locked channels.

        :param target: The object or pose bone to keyframe.
        """

    @classmethod
    def key_transformation_via_keyingset(
        cls,
        context: bpy.types.Context,
        target: bpy.types.Object | bpy.types.PoseBone,
        keyingset: bpy.types.KeyingSet,
    ) -> None:
        """Auto-key transformation properties with the given keying set.

        :param context: The context.
        """

    @classmethod
    def keyframe_channels(
        cls,
        target: bpy.types.Object | bpy.types.PoseBone,
        options: set[str],
        data_path: str,
        group: str,
        locks: Iterable[bool],
    ) -> None:
        """Keyframe channels, avoiding keying locked channels.

        :param target: The object or pose bone to keyframe.
        """

    @classmethod
    def keying_options(cls, context: bpy.types.Context) -> set[str]:
        """Retrieve the general keyframing options from user preferences.

        :param context: The context.
        """

    @classmethod
    def keying_options_from_keyingset(
        cls, context: bpy.types.Context, keyingset: bpy.types.KeyingSet
    ) -> set[str]:
        """Retrieve the general keyframing options from user preferences.

        :param context: The context.
        """

    @classmethod
    def keytype(cls, the_keytype: str) -> Iterator[None]:
        """Context manager to set the key type that's inserted.

        :param the_keytype: The key type to use.
        """

    @classmethod
    def options(
        cls,
        *,
        keytype: str = "",
        use_loc: bool = True,
        use_rot: bool = True,
        use_scale: bool = True,
        force_autokey: bool = False
    ) -> Iterator[None]:
        """Context manager to set various keyframing options.

        :param keytype: The key type to use.
        """

class BakeOptions:
    """BakeOptions(only_selected: bool, do_pose: bool, do_object: bool, do_visual_keying: bool, do_constraint_clear: bool, do_parents_clear: bool, do_clean: bool, do_location: bool, do_rotation: bool, do_scale: bool, do_bbone: bool, do_custom_props: bool)"""

    @override
    def __eq__(self, other: object) -> bool:
        """Return self==value."""

class KeyframesCo:
    """A buffer for keyframe Co unpacked values per ``FCurveKey``. ``FCurveKeys`` are added using
    ``add_paths()``, Co values stored using extend_co_values(), then finally use
    ``insert_keyframes_into_*_action()`` for efficiently inserting keys into the F-curves.

    Users are limited to one Action Group per instance.
    """

    @property
    def keyframes_from_fcurve(self) -> object: ...
    def add_paths(self, rna_path: str, total_indices: int) -> None: ...
    def extend_co_value(self, rna_path: str, frame: float, value: float) -> None: ...
    def extend_co_values(
        self,
        rna_path: str,
        total_indices: int,
        frame: float,
        values: collections.abc.Sequence[float],
    ) -> None: ...
    def insert_keyframes_into_existing_action(
        self,
        lookup_fcurves: collections.abc.Mapping[tuple[str, int], bpy.types.FCurve],
        total_new_keys: int,
        channelbag: bpy.types.ActionChannelbag,
    ) -> None:
        """Assumes the action already exists, that it might already have F-curves. Otherwise, the
        only difference between versions is performance and implementation simplicity.

        :param lookup_fcurves: : This is only used for efficiency.
           It's a substitute for ``channelbag.fcurves.find()`` which is a potentially expensive linear search.
        """

    def insert_keyframes_into_new_action(
        self,
        total_new_keys: int,
        channelbag: bpy.types.ActionChannelbag,
        group_name: str,
    ) -> None:
        """Assumes the action is new, that it has no F-curves. Otherwise, the only difference between versions is
        performance and implementation simplicity.

        :param group_name: Name of the Group that F-curves are added to.
        """
