from collections.abc import Sequence
import bpy.types
import mathutils

def add_object_align_init(
    context: bpy.types.Context, operator: bpy.types.Operator | None
) -> mathutils.Matrix:
    """Return a matrix using the operator settings and view context.

    :param context: The context to use.
    """

def object_add_grid_scale(context: bpy.types.Context) -> float:
    """Return scale which should be applied on object
    data to align it to grid scale.

    :param context: The context.
    """

def object_add_grid_scale_apply_operator(
    operator: bpy.types.Operator, context: bpy.types.Context
) -> None:
    """Scale an operator's distance values by the grid size.

    :param operator: The operator to scale.
    """

def object_data_add(
    context: bpy.types.Context,
    obdata: bpy.types.ID | None,
    operator: bpy.types.Operator | None = None,
    name: str | None = None,
) -> bpy.types.Object:
    """Add an object using the view context and preference to initialize the
    location, rotation and layer.

    :param context: The context to use.
    """

def object_report_if_active_shape_key_is_locked(
    obj: bpy.types.Object, operator: bpy.types.Operator | None
) -> bool:
    """Checks if the active shape key of the specified object is locked, and reports an error if so.

    If the object has no shape keys, there is nothing to lock, and the function returns False.

    :param obj: Object to check.
    """

def world_to_camera_view(
    scene: bpy.types.Scene,
    obj: bpy.types.Object,
    coord: mathutils.Vector | Sequence[float],
) -> mathutils.Vector:
    """Returns the camera space coords for a 3d point.
    (also known as: normalized device coordinates - NDC).

    Where (0, 0) is the bottom left and (1, 1)
    is the top right of the camera frame.
    values outside 0-1 are also supported.
    A negative 'z' value means the point is behind the camera.

    Takes shift-x/y, lens angle and sensor size into account
    as well as perspective/ortho projections.

    :param scene: Scene to use for frame size.
    """

class AddObjectHelper:
    def align_update_callback(self, _context: object) -> None:
        """Update callback for the align property, resets rotation for world alignment."""

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        """Check the scene is not linked from a library.

        :param context: The context.
        """
