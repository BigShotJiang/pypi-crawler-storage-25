import bpy.types

def get_all_referenced_ids(
    id: bpy.types.ID, ref_map: dict[bpy.types.ID, set[bpy.types.ID]]
) -> set[bpy.types.ID]:
    """Return a set of IDs directly or indirectly referenced by id.

    :param id: Datablock whose references we're interested in.
    """

def get_id_reference_map() -> dict[bpy.types.ID, set[bpy.types.ID]]:
    """Return a dictionary of direct data-block references for every data-block in the blend file."""
