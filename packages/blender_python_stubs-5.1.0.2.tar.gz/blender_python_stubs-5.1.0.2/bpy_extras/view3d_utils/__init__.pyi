from collections.abc import Sequence
import bpy.types
import mathutils

def location_3d_to_region_2d(
    region: bpy.types.Region,
    rv3d: bpy.types.RegionView3D,
    coord: mathutils.Vector | Sequence[float],
    *,
    default: object | None = None
) -> mathutils.Vector | object:
    """Return the *region* relative 2D location of a 3D position.

    :param region: region of the 3D viewport, typically bpy.context.region.
    """

def region_2d_to_location_3d(
    region: bpy.types.Region,
    rv3d: bpy.types.RegionView3D,
    coord: Sequence[float],
    depth_location: mathutils.Vector | Sequence[float],
) -> mathutils.Vector:
    """Return a 3D location from the region relative 2D coords, aligned with
    *depth_location*.

    :param region: region of the 3D viewport, typically bpy.context.region.
    """

def region_2d_to_origin_3d(
    region: bpy.types.Region,
    rv3d: bpy.types.RegionView3D,
    coord: Sequence[float],
    *,
    clamp: float | None = None
) -> mathutils.Vector:
    """Return the 3D view origin from the region relative 2D coords.

    :param region: region of the 3D viewport, typically bpy.context.region.
    """

def region_2d_to_vector_3d(
    region: bpy.types.Region, rv3d: bpy.types.RegionView3D, coord: Sequence[float]
) -> mathutils.Vector:
    """Return a direction vector from the viewport at the specific 2D region
    coordinate.

    :param region: region of the 3D viewport, typically bpy.context.region.
    """
