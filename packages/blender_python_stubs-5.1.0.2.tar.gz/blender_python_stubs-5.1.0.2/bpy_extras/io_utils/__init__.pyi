from collections.abc import Callable
from collections.abc import Sequence
from typing import Literal
import bpy.types
import mathutils

def axis_conversion(
    from_forward: object = "Y",
    from_up: object = "Z",
    to_forward: object = "Y",
    to_up: object = "Z",
) -> mathutils.Matrix:
    """Each argument is an axis
    where the first 2 are a source and the second 2 are the target.

    :param from_forward: Source forward axis.
    """

def axis_conversion_ensure(
    operator: bpy.types.Operator, forward_attr: str, up_attr: str
) -> bool:
    """Function to ensure an operator has valid axis conversion settings, intended
    to be used from :class:`bpy.types.Operator.check`.

    :param operator: the operator to access axis attributes from.
    """

def create_derived_objects(
    depsgraph: bpy.types.Depsgraph, objects: Sequence[bpy.types.Object]
) -> dict[bpy.types.Object, list[tuple[bpy.types.Object, mathutils.Matrix]]]:
    """This function takes a sequence of objects, returning their instances.

    :param depsgraph: The evaluated depsgraph.
    """

def orientation_helper(
    axis_forward: object = "Y", axis_up: object = "Z"
) -> Callable[[type], type]:
    """A decorator for import/export classes, generating properties needed by the axis conversion system and IO helpers,
    with specified default values (axes).

    :param axis_forward: The default forward axis.
    """

def path_reference(
    filepath: str,
    base_src: str,
    base_dst: str,
    mode: Literal["AUTO", "ABSOLUTE", "RELATIVE", "MATCH", "STRIP", "COPY"] = "AUTO",
    copy_subdir: str = "",
    copy_set: set[tuple[str, str]] | None = None,
    library: bpy.types.Library | None = None,
) -> str:
    """Return a filepath relative to a destination directory, for use with
    exporters.

    :param filepath: the file path to return,
       supporting blenders relative '//' prefix.
    """

def path_reference_copy(
    copy_set: set[tuple[str, str]], report: Callable[[str], None] = ...
) -> None:
    """Execute copying files of path_reference

    :param copy_set: set of (from, to) pairs to copy.
    """

def path_reference_mode(*args: object, **kwargs: object) -> None:
    """Intermediate storage for properties before registration."""

def poll_file_object_drop(context: bpy.types.Context) -> bool:
    """A default implementation for FileHandler poll_drop methods. Allows for both the 3D Viewport and
    the Outliner (in ViewLayer display mode) to be targets for file drag and drop.

    :param context: The context.
    """

def unique_name(
    key: object,
    name: str,
    name_dict: dict[object, str],
    name_max: int = -1,
    clean_func: Callable[[str], str] | None = None,
    sep: str = ...,
) -> str:
    """Helper function for storing unique names which may have special characters
    stripped and restricted to a maximum length.

    :param key: Unique item this name belongs to, name_dict[key] will be reused
       when available.
       This can be the object, mesh, material, etc instance itself.
       Any hashable object associated with the *name*.
    """

def unpack_face_list(list_of_tuples: Sequence[tuple[int, ...]]) -> list[int]:
    """Unpack a list of faces (triangles or quads) into a flat list,
    padding triangles with a zero to fit into groups of four.

    :param list_of_tuples: A sequence of face index tuples (3 or 4 elements each).
    """

def unpack_list(list_of_tuples: Sequence[tuple[object, ...]]) -> list[object]:
    """Flatten a sequence of tuples into a single list.

    :param list_of_tuples: A sequence of tuples to unpack.
    """

class ExportHelper:
    @property
    def check_extension(self) -> bool: ...
    def check(self, _context: object) -> bool:
        """Validate the filepath and axis conversion settings."""

    def invoke(self, context: bpy.types.Context, _event: object) -> set[str]:
        """Invoke the file selector for exporting, setting a default filepath
        based on the current blend file name.

        :param context: The context.
        """

class ImportHelper:
    def check(self, _context: object) -> bool:
        """Validate axis conversion settings."""

    def invoke(self, context: bpy.types.Context, _event: object) -> set[str]:
        """Invoke the file selector for importing.

        :param context: The context.
        """

    def invoke_popup(
        self, context: bpy.types.Context, confirm_text: str = ""
    ) -> set[str]:
        """Invoke as a popup confirmation dialog when a filepath is already set,
        otherwise fall back to the file selector.

        :param context: The context.
        """
