from collections.abc import Sequence
from typing import Literal
import gpu.types

def batch_for_shader(
    shader: gpu.types.GPUShader,
    type: Literal[
        "POINTS",
        "LINES",
        "TRIS",
        "LINE_STRIP",
        "TRI_STRIP",
        "LINES_ADJ",
        "TRIS_ADJ",
        "LINE_STRIP_ADJ",
    ],
    content: dict[
        str,
        gpu.types.Buffer
        | Sequence[float]
        | Sequence[int]
        | Sequence[Sequence[float]]
        | Sequence[Sequence[int]],
    ],
    *,
    indices: object = None
) -> gpu.types.GPUBatch:
    """Return a batch already configured and compatible with the shader.

    :param shader: shader for which a compatible format will be computed.
    """
