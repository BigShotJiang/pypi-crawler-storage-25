from collections.abc import Sequence
import gpu.types

def draw_circle_2d(
    position: Sequence[float],
    color: Sequence[float],
    radius: float,
    *,
    segments: int | None = None
) -> None:
    """Draw a circle.

    :param position: 2D position where the circle will be drawn.
    """

def draw_texture_2d(
    texture: gpu.types.GPUTexture,
    position: Sequence[float],
    width: float,
    height: float,
    is_scene_linear_with_rec709_srgb_target: bool = False,
) -> None:
    """Draw a 2d texture.

    :param texture: GPUTexture to draw (e.g. gpu.texture.from_image(image) for :class:`bpy.types.Image`).
    """
