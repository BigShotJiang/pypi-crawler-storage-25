"""This module contains application values that remain unchanged during runtime."""

alembic: object

autoexec_fail: bool

autoexec_fail_message: str

autoexec_fail_quiet: bool

background: bool

binary_path: str

build_branch: bytes

build_cflags: bytes

build_commit_date: bytes

build_commit_time: bytes

build_commit_timestamp: int

build_cxxflags: bytes

build_date: bytes

build_hash: bytes

build_linkflags: bytes

build_options: object

build_platform: bytes

build_system: bytes

build_time: bytes

build_type: bytes

cachedir: str

debug: bool

debug_depsgraph: bool

debug_depsgraph_build: bool

debug_depsgraph_eval: bool

debug_depsgraph_pretty: bool

debug_depsgraph_tag: bool

debug_depsgraph_time: bool

debug_events: bool

debug_freestyle: bool

debug_handlers: bool

debug_io: bool

debug_python: bool

debug_simdata: bool

debug_value: int

debug_wm: bool

driver_namespace: dict[str, object]

factory_startup: bool

ffmpeg: object

handlers: object

module: bool

n_fields: int

n_sequence_fields: int

n_unnamed_fields: int

ocio: object

oiio: object

online_access: bool

online_access_override: bool

opensubdiv: object

openvdb: object

portable: bool

python_args: tuple[object, ...]

render_icon_size: int

render_preview_size: int

sdl: object

tempdir: str

translations: object

usd: object

use_event_simulate: bool

use_userpref_skip_save_on_exit: bool

version: tuple[object, ...]

version_cycle: str

version_file: tuple[object, ...]

version_string: str

def count(value: object, /) -> None:
    """Return number of occurrences of value."""

def help_text(all: bool) -> str:
    """Return the help text as a string.

    :param all: Return all arguments, even those which aren't available for the current platform.
    """

def index(
    value: object, start: object = 0, stop: object = 9223372036854775807, /
) -> None:
    """Return first index of value.

    Raises ValueError if the value is not present.
    """

def is_job_running(job_type: str) -> bool:
    """Check whether a job of the given type is running.

    :param job_type: job type in :ref:`rna_enum_wm_job_type_items`.
    """

def memory_usage_undo() -> int:
    """Get undo memory usage information."""
