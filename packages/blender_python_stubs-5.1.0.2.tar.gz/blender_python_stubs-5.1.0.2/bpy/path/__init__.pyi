"""This module has a similar scope to os.path, containing utility
functions for dealing with paths in Blender."""

from collections.abc import Sequence
import bpy.types

extensions_audio: frozenset[str]

extensions_image: frozenset[str]

extensions_movie: frozenset[str]

def abspath(
    path: str | bytes,
    *,
    start: str | bytes | None = None,
    library: bpy.types.Library | None = None
) -> str:
    """Returns the absolute path relative to the current blend file
    using the "//" prefix.

    :param path: The path to convert to absolute.
    """

def basename(path: str | bytes) -> str:
    """Equivalent to ``os.path.basename``, but skips a "//" prefix.

    Use for Windows compatibility.

    :param path: The path to get the base name of.
    """

def clean_name(name: str | bytes, *, replace: str = "_") -> str:
    """Returns a name with characters replaced that
    may cause problems under various circumstances,
    such as writing to a file.

    All characters besides A-Z/a-z, 0-9 are replaced with "_"
    or the *replace* argument if defined.

    :param name: The path name.
    """

def display_name(name: str, *, has_ext: bool = True, title_case: bool = True) -> str:
    """Creates a display string from name to be used in menus and the user interface.
    Intended for use with filenames and module names.

    :param name: The name to be used for displaying the user interface.
    """

def display_name_from_filepath(name: str) -> str:
    """Returns the path stripped of directory and extension,
    ensured to be UTF-8 compatible.

    :param name: The file path to convert.
    """

def display_name_to_filepath(name: str) -> str:
    """Performs the reverse of display_name using literal versions of characters
    which aren't supported in a filepath.

    :param name: The display name to convert.
    """

def ensure_ext(filepath: str, ext: str, *, case_sensitive: bool = False) -> str:
    """Return the path with the extension added if it is not already set.

    :param filepath: The file path.
    """

def is_subdir(path: str | bytes, directory: str | bytes) -> bool:
    """Returns true if *path* is in a subdirectory of *directory*.
    Both paths must be absolute.

    :param path: An absolute path.
    """

def module_names(
    path: str, *, recursive: bool = False, package: str = ""
) -> list[tuple[str, str]]:
    """Return a list of modules which can be imported from *path*.

    :param path: a directory to scan.
    """

def native_pathsep(path: str) -> str:
    """Replace the path separator with the system's native ``os.sep``.

    :param path: The path to replace.
    """

def reduce_dirs(dirs: Sequence[str]) -> list[str]:
    """Given a sequence of directories, remove duplicates and
    any directories nested in one of the other paths.
    (Useful for recursive path searching).

    :param dirs: Sequence of directory paths.
    """

def relpath(path: str | bytes, *, start: str | bytes | None = None) -> str:
    """Returns the path relative to the current blend file using the "//" prefix.

    :param path: An absolute path.
    """

def resolve_ncase(path: str) -> str:
    """Resolve a case insensitive path on a case sensitive system,
    returning a string with the path if found else return the original path.

    :param path: The path name to resolve.
    """
