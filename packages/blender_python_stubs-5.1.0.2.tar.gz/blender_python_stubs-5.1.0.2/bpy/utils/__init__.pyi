"""This module contains utility functions specific to blender but
not associated with blenders internal data."""

from . import previews as previews
from . import toolsystem as toolsystem
from collections.abc import Callable
from collections.abc import Iterator
from collections.abc import Sequence
from typing import Literal
import bpy.types
import datetime

def app_template_paths(*, path: str | None = None) -> Iterator[str]:
    """Returns valid application template paths.

    :param path: Optional subdir.
    """

def blend_paths(
    *, absolute: bool = False, packed: bool = False, local: bool = False
) -> list[str]:
    """Returns a list of paths to external files referenced by the loaded .blend file.

    :param absolute: When true the paths returned are made absolute.
    """

def escape_identifier(string: str, /) -> str:
    """Simple string escaping function used for animation paths.

    :param string: text
    """

def execfile(filepath: str, *, mod: object | None = None) -> object:
    """Execute a file path as a Python script.

    :param filepath: Path of the script to execute.
    """

def expose_bundled_modules() -> None:
    """For Blender as a Python module, add bundled VFX library python bindings
    to ``sys.path``. These may be used instead of dedicated packages, to ensure
    the libraries are compatible with Blender.
    """

def extension_path_user(package: str, *, path: str = "", create: bool = False) -> str:
    """Return a user writable directory associated with an extension.

    :param package: The ``__package__`` of the extension.
    """

def flip_name(name: str, *, strip_digits: bool = False) -> str:
    """Flip a name between left/right sides, useful for
    mirroring bone names.

    :param name: Bone name to flip.
    """

def is_path_builtin(path: str) -> bool:
    """Returns True if the path is one of the built-in paths used by Blender.

    :param path: Path you want to check if it is in the built-in settings directory
    """

def is_path_extension(path: str) -> bool:
    """Returns True if the path is from an extensions repository.

    :param path: Path to check if it is within an extension repository.
    """

def keyconfig_init() -> None:
    """Initialize and refresh key configurations, called from the Blender
    window manager on startup and refresh.
    """

def keyconfig_set(
    filepath: str, *, report: Callable[[set[str], str], None] | None = None
) -> None:
    """Load and activate a key configuration from a file.

    :param filepath: The file path to the key configuration preset.
    """

def load_scripts(
    *,
    reload_scripts: bool = False,
    refresh_scripts: bool = False,
    extensions: bool = True,
) -> None:
    """Load scripts and run each modules register function.

    :param reload_scripts: Causes all scripts to have their unregister method
       called before loading.
    """

def load_scripts_extensions(*, reload_scripts: bool = False) -> None:
    """Load extensions scripts (add-ons and app-templates)

    :param reload_scripts: Causes all scripts to have their unregister method
       called before loading.
    """

def make_rna_paths(
    struct_name: str, prop_name: str, enum_name: str
) -> tuple[str, str, str]:
    """Create RNA "paths" from given names.

    :param struct_name: Name of a RNA struct (like e.g. "Scene").
    """

def manual_language_code(default: str = "en") -> str:
    """:param default: The fallback language code to use when the current language is unavailable."""

def manual_map() -> Iterator[tuple[str, list[tuple[str, str]]]]:
    """Yield manual URL mappings from all registered hooks."""

def modules_from_path(path: str, loaded_modules: set[str]) -> list[object]:
    """Load all modules in a path and return them as a list.

    :param path: this path is scanned for scripts and packages.
    """

def preset_find(
    name: str, preset_path: str, *, display_name: bool = False, ext: str = ...
) -> str | None:
    """Search for a preset by name.

    :param name: The preset name.
    """

def preset_paths(subdir: str) -> list[str]:
    """Returns a list of paths for a specific preset.

    :param subdir: preset subdirectory (must not be an absolute path).
    """

def refresh_script_paths() -> None:
    """Run this after creating new script paths to update sys.path"""

def register_class(
    cls: type[
        bpy.types.Panel
        | bpy.types.UIList
        | bpy.types.Menu
        | bpy.types.Header
        | bpy.types.Operator
        | bpy.types.KeyingSetInfo
        | bpy.types.RenderEngine
        | bpy.types.AssetShelf
        | bpy.types.FileHandler
        | bpy.types.PropertyGroup
        | bpy.types.AddonPreferences
        | bpy.types.NodeTree
        | bpy.types.Node
        | bpy.types.NodeSocket
        | bpy.types.Gizmo
        | bpy.types.GizmoGroup
    ],
    /,
) -> None:
    """Register a subclass of a Blender type class.

    :param cls: Registerable Blender class type.
    """

def register_classes_factory(
    classes: Sequence[type],
) -> tuple[Callable[[], None], Callable[[], None]]:
    """Utility function to create register and unregister functions
    which simply registers and unregisters a sequence of classes.

    :param classes: Sequence of classes to register and unregister.
    """

def register_cli_command(id: str, execute: Callable[[list[str]], int]) -> object:
    """Register a command, accessible via the (``-c`` / ``--command``) command-line argument.

    :param id: The command identifier (must pass an ``str.isidentifier`` check).

       If the ``id`` is already registered, a warning is printed and the command is inaccessible to prevent accidents invoking the wrong command.
    """

def register_manual_map(
    manual_hook: Callable[[], tuple[str, list[tuple[str, str]]]],
) -> None:
    """Register a function to provide manual URL mappings.

    :param manual_hook: A callable that returns ``(prefix, mapping)``
       where *mapping* is a sequence of ``(pattern, url)`` pairs.
    """

def register_preset_path(path: str) -> bool:
    """Register a preset search path.

    :param path: preset directory (must be an absolute path).

       This path must contain a "presets" subdirectory which will typically contain presets for add-ons.

       You may call ``bpy.utils.register_preset_path(os.path.dirname(__file__))`` from an add-ons ``__init__.py`` file.
       When the ``__init__.py`` is in the same location as a ``presets`` directory.
       For example an operators preset would be located under: ``presets/operator/{operator.id}/``
       where ``operator.id`` is the ``bl_idname`` of the operator.
    """

def register_submodule_factory(
    module_name: str, submodule_names: list[str]
) -> tuple[Callable[[], None], Callable[[], None]]:
    """Utility function to create register and unregister functions
    which simply load submodules,
    calling their register & unregister functions.

    :param module_name: The module name, typically ``__name__``.
    """

def register_tool(
    tool_cls: type[bpy.types.WorkSpaceTool],
    *,
    after: Sequence[str] | set[str] | None = None,
    separator: bool = False,
    group: bool = False,
) -> None:
    """Register a tool in the toolbar.

    :param tool_cls: A tool subclass.
    """

def resource_path(
    type: Literal["USER", "LOCAL", "SYSTEM"], *, major: int = ..., minor: int = ...
) -> str:
    """Return the base path for storing system files.

    :param type: The resource type.
    """

def script_path_user() -> str | None:
    """Return the user script path or None."""

def script_paths(
    *,
    subdir: str | None = None,
    user_pref: bool = True,
    check_all: bool = False,
    use_user: bool = True,
    use_system_environment: bool = True,
) -> list[str]:
    """Returns a list of valid script paths.

    :param subdir: Optional subdir.
    """

def script_paths_pref() -> None:
    """Returns a list of user preference script directories."""

def script_paths_system_environment() -> None:
    """Returns a list of system script directories from environment variables."""

def smpte_from_frame(
    frame: int | float, *, fps: float | None = None, fps_base: float | None = None
) -> str:
    """Returns an SMPTE formatted string from the *frame*:
    ``HH:MM:SS:FF``.

    If *fps* and *fps_base* are not given the current scene is used.

    :param frame: frame number.
    """

def smpte_from_seconds(
    time: int | float | datetime.timedelta,
    *,
    fps: float | None = None,
    fps_base: float | None = None,
) -> str:
    """Returns an SMPTE formatted string from the *time*:
    ``HH:MM:SS:FF``.

    If *fps* and *fps_base* are not given the current scene is used.

    :param time: time in seconds.
    """

def time_from_frame(
    frame: int | float, *, fps: float | None = None, fps_base: float | None = None
) -> datetime.timedelta:
    """Returns the time from a frame number.

    If *fps* and *fps_base* are not given the current scene is used.

    :param frame: number.
    """

def time_to_frame(
    time: float | int | datetime.timedelta,
    *,
    fps: object = None,
    fps_base: object = None,
) -> float | int | datetime.timedelta:
    """Returns a float frame number from a time given in seconds or
    as a datetime.timedelta object.

    If *fps* and *fps_base* are not given the current scene is used.

    :param time: time in seconds.
    """

def unescape_identifier(string: str, /) -> str:
    """Simple string un-escape function used for animation paths.
    This performs the reverse of :func:`escape_identifier`.

    :param string: text
    """

def unregister_class(
    cls: type[
        bpy.types.Panel
        | bpy.types.UIList
        | bpy.types.Menu
        | bpy.types.Header
        | bpy.types.Operator
        | bpy.types.KeyingSetInfo
        | bpy.types.RenderEngine
        | bpy.types.AssetShelf
        | bpy.types.FileHandler
        | bpy.types.PropertyGroup
        | bpy.types.AddonPreferences
        | bpy.types.NodeTree
        | bpy.types.Node
        | bpy.types.NodeSocket
        | bpy.types.Gizmo
        | bpy.types.GizmoGroup
    ],
    /,
) -> None:
    """Unload the Python class from blender.

    :param cls: Blender type class,
       see :func:`bpy.utils.register_class` for classes which can
       be registered.
    """

def unregister_cli_command(handle: object, /) -> None:
    """Unregister a CLI command.

    :param handle: The return value of :func:`register_cli_command`.
    """

def unregister_manual_map(
    manual_hook: Callable[[], tuple[str, list[tuple[str, str]]]],
) -> None:
    """Unregister a previously registered manual map hook.

    :param manual_hook: The hook function to remove.
    """

def unregister_preset_path(path: str) -> bool:
    """Unregister a preset search path.

    :param path: preset directory (must be an absolute path).

       This must match the registered path exactly.
    """

def unregister_tool(tool_cls: type[bpy.types.WorkSpaceTool]) -> None:
    """Unregister a previously registered tool.

    :param tool_cls: The tool class to unregister.
    """

def user_resource(
    resource_type: Literal["DATAFILES", "CONFIG", "SCRIPTS", "EXTENSIONS"],
    *,
    path: str = "",
    create: bool = False,
) -> str:
    """Return a user resource path (normally from the users home directory).

    :param resource_type: The resource type.
    """
