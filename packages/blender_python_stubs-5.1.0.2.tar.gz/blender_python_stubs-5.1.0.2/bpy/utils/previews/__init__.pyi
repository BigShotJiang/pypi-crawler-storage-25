"""This module contains utility functions to handle custom previews.

It behaves as a high-level 'cached' previews manager.

This allows scripts to generate their own previews, and use them as icons in UI widgets
('icon_value' for UILayout functions).


Custom Icon Example
-------------------

.. literalinclude:: __/__/__/scripts/templates_py/ui_previews_custom_icon.py"""

from typing import Literal
import bpy.types

def new() -> ImagePreviewCollection: ...
def remove(pcoll: ImagePreviewCollection) -> None:
    """Remove the specified previews collection.

    :param pcoll: Preview collection to close.
    """

class ImagePreviewCollection:
    """Dictionary-like class of previews.

    This is a subclass of Python's built-in dict type,
    used to store multiple image previews.

    .. note::

        - instance with :mod:`bpy.utils.previews.new`
        - keys must be ``str`` type.
        - values will be :class:`bpy.types.ImagePreview`
    """

    def __delitem__(self, key: int | slice) -> None:
        """Delete self[key]."""

    def clear(self) -> None:
        """Clear all previews."""

    def close(self) -> None:
        """Close the collection and clear all previews."""

    def load(
        self,
        name: str,
        filepath: str | bytes,
        file_type: Literal["IMAGE", "MOVIE", "BLEND", "FONT", "OBJECT_IO"],
        force_reload: bool = False,
    ) -> bpy.types.ImagePreview:
        """Generate a new preview from given file path.

        :param name: The name (unique id) identifying the preview.
        """

    def new(self, name: str) -> bpy.types.ImagePreview:
        """Generate a new empty preview.

        :param name: The name (unique id) identifying the preview.
        """
