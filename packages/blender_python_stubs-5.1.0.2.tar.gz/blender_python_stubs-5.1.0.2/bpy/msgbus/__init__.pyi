from collections.abc import Callable
from typing import Literal
import bpy.types

def clear_by_owner(owner: object, /) -> None:
    """Clear all subscribers using this owner.

    :param owner: The owner handle passed to :func:`subscribe_rna`.
    """

def publish_rna(
    *,
    key: bpy.types.Property | bpy.types.Struct | tuple[bpy.types.Struct, str] | object,
) -> None:
    """:param key: Represents the type of data being subscribed to

    Arguments include
    - A property instance.
    - A struct type.
    - A tuple representing a (struct, property name) pair.
    """

def subscribe_rna(
    *,
    key: bpy.types.Property | bpy.types.Struct | tuple[bpy.types.Struct, str] | object,
    owner: object,
    args: tuple[object, ...],
    notify: Callable[..., None],
    options: set[Literal["PERSISTENT"]] = ...,
) -> None: ...
