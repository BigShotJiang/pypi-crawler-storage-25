"""This module defines properties to extend Blender's internal data. The result of these functions is used to assign properties to classes registered with Blender and can't be used directly.

.. note:: All parameters to these functions must be passed as keywords."""

from collections.abc import Callable
from collections.abc import Iterable
from collections.abc import Sequence
import bpy.types

def BoolProperty(
    *,
    name: str = "",
    description: str = "",
    translation_context: str = "*",
    default: bool = False,
    options: set[str] = ...,
    override: set[str] = ...,
    tags: set[str] = ...,
    subtype: str = "NONE",
    update: Callable[[bpy.types.bpy_struct, bpy.types.Context], None] | None = None,
    get: Callable[[bpy.types.bpy_struct], bool] | None = None,
    set: Callable[[bpy.types.bpy_struct, bool], None] | None = None,
    get_transform: Callable[[bpy.types.bpy_struct, bool, bool], bool] | None = None,
    set_transform: (
        Callable[[bpy.types.bpy_struct, bool, bool, bool], bool] | None
    ) = None
) -> object:
    """Returns a new boolean property definition.

    :param name: Name used in the user interface.
    """

def BoolVectorProperty(
    *,
    name: str = "",
    description: str = "",
    translation_context: str = "*",
    default: Sequence[bool] = (False, False, False),
    options: set[str] = ...,
    override: set[str] = ...,
    tags: set[str] = ...,
    subtype: str = "NONE",
    size: int | Sequence[int] = 3,
    update: Callable[[bpy.types.bpy_struct, bpy.types.Context], None] | None = None,
    get: Callable[[bpy.types.bpy_struct], Sequence[bool]] | None = None,
    set: object | None = None,
    get_transform: (
        Callable[[bpy.types.bpy_struct, Sequence[bool], bool], Sequence[bool]] | None
    ) = None,
    set_transform: (
        Callable[
            [bpy.types.bpy_struct, Sequence[bool], Sequence[bool], bool], Sequence[bool]
        ]
        | None
    ) = None
) -> object:
    """Returns a new vector boolean property definition.

    :param name: Name used in the user interface.
    """

def CollectionProperty(
    type: type[bpy.types.PropertyGroup],
    *,
    name: str = "",
    description: str = "",
    translation_context: str = "*",
    options: set[str] = ...,
    override: set[str] = ...,
    tags: set[str] = ...
) -> object:
    """Returns a new collection property definition.

    :param type: A subclass of a property group.
    """

def EnumProperty(
    items: (
        Iterable[
            tuple[str, str, str]
            | tuple[str, str, str, int]
            | tuple[str, str, str, str | int, int]
            | None
        ]
        | Callable[
            [bpy.types.bpy_struct, bpy.types.Context | None],
            Iterable[
                tuple[str, str, str]
                | tuple[str, str, str, int]
                | tuple[str, str, str, str | int, int]
                | None
            ],
        ]
    ),
    *,
    name: str = "",
    description: str = "",
    translation_context: str = "*",
    default: str | int | set[str] | None = None,
    options: set[str] = ...,
    override: set[str] = ...,
    tags: set[str] = ...,
    update: Callable[[bpy.types.bpy_struct, bpy.types.Context], None] | None = None,
    get: Callable[[bpy.types.bpy_struct], int] | None = None,
    set: Callable[[bpy.types.bpy_struct, int], None] | None = None,
    get_transform: Callable[[bpy.types.bpy_struct, int, bool], int] | None = None,
    set_transform: Callable[[bpy.types.bpy_struct, int, int, bool], int] | None = None
) -> object:
    """Returns a new enumerator property definition.

    :param items: sequence of enum items formatted:
       ``[(identifier, name, description, icon, number), ...]``.

       The first three elements of the tuples are mandatory.

       :identifier: The identifier is used for Python access.
          An empty identifier means that the item is a separator
       :name: Name for the interface.
       :description: Used for documentation and tooltips.
       :icon: An icon string identifier or integer icon value
          (e.g. returned by :class:`bpy.types.UILayout.icon`)
       :number: Unique value used as the identifier for this item (stored in file data).
          Use when the identifier may need to change. If the *ENUM_FLAG* option is used,
          the values are bit-masks and should be powers of two.

       When an item only contains 4 items they define ``(identifier, name, description, number)``.

       Separators may be added using either None (nameless separator),
       or a regular item tuple with an empty identifier string, in which case the name,
       if non-empty, will be displayed in the UI above the separator line.
       For dynamic values a callback can be passed which returns a list in
       the same format as the static list.
       This function must take 2 arguments ``(self, context)``, **context may be None**.
    """

def FloatProperty(
    *,
    name: str = "",
    description: str = "",
    translation_context: str = "*",
    default: float = 0.0,
    min: float = ...,
    max: float = ...,
    soft_min: float = ...,
    soft_max: float = ...,
    step: float = 3,
    precision: int = 2,
    options: set[str] = ...,
    override: set[str] = ...,
    tags: set[str] = ...,
    subtype: str = "NONE",
    unit: str = "NONE",
    update: Callable[[bpy.types.bpy_struct, bpy.types.Context], None] | None = None,
    get: Callable[[bpy.types.bpy_struct], float] | None = None,
    set: Callable[[bpy.types.bpy_struct, float], None] | None = None,
    get_transform: Callable[[bpy.types.bpy_struct, float, bool], float] | None = None,
    set_transform: (
        Callable[[bpy.types.bpy_struct, float, float, bool], float] | None
    ) = None
) -> object:
    """Returns a new float (single precision) property definition.

    :param name: Name used in the user interface.
    """

def FloatVectorProperty(
    *,
    name: str = "",
    description: str = "",
    translation_context: str = "*",
    default: Sequence[float] = ...,
    min: float = ...,
    max: float = ...,
    soft_min: float = ...,
    soft_max: float = ...,
    step: float = 3,
    precision: int = 2,
    options: set[str] = ...,
    override: set[str] = ...,
    tags: set[str] = ...,
    subtype: str = "NONE",
    unit: str = "NONE",
    size: int | Sequence[int] = 3,
    update: Callable[[bpy.types.bpy_struct, bpy.types.Context], None] | None = None,
    get: Callable[[bpy.types.bpy_struct], Sequence[float]] | None = None,
    set: object | None = None,
    get_transform: (
        Callable[[bpy.types.bpy_struct, Sequence[float], bool], Sequence[float]] | None
    ) = None,
    set_transform: (
        Callable[
            [bpy.types.bpy_struct, Sequence[float], Sequence[float], bool],
            Sequence[float],
        ]
        | None
    ) = None
) -> object:
    """Returns a new vector float property definition.

    :param name: Name used in the user interface.
    """

def IntProperty(
    *,
    name: str = "",
    description: str = "",
    translation_context: str = "*",
    default: int = 0,
    min: int = -(2**31),
    max: int = 2**31 - 1,
    soft_min: int = -(2**31),
    soft_max: int = 2**31 - 1,
    step: int = 1,
    options: set[str] = ...,
    override: set[str] = ...,
    tags: set[str] = ...,
    subtype: str = "NONE",
    update: Callable[[bpy.types.bpy_struct, bpy.types.Context], None] | None = None,
    get: Callable[[bpy.types.bpy_struct], int] | None = None,
    set: Callable[[bpy.types.bpy_struct, int], None] | None = None,
    get_transform: Callable[[bpy.types.bpy_struct, int, bool], int] | None = None,
    set_transform: Callable[[bpy.types.bpy_struct, int, int, bool], int] | None = None
) -> object:
    """Returns a new int property definition.

    :param name: Name used in the user interface.
    """

def IntVectorProperty(
    *,
    name: str = "",
    description: str = "",
    translation_context: str = "*",
    default: Sequence[int] = (0, 0, 0),
    min: int = -(2**31),
    max: int = 2**31 - 1,
    soft_min: int = -(2**31),
    soft_max: int = 2**31 - 1,
    step: int = 1,
    options: set[str] = ...,
    override: set[str] = ...,
    tags: set[str] = ...,
    subtype: str = "NONE",
    size: int | Sequence[int] = 3,
    update: Callable[[bpy.types.bpy_struct, bpy.types.Context], None] | None = None,
    get: Callable[[bpy.types.bpy_struct], Sequence[int]] | None = None,
    set: object | None = None,
    get_transform: (
        Callable[[bpy.types.bpy_struct, Sequence[int], bool], Sequence[int]] | None
    ) = None,
    set_transform: (
        Callable[
            [bpy.types.bpy_struct, Sequence[int], Sequence[int], bool], Sequence[int]
        ]
        | None
    ) = None
) -> object:
    """Returns a new vector int property definition.

    :param name: Name used in the user interface.
    """

def PointerProperty(
    type: type[bpy.types.PropertyGroup | bpy.types.ID],
    *,
    name: str = "",
    description: str = "",
    translation_context: str = "*",
    options: set[str] = ...,
    override: set[str] = ...,
    tags: set[str] = ...,
    poll: Callable[[bpy.types.bpy_struct, bpy.types.ID], bool] | None = None,
    update: Callable[[bpy.types.bpy_struct, bpy.types.Context], None] | None = None
) -> object: ...
def RemoveProperty(cls: type[bpy.types.bpy_struct], attr: str) -> None:
    """Removes a dynamically defined property.

    :param cls: The class containing the property (must be a positional argument).
    """

def StringProperty(
    *,
    name: str = "",
    description: str = "",
    translation_context: str = "*",
    default: str = "",
    maxlen: int = 0,
    options: set[str] = ...,
    override: set[str] = ...,
    tags: set[str] = ...,
    subtype: str = "NONE",
    update: Callable[[bpy.types.bpy_struct, bpy.types.Context], None] | None = None,
    get: Callable[[bpy.types.bpy_struct], str] | None = None,
    set: Callable[[bpy.types.bpy_struct, str], None] | None = None,
    get_transform: Callable[[bpy.types.bpy_struct, str, bool], str] | None = None,
    set_transform: Callable[[bpy.types.bpy_struct, str, str, bool], str] | None = None,
    search: (
        Callable[
            [bpy.types.bpy_struct, bpy.types.Context, str],
            Iterable[str | tuple[str, str]],
        ]
        | None
    ) = None,
    search_options: set[str] = ...
) -> object:
    """Returns a new string property definition.

    :param name: Name used in the user interface.
    """
