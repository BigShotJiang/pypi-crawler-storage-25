import collections.abc

"""This module contains core classes of the Freestyle Python API,
including data types of view map components (0D and 1D elements), base
classes for user-defined line stylization rules (predicates,
functions, chaining iterators, and stroke shaders), and operators.

Class hierarchy:

- :class:`BBox`
- :class:`BinaryPredicate0D`
- :class:`BinaryPredicate1D`
- :class:`Id`
- :class:`Interface0D`

  - :class:`CurvePoint`

    - :class:`StrokeVertex`

  - :class:`SVertex`
  - :class:`ViewVertex`

    - :class:`NonTVertex`
    - :class:`TVertex`

- :class:`Interface1D`

  - :class:`Curve`

    - :class:`Chain`

  - :class:`FEdge`

    - :class:`FEdgeSharp`
    - :class:`FEdgeSmooth`

  - :class:`Stroke`
  - :class:`ViewEdge`

- :class:`Iterator`

  - :class:`AdjacencyIterator`
  - :class:`CurvePointIterator`
  - :class:`Interface0DIterator`
  - :class:`SVertexIterator`
  - :class:`StrokeVertexIterator`
  - :class:`ViewEdgeIterator`

    - :class:`ChainingIterator`

  - :class:`orientedViewEdgeIterator`

- :class:`Material`
- :class:`Noise`
- :class:`Operators`
- :class:`SShape`
- :class:`StrokeAttribute`
- :class:`StrokeShader`
- :class:`UnaryFunction0D`

  - :class:`UnaryFunction0DDouble`
  - :class:`UnaryFunction0DEdgeNature`
  - :class:`UnaryFunction0DFloat`
  - :class:`UnaryFunction0DId`
  - :class:`UnaryFunction0DMaterial`
  - :class:`UnaryFunction0DUnsigned`
  - :class:`UnaryFunction0DVec2f`
  - :class:`UnaryFunction0DVec3f`
  - :class:`UnaryFunction0DVectorViewShape`
  - :class:`UnaryFunction0DViewShape`

- :class:`UnaryFunction1D`

  - :class:`UnaryFunction1DDouble`
  - :class:`UnaryFunction1DEdgeNature`
  - :class:`UnaryFunction1DFloat`
  - :class:`UnaryFunction1DUnsigned`
  - :class:`UnaryFunction1DVec2f`
  - :class:`UnaryFunction1DVec3f`
  - :class:`UnaryFunction1DVectorViewShape`
  - :class:`UnaryFunction1DVoid`

- :class:`UnaryPredicate0D`
- :class:`UnaryPredicate1D`
- :class:`ViewMap`
- :class:`ViewShape`
- :class:`IntegrationType`
- :class:`MediumType`
- :class:`Nature`"""

from collections.abc import Sequence
from typing import Generic, TypeVar
from typing_extensions import override
import builtins
import mathutils

_T = TypeVar("_T")

class AdjacencyIterator:
    """Class hierarchy: :class:`Iterator` > :class:`AdjacencyIterator`

    Class for representing adjacency iterators used in the chaining
    process. An AdjacencyIterator is created in the increment() and
    decrement() methods of a :class:`ChainingIterator` and passed to the
    traverse() method of the ChainingIterator.

    .. method:: __init__()
                __init__(brother)
                __init__(vertex, restrict_to_selection=True, restrict_to_unvisited=True)

       Builds an :class:`AdjacencyIterator` using the default constructor,
       copy constructor or the overloaded constructor.

       :arg brother: An AdjacencyIterator object.
       :type brother: :class:`AdjacencyIterator`
       :arg vertex: The vertex which is the next crossing.
       :type vertex: :class:`ViewVertex`
       :arg restrict_to_selection: Indicates whether to force the chaining
          to stay within the set of selected ViewEdges or not.
       :type restrict_to_selection: bool
       :arg restrict_to_unvisited: Indicates whether a ViewEdge that has
          already been chained must be ignored ot not.
       :type restrict_to_unvisited: bool
    """

    is_incoming: bool
    """True if the current ViewEdge is coming towards the iteration vertex, and
False otherwise.

:type: bool"""

    object: ViewEdge
    """The ViewEdge object currently pointed to by this iterator.

:type: :class:`ViewEdge`"""

    def __iter__(self) -> None:
        """Implement iter(self)."""

class BBox:
    """Class for representing a bounding box.

    .. method:: __init__()

       Default constructor.
    """

class BinaryPredicate0D:
    """Base class for binary predicates working on :class:`Interface0D`
    objects. A BinaryPredicate0D is typically an ordering relation
    between two Interface0D objects. The predicate evaluates a relation
    between the two Interface0D instances and returns a boolean value (true
    or false). It is used by invoking the __call__() method.

    .. method:: __init__()

       Default constructor.

    .. method:: __call__(inter1, inter2)

       Must be overload by inherited classes. It evaluates a relation
       between two Interface0D objects.

       :arg inter1: The first Interface0D object.
       :type inter1: :class:`Interface0D`
       :arg inter2: The second Interface0D object.
       :type inter2: :class:`Interface0D`
       :return: True or false.
       :rtype: bool
    """

    name: str
    """The name of the binary 0D predicate.

:type: str"""

class BinaryPredicate1D:
    """Base class for binary predicates working on :class:`Interface1D`
    objects. A BinaryPredicate1D is typically an ordering relation
    between two Interface1D objects. The predicate evaluates a relation
    between the two Interface1D instances and returns a boolean value (true
    or false). It is used by invoking the __call__() method.

    .. method:: __init__()

       Default constructor.

    .. method:: __call__(inter1, inter2)

       Must be overload by inherited classes. It evaluates a relation
       between two Interface1D objects.

       :arg inter1: The first Interface1D object.
       :type inter1: :class:`Interface1D`
       :arg inter2: The second Interface1D object.
       :type inter2: :class:`Interface1D`
       :return: True or false.
       :rtype: bool
    """

    name: str
    """The name of the binary 1D predicate.

:type: str"""

class Chain:
    """Class hierarchy: :class:`Interface1D` > :class:`Curve` > :class:`Chain`

    Class to represent a 1D elements issued from the chaining process. A
    Chain is the last step before the :class:`Stroke` and is used in the
    Splitting and Creation processes.

    .. method:: __init__()
                __init__(brother)
                __init__(id)

       Builds a :class:`Chain` using the default constructor,
       copy constructor or from an :class:`Id`.

       :arg brother: A Chain object.
       :type brother: :class:`Chain`
       :arg id: An Id object.
       :type id: :class:`Id`
    """

    def push_viewedge_back(self, viewedge: ViewEdge, orientation: bool) -> None:
        """Adds a ViewEdge at the end of the Chain."""

    def push_viewedge_front(self, viewedge: ViewEdge, orientation: bool) -> None:
        """Adds a ViewEdge at the beginning of the Chain."""

class ChainingIterator:
    """Class hierarchy: :class:`Iterator` > :class:`ViewEdgeIterator` > :class:`ChainingIterator`

    Base class for chaining iterators. This class is designed to be
    overloaded in order to describe chaining rules. It makes the
    description of chaining rules easier. The two main methods that need
    to overloaded are traverse() and init(). traverse() tells which
    :class:`ViewEdge` to follow, among the adjacent ones. If you specify
    restriction rules (such as "Chain only ViewEdges of the selection"),
    they will be included in the adjacency iterator (i.e, the adjacent
    iterator will only stop on "valid" edges).

    .. method:: __init__(restrict_to_selection=True, restrict_to_unvisited=True,                     begin=None, orientation=True)
                __init__(brother)

       Builds a Chaining Iterator from the first ViewEdge used for
       iteration and its orientation or by using the copy constructor.

       :arg restrict_to_selection: Indicates whether to force the chaining
          to stay within the set of selected ViewEdges or not.
       :type restrict_to_selection: bool
       :arg restrict_to_unvisited: Indicates whether a ViewEdge that has
          already been chained must be ignored ot not.
       :type restrict_to_unvisited: bool
       :arg begin: The ViewEdge from which to start the chain.
       :type begin: :class:`ViewEdge` | None
       :arg orientation: The direction to follow to explore the graph. If
          true, the direction indicated by the first ViewEdge is used.
       :type orientation: bool
       :arg brother:
       :type brother: ChainingIterator
    """

    is_incrementing: bool
    """True if the current iteration is an incrementation.

:type: bool"""

    next_vertex: ViewVertex
    """The ViewVertex that is the next crossing.

:type: :class:`ViewVertex`"""

    object: ViewEdge
    """The ViewEdge object currently pointed by this iterator.

:type: :class:`ViewEdge`"""

    def init(self) -> None:
        """Initializes the iterator context. This method is called each
        time a new chain is started. It can be used to reset some
        history information that you might want to keep.
        """

    def traverse(self, it: AdjacencyIterator) -> ViewEdge | None:
        """This method iterates over the potential next ViewEdges and returns
        the one that will be followed next. Returns the next ViewEdge to
        follow or None when the end of the chain is reached.
        """

class Curve:
    """Class hierarchy: :class:`Interface1D` > :class:`Curve`

    Base class for curves made of CurvePoints. :class:`SVertex` is the
    type of the initial curve vertices. A :class:`Chain` is a
    specialization of a Curve.

    .. method:: __init__()
                __init__(brother)
                __init__(id)

       Builds a :class:`FrsCurve` using a default constructor,
       copy constructor or from an :class:`Id`.

       :arg brother: A Curve object.
       :type brother: :class:`Curve`
       :arg id: An Id object.
       :type id: :class:`Id`
    """

    is_empty: bool
    """True if the Curve doesn't have any Vertex yet.

:type: bool"""

    segments_size: int
    """The number of segments in the polyline constituting the Curve.

:type: int"""

    def push_vertex_back(self, vertex: SVertex | CurvePoint) -> None:
        """Adds a single vertex at the end of the Curve."""

    def push_vertex_front(self, vertex: SVertex | CurvePoint) -> None:
        """Adds a single vertex at the front of the Curve."""

class CurvePoint:
    """Class hierarchy: :class:`Interface0D` > :class:`CurvePoint`

    Class to represent a point of a curve. A CurvePoint can be any point
    of a 1D curve (it doesn't have to be a vertex of the curve). Any
    :class:`Interface1D` is built upon ViewEdges, themselves built upon
    FEdges. Therefore, a curve is basically a polyline made of a list of
    :class:`SVertex` objects. Thus, a CurvePoint is built by linearly
    interpolating two :class:`SVertex` instances. CurvePoint can be used
    as virtual points while querying 0D information along a curve at a
    given resolution.

    .. method:: __init__()
                __init__(brother)
                __init__(first_vertex, second_vertex, t2d)
                __init__(first_point, second_point, t2d)

       Builds a CurvePoint using the default constructor, copy constructor,
       or one of the overloaded constructors. The over loaded constructors
       can either take two :class:`SVertex` or two :class:`CurvePoint`
       objects and an interpolation parameter

       :arg brother: A CurvePoint object.
       :type brother: :class:`CurvePoint`
       :arg first_vertex: The first SVertex.
       :type first_vertex: :class:`SVertex`
       :arg second_vertex: The second SVertex.
       :type second_vertex: :class:`SVertex`
       :arg first_point: The first CurvePoint.
       :type first_point: :class:`CurvePoint`
       :arg second_point: The second CurvePoint.
       :type second_point: :class:`CurvePoint`
       :arg t2d: A 2D interpolation parameter used to linearly interpolate
                 first_vertex and second_vertex or first_point and second_point.
       :type t2d: float
    """

    fedge: FEdge
    """Gets the FEdge for the two SVertices that given CurvePoints consists out of.
A shortcut for CurvePoint.first_svertex.get_fedge(CurvePoint.second_svertex).

:type: :class:`FEdge`"""

    first_svertex: SVertex
    """The first SVertex upon which the CurvePoint is built.

:type: :class:`SVertex`"""

    second_svertex: SVertex
    """The second SVertex upon which the CurvePoint is built.

:type: :class:`SVertex`"""

    t2d: float
    """The 2D interpolation parameter.

:type: float"""

class CurvePointIterator:
    """Class hierarchy: :class:`Iterator` > :class:`CurvePointIterator`

    Class representing an iterator on a curve. Allows an iterating
    outside initial vertices. A CurvePoint is instantiated and returned
    through the .object attribute.

    .. method:: __init__()
                __init__(brother)
                __init__(step=0.0)

       Builds a CurvePointIterator object using either the default constructor,
       copy constructor, or the overloaded constructor.

       :arg brother: A CurvePointIterator object.
       :type brother: :class:`CurvePointIterator`
       :arg step: A resampling resolution with which the curve is resampled.
          If zero, no resampling is done (i.e., the iterator iterates over
          initial vertices).
       :type step: float
    """

    object: CurvePoint
    """The CurvePoint object currently pointed by this iterator.

:type: :class:`CurvePoint`"""

    t: float
    """The curvilinear abscissa of the current point.

:type: float"""

    u: float
    """The point parameter at the current point in the stroke (0 <= u <= 1).

:type: float"""

class FEdge:
    """Class hierarchy: :class:`Interface1D` > :class:`FEdge`

    Base Class for feature edges. This FEdge can represent a silhouette,
    a crease, a ridge/valley, a border or a suggestive contour. For
    silhouettes, the FEdge is oriented so that the visible face lies on
    the left of the edge. For borders, the FEdge is oriented so that the
    face lies on the left of the edge. An FEdge can represent an initial
    edge of the mesh or runs across a face of the initial mesh depending
    on the smoothness or sharpness of the mesh. This class is specialized
    into a smooth and a sharp version since their properties slightly vary
    from one to the other.

    .. method:: FEdge()
                FEdge(brother)

       Builds an :class:`FEdge` using the default constructor,
       copy constructor, or between two :class:`SVertex` objects.

       :arg brother: An FEdge object.
       :type brother: :class:`FEdge`
       :arg first_vertex: The first SVertex.
       :type first_vertex: :class:`SVertex`
       :arg second_vertex: The second SVertex.
       :type second_vertex: :class:`SVertex`
    """

    first_svertex: SVertex
    """The first SVertex constituting this FEdge.

:type: :class:`SVertex`"""

    id: Id
    """The Id of this FEdge.

:type: :class:`Id`"""

    is_smooth: bool
    """True if this FEdge is a smooth FEdge.

:type: bool"""

    nature: Nature
    """The nature of this FEdge.

:type: :class:`Nature`"""

    next_fedge: FEdge
    """The FEdge following this one in the ViewEdge. The value is None if
this FEdge is the last of the ViewEdge.

:type: :class:`FEdge`"""

    previous_fedge: FEdge
    """The FEdge preceding this one in the ViewEdge. The value is None if
this FEdge is the first one of the ViewEdge.

:type: :class:`FEdge`"""

    second_svertex: SVertex
    """The second SVertex constituting this FEdge.

:type: :class:`SVertex`"""

    viewedge: ViewEdge
    """The ViewEdge to which this FEdge belongs to.

:type: :class:`ViewEdge`"""

    def __getitem__(self, key: int | slice) -> None:
        """Return self[key]."""

    def __len__(self) -> int:
        """Return len(self)."""

    def __iter__(self) -> collections.abc.Iterator[None]: ...

class FEdgeSharp:
    """Class hierarchy: :class:`Interface1D` > :class:`FEdge` > :class:`FEdgeSharp`

    Class defining a sharp FEdge. A Sharp FEdge corresponds to an initial
    edge of the input mesh. It can be a silhouette, a crease or a border.
    If it is a crease edge, then it is bordered by two faces of the mesh.
    Face a lies on its right whereas Face b lies on its left. If it is a
    border edge, then it doesn't have any face on its right, and thus Face
    a is None.

    .. method:: __init__()
                __init__(brother)
                __init__(first_vertex, second_vertex)

       Builds an :class:`FEdgeSharp` using the default constructor,
       copy constructor, or between two :class:`SVertex` objects.

       :arg brother: An FEdgeSharp object.
       :type brother: :class:`FEdgeSharp`
       :arg first_vertex: The first SVertex object.
       :type first_vertex: :class:`SVertex`
       :arg second_vertex: The second SVertex object.
       :type second_vertex: :class:`SVertex`
    """

    face_mark_left: bool
    """The face mark of the face lying on the left of the FEdge.

:type: bool"""

    face_mark_right: bool
    """The face mark of the face lying on the right of the FEdge. If this FEdge
is a border, it has no face on the right and thus this property is set to
false.

:type: bool"""

    material_index_left: int
    """The index of the material of the face lying on the left of the FEdge.

:type: int"""

    material_index_right: int
    """The index of the material of the face lying on the right of the FEdge.
If this FEdge is a border, it has no Face on its right and therefore
no material.

:type: int"""

    material_left: Material
    """The material of the face lying on the left of the FEdge.

:type: :class:`Material`"""

    material_right: Material
    """The material of the face lying on the right of the FEdge. If this FEdge
is a border, it has no Face on its right and therefore no material.

:type: :class:`Material`"""

    @property
    def normal_left(self) -> mathutils.Vector:
        """The normal to the face lying on the left of the FEdge.

        :type: :class:`mathutils.Vector`"""

    @normal_left.setter
    def normal_left(self, value: mathutils.Vector | Sequence[float]) -> None: ...
    @property
    def normal_right(self) -> mathutils.Vector:
        """The normal to the face lying on the right of the FEdge. If this FEdge
        is a border, it has no Face on its right and therefore no normal.

        :type: :class:`mathutils.Vector`"""

    @normal_right.setter
    def normal_right(self, value: mathutils.Vector | Sequence[float]) -> None: ...

class FEdgeSmooth:
    """Class hierarchy: :class:`Interface1D` > :class:`FEdge` > :class:`FEdgeSmooth`

    Class defining a smooth edge. This kind of edge typically runs across
    a face of the input mesh. It can be a silhouette, a ridge or valley,
    a suggestive contour.

    .. method:: __init__()
                __init__(brother)
                __init__(first_vertex, second_vertex)

       Builds an :class:`FEdgeSmooth` using the default constructor,
       copy constructor, or between two :class:`SVertex`.

       :arg brother: An FEdgeSmooth object.
       :type brother: :class:`FEdgeSmooth`
       :arg first_vertex: The first SVertex object.
       :type first_vertex: :class:`SVertex`
       :arg second_vertex: The second SVertex object.
       :type second_vertex: :class:`SVertex`
    """

    face_mark: bool
    """The face mark of the face that this FEdge is running across.

:type: bool"""

    material: Material
    """The material of the face that this FEdge is running across.

:type: :class:`Material`"""

    material_index: int
    """The index of the material of the face that this FEdge is running across.

:type: int"""

    @property
    def normal(self) -> mathutils.Vector:
        """The normal of the face that this FEdge is running across.

        :type: :class:`mathutils.Vector`"""

    @normal.setter
    def normal(self, value: mathutils.Vector | Sequence[float]) -> None: ...

class Id:
    """Class for representing an object Id.

    .. method:: __init__(brother)
                __init__(first=0, second=0)

       Build the Id from two numbers or another :class:`Id` using the copy constructor.

       :arg brother: An Id object.
       :type brother: :class:`Id`   :arg first: The first number.
       :type first: int
       :arg second: The second number.
       :type second: int
    """

    first: int
    """The first number constituting the Id.

:type: int"""

    second: int
    """The second number constituting the Id.

:type: int"""

    @override
    def __eq__(self, value: object, /) -> bool:
        """Return self==value."""

    def __ge__(self, value: object, /) -> bool:
        """Return self>=value."""

    def __gt__(self, value: object, /) -> bool:
        """Return self>value."""

    def __le__(self, value: object, /) -> bool:
        """Return self<=value."""

    def __lt__(self, value: object, /) -> bool:
        """Return self<value."""

    @override
    def __ne__(self, value: object, /) -> bool:
        """Return self!=value."""

class IntegrationType:
    """Class hierarchy: int > :class:`IntegrationType`

    Different integration methods that can be invoked to integrate into a
    single value the set of values obtained from each 0D element of an 1D
    element:

    * IntegrationType.MEAN: The value computed for the 1D element is the
      mean of the values obtained for the 0D elements.
    * IntegrationType.MIN: The value computed for the 1D element is the
      minimum of the values obtained for the 0D elements.
    * IntegrationType.MAX: The value computed for the 1D element is the
      maximum of the values obtained for the 0D elements.
    * IntegrationType.FIRST: The value computed for the 1D element is the
      first of the values obtained for the 0D elements.
    * IntegrationType.LAST: The value computed for the 1D element is the
      last of the values obtained for the 0D elements.
    """

    @property
    def FIRST(self) -> IntegrationType: ...
    @property
    def LAST(self) -> IntegrationType: ...
    @property
    def MAX(self) -> IntegrationType: ...
    @property
    def MEAN(self) -> IntegrationType: ...
    @property
    def MIN(self) -> IntegrationType: ...

class Interface0D:
    """Base class for any 0D element.

    .. method:: __init__()

       Default constructor.
    """

    id: Id
    """The Id of this 0D element.

:type: :class:`Id`"""

    name: str
    """The string of the name of this 0D element.

:type: str"""

    nature: Nature
    """The nature of this 0D element.

:type: :class:`Nature`"""

    @property
    def point_2d(self) -> mathutils.Vector:
        """The 2D point of this 0D element.

        :type: :class:`mathutils.Vector`"""

    @point_2d.setter
    def point_2d(self, value: mathutils.Vector | Sequence[float]) -> None: ...
    @property
    def point_3d(self) -> mathutils.Vector:
        """The 3D point of this 0D element.

        :type: :class:`mathutils.Vector`"""

    @point_3d.setter
    def point_3d(self, value: mathutils.Vector | Sequence[float]) -> None: ...

    projected_x: float
    """The X coordinate of the projected 3D point of this 0D element.

:type: float"""

    projected_y: float
    """The Y coordinate of the projected 3D point of this 0D element.

:type: float"""

    projected_z: float
    """The Z coordinate of the projected 3D point of this 0D element.

:type: float"""

    def get_fedge(self, inter: Interface0D) -> FEdge:
        """Returns the FEdge that lies between this 0D element and the 0D
        element given as the argument.
        """

class Interface0DIterator:
    """Class hierarchy: :class:`Iterator` > :class:`Interface0DIterator`

    Class defining an iterator over Interface0D elements. An instance of
    this iterator is always obtained from a 1D element.

    .. method:: __init__(brother)
                __init__(it)

       Construct a nested Interface0DIterator using either the copy constructor
       or the constructor that takes an argument of a Function0D.

       :arg brother: An Interface0DIterator object.
       :type brother: :class:`Interface0DIterator`
       :arg it: An iterator object to be nested.
       :type it: :class:`SVertexIterator` | :class:`CurvePointIterator` | :class:`StrokeVertexIterator`
    """

    at_last: bool
    """True if the iterator points to the last valid element.
For its counterpart (pointing to the first valid element), use it.is_begin.

:type: bool"""

    object: Interface0D | builtins.object
    """The 0D object currently pointed to by this iterator. Note that the object
may be an instance of an Interface0D subclass. For example if the iterator
has been created from the `vertices_begin()` method of the :class:`Stroke`
class, the .object property refers to a :class:`StrokeVertex` object.

:type: :class:`Interface0D` or one of its subclasses."""

    t: float
    """The curvilinear abscissa of the current point.

:type: float"""

    u: float
    """The point parameter at the current point in the 1D element (0 <= u <= 1).

:type: float"""

    def __iter__(self) -> None:
        """Implement iter(self)."""

class Interface1D:
    """Base class for any 1D element.

    .. method:: __init__()

       Default constructor.
    """

    id: Id
    """The Id of this Interface1D.

:type: :class:`Id`"""

    length_2d: float
    """The 2D length of this Interface1D.

:type: float"""

    name: str
    """The string of the name of the 1D element.

:type: str"""

    nature: Nature
    """The nature of this Interface1D.

:type: :class:`Nature`"""

    time_stamp: int
    """The time stamp of the 1D element, mainly used for selection.

:type: int"""

    def points_begin(self, t: float = 0.0) -> Interface0DIterator:
        """Returns an iterator over the Interface1D points, pointing to the
        first point. The difference with vertices_begin() is that here we can
        iterate over points of the 1D element at a any given sampling.
        Indeed, for each iteration, a virtual point is created.
        """

    def points_end(self, t: float = 0.0) -> Interface0DIterator:
        """Returns an iterator over the Interface1D points, pointing after the
        last point. The difference with vertices_end() is that here we can
        iterate over points of the 1D element at a given sampling. Indeed,
        for each iteration, a virtual point is created.
        """

    def vertices_begin(self) -> Interface0DIterator:
        """Returns an iterator over the Interface1D vertices, pointing to the
        first vertex.
        """

    def vertices_end(self) -> Interface0DIterator:
        """Returns an iterator over the Interface1D vertices, pointing after
        the last vertex.
        """

class Iterator(Generic[_T]):
    """Base class to define iterators.

    .. method:: __init__()

       Default constructor.
    """

    is_begin: bool
    """True if the iterator points to the first element.

:type: bool"""

    is_end: bool
    """True if the iterator points to the last element.

:type: bool"""

    name: str
    """The string of the name of this iterator.

:type: str"""

    def decrement(self) -> None:
        """Makes the iterator point the previous element."""

    def increment(self) -> None:
        """Makes the iterator point the next element."""

class Material:
    """Class defining a material.

    .. method:: __init__()
                __init__(brother)
                __init__(line, diffuse, ambient, specular, emission, shininess, priority)

       Creates a :class:`FrsMaterial` using either default constructor,
       copy constructor, or an overloaded constructor

       :arg brother: A Material object to be used as a copy constructor.
       :type brother: :class:`Material`
       :arg line: The line color.
       :type line: :class:`mathutils.Vector` | tuple[float, float, float, float] | list[float]
       :arg diffuse: The diffuse color.
       :type diffuse:
       :arg ambient: The ambient color.
       :type ambient: :class:`mathutils.Vector` | tuple[float, float, float, float] | list[float]
       :arg specular: The specular color.
       :type specular: :class:`mathutils.Vector` | tuple[float, float, float, float] | list[float]
       :arg emission: The emissive color.
       :type emission: :class:`mathutils.Vector` | tuple[float, float, float, float] | list[float]
       :arg shininess: The shininess coefficient.
       :type shininess: float
       :arg priority: The line color priority.
       :type priority: int
    """

    @property
    def ambient(self) -> mathutils.Color:
        """RGBA components of the ambient color of the material.

        :type: :class:`mathutils.Color`"""

    @ambient.setter
    def ambient(self, value: mathutils.Color | Sequence[float]) -> None: ...
    @property
    def diffuse(self) -> mathutils.Vector:
        """RGBA components of the diffuse color of the material.

        :type: :class:`mathutils.Vector`"""

    @diffuse.setter
    def diffuse(self, value: mathutils.Vector | Sequence[float]) -> None: ...
    @property
    def emission(self) -> mathutils.Color:
        """RGBA components of the emissive color of the material.

        :type: :class:`mathutils.Color`"""

    @emission.setter
    def emission(self, value: mathutils.Color | Sequence[float]) -> None: ...
    @property
    def line(self) -> mathutils.Vector:
        """RGBA components of the line color of the material.

        :type: :class:`mathutils.Vector`"""

    @line.setter
    def line(self, value: mathutils.Vector | Sequence[float]) -> None: ...

    priority: int
    """Line color priority of the material.

:type: int"""

    shininess: float
    """Shininess coefficient of the material.

:type: float"""

    @property
    def specular(self) -> mathutils.Vector:
        """RGBA components of the specular color of the material.

        :type: :class:`mathutils.Vector`"""

    @specular.setter
    def specular(self, value: mathutils.Vector | Sequence[float]) -> None: ...
    @override
    def __eq__(self, value: object, /) -> bool:
        """Return self==value."""

    def __ge__(self, value: object, /) -> bool:
        """Return self>=value."""

    def __gt__(self, value: object, /) -> bool:
        """Return self>value."""

    def __le__(self, value: object, /) -> bool:
        """Return self<=value."""

    def __lt__(self, value: object, /) -> bool:
        """Return self<value."""

    @override
    def __ne__(self, value: object, /) -> bool:
        """Return self!=value."""

class MediumType:
    """Class hierarchy: int > :class:`MediumType`

    The different blending modes available to simulate the interaction
    media-medium:

    * Stroke.DRY_MEDIUM: To simulate a dry medium such as Pencil or Charcoal.
    * Stroke.HUMID_MEDIUM: To simulate ink painting (color subtraction blending).
    * Stroke.OPAQUE_MEDIUM: To simulate an opaque medium (oil, spray...).
    """

class Nature:
    """Class hierarchy: int > :class:`Nature`

    Different possible natures of 0D and 1D elements of the ViewMap.

    Vertex natures:

    * Nature.POINT: True for any 0D element.
    * Nature.S_VERTEX: True for SVertex.
    * Nature.VIEW_VERTEX: True for ViewVertex.
    * Nature.NON_T_VERTEX: True for NonTVertex.
    * Nature.T_VERTEX: True for TVertex.
    * Nature.CUSP: True for CUSP.

    Edge natures:

    * Nature.NO_FEATURE: True for non feature edges (always false for 1D
      elements of the ViewMap).
    * Nature.SILHOUETTE: True for silhouettes.
    * Nature.BORDER: True for borders.
    * Nature.CREASE: True for creases.
    * Nature.RIDGE: True for ridges.
    * Nature.VALLEY: True for valleys.
    * Nature.SUGGESTIVE_CONTOUR: True for suggestive contours.
    * Nature.MATERIAL_BOUNDARY: True for edges at material boundaries.
    * Nature.EDGE_MARK: True for edges having user-defined edge marks.
    """

    @property
    def BORDER(self) -> Nature: ...
    @property
    def CREASE(self) -> Nature: ...
    @property
    def CUSP(self) -> Nature: ...
    @property
    def EDGE_MARK(self) -> Nature: ...
    @property
    def MATERIAL_BOUNDARY(self) -> Nature: ...
    @property
    def NON_T_VERTEX(self) -> Nature: ...
    @property
    def NO_FEATURE(self) -> Nature: ...
    @property
    def POINT(self) -> Nature: ...
    @property
    def RIDGE(self) -> Nature: ...
    @property
    def SILHOUETTE(self) -> Nature: ...
    @property
    def SUGGESTIVE_CONTOUR(self) -> Nature: ...
    @property
    def S_VERTEX(self) -> Nature: ...
    @property
    def T_VERTEX(self) -> Nature: ...
    @property
    def VALLEY(self) -> Nature: ...
    @property
    def VIEW_VERTEX(self) -> Nature: ...

class Noise:
    """Class to provide Perlin noise functionalities.

    .. method:: __init__(seed = -1)

       Builds a Noise object. Seed is an optional argument. The seed value is used
       as a seed for random number generation if it is equal to or greater than zero;
       otherwise, time is used as a seed.

       :arg seed: Seed for random number generation.
       :type seed: int
    """

    def rand(self) -> None: ...
    def smoothNoise1(self, v: float) -> float:
        """Returns a smooth noise value for a 1D element."""

    def smoothNoise2(
        self, v: mathutils.Vector | tuple[float, float] | list[float]
    ) -> float:
        """Returns a smooth noise value for a 2D element."""

    def smoothNoise3(
        self, v: mathutils.Vector | tuple[float, float, float] | list[float]
    ) -> float:
        """Returns a smooth noise value for a 3D element."""

    def turbulence1(self, v: float, freq: float, amp: float, oct: int = 4) -> float:
        """Returns a noise value for a 1D element."""

    def turbulence2(
        self,
        v: mathutils.Vector | tuple[float, float] | list[float],
        freq: float,
        amp: float,
        oct: int = 4,
    ) -> float:
        """Returns a noise value for a 2D element."""

    def turbulence3(
        self,
        v: mathutils.Vector | tuple[float, float, float] | list[float],
        freq: float,
        amp: float,
        oct: int = 4,
    ) -> float:
        """Returns a noise value for a 3D element."""

    def turbulence_smooth(self) -> None: ...

class NonTVertex:
    """Class hierarchy: :class:`Interface0D` > :class:`ViewVertex` > :class:`NonTVertex`

    View vertex for corners, cusps, etc. associated to a single SVertex.
    Can be associated to 2 or more view edges.

    .. method:: __init__()
                __init__(svertex)

       Builds a :class:`NonTVertex` using the default constructor or a :class:`SVertex`.

       :arg svertex: An SVertex object.
       :type svertex: :class:`SVertex`
    """

    svertex: SVertex
    """The SVertex on top of which this NonTVertex is built.

:type: :class:`SVertex`"""

class Operators:
    """Class defining the operators used in a style module. There are five
    types of operators: Selection, chaining, splitting, sorting and
    creation. All these operators are user controlled through functors,
    predicates and shaders that are taken as arguments.
    """

    def bidirectional_chain(self, it: ChainingIterator, pred: UnaryPredicate1D) -> None:
        """Builds a set of chains from the current set of ViewEdges. Each
        ViewEdge of the current list potentially starts a new chain. The
        chaining operator then iterates over the ViewEdges of the ViewMap
        using the user specified iterator. This operator iterates both using
        the increment and decrement operators and is therefore bidirectional.
        This operator works with a ChainingIterator which contains the
        chaining rules. It is this last one which can be told to chain only
        edges that belong to the selection or not to process twice a ViewEdge
        during the chaining. Each time a ViewEdge is added to a chain, its
        chaining time stamp is incremented. This allows you to keep track of
        the number of chains to which a ViewEdge belongs to.
        """

    def chain(
        self,
        it: ViewEdgeIterator,
        pred: UnaryPredicate1D,
        modifier: UnaryFunction1DVoid,
    ) -> None:
        """Builds a set of chains from the current set of ViewEdges. Each
        ViewEdge of the current list starts a new chain. The chaining
        operator then iterates over the ViewEdges of the ViewMap using the
        user specified iterator. This operator only iterates using the
        increment operator and is therefore unidirectional.
        """

    def create(self, pred: UnaryPredicate1D, shaders: list[StrokeShader]) -> None:
        """Creates and shades the strokes from the current set of chains. A
        predicate can be specified to make a selection pass on the chains.
        """

    def get_chain_from_index(self, i: int) -> Chain:
        """Returns the Chain at the index in the current set of Chains."""

    def get_chains_size(self) -> int:
        """Returns the number of Chains."""

    def get_stroke_from_index(self, i: int) -> Stroke:
        """Returns the Stroke at the index in the current set of Strokes."""

    def get_strokes_size(self) -> int:
        """Returns the number of Strokes."""

    def get_view_edges_size(self) -> int:
        """Returns the number of ViewEdges."""

    def get_viewedge_from_index(self, i: int) -> ViewEdge:
        """Returns the ViewEdge at the index in the current set of ViewEdges."""

    def recursive_split(
        self,
        func: UnaryFunction0DDouble,
        pred_0d: UnaryPredicate0D,
        pred_1d: UnaryPredicate1D,
        sampling: float,
    ) -> None:
        """Splits the current set of chains in a recursive way. We process the
        points of each chain (with a specified sampling) to find the point
        minimizing a specified function. The chain is split in two at this
        point and the two new chains are processed in the same way. The
        recursivity level is controlled through a predicate 1D that expresses
        a stopping condition on the chain that is about to be processed.

        The user can also specify a 0D predicate to make a first selection on the points
        that can potentially be split. A point that doesn't verify the 0D
        predicate won't be candidate in realizing the min.
        """

    def reset(self, delete_strokes: bool) -> None:
        """Resets the line stylization process to the initial state. The results of
        stroke creation are accumulated if **delete_strokes** is set to False.
        """

    def select(self, pred: UnaryPredicate1D) -> None:
        """Selects the ViewEdges of the ViewMap verifying a specified
        condition.
        """

    def sequential_split(
        self,
        starting_pred: UnaryPredicate0D,
        stopping_pred: UnaryPredicate0D,
        pred: UnaryPredicate0D,
        sampling: float,
    ) -> None:
        """Splits each chain of the current set of chains in a sequential way.
        The points of each chain are processed (with a specified sampling)
        sequentially. The first point of the initial chain is the
        first point of one of the resulting chains. The splitting ends when
        no more chain can start.
        """

    def sort(self, pred: BinaryPredicate1D) -> None:
        """Sorts the current set of chains (or viewedges) according to the
        comparison predicate given as argument.
        """

class SShape:
    """Class to define a feature shape. It is the gathering of feature
    elements from an identified input shape.

    .. method:: __init__()
                __init__(brother)

       Creates a :class:`SShape` class using either a default constructor or copy constructor.

       :arg brother: An SShape object.
       :type brother: :class:`SShape`
    """

    bbox: BBox
    """The bounding box of the SShape.

:type: :class:`BBox`"""

    edges: list[object]
    """The list of edges constituting this SShape.

:type: List of :class:`FEdge`"""

    id: Id
    """The Id of this SShape.

:type: :class:`Id`"""

    name: str
    """The name of the SShape.

:type: str"""

    vertices: list[object]
    """The list of vertices constituting this SShape.

:type: List of :class:`SVertex`"""

    def add_edge(self, edge: FEdge) -> None:
        """Adds an FEdge to the list of FEdges."""

    def add_vertex(self, vertex: SVertex) -> None:
        """Adds an SVertex to the list of SVertex of this Shape. The SShape
        attribute of the SVertex is also set to this SShape.
        """

    def compute_bbox(self) -> None:
        """Compute the bbox of the SShape."""

class SVertex:
    """Class hierarchy: :class:`Interface0D` > :class:`SVertex`

    Class to define a vertex of the embedding.

    .. method:: __init__()
                __init__(brother)
                __init__(point_3d, id)

       Builds a :class:`SVertex` using the default constructor,
       copy constructor or the overloaded constructor which builds   a :class:`SVertex` from 3D coordinates and an Id.

       :arg brother: A SVertex object.
       :type brother: :class:`SVertex`
       :arg point_3d: A three-dimensional vector.
       :type point_3d: :class:`mathutils.Vector`
       :arg id: An Id object.
       :type id: :class:`Id`
    """

    curvatures: tuple[object, ...]
    """Curvature information expressed in the form of a seven-element tuple
(K1, e1, K2, e2, Kr, er, dKr), where K1 and K2 are scalar values
representing the first (maximum) and second (minimum) principal
curvatures at this SVertex, respectively; e1 and e2 are
three-dimensional vectors representing the first and second principal
directions, i.e. the directions of the normal plane where the
curvature takes its maximum and minimum values, respectively; and Kr,
er and dKr are the radial curvature, radial direction, and the
derivative of the radial curvature at this SVertex, respectively.

:type: tuple"""

    id: Id
    """The Id of this SVertex.

:type: :class:`Id`"""

    normals: list[mathutils.Vector]
    """The normals for this Vertex as a list. In a sharp surface, an SVertex
has exactly one normal. In a smooth surface, an SVertex can have any
number of normals.

:type: list of :class:`mathutils.Vector`"""

    normals_size: int
    """The number of different normals for this SVertex.

:type: int"""

    @property
    def point_2d(self) -> mathutils.Vector:
        """The projected 3D coordinates of the SVertex.

        :type: :class:`mathutils.Vector`"""

    @point_2d.setter
    def point_2d(self, value: mathutils.Vector | Sequence[float]) -> None: ...
    @property
    def point_3d(self) -> mathutils.Vector:
        """The 3D coordinates of the SVertex.

        :type: :class:`mathutils.Vector`"""

    @point_3d.setter
    def point_3d(self, value: mathutils.Vector | Sequence[float]) -> None: ...

    viewvertex: ViewVertex
    """If this SVertex is also a ViewVertex, this property refers to the
ViewVertex, and None otherwise.

:type: :class:`ViewVertex`"""

    def add_fedge(self, fedge: FEdge) -> None:
        """Add an FEdge to the list of edges emanating from this SVertex."""

    def add_normal(
        self, normal: mathutils.Vector | tuple[float, float, float] | list[float]
    ) -> None:
        """Adds a normal to the SVertex's set of normals. If the same normal
        is already in the set, nothing changes.
        """

class SVertexIterator:
    """Class hierarchy: :class:`Iterator` > :class:`SVertexIterator`

    Class representing an iterator over :class:`SVertex` of a
    :class:`ViewEdge`. An instance of an SVertexIterator can be obtained
    from a ViewEdge by calling verticesBegin() or verticesEnd().

    .. method:: __init__()
                __init__(brother)
                __init__(vertex, begin, previous_edge, next_edge, t)
       Build an SVertexIterator using either the default constructor, copy constructor,
       or the overloaded constructor that starts iteration from an SVertex object vertex.

       :arg brother: An SVertexIterator object.
       :type brother: :class:`SVertexIterator`
       :arg vertex: The SVertex from which the iterator starts iteration.
       :type vertex: :class:`SVertex`
       :arg begin: The first SVertex of a ViewEdge.
       :type begin: :class:`SVertex`
       :arg previous_edge: The previous FEdge coming to vertex.
       :type previous_edge: :class:`FEdge`
       :arg next_edge: The next FEdge going out from vertex.
       :type next_edge: :class:`FEdge`
       :arg t: The curvilinear abscissa at vertex.
       :type t: float
    """

    object: SVertex
    """The SVertex object currently pointed by this iterator.

:type: :class:`SVertex`"""

    t: float
    """The curvilinear abscissa of the current point.

:type: float"""

    u: float
    """The point parameter at the current point in the 1D element (0 <= u <= 1).

:type: float"""

class Stroke:
    """Class hierarchy: :class:`Interface1D` > :class:`Stroke`

    Class to define a stroke. A stroke is made of a set of 2D vertices
    (:class:`StrokeVertex`), regularly spaced out. This set of vertices
    defines the stroke's backbone geometry. Each of these stroke vertices
    defines the stroke's shape and appearance at this vertex position.

    .. method:: Stroke()
                Stroke(brother)

       Creates a :class:`Stroke` using the default constructor or copy constructor
    """

    @property
    def DRY_MEDIUM(self) -> MediumType: ...
    @property
    def HUMID_MEDIUM(self) -> MediumType: ...
    @property
    def OPAQUE_MEDIUM(self) -> MediumType: ...

    id: Id
    """The Id of this Stroke.

:type: :class:`Id`"""

    length_2d: float
    """The 2D length of the Stroke.

:type: float"""

    medium_type: MediumType
    """The MediumType used for this Stroke.

:type: :class:`MediumType`"""

    texture_id: int
    """The ID of the texture used to simulate th marks system for this Stroke.

:type: int"""

    tips: bool
    """True if this Stroke uses a texture with tips, and false otherwise.

:type: bool"""

    def __getitem__(self, key: object, /) -> None:
        """Return self[key]."""

    def __iter__(self) -> None:
        """Implement iter(self)."""

    def __len__(self) -> int:
        """Return len(self)."""

    def compute_sampling(self, n: int) -> float:
        """Compute the sampling needed to get N vertices. If the
        specified number of vertices is less than the actual number of
        vertices, the actual sampling value is returned. (To remove Vertices,
        use the RemoveVertex() method of this class.)
        """

    def insert_vertex(self, vertex: StrokeVertex, next: StrokeVertexIterator) -> None:
        """Inserts the StrokeVertex given as argument into the Stroke before the
        point specified by next. The length and curvilinear abscissa are
        updated consequently.
        """

    def remove_all_vertices(self) -> None:
        """Removes all vertices from the Stroke."""

    def remove_vertex(self, vertex: StrokeVertex) -> None:
        """Removes the StrokeVertex given as argument from the Stroke. The length
        and curvilinear abscissa are updated consequently.
        """

    def resample(self, n: int) -> None:
        """Resamples the stroke so using one of two methods with the goal
        of creating a stroke with fewer points and the same shape.
        """

    def stroke_vertices_begin(self, t: float = 0.0) -> StrokeVertexIterator:
        """Returns a StrokeVertexIterator pointing on the first StrokeVertex of
        the Stroke. One can specify a sampling value to re-sample the Stroke
        on the fly if needed.
        """

    def stroke_vertices_end(self) -> StrokeVertexIterator:
        """Returns a StrokeVertexIterator pointing after the last StrokeVertex
        of the Stroke.
        """

    def stroke_vertices_size(self) -> int:
        """Returns the number of StrokeVertex constituting the Stroke."""

    def update_length(self) -> None:
        """Updates the 2D length of the Stroke."""

class StrokeAttribute:
    """Class to define a set of attributes associated with a :class:`StrokeVertex`.
    The attribute set stores the color, alpha and thickness values for a Stroke
    Vertex.

    .. method:: __init__()
                __init__(brother)
                __init__(red, green, blue, alpha, thickness_right, thickness_left)
                __init__(attribute1, attribute2, t)

       Creates a :class:`StrokeAttribute` object using either a default constructor,
       copy constructor, overloaded constructor, or and interpolation constructor
       to interpolate between two :class:`StrokeAttribute` objects.

       :arg brother: A StrokeAttribute object to be used as a copy constructor.
       :type brother: :class:`StrokeAttribute`
       :arg red: Red component of a stroke color.
       :type red: float
       :arg green: Green component of a stroke color.
       :type green: float
       :arg blue: Blue component of a stroke color.
       :type blue: float
       :arg alpha: Alpha component of a stroke color.
       :type alpha: float
       :arg thickness_right: Stroke thickness on the right.
       :type thickness_right: float
       :arg thickness_left: Stroke thickness on the left.
       :type thickness_left: float
       :arg attribute1: The first StrokeAttribute object.
       :type attribute1: :class:`StrokeAttribute`
       :arg attribute2: The second StrokeAttribute object.
       :type attribute2: :class:`StrokeAttribute`
       :arg t: The interpolation parameter (0 <= t <= 1).
       :type t: float
    """

    alpha: float
    """Alpha component of the stroke color.

:type: float"""

    @property
    def color(self) -> mathutils.Color:
        """RGB components of the stroke color.

        :type: :class:`mathutils.Color`"""

    @color.setter
    def color(self, value: mathutils.Color | Sequence[float]) -> None: ...
    @property
    def thickness(self) -> mathutils.Vector:
        """Right and left components of the stroke thickness.
        The right (left) component is the thickness on the right (left) of the vertex
        when following the stroke.

        :type: :class:`mathutils.Vector`"""

    @thickness.setter
    def thickness(self, value: mathutils.Vector | Sequence[float]) -> None: ...

    visible: bool
    """The visibility flag. True if the StrokeVertex is visible.

:type: bool"""

    def get_attribute_real(self, name: str) -> float:
        """Returns an attribute of float type."""

    def get_attribute_vec2(self, name: str) -> mathutils.Vector:
        """Returns an attribute of two-dimensional vector type."""

    def get_attribute_vec3(self, name: str) -> mathutils.Vector:
        """Returns an attribute of three-dimensional vector type."""

    def has_attribute_real(self, name: str) -> bool:
        """Checks whether the attribute name of float type is available."""

    def has_attribute_vec2(self, name: str) -> bool:
        """Checks whether the attribute name of two-dimensional vector type
        is available.
        """

    def has_attribute_vec3(self, name: str) -> bool:
        """Checks whether the attribute name of three-dimensional vector
        type is available.
        """

    def set_attribute_real(self, name: str, value: float) -> None:
        """Adds a user-defined attribute of float type. If there is no
        attribute of the given name, it is added. Otherwise, the new value
        replaces the old one.
        """

    def set_attribute_vec2(
        self,
        name: str,
        value: mathutils.Vector | tuple[float, float, float] | list[float],
    ) -> None:
        """Adds a user-defined attribute of two-dimensional vector type. If
        there is no attribute of the given name, it is added. Otherwise,
        the new value replaces the old one.
        """

    def set_attribute_vec3(
        self,
        name: str,
        value: mathutils.Vector | tuple[float, float, float] | list[float],
    ) -> None:
        """Adds a user-defined attribute of three-dimensional vector type.
        If there is no attribute of the given name, it is added.
        Otherwise, the new value replaces the old one.
        """

class StrokeShader:
    """Base class for stroke shaders. Any stroke shader must inherit from
    this class and overload the shade() method. A StrokeShader is
    designed to modify stroke attributes such as thickness, color,
    geometry, texture, blending mode, and so on. The basic way for this
    operation is to iterate over the stroke vertices of the :class:`Stroke`
    and to modify the :class:`StrokeAttribute` of each vertex. Here is a
    code example of such an iteration::

      it = ioStroke.strokeVerticesBegin()
      while not it.is_end:
          att = it.object.attribute
          ## perform here any attribute modification
          it.increment()

    .. method:: __init__()

       Default constructor.
    """

    name: str
    """The name of the stroke shader.

:type: str"""

    def shade(self, stroke: Stroke) -> None:
        """The shading method. Must be overloaded by inherited classes."""

class StrokeVertex:
    """Class hierarchy: :class:`Interface0D` > :class:`CurvePoint` > :class:`StrokeVertex`

    Class to define a stroke vertex.

    .. method:: __init__()
                __init__(brother)
                __init__(first_vertex, second_vertex, t3d)
                __init__(point)
                __init__(svertex)
                __init__(svertex, attribute)

       Builds a :class:`StrokeVertex` using the default constructor,
       copy constructor, from 2 :class:`StrokeVertex` and an interpolation parameter,
       from a CurvePoint, from a SVertex, or a :class:`SVertex`   and a :class:`StrokeAttribute` object.

       :arg brother: A StrokeVertex object.
       :type brother: :class:`StrokeVertex`
       :arg first_vertex: The first StrokeVertex.
       :type first_vertex: :class:`StrokeVertex`
       :arg second_vertex: The second StrokeVertex.
       :type second_vertex: :class:`StrokeVertex`
       :arg t3d: An interpolation parameter.
       :type t3d: float
       :arg point: A CurvePoint object.
       :type point: :class:`CurvePoint`
       :arg svertex: An SVertex object.
       :type svertex: :class:`SVertex`
       :arg svertex: An SVertex object.
       :type svertex: :class:`SVertex`
       :arg attribute: A StrokeAttribute object.
       :type attribute: :class:`StrokeAttribute`
    """

    attribute: StrokeAttribute
    """StrokeAttribute for this StrokeVertex.

:type: :class:`StrokeAttribute`"""

    curvilinear_abscissa: float
    """Curvilinear abscissa of this StrokeVertex in the Stroke.

:type: float"""

    @property
    def point(self) -> mathutils.Vector:
        """2D point coordinates.

        :type: :class:`mathutils.Vector`"""

    @point.setter
    def point(self, value: mathutils.Vector | Sequence[float]) -> None: ...

    stroke_length: float
    """Stroke length (it is only a value retained by the StrokeVertex,
and it won't change the real stroke length).

:type: float"""

    u: float
    """Curvilinear abscissa of this StrokeVertex in the Stroke.

:type: float"""

class StrokeVertexIterator:
    """Class hierarchy: :class:`Iterator` > :class:`StrokeVertexIterator`

    Class defining an iterator designed to iterate over the
    :class:`StrokeVertex` of a :class:`Stroke`. An instance of a
    StrokeVertexIterator can be obtained from a Stroke by calling
    iter(), stroke_vertices_begin() or stroke_vertices_begin(). It is iterating
    over the same vertices as an :class:`Interface0DIterator`. The difference
    resides in the object access: an Interface0DIterator only allows
    access to an Interface0D while one might need to access the
    specialized StrokeVertex type. In this case, one should use a
    StrokeVertexIterator. To call functions of the UnaryFuntion0D type,
    a StrokeVertexIterator can be converted to an Interface0DIterator by
    by calling Interface0DIterator(it).

    .. method:: __init__()
                __init__(brother)

       Creates a :class:`StrokeVertexIterator` using either the
       default constructor or the copy constructor.

       :arg brother: A StrokeVertexIterator object.
       :type brother: :class:`StrokeVertexIterator`
    """

    at_last: bool
    """True if the iterator points to the last valid element.
For its counterpart (pointing to the first valid element), use it.is_begin.

:type: bool"""

    object: StrokeVertex
    """The StrokeVertex object currently pointed to by this iterator.

:type: :class:`StrokeVertex`"""

    t: float
    """The curvilinear abscissa of the current point.

:type: float"""

    u: float
    """The point parameter at the current point in the stroke (0 <= u <= 1).

:type: float"""

    def __iter__(self) -> None:
        """Implement iter(self)."""

    def decremented(self) -> StrokeVertexIterator:
        """Returns a copy of a decremented StrokeVertexIterator."""

    def incremented(self) -> StrokeVertexIterator:
        """Returns a copy of an incremented StrokeVertexIterator."""

    def reversed(self) -> StrokeVertexIterator:
        """Returns a StrokeVertexIterator that traverses stroke vertices in the
        reversed order.
        """

class TVertex:
    """Class hierarchy: :class:`Interface0D` > :class:`ViewVertex` > :class:`TVertex`

    Class to define a T vertex, i.e. an intersection between two edges.
    It points towards two SVertex and four ViewEdges. Among the
    ViewEdges, two are front and the other two are back. Basically a
    front edge hides part of a back edge. So, among the back edges, one
    is of invisibility N and the other of invisibility N+1.

    .. method:: __init__()

       Default constructor.
    """

    back_svertex: SVertex
    """The SVertex that is further away from the viewpoint.

:type: :class:`SVertex`"""

    front_svertex: SVertex
    """The SVertex that is closer to the viewpoint.

:type: :class:`SVertex`"""

    id: Id
    """The Id of this TVertex.

:type: :class:`Id`"""

    def get_mate(self, viewedge: ViewEdge) -> ViewEdge:
        """Returns the mate edge of the ViewEdge given as argument. If the
        ViewEdge is frontEdgeA, frontEdgeB is returned. If the ViewEdge is
        frontEdgeB, frontEdgeA is returned. Same for back edges.
        """

    def get_svertex(self, fedge: FEdge) -> SVertex:
        """Returns the SVertex (among the 2) belonging to the given FEdge."""

class UnaryFunction0D:
    """Base class for Unary Functions (functors) working on
    :class:`Interface0DIterator`. A unary function will be used by
    invoking __call__() on an Interface0DIterator. In Python, several
    different subclasses of UnaryFunction0D are used depending on the
    types of functors' return values. For example, you would inherit from
    a :class:`UnaryFunction0DDouble` if you wish to define a function that
    returns a double value. Available UnaryFunction0D subclasses are:

    * :class:`UnaryFunction0DDouble`
    * :class:`UnaryFunction0DEdgeNature`
    * :class:`UnaryFunction0DFloat`
    * :class:`UnaryFunction0DId`
    * :class:`UnaryFunction0DMaterial`
    * :class:`UnaryFunction0DUnsigned`
    * :class:`UnaryFunction0DVec2f`
    * :class:`UnaryFunction0DVec3f`
    * :class:`UnaryFunction0DVectorViewShape`
    * :class:`UnaryFunction0DViewShape`
    """

    name: str
    """The name of the unary 0D function.

:type: str"""

class UnaryFunction0DDouble:
    """Class hierarchy: :class:`UnaryFunction0D` > :class:`UnaryFunction0DDouble`

    Base class for unary functions (functors) that work on
    :class:`Interface0DIterator` and return a float value.

    .. method:: __init__()

       Default constructor.
    """

class UnaryFunction0DEdgeNature:
    """Class hierarchy: :class:`UnaryFunction0D` > :class:`UnaryFunction0DEdgeNature`

    Base class for unary functions (functors) that work on
    :class:`Interface0DIterator` and return a :class:`Nature` object.

    .. method:: __init__()

       Default constructor.
    """

class UnaryFunction0DFloat:
    """Class hierarchy: :class:`UnaryFunction0D` > :class:`UnaryFunction0DFloat`

    Base class for unary functions (functors) that work on
    :class:`Interface0DIterator` and return a float value.

    .. method:: __init__()

       Default constructor.
    """

class UnaryFunction0DId:
    """Class hierarchy: :class:`UnaryFunction0D` > :class:`UnaryFunction0DId`

    Base class for unary functions (functors) that work on
    :class:`Interface0DIterator` and return an :class:`Id` object.

    .. method:: __init__()

       Default constructor.
    """

class UnaryFunction0DMaterial:
    """Class hierarchy: :class:`UnaryFunction0D` > :class:`UnaryFunction0DMaterial`

    Base class for unary functions (functors) that work on
    :class:`Interface0DIterator` and return a :class:`Material` object.

    .. method:: __init__()

       Default constructor.
    """

class UnaryFunction0DUnsigned:
    """Class hierarchy: :class:`UnaryFunction0D` > :class:`UnaryFunction0DUnsigned`

    Base class for unary functions (functors) that work on
    :class:`Interface0DIterator` and return an int value.

    .. method:: __init__()

       Default constructor.
    """

class UnaryFunction0DVec2f:
    """Class hierarchy: :class:`UnaryFunction0D` > :class:`UnaryFunction0DVec2f`

    Base class for unary functions (functors) that work on
    :class:`Interface0DIterator` and return a 2D vector.

    .. method:: __init__()

       Default constructor.
    """

class UnaryFunction0DVec3f:
    """Class hierarchy: :class:`UnaryFunction0D` > :class:`UnaryFunction0DVec3f`

    Base class for unary functions (functors) that work on
    :class:`Interface0DIterator` and return a 3D vector.

    .. method:: __init__()

       Default constructor.
    """

class UnaryFunction0DVectorViewShape:
    """Class hierarchy: :class:`UnaryFunction0D` > :class:`UnaryFunction0DVectorViewShape`

    Base class for unary functions (functors) that work on
    :class:`Interface0DIterator` and return a list of :class:`ViewShape`
    objects.

    .. method:: __init__()

       Default constructor.
    """

class UnaryFunction0DViewShape:
    """Class hierarchy: :class:`UnaryFunction0D` > :class:`UnaryFunction0DViewShape`

    Base class for unary functions (functors) that work on
    :class:`Interface0DIterator` and return a :class:`ViewShape` object.

    .. method:: __init__()

       Default constructor.
    """

class UnaryFunction1D:
    """Base class for Unary Functions (functors) working on
    :class:`Interface1D`. A unary function will be used by invoking
    __call__() on an Interface1D. In Python, several different subclasses
    of UnaryFunction1D are used depending on the types of functors' return
    values. For example, you would inherit from a
    :class:`UnaryFunction1DDouble` if you wish to define a function that
    returns a double value. Available UnaryFunction1D subclasses are:

    * :class:`UnaryFunction1DDouble`
    * :class:`UnaryFunction1DEdgeNature`
    * :class:`UnaryFunction1DFloat`
    * :class:`UnaryFunction1DUnsigned`
    * :class:`UnaryFunction1DVec2f`
    * :class:`UnaryFunction1DVec3f`
    * :class:`UnaryFunction1DVectorViewShape`
    * :class:`UnaryFunction1DVoid`
    """

    name: str
    """The name of the unary 1D function.

:type: str"""

class UnaryFunction1DDouble:
    """Class hierarchy: :class:`UnaryFunction1D` > :class:`UnaryFunction1DDouble`

    Base class for unary functions (functors) that work on
    :class:`Interface1D` and return a float value.

    .. method:: __init__()
                __init__(integration_type)

       Builds a unary 1D function using the default constructor
       or the integration method given as an argument.

       :arg integration_type: An integration method.
       :type integration_type: :class:`IntegrationType`
    """

    integration_type: IntegrationType
    """The integration method.

:type: :class:`IntegrationType`"""

class UnaryFunction1DEdgeNature:
    """Class hierarchy: :class:`UnaryFunction1D` > :class:`UnaryFunction1DEdgeNature`

    Base class for unary functions (functors) that work on
    :class:`Interface1D` and return a :class:`Nature` object.

    .. method:: __init__()
                __init__(integration_type)

       Builds a unary 1D function using the default constructor
       or the integration method given as an argument.

       :arg integration_type: An integration method.
       :type integration_type: :class:`IntegrationType`
    """

    integration_type: IntegrationType
    """The integration method.

:type: :class:`IntegrationType`"""

class UnaryFunction1DFloat:
    """Class hierarchy: :class:`UnaryFunction1D` > :class:`UnaryFunction1DFloat`

    Base class for unary functions (functors) that work on
    :class:`Interface1D` and return a float value.

    .. method:: __init__()
                __init__(integration_type)

       Builds a unary 1D function using the default constructor
       or the integration method given as an argument.

       :arg integration_type: An integration method.
       :type integration_type: :class:`IntegrationType`
    """

    integration_type: IntegrationType
    """The integration method.

:type: :class:`IntegrationType`"""

class UnaryFunction1DUnsigned:
    """Class hierarchy: :class:`UnaryFunction1D` > :class:`UnaryFunction1DUnsigned`

    Base class for unary functions (functors) that work on
    :class:`Interface1D` and return an int value.

    .. method:: __init__()
                __init__(integration_type)

       Builds a unary 1D function using the default constructor
       or the integration method given as an argument.

       :arg integration_type: An integration method.
       :type integration_type: :class:`IntegrationType`
    """

    integration_type: IntegrationType
    """The integration method.

:type: :class:`IntegrationType`"""

class UnaryFunction1DVec2f:
    """Class hierarchy: :class:`UnaryFunction1D` > :class:`UnaryFunction1DVec2f`

    Base class for unary functions (functors) that work on
    :class:`Interface1D` and return a 2D vector.

    .. method:: __init__()
                __init__(integration_type)

       Builds a unary 1D function using the default constructor
       or the integration method given as an argument.

       :arg integration_type: An integration method.
       :type integration_type: :class:`IntegrationType`
    """

    integration_type: IntegrationType
    """The integration method.

:type: :class:`IntegrationType`"""

class UnaryFunction1DVec3f:
    """Class hierarchy: :class:`UnaryFunction1D` > :class:`UnaryFunction1DVec3f`

    Base class for unary functions (functors) that work on
    :class:`Interface1D` and return a 3D vector.

    .. method:: __init__()
                __init__(integration_type)

       Builds a unary 1D function using the default constructor
       or the integration method given as an argument.

       :arg integration_type: An integration method.
       :type integration_type: :class:`IntegrationType`
    """

    integration_type: IntegrationType
    """The integration method.

:type: :class:`IntegrationType`"""

class UnaryFunction1DVectorViewShape:
    """Class hierarchy: :class:`UnaryFunction1D` > :class:`UnaryFunction1DVectorViewShape`

    Base class for unary functions (functors) that work on
    :class:`Interface1D` and return a list of :class:`ViewShape`
    objects.

    .. method:: __init__()
                __init__(integration_type)

       Builds a unary 1D function using the default constructor
       or the integration method given as an argument.

       :arg integration_type: An integration method.
       :type integration_type: :class:`IntegrationType`
    """

    integration_type: IntegrationType
    """The integration method.

:type: :class:`IntegrationType`"""

class UnaryFunction1DVoid:
    """Class hierarchy: :class:`UnaryFunction1D` > :class:`UnaryFunction1DVoid`

    Base class for unary functions (functors) working on
    :class:`Interface1D`.

    .. method:: __init__()
                 __init__(integration_type)

       Builds a unary 1D function using either a default constructor
       or the integration method given as an argument.

       :arg integration_type: An integration method.
       :type integration_type: :class:`IntegrationType`
    """

    integration_type: IntegrationType
    """The integration method.

:type: :class:`IntegrationType`"""

class UnaryPredicate0D:
    """Base class for unary predicates that work on
    :class:`Interface0DIterator`. A UnaryPredicate0D is a functor that
    evaluates a condition on an Interface0DIterator and returns true or
    false depending on whether this condition is satisfied or not. The
    UnaryPredicate0D is used by invoking its __call__() method. Any
    inherited class must overload the __call__() method.

    .. method:: __init__()

       Default constructor.

    .. method:: __call__(it)

       Must be overload by inherited classes.

       :arg it: The Interface0DIterator pointing onto the Interface0D at
          which we wish to evaluate the predicate.
       :type it: :class:`Interface0DIterator`
       :return: True if the condition is satisfied, false otherwise.
       :rtype: bool
    """

    name: str
    """The name of the unary 0D predicate.

:type: str"""

class UnaryPredicate1D:
    """Base class for unary predicates that work on :class:`Interface1D`. A
    UnaryPredicate1D is a functor that evaluates a condition on a
    Interface1D and returns true or false depending on whether this
    condition is satisfied or not. The UnaryPredicate1D is used by
    invoking its __call__() method. Any inherited class must overload the
    __call__() method.

    .. method:: __init__()

       Default constructor.

    .. method:: __call__(inter)

       Must be overload by inherited classes.

       :arg inter: The Interface1D on which we wish to evaluate the predicate.
       :type inter: :class:`Interface1D`
       :return: True if the condition is satisfied, false otherwise.
       :rtype: bool
    """

    name: str
    """The name of the unary 1D predicate.

:type: str"""

class ViewEdge:
    """Class hierarchy: :class:`Interface1D` > :class:`ViewEdge`

    Class defining a ViewEdge. A ViewEdge in an edge of the image graph.
    it connects two :class:`ViewVertex` objects. It is made by connecting
    a set of FEdges.

    .. method:: __init__()
                __init__(brother)

       Builds a :class:`ViewEdge` using the default constructor or the copy constructor.

       :arg brother: A ViewEdge object.
       :type brother: :class:`ViewEdge`
    """

    chaining_time_stamp: int
    """The time stamp of this ViewEdge.

:type: int"""

    first_fedge: FEdge
    """The first FEdge that constitutes this ViewEdge.

:type: :class:`FEdge`"""

    first_viewvertex: ViewVertex
    """The first ViewVertex.

:type: :class:`ViewVertex`"""

    id: Id
    """The Id of this ViewEdge.

:type: :class:`Id`"""

    is_closed: bool
    """True if this ViewEdge forms a closed loop.

:type: bool"""

    last_fedge: FEdge
    """The last FEdge that constitutes this ViewEdge.

:type: :class:`FEdge`"""

    last_viewvertex: ViewVertex
    """The second ViewVertex.

:type: :class:`ViewVertex`"""

    nature: Nature
    """The nature of this ViewEdge.

:type: :class:`Nature`"""

    occludee: ViewShape
    """The shape that is occluded by the ViewShape to which this ViewEdge
belongs to. If no object is occluded, this property is set to None.

:type: :class:`ViewShape`"""

    qi: int
    """The quantitative invisibility.

:type: int"""

    viewshape: ViewShape
    """The ViewShape to which this ViewEdge belongs to.

:type: :class:`ViewShape`"""

    def update_fedges(self) -> None:
        """Sets Viewedge to this for all embedded fedges."""

class ViewEdgeIterator:
    """Class hierarchy: :class:`Iterator` > :class:`ViewEdgeIterator`

    Base class for iterators over ViewEdges of the :class:`ViewMap` Graph.
    Basically the increment() operator of this class should be able to
    take the decision of "where" (on which ViewEdge) to go when pointing
    on a given ViewEdge.

    .. method:: __init__(begin=None, orientation=True)
                __init__(brother)

       Builds a ViewEdgeIterator from a starting ViewEdge and its
       orientation or the copy constructor.

       :arg begin: The ViewEdge from where to start the iteration.
       :type begin: :class:`ViewEdge` | None
       :arg orientation: If true, we'll look for the next ViewEdge among
          the ViewEdges that surround the ending ViewVertex of begin. If
          false, we'll search over the ViewEdges surrounding the ending
          ViewVertex of begin.
       :type orientation: bool
       :arg brother: A ViewEdgeIterator object.
       :type brother: :class:`ViewEdgeIterator`
    """

    begin: ViewEdge
    """The first ViewEdge used for the iteration.

:type: :class:`ViewEdge`"""

    current_edge: ViewEdge
    """The ViewEdge object currently pointed by this iterator.

:type: :class:`ViewEdge`"""

    object: ViewEdge
    """The ViewEdge object currently pointed by this iterator.

:type: :class:`ViewEdge`"""

    orientation: bool
    """The orientation of the pointed ViewEdge in the iteration.
If true, the iterator looks for the next ViewEdge among those ViewEdges
that surround the ending ViewVertex of the "begin" ViewEdge. If false,
the iterator searches over the ViewEdges surrounding the ending ViewVertex
of the "begin" ViewEdge.

:type: bool"""

    def change_orientation(self) -> None:
        """Changes the current orientation."""

class ViewMap:
    """Class defining the ViewMap.

    .. method:: __init__()

       Default constructor.
    """

    scene_bbox: BBox
    """The 3D bounding box of the scene.

:type: :class:`BBox`"""

    def get_closest_fedge(self, x: float, y: float) -> FEdge:
        """Gets the FEdge nearest to the 2D point specified as arguments."""

    def get_closest_viewedge(self, x: float, y: float) -> ViewEdge:
        """Gets the ViewEdge nearest to the 2D point specified as arguments."""

class ViewShape:
    """Class gathering the elements of the ViewMap (i.e., :class:`ViewVertex`
    and :class:`ViewEdge`) that are issued from the same input shape.

    .. method:: __init__()
                __init__(brother)
                __init__(sshape)

       Builds a :class:`ViewShape` using the default constructor,
       copy constructor, or from a :class:`SShape`.

       :arg brother: A ViewShape object.
       :type brother: :class:`ViewShape`
       :arg sshape: An SShape object.
       :type sshape: :class:`SShape`
    """

    edges: list[object]
    """The list of ViewEdge objects contained in this ViewShape.

:type: List of :class:`ViewEdge`"""

    id: Id
    """The Id of this ViewShape.

:type: :class:`Id`"""

    library_path: str | None
    """The library path of the ViewShape.

:type: str, or None if the ViewShape is not part of a library."""

    name: str
    """The name of the ViewShape.

:type: str"""

    sshape: SShape
    """The SShape on top of which this ViewShape is built.

:type: :class:`SShape`"""

    vertices: list[object]
    """The list of ViewVertex objects contained in this ViewShape.

:type: List of :class:`ViewVertex`"""

    def add_edge(self, edge: ViewEdge) -> None:
        """Adds a ViewEdge to the list of ViewEdge objects."""

    def add_vertex(self, vertex: ViewVertex) -> None:
        """Adds a ViewVertex to the list of the ViewVertex objects."""

class ViewVertex:
    """Class hierarchy: :class:`Interface0D` > :class:`ViewVertex`

    Class to define a view vertex. A view vertex is a feature vertex
    corresponding to a point of the image graph, where the characteristics
    of an edge (e.g., nature and visibility) might change. A
    :class:`ViewVertex` can be of two kinds: A :class:`TVertex` when it
    corresponds to the intersection between two ViewEdges or a
    :class:`NonTVertex` when it corresponds to a vertex of the initial
    input mesh (it is the case for vertices such as corners for example).
    Thus, this class can be specialized into two classes, the
    :class:`TVertex` class and the :class:`NonTVertex` class.
    """

    nature: Nature
    """The nature of this ViewVertex.

:type: :class:`Nature`"""

    def edges_begin(self) -> orientedViewEdgeIterator:
        """Returns an iterator over the ViewEdges that goes to or comes from
        this ViewVertex pointing to the first ViewEdge of the list. The
        orientedViewEdgeIterator allows to iterate in CCW order over these
        ViewEdges and to get the orientation for each ViewEdge
        (incoming/outgoing).
        """

    def edges_end(self) -> orientedViewEdgeIterator:
        """Returns an orientedViewEdgeIterator over the ViewEdges around this
        ViewVertex, pointing after the last ViewEdge.
        """

    def edges_iterator(self, edge: ViewEdge) -> orientedViewEdgeIterator:
        """Returns an orientedViewEdgeIterator pointing to the ViewEdge given
        as argument.
        """

class orientedViewEdgeIterator:
    """Class hierarchy: :class:`Iterator` > :class:`orientedViewEdgeIterator`

    Class representing an iterator over oriented ViewEdges around a
    :class:`ViewVertex`. This iterator allows a CCW iteration (in the image
    plane). An instance of an orientedViewEdgeIterator can only be
    obtained from a ViewVertex by calling edges_begin() or edges_end().

    .. method:: __init__()
                __init__(iBrother)

       Creates an :class:`orientedViewEdgeIterator` using either the
       default constructor or the copy constructor.

       :arg iBrother: An orientedViewEdgeIterator object.
       :type iBrother: :class:`orientedViewEdgeIterator`
    """

    object: tuple[ViewEdge, bool]
    """The oriented ViewEdge (i.e., a tuple of the pointed ViewEdge and a boolean
value) currently pointed to by this iterator. If the boolean value is true,
the ViewEdge is incoming.

:type: tuple[:class:`ViewEdge`, bool]"""

    def __iter__(self) -> None:
        """Implement iter(self)."""
