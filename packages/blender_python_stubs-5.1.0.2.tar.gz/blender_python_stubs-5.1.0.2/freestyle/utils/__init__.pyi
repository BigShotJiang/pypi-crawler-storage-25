"""This module contains helper functions used for Freestyle style module
writing."""

import bpy.types
import freestyle.types
import mathutils

def angle_x_normal(it: freestyle.types.Interface0DIterator) -> None:
    """unsigned angle between a Point's normal and the X axis, in radians"""

def bound(lower: object, x: object, higher: object) -> None:
    """Returns x bounded by a maximum and minimum value. Equivalent to:
    return min(max(x, lower), higher)
    """

def bounding_box(stroke: object) -> None:
    """Returns the maximum and minimum coordinates (the bounding box) of the stroke's vertices"""

def curvature_from_stroke_vertex(svert: object) -> None:
    """The 3D curvature of an stroke vertex' underlying geometry
    The result is None or in the range [-inf, inf]
    """

def find_matching_vertex(id: object, it: object) -> None:
    """Finds the matching vertex, or returns None."""

def getCurrentScene() -> bpy.types.Scene:
    """Returns the current scene."""

def getSquareSegmentDistance(p: object, p1: object, p2: object) -> None:
    """Square distance between point and a segment"""

def get_chain_length(ve: object, orientation: object) -> None:
    """Returns the 2d length of a given ViewEdge."""

def get_object_name(stroke: object) -> None:
    """Returns the name of the object that this stroke is drawn on."""

def get_strokes() -> None:
    """Get all strokes that are currently available"""

def get_test_stroke() -> None:
    """Returns a static stroke object for testing"""

def integrate(
    func: freestyle.types.UnaryFunction0D,
    it: freestyle.types.Interface0DIterator,
    it_end: freestyle.types.Interface0DIterator,
    integration_type: freestyle.types.IntegrationType,
) -> int | float:
    """Returns a single value from a set of values evaluated at each 0D
    element of this 1D element.
    """

def is_poly_clockwise(stroke: object) -> None:
    """True if the stroke is orientated in a clockwise way, False otherwise"""

def iter_distance_along_stroke(stroke: object) -> None:
    """Yields the absolute distance along the stroke up to the current vertex."""

def iter_distance_from_camera(
    stroke: object, range_min: object, range_max: object, normfac: object
) -> None:
    """Yields the distance to the camera relative to the maximum
    possible distance for every stroke vertex, constrained by
    given minimum and maximum values.
    """

def iter_distance_from_object(
    stroke: object,
    location: object,
    range_min: object,
    range_max: object,
    normfac: object,
) -> None:
    """yields the distance to the given object relative to the maximum
    possible distance for every stroke vertex, constrained by
    given minimum and maximum values.
    """

def iter_material_value(stroke: object, func: object, attribute: object) -> None:
    """Yields a specific material attribute from the vertex' underlying material."""

def iter_t2d_along_stroke(stroke: object) -> None:
    """Yields the progress along the stroke."""

def material_from_fedge(fe: object) -> None:
    """get the diffuse RGBA color from an FEdge"""

def normal_at_I0D(it: freestyle.types.Interface0DIterator) -> mathutils.Vector:
    """Normal at an Interface0D object. In contrast to Normal2DF0D this
    function uses the actual data instead of underlying Fedge objects.
    """

def pairwise(iterable: object, types: object = ...) -> None:
    """Yields a tuple containing the previous and current object"""

def phase_to_direction(length: object) -> None:
    """Returns a list of tuples each containing:
    - the phase
    - a Vector with the values of the cosine and sine of 2pi * phase  (the direction)
    """

def rgb_to_bw(r: object, g: object, b: object) -> None:
    """Method to convert rgb to a bw intensity value."""

def simplify(points: object, tolerance: object) -> None:
    """Simplifies a set of points"""

def simplifyDouglasPeucker(points: object, tolerance: object) -> None: ...
def stroke_curvature(it: object) -> None:
    """Compute the 2D curvature at the stroke vertex pointed by the iterator 'it'.
    K = 1 / R
    where R is the radius of the circle going through the current vertex and its neighbors
    """

def stroke_normal(stroke: object) -> None:
    """Compute the 2D normal at the stroke vertex pointed by the iterator
    'it'.  It is noted that Normal2DF0D computes normals based on
    underlying FEdges instead, which is inappropriate for strokes when
    they have already been modified by stroke geometry modifiers.

    The returned normals are dynamic: they update when the
    vertex position (and therefore the vertex normal) changes.
    for use in geometry modifiers it is advised to
    cast this generator function to a tuple or list
    """

def tripplewise(iterable: object) -> None:
    """Yields a tuple containing the current object and its immediate neighbors"""

class BoundedProperty:
    """BoundedProperty(min, max, delta)"""

    def interpolate(self, val: object) -> None: ...

class BoundingBox:
    """Object representing a bounding box consisting out of 2 2D vectors"""

    @property
    def corners(self) -> object: ...
    @property
    def maximum(self) -> object: ...
    @property
    def minimum(self) -> object: ...
    @property
    def size(self) -> object: ...
    @classmethod
    def from_sequence(cls, sequence: object) -> None:
        """BoundingBox from sequence of 2D or 3D Vector objects"""

    def inside(self, other: object) -> None:
        """True if self inside other, False otherwise"""

class StrokeCollector:
    """Collects and Stores stroke objects"""

    def shade(self, stroke: freestyle.types.Stroke) -> None:
        """The shading method. Must be overloaded by inherited classes."""
