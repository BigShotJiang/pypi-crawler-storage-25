"""This module contains chaining iterators used for the chaining
operation to construct long strokes by concatenating feature edges
according to selected chaining rules.  The module is also intended to
be a collection of examples for defining chaining iterators in Python."""

import freestyle.types

def nature_in_preceding(nature: object, index: object) -> None:
    """Returns True if given nature appears before index, else False."""

class ChainPredicateIterator:
    """Class hierarchy: :class:`freestyle.types.Iterator` >
    :class:`freestyle.types.ViewEdgeIterator` >
    :class:`freestyle.types.ChainingIterator` >
    :class:`ChainPredicateIterator`

    A "generic" user-controlled ViewEdge iterator. This iterator is in
    particular built from a unary predicate and a binary predicate.
    First, the unary predicate is evaluated for all potential next
    ViewEdges in order to only keep the ones respecting a certain
    constraint. Then, the binary predicate is evaluated on the current
    ViewEdge together with each ViewEdge of the previous selection. The
    first ViewEdge respecting both the unary predicate and the binary
    predicate is kept as the next one. If none of the potential next
    ViewEdge respects these two predicates, None is returned.

    .. method:: __init__(upred, bpred, restrict_to_selection=True,                      restrict_to_unvisited=True, begin=None,                      orientation=True)
                __init__(brother)

       Builds a ChainPredicateIterator from a unary predicate, a binary
       predicate, a starting ViewEdge and its orientation or using the copy constructor.

       :arg upred: The unary predicate that the next ViewEdge must satisfy.
       :type upred: :class:`freestyle.types.UnaryPredicate1D`
       :arg bpred: The binary predicate that the next ViewEdge must
          satisfy together with the actual pointed ViewEdge.
       :type bpred: :class:`freestyle.types.BinaryPredicate1D`
       :arg restrict_to_selection: Indicates whether to force the chaining
          to stay within the set of selected ViewEdges or not.
       :type restrict_to_selection: bool
       :arg restrict_to_unvisited: Indicates whether a ViewEdge that has
          already been chained must be ignored ot not.
       :type restrict_to_unvisited: bool
       :arg begin: The ViewEdge from where to start the iteration.
       :type begin: :class:`freestyle.types.ViewEdge` | None
       :arg orientation: If true, we'll look for the next ViewEdge among
          the ViewEdges that surround the ending ViewVertex of begin. If
          false, we'll search over the ViewEdges surrounding the ending
          ViewVertex of begin.
       :type orientation: bool
       :arg brother: A ChainPredicateIterator object.
       :type brother: :class:`ChainPredicateIterator`
    """

class ChainSilhouetteIterator:
    """Class hierarchy: :class:`freestyle.types.Iterator` >
    :class:`freestyle.types.ViewEdgeIterator` >
    :class:`freestyle.types.ChainingIterator` >
    :class:`ChainSilhouetteIterator`

    A ViewEdge Iterator used to follow ViewEdges the most naturally. For
    example, it will follow visible ViewEdges of same nature. As soon, as
    the nature or the visibility changes, the iteration stops (by setting
    the pointed ViewEdge to 0). In the case of an iteration over a set of
    ViewEdge that are both Silhouette and Crease, there will be a
    precedence of the silhouette over the crease criterion.

    .. method:: __init__(restrict_to_selection=True, begin=None, orientation=True)
                __init__(brother)

       Builds a ChainSilhouetteIterator from the first ViewEdge used for
       iteration and its orientation or the copy constructor.

       :arg restrict_to_selection: Indicates whether to force the chaining
          to stay within the set of selected ViewEdges or not.
       :type restrict_to_selection: bool
       :arg begin: The ViewEdge from where to start the iteration.
       :type begin: :class:`freestyle.types.ViewEdge` | None
       :arg orientation: If true, we'll look for the next ViewEdge among
          the ViewEdges that surround the ending ViewVertex of begin. If
          false, we'll search over the ViewEdges surrounding the ending
          ViewVertex of begin.
       :type orientation: bool
       :arg brother: A ChainSilhouetteIterator object.
       :type brother: :class:`ChainSilhouetteIterator`
    """

class pyChainSilhouetteGenericIterator:
    """Natural chaining iterator that follows the edges of the same nature
    following the topology of objects, with decreasing priority for
    silhouettes, then borders, then suggestive contours, then all other
    edge types.

    .. method:: __init__(self, stayInSelection=True, stayInUnvisited=True)

       Builds a pyChainSilhouetteGenericIterator object.

       :param stayInSelection: True if it is allowed to go out of the selection
       :type stayInSelection: bool
       :param stayInUnvisited: May the same ViewEdge be chained twice
       :type stayInUnvisited: bool
    """

    def init(self) -> None:
        """Initializes the iterator context. This method is called each
        time a new chain is started. It can be used to reset some
        history information that you might want to keep.
        """

    def traverse(
        self, it: freestyle.types.AdjacencyIterator
    ) -> freestyle.types.ViewEdge | None:
        """This method iterates over the potential next ViewEdges and returns
        the one that will be followed next. Returns the next ViewEdge to
        follow or None when the end of the chain is reached.
        """

class pyChainSilhouetteIterator:
    """Natural chaining iterator that follows the edges of the same nature
    following the topology of objects, with decreasing priority for
    silhouettes, then borders, then suggestive contours, then all other edge
    types.  A ViewEdge is only chained once.
    """

    def init(self) -> None:
        """Initializes the iterator context. This method is called each
        time a new chain is started. It can be used to reset some
        history information that you might want to keep.
        """

    def traverse(
        self, it: freestyle.types.AdjacencyIterator
    ) -> freestyle.types.ViewEdge | None:
        """This method iterates over the potential next ViewEdges and returns
        the one that will be followed next. Returns the next ViewEdge to
        follow or None when the end of the chain is reached.
        """

class pyExternalContourChainingIterator:
    """Chains by external contour"""

    def checkViewEdge(self, ve: object, orientation: object) -> None: ...
    def init(self) -> None:
        """Initializes the iterator context. This method is called each
        time a new chain is started. It can be used to reset some
        history information that you might want to keep.
        """

    def traverse(
        self, it: freestyle.types.AdjacencyIterator
    ) -> freestyle.types.ViewEdge | None:
        """This method iterates over the potential next ViewEdges and returns
        the one that will be followed next. Returns the next ViewEdge to
        follow or None when the end of the chain is reached.
        """

class pyFillOcclusionsAbsoluteAndRelativeChainingIterator:
    """Chaining iterator that fills small occlusions regardless of the
    selection.

    .. method:: __init__(self, percent, l)

       Builds a pyFillOcclusionsAbsoluteAndRelativeChainingIterator object.

       :param percent: The maximal length of the occluded part as a
           percentage of the total chain length.
       :type percent: float
       :param l: Absolute length.
       :type l: float
    """

    def init(self) -> None:
        """Initializes the iterator context. This method is called each
        time a new chain is started. It can be used to reset some
        history information that you might want to keep.
        """

    def traverse(
        self, it: freestyle.types.AdjacencyIterator
    ) -> freestyle.types.ViewEdge | None:
        """This method iterates over the potential next ViewEdges and returns
        the one that will be followed next. Returns the next ViewEdge to
        follow or None when the end of the chain is reached.
        """

class pyFillOcclusionsAbsoluteChainingIterator:
    """Chaining iterator that fills small occlusions

    .. method:: __init__(self, length)

       Builds a pyFillOcclusionsAbsoluteChainingIterator object.

       :param length: The maximum length of the occluded part in pixels.
       :type length: int
    """

    def init(self) -> None:
        """Initializes the iterator context. This method is called each
        time a new chain is started. It can be used to reset some
        history information that you might want to keep.
        """

    def traverse(
        self, it: freestyle.types.AdjacencyIterator
    ) -> freestyle.types.ViewEdge | None:
        """This method iterates over the potential next ViewEdges and returns
        the one that will be followed next. Returns the next ViewEdge to
        follow or None when the end of the chain is reached.
        """

class pyFillOcclusionsRelativeChainingIterator:
    """Chaining iterator that fills small occlusions

    .. method:: __init__(self, percent)

       Builds a pyFillOcclusionsRelativeChainingIterator object.

       :param percent: The maximal length of the occluded part, expressed
           in a percentage of the total chain length.
       :type percent: float
    """

    def init(self) -> None:
        """Initializes the iterator context. This method is called each
        time a new chain is started. It can be used to reset some
        history information that you might want to keep.
        """

    def traverse(
        self, it: freestyle.types.AdjacencyIterator
    ) -> freestyle.types.ViewEdge | None:
        """This method iterates over the potential next ViewEdges and returns
        the one that will be followed next. Returns the next ViewEdge to
        follow or None when the end of the chain is reached.
        """

class pyFillQi0AbsoluteAndRelativeChainingIterator:
    """Chaining iterator that fills small occlusions regardless of the
    selection.

    .. method:: __init__(self, percent, l)

       Builds a pyFillQi0AbsoluteAndRelativeChainingIterator object.

       :param percent: The maximal length of the occluded part as a
           percentage of the total chain length.
       :type percent: float
       :param l: Absolute length.
       :type l: float
    """

    def init(self) -> None:
        """Initializes the iterator context. This method is called each
        time a new chain is started. It can be used to reset some
        history information that you might want to keep.
        """

    def traverse(
        self, it: freestyle.types.AdjacencyIterator
    ) -> freestyle.types.ViewEdge | None:
        """This method iterates over the potential next ViewEdges and returns
        the one that will be followed next. Returns the next ViewEdge to
        follow or None when the end of the chain is reached.
        """

class pyNoIdChainSilhouetteIterator:
    """Natural chaining iterator that follows the edges of the same nature
    following the topology of objects, with decreasing priority for
    silhouettes, then borders, then suggestive contours, then all other edge
    types.  It won't chain the same ViewEdge twice.

    .. method:: __init__(self, stayInSelection=True)

       Builds a pyNoIdChainSilhouetteIterator object.

       :param stayInSelection: True if it is allowed to go out of the selection
       :type stayInSelection: bool
    """

    def init(self) -> None:
        """Initializes the iterator context. This method is called each
        time a new chain is started. It can be used to reset some
        history information that you might want to keep.
        """

    def traverse(
        self, it: freestyle.types.AdjacencyIterator
    ) -> freestyle.types.ViewEdge | None:
        """This method iterates over the potential next ViewEdges and returns
        the one that will be followed next. Returns the next ViewEdge to
        follow or None when the end of the chain is reached.
        """

class pySketchyChainSilhouetteIterator:
    """Natural chaining iterator with a sketchy multiple touch.  It chains the
    same ViewEdge multiple times to achieve a sketchy effect.

    .. method:: __init__(self, nRounds=3,stayInSelection=True)

       Builds a pySketchyChainSilhouetteIterator object.

       :param nRounds: Number of times every Viewedge is chained.
       :type nRounds: int
       :param stayInSelection: if False, edges outside of the selection can be chained.
       :type stayInSelection: bool
    """

    def init(self) -> None:
        """Initializes the iterator context. This method is called each
        time a new chain is started. It can be used to reset some
        history information that you might want to keep.
        """

    def make_sketchy(self, ve: object) -> None:
        """Creates the sketchy effect by causing the chain to run from
        the start again. (loop over itself again)
        """

    def traverse(
        self, it: freestyle.types.AdjacencyIterator
    ) -> freestyle.types.ViewEdge | None:
        """This method iterates over the potential next ViewEdges and returns
        the one that will be followed next. Returns the next ViewEdge to
        follow or None when the end of the chain is reached.
        """

class pySketchyChainingIterator:
    """Chaining iterator designed for sketchy style. It chains the same
    ViewEdge several times in order to produce multiple strokes per
    ViewEdge.
    """

    def init(self) -> None:
        """Initializes the iterator context. This method is called each
        time a new chain is started. It can be used to reset some
        history information that you might want to keep.
        """

    def traverse(
        self, it: freestyle.types.AdjacencyIterator
    ) -> freestyle.types.ViewEdge | None:
        """This method iterates over the potential next ViewEdges and returns
        the one that will be followed next. Returns the next ViewEdge to
        follow or None when the end of the chain is reached.
        """
