# raglocal — Design Document

> MCP-first local knowledge search built on embedded LanceDB with local embeddings.
> No Docker. No external vector service. Query from any MCP-capable AI tool.

Status: **v1** — reflects current implementation.
Last updated: 2026-04-27

---


## 1. Architecture overview

```
raglocal/
├── mcp_server.py      — JSON-RPC 2.0 MCP server (search + expand tools)
├── config.py          — Config dataclass + TOML loader
├── profiles.py        — Embedder profile registry (lean/balanced/powerful)
├── embed.py           — SentenceTransformersEmbedder + OllamaEmbedder
├── store.py           — LanceStore (hybrid FTS+vector, RRF fusion)
├── chunk.py           — Chunker registry (token/sentence/code-aware/chapter)
├── state.py           — SQLite sidecar (ingest state, XDG paths)
├── rerank.py          — Optional cross-encoder reranker (Ollama backend)
├── parsers/
│   ├── markdown.py    — Markdown + journal frontmatter
│   ├── pdf.py         — PDF text extraction (pypdf)
│   ├── epub.py        — EPUB chapter extraction (ebooklib)
│   ├── docx.py        — DOCX/ODT extraction (python-docx)
│   ├── code.py        — Source code (tree-sitter, 20+ languages)
│   ├── web.py         — HTML main-content extraction (trafilatura)
│   └── data.py        — JSON/YAML structured data
└── export.py          — Portable corpus zip (lance data + run.sh)
cli.py                 — Typer CLI (rag init/index/mcp/stats/export/import/debug/doctor)
```

### Data flow

**Index** (one-shot):
```
source file → parser → text + metadata
            → chunker (strategy per collection)
            → embedder (profile: lean/balanced/powerful)
            → LanceStore upsert (dense vector + FTS index + metadata)
            → state.db update (mtime + content_hash)
```

**Query** (per MCP call):
```
search("what did I write about X?")
  → embed query
  → LanceStore.hybrid_search (vector + FTS, RRF fusion, top-N=20)
  → (optional) reranker → top-K
  → return ranked snippets (≤250 chars each) with chunk IDs

expand(["abc-123"])
  → LanceStore.get_by_id + neighbor chunks
  → return full text + metadata
```

---


## 2. Token economics

The search+expand pattern is the core design constraint.

| Concern            | Old raglocal          | New raglocal              |
|--------------------|---------------------|-------------------------|
| Schema per result  | ~80 tokens          | ~15 tokens              |
| Snippet size       | full chunk (500–800 tokens) | ≤250 chars (~60 tokens) |
| Results returned   | 5–10 full chunks    | 10–15 snippets          |
| Typical context    | ~4000 tokens        | ~1200 tokens            |
| Token reduction    | —                   | ~67%                    |

**How it works:** `search` returns only a 250-char snippet per hit plus a chunk ID. The
AI reads snippets, identifies which chunks are worth reading in full, then calls `expand`
on just those IDs. Most sessions need 1–3 expand calls.

The MCP schema overhead (tool definitions at session start) is approximately 400 tokens,
amortised across all queries in a session.

---


## 3. Storage

**LanceDB** — embedded, Apache Arrow columnar format, no daemon required.

- Default path: `~/.local/share/raglocal/lance/`
- One Lance table per collection (docs, code, journal, books, web, session)
- Each row: `id`, `text`, `vector` (float32[dim]), `source_uri`, `source_type`,
  `chunk_idx`, `chunk_total`, `mtime`, `content_hash`, `heading_path`, `line_start`,
  `line_end`, `language`, `tags`

**Hybrid search** uses LanceDB's built-in FTS (full-text search) fused with vector
similarity via Reciprocal Rank Fusion (RRF). The `hybrid_alpha` config knob controls
weight: `0` = FTS-only, `1` = vector-only, `0.5` = equal fusion.

**Incremental index:** a SQLite sidecar at `~/.local/share/raglocal/state.db` tracks
`(source_uri, mtime, content_hash, collection)`. Files whose `(mtime, content_hash)`
pair is unchanged are skipped without re-embedding.

**Embedder fingerprint:** a `manifest.json` written next to the Lance directory
records `(provider, model, dim, profile_name)` for the embedder that produced the
stored vectors. On every CLI call the loaded config's embedder is compared against
the manifest; a mismatch aborts with `SystemExit(4)` and prints a `rag reindex` hint
(see §11 Hot-swap).

**Local model cache:** sentence-transformers models are stored under
`~/.cache/huggingface/hub/` by default. Set `embedder.cache_dir` in `config.toml`
to override (e.g. for offline/portable installs). Ollama-backed models (powerful
profile) live in Ollama's own store (`~/.ollama/models/`).

---


## 4. Embedder profiles

Three built-in profiles; selected at `rag init` and stored in `config.toml`.

| Profile  | Model                 | Dim  | Disk   | RAM    | Provider              |
|----------|-----------------------|------|--------|--------|-----------------------|
| lean     | all-MiniLM-L6-v2      | 384  | 90 MB  | 400 MB | sentence-transformers |
| balanced | nomic-embed-text-v1.5 | 768  | 270 MB | 1 GB   | sentence-transformers |
| powerful | bge-m3                | 1024 | 2.3 GB | 4 GB   | Ollama                |

**Fallback chains:** if the requested profile's dependencies are unavailable, raglocal
falls back automatically:
- `powerful` → `balanced` → `lean`
- `balanced` → `lean`
- `lean` → (fail with clear error)

Embedders are lazily loaded on first use. The `sentence-transformers` provider
downloads model weights on first run and caches them under
`~/.cache/huggingface/hub/` (HuggingFace's default), or under `embedder.cache_dir`
when set in `config.toml`.

---


## 5. Chunking strategies

Each collection specifies a chunking strategy in `config.toml`.

| Strategy    | Used for        | Description                                                |
|-------------|-----------------|-------------------------------------------------------------|
| `token`     | docs, web       | Fixed token windows with overlap; heading-aware boundaries  |
| `sentence`  | journal         | Sentence-boundary splits; preserves paragraph coherence     |
| `code-aware`| code            | tree-sitter function/class splits; language-aware           |
| `chapter`   | books           | EPUB chapter boundaries; falls back to token on long chapters|

Default chunk sizes per profile are scaled to the embedding model's optimal context
window (lean: 512, balanced: 768, powerful: 1024). Per-collection overrides in config.

---


## 6. Parsers

| Parser       | Handles                                | Library            |
|--------------|----------------------------------------|--------------------|
| `markdown`   | .md, .txt; extracts heading hierarchy  | built-in           |
| `journal`    | .md/.txt with date frontmatter/filename| built-in           |
| `pdf`        | .pdf; preserves page boundaries        | pypdf              |
| `epub`       | .epub; chapter-level extraction        | ebooklib           |
| `docx`       | .docx, .odt                            | python-docx        |
| `code`       | .py .js .ts .go .rs .java .c .cpp ...  | tree-sitter        |
| `web`        | .html, .htm; strips boilerplate        | trafilatura        |
| `data`       | .json, .yaml; flattens to text repr    | built-in           |

Hidden directories (`.git`, `node_modules`, `__pycache__`, `.venv`) are skipped
automatically during directory traversal.

---

## 7. MCP server

The server speaks JSON-RPC 2.0 over stdio (MCP spec 2024-11-05).

**Tools exposed:**

`search` — semantic + keyword hybrid search.
- Input: `query` (string), `filter` (optional object), `top_k` (int, default 10),
  `mode` ("hybrid"|"vector"|"fts", default "hybrid")
- Filter keys: `type`, `since`, `until`, `path_prefix`, `tags`, `language`
- Output: `hits` array — each hit has `id`, `score`, `source`, `snippet` (≤250 chars),
  `type`, and optionally `date` and `title`

`expand` — fetch full text by chunk id.
- Input: `ids` (list of strings), `before` (int, default 1), `after` (int, default 1)
- Output: `chunks` array — each chunk has `id`, `text`, `source`, `lines`, `metadata`

**OpenCode integration:**
```json
{
  "mcp": {
    "raglocal": {
      "command": "rag",
      "args": ["mcp"],
      "type": "stdio"
    }
  }
}
```

---

## 8. Portable corpora

Corpora can be bundled into a self-contained zip for sharing or backup.

**Manifest format** (stored at `manifest.json` inside the zip):
```jsonc
{
  "raglocal_version": "1.0.0",
  "created_at": "2026-04-27T12:00:00Z",
  "collections": ["docs", "journal", "books"],
  "embedder_profile": "balanced",
  "chunk_counts": { "docs": 1240, "journal": 880, "books": 3200 }
}
```

The zip also includes:
- `lance/` — the full LanceDB tables (Apache Arrow format)
- `run.sh` — bootstrap script: installs raglocal if absent, imports the corpus, starts MCP

**Export/import:**
```bash
rag export ~/my-corpus.zip   # creates zip with lance data + manifest + run.sh
rag import ~/my-corpus.zip   # merges into local lance store
```

Recipients with a different embedder profile than the exporter will see a warning;
vectors are not re-embedded on import (requires manual re-index for full compatibility).

---

## 9. Configuration

`~/.config/raglocal/config.toml` — written by `rag init`, see `config.toml.example`.

Key sections:

```toml
[store]
backend = "lance"
path    = "~/.local/share/raglocal/lance"

[embedder]
profile = "balanced"   # lean | balanced | powerful | custom

[retrieval]
top_n        = 20      # candidates from hybrid search
top_k        = 10      # results after optional rerank
hybrid_alpha = 0.5     # 0=FTS-only, 1=vector-only

[collections.journal]
chunk_size     = 600
chunk_overlap  = 50
chunk_strategy = "sentence"
parser         = "journal"
```

---

## 10. Privacy

- Embeddings computed locally; document text never leaves the host.
- Remote LLM calls (for `rag debug`) are opt-in via model alias config.
- `.env` and `config.toml` are gitignored; only `*.example` files are checked in.

---

## 11. Hot-swap (changing the embedder)

Vectors produced by different embedding models are not directly comparable —
different families occupy different latent spaces, and dimensions often differ
outright (384 vs 768 vs 1024). Naively swapping `embedder.profile` in
`config.toml` would silently corrupt search; raglocal prevents this.

**Compatibility check.** A `manifest.json` at the store root records
`(provider, model, dim, profile_name)`. Every CLI command that touches the
store (`index`, `mcp`, `debug`, `stats`, `reindex`) calls
`is_embedder_compatible(manifest, cfg.embedder)` first:

- Match → silent pass.
- Mismatch → print expected vs configured fingerprints, hint at `rag reindex`,
  exit `4`.
- Legacy manifest (pre-7A, missing fields) → treated as compatible; gets
  upgraded on the next successful index.

**`rag reindex`.** Drops affected LanceDB tables, clears matching `state.db`
rows, then walks the source paths recorded in `state.db` and re-embeds them
with the new profile. Writes a fresh manifest on success.

```bash
# Switch from balanced (768) to powerful (1024)
$ vim ~/.config/raglocal/config.toml   # change [embedder] profile = "powerful"
$ rag stats
ERROR: Embedder mismatch.
  Indexed with: sentence-transformers:nomic-embed-text-v1.5:768  (balanced)
  Configured:   ollama:bge-m3:1024  (powerful)
Run `rag reindex` to rebuild with the new embedder.

$ rag reindex --yes
[... re-embeds 1,200 chunks across 4 collections ...]
$ rag stats
docs    420 chunks
code    612 chunks
journal  98 chunks
books    70 chunks
```

**Caveats.**
- Source files must still be reachable on disk; raglocal re-parses them.
- `--collection NAME` reindexes a single collection; useful when only one
  source has migrated.
- Ollama (powerful profile) must be running before invoking reindex.
- Switching to a profile with the same dim is *also* enforced — different
  models with matching `dim` still produce incompatible embedding spaces.

---

## See also

- [README.md](README.md) — quick start and CLI reference
- [docs/opencode.md](docs/opencode.md) — OpenCode integration
- [docs/troubleshooting.md](docs/troubleshooting.md) — common issues