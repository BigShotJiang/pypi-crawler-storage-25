# raglocal — Production Readiness Plan

> Generated: 2026-04-27  
> Status: complete — 306 passed, 4 skipped, mypy clean, ruff clean  
> Estimated wall-clock time: **~4–6 min** (5 agents in parallel, each ~2–3 min)

---

## Verified Bugs (all confirmed by static analysis)

### CRITICAL — silent wrong results in production

| # | File | Lines | Bug | Impact |
|---|------|-------|-----|--------|
| 1 | `raglocal/store.py` | 123–152 | `_build_lance_filter` does not handle `id`, `chunk_idx`, `source_uri` (exact), or `language` keys. `mcp_server.py:630,659` calls `filters={"id":…}` and `filters={"source_uri":…,"chunk_idx":…}`. Both return `None` → unfiltered scans → **`expand` MCP tool always returns wrong results.** | expand tool broken in production |
| 2 | `raglocal/rerank.py` | 55, 86–95 | Sends `[query, passage]` lists to Ollama `/api/embed` (accepts strings only). Takes `embedding[0]` (first float of a 384/768-dim vector) as relevance score. Semantically nonsensical. Silently produces garbage re-rankings. | reranking broken end-to-end |
| 3 | `raglocal/portable.py` | 41, 49, 75 | (a) `export_archive` reads manifest from `store_path` directly; `manifest_path_for_store` returns `store_path.parent` → file not found on export. (b) Config template uses `{profile}` slot but passes `embedder_provider` (`"sentence-transformers"`) instead of profile name (`"balanced"`) → imported corpus gets invalid config. | export/import broken |

### HIGH — silent quality degradation

| # | File | Lines | Bug |
|---|------|-------|-----|
| 4 | `raglocal/chunk.py` | 165–167 | ~~`chapter` split strategy is a stub~~ — **NOT A BUG**: `books.py` splits content per-chapter before calling `split(strategy="chapter")`; the token fallback is intentional and correct. No fix needed. |
| 5 | `raglocal/parsers/*.py` | docs:174, code:64, journal:102, web:44, sessions:100 | Every parser hardcodes `chunk_size`/`chunk_overlap`. Values in `config.toml` `[collections.*]` are **never respected**. |
| 6 | `raglocal/parsers/sessions.py` | 1 | `default_collection = "sessions"` but no `[collections.sessions]` in default config. Indexing sessions crashes `ensure_collection`. |

### MEDIUM — packaging / correctness

| # | File | Lines | Bug |
|---|------|-------|-----|
| 7 | `pyproject.toml` | `[tool.hatch…]` | `packages = ["raglocal"]` only — `cli.py` at repo root is NOT shipped in wheel. `rag` entry point breaks post-install. |
| 8 | `pyproject.toml` | `[project.scripts]` | `rag-bench = "tests.bench:main"` — `tests/` not in wheel. Breaks post-install. |
| 9 | `raglocal/__init__.py` | 3 | `__version__` hardcoded `"0.1.0"`. Drifts from `pyproject.toml` on every release. |
| 10 | `raglocal/mcp_server.py` | 47 | `_SERVER_INFO["version"]` hardcoded `"0.1.0"`. Same drift. |
| 11 | `cli.py:60–66` `mcp_server.py:219–225` | — | `_build_embedder` duplicated verbatim in two files. |
| 12 | `cli.py` | 687–726 | `rag doctor` always pings Ollama even for `sentence-transformers` embedder users → false failure. |
| 13 | `raglocal/parsers/docs.py` + `journal.py` | — | `_strip_frontmatter` and `_extract_first_h1` duplicated verbatim in both files. |
| 14 | `raglocal/chunk.py` | 349–351 | Dead `if/pass` block — stub never implemented. |

### LOW — noise / debt

| # | Item |
|---|------|
| 15 | `WAVE8.md` — stale planning artifact, no user value |
| 16 | `raglocal/ingest/` — empty directory |
| 17 | `improvements.md` — 7-bullet backlog; move to GitHub Issues |

---

## Execution Plan — Parallel Agents

All 5 agents run concurrently. Each is self-contained (no shared file conflicts).

### Agent A — Fix `_build_lance_filter` + `expand` filters
**File:** `raglocal/store.py`  
**Time:** ~2 min  
Add cases for `id` (exact string match), `chunk_idx` (integer equality), `source_uri` (exact string match), `language` (string equality) to `_build_lance_filter`.  
Also verify the two call sites in `mcp_server.py:630,659` pass compatible keys.

### Agent B — Fix reranker
**File:** `raglocal/rerank.py`  
**Time:** ~3 min  
Replace broken "embed pair → take embedding[0]" approach with proper cosine similarity between independently embedded query and passage vectors. Use existing `embed()` method. No external cross-encoder needed. Fallback: if reranker provider is `ollama`, use cosine similarity. Add unit test.

### Agent C — Thread CollectionConfig into parsers + deduplicate helpers
**Files:** `raglocal/index.py`, `raglocal/parsers/base.py`, `raglocal/parsers/docs.py`, `raglocal/parsers/code.py`, `raglocal/parsers/journal.py`, `raglocal/parsers/web.py`, `raglocal/parsers/sessions.py`, `raglocal/parsers/books.py`  
**Time:** ~3 min  
1. Add `chunk_size: int` + `chunk_overlap: int` params to `Parser.parse()` signature (with defaults matching current hardcoded values for backwards compat).  
2. Pass `collection_cfg.chunk_size / chunk_overlap` from `index.py` when calling each parser.  
3. Move `_strip_frontmatter` + `_extract_first_h1` to `raglocal/parsers/base.py`; remove duplicates from `docs.py` and `journal.py`.  
4. Add `[collections.sessions]` block to `config.toml.example`.

### Agent D — Fix `portable.py` bugs
**File:** `raglocal/portable.py`, `raglocal/manifest.py`  
**Time:** ~2 min  
1. Fix manifest read path: use `manifest_path_for_store(store_path)` consistently (not `store_path` directly).  
2. Fix config template: pass profile name (from `Config.embedder.profile`) not provider string to `{profile}` slot.

### Agent E — Misc fixes (5 bugs, low risk)
**Files:** `raglocal/__init__.py`, `raglocal/mcp_server.py`, `raglocal/embed.py` (new shared helper), `cli.py`, `raglocal/chunk.py`  
**Time:** ~3 min  
1. `__version__`: read from `importlib.metadata` in `__init__.py`; remove hardcoded string.  
2. `_SERVER_INFO`: read version from `importlib.metadata.version("raglocal")` in `mcp_server.py`.  
3. Deduplicate `_build_embedder`: move to `raglocal/embed.py` as `build_embedder(cfg)`; import in both `cli.py` and `mcp_server.py`.  
4. `doctor` Ollama check: skip if `cfg.embedder.provider != "ollama"`.  
5. `chunk.py` dead `if/pass`: remove lines 349–351.

---

## Repo Tidy (done by orchestrator, not agents)

| Action | Target |
|--------|--------|
| Delete | `WAVE8.md` |
| Delete | `raglocal/ingest/` |
| Delete | `improvements.md` |
| Fix wheel | Move `cli.py` → `raglocal/cli.py`; update `[project.scripts]` to `rag = "raglocal.cli:app"` |
| Fix rag-bench | Remove `rag-bench` script or move `bench.py` into `raglocal/` |
| Fix version | Single source of truth: `pyproject.toml` → `importlib.metadata` everywhere |

---

## Wall-Clock Estimate

```
t=0:00  All 5 agents dispatched simultaneously
t=0:02  Agents A, D finish (simpler edits)
t=0:03  Agents B, C, E finish
t=0:04  Orchestrator: tidy repo, patch pyproject.toml, run tests
t=0:05  Done
```

**Expected total: 4–6 min** (dominated by agent think time, all parallel).

---

## Post-Publish Checklist

- [ ] All tests pass (`uv run pytest -q`)
- [ ] `ruff check . --fix` clean
- [ ] `mypy raglocal/` clean
- [ ] `uv build` produces valid wheel
- [ ] `pip install dist/*.whl && rag --help` works
- [ ] `rag-bench` removed from entry points (or moved into package)
- [ ] CHANGELOG.md created
- [ ] Version bumped to `0.2.0` (breaking changes in parser API + portable format)
