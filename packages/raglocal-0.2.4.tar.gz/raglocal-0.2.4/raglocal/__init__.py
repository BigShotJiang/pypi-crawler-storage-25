"""raglocal — local-first, provider-agnostic RAG toolkit."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("raglocal")
except PackageNotFoundError:
    __version__ = "0.0.0"
