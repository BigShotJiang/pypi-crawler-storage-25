from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any, Protocol

import httpx

from raglocal.config import EmbedderConfig

if TYPE_CHECKING:
    from raglocal.config import Config


class Embedder(Protocol):
    """Protocol for text embedding."""

    @property
    def dim(self) -> int:
        """Embedding dimension."""
        ...

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed a list of texts, returning vectors."""
        ...


class OllamaEmbedder:
    """Ollama embedder using HTTP API."""

    def __init__(self, cfg: EmbedderConfig, client: httpx.AsyncClient | None = None) -> None:
        """Initialize with config and optional async client.

        Args:
            cfg: EmbedderConfig with host, model, dim.
            client: Optional httpx.AsyncClient for dependency injection (tests).
        """
        self.cfg = cfg
        if client is not None:
            self._client = client
            self._own_client = False
        else:
            self._client = httpx.AsyncClient(timeout=60.0)
            self._own_client = True

    @property
    def dim(self) -> int:
        """Return embedding dimension."""
        return self.cfg.dim

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed a list of texts.

        Batch size limit: if len(texts) > 64, split into sub-batches of 64.

        Args:
            texts: List of text strings to embed.

        Returns:
            List of embedding vectors (one per input text).

        Raises:
            RuntimeError: If the Ollama API returns a non-2xx status.
        """
        # Split into batches if needed
        if len(texts) <= 64:
            return await self._embed_batch(texts)

        all_embeddings: list[list[float]] = []
        for i in range(0, len(texts), 64):
            batch = texts[i : i + 64]
            embeddings = await self._embed_batch(batch)
            all_embeddings.extend(embeddings)

        return all_embeddings

    async def _embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Embed a single batch of texts (≤64).

        Args:
            texts: List of text strings (max 64).

        Returns:
            List of embedding vectors.

        Raises:
            RuntimeError: If the Ollama API returns a non-2xx status.
        """
        url = f"{self.cfg.host}/api/embed"
        payload = {"model": self.cfg.model, "input": texts}
        response = await self._client.post(url, json=payload)

        if response.status_code < 200 or response.status_code >= 300:
            raise RuntimeError(f"Ollama embed failed: {response.status_code} {response.text}")

        data: dict[str, list[list[float]]] = response.json()
        return data["embeddings"]

    async def aclose(self) -> None:
        """Close the async client if we own it."""
        if self._own_client and self._client is not None:
            await self._client.aclose()


class SentenceTransformersEmbedder:
    """
    Lazy-loading embedder using sentence-transformers.
    Model is downloaded/loaded on first embed() call.
    """

    def __init__(self, model_name: str, dim: int, cache_dir: str | None = None) -> None:
        self._model_name = model_name
        self._dim = dim
        self._cache_dir = cache_dir
        self._model: object | None = None  # lazy
        self._lock = asyncio.Lock()

    @property
    def dim(self) -> int:
        return self._dim

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed texts using sentence-transformers with lazy model loading.

        Args:
            texts: List of text strings to embed.

        Returns:
            List of embedding vectors (one per input text).

        Raises:
            ValueError: If the model's embedding dimension does not match self._dim.
        """
        if self._model is None:
            async with self._lock:
                if self._model is None:
                    import sentence_transformers  # noqa: PLC0415

                    new_model = sentence_transformers.SentenceTransformer(
                        self._model_name,
                        cache_folder=self._cache_dir,
                    )
                    try:
                        actual_dim = new_model.get_embedding_dimension()
                        if not isinstance(actual_dim, int):
                            raise AttributeError
                    except AttributeError:
                        actual_dim = new_model.get_sentence_embedding_dimension()
                    if actual_dim != self._dim:
                        raise ValueError(
                            f"Model '{self._model_name}' has embedding dimension "
                            f"{actual_dim}, but SentenceTransformersEmbedder was "
                            f"configured with dim={self._dim}."
                        )
                    self._model = new_model

        assert self._model is not None  # guaranteed by lazy-load block above
        loaded_model = self._model
        vectors = await asyncio.to_thread(
            loaded_model.encode,  # type: ignore[union-attr]
            texts,
            batch_size=32,
            normalize_embeddings=True,
        )
        return [v.tolist() for v in vectors]

    async def aclose(self) -> None:
        """No-op: sentence-transformers models have no async resources."""
        pass


def build_embedder(cfg: Config) -> Any:
    """Build an embedder from config.

    Args:
        cfg: Loaded Config instance.

    Returns:
        SentenceTransformersEmbedder or OllamaEmbedder based on cfg.embedder.provider.
    """
    if cfg.embedder.provider == "sentence-transformers":
        return SentenceTransformersEmbedder(cfg.embedder.model, cfg.embedder.dim, cfg.embedder.cache_dir)
    else:
        return OllamaEmbedder(cfg.embedder)
