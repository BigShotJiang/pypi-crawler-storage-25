from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

EmbedderProfile = Literal["lean", "balanced", "powerful", "custom"]

_VALID_NAMES = ("lean", "balanced", "powerful", "custom")


@dataclass(frozen=True)
class ResolvedProfile:
    provider: str
    model: str
    dim: int
    default_chunk_size: int
    default_chunk_overlap: int
    requires: list[str]
    display_name: str
    description: str
    disk_mb: int
    ram_mb: int


_PROFILES: dict[str, ResolvedProfile] = {
    "lean": ResolvedProfile(
        provider="sentence-transformers",
        model="all-MiniLM-L6-v2",
        dim=384,
        default_chunk_size=512,
        default_chunk_overlap=64,
        requires=["sentence-transformers"],
        display_name="Lean",
        description="Lightweight local embedder; fast and low-resource.",
        disk_mb=90,
        ram_mb=400,
    ),
    "balanced": ResolvedProfile(
        provider="sentence-transformers",
        model="nomic-embed-text-v1.5",
        dim=768,
        default_chunk_size=768,
        default_chunk_overlap=96,
        requires=["sentence-transformers"],
        display_name="Balanced",
        description="Good quality embeddings with moderate resource usage.",
        disk_mb=270,
        ram_mb=1000,
    ),
    "powerful": ResolvedProfile(
        provider="ollama",
        model="bge-m3",
        dim=1024,
        default_chunk_size=1024,
        default_chunk_overlap=128,
        requires=["ollama"],
        display_name="Powerful",
        description="High-quality multilingual embeddings via Ollama.",
        disk_mb=2300,
        ram_mb=4000,
    ),
}

_FALLBACK_CHAINS: dict[str, list[str]] = {
    "powerful": ["powerful", "balanced", "lean"],
    "balanced": ["balanced", "lean"],
    "lean": ["lean"],
    "custom": ["custom"],
}


def resolve_profile(name: str) -> ResolvedProfile:
    """Resolve a profile name to its full spec.

    Raises ValueError for unknown names or for 'custom' (not auto-resolvable).
    """
    if name not in _VALID_NAMES:
        raise ValueError(
            f"Unknown profile {name!r}. Valid options: {', '.join(_VALID_NAMES)}"
        )
    if name == "custom":
        raise ValueError(
            f"Profile 'custom' is not auto-resolvable. "
            f"Valid auto-resolvable options: {', '.join(k for k in _VALID_NAMES if k != 'custom')}"
        )
    return _PROFILES[name]


def fallback_chain(name: str) -> list[str]:
    """Return the fallback order for a profile name.

    Raises ValueError for unknown names.
    """
    if name not in _VALID_NAMES:
        raise ValueError(
            f"Unknown profile {name!r}. Valid options: {', '.join(_VALID_NAMES)}"
        )
    return list(_FALLBACK_CHAINS[name])
