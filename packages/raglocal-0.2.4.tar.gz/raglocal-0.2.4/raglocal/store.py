"""Vector store implementations: LanceStore (primary) and shared data classes."""

from __future__ import annotations

import asyncio
import math
import re
import uuid
from collections import Counter
from dataclasses import dataclass
from typing import Any, Protocol, runtime_checkable

# ---------------------------------------------------------------------------
# Shared data classes (consumed by A5, A6, A7, A10)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Chunk:
    text: str
    source_uri: str
    source_type: str
    collection: str
    chunk_idx: int
    chunk_total: int
    heading_path: list[str] | None = None
    line_start: int | None = None
    line_end: int | None = None
    mtime: int | None = None
    content_hash: str | None = None
    tags: list[str] | None = None
    extra: dict | None = None  # type: ignore[type-arg]


@dataclass(frozen=True)
class SearchResult:
    text: str
    score: float
    payload: dict  # type: ignore[type-arg]


# ---------------------------------------------------------------------------
# VectorStore Protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class VectorStore(Protocol):
    """Protocol defining the interface for vector store implementations."""

    def ensure_collection(self, name: str, dim: int, with_sparse: bool = True) -> None: ...
    async def upsert(self, collection: str, vectors: list[list[float]], chunks: list[Chunk]) -> None: ...
    async def search(self, collection: str, query_dense: list[float], top_n: int, filters: dict[str, Any] | None = None) -> list[SearchResult]: ...
    async def hybrid_search(self, collection: str, query_dense: list[float], query_text: str, top_n: int = 20, filters: dict[str, Any] | None = None, alpha: float = 0.5) -> list[SearchResult]: ...
    def count(self, collection: str) -> int: ...
    def delete_by_source(self, collection: str, source_uri: str) -> None: ...


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_NAMESPACE = uuid.UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8")  # UUID namespace URL


def _point_id(collection: str, source_uri: str, chunk_idx: int) -> str:
    """Return a deterministic UUID5 string for a given (collection, source_uri, chunk_idx)."""
    key = f"{collection}:{source_uri}:{chunk_idx}"
    return str(uuid.uuid5(_NAMESPACE, key))


def _tokenize(text: str) -> list[str]:
    """Lowercase word tokenizer (strips punctuation)."""
    return re.findall(r"[a-z0-9]+", text.lower())


def _bm25_rerank(
    results: list[SearchResult],
    query_text: str,
    alpha: float = 0.5,
) -> list[SearchResult]:
    """Client-side hybrid score = alpha * dense + (1-alpha) * bm25_overlap.

    A lightweight BM25-inspired score computed from token overlap between
    the query and each document chunk.  Used as a fallback when native
    fusion is unavailable.
    """
    if not results:
        return results

    query_tokens = set(_tokenize(query_text))
    if not query_tokens:
        return results

    # Compute IDF-like weight: log(N / df + 1)
    n = len(results)
    df: Counter[str] = Counter()
    doc_tokens: list[set[str]] = []
    for r in results:
        toks = set(_tokenize(r.text))
        doc_tokens.append(toks)
        for t in toks & query_tokens:
            df[t] += 1

    rescored: list[SearchResult] = []
    for r, toks in zip(results, doc_tokens, strict=True):
        overlap = toks & query_tokens
        bm25_score = sum(math.log(n / (df[t] + 1) + 1) for t in overlap)
        # Normalise to [0,1] by dividing by query length
        bm25_norm = bm25_score / len(query_tokens)
        hybrid = alpha * r.score + (1.0 - alpha) * bm25_norm
        rescored.append(SearchResult(text=r.text, score=hybrid, payload=r.payload))

    rescored.sort(key=lambda x: x.score, reverse=True)
    return rescored


# ---------------------------------------------------------------------------
# LanceStore
# ---------------------------------------------------------------------------


def _build_lance_filter(filters: dict[str, Any]) -> str | None:
    """Build a LanceDB SQL filter string from a filter dict.

    Supported keys:
    - source_type: exact match on source_type column
    - mtime_gte: mtime >= value
    - mtime_lte: mtime < value
    - source_uri_prefix: source_uri LIKE 'prefix%'
    - tags: array_contains(tags, value)
    - id: exact match on id column
    - chunk_idx: integer equality on chunk_idx column
    - source_uri: exact match on source_uri column
    - language: exact match on language column
    """
    if not filters:
        return None
    parts: list[str] = []
    for key, value in filters.items():
        if key == "source_type":
            escaped = str(value).replace("'", "''")
            parts.append(f"source_type = '{escaped}'")
        elif key == "mtime_gte":
            parts.append(f"mtime >= {int(value)}")
        elif key == "mtime_lte":
            parts.append(f"mtime < {int(value)}")
        elif key == "source_uri_prefix":
            escaped = str(value).replace("'", "''")
            parts.append(f"source_uri LIKE '{escaped}%'")
        elif key == "tags":
            escaped = str(value).replace("'", "''")
            parts.append(f"array_has(tags, '{escaped}')")
        elif key == "id":
            escaped = str(value).replace("'", "''")
            parts.append(f"id = '{escaped}'")
        elif key == "chunk_idx":
            parts.append(f"chunk_idx = {int(value)}")
        elif key == "source_uri":
            escaped = str(value).replace("'", "''")
            parts.append(f"source_uri = '{escaped}'")
        elif key == "language":
            escaped = str(value).replace("'", "''")
            parts.append(f"language = '{escaped}'")
    if not parts:
        return None
    return " AND ".join(parts)


class LanceStore:
    """LanceDB-backed vector store implementing the VectorStore protocol."""

    def __init__(self, path: str) -> None:
        try:
            import lancedb
        except ImportError as exc:
            raise ImportError(
                "lancedb is required for LanceStore. "
                "Install it with: pip install lancedb pyarrow"
            ) from exc
        import os

        self._db: Any = lancedb.connect(os.path.expanduser(path))
        self._tables: dict[str, Any] = {}
        self._fts_enabled: dict[str, bool] = {}

    def _get_schema(self, dim: int) -> Any:
        """Return a PyArrow schema for the given embedding dimension."""
        import pyarrow as pa

        return pa.schema(
            [
                pa.field("id", pa.string()),
                pa.field("vector", pa.list_(pa.float32(), dim)),
                pa.field("text", pa.string()),
                pa.field("source_uri", pa.string()),
                pa.field("source_type", pa.string()),
                pa.field("collection", pa.string()),
                pa.field("chunk_idx", pa.int32()),
                pa.field("chunk_total", pa.int32()),
                pa.field("heading_path", pa.list_(pa.string())),
                pa.field("line_start", pa.int32()),
                pa.field("line_end", pa.int32()),
                pa.field("mtime", pa.int64()),
                pa.field("content_hash", pa.string()),
                pa.field("tags", pa.list_(pa.string())),
                pa.field("extra_json", pa.string()),
            ]
        )

    def ensure_collection(
        self,
        name: str,
        dim: int,
        with_sparse: bool = True,  # noqa: FBT001
    ) -> None:
        """Create table if missing; optionally create an FTS index on 'text'."""
        import sys

        if name not in self._tables:
            existing_response = self._db.list_tables()
            # list_tables() returns a response object with .tables, or may return a list directly
            if hasattr(existing_response, "tables"):
                existing_names: list[str] = existing_response.tables or []
            else:
                existing_names = list(existing_response)
            if name in existing_names:
                tbl = self._db.open_table(name)
            else:
                schema = self._get_schema(dim)
                tbl = self._db.create_table(name, schema=schema)
            self._tables[name] = tbl

        tbl = self._tables[name]
        if with_sparse and name not in self._fts_enabled:
            try:
                tbl.create_fts_index("text")
                self._fts_enabled[name] = True
            except Exception as e:
                print(
                    f"Warning: FTS index creation failed for '{name}': {e}",
                    file=sys.stderr,
                )
                self._fts_enabled[name] = False
        elif not with_sparse:
            self._fts_enabled[name] = False

    async def upsert(
        self,
        collection: str,
        vectors: list[list[float]],
        chunks: list[Chunk],
    ) -> None:
        """Upsert vectors and chunks into the collection."""
        import json

        import pyarrow as pa

        if len(vectors) != len(chunks):
            raise ValueError(
                f"vectors and chunks must have the same length, "
                f"got {len(vectors)} and {len(chunks)}"
            )

        tbl = self._tables[collection]

        ids = [_point_id(collection, chunk.source_uri, chunk.chunk_idx) for chunk in chunks]

        data = pa.table(
            {
                "id": ids,
                "vector": vectors,
                "text": [chunk.text for chunk in chunks],
                "source_uri": [chunk.source_uri for chunk in chunks],
                "source_type": [chunk.source_type for chunk in chunks],
                "collection": [chunk.collection for chunk in chunks],
                "chunk_idx": [chunk.chunk_idx for chunk in chunks],
                "chunk_total": [chunk.chunk_total for chunk in chunks],
                "heading_path": [chunk.heading_path or [] for chunk in chunks],
                "line_start": [chunk.line_start for chunk in chunks],
                "line_end": [chunk.line_end for chunk in chunks],
                "mtime": [chunk.mtime for chunk in chunks],
                "content_hash": [chunk.content_hash for chunk in chunks],
                "tags": [chunk.tags or [] for chunk in chunks],
                "extra_json": [
                    json.dumps(chunk.extra) if chunk.extra is not None else None
                    for chunk in chunks
                ],
            }
        )

        await asyncio.to_thread(
            lambda: tbl.merge_insert("id")
            .when_matched_update_all()
            .when_not_matched_insert_all()
            .execute(data)
        )

    async def search(
        self,
        collection: str,
        query_dense: list[float],
        top_n: int,
        filters: dict | None = None,  # type: ignore[type-arg]
    ) -> list[SearchResult]:
        """Dense vector search with optional filter."""
        tbl = self._tables[collection]
        filter_str = _build_lance_filter(filters) if filters else None

        def _run() -> list[Any]:
            q = tbl.search(query_dense).limit(top_n)
            if filter_str:
                q = q.where(filter_str, prefilter=True)
            return q.to_list()  # type: ignore[no-any-return]

        rows = await asyncio.to_thread(_run)
        return [
            SearchResult(
                text=str(row.get("text", "")),
                score=float(1.0 - row.get("_distance", 1.0)),
                payload={k: v for k, v in row.items() if k != "_distance"},
            )
            for row in rows
        ]

    async def hybrid_search(
        self,
        collection: str,
        query_dense: list[float],
        query_text: str,
        top_n: int = 20,
        filters: dict | None = None,  # type: ignore[type-arg]
        alpha: float = 0.5,
    ) -> list[SearchResult]:
        """Hybrid search: RRF fusion of vector + FTS, or vector + bm25 fallback."""
        tbl = self._tables[collection]
        filter_str = _build_lance_filter(filters) if filters else None
        fts_on = self._fts_enabled.get(collection, False)

        if fts_on:
            # Run dense and FTS search in parallel, then fuse with RRF
            async def _dense() -> list[Any]:
                def _run() -> list[Any]:
                    q = tbl.search(query_dense).limit(top_n * 2)
                    if filter_str:
                        q = q.where(filter_str, prefilter=True)
                    return q.to_list()  # type: ignore[no-any-return]

                return await asyncio.to_thread(_run)

            async def _fts() -> list[Any]:
                def _run() -> list[Any]:
                    q = (
                        tbl.search(query_text, query_type="fts")
                        .limit(top_n * 2)
                    )
                    if filter_str:
                        q = q.where(filter_str, prefilter=True)
                    return q.to_list()  # type: ignore[no-any-return]

                return await asyncio.to_thread(_run)

            try:
                dense_rows, fts_rows = await asyncio.gather(_dense(), _fts())
            except Exception:
                # Fall back to vector + bm25
                dense_rows = await _dense()
                results = [
                    SearchResult(
                        text=str(row.get("text", "")),
                        score=float(1.0 - row.get("_distance", 1.0)),
                        payload={k: v for k, v in row.items() if k != "_distance"},
                    )
                    for row in dense_rows
                ]
                return _bm25_rerank(results, query_text, alpha=alpha)

            # Reciprocal Rank Fusion (k=60)
            k = 60
            scores: dict[str, float] = {}
            id_to_row: dict[str, Any] = {}

            for rank, row in enumerate(dense_rows):
                rid = str(row.get("id", rank))
                scores[rid] = scores.get(rid, 0.0) + 1.0 / (k + rank + 1)
                id_to_row[rid] = row

            for rank, row in enumerate(fts_rows):
                rid = str(row.get("id", f"fts_{rank}"))
                scores[rid] = scores.get(rid, 0.0) + 1.0 / (k + rank + 1)
                if rid not in id_to_row:
                    id_to_row[rid] = row

            fused = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:top_n]
            return [
                SearchResult(
                    text=str(id_to_row[rid].get("text", "")),
                    score=sc,
                    payload={k2: v for k2, v in id_to_row[rid].items() if k2 != "_distance"},
                )
                for rid, sc in fused
            ]
        else:
            # Vector + client-side BM25 rerank
            def _run() -> list[Any]:
                q = tbl.search(query_dense).limit(top_n)
                if filter_str:
                    q = q.where(filter_str, prefilter=True)
                return q.to_list()  # type: ignore[no-any-return]

            rows = await asyncio.to_thread(_run)
            results = [
                SearchResult(
                    text=str(row.get("text", "")),
                    score=float(1.0 - row.get("_distance", 1.0)),
                    payload={k2: v for k2, v in row.items() if k2 != "_distance"},
                )
                for row in rows
            ]
            return _bm25_rerank(results, query_text, alpha=alpha)

    def count(self, collection: str) -> int:
        """Return the number of rows in the collection."""
        tbl = self._tables[collection]
        return tbl.count_rows()  # type: ignore[no-any-return]

    def delete_by_source(self, collection: str, source_uri: str) -> None:
        """Delete all rows whose source_uri matches."""
        tbl = self._tables[collection]
        escaped = source_uri.replace("'", "''")
        tbl.delete(f"source_uri = '{escaped}'")

    def drop_collection(self, name: str) -> None:
        """Drop the LanceDB table for *name*, ignoring if it doesn't exist."""
        self._db.drop_table(name, ignore_missing=True)
        self._tables.pop(name, None)
        self._fts_enabled.pop(name, None)
