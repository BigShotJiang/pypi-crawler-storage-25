"""Retrieval: composition of embedder + store for multi-collection hybrid search."""

from __future__ import annotations

from dataclasses import dataclass

from raglocal.config import Config, RetrievalConfig
from raglocal.embed import Embedder
from raglocal.store import SearchResult, VectorStore


@dataclass(frozen=True)
class RetrievalContext:
    """Result of a retrieval operation."""

    query: str
    collections: list[str]
    results: list[SearchResult]


class Retriever:
    """Retriever composing embedder + store for multi-collection search."""

    def __init__(
        self,
        embedder: Embedder,
        store: VectorStore,
        cfg: Config | RetrievalConfig,
    ) -> None:
        """Initialize retriever with embedder, store, and config.

        Args:
            embedder: An Embedder instance (e.g., OllamaEmbedder).
            store: A VectorStore instance.
            cfg: Either a full Config or a RetrievalConfig. When a full Config
                 is provided, the reranker is enabled if configured.
        """
        self.embedder = embedder
        self.store = store
        self.cfg = cfg
        # Derive retrieval-specific config and optional reranker
        if isinstance(cfg, Config):
            self._retrieval = cfg.retrieval
            from raglocal.rerank import Reranker

            self.reranker: object = Reranker(cfg, embedder=embedder)
            self._reranker_enabled: bool = cfg.reranker.enabled
        else:
            self._retrieval = cfg
            self.reranker = None
            self._reranker_enabled = False

    async def retrieve(
        self,
        query: str,
        collections: list[str],
        top_n: int | None = None,
        top_k: int | None = None,
    ) -> RetrievalContext:
        """Retrieve and rank results across collections.

        Args:
            query: User query string.
            collections: List of collection names to search.
            top_n: Number of candidates per collection before reranking.
                   If None, use cfg.retrieval.top_n.
            top_k: Number of final results to return.
                   If None, use cfg.retrieval.top_k.

        Returns:
            RetrievalContext with merged and ranked results.

        Behavior:
            1. Embed the query.
            2. For each collection, hybrid_search via store.hybrid_search(..., top_n).
            3. Merge results from all collections.
            4. Sort by score descending.
            5. Apply reranker if enabled.
            6. Take top_k results.
        """
        # Use config defaults if args not provided
        if top_n is None:
            top_n = self._retrieval.top_n
        if top_k is None:
            top_k = self._retrieval.top_k

        # Embed the query
        query_vector = await self.embedder.embed([query])
        query_dense = query_vector[0]

        # Search each collection using hybrid BM25+dense search
        all_results: list[SearchResult] = []
        for collection in collections:
            results = await self.store.hybrid_search(
                collection=collection,
                query_dense=query_dense,
                query_text=query,
                top_n=top_n,
                alpha=self._retrieval.hybrid_alpha,
            )
            all_results.extend(results)

        # Sort by score descending
        all_results.sort(key=lambda r: r.score, reverse=True)

        # Apply reranker if enabled
        if self._reranker_enabled and self.reranker is not None:
            from raglocal.rerank import Reranker as _Reranker

            assert isinstance(self.reranker, _Reranker)
            final_results = await self.reranker.rerank(query, all_results, top_k=top_k)
        else:
            final_results = all_results[:top_k]

        return RetrievalContext(query=query, collections=collections, results=final_results)
