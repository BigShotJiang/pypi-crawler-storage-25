"""MCP server for raglocal — JSON-RPC 2.0 over stdio.

Exposes two tools: ``search`` and ``expand``.

OpenCode configuration example::

    # ~/.config/opencode/config.json  (add to "mcp" section)
    {
      "mcp": {
        "raglocal": {
          "command": "rag",
          "args": ["serve-mcp"],
          "type": "stdio"
        }
      }
    }

Protocol
--------
* Framing: newline-delimited JSON (one JSON object per line on stdin/stdout).
* The server responds to MCP ``initialize``, ``tools/list``, and ``tools/call``
  requests per the Model Context Protocol spec (2024-11-05).
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import re
import sys
from datetime import datetime
from typing import Any

import raglocal
from raglocal.config import Config
from raglocal.embed import build_embedder
from raglocal.rerank import Reranker
from raglocal.store import LanceStore, SearchResult

# ---------------------------------------------------------------------------
# MCP protocol constants
# ---------------------------------------------------------------------------

_PROTOCOL_VERSION = "2024-11-05"

_SERVER_INFO = {
    "name": "raglocal",
    "version": raglocal.__version__,
}

_SEARCH_TOOL_SCHEMA: dict[str, Any] = {
    "name": "search",
    "description": (
        "Semantic + keyword search across your indexed knowledge (code, journals, books, docs). "
        "Returns ranked snippets with IDs. Use the filter to narrow by content type, date range, "
        "path, tags, or language. Use top_k=15 for cross-source synthesis questions. "
        "Call expand on returned IDs to read full chunks."
    ),
    "inputSchema": {
        "type": "object",
        "required": ["query"],
        "properties": {
            "query": {
                "type": "string",
                "description": "Natural-language query.",
            },
            "filter": {
                "type": "object",
                "description": "Optional filters. All keys optional.",
                "properties": {
                    "type": {
                        "description": "One or more of: 'code','book','journal','doc','web','session'. String or list.",
                    },
                    "since": {
                        "type": "string",
                        "description": "ISO-8601 date; chunks with mtime >= this date.",
                    },
                    "until": {
                        "type": "string",
                        "description": "ISO-8601 date; chunks with mtime < this date.",
                    },
                    "path_prefix": {
                        "type": "string",
                        "description": "Match source URIs starting with this path.",
                    },
                    "tags": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "language": {
                        "type": "string",
                        "description": "For code type; e.g. 'python', 'rust'.",
                    },
                },
            },
            "top_k": {"type": "integer", "default": 10},
            "mode": {
                "type": "string",
                "enum": ["hybrid", "vector", "fts"],
                "default": "hybrid",
            },
            "rerank": {
                "type": "boolean",
                "description": "Override reranker for this call. Defaults to server config.",
            },
        },
    },
}

_EXPAND_TOOL_SCHEMA: dict[str, Any] = {
    "name": "expand",
    "description": (
        "Read the full text of one or more chunks by search hit IDs, with optional surrounding "
        "context. Use only for hits worth reading in full."
    ),
    "inputSchema": {
        "type": "object",
        "required": ["ids"],
        "properties": {
            "ids": {
                "type": "array",
                "items": {"type": "string"},
            },
            "before": {"type": "integer", "default": 1},
            "after": {"type": "integer", "default": 1},
        },
    },
}

_TOOL_SCHEMAS = [_SEARCH_TOOL_SCHEMA, _EXPAND_TOOL_SCHEMA]


# ---------------------------------------------------------------------------
# JSON-RPC helpers
# ---------------------------------------------------------------------------


def _ok(req_id: Any, result: Any) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": req_id, "result": result}


def _err(req_id: Any, code: int, message: str, data: Any = None) -> dict[str, Any]:
    error: dict[str, Any] = {"code": code, "message": message}
    if data is not None:
        error["data"] = data
    return {"jsonrpc": "2.0", "id": req_id, "error": error}


# JSON-RPC 2.0 standard error codes
_PARSE_ERROR = -32700
_INVALID_REQUEST = -32600
_METHOD_NOT_FOUND = -32601
_INVALID_PARAMS = -32602
_INTERNAL_ERROR = -32603


# ---------------------------------------------------------------------------
# Snippet generator
# ---------------------------------------------------------------------------


def _make_snippet(text: str, query: str) -> str:
    """Generate a ≤250-char snippet from *text* centered on the first query term match.

    Steps:
    1. Split query into terms (split on whitespace, strip punctuation).
    2. Find first occurrence of any term (case-insensitive, word boundary) in text.
    3. Extract ±125 chars centered on match, total ≤ 250 chars.
    4. If no match, take text[:250].
    5. Collapse internal whitespace.
    6. Add "..." prefix/suffix if window doesn't reach text boundaries.
    """
    # Split query into terms, strip punctuation
    terms = [re.sub(r"[^\w]", "", t) for t in query.split()]
    terms = [t for t in terms if t]

    match_pos: int | None = None
    if terms:
        # Build pattern for any term with word boundary
        pattern = "|".join(r"\b" + re.escape(t) + r"\b" for t in terms)
        m = re.search(pattern, text, re.IGNORECASE)
        if m:
            match_pos = m.start()

    if match_pos is None:
        # No match: take first 250 chars
        snippet = text[:250]
        # Collapse whitespace
        snippet = re.sub(r"\s+", " ", snippet).strip()
        return snippet

    # Center ±125 chars around match_pos
    half = 125
    start = max(0, match_pos - half)
    end = min(len(text), match_pos + half)

    # Adjust if window is too small
    if end - start < 250:
        extra = 250 - (end - start)
        if start == 0:
            end = min(len(text), end + extra)
        elif end == len(text):
            start = max(0, start - extra)

    window = text[start:end]
    # Collapse internal whitespace
    window = re.sub(r"\s+", " ", window).strip()

    prefix = "..." if start > 0 else ""
    suffix = "..." if end < len(text) else ""

    return prefix + window + suffix


# ---------------------------------------------------------------------------
# Embedder construction
# ---------------------------------------------------------------------------


def _build_embedder(cfg: Config) -> Any:
    return build_embedder(cfg)


# ---------------------------------------------------------------------------
# MCPServer
# ---------------------------------------------------------------------------


class MCPServer:
    """Async MCP server that reads JSON-RPC requests from stdin and writes
    responses to stdout.

    Args:
        cfg: Loaded :class:`~raglocal.config.Config` instance.
        reader: Async stream to read newline-delimited JSON from (defaults to
            ``asyncio.StreamReader`` wrapping ``sys.stdin``).
        writer: Async stream to write newline-delimited JSON to (defaults to
            ``asyncio.StreamWriter`` wrapping ``sys.stdout``).
        store: Optional pre-built VectorStore (for testing).
        embedder: Optional pre-built embedder (for testing).
    """

    def __init__(
        self,
        cfg: Config,
        reader: asyncio.StreamReader | None = None,
        writer: asyncio.StreamWriter | None = None,
        store: Any = None,
        embedder: Any = None,
    ) -> None:
        self._cfg = cfg
        self._reader = reader
        self._writer = writer
        self._store = store
        self._embedder = embedder

        # Initialize reranker if enabled in config
        try:
            self._reranker: Reranker | None = Reranker(self._cfg) if self._cfg.reranker.enabled else None
        except Exception:
            self._reranker = None
        self._initialized = False
        # Keep _retriever for backward compat with tests that patch _build_retriever
        self._retriever: Any = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def _build_retriever(self) -> Any:
        """Build embedder and store lazily. Returns a sentinel object."""
        self._embedder = _build_embedder(self._cfg)
        store = LanceStore(self._cfg.store.path)
        # Reattach to existing on-disk collections (LanceStore loads tables lazily)
        try:
            resp = store._db.list_tables()
            existing = set(resp.tables or []) if hasattr(resp, "tables") else set(resp)
        except Exception:
            existing = set()
        for coll_name in self._cfg.collections:
            if coll_name in existing:
                with contextlib.suppress(Exception):
                    store.ensure_collection(coll_name, self._cfg.embedder.dim)
        self._store = store
        return True  # sentinel — signals success

    # ------------------------------------------------------------------
    # Transport
    # ------------------------------------------------------------------

    async def _read_line(self) -> str | None:
        """Read one newline-terminated line from the reader."""
        if self._reader is not None:
            try:
                line_bytes = await self._reader.readline()
                if not line_bytes:
                    return None
                return line_bytes.decode("utf-8").rstrip("\n")
            except Exception:
                return None
        else:
            # Fallback: blocking stdin read in executor
            loop = asyncio.get_event_loop()
            line = await loop.run_in_executor(None, sys.stdin.readline)
            return line.rstrip("\n") if line else None

    def _write_response(self, obj: dict[str, Any]) -> None:
        """Serialise *obj* as JSON and write a newline-terminated line."""
        payload = json.dumps(obj, separators=(",", ":")) + "\n"
        if self._writer is not None:
            self._writer.write(payload.encode("utf-8"))
        else:
            sys.stdout.write(payload)
            sys.stdout.flush()

    # ------------------------------------------------------------------
    # Request dispatch
    # ------------------------------------------------------------------

    async def _handle(self, raw: str) -> dict[str, Any] | None:
        """Parse *raw* JSON string and dispatch to the appropriate handler.

        Returns a response dict, or ``None`` for notifications (no response
        expected).
        """
        try:
            req = json.loads(raw)
        except json.JSONDecodeError as exc:
            return _err(None, _PARSE_ERROR, f"Parse error: {exc}")

        if not isinstance(req, dict):
            return _err(None, _INVALID_REQUEST, "Request must be a JSON object")

        req_id = req.get("id")  # None for notifications
        method = req.get("method", "")
        params = req.get("params") or {}

        if method == "initialize":
            return await self._handle_initialize(req_id, params)
        elif method == "notifications/initialized":
            # Client notification — no response
            return None
        elif method == "tools/list":
            return await self._handle_tools_list(req_id, params)
        elif method == "tools/call":
            return await self._handle_tools_call(req_id, params)
        elif method == "ping":
            return _ok(req_id, {})
        else:
            return _err(req_id, _METHOD_NOT_FOUND, f"Method not found: {method!r}")

    async def _handle_initialize(
        self, req_id: Any, params: dict[str, Any]
    ) -> dict[str, Any]:
        # Build embedder/store lazily on first initialize
        if self._retriever is None and self._store is None and self._embedder is None:
            try:
                self._retriever = self._build_retriever()
            except Exception as exc:
                return _err(req_id, _INTERNAL_ERROR, f"Failed to initialise services: {exc}")

        self._initialized = True
        return _ok(
            req_id,
            {
                "protocolVersion": _PROTOCOL_VERSION,
                "serverInfo": _SERVER_INFO,
                "capabilities": {"tools": {}},
            },
        )

    async def _handle_tools_list(
        self, req_id: Any, params: dict[str, Any]
    ) -> dict[str, Any]:
        return _ok(req_id, {"tools": _TOOL_SCHEMAS})

    async def _handle_tools_call(
        self, req_id: Any, params: dict[str, Any]
    ) -> dict[str, Any]:
        tool_name = params.get("name", "")

        # Backwards compat: reject old tool name with deprecation error
        if tool_name == "rag.query":
            return _err(
                req_id,
                _METHOD_NOT_FOUND,
                "rag.query is deprecated. Use 'search' or 'expand' instead.",
            )

        if tool_name == "search":
            return await self._handle_search(req_id, params.get("arguments") or {})
        elif tool_name == "expand":
            return await self._handle_expand(req_id, params.get("arguments") or {})
        else:
            return _err(req_id, _METHOD_NOT_FOUND, f"Unknown tool: {tool_name!r}")

    # ------------------------------------------------------------------
    # Tool: search
    # ------------------------------------------------------------------

    async def _handle_search(
        self, req_id: Any, arguments: dict[str, Any]
    ) -> dict[str, Any]:
        query = arguments.get("query")
        if not query or not isinstance(query, str):
            return _err(req_id, _INVALID_PARAMS, "'query' must be a non-empty string")

        top_k = arguments.get("top_k", 10)
        try:
            top_k = int(top_k)
        except (TypeError, ValueError):
            top_k = 10

        # Per-call rerank override; defaults to whatever the server config says
        rerank_arg = arguments.get("rerank")
        if rerank_arg is None:
            rerank_enabled = self._reranker is not None and self._cfg.reranker.enabled
        else:
            rerank_enabled = bool(rerank_arg) and self._reranker is not None

        filter_params: dict[str, Any] = arguments.get("filter") or {}

        # Resolve collections from filter.type, or all configured collections
        type_filter = filter_params.get("type")
        if type_filter is not None:
            type_list = [type_filter] if isinstance(type_filter, str) else list(type_filter)
            # Map type strings to collection names: use those that exist in cfg.collections
            # If a type matches a collection name, use it; otherwise try all collections
            collections = [t for t in type_list if t in self._cfg.collections]
            if not collections:
                collections = list(self._cfg.collections.keys())
        else:
            collections = list(self._cfg.collections.keys())

        # Build store filter dict
        store_filters: dict[str, Any] = {}
        since = filter_params.get("since")
        if since:
            with contextlib.suppress(ValueError, TypeError):
                store_filters["mtime_gte"] = int(datetime.fromisoformat(since).timestamp())

        until = filter_params.get("until")
        if until:
            with contextlib.suppress(ValueError, TypeError):
                store_filters["mtime_lte"] = int(datetime.fromisoformat(until).timestamp())

        path_prefix = filter_params.get("path_prefix")
        if path_prefix:
            store_filters["source_uri_prefix"] = path_prefix

        language = filter_params.get("language")
        if language:
            store_filters["language"] = language

        # Embed query once
        if self._embedder is None:
            return _err(req_id, _INTERNAL_ERROR, "Server not initialized: no embedder")

        try:
            query_vecs = await self._embedder.embed([query])
            query_vec = query_vecs[0]
        except Exception as exc:
            return _err(req_id, _INTERNAL_ERROR, f"Embedding error: {exc}")

        if self._store is None:
            return _err(req_id, _INTERNAL_ERROR, "Server not initialized: no store")

        # Search each collection, collect up to 20 per collection
        all_results: list[tuple[str, SearchResult]] = []
        seen_ids: set[str] = set()

        for collection in collections:
            try:
                results = await self._store.hybrid_search(
                    collection=collection,
                    query_dense=query_vec,
                    query_text=query,
                    top_n=20,
                    filters=store_filters if store_filters else None,
                )
                for r in results:
                    rid = str(r.payload.get("id", "")) or _result_id(collection, r)
                    if rid not in seen_ids:
                        seen_ids.add(rid)
                        all_results.append((rid, r))
            except Exception:
                # Skip collections that fail (e.g., not yet created)
                continue

        # Sort by score descending
        all_results.sort(key=lambda x: x[1].score, reverse=True)

        # Optional reranking pass (config or per-call override)
        if rerank_enabled and self._reranker is not None and all_results:
            top_n = max(top_k, getattr(self._cfg.retrieval, "top_n", 20))
            initial = [r for _, r in all_results[:top_n]]
            try:
                reranked = await self._reranker.rerank(query, initial, top_k=top_k)
            except Exception:
                # Fail-safe: fall back to lexical/vector ranking
                hits = all_results[:top_k]
            else:
                # Re-pair reranked results with their existing IDs
                id_by_text: dict[int, str] = {id(r): rid for rid, r in all_results}
                hits = [(id_by_text.get(id(r), _result_id("", r)), r) for r in reranked]
        else:
            hits = all_results[:top_k]

        # Build response hits
        hit_list = []
        for chunk_id, r in hits:
            payload = r.payload
            source_uri = str(payload.get("source_uri", ""))
            line_start = payload.get("line_start")
            line_end = payload.get("line_end")
            if line_start is not None and line_end is not None:
                source = f"{source_uri}#L{line_start}-L{line_end}"
            else:
                source = source_uri

            snippet = _make_snippet(r.text, query)

            source_type = str(payload.get("source_type", ""))

            mtime = payload.get("mtime")
            date_str: str | None = None
            if mtime is not None:
                try:
                    date_str = datetime.fromtimestamp(int(mtime)).date().isoformat()
                except (ValueError, OSError, OverflowError):
                    date_str = None

            heading_path = payload.get("heading_path")
            title: str | None = None
            if heading_path and isinstance(heading_path, list) and len(heading_path) > 0:
                title = str(heading_path[-1])

            hit: dict[str, Any] = {
                "id": chunk_id,
                "score": r.score,
                "source": source,
                "snippet": snippet,
                "type": source_type,
            }
            if date_str is not None:
                hit["date"] = date_str
            if title is not None:
                hit["title"] = title

            hit_list.append(hit)

        return _ok(
            req_id,
            {
                "content": [
                    {"type": "text", "text": json.dumps({"hits": hit_list})}
                ],
                "isError": False,
            },
        )

    # ------------------------------------------------------------------
    # Tool: expand
    # ------------------------------------------------------------------

    async def _handle_expand(
        self, req_id: Any, arguments: dict[str, Any]
    ) -> dict[str, Any]:
        ids = arguments.get("ids")
        if not ids or not isinstance(ids, list):
            return _err(req_id, _INVALID_PARAMS, "'ids' must be a non-empty list")

        before = arguments.get("before", 1)
        after = arguments.get("after", 1)
        try:
            before = int(before)
            after = int(after)
        except (TypeError, ValueError):
            before = 1
            after = 1

        if self._store is None:
            return _err(req_id, _INTERNAL_ERROR, "Server not initialized: no store")

        chunks_out = []
        for chunk_id in ids:
            chunk_id = str(chunk_id)
            try:
                chunk_data = await self._fetch_chunk_with_neighbors(chunk_id, before, after)
                if chunk_data is not None:
                    chunks_out.append(chunk_data)
            except Exception:
                continue

        return _ok(
            req_id,
            {
                "content": [
                    {"type": "text", "text": json.dumps({"chunks": chunks_out})}
                ],
                "isError": False,
            },
        )

    async def _fetch_chunk_with_neighbors(
        self, chunk_id: str, before: int, after: int
    ) -> dict[str, Any] | None:
        """Fetch a chunk by ID and merge with neighbor chunks."""
        if self._store is None:
            return None

        # Search all collections for this id
        # We use a filter on id field
        target_chunk: SearchResult | None = None
        target_collection: str | None = None

        for collection in self._cfg.collections:
            try:
                # Search with a dummy vector but filter by id
                # Since we can't do direct id lookup via VectorStore protocol,
                # we use search with a filter that includes the id
                results = await self._store.search(
                    collection=collection,
                    query_dense=[0.0] * self._cfg.embedder.dim,
                    top_n=1,
                    filters={"id": chunk_id},
                )
                if results:
                    target_chunk = results[0]
                    target_collection = collection
                    break
            except Exception:
                continue

        if target_chunk is None or target_collection is None:
            return None

        payload = target_chunk.payload
        chunk_idx = payload.get("chunk_idx", 0)
        source_uri = str(payload.get("source_uri", ""))

        # Fetch neighbors
        neighbor_results: list[SearchResult] = []
        for idx in range(chunk_idx - before, chunk_idx + after + 1):
            if idx == chunk_idx:
                neighbor_results.append(target_chunk)
                continue
            if idx < 0:
                continue
            try:
                nbr = await self._store.search(
                    collection=target_collection,
                    query_dense=[0.0] * self._cfg.embedder.dim,
                    top_n=1,
                    filters={"source_uri": source_uri, "chunk_idx": idx},
                )
                if nbr:
                    neighbor_results.append(nbr[0])
            except Exception:
                continue

        # Sort by chunk_idx and concatenate
        neighbor_results.sort(key=lambda r: r.payload.get("chunk_idx", 0))
        full_text = " ".join(r.text for r in neighbor_results)

        line_start = payload.get("line_start")
        line_end = payload.get("line_end")
        lines: list[int] = []
        if line_start is not None and line_end is not None:
            lines = [int(line_start), int(line_end)]

        return {
            "id": chunk_id,
            "text": full_text,
            "source": source_uri,
            "lines": lines,
            "metadata": {
                "title": payload.get("heading_path", [""])[-1] if payload.get("heading_path") else "",
                "mtime": payload.get("mtime"),
            },
        }

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    async def serve(self) -> None:
        """Read requests from stdin and write responses to stdout until EOF."""
        try:
            while True:
                raw = await self._read_line()
                if raw is None:
                    break
                raw = raw.strip()
                if not raw:
                    continue
                response = await self._handle(raw)
                if response is not None:
                    self._write_response(response)
                if self._writer is not None:
                    try:
                        await self._writer.drain()
                    except Exception:
                        break
        finally:
            if self._embedder is not None and hasattr(self._embedder, "aclose"):
                await self._embedder.aclose()


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------


def _result_id(collection: str, result: SearchResult) -> str:
    """Derive a stable ID from collection + source_uri + chunk_idx."""
    payload = result.payload
    source_uri = str(payload.get("source_uri", ""))
    chunk_idx = int(payload.get("chunk_idx", 0))
    import uuid
    ns = uuid.UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8")
    return str(uuid.uuid5(ns, f"{collection}:{source_uri}:{chunk_idx}"))


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def run(cfg: Config) -> None:
    """Synchronous entry point for ``rag serve-mcp``."""
    server = MCPServer(cfg)
    asyncio.run(server.serve())
