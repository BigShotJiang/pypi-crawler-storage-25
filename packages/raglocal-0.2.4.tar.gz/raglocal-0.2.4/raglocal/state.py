"""SQLite-backed state store for tracking ingested files."""

from __future__ import annotations

import sqlite3
import threading
import time
from pathlib import Path


class StateStore:
    """Tracks ingested files for incremental reindex.

    Uses SQLite with a thread-safe lock for concurrent access.
    """

    def __init__(self, db_path: str) -> None:
        """Initialize state store, creating DB file and schema if needed.

        Args:
            db_path: Path to SQLite database file (expands ~ to home dir).
                Will create parent directories if they don't exist.

        Raises:
            sqlite3.DatabaseError: If DB initialization fails.
        """
        self._db_path = Path(db_path).expanduser().resolve()
        self._db_path.parent.mkdir(parents=True, exist_ok=True)

        self._lock = threading.Lock()

        # Open connection with check_same_thread=False for thread-safety via lock
        self._conn = sqlite3.connect(str(self._db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self) -> None:
        """Create tables if they don't exist."""
        with self._lock:
            cursor = self._conn.cursor()
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS ingested_file (
                    source_uri    TEXT PRIMARY KEY,
                    collection    TEXT NOT NULL,
                    content_hash  TEXT NOT NULL,
                    mtime         INTEGER NOT NULL,
                    chunk_count   INTEGER NOT NULL,
                    indexed_at    INTEGER NOT NULL
                )
                """
            )
            cursor.execute(
                """
                CREATE INDEX IF NOT EXISTS ix_collection
                ON ingested_file(collection)
                """
            )
            self._conn.commit()

    def is_fresh(self, source_uri: str, mtime: int, content_hash: str) -> bool:
        """Check if a source file is fresh (unchanged since last index).

        Args:
            source_uri: Unique identifier for the source.
            mtime: Current modification time (unix timestamp).
            content_hash: Current content hash.

        Returns:
            True if the file exists in DB with matching mtime and content_hash.
        """
        with self._lock:
            cursor = self._conn.cursor()
            cursor.execute(
                "SELECT mtime, content_hash FROM ingested_file WHERE source_uri = ?",
                (source_uri,),
            )
            row = cursor.fetchone()
            if row is None:
                return False
            db_mtime: int = row["mtime"]
            db_hash: str = row["content_hash"]
            return db_mtime == mtime and db_hash == content_hash

    def record(
        self,
        source_uri: str,
        collection: str,
        mtime: int,
        content_hash: str,
        chunk_count: int,
    ) -> None:
        """Record or update a file's ingestion state.

        Args:
            source_uri: Unique identifier for the source.
            collection: Collection name.
            mtime: Modification time (unix timestamp).
            content_hash: Content hash.
            chunk_count: Number of chunks created.
        """
        indexed_at = int(time.time())
        with self._lock:
            cursor = self._conn.cursor()
            cursor.execute(
                """
                INSERT INTO ingested_file
                    (source_uri, collection, content_hash, mtime, chunk_count, indexed_at)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(source_uri) DO UPDATE SET
                    collection = excluded.collection,
                    content_hash = excluded.content_hash,
                    mtime = excluded.mtime,
                    chunk_count = excluded.chunk_count,
                    indexed_at = excluded.indexed_at
                """,
                (source_uri, collection, content_hash, mtime, chunk_count, indexed_at),
            )
            self._conn.commit()

    def forget(self, source_uri: str) -> None:
        """Remove a source from the index.

        Args:
            source_uri: Unique identifier for the source to remove.
        """
        with self._lock:
            cursor = self._conn.cursor()
            cursor.execute("DELETE FROM ingested_file WHERE source_uri = ?", (source_uri,))
            self._conn.commit()

    def list_by_collection(self, collection: str) -> list[dict[str, object]]:
        """List all files in a collection.

        Args:
            collection: Collection name.

        Returns:
            List of dicts with keys: source_uri, collection, content_hash, mtime, chunk_count, indexed_at.
        """
        with self._lock:
            cursor = self._conn.cursor()
            cursor.execute(
                "SELECT * FROM ingested_file WHERE collection = ?",
                (collection,),
            )
            rows = cursor.fetchall()
            return [dict(row) for row in rows]

    def list_all(self) -> list[dict[str, object]]:
        """List every file in the state DB across all collections."""
        with self._lock:
            cursor = self._conn.cursor()
            cursor.execute("SELECT * FROM ingested_file")
            rows = cursor.fetchall()
            return [dict(row) for row in rows]

    def forget_collection(self, collection: str) -> None:
        """Remove all state records for *collection*."""
        with self._lock:
            cursor = self._conn.cursor()
            cursor.execute("DELETE FROM ingested_file WHERE collection = ?", (collection,))
            self._conn.commit()

    def close(self) -> None:
        """Close the database connection."""
        with self._lock:
            self._conn.close()
