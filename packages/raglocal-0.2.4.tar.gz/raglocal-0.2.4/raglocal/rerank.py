"""Reranker: cosine-similarity reranking using an Embedder backend."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from raglocal.config import Config
    from raglocal.embed import Embedder
    from raglocal.store import SearchResult

logger = logging.getLogger(__name__)


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    """Return cosine similarity between two vectors."""
    va = np.array(a, dtype=np.float32)
    vb = np.array(b, dtype=np.float32)
    norm_a = float(np.linalg.norm(va))
    norm_b = float(np.linalg.norm(vb))
    if norm_a == 0.0 or norm_b == 0.0:
        return 0.0
    return float(np.dot(va, vb) / (norm_a * norm_b))


class Reranker:
    """Reranker using cosine similarity between embedded query and passage vectors."""

    def __init__(self, cfg: Config, embedder: Embedder | None = None) -> None:
        """Initialize reranker with config and optional embedder.

        Args:
            cfg: Config instance with reranker settings.
            embedder: Embedder to use for encoding. If None, a new OllamaEmbedder
                      is created from cfg.embedder on first use.
        """
        self.cfg = cfg
        self.enabled = cfg.reranker.enabled
        self.model = cfg.reranker.model
        self._embedder = embedder

    def _get_embedder(self) -> Embedder:
        """Return the embedder, constructing one from cfg if not injected."""
        if self._embedder is not None:
            return self._embedder

        # Use reranker model if set, otherwise fall back to embedder model
        from raglocal.config import EmbedderConfig  # noqa: PLC0415
        from raglocal.embed import OllamaEmbedder  # noqa: PLC0415

        model = self.model if self.model else self.cfg.embedder.model
        host = self.cfg.embedder.host or "http://localhost:11434"
        embed_cfg = EmbedderConfig(
            profile=self.cfg.embedder.profile,
            provider="ollama",
            model=model,
            host=host,
            dim=self.cfg.embedder.dim,
            cache_dir=None,
        )
        return OllamaEmbedder(embed_cfg)

    async def rerank(
        self,
        query: str,
        results: list[SearchResult],
        top_k: int = 5,
    ) -> list[SearchResult]:
        """Rerank search results using cosine similarity of embeddings.

        Embeds the query once, embeds each passage independently, then scores
        each passage by cosine similarity to the query vector.

        Args:
            query: User query string.
            results: List of SearchResult from initial retrieval.
            top_k: Number of top results to return.

        Returns:
            Reranked list of SearchResult, truncated to top_k.
        """
        # Pass-through: if reranking disabled, return top_k unchanged
        if not self.enabled:
            return results[:top_k]

        # If no results or top_k=0, return empty
        if not results or top_k <= 0:
            return results[:top_k]

        embedder = self._get_embedder()

        try:
            # Embed query + all passages in one batch call
            texts = [query] + [r.text for r in results]
            all_vecs = await embedder.embed(texts)
        except Exception as e:
            logger.warning(
                f"Reranker embed failed ({e}), falling back to pass-through."
            )
            return results[:top_k]

        if len(all_vecs) != len(results) + 1:
            logger.warning(
                f"Expected {len(results) + 1} embeddings, got {len(all_vecs)}. "
                "Falling back to pass-through."
            )
            return results[:top_k]

        query_vec = all_vecs[0]
        passage_vecs = all_vecs[1:]

        # Score each passage by cosine similarity to query
        scores = [_cosine_similarity(query_vec, pv) for pv in passage_vecs]

        # Sort by score descending, return top_k
        scored = sorted(zip(results, scores, strict=True), key=lambda x: x[1], reverse=True)
        return [r for r, _ in scored[:top_k]]
