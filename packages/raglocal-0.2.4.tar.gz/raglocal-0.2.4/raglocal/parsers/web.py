"""Web parser: parses HTML files and URLs into ParsedDocuments."""

from __future__ import annotations

from pathlib import Path

from raglocal.chunk import split
from raglocal.parsers.base import ParsedDocument


class WebParser:
    """Parser for HTML files and web URLs."""

    default_collection: str = "docs"
    supported_extensions: frozenset[str] = frozenset({".html", ".htm"})

    async def parse(
        self,
        path: Path,
        *,
        chunk_size: int | None = None,
        chunk_overlap: int | None = None,
    ) -> ParsedDocument:
        """Parse an HTML file and return a ParsedDocument.

        Uses trafilatura for text extraction from HTML.

        Args:
            path: Path to an HTML file.
            chunk_size: Override default chunk size (800).
            chunk_overlap: Override default chunk overlap (100).

        Returns:
            ParsedDocument with extracted text, chunks, metadata, and default_collection.
        """
        try:
            import trafilatura  # noqa: PLC0415
        except ImportError as exc:
            raise ImportError(
                "Web parsing requires trafilatura: pip install trafilatura"
            ) from exc

        raw_html = path.read_text(encoding="utf-8", errors="replace")
        text = trafilatura.extract(raw_html, include_tables=True, include_links=False)
        if not text or not text.strip():
            # Fall back to raw HTML if trafilatura returns nothing
            text = raw_html

        chunks = split(
            text,
            strategy="token",
            chunk_size=chunk_size if chunk_size is not None else 800,
            chunk_overlap=chunk_overlap if chunk_overlap is not None else 100,
        )

        metadata: dict[str, str] = {
            "source": str(path),
            "mtime": str(path.stat().st_mtime),
        }

        return ParsedDocument(
            text=text,
            chunks=chunks,
            metadata=metadata,
            default_collection="docs",
        )
