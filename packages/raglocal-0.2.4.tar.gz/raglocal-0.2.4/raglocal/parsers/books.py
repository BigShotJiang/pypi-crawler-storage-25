"""BooksParser: parses EPUB, MOBI, and large/structured PDFs into ParsedDocuments."""

from __future__ import annotations

import html
import re
from pathlib import Path

from raglocal.chunk import TextChunk, split
from raglocal.parsers.base import ParsedDocument


def _strip_html(raw: str) -> str:
    """Strip HTML tags, decode entities, collapse whitespace."""
    # Remove script/style blocks
    raw = re.sub(r"<(script|style)[^>]*>.*?</(script|style)>", "", raw, flags=re.DOTALL | re.IGNORECASE)
    # Remove all remaining tags
    raw = re.sub(r"<[^>]+>", " ", raw)
    # Decode HTML entities
    raw = html.unescape(raw)
    # Collapse whitespace
    raw = re.sub(r"\s+", " ", raw).strip()
    return raw


def _find_toc_title(book: object, item_id: str) -> str | None:
    """Walk ebooklib TOC to find a title matching the given item_id."""
    try:
        from ebooklib import epub  # noqa: PLC0415

        def _walk(toc_entries: list[object]) -> str | None:
            for entry in toc_entries:
                if isinstance(entry, epub.Link):
                    # href may contain anchor: chap0.xhtml#anchor
                    href = entry.href.split("#")[0]
                    # item_id is like "chap0" — match by file_name or id
                    if href == item_id or href.startswith(item_id):
                        return str(entry.title)
                elif isinstance(entry, tuple):
                    # (Section, [children])
                    result = _walk(list(entry[1]) if len(entry) > 1 else [])
                    if result:
                        return result
            return None

        return _walk(list(book.toc))  # type: ignore[attr-defined]
    except Exception:
        return None


class BooksParser:
    """Parser for EPUB, MOBI, and large/structured PDF files."""

    supported_extensions: frozenset[str] = frozenset({".epub", ".mobi"})

    async def parse(
        self,
        path: Path,
        *,
        chunk_size: int | None = None,
        chunk_overlap: int | None = None,
    ) -> ParsedDocument:
        """Parse a book file into a ParsedDocument.

        Supports .epub, .mobi, and large/structured PDFs (detected via is_book_pdf).

        Args:
            path: Path to the book file.
            chunk_size: Override default chunk size (1200).
            chunk_overlap: Override default chunk overlap (150).
        """
        ext = path.suffix.lower()

        if ext == ".epub":
            return await self._parse_epub(path)
        if ext == ".mobi":
            return await self._parse_mobi(path)
        if ext == ".pdf" and self.is_book_pdf(path):
            return await self._parse_pdf(path)

        raise ValueError(f"BooksParser: unsupported or non-book file: {path}")

    async def _parse_epub(self, path: Path) -> ParsedDocument:
        try:
            import ebooklib  # noqa: PLC0415
            from ebooklib import epub  # noqa: PLC0415
        except ImportError as exc:
            raise ImportError(
                "EPUB support requires: pip install raglocal[books] (ebooklib package)"
            ) from exc

        book = epub.read_epub(str(path))

        title_meta = book.get_metadata("DC", "title")
        title = title_meta[0][0] if title_meta else path.stem

        author_meta = book.get_metadata("DC", "creator")
        author = author_meta[0][0] if author_meta else ""

        chapters: list[tuple[str, str]] = []
        for item_id, _linear in book.spine:
            item = book.get_item_with_id(item_id)
            if item is None:
                continue
            if item.get_type() != ebooklib.ITEM_DOCUMENT:
                continue
            raw = item.get_content().decode("utf-8", errors="replace")
            text = _strip_html(raw)
            if not text.strip():
                continue
            chapter_title = _find_toc_title(book, item.file_name) or f"Chapter {len(chapters) + 1}"
            chapters.append((chapter_title, text))

        all_chunks: list[TextChunk] = []
        full_text_parts: list[str] = []

        for chapter_title, chapter_text in chapters:
            chapter_chunks = split(chapter_text, strategy="chapter")
            # Override heading_path with [title, chapter_title]
            for chunk in chapter_chunks:
                all_chunks.append(
                    TextChunk(
                        text=chunk.text,
                        chunk_idx=chunk.chunk_idx,
                        chunk_total=chunk.chunk_total,
                        heading_path=[title, chapter_title],
                        line_start=chunk.line_start,
                        line_end=chunk.line_end,
                    )
                )
            full_text_parts.append(chapter_text)

        full_text = "\n\n".join(full_text_parts)

        return ParsedDocument(
            text=full_text,
            chunks=all_chunks,
            metadata={"title": title, "author": author},
            default_collection="books",
        )

    async def _parse_mobi(self, path: Path) -> ParsedDocument:
        try:
            import mobi  # noqa: PLC0415
        except ImportError as exc:
            raise ImportError(
                "MOBI support requires: pip install raglocal[books] (mobi package)"
            ) from exc

        tempdir, filepath = mobi.extract(str(path))
        extracted = Path(filepath)

        # Find HTML files in extracted directory
        html_files = sorted(extracted.parent.rglob("*.html")) + sorted(extracted.parent.rglob("*.htm"))
        if not html_files and extracted.suffix.lower() in {".html", ".htm"}:
            html_files = [extracted]

        chapters: list[tuple[str, str]] = []
        for i, html_file in enumerate(html_files):
            raw = html_file.read_text(encoding="utf-8", errors="replace")
            text = _strip_html(raw)
            if text.strip():
                chapters.append((f"Chapter {i + 1}", text))

        title = path.stem
        author = ""

        all_chunks: list[TextChunk] = []
        full_text_parts: list[str] = []

        for chapter_title, chapter_text in chapters:
            chapter_chunks = split(chapter_text, strategy="chapter")
            for chunk in chapter_chunks:
                all_chunks.append(
                    TextChunk(
                        text=chunk.text,
                        chunk_idx=chunk.chunk_idx,
                        chunk_total=chunk.chunk_total,
                        heading_path=[title, chapter_title],
                        line_start=chunk.line_start,
                        line_end=chunk.line_end,
                    )
                )
            full_text_parts.append(chapter_text)

        full_text = "\n\n".join(full_text_parts)

        return ParsedDocument(
            text=full_text,
            chunks=all_chunks,
            metadata={"title": title, "author": author},
            default_collection="books",
        )

    async def _parse_pdf(self, path: Path) -> ParsedDocument:
        try:
            import pypdf  # noqa: PLC0415
        except ImportError as exc:
            raise ImportError(
                "PDF support requires: pip install raglocal[books] (pypdf package)"
            ) from exc

        reader = pypdf.PdfReader(str(path))
        outline = []
        try:
            outline = reader.outline
        except Exception:
            outline = []

        title = path.stem
        all_chunks: list[TextChunk] = []
        full_text_parts: list[str] = []

        def _flatten_outline(entries: list[object]) -> list[object]:
            """Flatten nested outline to list of pypdf Destination objects."""
            flat = []
            for entry in entries:
                if isinstance(entry, list):
                    flat.extend(_flatten_outline(entry))
                else:
                    flat.append(entry)
            return flat

        if outline:
            flat = _flatten_outline(list(outline))
            # Map outline entries to page numbers
            entry_pages: list[tuple[str, int]] = []
            for entry in flat:
                try:
                    page_obj = getattr(entry, "page", None)
                    if page_obj is None:
                        continue
                    page_num = reader.get_page_number(page_obj)
                    if page_num is None:
                        continue
                    entry_title = getattr(entry, "title", None) or str(entry)
                    entry_pages.append((str(entry_title), int(page_num)))
                except Exception:
                    continue

            # Slice pages per outline entry
            for i, (entry_title, start_page) in enumerate(entry_pages):
                end_page = entry_pages[i + 1][1] if i + 1 < len(entry_pages) else len(reader.pages)
                pages_text = []
                for p in range(start_page, end_page):
                    page_text = reader.pages[p].extract_text() or ""
                    pages_text.append(page_text)
                section_text = "\n".join(pages_text)
                if not section_text.strip():
                    continue
                section_chunks = split(section_text, strategy="chapter")
                for chunk in section_chunks:
                    all_chunks.append(
                        TextChunk(
                            text=chunk.text,
                            chunk_idx=chunk.chunk_idx,
                            chunk_total=chunk.chunk_total,
                            heading_path=[title, entry_title],
                            line_start=chunk.line_start,
                            line_end=chunk.line_end,
                        )
                    )
                full_text_parts.append(section_text)
        else:
            # No outline: group pages into chunks of 10
            pages = reader.pages
            group_size = 10
            for group_start in range(0, len(pages), group_size):
                group_end = min(group_start + group_size, len(pages))
                pages_text = []
                for p in range(group_start, group_end):
                    pages_text.append(reader.pages[p].extract_text() or "")
                section_text = "\n".join(pages_text)
                if not section_text.strip():
                    continue
                section_chunks = split(section_text, strategy="chapter")
                chapter_title = f"Pages {group_start + 1}-{group_end}"
                for chunk in section_chunks:
                    all_chunks.append(
                        TextChunk(
                            text=chunk.text,
                            chunk_idx=chunk.chunk_idx,
                            chunk_total=chunk.chunk_total,
                            heading_path=[title, chapter_title],
                            line_start=chunk.line_start,
                            line_end=chunk.line_end,
                        )
                    )
                full_text_parts.append(section_text)

        full_text = "\n\n".join(full_text_parts)

        return ParsedDocument(
            text=full_text,
            chunks=all_chunks,
            metadata={"title": title, "author": ""},
            default_collection="books",
        )

    @staticmethod
    def is_book_pdf(path: Path) -> bool:
        """Return True if path is a large or structured PDF (book-like).

        Criteria: suffix == ".pdf" AND (size >= 5 MB OR outline has >= 3 entries).
        """
        if path.suffix.lower() != ".pdf":
            return False
        try:
            import pypdf  # noqa: PLC0415
        except ImportError:
            return False
        try:
            size = path.stat().st_size
            if size >= 5 * 1024 * 1024:
                return True
            reader = pypdf.PdfReader(str(path))
            try:
                outline = reader.outline
            except Exception:
                outline = []

            def _count_outline(entries: list[object]) -> int:
                count = 0
                for entry in entries:
                    if isinstance(entry, list):
                        count += _count_outline(entry)
                    else:
                        count += 1
                return count

            return _count_outline(list(outline)) >= 3
        except Exception:
            return False
