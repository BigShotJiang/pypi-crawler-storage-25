"""Sessions parser: parses OpenCode session JSON files into ParsedDocuments."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from raglocal.chunk import split
from raglocal.parsers.base import ParsedDocument

# Keys that indicate a session-format JSON file
_SESSION_KEYS = {"session_id", "messages", "role", "content"}


def _is_session_json(data: object) -> bool:
    """Return True if *data* looks like an OpenCode session JSON structure.

    Accepts:
    - A dict with at least one of the session-specific keys.
    - A list where at least one element has session-specific keys.
    """
    if isinstance(data, dict):
        return bool(set(data.keys()) & _SESSION_KEYS)
    if isinstance(data, list) and data:
        first = data[0]
        if isinstance(first, dict):
            return bool(set(first.keys()) & _SESSION_KEYS)
    return False


def _extract_session_text(data: object) -> str:
    """Convert session JSON data to a readable text representation."""
    lines: list[str] = []

    def _process_entry(entry: object) -> None:
        if not isinstance(entry, dict):
            return
        role = entry.get("role", "")
        content = entry.get("content", "")
        if role or content:
            lines.append(f"{role}: {content}" if role else str(content))

    if isinstance(data, dict):
        # Single session object
        messages = data.get("messages", [])
        if isinstance(messages, list):
            for msg in messages:
                _process_entry(msg)
        else:
            # Flat dict with role/content keys
            _process_entry(data)
    elif isinstance(data, list):
        for item in data:
            _process_entry(item)

    return "\n".join(lines) if lines else json.dumps(data, indent=2)


class SessionsParser:
    """Parser for OpenCode session JSON files."""

    default_collection: str = "sessions"
    supported_extensions: frozenset[str] = frozenset({".json"})

    async def parse(
        self,
        path: Path,
        *,
        chunk_size: int | None = None,
        chunk_overlap: int | None = None,
    ) -> ParsedDocument:
        """Parse a session JSON file and return a ParsedDocument.

        Only processes JSON files that contain session-format data (files
        with session-specific keys). Raises ValueError for non-session JSON.

        Args:
            path: Path to a JSON file containing session data.
            chunk_size: Override default chunk size (600).
            chunk_overlap: Override default chunk overlap (100).

        Returns:
            ParsedDocument with extracted text, chunks, metadata, and default_collection.

        Raises:
            ValueError: If the JSON file does not contain session-format data.
        """
        raw = path.read_text(encoding="utf-8", errors="replace")
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSON in {path}: {exc}") from exc

        if not _is_session_json(data):
            raise ValueError(
                f"{path} does not appear to be a session JSON file "
                f"(expected keys: {_SESSION_KEYS})"
            )

        text = _extract_session_text(data)

        content_hash = f"sha256:{hashlib.sha256(text.encode()).hexdigest()}"

        chunks = split(
            text,
            strategy="token",
            chunk_size=chunk_size if chunk_size is not None else 600,
            chunk_overlap=chunk_overlap if chunk_overlap is not None else 100,
        )

        metadata: dict[str, str] = {
            "source": str(path),
            "content_hash": content_hash,
            "mtime": str(path.stat().st_mtime),
        }

        return ParsedDocument(
            text=text,
            chunks=chunks,
            metadata=metadata,
            default_collection="sessions",
        )
