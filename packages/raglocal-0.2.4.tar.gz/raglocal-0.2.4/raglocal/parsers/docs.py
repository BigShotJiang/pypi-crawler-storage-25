"""Docs parser: parses Markdown, TXT, PDF, DOCX, DOC, ODT, JSON, YAML files."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

from raglocal.chunk import split
from raglocal.parsers.base import ParsedDocument, extract_first_h1, strip_frontmatter

_strip_frontmatter = strip_frontmatter
_extract_first_h1 = extract_first_h1


def _read_pdf(path: Path) -> str:
    try:
        import pypdf  # noqa: PLC0415
    except ImportError as e:
        raise ImportError(
            "PDF support requires pypdf: pip install raglocal[office] or pip install pypdf"
        ) from e
    reader = pypdf.PdfReader(str(path))
    pages = [page.extract_text() or "" for page in reader.pages]
    return "\n".join(pages)


def _read_docx(path: Path) -> str:
    try:
        import docx  # noqa: PLC0415
    except ImportError as e:
        raise ImportError(
            "DOCX support requires python-docx: pip install raglocal[office] or pip install python-docx"
        ) from e
    doc = docx.Document(str(path))
    return "\n".join(p.text for p in doc.paragraphs)


def _read_doc(path: Path) -> str:
    try:
        result = subprocess.run(
            ["antiword", str(path)],
            capture_output=True,
            text=True,
        )
    except FileNotFoundError as e:
        raise RuntimeError(
            "DOC support requires antiword: brew install antiword / apt install antiword"
        ) from e
    if result.returncode != 0:
        raise RuntimeError(
            "DOC support requires antiword: brew install antiword / apt install antiword"
        )
    return result.stdout


def _read_odt(path: Path) -> str:
    try:
        from odf import text as odftext  # noqa: PLC0415
        from odf.opendocument import load  # noqa: PLC0415
    except ImportError as e:
        raise ImportError(
            "ODT support requires odfpy: pip install raglocal[office] or pip install odfpy"
        ) from e
    doc = load(str(path))
    texts = doc.getElementsByType(odftext.P)
    return "\n".join(
        "".join(node.data for node in t.childNodes if hasattr(node, "data")) for t in texts
    )


def _read_json(path: Path) -> str:
    data = json.loads(path.read_text(encoding="utf-8"))
    return json.dumps(data, indent=2)


def _read_yaml(path: Path) -> str:
    try:
        import yaml  # noqa: PLC0415
    except ImportError as e:
        raise ImportError(
            "YAML support requires PyYAML: pip install raglocal[office] or pip install pyyaml"
        ) from e
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    result: str = yaml.safe_dump(data, default_flow_style=False)
    return result


class DocsParser:
    """Parser for documentation files: Markdown, TXT, PDF, DOCX, DOC, ODT, JSON, YAML."""

    supported_extensions: frozenset[str] = frozenset(
        {".md", ".markdown", ".txt", ".pdf", ".docx", ".doc", ".odt", ".json", ".yaml", ".yml"}
    )

    async def parse(
        self,
        path: Path,
        *,
        chunk_size: int | None = None,
        chunk_overlap: int | None = None,
    ) -> ParsedDocument:
        """Parse a document file and return a ParsedDocument.

        Args:
            path: Path to the file to parse.
            chunk_size: Override default chunk size (800).
            chunk_overlap: Override default chunk overlap (100).

        Returns:
            ParsedDocument with extracted text, chunks, metadata, and default_collection.
        """
        ext = path.suffix.lower()
        title: str | None = None
        text: str

        if ext in {".md", ".markdown"}:
            raw = path.read_text(encoding="utf-8", errors="replace")
            text, fm = _strip_frontmatter(raw)
            title = fm.get("title") or _extract_first_h1(text) or path.stem
        elif ext == ".txt":
            text = path.read_text(encoding="utf-8", errors="replace")
            title = path.stem
        elif ext == ".pdf":
            text = _read_pdf(path)
            title = path.stem
        elif ext == ".docx":
            text = _read_docx(path)
            title = path.stem
        elif ext == ".doc":
            text = _read_doc(path)
            title = path.stem
        elif ext == ".odt":
            text = _read_odt(path)
            title = path.stem
        elif ext == ".json":
            text = _read_json(path)
            title = path.stem
        elif ext in {".yaml", ".yml"}:
            text = _read_yaml(path)
            title = path.stem
        else:
            raise ValueError(f"Unsupported extension: {ext!r}")

        is_markdown = ".md" in path.suffixes
        chunks = split(
            text,
            strategy="token",
            chunk_size=chunk_size if chunk_size is not None else 800,
            chunk_overlap=chunk_overlap if chunk_overlap is not None else 100,
            is_markdown=is_markdown,
        )

        metadata: dict[str, str] = {
            "title": title or path.stem,
            "source": str(path),
            "mtime": str(path.stat().st_mtime),
        }

        return ParsedDocument(
            text=text,
            chunks=chunks,
            metadata=metadata,
            default_collection="docs",
        )
