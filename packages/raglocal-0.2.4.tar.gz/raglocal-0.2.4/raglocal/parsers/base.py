from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol, runtime_checkable

from raglocal.chunk import TextChunk


@dataclass
class ParsedDocument:
    text: str
    chunks: list[TextChunk]  # pre-chunked when parser knows structure
    metadata: dict[str, str]          # title, author, chapter_title, date, etc.
    default_collection: str


@runtime_checkable
class Parser(Protocol):
    supported_extensions: frozenset[str]

    async def parse(
        self,
        path: Path,
        *,
        chunk_size: int | None = None,
        chunk_overlap: int | None = None,
    ) -> ParsedDocument: ...


def strip_frontmatter(text: str) -> tuple[str, dict[str, str]]:
    """Strip YAML frontmatter from text, return (clean_text, frontmatter_dict)."""
    if not text.startswith("---"):
        return text, {}
    lines = text.split("\n")
    end = -1
    for i, line in enumerate(lines[1:], start=1):
        if line.strip() == "---":
            end = i
            break
    if end == -1:
        return text, {}

    fm_lines = lines[1:end]
    clean_text = "\n".join(lines[end + 1 :]).lstrip("\n")

    # Parse frontmatter as simple key: value pairs
    fm: dict[str, str] = {}
    for line in fm_lines:
        m = re.match(r"^(\w+):\s*(.*)$", line)
        if m:
            fm[m.group(1)] = m.group(2).strip()

    return clean_text, fm


def extract_first_h1(text: str) -> str | None:
    """Extract the first H1 heading from text."""
    for line in text.split("\n"):
        m = re.match(r"^#\s+(.+)$", line)
        if m:
            return m.group(1).strip()
    return None
