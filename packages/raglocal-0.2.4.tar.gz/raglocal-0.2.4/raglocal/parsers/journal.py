"""Journal parser: parses journal/diary entries from Markdown and TXT files."""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

from raglocal.chunk import split
from raglocal.parsers.base import ParsedDocument, extract_first_h1, strip_frontmatter

_DATE_PATTERN = re.compile(r"^(\d{4}-\d{2}-\d{2})")
_DATE_IN_TEXT = re.compile(r"\b(\d{4}-\d{2}-\d{2})\b")

_strip_frontmatter = strip_frontmatter
_extract_first_h1 = extract_first_h1


def _detect_date(path: Path, text: str, fm: dict[str, str]) -> str:
    """Detect date using priority order: frontmatter > filename > H1 > mtime."""
    # 1. YAML frontmatter date field
    if "date" in fm:
        return fm["date"]

    # 2. Filename pattern: YYYY-MM-DD or YYYY-MM-DD-anything
    filename_match = _DATE_PATTERN.match(path.stem)
    if filename_match:
        return filename_match.group(1)

    # 3. First H1 heading containing a date-like string
    for line in text.split("\n"):
        m = re.match(r"^#\s+(.+)$", line)
        if m:
            date_match = _DATE_IN_TEXT.search(m.group(1))
            if date_match:
                return date_match.group(1)

    # 4. File mtime as fallback
    return datetime.fromtimestamp(path.stat().st_mtime).date().isoformat()


class JournalParser:
    """Parser for journal/diary entries in Markdown and plain text format."""

    supported_extensions: frozenset[str] = frozenset({".md", ".markdown", ".txt"})

    async def parse(
        self,
        path: Path,
        *,
        chunk_size: int | None = None,
        chunk_overlap: int | None = None,
    ) -> ParsedDocument:
        """Parse a journal entry file and return a ParsedDocument.

        Args:
            path: Path to the journal entry file.
            chunk_size: Override default chunk size (600).
            chunk_overlap: Override default chunk overlap (50).

        Returns:
            ParsedDocument with extracted text, chunks, metadata, and default_collection.
        """
        raw = path.read_text(encoding="utf-8", errors="replace")
        text, fm = _strip_frontmatter(raw)

        date = _detect_date(path, text, fm)

        # Entry title detection
        if "title" in fm:
            entry_title = fm["title"]
        else:
            h1 = _extract_first_h1(text)
            entry_title = h1 if h1 else path.stem

        chunks = split(
            text,
            strategy="sentence",
            chunk_size=chunk_size if chunk_size is not None else 600,
            chunk_overlap=chunk_overlap if chunk_overlap is not None else 50,
        )

        metadata: dict[str, str] = {
            "date": date,
            "entry_title": entry_title,
            "source": str(path),
            "mtime": str(path.stat().st_mtime),
        }

        return ParsedDocument(
            text=text,
            chunks=chunks,
            metadata=metadata,
            default_collection="journal",
        )
