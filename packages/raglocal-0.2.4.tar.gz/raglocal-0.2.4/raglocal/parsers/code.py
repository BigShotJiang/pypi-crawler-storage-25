"""Code parser: parses source code files into ParsedDocuments."""

from __future__ import annotations

from pathlib import Path

from raglocal.chunk import split
from raglocal.parsers.base import ParsedDocument

_EXTENSION_TO_LANGUAGE: dict[str, str] = {
    ".py": "python",
    ".ts": "typescript",
    ".js": "javascript",
    ".go": "go",
    ".rs": "rust",
    ".java": "java",
    ".cpp": "cpp",
    ".c": "c",
    ".h": "c",
    ".hpp": "cpp",
    ".rb": "ruby",
    ".swift": "swift",
    ".kt": "kotlin",
    ".cs": "csharp",
    ".scala": "scala",
    ".r": "r",
    ".m": "objc",
    ".sh": "bash",
    ".bash": "bash",
    ".php": "php",
}


class CodeParser:
    """Parser for source code files."""

    default_collection: str = "code"
    supported_extensions: frozenset[str] = frozenset(
        {
            ".py", ".ts", ".js", ".go", ".rs", ".java",
            ".cpp", ".c", ".h", ".hpp", ".rb", ".swift",
            ".kt", ".cs", ".scala", ".r", ".m", ".sh",
            ".bash", ".php",
        }
    )

    async def parse(
        self,
        path: Path,
        *,
        chunk_size: int | None = None,
        chunk_overlap: int | None = None,
    ) -> ParsedDocument:
        """Parse a source code file and return a ParsedDocument.

        Args:
            path: Path to the source code file.
            chunk_size: Override default chunk size (500).
            chunk_overlap: Override default chunk overlap (50).

        Returns:
            ParsedDocument with extracted text, chunks, metadata, and default_collection.
        """
        ext = path.suffix.lower()
        language = _EXTENSION_TO_LANGUAGE.get(ext, ext.lstrip("."))

        text = path.read_text(encoding="utf-8", errors="replace")

        chunks = split(
            text,
            strategy="code-aware",
            chunk_size=chunk_size if chunk_size is not None else 500,
            chunk_overlap=chunk_overlap if chunk_overlap is not None else 50,
            language=language,
        )

        metadata: dict[str, str] = {
            "language": language,
            "source": str(path),
            "mtime": str(path.stat().st_mtime),
        }

        return ParsedDocument(
            text=text,
            chunks=chunks,
            metadata=metadata,
            default_collection="code",
        )
