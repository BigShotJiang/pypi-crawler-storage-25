"""index.py — top-level ingestion pipeline using the parsers layer."""

from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from raglocal.config import Config
    from raglocal.embed import Embedder
    from raglocal.state import StateStore
    from raglocal.store import VectorStore

_HASH_READ_LIMIT = 1024 * 1024  # 1 MiB
_BATCH_SIZE = 64

# Hidden directories to skip when walking file trees
_HIDDEN_DIRS = frozenset(
    {".git", "node_modules", "__pycache__", ".venv", ".tox", "dist", "build"}
)


@dataclass
class IngestReport:
    """Summary of an index_paths run."""

    indexed: int = 0
    skipped: int = 0
    errors: list[str] = field(default_factory=list)
    collections: dict[str, int] = field(default_factory=dict)


def _compute_content_hash(path: Path) -> str:
    """Return sha256 hex digest of the first 1 MiB of *path*."""
    h = hashlib.sha256()
    with path.open("rb") as f:
        h.update(f.read(_HASH_READ_LIMIT))
    return f"sha256:{h.hexdigest()}"


def _iter_paths(root: str) -> list[Path]:
    """Expand a path string to a list of files, respecting hidden-dir exclusions."""
    p = Path(root).expanduser().resolve()
    if p.is_file():
        return [p]
    if p.is_dir():
        collected: list[Path] = []
        for dirpath, dirs, files in os.walk(p):
            dirs[:] = [d for d in dirs if d not in _HIDDEN_DIRS]
            for fname in files:
                collected.append(Path(dirpath) / fname)
        return collected
    return []


def _build_parser_registry() -> list[object]:
    """Return all available parsers in priority order.

    Priority rules:
    - BooksParser before DocsParser: book-like PDFs take precedence.
    - SessionsParser before DocsParser: session JSON takes precedence over
      generic JSON handling (SessionsParser rejects non-session JSON via
      ValueError, allowing DocsParser to handle the rest).
    - CodeParser and WebParser handle their own disjoint extensions.
    """
    from raglocal.parsers.books import BooksParser
    from raglocal.parsers.code import CodeParser
    from raglocal.parsers.docs import DocsParser
    from raglocal.parsers.journal import JournalParser
    from raglocal.parsers.sessions import SessionsParser
    from raglocal.parsers.web import WebParser

    return [
        BooksParser(),
        SessionsParser(),
        DocsParser(),
        JournalParser(),
        CodeParser(),
        WebParser(),
    ]


def _find_candidates(path: Path, parsers: list[object]) -> list[object]:
    """Return all parsers that declare support for *path*'s extension, in order.

    BooksParser is pre-filtered: it only appears in the result for .pdf files
    that pass is_book_pdf().
    """
    from raglocal.parsers.books import BooksParser

    ext = path.suffix.lower()
    candidates: list[object] = []
    for parser in parsers:
        supported: frozenset[str] = getattr(parser, "supported_extensions", frozenset())
        if ext not in supported:
            continue
        if isinstance(parser, BooksParser) and ext == ".pdf" and not BooksParser.is_book_pdf(path):
            continue
        candidates.append(parser)
    return candidates


async def index_paths(
    cfg: Config,
    embedder: Embedder,
    store: VectorStore,
    state: StateStore,
    paths: list[str],
    *,
    reindex: bool = False,
    collection: str | None = None,
) -> IngestReport:
    """Index a list of file/directory paths into the vector store.

    For each file found under *paths*:
    1. Selects the appropriate parser by extension.
    2. Checks freshness via the state store (skips unchanged files unless
       ``reindex=True``).
    3. Parses the file into a ``ParsedDocument``.
    4. Converts ``TextChunk``s to ``Chunk``s and embeds in batches of 64.
    5. Upserts into the vector store and records the new state.

    Args:
        cfg: Application configuration (used for per-collection chunk_size/chunk_overlap).
        embedder: Embedder used to produce dense vectors.
        store: Vector store for ``ensure_collection`` / ``upsert`` / ``delete_by_source``.
        state: State store for incremental skip logic.
        paths: File paths or directories to index.
        reindex: When True, re-process files even if already up-to-date.
        collection: Override the collection name for all files. If None, each
            parser's ``default_collection`` is used.

    Returns:
        IngestReport summarising indexed, skipped, error counts, and per-collection
        chunk totals.
    """
    from raglocal.store import Chunk

    report = IngestReport()
    parsers = _build_parser_registry()

    # Gather all candidate files
    all_files: list[Path] = []
    for raw_path in paths:
        all_files.extend(_iter_paths(raw_path))

    for path in all_files:
        source_uri = path.as_uri()
        try:
            candidates = _find_candidates(path, parsers)
            if not candidates:
                # No parser supports this extension — silently skip
                continue

            # Freshness check (before parsing — uses file hash only)
            content_hash = _compute_content_hash(path)
            mtime = int(path.stat().st_mtime)

            if not reindex and state.is_fresh(source_uri, mtime, content_hash):
                report.skipped += 1
                continue

            # Try candidates in order; parsers may raise ValueError to signal
            # "not my format" (e.g. SessionsParser for non-session JSON).
            doc = None
            last_exc: Exception | None = None
            for parser in candidates:
                try:
                    # Determine collection name for config lookup.
                    # Use caller override first, else parser's default_collection.
                    _default_col = getattr(parser, "default_collection", None)
                    _col_for_cfg = collection if collection is not None else _default_col
                    _col_cfg = (
                        cfg.collections.get(_col_for_cfg)
                        if cfg is not None and _col_for_cfg
                        else None
                    )
                    _parse_kwargs: dict[str, int] = {}
                    if _col_cfg is not None:
                        if _col_cfg.chunk_size > 0:
                            _parse_kwargs["chunk_size"] = _col_cfg.chunk_size
                        if _col_cfg.chunk_overlap > 0:
                            _parse_kwargs["chunk_overlap"] = _col_cfg.chunk_overlap
                    doc = await parser.parse(path, **_parse_kwargs)  # type: ignore[attr-defined]
                    break
                except ValueError as exc:
                    last_exc = exc
                    continue

            if doc is None:
                if last_exc is not None:
                    raise last_exc
                continue

            text_chunks = doc.chunks

            # Determine collection name: caller override > parser's doc default
            col_name = collection if collection is not None else doc.default_collection

            if not text_chunks:
                # File parsed but produced no chunks (empty file, etc.)
                store.delete_by_source(col_name, source_uri)
                state.record(source_uri, col_name, mtime, content_hash, 0)
                report.indexed += 1
                report.collections[col_name] = report.collections.get(col_name, 0)
                continue

            chunk_total = len(text_chunks)

            # Ensure collection exists
            store.ensure_collection(col_name, dim=embedder.dim, with_sparse=False)

            # Build Chunk objects
            store_chunks = [
                Chunk(
                    text=tc.text,
                    source_uri=source_uri,
                    source_type=col_name,
                    collection=col_name,
                    chunk_idx=tc.chunk_idx,
                    chunk_total=chunk_total,
                    heading_path=tc.heading_path if tc.heading_path else [],
                    line_start=tc.line_start,
                    line_end=tc.line_end,
                    mtime=mtime,
                    content_hash=content_hash,
                    tags=[],
                    extra=None,
                )
                for tc in text_chunks
            ]

            # Embed in batches of _BATCH_SIZE
            all_vectors: list[list[float]] = []
            for i in range(0, len(store_chunks), _BATCH_SIZE):
                batch = store_chunks[i : i + _BATCH_SIZE]
                vectors = await embedder.embed([c.text for c in batch])
                all_vectors.extend(vectors)

            # Delete old points then upsert fresh ones
            store.delete_by_source(col_name, source_uri)
            await store.upsert(col_name, all_vectors, store_chunks)
            state.record(source_uri, col_name, mtime, content_hash, chunk_total)

            report.indexed += 1
            report.collections[col_name] = report.collections.get(col_name, 0) + chunk_total

        except Exception as exc:  # noqa: BLE001
            report.errors.append(f"{source_uri}: {exc}")

    return report
