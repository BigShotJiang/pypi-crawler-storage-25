"""Text and code chunker with token-aware splitting and markdown heading awareness."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal

ChunkStrategy = Literal["token", "sentence", "code-aware", "chapter"]


@dataclass(frozen=True)
class TextChunk:
    """A chunk of text with metadata."""

    text: str
    chunk_idx: int
    chunk_total: int
    heading_path: list[str]
    line_start: int
    line_end: int


def split_text(
    text: str,
    chunk_size: int = 800,
    chunk_overlap: int = 100,
    is_markdown: bool = False,
) -> list[TextChunk]:
    """
    Split text into chunks with optional overlap and markdown heading awareness.

    Args:
        text: The text to split.
        chunk_size: Target chunk size in tokens (approximate via whitespace-split).
        chunk_overlap: Number of tokens to overlap between consecutive chunks.
        is_markdown: If True, track markdown heading hierarchy.

    Returns:
        List of TextChunk objects.
    """
    if not text or not text.strip():
        return []

    lines = text.split("\n")

    # Parse markdown headings if needed
    heading_map: dict[int, tuple[int, str]] = {}  # line_idx -> (level, heading)
    if is_markdown:
        for line_idx, line in enumerate(lines):
            heading_match = re.match(r"^(#{1,6})\s+(.+)$", line)
            if heading_match:
                level = len(heading_match.group(1))
                heading_text = heading_match.group(2)
                heading_map[line_idx] = (level, heading_text)

    # Build a map of (line_idx) -> heading_stack at that line
    line_heading_stacks: dict[int, list[str]] = {}
    heading_stack: list[str] = []

    for line_idx in range(len(lines)):
        if line_idx in heading_map:
            level, heading_text = heading_map[line_idx]
            # Pop headings at same or deeper level
            while heading_stack and len(heading_stack) >= level:
                heading_stack.pop()
            heading_stack.append(heading_text)

        line_heading_stacks[line_idx] = list(heading_stack)

    # Split text into chunks based on token count
    tokens_with_positions: list[tuple[str, int, int]] = []  # (token, start_line, end_line)

    for line_idx, line in enumerate(lines):
        if line.strip():
            # Skip heading lines in markdown mode
            if is_markdown and line_idx in heading_map:
                continue

            for token in line.split():
                tokens_with_positions.append((token, line_idx, line_idx))

    if not tokens_with_positions:
        return []

    # Perform recursive splitting
    chunk_boundaries = _find_chunk_boundaries(tokens_with_positions, chunk_size, chunk_overlap)

    chunks: list[TextChunk] = []
    for chunk_idx, (start_idx, end_idx) in enumerate(chunk_boundaries):
        chunk_tokens = [t[0] for t in tokens_with_positions[start_idx : end_idx + 1]]
        chunk_text = " ".join(chunk_tokens)

        # Determine line range
        chunk_start_line = tokens_with_positions[start_idx][1] + 1  # 1-indexed
        chunk_end_line = tokens_with_positions[end_idx][2] + 1  # 1-indexed

        # Determine heading path (use the heading from the first token's position)
        heading_path = line_heading_stacks[tokens_with_positions[start_idx][1]]

        chunks.append(
            TextChunk(
                text=chunk_text,
                chunk_idx=chunk_idx,
                chunk_total=-1,  # Will update below
                heading_path=heading_path,
                line_start=chunk_start_line,
                line_end=chunk_end_line,
            )
        )

    # Update chunk_total
    total = len(chunks)
    chunks = [
        TextChunk(
            text=chunk.text,
            chunk_idx=chunk.chunk_idx,
            chunk_total=total,
            heading_path=chunk.heading_path,
            line_start=chunk.line_start,
            line_end=chunk.line_end,
        )
        for chunk in chunks
    ]

    return chunks


def _token_count(text: str) -> int:
    """Simple whitespace-based token count."""
    return len(text.split())


def split(
    text: str,
    strategy: ChunkStrategy = "token",
    chunk_size: int = 800,
    chunk_overlap: int = 100,
    is_markdown: bool = False,
    language: str | None = None,
) -> list[TextChunk]:
    """
    Split text using the specified strategy.

    Args:
        text: The text to split.
        strategy: One of "token", "sentence", "code-aware", "chapter".
        chunk_size: Target chunk size in tokens.
        chunk_overlap: Number of tokens to overlap (used by token strategy).
        is_markdown: If True, track markdown heading hierarchy (token strategy).
        language: Programming language hint for code-aware strategy.

    Returns:
        List of TextChunk objects.
    """
    if strategy == "token":
        return split_text(text, chunk_size=chunk_size, chunk_overlap=chunk_overlap, is_markdown=is_markdown)

    if strategy == "sentence":
        return _split_sentence(text, chunk_size=chunk_size)

    if strategy == "code-aware":
        return _split_code_aware(text, chunk_size=chunk_size, language=language)

    if strategy == "chapter":
        # Stub: delegates to token strategy; real chapter logic lives in parsers/books.py
        return split_text(text, chunk_size=chunk_size, chunk_overlap=chunk_overlap, is_markdown=is_markdown)

    # Exhaustive match — should never reach here with correct Literal type
    return split_text(text, chunk_size=chunk_size, chunk_overlap=chunk_overlap, is_markdown=is_markdown)


def _split_sentence(text: str, chunk_size: int = 800) -> list[TextChunk]:
    """Split on sentence boundaries, packing sentences into chunks <= chunk_size tokens."""
    if not text or not text.strip():
        return []

    # Split on sentence boundaries
    sentences = re.split(r"(?<=[.!?])\s+", text.strip())

    chunks: list[TextChunk] = []
    current_sentences: list[str] = []
    current_tokens = 0
    line_start = 1

    def _flush(sents: list[str], idx: int, start_line: int) -> TextChunk:
        chunk_text = " ".join(sents)
        end_line = start_line + chunk_text.count("\n")
        return TextChunk(
            text=chunk_text,
            chunk_idx=idx,
            chunk_total=-1,
            heading_path=[],
            line_start=start_line,
            line_end=end_line,
        )

    for sentence in sentences:
        sentence = sentence.strip()
        if not sentence:
            continue
        sent_tokens = _token_count(sentence)

        if current_sentences and current_tokens + sent_tokens > chunk_size:
            chunks.append(_flush(current_sentences, len(chunks), line_start))
            # Advance line_start past the flushed chunk
            flushed_text = chunks[-1].text
            line_start += flushed_text.count("\n") + 1
            current_sentences = [sentence]
            current_tokens = sent_tokens
        else:
            current_sentences.append(sentence)
            current_tokens += sent_tokens

    if current_sentences:
        chunks.append(_flush(current_sentences, len(chunks), line_start))

    # Fix chunk_total
    total = len(chunks)
    chunks = [
        TextChunk(
            text=c.text,
            chunk_idx=c.chunk_idx,
            chunk_total=total,
            heading_path=c.heading_path,
            line_start=c.line_start,
            line_end=c.line_end,
        )
        for c in chunks
    ]
    return chunks


def _split_code_aware(
    text: str,
    chunk_size: int = 800,
    language: str | None = None,
) -> list[TextChunk]:
    """Split on function/class boundaries, preserving boundary line at chunk start."""
    if not text or not text.strip():
        return []

    # Build boundary pattern based on language
    base_pattern = r"^(def |class |function |func |fn |impl |interface |struct |enum )"
    if language in ("javascript", "typescript"):
        pattern = re.compile(
            r"^(def |class |function |func |fn |impl |interface |struct |enum |const |let |var |async function |export )",
            re.MULTILINE,
        )
    else:
        pattern = re.compile(base_pattern, re.MULTILINE)

    lines = text.split("\n")
    # Identify boundary line indices
    boundary_set: set[int] = set()
    for i, line in enumerate(lines):
        if pattern.match(line):
            boundary_set.add(i)

    # Group lines into segments starting at each boundary
    segments: list[list[str]] = []
    current: list[str] = []
    for i, line in enumerate(lines):
        if i in boundary_set and current:
            segments.append(current)
            current = [line]
        else:
            current.append(line)
    if current:
        segments.append(current)

    # Pack segments into chunks <= chunk_size tokens
    chunks: list[TextChunk] = []
    current_lines: list[str] = []
    current_tokens = 0
    line_cursor = 1

    def _flush_code(ln: list[str], idx: int, start_line: int) -> TextChunk:
        chunk_text = "\n".join(ln)
        return TextChunk(
            text=chunk_text,
            chunk_idx=idx,
            chunk_total=-1,
            heading_path=[],
            line_start=start_line,
            line_end=start_line + len(ln) - 1,
        )

    for seg in segments:
        seg_text = "\n".join(seg)
        seg_tokens = _token_count(seg_text)

        if current_lines and current_tokens + seg_tokens > chunk_size:
            chunks.append(_flush_code(current_lines, len(chunks), line_cursor))
            line_cursor += len(current_lines)
            current_lines = list(seg)
            current_tokens = seg_tokens
        else:
            current_lines.extend(seg)
            current_tokens += seg_tokens

    if current_lines:
        chunks.append(_flush_code(current_lines, len(chunks), line_cursor))

    # Fix chunk_total
    total = len(chunks)
    chunks = [
        TextChunk(
            text=c.text,
            chunk_idx=c.chunk_idx,
            chunk_total=total,
            heading_path=c.heading_path,
            line_start=c.line_start,
            line_end=c.line_end,
        )
        for c in chunks
    ]
    return chunks


def _find_chunk_boundaries(
    tokens_with_positions: list[tuple[str, int, int]],
    chunk_size: int,
    chunk_overlap: int,
) -> list[tuple[int, int]]:
    """
    Find chunk boundaries (start_idx, end_idx) for tokens.

    Args:
        tokens_with_positions: List of (token, line_start, line_end).
        chunk_size: Target chunk size in tokens.
        chunk_overlap: Number of tokens to overlap.

    Returns:
        List of (start_idx, end_idx) tuples for chunk boundaries.
    """
    if not tokens_with_positions:
        return []

    total_tokens = len(tokens_with_positions)
    boundaries: list[tuple[int, int]] = []

    current_start = 0
    while current_start < total_tokens:
        # Calculate end index
        current_end = min(current_start + chunk_size - 1, total_tokens - 1)

        boundaries.append((current_start, current_end))

        # Move start for next chunk with overlap
        current_start = current_end + 1 - chunk_overlap
        if current_start <= current_end:
            # Overlap is larger than moving forward, adjust
            current_start = current_end + 1

    return boundaries
