from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from raglocal.config import EmbedderConfig

_MANIFEST_FILENAME = "raglocal.manifest.json"

_REQUIRED_KEYS = {
    "raglocal_version",
    "embedder_provider",
    "embedder_model",
    "embedder_dim",
    "store_backend",
    "chunk_strategy",
    "created_at",
    "updated_at",
    "collections",
}


@dataclass(frozen=True)
class Manifest:
    raglocal_version: str
    embedder_provider: str  # "ollama" | "sentence-transformers"
    embedder_model: str
    embedder_dim: int
    store_backend: str  # always "lance" in v1
    chunk_strategy: str
    created_at: str  # ISO-8601 UTC
    updated_at: str  # ISO-8601 UTC
    collections: list[str] = field(default_factory=list)
    profile_name: str = "custom"  # e.g. "lean", "balanced", "powerful", "custom"

    def embedder_fingerprint(self) -> str:
        """Return short deterministic string: provider:model:dim."""
        return f"{self.embedder_provider}:{self.embedder_model}:{self.embedder_dim}"

    def write(self, path: Path) -> None:
        """Write manifest JSON to <path>/raglocal.manifest.json. Directory must exist."""
        if not path.is_dir():
            raise FileNotFoundError(f"Directory does not exist: {path}")
        manifest_path = path / _MANIFEST_FILENAME
        data = asdict(self)
        with open(manifest_path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)

    @classmethod
    def read(cls, path: Path) -> Manifest | None:
        """Return Manifest or None if file missing; raises ValueError if malformed."""
        manifest_path = path / _MANIFEST_FILENAME
        if not manifest_path.exists():
            return None
        try:
            with open(manifest_path, encoding="utf-8") as fh:
                data = json.load(fh)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Malformed JSON in manifest: {exc}") from exc

        if not isinstance(data, dict):
            raise ValueError("Manifest JSON must be a JSON object")

        missing = _REQUIRED_KEYS - data.keys()
        if missing:
            raise ValueError(f"Manifest is missing required keys: {sorted(missing)}")

        try:
            return cls(
                raglocal_version=str(data["raglocal_version"]),
                embedder_provider=str(data["embedder_provider"]),
                embedder_model=str(data["embedder_model"]),
                embedder_dim=int(data["embedder_dim"]),
                store_backend=str(data["store_backend"]),
                chunk_strategy=str(data["chunk_strategy"]),
                created_at=str(data["created_at"]),
                updated_at=str(data["updated_at"]),
                collections=list(data["collections"]),
                profile_name=str(data.get("profile_name", "custom")),
            )
        except (TypeError, KeyError) as exc:
            raise ValueError(f"Manifest has invalid field values: {exc}") from exc

    def validate_compat(self, other: Manifest) -> list[str]:
        """Return list of incompatibility reasons between self and other."""
        reasons: list[str] = []

        # Hard rule: embedder_dim must match exactly
        if self.embedder_dim != other.embedder_dim:
            reasons.append(
                f"embedder_dim mismatch: {self.embedder_dim} vs {other.embedder_dim}"
            )

        # Hard rule: embedder_model must match exactly
        if self.embedder_model != other.embedder_model:
            reasons.append(
                f"embedder_model mismatch: {self.embedder_model!r} vs {other.embedder_model!r}"
            )

        # Hard rule: major version must match
        self_major = _parse_major(self.raglocal_version)
        other_major = _parse_major(other.raglocal_version)
        if self_major != other_major:
            reasons.append(
                f"raglocal_version major mismatch: {self.raglocal_version!r} vs {other.raglocal_version!r}"
            )

        # Soft rule: chunk_strategy mismatch
        if self.chunk_strategy != other.chunk_strategy:
            reasons.append(
                f"warning: chunk_strategy mismatch: {self.chunk_strategy!r} vs {other.chunk_strategy!r}"
            )

        return reasons


def manifest_path_for_store(store_path: str | Path) -> Path:
    """Return the canonical manifest directory for a given LanceDB store path.

    The manifest lives one level up from the lance/ directory so it is
    shared across all collections in that data_dir.
    Returns Path(store_path).parent — callers pass this to Manifest.read/write.
    """
    return Path(store_path).parent


def is_embedder_compatible(
    manifest: Manifest,
    embedder_cfg: EmbedderConfig,
) -> tuple[bool, str]:
    """Return (compatible, reason). reason is empty string when compatible.

    If the manifest has empty embedder fields (legacy), returns True with an
    upgrade notice. Otherwise all three of provider/model/dim must match.
    """
    # Legacy manifest — all empty/zero defaults
    if not manifest.embedder_provider and not manifest.embedder_model and manifest.embedder_dim == 0:
        return True, "manifest predates embedder tracking; will be upgraded on next index"

    reasons: list[str] = []
    if manifest.embedder_provider != embedder_cfg.provider:
        reasons.append(
            f"provider: indexed={manifest.embedder_provider!r} configured={embedder_cfg.provider!r}"
        )
    if manifest.embedder_model != embedder_cfg.model:
        reasons.append(
            f"model: indexed={manifest.embedder_model!r} configured={embedder_cfg.model!r}"
        )
    if manifest.embedder_dim != embedder_cfg.dim:
        reasons.append(
            f"dim: indexed={manifest.embedder_dim} configured={embedder_cfg.dim}"
        )

    if reasons:
        return False, "; ".join(reasons)
    return True, ""


def _parse_major(version: str) -> int:
    """Return the major version component of a semver-like string."""
    try:
        return int(version.split(".")[0])
    except (ValueError, IndexError) as exc:
        raise ValueError(f"Cannot parse major version from {version!r}") from exc
