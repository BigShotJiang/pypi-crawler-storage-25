from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass

from raglocal.profiles import resolve_profile


@dataclass(frozen=True)
class ModelSpec:
    alias: str
    provider: str  # "ollama" | "anthropic" | "openai" | "gemini" | "groq"
    model: str


@dataclass(frozen=True)
class StoreConfig:
    backend: str  # always "lance" in v1
    path: str     # local directory for LanceDB


@dataclass(frozen=True)
class EmbedderConfig:
    profile: str          # "lean" | "balanced" | "powerful" | "custom"
    provider: str
    model: str
    host: str | None      # only for ollama; None for sentence-transformers
    dim: int
    cache_dir: str | None  # only for sentence-transformers


@dataclass(frozen=True)
class RerankerConfig:
    enabled: bool
    model: str


@dataclass(frozen=True)
class RetrievalConfig:
    top_n: int
    top_k: int
    hybrid_alpha: float


@dataclass(frozen=True)
class CollectionConfig:
    name: str
    chunk_size: int
    chunk_overlap: int
    chunk_strategy: str = "token"


@dataclass(frozen=True)
class Config:
    state_dir: str
    log_level: str
    store: StoreConfig
    embedder: EmbedderConfig
    reranker: RerankerConfig
    retrieval: RetrievalConfig
    models: dict[str, ModelSpec]  # alias → spec
    default_model: str
    default_collections: list[str]
    collections: dict[str, CollectionConfig]  # name → cfg


def _require(section: dict[str, object], key: str, section_name: str) -> str:
    """Raise ValueError if key is absent or value is an empty string."""
    value = section.get(key)
    if value is None or value == "":
        raise ValueError(f"Missing required config key: [{section_name}] {key}")
    return str(value)


def load_config(path: str | None = None) -> Config:
    if path is None:
        config_path = os.environ.get("RAGKIT_CONFIG")
        if config_path is None:
            config_path = os.path.expanduser("~/.config/raglocal/config.toml")
    else:
        config_path = os.path.expanduser(path)

    if not os.path.exists(config_path):
        raise FileNotFoundError(
            f"Config file not found at {config_path}. "
            "Please create it or specify a path via $RAGKIT_CONFIG. "
            "See config.toml.example for a template."
        )

    with open(config_path, "rb") as f:
        raw_config = tomllib.load(f)

    # Guard against legacy sections
    for legacy in ["qdrant", "chroma"]:
        if legacy in raw_config:
            raise ValueError(
                f"Config uses [{legacy}] which is no longer supported. "
                "Replace with [store] section. See config.toml.example."
            )

    # Parse sections
    core_cfg = raw_config.get("core", {})
    store_cfg = raw_config.get("store", {})
    embedder_cfg = raw_config.get("embedder", {})
    reranker_cfg = raw_config.get("reranker", {})
    retrieval_cfg = raw_config.get("retrieval", {})
    defaults_cfg = raw_config.get("defaults", {})

    # Expand user for state_dir
    state_dir = os.path.expanduser(_require(core_cfg, "state_dir", "core"))

    # [store] section — required
    store_backend = _require(store_cfg, "backend", "store")
    if store_backend != "lance":
        raise ValueError(
            f"[store] backend must be \"lance\" (got {store_backend!r})"
        )
    store_path = os.path.expanduser(_require(store_cfg, "path", "store"))
    store_config = StoreConfig(backend=store_backend, path=store_path)

    # [embedder] section — profile-aware
    profile = embedder_cfg.get("profile", "custom")

    if profile != "custom":
        resolved = resolve_profile(profile)
        # User keys win over profile defaults
        provider = embedder_cfg.get("provider", resolved.provider)
        model = embedder_cfg.get("model", resolved.model)
        dim = embedder_cfg.get("dim", resolved.dim)
        # host: for powerful profile default to ollama host; otherwise None
        if "host" in embedder_cfg:
            host: str | None = embedder_cfg["host"]
        elif profile == "powerful":
            host = "http://localhost:11434"
        else:
            host = None
    else:
        provider = _require(embedder_cfg, "provider", "embedder")
        model = _require(embedder_cfg, "model", "embedder")
        dim = embedder_cfg.get("dim", 0)
        host = embedder_cfg.get("host", None)

    cache_dir_raw = embedder_cfg.get("cache_dir", None)
    cache_dir: str | None = os.path.expanduser(cache_dir_raw) if cache_dir_raw else None

    embedder_config = EmbedderConfig(
        profile=profile,
        provider=provider,
        model=model,
        host=host,
        dim=dim,
        cache_dir=cache_dir,
    )

    reranker_config = RerankerConfig(
        enabled=reranker_cfg.get("enabled", False),
        model=reranker_cfg.get("model", ""),
    )
    retrieval_config = RetrievalConfig(
        top_n=retrieval_cfg.get("top_n", 0),
        top_k=retrieval_cfg.get("top_k", 0),
        hybrid_alpha=float(retrieval_cfg.get("hybrid_alpha", 0.0)),
    )

    models: dict[str, ModelSpec] = {}
    for alias, model_data in raw_config.get("models", {}).items():
        models[alias] = ModelSpec(
            alias=alias,
            provider=model_data.get("provider", ""),
            model=model_data.get("model", ""),
        )

    collections: dict[str, CollectionConfig] = {}
    for name, coll_data in raw_config.get("collections", {}).items():
        collections[name] = CollectionConfig(
            name=name,
            chunk_size=coll_data.get("chunk_size", 0),
            chunk_overlap=coll_data.get("chunk_overlap", 0),
            chunk_strategy=coll_data.get("chunk_strategy", "token"),
        )

    cfg = Config(
        state_dir=state_dir,
        log_level=core_cfg.get("log_level", "info"),
        store=store_config,
        embedder=embedder_config,
        reranker=reranker_config,
        retrieval=retrieval_config,
        models=models,
        default_model=defaults_cfg.get("model", ""),
        default_collections=defaults_cfg.get("collections", []),
        collections=collections,
    )

    # Validation
    if not cfg.embedder.dim > 0:
        raise ValueError("embedder.dim must be greater than 0")
    if not cfg.retrieval.top_n >= cfg.retrieval.top_k >= 1:
        raise ValueError("retrieval.top_n must be >= retrieval.top_k and both >= 1")
    if not (0.0 <= cfg.retrieval.hybrid_alpha <= 1.0):
        raise ValueError("retrieval.hybrid_alpha must be between 0.0 and 1.0")
    if cfg.default_model not in cfg.models:
        raise ValueError(f"default_model '{cfg.default_model}' not found in models")
    for col_name in cfg.default_collections:
        if col_name not in cfg.collections:
            raise ValueError(f"Default collection '{col_name}' not found in collections")

    return cfg
