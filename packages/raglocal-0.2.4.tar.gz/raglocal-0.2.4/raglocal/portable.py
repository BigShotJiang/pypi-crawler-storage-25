from __future__ import annotations

import json
import zipfile
from pathlib import Path
from typing import TYPE_CHECKING

from raglocal.manifest import Manifest, manifest_path_for_store

if TYPE_CHECKING:
    from raglocal.config import Config

RUN_SH_TEMPLATE = """\
#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
command -v python3 >/dev/null || { echo "Need Python 3.12+"; exit 1; }
if ! command -v rag >/dev/null; then
  echo "Installing raglocal..."
  python3 -m pip install --user 'raglocal[local-embed]'
fi
echo "Importing corpus to ~/.local/share/raglocal/lance ..."
rag import "$HERE/corpus.zip"
echo "Done. Try: rag mcp  (then point your AI tool at the MCP server)"
"""

CONFIG_TOML_TEMPLATE = """\
[store]
backend = "lance"
path = "~/.local/share/raglocal/lance"

[embedder]
profile = "{profile}"
# dim = {dim}
"""


def export_archive(cfg: Config, output: Path) -> None:
    """Export the corpus at cfg.store.path into a portable zip archive."""
    store_path = Path(cfg.store.path)
    manifest_dir = manifest_path_for_store(store_path)
    manifest_file = manifest_dir / "raglocal.manifest.json"

    if not manifest_file.exists():
        raise FileNotFoundError(
            f"No manifest found at {manifest_file}. "
            "Run 'rag index' first to create a corpus before exporting."
        )

    manifest = Manifest.read(manifest_dir)
    if manifest is None:
        raise FileNotFoundError(
            f"No manifest found at {manifest_file}. "
            "Run 'rag index' first to create a corpus before exporting."
        )

    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        # Walk all files under the store root and add under lance/ prefix
        for file_path in store_path.rglob("*"):
            if file_path.is_dir():
                continue
            relative = file_path.relative_to(store_path)
            arcname = "lance/" + str(relative)
            zf.write(file_path, arcname)

        # Add manifest at zip root
        zf.write(manifest_file, "raglocal.manifest.json")

        # Add run.sh with executable bit
        info = zipfile.ZipInfo("run.sh")
        info.external_attr = 0o755 << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        zf.writestr(info, RUN_SH_TEMPLATE)

        # Add config.toml.template rendered from manifest
        config_content = CONFIG_TOML_TEMPLATE.format(
            profile=manifest.profile_name,
            dim=manifest.embedder_dim,
        )
        zf.writestr("config.toml.template", config_content)


def import_archive(archive: Path, target_path: Path) -> Manifest:
    """Import a portable corpus archive into target_path."""
    with zipfile.ZipFile(archive, "r") as zf:
        # Read manifest from zip
        try:
            content = zf.read("raglocal.manifest.json")
        except KeyError as e:
            raise ValueError("Malformed manifest in archive: missing raglocal.manifest.json") from e

        try:
            data = json.loads(content)
            manifest = Manifest(**data)
        except Exception as e:
            raise ValueError(f"Malformed manifest in archive: {e}") from e

        # Check existing manifest compatibility
        existing_manifest_dir = manifest_path_for_store(target_path)
        existing_manifest_file = existing_manifest_dir / "raglocal.manifest.json"
        if existing_manifest_file.exists():
            existing = Manifest.read(existing_manifest_dir)
            if existing is not None:
                reasons = existing.validate_compat(manifest)
                hard_errors = [r for r in reasons if not r.startswith("warning:")]
                if hard_errors:
                    raise ValueError("Archive incompatible: " + "; ".join(hard_errors))

        # Extract lance/ members
        for member in zf.infolist():
            if not member.filename.startswith("lance/"):
                continue
            stripped = member.filename[len("lance/"):]
            if not stripped:
                # Skip the bare "lance/" directory entry if present
                continue
            dest = target_path / stripped
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(zf.read(member.filename))

    # Write manifest to manifest_dir (one level up from lance store)
    manifest_dir = manifest_path_for_store(target_path)
    manifest_dir.mkdir(parents=True, exist_ok=True)
    manifest.write(manifest_dir)

    return manifest
