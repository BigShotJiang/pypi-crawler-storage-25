"""raglocal CLI: init, index, stats, export, import, debug, mcp, ingest, ask, models, collections, doctor."""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from typing import Any

import typer
from rich.console import Console
from rich.table import Table

from raglocal.config import Config, load_config
from raglocal.embed import build_embedder
from raglocal.index import index_paths
from raglocal.manifest import Manifest, is_embedder_compatible, manifest_path_for_store
from raglocal.portable import export_archive, import_archive
from raglocal.retrieve import Retriever
from raglocal.state import StateStore
from raglocal.store import LanceStore

# ---------------------------------------------------------------------------
# Typer app
# ---------------------------------------------------------------------------

app = typer.Typer(
    name="rag",
    help="Local-first, provider-agnostic RAG toolkit.",
)
console = Console()

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_CONFIG_PATH = Path("~/.config/raglocal/config.toml").expanduser()
# Patchable reference used by init (allows tests to override the target path)
_RAGKIT_CONFIG_FILE: Path = _CONFIG_PATH


def _load_services(cfg: Config) -> tuple[Any, LanceStore, StateStore]:
    """Load core services from config and attach existing collections."""
    embedder = _build_embedder(cfg)
    store = LanceStore(cfg.store.path)
    # Reattach to any on-disk collection that's also defined in config so
    # callers (debug, mcp, stats) can search without first calling ensure_collection.
    try:
        resp = store._db.list_tables()
        existing = set(resp.tables or []) if hasattr(resp, "tables") else set(resp)
    except Exception:
        existing = set()
    for coll_name in cfg.collections:
        if coll_name in existing:
            store.ensure_collection(coll_name, cfg.embedder.dim)
    state = StateStore(str(Path(cfg.state_dir) / "state.db"))
    return embedder, store, state


def _build_embedder(cfg: Config) -> Any:
    """Build an embedder from config."""
    return build_embedder(cfg)


def _check_embedder_compat(cfg: Config, *, warn_only: bool = False) -> None:
    """Check on-disk manifest against current embedder config.

    Raises SystemExit(4) if mismatch detected (unless warn_only=True, which
    prints a WARNING instead). No-op if no manifest exists yet.
    """
    manifest_dir = manifest_path_for_store(cfg.store.path)
    manifest = Manifest.read(manifest_dir)
    if manifest is None:
        return

    compatible, reason = is_embedder_compatible(manifest, cfg.embedder)
    if compatible:
        return

    indexed_fp = manifest.embedder_fingerprint()
    configured_fp = f"{cfg.embedder.provider}:{cfg.embedder.model}:{cfg.embedder.dim}"
    msg = (
        f"Embedder mismatch detected.\n"
        f"Indexed with: {indexed_fp}  (profile: {manifest.profile_name})\n"
        f"Configured:   {configured_fp}  (profile: {cfg.embedder.profile})\n\n"
        f"Run `rag reindex` to rebuild the index with the new embedder, or revert\n"
        f"the [embedder] section in your config.toml."
    )
    if warn_only:
        console.print(f"[yellow]WARNING: {msg}[/yellow]")
    else:
        console.print(f"[red]{msg}[/red]")
        raise SystemExit(4)


def _write_manifest(cfg: Config) -> None:
    """Write/update manifest with current embedder fingerprint."""
    import datetime

    manifest_dir = manifest_path_for_store(cfg.store.path)
    manifest_dir.mkdir(parents=True, exist_ok=True)

    existing = Manifest.read(manifest_dir)
    now = datetime.datetime.now(datetime.UTC).strftime("%Y-%m-%dT%H:%M:%SZ")

    try:
        from importlib.metadata import version as pkg_version
        raglocal_ver = pkg_version("raglocal")
    except Exception:
        raglocal_ver = "dev"

    if existing is not None:
        # Preserve created_at; update everything else
        updated = Manifest(
            raglocal_version=raglocal_ver,
            embedder_provider=cfg.embedder.provider,
            embedder_model=cfg.embedder.model,
            embedder_dim=cfg.embedder.dim,
            store_backend=cfg.store.backend,
            chunk_strategy="token",
            created_at=existing.created_at,
            updated_at=now,
            collections=existing.collections,
            profile_name=cfg.embedder.profile,
        )
    else:
        updated = Manifest(
            raglocal_version=raglocal_ver,
            embedder_provider=cfg.embedder.provider,
            embedder_model=cfg.embedder.model,
            embedder_dim=cfg.embedder.dim,
            store_backend=cfg.store.backend,
            chunk_strategy="token",
            created_at=now,
            updated_at=now,
            collections=[],
            profile_name=cfg.embedder.profile,
        )

    updated.write(manifest_dir)


# ---------------------------------------------------------------------------
# B5: --version callback
# ---------------------------------------------------------------------------


def version_callback(value: bool) -> None:
    if value:
        try:
            from importlib.metadata import PackageNotFoundError, version

            v = version("raglocal")
        except PackageNotFoundError:
            v = "dev"
        console.print(f"raglocal {v}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        False,
        "--version",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit",
    ),
    ctx: typer.Context = typer.Option(None, hidden=True),  # noqa: B008
) -> None:
    # First-run UX: if config is missing and the subcommand is not init, warn
    if ctx is not None:
        invoked = ctx.invoked_subcommand
        if invoked != "init" and not _CONFIG_PATH.exists():
            Console(stderr=True).print(
                "[yellow]No config found. Run 'rag init' to set up raglocal.[/yellow]"
            )


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


@app.command()
def init(
    non_interactive: bool = typer.Option(False, "--non-interactive", help="Skip all prompts"),
    profile: str = typer.Option("balanced", help="Profile: lean | balanced | powerful"),
    path: str = typer.Option("~/.local/share/raglocal", help="Data directory"),
    force: bool = typer.Option(False, "--force", help="Overwrite existing config"),
) -> None:
    """Interactive setup wizard — creates ~/.config/raglocal/config.toml."""
    import raglocal.cli as _cli_module
    from raglocal.profiles import _PROFILES, resolve_profile

    config_file: Path = _cli_module._RAGKIT_CONFIG_FILE

    # Guard: config already exists
    if config_file.exists() and not force:
        console.print(
            f"[red]Config already exists at {config_file}. Use --force to overwrite.[/red]"
        )
        sys.exit(1)

    if non_interactive:
        chosen_profile = profile
        data_path = Path(path).expanduser()
    else:
        # Welcome banner
        console.print(
            "\n[bold cyan]Welcome to raglocal — MCP-first local knowledge search[/bold cyan]\n"
        )

        # Show profile choices
        console.print("[bold]Choose an embedding profile:[/bold]")
        profile_names = ["lean", "balanced", "powerful"]
        for idx, pname in enumerate(profile_names, 1):
            p = _PROFILES[pname]
            marker = " [yellow](recommended)[/yellow]" if pname == "balanced" else ""
            console.print(
                f"  {idx}. [cyan]{p.display_name}[/cyan]{marker}"
                f" — {p.description}"
                f" (disk: {p.disk_mb} MB, RAM: {p.ram_mb} MB)"
            )

        raw = typer.prompt("\nSelect profile (1/2/3)", default="2")
        try:
            idx = int(raw) - 1
            if idx not in range(3):
                raise ValueError
            chosen_profile = profile_names[idx]
        except (ValueError, IndexError):
            console.print("[red]Invalid selection. Defaulting to 'balanced'.[/red]")
            chosen_profile = "balanced"

        # Powerful: check Ollama reachability
        if chosen_profile == "powerful":
            try:
                import httpx
                httpx.get("http://localhost:11434/api/tags", timeout=2)
            except Exception:
                console.print(
                    "[yellow]Warning: Ollama not reachable at http://localhost:11434. "
                    "Falling back to 'balanced'.[/yellow]"
                )
                chosen_profile = "balanced"

        # Lean / balanced: check sentence_transformers available
        if chosen_profile in ("lean", "balanced"):
            try:
                import sentence_transformers  # noqa: F401
            except ImportError as exc:
                console.print(
                    "[red]sentence-transformers is not installed.\n"
                    "Install it with: pip install raglocal[local-embed][/red]"
                )
                raise SystemExit(1) from exc

        # Data directory prompt
        raw_path = typer.prompt(
            "Data directory", default="~/.local/share/raglocal"
        )
        data_path = Path(raw_path).expanduser()

    # Validate profile
    if chosen_profile not in ("lean", "balanced", "powerful"):
        console.print(f"[red]Unknown profile '{chosen_profile}'. Use: lean, balanced, powerful[/red]")
        sys.exit(1)

    resolved = resolve_profile(chosen_profile)

    # Build config TOML
    collections_toml = """\
[collections.code]
name = "code"
chunk_size = 500
chunk_overlap = 50

[collections.docs]
name = "docs"
chunk_size = 800
chunk_overlap = 100

[collections.journal]
name = "journal"
chunk_size = 512
chunk_overlap = 64

[collections.books]
name = "books"
chunk_size = 1024
chunk_overlap = 128
"""

    provider_line = f'provider = "{resolved.provider}"'
    model_line = f'model = "{resolved.model}"'
    host_line = 'host = "http://localhost:11434"' if resolved.provider == "ollama" else ""
    dim_line = f"dim = {resolved.dim}"

    embedder_section_lines = [
        f'profile = "{chosen_profile}"',
        provider_line,
        model_line,
        dim_line,
    ]
    if host_line:
        embedder_section_lines.append(host_line)
    embedder_section = "\n".join(embedder_section_lines)

    lance_path = str(data_path / "lance")
    state_dir_path = str(data_path)

    config_toml = f"""\
[core]
state_dir = "{state_dir_path}"
log_level = "info"

[store]
backend = "lance"
path = "{lance_path}"

[embedder]
{embedder_section}

[reranker]
enabled = false
model = "bge-reranker-v2-m3"

[retrieval]
top_n = 20
top_k = 5
hybrid_alpha = 0.5

[defaults]
model = "smart"
collections = ["docs"]

[models.smart]
provider = "ollama"
model = "qwen3:32b"

[models.fast]
provider = "ollama"
model = "phi4:latest"

{collections_toml}"""

    # Write config
    config_file.parent.mkdir(parents=True, exist_ok=True)
    config_file.write_text(config_toml)

    console.print(f"\n[green]Config written to {config_file}[/green]")
    console.print(f"[green]Profile: {chosen_profile} ({resolved.model})[/green]")
    console.print(f"[green]Data directory: {data_path}[/green]")


@app.command()
def index(
    paths: list[str] = typer.Argument(..., help="Paths to index"),  # noqa: B008
    collection: str | None = typer.Option(None, help="Collection name"),
    reindex: bool = typer.Option(False, help="Force reindex, skip fresh files"),
    config: str | None = typer.Option(None, help="Path to config TOML"),
) -> None:
    """Index paths into the RAG store."""
    try:
        cfg = load_config(config)
    except FileNotFoundError as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(2)
    except ValueError as e:
        console.print(f"[red]Config error: {e}[/red]")
        sys.exit(2)

    _check_embedder_compat(cfg)

    try:
        embedder, store, state = _load_services(cfg)
    except Exception as e:
        console.print(f"[red]Cannot connect to services: {e}[/red]")
        sys.exit(3)

    try:
        report = asyncio.run(
            index_paths(cfg, embedder, store, state, paths, reindex=reindex, collection=collection)
        )
        console.print(
            f"Indexed {report.indexed} chunks, skipped {report.skipped}"
        )
        if report.errors:
            console.print("\n[yellow]Errors:[/yellow]")
            for err in report.errors:
                console.print(f"  {err}")
        _write_manifest(cfg)
    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]Index failed: {e}[/red]")
        sys.exit(1)
    finally:
        if hasattr(embedder, "aclose"):
            asyncio.run(embedder.aclose())
        state.close()


@app.command()
def stats(
    config: str | None = typer.Option(None, help="Path to config TOML"),
) -> None:
    """Show chunk counts and last indexed time per collection."""
    try:
        cfg = load_config(config)
    except FileNotFoundError as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(2)
    except ValueError as e:
        console.print(f"[red]Config error: {e}[/red]")
        sys.exit(2)

    _check_embedder_compat(cfg, warn_only=True)

    try:
        store = LanceStore(cfg.store.path)
    except Exception as e:
        console.print(f"[red]Cannot open LanceDB store: {e}[/red]")
        sys.exit(3)

    state = StateStore(str(Path(cfg.state_dir) / "state.db"))

    table = Table(title="Stats")
    table.add_column("Collection", style="cyan")
    table.add_column("Chunks", style="green")
    table.add_column("Last Indexed", style="magenta")

    for coll_name in sorted(cfg.collections.keys()):
        try:
            store.ensure_collection(coll_name, cfg.embedder.dim)
            count = store.count(coll_name)
        except Exception as e:
            count_str = f"[red]Error: {e}[/red]"
            table.add_row(coll_name, count_str, "unknown")
            continue

        # Get last indexed time from state store
        records = state.list_by_collection(coll_name)
        if records:
            import datetime
            latest = max(int(str(r.get("indexed_at") or 0)) for r in records)
            last_indexed = datetime.datetime.fromtimestamp(latest).strftime("%Y-%m-%d %H:%M")
        else:
            last_indexed = "never"

        table.add_row(coll_name, str(count), last_indexed)

    state.close()
    console.print(table)


@app.command("mcp")
def mcp(
    config: str | None = typer.Option(None, help="Path to config TOML"),
) -> None:
    """Start the MCP stdio server (alias for serve-mcp)."""
    _serve_mcp_impl(config)


@app.command("serve-mcp")
def serve_mcp(
    config: str | None = typer.Option(None, help="Path to config TOML"),
) -> None:
    """Start the MCP stdio server (JSON-RPC 2.0) for use with OpenCode.

    Add to your OpenCode config::

        {
          "mcp": {
            "raglocal": {
              "command": "rag",
              "args": ["serve-mcp"],
              "type": "stdio"
            }
          }
        }
    """
    _serve_mcp_impl(config)


def _serve_mcp_impl(config: str | None) -> None:
    """Shared implementation for mcp / serve-mcp."""
    # B4: use stderr-only console so we never corrupt the JSON-RPC stdout stream
    err_console = Console(stderr=True)
    try:
        cfg = load_config(config)
    except FileNotFoundError as e:
        err_console.print(f"[red]Error: {e}[/red]")
        sys.exit(2)
    except ValueError as e:
        err_console.print(f"[red]Config error: {e}[/red]")
        sys.exit(2)

    _check_embedder_compat(cfg)

    from raglocal.mcp_server import run

    run(cfg)


@app.command()
def export(
    output_zip: str = typer.Argument(..., help="Output zip file path"),
    config: str | None = typer.Option(None, help="Path to config TOML"),
) -> None:
    """Export the corpus to a portable zip archive."""
    try:
        cfg = load_config(config)
    except FileNotFoundError as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(2)
    except ValueError as e:
        console.print(f"[red]Config error: {e}[/red]")
        sys.exit(2)

    try:
        export_archive(cfg, Path(output_zip))
        console.print(f"[green]Exported corpus to {output_zip}[/green]")
    except Exception as e:
        console.print(f"[red]Export failed: {e}[/red]")
        sys.exit(1)


@app.command("import")
def import_cmd(
    input_zip: str = typer.Argument(..., help="Input zip file path"),
    path: str | None = typer.Option(None, help="Target path (defaults to cfg.store.path)"),
    config: str | None = typer.Option(None, help="Path to config TOML"),
) -> None:
    """Import a portable corpus archive."""
    try:
        cfg = load_config(config)
    except FileNotFoundError as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(2)
    except ValueError as e:
        console.print(f"[red]Config error: {e}[/red]")
        sys.exit(2)

    target_path = Path(path).expanduser() if path else Path(cfg.store.path)

    try:
        manifest = import_archive(Path(input_zip), target_path)
        console.print(f"[green]Imported corpus from {input_zip}[/green]")
        console.print(f"  Embedder model: {manifest.embedder_model}")
        console.print(f"  Collections: {', '.join(manifest.collections)}")
    except Exception as e:
        console.print(f"[red]Import failed: {e}[/red]")
        sys.exit(1)


@app.command()
def debug(
    query: str = typer.Argument(..., help="Query to search"),
    config: str | None = typer.Option(None, help="Path to config TOML"),
) -> None:
    """Debug search — pretty-print results to stderr."""
    err_console = Console(stderr=True)

    try:
        cfg = load_config(config)
    except FileNotFoundError as e:
        err_console.print(f"[red]Error: {e}[/red]")
        sys.exit(2)
    except ValueError as e:
        err_console.print(f"[red]Config error: {e}[/red]")
        sys.exit(2)

    _check_embedder_compat(cfg)

    try:
        embedder, store, _ = _load_services(cfg)
    except Exception as e:
        err_console.print(f"[red]Cannot connect to services: {e}[/red]")
        sys.exit(3)

    retriever = Retriever(embedder, store, cfg)

    async def _run() -> None:
        ctx = await retriever.retrieve(query, cfg.default_collections)
        if not ctx.results:
            err_console.print("[yellow]No results found.[/yellow]")
            return
        err_console.print(f"\n[bold]Results for:[/bold] {query}\n")
        for i, r in enumerate(ctx.results, 1):
            source_uri = r.payload.get("source_uri", "unknown")
            err_console.print(f"[{i}] score={r.score:.4f}  {source_uri}")
            err_console.print(f"    {r.text[:200]!r}")
            err_console.print()

    try:
        asyncio.run(_run())
    except Exception as e:
        err_console.print(f"[red]Debug failed: {e}[/red]")
        sys.exit(1)


@app.command()
def models(config: str | None = typer.Option(None, help="Path to config TOML")) -> None:
    """List configured model aliases and their backing models."""
    try:
        cfg = load_config(config)
    except FileNotFoundError as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(2)
    except ValueError as e:
        console.print(f"[red]Config error: {e}[/red]")
        sys.exit(2)

    table = Table(title="Models")
    table.add_column("Alias", style="cyan")
    table.add_column("Provider", style="magenta")
    table.add_column("Model", style="green")

    for alias in sorted(cfg.models.keys()):
        spec = cfg.models[alias]
        table.add_row(alias, spec.provider, spec.model)

    console.print(table)


@app.command()
def collections(config: str | None = typer.Option(None, help="Path to config TOML")) -> None:
    """List collections and their chunk counts."""
    try:
        cfg = load_config(config)
    except FileNotFoundError as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(2)
    except ValueError as e:
        console.print(f"[red]Config error: {e}[/red]")
        sys.exit(2)

    try:
        store = LanceStore(cfg.store.path)
    except Exception as e:
        console.print(f"[red]Cannot open LanceDB store: {e}[/red]")
        sys.exit(3)

    table = Table(title="Collections")
    table.add_column("Name", style="cyan")
    table.add_column("Points", style="green")

    for coll_name in sorted(cfg.collections.keys()):
        try:
            count = store.count(coll_name)
            table.add_row(coll_name, str(count))
        except Exception as e:
            table.add_row(coll_name, f"[red]Error: {e}[/red]")

    console.print(table)


@app.command()
def doctor(config: str | None = typer.Option(None, help="Path to config TOML")) -> None:
    """Health check: config loads, LanceDB up, Ollama up, default model reachable."""
    # Check 1: config loads
    try:
        cfg = load_config(config)
        console.print("[green]✓[/green] Config loads successfully")
    except FileNotFoundError as e:
        console.print(f"[red]✗ Config not found: {e}[/red]")
        sys.exit(2)
    except ValueError as e:
        console.print(f"[red]✗ Config validation error: {e}[/red]")
        sys.exit(2)

    # Check 2: LanceDB
    try:
        store = LanceStore(cfg.store.path)
        # B6: don't fail if the collection doesn't exist yet; it just means it's empty
        try:
            _ = store.count("docs")
            console.print("[green]✓[/green] LanceDB store is accessible")
        except Exception:
            console.print("[green]✓[/green] LanceDB store is accessible (empty)")
    except Exception as e:
        console.print(f"[red]✗ LanceDB store error: {e}[/red]")
        sys.exit(3)

    # Check 3: Ollama reachability + embedder model check (B3)
    if cfg.embedder.provider == "ollama":
        try:
            import httpx

            with httpx.Client(timeout=5.0) as client:
                resp = client.get(f"{cfg.embedder.host}/api/tags")
                if resp.status_code == 200:
                    console.print("[green]✓[/green] Ollama is reachable")
                    # B3: check that the embedder model is pulled
                    try:
                        data = resp.json()
                        pulled = data.get("models", [])
                        # Only check when we got a real list back
                        if isinstance(pulled, list) and pulled:
                            pulled_names = [
                                m.get("name", "") for m in pulled if isinstance(m, dict)
                            ]
                            model_name = cfg.embedder.model
                            model_pulled = any(
                                isinstance(n, str) and n.startswith(model_name)
                                for n in pulled_names
                            )
                            if model_pulled:
                                console.print(
                                    f"[green]✓[/green] Embedder model '{model_name}' is pulled"
                                )
                            else:
                                console.print(
                                    f"[red]✗ Embedder model '{model_name}' not pulled"
                                    f" — run: ollama pull {model_name}[/red]"
                                )
                                sys.exit(3)
                    except Exception:
                        pass  # Can't parse model list; skip check
                else:
                    console.print(f"[red]✗ Ollama returned {resp.status_code}[/red]")
                    sys.exit(3)
        except Exception as e:
            console.print(f"[red]✗ Ollama unreachable: {e}[/red]")
            sys.exit(3)
    else:
        console.print(
            f"[dim]- Ollama check skipped (embedder.provider={cfg.embedder.provider!r})[/dim]"
        )

    # Check 4: default model config is resolvable
    default_model = cfg.default_model
    if default_model in cfg.models:
        console.print(f"[green]✓[/green] Default model '{default_model}' is configured")
    else:
        console.print(f"[red]✗ Default model '{default_model}' not found in config[/red]")
        sys.exit(1)

    console.print("\n[green bold]All checks passed![/green bold]")


@app.command()
def reindex(
    collection: str | None = typer.Option(None, help="Re-index only this collection"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
    config: str | None = typer.Option(None, help="Path to config TOML"),
) -> None:
    """Drop and re-embed all (or one) collection using the current embedder."""
    try:
        cfg = load_config(config)
    except FileNotFoundError as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(2)
    except ValueError as e:
        console.print(f"[red]Config error: {e}[/red]")
        sys.exit(2)

    try:
        embedder, store, state = _load_services(cfg)
    except Exception as e:
        console.print(f"[red]Cannot connect to services: {e}[/red]")
        sys.exit(3)

    try:
        all_records = state.list_all()
    except Exception as e:
        console.print(f"[red]Cannot read state.db: {e}[/red]")
        sys.exit(1)

    if not all_records:
        console.print(
            "[red]No source paths tracked in state.db. "
            "Run `rag index <paths>` manually with the new embedder.[/red]"
        )
        sys.exit(1)

    # Filter by collection if requested
    if collection is not None:
        records = [r for r in all_records if r.get("collection") == collection]
        if not records:
            console.print(f"[red]No records found for collection '{collection}'.[/red]")
            sys.exit(1)
        target_collections = [collection]
    else:
        records = all_records
        target_collections = sorted({str(r["collection"]) for r in records})

    # Group source paths by collection
    coll_sources: dict[str, list[str]] = {}
    for r in records:
        col = str(r["collection"])
        src = str(r["source_uri"])
        coll_sources.setdefault(col, []).append(src)

    total_files = len({str(r["source_uri"]) for r in records})
    console.print(
        f"Will drop and re-embed {total_files} source file(s) "
        f"across {len(target_collections)} collection(s): {', '.join(target_collections)}"
    )

    if not yes:
        confirm = typer.prompt("Continue? [y/N]", default="n")
        if confirm.strip().lower() not in ("y", "yes"):
            console.print("Aborted.")
            sys.exit(0)

    # Drop collections and clear state
    for col in target_collections:
        console.print(f"  Dropping collection '{col}'...")
        store.drop_collection(col)
        state.forget_collection(col)

    # Convert file:// URIs back to paths and re-index per collection
    from urllib.parse import urlparse

    total_report_indexed = 0
    total_report_errors: list[str] = []

    for col in target_collections:
        sources = coll_sources.get(col, [])
        paths_for_col: list[str] = []
        for src in sources:
            parsed = urlparse(src)
            if parsed.scheme == "file":
                paths_for_col.append(parsed.path)
            else:
                paths_for_col.append(src)

        if not paths_for_col:
            continue

        console.print(f"  Re-indexing collection '{col}' ({len(paths_for_col)} files)...")
        try:
            report = asyncio.run(
                index_paths(cfg, embedder, store, state, paths_for_col,
                            reindex=True, collection=col)
            )
            total_report_indexed += report.indexed
            total_report_errors.extend(report.errors)
        except Exception as e:
            console.print(f"[red]  Failed re-indexing '{col}': {e}[/red]")
            total_report_errors.append(f"{col}: {e}")

    _write_manifest(cfg)

    console.print(
        f"\n[green]Reindex complete.[/green] "
        f"Indexed {total_report_indexed} chunks."
    )
    if total_report_errors:
        console.print("\n[yellow]Errors:[/yellow]")
        for err in total_report_errors:
            console.print(f"  {err}")

    if hasattr(embedder, "aclose"):
        asyncio.run(embedder.aclose())
    state.close()


if __name__ == "__main__":
    app()
