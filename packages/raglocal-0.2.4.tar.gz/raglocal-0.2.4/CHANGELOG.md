# Changelog

All notable changes to this project will be documented in this file.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [0.2.0] - 2026-04-27

### Fixed
- `expand` MCP tool now correctly resolves chunks by ID and neighbouring context — filter keys `id`, `chunk_idx`, `source_uri`, and `language` were silently ignored before, causing unfiltered table scans and wrong results
- Reranker replaced broken `embedding[0]` score (first float of an embedding vector) with proper cosine similarity between query and passage embeddings
- Portable export/import: manifest was read from the wrong path; generated `config.toml` used provider name instead of profile name
- `rag doctor` no longer fails for users using the `sentence-transformers` embedder who do not run Ollama
- All parsers now respect `chunk_size` and `chunk_overlap` from `config.toml` per-collection config (previously hardcoded in each parser)
- `_strip_frontmatter` and `_extract_first_h1` deduplicated — moved to `raglocal/parsers/base.py`

### Changed
- CLI entry point moved to `raglocal/cli.py` so the wheel is self-contained; entry point updated to `raglocal.cli:app`
- `__version__` now sourced dynamically from package metadata via `importlib.metadata` — single source of truth
- `build_embedder()` consolidated into `raglocal.embed` — no longer duplicated across `cli.py` and `mcp_server.py`
- `CollectionConfig.chunk_size` / `chunk_overlap` are now threaded into all parser calls from `index.py`
- Added `[collections.sessions]` block to `config.toml.example`

### Removed
- `rag-bench` PyPI entry point removed (it referenced `tests/` which is not shipped in the wheel); run benchmarks with `uv run python tests/bench.py`
- Dead `raglocal/ingest/` empty directory removed
- `WAVE8.md` internal planning artifact removed

## [0.1.0] - 2026-04-20

Initial public release.
