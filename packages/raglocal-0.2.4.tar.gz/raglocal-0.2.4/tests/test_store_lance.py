"""Tests for LanceStore in raglocal.store."""

from __future__ import annotations

import asyncio
import random

import pytest

from raglocal.store import Chunk, LanceStore, SearchResult

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

DIM = 4


def _make_chunk(
    source_uri: str = "file:///test.py",
    chunk_idx: int = 0,
    text: str = "hello world",
    source_type: str = "code",
    mtime: int = 1700000000,
    tags: list[str] | None = None,
) -> Chunk:
    return Chunk(
        text=text,
        source_uri=source_uri,
        source_type=source_type,
        collection="test",
        chunk_idx=chunk_idx,
        chunk_total=1,
        heading_path=[],
        line_start=1,
        line_end=10,
        mtime=mtime,
        content_hash="abc",
        tags=tags or [],
        extra=None,
    )


def _make_vector(dim: int = DIM) -> list[float]:
    return [random.random() for _ in range(dim)]


def _run(coro):  # type: ignore[no-untyped-def]
    """Run an async coroutine synchronously."""
    return asyncio.run(coro)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_smoke(tmp_path: pytest.MonkeyPatch) -> None:
    """Create LanceStore, upsert, search, count, delete_by_source."""
    store = LanceStore(str(tmp_path / "db"))
    store.ensure_collection("test", dim=DIM, with_sparse=False)

    chunks = [_make_chunk(chunk_idx=i, text=f"chunk {i}") for i in range(3)]
    vectors = [_make_vector() for _ in range(3)]

    _run(store.upsert("test", vectors, chunks))

    assert store.count("test") == 3

    results = _run(store.search("test", _make_vector(), top_n=5))
    assert len(results) > 0

    store.delete_by_source("test", "file:///test.py")
    assert store.count("test") == 0


def test_fts_enabled(tmp_path: pytest.MonkeyPatch) -> None:
    """with_sparse=True should attempt FTS (or gracefully fall back)."""
    store = LanceStore(str(tmp_path / "db"))
    # Should not raise regardless of whether FTS index actually succeeds
    store.ensure_collection("test", dim=DIM, with_sparse=True)
    assert "test" in store._fts_enabled  # type: ignore[attr-defined]


def test_fts_disabled(tmp_path: pytest.MonkeyPatch) -> None:
    """with_sparse=False should not attempt FTS."""
    store = LanceStore(str(tmp_path / "db"))
    store.ensure_collection("test", dim=DIM, with_sparse=False)
    assert store._fts_enabled.get("test") is False  # type: ignore[attr-defined]


def test_hybrid_fallback(tmp_path: pytest.MonkeyPatch) -> None:
    """When FTS disabled, hybrid_search falls back to vector + bm25."""
    store = LanceStore(str(tmp_path / "db"))
    store.ensure_collection("test", dim=DIM, with_sparse=False)

    chunks = [_make_chunk(chunk_idx=i, text=f"alpha beta gamma {i}") for i in range(3)]
    vectors = [_make_vector() for _ in range(3)]
    _run(store.upsert("test", vectors, chunks))

    results = _run(store.hybrid_search("test", _make_vector(), "alpha beta", top_n=5))
    assert len(results) > 0
    assert all(isinstance(r, SearchResult) for r in results)


def test_filter_source_type(tmp_path: pytest.MonkeyPatch) -> None:
    """Filter by source_type returns only matching docs."""
    store = LanceStore(str(tmp_path / "db"))
    store.ensure_collection("test", dim=DIM, with_sparse=False)

    chunks = [
        _make_chunk(source_uri="file:///a.md", chunk_idx=0, source_type="md"),
        _make_chunk(source_uri="file:///b.py", chunk_idx=0, source_type="py"),
    ]
    vectors = [_make_vector(), _make_vector()]
    _run(store.upsert("test", vectors, chunks))

    results = _run(
        store.search("test", _make_vector(), top_n=5, filters={"source_type": "md"})
    )
    assert len(results) > 0
    assert all(r.payload.get("source_type") == "md" for r in results)


def test_filter_mtime(tmp_path: pytest.MonkeyPatch) -> None:
    """Filter by mtime_gte excludes older documents."""
    store = LanceStore(str(tmp_path / "db"))
    store.ensure_collection("test", dim=DIM, with_sparse=False)

    chunks = [
        _make_chunk(source_uri="file:///old.py", chunk_idx=0, mtime=1000),
        _make_chunk(source_uri="file:///new.py", chunk_idx=0, mtime=2000),
    ]
    vectors = [_make_vector(), _make_vector()]
    _run(store.upsert("test", vectors, chunks))

    results = _run(
        store.search("test", _make_vector(), top_n=5, filters={"mtime_gte": 1500})
    )
    assert len(results) > 0
    assert all(r.payload.get("mtime", 0) >= 1500 for r in results)


def test_persistence(tmp_path: pytest.MonkeyPatch) -> None:
    """Data survives across LanceStore instances (persistence check)."""
    db_path = str(tmp_path / "db")

    store1 = LanceStore(db_path)
    store1.ensure_collection("test", dim=DIM, with_sparse=False)
    chunks = [_make_chunk(chunk_idx=i) for i in range(3)]
    vectors = [_make_vector() for _ in range(3)]
    _run(store1.upsert("test", vectors, chunks))
    del store1

    store2 = LanceStore(db_path)
    store2.ensure_collection("test", dim=DIM, with_sparse=False)
    assert store2.count("test") == 3


def test_no_duplicate_upsert(tmp_path: pytest.MonkeyPatch) -> None:
    """Upserting the same chunks twice should not increase count."""
    store = LanceStore(str(tmp_path / "db"))
    store.ensure_collection("test", dim=DIM, with_sparse=False)

    chunks = [_make_chunk(chunk_idx=i) for i in range(3)]
    vectors = [_make_vector() for _ in range(3)]

    _run(store.upsert("test", vectors, chunks))
    assert store.count("test") == 3

    # Upsert again with same IDs
    _run(store.upsert("test", vectors, chunks))
    assert store.count("test") == 3


def test_search_returns_search_results(tmp_path: pytest.MonkeyPatch) -> None:
    """Results are SearchResult instances with score and chunk fields."""
    store = LanceStore(str(tmp_path / "db"))
    store.ensure_collection("test", dim=DIM, with_sparse=False)

    chunks = [_make_chunk(chunk_idx=0, text="hello world")]
    vectors = [[0.1] * DIM]
    _run(store.upsert("test", vectors, chunks))

    results = _run(store.search("test", [0.1] * DIM, top_n=5))
    assert len(results) > 0
    r = results[0]
    assert isinstance(r, SearchResult)
    assert isinstance(r.score, float)
    assert isinstance(r.text, str)
    assert isinstance(r.payload, dict)


def test_ensure_collection_idempotent(tmp_path: pytest.MonkeyPatch) -> None:
    """Calling ensure_collection twice should not raise."""
    store = LanceStore(str(tmp_path / "db"))
    store.ensure_collection("test", dim=DIM, with_sparse=False)
    store.ensure_collection("test", dim=DIM, with_sparse=False)  # second call — no error
    assert store.count("test") == 0


def test_delete_by_source_removes_only_target(tmp_path: pytest.MonkeyPatch) -> None:
    """Deleting by source_uri removes only that source's chunks."""
    store = LanceStore(str(tmp_path / "db"))
    store.ensure_collection("test", dim=DIM, with_sparse=False)

    chunks_a = [_make_chunk(source_uri="file:///a.py", chunk_idx=i) for i in range(2)]
    chunks_b = [_make_chunk(source_uri="file:///b.py", chunk_idx=i) for i in range(2)]
    vectors = [_make_vector() for _ in range(4)]

    _run(store.upsert("test", vectors[:2], chunks_a))
    _run(store.upsert("test", vectors[2:], chunks_b))
    assert store.count("test") == 4

    store.delete_by_source("test", "file:///a.py")
    assert store.count("test") == 2

    results = _run(store.search("test", _make_vector(), top_n=10))
    assert all(r.payload.get("source_uri") == "file:///b.py" for r in results)


def test_hybrid_search_returns_ranked_results(tmp_path: pytest.MonkeyPatch) -> None:
    """Hybrid search (FTS disabled) returns non-empty ranked results."""
    store = LanceStore(str(tmp_path / "db"))
    store.ensure_collection("test", dim=DIM, with_sparse=False)

    chunks = [
        _make_chunk(chunk_idx=0, text="python programming language"),
        _make_chunk(chunk_idx=1, text="machine learning models"),
        _make_chunk(chunk_idx=2, text="python data science tools"),
    ]
    vectors = [_make_vector() for _ in range(3)]
    _run(store.upsert("test", vectors, chunks))

    results = _run(
        store.hybrid_search("test", _make_vector(), "python programming", top_n=3)
    )
    assert len(results) > 0
    assert all(isinstance(r, SearchResult) for r in results)
    # scores should be in descending order
    scores = [r.score for r in results]
    assert scores == sorted(scores, reverse=True)


def test_importerror_without_lancedb(tmp_path: pytest.MonkeyPatch) -> None:
    """LanceStore raises ImportError with helpful message if lancedb missing."""
    import sys
    import types

    # Temporarily hide lancedb
    real_lancedb = sys.modules.pop("lancedb", None)
    # Also remove any sub-modules so import fails
    lancedb_mods = [k for k in list(sys.modules.keys()) if k.startswith("lancedb")]
    saved = {k: sys.modules.pop(k) for k in lancedb_mods}

    # Install a broken module
    broken = types.ModuleType("lancedb")

    def _bad_import(*args, **kwargs):  # type: ignore[no-untyped-def]
        raise ImportError("lancedb not installed")

    broken.__spec__ = None  # type: ignore[assignment]
    sys.modules["lancedb"] = broken

    # Patch the import inside LanceStore.__init__
    import builtins

    real_import = builtins.__import__

    def fake_import(name, *args, **kwargs):  # type: ignore[no-untyped-def]
        if name == "lancedb":
            raise ImportError("lancedb not installed")
        return real_import(name, *args, **kwargs)

    builtins.__import__ = fake_import
    try:
        with pytest.raises(ImportError, match="lancedb"):
            LanceStore(str(tmp_path / "db"))
    finally:
        builtins.__import__ = real_import
        sys.modules.pop("lancedb", None)
        if real_lancedb is not None:
            sys.modules["lancedb"] = real_lancedb
        for k, v in saved.items():
            sys.modules[k] = v
