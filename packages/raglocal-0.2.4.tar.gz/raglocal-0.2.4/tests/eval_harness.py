"""Eval harness: golden set evaluation with recall@k and keyword_hit_rate metrics."""

from __future__ import annotations

import json
from pathlib import Path

from raglocal.retrieve import Retriever


async def run_eval(
    golden_path: str = "tests/golden.jsonl",
    retriever: Retriever | None = None,
    top_k: int = 5,
) -> dict[str, float]:
    """Run golden set eval. Returns {"recall_at_k": float, "keyword_hit_rate": float}.

    Args:
        golden_path: Path to the golden.jsonl file containing test questions.
        retriever: Retriever instance (optional; if None, returns 0.0 for both metrics).
        top_k: Number of top results to consider for evaluation.

    Returns:
        Dictionary with two metrics:
        - recall_at_k: Fraction of questions where at least one keyword was found.
        - keyword_hit_rate: Fraction of expected keywords that were found across all results.
    """
    entries = [
        json.loads(line) for line in Path(golden_path).read_text().splitlines() if line.strip()
    ]

    recall_hits = 0
    keyword_hits = 0
    total_keywords = 0

    for entry in entries:
        question = entry["question"]
        keywords = [k.lower() for k in entry["expected_keywords"]]

        if retriever is None:
            # No retriever available — skip gracefully
            total_keywords += len(keywords)
            continue

        ctx = await retriever.retrieve(question, collections=["docs"], top_k=top_k)
        all_text = " ".join(r.text.lower() for r in ctx.results)

        found = [k for k in keywords if k in all_text]
        if found:
            recall_hits += 1
        keyword_hits += len(found)
        total_keywords += len(keywords)

    n = len(entries)
    return {
        "recall_at_k": recall_hits / n if n else 0.0,
        "keyword_hit_rate": keyword_hits / total_keywords if total_keywords else 0.0,
    }
