"""End-to-end CLI tests using typer.testing.CliRunner.

Skipped entirely if sentence_transformers is not installed.
All paths redirected to tmp_path — never touches ~/.config/raglocal.
"""

from __future__ import annotations

import textwrap
from pathlib import Path

import pytest
from typer.testing import CliRunner

import cli as _cli_module
from cli import app

# ---------------------------------------------------------------------------
# Skip guard
# ---------------------------------------------------------------------------

try:
    import sentence_transformers  # noqa: F401
    _ST_AVAILABLE = True
except ImportError:
    _ST_AVAILABLE = False

pytestmark = pytest.mark.skipif(
    not _ST_AVAILABLE,
    reason="sentence_transformers not installed",
)

runner = CliRunner(mix_stderr=False)


def _write_config(config_path: Path, data_path: Path) -> None:
    """Write a minimal lean-profile config.toml to config_path."""
    lance_path = data_path / "lance"
    state_path = data_path / "state"
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(
        textwrap.dedent(f"""\
            [core]
            state_dir = "{state_path}"
            log_level = "info"

            [store]
            backend = "lance"
            path = "{lance_path}"

            [embedder]
            profile = "lean"
            provider = "sentence-transformers"
            model = "all-MiniLM-L6-v2"
            dim = 384

            [reranker]
            enabled = false
            model = ""

            [retrieval]
            top_n = 10
            top_k = 3
            hybrid_alpha = 0.5

            [defaults]
            model = "smart"
            collections = ["docs"]

            [models.smart]
            provider = "ollama"
            model = "qwen3:32b"

            [collections.docs]
            chunk_size = 400
            chunk_overlap = 40
            chunk_strategy = "token"
        """)
    )


def _make_corpus(corpus_dir: Path) -> None:
    """Write 3 small markdown files into corpus_dir."""
    corpus_dir.mkdir(parents=True, exist_ok=True)
    (corpus_dir / "rust.md").write_text(
        "# Rust\nRust guarantees memory safety through ownership and borrowing.\n"
        "The borrow checker prevents data races at compile time.\n"
    )
    (corpus_dir / "python.md").write_text(
        "# Python\nPython is a dynamically-typed language popular for scripting.\n"
        "It uses garbage collection for memory management.\n"
    )
    (corpus_dir / "cooking.md").write_text(
        "# Cooking\nSautéing involves cooking food quickly in a small amount of oil.\n"
        "Mise en place means having all your ingredients ready before cooking.\n"
    )


# ---------------------------------------------------------------------------
# Fixture: redirect _RAGKIT_CONFIG_FILE to tmp_path
# ---------------------------------------------------------------------------

@pytest.fixture()
def e2e_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    """Redirect CLI config path to tmp_path; return (config_path, data_path, corpus_dir)."""
    config_path = tmp_path / "config" / "config.toml"
    data_path = tmp_path / "data"
    corpus_dir = tmp_path / "corpus"

    # Patch module-level variable used by `init` command
    monkeypatch.setattr(_cli_module, "_RAGKIT_CONFIG_FILE", config_path)
    # Also patch load_config default env in case something reads RAGKIT_CONFIG
    monkeypatch.setenv("RAGKIT_CONFIG", str(config_path))

    return config_path, data_path, corpus_dir


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_init_creates_config(e2e_env, tmp_path):
    config_path, data_path, _ = e2e_env

    result = runner.invoke(
        app,
        [
            "init",
            "--non-interactive",
            "--profile", "lean",
            "--path", str(data_path),
        ],
    )
    assert result.exit_code == 0, result.output
    assert config_path.exists(), "config.toml not created by init"


def test_init_then_index_then_stats(e2e_env, tmp_path):
    config_path, data_path, corpus_dir = e2e_env
    _make_corpus(corpus_dir)

    # init
    r = runner.invoke(app, ["init", "--non-interactive", "--profile", "lean", "--path", str(data_path)])
    assert r.exit_code == 0, r.output

    # index
    r = runner.invoke(app, ["index", str(corpus_dir), "--collection", "docs", "--config", str(config_path)])
    assert r.exit_code == 0, r.output

    # stats
    r = runner.invoke(app, ["stats", "--config", str(config_path)])
    assert r.exit_code == 0, r.output


def test_full_workflow_search_finds_relevant_doc(e2e_env, tmp_path):
    """init → index corpus with Rust+Cooking docs → search via store → assert rust found."""
    config_path, data_path, corpus_dir = e2e_env
    _make_corpus(corpus_dir)

    # init
    runner.invoke(app, ["init", "--non-interactive", "--profile", "lean", "--path", str(data_path)])

    # index
    r = runner.invoke(app, ["index", str(corpus_dir), "--collection", "docs", "--config", str(config_path)])
    assert r.exit_code == 0, r.output

    # Verify search directly via raglocal API (debug CLI doesn't call ensure_collection)
    import asyncio

    from raglocal.config import load_config
    from raglocal.embed import SentenceTransformersEmbedder
    from raglocal.store import LanceStore

    cfg = load_config(str(config_path))
    store = LanceStore(cfg.store.path)
    store.ensure_collection("docs", cfg.embedder.dim)

    embedder = SentenceTransformersEmbedder(cfg.embedder.model, cfg.embedder.dim, cfg.embedder.cache_dir)

    async def _search():
        vecs = await embedder.embed(["memory safety"])
        results = await store.hybrid_search("docs", vecs[0], "memory safety", top_n=5)
        await embedder.aclose()
        return results

    results = asyncio.run(_search())
    assert results, "Expected at least one result for 'memory safety'"
    all_text = " ".join(r.text.lower() for r in results)
    assert "rust" in all_text, f"Expected 'rust' in results. Got:\n{all_text}"


def test_doctor_passes_after_init(e2e_env, tmp_path):
    config_path, data_path, _ = e2e_env

    # init first so config exists
    r = runner.invoke(app, ["init", "--non-interactive", "--profile", "lean", "--path", str(data_path)])
    assert r.exit_code == 0, r.output

    # doctor may exit non-zero if Ollama is unreachable, but must not crash
    r = runner.invoke(app, ["doctor", "--config", str(config_path)])
    # We only assert no unhandled exception (SystemExit is fine)
    assert isinstance(r.exit_code, int), "doctor raised unexpected exception"
