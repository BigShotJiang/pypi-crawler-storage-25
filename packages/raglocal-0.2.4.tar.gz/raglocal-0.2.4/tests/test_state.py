"""Tests for SQLite state store."""

from __future__ import annotations

import sqlite3
import tempfile
import time
from pathlib import Path

import pytest

from raglocal.state import StateStore


class TestStateStore:
    """Test StateStore CRUD and state persistence."""

    @pytest.fixture
    def temp_db(self) -> tuple[str, Path]:
        """Create a temporary DB file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = str(Path(tmpdir) / "state.db")
            yield db_path, Path(tmpdir)

    def test_init_creates_db_and_schema(self, temp_db: tuple[str, Path]) -> None:
        """StateStore.__init__ creates DB file and schema."""
        db_path, tmpdir = temp_db
        store = StateStore(db_path)
        store.close()

        # Verify file exists
        assert Path(db_path).exists()

        # Verify schema
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='ingested_file'")
        assert cursor.fetchone() is not None
        cursor.execute("SELECT name FROM sqlite_master WHERE type='index' AND name='ix_collection'")
        assert cursor.fetchone() is not None
        conn.close()

    def test_init_creates_parent_directories(self) -> None:
        """StateStore.__init__ creates parent dirs when db_path contains ~."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Use a nested path to verify parent creation
            db_path = str(Path(tmpdir) / "a" / "b" / "c" / "state.db")
            store = StateStore(db_path)
            store.close()
            assert Path(db_path).exists()

    def test_record_and_is_fresh(self, temp_db: tuple[str, Path]) -> None:
        """StateStore.record() and is_fresh() work correctly."""
        db_path, _ = temp_db
        store = StateStore(db_path)

        source_uri = "file:///docs/test.md"
        collection = "docs"
        mtime = 1000
        content_hash = "sha256:abc123"
        chunk_count = 5

        # File not yet recorded
        assert not store.is_fresh(source_uri, mtime, content_hash)

        # Record it
        store.record(source_uri, collection, mtime, content_hash, chunk_count)

        # Now it's fresh
        assert store.is_fresh(source_uri, mtime, content_hash)

        # Stale if mtime differs
        assert not store.is_fresh(source_uri, mtime + 1, content_hash)

        # Stale if content_hash differs
        assert not store.is_fresh(source_uri, mtime, "sha256:different")

        store.close()

    def test_record_updates_on_conflict(self, temp_db: tuple[str, Path]) -> None:
        """StateStore.record() updates existing entry."""
        db_path, _ = temp_db
        store = StateStore(db_path)

        source_uri = "file:///docs/test.md"

        # First record
        store.record(source_uri, "docs", 1000, "hash1", 5)
        assert store.is_fresh(source_uri, 1000, "hash1")

        # Update with new hash and mtime
        store.record(source_uri, "docs", 2000, "hash2", 10)
        assert store.is_fresh(source_uri, 2000, "hash2")
        assert not store.is_fresh(source_uri, 1000, "hash1")

        store.close()

    def test_forget_removes_entry(self, temp_db: tuple[str, Path]) -> None:
        """StateStore.forget() removes a source."""
        db_path, _ = temp_db
        store = StateStore(db_path)

        source_uri = "file:///docs/test.md"
        store.record(source_uri, "docs", 1000, "hash1", 5)
        assert store.is_fresh(source_uri, 1000, "hash1")

        store.forget(source_uri)
        assert not store.is_fresh(source_uri, 1000, "hash1")

        store.close()

    def test_list_by_collection(self, temp_db: tuple[str, Path]) -> None:
        """StateStore.list_by_collection() returns all entries in a collection."""
        db_path, _ = temp_db
        store = StateStore(db_path)

        # Add entries to different collections
        store.record("file:///docs/a.md", "docs", 1000, "hash1", 5)
        store.record("file:///docs/b.md", "docs", 2000, "hash2", 6)
        store.record("file:///code/c.py", "code", 3000, "hash3", 7)

        # List docs collection
        docs_entries = store.list_by_collection("docs")
        assert len(docs_entries) == 2
        source_uris = {e["source_uri"] for e in docs_entries}
        assert source_uris == {"file:///docs/a.md", "file:///docs/b.md"}

        # List code collection
        code_entries = store.list_by_collection("code")
        assert len(code_entries) == 1
        assert code_entries[0]["source_uri"] == "file:///code/c.py"

        store.close()

    def test_persistence_across_reopens(self, temp_db: tuple[str, Path]) -> None:
        """Data persists when DB is closed and reopened."""
        db_path, _ = temp_db

        # Write data
        store1 = StateStore(db_path)
        store1.record("file:///docs/test.md", "docs", 1000, "hash1", 5)
        store1.close()

        # Reopen and verify
        store2 = StateStore(db_path)
        assert store2.is_fresh("file:///docs/test.md", 1000, "hash1")
        entries = store2.list_by_collection("docs")
        assert len(entries) == 1
        assert entries[0]["chunk_count"] == 5
        store2.close()

    def test_multiple_sources_same_collection(self, temp_db: tuple[str, Path]) -> None:
        """Multiple sources can be tracked in the same collection."""
        db_path, _ = temp_db
        store = StateStore(db_path)

        for i in range(5):
            store.record(f"file:///docs/{i}.md", "docs", 1000 + i, f"hash{i}", 5 + i)

        entries = store.list_by_collection("docs")
        assert len(entries) == 5
        assert all(e["collection"] == "docs" for e in entries)

        store.close()

    def test_indexed_at_is_set(self, temp_db: tuple[str, Path]) -> None:
        """StateStore.record() sets indexed_at to current time."""
        db_path, _ = temp_db
        store = StateStore(db_path)

        before = int(time.time())
        store.record("file:///docs/test.md", "docs", 1000, "hash1", 5)
        after = int(time.time())

        entries = store.list_by_collection("docs")
        indexed_at = entries[0]["indexed_at"]
        assert before <= indexed_at <= after + 1

        store.close()

    def test_forget_nonexistent_source_is_safe(self, temp_db: tuple[str, Path]) -> None:
        """StateStore.forget() on nonexistent source does not error."""
        db_path, _ = temp_db
        store = StateStore(db_path)

        # Should not raise
        store.forget("file:///does/not/exist.md")

        store.close()
