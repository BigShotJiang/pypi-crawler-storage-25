"""Regression tests for cli._load_services function."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

pytest.importorskip("sentence_transformers")

import cli
from raglocal.config import (
    CollectionConfig,
    Config,
    EmbedderConfig,
    ModelSpec,
    RerankerConfig,
    RetrievalConfig,
    StoreConfig,
)
from raglocal.store import LanceStore


def test_load_services_attaches_existing_collections(tmp_path: Path):
    """Verify _load_services attaches collections that exist on disk."""
    # Setup: create config with "docs" and "code" collections
    cfg = Config(
        state_dir=str(tmp_path / "state"),
        log_level="info",
        store=StoreConfig(backend="lance", path=str(tmp_path / "lance")),
        embedder=EmbedderConfig(
            profile="lean",
            provider="sentence-transformers",
            model="all-MiniLM-L6-v2",
            host="",
            dim=384,
            cache_dir=None,
        ),
        reranker=RerankerConfig(enabled=False, model=""),
        retrieval=RetrievalConfig(top_n=5, top_k=3, hybrid_alpha=0.5),
        models={"smart": ModelSpec(alias="smart", provider="anthropic", model="claude-sonnet-4-6")},
        default_model="smart",
        default_collections=["docs"],
        collections={
            "docs": CollectionConfig(
                name="docs", chunk_size=800, chunk_overlap=100, chunk_strategy="token"
            ),
            "code": CollectionConfig(
                name="code", chunk_size=500, chunk_overlap=50, chunk_strategy="code-aware"
            ),
        },
    )

    # Manually create a LanceStore and ensure only "docs" collection exists on disk
    lance_dir = tmp_path / "lance"
    lance_dir.mkdir()
    store = LanceStore(str(lance_dir))
    store.ensure_collection("docs", 384)

    # Call _load_services with mocked embedder
    with patch("cli._build_embedder", return_value=MagicMock(dim=384)):
        embedder, result_store, state = cli._load_services(cfg)

    # Assert: "docs" should be attached, "code" should not
    assert "docs" in result_store._tables, "docs collection should be attached"
    assert "code" not in result_store._tables, "code collection should not be auto-attached"


def test_load_services_no_tables_on_fresh_store(tmp_path: Path):
    """Verify _load_services returns empty _tables on fresh store."""
    # Setup: config with collections but no pre-existing LanceDB
    cfg = Config(
        state_dir=str(tmp_path / "state"),
        log_level="info",
        store=StoreConfig(backend="lance", path=str(tmp_path / "lance")),
        embedder=EmbedderConfig(
            profile="lean",
            provider="sentence-transformers",
            model="all-MiniLM-L6-v2",
            host="",
            dim=384,
            cache_dir=None,
        ),
        reranker=RerankerConfig(enabled=False, model=""),
        retrieval=RetrievalConfig(top_n=5, top_k=3, hybrid_alpha=0.5),
        models={"smart": ModelSpec(alias="smart", provider="anthropic", model="claude-sonnet-4-6")},
        default_model="smart",
        default_collections=["docs"],
        collections={
            "docs": CollectionConfig(
                name="docs", chunk_size=800, chunk_overlap=100, chunk_strategy="token"
            ),
            "code": CollectionConfig(
                name="code", chunk_size=500, chunk_overlap=50, chunk_strategy="code-aware"
            ),
        },
    )

    # Call _load_services with mocked embedder
    with patch("cli._build_embedder", return_value=MagicMock(dim=384)):
        embedder, result_store, state = cli._load_services(cfg)

    # Assert: _tables should be empty and no exception raised
    assert result_store._tables == {}, "fresh store should have no attached tables"


def test_load_services_ignores_unknown_tables(tmp_path: Path):
    """Verify _load_services ignores tables not defined in config.collections."""
    # Setup: pre-create a LanceStore with a "rogue" table not in config
    lance_dir = tmp_path / "lance"
    lance_dir.mkdir()
    store = LanceStore(str(lance_dir))
    store.ensure_collection("rogue", 384)

    # Config only knows about "docs", not "rogue"
    cfg = Config(
        state_dir=str(tmp_path / "state"),
        log_level="info",
        store=StoreConfig(backend="lance", path=str(lance_dir)),
        embedder=EmbedderConfig(
            profile="lean",
            provider="sentence-transformers",
            model="all-MiniLM-L6-v2",
            host="",
            dim=384,
            cache_dir=None,
        ),
        reranker=RerankerConfig(enabled=False, model=""),
        retrieval=RetrievalConfig(top_n=5, top_k=3, hybrid_alpha=0.5),
        models={"smart": ModelSpec(alias="smart", provider="anthropic", model="claude-sonnet-4-6")},
        default_model="smart",
        default_collections=["docs"],
        collections={
            "docs": CollectionConfig(
                name="docs", chunk_size=800, chunk_overlap=100, chunk_strategy="token"
            ),
        },
    )

    # Call _load_services with mocked embedder
    with patch("cli._build_embedder", return_value=MagicMock(dim=384)):
        embedder, result_store, state = cli._load_services(cfg)

    # Assert: "rogue" should NOT be attached
    assert "rogue" not in result_store._tables, "rogue table should not be auto-attached"
