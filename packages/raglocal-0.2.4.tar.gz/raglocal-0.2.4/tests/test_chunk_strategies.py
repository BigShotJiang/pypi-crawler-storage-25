"""Tests for the split() dispatcher and new chunking strategies."""

from __future__ import annotations

from raglocal.chunk import TextChunk, split, split_text

# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _token_count(text: str) -> int:
    return len(text.split())


# ---------------------------------------------------------------------------
# 1. token strategy is a regression guard for split_text
# ---------------------------------------------------------------------------

def test_token_strategy_matches_split_text() -> None:
    """split(text, strategy="token") produces the same result as split_text(text)."""
    text = " ".join(["word"] * 500)
    via_split = split(text, strategy="token", chunk_size=200, chunk_overlap=20)
    via_split_text = split_text(text, chunk_size=200, chunk_overlap=20)

    assert len(via_split) == len(via_split_text)
    for a, b in zip(via_split, via_split_text, strict=True):
        assert a.text == b.text
        assert a.chunk_idx == b.chunk_idx
        assert a.chunk_total == b.chunk_total


# ---------------------------------------------------------------------------
# 2. sentence strategy: no chunk (except last) ends mid-sentence
# ---------------------------------------------------------------------------

def test_sentence_strategy_preserves_sentences() -> None:
    """Each chunk except the last must end with '.', '!', or '?'."""
    sentences = [
        "This is the first sentence.",
        "Here comes the second one!",
        "And a third?",
        "Fourth sentence here.",
        "Fifth and final sentence.",
    ]
    # Repeat to have multiple chunks with a small chunk_size
    text = " ".join(sentences * 20)
    chunks = split(text, strategy="sentence", chunk_size=30)

    assert len(chunks) > 1, "Expected multiple chunks"
    for chunk in chunks[:-1]:
        last_char = chunk.text.rstrip()[-1]
        assert last_char in (".", "!", "?"), (
            f"Non-terminal chunk does not end with sentence punctuation: ...{chunk.text[-30:]!r}"
        )


# ---------------------------------------------------------------------------
# 3. sentence strategy: chunks fit within chunk_size
# ---------------------------------------------------------------------------

def test_sentence_strategy_chunks_fit_size() -> None:
    """All chunks produced by sentence strategy have token count <= chunk_size."""
    sentences = ["The quick brown fox jumps over the lazy dog."] * 40
    text = " ".join(sentences)
    chunk_size = 50
    chunks = split(text, strategy="sentence", chunk_size=chunk_size)

    assert len(chunks) >= 1
    for chunk in chunks:
        count = _token_count(chunk.text)
        assert count <= chunk_size, (
            f"Chunk has {count} tokens, exceeds chunk_size={chunk_size}: {chunk.text[:60]!r}"
        )


# ---------------------------------------------------------------------------
# 4. code-aware: function bodies not split across chunks (Python)
# ---------------------------------------------------------------------------

def test_code_aware_preserves_function_boundaries() -> None:
    """
    A Python file with multiple defs should not split a function body across
    chunks unless a single function exceeds chunk_size on its own.
    Each chunk (except possibly the first preamble) that starts a new function
    must begin with 'def '.
    """
    code_lines = []
    # Generate 10 small functions
    for i in range(10):
        code_lines.append(f"def func_{i}(x):")
        for _ in range(8):
            code_lines.append("    return x + 1")
    code = "\n".join(code_lines)

    chunks = split(code, strategy="code-aware", chunk_size=80, language="python")

    assert len(chunks) >= 1

    # Every chunk that contains a 'def ' line should start with 'def '
    # unless it's preamble (no def at all)
    for chunk in chunks:
        first_line = chunk.text.split("\n")[0]
        has_def = "def " in chunk.text
        if has_def:
            assert first_line.startswith("def "), (
                f"Chunk starts mid-function without 'def': {chunk.text[:80]!r}"
            )


# ---------------------------------------------------------------------------
# 5. chapter strategy delegates to token
# ---------------------------------------------------------------------------

def test_chapter_delegates_to_token() -> None:
    """chapter strategy produces non-empty result matching token output."""
    text = " ".join(["word"] * 300)
    chapter_chunks = split(text, strategy="chapter", chunk_size=100, chunk_overlap=10)
    token_chunks = split(text, strategy="token", chunk_size=100, chunk_overlap=10)

    assert len(chapter_chunks) > 0
    assert len(chapter_chunks) == len(token_chunks)
    for a, b in zip(chapter_chunks, token_chunks, strict=True):
        assert a.text == b.text


# ---------------------------------------------------------------------------
# 6. split returns TextChunk instances
# ---------------------------------------------------------------------------

def test_split_returns_text_chunks() -> None:
    """All items returned by split() are TextChunk instances."""
    text = "Hello world. This is a test sentence. Another one here."
    for strategy in ("token", "sentence", "code-aware", "chapter"):
        chunks = split(text, strategy=strategy)  # type: ignore[arg-type]
        for chunk in chunks:
            assert isinstance(chunk, TextChunk), (
                f"strategy={strategy!r} returned non-TextChunk: {type(chunk)}"
            )


# ---------------------------------------------------------------------------
# 7. empty string returns empty list
# ---------------------------------------------------------------------------

def test_split_empty_string() -> None:
    """Empty string returns empty list for all strategies."""
    for strategy in ("token", "sentence", "code-aware", "chapter"):
        result = split("", strategy=strategy)  # type: ignore[arg-type]
        assert result == [], f"strategy={strategy!r} did not return [] for empty string"


# ---------------------------------------------------------------------------
# 8. code-aware with JavaScript splits on function/const boundaries
# ---------------------------------------------------------------------------

def test_code_aware_javascript() -> None:
    """With language='javascript', splits on 'function' and 'const' boundaries."""
    js_lines = []
    for i in range(6):
        js_lines.append(f"function handler{i}(req, res) {{")
        for _ in range(5):
            js_lines.append("  res.send('ok');")
        js_lines.append("}")
        js_lines.append(f"const value{i} = handler{i};")
    js_code = "\n".join(js_lines)

    chunks = split(js_code, strategy="code-aware", chunk_size=40, language="javascript")

    assert len(chunks) >= 2, "Expected multiple chunks for JS code"

    # Each chunk that contains a function/const declaration must start with one
    boundary_prefixes = ("function ", "const ", "let ", "var ", "async function ", "export ")
    for chunk in chunks:
        first_line = chunk.text.split("\n")[0]
        has_boundary = any(
            kw in chunk.text
            for kw in ("function ", "const ", "let ", "var ")
        )
        if has_boundary:
            assert any(first_line.startswith(p) for p in boundary_prefixes) or first_line.startswith("//"), (
                f"JS chunk starts mid-declaration: {chunk.text[:80]!r}"
            )
