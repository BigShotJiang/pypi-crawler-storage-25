"""Contract tests for raglocal MCP server response envelope (MCP 2024-11-05)."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock

import pytest

from tests.test_mcp import (
    _eof,
    _make_search_result,
    _make_server,
    _responses,
    _send,
)


@pytest.fixture
def mock_store_with_data() -> MagicMock:
    """Mock store with a chunk for expand testing."""
    store = MagicMock()
    # For search: return one result
    store.hybrid_search = AsyncMock(
        return_value=[
            _make_search_result(
                text="The quick brown fox jumps",
                chunk_id="chunk-1",
                source_uri="file:///test.md",
            )
        ]
    )
    # For expand: return chunk by id lookup
    store.search = AsyncMock(
        return_value=[
            _make_search_result(
                text="The quick brown fox jumps over the lazy dog",
                chunk_id="chunk-1",
                source_uri="file:///test.md",
                chunk_idx=0,
                chunk_total=1,
            )
        ]
    )
    store.count = MagicMock(return_value=1)
    return store


@pytest.fixture
def mock_embedder() -> MagicMock:
    """Mock embedder."""
    emb = MagicMock()
    emb.embed = AsyncMock(return_value=[[0.1, 0.2, 0.3, 0.4]])
    emb.aclose = AsyncMock(return_value=None)
    return emb


# ===========================================================================
# Test 1: search response envelope shape
# ===========================================================================


@pytest.mark.asyncio
async def test_search_response_envelope_shape(
    mock_store_with_data: MagicMock, mock_embedder: MagicMock
) -> None:
    """Verify search response has correct envelope structure and parseable JSON."""
    server, reader, written = _make_server(
        store=mock_store_with_data, embedder=mock_embedder
    )
    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "search", "arguments": {"query": "brown fox"}},
        },
    )
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    assert len(responses) > 0
    rpc_response = responses[0]

    # Verify top-level envelope keys
    assert "result" in rpc_response
    result = rpc_response["result"]
    assert "content" in result
    assert "isError" in result
    assert result["isError"] is False

    # Verify content structure
    content = result["content"]
    assert isinstance(content, list)
    assert len(content) >= 1
    assert content[0]["type"] == "text"
    assert isinstance(content[0]["text"], str)

    # Verify JSON inside text is parseable and contains "hits"
    text_json = json.loads(content[0]["text"])
    assert "hits" in text_json


# ===========================================================================
# Test 2: expand response envelope shape
# ===========================================================================


@pytest.mark.asyncio
async def test_expand_response_envelope_shape(
    mock_store_with_data: MagicMock, mock_embedder: MagicMock
) -> None:
    """Verify expand response has correct envelope structure and parseable JSON."""
    server, reader, written = _make_server(
        store=mock_store_with_data, embedder=mock_embedder
    )
    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "expand", "arguments": {"ids": ["chunk-1"]}},
        },
    )
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    assert len(responses) > 0
    rpc_response = responses[0]

    # Verify top-level envelope keys
    assert "result" in rpc_response
    result = rpc_response["result"]
    assert "content" in result
    assert "isError" in result
    assert result["isError"] is False

    # Verify content structure
    content = result["content"]
    assert isinstance(content, list)
    assert len(content) >= 1
    assert content[0]["type"] == "text"
    assert isinstance(content[0]["text"], str)

    # Verify JSON inside text is parseable and contains "chunks"
    text_json = json.loads(content[0]["text"])
    assert "chunks" in text_json


# ===========================================================================
# Test 3: search response text is valid JSON
# ===========================================================================


@pytest.mark.asyncio
async def test_search_response_text_is_valid_json(
    mock_store_with_data: MagicMock, mock_embedder: MagicMock
) -> None:
    """Verify search response text field contains valid JSON."""
    server, reader, written = _make_server(
        store=mock_store_with_data, embedder=mock_embedder
    )
    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "search", "arguments": {"query": "brown fox"}},
        },
    )
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    rpc_response = responses[0]
    result = rpc_response["result"]
    content = result["content"]
    text_field = content[0]["text"]

    # This should not raise
    parsed = json.loads(text_field)
    assert isinstance(parsed, dict)


# ===========================================================================
# Test 4: expand response text is valid JSON
# ===========================================================================


@pytest.mark.asyncio
async def test_expand_response_text_is_valid_json(
    mock_store_with_data: MagicMock, mock_embedder: MagicMock
) -> None:
    """Verify expand response text field contains valid JSON."""
    server, reader, written = _make_server(
        store=mock_store_with_data, embedder=mock_embedder
    )
    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "expand", "arguments": {"ids": ["chunk-1"]}},
        },
    )
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    rpc_response = responses[0]
    result = rpc_response["result"]
    content = result["content"]
    text_field = content[0]["text"]

    # This should not raise
    parsed = json.loads(text_field)
    assert isinstance(parsed, dict)


# ===========================================================================
# Test 5: search envelope has no extra top-level keys
# ===========================================================================


@pytest.mark.asyncio
async def test_search_envelope_has_no_extra_top_level_keys(
    mock_store_with_data: MagicMock, mock_embedder: MagicMock
) -> None:
    """Verify search envelope contains only 'content' and 'isError' at top level."""
    server, reader, written = _make_server(
        store=mock_store_with_data, embedder=mock_embedder
    )
    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "search", "arguments": {"query": "brown fox"}},
        },
    )
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    rpc_response = responses[0]
    result = rpc_response["result"]

    # Verify no legacy "hits" key at top level
    assert "hits" not in result
    # Verify only expected keys
    result_keys = set(result.keys())
    expected_keys = {"content", "isError"}
    assert result_keys == expected_keys


# ===========================================================================
# Test 6: expand envelope has no extra top-level keys
# ===========================================================================


@pytest.mark.asyncio
async def test_expand_envelope_has_no_extra_top_level_keys(
    mock_store_with_data: MagicMock, mock_embedder: MagicMock
) -> None:
    """Verify expand envelope contains only 'content' and 'isError' at top level."""
    server, reader, written = _make_server(
        store=mock_store_with_data, embedder=mock_embedder
    )
    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "expand", "arguments": {"ids": ["chunk-1"]}},
        },
    )
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    rpc_response = responses[0]
    result = rpc_response["result"]

    # Verify no legacy "chunks" key at top level
    assert "chunks" not in result
    # Verify only expected keys
    result_keys = set(result.keys())
    expected_keys = {"content", "isError"}
    assert result_keys == expected_keys
