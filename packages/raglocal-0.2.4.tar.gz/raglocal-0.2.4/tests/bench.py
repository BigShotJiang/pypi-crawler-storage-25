"""Performance benchmarks for raglocal.

Run via:
    uv run python -m tests.bench
or:
    uv run rag-bench  (after pip install -e .)
"""

from __future__ import annotations

import argparse
import asyncio
import json
import resource
import statistics
import subprocess
import sys
import tempfile
import time
from pathlib import Path

# Skip if sentence_transformers missing — bench requires local embedder
try:
    import sentence_transformers  # noqa: F401
except ImportError:
    print(
        "ERROR: sentence-transformers not installed. "
        "Run: pip install raglocal[local-embed]",
        file=sys.stderr,
    )
    sys.exit(1)

from raglocal.config import (
    CollectionConfig,
    Config,
    EmbedderConfig,
    ModelSpec,
    RerankerConfig,
    RetrievalConfig,
    StoreConfig,
)
from raglocal.embed import SentenceTransformersEmbedder
from raglocal.index import index_paths
from raglocal.state import StateStore
from raglocal.store import LanceStore

# --- Constants ----------------------------------------------------------------

_VOCAB = [
    "rust", "python", "typescript", "memory", "safety", "ownership", "borrow",
    "lifetime", "async", "runtime", "garbage", "collection", "compile", "time",
    "error", "static", "dynamic", "typing", "inference", "function", "module",
    "class", "struct", "enum", "trait", "protocol", "generic", "template",
    "iterator", "stream", "channel", "mutex", "spin", "lock", "atomic",
    "concurrent", "parallel", "thread", "fiber", "actor", "filesystem",
    "network", "socket", "http", "json", "yaml", "toml", "database", "query",
    "index", "cache",
]

_TOPICS = [
    "rust ownership and lifetimes",
    "python async/await runtime model",
    "typescript type inference vs explicit types",
    "memory safety without garbage collection",
    "concurrent programming with channels",
    "static vs dynamic typing tradeoffs",
    "filesystem and network IO patterns",
    "database indexing strategies",
    "compile-time error checking",
    "iterator and stream protocols",
]


# --- Helpers ------------------------------------------------------------------


def make_corpus(root: Path, n_files: int) -> tuple[Path, int]:
    """Generate N synthetic markdown files. Returns (root, total_bytes)."""
    import random

    rng = random.Random(42)  # deterministic
    total = 0
    for i in range(n_files):
        # 10–50 paragraphs per file, 30–80 words each
        n_paras = rng.randint(10, 50)
        title_topic = rng.choice(_TOPICS)
        lines = [f"# {title_topic} — file {i}\n"]
        for _ in range(n_paras):
            n_words = rng.randint(30, 80)
            words = [rng.choice(_VOCAB) for _ in range(n_words)]
            lines.append(" ".join(words) + ".")
            lines.append("")
        text = "\n".join(lines)
        f = root / f"file_{i:04d}.md"
        f.write_text(text)
        total += len(text)
    return root, total


def peak_rss_mb() -> float:
    """Return peak RSS in MB (cross-platform best-effort)."""
    rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    if sys.platform == "darwin":
        return rss / (1024 * 1024)
    return rss / 1024  # linux: KB


def build_config(store_path: Path, profile: str) -> Config:
    """Build a minimal Config for the bench."""
    if profile == "lean":
        model = "all-MiniLM-L6-v2"
        dim = 384
    elif profile == "balanced":
        model = "nomic-ai/nomic-embed-text-v1.5"
        dim = 768
    else:
        raise ValueError(f"unsupported profile: {profile}")

    return Config(
        state_dir=str(store_path.parent / "state"),
        log_level="warning",
        store=StoreConfig(backend="lance", path=str(store_path)),
        embedder=EmbedderConfig(
            profile=profile,
            provider="sentence-transformers",
            model=model,
            host="",
            dim=dim,
            cache_dir=None,
        ),
        reranker=RerankerConfig(enabled=False, model=""),
        retrieval=RetrievalConfig(top_n=20, top_k=10, hybrid_alpha=0.5),
        models={"smart": ModelSpec(alias="smart", provider="ollama", model="llama3")},
        default_model="smart",
        default_collections=["docs"],
        collections={
            "docs": CollectionConfig(name="docs", chunk_size=400, chunk_overlap=50),
        },
    )


def percentiles(samples_ms: list[float]) -> dict[str, float]:
    if not samples_ms:
        return {"p50_ms": 0.0, "p95_ms": 0.0, "mean_ms": 0.0}
    s = sorted(samples_ms)
    return {
        "p50_ms": round(s[len(s) // 2], 2),
        "p95_ms": round(s[min(len(s) - 1, int(len(s) * 0.95))], 2),
        "mean_ms": round(statistics.mean(s), 2),
    }


# --- Benchmarks ---------------------------------------------------------------


async def bench_index(corpus_dir: Path, store_path: Path, cfg: Config) -> dict:
    """Index the corpus, return throughput stats."""
    embedder = SentenceTransformersEmbedder(
        cfg.embedder.model, cfg.embedder.dim, cfg.embedder.cache_dir
    )
    store = LanceStore(cfg.store.path)
    Path(cfg.state_dir).mkdir(parents=True, exist_ok=True)
    state = StateStore(cfg.state_dir + "/state.db")

    rss_before = peak_rss_mb()
    t0 = time.perf_counter()
    report = await index_paths(cfg, embedder, store, state, [str(corpus_dir)])
    elapsed = time.perf_counter() - t0
    rss_after = peak_rss_mb()

    state.close()
    await embedder.aclose()

    return {
        "files_indexed": report.indexed,
        "files_skipped": report.skipped,
        "seconds": round(elapsed, 3),
        "files_per_sec": round(report.indexed / elapsed, 2) if elapsed > 0 else 0.0,
        "peak_rss_mb": round(rss_after, 1),
        "rss_delta_mb": round(rss_after - rss_before, 1),
    }


async def bench_search(store_path: Path, cfg: Config, queries: list[str]) -> dict:
    """Run queries, return latency percentiles."""
    embedder = SentenceTransformersEmbedder(
        cfg.embedder.model, cfg.embedder.dim, cfg.embedder.cache_dir
    )
    store = LanceStore(cfg.store.path)
    # Re-attach to existing on-disk tables (LanceStore only loads lazily)
    store.ensure_collection("docs", cfg.embedder.dim, with_sparse=False)

    samples_ms: list[float] = []
    last_results = None
    for q in queries:
        vecs = await embedder.embed([q])
        t0 = time.perf_counter()
        last_results = await store.hybrid_search(
            collection="docs", query_dense=vecs[0], query_text=q, top_n=10
        )
        samples_ms.append((time.perf_counter() - t0) * 1000)

    await embedder.aclose()
    p = percentiles(samples_ms)
    p["n"] = len(queries)
    p["last_hits"] = len(last_results) if last_results else 0
    return p


def bench_mcp_cold_start(cfg_path: Path) -> dict:
    """Spawn `python -m cli mcp`, send initialize, measure response time."""
    init_req = json.dumps({
        "jsonrpc": "2.0",
        "id": 1,
        "method": "initialize",
        "params": {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "bench", "version": "0"},
        },
    }) + "\n"

    t0 = time.perf_counter()
    proc = subprocess.Popen(
        [sys.executable, "-m", "cli", "mcp", "--config", str(cfg_path)],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
    )
    try:
        assert proc.stdin and proc.stdout
        proc.stdin.write(init_req)
        proc.stdin.flush()
        line = proc.stdout.readline()
        elapsed = time.perf_counter() - t0
    finally:
        try:
            proc.stdin.close() if proc.stdin else None
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()

    if not line.strip():
        return {"ms": -1.0, "error": "no response from server"}
    try:
        resp = json.loads(line)
        ok = "result" in resp and "serverInfo" in resp["result"]
    except json.JSONDecodeError:
        ok = False
    return {"ms": round(elapsed * 1000, 1), "ok": ok}


def fmt_results(results: dict) -> str:
    """Pretty-print results as a plain-text table."""
    lines = ["", "=" * 60, "raglocal performance benchmarks", "=" * 60]
    for section, data in results.items():
        lines.append(f"\n[{section}]")
        for k, v in data.items():
            lines.append(f"  {k:18s} = {v}")
    lines.append("=" * 60)
    return "\n".join(lines)


# --- Main ---------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(description="raglocal performance benchmarks")
    parser.add_argument("--n-files", type=int, default=100)
    parser.add_argument("--n-queries", type=int, default=50)
    parser.add_argument("--profile", choices=["lean", "balanced"], default="lean")
    parser.add_argument("--json", action="store_true", help="JSON output")
    parser.add_argument("--skip-mcp", action="store_true", help="Skip MCP cold-start bench")
    args = parser.parse_args()

    with tempfile.TemporaryDirectory(prefix="ragbench_") as td:
        td_path = Path(td)
        corpus = td_path / "corpus"
        corpus.mkdir()
        store_path = td_path / "lance"

        print(f"Generating {args.n_files} synthetic markdown files...", file=sys.stderr)
        _, total_bytes = make_corpus(corpus, args.n_files)

        cfg = build_config(store_path, args.profile)
        # Write config for MCP subprocess to use
        cfg_path = td_path / "config.toml"
        cfg_path.write_text(_serialize_cfg(cfg))

        results: dict = {
            "setup": {
                "profile": args.profile,
                "n_files": args.n_files,
                "corpus_bytes": total_bytes,
                "n_queries": args.n_queries,
            }
        }

        print(f"Indexing into {store_path}...", file=sys.stderr)
        results["index"] = asyncio.run(bench_index(corpus, store_path, cfg))

        queries = [_TOPICS[i % len(_TOPICS)] for i in range(args.n_queries)]
        print(f"Running {args.n_queries} search queries...", file=sys.stderr)
        results["search"] = asyncio.run(bench_search(store_path, cfg, queries))

        if not args.skip_mcp:
            print("Measuring MCP cold start...", file=sys.stderr)
            results["mcp_cold_start"] = bench_mcp_cold_start(cfg_path)

    if args.json:
        print(json.dumps(results, indent=2))
    else:
        print(fmt_results(results))


def _serialize_cfg(cfg: Config) -> str:
    """Minimal TOML serializer for the bench's Config (only fields we set)."""
    return f"""\
state_dir = "{cfg.state_dir}"
log_level = "{cfg.log_level}"

[store]
backend = "{cfg.store.backend}"
path = "{cfg.store.path}"

[embedder]
profile = "{cfg.embedder.profile}"
provider = "{cfg.embedder.provider}"
model = "{cfg.embedder.model}"
host = "{cfg.embedder.host}"
dim = {cfg.embedder.dim}

[reranker]
enabled = false
model = ""

[retrieval]
top_n = 20
top_k = 10
hybrid_alpha = 0.5

[models.smart]
alias = "smart"
provider = "ollama"
model = "llama3"

[defaults]
model = "smart"
collections = ["docs"]

[collections.docs]
name = "docs"
chunk_size = 400
chunk_overlap = 50
"""


if __name__ == "__main__":
    main()
