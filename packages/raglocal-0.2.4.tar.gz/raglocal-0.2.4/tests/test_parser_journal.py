"""Tests for raglocal.parsers.journal — JournalParser."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pytest

from raglocal.parsers.journal import JournalParser

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def make_parser() -> JournalParser:
    return JournalParser()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_date_from_frontmatter(tmp_path: Path) -> None:
    """Date should be extracted from YAML frontmatter date field."""
    entry = tmp_path / "entry.md"
    entry.write_text(
        "---\ndate: 2026-02-04\ntitle: My Day\n---\n\nToday was a good day.\n",
        encoding="utf-8",
    )
    parser = make_parser()
    doc = await parser.parse(entry)

    assert doc.metadata["date"] == "2026-02-04"


@pytest.mark.asyncio
async def test_date_from_filename(tmp_path: Path) -> None:
    """Date should be extracted from filename in YYYY-MM-DD.ext format."""
    entry = tmp_path / "2026-02-04.md"
    entry.write_text("Some journal content without frontmatter.\n", encoding="utf-8")
    parser = make_parser()
    doc = await parser.parse(entry)

    assert doc.metadata["date"] == "2026-02-04"


@pytest.mark.asyncio
async def test_date_from_filename_with_suffix(tmp_path: Path) -> None:
    """Date should be extracted from filename in YYYY-MM-DD-anything.ext format."""
    entry = tmp_path / "2026-02-04-my-entry.md"
    entry.write_text("Content of the entry.\n", encoding="utf-8")
    parser = make_parser()
    doc = await parser.parse(entry)

    assert doc.metadata["date"] == "2026-02-04"


@pytest.mark.asyncio
async def test_date_from_heading(tmp_path: Path) -> None:
    """Date should be extracted from first H1 heading containing a date string."""
    entry = tmp_path / "notes.md"
    entry.write_text("# 2026-02-04 Daily\n\nSome notes today.\n", encoding="utf-8")
    parser = make_parser()
    doc = await parser.parse(entry)

    assert doc.metadata["date"] == "2026-02-04"


@pytest.mark.asyncio
async def test_date_from_mtime_fallback(tmp_path: Path) -> None:
    """When no date signals exist, date should be based on file mtime."""
    entry = tmp_path / "random-notes.md"
    entry.write_text("Just some random notes with no date anywhere.\n", encoding="utf-8")
    parser = make_parser()
    doc = await parser.parse(entry)

    mtime_date = datetime.fromtimestamp(entry.stat().st_mtime).date().isoformat()
    assert doc.metadata["date"] == mtime_date
    # Should be a valid ISO date string
    assert len(doc.metadata["date"]) == 10
    assert doc.metadata["date"][4] == "-"


@pytest.mark.asyncio
async def test_entry_title_from_frontmatter(tmp_path: Path) -> None:
    """Entry title should come from frontmatter title field when present."""
    entry = tmp_path / "entry.md"
    entry.write_text(
        "---\ndate: 2026-02-04\ntitle: My Day\n---\n\n# Different Heading\n\nContent.\n",
        encoding="utf-8",
    )
    parser = make_parser()
    doc = await parser.parse(entry)

    assert doc.metadata["entry_title"] == "My Day"


@pytest.mark.asyncio
async def test_entry_title_from_h1(tmp_path: Path) -> None:
    """Entry title should fall back to first H1 heading if no frontmatter title."""
    entry = tmp_path / "2026-02-04.md"
    entry.write_text("# The Big Day\n\nSomething happened.\n", encoding="utf-8")
    parser = make_parser()
    doc = await parser.parse(entry)

    assert doc.metadata["entry_title"] == "The Big Day"


@pytest.mark.asyncio
async def test_entry_title_from_stem_fallback(tmp_path: Path) -> None:
    """Entry title should fall back to filename stem when no frontmatter or H1."""
    entry = tmp_path / "my-journal.txt"
    entry.write_text("Just plain text without headings.\n", encoding="utf-8")
    parser = make_parser()
    doc = await parser.parse(entry)

    assert doc.metadata["entry_title"] == "my-journal"


@pytest.mark.asyncio
async def test_default_collection_is_journal(tmp_path: Path) -> None:
    """JournalParser should always set default_collection to 'journal'."""
    entry = tmp_path / "2026-02-04.md"
    entry.write_text("Daily journal entry content.\n", encoding="utf-8")
    parser = make_parser()
    doc = await parser.parse(entry)

    assert doc.default_collection == "journal"


@pytest.mark.asyncio
async def test_chunks_use_sentence_strategy(tmp_path: Path) -> None:
    """Chunks should be produced using sentence strategy (non-empty for non-trivial text)."""
    entry = tmp_path / "2026-02-04.md"
    entry.write_text(
        "This is the first sentence. This is the second sentence. And a third one here.\n",
        encoding="utf-8",
    )
    parser = make_parser()
    doc = await parser.parse(entry)

    assert len(doc.chunks) >= 1
    assert all(c.text for c in doc.chunks)


@pytest.mark.asyncio
async def test_frontmatter_stripped_from_text(tmp_path: Path) -> None:
    """The text field should not contain raw frontmatter YAML."""
    entry = tmp_path / "entry.md"
    entry.write_text(
        "---\ndate: 2026-02-04\ntitle: My Day\n---\n\nActual journal content.\n",
        encoding="utf-8",
    )
    parser = make_parser()
    doc = await parser.parse(entry)

    assert "---" not in doc.text
    assert "Actual journal content" in doc.text
