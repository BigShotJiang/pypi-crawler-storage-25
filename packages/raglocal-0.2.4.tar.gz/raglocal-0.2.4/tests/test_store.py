"""Tests for raglocal.store."""

from __future__ import annotations

import uuid

import pytest

from raglocal.store import Chunk, SearchResult, _build_lance_filter, _point_id

# ---------------------------------------------------------------------------
# Unit tests — no Qdrant required
# ---------------------------------------------------------------------------


def test_point_id_is_deterministic() -> None:
    """Same inputs must always produce the same UUID5."""
    a = _point_id("docs", "file:///notes.md", 0)
    b = _point_id("docs", "file:///notes.md", 0)
    assert a == b


def test_point_id_is_valid_uuid() -> None:
    result = _point_id("docs", "file:///notes.md", 3)
    parsed = uuid.UUID(result)
    assert parsed.version == 5


def test_point_id_differs_by_collection() -> None:
    a = _point_id("docs", "file:///notes.md", 0)
    b = _point_id("code", "file:///notes.md", 0)
    assert a != b


def test_point_id_differs_by_chunk_idx() -> None:
    a = _point_id("docs", "file:///notes.md", 0)
    b = _point_id("docs", "file:///notes.md", 1)
    assert a != b


def test_point_id_differs_by_source_uri() -> None:
    a = _point_id("docs", "file:///a.md", 0)
    b = _point_id("docs", "file:///b.md", 0)
    assert a != b


def test_chunk_frozen() -> None:
    """Chunk is frozen — assignment must raise."""
    chunk = Chunk(
        text="hello",
        source_uri="file:///x.md",
        source_type="md",
        collection="docs",
        chunk_idx=0,
        chunk_total=1,
    )
    with pytest.raises((AttributeError, TypeError)):
        chunk.text = "other"  # type: ignore[misc]


def test_search_result_frozen() -> None:
    sr = SearchResult(text="t", score=0.9, payload={})
    with pytest.raises((AttributeError, TypeError)):
        sr.score = 0.5  # type: ignore[misc]


# ---------------------------------------------------------------------------
# _build_lance_filter unit tests
# ---------------------------------------------------------------------------


def test_build_lance_filter_none_on_empty() -> None:
    assert _build_lance_filter({}) is None


def test_build_lance_filter_id() -> None:
    result = _build_lance_filter({"id": "abc-123"})
    assert result == "id = 'abc-123'"


def test_build_lance_filter_id_escapes_quotes() -> None:
    result = _build_lance_filter({"id": "it's"})
    assert result == "id = 'it''s'"


def test_build_lance_filter_chunk_idx() -> None:
    result = _build_lance_filter({"chunk_idx": 3})
    assert result == "chunk_idx = 3"


def test_build_lance_filter_source_uri_exact() -> None:
    result = _build_lance_filter({"source_uri": "file:///foo/bar.py"})
    assert result == "source_uri = 'file:///foo/bar.py'"


def test_build_lance_filter_source_uri_escapes_quotes() -> None:
    result = _build_lance_filter({"source_uri": "file:///it's/a/path"})
    assert result == "source_uri = 'file:///it''s/a/path'"


def test_build_lance_filter_language() -> None:
    result = _build_lance_filter({"language": "python"})
    assert result == "language = 'python'"


def test_build_lance_filter_language_escapes_quotes() -> None:
    result = _build_lance_filter({"language": "c++"})
    assert result == "language = 'c++'"


def test_build_lance_filter_source_uri_and_chunk_idx() -> None:
    result = _build_lance_filter({"source_uri": "file:///foo.py", "chunk_idx": 2})
    assert result is not None
    assert "source_uri = 'file:///foo.py'" in result
    assert "chunk_idx = 2" in result
    assert " AND " in result


def test_build_lance_filter_unknown_key_returns_none() -> None:
    result = _build_lance_filter({"unknown_key": "value"})
    assert result is None


# ---------------------------------------------------------------------------
# Integration tests — QdrantStore removed in Wave 2; see test_store_lance.py
# ---------------------------------------------------------------------------
# These tests have been removed since QdrantStore no longer exists.
# LanceStore integration tests are in tests/test_store_lance.py.
