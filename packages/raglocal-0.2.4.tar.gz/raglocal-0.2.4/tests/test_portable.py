from __future__ import annotations

import zipfile
from pathlib import Path

import pytest

from raglocal.config import (
    CollectionConfig,
    Config,
    EmbedderConfig,
    ModelSpec,
    RerankerConfig,
    RetrievalConfig,
    StoreConfig,
)
from raglocal.manifest import Manifest, manifest_path_for_store
from raglocal.portable import export_archive, import_archive


def _make_cfg(store_path: Path) -> Config:
    """Build a minimal Config using store_path as the lance store directory."""
    return Config(
        state_dir=str(store_path / "state"),
        log_level="info",
        store=StoreConfig(backend="lance", path=str(store_path)),
        embedder=EmbedderConfig(
            profile="balanced",
            provider="sentence-transformers",
            model="nomic-embed-text-v1.5",
            host=None,
            dim=768,
            cache_dir=None,
        ),
        reranker=RerankerConfig(enabled=False, model=""),
        retrieval=RetrievalConfig(top_n=10, top_k=5, hybrid_alpha=0.5),
        models={"default": ModelSpec(alias="default", provider="anthropic", model="claude-3-haiku")},
        default_model="default",
        default_collections=["docs"],
        collections={
            "docs": CollectionConfig(
                name="docs",
                chunk_size=512,
                chunk_overlap=64,
                chunk_strategy="token",
            )
        },
    )


def _make_fake_corpus(store_path: Path, dim: int = 768) -> None:
    """Create a fake corpus with manifest and a fake lance table.

    The manifest is written one level above store_path (i.e. to
    manifest_path_for_store(store_path)) to match the real layout.
    """
    store_path.mkdir(parents=True, exist_ok=True)
    manifest = Manifest(
        raglocal_version="0.3.0",
        embedder_provider="sentence-transformers",
        embedder_model="nomic-embed-text-v1.5",
        embedder_dim=dim,
        store_backend="lance",
        chunk_strategy="token",
        created_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
        collections=["docs"],
        profile_name="balanced",
    )
    manifest_dir = manifest_path_for_store(store_path)
    manifest_dir.mkdir(parents=True, exist_ok=True)
    manifest.write(manifest_dir)
    # Fake lance table
    lance_dir = store_path / "docs.lance"
    lance_dir.mkdir()
    (lance_dir / "data.bin").write_bytes(b"fake lance data")


# ---------------------------------------------------------------------------
# Test 1: export creates a zip file with non-zero size
# ---------------------------------------------------------------------------

def test_export_creates_zip(tmp_path: Path) -> None:
    store_path = tmp_path / "data" / "lance"
    _make_fake_corpus(store_path)
    cfg = _make_cfg(store_path)
    output = tmp_path / "corpus.zip"

    export_archive(cfg, output)

    assert output.exists()
    assert output.stat().st_size > 0


# ---------------------------------------------------------------------------
# Test 2: zip contains raglocal.manifest.json at the root
# ---------------------------------------------------------------------------

def test_export_zip_contains_manifest(tmp_path: Path) -> None:
    store_path = tmp_path / "data" / "lance"
    _make_fake_corpus(store_path)
    cfg = _make_cfg(store_path)
    output = tmp_path / "corpus.zip"

    export_archive(cfg, output)

    with zipfile.ZipFile(output, "r") as zf:
        assert "raglocal.manifest.json" in zf.namelist()


# ---------------------------------------------------------------------------
# Test 3: zip contains run.sh with executable bit set
# ---------------------------------------------------------------------------

def test_export_zip_contains_run_sh_executable(tmp_path: Path) -> None:
    store_path = tmp_path / "data" / "lance"
    _make_fake_corpus(store_path)
    cfg = _make_cfg(store_path)
    output = tmp_path / "corpus.zip"

    export_archive(cfg, output)

    with zipfile.ZipFile(output, "r") as zf:
        names = zf.namelist()
        assert "run.sh" in names
        info = zf.getinfo("run.sh")
        unix_perms = info.external_attr >> 16
        assert unix_perms & 0o111, f"run.sh is not executable: mode {oct(unix_perms)}"


# ---------------------------------------------------------------------------
# Test 4: exporting when manifest is missing raises FileNotFoundError
# ---------------------------------------------------------------------------

def test_export_missing_manifest_raises(tmp_path: Path) -> None:
    store_path = tmp_path / "data" / "lance"
    store_path.mkdir(parents=True)  # directory exists but no manifest
    cfg = _make_cfg(store_path)
    output = tmp_path / "corpus.zip"

    with pytest.raises(FileNotFoundError, match="rag index"):
        export_archive(cfg, output)


# ---------------------------------------------------------------------------
# Test 5: export then import roundtrip preserves embedder_model
# ---------------------------------------------------------------------------

def test_import_roundtrip(tmp_path: Path) -> None:
    store_path = tmp_path / "src" / "lance"
    _make_fake_corpus(store_path)
    cfg = _make_cfg(store_path)
    output = tmp_path / "corpus.zip"

    export_archive(cfg, output)

    target = tmp_path / "dst" / "lance"
    result = import_archive(output, target)

    assert result.embedder_model == "nomic-embed-text-v1.5"


# ---------------------------------------------------------------------------
# Test 6: importing archive whose dim differs from existing manifest raises
# ---------------------------------------------------------------------------

def test_import_dim_mismatch_raises(tmp_path: Path) -> None:
    # Build source corpus with dim=768
    src_root = tmp_path / "src"
    store_path = src_root / "lance"
    _make_fake_corpus(store_path, dim=768)
    cfg = _make_cfg(store_path)
    output = tmp_path / "corpus.zip"
    export_archive(cfg, output)

    # Build target with existing manifest dim=384
    dst_root = tmp_path / "dst"
    target = dst_root / "lance"
    _make_fake_corpus(target, dim=384)

    with pytest.raises(ValueError, match="dim"):
        import_archive(output, target)


# ---------------------------------------------------------------------------
# Test 7: after import, lance files are extracted correctly
# ---------------------------------------------------------------------------

def test_import_extracts_lance_files(tmp_path: Path) -> None:
    store_path = tmp_path / "src" / "lance"
    _make_fake_corpus(store_path)
    cfg = _make_cfg(store_path)
    output = tmp_path / "corpus.zip"

    export_archive(cfg, output)

    target = tmp_path / "dst" / "lance"
    import_archive(output, target)

    extracted = target / "docs.lance" / "data.bin"
    assert extracted.exists()
    assert extracted.read_bytes() == b"fake lance data"
