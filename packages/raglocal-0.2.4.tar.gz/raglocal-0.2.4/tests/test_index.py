"""Tests for raglocal.index — index_paths pipeline."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from raglocal.index import index_paths
from raglocal.store import LanceStore

# ---------------------------------------------------------------------------
# Fixtures / fakes
# ---------------------------------------------------------------------------


class FakeEmbedder:
    """Returns fixed-dimension vectors regardless of input text."""

    dim = 4

    async def embed(self, texts: list[str]) -> list[list[float]]:
        return [[0.1, 0.2, 0.3, 0.4]] * len(texts)


class FakeStateStore:
    """In-memory state store."""

    def __init__(self) -> None:
        self._records: dict[str, tuple[int, str, str, int]] = {}

    def is_fresh(self, source_uri: str, mtime: int, content_hash: str) -> bool:
        rec = self._records.get(source_uri)
        if rec is None:
            return False
        return rec[0] == mtime and rec[1] == content_hash

    def record(
        self,
        source_uri: str,
        collection: str,
        mtime: int,
        content_hash: str,
        chunk_count: int,
    ) -> None:
        self._records[source_uri] = (mtime, content_hash, collection, chunk_count)

    def forget(self, source_uri: str) -> None:
        self._records.pop(source_uri, None)

    def list_by_collection(self, collection: str) -> list[dict[str, Any]]:
        return []

    def close(self) -> None:
        pass


@pytest.fixture
def mock_embedder() -> FakeEmbedder:
    return FakeEmbedder()


@pytest.fixture
def fake_state() -> FakeStateStore:
    return FakeStateStore()


def make_lance_store(tmp_path: Path) -> LanceStore:
    return LanceStore(str(tmp_path / "lancedb"))


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_index_markdown_file(tmp_path: Path, mock_embedder: FakeEmbedder) -> None:
    """Indexing a single .md file produces indexed==1 and store has chunks."""
    md = tmp_path / "readme.md"
    md.write_text(
        "# Hello World\n\n" + ("This is content. " * 50),
        encoding="utf-8",
    )

    store = make_lance_store(tmp_path)
    state = FakeStateStore()

    report = await index_paths(
        cfg=None,  # type: ignore[arg-type]
        embedder=mock_embedder,
        store=store,
        state=state,
        paths=[str(md)],
    )

    assert report.indexed == 1
    assert report.skipped == 0
    assert report.errors == []
    assert store.count("docs") > 0


@pytest.mark.asyncio
async def test_index_python_file(tmp_path: Path, mock_embedder: FakeEmbedder) -> None:
    """Indexing a .py file places chunks in the 'code' collection."""
    py_file = tmp_path / "main.py"
    py_file.write_text(
        "def hello():\n    print('world')\n" * 30,
        encoding="utf-8",
    )

    store = make_lance_store(tmp_path)
    state = FakeStateStore()

    report = await index_paths(
        cfg=None,  # type: ignore[arg-type]
        embedder=mock_embedder,
        store=store,
        state=state,
        paths=[str(py_file)],
    )

    assert report.indexed == 1
    assert report.errors == []
    assert "code" in report.collections
    assert store.count("code") > 0


@pytest.mark.asyncio
async def test_index_mixed_directory(tmp_path: Path, mock_embedder: FakeEmbedder) -> None:
    """Indexing a directory with .md, .py, and session .json files indexes all."""
    (tmp_path / "doc.md").write_text("# Doc\n" + "content " * 50, encoding="utf-8")
    (tmp_path / "code.py").write_text("def fn():\n    pass\n" * 30, encoding="utf-8")
    session_data = {
        "session_id": "sess-001",
        "messages": [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi there!"},
        ],
    }
    (tmp_path / "session.json").write_text(json.dumps(session_data), encoding="utf-8")

    store = make_lance_store(tmp_path)
    state = FakeStateStore()

    report = await index_paths(
        cfg=None,  # type: ignore[arg-type]
        embedder=mock_embedder,
        store=store,
        state=state,
        paths=[str(tmp_path)],
    )

    assert report.indexed == 3
    assert report.errors == []
    assert "docs" in report.collections
    assert "code" in report.collections
    assert "sessions" in report.collections


@pytest.mark.asyncio
async def test_incremental_skip(tmp_path: Path, mock_embedder: FakeEmbedder) -> None:
    """Second run without changes skips the already-indexed file."""
    md = tmp_path / "note.md"
    md.write_text("# Note\n" + "content " * 50, encoding="utf-8")

    store = make_lance_store(tmp_path)
    state = FakeStateStore()

    # First run
    report1 = await index_paths(
        cfg=None,  # type: ignore[arg-type]
        embedder=mock_embedder,
        store=store,
        state=state,
        paths=[str(md)],
    )
    assert report1.indexed == 1

    # Second run — file unchanged
    report2 = await index_paths(
        cfg=None,  # type: ignore[arg-type]
        embedder=mock_embedder,
        store=store,
        state=state,
        paths=[str(md)],
    )
    assert report2.skipped > 0
    assert report2.indexed == 0


@pytest.mark.asyncio
async def test_reindex_forces_update(tmp_path: Path, mock_embedder: FakeEmbedder) -> None:
    """reindex=True reprocesses files even when unchanged."""
    py_file = tmp_path / "app.py"
    py_file.write_text("def app():\n    pass\n" * 30, encoding="utf-8")

    store = make_lance_store(tmp_path)
    state = FakeStateStore()

    # First run
    await index_paths(
        cfg=None,  # type: ignore[arg-type]
        embedder=mock_embedder,
        store=store,
        state=state,
        paths=[str(py_file)],
    )

    # Second run with reindex=True
    report = await index_paths(
        cfg=None,  # type: ignore[arg-type]
        embedder=mock_embedder,
        store=store,
        state=state,
        paths=[str(py_file)],
        reindex=True,
    )
    assert report.indexed == 1
    assert report.skipped == 0


@pytest.mark.asyncio
async def test_index_report_aggregates(tmp_path: Path, mock_embedder: FakeEmbedder) -> None:
    """Indexing 3 files produces report.indexed == 3."""
    for i in range(3):
        (tmp_path / f"file{i}.md").write_text(
            f"# File {i}\n" + f"Content for file {i}. " * 30,
            encoding="utf-8",
        )

    store = make_lance_store(tmp_path)
    state = FakeStateStore()

    report = await index_paths(
        cfg=None,  # type: ignore[arg-type]
        embedder=mock_embedder,
        store=store,
        state=state,
        paths=[str(tmp_path)],
    )

    assert report.indexed == 3
    assert report.errors == []


@pytest.mark.asyncio
async def test_collection_override(tmp_path: Path, mock_embedder: FakeEmbedder) -> None:
    """Passing collection= overrides the parser's default_collection."""
    md = tmp_path / "doc.md"
    md.write_text("# Override\n" + "text " * 50, encoding="utf-8")

    store = make_lance_store(tmp_path)
    state = FakeStateStore()

    report = await index_paths(
        cfg=None,  # type: ignore[arg-type]
        embedder=mock_embedder,
        store=store,
        state=state,
        paths=[str(md)],
        collection="custom",
    )

    assert report.indexed == 1
    assert "custom" in report.collections
    assert store.count("custom") > 0


@pytest.mark.asyncio
async def test_unsupported_files_skipped(tmp_path: Path, mock_embedder: FakeEmbedder) -> None:
    """Files with no matching parser are silently skipped (not counted as errors)."""
    (tmp_path / "image.png").write_bytes(b"\x89PNG\r\n\x1a\n")
    (tmp_path / "data.bin").write_bytes(b"\x00\x01\x02\x03")

    store = make_lance_store(tmp_path)
    state = FakeStateStore()

    report = await index_paths(
        cfg=None,  # type: ignore[arg-type]
        embedder=mock_embedder,
        store=store,
        state=state,
        paths=[str(tmp_path)],
    )

    assert report.indexed == 0
    assert report.errors == []
