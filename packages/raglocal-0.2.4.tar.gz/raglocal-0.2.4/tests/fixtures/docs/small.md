# Introduction

This is the introduction section of the test document.
It contains some text to exercise the markdown ingestor.

## Background

The background section provides context for the main topic.
Here we describe the history and motivation behind the project.
There are several important points to consider when evaluating this approach.

### Details

This subsection goes into finer detail about the background.
Additional information is provided here for completeness.

## Main Content

This is the main content of the document.
It covers the primary subject matter in depth.
Multiple sentences are included so that chunking has enough material to work with.
The content is intentionally kept brief for testing purposes.
