"""Tests for raglocal.profiles — Block 0B."""

import pytest

from raglocal.profiles import ResolvedProfile, fallback_chain, resolve_profile

# ---------------------------------------------------------------------------
# resolve_profile — named profiles
# ---------------------------------------------------------------------------


class TestResolveProfileLean:
    def test_returns_resolved_profile(self) -> None:
        p = resolve_profile("lean")
        assert isinstance(p, ResolvedProfile)

    def test_provider(self) -> None:
        assert resolve_profile("lean").provider == "sentence-transformers"

    def test_model(self) -> None:
        assert resolve_profile("lean").model == "all-MiniLM-L6-v2"

    def test_dim(self) -> None:
        assert resolve_profile("lean").dim == 384

    def test_default_chunk_size(self) -> None:
        assert resolve_profile("lean").default_chunk_size == 512

    def test_default_chunk_overlap(self) -> None:
        assert resolve_profile("lean").default_chunk_overlap == 64

    def test_requires(self) -> None:
        assert resolve_profile("lean").requires == ["sentence-transformers"]

    def test_disk_mb(self) -> None:
        assert resolve_profile("lean").disk_mb == 90

    def test_ram_mb(self) -> None:
        assert resolve_profile("lean").ram_mb == 400


class TestResolveProfileBalanced:
    def test_returns_resolved_profile(self) -> None:
        p = resolve_profile("balanced")
        assert isinstance(p, ResolvedProfile)

    def test_provider(self) -> None:
        assert resolve_profile("balanced").provider == "sentence-transformers"

    def test_model(self) -> None:
        assert resolve_profile("balanced").model == "nomic-embed-text-v1.5"

    def test_dim(self) -> None:
        assert resolve_profile("balanced").dim == 768

    def test_default_chunk_size(self) -> None:
        assert resolve_profile("balanced").default_chunk_size == 768

    def test_default_chunk_overlap(self) -> None:
        assert resolve_profile("balanced").default_chunk_overlap == 96

    def test_requires(self) -> None:
        assert resolve_profile("balanced").requires == ["sentence-transformers"]

    def test_disk_mb(self) -> None:
        assert resolve_profile("balanced").disk_mb == 270

    def test_ram_mb(self) -> None:
        assert resolve_profile("balanced").ram_mb == 1000


class TestResolveProfilePowerful:
    def test_returns_resolved_profile(self) -> None:
        p = resolve_profile("powerful")
        assert isinstance(p, ResolvedProfile)

    def test_provider(self) -> None:
        assert resolve_profile("powerful").provider == "ollama"

    def test_model(self) -> None:
        assert resolve_profile("powerful").model == "bge-m3"

    def test_dim(self) -> None:
        assert resolve_profile("powerful").dim == 1024

    def test_default_chunk_size(self) -> None:
        assert resolve_profile("powerful").default_chunk_size == 1024

    def test_default_chunk_overlap(self) -> None:
        assert resolve_profile("powerful").default_chunk_overlap == 128

    def test_requires(self) -> None:
        assert resolve_profile("powerful").requires == ["ollama"]

    def test_disk_mb(self) -> None:
        assert resolve_profile("powerful").disk_mb == 2300

    def test_ram_mb(self) -> None:
        assert resolve_profile("powerful").ram_mb == 4000


# ---------------------------------------------------------------------------
# resolve_profile — error cases
# ---------------------------------------------------------------------------


class TestResolveProfileErrors:
    def test_custom_raises_value_error(self) -> None:
        with pytest.raises(ValueError):
            resolve_profile("custom")

    def test_custom_error_message(self) -> None:
        with pytest.raises(ValueError, match="custom"):
            resolve_profile("custom")

    def test_unknown_name_raises_value_error(self) -> None:
        with pytest.raises(ValueError):
            resolve_profile("nonexistent")

    def test_unknown_name_lists_valid_options(self) -> None:
        with pytest.raises(ValueError, match="lean"):
            resolve_profile("nonexistent")

    def test_unknown_name_message_contains_balanced(self) -> None:
        with pytest.raises(ValueError, match="balanced"):
            resolve_profile("bad_profile")

    def test_unknown_name_message_contains_powerful(self) -> None:
        with pytest.raises(ValueError, match="powerful"):
            resolve_profile("bad_profile")


# ---------------------------------------------------------------------------
# fallback_chain
# ---------------------------------------------------------------------------


class TestFallbackChain:
    def test_powerful_chain(self) -> None:
        assert fallback_chain("powerful") == ["powerful", "balanced", "lean"]

    def test_balanced_chain(self) -> None:
        assert fallback_chain("balanced") == ["balanced", "lean"]

    def test_lean_chain(self) -> None:
        assert fallback_chain("lean") == ["lean"]

    def test_custom_chain(self) -> None:
        assert fallback_chain("custom") == ["custom"]

    def test_returns_new_list_each_call(self) -> None:
        a = fallback_chain("powerful")
        b = fallback_chain("powerful")
        assert a == b
        assert a is not b

    def test_unknown_name_raises_value_error(self) -> None:
        with pytest.raises(ValueError):
            fallback_chain("nonexistent")

    def test_unknown_name_lists_valid_options(self) -> None:
        with pytest.raises(ValueError, match="lean"):
            fallback_chain("nonexistent")
