"""Tests for raglocal.parsers.docs — DocsParser."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import pytest

from raglocal.parsers.docs import DocsParser

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def make_parser() -> DocsParser:
    return DocsParser()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_markdown_parse(tmp_path: Path) -> None:
    """Markdown file with frontmatter and H1 should have text and title extracted."""
    md_file = tmp_path / "entry.md"
    md_file.write_text(
        "---\ntitle: My Title\nauthor: Alice\n---\n# First Heading\n\nSome content here.\n",
        encoding="utf-8",
    )
    parser = make_parser()
    doc = await parser.parse(md_file)

    # Text should have frontmatter stripped (clean text)
    assert "First Heading" in doc.text or "Some content here" in doc.text
    assert doc.metadata["title"] == "My Title"
    assert doc.default_collection == "docs"
    assert doc.metadata["source"] == str(md_file)


@pytest.mark.asyncio
async def test_markdown_parse_h1_title_fallback(tmp_path: Path) -> None:
    """Markdown without frontmatter title should use first H1 as title."""
    md_file = tmp_path / "entry.md"
    md_file.write_text("# Hello World\n\nSome text.\n", encoding="utf-8")
    parser = make_parser()
    doc = await parser.parse(md_file)

    assert doc.metadata["title"] == "Hello World"


@pytest.mark.asyncio
async def test_txt_parse(tmp_path: Path) -> None:
    """Plain text file should have its content preserved."""
    txt_file = tmp_path / "note.txt"
    content = "This is plain text content.\nLine two of the file.\n"
    txt_file.write_text(content, encoding="utf-8")
    parser = make_parser()
    doc = await parser.parse(txt_file)

    assert "plain text content" in doc.text
    assert doc.default_collection == "docs"
    assert doc.metadata["source"] == str(txt_file)


@pytest.mark.asyncio
async def test_json_parse(tmp_path: Path) -> None:
    """JSON file should be parsed and text should be pretty-printed JSON."""
    json_file = tmp_path / "data.json"
    data = {"key": "value", "number": 42, "list": [1, 2, 3]}
    json_file.write_text(json.dumps(data), encoding="utf-8")
    parser = make_parser()
    doc = await parser.parse(json_file)

    # Should be pretty-printed
    parsed_back = json.loads(doc.text)
    assert parsed_back == data
    # Check it's indented (pretty-printed)
    assert "\n" in doc.text
    assert doc.default_collection == "docs"


@pytest.mark.asyncio
async def test_yaml_parse(tmp_path: Path) -> None:
    """YAML file should be parsed and text should be canonical YAML."""
    try:
        import yaml
    except ImportError:
        pytest.skip("pyyaml not installed")

    yaml_file = tmp_path / "config.yaml"
    yaml_file.write_text("name: test\nvalue: 123\nflag: true\n", encoding="utf-8")
    parser = make_parser()
    doc = await parser.parse(yaml_file)

    # Text should be valid YAML that round-trips
    loaded = yaml.safe_load(doc.text)
    assert loaded["name"] == "test"
    assert loaded["value"] == 123
    assert doc.default_collection == "docs"


@pytest.mark.asyncio
async def test_pdf_parse(tmp_path: Path) -> None:
    """PDF file created with pypdf should be parseable and return non-empty text."""
    try:
        from pypdf import PdfWriter
    except ImportError:
        pytest.skip("pypdf not installed")

    pdf_path = tmp_path / "test.pdf"

    # Create a minimal PDF with a text page
    writer = PdfWriter()
    writer.add_blank_page(width=200, height=200)
    with open(pdf_path, "wb") as f:
        writer.write(f)

    parser = make_parser()
    doc = await parser.parse(pdf_path)

    # Even a blank page returns an empty string — text may be empty or not
    # The key is that it doesn't raise and returns a ParsedDocument
    assert doc.default_collection == "docs"
    assert doc.metadata["source"] == str(pdf_path)


@pytest.mark.asyncio
async def test_docx_parse(tmp_path: Path) -> None:
    """DOCX file created with python-docx should have text extracted."""
    try:
        import docx
    except ImportError:
        pytest.skip("python-docx not installed")

    docx_path = tmp_path / "test.docx"
    doc_obj = docx.Document()
    doc_obj.add_paragraph("Hello from docx paragraph one.")
    doc_obj.add_paragraph("Second paragraph content here.")
    doc_obj.save(str(docx_path))

    parser = make_parser()
    doc = await parser.parse(docx_path)

    assert "Hello from docx" in doc.text
    assert "Second paragraph" in doc.text
    assert doc.default_collection == "docs"


@pytest.mark.asyncio
async def test_missing_dep_actionable_error(tmp_path: Path) -> None:
    """When python-docx is unavailable, ImportError message mentions pip install."""
    docx_path = tmp_path / "test.docx"
    docx_path.write_bytes(b"fake docx content")

    parser = make_parser()

    with patch("builtins.__import__", side_effect=ImportError("No module named 'docx'")):
        # The import happens lazily inside _read_docx; we test the error propagation
        pass

    # Directly test _read_docx with mocked import
    import raglocal.parsers.docs as docs_mod

    def fake_read_docx(path: Path) -> str:
        raise ImportError(
            "DOCX support requires python-docx: pip install raglocal[office] or pip install python-docx"
        )

    with patch.object(docs_mod, "_read_docx", fake_read_docx), pytest.raises(ImportError, match="pip install"):
        await parser.parse(docx_path)
