"""Tests for the retriever module."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from raglocal.config import Config, RerankerConfig, RetrievalConfig
from raglocal.retrieve import RetrievalContext, Retriever
from raglocal.store import SearchResult


class FakeEmbedder:
    """Fake embedder that returns a constant vector."""

    def __init__(self, dim: int = 1024) -> None:
        """Initialize with embedding dimension."""
        self._dim = dim

    @property
    def dim(self) -> int:
        """Return embedding dimension."""
        return self._dim

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Return constant vector of all 0.1 values."""
        return [[0.1] * self._dim for _ in texts]


class FakeStore:
    """Fake store that returns pre-configured search results."""

    def __init__(self, results_by_collection: dict[str, list[SearchResult]] | None = None) -> None:
        """Initialize with optional results per collection.

        Args:
            results_by_collection: Dict mapping collection name to list of SearchResults.
        """
        self.results_by_collection = results_by_collection or {}

    async def search(
        self,
        collection: str,
        query_dense: list[float],
        top_n: int,
        filters: dict | None = None,  # type: ignore[type-arg]
    ) -> list[SearchResult]:
        """Return pre-configured results for the collection, limited to top_n."""
        results = self.results_by_collection.get(collection, [])
        return results[:top_n]

    async def hybrid_search(
        self,
        collection: str,
        query_dense: list[float],
        query_text: str,
        top_n: int = 20,
        filters: dict | None = None,  # type: ignore[type-arg]
        alpha: float = 0.5,
    ) -> list[SearchResult]:
        """Return pre-configured results for the collection, limited to top_n."""
        results = self.results_by_collection.get(collection, [])
        return results[:top_n]


def _make_config(
    top_n: int = 20,
    top_k: int = 5,
    reranker_enabled: bool = False,
) -> Config:
    """Create a Config mock for testing."""
    cfg = MagicMock(spec=Config)
    cfg.retrieval = RetrievalConfig(
        top_n=top_n,
        top_k=top_k,
        hybrid_alpha=0.5,
    )
    cfg.reranker = RerankerConfig(enabled=reranker_enabled, model="bge-reranker-v2-m3")
    return cfg


@pytest.mark.asyncio
async def test_retrieve_single_collection() -> None:
    """Test retrieval from a single collection."""
    # Setup
    embedder = FakeEmbedder(dim=1024)
    results = [
        SearchResult(text="chunk1", score=0.95, payload={"source_uri": "file1.md"}),
        SearchResult(text="chunk2", score=0.85, payload={"source_uri": "file2.md"}),
    ]
    store = FakeStore({"docs": results})
    cfg = _make_config(top_n=20, top_k=5)
    retriever = Retriever(embedder, store, cfg)

    # Act
    ctx = await retriever.retrieve("test query", ["docs"])

    # Assert
    assert ctx.query == "test query"
    assert ctx.collections == ["docs"]
    assert len(ctx.results) == 2
    assert ctx.results[0].score == 0.95
    assert ctx.results[1].score == 0.85


@pytest.mark.asyncio
async def test_retrieve_multiple_collections_merged() -> None:
    """Test retrieval from multiple collections with result merging."""
    # Setup
    embedder = FakeEmbedder(dim=1024)
    docs_results = [
        SearchResult(text="doc1", score=0.90, payload={"source_uri": "file1.md"}),
        SearchResult(text="doc2", score=0.80, payload={"source_uri": "file2.md"}),
    ]
    code_results = [
        SearchResult(text="code1", score=0.88, payload={"source_uri": "file3.py"}),
        SearchResult(text="code2", score=0.75, payload={"source_uri": "file4.py"}),
    ]
    store = FakeStore({"docs": docs_results, "code": code_results})
    cfg = _make_config(top_n=20, top_k=5)
    retriever = Retriever(embedder, store, cfg)

    # Act
    ctx = await retriever.retrieve("test query", ["docs", "code"])

    # Assert
    assert ctx.query == "test query"
    assert ctx.collections == ["docs", "code"]
    assert len(ctx.results) == 4  # All 4 results
    # Results should be sorted by score desc
    assert ctx.results[0].score == 0.90
    assert ctx.results[1].score == 0.88
    assert ctx.results[2].score == 0.80
    assert ctx.results[3].score == 0.75


@pytest.mark.asyncio
async def test_retrieve_respects_top_k() -> None:
    """Test that top_k parameter limits final result count."""
    # Setup
    embedder = FakeEmbedder(dim=1024)
    results = [
        SearchResult(text="chunk1", score=0.95, payload={}),
        SearchResult(text="chunk2", score=0.90, payload={}),
        SearchResult(text="chunk3", score=0.85, payload={}),
        SearchResult(text="chunk4", score=0.80, payload={}),
        SearchResult(text="chunk5", score=0.75, payload={}),
    ]
    store = FakeStore({"docs": results})
    cfg = _make_config(top_n=20, top_k=3)
    retriever = Retriever(embedder, store, cfg)

    # Act
    ctx = await retriever.retrieve("test query", ["docs"])

    # Assert
    assert len(ctx.results) == 3
    assert ctx.results[0].text == "chunk1"
    assert ctx.results[2].text == "chunk3"


@pytest.mark.asyncio
async def test_retrieve_respects_top_n() -> None:
    """Test that top_n limits results per collection before merge."""
    # Setup
    embedder = FakeEmbedder(dim=1024)
    results = [
        SearchResult(text="chunk1", score=0.95, payload={}),
        SearchResult(text="chunk2", score=0.90, payload={}),
        SearchResult(text="chunk3", score=0.85, payload={}),
        SearchResult(text="chunk4", score=0.80, payload={}),
    ]
    store = FakeStore({"docs": results})
    cfg = _make_config(top_n=2, top_k=10)
    retriever = Retriever(embedder, store, cfg)

    # Act
    ctx = await retriever.retrieve("test query", ["docs"], top_n=2)

    # Assert
    # FakeStore will limit to top_n=2 before returning
    assert len(ctx.results) == 2
    assert ctx.results[0].text == "chunk1"
    assert ctx.results[1].text == "chunk2"


@pytest.mark.asyncio
async def test_retrieve_with_explicit_args_override_cfg() -> None:
    """Test that explicit top_n/top_k args override config."""
    # Setup
    embedder = FakeEmbedder(dim=1024)
    results = [
        SearchResult(text="chunk1", score=0.95, payload={}),
        SearchResult(text="chunk2", score=0.90, payload={}),
        SearchResult(text="chunk3", score=0.85, payload={}),
        SearchResult(text="chunk4", score=0.80, payload={}),
        SearchResult(text="chunk5", score=0.75, payload={}),
    ]
    store = FakeStore({"docs": results})
    cfg = _make_config(top_n=20, top_k=5)
    retriever = Retriever(embedder, store, cfg)

    # Act
    ctx = await retriever.retrieve("test query", ["docs"], top_n=20, top_k=2)

    # Assert
    assert len(ctx.results) == 2
    assert ctx.results[0].text == "chunk1"
    assert ctx.results[1].text == "chunk2"


@pytest.mark.asyncio
async def test_retrieve_empty_results() -> None:
    """Test retrieval when no results are found."""
    # Setup
    embedder = FakeEmbedder(dim=1024)
    store = FakeStore({"docs": []})
    cfg = _make_config(top_n=20, top_k=5)
    retriever = Retriever(embedder, store, cfg)

    # Act
    ctx = await retriever.retrieve("test query", ["docs"])

    # Assert
    assert ctx.query == "test query"
    assert ctx.collections == ["docs"]
    assert len(ctx.results) == 0


@pytest.mark.asyncio
async def test_retrieve_multiple_collections_partial_overlap() -> None:
    """Test overlapping high-scoring results across collections are merged correctly."""
    # Setup
    embedder = FakeEmbedder(dim=1024)
    docs_results = [
        SearchResult(text="doc_high", score=0.95, payload={"col": "docs"}),
        SearchResult(text="doc_mid", score=0.70, payload={"col": "docs"}),
    ]
    code_results = [
        SearchResult(text="code_high", score=0.92, payload={"col": "code"}),
        SearchResult(text="code_low", score=0.60, payload={"col": "code"}),
    ]
    store = FakeStore({"docs": docs_results, "code": code_results})
    cfg = _make_config(top_n=20, top_k=3)
    retriever = Retriever(embedder, store, cfg)

    # Act
    ctx = await retriever.retrieve("test query", ["docs", "code"])

    # Assert
    assert len(ctx.results) == 3  # top_k=3
    assert ctx.results[0].text == "doc_high"  # 0.95
    assert ctx.results[1].text == "code_high"  # 0.92
    assert ctx.results[2].text == "doc_mid"  # 0.70


@pytest.mark.asyncio
async def test_retrieval_context_dataclass() -> None:
    """Test RetrievalContext dataclass creation and attributes."""
    results = [SearchResult(text="test", score=0.9, payload={})]
    ctx = RetrievalContext(query="q", collections=["c"], results=results)

    assert ctx.query == "q"
    assert ctx.collections == ["c"]
    assert len(ctx.results) == 1
    assert ctx.results[0].score == 0.9
