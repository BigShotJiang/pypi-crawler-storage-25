"""Tests for hybrid BM25+dense retrieval (B6)."""

from __future__ import annotations

import pytest

from raglocal.config import RetrievalConfig
from raglocal.retrieve import Retriever
from raglocal.store import SearchResult


class FakeEmbedder:
    """Fake embedder returning a constant vector."""

    def __init__(self, dim: int = 8) -> None:
        self._dim = dim

    @property
    def dim(self) -> int:
        return self._dim

    async def embed(self, texts: list[str]) -> list[list[float]]:
        return [[0.1] * self._dim for _ in texts]


class CapturingStore:
    """Fake store that records calls to hybrid_search and returns configured results."""

    def __init__(self, results: list[SearchResult] | None = None) -> None:
        self.calls: list[dict] = []  # type: ignore[type-arg]
        self._results = results or []

    async def hybrid_search(
        self,
        collection: str,
        query_dense: list[float],
        query_text: str,
        top_n: int = 20,
        filters: dict | None = None,  # type: ignore[type-arg]
        alpha: float = 0.5,
    ) -> list[SearchResult]:
        self.calls.append(
            {
                "collection": collection,
                "query_dense": query_dense,
                "query_text": query_text,
                "top_n": top_n,
                "filters": filters,
                "alpha": alpha,
            }
        )
        return self._results[:top_n]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_hybrid_search_called_with_dense_and_text() -> None:
    """Retriever must call hybrid_search with both query_dense and query_text."""
    store = CapturingStore(results=[SearchResult(text="chunk1", score=0.9, payload={})])
    cfg = RetrievalConfig(top_n=10, top_k=5, hybrid_alpha=0.6)
    retriever = Retriever(FakeEmbedder(), store, cfg)

    await retriever.retrieve("hello world", ["docs"])

    assert len(store.calls) == 1
    call = store.calls[0]
    # dense vector must be present and non-empty
    assert isinstance(call["query_dense"], list)
    assert len(call["query_dense"]) > 0
    # query text must be forwarded verbatim
    assert call["query_text"] == "hello world"


@pytest.mark.asyncio
async def test_alpha_forwarded_from_config() -> None:
    """hybrid_alpha from RetrievalConfig must be forwarded to hybrid_search."""
    store = CapturingStore()
    cfg = RetrievalConfig(top_n=10, top_k=5, hybrid_alpha=0.3)
    retriever = Retriever(FakeEmbedder(), store, cfg)

    await retriever.retrieve("query", ["col"])

    assert store.calls[0]["alpha"] == pytest.approx(0.3)


@pytest.mark.asyncio
async def test_results_returned_score_descending() -> None:
    """Final results must be sorted by score descending."""
    results = [
        SearchResult(text="low", score=0.5, payload={}),
        SearchResult(text="high", score=0.95, payload={}),
        SearchResult(text="mid", score=0.75, payload={}),
    ]
    store = CapturingStore(results=results)
    cfg = RetrievalConfig(top_n=10, top_k=10, hybrid_alpha=0.5)
    retriever = Retriever(FakeEmbedder(), store, cfg)

    ctx = await retriever.retrieve("query", ["col"])

    scores = [r.score for r in ctx.results]
    assert scores == sorted(scores, reverse=True)


@pytest.mark.asyncio
async def test_top_k_limits_final_results() -> None:
    """top_k must limit the number of results returned."""
    results = [SearchResult(text=f"c{i}", score=1.0 - i * 0.1, payload={}) for i in range(6)]
    store = CapturingStore(results=results)
    cfg = RetrievalConfig(top_n=10, top_k=3, hybrid_alpha=0.5)
    retriever = Retriever(FakeEmbedder(), store, cfg)

    ctx = await retriever.retrieve("query", ["col"])

    assert len(ctx.results) == 3


@pytest.mark.asyncio
async def test_alpha_0_uses_text_side() -> None:
    """alpha=0.0 must still be forwarded (pure sparse)."""
    store = CapturingStore()
    cfg = RetrievalConfig(top_n=5, top_k=2, hybrid_alpha=0.0)
    retriever = Retriever(FakeEmbedder(), store, cfg)

    await retriever.retrieve("test", ["col"])

    assert store.calls[0]["alpha"] == pytest.approx(0.0)


@pytest.mark.asyncio
async def test_alpha_1_uses_dense_side() -> None:
    """alpha=1.0 must still be forwarded (pure dense)."""
    store = CapturingStore()
    cfg = RetrievalConfig(top_n=5, top_k=2, hybrid_alpha=1.0)
    retriever = Retriever(FakeEmbedder(), store, cfg)

    await retriever.retrieve("test", ["col"])

    assert store.calls[0]["alpha"] == pytest.approx(1.0)


@pytest.mark.asyncio
async def test_multiple_collections_all_searched() -> None:
    """hybrid_search must be called once per collection."""
    store = CapturingStore(results=[SearchResult(text="x", score=0.8, payload={})])
    cfg = RetrievalConfig(top_n=10, top_k=10, hybrid_alpha=0.5)
    retriever = Retriever(FakeEmbedder(), store, cfg)

    await retriever.retrieve("query", ["col_a", "col_b", "col_c"])

    called_collections = [c["collection"] for c in store.calls]
    assert called_collections == ["col_a", "col_b", "col_c"]
