"""Tests for the CLI index and debug commands."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from typer.testing import CliRunner

from cli import app
from raglocal.config import (
    CollectionConfig,
    Config,
    EmbedderConfig,
    ModelSpec,
    RerankerConfig,
    RetrievalConfig,
    StoreConfig,
)

runner = CliRunner()


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_config() -> Config:
    """Create a minimal test config with all supported collections."""
    return Config(
        state_dir="/tmp/raglocal",
        log_level="info",
        store=StoreConfig(backend="lance", path="/tmp/raglocal/lance"),
        embedder=EmbedderConfig(
            profile="custom", provider="ollama", model="bge-m3", host="http://localhost:11434", dim=1024, cache_dir=None
        ),
        reranker=RerankerConfig(enabled=False, model="bge-reranker-v2-m3"),
        retrieval=RetrievalConfig(top_n=20, top_k=5, hybrid_alpha=0.5),
        models={
            "smart": ModelSpec(alias="smart", provider="ollama", model="qwen3:32b"),
            "fast": ModelSpec(alias="fast", provider="ollama", model="phi4:latest"),
        },
        default_model="smart",
        default_collections=["docs"],
        collections={
            "docs": CollectionConfig(name="docs", chunk_size=800, chunk_overlap=100),
            "code": CollectionConfig(name="code", chunk_size=500, chunk_overlap=50),
            "web": CollectionConfig(name="web", chunk_size=800, chunk_overlap=100),
            "sessions": CollectionConfig(name="sessions", chunk_size=600, chunk_overlap=50),
        },
    )


# ---------------------------------------------------------------------------
# index command
# ---------------------------------------------------------------------------


def test_index_help() -> None:
    """Test that 'rag index --help' shows expected help text."""
    result = runner.invoke(app, ["index", "--help"])
    assert result.exit_code == 0
    assert "index" in result.stdout.lower()


def test_index_command(mock_config: Config) -> None:
    """Test 'rag index' calls index_paths with correct args."""
    from raglocal.index import IngestReport

    mock_embedder = MagicMock()
    mock_embedder.dim = 1024
    mock_embedder.aclose = AsyncMock()
    mock_store = MagicMock()
    mock_state = MagicMock()
    mock_state.close = MagicMock()

    mock_report = IngestReport(indexed=5, skipped=2)

    async_mock = AsyncMock(return_value=mock_report)
    with (
        patch("cli.load_config", return_value=mock_config),
        patch("cli._load_services", return_value=(mock_embedder, mock_store, mock_state)),
        patch("cli.index_paths", async_mock),
    ):
        result = runner.invoke(app, ["index", "/tmp/test.md"])
        assert result.exit_code == 0
        async_mock.assert_called_once()
        call_kwargs = async_mock.call_args
        # Verify paths were passed
        assert "/tmp/test.md" in call_kwargs[0][4]  # positional paths arg
        assert "Indexed 5" in result.stdout or "indexed" in result.stdout.lower()


def test_index_command_with_collection(mock_config: Config) -> None:
    """Test 'rag index' with --collection flag."""
    from raglocal.index import IngestReport

    mock_embedder = MagicMock()
    mock_embedder.dim = 1024
    mock_embedder.aclose = AsyncMock()
    mock_store = MagicMock()
    mock_state = MagicMock()
    mock_state.close = MagicMock()

    mock_report = IngestReport(indexed=3, skipped=0)

    async_mock = AsyncMock(return_value=mock_report)
    with (
        patch("cli.load_config", return_value=mock_config),
        patch("cli._load_services", return_value=(mock_embedder, mock_store, mock_state)),
        patch("cli.index_paths", async_mock),
    ):
        result = runner.invoke(app, ["index", "/tmp/test.md", "--collection", "docs"])
        assert result.exit_code == 0
        async_mock.assert_called_once()
        call_kwargs = async_mock.call_args[1]
        assert call_kwargs.get("collection") == "docs"


def test_index_config_error() -> None:
    """Test 'rag index' with config error."""
    with patch("cli.load_config", side_effect=FileNotFoundError("Config not found")):
        result = runner.invoke(app, ["index", "/tmp/test.md"])
        assert result.exit_code == 2


def test_index_service_error(mock_config: Config) -> None:
    """Test 'rag index' when services are unreachable."""
    with (
        patch("cli.load_config", return_value=mock_config),
        patch("cli._load_services", side_effect=Exception("Connection failed")),
    ):
        result = runner.invoke(app, ["index", "/tmp/test.md"])
        assert result.exit_code == 3


# ---------------------------------------------------------------------------
# debug command
# ---------------------------------------------------------------------------


def test_debug_help() -> None:
    """Test that 'rag debug --help' shows expected help text."""
    result = runner.invoke(app, ["debug", "--help"])
    assert result.exit_code == 0
    assert "debug" in result.stdout.lower()


def test_debug_command_outputs_to_stderr(mock_config: Config) -> None:
    """Test 'rag debug' outputs results to stderr, not stdout."""
    from raglocal.retrieve import RetrievalContext
    from raglocal.store import SearchResult

    mock_embedder = MagicMock()
    mock_embedder.dim = 1024
    mock_store = MagicMock()
    mock_state = MagicMock()

    mock_sr = SearchResult(
        text="This is a test chunk of text.",
        score=0.95,
        payload={"source_uri": "file:///tmp/test.md"},
    )
    mock_ctx = RetrievalContext(
        query="test query",
        collections=["docs"],
        results=[mock_sr],
    )

    mock_retriever = MagicMock()
    mock_retriever.retrieve = AsyncMock(return_value=mock_ctx)

    with (
        patch("cli.load_config", return_value=mock_config),
        patch("cli._load_services", return_value=(mock_embedder, mock_store, mock_state)),
        patch("cli.Retriever", return_value=mock_retriever),
    ):
        result = runner.invoke(app, ["debug", "test query"])
        # debug outputs to stderr — stdout should be empty or minimal
        assert result.exit_code == 0
        # The CliRunner mix_stderr=False would separate them, but by default they're mixed
        # What matters is no crash and exit_code == 0


def test_debug_config_error() -> None:
    """Test 'rag debug' with config error."""
    with patch("cli.load_config", side_effect=FileNotFoundError("Config not found")):
        result = runner.invoke(app, ["debug", "test query"])
        assert result.exit_code == 2


def test_debug_service_error(mock_config: Config) -> None:
    """Test 'rag debug' when services are unreachable."""
    with (
        patch("cli.load_config", return_value=mock_config),
        patch("cli._load_services", side_effect=Exception("Connection failed")),
    ):
        result = runner.invoke(app, ["debug", "test query"])
        assert result.exit_code == 3
