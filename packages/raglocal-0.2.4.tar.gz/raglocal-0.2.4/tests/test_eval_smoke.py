"""Smoke tests for eval harness."""

import pytest

from tests.eval_harness import run_eval


@pytest.mark.asyncio
async def test_eval_smoke():
    """Smoke test: golden set evaluation with no retriever (None path).

    Verifies eval harness runs without errors when no live store is present.
    """
    metrics = await run_eval(retriever=None, top_k=5)
    assert metrics["recall_at_k"] == 0.0
    assert metrics["keyword_hit_rate"] == 0.0


@pytest.mark.asyncio
async def test_eval_no_retriever():
    """Unit test: graceful handling when no retriever is available.

    This test does NOT require live dependencies and verifies that run_eval
    returns sensible defaults (0.0 metrics) when retriever is None.
    """
    metrics = await run_eval(retriever=None)
    assert metrics["recall_at_k"] == 0.0
    assert metrics["keyword_hit_rate"] == 0.0
