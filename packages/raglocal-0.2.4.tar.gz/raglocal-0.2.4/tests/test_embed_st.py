from __future__ import annotations

import asyncio
import os
from unittest.mock import MagicMock, patch

import numpy as np
import pytest

from raglocal.embed import SentenceTransformersEmbedder

# ---------------------------------------------------------------------------
# Shared fixture
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_st_module():
    """Patches sentence_transformers so no model is downloaded."""
    mock_model = MagicMock()
    mock_model.get_sentence_embedding_dimension.return_value = 384
    mock_model.encode.return_value = np.array([[0.1] * 384, [0.2] * 384])

    with patch.dict(
        "sys.modules",
        {"sentence_transformers": MagicMock(SentenceTransformer=MagicMock(return_value=mock_model))},
    ):
        yield mock_model


# ---------------------------------------------------------------------------
# Unit tests
# ---------------------------------------------------------------------------


def test_model_is_none_before_embed() -> None:
    """_model must be None before any embed() call (lazy loading not triggered)."""
    embedder = SentenceTransformersEmbedder("all-MiniLM-L6-v2", dim=384)
    assert embedder._model is None


@pytest.mark.asyncio
async def test_lazy_load_on_first_embed(mock_st_module: MagicMock) -> None:
    """After the first embed() call _model should be populated."""
    embedder = SentenceTransformersEmbedder("all-MiniLM-L6-v2", dim=384)
    assert embedder._model is None

    await embedder.embed(["hello", "world"])

    assert embedder._model is not None


@pytest.mark.asyncio
async def test_concurrent_first_calls_load_once(mock_st_module: MagicMock) -> None:
    """Two concurrent embed() calls must instantiate the model exactly once."""
    embedder = SentenceTransformersEmbedder("all-MiniLM-L6-v2", dim=384)

    await asyncio.gather(
        embedder.embed(["hello", "world"]),
        embedder.embed(["foo", "bar"]),
    )

    import sys

    st_module = sys.modules["sentence_transformers"]
    assert st_module.SentenceTransformer.call_count == 1


@pytest.mark.asyncio
async def test_dim_mismatch_raises(mock_st_module: MagicMock) -> None:
    """embed() must raise ValueError when model dim != configured dim."""
    # Model fixture reports 384; configure embedder with wrong dim
    embedder = SentenceTransformersEmbedder("all-MiniLM-L6-v2", dim=768)

    with pytest.raises(ValueError, match="embedding dimension"):
        await embedder.embed(["hello"])


@pytest.mark.asyncio
async def test_embed_returns_correct_shape(mock_st_module: MagicMock) -> None:
    """embed() must return list[list[float]] with the expected shape."""
    embedder = SentenceTransformersEmbedder("all-MiniLM-L6-v2", dim=384)

    result = await embedder.embed(["hello", "world"])

    assert isinstance(result, list)
    assert len(result) == 2
    assert all(isinstance(vec, list) for vec in result)
    assert all(isinstance(v, float) for vec in result for v in vec)
    assert all(len(vec) == 384 for vec in result)


@pytest.mark.asyncio
async def test_aclose_noop() -> None:
    """aclose() must complete without raising any exception."""
    embedder = SentenceTransformersEmbedder("all-MiniLM-L6-v2", dim=384)
    await embedder.aclose()  # should not raise


# ---------------------------------------------------------------------------
# Integration test (opt-in via env var)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@pytest.mark.skipif(
    not os.environ.get("RAGKIT_TEST_ST"),
    reason="Set RAGKIT_TEST_ST=1 to run integration tests (downloads model)",
)
async def test_real_model_integration() -> None:
    embedder = SentenceTransformersEmbedder("all-MiniLM-L6-v2", dim=384)
    results = await embedder.embed(["hello", "world", "foo"])
    assert len(results) == 3
    assert len(results[0]) == 384
