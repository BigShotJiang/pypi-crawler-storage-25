from __future__ import annotations

import json
from pathlib import Path

import pytest

from raglocal.manifest import Manifest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_manifest(**overrides) -> Manifest:
    defaults = dict(
        raglocal_version="0.2.0",
        embedder_provider="ollama",
        embedder_model="nomic-embed-text",
        embedder_dim=768,
        store_backend="lance",
        chunk_strategy="fixed",
        created_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
        collections=["docs", "code"],
    )
    defaults.update(overrides)
    return Manifest(**defaults)


# ---------------------------------------------------------------------------
# Test 1: Roundtrip write → read returns identical Manifest
# ---------------------------------------------------------------------------

def test_roundtrip(tmp_path: Path) -> None:
    m = _make_manifest()
    m.write(tmp_path)
    loaded = Manifest.read(tmp_path)
    assert loaded == m


# ---------------------------------------------------------------------------
# Test 2: Missing file returns None
# ---------------------------------------------------------------------------

def test_missing_file_returns_none(tmp_path: Path) -> None:
    result = Manifest.read(tmp_path)
    assert result is None


# ---------------------------------------------------------------------------
# Test 3: Malformed JSON raises ValueError
# ---------------------------------------------------------------------------

def test_malformed_json_raises(tmp_path: Path) -> None:
    manifest_file = tmp_path / "raglocal.manifest.json"
    manifest_file.write_text("{this is not valid json}", encoding="utf-8")
    with pytest.raises(ValueError, match="Malformed JSON"):
        Manifest.read(tmp_path)


# ---------------------------------------------------------------------------
# Test 4: embedder_dim mismatch detected (hard rule)
# ---------------------------------------------------------------------------

def test_validate_compat_dim_mismatch() -> None:
    m1 = _make_manifest(embedder_dim=768)
    m2 = _make_manifest(embedder_dim=1536)
    reasons = m1.validate_compat(m2)
    assert any("embedder_dim" in r for r in reasons)
    # Must not be a soft/warning reason
    hard_reasons = [r for r in reasons if not r.startswith("warning:")]
    assert any("embedder_dim" in r for r in hard_reasons)


# ---------------------------------------------------------------------------
# Test 5: embedder_model mismatch detected (hard rule)
# ---------------------------------------------------------------------------

def test_validate_compat_model_mismatch() -> None:
    m1 = _make_manifest(embedder_model="nomic-embed-text")
    m2 = _make_manifest(embedder_model="mxbai-embed-large")
    reasons = m1.validate_compat(m2)
    hard_reasons = [r for r in reasons if not r.startswith("warning:")]
    assert any("embedder_model" in r for r in hard_reasons)


# ---------------------------------------------------------------------------
# Test 6: Major version mismatch detected (hard rule)
# ---------------------------------------------------------------------------

def test_validate_compat_major_version_mismatch() -> None:
    m1 = _make_manifest(raglocal_version="1.0.0")
    m2 = _make_manifest(raglocal_version="2.0.0")
    reasons = m1.validate_compat(m2)
    hard_reasons = [r for r in reasons if not r.startswith("warning:")]
    assert any("major" in r for r in hard_reasons)


# ---------------------------------------------------------------------------
# Test 7: Minor/patch version mismatch passes (no hard error)
# ---------------------------------------------------------------------------

def test_validate_compat_minor_version_no_error() -> None:
    m1 = _make_manifest(raglocal_version="0.2.0")
    m2 = _make_manifest(raglocal_version="0.2.1")
    reasons = m1.validate_compat(m2)
    hard_reasons = [r for r in reasons if not r.startswith("warning:")]
    # No hard incompatibilities for minor/patch differences
    assert not hard_reasons


# ---------------------------------------------------------------------------
# Test 8: chunk_strategy mismatch is soft (warning, not a hard failure)
# ---------------------------------------------------------------------------

def test_validate_compat_chunk_strategy_is_soft_warning() -> None:
    m1 = _make_manifest(chunk_strategy="fixed")
    m2 = _make_manifest(chunk_strategy="sentence")
    reasons = m1.validate_compat(m2)
    # Must have at least one warning reason
    warning_reasons = [r for r in reasons if r.startswith("warning:")]
    assert warning_reasons
    assert any("chunk_strategy" in r for r in warning_reasons)
    # Must not have any hard reason for chunk_strategy
    hard_reasons = [r for r in reasons if not r.startswith("warning:")]
    assert not any("chunk_strategy" in r for r in hard_reasons)


# ---------------------------------------------------------------------------
# Test 9: collections list is preserved through roundtrip
# ---------------------------------------------------------------------------

def test_collections_preserved_in_roundtrip(tmp_path: Path) -> None:
    collections = ["alpha", "beta", "gamma"]
    m = _make_manifest(collections=collections)
    m.write(tmp_path)
    loaded = Manifest.read(tmp_path)
    assert loaded is not None
    assert loaded.collections == collections


# ---------------------------------------------------------------------------
# Test 10: Missing required keys raises ValueError
# ---------------------------------------------------------------------------

def test_missing_required_key_raises(tmp_path: Path) -> None:
    manifest_file = tmp_path / "raglocal.manifest.json"
    # Write a JSON object missing 'embedder_dim'
    data = {
        "raglocal_version": "0.1.0",
        "embedder_provider": "ollama",
        "embedder_model": "nomic-embed-text",
        # embedder_dim intentionally omitted
        "store_backend": "lance",
        "chunk_strategy": "fixed",
        "created_at": "2026-01-01T00:00:00Z",
        "updated_at": "2026-01-01T00:00:00Z",
        "collections": [],
    }
    manifest_file.write_text(json.dumps(data), encoding="utf-8")
    with pytest.raises(ValueError, match="missing required keys"):
        Manifest.read(tmp_path)


# ---------------------------------------------------------------------------
# Test 11: No incompatibilities when manifests are identical
# ---------------------------------------------------------------------------

def test_validate_compat_identical_manifests() -> None:
    m = _make_manifest()
    reasons = m.validate_compat(m)
    assert reasons == []


# ---------------------------------------------------------------------------
# Test 12: write raises if directory does not exist
# ---------------------------------------------------------------------------

def test_write_raises_if_directory_missing(tmp_path: Path) -> None:
    m = _make_manifest()
    nonexistent = tmp_path / "does_not_exist"
    with pytest.raises(FileNotFoundError):
        m.write(nonexistent)
