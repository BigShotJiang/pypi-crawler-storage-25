from __future__ import annotations

import json

import pytest
import respx
from httpx import AsyncClient, Response

from raglocal.config import EmbedderConfig
from raglocal.embed import OllamaEmbedder


@pytest.fixture
def embedder_config() -> EmbedderConfig:
    """Provide a test EmbedderConfig."""
    return EmbedderConfig(
        profile="custom",
        provider="ollama",
        model="bge-m3",
        host="http://localhost:11434",
        dim=1024,
        cache_dir=None,
    )


@pytest.mark.asyncio
async def test_single_batch_embedding(embedder_config: EmbedderConfig) -> None:
    """Test embedding a single batch of texts."""
    texts = ["hello world", "foo bar", "test"]
    embedder = OllamaEmbedder(embedder_config)

    with respx.mock:
        # Mock the Ollama embed endpoint
        mock_route = respx.post(
            "http://localhost:11434/api/embed",
        ).mock(
            return_value=Response(
                200,
                json={
                    "embeddings": [
                        [0.1] * 1024,
                        [0.2] * 1024,
                        [0.3] * 1024,
                    ]
                },
            )
        )

        result = await embedder.embed(texts)

        assert len(result) == 3
        assert all(len(vec) == 1024 for vec in result)
        assert mock_route.called


@pytest.mark.asyncio
async def test_batch_of_150_texts_splits_into_3_calls(
    embedder_config: EmbedderConfig,
) -> None:
    """Test that 150 texts are split into 3 HTTP calls (64, 64, 22)."""
    texts = [f"text {i}" for i in range(150)]
    embedder = OllamaEmbedder(embedder_config)

    with respx.mock:
        call_count = 0

        def response_func(request):
            nonlocal call_count
            call_count += 1
            # Parse the request body
            json_data = json.loads(request.content)
            batch_size = len(json_data["input"])
            # Return vectors matching the batch size
            return Response(
                200,
                json={"embeddings": [[0.1] * 1024 for _ in range(batch_size)]},
            )

        respx.post("http://localhost:11434/api/embed").mock(side_effect=response_func)

        result = await embedder.embed(texts)

        assert len(result) == 150
        assert all(len(vec) == 1024 for vec in result)
        assert call_count == 3  # 64, 64, 22


@pytest.mark.asyncio
async def test_500_response_raises_runtime_error(
    embedder_config: EmbedderConfig,
) -> None:
    """Test that a 500 response raises RuntimeError."""
    texts = ["test"]
    embedder = OllamaEmbedder(embedder_config)

    with respx.mock:
        respx.post("http://localhost:11434/api/embed").mock(
            return_value=Response(500, text="Internal Server Error")
        )

        with pytest.raises(RuntimeError, match="Ollama embed failed: 500"):
            await embedder.embed(texts)


@pytest.mark.asyncio
async def test_dim_property(embedder_config: EmbedderConfig) -> None:
    """Test that the dim property returns the configured dimension."""
    embedder = OllamaEmbedder(embedder_config)
    assert embedder.dim == 1024


@pytest.mark.asyncio
async def test_with_custom_client(embedder_config: EmbedderConfig) -> None:
    """Test that a custom AsyncClient can be injected."""
    texts = ["hello"]
    custom_client = AsyncClient()
    embedder = OllamaEmbedder(embedder_config, client=custom_client)

    with respx.mock:
        respx.post("http://localhost:11434/api/embed").mock(
            return_value=Response(200, json={"embeddings": [[0.5] * 1024]})
        )

        result = await embedder.embed(texts)
        assert len(result) == 1

    await custom_client.aclose()


@pytest.mark.asyncio
async def test_aclose_with_owned_client(embedder_config: EmbedderConfig) -> None:
    """Test aclose when embedder owns the client."""
    embedder = OllamaEmbedder(embedder_config)
    await embedder.aclose()  # Should not raise


@pytest.mark.asyncio
async def test_batch_exactly_64(embedder_config: EmbedderConfig) -> None:
    """Test that exactly 64 texts fit in one batch."""
    texts = [f"text {i}" for i in range(64)]
    embedder = OllamaEmbedder(embedder_config)

    with respx.mock:
        call_count = 0

        def response_func(request):
            nonlocal call_count
            call_count += 1
            json_data = json.loads(request.content)
            batch_size = len(json_data["input"])
            return Response(
                200,
                json={"embeddings": [[0.1] * 1024 for _ in range(batch_size)]},
            )

        respx.post("http://localhost:11434/api/embed").mock(side_effect=response_func)

        result = await embedder.embed(texts)

        assert len(result) == 64
        assert call_count == 1  # Should be just one call


@pytest.mark.asyncio
async def test_batch_65_texts_requires_2_calls(
    embedder_config: EmbedderConfig,
) -> None:
    """Test that 65 texts require 2 calls (64 + 1)."""
    texts = [f"text {i}" for i in range(65)]
    embedder = OllamaEmbedder(embedder_config)

    with respx.mock:
        call_count = 0

        def response_func(request):
            nonlocal call_count
            call_count += 1
            json_data = json.loads(request.content)
            batch_size = len(json_data["input"])
            return Response(
                200,
                json={"embeddings": [[0.1] * 1024 for _ in range(batch_size)]},
            )

        respx.post("http://localhost:11434/api/embed").mock(side_effect=response_func)

        result = await embedder.embed(texts)

        assert len(result) == 65
        assert call_count == 2


@pytest.mark.asyncio
async def test_non_200_status_raises_error(
    embedder_config: EmbedderConfig,
) -> None:
    """Test that any non-2xx status raises RuntimeError."""
    texts = ["test"]
    embedder = OllamaEmbedder(embedder_config)

    with respx.mock:
        respx.post("http://localhost:11434/api/embed").mock(
            return_value=Response(400, text="Bad request: invalid model")
        )

        with pytest.raises(RuntimeError, match="Ollama embed failed: 400"):
            await embedder.embed(texts)
