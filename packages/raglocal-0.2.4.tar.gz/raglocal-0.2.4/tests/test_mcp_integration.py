"""MCP server integration tests.

Tests the MCPServer class in-process using asyncio streams.
Skipped entirely if sentence_transformers is not installed.
"""

from __future__ import annotations

import json
import textwrap
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Skip guard
# ---------------------------------------------------------------------------

try:
    import sentence_transformers  # noqa: F401
    _ST_AVAILABLE = True
except ImportError:
    _ST_AVAILABLE = False

pytestmark = pytest.mark.skipif(
    not _ST_AVAILABLE,
    reason="sentence_transformers not installed",
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _write_config(config_path: Path, data_path: Path) -> None:
    lance_path = data_path / "lance"
    state_path = data_path / "state"
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(
        textwrap.dedent(f"""\
            [core]
            state_dir = "{state_path}"
            log_level = "info"

            [store]
            backend = "lance"
            path = "{lance_path}"

            [embedder]
            profile = "lean"
            provider = "sentence-transformers"
            model = "all-MiniLM-L6-v2"
            dim = 384

            [reranker]
            enabled = false
            model = ""

            [retrieval]
            top_n = 10
            top_k = 3
            hybrid_alpha = 0.5

            [defaults]
            model = "smart"
            collections = ["docs"]

            [models.smart]
            provider = "ollama"
            model = "qwen3:32b"

            [collections.docs]
            chunk_size = 400
            chunk_overlap = 40
            chunk_strategy = "token"
        """)
    )


def _make_corpus(corpus_dir: Path) -> None:
    corpus_dir.mkdir(parents=True, exist_ok=True)
    (corpus_dir / "rust.md").write_text(
        "# Rust Programming\n"
        "Rust guarantees memory safety through ownership and borrowing.\n"
        "The borrow checker prevents data races and memory leaks at compile time.\n"
        "Rust is ideal for systems programming where performance and safety matter.\n"
    )
    (corpus_dir / "cooking.md").write_text(
        "# Cooking Basics\n"
        "Sautéing involves cooking food quickly in a small amount of hot oil.\n"
        "Braising uses low heat and moisture to tenderize tougher cuts of meat.\n"
    )


# ---------------------------------------------------------------------------
# In-process MCP helper: send a request dict, get response dict
# ---------------------------------------------------------------------------

async def _call(server, request: dict) -> dict:
    """Dispatch a single request through MCPServer._handle and return response."""
    raw = json.dumps(request)
    response = await server._handle(raw)
    assert response is not None, f"Server returned None for request: {request}"
    return response


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def mcp_setup(tmp_path_factory: pytest.TempPathFactory):
    """Index corpus once. Returns (cfg, store, embedder)."""
    import subprocess
    import sys

    tmp = tmp_path_factory.mktemp("mcp")
    config_path = tmp / "config.toml"
    data_path = tmp / "data"
    corpus_dir = tmp / "corpus"

    _write_config(config_path, data_path)
    _make_corpus(corpus_dir)

    # Index using CLI subprocess
    result = subprocess.run(
        [
            sys.executable, "-m", "cli",
            "index", str(corpus_dir),
            "--collection", "docs",
            "--config", str(config_path),
        ],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, f"index failed:\nstdout={result.stdout}\nstderr={result.stderr}"

    from raglocal.config import load_config
    from raglocal.embed import SentenceTransformersEmbedder
    from raglocal.store import LanceStore

    cfg = load_config(str(config_path))
    store = LanceStore(cfg.store.path)
    store.ensure_collection("docs", cfg.embedder.dim)
    embedder = SentenceTransformersEmbedder(cfg.embedder.model, cfg.embedder.dim, cfg.embedder.cache_dir)

    return cfg, store, embedder


@pytest.fixture()
def mcp_server(mcp_setup):
    """Return a pre-warmed MCPServer instance (store + embedder injected)."""
    from raglocal.mcp_server import MCPServer

    cfg, store, embedder = mcp_setup
    server = MCPServer(cfg=cfg, store=store, embedder=embedder)
    # Mark as initialized so tools/call works without a round-trip initialize
    return server


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_initialize_handshake(mcp_server):
    response = await _call(mcp_server, {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "initialize",
        "params": {"protocolVersion": "2024-11-05", "clientInfo": {"name": "test"}},
    })
    assert response.get("jsonrpc") == "2.0"
    assert response.get("id") == 1
    assert "result" in response, f"Expected 'result', got: {response}"


@pytest.mark.asyncio
async def test_tools_list(mcp_server):
    response = await _call(mcp_server, {
        "jsonrpc": "2.0",
        "id": 2,
        "method": "tools/list",
        "params": {},
    })
    assert "result" in response, f"Unexpected response: {response}"
    tools = response["result"]["tools"]
    tool_names = {t["name"] for t in tools}
    assert "search" in tool_names
    assert "expand" in tool_names


@pytest.mark.asyncio
async def test_search_returns_relevant_hits(mcp_server):
    response = await _call(mcp_server, {
        "jsonrpc": "2.0",
        "id": 3,
        "method": "tools/call",
        "params": {
            "name": "search",
            "arguments": {
                "query": "memory safety",
                "top_k": 3,
            },
        },
    })
    assert "result" in response, f"Unexpected response: {response}"
    payload = json.loads(response["result"]["content"][0]["text"])
    hits = payload["hits"]
    assert len(hits) > 0, "Expected at least one search hit for 'memory safety'"


@pytest.mark.asyncio
async def test_expand_returns_full_text(mcp_server):
    # Search first to get a hit ID
    search_resp = await _call(mcp_server, {
        "jsonrpc": "2.0",
        "id": 4,
        "method": "tools/call",
        "params": {
            "name": "search",
            "arguments": {"query": "memory safety", "top_k": 3},
        },
    })
    search_payload = json.loads(search_resp["result"]["content"][0]["text"])
    hits = search_payload["hits"]
    assert hits, "No hits to expand"

    first_id = hits[0]["id"]
    expand_resp = await _call(mcp_server, {
        "jsonrpc": "2.0",
        "id": 5,
        "method": "tools/call",
        "params": {
            "name": "expand",
            "arguments": {"ids": [first_id]},
        },
    })
    assert "result" in expand_resp, f"Unexpected expand response: {expand_resp}"
    expand_payload = json.loads(expand_resp["result"]["content"][0]["text"])
    chunks = expand_payload["chunks"]
    assert isinstance(chunks, list)
    if chunks:
        assert "text" in chunks[0], f"chunk missing 'text': {chunks[0]}"
