"""Tests for text chunking with token awareness and markdown support."""

from __future__ import annotations

from raglocal.chunk import TextChunk, split_text


def test_empty_text() -> None:
    """Empty input returns empty list."""
    assert split_text("") == []


def test_single_chunk() -> None:
    """Text smaller than chunk_size returns single chunk."""
    text = "Hello world this is a short text"
    chunks = split_text(text, chunk_size=100, chunk_overlap=10)

    assert len(chunks) == 1
    chunk = chunks[0]
    assert chunk.chunk_idx == 0
    assert chunk.chunk_total == 1
    assert chunk.heading_path == []
    assert chunk.line_start == 1
    assert chunk.line_end == 1


def test_multiple_chunks() -> None:
    """Text larger than chunk_size splits into multiple chunks."""
    # Create text with ~2000 words
    words = ["word"] * 2000
    text = " ".join(words)

    chunks = split_text(text, chunk_size=800, chunk_overlap=100)

    assert len(chunks) >= 3, "Expected at least 3 chunks for 2000 words with 800-token chunks"

    # All chunks should be under chunk_size (with +10 tolerance for boundaries)
    for chunk in chunks:
        token_count = len(chunk.text.split())
        assert token_count <= 810, f"Chunk {chunk.chunk_idx} has {token_count} tokens, exceeds 810"

    # Check chunk_total is consistent
    assert all(chunk.chunk_total == len(chunks) for chunk in chunks)

    # Check chunk indices
    for i, chunk in enumerate(chunks):
        assert chunk.chunk_idx == i


def test_overlap() -> None:
    """Chunks should have overlap as specified."""
    words = ["word"] * 2000
    text = " ".join(words)
    chunks = split_text(text, chunk_size=500, chunk_overlap=50)

    assert len(chunks) > 1

    # Check for overlap between consecutive chunks
    # The last 50 tokens of chunk N should be in the start of chunk N+1
    for i in range(len(chunks) - 1):
        current_chunk_tokens = chunks[i].text.split()
        next_chunk_tokens = chunks[i + 1].text.split()

        if len(current_chunk_tokens) > 50:
            overlap_tokens = current_chunk_tokens[-50:]
            # Check if overlap exists at start of next chunk
            assert next_chunk_tokens[: len(overlap_tokens)] == overlap_tokens, (
                f"No overlap found between chunks {i} and {i + 1}"
            )


def test_markdown_heading_tracking() -> None:
    """Markdown mode tracks heading hierarchy."""
    text = """# Main Title
Some content under main title.

## Subsection
Content under subsection.

### Sub-subsection
More content here.

## Another Subsection
Different content.
"""

    chunks = split_text(text, chunk_size=100, chunk_overlap=10, is_markdown=True)

    assert len(chunks) > 0

    # Find chunks in "Subsection" area
    subsection_chunks = [
        c for c in chunks if "Subsection" in c.text or "subsection" in c.text.lower()
    ]

    # Chunks in the subsection should have the heading path
    for chunk in subsection_chunks:
        # Should include "Main Title" in path
        assert "Main Title" in chunk.heading_path or "Subsection" in chunk.heading_path, (
            f"Heading path {chunk.heading_path} missing expected headings"
        )


def test_markdown_multiple_h1() -> None:
    """Markdown with multiple H1 sections updates heading stack correctly."""
    # Make text large enough to be split
    content_a = " ".join(["Content A"] * 50)
    content_b = " ".join(["Content B"] * 50)

    text = f"""# First Section
{content_a}

# Second Section
{content_b}
"""

    chunks = split_text(text, chunk_size=100, chunk_overlap=10, is_markdown=True)

    # Find chunks from each section
    first_chunks = [c for c in chunks if "Content A" in c.text]
    second_chunks = [c for c in chunks if "Content B" in c.text]

    if first_chunks:
        assert "First Section" in first_chunks[0].heading_path

    if second_chunks:
        # Check that the second section chunks have the correct heading
        # The heading path should reflect the current heading context
        has_second_section = any("Second Section" in c.heading_path for c in second_chunks)
        assert has_second_section, (
            f"No chunk in second section has 'Second Section' in heading_path. Chunks: {[c.heading_path for c in second_chunks]}"
        )


def test_line_numbers() -> None:
    """line_start and line_end track original line numbers."""
    text = """Line 1
Line 2
Line 3
Line 4
Line 5
Line 6
Line 7
Line 8
Line 9
Line 10
"""

    chunks = split_text(text, chunk_size=50, chunk_overlap=5)

    assert len(chunks) > 0

    # First chunk should start at line 1
    assert chunks[0].line_start == 1

    # All chunks should have valid line ranges
    for chunk in chunks:
        assert chunk.line_start >= 1
        assert chunk.line_end >= chunk.line_start
        assert chunk.line_end <= len(text.split("\n"))


def test_chunk_text_content() -> None:
    """Chunk text contains actual content from original text."""
    text = "This is some sample text that should be split into chunks based on the chunk size parameter."

    chunks = split_text(text, chunk_size=10, chunk_overlap=2)

    # Reconstruct text from chunks (removing overlaps for comparison)
    reconstructed = " ".join(chunks[0].text.split())

    # The reconstructed text should contain the original
    assert "sample" in reconstructed or "sample" in text


def test_whitespace_only() -> None:
    """Text with only whitespace returns empty list."""
    text = "   \n\n   \t\t  "
    chunks = split_text(text, chunk_size=100)

    assert chunks == []


def test_chunk_frozen() -> None:
    """TextChunk is immutable."""
    chunk = TextChunk(
        text="test",
        chunk_idx=0,
        chunk_total=1,
        heading_path=["H1"],
        line_start=1,
        line_end=1,
    )

    # Attempting to modify should raise an error
    try:
        chunk.text = "modified"  # type: ignore
        raise AssertionError("TextChunk should be frozen")
    except (AttributeError, TypeError):
        pass
