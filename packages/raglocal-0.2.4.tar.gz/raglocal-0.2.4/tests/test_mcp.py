"""Tests for raglocal.mcp_server — JSON-RPC 2.0 MCP stdio server (Block 4A rewrite)."""

from __future__ import annotations

import asyncio
import json
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from raglocal.config import (
    CollectionConfig,
    Config,
    EmbedderConfig,
    ModelSpec,
    RerankerConfig,
    RetrievalConfig,
    StoreConfig,
)
from raglocal.mcp_server import MCPServer, _err, _make_snippet, _ok
from raglocal.store import SearchResult

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

_DEFAULT_COLLECTIONS = ["docs"]


@pytest.fixture
def mock_cfg() -> Config:
    return Config(
        state_dir="/tmp/mcp_test",
        log_level="info",
        store=StoreConfig(backend="lance", path="/tmp/mcp_test/lance"),
        embedder=EmbedderConfig(
            profile="custom",
            provider="ollama",
            model="bge-m3",
            host="http://localhost:11434",
            dim=4,
            cache_dir=None,
        ),
        reranker=RerankerConfig(enabled=False, model="bge-reranker-v2-m3"),
        retrieval=RetrievalConfig(top_n=20, top_k=10, hybrid_alpha=0.5),
        models={"smart": ModelSpec(alias="smart", provider="ollama", model="llama3")},
        default_model="smart",
        default_collections=["docs"],
        collections={
            "docs": CollectionConfig(name="docs", chunk_size=800, chunk_overlap=100),
            "code": CollectionConfig(name="code", chunk_size=256, chunk_overlap=32),
        },
    )


def _make_search_result(
    text: str = "The quick brown fox jumps",
    source_uri: str = "file:///test.md",
    source_type: str = "docs",
    collection: str = "docs",
    chunk_idx: int = 0,
    chunk_total: int = 1,
    heading_path: list[str] | None = None,
    line_start: int | None = 1,
    line_end: int | None = 5,
    mtime: int | None = 1700000000,
    chunk_id: str = "hit-1",
    score: float = 0.9,
) -> SearchResult:
    return SearchResult(
        text=text,
        score=score,
        payload={
            "id": chunk_id,
            "source_uri": source_uri,
            "source_type": source_type,
            "collection": collection,
            "chunk_idx": chunk_idx,
            "chunk_total": chunk_total,
            "heading_path": heading_path or ["Test Doc"],
            "line_start": line_start,
            "line_end": line_end,
            "mtime": mtime,
        },
    )


@pytest.fixture
def mock_store() -> MagicMock:
    store = MagicMock()
    store.hybrid_search = AsyncMock(return_value=[_make_search_result()])
    store.search = AsyncMock(return_value=[])
    store.count = MagicMock(return_value=1)
    return store


@pytest.fixture
def mock_embedder() -> MagicMock:
    emb = MagicMock()
    emb.embed = AsyncMock(return_value=[[0.1, 0.2, 0.3, 0.4]])
    emb.aclose = AsyncMock(return_value=None)
    return emb


def _make_server(
    cfg: Config | None = None,
    store: MagicMock | None = None,
    embedder: MagicMock | None = None,
) -> tuple[MCPServer, asyncio.StreamReader, list[bytes]]:
    """Return (server, reader, written_bytes_list)."""
    if cfg is None:
        cfg = Config(
            state_dir="/tmp/mcp_test",
            log_level="info",
            store=StoreConfig(backend="lance", path="/tmp/mcp_test/lance"),
            embedder=EmbedderConfig(
                profile="custom",
                provider="ollama",
                model="bge-m3",
                host="http://localhost:11434",
                dim=4,
                cache_dir=None,
            ),
            reranker=RerankerConfig(enabled=False, model="bge-reranker-v2-m3"),
            retrieval=RetrievalConfig(top_n=20, top_k=10, hybrid_alpha=0.5),
            models={"smart": ModelSpec(alias="smart", provider="ollama", model="llama3")},
            default_model="smart",
            default_collections=["docs"],
            collections={
                "docs": CollectionConfig(name="docs", chunk_size=800, chunk_overlap=100),
                "code": CollectionConfig(name="code", chunk_size=256, chunk_overlap=32),
            },
        )

    reader = asyncio.StreamReader()

    written: list[bytes] = []
    fake_writer = MagicMock()
    fake_writer.write = lambda data: written.append(data)
    fake_writer.drain = AsyncMock(return_value=None)

    server = MCPServer(cfg, reader=reader, writer=fake_writer, store=store, embedder=embedder)
    return server, reader, written


def _responses(written: list[bytes]) -> list[dict]:
    raw = b"".join(written).decode("utf-8")
    return [json.loads(line) for line in raw.splitlines() if line.strip()]


async def _send(reader: asyncio.StreamReader, obj: dict) -> None:
    line = json.dumps(obj).encode("utf-8") + b"\n"
    reader.feed_data(line)


async def _eof(reader: asyncio.StreamReader) -> None:
    reader.feed_eof()


# ---------------------------------------------------------------------------
# JSON-RPC helpers
# ---------------------------------------------------------------------------


def test_ok_response() -> None:
    resp = _ok(1, {"foo": "bar"})
    assert resp == {"jsonrpc": "2.0", "id": 1, "result": {"foo": "bar"}}


def test_err_response() -> None:
    resp = _err(2, -32601, "Method not found")
    assert resp["jsonrpc"] == "2.0"
    assert resp["id"] == 2
    assert resp["error"]["code"] == -32601
    assert "Method not found" in resp["error"]["message"]
    assert "data" not in resp["error"]


def test_err_response_with_data() -> None:
    resp = _err(3, -32603, "Internal", data={"detail": "oops"})
    assert resp["error"]["data"] == {"detail": "oops"}


# ---------------------------------------------------------------------------
# tools/list — Block 4A requirement tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tools_list_returns_search_and_expand(mock_store: MagicMock, mock_embedder: MagicMock) -> None:
    """tools/list returns exactly 2 tools named 'search' and 'expand'."""
    server, reader, written = _make_server(store=mock_store, embedder=mock_embedder)
    await _send(reader, {"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}})
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    assert len(responses) == 1
    tools = responses[0]["result"]["tools"]
    names = [t["name"] for t in tools]
    assert "search" in names
    assert "expand" in names
    assert len(tools) == 2


@pytest.mark.asyncio
async def test_tools_list_no_legacy_tool(mock_store: MagicMock, mock_embedder: MagicMock) -> None:
    """tools/list does NOT contain rag.query."""
    server, reader, written = _make_server(store=mock_store, embedder=mock_embedder)
    await _send(reader, {"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}})
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    tools = responses[0]["result"]["tools"]
    names = [t["name"] for t in tools]
    assert "rag.query" not in names


# ---------------------------------------------------------------------------
# search tool tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_search_returns_hits(mock_store: MagicMock, mock_embedder: MagicMock) -> None:
    """Basic search returns non-empty hits list."""
    server, reader, written = _make_server(store=mock_store, embedder=mock_embedder)
    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "search", "arguments": {"query": "brown fox"}},
        },
    )
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    assert "result" in responses[0]
    hits = json.loads(responses[0]["result"]["content"][0]["text"])["hits"]
    assert len(hits) > 0


@pytest.mark.asyncio
async def test_search_empty_query_returns_error(mock_store: MagicMock, mock_embedder: MagicMock) -> None:
    """Empty string query returns INVALID_PARAMS error."""
    server, reader, written = _make_server(store=mock_store, embedder=mock_embedder)
    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "search", "arguments": {"query": ""}},
        },
    )
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    assert "error" in responses[0]
    assert responses[0]["error"]["code"] == -32602


@pytest.mark.asyncio
async def test_search_hits_have_required_fields(mock_store: MagicMock, mock_embedder: MagicMock) -> None:
    """Each hit has id, score, source, snippet, type."""
    server, reader, written = _make_server(store=mock_store, embedder=mock_embedder)
    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "search", "arguments": {"query": "brown fox"}},
        },
    )
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    hits = json.loads(responses[0]["result"]["content"][0]["text"])["hits"]
    for hit in hits:
        assert "id" in hit
        assert "score" in hit
        assert "source" in hit
        assert "snippet" in hit
        assert "type" in hit


@pytest.mark.asyncio
async def test_search_snippet_max_250_chars(mock_store: MagicMock, mock_embedder: MagicMock) -> None:
    """Snippet length ≤ 250 for all hits."""
    long_text = "word " * 200  # 1000 chars
    mock_store.hybrid_search = AsyncMock(return_value=[
        _make_search_result(text=long_text)
    ])
    server, reader, written = _make_server(store=mock_store, embedder=mock_embedder)
    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "search", "arguments": {"query": "word"}},
        },
    )
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    hits = json.loads(responses[0]["result"]["content"][0]["text"])["hits"]
    for hit in hits:
        assert len(hit["snippet"]) <= 253  # 250 + up to 3 dots


@pytest.mark.asyncio
async def test_search_no_full_text_in_hits(mock_store: MagicMock, mock_embedder: MagicMock) -> None:
    """Hits do NOT have a 'text' field (regression guard)."""
    server, reader, written = _make_server(store=mock_store, embedder=mock_embedder)
    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "search", "arguments": {"query": "brown fox"}},
        },
    )
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    hits = json.loads(responses[0]["result"]["content"][0]["text"])["hits"]
    for hit in hits:
        assert "text" not in hit


@pytest.mark.asyncio
async def test_search_filter_type_narrows_collections(mock_store: MagicMock, mock_embedder: MagicMock) -> None:
    """filter.type='code' only searches 'code' collection."""
    server, reader, written = _make_server(store=mock_store, embedder=mock_embedder)
    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {
                "name": "search",
                "arguments": {"query": "some query", "filter": {"type": "code"}},
            },
        },
    )
    await _eof(reader)
    await server.serve()

    # hybrid_search should only be called with collection="code"
    calls = mock_store.hybrid_search.call_args_list
    assert len(calls) == 1
    call_kwargs = calls[0].kwargs if calls[0].kwargs else {}
    call_args = calls[0].args if calls[0].args else ()
    # First positional arg is collection name
    collection_arg = call_args[0] if call_args else call_kwargs.get("collection", "")
    assert collection_arg == "code"


@pytest.mark.asyncio
async def test_search_filter_since_builds_mtime_filter(mock_store: MagicMock, mock_embedder: MagicMock) -> None:
    """filter.since='2026-01-01' translates to mtime_gte in store call."""
    server, reader, written = _make_server(store=mock_store, embedder=mock_embedder)
    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {
                "name": "search",
                "arguments": {"query": "test", "filter": {"since": "2026-01-01"}},
            },
        },
    )
    await _eof(reader)
    await server.serve()

    calls = mock_store.hybrid_search.call_args_list
    assert len(calls) >= 1
    for call in calls:
        kwargs = call.kwargs if call.kwargs else {}
        filters = kwargs.get("filters") or (call.args[4] if len(call.args) > 4 else None)
        assert filters is not None
        assert "mtime_gte" in filters
        expected_ts = int(datetime.fromisoformat("2026-01-01").timestamp())
        assert filters["mtime_gte"] == expected_ts


@pytest.mark.asyncio
async def test_search_top_k_default_is_10(mock_store: MagicMock, mock_embedder: MagicMock) -> None:
    """Without top_k param, at most 10 hits returned."""
    # Return 15 results from the store
    mock_store.hybrid_search = AsyncMock(return_value=[
        _make_search_result(chunk_id=f"hit-{i}", score=1.0 - i * 0.05)
        for i in range(15)
    ])
    server, reader, written = _make_server(store=mock_store, embedder=mock_embedder)
    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "search", "arguments": {"query": "test"}},
        },
    )
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    hits = json.loads(responses[0]["result"]["content"][0]["text"])["hits"]
    assert len(hits) <= 10


@pytest.mark.asyncio
async def test_search_top_k_respected(mock_store: MagicMock, mock_embedder: MagicMock) -> None:
    """top_k=3 returns at most 3 hits."""
    mock_store.hybrid_search = AsyncMock(return_value=[
        _make_search_result(chunk_id=f"hit-{i}", score=1.0 - i * 0.05)
        for i in range(10)
    ])
    server, reader, written = _make_server(store=mock_store, embedder=mock_embedder)
    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "search", "arguments": {"query": "test", "top_k": 3}},
        },
    )
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    hits = json.loads(responses[0]["result"]["content"][0]["text"])["hits"]
    assert len(hits) <= 3


# ---------------------------------------------------------------------------
# expand tool tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_expand_returns_full_text(mock_store: MagicMock, mock_embedder: MagicMock) -> None:
    """expand returns chunk with 'text' field."""
    mock_store.search = AsyncMock(return_value=[_make_search_result(text="Full chunk content here")])
    server, reader, written = _make_server(store=mock_store, embedder=mock_embedder)
    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "expand", "arguments": {"ids": ["hit-1"]}},
        },
    )
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    assert "result" in responses[0]
    chunks = json.loads(responses[0]["result"]["content"][0]["text"])["chunks"]
    assert len(chunks) == 1
    assert "text" in chunks[0]
    assert "Full chunk content here" in chunks[0]["text"]


@pytest.mark.asyncio
async def test_expand_returns_source_and_lines(mock_store: MagicMock, mock_embedder: MagicMock) -> None:
    """expand result has source and lines fields."""
    mock_store.search = AsyncMock(return_value=[
        _make_search_result(source_uri="file:///path/to/doc.md", line_start=10, line_end=20)
    ])
    server, reader, written = _make_server(store=mock_store, embedder=mock_embedder)
    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "expand", "arguments": {"ids": ["hit-1"]}},
        },
    )
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    chunks = json.loads(responses[0]["result"]["content"][0]["text"])["chunks"]
    assert len(chunks) == 1
    assert "source" in chunks[0]
    assert "lines" in chunks[0]
    assert chunks[0]["source"] == "file:///path/to/doc.md"


@pytest.mark.asyncio
async def test_expand_multiple_ids(mock_store: MagicMock, mock_embedder: MagicMock) -> None:
    """expand with 2 ids returns 2 chunks."""
    def search_side_effect(collection: str, query_dense: list, top_n: int, filters: dict | None = None) -> list:
        chunk_id = filters.get("id", "") if filters else ""
        if chunk_id == "hit-1":
            return [_make_search_result(chunk_id="hit-1", text="First chunk")]
        elif chunk_id == "hit-2":
            return [_make_search_result(chunk_id="hit-2", text="Second chunk")]
        return []

    mock_store.search = AsyncMock(side_effect=search_side_effect)
    server, reader, written = _make_server(store=mock_store, embedder=mock_embedder)
    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "expand", "arguments": {"ids": ["hit-1", "hit-2"]}},
        },
    )
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    chunks = json.loads(responses[0]["result"]["content"][0]["text"])["chunks"]
    assert len(chunks) == 2


# ---------------------------------------------------------------------------
# Backwards compatibility — rag.query deprecated
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_legacy_rag_query_returns_deprecation_error(mock_store: MagicMock, mock_embedder: MagicMock) -> None:
    """Calling rag.query returns JSON-RPC error -32601 with deprecation message."""
    server, reader, written = _make_server(store=mock_store, embedder=mock_embedder)
    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "rag.query", "arguments": {"query": "test"}},
        },
    )
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    assert "error" in responses[0]
    assert responses[0]["error"]["code"] == -32601
    assert "deprecated" in responses[0]["error"]["message"].lower()
    assert "search" in responses[0]["error"]["message"]


# ---------------------------------------------------------------------------
# Snippet generator unit tests
# ---------------------------------------------------------------------------


def test_snippet_generator_centers_on_match() -> None:
    """_make_snippet centers on the matched term."""
    # Build a long text with 'fox' in the middle
    prefix = "a " * 100  # 200 chars
    suffix = " b" * 100  # 200 chars
    text = prefix + "fox" + suffix
    snippet = _make_snippet(text, "fox")
    assert "fox" in snippet


def test_snippet_generator_no_match_takes_start() -> None:
    """_make_snippet returns start of text when no term matches."""
    text = "hello world this is a test document"
    snippet = _make_snippet(text, "xyz nonexistent")
    # Should take first 250 chars
    assert snippet.startswith("hello")
    assert len(snippet) <= 250


def test_snippet_generator_adds_ellipsis() -> None:
    """Long text with mid-match gets '...' prefix."""
    # Put match far into the text so window starts after position 0
    padding = "word " * 60  # ~300 chars
    text = padding + "TARGET " + "word " * 60
    snippet = _make_snippet(text, "TARGET")
    assert "..." in snippet
    assert "TARGET" in snippet


def test_snippet_generator_short_text_no_ellipsis() -> None:
    """Short text gets no ellipsis."""
    text = "The quick brown fox jumps over the lazy dog"
    snippet = _make_snippet(text, "fox")
    assert snippet == "The quick brown fox jumps over the lazy dog"
    assert not snippet.startswith("...")
    assert not snippet.endswith("...")


# ---------------------------------------------------------------------------
# Schema token count
# ---------------------------------------------------------------------------


def test_schema_token_count() -> None:
    """Combined JSON of both tool schemas ≤ 600 tokens (word count proxy)."""
    from raglocal.mcp_server import _TOOL_SCHEMAS

    combined = json.dumps(_TOOL_SCHEMAS)
    word_count = len(combined.split())
    assert word_count <= 600, f"Schema token count {word_count} exceeds 600"


# ---------------------------------------------------------------------------
# Deduplication
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_search_deduplicates_results(mock_store: MagicMock, mock_embedder: MagicMock) -> None:
    """Same chunk id in multiple collection results deduped to one hit."""
    # Both docs and code collections return the same chunk id
    same_result = _make_search_result(chunk_id="hit-shared", score=0.9)
    mock_store.hybrid_search = AsyncMock(return_value=[same_result])

    server, reader, written = _make_server(store=mock_store, embedder=mock_embedder)
    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "search", "arguments": {"query": "test"}},
        },
    )
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    hits = json.loads(responses[0]["result"]["content"][0]["text"])["hits"]
    ids = [h["id"] for h in hits]
    # Should only appear once despite being returned by both collections
    assert ids.count("hit-shared") == 1


# ---------------------------------------------------------------------------
# Protocol scaffolding (preserved from original)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_initialize_returns_protocol_info(mock_store: MagicMock, mock_embedder: MagicMock) -> None:
    server, reader, written = _make_server(store=mock_store, embedder=mock_embedder)
    server._initialized = True

    await _send(reader, {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}})
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    assert len(responses) == 1
    result = responses[0]["result"]
    assert result["protocolVersion"] == "2024-11-05"
    assert result["serverInfo"]["name"] == "raglocal"
    assert "tools" in result["capabilities"]


@pytest.mark.asyncio
async def test_initialize_builds_retriever() -> None:
    """initialize lazily builds embedder/store."""
    server, reader, written = _make_server()

    with patch.object(server, "_build_retriever", return_value=True) as mock_build:
        await _send(reader, {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}})
        await _eof(reader)
        await server.serve()

    mock_build.assert_called_once()
    responses = _responses(written)
    assert "result" in responses[0]


@pytest.mark.asyncio
async def test_notification_initialized_no_response(mock_store: MagicMock, mock_embedder: MagicMock) -> None:
    server, reader, written = _make_server(store=mock_store, embedder=mock_embedder)
    await _send(reader, {"jsonrpc": "2.0", "method": "notifications/initialized"})
    await _eof(reader)
    await server.serve()

    assert _responses(written) == []


@pytest.mark.asyncio
async def test_unknown_method_returns_method_not_found(mock_store: MagicMock, mock_embedder: MagicMock) -> None:
    server, reader, written = _make_server(store=mock_store, embedder=mock_embedder)
    await _send(reader, {"jsonrpc": "2.0", "id": 9, "method": "resources/list", "params": {}})
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    assert "error" in responses[0]
    assert responses[0]["error"]["code"] == -32601


@pytest.mark.asyncio
async def test_parse_error_on_invalid_json(mock_store: MagicMock, mock_embedder: MagicMock) -> None:
    server, reader, written = _make_server(store=mock_store, embedder=mock_embedder)
    reader.feed_data(b"this is not json\n")
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    assert len(responses) == 1
    assert responses[0]["error"]["code"] == -32700


@pytest.mark.asyncio
async def test_ping_returns_empty_result(mock_store: MagicMock, mock_embedder: MagicMock) -> None:
    server, reader, written = _make_server(store=mock_store, embedder=mock_embedder)
    await _send(reader, {"jsonrpc": "2.0", "id": 10, "method": "ping", "params": {}})
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    assert responses[0]["result"] == {}


# ---------------------------------------------------------------------------
# Reranker integration
# ---------------------------------------------------------------------------


def _make_reranker_cfg(enabled: bool) -> Config:
    cfg = Config(
        state_dir="/tmp/mcp_test",
        log_level="info",
        store=StoreConfig(backend="lance", path="/tmp/mcp_test/lance"),
        embedder=EmbedderConfig(
            profile="custom",
            provider="ollama",
            model="bge-m3",
            host="http://localhost:11434",
            dim=4,
            cache_dir=None,
        ),
        reranker=RerankerConfig(enabled=enabled, model="bge-reranker-v2-m3"),
        retrieval=RetrievalConfig(top_n=20, top_k=10, hybrid_alpha=0.5),
        models={"smart": ModelSpec(alias="smart", provider="ollama", model="llama3")},
        default_model="smart",
        default_collections=["docs"],
        collections={
            "docs": CollectionConfig(name="docs", chunk_size=800, chunk_overlap=100),
        },
    )
    return cfg


@pytest.mark.asyncio
async def test_search_without_reranker_skips_rerank(
    mock_store: MagicMock, mock_embedder: MagicMock
) -> None:
    """Reranker disabled in config: no rerank call, top_k results returned directly."""
    cfg = _make_reranker_cfg(enabled=False)
    server, reader, written = _make_server(cfg=cfg, store=mock_store, embedder=mock_embedder)
    assert server._reranker is None

    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "search", "arguments": {"query": "fox", "top_k": 3}},
        },
    )
    await _eof(reader)
    await server.serve()

    responses = _responses(written)
    assert "result" in responses[0]


@pytest.mark.asyncio
async def test_search_with_reranker_calls_rerank(
    mock_store: MagicMock, mock_embedder: MagicMock
) -> None:
    """Reranker enabled: rerank() is called with retrieved results, returns top_k."""
    cfg = _make_reranker_cfg(enabled=True)
    server, reader, written = _make_server(cfg=cfg, store=mock_store, embedder=mock_embedder)

    # Replace reranker with a mock that returns the input list unchanged
    mock_reranker = MagicMock()
    mock_reranker.rerank = AsyncMock(side_effect=lambda q, results, top_k: results[:top_k])
    server._reranker = mock_reranker

    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "search", "arguments": {"query": "fox", "top_k": 3}},
        },
    )
    await _eof(reader)
    await server.serve()

    mock_reranker.rerank.assert_called_once()
    responses = _responses(written)
    assert "result" in responses[0]


@pytest.mark.asyncio
async def test_search_rerank_param_overrides_config(
    mock_store: MagicMock, mock_embedder: MagicMock
) -> None:
    """Per-call rerank=false overrides enabled config; reranker not invoked."""
    cfg = _make_reranker_cfg(enabled=True)
    server, reader, written = _make_server(cfg=cfg, store=mock_store, embedder=mock_embedder)

    mock_reranker = MagicMock()
    mock_reranker.rerank = AsyncMock(side_effect=lambda q, results, top_k: results[:top_k])
    server._reranker = mock_reranker

    await _send(
        reader,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {
                "name": "search",
                "arguments": {"query": "fox", "top_k": 3, "rerank": False},
            },
        },
    )
    await _eof(reader)
    await server.serve()

    mock_reranker.rerank.assert_not_called()
    responses = _responses(written)
    assert "result" in responses[0]
