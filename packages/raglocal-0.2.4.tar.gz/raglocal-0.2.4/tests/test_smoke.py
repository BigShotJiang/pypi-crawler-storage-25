"""Smoke test that the package imports."""

from __future__ import annotations

import raglocal


import tomllib
from pathlib import Path

def test_package_imports() -> None:
    # Ensure the version in code matches the version in pyproject.toml
    pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
    with open(pyproject_path, "rb") as f:
        pyproject = tomllib.load(f)
    version = pyproject["project"]["version"]
    assert raglocal.__version__ == version
