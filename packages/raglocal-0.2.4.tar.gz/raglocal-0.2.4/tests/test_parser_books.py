"""Tests for raglocal.parsers.books.BooksParser."""

from __future__ import annotations

import io
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from raglocal.parsers.books import BooksParser

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_epub(tmp_path: Path, chapters: list[tuple[str, str]]) -> Path:
    """Create a minimal EPUB with given (title, text) chapters."""
    pytest.importorskip("ebooklib.epub", reason="ebooklib not installed")
    from ebooklib import epub as epub_mod  # noqa: PLC0415

    book = epub_mod.EpubBook()
    book.set_title("Test Book")
    book.add_author("Test Author")
    items = []
    toc = []
    for i, (ch_title, ch_text) in enumerate(chapters):
        c = epub_mod.EpubHtml(title=ch_title, file_name=f"chap{i}.xhtml", lang="en")
        c.content = f"<h1>{ch_title}</h1><p>{ch_text}</p>"
        book.add_item(c)
        items.append(c)
        toc.append(epub_mod.Link(f"chap{i}.xhtml", ch_title, f"chap{i}"))
    book.toc = toc
    book.spine = ["nav"] + items
    book.add_item(epub_mod.EpubNcx())
    book.add_item(epub_mod.EpubNav())
    out = tmp_path / "test.epub"
    epub_mod.write_epub(str(out), book)
    return out


def _make_simple_pdf(tmp_path: Path, pages: list[str], filename: str = "test.pdf") -> Path:
    """Create a minimal PDF with the given page texts using pypdf."""
    import pypdf  # noqa: PLC0415
    from pypdf import PdfWriter  # noqa: PLC0415

    writer = PdfWriter()
    for page_text in pages:
        # Add blank page and annotate — pypdf writer doesn't embed text directly,
        # so we use reportlab if available, otherwise create blank pages.
        try:
            from reportlab.pdfgen import canvas  # noqa: PLC0415

            buf = io.BytesIO()
            c = canvas.Canvas(buf)
            c.drawString(72, 720, page_text)
            c.save()
            buf.seek(0)
            reader_page = pypdf.PdfReader(buf)
            writer.add_page(reader_page.pages[0])
        except ImportError:
            writer.add_blank_page(width=612, height=792)

    out = tmp_path / filename
    with out.open("wb") as f:
        writer.write(f)
    return out


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_epub_parse_two_chapters(tmp_path: Path) -> None:
    """Two-chapter EPUB should yield 2 detected chapters and non-empty chunks."""
    pytest.importorskip("ebooklib", reason="ebooklib not installed")

    chapters = [
        ("Introduction", "This is the introduction chapter with some sample text to chunk."),
        ("Chapter One", "This is the first chapter. It contains more text for testing purposes."),
    ]
    epub_path = _make_epub(tmp_path, chapters)
    parser = BooksParser()
    doc = await parser.parse(epub_path)

    assert doc.default_collection == "books"
    assert len(doc.chunks) > 0

    # Verify both chapter titles appear in heading_paths
    heading_titles = {chunk.heading_path[-1] for chunk in doc.chunks if chunk.heading_path}
    assert "Introduction" in heading_titles
    assert "Chapter One" in heading_titles


@pytest.mark.asyncio
async def test_epub_metadata(tmp_path: Path) -> None:
    """EPUB metadata should include title and author."""
    pytest.importorskip("ebooklib", reason="ebooklib not installed")

    chapters = [("Preface", "Some preface text here for the metadata test.")]
    epub_path = _make_epub(tmp_path, chapters)
    parser = BooksParser()
    doc = await parser.parse(epub_path)

    assert doc.metadata["title"] == "Test Book"
    assert doc.metadata["author"] == "Test Author"


@pytest.mark.asyncio
async def test_epub_missing_ebooklib(tmp_path: Path) -> None:
    """Should raise ImportError with clear message when ebooklib is unavailable."""
    # Create a dummy .epub file (content doesn't matter for this test)
    epub_path = tmp_path / "fake.epub"
    epub_path.write_bytes(b"PK\x03\x04")  # fake epub (ZIP magic bytes)

    parser = BooksParser()

    original_import = __builtins__.__import__ if hasattr(__builtins__, "__import__") else __import__

    def _mock_import(name: str, *args, **kwargs):  # type: ignore[no-untyped-def]
        if name == "ebooklib":
            raise ImportError("No module named 'ebooklib'")
        return original_import(name, *args, **kwargs)

    with patch("builtins.__import__", side_effect=_mock_import), pytest.raises(ImportError, match="ebooklib"):
        await parser.parse(epub_path)


def test_pdf_is_book_detection_large_file(tmp_path: Path) -> None:
    """A PDF whose stat().st_size >= 5 MB should be detected as a book PDF."""
    pytest.importorskip("pypdf", reason="pypdf not installed")

    pdf_path = _make_simple_pdf(tmp_path, ["Page one content."])

    mock_stat = MagicMock()
    mock_stat.st_size = 6 * 1024 * 1024  # 6 MB

    with patch.object(Path, "stat", return_value=mock_stat):
        result = BooksParser.is_book_pdf(pdf_path)

    assert result is True


def test_pdf_is_book_detection_small_file(tmp_path: Path) -> None:
    """A small PDF with no outline should NOT be detected as a book PDF."""
    pytest.importorskip("pypdf", reason="pypdf not installed")

    pdf_path = _make_simple_pdf(tmp_path, ["Small page."])
    # File is tiny and has no outline
    result = BooksParser.is_book_pdf(pdf_path)
    assert result is False


@pytest.mark.asyncio
async def test_pdf_parse_no_outline(tmp_path: Path) -> None:
    """A 3-page PDF with no outline should produce non-empty chunks and default_collection='books'."""
    pytest.importorskip("pypdf", reason="pypdf not installed")

    pages = [
        "First page of the document with enough text to produce a chunk.",
        "Second page continues with more content for testing the parser.",
        "Third page wraps up with additional textual content for chunking.",
    ]
    pdf_path = _make_simple_pdf(tmp_path, pages)

    # Force is_book_pdf to return True via size mock so parse() accepts it
    mock_stat = MagicMock()
    mock_stat.st_size = 6 * 1024 * 1024

    parser = BooksParser()

    with patch.object(Path, "stat", return_value=mock_stat):
        doc = await parser.parse(pdf_path)

    assert doc.default_collection == "books"
    # chunks may be empty if pages have no extractable text (blank pages fallback)
    # but the document should be returned
    assert isinstance(doc.chunks, list)
