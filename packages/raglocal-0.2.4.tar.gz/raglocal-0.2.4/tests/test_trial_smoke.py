"""End-to-end smoke test: init → index → stats → debug → mcp → search → expand.

This test exercises the exact flow a real user follows and catches regressions
in the full pipeline that unit tests miss.

Skipped if sentence_transformers is not installed.
"""

from __future__ import annotations

import json
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest
from typer.testing import CliRunner

import cli as _cli_module
from cli import app

# ---------------------------------------------------------------------------
# Skip guard
# ---------------------------------------------------------------------------

try:
    import sentence_transformers  # noqa: F401
    _ST_AVAILABLE = True
except ImportError:
    _ST_AVAILABLE = False

pytestmark = pytest.mark.skipif(
    not _ST_AVAILABLE,
    reason="sentence_transformers not installed",
)

runner = CliRunner(mix_stderr=True)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _write_config(config_path: Path, data_path: Path) -> None:
    """Write a minimal lean-profile config.toml to config_path."""
    lance_path = data_path / "lance"
    state_path = data_path / "state"
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(
        textwrap.dedent(f"""\
            [core]
            state_dir = "{state_path}"
            log_level = "info"

            [store]
            backend = "lance"
            path = "{lance_path}"

            [embedder]
            profile = "lean"
            provider = "sentence-transformers"
            model = "all-MiniLM-L6-v2"
            dim = 384

            [reranker]
            enabled = false
            model = ""

            [retrieval]
            top_n = 10
            top_k = 3
            hybrid_alpha = 0.5

            [defaults]
            model = "smart"
            collections = ["docs"]

            [models.smart]
            provider = "ollama"
            model = "qwen3:32b"

            [collections.docs]
            chunk_size = 400
            chunk_overlap = 40
            chunk_strategy = "token"
        """)
    )


def _make_corpus(corpus_dir: Path) -> None:
    """Write 3 small markdown files into corpus_dir."""
    corpus_dir.mkdir(parents=True, exist_ok=True)
    (corpus_dir / "rust.md").write_text(
        "# Rust\nRust guarantees memory safety through ownership and borrowing.\n"
        "The borrow checker prevents data races at compile time.\n"
    )
    (corpus_dir / "python.md").write_text(
        "# Python\nPython is a dynamically-typed language popular for scripting.\n"
        "It uses garbage collection for memory management.\n"
    )
    (corpus_dir / "cooking.md").write_text(
        "# Cooking\nSautéing involves cooking food quickly in a small amount of oil.\n"
        "Mise en place means having all your ingredients ready before cooking.\n"
    )


# ---------------------------------------------------------------------------
# Test: full workflow
# ---------------------------------------------------------------------------


# Mark as slow if the marker exists in pytest
def test_trial_smoke_full_workflow(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Smoke test: init → index → stats → debug → mcp → search → expand."""
    config_path = tmp_path / "config" / "config.toml"
    data_path = tmp_path / "data"
    corpus_dir = tmp_path / "corpus"

    # Redirect CLI config path to tmp_path
    monkeypatch.setattr(_cli_module, "_RAGKIT_CONFIG_FILE", config_path)
    monkeypatch.setenv("RAGKIT_CONFIG", str(config_path))

    # Create corpus with 3 markdown files
    _make_corpus(corpus_dir)

    # -----------------------------------------------------------------------
    # Step 1: rag init
    # -----------------------------------------------------------------------
    result = runner.invoke(
        app,
        [
            "init",
            "--non-interactive",
            "--profile", "lean",
            "--path", str(data_path),
        ],
    )
    assert result.exit_code == 0, f"init failed:\n{result.output}"
    assert config_path.exists(), "config.toml not created"

    # -----------------------------------------------------------------------
    # Step 2: rag index
    # -----------------------------------------------------------------------
    result = runner.invoke(
        app,
        ["index", str(corpus_dir), "--collection", "docs", "--config", str(config_path)],
    )
    assert result.exit_code == 0, f"index failed:\n{result.output}"

    # -----------------------------------------------------------------------
    # Step 3: rag stats
    # -----------------------------------------------------------------------
    result = runner.invoke(app, ["stats", "--config", str(config_path)])
    assert result.exit_code == 0, f"stats failed:\n{result.output}"
    assert "docs" in result.output, "Expected 'docs' in stats output"

    # -----------------------------------------------------------------------
    # Step 4: rag debug
    # -----------------------------------------------------------------------
    result = runner.invoke(
        app,
        ["debug", "memory safety", "--config", str(config_path)],
    )
    assert result.exit_code == 0, f"debug failed:\n{result.output}"
    assert "rust" in result.output.lower(), "Expected 'rust' in debug output"

    # -----------------------------------------------------------------------
    # Step 5: MCP server subprocess flow
    # -----------------------------------------------------------------------
    proc = subprocess.Popen(
        [sys.executable, "-m", "cli", "mcp", "--config", str(config_path)],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
    )

    try:
        assert proc.stdin and proc.stdout, "Failed to open subprocess pipes"

        # Step 5a: Send initialize handshake
        init_req = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "smoke_test", "version": "0"},
            },
        })
        proc.stdin.write(init_req + "\n")
        proc.stdin.flush()

        init_resp_line = proc.stdout.readline()
        assert init_resp_line.strip(), "No response from MCP server on initialize"
        init_resp = json.loads(init_resp_line)
        assert "result" in init_resp, f"Initialize response missing 'result': {init_resp}"
        assert init_resp["result"]["serverInfo"]["name"] == "raglocal", \
            f"Expected serverInfo.name == 'raglocal', got {init_resp['result']['serverInfo']['name']}"

        # Step 5b: Send tools/call search
        search_req = json.dumps({
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/call",
            "params": {
                "name": "search",
                "arguments": {
                    "query": "memory safety",
                    "top_k": 3,
                },
            },
        })
        proc.stdin.write(search_req + "\n")
        proc.stdin.flush()

        search_resp_line = proc.stdout.readline()
        assert search_resp_line.strip(), "No response from MCP server on search"
        search_resp = json.loads(search_resp_line)
        assert "result" in search_resp, f"Search response missing 'result': {search_resp}"
        assert "content" in search_resp["result"], "Search result missing 'content'"
        content = search_resp["result"]["content"]
        assert isinstance(content, list), f"Expected content to be list, got {type(content)}"
        assert len(content) > 0, "Expected non-empty content list"
        assert content[0]["type"] == "text", f"Expected content[0].type == 'text', got {content[0]['type']}"

        search_payload = json.loads(content[0]["text"])
        hits = search_payload.get("hits", [])
        assert hits, "Expected non-empty hits list in search response"

        # Step 5c: Send tools/call expand with first hit's ID
        first_hit_id = hits[0]["id"]
        expand_req = json.dumps({
            "jsonrpc": "2.0",
            "id": 3,
            "method": "tools/call",
            "params": {
                "name": "expand",
                "arguments": {
                    "ids": [first_hit_id],
                },
            },
        })
        proc.stdin.write(expand_req + "\n")
        proc.stdin.flush()

        expand_resp_line = proc.stdout.readline()
        assert expand_resp_line.strip(), "No response from MCP server on expand"
        expand_resp = json.loads(expand_resp_line)
        assert "result" in expand_resp, f"Expand response missing 'result': {expand_resp}"
        expand_content = expand_resp["result"]["content"]
        assert isinstance(expand_content, list), "Expected expand content to be list"
        assert len(expand_content) > 0, "Expected non-empty expand content"
        assert expand_content[0]["type"] == "text", "Expected expand content[0].type == 'text'"

        expand_payload = json.loads(expand_content[0]["text"])
        chunks = expand_payload.get("chunks", [])
        assert chunks, "Expected non-empty chunks list in expand response"
        assert "text" in chunks[0], "Expected 'text' field in first chunk"
        chunk_text = chunks[0]["text"]
        assert "rust" in chunk_text.lower(), \
            f"Expected 'rust' in expanded chunk text, got: {chunk_text}"

    finally:
        # Clean up
        if proc.stdin:
            proc.stdin.close()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
