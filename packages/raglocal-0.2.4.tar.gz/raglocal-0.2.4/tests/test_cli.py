"""Tests for the CLI."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from cli import app
from raglocal.config import (
    CollectionConfig,
    Config,
    EmbedderConfig,
    ModelSpec,
    RerankerConfig,
    RetrievalConfig,
    StoreConfig,
)

runner = CliRunner()


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_config() -> Config:
    """Create a minimal test config."""
    return Config(
        state_dir="/tmp/raglocal",
        log_level="info",
        store=StoreConfig(backend="lance", path="/tmp/raglocal/lance"),
        embedder=EmbedderConfig(
            profile="custom", provider="ollama", model="bge-m3", host="http://localhost:11434", dim=1024, cache_dir=None
        ),
        reranker=RerankerConfig(enabled=False, model="bge-reranker-v2-m3"),
        retrieval=RetrievalConfig(top_n=20, top_k=5, hybrid_alpha=0.5),
        models={
            "smart": ModelSpec(alias="smart", provider="ollama", model="qwen3:32b"),
            "fast": ModelSpec(alias="fast", provider="ollama", model="phi4:latest"),
        },
        default_model="smart",
        default_collections=["docs"],
        collections={
            "docs": CollectionConfig(name="docs", chunk_size=800, chunk_overlap=100),
        },
    )


# ---------------------------------------------------------------------------
# models command
# ---------------------------------------------------------------------------


def test_models_help() -> None:
    """Test that 'rag models --help' shows expected help text."""
    result = runner.invoke(app, ["models", "--help"])
    assert result.exit_code == 0
    assert "List configured model aliases" in result.stdout


def test_models_with_config(mock_config: Config) -> None:
    """Test 'rag models' displays a table of models."""
    with patch("cli.load_config", return_value=mock_config):
        result = runner.invoke(app, ["models"])
        assert result.exit_code == 0
        assert "smart" in result.stdout
        assert "qwen3:32b" in result.stdout
        assert "fast" in result.stdout


def test_models_config_error() -> None:
    """Test 'rag models' with config error."""
    with patch("cli.load_config", side_effect=ValueError("Bad config")):
        result = runner.invoke(app, ["models"])
        assert result.exit_code == 2


def test_models_file_not_found() -> None:
    """Test 'rag models' when config file does not exist."""
    with patch("cli.load_config", side_effect=FileNotFoundError("Config not found")):
        result = runner.invoke(app, ["models"])
        assert result.exit_code == 2


# ---------------------------------------------------------------------------
# collections command
# ---------------------------------------------------------------------------


def test_collections_help() -> None:
    """Test that 'rag collections --help' shows expected help text."""
    result = runner.invoke(app, ["collections", "--help"])
    assert result.exit_code == 0
    assert "collections" in result.stdout.lower()


def test_collections_with_store(mock_config: Config) -> None:
    """Test 'rag collections' displays Qdrant collections."""
    mock_store = MagicMock()
    mock_store.count.return_value = 42

    with (
        patch("cli.load_config", return_value=mock_config),
        patch("cli.LanceStore", return_value=mock_store),
    ):
        result = runner.invoke(app, ["collections"])
        assert result.exit_code == 0
        assert "docs" in result.stdout
        assert "42" in result.stdout


def test_collections_qdrant_unreachable(mock_config: Config) -> None:
    """Test 'rag collections' when Qdrant is unreachable."""
    with (
        patch("cli.load_config", return_value=mock_config),
        patch("cli.LanceStore", side_effect=Exception("Connection failed")),
    ):
        result = runner.invoke(app, ["collections"])
        assert result.exit_code == 3


# ---------------------------------------------------------------------------
# doctor command
# ---------------------------------------------------------------------------


def test_doctor_help() -> None:
    """Test that 'rag doctor --help' shows expected help text."""
    result = runner.invoke(app, ["doctor", "--help"])
    assert result.exit_code == 0
    assert "Health check" in result.stdout or "doctor" in result.stdout.lower()


def test_doctor_all_checks_pass(mock_config: Config) -> None:
    """Test 'rag doctor' when all checks pass."""
    mock_store = MagicMock()
    mock_store.count.return_value = 1

    with (
        patch("cli.load_config", return_value=mock_config),
        patch("cli.LanceStore", return_value=mock_store),
        patch("httpx.Client") as mock_client_ctx,
    ):
        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_client.get.return_value = mock_response
        mock_client_ctx.return_value.__enter__.return_value = mock_client

        result = runner.invoke(app, ["doctor"])
        assert result.exit_code == 0
        assert "passed" in result.stdout.lower() or "✓" in result.stdout


def test_doctor_config_error() -> None:
    """Test 'rag doctor' with config error."""
    with patch("cli.load_config", side_effect=FileNotFoundError("Config not found")):
        result = runner.invoke(app, ["doctor"])
        assert result.exit_code == 2


def test_doctor_qdrant_unreachable(mock_config: Config) -> None:
    """Test 'rag doctor' when Qdrant is unreachable."""
    with (
        patch("cli.load_config", return_value=mock_config),
        patch("cli.LanceStore", side_effect=Exception("Connection failed")),
    ):
        result = runner.invoke(app, ["doctor"])
        assert result.exit_code == 3


# ---------------------------------------------------------------------------
# init command
# ---------------------------------------------------------------------------


def test_init_help() -> None:
    """Test that 'rag init --help' shows expected help text."""
    result = runner.invoke(app, ["init", "--help"])
    assert result.exit_code == 0
    assert "init" in result.stdout.lower()


def test_init_non_interactive(tmp_path: Path) -> None:
    """Test 'rag init --non-interactive --profile lean' writes config file."""

    config_file = tmp_path / "config.toml"
    data_dir = tmp_path / "data"

    with patch("cli._RAGKIT_CONFIG_FILE", config_file):
        result = runner.invoke(
            app,
            ["init", "--non-interactive", "--profile", "lean", "--path", str(data_dir)],
        )
        assert result.exit_code == 0, result.output
        assert config_file.exists()
        content = config_file.read_text()
        assert "lean" in content
        assert "Config written" in result.output


def test_init_config_already_exists(tmp_path: Path) -> None:
    """Test 'rag init' fails when config already exists and --force not given."""
    existing_config = tmp_path / "config.toml"
    existing_config.write_text("[core]\nstate_dir = '/tmp'\n")

    with patch("cli._RAGKIT_CONFIG_FILE", existing_config):
        result = runner.invoke(app, ["init", "--non-interactive"])
        assert result.exit_code == 1
        assert "already exists" in result.output or "force" in result.output.lower()


# ---------------------------------------------------------------------------
# stats command
# ---------------------------------------------------------------------------


def test_stats_help() -> None:
    """Test that 'rag stats --help' shows expected help text."""
    result = runner.invoke(app, ["stats", "--help"])
    assert result.exit_code == 0
    assert "stats" in result.stdout.lower()


def test_stats_command(mock_config: Config) -> None:
    """Test 'rag stats' shows collection names and chunk counts."""
    mock_store = MagicMock()
    mock_store.count.return_value = 42
    mock_store.ensure_collection.return_value = None

    mock_state = MagicMock()
    mock_state.list_by_collection.return_value = []

    with (
        patch("cli.load_config", return_value=mock_config),
        patch("cli.LanceStore", return_value=mock_store),
        patch("cli.StateStore", return_value=mock_state),
    ):
        result = runner.invoke(app, ["stats"])
        assert result.exit_code == 0
        assert "docs" in result.stdout
        assert "42" in result.stdout


def test_stats_store_error(mock_config: Config) -> None:
    """Test 'rag stats' when store is unreachable."""
    with (
        patch("cli.load_config", return_value=mock_config),
        patch("cli.LanceStore", side_effect=Exception("Cannot open store")),
    ):
        result = runner.invoke(app, ["stats"])
        assert result.exit_code == 3


# ---------------------------------------------------------------------------
# export command
# ---------------------------------------------------------------------------


def test_export_help() -> None:
    """Test that 'rag export --help' shows expected help text."""
    result = runner.invoke(app, ["export", "--help"])
    assert result.exit_code == 0


def test_export_command(mock_config: Config, tmp_path: Path) -> None:
    """Test 'rag export' calls export_archive."""
    output_zip = str(tmp_path / "corpus.zip")

    with (
        patch("cli.load_config", return_value=mock_config),
        patch("cli.export_archive") as mock_export,
    ):
        # Need to also patch where it's imported in the function scope
        with patch("raglocal.portable.export_archive") as _:
            pass

        result = runner.invoke(app, ["export", output_zip])
        assert result.exit_code == 0
        mock_export.assert_called_once()


def test_export_failure(mock_config: Config, tmp_path: Path) -> None:
    """Test 'rag export' handles failure gracefully."""
    output_zip = str(tmp_path / "corpus.zip")

    with (
        patch("cli.load_config", return_value=mock_config),
        patch("cli.export_archive", side_effect=FileNotFoundError("No manifest")),
    ):
        result = runner.invoke(app, ["export", output_zip])
        assert result.exit_code == 1


# ---------------------------------------------------------------------------
# import command
# ---------------------------------------------------------------------------


def test_import_help() -> None:
    """Test that 'rag import --help' shows expected help text."""
    result = runner.invoke(app, ["import", "--help"])
    assert result.exit_code == 0


def test_import_command(mock_config: Config, tmp_path: Path) -> None:
    """Test 'rag import' calls import_archive."""
    from raglocal.manifest import Manifest

    input_zip = str(tmp_path / "corpus.zip")

    mock_manifest = Manifest(
        raglocal_version="1.0.0",
        embedder_provider="sentence-transformers",
        embedder_model="all-MiniLM-L6-v2",
        embedder_dim=384,
        store_backend="lance",
        chunk_strategy="token",
        created_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
        collections=["docs", "code"],
    )

    with (
        patch("cli.load_config", return_value=mock_config),
        patch("cli.import_archive", return_value=mock_manifest) as mock_import,
    ):
        result = runner.invoke(app, ["import", input_zip])
        assert result.exit_code == 0
        mock_import.assert_called_once()
        assert "all-MiniLM-L6-v2" in result.stdout
        assert "docs" in result.stdout


def test_import_failure(mock_config: Config, tmp_path: Path) -> None:
    """Test 'rag import' handles failure gracefully."""
    input_zip = str(tmp_path / "corpus.zip")

    with (
        patch("cli.load_config", return_value=mock_config),
        patch("cli.import_archive", side_effect=ValueError("Malformed archive")),
    ):
        result = runner.invoke(app, ["import", input_zip])
        assert result.exit_code == 1
