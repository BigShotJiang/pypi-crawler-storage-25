"""Tests for Wave 7A: embedder fingerprint, compat checks, reindex command."""

from __future__ import annotations

from pathlib import Path

import pytest
from typer.testing import CliRunner

from raglocal.config import EmbedderConfig
from raglocal.manifest import Manifest, is_embedder_compatible
from raglocal.store import LanceStore

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_manifest(**overrides) -> Manifest:  # type: ignore[no-untyped-def]
    defaults = dict(
        raglocal_version="0.2.0",
        embedder_provider="sentence-transformers",
        embedder_model="all-MiniLM-L6-v2",
        embedder_dim=384,
        store_backend="lance",
        chunk_strategy="token",
        created_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
        collections=["docs"],
        profile_name="lean",
    )
    defaults.update(overrides)
    return Manifest(**defaults)


def _make_embedder_cfg(**overrides) -> EmbedderConfig:  # type: ignore[no-untyped-def]
    defaults = dict(
        profile="lean",
        provider="sentence-transformers",
        model="all-MiniLM-L6-v2",
        host=None,
        dim=384,
        cache_dir=None,
    )
    defaults.update(overrides)
    return EmbedderConfig(**defaults)


# ---------------------------------------------------------------------------
# 1. test_manifest_embedder_fingerprint
# ---------------------------------------------------------------------------


def test_manifest_embedder_fingerprint() -> None:
    m = _make_manifest(
        embedder_provider="sentence-transformers",
        embedder_model="all-MiniLM-L6-v2",
        embedder_dim=384,
    )
    fp = m.embedder_fingerprint()
    assert fp == "sentence-transformers:all-MiniLM-L6-v2:384"
    # Must be provider:model:dim format
    parts = fp.split(":")
    assert len(parts) == 3
    assert parts[2] == "384"


# ---------------------------------------------------------------------------
# 2. test_is_embedder_compatible_match
# ---------------------------------------------------------------------------


def test_is_embedder_compatible_match() -> None:
    m = _make_manifest()
    cfg = _make_embedder_cfg()
    ok, reason = is_embedder_compatible(m, cfg)
    assert ok is True
    assert reason == ""


# ---------------------------------------------------------------------------
# 3. test_is_embedder_compatible_mismatch
# ---------------------------------------------------------------------------


def test_is_embedder_compatible_mismatch() -> None:
    m = _make_manifest(embedder_model="all-MiniLM-L6-v2", embedder_dim=384)
    cfg = _make_embedder_cfg(model="nomic-embed-text-v1.5", dim=768)
    ok, reason = is_embedder_compatible(m, cfg)
    assert ok is False
    assert reason  # non-empty
    assert "model" in reason or "dim" in reason


# ---------------------------------------------------------------------------
# 4. test_is_embedder_compatible_legacy_manifest
# ---------------------------------------------------------------------------


def test_is_embedder_compatible_legacy_manifest() -> None:
    m = _make_manifest(
        embedder_provider="",
        embedder_model="",
        embedder_dim=0,
    )
    cfg = _make_embedder_cfg()
    ok, reason = is_embedder_compatible(m, cfg)
    assert ok is True
    assert "legacy" in reason.lower() or "predates" in reason.lower() or "upgrade" in reason.lower()


# ---------------------------------------------------------------------------
# 5. test_check_embedder_compat_no_manifest
# ---------------------------------------------------------------------------


def test_check_embedder_compat_no_manifest(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """No manifest on disk → _check_embedder_compat is a no-op."""
    import cli as cli_module
    from raglocal.config import (
        CollectionConfig,
        Config,
        ModelSpec,
        RerankerConfig,
        RetrievalConfig,
        StoreConfig,
    )

    lance_path = tmp_path / "lance"
    lance_path.mkdir()
    cfg = Config(
        state_dir=str(tmp_path / "state"),
        log_level="info",
        store=StoreConfig(backend="lance", path=str(lance_path)),
        embedder=_make_embedder_cfg(),
        reranker=RerankerConfig(enabled=False, model=""),
        retrieval=RetrievalConfig(top_n=5, top_k=3, hybrid_alpha=0.5),
        models={"smart": ModelSpec(alias="smart", provider="ollama", model="qwen3")},
        default_model="smart",
        default_collections=["docs"],
        collections={
            "docs": CollectionConfig(name="docs", chunk_size=800, chunk_overlap=100)
        },
    )

    # Should not raise
    cli_module._check_embedder_compat(cfg)


# ---------------------------------------------------------------------------
# 6. test_check_embedder_compat_match
# ---------------------------------------------------------------------------


def test_check_embedder_compat_match(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Manifest present and matches config → no-op."""
    import cli as cli_module
    from raglocal.config import (
        CollectionConfig,
        Config,
        ModelSpec,
        RerankerConfig,
        RetrievalConfig,
        StoreConfig,
    )

    lance_path = tmp_path / "lance"
    lance_path.mkdir()

    # Write matching manifest in parent (data_dir = tmp_path)
    m = _make_manifest(
        embedder_provider="sentence-transformers",
        embedder_model="all-MiniLM-L6-v2",
        embedder_dim=384,
        profile_name="lean",
    )
    m.write(tmp_path)  # manifest lives in tmp_path (parent of lance/)

    cfg = Config(
        state_dir=str(tmp_path / "state"),
        log_level="info",
        store=StoreConfig(backend="lance", path=str(lance_path)),
        embedder=_make_embedder_cfg(),
        reranker=RerankerConfig(enabled=False, model=""),
        retrieval=RetrievalConfig(top_n=5, top_k=3, hybrid_alpha=0.5),
        models={"smart": ModelSpec(alias="smart", provider="ollama", model="qwen3")},
        default_model="smart",
        default_collections=["docs"],
        collections={
            "docs": CollectionConfig(name="docs", chunk_size=800, chunk_overlap=100)
        },
    )

    # Should not raise
    cli_module._check_embedder_compat(cfg)


# ---------------------------------------------------------------------------
# 7. test_check_embedder_compat_mismatch_exits
# ---------------------------------------------------------------------------


def test_check_embedder_compat_mismatch_exits(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Manifest present with different model → SystemExit(4)."""
    import cli as cli_module
    from raglocal.config import (
        CollectionConfig,
        Config,
        ModelSpec,
        RerankerConfig,
        RetrievalConfig,
        StoreConfig,
    )

    lance_path = tmp_path / "lance"
    lance_path.mkdir()

    # Manifest says lean (all-MiniLM-L6-v2:384)
    m = _make_manifest(
        embedder_provider="sentence-transformers",
        embedder_model="all-MiniLM-L6-v2",
        embedder_dim=384,
        profile_name="lean",
    )
    m.write(tmp_path)

    # Config says balanced (nomic-embed-text-v1.5:768)
    cfg = Config(
        state_dir=str(tmp_path / "state"),
        log_level="info",
        store=StoreConfig(backend="lance", path=str(lance_path)),
        embedder=_make_embedder_cfg(
            profile="balanced",
            model="nomic-embed-text-v1.5",
            dim=768,
        ),
        reranker=RerankerConfig(enabled=False, model=""),
        retrieval=RetrievalConfig(top_n=5, top_k=3, hybrid_alpha=0.5),
        models={"smart": ModelSpec(alias="smart", provider="ollama", model="qwen3")},
        default_model="smart",
        default_collections=["docs"],
        collections={
            "docs": CollectionConfig(name="docs", chunk_size=800, chunk_overlap=100)
        },
    )

    with pytest.raises(SystemExit) as exc_info:
        cli_module._check_embedder_compat(cfg)
    assert exc_info.value.code == 4


# ---------------------------------------------------------------------------
# 8. test_reindex_command_help
# ---------------------------------------------------------------------------


def test_reindex_command_help() -> None:
    from cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["reindex", "--help"])
    assert result.exit_code == 0
    assert "reindex" in result.output.lower() or "re-embed" in result.output.lower() or "collection" in result.output.lower()


# ---------------------------------------------------------------------------
# 9. test_drop_collection
# ---------------------------------------------------------------------------


def test_drop_collection(tmp_path: Path) -> None:
    """drop_collection removes the table; ensure_collection after succeeds with count 0."""
    import asyncio
    import random

    from raglocal.store import Chunk

    store = LanceStore(str(tmp_path / "db"))
    store.ensure_collection("test_drop", dim=4, with_sparse=False)

    # Upsert a row
    chunk = Chunk(
        text="hello",
        source_uri="file:///test.txt",
        source_type="docs",
        collection="test_drop",
        chunk_idx=0,
        chunk_total=1,
        heading_path=[],
        line_start=1,
        line_end=1,
        mtime=1700000000,
        content_hash="abc",
        tags=[],
        extra=None,
    )
    vector = [random.random() for _ in range(4)]
    asyncio.run(store.upsert("test_drop", [vector], [chunk]))
    assert store.count("test_drop") == 1

    # Drop the collection
    store.drop_collection("test_drop")

    # Dropping again should not raise (ignore_missing)
    store.drop_collection("test_drop")

    # Re-create should succeed and be empty
    store.ensure_collection("test_drop", dim=4, with_sparse=False)
    assert store.count("test_drop") == 0
