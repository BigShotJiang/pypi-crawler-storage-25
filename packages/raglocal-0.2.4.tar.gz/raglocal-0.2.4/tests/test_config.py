from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import patch

import pytest

from raglocal.config import (
    CollectionConfig,
    Config,
    EmbedderConfig,
    ModelSpec,
    RerankerConfig,
    RetrievalConfig,
    StoreConfig,
    load_config,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _base_toml(
    *,
    store_section: str = '[store]\nbackend = "lance"\npath    = "~/.local/share/raglocal/lance"\n',
    embedder_section: str = (
        '[embedder]\nprovider = "ollama"\nmodel    = "bge-m3"\n'
        'host     = "http://localhost:11434"\ndim      = 1024\n'
    ),
) -> str:
    return f"""
[core]
state_dir = "~/.local/share/raglocal"
log_level = "info"

{store_section}

{embedder_section}

[reranker]
enabled  = false
model    = "bge-reranker-v2-m3"

[retrieval]
top_n        = 20
top_k        = 5
hybrid_alpha = 0.5

[models.smart]
provider = "ollama"
model    = "qwen3:32b"

[defaults]
model       = "smart"
collections = ["docs"]

[collections.docs]
chunk_size    = 800
chunk_overlap = 100
"""


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def config_full_path(tmp_path: Path) -> Path:
    """Fixture for the full config file path."""
    full_config_content = """
[core]
state_dir = "~/.local/share/raglocal"
log_level = "info"

[store]
backend = "lance"
path    = "~/.local/share/raglocal/lance"

[embedder]
provider = "ollama"
model    = "bge-m3"
host     = "http://localhost:11434"
dim      = 1024

[reranker]
enabled  = false
model    = "bge-reranker-v2-m3"

[retrieval]
top_n        = 20
top_k        = 5
hybrid_alpha = 0.5

[models.fast]
provider = "ollama"
model    = "phi4:latest"

[models.smart]
provider = "ollama"
model    = "qwen3:32b"

[defaults]
model       = "smart"
collections = ["docs"]

[collections.docs]
chunk_size    = 800
chunk_overlap = 100
"""
    config_file = tmp_path / "config_full.toml"
    config_file.write_text(full_config_content)
    return config_file


@pytest.fixture
def config_minimal_path(tmp_path: Path) -> Path:
    """Fixture for the minimal config file path."""
    minimal_config_content = """
[core]
state_dir = "~/.local/share/raglocal_min"
log_level = "debug"

[store]
backend = "lance"
path    = "~/.local/share/raglocal_min/lance"

[embedder]
provider = "ollama"
model    = "min_embed_model"
host     = "http://localhost:11434"
dim      = 768

[reranker]
enabled  = false
model    = "min_rerank_model"

[retrieval]
top_n        = 10
top_k        = 3
hybrid_alpha = 0.8

[models.default_model_alias]
provider = "ollama"
model    = "min_model"

[defaults]
model       = "default_model_alias"
collections = ["min_collection"]

[collections.min_collection]
chunk_size    = 100
chunk_overlap = 10
"""
    config_file = tmp_path / "config_minimal.toml"
    config_file.write_text(minimal_config_content)
    return config_file


# ---------------------------------------------------------------------------
# Migrated existing tests (qdrant → store)
# ---------------------------------------------------------------------------

def test_load_config_full(config_full_path: Path) -> None:
    config = load_config(str(config_full_path))
    assert isinstance(config, Config)
    assert config.state_dir == os.path.expanduser("~/.local/share/raglocal")
    assert config.log_level == "info"

    assert config.store == StoreConfig(backend="lance", path=os.path.expanduser("~/.local/share/raglocal/lance"))
    assert config.embedder == EmbedderConfig(
        profile="custom",
        provider="ollama",
        model="bge-m3",
        host="http://localhost:11434",
        dim=1024,
        cache_dir=None,
    )
    assert config.reranker == RerankerConfig(enabled=False, model="bge-reranker-v2-m3")
    assert config.retrieval == RetrievalConfig(top_n=20, top_k=5, hybrid_alpha=0.5)

    assert len(config.models) == 2
    assert config.models["fast"] == ModelSpec(alias="fast", provider="ollama", model="phi4:latest")
    assert config.models["smart"] == ModelSpec(alias="smart", provider="ollama", model="qwen3:32b")

    assert config.default_model == "smart"
    assert config.default_collections == ["docs"]

    assert len(config.collections) == 1
    assert config.collections["docs"] == CollectionConfig(
        name="docs", chunk_size=800, chunk_overlap=100
    )


def test_load_config_minimal(config_minimal_path: Path) -> None:
    config = load_config(str(config_minimal_path))
    assert isinstance(config, Config)
    assert config.state_dir == os.path.expanduser("~/.local/share/raglocal_min")
    assert config.log_level == "debug"
    assert config.store == StoreConfig(
        backend="lance", path=os.path.expanduser("~/.local/share/raglocal_min/lance")
    )
    assert config.embedder == EmbedderConfig(
        profile="custom",
        provider="ollama",
        model="min_embed_model",
        host="http://localhost:11434",
        dim=768,
        cache_dir=None,
    )
    assert config.reranker == RerankerConfig(enabled=False, model="min_rerank_model")
    assert config.retrieval == RetrievalConfig(top_n=10, top_k=3, hybrid_alpha=0.8)
    assert len(config.models) == 1
    assert config.models["default_model_alias"] == ModelSpec(
        alias="default_model_alias", provider="ollama", model="min_model"
    )
    assert config.default_model == "default_model_alias"
    assert config.default_collections == ["min_collection"]
    assert len(config.collections) == 1
    assert config.collections["min_collection"] == CollectionConfig(
        name="min_collection", chunk_size=100, chunk_overlap=10
    )


def test_load_config_file_not_found() -> None:
    with pytest.raises(FileNotFoundError, match="Config file not found at /nonexistent/path"):
        load_config("/nonexistent/path")


def test_load_config_from_env_var(config_minimal_path: Path) -> None:
    with patch.dict(os.environ, {"RAGKIT_CONFIG": str(config_minimal_path)}):
        config = load_config()
        assert config.default_model == "default_model_alias"


def test_load_config_embedder_dim_validation(tmp_path: Path) -> None:
    config_file = tmp_path / "config_bad_dim.toml"
    config_file.write_text(
        _base_toml(
            embedder_section=(
                '[embedder]\nprovider = "ollama"\nmodel = "bge-m3"\n'
                'host = "http://localhost:11434"\ndim = 0\n'
            )
        )
    )
    with pytest.raises(ValueError, match="embedder.dim must be greater than 0"):
        load_config(str(config_file))


def test_load_config_retrieval_top_n_top_k_validation(tmp_path: Path) -> None:
    bad_top_k = tmp_path / "config_bad_top_k.toml"
    bad_top_k.write_text(
        _base_toml().replace("top_n        = 20\ntop_k        = 5", "top_n        = 3\ntop_k        = 5")
    )
    with pytest.raises(
        ValueError, match="retrieval.top_n must be >= retrieval.top_k and both >= 1"
    ):
        load_config(str(bad_top_k))

    bad_zero = tmp_path / "config_bad_top_k_zero.toml"
    bad_zero.write_text(
        _base_toml().replace("top_n        = 20\ntop_k        = 5", "top_n        = 5\ntop_k        = 0")
    )
    with pytest.raises(
        ValueError, match="retrieval.top_n must be >= retrieval.top_k and both >= 1"
    ):
        load_config(str(bad_zero))


def test_load_config_hybrid_alpha_validation(tmp_path: Path) -> None:
    config_file = tmp_path / "config_bad_alpha.toml"
    config_file.write_text(
        _base_toml().replace("hybrid_alpha = 0.5", "hybrid_alpha = 2.0")
    )
    with pytest.raises(ValueError, match="hybrid_alpha must be between 0.0 and 1.0"):
        load_config(str(config_file))


def test_load_config_unknown_default_model_validation(tmp_path: Path) -> None:
    config_file = tmp_path / "config_unknown_model.toml"
    config_file.write_text(
        _base_toml().replace('model       = "smart"', 'model       = "unknown_model"')
    )
    with pytest.raises(ValueError, match="default_model 'unknown_model' not found in models"):
        load_config(str(config_file))


def test_load_config_unknown_default_collection_validation(tmp_path: Path) -> None:
    config_file = tmp_path / "config_unknown_collection.toml"
    config_file.write_text(
        _base_toml().replace('collections = ["docs"]', 'collections = ["unknown_collection"]')
    )
    with pytest.raises(
        ValueError, match="Default collection 'unknown_collection' not found in collections"
    ):
        load_config(str(config_file))


def _make_config(tmp_path: Path, name: str, overrides: dict[str, str]) -> Path:
    """
    Build a minimal valid TOML config (store-based), apply string-level overrides, write it.
    ``overrides`` maps section.key → replacement line (the entire key = value line
    is replaced, or the key line is removed when the replacement is an empty string).
    """
    lines = _base_toml()
    content = lines
    for dotted_key, replacement in overrides.items():
        raw_key = dotted_key.split(".", 1)[1]
        import re
        content = re.sub(rf"(?m)^{re.escape(raw_key)}\s*=.*\n", replacement, content)
    config_file = tmp_path / name
    config_file.write_text(content)
    return config_file


def test_load_config_missing_store_backend_raises(tmp_path: Path) -> None:
    config_file = _make_config(tmp_path, "missing_store_backend.toml", {"store.backend": ""})
    with pytest.raises(ValueError, match=r"store.*backend|backend.*store"):
        load_config(str(config_file))


def test_load_config_missing_embedder_host_does_not_raise_for_custom_profile(tmp_path: Path) -> None:
    # For custom profile, host is optional (defaults to None)
    config_file = _make_config(tmp_path, "no_host.toml", {"embedder.host": ""})
    config = load_config(str(config_file))
    assert config.embedder.host is None


def test_config_state_dir_tilde_expansion(tmp_path: Path) -> None:
    config_content = _base_toml().replace(
        'state_dir = "~/.local/share/raglocal"', 'state_dir = "~/test_raglocal_state"'
    )
    config_file = tmp_path / "config_tilde.toml"
    config_file.write_text(config_content)
    config = load_config(str(config_file))
    assert config.state_dir == os.path.expanduser("~/test_raglocal_state")


# ---------------------------------------------------------------------------
# New tests
# ---------------------------------------------------------------------------

def _profile_toml(tmp_path: Path, name: str, profile_line: str, extras: str = "") -> Path:
    """Write a config using an embedder profile instead of explicit fields."""
    content = f"""
[core]
state_dir = "~/.local/share/raglocal"
log_level = "info"

[store]
backend = "lance"
path    = "~/.local/share/raglocal/lance"

[embedder]
{profile_line}
{extras}

[reranker]
enabled  = false
model    = "bge-reranker-v2-m3"

[retrieval]
top_n        = 20
top_k        = 5
hybrid_alpha = 0.5

[models.smart]
provider = "ollama"
model    = "qwen3:32b"

[defaults]
model       = "smart"
collections = ["docs"]

[collections.docs]
chunk_size    = 800
chunk_overlap = 100
"""
    p = tmp_path / name
    p.write_text(content)
    return p


def test_profile_lean_resolves(tmp_path: Path) -> None:
    cfg_path = _profile_toml(tmp_path, "lean.toml", 'profile = "lean"')
    config = load_config(str(cfg_path))
    assert config.embedder.profile == "lean"
    assert config.embedder.provider == "sentence-transformers"
    assert config.embedder.model == "all-MiniLM-L6-v2"
    assert config.embedder.dim == 384
    assert config.embedder.host is None


def test_profile_balanced_resolves(tmp_path: Path) -> None:
    cfg_path = _profile_toml(tmp_path, "balanced.toml", 'profile = "balanced"')
    config = load_config(str(cfg_path))
    assert config.embedder.profile == "balanced"
    assert config.embedder.provider == "sentence-transformers"
    assert config.embedder.model == "nomic-embed-text-v1.5"
    assert config.embedder.dim == 768
    assert config.embedder.host is None


def test_profile_powerful_resolves_with_default_host(tmp_path: Path) -> None:
    cfg_path = _profile_toml(tmp_path, "powerful.toml", 'profile = "powerful"')
    config = load_config(str(cfg_path))
    assert config.embedder.profile == "powerful"
    assert config.embedder.provider == "ollama"
    assert config.embedder.model == "bge-m3"
    assert config.embedder.dim == 1024
    assert config.embedder.host == "http://localhost:11434"


def test_profile_custom_requires_explicit_fields(tmp_path: Path) -> None:
    # custom profile with missing provider/model/dim should fail
    cfg_path = _profile_toml(tmp_path, "custom_missing.toml", 'profile = "custom"')
    with pytest.raises(ValueError, match=r"embedder.*provider|provider.*embedder"):
        load_config(str(cfg_path))


def test_qdrant_section_raises_helpful_error(tmp_path: Path) -> None:
    content = """
[core]
state_dir = "~/.local/share/raglocal"
log_level = "info"

[qdrant]
url = "http://localhost:6333"

[embedder]
provider = "ollama"
model    = "bge-m3"
host     = "http://localhost:11434"
dim      = 1024

[reranker]
enabled  = false
model    = "bge-reranker-v2-m3"

[retrieval]
top_n        = 20
top_k        = 5
hybrid_alpha = 0.5

[models.smart]
provider = "ollama"
model    = "qwen3:32b"

[defaults]
model       = "smart"
collections = ["docs"]

[collections.docs]
chunk_size    = 800
chunk_overlap = 100
"""
    config_file = tmp_path / "qdrant_config.toml"
    config_file.write_text(content)
    with pytest.raises(ValueError, match=r"\[qdrant\].*no longer supported|\[store\]"):
        load_config(str(config_file))


def test_store_path_tilde_expansion(tmp_path: Path) -> None:
    cfg_path = _profile_toml(
        tmp_path,
        "tilde_store.toml",
        'profile = "powerful"',
    )
    # Replace the store path with a tilde path
    content = cfg_path.read_text().replace(
        'path    = "~/.local/share/raglocal/lance"',
        'path    = "~/path/to/lance"',
    )
    cfg_path.write_text(content)
    config = load_config(str(cfg_path))
    assert config.store.path == os.path.expanduser("~/path/to/lance")
    assert not config.store.path.startswith("~")


def test_chunk_strategy_loads_correctly(tmp_path: Path) -> None:
    content = _base_toml() + '\n[collections.code]\nchunk_size = 500\nchunk_overlap = 50\nchunk_strategy = "code-aware"\n'
    # Also update defaults to include code
    content = content.replace('collections = ["docs"]', 'collections = ["docs", "code"]')
    cfg_file = tmp_path / "chunk_strategy.toml"
    cfg_file.write_text(content)
    config = load_config(str(cfg_file))
    assert config.collections["docs"].chunk_strategy == "token"  # default
    assert config.collections["code"].chunk_strategy == "code-aware"
