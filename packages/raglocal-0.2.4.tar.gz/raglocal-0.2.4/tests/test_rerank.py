"""Tests for reranker module."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from raglocal.config import Config, RerankerConfig, RetrievalConfig
from raglocal.rerank import Reranker, _cosine_similarity
from raglocal.store import SearchResult


@pytest.fixture
def disabled_config() -> Config:
    """Config with reranker disabled."""
    return MagicMock(
        spec=Config,
        reranker=RerankerConfig(enabled=False, model="bge-reranker-v2-m3"),
        retrieval=RetrievalConfig(top_n=10, top_k=5, hybrid_alpha=0.0),
    )


@pytest.fixture
def enabled_config() -> Config:
    """Config with reranker enabled."""
    return MagicMock(
        spec=Config,
        reranker=RerankerConfig(enabled=True, model="bge-reranker-v2-m3"),
        retrieval=RetrievalConfig(top_n=10, top_k=5, hybrid_alpha=0.0),
    )


@pytest.fixture
def sample_results() -> list[SearchResult]:
    """Sample search results."""
    return [
        SearchResult(text="First result", score=0.9, payload={"id": 1}),
        SearchResult(text="Second result", score=0.8, payload={"id": 2}),
        SearchResult(text="Third result", score=0.7, payload={"id": 3}),
        SearchResult(text="Fourth result", score=0.6, payload={"id": 4}),
    ]


def _make_mock_embedder(vecs: list[list[float]]) -> MagicMock:
    """Create a mock Embedder that returns vecs in order."""
    embedder = MagicMock()
    embedder.embed = AsyncMock(return_value=vecs)
    return embedder


class TestCosineSimlarity:
    """Unit tests for _cosine_similarity helper."""

    def test_identical_vectors(self) -> None:
        assert _cosine_similarity([1.0, 0.0], [1.0, 0.0]) == pytest.approx(1.0)

    def test_orthogonal_vectors(self) -> None:
        assert _cosine_similarity([1.0, 0.0], [0.0, 1.0]) == pytest.approx(0.0)

    def test_opposite_vectors(self) -> None:
        assert _cosine_similarity([1.0, 0.0], [-1.0, 0.0]) == pytest.approx(-1.0)

    def test_zero_vector_returns_zero(self) -> None:
        assert _cosine_similarity([0.0, 0.0], [1.0, 0.0]) == 0.0

    def test_partial_similarity(self) -> None:
        import math
        score = _cosine_similarity([1.0, 1.0], [1.0, 0.0])
        assert score == pytest.approx(1.0 / math.sqrt(2))


class TestRerankerDisabled:
    """Test reranker in pass-through mode (disabled)."""

    @pytest.mark.asyncio
    async def test_passthrough_returns_top_k_unchanged(
        self, disabled_config: Config, sample_results: list[SearchResult]
    ) -> None:
        """When disabled, reranker returns first top_k results unchanged."""
        reranker = Reranker(disabled_config)
        result = await reranker.rerank(query="test query", results=sample_results, top_k=2)
        assert len(result) == 2
        assert result[0].text == "First result"
        assert result[1].text == "Second result"

    @pytest.mark.asyncio
    async def test_passthrough_empty_results(self, disabled_config: Config) -> None:
        """When disabled, reranker handles empty results."""
        reranker = Reranker(disabled_config)
        result = await reranker.rerank(query="test query", results=[], top_k=5)
        assert result == []

    @pytest.mark.asyncio
    async def test_passthrough_top_k_zero(
        self, disabled_config: Config, sample_results: list[SearchResult]
    ) -> None:
        """When disabled, reranker respects top_k=0."""
        reranker = Reranker(disabled_config)
        result = await reranker.rerank(query="test query", results=sample_results, top_k=0)
        assert result == []

    @pytest.mark.asyncio
    async def test_passthrough_top_k_exceeds_results(
        self, disabled_config: Config, sample_results: list[SearchResult]
    ) -> None:
        """When disabled, reranker returns all available if top_k exceeds results."""
        reranker = Reranker(disabled_config)
        result = await reranker.rerank(query="test query", results=sample_results, top_k=100)
        assert len(result) == len(sample_results)


class TestRerankerEnabled:
    """Test reranker with injected mock embedder (enabled)."""

    @pytest.mark.asyncio
    async def test_rerank_reorders_by_cosine_similarity(
        self, enabled_config: Config, sample_results: list[SearchResult]
    ) -> None:
        """Reranker reorders results by cosine similarity to the query vector.

        passage B (Third result) is most similar to query; passage A (First result)
        is least similar. Expected order: Third, Second, Fourth, First.
        """
        # query_vec is index 0; passage vecs follow
        # Use 2-D vectors for clarity: query = [1,0]
        # Third  = [0.95, 0.31] → cos ≈ 0.95  (most similar)
        # Second = [0.80, 0.60] → cos ≈ 0.80
        # Fourth = [0.60, 0.80] → cos ≈ 0.60
        # First  = [0.31, 0.95] → cos ≈ 0.31  (least similar)
        query_vec = [1.0, 0.0]
        vecs_by_text = {
            "First result":  [0.31, 0.95],
            "Second result": [0.80, 0.60],
            "Third result":  [0.95, 0.31],
            "Fourth result": [0.60, 0.80],
        }
        embed_return = [query_vec] + [vecs_by_text[r.text] for r in sample_results]
        mock_embedder = _make_mock_embedder(embed_return)

        reranker = Reranker(enabled_config, embedder=mock_embedder)
        result = await reranker.rerank(query="test query", results=sample_results, top_k=4)

        assert result[0].text == "Third result"
        assert result[1].text == "Second result"
        assert result[2].text == "Fourth result"
        assert result[3].text == "First result"

    @pytest.mark.asyncio
    async def test_rerank_passage_b_more_similar_than_a(
        self, enabled_config: Config
    ) -> None:
        """Passage B ranked above passage A when B is closer to query."""
        results = [
            SearchResult(text="passage A", score=0.9, payload={}),
            SearchResult(text="passage B", score=0.1, payload={}),
        ]
        # passage B has higher cosine similarity despite lower initial score
        query_vec = [1.0, 0.0, 0.0]
        vec_a = [0.1, 0.99, 0.0]   # nearly orthogonal to query
        vec_b = [0.99, 0.1, 0.0]   # nearly parallel to query
        mock_embedder = _make_mock_embedder([query_vec, vec_a, vec_b])

        reranker = Reranker(enabled_config, embedder=mock_embedder)
        result = await reranker.rerank(query="q", results=results, top_k=2)

        assert result[0].text == "passage B"
        assert result[1].text == "passage A"

    @pytest.mark.asyncio
    async def test_rerank_respects_top_k(
        self, enabled_config: Config, sample_results: list[SearchResult]
    ) -> None:
        """Reranker respects top_k limit."""
        query_vec = [1.0, 0.0]
        passage_vecs = [[float(i), 0.0] for i in range(len(sample_results), 0, -1)]
        mock_embedder = _make_mock_embedder([query_vec] + passage_vecs)

        reranker = Reranker(enabled_config, embedder=mock_embedder)
        result = await reranker.rerank(query="test query", results=sample_results, top_k=2)

        assert len(result) == 2

    @pytest.mark.asyncio
    async def test_rerank_embed_failure_fallback(
        self, enabled_config: Config, sample_results: list[SearchResult]
    ) -> None:
        """When embedder raises, reranker falls back to pass-through."""
        mock_embedder = MagicMock()
        mock_embedder.embed = AsyncMock(side_effect=RuntimeError("embed failed"))

        reranker = Reranker(enabled_config, embedder=mock_embedder)
        result = await reranker.rerank(query="test query", results=sample_results, top_k=2)

        assert len(result) == 2
        assert result[0].text == "First result"
        assert result[1].text == "Second result"

    @pytest.mark.asyncio
    async def test_rerank_embedding_count_mismatch_fallback(
        self, enabled_config: Config, sample_results: list[SearchResult]
    ) -> None:
        """When embedding count mismatches, reranker falls back to pass-through."""
        # Return only 2 vectors when 5 (1 query + 4 passages) are expected
        mock_embedder = _make_mock_embedder([[1.0, 0.0], [0.5, 0.5]])

        reranker = Reranker(enabled_config, embedder=mock_embedder)
        result = await reranker.rerank(query="test query", results=sample_results, top_k=2)

        assert len(result) == 2
        assert result[0].text == "First result"
        assert result[1].text == "Second result"

    @pytest.mark.asyncio
    async def test_rerank_empty_results(self, enabled_config: Config) -> None:
        """When enabled with empty results, reranker returns empty."""
        reranker = Reranker(enabled_config, embedder=_make_mock_embedder([]))
        result = await reranker.rerank(query="test query", results=[], top_k=5)
        assert result == []
