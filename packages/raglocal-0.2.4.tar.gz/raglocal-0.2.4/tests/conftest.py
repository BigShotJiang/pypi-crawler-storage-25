"""Shared pytest fixtures for raglocal test suite."""

from pathlib import Path

import pytest

from raglocal.config import (
    CollectionConfig,
    Config,
    EmbedderConfig,
    ModelSpec,
    RerankerConfig,
    RetrievalConfig,
    StoreConfig,
)


@pytest.fixture
def lance_path(tmp_path: Path) -> Path:
    """Return a tmp path for a LanceDB store."""
    return tmp_path / "lance"


@pytest.fixture
def mock_embedder():
    """A fake embedder that returns fixed-dim vectors without loading any model."""

    class FakeEmbedder:
        dim = 4

        async def embed(self, texts):
            return [[0.1, 0.2, 0.3, 0.4]] * len(texts)

        async def aclose(self):
            pass

    return FakeEmbedder()


@pytest.fixture
def base_config(tmp_path: Path) -> Config:
    """Minimal valid Config for tests."""
    return Config(
        state_dir=str(tmp_path / "state"),
        log_level="info",
        store=StoreConfig(backend="lance", path=str(tmp_path / "lance")),
        embedder=EmbedderConfig(
            profile="custom",
            provider="ollama",
            model="bge-m3",
            host="http://localhost:11434",
            dim=4,
            cache_dir=None,
        ),
        reranker=RerankerConfig(enabled=False, model=""),
        retrieval=RetrievalConfig(top_n=5, top_k=3, hybrid_alpha=0.5),
        models={"smart": ModelSpec(alias="smart", provider="anthropic", model="claude-sonnet-4-6")},
        default_model="smart",
        default_collections=["docs"],
        collections={
            "docs": CollectionConfig(
                name="docs", chunk_size=800, chunk_overlap=100, chunk_strategy="token"
            ),
            "code": CollectionConfig(
                name="code", chunk_size=500, chunk_overlap=50, chunk_strategy="code-aware"
            ),
        },
    )
