# OpenCode integration

raglocal ships an MCP (Model Context Protocol) server that lets OpenCode (and
other MCP-capable AI tools) reference your indexed knowledge with minimum
tokens per session.

## One-time setup

1. Install raglocal with local embeddings:
   ```bash
   pip install raglocal[local-embed]
   ```

2. Initialise and index your content:
   ```bash
   rag init
   rag index ~/code/ ~/journals/
   ```

3. Add raglocal to your OpenCode config (`~/.config/opencode/config.json`):
   ```jsonc
    {
      "mcp": {
        "raglocal": {
          "command": "rag",
          "args": ["serve-mcp"],
          "type": "stdio"
        }
      }
    }
   ```

4. Restart OpenCode. Ragkit's `search` and `expand` tools appear in your tool list.

## How OpenCode uses it

- `search(query, top_k=10)` returns ranked snippets (<=250 chars each) plus chunk IDs.
- `expand(ids=[...])` fetches full text of specific chunks on demand.

Token overhead: ~400 tokens for the schema + ~60 per snippet. Typical session ~1200 tokens vs ~4000 for classic RAG.

## Troubleshooting

See [troubleshooting.md](troubleshooting.md).