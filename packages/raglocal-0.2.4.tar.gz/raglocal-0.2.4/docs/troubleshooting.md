# Troubleshooting

## `rag: command not found`

```bash
pip install raglocal[local-embed]
which rag
```

If using `uv`: `uv run rag ...` or activate the venv.

## `No config found. Run 'rag init' to set up raglocal.`

```bash
rag init
```

## MCP server: "Cannot import sentence_transformers"

```bash
pip install raglocal[local-embed]
# or with uv:
uv pip install sentence-transformers torch
```

## `LanceDB store error: ...`

- Path in `~/.config/raglocal/config.toml` missing or not writable. Edit `[store] path` or run `rag init --force`.
- Schema changed after upgrade. Re-index: `rag index <paths...>`.

## Search returns nothing

- Check index: `rag stats`
- Try broader query.
- Switched profiles? Must re-index (vectors incompatible across models).

## `rag debug` returns 'docs' KeyError or empty hits

Symptom: `rag debug "<query>"` exits with `Debug failed: 'docs'` (or similar
collection name) even though `rag stats` shows chunks indexed.

Cause: a stale raglocal installation prior to v1.1.x. `_load_services` did not
re-attach to existing on-disk LanceDB tables.

Fix: upgrade to v1.1.1 or later. Pin in your install:
```bash
pip install --upgrade raglocal[local-embed]
```

Verification: `rag debug "test"` should return the same hits that `rag stats`
promised exist.

---

## MCP client says "invalid response" or "missing content"

Symptom: Claude Desktop or OpenCode logs `expected content array, got hits`
or similar.

Cause: raglocal < 1.1.1 returned non-standard MCP envelopes
(`{"hits": [...]}` instead of `{"content": [...]}`).

Fix: upgrade to v1.1.1 or later. The server now returns the standard MCP
2024-11-05 envelope: `{"content": [{"type": "text", "text": "<json>"}],
"isError": false}`. The MCP client unwraps and parses the JSON automatically.

---

## OpenCode can't see raglocal's tools

- Test: `rag mcp` should wait silently for JSON-RPC input.
- Config: `command = "rag"`, `args = ["mcp"]`, `type = "stdio"`.
- Restart OpenCode after config edit.

## `Ollama not reachable` (powerful profile only)

Start Ollama: `ollama serve`
Or switch: edit `[embedder] profile = "balanced"` in config.toml, then re-index.