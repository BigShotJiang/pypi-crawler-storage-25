"""Module for the RemoteSimOpsHandler class.

It is responsible for handling the operations on the remote nodes.
It can deploy, start, stop and undeploy services on the remote nodes.
"""

from __future__ import annotations

from typing import (
    TYPE_CHECKING,
    Any,
    cast,
)

from eclypse.remote import ray_backend
from eclypse.remote.utils import (
    RemoteOpResult,
    RemoteOps,
)

if TYPE_CHECKING:
    from eclypse.placement import Placement
    from eclypse.remote._node import RemoteNode
    from eclypse.remote.service import Service
    from eclypse.remote.utils import RemoteOpResult


class RemoteSimOpsHandler:
    """A RemoteSimOpsHandler performs the operations on the remote nodes.

    Available operations are: deploy, start, stop and undeploy.
    """

    @staticmethod
    def deploy(placement: Placement):
        """Deploy the services to the remote nodes, according to the placement mapping.

        Args:
            placement (Placement): The placement mapping of the services to the nodes.

        Raises:
            ValueError: If any of the responses from the remote nodes is an error.
        """
        deployments = cast(
            "list[RemoteOpResult]",
            ray_backend.get(
                cast(
                    "Any",
                    [
                        node.ops_entrypoint.remote(  # type: ignore[attr-defined]
                            RemoteOps.DEPLOY,
                            service_id=service.id,
                            service=service,
                        )
                        for node, service in RemoteSimOpsHandler._get_remotes(placement)
                    ],
                )
            ),
        )

        _handle_error(deployments)
        placement.mark_deployed()

    @staticmethod
    def start(placement: Placement):
        """Start the deployed services on the remote nodes.

        Args:
            placement (Placement): The placement mapping of the services to the nodes.

        Raises:
            ValueError: If any of the responses from the remote nodes is an error.
        """
        starts = cast(
            "list[RemoteOpResult]",
            ray_backend.get(
                cast(
                    "Any",
                    [
                        node.ops_entrypoint.remote(  # type: ignore[attr-defined]
                            RemoteOps.START,
                            service_id=service.id,
                        )
                        for node, service in RemoteSimOpsHandler._get_remotes(placement)
                    ],
                )
            ),
        )
        _handle_error(starts)

    @staticmethod
    def stop(placement: Placement):
        """Stop the running services on the remote nodes.

        Args:
            placement (Placement): The placement mapping of the services to the nodes.

        Raises:
            ValueError: If any of the responses from the remote nodes is an error.
        """
        stops = cast(
            "list[RemoteOpResult]",
            ray_backend.get(
                cast(
                    "Any",
                    [
                        node.ops_entrypoint.remote(  # type: ignore[attr-defined]
                            RemoteOps.STOP,
                            service_id=service.id,
                        )
                        for node, service in RemoteSimOpsHandler._get_remotes(placement)
                    ],
                )
            ),
        )

        _handle_error(stops)

    @staticmethod
    def undeploy(placement: Placement):
        """Undeploy the services from the remote nodes.

        Args:
            placement (Placement): The placement mapping of the services to the nodes.

        Raises:
            ValueError: If any of the responses from the remote nodes is an error.
        """
        undeploy_result = cast(
            "list[RemoteOpResult]",
            ray_backend.get(
                cast(
                    "Any",
                    [
                        node.ops_entrypoint.remote(  # type: ignore[attr-defined]
                            RemoteOps.UNDEPLOY,
                            service_id=service.id,
                        )
                        for node, service in RemoteSimOpsHandler._get_remotes(placement)
                    ],
                )
            ),
        )
        _handle_error(undeploy_result)

        for result in undeploy_result:
            if result.service is not None:
                placement.application.services[result.service.id] = result.service

        placement.mark_undeployed()

    @staticmethod
    def _get_remotes(placement: Placement) -> list[tuple[RemoteNode, Service]]:
        """Get the remote nodes (ray actors) and Services to perform the operation.

        Args:
            placement (Placement): The placement mapping of the services to the nodes.

        Returns:
            list[tuple[RemoteEngine, Service]]: A list of tuples containing \
                the remote nodes and the services to perform the operation.
        """
        node_serv = []
        actor_cache = {}
        for service_id in placement.application.services:
            node_name = placement.service_placement(service_id)
            actor_name = f"{placement.infrastructure.id}/{node_name}"
            if actor_name not in actor_cache:
                actor_cache[actor_name] = ray_backend.get_actor(actor_name)
            node = actor_cache[actor_name]
            service = placement.application.services[service_id]
            node_serv.append((node, service))
        return node_serv  # type: ignore[return-value]


def _handle_error(results: list[RemoteOpResult]):
    """Handle remote operation results and surface actionable error details.

    Args:
        results (list[RemoteOpResult]): The results returned by the remote nodes.

    Raises:
        ValueError: If any of the remote operations failed.
    """
    failures = [result for result in results if result.code.name == "ERROR"]
    if not failures:
        return

    details = [
        (
            f"{result.operation.name} failed on node '{result.node_id}' "
            f"for service '{result.service_id}'"
            + (f": {result.error}" if result.error else "")
        )
        for result in failures
    ]
    raise ValueError("Remote operation errors:\n- " + "\n- ".join(details))
