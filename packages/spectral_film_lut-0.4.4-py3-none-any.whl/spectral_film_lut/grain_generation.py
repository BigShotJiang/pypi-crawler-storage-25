"""
Functions to simulate film grain and to export film grain overlays.
"""

import math
import os
import sys
from functools import cache

import cv2 as cv
import imageio
import imageio.v3 as iio
import numpy as np
from PyQt6.QtCore import QRegularExpression, Qt
from PyQt6.QtGui import QIntValidator, QRegularExpressionValidator
from PyQt6.QtWidgets import (
    QApplication,
    QCheckBox,
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QProgressDialog,
    QVBoxLayout,
)

from spectral_film_lut.config import DEFAULT_DTYPE
from spectral_film_lut.css_theme import (
    BASE_COLOR,
    BUTTON_RADIUS,
    HOVER_COLOR,
    OUTLINE_COLOR,
    PRESSED_COLOR,
    SCROLLBAR_HOVER_COLOR,
    TEXT_PRIMARY,
)
from spectral_film_lut.file_formats import FILE_FORMATS
from spectral_film_lut.gui_objects import (
    AnimatedButton,
    HoverLineEdit,
    SliderLog,
    WideComboBox,
)


@cache
def gaussian_noise_cache(shape):
    """Computes and pre caches gaussian noise."""
    return np.random.default_rng().standard_normal(shape, dtype=DEFAULT_DTYPE)


def gaussian_noise(shape, cached=False):
    """
    Computes gaussian noise.
    If cached noise is used a random crop is used to not get identical noise every time.
    """
    if not cached:
        return np.random.default_rng().standard_normal(shape, dtype=DEFAULT_DTYPE)
    noise_size = ((max(shape[:2]) + 100) // 1024 + 1) * 1024
    noise_map = gaussian_noise_cache((noise_size, noise_size))
    offsets = np.random.randint(
        [0, 0],
        [noise_size - shape[0] + 1, noise_size - shape[1] + 1],
        size=(shape[2], 2),
    )
    noise = np.stack(
        [noise_map[x : shape[0] + x, y : shape[1] + y] for x, y in offsets], axis=-1
    )
    return noise


def two_component_params(
    grain_size_mm: float, sigma: float, p=2
) -> tuple[float, float, float, float]:
    r"""
    Return :math:`d_1`, :math:`d_2`, :math:`w_1`, :math:`w_2` for a 2-component
    approximation of :math:`LogNormal(\mu, \sigma^2)`.
    - :math:`d_1 = \exp(\mu - \sigma)`
    - :math:`d_2 = \exp(\mu + \sigma)`
    - Split point :math:`=` geometric mean :math:`= \exp(\mu)`
    - Weights :math:`w_1, w_2` derived for weighting :math:`~ d^p \cdot \text{pdf}(d)`
      (:math:`p=0 \rightarrow` number weighting, :math:`p=2 \rightarrow` area weighting,
      :math:`p=3 \rightarrow` volume/scattering)

    All returned as floats: :math:`(d_1, d_2, w_1, w_2)`.
    """
    mu = np.log(grain_size_mm) - 0.5 * sigma**2

    d1 = math.exp(mu - sigma)
    d2 = math.exp(mu + sigma)

    # Normal CDF using erf
    def std_norm_cdf(x):
        return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))

    # Using closed-form: W1 = Phi( (ln(split) - (mu + p*sigma^2)) / sigma )
    # with ln(split)=mu -> argument = -p*sigma
    w1 = std_norm_cdf(-p * sigma)
    w2 = 1.0 - w1

    return d1, d2, w1, w2


def grain_kernel(
    pixel_size_mm: float, grain_size_mm=0.006, grain_sigma=0.3
) -> np.ndarray:
    r"""
    Computes a convolution kernel for film grain.
    Based on the paper *Simulating Film Grain using the Noise-Power Spectrum* by Ian
    Stephenson and Arthur Saunders.

    Args:
        pixel_size_mm: The side length of the pixels in mm.
        grain_size_mm: The grain diameter in mm.
        grain_sigma: The grain size distribution standard variance
    """
    dye_size1_mm, dye_size2_mm, w1, w2 = two_component_params(
        grain_size_mm, grain_sigma
    )

    kernel_size_mm = 4.24 * max(dye_size1_mm, dye_size2_mm)
    kernel_size = round(kernel_size_mm / pixel_size_mm)
    if kernel_size % 2 == 0:
        kernel_size += 1
    if kernel_size < 3:
        return None

    # Frequency grid (cycles per mm)
    fx = np.fft.fftfreq(kernel_size, d=pixel_size_mm)
    fy = np.fft.fftfreq(kernel_size, d=pixel_size_mm)
    FX, FY = np.meshgrid(fx, fy)
    f = np.sqrt(FX**2 + FY**2)  # radial frequency

    # Gaussian model for dye NPS: exp(-(pi*f*D)^2)
    nps1 = np.exp(-((np.pi * f * dye_size1_mm) ** 2)) * w1
    nps2 = np.exp(-((np.pi * f * dye_size2_mm) ** 2)) * w2

    # Total NPS (weighted sum)
    nps = nps1 + nps2
    # generate convolution kernel
    # Get spatial kernel by inverse FFT
    kernel = np.fft.ifft2(np.sqrt(nps))
    kernel = np.fft.fftshift(kernel.real)  # center it

    # normalize kernel
    kernel /= np.sqrt(np.sum(kernel))

    return kernel


def generate_grain(
    shape,
    scale: float,
    grain_size_mm=0.006,
    bw_grain=False,
    cached=False,
    grain_sigma=0.3,
    **kwargs,
) -> np.ndarray:
    """
    Computes random grain somewhat efficiently with the grain smoothing inspired by
    the paper *Simulating Film Grain using the Noise-Power Spectrum* by Ian Stephenson
    and Arthur Saunders.

    Args:
        shape: The shape of the output ndarry.
        scale: The pixel scale in pixels per mm.
        grain_size_mm: The diameter of the individual grains in mm.
        bw_grain: Is the grain monochromatic or per channel?
        cached: Should cached noise be used for grain generation?
        grain_sigma: The grain size distribution standard variance.
        **kwargs:

    Returns:
        An ndarray that is essentially a grain overlay.
    """
    # compute scaling factor of exposure rms in regard to measuring device size
    if bw_grain:
        shape = (shape[0], shape[1], 1)
    noise = gaussian_noise(shape, cached=cached)
    kernel = grain_kernel(
        1 / scale, grain_size_mm=grain_size_mm, grain_sigma=grain_sigma
    )
    if kernel is not None:
        noise = cv.filter2D(noise, -1, kernel)
    if len(noise.shape) == 2:
        noise = noise[..., np.newaxis]
    if bw_grain:
        noise /= 1.5
    return noise


def generate_grain_frame(
    width, height, channels, scale, grain_size_mm=0.06, std_div=0.001, grain_sigma=0.3
) -> np.ndarray:
    """Generates a single frame of grain scaled to 8 bit int values."""
    noise = (
        generate_grain(
            (height, width, channels),
            scale,
            grain_size_mm=grain_size_mm,
            grain_sigma=grain_sigma,
        )
        * scale
    )
    noise = (np.clip(noise * std_div + 0.5, 0, 1) * 255).astype(np.uint8)
    noise = noise
    return noise


def output_file(noise: np.ndarray, file_format: str, filename: str, ext: str):
    """
    Writes the noise array to an image or video file. Formats specified in
    `.file_formats`.
    """
    kwargs = FILE_FORMATS[file_format]["kwargs"]
    # Write output
    if file_format.endswith("Sequence"):
        os.makedirs(filename, exist_ok=True)
        for i, frame in enumerate(noise):
            frame_filename = os.path.join(
                filename, f"{os.path.basename(filename).split('.')[0]}_{i:04d}{ext}"
            )
            iio.imwrite(frame_filename, frame, **kwargs)
    else:
        iio.imwrite(filename, noise, fps=24, **kwargs)


class ExportGrainDialog(QDialog):
    """Dialog for exporting random grain overlays as images or video."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Export Noise")
        self.setStyleSheet(f"""
        QWidget {{
            border-radius: {BUTTON_RADIUS}px;
            background-color: {BASE_COLOR};
        }}

        HoverLineEdit {{
            background-color: {SCROLLBAR_HOVER_COLOR};
        }}

        AnimatedButton, QComboBox, QToolButton {{
            padding: 3px;
        }}

        AnimatedButton::hover, QComboBox::hover, HoverLineEdit::hover {{
            background-color: {HOVER_COLOR};
        }}
        """)

        # --- UI Elements ---
        layout = QVBoxLayout()

        # Width
        layout.addWidget(QLabel("Width:"))
        self.width_field = HoverLineEdit("1920")
        self.width_field.setValidator(QIntValidator())
        layout.addWidget(self.width_field)

        # Height
        layout.addWidget(QLabel("Height:"))
        self.height_field = HoverLineEdit("1080")
        self.height_field.setValidator(QIntValidator())
        layout.addWidget(self.height_field)

        # Frames
        layout.addWidget(QLabel("Frame count:"))
        self.frame_field = HoverLineEdit("100")
        self.frame_field.setValidator(QIntValidator())
        layout.addWidget(self.frame_field)

        # Channels
        self.color_box = QCheckBox("Full color")
        self.color_box.setChecked(True)
        layout.addWidget(self.color_box)

        # Format selector
        layout.addWidget(QLabel("File format:"))
        self.format_selector = WideComboBox()
        self.format_selector.addItems(list(FILE_FORMATS.keys()))
        self.format_selector.setCurrentText("TIFF Sequence")
        layout.addWidget(self.format_selector)

        regex = QRegularExpression(r"[0-9]*|[0-9]+\.[0-9]*")
        double_validator = QRegularExpressionValidator(regex)
        layout.addWidget(QLabel("Frame rate:"))
        self.frame_rate = WideComboBox()
        self.frame_rate.setEditable(True)
        self.frame_rate.addItems(
            ["23.976", "24", "25", "29.97", "30", "50", "59.94", "60"]
        )
        self.frame_rate.setValidator(double_validator)
        self.frame_rate.setCurrentText("24")
        layout.addWidget(self.frame_rate)

        layout.addWidget(QLabel("Frame width (mm):"))
        self.frame_width_field = WideComboBox()
        self.frame_width_field.setEditable(True)
        self.frame_width_field.addItems(
            ["5.79", "6.30", "12.42", "24.90", "36", "52.15", "70.41"]
        )
        self.frame_width_field.setValidator(double_validator)
        self.frame_width_field.setCurrentText("36")
        layout.addWidget(self.frame_width_field)

        layout.addWidget(QLabel("Grain size (microns):"))
        self.grain_size_field = SliderLog()
        self.grain_size_field.setMinMaxSteps(3, 12, 30, 6)
        layout.addWidget(self.grain_size_field)

        # Buttons
        button_layout = QHBoxLayout()
        ok_button = AnimatedButton("Export")
        cancel_button = AnimatedButton("Cancel")
        button_layout.addWidget(ok_button)
        button_layout.addWidget(cancel_button)
        layout.addLayout(button_layout)

        self.setLayout(layout)

        self.cancelled = False

        # --- Connections ---
        ok_button.clicked.connect(self.export_noise)
        cancel_button.clicked.connect(self.reject)

    def get_values(self):
        width = int(self.width_field.text() or 1920)
        height = int(self.height_field.text() or 1080)
        frames = int(self.frame_field.text() or 1)
        channels = 3 if self.color_box.isChecked() else 1
        file_format = self.format_selector.currentText()
        frame_rate = float(self.frame_rate.currentText())
        scale = width / float(self.frame_width_field.currentText())
        grain_size = float(self.grain_size_field.getValue()) / 1000
        return (
            width,
            height,
            frames,
            channels,
            file_format,
            frame_rate,
            scale,
            grain_size,
        )

    def export_noise(self):
        width, height, frames, channels, file_format, frame_rate, scale, grain_size = (
            self.get_values()
        )
        ext = FILE_FORMATS[file_format]["extension"]

        filename, ok = QFileDialog.getSaveFileName(
            self, "Choose output file", "", "*" + ext
        )
        if not ok or not filename:
            return

        if not filename.endswith(ext):
            filename += ext

        # --- Setup QProgressDialog ---
        self.progress_dialog = QProgressDialog(
            "Preparing export...", "Cancel", 0, frames + 1, self
        )
        self.progress_dialog.setWindowTitle("Export grain overlay")
        self.progress_dialog.setWindowModality(Qt.WindowModality.ApplicationModal)
        self.progress_dialog.setMinimumDuration(0)
        self.progress_dialog.setValue(0)
        self.progress_dialog.setStyleSheet(f"""
QProgressDialog {{
    background-color: {BASE_COLOR}; color: {TEXT_PRIMARY};
}}
QProgressBar {{
    border-radius: {BUTTON_RADIUS}px;
    text-align: center;
    background-color: {PRESSED_COLOR};
    height: 16px;  /* thicker bar */
    color: {TEXT_PRIMARY};
}}
QProgressBar::chunk {{
    background-color: {OUTLINE_COLOR};
    border-radius: {BUTTON_RADIUS}px;
}}
""")
        # self.progress_dialog.canceled.connect(self.cancel_export)
        QApplication.processEvents()

        self.cancelled = False
        self.progress_dialog.canceled.connect(self.cancel)

        kwargs = FILE_FORMATS[file_format]["kwargs"]
        if file_format.endswith("Sequence"):
            os.makedirs(filename, exist_ok=True)
            for i in range(frames):
                if self.cancelled:
                    break
                frame = generate_grain_frame(width, height, channels, scale, grain_size)
                frame_filename = os.path.join(
                    filename, f"{os.path.basename(filename).split('.')[0]}_{i:04d}{ext}"
                )
                iio.imwrite(frame_filename, frame, **kwargs)
                self.progress_dialog.setLabelText(f"Exported {i + 1}/{frames} frames")
                self.progress_dialog.setValue(i + 1)
        else:
            with imageio.get_writer(filename, fps=frame_rate, **kwargs) as writer:
                for i in range(frames):
                    if self.cancelled:
                        break
                    frame = generate_grain_frame(
                        width, height, channels, scale, grain_size
                    )
                    writer.append_data(frame)
                    self.progress_dialog.setLabelText(
                        f"Exported {i + 1}/{frames} frames"
                    )
                    self.progress_dialog.setValue(i + 1)
                self.progress_dialog.setLabelText("Finishing up video file")
                QApplication.processEvents()

        self.progress_dialog.setValue(frames + 1)
        self.accept()
        QApplication.processEvents()

    def cancel(self):
        self.cancelled = True


if __name__ == "__main__":
    app = QApplication(sys.argv)
    dlg = ExportGrainDialog()
    dlg.show()
    sys.exit(app.exec())
