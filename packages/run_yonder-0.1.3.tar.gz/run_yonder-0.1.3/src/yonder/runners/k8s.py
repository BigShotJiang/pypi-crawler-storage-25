from __future__ import annotations

import base64
import logging
import uuid
from threading import RLock
from typing import Iterable, List, Mapping, Optional, Union

from .base import Runner
from .._shipping import (
    DEFAULT_SOURCE_INCLUDE,
    REMOTE_ROOT,
    auto_resolve_or_none,
    normalize_source_paths,
    remote_path_for,
    tar_directory,
)

_log = logging.getLogger("yonder.runners.k8s")


def _bootstrap_with_payload(
    payload: bytes,
    mode: str = "cloudpickle",
    sys_path_prepend: Optional[List[str]] = None,
) -> str:
    """Build a self-contained ``python -c`` script with the payload inlined.

    Kubernetes pod exec streams data over a WebSocket with channel framing,
    and the kubernetes Python client returns stdout/stderr as text by default.
    To survive any text-mode coercion and channel quirks, the envelope is
    base64-encoded on the pod side before it hits stdout; the runner
    base64-decodes it back.

    ``mode`` selects which bootstrap to emit:

    - ``"cloudpickle"`` — the payload is a cloudpickled ``{"func", "args",
      "kwargs"}`` dict; the pod unpickles it (requires cloudpickle in the
      container) and calls the function.
    - ``"reference"`` — the payload is a stdlib-pickled ``{"module",
      "qualname", "args", "kwargs"}`` dict; the pod imports the module
      under its own Python, resolves the function by qualname, and calls
      it. No cloudpickle required; bytecode never crosses the wire. A
      small ``yonder`` shim module is installed if yonder isn't on the
      pod's path so user modules using ``@yonder.to(...)`` still import.

    ``sys_path_prepend`` is a list of absolute in-pod paths to insert at
    the front of ``sys.path`` before any user code runs. Used when the
    runner has shipped a host source tree into the pod (see
    :mod:`yonder._shipping`).
    """
    encoded = base64.b64encode(payload).decode("ascii")
    sys_path_lines = ""
    if sys_path_prepend:
        for p in reversed(sys_path_prepend):
            sys_path_lines += f"sys.path.insert(0, {p!r})\n"
    if mode == "reference":
        shim_and_dispatch = (
            "_install_shim = False\n"
            "try:\n"
            "    import yonder as _y\n"
            "    if not callable(getattr(_y, 'to', None)):\n"
            "        _install_shim = True\n"
            "except ImportError:\n"
            "    _install_shim = True\n"
            "if _install_shim:\n"
            "    _shim = types.ModuleType('yonder')\n"
            "    def _noop(*a, **kw):\n"
            "        def _d(f):\n"
            "            return f\n"
            "        return _d\n"
            "    _shim.to = _noop\n"
            "    sys.modules['yonder'] = _shim\n"
            f"_p = pickle.loads(base64.b64decode({encoded!r}))\n"
            "_mod = importlib.import_module(_p['module'])\n"
            "_obj = _mod\n"
            "for _part in _p['qualname'].split('.'):\n"
            "    _obj = getattr(_obj, _part)\n"
            "_inner = getattr(_obj, '__yonder_inner__', _obj)\n"
            "try:\n"
            "    _v = _inner(*_p['args'], **_p['kwargs'])\n"
            "    _e = {'status': 'ok', 'value': _v}\n"
            "except BaseException as _exc:\n"
            "    _e = {'status': 'err', 'exception': _exc}\n"
            "sys.stdout.write(base64.b64encode(pickle.dumps(_e)).decode('ascii'))\n"
        )
        return (
            "import base64, importlib, pickle, sys, types\n"
            + sys_path_lines
            + shim_and_dispatch
        )
    return (
        "import base64, sys\n"
        + sys_path_lines
        + "import cloudpickle\n"
        + f"_p = cloudpickle.loads(base64.b64decode({encoded!r}))\n"
        + "try:\n"
        + "    _v = _p['func'](*_p['args'], **_p['kwargs'])\n"
        + "    _e = {'status': 'ok', 'value': _v}\n"
        + "except BaseException as _exc:\n"
        + "    _e = {'status': 'err', 'exception': _exc}\n"
        + "sys.stdout.write(base64.b64encode(cloudpickle.dumps(_e)).decode('ascii'))\n"
    )


class K8sRunner(Runner):
    """A Runner that execs Python inside a Kubernetes pod.

    Specify the target pod one of three ways (exactly one is required):

    - ``image="repo/name:tag"`` — create a new pod from the image. Yonder
      owns this pod: ``start()`` creates it (``command: ["sleep",
      "infinity"]`` so it stays around for exec calls), and ``close()``
      deletes it. The container inside is always named ``"yonder"``.
    - ``pod="pod-name"`` — attach to a specific existing pod by name.
      Yonder never creates or removes it; ``close()`` is a no-op.
    - ``selector="key=value,key2=value2"`` — attach via Kubernetes label
      selector. The first Running pod that matches is used. Resolution
      is lazy (first call or eager via :meth:`start`). Like ``pod=``,
      yonder doesn't manage the pod's lifecycle.

    Options that apply to all modes:

    - ``namespace`` — pod namespace (default ``"default"``).
    - ``container`` — container within the pod (default for attach modes:
      the pod's first container; for ``image=`` mode: always ``"yonder"``).
    - ``kubeconfig`` — path to a kubeconfig file. If omitted, standard
      ``KUBECONFIG`` / ``~/.kube/config`` discovery is used; failing that,
      the in-cluster service-account config is loaded.
    - ``context`` — kubeconfig context name.
    - ``name`` — runner name (auto-derived from pod/selector/image if omitted).
    - ``api_client`` — pre-built ``kubernetes.client.ApiClient``. When
      provided, ``kubeconfig`` and ``context`` are ignored.

    Options that apply only to ``image=`` mode:

    - ``env`` — dict of environment variables to set on the container.
    - ``image_pull_secrets`` — list of existing Secret names to use as
      ``imagePullSecrets`` (for private registries).
    - ``startup_timeout`` — seconds to wait for the pod to reach Running
      before failing. Default 60. ``ImagePullBackOff`` /
      ``ErrImagePull`` / ``CreateContainerConfigError`` raise
      immediately instead of waiting out the timeout.

    For anything beyond this surface (resources, service account,
    tolerations, affinity, custom volumes, sidecars, …) deploy the pod
    out-of-band with the tooling of your choice and attach via ``pod=``
    or ``selector=``.

    Requires the ``kubernetes`` package: ``pip install 'yonder[k8s]'``.
    The target container must have ``python`` on ``PATH``. In the default
    ``mode="cloudpickle"`` it must also have ``cloudpickle`` installed and
    a Python minor version matching the host; ``mode="reference"`` drops
    both requirements but needs the function's module to be importable
    inside the pod. Pass ``source_path=`` to ship a host source tree into
    the pod automatically — yonder tars the tree, exec-streams it to
    ``/tmp/yonder-src/<digest>/``, and prepends that path to
    ``sys.path`` in the bootstrap. The upload is cached per content
    digest so an unchanged tree is shipped at most once per process.
    """

    def __init__(
        self,
        pod: Optional[str] = None,
        selector: Optional[str] = None,
        image: Optional[str] = None,
        namespace: str = "default",
        container: Optional[str] = None,
        kubeconfig: Optional[str] = None,
        context: Optional[str] = None,
        name: Optional[str] = None,
        mode: str = "cloudpickle",
        inject_cloudpickle: bool = False,
        source_path: Optional[Union[str, Iterable[str]]] = None,
        source_include: Optional[Iterable[str]] = DEFAULT_SOURCE_INCLUDE,
        env: Optional[Mapping[str, str]] = None,
        image_pull_secrets: Optional[Iterable[str]] = None,
        startup_timeout: float = 60.0,
        api_client=None,
    ):
        try:
            import kubernetes  # noqa: F401
        except ImportError as exc:
            raise ImportError(
                "K8sRunner requires the kubernetes client. "
                "Install with: pip install 'yonder[k8s]'"
            ) from exc

        if sum(s is not None for s in (pod, selector, image)) != 1:
            raise TypeError(
                "K8sRunner requires exactly one of `pod=`, `selector=`, "
                "or `image=`"
            )

        if mode not in ("cloudpickle", "reference"):
            raise ValueError(
                f"mode must be 'cloudpickle' or 'reference', got {mode!r}"
            )

        if inject_cloudpickle:
            raise TypeError(
                "`inject_cloudpickle=True` is not supported on K8sRunner. "
                "K8sRunner attaches to a pod you manage and never mutates "
                "it — injection only works on images yonder builds itself "
                "(DockerRunner with `image=`). Either bake cloudpickle "
                "into the pod's image (`RUN pip install cloudpickle`), "
                "install it ahead of time "
                "(`kubectl exec <pod> -- pip install cloudpickle`), or "
                "switch to `mode='reference'` to avoid the dependency."
            )

        if image is None and (env or image_pull_secrets):
            raise TypeError(
                "`env=` and `image_pull_secrets=` only apply to `image=` "
                "mode (yonder is creating the pod). When attaching to an "
                "existing pod via `pod=` or `selector=`, set them in the "
                "pod spec yourself."
            )

        # Reference mode almost always needs the caller's source tree
        # shipped into the pod — default to the caller's __file__
        # directory when the user didn't specify. Pass `source_path=[]`
        # to opt out (e.g. when the pod's image already has the module).
        # REPL/Jupyter contexts silently fall through to no default.
        if mode == "reference" and source_path is None:
            source_path = auto_resolve_or_none()

        self.pod = pod
        self.selector = selector
        self.image = image
        self.namespace = namespace
        self.container = container
        self.kubeconfig = kubeconfig
        self.context = context
        self.mode = mode
        self.env = dict(env or {})
        self.image_pull_secrets = list(image_pull_secrets or [])
        self.startup_timeout = float(startup_timeout)
        self._owned = image is not None
        self._pod_created = False
        self._api_client = api_client
        self._core_v1 = None
        self._lock = RLock()
        self._resolved_pod: Optional[str] = pod
        self._resolved_container: Optional[str] = container
        self._ship_paths: List[str] = normalize_source_paths(source_path)
        self._shipped_sources: dict = {}
        self.source_include: Optional[tuple] = (
            None if source_include is None else tuple(source_include)
        )

        if name is not None:
            self.name = name
        elif pod is not None:
            self.name = pod
        else:
            self.name = f"yonder-k8s-{uuid.uuid4().hex[:8]}"

        # For image= mode, the pod we create has this exact name and a
        # single container named "yonder" — pre-populate the resolved
        # targets so exec works without a separate pod-read round-trip.
        if self._owned:
            self._resolved_pod = self.name
            if self._resolved_container is None:
                self._resolved_container = "yonder"

    @property
    def core_v1(self):
        if self._core_v1 is None:
            from kubernetes import client, config

            if self._api_client is None:
                try:
                    config.load_kube_config(
                        config_file=self.kubeconfig, context=self.context
                    )
                except Exception:
                    config.load_incluster_config()
                self._api_client = client.ApiClient()
            self._core_v1 = client.CoreV1Api(self._api_client)
        return self._core_v1

    def start(self) -> None:
        """Bring the runner online.

        In ``image=`` mode, creates the pod (if not already created) and
        waits for it to reach ``Running``. In attach modes, resolves the
        pod name / container eagerly. Safe to call more than once.
        """
        with self._lock:
            self._ensure_pod_created()
            self._ensure_target_resolved()

    def run(self, payload: bytes) -> bytes:
        with self._lock:
            self._ensure_pod_created()
            self._ensure_target_resolved()
            pod = self._resolved_pod
            ctr = self._resolved_container

        from kubernetes.client.rest import ApiException
        from kubernetes.stream import stream

        sys_path_prepend = self._ensure_sources_shipped(pod, ctr)
        bootstrap = _bootstrap_with_payload(payload, self.mode, sys_path_prepend)
        _log.debug(
            "exec in pod %s/%s container=%s (%d bytes)",
            self.namespace, pod, ctr, len(payload),
        )
        kwargs = dict(
            name=pod,
            namespace=self.namespace,
            command=["python", "-c", bootstrap],
            stderr=True,
            stdin=False,
            stdout=True,
            tty=False,
            _preload_content=False,
        )
        if ctr is not None:
            kwargs["container"] = ctr

        try:
            ws = stream(self.core_v1.connect_get_namespaced_pod_exec, **kwargs)
        except ApiException as exc:
            raise RuntimeError(
                f"K8sRunner: pod exec failed for {self.namespace}/{pod}: {exc}"
            ) from exc

        stdout_chunks = []
        stderr_chunks = []
        try:
            while ws.is_open():
                ws.update(timeout=1)
                if ws.peek_stdout():
                    stdout_chunks.append(ws.read_stdout())
                if ws.peek_stderr():
                    stderr_chunks.append(ws.read_stderr())
            # Drain anything buffered after the channel closed.
            if ws.peek_stdout():
                stdout_chunks.append(ws.read_stdout())
            if ws.peek_stderr():
                stderr_chunks.append(ws.read_stderr())
        finally:
            ws.close()

        stdout = "".join(stdout_chunks).strip()
        stderr = "".join(stderr_chunks)

        if not stdout:
            msg = stderr.strip() or "<no stderr>"
            raise RuntimeError(
                f"yonder runner returned no stdout from pod "
                f"{self.namespace}/{pod}. stderr:\n{msg}"
            )
        try:
            return base64.b64decode(stdout)
        except Exception as exc:
            raise RuntimeError(
                f"K8sRunner: failed to decode envelope from pod "
                f"{self.namespace}/{pod}: {exc}\n"
                f"raw stdout (truncated): {stdout[:200]!r}\n"
                f"stderr: {stderr.strip() or '<no stderr>'}"
            ) from exc

    def close(self) -> None:
        with self._lock:
            if not self._owned or not self._pod_created:
                _log.info(
                    "detaching from pod %s/%s",
                    self.namespace,
                    self._resolved_pod or self.pod or self.selector,
                )
                return
            from kubernetes.client.rest import ApiException

            pod_name = self._resolved_pod
            _log.info("deleting pod %s/%s", self.namespace, pod_name)
            try:
                self.core_v1.delete_namespaced_pod(
                    name=pod_name,
                    namespace=self.namespace,
                    grace_period_seconds=0,
                )
            except ApiException as exc:
                # 404 = already gone; anything else is best-effort.
                if getattr(exc, "status", None) != 404:
                    _log.warning(
                        "failed to delete pod %s/%s: %s",
                        self.namespace, pod_name, exc,
                    )
            self._pod_created = False

    def _ensure_pod_created(self) -> None:
        """In ``image=`` mode, create the pod and wait for Running.

        No-op for attach modes (``pod=`` / ``selector=``) and after the
        first successful creation in ``image=`` mode.
        """
        if not self._owned or self._pod_created:
            return
        from kubernetes import client
        from kubernetes.client.rest import ApiException

        env_vars = [
            client.V1EnvVar(name=k, value=v) for k, v in self.env.items()
        ]
        container = client.V1Container(
            name="yonder",
            image=self.image,
            command=["sleep", "infinity"],
            env=env_vars or None,
        )
        spec = client.V1PodSpec(
            containers=[container],
            restart_policy="Never",
            image_pull_secrets=[
                client.V1LocalObjectReference(name=n)
                for n in self.image_pull_secrets
            ] or None,
        )
        pod = client.V1Pod(
            metadata=client.V1ObjectMeta(
                name=self.name,
                namespace=self.namespace,
                labels={"app.kubernetes.io/managed-by": "yonder"},
            ),
            spec=spec,
        )

        _log.info(
            "creating pod %s/%s (image=%s)",
            self.namespace, self.name, self.image,
        )
        try:
            self.core_v1.create_namespaced_pod(
                namespace=self.namespace, body=pod
            )
        except ApiException as exc:
            raise RuntimeError(
                f"K8sRunner: failed to create pod "
                f"{self.namespace}/{self.name}: {exc}"
            ) from exc
        # Flag set before the wait so close() on a creation-then-timeout
        # path still tries to delete the (likely-stuck) pod.
        self._pod_created = True
        self._wait_for_pod_running()

    def _wait_for_pod_running(self) -> None:
        """Watch the pod until status.phase == 'Running'.

        Uses the Kubernetes watch API rather than per-second polling —
        one long-lived stream connection instead of N HTTPS requests
        (which is both more efficient and avoids spamming
        ``InsecureRequestWarning`` on clusters with self-signed certs).

        Fails fast — and with rich detail — when the pod can't reach
        Running: ``ImagePullBackOff`` and friends raise as soon as the
        condition appears, and a terminal phase (``Failed`` /
        ``Succeeded``) includes container exit codes, container reasons,
        and the last few lines of container logs in the error.
        """
        from kubernetes import watch
        from kubernetes.client.rest import ApiException

        fail_reasons = {
            "ImagePullBackOff",
            "ErrImagePull",
            "InvalidImageName",
            "CreateContainerConfigError",
            "CreateContainerError",
        }

        w = watch.Watch()
        last_pod = None
        try:
            try:
                stream = w.stream(
                    self.core_v1.list_namespaced_pod,
                    namespace=self.namespace,
                    field_selector=f"metadata.name={self.name}",
                    timeout_seconds=int(self.startup_timeout),
                )
            except ApiException as exc:
                raise RuntimeError(
                    f"K8sRunner: failed to watch pod "
                    f"{self.namespace}/{self.name}: {exc}"
                ) from exc
            for event in stream:
                pod = event.get("object")
                if pod is None:
                    continue
                last_pod = pod
                phase = pod.status.phase if pod.status else None
                if phase == "Running":
                    return
                # Surface container-state failures before pod phase goes
                # terminal — for image-pull problems the user wants the
                # specific reason, not just "pod failed".
                for cs in (
                    (pod.status.container_statuses or [])
                    if pod.status else []
                ):
                    waiting = cs.state.waiting if cs.state else None
                    reason = waiting.reason if waiting else None
                    if reason in fail_reasons:
                        msg = waiting.message or "<no message>"
                        raise RuntimeError(
                            f"K8sRunner: pod {self.namespace}/{self.name} "
                            f"container {cs.name!r} is stuck in {reason!r}: "
                            f"{msg}"
                        )
                if phase in ("Failed", "Succeeded"):
                    raise RuntimeError(self._format_terminal_pod_error(pod))
        finally:
            w.stop()

        # Watch stream ended without seeing Running — that's the
        # server-side timeout firing.
        last_phase = (
            last_pod.status.phase if last_pod and last_pod.status else None
        )
        raise RuntimeError(
            f"K8sRunner: pod {self.namespace}/{self.name} did not reach "
            f"Running within {self.startup_timeout}s "
            f"(last phase: {last_phase!r})"
        )

    def _format_terminal_pod_error(self, pod) -> str:
        """Build a rich error string for a pod that reached a terminal phase.

        Includes the pod-level reason/message, each container's state
        (waiting / terminated, with exit code and reason), and — if the
        container actually ran — the tail of its logs. Best-effort: any
        single piece that can't be fetched is silently omitted.
        """
        from kubernetes.client.rest import ApiException

        phase = pod.status.phase if pod.status else None
        lines = [
            f"K8sRunner: pod {self.namespace}/{self.name} reached "
            f"terminal phase {phase!r} before Running"
        ]
        if pod.status:
            if pod.status.reason:
                lines.append(f"  pod reason: {pod.status.reason}")
            if pod.status.message:
                lines.append(f"  pod message: {pod.status.message}")
        for cs in (pod.status.container_statuses or []) if pod.status else []:
            state = cs.state
            if state and state.terminated:
                t = state.terminated
                lines.append(
                    f"  container {cs.name!r} terminated: "
                    f"exit={t.exit_code} reason={t.reason!r} "
                    f"message={t.message!r}"
                )
            elif state and state.waiting:
                wait = state.waiting
                lines.append(
                    f"  container {cs.name!r} waiting: "
                    f"reason={wait.reason!r} message={wait.message!r}"
                )
        # Container logs are often the most useful thing. Tolerate any
        # error — the container may have never run far enough to produce
        # output, or logs may be unavailable for other reasons.
        try:
            logs = self.core_v1.read_namespaced_pod_log(
                name=self.name,
                namespace=self.namespace,
                container="yonder",
                tail_lines=20,
            )
            if logs and logs.strip():
                lines.append("  recent container logs:")
                for ln in logs.rstrip().splitlines():
                    lines.append(f"    {ln}")
        except ApiException:
            pass
        return "\n".join(lines)

    def _ensure_sources_shipped(self, pod: str, ctr: Optional[str]) -> List[str]:
        """Tar each entry in ``self._ship_paths``, stream into the pod via
        exec stdin if not already in the per-runner cache, and return the
        list of in-pod PYTHONPATH entries to prepend in the bootstrap.

        Uses ``sh -c "mkdir -p <dir> && tar xf - -C <dir>"`` as the exec
        command and pipes the tar bytes to stdin. Requires the target
        container to have ``sh`` and ``tar`` on PATH (true for nearly
        every base image, but a hard requirement). Cached per content
        digest so an unchanged tree is shipped at most once per runner.
        """
        if not self._ship_paths:
            return []
        from kubernetes.client.rest import ApiException
        from kubernetes.stream import stream

        pythonpath_entries: List[str] = []
        for abs_host in self._ship_paths:
            tar_bytes, digest, basename = tar_directory(
                abs_host, include=self.source_include
            )
            extract_dir, pp_entry = remote_path_for(digest, basename)
            pythonpath_entries.append(pp_entry)
            if digest in self._shipped_sources:
                continue
            _log.info(
                "shipping source tree %s (%d bytes, digest=%s) to pod %s/%s:%s",
                abs_host, len(tar_bytes), digest,
                self.namespace, pod, extract_dir,
            )
            kwargs = dict(
                name=pod,
                namespace=self.namespace,
                command=["sh", "-c", f"mkdir -p {extract_dir} && tar xf - -C {extract_dir}"],
                stderr=True,
                stdin=True,
                stdout=True,
                tty=False,
                _preload_content=False,
            )
            if ctr is not None:
                kwargs["container"] = ctr
            try:
                ws = stream(
                    self.core_v1.connect_get_namespaced_pod_exec, **kwargs
                )
            except ApiException as exc:
                raise RuntimeError(
                    f"K8sRunner: failed to open exec stream for source ship "
                    f"into {self.namespace}/{pod}: {exc}"
                ) from exc
            stderr_chunks: List[str] = []
            try:
                # The tar bytes from tar_directory() include the standard
                # end-of-archive marker (two zero blocks), so `tar xf -`
                # exits cleanly after reading them and the exec session
                # closes on its own.
                ws.write_stdin(tar_bytes)
                while ws.is_open():
                    ws.update(timeout=1)
                    if ws.peek_stderr():
                        stderr_chunks.append(ws.read_stderr())
                if ws.peek_stderr():
                    stderr_chunks.append(ws.read_stderr())
            finally:
                ws.close()
            stderr = "".join(stderr_chunks).strip()
            if stderr:
                raise RuntimeError(
                    f"K8sRunner: source ship into {self.namespace}/{pod} "
                    f"reported errors: {stderr}"
                )
            self._shipped_sources[digest] = extract_dir
        return pythonpath_entries

    def _ensure_target_resolved(self) -> None:
        if self._resolved_pod is not None and self._resolved_container is not None:
            return

        pod_obj = None
        if self._resolved_pod is None:
            pod_obj = self._find_pod_by_selector()
            self._resolved_pod = pod_obj.metadata.name

        if self._resolved_container is None:
            if pod_obj is None:
                pod_obj = self._read_pod(self._resolved_pod)
            containers = pod_obj.spec.containers or []
            if not containers:
                raise RuntimeError(
                    f"K8sRunner: pod {self.namespace}/{self._resolved_pod} "
                    f"has no containers"
                )
            self._resolved_container = containers[0].name

        _log.info(
            "K8sRunner %r targeting pod %s/%s (container=%s)",
            self.name, self.namespace, self._resolved_pod, self._resolved_container,
        )

    def _find_pod_by_selector(self):
        from kubernetes.client.rest import ApiException

        try:
            pods = self.core_v1.list_namespaced_pod(
                namespace=self.namespace,
                label_selector=self.selector,
            )
        except ApiException as exc:
            raise RuntimeError(
                f"K8sRunner: failed to list pods with selector "
                f"{self.selector!r} in namespace {self.namespace!r}: {exc}"
            ) from exc

        running = [
            p for p in pods.items
            if p.status and p.status.phase == "Running"
        ]
        if not running:
            raise RuntimeError(
                f"K8sRunner: no Running pods match selector "
                f"{self.selector!r} in namespace {self.namespace!r}"
            )
        return running[0]

    def _read_pod(self, pod_name: str):
        from kubernetes.client.rest import ApiException

        try:
            return self.core_v1.read_namespaced_pod(
                name=pod_name, namespace=self.namespace,
            )
        except ApiException as exc:
            raise RuntimeError(
                f"K8sRunner: pod {self.namespace}/{pod_name} not found: {exc}"
            ) from exc
