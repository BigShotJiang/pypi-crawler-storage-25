from __future__ import annotations

import logging
import os
import sys
from concurrent.futures import ThreadPoolExecutor
from threading import RLock
from typing import Dict, List, Mapping, Optional, Union

from .runners.base import Runner

LogLevel = Union[int, str]

_LOG_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

# Tiny ANSI escape set — no dependency on colorlog/rich. The whole log
# line is wrapped per level so yonder output is visibly distinct from the
# user's own stdout: DEBUG/INFO are dim (fade into the background),
# WARNING/ERROR/CRITICAL take their level color (pop forward). One
# wrapper per line — no nested escape sequences.
_ANSI_RESET = "\x1b[0m"
_ANSI_DIM = "\x1b[2m"
_LEVEL_LINE_COLORS = {
    "DEBUG": "\x1b[2;36m",    # dim cyan
    "INFO": "\x1b[2m",        # dim default
    "WARNING": "\x1b[33m",    # yellow
    "ERROR": "\x1b[31m",      # red
    "CRITICAL": "\x1b[1;31m", # bold red
}


def _stream_supports_color(stream) -> bool:
    """Decide whether to emit ANSI escapes on ``stream``.

    Honors the de-facto ``NO_COLOR`` (https://no-color.org) and
    ``FORCE_COLOR`` env vars; otherwise checks ``isatty()`` so piped /
    redirected output stays plain.
    """
    if os.environ.get("NO_COLOR"):
        return False
    if os.environ.get("FORCE_COLOR"):
        return True
    return hasattr(stream, "isatty") and stream.isatty()


class _ColorFormatter(logging.Formatter):
    """Formatter that wraps the whole line in a level-keyed ANSI escape.

    DEBUG/INFO render dim so routine yonder output recedes against
    default-bright stdout; WARNING/ERROR/CRITICAL render in their level
    color so they pop. When ``use_color=False``, falls back to the plain
    base formatter.
    """

    def __init__(self, fmt: str, datefmt: str, use_color: bool):
        super().__init__(fmt, datefmt=datefmt)
        self._use_color = use_color

    def format(self, record: logging.LogRecord) -> str:
        line = super().format(record)
        if not self._use_color:
            return line
        wrap = _LEVEL_LINE_COLORS.get(record.levelname)
        if not wrap:
            return line
        return f"{wrap}{line}{_ANSI_RESET}"


def _configure_logging(level: LogLevel) -> None:
    """Attach (or replace) yonder's stderr handler and set the level.

    Idempotent: re-calling swaps out the previous yonder handler so the
    formatter and level reflect the latest configuration. Color is
    auto-enabled when stderr is a TTY (overridable via ``NO_COLOR`` /
    ``FORCE_COLOR``).
    """
    logger = logging.getLogger("yonder")
    for h in list(logger.handlers):
        if getattr(h, "_yonder_handler", False):
            logger.removeHandler(h)
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(
        _ColorFormatter(
            _LOG_FORMAT, _DATE_FORMAT, _stream_supports_color(sys.stderr)
        )
    )
    handler._yonder_handler = True  # marker so we can find/replace it later
    logger.addHandler(handler)
    logger.setLevel(level)
    logger.propagate = False  # avoid double output via the root logger


class YonderSession:
    """A process-wide collection of named :class:`Runner` instances.

    Populate it with :meth:`register`, then call :meth:`wait` to bring every
    runner to "available" (image built/pulled, persistent containers started)
    before you begin invoking decorated functions.

    Pass ``log_level`` (e.g. ``"INFO"``, ``"DEBUG"``, ``logging.WARNING``) to
    enable formatted yonder logging on stderr. Logging can also be toggled
    later via :meth:`set_log_level` or the module-level
    :func:`yonder.setLogLevel`.
    """

    def __init__(self, log_level: Optional[LogLevel] = None) -> None:
        self._runners: Dict[str, Runner] = {}
        self._lock = RLock()
        self._log = logging.getLogger("yonder.session")
        if log_level is not None:
            _configure_logging(log_level)

    def set_log_level(self, level: LogLevel) -> None:
        _configure_logging(level)

    def register(self, runners: Mapping[str, Runner]) -> None:
        with self._lock:
            for name, runner in runners.items():
                if not isinstance(runner, Runner):
                    raise TypeError(
                        f"register({name!r}=...): expected Runner, "
                        f"got {type(runner).__name__}"
                    )
                self._runners[name] = runner
                self._log.info("registered runner %r (%s)", name, type(runner).__name__)

    def get(self, name: str) -> Runner:
        runner = self._runners.get(name)
        if runner is None:
            raise KeyError(
                f"yonder runner {name!r} is not registered; "
                f"call yonder.register({{'{name}': MyRunner(...)}}) first"
            )
        return runner

    def names(self) -> List[str]:
        return list(self._runners)

    def wait(self, parallel: bool = True) -> None:
        """Block until every registered runner is available.

        Calls :meth:`Runner.start` on each registered runner. With
        ``parallel=True`` (default) image builds/pulls and container starts
        happen concurrently across runners; with ``parallel=False`` they run
        sequentially in registration order.

        If any runner's ``start()`` raises, :meth:`wait` re-raises after the
        other in-flight starts complete.
        """
        runners = list(self._runners.values())
        if not runners:
            return
        self._log.info("waiting for %d runner(s) to become available", len(runners))
        if parallel and len(runners) > 1:
            with ThreadPoolExecutor(max_workers=len(runners)) as ex:
                futures = [ex.submit(r.start) for r in runners]
                first_exc: BaseException | None = None
                for f in futures:
                    try:
                        f.result()
                    except BaseException as exc:  # noqa: BLE001
                        if first_exc is None:
                            first_exc = exc
                if first_exc is not None:
                    raise first_exc
        else:
            for r in runners:
                r.start()
        self._log.info("all runners available")

    def closeAll(self) -> None:
        with self._lock:
            runners = list(self._runners.values())
            self._runners.clear()
        if runners:
            self._log.info("closing %d runner(s)", len(runners))
        for runner in runners:
            runner.close()


_session = YonderSession()


def register(runners: Mapping[str, Runner]) -> None:
    _session.register(runners)


def get(name: str) -> Runner:
    return _session.get(name)


def wait(parallel: bool = True) -> None:
    _session.wait(parallel=parallel)


def closeAll() -> None:
    _session.closeAll()


def setLogLevel(level: LogLevel) -> None:
    """Enable formatted yonder logging on stderr at ``level``."""
    _configure_logging(level)


def getSession() -> YonderSession:
    return _session
