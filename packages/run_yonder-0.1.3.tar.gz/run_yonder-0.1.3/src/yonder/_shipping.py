"""Helpers for shipping a host source tree into a runner.

Used by runners that can't mount host paths (K8sRunner; DockerRunner in
``container=`` mode). The tree is packed into a deterministic tar, the
tar bytes are sha256'd, and the runner uploads the tar once per digest
and caches the remote path so repeat calls are a no-op.
"""
from __future__ import annotations

import hashlib
import io
import os
import sys
import tarfile
from typing import Iterable, List, Optional, Tuple, Union

# Directory entries skipped while walking a source tree. These never
# need to ship — they're caches, VCS metadata, or installed deps that
# blow up the tar without affecting imports.
_SKIP_DIRS = frozenset({"__pycache__", ".git", ".hg", ".svn", ".venv", "venv", "node_modules", ".mypy_cache", ".pytest_cache", ".ruff_cache"})

# File-extension allowlist applied during shipping. The default is the
# union of Python source (``.py``) and the config formats Python
# projects typically read at runtime — anything outside that set is
# skipped. Override per-runner with ``source_include=`` (pass ``None``
# to ship every file in the tree, modulo :data:`_SKIP_DIRS`).
#
# This is *not* a security boundary; it's a default that keeps shipped
# tarballs small in projects that happen to share a directory with
# datasets, notebooks, or build artifacts the runtime doesn't need.
DEFAULT_SOURCE_INCLUDE: Tuple[str, ...] = (".py", ".yaml", ".yml", ".json")

# Where shipped sources land inside the container. Each digest gets its
# own subdirectory so multiple source trees coexist without colliding.
REMOTE_ROOT = "/tmp/yonder-src"


def resolve_auto_source_path() -> str:
    """Resolve ``source_path="auto"`` to the directory of the caller's file.

    Walks up the call stack and returns ``dirname(__file__)`` of the first
    frame whose ``__file__`` is *not* inside the yonder package itself —
    so subclasses of a runner that ``super().__init__(source_path="auto")``
    still resolve to the user's file, not the subclass's.

    Raises :class:`ValueError` if no usable frame is found (REPL/Jupyter
    contexts where ``__file__`` isn't defined).
    """
    yonder_root = os.path.abspath(os.path.dirname(__file__))
    frame = sys._getframe(1)
    while frame is not None:
        fname = frame.f_globals.get("__file__")
        if fname:
            abs_fname = os.path.abspath(fname)
            if not abs_fname.startswith(yonder_root + os.sep):
                return os.path.dirname(abs_fname)
        frame = frame.f_back
    raise ValueError(
        "source_path='auto' could not find a caller with __file__ "
        "(REPL or notebook context); pass an explicit path instead."
    )


def auto_resolve_or_none() -> Optional[str]:
    """Like :func:`resolve_auto_source_path` but returns ``None`` instead
    of raising in REPL/Jupyter contexts.

    Used to drive the implicit ``source_path="auto"`` default that
    runners apply in reference mode: we want the convenience when we
    can deliver it, and to silently fall through (no source shipped /
    mounted) when we can't.
    """
    try:
        return resolve_auto_source_path()
    except ValueError:
        return None


def normalize_source_paths(
    source_path: Optional[Union[str, "os.PathLike[str]", Iterable]],
) -> List[str]:
    """Resolve a ``source_path=`` argument to a list of absolute host paths.

    Accepts a single path, a list/tuple of paths, or ``None``. The literal
    string ``"auto"`` (either standalone or as a list entry) is replaced
    with the calling file's directory via :func:`resolve_auto_source_path`.
    """
    if source_path is None:
        return []
    if source_path == "auto":
        source_path = resolve_auto_source_path()
    elif isinstance(source_path, (list, tuple)):
        source_path = [
            resolve_auto_source_path() if p == "auto" else p
            for p in source_path
        ]
    if isinstance(source_path, (str, bytes, os.PathLike)):
        items = [os.fspath(source_path)]
    else:
        items = [os.fspath(p) for p in source_path]
    return [os.path.abspath(p) for p in items]


def tar_directory(
    host_path: str,
    include: Optional[Iterable[str]] = DEFAULT_SOURCE_INCLUDE,
) -> Tuple[bytes, str, str]:
    """Pack ``host_path`` into a deterministic tar.

    Returns ``(tar_bytes, sha256_digest, basename)``:

    - ``tar_bytes`` — uncompressed tar; entries are placed under
      ``<basename>/<relpath>`` so extracting the archive at some
      ``<remote_root>`` drops the source tree at
      ``<remote_root>/<basename>``.
    - ``sha256_digest`` — first 16 hex chars of sha256 over the tar
      bytes. Used to key the per-runner ship cache so an unchanged
      tree is shipped at most once per process.
    - ``basename`` — ``os.path.basename`` of the host path, used by
      the runner to compute the PYTHONPATH entry inside the container.

    The tar is deterministic given identical file contents: entries are
    sorted, and ``mtime``/``uid``/``gid``/``uname``/``gname`` are zeroed
    so the digest is stable across hosts and timestamps. Common cache
    and VCS directories (see :data:`_SKIP_DIRS`) are excluded.

    ``include`` is a sequence of file extensions to ship (case-insensitive,
    leading dot). Defaults to :data:`DEFAULT_SOURCE_INCLUDE`. Pass ``None``
    to disable the filter and ship every file in the tree (still subject
    to the directory-level skip list).

    Raises :class:`ValueError` if ``host_path`` is not a directory.
    """
    abs_host = os.path.abspath(host_path)
    if not os.path.isdir(abs_host):
        raise ValueError(
            f"source_path {host_path!r} is not a directory (shipped "
            f"source paths must be directories, not single files)"
        )
    basename = os.path.basename(abs_host.rstrip(os.sep)) or "root"
    allowed_exts = (
        None if include is None else {ext.lower() for ext in include}
    )

    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w", format=tarfile.PAX_FORMAT) as tf:
        for root, dirs, files in os.walk(abs_host):
            dirs[:] = sorted(d for d in dirs if d not in _SKIP_DIRS)
            for fname in sorted(files):
                if allowed_exts is not None:
                    ext = os.path.splitext(fname)[1].lower()
                    if ext not in allowed_exts:
                        continue
                full = os.path.join(root, fname)
                rel = os.path.relpath(full, abs_host)
                arcname = os.path.join(basename, rel)
                ti = tf.gettarinfo(full, arcname=arcname)
                ti.mtime = 0
                ti.uid = 0
                ti.gid = 0
                ti.uname = ""
                ti.gname = ""
                with open(full, "rb") as fh:
                    tf.addfile(ti, fh)

    data = buf.getvalue()
    digest = hashlib.sha256(data).hexdigest()[:16]
    return data, digest, basename


def remote_path_for(digest: str, basename: str) -> Tuple[str, str]:
    """Return ``(extract_dir, pythonpath_entry)`` for a shipped source.

    ``extract_dir`` is where the runner uploads/extracts the tar.
    ``pythonpath_entry`` is what gets prepended to ``sys.path`` inside
    the container so ``import <module>`` from the original source tree
    works.
    """
    extract_dir = f"{REMOTE_ROOT}/{digest}"
    pythonpath_entry = f"{extract_dir}/{basename}"
    return extract_dir, pythonpath_entry
