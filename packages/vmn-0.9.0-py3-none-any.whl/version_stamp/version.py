name = "vmn"
version = "0.9.0"
_version = "0.9.0"
