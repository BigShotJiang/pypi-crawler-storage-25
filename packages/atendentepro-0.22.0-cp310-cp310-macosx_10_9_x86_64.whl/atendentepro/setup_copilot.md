# Setup completo AtendentePro — para colar no Copilot

Siga o setup abaixo no projeto atual. Substitua os placeholders pelos valores reais. Aplique apenas os passos opcionais (memória, user_loader) se forem necessários para este projeto. Respeite a seção de cuidados ao final.

---

## 1. Instalação

```bash
pip install atendentepro
```

Opcionais (só se o projeto precisar):
- Memória de longo prazo: `pip install atendentepro[memory]`
- Tracing: `pip install atendentepro[tracing]`
- Tuning: `pip install atendentepro[tuning]`

---

## 2. Variáveis de ambiente (.env)

Criar arquivo `.env` na raiz do projeto. Garantir que `.env` está no `.gitignore`. Nunca commitar chaves reais.

```env
ATENDENTEPRO_LICENSE_KEY=[ATP_SEU_TOKEN]
OPENAI_API_KEY=[OPENAI_API_KEY]

# Opcional Azure (descomente se usar)
# OPENAI_PROVIDER=azure
# AZURE_API_KEY=...
# AZURE_API_ENDPOINT=...
# AZURE_API_VERSION=2024-02-15-preview
# AZURE_DEPLOYMENT_NAME=gpt-4o

# Opcional Custom Provider (DeepSeek, Gemini, Grok, Mistral, Ollama, etc.)
# OPENAI_PROVIDER=custom
# CUSTOM_BASE_URL=https://api.deepseek.com/v1
# CUSTOM_API_KEY=sk-...
# DEFAULT_MODEL=deepseek-chat

# Opcional memória (apenas se usar atendentepro[memory])
# GRKMEMORY_API_KEY=...
```

---

## 3. Ativação e criação da rede

No código de entrada, ativar antes de qualquer uso da rede e criar a rede:

```python
import os
import asyncio
from pathlib import Path
from dotenv import load_dotenv
from atendentepro import activate, create_standard_network
from agents import Runner

load_dotenv()
activate(os.getenv("ATENDENTEPRO_LICENSE_KEY"))

network = create_standard_network(
    templates_root=Path("[CAMINHO_PASTA_TEMPLATES]"),
    client="[NOME_CLIENTE]",
)

async def main():
    messages = [{"role": "user", "content": "Olá, preciso de ajuda"}]
    result = await Runner.run(network.triage, messages)
    print(result.final_output)

asyncio.run(main())
```

Substituir:
- `[CAMINHO_PASTA_TEMPLATES]`: pasta que contém a subpasta do cliente (ex.: `config` ou `templates`)
- `[NOME_CLIENTE]`: nome da subpasta (ex.: `meu_cliente` ou `standard`)

---

## 4. Estrutura de pastas e triage_config.yaml mínimo

Criar a pasta do cliente e o arquivo obrigatório. Exemplo: se `templates_root=config` e `client=meu_cliente`, criar `config/meu_cliente/triage_config.yaml`.

Conteúdo mínimo de `triage_config.yaml`:

```yaml
agent_keywords:
  flow_agent:
    keywords: ["fluxo", "processo", "opções", "menu"]
    description: "Fluxos e opções"
  knowledge_agent:
    keywords: ["conhecimento", "documentação", "dúvida", "informação"]
    description: "Base de conhecimento"
  answer_agent:
    keywords: ["resposta", "ajuda", "suporte"]
    description: "Respostas diretas"

routing_rules:
  priority_order:
    - "answer_agent"
    - "knowledge_agent"
    - "flow_agent"
  default_agent: "knowledge_agent"
```

---

## 4b. knowledge_config.yaml (Knowledge Agent)

Arquivo: `<templates_root>/<cliente>/knowledge_config.yaml`.

**Chaves de topo lidas pela biblioteca** (`KnowledgeConfig.load`):

| Chave | Tipo | Descrição |
|-------|------|-----------|
| `about` | string | Contexto / descrição da base (ou conhecimento direto sem RAG). |
| `template` | string | Metadados de documentos (fluxo RAG). |
| `format` | string | Formato de resposta esperado. |
| `instructions` | string | Instruções extras incorporadas ao prompt do Knowledge Agent. |
| `embeddings_path` | string | Caminho para `.npz` de embeddings. |
| `documents` | lista | Documentos `{name, path, description}`. |
| `rag_config` | objeto | `max_results` (int), `similarity_threshold` (float opcional, 0–1). |
| `data_source` | objeto | Uma fonte estruturada (legado; mesmo formato interno de uma entrada de `data_sources`). |
| `data_sources` | lista | Várias fontes CSV/DB/API. |

Outras chaves **não são usadas** e geram **warning** no log. Exemplo histórico de campos não suportados: `templates/standard/knowledge_config.legacy_example.yaml` (referência apenas; não é carregado).

---

## 5. Opcional: Memória de contexto longo

Aplicar apenas se o projeto precisar de memória (conversas anteriores).

- Instalar: `pip install atendentepro[memory]`
- Adicionar no .env: `GRKMEMORY_API_KEY=...`
- Código:

```python
from atendentepro.memory import run_with_memory, create_grk_backend

network.memory_backend = create_grk_backend()
# Em vez de Runner.run, usar:
result = await run_with_memory(network, network.triage, messages)
```

Em multi-usuário ou canal compartilhado, passar sempre `user_id` (e `session_id` se aplicável) em cada chamada a `run_with_memory`.

---

## 6. Opcional: User loader

Aplicar apenas se o projeto precisar carregar dados do usuário por request (banco, CSV, API).

- user_loader retorna `UserContext(user_id=..., role=..., metadata=...)` com dados do **request atual**.
- Não usar user_loader para memória nem session_id; session_id por parâmetro ou `network.session_id_factory`.

```python
from atendentepro.models import UserContext

def loader(messages):
    return UserContext(user_id="...", role="cliente", metadata={})

network = create_standard_network(..., user_loader=loader)
```

---

## 6b. Opcional: hard_block_patterns (PII / domínio do cliente)

Setores regulados (financeiro, saúde, telco) podem precisar bloquear deterministicamente padrões de PII na entrada — sem depender de LLM e antes do guardrail de escopo. Declare em `client_templates/<cliente>/guardrails_config.yaml`:

```yaml
agent_scopes:
  triage_agent:
    about: |
      ...

# Regex hard-block customizado por cliente (issue #90).
# Roda na input guardrail APOS o block global de jailbreak e ANTES do
# LLM de escopo. Mensagem customizada por pattern propaga via output_info.
hard_block_patterns:
  - name: "cpf"
    pattern: "\\b\\d{3}\\.?\\d{3}\\.?\\d{3}-?\\d{2}\\b"
    message: "Nao posso processar CPF nesta conversa. Por favor remova o dado e tente novamente."

  - name: "cnpj"
    pattern: "\\b\\d{2}\\.?\\d{3}\\.?\\d{3}/?\\d{4}-?\\d{2}\\b"
    message: "Nao posso processar CNPJ nesta conversa."

  - name: "credit_card"
    pattern: "\\b\\d{4}[\\s-]?\\d{4}[\\s-]?\\d{4}[\\s-]?\\d{4}\\b"
    message: "Nao posso processar dados de cartao."
```

**Comportamento:**
- Cada pattern e compilado uma vez (case-insensitive). Regex inválido é logado como WARNING e ignorado — não quebra o resto.
- Quando casa, `tripwire_triggered=True` e `output_info` carrega `CustomHardBlockHit(name, message)`. O caller que captura `InputGuardrailTripwireTriggered` lê `.guardrail_result.output.output_info.message` para a resposta ao usuário.
- Camada **1.2** no pipeline: jailbreak hard-block → custom hard-block → escalation bypass → LLM scope.

**Cuidados:**
- Patterns muito amplos podem bloquear conversas legítimas. Teste com mensagens reais.
- A message é **obrigatória**; entries sem message são ignoradas com WARNING (forçar escolha consciente).

---

## 6c. Opcional: rede custom via factory module (issue #87)

Quando o cliente precisa de uma rede que combina injeção de instructions, tools e handoffs alem do `create_standard_network`/`create_custom_network`, o `TenantManager.setup()` aceita um caminho `network_type="custom_module"` que importa um modulo Python pelo nome e chama uma factory.

```python
await manager.setup(
    tenant_id="acme",
    yamls={...},
    network_type="custom_module",
    network_module="client_resources.acme.network",
    network_factory="create_acme_network",
    network_params={"brand": "Acme Inc.", "tier": "premium"},
)
```

A factory deve retornar uma instancia de `atendentepro.AgentNetwork`.

**Allowlist de seguranca (RCE protection):**

`importlib.import_module(arg)` permite carregar qualquer modulo Python — vetor de RCE se um YAML malicioso passar por code review desatento. A lib enforce uma allowlist por prefixo:

| Variavel | Default | Como usar |
|---|---|---|
| `ATENDENTEPRO_NETWORK_MODULE_PREFIX` | `client_resources.` | Lista de prefixos permitidos, separados por virgula. Modulos fora destes prefixos sao rejeitados com `NetworkModuleNotAllowedError`. |

Exemplos:
```bash
# Permitir apenas client_resources/* (default)
unset ATENDENTEPRO_NETWORK_MODULE_PREFIX

# Adicionar segundo namespace para clientes externos
export ATENDENTEPRO_NETWORK_MODULE_PREFIX="client_resources.,partner_clients."

# Desabilitar a checagem (NAO RECOMENDADO)
export ATENDENTEPRO_NETWORK_MODULE_PREFIX="*"
```

**Erros precisos por categoria** (todos validados no boot, fail-fast):
- `NetworkModuleNotAllowedError` — prefixo nao bate
- `ImportError` — modulo nao existe / nao importa
- `AttributeError` — factory ausente no modulo
- `TypeError` — factory nao callable, ou kwargs incompativeis, ou retorno nao e AgentNetwork

**Cuidados:**
- Nao misture `network_type="custom_module"` com `network_config` — o primeiro tem precedencia.
- A factory deve aceitar `**kwargs` para propagacao de `network_params`.
- Validar o factory localmente antes de declarar no `clients.yaml` do tenant.

---

## 6d. Opcional: janela de histórico (multi-turn, issue #57)

Em conversas longas (5+ turnos no mesmo assunto, ou troca frequente de
assunto), o LLM pode degradar (alucinações, latência alta). Configure
opt-in via `HistoryWindow` (default `None` = comportamento original):

```python
from atendentepro import HistoryWindow

network.history_window = HistoryWindow(
    max_messages=20,                    # [Phase 4.1 ATIVO]
    summarize_after_n_messages=10,      # [Phase 4.2 planejado]
    summary_system_prompt=None,         # [Phase 4.2 planejado] None = prompt PT-BR padrão
    summary_model="gpt-4.1",            # [Phase 4.2 ATIVO] None usa default_model
    on_agent_reset=None,                # [Phase 4.3 planejado] callback(agent_name, msgs)
)
```

| Parâmetro | Status | Uso |
|---|---|---|
| `max_messages` | ATIVO v0.19.0 | Trunca para N últimos turnos user/assistant; system messages preservadas |
| `summarize_after_n_messages` | ATIVO v0.20.0 | Comprime turnos antigos em 1 mensagem `system` via LLM |
| `summary_system_prompt` | ATIVO v0.20.0 | Override do prompt de sumarização (default: PT-BR built-in) |
| `summary_model` | ATIVO v0.20.0 | Modelo da chamada de sumarização (default: `get_config().default_model`) |
| `on_agent_reset` | ATIVO v0.21.0 | Callback `(agent_name, msgs)` quando controle volta para Triage; exceções logadas + ignoradas |

Desde a v0.20.0, `apply_history_window` é `async` — direct callers
(`Runner.run` direto, sem `run_with_memory`) precisam de `await`.
`run_with_memory` foi atualizado internamente: aplica a janela antes do
turno **e** salva `network.last_agent_name` após para o callback do
próximo turno disparar quando apropriado.

Detalhes completos: [docs/setup_passo_a_passo/08_opcionais_history_window.md](../docs/setup_passo_a_passo/08_opcionais_history_window.md).
Exemplos executáveis: [docs/examples/history_window/](../docs/examples/history_window/).

---

## 7. Principais cuidados (checklist)

- [ ] Não commitar `.env`; manter no `.gitignore`. Não colar chaves em código.
- [ ] Chamar `activate()` antes de qualquer uso da rede.
- [ ] Em multi-usuário ou canal compartilhado: sempre passar `user_id` (e `session_id` quando aplicável) em `run_with_memory`.
- [ ] user_loader: retornar dados do request atual; não usar para session_id.
- [ ] Não concatenar input do usuário em system prompts (ver docs/SECURITY.md ao estender).
- [ ] Pasta de templates deve existir e conter pelo menos `triage_config.yaml`; `templates_root` + `client` devem apontar para ela.

Referências: [docs/setup_passo_a_passo/07_cuidados_principais.md](07_cuidados_principais.md), [docs/SECURITY.md](../SECURITY.md).
