# -*- coding: utf-8 -*-
"""Configuration module for AtendentePro library."""

from .settings import (
    DEFAULT_MODEL,
    KNOWN_PROVIDERS,
    RECOMMENDED_PROMPT_PREFIX,
    SINGLE_REPLY_INSTRUCTION,
    AtendenteProConfig,
    AtendentProConfig,
    ProviderConfig,
    configure,
    get_config,
)

__all__ = [
    "AtendenteProConfig",
    "AtendentProConfig",
    "get_config",
    "configure",
    "RECOMMENDED_PROMPT_PREFIX",
    "SINGLE_REPLY_INSTRUCTION",
    "DEFAULT_MODEL",
    "KNOWN_PROVIDERS",
    "ProviderConfig",
]
