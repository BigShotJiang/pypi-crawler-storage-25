"""Base adapter interface for provider compatibility layer."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Optional


class _CompletionsNamespace:
    """Namespace that delegates to adapter._chat_completions_create()."""

    def __init__(self, adapter: "AdapterClient") -> None:
        self._adapter = adapter

    async def create(self, **kwargs: Any) -> Any:
        return await self._adapter._chat_completions_create(**kwargs)


class _ChatNamespace:
    """Namespace that exposes .completions matching AsyncOpenAI.chat.completions."""

    def __init__(self, adapter: "AdapterClient") -> None:
        self.completions = _CompletionsNamespace(adapter)


class _EmbeddingsNamespace:
    """Namespace that delegates to adapter._embeddings_create()."""

    def __init__(self, adapter: "AdapterClient") -> None:
        self._adapter = adapter

    async def create(self, **kwargs: Any) -> Any:
        return await self._adapter._embeddings_create(**kwargs)


class AdapterClient(ABC):
    """Abstract base for provider adapters.

    Subclasses implement _chat_completions_create() and _embeddings_create().
    Callers use the same interface as AsyncOpenAI:
        adapter.chat.completions.create(...)
        adapter.embeddings.create(...)
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> None:
        self.chat = _ChatNamespace(self)
        self.embeddings = _EmbeddingsNamespace(self)

    @abstractmethod
    async def _chat_completions_create(self, **kwargs: Any) -> Any: ...

    @abstractmethod
    async def _embeddings_create(self, **kwargs: Any) -> Any: ...
