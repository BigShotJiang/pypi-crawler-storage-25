"""Provider compatibility layer for AtendentePro.

Adapters translate non-OpenAI-compatible APIs into the AsyncOpenAI interface
that the OpenAI Agents SDK expects.
"""

from atendentepro.providers.base import AdapterClient
from atendentepro.providers.registry import (
    PROVIDER_CAPABILITIES,
    get_provider_capabilities,
    register_adapter,
    resolve_client_for_provider,
)

__all__ = [
    "AdapterClient",
    "PROVIDER_CAPABILITIES",
    "get_provider_capabilities",
    "register_adapter",
    "resolve_client_for_provider",
]
