"""Provider adapter registry and capability declarations."""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional, Type

from atendentepro.providers.base import AdapterClient

logger = logging.getLogger(__name__)

# Maps provider name -> adapter class (lazy-populated for optional deps)
PROVIDER_ADAPTERS: Dict[str, Type[AdapterClient]] = {}

PROVIDER_CAPABILITIES: Dict[str, Dict[str, bool]] = {
    "openai": {"json_schema": True, "tools": True, "embeddings": True},
    "azure": {"json_schema": True, "tools": True, "embeddings": True},
    "anthropic": {"json_schema": True, "tools": True, "embeddings": False},
    "deepseek": {"json_schema": False, "tools": True, "embeddings": False},
    "gemini": {"json_schema": True, "tools": True, "embeddings": True},
}

_DEFAULT_CAPABILITIES: Dict[str, bool] = {
    "json_schema": False,
    "tools": True,
    "embeddings": False,
}


def get_provider_capabilities(provider: str) -> Dict[str, bool]:
    """Return capability flags for a provider. Unknown providers get conservative defaults."""
    return PROVIDER_CAPABILITIES.get(provider, dict(_DEFAULT_CAPABILITIES))


def register_adapter(provider: str, adapter_cls: Type[AdapterClient]) -> None:
    """Register a provider adapter class."""
    PROVIDER_ADAPTERS[provider] = adapter_cls
    logger.info("Registered adapter for provider '%s': %s", provider, adapter_cls.__name__)


def resolve_client_for_provider(provider_config: Any) -> Optional[AdapterClient]:
    """If the provider has a registered native adapter, instantiate and return it.

    Returns None if no adapter is registered (caller should fall back to AsyncOpenAI).
    """
    adapter_cls = PROVIDER_ADAPTERS.get(provider_config.provider)
    if adapter_cls is None:
        return None
    api_key = provider_config.get_api_key()
    base_url = provider_config.get_base_url()
    return adapter_cls(api_key=api_key, base_url=base_url)


def _auto_register() -> None:
    """Auto-register adapters for available optional dependencies."""
    try:
        from atendentepro.providers.anthropic import AnthropicAdapter

        register_adapter("anthropic", AnthropicAdapter)
    except ImportError:
        pass

    try:
        from atendentepro.providers.gemini import GeminiAdapter

        register_adapter("gemini", GeminiAdapter)
    except ImportError:
        pass


_auto_register()
