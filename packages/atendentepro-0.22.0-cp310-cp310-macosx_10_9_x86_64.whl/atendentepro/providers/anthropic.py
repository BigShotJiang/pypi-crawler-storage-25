"""Anthropic provider adapter.

Translates AsyncOpenAI chat.completions.create() calls to the native Anthropic
Messages API, enabling Anthropic models (Claude) to work with the OpenAI Agents SDK.

Requires: pip install anthropic  (or: pip install atendentepro[anthropic])
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional, Tuple

from atendentepro.providers.base import AdapterClient

logger = logging.getLogger(__name__)

try:
    import anthropic
    from anthropic import AsyncAnthropic
except ImportError as _e:
    raise ImportError(
        "The 'anthropic' package is required for the Anthropic provider adapter. "
        "Install it with: pip install atendentepro[anthropic]"
    ) from _e

from dataclasses import dataclass
from dataclasses import field as dc_field


@dataclass
class _Function:
    name: str
    arguments: str


@dataclass
class _ToolCall:
    id: str
    type: str
    function: _Function


@dataclass
class _Message:
    role: str
    content: Optional[str]
    tool_calls: Optional[List[_ToolCall]] = None


@dataclass
class _Choice:
    index: int
    message: _Message
    finish_reason: str


@dataclass
class _Usage:
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


@dataclass
class _ChatCompletion:
    id: str
    object: str
    model: str
    choices: List[_Choice]
    usage: _Usage


class AnthropicAdapter(AdapterClient):
    """Adapter that translates OpenAI chat.completions interface to Anthropic Messages API."""

    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None) -> None:
        super().__init__()
        kwargs: Dict[str, Any] = {}
        if api_key:
            kwargs["api_key"] = api_key
        if base_url:
            kwargs["base_url"] = base_url
        self._anthropic_client = AsyncAnthropic(**kwargs)

    def _translate_messages(
        self, messages: List[Dict[str, Any]]
    ) -> Tuple[Optional[str], List[Dict[str, Any]]]:
        """Translate OpenAI messages to Anthropic format.
        Returns (system_prompt, translated_messages).
        """
        system_parts: List[str] = []
        translated: List[Dict[str, Any]] = []

        for msg in messages:
            role = msg.get("role", "")
            content = msg.get("content")
            tool_calls = msg.get("tool_calls")

            if role == "system":
                if content:
                    system_parts.append(content)
                continue

            if role == "tool":
                tool_result_block = {
                    "type": "tool_result",
                    "tool_use_id": msg.get("tool_call_id", ""),
                    "content": content or "",
                }
                translated.append({"role": "user", "content": [tool_result_block]})
                continue

            if role == "assistant" and tool_calls:
                blocks: List[Dict[str, Any]] = []
                if content:
                    blocks.append({"type": "text", "text": content})
                for tc in tool_calls:
                    fn = tc.get("function", {})
                    try:
                        input_data = json.loads(fn.get("arguments", "{}"))
                    except (json.JSONDecodeError, TypeError):
                        input_data = {}
                    blocks.append(
                        {
                            "type": "tool_use",
                            "id": tc.get("id", ""),
                            "name": fn.get("name", ""),
                            "input": input_data,
                        }
                    )
                translated.append({"role": "assistant", "content": blocks})
                continue

            translated.append({"role": role, "content": content or ""})

        system = "\n\n".join(system_parts) if system_parts else None
        return system, translated

    def _translate_tools(self, tools: Optional[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
        """Translate OpenAI tool definitions to Anthropic format."""
        if not tools:
            return []
        result = []
        for tool in tools:
            fn = tool.get("function", {})
            result.append(
                {
                    "name": fn.get("name", ""),
                    "description": fn.get("description", ""),
                    "input_schema": fn.get("parameters", {"type": "object", "properties": {}}),
                }
            )
        return result

    def _translate_tool_choice(self, tool_choice: Any) -> Optional[Dict[str, Any]]:
        """Translate OpenAI tool_choice to Anthropic format."""
        if tool_choice is None:
            return None
        if tool_choice == "auto":
            return {"type": "auto"}
        if tool_choice == "required":
            return {"type": "any"}
        if tool_choice == "none":
            return {"type": "auto"}
        if isinstance(tool_choice, dict):
            fn = tool_choice.get("function", {})
            return {"type": "tool", "name": fn.get("name", "")}
        return None

    def _build_structured_output_tool(self, response_format: Dict[str, Any]) -> Dict[str, Any]:
        """Build a synthetic tool for structured output enforcement."""
        json_schema = response_format.get("json_schema", {})
        schema = json_schema.get("schema", {"type": "object", "properties": {}})
        return {
            "name": "_structured_output",
            "description": "Return the structured response in the required format.",
            "input_schema": schema,
        }

    def _translate_response(
        self, response: Any, structured_output: bool = False
    ) -> _ChatCompletion:
        """Translate Anthropic response to OpenAI ChatCompletion format."""
        text_parts: List[str] = []
        tool_calls: List[_ToolCall] = []

        for block in response.content:
            if block.type == "text":
                text_parts.append(block.text)
            elif block.type == "tool_use":
                if structured_output and block.name == "_structured_output":
                    return _ChatCompletion(
                        id=response.id,
                        object="chat.completion",
                        model=response.model,
                        choices=[
                            _Choice(
                                index=0,
                                message=_Message(
                                    role="assistant",
                                    content=json.dumps(block.input),
                                    tool_calls=None,
                                ),
                                finish_reason="stop",
                            )
                        ],
                        usage=_Usage(
                            prompt_tokens=response.usage.input_tokens,
                            completion_tokens=response.usage.output_tokens,
                            total_tokens=response.usage.input_tokens + response.usage.output_tokens,
                        ),
                    )
                tool_calls.append(
                    _ToolCall(
                        id=block.id,
                        type="function",
                        function=_Function(
                            name=block.name,
                            arguments=json.dumps(block.input),
                        ),
                    )
                )

        content = "\n".join(text_parts) if text_parts else None
        has_tools = len(tool_calls) > 0
        finish_reason = "tool_calls" if has_tools else "stop"
        if response.stop_reason == "end_turn":
            finish_reason = "stop"
        elif response.stop_reason == "tool_use":
            finish_reason = "tool_calls"

        return _ChatCompletion(
            id=response.id,
            object="chat.completion",
            model=response.model,
            choices=[
                _Choice(
                    index=0,
                    message=_Message(
                        role="assistant",
                        content=content,
                        tool_calls=tool_calls if has_tools else None,
                    ),
                    finish_reason=finish_reason,
                )
            ],
            usage=_Usage(
                prompt_tokens=response.usage.input_tokens,
                completion_tokens=response.usage.output_tokens,
                total_tokens=response.usage.input_tokens + response.usage.output_tokens,
            ),
        )

    async def _chat_completions_create(self, **kwargs: Any) -> _ChatCompletion:
        """Translate and forward a chat.completions.create() call to Anthropic."""
        messages = kwargs.get("messages", [])
        model = kwargs.get("model", "claude-sonnet-4-6")
        tools = kwargs.get("tools")
        tool_choice = kwargs.get("tool_choice")
        response_format = kwargs.get("response_format")
        max_tokens = kwargs.get("max_tokens", 4096)
        temperature = kwargs.get("temperature")

        system, translated_messages = self._translate_messages(messages)
        structured_output = False

        anthropic_kwargs: Dict[str, Any] = {
            "model": model,
            "messages": translated_messages,
            "max_tokens": max_tokens,
        }
        if system:
            anthropic_kwargs["system"] = system
        if temperature is not None:
            anthropic_kwargs["temperature"] = temperature

        anthropic_tools = self._translate_tools(tools)

        if response_format and response_format.get("type") in ("json_schema", "json_object"):
            if response_format.get("type") == "json_schema":
                struct_tool = self._build_structured_output_tool(response_format)
                anthropic_tools.append(struct_tool)
                tool_choice = {"type": "function", "function": {"name": "_structured_output"}}
                structured_output = True
            else:
                json_instruction = "\n\nYou must respond with valid JSON only. No other text."
                if system:
                    anthropic_kwargs["system"] = system + json_instruction
                else:
                    anthropic_kwargs["system"] = json_instruction.strip()

        if anthropic_tools:
            anthropic_kwargs["tools"] = anthropic_tools
        translated_choice = self._translate_tool_choice(tool_choice)
        if translated_choice:
            anthropic_kwargs["tool_choice"] = translated_choice

        response = await self._anthropic_client.messages.create(**anthropic_kwargs)
        return self._translate_response(response, structured_output=structured_output)

    async def _embeddings_create(self, **kwargs: Any) -> Any:
        """Anthropic does not support embeddings."""
        raise NotImplementedError(
            "Anthropic does not support embeddings. "
            "Configure a separate embedding provider (e.g. OpenAI) for RAG."
        )
