"""Google Gemini provider adapter.

Translates AsyncOpenAI chat.completions.create() calls to the native Google
GenAI SDK, enabling Gemini models to work with the OpenAI Agents SDK with full
support for function calling, structured output, and embeddings.

Requires: pip install google-genai  (or: pip install atendentepro[gemini])
"""

from __future__ import annotations

import json
import logging
import uuid
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from atendentepro.providers.base import AdapterClient

logger = logging.getLogger(__name__)

try:
    from google import genai
    from google.genai import types as genai_types
except ImportError as _e:
    raise ImportError(
        "The 'google-genai' package is required for the Gemini provider adapter. "
        "Install it with: pip install atendentepro[gemini]"
    ) from _e


# ---------------------------------------------------------------------------
# Lightweight OpenAI-compatible response dataclasses
# (shared shape with anthropic.py — kept local to avoid coupling)
# ---------------------------------------------------------------------------


@dataclass
class _Function:
    name: str
    arguments: str


@dataclass
class _ToolCall:
    id: str
    type: str
    function: _Function


@dataclass
class _Message:
    role: str
    content: Optional[str]
    tool_calls: Optional[List[_ToolCall]] = None


@dataclass
class _Choice:
    index: int
    message: _Message
    finish_reason: str


@dataclass
class _Usage:
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


@dataclass
class _ChatCompletion:
    id: str
    object: str
    model: str
    choices: List[_Choice]
    usage: _Usage


@dataclass
class _EmbeddingData:
    object: str
    index: int
    embedding: List[float]


@dataclass
class _EmbeddingUsage:
    prompt_tokens: int
    total_tokens: int


@dataclass
class _EmbeddingResponse:
    object: str
    data: List[_EmbeddingData]
    model: str
    usage: _EmbeddingUsage


class GeminiAdapter(AdapterClient):
    """Adapter that translates OpenAI chat.completions interface to Google GenAI SDK."""

    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None) -> None:
        super().__init__(api_key=api_key, base_url=base_url)
        if not api_key:
            raise RuntimeError(
                "API key is required for the Gemini adapter. "
                "Set api_key in ProviderConfig or the GEMINI_API_KEY env var."
            )
        self._client = genai.Client(api_key=api_key)

    # =========================================================================
    # Message translation
    # =========================================================================

    def _translate_messages(
        self, messages: List[Dict[str, Any]]
    ) -> Tuple[Optional[str], List[genai_types.Content]]:
        """Translate OpenAI messages to Gemini Content format.

        Returns (system_instruction, contents).
        """
        system_parts: List[str] = []
        contents: List[genai_types.Content] = []

        for msg in messages:
            role = msg.get("role", "")
            content = msg.get("content")
            tool_calls = msg.get("tool_calls")

            if role == "system":
                if content:
                    system_parts.append(content)
                continue

            if role == "tool":
                # OpenAI tool result → Gemini function response
                tool_call_id = msg.get("tool_call_id", "")
                # Extract function name from tool_call_id if available
                fn_name = msg.get("name", tool_call_id)
                try:
                    result_data = json.loads(content) if content else {}
                except (json.JSONDecodeError, TypeError):
                    result_data = {"result": content or ""}
                part = genai_types.Part.from_function_response(
                    name=fn_name,
                    response=result_data,
                )
                contents.append(genai_types.Content(role="user", parts=[part]))
                continue

            if role == "assistant" and tool_calls:
                # Assistant with tool calls → function call parts
                parts: List[genai_types.Part] = []
                if content:
                    parts.append(genai_types.Part.from_text(text=content))
                for tc in tool_calls:
                    fn = tc.get("function", {})
                    try:
                        args = json.loads(fn.get("arguments", "{}"))
                    except (json.JSONDecodeError, TypeError):
                        args = {}
                    parts.append(
                        genai_types.Part.from_function_call(
                            name=fn.get("name", ""),
                            args=args,
                        )
                    )
                contents.append(genai_types.Content(role="model", parts=parts))
                continue

            # Regular user/assistant message
            gemini_role = "model" if role == "assistant" else "user"
            parts_list: List[genai_types.Part] = []
            if content:
                parts_list.append(genai_types.Part.from_text(text=content))
            if parts_list:
                contents.append(genai_types.Content(role=gemini_role, parts=parts_list))

        system_instruction = "\n\n".join(system_parts) if system_parts else None
        return system_instruction, contents

    # =========================================================================
    # Tool translation
    # =========================================================================

    def _translate_tools(
        self, tools: Optional[List[Dict[str, Any]]]
    ) -> Optional[List[genai_types.Tool]]:
        """Translate OpenAI tool definitions to Gemini format."""
        if not tools:
            return None
        declarations = []
        for tool in tools:
            fn = tool.get("function", {})
            params = fn.get("parameters")
            decl_kwargs: Dict[str, Any] = {
                "name": fn.get("name", ""),
                "description": fn.get("description", ""),
            }
            if params:
                decl_kwargs["parameters"] = params
            declarations.append(genai_types.FunctionDeclaration(**decl_kwargs))
        return [genai_types.Tool(function_declarations=declarations)]

    def _translate_tool_choice(
        self, tool_choice: Any, tools_present: bool
    ) -> Optional[genai_types.ToolConfig]:
        """Translate OpenAI tool_choice to Gemini ToolConfig."""
        if not tools_present:
            return None
        if tool_choice is None or tool_choice == "auto":
            return genai_types.ToolConfig(
                function_calling_config=genai_types.FunctionCallingConfig(mode="AUTO")
            )
        if tool_choice == "required":
            return genai_types.ToolConfig(
                function_calling_config=genai_types.FunctionCallingConfig(mode="ANY")
            )
        if tool_choice == "none":
            return genai_types.ToolConfig(
                function_calling_config=genai_types.FunctionCallingConfig(mode="NONE")
            )
        if isinstance(tool_choice, dict):
            fn = tool_choice.get("function", {})
            fn_name = fn.get("name", "")
            return genai_types.ToolConfig(
                function_calling_config=genai_types.FunctionCallingConfig(
                    mode="ANY",
                    allowed_function_names=[fn_name],
                )
            )
        return None

    # =========================================================================
    # Response translation
    # =========================================================================

    def _translate_response(
        self, response: Any, model: str, structured_output: bool = False
    ) -> _ChatCompletion:
        """Translate Gemini response to OpenAI ChatCompletion format."""
        text_parts: List[str] = []
        tool_calls: List[_ToolCall] = []

        candidate = response.candidates[0] if response.candidates else None
        if candidate and candidate.content and candidate.content.parts:
            for part in candidate.content.parts:
                if hasattr(part, "text") and part.text is not None:
                    text_parts.append(part.text)
                elif hasattr(part, "function_call") and part.function_call is not None:
                    fc = part.function_call
                    args = dict(fc.args) if fc.args else {}
                    if structured_output and fc.name == "_structured_output":
                        return _ChatCompletion(
                            id=f"gemini-{uuid.uuid4().hex[:12]}",
                            object="chat.completion",
                            model=model,
                            choices=[
                                _Choice(
                                    index=0,
                                    message=_Message(
                                        role="assistant",
                                        content=json.dumps(args),
                                        tool_calls=None,
                                    ),
                                    finish_reason="stop",
                                )
                            ],
                            usage=self._extract_usage(response),
                        )
                    tool_calls.append(
                        _ToolCall(
                            id=f"call_{uuid.uuid4().hex[:8]}",
                            type="function",
                            function=_Function(
                                name=fc.name,
                                arguments=json.dumps(args),
                            ),
                        )
                    )

        content = "\n".join(text_parts) if text_parts else None
        has_tools = len(tool_calls) > 0

        # Determine finish_reason
        finish_reason = "stop"
        if has_tools:
            finish_reason = "tool_calls"
        elif candidate and hasattr(candidate, "finish_reason"):
            fr = str(candidate.finish_reason).upper() if candidate.finish_reason else ""
            if "STOP" in fr:
                finish_reason = "stop"
            elif "MAX_TOKENS" in fr or "LENGTH" in fr:
                finish_reason = "length"

        return _ChatCompletion(
            id=f"gemini-{uuid.uuid4().hex[:12]}",
            object="chat.completion",
            model=model,
            choices=[
                _Choice(
                    index=0,
                    message=_Message(
                        role="assistant",
                        content=content,
                        tool_calls=tool_calls if has_tools else None,
                    ),
                    finish_reason=finish_reason,
                )
            ],
            usage=self._extract_usage(response),
        )

    def _extract_usage(self, response: Any) -> _Usage:
        """Extract token usage from Gemini response."""
        usage = getattr(response, "usage_metadata", None)
        if usage:
            prompt = getattr(usage, "prompt_token_count", 0) or 0
            completion = getattr(usage, "candidates_token_count", 0) or 0
            return _Usage(
                prompt_tokens=prompt,
                completion_tokens=completion,
                total_tokens=prompt + completion,
            )
        return _Usage(prompt_tokens=0, completion_tokens=0, total_tokens=0)

    # =========================================================================
    # Structured output via response_schema or synthetic tool
    # =========================================================================

    def _build_response_schema(self, response_format: Dict[str, Any]) -> Dict[str, Any]:
        """Extract JSON schema from OpenAI response_format for Gemini's response_schema."""
        json_schema = response_format.get("json_schema", {})
        return json_schema.get("schema", {"type": "object", "properties": {}})

    # =========================================================================
    # Main API methods
    # =========================================================================

    async def _chat_completions_create(self, **kwargs: Any) -> _ChatCompletion:
        """Translate and forward a chat.completions.create() call to Gemini."""
        messages = kwargs.get("messages", [])
        model = kwargs.get("model", "gemini-2.0-flash")
        tools = kwargs.get("tools")
        tool_choice = kwargs.get("tool_choice")
        response_format = kwargs.get("response_format")
        max_tokens = kwargs.get("max_tokens")
        temperature = kwargs.get("temperature")

        system_instruction, contents = self._translate_messages(messages)
        structured_output = False

        config_kwargs: Dict[str, Any] = {}
        if max_tokens is not None:
            config_kwargs["max_output_tokens"] = max_tokens
        if temperature is not None:
            config_kwargs["temperature"] = temperature
        if system_instruction:
            config_kwargs["system_instruction"] = system_instruction

        # Translate tools
        gemini_tools = self._translate_tools(tools)

        # Handle structured output
        if response_format and response_format.get("type") in ("json_schema", "json_object"):
            if response_format.get("type") == "json_schema":
                # Use Gemini's native response_schema (preferred over synthetic tool)
                schema = self._build_response_schema(response_format)
                config_kwargs["response_mime_type"] = "application/json"
                config_kwargs["response_schema"] = schema
                structured_output = True
            else:
                # json_object mode
                config_kwargs["response_mime_type"] = "application/json"

        generate_kwargs: Dict[str, Any] = {
            "model": model,
            "contents": contents,
        }

        if config_kwargs:
            generate_kwargs["config"] = genai_types.GenerateContentConfig(**config_kwargs)

        if gemini_tools:
            # Tools go in config
            if "config" in generate_kwargs:
                # Rebuild config with tools
                config_kwargs_with_tools = dict(config_kwargs)
                config_kwargs_with_tools["tools"] = gemini_tools
                tool_config = self._translate_tool_choice(tool_choice, True)
                if tool_config:
                    config_kwargs_with_tools["tool_config"] = tool_config
                generate_kwargs["config"] = genai_types.GenerateContentConfig(
                    **config_kwargs_with_tools
                )
            else:
                tc = self._translate_tool_choice(tool_choice, True)
                tool_cfg: Dict[str, Any] = {"tools": gemini_tools}
                if tc:
                    tool_cfg["tool_config"] = tc
                generate_kwargs["config"] = genai_types.GenerateContentConfig(**tool_cfg)

        response = await self._client.aio.models.generate_content(**generate_kwargs)
        return self._translate_response(response, model=model, structured_output=structured_output)

    async def _embeddings_create(self, **kwargs: Any) -> _EmbeddingResponse:
        """Translate embeddings.create() to Gemini embed_content."""
        model = kwargs.get("model", "text-embedding-004")
        input_text = kwargs.get("input", "")

        # Handle both string and list inputs
        if isinstance(input_text, list):
            texts = input_text
        else:
            texts = [input_text]

        data: List[_EmbeddingData] = []
        total_tokens = 0

        for i, text in enumerate(texts):
            response = await self._client.aio.models.embed_content(
                model=model,
                contents=text,
            )
            embedding = list(response.embeddings[0].values)
            data.append(
                _EmbeddingData(
                    object="embedding",
                    index=i,
                    embedding=embedding,
                )
            )

        return _EmbeddingResponse(
            object="list",
            data=data,
            model=model,
            usage=_EmbeddingUsage(prompt_tokens=total_tokens, total_tokens=total_tokens),
        )
