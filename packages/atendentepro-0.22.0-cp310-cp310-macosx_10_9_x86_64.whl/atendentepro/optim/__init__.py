# -*- coding: utf-8 -*-
"""Prompt optimization cache (zero external dependencies).

This module stores pre-compiled/optimized prompt variants on disk and
exposes them to ``_apply_dialect_to_instructions`` at agent-build time.

**The AtendentePro package does NOT ship any optimizer.** The cache is a
pure in/out store: callers compile prompts with whatever tooling they
choose (DSPy, hand-tuned prompts, a script that calls the LLM directly,
a human editing a file) and persist the result via ``store_optimized_prompt``.
At runtime, ``_apply_dialect_to_instructions`` consults the cache and,
on a hit, returns the optimized text as-is — bypassing the dialect
adapter.

This deliberate split keeps AtendentePro's supply-chain surface minimal:
no optional dependency on DSPy / LiteLLM / transitive packages whose
security we cannot guarantee. Security-conscious deployments get the
optim cache functionality with zero extra pip install.

See ``docs/examples/optim/dspy_external.py`` for a reference script
that wires DSPy (installed separately by the caller) to populate the
cache. The pattern generalises to any optimizer.

Public API
----------
- ``cache_key_for(text, provider=None)`` — deterministic hash key.
- ``get_optimized_prompt(text, model, provider=None)`` — cache lookup.
- ``store_optimized_prompt(text, model, optimized, ...)`` — cache write.
- ``OptimCache`` — low-level cache reader/writer.
- ``compose_lm_model_string`` — LiteLLM-style spec helper
  (exported for convenience of callers writing their own optimizer).
"""

from __future__ import annotations

from atendentepro.optim._lm_spec import compose_lm_model_string
from atendentepro.optim.cache import (
    OptimCache,
    cache_key_for,
    get_optimized_prompt,
    store_optimized_prompt,
)

__all__ = [
    "cache_key_for",
    "get_optimized_prompt",
    "store_optimized_prompt",
    "OptimCache",
    "compose_lm_model_string",
]
