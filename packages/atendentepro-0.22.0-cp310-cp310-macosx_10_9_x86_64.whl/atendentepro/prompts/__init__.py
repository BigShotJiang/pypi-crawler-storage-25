# -*- coding: utf-8 -*-
"""Prompts module for AtendentePro library.

Prompt builders return canonical prompt text (Portuguese, structured with
``[SECTION]`` markers). Adaptation to provider-specific dialects happens at
the agent factory boundary (see :mod:`atendentepro.agents._factory`) so the
transformation is applied once to the fully composed instructions.

For manual usage, ``apply_dialect`` and ``resolve_dialect`` are re-exported.
"""

from .answer import AnswerPromptBuilder, get_answer_prompt
from .confirmation import ConfirmationPromptBuilder, get_confirmation_prompt
from .dialect import apply_dialect, resolve_dialect
from .escalation import ESCALATION_INTRO, EscalationPromptBuilder, get_escalation_prompt
from .feedback import FEEDBACK_INTRO, FeedbackPromptBuilder, get_feedback_prompt
from .flow import FlowPromptBuilder, get_flow_prompt
from .interview import InterviewPromptBuilder, get_interview_prompt
from .knowledge import KnowledgePromptBuilder, get_knowledge_prompt
from .onboarding import OnboardingPromptBuilder, get_onboarding_prompt
from .triage import TRIAGE_INTRO, get_triage_prompt
from .usage import UsagePromptBuilder, get_usage_prompt

__all__ = [
    # Triage
    "get_triage_prompt",
    "TRIAGE_INTRO",
    # Flow
    "get_flow_prompt",
    "FlowPromptBuilder",
    # Interview
    "get_interview_prompt",
    "InterviewPromptBuilder",
    # Answer
    "get_answer_prompt",
    "AnswerPromptBuilder",
    # Knowledge
    "get_knowledge_prompt",
    "KnowledgePromptBuilder",
    # Confirmation
    "get_confirmation_prompt",
    "ConfirmationPromptBuilder",
    # Onboarding
    "get_onboarding_prompt",
    "OnboardingPromptBuilder",
    # Escalation
    "get_escalation_prompt",
    "EscalationPromptBuilder",
    "ESCALATION_INTRO",
    # Feedback
    "get_feedback_prompt",
    "FeedbackPromptBuilder",
    "FEEDBACK_INTRO",
    # Usage
    "get_usage_prompt",
    "UsagePromptBuilder",
    # Dialect adapter (advanced usage)
    "apply_dialect",
    "resolve_dialect",
]
