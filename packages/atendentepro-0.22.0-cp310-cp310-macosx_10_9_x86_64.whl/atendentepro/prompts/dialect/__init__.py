# -*- coding: utf-8 -*-
"""Provider-specific prompt dialect adapter.

Rule-based transformation layer that translates canonical prompt text to
the preferred dialect of the target model family (Claude XML tags, Gemini
markdown headers, Grok imperative, Llama instruct-style). GPT stays as
passthrough.

Public API:
    resolve_dialect(provider, model) -> str
    apply_dialect(text, dialect) -> str
    KNOWN_DIALECTS: set of supported dialect names
"""

from __future__ import annotations

from atendentepro.prompts.dialect.registry import DIALECT_REGISTRY, resolve_dialect
from atendentepro.prompts.dialect.transforms import (
    KNOWN_DIALECTS,
    apply_claude,
    apply_dialect,
    apply_gemini,
    apply_grok,
    apply_llama,
)

__all__ = [
    "resolve_dialect",
    "apply_dialect",
    "apply_claude",
    "apply_gemini",
    "apply_grok",
    "apply_llama",
    "KNOWN_DIALECTS",
    "DIALECT_REGISTRY",
]
