# -*- coding: utf-8 -*-
"""CLI provider aliases — maps user-friendly --provider names to configure() kwargs.

Issue #65: expose existing provider adapters in the CLI so users can run
``atendentepro test --provider gemini`` instead of having to assemble a
``--provider custom`` invocation by hand. OpenAI-compatible providers are
routed through ``provider="custom"`` with the appropriate ``custom_base_url``
and ``custom_api_key`` resolved from a provider-specific env var.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from atendentepro.config.settings import KNOWN_PROVIDERS


@dataclass(frozen=True)
class ProviderAlias:
    """User-facing CLI provider name mapped to configure() kwargs."""

    name: str
    config_provider: str  # one of "openai", "azure", "custom"
    env_vars: tuple  # ordered list of env vars to try for the API key
    base_url: Optional[str] = None  # applied when config_provider == "custom"


# Canonical native providers (config Literal accepts these).
_NATIVE: List[ProviderAlias] = [
    ProviderAlias(name="openai", config_provider="openai", env_vars=("OPENAI_API_KEY",)),
    ProviderAlias(name="azure", config_provider="azure", env_vars=("AZURE_API_KEY",)),
    ProviderAlias(
        name="custom",
        config_provider="custom",
        env_vars=("CUSTOM_API_KEY",),
    ),
]

# OpenAI-compatible providers — routed through "custom" with base_url.
# For providers tracked in KNOWN_PROVIDERS, the URL is resolved at call
# time so a single source of truth governs base_url.
_COMPAT: List[ProviderAlias] = [
    ProviderAlias(
        name="gemini",
        config_provider="custom",
        env_vars=("GEMINI_API_KEY", "GOOGLE_API_KEY"),
    ),
    ProviderAlias(
        name="deepseek",
        config_provider="custom",
        env_vars=("DEEPSEEK_API_KEY",),
    ),
    ProviderAlias(
        name="anthropic",
        config_provider="custom",
        env_vars=("ANTHROPIC_API_KEY",),
    ),
    # Grok is not yet in KNOWN_PROVIDERS on main (tracked by PR #63);
    # carry the base_url here so the CLI works regardless of merge order.
    ProviderAlias(
        name="grok",
        config_provider="custom",
        env_vars=("XAI_API_KEY", "GROK_API_KEY"),
        base_url="https://api.x.ai/v1",
    ),
]

CLI_PROVIDER_ALIASES: Dict[str, ProviderAlias] = {alias.name: alias for alias in _NATIVE + _COMPAT}


def supported_provider_names() -> List[str]:
    """Stable, ordered list of CLI provider names for help text."""
    return [a.name for a in _NATIVE + _COMPAT]


def resolve_api_key(alias: ProviderAlias, explicit: Optional[str]) -> Optional[str]:
    """Resolve the API key from explicit flag or env vars (first non-empty wins)."""
    if explicit:
        return explicit
    for var in alias.env_vars:
        value = os.environ.get(var)
        if value:
            return value
    return None


def build_configure_kwargs(
    provider_name: str,
    api_key: Optional[str],
    model: str,
) -> Dict[str, Any]:
    """Build configure() kwargs for a CLI ``--provider`` choice.

    Raises:
        KeyError: when ``provider_name`` is not a known CLI alias.
    """
    alias = CLI_PROVIDER_ALIASES[provider_name]
    kwargs: Dict[str, Any] = {
        "provider": alias.config_provider,
        "default_model": model,
    }

    if alias.config_provider == "openai":
        kwargs["openai_api_key"] = api_key
    elif alias.config_provider == "azure":
        kwargs["azure_api_key"] = api_key
    else:  # custom
        kwargs["custom_api_key"] = api_key
        base_url = alias.base_url
        if base_url is None and alias.name in KNOWN_PROVIDERS:
            base_url = KNOWN_PROVIDERS[alias.name].get("base_url")
        if base_url:
            kwargs["custom_base_url"] = base_url

    return kwargs


def expected_env_vars(provider_name: str) -> tuple:
    """Return env vars consulted for ``provider_name``. Empty if unknown."""
    alias = CLI_PROVIDER_ALIASES.get(provider_name)
    return alias.env_vars if alias else ()
