# -*- coding: utf-8 -*-
"""CLI command: atendentepro test."""

from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import Any, Dict, Optional

import typer

from atendentepro.cli._providers import (
    CLI_PROVIDER_ALIASES,
    build_configure_kwargs,
    expected_env_vars,
    resolve_api_key,
    supported_provider_names,
)
from atendentepro.cli.output import print_error, print_success
from atendentepro.cli.validate_cmd import _validate_client_dir


def _run_test(
    templates_root: Path,
    client: str,
    message: str,
    provider: str,
    api_key: str,
    model: str,
    license_key: str,
    dialect: Optional[str] = None,
    optim_mode: Optional[str] = None,
) -> Dict[str, Any]:
    """Run a test message through the agent network. Returns result dict.

    ``dialect`` / ``optim_mode`` override the corresponding config
    fields when set; ``None`` keeps whatever the environment provides.
    """
    from atendentepro import activate, configure, create_standard_network

    activate(token=license_key, silent=True)

    configure_kwargs: Dict[str, Any] = build_configure_kwargs(
        provider_name=provider,
        api_key=api_key,
        model=model,
    )

    # Dialect/optim overrides (dominant case: user passes nothing and
    # config defaults kick in). ``dialect="auto"`` is treated as "use
    # registry", so we pass None to let the registry resolve from
    # (provider, model) at agent-build time.
    if dialect and dialect.lower() != "auto":
        configure_kwargs["prompt_dialect"] = dialect.lower()
    if optim_mode:
        configure_kwargs["prompt_optim_mode"] = optim_mode.lower()

    configure(**configure_kwargs)

    network = create_standard_network(
        templates_root=templates_root,
        client=client,
    )

    from agents import Runner

    async def _run() -> Any:
        return await Runner.run(
            network.triage,
            input=message,
        )

    result = asyncio.run(_run())

    # Build trace from agent handoffs
    trace: list[str] = []
    for item in getattr(result, "raw_responses", []):
        agent_name = getattr(item, "agent_name", None)
        if agent_name and (not trace or trace[-1] != agent_name):
            trace.append(agent_name)

    final_agent = getattr(result, "last_agent", None)
    agent_name = getattr(final_agent, "name", "unknown") if final_agent else "unknown"

    return {
        "response": result.final_output or "",
        "agent": agent_name,
        "trace": trace or [agent_name],
    }


def test_client(
    client: str = typer.Argument(..., help="Client name to test."),
    message: str = typer.Argument(..., help="Test message to send."),
    templates_root: Path = typer.Option(
        Path("./client_templates"), help="Root directory for templates."
    ),
    provider: str = typer.Option(
        "openai",
        help=(
            "LLM provider. Options: " + ", ".join(supported_provider_names()) + ". "
            "Native (openai/azure/custom) and OpenAI-compatible (gemini/grok/deepseek/anthropic) "
            "are accepted; the latter are routed through the custom adapter with the right base_url "
            "and a provider-specific API key env var."
        ),
    ),
    api_key: Optional[str] = typer.Option(None, "--api-key", help="API key for the provider."),
    model: str = typer.Option("gpt-4.1-mini", help="Model name."),
    license_key: Optional[str] = typer.Option(
        None, "--license-key", help="AtendentePro license key."
    ),
    dialect: Optional[str] = typer.Option(
        None,
        "--dialect",
        help=(
            "Override prompt dialect for this run. One of: "
            "auto | gpt | claude | gemini | grok | llama. "
            "'auto' (default when unset) lets the registry pick from (provider, model)."
        ),
    ),
    optim_mode: Optional[str] = typer.Option(
        None,
        "--optim-mode",
        help=(
            "Override prompt_optim_mode for this run. One of: off | fallback | force. "
            "See atendentepro optim-cache list to inspect existing cache entries."
        ),
    ),
) -> None:
    """Send a test message to the agent network and return the response."""
    client_dir = templates_root / client

    if not client_dir.is_dir():
        print_error(f"Client not found: {client_dir}", code="CLIENT_NOT_FOUND")

    # Run validation before testing
    val_errors, val_warnings, _ = _validate_client_dir(client_dir)
    if val_errors:
        print_error(
            f"Validation failed with {len(val_errors)} error(s)",
            code="VALIDATION_ERROR",
            errors=val_errors,
            warnings=val_warnings,
        )

    # Validate provider choice up-front (clean error vs cryptic configure failure).
    if provider not in CLI_PROVIDER_ALIASES:
        print_error(
            f"--provider={provider!r} is not one of {supported_provider_names()}",
            code="VALIDATION_ERROR",
        )

    # Resolve API key from flag or environment (provider-specific env vars).
    resolved_key = resolve_api_key(CLI_PROVIDER_ALIASES[provider], api_key)
    if not resolved_key:
        env_hint = "/".join(expected_env_vars(provider)) or "API key env var"
        print_error(
            f"API key required for provider={provider!r}. Use --api-key or set {env_hint}.",
            code="API_ERROR",
        )

    resolved_license = license_key or os.environ.get("ATENDENTEPRO_LICENSE_KEY", "")

    # Validate dialect/optim flags BEFORE running so the user gets a
    # clean error instead of a silent passthrough on typo.
    if dialect:
        from atendentepro.prompts.dialect.transforms import KNOWN_DIALECTS

        allowed = KNOWN_DIALECTS | {"auto"}
        if dialect.lower() not in allowed:
            print_error(
                f"--dialect={dialect!r} is not one of {sorted(allowed)}",
                code="VALIDATION_ERROR",
            )
    if optim_mode and optim_mode.lower() not in ("off", "fallback", "force"):
        print_error(
            f"--optim-mode={optim_mode!r} is not one of off/fallback/force",
            code="VALIDATION_ERROR",
        )

    try:
        result = _run_test(
            templates_root=templates_root,
            client=client,
            message=message,
            provider=provider,
            api_key=resolved_key,
            model=model,
            license_key=resolved_license,
            dialect=dialect,
            optim_mode=optim_mode,
        )
    except Exception as exc:
        print_error(f"Test failed: {exc}", code="API_ERROR")

    print_success(**result)
