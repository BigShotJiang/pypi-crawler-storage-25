# -*- coding: utf-8 -*-
"""CLI commands: ``atendentepro optim-cache`` (list / show / clear).

Inspection and maintenance of the on-disk optim cache. These commands
do not require ``dspy-ai`` or any other optimizer — the cache is a
pure in/out store.
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterator, Optional, Tuple

import typer

from atendentepro.cli.output import print_error, print_success

optim_cache_app = typer.Typer(
    name="optim-cache",
    help="Inspect / clear the AtendentePro optim prompt cache.",
    no_args_is_help=True,
)


@optim_cache_app.callback()
def _optim_cache_callback() -> None:
    """Placeholder callback so Typer preserves subcommand routing."""


def _cache(cache_dir: Optional[Path]) -> object:
    """Build an OptimCache honoring the --cache-dir override when given."""
    from atendentepro.optim import OptimCache
    from atendentepro.optim.cache import _default_cache_dir

    return OptimCache(cache_dir=cache_dir or _default_cache_dir())


def _iter_entries(cache_dir: Path) -> Iterator[Tuple[str, str, Path]]:
    """Yield (hash, model, json_path) tuples for every cache entry on disk.

    Cache layout: ``{cache_dir}/{hash[:2]}/{hash}/{model}.json``.
    """
    if not cache_dir.exists():
        return
    for hash_prefix_dir in sorted(cache_dir.iterdir()):
        if not hash_prefix_dir.is_dir():
            continue
        for hash_dir in sorted(hash_prefix_dir.iterdir()):
            if not hash_dir.is_dir():
                continue
            hash_value = hash_dir.name
            for json_path in sorted(hash_dir.glob("*.json")):
                yield hash_value, json_path.stem, json_path


@optim_cache_app.command("list")
def list_entries(
    cache_dir: Optional[Path] = typer.Option(
        None,
        "--cache-dir",
        help="Override ATENDENTEPRO_OPTIM_CACHE_DIR for this invocation.",
    ),
    hash_filter: Optional[str] = typer.Option(
        None,
        "--hash",
        help="Filter output to a single canonical-prompt hash prefix.",
    ),
) -> None:
    """List every cached optimized prompt on disk."""
    import json

    from atendentepro.optim.cache import _default_cache_dir

    root = cache_dir or _default_cache_dir()
    entries: list[dict] = []
    for hash_value, model, json_path in _iter_entries(root):
        if hash_filter and not hash_value.startswith(hash_filter):
            continue
        try:
            payload = json.loads(json_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            payload = {}
        metadata = payload.get("metadata") or {}
        entries.append(
            {
                "hash": hash_value,
                "model": model,
                "optimizer": metadata.get("optimizer"),
                "compile_seconds": metadata.get("compile_seconds"),
                "timestamp": metadata.get("timestamp"),
                "path": str(json_path),
                "size_bytes": json_path.stat().st_size,
            }
        )
    print_success(cache_dir=str(root), count=len(entries), entries=entries)


@optim_cache_app.command("show")
def show_entry(
    hash_value: str = typer.Argument(..., help="Canonical-prompt hash (or prefix)."),
    model: str = typer.Argument(..., help="Model name (e.g. gpt-4.1)."),
    cache_dir: Optional[Path] = typer.Option(
        None,
        "--cache-dir",
        help="Override ATENDENTEPRO_OPTIM_CACHE_DIR for this invocation.",
    ),
) -> None:
    """Print the full optimized prompt text + metadata for one entry."""
    cache = _cache(cache_dir)
    entry = cache.read(hash_value, model)  # type: ignore[attr-defined]
    if entry is None:
        models_for_hash = cache.list_models(hash_value)  # type: ignore[attr-defined]
        print_error(
            f"No cache entry for (hash={hash_value!r}, model={model!r}).",
            code="CACHE_MISS",
            cached_models=models_for_hash or [],
        )
    print_success(**entry)


@optim_cache_app.command("clear")
def clear_entries(
    hash_value: Optional[str] = typer.Argument(
        None, help="Canonical-prompt hash. Required unless --all is passed."
    ),
    model: Optional[str] = typer.Option(
        None,
        "--model",
        help="When given with <hash>, delete only that model. Otherwise all models for the hash.",
    ),
    all_entries: bool = typer.Option(
        False,
        "--all",
        help="Delete EVERY cache entry (requires --confirm).",
    ),
    confirm: bool = typer.Option(
        False,
        "--confirm",
        help="Required when using --all. Mechanical safety check.",
    ),
    cache_dir: Optional[Path] = typer.Option(
        None,
        "--cache-dir",
        help="Override ATENDENTEPRO_OPTIM_CACHE_DIR for this invocation.",
    ),
) -> None:
    """Delete cache entries. Scoped by hash, hash+model, or --all."""
    import shutil

    from atendentepro.optim.cache import _default_cache_dir

    root = cache_dir or _default_cache_dir()

    if all_entries:
        if not confirm:
            print_error(
                "--all requires --confirm to avoid accidental wipe.",
                code="CONFIRM_REQUIRED",
            )
        removed = 0
        for _h, _m, json_path in _iter_entries(root):
            json_path.unlink(missing_ok=True)  # type: ignore[call-arg]
            removed += 1
        # Also drop empty prefix directories for cleanliness.
        if root.exists():
            for hash_prefix_dir in list(root.iterdir()):
                if hash_prefix_dir.is_dir():
                    try:
                        shutil.rmtree(hash_prefix_dir)
                    except OSError:
                        pass
        print_success(cleared="all", removed=removed, cache_dir=str(root))
        return  # print_success returns; without this we'd fall through

    if not hash_value:
        print_error(
            "Either provide <hash> or pass --all --confirm.",
            code="VALIDATION_ERROR",
        )

    cache = _cache(cache_dir)
    if model:
        deleted = cache.delete(hash_value, model)  # type: ignore[attr-defined]
        if not deleted:
            print_error(
                f"No entry for (hash={hash_value!r}, model={model!r}).",
                code="CACHE_MISS",
            )
        print_success(cleared="entry", hash=hash_value, model=model)
        return

    # Full hash: delete every model for this hash.
    hash_dir = root / hash_value[:2] / hash_value
    if not hash_dir.exists():
        print_error(
            f"No entries for hash={hash_value!r}.",
            code="CACHE_MISS",
        )
    removed = sum(1 for _ in hash_dir.glob("*.json"))
    shutil.rmtree(hash_dir)
    # Best-effort: drop the prefix dir if empty.
    try:
        hash_dir.parent.rmdir()
    except OSError:
        pass
    print_success(cleared="hash", hash=hash_value, removed=removed)
