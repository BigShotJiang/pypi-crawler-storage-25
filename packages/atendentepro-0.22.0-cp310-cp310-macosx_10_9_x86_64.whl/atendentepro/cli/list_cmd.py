# -*- coding: utf-8 -*-
"""CLI command: atendentepro list."""

from __future__ import annotations

from pathlib import Path

import typer

from atendentepro.cli.output import print_error, print_success

_EMBEDDING_EXTENSIONS = {".npz", ".pkl", ".npy"}


def list_clients(
    templates_root: Path = typer.Option(
        Path("./client_templates"), help="Root directory for templates."
    ),
) -> None:
    """List existing client templates."""
    if not templates_root.is_dir():
        print_error(
            f"Templates root not found: {templates_root}",
            code="CLIENT_NOT_FOUND",
        )

    clients = []
    for entry in sorted(templates_root.iterdir()):
        if not entry.is_dir() or entry.name.startswith("."):
            continue

        yaml_files = list(entry.glob("*.yaml")) + list(entry.glob("*.yml"))
        has_embeddings = any(
            f.suffix in _EMBEDDING_EXTENSIONS for f in entry.rglob("*") if f.is_file()
        )

        clients.append(
            {
                "name": entry.name,
                "files": len(yaml_files),
                "has_embeddings": has_embeddings,
            }
        )

    print_success(clients=clients)
