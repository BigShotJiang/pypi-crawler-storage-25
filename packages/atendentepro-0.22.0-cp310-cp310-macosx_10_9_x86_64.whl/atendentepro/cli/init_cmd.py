# -*- coding: utf-8 -*-
"""CLI command: atendentepro init."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional

import typer
import yaml

from atendentepro.cli.output import print_error, print_success

# Keys in the unified YAML that map to *_config.yaml files
_CONFIG_KEYS = (
    "triage",
    "flow",
    "interview",
    "knowledge",
    "confirmation",
    "style",
    "guardrails",
    "answer",
    "usage",
    "onboarding",
    "escalation",
    "feedback",
)

_DEFAULT_TRIAGE: dict = {"keywords": {}}


def _write_yaml(path: Path, data: dict) -> None:
    """Write a dict to a YAML file."""
    path.write_text(
        yaml.dump(data, default_flow_style=False, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )


def _parse_json_option(value: Optional[str], name: str) -> Optional[dict]:
    """Parse a JSON string option, returning None if empty."""
    if not value:
        return None
    try:
        return json.loads(value)
    except json.JSONDecodeError as e:
        print_error(f"Invalid JSON for --{name}: {e}", code="YAML_PARSE_ERROR")
        return None  # unreachable (print_error raises SystemExit), but keeps mypy happy


def init_client(
    client: str = typer.Argument(..., help="Client name (used as directory name)."),
    templates_root: Path = typer.Option(
        Path("./client_templates"), help="Root directory for templates."
    ),
    from_yaml: Optional[Path] = typer.Option(
        None, "--from-yaml", help="Path to unified YAML config file."
    ),
    triage: Optional[str] = typer.Option(None, help="Triage config as JSON."),
    flow: Optional[str] = typer.Option(None, help="Flow config as JSON."),
    interview: Optional[str] = typer.Option(None, help="Interview config as JSON."),
    knowledge: Optional[str] = typer.Option(None, help="Knowledge config as JSON."),
    confirmation: Optional[str] = typer.Option(None, help="Confirmation config as JSON."),
    style: Optional[str] = typer.Option(None, help="Style config as JSON."),
    guardrails: Optional[str] = typer.Option(None, help="Guardrails config as JSON."),
    answer: Optional[str] = typer.Option(None, help="Answer config as JSON."),
    usage: Optional[str] = typer.Option(None, help="Usage config as JSON."),
    onboarding: Optional[str] = typer.Option(None, help="Onboarding config as JSON."),
    escalation: Optional[str] = typer.Option(None, help="Escalation config as JSON."),
    feedback: Optional[str] = typer.Option(None, help="Feedback config as JSON."),
    agents: Optional[str] = typer.Option(None, help="Agent inclusion flags as JSON."),
    overwrite: bool = typer.Option(False, help="Overwrite existing client directory."),
) -> None:
    """Create a new client template with YAML configuration files."""
    client_dir = templates_root / client

    if client_dir.exists() and not overwrite:
        print_error(
            f"Client directory already exists: {client_dir}. Use --overwrite to replace.",
            code="CLIENT_EXISTS",
        )

    # Collect configs from unified YAML or individual flags
    configs: Dict[str, dict] = {}

    if from_yaml:
        if not from_yaml.exists():
            print_error(f"YAML file not found: {from_yaml}", code="YAML_PARSE_ERROR")
        try:
            data = yaml.safe_load(from_yaml.read_text(encoding="utf-8")) or {}
        except yaml.YAMLError as e:
            print_error(f"Invalid YAML: {e}", code="YAML_PARSE_ERROR")
            return  # unreachable (print_error raises SystemExit), but keeps mypy happy

        for key in _CONFIG_KEYS:
            if key in data:
                configs[key] = data[key]

        if "agents" in data:
            configs["agents"] = data["agents"]
    else:
        # Parse individual JSON flags
        flag_map = {
            "triage": triage,
            "flow": flow,
            "interview": interview,
            "knowledge": knowledge,
            "confirmation": confirmation,
            "style": style,
            "guardrails": guardrails,
            "answer": answer,
            "usage": usage,
            "onboarding": onboarding,
            "escalation": escalation,
            "feedback": feedback,
            "agents": agents,
        }
        for name, value in flag_map.items():
            parsed = _parse_json_option(value, name)
            if parsed is not None:
                configs[name] = parsed

    # Ensure triage always exists
    if "triage" not in configs:
        configs["triage"] = _DEFAULT_TRIAGE

    # Write files
    client_dir.mkdir(parents=True, exist_ok=True)

    written_files = []
    for key, data in configs.items():
        filename = f"{key}_config.yaml"
        _write_yaml(client_dir / filename, data)
        written_files.append(filename)

    print_success(
        client=client,
        path=str(client_dir),
        files=sorted(written_files),
    )
