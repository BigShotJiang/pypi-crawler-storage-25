# -*- coding: utf-8 -*-
"""JSON output helpers for the AtendentePro CLI."""

from __future__ import annotations

import json
from typing import Any, NoReturn, Optional


def format_success(**kwargs: Any) -> str:
    """Format a success response as JSON string."""
    data = {"status": "ok", **kwargs}
    return json.dumps(data, ensure_ascii=False, indent=2)


def format_error(message: str, code: Optional[str] = None, **kwargs: Any) -> str:
    """Format an error response as JSON string."""
    data: dict[str, Any] = {"status": "error"}
    if code:
        data["code"] = code
    data["message"] = message
    data.update(kwargs)
    return json.dumps(data, ensure_ascii=False, indent=2)


def print_success(**kwargs: Any) -> None:
    """Print a success JSON response to stdout."""
    print(format_success(**kwargs))


def print_error(message: str, code: Optional[str] = None, **kwargs: Any) -> NoReturn:
    """Print an error JSON response to stdout and exit with code 1."""
    print(format_error(message, code=code, **kwargs))
    raise SystemExit(1)
