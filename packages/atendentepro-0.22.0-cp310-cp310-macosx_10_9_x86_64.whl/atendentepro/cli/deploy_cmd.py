# -*- coding: utf-8 -*-
"""CLI command: atendentepro deploy."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional

import typer

from atendentepro.cli.output import print_error, print_success
from atendentepro.cli.validate_cmd import _validate_client_dir


def _post_setup(server: str, tenant_id: str, yamls: Dict[str, str]) -> Dict[str, Any]:
    """Send POST /setup to the AtendentePro server."""
    import httpx

    url = f"{server.rstrip('/')}/setup"
    payload = {
        "tenant_id": tenant_id,
        "yamls": yamls,
    }

    response = httpx.post(url, json=payload, timeout=30.0)
    response.raise_for_status()
    return response.json()


def deploy_client(
    client: str = typer.Argument(..., help="Client name to deploy."),
    templates_root: Path = typer.Option(
        Path("./client_templates"), help="Root directory for templates."
    ),
    server: str = typer.Option(..., help="Server base URL (e.g., http://localhost:8000)."),
    tenant_id: Optional[str] = typer.Option(
        None, "--tenant-id", help="Tenant ID on the server (defaults to client name)."
    ),
) -> None:
    """Deploy client configuration to an AtendentePro server."""
    client_dir = templates_root / client

    if not client_dir.is_dir():
        print_error(f"Client not found: {client_dir}", code="CLIENT_NOT_FOUND")

    # Run validation before deploying
    val_errors, val_warnings, _ = _validate_client_dir(client_dir)
    if val_errors:
        print_error(
            f"Validation failed with {len(val_errors)} error(s)",
            code="VALIDATION_ERROR",
            errors=val_errors,
            warnings=val_warnings,
        )

    resolved_tenant = tenant_id or client

    # Read all YAML files
    yamls: Dict[str, str] = {}
    for yaml_file in sorted(client_dir.glob("*.yaml")) + sorted(client_dir.glob("*.yml")):
        config_name = yaml_file.stem  # e.g., "triage_config"
        yamls[config_name] = yaml_file.read_text(encoding="utf-8")

    if not yamls:
        print_error(
            f"No YAML files found in {client_dir}",
            code="VALIDATION_ERROR",
        )

    try:
        _post_setup(server, resolved_tenant, yamls)
    except Exception as exc:
        print_error(f"Deploy failed: {exc}", code="API_ERROR")

    print_success(
        tenant_id=resolved_tenant,
        server=server,
    )
