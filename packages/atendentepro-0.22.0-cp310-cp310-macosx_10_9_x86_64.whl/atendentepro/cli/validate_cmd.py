# -*- coding: utf-8 -*-
"""CLI command: atendentepro validate."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List, Tuple

import typer
import yaml

from atendentepro.cli.output import print_error, print_success

_VALID_AGENTS = {
    "triage",
    "flow",
    "interview",
    "answer",
    "knowledge",
    "confirmation",
    "usage",
    "onboarding",
    "escalation",
    "feedback",
}

_VALID_LANGUAGE_STYLES = {"formal", "informal", "neutro"}
_VALID_RESPONSE_LENGTHS = {"conciso", "moderado", "detalhado"}


def _load_yaml(path: Path) -> Dict[str, Any]:
    """Load and parse a YAML file."""
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def _validate_triage(data: Dict[str, Any], warnings: List[str], errors: List[str]) -> None:
    """Validate triage_config.yaml contents."""
    keywords = data.get("keywords", {})
    if not isinstance(keywords, dict):
        errors.append("triage_config.yaml: 'keywords' must be a mapping")
        return
    for agent_name in keywords:
        if agent_name not in _VALID_AGENTS:
            warnings.append(f"triage_config.yaml: keyword references unknown agent '{agent_name}'")


def _validate_flow(data: Dict[str, Any], warnings: List[str], errors: List[str]) -> None:
    """Validate flow_config.yaml contents."""
    for i, topic in enumerate(data.get("topics", [])):
        if not isinstance(topic, dict):
            errors.append(f"flow_config.yaml: topic[{i}] is not a mapping")
            continue
        if "id" not in topic:
            warnings.append(f"flow_config.yaml: topic[{i}] missing 'id' field")
        if "label" not in topic:
            warnings.append(f"flow_config.yaml: topic[{i}] missing 'label' field")


def _validate_knowledge(data: Dict[str, Any], client_dir: Path, warnings: List[str]) -> None:
    """Validate knowledge_config.yaml contents."""
    emb_path = data.get("embeddings_path")
    if emb_path:
        resolved = (client_dir / emb_path).resolve()
        if not resolved.exists():
            warnings.append(
                f"knowledge_config.yaml: embeddings_path not found ({emb_path}), "
                "RAG will be disabled"
            )


def _validate_guardrails(data: Dict[str, Any], warnings: List[str]) -> None:
    """Validate guardrails_config.yaml contents."""
    blocked_patterns = data.get("blocked_patterns")
    if not blocked_patterns:
        return
    if not isinstance(blocked_patterns, list):
        warnings.append("guardrails_config.yaml: 'blocked_patterns' must be a list")
        return
    for pattern in blocked_patterns:
        try:
            re.compile(pattern)
        except re.error as exc:
            warnings.append(
                f"guardrails_config.yaml: blocked_patterns contains invalid regex"
                f" '{pattern}': {exc}"
            )


def _validate_style(data: Dict[str, Any], warnings: List[str]) -> None:
    """Validate style_config.yaml contents."""
    global_style = data.get("global", {})
    if not isinstance(global_style, dict):
        return

    lang = global_style.get("language_style", "")
    if lang and lang.lower() not in _VALID_LANGUAGE_STYLES:
        warnings.append(
            f"style_config.yaml: language_style '{lang}' is not one of "
            f"{sorted(_VALID_LANGUAGE_STYLES)}"
        )

    resp = global_style.get("response_length", "")
    if resp and resp.lower() not in _VALID_RESPONSE_LENGTHS:
        warnings.append(
            f"style_config.yaml: response_length '{resp}' is not one of "
            f"{sorted(_VALID_RESPONSE_LENGTHS)}"
        )


def _validate_client_dir(
    client_dir: Path,
) -> Tuple[List[str], List[str], List[str]]:
    """Run all validation checks on a client directory.

    Returns (errors, warnings, yaml_parse_errors). Does not raise or call
    print_error — callers decide how to surface results.
    """
    warnings: List[str] = []
    errors: List[str] = []
    yaml_parse_errors: List[str] = []

    # Check 1: triage_config.yaml exists (mandatory)
    triage_path = client_dir / "triage_config.yaml"
    if not triage_path.exists():
        errors.append("triage_config.yaml: missing required file")

    # Validate each YAML file
    yaml_files = sorted(client_dir.glob("*.yaml")) + sorted(client_dir.glob("*.yml"))

    for yaml_file in yaml_files:
        try:
            data = _load_yaml(yaml_file)
        except (yaml.YAMLError, UnicodeDecodeError) as e:
            msg = f"{yaml_file.name}: {e}"
            errors.append(msg)
            yaml_parse_errors.append(msg)
            continue

        name = yaml_file.stem  # e.g. "triage_config"

        if name == "triage_config":
            _validate_triage(data, warnings, errors)
        elif name == "flow_config":
            _validate_flow(data, warnings, errors)
        elif name == "knowledge_config":
            _validate_knowledge(data, client_dir, warnings)
        elif name == "style_config":
            _validate_style(data, warnings)
        elif name == "guardrails_config":
            _validate_guardrails(data, warnings)

    return errors, warnings, yaml_parse_errors


def validate_client(
    client: str = typer.Argument(..., help="Client name to validate."),
    templates_root: Path = typer.Option(
        Path("./client_templates"), help="Root directory for templates."
    ),
) -> None:
    """Validate YAML configuration for a client."""
    client_dir = templates_root / client

    if not client_dir.is_dir():
        print_error(
            f"Client not found: {client_dir}",
            code="CLIENT_NOT_FOUND",
        )

    errors, warnings, yaml_parse_errors = _validate_client_dir(client_dir)

    # Count checks: 1 for triage existence + 1 per YAML file
    yaml_files = sorted(client_dir.glob("*.yaml")) + sorted(client_dir.glob("*.yml"))
    checks = 1 + len(yaml_files)

    if errors:
        # Surface YAML parse errors with a dedicated code when that is the sole cause
        if yaml_parse_errors and len(errors) == len(yaml_parse_errors):
            print_error(
                f"Invalid YAML: {yaml_parse_errors[0]}",
                code="YAML_PARSE_ERROR",
                errors=errors,
                warnings=warnings,
            )
        print_error(
            f"Validation failed with {len(errors)} error(s)",
            code="VALIDATION_ERROR",
            errors=errors,
            warnings=warnings,
        )

    print_success(
        client=client,
        checks=checks,
        passed=checks - len(errors),
        warnings=warnings,
        errors=errors,
    )
