# -*- coding: utf-8 -*-
"""CLI command: ``atendentepro dialect preview`` — show a prompt
rendered in every dialect side-by-side for visual inspection.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer

from atendentepro.cli.output import print_error, print_success

dialect_app = typer.Typer(
    name="dialect",
    help="Inspect / preview dialect adapter output.",
    no_args_is_help=True,
)


@dialect_app.callback()
def _dialect_callback() -> None:
    """Placeholder callback so Typer preserves subcommand routing
    even when only one command is registered under this sub-app.
    Without it, ``dialect_app`` with a single command would be
    auto-promoted, breaking ``atendentepro dialect preview ...``."""


_AGENT_PROMPT_BUILDERS = {
    "triage": "get_triage_prompt",
    "flow": "get_flow_prompt",
    "interview": "get_interview_prompt",
    "answer": "get_answer_prompt",
    "knowledge": "get_knowledge_prompt",
    "confirmation": "get_confirmation_prompt",
    "usage": "get_usage_prompt",
    "onboarding": "get_onboarding_prompt",
    "escalation": "get_escalation_prompt",
    "feedback": "get_feedback_prompt",
}


def _canonical_prompt_for_agent(agent_name: str) -> str:
    """Call the matching ``get_*_prompt`` builder with defaults.

    Returns the canonical text BEFORE any dialect transform. Templates
    are intentionally not loaded — the goal is to compare dialects on
    a consistent baseline.
    """
    builder_name = _AGENT_PROMPT_BUILDERS.get(agent_name)
    if builder_name is None:
        print_error(
            f"Unknown agent {agent_name!r}. Valid: {sorted(_AGENT_PROMPT_BUILDERS)}",
            code="VALIDATION_ERROR",
        )
    from atendentepro import prompts as atd_prompts

    builder = getattr(atd_prompts, builder_name)
    try:
        return builder()
    except TypeError:
        # Some builders require positional args with no reasonable
        # default; surface the issue rather than silently masking it.
        print_error(
            f"Builder {builder_name} requires arguments — preview without "
            "template customization is not supported for this agent yet.",
            code="VALIDATION_ERROR",
        )
        raise  # pragma: no cover - print_error raises SystemExit first


@dialect_app.command("preview")
def preview(
    agent: str = typer.Argument(
        ...,
        help=f"Agent to preview. One of: {', '.join(sorted(_AGENT_PROMPT_BUILDERS))}.",
    ),
    dialect: Optional[str] = typer.Option(
        None,
        "--dialect",
        help=(
            "Render only this dialect. Default: render ALL known "
            "dialects side-by-side (gpt/claude/gemini/grok/llama)."
        ),
    ),
    output: Optional[Path] = typer.Option(
        None,
        "--output",
        "-o",
        help="Write each dialect to a file under this directory instead of stdout.",
    ),
) -> None:
    """Render the canonical prompt of an agent in each dialect."""
    from atendentepro.prompts.dialect import apply_dialect
    from atendentepro.prompts.dialect.transforms import KNOWN_DIALECTS

    canonical = _canonical_prompt_for_agent(agent)

    if dialect:
        if dialect.lower() not in KNOWN_DIALECTS:
            print_error(
                f"--dialect={dialect!r} is not one of {sorted(KNOWN_DIALECTS)}",
                code="VALIDATION_ERROR",
            )
        dialects_to_render = [dialect.lower()]
    else:
        dialects_to_render = sorted(KNOWN_DIALECTS)

    rendered: dict = {}
    for dl in dialects_to_render:
        rendered[dl] = apply_dialect(canonical, dl)

    if output is not None:
        output.mkdir(parents=True, exist_ok=True)
        paths: dict = {}
        for dl, text in rendered.items():
            path = output / f"{agent}.{dl}.txt"
            path.write_text(text, encoding="utf-8")
            paths[dl] = str(path)
        print_success(
            agent=agent, files=paths, byte_counts={d: len(t) for d, t in rendered.items()}
        )
        return

    # Stdout case: keep the success envelope machine-readable but embed
    # full text so operators can eyeball differences.
    print_success(
        agent=agent,
        dialects=dialects_to_render,
        byte_counts={d: len(t) for d, t in rendered.items()},
        rendered=rendered,
    )
