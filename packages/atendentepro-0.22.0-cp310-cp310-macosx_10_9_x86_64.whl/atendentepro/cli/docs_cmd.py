# -*- coding: utf-8 -*-
"""CLI command: atendentepro docs.

Fetches the public documentation bundle from BeMonkAI/atendentepro-docs.
Designed to be piped into a clipboard or file so the user can hand the
entire guide to an AI assistant of their choice:

    atendentepro docs bundle | pbcopy
    atendentepro docs bundle > atendentepro-guide.md

The bundle is fetched from the git tag matching the installed version
(falls back to `main` when the tag is missing — useful for unreleased
local builds).
"""

from __future__ import annotations

import sys
import urllib.error
import urllib.request
import webbrowser

import typer

from atendentepro import __version__

REPO_URL = "https://github.com/BeMonkAI/atendentepro-docs"
RAW_BASE = "https://raw.githubusercontent.com/BeMonkAI/atendentepro-docs"

docs_app = typer.Typer(
    name="docs",
    help="Access AtendentePro documentation bundle (README + setup + examples).",
    no_args_is_help=True,
)


def _bundle_urls() -> list[str]:
    """URLs to try for the bundle, in priority order."""
    return [
        f"{RAW_BASE}/v{__version__}/llms-full.txt",
        f"{RAW_BASE}/main/llms-full.txt",
    ]


def _fetch(url: str, timeout: float = 15.0) -> str:
    req = urllib.request.Request(
        url, headers={"User-Agent": f"atendentepro-cli/{__version__}"}
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode("utf-8")


@docs_app.command("bundle")
def bundle() -> None:
    """Print the full documentation bundle (llms-full.txt) to stdout.

    Pipe into `pbcopy` (macOS), `xclip` (Linux), or redirect to a file
    to feed a single-paste prompt to your AI assistant.
    """
    last_error: str | None = None
    for url in _bundle_urls():
        try:
            content = _fetch(url)
        except urllib.error.HTTPError as exc:
            last_error = f"{exc.code} {exc.reason} — {url}"
            continue
        except urllib.error.URLError as exc:
            last_error = f"{exc.reason} — {url}"
            continue
        sys.stdout.write(content)
        if not content.endswith("\n"):
            sys.stdout.write("\n")
        return
    typer.echo(f"error: could not fetch docs bundle ({last_error})", err=True)
    raise typer.Exit(code=1)


@docs_app.command("url")
def url() -> None:
    """Print the public docs repo URL and useful direct links."""
    typer.echo(f"Repository: {REPO_URL}")
    typer.echo(f"Bundle (this version): {RAW_BASE}/v{__version__}/llms-full.txt")
    typer.echo(f"Bundle (latest):       {RAW_BASE}/main/llms-full.txt")
    typer.echo(f"Index:                 {RAW_BASE}/main/llms.txt")


@docs_app.command("open")
def open_in_browser() -> None:
    """Open the public docs repo in the default browser."""
    webbrowser.open(REPO_URL)
    typer.echo(f"Opened {REPO_URL}")
