# -*- coding: utf-8 -*-
"""AtendentePro CLI — Agent Builder for AI Assistants."""

from __future__ import annotations

import typer

app = typer.Typer(
    name="atendentepro",
    help="AtendentePro CLI — create, validate, test and deploy agent configurations.",
    add_completion=False,
    pretty_exceptions_enable=False,
    invoke_without_command=True,
)


@app.callback()
def _main(ctx: typer.Context) -> None:
    """AtendentePro CLI — create, validate, test and deploy agent configurations."""
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())


from atendentepro.cli.deploy_cmd import deploy_client
from atendentepro.cli.dialect_cmd import dialect_app
from atendentepro.cli.docs_cmd import docs_app
from atendentepro.cli.init_cmd import init_client
from atendentepro.cli.list_cmd import list_clients
from atendentepro.cli.optim_cache_cmd import optim_cache_app
from atendentepro.cli.test_cmd import test_client
from atendentepro.cli.validate_cmd import validate_client

app.command(name="list")(list_clients)
app.command(name="init")(init_client)
app.command(name="validate")(validate_client)
app.command(name="test")(test_client)
app.command(name="deploy")(deploy_client)
app.add_typer(optim_cache_app, name="optim-cache")
app.add_typer(dialect_app, name="dialect")
app.add_typer(docs_app, name="docs")

if __name__ == "__main__":
    app()
