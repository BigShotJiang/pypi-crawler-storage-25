# -*- coding: utf-8 -*-
"""
Tenant manager for the AtendentePro multi-tenant service.

Handles per-tenant AgentNetwork lifecycle and per-session conversation history.
"""

from __future__ import annotations

import asyncio
import importlib
import logging
import os
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


# ============================================================================
# CUSTOM NETWORK MODULE RESOLVER (issue #87)
# ============================================================================

# Allowlist prefix for ``network_type="custom_module"``. Modules outside
# this prefix cannot be imported via the YAML / kwargs path — protects
# against arbitrary code execution if a malicious YAML lands in the
# template tree (e.g. a compromised PR review). Override at deploy time
# via ``ATENDENTEPRO_NETWORK_MODULE_PREFIX`` (comma-separated list of
# allowed prefixes — set to ``"*"`` to disable the check, NOT recommended).
_NETWORK_MODULE_PREFIX_ENV = "ATENDENTEPRO_NETWORK_MODULE_PREFIX"
_DEFAULT_NETWORK_MODULE_PREFIX = "client_resources."


class NetworkModuleNotAllowedError(RuntimeError):
    """Raised when ``network_module`` does not match the allowlist prefix."""


def _allowed_network_module_prefixes() -> List[str]:
    """Return the active prefix allowlist (env override > default)."""
    raw = os.environ.get(_NETWORK_MODULE_PREFIX_ENV, "").strip()
    if not raw:
        return [_DEFAULT_NETWORK_MODULE_PREFIX]
    parts = [p.strip() for p in raw.split(",") if p.strip()]
    return parts or [_DEFAULT_NETWORK_MODULE_PREFIX]


def _is_module_allowed(module_path: str, prefixes: List[str]) -> bool:
    """``True`` when *module_path* matches any allowed prefix.

    The literal ``"*"`` disables the check entirely (escape hatch — caller
    explicitly accepts the risk).
    """
    if not module_path:
        return False
    if "*" in prefixes:
        return True
    return any(module_path == p.rstrip(".") or module_path.startswith(p) for p in prefixes)


def _resolve_custom_network_factory(
    module_path: str,
    factory_name: str,
) -> Callable[..., Any]:
    """Import *module_path* and return its *factory_name* callable.

    Enforces the allowlist prefix (issue #87). Raises a precise error
    message at the first failure so misconfiguration is obvious in logs.
    """
    if not module_path:
        raise NetworkModuleNotAllowedError(
            "network_module is required when network_type='custom_module'."
        )
    if not factory_name:
        raise NetworkModuleNotAllowedError(
            "network_factory is required when network_type='custom_module'."
        )

    prefixes = _allowed_network_module_prefixes()
    if not _is_module_allowed(module_path, prefixes):
        raise NetworkModuleNotAllowedError(
            f"network_module={module_path!r} is outside the allowlist prefixes "
            f"{prefixes!r}. Either move the module under an allowed prefix or "
            f"export {_NETWORK_MODULE_PREFIX_ENV} with a comma-separated list "
            f"of additional prefixes (use '*' to disable the check entirely — "
            f"NOT recommended)."
        )

    try:
        module = importlib.import_module(module_path)
    except ImportError as exc:
        raise ImportError(
            f"Could not import network_module={module_path!r}: {exc}. "
            f"Verify the module is on PYTHONPATH and the spelling is correct."
        ) from exc

    factory = getattr(module, factory_name, None)
    if factory is None:
        raise AttributeError(
            f"network_factory={factory_name!r} is not defined in module "
            f"{module_path!r}. Verify the symbol name and that it is exported "
            f"at module top-level."
        )
    if not callable(factory):
        raise TypeError(
            f"network_factory={factory_name!r} in {module_path!r} is not callable "
            f"(got {type(factory).__name__})."
        )
    return factory


_INCLUDE_AGENT_KEYS = frozenset(
    {
        "flow",
        "interview",
        "answer",
        "knowledge",
        "confirmation",
        "usage",
        "onboarding",
        "escalation",
        "feedback",
    }
)

SESSION_TTL_SECONDS = int(os.environ.get("ATENDENTEPRO_SESSION_TTL", "3600"))
CLEANUP_INTERVAL_SECONDS = 300
AGENT_TIMEOUT_SECONDS = float(os.environ.get("ATENDENTEPRO_AGENT_TIMEOUT", "60"))


@dataclass
class _Session:
    messages: List[Dict[str, str]] = field(default_factory=list)
    last_active: float = field(default_factory=time.time)


@dataclass
class _TenantState:
    network: Any  # AgentNetwork
    sessions: Dict[str, _Session] = field(default_factory=dict)
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)


class TenantManager:
    """Manages AgentNetwork instances per tenant and conversation histories per session.

    All ``default_*`` parameters set baseline values that apply to every tenant.
    Per-tenant overrides can be passed via :meth:`setup` and :meth:`chat`.
    """

    def __init__(
        self,
        templates_dir: Optional[Path] = None,
        default_custom_tools: Optional[Dict[str, List[Any]]] = None,
        default_include_agents: Optional[Dict[str, bool]] = None,
        default_network_config: Optional[Dict[str, List[str]]] = None,
        default_user_loader: Optional[Callable[[List], Any]] = None,
    ) -> None:
        self._tenants: Dict[str, _TenantState] = {}
        self._templates_dir = templates_dir or Path(tempfile.mkdtemp(prefix="atendentepro_"))
        self._default_custom_tools: Dict[str, List[Any]] = default_custom_tools or {}
        self._default_include_agents: Dict[str, bool] = default_include_agents or {}
        self._default_network_config: Optional[Dict[str, List[str]]] = default_network_config
        self._default_user_loader: Optional[Callable[[List], Any]] = default_user_loader
        self._cleanup_task: Optional[asyncio.Task[None]] = None

    # ------------------------------------------------------------------
    # Setup
    # ------------------------------------------------------------------

    async def setup(
        self,
        tenant_id: str,
        yamls: Dict[str, str],
        custom_tools: Optional[Dict[str, List[Any]]] = None,
        include_agents: Optional[Dict[str, bool]] = None,
        network_config: Optional[Dict[str, List[str]]] = None,
        network_type: str = "standard",
        network_module: Optional[str] = None,
        network_factory: Optional[str] = None,
        network_params: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Write YAML configs to disk and create an AgentNetwork for *tenant_id*.

        Knowledge items (title/category/content) received via YAML are mapped
        to the ``about`` field of ``knowledge_config.yaml`` so the Knowledge
        Agent has them as direct context.  Embeddings are NOT generated here --
        they belong to the separate document-upload flow (PDFs chunked into
        hundreds of embeddings).

        Args:
            tenant_id: Unique identifier for the tenant.
            yamls: Map of config name to YAML content.
            custom_tools: Optional dict of custom tools per agent name.
                Merged with ``default_custom_tools`` (per-tenant overrides win).
            include_agents: Optional dict of agent name to bool controlling
                which agents are included. Merged with ``default_include_agents``.
                Valid keys: flow, interview, answer, knowledge, confirmation,
                usage, onboarding, escalation, feedback.
            network_config: Optional dict mapping agent names to their handoff
                targets (list of agent name strings). When provided, uses
                ``create_custom_network`` instead of ``create_standard_network``.
                Overrides ``default_network_config`` for this tenant.
            network_type: Strategy for assembling the AgentNetwork (issue #87).
                ``"standard"`` (default) → existing standard/custom network path.
                ``"custom_module"`` → import a Python factory by name and call
                it with ``network_params``. The module path MUST match the
                allowlist prefix in ``ATENDENTEPRO_NETWORK_MODULE_PREFIX``
                (default ``client_resources.``) — protects against arbitrary
                code execution from a compromised YAML.
            network_module: Required when ``network_type="custom_module"`` —
                dotted module path (e.g. ``client_resources.acme.network``).
            network_factory: Required when ``network_type="custom_module"`` —
                name of a top-level callable that returns an AgentNetwork.
            network_params: kwargs forwarded to the custom factory. Must be a
                plain dict; ``None`` means no kwargs.
        """
        import yaml as _yaml

        from atendentepro.network import (
            AgentNetwork,
            create_custom_network,
            create_standard_network,
        )
        from atendentepro.templates.manager import get_template_manager

        tenant_dir = self._templates_dir / tenant_id
        tenant_dir.mkdir(parents=True, exist_ok=True)

        for config_name, content in yamls.items():
            filename = f"{config_name}.yaml" if not config_name.endswith(".yaml") else config_name
            (tenant_dir / filename).write_text(content, encoding="utf-8")

        self._rewrite_knowledge_config(yamls, tenant_dir)

        get_template_manager().clear_caches()

        merged_tools: Optional[Dict[str, List[Any]]] = None
        if self._default_custom_tools or custom_tools:
            merged_tools = {**self._default_custom_tools, **(custom_tools or {})}

        merged_includes = {**self._default_include_agents, **(include_agents or {})}

        effective_network_config = network_config or self._default_network_config

        if network_type == "custom_module":
            # Issue #87: import-by-name network factory with allowlist.
            factory = _resolve_custom_network_factory(
                module_path=network_module or "",
                factory_name=network_factory or "",
            )
            kwargs = dict(network_params or {})
            try:
                network = factory(**kwargs)
            except TypeError as exc:
                raise TypeError(
                    f"network_factory={network_factory!r} in {network_module!r} "
                    f"rejected the supplied network_params kwargs: {exc}"
                ) from exc
            if not isinstance(network, AgentNetwork):
                raise TypeError(
                    f"network_factory={network_factory!r} in {network_module!r} "
                    f"returned {type(network).__name__}, expected AgentNetwork."
                )
        elif effective_network_config:
            network = create_custom_network(
                templates_root=self._templates_dir,
                client=tenant_id,
                network_config=effective_network_config,
                custom_tools=merged_tools,
            )
        elif network_type == "standard":
            network = create_standard_network(
                templates_root=self._templates_dir,
                client=tenant_id,
                custom_tools=merged_tools,
                user_loader=self._default_user_loader,
                include_flow=merged_includes.get("flow", True),
                include_interview=merged_includes.get("interview", True),
                include_answer=merged_includes.get("answer", True),
                include_knowledge=merged_includes.get("knowledge", True),
                include_confirmation=merged_includes.get("confirmation", True),
                include_usage=merged_includes.get("usage", True),
                include_onboarding=merged_includes.get("onboarding", False),
                include_escalation=merged_includes.get("escalation", True),
                include_feedback=merged_includes.get("feedback", True),
            )
        else:
            raise ValueError(
                f"Unknown network_type={network_type!r}. "
                f"Expected one of: 'standard', 'custom_module'."
            )

        if tenant_id in self._tenants:
            self._tenants[tenant_id].network = network
        else:
            self._tenants[tenant_id] = _TenantState(network=network)

        logger.info("Tenant %s configured (%d yamls)", tenant_id, len(yamls))

    # ------------------------------------------------------------------
    # Knowledge helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _rewrite_knowledge_config(yamls: Dict[str, str], tenant_dir: Path) -> None:
        """Convert knowledge items into the format KnowledgeConfig.load() expects.

        Incoming YAML may contain ``items`` (title/category/content).  The
        ``KnowledgeConfig`` model reads ``about``, ``template`` and ``format``.
        This method builds an ``about`` string from the items so the Knowledge
        Agent receives all the content as direct context (no RAG needed).
        """
        import yaml as _yaml

        raw = yamls.get("knowledge_config")
        if not raw:
            return

        try:
            data = _yaml.safe_load(raw)
        except Exception:
            return

        if not isinstance(data, dict):
            return

        items = data.get("items")
        if not items or not isinstance(items, list):
            return

        sections: List[str] = []
        for item in items:
            if not isinstance(item, dict):
                continue
            title = item.get("title", "")
            category = item.get("category", "")
            content = item.get("content", "")
            if not content:
                continue
            header = title or category or "Item"
            sections.append(f"### {header}\n{content}")

        if not sections:
            return

        about_text = "\n\n".join(sections)

        kc_path = tenant_dir / "knowledge_config.yaml"
        existing: Dict[str, Any] = {}
        if kc_path.exists():
            existing = _yaml.safe_load(kc_path.read_text(encoding="utf-8")) or {}

        existing["about"] = about_text
        existing.pop("items", None)

        kc_path.write_text(_yaml.dump(existing, allow_unicode=True), encoding="utf-8")
        logger.info("Knowledge config rewritten with %d items as context", len(sections))

    # ------------------------------------------------------------------
    # Chat
    # ------------------------------------------------------------------

    async def chat(
        self,
        tenant_id: str,
        session_id: str,
        message: str,
        metadata: Optional[Dict[str, Any]] = None,
        user_context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Run a message through the tenant's triage agent and return the result.

        Args:
            tenant_id: Target tenant.
            session_id: Conversation session identifier.
            message: User message text.
            metadata: Optional free-form metadata (phone, channel, etc.).
            user_context: Optional dict with ``user_id``, ``role``, and
                ``metadata`` keys.  When provided, a ``UserContext`` object
                is created and the runner uses it for access filtering.
                If a ``user_loader`` is configured on the network, it runs
                automatically via ``run_with_user_context``.
        """
        from agents import Runner

        state = self._tenants.get(tenant_id)
        if state is None:
            raise KeyError(f"Tenant '{tenant_id}' not configured. Call POST /setup first.")

        async with state.lock:
            session = state.sessions.setdefault(session_id, _Session())
            session.last_active = time.time()

            session.messages.append({"role": "user", "content": message})

            network = state.network

            # Reset user_context to prevent leaking between sessions (issue #15)
            network.loaded_user_context = None

            if user_context:
                from atendentepro.models.context import UserContext as _UC

                uc = _UC(
                    user_id=user_context.get("user_id"),
                    role=user_context.get("role"),
                    metadata=user_context.get("metadata", {}),
                )
                network.loaded_user_context = uc

            try:
                async with asyncio.timeout(AGENT_TIMEOUT_SECONDS):  # type: ignore[attr-defined]
                    if getattr(network, "user_loader", None) is not None:
                        from atendentepro.utils.user_loader import run_with_user_context as _run_ctx

                        result = await _run_ctx(network, network.triage, list(session.messages))
                    else:
                        result = await Runner.run(network.triage, list(session.messages))
            except TimeoutError:
                logger.error(
                    "Agent execution timed out after %.0fs for tenant=%s session=%s",
                    AGENT_TIMEOUT_SECONDS,
                    tenant_id,
                    session_id,
                )
                session.messages.append({"role": "assistant", "content": ""})
                return {
                    "response": "",
                    "agent_name": None,
                    "error": "timeout",
                    "timeout_seconds": AGENT_TIMEOUT_SECONDS,
                }

            assistant_text = str(result.final_output) if result.final_output else ""
            session.messages.append({"role": "assistant", "content": assistant_text})

            last_agent = getattr(result, "last_agent", None)
            agent_name = getattr(last_agent, "name", None) if last_agent else None

            # Extract handoff target if the agent handed off (issue #39)
            handoff_to = None
            if last_agent and agent_name:
                triage_name = getattr(network.triage, "name", None)
                if triage_name and agent_name != triage_name:
                    handoff_to = agent_name

        return {
            "response": assistant_text,
            "agent_name": agent_name,
            "handoff_to": handoff_to,
        }

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def get_loaded_tenants(self) -> List[str]:
        return list(self._tenants.keys())

    def remove_tenant(self, tenant_id: str) -> bool:
        return self._tenants.pop(tenant_id, None) is not None

    # ------------------------------------------------------------------
    # Session cleanup
    # ------------------------------------------------------------------

    def start_cleanup_loop(self) -> None:
        if self._cleanup_task is None or self._cleanup_task.done():
            self._cleanup_task = asyncio.create_task(self._cleanup_loop())

    def stop_cleanup_loop(self) -> None:
        if self._cleanup_task and not self._cleanup_task.done():
            self._cleanup_task.cancel()

    async def _cleanup_loop(self) -> None:
        while True:
            await asyncio.sleep(CLEANUP_INTERVAL_SECONDS)
            await self._purge_expired_sessions()

    async def _purge_expired_sessions(self) -> None:
        """Purge expired sessions with per-tenant locking to avoid race conditions (issue #14)."""
        now = time.time()
        purged = 0
        for state in list(self._tenants.values()):
            async with state.lock:
                expired = [
                    sid
                    for sid, sess in state.sessions.items()
                    if now - sess.last_active > SESSION_TTL_SECONDS
                ]
                for sid in expired:
                    del state.sessions[sid]
                    purged += 1
        if purged:
            logger.info("Purged %d expired sessions", purged)
