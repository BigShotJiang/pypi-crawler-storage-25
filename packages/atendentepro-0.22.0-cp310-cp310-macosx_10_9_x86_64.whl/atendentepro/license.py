# -*- coding: utf-8 -*-
"""
AtendentePro - Sistema de Licenciamento

Este módulo gerencia a validação de tokens de acesso para uso da biblioteca.

Uso:
    from atendentepro import activate

    # Ativar com token
    activate("seu-token-de-acesso")

    # Agora pode usar a biblioteca normalmente
    from atendentepro import create_standard_network
"""

import hashlib
import hmac
import json
import logging
import os
import threading
import time
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# Process-level secret override configured via ``activate(secret=...)``
# (issue #86). When set, takes precedence over ATENDENTEPRO_LICENSE_SECRET
# and the file-based secret so callers can supply the HMAC key explicitly
# without resorting to monkey-patching ``_validate_token_local`` — the
# previous workaround broke silently in compiled Cython wheels because
# attribute binding differed from the .py source.
_configured_secret_lock = threading.Lock()
_configured_secret: Optional[str] = None


def _set_configured_secret(secret: Optional[str]) -> None:
    """Set the process-level HMAC secret used by ``_get_secret_key``.

    ``None`` clears the override and restores the environment-variable
    fallback. Thread-safe.
    """
    global _configured_secret
    with _configured_secret_lock:
        if secret is None or not secret.strip():
            _configured_secret = None
        else:
            _configured_secret = secret.strip()


def get_configured_secret() -> Optional[str]:
    """Return the currently configured HMAC secret, or ``None``.

    Public read accessor exposed for diagnostics; the private setter is
    invoked via :func:`activate`.
    """
    with _configured_secret_lock:
        return _configured_secret


# Chave secreta carregada obrigatoriamente de variável de ambiente.
# A chave NÃO pode ser hardcoded no código-fonte distribuído.
def _get_secret_key() -> str:
    """
    Retorna a chave HMAC para assinatura de tokens.

    Resolução, na ordem:
      1. Override configurado via :func:`activate` (``secret=...``) — issue #86.
      2. Variável ``ATENDENTEPRO_LICENSE_SECRET``.
      3. Arquivo apontado por ``ATENDENTEPRO_LICENSE_SECRET_FILE`` ou
         ``/run/secrets/ATENDENTEPRO_LICENSE_SECRET`` (Docker/K8s).

    Levanta RuntimeError se nenhuma fonte estiver configurada, evitando
    operação com segredo vazio.
    """
    override = get_configured_secret()
    if override:
        return override

    key = os.environ.get("ATENDENTEPRO_LICENSE_SECRET")

    # Support file-based secrets (Docker/K8s: /run/secrets/) — issue #49
    if not key or not key.strip():
        secret_file = os.environ.get(
            "ATENDENTEPRO_LICENSE_SECRET_FILE",
            "/run/secrets/ATENDENTEPRO_LICENSE_SECRET",
        )
        if os.path.isfile(secret_file):
            try:
                with open(secret_file, "r", encoding="utf-8") as f:
                    key = f.read().strip()
            except Exception:
                key = None

    if not key or not key.strip():
        raise RuntimeError(
            "ATENDENTEPRO_LICENSE_SECRET nao configurada. "
            "Defina via variavel de ambiente, ou monte o segredo em "
            "/run/secrets/ATENDENTEPRO_LICENSE_SECRET (Docker/K8s), ou "
            "defina ATENDENTEPRO_LICENSE_SECRET_FILE apontando para o arquivo."
        )
    return key.strip()


# Lock para acesso thread-safe ao estado global de licença.
_license_lock = threading.Lock()

# Estado global de ativação
_license_state: Dict[str, Any] = {
    "activated": False,
    "token": None,
    "expiration": None,
    "features": [],
    "organization": None,
}


@dataclass
class LicenseInfo:
    """Informações da licença ativa."""

    valid: bool
    organization: Optional[str] = None
    expiration: Optional[str] = None
    features: Optional[List[Any]] = None
    message: str = ""

    def __post_init__(self) -> None:
        if self.features is None:
            self.features = []


class LicenseError(Exception):
    """Erro de licenciamento."""

    pass


class LicenseNotActivatedError(LicenseError):
    """Biblioteca não foi ativada com um token válido."""

    def __init__(self) -> None:
        super().__init__(
            "\n\n"
            "╔══════════════════════════════════════════════════════════════╗\n"
            "║          ATENDENTEPRO - LICENÇA NÃO ATIVADA                  ║\n"
            "╠══════════════════════════════════════════════════════════════╣\n"
            "║                                                              ║\n"
            "║  A biblioteca AtendentePro requer ativação para uso.        ║\n"
            "║                                                              ║\n"
            "║  Para ativar, use:                                          ║\n"
            "║                                                              ║\n"
            "║    from atendentepro import activate                        ║\n"
            "║    activate('seu-token-de-acesso')                          ║\n"
            "║                                                              ║\n"
            "║  Ou defina a variável de ambiente:                          ║\n"
            "║                                                              ║\n"
            "║    export ATENDENTEPRO_LICENSE_KEY='seu-token'              ║\n"
            "║                                                              ║\n"
            "║  Para obter um token, entre em contato:                     ║\n"
            "║  📧 contato@monkai.com.br                                    ║\n"
            "║                                                              ║\n"
            "╚══════════════════════════════════════════════════════════════╝\n"
        )


class LicenseExpiredError(LicenseError):
    """Token de licença expirado."""

    def __init__(self, expiration: str) -> None:
        super().__init__(
            f"\n\n"
            f"╔══════════════════════════════════════════════════════════════╗\n"
            f"║          ATENDENTEPRO - LICENÇA EXPIRADA                    ║\n"
            f"╠══════════════════════════════════════════════════════════════╣\n"
            f"║                                                              ║\n"
            f"║  Sua licença expirou em: {expiration:<36}║\n"
            f"║                                                              ║\n"
            f"║  Para renovar, entre em contato:                            ║\n"
            f"║  📧 contato@monkai.com.br                                    ║\n"
            f"║                                                              ║\n"
            f"╚══════════════════════════════════════════════════════════════╝\n"
        )


class InvalidTokenError(LicenseError):
    """Token inválido."""

    def __init__(self) -> None:
        super().__init__(
            "\n\n"
            "╔══════════════════════════════════════════════════════════════╗\n"
            "║          ATENDENTEPRO - TOKEN INVÁLIDO                       ║\n"
            "╠══════════════════════════════════════════════════════════════╣\n"
            "║                                                              ║\n"
            "║  O token fornecido não é válido.                            ║\n"
            "║                                                              ║\n"
            "║  Verifique se o token está correto ou entre em contato:     ║\n"
            "║  📧 contato@monkai.com.br                                    ║\n"
            "║                                                              ║\n"
            "╚══════════════════════════════════════════════════════════════╝\n"
        )


class LicenseTimeoutError(LicenseError):
    """Ativação de licença excedeu o timeout configurado."""

    def __init__(self, timeout: float) -> None:
        super().__init__(
            f"\n\n"
            f"╔══════════════════════════════════════════════════════════════╗\n"
            f"║          ATENDENTEPRO - TIMEOUT NA ATIVAÇÃO                 ║\n"
            f"╠══════════════════════════════════════════════════════════════╣\n"
            f"║                                                              ║\n"
            f"║  A ativação da licença excedeu o limite de {timeout:>5.1f}s.         ║\n"
            f"║                                                              ║\n"
            f"║  Verifique conectividade com o servidor de validação        ║\n"
            f"║  (ATENDENTEPRO_VALIDATION_URL) ou aumente o timeout via     ║\n"
            f"║  activate(timeout=<segundos>).                              ║\n"
            f"║                                                              ║\n"
            f"╚══════════════════════════════════════════════════════════════╝\n"
        )
        self.timeout = timeout


def _generate_token(
    organization: str,
    expiration_timestamp: Optional[int] = None,
    features: Optional[List[Any]] = None,
    secret_key: Optional[str] = None,
) -> str:
    """
    Gera um token de licença.

    USO INTERNO - Para gerar tokens para clientes.

    Args:
        organization: Nome da organização
        expiration_timestamp: Unix timestamp de expiração (None = sem expiração)
        features: Lista de features habilitadas
        secret_key: Chave secreta para assinatura

    Returns:
        Token codificado em base64
    """
    import base64

    if secret_key is None:
        secret_key = _get_secret_key()

    if features is None:
        features = ["full"]

    # Payload do token
    payload = {
        "org": organization,
        "exp": expiration_timestamp,
        "feat": features,
        "v": 1,  # versão do token
    }

    # Serializar payload
    payload_json = json.dumps(payload, separators=(",", ":"))
    payload_b64 = base64.urlsafe_b64encode(payload_json.encode()).decode()

    # Gerar assinatura
    signature = hmac.new(secret_key.encode(), payload_b64.encode(), hashlib.sha256).hexdigest()

    # Token final: payload.signature
    token = f"ATP_{payload_b64}.{signature}"

    return token


def _validate_token_local(token: str, secret_key: Optional[str] = None) -> LicenseInfo:
    """
    Valida um token localmente via HMAC-SHA256.

    Args:
        token: Token de licença
        secret_key: Chave secreta para validação

    Returns:
        LicenseInfo com informações da validação
    """
    import base64

    if secret_key is None:
        secret_key = _get_secret_key()

    try:
        # Verificar formato
        if not token.startswith("ATP_"):
            return LicenseInfo(valid=False, message="Formato de token inválido")

        token_body = token[4:]  # Remover "ATP_"

        if "." not in token_body:
            return LicenseInfo(valid=False, message="Token malformado")

        payload_b64, signature = token_body.rsplit(".", 1)

        # Verificar assinatura (full 256-bit; backward-compat with legacy 64-bit)
        full_sig = hmac.new(secret_key.encode(), payload_b64.encode(), hashlib.sha256).hexdigest()

        # Accept both full signature and legacy truncated (16-char) signatures
        sig_valid = hmac.compare_digest(signature, full_sig) or (
            len(signature) == 16 and hmac.compare_digest(signature, full_sig[:16])
        )
        if not sig_valid:
            return LicenseInfo(valid=False, message="Assinatura inválida")

        # Decodificar payload
        try:
            payload_json = base64.urlsafe_b64decode(payload_b64).decode()
            payload = json.loads(payload_json)
        except Exception:
            return LicenseInfo(valid=False, message="Payload inválido")

        # Verificar expiração
        expiration = payload.get("exp")
        expiration_str = None

        if expiration is not None:
            expiration_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(expiration))
            if time.time() > expiration:
                return LicenseInfo(valid=False, expiration=expiration_str, message="Token expirado")

        # Token válido
        return LicenseInfo(
            valid=True,
            organization=payload.get("org", "Unknown"),
            expiration=expiration_str,
            features=payload.get("feat", ["full"]),
            message="Token válido",
        )

    except Exception as e:
        logger.warning("Falha na validação local do token: %s", e, exc_info=True)
        return LicenseInfo(valid=False, message="Erro interno na validação. Tente novamente.")


def _is_production_mode() -> bool:
    """Return True if ATENDENTEPRO_PRODUCTION is set (1, true, yes)."""
    v = (os.environ.get("ATENDENTEPRO_PRODUCTION") or "").strip().lower()
    return v in ("1", "true", "yes")


def _http_post_with_retry(
    url: str,
    payload: Dict[str, Any],
    timeout: float = 5.0,
    max_retries: int = 3,
    headers: Optional[Dict[str, str]] = None,
) -> Any:
    """POST com retry e backoff exponencial para erros de conexao e 5xx."""
    import httpx

    _headers = {"Content-Type": "application/json"}
    if headers:
        _headers.update(headers)

    delays = [0.5, 1.0, 2.0]
    transport = httpx.HTTPTransport(retries=2)
    last_exc: Optional[Exception] = None

    with httpx.Client(transport=transport) as client:
        for attempt in range(max_retries):
            try:
                resp = client.post(url, json=payload, timeout=timeout, headers=_headers)
                if resp.status_code < 500:
                    resp.raise_for_status()
                    return resp
                # 5xx: retry
                last_exc = httpx.HTTPStatusError(
                    f"Server error {resp.status_code}",
                    request=resp.request,
                    response=resp,
                )
            except httpx.HTTPStatusError:
                raise
            except Exception as exc:
                last_exc = exc

            if attempt < max_retries - 1:
                time.sleep(delays[min(attempt, len(delays) - 1)])

    raise last_exc  # type: ignore[misc]


def _validate_token_online(token: str, api_url: Optional[str] = None) -> LicenseInfo:
    """
    Valida um token online através de API de revogação em tempo real.

    Se ATENDENTEPRO_VALIDATION_URL (ou api_url) estiver configurada, faz uma
    requisição POST ao endpoint de validação com retry automatico (3 tentativas
    com backoff). Em caso de falha ou ausência de URL, emite RuntimeWarning e
    faz fallback para validação local.

    Args:
        token: Token de licença
        api_url: URL do endpoint de validação (sobrepõe a variável de ambiente)

    Returns:
        LicenseInfo com informações da validação
    """
    endpoint = api_url or os.environ.get("ATENDENTEPRO_VALIDATION_URL")

    if not endpoint:
        warnings.warn(
            "ATENDENTEPRO_VALIDATION_URL nao configurada. "
            "Usando validacao local. Para suporte a revogacao em tempo real, "
            "configure a URL do endpoint de validacao.",
            RuntimeWarning,
            stacklevel=2,
        )
        return _validate_token_local(token)

    try:
        resp = _http_post_with_retry(endpoint, {"token": token}, timeout=5.0)
        data = resp.json()
        return LicenseInfo(
            valid=bool(data.get("valid", False)),
            organization=data.get("organization"),
            expiration=data.get("expiration"),
            features=data.get("features", ["full"]),
            message=data.get("message", ""),
        )
    except Exception as exc:
        warnings.warn(
            f"Validacao online falhou ({exc}). Usando validacao local como fallback.",
            RuntimeWarning,
            stacklevel=2,
        )
        return _validate_token_local(token)


def _activate_impl(
    token: Optional[str] = None,
    validate_online: bool = False,
    silent: bool = False,
    secret: Optional[str] = None,
) -> LicenseInfo:
    """Synchronous activation implementation. See :func:`activate` for docs."""
    global _license_state

    # Issue #86: persist the explicit HMAC secret BEFORE any validation step
    # so ``_validate_token_local`` (and any subsequent ``require_activation``
    # check that re-resolves the secret) consults the override instead of
    # falling back to the env var.
    if secret is not None:
        _set_configured_secret(secret)

    # Tentar obter token de variável de ambiente
    if token is None:
        token = os.environ.get("ATENDENTEPRO_LICENSE_KEY")

    if token is None:
        raise LicenseNotActivatedError()

    # Produção: forçar validação online; segredo fica só no servidor de validação
    use_online = validate_online or _is_production_mode()
    if _is_production_mode():
        validation_url = os.environ.get("ATENDENTEPRO_VALIDATION_URL") or ""
        if not validation_url.strip():
            raise LicenseError(
                "Em modo producao (ATENDENTEPRO_PRODUCTION=1) e obrigatorio configurar "
                "ATENDENTEPRO_VALIDATION_URL com o endpoint de validacao. "
                "O segredo (ATENDENTEPRO_LICENSE_SECRET) deve ficar apenas no servidor de validacao."
            )
    # Validar token
    if use_online:
        license_info = _validate_token_online(token)
    else:
        license_info = _validate_token_local(token)

    if not license_info.valid:
        if "expirado" in license_info.message.lower():
            raise LicenseExpiredError(license_info.expiration or "Data desconhecida")
        raise InvalidTokenError()

    # Atualizar estado global com lock para thread-safety
    with _license_lock:
        _license_state["activated"] = True
        _license_state["token"] = token
        _license_state["expiration"] = license_info.expiration
        _license_state["features"] = license_info.features
        _license_state["organization"] = license_info.organization

    if not silent:
        exp_msg = (
            f" (expira: {license_info.expiration})"
            if license_info.expiration
            else " (sem expiração)"
        )
        print(f"✅ AtendentePro ativado para: {license_info.organization}{exp_msg}")

    return license_info


def _run_with_timeout(
    func: Any,
    timeout: float,
    *args: Any,
    **kwargs: Any,
) -> Any:
    """
    Run `func(*args, **kwargs)` in a daemon thread with a hard deadline.

    If the call does not return within `timeout` seconds, raises
    :class:`LicenseTimeoutError`. The worker thread is left to finish on its
    own (daemon = it will not block process exit) — there is no safe way to
    abort a blocking syscall from Python.

    Exceptions raised by `func` are re-raised on the caller thread.
    """
    result: Dict[str, Any] = {}

    def _worker() -> None:
        try:
            result["value"] = func(*args, **kwargs)
        except BaseException as exc:  # noqa: BLE001 - we re-raise on caller
            result["error"] = exc

    thread = threading.Thread(target=_worker, daemon=True, name="atp-activate")
    thread.start()
    thread.join(timeout=timeout)

    if thread.is_alive():
        raise LicenseTimeoutError(timeout)

    if "error" in result:
        raise result["error"]
    return result.get("value")


def activate(
    token: Optional[str] = None,
    validate_online: bool = False,
    silent: bool = False,
    timeout: Optional[float] = 5.0,
    secret: Optional[str] = None,
) -> LicenseInfo:
    """
    Ativa a biblioteca AtendentePro com um token de licença.

    Args:
        token: Token de licença. Se não fornecido, tenta usar
               a variável de ambiente ATENDENTEPRO_LICENSE_KEY
        validate_online: Se True, valida o token online (requer internet).
               Se ATENDENTEPRO_PRODUCTION=1, a validação online é sempre usada
               e ATENDENTEPRO_VALIDATION_URL é obrigatória.
        silent: Se True, não imprime mensagens de sucesso
        timeout: Tempo máximo (em segundos) para a ativação completar. Protege
               contra hang silencioso na resolução HMAC secret / validação
               online. ``None`` desliga o wrapper (sem deadline). Default: 5.0.
        secret: HMAC secret explícito para validação local (issue #86). Quando
               fornecido, sobrepõe ``ATENDENTEPRO_LICENSE_SECRET`` (e o caminho
               ``/run/secrets/...``) durante toda a vida do processo. Permite
               que clientes (ex.: White Martins) configurem o segredo via
               KeyVault/Graph sem precisar de monkey-patch em
               ``_validate_token_local``. Funciona tanto em wheels Cython
               quanto na fonte ``.py``.

    Returns:
        LicenseInfo com informações da licença

    Raises:
        InvalidTokenError: Se o token for inválido
        LicenseExpiredError: Se o token estiver expirado
        LicenseTimeoutError: Se a ativação exceder ``timeout`` segundos

    Exemplo:
        >>> from atendentepro import activate
        >>> activate("ATP_eyJvcmciOiJNaW5oYUVtcHJlc2EiLCJleHAiOm51bGwsImZlYXQiOlsiZnVsbCJdLCJ2IjoxfQ.abc123")
        ✅ AtendentePro ativado para: MinhaEmpresa

        >>> # Cliente que carrega o secret de Key Vault em runtime:
        >>> activate(token=os.environ["LICENSE_KEY"], secret=keyvault.get("license-secret"))
    """
    if timeout is None:
        return _activate_impl(
            token=token,
            validate_online=validate_online,
            silent=silent,
            secret=secret,
        )

    return _run_with_timeout(
        _activate_impl,
        timeout,
        token=token,
        validate_online=validate_online,
        silent=silent,
        secret=secret,
    )


def deactivate() -> None:
    """Desativa a biblioteca (útil para testes).

    Também limpa o segredo HMAC configurado via ``activate(secret=...)``
    (issue #86) para garantir isolamento entre testes/processos.
    """
    global _license_state
    with _license_lock:
        _license_state = {
            "activated": False,
            "token": None,
            "expiration": None,
            "features": [],
            "organization": None,
        }
    _set_configured_secret(None)


def is_activated() -> bool:
    """Verifica se a biblioteca está ativada."""
    with _license_lock:
        return _license_state["activated"]


def get_license_info() -> LicenseInfo:
    """Retorna informações da licença atual."""
    with _license_lock:
        activated = _license_state["activated"]
        if not activated:
            return LicenseInfo(valid=False, message="Não ativado")
        return LicenseInfo(
            valid=True,
            organization=_license_state["organization"],
            expiration=_license_state["expiration"],
            features=_license_state["features"],
            message="Ativo",
        )


def require_activation() -> None:
    """
    Decorator/função para verificar se a biblioteca está ativada.

    Raises:
        LicenseNotActivatedError: Se não estiver ativada
    """
    with _license_lock:
        already_active = _license_state["activated"]

    if not already_active:
        env_token = os.environ.get("ATENDENTEPRO_LICENSE_KEY")
        if env_token:
            try:
                activate(env_token, silent=True)
            except LicenseError:
                pass

    with _license_lock:
        if not _license_state["activated"]:
            raise LicenseNotActivatedError()


def has_feature(feature: str) -> bool:
    """Verifica se uma feature específica está habilitada."""
    with _license_lock:
        if not _license_state["activated"]:
            return False
        features = _license_state.get("features", [])
    return "full" in features or feature in features


# ============================================================================
# AUTO-ATIVAÇÃO VIA VARIÁVEL DE AMBIENTE
# ============================================================================


def _try_auto_activate() -> None:
    """Tenta ativar automaticamente via variável de ambiente."""
    env_token = os.environ.get("ATENDENTEPRO_LICENSE_KEY")
    with _license_lock:
        already = _license_state["activated"]
    if env_token and not already:
        try:
            activate(env_token, silent=True)
        except LicenseError:
            pass  # Silenciosamente ignora erros de auto-ativação


# Tentar auto-ativar ao importar o módulo
_try_auto_activate()
