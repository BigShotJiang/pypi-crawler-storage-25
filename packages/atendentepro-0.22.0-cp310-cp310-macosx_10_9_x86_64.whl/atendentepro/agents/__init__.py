# -*- coding: utf-8 -*-
"""
Agents module for AtendentePro library.

This module provides factory functions for creating agents with customizable
configurations. Templates can be loaded from external directories.
"""

from ._factory import set_agent_instructions
from .answer import AnswerAgent, create_answer_agent
from .confirmation import ConfirmationAgent, create_confirmation_agent
from .escalation import ESCALATION_TOOLS, EscalationAgent, create_escalation_agent
from .feedback import (
    FEEDBACK_TOOLS,
    FeedbackAgent,
    configure_feedback_storage,
    create_feedback_agent,
)
from .flow import FlowAgent, create_flow_agent
from .interview import InterviewAgent, create_interview_agent
from .knowledge import KnowledgeAgent, create_knowledge_agent, go_to_rag, make_go_to_rag
from .onboarding import OnboardingAgent, create_onboarding_agent
from .triage import TriageAgent, create_triage_agent
from .usage import UsageAgent, create_usage_agent

__all__ = [
    # Triage
    "create_triage_agent",
    "TriageAgent",
    # Flow
    "create_flow_agent",
    "FlowAgent",
    # Interview
    "create_interview_agent",
    "InterviewAgent",
    # Answer
    "create_answer_agent",
    "AnswerAgent",
    # Knowledge
    "create_knowledge_agent",
    "KnowledgeAgent",
    "go_to_rag",
    "make_go_to_rag",
    # Confirmation
    "create_confirmation_agent",
    "ConfirmationAgent",
    # Usage
    "create_usage_agent",
    "UsageAgent",
    # Onboarding
    "create_onboarding_agent",
    "OnboardingAgent",
    # Escalation
    "create_escalation_agent",
    "EscalationAgent",
    "ESCALATION_TOOLS",
    # Feedback
    "create_feedback_agent",
    "FeedbackAgent",
    "FEEDBACK_TOOLS",
    "configure_feedback_storage",
    # Helpers
    "set_agent_instructions",
]
