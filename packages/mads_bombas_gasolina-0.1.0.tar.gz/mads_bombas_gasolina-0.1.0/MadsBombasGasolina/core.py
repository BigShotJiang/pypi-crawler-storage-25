"""Módulo principal do projeto MADS Bombas de Gasolina.

Este módulo reúne as funcionalidades desenvolvidas no notebook/Colab original:
- registo de compras;
- consulta e filtragem de histórico;
- visualização em mapa;
- gráficos de variação de preços;
- exportação para CSV e PDF.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timedelta
from typing import Any, Iterable

import folium
import matplotlib.pyplot as plt
import pandas as pd
import requests
from branca.element import Element

FICHEIRO_COMPRAS = "compras.json"
FICHEIRO_LOCALIZACOES = "localizacoes_mapa.json"

MARCAS_VALIDAS = ["galp", "bp", "repsol", "cepsa", "prio"]
TIPOS_COMBUSTIVEL_VALIDOS = ["gasolina", "gasoleo", "gpl"]

CORES_MARCAS = {
    "galp": "#FF0000",
    "bp": "#008000",
    "repsol": "#FFA500",
    "cepsa": "#0000FF",
    "prio": "#800080",
}


def _ler_json_lista(caminho: str) -> list[dict[str, Any]]:
    """Lê um ficheiro JSON contendo uma lista de dicionários."""
    if not os.path.exists(caminho):
        return []

    try:
        with open(caminho, "r", encoding="utf-8") as ficheiro:
            dados = json.load(ficheiro)
    except Exception:
        return []

    return dados if isinstance(dados, list) else []


def _guardar_json_lista(caminho: str, dados: Iterable[dict[str, Any]]) -> None:
    """Guarda uma lista de dicionários em JSON."""
    with open(caminho, "w", encoding="utf-8") as ficheiro:
        json.dump(list(dados), ficheiro, indent=4, ensure_ascii=False)


def registar_compra(nif, marca, preco, data, tipo_combustivel):
    """Regista uma compra de combustível no ficheiro compras.json."""
    erros = []

    if not (isinstance(nif, str) and nif.isdigit() and len(nif) == 9):
        erros.append(f"NIF inválido ('{nif}'). Deve ter 9 dígitos.")

    if not isinstance(marca, str) or marca.lower() not in MARCAS_VALIDAS:
        erros.append(f"Marca inválida ('{marca}'). Use: {MARCAS_VALIDAS}")

    if not isinstance(preco, (int, float)) or preco <= 0:
        erros.append(f"Preço inválido ('{preco}'). Deve ser positivo.")

    try:
        data_obj = datetime.strptime(data, "%Y-%m-%d")
        if data_obj > datetime.now():
            erros.append(f"Data '{data}' está no futuro.")
    except Exception:
        erros.append(f"Data inválida ('{data}'). Use YYYY-MM-DD.")

    if (
        not isinstance(tipo_combustivel, str)
        or tipo_combustivel.lower() not in TIPOS_COMBUSTIVEL_VALIDOS
    ):
        erros.append(
            f"Tipo de combustível inválido ('{tipo_combustivel}'). "
            f"Use: {TIPOS_COMBUSTIVEL_VALIDOS}"
        )

    compras = _ler_json_lista(FICHEIRO_COMPRAS)

    if not erros:
        for compra in compras:
            if (
                compra.get("nif") == nif
                and compra.get("data") == data
                and compra.get("marca") == marca.lower()
            ):
                erros.append(
                    f"Erro: Já existe um registo para a bomba: {marca.lower()} "
                    f"com NIF {nif} na data {data}. Não é permitido registar "
                    "duas compras para a mesma bomba no mesmo dia."
                )
                break

    if erros:
        return "Erros encontrados:\n" + "\n".join(f"- {erro}" for erro in erros)

    nova_compra = {
        "nif": nif,
        "marca": marca.lower(),
        "preco": preco,
        "data": data,
        "tipo": tipo_combustivel.lower(),
    }

    compras.append(nova_compra)
    _guardar_json_lista(FICHEIRO_COMPRAS, compras)

    return (
        "Sucesso: Compra com "
        f"NIF '{nif}', marca '{marca.lower()}', preço '{preco}', data '{data}' "
        f"e tipo '{tipo_combustivel.lower()}' guardada no ficheiro."
    )


def listar_bombas_por_marca(marca):
    """Lista os registos de compras associados a uma marca."""
    if not isinstance(marca, str) or marca.lower() not in MARCAS_VALIDAS:
        return f"Erro: Marca inválida. Use: {MARCAS_VALIDAS}"

    compras = _ler_json_lista(FICHEIRO_COMPRAS)
    if not compras:
        return "Erro: Não existem dados registados."

    resultados = [compra for compra in compras if compra.get("marca") == marca.lower()]

    if not resultados:
        return f"Não existem registos para a marca '{marca}'."

    resultados.sort(key=lambda item: item.get("data", ""))

    mensagem = f"Bombas da marca '{marca}':\n"
    mensagem += "-" * 40 + "\n"
    for registo in resultados:
        mensagem += (
            f"NIF: {registo['nif']} | "
            f"Data: {registo['data']} | "
            f"Preço: {registo['preco']}€ | "
            f"Combustível: {registo['tipo']}\n"
        )
    return mensagem


def consultar_historico_precos(marca):
    """Consulta o histórico de preços de uma marca."""
    if not isinstance(marca, str) or marca.lower() not in MARCAS_VALIDAS:
        return f"Erro: Marca inválida. Use: {MARCAS_VALIDAS}"

    compras = _ler_json_lista(FICHEIRO_COMPRAS)
    if not compras:
        return "Erro: Não existem dados registados."

    historico = [compra for compra in compras if compra.get("marca") == marca.lower()]
    if not historico:
        return f"Não existem registos para a marca '{marca}'."

    historico.sort(key=lambda item: item.get("data", ""))

    mensagem = f"Histórico de preços da marca '{marca}':\n"
    mensagem += "-" * 50 + "\n"
    for item in historico:
        mensagem += (
            f"NIF: {item['nif']} | "
            f"Data: {item['data']} | "
            f"Preço: {item['preco']}€ | "
            f"Combustível: {item['tipo']}\n"
        )
    return mensagem


def get_preco_mais_recente(marca):
    """Obtém o preço mais recente disponível para uma marca."""
    compras = _ler_json_lista(FICHEIRO_COMPRAS)
    if not compras:
        return None

    compras_marca = []
    for compra in compras:
        if compra.get("marca") == marca.lower():
            try:
                data = datetime.strptime(compra["data"], "%Y-%m-%d")
                compras_marca.append((data, compra["preco"]))
            except Exception:
                continue

    if not compras_marca:
        return None

    compras_marca.sort(reverse=True, key=lambda item: item[0])
    return compras_marca[0][1]


def registar_localizacao_mapa(marca, latitude, longitude):
    """Regista a localização geográfica de uma marca para visualização em mapa."""
    erros = []

    if not isinstance(marca, str) or marca.lower() not in CORES_MARCAS:
        erros.append(f"Marca inválida ('{marca}'). Use: {list(CORES_MARCAS.keys())}")

    if not isinstance(latitude, (int, float)) or not -90 <= latitude <= 90:
        erros.append(f"Latitude inválida ('{latitude}'). Deve estar entre -90 e 90.")

    if not isinstance(longitude, (int, float)) or not -180 <= longitude <= 180:
        erros.append(
            f"Longitude inválida ('{longitude}'). Deve estar entre -180 e 180."
        )

    if erros:
        return "Erros encontrados:\n" + "\n".join(f"- {erro}" for erro in erros)

    localizacoes = _ler_json_lista(FICHEIRO_LOCALIZACOES)

    nova_localizacao = {
        "marca": marca.lower(),
        "latitude": latitude,
        "longitude": longitude,
        "cor": CORES_MARCAS[marca.lower()],
    }

    localizacoes.append(nova_localizacao)
    _guardar_json_lista(FICHEIRO_LOCALIZACOES, localizacoes)

    return (
        f"Sucesso: Localização da marca '{marca.lower()}' "
        f"registada com cor '{CORES_MARCAS[marca.lower()]}'"
    )


def mapa_bombas():
    """Cria um mapa Folium com as localizações e o preço mais recente por marca."""
    localizacoes = _ler_json_lista(FICHEIRO_LOCALIZACOES)

    resposta = requests.get(
        "http://baze.cm-maia.pt/BaZe/api/api4gj.php?nome=LimConcVM", timeout=20
    )
    resposta.raise_for_status()
    conteudo = resposta.text[1:]
    geojson_maia = json.loads(conteudo)

    mapa = folium.Map(
        location=[41.22, -8.5795],
        zoom_start=12,
        width=1200,
        height=700,
        tiles="cartodbpositron",
    )

    folium.TileLayer("cartodbpositron", name="CartoDB Positron").add_to(mapa)
    folium.TileLayer("cartodbdark_matter", name="CartoDB Dark").add_to(mapa)
    folium.TileLayer(
        "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
        name="OpenTopoMap",
        attr="Map data: © OpenStreetMap contributors",
    ).add_to(mapa)
    folium.TileLayer(
        tiles="https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}",
        attr="Google",
        name="Google Satellite",
    ).add_to(mapa)
    folium.TileLayer(
        tiles="https://mt1.google.com/vt/lyrs=p&x={x}&y={y}&z={z}",
        attr="Google",
        name="Google Terrain",
    ).add_to(mapa)

    folium.GeoJson(geojson_maia, name="Limite do Concelho").add_to(mapa)

    for loc in localizacoes:
        preco = get_preco_mais_recente(loc["marca"])
        popup_texto = f"<b>Marca:</b> {loc['marca'].capitalize()}"
        if preco is not None:
            popup_texto += f"<br><b>Preço mais recente:</b> {preco} €"

        folium.CircleMarker(
            location=[loc["latitude"], loc["longitude"]],
            radius=7,
            color=loc["cor"],
            fill=True,
            fill_color=loc["cor"],
            fill_opacity=0.9,
            popup=folium.Popup(popup_texto, max_width=250),
        ).add_to(mapa)

    folium.LayerControl().add_to(mapa)

    legenda_html = """
    <div style="
        position: fixed;
        top: 10vh;
        left: 1vh;
        width: 180px;
        z-index: 9999;
        font-size: 14px;
        background-color: white;
        border: 2px solid grey;
        padding: 10px;
    ">
        <b>Legenda de Marcas</b><br>
    """

    marcas = {}
    for loc in localizacoes:
        marcas[loc["marca"]] = loc["cor"]

    for marca, cor in marcas.items():
        legenda_html += (
            "<i style='background:"
            f"{cor}; width:15px; height:15px; display:inline-block; "
            "margin-right:5px;'></i> "
            f"{marca.capitalize()}<br>"
        )

    legenda_html += "</div>"

    mapa.get_root().html.add_child(Element(legenda_html))
    return mapa


def grafico_variacao_precos(marca):
    """Mostra um gráfico da variação de preços da marca nos últimos 6 meses."""
    if not isinstance(marca, str) or marca.lower() not in MARCAS_VALIDAS:
        return f"Erro: Marca inválida. Use: {MARCAS_VALIDAS}"

    compras = _ler_json_lista(FICHEIRO_COMPRAS)
    if not compras:
        return "Erro: Não existem dados registados."

    dados = [compra for compra in compras if compra.get("marca") == marca.lower()]
    if not dados:
        return f"Não existem dados para a marca '{marca}'."

    hoje = datetime.now()
    limite = hoje - timedelta(days=180)

    dados_filtrados = []
    for item in dados:
        try:
            data_obj = datetime.strptime(item["data"], "%Y-%m-%d")
        except Exception:
            continue

        if data_obj >= limite:
            dados_filtrados.append({"data": data_obj, "preco": item["preco"]})

    if not dados_filtrados:
        return "Não existem dados nos últimos 6 meses."

    dados_filtrados.sort(key=lambda item: item["data"])
    datas = [item["data"] for item in dados_filtrados]
    precos = [item["preco"] for item in dados_filtrados]

    plt.figure()
    plt.plot(datas, precos, marker="o")
    plt.xlabel("Data")
    plt.ylabel("Preço (€)")
    plt.title(f"Variação de preços - {marca}")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()
    return None


def filtrar_dados_por_periodo(data_inicio, data_fim):
    """Filtra compras por intervalo de datas."""
    compras = _ler_json_lista(FICHEIRO_COMPRAS)
    if not compras:
        return []

    try:
        inicio = datetime.strptime(data_inicio, "%Y-%m-%d")
        fim = datetime.strptime(data_fim, "%Y-%m-%d")
    except Exception:
        print("Formato inválido. Use YYYY-MM-DD")
        return []

    dados_filtrados = []
    for compra in compras:
        try:
            data = datetime.strptime(compra["data"], "%Y-%m-%d")
            if inicio <= data <= fim:
                dados_filtrados.append(compra)
        except Exception:
            continue

    return dados_filtrados


def top_3_bombas_mais_baratas(data_inicio, data_fim):
    """Devolve as 3 compras mais baratas num dado período."""
    compras_filtradas = filtrar_dados_por_periodo(data_inicio, data_fim)
    return sorted(compras_filtradas, key=lambda item: item["preco"])[:3]


def top_3_bombas_mais_caras(data_inicio, data_fim):
    """Devolve as 3 compras mais caras num dado período."""
    compras_filtradas = filtrar_dados_por_periodo(data_inicio, data_fim)
    return sorted(compras_filtradas, key=lambda item: item["preco"], reverse=True)[:3]


def exportar_consulta_resumida(dados, formato="csv", nome_ficheiro="exportacao_consulta"):
    """Exporta uma lista de dicionários para CSV ou PDF."""
    if not dados or not isinstance(dados, list):
        return "Erro: Não existem dados válidos para exportar."

    df = pd.DataFrame(dados)
    df.columns = [str(col).capitalize() for col in df.columns]

    if formato.lower() == "csv":
        caminho_ficheiro = f"{nome_ficheiro}.csv"
        df.to_csv(caminho_ficheiro, index=False, encoding="utf-8-sig", sep=";")
        return (
            "Sucesso: Dados exportados com sucesso para o ficheiro "
            f"'{caminho_ficheiro}'."
        )

    if formato.lower() == "pdf":
        caminho_ficheiro = f"{nome_ficheiro}.pdf"

        altura_figura = max(2, len(dados) * 0.5 + 1)
        fig, ax = plt.subplots(figsize=(10, altura_figura))
        ax.axis("tight")
        ax.axis("off")

        tabela = ax.table(
            cellText=df.values,
            colLabels=df.columns,
            cellLoc="center",
            loc="center",
        )
        tabela.auto_set_font_size(False)
        tabela.set_fontsize(10)
        tabela.scale(1.2, 1.2)

        plt.savefig(caminho_ficheiro, format="pdf", bbox_inches="tight")
        plt.close(fig)

        return (
            "Sucesso: Dados exportados com sucesso para o ficheiro "
            f"'{caminho_ficheiro}'."
        )

    return "Erro: Formato inválido. Por favor, escolha 'csv' ou 'pdf'."


def exportar_todos_dados(nome_ficheiro="backup_total_bombas"):
    """Exporta todos os registos do sistema para CSV."""
    compras = _ler_json_lista(FICHEIRO_COMPRAS)
    if not compras:
        return "Erro: Não existem dados registados no sistema para exportar."

    df = pd.DataFrame(compras)
    df.columns = [str(col).capitalize() for col in df.columns]

    caminho_csv = f"{nome_ficheiro}.csv"
    df.to_csv(caminho_csv, index=False, encoding="utf-8-sig", sep=";")

    return (
        f"Sucesso: O backup foi concluído. {len(compras)} registos exportados "
        f"para '{caminho_csv}'."
    )
