import time
from rich.console import Console
from rich.live import Live
from rich.layout import Layout
from rich.panel import Panel
from rich.text import Text
from rich import box

from ..utils import sample_words, calculate_wpm, calculate_accuracy
from .. import compat as kb

console = Console()

TIMED_WORD_BUFFER = 200


def run_test(mode: str, setting: int) -> dict:
    """Run a typing test. Returns dict with wpm, accuracy, errors, typed, prompt."""
    if mode == "timed":
        prompt = sample_words(TIMED_WORD_BUFFER)
        duration = setting
    else:
        prompt = sample_words(setting)
        duration = None

    typed = ""
    start_time = None
    finished = False

    def build_display() -> Layout:
        elapsed = (time.perf_counter() - start_time) if start_time else 0.0
        wpm = calculate_wpm(typed, elapsed) if elapsed > 0 else 0.0

        if mode == "timed":
            remaining = max(0.0, duration - elapsed) if start_time else float(duration)
            timer_str = f"{remaining:.1f}s"
            timer_style = "bold yellow" if remaining > 5 else "bold red"
        else:
            words_done = len(typed.split()) if typed else 0
            if typed and not typed.endswith(" "):
                words_done = max(0, words_done - 1)
            timer_str = f"{words_done}/{setting} words"
            timer_style = "bold cyan"

        acc = calculate_accuracy(prompt, typed) if typed else 100.0
        stats = Text()
        stats.append("WPM: ", style="dim")
        stats.append(f"{wpm:.0f}", style="bold cyan")
        stats.append("   ACC: ", style="dim")
        stats.append(f"{acc:.0f}%", style="bold green")
        stats.append("   ", style="dim")
        stats.append(timer_str, style=timer_style)

        prompt_text = Text(overflow="fold")
        cursor_placed = False
        for i, ch in enumerate(prompt):
            if i < len(typed):
                if typed[i] == ch:
                    prompt_text.append(ch, style="bold green")
                else:
                    prompt_text.append(ch, style="bold red")
            elif i == len(typed) and not cursor_placed:
                prompt_text.append(ch, style="bold white underline")
                cursor_placed = True
            else:
                prompt_text.append(ch, style="dim white")

        layout = Layout()
        layout.split_column(
            Layout(name="stats", size=3),
            Layout(name="prompt", size=10),
            Layout(name="hint", size=3),
        )
        layout["stats"].update(Panel(stats, border_style="blue", box=box.SIMPLE))
        layout["prompt"].update(Panel(prompt_text, title="[dim]type the words below[/dim]", border_style="dim", padding=(1, 2)))
        hint = Text("TAB  restart    ESC  quit test", style="dim", justify="center")
        layout["hint"].update(Panel(hint, border_style="dim", box=box.SIMPLE))
        return layout

    arrow_keys = (kb.KEY_UP, kb.KEY_DOWN, kb.KEY_LEFT, kb.KEY_RIGHT)

    with Live(console=console, screen=True, auto_refresh=False, refresh_per_second=20) as live:
        live.update(build_display(), refresh=True)

        while not finished:
            elapsed = (time.perf_counter() - start_time) if start_time else 0.0

            if mode == "timed" and start_time and elapsed >= duration:
                finished = True
                break

            if mode == "words":
                words_typed = typed.split()
                prompt_words = prompt.split()
                last_word_done = (
                    typed.endswith(" ") or
                    len(typed) >= len(" ".join(prompt_words[:setting]))
                )
                if len(words_typed) >= setting and last_word_done:
                    finished = True
                    break

            if kb.kbhit():
                key = kb.getch()

                if not key or key in arrow_keys:
                    pass

                elif key == kb.KEY_ESC:
                    return {"wpm": 0.0, "accuracy": 0.0, "errors": 0, "typed": "", "prompt": prompt, "aborted": True}

                elif key == kb.KEY_TAB:
                    if mode == "timed":
                        prompt = sample_words(TIMED_WORD_BUFFER)
                    else:
                        prompt = sample_words(setting)
                    typed = ""
                    start_time = None

                elif key == kb.KEY_BACKSPACE:
                    if typed:
                        typed = typed[:-1]

                elif key == kb.KEY_ENTER:
                    if mode == "words":
                        finished = True
                        break

                elif len(key) == 1 and key.isprintable():
                    if start_time is None:
                        start_time = time.perf_counter()
                    if len(typed) < len(prompt):
                        typed += key

                live.update(build_display(), refresh=True)
            else:
                if start_time:
                    live.update(build_display(), refresh=True)
                time.sleep(0.05)

    if not start_time:
        return {"wpm": 0.0, "accuracy": 100.0, "errors": 0, "typed": "", "prompt": prompt, "aborted": False}

    elapsed = time.perf_counter() - start_time
    wpm = calculate_wpm(typed, elapsed)
    accuracy = calculate_accuracy(prompt, typed)
    errors = sum(1 for a, b in zip(prompt, typed) if a != b)

    return {
        "wpm": round(wpm, 1),
        "accuracy": accuracy,
        "errors": errors,
        "typed": typed,
        "prompt": prompt,
        "aborted": False,
        "elapsed": round(elapsed, 1),
    }
