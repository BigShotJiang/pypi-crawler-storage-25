from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.table import Table
from rich import box

from ..db import save_result, get_history, get_personal_best, get_average_wpm
from .. import compat as kb

console = Console()

SPARK_CHARS = "▁▂▃▄▅▆▇█"


def _sparkline(values: list) -> str:
    if not values:
        return ""
    mn, mx = min(values), max(values)
    if mn == mx:
        return SPARK_CHARS[4] * len(values)
    rng = mx - mn
    return "".join(SPARK_CHARS[int((v - mn) / rng * 7)] for v in values)


def show_results(result: dict, con) -> str:
    """Show results screen. Returns 'again' or 'quit'."""
    if not result.get("aborted"):
        save_result(con, result["mode"], result["setting"], result["wpm"], result["accuracy"], result["errors"])

    history = get_history(con, limit=10)
    best = get_personal_best(con)
    avg = get_average_wpm(con, last_n=10)

    console.clear()

    console.print(Panel(
        Text("results", style="bold cyan", justify="center"),
        box=box.DOUBLE, border_style="cyan", padding=(0, 4)
    ))
    console.print()

    if result.get("aborted"):
        console.print(Text("  test aborted", style="bold red"))
        console.print()
    else:
        stats = Text()
        stats.append(f"  WPM      ", style="dim")
        stats.append(f"{result['wpm']:.0f}\n", style="bold cyan")
        stats.append(f"  Accuracy ", style="dim")
        stats.append(f"{result['accuracy']:.0f}%\n", style="bold green")
        stats.append(f"  Errors   ", style="dim")
        stats.append(f"{result['errors']}\n", style="bold red" if result['errors'] > 0 else "bold green")
        stats.append(f"  Mode     ", style="dim")
        mode_label = f"{result['mode']} · {result['setting']}{'s' if result['mode'] == 'timed' else ' words'}"
        stats.append(mode_label, style="bold white")
        console.print(Panel(stats, border_style="blue", box=box.ROUNDED))
        console.print()

    if history:
        wpm_vals = [h["wpm"] for h in reversed(history)]
        spark = _sparkline(wpm_vals)
        hist_text = Text()
        hist_text.append("  last 10  ", style="dim")
        hist_text.append(spark, style="bold cyan")
        hist_text.append(f"\n  best     ", style="dim")
        hist_text.append(f"{best['wpm']:.0f} WPM" if best else "—", style="bold yellow")
        hist_text.append(f"\n  avg      ", style="dim")
        hist_text.append(f"{avg:.0f} WPM", style="bold white")
        console.print(Panel(hist_text, title="[dim]history[/dim]", border_style="dim", box=box.ROUNDED))
        console.print()

    help_text = Text(justify="center")
    help_text.append("ENTER", style="bold green")
    help_text.append("  play again    ", style="dim")
    help_text.append("Q", style="bold red")
    help_text.append("  quit", style="dim")
    console.print(help_text)

    while True:
        key = kb.getch()
        if key == kb.KEY_ENTER:
            return "again"
        if key.lower() == "q":
            return "quit"


def show_history(con) -> None:
    """Show full history table. Press any key to return."""
    history = get_history(con, limit=20)
    console.clear()

    table = Table(title="history", box=box.ROUNDED, border_style="cyan", show_header=True, header_style="bold cyan")
    table.add_column("#", style="dim", width=4)
    table.add_column("WPM", style="bold cyan", width=7)
    table.add_column("Accuracy", style="bold green", width=10)
    table.add_column("Errors", style="bold red", width=8)
    table.add_column("Mode", width=12)
    table.add_column("Date", style="dim", width=20)

    for i, row in enumerate(history, 1):
        table.add_row(
            str(i),
            f"{row['wpm']:.0f}",
            f"{row['accuracy']:.0f}%",
            str(row['errors']),
            f"{row['mode']} {row['setting']}{'s' if row['mode'] == 'timed' else 'w'}",
            row['timestamp'],
        )

    console.print(table)
    console.print()
    console.print(Text("  press any key to go back", style="dim"))
    kb.getch()
