from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich import box

from .. import compat as kb

console = Console()

MODES = ["timed", "words"]
TIMED_SETTINGS = [15, 30, 60]
WORDS_SETTINGS = [10, 25, 50, 100]


def show_home(mode_idx: int = 0, setting_idx: int = 1) -> tuple:
    """Show home screen. Returns (mode, setting) or ('quit', 0) or ('history', 0)."""
    while True:
        mode = MODES[mode_idx]
        settings = TIMED_SETTINGS if mode == "timed" else WORDS_SETTINGS
        setting_idx = min(setting_idx, len(settings) - 1)
        setting = settings[setting_idx]

        console.clear()
        _render_home(mode, mode_idx, settings, setting_idx)

        key = kb.getch()

        if key == kb.KEY_LEFT:
            mode_idx = (mode_idx - 1) % len(MODES)
            setting_idx = 1
        elif key == kb.KEY_RIGHT:
            mode_idx = (mode_idx + 1) % len(MODES)
            setting_idx = 1
        elif key == kb.KEY_UP:
            setting_idx = (setting_idx - 1) % len(settings)
        elif key == kb.KEY_DOWN:
            setting_idx = (setting_idx + 1) % len(settings)
        elif key == kb.KEY_ENTER:
            return (mode, setting)
        elif key.lower() == "q":
            return ("quit", 0)
        elif key.lower() == "h":
            return ("history", 0)


def _render_home(mode: str, mode_idx: int, settings: list, setting_idx: int):
    title = Text("typefast", style="bold cyan", justify="center")
    console.print(Panel(title, box=box.DOUBLE, border_style="cyan", padding=(1, 4)))
    console.print()

    mode_line = Text("  mode:  ", style="dim")
    for i, m in enumerate(MODES):
        if i == mode_idx:
            mode_line.append(f" {m} ", style="bold white on blue")
        else:
            mode_line.append(f" {m} ", style="dim")
        mode_line.append("  ")
    console.print(mode_line)
    console.print()

    label = "  time (s): " if mode == "timed" else "  words:    "
    setting_line = Text(label, style="dim")
    for i, s in enumerate(settings):
        if i == setting_idx:
            setting_line.append(f" {s} ", style="bold white on blue")
        else:
            setting_line.append(f" {s} ", style="dim")
        setting_line.append("  ")
    console.print(setting_line)
    console.print()
    console.print()

    help_text = Text(justify="center")
    help_text.append("← →", style="bold yellow")
    help_text.append("  switch mode    ", style="dim")
    help_text.append("↑ ↓", style="bold yellow")
    help_text.append("  change setting    ", style="dim")
    help_text.append("ENTER", style="bold green")
    help_text.append("  start    ", style="dim")
    help_text.append("H", style="bold cyan")
    help_text.append("  history    ", style="dim")
    help_text.append("Q", style="bold red")
    help_text.append("  quit", style="dim")
    console.print(help_text)
