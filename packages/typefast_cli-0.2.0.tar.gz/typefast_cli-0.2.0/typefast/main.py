from rich.console import Console

from .db import init_db
from .compat import raw_mode
from .screens.home import show_home, MODES, TIMED_SETTINGS, WORDS_SETTINGS
from .screens.test import run_test
from .screens.results import show_results, show_history

console = Console()


def main():
    con = init_db()
    mode_idx = 0
    setting_idx = 1

    try:
        with raw_mode():
            while True:
                action = show_home(mode_idx, setting_idx)

                if action[0] == "quit":
                    break

                if action[0] == "history":
                    show_history(con)
                    continue

                mode, setting = action

                mode_idx = MODES.index(mode)
                settings = TIMED_SETTINGS if mode == "timed" else WORDS_SETTINGS
                setting_idx = settings.index(setting) if setting in settings else 1

                result = run_test(mode, setting)
                result["mode"] = mode
                result["setting"] = setting

                next_action = show_results(result, con)
                if next_action == "quit":
                    break

    except KeyboardInterrupt:
        pass
    finally:
        con.close()
        console.clear()
        console.print("[bold cyan]thanks for typing! bye.[/bold cyan]")


if __name__ == "__main__":
    main()
