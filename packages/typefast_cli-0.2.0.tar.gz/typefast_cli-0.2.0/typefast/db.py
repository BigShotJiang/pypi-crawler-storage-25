import sqlite3
from pathlib import Path

DB_PATH = Path.home() / ".typefast.db"

def init_db() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("""
        CREATE TABLE IF NOT EXISTS results (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            mode      TEXT NOT NULL,
            setting   INTEGER NOT NULL,
            wpm       REAL NOT NULL,
            accuracy  REAL NOT NULL,
            errors    INTEGER NOT NULL,
            timestamp TEXT DEFAULT (datetime('now','localtime'))
        )
    """)
    con.commit()
    return con

def save_result(con: sqlite3.Connection, mode: str, setting: int, wpm: float, accuracy: float, errors: int):
    con.execute(
        "INSERT INTO results (mode, setting, wpm, accuracy, errors) VALUES (?, ?, ?, ?, ?)",
        (mode, setting, round(wpm, 1), round(accuracy, 1), errors)
    )
    con.commit()

def get_history(con: sqlite3.Connection, limit: int = 10) -> list:
    cur = con.execute(
        "SELECT * FROM results ORDER BY timestamp DESC LIMIT ?", (limit,)
    )
    return [dict(row) for row in cur.fetchall()]

def get_personal_best(con: sqlite3.Connection) -> dict | None:
    cur = con.execute("SELECT * FROM results ORDER BY wpm DESC LIMIT 1")
    row = cur.fetchone()
    return dict(row) if row else None

def get_average_wpm(con: sqlite3.Connection, last_n: int = 10) -> float:
    cur = con.execute(
        "SELECT AVG(wpm) FROM (SELECT wpm FROM results ORDER BY timestamp DESC LIMIT ?)", (last_n,)
    )
    result = cur.fetchone()[0]
    return round(result, 1) if result else 0.0
