"""Cross-platform raw keyboard input for terminal apps.

Provides `getch()`, `kbhit()`, and a `raw_mode` context manager that work
identically on Windows (via msvcrt) and Unix/macOS (via termios + tty + select).
"""

import sys

WINDOWS = sys.platform == "win32"

KEY_ESC = "<ESC>"
KEY_ENTER = "<ENTER>"
KEY_BACKSPACE = "<BACKSPACE>"
KEY_TAB = "<TAB>"
KEY_UP = "<UP>"
KEY_DOWN = "<DOWN>"
KEY_LEFT = "<LEFT>"
KEY_RIGHT = "<RIGHT>"


if WINDOWS:
    import msvcrt

    _WIN_SPECIAL = {
        b"H": KEY_UP,
        b"P": KEY_DOWN,
        b"K": KEY_LEFT,
        b"M": KEY_RIGHT,
    }

    class raw_mode:
        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

    def kbhit() -> bool:
        return bool(msvcrt.kbhit())

    def getch() -> str:
        ch = msvcrt.getch()
        if ch in (b"\x00", b"\xe0"):
            ch2 = msvcrt.getch()
            return _WIN_SPECIAL.get(ch2, "")
        if ch == b"\r":
            return KEY_ENTER
        if ch == b"\x08":
            return KEY_BACKSPACE
        if ch == b"\x1b":
            return KEY_ESC
        if ch == b"\t":
            return KEY_TAB
        try:
            return ch.decode("utf-8")
        except UnicodeDecodeError:
            return ""

else:
    import os
    import tty
    import termios
    import select

    _UNIX_ARROWS = {
        "A": KEY_UP,
        "B": KEY_DOWN,
        "D": KEY_LEFT,
        "C": KEY_RIGHT,
    }

    class raw_mode:
        """Put the terminal into cbreak mode for the duration of the block."""

        def __enter__(self):
            self.fd = sys.stdin.fileno()
            self.old = termios.tcgetattr(self.fd)
            tty.setcbreak(self.fd)
            return self

        def __exit__(self, *args):
            termios.tcsetattr(self.fd, termios.TCSADRAIN, self.old)
            return False

    def kbhit() -> bool:
        return bool(select.select([sys.stdin], [], [], 0)[0])

    def _read_byte() -> str:
        return os.read(sys.stdin.fileno(), 1).decode("utf-8", errors="replace")

    def getch() -> str:
        ch = _read_byte()
        if ch == "\x1b":
            if select.select([sys.stdin], [], [], 0.05)[0]:
                ch2 = _read_byte()
                if ch2 == "[":
                    if select.select([sys.stdin], [], [], 0.05)[0]:
                        ch3 = _read_byte()
                        return _UNIX_ARROWS.get(ch3, "")
                return ""
            return KEY_ESC
        if ch in ("\r", "\n"):
            return KEY_ENTER
        if ch in ("\x7f", "\x08"):
            return KEY_BACKSPACE
        if ch == "\t":
            return KEY_TAB
        return ch
