import json
import random
from pathlib import Path

_WORDS_FILE = Path(__file__).parent / "words.json"
with open(_WORDS_FILE) as f:
    WORD_LIST = json.load(f)

def sample_words(n: int) -> str:
    return " ".join(random.choices(WORD_LIST, k=n))

def calculate_wpm(typed: str, elapsed: float) -> float:
    if elapsed <= 0:
        return 0.0
    return (len(typed) / 5.0) / (elapsed / 60.0)

def calculate_accuracy(prompt: str, typed: str) -> float:
    if not typed:
        return 100.0
    compare_len = min(len(prompt), len(typed))
    correct = sum(1 for a, b in zip(prompt[:compare_len], typed[:compare_len]) if a == b)
    return round((correct / compare_len) * 100, 1)
