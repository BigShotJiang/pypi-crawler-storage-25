# typefast

A minimal terminal typing speed test, inspired by Monkeytype.

## Install

```
pip install typefast
```

## Usage

```
typefast
```

## Features

- Timed mode (15s / 30s / 60s) and word count mode (10 / 25 / 50 / 100 words)
- Live WPM and accuracy as you type
- Green / red character feedback
- Tab to restart, Esc to quit
- Persistent stats saved locally — personal best, average WPM, history sparkline

## Controls

| Key | Action |
|-----|--------|
| `← →` | Switch mode |
| `↑ ↓` | Change setting |
| `Enter` | Start test |
| `Tab` | Restart test |
| `Esc` | Quit test |
| `H` | View history |
| `Q` | Quit |

## Requirements

- Python 3.10+
- Works on Windows, macOS, and Linux
