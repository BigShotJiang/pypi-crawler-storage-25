# SPDX-License-Identifier: AGPL-3.0-or-later
# Copyright (C) 2026 João Tonini
"""
Signal readers for the NØMAD Insight Engine.

Each reader queries a specific data source (jobs, disk, GPU, network,
TESSERA, derivatives, alerts) and returns typed Signal objects that
the engine can interpret and narrate.
"""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Optional


class SignalType(Enum):
    """Categories of operational signals."""
    DISK = "disk"
    GPU = "gpu"
    NETWORK = "network"
    JOBS = "jobs"
    MEMORY = "memory"
    QUEUE = "queue"
    TESSERA = "tessera"
    DERIVATIVE = "derivative"
    ALERT = "alert"
    CLOUD = "cloud"
    INTERACTIVE = "interactive"
    DYNAMICS = "dynamics"


class Severity(Enum):
    """Signal severity levels."""
    INFO = "info"
    NOTICE = "notice"
    WARNING = "warning"
    CRITICAL = "critical"


@dataclass
class Signal:
    """A single operational signal extracted from NØMAD data."""
    signal_type: SignalType
    severity: Severity
    title: str
    detail: str
    metrics: dict[str, Any] = field(default_factory=dict)
    affected_entities: list[str] = field(default_factory=list)
    timestamp: datetime | None = None
    tags: dict[str, str] = field(default_factory=dict)

    @property
    def key(self) -> str:
        """Unique key for deduplication and correlation."""
        return f"{self.signal_type.value}:{self.title}"


def _get_conn(db_path: Path) -> sqlite3.Connection:
    """Open a read-only connection."""
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    return conn


# ── Job signals ──────────────────────────────────────────────────────────

def read_job_signals(db_path: Path, hours: int = 24) -> list[Signal]:
    """Analyze recent job outcomes for failure patterns."""
    signals: list[Signal] = []
    conn = _get_conn(db_path)
    cutoff = (datetime.now() - timedelta(hours=hours)).isoformat()

    try:
        # Overall success rate
        row = conn.execute("""
            SELECT COUNT(*) as total,
                   SUM(CASE WHEN state = 'COMPLETED' THEN 1 ELSE 0 END) as completed,
                   SUM(CASE WHEN state = 'FAILED' THEN 1 ELSE 0 END) as failed,
                   SUM(CASE WHEN state = 'TIMEOUT' THEN 1 ELSE 0 END) as timed_out,
                   SUM(CASE WHEN state = 'OUT_OF_MEMORY' THEN 1 ELSE 0 END) as oom
            FROM jobs WHERE end_time >= ?
        """, (cutoff,)).fetchone()

        if row and row["total"] > 0:
            total = row["total"]
            failed = row["failed"] or 0
            timed_out = row["timed_out"] or 0
            oom = row["oom"] or 0
            success_rate = ((row["completed"] or 0) / total) * 100

            if success_rate < 80:
                sev = Severity.CRITICAL
            elif success_rate < 90:
                sev = Severity.WARNING
            elif success_rate < 95:
                sev = Severity.NOTICE
            else:
                sev = Severity.INFO

            signals.append(Signal(
                signal_type=SignalType.JOBS,
                severity=sev,
                title="job_success_rate",
                detail=f"{total} jobs in the last {hours}h, {success_rate:.1f}% success rate",
                metrics={
                    "total": total, "success_rate": success_rate,
                    "failed": failed, "timed_out": timed_out, "oom": oom,
                    "hours": hours,
                },
            ))

            # Failure concentration by partition
            partitions = conn.execute("""
                SELECT partition, COUNT(*) as cnt
                FROM jobs
                WHERE end_time >= ? AND state IN ('FAILED', 'TIMEOUT', 'OUT_OF_MEMORY')
                GROUP BY partition ORDER BY cnt DESC LIMIT 3
            """, (cutoff,)).fetchall()

            for p in partitions:
                pct = (p["cnt"] / total) * 100
                if pct > 5:
                    signals.append(Signal(
                        signal_type=SignalType.JOBS,
                        severity=Severity.WARNING if pct > 10 else Severity.NOTICE,
                        title="partition_failure_concentration",
                        detail=f"Partition '{p['partition']}': {p['cnt']} failures ({pct:.1f}% of all jobs)",
                        metrics={"partition": p["partition"], "failures": p["cnt"], "pct": pct},
                        affected_entities=[p["partition"]],
                        tags={"partition": p["partition"]},
                    ))

            # OOM-specific signal
            if oom > 0:
                oom_users = conn.execute("""
                    SELECT user_name as username, COUNT(*) as cnt
                    FROM jobs
                    WHERE end_time >= ? AND state = 'OUT_OF_MEMORY'
                    GROUP BY user_name ORDER BY cnt DESC LIMIT 3
                """, (cutoff,)).fetchall()
                users = [f"{u['username']} ({u['cnt']})" for u in oom_users]
                signals.append(Signal(
                    signal_type=SignalType.MEMORY,
                    severity=Severity.WARNING if oom > 3 else Severity.NOTICE,
                    title="oom_failures",
                    detail=f"{oom} out-of-memory failures in the last {hours}h",
                    metrics={"oom_count": oom, "top_users": users},
                    affected_entities=[u["username"] for u in oom_users],
                ))

            # Timeout signal
            if timed_out > 2:
                signals.append(Signal(
                    signal_type=SignalType.JOBS,
                    severity=Severity.WARNING if timed_out > 5 else Severity.NOTICE,
                    title="timeout_failures",
                    detail=f"{timed_out} jobs timed out in the last {hours}h",
                    metrics={"timeout_count": timed_out, "hours": hours},
                ))

        # Compare to previous period
        prev_cutoff = (datetime.now() - timedelta(hours=hours * 2)).isoformat()
        prev = conn.execute("""
            SELECT COUNT(*) as total,
                   SUM(CASE WHEN state = 'COMPLETED' THEN 1 ELSE 0 END) as completed
            FROM jobs WHERE end_time >= ? AND end_time < ?
        """, (prev_cutoff, cutoff)).fetchone()

        if prev and prev["total"] > 10 and row and row["total"] > 10:
            prev_rate = ((prev["completed"] or 0) / prev["total"]) * 100
            curr_rate = success_rate
            delta = curr_rate - prev_rate
            if abs(delta) > 3:
                direction = "improving" if delta > 0 else "degrading"
                signals.append(Signal(
                    signal_type=SignalType.JOBS,
                    severity=Severity.INFO if delta > 0 else Severity.WARNING,
                    title="job_rate_trend",
                    detail=f"Success rate {direction}: {prev_rate:.1f}% -> {curr_rate:.1f}% ({delta:+.1f}pp)",
                    metrics={"previous_rate": prev_rate, "current_rate": curr_rate, "delta": delta},
                ))

    except sqlite3.OperationalError:
        pass
    finally:
        conn.close()

    return signals


# ── Disk / storage signals ───────────────────────────────────────────────

def read_disk_signals(db_path: Path, hours: int = 6) -> list[Signal]:
    """Check storage filesystem trends."""
    signals: list[Signal] = []
    conn = _get_conn(db_path)
    cutoff = (datetime.now() - timedelta(hours=hours)).isoformat()

    try:
        # Get latest storage readings per server
        rows = conn.execute("""
            SELECT s1.hostname, s1.usage_percent,
                   (s1.total_bytes/1073741824.0) as total_gb,
                   (s1.used_bytes/1073741824.0) as used_gb,
                   (s1.free_bytes/1073741824.0) as free_gb,
                   s1.timestamp
            FROM storage_state s1
            INNER JOIN (
                SELECT hostname, MAX(timestamp) as max_ts
                FROM storage_state GROUP BY hostname
            ) s2 ON s1.hostname = s2.hostname
                 
                 AND s1.timestamp = s2.max_ts
        """).fetchall()

        for r in rows:
            usage = r["usage_percent"]
            if usage >= 90:
                sev = Severity.CRITICAL
            elif usage >= 80:
                sev = Severity.WARNING
            elif usage >= 70:
                sev = Severity.NOTICE
            else:
                continue  # Only signal notable usage

            signals.append(Signal(
                signal_type=SignalType.DISK,
                severity=sev,
                title="filesystem_usage",
                detail=f"{r['hostname']} at {usage:.0f}% ({r['free_gb']:.1f} GB free)",
                metrics={
                    "server": r["hostname"], 
                    "usage_pct": usage, "avail_gb": r["free_gb"], "free_gb": r["free_gb"],
                    "total_gb": r["total_gb"],
                },
                affected_entities=[r["hostname"]],
                tags={"server": r["hostname"]},
            ))

        # Fill rate estimation (needs 2+ data points)
        for r in rows:
            history = conn.execute("""
                SELECT timestamp, usage_percent as usage_pct FROM storage_state
                WHERE server_name = ? AND filesystem = ?
                  AND timestamp >= ?
                ORDER BY timestamp
            """, (r["hostname"], cutoff)).fetchall()

            if len(history) >= 2:
                first = history[0]
                last = history[-1]
                try:
                    t0 = datetime.fromisoformat(first["timestamp"])
                    t1 = datetime.fromisoformat(last["timestamp"])
                    dt_hours = (t1 - t0).total_seconds() / 3600
                    if dt_hours > 0:
                        rate_pct_per_hour = (last["usage_pct"] - first["usage_pct"]) / dt_hours
                        if rate_pct_per_hour > 0.5:  # Growing meaningfully
                            remaining_pct = 100 - last["usage_pct"]
                            hours_to_full = remaining_pct / rate_pct_per_hour if rate_pct_per_hour > 0 else float('inf')
                            if hours_to_full < 48:
                                total_gb = r["total_gb"] or 1
                                fill_rate_gb = (rate_pct_per_hour / 100) * total_gb
                                signals.append(Signal(
                                    signal_type=SignalType.DISK,
                                    severity=Severity.CRITICAL if hours_to_full < 12 else Severity.WARNING,
                                    title="disk_fill_projection",
                                    detail=f"{r['server_name']}:{r.get('storage_type', '')} filling at {fill_rate_gb:.1f} GB/hr, projected full in {hours_to_full:.0f}h",
                                    metrics={
                                        "server": r["hostname"], "hostname": r["hostname"],
                                        "fill_rate_gb_hr": fill_rate_gb,
                                        "hours_to_full": hours_to_full,
                                    },
                                    affected_entities=[r["hostname"]],
                                    tags={"server": r["hostname"]},
                                ))
                except (ValueError, TypeError):
                    pass

    except sqlite3.OperationalError:
        pass
    finally:
        conn.close()

    return signals


# ── GPU signals ──────────────────────────────────────────────────────────

def read_gpu_signals(db_path: Path, hours: int = 24) -> list[Signal]:
    """Analyze GPU utilization and memory patterns."""
    signals: list[Signal] = []
    conn = _get_conn(db_path)
    cutoff = (datetime.now() - timedelta(hours=hours)).isoformat()

    try:
        # GPU utilization from jobs requesting GPUs
        gpu_jobs = conn.execute("""
            SELECT COUNT(*) as total,
                   SUM(CASE WHEN state = 'FAILED' THEN 1 ELSE 0 END) as failed,
                   SUM(CASE WHEN state = 'OUT_OF_MEMORY' THEN 1 ELSE 0 END) as oom,
                   AVG(CAST(req_gpus AS REAL)) as avg_gpus
            FROM jobs
            WHERE end_time >= ? AND req_gpus > 0
        """, (cutoff,)).fetchone()

        if gpu_jobs and gpu_jobs["total"] > 0:
            total = gpu_jobs["total"]
            failed = gpu_jobs["failed"] or 0
            oom = gpu_jobs["oom"] or 0
            fail_rate = (failed / total) * 100

            if fail_rate > 20:
                signals.append(Signal(
                    signal_type=SignalType.GPU,
                    severity=Severity.WARNING,
                    title="gpu_job_failure_rate",
                    detail=f"{fail_rate:.0f}% of GPU jobs failed in the last {hours}h ({failed}/{total})",
                    metrics={"total_gpu_jobs": total, "failed": failed, "fail_rate": fail_rate},
                ))

            if oom > 0:
                signals.append(Signal(
                    signal_type=SignalType.GPU,
                    severity=Severity.WARNING if oom > 2 else Severity.NOTICE,
                    title="gpu_oom",
                    detail=f"{oom} GPU jobs ran out of memory — possible VRAM limitation",
                    metrics={"gpu_oom_count": oom, "total_gpu_jobs": total},
                ))

    except sqlite3.OperationalError:
        pass
    finally:
        conn.close()

    return signals


# ── Queue signals ────────────────────────────────────────────────────────

def read_queue_signals(db_path: Path, hours: int = 6) -> list[Signal]:
    """Analyze job queue pressure and wait times."""
    signals: list[Signal] = []
    conn = _get_conn(db_path)
    cutoff = (datetime.now() - timedelta(hours=hours)).isoformat()

    try:
        # Queue depth from queue_state table
        latest = conn.execute("""
            SELECT partition, pending_jobs, running_jobs, total_jobs, timestamp
            FROM queue_state
            WHERE timestamp >= ?
            ORDER BY timestamp DESC
        """, (cutoff,)).fetchall()

        # Deduplicate to latest per partition
        seen: dict[str, sqlite3.Row] = {}
        for r in latest:
            if r["partition"] not in seen:
                seen[r["partition"]] = r

        for partition, r in seen.items():
            pending = r["pending_jobs"] or 0
            running = r["running_jobs"] or 0
            if pending > 0 and running > 0:
                ratio = pending / running
                if ratio > 2:
                    signals.append(Signal(
                        signal_type=SignalType.QUEUE,
                        severity=Severity.WARNING if ratio > 5 else Severity.NOTICE,
                        title="queue_pressure",
                        detail=f"Partition '{partition}': {pending} pending vs {running} running (ratio {ratio:.1f}x)",
                        metrics={"partition": partition, "pending": pending, "running": running, "ratio": ratio},
                        affected_entities=[partition],
                        tags={"partition": partition},
                    ))

        # Average wait time from jobs
        wait_rows = conn.execute("""
            SELECT partition, AVG(wait_time_seconds) as avg_wait, MAX(wait_time_seconds) as max_wait
            FROM jobs
            WHERE end_time >= ? AND wait_time_seconds IS NOT NULL
            GROUP BY partition
        """, (cutoff,)).fetchall()

        for w in wait_rows:
            avg_wait = w["avg_wait"] or 0
            max_wait = w["max_wait"] or 0
            if avg_wait > 3600:  # > 1 hour average wait
                signals.append(Signal(
                    signal_type=SignalType.QUEUE,
                    severity=Severity.WARNING if avg_wait > 7200 else Severity.NOTICE,
                    title="high_wait_time",
                    detail=f"Partition '{w['partition']}': average wait {avg_wait/3600:.1f}h (max {max_wait/3600:.1f}h)",
                    metrics={
                        "partition": w["partition"],
                        "avg_wait_sec": avg_wait, "max_wait_sec": max_wait,
                    },
                    affected_entities=[w["partition"]],
                    tags={"partition": w["partition"]},
                ))

    except sqlite3.OperationalError:
        pass
    finally:
        conn.close()

    return signals


# ── Network signals ──────────────────────────────────────────────────────

def read_network_signals(db_path: Path, hours: int = 6) -> list[Signal]:
    """Check for network anomalies."""
    signals: list[Signal] = []
    conn = _get_conn(db_path)
    cutoff = (datetime.now() - timedelta(hours=hours)).isoformat()

    try:
        rows = conn.execute("""
            SELECT source_host || '->' || dest_host as path, AVG(ping_avg_ms) as avg_latency,
                   MAX(ping_avg_ms) as max_latency,
                   AVG(ping_loss_pct) as avg_loss,
                   MAX(ping_loss_pct) as max_loss
            FROM network_perf
            WHERE timestamp >= ?
            GROUP BY source_host, dest_host
        """, (cutoff,)).fetchall()

        for r in rows:
            if (r["avg_latency"] or 0) > 5:
                signals.append(Signal(
                    signal_type=SignalType.NETWORK,
                    severity=Severity.WARNING if r["avg_latency"] > 20 else Severity.NOTICE,
                    title="high_network_latency",
                    detail=f"Path '{r['path']}': avg latency {r['avg_latency']:.1f}ms (peak {r['max_latency']:.1f}ms)",
                    metrics={"path": r["path"], "avg_latency": r["avg_latency"], "max_latency": r["max_latency"]},
                    affected_entities=[r["path"]],
                ))

            if (r["avg_loss"] or 0) > 0.1:
                signals.append(Signal(
                    signal_type=SignalType.NETWORK,
                    severity=Severity.CRITICAL if r["avg_loss"] > 1 else Severity.WARNING,
                    title="packet_loss",
                    detail=f"Path '{r['path']}': {r['avg_loss']:.2f}% average packet loss",
                    metrics={"path": r["path"], "avg_loss": r["avg_loss"], "max_loss": r["max_loss"]},
                    affected_entities=[r["path"]],
                ))

    except sqlite3.OperationalError:
        pass
    finally:
        conn.close()

    return signals


# ── Alert signals ────────────────────────────────────────────────────────

def read_alert_signals(db_path: Path, hours: int = 24) -> list[Signal]:
    """Read active/recent alerts from the alerts table."""
    signals: list[Signal] = []
    conn = _get_conn(db_path)
    cutoff = (datetime.now() - timedelta(hours=hours)).isoformat()

    try:
        rows = conn.execute("""
            SELECT severity, source as metric, host, message,
                   details, timestamp, resolved
            FROM alerts
            WHERE timestamp >= ?
            ORDER BY timestamp DESC
        """, (cutoff,)).fetchall()

        unresolved = [r for r in rows if not r["resolved"]]
        resolved = [r for r in rows if r["resolved"]]

        if unresolved:
            # Group by severity
            crit = [r for r in unresolved if r["severity"] == "critical"]
            warn = [r for r in unresolved if r["severity"] == "warning"]

            signals.append(Signal(
                signal_type=SignalType.ALERT,
                severity=Severity.CRITICAL if crit else Severity.WARNING,
                title="active_alerts",
                detail=f"{len(unresolved)} active alerts ({len(crit)} critical, {len(warn)} warning)",
                metrics={
                    "total_active": len(unresolved),
                    "critical": len(crit),
                    "warning": len(warn),
                    "resolved_recently": len(resolved),
                },
            ))

        # Flapping detection: alerts that resolved and re-triggered
        metrics_seen: dict[str, int] = {}
        for r in rows:
            m = r["metric"] or "unknown"
            metrics_seen[m] = metrics_seen.get(m, 0) + 1

        flap_threshold = max(3, (hours // 24) * 3)
        for metric, count in metrics_seen.items():
            if count >= flap_threshold:
                signals.append(Signal(
                    signal_type=SignalType.ALERT,
                    severity=Severity.WARNING,
                    title="flapping_alert",
                    detail=f"Alert on '{metric}' triggered {count} times in {hours}h — possible flapping",
                    metrics={"metric": metric, "trigger_count": count},
                    affected_entities=[metric],
                ))

    except sqlite3.OperationalError:
        pass
    finally:
        conn.close()

    return signals


# ── Cloud signals ────────────────────────────────────────────────────────

def read_cloud_signals(db_path: Path, hours: int = 24) -> list[Signal]:
    """Analyze cloud instance metrics for cost and performance signals."""
    signals: list[Signal] = []
    conn = _get_conn(db_path)
    cutoff = (datetime.now() - timedelta(hours=hours)).isoformat()

    try:
        # Cost trend
        cost_rows = conn.execute("""
            SELECT SUM(value) as total_cost
            FROM cloud_metrics
            WHERE metric_name = 'cost_usd_per_day' AND timestamp >= ?
        """, (cutoff,)).fetchone()

        if cost_rows and cost_rows["total_cost"]:
            total = cost_rows["total_cost"]
            signals.append(Signal(
                signal_type=SignalType.CLOUD,
                severity=Severity.INFO,
                title="cloud_cost_summary",
                detail=f"Cloud spending: ${total:.2f} in the last {hours}h",
                metrics={"total_cost_usd": total, "hours": hours},
            ))

        # Underutilized instances
        underused = conn.execute("""
            SELECT node_name, AVG(value) as avg_cpu
            FROM cloud_metrics
            WHERE metric_name = 'cpu_utilization' AND timestamp >= ?
            GROUP BY node_name
            HAVING avg_cpu < 15
        """, (cutoff,)).fetchall()

        for u in underused:
            signals.append(Signal(
                signal_type=SignalType.CLOUD,
                severity=Severity.NOTICE,
                title="underutilized_cloud_instance",
                detail=f"Instance '{u['node_name']}' averaging {u['avg_cpu']:.1f}% CPU — consider downsizing",
                metrics={"instance": u["node_name"], "avg_cpu": u["avg_cpu"]},
                affected_entities=[u["node_name"]],
            ))

    except sqlite3.OperationalError:
        pass
    finally:
        conn.close()

    return signals


# ── Workstation signals ──────────────────────────────────────────────────

def read_workstation_signals(db_path: Path, hours: int = 6) -> list[Signal]:
    """Check workstation health."""
    signals: list[Signal] = []
    conn = _get_conn(db_path)
    cutoff = (datetime.now() - timedelta(hours=hours)).isoformat()

    try:
        rows = conn.execute("""
            SELECT hostname,
                   AVG(cpu_percent) as avg_cpu,
                   AVG(memory_percent) as avg_mem,
                   MAX(cpu_percent) as max_cpu,
                   MAX(memory_percent) as max_mem
            FROM workstation_state
            WHERE timestamp >= ?
            GROUP BY hostname
        """, (cutoff,)).fetchall()

        for r in rows:
            if (r["avg_cpu"] or 0) > 80:
                signals.append(Signal(
                    signal_type=SignalType.MEMORY,
                    severity=Severity.WARNING if r["avg_cpu"] > 90 else Severity.NOTICE,
                    title="workstation_high_cpu",
                    detail=f"Workstation '{r['hostname']}': avg CPU {r['avg_cpu']:.0f}% (peak {r['max_cpu']:.0f}%)",
                    metrics={"hostname": r["hostname"], "avg_cpu": r["avg_cpu"]},
                    affected_entities=[r["hostname"]],
                ))

            if (r["avg_mem"] or 0) > 85:
                signals.append(Signal(
                    signal_type=SignalType.MEMORY,
                    severity=Severity.WARNING if r["avg_mem"] > 95 else Severity.NOTICE,
                    title="workstation_high_memory",
                    detail=f"Workstation '{r['hostname']}': avg memory {r['avg_mem']:.0f}% (peak {r['max_mem']:.0f}%)",
                    metrics={"hostname": r["hostname"], "avg_mem": r["avg_mem"]},
                    affected_entities=[r["hostname"]],
                ))

    except sqlite3.OperationalError:
        pass
    finally:
        conn.close()

    return signals


# ── Master reader ────────────────────────────────────────────────────────


def read_dynamics_signals(db_path: Path, hours: int = 168) -> list[Signal]:
    """Read system dynamics metrics and convert notable findings to signals."""
    signals: list[Signal] = []

    try:
        from nomad.dynamics.diversity import compute_diversity
        div = compute_diversity(db_path, dimension="group", hours=hours)

        # Fragility warning
        if div.fragility_warning:
            signals.append(Signal(
                signal_type=SignalType.DYNAMICS,
                severity=Severity.WARNING,
                title="diversity_fragility",
                detail=div.fragility_detail,
                metrics={
                    "shannon_h": div.current.shannon_h,
                    "dominant": div.current.dominant_category,
                    "dominant_proportion": div.current.dominant_proportion,
                    "trend": div.trend_direction,
                },
            ))

        # Diversity declining
        if div.trend_direction == "decreasing" and abs(div.trend_slope) > 0.01:
            signals.append(Signal(
                signal_type=SignalType.DYNAMICS,
                severity=Severity.NOTICE,
                title="diversity_declining",
                detail=(
                    f"Workload diversity is declining "
                    f"(slope: {div.trend_slope:.4f}/window). "
                    f"Current H'={div.current.shannon_h:.3f}."
                ),
                metrics={
                    "shannon_h": div.current.shannon_h,
                    "slope": div.trend_slope,
                },
            ))
    except Exception:
        pass

    try:
        from nomad.dynamics.capacity import compute_capacity
        cap = compute_capacity(db_path, hours=hours)

        if cap.binding_constraint:
            bc = cap.binding_constraint
            sev = Severity.CRITICAL if bc.current_utilization >= 0.9 else \
                  Severity.WARNING if bc.current_utilization >= 0.75 else \
                  Severity.NOTICE

            signals.append(Signal(
                signal_type=SignalType.DYNAMICS,
                severity=sev,
                title="capacity_binding_constraint",
                detail=(
                    f"{bc.label} is the binding constraint at "
                    f"{bc.current_utilization:.0%} utilization."
                ),
                metrics={
                    "dimension": bc.dimension,
                    "label": bc.label,
                    "utilization": bc.current_utilization,
                    "pressure": cap.overall_pressure,
                    "hours_to_saturation": bc.hours_to_saturation,
                },
            ))

            # Saturation warning
            if bc.hours_to_saturation and bc.hours_to_saturation < 48:
                signals.append(Signal(
                    signal_type=SignalType.DYNAMICS,
                    severity=Severity.CRITICAL,
                    title="capacity_saturation_imminent",
                    detail=(
                        f"{bc.label} projected to reach saturation "
                        f"in {bc.hours_to_saturation:.0f} hours "
                        f"at current growth rate."
                    ),
                    metrics={
                        "dimension": bc.dimension,
                        "hours_to_saturation": bc.hours_to_saturation,
                    },
                ))
    except Exception:
        pass

    try:
        from nomad.dynamics.niche import compute_niche_overlap
        niche = compute_niche_overlap(db_path, hours=hours)

        if niche.high_overlap_pairs:
            high_count = len([p for p in niche.high_overlap_pairs if p.contention_risk == "high"])
            if high_count > 0:
                top = niche.high_overlap_pairs[0]
                signals.append(Signal(
                    signal_type=SignalType.DYNAMICS,
                    severity=Severity.WARNING if high_count >= 3 else Severity.NOTICE,
                    title="niche_contention_risk",
                    detail=(
                        f"{high_count} high-overlap group pair(s) detected. "
                        f"Highest: {top.group_a} <-> {top.group_b} "
                        f"(O={top.overlap:.2f})."
                    ),
                    metrics={
                        "high_overlap_count": high_count,
                        "top_pair_a": top.group_a,
                        "top_pair_b": top.group_b,
                        "top_overlap": top.overlap,
                    },
                ))
    except Exception:
        pass

    try:
        from nomad.dynamics.resilience import compute_resilience
        res = compute_resilience(db_path, hours=max(hours, 720))

        if res.resilience_score < 50:
            signals.append(Signal(
                signal_type=SignalType.DYNAMICS,
                severity=Severity.WARNING,
                title="resilience_low",
                detail=(
                    f"Cluster resilience score is {res.resilience_score:.0f}/100. "
                    f"{res.summary}"
                ),
                metrics={
                    "score": res.resilience_score,
                    "trend": res.resilience_trend,
                    "mean_recovery_hours": res.mean_recovery_hours,
                },
            ))

        if res.resilience_trend == "degrading":
            signals.append(Signal(
                signal_type=SignalType.DYNAMICS,
                severity=Severity.NOTICE,
                title="resilience_degrading",
                detail=(
                    f"Cluster resilience is degrading — recovery times "
                    f"are increasing over time. Score: {res.resilience_score:.0f}/100."
                ),
                metrics={
                    "score": res.resilience_score,
                    "trend": "degrading",
                },
            ))
    except Exception:
        pass

    try:
        from nomad.dynamics.externality import compute_externalities
        ext = compute_externalities(db_path, hours=hours)

        if ext.top_imposers:
            signals.append(Signal(
                signal_type=SignalType.DYNAMICS,
                severity=Severity.NOTICE,
                title="externality_detected",
                detail=(
                    f"{len(ext.edges)} inter-group impact relationship(s). "
                    f"Top imposer(s): {', '.join(ext.top_imposers[:2])}."
                ),
                metrics={
                    "edge_count": len(ext.edges),
                    "top_imposers": ext.top_imposers[:3],
                    "top_receivers": ext.top_receivers[:3],
                },
            ))
    except Exception:
        pass

    return signals


# ── Network analytics signals ────────────────────────────────────────────

def read_network_analytics_signals(db_path: Path, hours: int = 24) -> list[Signal]:
    """Analyze job similarity network structure for clustering patterns."""
    signals: list[Signal] = []

    try:
        from nomad.viz.server import (
            load_jobs_from_db,
            build_similarity_network,
            compute_clustering_quality,
            compute_failure_hotspots,
            compute_correlation_matrix,
        )

        jobs = load_jobs_from_db(db_path, limit=2000)
        if not jobs or len(jobs) < 20:
            return signals

        network_result = build_similarity_network(jobs, threshold=0.90)
        edges = network_result.get("edges", [])
        if not edges:
            return signals

        quality = compute_clustering_quality(jobs, edges)
        if quality.get("error"):
            return signals

        assort = quality.get("assortativity", {})
        assort_val = assort.get("binary", 0) if isinstance(assort, dict) else 0
        assort_z = assort.get("z_score", 0) if isinstance(assort, dict) else 0
        mntd = quality.get("mntd_ratio", 1.0)
        ses_mntd = quality.get("ses_mntd", 0)
        purity = quality.get("neighborhood_purity", {})
        purity_val = purity.get("binary", 0) if isinstance(purity, dict) else 0
        is_clustered = quality.get("is_clustered", False)
        n_jobs = quality.get("sample_sizes", {}).get("n_jobs", 0)
        n_edges = quality.get("sample_sizes", {}).get("n_edges", 0)
        n_failure = quality.get("sample_sizes", {}).get("n_failure", 0)

        if is_clustered:
            signals.append(Signal(
                signal_type=SignalType.JOBS,
                severity=Severity.WARNING if assort_z > 3 else Severity.NOTICE,
                title="failure_clustering",
                detail=(
                    f"Job failures are clustering in the similarity network "
                    f"(assortativity r={assort_val}, z={assort_z}). "
                    f"Failures are not random -- they share common resource patterns."
                ),
                metrics={
                    "assortativity": assort_val, "assortativity_z": assort_z,
                    "mntd_ratio": mntd, "ses_mntd": ses_mntd,
                    "purity": purity_val, "n_jobs": n_jobs,
                    "n_edges": n_edges, "n_failures": n_failure,
                },
            ))
        elif assort_val < -0.1 and abs(assort_z) > 2:
            signals.append(Signal(
                signal_type=SignalType.JOBS,
                severity=Severity.INFO,
                title="failure_dispersion",
                detail=(
                    f"Failures are dispersed across the similarity network "
                    f"(r={assort_val}, z={assort_z}). "
                    f"No systematic resource pattern drives failures."
                ),
                metrics={"assortativity": assort_val, "assortativity_z": assort_z},
            ))

        if mntd < 0.8 and abs(ses_mntd) > 1.5:
            signals.append(Signal(
                signal_type=SignalType.JOBS,
                severity=Severity.NOTICE,
                title="mntd_clustering",
                detail=(
                    f"Same-outcome jobs are closer in the network than expected "
                    f"(MNTD ratio={mntd}, SES={ses_mntd}). "
                    f"Failed jobs tend to be similar to other failed jobs."
                ),
                metrics={"mntd_ratio": mntd, "ses_mntd": ses_mntd},
            ))

        hotspots = quality.get("hotspots", [])
        if not hotspots:
            hotspots = compute_failure_hotspots(jobs)
        for hs in hotspots[:3]:
            ratio = hs.get("ratio", 1)
            if ratio >= 1.5:
                feature = hs["feature"].replace("_", " ")
                signals.append(Signal(
                    signal_type=SignalType.JOBS,
                    severity=Severity.WARNING if ratio >= 2.0 else Severity.NOTICE,
                    title="failure_hotspot",
                    detail=(
                        f"Jobs with {hs['bin']} {feature} fail at "
                        f"{hs['failure_rate']}% vs {hs['baseline_rate']}% baseline "
                        f"({ratio}x higher). "
                        f"{hs['n_failures']}/{hs['n_jobs']} jobs affected."
                    ),
                    metrics={
                        "feature": hs["feature"], "bin": hs["bin"],
                        "failure_rate": hs["failure_rate"],
                        "baseline_rate": hs["baseline_rate"],
                        "ratio": ratio,
                    },
                ))

        try:
            corr_data = compute_correlation_matrix(jobs)
            if corr_data and "matrix" in corr_data and "features" in corr_data:
                features = corr_data["features"]
                matrix = corr_data["matrix"]
                strong = []
                for i in range(len(features)):
                    for j in range(i + 1, len(features)):
                        if abs(matrix[i][j]) > 0.7:
                            strong.append((features[i], features[j], matrix[i][j]))
                if strong:
                    strong.sort(key=lambda x: -abs(x[2]))
                    f1 = strong[0][0].replace("_", " ")
                    f2 = strong[0][1].replace("_", " ")
                    r_val = strong[0][2]
                    direction = "positively" if r_val > 0 else "negatively"
                    signals.append(Signal(
                        signal_type=SignalType.JOBS,
                        severity=Severity.INFO,
                        title="strong_feature_correlation",
                        detail=(
                            f"{f1} and {f2} are strongly {direction} correlated "
                            f"(r={r_val:.2f}). {len(strong)} strong correlations "
                            f"found across job features."
                        ),
                        metrics={
                            "feature_1": strong[0][0], "feature_2": strong[0][1],
                            "correlation": round(r_val, 3),
                            "total_strong_correlations": len(strong),
                        },
                    ))
        except Exception:
            pass

        n_possible = n_jobs * (n_jobs - 1) / 2
        if n_possible > 0:
            density = n_edges / n_possible
            if density > 0.3:
                signals.append(Signal(
                    signal_type=SignalType.JOBS,
                    severity=Severity.INFO,
                    title="high_network_density",
                    detail=(
                        f"Job similarity network is dense ({density:.1%} of possible edges). "
                        f"Most jobs share similar resource patterns."
                    ),
                    metrics={"density": round(density, 4), "n_edges": n_edges, "n_jobs": n_jobs},
                ))
            elif density < 0.05 and n_jobs > 50:
                signals.append(Signal(
                    signal_type=SignalType.JOBS,
                    severity=Severity.NOTICE,
                    title="sparse_network",
                    detail=(
                        f"Job similarity network is sparse ({density:.1%}). "
                        f"Jobs have diverse resource profiles."
                    ),
                    metrics={"density": round(density, 4), "n_edges": n_edges, "n_jobs": n_jobs},
                ))

    except ImportError:
        pass
    except Exception:
        pass

    return signals

def read_all_signals(db_path: Path, hours: int = 24) -> list[Signal]:
    """Run all signal readers and return combined results."""
    all_signals: list[Signal] = []

    readers = [
        (read_job_signals, {"hours": hours}),
        (read_disk_signals, {"hours": min(hours, 12)}),
        (read_gpu_signals, {"hours": hours}),
        (read_queue_signals, {"hours": min(hours, 12)}),
        (read_network_signals, {"hours": min(hours, 12)}),
        (read_alert_signals, {"hours": hours}),
        (read_cloud_signals, {"hours": hours}),
        (read_workstation_signals, {"hours": min(hours, 12)}),
        (read_dynamics_signals, {"hours": hours}),
        (read_network_analytics_signals, {"hours": hours}),
    ]

    for reader, kwargs in readers:
        try:
            sigs = reader(db_path, **kwargs)
            all_signals.extend(sigs)
        except Exception:
            pass  # Individual reader failures don't break the engine

    return all_signals
