import click


@click.command()
def main():
    """
    Pocketbase Model Context Protocol Server

    This server is a Model Context Protocol (MCP) server for Pocketbase.
    It allows you to interact with your Pocketbase database using natural language.
    """


if __name__ == "__main__":
    main()
