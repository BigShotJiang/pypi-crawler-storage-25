//! Main tokenizer
//!
//! Orchestrates normalization, routing, vocabulary lookup, and encode/decode.

use crate::error::{NomedaError, Result};
use crate::normalize::{Normalizer, NormalizerConfig};
use crate::router::{Router, RouterConfig, RoutingDecision};
use crate::vocab::{BaseVocabulary, CombinedVocabulary, PluginVocabulary, SpecialTokens};
use std::collections::HashMap;

/// Tokenizer configuration
#[derive(Debug, Clone)]
pub struct TokenizerConfig {
    pub normalizer: NormalizerConfig,
    pub router: Option<RouterConfig>,
    pub max_token_length: usize,
    pub batch_size: usize,
}

impl Default for TokenizerConfig {
    fn default() -> Self {
        Self {
            normalizer: NormalizerConfig::default(),
            router: None,
            max_token_length: 32,
            batch_size: 1024,
        }
    }
}

/// Result of encoding a text string
#[derive(Debug, Clone)]
pub struct EncodeResult {
    /// Token IDs
    pub ids: Vec<u32>,
    /// Token strings
    pub tokens: Vec<String>,
    /// Detected/forced dialect
    pub dialect: String,
    /// Router confidence
    pub confidence: f32,
    /// Whether MSA fallback occurred
    pub fallback: bool,
    /// Character offsets for each token
    pub offsets: Vec<(usize, usize)>,
}

/// Plugin registry
pub struct PluginRegistry {
    plugins: HashMap<String, PluginVocabulary>,
}

impl PluginRegistry {
    pub fn new() -> Self {
        Self {
            plugins: HashMap::new(),
        }
    }

    pub fn load(&mut self, _path: &str, name: &str) -> Result<()> {
        // TODO: implement actual plugin loading from file
        let plugin = PluginVocabulary::new(name.to_string(), 50000, 16000);
        self.plugins.insert(name.to_string(), plugin);
        Ok(())
    }

    pub fn unload(&mut self, name: &str) {
        self.plugins.remove(name);
    }

    pub fn get(&self, name: &str) -> Option<&PluginVocabulary> {
        self.plugins.get(name)
    }

    pub fn list(&self) -> Vec<String> {
        self.plugins.keys().cloned().collect()
    }
}

/// Main tokenizer struct
pub struct Tokenizer {
    base: BaseVocabulary,
    router: Option<Router>,
    plugins: PluginRegistry,
    normalizer: Normalizer,
    config: TokenizerConfig,
}

impl Tokenizer {
    /// Load a base tokenizer model from file (stub — future binary format)
    pub fn load(_path: &str) -> Result<Self> {
        let mut builder = BaseVocabulary::new(32, SpecialTokens::default());
        builder.insert("[PAD]".to_string(), 0, 0.0)?;
        builder.insert("[BOS]".to_string(), 1, 0.0)?;
        builder.insert("[EOS]".to_string(), 2, 0.0)?;
        builder.insert("[UNK]".to_string(), 3, 0.0)?;
        let base = builder.build()?;
        let normalizer = Normalizer::new(NormalizerConfig::default());
        let config = TokenizerConfig::default();

        Ok(Self {
            base,
            router: None,
            plugins: PluginRegistry::new(),
            normalizer,
            config,
        })
    }

    /// Load tokenizer from a TSV vocabulary file
    pub fn from_tsv(path: &str) -> Result<Self> {
        let base = BaseVocabulary::from_tsv(path)?;
        let max_token_len = base.max_token_len();
        let normalizer = Normalizer::new(NormalizerConfig::default());
        let config = TokenizerConfig {
            max_token_length: max_token_len,
            ..TokenizerConfig::default()
        };

        Ok(Self {
            base,
            router: None,
            plugins: PluginRegistry::new(),
            normalizer,
            config,
        })
    }

    pub fn with_router(mut self, path: &str) -> Result<Self> {
        self.router = Some(Router::load(path)?);
        Ok(self)
    }

    pub fn with_plugin(mut self, path: &str, name: &str) -> Result<Self> {
        self.plugins.load(path, name)?;
        Ok(self)
    }

    pub fn load_plugin(&mut self, path: &str, name: &str) -> Result<()> {
        self.plugins.load(path, name)
    }

    pub fn unload_plugin(&mut self, name: &str) {
        self.plugins.unload(name);
    }

    pub fn list_plugins(&self) -> Vec<String> {
        self.plugins.list()
    }

    pub fn vocab_size(&self) -> u32 {
        self.base.vocab_size()
    }

    pub fn unk_id(&self) -> u32 {
        self.base.special().unk_id
    }

    pub fn bos_id(&self) -> u32 {
        self.base.special().bos_id
    }

    pub fn eos_id(&self) -> u32 {
        self.base.special().eos_id
    }

    pub fn pad_id(&self) -> u32 {
        self.base.special().pad_id
    }

    /// Encode a single text string
    pub fn encode(&self, text: &str) -> Result<EncodeResult> {
        let normalized = self.normalizer.normalize(text);
        
        // Route to dialect
        let routing = if let Some(router) = &self.router {
            router.predict(&normalized)
        } else {
            RoutingDecision::msa()
        };

        let dialect = if routing.fallback {
            "msa".to_string()
        } else {
            routing.dialect.clone()
        };

        self.encode_with_dialect_internal(&normalized, &dialect, routing.confidence, routing.fallback)
    }

    /// Encode with explicit dialect selection
    pub fn encode_with_dialect(&self, text: &str, dialect: &str) -> Result<EncodeResult> {
        let normalized = self.normalizer.normalize(text);
        self.encode_with_dialect_internal(&normalized, dialect, 1.0, false)
    }

    fn encode_with_dialect_internal(
        &self,
        text: &str,
        dialect: &str,
        confidence: f32,
        fallback: bool,
    ) -> Result<EncodeResult> {
        let plugin = self.plugins.get(dialect);
        let vocab = CombinedVocabulary::new(&self.base, plugin);

        let mut ids = vec![self.base.special().bos_id];
        let mut tokens = vec!["[BOS]".to_string()];
        let mut offsets = vec![(0, 0)];

        let chars: Vec<char> = text.chars().collect();
        let mut i = 0;

        while i < chars.len() {
            // Skip whitespace — spaces are absorbed into ▁ prefixes
            if chars[i].is_whitespace() {
                i += 1;
                continue;
            }

            let mut found = false;
            let max_len = std::cmp::min(self.config.max_token_length, chars.len() - i);
            let is_word_start = i == 0 || chars[i - 1].is_whitespace();

            for len in (1..=max_len).rev() {
                let substr: String = chars[i..i + len].iter().collect();

                // Don't match across whitespace
                if substr.chars().any(|c| c.is_whitespace()) {
                    continue;
                }

                // At word boundaries, try ▁-prefixed tokens first (SentencePiece convention)
                let lookup_key = if is_word_start {
                    format!("\u{2581}{}", substr)
                } else {
                    substr.clone()
                };

                if let Some((id, _score)) = vocab.lookup(&lookup_key) {
                    ids.push(id);
                    tokens.push(lookup_key);
                    offsets.push((i, i + len));
                    i += len;
                    found = true;
                    break;
                }

                // Fallback: if ▁-prefixed failed, try without ▁
                if is_word_start && lookup_key != substr {
                    if let Some((id, _score)) = vocab.lookup(&substr) {
                        ids.push(id);
                        tokens.push(substr);
                        offsets.push((i, i + len));
                        i += len;
                        found = true;
                        break;
                    }
                }
            }

            if !found {
                // Byte fallback: decompose character to UTF-8 bytes
                let ch = chars[i];
                let mut byte_matched = false;
                for byte in ch.encode_utf8(&mut [0; 4]).bytes() {
                    let byte_token = format!("<0x{:02X}>", byte);
                    if let Some((id, _score)) = vocab.lookup(&byte_token) {
                        ids.push(id);
                        tokens.push(byte_token);
                        offsets.push((i, i + 1));
                        byte_matched = true;
                    } else {
                        // If byte token not in vocab, fall back to UNK
                        ids.push(self.base.special().unk_id);
                        tokens.push("[UNK]".to_string());
                        offsets.push((i, i + 1));
                    }
                }
                if byte_matched {
                    i += 1;
                } else {
                    i += 1;
                }
            }
        }

        ids.push(self.base.special().eos_id);
        tokens.push("[EOS]".to_string());
        offsets.push((text.len(), text.len()));

        Ok(EncodeResult {
            ids,
            tokens,
            dialect: dialect.to_string(),
            confidence,
            fallback,
            offsets,
        })
    }

    /// Batch encode multiple texts
    pub fn encode_batch(&self, texts: &[&str]) -> Result<Vec<EncodeResult>> {
        texts.iter().map(|t| self.encode(t)).collect()
    }

    /// Decode token IDs back to text
    /// Handles byte fallback tokens <0xXX> by collecting bytes and decoding UTF-8
    pub fn decode(&self, ids: &[u32]) -> String {
        let vocab = CombinedVocabulary::new(&self.base, None);
        let mut result = String::new();
        let mut byte_buffer: Vec<u8> = Vec::new();

        fn flush_bytes(buf: &mut Vec<u8>, out: &mut String) {
            if !buf.is_empty() {
                out.push_str(&String::from_utf8_lossy(buf));
                buf.clear();
            }
        }

        for &id in ids {
            let Some(token) = vocab.id_to_token(id) else { continue };

            // Skip special tokens
            if token == "[BOS]" || token == "[EOS]" || token == "[PAD]" {
                flush_bytes(&mut byte_buffer, &mut result);
                continue;
            }

            // Check if token is a byte token: <0xXX>
            if token.len() == 6 && token.starts_with("<0x") && token.ends_with(">") {
                if let Ok(byte_val) = u8::from_str_radix(&token[3..5], 16) {
                    byte_buffer.push(byte_val);
                    continue;
                }
            }

            // Non-byte token: flush any pending bytes first
            flush_bytes(&mut byte_buffer, &mut result);

            // Apply word boundary marker
            let text = token.replace('\u{2581}', " ");
            result.push_str(&text);
        }

        // Flush remaining bytes
        flush_bytes(&mut byte_buffer, &mut result);

        result.trim().to_string()
    }

    /// Batch decode
    pub fn decode_batch(&self, id_batches: &[Vec<u32>]) -> Vec<String> {
        id_batches.iter().map(|ids| self.decode(ids)).collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_test_tsv() -> tempfile::NamedTempFile {
        let tsv = "[PAD]\t0\t0.0\n[BOS]\t1\t0.0\n[EOS]\t2\t0.0\n[UNK]\t3\t0.0\n\u{2581}ال\t10\t-1.0\n\u{2581}علم\t11\t-1.5\nعلم\t12\t-1.5\n\u{2581}نور\t13\t-1.7\nنور\t14\t-1.7\n\u{2581}كتاب\t15\t-1.8\nات\t16\t-2.0\n\u{2581}حديث\t17\t-2.1\nه\t18\t-2.2\n";
        let tmp = tempfile::NamedTempFile::new().unwrap();
        std::fs::write(tmp.path(), tsv.as_bytes()).unwrap();
        tmp
    }

    #[test]
    fn test_tokenizer_creation() {
        let tok = Tokenizer::load("dummy").unwrap();
        assert!(tok.list_plugins().is_empty());
    }

    #[test]
    fn test_encode_decode_with_word_boundary() {
        let tmp = make_test_tsv();
        let tok = Tokenizer::from_tsv(tmp.path().to_str().unwrap()).unwrap();

        let result = tok.encode_with_dialect("العلم نور", "msa").unwrap();
        assert_eq!(result.tokens[0], "[BOS]");
        // "العلم" tokenizes as ["▁ال", "علم"] because "ال" is a clitic prefix
        assert!(result.tokens.contains(&"\u{2581}ال".to_string()));
        assert!(result.tokens.contains(&"علم".to_string()));
        assert!(result.tokens.contains(&"\u{2581}نور".to_string()));
        assert_eq!(result.tokens.last().unwrap(), "[EOS]");

        let decoded = tok.decode(&result.ids);
        assert_eq!(decoded, "العلم نور");
    }

    #[test]
    fn test_batch_encode() {
        let tmp = make_test_tsv();
        let tok = Tokenizer::from_tsv(tmp.path().to_str().unwrap()).unwrap();
        let texts = vec!["text1", "text2"];
        let results = tok.encode_batch(&texts).unwrap();
        assert_eq!(results.len(), 2);
    }

    #[test]
    fn test_from_tsv_roundtrip() {
        let tmp = make_test_tsv();
        let tok = Tokenizer::from_tsv(tmp.path().to_str().unwrap()).unwrap();
        let ids = tok.encode("العلم نور").unwrap().ids;
        let decoded = tok.decode(&ids);
        assert!(decoded.contains("العلم"));
        assert!(decoded.contains("نور"));
    }

    #[test]
    fn test_vocab_size_and_special_ids() {
        let tmp = make_test_tsv();
        let tok = Tokenizer::from_tsv(tmp.path().to_str().unwrap()).unwrap();
        assert_eq!(tok.vocab_size(), 19);
        assert_eq!(tok.unk_id(), 3);
        assert_eq!(tok.bos_id(), 1);
        assert_eq!(tok.eos_id(), 2);
        assert_eq!(tok.pad_id(), 0);
    }
}
