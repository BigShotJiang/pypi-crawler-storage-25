use thiserror::Error;

pub type Result<T> = std::result::Result<T, NomedaError>;

#[derive(Error, Debug)]
pub enum NomedaError {
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),

    #[error("Invalid model file: {0}")]
    InvalidModel(String),

    #[error("Plugin incompatible with base model: plugin_hash={plugin_hash}, base_hash={base_hash}")]
    PluginIncompatible {
        plugin_hash: String,
        base_hash: String,
    },

    #[error("Unknown dialect: {0}")]
    UnknownDialect(String),

    #[error("Router not loaded but auto-routing requested")]
    RouterUnavailable,

    #[error("Invalid input: {0}")]
    InvalidInput(String),

    #[error("Serialization error: {0}")]
    Serialization(#[from] bincode::Error),

    #[error("FST error: {0}")]
    Fst(String),
}
