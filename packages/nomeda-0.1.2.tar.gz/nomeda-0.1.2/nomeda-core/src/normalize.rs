//! Arabic text normalization
//!
//! Configurable pipeline for cleaning Arabic text before tokenization.
//! Preserves linguistic features where appropriate.

use unicode_categories::UnicodeCategories;
use unicode_normalization::UnicodeNormalization;

/// Configuration for the normalizer
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct NormalizerConfig {
    /// Remove tashkeel (diacritics): default false for base, true for plugins
    pub strip_tashkeel: bool,
    /// Remove tatweel (kashida stretcher): default true
    pub strip_tatweel: bool,
    /// Unify alef variants (أ/إ/آ → ا): default true for base
    pub normalize_alef: bool,
    /// Unify ya variants (ى → ي): default true for base
    pub normalize_ya: bool,
    /// Unify ta marbuta (ة → ه): default true for base
    pub normalize_hamza: bool,
    /// Fix presentation forms (U+FB50–U+FEFF): default true
    pub fix_presentation_forms: bool,
    /// Collapse whitespace: default true
    pub collapse_whitespace: bool,
}

impl Default for NormalizerConfig {
    fn default() -> Self {
        Self {
            strip_tashkeel: false,
            strip_tatweel: true,
            normalize_alef: true,
            normalize_ya: true,
            normalize_hamza: true,
            fix_presentation_forms: true,
            collapse_whitespace: true,
        }
    }
}

impl NormalizerConfig {
    /// Aggressive normalization suitable for base MSA tokenizer training
    pub fn base() -> Self {
        Self {
            strip_tashkeel: true,
            strip_tatweel: true,
            normalize_alef: true,
            normalize_ya: true,
            normalize_hamza: true,
            fix_presentation_forms: true,
            collapse_whitespace: true,
        }
    }

    /// Conservative normalization suitable for dialect plugins
    pub fn plugin() -> Self {
        Self {
            strip_tashkeel: true,
            strip_tatweel: true,
            normalize_alef: false,
            normalize_ya: false,
            normalize_hamza: false,
            fix_presentation_forms: true,
            collapse_whitespace: true,
        }
    }
}

/// Arabic text normalizer
pub struct Normalizer {
    config: NormalizerConfig,
}

impl Normalizer {
    pub fn new(config: NormalizerConfig) -> Self {
        Self { config }
    }

    pub fn normalize(&self, text: &str) -> String {
        let mut result = text.nfc().collect::<String>();

        if self.config.fix_presentation_forms {
            result = Self::fix_presentation_forms(&result);
        }

        if self.config.strip_tashkeel {
            result = Self::strip_tashkeel(&result);
        }

        if self.config.strip_tatweel {
            result = result.replace('\u{0640}', "");
        }

        if self.config.normalize_alef {
            result = result
                .replace('\u{0622}', "\u{0627}")  // آ → ا
                .replace('\u{0623}', "\u{0627}")  // أ → ا
                .replace('\u{0625}', "\u{0627}"); // إ → ا
        }

        if self.config.normalize_ya {
            result = result.replace('\u{0649}', "\u{064A}"); // ى → ي
        }

        if self.config.normalize_hamza {
            result = result.replace('\u{0629}', "\u{0647}"); // ة → ه
        }

        if self.config.collapse_whitespace {
            result = Self::collapse_whitespace(&result);
        }

        result
    }

    fn fix_presentation_forms(text: &str) -> String {
        // TODO: implement full presentation form mapping
        // For now, handle common cases
        text.chars()
            .map(|ch| match ch {
                '\u{FE8E}' => '\u{0627}', // ـا → ا
                '\u{FEF5}' | '\u{FEF6}' => '\u{0644}', // Lam-alef with madda → ل
                '\u{FEF7}' | '\u{FEF8}' => '\u{0644}', // Lam-alef with hamza above → ل
                '\u{FEF9}' | '\u{FEFA}' => '\u{0644}', // Lam-alef with hamza below → ل
                '\u{FEFB}' | '\u{FEFC}' => '\u{0644}', // Lam-alef → ل
                _ => ch,
            })
            .collect()
    }

    fn strip_tashkeel(text: &str) -> String {
        text.chars()
            .filter(|&ch| {
                let cp = ch as u32;
                !((0x064B..=0x065F).contains(&cp) || cp == 0x0670)
            })
            .collect()
    }

    fn collapse_whitespace(text: &str) -> String {
        let mut result = String::with_capacity(text.len());
        let mut prev_ws = false;
        for ch in text.chars() {
            if ch.is_whitespace() {
                if !prev_ws {
                    result.push(' ');
                    prev_ws = true;
                }
            } else {
                result.push(ch);
                prev_ws = false;
            }
        }
        result.trim().to_string()
    }
}

impl Default for Normalizer {
    fn default() -> Self {
        Self::new(NormalizerConfig::default())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_normalize_base() {
        let n = Normalizer::new(NormalizerConfig::base());
        assert_eq!(n.normalize("العِلْمُ نُورٌ"), "العلم نور");
        assert_eq!(n.normalize("آثار الشمس"), "اثار الشمس");
        assert_eq!(n.normalize("مدرسة"), "مدرسه");
    }

    #[test]
    fn test_normalize_plugin() {
        let n = Normalizer::new(NormalizerConfig::plugin());
        assert_eq!(n.normalize("العِلْمُ"), "العلم"); // tashkeel stripped
        assert_eq!(n.normalize("آثار"), "آثار"); // alef preserved
        assert_eq!(n.normalize("مدرسة"), "مدرسة"); // ta marbuta preserved
    }

    #[test]
    fn test_collapse_whitespace() {
        let n = Normalizer::new(NormalizerConfig::default());
        assert_eq!(n.normalize("hello   world"), "hello world");
        assert_eq!(n.normalize("  trimmed  "), "trimmed");
    }
}
