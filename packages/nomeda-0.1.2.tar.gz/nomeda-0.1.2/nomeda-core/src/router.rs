//! Dialect router
//!
//! Lightweight classifier that assigns a dialect label to input text.
//! Currently a stub — will be implemented with FastText-style char n-gram LR.

use crate::error::Result;
use std::collections::HashMap;

/// Router configuration
#[derive(Debug, Clone)]
pub struct RouterConfig {
    pub model_path: String,
    pub fallback_threshold: f32,
}

impl Default for RouterConfig {
    fn default() -> Self {
        Self {
            model_path: String::new(),
            fallback_threshold: 0.65,
        }
    }
}

/// Dialect routing decision
#[derive(Debug, Clone)]
pub struct RoutingDecision {
    /// Assigned dialect (or "msa" if fallback)
    pub dialect: String,
    /// Confidence in top dialect (0.0 - 1.0)
    pub confidence: f32,
    /// Full probability distribution
    pub scores: HashMap<String, f32>,
    /// Whether fallback to MSA was triggered
    pub fallback: bool,
}

impl RoutingDecision {
    pub fn msa() -> Self {
        let mut scores = HashMap::new();
        scores.insert("msa".to_string(), 1.0);
        Self {
            dialect: "msa".to_string(),
            confidence: 1.0,
            scores,
            fallback: true,
        }
    }
}

/// Dialect classifier
pub struct Router {
    config: RouterConfig,
    // TODO: load actual model weights
    labels: Vec<String>,
}

impl Router {
    pub fn load(path: &str) -> Result<Self> {
        // TODO: implement actual model loading
        let labels = vec![
            "msa".to_string(),
            "egy".to_string(),
            "shami".to_string(),
            "gulf".to_string(),
            "magh".to_string(),
        ];
        Ok(Self {
            config: RouterConfig {
                model_path: path.to_string(),
                ..Default::default()
            },
            labels,
        })
    }

    pub fn predict(&self, text: &str) -> RoutingDecision {
        // TODO: implement actual prediction
        // Stub: always returns MSA for now
        let mut scores = HashMap::new();
        scores.insert("msa".to_string(), 0.95);
        scores.insert("egy".to_string(), 0.02);
        scores.insert("shami".to_string(), 0.01);
        scores.insert("gulf".to_string(), 0.01);
        scores.insert("magh".to_string(), 0.01);

        RoutingDecision {
            dialect: "msa".to_string(),
            confidence: 0.95,
            scores,
            fallback: false,
        }
    }

    pub fn predict_batch(&self, texts: &[&str]) -> Vec<RoutingDecision> {
        texts.iter().map(|t| self.predict(t)).collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_routing_decision_msa() {
        let decision = RoutingDecision::msa();
        assert_eq!(decision.dialect, "msa");
        assert!(decision.fallback);
    }

    #[test]
    fn test_router_predict() {
        let router = Router::load("dummy").unwrap();
        let decision = router.predict("العلم نور");
        assert_eq!(decision.dialect, "msa");
        assert!(decision.confidence > 0.0);
    }

    #[test]
    fn test_router_predict_batch() {
        let router = Router::load("dummy").unwrap();
        let texts = vec!["text1", "text2"];
        let decisions = router.predict_batch(&texts);
        assert_eq!(decisions.len(), 2);
    }
}
