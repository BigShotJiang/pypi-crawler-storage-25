//! Nomeda Arabic Tokenizer - Core Library
//!
//! A high-performance Arabic tokenizer with dialect-aware routing.
//!
//! # Quick Start
//! ```rust,no_run
//! use nomeda_core::Tokenizer;
//!
//! let tok = Tokenizer::load("msa-base-v1.0.base").unwrap();
//! let result = tok.encode("العلم نور").unwrap();
//! assert_eq!(result.tokens, vec!["[BOS]", "العلم", "نور", "[EOS]"]);
//! ```

pub mod error;
pub mod normalize;
pub mod router;
pub mod tokenizer;
pub mod vocab;

pub use error::{NomedaError, Result};
pub use normalize::{Normalizer, NormalizerConfig};
pub use router::{Router, RouterConfig, RoutingDecision};
pub use tokenizer::{EncodeResult, Tokenizer, TokenizerConfig};
pub use vocab::{BaseVocabulary, PluginVocabulary, SpecialTokens, VocabBuilder};

/// Re-export version
pub const VERSION: &str = env!("CARGO_PKG_VERSION");
