//! Vocabulary management
//!
//! Base vocabulary (FST-based) and plugin vocabulary (hash map overlay).

use crate::error::{NomedaError, Result};
use fst::Map;
use std::collections::HashMap;
use std::io::{self, BufRead};
use std::path::Path;

/// Special tokens always present in the vocabulary
#[derive(Debug, Clone)]
pub struct SpecialTokens {
    pub pad_id: u32,
    pub bos_id: u32,
    pub eos_id: u32,
    pub unk_id: u32,
    pub mask_id: u32,
}

impl Default for SpecialTokens {
    fn default() -> Self {
        Self {
            pad_id: 0,
            bos_id: 1,
            eos_id: 2,
            unk_id: 3,
            mask_id: 4,
        }
    }
}

/// Builder for constructing a BaseVocabulary incrementally.
///
/// After inserting all tokens, call `.build()` to freeze into an FST-backed vocabulary.
pub struct VocabBuilder {
    max_token_len: usize,
    special: SpecialTokens,
    entries: Vec<(String, u32, f32)>,
}

impl VocabBuilder {
    pub fn new(max_token_len: usize, special: SpecialTokens) -> Self {
        Self {
            max_token_len,
            special,
            entries: Vec::new(),
        }
    }

    pub fn insert(&mut self, token: String, id: u32, score: f32) -> Result<()> {
        if token.chars().count() > self.max_token_len {
            return Err(NomedaError::InvalidModel(format!(
                "Token '{}' exceeds max_token_len {}",
                token, self.max_token_len
            )));
        }
        self.entries.push((token, id, score));
        Ok(())
    }

    pub fn build(self) -> Result<BaseVocabulary> {
        if self.entries.is_empty() {
            return Err(NomedaError::InvalidModel(
                "Cannot build vocabulary with no entries".to_string(),
            ));
        }

        // Sort by token bytes for FST construction
        let mut entries = self.entries;
        entries.sort_by(|a, b| a.0.as_bytes().cmp(b.0.as_bytes()));

        // Validate contiguous IDs starting from 0
        let max_id = entries.iter().map(|(_, id, _)| *id).max().unwrap();
        let vocab_size = max_id + 1;

        let mut id_to_token: Vec<String> = Vec::with_capacity(vocab_size as usize);
        let mut scores: Vec<f32> = Vec::with_capacity(vocab_size as usize);
        id_to_token.resize(vocab_size as usize, String::new());
        scores.resize(vocab_size as usize, 0.0);

        let mut seen_ids = std::collections::HashSet::new();
        let mut seen_tokens = std::collections::HashSet::new();

        // Build FST
        let mut fst_build = fst::MapBuilder::new(Vec::new())
            .map_err(|e| NomedaError::Fst(e.to_string()))?;

        for (token, id, score) in &entries {
            if !seen_ids.insert(*id) {
                return Err(NomedaError::InvalidModel(format!(
                    "Duplicate token ID {}",
                    id
                )));
            }
            if !seen_tokens.insert(token.clone()) {
                return Err(NomedaError::InvalidModel(format!(
                    "Duplicate token '{}'",
                    token
                )));
            }

            id_to_token[*id as usize] = token.clone();
            scores[*id as usize] = *score;

            fst_build
                .insert(token.as_bytes(), u64::from(*id))
                .map_err(|e| NomedaError::Fst(e.to_string()))?;
        }

        let fst_bytes = fst_build
            .into_inner()
            .map_err(|e| NomedaError::Fst(e.to_string()))?;
        let fst = Map::new(fst_bytes).map_err(|e| NomedaError::Fst(e.to_string()))?;

        Ok(BaseVocabulary {
            vocab_size,
            max_token_len: self.max_token_len,
            special: self.special,
            fst,
            id_to_token,
            scores,
        })
    }
}

/// Base MSA vocabulary, immutable after construction
pub struct BaseVocabulary {
    vocab_size: u32,
    max_token_len: usize,
    special: SpecialTokens,
    fst: Map<Vec<u8>>,
    id_to_token: Vec<String>,
    scores: Vec<f32>,
}

impl BaseVocabulary {
    pub fn new(max_token_len: usize, special: SpecialTokens) -> VocabBuilder {
        VocabBuilder::new(max_token_len, special)
    }

    pub fn from_tsv<P: AsRef<Path>>(path: P) -> Result<Self> {
        let file = std::fs::File::open(path)?;
        let reader = io::BufReader::new(file);
        let mut entries: Vec<(String, u32, f32)> = Vec::new();
        let mut max_token_len = 0usize;

        for (line_no, line) in reader.lines().enumerate() {
            let line = line?;
            if line.trim().is_empty() || line.starts_with('#') {
                continue;
            }

            let parts: Vec<&str> = line.split('\t').collect();
            if parts.len() != 3 {
                return Err(NomedaError::InvalidModel(format!(
                    "TSV line {}: expected 3 columns, got {} (line: '{}')",
                    line_no + 1,
                    parts.len(),
                    line
                )));
            }

            let token = parts[0].to_string();
            let id: u32 = parts[1]
                .parse()
                .map_err(|e| NomedaError::InvalidModel(format!(
                    "TSV line {}: invalid id '{}' ({}",
                    line_no + 1,
                    parts[1],
                    e
                )))?;
            let score: f32 = parts[2]
                .parse()
                .map_err(|e| NomedaError::InvalidModel(format!(
                    "TSV line {}: invalid score '{}' ({})",
                    line_no + 1,
                    parts[2],
                    e
                )))?;

            let token_len = token.chars().count();
            if token_len > max_token_len {
                max_token_len = token_len;
            }

            entries.push((token, id, score));
        }

        if entries.is_empty() {
            return Err(NomedaError::InvalidModel(
                "TSV file contains no valid entries".to_string(),
            ));
        }

        // Build using VocabBuilder to get FST and validation
        let mut builder = VocabBuilder::new(max_token_len, SpecialTokens::default());
        for (token, id, score) in entries {
            builder.insert(token, id, score)?;
        }
        builder.build()
    }

    pub fn vocab_size(&self) -> u32 {
        self.vocab_size
    }

    pub fn max_token_len(&self) -> usize {
        self.max_token_len
    }

    pub fn special(&self) -> &SpecialTokens {
        &self.special
    }

    pub fn lookup(&self, token: &str) -> Option<(u32, f32)> {
        self.fst.get(token).map(|id| {
            let id = id as u32;
            (id, self.scores[id as usize])
        })
    }

    pub fn id_to_token(&self, id: u32) -> Option<&str> {
        self.id_to_token.get(id as usize).map(|s| s.as_str())
    }

    pub fn unk_token(&self) -> &str {
        self.id_to_token(self.special.unk_id).unwrap_or("[UNK]")
    }
}

/// Plugin vocabulary — extends base with dialect-specific tokens
pub struct PluginVocabulary {
    name: String,
    base_vocab_size: u32,
    plugin_vocab_size: u32,
    // Maps plugin token string → global ID
    token_to_id: HashMap<String, u32>,
    // Global ID → token string (only plugin IDs)
    id_to_token: Vec<String>,
    // Global ID → unigram score
    scores: HashMap<u32, f32>,
}

impl PluginVocabulary {
    pub fn new(name: String, base_vocab_size: u32, plugin_vocab_size: u32) -> Self {
        Self {
            name,
            base_vocab_size,
            plugin_vocab_size,
            token_to_id: HashMap::new(),
            id_to_token: Vec::with_capacity(plugin_vocab_size as usize),
            scores: HashMap::new(),
        }
    }

    pub fn name(&self) -> &str {
        &self.name
    }

    pub fn total_vocab_size(&self) -> u32 {
        self.base_vocab_size + self.plugin_vocab_size
    }

    pub fn insert(&mut self, token: String, local_id: u32, score: f32) -> Result<()> {
        if local_id >= self.plugin_vocab_size {
            return Err(NomedaError::InvalidModel(format!(
                "Plugin token ID {} exceeds plugin vocab size {}",
                local_id, self.plugin_vocab_size
            )));
        }
        let global_id = self.base_vocab_size + local_id;
        self.token_to_id.insert(token.clone(), global_id);

        while self.id_to_token.len() <= local_id as usize {
            self.id_to_token.push(String::new());
        }

        self.id_to_token[local_id as usize] = token;
        self.scores.insert(global_id, score);
        Ok(())
    }

    pub fn lookup(&self, token: &str) -> Option<(u32, f32)> {
        self.token_to_id.get(token).map(|&id| {
            (id, *self.scores.get(&id).unwrap_or(&0.0))
        })
    }

    pub fn id_to_token(&self, global_id: u32) -> Option<&str> {
        if global_id < self.base_vocab_size {
            None // Base tokens not stored here
        } else {
            let local_id = (global_id - self.base_vocab_size) as usize;
            self.id_to_token.get(local_id).map(|s| s.as_str())
        }
    }

    pub fn contains_token(&self, token: &str) -> bool {
        self.token_to_id.contains_key(token)
    }
}

/// Combined vocabulary for tokenization (base + active plugin)
pub struct CombinedVocabulary<'a> {
    base: &'a BaseVocabulary,
    plugin: Option<&'a PluginVocabulary>,
}

impl<'a> CombinedVocabulary<'a> {
    pub fn new(base: &'a BaseVocabulary, plugin: Option<&'a PluginVocabulary>) -> Self {
        Self { base, plugin }
    }

    pub fn lookup(&self, token: &str) -> Option<(u32, f32)> {
        // Try plugin first (dialect-specific tokens take precedence)
        if let Some(plugin) = self.plugin {
            if let Some(result) = plugin.lookup(token) {
                return Some(result);
            }
        }
        self.base.lookup(token)
    }

    pub fn id_to_token(&self, id: u32) -> Option<String> {
        if let Some(plugin) = self.plugin {
            if let Some(token) = plugin.id_to_token(id) {
                return Some(token.to_string());
            }
        }
        self.base.id_to_token(id).map(|s| s.to_string())
    }

    pub fn vocab_size(&self) -> u32 {
        self.base.vocab_size()
            + self.plugin.map(|p| p.total_vocab_size() - self.base.vocab_size()).unwrap_or(0)
    }

    pub fn max_token_len(&self) -> usize {
        self.base.max_token_len()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_base_vocabulary() {
        let mut builder = BaseVocabulary::new(16, SpecialTokens::default());
        builder.insert("العلم".to_string(), 5, -2.5).unwrap();
        builder.insert("نور".to_string(), 6, -3.0).unwrap();
        let vocab = builder.build().unwrap();

        assert_eq!(vocab.lookup("العلم"), Some((5, -2.5)));
        assert_eq!(vocab.lookup("missing"), None);
        assert_eq!(vocab.id_to_token(5), Some("العلم"));
    }

    #[test]
    fn test_plugin_vocabulary() {
        let mut builder = BaseVocabulary::new(16, SpecialTokens::default());
        builder.insert("dummy".to_string(), 0, 0.0).unwrap();
        let base = builder.build().unwrap();
        let mut plugin = PluginVocabulary::new("egy".to_string(), 100, 50);
        plugin.insert("إحنا".to_string(), 0, -1.5).unwrap();
        plugin.insert("رايحين".to_string(), 1, -2.0).unwrap();

        assert_eq!(plugin.lookup("إحنا"), Some((100, -1.5)));
        assert_eq!(plugin.id_to_token(100), Some("إحنا"));
    }

    #[test]
    fn test_combined_vocabulary() {
        let mut builder = BaseVocabulary::new(16, SpecialTokens::default());
        builder.insert("ال".to_string(), 10, -1.0).unwrap();
        builder.insert("dummy".to_string(), 0, 0.0).unwrap();
        let base = builder.build().unwrap();

        let mut plugin = PluginVocabulary::new("egy".to_string(), 100, 50);
        plugin.insert("إحنا".to_string(), 0, -1.5).unwrap();

        let combined = CombinedVocabulary::new(&base, Some(&plugin));
        assert_eq!(combined.lookup("إحنا"), Some((100, -1.5)));
        assert_eq!(combined.lookup("ال"), Some((10, -1.0)));
        assert_eq!(combined.vocab_size(), 150);
    }

    #[test]
    fn test_vocab_from_tsv() {
        let tsv = "# comment line\n[PAD]\t0\t0.0\n[BOS]\t1\t0.0\n[EOS]\t2\t0.0\n[UNK]\t3\t0.0\nال\t4\t-1.0\nو\t5\t-0.8\n";
        let tmp = tempfile::NamedTempFile::new().unwrap();
        std::fs::write(tmp.path(), tsv.as_bytes()).unwrap();

        let vocab = BaseVocabulary::from_tsv(tmp.path()).unwrap();
        assert_eq!(vocab.vocab_size(), 6);
        assert_eq!(vocab.lookup("ال"), Some((4, -1.0)));
        assert_eq!(vocab.lookup("و"), Some((5, -0.8)));
        assert_eq!(vocab.lookup("missing"), None);
    }
}
