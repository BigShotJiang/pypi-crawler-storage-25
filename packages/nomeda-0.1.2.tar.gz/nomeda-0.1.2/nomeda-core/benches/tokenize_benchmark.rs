use criterion::{black_box, criterion_group, criterion_main, Criterion};

fn tokenize_benchmark(c: &mut Criterion) {
    c.bench_function("dummy_tokenize", |b| {
        b.iter(|| {
            black_box("العلم نور".to_string())
        })
    });
}

criterion_group!(benches, tokenize_benchmark);
criterion_main!(benches);
