use nomeda_core::{EncodeResult, Tokenizer};
use pyo3::prelude::*;
use pyo3::types::PyDict;
use std::env;
use std::path::{Path, PathBuf};

fn runtime_err(message: impl Into<String>) -> PyErr {
    PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(message.into())
}

fn push_unique(items: &mut Vec<String>, value: String) {
    if !items.iter().any(|v| v == &value) {
        items.push(value);
    }
}

fn pretrained_filenames(name: &str) -> Vec<String> {
    let mut candidates = Vec::new();

    if name.ends_with(".tsv") {
        push_unique(&mut candidates, name.to_string());
    } else {
        push_unique(&mut candidates, format!("{name}.tsv"));
    }

    let normalized = name.to_ascii_lowercase().replace('_', "-");
    if normalized == "nomeda-msa-64k"
        || normalized == "nomeda-msa-64kv1"
        || normalized == "nomeda-msa-64k-v1"
    {
        push_unique(&mut candidates, "Nomeda-MSA-64Kv1.tsv".to_string());
        push_unique(&mut candidates, "nomeda_msa_v64000_step10.tsv".to_string());
    }

    push_unique(&mut candidates, "tokenizer.tsv".to_string());
    push_unique(&mut candidates, "vocab.tsv".to_string());
    candidates
}

fn local_search_dirs() -> Vec<PathBuf> {
    let mut dirs = Vec::new();

    if let Ok(path) = env::var("NOMEDA_MODEL_DIR") {
        dirs.push(PathBuf::from(path));
    }
    if let Ok(path) = env::var("NOMEDA_PRETRAINED_DIR") {
        dirs.push(PathBuf::from(path));
    }

    if let Ok(home) = env::var("HOME") {
        let home = PathBuf::from(home);
        dirs.push(home.join(".cache/nomeda"));
        dirs.push(home.join(".cache/nomeda/pretrained"));
        dirs.push(home.join(".local/share/nomeda"));
    }

    if let Ok(cwd) = env::current_dir() {
        dirs.push(cwd.clone());
        dirs.push(cwd.join("vocab"));
        dirs.push(cwd.join("models"));
        dirs.push(cwd.join("Nomeda-MSA-64Kv1"));
        dirs.push(cwd.join("Nomeda-MSA-64Kv1/vocab"));
    }

    dirs
}

fn resolve_local_pretrained(name: &str) -> Option<PathBuf> {
    let direct = PathBuf::from(name);
    if direct.is_file() {
        return Some(direct);
    }

    if Path::new(name).extension().is_none() {
        let with_tsv = PathBuf::from(format!("{name}.tsv"));
        if with_tsv.is_file() {
            return Some(with_tsv);
        }
    }

    let filenames = pretrained_filenames(name);
    for dir in local_search_dirs() {
        for file_name in &filenames {
            let candidate = dir.join(file_name);
            if candidate.is_file() {
                return Some(candidate);
            }
        }
    }

    None
}

fn pretrained_repo_ids(name: &str) -> Vec<String> {
    let mut repo_ids = Vec::new();
    push_unique(&mut repo_ids, name.to_string());

    if !name.contains('/') {
        let namespace = env::var("NOMEDA_HF_NAMESPACE").unwrap_or_else(|_| "nomeda-lab".to_string());
        push_unique(&mut repo_ids, format!("{namespace}/{name}"));
    }

    repo_ids
}

fn try_hf_download(py: Python<'_>, repo_id: &str, filenames: &[String]) -> PyResult<Option<PathBuf>> {
    let hub = match py.import_bound("huggingface_hub") {
        Ok(module) => module,
        Err(_) => return Ok(None),
    };

    let hf_hub_download = match hub.getattr("hf_hub_download") {
        Ok(func) => func,
        Err(_) => return Ok(None),
    };

    for file_name in filenames {
        let kwargs = PyDict::new_bound(py);
        kwargs.set_item("repo_id", repo_id)?;
        kwargs.set_item("filename", file_name)?;
        kwargs.set_item("repo_type", "model")?;

        let download_result = hf_hub_download.call((), Some(&kwargs));
        if let Ok(path_obj) = download_result {
            let path: String = path_obj.extract()?;
            let path_buf = PathBuf::from(path);
            if path_buf.is_file() {
                return Ok(Some(path_buf));
            }
        }
    }

    Ok(None)
}

/// Python wrapper for EncodeResult
#[pyclass(name = "EncodeResult")]
struct PyEncodeResult {
    #[pyo3(get)]
    ids: Vec<u32>,
    #[pyo3(get)]
    tokens: Vec<String>,
    #[pyo3(get)]
    dialect: String,
    #[pyo3(get)]
    confidence: f32,
    #[pyo3(get)]
    fallback: bool,
    #[pyo3(get)]
    offsets: Vec<(usize, usize)>,
}

impl From<EncodeResult> for PyEncodeResult {
    fn from(result: EncodeResult) -> Self {
        Self {
            ids: result.ids,
            tokens: result.tokens,
            dialect: result.dialect,
            confidence: result.confidence,
            fallback: result.fallback,
            offsets: result.offsets,
        }
    }
}

/// Python wrapper for the MSA Base Tokenizer
#[pyclass(name = "NomedaMSATokenizer")]
struct PyNomedaMSATokenizer {
    inner: Tokenizer,
}

#[pymethods]
impl PyNomedaMSATokenizer {
    /// Load a base tokenizer from a TSV vocabulary file.
    ///
    /// TSV format: token<TAB>id<TAB>score
    #[staticmethod]
    fn from_tsv(path: &str) -> PyResult<Self> {
        let inner = Tokenizer::from_tsv(path)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
        Ok(Self { inner })
    }

    /// Load a tokenizer by a pretrained name, local path, or Hugging Face repo id.
    ///
    /// Resolution order:
    /// 1) Local file path (`name` as-is)
    /// 2) Local aliases/search dirs (e.g. `nomeda-msa-64k`)
    /// 3) Hugging Face Hub via `huggingface_hub` if installed
    #[staticmethod]
    fn from_pretrained(py: Python<'_>, name: &str) -> PyResult<Self> {
        if let Some(path) = resolve_local_pretrained(name) {
            let path_str = path.to_string_lossy().to_string();
            return Self::from_tsv(&path_str);
        }

        let filenames = pretrained_filenames(name);
        for repo_id in pretrained_repo_ids(name) {
            if let Some(path) = try_hf_download(py, &repo_id, &filenames)? {
                let path_str = path.to_string_lossy().to_string();
                return Self::from_tsv(&path_str);
            }
        }

        Err(runtime_err(format!(
            "Could not resolve pretrained tokenizer '{}'. Try: from_tsv('/path/to/model.tsv'), set NOMEDA_MODEL_DIR, or install huggingface_hub and publish a repo with a TSV file.",
            name
        )))
    }

    /// Load the default tokenizer.
    ///
    /// Uses `NOMEDA_DEFAULT_MODEL` when set, otherwise defaults to `nomeda-msa-64k`.
    #[staticmethod]
    fn load_default(py: Python<'_>) -> PyResult<Self> {
        let default_name = env::var("NOMEDA_DEFAULT_MODEL").unwrap_or_else(|_| "nomeda-msa-64k".to_string());
        Self::from_pretrained(py, &default_name)
    }

    /// Encode text (auto-routed to MSA since router is not yet implemented)
    fn encode(&self, text: &str) -> PyResult<PyEncodeResult> {
        let result = self.inner.encode(text)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
        Ok(result.into())
    }

    /// Encode with explicit dialect (for future plugin support)
    fn encode_with_dialect(&self, text: &str, dialect: &str) -> PyResult<PyEncodeResult> {
        let result = self.inner.encode_with_dialect(text, dialect)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
        Ok(result.into())
    }

    /// Batch encode
    fn encode_batch(&self, texts: Vec<String>) -> PyResult<Vec<PyEncodeResult>> {
        let text_refs: Vec<&str> = texts.iter().map(|s| s.as_str()).collect();
        let results = self.inner.encode_batch(&text_refs)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
        Ok(results.into_iter().map(|r| r.into()).collect())
    }

    /// Decode token IDs
    fn decode(&self, ids: Vec<u32>) -> String {
        self.inner.decode(&ids)
    }

    /// Batch decode
    fn decode_batch(&self, id_batches: Vec<Vec<u32>>) -> Vec<String> {
        self.inner.decode_batch(&id_batches)
    }

    /// Load a plugin (stub — future dialect plugin support)
    fn load_plugin(&mut self, path: &str, name: &str) -> PyResult<()> {
        self.inner.load_plugin(path, name)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))
    }

    /// Unload a plugin
    fn unload_plugin(&mut self, name: &str) {
        self.inner.unload_plugin(name);
    }

    /// List loaded plugins
    fn list_plugins(&self) -> Vec<String> {
        self.inner.list_plugins()
    }

    /// Vocabulary size
    #[getter]
    fn vocab_size(&self) -> u32 {
        self.inner.vocab_size()
    }

    /// [UNK] token ID
    #[getter]
    fn unk_id(&self) -> u32 {
        self.inner.unk_id()
    }

    /// [BOS] token ID
    #[getter]
    fn bos_id(&self) -> u32 {
        self.inner.bos_id()
    }

    /// [EOS] token ID
    #[getter]
    fn eos_id(&self) -> u32 {
        self.inner.eos_id()
    }

    /// [PAD] token ID
    #[getter]
    fn pad_id(&self) -> u32 {
        self.inner.pad_id()
    }
}

/// Python module
#[pymodule]
fn nomeda(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyNomedaMSATokenizer>()?;
    m.add_class::<PyEncodeResult>()?;
    Ok(())
}
