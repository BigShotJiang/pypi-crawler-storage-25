from __future__ import annotations
import hashlib,json,os,re,socket,subprocess
from dataclasses import dataclass
from datetime import datetime,timezone
from pathlib import Path
from typing import Any,Literal
from urllib import error,request
import httpx
from.http_client import api_base_url,auth_headers,raise_for_response
RUNTIME_DIR_NAME='.gv'
RUNTIME_METADATA_NAME='runtime.json'
MANAGED_RUNTIME_DIR='.tabtabtab/runtime'
MANAGED_DEVCONTAINER_FILE='.tabtabtab/runtime/devcontainer.json'
MANAGED_RUNTIME_MANIFEST='.tabtabtab/runtime/manifest.json'
NATIVE_DEVCONTAINER_FILE='.devcontainer/devcontainer.json'
RUNTIME_ID_PREFIX='gv-'
RUNTIME_LABEL='gv.runtime'
DEVCONTAINER_LABEL='devcontainer.local_folder'
RuntimeMode=Literal['devcontainer','none']
DevcontainerShape=Literal['compose','single']
@dataclass(frozen=True)
class RuntimeContext:worktree:Path;project_root:Path;repo_root:Path;runtime_id:str;metadata_path:Path
@dataclass(frozen=True)
class RuntimePort:runtime:str;service:str;container:str;container_port:int;host_port:int|None;protocol:str
@dataclass(frozen=True)
class RuntimeStatus:runtime:str;mode:RuntimeMode;detail:str|None;worktree:Path|None;compose_project:str;status:str;containers:tuple[dict[str,str],...]=();ports:tuple[RuntimePort,...]=()
@dataclass(frozen=True)
class DevcontainerConfig:shape:DevcontainerShape;config_path:Path;workspace_folder:Path;compose_files:tuple[Path,...]=();service:str|None=None
@dataclass(frozen=True)
class RegisteredSetupFile:path:str;content:str;hash:str
@dataclass(frozen=True)
class RegisteredSetup:repo_id:str;setup_hash:str;forward_ports:list[int];files:list[RegisteredSetupFile]
@dataclass(frozen=True)
class RuntimeSetupSelection:config:DevcontainerConfig;source:Literal['explicit','local','registered','native']
def runtime_context(command:str='up')->RuntimeContext:
	D=Path.cwd().resolve();A=_git_toplevel(D)
	if A is None:raise RuntimeError(f"`tabtabtab runtime {command}` must be run from a repository workspace.")
	B=A;C=_git_project_root(A);E=build_runtime_id(C,B);F=A/RUNTIME_DIR_NAME/RUNTIME_METADATA_NAME;return RuntimeContext(worktree=B,project_root=C,repo_root=A,runtime_id=E,metadata_path=F)
def build_runtime_id(repo_root:Path,worktree:Path)->str:A=worktree;B=_runtime_id_part(repo_root.name);C=_runtime_id_part(A.name);D=hashlib.sha256(str(A).encode('utf-8')).hexdigest()[:6];return f"{RUNTIME_ID_PREFIX}{B}-{C}-{D}"
def handle_runtime_up(*,setup_path:str|None=None)->int:A=runtime_context('up');C=_select_runtime_setup(A,setup_path=setup_path);B=C.config;_run_devcontainer_up(A,B);_write_metadata(A,'devcontainer',detail=B.shape,config_path=B.config_path);print(f"Runtime {A.runtime_id} is running.");return 0
def handle_runtime_status(*,all_runtimes:bool,as_json:bool)->int:
	A=all_runtimes;B=list_all_runtime_statuses()if A else[runtime_status(runtime_context('status'))]
	if as_json:print(json.dumps([_runtime_status_json(A)for A in B],indent=2));return 0
	_print_runtime_statuses(B,include_runtime=A);return 0
def handle_runtime_ports(*,all_runtimes:bool,as_json:bool)->int:
	B=as_json
	if all_runtimes:
		A=list_all_runtime_ports()
		if B:print(json.dumps([_runtime_port_json(A)for A in A],indent=2))
		else:_print_ports(A,include_runtime=True)
		return 0
	C=runtime_context('ports');A=list_runtime_ports(C.runtime_id)
	if B:print(json.dumps([_runtime_port_json(A)for A in A],indent=2))
	else:_print_ports(A,include_runtime=False)
	return 0
def handle_runtime_preview(target:str,*,auth:bool=True)->int:A=runtime_context('preview');B=_resolve_preview_port(A.runtime_id,target);C=create_preview_url(B,auth=auth);print(C);return 0
def handle_runtime_logs()->int:
	A=runtime_context('logs');E=_runtime_mode_for_context(A,_read_metadata(A.metadata_path))
	if E=='devcontainer':
		B=_container_ids_for_runtime(A.runtime_id)
		if not B:raise RuntimeError('No devcontainer runtime is currently running.')
		C=0
		for F in B:
			D=_run_docker(['logs',F],check=False)
			if D.returncode!=0:C=D.returncode
		return C
	raise RuntimeError('No managed runtime found for this workspace.')
def handle_runtime_down()->int:
	A=runtime_context('down');B=_read_metadata(A.metadata_path);C=_runtime_mode_for_context(A,B)
	if C=='devcontainer':D=load_devcontainer_config(A.repo_root,setup_path=_metadata_setup_path(A,B));_run_devcontainer_down(A,D)
	else:raise RuntimeError('No managed runtime found for this workspace.')
	print(f"Runtime {A.runtime_id} stopped.");return 0
def handle_runtime_rebuild(*,setup_path:str|None=None)->int:A=runtime_context('rebuild');C=_select_runtime_setup(A,setup_path=setup_path);B=C.config;_run_devcontainer_down(A,B,ignore_missing=True);_run_devcontainer_up(A,B,rebuild=True);_write_metadata(A,'devcontainer',detail=B.shape,config_path=B.config_path);print(f"Runtime {A.runtime_id} rebuilt and running.");return 0
def list_runtime_ports(runtime_id:str)->list[RuntimePort]:return[A for A in _docker_ports()if A.runtime==runtime_id]
def list_all_runtime_ports()->list[RuntimePort]:return[A for A in _docker_ports()if A.runtime.startswith(RUNTIME_ID_PREFIX)]
def runtime_status(ctx:RuntimeContext)->RuntimeStatus:
	A=ctx;C=_read_metadata(A.metadata_path);B=_runtime_mode_for_context(A,C)
	if B=='devcontainer':D=_docker_containers_for_runtime(A.runtime_id);return RuntimeStatus(runtime=A.runtime_id,mode=B,detail=_runtime_detail_for_context(A,C,B),worktree=A.worktree,compose_project=A.runtime_id,status='running'if D else'not_running',containers=tuple(D),ports=tuple(list_runtime_ports(A.runtime_id)))
	return RuntimeStatus(runtime=A.runtime_id,mode=B,detail=_runtime_detail_for_context(A,C,B),worktree=A.worktree,compose_project=A.runtime_id,status='no_managed_runtime')
def list_all_runtime_statuses()->list[RuntimeStatus]:
	F=list_all_runtime_ports();C:dict[str,list[RuntimePort]]={}
	for E in F:C.setdefault(E.runtime,[]).append(E)
	B:list[RuntimeStatus]=[]
	for(A,D)in _docker_containers_by_runtime().items():
		if not A.startswith(RUNTIME_ID_PREFIX):continue
		B.append(RuntimeStatus(runtime=A,mode='devcontainer',detail=None,worktree=_worktree_from_containers(D),compose_project=A,status='running'if D else'not_running',containers=tuple(D),ports=tuple(C.get(A,[]))))
	for(A,G)in C.items():
		if A in{A.runtime for A in B}:continue
		B.append(RuntimeStatus(runtime=A,mode='devcontainer',detail=None,worktree=None,compose_project=A,status='running',ports=tuple(G)))
	return sorted(B,key=lambda status:status.runtime)
def create_preview_url(host_port:int,*,auth:bool=True)->str:
	G=os.environ.get('GV_PREVIEW_API_URL','http://127.0.0.1:42557/preview');D=os.environ.get('GV_PREVIEW_API_TOKEN','');H=json.dumps({'port':host_port,'auth':auth}).encode('utf-8');E={'Content-Type':'application/json'}
	if D:E['Authorization']=f"Bearer {D}"
	I=request.Request(G,data=H,headers=E,method='POST')
	try:
		with request.urlopen(I,timeout=30)as J:K=J.read().decode('utf-8')
	except error.HTTPError as A:L=A.read().decode('utf-8',errors='replace').strip();raise RuntimeError(f"Preview request failed: HTTP {A.code} {L}")from A
	except error.URLError as A:raise RuntimeError(f"Preview request failed: {A}")from A
	F=json.loads(K or'{}');B=F.get('url')
	if not isinstance(B,str)or not B:raise RuntimeError('Preview request succeeded but did not return a URL')
	C=F.get('text');return C if isinstance(C,str)and C else B
def load_devcontainer_config(repo_root:Path,setup_path:str|Path|None=None)->DevcontainerConfig:
	C=repo_root;A=_devcontainer_config_path(C,setup_path=setup_path)
	try:B=json.loads(A.read_text(encoding='utf-8'))
	except FileNotFoundError as E:raise RuntimeError(f"Devcontainer config not found at {A}.")from E
	except json.JSONDecodeError as E:raise RuntimeError(f"Invalid devcontainer JSON at {A}: {E}")from E
	if not isinstance(B,dict):raise RuntimeError(f"Invalid devcontainer config at {A}: top level must be an object.")
	if'dockerComposeFile'in B:
		G=_resolve_devcontainer_compose_files(A,B['dockerComposeFile']);H=[A for A in G if not A.is_file()]
		if H:raise RuntimeError(f"Referenced compose file not found: {_display_path(C,H[0])}")
		F=B.get('service')
		if not isinstance(F,str)or not F.strip():raise RuntimeError('Unsupported devcontainer shape: `dockerComposeFile` requires a string `service`.')
		return DevcontainerConfig(shape='compose',config_path=A,workspace_folder=C,compose_files=G,service=F.strip())
	if isinstance(B.get('image'),str)and B['image'].strip():return DevcontainerConfig(shape='single',config_path=A,workspace_folder=C)
	D=B.get('build')
	if isinstance(D,dict):
		I=D.get('dockerfile')or D.get('dockerFile')
		if isinstance(I,str)and I.strip():return DevcontainerConfig(shape='single',config_path=A,workspace_folder=C)
	if isinstance(D,str)and D.strip():return DevcontainerConfig(shape='single',config_path=A,workspace_folder=C)
	raise RuntimeError('This devcontainer shape is not supported by `tabtabtab runtime` yet. Supported shapes: `dockerComposeFile`, `image`, and `build.dockerfile`.')
def _select_runtime_setup(ctx:RuntimeContext,*,setup_path:str|None)->RuntimeSetupSelection:
	D=setup_path;A=ctx
	if D:B=load_devcontainer_config(A.repo_root,setup_path=D);_print_setup_choice('Using runtime setup from --setup-path',A.repo_root,B.config_path);return RuntimeSetupSelection(config=B,source='explicit')
	E=A.repo_root/MANAGED_DEVCONTAINER_FILE
	if E.is_file():
		try:B=load_devcontainer_config(A.repo_root,setup_path=E)
		except RuntimeError as G:
			print(f"Local runtime setup is incomplete: {G}");C=_hydrate_registered_setup(A.repo_root)
			if C is None:raise
			B=load_devcontainer_config(A.repo_root,setup_path=C);_print_setup_choice('Using registered runtime setup template',A.repo_root,B.config_path);return RuntimeSetupSelection(config=B,source='registered')
		_print_setup_choice('Using local runtime setup',A.repo_root,B.config_path);return RuntimeSetupSelection(config=B,source='local')
	C=_hydrate_registered_setup(A.repo_root)
	if C is not None:B=load_devcontainer_config(A.repo_root,setup_path=C);_print_setup_choice('Using registered runtime setup',A.repo_root,B.config_path);return RuntimeSetupSelection(config=B,source='registered')
	F=A.repo_root/NATIVE_DEVCONTAINER_FILE
	if F.is_file():B=load_devcontainer_config(A.repo_root,setup_path=F);_print_setup_choice('Using native devcontainer setup',A.repo_root,B.config_path);return RuntimeSetupSelection(config=B,source='native')
	raise RuntimeError('`tabtabtab runtime` requires `.tabtabtab/runtime/devcontainer.json` or `.devcontainer/devcontainer.json`. This repo is not yet onboarded to the TabTabTab runtime contract.')
def _hydrate_registered_setup(repo_root:Path)->Path|None:
	B=repo_root;F=_fetch_registered_setup(B)
	if F is None:return
	D,L=_render_registered_setup(B,F);print(f"Rendering registered runtime setup template into: {MANAGED_RUNTIME_DIR}")
	for(C,G)in sorted(L.items()):
		if C!=G:print(f"Assigned runtime port {C} -> {G}")
	H:dict[Path,str|None]={};I:list[Path]=[]
	try:
		for(J,A,J)in D:
			if A.exists()and not A.is_file():raise RuntimeError(f"Registered setup path conflicts with an existing non-file path: {_display_path(B,A)}")
		for(J,A,E)in D:H[A]=A.read_text(encoding='utf-8')if A.is_file()else None;I.extend(_create_parent_dirs(B,A));A.write_text(E,encoding='utf-8')
		for(M,A,E)in D:
			if A.read_text(encoding='utf-8')!=E:raise RuntimeError(f"Registered setup file verification failed: {M.path}")
	except Exception as K:
		for(A,C)in H.items():
			try:
				if C is None:A.unlink()
				else:A.write_text(C,encoding='utf-8')
			except OSError:pass
		for N in I:
			try:N.rmdir()
			except OSError:pass
		raise RuntimeError(f"Failed to hydrate registered setup files: {K}")from K
	return _setup_target_path(B,MANAGED_DEVCONTAINER_FILE)
def _render_registered_setup(repo_root:Path,setup:RegisteredSetup)->tuple[list[tuple[RegisteredSetupFile,Path,str]],dict[int,int]]:
	A=setup;_validate_registered_setup(A);G=next(A for A in A.files if A.path==MANAGED_DEVCONTAINER_FILE)
	try:B=json.loads(G.content)
	except json.JSONDecodeError as D:raise RuntimeError(f"Invalid registered devcontainer JSON: {D}")from D
	if not isinstance(B,dict):raise RuntimeError('Invalid registered devcontainer JSON: top level must be an object.')
	E=_assign_runtime_ports(sorted(set(A.forward_ports)|_template_ports(B)));F:list[tuple[RegisteredSetupFile,Path,str]]=[]
	for C in A.files:H=_setup_target_path(repo_root,C.path);F.append((C,H,_render_setup_file_content(C,B,E)))
	return F,E
def _render_setup_file_content(setup_file:RegisteredSetupFile,raw_devcontainer:dict[str,Any],port_map:dict[int,int])->str:
	C=port_map;B=raw_devcontainer;A=setup_file
	if A.path!=MANAGED_DEVCONTAINER_FILE:return _replace_template_ports(A.content,C)
	D=_rewrite_json_ports(B,C)
	if D==B:return A.content
	return json.dumps(D,indent=2)+'\n'
def _assign_runtime_ports(ports:list[int])->dict[int,int]:B:set[int]=set();return{A:_available_host_port(A,B)for A in ports}
def _available_host_port(start:int,reserved:set[int])->int:
	C=reserved;A=start
	if A<1 or A>65535:raise RuntimeError(f"Invalid runtime port: {A}")
	for B in range(A,65536):
		if B in C:continue
		with socket.socket(socket.AF_INET,socket.SOCK_STREAM)as D:
			try:D.bind(('127.0.0.1',B))
			except OSError:continue
		C.add(B);return B
	raise RuntimeError(f"No available host port found at or after {A}.")
def _template_ports(raw_devcontainer:dict[str,Any])->set[int]:
	A=raw_devcontainer;B=set(_ports_from_value(A.get('forwardPorts')));B.update(_ports_from_value(A.get('appPort')));C=A.get('portsAttributes')
	if isinstance(C,dict):
		for D in C:B.update(_ports_from_value(D))
	return B
def _ports_from_value(value:Any)->set[int]:
	A=value
	if isinstance(A,bool)or A is None:return set()
	if isinstance(A,int):return{A}if 1<=A<=65535 else set()
	if isinstance(A,str):return{int(A)for A in re.findall('(?<!\\d)(\\d{2,5})(?!\\d)',A)if 1<=int(A)<=65535}
	if isinstance(A,list):return{B for A in A for B in _ports_from_value(A)}
	return set()
def _rewrite_json_ports(value:Any,port_map:dict[int,int])->Any:
	B=port_map;A=value
	if isinstance(A,bool)or A is None:return A
	if isinstance(A,int):return B.get(A,A)
	if isinstance(A,str):return _replace_template_ports(A,B)
	if isinstance(A,list):return[_rewrite_json_ports(A,B)for A in A]
	if isinstance(A,dict):return{_replace_template_ports(str(A),B):_rewrite_json_ports(C,B)for(A,C)in A.items()}
	return A
def _replace_template_ports(value:str,port_map:dict[int,int])->str:
	A=value
	for(B,C)in sorted(port_map.items()):A=re.sub(rf"(?<!\d){B}(?!\d)",str(C),A)
	return A
def _fetch_registered_setup(repo_root:Path)->RegisteredSetup|None:
	B=_git_remote_url(repo_root)
	if B is None:return
	with httpx.Client(timeout=5)as C:A=C.get(f"{api_base_url()}/v1/runtime-setup",params={'gitRemoteUrl':B},headers={**auth_headers(),'Accept':'application/json'})
	if A.status_code==404:return
	raise_for_response(A);return _registered_setup(json.loads(A.text or'{}'))
def _validate_registered_setup(setup:RegisteredSetup)->None:
	B=setup;C:set[str]=set()
	if B.setup_hash!=_setup_hash(B.files):raise RuntimeError('Registered setup hash does not match setup files.')
	for A in B.files:
		if A.path in C:raise RuntimeError(f"Duplicate registered setup file: {A.path}")
		C.add(A.path)
		if not _is_managed_runtime_path(A.path)or A.path==MANAGED_RUNTIME_MANIFEST:raise RuntimeError(f"Invalid registered setup file path: {A.path}")
		if _sha256(A.content)!=A.hash:raise RuntimeError(f"Registered setup file hash mismatch from control plane: {A.path}")
	if MANAGED_DEVCONTAINER_FILE not in C:raise RuntimeError(f"Registered setup must include {MANAGED_DEVCONTAINER_FILE}.")
def _create_parent_dirs(repo_root:Path,target:Path)->list[Path]:
	C=repo_root.resolve();A=target.parent;B:list[Path]=[]
	while A!=C and not A.exists():B.append(A);A=A.parent
	for D in reversed(B):D.mkdir()
	return B
def _registered_setup(data:dict[str,Any])->RegisteredSetup:
	A=data.get('runtimeSetup')
	if not isinstance(A,dict):raise RuntimeError('Control-plane setup lookup returned no setup.')
	D=A.get('repoId');E=A.get('setupHash')
	if not isinstance(D,str)or not isinstance(E,str):raise RuntimeError('Control-plane setup lookup returned an invalid setup.')
	F=A.get('files')
	if not isinstance(F,list):raise RuntimeError('Control-plane setup lookup returned no setup files.')
	G=A.get('forwardPorts',[])
	if not isinstance(G,list):raise RuntimeError('Control-plane setup lookup returned invalid forward ports.')
	H:list[int]=[]
	for C in G:
		if isinstance(C,bool)or not isinstance(C,int):raise RuntimeError('Control-plane setup lookup returned invalid forward ports.')
		H.append(C)
	I:list[RegisteredSetupFile]=[]
	for B in F:
		if not isinstance(B,dict):raise RuntimeError('Control-plane setup lookup returned an invalid file record.')
		if not all(isinstance(B.get(A),str)for A in('path','content','hash')):raise RuntimeError('Control-plane setup lookup returned an invalid file record.')
		I.append(RegisteredSetupFile(path=B['path'],content=B['content'],hash=B['hash']))
	return RegisteredSetup(repo_id=D,setup_hash=E,forward_ports=H,files=I)
def _setup_target_path(repo_root:Path,value:str)->Path:
	B=repo_root;A=value
	if not A or Path(A).is_absolute():raise RuntimeError(f"Invalid registered setup file path: {A}")
	if not _is_managed_runtime_path(A):raise RuntimeError(f"Invalid registered setup file path: {A}")
	C=(B/A).resolve()
	try:C.relative_to(B.resolve())
	except ValueError as D:raise RuntimeError(f"Invalid registered setup file path: {A}")from D
	return C
def _is_managed_runtime_path(value:str)->bool:
	A=value;B=Path(A)
	if B.is_absolute()or'..'in B.parts:return False
	return A==MANAGED_RUNTIME_MANIFEST or A.startswith(f"{MANAGED_RUNTIME_DIR}/")
def _devcontainer_config_path(repo_root:Path,setup_path:str|Path|None=None)->Path:
	C=setup_path;B=repo_root
	if C is not None:
		A=Path(C)
		if not A.is_absolute():A=(Path.cwd()/A).resolve()
		else:A=A.resolve()
		try:A.relative_to(B.resolve())
		except ValueError as E:raise RuntimeError('Runtime setup path must be inside the repository.')from E
		return A
	D=B/MANAGED_DEVCONTAINER_FILE
	if D.is_file():return D
	return B/NATIVE_DEVCONTAINER_FILE
def _display_path(repo_root:Path,path:Path)->str:
	try:return str(path.resolve().relative_to(repo_root.resolve()))
	except ValueError:return str(path)
def _print_setup_choice(label:str,repo_root:Path,path:Path)->None:print(f"{label}: {_display_path(repo_root,path)}")
def _metadata_setup_path(ctx:RuntimeContext,metadata:dict[str,Any])->Path|None:
	B=metadata.get('setupPath')
	if not isinstance(B,str)or not B:return
	A=Path(B)
	if not A.is_absolute():A=ctx.repo_root/A
	return A
def _setup_hash(files:list[RegisteredSetupFile])->str:return _sha256('\n'.join(f"{A.path}\x00{A.hash}"for A in sorted(files,key=lambda item:item.path)))
def _sha256(value:str)->str:return hashlib.sha256(value.encode('utf-8')).hexdigest()
def _runtime_id_part(value:str)->str:A=re.sub('[^a-z0-9]+','-',value.lower());A=re.sub('-+','-',A).strip('-');return(A or'workspace')[:12]
def _git_toplevel(path:Path)->Path|None:
	A=subprocess.run(['git','-C',str(path),'rev-parse','--show-toplevel'],text=True,capture_output=True,check=False)
	if A.returncode!=0:return
	return Path(A.stdout.strip()).resolve()
def _git_project_root(repo_root:Path)->Path:
	B=repo_root;C=subprocess.run(['git','-C',str(B),'rev-parse','--git-common-dir'],text=True,capture_output=True,check=False)
	if C.returncode!=0:return B
	A=Path(C.stdout.strip())
	if not A.is_absolute():A=(B/A).resolve()
	else:A=A.resolve()
	if A.name=='.git':return A.parent
	return B
def _git_remote_url(repo_root:Path)->str|None:
	A=subprocess.run(['git','-C',str(repo_root),'remote','get-url','origin'],text=True,capture_output=True,check=False)
	if A.returncode!=0:return
	B=A.stdout.strip();return B or None
def _detect_runtime_mode(repo_root:Path)->RuntimeMode:
	A=repo_root
	if(A/MANAGED_DEVCONTAINER_FILE).is_file():return'devcontainer'
	if(A/NATIVE_DEVCONTAINER_FILE).is_file():return'devcontainer'
	return'none'
def _runtime_mode_for_context(ctx:RuntimeContext,metadata:dict[str,Any])->RuntimeMode:
	A=metadata.get('mode')
	if A in{'devcontainer','none'}:return A
	return _detect_runtime_mode(ctx.repo_root)
def _runtime_detail_for_context(ctx:RuntimeContext,metadata:dict[str,Any],mode:RuntimeMode)->str|None:
	B=metadata;A=B.get('detail')
	if isinstance(A,str)and A:return A
	if mode!='devcontainer':return
	try:return load_devcontainer_config(ctx.repo_root,setup_path=_metadata_setup_path(ctx,B)).shape
	except RuntimeError:return
def _compose_env(ctx:RuntimeContext)->dict[str,str]:A=os.environ.copy();A['COMPOSE_PROJECT_NAME']=ctx.runtime_id;return A
def _run_docker(args:list[str],*,check:bool,capture_output:bool=False,cwd:Path|None=None)->subprocess.CompletedProcess[str]:return subprocess.run(['docker',*args],text=True,capture_output=capture_output,check=check,cwd=cwd)
def _run_devcontainer_up(ctx:RuntimeContext,config:DevcontainerConfig,*,rebuild:bool=False)->None:
	B=config;A=ctx;C=['devcontainer','up','--workspace-folder',str(B.workspace_folder),'--config',str(B.config_path),'--id-label',f"{RUNTIME_LABEL}={A.runtime_id}"]
	if rebuild:C.append('--remove-existing-container')
	subprocess.run(C,cwd=A.repo_root,env=_compose_env(A),text=True,check=True)
def _run_devcontainer_down(ctx:RuntimeContext,config:DevcontainerConfig,*,ignore_missing:bool=False)->None:
	B=ignore_missing;A=config
	if A.shape=='compose':_run_devcontainer_compose_down(ctx,A,ignore_missing=B);return
	C=_container_ids_for_runtime(ctx.runtime_id)
	if not C:
		if B:return
		raise RuntimeError('No devcontainer runtime is currently running.')
	_run_docker(['rm','-f',*C],check=True)
def _run_devcontainer_compose_down(ctx:RuntimeContext,config:DevcontainerConfig,*,ignore_missing:bool)->None:
	C=config;A=['docker','compose']
	for D in C.compose_files:A.extend(['-f',str(D)])
	A.append('down');B=subprocess.run(A,cwd=C.config_path.parent,env=_compose_env(ctx),text=True,capture_output=True,check=False)
	if B.returncode==0:return
	if ignore_missing:return
	E=(B.stderr or B.stdout or'').strip();raise RuntimeError(E or'Failed to stop devcontainer compose runtime.')
def _write_metadata(ctx:RuntimeContext,mode:RuntimeMode,detail:str|None=None,config_path:Path|None=None)->None:
	D=config_path;C=detail;A=ctx;A.metadata_path.parent.mkdir(parents=True,exist_ok=True);B:dict[str,Any]={'id':A.runtime_id,'mode':mode,'worktree':str(A.worktree),'repoRoot':str(A.repo_root),'composeProject':A.runtime_id,'startedAt':datetime.now(timezone.utc).isoformat()}
	if C:B['detail']=C
	if D is not None:B['setupPath']=_display_path(A.repo_root,D)
	A.metadata_path.write_text(json.dumps(B,indent=2,sort_keys=True)+'\n')
def _read_metadata(path:Path)->dict[str,Any]:
	if not path.is_file():return{}
	try:A=json.loads(path.read_text(encoding='utf-8'))
	except(OSError,json.JSONDecodeError):return{}
	return A if isinstance(A,dict)else{}
def _docker_ps_rows()->list[dict[str,Any]]:
	B=_run_docker(['ps','--format','{{json .}}'],check=False,capture_output=True)
	if B.returncode!=0:return[]
	C:list[dict[str,Any]]=[]
	for A in B.stdout.splitlines():
		A=A.strip()
		if not A:continue
		try:D=json.loads(A)
		except json.JSONDecodeError:continue
		if isinstance(D,dict):C.append(D)
	return C
def _docker_inspect_rows(ids:list[str])->list[dict[str,Any]]:
	if not ids:return[]
	A=_run_docker(['inspect',*ids],check=False,capture_output=True)
	if A.returncode!=0:return[]
	try:B=json.loads(A.stdout)
	except json.JSONDecodeError:return[]
	return[A for A in B if isinstance(A,dict)]if isinstance(B,list)else[]
def _container_ids_for_runtime(runtime_id:str)->list[str]:A=_run_docker(['ps','-aq','--filter',f"label={RUNTIME_LABEL}={runtime_id}"],check=False,capture_output=True);return[A.strip()for A in A.stdout.splitlines()if A.strip()]
def _docker_containers_by_runtime()->dict[str,list[dict[str,str]]]:
	D=_docker_ps_rows();H=_docker_inspect_rows([str(A['ID'])for A in D if isinstance(A.get('ID'),str)and A['ID']]);I={str(A.get('Id',''))[:12]:A for A in H if str(A.get('Id',''))};E:dict[str,list[dict[str,str]]]={}
	for A in D:
		F=str(A.get('ID')or'');C=I.get(F,{});B=C.get('Config',{}).get('Labels',{})
		if not isinstance(B,dict):B={}
		G=str(B.get(RUNTIME_LABEL)or B.get('com.docker.compose.project')or'')
		if not G:continue
		E.setdefault(G,[]).append({'id':F,'image':str(A.get('Image')or''),'command':str(A.get('Command')or''),'created':str(A.get('RunningFor')or A.get('CreatedAt')or''),'status':str(A.get('Status')or''),'ports':str(A.get('Ports')or''),'names':str(A.get('Names')or _container_name(C)),'worktree':str(B.get(DEVCONTAINER_LABEL)or''),'startedAt':str(C.get('State',{}).get('StartedAt')or'')})
	return E
def _docker_containers_for_runtime(runtime_id:str)->list[dict[str,str]]:return _docker_containers_by_runtime().get(runtime_id,[])
def _worktree_from_containers(containers:list[dict[str,str]])->Path|None:
	for B in containers:
		A=B.get('worktree')
		if A:return Path(A)
def _docker_ports()->list[RuntimePort]:
	C:list[RuntimePort]=[]
	for B in _docker_inspect_rows([str(A['ID'])for A in _docker_ps_rows()if isinstance(A.get('ID'),str)and A['ID']]):
		A=B.get('Config',{}).get('Labels',{})
		if not isinstance(A,dict):A={}
		E=str(A.get(RUNTIME_LABEL)or A.get('com.docker.compose.project')or'');F=str(A.get('com.docker.compose.service')or A.get('devcontainer.metadata.service')or _container_name(B));G=B.get('NetworkSettings',{});H=G.get('Ports',{})if isinstance(G,dict)else{}
		if not isinstance(H,dict):continue
		for(N,D)in H.items():
			I=_parse_container_port(str(N))
			if I is None:continue
			J,K=I
			if not D:C.append(RuntimePort(runtime=E,service=F,container=_container_name(B),container_port=J,host_port=None,protocol=K));continue
			if not isinstance(D,list):continue
			for L in D:
				if not isinstance(L,dict):continue
				O=L.get('HostPort')
				try:M=int(str(O))
				except(TypeError,ValueError):M=None
				C.append(RuntimePort(runtime=E,service=F,container=_container_name(B),container_port=J,host_port=M,protocol=K))
	return C
def _parse_container_port(value:str)->tuple[int,str]|None:
	A,D,B=value.partition('/')
	try:C=int(A)
	except ValueError:return
	return C,B or'tcp'
def _container_name(container:dict[str,Any])->str:A=container;B=str(A.get('Name')or'').lstrip('/');return B or str(A.get('Id')or'')[:12]
def _runtime_port_json(port:RuntimePort)->dict[str,Any]:A=port;return{'runtime':A.runtime,'service':A.service,'container':A.container,'containerPort':A.container_port,'hostPort':A.host_port,'protocol':A.protocol}
def _runtime_status_json(status:RuntimeStatus)->dict[str,Any]:A=status;return{'runtime':A.runtime,'mode':A.mode,'detail':A.detail,'worktree':str(A.worktree)if A.worktree else None,'composeProject':A.compose_project,'status':A.status,'containers':[{'id':A.get('id')or'','image':A.get('image')or'','command':A.get('command')or'','created':A.get('created')or'','status':A.get('status')or'','ports':A.get('ports')or'','names':A.get('names')or'','startedAt':A.get('startedAt')or None}for A in A.containers],'ports':[_runtime_port_json(A)for A in A.ports]}
def _print_runtime_statuses(statuses:list[RuntimeStatus],*,include_runtime:bool)->None:
	B=statuses
	if not B:print('No runtime status found.');return
	for(C,A)in enumerate(B):
		if C>0:print('')
		D=f" ({A.detail})"if A.detail else'';print(f"Runtime: {A.runtime}");print(f"Mode: {A.mode}{D}")
		if A.worktree:print(f"Worktree: {A.worktree}")
		print(f"Compose project: {A.compose_project}")
		if A.mode=='devcontainer'and A.containers:print('');_print_containers(A.containers)
		elif A.mode=='devcontainer':print('Status: not running or unavailable')
		else:print('Status: no managed runtime found')
		if A.ports:print('');_print_ports(A.ports,include_runtime=include_runtime)
def _print_containers(containers:tuple[dict[str,str],...])->None:
	C=['CONTAINER ID','IMAGE','COMMAND','CREATED','STATUS','PORTS','NAMES'];D=[[A.get('id')or'',A.get('image')or'',A.get('command')or'',A.get('created')or'',A.get('status')or'',A.get('ports')or'',A.get('names')or'']for A in containers];A=[len(A)for A in C]
	for B in D:
		for(E,F)in enumerate(B):A[E]=max(A[E],len(F))
	print('  '.join(C[B].ljust(A[B])for B in range(len(C))))
	for B in D:print('  '.join(B[C].ljust(A[C])for C in range(len(B))))
def _print_ports(ports:list[RuntimePort],*,include_runtime:bool)->None:
	G=include_runtime;F=ports
	if not F:print('No runtime ports found.');return
	C=['SERVICE','CONTAINER','HOST','PROTO'];E:list[list[str]]=[]
	if G:C.insert(0,'RUNTIME')
	for B in F:
		A=[B.service,str(B.container_port),str(B.host_port)if B.host_port else'-',B.protocol]
		if G:A.insert(0,B.runtime)
		E.append(A)
	D=[len(A)for A in C]
	for A in E:
		for(H,I)in enumerate(A):D[H]=max(D[H],len(I))
	print('  '.join(C[A].ljust(D[A])for A in range(len(C))))
	for A in E:print('  '.join(A[B].ljust(D[B])for B in range(len(A))))
def _resolve_preview_port(runtime_id:str,target:str)->int:
	A=target
	if A.isdigit():
		C=int(A)
		if C<1 or C>65535:raise RuntimeError('Preview port must be between 1 and 65535.')
		return C
	B=[B for B in list_runtime_ports(runtime_id)if B.service==A and B.host_port is not None]
	if not B:raise RuntimeError(f"No published host port found for service `{A}`.")
	if len(B)>1:D=', '.join(f"{A.service}:{A.container_port}->{A.host_port}"for A in B);raise RuntimeError(f"Service `{A}` has multiple published ports. Use a host port instead: {D}")
	return int(B[0].host_port)
def _resolve_devcontainer_compose_files(config_path:Path,value:Any)->tuple[Path,...]:
	A=value;B:list[str]
	if isinstance(A,str)and A.strip():B=[A.strip()]
	elif isinstance(A,list):B=[A.strip()for A in A if isinstance(A,str)and A.strip()]
	else:raise RuntimeError('Unsupported devcontainer shape: `dockerComposeFile` must be a string or list of strings.')
	if not B:raise RuntimeError('Unsupported devcontainer shape: `dockerComposeFile` must not be empty.')
	C=config_path.parent;return tuple((C/A).resolve()for A in B)