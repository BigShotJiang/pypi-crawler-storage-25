# ReDSL

**Re**factor + **DSL** + **S**elf-**L**earning — autonomous code refactoring with LLM, memory, and DSL.

ReDSL is a code refactoring system that combines static analysis, DSL rules, and LLM intelligence to automatically improve Python code quality.

## Features

- 🔍 **Static Analysis** - Integration with popular linters and metrics tools
- 🧠 **LLM with Reflection** - Generate refactoring proposals with self-reflection loop
- ⚡ **Hybrid Engine** - Direct refactorings for simple changes, LLM for complex ones
- 📊 **DSL Engine** - Define refactoring rules in readable YAML format
- 💾 **Memory System** - Learn from refactoring history
- 🚀 **Scalability** - Process multiple projects simultaneously

## Installation

```bash
pip install redsl
```

## Quick Start

### Basic CLI Usage

```bash
# Refactor a single project
redsl refactor ./my-project --max-actions 5 --dry-run

# Refactor without dry run
redsl refactor ./my-project --max-actions 10
```

### Batch Processing

```bash
# Process semcod projects with LLM
redsl batch semcod /path/to/semcod --max-actions 10

# Hybrid refactoring (no LLM) for semcod projects
redsl batch hybrid /path/to/semcod --max-changes 30
```

### Debugging

```bash
# Check configuration
redsl debug config --show-env

# View DSL decisions for a project
redsl debug decisions ./my-project --limit 20
```

## Available Refactoring Actions

### Simple Actions (no LLM)
- `REMOVE_UNUSED_IMPORTS` - Remove unused imports
- `FIX_MODULE_EXECUTION_BLOCK` - Fix module execution blocks
- `EXTRACT_CONSTANTS` - Extract magic numbers to constants
- `ADD_RETURN_TYPES` - Add return type annotations

### Complex Actions (with LLM)
- `EXTRACT_FUNCTIONS` - Extract high-complexity functions
- `SPLIT_MODULE` - Split large modules
- `REDUCE_COMPLEXITY` - Reduce cyclomatic complexity

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                  ORCHESTRATOR                       │
│   (loop: analyze → decide → refactor → reflect)    │
├─────────────┬──────────────┬────────────────────────┤
│  ANALYZER   │  DSL ENGINE  │   REFACTOR ENGINE      │
│  ─ toon.yaml│  ─ rules     │   ─ patch generation   │
│  ─ linters  │  ─ scoring   │   ─ validation         │
│  ─ metrics  │  ─ planning  │   ─ application        │
├─────────────┴──────────────┴────────────────────────┤
│            HYBRID REFACTOR ENGINES                  │
│  ─ DirectRefactorEngine (no LLM)                   │
│  ─ LLM RefactorEngine (with reflection)            │
├─────────────────────────────────────────────────────┤
│                  LLM LAYER (LiteLLM)                │
│   ─ code generation  ─ reflection  ─ self-critique  │
├─────────────────────────────────────────────────────┤
│                 MEMORY SYSTEM                       │
│   ─ episodic (refactoring history)                 │
│   ─ semantic (patterns, rules)                     │
│   ─ procedural (strategies, plans)                 │
└─────────────────────────────────────────────────────┘
```

## Configuration

Environment variables:
- `OPENAI_API_KEY` or `OPENROUTER_API_KEY` — API key
- `REFACTOR_LLM_MODEL` — LLM model (e.g., `openrouter/openai/gpt-5.4-mini`)
- `REFACTOR_DRY_RUN` — test mode (`true`/`false`)

## Examples

| Directory | Description |
|-----------|-------------|
| `examples/01-basic-analysis/` | Project analysis from toon.yaml files |
| `examples/02-custom-rules/` | Define custom DSL rules |
| `examples/03-full-pipeline/` | Full cycle: analyze → decide → refactor → reflect |
| `examples/04-memory-learning/` | Memory system: episodic, semantic, procedural |

## License

Apache License 2.0
