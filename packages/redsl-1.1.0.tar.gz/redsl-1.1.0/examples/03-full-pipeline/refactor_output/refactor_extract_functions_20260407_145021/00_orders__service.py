def process_order(order, user, db, mailer, logger, inventory, pricing, tax, discount, shipping):
    """Funkcja z CC=25 i fan-out=10 — idealny kandydat do refaktoryzacji."""
    if not _validate_order_and_user(order, user, logger):
        return None
    
    if _is_order_terminal(order, logger):
        return order

    items = order.items
    total = _calculate_order_total(
        items, user, inventory, pricing, tax, discount, logger
    )

    if total <= 0:
        logger.error("Empty order total")
        return None

    shipping_cost = shipping.calculate(order.address, items)
    total += shipping_cost
    
    return _finalize_order(order, total, db, mailer, logger)


def _validate_order_and_user(order, user, logger):
    """Validate that order and user exist."""
    if not order:
        logger.error("No order")
        return False
    if not user:
        logger.error("No user")
        return False
    return True


def _is_order_terminal(order, logger):
    """Check if order is in a terminal state (cancelled/completed)."""
    if order.status == "cancelled":
        logger.info("Order cancelled")
        return True
    if order.status == "completed":
        logger.info("Order already completed")
        return True
    return False


def _calculate_order_total(items, user, inventory, pricing, tax, discount, logger):
    """Calculate total order amount considering item types, pricing, tax, and discounts."""
    total = 0
    for item in items:
        if item.type == "physical":
            _process_physical_item(
                item, inventory, pricing, tax, discount, user, logger
            )
            price = pricing.get_price(item.sku)
            if discount.is_eligible(user, item):
                price = discount.apply(price, user.tier)
            tax_amount = tax.calculate(price, user.region)
            total += price + tax_amount
        elif item.type == "digital":
            price = pricing.get_price(item.sku)
            total += price
        elif item.type == "subscription":
            price = pricing.get_subscription_price(item.sku, item.period)
            total += price
        else:
            logger.warning(f"Unknown item type: {item.type}")
    return total


def _process_physical_item(item, inventory, pricing, tax, discount, user, logger):
    """Process physical item inventory and pricing logic."""
    stock = inventory.check(item.sku)
    if stock <= 0:
        logger.warning(f"Out of stock: {item.sku}")
        if item.backorder_allowed:
            inventory.backorder(item.sku, item.quantity)
        else:
            raise ValueError(f"Out of stock: {item.sku}")


def _finalize_order(order, total, db, mailer, logger):
    """Finalize order: set total, status, save to DB, and send confirmation."""
    order.total = total
    order.status = "processing"
    db.save(order)
    mailer.send_confirmation(user.email, order)
    logger.info(f"Order {order.id} processed: ${total}")
    return order