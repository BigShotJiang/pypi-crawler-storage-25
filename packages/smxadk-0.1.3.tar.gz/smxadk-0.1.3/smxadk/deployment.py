from pathlib import Path
from typing import Any

import yaml


SUPPORTED_OPENAI_PROVIDERS = {"openai_compatible", "vllm"}
SUPPORTED_OLLAMA_PROVIDERS = {"ollama", "ollama_chat"}


def load_yaml_config(config_path: str | Path) -> dict[str, Any]:
    path = Path(config_path)

    if not path.exists():
        raise FileNotFoundError(f"Config not found: {path}")

    with path.open("r", encoding="utf-8") as file:
        data = yaml.safe_load(file)

    if not isinstance(data, dict):
        raise ValueError("Config must be a YAML object.")

    return data


def normalise_config(config: dict[str, Any]) -> dict[str, Any]:
    """
    Supports both formats:

    1. New ADK format:
       models:
         chat:
           expert:
             provider: openai_compatible
             model: ...
             api_base: ...

    2. Legacy format:
       models:
         expert:
           provider: openai_compatible
           model: ...
           api_base: ...
    """
    models = config.get("models")

    if not isinstance(models, dict):
        raise ValueError("Config must contain a 'models' section.")

    # New smx.yaml format
    if "chat" in models:
        chat_models = models.get("chat") or {}

        if not isinstance(chat_models, dict) or not chat_models:
            raise ValueError("models.chat must contain at least one chat route.")

        return {
            **config,
            "models": chat_models,
        }

    # Legacy format
    return config


def load_deployment_config(config_path: str | Path) -> dict[str, Any]:
    return normalise_config(load_yaml_config(config_path))


def get_supported_modes(config: dict[str, Any]) -> list[str]:
    agent_service = config.get("agent_service") or {}
    supported_modes = agent_service.get("supported_modes")

    if supported_modes:
        return list(supported_modes)

    return list(config["models"].keys())


def build_litellm_model_entry(mode: str, model_config: dict[str, Any]) -> dict[str, Any]:
    provider = model_config["provider"]
    model = model_config["model"]
    api_base = model_config["api_base"]

    if provider in SUPPORTED_OLLAMA_PROVIDERS:
        litellm_params = {
            "model": f"{provider}/{model}",
            "api_base": api_base,
        }

    elif provider in SUPPORTED_OPENAI_PROVIDERS:
        litellm_params = {
            "model": f"openai/{model}",
            "api_base": api_base,
            "api_key": model_config.get("api_key", "dummy-key"),
        }

    else:
        raise ValueError(
            f"Unsupported provider '{provider}' for mode '{mode}'. "
            f"Supported providers: ollama, ollama_chat, openai_compatible, vllm"
        )

    return {
        "model_name": mode,
        "litellm_params": litellm_params,
    }


def generate_litellm_config(config: dict[str, Any]) -> dict[str, Any]:
    config = normalise_config(config)
    supported_modes = get_supported_modes(config)
    models = config["models"]

    model_list = []

    for mode in supported_modes:
        if mode not in models:
            raise ValueError(
                f"Mode '{mode}' is listed in supported modes "
                f"but is missing from models."
            )

        model_list.append(
            build_litellm_model_entry(
                mode=mode,
                model_config=models[mode],
            )
        )

    return {
        "model_list": model_list,
        "general_settings": {
            "master_key": None,
        },
    }


def get_default_output_paths(config: dict[str, Any]) -> tuple[str, str]:
    outputs = config.get("outputs") or {}

    litellm_output = outputs.get("litellm_config", "../llm-proxy/config.yaml")
    modes_output = outputs.get("supported_modes", "../agent-service/supported_modes.txt")

    return litellm_output, modes_output


def write_litellm_config(
    *,
    config_path: str | Path,
    output_path: str | Path | None = None,
) -> Path:
    config = load_deployment_config(config_path)
    default_litellm_output, _ = get_default_output_paths(load_yaml_config(config_path))

    output = Path(output_path or default_litellm_output)

    litellm_config = generate_litellm_config(config)

    output.parent.mkdir(parents=True, exist_ok=True)

    with output.open("w", encoding="utf-8") as file:
        yaml.safe_dump(
            litellm_config,
            file,
            sort_keys=False,
            default_flow_style=False,
        )

    return output


def write_supported_modes(
    *,
    config_path: str | Path,
    output_path: str | Path | None = None,
) -> Path:
    config = load_deployment_config(config_path)
    _, default_modes_output = get_default_output_paths(load_yaml_config(config_path))

    output = Path(output_path or default_modes_output)

    supported_modes = get_supported_modes(config)

    output.parent.mkdir(parents=True, exist_ok=True)

    with output.open("w", encoding="utf-8") as file:
        file.write(",".join(supported_modes))

    return output