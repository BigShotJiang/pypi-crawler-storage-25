from pydantic import BaseModel


class TokenUsage(BaseModel):
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    total_tokens: int | None = None


class ChatResponse(BaseModel):
    mode: str
    answer: str
    usage: TokenUsage


class HealthResponse(BaseModel):
    status: str
    litellm_configured: bool
    supported_modes: list[str]