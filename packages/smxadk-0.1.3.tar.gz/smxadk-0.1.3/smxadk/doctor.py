from __future__ import annotations

from pathlib import Path
from typing import Any

import httpx

from smxadk.deployment import (
    get_default_output_paths,
    get_supported_modes,
    load_deployment_config,
    load_yaml_config,
)


def _ok(message: str) -> None:
    print(f"[OK] {message}")


def _warn(message: str) -> None:
    print(f"[WARN] {message}")


def _fail(message: str) -> None:
    print(f"[FAIL] {message}")


def _get_nested(config: dict[str, Any], *keys: str) -> Any:
    current: Any = config

    for key in keys:
        if not isinstance(current, dict):
            return None
        current = current.get(key)

    return current


def validate_config_shape(config_path: str) -> tuple[dict[str, Any], dict[str, Any], list[str]]:
    raw_config = load_yaml_config(config_path)
    normalised_config = load_deployment_config(config_path)
    supported_modes = get_supported_modes(normalised_config)

    _ok(f"Config file found: {config_path}")

    project_name = _get_nested(raw_config, "project", "name")
    if project_name:
        _ok(f"Project name: {project_name}")
    else:
        _warn("project.name is not set.")

    if not supported_modes:
        raise ValueError("No supported chat modes found.")

    _ok(f"Supported chat modes: {', '.join(supported_modes)}")

    models = normalised_config["models"]

    for mode in supported_modes:
        if mode not in models:
            raise ValueError(f"Mode '{mode}' is listed but missing from models.")

        model_config = models[mode]

        for field in ("provider", "model", "api_base"):
            if not model_config.get(field):
                raise ValueError(f"Mode '{mode}' is missing required field: {field}")

        provider = model_config["provider"]
        api_base = model_config["api_base"]

        if provider in {"openai_compatible", "vllm"} and not api_base.rstrip("/").endswith("/v1"):
            _warn(f"Mode '{mode}' is OpenAI-compatible but api_base does not end with /v1.")

        if provider in {"ollama", "ollama_chat"} and api_base.rstrip("/").endswith("/v1"):
            _warn(f"Mode '{mode}' is Ollama but api_base ends with /v1.")

        _ok(f"Mode '{mode}' configured: provider={provider}, model={model_config['model']}")

    return raw_config, normalised_config, supported_modes


def validate_generated_outputs(raw_config: dict[str, Any]) -> None:
    litellm_output, modes_output = get_default_output_paths(raw_config)

    litellm_path = Path(litellm_output)
    modes_path = Path(modes_output)

    if litellm_path.exists():
        _ok(f"Generated LiteLLM config exists: {litellm_path}")
    else:
        _warn(f"Generated LiteLLM config not found: {litellm_path}")

    if modes_path.exists():
        _ok(f"Generated supported modes file exists: {modes_path}")
    else:
        _warn(f"Generated supported modes file not found: {modes_path}")


def check_litellm_proxy(
    *,
    raw_config: dict[str, Any],
    supported_modes: list[str],
    timeout: float,
) -> None:
    litellm_url = str(_get_nested(raw_config, "services", "litellm_proxy", "url") or "").strip().rstrip("/")

    if not litellm_url:
        _warn("services.litellm_proxy.url is not set. Skipping LiteLLM live check.")
        return

    _ok(f"LiteLLM proxy URL configured: {litellm_url}")

    try:
        response = httpx.get(f"{litellm_url}/v1/models", timeout=timeout)
        response.raise_for_status()
        data = response.json()
    except Exception as exc:
        _fail(f"LiteLLM /v1/models check failed: {exc}")
        raise

    returned_modes = [
        item.get("id")
        for item in data.get("data", [])
        if isinstance(item, dict) and item.get("id")
    ]

    missing = [mode for mode in supported_modes if mode not in returned_modes]

    if missing:
        raise ValueError(
            "LiteLLM proxy is missing expected modes: "
            + ", ".join(missing)
        )

    _ok("LiteLLM /v1/models returned all supported modes.")


def check_agent_service(
    *,
    raw_config: dict[str, Any],
    supported_modes: list[str],
    timeout: float,
) -> None:
    agent_url = str(_get_nested(raw_config, "services", "agent_service", "url") or "").strip().rstrip("/")

    if not agent_url:
        _warn("services.agent_service.url is not set. Skipping Agent Service live check.")
        return

    _ok(f"Agent Service URL configured: {agent_url}")

    try:
        response = httpx.get(f"{agent_url}/health", timeout=timeout)
        response.raise_for_status()
        data = response.json()
    except Exception as exc:
        _fail(f"Agent Service /health check failed: {exc}")
        raise

    returned_modes = data.get("supported_modes") or []

    missing = [mode for mode in supported_modes if mode not in returned_modes]

    if missing:
        raise ValueError(
            "Agent Service is missing expected supported modes: "
            + ", ".join(missing)
        )

    _ok("Agent Service /health returned all supported modes.")


def test_agent_routes(
    *,
    raw_config: dict[str, Any],
    supported_modes: list[str],
    timeout: float,
    max_tokens: int,
) -> None:
    agent_url = str(_get_nested(raw_config, "services", "agent_service", "url") or "").strip().rstrip("/")

    if not agent_url:
        _warn("services.agent_service.url is not set. Skipping route chat tests.")
        return

    for mode in supported_modes:
        payload = {
            "message": f"Reply with exactly: smxadk doctor {mode} route works",
            "mode": mode,
            "temperature": 0.0,
            "max_tokens": max_tokens,
        }

        try:
            response = httpx.post(
                f"{agent_url}/chat",
                json=payload,
                timeout=timeout,
            )
            response.raise_for_status()
            data = response.json()
        except Exception as exc:
            _fail(f"Route test failed for mode '{mode}': {exc}")
            raise

        answer = str(data.get("answer") or "").strip()
        usage = data.get("usage") or {}

        if not answer:
            raise ValueError(f"Route '{mode}' returned an empty answer.")

        if usage.get("total_tokens") is None:
            _warn(f"Route '{mode}' response did not include usage.total_tokens.")
        else:
            _ok(f"Route '{mode}' returned answer and usage.total_tokens={usage.get('total_tokens')}.")


def run_doctor(
    *,
    config_path: str = "smx.yaml",
    timeout: float = 600.0,
    test_routes: bool = False,
    max_tokens: int = 80,
) -> int:
    print("smxADK doctor")
    print("=============")

    try:
        raw_config, _normalised_config, supported_modes = validate_config_shape(config_path)
        validate_generated_outputs(raw_config)
        check_litellm_proxy(
            raw_config=raw_config,
            supported_modes=supported_modes,
            timeout=timeout,
        )
        check_agent_service(
            raw_config=raw_config,
            supported_modes=supported_modes,
            timeout=timeout,
        )

        if test_routes:
            test_agent_routes(
                raw_config=raw_config,
                supported_modes=supported_modes,
                timeout=timeout,
                max_tokens=max_tokens,
            )
        else:
            _warn("Route chat tests skipped. Use --test-routes to test live chat routes.")

        print()
        _ok("Doctor completed.")
        return 0

    except Exception as exc:
        print()
        _fail(str(exc))
        return 1