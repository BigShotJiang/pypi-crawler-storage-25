DEFAULT_DEPLOYMENT_TEMPLATE = """# SyntaxMatrix self-hosted deployment configuration.
#
# This file belongs in the client deployment project.
#
# Fill only the routes your organisation has actually deployed.
# Remove any route you do not operate.
#
# The mode names below are route labels, not model requirements.
# The model names are the exact names served by your backend.

agent_service:
  supported_modes:
    - light
    - medium
    - heavy
    - expert
    - expert-heavy

models:
  light:
    provider: ollama
    model: your-light-model-name
    api_base: https://your-light-ollama-service-url

  medium:
    provider: ollama
    model: your-medium-model-name
    api_base: https://your-medium-ollama-service-url

  heavy:
    provider: ollama
    model: your-heavy-model-name
    api_base: https://your-heavy-ollama-service-url

  expert:
    provider: vllm
    model: your-expert-model-name
    api_base: https://your-expert-vllm-service-url/v1

  expert-heavy:
    provider: vllm
    model: your-expert-heavy-model-name
    api_base: https://your-expert-heavy-vllm-service-url/v1
"""