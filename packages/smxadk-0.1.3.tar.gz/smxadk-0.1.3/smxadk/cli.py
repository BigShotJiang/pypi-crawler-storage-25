import argparse
import sys

from smxadk.deployment import write_litellm_config, write_supported_modes
from smxadk.doctor import run_doctor


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="smxadk",
        description="SyntaxMatrix Agent Development Kit CLI",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    generate_parser = subparsers.add_parser(
        "generate",
        help="Generate deployment files from smx.yaml",
    )

    generate_parser.add_argument(
        "--config",
        default="smx.yaml",
        help="Path to the SyntaxMatrix ADK config. Default: smx.yaml",
    )

    generate_parser.add_argument(
        "--litellm-output",
        default=None,
        help="Optional override path for generated LiteLLM config.yaml.",
    )

    generate_parser.add_argument(
        "--modes-output",
        default=None,
        help="Optional override path for generated supported_modes.txt.",
    )

    doctor_parser = subparsers.add_parser(
        "doctor",
        help="Validate smxADK config, generated files, proxy, Agent Service, and routes.",
    )

    doctor_parser.add_argument(
        "--config",
        default="smx.yaml",
        help="Path to the SyntaxMatrix ADK config. Default: smx.yaml",
    )

    doctor_parser.add_argument(
        "--timeout",
        type=float,
        default=600.0,
        help="HTTP timeout in seconds for live checks.",
    )

    doctor_parser.add_argument(
        "--test-routes",
        action="store_true",
        help="Run live /chat checks for every supported mode.",
    )

    doctor_parser.add_argument(
        "--max-tokens",
        type=int,
        default=80,
        help="Max tokens to use for route chat tests.",
    )

    args = parser.parse_args()

    if args.command == "generate":
        litellm_path = write_litellm_config(
            config_path=args.config,
            output_path=args.litellm_output,
        )

        modes_path = write_supported_modes(
            config_path=args.config,
            output_path=args.modes_output,
        )

        print(f"Generated LiteLLM config: {litellm_path}")
        print(f"Generated supported modes: {modes_path}")

    elif args.command == "doctor":
        exit_code = run_doctor(
            config_path=args.config,
            timeout=args.timeout,
            test_routes=args.test_routes,
            max_tokens=args.max_tokens,
        )
        sys.exit(exit_code)


if __name__ == "__main__":
    main()