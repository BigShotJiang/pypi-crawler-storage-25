# axonet

Utilities for neural network experiments.

A neural network is composed of layers of artificial neurons (loosely modeled after biological neurons connected by axons and synapses). Each neuron applies a learnable linear transformation followed by a nonlinearity. Modern architectures — feedforward, convolutional, recurrent, and transformer — all build on this core mechanic.

## Install

```
pip install axonet
```
