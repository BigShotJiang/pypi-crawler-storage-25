"""The axonet.conventions reference entry — canonical names and conventions."""
from ._entry import Entry


conventions = Entry(
    name="conventions",
    title="Canonical names and conventions used throughout axonet",
    code='''# ─── variable name conventions ───
#   train, test               raw DataFrames from CSV
#   target_col, id_col        column-name strings (edit in CONFIG block)
#   X, y, X_test              features, target, test features
#   X_pp, X_test_pp           preprocessed features (after ColumnTransformer)
#   num_cols, cat_cols        dtype-detected column lists
#   oof                       out-of-fold predictions on training set
#   test_preds                averaged test predictions across folds
#   predictions               final integer/class labels for submission

# ─── CONFIG block at top of every pipeline section ───
# Each section opens with a CONFIG block. Edit only those lines.
# Body of the snippet uses these names — never touch the body.
#
#   # ─── CONFIG ───
#   target_col = "target"
#   id_col     = "id"
#   metric     = "roc_auc"
#   # ──────────────

# ─── standard sequence ───
#   load → eda → failure_modes → preprocess → cv_train → threshold → submit

# ─── helpers in axonet.utils ───
#   preflight()                                   env check (Python, libs, GPU)
#   set_seed(42)                                  seed numpy/torch/random/cuda
#   detect_columns(df, target_col=...)            dict of column-type lists
#   check_dataset(train, test, target_col)        sanity-check report
#   submit(predictions, ids, target_col=...)      writes submission CSV with checks
#   find(query)                                   search across loaded entries

# ─── how to navigate the library ───
#   axonet.index()                                top-level subpackages
#   axonet.ml.index()                             ML building blocks + pipelines
#   axonet.ml.binary.index()                      binary pipeline sections
#   axonet.ml.boosting.lightgbm                   single building block (rich repr)
#   axonet.ml.boosting.lightgbm.code              just the code as a string
''',
    notes=[
        "Read this once. Every snippet in axonet uses these names consistently.",
        "Pipeline sections (e.g., axonet.ml.binary.preprocess) are short drop-in cells.",
        "Top-level building blocks (e.g., axonet.ml.preprocess) are deeper reference for swap-outs.",
        "When a snippet declares 'Inputs: X_pp, y' it expects those variables to exist from the prior cell.",
    ],
    when_to_use=[
        "First read after installing axonet",
        "When something doesn't match your task's data shape",
    ],
)
