"""Internal: Entry class and shared helpers."""

import sys
import types


class Entry:
    """A reference entry. Type the entry name (no parens) in a Jupyter cell to
    display its full content. Use ``.code`` to get just the code as a string.
    """

    def __init__(
        self,
        name,
        title,
        code="",
        notes=None,
        when_to_use=None,
        inputs=None,
        outputs=None,
        requires=None,
        brief="",
    ):
        self.name = name
        self.title = title
        self.code = code
        self.notes = list(notes) if notes else []
        self.when_to_use = list(when_to_use) if when_to_use else []
        self.inputs = list(inputs) if inputs else []
        self.outputs = list(outputs) if outputs else []
        self.requires = list(requires) if requires else []
        self.brief = brief or title
        self.__doc__ = f"{name} — {title}\n\n{self.brief}"

    def __repr__(self):
        lines = [f"{self.name}  —  {self.title}", ""]

        if self.code:
            lines.append("Code")
            lines.append(self.code.strip())
            lines.append("")

        if self.notes:
            lines.append("Notes")
            lines.extend(f"  - {n}" for n in self.notes)
            lines.append("")

        if self.when_to_use:
            lines.append("When to use")
            lines.extend(f"  - {w}" for w in self.when_to_use)
            lines.append("")

        # contract block — what the snippet expects to exist and what it produces
        contract = []
        if self.inputs:
            contract.append(f"Inputs:   {', '.join(self.inputs)}")
        if self.outputs:
            contract.append(f"Outputs:  {', '.join(self.outputs)}")
        if self.requires:
            contract.append(f"Requires: {', '.join(self.requires)}")
        if contract:
            lines.append("\n".join(contract))

        return "\n".join(lines).rstrip()

    def __str__(self):
        return self.__repr__()


def _make_index(module_name):
    """Return an `index()` function bound to a specific module path. Each
    submodule's __init__.py does ``index = _make_index(__name__)`` so calling
    ``axonet.cv.index()`` lists everything one level down inside cv.
    """

    def index():
        module = sys.modules[module_name]
        names = [n for n in dir(module)
                 if not n.startswith('_') and n != 'index']
        lines = [f"{module.__name__}:"]
        for n in sorted(names):
            obj = getattr(module, n)
            if isinstance(obj, Entry):
                lines.append(f"  {n}  —  {obj.title}")
            elif isinstance(obj, types.ModuleType):
                # only show submodules of axonet (skip stdlib / external imports)
                if not getattr(obj, "__name__", "").startswith("axonet"):
                    continue
                doc = (obj.__doc__ or "").splitlines()[0] if obj.__doc__ else ""
                lines.append(f"  {n}/  —  {doc}" if doc else f"  {n}/")
            elif callable(obj):
                # only show functions defined locally (skip imported helpers like Entry)
                if getattr(obj, "__module__", "") != module_name:
                    continue
                doc = (obj.__doc__ or "").splitlines()[0] if obj.__doc__ else ""
                lines.append(f"  {n}()  —  {doc}" if doc else f"  {n}()")
        print("\n".join(lines))

    index.__doc__ = f"One-level listing of {module_name}."
    return index
