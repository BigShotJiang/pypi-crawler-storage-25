"""axonet: utilities for neural network experiments."""
import importlib as _importlib

from ._conventions import conventions

__version__ = "0.1.3"

_subpackages = ("ml", "cv", "nlp", "audio", "mm", "qa", "utils")


def __getattr__(name):
    if name in _subpackages:
        module = _importlib.import_module(f".{name}", __name__)
        globals()[name] = module
        return module
    raise AttributeError(f"module 'axonet' has no attribute {name!r}")


def __dir__():
    return sorted(set(globals()) | set(_subpackages) | {"index"})


def index():
    """One-level listing of axonet's top structure."""
    lines = ["axonet:"]
    lines.append(f"  conventions  —  {conventions.title}")
    for sub in sorted(_subpackages):
        try:
            m = _importlib.import_module(f".{sub}", __name__)
            doc = (m.__doc__ or "").splitlines()[0] if m.__doc__ else ""
            lines.append(f"  {sub}/  —  {doc}" if doc else f"  {sub}/")
        except ImportError:
            lines.append(f"  {sub}/")
    print("\n".join(lines))
