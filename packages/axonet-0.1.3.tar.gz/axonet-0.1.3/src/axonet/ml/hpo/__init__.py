"""Hyperparameter optimization with Optuna — boosting libraries + sensible search spaces.

50 trials × ~30 sec per trial = ~25 min. Fits a 30-minute budget. Use only
after the baseline pipeline (data → preprocess → boosting + cv) is in place.
"""
from ..._entry import Entry, _make_index


optuna_lightgbm = Entry(
    name="optuna_lightgbm",
    title="Optuna search for LightGBM hyperparameters",
    code='''import optuna
import lightgbm as lgb
import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score


def objective(trial):
    params = {
        "n_estimators":      trial.suggest_int("n_estimators", 500, 3000),
        "learning_rate":     trial.suggest_float("learning_rate", 0.01, 0.3, log=True),
        "num_leaves":        trial.suggest_int("num_leaves", 15, 255),
        "max_depth":         trial.suggest_int("max_depth", 3, 12),
        "min_child_samples": trial.suggest_int("min_child_samples", 5, 100),
        "subsample":         trial.suggest_float("subsample", 0.6, 1.0),
        "colsample_bytree":  trial.suggest_float("colsample_bytree", 0.6, 1.0),
        "reg_alpha":         trial.suggest_float("reg_alpha",  1e-3, 10.0, log=True),
        "reg_lambda":        trial.suggest_float("reg_lambda", 1e-3, 10.0, log=True),
    }

    skf = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
    scores = []
    for tr_idx, val_idx in skf.split(X, y):
        model = lgb.LGBMClassifier(**params, verbose=-1, random_state=42)
        model.fit(X.iloc[tr_idx], y.iloc[tr_idx],
                  eval_set=[(X.iloc[val_idx], y.iloc[val_idx])],
                  callbacks=[lgb.early_stopping(30, verbose=False)])
        proba = model.predict_proba(X.iloc[val_idx])[:, 1]
        scores.append(roc_auc_score(y.iloc[val_idx], proba))
    return float(np.mean(scores))


study = optuna.create_study(
    direction="maximize",
    pruner=optuna.pruners.MedianPruner(n_startup_trials=5),
)
study.optimize(objective, n_trials=50, timeout=1800)    # 30 min cap

print(f"best AUC: {study.best_value:.4f}")
print(f"best params: {study.best_params}")
''',
    notes=[
        "30-50 trials is a sensible budget; more often hits diminishing returns",
        "3-fold CV inside the objective is faster than 5-fold; noise is fine for ranking trials",
        "MedianPruner cuts unpromising trials early; n_startup_trials=5 gives it data to compare",
        "log=True on learning_rate, reg_alpha, reg_lambda is essential — multiplicative scale",
    ],
    when_to_use=[
        "After a working baseline; 30+ min spare time",
        "Late-stage optimization for final ranking",
    ],
    inputs=["X, y"],
    outputs=["study.best_params"],
    requires=["optuna", "lightgbm", "sklearn", "numpy"],
)


optuna_xgboost = Entry(
    name="optuna_xgboost",
    title="Optuna search for XGBoost hyperparameters",
    code='''import optuna
import xgboost as xgb
import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score


def objective(trial):
    params = {
        "n_estimators":     trial.suggest_int("n_estimators", 500, 3000),
        "learning_rate":    trial.suggest_float("learning_rate", 0.01, 0.3, log=True),
        "max_depth":        trial.suggest_int("max_depth", 3, 10),
        "min_child_weight": trial.suggest_int("min_child_weight", 1, 10),
        "subsample":        trial.suggest_float("subsample", 0.6, 1.0),
        "colsample_bytree": trial.suggest_float("colsample_bytree", 0.6, 1.0),
        "reg_alpha":        trial.suggest_float("reg_alpha",  1e-3, 10.0, log=True),
        "reg_lambda":       trial.suggest_float("reg_lambda", 1e-3, 10.0, log=True),
        "gamma":            trial.suggest_float("gamma", 0.0, 5.0),
    }

    skf = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
    scores = []
    for tr_idx, val_idx in skf.split(X, y):
        model = xgb.XGBClassifier(
            **params,
            tree_method="hist",
            device="cuda",                              # "cpu" if no GPU
            enable_categorical=True,
            early_stopping_rounds=30,
            eval_metric="logloss",
            objective="binary:logistic",
            verbosity=0,
            random_state=42,
        )
        model.fit(X.iloc[tr_idx], y.iloc[tr_idx],
                  eval_set=[(X.iloc[val_idx], y.iloc[val_idx])],
                  verbose=False)
        proba = model.predict_proba(X.iloc[val_idx])[:, 1]
        scores.append(roc_auc_score(y.iloc[val_idx], proba))
    return float(np.mean(scores))


study = optuna.create_study(
    direction="maximize",
    pruner=optuna.pruners.MedianPruner(n_startup_trials=5),
)
study.optimize(objective, n_trials=50, timeout=1800)
print(f"best AUC: {study.best_value:.4f}")
print(f"best params: {study.best_params}")
''',
    notes=[
        "early_stopping_rounds and eval_metric live in the constructor (XGBoost 3.x)",
        "device='cuda' replaces tree_method='gpu_hist' from older XGBoost versions",
        "gamma controls minimum loss reduction for split — keep low (0-1) for most tasks",
    ],
    when_to_use=[
        "After XGBoost is your best base model and you want to squeeze more",
    ],
    inputs=["X, y"],
    outputs=["study.best_params"],
    requires=["optuna", "xgboost", "sklearn", "numpy"],
)


optuna_catboost = Entry(
    name="optuna_catboost",
    title="Optuna search for CatBoost hyperparameters",
    code='''import optuna
from catboost import CatBoostClassifier
import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score


def objective(trial):
    params = {
        "iterations":          trial.suggest_int("iterations", 500, 3000),
        "learning_rate":       trial.suggest_float("learning_rate", 0.01, 0.3, log=True),
        "depth":               trial.suggest_int("depth", 4, 10),
        "l2_leaf_reg":         trial.suggest_float("l2_leaf_reg", 1.0, 30.0, log=True),
        "random_strength":     trial.suggest_float("random_strength", 0.0, 10.0),
        "bagging_temperature": trial.suggest_float("bagging_temperature", 0.0, 10.0),
    }

    skf = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
    scores = []
    for tr_idx, val_idx in skf.split(X, y):
        model = CatBoostClassifier(
            **params,
            cat_features=cat_cols,
            early_stopping_rounds=30,
            verbose=0,
            random_seed=42,
        )
        model.fit(X.iloc[tr_idx], y.iloc[tr_idx],
                  eval_set=(X.iloc[val_idx], y.iloc[val_idx]))
        proba = model.predict_proba(X.iloc[val_idx])[:, 1]
        scores.append(roc_auc_score(y.iloc[val_idx], proba))
    return float(np.mean(scores))


study = optuna.create_study(
    direction="maximize",
    pruner=optuna.pruners.MedianPruner(n_startup_trials=5),
)
study.optimize(objective, n_trials=30, timeout=1800)    # CatBoost is slower → fewer trials
print(f"best AUC: {study.best_value:.4f}")
print(f"best params: {study.best_params}")
''',
    notes=[
        "CatBoost is slower per trial — drop to 30 trials (or 20 with timeout=1200)",
        "depth in CatBoost is total tree depth (not max_depth); 4-10 is the sane range",
        "l2_leaf_reg is broader than other libs (1-30) — log scale is essential",
    ],
    when_to_use=[
        "After CatBoost is in your top base models",
    ],
    inputs=["X, y, cat_cols"],
    outputs=["study.best_params"],
    requires=["optuna", "catboost", "sklearn", "numpy"],
)


search_spaces = Entry(
    name="search_spaces",
    title="Sensible Optuna search spaces — quick reference",
    code='''# pluggable lambdas: pass them into your own objective wrapper

# ── LightGBM ──
def lightgbm_space(trial):
    return {
        "n_estimators":      trial.suggest_int("n_estimators", 500, 3000),
        "learning_rate":     trial.suggest_float("learning_rate", 0.01, 0.3, log=True),
        "num_leaves":        trial.suggest_int("num_leaves", 15, 255),
        "max_depth":         trial.suggest_int("max_depth", 3, 12),
        "min_child_samples": trial.suggest_int("min_child_samples", 5, 100),
        "subsample":         trial.suggest_float("subsample", 0.6, 1.0),
        "colsample_bytree":  trial.suggest_float("colsample_bytree", 0.6, 1.0),
        "reg_alpha":         trial.suggest_float("reg_alpha",  1e-3, 10.0, log=True),
        "reg_lambda":        trial.suggest_float("reg_lambda", 1e-3, 10.0, log=True),
    }

# ── XGBoost ──
def xgboost_space(trial):
    return {
        "n_estimators":     trial.suggest_int("n_estimators", 500, 3000),
        "learning_rate":    trial.suggest_float("learning_rate", 0.01, 0.3, log=True),
        "max_depth":        trial.suggest_int("max_depth", 3, 10),
        "min_child_weight": trial.suggest_int("min_child_weight", 1, 10),
        "subsample":        trial.suggest_float("subsample", 0.6, 1.0),
        "colsample_bytree": trial.suggest_float("colsample_bytree", 0.6, 1.0),
        "reg_alpha":        trial.suggest_float("reg_alpha",  1e-3, 10.0, log=True),
        "reg_lambda":       trial.suggest_float("reg_lambda", 1e-3, 10.0, log=True),
        "gamma":            trial.suggest_float("gamma", 0.0, 5.0),
    }

# ── CatBoost ──
def catboost_space(trial):
    return {
        "iterations":          trial.suggest_int("iterations", 500, 3000),
        "learning_rate":       trial.suggest_float("learning_rate", 0.01, 0.3, log=True),
        "depth":               trial.suggest_int("depth", 4, 10),
        "l2_leaf_reg":         trial.suggest_float("l2_leaf_reg", 1.0, 30.0, log=True),
        "random_strength":     trial.suggest_float("random_strength", 0.0, 10.0),
        "bagging_temperature": trial.suggest_float("bagging_temperature", 0.0, 10.0),
    }
''',
    notes=[
        "Starting ranges — tighten around the optimum after a first pass",
        "log=True is essential for params spanning orders of magnitude (learning_rate, reg_*)",
        "n_estimators upper bound is high because early stopping cuts in well below it",
        "If short on time, fix n_estimators=2000 and only tune learning_rate + complexity (num_leaves / max_depth)",
    ],
    requires=["optuna"],
)


index = _make_index(__name__)
