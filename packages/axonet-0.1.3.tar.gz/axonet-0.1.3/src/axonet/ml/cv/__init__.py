"""Cross-validation strategies — pick the right one based on data structure.

Wrong CV = optimizing for noise. The right strategy depends on whether your
data has class imbalance, group structure, or temporal ordering.
"""
from ..._entry import Entry, _make_index


stratified = Entry(
    name="stratified",
    title="StratifiedKFold — default for classification (preserves class distribution per fold)",
    code='''from sklearn.model_selection import StratifiedKFold

skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
for fold_idx, (tr_idx, val_idx) in enumerate(skf.split(X, y)):
    X_tr, X_val = X.iloc[tr_idx], X.iloc[val_idx]
    y_tr, y_val = y.iloc[tr_idx], y.iloc[val_idx]
    # ... fit model on X_tr, y_tr; evaluate on X_val, y_val ...
''',
    notes=[
        "Use for any classification task without group/time structure",
        "Each fold has the same class distribution as the full set",
        "n_splits=5 is the default; bump to 10 only when you have time and data",
        "shuffle=True is essential — preserves stratification on shuffled data",
    ],
    when_to_use=[
        "Default for any classification — binary, multiclass, multilabel",
        "When data has no group / time structure",
    ],
    inputs=["X (DataFrame or array)", "y (Series or array)"],
    requires=["sklearn"],
)


group = Entry(
    name="group",
    title="GroupKFold — when rows share an entity (user, patient, account)",
    code='''from sklearn.model_selection import GroupKFold

# `groups` is a 1D array of group ids, same length as X
# example: groups = train["user_id"].values

gkf = GroupKFold(n_splits=5)
for fold_idx, (tr_idx, val_idx) in enumerate(gkf.split(X, y, groups=groups)):
    # all rows from a single group are entirely in one fold (no leakage across)
    X_tr, X_val = X.iloc[tr_idx], X.iloc[val_idx]
    y_tr, y_val = y.iloc[tr_idx], y.iloc[val_idx]
    # ...
''',
    notes=[
        "Use when multiple rows belong to the same entity and entity overlap leaks information",
        "Examples: per-user transactions, per-patient visits, per-image patches",
        "GroupKFold doesn't shuffle (deterministic) — but is order-invariant since it splits by group",
        "For class-balanced + grouped data, use stratified_group instead",
    ],
    when_to_use=[
        "Multiple rows per entity AND entity could appear in both train and val",
        "Detected by axonet.ml.failure_modes.all_checks (group overlap warning)",
    ],
    inputs=["X", "y", "groups (entity ids)"],
    requires=["sklearn"],
)


stratified_group = Entry(
    name="stratified_group",
    title="StratifiedGroupKFold — both class balance AND group safety",
    code='''from sklearn.model_selection import StratifiedGroupKFold

# preserves class proportions while keeping each group entirely in one fold
sgkf = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=42)
for fold_idx, (tr_idx, val_idx) in enumerate(sgkf.split(X, y, groups=groups)):
    X_tr, X_val = X.iloc[tr_idx], X.iloc[val_idx]
    y_tr, y_val = y.iloc[tr_idx], y.iloc[val_idx]
    # ...
''',
    notes=[
        "Best of both worlds when you have imbalanced classes AND grouped data",
        "Tries to preserve class distribution per fold while respecting group boundaries",
        "Available since sklearn 1.0 — make sure your sklearn is recent",
    ],
    when_to_use=[
        "Imbalanced classification + grouped data (e.g., rare-disease patient cohort)",
    ],
    inputs=["X", "y", "groups"],
    requires=["sklearn"],
)


timeseries = Entry(
    name="timeseries",
    title="TimeSeriesSplit — train on past, validate on future (no leakage)",
    code='''from sklearn.model_selection import TimeSeriesSplit

# X must be sorted by time before calling .split()
# example: X = X.sort_values("timestamp").reset_index(drop=True)
#          y = y.loc[X.index].reset_index(drop=True)

tscv = TimeSeriesSplit(n_splits=5, test_size=None, gap=0)
for fold_idx, (tr_idx, val_idx) in enumerate(tscv.split(X)):
    # train indices are always BEFORE val indices in the sorted order
    X_tr, X_val = X.iloc[tr_idx], X.iloc[val_idx]
    y_tr, y_val = y.iloc[tr_idx], y.iloc[val_idx]
    # ...
''',
    notes=[
        "Use whenever timestamps exist and test set is genuinely 'the future'",
        "DOES NOT shuffle — order matters",
        "gap= argument lets you skip rows between train and val (useful when prediction has lead time)",
        "test_size= lets you use a fixed-size validation window per fold (rolling window pattern)",
        "If you also have group structure, sort by time within each group and use a custom split",
    ],
    when_to_use=[
        "Timestamp column present AND test set follows train chronologically",
        "Detected by axonet.ml.failure_modes.time_leakage",
    ],
    inputs=["X (sorted by time)", "y (aligned)"],
    requires=["sklearn"],
)


repeated = Entry(
    name="repeated",
    title="RepeatedStratifiedKFold — averages out fold-split noise on small data",
    code='''from sklearn.model_selection import RepeatedStratifiedKFold

# n_splits=5 × n_repeats=10 = 50 train/val pairs; average scores reduce variance
rskf = RepeatedStratifiedKFold(n_splits=5, n_repeats=10, random_state=42)
for tr_idx, val_idx in rskf.split(X, y):
    X_tr, X_val = X.iloc[tr_idx], X.iloc[val_idx]
    y_tr, y_val = y.iloc[tr_idx], y.iloc[val_idx]
    # ...
''',
    notes=[
        "Use when total dataset is small (<1000 rows) and single-fold scores are noisy",
        "Cost: 10× the training time of a single 5-fold pass",
        "Not for stacking — produces overlapping OOFs that can't be combined cleanly",
    ],
    when_to_use=[
        "Small data where you need a more reliable score estimate",
        "Final model evaluation before submission, not during iteration",
    ],
    inputs=["X", "y"],
    requires=["sklearn"],
)


oof_pattern = Entry(
    name="oof_pattern",
    title="OOF prediction loop — build out-of-fold predictions for stacking",
    code='''import numpy as np
from sklearn.model_selection import StratifiedKFold

# preallocate
oof = np.zeros(len(X))                       # per-row val prediction (filled across folds)
test_preds = np.zeros(len(X_test))           # averaged across folds
n_splits = 5

skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)

for fold_idx, (tr_idx, val_idx) in enumerate(skf.split(X, y)):
    X_tr, X_val = X.iloc[tr_idx], X.iloc[val_idx]
    y_tr, y_val = y.iloc[tr_idx], y.iloc[val_idx]

    # train any model — replace with the LGBM/XGB/CatBoost from axonet.ml.boosting
    model = ...                              # your model construction
    model.fit(X_tr, y_tr, ...)

    oof[val_idx] = model.predict_proba(X_val)[:, 1]      # binary; for multiclass: predict_proba(X_val)
    test_preds += model.predict_proba(X_test)[:, 1] / n_splits

# OOF score is honest — same data the meta-model would see if you stacked
from sklearn.metrics import roc_auc_score
print(f"OOF AUC: {roc_auc_score(y, oof):.4f}")
''',
    notes=[
        "OOF predictions = out-of-fold = each row's prediction comes from a model that DIDN'T see it during training",
        "Used for stacking: feed oof to a meta-model (typically LogReg) — see axonet.ml.ensemble.stacking",
        "test_preds is the average across folds — use for the actual submission",
        "For multiclass: replace [:, 1] with the full predict_proba; oof shape becomes (n, num_classes)",
    ],
    when_to_use=[
        "Any time you want stacking",
        "When you want an honest score that doesn't overlap with training",
    ],
    inputs=["X, y, X_test"],
    outputs=["oof, test_preds"],
    requires=["sklearn", "numpy"],
)


index = _make_index(__name__)
