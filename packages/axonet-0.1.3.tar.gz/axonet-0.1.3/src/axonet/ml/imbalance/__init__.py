"""Imbalance handling — class weights, weighted sampling, threshold tuning, focal loss.

Three independent levers that compose: weighting (loss-side), sampling
(data-side), threshold tuning (post-hoc). Use weighting first; add the others
only if weighting alone isn't enough.
"""
from ..._entry import Entry, _make_index


class_weights = Entry(
    name="class_weights",
    title="Class weights from inverse frequency or effective number of samples",
    code='''import numpy as np

# inverse-frequency weights (simple, often enough)
class_counts = y.value_counts().sort_index().values     # ordered by class index
weights = 1.0 / class_counts
weights = weights / weights.sum() * len(class_counts)   # normalize so mean=1

# OR: effective number of samples (Cui et al. 2019) — smoother for severe imbalance
beta = 0.9999                                           # closer to 1 = more aggressive
effective_num = (1 - np.power(beta, class_counts)) / (1 - beta)
weights_eff = 1.0 / effective_num
weights_eff = weights_eff / weights_eff.sum() * len(class_counts)

# binary-only shortcut: scale_pos_weight = neg / pos
n_pos = (y == 1).sum()
n_neg = (y == 0).sum()
scale_pos_weight = n_neg / n_pos

# how to use these
# LightGBM:    class_weight="balanced"  (auto)  OR  class_weight=dict(enumerate(weights))
# XGBoost:     scale_pos_weight=scale_pos_weight  (binary)  OR  sample_weight=array  (multi)
# CatBoost:    auto_class_weights="Balanced"  OR  class_weights=weights.tolist()
# sklearn:     class_weight="balanced"  OR  class_weight=dict(enumerate(weights))
''',
    notes=[
        "class_weight='balanced' (sklearn / LGBM) is equivalent to inverse-frequency",
        "Effective Number weighting smooths extreme weights; preferred for imbalance > 100:1",
        "scale_pos_weight is XGB binary-only — for multiclass use sample_weight in fit()",
        "Class weights affect LOSS only, not sampling. For sampling, see weighted_sampler",
    ],
    inputs=["y (Series of class labels)"],
    outputs=["weights, scale_pos_weight"],
    requires=["pandas", "numpy"],
)


weighted_sampler = Entry(
    name="weighted_sampler",
    title="Weighted oversampling — sklearn sample_weight or torch WeightedRandomSampler",
    code='''import numpy as np

# ── option A: sklearn sample_weight (works with any sklearn-API estimator) ──
class_counts = np.bincount(y)
class_weights = 1.0 / class_counts
sample_weight = class_weights[y]                       # broadcast per-row

# pass to .fit():
# model.fit(X, y, sample_weight=sample_weight)


# ── option B: PyTorch WeightedRandomSampler (DL training loops) ──
import torch
from torch.utils.data import WeightedRandomSampler

samples_w = torch.tensor(sample_weight, dtype=torch.float)
sampler = WeightedRandomSampler(
    weights=samples_w,
    num_samples=len(samples_w),
    replacement=True,
)
# loader = DataLoader(dataset, batch_size=32, sampler=sampler)
''',
    notes=[
        "sample_weight is the natural way for sklearn / boosting libraries",
        "WeightedRandomSampler is for PyTorch loops only",
        "Oversampling can hurt when minority class has few unique patterns — adds noise via repetition",
        "Try class_weights in the loss FIRST; only add oversampling if weighting alone is insufficient",
    ],
    inputs=["y (Series or array of class labels)"],
    outputs=["sample_weight, sampler"],
    requires=["numpy", "torch (optional)"],
)


threshold_tuning = Entry(
    name="threshold_tuning",
    title="F1-optimal threshold via OOF probability sweep",
    code='''import numpy as np
from sklearn.metrics import f1_score

# requires `oof` (probabilities for class 1) and `y` from the OOF training loop
# see axonet.ml.cv.oof_pattern

thresholds = np.arange(0.05, 0.95, 0.005)
f1s = [f1_score(y, oof > t) for t in thresholds]

best_idx = int(np.argmax(f1s))
best_threshold = thresholds[best_idx]
print(f"best threshold: {best_threshold:.3f}  →  F1 = {f1s[best_idx]:.4f}")

# apply to test predictions
predictions = (test_preds > best_threshold).astype(int)
''',
    notes=[
        "Default 0.5 threshold is rarely optimal for F1 on imbalanced binary",
        "Tune on OOF predictions — never on training-set probabilities (over-confident)",
        "Step 0.005 is overkill on small validation; 0.01 is fine",
        "For multi-class macro-F1: argmax on probas, threshold tuning doesn't apply",
        "For multi-label: tune per-label threshold (different optimum per class)",
    ],
    when_to_use=[
        "Binary classification with F1 metric",
        "When base rate is far from 0.5",
    ],
    inputs=["oof (probabilities)", "y (true labels)", "test_preds"],
    outputs=["best_threshold, predictions"],
    requires=["numpy", "sklearn"],
)


focal_loss = Entry(
    name="focal_loss",
    title="Focal loss — for severe class imbalance (PyTorch multi-class + binary)",
    code='''import torch
import torch.nn as nn
import torch.nn.functional as F


# ── multi-class ──
class FocalLoss(nn.Module):
    """FL(p_t) = -alpha_t * (1 - p_t)^gamma * log(p_t)"""
    def __init__(self, gamma=2.0, alpha=None, label_smoothing=0.0):
        super().__init__()
        self.gamma = gamma
        self.alpha = alpha                              # tensor [num_classes] or None
        self.label_smoothing = label_smoothing

    def forward(self, logits, targets):
        ce = F.cross_entropy(logits, targets, reduction="none",
                             label_smoothing=self.label_smoothing)
        pt = torch.exp(-ce)
        focal_weight = (1 - pt) ** self.gamma
        if self.alpha is not None:
            alpha_t = self.alpha[targets] if torch.is_tensor(self.alpha) else self.alpha
            focal_weight = focal_weight * alpha_t
        return (focal_weight * ce).mean()


# ── binary (sigmoid-based) ──
def sigmoid_focal_loss(logits, targets, alpha=0.25, gamma=2.0):
    """Binary focal loss; logits and targets are [B] (or [B, 1])."""
    p = torch.sigmoid(logits)
    ce = F.binary_cross_entropy_with_logits(logits, targets.float(), reduction="none")
    p_t = p * targets + (1 - p) * (1 - targets)
    alpha_t = alpha * targets + (1 - alpha) * (1 - targets)
    return (alpha_t * (1 - p_t) ** gamma * ce).mean()


# usage
# criterion = FocalLoss(gamma=2.0, alpha=class_weights_tensor)
# loss = criterion(model(x), y)
''',
    notes=[
        "α (alpha) = class-balance parameter; γ (gamma) = focusing parameter",
        "Higher gamma → more aggressive down-weighting of easy examples; typical γ=2",
        "Use focal loss when class_weight + scale_pos_weight aren't enough (imbalance > 100:1)",
        "Pairs well with label_smoothing for noisy labels",
        "For boosting: use class_weights / scale_pos_weight; focal in boosting is overkill except for extreme imbalance",
    ],
    when_to_use=[
        "Severe imbalance (> 100:1)",
        "When standard class_weight provides insufficient gain",
    ],
    inputs=["logits, targets (PyTorch tensors)"],
    requires=["torch"],
)


scale_pos_weight = Entry(
    name="scale_pos_weight",
    title="scale_pos_weight — XGBoost's simplest binary imbalance knob",
    code='''import xgboost as xgb

n_pos = (y == 1).sum()
n_neg = (y == 0).sum()
scale_pos_weight = n_neg / n_pos
print(f"scale_pos_weight = {scale_pos_weight:.2f}")

model = xgb.XGBClassifier(
    n_estimators=2000,
    learning_rate=0.05,
    max_depth=6,
    scale_pos_weight=scale_pos_weight,                  # equivalent to class_weight={0:1, 1:N}
    tree_method="hist",
    device="cuda",
    enable_categorical=True,
    early_stopping_rounds=50,
    eval_metric="logloss",
    objective="binary:logistic",
    random_state=42,
)
model.fit(X_train, y_train, eval_set=[(X_val, y_val)], verbose=100)
''',
    notes=[
        "BINARY ONLY — for multiclass, XGBoost wants sample_weight via fit()'s sample_weight= kwarg",
        "Start with scale_pos_weight = n_neg / n_pos and tune ±50% if needed",
        "LightGBM equivalent: class_weight='balanced' or scale_pos_weight= (also accepted)",
        "CatBoost equivalent: class_weights=[1, scale] or auto_class_weights='Balanced'",
    ],
    inputs=["y (binary 0/1)"],
    outputs=["scale_pos_weight"],
    requires=["xgboost"],
)


smote = Entry(
    name="smote",
    title="SMOTE — synthetic minority oversampling (requires imbalanced-learn)",
    code='''# ─── pip install imbalanced-learn ───
from imblearn.over_sampling import SMOTE, SMOTENC
from imblearn.pipeline import Pipeline as ImbPipeline


# ── all-numeric features ──
smote = SMOTE(random_state=42, k_neighbors=5)
# X_resampled, y_resampled = smote.fit_resample(X_train, y_train)

# ── mixed numeric + categorical ──
# cat_features takes column INDICES (not names) when X is a DataFrame
cat_indices = [X_train.columns.get_loc(c) for c in cat_cols]
smote_nc = SMOTENC(categorical_features=cat_indices, random_state=42, k_neighbors=5)
# X_resampled, y_resampled = smote_nc.fit_resample(X_train, y_train)

# ── inside an sklearn pipeline (avoids leakage in CV) ──
imb_pipe = ImbPipeline([
    ("smote", SMOTE(random_state=42, k_neighbors=5)),
    ("model", model),                                   # any estimator
])
# imb_pipe.fit(X_train, y_train)                        # SMOTE fires only on fit, skipped on predict
''',
    notes=[
        "Apply SMOTE ONLY on training data — never on val/test (it's a fit-time step)",
        "Use ImbPipeline (not sklearn Pipeline) to ensure SMOTE is skipped during predict/transform",
        "k_neighbors must be < class size; lower for very small minority class",
        "SMOTE in high dimensions creates unrealistic samples — combine with undersampling (SMOTETomek, SMOTEENN) for severe imbalance",
        "For tabular boosting, class_weights and focal loss are usually preferable to SMOTE",
    ],
    inputs=["X_train, y_train (and optional cat_cols)"],
    outputs=["X_resampled, y_resampled (or imb_pipe)"],
    requires=["imbalanced-learn"],
)


index = _make_index(__name__)
