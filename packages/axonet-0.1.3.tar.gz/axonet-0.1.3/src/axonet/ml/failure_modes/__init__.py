"""The 5 quiet failure modes that separate candidates on tabular tasks.

Each entry is a check you run on your data BEFORE training, plus the fix.
Catching these early saves 5-15% on hidden test compared to validation.
"""
from ..._entry import Entry, _make_index


target_encoding_oof = Entry(
    name="target_encoding_oof",
    title="Target encoding done right (out-of-fold) — leakage-safe pattern",
    code='''import numpy as np
from sklearn.model_selection import KFold


def target_encode_oof(train_df, test_df, col, target_col, n_splits=5, smooth=10, seed=42):
    """OOF target encoding. Each train row is encoded from OTHER folds only;
    test set is encoded from full train (no leakage since test is held out).
    """
    global_mean = train_df[target_col].mean()
    encoded_train = np.zeros(len(train_df))

    kf = KFold(n_splits=n_splits, shuffle=True, random_state=seed)
    for tr_idx, val_idx in kf.split(train_df):
        fold_train = train_df.iloc[tr_idx]
        agg = fold_train.groupby(col)[target_col].agg(["mean", "count"])
        # smoothing pulls rare-category encodings toward the global mean
        smoothed = (agg["mean"] * agg["count"] + global_mean * smooth) / (agg["count"] + smooth)
        encoded_train[val_idx] = train_df.iloc[val_idx][col].map(smoothed).fillna(global_mean)

    # test uses the full-train aggregation
    agg = train_df.groupby(col)[target_col].agg(["mean", "count"])
    smoothed = (agg["mean"] * agg["count"] + global_mean * smooth) / (agg["count"] + smooth)
    encoded_test = test_df[col].map(smoothed).fillna(global_mean).values

    return encoded_train, encoded_test


# usage
# train["city_te"], test["city_te"] = target_encode_oof(train, test, "city", target_col)
''',
    notes=[
        "FAILURE: fitting a target encoder on full train then transforming train → leakage. Validation looks great, hidden test bombs (5%+ gap)",
        "Always use OOF encoding, OR delegate to a model that handles it natively (CatBoost has internal target encoding)",
        "smooth=10 is conservative — for high-cardinality columns, increase smooth to keep rare categories from over-fitting",
    ],
    inputs=["train (DataFrame)", "test (DataFrame)", "target_col (str)"],
    requires=["pandas", "sklearn", "numpy"],
)


time_leakage = Entry(
    name="time_leakage",
    title="Time leakage check — flag time columns and recommend CV strategy",
    code='''datetime_cols = train.select_dtypes(include="datetime").columns.tolist()
date_like_cols = [c for c in train.select_dtypes(include="object").columns
                  if any(kw in c.lower() for kw in ["date", "time", "timestamp", "year"])]

if datetime_cols or date_like_cols:
    print("⚠ time-structured data detected:")
    for c in datetime_cols:
        print(f"  {c}: datetime dtype")
    for c in date_like_cols:
        print(f"  {c}: object dtype with time-suggestive name (parse it)")
    print()
    print("  → use TimeSeriesSplit instead of StratifiedKFold")
    print("  → make sure train < test in time, NOT random sampling")
    print("  → see axonet.ml.cv.timeseries for the correct CV pattern")
else:
    print("no time-structured columns detected — StratifiedKFold is fine")
''',
    notes=[
        "FAILURE: random KFold on time-ordered data leaks future into past — the inflated CV crashes on hidden test",
        "Even without lag features, plain split still validates incorrectly when time is the underlying generator",
        "If you see ⚠: switch to TimeSeriesSplit AND respect chronological order in any train/test internal split",
    ],
    inputs=["train"],
    requires=["pandas"],
)


ordinal_check = Entry(
    name="ordinal_check",
    title="Ordinal target check — is your multiclass actually ordinal?",
    code='''vals = train[target_col].unique()
vals_str = sorted(str(v) for v in vals)

# heuristic: target values look like ordered numerics or ranges
ordinal_like = (
    all(v.replace("-", "").replace(".", "").isdigit() for v in vals_str if v != "nan")
    and len(vals_str) > 2
    and len(vals_str) <= 20
)

if ordinal_like:
    print(f"⚠ target values look ordinal: {vals_str}")
    print()
    print("  → consider treating as REGRESSION and rounding at predict time:")
    print("       predictions = np.round(model.predict(X_test)).clip(0, K-1).astype(int)")
    print("  → use Quadratic Weighted Kappa as the metric:")
    print("       sklearn.metrics.cohen_kappa_score(y, preds, weights='quadratic')")
    print("  → see axonet.ml.ordinal for the regression-then-round pipeline")
else:
    print(f"target values: {vals_str} — looks plain multiclass")
''',
    notes=[
        "FAILURE: ordinal target trained as plain multiclass loses the ordering signal — typically -5% to -15% on QWK",
        "QWK penalizes far-off mistakes more than near-off, so model needs to know the ordering",
        "2025 SG camp HDB storey-range was exactly this — '01-03', '04-06', '07-09' look like categories but they're ordered",
    ],
    inputs=["train", "target_col"],
    requires=["pandas"],
)


categorical_marking = Entry(
    name="categorical_marking",
    title="Categorical marking reminder — pass cat columns explicitly to boosting libs",
    code='''cat_cols = [c for c in train.select_dtypes(include=["object", "category"]).columns
            if c != target_col]

if not cat_cols:
    print("no categorical columns detected — nothing to mark")
else:
    print(f"{len(cat_cols)} categorical columns: {cat_cols}")
    print()
    print("LightGBM:  pass categorical_feature=cat_cols to .fit(),")
    print("           OR cast to category first: train[col] = train[col].astype('category')")
    print()
    print("CatBoost:  pass cat_features=cat_cols (or column indices) to constructor")
    print()
    print("XGBoost:   set enable_categorical=True in constructor,")
    print("           AND cast columns to pd.Categorical first")
''',
    notes=[
        "FAILURE: passing object-dtype to boosting libs without marking them → treated as ordinal numerics",
        "Symptom: feature_importances dominated by id-like cols; CV score lower than it should be",
        "Each library's exact API in axonet.ml.boosting.{lightgbm, xgboost, catboost}",
    ],
    inputs=["train", "target_col"],
    requires=["pandas"],
)


missingness_target_corr = Entry(
    name="missingness_target_corr",
    title="Missingness-target correlation — does is-missing leak the target?",
    code='''import pandas as pd

miss_cols = [c for c in train.columns
             if train[c].isna().any() and c != target_col]

if not miss_cols:
    print("no missing values in train — nothing to check")
elif not pd.api.types.is_numeric_dtype(train[target_col]):
    print("non-numeric target — skipping (extend the heuristic if needed)")
else:
    base_rate = train[target_col].mean()
    print(f"target overall mean: {base_rate:.4f}\\n")
    flagged = []
    for col in miss_cols:
        is_missing = train[col].isna()
        if is_missing.sum() < 30:
            continue
        rate_missing = train.loc[is_missing, target_col].mean()
        delta = rate_missing - base_rate
        if abs(delta) > 0.05:
            flagged.append((col, rate_missing, delta))

    if flagged:
        print("⚠ columns where missingness correlates with target:")
        for col, rate, delta in flagged:
            print(f"  {col}: target mean when MISSING = {rate:.4f}  (Δ {delta:+.4f})")
        print()
        print("  → ADD missing-indicators BEFORE imputing:")
        print("       for col in [...]:")
        print("           train[f'{col}_isna'] = train[col].isna().astype(int)")
        print("           test[f'{col}_isna']  = test[col].isna().astype(int)")
    else:
        print("no missingness-target correlation found")
''',
    notes=[
        "FAILURE: missingness encodes the target, but median imputation destroys the signal",
        "Fix: add binary indicator BEFORE imputing — see axonet.ml.preprocess.missing_indicators",
        "|Δ| > 0.05 threshold is heuristic — adjust based on overall target dispersion",
    ],
    inputs=["train", "target_col"],
    requires=["pandas"],
)


all_checks = Entry(
    name="all_checks",
    title="Run every failure-mode detector in one cell",
    code='''import pandas as pd

# [1] time leakage
print("[1] time leakage")
datetime_cols = train.select_dtypes(include="datetime").columns.tolist()
date_like = [c for c in train.select_dtypes(include="object").columns
             if any(kw in c.lower() for kw in ["date", "time", "timestamp", "year"])]
if datetime_cols or date_like:
    print(f"  ⚠ time columns: {datetime_cols + date_like} → use TimeSeriesSplit")
else:
    print("  ok")

# [2] ordinal target
print("\\n[2] ordinal target")
vals_str = sorted(str(v) for v in train[target_col].unique())
ordinal_like = (
    all(v.replace("-", "").replace(".", "").isdigit() for v in vals_str if v != "nan")
    and 2 < len(vals_str) <= 20
)
if ordinal_like:
    print(f"  ⚠ target values look ordinal: {vals_str} → consider regression+round")
else:
    print("  ok")

# [3] categorical columns to mark
print("\\n[3] categorical marking")
cat_cols = [c for c in train.select_dtypes(include=["object", "category"]).columns if c != target_col]
if cat_cols:
    print(f"  {len(cat_cols)} cols → pass categorical_feature=/cat_features= to boosting fit")
else:
    print("  ok (no categoricals)")

# [4] missingness leaking target
print("\\n[4] missingness ↔ target")
flagged = []
if pd.api.types.is_numeric_dtype(train[target_col]):
    base_rate = train[target_col].mean()
    for col in train.columns:
        if col == target_col or not train[col].isna().any():
            continue
        is_missing = train[col].isna()
        if is_missing.sum() < 30:
            continue
        delta = train.loc[is_missing, target_col].mean() - base_rate
        if abs(delta) > 0.05:
            flagged.append(f"{col} (Δ={delta:+.3f})")
if flagged:
    print(f"  ⚠ add isna() indicators for: {flagged}")
else:
    print("  ok")

# [5] group / entity overlap (heuristic — adjust threshold per task)
print("\\n[5] group / entity overlap")
flagged_groups = []
for col in train.columns:
    if col == target_col or col not in test.columns:
        continue
    s = train[col]
    if pd.api.types.is_numeric_dtype(s) or pd.api.types.is_object_dtype(s):
        n_unique = s.nunique()
        if 5 < n_unique < len(train) * 0.5:
            overlap = len(set(s.dropna()) & set(test[col].dropna()))
            if overlap > 0:
                flagged_groups.append(f"{col} ({overlap} train/test overlap)")
if flagged_groups:
    print(f"  ⚠ entity-like columns with overlap: {flagged_groups}")
    print("     → use GroupKFold (see axonet.ml.cv.group)")
else:
    print("  ok")
''',
    notes=[
        "Run after EDA, before defining the pipeline",
        "Each ⚠ has a specific fix — see the individual sub-entries for details",
        "Group-overlap check is heuristic — false positives possible if entity columns happen to overlap by coincidence",
    ],
    when_to_use=[
        "Right after EDA, before defining preprocess + train",
    ],
    inputs=["train", "test", "target_col"],
    requires=["pandas"],
)


index = _make_index(__name__)
