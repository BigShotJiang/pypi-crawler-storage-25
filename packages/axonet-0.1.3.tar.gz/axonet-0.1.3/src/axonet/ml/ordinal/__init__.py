"""Tabular ordinal classification — when target classes have order.

The trick: train as REGRESSION on class indices, round at predict time.
Wins when metric is Quadratic Weighted Kappa (QWK) — penalizes far-off mistakes.
2025 SG camp HDB storey-range ('01-03', '04-06', ...) was exactly this shape.
"""
from ..._entry import Entry, _make_index


load = Entry(
    name="load",
    title="Section 1 — load + ordinal encoding (string ranges → integer indices)",
    code='''# ─── CONFIG ───
train_path  = "train.csv"
test_path   = "test.csv"
target_col  = "target"
id_col      = "id"
metric      = "quadratic_kappa"
# ──────────────

import pandas as pd
import numpy as np

train = pd.read_csv(train_path)
test  = pd.read_csv(test_path)
test_ids = test[id_col].copy() if id_col in test.columns else pd.Series(range(len(test)), name=id_col)

# encode ordered classes — manual ordering is critical (don't rely on alphabetic)
# example: ranges like '01-03', '04-06', '07-09' should be encoded as 0, 1, 2
ordered_classes = sorted(train[target_col].unique())   # adjust if natural order differs from alphabetic
print(f"ordered classes: {ordered_classes}")

label_map     = {c: i for i, c in enumerate(ordered_classes)}
inv_label_map = {i: c for c, i in label_map.items()}

y = train[target_col].map(label_map).astype(float)     # FLOAT — we'll do regression
num_classes = len(ordered_classes)
print(f"num_classes: {num_classes}")

X = train.drop(columns=[c for c in [target_col, id_col] if c in train.columns])
X_test = test.drop(columns=[c for c in [id_col] if c in test.columns])
''',
    notes=[
        "ORDER MATTERS — verify ordered_classes is the natural ordering, not alphabetic. Override the sorted() if needed",
        "Float target enables regression-then-round trick",
        "QWK metric penalizes |pred - true| more than misclassification",
        "Run axonet.ml.failure_modes.ordinal_check to confirm ordinal structure (skip pipeline if false alarm)",
    ],
    inputs=["train.csv, test.csv"],
    outputs=["X, y (float indices), X_test, num_classes, inv_label_map, test_ids"],
    requires=["pandas", "numpy"],
)


preprocess = Entry(
    name="preprocess",
    title="Section 2 — ColumnTransformer (same as binary/multiclass)",
    code='''# Same recipe — see axonet.ml.binary.preprocess for variants
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OrdinalEncoder

num_cols = X.select_dtypes(include="number").columns.tolist()
cat_cols = X.select_dtypes(include=["object", "category"]).columns.tolist()

preprocessor = ColumnTransformer([
    ("num", Pipeline([("imputer", SimpleImputer(strategy="median")), ("scaler", StandardScaler())]), num_cols),
    ("cat", Pipeline([("imputer", SimpleImputer(strategy="constant", fill_value="missing")),
                       ("encoder", OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1))]), cat_cols),
])

X_pp      = preprocessor.fit_transform(X)
X_test_pp = preprocessor.transform(X_test)
''',
    inputs=["X, X_test"],
    outputs=["X_pp, X_test_pp"],
    requires=["sklearn"],
)


cv_train_regression_round = Entry(
    name="cv_train_regression_round",
    title="Section 3 — regression + round-to-class trick (the key move)",
    code='''import lightgbm as lgb
import numpy as np
from sklearn.model_selection import KFold
from sklearn.metrics import cohen_kappa_score, accuracy_score

n_splits = 5
oof        = np.zeros(len(X_pp))
test_preds = np.zeros(len(X_test_pp))

kf = KFold(n_splits=n_splits, shuffle=True, random_state=42)

for fold_idx, (tr_idx, val_idx) in enumerate(kf.split(X_pp, y)):
    model = lgb.LGBMRegressor(
        n_estimators=2000,
        learning_rate=0.05,
        num_leaves=31,
        objective="regression_l1",                       # MAE objective (robust for ordinal)
        metric="mae",
        verbose=-1,
        random_state=42,
    )
    model.fit(
        X_pp[tr_idx], y.iloc[tr_idx],
        eval_set=[(X_pp[val_idx], y.iloc[val_idx])],
        callbacks=[lgb.early_stopping(50, verbose=False)],
    )
    oof[val_idx]  = model.predict(X_pp[val_idx])
    test_preds   += model.predict(X_test_pp) / n_splits

# round predictions to nearest class index, clip to valid range
oof_classes        = np.round(oof).clip(0, num_classes - 1).astype(int)
predictions_idx    = np.round(test_preds).clip(0, num_classes - 1).astype(int)

# QWK is the natural metric here
qwk = cohen_kappa_score(y.astype(int), oof_classes, weights="quadratic")
acc = accuracy_score(y.astype(int), oof_classes)
print(f"OOF QWK: {qwk:.4f},  accuracy: {acc:.4f}")

# decode back to original labels for submission
predictions = pd.Series(predictions_idx).map(inv_label_map).values
''',
    notes=[
        "objective='regression_l1' (MAE) is more robust for ordinal than L2",
        "Round-then-clip is essential — predictions can drift outside [0, K-1]",
        "QWK metric: cohen_kappa_score(y, preds, weights='quadratic')",
        "Variant: use cumulative-link models (K-1 binary classifiers for P(y > k)) — more principled but rarely worth the complexity at selection level",
        "Decode predictions back to original labels via inv_label_map before submission",
    ],
    inputs=["X_pp, y, X_test_pp, num_classes, inv_label_map"],
    outputs=["oof, test_preds, predictions, oof_classes"],
    requires=["lightgbm", "sklearn", "numpy"],
)


submit = Entry(
    name="submit",
    title="Section 4 — write submission CSV (ordinal)",
    code='''from axonet.utils import submit

sub = submit(
    predictions,                                        # original labels (string or int)
    test_ids,
    target_col=target_col,
    id_col=id_col,
    filename="submission.csv",
)
sub.head()
''',
    inputs=["predictions, test_ids, target_col, id_col"],
    outputs=["submission.csv on disk"],
    requires=["axonet.utils"],
)


index = _make_index(__name__)
