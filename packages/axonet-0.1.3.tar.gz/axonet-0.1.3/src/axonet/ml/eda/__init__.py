"""Exploratory data analysis — broken into copy-pastable cells.

The `full_quick` aggregator gives a single-cell 5-minute ritual; the named
sub-entries (load_inspect, target_dist, missing_data, ...) let you copy
individual checks one cell at a time.
"""
from ..._entry import Entry, _make_index


load_inspect = Entry(
    name="load_inspect",
    title="Initial dataset inspection (shape, dtypes, head)",
    code='''# ─── CONFIG ───
train_path = "train.csv"
test_path  = "test.csv"
# ──────────────

import pandas as pd

train = pd.read_csv(train_path)
test  = pd.read_csv(test_path)
print(f"train: {train.shape},  test: {test.shape}")

# columns in train but not test → almost always the target
print("only in train:", sorted(set(train.columns) - set(test.columns)))

print("\\ndtypes:")
print(train.dtypes)

train.head()
''',
    notes=[
        "Run as the first cell after install/imports",
        "object dtype on a 'numeric' column means it has strings — investigate",
        "set(train.columns) - set(test.columns) usually reveals the target column name",
    ],
    when_to_use=[
        "First cell of any tabular task",
    ],
    outputs=["train", "test"],
    requires=["pandas"],
)


target_dist = Entry(
    name="target_dist",
    title="Target distribution and imbalance ratio",
    code='''# ─── CONFIG ───
target_col = "target"
# ──────────────

vc = train[target_col].value_counts()
print(vc)
print(f"\\nproportion:\\n{(vc / vc.sum()).round(4)}")

if 1 < len(vc) <= 50:
    print(f"\\nimbalance ratio (max/min): {vc.max() / max(vc.min(), 1):.2f}")

# quick visual
ax = vc.plot(kind="bar", figsize=(6, 3), title=f"{target_col} distribution")
ax.figure.tight_layout()
''',
    notes=[
        "ratio < 2: balanced — accuracy is fine",
        "ratio 2–10: mild — switch to F1/macro-F1, add class_weight='balanced'",
        "ratio 10–100: significant — class weights mandatory; consider focal loss",
        "ratio > 100: severe — focal loss + threshold tuning + maybe SMOTE",
    ],
    inputs=["train", "target_col"],
    requires=["pandas", "matplotlib"],
)


missing_data = Entry(
    name="missing_data",
    title="Missing data — per-column summary and heatmap",
    code='''import matplotlib.pyplot as plt
import seaborn as sns

# per-column count + percentage
miss = pd.DataFrame({
    "col":         train.columns,
    "n_missing":   train.isna().sum().values,
    "pct_missing": (train.isna().mean() * 100).values,
}).sort_values("pct_missing", ascending=False)
print(miss[miss["pct_missing"] > 0].to_string(index=False))

# heatmap — vertical stripes mean a column is mostly missing
plt.figure(figsize=(12, 6))
sns.heatmap(train.isna(), cbar=False, yticklabels=False, cmap="viridis")
plt.title("missing values (yellow)")
plt.show()
''',
    notes=[
        "If two cols are missing on the same rows, missingness is correlated — usually a survey skip pattern",
        "If missingness in col X correlates with target, ADD a missing-indicator feature before imputing",
        "Median imputation destroys the missingness signal — pair it with the indicator",
    ],
    inputs=["train"],
    requires=["pandas", "matplotlib", "seaborn"],
)


cardinality = Entry(
    name="cardinality",
    title="Categorical cardinality scan",
    code='''cat_cols = train.select_dtypes(include=["object", "category", "bool"]).columns.tolist()

print(f"{len(cat_cols)} categorical columns:")
for col in cat_cols:
    n = train[col].nunique(dropna=True)
    print(f"  {col}: {n} unique")
    if n <= 5:
        print(f"    values: {train[col].value_counts().head().to_dict()}")
''',
    notes=[
        "≤10 unique: one-hot or label encoding fine",
        "10–50: target encoding (with OOF) or freq encoding for trees",
        "50+: high-cardinality — freq encoding or native handling (CatBoost, LightGBM categorical_feature=)",
        "near-unique-per-row (~95%+): id-like, drop or convert to frequency feature",
    ],
    inputs=["train"],
    outputs=["cat_cols"],
    requires=["pandas"],
)


correlation = Entry(
    name="correlation",
    title="Correlation matrix and feature-target correlation",
    code='''import seaborn as sns
import matplotlib.pyplot as plt

# numeric correlations (Pearson)
num_cols = train.select_dtypes(include="number").columns.tolist()
corr = train[num_cols].corr()

plt.figure(figsize=(10, 8))
sns.heatmap(corr, annot=False, cmap="coolwarm", center=0)
plt.title("numeric feature correlations")
plt.show()

# top correlations with target
if target_col in num_cols:
    target_corr = corr[target_col].abs().sort_values(ascending=False)
    print("top correlations with target:")
    print(target_corr.head(15).round(3))
''',
    notes=[
        "|corr| > 0.95 between two non-target features: near-duplicates, drop one",
        "|corr| > 0.95 between a feature and target: SUSPICIOUS — likely leakage",
        "Pearson is linear; for non-linear use Spearman: train.corr(method='spearman')",
        "For categorical-vs-target, use mutual_info_classif from sklearn instead",
    ],
    inputs=["train", "target_col"],
    outputs=["num_cols"],
    requires=["pandas", "seaborn", "matplotlib"],
)


leakage_check = Entry(
    name="leakage_check",
    title="Leakage scan — suspicious correlations, ID overlap, post-target column names",
    code='''# 1. features with too-high correlation to target
num_cols = train.select_dtypes(include="number").columns.tolist()
if target_col in num_cols:
    target_corr = train[num_cols].corr()[target_col].abs().sort_values(ascending=False)
    suspicious = target_corr[(target_corr > 0.95) & (target_corr.index != target_col)]
    if len(suspicious) > 0:
        print("⚠ suspicious features (corr > 0.95 with target):")
        print(suspicious.round(3))

# 2. ID-based leakage if a group/entity column exists
# adjust: change 'user_id' to your task's actual entity column (or skip this block)
group_col = "user_id"
if group_col in train.columns and group_col in test.columns:
    overlap = set(train[group_col]) & set(test[group_col])
    if overlap:
        print(f"⚠ {len(overlap)} {group_col} values overlap train/test → use GroupKFold")

# 3. column names suggesting post-target information
post_target_keywords = ["final", "outcome", "result", "label", "answer", "actual", "post"]
for col in train.columns:
    if any(kw in col.lower() for kw in post_target_keywords) and col != target_col:
        print(f"⚠ column '{col}' name suggests post-target info — investigate")
''',
    notes=[
        "Catch leakage BEFORE training — wasted compute otherwise",
        "Replace 'user_id' with your task's actual entity column (or remove that block if not applicable)",
        "If overlap is found: switch CV to GroupKFold (see axonet.ml.cv.group)",
    ],
    inputs=["train", "test", "target_col"],
    requires=["pandas"],
)


full_quick = Entry(
    name="full_quick",
    title="5-minute EDA ritual — every check in one cell",
    code='''# ─── CONFIG ───
train_path = "train.csv"
test_path  = "test.csv"
target_col = "target"
# ──────────────

import pandas as pd
import matplotlib.pyplot as plt

# 1. shape + schema
train = pd.read_csv(train_path)
test  = pd.read_csv(test_path)
print(f"train: {train.shape},  test: {test.shape}")
print("only in train:", sorted(set(train.columns) - set(test.columns)))

# 2. target distribution + imbalance
vc = train[target_col].value_counts()
print(f"\\ntarget distribution:\\n{vc}")
if 1 < len(vc) <= 50:
    print(f"imbalance ratio: {vc.max() / max(vc.min(), 1):.2f}")

# 3. missing data summary
miss = train.isna().sum()
miss = miss[miss > 0].sort_values(ascending=False)
if len(miss) > 0:
    print(f"\\nmissing values (top 10):")
    print((miss.head(10) / len(train) * 100).round(2).astype(str) + "%")

# 4. categorical cardinality
cat_cols = train.select_dtypes(include=["object", "category"]).columns.tolist()
print(f"\\ncategorical columns ({len(cat_cols)}):")
for c in cat_cols:
    print(f"  {c}: {train[c].nunique()} unique")

# 5. suspicious correlations with target (potential leakage)
num_cols = train.select_dtypes(include="number").columns.tolist()
if target_col in num_cols:
    tc = train[num_cols].corr()[target_col].abs().sort_values(ascending=False)
    susp = tc[(tc > 0.95) & (tc.index != target_col)]
    if len(susp) > 0:
        print(f"\\n⚠ suspicious correlations with target (>0.95):\\n{susp.round(3)}")

# 6. duplicate rows
dup = train.duplicated().sum()
if dup > 0:
    print(f"\\n⚠ {dup} duplicate rows in train")
''',
    notes=[
        "Drop into the first cell after !pip install — replaces 5+ separate EDA cells",
        "After running, the next steps are: failure-mode scan (axonet.ml.failure_modes) and preprocess",
        "For deeper detail on any check, see the individual sub-entries (load_inspect, target_dist, ...)",
    ],
    when_to_use=[
        "Tabular task, first cell after install",
        "When you want one-shot diagnostic instead of section-by-section",
    ],
    outputs=["train", "test", "target_col"],
    requires=["pandas", "matplotlib"],
)


index = _make_index(__name__)
