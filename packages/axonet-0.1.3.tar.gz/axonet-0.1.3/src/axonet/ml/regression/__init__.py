"""Tabular regression — sectioned end-to-end pipeline.

Differences from binary/multiclass:
  - target is continuous; metric is RMSE / MAE / log-RMSE / MAPE
  - LightGBM objective='regression' / 'regression_l1' / 'huber'
  - target log-transform (log1p / expm1) for skewed targets
  - clip predictions if target is bounded (non-negative, percentage, etc.)
"""
from ..._entry import Entry, _make_index


load = Entry(
    name="load",
    title="Section 1 — load CSVs (regression) + skewness check",
    code='''# ─── CONFIG ───
train_path  = "train.csv"
test_path   = "test.csv"
target_col  = "target"
id_col      = "id"
metric      = "rmse"                                    # rmse / mae / log_rmse / mape
log_target  = True                                      # set False if target is normally distributed
# ──────────────

import pandas as pd
import numpy as np
from scipy import stats

train = pd.read_csv(train_path)
test  = pd.read_csv(test_path)
print(f"train: {train.shape},  test: {test.shape}")

test_ids = test[id_col].copy() if id_col in test.columns else pd.Series(range(len(test)), name=id_col)

# target distribution check
y_raw = train[target_col]
print(f"target stats: mean={y_raw.mean():.3f}, median={y_raw.median():.3f}, std={y_raw.std():.3f}")
print(f"target skewness: {stats.skew(y_raw):.3f}")     # |skew| > 1 → consider log

# log transform if skewed and positive
if log_target and (y_raw > 0).all():
    y = np.log1p(y_raw)
    print(f"applied log1p; new skewness: {stats.skew(y):.3f}")
else:
    y = y_raw
    log_target = False                                  # disable inverse-transform later

X = train.drop(columns=[c for c in [target_col, id_col] if c in train.columns])
X_test = test.drop(columns=[c for c in [id_col] if c in test.columns])
''',
    notes=[
        "Skewness > 1 → log transform usually helps RMSE",
        "log1p (not log) handles zeros safely",
        "Inverse transform with expm1 at submission",
        "If target has negative values, log1p won't work — try Box-Cox or quantile transform instead",
    ],
    inputs=["train.csv, test.csv"],
    outputs=["X, y, X_test, test_ids, target_col, id_col, log_target"],
    requires=["pandas", "numpy", "scipy"],
)


preprocess = Entry(
    name="preprocess",
    title="Section 2 — ColumnTransformer (same recipe as classification)",
    code='''# Same as binary/multiclass preprocess
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OrdinalEncoder

num_cols = X.select_dtypes(include="number").columns.tolist()
cat_cols = X.select_dtypes(include=["object", "category"]).columns.tolist()

preprocessor = ColumnTransformer([
    ("num", Pipeline([("imputer", SimpleImputer(strategy="median")), ("scaler", StandardScaler())]), num_cols),
    ("cat", Pipeline([("imputer", SimpleImputer(strategy="constant", fill_value="missing")),
                       ("encoder", OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1))]), cat_cols),
])

X_pp      = preprocessor.fit_transform(X)
X_test_pp = preprocessor.transform(X_test)
''',
    notes=[
        "Identical to classification preprocess — see axonet.ml.binary.preprocess for variants",
    ],
    inputs=["X, X_test"],
    outputs=["X_pp, X_test_pp, num_cols, cat_cols"],
    requires=["sklearn"],
)


cv_train_manual = Entry(
    name="cv_train_manual",
    title="Section 3a — regression OOF with LightGBM",
    code='''import lightgbm as lgb
import numpy as np
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error, mean_absolute_error

n_splits = 5
oof        = np.zeros(len(X_pp))
test_preds = np.zeros(len(X_test_pp))

# regression uses plain KFold (no stratification on continuous targets)
kf = KFold(n_splits=n_splits, shuffle=True, random_state=42)

for fold_idx, (tr_idx, val_idx) in enumerate(kf.split(X_pp, y)):
    model = lgb.LGBMRegressor(
        n_estimators=2000,
        learning_rate=0.05,
        num_leaves=31,
        subsample=0.8,
        colsample_bytree=0.8,
        objective="regression",                         # L2 / "regression_l1" for MAE / "huber" for outlier-robust
        metric="rmse",
        verbose=-1,
        random_state=42,
    )
    model.fit(
        X_pp[tr_idx], y.iloc[tr_idx],
        eval_set=[(X_pp[val_idx], y.iloc[val_idx])],
        callbacks=[lgb.early_stopping(50, verbose=False)],
    )
    oof[val_idx]  = model.predict(X_pp[val_idx])
    test_preds   += model.predict(X_test_pp) / n_splits

# evaluate (in log space if applicable, else raw)
print(f"OOF RMSE (in fitted space): {np.sqrt(mean_squared_error(y, oof)):.4f}")
print(f"OOF MAE  (in fitted space): {mean_absolute_error(y, oof):.4f}")

# inverse-transform if log was applied
if log_target:
    oof_orig        = np.expm1(oof)
    test_preds_orig = np.expm1(test_preds)
    y_orig          = np.expm1(y)
    print(f"OOF RMSE (original scale): {np.sqrt(mean_squared_error(y_orig, oof_orig)):.4f}")
else:
    oof_orig, test_preds_orig = oof, test_preds

# clip to valid range if target is bounded (e.g., non-negative, [0, 1], etc.)
test_preds_orig = np.clip(test_preds_orig, a_min=0, a_max=None)   # adapt bounds to your target
predictions = test_preds_orig
''',
    notes=[
        "objective='regression' = L2 (RMSE-optimal); 'regression_l1' = L1 (MAE-optimal); 'huber' = outlier-robust",
        "Plain KFold for regression — no stratification on continuous targets",
        "Inverse-transform with np.expm1 if you log-transformed in load",
        "Clip predictions to valid range — np.clip(preds, 0, None) for non-negative targets",
        "For RMSE: use log target if skewed; for MAE: log helps less, often skip",
    ],
    inputs=["X_pp, y, X_test_pp, log_target"],
    outputs=["oof, test_preds, predictions"],
    requires=["lightgbm", "sklearn", "numpy"],
)


cv_train_autogluon = Entry(
    name="cv_train_autogluon",
    title="Section 3b — AutoGluon TabularPredictor (regression)",
    code='''# AutoGluon detects regression automatically when target is continuous
from autogluon.tabular import TabularDataset, TabularPredictor
from sklearn.metrics import mean_squared_error
import numpy as np

train_data = TabularDataset(train.drop(columns=[c for c in [id_col] if c in train.columns]))
test_data  = TabularDataset(test.drop(columns=[c for c in [id_col] if c in test.columns]))

predictor = TabularPredictor(
    label=target_col,
    problem_type="regression",                          # explicit (auto-detection usually correct)
    eval_metric=metric,                                 # rmse / mae / r2 / mean_absolute_percentage_error
    path="./ag_models",
).fit(
    train_data,
    presets="best_quality_v150",
    time_limit=3600,
)

predictor.leaderboard(silent=True).head(10)

oof        = predictor.predict_oof().values
test_preds = predictor.predict(test_data).values

print(f"AG OOF RMSE: {np.sqrt(mean_squared_error(y, oof)):.4f}")

predictions = np.clip(test_preds, a_min=0, a_max=None)  # adapt bounds to your target
''',
    notes=[
        "AutoGluon doesn't apply log transforms — pre-transform target before fit if you want it",
        "Pass eval_metric='rmse' even if target is log-transformed (AG just optimizes that metric on the data you give it)",
        "predict_oof() returns raw predictions; same scale as fit target",
        "Clip predictions to valid range as the last step",
    ],
    inputs=["train, test, target_col, id_col, metric"],
    outputs=["predictor, oof, test_preds, predictions"],
    requires=["autogluon.tabular", "sklearn", "numpy"],
)


submit = Entry(
    name="submit",
    title="Section 4 — write submission CSV (regression)",
    code='''from axonet.utils import submit

sub = submit(
    predictions,                                        # continuous values
    test_ids,
    target_col=target_col,
    id_col=id_col,
    filename="submission.csv",
)
sub.head()
''',
    notes=[
        "Most regression submissions accept floats directly — no rounding/casting",
        "For count-like targets (integer-valued): cast to int with .astype(int) AFTER clipping",
        "Some submissions have specific precision requirements — check sample_submission.csv",
    ],
    inputs=["predictions, test_ids, target_col, id_col"],
    outputs=["submission.csv on disk"],
    requires=["axonet.utils"],
)


index = _make_index(__name__)
