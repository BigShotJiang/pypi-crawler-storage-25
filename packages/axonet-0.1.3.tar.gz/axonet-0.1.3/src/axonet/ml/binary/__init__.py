"""Tabular binary classification — sectioned end-to-end pipeline.

Copy each section into a notebook cell in order. The CONFIG block at the top
of `load` sets target_col / id_col / paths once for the whole flow.

Sections expected to run in this order:
  load → preprocess → cv_train_manual (or cv_train_autogluon) → threshold → submit
"""
from ..._entry import Entry, _make_index


load = Entry(
    name="load",
    title="Section 1 — load CSVs and split features/target",
    code='''# ─── CONFIG ───
train_path = "train.csv"
test_path  = "test.csv"
target_col = "target"
id_col     = "id"
metric     = "roc_auc"                                  # roc_auc / f1 / accuracy / log_loss
# ──────────────

import pandas as pd
import numpy as np

train = pd.read_csv(train_path)
test  = pd.read_csv(test_path)
print(f"train: {train.shape},  test: {test.shape}")

# preserve test ids for submission
test_ids = test[id_col].copy() if id_col in test.columns else pd.Series(range(len(test)), name=id_col)

# split features/target/id
y = train[target_col]
X = train.drop(columns=[c for c in [target_col, id_col] if c in train.columns])
X_test = test.drop(columns=[c for c in [id_col] if c in test.columns])

print(f"X: {X.shape},  y: {y.shape},  X_test: {X_test.shape}")
print(f"target balance: {y.value_counts().to_dict()}")
''',
    notes=[
        "Run axonet.ml.eda.full_quick BEFORE this section to scout the data",
        "Run axonet.ml.failure_modes.all_checks AFTER this section to catch leakage / time / ordinal / etc.",
        "If id_col isn't in test (or is named differently), test_ids falls back to range index",
    ],
    inputs=["train.csv, test.csv"],
    outputs=["X, y, X_test, test_ids, target_col, id_col, metric"],
    requires=["pandas", "numpy"],
)


preprocess = Entry(
    name="preprocess",
    title="Section 2 — ColumnTransformer (numeric impute+scale, cat impute+ordinal)",
    code='''from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OrdinalEncoder

# detect column types
num_cols = X.select_dtypes(include="number").columns.tolist()
cat_cols = X.select_dtypes(include=["object", "category"]).columns.tolist()
print(f"{len(num_cols)} numeric, {len(cat_cols)} categorical")

preprocessor = ColumnTransformer([
    ("num", Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler",  StandardScaler()),
    ]), num_cols),
    ("cat", Pipeline([
        ("imputer", SimpleImputer(strategy="constant", fill_value="missing")),
        ("encoder", OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1)),
    ]), cat_cols),
])

X_pp      = preprocessor.fit_transform(X)
X_test_pp = preprocessor.transform(X_test)
print(f"X_pp: {X_pp.shape},  X_test_pp: {X_test_pp.shape}")
''',
    notes=[
        "Skip the StandardScaler step if you only use tree models (harmless but wasted compute)",
        "OrdinalEncoder unknown_value=-1 is essential — test categories absent in train would error otherwise",
        "For higher-cardinality cats, swap the cat encoder for frequency or target encoding (see axonet.ml.preprocess.encoders)",
        "For CatBoost, skip preprocessing entirely — pass raw X + cat_features=cat_cols",
    ],
    inputs=["X, X_test"],
    outputs=["X_pp, X_test_pp, num_cols, cat_cols"],
    requires=["sklearn"],
)


cv_train_manual = Entry(
    name="cv_train_manual",
    title="Section 3a — manual OOF training with LightGBM",
    code='''import lightgbm as lgb
import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score, f1_score, accuracy_score

n_splits = 5
oof        = np.zeros(len(X_pp))
test_preds = np.zeros(len(X_test_pp))

skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)

for fold_idx, (tr_idx, val_idx) in enumerate(skf.split(X_pp, y)):
    model = lgb.LGBMClassifier(
        n_estimators=2000,
        learning_rate=0.05,
        num_leaves=31,
        min_child_samples=20,
        subsample=0.8,
        colsample_bytree=0.8,
        objective="binary",
        metric="auc",
        verbose=-1,
        random_state=42,
        # for severe imbalance, uncomment:
        # class_weight="balanced",
    )
    model.fit(
        X_pp[tr_idx], y.iloc[tr_idx],
        eval_set=[(X_pp[val_idx], y.iloc[val_idx])],
        callbacks=[lgb.early_stopping(50, verbose=False)],
    )
    oof[val_idx]  = model.predict_proba(X_pp[val_idx])[:, 1]
    test_preds   += model.predict_proba(X_test_pp)[:, 1] / n_splits
    print(f"fold {fold_idx}: AUC = {roc_auc_score(y.iloc[val_idx], oof[val_idx]):.4f}")

print(f"\\nOOF AUC: {roc_auc_score(y, oof):.4f}")
''',
    notes=[
        "For ensembling diversity, repeat with XGBoost and CatBoost (see axonet.ml.boosting)",
        "For severe imbalance: add class_weight='balanced' or scale_pos_weight=N_neg/N_pos",
        "For grouped data: replace StratifiedKFold with StratifiedGroupKFold and pass groups=",
        "For time structure: use TimeSeriesSplit instead",
        "To stack multiple base models: see axonet.ml.ensemble.stacking",
    ],
    inputs=["X_pp, y, X_test_pp"],
    outputs=["oof, test_preds"],
    requires=["lightgbm", "sklearn", "numpy"],
)


cv_train_autogluon = Entry(
    name="cv_train_autogluon",
    title="Section 3b — AutoGluon TabularPredictor (alternative to manual training)",
    code='''# ─── prereq ───
# !pip install -U autogluon.tabular[lightgbm,xgboost,catboost]
# for extreme_quality: !pip install -U autogluon.tabular[tabarena]
# ──────────────

from autogluon.tabular import TabularDataset, TabularPredictor

# AG works on raw DataFrames — skip the ColumnTransformer step before this
train_data = TabularDataset(train.drop(columns=[c for c in [id_col] if c in train.columns]))
test_data  = TabularDataset(test.drop(columns=[c for c in [id_col] if c in test.columns]))

# pick a preset based on time + GPU availability
predictor = TabularPredictor(
    label=target_col,
    eval_metric=metric,
    path="./ag_models",
).fit(
    train_data,
    presets="best_quality_v150",                        # safe choice on L4
    # presets="extreme_quality",                        # if [tabarena] is installed and small data
    time_limit=3600,                                    # 1 hour cap
)

# leaderboard
predictor.leaderboard(silent=True).head(10)

# OOF + test predictions (binary)
oof        = predictor.predict_proba_oof().iloc[:, 1].values
test_preds = predictor.predict_proba(test_data).iloc[:, 1].values

# AG's internal CV score — should match the leaderboard's score_val
from sklearn.metrics import roc_auc_score
print(f"AG OOF score: {roc_auc_score(y, oof):.4f}")
''',
    notes=[
        "Skip Section 2 (preprocess) — AutoGluon ingests raw DataFrames",
        "Use best_quality_v150 as the safe default; extreme_quality only if you've installed [tabarena] AND have GPU",
        "predict_proba_oof() requires bagging (any preset other than medium_quality) — automatically true for the v150 / extreme",
        "For OOM on L4 with extreme_quality, see axonet.ml.autogluon.memory_fallback",
        "predict_proba returns a DataFrame with one column per class; .iloc[:, 1] picks class 1 for binary",
    ],
    inputs=["train, test, target_col, id_col, metric"],
    outputs=["predictor, oof, test_preds"],
    requires=["autogluon.tabular", "sklearn"],
)


threshold = Entry(
    name="threshold",
    title="Section 4 — F1-optimal threshold tuning (skip if metric is AUC)",
    code='''import numpy as np
from sklearn.metrics import f1_score

# only relevant if metric is f1 / accuracy with class imbalance
# for AUC / log_loss, skip this and use raw probabilities

thresholds = np.arange(0.05, 0.95, 0.005)
f1s = [f1_score(y, oof > t) for t in thresholds]

best_idx = int(np.argmax(f1s))
best_threshold = thresholds[best_idx]
print(f"best threshold: {best_threshold:.3f}  →  F1 = {f1s[best_idx]:.4f}")

# binary predictions for submission
predictions = (test_preds > best_threshold).astype(int)
''',
    notes=[
        "Skip this section if metric is AUC or log_loss — use raw probabilities",
        "Tune on OOF — never on training-set probabilities",
        "Default 0.5 is rarely optimal for F1 on imbalanced data",
        "If submission accepts probabilities, skip threshold tuning entirely and submit test_preds",
    ],
    inputs=["oof, y, test_preds"],
    outputs=["best_threshold, predictions"],
    requires=["sklearn", "numpy"],
)


submit = Entry(
    name="submit",
    title="Section 5 — write submission CSV with sanity checks",
    code='''from axonet.utils import submit

# choose what to submit:
#   - if F1 / accuracy: submit class predictions
#   - if AUC / log_loss: submit probabilities (test_preds)

# class predictions:
sub = submit(
    predictions,                                        # 1D array
    test_ids,                                           # 1D array of test row ids
    target_col=target_col,
    id_col=id_col,
    filename="submission.csv",
    dtype=int,                                          # cast to int
)

# OR probability-style submission:
# sub = submit(test_preds, test_ids, target_col=target_col, id_col=id_col,
#              filename="submission.csv")

sub.head()
''',
    notes=[
        "axonet.utils.submit asserts no NaNs, no duplicate ids, and row count match — last-mile sanity",
        "Verify the column order against sample_submission.csv before submitting",
        "Some tasks want strings, not ints — pass dtype=str or use a manual mapping",
    ],
    inputs=["predictions (or test_preds), test_ids, target_col, id_col"],
    outputs=["submission.csv on disk"],
    requires=["axonet.utils"],
)


index = _make_index(__name__)
