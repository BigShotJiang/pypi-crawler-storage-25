"""Ensembling — stacking, blending, seed averaging, weight optimization.

All require OOF predictions from base models — see axonet.ml.cv.oof_pattern.
Stacking is the strongest default; seed_avg is the cheapest.
"""
from ..._entry import Entry, _make_index


stacking = Entry(
    name="stacking",
    title="OOF stacking — base models → LogReg meta",
    code='''import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score

# ─── CONFIG ───
n_splits = 5
metric = roc_auc_score                                  # or sklearn.metrics.f1_score, log_loss, etc.
# ──────────────


def train_oof(model_factory, X, y, X_test):
    """Build OOF + test predictions for one base model."""
    oof = np.zeros(len(X))
    test_preds = np.zeros(len(X_test))
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
    for tr_idx, val_idx in skf.split(X, y):
        m = model_factory()
        m.fit(X.iloc[tr_idx], y.iloc[tr_idx])
        oof[val_idx] = m.predict_proba(X.iloc[val_idx])[:, 1]
        test_preds += m.predict_proba(X_test)[:, 1] / n_splits
    return oof, test_preds


# build OOF + test for each base model
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier

oof_lgb, test_lgb = train_oof(lambda: lgb.LGBMClassifier(n_estimators=2000, learning_rate=0.05, verbose=-1, random_state=42), X, y, X_test)
oof_xgb, test_xgb = train_oof(lambda: xgb.XGBClassifier(n_estimators=2000, learning_rate=0.05, tree_method="hist", verbosity=0, random_state=42), X, y, X_test)
oof_cat, test_cat = train_oof(lambda: CatBoostClassifier(iterations=2000, learning_rate=0.05, verbose=0, random_seed=42), X, y, X_test)

print(f"LGB OOF: {metric(y, oof_lgb):.4f}")
print(f"XGB OOF: {metric(y, oof_xgb):.4f}")
print(f"CAT OOF: {metric(y, oof_cat):.4f}")

# meta features = base OOFs
X_meta      = pd.DataFrame({"lgb": oof_lgb,  "xgb": oof_xgb,  "cat": oof_cat})
X_meta_test = pd.DataFrame({"lgb": test_lgb, "xgb": test_xgb, "cat": test_cat})

# meta model — keep simple to avoid overfitting OOF
meta = LogisticRegression(C=1.0, max_iter=2000)
meta.fit(X_meta, y)

# honest meta evaluation: cross_val_predict
meta_oof = cross_val_predict(meta, X_meta, y, cv=n_splits, method="predict_proba")[:, 1]
print(f"STACK   : {metric(y, meta_oof):.4f}")

# final test predictions
test_preds = meta.predict_proba(X_meta_test)[:, 1]
''',
    notes=[
        "OOF predictions = each row's prediction came from a model that didn't see it during training (no leakage)",
        "Meta model SIMPLER than base models — LogReg / Ridge — to avoid overfitting OOFs",
        "Common gain: +1-3% over best single model on imbalanced binary",
        "For multiclass: replace [:, 1] with full predict_proba (oof becomes (n, K))",
        "For more diverse meta inputs: add original features into X_meta alongside OOFs (feature-stacking)",
    ],
    when_to_use=[
        "After all base models are tuned individually",
        "Diverse base models (different families) — LGBM + CatBoost > LGBM + XGB",
    ],
    inputs=["X, y, X_test"],
    outputs=["test_preds (final), meta_oof"],
    requires=["lightgbm", "xgboost", "catboost", "sklearn", "pandas", "numpy"],
)


blending = Entry(
    name="blending",
    title="Blending — single held-out set, simpler than full OOF stacking",
    code='''from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
import pandas as pd
import numpy as np

# split train into main + holdout (blending uses ONE holdout, not K folds)
X_main, X_hold, y_main, y_hold = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# train each base model on X_main only
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier

models = {
    "lgb": lgb.LGBMClassifier(n_estimators=2000, verbose=-1, random_state=42),
    "xgb": xgb.XGBClassifier(n_estimators=2000, tree_method="hist", verbosity=0, random_state=42),
    "cat": CatBoostClassifier(iterations=2000, verbose=0, random_seed=42),
}

hold_preds, test_preds_dict = {}, {}
for name, m in models.items():
    m.fit(X_main, y_main)
    hold_preds[name]      = m.predict_proba(X_hold)[:, 1]
    test_preds_dict[name] = m.predict_proba(X_test)[:, 1]

# meta on holdout
X_meta_hold = pd.DataFrame(hold_preds)
X_meta_test = pd.DataFrame(test_preds_dict)

meta = LogisticRegression(C=1.0, max_iter=2000)
meta.fit(X_meta_hold, y_hold)
test_preds = meta.predict_proba(X_meta_test)[:, 1]
''',
    notes=[
        "Trade: faster (no K-fold loop) but uses less training data per base model (~80% vs 100%)",
        "Single held-out set means more variance in meta — full stacking is more reliable",
        "Use blending when stacking takes too long",
        "Holdout 20% is conventional; 10% if you want to keep more training data",
    ],
    when_to_use=[
        "Time-constrained, when full K-fold stacking is too slow",
    ],
    inputs=["X, y, X_test"],
    outputs=["test_preds"],
    requires=["sklearn", "pandas", "numpy", "lightgbm", "xgboost", "catboost"],
)


seed_avg = Entry(
    name="seed_avg",
    title="Seed averaging — same model, different random states",
    code='''import numpy as np
import lightgbm as lgb
from sklearn.metrics import roc_auc_score

seeds = [42, 123, 456, 789, 2024]
test_preds = np.zeros(len(X_test))
oof_avg    = np.zeros(len(X))

for seed in seeds:
    # use any base model + OOF loop here (see axonet.ml.cv.oof_pattern for train_oof)
    factory = lambda s=seed: lgb.LGBMClassifier(
        n_estimators=2000, learning_rate=0.05, num_leaves=31,
        verbose=-1, random_state=s,
    )
    oof_seed, test_seed = train_oof(factory, X, y, X_test)
    oof_avg    += oof_seed   / len(seeds)
    test_preds += test_seed / len(seeds)

print(f"seed-avg OOF AUC: {roc_auc_score(y, oof_avg):.4f}")
''',
    notes=[
        "Same model trained N times with different seeds — averaging reduces variance",
        "Cheapest ensembling technique; ~0.2-0.5% gain typically",
        "Cost: N× training time. Only worth after exhausting bigger gains (model swap, stacking)",
        "Pairs with stacking — average each base model across seeds, THEN stack the averaged OOFs",
    ],
    when_to_use=[
        "After model choice and tuning are done",
        "When you have spare time at the end of the 2-hour budget",
    ],
    inputs=["X, y, X_test"],
    outputs=["test_preds, oof_avg"],
    requires=["lightgbm", "numpy", "sklearn"],
)


weighted_avg = Entry(
    name="weighted_avg",
    title="Weighted averaging — optimize blend weights on OOF",
    code='''import numpy as np
from scipy.optimize import minimize
from sklearn.metrics import roc_auc_score

# requires: oof_lgb, oof_xgb, oof_cat (each shape (n,)) and y exist
# also:     test_lgb, test_xgb, test_cat (each shape (n_test,))

oof_list  = [oof_lgb, oof_xgb, oof_cat]
test_list = [test_lgb, test_xgb, test_cat]
n_models = len(oof_list)


def neg_score(weights):
    w = np.array(weights)
    w = w / w.sum()                                     # normalize so weights sum to 1
    blended = sum(w_i * oof for w_i, oof in zip(w, oof_list))
    return -roc_auc_score(y, blended)                   # maximize → negate for minimize


# constrained optimization — weights >= 0 (no anti-portfolio)
result = minimize(
    neg_score,
    x0=[1.0 / n_models] * n_models,
    method="Nelder-Mead",
    options={"xatol": 1e-5, "fatol": 1e-6, "maxiter": 200},
)

best_weights = np.array(result.x) / np.sum(result.x)
print(f"weights: {dict(zip(['lgb','xgb','cat'], best_weights.round(3)))}")
print(f"best OOF AUC: {-result.fun:.4f}")

test_preds = sum(w * t for w, t in zip(best_weights, test_list))
''',
    notes=[
        "Better than simple average when models have different strengths",
        "Optimize on OOF — only honest signal",
        "Nelder-Mead is robust for low-dim optimization (≤5 weights)",
        "If a weight ends up 0, that model is being excluded — drop it from the ensemble",
        "Beware overfitting OOF on very few rows — stacking with LogReg meta is more robust",
    ],
    when_to_use=[
        "After OOF predictions from multiple models exist",
        "Faster alternative to full stacking when time is tight",
    ],
    inputs=["oof_list, test_list, y"],
    outputs=["best_weights, test_preds"],
    requires=["scipy", "numpy", "sklearn"],
)


hill_climb = Entry(
    name="hill_climb",
    title="Caruana hill-climbing — greedy weight selection",
    code='''import numpy as np
from sklearn.metrics import roc_auc_score

oof_array  = np.column_stack(oof_list)                  # shape (n, n_models)
test_array = np.column_stack(test_list)                 # shape (n_test, n_models)
n_models = oof_array.shape[1]

# greedy: at each step, pick the model that most improves the running ensemble
# (with replacement — same model can be picked multiple times to up-weight it)
ensemble_idx = []
running = np.zeros(len(y))
n_iters = 50

for step in range(n_iters):
    best_score, best_pick = -np.inf, None
    for k in range(n_models):
        candidate = (running * step + oof_array[:, k]) / (step + 1)
        score = roc_auc_score(y, candidate)
        if score > best_score:
            best_score, best_pick = score, k
    ensemble_idx.append(best_pick)
    running = (running * step + oof_array[:, best_pick]) / (step + 1)

# count picks → effective weights
counts = np.bincount(ensemble_idx, minlength=n_models)
weights = counts / counts.sum()
print(f"weights: {weights.round(3)}")
print(f"final OOF: {best_score:.4f}")

test_preds = test_array @ weights
''',
    notes=[
        "Caruana et al. (2004): start empty, greedily add the model that most improves ensemble",
        "More robust than gradient-based weight optimization on noisy OOFs",
        "Tends to assign weight 0 to weak models — automatic feature selection",
        "n_iters=50 is conservative; usually converges in <20 picks",
    ],
    when_to_use=[
        "Many candidate models (5+) — automatic selection",
        "When weighted_avg gives unstable weights",
    ],
    inputs=["oof_list, test_list, y"],
    outputs=["weights, test_preds"],
    requires=["numpy", "sklearn"],
)


index = _make_index(__name__)
