"""Tabular preprocessing — ColumnTransformer recipe + encoder/imputer variants.

The default `column_transformer` is what you use 90% of the time. The other
entries cover variants for high-cardinality categoricals, missingness-aware
imputation, and the missing-indicator pattern.
"""
from ..._entry import Entry, _make_index


column_transformer = Entry(
    name="column_transformer",
    title="Standard ColumnTransformer — numeric + categorical, leakage-safe",
    code='''# ─── CONFIG ───
target_col = "target"
id_col     = "id"
# ──────────────

from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OrdinalEncoder

# split features and target
y = train[target_col]
drop_cols = [target_col] + ([id_col] if id_col in train.columns else [])
X = train.drop(columns=drop_cols)
X_test = test.drop(columns=[id_col] if id_col in test.columns else [])

# detect column types
num_cols = X.select_dtypes(include="number").columns.tolist()
cat_cols = X.select_dtypes(include=["object", "category"]).columns.tolist()
print(f"{len(num_cols)} numeric, {len(cat_cols)} categorical")

# pipeline: impute → scale (numeric) || impute → ordinal-encode (categorical)
preprocessor = ColumnTransformer([
    ("num", Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler",  StandardScaler()),
    ]), num_cols),
    ("cat", Pipeline([
        ("imputer", SimpleImputer(strategy="constant", fill_value="missing")),
        ("encoder", OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1)),
    ]), cat_cols),
])

# fit on train only (leakage-safe), transform both
X_pp      = preprocessor.fit_transform(X)
X_test_pp = preprocessor.transform(X_test)
print(f"X_pp: {X_pp.shape},  X_test_pp: {X_test_pp.shape}")
''',
    notes=[
        "Skip StandardScaler if you only use tree models — harmless but wasted compute",
        "OrdinalEncoder handle_unknown='use_encoded_value' is essential — test categories absent in train would error otherwise",
        "For CatBoost: skip this entirely. Pass raw DataFrame + cat_features=cat_cols",
        "For high-card categoricals (>50 unique): swap to freq encoding or target encoding (see encoders entry)",
    ],
    when_to_use=[
        "Default first move for any tabular pipeline",
    ],
    inputs=["train", "test", "target_col", "id_col"],
    outputs=["X_pp", "X_test_pp", "y", "num_cols", "cat_cols"],
    requires=["pandas", "sklearn"],
)


encoders = Entry(
    name="encoders",
    title="Categorical encoder variants — when to pick which",
    code='''# ── ordinal (default for trees in column_transformer) ──
from sklearn.preprocessing import OrdinalEncoder
ord_enc = OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1)
# fits per-column; assigns each unique value an integer 0..K-1
# good for trees; bad for linear models (implies false ordering)

# ── one-hot (low-card + linear/MLP) ──
from sklearn.preprocessing import OneHotEncoder
ohe = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
# explodes feature count; only use ≤10 unique values per column

# ── frequency encoding (high-card) ──
freq_map = train[col].value_counts(normalize=True)
train[f"{col}_freq"] = train[col].map(freq_map)
test[f"{col}_freq"]  = test[col].map(freq_map).fillna(0)  # unseen → 0

# ── target encoding (high-card, supervised) ──
# DO NOT fit on full train — leakage. Use OOF version:
# from axonet.ml.failure_modes.target_encoding_oof:
#   train["col_te"], test["col_te"] = target_encode_oof(train, test, col, target_col)

# ── native categorical (LightGBM) ──
train[col] = train[col].astype("category")
test[col]  = test[col].astype("category")
# then pass categorical_feature=[col, ...] to lgb fit()

# ── native categorical (CatBoost) ──
# pass cat_features=[col, ...] to CatBoostClassifier — no manual encoding needed

# ── native categorical (XGBoost 3.x) ──
# set enable_categorical=True in XGBClassifier
# AND ensure columns are pd.Categorical: train[col] = train[col].astype("category")
''',
    notes=[
        "Default for boosting pipelines: OrdinalEncoder (compact + tree-friendly)",
        "Default for linear/MLP: OneHotEncoder (≤10 unique) or target encoding (more)",
        "Very high cardinality (city, zipcode, name): freq encoding or native categorical",
        "CatBoost handles categoricals best of the three — pass cat_features and skip encoding entirely",
    ],
    inputs=["train (DataFrame)", "col (str)"],
    requires=["pandas", "sklearn"],
)


imputation = Entry(
    name="imputation",
    title="Imputation choice — median / mode / KNN / iterative / model-native",
    code='''from sklearn.impute import SimpleImputer

# ── numeric: median (default — robust to outliers) ──
num_imputer = SimpleImputer(strategy="median")

# numeric alternative: mean (use only when outliers are minimal)
# num_imputer = SimpleImputer(strategy="mean")

# ── categorical: constant 'missing' (preserves missingness as its own category) ──
cat_imputer = SimpleImputer(strategy="constant", fill_value="missing")

# categorical alternative: most frequent (loses the missingness signal)
# cat_imputer = SimpleImputer(strategy="most_frequent")

# ── KNN imputation (slower, uses feature relationships) ──
# from sklearn.impute import KNNImputer
# knn_imputer = KNNImputer(n_neighbors=5)

# ── iterative imputation (slowest, models each col as a function of others) ──
# from sklearn.experimental import enable_iterative_imputer  # noqa: required import
# from sklearn.impute import IterativeImputer
# iter_imputer = IterativeImputer(random_state=42, max_iter=10)

# ── model-native (no imputation) ──
# LightGBM, XGBoost (3.x), CatBoost handle NaN natively. Pass raw DataFrames.
# Trees split optimally on 'is missing'. Often the best choice for boosting.
''',
    notes=[
        "Default for boosting: skip imputation — pass NaN directly. Often beats explicit median fill",
        "Default for linear/MLP: median (numeric) + constant 'missing' (categorical)",
        "KNN/Iterative are slow on large data — only use when you have time AND a reason",
        "If missingness is predictive (see failure_modes.missingness_target_corr), ADD missing_indicators BEFORE imputing",
    ],
    requires=["sklearn"],
)


missing_indicators = Entry(
    name="missing_indicators",
    title="Add missing-indicator features (preserves the missingness signal)",
    code='''# add binary 'is_missing' columns for any column with missing values
miss_cols = [c for c in train.columns if train[c].isna().any() and c != target_col]
for col in miss_cols:
    train[f"{col}_isna"] = train[col].isna().astype(int)
    test[f"{col}_isna"]  = test[col].isna().astype(int)

print(f"added {len(miss_cols)} missing-indicator columns")
''',
    notes=[
        "Run BEFORE imputation — once you impute, missingness is destroyed",
        "Trees and linear models can both use these directly",
        "Pair with axonet.ml.failure_modes.missingness_target_corr to check WHICH columns benefit",
        "If no column's missingness correlates with target, indicators are noise — skip them",
    ],
    inputs=["train", "test", "target_col"],
    outputs=["train (mutated)", "test (mutated)"],
    requires=["pandas"],
)


index = _make_index(__name__)
