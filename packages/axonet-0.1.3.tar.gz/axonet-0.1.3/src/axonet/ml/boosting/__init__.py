"""Boosting libraries — LightGBM 4.x, XGBoost 3.x, CatBoost.

Each entry shows the canonical fit pattern with 2026-correct syntax. The
`compare` entry is a quick decision table for picking among them.
"""
from ..._entry import Entry, _make_index


lightgbm = Entry(
    name="lightgbm",
    title="LightGBM 4.x — fit with early stopping, categorical features, GPU",
    code='''import lightgbm as lgb

# ─── CONFIG ───
n_estimators  = 2000      # cap; early stopping picks the best round
learning_rate = 0.05
num_leaves    = 31        # complexity knob (default 31; 63-127 for larger data)
metric        = "auc"     # binary: auc | binary_logloss; multi: multi_logloss
device        = "cpu"     # "gpu" / "cuda" if compiled with GPU support
# ──────────────

model = lgb.LGBMClassifier(
    n_estimators=n_estimators,
    learning_rate=learning_rate,
    num_leaves=num_leaves,
    min_child_samples=20,        # lower = more fit; raise for noisy/small data
    subsample=0.8,
    colsample_bytree=0.8,
    reg_alpha=0.0,
    reg_lambda=0.0,
    objective="binary",          # "multiclass" + num_class=K for multiclass
    metric=metric,
    device=device,
    verbose=-1,
    random_state=42,
)

# native categorical handling — pass column names (or list of indices)
cat_features = train.select_dtypes(include=["object", "category"]).columns.tolist()

model.fit(
    X_train, y_train,
    eval_set=[(X_val, y_val)],
    categorical_feature=cat_features,
    callbacks=[
        lgb.early_stopping(stopping_rounds=50),
        lgb.log_evaluation(period=100),     # set 0 to silence
    ],
)

# inference
proba = model.predict_proba(X_test)         # (n, num_classes)
preds = model.predict(X_test)               # argmax / threshold internally
''',
    notes=[
        "early_stopping is a callback in LGBM 4.x — not a fit kwarg",
        "categorical_feature= takes column names if input is DataFrame, indices if numpy",
        "For severe imbalance (binary): add class_weight='balanced' or scale_pos_weight=N",
        "For multiclass: objective='multiclass', num_class=K, metric='multi_logloss'",
        "Tuning order: learning_rate → num_leaves → min_child_samples → subsample/colsample → reg_alpha/reg_lambda",
        "GPU: requires special build — pip install lightgbm with CMAKE_ARGS, or use device='cpu' as fallback",
    ],
    when_to_use=[
        "Default first model for tabular tasks",
        "Mixed numeric + categorical, any size data",
    ],
    inputs=["X_train, y_train, X_val, y_val, X_test (and optional cat_features)"],
    outputs=["model, proba, preds"],
    requires=["lightgbm", "pandas"],
)


xgboost = Entry(
    name="xgboost",
    title="XGBoost 3.x — early stopping in constructor, device='cuda', native categorical",
    code='''import xgboost as xgb

# ─── CONFIG ───
n_estimators  = 2000
learning_rate = 0.05
max_depth     = 6
device        = "cuda"        # "cuda" / "cpu" — XGBoost 3.x dropped tree_method='gpu_hist'
eval_metric   = "logloss"     # binary: logloss | auc; multi: mlogloss
# ──────────────

# 3.x KEY CHANGES from 1.x/2.x:
#   - device="cuda" (replaces tree_method="gpu_hist")
#   - early_stopping_rounds & eval_metric moved to CONSTRUCTOR (not fit kwargs)
#   - enable_categorical=True needs columns cast to pd.Categorical first

model = xgb.XGBClassifier(
    n_estimators=n_estimators,
    learning_rate=learning_rate,
    max_depth=max_depth,
    min_child_weight=5,
    subsample=0.8,
    colsample_bytree=0.8,
    reg_alpha=0.0,
    reg_lambda=1.0,
    tree_method="hist",
    device=device,
    enable_categorical=True,        # required if any column is pd.Categorical
    early_stopping_rounds=50,       # in constructor, not fit
    eval_metric=eval_metric,        # in constructor, not fit
    objective="binary:logistic",    # "multi:softprob" + num_class=K for multiclass
    random_state=42,
)

# cast object columns to pd.Categorical for native handling
cat_cols = train.select_dtypes(include=["object", "category"]).columns.tolist()
for col in cat_cols:
    X_train[col] = X_train[col].astype("category")
    X_val[col]   = X_val[col].astype("category")
    X_test[col]  = X_test[col].astype("category")

model.fit(
    X_train, y_train,
    eval_set=[(X_val, y_val)],
    verbose=100,                    # 0 to silence
)

# inference
proba = model.predict_proba(X_test)
preds = model.predict(X_test)
''',
    notes=[
        "BREAKING CHANGE in 3.x: tree_method='gpu_hist' removed → use tree_method='hist' + device='cuda'",
        "BREAKING CHANGE in 3.x: early_stopping_rounds and eval_metric live in the constructor, NOT in fit()",
        "For multiclass: objective='multi:softprob', num_class=K, eval_metric='mlogloss'",
        "For severe binary imbalance: scale_pos_weight = (neg_count / pos_count)",
        "Set device='cpu' if no GPU or if dataset is small — overhead of GPU rarely worth it under 10K rows",
    ],
    when_to_use=[
        "Tabular task; alternative to LightGBM with similar performance",
        "When you specifically want XGBoost (e.g., for ensembling diversity with LGBM)",
    ],
    inputs=["X_train, y_train, X_val, y_val, X_test"],
    outputs=["model, proba, preds"],
    requires=["xgboost", "pandas"],
)


catboost = Entry(
    name="catboost",
    title="CatBoost — native categorical handling, GPU via task_type='GPU'",
    code='''from catboost import CatBoostClassifier

# ─── CONFIG ───
iterations    = 2000        # CatBoost's name for n_estimators
learning_rate = 0.05
depth         = 6
loss_function = "Logloss"   # binary: Logloss; multi: MultiClass
eval_metric   = "Logloss"   # or "AUC" / "Accuracy" / "F1"
task_type     = "CPU"       # "GPU" if CUDA available
# ──────────────

# detect categorical columns by name (CatBoost prefers column names with DataFrame input)
cat_features = train.select_dtypes(include=["object", "category"]).columns.tolist()

model = CatBoostClassifier(
    iterations=iterations,
    learning_rate=learning_rate,
    depth=depth,
    l2_leaf_reg=3,
    random_strength=1.0,
    bagging_temperature=1.0,
    loss_function=loss_function,
    eval_metric=eval_metric,
    cat_features=cat_features,    # CatBoost handles encoding internally
    early_stopping_rounds=50,
    task_type=task_type,
    devices="0",                  # GPU index; ignored on CPU
    random_seed=42,
    verbose=100,                  # 0 to silence
)

model.fit(
    X_train, y_train,
    eval_set=(X_val, y_val),      # tuple, not list
)

# inference
proba = model.predict_proba(X_test)
preds = model.predict(X_test).flatten()  # CatBoost returns 2D for predict
''',
    notes=[
        "Best out-of-the-box for mixed-type data — minimal preprocessing needed",
        "cat_features= accepts column names (with DataFrame) OR column indices (with numpy)",
        "For multiclass: loss_function='MultiClass', eval_metric='MultiClass' or 'Accuracy'",
        "For severe binary imbalance: class_weights=[1, N] or auto_class_weights='Balanced'",
        "GPU: task_type='GPU' is much faster on large data; ignored on small data anyway",
        "Slower training than LightGBM but better defaults — often best baseline accuracy",
    ],
    when_to_use=[
        "Mixed types, minimal tuning time — CatBoost shines on default params",
        "Many high-cardinality categoricals (CatBoost target-encodes natively)",
        "When you want diversity in an ensemble (CatBoost vs LGBM/XGB are decorrelated)",
    ],
    inputs=["X_train, y_train, X_val, y_val, X_test"],
    outputs=["model, proba, preds"],
    requires=["catboost", "pandas"],
)


compare = Entry(
    name="compare",
    title="LightGBM vs XGBoost vs CatBoost — when to pick which",
    code='''#                    LightGBM            XGBoost 3.x          CatBoost
# Default speed       fastest             middle               slowest
# Default accuracy    competitive         competitive          best out-of-box
# Categorical          good (mark cols)    good (cast pd.Cat)   BEST (cat_features=)
# Imbalance binary    class_weight=...    scale_pos_weight=N   class_weights=[..]
# Memory              lowest              middle               highest
# GPU support          decent              best                  good
# Tuning sensitivity  high (num_leaves)   medium               low (often default)
# Ensembling diversity high                with LGBM            with both above
#
# DEFAULT CHOICE: LightGBM
#   - mixed types, want fast iteration: LGBM
#   - want best out-of-box without tuning: CatBoost
#   - already using LGBM and want ensemble diversity: add CatBoost (more diverse than XGB)
#
# 2-HOUR PLAN: train all three with default params + early stopping. Stack OOFs.
# That's ~8-10 lines per model and a quick ensemble win.
''',
    notes=[
        "All three handle missing values natively — no need to impute",
        "All three handle categoricals natively — but each has a different API",
        "For ensembling diversity, the LGBM+CatBoost pair is more decorrelated than LGBM+XGB",
        "GPU helps mostly on large data (>1M rows) — skip GPU on small/medium and avoid setup overhead",
    ],
    requires=["lightgbm", "xgboost", "catboost"],
)


index = _make_index(__name__)
