"""AutoGluon Tabular — high-level autoML for tabular tasks.

AutoGluon (v1.5.x) wraps boosting trees, foundation models (TabPFNv2, MITRA,
TabICL, TabM, TabDPT), and ensembling into a single TabularPredictor call.
The `extreme_quality` preset is state-of-the-art on TabArena.

This namespace is ML-only — AutoGluon Multimodal is intentionally not used
here for CV/NLP/audio (those domains stay manual via HF + torchvision).
"""
from ..._entry import Entry, _make_index


installation = Entry(
    name="installation",
    title="AutoGluon installation — base, foundation models, extreme bundle",
    code='''# ── base tabular (~5 min in Colab) ──
!pip install -U autogluon.tabular[lightgbm,xgboost,catboost]

# ── foundation models (one-by-one) ──
!pip install -U autogluon.tabular[mitra]                # Mitra (small data)
!pip install -U autogluon.tabular[tabicl]               # TabICL (large data)
!pip install -U autogluon.tabular[tabpfn]               # TabPFNv2

# ── extreme bundle (everything for extreme_quality preset) ──
!pip install -U autogluon.tabular[tabarena]             # ~10 min in Colab

# verify
import autogluon
print(autogluon.__version__)                            # should be 1.5.x or higher
''',
    notes=[
        "extreme_quality preset wants the [tabarena] bundle — install before fitting if you plan to use it",
        "Foundation models can be installed individually if you only want one (saves install time)",
        "Total bundle install in Colab takes ~10 minutes — start it early in the task",
        "If install fails: restart Colab runtime and retry; sometimes pip cache gets confused",
    ],
    when_to_use=[
        "First step before using any AutoGluon entry",
    ],
    requires=["pip"],
)


basic_tabular = Entry(
    name="basic_tabular",
    title="Basic TabularPredictor — 5-line autoML baseline",
    code='''from autogluon.tabular import TabularDataset, TabularPredictor

# ─── CONFIG ───
target_col  = "target"
eval_metric = "roc_auc"                                 # "roc_auc" / "f1" / "accuracy" / "log_loss" / "rmse"
time_limit  = 600                                       # seconds
# ──────────────

# AutoGluon ingests pandas DataFrames or its own TabularDataset (CSV-aware)
train_data = TabularDataset(train)                      # or pd.read_csv("train.csv") directly
test_data  = TabularDataset(test)

predictor = TabularPredictor(
    label=target_col,
    eval_metric=eval_metric,
    path="./ag_models",                                 # where models are saved
).fit(
    train_data,
    presets="medium_quality",                           # default — good balance of speed/accuracy
    time_limit=time_limit,
)

# leaderboard of all base models + ensembles
predictor.leaderboard(test_data)

# predictions
predictions = predictor.predict(test_data.drop(columns=[target_col]) if target_col in test_data.columns else test_data)
proba       = predictor.predict_proba(test_data.drop(columns=[target_col]) if target_col in test_data.columns else test_data)
''',
    notes=[
        "5 lines of actual model code — AutoGluon handles preprocessing, CV, ensembling automatically",
        "Pass DataFrames directly — TabularDataset is just a CSV-aware subclass",
        "presets: medium_quality (default) → good_quality → high_quality → best_quality → extreme_quality",
        "time_limit is approximate — AG may run slightly over",
        "predictor.leaderboard() shows base model scores + ensemble — useful for diagnostics",
    ],
    when_to_use=[
        "Quick baseline; sanity check the data + target",
        "When you want zero modeling decisions — let AG figure it out",
    ],
    inputs=["train, test, target_col"],
    outputs=["predictor, predictions, proba"],
    requires=["autogluon.tabular", "pandas"],
)


extreme_preset = Entry(
    name="extreme_preset",
    title="extreme_quality preset — foundation models + 22-model portfolio (SOTA on TabArena)",
    code='''from autogluon.tabular import TabularDataset, TabularPredictor

# ─── CONFIG ───
target_col  = "target"
eval_metric = "roc_auc"
time_limit  = 5400                                      # 90 min — extreme can use lots
# ──────────────

# ── REQUIREMENTS ──
# 1. !pip install -U autogluon.tabular[tabarena]
# 2. CUDA GPU recommended (32+ GB ideal; L4 24 GB often works on smaller data)
# 3. Dataset ≤ 100k samples for best results

train_data = TabularDataset(train)

predictor = TabularPredictor(
    label=target_col,
    eval_metric=eval_metric,
    path="./ag_extreme",
).fit(
    train_data,
    presets="extreme_quality",                          # uses 'zeroshot_2025_tabfm' portfolio
    time_limit=time_limit,
)

predictor.leaderboard(test)
predictions = predictor.predict(test.drop(columns=[target_col], errors="ignore"))
proba       = predictor.predict_proba(test.drop(columns=[target_col], errors="ignore"))
''',
    notes=[
        "extreme_quality is state-of-the-art on TabArena — uses TabPFNv2, RealTabPFN-2, MITRA, TabICL, TabM, TabDPT, EBM, and tuned boosting",
        "Officially recommended: CUDA GPU with 32+ GB vRAM. L4 (24 GB) often works for ≤50k rows but may OOM",
        "If extreme OOMs: see memory_fallback — drop to best_quality_v150 or experimental_quality",
        "Best when dataset ≤ 100k samples; for larger data, use best_quality_v150",
        "Install [tabarena] FIRST — extreme will fail if foundation models aren't installed",
    ],
    when_to_use=[
        "L4 GPU, dataset ≤ 50k rows, want maximum accuracy",
        "30+ minute time budget for fitting",
    ],
    inputs=["train, test, target_col"],
    outputs=["predictor, predictions, proba"],
    requires=["autogluon.tabular[tabarena]", "pandas", "CUDA GPU"],
)


foundation_models = Entry(
    name="foundation_models",
    title="Tabular foundation models — MITRA, TabPFNv2, TabICL configs",
    code='''from autogluon.tabular import TabularPredictor

# ── single foundation model (faster than extreme; less ensembling) ──
predictor = TabularPredictor(label=target_col).fit(
    train_data,
    hyperparameters={
        "MITRA": {"fine_tune": False},                  # zero-shot — fastest
    },
    time_limit=300,
)

# ── MITRA with fine-tuning (a few hundred steps over the data) ──
predictor = TabularPredictor(label=target_col).fit(
    train_data,
    hyperparameters={
        "MITRA": {"fine_tune": True, "fine_tune_steps": 50},
    },
    time_limit=600,
)

# ── ensemble of multiple foundation models ──
predictor = TabularPredictor(label=target_col).fit(
    train_data,
    hyperparameters={
        "MITRA":     {"fine_tune": True, "fine_tune_steps": 30},
        "TABPFNV2":  {},
        "TABICL":    {},
    },
    time_limit=900,
)


# ── data size limits ──
# MITRA      best for <5,000 rows × <100 features
# TabPFNv2   best for <10,000 rows
# TabPFN-2.5 (RealTabPFN-2) up to 50,000 × 2,000
# TabICL     for larger datasets
# TabM       general-purpose; medium-to-large
''',
    notes=[
        "Foundation models are PRETRAINED — they work without much data (TabPFN especially)",
        "MITRA is best for the small-data regime — under 5k samples is its sweet spot",
        "TabPFNv2 / TabPFN-2.5 do in-context inference — no real fitting; ~30 sec on small data",
        "Stack with traditional boosting models inside the same hyperparameters dict for diversity",
        "Foundation models often beat tuned boosting on small data (<2k rows)",
    ],
    when_to_use=[
        "Small dataset (<10k rows) — foundation models often win",
        "Want a specific model rather than the full extreme portfolio",
    ],
    inputs=["train_data, target_col"],
    outputs=["predictor"],
    requires=["autogluon.tabular[mitra,tabicl,tabpfn]"],
)


presets_table = Entry(
    name="presets_table",
    title="Preset cheat sheet — quality vs speed trade-offs",
    code='''# ─── ranked from fastest to most accurate ───
#
# medium_quality       (default)  fast, decent — first pass / sanity check
# good_quality         ~4× faster inference than high_quality
# high_quality         ~8× faster inference than best_quality
# high_quality_v150    high_quality but ~5× faster training
# best_quality         auto_stack + dynamic_stacking; high accuracy
# best_quality_v150    best_quality but ~5× faster training
# experimental_quality bleeding edge; parallel fitting strategy
# extreme_quality      SOTA on TabArena — foundation models + 22-model portfolio
#                      requires GPU + autogluon.tabular[tabarena]
#                      best for ≤100k samples
#
# ─── utility presets (combine with quality presets) ───
#
# optimize_for_deployment   ~2-4× smaller models, no accuracy loss
# interpretable             rule-based models only (worse accuracy, explainable)
# ignore_text               disable auto text feature generation
#
# ── 2-hour test rule of thumb ──
#   t < 5 min:  medium_quality
#   5-30 min:   good_quality or high_quality
#   30-60 min:  high_quality_v150 or best_quality_v150
#   60+ min, GPU + small data:  extreme_quality
''',
    notes=[
        "presets accept a list — combine quality + utility: presets=['high_quality', 'optimize_for_deployment']",
        "extreme is the only preset using foundation models — others are boosting + linear ensembles",
        "_v150 variants (best_quality_v150, high_quality_v150) are newer in 1.5+ — much faster training, similar accuracy",
        "Always set time_limit explicitly — don't rely on the preset's default",
    ],
    requires=[],
)


hyperparameters_override = Entry(
    name="hyperparameters_override",
    title="Hyperparameters override — pick specific models, configs, ensembles",
    code='''from autogluon.tabular import TabularPredictor

# ─── pick a single model family ───
predictor = TabularPredictor(label=target_col).fit(
    train_data,
    hyperparameters={
        "GBM": {},                                      # LightGBM with AutoGluon defaults
    },
    time_limit=300,
)


# ─── pick multiple base models with custom configs ───
predictor = TabularPredictor(label=target_col).fit(
    train_data,
    hyperparameters={
        "GBM": [
            {},                                         # LGBM default
            {"num_leaves": 64, "learning_rate": 0.03},  # second LGBM with custom params
        ],
        "CAT": {},                                      # CatBoost default
        "XGB": {},                                      # XGBoost default
        "RF":  {},                                      # RandomForest
        "EBM": {},                                      # explainable boosting
    },
    time_limit=600,
)


# ─── all stable model strings ───
# GBM     LightGBM
# CAT     CatBoost
# XGB     XGBoost
# RF      RandomForest
# XT      ExtraTrees
# KNN     KNN
# LR      LogReg / Ridge
# NN_TORCH        sklearn-MLP-style PyTorch model
# FASTAI          fastai tabular model
# EBM             Explainable Boosting Machine
# REALMLP         scikit-learn MLP
# TABM            TabM foundation
# MITRA           Mitra foundation
# TABICL          TabICL foundation
# TABPFNV2        TabPFNv2
# AG_AUTOMM       multimodal (used for tabular with image/text columns)


# ─── high-level shortcut strings ───
predictor.fit(
    train_data,
    hyperparameters="default",                          # AG's default config
    # OR "zeroshot"  → portfolio learned from TabArena
    # OR "light"     → fast subset
    # OR "toy"       → tiny config for tests
)
''',
    notes=[
        "hyperparameters dict overrides the preset's choice of models",
        "Pass a LIST under a model key to train multiple variants of that model",
        "Use included_model_types= or excluded_model_types= for simpler whitelist/blacklist",
        "EBM (Explainable Boosting Machine) is genuinely interpretable — useful when explanations matter",
    ],
    when_to_use=[
        "When you want specific model families, not the full preset portfolio",
        "Custom configs per model (e.g., wide-deep LGBM)",
    ],
    inputs=["train_data, target_col"],
    outputs=["predictor"],
    requires=["autogluon.tabular"],
)


leaderboard_reading = Entry(
    name="leaderboard_reading",
    title="Reading predictor.leaderboard() — diagnose what AutoGluon picked",
    code='''# leaderboard prints a DataFrame with columns:
#   model              base model name (e.g., 'LightGBMLarge_FULL_L1')
#   score_test         metric on the test set (or holdout)
#   score_val          metric on internal validation
#   pred_time_test     inference time on test
#   pred_time_val      inference time on val
#   fit_time           training time
#   stack_level        L1 = base, L2+ = stacked on top of L1 OOFs
#   can_infer          whether the model can be used for inference

leaderboard = predictor.leaderboard(test_data, silent=True)
print(leaderboard.head(20))

# the model name appended with "_FULL" was retrained on 100% of data after CV
# the WeightedEnsemble_L2 model is usually the final predictor (top of leaderboard)


# inspect the WeightedEnsemble's recipe — which base models it uses
from autogluon.tabular import TabularPredictor
ensemble_info = predictor.info()["model_info"]["WeightedEnsemble_L2"]
print(ensemble_info)


# get just the validation score of all models
predictor.leaderboard(silent=True)[["model", "score_val", "fit_time"]]


# predictions from a SPECIFIC model (not the ensemble)
proba_lgb = predictor.predict_proba(test_data, model="LightGBMLarge_BAG_L1")
''',
    notes=[
        "WeightedEnsemble_L2 is the default predictor — it stacks L1 base models",
        "_FULL suffix = retrained on 100% of data; usually slightly better than the bagged version",
        "If a foundation model (MITRA, TabPFN) sits at the top, the ensemble is dominated by it — boosting added little",
        "fit_time across rows is approximate — Big differences indicate which models slow you down",
        "For final submission, use the ensemble (default predict()) — it's almost always best",
    ],
    when_to_use=[
        "After fitting, to understand which models AG picked",
        "To investigate why a preset over/under-performed expectations",
    ],
    inputs=["predictor, test_data"],
    outputs=["leaderboard DataFrame"],
    requires=["autogluon.tabular"],
)


eval_metrics = Entry(
    name="eval_metrics",
    title="Custom eval_metric — common values and how to pass yours",
    code='''from autogluon.tabular import TabularPredictor

# ── classification ──
TabularPredictor(label=target_col, eval_metric="accuracy").fit(...)
TabularPredictor(label=target_col, eval_metric="balanced_accuracy").fit(...)
TabularPredictor(label=target_col, eval_metric="roc_auc").fit(...)             # binary
TabularPredictor(label=target_col, eval_metric="roc_auc_ovo").fit(...)         # multiclass
TabularPredictor(label=target_col, eval_metric="f1").fit(...)                  # binary
TabularPredictor(label=target_col, eval_metric="f1_macro").fit(...)            # multi
TabularPredictor(label=target_col, eval_metric="log_loss").fit(...)
TabularPredictor(label=target_col, eval_metric="precision").fit(...)
TabularPredictor(label=target_col, eval_metric="recall").fit(...)
TabularPredictor(label=target_col, eval_metric="quadratic_kappa").fit(...)     # ordinal

# ── regression ──
TabularPredictor(label=target_col, eval_metric="rmse").fit(...)
TabularPredictor(label=target_col, eval_metric="mae").fit(...)
TabularPredictor(label=target_col, eval_metric="r2").fit(...)
TabularPredictor(label=target_col, eval_metric="mean_absolute_percentage_error").fit(...)


# ── custom metric ──
from autogluon.core.metrics import make_scorer
import numpy as np

def custom_score(y_true, y_pred):
    # higher = better (set greater_is_better appropriately)
    return -np.mean((y_true - y_pred) ** 2)

custom_scorer = make_scorer(
    name="my_score",
    score_func=custom_score,
    optimum=0,
    greater_is_better=True,
    needs_proba=False,                                  # True if it needs predict_proba
)
TabularPredictor(label=target_col, eval_metric=custom_scorer).fit(...)
''',
    notes=[
        "eval_metric drives both model selection AND ensemble weighting — match it to the task's actual scoring",
        "For ordinal targets: use quadratic_kappa (not accuracy / f1)",
        "For severe imbalance binary: prefer roc_auc or f1 over accuracy",
        "needs_proba=True for metrics that require probabilities (log_loss, roc_auc)",
    ],
    when_to_use=[
        "Always set eval_metric explicitly — don't rely on AG's default",
    ],
    inputs=["target_col"],
    outputs=["predictor"],
    requires=["autogluon.tabular"],
)


memory_fallback = Entry(
    name="memory_fallback",
    title="Memory fallback — what to do when extreme_quality OOMs on L4",
    code='''# extreme_quality wants 32+ GB vRAM officially. L4 has 24 GB.
# If you hit OOM:

# ── option 1: use the next-strongest preset that fits ──
predictor = TabularPredictor(label=target_col).fit(
    train_data,
    presets="best_quality_v150",                        # 5x faster than best_quality, fits L4
    time_limit=time_limit,
)

# ── option 2: use specific foundation models without the full extreme portfolio ──
predictor = TabularPredictor(label=target_col).fit(
    train_data,
    hyperparameters={
        "GBM": [{}],
        "CAT": {},
        "MITRA": {"fine_tune": False},                  # zero-shot, low memory
    },
    time_limit=time_limit,
)

# ── option 3: subsample training data ──
train_sub = train.sample(n=20_000, random_state=42)     # cap at 20k for foundation models
predictor = TabularPredictor(label=target_col).fit(
    train_sub,
    presets="extreme_quality",
    time_limit=time_limit,
)

# ── option 4: exclude memory-heavy models ──
predictor = TabularPredictor(label=target_col).fit(
    train_data,
    presets="extreme_quality",
    excluded_model_types=["TABPFNV2", "TABM"],          # heaviest in the portfolio
    time_limit=time_limit,
)
''',
    notes=[
        "OOM on L4 with extreme_quality is common at >50k rows — subsample first or drop to best_quality_v150",
        "Foundation models (especially TabPFNv2 and TabM) are memory-hungry — exclude them as a workaround",
        "Subsampling to 20-30k for foundation model training is a fine middle ground — they're designed for small data",
        "best_quality_v150 is genuinely close to extreme on most tasks and never OOMs",
    ],
    when_to_use=[
        "After extreme_quality fails with CUDA OOM",
    ],
    inputs=["train_data, target_col"],
    outputs=["predictor"],
    requires=["autogluon.tabular"],
)


index = _make_index(__name__)
