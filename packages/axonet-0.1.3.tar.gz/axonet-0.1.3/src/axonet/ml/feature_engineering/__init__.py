"""Feature engineering — datetime, interactions, encodings, time-series patterns.

Most entries are tactical (drop into a cell, run, get features). For target/freq
encoding the canonical implementations live elsewhere (failure_modes,
preprocess) — referenced here for visibility.
"""
from ..._entry import Entry, _make_index


datetime_features = Entry(
    name="datetime",
    title="Datetime decomposition — components + cyclical encoding",
    code='''import pandas as pd
import numpy as np

# ─── CONFIG ───
date_col = "timestamp"                                  # column to extract from
# ──────────────

train[date_col] = pd.to_datetime(train[date_col])
test[date_col]  = pd.to_datetime(test[date_col])

for df in (train, test):
    df[f"{date_col}_year"]       = df[date_col].dt.year
    df[f"{date_col}_month"]      = df[date_col].dt.month
    df[f"{date_col}_day"]        = df[date_col].dt.day
    df[f"{date_col}_dow"]        = df[date_col].dt.dayofweek
    df[f"{date_col}_dayofyear"]  = df[date_col].dt.dayofyear
    df[f"{date_col}_hour"]       = df[date_col].dt.hour
    df[f"{date_col}_quarter"]    = df[date_col].dt.quarter
    df[f"{date_col}_is_weekend"] = df[date_col].dt.dayofweek.isin([5, 6]).astype(int)

    # cyclical encoding — preserves "december next to january" relationship
    df[f"{date_col}_month_sin"] = np.sin(2 * np.pi * df[f"{date_col}_month"] / 12)
    df[f"{date_col}_month_cos"] = np.cos(2 * np.pi * df[f"{date_col}_month"] / 12)
    df[f"{date_col}_dow_sin"]   = np.sin(2 * np.pi * df[f"{date_col}_dow"]   / 7)
    df[f"{date_col}_dow_cos"]   = np.cos(2 * np.pi * df[f"{date_col}_dow"]   / 7)
    df[f"{date_col}_hour_sin"]  = np.sin(2 * np.pi * df[f"{date_col}_hour"]  / 24)
    df[f"{date_col}_hour_cos"]  = np.cos(2 * np.pi * df[f"{date_col}_hour"]  / 24)
''',
    notes=[
        "Cyclical encoding (sin/cos) is essential — month=12 and month=1 should be 'close'",
        "Drop the original datetime column after extraction (or trees treat it as numeric epoch)",
        "For time-series tasks, also see lag_rolling for past-value features",
        "is_weekend is small but often valuable; quarter mostly redundant with month",
    ],
    inputs=["train, test, date_col"],
    outputs=["train (mutated), test (mutated)"],
    requires=["pandas", "numpy"],
)


interactions = Entry(
    name="interactions",
    title="Pairwise interactions — products, ratios, row-wise aggregates",
    code='''# usually only worth doing on the top 5-10 most important features
top_features = ["feature_a", "feature_b", "feature_c", "feature_d"]

for df in (train, test):
    # pairwise products and ratios
    for i, c1 in enumerate(top_features):
        for c2 in top_features[i + 1:]:
            df[f"{c1}_x_{c2}"]   = df[c1] * df[c2]
            df[f"{c1}_div_{c2}"] = df[c1] / (df[c2] + 1e-8)

    # row-wise aggregates over the group
    df["feature_sum"]  = df[top_features].sum(axis=1)
    df["feature_mean"] = df[top_features].mean(axis=1)
    df["feature_std"]  = df[top_features].std(axis=1)
    df["feature_min"]  = df[top_features].min(axis=1)
    df["feature_max"]  = df[top_features].max(axis=1)
''',
    notes=[
        "Limit to top 5-10 features — pairwise explodes feature count quickly",
        "Trees can find interactions on their own to some extent — manual interactions help most when the relationship is multiplicative (price × quantity)",
        "Always add 1e-8 to denominators to avoid division-by-zero",
        "Run feature importance first (quick LGBM) to pick which features to interact",
    ],
    inputs=["train, test, top_features"],
    outputs=["train (mutated), test (mutated)"],
    requires=["pandas"],
)


target_encoding_oof = Entry(
    name="target_encoding_oof",
    title="Target encoding (OOF) — see axonet.ml.failure_modes.target_encoding_oof",
    code='''# Canonical implementation lives in axonet.ml.failure_modes.target_encoding_oof
# (placed there because the failure mode is doing it WITHOUT the OOF wrapper).
#
# Usage:
#   from axonet.ml.failure_modes import target_encoding_oof as te
#   print(te)        # see the full code
''',
    notes=[
        "Cross-reference: see axonet.ml.failure_modes.target_encoding_oof",
        "Always use OOF when target-encoding to avoid leakage",
    ],
    requires=[],
)


frequency_encoding = Entry(
    name="frequency_encoding",
    title="Frequency encoding — replace category with its training frequency",
    code='''# fit on train, apply to both
freq_map = train[col].value_counts(normalize=True)
train[f"{col}_freq"] = train[col].map(freq_map)
test[f"{col}_freq"]  = test[col].map(freq_map).fillna(0)   # unseen → 0
''',
    notes=[
        "Cheap, leakage-free, dimension-preserving alternative to one-hot for high-card categoricals",
        "Loses category identity — only preserves 'how common is this value' signal",
        "Combine with target encoding for the best of both signals",
    ],
    inputs=["train, test, col"],
    outputs=["train (mutated), test (mutated)"],
    requires=["pandas"],
)


lag_rolling = Entry(
    name="lag_rolling",
    title="Lag and rolling features for time-structured data",
    code='''# ─── CONFIG ───
group_col   = "user_id"                                 # entity column (None for non-grouped)
time_col    = "timestamp"
target_col  = "target"
lags        = [1, 2, 7, 14, 30]
windows     = [7, 14, 30]
# ──────────────

# CRITICAL: sort by group + time first
train = train.sort_values([group_col, time_col]).reset_index(drop=True)

# lag features — past values shifted forward
for lag in lags:
    train[f"target_lag_{lag}"] = train.groupby(group_col)[target_col].shift(lag)

# rolling statistics — shift first to avoid leaking current row into its own window
for window in windows:
    grp = train.groupby(group_col)[target_col]
    train[f"target_roll_mean_{window}"] = grp.shift(1).rolling(window).mean().reset_index(level=0, drop=True)
    train[f"target_roll_std_{window}"]  = grp.shift(1).rolling(window).std().reset_index(level=0, drop=True)
    train[f"target_roll_max_{window}"]  = grp.shift(1).rolling(window).max().reset_index(level=0, drop=True)
    train[f"target_roll_min_{window}"]  = grp.shift(1).rolling(window).min().reset_index(level=0, drop=True)

# expanding statistics — all-history-up-to-current
train["target_expanding_mean"] = (
    train.groupby(group_col)[target_col]
    .shift(1)
    .expanding().mean()
    .reset_index(level=0, drop=True)
)
''',
    notes=[
        "ALWAYS shift(1) before rolling/expanding — without it, current row leaks into its own window",
        "Lag features will have NaN at the start of each group — leave them, trees handle NaN",
        "For test set: same transform but using trailing rows from train (concat train+test by time, then split back after feature creation)",
        "Window size: depends on natural cadence (daily → 7/14/30; hourly → 24/168)",
    ],
    when_to_use=[
        "Time-series tabular where past values predict future",
    ],
    inputs=["train, group_col, time_col, target_col"],
    outputs=["train (mutated)"],
    requires=["pandas"],
)


group_aggregations = Entry(
    name="group_aggregations",
    title="Per-group aggregation features (entity-level statistics)",
    code='''# ─── CONFIG ───
group_col  = "user_id"
target_col = "target"
agg_funcs = {
    "amount":   ["mean", "std", "min", "max", "count"],
    "duration": ["mean", "std", "median"],
    "category": ["nunique"],
}
# ──────────────

# compute per-group stats on training data
group_stats = train.groupby(group_col).agg(agg_funcs).reset_index()
group_stats.columns = [group_col] + [
    f"{col}_{agg}" for col, aggs in agg_funcs.items() for agg in aggs
]

# merge into both train and test
train = train.merge(group_stats, on=group_col, how="left")
test  = test.merge(group_stats,  on=group_col, how="left")
''',
    notes=[
        "If a user appears in BOTH train and test, group stats from full train alone leak less than per-fold computation",
        "For strict no-leakage: compute stats per fold (OOF) — slower but correct on overlapping groups",
        "Aggregations to consider: count, mean, std, min, max, median, nunique, mode",
        "Especially powerful with 'transactions per user' / 'visits per patient' structure",
    ],
    inputs=["train, test, group_col, agg_funcs"],
    outputs=["train (mutated), test (mutated)"],
    requires=["pandas"],
)


index = _make_index(__name__)
