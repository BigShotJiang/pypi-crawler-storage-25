"""Tabular time-structured data — sectioned end-to-end pipeline.

Differences from generic tabular:
  - sort by time before splitting
  - lag and rolling features (axonet.ml.feature_engineering.lag_rolling)
  - TimeSeriesSplit instead of StratifiedKFold (no leakage from future to past)
"""
from ..._entry import Entry, _make_index


load = Entry(
    name="load",
    title="Section 1 — load CSVs and SORT BY TIME",
    code='''# ─── CONFIG ───
train_path  = "train.csv"
test_path   = "test.csv"
target_col  = "target"
id_col      = "id"
time_col    = "timestamp"                               # the column defining temporal order
group_col   = None                                      # set to e.g. "user_id" for panel data
metric      = "rmse"                                    # rmse / mae / accuracy / f1
# ──────────────

import pandas as pd
import numpy as np

train = pd.read_csv(train_path, parse_dates=[time_col])
test  = pd.read_csv(test_path, parse_dates=[time_col])

# CRITICAL: sort by time (and group, if applicable) before any other step
sort_keys = [time_col] if group_col is None else [group_col, time_col]
train = train.sort_values(sort_keys).reset_index(drop=True)
test  = test.sort_values(sort_keys).reset_index(drop=True)

print(f"train period: {train[time_col].min()} → {train[time_col].max()}")
print(f"test  period: {test[time_col].min()} → {test[time_col].max()}")

test_ids = test[id_col].copy() if id_col in test.columns else pd.Series(range(len(test)), name=id_col)
y = train[target_col]
''',
    notes=[
        "Always sort by time BEFORE feature engineering — lag/rolling features depend on order",
        "If train and test overlap in time, you have leakage by design — split chronologically",
        "Verify train < test in time before proceeding",
    ],
    inputs=["train.csv, test.csv (with time_col)"],
    outputs=["train, test, y, test_ids"],
    requires=["pandas", "numpy"],
)


lag_features = Entry(
    name="lag_features",
    title="Section 2 — lag and rolling features (no shift = leakage)",
    code='''# concatenate train+test for feature creation, then split back
# this allows test rows to use trailing train values without leakage
combined = pd.concat([
    train.assign(_split="train"),
    test.assign(_split="test", **{target_col: np.nan}),
], ignore_index=True)
combined = combined.sort_values(sort_keys).reset_index(drop=True)

# lag features
lags = [1, 2, 7, 14, 30]
for lag in lags:
    if group_col is not None:
        combined[f"target_lag_{lag}"] = combined.groupby(group_col)[target_col].shift(lag)
    else:
        combined[f"target_lag_{lag}"] = combined[target_col].shift(lag)

# rolling features — shift first to prevent leakage of current row into its own window
windows = [7, 14, 30]
for window in windows:
    if group_col is not None:
        grp = combined.groupby(group_col)[target_col]
        combined[f"target_roll_mean_{window}"] = grp.shift(1).rolling(window).mean().reset_index(level=0, drop=True)
        combined[f"target_roll_std_{window}"]  = grp.shift(1).rolling(window).std().reset_index(level=0, drop=True)
    else:
        combined[f"target_roll_mean_{window}"] = combined[target_col].shift(1).rolling(window).mean()
        combined[f"target_roll_std_{window}"]  = combined[target_col].shift(1).rolling(window).std()

# split back
train = combined[combined["_split"] == "train"].drop(columns=["_split"]).reset_index(drop=True)
test  = combined[combined["_split"] == "test" ].drop(columns=["_split", target_col]).reset_index(drop=True)

# refresh y after the resort
y = train[target_col]
''',
    notes=[
        "ALWAYS shift(1) before rolling — without it, current row leaks into its own window",
        "Concat-then-split lets test rows use trailing train values legitimately (no future leakage)",
        "Lags will have NaN at the start of each group; trees handle NaN natively",
        "Window size matches data cadence: daily → [7, 14, 30]; hourly → [24, 168, 720]",
    ],
    inputs=["train, test, target_col, time_col, group_col, sort_keys"],
    outputs=["train, test (with lag and rolling features)"],
    requires=["pandas", "numpy"],
)


preprocess = Entry(
    name="preprocess",
    title="Section 3 — ColumnTransformer (same recipe)",
    code='''# Drop time_col before training — it's already encoded in lag/rolling features
# (also drop group_col if it's high-cardinality; keep it as a feature otherwise)
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OrdinalEncoder

drop_cols_train = [target_col, id_col, time_col]
drop_cols_test  = [id_col, time_col]
X      = train.drop(columns=[c for c in drop_cols_train if c in train.columns])
X_test = test.drop(columns=[c for c in drop_cols_test  if c in test.columns])

num_cols = X.select_dtypes(include="number").columns.tolist()
cat_cols = X.select_dtypes(include=["object", "category"]).columns.tolist()

preprocessor = ColumnTransformer([
    ("num", Pipeline([("imputer", SimpleImputer(strategy="median")), ("scaler", StandardScaler())]), num_cols),
    ("cat", Pipeline([("imputer", SimpleImputer(strategy="constant", fill_value="missing")),
                       ("encoder", OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1))]), cat_cols),
])

X_pp      = preprocessor.fit_transform(X)
X_test_pp = preprocessor.transform(X_test)
''',
    notes=[
        "Drop time_col after lag/rolling features are built — direct timestamps confuse trees",
        "Group column: drop if high-card (>50 unique values) AND group_aggregations were already added; keep if low-card",
    ],
    inputs=["train, test, target_col, id_col, time_col"],
    outputs=["X, X_test, X_pp, X_test_pp"],
    requires=["sklearn"],
)


cv_train_manual = Entry(
    name="cv_train_manual",
    title="Section 4 — TimeSeriesSplit (no leakage from future)",
    code='''import lightgbm as lgb
import numpy as np
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import mean_squared_error

n_splits = 5
oof        = np.zeros(len(X_pp))
test_preds = np.zeros(len(X_test_pp))

# X_pp is already sorted by time from Section 1 — TimeSeriesSplit walks forward
tscv = TimeSeriesSplit(n_splits=n_splits, test_size=None, gap=0)

for fold_idx, (tr_idx, val_idx) in enumerate(tscv.split(X_pp)):
    model = lgb.LGBMRegressor(
        n_estimators=2000,
        learning_rate=0.05,
        num_leaves=31,
        objective="regression",                          # or 'binary' / 'multiclass' for ts classification
        metric="rmse",
        verbose=-1,
        random_state=42,
    )
    model.fit(
        X_pp[tr_idx], y.iloc[tr_idx],
        eval_set=[(X_pp[val_idx], y.iloc[val_idx])],
        callbacks=[lgb.early_stopping(50, verbose=False)],
    )
    oof[val_idx]  = model.predict(X_pp[val_idx])
    test_preds   += model.predict(X_test_pp) / n_splits
    rmse = np.sqrt(mean_squared_error(y.iloc[val_idx], oof[val_idx]))
    print(f"fold {fold_idx}: train [{tr_idx[0]}..{tr_idx[-1]}], val [{val_idx[0]}..{val_idx[-1]}], RMSE = {rmse:.4f}")

print(f"\\nOOF RMSE: {np.sqrt(mean_squared_error(y[oof != 0], oof[oof != 0])):.4f}")

predictions = test_preds                                # already aligned with sorted test
''',
    notes=[
        "TimeSeriesSplit walks forward — train_idx is always BEFORE val_idx in time",
        "First fold has the smallest train set (just the earliest chunk); last fold uses most data",
        "gap= argument: skip rows between train and val (use when prediction has lead time)",
        "test_size= argument: fixed-size validation window (rolling-window pattern)",
        "Don't shuffle — order is the whole point",
    ],
    inputs=["X_pp, y, X_test_pp"],
    outputs=["oof, test_preds, predictions"],
    requires=["lightgbm", "sklearn", "numpy"],
)


cv_train_autogluon = Entry(
    name="cv_train_autogluon",
    title="Section 4b — AutoGluon TabularPredictor (caveat: AG doesn't natively respect time order)",
    code='''# WARNING: AutoGluon's TabularPredictor does NOT use TimeSeriesSplit by default.
# It will use random K-fold internally — which leaks future into past for time-series.
#
# Workaround: explicitly pass a held-out validation set that is the LAST chunk of train.

from autogluon.tabular import TabularDataset, TabularPredictor
import numpy as np
from sklearn.metrics import mean_squared_error

# split chronologically (last 20% as validation)
split_idx = int(len(train) * 0.8)
train_main = train.iloc[:split_idx]
train_val  = train.iloc[split_idx:]
print(f"train_main: {train_main.shape},  train_val: {train_val.shape}")

train_data = TabularDataset(train_main.drop(columns=[c for c in [id_col, time_col] if c in train_main.columns]))
val_data   = TabularDataset(train_val.drop( columns=[c for c in [id_col, time_col] if c in train_val.columns]))
test_data  = TabularDataset(test.drop(      columns=[c for c in [id_col, time_col] if c in test.columns]))

predictor = TabularPredictor(
    label=target_col,
    eval_metric=metric,
    path="./ag_models",
).fit(
    train_data,
    tuning_data=val_data,                                # explicit validation
    presets="best_quality_v150",
    time_limit=3600,
)

test_preds = predictor.predict(test_data).values
val_preds  = predictor.predict(val_data).values
print(f"AG holdout RMSE: {np.sqrt(mean_squared_error(train_val[target_col], val_preds)):.4f}")

predictions = test_preds
''',
    notes=[
        "AutoGluon's auto-CV uses RANDOM splits by default — not appropriate for time-series",
        "Workaround: pass tuning_data= explicitly with the chronological tail of train",
        "For full TimeSeriesSplit-aware autoML, use AutoGluon's TimeSeriesPredictor instead (different API, beyond this scope)",
        "If task is genuinely panel/forecast, the manual TimeSeriesSplit pipeline (Section 4a) is more reliable",
    ],
    inputs=["train, test, target_col, id_col, time_col, metric"],
    outputs=["predictor, test_preds, predictions"],
    requires=["autogluon.tabular", "sklearn", "numpy"],
)


submit = Entry(
    name="submit",
    title="Section 5 — write submission CSV (preserve test row order)",
    code='''from axonet.utils import submit

# CRITICAL: test was sorted in Section 1; predictions are aligned with sorted test
# If submission expects original order, restore it:
test_orig = pd.read_csv(test_path)                       # re-load to get original order
order_map = {row[id_col]: i for i, row in test_orig.iterrows()}
sorted_to_orig = [order_map[v] for v in test_ids.values]

predictions_orig = np.zeros(len(predictions))
for i, orig_pos in enumerate(sorted_to_orig):
    predictions_orig[orig_pos] = predictions[i]

sub = submit(
    predictions_orig,
    test_orig[id_col].values,
    target_col=target_col,
    id_col=id_col,
    filename="submission.csv",
)
sub.head()
''',
    notes=[
        "Test rows were sorted by time in Section 1 — submission usually expects original (unsorted) order",
        "Re-load the original test.csv to recover the order, then re-align predictions",
        "Skip this re-alignment if the task accepts any order (rare)",
    ],
    inputs=["predictions, test_ids, test_path, id_col"],
    outputs=["submission.csv on disk"],
    requires=["axonet.utils", "pandas", "numpy"],
)


index = _make_index(__name__)
