"""Tabular machine learning: building blocks + assembled pipelines."""
from .._entry import _make_index

# building blocks (deep reference)
from . import eda
from . import failure_modes
from . import preprocess
from . import boosting
from . import cv
from . import imbalance
from . import ensemble
from . import calibration
from . import anomaly
from . import feature_engineering
from . import hpo
from . import autogluon

# assembled pipelines (sectioned drop-in cells)
from . import binary
from . import multiclass
from . import regression
from . import ordinal
from . import timeseries


index = _make_index(__name__)
