"""Probability calibration — Platt scaling, isotonic regression, temperature scaling.

Boosting models tend to be over-confident. Calibration matters when downstream
uses thresholds or expected-utility decisions, OR when log-loss is the metric.
"""
from ..._entry import Entry, _make_index


platt = Entry(
    name="platt",
    title="Platt scaling — sigmoid-based calibration",
    code='''from sklearn.calibration import CalibratedClassifierCV
import lightgbm as lgb

base_model = lgb.LGBMClassifier(n_estimators=2000, verbose=-1)
calibrated = CalibratedClassifierCV(base_model, method="sigmoid", cv=5)

calibrated.fit(X_train, y_train)
proba = calibrated.predict_proba(X_test)
''',
    notes=[
        "Platt scaling fits a 1-parameter sigmoid to base model scores",
        "Use when boosting predict_proba is over-confident",
        "Default first try — works well with ~1000+ samples",
        "For non-sigmoidal calibration curves, use isotonic instead",
        "cv=5: model trained on 4/5 folds, calibrated on 1/5; pass int or 'prefit'",
    ],
    when_to_use=[
        "Binary classification, default first try for calibration",
        "Have ~1000+ samples (less data → use isotonic)",
    ],
    inputs=["X_train, y_train, X_test"],
    outputs=["proba (calibrated)"],
    requires=["sklearn", "lightgbm"],
)


isotonic = Entry(
    name="isotonic",
    title="Isotonic regression — non-parametric calibration",
    code='''from sklearn.calibration import CalibratedClassifierCV
import lightgbm as lgb

base_model = lgb.LGBMClassifier(n_estimators=2000, verbose=-1)
# isotonic: fits a piecewise-constant non-decreasing function — more flexible than Platt
calibrated = CalibratedClassifierCV(base_model, method="isotonic", cv=5)

calibrated.fit(X_train, y_train)
proba = calibrated.predict_proba(X_test)
''',
    notes=[
        "More flexible than Platt — fits any monotonic shape (not just sigmoid)",
        "Risk of overfitting on small data (<1000) — use Platt instead in that regime",
        "Output is not differentiable — fine for inference, awkward for further differentiable layers",
    ],
    when_to_use=[
        "Boosting + 1000+ samples + want best calibration",
        "When Platt scaling underperforms",
    ],
    inputs=["X_train, y_train, X_test"],
    outputs=["proba (calibrated)"],
    requires=["sklearn", "lightgbm"],
)


temperature = Entry(
    name="temperature",
    title="Temperature scaling — single-scalar calibration for NN logits",
    code='''import torch
import torch.nn as nn


class TemperatureScaling(nn.Module):
    """Calibrated logits = logits / T.
    T > 1 softens (over-confident → less confident); T < 1 sharpens.
    """
    def __init__(self):
        super().__init__()
        self.T = nn.Parameter(torch.ones(1) * 1.5)

    def forward(self, logits):
        return logits / self.T


# fit T on validation set (NOT training — that's the over-confident set)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
temp_model = TemperatureScaling().to(device)
optimizer = torch.optim.LBFGS([temp_model.T], lr=0.01, max_iter=50)

def closure():
    optimizer.zero_grad()
    loss = nn.functional.cross_entropy(temp_model(val_logits), val_labels)
    loss.backward()
    return loss

optimizer.step(closure)
print(f"learned T = {temp_model.T.item():.3f}")

# apply at inference
test_logits_calibrated = test_logits / temp_model.T.detach()
test_proba = torch.softmax(test_logits_calibrated, dim=-1)
''',
    notes=[
        "Single scalar — preserves argmax (relative ordering unchanged)",
        "Standard fix for over-confident neural networks (Guo et al. 2017)",
        "Fit on a held-out validation set; never on training data",
        "L-BFGS converges in <50 iterations",
    ],
    when_to_use=[
        "Neural network classifier (image/text/audio) where probabilities are over-confident",
        "When downstream uses thresholds or expected-utility decisions",
    ],
    inputs=["val_logits, val_labels, test_logits"],
    outputs=["test_proba (calibrated)"],
    requires=["torch"],
)


index = _make_index(__name__)
