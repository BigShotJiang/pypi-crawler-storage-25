"""Anomaly detection — supervised, semi-supervised, and unsupervised tabular methods.

Pick by data shape: IsolationForest for mixed types & medium data; Mahalanobis
for ~Gaussian normals; Autoencoder for non-linear; OneClassSVM for small data;
MSP for free post-hoc OOD on a trained classifier.
"""
from ..._entry import Entry, _make_index


isolation_forest = Entry(
    name="isolation_forest",
    title="Isolation Forest — fast unsupervised anomaly detection",
    code='''from sklearn.ensemble import IsolationForest
import numpy as np

iso = IsolationForest(
    n_estimators=200,
    contamination=0.05,                                 # expected anomaly fraction; "auto" for default
    max_samples="auto",
    random_state=42,
    n_jobs=-1,
)

# fit on training data (typically all-normal, or mixed if contamination is set)
iso.fit(X_train)

# scores: lower = more anomalous (negative log-density-like)
anomaly_scores = -iso.score_samples(X_test)             # negate so higher = more anomalous

# binary prediction: +1 normal, -1 anomalous
predictions = iso.predict(X_test)
is_anomaly = (predictions == -1).astype(int)

# threshold-based on top-k% (when contamination is uncertain)
threshold = np.quantile(anomaly_scores, 0.95)
is_anomaly_top5 = (anomaly_scores > threshold).astype(int)
''',
    notes=[
        "Default first try for tabular anomaly — fast, decent accuracy",
        "contamination= must roughly match expected anomaly fraction",
        "Score is the negation of score_samples — higher value = more anomalous",
        "Combine with autoencoder + mahalanobis via score averaging for robustness",
    ],
    when_to_use=[
        "Mixed numeric + categorical, medium-to-large data",
        "Quick anomaly baseline",
    ],
    inputs=["X_train, X_test"],
    outputs=["anomaly_scores, is_anomaly"],
    requires=["sklearn", "numpy"],
)


autoencoder = Entry(
    name="autoencoder",
    title="Autoencoder reconstruction error — anomaly via failed reconstruction",
    code='''import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
import numpy as np


class Autoencoder(nn.Module):
    def __init__(self, input_dim, hidden_dim=64, bottleneck_dim=16):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, bottleneck_dim),
        )
        self.decoder = nn.Sequential(
            nn.Linear(bottleneck_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, input_dim),
        )

    def forward(self, x):
        return self.decoder(self.encoder(x))


# train on NORMAL data only — anomalies break the reconstruction objective
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
ae = Autoencoder(input_dim=X_normal.shape[1]).to(device)
optimizer = torch.optim.Adam(ae.parameters(), lr=1e-3)
criterion = nn.MSELoss()

X_tensor = torch.tensor(X_normal.values, dtype=torch.float32).to(device)
loader = DataLoader(TensorDataset(X_tensor, X_tensor), batch_size=256, shuffle=True)

for epoch in range(50):
    ae.train()
    for batch_x, _ in loader:
        recon = ae(batch_x)
        loss = criterion(recon, batch_x)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()


# score: reconstruction error (per row)
ae.eval()
X_test_tensor = torch.tensor(X_test.values, dtype=torch.float32).to(device)
with torch.no_grad():
    recon = ae(X_test_tensor)
    errors = ((recon - X_test_tensor) ** 2).mean(dim=1).cpu().numpy()

# threshold from held-out normal data (NOT test data)
threshold = np.percentile(train_errors, 95)
is_anomaly = (errors > threshold).astype(int)
''',
    notes=[
        "Train on NORMAL data only — anomalies break the reconstruction objective",
        "Bottleneck dim controls capacity: too large = AE memorizes anomalies; too small = misses subtle patterns",
        "Compute threshold on held-out normal data — never tune on test",
        "Often outperforms IsolationForest when features have non-linear structure",
    ],
    when_to_use=[
        "Tabular anomaly detection with available 'normal-only' data",
        "Features have non-linear structure trees miss",
    ],
    inputs=["X_normal (train), X_test"],
    outputs=["errors, is_anomaly"],
    requires=["torch", "numpy"],
)


mahalanobis = Entry(
    name="mahalanobis",
    title="Mahalanobis distance — assumes normals are roughly Gaussian",
    code='''import numpy as np
from scipy.linalg import inv

# fit on normal data
mean = X_normal.mean(axis=0).values
cov  = np.cov(X_normal.values.T)
cov_inv = inv(cov + 1e-6 * np.eye(cov.shape[0]))        # regularize for invertibility


def mahalanobis_dist(X, mean, cov_inv):
    diff = X - mean
    return np.sqrt(np.sum(diff @ cov_inv * diff, axis=1))


train_distances = mahalanobis_dist(X_normal.values, mean, cov_inv)
test_distances  = mahalanobis_dist(X_test.values,   mean, cov_inv)

# threshold at 95th percentile of training distances
threshold = np.percentile(train_distances, 95)
is_anomaly = (test_distances > threshold).astype(int)
''',
    notes=[
        "Assumes normal class is roughly Gaussian — bad fit for highly non-Gaussian data",
        "Add 1e-6 * I to covariance to ensure invertibility (especially with collinear features)",
        "Pairs well with PCA: project to k components first, compute Mahalanobis in reduced space",
        "Closed-form (no training loop) — fastest of the anomaly detectors",
    ],
    when_to_use=[
        "Normal class is roughly Gaussian (e.g., low-dim sensor data)",
        "Fast baseline alongside IsolationForest",
    ],
    inputs=["X_normal, X_test"],
    outputs=["test_distances, is_anomaly"],
    requires=["numpy", "scipy"],
)


one_class_svm = Entry(
    name="one_class_svm",
    title="One-Class SVM — small data, non-linear normal boundaries",
    code='''from sklearn.svm import OneClassSVM
import numpy as np

# nu = upper bound on fraction of training errors (~contamination)
ocs = OneClassSVM(nu=0.05, kernel="rbf", gamma="scale")
ocs.fit(X_normal)

# +1 normal, -1 anomalous
predictions = ocs.predict(X_test)
is_anomaly = (predictions == -1).astype(int)

# decision function: positive = normal, negative = anomaly
scores = -ocs.score_samples(X_test)                     # invert so higher = more anomalous
''',
    notes=[
        "O(n²) training cost — only practical for ≤5,000 training samples",
        "RBF kernel with gamma='scale' is the default; tune gamma if results are poor",
        "nu controls trade-off: lower = stricter (fewer points labeled anomalous)",
        "For larger data, IsolationForest or Autoencoder are usually better trade-offs",
    ],
    when_to_use=[
        "Small training set (<5k rows) with non-linear normal distribution",
        "When tree-based methods underperform",
    ],
    inputs=["X_normal, X_test"],
    outputs=["is_anomaly, scores"],
    requires=["sklearn", "numpy"],
)


msp = Entry(
    name="msp",
    title="MSP — max softmax probability post-hoc OOD on a trained classifier",
    code='''import numpy as np

# given a classifier already trained on (in-distribution) class labels,
# score OOD via its uncertainty. No retraining.

proba = trained_classifier.predict_proba(X_test)        # (n, K)
max_probs = proba.max(axis=1)
ood_score_msp = 1 - max_probs                            # higher = more OOD

# energy-based OOD (often beats MSP) — needs raw logits, not just proba
# E(x) = -logsumexp(logits)
# logits = trained_classifier.predict_log_proba(X_test)
# energy = -np.logaddexp.reduce(logits, axis=1)         # higher = more OOD

# threshold via held-out validation set with known anomalies, OR a quantile
threshold = np.quantile(ood_score_msp_train, 0.95)
is_ood = (ood_score_msp > threshold).astype(int)
''',
    notes=[
        "Free if you already have a classifier — no separate training",
        "MSP is the simplest OOD signal; energy-based is stronger but needs logits",
        "Works on any classifier with predict_proba — sklearn, boosting, neural networks",
        "Pair with calibration (temperature scaling) if MSP is over-confident on in-distribution data",
    ],
    when_to_use=[
        "You already have a trained classifier and want to flag uncertain test rows",
        "Adding OOD detection as a secondary score",
    ],
    inputs=["trained_classifier, X_test"],
    outputs=["ood_score_msp, is_ood"],
    requires=["numpy"],
)


index = _make_index(__name__)
