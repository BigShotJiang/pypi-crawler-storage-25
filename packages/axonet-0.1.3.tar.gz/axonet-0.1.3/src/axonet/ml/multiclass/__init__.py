"""Tabular multiclass classification — sectioned end-to-end pipeline.

Differences from binary:
  - predict_proba returns (n, K) instead of (n, 2) — index by argmax, not threshold
  - metric defaults to log_loss / accuracy / f1_macro (NOT roc_auc)
  - LightGBM objective='multiclass' + num_class=K

For ordinal targets, see axonet.ml.ordinal instead.
"""
from ..._entry import Entry, _make_index


load = Entry(
    name="load",
    title="Section 1 — load CSVs and split features/target (multiclass)",
    code='''# ─── CONFIG ───
train_path = "train.csv"
test_path  = "test.csv"
target_col = "target"
id_col     = "id"
metric     = "f1_macro"                                 # f1_macro / accuracy / log_loss
# ──────────────

import pandas as pd
import numpy as np

train = pd.read_csv(train_path)
test  = pd.read_csv(test_path)
print(f"train: {train.shape},  test: {test.shape}")

test_ids = test[id_col].copy() if id_col in test.columns else pd.Series(range(len(test)), name=id_col)

# encode string target labels to integers if needed
y_raw = train[target_col]
if y_raw.dtype == "object":
    classes_ = sorted(y_raw.unique())
    label_map = {c: i for i, c in enumerate(classes_)}
    inv_label_map = {i: c for c, i in label_map.items()}
    y = y_raw.map(label_map)
    print(f"label encoding: {label_map}")
else:
    y = y_raw
    classes_ = sorted(y.unique())
    inv_label_map = {i: i for i in classes_}

num_classes = len(classes_)
print(f"num_classes: {num_classes}")
print(f"class balance: {y.value_counts().sort_index().to_dict()}")

X = train.drop(columns=[c for c in [target_col, id_col] if c in train.columns])
X_test = test.drop(columns=[c for c in [id_col] if c in test.columns])
''',
    notes=[
        "If target is strings, build label_map and inv_label_map for round-trip during submission",
        "Run axonet.ml.failure_modes.ordinal_check to confirm this is plain multiclass (not ordinal)",
        "If ordinal, use axonet.ml.ordinal pipeline instead — regression+round wins on QWK",
    ],
    inputs=["train.csv, test.csv"],
    outputs=["X, y, X_test, test_ids, target_col, id_col, metric, num_classes, inv_label_map"],
    requires=["pandas", "numpy"],
)


preprocess = Entry(
    name="preprocess",
    title="Section 2 — ColumnTransformer (same as binary)",
    code='''# Same as axonet.ml.binary.preprocess — ColumnTransformer with numeric scale + categorical ordinal
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OrdinalEncoder

num_cols = X.select_dtypes(include="number").columns.tolist()
cat_cols = X.select_dtypes(include=["object", "category"]).columns.tolist()

preprocessor = ColumnTransformer([
    ("num", Pipeline([("imputer", SimpleImputer(strategy="median")), ("scaler", StandardScaler())]), num_cols),
    ("cat", Pipeline([("imputer", SimpleImputer(strategy="constant", fill_value="missing")),
                       ("encoder", OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1))]), cat_cols),
])

X_pp      = preprocessor.fit_transform(X)
X_test_pp = preprocessor.transform(X_test)
''',
    notes=[
        "Identical to binary preprocess — see axonet.ml.binary.preprocess for variants",
        "For high-cardinality cats: see axonet.ml.preprocess.encoders",
    ],
    inputs=["X, X_test"],
    outputs=["X_pp, X_test_pp, num_cols, cat_cols"],
    requires=["sklearn"],
)


cv_train_manual = Entry(
    name="cv_train_manual",
    title="Section 3a — multiclass OOF training with LightGBM",
    code='''import lightgbm as lgb
import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import f1_score, accuracy_score, log_loss

n_splits = 5
oof        = np.zeros((len(X_pp), num_classes))
test_preds = np.zeros((len(X_test_pp), num_classes))

skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)

for fold_idx, (tr_idx, val_idx) in enumerate(skf.split(X_pp, y)):
    model = lgb.LGBMClassifier(
        n_estimators=2000,
        learning_rate=0.05,
        num_leaves=31,
        min_child_samples=20,
        subsample=0.8,
        colsample_bytree=0.8,
        objective="multiclass",
        num_class=num_classes,
        metric="multi_logloss",
        verbose=-1,
        random_state=42,
        # class_weight="balanced",                      # uncomment if imbalanced
    )
    model.fit(
        X_pp[tr_idx], y.iloc[tr_idx],
        eval_set=[(X_pp[val_idx], y.iloc[val_idx])],
        callbacks=[lgb.early_stopping(50, verbose=False)],
    )
    oof[val_idx]  = model.predict_proba(X_pp[val_idx])
    test_preds   += model.predict_proba(X_test_pp) / n_splits

# evaluation
oof_argmax = oof.argmax(axis=1)
print(f"OOF accuracy: {accuracy_score(y, oof_argmax):.4f}")
print(f"OOF macro-F1: {f1_score(y, oof_argmax, average='macro'):.4f}")
print(f"OOF log-loss: {log_loss(y, oof):.4f}")

# final predictions = argmax over averaged test probabilities
predictions = test_preds.argmax(axis=1)
''',
    notes=[
        "objective='multiclass' + num_class=K is mandatory for LightGBM multiclass",
        "predict_proba returns (n, K); argmax to get class predictions",
        "For severe imbalance: class_weight='balanced' OR per-class weights via sample_weight",
        "Per-class breakdown: from sklearn.metrics import classification_report; print(classification_report(y, oof_argmax))",
    ],
    inputs=["X_pp, y, X_test_pp, num_classes"],
    outputs=["oof, test_preds, predictions"],
    requires=["lightgbm", "sklearn", "numpy"],
)


cv_train_autogluon = Entry(
    name="cv_train_autogluon",
    title="Section 3b — AutoGluon TabularPredictor (multiclass)",
    code='''# AutoGluon auto-detects multiclass when target has 3+ unique values
from autogluon.tabular import TabularDataset, TabularPredictor
from sklearn.metrics import f1_score, accuracy_score

train_data = TabularDataset(train.drop(columns=[c for c in [id_col] if c in train.columns]))
test_data  = TabularDataset(test.drop(columns=[c for c in [id_col] if c in test.columns]))

predictor = TabularPredictor(
    label=target_col,
    eval_metric=metric,                                 # f1_macro / accuracy / log_loss
    path="./ag_models",
).fit(
    train_data,
    presets="best_quality_v150",
    time_limit=3600,
)

predictor.leaderboard(silent=True).head(10)

# OOF + test predictions
oof_proba  = predictor.predict_proba_oof().values
test_proba = predictor.predict_proba(test_data).values

oof_argmax = oof_proba.argmax(axis=1)
predictions = test_proba.argmax(axis=1)

print(f"AG OOF accuracy: {accuracy_score(y, oof_argmax):.4f}")
print(f"AG OOF macro-F1: {f1_score(y, oof_argmax, average='macro'):.4f}")
''',
    notes=[
        "AutoGluon detects multiclass automatically — no special config needed",
        "predict_proba returns a DataFrame; .values gives a (n, K) numpy array",
        "Use eval_metric='f1_macro' for imbalanced multiclass; 'log_loss' if calibration matters",
        "Skip Section 2 (preprocess) — AG handles it internally",
    ],
    inputs=["train, test, target_col, id_col, metric, num_classes"],
    outputs=["predictor, oof_proba, test_proba, predictions"],
    requires=["autogluon.tabular", "sklearn"],
)


submit = Entry(
    name="submit",
    title="Section 4 — write submission CSV (multiclass)",
    code='''from axonet.utils import submit

# if target was string-encoded, decode predictions back to original labels
if inv_label_map and not all(k == v for k, v in inv_label_map.items()):
    predictions_out = pd.Series(predictions).map(inv_label_map).values
else:
    predictions_out = predictions

sub = submit(
    predictions_out,
    test_ids,
    target_col=target_col,
    id_col=id_col,
    filename="submission.csv",
)
sub.head()
''',
    notes=[
        "If target was strings, decode via inv_label_map BEFORE writing — submission system expects original labels",
        "axonet.utils.submit asserts no NaNs, no dup ids, row count match",
        "Some tasks want one column of probabilities per class (e.g., proba_class_0, proba_class_1, ...) — adapt the column shape if needed",
    ],
    inputs=["predictions, test_ids, target_col, id_col, inv_label_map"],
    outputs=["submission.csv on disk"],
    requires=["axonet.utils"],
)


index = _make_index(__name__)
