"""Written-answer entries — short canned answers for embedded qualitative
questions in scaffolded tasks.
"""
from .._entry import Entry, _make_index


focal_loss_alpha_gamma = Entry(
    name="focal_loss_alpha_gamma",
    title="Q: What do alpha and gamma do in focal loss?",
    code="""Focal loss is FL(p_t) = -alpha_t * (1 - p_t)^gamma * log(p_t).

Gamma is the focusing parameter: it down-weights easy (high-confidence
correct) examples by a factor of (1 - p_t)^gamma so training signal
concentrates on hard examples. Higher gamma = more aggressive down-weighting.
Typical: gamma = 2.

Alpha is the class-balance parameter: a per-class weight that up-weights the
rare class. Typical: alpha = 0.25 for the foreground class in detection
(where background dominates).
""",
    notes=["2-3 sentences with the right concepts is full marks"],
)


index = _make_index(__name__)
