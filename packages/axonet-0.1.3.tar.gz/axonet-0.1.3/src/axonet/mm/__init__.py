"""Multimodal entries (vision + language, fusion, VLMs)."""
from .._entry import Entry, _make_index


clip_zero_shot = Entry(
    name="clip_zero_shot",
    title="CLIP / SigLIP zero-shot image classification (placeholder)",
    when_to_use=[
        "Zero or few labeled examples, but class names are descriptive",
        "Quick first-pass on any image classification task",
    ],
    code="# placeholder — CLIPProcessor + CLIPModel, prompt template ensemble\n",
    notes=[
        "Prompt engineering matters — ensemble across multiple templates",
        "SigLIP-2 often beats CLIP at similar scale",
    ],
    requires=["transformers", "torch"],
)


index = _make_index(__name__)
