"""Task-agnostic utilities."""
import sys

from .._entry import _make_index
from . import refs


def preflight():
    """Print environment summary: Python, key library versions, GPU status."""
    lines = [f"Python: {sys.version.split()[0]}"]

    for mod_name in ("numpy", "pandas", "sklearn", "torch", "transformers",
                     "torchvision", "torchaudio", "lightgbm", "xgboost", "catboost",
                     "autogluon"):
        try:
            mod = __import__(mod_name)
            lines.append(f"{mod_name}: {getattr(mod, '__version__', '?')}")
        except ImportError:
            lines.append(f"{mod_name}: not installed")

    try:
        import torch
        if torch.cuda.is_available():
            props = torch.cuda.get_device_properties(0)
            lines.append(f"cuda: {torch.cuda.get_device_name(0)} ({props.total_memory / 1e9:.1f} GB)")
        else:
            lines.append("cuda: not available")
    except ImportError:
        pass

    print("\n".join(lines))


def set_seed(seed=42):
    """Seed numpy, random, torch (and cuda if available) for reproducibility."""
    import random
    random.seed(seed)
    try:
        import numpy as np
        np.random.seed(seed)
    except ImportError:
        pass
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except ImportError:
        pass


def detect_columns(df, target_col=None, id_like_threshold=0.95):
    """Detect column types in a DataFrame.

    Returns a dict with keys: numeric, categorical, datetime, id_like,
    high_cardinality. Excludes target_col from all lists.

    id_like_threshold: a column with unique-ratio above this is flagged id-like.
    """
    import pandas as pd

    out = {
        "numeric": [],
        "categorical": [],
        "datetime": [],
        "id_like": [],
        "high_cardinality": [],
    }
    n = max(len(df), 1)
    for col in df.columns:
        if col == target_col:
            continue
        s = df[col]
        if pd.api.types.is_datetime64_any_dtype(s):
            out["datetime"].append(col)
        elif pd.api.types.is_numeric_dtype(s):
            unique_ratio = s.nunique(dropna=True) / n
            if unique_ratio > id_like_threshold:
                out["id_like"].append(col)
            else:
                out["numeric"].append(col)
        else:  # object / category / bool
            n_unique = s.nunique(dropna=True)
            unique_ratio = n_unique / n
            if unique_ratio > id_like_threshold:
                out["id_like"].append(col)
            elif n_unique > 50:
                out["high_cardinality"].append(col)
            else:
                out["categorical"].append(col)
    return out


def check_dataset(train, test=None, target_col=None):
    """Run sanity checks on a train (and optionally test) DataFrame.

    Prints findings — column overlap, target distribution + imbalance ratio,
    missing data summary, duplicate rows. Doesn't return anything.
    """
    print(f"train: {train.shape}" + (f",  test: {test.shape}" if test is not None else ""))

    # train/test schema mismatch
    if test is not None:
        train_cols = set(train.columns) - {target_col} if target_col else set(train.columns)
        test_cols = set(test.columns)
        only_train = train_cols - test_cols
        only_test = test_cols - train_cols
        if only_train:
            print(f"  ⚠ in train but not test: {sorted(only_train)}")
        if only_test:
            print(f"  ⚠ in test but not train: {sorted(only_test)}")

    # target distribution
    if target_col and target_col in train.columns:
        vc = train[target_col].value_counts(dropna=False)
        if len(vc) <= 50:
            print(f"  target distribution: {vc.to_dict()}")
            ratio = vc.max() / max(vc.min(), 1)
            if ratio > 2:
                print(f"  imbalance ratio: {ratio:.1f}" + ("  (severe)" if ratio > 10 else ""))
        else:
            print(f"  target: continuous-like ({len(vc)} unique values)")

    # missing data
    miss = train.isna().sum()
    miss = miss[miss > 0].sort_values(ascending=False)
    if len(miss) > 0:
        print(f"  missing values (top 5):")
        for col, n in miss.head(5).items():
            print(f"    {col}: {n} ({n / len(train):.1%})")

    # duplicates
    dup = train.duplicated().sum()
    if dup > 0:
        print(f"  ⚠ {dup} duplicate rows in train")


def submit(predictions, ids, *, target_col="target", id_col="id",
           filename="submission.csv", dtype=None):
    """Write a clean submission CSV with sanity checks.

    predictions: 1D array-like of predicted labels/values
    ids:         1D array-like of test row identifiers
    target_col:  column name for predictions in the CSV
    id_col:      column name for ids in the CSV
    dtype:       optional dtype to cast predictions to (e.g., int, str)

    Asserts: row count match, no duplicate ids, no NaN predictions.
    """
    import pandas as pd
    import numpy as np

    sub = pd.DataFrame({id_col: list(ids), target_col: list(predictions)})
    if dtype is not None:
        sub[target_col] = sub[target_col].astype(dtype)

    assert len(sub) == len(predictions), "row count mismatch"
    assert not sub[id_col].duplicated().any(), f"duplicate values in {id_col}"
    assert sub[target_col].isna().sum() == 0, f"NaN values in {target_col}"

    sub.to_csv(filename, index=False)
    print(f"wrote {filename} ({len(sub)} rows; columns: {id_col}, {target_col})")
    return sub


def find(query):
    """Search across all entries for a query string. Recurses into sub-subpackages
    and force-imports top-level subpackages on the first call. Returns full
    dotted paths (e.g., 'axonet.ml.preprocess.encoders').
    """
    import axonet
    import importlib
    import types

    query_lower = query.lower()
    hits = []

    # force-import top-level subpackages so lazy-loaded ones are searchable
    for sub_name in axonet._subpackages:
        try:
            importlib.import_module(f"axonet.{sub_name}")
        except ImportError:
            pass

    def search(module, prefix):
        for attr_name in dir(module):
            if attr_name.startswith("_") or attr_name == "index":
                continue
            attr = getattr(module, attr_name, None)
            if attr is None:
                continue
            path = f"{prefix}.{attr_name}"
            if isinstance(attr, types.ModuleType):
                # recurse only into axonet submodules
                if getattr(attr, "__name__", "").startswith("axonet"):
                    search(attr, path)
            else:
                haystack = " ".join([
                    str(getattr(attr, "name", "")),
                    str(getattr(attr, "title", "")),
                    str(getattr(attr, "brief", "")),
                    " ".join(getattr(attr, "notes", []) or []),
                    " ".join(getattr(attr, "when_to_use", []) or []),
                ]).lower()
                if query_lower in haystack:
                    hits.append(path)

    for sub_name in axonet._subpackages:
        sub = getattr(axonet, sub_name, None)
        if sub is not None:
            search(sub, f"axonet.{sub_name}")

    return hits


index = _make_index(__name__)
