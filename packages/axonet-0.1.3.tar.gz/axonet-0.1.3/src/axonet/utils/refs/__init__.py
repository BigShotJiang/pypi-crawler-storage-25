"""API references for common libraries.

Keys map to short, copy-paste idioms for each library — pandas, numpy, torch,
huggingface, sklearn, etc. Each entry follows the same shape as the rest of
the package.
"""
from ..._entry import Entry, _make_index


python_idioms = Entry(
    name="python_idioms",
    title="Common Python idioms (placeholder)",
    code='''# list / dict comprehensions
xs = [f(x) for x in iterable if cond(x)]
d = {k: v for k, v in pairs}

# defaultdict
from collections import defaultdict
counts = defaultdict(int)
for x in items: counts[x] += 1

# pathlib
from pathlib import Path
for p in Path("data").rglob("*.csv"): ...

# sorting with key
sorted(items, key=lambda x: (x.score, -x.size))
''',
    notes=["Placeholder — fuller cheatsheet entries to be added"],
)


torch_idioms = Entry(
    name="torch_idioms",
    title="Common PyTorch idioms (placeholder)",
    code='''import torch
import torch.nn as nn
import torch.nn.functional as F

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# AMP
scaler = torch.amp.GradScaler("cuda")
with torch.amp.autocast("cuda", dtype=torch.float16):
    out = model(x)
    loss = criterion(out, y)
scaler.scale(loss).backward()
scaler.step(optimizer)
scaler.update()

# eval mode + no_grad
model.eval()
with torch.no_grad():
    preds = model(x)
''',
    notes=["torch.cuda.amp.autocast was renamed to torch.amp.autocast(device_type=...)"],
)


index = _make_index(__name__)
