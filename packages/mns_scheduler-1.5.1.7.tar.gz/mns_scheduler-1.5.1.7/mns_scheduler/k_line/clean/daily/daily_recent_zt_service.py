import sys
import os

file_path = os.path.abspath(__file__)
end = file_path.index('mns') + 16
project_path = file_path[0:end]
sys.path.append(project_path)
from functools import lru_cache
import mns_common.component.trade_date.trade_date_common_service_api as trade_date_common_service_api
import mns_common.constant.db_name_constant as db_name_constant
from mns_common.db.MongodbUtil import MongodbUtil
import mns_common.utils.data_frame_util as data_frame_util

mongodb_util = MongodbUtil('27017')
from loguru import logger
import pandas as pd

# todo 排除最近连板的股票
# todo 逻辑: 大炒过的股票,就像被多人玩过的女人,套牢盘太多,短期不具备博弈机会,股票有周期,女人没有

# 今日到之前最早连板开始时间 60个交易日
recent_days = 60
# 最大连板数目 SH
max_connected_boards_numbers_sh = 4
# 最大连板数目 KCX 创业 科创
max_connected_boards_numbers_kcx = 2


@lru_cache(maxsize=None)
def get_recent_connected_boards_zt(str_day):
    before_day = trade_date_common_service_api.get_before_trade_date(str_day, recent_days)
    query = {"$and": [{"str_day": {"$gte": before_day}}, {"str_day": {"$lte": str_day}}],
             'connected_boards_numbers': {"$gte": 2}}
    stock_zt_pool_df = mongodb_util.find_query_data(db_name_constant.STOCK_ZT_POOL, query)
    stock_zt_pool_df = stock_zt_pool_df.loc[stock_zt_pool_df.groupby('symbol')['connected_boards_numbers'].idxmax()]

    stock_zt_pool_df = stock_zt_pool_df.loc[((stock_zt_pool_df['classification'].isin(['S', 'H']))
                                             & (stock_zt_pool_df[
                                                    'connected_boards_numbers'] >= max_connected_boards_numbers_sh))
                                            | ((stock_zt_pool_df['classification'].isin(['K', 'C', 'X']))
                                               & (stock_zt_pool_df[
                                                      'connected_boards_numbers'] >= max_connected_boards_numbers_kcx))]

    if data_frame_util.is_empty(stock_zt_pool_df):
        return pd.DataFrame()
    else:
        stock_zt_pool_df = stock_zt_pool_df.sort_values(by=['connected_boards_numbers'], ascending=False)
        return stock_zt_pool_df


def exclude_recent_connected_boards_zt_stock(str_day, symbol, k_line_info):
    recent_connected_boards_zt_pool_df = get_recent_connected_boards_zt(str_day)
    if data_frame_util.is_empty(recent_connected_boards_zt_pool_df):
        return k_line_info
    else:
        recent_connected_boards_zt_one_pool_df = recent_connected_boards_zt_pool_df.loc[
            recent_connected_boards_zt_pool_df['symbol'] == symbol]
        if data_frame_util.is_empty(recent_connected_boards_zt_one_pool_df):
            return k_line_info
        else:
            # 排除连板股票
            k_line_info.loc[:, 'exclude'] = True
            return k_line_info


if __name__ == '__main__':
    get_recent_connected_boards_zt('2026-04-10')
