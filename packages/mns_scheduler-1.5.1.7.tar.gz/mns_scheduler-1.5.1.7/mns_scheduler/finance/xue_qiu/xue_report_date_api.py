import sys
import os

file_path = os.path.abspath(__file__)
end = file_path.index('mns') + 16
project_path = file_path[0:end]
sys.path.append(project_path)
from datetime import datetime


def get_current_report_dates():
    """
    根据当前系统时间，返回对应需要公布的财报截止日期（A股规则）
    格式：YYYY-MM-DD 列表
    """
    now = datetime.now()
    year = now.year
    month = now.month

    # 1-4月：年报（去年） + 一季报（今年）
    if 1 <= month <= 4:
        return [
            f"{year - 1}-12-30",
            f"{year}-03-30"
        ]
    # 7-8月：半年报
    elif 7 <= month <= 8:
        return [f"{year}-06-29"]
    # 10月：三季报
    elif month == 10:
        return [f"{year}-09-29"]
    # 5、6、9、11、12月：无财报
    else:
        return []


# 直接调用查看结果
if __name__ == "__main__":
    result = get_current_report_dates()
    print("当前财报季度日期：", result)