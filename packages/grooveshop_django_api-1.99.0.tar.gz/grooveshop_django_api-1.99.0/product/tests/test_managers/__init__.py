"""Tests for custom managers."""
